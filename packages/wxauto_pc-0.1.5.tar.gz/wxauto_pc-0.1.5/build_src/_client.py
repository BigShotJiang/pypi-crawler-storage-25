"""微信客户端核心类。"""

from __future__ import annotations

import ctypes
import os
import re
import time
from typing import Dict, List, Optional, Tuple

try:
    import pyperclip
except ImportError:
    pyperclip = None

try:
    import win32api
    import win32con
except ImportError:
    win32api = None
    win32con = None

from wxauto_pc.storage.message_cache import MessageCache

try:
    import uiautomation as auto
except ImportError:  # pragma: no cover - 允许未安装时导入包本身
    auto = None


class WeChatClient:
    """微信桌面客户端操作类。"""

    PROFILE_CLASS_NAME = "mmui::ContactProfileView"
    TABBAR_AUTOMATION_ID = "MainView.main_tabbar"
    PROFILE_NICKNAME_AUTOMATION_ID = "right_v_view.nickname_button_view.display_name_text"
    PROFILE_KEY_AUTOMATION_ID = "right_v_view.user_info_center_view.basic_line_view.basic_line.key_text"
    PROFILE_VALUE_AUTOMATION_ID = "right_v_view.user_info_center_view.basic_line_view.ContactProfileTextView"

    def __init__(self, process_id: Optional[int] = None, auto_fetch_profile: bool = False):
        self._ensure_auto_available()
        self.process_id = process_id
        self.main_window = None
        self.profile_cache: Dict[str, str] = {}
        self.message_cache = MessageCache()
        self._connect()
        if auto_fetch_profile:
            self._init_profile()

    @staticmethod
    def _ensure_auto_available():
        if auto is None:
            raise ImportError("未安装 uiautomation，请先安装依赖后再使用微信自动化功能")

    def _walk_controls(self, control, *, max_depth: int = 6, _depth: int = 0):
        if _depth > max_depth:
            return
        yield control
        try:
            children = control.GetChildren()
        except Exception:
            children = []
        for child in children:
            yield from self._walk_controls(child, max_depth=max_depth, _depth=_depth + 1)

    def _find_contact_profile_view_once(self, *, max_depth_main: int = 8, max_depth_root: int = 4, max_nodes: int = 1200):
        scanned = 0
        roots = []
        if self.main_window is not None:
            roots.append((self.main_window, max_depth_main))
        roots.append((auto.GetRootControl(), max_depth_root))
        for root, depth in roots:
            for ctrl in self._walk_controls(root, max_depth=depth):
                scanned += 1
                if getattr(ctrl, "ClassName", "") == self.PROFILE_CLASS_NAME:
                    return ctrl
                if scanned >= max_nodes:
                    return None
        return None

    def _wait_contact_profile_view(self, *, timeout: float = 1.5, interval: float = 0.05, max_depth: int = 10):
        deadline = time.time() + timeout
        while time.time() < deadline:
            ctrl = self._find_contact_profile_view_once(
                max_depth_main=min(max_depth + 2, 12),
                max_depth_root=min(max_depth, 6),
            )
            if ctrl is not None:
                return ctrl
            time.sleep(interval)
        return None

    def _close_contact_profile_view(self, max_attempts: int = 2) -> bool:
        closed = False
        for _ in range(max_attempts):
            profile_view = self._find_contact_profile_view_once(max_depth_main=10, max_depth_root=3, max_nodes=700)
            if profile_view is None:
                return closed
            try:
                profile_view.SetFocus()
            except Exception:
                pass
            try:
                profile_view.SendKeys("{Esc}")
                closed = True
            except Exception:
                break
            time.sleep(0.06)
        return closed

    def _close_contact_profile_view_safely(self, delay: float = 0.3):
        try:
            time.sleep(delay)
            self._close_contact_profile_view()
        except Exception:
            pass

    @staticmethod
    def _control_center(rect) -> Tuple[int, int]:
        center_x = rect.left + max(1, (rect.right - rect.left) // 2)
        center_y = rect.top + max(1, (rect.bottom - rect.top) // 2)
        return center_x, center_y

    def _find_contacts_control(self, tabbar):
        tabbar_rect = tabbar.BoundingRectangle
        target_y = tabbar_rect.top + 105
        keywords = ("通讯录", "联系人", "contact", "contacts", "addressbook")
        preferred_types = {"ButtonControl", "ListItemControl", "TabItemControl"}
        candidates = []
        for ctrl in self._walk_controls(tabbar, max_depth=6):
            aid = getattr(ctrl, "AutomationId", "") or ""
            name = (getattr(ctrl, "Name", "") or "").strip()
            class_name = getattr(ctrl, "ClassName", "") or ""
            control_type = getattr(ctrl, "ControlTypeName", "") or ""
            if not aid and not name and control_type not in preferred_types:
                continue
            probe = f"{aid} {name} {class_name}".lower()
            score = 0
            if any(k in probe for k in keywords):
                score += 10
            if control_type in preferred_types:
                score += 2
            try:
                rect = ctrl.BoundingRectangle
                center_x, center_y = self._control_center(rect)
            except Exception:
                continue
            if rect.right - rect.left <= 120:
                score += 1
            distance = abs(center_y - target_y)
            candidates.append((score, distance, ctrl, {"name": name, "aid": aid, "center_x": center_x, "center_y": center_y}))
        if not candidates:
            return None
        candidates.sort(key=lambda item: (-item[0], item[1]))
        best = candidates[0]
        return {"control": best[2], "meta": best[3], "score": best[0]}

    def click_contacts_tab(self, y_offset: int = 106) -> Tuple[bool, str]:
        try:
            tabbar = self.main_window.Control(AutomationId=self.TABBAR_AUTOMATION_ID)
            if not tabbar.Exists(2, 0.5):
                return False, f"未找到 AutomationId={self.TABBAR_AUTOMATION_ID} 的控件"
            found = self._find_contacts_control(tabbar)
            if found is not None:
                ctrl = found["control"]
                meta = found["meta"]
                try:
                    ctrl.Click()
                    time.sleep(0.25)
                    return True, f"已打开联系人页面：{meta['name'] or '通讯录'}"
                except Exception:
                    auto.Click(meta["center_x"], meta["center_y"])
                    time.sleep(0.25)
                    return True, f"已通过坐标回退打开联系人页面：{meta['name'] or '通讯录'}"
            rect = tabbar.BoundingRectangle
            click_x = rect.left + max(1, (rect.right - rect.left) // 2)
            click_y = max(rect.top + 5, min(rect.bottom - 5, rect.top + int(y_offset)))
            auto.Click(click_x, click_y)
            time.sleep(0.25)
            return True, "已通过坐标点击联系人入口"
        except Exception as exc:
            return False, f"点击联系人失败: {exc}"

    def click_top_avatar(self, y_offset: int = 50) -> Tuple[bool, str]:
        try:
            tabbar = self.main_window.Control(AutomationId=self.TABBAR_AUTOMATION_ID)
            if not tabbar.Exists(2, 0.5):
                return False, f"未找到 AutomationId={self.TABBAR_AUTOMATION_ID} 的控件"
            rect = tabbar.BoundingRectangle
            click_x = rect.left + max(1, (rect.right - rect.left) // 2)
            click_y = max(rect.top + 5, min(rect.bottom - 5, rect.top + int(y_offset)))
            auto.Click(click_x, click_y)
            time.sleep(0.25)
            return True, "已点击顶部头像区域"
        except Exception as exc:
            return False, f"点击顶部头像失败: {exc}"

    @staticmethod
    def _normalize_wechat_id(value: str) -> str:
        text = (value or "").strip()
        if not text:
            return ""
        labeled = re.search(r"(?:微信号|微信ID|WeChat ID)\s*[:：]?\s*([a-zA-Z][-_a-zA-Z0-9]{5,31})", text, flags=re.IGNORECASE)
        if labeled:
            return labeled.group(1)
        if re.fullmatch(r"[a-zA-Z][-_a-zA-Z0-9]{5,31}", text):
            return text
        return ""

    def _extract_profile_from_contact_profile_view(self, profile_view) -> Tuple[str, str]:
        nickname = ""
        for ctrl in self._walk_controls(profile_view, max_depth=14):
            if getattr(ctrl, "AutomationId", "") == self.PROFILE_NICKNAME_AUTOMATION_ID:
                nickname = (getattr(ctrl, "Name", "") or "").strip()
                break
        wechat_id = ""
        expecting_value = False
        for ctrl in self._walk_controls(profile_view, max_depth=14):
            aid = getattr(ctrl, "AutomationId", "")
            name = (getattr(ctrl, "Name", "") or "").strip()
            if aid == self.PROFILE_KEY_AUTOMATION_ID and name.startswith("微信号"):
                expecting_value = True
                continue
            if expecting_value and aid == self.PROFILE_VALUE_AUTOMATION_ID:
                wechat_id = self._normalize_wechat_id(name)
                if wechat_id:
                    break
        if not wechat_id:
            for ctrl in self._walk_controls(profile_view, max_depth=14):
                candidate = self._normalize_wechat_id((getattr(ctrl, "Name", "") or "").strip())
                if candidate:
                    wechat_id = candidate
                    break
        return nickname, wechat_id

    def _init_profile(self):
        tabbar = self.main_window.Control(AutomationId=self.TABBAR_AUTOMATION_ID)
        if not tabbar.Exists(2, 0.5):
            raise RuntimeError(f"未找到 AutomationId={self.TABBAR_AUTOMATION_ID} 的控件")
        for _ in range(3):
            ok, _ = self.click_top_avatar(y_offset=50)
            if not ok:
                time.sleep(0.18)
                continue
            profile_view = self._wait_contact_profile_view(timeout=1.8, interval=0.05, max_depth=12)
            if profile_view is None:
                time.sleep(0.18)
                continue
            extract_deadline = time.time() + 2.5
            while time.time() < extract_deadline:
                nickname, wechat_id = self._extract_profile_from_contact_profile_view(profile_view)
                if nickname and wechat_id:
                    self.profile_cache = {"nickname": nickname, "wechat_id": wechat_id}
                    self._close_contact_profile_view_safely(delay=0.5)
                    return
                time.sleep(0.08)
            raise RuntimeError("个人信息弹窗已打开，但在等待时间内未完成识别")
        raise RuntimeError("点击顶部头像后未能提取完整个人资料")

    def get_profile(self) -> Dict[str, str]:
        return self.profile_cache

    def verify_profile(self) -> bool:
        try:
            self._init_profile()
            return bool(self.profile_cache.get("nickname") and self.profile_cache.get("wechat_id"))
        except Exception:
            return False

    def _get_window_handle(self) -> int:
        try:
            return int(getattr(self.main_window, "NativeWindowHandle", 0) or 0)
        except Exception:
            return 0

    def _show_and_focus_main_window(self) -> Tuple[bool, str]:
        hwnd = self._get_window_handle()
        last_error = ""

        if hwnd:
            try:
                user32 = ctypes.windll.user32
                user32.ShowWindow(hwnd, 9)
                user32.ShowWindow(hwnd, 5)
                user32.ShowWindow(hwnd, 1)
                time.sleep(0.2)
                user32.SetForegroundWindow(hwnd)
                user32.BringWindowToTop(hwnd)
                user32.SetActiveWindow(hwnd)
                user32.SetFocus(hwnd)
                time.sleep(0.2)
            except Exception as exc:
                last_error = str(exc)

        try:
            self.main_window.ShowWindow(9)
            self.main_window.ShowWindow(5)
            self.main_window.ShowWindow(1)
            time.sleep(0.2)
        except Exception as exc:
            last_error = str(exc)

        try:
            self.main_window.SetFocus()
            time.sleep(0.2)
            if self.get_chat_name() or self.is_active():
                return True, "已恢复并激活微信窗口"
        except Exception as exc:
            last_error = str(exc)

        if hwnd:
            return False, f"已尝试恢复微信窗口，但激活失败: {last_error}"
        return False, "未获取到微信窗口句柄，可能已隐藏到托盘或未正确创建主窗口"

    def _reconnect_main_window(self) -> bool:
        try:
            if self.process_id:
                self.main_window = auto.WindowControl(searchDepth=1, ProcessId=self.process_id)
            else:
                self.main_window = auto.WindowControl(searchDepth=1, ClassName="mmui::MainWindow")
            return bool(self.main_window and self.main_window.Exists(0, 0))
        except Exception:
            return False

    def _connect(self):
        if self.process_id:
            self.main_window = auto.WindowControl(searchDepth=1, ProcessId=self.process_id)
            if not self.main_window.Exists(0, 0):
                raise ConnectionError(f"未找到进程ID为 {self.process_id} 的微信窗口")
        else:
            self.main_window = auto.WindowControl(searchDepth=1, ClassName="mmui::MainWindow")
            if not self.main_window.Exists(0, 0):
                raise ConnectionError("未找到微信窗口，请确保微信已启动")
        self._show_and_focus_main_window()

    def activate(self) -> Tuple[bool, str]:
        success, message = self._show_and_focus_main_window()
        if success:
            return success, message

        self._reconnect_main_window()
        success, message = self._show_and_focus_main_window()
        if success:
            return success, "已重新连接并激活微信窗口"

        return False, message

    def is_active(self) -> bool:
        try:
            return bool(self.main_window.HasKeyboardFocus or self.main_window.IsTopLevel())
        except Exception:
            return False

    def get_status(self) -> Dict[str, object]:
        exists = False
        try:
            exists = bool(self.main_window and self.main_window.Exists(0, 0))
        except Exception:
            exists = False
        return {
            "connected": exists,
            "active": self.is_active() if exists else False,
            "visible": bool(self._get_window_handle()) if exists else False,
            "chat_name": self.get_chat_name() if exists else "",
            "profile_loaded": bool(self.profile_cache),
        }

    def get_chat_list(self):
        chat_list = self.main_window.ListControl(AutomationId="chat_message_list")
        if not chat_list.Exists(0, 0):
            raise ValueError("未找到聊天消息列表")
        return chat_list

    def get_session_list_control(self):
        session_list = self.main_window.ListControl(Name="会话")
        if not session_list.Exists(1, 0.5):
            return None
        return session_list

    def _parse_unread_from_session_item_name(self, name: str) -> Optional[Tuple[str, int]]:
        text = (name or "").strip()
        if not text:
            return None
        chat_name = text.split("\n")[0].strip()
        if not chat_name:
            return None
        matched = re.search(r"\[(\d+)\s*条\]", text)
        if not matched:
            return None
        try:
            unread = int(matched.group(1))
        except ValueError:
            return None
        return chat_name, unread

    def get_unread_chats(self, ignore_list: Optional[List[str]] = None) -> List[Dict[str, int]]:
        ignore_set = set(ignore_list or [])
        session_list = self.get_session_list_control()
        if not session_list:
            return []
        unread_items: List[Dict[str, int]] = []
        for item in session_list.GetChildren():
            parsed = self._parse_unread_from_session_item_name(getattr(item, "Name", ""))
            if not parsed:
                continue
            chat_name, unread = parsed
            if chat_name in ignore_set:
                continue
            unread_items.append({"chat_name": chat_name, "unread": unread})
        return unread_items

    def get_sessions(self) -> List[Dict[str, object]]:
        session_list = self.get_session_list_control()
        if not session_list:
            return []
        rows: List[Dict[str, object]] = []
        for item in session_list.GetChildren():
            name = (getattr(item, "Name", "") or "").strip()
            if not name:
                continue
            parsed = self._parse_unread_from_session_item_name(name)
            chat_name = parsed[0] if parsed else name.split("\n")[0].strip()
            unread = parsed[1] if parsed else 0
            rows.append({"chat_name": chat_name, "unread": unread, "raw_name": name})
        return rows

    def get_recent_groups(self) -> List[Dict[str, object]]:
        return [item for item in self.get_sessions() if item.get("chat_name", "").endswith(")") and "(" in item.get("chat_name", "")]

    def get_unread_count(self, chat_name: str) -> int:
        for item in self.get_unread_chats():
            if item["chat_name"] == chat_name:
                return item["unread"]
        return 0

    def switch_to_chat(self, chat_name: str, timeout: int = 5) -> bool:
        try:
            title_text = self.main_window.TextControl(Name=chat_name)
            if title_text.Exists(0.3, 0.3):
                return True
            session_list = self.main_window.ListControl(Name="会话")
            if session_list.Exists(1, 0.5):
                automation_id = f"session_item_{chat_name}"
                chat_item = session_list.ListItemControl(AutomationId=automation_id)
                if chat_item.Exists(0.5, 0.5):
                    chat_item.Click()
                    time.sleep(0.3)
                    return True
            search_box = self.main_window.EditControl(Name="搜索")
            if not search_box.Exists(2, 0.5):
                return False
            search_box.Click()
            time.sleep(0.3)
            search_box.SendKeys(chat_name)
            time.sleep(min(timeout, 1))
            search_result_list = self.main_window.ListControl(AutomationId="search_list")
            if not search_result_list.Exists(0.5, 0.5):
                search_box.SendKeys("{Esc}")
                return False
            items = search_result_list.GetChildren()
            if not items:
                search_box.SendKeys("{Esc}")
                return False
            section_name = None
            frequent_item = None
            contact_item = None
            group_item = None
            for item in items:
                item_name = item.Name.strip()
                if item.ControlTypeName != "ListItemControl":
                    continue
                if item_name in {"最常使用", "联系人", "群聊", "聊天记录", "收藏", "搜索网络结果"}:
                    section_name = item_name
                    continue
                if item.AutomationId == f"search_item_{chat_name}" or item_name == chat_name:
                    if section_name == "最常使用" and frequent_item is None:
                        frequent_item = item
                    elif section_name == "联系人" and contact_item is None:
                        contact_item = item
                    elif section_name == "群聊" and group_item is None:
                        group_item = item
            target_item = frequent_item or contact_item or group_item
            if not target_item:
                search_box.SendKeys("{Esc}")
                return False
            target_item.Click()
            time.sleep(0.5)
            return True
        except Exception:
            return False

    def get_latest_messages(self, count: int | None = None) -> List[Dict[str, object]]:
        chat_list = self.get_chat_list()
        messages = []
        all_items = chat_list.GetChildren()
        items_to_parse = all_items[-count:] if count else all_items
        for item in items_to_parse:
            msg_data = self._parse_message_item(item)
            if msg_data:
                messages.append(msg_data)
        return messages

    def _parse_message_item(self, item) -> Optional[Dict[str, object]]:
        try:
            text = item.Name.strip()
            if not text:
                return None
            is_time = self._is_time_marker(item)
            is_mine = False
            color_ambiguous = not is_time
            if not is_time:
                try:
                    from PIL import ImageGrab

                    def _is_green(px):
                        r, g, b = px[0], px[1], px[2]
                        return g > 150 and g > r * 1.3 and g > b * 1.1

                    def _sample_green(img):
                        w, h = img.size
                        if w <= 0 or h <= 0:
                            return 0, 0
                        sample_rows = [int(h * ratio) for ratio in (0.25, 0.5, 0.75) if 0 < int(h * ratio) < h]
                        rg = sum(1 for sy in sample_rows for x in range(60, 95, 5) if _is_green(img.getpixel((int(w * x / 100), sy))))
                        lg = sum(1 for sy in sample_rows for x in range(5, 40, 5) if _is_green(img.getpixel((int(w * x / 100), sy))))
                        return rg, lg

                    rect = item.BoundingRectangle
                    img = ImageGrab.grab(bbox=(rect.left, rect.top, rect.right, rect.bottom))
                    right_green, left_green = _sample_green(img)
                    if right_green == 0 and left_green == 0:
                        time.sleep(0.2)
                        img2 = ImageGrab.grab(bbox=(rect.left, rect.top, rect.right, rect.bottom))
                        right_green, left_green = _sample_green(img2)
                    if right_green > 0 or left_green > 0:
                        is_mine = right_green > left_green
                        color_ambiguous = False
                except Exception:
                    pass
            return {
                "sender": "",
                "content": text,
                "time": "",
                "is_time": is_time,
                "is_mine": is_mine,
                "color_ambiguous": color_ambiguous if not is_time else False,
                "raw_content": text,
            }
        except Exception:
            return None

    def _is_time_marker(self, item) -> bool:
        if getattr(item, "AutomationId", None):
            return False
        text = (getattr(item, "Name", "") or "").strip()
        if not text or ":" not in text or len(text) > 20:
            return False
        time_patterns = [
            r"^\d{1,2}:\d{2}$",
            r"^昨天",
            r"^星期[一二三四五六日]",
            r"^\d{1,2}月\d{1,2}日",
            r"^\d{4}年\d{1,2}月\d{1,2}日",
        ]
        return any(re.match(pattern, text) for pattern in time_patterns)

    def get_chat_name(self) -> str:
        try:
            chat_name_label = self.main_window.TextControl(
                AutomationId="content_view.top_content_view.title_h_view.left_v_view.left_content_v_view.left_ui_.big_title_line_h_view.current_chat_name_label"
            )
            if chat_name_label.Exists(1, 0.5):
                return chat_name_label.Name
            return ""
        except Exception:
            return ""

    def get_cached_wechat_id(self) -> Optional[str]:
        wechat_id = (self.profile_cache or {}).get("wechat_id")
        if not wechat_id or wechat_id == "未知":
            return None
        return wechat_id

    def get_sender_info(self, sender_name: str) -> Dict[str, str]:
        """获取发送人的微信名称和微信号。

        通过点击聊天消息左侧的头像来打开联系人详情弹窗。

        Args:
            sender_name: 发送人的显示名称

        Returns:
            包含以下字段的字典：
            - display_name: 显示名称
            - wechat_id: 微信号（如果能获取到）
            - nickname: 昵称
            - error: 错误信息（如果获取失败）
        """
        result = {
            "display_name": sender_name,
            "wechat_id": "",
            "nickname": "",
            "error": ""
        }

        try:
            # 判断当前聊天类型
            chat_type = self._detect_chat_type()
            is_group = chat_type == "group"

            # 获取聊天消息列表
            chat_list = self.get_chat_list()
            if not chat_list.Exists(1, 0.5):
                result["error"] = "未找到聊天消息列表"
                return result

            # 获取最新的消息项
            all_items = chat_list.GetChildren()
            if not all_items:
                result["error"] = "聊天列表为空"
                return result

            # print(f"  [调试] 聊天类型: {'群聊' if is_group else '私聊'}")
            # print(f"  [调试] 共找到 {len(all_items)} 个消息项")

            # 从后往前查找合适的消息
            target_item = None
            for i, item in enumerate(reversed(all_items)):
                # 检查 AutomationId
                automation_id = getattr(item, "AutomationId", "")
                item_text = getattr(item, "Name", "").strip()

                # 跳过时间标记
                if self._is_time_marker(item):
                    continue

                # 必须是消息气泡
                if "chat_bubble_item_view" not in automation_id:
                    continue

                # print(f"  [调试] 检查消息 {len(all_items)-i}: Name={item_text[:50]}...")

                if is_group:
                    # 群聊：需要点击头像来验证是否是目标发送人
                    # 因为群聊消息的Name属性只包含消息内容，不包含发送人名称
                    msg_data = self._parse_message_item(item)
                    if msg_data and not msg_data.get("is_mine", False):
                        # 这是一条非"我"发送的消息，点击头像验证发送人
                        try:
                            rect = item.BoundingRectangle
                            avatar_x = rect.left + 30
                            avatar_y = rect.top + (rect.bottom - rect.top) // 2

                            auto.Click(avatar_x, avatar_y)
                            time.sleep(0.5)

                            profile_view = self._wait_contact_profile_view(timeout=2.0, interval=0.05, max_depth=12)
                            if profile_view:
                                nickname, wechat_id = self._extract_profile_from_contact_profile_view(profile_view)
                                self._close_contact_profile_view_safely(delay=0.3)

                                # 检查昵称是否匹配
                                if nickname == sender_name:
                                    target_item = item
                                    # print(f"    -> 找到群聊消息（发送人匹配: {nickname}）")
                                    # 已经获取到信息，直接返回
                                    result["nickname"] = nickname
                                    result["wechat_id"] = wechat_id
                                    return result
                                else:
                                    print(f"    -> 发送人不匹配（实际: {nickname}，期望: {sender_name}）")
                        except Exception as e:
                            print(f"    -> 点击头像失败: {e}")
                            continue
                else:
                    # 私聊：找到任何一条对方发送的消息即可
                    msg_data = self._parse_message_item(item)
                    if msg_data and not msg_data.get("is_mine", False):
                        target_item = item
                        # print(f"    -> 找到私聊消息（对方发送）")
                        break

            if not target_item:
                if is_group:
                    result["error"] = f"未找到发送人 {sender_name} 的消息"
                else:
                    result["error"] = f"未找到对方发送的消息"
                return result

            # 通过坐标点击头像区域（参考 click_top_avatar 的实现）
            try:
                rect = target_item.BoundingRectangle
                # 头像位置：消息框最左边 + 30像素偏移，垂直居中
                avatar_x = rect.left + 30
                avatar_y = rect.top + (rect.bottom - rect.top) // 2

                # print(f"  [调试] 找到消息: AutomationId={getattr(target_item, 'AutomationId', '')}")
                # print(f"  [调试] 消息框位置: left={rect.left}, top={rect.top}, right={rect.right}, bottom={rect.bottom}")
                # print(f"  [调试] 计算的头像坐标: x={avatar_x}, y={avatar_y}")

                # 使用 auto.Click 点击头像（与 click_top_avatar 相同的方式）
                auto.Click(avatar_x, avatar_y)
                time.sleep(0.5)
                # print(f"  [调试] 已点击头像位置")

                # 等待 ContactProfileView 弹窗出现
                profile_view = self._wait_contact_profile_view(timeout=2.0, interval=0.05, max_depth=12)
                if profile_view is None:
                    result["error"] = "点击头像后未出现联系人详情弹窗"
                    return result

                # print(f"  [调试] 联系人详情弹窗已出现")

                # 提取联系人信息
                nickname, wechat_id = self._extract_profile_from_contact_profile_view(profile_view)
                result["nickname"] = nickname
                result["wechat_id"] = wechat_id

                # print(f"  [调试] 提取到信息: nickname={nickname}, wechat_id={wechat_id}")

                # 关闭弹窗
                self._close_contact_profile_view_safely(delay=0.3)

            except Exception as e:
                result["error"] = f"点击头像或提取信息失败: {str(e)}"
                import traceback
                traceback.print_exc()

        except Exception as e:
            result["error"] = f"获取发送人信息失败: {str(e)}"
            import traceback
            traceback.print_exc()

        return result

    def get_group_senders_info(self, messages: List[Dict[str, object]]) -> Dict[str, Dict[str, str]]:
        """从群聊消息列表中获取所有发送人的详细信息。

        通过点击消息头像来获取发送人的微信昵称和微信号。
        使用缓存机制避免重复点击同一个人的头像。

        Args:
            messages: 消息列表，每条消息应包含 raw_content 和 is_mine 字段

        Returns:
            消息内容到发送人信息的映射字典，key为消息内容(raw_content)，value包含：
            - nickname: 昵称
            - wechat_id: 微信号
        """
        content_to_sender = {}  # 消息内容 -> 发送人信息的映射
        sender_cache = {}  # 缓存已获取的发送人信息，key为昵称

        # 获取聊天消息列表的UI元素
        chat_list = self.get_chat_list()
        all_items = chat_list.GetChildren()

        # 建立消息内容到UI元素的映射
        msg_item_map = {}
        for item in all_items:
            if self._is_time_marker(item):
                continue
            automation_id = getattr(item, "AutomationId", "")
            if "chat_bubble_item_view" not in automation_id:
                continue
            item_text = getattr(item, "Name", "").strip()
            if item_text:
                msg_item_map[item_text] = item

        # 遍历消息，获取发送人信息
        for msg in messages:
            # 跳过我发送的消息
            is_mine = msg.get("is_mine", False)
            sender = msg.get("sender", "")
            if is_mine or sender == "我":
                continue

            # 获取消息内容
            content = msg.get("raw_content", "")
            if not content or content not in msg_item_map:
                continue

            # 如果已经获取过这条消息的发送人信息，跳过
            if content in content_to_sender:
                continue

            # 通过点击头像获取发送人信息
            try:
                item = msg_item_map[content]

                rect = item.BoundingRectangle
                avatar_x = rect.left + 30
                avatar_y = rect.top + (rect.bottom - rect.top) // 2

                auto.Click(avatar_x, avatar_y)
                time.sleep(0.5)

                profile_view = self._wait_contact_profile_view(timeout=2.0, interval=0.05, max_depth=12)
                if profile_view:
                    nickname, wechat_id = self._extract_profile_from_contact_profile_view(profile_view)

                    # 如果是第一次遇到这个发送人，缓存其信息
                    if nickname and nickname not in sender_cache:
                        sender_cache[nickname] = {
                            "nickname": nickname,
                            "wechat_id": wechat_id
                        }

                    # 建立消息内容到发送人信息的映射
                    if nickname:
                        content_to_sender[content] = sender_cache[nickname]

                    self._close_contact_profile_view_safely(delay=0.3)

            except Exception as e:
                # 忽略单个消息的错误，继续处理下一条
                continue

        return content_to_sender

    def _detect_chat_type(self) -> str:
        """判断聊天类型（群聊或私聊）。

        通过检查群聊特有的UI元素来判断：
        - current_chat_name_label: 群聊名称
        - current_chat_count_label: 群聊成员数量
        如果这两个元素都存在且有值，则为群聊，否则为私聊。
        """
        try:
            # 检查群聊名称标签
            chat_name_label = self.main_window.TextControl(
                AutomationId="content_view.top_content_view.title_h_view.left_v_view.left_content_v_view.left_ui_.big_title_line_h_view.current_chat_name_label"
            )
            # 检查群聊成员数量标签
            chat_count_label = self.main_window.TextControl(
                AutomationId="content_view.top_content_view.title_h_view.left_v_view.left_content_v_view.left_ui_.big_title_line_h_view.current_chat_count_label"
            )

            # 如果两个标签都存在且有值，则为群聊
            if chat_name_label.Exists(0.5, 0.2) and chat_count_label.Exists(0.5, 0.2):
                name_text = chat_name_label.Name
                count_text = chat_count_label.Name
                if name_text and count_text:
                    return "group"
        except Exception:
            pass

        return "private"

    def _guess_content_type_from_path(self, file_path: str) -> str:
        ext = os.path.splitext(file_path)[1].lower()
        if ext in {".png", ".jpg", ".jpeg", ".gif", ".bmp", ".webp"}:
            return "image"
        return "file"

    def send_message(self, chat_name: str, message: str) -> Tuple[bool, str]:
        try:
            if not self.switch_to_chat(chat_name):
                return False, f"未找到联系人或群聊: {chat_name}"
            input_box = self.main_window.EditControl(AutomationId="chat_input_field")
            if not input_box.Exists(2, 0.5):
                return False, "未找到输入框"
            input_box.Click()
            time.sleep(0.2)

            # 使用剪贴板方式发送消息，避免字符丢失
            if pyperclip is not None:
                old_clipboard = None
                try:
                    old_clipboard = pyperclip.paste()
                except Exception:
                    pass

                pyperclip.copy(message)
                time.sleep(0.1)
                input_box.SendKeys("{Ctrl}v")
                time.sleep(0.3)

                if old_clipboard is not None:
                    try:
                        pyperclip.copy(old_clipboard)
                    except Exception:
                        pass
            else:
                # 降级到 SendKeys 方式
                input_box.SendKeys(message)
                time.sleep(0.3)

            input_box.SendKeys("{Enter}")
            time.sleep(0.3)
            chat_type = self._detect_chat_type()
            self.message_cache.add_message(
                chat_name,
                message,
                chat_type=chat_type,
                content_type="text",
                chat_id=self.get_cached_wechat_id(),
                to_chat_name=chat_name,
                to_chat_id=None,
                from_chat_name=(self.profile_cache or {}).get("nickname") or "我",
                group_name=chat_name if chat_type == "group" else None,
            )
            return True, "发送成功"
        except Exception as exc:
            return False, f"发送失败: {exc}"

    def send_message_with_mention(self, chat_name: str, mention_names: List[str], message: str) -> Tuple[bool, str]:
        try:
            if not self.switch_to_chat(chat_name):
                return False, f"未找到群聊: {chat_name}"

            input_box = self.main_window.EditControl(AutomationId="chat_input_field")
            if not input_box.Exists(2, 0.5):
                return False, "未找到输入框"

            input_box.Click()
            time.sleep(0.2)

            for mention_name in mention_names:
                input_box.SendKeys("@")
                time.sleep(0.5)
                input_box.SendKeys(mention_name)
                time.sleep(0.8)

                if mention_name == "所有人":
                    input_box.SendKeys("{Enter}")
                    time.sleep(0.3)
                    continue

                mention_list = self.main_window.ListControl(AutomationId="chat_mention_list")
                if not mention_list.Exists(0.5, 0.5):
                    try:
                        input_box.GetValuePattern().SetValue("")
                    except Exception:
                        pass
                    return False, f"好友 '{mention_name}' 不在群 '{chat_name}' 中，已取消发送"

                items = mention_list.GetChildren()
                if len(items) == 0:
                    try:
                        input_box.GetValuePattern().SetValue("")
                    except Exception:
                        pass
                    return False, f"好友 '{mention_name}' 不在群 '{chat_name}' 中，已取消发送"

                input_box.SendKeys("{Enter}")
                time.sleep(0.3)

            # 使用剪贴板方式发送消息，避免字符丢失
            if pyperclip is not None:
                old_clipboard = None
                try:
                    old_clipboard = pyperclip.paste()
                except Exception:
                    pass

                pyperclip.copy(" " + message)
                time.sleep(0.1)
                input_box.SendKeys("{Ctrl}v")
                time.sleep(0.3)

                if old_clipboard is not None:
                    try:
                        pyperclip.copy(old_clipboard)
                    except Exception:
                        pass
            else:
                # 降级到 SendKeys 方式
                input_box.SendKeys(" " + message)
                time.sleep(0.3)

            input_box.SendKeys("{Enter}")
            time.sleep(0.3)

            mention_text = " ".join(f"@{name}" for name in mention_names)
            self.message_cache.add_message(
                chat_name,
                f"{mention_text} {message}".strip(),
                chat_type="group",
                content_type="text",
                chat_id=self.get_cached_wechat_id(),
                to_chat_name=chat_name,
                to_chat_id=None,
                from_chat_name=(self.profile_cache or {}).get("nickname") or "我",
                group_name=chat_name,
            )
            return True, "发送成功"
        except Exception as exc:
            return False, f"发送失败: {exc}"

    @staticmethod
    def _normalize_input_path(file_path: str) -> str:
        text = (file_path or "").strip()
        if not text:
            return ""
        invisible_chars = {
            "\u200e",
            "\u200f",
            "\u202a",
            "\u202b",
            "\u202c",
            "\u202d",
            "\u202e",
            "\ufeff",
        }
        return "".join(ch for ch in text if ch not in invisible_chars)

    def send_file(self, chat_name: str, file_path: str) -> Tuple[bool, str]:
        try:
            normalized_path = self._normalize_input_path(file_path)
            if not normalized_path:
                return False, "文件路径不能为空"
            if not os.path.exists(normalized_path):
                return False, f"文件不存在: {normalized_path}"
            if not self.switch_to_chat(chat_name):
                return False, f"未找到联系人或群聊: {chat_name}"
            input_box = self.main_window.EditControl(AutomationId="chat_input_field")
            if not input_box.Exists(2, 0.5):
                return False, "未找到输入框"
            input_box.Click()
            time.sleep(0.3)
            import subprocess

            ps_script = f'Set-Clipboard -Path "{normalized_path}"'
            subprocess.run(["powershell", "-Command", ps_script], check=True)
            time.sleep(0.3)
            input_box.SendKeys("{Ctrl}v")
            time.sleep(0.8)
            input_box.SendKeys("{Enter}")
            time.sleep(0.3)
            chat_type = self._detect_chat_type()
            self.message_cache.add_message(
                chat_name,
                os.path.basename(normalized_path),
                chat_type=chat_type,
                content_type=self._guess_content_type_from_path(normalized_path),
                chat_id=self.get_cached_wechat_id(),
                to_chat_name=chat_name,
                to_chat_id=None,
                from_chat_name=(self.profile_cache or {}).get("nickname") or "我",
                group_name=chat_name if chat_type == "group" else None,
            )
            return True, "发送成功"
        except Exception as exc:
            return False, f"发送失败: {exc}"

    def clear_message_cache(self):
        self.message_cache.clear_all()

    def clear_old_cache(self, days: int = 7):
        self.message_cache.clear_old_messages(days)
