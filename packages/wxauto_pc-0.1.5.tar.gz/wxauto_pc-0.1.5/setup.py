from setuptools import Extension, setup
from Cython.Build import cythonize


extensions = [
    Extension("wxauto_pc.core._client", ["build_src/_client.py"]),
    Extension("wxauto_pc.core._message_reader", ["build_src/_message_reader.py"]),
    Extension("wxauto_pc.core._unread_monitor", ["build_src/_unread_monitor.py"]),
]


setup(
    ext_modules=cythonize(
        extensions,
        compiler_directives={"language_level": "3"},
    ),
    exclude_package_data={"wxauto_pc": ["core/_*.py", "core/*.c"]},
)
