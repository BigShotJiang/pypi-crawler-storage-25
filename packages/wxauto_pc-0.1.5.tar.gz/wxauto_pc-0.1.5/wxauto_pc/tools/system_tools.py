"""系统类工具。"""

from __future__ import annotations

from ..core.client import WeChatClient
from ..storage.progress_log import ProgressLog
from .registry import register_tool, list_tools as list_registered_tools
from .schemas import make_result


def _record(tool_name: str, notes: str, test_status: str = "未验证"):
    ProgressLog().record(
        tool_name=tool_name,
        category="system",
        status="done",
        notes=notes,
        test_status=test_status,
    )


@register_tool("wechat_initialize", "system", "初始化微信连接")
def wechat_initialize(process_id: int | None = None, auto_fetch_profile: bool = False):
    client = WeChatClient(process_id=process_id, auto_fetch_profile=auto_fetch_profile)
    _record("wechat_initialize", "已实现微信初始化连接工具")
    return make_result(success=True, tool_name="wechat_initialize", message="已成功初始化微信连接", data=client.get_status())


@register_tool("wechat_status", "system", "获取微信运行状态")
def wechat_status(client: WeChatClient):
    _record("wechat_status", "已实现微信运行状态查询工具")
    return make_result(success=True, tool_name="wechat_status", message="已获取微信运行状态", data=client.get_status())


@register_tool("wechat_activate", "system", "激活微信窗口")
def wechat_activate(client: WeChatClient):
    success, message = client.activate()
    _record("wechat_activate", "已实现微信窗口激活工具")
    return make_result(success=success, tool_name="wechat_activate", message=message, data=client.get_status())


@register_tool("wechat_check_activation", "system", "检查微信是否激活")
def wechat_check_activation(client: WeChatClient):
    active = client.is_active()
    _record("wechat_check_activation", "已实现微信激活状态检查工具")
    return make_result(success=True, tool_name="wechat_check_activation", message="已检查微信激活状态", data={"active": active})


@register_tool("wechat_list_tools", "system", "列出所有可用工具")
def wechat_list_tools():
    tools = list_registered_tools()
    _record("wechat_list_tools", "已实现工具列表查询工具")
    return make_result(success=True, tool_name="wechat_list_tools", message="已列出当前可用工具", data=tools)


@register_tool("get_my_info", "system", "获取我的微信账号信息")
def get_my_info(client: WeChatClient):
    if not client.get_profile():
        client._init_profile()
    profile = client.get_profile()
    _record("get_my_info", "已实现个人微信资料查询工具")
    return make_result(success=True, tool_name="get_my_info", message="已获取当前微信账号信息", data=profile)
