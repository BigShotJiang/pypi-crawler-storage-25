"""消息与会话类工具。"""

from __future__ import annotations

from ..core.client import WeChatClient
from ..core.message_reader import MessageReader
from ..core.unread_monitor import UnreadMessageMonitor
from ..storage.progress_log import ProgressLog
from .registry import register_tool
from .schemas import make_result

DEFAULT_IGNORED_UNREAD_CHATS = {
    "服务号",
    "公众号",
    "腾讯新闻",
    "文件传输助手",
    "微信支付",
    "服务通知",
    "微信游戏",
    "微信运动",
}


def _record(tool_name: str, notes: str, test_status: str = "未验证"):
    category = "message" if tool_name in {"send_message", "send_message_with_mention", "get_messages", "get_history", "get_next_new_message", "send_bulk_messages"} else "session"
    ProgressLog().record(
        tool_name=tool_name,
        category=category,
        status="done",
        notes=notes,
        test_status=test_status,
    )


@register_tool("switch_chat", "session", "切换聊天窗口")
def switch_chat(client: WeChatClient, chat_name: str):
    success = client.switch_to_chat(chat_name)
    _record("switch_chat", "已实现聊天切换工具")
    return make_result(success=success, tool_name="switch_chat", message=(f"已切换到聊天：{chat_name}" if success else f"未找到聊天：{chat_name}"), data={"chat_name": client.get_chat_name()})


@register_tool("send_message", "message", "发送文本消息")
def send_message(client: WeChatClient, chat_name: str, message: str):
    success, result_message = client.send_message(chat_name, message)
    _record("send_message", "已实现文本消息发送工具")
    return make_result(success=success, tool_name="send_message", message=result_message, data={"chat_name": chat_name, "content": message})


@register_tool("send_message_with_mention", "message", "群聊@后发送文本消息")
def send_message_with_mention(client: WeChatClient, chat_name: str, mention_names: list[str], message: str):
    success, result_message = client.send_message_with_mention(chat_name, mention_names, message)
    _record("send_message_with_mention", "已实现群聊@发送消息工具")
    return make_result(
        success=success,
        tool_name="send_message_with_mention",
        message=result_message,
        data={"chat_name": chat_name, "mention_names": mention_names, "content": message},
    )


@register_tool("get_messages", "message", "获取当前聊天消息")
def get_messages(client: WeChatClient, chat_name: str, count: int | None = 20):
    reader = MessageReader(client)
    messages = reader.read_latest_from_chat(chat_name, count=count)
    _record("get_messages", "已实现当前聊天消息读取工具")
    return make_result(success=True, tool_name="get_messages", message="已获取当前聊天消息", data={"chat_name": chat_name, "messages": messages})


@register_tool("get_history", "message", "获取当前可见历史消息")
def get_history(client: WeChatClient, chat_name: str, count: int | None = 50):
    reader = MessageReader(client)
    messages = reader.read_latest_from_chat(chat_name, count=count)
    _record("get_history", "已实现当前可见区域历史消息读取工具")
    return make_result(success=True, tool_name="get_history", message="已获取当前可见历史消息", data={"chat_name": chat_name, "messages": messages, "scope": "当前可见区域"})


@register_tool("get_next_new_message", "message", "获取下一个新消息批次")
def get_next_new_message(client: WeChatClient, chat_name: str, timeout_s: float = 30.0, read_count: int = 20):
    monitor = UnreadMessageMonitor(client=client, reader=MessageReader(client))
    for batch in monitor.monitor_chat(
        chat_name,
        timeout_s=timeout_s,
        read_count=read_count,
        stop_on_first_batch=True,
    ):
        _record("get_next_new_message", "已实现下一个新消息批次监听工具")
        return make_result(success=True, tool_name="get_next_new_message", message="已获取下一批新消息", data={"chat_name": chat_name, "messages": batch})
    _record("get_next_new_message", "已实现下一个新消息批次监听工具")
    return make_result(success=False, tool_name="get_next_new_message", message="在超时时间内未获取到新消息", data={"chat_name": chat_name, "messages": []})


@register_tool("get_sessions", "session", "获取会话列表")
def get_sessions(client: WeChatClient):
    sessions = client.get_sessions()
    _record("get_sessions", "已实现会话列表获取工具")
    return make_result(success=True, tool_name="get_sessions", message="已获取会话列表", data=sessions)


@register_tool("filter_sessions", "session", "筛选会话列表")
def filter_sessions(client: WeChatClient, keyword: str = "", unread_only: bool = False):
    sessions = client.get_sessions()
    if keyword:
        sessions = [item for item in sessions if keyword in item.get("chat_name", "") or keyword in item.get("raw_name", "")]
    if unread_only:
        sessions = [item for item in sessions if item.get("unread", 0) > 0]
    _record("filter_sessions", "已实现会话列表筛选工具")
    return make_result(success=True, tool_name="filter_sessions", message="已完成会话筛选", data=sessions)


@register_tool("get_unread_sessions", "session", "获取未读会话")
def get_unread_sessions(client: WeChatClient, ignore_list: list[str] | None = None):
    merged_ignore = set(DEFAULT_IGNORED_UNREAD_CHATS)
    if ignore_list:
        merged_ignore.update(ignore_list)
    rows = client.get_unread_chats(ignore_list=list(merged_ignore))
    _record("get_unread_sessions", "已实现未读会话获取工具")
    return make_result(success=True, tool_name="get_unread_sessions", message="已获取未读会话", data=rows)


@register_tool("get_unread_messages", "message", "获取所有未读消息内容")
def get_unread_messages(client: WeChatClient, ignore_list: list[str] | None = None):
    """获取所有未读会话的未读消息内容（只读取真正的未读消息，不读取历史）。"""
    reader = MessageReader(client)
    all_unread_messages = reader.read_all_unread_messages(ignore_list=ignore_list)

    _record("get_unread_messages", "已实现未读消息获取工具")

    if not all_unread_messages:
        return make_result(success=True, tool_name="get_unread_messages", message="当前没有未读消息", data=[])

    return make_result(
        success=True,
        tool_name="get_unread_messages",
        message=f"已获取 {len(all_unread_messages)} 个会话的未读消息",
        data=all_unread_messages
    )


@register_tool("send_bulk_messages", "message", "批量发送文本消息")
def send_bulk_messages(client: WeChatClient, chat_names: list[str], message: str):
    results = []
    for chat_name in chat_names:
        success, result_message = client.send_message(chat_name, message)
        results.append({"chat_name": chat_name, "success": success, "message": result_message})
    all_success = all(item["success"] for item in results) if results else True
    _record("send_bulk_messages", "已实现批量文本消息发送工具")
    return make_result(success=all_success, tool_name="send_bulk_messages", message="已完成批量发送", data=results)


@register_tool("get_recent_groups", "session", "获取最近群聊")
def get_recent_groups(client: WeChatClient):
    groups = client.get_recent_groups()
    _record("get_recent_groups", "已实现最近群聊获取工具")
    return make_result(success=True, tool_name="get_recent_groups", message="已获取最近群聊", data=groups)
