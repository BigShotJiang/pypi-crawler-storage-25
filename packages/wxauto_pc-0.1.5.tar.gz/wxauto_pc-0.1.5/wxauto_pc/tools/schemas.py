"""工具返回结构。"""

from __future__ import annotations

from datetime import datetime
from typing import Any


class ToolResult(dict):
    """统一工具返回结构。"""


def make_result(
    *,
    success: bool,
    tool_name: str,
    message: str,
    data: Any = None,
) -> ToolResult:
    return ToolResult(
        success=success,
        tool_name=tool_name,
        message=message,
        data=data,
        timestamp=datetime.now().isoformat(timespec="seconds"),
    )
