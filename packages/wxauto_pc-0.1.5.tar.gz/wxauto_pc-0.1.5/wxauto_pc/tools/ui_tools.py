"""界面类工具。"""

from __future__ import annotations

from ..core.client import WeChatClient
from ..storage.progress_log import ProgressLog
from .registry import register_tool
from .schemas import make_result


@register_tool("switch_to_contact", "ui", "切换到联系人页面")
def switch_to_contact(client: WeChatClient):
    success, message = client.click_contacts_tab()
    ProgressLog().record(
        tool_name="switch_to_contact",
        category="ui",
        status="done",
        notes="已实现切换到联系人页面工具",
        test_status="未验证",
    )
    return make_result(success=success, tool_name="switch_to_contact", message=message, data={"active": success})
