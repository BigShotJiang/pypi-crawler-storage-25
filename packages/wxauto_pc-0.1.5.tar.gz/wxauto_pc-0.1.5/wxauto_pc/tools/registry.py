"""工具注册表。"""

from __future__ import annotations

from typing import Callable

TOOL_REGISTRY: list[dict] = []


def register_tool(name: str, category: str, description: str):
    def decorator(func: Callable):
        TOOL_REGISTRY.append(
            {
                "name": name,
                "category": category,
                "description": description,
                "handler": func,
            }
        )
        return func

    return decorator


def list_tools() -> list[dict[str, str]]:
    return [
        {
            "name": item["name"],
            "category": item["category"],
            "description": item["description"],
        }
        for item in TOOL_REGISTRY
    ]


def get_tool(name: str):
    for item in TOOL_REGISTRY:
        if item["name"] == name:
            return item["handler"]
    raise KeyError(f"未找到工具: {name}")
