"""路径管理。"""

from __future__ import annotations

from pathlib import Path


def get_package_root() -> Path:
    """返回包根目录。"""
    return Path(__file__).resolve().parents[1]


def get_data_dir() -> Path:
    """返回数据目录，不存在时自动创建。"""
    data_dir = get_package_root().parent / "data"
    data_dir.mkdir(parents=True, exist_ok=True)
    return data_dir


def get_message_cache_db_path() -> Path:
    return get_data_dir() / "message_cache.db"


def get_progress_log_path() -> Path:
    return get_data_dir() / "progress_log.json"


def get_monitor_log_path() -> Path:
    return get_data_dir() / "unread_monitor.log"
