"""功能完成记录。"""

from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from typing import Any

from .paths import get_progress_log_path


class ProgressLog:
    """记录工具完成状态。"""

    def __init__(self, file_path: str | Path | None = None):
        self.file_path = Path(file_path) if file_path else get_progress_log_path()
        self.file_path.parent.mkdir(parents=True, exist_ok=True)
        if not self.file_path.exists():
            self.file_path.write_text("[]", encoding="utf-8")

    def _load(self) -> list[dict[str, Any]]:
        return json.loads(self.file_path.read_text(encoding="utf-8") or "[]")

    def _save(self, rows: list[dict[str, Any]]):
        self.file_path.write_text(json.dumps(rows, ensure_ascii=False, indent=2), encoding="utf-8")

    def record(
        self,
        *,
        tool_name: str,
        category: str,
        status: str,
        notes: str = "",
        version: str = "0.1.0",
        test_status: str = "未验证",
    ) -> dict[str, Any]:
        row = {
            "tool_name": tool_name,
            "category": category,
            "status": status,
            "completed_at": datetime.now().isoformat(timespec="seconds"),
            "version": version,
            "notes": notes,
            "test_status": test_status,
        }
        rows = [item for item in self._load() if item.get("tool_name") != tool_name]
        rows.append(row)
        self._save(rows)
        return row

    def list_all(self) -> list[dict[str, Any]]:
        return self._load()
