"""消息缓存数据库。"""

from __future__ import annotations

import sqlite3
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional

from .paths import get_message_cache_db_path


class MessageCache:
    """使用 SQLite 存储发送消息记录。"""

    def __init__(self, db_path: str | Path | None = None):
        self.db_path = Path(db_path) if db_path else get_message_cache_db_path()
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._init_db()

    def _connect(self) -> sqlite3.Connection:
        return sqlite3.connect(self.db_path)

    def _init_db(self):
        conn = self._connect()
        cursor = conn.cursor()
        cursor.execute(
            """
            CREATE TABLE IF NOT EXISTS sent_messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp REAL NOT NULL,
                chat_name TEXT NOT NULL,
                chat_id TEXT,
                chat_type TEXT,
                group_name TEXT,
                content TEXT NOT NULL,
                content_type TEXT,
                to_chat_name TEXT,
                to_chat_id TEXT
            )
            """
        )
        conn.commit()
        conn.close()

    def add_message(
        self,
        chat_name: str,
        content: str,
        *,
        chat_type: Optional[str] = None,
        content_type: Optional[str] = None,
        chat_id: Optional[str] = None,
        to_chat_name: Optional[str] = None,
        to_chat_id: Optional[str] = None,
        from_chat_name: Optional[str] = None,
        group_name: Optional[str] = None,
    ):
        conn = self._connect()
        cursor = conn.cursor()
        ts = datetime.now().timestamp()
        to_chat_name = to_chat_name if to_chat_name is not None else chat_name
        db_chat_name = from_chat_name if from_chat_name is not None else chat_name
        cursor.execute(
            """
            INSERT INTO sent_messages (
                chat_name, content, timestamp, chat_type, content_type,
                chat_id, to_chat_name, to_chat_id, group_name
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                db_chat_name,
                content,
                ts,
                chat_type,
                content_type,
                chat_id,
                to_chat_name,
                to_chat_id,
                group_name,
            ),
        )
        conn.commit()
        conn.close()

    def is_sent_by_me(self, content: str, chat_name: str | None = None, time_window: int = 300) -> bool:
        conn = self._connect()
        cursor = conn.cursor()
        cutoff_time = datetime.now().timestamp() - time_window
        if chat_name:
            cursor.execute(
                """
                SELECT 1 FROM sent_messages
                WHERE content = ?
                  AND timestamp > ?
                  AND (chat_name = ? OR to_chat_name = ?)
                LIMIT 1
                """,
                (content, cutoff_time, chat_name, chat_name),
            )
        else:
            cursor.execute(
                "SELECT 1 FROM sent_messages WHERE content = ? AND timestamp > ? LIMIT 1",
                (content, cutoff_time),
            )
        result = cursor.fetchone() is not None
        conn.close()
        return result

    def clear_all(self):
        conn = self._connect()
        cursor = conn.cursor()
        cursor.execute("DELETE FROM sent_messages")
        conn.commit()
        conn.close()

    def clear_old_messages(self, days: int = 7):
        cutoff_time = (datetime.now() - timedelta(days=days)).timestamp()
        conn = self._connect()
        cursor = conn.cursor()
        cursor.execute("DELETE FROM sent_messages WHERE timestamp < ?", (cutoff_time,))
        conn.commit()
        conn.close()
