# Beatlyze MCP Server

Use the [Beatlyze](https://beatlyze.dev) audio analysis API directly from Claude, Cursor, or any MCP-compatible AI agent.

## Tools

| Tool | Description |
|---|---|
| `analyze_url` | Submit an audio URL, wait for result (BPM, key, energy, mood, genre, sections) |
| `get_analysis` | Check status / retrieve result for a job_id |
| `get_usage` | Check your monthly usage and limits |

## Setup

**1. Get a free API key** at [beatlyze.dev](https://beatlyze.dev)

**2. Add to Claude Desktop** (`~/Library/Application Support/Claude/claude_desktop_config.json`):

```json
{
  "mcpServers": {
    "beatlyze": {
      "command": "uvx",
      "args": ["beatlyze-mcp"],
      "env": {
        "BEATLYZE_API_KEY": "bz_your_key_here"
      }
    }
  }
}
```

**3. Or run directly:**

```bash
pip install beatlyze-mcp
BEATLYZE_API_KEY=bz_your_key_here python -m beatlyze_mcp
```

## Example

Ask Claude:
> "Analyse this track: https://example.com/mytrack.mp3 — what's the BPM and key?"

Claude will call `analyze_url`, wait for the result, and tell you:
> "The track is 128.4 BPM in A minor, with high energy (0.78) and mood tags: energetic, dark."

## Environment variables

| Variable | Required | Default |
|---|---|---|
| `BEATLYZE_API_KEY` | Yes | — |
| `BEATLYZE_API_BASE` | No | `https://api.beatlyze.dev` |

The MCP server targets the live production API at `https://api.beatlyze.dev` by default.
