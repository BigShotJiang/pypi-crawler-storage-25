"""Beatlyze MCP server — audio analysis tools for AI agents."""
