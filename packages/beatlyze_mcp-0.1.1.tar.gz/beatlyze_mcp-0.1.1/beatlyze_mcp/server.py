"""Beatlyze MCP Server

Exposes the Beatlyze audio analysis API as MCP tools so AI agents can:
- Submit audio files or URLs for analysis
- Poll for results
- Check usage

Usage:
    BEATLYZE_API_KEY=bz_... python server.py

Or add to claude_desktop_config.json / any MCP host.
"""

from __future__ import annotations

import os
import time
from typing import Any

import httpx
from mcp.server.fastmcp import FastMCP

API_BASE = os.getenv("BEATLYZE_API_BASE", "https://api.beatlyze.dev")
API_KEY = os.getenv("BEATLYZE_API_KEY", "")
POLL_INTERVAL = 3  # seconds between status checks
POLL_TIMEOUT = 120  # max seconds to wait for completion

mcp = FastMCP(
    name="beatlyze",
    instructions=(
        "Beatlyze analyses audio files and returns BPM, musical key, energy, "
        "danceability, valence, LUFS loudness, mood tags, genre suggestions, "
        "duration, time signature, and structural sections.\n\n"
        "Typical workflow:\n"
        "1. Call `analyze_url` with a direct audio file URL (.mp3, .wav, .flac, etc.)\n"
        "2. The tool polls automatically and returns the completed result.\n\n"
        "Source: https://github.com/mg0024/beatlyze"
    ),
)


def _headers() -> dict[str, str]:
    if not API_KEY:
        raise ValueError(
            "BEATLYZE_API_KEY environment variable is not set. "
            "Register at https://beatlyze.dev to get a free API key."
        )
    return {"X-API-Key": API_KEY, "Content-Type": "application/json"}


def _poll_until_done(client: httpx.Client, job_id: str) -> dict[str, Any]:
    """Poll /v1/analysis/{job_id} until status is completed or failed."""
    deadline = time.time() + POLL_TIMEOUT
    while time.time() < deadline:
        resp = client.get(f"{API_BASE}/v1/analysis/{job_id}", headers=_headers())
        resp.raise_for_status()
        data = resp.json()
        if data["status"] in ("completed", "failed"):
            return data
        time.sleep(POLL_INTERVAL)
    raise TimeoutError(f"Job {job_id} did not complete within {POLL_TIMEOUT}s")


@mcp.tool()
def analyze_url(url: str, webhook_url: str = "") -> dict[str, Any]:
    """Analyse an audio file from a URL.

    Submits the URL to Beatlyze, waits for analysis to complete (up to 2 minutes),
    and returns the full result including BPM, key, energy, mood tags, and more.

    Args:
        url: Direct URL to an audio file (.mp3, .wav, .flac, .ogg, .aac, .m4a).
             Must be a public, direct-download link — not a streaming page.
        webhook_url: Optional URL to receive a signed POST when analysis completes.

    Returns:
        Analysis result dict with: bpm, bpm_confidence, key, scale, key_notation,
        key_confidence, energy, danceability, valence, loudness_lufs, mood_tags,
        genre_suggestions, duration_seconds, time_signature, sections.
    """
    payload: dict[str, Any] = {"url": url}
    if webhook_url:
        payload["webhook_url"] = webhook_url

    with httpx.Client(timeout=30) as client:
        resp = client.post(
            f"{API_BASE}/v1/analyze/url", json=payload, headers=_headers()
        )
        resp.raise_for_status()
        job = resp.json()
        return _poll_until_done(client, job["job_id"])


@mcp.tool()
def get_analysis(job_id: str) -> dict[str, Any]:
    """Get the result of a previously submitted analysis job.

    Use this to check on a job without waiting (e.g. if you already have a job_id
    from a prior session). Returns status and result if completed.

    Args:
        job_id: UUID returned by analyze_url.
    """
    with httpx.Client(timeout=10) as client:
        resp = client.get(f"{API_BASE}/v1/analysis/{job_id}", headers=_headers())
        resp.raise_for_status()
        return resp.json()


@mcp.tool()
def get_usage() -> dict[str, Any]:
    """Check your Beatlyze API usage for the current month.

    Returns current analysis count, monthly limit, subscription tier,
    and Stripe meter usage for paid tiers.
    """
    with httpx.Client(timeout=10) as client:
        resp = client.get(f"{API_BASE}/v1/usage", headers=_headers())
        resp.raise_for_status()
        return resp.json()


if __name__ == "__main__":
    mcp.run(transport="stdio")
