import pytest
from fa_purity import Cmd, FrozenList, ResultE, Unsafe

from fluidattacks_cloudflare_sdk import Token
from fluidattacks_cloudflare_sdk.ai_gateway import AiGatewayClientFactory
from fluidattacks_cloudflare_sdk.ai_gateway.core import LogRecord
from tests_fx._utils import (
    account_id_from_env,
    frozen_query,
    gateway_id_from_env,
    new_ai_client,
)


def _assert_failure(result: ResultE[FrozenList[LogRecord]]) -> None:
    assert result.to_coproduct().map(
        lambda _: False,
        lambda _: True,
    )


def test_list_logs_returns_valid_records() -> None:
    def _check(result: ResultE[FrozenList[LogRecord]]) -> None:
        assert len(result.alt(Unsafe.raise_exception).to_union()) > 0

    cmd: Cmd[None] = new_ai_client().bind(
        lambda client: client.list_logs(frozen_query()).map(_check)
    )
    with pytest.raises(SystemExit):
        cmd.compute()


def test_list_logs_with_invalid_token_returns_failure() -> None:
    cmd: Cmd[None] = account_id_from_env().bind(
        lambda account: gateway_id_from_env().bind(
            lambda gateway: (
                AiGatewayClientFactory.new(Token(raw="invalid-token"), account, gateway)
                .list_logs(frozen_query())
                .map(_assert_failure)
            )
        )
    )
    with pytest.raises(SystemExit):
        cmd.compute()
