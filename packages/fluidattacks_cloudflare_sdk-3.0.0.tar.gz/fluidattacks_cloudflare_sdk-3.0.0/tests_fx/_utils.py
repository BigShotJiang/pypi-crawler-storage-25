from datetime import UTC, datetime

from fa_purity import Cmd, Maybe, Unsafe
from fa_purity.date_time import DatetimeUTC
from fluidattacks_etl_utils.env_var import require_env_var

from fluidattacks_cloudflare_sdk import AccountId, GatewayId, Token
from fluidattacks_cloudflare_sdk.ai_gateway import AiGatewayClientFactory
from fluidattacks_cloudflare_sdk.ai_gateway.core import (
    AiGatewayClient,
    EndDate,
    LogsOrderBy,
    LogsQuery,
    StartDate,
)


def _get(var: str) -> Cmd[str]:
    return require_env_var(var).map(lambda r: r.alt(Unsafe.raise_exception).to_union())


def account_id_from_env() -> Cmd[AccountId]:
    return _get("CLOUDFLARE_ACCOUNT_ID").map(AccountId)


def gateway_id_from_env() -> Cmd[GatewayId]:
    return _get("CLOUDFLARE_GATEWAY_ID").map(GatewayId)


def frozen_query() -> LogsQuery:
    # 6pm-7pm UTC-5 = 23:00-00:00 UTC on 2026-04-07/08
    _start = (
        DatetimeUTC.assert_utc(datetime(2026, 4, 7, 23, 0, 0, tzinfo=UTC))
        .alt(Unsafe.raise_exception)
        .to_union()
    )
    _end = (
        DatetimeUTC.assert_utc(datetime(2026, 4, 8, 0, 0, 0, tzinfo=UTC))
        .alt(Unsafe.raise_exception)
        .to_union()
    )
    return LogsQuery(
        start=Maybe.some(StartDate(raw=_start)),
        end=Maybe.some(EndDate(raw=_end)),
        order_by=Maybe.some(LogsOrderBy.default()),
        per_page=Maybe.empty(),
    )


def new_ai_client() -> Cmd[AiGatewayClient]:
    return _get("CLOUDFLARE_API_TOKEN").bind(
        lambda token: account_id_from_env().bind(
            lambda account: gateway_id_from_env().map(
                lambda gateway: AiGatewayClientFactory.new(
                    Token(raw=token),
                    account,
                    gateway,
                )
            )
        )
    )
