"""Domain types and client interface for the Cloudflare AI Gateway resource."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Literal

from fa_purity import Maybe, Result, ResultE

if TYPE_CHECKING:
    from collections.abc import Callable

    from fa_purity import Cmd, FrozenList
    from fa_purity.date_time import DatetimeUTC
    from fa_purity.json import JsonObj


LogsOrderByField = Literal["created_at", "provider", "model", "model_type", "success", "cached"]
LogsOrderByDirection = Literal["asc", "desc"]


@dataclass(frozen=True)
class LogId:
    """Identifier for a single AI Gateway log entry."""

    raw: str


@dataclass(frozen=True)
class StartDate:
    """Inclusive lower bound for AI Gateway log queries."""

    raw: DatetimeUTC


@dataclass(frozen=True)
class EndDate:
    """Exclusive upper bound for AI Gateway log queries."""

    raw: DatetimeUTC


@dataclass(frozen=True)
class LogsOrderBy:
    """Ordering configuration for AI Gateway log queries."""

    field: LogsOrderByField
    direction: LogsOrderByDirection

    @staticmethod
    def default() -> LogsOrderBy:
        """Default ordering: created_at descending."""
        return LogsOrderBy(field="created_at", direction="desc")


@dataclass(frozen=True)
class _LogsPerPagePrivate:
    pass


@dataclass(frozen=True)
class LogsPerPage:
    """Number of records per page for AI Gateway log queries (1-50)."""

    _private: _LogsPerPagePrivate
    raw: int

    @staticmethod
    def new(raw: int) -> ResultE[LogsPerPage]:
        """Return failure if raw is outside [1, 50]."""
        _min = 1
        _max = 50
        if not _min <= raw <= _max:
            return Result.failure(
                ValueError(f"per_page must be between {_min} and {_max}, got {raw}"),
                LogsPerPage,
            ).alt(Exception)
        return Result.success(LogsPerPage(_LogsPerPagePrivate(), raw), Exception)

    @staticmethod
    def default() -> LogsPerPage:
        """Default page size (20)."""
        return LogsPerPage(_LogsPerPagePrivate(), 20)


@dataclass(frozen=True)
class LogsQuery:
    """Filter and ordering options for AI Gateway log queries."""

    start: Maybe[StartDate]
    end: Maybe[EndDate]
    order_by: Maybe[LogsOrderBy]
    per_page: Maybe[LogsPerPage]

    @staticmethod
    def all() -> LogsQuery:
        """Query with no filters and default ordering."""
        return LogsQuery(
            start=Maybe.empty(),
            end=Maybe.empty(),
            order_by=Maybe.some(LogsOrderBy.default()),
            per_page=Maybe.empty(),
        )


@dataclass(frozen=True)
class LogRecord:
    """A single AI Gateway request log entry."""

    id: str
    cached: bool
    created_at: DatetimeUTC
    duration: int
    model: str
    path: str
    provider: str
    success: bool
    tokens_in: Maybe[int]
    tokens_out: Maybe[int]
    cost: Maybe[float]
    custom_cost: Maybe[bool]
    metadata: Maybe[JsonObj]
    model_type: Maybe[str]
    request_content_type: Maybe[str]
    request_type: Maybe[str]
    response_content_type: Maybe[str]
    status_code: Maybe[int]
    step: Maybe[int]


@dataclass(frozen=True)
class AiGatewayClient:
    """Interface for Cloudflare AI Gateway operations."""

    list_logs: Callable[
        [LogsQuery],
        Cmd[ResultE[FrozenList[LogRecord]]],
    ]
    get_log_request: Callable[[LogId], Cmd[ResultE[JsonObj]]]
    get_log_response: Callable[[LogId], Cmd[ResultE[JsonObj]]]
