"""Private connection package for the Cloudflare SDK."""

from dataclasses import dataclass

from fluidattacks_cloudflare_sdk._client._client import CloudflareClient
from fluidattacks_cloudflare_sdk._client._core import Client, Token


@dataclass(frozen=True)
class CloudflareClientFactory:
    """Factory for a Cloudflare Client."""

    @staticmethod
    def new(token: Token) -> Client:
        """Build a Client from a Token."""
        return CloudflareClient.new(token).client


__all__ = ["Client", "CloudflareClientFactory", "Token"]
