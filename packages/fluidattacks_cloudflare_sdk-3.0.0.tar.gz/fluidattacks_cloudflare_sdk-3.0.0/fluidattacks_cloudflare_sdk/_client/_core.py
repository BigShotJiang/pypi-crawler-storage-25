"""Core types for the private Cloudflare connection package."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from cloudflare import Cloudflare


@dataclass(frozen=True)
class Token:
    """Cloudflare API token."""

    raw: str


@dataclass(frozen=True)
class Client:
    """Opaque Cloudflare connection; raw field is SDK-internal."""

    client: Cloudflare
