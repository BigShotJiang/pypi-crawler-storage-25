"""Private Cloudflare client; builds the public Client."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from cloudflare import Cloudflare

from fluidattacks_cloudflare_sdk._client._core import Client

if TYPE_CHECKING:
    from fluidattacks_cloudflare_sdk._client._core import Token


@dataclass(frozen=True)
class CloudflareClient:
    """Private class holding the raw Cloudflare connection."""

    _cloudflare: Cloudflare

    @staticmethod
    def new(token: Token) -> CloudflareClient:
        """Build a CloudflareClient from a Token."""
        return CloudflareClient(Cloudflare(api_token=token.raw))

    @property
    def client(self) -> Client:
        """Return the opaque Client."""
        return Client(self._cloudflare)
