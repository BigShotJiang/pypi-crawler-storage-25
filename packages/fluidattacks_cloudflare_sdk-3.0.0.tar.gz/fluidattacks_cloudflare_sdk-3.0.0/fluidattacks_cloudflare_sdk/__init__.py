"""Cloudflare SDK for fluidattacks observes."""

from fa_purity import Unsafe

from fluidattacks_cloudflare_sdk._client import Token
from fluidattacks_cloudflare_sdk._logger import set_logger
from fluidattacks_cloudflare_sdk.core import AccountId, GatewayId

__version__ = "3.0.0"

Unsafe.compute(set_logger(__name__, __version__))

__all__ = [
    "AccountId",
    "GatewayId",
    "Token",
]
