"""Provider-specific decoders for AI Gateway log payloads."""
