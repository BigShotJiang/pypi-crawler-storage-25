"""Decoders for raw Anthropic AI Gateway log payloads."""

from __future__ import annotations

from fa_purity import Coproduct, FrozenList, Maybe, PureIterFactory, PureIterTransform, ResultE
from fa_purity.json import (
    JsonObj,
    JsonPrimitiveUnfolder,
    JsonUnfolder,
    JsonValue,
    Unfolder,
)

from fluidattacks_cloudflare_sdk.providers.anthropic._core import (
    AnthropicErrorResponse,
    AnthropicMessage,
    AnthropicRequest,
    AnthropicResponse,
    AnthropicUsage,
    ContentBlock,
    ImageBlock,
    TextBlock,
    ToolResultArrayContent,
    ToolResultBlock,
    ToolResultContent,
    ToolResultStringContent,
)


def _jval_to_str(value: JsonValue) -> ResultE[str]:
    return Unfolder.to_primitive(value).bind(JsonPrimitiveUnfolder.to_str)


def _jval_to_int(value: JsonValue) -> ResultE[int]:
    return Unfolder.to_primitive(value).bind(JsonPrimitiveUnfolder.to_int)


def _decode_tool_result_content(value: JsonValue) -> ResultE[ToolResultContent]:
    """Decode tool_result content: plain string or array of raw JSON objects."""
    as_string: ResultE[ToolResultContent] = _jval_to_str(value).map(ToolResultStringContent)
    as_array: ResultE[ToolResultContent] = (
        Unfolder.to_list(value)
        .bind(
            lambda items: PureIterFactory.from_list(items).reduce(
                lambda acc, item: acc.bind(
                    lambda t: Unfolder.to_json(item).map(lambda obj: (*t, obj))
                ),
                ResultE[tuple[JsonObj, ...]].success(()),
            )
        )
        .map(ToolResultArrayContent)
    )
    return as_string.lash(lambda _: as_array)


def _decode_image_source(raw: JsonObj) -> ResultE[ImageBlock]:
    return JsonUnfolder.require(raw, "type", _jval_to_str).bind(
        lambda source_type: JsonUnfolder.require(raw, "media_type", _jval_to_str).bind(
            lambda media_type: JsonUnfolder.require(raw, "data", _jval_to_str).map(
                lambda data: ImageBlock(source_type=source_type, media_type=media_type, data=data)
            )
        )
    )


def _decode_content_block(item: JsonValue) -> Maybe[ContentBlock]:
    def _by_type(raw: JsonObj, block_type: str) -> ResultE[Maybe[ContentBlock]]:
        if block_type == "text":
            return JsonUnfolder.require(raw, "text", _jval_to_str).map(
                lambda t: Maybe.some(TextBlock(text=t))
            )
        if block_type == "tool_result":
            return JsonUnfolder.require(raw, "content", _decode_tool_result_content).map(
                lambda c: Maybe.some(ToolResultBlock(content=c))
            )
        if block_type == "image":
            return JsonUnfolder.require(
                raw, "source", lambda v: Unfolder.to_json(v).bind(_decode_image_source)
            ).map(Maybe.some)
        return ResultE[Maybe[ContentBlock]].success(Maybe.empty())

    return (
        Unfolder.to_json(item)
        .bind(
            lambda raw: JsonUnfolder.require(raw, "type", _jval_to_str).bind(
                lambda block_type: _by_type(raw, block_type)
            )
        )
        .to_coproduct()
        .map(lambda mb: mb, lambda _: Maybe.empty())
    )


def _decode_content_blocks(value: JsonValue) -> ResultE[FrozenList[ContentBlock]]:
    return (
        Unfolder.to_list(value)
        .map(
            lambda items: (
                PureIterFactory.from_list(items)
                .map(_decode_content_block)
                .transform(PureIterTransform.filter_maybe)
                .to_list()
            )
        )
        .lash(lambda _: _jval_to_str(value).map(lambda s: (TextBlock(text=s),)))
    )


def _decode_usage(raw: JsonObj) -> ResultE[AnthropicUsage]:
    return JsonUnfolder.require(raw, "input_tokens", _jval_to_int).bind(
        lambda input_t: JsonUnfolder.require(raw, "output_tokens", _jval_to_int).bind(
            lambda output_t: JsonUnfolder.optional(
                raw, "cache_read_input_tokens", _jval_to_int
            ).bind(
                lambda cache_read: JsonUnfolder.optional(
                    raw, "cache_creation_input_tokens", _jval_to_int
                ).map(
                    lambda cache_creation: AnthropicUsage(
                        input_tokens=input_t,
                        output_tokens=output_t,
                        cache_read_input_tokens=cache_read,
                        cache_creation_input_tokens=cache_creation,
                    )
                )
            )
        )
    )


def _decode_message(item: JsonValue) -> ResultE[AnthropicMessage]:
    return Unfolder.to_json(item).bind(
        lambda raw: JsonUnfolder.require(raw, "role", _jval_to_str).bind(
            lambda role: JsonUnfolder.require(raw, "content", _decode_content_blocks).map(
                lambda content: AnthropicMessage(role=role, content=content)
            )
        )
    )


def _decode_messages(messages: JsonValue) -> ResultE[FrozenList[AnthropicMessage]]:
    return Unfolder.to_list(messages).bind(
        lambda items: (
            ResultE[FrozenList[AnthropicMessage]].failure(TypeError("empty messages"))
            if len(items) == 0
            else PureIterFactory.from_list(items).reduce(
                lambda acc, item: acc.bind(lambda t: _decode_message(item).map(lambda m: (*t, m))),
                ResultE[tuple[AnthropicMessage, ...]].success(()),
            )
        )
    )


def decode_anthropic_request(raw: JsonObj) -> ResultE[AnthropicRequest]:
    """Decode a raw AI Gateway log request payload."""
    return JsonUnfolder.require(raw, "model", _jval_to_str).bind(
        lambda model: JsonUnfolder.require(raw, "messages", _decode_messages).map(
            lambda messages: AnthropicRequest(model=model, messages=messages)
        )
    )


def _decode_message_response(raw: JsonObj) -> ResultE[AnthropicResponse]:
    return JsonUnfolder.require(raw, "model", _jval_to_str).bind(
        lambda model: JsonUnfolder.require(raw, "id", _jval_to_str).bind(
            lambda msg_id: JsonUnfolder.require(raw, "role", _jval_to_str).bind(
                lambda role: JsonUnfolder.require(raw, "content", _decode_content_blocks).bind(
                    lambda content: JsonUnfolder.require(
                        raw, "usage", lambda v: Unfolder.to_json(v).bind(_decode_usage)
                    ).bind(
                        lambda usage: JsonUnfolder.optional(raw, "stop_reason", _jval_to_str).map(
                            lambda stop_reason: AnthropicResponse(
                                model=model,
                                id=msg_id,
                                role=role,
                                content=content,
                                stop_reason=stop_reason,
                                usage=usage,
                            )
                        )
                    )
                )
            )
        )
    )


def _decode_error_response(raw: JsonObj) -> ResultE[AnthropicErrorResponse]:
    return JsonUnfolder.require(
        raw,
        "error",
        lambda v: Unfolder.to_json(v).bind(
            lambda err: JsonUnfolder.require(err, "type", _jval_to_str).bind(
                lambda error_type: JsonUnfolder.require(err, "message", _jval_to_str).map(
                    lambda msg: AnthropicErrorResponse(error_type=error_type, message=msg)
                )
            )
        ),
    )


def decode_anthropic_response(
    raw: JsonObj,
) -> ResultE[Coproduct[AnthropicErrorResponse, AnthropicResponse]]:
    """Decode a raw AI Gateway log response payload."""
    return JsonUnfolder.require(raw, "type", _jval_to_str).bind(
        lambda resp_type: (
            _decode_error_response(raw).map(Coproduct.inl)
            if resp_type == "error"
            else _decode_message_response(raw).map(Coproduct.inr)
        )
    )
