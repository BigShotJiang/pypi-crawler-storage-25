"""Domain types for Anthropic provider log payloads."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from fa_purity import FrozenList, Maybe
    from fa_purity.json import JsonObj


@dataclass(frozen=True)
class TextBlock:
    """A text content block — user-authored prompt text."""

    text: str


@dataclass(frozen=True)
class ImageBlock:
    """An image content block."""

    source_type: str
    media_type: str
    data: str


@dataclass(frozen=True)
class ToolResultStringContent:
    """tool_result content when the API returned a plain string."""

    value: str


@dataclass(frozen=True)
class ToolResultArrayContent:
    """tool_result content when the API returned an array of JSON objects."""

    items: FrozenList[JsonObj]


ToolResultContent = ToolResultStringContent | ToolResultArrayContent


@dataclass(frozen=True)
class ToolResultBlock:
    """A tool_result content block."""

    content: ToolResultContent


ContentBlock = TextBlock | ToolResultBlock | ImageBlock


@dataclass(frozen=True)
class AnthropicUsage:
    """Token usage from an Anthropic response."""

    input_tokens: int
    output_tokens: int
    cache_read_input_tokens: Maybe[int]
    cache_creation_input_tokens: Maybe[int]


@dataclass(frozen=True)
class AnthropicMessage:
    """A single message in an Anthropic conversation."""

    role: str
    content: FrozenList[ContentBlock]


@dataclass(frozen=True)
class AnthropicErrorResponse:
    """Error payload from an Anthropic response via AI Gateway."""

    error_type: str
    message: str


@dataclass(frozen=True)
class AnthropicRequest:
    """Decoded Anthropic request payload from AI Gateway."""

    model: str
    messages: FrozenList[AnthropicMessage]


@dataclass(frozen=True)
class AnthropicResponse:
    """Decoded Anthropic response payload from AI Gateway."""

    model: str
    id: str
    role: str
    content: FrozenList[ContentBlock]
    stop_reason: Maybe[str]
    usage: AnthropicUsage
