"""Shared identifiers for the Cloudflare SDK."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class AccountId:
    """Cloudflare account identifier."""

    raw: str


@dataclass(frozen=True)
class GatewayId:
    """Cloudflare AI Gateway identifier."""

    raw: str
