from fa_purity import Maybe, Unsafe
from fa_purity.json import JsonObj, UnfoldedFactory

from fluidattacks_cloudflare_sdk.providers.anthropic import (
    AnthropicMessage,
    AnthropicRequest,
    AnthropicResponse,
    AnthropicUsage,
    ImageBlock,
    TextBlock,
    ToolResultArrayContent,
    ToolResultBlock,
    ToolResultStringContent,
    decode_anthropic_request,
    decode_anthropic_response,
)


def _to_json_obj(raw: object) -> JsonObj:
    return UnfoldedFactory.json_from_any(raw).alt(Unsafe.raise_exception).to_union()


# -- request fixtures --


def _full_request_raw() -> JsonObj:
    return _to_json_obj(
        {
            "model": "claude-opus-4-5-20251101",
            "messages": [
                {"role": "user", "content": [{"type": "text", "text": "what is 2+2?"}]},
            ],
            "system": "you are a helpful assistant",
        }
    )


def _minimal_request_raw() -> JsonObj:
    return _to_json_obj(
        {
            "model": "claude-sonnet-4-6",
            "messages": [
                {"role": "user", "content": [{"type": "text", "text": "hello"}]},
            ],
        }
    )


def _tool_result_string_raw() -> JsonObj:
    return _to_json_obj(
        {
            "model": "claude-sonnet-4-6",
            "messages": [
                {
                    "role": "user",
                    "content": [{"type": "tool_result", "content": "file content here"}],
                }
            ],
        }
    )


def _tool_result_array_raw() -> JsonObj:
    return _to_json_obj(
        {
            "model": "claude-sonnet-4-6",
            "messages": [
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "tool_result",
                            "content": [
                                {"type": "text", "text": "file line 1"},
                                {"type": "text", "text": "file line 2"},
                            ],
                        }
                    ],
                }
            ],
        }
    )


def _image_block_raw() -> JsonObj:
    return _to_json_obj(
        {
            "model": "claude-sonnet-4-6",
            "messages": [
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "image",
                            "source": {
                                "type": "base64",
                                "media_type": "image/jpeg",
                                "data": "abc123",
                            },
                        }
                    ],
                }
            ],
        }
    )


def _unknown_block_type_raw() -> JsonObj:
    return _to_json_obj(
        {
            "model": "claude-sonnet-4-6",
            "messages": [
                {
                    "role": "user",
                    "content": [
                        {"type": "tool_use", "id": "toolu_abc", "name": "read_file", "input": {}},
                        {"type": "text", "text": "hello"},
                    ],
                }
            ],
        }
    )


def _empty_messages_request_raw() -> JsonObj:
    return _to_json_obj(
        {
            "model": "claude-sonnet-4-6",
            "messages": [],
        }
    )


# -- response fixtures --


def _full_response_raw() -> JsonObj:
    return _to_json_obj(
        {
            "type": "message",
            "model": "claude-opus-4-5-20251101",
            "id": "msg_01ABC",
            "role": "assistant",
            "content": [{"type": "text", "text": "4"}],
            "stop_reason": "end_turn",
            "usage": {
                "input_tokens": 10,
                "output_tokens": 3,
                "cache_read_input_tokens": 200,
                "cache_creation_input_tokens": 50,
            },
        }
    )


def _minimal_response_raw() -> JsonObj:
    return _to_json_obj(
        {
            "type": "message",
            "model": "claude-sonnet-4-6",
            "id": "msg_02DEF",
            "role": "assistant",
            "content": [{"type": "text", "text": "hi"}],
            "usage": {
                "input_tokens": 5,
                "output_tokens": 1,
            },
        }
    )


# -- expected values --

_EXPECTED_FULL_REQUEST = AnthropicRequest(
    model="claude-opus-4-5-20251101",
    messages=(
        AnthropicMessage(
            role="user",
            content=(TextBlock(text="what is 2+2?"),),
        ),
    ),
)

_EXPECTED_MINIMAL_REQUEST = AnthropicRequest(
    model="claude-sonnet-4-6",
    messages=(
        AnthropicMessage(
            role="user",
            content=(TextBlock(text="hello"),),
        ),
    ),
)

_EXPECTED_FULL_RESPONSE = AnthropicResponse(
    model="claude-opus-4-5-20251101",
    id="msg_01ABC",
    role="assistant",
    content=(TextBlock(text="4"),),
    stop_reason=Maybe.some("end_turn"),
    usage=AnthropicUsage(
        input_tokens=10,
        output_tokens=3,
        cache_read_input_tokens=Maybe.some(200),
        cache_creation_input_tokens=Maybe.some(50),
    ),
)

_EXPECTED_MINIMAL_RESPONSE = AnthropicResponse(
    model="claude-sonnet-4-6",
    id="msg_02DEF",
    role="assistant",
    content=(TextBlock(text="hi"),),
    stop_reason=Maybe.empty(),
    usage=AnthropicUsage(
        input_tokens=5,
        output_tokens=1,
        cache_read_input_tokens=Maybe.empty(),
        cache_creation_input_tokens=Maybe.empty(),
    ),
)


# -- request tests --


def test_decode_full_request() -> None:
    result = decode_anthropic_request(_full_request_raw()).alt(Unsafe.raise_exception).to_union()
    assert result == _EXPECTED_FULL_REQUEST


def test_decode_minimal_request_optional_fields_are_empty() -> None:
    result = decode_anthropic_request(_minimal_request_raw()).alt(Unsafe.raise_exception).to_union()
    assert result == _EXPECTED_MINIMAL_REQUEST


def test_decode_request_empty_messages_fails() -> None:
    assert (
        decode_anthropic_request(_empty_messages_request_raw())
        .to_coproduct()
        .map(lambda _: False, lambda _: True)
    )


def test_decode_request_tool_result_string_content() -> None:
    result = (
        decode_anthropic_request(_tool_result_string_raw()).alt(Unsafe.raise_exception).to_union()
    )
    block = result.messages[0].content[0]
    assert isinstance(block, ToolResultBlock)
    assert isinstance(block.content, ToolResultStringContent)
    assert block.content.value == "file content here"


def test_decode_request_tool_result_array_content() -> None:
    _total_content = 2
    result = (
        decode_anthropic_request(_tool_result_array_raw()).alt(Unsafe.raise_exception).to_union()
    )
    block = result.messages[0].content[0]
    assert isinstance(block, ToolResultBlock)
    assert isinstance(block.content, ToolResultArrayContent)
    assert len(block.content.items) == _total_content


def test_decode_request_image_block() -> None:
    result = decode_anthropic_request(_image_block_raw()).alt(Unsafe.raise_exception).to_union()
    block = result.messages[0].content[0]
    assert block == ImageBlock(source_type="base64", media_type="image/jpeg", data="abc123")


def test_decode_request_unknown_block_type_is_dropped() -> None:
    result = (
        decode_anthropic_request(_unknown_block_type_raw()).alt(Unsafe.raise_exception).to_union()
    )
    content = result.messages[0].content
    assert len(content) == 1
    assert content[0] == TextBlock(text="hello")


# -- response tests --


def test_decode_full_response() -> None:
    cop = decode_anthropic_response(_full_response_raw()).alt(Unsafe.raise_exception).to_union()
    result = cop.map(lambda _: None, lambda r: r)
    assert result == _EXPECTED_FULL_RESPONSE


def test_decode_minimal_response_cache_fields_are_empty() -> None:
    cop = decode_anthropic_response(_minimal_response_raw()).alt(Unsafe.raise_exception).to_union()
    result = cop.map(lambda _: None, lambda r: r)
    assert result == _EXPECTED_MINIMAL_RESPONSE
