from __future__ import annotations

import math
import re
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Callable, Mapping

from memorymaster.config import get_config
from memorymaster.models import Claim
from memorymaster.recall_fusion import RRF_K_DEFAULT, rrf_fuse

RETRIEVAL_MODES = ("legacy", "hybrid")

VectorSearchHook = Callable[[str, list[Claim]], Mapping[int, float]]

_TOKEN_RE = re.compile(r"[a-z0-9_]+")
_STOPWORDS = {
    "a",
    "an",
    "and",
    "are",
    "as",
    "at",
    "be",
    "by",
    "for",
    "from",
    "has",
    "he",
    "in",
    "is",
    "it",
    "its",
    "of",
    "on",
    "that",
    "the",
    "to",
    "was",
    "were",
    "will",
    "with",
}


@dataclass(slots=True)
class RankedClaim:
    claim: Claim
    score: float
    lexical_score: float
    freshness_score: float
    confidence_score: float
    vector_score: float


def _parse_iso(value: str | None) -> datetime | None:
    if not value:
        return None
    try:
        parsed = datetime.fromisoformat(value)
        if parsed.tzinfo is None:
            return parsed.replace(tzinfo=timezone.utc)
        return parsed
    except ValueError:
        return None


def _tokens(value: str) -> set[str]:
    tokens: set[str] = set()
    for token in _TOKEN_RE.findall(value.lower()):
        if len(token) < 3:
            continue
        if token in _STOPWORDS:
            continue
        tokens.add(token)
    return tokens


def _lexical_score(query_text: str, claim: Claim) -> float:
    q = query_text.strip().lower()
    if not q:
        return 0.0
    body = " ".join(x for x in [claim.text, claim.normalized_text or "", claim.subject or "", claim.object_value or ""] if x)
    body_lower = body.lower()

    q_tokens = _tokens(q)
    c_tokens = _tokens(body_lower)
    if not q_tokens or not c_tokens:
        return 0.0

    overlap = len(q_tokens & c_tokens)
    token_recall = overlap / max(1, len(q_tokens))
    token_precision = overlap / max(1, len(c_tokens))
    contains_phrase = 1.0 if q in body_lower else 0.0
    prefix_bonus = 1.0 if any(tok.startswith(q) for tok in c_tokens) and len(q) >= 3 else 0.0

    cfg = get_config()
    w_recall, w_precision, w_phrase, w_prefix = cfg.lexical_weights
    score = (w_recall * token_recall) + (w_precision * token_precision) + (w_phrase * contains_phrase) + (w_prefix * prefix_bonus)
    return max(0.0, min(1.0, score))


def _freshness_score(claim: Claim) -> float:
    anchor = _parse_iso(claim.last_validated_at) or _parse_iso(claim.updated_at) or _parse_iso(claim.created_at)
    if anchor is None:
        return 0.5
    now = datetime.now(timezone.utc)
    age_hours = max(0.0, (now - anchor).total_seconds() / 3600.0)
    cfg = get_config()
    half_life_hours = cfg.freshness_half_life_hours
    half_life = half_life_hours.get(claim.volatility, half_life_hours["medium"])
    return max(0.0, min(1.0, math.exp(-age_hours / max(1.0, half_life))))


_TIER_BONUS = {"core": 0.15, "working": 0.0, "peripheral": -0.10}


def _tier_bonus(claim: Claim) -> float:
    """Return a score adjustment based on the claim's memory tier."""
    tier = getattr(claim, "tier", "working") or "working"
    return _TIER_BONUS.get(tier, 0.0)


def rank_claims(
    query_text: str,
    claims: list[Claim],
    *,
    mode: str = "legacy",
    limit: int = 20,
    vector_hook: VectorSearchHook | None = None,
    semantic_vectors: bool = False,
    query_type: str | None = None,
) -> list[Claim]:
    return [
        row.claim
        for row in rank_claim_rows(
            query_text,
            claims,
            mode=mode,
            limit=limit,
            vector_hook=vector_hook,
            semantic_vectors=semantic_vectors,
            query_type=query_type,
        )
    ]


def _compute_claim_score(
    claim: Claim,
    lexical: float,
    confidence: float,
    freshness: float,
    vector: float,
    vector_enabled: bool,
    semantic_vectors: bool,
    query_type: str | None = None,
) -> float:
    """Compute relevance score for a claim.

    When ``query_type`` matches a configured per-type profile
    (``cfg.retrieval_profile(query_type)``), the profile's 4-tuple replaces
    ``cfg.retrieval_weights`` for vector-enabled paths. The no-vector path
    is unchanged — profiles only override the hybrid blend.
    """
    cfg = get_config()
    profile = cfg.retrieval_profile(query_type) if query_type else None
    w_l, w_c, w_f, w_v = profile if profile is not None else cfg.retrieval_weights
    if vector_enabled and semantic_vectors:
        # Real semantic embeddings use the same configurable blend as other
        # vector-enabled ranking so env sweeps affect both paths.
        score = (w_l * lexical) + (w_c * confidence) + (w_f * freshness) + (w_v * vector)
    elif vector_enabled:
        score = (w_l * lexical) + (w_c * confidence) + (w_f * freshness) + (w_v * vector)
    else:
        w_l, w_c, w_f = cfg.retrieval_weights_no_vector
        score = (w_l * lexical) + (w_c * confidence) + (w_f * freshness)
    if claim.pinned:
        score += cfg.pinned_bonus
    score += _tier_bonus(claim)
    return score


def _source_session_key(row: RankedClaim) -> str:
    claim = row.claim
    if claim.source_agent:
        return claim.source_agent
    if claim.citations:
        source = claim.citations[0].source
        if source:
            return source
    if claim.subject:
        return claim.subject
    return f"claim:{claim.id}"


def apply_session_diversity_cap(ranked: list[RankedClaim], cap: int) -> list[RankedClaim]:
    if cap <= 0:
        return ranked
    counts: dict[str, int] = {}
    result: list[RankedClaim] = []
    for row in ranked:
        source_session = _source_session_key(row)
        count = counts.get(source_session, 0)
        if count >= cap:
            continue
        counts[source_session] = count + 1
        result.append(row)
    return result


def _component_rankings(rows: list[RankedClaim]) -> dict[str, list[int]]:
    original_positions = {row.claim.id: index for index, row in enumerate(rows)}

    def ranked_ids(score_attr: str) -> list[int]:
        ordered = sorted(
            rows,
            key=lambda row: (
                -float(getattr(row, score_attr)),
                original_positions[row.claim.id],
            ),
        )
        return [row.claim.id for row in ordered]

    return {
        "lexical": ranked_ids("lexical_score"),
        "vector": ranked_ids("vector_score"),
        "confidence": ranked_ids("confidence_score"),
        "freshness": ranked_ids("freshness_score"),
    }


def apply_rrf_tiebreaker(
    ranked: list[RankedClaim],
    *,
    threshold: float = 0.01,
    k: int = RRF_K_DEFAULT,
    enabled: bool = True,
) -> list[RankedClaim]:
    if not enabled or len(ranked) < 2:
        return ranked

    threshold = max(0.0, threshold)
    threshold_epsilon = 1e-12
    head_count = min(10, len(ranked))
    result = list(ranked)
    index = 0

    while index < head_count:
        group_end = index + 1
        while (
            group_end < head_count
            and abs(ranked[group_end - 1].score - ranked[group_end].score)
            <= threshold + threshold_epsilon
        ):
            group_end += 1

        if group_end - index > 1:
            group = ranked[index:group_end]
            original_positions = {row.claim.id: offset for offset, row in enumerate(group)}
            rrf_scores = rrf_fuse(_component_rankings(group), k=k)
            result[index:group_end] = sorted(
                group,
                key=lambda row: (
                    -rrf_scores.get(row.claim.id, 0.0),
                    original_positions[row.claim.id],
                ),
            )

        index = group_end

    return result


def rank_claim_rows(
    query_text: str,
    claims: list[Claim],
    *,
    mode: str = "legacy",
    limit: int = 20,
    vector_hook: VectorSearchHook | None = None,
    semantic_vectors: bool = False,
    query_type: str | None = None,
) -> list[RankedClaim]:
    if mode not in RETRIEVAL_MODES:
        raise ValueError(f"Unknown retrieval mode: {mode}")
    if limit <= 0:
        return []
    if mode == "legacy":
        rows: list[RankedClaim] = []
        for claim in claims:
            lexical = _lexical_score(query_text, claim) if query_text.strip() else 0.0
            confidence = max(0.0, min(1.0, claim.confidence))
            freshness = _freshness_score(claim)
            score = confidence + (get_config().pinned_bonus if claim.pinned else 0.0) + _tier_bonus(claim)
            rows.append(
                RankedClaim(
                    claim=claim,
                    score=score,
                    lexical_score=lexical,
                    freshness_score=freshness,
                    confidence_score=confidence,
                    vector_score=0.0,
                )
            )
        return apply_session_diversity_cap(rows, get_config().session_diversity_cap)[:limit]

    vector_scores: Mapping[int, float] = {}
    if vector_hook is not None:
        vector_scores = vector_hook(query_text, claims) or {}

    vector_enabled = bool(vector_scores)
    ranked: list[RankedClaim] = []

    for claim in claims:
        lexical = _lexical_score(query_text, claim)
        confidence = max(0.0, min(1.0, claim.confidence))
        freshness = _freshness_score(claim)
        vector = max(0.0, min(1.0, float(vector_scores.get(claim.id, 0.0))))

        score = _compute_claim_score(
            claim,
            lexical,
            confidence,
            freshness,
            vector,
            vector_enabled,
            semantic_vectors,
            query_type=query_type,
        )

        ranked.append(
            RankedClaim(
                claim=claim,
                score=score,
                lexical_score=lexical,
                freshness_score=freshness,
                confidence_score=confidence,
                vector_score=vector,
            )
        )

    if query_text.strip():
        max_lexical = max((row.lexical_score for row in ranked), default=0.0)
        if max_lexical > 0.0:
            if semantic_vectors and vector_enabled:
                # With real semantic search, keep results that match on vector OR lexical
                min_vector_threshold = 0.55
                ranked = [
                    row for row in ranked
                    if row.lexical_score > 0.0 or row.vector_score >= min_vector_threshold or row.claim.pinned
                ]
            else:
                ranked = [row for row in ranked if row.lexical_score > 0.0 or row.claim.pinned]

    ranked.sort(
        key=lambda row: (
            row.score,
            row.lexical_score,
            row.confidence_score,
            row.freshness_score,
            row.claim.updated_at,
            row.claim.id,
        ),
        reverse=True,
    )
    cfg = get_config()
    ranked = apply_rrf_tiebreaker(
        ranked,
        threshold=cfg.rrf_tiebreaker_threshold,
        enabled=cfg.rrf_tiebreaker_enabled,
    )
    ranked = apply_session_diversity_cap(ranked, get_config().session_diversity_cap)
    return ranked[:limit]
