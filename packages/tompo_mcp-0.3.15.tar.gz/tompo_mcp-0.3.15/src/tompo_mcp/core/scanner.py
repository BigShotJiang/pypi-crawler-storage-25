"""Portfolio scanner — scans all workspaces, builds cross-workspace map."""

from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass, field
from typing import Any, Callable, Optional

from tompo_mcp.core.fabric_client import FabricClient
from tompo_mcp.core.lineage import build_lineage
from tompo_mcp.core.models import (
    LineageResponse,
    ReportInfo,
    SemanticModelInfo,
)
from tompo_mcp.core.parser import parse_report_definition, parse_semantic_model

logger = logging.getLogger(__name__)

# Max concurrent workspace scans to avoid throttling
MAX_CONCURRENT = 5


@dataclass
class WorkspaceSummary:
    """Lightweight summary of a workspace (Phase 1 — no definitions needed)."""

    id: str
    name: str
    datasets: list[dict[str, Any]] = field(default_factory=list)
    reports: list[dict[str, Any]] = field(default_factory=list)


@dataclass
class CrossWorkspaceLink:
    """A report in one workspace using a model from another workspace."""

    model_id: str
    model_name: str
    model_workspace_id: str
    model_workspace_name: str
    report_id: str
    report_name: str
    report_workspace_id: str
    report_workspace_name: str


@dataclass
class PortfolioScan:
    """Result of a full portfolio scan (Phase 1)."""

    workspaces: list[WorkspaceSummary] = field(default_factory=list)
    cross_workspace_links: list[CrossWorkspaceLink] = field(default_factory=list)
    total_datasets: int = 0
    total_reports: int = 0

    # Maps for quick lookup
    dataset_locations: dict[str, tuple[str, str, str]] = field(default_factory=dict)
    # dataset_id -> (workspace_id, workspace_name, dataset_name)


async def scan_portfolio(
    client: FabricClient,
    progress_callback: Optional[Callable[[int, int, str], None]] = None,
) -> PortfolioScan:
    """Phase 1 scan: list all workspaces, datasets, reports. Build cross-workspace map.

    This is fast (~15-20 seconds) because it only uses list APIs, no definitions.

    Args:
        client: FabricClient instance
        progress_callback: Optional function(current, total, message) for progress updates
    """
    # Step 1: List all workspaces
    workspaces_raw = await client.list_workspaces()
    total = len(workspaces_raw)

    if progress_callback:
        progress_callback(0, total, f"Found {total} workspaces, scanning items...")

    # Step 2: Scan items in each workspace (parallel, throttled)
    semaphore = asyncio.Semaphore(MAX_CONCURRENT)
    summaries: list[WorkspaceSummary] = []
    completed = 0

    async def _scan_workspace(ws: dict[str, Any]) -> Optional[WorkspaceSummary]:
        nonlocal completed
        async with semaphore:
            ws_id = ws.get("id", "")
            ws_name = ws.get("name", "")
            try:
                items = await client.get_workspace_items(ws_id)
                summary = WorkspaceSummary(
                    id=ws_id,
                    name=ws_name,
                    datasets=items.get("datasets", []),
                    reports=items.get("reports", []),
                )
                completed += 1
                if progress_callback:
                    progress_callback(completed, total, f"Scanned {ws_name}")
                return summary
            except Exception as exc:
                logger.warning("Failed to scan workspace %s: %s", ws_name, exc)
                completed += 1
                if progress_callback:
                    progress_callback(completed, total, f"Failed: {ws_name}")
                return None

    tasks = [_scan_workspace(ws) for ws in workspaces_raw]
    results = await asyncio.gather(*tasks)
    summaries = [s for s in results if s is not None]

    # Step 3: Build cross-workspace map
    # Map: dataset_id -> (workspace_id, workspace_name, dataset_name)
    dataset_locations: dict[str, tuple[str, str, str]] = {}
    for ws_summary in summaries:
        for ds in ws_summary.datasets:
            ds_id = ds.get("id", "")
            ds_name = ds.get("name", "")
            dataset_locations[ds_id] = (ws_summary.id, ws_summary.name, ds_name)

    # Find cross-workspace links
    cross_links: list[CrossWorkspaceLink] = []
    for ws_summary in summaries:
        for report in ws_summary.reports:
            report_ds_id = report.get("datasetId", "")
            if not report_ds_id:
                continue
            if report_ds_id in dataset_locations:
                model_ws_id, model_ws_name, model_name = dataset_locations[report_ds_id]
                # Only record if the report is in a DIFFERENT workspace than the model
                if model_ws_id != ws_summary.id:
                    cross_links.append(CrossWorkspaceLink(
                        model_id=report_ds_id,
                        model_name=model_name,
                        model_workspace_id=model_ws_id,
                        model_workspace_name=model_ws_name,
                        report_id=report.get("id", ""),
                        report_name=report.get("name", ""),
                        report_workspace_id=ws_summary.id,
                        report_workspace_name=ws_summary.name,
                    ))

    total_datasets = sum(len(ws.datasets) for ws in summaries)
    total_reports = sum(len(ws.reports) for ws in summaries)

    return PortfolioScan(
        workspaces=summaries,
        cross_workspace_links=cross_links,
        total_datasets=total_datasets,
        total_reports=total_reports,
        dataset_locations=dataset_locations,
    )


async def deep_scan_model(
    client: FabricClient,
    workspace_id: str,
    dataset_id: str,
    dataset_name: str,
    portfolio: Optional[PortfolioScan] = None,
) -> Optional[LineageResponse]:
    """Phase 2 deep scan: get full lineage for a specific model, including cross-workspace reports.

    Args:
        client: FabricClient instance
        workspace_id: The workspace containing the semantic model
        dataset_id: The semantic model ID
        dataset_name: Human-readable name
        portfolio: Optional PortfolioScan to find cross-workspace reports
    """
    # Get semantic model definition AND reports list in parallel
    raw_model, same_ws_reports = await asyncio.gather(
        client.get_semantic_model_definition(workspace_id, dataset_id),
        client.get_reports_for_dataset(workspace_id, dataset_id),
    )
    if not raw_model:
        return None

    model = parse_semantic_model(raw_model, dataset_id, dataset_name)

    # Get cross-workspace reports if portfolio is available
    cross_ws_report_refs: list[dict[str, Any]] = []
    if portfolio:
        for link in portfolio.cross_workspace_links:
            if link.model_id == dataset_id:
                cross_ws_report_refs.append({
                    "id": link.report_id,
                    "name": f"{link.report_name} ({link.report_workspace_name})",
                    "datasetId": dataset_id,
                    "_workspace_id": link.report_workspace_id,
                    "_workspace_name": link.report_workspace_name,
                })

    # Fetch ALL report definitions in parallel
    reports: list[ReportInfo] = []

    async def _fetch_report(ws_id: str, rid: str, rname: str) -> ReportInfo:
        raw_report = await client.get_report_definition(ws_id, rid)
        if raw_report:
            return parse_report_definition(raw_report, rid, rname, dataset_id)
        return ReportInfo(id=rid, name=rname, dataset_id=dataset_id)

    report_tasks = []
    # Same-workspace reports
    for rd in same_ws_reports:
        rid = rd.get("id", "")
        rname = rd.get("name", "Unknown")
        report_tasks.append(_fetch_report(workspace_id, rid, rname))

    # Cross-workspace reports
    for ref in cross_ws_report_refs:
        report_tasks.append(_fetch_report(ref["_workspace_id"], ref["id"], ref["name"]))

    if report_tasks:
        reports = list(await asyncio.gather(*report_tasks))

    return build_lineage(model, reports, workspace_id)


def search_portfolio(
    portfolio: PortfolioScan,
    query: str,
    lineage_cache: dict[str, LineageResponse] | None = None,
) -> list[dict[str, Any]]:
    """Search for a column or measure name across all scanned lineage data.

    Args:
        portfolio: The portfolio scan result
        query: Search term (column name, measure name, table name)
        lineage_cache: Dict of dataset_id -> LineageResponse from deep scans

    Returns list of matches with full context.
    """
    if not lineage_cache:
        return []

    query_lower = query.lower().strip()
    results: list[dict[str, Any]] = []

    for dataset_id, lineage in lineage_cache.items():
        model = lineage.model
        ws_id, ws_name, _ = portfolio.dataset_locations.get(dataset_id, ("", "", ""))

        for table in model.tables:
            if table.is_hidden:
                continue

            # Search columns
            for col in table.columns:
                if col.is_hidden:
                    continue
                if query_lower in col.name.lower():
                    # Find usages in reports
                    usages = _find_field_usages(
                        col.name, "column", table.name, lineage.reports
                    )
                    results.append({
                        "type": "column",
                        "name": col.name,
                        "table": table.name,
                        "data_type": col.data_type,
                        "model_name": model.name,
                        "model_id": dataset_id,
                        "workspace_name": ws_name,
                        "workspace_id": ws_id,
                        "usages": usages,
                    })

            # Search measures
            for measure in table.measures:
                if query_lower in measure.name.lower():
                    usages = _find_field_usages(
                        measure.name, "measure", table.name, lineage.reports
                    )
                    results.append({
                        "type": "measure",
                        "name": measure.name,
                        "table": table.name,
                        "expression": measure.expression,
                        "model_name": model.name,
                        "model_id": dataset_id,
                        "workspace_name": ws_name,
                        "workspace_id": ws_id,
                        "usages": usages,
                    })

            # Search table names
            if query_lower in table.name.lower():
                results.append({
                    "type": "table",
                    "name": table.name,
                    "column_count": len(table.columns),
                    "measure_count": len(table.measures),
                    "model_name": model.name,
                    "model_id": dataset_id,
                    "workspace_name": ws_name,
                    "workspace_id": ws_id,
                    "usages": [],
                })

    return results


def _find_field_usages(
    field_name: str,
    field_type: str,
    table_name: str,
    reports: list[ReportInfo],
) -> list[dict[str, str]]:
    """Find all visuals where a field is used."""
    usages: list[dict[str, str]] = []
    for report in reports:
        for page in report.pages:
            for visual in page.visuals:
                for fb in visual.field_bindings:
                    if (
                        fb.table_name == table_name
                        and fb.field_name == field_name
                        and fb.field_type == field_type
                    ):
                        usages.append({
                            "report": report.name,
                            "page": page.display_name,
                            "visual_type": visual.visual_type,
                            "visual_title": visual.title or visual.visual_type,
                        })
    return usages


# ── Incremental Deep Scan ─────────────────────────────────────────────


@dataclass
class ScanProgress:
    """Mutable progress tracker for deep scans."""
    total: int = 0
    completed: int = 0
    current_name: str = ""
    current_detail: str = ""
    completed_items: list[dict[str, Any]] = field(default_factory=list)
    skipped_items: list[dict[str, Any]] = field(default_factory=list)
    stop_requested: bool = False

    # Running totals
    total_tables: int = 0
    total_columns: int = 0
    total_measures: int = 0
    total_reports_parsed: int = 0
    total_visuals_mapped: int = 0


async def deep_scan_selected_workspaces(
    client: FabricClient,
    workspace_ids: list[str],
    portfolio: PortfolioScan,
    progress: ScanProgress,
    datasets_to_scan: Optional[list[dict[str, Any]]] = None,
) -> dict[str, LineageResponse]:
    """Deep scan models in selected workspaces. Supports stop signal.

    Args:
        client: FabricClient instance
        workspace_ids: Workspace IDs to scan
        portfolio: PortfolioScan for cross-workspace detection
        progress: Mutable progress object (check stop_requested)
        datasets_to_scan: If provided, only scan these specific datasets
                          (for incremental scans). Otherwise scan all in selected workspaces.

    Returns dict of dataset_id -> LineageResponse for models that succeeded.
    """
    # Build list of (workspace_id, dataset_id, dataset_name)
    scan_list: list[tuple[str, str, str]] = []

    if datasets_to_scan:
        # Targeted scan — specific datasets
        for ds in datasets_to_scan:
            ds_id = ds.get("id", "")
            ds_name = ds.get("name", "")
            ws_id = ds.get("_workspace_id", "")
            if not ws_id:
                # Look up from portfolio
                loc = portfolio.dataset_locations.get(ds_id)
                if loc:
                    ws_id = loc[0]
            if ws_id and ds_id:
                scan_list.append((ws_id, ds_id, ds_name))
    else:
        # Full scan — all datasets in selected workspaces
        ws_set = set(workspace_ids)
        for ws_summary in portfolio.workspaces:
            if ws_summary.id in ws_set:
                for ds in ws_summary.datasets:
                    scan_list.append((ws_summary.id, ds.get("id", ""), ds.get("name", "")))

    progress.total = len(scan_list)
    results: dict[str, LineageResponse] = {}

    for ws_id, ds_id, ds_name in scan_list:
        if progress.stop_requested:
            break

        progress.current_name = ds_name
        progress.current_detail = "Fetching model definition..."

        try:
            lineage = await deep_scan_model(client, ws_id, ds_id, ds_name, portfolio)

            if lineage:
                results[ds_id] = lineage
                n_tables = len(lineage.model.tables)
                n_cols = sum(len(t.columns) for t in lineage.model.tables)
                n_meas = sum(len(t.measures) for t in lineage.model.tables)
                n_reports = len(lineage.reports)
                n_visuals = sum(
                    len(v.field_bindings)
                    for r in lineage.reports for p in r.pages for v in p.visuals
                )

                progress.total_tables += n_tables
                progress.total_columns += n_cols
                progress.total_measures += n_meas
                progress.total_reports_parsed += n_reports
                progress.total_visuals_mapped += n_visuals

                ws_name = ""
                loc = portfolio.dataset_locations.get(ds_id)
                if loc:
                    ws_name = loc[1]

                progress.completed_items.append({
                    "name": ds_name,
                    "workspace": ws_name,
                    "tables": n_tables,
                    "reports": n_reports,
                    "visuals": n_visuals,
                    "status": "ok",
                })
            else:
                ws_name = ""
                loc = portfolio.dataset_locations.get(ds_id)
                if loc:
                    ws_name = loc[1]
                progress.skipped_items.append({
                    "id": ds_id,
                    "name": ds_name,
                    "workspace_id": ws_id,
                    "workspace_name": ws_name,
                    "reason": "No definition available (permission denied or unsupported format)",
                })

        except Exception as exc:
            ws_name = ""
            loc = portfolio.dataset_locations.get(ds_id)
            if loc:
                ws_name = loc[1]
            reason = str(exc)[:120]
            progress.skipped_items.append({
                "id": ds_id,
                "name": ds_name,
                "workspace_id": ws_id,
                "workspace_name": ws_name,
                "reason": reason,
            })

        progress.completed += 1

    return results
