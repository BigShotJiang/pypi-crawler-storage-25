"""Governance health score calculator for Fabric workspaces."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from tompo_mcp.core.models import LineageResponse, ReportInfo, SemanticModelInfo


@dataclass
class HealthIssue:
    """A single governance issue found."""

    severity: str  # "error", "warning", "info"
    category: str  # "unused", "documentation", "quality", "security"
    message: str
    details: str = ""


@dataclass
class HealthScore:
    """Governance health score for a workspace or model."""

    score: int  # 0-100
    total_checks: int
    passed_checks: int
    issues: list[HealthIssue] = field(default_factory=list)
    breakdown: dict[str, int] = field(default_factory=dict)
    # category -> points deducted


def calculate_model_health(
    model: SemanticModelInfo,
    reports: list[ReportInfo],
) -> HealthScore:
    """Calculate governance health score for a semantic model.

    Scoring (100 points total, deductions):
    - Unused tables: -3 per unused non-date table, -1 per unused date table
    - Missing descriptions: -1 per column without description (max -15), -2 per table without desc (max -10)
    - Orphan measures: -3 per measure not used in any visual
    - Missing format strings: -1 per measure without format string (max -5)
    - No relationships: -5 if model has >1 table but no relationships
    - Empty tables: -3 per table with 0 columns
    """
    issues: list[HealthIssue] = []
    deductions: dict[str, int] = {
        "unused": 0,
        "documentation": 0,
        "quality": 0,
    }

    visible_tables = [t for t in model.tables if not t.is_hidden]

    # ── Check 1: Unused tables ────────────────────────────────────
    used_tables = _get_used_table_names(reports)
    auto_date_pattern = {"datetabletemplate", "localdatetable"}

    for table in visible_tables:
        is_auto_date = any(
            table.name.lower().startswith(p) for p in auto_date_pattern
        )
        if table.name not in used_tables:
            if is_auto_date:
                deductions["unused"] += 1
                issues.append(HealthIssue(
                    severity="info",
                    category="unused",
                    message=f"Auto-generated date table `{table.name}` is not used",
                    details="Consider removing to reduce model size",
                ))
            else:
                deductions["unused"] += 3
                issues.append(HealthIssue(
                    severity="warning",
                    category="unused",
                    message=f"Table `{table.name}` is not used in any report",
                    details="No visuals reference columns or measures from this table",
                ))

    # ── Check 2: Missing descriptions ─────────────────────────────
    tables_no_desc = 0
    cols_no_desc = 0

    for table in visible_tables:
        is_auto_date = any(
            table.name.lower().startswith(p) for p in auto_date_pattern
        )
        if is_auto_date:
            continue

        if not table.description:
            tables_no_desc += 1

        for col in table.columns:
            if col.is_hidden:
                continue
            if not col.description:
                cols_no_desc += 1

    if tables_no_desc > 0:
        penalty = min(tables_no_desc * 2, 10)
        deductions["documentation"] += penalty
        issues.append(HealthIssue(
            severity="warning",
            category="documentation",
            message=f"{tables_no_desc} table(s) without descriptions",
            details="Add descriptions to help users understand the data",
        ))

    if cols_no_desc > 0:
        penalty = min(cols_no_desc, 15)
        deductions["documentation"] += penalty
        issues.append(HealthIssue(
            severity="warning",
            category="documentation",
            message=f"{cols_no_desc} column(s) without descriptions",
            details="Column descriptions improve discoverability",
        ))

    # ── Check 3: Orphan measures ──────────────────────────────────
    used_measures = _get_used_measures(reports)
    orphan_measures = 0

    for table in visible_tables:
        for measure in table.measures:
            key = (table.name, measure.name)
            if key not in used_measures:
                orphan_measures += 1

    if orphan_measures > 0:
        deductions["quality"] += min(orphan_measures * 3, 15)
        issues.append(HealthIssue(
            severity="warning",
            category="quality",
            message=f"{orphan_measures} measure(s) not used in any visual",
            details="Unused measures add complexity without value",
        ))

    # ── Check 4: Missing format strings ───────────────────────────
    measures_no_format = 0
    for table in visible_tables:
        for measure in table.measures:
            if not measure.format_string:
                measures_no_format += 1

    if measures_no_format > 0:
        deductions["quality"] += min(measures_no_format, 5)
        issues.append(HealthIssue(
            severity="info",
            category="quality",
            message=f"{measures_no_format} measure(s) without format strings",
            details="Format strings ensure consistent display (e.g., currency, percentage)",
        ))

    # ── Check 5: No relationships ─────────────────────────────────
    real_tables = [
        t for t in visible_tables
        if not any(t.name.lower().startswith(p) for p in auto_date_pattern)
    ]
    if len(real_tables) > 1 and len(model.relationships) == 0:
        deductions["quality"] += 5
        issues.append(HealthIssue(
            severity="warning",
            category="quality",
            message="No relationships defined between tables",
            details=f"Model has {len(real_tables)} tables but no relationships",
        ))

    # ── Check 6: Empty tables ─────────────────────────────────────
    empty_tables = [t for t in real_tables if len(t.columns) == 0]
    if empty_tables:
        deductions["quality"] += len(empty_tables) * 3
        issues.append(HealthIssue(
            severity="error",
            category="quality",
            message=f"{len(empty_tables)} table(s) with no columns",
            details=", ".join(t.name for t in empty_tables),
        ))

    # ── Calculate score ───────────────────────────────────────────
    total_deduction = sum(deductions.values())
    score = max(0, 100 - total_deduction)
    total_checks = 6
    passed_checks = total_checks - len([i for i in issues if i.severity in ("warning", "error")])

    return HealthScore(
        score=score,
        total_checks=total_checks,
        passed_checks=passed_checks,
        issues=issues,
        breakdown=deductions,
    )


def calculate_workspace_health(
    lineages: list[LineageResponse],
) -> HealthScore:
    """Calculate aggregate health for an entire workspace."""
    all_issues: list[HealthIssue] = []
    total_score = 0
    count = 0

    for lineage in lineages:
        model_health = calculate_model_health(lineage.model, lineage.reports)
        all_issues.extend(model_health.issues)
        total_score += model_health.score
        count += 1

    avg_score = round(total_score / count) if count > 0 else 0

    # Aggregate deductions by category
    breakdown: dict[str, int] = {}
    for issue in all_issues:
        breakdown.setdefault(issue.category, 0)
        if issue.severity == "error":
            breakdown[issue.category] += 3
        elif issue.severity == "warning":
            breakdown[issue.category] += 1

    return HealthScore(
        score=avg_score,
        total_checks=count * 6,
        passed_checks=count * 6 - len([i for i in all_issues if i.severity in ("warning", "error")]),
        issues=all_issues,
        breakdown=breakdown,
    )


def format_health_score(health: HealthScore, name: str = "") -> str:
    """Format health score as readable markdown."""
    lines: list[str] = []

    title = f"Health Score for {name}" if name else "Health Score"
    lines.append(f"# {title}\n")

    # Score bar
    filled = health.score // 5
    empty = 20 - filled
    bar = "█" * filled + "░" * empty
    lines.append(f"**Score: {health.score}/100**  {bar}\n")

    # Breakdown
    if health.breakdown:
        lines.append("**Deductions by category:**")
        for cat, points in sorted(health.breakdown.items()):
            if points > 0:
                lines.append(f"  - {cat.title()}: -{points} points")
        lines.append("")

    # Issues by severity
    errors = [i for i in health.issues if i.severity == "error"]
    warnings = [i for i in health.issues if i.severity == "warning"]
    infos = [i for i in health.issues if i.severity == "info"]

    if errors:
        lines.append("**❌ Errors:**")
        for issue in errors:
            lines.append(f"  - {issue.message}")
            if issue.details:
                lines.append(f"    *{issue.details}*")
        lines.append("")

    if warnings:
        lines.append("**⚠️ Warnings:**")
        for issue in warnings:
            lines.append(f"  - {issue.message}")
            if issue.details:
                lines.append(f"    *{issue.details}*")
        lines.append("")

    if infos:
        lines.append("**ℹ️ Info:**")
        for issue in infos:
            lines.append(f"  - {issue.message}")
        lines.append("")

    # Good news
    good_count = health.total_checks - len(errors) - len(warnings)
    if good_count > 0:
        lines.append(f"**✅ {good_count} check(s) passed**\n")

    # Recommendations
    if errors or warnings:
        lines.append("**📋 Recommendations:**")
        seen: set[str] = set()
        for issue in errors + warnings:
            if issue.details and issue.details not in seen:
                seen.add(issue.details)
                lines.append(f"  - {issue.details}")

    return "\n".join(lines)


def _get_used_table_names(reports: list[ReportInfo]) -> set[str]:
    """Get all table names referenced by any visual in any report."""
    used: set[str] = set()
    for report in reports:
        for page in report.pages:
            for visual in page.visuals:
                for fb in visual.field_bindings:
                    used.add(fb.table_name)
    return used


def _get_used_measures(reports: list[ReportInfo]) -> set[tuple[str, str]]:
    """Get all (table_name, measure_name) pairs used in visuals."""
    used: set[tuple[str, str]] = set()
    for report in reports:
        for page in report.pages:
            for visual in page.visuals:
                for fb in visual.field_bindings:
                    if fb.field_type == "measure":
                        used.add((fb.table_name, fb.field_name))
    return used
