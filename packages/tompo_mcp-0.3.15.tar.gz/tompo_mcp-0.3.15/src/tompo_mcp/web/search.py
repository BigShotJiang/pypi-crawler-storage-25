"""Natural-language query parser for TOMPo.

Handles common questions without an LLM by pattern-matching intents,
then querying the SQLite FTS index + lineage cache.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Optional

from tompo_mcp.core.governance import calculate_model_health
from tompo_mcp.core.models import LineageResponse
from tompo_mcp.db import store


# ── Intent Detection ──────────────────────────────────────────────────

@dataclass
class ParsedQuery:
    intent: str  # "search", "where_used", "unused", "health", "cross_ws", "list", "help"
    subject: str = ""  # the entity name the user is asking about
    entity_type: str = ""  # "column", "measure", "table", "dataset", "report", ""
    workspace: str = ""  # workspace filter if mentioned


_INTENT_PATTERNS: list[tuple[str, re.Pattern]] = [
    ("where_used", re.compile(
        r"(?:where|which|what)[\s\w]*(?:is|are|does)?\s+['\"]?(.+?)['\"]?\s+(?:used|referenced|consumed|appear)",
        re.IGNORECASE,
    )),
    ("where_used", re.compile(
        r"(?:show|find|get|trace)[\s\w]*(?:usage|usages|references|lineage)\s+(?:of|for)\s+['\"]?(.+?)['\"]?$",
        re.IGNORECASE,
    )),
    ("where_used", re.compile(
        r"(?:who|what|which)\s+(?:uses|consumes|references)\s+['\"]?(.+?)['\"]?",
        re.IGNORECASE,
    )),
    ("unused", re.compile(
        r"(?:show|find|list|get)[\s\w]*(?:unused|orphan|dead|unreferenced)\s+(\w+)",
        re.IGNORECASE,
    )),
    ("health", re.compile(
        r"(?:health|score|quality|governance)[\s\w]*(?:of|for)?\s*['\"]?(.+?)['\"]?$",
        re.IGNORECASE,
    )),
    ("cross_ws", re.compile(
        r"(?:cross[\s-]?workspace|external|shared)\s*(?:dependencies|links|reports)?",
        re.IGNORECASE,
    )),
    ("list", re.compile(
        r"(?:list|show|get)\s+(?:all\s+)?(\w+)",
        re.IGNORECASE,
    )),
]


def parse_question(text: str) -> ParsedQuery:
    """Parse a natural-language question into a structured intent."""
    text = text.strip()
    if not text:
        return ParsedQuery(intent="help")

    for intent, pattern in _INTENT_PATTERNS:
        m = pattern.search(text)
        if m:
            subject = m.group(1).strip() if m.lastindex and m.lastindex >= 1 else ""
            return ParsedQuery(intent=intent, subject=subject)

    # Fallback: treat as keyword search
    return ParsedQuery(intent="search", subject=text)


# ── Answer Generation ─────────────────────────────────────────────────

def answer(question: str) -> str:
    """Answer a natural-language question using the local index.

    Returns a markdown-formatted string.
    """
    q = parse_question(question)

    if q.intent == "help":
        return _help_text()
    if q.intent == "where_used":
        return _answer_where_used(q.subject)
    if q.intent == "unused":
        return _answer_unused(q.subject)
    if q.intent == "health":
        return _answer_health(q.subject)
    if q.intent == "cross_ws":
        return _answer_cross_workspace()
    if q.intent == "list":
        return _answer_list(q.subject)
    # Default: search
    return _answer_search(q.subject)


# ── Answer Implementations ────────────────────────────────────────────

def _answer_search(term: str) -> str:
    """Search the FTS index for a term."""
    results = store.search(term, limit=30)
    if not results:
        return f"No results found for **{term}**. Try indexing more workspaces or check the spelling."

    lines = [f"### Found {len(results)} result(s) for \"{term}\"\n"]
    for r in results:
        icon = {"column": "🔹", "measure": "🔸", "table": "📋", "dataset": "📊",
                "report": "📄", "workspace": "📁"}.get(r["entity_type"], "•")
        parent = f" in `{r['parent_name']}`" if r["parent_name"] else ""
        ws = f" — {r['workspace_name']}" if r["workspace_name"] else ""
        extra = ""
        if r["entity_type"] == "column" and r["extra"]:
            extra = f" ({r['extra']})"
        elif r["entity_type"] == "measure" and r["extra"]:
            expr_short = r["extra"][:80] + "..." if len(r["extra"]) > 80 else r["extra"]
            extra = f"\n  ```dax\n  {expr_short}\n  ```"
        lines.append(f"{icon} **{r['name']}** ({r['entity_type']}){parent}{ws}{extra}")

    return "\n\n".join(lines)


def _answer_where_used(name: str) -> str:
    """Find where a column/measure/table is used across visuals."""
    results = store.search(name, limit=20)
    if not results:
        return f"Could not find **{name}** in the index. Make sure lineage has been generated for the relevant workspace."

    # Get lineage for each matching dataset to find visual usages
    seen_datasets: set[str] = set()
    usage_lines: list[str] = []

    for r in results:
        ds_id = r["dataset_id"]
        if ds_id in seen_datasets:
            continue
        seen_datasets.add(ds_id)

        lineage = store.get_lineage(ds_id)
        if not lineage:
            continue

        usages = _find_usages_in_lineage(name, lineage)
        for u in usages:
            usage_lines.append(
                f"- 📄 **{u['report']}** → 📑 {u['page']} → 📈 {u['visual_type']}"
                f" — *{r['workspace_name']} / {lineage.model.name}*"
            )

    if not usage_lines:
        # Still show where it exists even if no visual usage
        lines = [f"### Where is \"{name}\" defined?\n"]
        for r in results:
            if r["entity_type"] in ("column", "measure", "table"):
                lines.append(f"- {r['entity_type'].title()} **{r['name']}** in table `{r['parent_name']}` "
                             f"— {r['workspace_name']}")
        lines.append("\n*No visual usage found. Generate lineage for the workspace to trace visual references.*")
        return "\n".join(lines)

    header = f"### \"{name}\" is used in {len(usage_lines)} visual(s)\n"
    return header + "\n".join(usage_lines)


def _answer_unused(entity_type: str) -> str:
    """Find unused tables/columns/measures."""
    all_lineage = store.get_all_lineage()
    if not all_lineage:
        return "No lineage data indexed yet. Generate lineage for a workspace first."

    unused_items: list[str] = []
    check_type = entity_type.lower().rstrip("s")  # "tables" -> "table"

    for ds_id, lineage in all_lineage.items():
        ws_row = None
        with store._connect() as conn:
            ws_row = conn.execute(
                "SELECT w.name FROM workspaces w JOIN datasets d ON d.workspace_id=w.id WHERE d.id=?",
                (ds_id,),
            ).fetchone()
        ws_name = ws_row["name"] if ws_row else "Unknown"

        # Use the governance engine to find issues
        health = calculate_model_health(lineage.model, lineage.reports)
        for issue in health.issues:
            if check_type in ("table", "") and "unused" in issue.message.lower() and "table" in issue.message.lower():
                unused_items.append(f"- {issue.message} — *{ws_name} / {lineage.model.name}*")
            if check_type == "measure" and "orphan" in issue.message.lower():
                unused_items.append(f"- {issue.message} — *{ws_name} / {lineage.model.name}*")

    if not unused_items:
        return f"No unused {entity_type} found across indexed models. 🎉"

    return f"### Found {len(unused_items)} unused {entity_type}\n" + "\n".join(unused_items)


def _answer_health(subject: str) -> str:
    """Show health score for a model or workspace."""
    all_lineage = store.get_all_lineage()
    if not all_lineage:
        return "No lineage data indexed yet. Generate lineage for a workspace first."

    # Try to match by name
    matched: list[tuple[str, LineageResponse]] = []
    for ds_id, lineage in all_lineage.items():
        if subject.lower() in lineage.model.name.lower():
            matched.append((ds_id, lineage))

    if not matched:
        return f"No model matching **{subject}** found in the index."

    lines = []
    for ds_id, lineage in matched:
        health = calculate_model_health(lineage.model, lineage.reports)
        bar = "█" * (health.score // 5) + "░" * (20 - health.score // 5)
        lines.append(f"### {lineage.model.name}: {health.score}/100 `{bar}`\n")
        for issue in health.issues:
            icon = {"error": "❌", "warning": "⚠️", "info": "ℹ️"}.get(issue.severity, "•")
            lines.append(f"{icon} {issue.message}")
        if not health.issues:
            lines.append("✅ All checks passed!")
        lines.append("")

    return "\n".join(lines)


def _answer_cross_workspace() -> str:
    """Show cross-workspace dependency summary."""
    links = store.get_cross_workspace_links()
    if not links:
        return "No cross-workspace dependencies found. Run a full portfolio scan first."

    # Group by model
    groups: dict[str, list[CrossWorkspaceLink]] = {}
    for link in links:
        key = f"{link.model_name} ({link.model_workspace_name})"
        groups.setdefault(key, []).append(link)

    lines = [f"### 🌐 {len(links)} Cross-Workspace Dependencies\n"]
    for model_key, model_links in sorted(groups.items()):
        lines.append(f"**📊 {model_key}** → {len(model_links)} external report(s)")
        for link in model_links:
            lines.append(f"  - 📄 {link.report_name} in *{link.report_workspace_name}*")
        lines.append("")

    return "\n".join(lines)


def _answer_list(subject: str) -> str:
    """List workspaces, datasets, or reports."""
    kind = subject.lower().rstrip("s")
    if kind in ("workspace", "ws"):
        items = store.get_workspaces()
        if not items:
            return "No workspaces indexed. Click **Build Index** first."
        lines = [f"### {len(items)} Workspaces\n"]
        for ws in items:
            lines.append(f"- 📁 {ws['name']}")
        return "\n".join(lines)

    if kind in ("dataset", "model", "semantic"):
        total = store.get_total_datasets()
        indexed = store.get_indexed_dataset_count()
        return f"**{total}** semantic models across all workspaces. **{indexed}** have deep lineage indexed."

    if kind in ("report",):
        total = store.get_total_reports()
        return f"**{total}** reports across all workspaces."

    return _answer_search(subject)


def _help_text() -> str:
    return """### Ask TOMPo — What can I ask?

**Search:**
- `DateOnly` — find all columns, measures, tables matching that name
- `Revenue` — search across all indexed workspaces

**Trace usage:**
- `Where is DateOnly used?` — find every visual referencing that column
- `Which reports use Revenue?` — trace a measure to reports/visuals

**Governance:**
- `Show unused tables` — find tables not referenced by any report
- `Health of ModelName` — get governance health score

**Cross-workspace:**
- `Show cross-workspace dependencies` — reports using models from other workspaces

**Lists:**
- `List workspaces` — show all indexed workspaces
- `List models` — count of semantic models
"""


# ── Helpers ───────────────────────────────────────────────────────────

def _find_usages_in_lineage(
    name: str, lineage: LineageResponse,
) -> list[dict[str, str]]:
    """Find all visuals in a lineage that reference a field name."""
    usages = []
    name_lower = name.lower()

    for report in lineage.reports:
        for page in report.pages:
            for visual in page.visuals:
                for binding in visual.field_bindings:
                    if name_lower in binding.field_name.lower() or name_lower in binding.table_name.lower():
                        usages.append({
                            "report": report.name,
                            "page": page.display_name or page.name,
                            "visual_type": visual.visual_type,
                            "visual_title": visual.title or "",
                        })
                        break  # one match per visual is enough
    return usages
