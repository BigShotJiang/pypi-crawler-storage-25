"""TOMPo Streamlit Web App v0.4 — Fabric Lineage Explorer.

One-page UI: workspace picker -> auto-scan -> cascaded dropdowns -> lineage tree.
No NLP. No tabs. Just filter, explore, trace.
"""

from __future__ import annotations

import asyncio
import json
import logging
import time
from pathlib import Path
from typing import Any

import streamlit as st

logger = logging.getLogger(__name__)

from tompo_mcp.auth import TokenProvider
from tompo_mcp.core.fabric_client import FabricClient
from tompo_mcp.core.models import LineageResponse
from tompo_mcp.core.scanner import (
    deep_scan_model,
)
from tompo_mcp.db import store

# ── Page Config ───────────────────────────────────────────────────────

st.set_page_config(
    page_title="TOMPo — Fabric Lineage Explorer",
    page_icon="🔍",
    layout="wide",
    initial_sidebar_state="collapsed",
)

# ── CSS — Microsoft Fluent Light Theme ────────────────────────────────

_CSS = """
<style>
    html, body, [class*="css"], .stMarkdown, .stText,
    section[data-testid="stSidebar"], .main {
        font-family: 'Segoe UI', -apple-system, BlinkMacSystemFont, sans-serif !important;
    }
    .stApp, [data-testid="stAppViewContainer"] {
        background-color: #faf9f8 !important;
        color: #323130 !important;
    }
    section[data-testid="stSidebar"] {
        background-color: #f3f2f1 !important;
        border-right: 1px solid #edebe9 !important;
    }
    .tompo-header {
        background: linear-gradient(135deg, #0078d4 0%, #005a9e 100%);
        color: #fff; padding: 16px 24px; border-radius: 8px;
        margin-bottom: 16px; display: flex; align-items: center;
        justify-content: space-between;
    }
    .tompo-header h1 { margin: 0; font-size: 22px; font-weight: 600; }
    .tompo-header .sub { font-size: 13px; opacity: .8; }
    .tree-model { color: #0078d4; font-weight: 600; }
    .tree-table { color: #038387; }
    .tree-report { color: #d13438; }
    .tree-page { color: #107c10; }
    .tree-visual { color: #ca5010; }
    .tree-column { color: #8764b8; }
    .tree-measure { color: #e3008c; }
    .cross-ws-badge {
        background: #fff4ce; color: #8a6914; font-size: 10px;
        padding: 1px 6px; border-radius: 3px; margin-left: 6px;
    }
    .scan-item-ok { color: #107c10; }
    .scan-item-skip { color: #ca5010; }
    .skip-table { width: 100%; border-collapse: collapse; font-size: 13px; }
    .skip-table th {
        background: #f3f2f1; color: #605e5c; text-align: left;
        padding: 6px 10px; border-bottom: 1px solid #edebe9;
    }
    .skip-table td {
        padding: 6px 10px; border-bottom: 1px solid #edebe9; color: #323130;
    }
    /* Streamlit overrides for light theme */
    .stMarkdown, .stText, p, span, label, .stSelectbox label,
    [data-testid="stMarkdownContainer"] {
        color: #323130 !important;
    }
    .stCheckbox label span { color: #323130 !important; }
    [data-testid="stMetricValue"] { color: #0078d4 !important; }
    [data-testid="stMetricLabel"] { color: #605e5c !important; }
    .stTextInput > div > div > input {
        background: #ffffff !important; color: #323130 !important;
        border: 1px solid #c8c6c4 !important;
    }
    .stSelectbox > div > div {
        background: #ffffff !important; color: #323130 !important;
    }
    .stButton > button {
        border: 1px solid #c8c6c4; border-radius: 4px;
    }
    .stButton > button[kind="primary"] {
        background-color: #0078d4 !important; color: #fff !important;
        border: none;
    }
    .stProgress > div > div > div {
        background-color: #0078d4 !important;
    }
    .stExpander {
        background: #ffffff; border: 1px solid #edebe9; border-radius: 4px;
    }
    /* hide default streamlit header/footer */
    #MainMenu, footer, header { visibility: hidden; }
</style>
"""
st.markdown(_CSS, unsafe_allow_html=True)


# ── State Initialization ──────────────────────────────────────────────

def _init_state():
    defaults = {
        "screen": "auto",
        "portfolio": None,
        "client": None,
        "stop_scan": False,
    }
    for k, v in defaults.items():
        if k not in st.session_state:
            st.session_state[k] = v

_init_state()


# ── Helpers ───────────────────────────────────────────────────────────

def _get_client() -> FabricClient:
    if st.session_state.client is None:
        tp = TokenProvider()
        st.session_state.client = FabricClient(tp)
    return st.session_state.client


def _run_async(coro):
    """Run an async coroutine from sync Streamlit code."""
    try:
        loop = asyncio.get_event_loop()
        if loop.is_running():
            import concurrent.futures
            with concurrent.futures.ThreadPoolExecutor() as pool:
                return pool.submit(lambda: asyncio.run(coro)).result()
        return loop.run_until_complete(coro)
    except RuntimeError:
        return asyncio.run(coro)


# ── Header ────────────────────────────────────────────────────────────

st.markdown("""
<div class="tompo-header">
    <div>
        <h1>🔍 TOMPo — Lineage Explorer</h1>
        <div class="sub">Trace from columns to visuals, across workspaces</div>
    </div>
</div>
""", unsafe_allow_html=True)


# ═══════════════════════════════════════════════════════════════════════
# RENDERING HELPERS  (must be defined before screen router)
# ═══════════════════════════════════════════════════════════════════════

def _render_field_lineage(
    field_name: str, field_type: str, table_name: str,
    lineage: LineageResponse,
):
    """Render inline lineage tree for a specific field down to visual depth."""
    usages: list[dict[str, str]] = []
    for report in lineage.reports:
        for page in report.pages:
            for visual in page.visuals:
                for fb in visual.field_bindings:
                    if fb.table_name == table_name and fb.field_name == field_name:
                        usages.append({
                            "report": report.name,
                            "page": page.display_name,
                            "visual_type": visual.visual_type,
                            "visual_title": visual.title or visual.visual_type,
                        })

    if not usages:
        st.markdown(
            "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"
            "<span style='color:#a19f9d;font-size:12px;font-style:italic'>"
            "No visual usage found</span>",
            unsafe_allow_html=True,
        )
        return

    rmap: dict[str, dict[str, list[str]]] = {}
    for u in usages:
        rmap.setdefault(u["report"], {}).setdefault(u["page"], []).append(
            u["visual_title"]
        )

    indent2 = "&nbsp;" * 8
    indent3 = "&nbsp;" * 12
    indent4 = "&nbsp;" * 16

    for rname, pages in rmap.items():
        cross = ""
        if "(" in rname and rname.endswith(")"):
            cross = "<span class='cross-ws-badge'>cross-workspace</span>"
        st.markdown(
            f"{indent2}<span class='tree-report'>📄 {rname}</span>{cross}",
            unsafe_allow_html=True,
        )
        for pname, visuals in pages.items():
            st.markdown(
                f"{indent3}<span class='tree-page'>📑 {pname}</span>",
                unsafe_allow_html=True,
            )
            for v in visuals:
                st.markdown(
                    f"{indent4}<span class='tree-visual'>📊 {v}</span>",
                    unsafe_allow_html=True,
                )


def _render_d3_tree(lineage: LineageResponse):
    """Embed the full D3 interactive lineage tree."""
    try:
        tpl_path = Path(__file__).parent.parent / "viz" / "template.html"
        if not tpl_path.exists():
            st.warning("D3 template not found.")
            return
        tpl = tpl_path.read_text(encoding="utf-8")
        data_json = json.dumps(lineage.model_dump(), default=str)
        html = tpl.replace("__LINEAGE_DATA_PLACEHOLDER__", data_json)

        import streamlit.components.v1 as components
        components.html(html, height=700, scrolling=True)
    except Exception as e:
        st.error(f"Failed to render D3 tree: {e}")


# ═══════════════════════════════════════════════════════════════════════
# SCREEN ROUTER
# ═══════════════════════════════════════════════════════════════════════

def _determine_screen() -> str:
    """Pick the right screen based on DB + session state."""
    forced = st.session_state.get("screen", "auto")
    if forced in ("picker", "scanning"):
        return forced
    selected = store.get_selected_workspaces()
    if selected and store.get_indexed_dataset_count() > 0:
        return "explore"
    if store.get_workspace_count() > 0:
        return "picker"
    return "loading"

screen = _determine_screen()


# ═══════════════════════════════════════════════════════════════════════
# SCREEN 1: DISCOVERY — Quick workspace list from API
# ═══════════════════════════════════════════════════════════════════════

if screen == "loading":
    st.markdown("### 🔍 Discovering your Power BI tenant...")
    status_text = st.empty()
    status_text.markdown("Connecting to Power BI APIs...")

    try:
        client = _get_client()

        # Single API call — just list workspace names/ids
        workspaces_raw = _run_async(client.list_workspaces())

        # Persist to DB
        store.save_workspaces([{"id": w["id"], "name": w["name"]} for w in workspaces_raw])
        store.set_meta("last_workspace_scan", str(time.time()))

        status_text.markdown(f"✅ Found **{len(workspaces_raw)}** workspaces")
        time.sleep(0.5)
        st.session_state.screen = "picker"
        st.rerun()

    except Exception as e:
        st.error(f"❌ Failed to connect: {e}")
        st.info("Make sure you ran `az login` before launching TOMPo.")
        st.stop()


# ═══════════════════════════════════════════════════════════════════════
# SCREEN 2: WORKSPACE PICKER
# ═══════════════════════════════════════════════════════════════════════

elif screen == "picker":
    all_ws = store.get_workspaces()
    st.markdown("### Select workspaces to scan for lineage")
    st.markdown(
        f"Found **{len(all_ws)}** workspaces you have access to. "
        "Pick the ones you want to deep-scan."
    )

    # Filter
    filter_text = st.text_input(
        "🔍 Filter workspaces", "", placeholder="Type to filter by name...",
        key="ws_filter",
    )
    filtered = (
        [w for w in all_ws if filter_text.lower() in w["name"].lower()]
        if filter_text else all_ws
    )

    # Select/clear
    btn_cols = st.columns([1, 1, 6])
    with btn_cols[0]:
        select_all = st.button("Select All")
    with btn_cols[1]:
        clear_all = st.button("Clear All")

    prev_selected = set(store.get_selected_workspaces())
    if select_all:
        init_set = {w["id"] for w in filtered}
    elif clear_all:
        init_set: set[str] = set()
    else:
        init_set = prev_selected if prev_selected else set()

    selected_ids: set[str] = set()
    cols = st.columns(2)
    for i, w in enumerate(filtered):
        with cols[i % 2]:
            if st.checkbox(
                w["name"],
                value=w["id"] in init_set,
                key=f"ws_{w['id']}",
            ):
                selected_ids.add(w["id"])

    # Summary
    st.markdown("---")
    st.markdown(f"**Selected: {len(selected_ids)} workspaces**")

    # Confirm
    if st.button(
        f"🚀 Start Scan ({len(selected_ids)} workspaces)",
        type="primary",
        disabled=len(selected_ids) == 0,
    ):
        store.save_selected_workspaces(list(selected_ids))
        store.clear_all_skipped()
        st.session_state.screen = "scanning"
        st.session_state.stop_scan = False
        st.rerun()

    # Option to go to explore if data exists
    if store.get_indexed_dataset_count() > 0:
        st.markdown("---")
        if st.button("🔍 Skip — Explore existing data"):
            st.session_state.screen = "explore"
            st.rerun()


# ═══════════════════════════════════════════════════════════════════════
# SCREEN 3: SCANNING WITH LIVE STATUS + STOP
# ═══════════════════════════════════════════════════════════════════════

elif screen == "scanning":
    st.markdown("### 🔄 Scanning Lineage (visual depth)")

    selected_ws = store.get_selected_workspaces()
    if not selected_ws:
        st.session_state.screen = "picker"
        st.rerun()

    # Stop button at top
    if st.button("⏹ Stop Scan"):
        st.session_state.stop_scan = True

    progress_bar = st.progress(0)
    status_text = st.empty()
    log_container = st.container()
    totals_container = st.empty()

    try:
        client = _get_client()

        # Phase 1: Fetch items (datasets/reports) for selected workspaces — PARALLEL
        status_text.markdown("📂 Fetching models and reports for selected workspaces...")
        ws_names = {w["id"]: w["name"] for w in store.get_workspaces()}

        async def _fetch_items():
            sem = asyncio.Semaphore(10)  # max 10 concurrent workspace list calls
            items_list: list[tuple[str, str, list]] = []

            async def _fetch_one(ws_id: str):
                ws_name = ws_names.get(ws_id, ws_id)
                async with sem:
                    try:
                        items = await client.get_workspace_items(ws_id)
                        datasets = items.get("datasets", [])
                        reports = items.get("reports", [])
                        store.save_workspace_items(ws_id, datasets, reports)
                        return (ws_id, ws_name, datasets)
                    except Exception as exc:
                        logger.warning("Failed to list items for %s: %s", ws_name, exc)
                        return (ws_id, ws_name, [])

            results = await asyncio.gather(*[_fetch_one(ws_id) for ws_id in selected_ws])
            return list(results)

        items_list = _run_async(_fetch_items())
        status_text.markdown(f"📂 Found items in **{len(items_list)}** workspaces")

        # Phase 2: Build scan list from fetched datasets
        scan_list: list[tuple[str, str, str, str]] = []  # ws_id, ws_name, ds_id, ds_name
        for ws_id, ws_name, datasets in items_list:
            for ds in datasets:
                scan_list.append((ws_id, ws_name, ds.get("id", ""), ds.get("name", "")))

        total = len(scan_list)
        completed_items: list[dict[str, Any]] = []
        skipped_items: list[dict[str, Any]] = []
        counters = {"done": 0, "tables": 0, "cols": 0, "meas": 0, "reports": 0, "visuals": 0}

        async def _scan_all():
            sem = asyncio.Semaphore(3)  # 3 models in parallel
            results: dict[str, LineageResponse] = {}

            async def _scan_one(ws_id, ws_name, ds_id, ds_name):
                if st.session_state.stop_scan:
                    return
                async with sem:
                    if st.session_state.stop_scan:
                        return
                    try:
                        lineage = await deep_scan_model(client, ws_id, ds_id, ds_name)
                        if lineage:
                            results[ds_id] = lineage
                            store.save_lineage(ds_id, lineage)

                            nt = len(lineage.model.tables)
                            nc = sum(len(t.columns) for t in lineage.model.tables)
                            nm = sum(len(t.measures) for t in lineage.model.tables)
                            nr = len(lineage.reports)
                            nv = sum(
                                len(v.field_bindings)
                                for r in lineage.reports for p in r.pages for v in p.visuals
                            )
                            counters["tables"] += nt; counters["cols"] += nc
                            counters["meas"] += nm; counters["reports"] += nr
                            counters["visuals"] += nv

                            completed_items.append({
                                "name": ds_name, "workspace": ws_name,
                                "tables": nt, "reports": nr, "visuals": nv,
                            })
                        else:
                            skipped_items.append({
                                "id": ds_id, "name": ds_name,
                                "workspace_id": ws_id, "workspace_name": ws_name,
                                "reason": "No definition (permission denied or unsupported)",
                            })
                            store.save_skipped_item(
                                ds_id, ds_name, "dataset", ws_id, ws_name,
                                "No definition available",
                            )
                    except Exception as exc:
                        reason = str(exc)[:120]
                        skipped_items.append({
                            "id": ds_id, "name": ds_name,
                            "workspace_id": ws_id, "workspace_name": ws_name,
                            "reason": reason,
                        })
                        store.save_skipped_item(
                            ds_id, ds_name, "dataset", ws_id, ws_name, reason,
                        )

                    counters["done"] += 1

            await asyncio.gather(*[
                _scan_one(ws_id, ws_name, ds_id, ds_name)
                for ws_id, ws_name, ds_id, ds_name in scan_list
            ])
            return results

        results = _run_async(_scan_all())

        # Final progress
        done = counters["done"]
        progress_bar.progress(1.0 if not st.session_state.stop_scan else done / max(total, 1))

        if st.session_state.stop_scan:
            st.warning(
                f"⚠️ Scan stopped at **{done}/{total}** models. "
                "You can explore what's been scanned or resume later."
            )
        else:
            st.success(f"✅ Scan complete! **{len(completed_items)}** models scanned.")

        # Totals
        st.markdown(
            f"📊 **{counters['cols']}** columns · **{counters['meas']}** measures · "
            f"**{counters['reports']}** reports · **{counters['visuals']}** visual bindings mapped"
        )

        # Completed log
        if completed_items:
            with st.expander(f"✅ {len(completed_items)} models scanned", expanded=False):
                for it in completed_items:
                    st.markdown(
                        f"✅ **{it['name']}** — "
                        f"{it['tables']} tables · {it['reports']} reports · "
                        f"{it['visuals']} visuals — *{it['workspace']}*"
                    )

        # Skipped log
        if skipped_items:
            with st.expander(f"⚠️ {len(skipped_items)} items skipped", expanded=True):
                for it in skipped_items:
                    st.markdown(
                        f"⚠️ **{it['name']}** — {it['reason']} — *{it['workspace_name']}*"
                    )
                st.info(
                    "💡 For confidential items: ask your admin to downgrade the "
                    "sensitivity label, then click ⟳ Sync to retry."
                )

        # Navigation
        nav_cols = st.columns([2, 2, 4])
        with nav_cols[0]:
            if st.button("🔍 Explore Now →", type="primary"):
                st.session_state.screen = "explore"
                st.rerun()
        with nav_cols[1]:
            if st.session_state.stop_scan and counters["done"] < total:
                if st.button("▶️ Resume Scan"):
                    st.session_state.stop_scan = False
                    st.rerun()

    except Exception as e:
        st.error(f"❌ Scan failed: {e}")
        st.info("Check your `az login` session and try again.")


# ═══════════════════════════════════════════════════════════════════════
# SCREEN 4: EXPLORE — Cascaded Dropdowns + Lineage Tree
# ═══════════════════════════════════════════════════════════════════════

elif screen == "explore":

    # ── Status bar ────────────────────────────────────────────────────
    stats = store.get_scan_stats()
    last_scan = store.get_last_scan_time()

    scols = st.columns([1, 1, 1, 1, 2])
    with scols[0]:
        st.metric("Workspaces", stats["workspaces"])
    with scols[1]:
        st.metric("Models", stats["models"])
    with scols[2]:
        st.metric("Reports", stats["reports"])
    with scols[3]:
        st.metric("Lineage indexed", stats["lineage"])
    with scols[4]:
        c1, c2, c3 = st.columns(3)
        with c1:
            st.caption(f"Synced: {last_scan or 'Never'}")
        with c2:
            if st.button("⟳ Sync"):
                # Incremental rescan
                st.session_state.screen = "scanning"
                st.session_state.stop_scan = False
                st.rerun()
        with c3:
            if st.button("⚙️ Workspaces"):
                st.session_state.screen = "picker"
                st.rerun()

    st.markdown("---")

    # ── Bidirectional Cascaded Dropdown Filters ───────────────────────
    # Any dropdown can be the entry point. Others auto-narrow.

    # Load ALL fields across all scanned workspaces (unfiltered)
    all_fields = store.get_all_fields("", "")
    all_ws = store.get_workspaces()
    sel_ids = set(store.get_selected_workspaces())
    avail_ws = [w for w in all_ws if w["id"] in sel_ids]

    # Build lookup structures
    ws_id_to_name = {w["id"]: w["name"] for w in avail_ws}
    ws_name_to_id = {w["name"]: w["id"] for w in avail_ws}

    # ── Type filter (independent — narrows everything)
    type_choice = st.session_state.get("flt_type", "All")
    if type_choice != "All":
        type_filtered = [f for f in all_fields if f["entity_type"].lower() == type_choice.lower()]
    else:
        type_filtered = all_fields

    # Get unique field names, workspace names, model names from the full set
    all_field_names = sorted(set(f["name"] for f in type_filtered))
    all_ws_names = sorted(set(
        f.get("workspace_name", "") for f in type_filtered if f.get("workspace_name")
    ))
    all_model_names_map: dict[str, str] = {}  # display_label -> model_id
    for f in type_filtered:
        ds_id = f.get("dataset_id", "")
        ds_name = f.get("dataset_name", ds_id)
        ws_name = f.get("workspace_name", "")
        label = f"{ds_name} ({ws_name})" if ws_name else ds_name
        all_model_names_map[label] = ds_id

    fcols = st.columns(4)

    # Field / Measure — can be selected first to narrow everything
    with fcols[2]:
        field_opts = ["All"] + all_field_names
        field_choice = st.selectbox("Field / Measure", field_opts, key="flt_field")

    # Type
    with fcols[3]:
        type_choice = st.selectbox("Type", ["All", "Column", "Measure"], key="flt_type")

    # If field is chosen, narrow workspace and model options to those containing it
    if field_choice != "All":
        field_matches = [f for f in type_filtered if f["name"] == field_choice]
        ws_names_with_field = sorted(set(
            f.get("workspace_name", "") for f in field_matches if f.get("workspace_name")
        ))
        model_map_with_field: dict[str, str] = {}
        for f in field_matches:
            ds_id = f.get("dataset_id", "")
            ds_name = f.get("dataset_name", ds_id)
            ws_name = f.get("workspace_name", "")
            label = f"{ds_name} ({ws_name})" if ws_name else ds_name
            model_map_with_field[label] = ds_id
    else:
        ws_names_with_field = all_ws_names
        model_map_with_field = all_model_names_map

    # Workspace
    with fcols[0]:
        ws_opts = ["All"] + ws_names_with_field
        ws_choice = st.selectbox("Workspace", ws_opts, key="flt_ws")
        chosen_ws_id = ws_name_to_id.get(ws_choice, "") if ws_choice != "All" else ""

    # If workspace is chosen, further narrow models
    if chosen_ws_id:
        model_map_filtered = {
            label: mid for label, mid in model_map_with_field.items()
            if f"({ws_id_to_name.get(chosen_ws_id, '')})" in label
            or not any(f"({n})" in label for n in ws_id_to_name.values())
        }
        # Re-filter more precisely using fields
        ws_model_ids = set()
        check_fields = [f for f in type_filtered if f.get("workspace_id") == chosen_ws_id]
        if field_choice != "All":
            check_fields = [f for f in check_fields if f["name"] == field_choice]
        for f in check_fields:
            ds_id = f.get("dataset_id", "")
            ds_name = f.get("dataset_name", ds_id)
            ws_name = f.get("workspace_name", "")
            label = f"{ds_name} ({ws_name})" if ws_name else ds_name
            model_map_filtered[label] = ds_id
            ws_model_ids.add(ds_id)
        # Only keep models in this workspace
        model_map_filtered = {
            label: mid for label, mid in model_map_filtered.items()
            if mid in ws_model_ids
        }
    else:
        model_map_filtered = model_map_with_field

    # Model
    with fcols[1]:
        model_labels = sorted(model_map_filtered.keys())
        model_opts = ["All"] + model_labels
        model_choice = st.selectbox("Semantic Model", model_opts, key="flt_model")
        chosen_model_id = model_map_filtered.get(model_choice, "") if model_choice != "All" else ""

    # ── Build final matched results ───────────────────────────────────

    matched: list[dict[str, Any]] = []

    for f in type_filtered:
        # Type filter already applied
        if field_choice != "All" and f["name"] != field_choice:
            continue
        if chosen_ws_id and f.get("workspace_id") != chosen_ws_id:
            continue
        if chosen_model_id and f.get("dataset_id") != chosen_model_id:
            continue
        matched.append(f)

    # Only show results if at least one filter is active
    has_filter = (field_choice != "All" or chosen_ws_id or chosen_model_id or type_choice != "All")

    # ── Render ────────────────────────────────────────────────────────

    if has_filter and matched:
        # Group: workspace -> dataset_id -> fields
        groups: dict[str, dict[str, list[dict]]] = {}
        for f in matched:
            ws = f.get("workspace_name", "Unknown")
            ds = f.get("dataset_id", "")
            groups.setdefault(ws, {}).setdefault(ds, []).append(f)

        st.markdown(
            f"**{len(matched)} result(s)** across "
            f"**{len(groups)} workspace(s)**"
        )

        for ws_name, ds_map in sorted(groups.items()):
            with st.expander(f"📁 {ws_name}", expanded=True):
                for ds_id, flist in ds_map.items():
                    lineage = store.get_lineage(ds_id)
                    model_name = lineage.model.name if lineage else ds_id

                    st.markdown(
                        f"<span class='tree-model'>📊 {model_name}</span>",
                        unsafe_allow_html=True,
                    )

                    for f in flist:
                        icon = "🔹" if f["entity_type"] == "column" else "🔸"
                        extra = ""
                        if f.get("extra") and f["entity_type"] == "column":
                            extra = f" ({f['extra']})"
                        tbl = f.get("parent_name", "")
                        st.markdown(
                            f"&nbsp;&nbsp;&nbsp;&nbsp;{icon} **{f['name']}**{extra}"
                            f" — `{tbl}`",
                        )

                        # Inline lineage tree
                        if lineage:
                            _render_field_lineage(
                                f["name"], f["entity_type"], tbl, lineage,
                            )

    elif has_filter and chosen_ws_id and not chosen_model_id and field_choice == "All":
        # No field filter — show workspace model overview
        ws_models = store.get_datasets_for_workspace(chosen_ws_id)
        st.markdown(f"**{len(ws_models)} model(s)** in this workspace")
        for m in ws_models:
            lineage = store.get_lineage(m["id"])
            if lineage:
                nt = len(lineage.model.tables)
                nr = len(lineage.reports)
                st.markdown(f"📊 **{m['name']}** — {nt} tables · {nr} reports")
            else:
                st.markdown(f"📊 **{m['name']}** — *lineage not yet scanned*")

    elif has_filter and not matched:
        st.info("No results match the current filters.")

    else:
        # No filter — overview
        st.markdown("**Select a workspace, model, or field above to explore lineage.**")
        st.markdown("")
        sel_ws_ids = set(store.get_selected_workspaces())
        scanned_ws = [w for w in store.get_workspaces() if w["id"] in sel_ws_ids]
        for w in scanned_ws[:25]:
            ds = store.get_datasets_for_workspace(w["id"])
            rp = store.get_reports_for_workspace(w["id"])
            st.markdown(f"📁 **{w['name']}** — {len(ds)} models · {len(rp)} reports")
        if len(scanned_ws) > 25:
            st.caption(f"… and {len(scanned_ws) - 25} more workspaces")

    # ── D3 Interactive Tree ───────────────────────────────────────────

    if chosen_model_id:
        lineage = store.get_lineage(chosen_model_id)
        if lineage:
            st.markdown("---")
            if st.button("🌳 Open Interactive Lineage Tree (D3)"):
                _render_d3_tree(lineage)

    # ── Skipped Items ─────────────────────────────────────────────────

    skipped = store.get_skipped_items()
    if skipped:
        st.markdown("---")
        with st.expander(f"⚠️ {len(skipped)} items skipped during scan", expanded=False):
            header = "<table class='skip-table'><tr><th>Model</th><th>Workspace</th><th>Reason</th></tr>"
            rows = "".join(
                f"<tr><td>{s['name']}</td><td>{s['workspace_name']}</td><td>{s['reason']}</td></tr>"
                for s in skipped
            )
            st.markdown(header + rows + "</table>", unsafe_allow_html=True)
            st.info(
                "💡 For confidential items: ask your admin to downgrade the "
                "sensitivity label, then click ⟳ Sync to retry."
            )


