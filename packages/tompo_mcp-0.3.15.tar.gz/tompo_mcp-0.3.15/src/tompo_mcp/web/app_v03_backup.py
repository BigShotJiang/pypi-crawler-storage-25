"""TOMPo Streamlit Web App v0.3 — Fabric Lineage Intelligence.

Microsoft Fluent-style UI with persistent SQLite index,
search-first UX, and natural-language Ask TOMPo chat.
"""

from __future__ import annotations

import asyncio
import json
import os
import time
from typing import Any

import streamlit as st

from tompo_mcp.auth import TokenProvider
from tompo_mcp.core.fabric_client import FabricClient
from tompo_mcp.core.governance import calculate_model_health
from tompo_mcp.core.models import LineageResponse
from tompo_mcp.core.scanner import (
    CrossWorkspaceLink,
    PortfolioScan,
    WorkspaceSummary,
    deep_scan_model,
)
from tompo_mcp.db import store
from tompo_mcp.web.search import answer as ask_tompo_answer

# ── Page Config ───────────────────────────────────────────────────────

st.set_page_config(
    page_title="TOMPo — Fabric Lineage Intelligence",
    page_icon="🔍",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Microsoft Fluent CSS ──────────────────────────────────────────────

st.markdown("""
<style>
    /* ══════════════════════════════════════════════════════════════════
       Microsoft Fluent UI Dark Theme — Azure Portal / Fabric style
       ══════════════════════════════════════════════════════════════════ */

    /* ── Foundation ── */
    html, body, [class*="css"], .stMarkdown, .stText,
    section[data-testid="stSidebar"], .main {
        font-family: 'Segoe UI', -apple-system, BlinkMacSystemFont, sans-serif !important;
    }

    /* ── Page background — Fabric dark ── */
    .stApp, [data-testid="stAppViewContainer"] {
        background-color: #1b1a19 !important;
    }

    /* ── Sidebar — Azure Portal left nav ── */
    section[data-testid="stSidebar"] {
        background-color: #252423 !important;
        border-right: 1px solid #323130 !important;
    }
    section[data-testid="stSidebar"] [data-testid="stSidebarContent"] {
        background-color: #252423 !important;
    }
    section[data-testid="stSidebar"] .stMarkdown h2,
    section[data-testid="stSidebar"] .stMarkdown h3 {
        color: #ffffff !important;
        font-weight: 600 !important;
        font-size: 1rem !important;
    }
    section[data-testid="stSidebar"] .stMarkdown p,
    section[data-testid="stSidebar"] .stCaption,
    section[data-testid="stSidebar"] label {
        color: #d2d0ce !important;
    }
    section[data-testid="stSidebar"] hr {
        border-color: #3b3a39 !important;
    }

    /* Sidebar radio — Azure left-nav style */
    section[data-testid="stSidebar"] [role="radiogroup"] {
        gap: 0 !important;
    }
    section[data-testid="stSidebar"] [role="radiogroup"] label {
        background: transparent !important;
        border-radius: 4px !important;
        padding: 8px 12px !important;
        margin: 1px 0 !important;
        cursor: pointer !important;
        transition: background 0.1s !important;
        color: #d2d0ce !important;
        font-weight: 400 !important;
        font-size: 0.9rem !important;
    }
    section[data-testid="stSidebar"] [role="radiogroup"] label:hover {
        background: #3b3a39 !important;
    }
    section[data-testid="stSidebar"] [role="radiogroup"] label[data-checked="true"],
    section[data-testid="stSidebar"] [role="radiogroup"] label:has(input:checked) {
        background: #0078d4 !important;
        color: #ffffff !important;
        font-weight: 600 !important;
    }
    /* Hide radio circles */
    section[data-testid="stSidebar"] [role="radiogroup"] input[type="radio"] {
        display: none !important;
    }
    section[data-testid="stSidebar"] [role="radiogroup"] [data-testid="stMarkdownContainer"] {
        pointer-events: none;
    }

    /* Sidebar selectbox */
    section[data-testid="stSidebar"] [data-baseweb="select"] > div {
        background-color: #1b1a19 !important;
        border-color: #484644 !important;
        color: #d2d0ce !important;
    }

    /* ── Main content ── */
    .main .block-container {
        padding-top: 1.5rem !important;
        max-width: 1200px !important;
    }

    /* ── Title bar — Azure service header ── */
    .tompo-titlebar {
        background: linear-gradient(135deg, #0078d4 0%, #005a9e 100%) !important;
        color: white !important;
        padding: 1.5rem 2rem !important;
        border-radius: 6px !important;
        margin-bottom: 1.5rem !important;
        box-shadow: 0 2px 8px rgba(0,120,212,0.3) !important;
    }
    .tompo-titlebar h1 {
        margin: 0 !important; font-size: 1.4rem !important;
        font-weight: 600 !important; color: white !important;
    }
    .tompo-titlebar p {
        margin: 0.3rem 0 0 0 !important; opacity: 0.9 !important;
        font-size: 0.88rem !important; color: white !important;
    }

    /* ── Stat cards — Fabric metric tiles ── */
    .stat-row {
        display: flex; gap: 12px; margin-bottom: 1.5rem; flex-wrap: wrap;
    }
    .stat-card {
        flex: 1; min-width: 140px;
        background: #292827 !important;
        border: 1px solid #3b3a39 !important;
        border-radius: 6px !important;
        padding: 1.2rem 1.4rem !important;
        text-align: left;
        box-shadow: 0 2px 4px rgba(0,0,0,0.2) !important;
    }
    .stat-card .stat-value {
        font-size: 2rem; font-weight: 700; color: #60cdff;
        line-height: 1.2;
    }
    .stat-card .stat-label {
        font-size: 0.75rem; color: #a19f9d; text-transform: uppercase;
        letter-spacing: 0.8px; margin-top: 4px; font-weight: 600;
    }

    /* ── Section headers — Azure blade titles ── */
    .section-header {
        font-size: 1rem !important;
        font-weight: 600 !important;
        color: #ffffff !important;
        border-bottom: 2px solid #0078d4 !important;
        padding-bottom: 8px !important;
        margin: 1.5rem 0 1rem 0 !important;
    }

    /* ── Index banners — Fluent message bars ── */
    .index-banner {
        border-radius: 4px; padding: 10px 14px;
        font-size: 0.85rem; margin-bottom: 10px;
        font-weight: 500;
    }
    .index-banner.ok {
        background: #0e3b2e !important; border: 1px solid #107c10 !important;
        color: #92e09d !important;
    }
    .index-banner.stale {
        background: #3d3022 !important; border: 1px solid #ca5010 !important;
        color: #fdcfb4 !important;
    }
    .index-banner.empty {
        background: #3b1e20 !important; border: 1px solid #d13438 !important;
        color: #f4b8ba !important;
    }

    /* ── Buttons — Fluent primary & secondary ── */
    .stButton > button {
        font-family: 'Segoe UI', sans-serif !important;
        font-weight: 600 !important;
        border-radius: 4px !important;
        font-size: 0.85rem !important;
        padding: 6px 16px !important;
        transition: all 0.1s !important;
    }
    /* Primary button */
    .stButton > button[kind="primary"],
    .stButton > button[data-testid="stBaseButton-primary"] {
        background-color: #0078d4 !important;
        border: 1px solid #0078d4 !important;
        color: white !important;
    }
    .stButton > button[kind="primary"]:hover,
    .stButton > button[data-testid="stBaseButton-primary"]:hover {
        background-color: #106ebe !important;
        border-color: #106ebe !important;
    }
    /* Secondary button */
    .stButton > button[kind="secondary"],
    .stButton > button[data-testid="stBaseButton-secondary"] {
        background-color: transparent !important;
        border: 1px solid #605e5c !important;
        color: #d2d0ce !important;
    }
    .stButton > button[kind="secondary"]:hover,
    .stButton > button[data-testid="stBaseButton-secondary"]:hover {
        background-color: #3b3a39 !important;
        border-color: #8a8886 !important;
    }

    /* ── Expanders — Fabric-style ── */
    details[data-testid="stExpander"] {
        background-color: #292827 !important;
        border: 1px solid #3b3a39 !important;
        border-radius: 4px !important;
        margin-bottom: 4px !important;
    }
    details[data-testid="stExpander"] summary {
        color: #d2d0ce !important;
        font-weight: 600 !important;
        font-size: 0.9rem !important;
    }
    details[data-testid="stExpander"] summary:hover {
        color: #ffffff !important;
    }

    /* ── Chat input ── */
    [data-testid="stChatInput"] textarea {
        background-color: #292827 !important;
        border: 1px solid #484644 !important;
        color: #ffffff !important;
        border-radius: 4px !important;
    }
    [data-testid="stChatInput"] textarea:focus {
        border-color: #0078d4 !important;
        box-shadow: 0 0 0 1px #0078d4 !important;
    }

    /* ── Text inputs ── */
    .stTextInput input {
        background-color: #292827 !important;
        border: 1px solid #484644 !important;
        color: #ffffff !important;
        border-radius: 4px !important;
    }
    .stTextInput input:focus {
        border-color: #0078d4 !important;
        box-shadow: 0 0 0 1px #0078d4 !important;
    }

    /* ── Health bar ── */
    .health-big { text-align: center; margin: 1rem 0; }
    .health-big .score { font-size: 3.5rem; font-weight: 700; line-height: 1; }
    .health-big .max { font-size: 1.5rem; color: #a19f9d; }
    .health-bar-track {
        background: #3b3a39; border-radius: 2px; height: 8px;
        margin: 0.5rem auto; max-width: 300px;
    }
    .health-bar-fill { height: 8px; border-radius: 2px; }

    /* ── Tabs — Fabric pivot style ── */
    .stTabs [data-baseweb="tab-list"] {
        gap: 0 !important; border-bottom: 1px solid #3b3a39 !important;
        background: transparent !important;
    }
    .stTabs [data-baseweb="tab"] {
        font-family: 'Segoe UI', sans-serif !important;
        font-weight: 600 !important; font-size: 0.85rem !important;
        color: #a19f9d !important;
        padding: 10px 16px !important;
        border-bottom: 2px solid transparent !important;
    }
    .stTabs [aria-selected="true"] {
        color: #60cdff !important;
        border-bottom-color: #0078d4 !important;
    }

    /* ── Markdown in main area ── */
    .main .stMarkdown h3 { color: #ffffff !important; }
    .main .stMarkdown p, .main .stMarkdown li { color: #d2d0ce !important; }
    .main .stMarkdown code { background: #3b3a39 !important; color: #60cdff !important; }
    .main .stCaption { color: #a19f9d !important; }

    /* ── Alerts — Fluent message bars ── */
    .stAlert [data-testid="stAlertContentInfo"] {
        background: #002b50 !important; color: #87ceeb !important;
    }

    /* ── Progress bar ── */
    [data-testid="stProgress"] > div > div {
        background-color: #0078d4 !important;
    }

    /* ── Download buttons ── */
    .stDownloadButton > button {
        background-color: #292827 !important;
        border: 1px solid #484644 !important;
        color: #60cdff !important;
    }
    .stDownloadButton > button:hover {
        background-color: #3b3a39 !important;
    }

    /* ── Metrics ── */
    [data-testid="stMetricValue"] { color: #60cdff !important; }
    [data-testid="stMetricLabel"] { color: #a19f9d !important; }

    /* ── Hide branding ── */
    footer { visibility: hidden !important; }
    #MainMenu { visibility: hidden !important; }
    header[data-testid="stHeader"] { background: #1b1a19 !important; }
</style>
""", unsafe_allow_html=True)


# ── Helpers ───────────────────────────────────────────────────────────

def _run_async(coro):
    """Run async function in sync context."""
    try:
        loop = asyncio.get_event_loop()
        if loop.is_running():
            import concurrent.futures
            with concurrent.futures.ThreadPoolExecutor() as pool:
                return pool.submit(asyncio.run, coro).result()
        return loop.run_until_complete(coro)
    except RuntimeError:
        return asyncio.run(coro)


def _get_client() -> FabricClient:
    if "client" not in st.session_state:
        tp = TokenProvider()
        st.session_state["client"] = FabricClient(tp)
    return st.session_state["client"]


def _score_color(score: int) -> str:
    if score >= 80:
        return "#107c10"
    if score >= 60:
        return "#ca5010"
    return "#d13438"


def _health_bar_html(score: int) -> str:
    color = _score_color(score)
    return (
        f'<div class="health-bar-track">'
        f'<div class="health-bar-fill" style="width:{score}%;background:{color}"></div>'
        f'</div>'
    )


def _render_lineage_view(lineage: LineageResponse, ws_name: str):
    """Render full lineage tree."""
    model = lineage.model
    st.markdown(f"### 🌳 {model.name}")
    st.caption(
        f"{ws_name} · {len(model.tables)} tables · "
        f"{len(lineage.reports)} reports · {len(model.relationships)} relationships"
    )

    tree = lineage.lineage_tree
    for table_node in tree.children:
        is_orphan = table_node.metadata.get("orphan", False)
        col_count = table_node.metadata.get("column_count", 0)
        meas_count = table_node.metadata.get("measure_count", 0)
        tag = " ⚠️ *unused*" if is_orphan else ""

        with st.expander(f"📋 {table_node.name} ({col_count} cols, {meas_count} measures){tag}"):
            if is_orphan:
                st.caption("Not referenced by any visual in any report.")
                continue
            for report_node in table_node.children:
                if report_node.node_type == "report":
                    st.markdown(f"**📄 {report_node.name}**")
                    for page_node in report_node.children:
                        if page_node.node_type == "page":
                            st.markdown(f"&nbsp;&nbsp;📑 {page_node.name}")
                            for vis in page_node.children:
                                if vis.node_type == "visual":
                                    fields = ", ".join(f"`{c.name}`" for c in vis.children)
                                    st.markdown(
                                        f"&nbsp;&nbsp;&nbsp;&nbsp;📈 {vis.name} — {fields}"
                                    )

    # Downloads
    st.markdown("---")
    col1, col2 = st.columns(2)
    with col1:
        html = _generate_html_export(lineage)
        if html:
            st.download_button(
                "📥 Download HTML", data=html,
                file_name=f"lineage_{model.name}.html", mime="text/html",
                use_container_width=True,
            )
    with col2:
        st.download_button(
            "📥 Download JSON",
            data=json.dumps(lineage.model_dump(), indent=2, default=str),
            file_name=f"lineage_{model.name}.json", mime="application/json",
            use_container_width=True,
        )


def _render_health_view(ds_name: str, ws_name: str, health):
    """Render health score."""
    color = _score_color(health.score)
    st.markdown(f"### 📋 {ds_name}")
    st.caption(ws_name)
    st.markdown(
        f'<div class="health-big">'
        f'<div class="score" style="color:{color}">{health.score}</div>'
        f'<div class="max">/100</div>'
        f'{_health_bar_html(health.score)}'
        f'</div>',
        unsafe_allow_html=True,
    )

    if not health.issues:
        st.success("✅ All checks passed!")
    else:
        for issue in health.issues:
            icon = {"error": "❌", "warning": "⚠️", "info": "ℹ️"}.get(issue.severity, "•")
            if issue.severity == "error":
                st.error(f"{icon} {issue.message}")
            elif issue.severity == "warning":
                st.warning(f"{icon} {issue.message}")
            else:
                st.info(f"{icon} {issue.message}")

    if health.breakdown:
        st.markdown("---")
        cols = st.columns(len(health.breakdown))
        for i, (cat, pts) in enumerate(health.breakdown.items()):
            with cols[i]:
                st.metric(cat.title(), f"-{pts}")


def _generate_html_export(lineage: LineageResponse) -> str | None:
    template_path = os.path.join(
        os.path.dirname(os.path.dirname(__file__)), "viz", "template.html"
    )
    try:
        with open(template_path, "r", encoding="utf-8") as f:
            template = f.read()
        return template.replace(
            "__LINEAGE_DATA_PLACEHOLDER__",
            json.dumps(lineage.model_dump(), default=str),
        )
    except Exception:
        return None


# ── Sidebar ───────────────────────────────────────────────────────────

with st.sidebar:
    st.markdown("## 🔍 TOMPo")
    st.caption("Fabric Lineage Intelligence")
    st.divider()

    # Index status
    ws_count = store.get_workspace_count()
    ds_count = store.get_total_datasets()
    rpt_count = store.get_total_reports()
    idx_count = store.get_indexed_dataset_count()
    age_hrs = store.get_index_age_hours()

    if ws_count > 0:
        age_str = f"{age_hrs:.0f}h ago" if age_hrs is not None else ""
        st.markdown(
            f'<div class="index-banner ok">'
            f'✅ <b>{ws_count}</b> workspaces · <b>{ds_count}</b> models · '
            f'<b>{idx_count}</b> deep indexed · {age_str}'
            f'</div>',
            unsafe_allow_html=True,
        )
        if age_hrs and age_hrs > 24:
            st.markdown(
                '<div class="index-banner stale">⚠️ Index older than 24h — consider refreshing</div>',
                unsafe_allow_html=True,
            )
    else:
        st.markdown(
            '<div class="index-banner empty">No index — click Build Index to start</div>',
            unsafe_allow_html=True,
        )

    st.markdown("**Index**")
    col_b1, col_b2 = st.columns(2)
    with col_b1:
        if st.button("⚡ Build", type="primary", use_container_width=True):
            st.session_state["action"] = "build_index"
            st.rerun()
    with col_b2:
        if st.button("🔄 Refresh", use_container_width=True):
            st.session_state["action"] = "build_index"
            st.rerun()

    st.divider()

    # Navigation
    st.markdown("**Navigate**")
    page = st.radio(
        "Page",
        ["🔍 Ask TOMPo", "📊 Browse", "🌐 Cross-Workspace", "📋 Health"],
        label_visibility="collapsed",
    )
    st.session_state["page"] = page

    st.divider()

    # Workspace + model picker
    if ws_count > 0:
        workspaces = store.get_workspaces()
        ws_map = {ws["name"]: ws for ws in workspaces}
        selected_ws_name = st.selectbox(
            "📁 Workspace",
            options=[""] + list(ws_map.keys()),
            placeholder="Select workspace...",
        )

        if selected_ws_name and selected_ws_name in ws_map:
            ws = ws_map[selected_ws_name]
            st.session_state["selected_ws_id"] = ws["id"]
            st.session_state["selected_ws_name"] = selected_ws_name

            datasets = store.get_datasets_for_workspace(ws["id"])
            reports = store.get_reports_for_workspace(ws["id"])
            st.caption(f"{len(datasets)} models · {len(reports)} reports")

            ds_map = {ds["name"]: ds for ds in datasets}
            selected_ds_name = st.selectbox(
                "📊 Semantic Model",
                options=[""] + list(ds_map.keys()),
                placeholder="Select model...",
            )

            if selected_ds_name and selected_ds_name in ds_map:
                st.session_state["selected_ds"] = ds_map[selected_ds_name]

                if st.button("🌳 Generate Lineage", use_container_width=True):
                    st.session_state["action"] = "lineage"
                    st.session_state["page"] = "📊 Browse"
                    st.rerun()

                if st.button("📋 Health Score", use_container_width=True):
                    st.session_state["action"] = "health_single"
                    st.session_state["page"] = "📋 Health"
                    st.rerun()

    st.divider()
    if st.button("🗑️ Reset Index", use_container_width=True):
        store.nuke_db()
        for key in list(st.session_state.keys()):
            del st.session_state[key]
        st.rerun()

    st.caption("TOMPo v0.3.0 · [PyPI](https://pypi.org/project/tompo-mcp/)")


# ── Title Bar ─────────────────────────────────────────────────────────

st.markdown(
    '<div class="tompo-titlebar">'
    '<div><h1>🔍 TOMPo</h1>'
    '<p>Trace lineage from semantic models → reports → visuals. '
    'Search any column across your Fabric tenant.</p>'
    '</div></div>',
    unsafe_allow_html=True,
)


# ── Handle Build Index Action ─────────────────────────────────────────

if st.session_state.get("action") == "build_index":
    st.markdown('<div class="section-header">Building Index</div>', unsafe_allow_html=True)

    progress = st.progress(0)
    status = st.empty()
    client = _get_client()

    # Phase 1: List workspaces
    status.text("Phase 1/2 — Loading workspace list...")
    ws_list = _run_async(client.list_workspaces())
    store.save_workspaces(ws_list)
    progress.progress(0.05)

    total = len(ws_list)
    status.text(f"Phase 2/2 — Scanning items in {total} workspaces...")

    # Phase 2: Scan items per workspace
    dataset_locations: dict[str, tuple[str, str, str]] = {}
    all_summaries: list[WorkspaceSummary] = []

    for idx, ws_raw in enumerate(ws_list):
        ws_id = ws_raw.get("id", "")
        ws_name = ws_raw.get("name", "Unknown")
        status.text(f"Scanning {ws_name} ({idx + 1}/{total})...")
        try:
            items = _run_async(client.get_workspace_items(ws_id))
            datasets = items.get("datasets", [])
            reports = items.get("reports", [])
            store.save_workspace_items(ws_id, datasets, reports)

            all_summaries.append(WorkspaceSummary(
                id=ws_id, name=ws_name, datasets=datasets, reports=reports,
            ))
            for ds in datasets:
                dataset_locations[ds.get("id", "")] = (ws_id, ws_name, ds.get("name", ""))
        except Exception:
            pass
        progress.progress((idx + 1) / total)

    # Build cross-workspace links
    status.text("Calculating cross-workspace dependencies...")
    cross_links: list[CrossWorkspaceLink] = []
    for ws_summary in all_summaries:
        for report in ws_summary.reports:
            report_ds_id = report.get("datasetId", "")
            if report_ds_id and report_ds_id in dataset_locations:
                m_ws_id, m_ws_name, m_name = dataset_locations[report_ds_id]
                if m_ws_id != ws_summary.id:
                    cross_links.append(CrossWorkspaceLink(
                        model_id=report_ds_id, model_name=m_name,
                        model_workspace_id=m_ws_id, model_workspace_name=m_ws_name,
                        report_id=report.get("id", ""), report_name=report.get("name", ""),
                        report_workspace_id=ws_summary.id,
                        report_workspace_name=ws_summary.name,
                    ))
    store.save_cross_workspace_links(cross_links)

    progress.progress(1.0)
    status.text(
        f"✅ Index built — {total} workspaces, "
        f"{store.get_total_datasets()} models, "
        f"{len(cross_links)} cross-workspace links"
    )
    st.session_state["action"] = None
    time.sleep(1)
    st.rerun()


# ── Stats Row ─────────────────────────────────────────────────────────

ws_count = store.get_workspace_count()
ds_count = store.get_total_datasets()
rpt_count = store.get_total_reports()
idx_count = store.get_indexed_dataset_count()

if ws_count > 0:
    st.markdown(
        f'<div class="stat-row">'
        f'<div class="stat-card"><div class="stat-value">{ws_count}</div>'
        f'<div class="stat-label">Workspaces</div></div>'
        f'<div class="stat-card"><div class="stat-value">{ds_count}</div>'
        f'<div class="stat-label">Semantic Models</div></div>'
        f'<div class="stat-card"><div class="stat-value">{rpt_count}</div>'
        f'<div class="stat-label">Reports</div></div>'
        f'<div class="stat-card"><div class="stat-value">{idx_count}</div>'
        f'<div class="stat-label">Deep Indexed</div></div>'
        f'</div>',
        unsafe_allow_html=True,
    )

page = st.session_state.get("page", "🔍 Ask TOMPo")


# ── Page: Ask TOMPo ──────────────────────────────────────────────────

if page == "🔍 Ask TOMPo":
    st.markdown('<div class="section-header">Ask TOMPo</div>', unsafe_allow_html=True)

    if ws_count == 0:
        st.info("Build an index first using the sidebar to enable search and Q&A.")
        st.stop()

    # Chat history
    if "chat_history" not in st.session_state:
        st.session_state["chat_history"] = []

    for msg in st.session_state["chat_history"]:
        if msg["role"] == "user":
            st.markdown(f"**You:** {msg['text']}")
        else:
            st.markdown(msg["text"])

    # Chat input
    question = st.chat_input(
        "Ask anything — 'Where is DateOnly used?' or 'Show unused tables' or just type a column name..."
    )

    if question:
        st.session_state["chat_history"].append({"role": "user", "text": question})
        with st.spinner("Searching..."):
            answer_text = ask_tompo_answer(question)
        st.session_state["chat_history"].append({"role": "assistant", "text": answer_text})
        st.rerun()

    # Quick actions
    st.markdown('<div class="section-header">Quick Actions</div>', unsafe_allow_html=True)
    qc1, qc2, qc3, qc4 = st.columns(4)
    with qc1:
        if st.button("📁 List workspaces", use_container_width=True):
            st.session_state["chat_history"].append({"role": "user", "text": "List workspaces"})
            st.session_state["chat_history"].append(
                {"role": "assistant", "text": ask_tompo_answer("List workspaces")}
            )
            st.rerun()
    with qc2:
        if st.button("🌐 Cross-workspace", use_container_width=True):
            st.session_state["chat_history"].append(
                {"role": "user", "text": "Show cross-workspace dependencies"}
            )
            st.session_state["chat_history"].append(
                {"role": "assistant", "text": ask_tompo_answer("Show cross-workspace dependencies")}
            )
            st.rerun()
    with qc3:
        if st.button("⚠️ Unused tables", use_container_width=True):
            st.session_state["chat_history"].append({"role": "user", "text": "Show unused tables"})
            st.session_state["chat_history"].append(
                {"role": "assistant", "text": ask_tompo_answer("Show unused tables")}
            )
            st.rerun()
    with qc4:
        if st.button("❓ Help", use_container_width=True):
            st.session_state["chat_history"].append({"role": "user", "text": "help"})
            st.session_state["chat_history"].append(
                {"role": "assistant", "text": ask_tompo_answer("")}
            )
            st.rerun()


# ── Page: Browse ──────────────────────────────────────────────────────

elif page == "📊 Browse":
    st.markdown('<div class="section-header">Browse Workspaces & Models</div>', unsafe_allow_html=True)

    action = st.session_state.get("action")
    if action == "lineage":
        selected_ds = st.session_state.get("selected_ds")
        ws_id = st.session_state.get("selected_ws_id", "")
        ws_name = st.session_state.get("selected_ws_name", "")
        st.session_state["action"] = None

        if selected_ds and ws_id:
            ds_id = selected_ds.get("id", "")
            ds_name = selected_ds.get("name", "Unknown")

            lineage = store.get_lineage(ds_id)
            if not lineage:
                with st.spinner(f"Generating deep lineage for **{ds_name}**..."):
                    portfolio = store.load_portfolio()
                    lineage = _run_async(deep_scan_model(
                        _get_client(), ws_id, ds_id, ds_name, portfolio
                    ))
                    if lineage:
                        store.save_lineage(ds_id, lineage)

            if lineage:
                _render_lineage_view(lineage, ws_name)
            else:
                st.error(f"Could not generate lineage for **{ds_name}**. Check permissions.")
        else:
            st.warning("Select a workspace and model in the sidebar first.")
    else:
        if ws_count == 0:
            st.info("Build an index first to browse workspaces.")
        else:
            workspaces = store.get_workspaces()
            search_ws = st.text_input("Filter workspaces...", placeholder="Type to filter...")

            filtered = [
                ws for ws in workspaces
                if not search_ws or search_ws.lower() in ws["name"].lower()
            ]

            for ws in filtered[:50]:
                datasets = store.get_datasets_for_workspace(ws["id"])
                reports = store.get_reports_for_workspace(ws["id"])
                with st.expander(
                    f"📁 {ws['name']} — {len(datasets)} models, {len(reports)} reports"
                ):
                    if datasets:
                        st.markdown("**Semantic Models:**")
                        for ds in datasets:
                            cached = store.get_lineage(ds["id"])
                            badge = " ✅ *indexed*" if cached else ""
                            st.markdown(f"• 📊 {ds['name']}{badge}")
                    if reports:
                        st.markdown("**Reports:**")
                        for rpt in reports:
                            st.markdown(f"• 📄 {rpt['name']}")

            if len(filtered) > 50:
                st.caption(
                    f"Showing first 50 of {len(filtered)} workspaces. Use the filter."
                )


# ── Page: Cross-Workspace ─────────────────────────────────────────────

elif page == "🌐 Cross-Workspace":
    st.markdown(
        '<div class="section-header">Cross-Workspace Dependencies</div>',
        unsafe_allow_html=True,
    )

    links = store.get_cross_workspace_links()
    if not links:
        st.info("No cross-workspace data. Build the index first.")
    else:
        st.markdown(f"**{len(links)}** reports use semantic models from a different workspace.")

        groups: dict[str, list] = {}
        for link in links:
            key = f"{link.model_name} ({link.model_workspace_name})"
            groups.setdefault(key, []).append(link)

        for model_key, model_links in sorted(groups.items()):
            with st.expander(
                f"📊 {model_key} → {len(model_links)} external report(s)"
            ):
                for link in model_links:
                    st.markdown(
                        f"• 📄 **{link.report_name}** in *{link.report_workspace_name}*"
                    )

                first = model_links[0]
                if st.button(
                    f"🌳 Generate lineage for {first.model_name}",
                    key=f"xws_{first.model_id}",
                ):
                    with st.spinner("Generating deep lineage..."):
                        portfolio = store.load_portfolio()
                        lineage = _run_async(deep_scan_model(
                            _get_client(),
                            first.model_workspace_id,
                            first.model_id,
                            first.model_name,
                            portfolio,
                        ))
                        if lineage:
                            store.save_lineage(first.model_id, lineage)
                            _render_lineage_view(lineage, first.model_workspace_name)


# ── Page: Health ──────────────────────────────────────────────────────

elif page == "📋 Health":
    st.markdown(
        '<div class="section-header">Governance Health Score</div>',
        unsafe_allow_html=True,
    )

    action = st.session_state.get("action")
    if action == "health_single":
        selected_ds = st.session_state.get("selected_ds")
        ws_id = st.session_state.get("selected_ws_id", "")
        ws_name = st.session_state.get("selected_ws_name", "")
        st.session_state["action"] = None

        if selected_ds and ws_id:
            ds_id = selected_ds.get("id", "")
            ds_name = selected_ds.get("name", "Unknown")

            lineage = store.get_lineage(ds_id)
            if not lineage:
                with st.spinner(f"Analyzing **{ds_name}**..."):
                    portfolio = store.load_portfolio()
                    lineage = _run_async(deep_scan_model(
                        _get_client(), ws_id, ds_id, ds_name, portfolio
                    ))
                    if lineage:
                        store.save_lineage(ds_id, lineage)

            if lineage:
                health = calculate_model_health(lineage.model, lineage.reports)
                _render_health_view(ds_name, ws_name, health)
            else:
                st.error(f"Could not analyze **{ds_name}**.")
        else:
            st.warning("Select a workspace and model in the sidebar.")
    else:
        # Show all indexed health scores
        all_ids = store.get_all_lineage_ids()
        if not all_ids:
            st.info(
                "No models indexed yet. Select a model in the sidebar and "
                "click **Health Score** or **Generate Lineage**."
            )
        else:
            scores: list[tuple[str, str, int, Any]] = []
            for ds_id in all_ids:
                lineage = store.get_lineage(ds_id)
                if lineage:
                    health = calculate_model_health(lineage.model, lineage.reports)
                    with store._connect() as conn:
                        row = conn.execute(
                            "SELECT w.name FROM workspaces w "
                            "JOIN datasets d ON d.workspace_id=w.id WHERE d.id=?",
                            (ds_id,),
                        ).fetchone()
                    ws_nm = row["name"] if row else ""
                    scores.append((lineage.model.name, ws_nm, health.score, health))

            if scores:
                avg = round(sum(s[2] for s in scores) / len(scores))
                st.markdown(
                    f'<div class="health-big">'
                    f'<div class="score" style="color:{_score_color(avg)}">{avg}</div>'
                    f'<div class="max">/100 avg across {len(scores)} model(s)</div>'
                    f'{_health_bar_html(avg)}'
                    f'</div>',
                    unsafe_allow_html=True,
                )
                st.markdown("---")

                for name, ws_nm, score, health in sorted(scores, key=lambda x: x[2]):
                    issue_ct = len(
                        [i for i in health.issues if i.severity in ("error", "warning")]
                    )
                    icon = "⚠️" if issue_ct > 0 else "✅"
                    with st.expander(f"{icon} {name} — {score}/100 ({ws_nm})"):
                        st.markdown(f"**Score:** {score}/100")
                        st.markdown(_health_bar_html(score), unsafe_allow_html=True)
                        for issue in health.issues:
                            sev = {"error": "❌", "warning": "⚠️", "info": "ℹ️"}.get(
                                issue.severity, "•"
                            )
                            st.markdown(f"{sev} {issue.message}")
                        if not health.issues:
                            st.success("All checks passed!")
