"""CLI entry point for tompo-web command."""

import os
import subprocess
import sys


def main():
    """Launch the TOMPo Streamlit web app."""
    app_path = os.path.join(os.path.dirname(__file__), "web", "app.py")

    args = sys.argv[1:]

    # Handle --reindex: nuke the DB before launching
    if "--reindex" in args:
        from tompo_mcp.db.store import nuke_db
        print("🗑️  Clearing index...")
        nuke_db()
        print("   Index cleared. Will rebuild on next scan.")
        args = [a for a in args if a != "--reindex"]

    cmd = [
        sys.executable, "-m", "streamlit", "run",
        app_path,
        "--server.headless", "true",
        "--browser.gatherUsageStats", "false",
    ]

    # Pass through host/port if provided via CLI args
    for i, arg in enumerate(args):
        if arg in ("--host", "--server.address") and i + 1 < len(args):
            cmd.extend(["--server.address", args[i + 1]])
        elif arg in ("--port", "--server.port") and i + 1 < len(args):
            cmd.extend(["--server.port", args[i + 1]])

    print("🔍 Starting TOMPo — Fabric Lineage Intelligence")
    print("   Open http://localhost:8501 in your browser")
    print("   Index stored at: ~/.tompo/index.db")
    print()

    try:
        subprocess.run(cmd, check=True)
    except KeyboardInterrupt:
        print("\nTOMPo stopped.")
    except FileNotFoundError:
        print("Error: streamlit not found. Install it with: pip install streamlit")
        sys.exit(1)


if __name__ == "__main__":
    main()
