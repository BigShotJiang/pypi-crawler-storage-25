"""TOMPo persistent storage layer."""
