"""SQLite-backed persistent index for TOMPo.

Stores workspace metadata, dataset definitions, report info, and lineage
at ~/.tompo/index.db so the Streamlit app starts instantly on subsequent runs.
"""

from __future__ import annotations

import json
import os
import sqlite3
import time
from contextlib import contextmanager
from dataclasses import asdict
from pathlib import Path
from typing import Any, Generator, Optional

from tompo_mcp.core.models import LineageResponse
from tompo_mcp.core.scanner import (
    CrossWorkspaceLink,
    PortfolioScan,
    WorkspaceSummary,
)

# ── Location ──────────────────────────────────────────────────────────

DB_DIR = Path.home() / ".tompo"
DB_PATH = DB_DIR / "index.db"

# ── Schema ────────────────────────────────────────────────────────────

_SCHEMA = """
CREATE TABLE IF NOT EXISTS meta (
    key   TEXT PRIMARY KEY,
    value TEXT
);

CREATE TABLE IF NOT EXISTS workspaces (
    id   TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    scanned_at REAL  -- epoch
);

CREATE TABLE IF NOT EXISTS datasets (
    id           TEXT PRIMARY KEY,
    name         TEXT NOT NULL,
    workspace_id TEXT NOT NULL,
    definition_json TEXT,   -- SemanticModelInfo.model_dump_json() or NULL
    last_modified TEXT,     -- from API modifiedDateTime
    scanned_at   REAL,
    FOREIGN KEY (workspace_id) REFERENCES workspaces(id)
);

CREATE TABLE IF NOT EXISTS reports (
    id           TEXT PRIMARY KEY,
    name         TEXT NOT NULL,
    workspace_id TEXT NOT NULL,
    dataset_id   TEXT,
    last_modified TEXT,     -- from API modifiedDateTime
    scanned_at   REAL,
    FOREIGN KEY (workspace_id) REFERENCES workspaces(id)
);

CREATE TABLE IF NOT EXISTS selected_workspaces (
    workspace_id TEXT PRIMARY KEY,
    selected_at  REAL,
    FOREIGN KEY (workspace_id) REFERENCES workspaces(id)
);

CREATE TABLE IF NOT EXISTS skipped_items (
    id           TEXT PRIMARY KEY,
    name         TEXT NOT NULL,
    item_type    TEXT NOT NULL,  -- 'dataset' or 'report'
    workspace_id TEXT NOT NULL,
    workspace_name TEXT,
    reason       TEXT NOT NULL,
    skipped_at   REAL
);

CREATE TABLE IF NOT EXISTS lineage_cache (
    dataset_id   TEXT PRIMARY KEY,
    lineage_json TEXT NOT NULL,  -- LineageResponse.model_dump_json()
    created_at   REAL,
    FOREIGN KEY (dataset_id) REFERENCES datasets(id)
);

CREATE TABLE IF NOT EXISTS cross_workspace_links (
    id                   INTEGER PRIMARY KEY AUTOINCREMENT,
    model_id             TEXT NOT NULL,
    model_name           TEXT,
    model_workspace_id   TEXT,
    model_workspace_name TEXT,
    report_id            TEXT NOT NULL,
    report_name          TEXT,
    report_workspace_id  TEXT,
    report_workspace_name TEXT
);

-- FTS5 virtual table for fast text search
CREATE VIRTUAL TABLE IF NOT EXISTS search_index USING fts5(
    entity_type,   -- 'workspace', 'dataset', 'report', 'table', 'column', 'measure'
    entity_id,
    name,
    parent_name,   -- e.g. table name for columns, workspace name for datasets
    workspace_name,
    workspace_id,
    dataset_id,
    extra          -- data_type for columns, expression for measures
);
"""


# ── Connection ────────────────────────────────────────────────────────

def _ensure_dir() -> None:
    DB_DIR.mkdir(parents=True, exist_ok=True)


@contextmanager
def _connect() -> Generator[sqlite3.Connection, None, None]:
    _ensure_dir()
    conn = sqlite3.connect(str(DB_PATH), timeout=10)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def init_db() -> None:
    """Create tables if they don't exist."""
    with _connect() as conn:
        conn.executescript(_SCHEMA)


# ── Meta ──────────────────────────────────────────────────────────────

def get_meta(key: str) -> Optional[str]:
    with _connect() as conn:
        row = conn.execute("SELECT value FROM meta WHERE key=?", (key,)).fetchone()
        return row["value"] if row else None


def set_meta(key: str, value: str) -> None:
    with _connect() as conn:
        conn.execute(
            "INSERT INTO meta(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=?",
            (key, value, value),
        )


# ── Workspaces ────────────────────────────────────────────────────────

def save_workspaces(workspaces: list[dict[str, Any]]) -> None:
    """Save workspace list from API."""
    now = time.time()
    with _connect() as conn:
        conn.executemany(
            "INSERT INTO workspaces(id,name,scanned_at) VALUES(?,?,?) "
            "ON CONFLICT(id) DO UPDATE SET name=excluded.name, scanned_at=excluded.scanned_at",
            [(ws.get("id", ""), ws.get("name", ""), now) for ws in workspaces],
        )
    set_meta("last_workspace_scan", str(now))


def get_workspaces() -> list[dict[str, str]]:
    with _connect() as conn:
        rows = conn.execute("SELECT id, name FROM workspaces ORDER BY name").fetchall()
        return [{"id": r["id"], "name": r["name"]} for r in rows]


def get_workspace_count() -> int:
    with _connect() as conn:
        row = conn.execute("SELECT COUNT(*) as cnt FROM workspaces").fetchone()
        return row["cnt"] if row else 0


# ── Datasets / Reports ───────────────────────────────────────────────

def save_workspace_items(
    workspace_id: str,
    datasets: list[dict[str, Any]],
    reports: list[dict[str, Any]],
) -> None:
    """Save datasets and reports for a workspace."""
    now = time.time()
    with _connect() as conn:
        conn.executemany(
            "INSERT INTO datasets(id,name,workspace_id,last_modified,scanned_at) VALUES(?,?,?,?,?) "
            "ON CONFLICT(id) DO UPDATE SET name=excluded.name, workspace_id=excluded.workspace_id, "
            "last_modified=excluded.last_modified, scanned_at=excluded.scanned_at",
            [(ds.get("id", ""), ds.get("name", ""), workspace_id,
              ds.get("configuredDate", ds.get("modifiedDateTime", "")), now) for ds in datasets],
        )
        conn.executemany(
            "INSERT INTO reports(id,name,workspace_id,dataset_id,last_modified,scanned_at) VALUES(?,?,?,?,?,?) "
            "ON CONFLICT(id) DO UPDATE SET name=excluded.name, workspace_id=excluded.workspace_id, "
            "dataset_id=excluded.dataset_id, last_modified=excluded.last_modified, scanned_at=excluded.scanned_at",
            [
                (r.get("id", ""), r.get("name", ""), workspace_id,
                 r.get("datasetId", ""), r.get("modifiedDateTime", ""), now)
                for r in reports
            ],
        )


def get_datasets_for_workspace(workspace_id: str) -> list[dict[str, str]]:
    with _connect() as conn:
        rows = conn.execute(
            "SELECT id, name FROM datasets WHERE workspace_id=? ORDER BY name",
            (workspace_id,),
        ).fetchall()
        return [{"id": r["id"], "name": r["name"]} for r in rows]


def get_reports_for_workspace(workspace_id: str) -> list[dict[str, str]]:
    with _connect() as conn:
        rows = conn.execute(
            "SELECT id, name, dataset_id FROM reports WHERE workspace_id=? ORDER BY name",
            (workspace_id,),
        ).fetchall()
        return [{"id": r["id"], "name": r["name"], "datasetId": r["dataset_id"]} for r in rows]


def get_total_datasets() -> int:
    with _connect() as conn:
        return conn.execute("SELECT COUNT(*) as c FROM datasets").fetchone()["c"]


def get_total_reports() -> int:
    with _connect() as conn:
        return conn.execute("SELECT COUNT(*) as c FROM reports").fetchone()["c"]


def get_indexed_dataset_count() -> int:
    """How many datasets have lineage cached."""
    with _connect() as conn:
        return conn.execute("SELECT COUNT(*) as c FROM lineage_cache").fetchone()["c"]


# ── Lineage Cache ─────────────────────────────────────────────────────

def save_lineage(dataset_id: str, lineage: LineageResponse) -> None:
    """Persist a full lineage result."""
    now = time.time()
    data = json.dumps(lineage.model_dump(), default=str)
    with _connect() as conn:
        conn.execute(
            "INSERT INTO lineage_cache(dataset_id,lineage_json,created_at) VALUES(?,?,?) "
            "ON CONFLICT(dataset_id) DO UPDATE SET lineage_json=excluded.lineage_json, created_at=excluded.created_at",
            (dataset_id, data, now),
        )
    # Rebuild search index for this dataset
    _index_lineage(dataset_id, lineage)


def get_lineage(dataset_id: str) -> Optional[LineageResponse]:
    with _connect() as conn:
        row = conn.execute(
            "SELECT lineage_json FROM lineage_cache WHERE dataset_id=?", (dataset_id,)
        ).fetchone()
        if row:
            return LineageResponse.model_validate_json(row["lineage_json"])
        return None


def get_all_lineage_ids() -> list[str]:
    with _connect() as conn:
        rows = conn.execute("SELECT dataset_id FROM lineage_cache").fetchall()
        return [r["dataset_id"] for r in rows]


def get_all_lineage() -> dict[str, LineageResponse]:
    """Load every cached lineage into memory. Use sparingly."""
    with _connect() as conn:
        rows = conn.execute("SELECT dataset_id, lineage_json FROM lineage_cache").fetchall()
        result = {}
        for r in rows:
            try:
                result[r["dataset_id"]] = LineageResponse.model_validate_json(r["lineage_json"])
            except Exception:
                continue
        return result


# ── Cross-Workspace Links ─────────────────────────────────────────────

def save_cross_workspace_links(links: list[CrossWorkspaceLink]) -> None:
    with _connect() as conn:
        conn.execute("DELETE FROM cross_workspace_links")
        conn.executemany(
            "INSERT INTO cross_workspace_links("
            "model_id,model_name,model_workspace_id,model_workspace_name,"
            "report_id,report_name,report_workspace_id,report_workspace_name"
            ") VALUES(?,?,?,?,?,?,?,?)",
            [
                (l.model_id, l.model_name, l.model_workspace_id, l.model_workspace_name,
                 l.report_id, l.report_name, l.report_workspace_id, l.report_workspace_name)
                for l in links
            ],
        )


def get_cross_workspace_links() -> list[CrossWorkspaceLink]:
    with _connect() as conn:
        rows = conn.execute("SELECT * FROM cross_workspace_links").fetchall()
        return [
            CrossWorkspaceLink(
                model_id=r["model_id"], model_name=r["model_name"],
                model_workspace_id=r["model_workspace_id"],
                model_workspace_name=r["model_workspace_name"],
                report_id=r["report_id"], report_name=r["report_name"],
                report_workspace_id=r["report_workspace_id"],
                report_workspace_name=r["report_workspace_name"],
            )
            for r in rows
        ]


# ── Full-text Search Index ────────────────────────────────────────────

def _index_lineage(dataset_id: str, lineage: LineageResponse) -> None:
    """Rebuild FTS index entries for one dataset's lineage."""
    model = lineage.model
    # Look up workspace name
    ws_name = ""
    ws_id = ""
    with _connect() as conn:
        row = conn.execute(
            "SELECT w.id, w.name FROM workspaces w "
            "JOIN datasets d ON d.workspace_id = w.id WHERE d.id=?",
            (dataset_id,),
        ).fetchone()
        if row:
            ws_name = row["name"]
            ws_id = row["id"]

        # Remove old entries for this dataset
        conn.execute("DELETE FROM search_index WHERE dataset_id=?", (dataset_id,))

        # Index the dataset itself
        conn.execute(
            "INSERT INTO search_index(entity_type,entity_id,name,parent_name,workspace_name,workspace_id,dataset_id,extra) "
            "VALUES(?,?,?,?,?,?,?,?)",
            ("dataset", dataset_id, model.name, ws_name, ws_name, ws_id, dataset_id, ""),
        )

        # Index tables, columns, measures
        for table in model.tables:
            conn.execute(
                "INSERT INTO search_index(entity_type,entity_id,name,parent_name,workspace_name,workspace_id,dataset_id,extra) "
                "VALUES(?,?,?,?,?,?,?,?)",
                ("table", dataset_id, table.name, model.name, ws_name, ws_id, dataset_id, ""),
            )
            for col in table.columns:
                conn.execute(
                    "INSERT INTO search_index(entity_type,entity_id,name,parent_name,workspace_name,workspace_id,dataset_id,extra) "
                    "VALUES(?,?,?,?,?,?,?,?)",
                    ("column", dataset_id, col.name, table.name, ws_name, ws_id, dataset_id, col.data_type),
                )
            for meas in table.measures:
                conn.execute(
                    "INSERT INTO search_index(entity_type,entity_id,name,parent_name,workspace_name,workspace_id,dataset_id,extra) "
                    "VALUES(?,?,?,?,?,?,?,?)",
                    ("measure", dataset_id, meas.name, table.name, ws_name, ws_id, dataset_id, meas.expression[:500] if meas.expression else ""),
                )

        # Index reports
        for report in lineage.reports:
            conn.execute(
                "INSERT INTO search_index(entity_type,entity_id,name,parent_name,workspace_name,workspace_id,dataset_id,extra) "
                "VALUES(?,?,?,?,?,?,?,?)",
                ("report", report.id, report.name, model.name, ws_name, ws_id, dataset_id, ""),
            )


def search(query: str, limit: int = 100) -> list[dict[str, Any]]:
    """Full-text search across the entire index.

    Returns list of dicts with: entity_type, entity_id, name, parent_name,
    workspace_name, workspace_id, dataset_id, extra, rank.
    """
    if not query or not query.strip():
        return []

    # Escape FTS special chars and add prefix matching
    safe_q = query.strip().replace('"', '""')
    fts_query = f'"{safe_q}"*'

    with _connect() as conn:
        rows = conn.execute(
            "SELECT entity_type, entity_id, name, parent_name, "
            "workspace_name, workspace_id, dataset_id, extra, rank "
            "FROM search_index WHERE search_index MATCH ? "
            "ORDER BY rank LIMIT ?",
            (fts_query, limit),
        ).fetchall()
        return [dict(r) for r in rows]


# ── Portfolio reconstruction ──────────────────────────────────────────

def load_portfolio() -> Optional[PortfolioScan]:
    """Reconstruct a PortfolioScan from the DB (if data exists)."""
    workspaces_raw = get_workspaces()
    if not workspaces_raw:
        return None

    summaries = []
    dataset_locations: dict[str, tuple[str, str, str]] = {}

    for ws in workspaces_raw:
        ws_id = ws["id"]
        ws_name = ws["name"]
        datasets = get_datasets_for_workspace(ws_id)
        reports = get_reports_for_workspace(ws_id)
        summaries.append(WorkspaceSummary(
            id=ws_id, name=ws_name,
            datasets=datasets, reports=reports,
        ))
        for ds in datasets:
            dataset_locations[ds["id"]] = (ws_id, ws_name, ds["name"])

    cross_links = get_cross_workspace_links()

    return PortfolioScan(
        workspaces=summaries,
        cross_workspace_links=cross_links,
        total_datasets=sum(len(ws.datasets) for ws in summaries),
        total_reports=sum(len(ws.reports) for ws in summaries),
        dataset_locations=dataset_locations,
    )


# ── Selected Workspaces ───────────────────────────────────────────────

def save_selected_workspaces(workspace_ids: list[str]) -> None:
    """Save user's workspace selection."""
    now = time.time()
    with _connect() as conn:
        conn.execute("DELETE FROM selected_workspaces")
        conn.executemany(
            "INSERT INTO selected_workspaces(workspace_id,selected_at) VALUES(?,?)",
            [(ws_id, now) for ws_id in workspace_ids],
        )


def get_selected_workspaces() -> list[str]:
    """Get IDs of user-selected workspaces."""
    with _connect() as conn:
        rows = conn.execute("SELECT workspace_id FROM selected_workspaces").fetchall()
        return [r["workspace_id"] for r in rows]


# ── Skipped Items ─────────────────────────────────────────────────────

def save_skipped_item(
    item_id: str, name: str, item_type: str,
    workspace_id: str, workspace_name: str, reason: str,
) -> None:
    now = time.time()
    with _connect() as conn:
        conn.execute(
            "INSERT INTO skipped_items(id,name,item_type,workspace_id,workspace_name,reason,skipped_at) "
            "VALUES(?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET reason=excluded.reason, skipped_at=excluded.skipped_at",
            (item_id, name, item_type, workspace_id, workspace_name, reason, now),
        )


def get_skipped_items() -> list[dict[str, Any]]:
    with _connect() as conn:
        rows = conn.execute(
            "SELECT id, name, item_type, workspace_id, workspace_name, reason, skipped_at "
            "FROM skipped_items ORDER BY skipped_at DESC"
        ).fetchall()
        return [dict(r) for r in rows]


def clear_skipped_item(item_id: str) -> None:
    with _connect() as conn:
        conn.execute("DELETE FROM skipped_items WHERE id=?", (item_id,))


def clear_all_skipped() -> None:
    with _connect() as conn:
        conn.execute("DELETE FROM skipped_items")


# ── Incremental Scan Helpers ──────────────────────────────────────────

def get_stale_datasets(api_datasets: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Compare API dataset list with DB to find new/changed datasets."""
    stale = []
    with _connect() as conn:
        for ds in api_datasets:
            ds_id = ds.get("id", "")
            api_modified = ds.get("configuredDate", ds.get("modifiedDateTime", ""))
            row = conn.execute(
                "SELECT last_modified, scanned_at FROM datasets WHERE id=?", (ds_id,)
            ).fetchone()
            if not row:
                stale.append(ds)  # new
            elif api_modified and row["last_modified"] != api_modified:
                stale.append(ds)  # changed
            # Also check if lineage is missing
            elif not conn.execute(
                "SELECT 1 FROM lineage_cache WHERE dataset_id=?", (ds_id,)
            ).fetchone():
                stale.append(ds)  # no lineage yet
    return stale


def get_stale_reports(api_reports: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Compare API report list with DB to find new/changed reports."""
    stale = []
    with _connect() as conn:
        for r in api_reports:
            r_id = r.get("id", "")
            api_modified = r.get("modifiedDateTime", "")
            row = conn.execute(
                "SELECT last_modified FROM reports WHERE id=?", (r_id,)
            ).fetchone()
            if not row:
                stale.append(r)  # new
            elif api_modified and row["last_modified"] != api_modified:
                stale.append(r)  # changed
    return stale


def get_deleted_datasets(api_dataset_ids: set[str], workspace_id: str) -> list[str]:
    """Find datasets in DB that no longer exist in API for a workspace."""
    with _connect() as conn:
        rows = conn.execute(
            "SELECT id FROM datasets WHERE workspace_id=?", (workspace_id,)
        ).fetchall()
        return [r["id"] for r in rows if r["id"] not in api_dataset_ids]


def remove_dataset(dataset_id: str) -> None:
    """Remove a dataset and its lineage from DB."""
    with _connect() as conn:
        conn.execute("DELETE FROM lineage_cache WHERE dataset_id=?", (dataset_id,))
        conn.execute("DELETE FROM search_index WHERE dataset_id=?", (dataset_id,))
        conn.execute("DELETE FROM datasets WHERE id=?", (dataset_id,))


# ── Dropdown Queries (cascaded filter support) ────────────────────────

def get_all_fields(workspace_id: str = "", dataset_id: str = "") -> list[dict[str, Any]]:
    """Get columns and measures from the search index, optionally filtered."""
    conditions = ["s.entity_type IN ('column', 'measure')"]
    params: list[str] = []
    if workspace_id:
        conditions.append("s.workspace_id=?")
        params.append(workspace_id)
    if dataset_id:
        conditions.append("s.dataset_id=?")
        params.append(dataset_id)
    where = " AND ".join(conditions)
    with _connect() as conn:
        rows = conn.execute(
            f"SELECT DISTINCT s.name, s.entity_type, s.parent_name, s.workspace_name, "
            f"s.workspace_id, s.dataset_id, s.extra, d.name as dataset_name "
            f"FROM search_index s LEFT JOIN datasets d ON s.dataset_id = d.id "
            f"WHERE {where} ORDER BY s.name",
            params,
        ).fetchall()
        return [dict(r) for r in rows]


def get_models_for_dropdown(workspace_id: str = "") -> list[dict[str, str]]:
    """Get models, optionally filtered by workspace."""
    if workspace_id:
        return get_datasets_for_workspace(workspace_id)
    with _connect() as conn:
        rows = conn.execute(
            "SELECT d.id, d.name, w.name as workspace_name FROM datasets d "
            "JOIN workspaces w ON d.workspace_id = w.id ORDER BY w.name, d.name"
        ).fetchall()
        return [{"id": r["id"], "name": r["name"], "workspace_name": r["workspace_name"]} for r in rows]


def get_reports_for_dropdown(workspace_id: str = "", dataset_id: str = "") -> list[dict[str, str]]:
    """Get reports, optionally filtered."""
    conditions = ["1=1"]
    params: list[str] = []
    if workspace_id:
        conditions.append("r.workspace_id=?")
        params.append(workspace_id)
    if dataset_id:
        conditions.append("r.dataset_id=?")
        params.append(dataset_id)
    where = " AND ".join(conditions)
    with _connect() as conn:
        rows = conn.execute(
            f"SELECT r.id, r.name, r.dataset_id, w.name as workspace_name FROM reports r "
            f"JOIN workspaces w ON r.workspace_id = w.id WHERE {where} ORDER BY w.name, r.name",
            params,
        ).fetchall()
        return [{"id": r["id"], "name": r["name"], "dataset_id": r["dataset_id"],
                 "workspace_name": r["workspace_name"]} for r in rows]


def get_scan_stats() -> dict[str, int]:
    """Get summary stats for the status bar."""
    with _connect() as conn:
        ws_count = conn.execute("SELECT COUNT(*) as c FROM selected_workspaces").fetchone()["c"]
        ds_count = conn.execute(
            "SELECT COUNT(*) as c FROM datasets WHERE workspace_id IN (SELECT workspace_id FROM selected_workspaces)"
        ).fetchone()["c"]
        report_count = conn.execute(
            "SELECT COUNT(*) as c FROM reports WHERE workspace_id IN (SELECT workspace_id FROM selected_workspaces)"
        ).fetchone()["c"]
        lineage_count = conn.execute("SELECT COUNT(*) as c FROM lineage_cache").fetchone()["c"]
        skipped_count = conn.execute("SELECT COUNT(*) as c FROM skipped_items").fetchone()["c"]
        return {
            "workspaces": ws_count,
            "models": ds_count,
            "reports": report_count,
            "lineage": lineage_count,
            "skipped": skipped_count,
        }


# ── Index age ─────────────────────────────────────────────────────────

def get_index_age_hours() -> Optional[float]:
    """How old is the workspace index, in hours. None if no index."""
    ts = get_meta("last_workspace_scan")
    if ts:
        return (time.time() - float(ts)) / 3600
    return None


def get_last_scan_time() -> Optional[str]:
    """Human-readable last scan timestamp."""
    ts = get_meta("last_workspace_scan")
    if ts:
        import datetime
        dt = datetime.datetime.fromtimestamp(float(ts))
        return dt.strftime("%Y-%m-%d %H:%M")
    return None


def nuke_db() -> None:
    """Delete the entire index. Used by --reindex."""
    if DB_PATH.exists():
        DB_PATH.unlink()
    init_db()


# ── Auto-init on import ──────────────────────────────────────────────

init_db()
