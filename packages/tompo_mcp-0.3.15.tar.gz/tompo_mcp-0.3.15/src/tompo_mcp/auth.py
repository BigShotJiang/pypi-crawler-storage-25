"""
Authentication for TOMPo MCP.

Uses DefaultAzureCredential (Azure CLI / VS Code) by default.
Also accepts a raw bearer token for Fabric Notebook scenarios.
Token caching: tokens are cached in-memory and reused until 5 minutes before expiry.
"""

from __future__ import annotations

import logging
import time
from typing import Optional

from azure.identity import DefaultAzureCredential

logger = logging.getLogger(__name__)

_credential: Optional[DefaultAzureCredential] = None

# Cache: scope -> (token_string, expires_on_epoch)
_token_cache: dict[str, tuple[str, float]] = {}

# Refresh tokens 5 minutes before expiry
_REFRESH_BUFFER = 300


def _get_credential() -> DefaultAzureCredential:
    global _credential
    if _credential is None:
        _credential = DefaultAzureCredential(
            exclude_shared_token_cache_credential=True,
        )
        logger.info("DefaultAzureCredential initialized")
    return _credential


def _get_cached_token(scope: str) -> str:
    """Return a cached token if still valid, otherwise fetch a new one."""
    cached = _token_cache.get(scope)
    if cached:
        token_str, expires_on = cached
        if time.time() < expires_on - _REFRESH_BUFFER:
            return token_str

    cred = _get_credential()
    result = cred.get_token(scope)
    _token_cache[scope] = (result.token, result.expires_on)
    logger.info("Token acquired for %s (expires in %ds)", scope.split("/")[2], int(result.expires_on - time.time()))
    return result.token


class TokenProvider:
    """Provides bearer tokens for Fabric/Power BI API calls.

    If initialized with a raw token string, uses it directly (Fabric Notebook).
    Otherwise uses DefaultAzureCredential (az login / VS Code identity).
    Tokens are cached in-memory and reused until 5 minutes before expiry.
    """

    def __init__(self, token: Optional[str] = None) -> None:
        self._raw_token = token

    def get_powerbi_token(self) -> str:
        if self._raw_token:
            return self._raw_token
        return _get_cached_token("https://analysis.windows.net/powerbi/api/.default")

    def get_fabric_token(self) -> str:
        if self._raw_token:
            return self._raw_token
        return _get_cached_token("https://api.fabric.microsoft.com/.default")

    def get_graph_token(self) -> str:
        if self._raw_token:
            return self._raw_token
        return _get_cached_token("https://graph.microsoft.com/.default")
