"""
TOMPo MCP Server — Power BI & Fabric Lineage Intelligence.

Exposes 5 tools to AI assistants (GitHub Copilot, Claude, etc.):
  1. list_workspaces       — List Fabric workspaces you have access to
  2. generate_lineage      — Full lineage: model → tables → reports → visuals → fields
  3. impact_analysis       — Where is a specific column/measure used?
  4. describe_semantic_model — Tables, columns, measures, relationships, roles
  5. export_lineage_html   — Generate interactive D3 visualization as HTML file
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import tempfile
import webbrowser
from importlib import resources
from typing import Any

from mcp.server.fastmcp import Context, FastMCP

from tompo_mcp.auth import TokenProvider
from tompo_mcp.core.fabric_client import FabricClient
from tompo_mcp.core.lineage import build_lineage, get_all_impact_analysis, get_impact_analysis
from tompo_mcp.core.models import LineageNode, LineageResponse, MeasureInfo, ReportInfo, SemanticModelInfo
from tompo_mcp.core.parser import parse_report_definition, parse_semantic_model
from tompo_mcp.core.scanner import PortfolioScan, scan_portfolio, deep_scan_model
from tompo_mcp.core.governance import calculate_model_health, format_health_score

logger = logging.getLogger(__name__)

mcp = FastMCP(
    "TOMPo",
    instructions="Power BI & Fabric lineage intelligence — trace from semantic models to reports to individual visuals.",
)

# ── Shared state ──────────────────────────────────────────────────────
_token_provider: TokenProvider | None = None
_client: FabricClient | None = None
_last_lineage: LineageResponse | None = None
_last_workspace_id: str = ""
_portfolio: PortfolioScan | None = None


def _get_client() -> FabricClient:
    global _token_provider, _client
    if _client is None:
        _token_provider = TokenProvider()
        _client = FabricClient(_token_provider)
    return _client


# ── Tool 1: List Workspaces ──────────────────────────────────────────

@mcp.tool()
async def list_workspaces() -> str:
    """List all Fabric/Power BI workspaces you have access to.

    Returns workspace names and IDs. Use the workspace ID in other tools.
    Requires: az login (uses your Azure identity).
    """
    client = _get_client()
    workspaces = await client.list_workspaces()

    if not workspaces:
        return "No workspaces found. Make sure you're logged in with `az login` and have access to Fabric workspaces."

    lines = [f"Found {len(workspaces)} workspaces:\n"]
    for ws in sorted(workspaces, key=lambda w: w.get("name", "")):
        name = ws.get("name", "Unknown")
        wid = ws.get("id", "")
        ws_type = ws.get("type", "")
        state = ws.get("state", "")
        line = f"  - **{name}** (`{wid}`)"
        if ws_type:
            line += f" [{ws_type}]"
        if state and state != "Active":
            line += f" ({state})"
        lines.append(line)

    return "\n".join(lines)


# ── Tool 2: Generate Lineage ────────────────────────────────────────

@mcp.tool()
async def generate_lineage(
    workspace_id: str,
    dataset_id: str | None = None,
    dataset_name: str | None = None,
    ctx: Context | None = None,
) -> str:
    """Generate complete lineage for a semantic model: Model → Tables → Reports → Pages → Visuals → Columns/Measures.

    ⏳ Takes 1-2 minutes — fetches model definitions and report structures from Fabric APIs.
    You'll get a rich lineage tree showing every column and measure traced to the exact visual.

    Args:
        workspace_id: The workspace ID (from list_workspaces).
        dataset_id: The semantic model (dataset) ID. If not provided, lists available models.
        dataset_name: Optional human name for the dataset (helps with display).

    Returns the lineage tree showing exactly which columns/measures appear in which visuals.
    """
    global _last_lineage, _last_workspace_id
    client = _get_client()

    # If no dataset_id, list available datasets
    if not dataset_id:
        items = await client.get_workspace_items(workspace_id)
        datasets = items.get("datasets", [])
        if not datasets:
            return "No semantic models found in this workspace."
        lines = ["Available semantic models in this workspace:\n"]
        for ds in datasets:
            lines.append(f"  - **{ds.get('name', 'Unknown')}** (`{ds.get('id', '')}`)")
        lines.append("\nUse the dataset ID to generate lineage.")
        return "\n".join(lines)

    # Get semantic model definition
    if ctx:
        await ctx.report_progress(1, 4, "🔍 Fetching semantic model definition...")
    raw_model = await client.get_semantic_model_definition(workspace_id, dataset_id)
    if not raw_model:
        return f"Could not retrieve semantic model definition for dataset `{dataset_id}`. Check permissions."

    model = parse_semantic_model(raw_model, dataset_id, dataset_name or dataset_id)

    # If TMDL/BIM returned 0 measures, supplement with DAX INFO.MEASURES()
    total_measures = sum(len(t.measures) for t in model.tables)
    if total_measures == 0 and model.tables:
        dax_measures = await client.get_measures_via_dax(workspace_id, dataset_id)
        if dax_measures:
            logger.info("Supplementing %d measures from DAX INFO.MEASURES()", len(dax_measures))
            table_map = {t.name: t for t in model.tables}
            for m in dax_measures:
                tbl = table_map.get(m["table_name"])
                if tbl:
                    tbl.measures.append(MeasureInfo(
                        name=m["name"],
                        expression=m.get("expression", ""),
                        format_string=m.get("format_string"),
                        description=m.get("description"),
                        table_name=m["table_name"],
                    ))

    # Get reports bound to this dataset
    if ctx:
        await ctx.report_progress(2, 4, "📄 Discovering reports bound to this model...")
    report_dicts = await client.get_reports_for_dataset(workspace_id, dataset_id)
    if not report_dicts:
        lineage = build_lineage(model, [], workspace_id)
        _last_lineage = lineage
        _last_workspace_id = workspace_id
        return f"Semantic model **{model.name}** has {len(model.tables)} tables but no reports are bound to it.\n\n" + _format_model_summary(model)

    if ctx:
        await ctx.report_progress(3, 4, f"📊 Parsing {len(report_dicts)} report(s) — extracting visual bindings...")
    # Get report definitions (parallel for speed)
    async def _fetch_report(rd: dict) -> ReportInfo:
        rid = rd.get("id", "")
        rname = rd.get("name", "Unknown")
        raw_report = await client.get_report_definition(workspace_id, rid)
        if raw_report:
            return parse_report_definition(raw_report, rid, rname, dataset_id)
        return ReportInfo(id=rid, name=rname, dataset_id=dataset_id)

    reports: list[ReportInfo] = await asyncio.gather(*[_fetch_report(rd) for rd in report_dicts])

    # If model still has 0 measures, infer from report visual bindings
    total_measures = sum(len(t.measures) for t in model.tables)
    if total_measures == 0:
        table_map = {t.name: t for t in model.tables}
        seen_measures: set[tuple[str, str]] = set()
        for report in reports:
            for page in report.pages:
                for visual in page.visuals:
                    for fb in visual.field_bindings:
                        if fb.field_type == "measure" and (fb.table_name, fb.field_name) not in seen_measures:
                            seen_measures.add((fb.table_name, fb.field_name))
                            tbl = table_map.get(fb.table_name)
                            if tbl:
                                tbl.measures.append(MeasureInfo(
                                    name=fb.field_name,
                                    expression="(inferred from report bindings)",
                                    table_name=fb.table_name,
                                ))
        if seen_measures:
            logger.info("Inferred %d measures from report visual bindings", len(seen_measures))

    # Build lineage
    if ctx:
        await ctx.report_progress(4, 4, "🌳 Building lineage tree — almost done!")
    lineage = build_lineage(model, reports, workspace_id)
    _last_lineage = lineage
    _last_workspace_id = workspace_id

    return _format_lineage_tree(lineage)


def _format_lineage_tree(lineage: LineageResponse) -> str:
    """Format lineage as a readable tree string."""
    lines: list[str] = []
    model = lineage.model
    tree = lineage.lineage_tree

    lines.append(f"# Lineage for {model.name}\n")
    lines.append(f"**Tables:** {len(model.tables)} | **Reports:** {len(lineage.reports)} | "
                 f"**Relationships:** {len(model.relationships)}\n")

    def _render_node(node: LineageNode, indent: str = "", is_last: bool = True) -> None:
        connector = "└── " if is_last else "├── "
        prefix = indent + connector

        icon = {
            "model": "📊", "table": "📋", "report": "📄",
            "page": "📑", "visual": "📈", "column": "🔹", "measure": "🔸",
        }.get(node.node_type, "•")

        label = node.name
        extra = ""

        if node.node_type == "visual":
            title = node.metadata.get("title", "")
            if title and title != node.name:
                extra = f" — *{title}*"
        elif node.node_type == "table":
            cc = node.metadata.get("column_count", 0)
            mc = node.metadata.get("measure_count", 0)
            if node.metadata.get("orphan"):
                extra = f" ({cc} cols, {mc} measures) ⚠️ *not used in any report*"
            else:
                extra = f" ({cc} cols, {mc} measures)"
        elif node.node_type in ("column", "measure"):
            extra = f" [{node.node_type[0].upper()}]"

        lines.append(f"{prefix}{icon} {label}{extra}")

        child_indent = indent + ("    " if is_last else "│   ")
        for i, child in enumerate(node.children):
            _render_node(child, child_indent, i == len(node.children) - 1)

    if tree.children:
        for i, child in enumerate(tree.children):
            _render_node(child, "", i == len(tree.children) - 1)
    else:
        lines.append("No lineage connections found.")

    return "\n".join(lines)


def _format_model_summary(model: SemanticModelInfo) -> str:
    lines = [f"## {model.name}\n"]
    for tbl in model.tables:
        if tbl.is_hidden:
            continue
        lines.append(f"**{tbl.name}** — {len(tbl.columns)} columns, {len(tbl.measures)} measures")
    return "\n".join(lines)


# ── Tool 2b: Generate Workspace Lineage ──────────────────────────────

@mcp.tool()
async def generate_workspace_lineage(
    workspace_id: str,
    ctx: Context | None = None,
) -> str:
    """Generate lineage for ALL semantic models in a workspace, combined into one view.

    ⏳ Takes 1-2 minutes per model — fetches definitions, parses reports, and maps every column
    to its visual. Worth the wait: you get a complete interactive lineage map of your entire workspace.

    Args:
        workspace_id: The workspace ID (from list_workspaces).

    Iterates over every semantic model in the workspace, generates lineage for each,
    and combines them into a single exportable result. Use export_lineage_html after this
    to get a combined interactive visualization.
    """
    global _last_lineage, _last_workspace_id
    client = _get_client()

    items = await client.get_workspace_items(workspace_id)
    ws_name = await client.get_workspace_name(workspace_id)
    datasets = items.get("datasets", [])
    if not datasets:
        return "No semantic models found in this workspace."

    all_tables = []
    all_reports: list[ReportInfo] = []
    all_relationships = []
    all_roles = []
    combined_children = []
    lines: list[str] = [f"# Workspace Lineage — {len(datasets)} semantic model(s)\n"]

    for idx, ds in enumerate(datasets):
        ds_id = ds.get("id", "")
        ds_name = ds.get("name", "Unknown")
        logger.info("Processing model %d/%d: %s", idx + 1, len(datasets), ds_name)
        if ctx:
            await ctx.report_progress(idx, len(datasets), f"🔍 [{idx+1}/{len(datasets)}] Analyzing '{ds_name}' — fetching model definition...")

        # Get model definition
        raw_model = await client.get_semantic_model_definition(workspace_id, ds_id)
        if not raw_model:
            lines.append(f"⚠️ **{ds_name}** — could not access\n")
            continue

        model = parse_semantic_model(raw_model, ds_id, ds_name)

        # Supplement measures via DAX if needed
        total_measures = sum(len(t.measures) for t in model.tables)
        if total_measures == 0 and model.tables:
            dax_measures = await client.get_measures_via_dax(workspace_id, ds_id)
            if dax_measures:
                table_map = {t.name: t for t in model.tables}
                for m in dax_measures:
                    tbl = table_map.get(m["table_name"])
                    if tbl:
                        tbl.measures.append(MeasureInfo(
                            name=m["name"],
                            expression=m.get("expression", ""),
                            table_name=m["table_name"],
                        ))

        # Get reports
        if ctx:
            await ctx.report_progress(idx, len(datasets), f"📄 [{idx+1}/{len(datasets)}] '{ds_name}' — discovering reports & parsing visuals...")
        report_dicts = await client.get_reports_for_dataset(workspace_id, ds_id)
        reports: list[ReportInfo] = []
        if report_dicts:
            async def _fetch(rd: dict) -> ReportInfo:
                rid = rd.get("id", "")
                rname = rd.get("name", "Unknown")
                raw_report = await client.get_report_definition(workspace_id, rid)
                if raw_report:
                    return parse_report_definition(raw_report, rid, rname, ds_id)
                return ReportInfo(id=rid, name=rname, dataset_id=ds_id)

            reports = await asyncio.gather(*[_fetch(rd) for rd in report_dicts])

        # Infer measures from report bindings
        total_measures = sum(len(t.measures) for t in model.tables)
        if total_measures == 0:
            table_map = {t.name: t for t in model.tables}
            for report in reports:
                for page in report.pages:
                    for visual in page.visuals:
                        for fb in visual.field_bindings:
                            if fb.field_type == "measure":
                                tbl = table_map.get(fb.table_name)
                                if tbl and not any(m.name == fb.field_name for m in tbl.measures):
                                    tbl.measures.append(MeasureInfo(
                                        name=fb.field_name,
                                        expression="(inferred from report bindings)",
                                        table_name=fb.table_name,
                                    ))

        # Build lineage for this model
        lineage = build_lineage(model, reports, workspace_id)

        # Accumulate
        all_tables.extend(model.tables)
        all_reports.extend(reports)
        all_relationships.extend(model.relationships)
        all_roles.extend(model.roles)
        # Keep each model as a sub-tree (not flattened)
        combined_children.append(lineage.lineage_tree)

        # Summary line
        report_count = len(reports)
        measure_count = sum(len(t.measures) for t in model.tables)
        col_count = sum(len(t.columns) for t in model.tables)
        lines.append(f"✅ **{ds_name}** — {len(model.tables)} tables, {col_count} cols, {measure_count} measures, {report_count} reports")

    # Build combined LineageResponse
    from tompo_mcp.core.models import LineageNode
    combined_model = SemanticModelInfo(
        id="workspace_combined",
        name=f"Workspace ({len(datasets)} models)",
        tables=all_tables,
        relationships=all_relationships,
        roles=all_roles,
    )
    combined_tree = LineageNode(
        name=ws_name or combined_model.name,
        node_type="workspace",
        children=combined_children,
    )
    combined_lineage = LineageResponse(
        model=combined_model,
        reports=all_reports,
        lineage_tree=combined_tree,
        workspace_name=ws_name,
    )

    _last_lineage = combined_lineage
    _last_workspace_id = workspace_id

    lines.append(f"\n**Total:** {len(all_tables)} tables | {len(all_reports)} reports | {sum(len(t.measures) for t in all_tables)} measures")
    lines.append("\nUse `export_lineage_html` to get the combined interactive visualization.")

    return "\n".join(lines)


# ── Tool 3: Impact Analysis ─────────────────────────────────────────

@mcp.tool()
async def impact_analysis(
    field_name: str,
    table_name: str = "",
    field_type: str = "column",
    workspace_id: str = "",
    dataset_id: str = "",
) -> str:
    """Find all visuals where a specific column or measure is used (impact analysis).

    Args:
        field_name: The column or measure name to search for.
        table_name: The table containing the field. If empty, searches all tables.
        field_type: "column" or "measure" (default: "column").
        workspace_id: Workspace ID (optional if you just ran generate_lineage).
        dataset_id: Dataset ID (optional if you just ran generate_lineage).

    Shows which reports, pages, and visuals would be affected if you rename or remove this field.
    """
    global _last_lineage, _last_workspace_id

    # Use cached lineage if available
    lineage = _last_lineage
    wid = workspace_id or _last_workspace_id

    if not lineage and workspace_id and dataset_id:
        # Generate fresh lineage
        await generate_lineage(workspace_id, dataset_id)
        lineage = _last_lineage
        wid = workspace_id

    if not lineage:
        return "No lineage data available. Run `generate_lineage` first for a workspace and dataset."

    reports = lineage.reports
    model = lineage.model

    # If no table_name, search all tables
    if not table_name:
        results = []
        for tbl in model.tables:
            for col in tbl.columns:
                if col.name.lower() == field_name.lower():
                    r = get_impact_analysis(col.name, "column", tbl.name, reports, wid)
                    if r.usage_count > 0:
                        results.append(r)
            for m in tbl.measures:
                if m.name.lower() == field_name.lower():
                    r = get_impact_analysis(m.name, "measure", tbl.name, reports, wid)
                    if r.usage_count > 0:
                        results.append(r)
        if not results:
            return f"Field `{field_name}` is not used in any visual across {len(reports)} report(s)."
        return _format_impact_results(results)
    else:
        result = get_impact_analysis(field_name, field_type, table_name, reports, wid)
        if result.usage_count == 0:
            return f"`{table_name}.{field_name}` ({field_type}) is not used in any visual."
        return _format_impact_results([result])


def _format_impact_results(results: list) -> str:
    lines: list[str] = []
    total_usage = sum(r.usage_count for r in results)
    lines.append(f"# Impact Analysis — {total_usage} visual(s) affected\n")

    for r in results:
        lines.append(f"## `{r.table_name}.{r.object_name}` ({r.object_type}) — {r.usage_count} usage(s)\n")
        lines.append("| Report | Page | Visual | Type |")
        lines.append("|--------|------|--------|------|")
        for item in r.used_in:
            title = item.visual_title or item.visual_type
            lines.append(f"| {item.report_name} | {item.page_name} | {title} | {item.visual_type} |")
        lines.append("")

    return "\n".join(lines)


# ── Tool 4: Describe Semantic Model ──────────────────────────────────

@mcp.tool()
async def describe_semantic_model(
    workspace_id: str = "",
    dataset_id: str = "",
) -> str:
    """Describe the semantic model: tables, columns, measures, relationships, and roles.

    Args:
        workspace_id: Workspace ID (optional if you just ran generate_lineage).
        dataset_id: Dataset ID (optional if you just ran generate_lineage).

    Returns detailed metadata about the semantic model structure.
    """
    global _last_lineage

    lineage = _last_lineage

    if not lineage and workspace_id and dataset_id:
        await generate_lineage(workspace_id, dataset_id)
        lineage = _last_lineage

    if not lineage:
        return "No lineage data available. Run `generate_lineage` first."

    model = lineage.model
    lines: list[str] = []

    lines.append(f"# Semantic Model: {model.name}\n")
    if model.description:
        lines.append(f"*{model.description}*\n")

    # Tables summary
    visible_tables = [t for t in model.tables if not t.is_hidden]
    lines.append(f"**Tables:** {len(visible_tables)} visible ({len(model.tables)} total)")
    lines.append(f"**Relationships:** {len(model.relationships)}")
    lines.append(f"**Roles:** {len(model.roles)}\n")

    # Per-table detail
    for tbl in visible_tables:
        lines.append(f"## 📋 {tbl.name}")
        if tbl.description:
            lines.append(f"*{tbl.description}*")
        if tbl.source:
            src_preview = tbl.source[:200] + "..." if len(tbl.source) > 200 else tbl.source
            lines.append(f"Source: `{src_preview}`")

        if tbl.columns:
            lines.append(f"\n**Columns ({len(tbl.columns)}):**")
            for col in tbl.columns:
                if col.is_hidden:
                    continue
                desc = f" — {col.description}" if col.description else ""
                lines.append(f"  - `{col.name}` ({col.data_type}){desc}")

        if tbl.measures:
            lines.append(f"\n**Measures ({len(tbl.measures)}):**")
            for m in tbl.measures:
                desc = f" — {m.description}" if m.description else ""
                expr_preview = m.expression[:100] + "..." if len(m.expression) > 100 else m.expression
                lines.append(f"  - `{m.name}` = `{expr_preview}`{desc}")
        lines.append("")

    # Relationships
    if model.relationships:
        lines.append("## 🔗 Relationships\n")
        lines.append("| From | → | To | Cardinality | Active |")
        lines.append("|------|---|-----|-------------|--------|")
        for rel in model.relationships:
            card = f"{rel.from_cardinality}:{rel.to_cardinality}"
            active = "✅" if rel.is_active else "❌"
            lines.append(f"| {rel.from_table}.{rel.from_column} | → | {rel.to_table}.{rel.to_column} | {card} | {active} |")
        lines.append("")

    # Roles
    if model.roles:
        lines.append("## 🔐 Roles\n")
        for role in model.roles:
            lines.append(f"  - **{role.name}** (permission: {role.model_permission})")
            for tp in role.table_permissions:
                lines.append(f"    - {tp.get('table', '')}: `{tp.get('filter', '')}`")

    return "\n".join(lines)


# ── Tool 5: Export Lineage HTML ──────────────────────────────────────

@mcp.tool()
async def export_lineage_html(
    output_path: str = "",
) -> str:
    """Export the last generated lineage as an interactive D3 tree visualization (HTML file).

    Args:
        output_path: File path to save HTML (default: auto-generated in current directory).

    Opens the visualization in your default browser. The HTML file is self-contained
    with all JavaScript/CSS inlined — no server needed, works offline.

    Run generate_lineage first to populate the lineage data.
    """
    global _last_lineage

    if not _last_lineage:
        return "No lineage data available. Run `generate_lineage` first."

    lineage_json = _last_lineage.model_dump()

    # Load HTML template
    template_path = os.path.join(os.path.dirname(__file__), "viz", "template.html")
    with open(template_path, "r", encoding="utf-8") as f:
        template = f.read()

    # Inject lineage data
    html = template.replace("__LINEAGE_DATA_PLACEHOLDER__", json.dumps(lineage_json, default=str))

    # Determine output path
    if not output_path:
        model_name = _last_lineage.model.name.replace(" ", "_").replace("/", "_")
        output_path = os.path.join(os.getcwd(), f"lineage_{model_name}.html")

    with open(output_path, "w", encoding="utf-8") as f:
        f.write(html)

    # Open in browser
    try:
        webbrowser.open(f"file://{os.path.abspath(output_path)}")
    except Exception:
        pass

    return f"Interactive lineage visualization saved to `{output_path}` and opened in browser."


# ── Tool 6: Cross-Workspace Lineage ─────────────────────────────────

@mcp.tool()
async def cross_workspace_lineage(
    dataset_id: str = "",
    workspace_id: str = "",
) -> str:
    """Trace a semantic model's usage across ALL workspaces. Finds every report
    that uses this model, even in different workspaces. Full depth lineage.

    Args:
        dataset_id: The semantic model ID to trace. Optional if you ran generate_lineage.
        workspace_id: The workspace containing the model. Optional if you ran generate_lineage.

    First scans all workspaces to find cross-workspace links, then generates
    deep lineage including reports from other workspaces.
    """
    global _portfolio, _last_lineage, _last_workspace_id

    client = _get_client()

    # Determine which model to trace
    ds_id = dataset_id
    ws_id = workspace_id
    if not ds_id and _last_lineage:
        ds_id = _last_lineage.model.id
        ws_id = ws_id or _last_workspace_id
    if not ds_id:
        return "No dataset specified. Provide dataset_id and workspace_id, or run generate_lineage first."

    # Phase 1: Portfolio scan (if not cached)
    if not _portfolio:
        _portfolio = await scan_portfolio(client)

    # Look up model info
    model_loc = _portfolio.dataset_locations.get(ds_id)
    if not model_loc:
        return f"Dataset `{ds_id}` not found in any workspace."

    ws_id = ws_id or model_loc[0]
    model_ws_name = model_loc[1]
    model_name = model_loc[2]

    # Find cross-workspace links for this model
    cross_links = [
        link for link in _portfolio.cross_workspace_links
        if link.model_id == ds_id
    ]

    # Phase 2: Deep scan with cross-workspace reports
    lineage = await deep_scan_model(
        client, ws_id, ds_id, model_name, _portfolio
    )

    if lineage:
        _last_lineage = lineage
        _last_workspace_id = ws_id

    # Format output
    lines: list[str] = []
    lines.append(f"# Cross-Workspace Lineage for {model_name}\n")
    lines.append(f"**Model workspace:** {model_ws_name}\n")

    # Same-workspace reports
    same_ws_reports = [
        r for r in (lineage.reports if lineage else [])
        if f"({model_ws_name})" not in r.name  # cross-ws reports have workspace name appended
        and not any(
            link.report_name in r.name for link in cross_links
        )
    ]

    if same_ws_reports:
        lines.append(f"## 📍 Same workspace ({model_ws_name}) — {len(same_ws_reports)} report(s)\n")
        for report in same_ws_reports:
            lines.append(f"  - **{report.name}** ({len(report.pages)} pages)")
            for page in report.pages:
                visual_count = len(page.visuals)
                if visual_count:
                    lines.append(f"    - 📑 {page.display_name} ({visual_count} visuals)")

    if cross_links:
        # Group by target workspace
        ws_groups: dict[str, list] = {}
        for link in cross_links:
            ws_groups.setdefault(link.report_workspace_name, []).append(link)

        lines.append(f"\n## 🌐 Cross-workspace — {len(cross_links)} report(s) in {len(ws_groups)} other workspace(s)\n")

        for target_ws, links in ws_groups.items():
            lines.append(f"### 📍 {target_ws}\n")
            for link in links:
                # Find the parsed report
                matching = [
                    r for r in (lineage.reports if lineage else [])
                    if r.id == link.report_id
                ]
                if matching:
                    report = matching[0]
                    lines.append(f"  - **{link.report_name}** ({len(report.pages)} pages)")
                    for page in report.pages:
                        visual_count = len(page.visuals)
                        if visual_count:
                            lines.append(f"    - 📑 {page.display_name} ({visual_count} visuals)")
                            for visual in page.visuals:
                                fields = [f.field_name for f in visual.field_bindings]
                                if fields:
                                    lines.append(f"      - 📈 {visual.visual_type} → {', '.join(fields)}")
                else:
                    lines.append(f"  - **{link.report_name}**")
    else:
        lines.append("\n## 🌐 Cross-workspace\n")
        lines.append("No reports in other workspaces use this model.")

    # Summary
    total_reports = len(lineage.reports) if lineage else 0
    lines.append(f"\n---\n**Total:** {total_reports} report(s) across {1 + len(set(l.report_workspace_name for l in cross_links))} workspace(s)")

    if lineage:
        lines.append(f"\nFull lineage tree available — use `export_lineage_html` to visualize.")

    return "\n".join(lines)


# ── Tool 7: Governance Health Score ──────────────────────────────────

@mcp.tool()
async def governance_health_score(
    workspace_id: str = "",
    dataset_id: str = "",
) -> str:
    """Score the governance quality of a semantic model or workspace (0-100).

    Checks for: unused tables, missing descriptions, orphan measures,
    missing format strings, missing relationships, empty tables.

    Args:
        workspace_id: Workspace to score. If empty, uses the last workspace.
        dataset_id: Optional specific model. If empty, scores all models in workspace.

    Returns a health score with detailed issues and recommendations.
    """
    global _last_lineage, _last_workspace_id

    client = _get_client()
    ws_id = workspace_id or _last_workspace_id

    if not ws_id:
        return "No workspace specified. Provide workspace_id or run generate_lineage first."

    if dataset_id:
        # Score a specific model
        if _last_lineage and _last_lineage.model.id == dataset_id:
            lineage = _last_lineage
        else:
            # Generate fresh
            items = await client.get_workspace_items(ws_id)
            ds_name = dataset_id
            for ds in items.get("datasets", []):
                if ds.get("id") == dataset_id:
                    ds_name = ds.get("name", dataset_id)
                    break

            raw_model = await client.get_semantic_model_definition(ws_id, dataset_id)
            if not raw_model:
                return f"Could not retrieve model `{dataset_id}`. Check permissions."
            model = parse_semantic_model(raw_model, dataset_id, ds_name)
            report_dicts = await client.get_reports_for_dataset(ws_id, dataset_id)
            reports: list[ReportInfo] = []
            for rd in report_dicts:
                rid = rd.get("id", "")
                rname = rd.get("name", "Unknown")
                raw_report = await client.get_report_definition(ws_id, rid)
                if raw_report:
                    reports.append(parse_report_definition(raw_report, rid, rname, dataset_id))
                else:
                    reports.append(ReportInfo(id=rid, name=rname, dataset_id=dataset_id))
            lineage = build_lineage(model, reports, ws_id)
            _last_lineage = lineage
            _last_workspace_id = ws_id

        health = calculate_model_health(lineage.model, lineage.reports)
        return format_health_score(health, lineage.model.name)
    else:
        # Score all models in workspace
        items = await client.get_workspace_items(ws_id)
        datasets = items.get("datasets", [])

        if not datasets:
            return "No semantic models found in this workspace."

        # Get workspace name
        ws_name = ws_id
        workspaces = await client.list_workspaces()
        for ws in workspaces:
            if ws.get("id") == ws_id:
                ws_name = ws.get("name", ws_id)
                break

        lines: list[str] = [f"# Governance Health — {ws_name}\n"]
        lines.append(f"Scanning {len(datasets)} semantic model(s)...\n")

        total_score = 0
        model_count = 0

        for ds in datasets:
            ds_id = ds.get("id", "")
            ds_name = ds.get("name", "Unknown")

            raw_model = await client.get_semantic_model_definition(ws_id, ds_id)
            if not raw_model:
                lines.append(f"⚠️ **{ds_name}** — could not access (permissions?)\n")
                continue

            model = parse_semantic_model(raw_model, ds_id, ds_name)
            report_dicts = await client.get_reports_for_dataset(ws_id, ds_id)
            reports = []
            for rd in report_dicts:
                rid = rd.get("id", "")
                rname = rd.get("name", "Unknown")
                raw_report = await client.get_report_definition(ws_id, rid)
                if raw_report:
                    reports.append(parse_report_definition(raw_report, rid, rname, ds_id))
                else:
                    reports.append(ReportInfo(id=rid, name=rname, dataset_id=ds_id))

            health = calculate_model_health(model, reports)
            total_score += health.score
            model_count += 1

            filled = health.score // 5
            empty = 20 - filled
            bar = "█" * filled + "░" * empty
            issue_count = len([i for i in health.issues if i.severity in ("warning", "error")])
            lines.append(f"**{ds_name}** — {health.score}/100 {bar} ({issue_count} issues)")

        if model_count > 0:
            avg = round(total_score / model_count)
            filled = avg // 5
            empty = 20 - filled
            bar = "█" * filled + "░" * empty
            lines.insert(2, f"**Overall Score: {avg}/100** {bar}\n")

        return "\n".join(lines)


# ── Server entry point ───────────────────────────────────────────────

def run_server() -> None:
    """Start the MCP server (stdio transport)."""
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")
    mcp.run(transport="stdio")
