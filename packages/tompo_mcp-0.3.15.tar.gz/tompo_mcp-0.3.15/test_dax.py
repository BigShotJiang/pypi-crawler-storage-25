import asyncio, sys, logging
logging.disable(logging.CRITICAL)
print("=" * 60)
print("END-TO-END TEST: tompo-mcp v0.3.4 measures fix")
print("=" * 60)

async def test():
    from tompo_mcp.server import generate_lineage
    
    workspace_id = '5df943f8-184c-440b-b4fb-d2934ddc911a'
    
    # TEST 1: OneHR (measures fix - should show measures now)
    print("\n[TEST 1] OneHR - measures should be detected")
    print("-" * 50)
    result1 = await generate_lineage(
        workspace_id=workspace_id,
        dataset_id='535de7f2-7ea0-49ba-addb-d51df167d0fe',
        dataset_name="OneHR"
    )
    m1 = [l for l in result1.split('\n') if '[M]' in l]
    c1 = [l for l in result1.split('\n') if '[C]' in l]
    print(f"  Measures: {len(m1)}")
    print(f"  Columns:  {len(c1)}")
    if m1:
        print(f"  Sample measures:")
        for l in m1[:5]:
            print(f"    {l.strip()}")
    test1_pass = len(m1) > 0
    print(f"  RESULT: {'PASS' if test1_pass else 'FAIL'}")
    
    # TEST 2: TOMPo_HRDI (regression check - should still work)
    print("\n[TEST 2] TOMPo_HRDI - regression check")
    print("-" * 50)
    result2 = await generate_lineage(
        workspace_id=workspace_id,
        dataset_id='1f25ab8f-cf9f-438a-814e-06785b03c51d',
        dataset_name="TOMPo_HRDI"
    )
    m2 = [l for l in result2.split('\n') if '[M]' in l]
    c2 = [l for l in result2.split('\n') if '[C]' in l]
    print(f"  Measures: {len(m2)}")
    print(f"  Columns:  {len(c2)}")
    test2_pass = len(c2) > 50  # Should have ~81 columns
    print(f"  RESULT: {'PASS' if test2_pass else 'FAIL'}")
    
    print("\n" + "=" * 60)
    if test1_pass and test2_pass:
        print("ALL TESTS PASSED")
    else:
        print("SOME TESTS FAILED")
    print("=" * 60)

asyncio.run(test())