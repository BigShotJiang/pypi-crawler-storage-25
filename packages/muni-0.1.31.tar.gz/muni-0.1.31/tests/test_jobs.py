import unittest
import contextlib
import io
import json
from types import SimpleNamespace
from unittest.mock import patch

from muni import cli
from muni.client import MuniClient


class JobsSearchStub:
    def __init__(self) -> None:
        self.calls: list[dict] = []

    def search(self, **kwargs):
        self.calls.append(kwargs)
        return [
            SimpleNamespace(model_dump=lambda by_alias=False: {
                "id": "job-row-1",
                "call_id": "job_123",
                "tool_name": "onepot-rbfe-demo",
                "status": "completed",
                "created_at": "2026-05-06T12:00:00Z",
            })
        ]


class JobsTests(unittest.TestCase):
    def test_list_jobs_passes_tool_filter_to_sdk_search(self) -> None:
        client = object.__new__(MuniClient)
        client.jobs = JobsSearchStub()

        rows = client.list_jobs(
            space_id="space_123",
            status="completed",
            tool_name="onepot-rbfe-demo",
            limit=50,
        )

        self.assertEqual(client.jobs.calls, [{
            "space_id": "space_123",
            "status": "completed",
            "tool_name": "onepot-rbfe-demo",
            "limit": 50,
        }])
        self.assertEqual(rows[0]["job_type"], "onepot-rbfe-demo")

    def test_job_nodes_json_command_emits_full_agent_context(self) -> None:
        plan = {
            "status": "ready",
            "job_id": "job_a979f94b-9b6e-499c-9580-0505df3ee29e",
            "call_id": "rw-7277a60a-dc0e-410a-b3c1-fed3186a40e3",
            "tool_name": "rowan_rbfe",
            "nodes": [
                {
                    "type": "chart",
                    "title": "RBFE results network",
                    "output_key": "rbfe_network",
                    "view_key": "rbfe_results_chart",
                    "renderer": {
                        "kind": "agent_prompt",
                        "prompt": "Create a D3 RBFE network chart.",
                        "examples": [
                            {
                                "title": "RBFE ligand table and molecule-card results chart",
                                "views": [
                                    {
                                        "view_key": "rbfe_results_chart",
                                        "node_type": "chart",
                                        "script_path": "docs/canvas-examples/rowan-rbfe-test1-results-chart.tsx",
                                        "script": "export default node('chart', () => null)",
                                        "example_context": {
                                            "markdown": "# Canvas materialization example",
                                        },
                                    }
                                ],
                            }
                        ],
                    },
                }
            ],
        }

        class JobNodesStub:
            def __init__(self) -> None:
                self.calls: list[str] = []

            def job_nodes(self, call_id: str):
                self.calls.append(call_id)
                return 200, plan

        stub = JobNodesStub()
        args = SimpleNamespace(
            job_action="nodes",
            apply=False,
            call_id="job_a979f94b-9b6e-499c-9580-0505df3ee29e",
            json=True,
        )

        output = io.StringIO()
        with patch.object(cli, "MuniClient", return_value=stub), contextlib.redirect_stdout(output):
            cli.cmd_job(args)

        payload = json.loads(output.getvalue())
        self.assertEqual(stub.calls, ["job_a979f94b-9b6e-499c-9580-0505df3ee29e"])
        chart_node = payload["nodes"][0]
        self.assertEqual(chart_node["renderer"]["kind"], "agent_prompt")
        self.assertIn("script", chart_node["renderer"]["examples"][0]["views"][0])
        self.assertIn("example_context", chart_node["renderer"]["examples"][0]["views"][0])


if __name__ == "__main__":
    unittest.main()
