import unittest

from muni import display


class DisplayTests(unittest.TestCase):
    def test_spaces_table_marks_active_space(self) -> None:
        output = display.format_spaces_table(
            [
                {"id": "space-1", "name": "Alpha", "owner_id": "owner"},
                {"id": "space-2", "name": "Beta", "owner_id": "owner"},
            ],
            active_space_id="space-2",
        )
        self.assertIn("*", output)
        self.assertIn("space-2", output)

    def test_nodes_table_includes_columns(self) -> None:
        output = display.format_nodes_table([
            {
                "id": "node-1",
                "type": "structure",
                "title": "1UBQ",
                "hasScript": True,
                "positionX": 12,
                "positionY": 34,
            },
        ])
        self.assertIn("Type", output)
        self.assertIn("Title", output)
        self.assertIn("Script", output)
        self.assertIn("Position", output)
        self.assertIn("(12, 34)", output)
        self.assertIn("yes", output)

    def test_tool_outputs_includes_materialization_examples(self) -> None:
        output = display.format_tool_outputs({
            "outputs": [
                {
                    "key": "rbfe_network",
                    "kind": "plot_data",
                    "source": {
                        "type": "file",
                        "path": "materialized/rowan_rbfe_results_network.json",
                        "format": "json_object",
                    },
                }
            ],
            "views": [
                {
                    "key": "rbfe_results_chart",
                    "output": "rbfe_network",
                    "view": "chart",
                    "auto": True,
                }
            ],
            "materialization_examples": [
                {
                    "title": "RBFE ligand table and molecule-card results chart",
                    "job_id": "job_a979f94b-9b6e-499c-9580-0505df3ee29e",
                    "call_id": "rw-7277a60a-dc0e-410a-b3c1-fed3186a40e3",
                    "views": [
                        {
                            "view_key": "rbfe_results_chart",
                            "node_type": "chart",
                            "script_path": "docs/canvas-examples/rowan-rbfe-test1-results-chart.tsx",
                            "script_size_bytes": 11366,
                            "example_context": {
                                "markdown": "# Canvas materialization example"
                            },
                        }
                    ],
                }
            ],
        })

        self.assertIn("Materialization Examples", output)
        self.assertIn("RBFE ligand table and molecule-card results chart", output)
        self.assertIn("rbfe_results_chart: chart", output)
        self.assertIn("example_context.markdown", output)

    def test_job_nodes_includes_renderer_examples(self) -> None:
        output = display.format_job_nodes({
            "status": "ready",
            "job_id": "job_a979f94b-9b6e-499c-9580-0505df3ee29e",
            "call_id": "rw-7277a60a-dc0e-410a-b3c1-fed3186a40e3",
            "tool_name": "rowan_rbfe",
            "nodes": [
                {
                    "type": "chart",
                    "title": "RBFE results network",
                    "output_key": "rbfe_network",
                    "view_key": "rbfe_results_chart",
                    "source_file": {
                        "path": "materialized/rowan_rbfe_results_network.json",
                        "exists": True,
                    },
                    "renderer": {
                        "kind": "agent_prompt",
                        "examples": [
                            {
                                "title": "RBFE ligand table and molecule-card results chart",
                                "views": [
                                    {
                                        "view_key": "rbfe_results_chart",
                                        "script_path": "docs/canvas-examples/rowan-rbfe-test1-results-chart.tsx",
                                        "script_size_bytes": 11366,
                                        "example_context": {
                                            "markdown": "# Canvas materialization example"
                                        },
                                    }
                                ],
                            }
                        ],
                    },
                }
            ],
        })

        self.assertIn("Job nodes for job_a979f94b-9b6e-499c-9580-0505df3ee29e", output)
        self.assertIn("rbfe_results_chart: chart from rbfe_network", output)
        self.assertIn("renderer: agent_prompt (1 example)", output)
        self.assertIn("example_context.markdown", output)
        self.assertIn("re-run with --json", output)
        self.assertIn("inline code examples", output)

    def test_job_nodes_apply_summary(self) -> None:
        output = display.format_job_nodes_apply({
            "plan": {
                "callId": "rw-7277a60a-dc0e-410a-b3c1-fed3186a40e3",
                "nodes": [
                    {
                        "nodeType": "chart",
                        "title": "RBFE results network",
                        "outputKey": "rbfe_network",
                        "viewKey": "rbfe_results_chart",
                    }
                ],
            },
            "materialization": {
                "status": "materialized",
                "nodes": [
                    {
                        "nodeId": "node_chart",
                        "outputKey": "rbfe_network",
                        "viewKey": "rbfe_results_chart",
                        "status": "exists",
                    }
                ],
                "chartRendererTasks": [
                    {
                        "nodeId": "node_chart",
                        "examples": [{"title": "Example"}],
                    }
                ],
            },
        })

        self.assertIn("Materialized job nodes for rw-7277a60a-dc0e-410a-b3c1-fed3186a40e3", output)
        self.assertIn("node_chart: chart — RBFE results network", output)
        self.assertIn("[exists]", output)
        self.assertIn("Chart renderer tasks", output)


if __name__ == "__main__":
    unittest.main()
