import contextlib
import io
import json
import unittest
from types import SimpleNamespace
from unittest.mock import patch

from muni import cli


class RunParamTests(unittest.TestCase):
    def test_boolean_values_are_coerced_from_cli_strings(self) -> None:
        tool = {
            "parameters": {
                "properties": {
                    "use_msa": {"type": "boolean"},
                    "run_local_optimization": {"type": "boolean"},
                    "require_posebusters": {"type": "boolean"},
                }
            }
        }
        kwargs = cli._parse_kv([
            "use_msa=False",
            "run_local_optimization=True",
            "require_posebusters=0",
        ])

        coerced = cli._coerce_kwargs_against_tool(tool, kwargs)

        self.assertIs(coerced["use_msa"], False)
        self.assertIs(coerced["run_local_optimization"], True)
        self.assertIs(coerced["require_posebusters"], False)
        self.assertEqual(cli._validate_kwargs_against_tool(tool, coerced), [])

    def test_run_print_job_id_outputs_only_full_job_id(self) -> None:
        full_job_id = "job_f28c824c-d42f-4669-b1aa-123456789abc"

        class RunStub:
            def __init__(self) -> None:
                self.calls: list[dict] = []

            def get_tool(self, name: str) -> dict:
                self.calls.append({"method": "get_tool", "name": name})
                return {
                    "parameters": {
                        "properties": {
                            "use_msa": {"type": "boolean"},
                        }
                    }
                }

            def run(self, tool: str, kwargs: dict, **opts):
                self.calls.append({"method": "run", "tool": tool, "kwargs": kwargs, **opts})
                return {"job_id": full_job_id, "call_id": "rw-123", "status": "submitted"}

        stub = RunStub()
        args = SimpleNamespace(
            batch=None,
            params=["use_msa=False"],
            params_file=None,
            validate=True,
            dry_run=False,
            tool="boltz_affinity",
            space_id=None,
            page_id=None,
            no_space=True,
            title=None,
            follow=False,
            timeout=1800,
            json=True,
            log_lines=120,
            print_job_id=True,
        )

        output = io.StringIO()
        with patch.object(cli, "MuniClient", return_value=stub), contextlib.redirect_stdout(output):
            cli.cmd_run(args)

        self.assertEqual(output.getvalue(), f"{full_job_id}\n")
        run_call = [call for call in stub.calls if call["method"] == "run"][0]
        self.assertIs(run_call["kwargs"]["use_msa"], False)

    def test_dry_run_uses_coerced_boolean_values(self) -> None:
        class ToolStub:
            def get_tool(self, name: str) -> dict:
                return {
                    "parameters": {
                        "properties": {
                            "require_posebusters": {"type": "boolean"},
                        }
                    }
                }

        args = SimpleNamespace(
            batch=None,
            params=["require_posebusters=True"],
            params_file=None,
            validate=True,
            dry_run=True,
            tool="rowan_analogue_docking",
            space_id=None,
            page_id=None,
            no_space=True,
            title=None,
            follow=False,
            timeout=1800,
            json=True,
            log_lines=120,
            print_job_id=False,
        )

        output = io.StringIO()
        with patch.object(cli, "MuniClient", return_value=ToolStub()), contextlib.redirect_stdout(output):
            cli.cmd_run(args)

        payload = json.loads(output.getvalue())
        self.assertIs(payload["params"]["require_posebusters"], True)


if __name__ == "__main__":
    unittest.main()
