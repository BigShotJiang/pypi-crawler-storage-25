import unittest
import urllib.error
from unittest.mock import patch

from muni import api
from muni.exceptions import APIError


class ApiTests(unittest.TestCase):
    def test_request_wraps_url_errors(self) -> None:
        with patch("urllib.request.urlopen", side_effect=urllib.error.URLError("no route")):
            with self.assertRaises(APIError) as ctx:
                api.list_files("https://bad.example", "job_123", "user_123")

        self.assertIn("Unable to reach Muni API", str(ctx.exception))
        self.assertIn("https://bad.example", str(ctx.exception))


if __name__ == "__main__":
    unittest.main()
