import unittest
import urllib.error
from unittest.mock import patch

from muni.clients._base import SDKClientBase
from muni.exceptions import APIError


class FakeClient:
    app_url = "https://muni.example"

    def _auth(self) -> tuple[str, str]:
        return "token_123", "user_123"


class FakeSDKClient(SDKClientBase):
    _namespace = "fake"


class SDKBaseTests(unittest.TestCase):
    def test_call_wraps_url_errors(self) -> None:
        client = FakeSDKClient(FakeClient())

        with patch("urllib.request.urlopen", side_effect=urllib.error.URLError("no route")):
            with self.assertRaises(APIError) as ctx:
                client._call("search")

        self.assertIn("Unable to reach Muni app", str(ctx.exception))
        self.assertIn("https://muni.example", str(ctx.exception))


if __name__ == "__main__":
    unittest.main()
