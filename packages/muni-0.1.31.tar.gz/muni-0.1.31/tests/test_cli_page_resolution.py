import contextlib
import io
import json
import os
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from muni import cli
from muni.config import load_config


class CliPageResolutionTests(unittest.TestCase):
    def test_run_with_space_id_resolves_default_page(self) -> None:
        class RunStub:
            def __init__(self) -> None:
                self.calls: list[dict] = []
                self.nodes = self

            def run(self, tool: str, kwargs: dict, **opts):
                self.calls.append({"tool": tool, "kwargs": kwargs, **opts})
                return {"job_id": "job_123", "call_id": "rw-123", "status": "submitted"}

            def create(self, page_id: str, title: str, **opts):
                self.calls.append({"method": "nodes.create", "page_id": page_id, "title": title, **opts})
                return {"nodeId": "node_123"}

            def submit(self, node_id: str):
                self.calls.append({"method": "nodes.submit", "node_id": node_id})
                return {"jobId": "job_123", "callId": "rw-123", "status": "submitted"}

        stub = RunStub()
        args = SimpleNamespace(
            batch=None,
            params=[],
            params_file=None,
            validate=False,
            dry_run=False,
            tool="rowan_batch_docking",
            space_id="space-new",
            page_id=None,
            title=None,
            follow=False,
            timeout=1800,
            json=True,
            log_lines=120,
        )

        output = io.StringIO()
        with patch.object(cli, "MuniClient", return_value=stub), \
             patch.object(cli, "get_active_page_id", return_value="page-first") as resolve_page, \
             contextlib.redirect_stdout(output):
            cli.cmd_run(args)

        payload = json.loads(output.getvalue())
        self.assertEqual(payload["job_id"], "job_123")
        self.assertEqual(payload["node_id"], "node_123")
        resolve_page.assert_called_once_with(None, space_id="space-new")
        self.assertEqual(stub.calls[0]["method"], "nodes.create")
        self.assertEqual(stub.calls[0]["page_id"], "page-first")
        self.assertEqual(stub.calls[0]["type"], "job")
        self.assertEqual(stub.calls[1], {"method": "nodes.submit", "node_id": "node_123"})

    def test_run_uses_active_space_and_page_by_default(self) -> None:
        class RunStub:
            def __init__(self) -> None:
                self.calls: list[dict] = []
                self.nodes = self

            def run(self, tool: str, kwargs: dict, **opts):
                self.calls.append({"tool": tool, "kwargs": kwargs, **opts})
                return {"job_id": "job_123", "status": "submitted"}

            def create(self, page_id: str, title: str, **opts):
                self.calls.append({"method": "nodes.create", "page_id": page_id, "title": title, **opts})
                return {"nodeId": "node_123"}

            def submit(self, node_id: str):
                self.calls.append({"method": "nodes.submit", "node_id": node_id})
                return {"jobId": "job_123", "callId": "rw-123", "status": "submitted"}

        with tempfile.TemporaryDirectory() as home:
            muni_dir = Path(home) / ".muni"
            muni_dir.mkdir()
            (muni_dir / "config.json").write_text(json.dumps({
                "current_profile": "default",
                "profiles": {
                    "default": {
                        "active_space_id": "space-active",
                        "active_page_id": "page-active",
                    }
                },
            }))

            stub = RunStub()
            args = SimpleNamespace(
                batch=None,
                params=[],
                params_file=None,
                validate=False,
                dry_run=False,
                tool="crem",
                space_id=None,
                page_id=None,
                no_space=False,
                title=None,
                follow=False,
                timeout=1800,
                json=True,
                log_lines=120,
            )

            output = io.StringIO()
            with patch.dict(os.environ, {
                "HOME": home,
                "MUNI_PROFILE": "",
                "MUNI_SPACE_ID": "",
                "MUNI_PAGE_ID": "",
            }, clear=False), \
                 patch.object(cli, "MuniClient", return_value=stub), \
                 contextlib.redirect_stdout(output):
                cli.cmd_run(args)

        payload = json.loads(output.getvalue())
        self.assertEqual(payload["job_id"], "job_123")
        self.assertEqual(payload["node_id"], "node_123")
        self.assertEqual(stub.calls[0]["method"], "nodes.create")
        self.assertEqual(stub.calls[0]["page_id"], "page-active")
        self.assertEqual(stub.calls[1], {"method": "nodes.submit", "node_id": "node_123"})

    def test_run_no_space_ignores_active_space_and_page(self) -> None:
        class RunStub:
            def __init__(self) -> None:
                self.calls: list[dict] = []

            def run(self, tool: str, kwargs: dict, **opts):
                self.calls.append({"tool": tool, "kwargs": kwargs, **opts})
                return {"job_id": "job_123", "status": "submitted"}

        with tempfile.TemporaryDirectory() as home:
            muni_dir = Path(home) / ".muni"
            muni_dir.mkdir()
            (muni_dir / "config.json").write_text(json.dumps({
                "current_profile": "default",
                "profiles": {
                    "default": {
                        "active_space_id": "space-active",
                        "active_page_id": "page-active",
                    }
                },
            }))

            stub = RunStub()
            args = SimpleNamespace(
                batch=None,
                params=[],
                params_file=None,
                validate=False,
                dry_run=False,
                tool="crem",
                space_id=None,
                page_id=None,
                no_space=True,
                title=None,
                follow=False,
                timeout=1800,
                json=True,
                log_lines=120,
            )

            output = io.StringIO()
            with patch.dict(os.environ, {
                "HOME": home,
                "MUNI_PROFILE": "",
                "MUNI_SPACE_ID": "",
                "MUNI_PAGE_ID": "",
            }, clear=False), \
                 patch.object(cli, "MuniClient", return_value=stub), \
                 contextlib.redirect_stdout(output):
                cli.cmd_run(args)

        self.assertEqual(json.loads(output.getvalue())["job_id"], "job_123")
        self.assertIsNone(stub.calls[0]["space_id"])
        self.assertIsNone(stub.calls[0]["page_id"])

    def test_job_nodes_apply_with_space_id_resolves_default_page(self) -> None:
        class MaterializeStub:
            def __init__(self) -> None:
                self.calls: list[dict] = []

            def materialize_job_nodes(self, call_id: str, **opts):
                self.calls.append({"call_id": call_id, **opts})
                return {"ok": True}

        stub = MaterializeStub()
        args = SimpleNamespace(
            job_action="nodes",
            apply=True,
            call_id="rw-123",
            space_id="space-new",
            page_id=None,
            launcher_node_id=None,
            no_space=False,
            no_refresh_contract=False,
            no_prune_stale=False,
            json=True,
        )

        output = io.StringIO()
        with patch.object(cli, "MuniClient", return_value=stub), \
             patch.object(cli, "get_active_page_id", return_value="page-first") as resolve_page, \
             contextlib.redirect_stdout(output):
            cli.cmd_job(args)

        self.assertEqual(json.loads(output.getvalue()), {"ok": True})
        resolve_page.assert_called_once_with(None, space_id="space-new")
        self.assertEqual(stub.calls[0]["space_id"], "space-new")
        self.assertEqual(stub.calls[0]["page_id"], "page-first")

    def test_job_nodes_apply_uses_active_space_and_page_by_default(self) -> None:
        class MaterializeStub:
            def __init__(self) -> None:
                self.calls: list[dict] = []

            def materialize_job_nodes(self, call_id: str, **opts):
                self.calls.append({"call_id": call_id, **opts})
                return {"ok": True}

        with tempfile.TemporaryDirectory() as home:
            muni_dir = Path(home) / ".muni"
            muni_dir.mkdir()
            (muni_dir / "config.json").write_text(json.dumps({
                "current_profile": "default",
                "profiles": {
                    "default": {
                        "active_space_id": "space-active",
                        "active_page_id": "page-active",
                    }
                },
            }))

            stub = MaterializeStub()
            args = SimpleNamespace(
                job_action="nodes",
                apply=True,
                call_id="rw-123",
                space_id=None,
                page_id=None,
                launcher_node_id=None,
                no_space=False,
                no_refresh_contract=False,
                no_prune_stale=False,
                json=True,
            )

            output = io.StringIO()
            with patch.dict(os.environ, {
                "HOME": home,
                "MUNI_PROFILE": "",
                "MUNI_SPACE_ID": "",
                "MUNI_PAGE_ID": "",
            }, clear=False), \
                 patch.object(cli, "MuniClient", return_value=stub), \
                 contextlib.redirect_stdout(output):
                cli.cmd_job(args)

        self.assertEqual(json.loads(output.getvalue()), {"ok": True})
        self.assertEqual(stub.calls[0]["space_id"], "space-active")
        self.assertEqual(stub.calls[0]["page_id"], "page-active")

    def test_space_use_none_clears_active_space_and_page(self) -> None:
        with tempfile.TemporaryDirectory() as home:
            muni_dir = Path(home) / ".muni"
            muni_dir.mkdir()
            (muni_dir / "config.json").write_text(json.dumps({
                "current_profile": "default",
                "profiles": {
                    "default": {
                        "active_space_id": "space-active",
                        "active_page_id": "page-active",
                    }
                },
            }))

            args = SimpleNamespace(space_action="use", space_id="none", json=True)
            output = io.StringIO()
            with patch.dict(os.environ, {
                "HOME": home,
                "MUNI_PROFILE": "",
                "MUNI_SPACE_ID": "",
                "MUNI_PAGE_ID": "",
            }, clear=False), \
                 patch.object(cli, "MuniClient"), \
                 contextlib.redirect_stdout(output):
                cli.cmd_space(args)

            with patch.dict(os.environ, {
                "HOME": home,
                "MUNI_PROFILE": "",
                "MUNI_SPACE_ID": "",
                "MUNI_PAGE_ID": "",
            }, clear=False):
                cfg = load_config()

        self.assertEqual(json.loads(output.getvalue()), {
            "active_space_id": None,
            "active_page_id": None,
            "mode": "api-only",
        })
        self.assertNotIn("active_space_id", cfg)
        self.assertNotIn("active_page_id", cfg)

    def test_page_use_accepts_exact_page_title(self) -> None:
        class PageStub:
            def get_page(self, page_id: str, *, space_id: str | None = None):
                raise RuntimeError("not an id")

            def list_pages(self, space_id: str):
                return [
                    {"id": "page-one", "title": "Page 1", "space_id": space_id},
                    {"id": "page-two", "title": "Chemistry", "space_id": space_id},
                ]

        with tempfile.TemporaryDirectory() as home:
            muni_dir = Path(home) / ".muni"
            muni_dir.mkdir()
            (muni_dir / "config.json").write_text(json.dumps({
                "current_profile": "default",
                "profiles": {
                    "default": {
                        "active_space_id": "space-active",
                        "active_page_id": "page-one",
                    }
                },
            }))

            args = SimpleNamespace(page_action="use", page_id="Chemistry", space_id=None, json=True)
            output = io.StringIO()
            with patch.dict(os.environ, {
                "HOME": home,
                "MUNI_PROFILE": "",
                "MUNI_SPACE_ID": "",
                "MUNI_PAGE_ID": "",
            }, clear=False), \
                 patch.object(cli, "MuniClient", return_value=PageStub()), \
                 contextlib.redirect_stdout(output):
                cli.cmd_page(args)

            with patch.dict(os.environ, {
                "HOME": home,
                "MUNI_PROFILE": "",
                "MUNI_SPACE_ID": "",
                "MUNI_PAGE_ID": "",
            }, clear=False):
                cfg = load_config()

        self.assertEqual(json.loads(output.getvalue()), {"active_page_id": "page-two", "title": "Chemistry"})
        self.assertEqual(cfg["active_space_id"], "space-active")
        self.assertEqual(cfg["active_page_id"], "page-two")


if __name__ == "__main__":
    unittest.main()
