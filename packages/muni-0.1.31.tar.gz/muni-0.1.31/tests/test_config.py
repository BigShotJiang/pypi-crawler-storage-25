import json
import os
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock, patch

from muni.config import DEFAULTS, get_active_page_id, load_config, list_profiles, load_credentials


class ConfigTests(unittest.TestCase):
    def test_load_config_replaces_retired_bioarena_api_hosts(self) -> None:
        with tempfile.TemporaryDirectory() as home:
            muni_dir = Path(home) / ".muni"
            muni_dir.mkdir()
            (muni_dir / "config.json").write_text(json.dumps({
                "current_profile": "default",
                "profiles": {
                    "default": {
                        "api_url": "https://bioarena-api-tools-production.up.railway.app",
                        "sandbox_tools_api_url": "https://api.bioarena.com",
                    }
                },
            }))

            with patch.dict(os.environ, {
                "HOME": home,
                "MUNI_API_URL": "",
                "MUNI_PROFILE": "",
            }, clear=False):
                cfg = load_config()

        self.assertEqual(cfg["api_url"], DEFAULTS["api_url"])
        self.assertEqual(cfg["sandbox_tools_api_url"], DEFAULTS["sandbox_tools_api_url"])

    def test_load_config_preserves_custom_api_hosts(self) -> None:
        with tempfile.TemporaryDirectory() as home:
            muni_dir = Path(home) / ".muni"
            muni_dir.mkdir()
            (muni_dir / "config.json").write_text(json.dumps({
                "current_profile": "local",
                "profiles": {
                    "local": {
                        "api_url": "http://localhost:8000",
                        "sandbox_tools_api_url": "http://localhost:8000",
                    }
                },
            }))

            with patch.dict(os.environ, {
                "HOME": home,
                "MUNI_API_URL": "",
                "MUNI_PROFILE": "",
            }, clear=False):
                cfg = load_config()

        self.assertEqual(cfg["api_url"], "http://localhost:8000")
        self.assertEqual(cfg["sandbox_tools_api_url"], "http://localhost:8000")

    def test_muni_api_url_env_override_wins_after_legacy_replacement(self) -> None:
        with tempfile.TemporaryDirectory() as home:
            muni_dir = Path(home) / ".muni"
            muni_dir.mkdir()
            (muni_dir / "config.json").write_text(json.dumps({
                "current_profile": "default",
                "profiles": {
                    "default": {
                        "api_url": "https://bioarena-api-tools-production.up.railway.app",
                    }
                },
            }))

            with patch.dict(os.environ, {
                "HOME": home,
                "MUNI_API_URL": "http://localhost:9000",
                "MUNI_PROFILE": "",
            }, clear=False):
                cfg = load_config()

        self.assertEqual(cfg["api_url"], "http://localhost:9000")

    def test_dev_profile_defaults_to_localhost_services(self) -> None:
        with tempfile.TemporaryDirectory() as home:
            with patch.dict(os.environ, {
                "HOME": home,
                "MUNI_API_URL": "",
                "MUNI_APP_URL": "",
                "MUNI_PROFILE": "dev",
            }, clear=False):
                cfg = load_config()

        self.assertEqual(cfg["api_url"], "http://localhost:8000")
        self.assertEqual(cfg["app_url"], "http://localhost:3000")
        self.assertEqual(cfg["sandbox_tools_api_url"], "http://localhost:8000")

    def test_list_profiles_includes_builtin_dev_and_prod(self) -> None:
        with tempfile.TemporaryDirectory() as home:
            with patch.dict(os.environ, {"HOME": home, "MUNI_PROFILE": ""}, clear=False):
                profiles = list_profiles()

        self.assertIn("dev", profiles)
        self.assertIn("prod", profiles)

    def test_dev_credentials_fall_back_to_local_or_default(self) -> None:
        with tempfile.TemporaryDirectory() as home:
            muni_dir = Path(home) / ".muni"
            muni_dir.mkdir()
            (muni_dir / "credentials.json").write_text(json.dumps({
                "current_profile": "default",
                "profiles": {
                    "default": {
                        "access_token": "token-default",
                        "refresh_token": "refresh-default",
                        "expires_at": 9999999999,
                        "user_id": "user-default",
                    }
                },
            }))

            with patch.dict(os.environ, {"HOME": home, "MUNI_PROFILE": "dev"}, clear=False):
                creds = load_credentials()

        self.assertIsNotNone(creds)
        self.assertEqual(creds["access_token"], "token-default")

    def test_get_active_page_id_space_override_uses_that_space_before_active_page(self) -> None:
        with tempfile.TemporaryDirectory() as home:
            muni_dir = Path(home) / ".muni"
            muni_dir.mkdir()
            (muni_dir / "config.json").write_text(json.dumps({
                "current_profile": "default",
                "profiles": {
                    "default": {
                        "active_space_id": "space-old",
                        "active_page_id": "page-active",
                    }
                },
            }))

            pages = Mock()
            pages.get_default.return_value = SimpleNamespace(id="page-first")
            client = SimpleNamespace(pages=pages)
            with patch.dict(os.environ, {"HOME": home, "MUNI_PROFILE": ""}, clear=False), \
                 patch("muni.client.MuniClient", return_value=client):
                page_id = get_active_page_id(space_id="space-new")

        self.assertEqual(page_id, "page-first")
        pages.get_default.assert_called_once_with("space-new")
        pages.list.assert_not_called()

    def test_get_active_page_id_explicit_page_wins_over_space_override(self) -> None:
        with patch("muni.client.MuniClient") as constructor:
            page_id = get_active_page_id("page-explicit", space_id="space-new")

        self.assertEqual(page_id, "page-explicit")
        constructor.assert_not_called()

    def test_get_active_page_id_space_override_falls_back_to_page_list(self) -> None:
        with tempfile.TemporaryDirectory() as home:
            pages = Mock()
            pages.get_default.side_effect = RuntimeError("not available")
            pages.list.return_value = [{"id": "page-listed"}]
            client = SimpleNamespace(pages=pages)
            with patch.dict(os.environ, {"HOME": home, "MUNI_PROFILE": ""}, clear=False), \
                 patch("muni.client.MuniClient", return_value=client):
                page_id = get_active_page_id(space_id="space-new")

        self.assertEqual(page_id, "page-listed")
        pages.get_default.assert_called_once_with("space-new")
        pages.list.assert_called_once_with("space-new")


if __name__ == "__main__":
    unittest.main()
