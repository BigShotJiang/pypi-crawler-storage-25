# Muni CLI

Muni is the command-line interface for the Muni platform. Use it to discover available
tools, submit jobs, monitor runs, download outputs, and work with spaces and
canvas nodes from your terminal.

## Install

```bash
pipx install muni
```

Or install into an existing environment:

```bash
pip install muni
```

Requires Python 3.11 or newer.

## Log in

```bash
muni login
```

On a server or SSH session without a browser:

```bash
muni login --device
```

Check the active account:

```bash
muni whoami
```

## Common Workflow

Find a tool:

```bash
muni tools
muni tools --category protein-design
muni tools -q rfd3
```

Inspect tool inputs:

```bash
muni tool rfd3 --inputs
muni tool rfd3 --examples
```

Submit a job:

```bash
muni run rfd3 pdb_id=1UBQ num_designs=5
```

Submit and wait for completion:

```bash
muni run rfd3 pdb_id=1UBQ num_designs=5 --follow
```

Submit parameters from JSON:

```bash
muni run rfd3 --params-file params.json --follow
```

Run a batch from JSONL:

```bash
muni run ipsae --batch jobs.jsonl --follow
cat jobs.jsonl | muni run ipsae --batch - --follow
```

Check status and retrieve outputs:

```bash
muni status job_<uuid>
muni wait job_<uuid>
muni results job_<uuid>
muni results job_<uuid> --fields rank,sequence
muni files job_<uuid>
muni download-all job_<uuid> -o ./results/
```

## Spaces and Canvas Nodes

List and choose a workspace:

```bash
muni spaces
muni space use             # choose interactively
muni space use "My Space"  # or pass a name/ID
muni page use              # choose a page in the active space
```

Once selected, `muni run`, `muni job nodes --apply`, `muni nodes`, and
`muni node` default to that active space/page. Canvas-targeted `muni run`
creates and submits a real job node so completion can add deterministic result
nodes to the canvas. Use `--space-id` or `--page-id` to override one command,
or `muni space use none` / `muni run ... --no-space` for API-only jobs.

List nodes on the active page:

```bash
muni nodes
muni nodes search "PXDesign"
```

Create or inspect nodes:

```bash
muni node create "Results" --type table
muni node create "TREM2 rank 1" --type structure --file ./rank_1.cif
muni node read <node_id>
muni node submit <node_id> --wait
```

## Command Reference

| Command | What it does |
| --- | --- |
| `muni login` | Authenticate the CLI |
| `muni whoami` | Show the current account |
| `muni balance` | Show credit balance |
| `muni tools` | List available tools |
| `muni tool <name>` | Show details for one tool |
| `muni run <tool> KEY=VALUE` | Submit a job |
| `muni jobs` | List recent jobs |
| `muni jobs --tool ipsae` | Filter recent jobs by tool |
| `muni status <job_id>` | Check a job |
| `muni wait <job_id>` | Wait for one or more jobs |
| `muni results <job_id>` | Print job results |
| `muni files <job_id>` | List job output files |
| `muni download <job_id> <path>` | Download one output file |
| `muni download-all <job_id>` | Download all output files |
| `muni spaces` | List spaces |
| `muni space <subcommand>` | Manage a space |
| `muni nodes` | List canvas nodes |
| `muni node <subcommand>` | Create, read, edit, connect, or run nodes |

Run `muni --help` or `muni <command> --help` for the full set of options.

## License

MIT
