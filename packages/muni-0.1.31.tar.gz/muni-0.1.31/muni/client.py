"""MuniClient — high-level methods combining auth, Supabase, and API calls."""

import base64
import fnmatch
import time
import urllib.parse
from pathlib import Path
from typing import Any

from .auth import ensure_token
from .config import load_config
from .exceptions import MuniError, NotFoundError, JobCancelledError, JobFailedError, JobTimeoutError
from . import api


def _first_stage_message(stage: Any) -> str | None:
    if not isinstance(stage, dict):
        return None
    diagnostics = stage.get("diagnostics")
    if isinstance(diagnostics, list):
        for diagnostic in diagnostics:
            if isinstance(diagnostic, dict) and diagnostic.get("message"):
                return str(diagnostic["message"])
    issues = stage.get("issues")
    if isinstance(issues, list):
        for issue in issues:
            if isinstance(issue, dict) and issue.get("message"):
                return str(issue["message"])
    return None


class MuniClient:
    """High-level client for Muni operations.

    Provides namespaced sub-clients matching the TypeScript SDK:
        client.user      — whoami, balance
        client.tools     — list, get, examples
        client.jobs      — submit, status, wait, results, search, summary, query
        client.files     — list, read, download, save, save_all
        client.spaces    — list, get, create, delete, members, invite
        client.pages     — list, get
        client.canvas    — current_position, preview_placement
        client.nodes     — list, get, create, update, remove, run
        client.connections — list, create, update, remove
        client.sandbox   — run

    Legacy flat methods (e.g. client.list_tools()) are kept as aliases.
    """

    def __init__(self) -> None:
        self._cfg = load_config()

        # Namespaced sub-clients (mirrors TypeScript MuniSDK interface)
        from .clients import (
            UserClient, ToolsClient, JobsClient, FilesClient,
            SpacesClient, PagesClient, CanvasClient, NodesClient, NodeFilesClient,
            NodeDataClient, ConnectionsClient, ChatClient, PlansClient,
            SandboxClient, ScriptsClient,
        )
        self.user = UserClient(self)
        self.tools = ToolsClient(self)
        self.jobs = JobsClient(self)
        self.files = FilesClient(self)
        self.spaces = SpacesClient(self)
        self.pages = PagesClient(self)
        self.canvas = CanvasClient(self)
        self.nodes = NodesClient(self)
        self.node_files = NodeFilesClient(self)
        self.node_data = NodeDataClient(self)
        self.connections = ConnectionsClient(self)
        self.chat = ChatClient(self)
        self.plans = PlansClient(self)
        self.sandbox = SandboxClient(self)
        self.scripts = ScriptsClient(self)

    @property
    def api_url(self) -> str:
        url = self._cfg.get("api_url")
        if not url:
            raise MuniError("API URL not configured. Run 'muni config' or set MUNI_API_URL.")
        return url.rstrip("/")

    @property
    def app_url(self) -> str:
        url = self._cfg.get("app_url")
        if isinstance(url, str) and url.strip():
            return url.rstrip("/")

        api_url = self._cfg.get("api_url")
        if isinstance(api_url, str) and api_url.strip():
            parsed = urllib.parse.urlparse(api_url)
            if parsed.scheme and parsed.hostname:
                if parsed.hostname in {"localhost", "127.0.0.1"} and parsed.port == 8000:
                    return urllib.parse.urlunparse(parsed._replace(netloc=f"{parsed.hostname}:3000", path="", params="", query="", fragment="")).rstrip("/")
                if parsed.port == 3000:
                    return api_url.rstrip("/")

        raise MuniError("App URL not configured. Run 'muni config' or set MUNI_APP_URL.")

    @property
    def supabase_url(self) -> str:
        url = self._cfg.get("supabase_url")
        if not url:
            raise MuniError("Supabase URL not configured.")
        return url.rstrip("/")

    @property
    def publishable_key(self) -> str:
        key = self._cfg.get("supabase_publishable_key")
        if not key:
            raise MuniError("Supabase publishable key not configured.")
        return key

    def _auth(self) -> tuple[str, str]:
        """Return (access_token, user_id) after ensuring token is valid."""
        creds = ensure_token()
        return creds["access_token"], creds["user_id"]

    # ── Balance ──────────────────────────────────────────────────────

    def get_balance(self) -> dict:
        """Legacy dict-returning wrapper. Prefer ``client.user.balance()``.

        Emits snake_case keys (``user_id``, ``balance``) to match the shape
        that ``display.format_balance`` and ``--json`` consumers already expect.
        """
        return self.user.balance().model_dump(by_alias=False)

    # ── Spaces ───────────────────────────────────────────────────────

    def list_spaces(self) -> list[dict]:
        """Legacy dict-returning wrapper. Prefer ``client.spaces.list()``.

        Emits snake_case keys (``owner_id``, ``created_at``) to match the
        PostgREST shape that ``display.format_spaces_table`` consumes.
        """
        return [s.model_dump(by_alias=False) for s in self.spaces.list()]

    def create_space(self, name: str) -> dict:
        """Legacy dict-returning wrapper. Prefer ``client.spaces.create()``."""
        return self.spaces.create(name).model_dump(by_alias=False)

    def delete_space(self, space_id: str) -> None:
        """Legacy wrapper. Prefer ``client.spaces.delete()``."""
        self.spaces.delete(space_id)

    def space_members(self, space_id: str) -> list[dict]:
        """List space members (shape not yet in generated models)."""
        return self.spaces.members(space_id)

    def invite_to_space(self, space_id: str, email: str) -> str:
        """Legacy wrapper. Prefer ``client.spaces.invite()``."""
        return self.spaces.invite(space_id, email)

    # ── Tools ────────────────────────────────────────────────────────
    #
    # Flat wrappers stay on the Tools API (Elysia, port 8000) to preserve the
    # snake_case dict shape that ``display.format_tool_detail`` (via
    # ``reference_url``) and ``cli.cmd_run`` (via ``tool.get('batch')``) rely on.
    # The sub-client path ``client.tools.*`` routes through /api/sdk and returns
    # typed Pydantic models for new callers that want camelCase + validation.

    def list_tools(self, query: str | None = None, category: str | None = None) -> dict:
        """Legacy shape: ``{"tools": [...]}`` from the Tools API."""
        return api.list_tools(self.api_url, query=query, category=category)

    def get_tool(self, name: str) -> dict:
        """Legacy dict-returning wrapper. Prefer ``client.tools.get()``."""
        return api.get_tool(self.api_url, name)

    def get_examples(self, name: str) -> dict:
        """Legacy wrapper returning ``{"examples": [...]}``."""
        return api.get_examples(self.api_url, name)

    # ── Job Execution ────────────────────────────────────────────────

    def run(
        self,
        tool: str,
        args: dict,
        *,
        space_id: str | None = None,
        page_id: str | None = None,
        title: str | None = None,
    ) -> dict:
        token, uid = self._auth()
        return api.execute_tool(
            self.api_url, tool, args, uid,
            access_token=token,
            space_id=space_id, page_id=page_id, title=title,
        )

    def run_batch(
        self,
        tool: str,
        items: list[dict[str, Any]],
        *,
        space_id: str | None = None,
        page_id: str | None = None,
        title_prefix: str | None = None,
        submit_concurrency: int = 10,
    ) -> dict:
        token, uid = self._auth()
        payload_items: list[dict[str, Any]] = []
        total = len(items)
        for index, args in enumerate(items, start=1):
            item: dict[str, Any] = {"args": args}
            if title_prefix:
                item["title"] = f"{title_prefix} [{index}/{total}]"
            payload_items.append(item)
        return api.execute_tool_batch(
            self.api_url,
            tool,
            payload_items,
            uid,
            access_token=token,
            space_id=space_id,
            page_id=page_id,
            submit_concurrency=submit_concurrency,
        )

    def job_status(self, call_id: str) -> dict:
        token, uid = self._auth()
        return api.job_status(self.api_url, call_id, uid, token)

    def cancel_job(self, call_id: str) -> tuple[int, dict]:
        token, uid = self._auth()
        return api.cancel_job(self.api_url, call_id, uid, token)

    def job_results(self, call_id: str) -> tuple[int, dict]:
        token, uid = self._auth()
        return api.job_results(self.api_url, call_id, uid, token)

    def job_nodes(self, call_id: str) -> tuple[int, dict]:
        token, uid = self._auth()
        return api.job_nodes(self.api_url, call_id, uid, token)

    def materialize_job_nodes(
        self,
        call_id: str,
        *,
        space_id: str | None = None,
        page_id: str | None = None,
        launcher_node_id: str | None = None,
        refresh_contract: bool = True,
        prune_stale: bool = True,
    ) -> dict:
        token, _ = self._auth()
        return api.materialize_job_nodes(
            self.app_url,
            call_id,
            token,
            space_id=space_id,
            page_id=page_id,
            launcher_node_id=launcher_node_id,
            refresh_contract=refresh_contract,
            prune_stale=prune_stale,
        )

    def job_logs(self, call_id: str, *, max_lines: int | None = None) -> dict:
        token, uid = self._auth()
        return api.job_logs(self.api_url, call_id, uid, token, max_lines=max_lines)

    def wait_for_job(
        self,
        call_id: str,
        *,
        timeout: int = 1800,
        on_status: Any = None,
    ) -> dict:
        """Wait for job using realtime subscription (with polling fallback). Returns results dict."""
        from .realtime import create_job_waiter

        waiter = create_job_waiter(self, [call_id])
        start = time.time()
        delays = [2, 2, 5, 5, 10]  # escalating backoff
        i = 0
        try:
            while True:
                elapsed = time.time() - start
                if elapsed >= timeout:
                    raise JobTimeoutError(call_id, timeout)

                status_data = self.job_status(call_id)
                status = status_data.get("status")

                if on_status:
                    on_status(status_data)

                if status == "completed":
                    _, results = self.job_results(call_id)
                    return results

                if status == "failed":
                    raise JobFailedError(call_id, status_data.get("error"))
                if status == "cancelled":
                    raise JobCancelledError(call_id)

                delay = delays[min(i, len(delays) - 1)]
                if waiter:
                    waiter.wait_for_update(call_id, timeout=delay)
                else:
                    time.sleep(delay)
                i += 1
        finally:
            if waiter:
                waiter.stop()

    # ── Jobs Listing ─────────────────────────────────────────────────

    def list_jobs(
        self,
        space_id: str | None = None,
        status: str | None = None,
        tool_name: str | None = None,
        limit: int = 20,
    ) -> list[dict]:
        """Legacy dict-returning wrapper. Prefer ``client.jobs.search()``."""
        rows = self.jobs.search(space_id=space_id, status=status, tool_name=tool_name, limit=limit)
        result: list[dict] = []
        for row in rows:
            data = row.model_dump(by_alias=False)
            data["job_type"] = data.get("tool_name")
            result.append(data)
        return result

    # ── Files ────────────────────────────────────────────────────────

    def list_files(self, call_id: str) -> dict:
        token, uid = self._auth()
        return api.list_files(self.api_url, call_id, uid, token)

    def download_file(self, call_id: str, file_path: str) -> tuple[str, bool]:
        """Download a file. Returns (content, is_text). Binary content is raw base64."""
        token, uid = self._auth()
        data = api.download_file(self.api_url, call_id, file_path, uid, token)
        return data.get("content", ""), data.get("is_text", True)

    def save_file(self, call_id: str, file_path: str, dest: str | Path) -> Path:
        """Download a file and write it to disk."""
        content, is_text = self.download_file(call_id, file_path)
        dest = Path(dest)
        dest.parent.mkdir(parents=True, exist_ok=True)
        if is_text:
            dest.write_text(content)
        else:
            dest.write_bytes(base64.b64decode(content))
        return dest

    def save_all_files(
        self,
        call_id: str,
        output_dir: str | Path,
        *,
        path_prefix: str | None = None,
        glob_pattern: str | None = None,
    ) -> list[Path]:
        """Download files for a job into output_dir.

        Args:
            path_prefix: Only download files under this directory prefix (e.g. "designs/").
            glob_pattern: Only download files matching this glob (e.g. "*.pdb", "designs/*.json").
        """
        output_dir = Path(output_dir)
        file_data = self.list_files(call_id)
        files = file_data.get("files", [])
        saved: list[Path] = []
        for f in files:
            fpath = f["path"]
            if path_prefix:
                prefix = path_prefix.rstrip("/") + "/"
                if not (fpath.startswith(prefix) or fpath == path_prefix.rstrip("/")):
                    continue
            if glob_pattern:
                if not fnmatch.fnmatch(fpath, glob_pattern):
                    # Also match against just the filename
                    if not fnmatch.fnmatch(Path(fpath).name, glob_pattern):
                        continue
            dest = output_dir / fpath
            self.save_file(call_id, fpath, dest)
            saved.append(dest)
        return saved

    # ── Muni Nodes & Pages (new) ────────────────────────────────────

    def resolve_space_id(self, id_or_name: str) -> str:
        """Resolve a space by UUID or name. Returns the space ID."""
        return self.spaces.resolve(id_or_name)

    # ── Pages ───────────────────────────────────────────────────────

    def list_pages(self, space_id: str) -> list[dict]:
        """List all pages in the given space."""
        return [
            page.model_dump(by_alias=False)
            for page in self.pages.list(space_id)
        ]

    def get_page(self, page_id: str, *, space_id: str | None = None) -> dict:
        """Fetch a single page, optionally validating it belongs to space_id."""
        try:
            page = self.pages.get(page_id)
        except NotFoundError:
            raise NotFoundError(f"Page not found: {page_id}")
        data = page.model_dump(by_alias=False) if hasattr(page, "model_dump") else dict(page)
        if space_id and data.get("space_id") != space_id:
            raise NotFoundError(f"Page not found: {page_id}")
        return data

    # ── Nodes ───────────────────────────────────────────────────────

    def search_nodes(
        self,
        page_id: str,
        *,
        node_type: str | None = None,
        query: str | None = None,
        limit: int = 20,
    ) -> list[dict]:
        """Search nodes on a page by type or title."""
        return [
            node.model_dump(by_alias=True)
            for node in self.nodes.list(
                page_id,
                type=node_type,
                query=query,
                limit=limit,
            )
        ]

    def create_node(
        self,
        page_id: str,
        title: str,
        *,
        node_type: str = "table",
        script: str | None = None,
        python_code: str | None = None,
        position_x: float | None = None,
        position_y: float | None = None,
        group_id: str | None = None,
        connections: list[dict] | None = None,
    ) -> dict:
        """Create a new node on a page.

        The server unconditionally dispatches the pipeline after insert:
        image/group skip, job/plan → saveNode (compile + validate, no
        submission), everything else → runNode. No --no-run flag; script
        is optional because the SDK supplies kind-appropriate defaults.

        For code nodes, pass ``python_code`` to set the main.py content
        before the first dispatch.
        """
        return self.nodes.create(
            page_id,
            title,
            type=node_type,
            script=script,
            python_code=python_code,
            position_x=position_x,
            position_y=position_y,
            group_id=group_id,
            connections=connections,
        )

    def read_node(self, node_id: str) -> dict:
        """Read a node's full state including script, data, connections, and Python code."""
        node_detail = self.nodes.get(node_id)

        # Soft-deleted nodes return minimal info
        if node_detail.get("isRemoved"):
            return {
                "nodeId": node_detail.get("id", ""),
                "title": node_detail.get("title", ""),
                "type": node_detail.get("type", ""),
                "isRemoved": True,
            }

        return {
            "nodeId": node_detail.get("id", ""),
            "title": node_detail.get("title", ""),
            "type": node_detail.get("type", ""),
            "isRemoved": False,
            "script": node_detail.get("script"),
            "positionX": node_detail.get("positionX", 0),
            "positionY": node_detail.get("positionY", 0),
            "runtime": node_detail.get("runtime"),
            "currentRun": node_detail.get("currentRun"),
            "compileResult": node_detail.get("compileResult"),
            "executeResult": node_detail.get("executeResult"),
            "validateResult": node_detail.get("validateResult"),
            "renderHealth": node_detail.get("renderHealth"),
            "currentData": node_detail.get("currentData"),
            "connections": node_detail.get("connections", []),
            # Code node fields (None for non-code nodes)
            "pythonCode": node_detail.get("pythonCode"),
            "pythonFiles": node_detail.get("pythonFiles"),
            "pythonStdout": node_detail.get("pythonStdout"),
            "pythonStderr": node_detail.get("pythonStderr"),
        }

    def edit_node(
        self,
        node_id: str,
        *,
        title: str | None = None,
        script: str | None = None,
        python_code: str | None = None,
    ) -> dict:
        """Edit a node's title, script, and/or Python code."""
        if title is None and script is None and python_code is None:
            raise MuniError("At least one of --title, --script, or --python must be provided.")
        result = self.nodes.update(node_id, title=title, script=script, python_code=python_code)
        resolved_title = title
        if resolved_title is None:
            try:
                resolved_title = self.read_node(node_id).get("title")
            except Exception:
                resolved_title = None
        return {
            "nodeId": result.get("nodeId", node_id),
            "title": resolved_title,
            "updatedFields": result.get("updated", []),
        }

    def remove_node(self, node_id: str) -> dict:
        """Soft-delete a node (set is_removed=true).

        Routes through ``self.nodes.remove`` → ``/api/sdk`` → the TypeScript
        SDK on the server. This keeps the bulk-delete guard and audit trail
        (``last_write_client_id`` stamping + ``muni_node_audit`` trigger) in
        the canonical code path, instead of PATCHing PostgREST directly.
        """
        return self.nodes.remove(node_id, origin="cli-remove")

    def submit_node(self, node_id: str, *, wait: bool = False, timeout: int = 60,
                    page_id: str | None = None, space_id: str | None = None) -> dict:
        """Submit a node for execution. If wait=True and the result is async (job), poll until completed/failed."""
        result = self.nodes.submit(node_id, page_id=page_id, space_id=space_id)

        # For synchronous/terminal results (most node kinds), return directly.
        if result.get("status") in ("completed", "failed", "saved", "preflight_failed"):
            return result

        # For async results (job submitted), optionally poll
        if not wait:
            return result

        return self.wait_for_node_submit(node_id, timeout=timeout)

    def wait_for_node_submit(self, node_id: str, *, timeout: int = 60) -> dict:
        """Poll currentRun until execution completes, fails, or times out."""
        import time
        start = time.time()

        while time.time() - start < timeout:
            time.sleep(1)
            try:
                node = self.read_node(node_id)
            except NotFoundError:
                return {
                    "nodeId": node_id,
                    "status": "failed",
                    "error": "Node not found",
                    "outputs": [],
                    "runtime": {},
                }

            node_runtime = node.get("runtime", {}) or {}
            current_run = node.get("currentRun") if isinstance(node.get("currentRun"), dict) else None
            if current_run:
                overall_status = current_run.get("overallStatus")
                run_id = current_run.get("id")
                outputs = []
                current_data = node.get("currentData")
                if isinstance(current_data, dict):
                    outputs.append({
                        "outputKey": current_data.get("outputKey", "primary"),
                        "dataType": current_data.get("dataType"),
                        "rowCount": current_data.get("rowCount"),
                    })

                if overall_status == "ok":
                    return {
                        "nodeId": node_id,
                        "status": "completed",
                        "runId": run_id,
                        "currentRun": current_run,
                        "outputs": outputs,
                    }

                if overall_status in {"error", "timeout", "cancelled"}:
                    execute = current_run.get("execute") if isinstance(current_run.get("execute"), dict) else {}
                    preflight = current_run.get("preflight") if isinstance(current_run.get("preflight"), dict) else {}
                    compile_stage = current_run.get("compile") if isinstance(current_run.get("compile"), dict) else {}
                    error = (
                        execute.get("error")
                        or preflight.get("nextStep")
                        or _first_stage_message(preflight)
                        or _first_stage_message(compile_stage)
                        or f"Node run ended with status {overall_status}"
                    )
                    return {
                        "nodeId": node_id,
                        "status": "failed" if overall_status in {"error", "timeout"} else "cancelled",
                        "runId": run_id,
                        "currentRun": current_run,
                        "error": error,
                        "outputs": outputs,
                    }

            lifecycle = node_runtime.get("lifecycle", "")

            if lifecycle in {"completed", "saved"}:
                outputs = []
                current_data = node.get("currentData")
                if isinstance(current_data, dict):
                    outputs.append({
                        "outputKey": current_data.get("outputKey", "primary"),
                        "dataType": current_data.get("dataType"),
                        "rowCount": current_data.get("rowCount"),
                    })
                status = "saved" if lifecycle == "saved" else "completed"
                return {"nodeId": node_id, "status": status, "outputs": outputs, "runtime": node_runtime}

            if lifecycle == "failed":
                error = node_runtime.get("lastError", "Unknown error")
                return {"nodeId": node_id, "status": "failed", "error": error, "outputs": [], "runtime": node_runtime}

        return {"nodeId": node_id, "status": "timeout", "error": f"Node did not complete within {timeout}s", "outputs": [], "runtime": {}}

    # ── Metric node data ────────────────────────────────────────────

    def table_summary(self, node_id: str) -> dict:
        """Get column names, types, and row count for a metric node."""
        return self.nodes.table_summary(node_id)

    def table_query(
        self,
        node_id: str,
        *,
        columns: list[str] | None = None,
        sort_by: str | None = None,
        sort_order: str = "asc",
        filters: list[dict] | None = None,
        limit: int = 20,
        offset: int = 0,
    ) -> dict:
        """Query a metric node's data with sorting, filtering, and pagination."""
        return self.nodes.table_query(
            node_id,
            columns=columns,
            sortBy=sort_by,
            sortOrder=sort_order,
            filters=filters,
            limit=limit,
            offset=offset,
        )

    def table_select(
        self,
        node_id: str,
        action: str,
        *,
        rows: list[int] | None = None,
        filters: list[dict] | None = None,
    ) -> dict:
        """Select/deselect rows on a metric node. Persists to runtime.viewState."""
        return self.nodes.table_select(
            node_id,
            action=action,
            rows=rows,
            filters=filters,
        )
