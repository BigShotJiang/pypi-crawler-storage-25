"""HTTP helpers for the Muni Tools API (Elysia server)."""

import json
import urllib.request
import urllib.error
import urllib.parse
from typing import Any

from .exceptions import APIError, NotFoundError


def _request(
    url: str,
    *,
    method: str = "GET",
    headers: dict[str, str] | None = None,
    body: dict | None = None,
) -> tuple[int, Any]:
    """Make an HTTP request, return (status_code, parsed_json | bytes)."""
    data = json.dumps(body).encode() if body else None
    hdrs = headers or {}
    if body and "Content-Type" not in hdrs:
        hdrs["Content-Type"] = "application/json"

    req = urllib.request.Request(url, data=data, headers=hdrs, method=method)
    try:
        with urllib.request.urlopen(req) as resp:
            raw = resp.read()
            try:
                parsed = json.loads(raw.decode())
            except (json.JSONDecodeError, UnicodeDecodeError):
                return resp.status, raw
            return resp.status, parsed
    except urllib.error.HTTPError as e:
        raw = e.read().decode()
        try:
            parsed = json.loads(raw)
        except (json.JSONDecodeError, ValueError):
            parsed = {"error": raw}
        return e.code, parsed
    except urllib.error.URLError as e:
        parsed_url = urllib.parse.urlparse(url)
        endpoint = (
            urllib.parse.urlunparse((parsed_url.scheme, parsed_url.netloc, "", "", "", ""))
            if parsed_url.scheme and parsed_url.netloc
            else url
        )
        reason = getattr(e, "reason", e)
        raise APIError(f"Unable to reach Muni API at {endpoint}: {reason}") from e


def list_tools(api_url: str, query: str | None = None, category: str | None = None, limit: int = 50) -> dict:
    """GET /tools — list/search tools."""
    params = [f"limit={limit}"]
    if query:
        params.append(f"q={urllib.request.quote(query)}")
    if category:
        params.append(f"category={urllib.request.quote(category)}")
    url = f"{api_url}/tools?{'&'.join(params)}"
    status, data = _request(url)
    if status != 200:
        raise APIError(f"List tools failed: {data}", status)
    return data


def get_tool(api_url: str, name: str) -> dict:
    """GET /tools/:name — get tool schema."""
    url = f"{api_url}/tools/{urllib.request.quote(name)}"
    status, data = _request(url)
    if status == 404:
        raise NotFoundError(f"Tool not found: {name}")
    if status != 200:
        raise APIError(f"Get tool failed: {data}", status)
    return data


def get_examples(api_url: str, name: str) -> dict:
    """GET /tools/:name/examples — get usage examples."""
    url = f"{api_url}/tools/{urllib.request.quote(name)}/examples"
    status, data = _request(url)
    if status == 404:
        raise NotFoundError(f"Tool not found: {name}")
    if status != 200:
        raise APIError(f"Get examples failed: {data}", status)
    return data


def execute_tool(
    api_url: str,
    name: str,
    args: dict,
    user_id: str,
    *,
    access_token: str | None = None,
    space_id: str | None = None,
    page_id: str | None = None,
    title: str | None = None,
) -> dict:
    """POST /tools/:name/execute — run a tool."""
    url = f"{api_url}/tools/{urllib.request.quote(name)}/execute"
    headers: dict[str, str] = {"x-user-id": user_id}
    if access_token:
        headers["Authorization"] = f"Bearer {access_token}"
    if space_id:
        headers["x-space-id"] = space_id
    if page_id:
        headers["x-page-id"] = page_id
    if title:
        headers["x-job-title"] = title
    status, data = _request(url, method="POST", headers=headers, body=args)
    if status in (401, 403):
        raise APIError("Unauthorized — missing or invalid bearer token", status)
    if status == 404:
        raise NotFoundError(f"Tool not found: {name}")
    if status != 200:
        raise APIError(f"Execute failed: {data}", status)
    return data


def execute_tool_batch(
    api_url: str,
    name: str,
    items: list[dict],
    user_id: str,
    *,
    access_token: str | None = None,
    space_id: str | None = None,
    page_id: str | None = None,
    submit_concurrency: int = 10,
) -> dict:
    """POST /tools/:name/execute-batch — run many items in one request."""
    url = f"{api_url}/tools/{urllib.request.quote(name)}/execute-batch"
    headers: dict[str, str] = {"x-user-id": user_id}
    if access_token:
        headers["Authorization"] = f"Bearer {access_token}"
    if space_id:
        headers["x-space-id"] = space_id
    if page_id:
        headers["x-page-id"] = page_id
    status, data = _request(
        url,
        method="POST",
        headers=headers,
        body={"items": items, "submit_concurrency": submit_concurrency},
    )
    if status in (401, 403):
        raise APIError("Unauthorized — missing or invalid bearer token", status)
    if status == 404:
        raise NotFoundError(f"Tool not found: {name}")
    if status != 200:
        raise APIError(f"Batch execute failed: {data}", status)
    return data


def cancel_job(api_url: str, call_id: str, user_id: str, access_token: str | None = None) -> tuple[int, dict]:
    """POST /jobs/:callId/cancel — returns (http_status, data). 409 = already terminal."""
    url = f"{api_url}/jobs/{urllib.request.quote(call_id)}/cancel"
    headers = {"x-user-id": user_id}
    if access_token:
        headers["Authorization"] = f"Bearer {access_token}"
    status, data = _request(url, method="POST", headers=headers, body={})
    if status == 404:
        raise NotFoundError(f"Job not found: {call_id}")
    if status not in (200, 409):
        raise APIError(f"Cancel failed: {data}", status)
    return status, data


def job_status(api_url: str, call_id: str, user_id: str, access_token: str | None = None) -> dict:
    """GET /jobs/:callId/status"""
    url = f"{api_url}/jobs/{urllib.request.quote(call_id)}/status"
    headers = {"x-user-id": user_id}
    if access_token:
        headers["Authorization"] = f"Bearer {access_token}"
    status, data = _request(url, headers=headers)
    if status == 404:
        raise NotFoundError(f"Job not found: {call_id}")
    if status != 200:
        raise APIError(f"Job status failed: {data}", status)
    return data


def job_results(api_url: str, call_id: str, user_id: str, access_token: str | None = None) -> tuple[int, dict]:
    """GET /jobs/:callId/results — returns (http_status, data). 202 = still running."""
    url = f"{api_url}/jobs/{urllib.request.quote(call_id)}/results"
    headers = {"x-user-id": user_id}
    if access_token:
        headers["Authorization"] = f"Bearer {access_token}"
    status, data = _request(url, headers=headers)
    if status == 404:
        raise NotFoundError(f"Job not found: {call_id}")
    if status not in (200, 202):
        raise APIError(f"Job results failed: {data}", status)
    return status, data


def job_nodes(api_url: str, call_id: str, user_id: str, access_token: str | None = None) -> tuple[int, dict]:
    """GET /jobs/:callId/nodes — returns (http_status, node plan). 202 = still running."""
    url = f"{api_url}/jobs/{urllib.request.quote(call_id)}/nodes"
    headers = {"x-user-id": user_id}
    if access_token:
        headers["Authorization"] = f"Bearer {access_token}"
    status, data = _request(url, headers=headers)
    if status == 404:
        raise NotFoundError(f"Job not found: {call_id}")
    if status not in (200, 202):
        raise APIError(f"Job nodes failed: {data}", status)
    return status, data


def materialize_job_nodes(
    app_url: str,
    call_id: str,
    access_token: str,
    *,
    space_id: str | None = None,
    page_id: str | None = None,
    launcher_node_id: str | None = None,
    refresh_contract: bool = True,
    prune_stale: bool = True,
) -> dict:
    """POST /api/jobs/:callId/materialization/apply — create/update canvas nodes."""
    url = f"{app_url}/api/jobs/{urllib.request.quote(call_id)}/materialization/apply"
    headers = {"Authorization": f"Bearer {access_token}", "User-Agent": "MuniCLI/1.0"}
    body: dict[str, Any] = {
        "refreshContract": refresh_contract,
        "pruneStale": prune_stale,
    }
    if space_id:
        body["spaceId"] = space_id
    if page_id:
        body["pageId"] = page_id
    if launcher_node_id is not None:
        body["launcherNodeId"] = launcher_node_id
    status, data = _request(url, method="POST", headers=headers, body=body)
    if status == 404:
        raise NotFoundError(f"Job not found: {call_id}")
    if status not in (200,):
        raise APIError(f"Materialize job nodes failed: {data}", status)
    return data


def job_logs(
    api_url: str,
    call_id: str,
    user_id: str,
    access_token: str | None = None,
    *,
    max_lines: int | None = None,
) -> dict:
    """GET /jobs/:callId/logs — fetch provider logs."""
    params: list[str] = []
    if max_lines is not None:
        params.append(f"max_lines={max_lines}")
    suffix = f"?{'&'.join(params)}" if params else ""
    url = f"{api_url}/jobs/{urllib.request.quote(call_id)}/logs{suffix}"
    headers = {"x-user-id": user_id}
    if access_token:
        headers["Authorization"] = f"Bearer {access_token}"
    status, data = _request(url, headers=headers)
    if status == 404:
        raise NotFoundError(f"Job not found: {call_id}")
    if status != 200:
        raise APIError(f"Job logs failed: {data}", status)
    return data


def list_files(api_url: str, call_id: str, user_id: str, access_token: str | None = None) -> dict:
    """GET /jobs/:callId/files — list output files."""
    url = f"{api_url}/jobs/{urllib.request.quote(call_id)}/files"
    headers = {"x-user-id": user_id}
    if access_token:
        headers["Authorization"] = f"Bearer {access_token}"
    status, data = _request(url, headers=headers)
    if status == 404:
        raise NotFoundError(f"Job not found: {call_id}")
    if status != 200:
        raise APIError(f"List files failed: {data}", status)
    return data


def download_file(api_url: str, call_id: str, file_path: str, user_id: str, access_token: str | None = None) -> dict:
    """GET /jobs/:callId/files/:path — download a file."""
    escaped_path = urllib.parse.quote(file_path, safe="/")
    url = f"{api_url}/jobs/{urllib.request.quote(call_id)}/files/{escaped_path}"
    headers = {"x-user-id": user_id}
    if access_token:
        headers["Authorization"] = f"Bearer {access_token}"
    status, data = _request(url, headers=headers)
    if status == 404:
        raise NotFoundError(f"File not found: {file_path}")
    if status != 200:
        raise APIError(f"Download failed: {data}", status)
    return data
