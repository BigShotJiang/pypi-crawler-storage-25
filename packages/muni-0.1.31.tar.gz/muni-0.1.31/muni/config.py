"""Configuration file paths, env var reading, and profile-aware defaults."""

import json
import os
import urllib.parse
from pathlib import Path
from typing import Any

from .exceptions import MuniError

CONFIG_KEYS = (
    "app_url",
    "api_url",
    "supabase_url",
    "supabase_publishable_key",
    "active_space_id",
    "active_page_id",
    "sandbox_url",
    "sandbox_secret",
    "sandbox_tools_api_url",
)

# Public defaults — users shouldn't need to configure these.
DEFAULTS = {
    "api_url": "https://api.muni.bio",
    "app_url": "https://muni.bio",
    "supabase_url": "https://kxoseeayisbxmbjmapjc.supabase.co",
    "supabase_publishable_key": "sb_publishable_g6AicEny85FI5yLqZXprRg_HYvO1_N4",
    "sandbox_tools_api_url": "https://api.muni.bio",
}

DEV_DEFAULTS = {
    **DEFAULTS,
    "api_url": "http://localhost:8000",
    "app_url": "http://localhost:3000",
    "sandbox_tools_api_url": "http://localhost:8000",
}

PROFILE_DEFAULTS = {
    "default": DEFAULTS,
    "prod": DEFAULTS,
    "production": DEFAULTS,
    "dev": DEV_DEFAULTS,
    "local": DEV_DEFAULTS,
}

CREDENTIAL_PROFILE_FALLBACKS = {
    "dev": ("local", "default"),
    "local": ("dev", "default"),
    "prod": ("default",),
    "production": ("default",),
}

LEGACY_API_HOSTS = {
    "api.bioarena.com",
    "bioarena-api-tools-production.up.railway.app",
}

CREDENTIAL_KEYS = (
    "access_token",
    "refresh_token",
    "expires_at",
    "user_id",
    "email",
)


def _muni_dir() -> Path:
    """Return ~/.muni, creating it if needed."""
    d = Path.home() / ".muni"
    d.mkdir(mode=0o700, exist_ok=True)
    return d


def config_path() -> Path:
    return _muni_dir() / "config.json"


def credentials_path() -> Path:
    return _muni_dir() / "credentials.json"


def _read_json(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    with open(path) as f:
        data = json.load(f)
    return data if isinstance(data, dict) else {}


def _selected_profile(raw: dict[str, Any]) -> str:
    env_profile = os.environ.get("MUNI_PROFILE", "").strip()
    if env_profile:
        return env_profile
    current = raw.get("current_profile")
    if isinstance(current, str) and current.strip():
        return current.strip()
    return "default"


def _normalize_profiles(raw: dict[str, Any], keys: tuple[str, ...]) -> dict[str, Any]:
    profiles_raw = raw.get("profiles")
    if isinstance(profiles_raw, dict):
        profiles: dict[str, dict[str, Any]] = {}
        for name, profile in profiles_raw.items():
            if not isinstance(name, str) or not isinstance(profile, dict):
                continue
            profiles[name] = {
                key: profile[key]
                for key in keys
                if key in profile and profile[key] not in (None, "")
            }
        if not profiles:
            profiles = {"default": {}}
        current = raw.get("current_profile")
        current_profile = current if isinstance(current, str) and current in profiles else next(iter(profiles))
        return {
            "current_profile": current_profile,
            "profiles": profiles,
        }

    legacy = {
        key: raw[key]
        for key in keys
        if key in raw and raw[key] not in (None, "")
    }
    return {
        "current_profile": "default",
        "profiles": {"default": legacy},
    }


def _write_profile_doc(path: Path, payload: dict[str, Any]) -> None:
    with open(path, "w") as f:
        json.dump(payload, f, indent=2)
    os.chmod(path, 0o600)


def _is_legacy_api_url(value: Any) -> bool:
    if not isinstance(value, str) or not value.strip():
        return False
    parsed = urllib.parse.urlparse(value.strip())
    return (parsed.hostname or "").lower() in LEGACY_API_HOSTS


def _replace_legacy_api_urls(cfg: dict[str, Any]) -> None:
    for key in ("api_url", "sandbox_tools_api_url"):
        if _is_legacy_api_url(cfg.get(key)):
            cfg[key] = DEFAULTS[key]


def list_profiles() -> list[str]:
    raw = _normalize_profiles(_read_json(config_path()), CONFIG_KEYS)
    return sorted(set(PROFILE_DEFAULTS.keys()) | set(raw["profiles"].keys()))


def current_profile_name() -> str:
    raw = _normalize_profiles(_read_json(config_path()), CONFIG_KEYS)
    return _selected_profile(raw)


def set_current_profile(profile: str) -> None:
    raw = _normalize_profiles(_read_json(config_path()), CONFIG_KEYS)
    if profile not in raw["profiles"]:
        raw["profiles"][profile] = {}
    raw["current_profile"] = profile
    _write_profile_doc(config_path(), raw)


def load_config(profile: str | None = None) -> dict:
    """Load config from file, falling back to built-in defaults and env vars."""
    raw = _normalize_profiles(_read_json(config_path()), CONFIG_KEYS)
    selected = profile or _selected_profile(raw)

    # Start with built-in defaults for the selected profile, then layer
    # user-saved profile values on top. This lets `muni --profile dev ...`
    # work out of the box without asking users to remember localhost ports.
    cfg = dict(PROFILE_DEFAULTS.get(selected, DEFAULTS))
    cfg.update(raw["profiles"].get(selected, {}))
    _replace_legacy_api_urls(cfg)

    # Env vars override everything
    if v := os.environ.get("MUNI_API_URL"):
        cfg["api_url"] = v
    if v := os.environ.get("MUNI_APP_URL"):
        cfg["app_url"] = v
    if v := os.environ.get("MUNI_SUPABASE_URL"):
        cfg["supabase_url"] = v
    if v := os.environ.get("MUNI_SUPABASE_PUBLISHABLE_KEY"):
        cfg["supabase_publishable_key"] = v
    if v := os.environ.get("MUNI_SPACE_ID"):
        cfg["active_space_id"] = v
    if v := os.environ.get("MUNI_PAGE_ID"):
        cfg["active_page_id"] = v

    cfg["profile"] = selected
    return cfg


def save_config(cfg: dict, *, profile: str | None = None, set_current: bool = True) -> None:
    raw = _normalize_profiles(_read_json(config_path()), CONFIG_KEYS)
    selected = profile or os.environ.get("MUNI_PROFILE", "").strip() or raw["current_profile"]
    raw["profiles"][selected] = {
        key: cfg[key]
        for key in CONFIG_KEYS
        if key in cfg and cfg[key] not in (None, "")
    }
    if set_current:
        raw["current_profile"] = selected
    _write_profile_doc(config_path(), raw)


def load_credentials(profile: str | None = None) -> dict | None:
    raw = _normalize_profiles(_read_json(credentials_path()), CREDENTIAL_KEYS)
    selected = profile or os.environ.get("MUNI_PROFILE", "").strip() or current_profile_name()
    profile_order = (selected, *CREDENTIAL_PROFILE_FALLBACKS.get(selected, ()))
    creds = next((raw["profiles"].get(name) for name in profile_order if raw["profiles"].get(name)), None)
    return dict(creds) if creds else None


def save_credentials(creds: dict, *, profile: str | None = None) -> None:
    raw = _normalize_profiles(_read_json(credentials_path()), CREDENTIAL_KEYS)
    selected = profile or os.environ.get("MUNI_PROFILE", "").strip() or current_profile_name()
    raw["profiles"][selected] = {
        key: creds[key]
        for key in CREDENTIAL_KEYS
        if key in creds and creds[key] not in (None, "")
    }
    raw["current_profile"] = selected
    _write_profile_doc(credentials_path(), raw)


def clear_credentials(profile: str | None = None) -> None:
    p = credentials_path()
    if not p.exists():
        return

    raw = _normalize_profiles(_read_json(p), CREDENTIAL_KEYS)
    selected = profile or os.environ.get("MUNI_PROFILE", "").strip() or current_profile_name()
    raw["profiles"].pop(selected, None)
    if not raw["profiles"]:
        p.unlink()
        return

    if raw["current_profile"] not in raw["profiles"]:
        raw["current_profile"] = next(iter(raw["profiles"]))
    _write_profile_doc(p, raw)


def get_active_space_id(override: str | None = None) -> str:
    """Return the space_id to use.

    Resolution order:
      1. Explicit override (CLI flag)
      2. Local CLI config (`active_space_id`, set by `muni space use ...`)
      3. Server-side `muni_user_preferences.last_space_id` (where the user
         was last active in the canvas)
      4. Error

    Step 3 is what makes CLI nodes land in the same space the user is
    looking at in the browser when they haven't explicitly chosen one
    via `muni space use`.
    """
    if override:
        return override
    cfg = load_config()
    space_id = cfg.get("active_space_id")
    if space_id:
        return space_id
    # Server fallback: muni_user_preferences.last_space_id
    server_space_id = _try_server_last_space_id()
    if server_space_id:
        return server_space_id
    raise MuniError(
        "No active space. Run 'muni space use <space_id>', visit a space "
        "in the canvas first, or pass --space-id."
    )


def _page_id_from_page(page: Any) -> str | None:
    if isinstance(page, dict):
        value = page.get("id")
    else:
        value = getattr(page, "id", None)
    return value if isinstance(value, str) and value else None


def _first_page_id_for_space(space_id: str) -> str | None:
    """Return the first/default page for a space, creating one if supported."""
    try:
        from .client import MuniClient
        client = MuniClient()
    except Exception:
        return None

    try:
        default_page = client.pages.get_default(space_id)
        page_id = _page_id_from_page(default_page)
        if page_id:
            return page_id
    except Exception:
        pass

    # Older app builds may not expose getDefault consistently. Fall back
    # to list() so explicit --space-id still lands on that space's page.
    try:
        for page in client.pages.list(space_id):
            page_id = _page_id_from_page(page)
            if page_id:
                return page_id
    except Exception:
        pass
    return None


def get_active_page_id(override: str | None = None, *, space_id: str | None = None) -> str:
    """Return the page_id to use.

    Resolution order:
      1. Explicit override (CLI flag)
      2. First/default page of an explicit space_id, when provided
      3. Local CLI config (`active_page_id`)
      4. Server-side `muni_user_preferences.last_page_id`
      5. First/default page of the resolved active space
      6. Error
    """
    if override:
        return override
    if space_id:
        page_id = _first_page_id_for_space(space_id)
        if page_id:
            return page_id
        raise MuniError(
            f"No page found for space {space_id}. Create a page in the canvas "
            "or pass --page-id."
        )
    cfg = load_config()
    page_id = cfg.get("active_page_id")
    if page_id:
        return page_id
    # Server fallback: prefer the user's actual last-visited page.
    server_page_id, server_space_id = _try_server_last_page_id()
    if server_page_id:
        return server_page_id
    # Final fallback: first page of the resolved active space.
    space_id = server_space_id or cfg.get("active_space_id")
    if space_id:
        page_id = _first_page_id_for_space(space_id)
        if page_id:
            return page_id
    raise MuniError(
        "No active page. Run 'muni page use <page_id>', visit a page in "
        "the canvas first, or pass --page-id."
    )


def _try_server_last_space_id() -> str | None:
    """Best-effort fetch of `muni_user_preferences.last_space_id` for the
    authenticated user. Returns None on any failure (network, auth, etc.)
    so the caller can fall through to the next step in the chain.
    """
    try:
        from .client import MuniClient
        client = MuniClient()
        result = client.user.last_visited()
        if isinstance(result, dict):
            value = result.get("lastSpaceId")
            if isinstance(value, str) and value:
                return value
    except Exception:
        pass
    return None


def _try_server_last_page_id() -> tuple[str | None, str | None]:
    """Best-effort fetch of `muni_user_preferences.last_page_id` (and
    last_space_id) for the authenticated user. Returns
    ``(page_id_or_None, space_id_or_None)``.
    """
    try:
        from .client import MuniClient
        client = MuniClient()
        result = client.user.last_visited()
        if isinstance(result, dict):
            page_value = result.get("lastPageId")
            space_value = result.get("lastSpaceId")
            page_id = page_value if isinstance(page_value, str) and page_value else None
            space_id = space_value if isinstance(space_value, str) and space_value else None
            return (page_id, space_id)
    except Exception:
        pass
    return (None, None)
