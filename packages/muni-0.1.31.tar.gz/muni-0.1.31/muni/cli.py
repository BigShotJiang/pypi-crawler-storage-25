"""argparse CLI with subcommands, KEY=VALUE parsing, and DB-aligned result helpers."""

import argparse
import base64
import json
import os
import re
import sys
import time
from pathlib import Path
from typing import Any

from . import auth
from . import display
from . import __version__
from .client import MuniClient
from .config import current_profile_name, get_active_page_id, get_active_space_id, list_profiles, load_config, save_config, set_current_profile
from .exceptions import MuniError

TERMINAL_STATUSES = {"completed", "failed", "cancelled"}
SPACE_PAGE_HELP = "Space ID (overrides active space; when --page-id is omitted, uses that space's first/default page)"
NO_SPACE_VALUES = {"none", "no-space", "api-only", "off", "clear"}
PREFERRED_RECORD_CONTAINERS = (
    "rankings",
    "top_designs",
    "sequences",
    "designs",
    "metrics",
    "ranked_poses",
    "poses",
    "affinities",
)
PREFERRED_OBJECT_CONTAINERS = ("best_metrics", "metrics_summary", "ranking", "metrics", "summary")
FILE_HINT_KEYS = (
    "pdb_files",
    "summary_files",
    "csv_files",
    "json_files",
    "cif_files",
    "pae_files",
    "plddt_files",
)

PXDESIGN_GALLERY_SCRIPT = """import { node } from '@muni/sdk'

const CALL_ID = 'muni-pxdesign-job_...'
const BUCKET = 'job-outputs'
const BASE_PATH = '<base_path from muni files JOB_ID --json>'

function structurePath(row: Record<string, unknown>): string {
  const rel = String(row.chosen_struct_path ?? '')
  if (!rel) throw new Error(`Missing chosen_struct_path for rank ${String(row.rank ?? '?')}`)
  if (rel.startsWith('design_outputs/')) return rel
  const task = String(row.task_name ?? 'config')
  return `design_outputs/${task}/${rel}`
}

export default node(
  'structure',
  {
    outputs: {
      primary: { type: 'structure' },
    },
  },
  async (ctx) => {
    if (!ctx.in.has('rows')) return

    const frame = (await ctx.in.data('rows')).asDataframe()
    const rows = [...frame.rows].sort((a, b) => Number(a.rank ?? 0) - Number(b.rank ?? 0))

    let emitted = 0
    for (const row of rows) {
      const rank = Number(row.rank)
      if (!Number.isFinite(rank)) continue

      const relativePath = structurePath(row)
      const storagePath = `${BASE_PATH}/${relativePath}`
      const outputKey = emitted === 0 ? 'primary' : `rank_${rank}`

      await ctx.out.data(outputKey, {
        __ref: { bucket: BUCKET, path: storagePath },
        dataType: 'structure',
        preview: {
          callId: CALL_ID,
          rank,
          fileName: relativePath.split('/').pop(),
          filePath: relativePath,
        },
      })
      emitted++
    }

    if (emitted === 0) {
      throw new Error('No PXDesign structure rows were available for the gallery')
    }
  },
)
"""

NODE_EXAMPLES: dict[str, dict[str, Any]] = {
    "structure": {
        "kind": "structure",
        "description": "Create molecular structure nodes and galleries.",
        "examples": [
            {
                "name": "single_structure_file",
                "title": "Single structure from a local PDB/mmCIF file",
                "commands": [
                    'muni node create "TREM2 rank 1" --type structure --file ./rank_1.cif --json',
                    "muni node read STRUCTURE_NODE_ID",
                ],
                "notes": [
                    "The CLI uploads the file once to muni-node-data.",
                    "The generated node script emits a {__ref:{bucket,path}} pointer instead of inlining structure text.",
                ],
            },
            {
                "name": "pxdesign_table_gallery",
                "title": "PXDesign gallery from table rows on a fresh canvas",
                "commands": [
                    "muni files JOB_ID --json",
                    "muni download JOB_ID design_outputs/config/summary.csv --output ./summary.csv",
                    'GROUP_ID=$(muni node create "PXDesign analysis" --type group --json | jq -r .nodeId)',
                    'TABLE_ID=$(muni node create "PXDesign summary" --type table --file ./summary.csv --group-id "$GROUP_ID" --json | jq -r .nodeId)',
                    'GALLERY_ID=$(muni node create "PXDesign structure gallery" --type structure --script ./pxdesign-gallery.ts --from "$TABLE_ID" --source-port primary --target-port rows --group-id "$GROUP_ID" --wait --json | jq -r .nodeId)',
                    'muni node read "$GALLERY_ID"',
                ],
                "script": {
                    "path": "pxdesign-gallery.ts",
                    "content": PXDESIGN_GALLERY_SCRIPT,
                },
                "notes": [
                    "Use bucket and base_path from `muni files JOB_ID --json`.",
                    "Create the group before the table so every generated node starts inside the auto-resizing analysis frame.",
                    "The table rows should include chosen_struct_path and usually task_name/rank.",
                    "The gallery script reads the connected rows port; do not hardcode the table node id.",
                    "Each gallery output stores storage_bucket + storage_path pointing at job-outputs, so CIF files are not copied into muni-node-data.",
                ],
            },
        ],
    },
}


def _format_node_examples(kind: str, scenario: str = "all") -> str:
    payload = NODE_EXAMPLES.get(kind)
    if not payload:
        available = ", ".join(sorted(NODE_EXAMPLES))
        return f"No examples available for node kind '{kind}'. Available: {available}"

    examples = payload["examples"]
    if scenario != "all":
        examples = [ex for ex in examples if ex.get("name") == scenario]
        if not examples:
            names = ", ".join(ex["name"] for ex in payload["examples"])
            return f"No '{scenario}' example for {kind}. Available scenarios: {names}"

    lines = [
        f"{kind} node examples",
        payload["description"],
        "",
    ]
    for index, example in enumerate(examples, start=1):
        lines.append(f"{index}. {example['title']}")
        lines.append("")
        lines.append("Commands:")
        for command in example.get("commands", []):
            lines.append(f"  {command}")
        script = example.get("script")
        if isinstance(script, dict):
            lines.append("")
            lines.append(f"Script: {script.get('path', 'script.ts')}")
            lines.append("```typescript")
            lines.append(str(script.get("content", "")).rstrip())
            lines.append("```")
        notes = example.get("notes", [])
        if notes:
            lines.append("")
            lines.append("Notes:")
            for note in notes:
                lines.append(f"  - {note}")
        lines.append("")
    return "\n".join(lines).rstrip()


def _node_examples_payload(kind: str, scenario: str = "all") -> dict[str, Any]:
    payload = NODE_EXAMPLES.get(kind)
    if not payload:
        return {
            "kind": kind,
            "error": f"No examples available for node kind '{kind}'",
            "availableKinds": sorted(NODE_EXAMPLES),
        }
    if scenario == "all":
        return payload
    examples = [ex for ex in payload["examples"] if ex.get("name") == scenario]
    return {
        **payload,
        "examples": examples,
        **({} if examples else {"error": f"No '{scenario}' example for {kind}"}),
    }


def _read_param_file(path: str, *, force_json: bool = False, force_text: bool = False) -> Any:
    # Support stdin via "-"
    if path == "-":
        text = sys.stdin.read()
        if force_text:
            return text
        if force_json:
            try:
                return json.loads(text)
            except json.JSONDecodeError as exc:
                raise MuniError(f"Invalid JSON from stdin: {exc}") from exc
        return text

    file_path = Path(path).expanduser()
    if not file_path.is_file():
        # If force_text and not a file path, treat the value as inline text
        if force_text:
            return path
        raise MuniError(f"Parameter file not found: {path}")

    text = file_path.read_text()
    if force_text:
        return text
    if force_json or file_path.suffix.lower() == ".json":
        try:
            return json.loads(text)
        except json.JSONDecodeError as e:
            raise MuniError(f"Invalid JSON in {path}: {e}")
    return text


def _read_script_arg(path: str | None, *, inline_text: str | None = None) -> str | None:
    """Read a node script with strict path semantics.

    ``--script`` is intentionally path-only (or ``-`` for stdin) so agents do
    not accidentally create broken nodes when a file path is misspelled.
    Inline source must use ``--script-text``.
    """
    if path and inline_text is not None:
        raise MuniError("Use only one of --script or --script-text.")
    if inline_text is not None:
        return inline_text
    if not path:
        return None
    if path == "-":
        return sys.stdin.read()
    file_path = Path(path).expanduser()
    if not file_path.is_file():
        raise MuniError(
            f"Script file not found: {path}. Use --script-text for inline source or --script - for stdin."
        )
    return file_path.read_text()


# `_local_node_script_check` and `_infer_node_kind_from_script` were  removed
# 2026-05-04 (PR C of
# node-script-preflight.md). `muni node check` now calls the real preflight
# engine via `client.scripts.preflight()`, which runs all 6 analyzers
# (syntax / typecheck / api-usage / ports / literal-schema / graph) and
# returns byte-identical diagnostics to what the server pipeline records.


def _parse_expect_output(values: list[str] | None, *, as_json: bool) -> list[dict[str, str]]:
    expectations: list[dict[str, str]] = []
    for value in values or []:
        parts = value.split(":", 1)
        if len(parts) != 2 or not parts[0] or not parts[1]:
            _fail(f"Invalid --expect-output '{value}' — expected OUTPUT_KEY:DATA_TYPE", as_json=as_json)
        expectations.append({"outputKey": parts[0], "dataType": parts[1]})
    return expectations


def _data_row_summary(data_row: dict[str, Any] | None, *, output_key: str = "primary") -> dict[str, Any]:
    if not isinstance(data_row, dict):
        return {"outputKey": output_key, "exists": False}
    column_schema = data_row.get("columnSchema") or data_row.get("column_schema") or []
    column_count = len(column_schema) if isinstance(column_schema, list) else None
    return {
        "outputKey": data_row.get("outputKey") or data_row.get("output_key") or output_key,
        "exists": True,
        "dataType": data_row.get("dataType") or data_row.get("data_type"),
        "rowCount": data_row.get("rowCount") if data_row.get("rowCount") is not None else data_row.get("row_count"),
        "columnCount": column_count,
        "columnSchema": column_schema,
        "storagePath": data_row.get("storagePath") or data_row.get("storage_path"),
    }


def _collect_node_status(
    client: MuniClient,
    node_id: str,
    expected_outputs: list[dict[str, str]],
) -> dict[str, Any]:
    node = client.read_node(node_id)
    runtime = node.get("runtime") if isinstance(node.get("runtime"), dict) else {}
    current_run = node.get("currentRun") if isinstance(node.get("currentRun"), dict) else None
    current = _data_row_summary(node.get("currentData"), output_key="primary")
    outputs_by_key: dict[str, dict[str, Any]] = {}
    if current.get("exists"):
        outputs_by_key[str(current["outputKey"])] = current

    for expectation in expected_outputs:
        key = expectation["outputKey"]
        if key in outputs_by_key:
            continue
        try:
            outputs_by_key[key] = _data_row_summary(client.node_data.read(node_id, output_key=key), output_key=key)
        except Exception as exc:
            outputs_by_key[key] = {"outputKey": key, "exists": False, "error": str(exc)}

    lifecycle = runtime.get("lifecycle")
    current_run_status = current_run.get("overallStatus") if current_run else None
    return {
        "nodeId": node_id,
        "status": current_run_status,
        "lifecycle": lifecycle,
        "lastError": runtime.get("lastError"),
        "currentRun": current_run,
        "compileResult": node.get("compileResult"),
        "executeResult": node.get("executeResult"),
        "validateResult": node.get("validateResult"),
        "outputs": list(outputs_by_key.values()),
    }


def _node_run_from_action(node_id: str, action: Any) -> dict[str, Any] | None:
    if not isinstance(action, dict):
        return None
    status = action.get("status")
    if status not in {"completed", "failed", "saved", "preflight_failed"}:
        return None
    payload = {
        "nodeId": node_id,
        "status": status,
        "runId": action.get("runId"),
        "currentRun": action.get("currentRun"),
        "outputs": action.get("outputs") if isinstance(action.get("outputs"), list) else [],
    }
    if action.get("error"):
        payload["error"] = action.get("error")
    return payload


def _evaluate_node_assertions(
    status: dict[str, Any],
    *,
    expected_outputs: list[dict[str, str]],
    min_rows: int | None,
    min_columns: int | None,
) -> dict[str, Any]:
    checks: list[dict[str, Any]] = []
    outputs = {
        str(output.get("outputKey")): output
        for output in status.get("outputs", [])
        if isinstance(output, dict) and output.get("outputKey")
    }

    for expectation in expected_outputs:
        key = expectation["outputKey"]
        expected_type = expectation["dataType"]
        output = outputs.get(key)
        if not output or not output.get("exists"):
            checks.append({
                "name": "expect_output",
                "status": "failed",
                "outputKey": key,
                "message": f"Expected output '{key}' was not stored.",
            })
            continue
        actual_type = output.get("dataType")
        checks.append({
            "name": "expect_output",
            "status": "passed" if actual_type == expected_type else "failed",
            "outputKey": key,
            "expectedDataType": expected_type,
            "actualDataType": actual_type,
        })

    if min_rows is not None:
        primary = outputs.get("primary") or next(iter(outputs.values()), None)
        actual = primary.get("rowCount") if primary else None
        checks.append({
            "name": "expect_min_rows",
            "status": "passed"
            if isinstance(actual, (int, float)) and not isinstance(actual, bool) and actual >= min_rows
            else "failed",
            "expectedMinRows": min_rows,
            "actualRows": actual,
        })

    if min_columns is not None:
        primary = outputs.get("primary") or next(iter(outputs.values()), None)
        actual = primary.get("columnCount") if primary else None
        checks.append({
            "name": "expect_min_columns",
            "status": "passed"
            if isinstance(actual, (int, float)) and not isinstance(actual, bool) and actual >= min_columns
            else "failed",
            "expectedMinColumns": min_columns,
            "actualColumns": actual,
        })

    failed = [check for check in checks if check.get("status") == "failed"]
    return {"status": "failed" if failed else "passed", "checks": checks}


def _parse_kv(pairs: list[str]) -> dict[str, Any]:
    """Parse KEY=VALUE pairs. Supports @file for file contents and JSON arrays/objects."""
    result: dict[str, Any] = {}
    for pair in pairs:
        if "=" not in pair:
            print(f"Error: invalid argument '{pair}' — expected KEY=VALUE", file=sys.stderr)
            sys.exit(1)
        key, value = pair.split("=", 1)
        if value.startswith("@json:"):
            value = _read_param_file(value[6:], force_json=True)
        elif value.startswith("@text:"):
            value = _read_param_file(value[6:], force_text=True)
        elif value.startswith("@") and os.path.isfile(value[1:]):
            value = _read_param_file(value[1:])
        else:
            try:
                value = json.loads(value)
            except (json.JSONDecodeError, ValueError):
                pass
        result[key] = value
    return result


"""Script-first import orchestration.

The script generators live in the server-side `@muni/sdk/scripts` module and
are called over `/api/sdk` — the CLI stays thin. We still derive labels and
extract primitives locally (CSV parsing, file reads) before handing the
primitives to the SDK generator, which returns the canonical TypeScript.

Every node kind routes through the same SDK surface, so UI drag-drop, CLI
imports, and AI chat produce byte-identical scripts for the same input.
"""

# Embed-friendly upper bound. Above this the muni_nodes.script TOAST starts
# to feel the same pressure we removed in the unified-storage work.
SCRIPT_EMBED_MAX_BYTES = 200_000


def _derive_label_from_filename(path: str) -> str:
    """Strip extension + common kind-prefix. e.g. 'chem-Epinephrine.smi' → 'Epinephrine'."""
    import os
    name = os.path.basename(path).rsplit(".", 1)[0]
    for prefix in ("chem-", "text-", "json-", "metric-"):
        if name.startswith(prefix):
            return name[len(prefix):]
    return name


_IMAGE_CONTENT_TYPES: dict[str, str] = {
    "png": "image/png",
    "jpg": "image/jpeg",
    "jpeg": "image/jpeg",
    "gif": "image/gif",
    "webp": "image/webp",
    "svg": "image/svg+xml",
    "bmp": "image/bmp",
}


def _parse_csv_to_dataframe(csv_text: str) -> dict:
    """Parse CSV into a `{columns, rows}` dict for the metric generator."""
    import csv as csv_mod
    import io

    reader = csv_mod.reader(io.StringIO(csv_text))
    rows_raw = list(reader)
    if not rows_raw:
        raise ValueError("CSV import file is empty")
    columns = [c.strip() for c in rows_raw[0]]
    rows: list[dict[str, str]] = []
    for row in rows_raw[1:]:
        if not row or all(not cell.strip() for cell in row):
            continue
        obj = {columns[i]: (row[i].strip() if i < len(row) else "") for i in range(len(columns))}
        rows.append(obj)
    return {"columns": columns, "rows": rows}


def _apply_ref_import(
    client,
    node_id: str,
    file_path: str,
    node_type: str,
) -> dict:
    """Script-first import for BIG content (structure / image).

    Upload file to `muni-node-data`, ask the SDK to build a
    `{__ref:{bucket,path}}` emit script, patch the node, run it. Script stays
    ~1 KB regardless of payload size — the bytes live in Storage and
    muni_node_data.storage_path points at the existing blob.
    """
    import os

    if not os.path.isfile(file_path):
        raise FileNotFoundError(f"File not found: {file_path}")
    filename = os.path.basename(file_path)
    ext = filename.rsplit(".", 1)[-1].lower() if "." in filename else ""

    if node_type == "image":
        # PR E of docs/plans/node-flow/node-script-preflight.md — image
        # imports go through one SDK method (`nodes.importImage`) that does
        # upload + script-write + submit server-side. CLI just sends the
        # bytes; no `node_data.upload_blob` + `scripts.image` + `edit_node`
        # + `submit_node` four-step dance.
        content_type = _IMAGE_CONTENT_TYPES.get(ext, "image/png")
        with open(file_path, "rb") as f:
            raw_bytes = f.read()
        result = client.nodes.import_image(
            node_id,
            bytes_=raw_bytes,
            file_name=filename,
            content_type=content_type,
        )
        return {
            "imported": filename,
            "storagePath": result.get("storagePath"),
            "storageBucket": "muni-node-data",
            "contentType": content_type,
            "mode": "script-first-ref",
            "runId": result.get("runId"),
        }

    if node_type == "structure":
        content_type = "chemical/x-cif" if ext == "cif" else "chemical/x-pdb"
        with open(file_path, "r", encoding="utf-8", errors="replace") as f:
            content = f.read()
        upload_res = client.node_data.upload_blob(
            node_id,
            content=content,
            content_type=content_type,
            filename=filename,
            base64=False,
        )
        bucket = upload_res.get("bucket", "muni-node-data")
        path = upload_res["path"]
        script = client.scripts.structure(bucket=bucket, path=path, filename=filename)
        client.edit_node(node_id, script=script)
        client.submit_node(node_id)
        return {
            "imported": filename,
            "storagePath": path,
            "storageBucket": bucket,
            "contentType": content_type,
            "mode": "script-first-ref",
        }

    raise ValueError(f"_apply_ref_import: unsupported node_type '{node_type}'")


def _try_build_script_first(
    client,
    node_type: str,
    file_path: str,
) -> tuple[str | None, str | None]:
    """Try to build a script-first embed for a content file.

    Extracts primitives locally (SMILES / text / JSON / CSV → dataframe) and
    hands them to the SDK's script generator. Returns (script, filename) on
    success, (None, None) if the kind needs the ref path instead (see
    `_apply_ref_import`). Raises ValueError if the file is too big to embed.
    """
    import os
    if not os.path.isfile(file_path):
        return (None, None)

    size = os.path.getsize(file_path)
    if size > SCRIPT_EMBED_MAX_BYTES and node_type in {"compound", "instruction", "json", "table", "csv", "dataframe"}:
        raise ValueError(
            f"Content file is {size} bytes — too large for script-embed (limit "
            f"{SCRIPT_EMBED_MAX_BYTES}). Structure/image/large content use "
            f"Storage references instead."
        )

    label = _derive_label_from_filename(file_path)
    filename = os.path.basename(file_path)
    ext = filename.rsplit(".", 1)[-1].lower() if "." in filename else ""

    if node_type == "compound" or ext in {"smi", "sdf", "mol"}:
        with open(file_path, "r", encoding="utf-8", errors="replace") as f:
            smiles = f.read().strip()
        return (client.scripts.compound(smiles=smiles, label=label), filename)

    if node_type == "instruction" or ext in {"txt", "md"}:
        with open(file_path, "r", encoding="utf-8", errors="replace") as f:
            text = f.read()
        return (client.scripts.instruction(content=text, label=label), filename)

    if node_type == "json" or ext == "json":
        import json as json_mod
        with open(file_path, "r", encoding="utf-8", errors="replace") as f:
            json_text = f.read()
        try:
            parsed = json_mod.loads(json_text)
        except json_mod.JSONDecodeError as e:
            raise ValueError(f"Invalid JSON in import file: {e}")
        return (client.scripts.json(data=parsed, label=label), filename)

    if node_type == "table" or ext in {"csv", "tsv"}:
        with open(file_path, "r", encoding="utf-8", errors="replace") as f:
            csv_text = f.read()
        dataframe = _parse_csv_to_dataframe(csv_text)
        return (
            client.scripts.table(
                columns=dataframe["columns"],
                rows=dataframe["rows"],
                label=label,
            ),
            filename,
        )

    # structure / image / other big content: ref path (see _apply_ref_import)
    return (None, None)


def _flatten_job_files(files_payload: Any) -> list[dict[str, Any]]:
    if isinstance(files_payload, dict) and isinstance(files_payload.get("flat_files"), list):
        return [f for f in files_payload["flat_files"] if isinstance(f, dict)]

    flat: list[dict[str, Any]] = []

    def visit(node: Any) -> None:
        if isinstance(node, dict):
            if node.get("type") == "file" or node.get("path"):
                flat.append(node)
            for child in node.get("children") or []:
                visit(child)
        elif isinstance(node, list):
            for item in node:
                visit(item)

    if isinstance(files_payload, dict):
        visit(files_payload.get("tree") or files_payload.get("files") or [])
    else:
        visit(files_payload)
    return flat


def _pick_pxdesign_summary_path(files_payload: Any) -> str | None:
    files = _flatten_job_files(files_payload)
    paths = [str(f.get("path") or f.get("name") or "") for f in files]
    preferred = [
        path for path in paths
        if path.endswith("design_outputs/config/summary.csv")
    ]
    if preferred:
        return preferred[0]
    summaries = [path for path in paths if path.endswith("summary.csv")]
    return summaries[0] if summaries else None


def _scaffold_table_from_job(client: MuniClient, call_id: str, *, kind: str) -> dict[str, Any]:
    if kind != "pxdesign-summary":
        raise MuniError(f"Unsupported metric scaffold kind '{kind}'. Available: pxdesign-summary")

    files_payload = client.list_files(call_id)
    summary_path = _pick_pxdesign_summary_path(files_payload)
    if not summary_path:
        raise MuniError(f"No PXDesign summary.csv found in job files for {call_id}.")

    content, is_text = client.download_file(call_id, summary_path)
    if not is_text:
        raise MuniError(f"Expected text CSV for {summary_path}, got binary content.")

    dataframe = _parse_csv_to_dataframe(content)
    script = client.scripts.table(
        columns=dataframe["columns"],
        rows=dataframe["rows"],
        label=f"PXDesign summary {call_id}",
    )
    return {
        "callId": call_id,
        "kind": kind,
        "summaryPath": summary_path,
        "rows": len(dataframe["rows"]),
        "columns": len(dataframe["columns"]),
        "script": script,
    }


def _output(data: Any, as_json: bool, *, stream: Any = None) -> None:
    """Print data — JSON if --json, else as-is string."""
    stream = stream or sys.stdout
    if as_json:
        if isinstance(data, str):
            print(json.dumps({"output": data}, indent=2), file=stream)
        else:
            print(json.dumps(data, indent=2), file=stream)
    else:
        print(data, file=stream)


def _progress(message: str = "", *, end: str = "\n") -> None:
    print(message, file=sys.stderr, end=end, flush=True)


def _emit_error(message: str, *, as_json: bool, payload: dict[str, Any] | None = None) -> None:
    if as_json:
        _output(payload or {"error": message}, True)
    else:
        print(f"Error: {message}", file=sys.stderr)


def _fail(message: str, *, as_json: bool, payload: dict[str, Any] | None = None, exit_code: int = 1) -> None:
    _emit_error(message, as_json=as_json, payload=payload)
    raise SystemExit(exit_code)


def _resolve_page_id_arg(args: argparse.Namespace) -> str:
    return get_active_page_id(
        getattr(args, "page_id", None),
        space_id=getattr(args, "space_id", None),
    )


def _resolve_optional_page_id_arg(args: argparse.Namespace) -> str | None:
    page_id = getattr(args, "page_id", None)
    space_id = getattr(args, "space_id", None)
    if page_id or space_id:
        return get_active_page_id(page_id, space_id=space_id)
    return None


def _resolve_optional_canvas_target_arg(args: argparse.Namespace) -> tuple[str | None, str | None]:
    """Resolve an optional canvas target for commands that can run API-only.

    Unlike `_resolve_page_id_arg`, this does not fall back to server-side last
    visited state when the user has not selected a local CLI space. That keeps
    `muni space use none` meaningful: future `muni run ...` calls stay API-only
    until the user chooses a space again.
    """
    if getattr(args, "no_space", False):
        if getattr(args, "space_id", None) or getattr(args, "page_id", None):
            raise MuniError("Use either --no-space or --space-id/--page-id, not both.")
        return None, None

    explicit_space_id = getattr(args, "space_id", None)
    explicit_page_id = getattr(args, "page_id", None)
    cfg = load_config()
    if explicit_space_id:
        return explicit_space_id, get_active_page_id(explicit_page_id, space_id=explicit_space_id)
    if explicit_page_id:
        return cfg.get("active_space_id"), explicit_page_id

    active_space_id = cfg.get("active_space_id")
    if not active_space_id:
        return None, None

    active_page_id = None if os.environ.get("MUNI_SPACE_ID") and not os.environ.get("MUNI_PAGE_ID") else cfg.get("active_page_id")
    if active_page_id:
        return active_space_id, active_page_id

    return active_space_id, get_active_page_id(space_id=active_space_id)


def _build_job_node_script(tool: str, params: dict[str, Any]) -> str:
    """Generate the same declarative job-node script used by the app SDK."""
    tool_json = json.dumps(tool)
    params_json = json.dumps(params, indent=2, sort_keys=True)
    return (
        "import { node } from '@muni/sdk'\n\n"
        "export default node('job', {\n"
        f"  tool: {tool_json},\n"
        f"  params: {params_json},\n"
        "})\n"
    )


def _submit_canvas_job_node(
    client: MuniClient,
    *,
    tool: str,
    params: dict[str, Any],
    page_id: str,
    title: str | None,
) -> dict[str, Any]:
    """Create a real canvas job node, then submit it through the app SDK path."""
    node_title = title or f"{tool} job"
    created = client.nodes.create(
        page_id,
        node_title,
        type="job",
        script=_build_job_node_script(tool, params),
    )
    node_id = created.get("nodeId") or created.get("node_id")
    if not node_id:
        raise MuniError(f"Created job node but no node id was returned: {created}")

    submitted = client.nodes.submit(str(node_id))
    call_id = submitted.get("callId") or submitted.get("call_id")
    job_id = submitted.get("jobId") or submitted.get("job_id")
    status = submitted.get("status") or "submitted"

    return {
        "status": status,
        "call_id": call_id,
        "job_id": job_id,
        "node_id": str(node_id),
        "mode": "canvas",
        "tool": tool,
    }


def _ensure_interactive(args: argparse.Namespace, description: str) -> None:
    if getattr(args, "json", False) or not sys.stdin.isatty():
        raise MuniError(f"{description} requires an argument in non-interactive mode.")


def _choose_index(prompt: str, max_index: int, *, allow_none: bool = False, allow_manual: bool = True) -> str:
    while True:
        choice = input(prompt).strip()
        lowered = choice.lower()
        if allow_none and lowered in {"0", "none", "no-space", "api-only"}:
            return "none"
        if allow_manual and lowered in {"m", "manual"}:
            return "manual"
        if choice.isdigit():
            index = int(choice)
            if 1 <= index <= max_index:
                return choice
        print("Choose a listed number" + (", 0" if allow_none else "") + (", or m for manual entry." if allow_manual else "."))


def _resolve_page_in_space(client: MuniClient, space_id: str, page_selector: str) -> dict[str, Any]:
    """Resolve a page by ID or exact title within a space."""
    try:
        return client.get_page(page_selector, space_id=space_id)
    except Exception:
        pass

    pages = client.list_pages(space_id)
    matches = [
        page for page in pages
        if page.get("id") == page_selector or page.get("title") == page_selector
    ]
    if len(matches) == 1:
        return matches[0]
    if len(matches) > 1:
        raise MuniError(f"Multiple pages named {page_selector!r}; use the page ID.")
    raise MuniError(f"Page not found in active space: {page_selector}")


def _default_page_for_space(client: MuniClient, space_id: str) -> tuple[str | None, str | None]:
    try:
        default_page = client.pages.get_default(space_id)
        return default_page.id, getattr(default_page, "title", None)
    except Exception:
        pass

    try:
        pages = client.list_pages(space_id)
        if pages:
            first = pages[0]
            return first.get("id"), first.get("title")
    except Exception:
        pass
    return None, None


def _sdk_value_to_dict(value: Any) -> Any:
    if hasattr(value, "model_dump"):
        return value.model_dump(by_alias=True)
    return value


def _connection_to_dict(connection: Any) -> dict[str, Any]:
    data = _sdk_value_to_dict(connection)
    if not isinstance(data, dict):
        raise MuniError(f"Unexpected connection response: {data!r}")
    return data


def _format_connection_endpoint(node_id: str | None, port: str | None) -> str:
    if not node_id:
        return "(external)"
    return f"{node_id}.{port or 'primary'}"


def _format_connections_table(connections: list[dict[str, Any]]) -> str:
    if not connections:
        return "No connections on this page."

    rows = []
    for conn in connections:
        rows.append(
            [
                str(conn.get("id", "")),
                _format_connection_endpoint(conn.get("sourceNodeId"), conn.get("sourcePort")),
                _format_connection_endpoint(conn.get("targetNodeId"), conn.get("targetPort")),
                str(conn.get("kind", "data")),
                "yes" if conn.get("isEnabled", True) else "no",
            ]
        )

    headers = ["ID", "SOURCE", "TARGET", "KIND", "ENABLED"]
    widths = [
        max(len(headers[i]), *(len(row[i]) for row in rows))
        for i in range(len(headers))
    ]
    lines = ["  ".join(headers[i].ljust(widths[i]) for i in range(len(headers)))]
    lines.append("  ".join("-" * widths[i] for i in range(len(headers))))
    lines.extend("  ".join(row[i].ljust(widths[i]) for i in range(len(headers))) for row in rows)
    return "\n".join(lines)


def _find_connection_on_page(client: MuniClient, page_id: str, connection_id: str) -> dict[str, Any]:
    for connection in client.connections.list(page_id):
        conn = _connection_to_dict(connection)
        if conn.get("id") == connection_id:
            return conn
    raise MuniError(f"Connection not found on page {page_id}: {connection_id}")


def _maybe_run_connection_target(client: MuniClient, target_node_id: str | None, args: argparse.Namespace) -> dict[str, Any] | None:
    if getattr(args, "no_run", False) or not target_node_id:
        return None
    return client.submit_node(
        target_node_id,
        wait=getattr(args, "wait", False),
        timeout=getattr(args, "timeout", 60) or 60,
    )


def _connection_result_payload(
    result: dict[str, Any],
    *,
    action: str,
    target_node_id: str | None,
    target_run: dict[str, Any] | None,
) -> dict[str, Any]:
    payload = dict(result)
    payload["action"] = action
    if target_node_id:
        payload["targetNodeId"] = target_node_id
    if target_run is not None:
        payload["targetRun"] = target_run
    return payload


def _load_params_file(path: str) -> dict[str, Any]:
    payload = _read_param_file(path, force_json=True)
    if not isinstance(payload, dict):
        raise MuniError("Params file must contain a top-level JSON object")
    return payload


def _parse_input_bindings(pairs: list[str] | None) -> dict[str, str]:
    bindings: dict[str, str] = {}
    for pair in pairs or []:
        if "=" not in pair:
            raise MuniError(f'Invalid binding "{pair}". Expected INPUT_NAME=NODE_REF.')
        input_name, node_ref = pair.split("=", 1)
        input_name = input_name.strip()
        node_ref = node_ref.strip()
        if not input_name or not node_ref:
            raise MuniError(f'Invalid binding "{pair}". Expected INPUT_NAME=NODE_REF.')
        bindings[input_name] = node_ref
    return bindings


def _schema_type_matches(key: str, value: Any, expected: Any) -> bool:
    if isinstance(expected, list):
        return any(_schema_type_matches(key, value, item) for item in expected)
    if expected == "string":
        return isinstance(value, str)
    if expected == "integer":
        return isinstance(value, int) and not isinstance(value, bool)
    if expected == "number":
        return isinstance(value, (int, float)) and not isinstance(value, bool)
    if expected == "boolean":
        return isinstance(value, bool)
    if expected == "object":
        if isinstance(value, dict):
            return True
        if key.endswith("_json") and isinstance(value, list):
            return True
        return False
    if expected == "array":
        return isinstance(value, list)
    if expected == "null":
        return value is None
    return True


def _coerce_value_for_schema(value: Any, expected: Any) -> Any:
    if isinstance(expected, list):
        for item in expected:
            coerced = _coerce_value_for_schema(value, item)
            if _schema_type_matches("", coerced, item):
                return coerced
        return value

    if expected == "boolean":
        if isinstance(value, bool):
            return value
        if isinstance(value, int) and value in (0, 1):
            return bool(value)
        if isinstance(value, str):
            normalized = value.strip().lower()
            if normalized in {"true", "1"}:
                return True
            if normalized in {"false", "0"}:
                return False
        return value

    if expected == "integer" and isinstance(value, str):
        normalized = value.strip()
        if re.fullmatch(r"[+-]?\d+", normalized):
            try:
                return int(normalized)
            except ValueError:
                return value
        return value

    if expected == "number" and isinstance(value, str):
        normalized = value.strip()
        try:
            return float(normalized)
        except ValueError:
            return value

    return value


def _coerce_kwargs_against_tool(tool: dict, kwargs: dict[str, Any]) -> dict[str, Any]:
    params = tool.get("parameters", {})
    props = params.get("properties", {}) or {}
    coerced = dict(kwargs)
    for key, value in kwargs.items():
        schema = props.get(key)
        if not isinstance(schema, dict):
            continue
        expected = schema.get("type")
        if expected is None:
            continue
        coerced[key] = _coerce_value_for_schema(value, expected)
    return coerced


def _validate_kwargs_against_tool(tool: dict, kwargs: dict[str, Any]) -> list[str]:
    params = tool.get("parameters", {})
    props = params.get("properties", {}) or {}
    errors: list[str] = []

    unknown = sorted(set(kwargs.keys()) - set(props.keys()))
    if unknown:
        errors.append(f"Unknown parameter(s): {', '.join(unknown)}")

    required = params.get("required", []) or []
    missing = [name for name in required if name not in kwargs]
    if missing:
        errors.append(f"Missing required parameter(s): {', '.join(missing)}")

    one_of = params.get("oneOf", []) or []
    if one_of:
        matches = 0
        for branch in one_of:
            branch_required = branch.get("required", []) if isinstance(branch, dict) else []
            if branch_required and all(name in kwargs for name in branch_required):
                matches += 1
        if matches != 1:
            errors.append("Parameters do not satisfy exactly one allowed input mode")

    for key, value in kwargs.items():
        schema = props.get(key)
        if not isinstance(schema, dict):
            continue
        expected = schema.get("type")
        if expected is None:
            continue
        if not _schema_type_matches(key, value, expected):
            errors.append(f"Parameter '{key}' has wrong type: expected {expected}, got {type(value).__name__}")
            continue
        enum_values = schema.get("enum")
        if isinstance(enum_values, list) and value not in enum_values:
            errors.append(f"Parameter '{key}' must be one of: {', '.join(str(v) for v in enum_values)}")

    return errors


def _read_batch_source(path: str) -> str:
    if path == "-":
        return sys.stdin.read()

    file_path = Path(path).expanduser()
    if not file_path.is_file():
        raise MuniError(f"Batch file not found: {path}")
    return file_path.read_text()


def _load_batch_jsonl(path: str) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    entries: list[dict[str, Any]] = []
    failures: list[dict[str, Any]] = []
    for line_number, raw_line in enumerate(_read_batch_source(path).splitlines(), start=1):
        line = raw_line.strip()
        if not line:
            continue
        index = line_number - 1
        try:
            payload = json.loads(line)
        except json.JSONDecodeError as exc:
            failures.append({
                "index": index,
                "line_number": line_number,
                "status": "failed",
                "error": f"Invalid JSON: {exc.msg}",
            })
            continue
        if not isinstance(payload, dict):
            failures.append({
                "index": index,
                "line_number": line_number,
                "status": "failed",
                "error": "Batch lines must be JSON objects.",
            })
            continue
        entries.append({
            "index": index,
            "line_number": line_number,
            "args": payload,
        })
    return entries, failures


def _parse_field_list(raw: str | None) -> list[str]:
    if raw is None:
        return []
    fields = [part.strip() for part in raw.split(",") if part.strip()]
    if not fields:
        raise MuniError("Provide at least one field name after --fields (for example: --fields sequence,ipTM)")
    return fields


def _is_scalar(value: Any) -> bool:
    return value is None or isinstance(value, (str, int, float, bool))


def _result_payload(data: dict[str, Any]) -> Any:
    return data.get("result")


def _file_hint_keys(result: Any) -> list[str]:
    if not isinstance(result, dict):
        return []
    return [
        key for key, value in result.items()
        if key in FILE_HINT_KEYS and isinstance(value, list) and len(value) > 0
    ]


def _extract_field_targets(result: Any) -> tuple[str, list[dict[str, Any]]] | None:
    if not isinstance(result, dict):
        return None

    for key in PREFERRED_RECORD_CONTAINERS:
        value = result.get(key)
        if isinstance(value, list) and all(isinstance(item, dict) for item in value):
            return key, value

    for key, value in result.items():
        if isinstance(value, list) and all(isinstance(item, dict) for item in value):
            return key, value

    for key in PREFERRED_OBJECT_CONTAINERS:
        value = result.get(key)
        if isinstance(value, dict):
            return key, [value]

    return "result", [result]


def _resolve_field_path(value: Any, path: str) -> Any:
    current = value
    for segment in path.split("."):
        if isinstance(current, dict):
            if segment not in current:
                return None
            current = current[segment]
        elif isinstance(current, list):
            if not segment.isdigit():
                return None
            idx = int(segment)
            if idx < 0 or idx >= len(current):
                return None
            current = current[idx]
        else:
            return None
    return current


def _project_fields(records: list[dict[str, Any]], fields: list[str]) -> list[dict[str, Any]]:
    return [{field: _resolve_field_path(record, field) for field in fields} for record in records]


def _extract_sequences(result: Any) -> tuple[str, list[str]] | None:
    if not isinstance(result, dict):
        return None

    sequence_specs = (
        ("sequences", "sequence"),
        ("rankings", "sequence"),
        ("top_designs", "designed_chain_sequence"),
        ("top_designs", "sequence"),
        ("designs", "sequence"),
    )
    for container, field in sequence_specs:
        value = result.get(container)
        if not isinstance(value, list):
            continue
        sequences = [item.get(field) for item in value if isinstance(item, dict) and isinstance(item.get(field), str)]
        if sequences:
            return f"{container}.{field}", sequences
    return None


def _result_shape(result: Any) -> dict[str, Any]:
    file_keys = _file_hint_keys(result)
    field_targets = _extract_field_targets(result)
    if field_targets:
        source, records = field_targets
        if source != "result":
            if records:
                return {"kind": "records", "source": source, "count": len(records), "file_keys": file_keys}
            return {"kind": "records", "source": source, "count": 0, "file_keys": file_keys}
        if isinstance(result, dict):
            return {"kind": "root_object", "source": "result", "count": 1, "file_keys": file_keys}

    if isinstance(result, list):
        return {"kind": "list", "source": "result", "count": len(result), "file_keys": file_keys}
    if isinstance(result, str):
        return {"kind": "text", "source": "summary", "count": None, "file_keys": file_keys}
    if result is None:
        return {"kind": "empty", "source": None, "count": 0, "file_keys": file_keys}
    return {"kind": "scalar", "source": "result", "count": 1, "file_keys": file_keys}


def _suggest_scalar_fields(record: dict[str, Any]) -> list[str]:
    preferred = [
        "rank",
        "sequence",
        "designed_chain_sequence",
        "ipTM",
        "iptm",
        "pTM",
        "ptm",
        "pLDDT",
        "plddt",
        "design",
        "design_to_target_iptm",
        "design_ptm",
        "confidence_score",
        "best_affinity",
        "affinity",
        "Kd_M",
        "dG_kcal_mol",
        "duration_seconds",
    ]
    chosen = [field for field in preferred if field in record and _is_scalar(record.get(field))]
    if chosen:
        return chosen[:4]

    return [key for key, value in record.items() if _is_scalar(value)][:4]


def _result_hint(call_id: str, data: dict[str, Any]) -> str:
    result = _result_payload(data)
    job_type = data.get("job_type", "?")
    shape = _result_shape(result)
    lines = [f"Completed: {call_id} ({job_type})"]

    if shape["kind"] == "records":
        lines.append(f"Result shape: {shape['source']} ({shape['count']} record{'s' if shape['count'] != 1 else ''})")
    elif shape["kind"] == "root_object":
        lines.append("Result shape: scorecard/object")
    elif shape["kind"] == "text":
        lines.append("Result shape: text summary")
    elif shape["file_keys"]:
        lines.append("Result shape: file manifest + metadata")

    sequence_data = _extract_sequences(result)
    if sequence_data:
        lines.append(f"Next: muni results {call_id} --sequences")
        return "\n".join(lines)

    field_targets = _extract_field_targets(result)
    if field_targets:
        source, records = field_targets
        if records:
            fields = _suggest_scalar_fields(records[0])
            if fields and (source != "designs" or not shape["file_keys"]):
                lines.append(f"Next: muni results {call_id} --fields {','.join(fields)}")
                if shape["file_keys"]:
                    lines.append(f"Files: muni files {call_id}")
                return "\n".join(lines)

    if shape["file_keys"]:
        lines.append(f"Next: muni files {call_id}")
    else:
        lines.append(f"Next: muni results {call_id} --json")
    return "\n".join(lines)


def _file_count_from_files_data(files_data: dict[str, Any] | None) -> int | None:
    if not isinstance(files_data, dict):
        return None
    total = files_data.get("total_files")
    if isinstance(total, int):
        return total
    files = files_data.get("files")
    if isinstance(files, list):
        return len(files)
    tree = files_data.get("tree")
    if isinstance(tree, list):
        return len(_flatten_job_files(tree))
    return None


def _wait_summary_from_data(
    call_id: str,
    status_data: dict[str, Any],
    result_data: dict[str, Any] | None = None,
    files_data: dict[str, Any] | None = None,
) -> dict[str, Any]:
    status = status_data.get("status", "?")
    summary = {
        "call_id": call_id,
        "job_type": status_data.get("job_type"),
        "status": status,
        "updated_at": status_data.get("updated_at"),
        "completed_at": status_data.get("completed_at"),
    }
    if title := status_data.get("title"):
        summary["title"] = title
    if provider := status_data.get("provider"):
        summary["provider"] = provider
    if runtime := status_data.get("runtime_seconds"):
        summary["runtime_seconds"] = runtime
    if error := status_data.get("error"):
        summary["error"] = error

    if result_data is not None and status == "completed":
        result = _result_payload(result_data)
        shape = _result_shape(result)
        summary["result_kind"] = shape["kind"]
        if source := shape.get("source"):
            summary["result_source"] = source
        if shape.get("count") is not None:
            summary["result_count"] = shape["count"]
        file_count = _file_count_from_files_data(files_data)
        if file_count is not None:
            summary["has_file_outputs"] = file_count > 0
            summary["file_count"] = file_count
            if file_count > 0:
                summary["files_command"] = f"muni files {call_id}"
        else:
            summary["has_file_outputs"] = bool(shape["file_keys"])
    return summary


def _wait_for_jobs(
    client: MuniClient,
    call_ids: list[str],
    *,
    timeout: int,
    interval: int,
    progress_mode: str,
) -> tuple[list[dict[str, Any]], dict[str, dict[str, Any]], list[str]]:
    from .realtime import create_job_waiter

    start = time.time()
    pending = list(dict.fromkeys(call_ids))
    last_status: dict[str, str] = {}
    last_follow_line: dict[str, str] = {}
    summaries: dict[str, dict[str, Any]] = {}
    results_by_call: dict[str, dict[str, Any]] = {}

    # Try realtime subscription; falls back to polling on failure.
    waiter = create_job_waiter(client, pending)

    # Token refresh tracking for long-running jobs (JWT expires in ~1hr).
    TOKEN_REFRESH_INTERVAL = 2400  # 40 minutes
    last_token_refresh = time.time()

    if progress_mode == "multi" and pending:
        _progress(f"Waiting for {len(pending)} job{'s' if len(pending) != 1 else ''}...")

    try:
        while pending:
            elapsed = time.time() - start
            if elapsed >= timeout:
                timed_out = list(pending)
                for call_id in timed_out:
                    status = last_status.get(call_id, "submitted")
                    summaries[call_id] = {
                        "call_id": call_id,
                        "status": "timeout",
                        "last_status": status,
                        "timed_out_after_seconds": timeout,
                    }
                ordered = [summaries[call_id] for call_id in call_ids if call_id in summaries]
                return ordered, results_by_call, timed_out

            # Refresh token periodically for long-running jobs.
            if time.time() - last_token_refresh >= TOKEN_REFRESH_INTERVAL:
                try:
                    from .auth import ensure_token
                    creds = ensure_token()
                    if waiter:
                        waiter.refresh_token(creds["access_token"])
                    last_token_refresh = time.time()
                except Exception:
                    pass

            # If realtime is active, wait for an event before polling.
            # This replaces the sleep at the bottom of the loop — we either
            # wake instantly on a realtime notification or after `interval` seconds.
            if waiter:
                for call_id in list(pending):
                    waiter.wait_for_update(call_id, timeout=interval / max(len(pending), 1))

            for call_id in list(pending):
                status_data = client.job_status(call_id)
                status = status_data.get("status", "?")
                previous = last_status.get(call_id)

                if progress_mode == "follow_single":
                    parts = [f"Status: {status}"]
                    if provider := status_data.get("provider"):
                        parts.append(f"provider={provider}")
                    if runtime := status_data.get("runtime_seconds"):
                        parts.append(f"runtime={runtime}s")
                    line = " | ".join(parts)
                    if line != last_follow_line.get(call_id):
                        _progress(line)
                        last_follow_line[call_id] = line
                elif progress_mode == "status_single" and status != previous:
                    _progress(f"\r  Status: {status}...", end="")

                last_status[call_id] = status

                if status == "completed":
                    _, result_data = client.job_results(call_id)
                    files_data = None
                    try:
                        files_data = client.list_files(call_id)
                    except Exception:
                        files_data = None
                    results_by_call[call_id] = result_data
                    summaries[call_id] = _wait_summary_from_data(call_id, status_data, result_data, files_data)
                    pending.remove(call_id)
                    if progress_mode == "multi":
                        _progress(f"Completed: {call_id}")
                elif status in {"failed", "cancelled"}:
                    summaries[call_id] = _wait_summary_from_data(call_id, status_data)
                    pending.remove(call_id)
                    if progress_mode == "multi":
                        label = "Failed" if status == "failed" else "Cancelled"
                        _progress(f"{label}: {call_id}")

            if pending and not waiter:
                time.sleep(interval)
    finally:
        if waiter:
            waiter.stop()

    if progress_mode == "status_single":
        _progress()

    ordered = [summaries[call_id] for call_id in call_ids if call_id in summaries]
    return ordered, results_by_call, []


def _maybe_print_follow_logs(client: MuniClient, call_id: str, max_lines: int) -> None:
    try:
        log_data = client.job_logs(call_id, max_lines=max_lines)
    except MuniError:
        return

    logs = log_data.get("logs", "")
    if not logs:
        message = log_data.get("log_message")
        if message:
            _progress("\n--- logs ---")
            _progress(message)
        return

    _progress("\n--- logs tail ---")
    _progress(logs)


def _filtered_results_payload(call_id: str, data: dict[str, Any], *, fields: list[str] | None = None, sequences: bool = False) -> tuple[str, Any]:
    result = _result_payload(data)

    if sequences:
        sequence_data = _extract_sequences(result)
        if not sequence_data:
            raise MuniError(
                f"No sequences found in job {call_id}. Try 'muni results {call_id} --fields ...' or 'muni files {call_id}'."
            )
        source, items = sequence_data
        return source, items

    assert fields is not None
    targets = _extract_field_targets(result)
    if not targets:
        raise MuniError(f"Job {call_id} has no structured result object. Try 'muni files {call_id}' instead.")

    source, records = targets
    if not records:
        return source, []

    projected = _project_fields(records, fields)
    return source, projected


def _format_batch_summary(summary: dict[str, Any], *, include_call_ids: bool) -> str:
    lines = [
        f"Batch: {summary.get('tool_name', '?')}",
        f"Submitted: {summary.get('submitted', 0)}",
        f"Failed: {summary.get('failed', 0)}",
    ]
    if batch_id := summary.get("batch_id"):
        lines.append(f"Batch ID: {batch_id}")
    if queue_name := summary.get("queue_name"):
        lines.append(f"Queue: {queue_name}")
    call_ids = summary.get("call_ids", [])
    if include_call_ids and call_ids:
        lines.append("Call IDs:")
        lines.extend(f"  {call_id}" for call_id in call_ids)
    return "\n".join(lines)


def _print_batch_failures(summary: dict[str, Any]) -> None:
    for item in summary.get("items", []):
        if item.get("status") != "failed":
            continue
        label = (
            f"line {item['line_number']}"
            if item.get("line_number") is not None
            else f"item {int(item.get('index', 0)) + 1}"
        )
        _emit_error(f"{label}: {item.get('error', 'Batch item failed')}", as_json=False)


def _merge_batch_summary(
    tool_name: str,
    prepared_entries: list[dict[str, Any]],
    local_failures: list[dict[str, Any]],
    api_summary: dict[str, Any] | None,
) -> dict[str, Any]:
    remapped_items: list[dict[str, Any]] = []
    if api_summary is not None:
        for item in api_summary.get("items", []):
            mapped = prepared_entries[item["index"]]
            remapped_items.append({
                **item,
                "index": mapped["index"],
                "line_number": mapped["line_number"],
            })

    merged = {
        "tool_name": tool_name,
        "submitted": api_summary.get("submitted", 0) if api_summary else 0,
        "failed": (api_summary.get("failed", 0) if api_summary else 0) + len(local_failures),
        "call_ids": api_summary.get("call_ids", []) if api_summary else [],
        "items": sorted(local_failures + remapped_items, key=lambda item: item.get("index", 0)),
    }
    if api_summary:
        if api_summary.get("batch_id"):
            merged["batch_id"] = api_summary["batch_id"]
        if api_summary.get("queue_name"):
            merged["queue_name"] = api_summary["queue_name"]
    return merged


def _resolve_active_space_info(client: MuniClient, cfg: dict[str, Any] | None = None) -> tuple[str | None, str | None]:
    config = cfg or load_config()
    active_space_id = config.get("active_space_id")
    if not active_space_id:
        return None, None

    try:
        spaces = client.list_spaces()
    except Exception:
        return active_space_id, None

    match = next((space for space in spaces if space.get("id") == active_space_id), None)
    return active_space_id, match.get("name") if match else None


# _load_and_validate_node_script — removed (old BioArena node script validation)


# ── Subcommand handlers ──────────────────────────────────────────

def cmd_config(args: argparse.Namespace) -> None:
    """Interactive config setup and profile management."""
    action = getattr(args, "config_action", None)

    if action == "profiles":
        data = {
            "current_profile": current_profile_name(),
            "profiles": list_profiles(),
        }
        _output(data if args.json else "\n".join(
            [f"Current profile: {data['current_profile']}", "Profiles:"]
            + [f"  {name}" for name in data["profiles"]]
        ), args.json)
        return

    if action == "show":
        cfg = load_config()
        masked = dict(cfg)
        if masked.get("supabase_publishable_key"):
            masked["supabase_publishable_key"] = f"{masked['supabase_publishable_key'][:12]}..."
        client = MuniClient()
        active_space_id, active_space_name = _resolve_active_space_info(client, cfg)
        if active_space_id:
            masked["active_space_id"] = active_space_id
        if active_space_name:
            masked["active_space_name"] = active_space_name
        active_page_id = cfg.get("active_page_id")
        if active_page_id:
            masked["active_page_id"] = active_page_id
            try:
                page = client.get_page(active_page_id)
                masked["active_page_title"] = page.get("title", "")
            except Exception:
                pass
        _output(masked if args.json else display.format_config_display(masked), args.json)
        return

    if action == "use":
        set_current_profile(args.profile_name)
        _output(
            {"current_profile": args.profile_name} if args.json else f"Switched to profile: {args.profile_name}",
            args.json,
        )
        return

    cfg = load_config()
    profile_name = cfg.get("profile", current_profile_name())

    api_url = input(f"API URL [{cfg.get('api_url', '')}]: ").strip()
    if api_url:
        cfg["api_url"] = api_url

    app_url = input(f"App URL [{cfg.get('app_url', '')}]: ").strip()
    if app_url:
        cfg["app_url"] = app_url

    sb_url = input(f"Supabase URL [{cfg.get('supabase_url', '')}]: ").strip()
    if sb_url:
        cfg["supabase_url"] = sb_url

    sb_key = input(f"Supabase Publishable Key [{cfg.get('supabase_publishable_key', '')[:20]}...]: ").strip()
    if sb_key:
        cfg["supabase_publishable_key"] = sb_key

    save_config(cfg, profile=profile_name, set_current=True)
    _output({"profile": profile_name, "saved": True} if args.json else f"Config saved to ~/.muni/config.json (profile: {profile_name})", args.json)


def cmd_login(args: argparse.Namespace) -> None:
    email = getattr(args, "email", None)
    password = getattr(args, "password", None)
    use_device = bool(getattr(args, "device", False))
    use_password = bool(getattr(args, "password_flow", False)) or bool(email) or bool(password)
    open_browser = not bool(getattr(args, "no_browser", False))
    client_name = getattr(args, "client_name", None)

    if use_password and use_device:
        raise MuniError("--device cannot be combined with --email/--password/--password-flow.")

    if use_password:
        method = "password"
    elif use_device:
        method = "device"
    else:
        method = "browser"

    creds = auth.login(
        method=method,
        email=email,
        password=password,
        open_browser=open_browser,
        client_name=client_name,
    )
    _output(
        {"email": creds["email"], "method": method} if args.json else f"Logged in as {creds['email']}",
        args.json,
    )


def cmd_logout(args: argparse.Namespace) -> None:
    auth.logout()
    _output({"logged_out": True} if args.json else "Logged out.", args.json)


def cmd_whoami(args: argparse.Namespace) -> None:
    info = auth.whoami()
    client = MuniClient()
    try:
        balance = client.get_balance()
        info["balance"] = balance.get("balance", balance.get("credits", 0))
    except Exception:
        pass
    info["profile"] = current_profile_name()
    active_space_id, active_space_name = _resolve_active_space_info(client)
    if active_space_id:
        info["active_space_id"] = active_space_id
    if active_space_name:
        info["active_space_name"] = active_space_name
    _output(
        info if args.json else f"Email: {info['email']}\nUser ID: {info['user_id']}\nProfile: {info['profile']}"
        + (f"\nBalance: {info['balance']} credits" if "balance" in info else "")
        + (
            f"\nActive Space: {info['active_space_name']} ({info['active_space_id']})"
            if "active_space_name" in info and "active_space_id" in info
            else f"\nActive Space: {info['active_space_id']}"
            if "active_space_id" in info
            else ""
        ),
        args.json,
    )


def cmd_balance(args: argparse.Namespace) -> None:
    client = MuniClient()
    data = client.get_balance()
    _output(data if args.json else display.format_balance(data), args.json)


def cmd_update(args: argparse.Namespace) -> None:
    """Upgrade the muni CLI in place using whichever tool installed it."""
    import shutil
    import subprocess

    current = __version__
    executable = sys.executable
    exec_lower = executable.lower()
    editable = False

    if "pipx" in exec_lower:
        method = "pipx"
        cmd = ["pipx", "upgrade", "muni"]
    elif "uv/tools" in exec_lower or "uv\\tools" in exec_lower:
        method = "uv"
        cmd = ["uv", "tool", "upgrade", "muni"]
    else:
        try:
            show = subprocess.run(
                [executable, "-m", "pip", "show", "muni"],
                capture_output=True, text=True, check=False,
            )
            editable = "Editable project location:" in show.stdout
        except FileNotFoundError:
            pass
        method = "pip-editable" if editable else "pip"
        cmd = [executable, "-m", "pip", "install", "--upgrade", "muni"]

    if getattr(args, "check", False):
        _output(
            {"current": current, "method": method} if args.json
            else f"Current version: {current}\nInstall method:  {method}\nRun `muni update` to upgrade.",
            args.json,
        )
        return

    if editable:
        _fail(
            "This is an editable dev install (pip install -e). "
            "Update your git checkout instead.",
            as_json=getattr(args, "json", False),
        )

    if method in ("pipx", "uv") and not shutil.which(cmd[0]):
        _fail(f"{cmd[0]} not found on PATH.", as_json=args.json)

    if not args.json:
        print(f"Current version: {current}")
        print(f"Updating via {method}...")

    try:
        result = subprocess.run(cmd, check=False)
    except FileNotFoundError as e:
        _fail(f"Failed to run {cmd[0]}: {e}", as_json=args.json)
        return

    if result.returncode != 0:
        _fail(f"Update failed (exit {result.returncode})", as_json=args.json)

    _output(
        {"updated": True, "previous": current, "method": method} if args.json
        else "Update complete. Run `muni --version` in a new shell to confirm.",
        args.json,
    )


def cmd_spaces(args: argparse.Namespace) -> None:
    client = MuniClient()
    spaces = client.list_spaces()
    active_space_id = load_config().get("active_space_id")
    enriched = [dict(space, is_active=space.get("id") == active_space_id) for space in spaces]
    _output(
        enriched if args.json else display.format_spaces_table(enriched, active_space_id=active_space_id),
        args.json,
    )


def cmd_space(args: argparse.Namespace) -> None:
    client = MuniClient()
    action = args.space_action

    if action == "create":
        space = client.create_space(args.name)
        space_id = space.get("id", "")
        space_name = space.get("name", args.name)

        cfg = load_config()
        cfg["active_space_id"] = space_id

        page_id: str | None = None
        page_title: str | None = None
        try:
            default_page = client.pages.get_default(space_id)
            page_id = default_page.id
            page_title = default_page.title
            cfg["active_page_id"] = page_id
        except Exception:
            pass  # Non-critical — user can still `muni page use` later

        save_config(cfg)

        if args.json:
            payload: dict[str, Any] = dict(space)
            payload["active_space_id"] = space_id
            if page_id:
                payload["active_page_id"] = page_id
                payload["active_page_title"] = page_title
            _output(payload, args.json)
        else:
            lines = [f"Created space: {space_id} ({space_name})"]
            lines.append(f"Active space set to: {space_name} ({space_id})")
            if page_id:
                label = f"{page_title} ({page_id})" if page_title else page_id
                lines.append(f"Active page set to: {label}")
            _output("\n".join(lines), args.json)
    elif action == "delete":
        client.delete_space(args.space_id)
        _output({"deleted": args.space_id} if args.json else f"Deleted space {args.space_id}", args.json)
    elif action == "members":
        members = client.space_members(args.space_id)
        _output(members if args.json else display.format_members_table(members), args.json)
    elif action == "invite":
        result = client.invite_to_space(args.space_id, args.email)
        _output({"result": result} if args.json else result, args.json)
    elif action == "use":
        requested_space = (args.space_id or "").strip()
        if not requested_space:
            _ensure_interactive(args, "Interactive space selection")
            spaces = client.list_spaces()
            if not spaces:
                _fail("No spaces found.", as_json=args.json)
            print("Select active space:")
            print("  0. No active space (API-only)")
            for index, space in enumerate(spaces, start=1):
                print(f"  {index}. {space.get('name', '(untitled)')} ({space.get('id', '?')})")
            print("  m. Enter space ID or name manually")
            choice = _choose_index("Space: ", len(spaces), allow_none=True)
            if choice == "none":
                cfg = load_config()
                cfg.pop("active_space_id", None)
                cfg.pop("active_page_id", None)
                save_config(cfg)
                payload = {"active_space_id": None, "active_page_id": None, "mode": "api-only"}
                _output(payload if args.json else "Active space cleared. Future jobs run API-only unless you pass a space.", args.json)
                return
            if choice == "manual":
                requested_space = input("Space ID or name: ").strip()
                if not requested_space:
                    raise MuniError("No space entered.")
            else:
                requested_space = spaces[int(choice) - 1].get("id", "")

        if requested_space.lower() in NO_SPACE_VALUES:
            cfg = load_config()
            cfg.pop("active_space_id", None)
            cfg.pop("active_page_id", None)
            save_config(cfg)
            payload = {"active_space_id": None, "active_page_id": None, "mode": "api-only"}
            _output(payload if args.json else "Active space cleared. Future jobs run API-only unless you pass a space.", args.json)
            return

        space_id = client.resolve_space_id(requested_space)
        spaces = client.list_spaces()
        space_name = next((space.get("name") for space in spaces if space.get("id") == space_id), None)
        cfg = load_config()
        cfg["active_space_id"] = space_id

        # Switching spaces invalidates the prior active_page_id (it belongs to
        # a different space). Resolve the new space's default page and pin it.
        page_id, page_title = _default_page_for_space(client, space_id)
        if page_id:
            cfg["active_page_id"] = page_id
        else:
            cfg.pop("active_page_id", None)

        save_config(cfg)

        payload: dict[str, Any] = {"active_space_id": space_id}
        if space_name:
            payload["active_space_name"] = space_name
        if page_id:
            payload["active_page_id"] = page_id
            payload["active_page_title"] = page_title

        if args.json:
            _output(payload, args.json)
        else:
            lines = [
                f"Active space set to: {space_name} ({space_id})"
                if space_name else f"Active space set to: {space_id}"
            ]
            if page_id:
                label = f"{page_title} ({page_id})" if page_title else page_id
                lines.append(f"Active page set to: {label}")
            _output("\n".join(lines), args.json)


def cmd_pages(args: argparse.Namespace) -> None:
    """List pages in the active space."""
    client = MuniClient()
    space_id = get_active_space_id(getattr(args, "space_id", None))
    pages = client.list_pages(space_id)
    active_page_id = load_config().get("active_page_id")
    _output(
        pages if args.json
        else display.format_pages_table(pages, active_page_id=active_page_id),
        args.json,
    )


def cmd_page(args: argparse.Namespace) -> None:
    """Manage pages — currently supports 'use' to set active page."""
    client = MuniClient()
    action = getattr(args, "page_action", None)

    if action == "use":
        space_id = get_active_space_id(getattr(args, "space_id", None))
        requested_page = (args.page_id or "").strip()
        if not requested_page:
            _ensure_interactive(args, "Interactive page selection")
            pages = client.list_pages(space_id)
            if not pages:
                _fail(f"No pages found for space {space_id}.", as_json=args.json)
            active_page_id = load_config().get("active_page_id")
            print("Select active page:")
            for index, page in enumerate(pages, start=1):
                marker = "*" if page.get("id") == active_page_id else " "
                print(f"  {index}. {marker} {page.get('title', '(untitled)')} ({page.get('id', '?')})")
            print("  m. Enter page ID or title manually")
            choice = _choose_index("Page: ", len(pages), allow_manual=True)
            if choice == "manual":
                requested_page = input("Page ID or title: ").strip()
                if not requested_page:
                    raise MuniError("No page entered.")
            else:
                requested_page = pages[int(choice) - 1].get("id", "")

        page = _resolve_page_in_space(client, space_id, requested_page)
        cfg = load_config()
        cfg["active_space_id"] = space_id
        cfg["active_page_id"] = page["id"]
        save_config(cfg)
        title = page.get("title", "")
        message = f"Active page set to: {title} ({page['id']})" if title else f"Active page set to: {page['id']}"
        _output(
            {"active_page_id": page["id"], "title": title} if args.json else message,
            args.json,
        )
        return

    _fail("Use a subcommand: use.", as_json=args.json)


def cmd_nodes(args: argparse.Namespace) -> None:
    """List or search nodes on the active page."""
    client = MuniClient()
    action = getattr(args, "nodes_action", None)
    page_id = _resolve_page_id_arg(args)

    if action == "search":
        nodes = client.search_nodes(
            page_id,
            query=args.query,
            node_type=getattr(args, "type", None),
            limit=args.limit,
        )
        _output(
            nodes if args.json
            else display.format_search_results(nodes, args.query),
            args.json,
        )
        return

    nodes = client.search_nodes(
        page_id,
        node_type=getattr(args, "type", None),
        limit=args.limit,
    )
    _output(nodes if args.json else display.format_nodes_table(nodes), args.json)


def cmd_connections(args: argparse.Namespace) -> None:
    """List connections on the active page."""
    client = MuniClient()
    page_id = _resolve_page_id_arg(args)
    connections = [_connection_to_dict(c) for c in client.connections.list(page_id)]
    _output(connections if args.json else _format_connections_table(connections), args.json)


def cmd_connection(args: argparse.Namespace) -> None:
    """Create, edit, or remove a connection."""
    client = MuniClient()
    action = getattr(args, "connection_action", None)

    if action == "create":
        page_id = _resolve_page_id_arg(args)
        result = _connection_to_dict(
            client.connections.create(
                page_id=page_id,
                source_node_id=args.source_node_id,
                source_port=getattr(args, "source_port", "primary") or "primary",
                target_node_id=args.target_node_id,
                target_port=getattr(args, "target_port", "rows") or "rows",
                kind=getattr(args, "kind", "data") or "data",
            )
        )
        target_run = _maybe_run_connection_target(client, args.target_node_id, args)
        payload = _connection_result_payload(
            result,
            action="created",
            target_node_id=args.target_node_id,
            target_run=target_run,
        )
        _output(
            payload if args.json
            else f"Connected {args.source_node_id}.{args.source_port} -> {args.target_node_id}.{args.target_port} ({result.get('connectionId', '?')})",
            args.json,
        )
        return

    if action == "edit":
        opts: dict[str, Any] = {}
        if getattr(args, "source_node_id", None) is not None:
            opts["source_node_id"] = args.source_node_id
        if getattr(args, "target_node_id", None) is not None:
            opts["target_node_id"] = args.target_node_id
        if getattr(args, "source_port", None) is not None:
            opts["source_port"] = args.source_port
        if getattr(args, "target_port", None) is not None:
            opts["target_port"] = args.target_port
        if getattr(args, "kind", None) is not None:
            opts["kind"] = args.kind
        if getattr(args, "is_enabled", None) is not None:
            opts["is_enabled"] = args.is_enabled
        if not opts:
            _fail(
                "Provide at least one field to edit: --source-node-id, --target-node-id, --source-port, --target-port, --kind, --enabled, or --disabled.",
                as_json=args.json,
            )

        result = _connection_to_dict(client.connections.update(args.connection_id, **opts))
        target_node_id = result.get("targetNodeId")
        target_run = _maybe_run_connection_target(client, target_node_id, args)
        payload = _connection_result_payload(
            result,
            action="edited",
            target_node_id=target_node_id,
            target_run=target_run,
        )
        _output(
            payload if args.json
            else f"Edited connection {args.connection_id} -> target {target_node_id or '?'}",
            args.json,
        )
        return

    if action == "remove":
        page_id = _resolve_page_id_arg(args)
        existing = _find_connection_on_page(client, page_id, args.connection_id)
        client.connections.remove(args.connection_id)
        target_node_id = existing.get("targetNodeId")
        target_run = _maybe_run_connection_target(client, target_node_id, args)
        payload = _connection_result_payload(
            {"connectionId": args.connection_id, "removed": True},
            action="removed",
            target_node_id=target_node_id,
            target_run=target_run,
        )
        _output(
            payload if args.json
            else f"Removed connection {args.connection_id}",
            args.json,
        )
        return

    _fail("Use a subcommand: create, edit, remove.", as_json=args.json)


def cmd_node(args: argparse.Namespace) -> None:
    """Create, read, edit, remove, or run a node."""
    action = getattr(args, "node_action", None)

    if action == "examples":
        kind = getattr(args, "kind", None) or "structure"
        scenario = getattr(args, "scenario", None) or "all"
        _output(
            _node_examples_payload(kind, scenario) if args.json
            else _format_node_examples(kind, scenario),
            args.json,
        )
        return

    client = MuniClient()

    if action == "create":
        page_id = _resolve_page_id_arg(args)
        script_text = _read_script_arg(
            getattr(args, "script", None),
            inline_text=getattr(args, "script_text", None),
        )
        python_text: str | None = None
        if getattr(args, "python_code", None):
            python_text = _read_param_file(args.python_code, force_text=True)

        import_file = getattr(args, "import_file", None)
        node_type = getattr(args, "type", None) or "table"

        # Script-first content import. Content goes INTO the script as a
        # literal; sandbox execution produces muni_node_data through the
        # normal computed path. Script IS the source of truth — no import
        # bypass, no out-of-band muni_node_data write.
        # Covered kinds: chem, text, json, metric (CSV). Structure/image
        # fall through to legacy import (Storage-ref migration TBD).
        script_first_used = False
        script_first_filename: str | None = None
        if import_file:
            import os
            file_path = os.path.expanduser(import_file)
            try:
                generated, filename = _try_build_script_first(client, node_type, file_path)
            except ValueError as e:
                print(f"{e}", file=sys.stderr)
                sys.exit(1)
            if generated:
                script_text = generated
                script_first_used = True
                script_first_filename = filename

        from_node_ids = getattr(args, "from_node_ids", None) or []
        connections = None
        if from_node_ids:
            connections = [
                {
                    "sourceNodeId": source_node_id,
                    "sourcePort": getattr(args, "source_port", None) or "primary",
                    "targetPort": getattr(args, "target_port", None) or "rows",
                    "kind": "data",
                }
                for source_node_id in from_node_ids
            ]

        result = client.create_node(
            page_id,
            args.title,
            node_type=node_type,
            script=script_text,
            python_code=python_text,
            position_x=float(args.x) if getattr(args, "x", None) is not None else None,
            position_y=float(args.y) if getattr(args, "y", None) is not None else None,
            group_id=getattr(args, "group_id", None),
            connections=connections,
        )

        # Script-first: run the node so the embedded content flows out via
        # ctx.out.data → muni_node_data. Card renders on the node-executed
        # broadcast that /api/sdk nodes.submit emits on completion.
        if script_first_used and result.get("nodeId"):
            try:
                client.submit_node(result["nodeId"])
                result["imported"] = script_first_filename
                result["mode"] = "script-first"
            except Exception as e:
                result["runError"] = str(e)

        # Script-first ref path for BIG content (structure, image): upload
        # to Storage, rewrite script with a {__ref} emit, run. No legacy
        # bypass — every kind routes through the sandbox.
        elif import_file and node_type in ("structure", "image") and result.get("nodeId"):
            import os
            file_path = os.path.expanduser(import_file)
            try:
                summary = _apply_ref_import(client, result["nodeId"], file_path, node_type)
                result.update(summary)
            except Exception as e:
                print(f"{node_type} import failed: {e}", file=sys.stderr)
                result["runError"] = str(e)

        expected_outputs = _parse_expect_output(getattr(args, "expect_outputs", None), as_json=args.json)
        min_rows = getattr(args, "expect_min_rows", None)
        min_columns = getattr(args, "expect_min_columns", None)
        wants_status = bool(getattr(args, "wait", False) or expected_outputs or min_rows is not None or min_columns is not None)
        if wants_status and result.get("nodeId"):
            timeout = getattr(args, "timeout", 60) or 60
            waited = _node_run_from_action(result["nodeId"], result.get("action"))
            if waited is None:
                waited = client.wait_for_node_submit(result["nodeId"], timeout=timeout)
            result["run"] = waited
            status = _collect_node_status(client, result["nodeId"], expected_outputs)
            result["status"] = status
            if expected_outputs or min_rows is not None or min_columns is not None:
                assertions = _evaluate_node_assertions(
                    status,
                    expected_outputs=expected_outputs,
                    min_rows=min_rows,
                    min_columns=min_columns,
                )
                result["assertions"] = assertions
                if assertions["status"] == "failed":
                    failed = [c for c in assertions["checks"] if c.get("status") == "failed"]
                    message = failed[0].get("message") if failed and failed[0].get("message") else "Node output assertions failed."
                    _fail(str(message), as_json=args.json, payload=result)

        _output(
            result if args.json
            else display.format_node_create_result(result),
            args.json,
        )
        return

    if action == "check":
        # PR C of node-script-preflight.md: `muni node check` runs the real
        # preflight engine via `scripts.preflight` (the same engine the
        # server pipeline uses). Diagnostics are byte-identical to what
        # the server would record on `muni_node_runs.preflight_*`.
        node_type = getattr(args, "type", None) or "table"
        script_text = _read_script_arg(
            getattr(args, "script", None),
            inline_text=getattr(args, "script_text", None),
        )
        page_id = getattr(args, "page_id", None) or load_config().get("active_page_id") or None
        report = client.scripts.preflight(
            source=script_text,
            kind=node_type,
            page_id=page_id,
        )
        if args.json:
            _output(report, True)
        else:
            ok = report.get("ok", False)
            err_count = report.get("errorCount", 0)
            warn_count = report.get("warningCount", 0)
            duration = report.get("durationMs", 0)
            analyzers = ", ".join(report.get("analyzersRun", []))
            status_word = "ok" if ok else "error"
            print(f"Preflight: {status_word} ({err_count} errors, {warn_count} warnings, {duration}ms)")
            print(f"  analyzers: {analyzers}")
            diagnostics = report.get("diagnostics", []) or []
            for d in diagnostics:
                code = d.get("code", "?")
                source = d.get("source", "?")
                severity = d.get("severity", "?")
                msg = d.get("message", "")
                span = d.get("span") or {}
                where = ""
                if "line" in span:
                    where = f" at line {span['line']}"
                    if "column" in span:
                        where += f", col {span['column']}"
                print(f"  [{severity}] {code} ({source}){where}: {msg}")
                hint = d.get("hint") or {}
                if hint.get("text"):
                    print(f"    hint: {hint['text']}")
            next_step = report.get("nextStep")
            if not ok and next_step:
                print(f"\n→ {next_step}")
        if not report.get("ok", False):
            sys.exit(1)
        return

    if action == "read":
        node = client.read_node(args.node_id)
        _output(
            node if args.json
            else display.format_node_detail(node),
            args.json,
        )
        return

    if action == "edit":
        title = getattr(args, "title", None)
        script_text = _read_script_arg(
            getattr(args, "script", None),
            inline_text=getattr(args, "script_text", None),
        )
        python_text = None
        if getattr(args, "python_code", None):
            python_text = _read_param_file(args.python_code, force_text=True)

        # --file: generate a script-first wrapper from a content file and
        # apply it (same dispatch as `node create --file`). Embed for small
        # kinds, upload + `__ref` for structure/image.
        import_file = getattr(args, "import_file", None)
        if import_file:
            import os
            file_path = os.path.expanduser(import_file)
            if not os.path.isfile(file_path):
                print(f"File not found: {import_file}", file=sys.stderr)
                sys.exit(1)
            # Look up node type for dispatch
            node_state = client.read_node(args.node_id)
            node_type = (node_state or {}).get("type", "")
            try:
                generated, filename = _try_build_script_first(client, node_type, file_path)
            except ValueError as e:
                print(f"{e}", file=sys.stderr)
                sys.exit(1)
            if generated:
                script_text = generated
            elif node_type in ("structure", "image"):
                # Ref path: uploads + rewrites + runs in one helper.
                try:
                    summary = _apply_ref_import(client, args.node_id, file_path, node_type)
                except Exception as e:
                    print(f"Import failed: {e}", file=sys.stderr)
                    sys.exit(1)
                combined = {
                    "nodeId": args.node_id,
                    "type": node_type,
                    **summary,
                }
                _output(
                    combined if args.json
                    else f"Updated node {args.node_id} from {summary['imported']} ({node_type}, {summary['mode']})",
                    args.json,
                )
                return
            else:
                print(
                    f"Cannot import '{import_file}' into node of type '{node_type}': "
                    f"no script-first path for that kind.",
                    file=sys.stderr,
                )
                sys.exit(1)

        result = client.edit_node(
            args.node_id,
            title=title,
            script=script_text,
            python_code=python_text,
        )
        # Auto-run if --run flag is set
        if getattr(args, "run", False):
            timeout = getattr(args, "timeout", 60) or 60
            if not args.json:
                print(f"Updated node {result.get('nodeId', '?')}: {', '.join(result.get('updatedFields', []))}")
                print(f"Running node {args.node_id} (timeout: {timeout}s)...", file=sys.stderr)
            run_result = client.submit_node(args.node_id, wait=True, timeout=timeout)
            # Combine edit + run into a single JSON response
            if args.json:
                run_result["edit"] = result
                _output(run_result, True)
            else:
                status = run_result.get("status", "?")
                if status == "completed":
                    outputs = run_result.get("outputs", [])
                    summary = ", ".join(
                        f"{o['outputKey']} ({o.get('dataType', '?')}, {o.get('rowCount', '?')} rows)"
                        for o in outputs
                    ) if outputs else "no outputs"
                    print(f"Done: {summary}")
                elif status == "failed":
                    print(f"Failed: {run_result.get('error', 'Unknown error')}")
                else:
                    print(f"Status: {status} — {run_result.get('error', '')}")
        else:
            _output(
                result if args.json
                else f"Updated node {result.get('nodeId', '?')}: {', '.join(result.get('updatedFields', []))}",
                args.json,
            )
        return

    if action == "remove":
        result = client.remove_node(args.node_id)
        _output(
            result if args.json
            else f"Removed node {result.get('nodeId', '?')}",
            args.json,
        )
        return

    if action == "submit":
        should_wait = getattr(args, "wait", False)
        timeout = getattr(args, "timeout", 60) or 60
        result = client.submit_node(args.node_id, wait=should_wait, timeout=timeout)
        status = result.get("status", "?")
        if should_wait and status == "completed":
            outputs = result.get("outputs", [])
            summary = ", ".join(
                f"{o['outputKey']} ({o.get('dataType', '?')}, {o.get('rowCount', '?')} rows)"
                for o in outputs
            ) if outputs else "no outputs"
            _output(
                result if args.json
                else f"Completed: {summary}",
                args.json,
            )
        elif should_wait and status == "failed":
            _output(
                result if args.json
                else f"Failed: {result.get('error', 'Unknown error')}",
                args.json,
            )
        else:
            _output(
                result if args.json
                else f"Node {result.get('nodeId', '?')} — {status}{': ' + result.get('error', '') if result.get('error') else ''}",
                args.json,
            )
        return

    if action == "move":
        result = client.nodes.move(args.node_id, x=args.x, y=args.y)
        _output(
            result if args.json
            else f"Moved node {result.get('nodeId', '?')} to ({result.get('x')}, {result.get('y')})",
            args.json,
        )
        return

    if action == "select":
        page_id = _resolve_page_id_arg(args)
        result = client.nodes.select(page_id, args.node_ids)
        _output(
            result if args.json
            else f"Selected {len(result.get('nodeIds', []))} node(s)",
            args.json,
        )
        return

    if action == "focus":
        page_id = _resolve_page_id_arg(args)
        result = client.nodes.focus(page_id, args.node_id)
        _output(
            result if args.json
            else f"Focused on node {result.get('nodeId', '?')}",
            args.json,
        )
        return

    if action == "content":
        # Get the data row to find the storage path
        data_row = client.node_data.read(args.node_id, output_key=getattr(args, "output_key", "primary") or "primary")
        if data_row is None:
            print("No data found for this node.", file=sys.stderr)
            return

        storage_path = data_row.get("storagePath") or data_row.get("storage_path")
        if not storage_path:
            # No storage path — check preview for text
            preview = data_row.get("preview", {}) or {}
            text = preview.get("textPreview") or preview.get("text")
            if text:
                if args.json:
                    _output({"content": text, "source": "preview", "truncated": True}, True)
                else:
                    print(text)
            else:
                print("No content available (no storage path or preview).", file=sys.stderr)
            return

        # Download the blob from Supabase Storage
        import urllib.request, json as jsonmod
        access_token, _ = client._auth()
        url = f"{client.supabase_url}/storage/v1/object/muni-node-data/{storage_path}"
        req = urllib.request.Request(url, headers={
            "apikey": client.publishable_key,
            "Authorization": f"Bearer {access_token}",
        })
        try:
            with urllib.request.urlopen(req) as resp:
                raw = resp.read()
                # Try JSON parse
                try:
                    content = jsonmod.loads(raw)
                except (jsonmod.JSONDecodeError, ValueError):
                    content = raw.decode("utf-8", errors="replace")

                if args.json:
                    _output({"content": content, "source": "storage", "storagePath": storage_path, "dataType": data_row.get("dataType")}, True)
                elif isinstance(content, dict):
                    if content.get("kind") == "text" and "text" in content:
                        print(content["text"])
                    elif content.get("kind") == "dataframe" and "columns" in content:
                        cols = content["columns"]
                        print("\t".join(str(c) for c in cols))
                        for row in content.get("rows", [])[:20]:
                            print("\t".join(str(row.get(c, "")) for c in cols))
                    else:
                        print(jsonmod.dumps(content, indent=2))
                elif isinstance(content, str):
                    print(content)
                else:
                    print(str(content))
        except Exception as e:
            print(f"Failed to download content: {e}", file=sys.stderr)
        return

    if action == "connect":
        page_id = _resolve_page_id_arg(args)
        result = _connection_to_dict(
            client.connections.create(
                page_id=page_id,
                source_node_id=args.source_node_id,
                source_port=getattr(args, "source_port", "primary") or "primary",
                target_node_id=args.target_node_id,
                target_port=getattr(args, "target_port", "rows") or "rows",
                kind=getattr(args, "kind", "data") or "data",
            )
        )
        target_run = _maybe_run_connection_target(client, args.target_node_id, args)
        payload = _connection_result_payload(
            result,
            action="created",
            target_node_id=args.target_node_id,
            target_run=target_run,
        )
        _output(
            payload if args.json
            else f"Connected {args.source_node_id}.{args.source_port} -> {args.target_node_id}.{args.target_port} ({result.get('connectionId', '?')})",
            args.json,
        )
        return

    if action == "group":
        page_id = _resolve_page_id_arg(args)
        result = client.nodes.group(page_id, args.node_ids, label=args.label)
        if args.json:
            _output(result.model_dump(by_alias=True), True)
        else:
            _output(
                f"Grouped {result.node_count} nodes under {result.group_id} (\"{args.label}\")",
                False,
            )
        return

    if action == "layout-group":
        result = client.nodes.layout_group(
            args.group_id,
            algorithm=args.algorithm,
            direction=args.direction,
        )
        if args.json:
            _output(result, True)
        elif result is None:
            _output(f"Group {args.group_id}: not found", False)
        else:
            _output(
                f"Laid out {result.get('nodeCount', 0)} nodes in {args.group_id} using {args.algorithm}",
                False,
            )
        return

    if action == "ungroup":
        result = client.nodes.ungroup(args.group_id)
        if args.json:
            _output(result.model_dump(by_alias=True), True)
        else:
            status = "ungrouped" if result.removed else "no-op"
            _output(f"Group {args.group_id}: {status}", False)
        return

    if action == "table-summary":
        result = client.table_summary(args.node_id)
        if args.json:
            _output(result, True)
        else:
            print(f"{result['title']} — {result['totalRows']} rows, {result['totalColumns']} columns")
            for col in result["columns"]:
                print(f"  {col['name']:30s} {col['type']}")
        return

    if action == "table-query":
        filters = None
        if getattr(args, "filters", None):
            filters = []
            for f in args.filters:
                parts = f.split(":", 2)
                if len(parts) != 3:
                    _fail(f"Invalid filter '{f}' — expected COLUMN:OP:VALUE", as_json=args.json)
                col, op, val = parts
                # Try numeric conversion
                try:
                    val = float(val)
                    if val == int(val):
                        val = int(val)
                except ValueError:
                    pass
                filters.append({"column": col, "op": op, "value": val})

        result = client.table_query(
            args.node_id,
            columns=getattr(args, "columns", None),
            sort_by=getattr(args, "sort_by", None),
            sort_order=getattr(args, "sort_order", "asc"),
            filters=filters,
            limit=getattr(args, "limit", 20),
            offset=getattr(args, "offset", 0),
        )
        _output(result, args.json)
        return

    if action == "table-select":
        filters = None
        if getattr(args, "filters", None):
            filters = []
            for f in args.filters:
                parts = f.split(":", 2)
                if len(parts) != 3:
                    _fail(f"Invalid filter '{f}' — expected COLUMN:OP:VALUE", as_json=args.json)
                col, op, val = parts
                try:
                    val = float(val)
                    if val == int(val):
                        val = int(val)
                except ValueError:
                    pass
                filters.append({"column": col, "op": op, "value": val})

        # Convert 1-based user input to 0-based internal indices
        raw_rows = getattr(args, "rows", None)
        zero_based_rows = [r - 1 for r in raw_rows] if raw_rows else None

        result = client.table_select(
            args.node_id,
            args.action,
            rows=zero_based_rows,
            filters=filters,
        )
        if args.json:
            _output(result, True)
        else:
            if result["checkedCount"] == 0:
                print("No rows selected.")
            else:
                display_rows = [r + 1 for r in result["checkedRows"]]
                print(f"{result['checkedCount']} of {result['totalRows']} rows selected: {display_rows}")
        return

    _fail("Use a subcommand: create, check, read, edit, content, remove, run, move, select, focus, connect, examples, table-summary, table-query, table-select.", as_json=args.json)


def cmd_canvas(args: argparse.Namespace) -> None:
    client = MuniClient()
    action = getattr(args, "canvas_action", None)

    if action == "position":
        page_id = _resolve_page_id_arg(args)
        result = client.canvas.current_position(page_id)
        _output(
            result if args.json
            else display.format_canvas_position(result),
            args.json,
        )
        return

    if action == "placement":
        page_id = _resolve_page_id_arg(args)
        result = client.canvas.preview_placement(
            page_id,
            type=getattr(args, "type", None) or "table",
            width=getattr(args, "width", None),
            height=getattr(args, "height", None),
        )
        _output(
            result if args.json
            else display.format_canvas_placement_preview(result),
            args.json,
        )
        return

    _fail("Use a subcommand: position, placement.", as_json=args.json)


def cmd_tools(args: argparse.Namespace) -> None:
    client = MuniClient()
    data = client.list_tools(query=args.query, category=args.category)
    tools = data.get("tools", [])
    _output(data if args.json else display.format_tools_table(tools), args.json)


def cmd_tool(args: argparse.Namespace) -> None:
    client = MuniClient()

    if args.examples:
        data = client.get_examples(args.name)
        examples = data.get("examples", [])
        _output(data if args.json else display.format_examples(args.name, examples), args.json)
    elif args.inputs:
        tool = client.get_tool(args.name)
        _output(tool if args.json else display.format_tool_inputs(tool), args.json)
    elif args.outputs:
        tool = client.get_tool(args.name)
        contract = {
            "name": tool.get("name", args.name),
            "outputs": tool.get("outputs", []),
            "views": tool.get("views", []),
            "view_connections": tool.get("view_connections", []),
            "materialization_examples": tool.get("materialization_examples", []),
        }
        _output(contract if args.json else display.format_tool_outputs(tool), args.json)
    else:
        tool = client.get_tool(args.name)
        _output(tool if args.json else display.format_tool_detail(tool), args.json)


def cmd_run(args: argparse.Namespace) -> None:
    client = MuniClient()

    if args.batch:
        if getattr(args, "print_job_id", False):
            _fail("Cannot combine --batch with --print-job-id.", as_json=args.json)
        if args.params or args.params_file:
            _fail("Cannot combine --batch with KEY=VALUE params or --params-file.", as_json=args.json)
        if args.submit_concurrency <= 0:
            _fail("--submit-concurrency must be a positive integer.", as_json=args.json)

        parsed_entries, parse_failures = _load_batch_jsonl(args.batch)
        if not parsed_entries and not parse_failures:
            _fail("Batch input is empty.", as_json=args.json)

        tool = client.get_tool(args.tool) if args.validate or args.dry_run else None
        if tool is not None and not tool.get("batch"):
            _fail(f"Tool {args.tool} does not support batch execution.", as_json=args.json)
        prepared_entries: list[dict[str, Any]] = []
        local_failures = list(parse_failures)
        for entry in parsed_entries:
            if tool is not None:
                entry = {**entry, "args": _coerce_kwargs_against_tool(tool, entry["args"])}
            if args.validate and tool is not None:
                errors = _validate_kwargs_against_tool(tool, entry["args"])
                if errors:
                    local_failures.append({
                        "index": entry["index"],
                        "line_number": entry["line_number"],
                        "status": "failed",
                        "error": "; ".join(errors),
                    })
                    continue
            prepared_entries.append(entry)

        if args.dry_run:
            target_space_id, target_page_id = _resolve_optional_canvas_target_arg(args)
            payload = {
                "tool": args.tool,
                "profile": current_profile_name(),
                "target": {
                    "space_id": target_space_id,
                    "page_id": target_page_id,
                },
                "batch": {
                    "path": args.batch,
                    "submit_concurrency": args.submit_concurrency,
                    "parsed_items": len(parsed_entries),
                    "valid_items": len(prepared_entries),
                    "failed_items": len(local_failures),
                },
                "items": [entry["args"] for entry in prepared_entries],
                "errors": local_failures,
            }
            _output(payload if args.json else json.dumps(payload, indent=2), args.json)
            if local_failures:
                raise SystemExit(1)
            return

        target_space_id, target_page_id = _resolve_optional_canvas_target_arg(args)
        api_summary = None
        if prepared_entries:
            api_summary = client.run_batch(
                args.tool,
                [entry["args"] for entry in prepared_entries],
                space_id=target_space_id,
                page_id=target_page_id,
                title_prefix=args.title,
                submit_concurrency=args.submit_concurrency,
            )
        summary = _merge_batch_summary(args.tool, prepared_entries, local_failures, api_summary)

        wait_summaries: list[dict[str, Any]] = []
        results_by_call: dict[str, dict[str, Any]] = {}
        timed_out: list[str] = []
        if args.follow and summary["call_ids"]:
            wait_summaries, results_by_call, timed_out = _wait_for_jobs(
                client,
                summary["call_ids"],
                timeout=args.timeout or 1800,
                interval=5,
                progress_mode="multi",
            )

        if args.json:
            if args.follow:
                _output({"batch": summary, "jobs": wait_summaries}, True)
            else:
                _output(summary, True)
        else:
            _output(_format_batch_summary(summary, include_call_ids=not args.follow), False)
            _print_batch_failures(summary)
            if args.follow:
                for wait_summary in wait_summaries:
                    call_id = wait_summary["call_id"]
                    if wait_summary["status"] == "completed" and call_id in results_by_call:
                        _output(_result_hint(call_id, results_by_call[call_id]), False)
                    elif wait_summary["status"] == "timeout":
                        _emit_error(
                            f"Job {call_id} did not complete within {args.timeout or 1800}s "
                            f"(last status: {wait_summary.get('last_status', '?')})",
                            as_json=False,
                        )
                    else:
                        message = wait_summary.get("error") or f"Job {call_id} ended with status {wait_summary['status']}"
                        _emit_error(message, as_json=False)

        if summary["failed"] > 0:
            raise SystemExit(1)
        if timed_out or any(wait_summary.get("status") in {"failed", "cancelled"} for wait_summary in wait_summaries):
            raise SystemExit(1)
        return

    kwargs: dict[str, Any] = {}
    if args.params_file:
        kwargs.update(_load_params_file(args.params_file))
    kwargs.update(_parse_kv(args.params))
    print_job_id = bool(getattr(args, "print_job_id", False))
    if print_job_id and args.follow:
        _fail("Cannot combine --print-job-id with --follow.", as_json=args.json)

    tool = client.get_tool(args.tool) if args.validate or args.dry_run else None
    if tool is not None:
        kwargs = _coerce_kwargs_against_tool(tool, kwargs)

    if args.validate:
        errors = _validate_kwargs_against_tool(tool, kwargs)
        if errors:
            payload = {"errors": errors}
            if args.json:
                _output(payload, True)
            else:
                for error in errors:
                    print(f"- {error}", file=sys.stderr)
            raise SystemExit(1)

    if args.dry_run:
        target_space_id, target_page_id = _resolve_optional_canvas_target_arg(args)
        payload = {
            "tool": args.tool,
            "profile": current_profile_name(),
            "params": kwargs,
            "target": {
                "space_id": target_space_id,
                "page_id": target_page_id,
            },
            "submission": "canvas_job_node" if target_page_id else "api_only",
        }
        _output(payload if args.json else json.dumps(payload, indent=2), args.json)
        return

    target_space_id, target_page_id = _resolve_optional_canvas_target_arg(args)
    if target_page_id:
        result = _submit_canvas_job_node(
            client,
            tool=args.tool,
            params=kwargs,
            page_id=target_page_id,
            title=args.title,
        )
    else:
        result = client.run(
            args.tool, kwargs,
            space_id=target_space_id,
            page_id=target_page_id,
            title=args.title,
        )

    # Prefer job_id (DB primary key, consistent across providers) for user-facing output and polling.
    # Fall back to call_id (provider-specific external tracker) for legacy responses.
    job_ref = result.get("job_id") or result.get("call_id")

    if print_job_id:
        if not job_ref:
            _fail("Job submitted but no job_id or call_id was returned.", as_json=False)
        print(job_ref)
        return

    if not args.follow:
        _output(result if args.json else f"Submitted: {job_ref or '?'}", args.json)
        return

    if not job_ref:
        _output(result if args.json else "Job submitted (no job_id or call_id returned)", args.json)
        return
    call_id = job_ref

    summaries, results_by_call, timed_out = _wait_for_jobs(
        client,
        [call_id],
        timeout=args.timeout or 1800,
        interval=5,
        progress_mode="follow_single",
    )
    summary = summaries[0]

    if args.follow and summary.get("status") in {"failed", "cancelled"}:
        _maybe_print_follow_logs(client, call_id, args.log_lines)

    if args.json:
        _output(summary, True)
    else:
        status = summary.get("status")
        if status == "completed":
            result_data = results_by_call.get(call_id)
            if result_data is None:
                _output(f"Completed: {call_id}", False)
            else:
                _output(_result_hint(call_id, result_data), False)
        elif status == "timeout":
            _emit_error(f"Job {call_id} did not complete within {args.timeout or 1800}s", as_json=False)
        else:
            message = summary.get("error") or f"Job {call_id} ended with status {status}"
            _emit_error(message, as_json=False)

    if timed_out or summary.get("status") in {"failed", "cancelled"}:
        raise SystemExit(1)


def cmd_wait(args: argparse.Namespace) -> None:
    client = MuniClient()
    summaries, results_by_call, timed_out = _wait_for_jobs(
        client,
        args.call_ids,
        timeout=args.timeout,
        interval=5,
        progress_mode="follow_single" if len(args.call_ids) == 1 else "multi",
    )

    if args.json:
        _output({"jobs": summaries}, True)
    else:
        for summary in summaries:
            call_id = summary["call_id"]
            if summary["status"] == "completed" and call_id in results_by_call:
                _output(_result_hint(call_id, results_by_call[call_id]), False)
            elif summary["status"] == "timeout":
                _emit_error(
                    f"Job {call_id} did not complete within {args.timeout}s (last status: {summary.get('last_status', '?')})",
                    as_json=False,
                )
            else:
                message = summary.get("error") or f"Job {call_id} ended with status {summary['status']}"
                _emit_error(message, as_json=False)

    if timed_out or any(summary.get("status") in {"failed", "cancelled"} for summary in summaries):
        raise SystemExit(1)


def cmd_jobs(args: argparse.Namespace) -> None:
    client = MuniClient()
    jobs = client.list_jobs(
        space_id=args.space_id,
        status=args.status,
        tool_name=args.tool_name,
        limit=args.limit,
    )
    _output(jobs if args.json else display.format_jobs_table(jobs), args.json)


def cmd_job(args: argparse.Namespace) -> None:
    """Job management: summary, query."""
    client = MuniClient()
    action = getattr(args, "job_action", None)

    if action == "summary":
        data = client.jobs.summary(args.call_id)
        _output(data if args.json else display.format_job_summary(data), args.json)
        return

    if action == "query":
        opts = {}
        if getattr(args, "columns", None):
            opts["columns"] = [c.strip() for c in args.columns.split(",")]
        if getattr(args, "sort_by", None):
            opts["sortBy"] = args.sort_by
        if getattr(args, "sort_dir", None):
            opts["sortDir"] = args.sort_dir
        if getattr(args, "limit", None) is not None:
            opts["limit"] = args.limit
        if getattr(args, "offset", None) is not None:
            opts["offset"] = args.offset
        data = client.jobs.query(args.call_id, **opts)
        _output(data if args.json else display.format_job_query(data), args.json)
        return

    if action == "nodes":
        if args.apply:
            if getattr(args, "no_space", False):
                _fail("Cannot use --apply with --no-space; applying job nodes requires a canvas space/page.", as_json=args.json)
            call_id = args.call_id
            space_id, page_id = _resolve_optional_canvas_target_arg(args)
            if call_id.startswith("job_"):
                _, plan = client.job_nodes(call_id)
                resolved_call_id = plan.get("call_id")
                if not resolved_call_id:
                    _fail("Could not resolve provider call_id from job node plan.", as_json=args.json)
                call_id = str(resolved_call_id)
            data = client.materialize_job_nodes(
                call_id,
                space_id=space_id,
                page_id=page_id,
                launcher_node_id=args.launcher_node_id,
                refresh_contract=not args.no_refresh_contract,
                prune_stale=not args.no_prune_stale,
            )
            _output(data if args.json else display.format_job_nodes_apply(data), args.json)
        else:
            status, data = client.job_nodes(args.call_id)
            _output(data if args.json else display.format_job_nodes(data), args.json)
        return

    if action == "scaffold-table":
        result = _scaffold_table_from_job(client, args.call_id, kind=args.kind)
        output_path = getattr(args, "output", None)
        if output_path:
            path = Path(output_path).expanduser()
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(result["script"])
            result = {k: v for k, v in result.items() if k != "script"}
            result["output"] = str(path)
        if args.json:
            _output(result, True)
        elif output_path:
            print(
                f"Wrote {result['kind']} metric script to {result['output']} "
                f"({result['rows']} rows, {result['columns']} columns from {result['summaryPath']})"
            )
        else:
            print(result["script"])
        return

    _fail("Unknown job action. Use: muni job summary|query|nodes|scaffold-table", as_json=args.json)


def cmd_status(args: argparse.Namespace) -> None:
    client = MuniClient()
    data = client.job_status(args.call_id)
    _output(data if args.json else display.format_job_status(data), args.json)


def cmd_cancel(args: argparse.Namespace) -> None:
    client = MuniClient()
    http_status, data = client.cancel_job(args.call_id)
    if args.json:
        _output(data, True)
        if http_status == 409:
            raise SystemExit(1)
        return
    if http_status == 409:
        status = data.get("status", "?")
        print(f"Cannot cancel {args.call_id}: already {status}.", file=sys.stderr)
        raise SystemExit(1)
    job_id = data.get("job_id", args.call_id)
    provider_note = data.get("provider_note")
    print(f"Cancelled: {job_id}")
    if provider_note:
        print(f"Provider note: {provider_note}", file=sys.stderr)


def cmd_results(args: argparse.Namespace) -> None:
    if args.fields and args.sequences:
        _fail("Use either --fields or --sequences, not both.", as_json=args.json)

    client = MuniClient()
    http_status, data = client.job_results(args.call_id)
    if http_status == 202:
        if args.json:
            _output(data, True)
        else:
            print(f"Job {args.call_id} is still running.", file=sys.stderr)
        return

    if args.sequences:
        source, items = _filtered_results_payload(args.call_id, data, sequences=True)
        if args.json:
            _output({"call_id": args.call_id, "source": source, "count": len(items), "sequences": items}, True)
        else:
            _output("\n".join(items), False)
        return

    if args.fields:
        fields = _parse_field_list(args.fields)
        source, projected = _filtered_results_payload(args.call_id, data, fields=fields)
        if args.json:
            _output({"call_id": args.call_id, "source": source, "count": len(projected), "records": projected}, True)
        else:
            _output(json.dumps(projected, indent=2), False)
        return

    _output(data if args.json else display.format_results(data), args.json)


def cmd_files(args: argparse.Namespace) -> None:
    client = MuniClient()
    data = client.list_files(args.call_id)
    path_filter = getattr(args, "path", None)
    if path_filter and not args.json:
        _output(display.format_file_tree(data, path_prefix=path_filter), args.json)
    else:
        _output(data if args.json else display.format_file_tree(data), args.json)


def cmd_logs(args: argparse.Namespace) -> None:
    client = MuniClient()
    if not args.follow:
        data = client.job_logs(args.call_id, max_lines=args.max_lines)
        if args.json:
            _output(data, True)
        else:
            logs = data.get("logs", "")
            if logs:
                _output(logs, False)
            elif data.get("log_message"):
                print(data["log_message"], file=sys.stderr)
        return

    last_logs = ""
    last_message = None
    while True:
        data = client.job_logs(args.call_id, max_lines=args.max_lines)
        logs = data.get("logs", "")
        if logs != last_logs:
            if logs.startswith(last_logs):
                delta = logs[len(last_logs):]
                if delta:
                    print(delta, end="" if delta.endswith("\n") else "\n")
            else:
                print(logs)
            last_logs = logs
            last_message = None
        elif not logs:
            message = data.get("log_message")
            if message and message != last_message:
                print(message, file=sys.stderr)
                last_message = message

        status = client.job_status(args.call_id).get("status")
        if status in TERMINAL_STATUSES:
            break
        time.sleep(args.interval)


def cmd_download(args: argparse.Namespace) -> None:
    client = MuniClient()
    stdout_mode = args.stdout or args.output == "-"

    if stdout_mode and args.json:
        _fail("Cannot combine --stdout with --json. Pipe the raw file content directly instead.", as_json=args.json)
    if args.stdout and args.output not in (None, "-"):
        _fail("Use either --stdout or --output PATH, not both.", as_json=args.json)

    if stdout_mode:
        try:
            content, is_text = client.download_file(args.call_id, args.path)
        except MuniError as exc:
            _fail(
                f"{exc}. --stdout only works for a single file path. Use 'muni files {args.call_id}' to inspect available files.",
                as_json=False,
            )
        if is_text:
            sys.stdout.write(content)
        else:
            sys.stdout.buffer.write(base64.b64decode(content))
        return

    try:
        output_path = args.output or Path(args.path).name
        saved = client.save_file(args.call_id, args.path, output_path)
        _output({"saved": str(saved)} if args.json else f"Saved: {saved}", args.json)
    except MuniError:
        output_dir = args.output or f"./{Path(args.path).name}"
        saved_files = client.save_all_files(
            args.call_id, output_dir, path_prefix=args.path,
        )
        if not saved_files:
            raise
        if args.json:
            _output({"saved": [str(p) for p in saved_files], "count": len(saved_files)}, True)
        else:
            print(f"Downloaded {len(saved_files)} file{'s' if len(saved_files) != 1 else ''} to {output_dir}/")
            for p in saved_files:
                print(f"  {p}")


def cmd_download_all(args: argparse.Namespace) -> None:
    client = MuniClient()
    output_dir = args.output_dir or f"./{args.call_id}"
    saved = client.save_all_files(
        args.call_id,
        output_dir,
        path_prefix=args.path,
        glob_pattern=args.glob,
    )
    if args.json:
        _output({"saved": [str(p) for p in saved], "count": len(saved)}, True)
    else:
        if not saved:
            filters = []
            if args.path:
                filters.append(f"--path {args.path}")
            if args.glob:
                filters.append(f"--glob {args.glob}")
            hint = f" (filters: {', '.join(filters)})" if filters else ""
            print(f"No files matched{hint}. Use 'muni files {args.call_id}' to see available files.")
        else:
            print(f"Downloaded {len(saved)} file{'s' if len(saved) != 1 else ''} to {output_dir}/")
            for p in saved:
                print(f"  {p}")


# ── Parser ────────────────────────────────────────────────────────

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="muni",
        description="Muni CLI — manage nodes, pages, tools, jobs, spaces, and more.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""\
examples:
  muni login                                  Log in interactively
  muni spaces                                 List your spaces
  muni space create "My Space"                Create a new space
  muni space use "My Space"                   Set active space (by name or ID)
  muni pages                                  List pages in active space
  muni canvas position                        Show where the user is looking
  muni nodes                                  List nodes on active page
  muni node create "PXDesign summary" --type table
                                             Create a metric table node
  muni node create "TREM2 rank 1" --type structure --file ./rank_1.cif
                                             Import one structure using a storage ref
  muni node create "TREM2 structure gallery" --type structure --script ./pxdesign-gallery.ts
                                             Create a metric-row-driven structure gallery
  muni node examples structure               Show copyable structure scripts and commands
  muni node connect TABLE_NODE_ID STRUCTURE_NODE_ID --source-port primary --target-port rows --wait
                                             Feed metric rows into a gallery script
  muni tools -q complexa                      Search tools by name
  muni tool rfd3 --inputs            Show a tool's input parameters
  muni run rfd3 pdb_id=1UBQ --follow  Run a tool and wait for results
  muni wait job_<uuid>                        Wait for an existing job (also accepts provider call_id)
  muni jobs --status completed -n 5           List recent completed jobs
  muni job summary JOB_ID                     Structured output summary
  muni job query JOB_ID --columns rank,seq    Query job metric data
  muni results JOB_ID --fields rank,sequence  Extract specific result columns
  muni download-all JOB_ID -o ./results/      Download all job output files

Job IDs:
  Commands that take a job identifier accept either form interchangeably:
    - job_<uuid>                          Primary DB id (preferred)
    - muni-<tool>-job_<uuid>              Anyscale call_id (legacy: bioarena-<tool>-...)
    - rw-<workflow-uuid>                  Rowan call_id

pattern: plural commands (spaces, tools, jobs) list items;
         singular commands (space, tool, node, job) manage them.""",
    )
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    parser.add_argument("--json", action="store_true", help="Output as JSON")
    parser.add_argument("--profile", help="Use a named config/credentials profile")
    # Infrastructure overrides — accepted but hidden from top-level help.
    # Set these once via 'muni config' or environment variables instead.
    parser.add_argument("--api-url", help=argparse.SUPPRESS)
    parser.add_argument("--app-url", help=argparse.SUPPRESS)
    parser.add_argument("--supabase-url", help=argparse.SUPPRESS)
    parser.add_argument("--supabase-publishable-key", help=argparse.SUPPRESS)

    global_parent = argparse.ArgumentParser(add_help=False)
    global_parent.add_argument("--json", action="store_true", default=argparse.SUPPRESS, help="Output as JSON")
    global_parent.add_argument("--profile", default=argparse.SUPPRESS, help="Use a named config/credentials profile")
    global_parent.add_argument("--api-url", default=argparse.SUPPRESS, help=argparse.SUPPRESS)
    global_parent.add_argument("--app-url", default=argparse.SUPPRESS, help=argparse.SUPPRESS)
    global_parent.add_argument("--supabase-url", default=argparse.SUPPRESS, help=argparse.SUPPRESS)
    global_parent.add_argument(
        "--supabase-publishable-key",
        default=argparse.SUPPRESS,
        help=argparse.SUPPRESS,
    )

    sub = parser.add_subparsers(dest="command")

    sp_config = sub.add_parser("config", parents=[global_parent], help="Configure API URLs and keys")
    sp_config_sub = sp_config.add_subparsers(dest="config_action")
    sp_config_sub.add_parser("show", parents=[global_parent], help="Show the active profile config")
    sp_config_sub.add_parser("profiles", parents=[global_parent], help="List configured profiles")
    sp_config_use = sp_config_sub.add_parser("use", parents=[global_parent], help="Switch the default profile")
    sp_config_use.add_argument("profile_name", help="Profile name")

    sp_login = sub.add_parser(
        "login",
        parents=[global_parent],
        help="Log in (browser flow by default; --device or --password for alternatives)",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""\
examples:
  muni login                        Browser + PKCE flow (default)
  muni login --device               Device-code flow (headless / SSH)
  muni login --password             Legacy email/password prompt
  muni login -e you@ex.com -p PW    Non-interactive email/password""",
    )
    sp_login.add_argument("--email", "-e", help="Email (implies --password flow)")
    sp_login.add_argument("--password", "-p", help="Password (implies --password flow)")
    sp_login.add_argument(
        "--password-flow",
        dest="password_flow",
        action="store_true",
        help="Force the legacy email/password flow",
    )
    sp_login.add_argument(
        "--device",
        action="store_true",
        help="Use the device-code flow (no local browser)",
    )
    sp_login.add_argument(
        "--no-browser",
        dest="no_browser",
        action="store_true",
        help="Print the authorize URL instead of launching a browser",
    )
    sp_login.add_argument(
        "--client-name",
        dest="client_name",
        help="Label for this CLI session in Connected Devices (default: 'muni-cli on <host>')",
    )
    sub.add_parser("logout", parents=[global_parent], help="Clear stored credentials")
    sub.add_parser("whoami", parents=[global_parent], help="Show current user info")

    sub.add_parser("balance", parents=[global_parent], help="Show credit balance")

    sp_update = sub.add_parser(
        "update",
        parents=[global_parent],
        help="Upgrade muni to the latest version from PyPI",
    )
    sp_update.add_argument(
        "--check",
        action="store_true",
        help="Show current version and install method without upgrading",
    )

    sub.add_parser("spaces", parents=[global_parent], help="List your spaces")

    sp_space = sub.add_parser("space", parents=[global_parent], help="Manage a space",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""\
examples:
  muni space create "My Space"          Create a new space
  muni space use                        Select active space interactively
  muni space use "My Space"             Set active space (accepts name or ID)
  muni space use none                   Clear active space; run jobs API-only by default
  muni space members SPACE_ID           List members
  muni space invite SPACE_ID user@co    Invite a user
  muni space delete SPACE_ID            Delete a space""")
    sp_space_sub = sp_space.add_subparsers(dest="space_action")
    sp_create = sp_space_sub.add_parser("create", parents=[global_parent], help="Create a space")
    sp_create.add_argument("name", help="Space name")
    sp_delete = sp_space_sub.add_parser("delete", parents=[global_parent], help="Delete a space")
    sp_delete.add_argument("space_id", help="Space ID")
    sp_members = sp_space_sub.add_parser("members", parents=[global_parent], help="List space members")
    sp_members.add_argument("space_id", help="Space ID")
    sp_invite = sp_space_sub.add_parser("invite", parents=[global_parent], help="Invite a user to a space")
    sp_invite.add_argument("space_id", help="Space ID")
    sp_invite.add_argument("email", help="Email to invite")
    sp_use = sp_space_sub.add_parser("use", parents=[global_parent], help="Set the active space for node and job commands")
    sp_use.add_argument("space_id", nargs="?", help="Space ID or name; omit for interactive selection, or use 'none' for API-only")

    # ── Pages ────────────────────────────────────────────────────
    sp_pages = sub.add_parser("pages", parents=[global_parent], help="List pages in the active space")
    sp_pages.add_argument("--space-id", help="Space ID (overrides active space)")

    sp_page = sub.add_parser("page", parents=[global_parent], help="Manage pages")
    sp_page_sub = sp_page.add_subparsers(dest="page_action")
    sp_page_use = sp_page_sub.add_parser("use", parents=[global_parent], help="Set the active page")
    sp_page_use.add_argument("page_id", nargs="?", help="Page ID or exact title; omit for interactive selection")
    sp_page_use.add_argument("--space-id", help="Space ID (overrides active space)")

    # ── Canvas ─────────────────────────────────────────────────────
    sp_canvas = sub.add_parser("canvas", parents=[global_parent], help="Inspect the active canvas viewport",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""\
examples:
  muni canvas position                         Show where the user is looking
  muni canvas position --json                  Emit current canvas center and visible rect
  muni canvas placement --type chart           Preview where a new chart would land""")
    sp_canvas_sub = sp_canvas.add_subparsers(dest="canvas_action")
    sp_canvas_position = sp_canvas_sub.add_parser(
        "position",
        parents=[global_parent],
        help="Show the current canvas position the user is looking at",
    )
    sp_canvas_position.add_argument("--page-id", help="Page ID (overrides active page)")
    sp_canvas_position.add_argument("--space-id", help=SPACE_PAGE_HELP)
    sp_canvas_placement = sp_canvas_sub.add_parser(
        "placement",
        parents=[global_parent],
        help="Preview where the next unpositioned node would be placed",
    )
    sp_canvas_placement.add_argument("--type", default="table", help="Node type to size for placement (default: table)")
    sp_canvas_placement.add_argument("--width", type=float, help="Override node width")
    sp_canvas_placement.add_argument("--height", type=float, help="Override node height")
    sp_canvas_placement.add_argument("--page-id", help="Page ID (overrides active page)")
    sp_canvas_placement.add_argument("--space-id", help=SPACE_PAGE_HELP)

    # ── Nodes ────────────────────────────────────────────────────
    sp_nodes = sub.add_parser("nodes", parents=[global_parent], help="List nodes on the active page",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""\
examples:
  muni nodes                            List nodes on active page
  muni nodes --type table              List only table nodes
  muni nodes --type python -n 50          List up to 50 python nodes
  muni nodes search "PXDesign"          Search nodes by title""")
    sp_nodes.add_argument("--page-id", help="Page ID (overrides active page)")
    sp_nodes.add_argument("--space-id", help=SPACE_PAGE_HELP)
    sp_nodes.add_argument("--type", help="Filter by node type (metric, code, json, structure, chem, chart, text, image, job, plan, group)")
    sp_nodes.add_argument("--limit", "-n", type=int, default=20, help="Max results (default: 20)")
    sp_nodes_sub = sp_nodes.add_subparsers(dest="nodes_action")
    sp_nodes_search = sp_nodes_sub.add_parser("search", parents=[global_parent], help="Search nodes by title")
    sp_nodes_search.add_argument("query", help="Search keyword")
    sp_nodes_search.add_argument("--page-id", help="Page ID (overrides active page)")
    sp_nodes_search.add_argument("--space-id", help=SPACE_PAGE_HELP)
    sp_nodes_search.add_argument("--type", help="Filter by node type")
    sp_nodes_search.add_argument("--limit", "-n", type=int, default=20, help="Max results (default: 20)")

    # ── Connections ────────────────────────────────────────────────
    sp_connections = sub.add_parser("connections", parents=[global_parent], help="List connections on the active page")
    sp_connections.add_argument("--page-id", help="Page ID (overrides active page)")
    sp_connections.add_argument("--space-id", help=SPACE_PAGE_HELP)

    sp_connection = sub.add_parser("connection", parents=[global_parent], help="Create, edit, or remove a connection")
    sp_connection_sub = sp_connection.add_subparsers(dest="connection_action")

    sp_connection_create = sp_connection_sub.add_parser("create", parents=[global_parent], help="Connect two nodes")
    sp_connection_create.add_argument("source_node_id", help="Source node ID")
    sp_connection_create.add_argument("target_node_id", help="Target node ID")
    sp_connection_create.add_argument("--source-port", default="primary", help="Source output port (default: primary)")
    sp_connection_create.add_argument("--target-port", default="rows", help="Target input port (default: rows)")
    sp_connection_create.add_argument("--kind", default="data", choices=["data", "signal", "provenance"], help="Connection kind (default: data)")
    sp_connection_create.add_argument("--page-id", help="Page ID (overrides active page)")
    sp_connection_create.add_argument("--space-id", help=SPACE_PAGE_HELP)
    sp_connection_create.add_argument("--no-run", action="store_true", help="Do not rerun the target node after connecting")
    sp_connection_create.add_argument("--wait", action="store_true", help="Wait for the target rerun to complete")
    sp_connection_create.add_argument("--timeout", type=int, default=60, help="Timeout in seconds when using --wait (default: 60)")

    sp_connection_edit = sp_connection_sub.add_parser("edit", parents=[global_parent], help="Edit a connection in place")
    sp_connection_edit.add_argument("connection_id", help="Connection ID")
    sp_connection_edit.add_argument("--source-node-id", help="New source node ID")
    sp_connection_edit.add_argument("--target-node-id", help="New target node ID")
    sp_connection_edit.add_argument("--source-port", help="New source output port")
    sp_connection_edit.add_argument("--target-port", help="New target input port")
    sp_connection_edit.add_argument("--kind", choices=["data", "signal", "provenance"], help="New connection kind")
    connection_state = sp_connection_edit.add_mutually_exclusive_group()
    connection_state.add_argument("--enabled", dest="is_enabled", action="store_true", default=None, help="Enable the connection")
    connection_state.add_argument("--disabled", dest="is_enabled", action="store_false", help="Disable the connection")
    sp_connection_edit.add_argument("--no-run", action="store_true", help="Do not rerun the target node after editing")
    sp_connection_edit.add_argument("--wait", action="store_true", help="Wait for the target rerun to complete")
    sp_connection_edit.add_argument("--timeout", type=int, default=60, help="Timeout in seconds when using --wait (default: 60)")

    sp_connection_remove = sp_connection_sub.add_parser("remove", parents=[global_parent], help="Remove a connection")
    sp_connection_remove.add_argument("connection_id", help="Connection ID")
    sp_connection_remove.add_argument("--page-id", help="Page ID (overrides active page; used to find the target node for rerun)")
    sp_connection_remove.add_argument("--space-id", help=SPACE_PAGE_HELP)
    sp_connection_remove.add_argument("--no-run", action="store_true", help="Do not rerun the former target node after removing")
    sp_connection_remove.add_argument("--wait", action="store_true", help="Wait for the target rerun to complete")
    sp_connection_remove.add_argument("--timeout", type=int, default=60, help="Timeout in seconds when using --wait (default: 60)")

    sp_node = sub.add_parser("node", parents=[global_parent], help="Create, read, edit, remove, or run a node",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""\
examples:
  muni node create "Results" --type table          Create a table node
  muni node create "TREM2 rank 1" --type structure --file ./rank_1.cif
                                                    Create a single structure node
  muni node create "TREM2 gallery" --type structure --script ./pxdesign-gallery.ts
                                                    Create a metric-row-driven gallery
  muni node examples structure                       Show structure scripts and commands
  muni node create "Aspirin" --type compound --file ./aspirin.smi
                                                    Create a chemical structure node
  muni node create "Run metadata" --type json --file ./payload.json
                                                    Create a JSON payload node
  muni node create "Notes" --type instruction --file ./notes.md
                                                    Create a text node
  muni node create "Assay image" --type image --file ./assay.svg
                                                    Create an image node
  muni node create "Analysis" --type python           Create a python node
  muni node create "Score chart" --type chart       Create a chart node
  muni node create "pKa job" --type job --script job.ts
                                                    Create a job declaration node
  muni node read NODE_ID                            Read full node state
  muni node edit NODE_ID --script script.ts         Update node script from file
  muni node edit NODE_ID --title "New Title"        Rename a node
  muni node submit NODE_ID --wait                   Execute and wait for results
  muni node connect TABLE_NODE_ID STRUCTURE_NODE_ID --source-port primary --target-port rows --wait
                                                    Connect metric rows to a gallery script
  muni node move NODE_ID 100 200                    Reposition on canvas
  muni node table-summary NODE_ID                  See columns and row count
  muni node table-query NODE_ID --columns rank,sequence --sort-by rank
                                                    Query metric data""")
    sp_node_sub = sp_node.add_subparsers(dest="node_action")

    sp_node_create = sp_node_sub.add_parser("create", parents=[global_parent], help="Create a new node",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""\
examples:
  muni node create "PXDesign summary" --type table
  muni node create "TREM2 rank 1" --type structure --file ./rank_1.cif
  muni node create "TREM2 structure gallery" --type structure --script ./pxdesign-gallery.ts
  muni node examples structure
  muni node create "Smoke image SVG" --type image --file ./diagram.svg
  muni node create "Smoke python dataframe" --type python --python ./analysis.py
  muni node create "Smoke chart bars" --type chart --script ./chart.ts
  muni node create "Smoke instruction note" --type instruction --file ./notes.md
  muni node create "Smoke JSON payload" --type json --file ./payload.json
  muni node create "Smoke compound aspirin" --type compound --file ./aspirin.smi
  muni node create "Rowan pKa Test - Aspirin" --type job --script ./job.ts
  muni node create "Derived table" --type table --from TABLE_NODE_ID
  muni node create "Derived chart" --type chart --from TABLE_NODE_ID --target-port rows
  muni node create "PXDesign summary" --type table --script ./table.ts --wait --expect-output primary:dataframe --expect-min-rows 1 --expect-min-columns 2
  muni node check --type table --script ./table.ts --json

recommended grouped workflow:
  # Create a group first; it auto-resizes around nodes created with --group-id.
  GROUP_ID=$(muni node create "PXDesign analysis" --type group --json | jq -r .nodeId)
  TABLE_ID=$(muni node create "PXDesign summary" --type table --file ./summary.csv --group-id "$GROUP_ID" --json | jq -r .nodeId)
  muni node create "PXDesign quality chart" --type chart --script ./chart.ts --from "$TABLE_ID" --target-port rows --group-id "$GROUP_ID" --wait
  muni node create "PXDesign structure gallery" --type structure --script ./pxdesign-gallery.ts --from "$TABLE_ID" --target-port rows --group-id "$GROUP_ID" --wait

connection example:
  muni node connect TABLE_NODE_ID STRUCTURE_NODE_ID --source-port primary --target-port rows --wait
  # The target script must read ctx.in.data('rows'); see README for pxdesign-gallery.ts.
  # Example from the active test-1 canvas:
  #   PXDesign TREM2 5UD8 summary (metric) -> PXDesign TREM2 structures gallery (structure)
""")
    sp_node_create.add_argument("title", help="Node title")
    sp_node_create.add_argument("--type", default="table", help="Node type: table, python, json, structure, compound, chart, instruction, image, job, plan, group (default: table)")
    sp_node_create.add_argument("--script", help="Path to a script file for the node, or - for stdin")
    sp_node_create.add_argument("--script-text", help="Inline TypeScript source for the node")
    sp_node_create.add_argument("--python", dest="python_code", help="Code nodes: Python code for main.py (inline text, file path, or - for stdin)")
    sp_node_create.add_argument("--file", dest="import_file", help="Path to a content file to import (auto-detects type from extension: .pdb/.cif/.sdf/.mol/.csv/.json/.txt/.png etc.)")
    sp_node_create.add_argument("--x", type=float, help="X position on the canvas")
    sp_node_create.add_argument("--y", type=float, help="Y position on the canvas")
    sp_node_create.add_argument("--group-id", help="Create the node inside an existing auto-resizing group node; recommended for multi-node analyses")
    sp_node_create.add_argument("--from", dest="from_node_ids", action="append", default=[], help="Source node ID to connect at create time; repeat for multiple sources")
    sp_node_create.add_argument("--source-port", default="primary", help="Source output port for --from connections (default: primary)")
    sp_node_create.add_argument("--target-port", default="rows", help="Target input port for --from connections (default: rows)")
    sp_node_create.add_argument("--page-id", help="Page ID (overrides active page)")
    sp_node_create.add_argument("--space-id", help=SPACE_PAGE_HELP)
    sp_node_create.add_argument("--wait", action="store_true", help="Wait for create-time execution to complete and include runtime status")
    sp_node_create.add_argument("--timeout", type=int, default=60, help="Timeout in seconds when using --wait or expectations (default: 60)")
    sp_node_create.add_argument("--expect-output", dest="expect_outputs", action="append", default=[], help="Assert an output exists with a data type, e.g. primary:dataframe. Repeatable")
    sp_node_create.add_argument("--expect-min-rows", type=int, help="Assert the primary dataframe has at least this many rows")
    sp_node_create.add_argument("--expect-min-columns", type=int, help="Assert the primary dataframe has at least this many columns")

    sp_node_check = sp_node_sub.add_parser("check", parents=[global_parent], help="Preflight a node script without creating a node",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""\
examples:
  muni node check --type table --script ./table.ts
  muni node check --type chart --script - --json

notes:
  This is currently a local preflight: strict script reading plus basic
  node('kind', ...) checks. Server-side compile/SSR smoke checks require a
  future no-mutation SDK endpoint.
""")
    sp_node_check.add_argument("--type", default="table", help="Expected node type (default: table)")
    sp_node_check.add_argument("--script", help="Path to a script file for the node, or - for stdin")
    sp_node_check.add_argument("--script-text", help="Inline TypeScript source for the node")

    sp_node_examples = sp_node_sub.add_parser("examples", parents=[global_parent], help="Show copyable examples for a node kind",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""\
examples:
  muni node examples structure
  muni node examples structure --scenario pxdesign_table_gallery
  muni node examples structure --json
""")
    sp_node_examples.add_argument("kind", nargs="?", default="structure", choices=sorted(NODE_EXAMPLES), help="Node kind to show examples for")
    sp_node_examples.add_argument("--scenario", default="all", help="Example scenario name (default: all)")

    sp_node_read = sp_node_sub.add_parser("read", parents=[global_parent], help="Read a node's script, data, sources, and view state")
    sp_node_read.add_argument("node_id", help="Node ID")

    sp_node_edit = sp_node_sub.add_parser("edit", parents=[global_parent], help="Edit a node's title, script, Python code, or content (via --file)")
    sp_node_edit.add_argument("node_id", help="Node ID")
    sp_node_edit.add_argument("--title", help="New title")
    sp_node_edit.add_argument("--script", help="Path to a script file, or - for stdin")
    sp_node_edit.add_argument("--script-text", help="Inline TypeScript source for the node")
    sp_node_edit.add_argument("--python", dest="python_code", help="Code nodes: Python code for main.py (inline text, file path, or - for stdin)")
    sp_node_edit.add_argument("--file", dest="import_file", help="Path to a content file — auto-generates the script-first wrapper (.pdb/.cif → structure ref, .sdf/.mol/.smi → chem embed, .csv → metric embed, .json → json embed, .txt/.md → text embed, .png/.jpg → image ref)")
    sp_node_edit.add_argument("--run", action="store_true", help="Run the node after editing and wait for results")
    sp_node_edit.add_argument("--timeout", type=int, default=60, help="Timeout in seconds when using --run (default: 60)")

    sp_node_content = sp_node_sub.add_parser("content", parents=[global_parent], help="Read a node's output content from storage")
    sp_node_content.add_argument("node_id", help="Node ID")
    sp_node_content.add_argument("--output-key", default="primary", help="Output key (default: primary)")

    sp_node_remove = sp_node_sub.add_parser("remove", parents=[global_parent], help="Remove a node (recoverable)")
    sp_node_remove.add_argument("node_id", help="Node ID")

    sp_node_submit = sp_node_sub.add_parser("submit", parents=[global_parent], help="Submit a node for execution")
    sp_node_submit.add_argument("node_id", help="Node ID")
    sp_node_submit.add_argument("--wait", action="store_true", help="Wait for execution to complete and return results")
    sp_node_submit.add_argument("--timeout", type=int, default=60, help="Timeout in seconds when using --wait (default: 60)")

    sp_node_move = sp_node_sub.add_parser("move", parents=[global_parent], help="Move a node to a new position")
    sp_node_move.add_argument("node_id", help="Node ID")
    sp_node_move.add_argument("x", type=float, help="X position")
    sp_node_move.add_argument("y", type=float, help="Y position")

    sp_node_select = sp_node_sub.add_parser("select", parents=[global_parent], help="Select node(s) on the canvas")
    sp_node_select.add_argument("node_ids", nargs="+", help="Node ID(s) to select")
    sp_node_select.add_argument("--page-id", help="Page ID (overrides active page)")
    sp_node_select.add_argument("--space-id", help=SPACE_PAGE_HELP)

    sp_node_focus = sp_node_sub.add_parser("focus", parents=[global_parent], help="Focus the canvas viewport on a node")
    sp_node_focus.add_argument("node_id", help="Node ID to focus on")
    sp_node_focus.add_argument("--page-id", help="Page ID (overrides active page)")
    sp_node_focus.add_argument("--space-id", help=SPACE_PAGE_HELP)

    sp_node_connect = sp_node_sub.add_parser("connect", parents=[global_parent], help="Connect two nodes (create a data edge)",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""\
examples:
  muni node connect TABLE_NODE_ID STRUCTURE_NODE_ID --source-port primary --target-port rows --wait
  muni node connect JOB_NODE_ID TABLE_NODE_ID --source-port primary --target-port rows --wait

active canvas example:
  PXDesign TREM2 5UD8 summary (metric) -> PXDesign TREM2 structures gallery (structure)
""")
    sp_node_connect.add_argument("source_node_id", help="Source node ID")
    sp_node_connect.add_argument("target_node_id", help="Target node ID")
    sp_node_connect.add_argument("--source-port", default="primary", help="Source output port (default: primary)")
    sp_node_connect.add_argument("--target-port", default="rows", help="Target input port (default: rows)")
    sp_node_connect.add_argument("--kind", default="data", choices=["data", "signal", "provenance"], help="Connection kind (default: data)")
    sp_node_connect.add_argument("--page-id", help="Page ID (overrides active page)")
    sp_node_connect.add_argument("--space-id", help=SPACE_PAGE_HELP)
    sp_node_connect.add_argument("--no-run", action="store_true", help="Do not rerun the target node after connecting")
    sp_node_connect.add_argument("--wait", action="store_true", help="Wait for the target rerun to complete")
    sp_node_connect.add_argument("--timeout", type=int, default=60, help="Timeout in seconds when using --wait (default: 60)")

    sp_node_group = sp_node_sub.add_parser("group", parents=[global_parent], help="Group existing loose nodes under a new parent group node",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""\
notes:
  Use this command when the nodes already exist on the canvas.
  For new multi-node analyses, prefer creating the group first and then
  creating child nodes with --group-id:
    GROUP_ID=$(muni node create "Analysis" --type group --json | jq -r .nodeId)
    muni node create "Results" --type table --group-id "$GROUP_ID"
""")
    sp_node_group.add_argument("node_ids", nargs="+", help="Node IDs to group together (two or more)")
    sp_node_group.add_argument("--label", required=True, help="Label for the new group node")
    sp_node_group.add_argument("--page-id", help="Page ID (overrides active page)")
    sp_node_group.add_argument("--space-id", help=SPACE_PAGE_HELP)

    sp_node_layout_group = sp_node_sub.add_parser("layout-group", parents=[global_parent], help="Lay out nodes inside a group")
    sp_node_layout_group.add_argument("group_id", help="Group node ID")
    sp_node_layout_group.add_argument("--algorithm", choices=["elk", "simple"], default="elk", help="Layout algorithm (default: elk)")
    sp_node_layout_group.add_argument("--direction", choices=["right", "down"], default="right", help="Layout direction (default: right)")

    sp_node_ungroup = sp_node_sub.add_parser("ungroup", parents=[global_parent], help="Ungroup a group node (detaches children and removes the group)")
    sp_node_ungroup.add_argument("group_id", help="Group node ID")

    sp_node_table_summary = sp_node_sub.add_parser("table-summary", parents=[global_parent], help="Get column names, types, and row count for a table node")
    sp_node_table_summary.add_argument("node_id", help="Metric node ID")

    sp_node_table_query = sp_node_sub.add_parser("table-query", parents=[global_parent], help="Sort, filter, and paginate a table node's data")
    sp_node_table_query.add_argument("node_id", help="Metric node ID")
    sp_node_table_query.add_argument("--columns", nargs="+", help="Columns to include")
    sp_node_table_query.add_argument("--sort-by", help="Column to sort by")
    sp_node_table_query.add_argument("--sort-order", choices=["asc", "desc"], default="asc", help="Sort order (default: asc)")
    sp_node_table_query.add_argument("--filter", action="append", dest="filters", help="Filter: COLUMN:OP:VALUE (e.g. af2_iptm:gt:0.3)")
    sp_node_table_query.add_argument("--limit", "-n", type=int, default=20, help="Max rows (default: 20)")
    sp_node_table_query.add_argument("--offset", type=int, default=0, help="Skip rows (default: 0)")

    sp_node_table_select = sp_node_sub.add_parser("table-select", parents=[global_parent], help="Check/uncheck rows on a table node")
    sp_node_table_select.add_argument("node_id", help="Metric node ID")
    sp_node_table_select.add_argument("action", choices=["get", "select", "deselect", "clear"], help="get: show selection, select/deselect: modify by rows or filter, clear: uncheck all")
    sp_node_table_select.add_argument("--rows", nargs="+", type=int, help="Row numbers to select/deselect (1-based, as shown in the UI)")
    sp_node_table_select.add_argument("--filter", action="append", dest="filters", help="Select/deselect rows matching filter: COLUMN:OP:VALUE")

    # ── plan ──
    sp_plan = sub.add_parser("plan", parents=[global_parent], help="Create or manage a pipeline",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""\
examples:
  muni plan create plan.json                        Create a pipeline from a JSON definition
  muni plan create plan.json --page-id PAGE_ID      Create on a specific page
  muni plan validate PLAN_NODE_ID                   Validate a plan node
  muni plan run PLAN_NODE_ID                        Run a plan's orchestrator""")
    sp_plan_sub = sp_plan.add_subparsers(dest="plan_action")

    sp_plan_create = sp_plan_sub.add_parser("create", parents=[global_parent], help="Create a pipeline from a JSON definition")
    sp_plan_create.add_argument("definition", help="Path to a JSON plan definition file, or - for stdin")
    sp_plan_create.add_argument("--page-id", help="Page ID (overrides active page)")
    sp_plan_create.add_argument("--space-id", help=SPACE_PAGE_HELP)

    sp_plan_validate = sp_plan_sub.add_parser("validate", parents=[global_parent], help="Validate a plan node")
    sp_plan_validate.add_argument("node_id", help="Plan node ID")

    sp_plan_run = sp_plan_sub.add_parser("run", parents=[global_parent], help="Run a plan's orchestrator")
    sp_plan_run.add_argument("node_id", help="Plan node ID")
    sp_plan_run.add_argument("--wait", action="store_true", help="Wait for completion")
    sp_plan_run.add_argument("--timeout", type=int, default=300, help="Timeout in seconds (default: 300)")

    sp_tools = sub.add_parser("tools", parents=[global_parent], help="List available tools",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""\
examples:
  muni tools                            List all available tools
  muni tools -q complexa                Search tools by name
  muni tools -c protein-design          Filter by category
  muni tools --json                     Machine-readable output""")
    sp_tools.add_argument("--query", "-q", help="Search keyword")
    sp_tools.add_argument("--category", "-c", help="Filter by category")

    sp_tool = sub.add_parser("tool", parents=[global_parent], help="Show tool details",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""\
examples:
  muni tool rfd3               Show tool description and metadata
  muni tool rfd3 --inputs      Show input parameter schema
  muni tool rfd3 --outputs     Show output files and canvas views
  muni tool rfd3 --examples    Show usage examples""")
    sp_tool.add_argument("name", help="Tool name")
    sp_tool.add_argument("--inputs", action="store_true", help="Show input parameters")
    sp_tool.add_argument("--outputs", action="store_true", help="Show output files and canvas views")
    sp_tool.add_argument("--examples", action="store_true", help="Show usage examples")

    sp_run = sub.add_parser("run", parents=[global_parent], help="Execute a tool",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""\
examples:
  muni run rfd3 pdb_id=1UBQ num_designs=5
                                        Submit a job (returns immediately)
  muni run rfd3 pdb_id=1UBQ --follow
                                        Submit and wait for completion
  muni run rfd3 --params-file params.json --follow
                                        Submit from JSON file and wait
  muni run ipsae --batch jobs.jsonl --follow
                                        Batch submit and wait for all
  muni run crem smiles=CCO --no-space
                                        Submit API-only, ignoring the active space
  muni run rfd3 pdb_id=1UBQ --dry-run
                                        Validate without submitting""")
    sp_run.add_argument("tool", help="Tool name")
    sp_run.add_argument("params", nargs="*", help="KEY=VALUE parameters")
    sp_run.add_argument("--params-file", help="Path to a JSON file with tool parameters")
    sp_run.add_argument("--batch", help="Path to a JSONL batch file (use '-' to read from stdin)")
    sp_run.add_argument("--submit-concurrency", type=int, default=10, help="Concurrent submissions for batch mode (default: 10)")
    sp_run.add_argument("--space-id", help=SPACE_PAGE_HELP)
    sp_run.add_argument("--page-id", help="Page ID (overrides the page selected from --space-id)")
    sp_run.add_argument("--no-space", action="store_true", help="Submit without active space/page metadata")
    sp_run.add_argument("--follow", "-f", action="store_true", help="Wait for job completion (uses realtime, falls back to polling)")
    sp_run.add_argument("--timeout", "-t", type=int, default=1800, help="Timeout in seconds (default: 1800)")
    sp_run.add_argument("--title", help="Job title")
    sp_run.add_argument("--dry-run", action="store_true", help="Validate and print the resolved request without submitting")
    sp_run.add_argument("--no-validate", dest="validate", action="store_false", help="Skip client-side schema validation before submitting")
    sp_run.add_argument("--log-lines", type=int, default=120, help="Number of log lines to show after a failed --follow run")
    sp_run.add_argument("--print-job-id", action="store_true", help="Print only the submitted job ID for shell capture")
    sp_run.set_defaults(validate=True)

    sp_wait = sub.add_parser("wait", parents=[global_parent], help="Wait for one or more jobs to finish",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""\
examples:
  muni wait job_<uuid>                       Wait for a single job (job_id preferred)
  muni wait job_<uuid-a> job_<uuid-b>        Wait for multiple jobs
  muni wait job_<uuid> --timeout 3600        Wait up to 1 hour
  muni wait rw-<workflow-uuid>               call_id form also accepted (Rowan/Anyscale)
  muni wait job_<uuid> --json                Machine-readable output""")
    sp_wait.add_argument("call_ids", nargs="+", help="One or more job IDs (job_<uuid> preferred; provider call_ids also accepted)")
    sp_wait.add_argument("--timeout", type=int, default=7200, help="Timeout in seconds (default: 7200)")

    sp_jobs = sub.add_parser("jobs", parents=[global_parent], help="List your jobs",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""\
examples:
  muni jobs                             List recent jobs
  muni jobs --status completed -n 10    Last 10 completed jobs
  muni jobs --status running            Show running jobs
  muni jobs --tool onepot-rbfe-demo     Jobs for a specific tool
  muni jobs --space-id SPACE_ID         Jobs in a specific space""")
    sp_jobs.add_argument("--space-id", help="Filter by space")
    sp_jobs.add_argument("--status", "-s", help="Filter by status")
    sp_jobs.add_argument("--tool", "-t", dest="tool_name", help="Filter by tool name")
    sp_jobs.add_argument("--limit", "-n", type=int, default=20, help="Max results")

    sp_job = sub.add_parser("job", parents=[global_parent], help="Job management: summary, query, scaffold helpers",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""\
examples:
  muni job summary JOB_ID                       Structured output summary
  muni job query JOB_ID                         Query all metric data
  muni job nodes JOB_ID                         Preview canvas nodes for a completed job
  muni job query JOB_ID --columns rank,sequence,af2_iptm
                                                 Select specific columns
  muni job query JOB_ID --sort-by rank --limit 10
                                                 Sort and paginate
  muni job scaffold-table JOB_ID --kind pxdesign-summary --output ./table.ts
                                                 Generate a table node script from job outputs""")
    job_sub = sp_job.add_subparsers(dest="job_action")

    sp_job_summary = job_sub.add_parser("summary", parents=[global_parent], help="Get structured output summary: columns, row count, file count")
    sp_job_summary.add_argument("call_id", help="Job ID (job_<uuid>) or provider call_id")

    sp_job_query = job_sub.add_parser("query", parents=[global_parent], help="Query metric/tabular data from job results",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""\
examples:
  muni job query JOB_ID                                 All columns, default limit
  muni job query JOB_ID --columns rank,sequence,iptm    Select columns
  muni job query JOB_ID --sort-by af2_iptm --sort-dir desc --limit 5
                                                         Sort descending, top 5
  muni job query JOB_ID --offset 20 --limit 20          Page 2""")
    sp_job_query.add_argument("call_id", help="Job ID (job_<uuid>) or provider call_id")
    sp_job_query.add_argument("--columns", "-c", help="Comma-separated column names")
    sp_job_query.add_argument("--sort-by", help="Column to sort by")
    sp_job_query.add_argument("--sort-dir", choices=["asc", "desc"], default=None, help="Sort direction")
    sp_job_query.add_argument("--limit", "-n", type=int, default=20, help="Max rows (default: 20, max: 50)")
    sp_job_query.add_argument("--offset", type=int, default=0, help="Skip this many rows (default: 0)")

    sp_job_nodes = job_sub.add_parser("nodes", parents=[global_parent], help="Preview canvas nodes for a completed job",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""\
examples:
  muni job nodes JOB_ID
  muni job nodes JOB_ID --json
  muni job nodes JOB_ID --apply
  muni job nodes JOB_ID --apply --page-id PAGE_ID

notes:
  Returns the concrete output-backed canvas nodes for a finished job.
  The default text output summarizes the nodes and example paths. Add --json
  to include the full prompt, materialization_examples example context, and
  inline code examples an agent can use to generate renderer scripts.
  Use --apply to create/update those nodes on the canvas through the app
  materializer.""")
    sp_job_nodes.add_argument("call_id", help="Job ID (job_<uuid>) or provider call_id")
    sp_job_nodes.add_argument("--apply", action="store_true", help="Create/update the planned nodes on the canvas")
    sp_job_nodes.add_argument("--space-id", help=SPACE_PAGE_HELP)
    sp_job_nodes.add_argument("--page-id", help="Target page for --apply")
    sp_job_nodes.add_argument("--no-space", action="store_true", help="Do not use an active space/page; invalid with --apply")
    sp_job_nodes.add_argument("--launcher-node-id", help="Optional launcher/anchor node for --apply")
    sp_job_nodes.add_argument("--no-refresh-contract", action="store_true", help="Use stored binding contract instead of refreshing from Tools API")
    sp_job_nodes.add_argument("--no-prune-stale", action="store_true", help="Do not remove stale materialized nodes for retired views")

    sp_job_scaffold_table = job_sub.add_parser("scaffold-table", parents=[global_parent], help="Generate a table node script from job outputs",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""\
examples:
  muni job scaffold-table JOB_ID --kind pxdesign-summary --output ./table.ts
  muni job scaffold-table JOB_ID --kind pxdesign-summary > metric.ts

notes:
  pxdesign-summary looks for design_outputs/config/summary.csv, downloads it,
  and emits the canonical table node script with those rows embedded.
""")
    sp_job_scaffold_table.add_argument("call_id", help="Job ID (job_<uuid>) or provider call_id")
    sp_job_scaffold_table.add_argument("--kind", default="pxdesign-summary", choices=["pxdesign-summary"], help="Metric scaffold kind (default: pxdesign-summary)")
    sp_job_scaffold_table.add_argument("--output", "-o", help="Write script to this path instead of stdout")

    sp_cancel = sub.add_parser("cancel", parents=[global_parent], help="Cancel a running job",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""\
examples:
  muni cancel job_<uuid>                   Cancel a running job (exits 1 if already terminal)
  muni cancel rw-<workflow-uuid>           call_id form also accepted
  muni cancel job_<uuid> --json            Machine-readable output""")
    sp_cancel.add_argument("call_id", help="Job ID (job_<uuid>) or provider call_id")

    sp_status = sub.add_parser("status", parents=[global_parent], help="Check job status")
    sp_status.add_argument("call_id", help="Job ID (job_<uuid>) or provider call_id")

    sp_results = sub.add_parser("results", parents=[global_parent], help="Get job results",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""\
examples:
  muni results JOB_ID                  Show full results
  muni results JOB_ID --fields rank,sequence,iptm
                                        Extract specific columns
  muni results JOB_ID --sequences      Extract designed sequences
  muni results JOB_ID --json           Machine-readable output""")
    sp_results.add_argument("call_id", help="Job ID (job_<uuid>) or provider call_id")
    sp_results.add_argument("--fields", help="Comma-separated field paths to extract from structured results")
    sp_results.add_argument("--sequences", action="store_true", help="Extract designed sequences from common protein-design result shapes")

    sp_files = sub.add_parser("files", parents=[global_parent], help="List job output files")
    sp_files.add_argument("call_id", help="Job ID (job_<uuid>) or provider call_id")
    sp_files.add_argument("--path", "-p", help="Only show files under this directory")

    sp_logs = sub.add_parser("logs", parents=[global_parent], help="Fetch provider logs for a job")
    sp_logs.add_argument("call_id", help="Job ID (job_<uuid>) or provider call_id")
    sp_logs.add_argument("--follow", action="store_true", help="Poll logs until the job reaches a terminal state")
    sp_logs.add_argument("--interval", type=int, default=5, help="Polling interval in seconds for --follow")
    sp_logs.add_argument("--max-lines", type=int, default=200, help="Tail this many log lines")

    sp_dl = sub.add_parser("download", parents=[global_parent], help="Download a single file")
    sp_dl.add_argument("call_id", help="Job ID (job_<uuid>) or provider call_id")
    sp_dl.add_argument("path", help="File path within job")
    sp_dl.add_argument("--output", "-o", help="Output path (default: file name)")
    sp_dl.add_argument("--stdout", action="store_true", help="Write file content to stdout (alias: -o -)")

    sp_dla = sub.add_parser("download-all", parents=[global_parent], help="Download all job files",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""\
examples:
  muni download-all JOB_ID -o ./results/
                                        Download everything to a directory
  muni download-all JOB_ID -o ./pdbs/ --glob '*.pdb'
                                        Download only PDB files
  muni download-all JOB_ID -o ./out/ --path 'designs/'
                                        Download only files under designs/""")
    sp_dla.add_argument("call_id", help="Job ID (job_<uuid>) or provider call_id")
    sp_dla.add_argument("--output-dir", "-o", help="Output directory")
    sp_dla.add_argument("--path", "-p", help="Only download files under this directory (e.g. 'designs/')")
    sp_dla.add_argument("--glob", "-g", help="Only download files matching this pattern (e.g. '*.pdb')")

    return parser


def cmd_plan(args: argparse.Namespace) -> None:
    """Handle plan subcommands."""
    import json as _json

    client = MuniClient()
    action = getattr(args, "plan_action", None)

    if action == "create":
        definition_path = args.definition
        if definition_path == "-":
            plan_data = _json.load(sys.stdin)
        else:
            with open(definition_path) as f:
                plan_data = _json.load(f)

        page_id = _resolve_page_id_arg(args)
        result = client.plans.create(
            plan_data,
            page_id=page_id,
        )
        if args.json:
            _output(result, True)
        else:
            plan_node_id = result.get("planNodeId", "?")
            steps = result.get("steps", [])
            summary = result.get("summary", "")
            print(f"Plan: {plan_node_id}")
            print(f"Steps: {len(steps)}")
            for s in steps:
                status_icon = "✓" if s.get("status") == "completed" else "✗" if s.get("error") else "○"
                print(f"  {status_icon} {s.get('stepId', '?')} ({s.get('kind', '?')}) → {s.get('nodeId', '?')}")
                if s.get("error"):
                    print(f"    Error: {s['error']}")
            print(summary)
        return

    if action == "validate":
        result = client.plans.validate(args.node_id)
        _output(
            result if args.json
            else ("Plan is valid" if result.get("valid") else f"Plan has issues:\n" + "\n".join(result.get("issues", []))),
            args.json,
        )
        return

    if action == "run":
        client.plans.run(args.node_id)
        if not args.json:
            print(f"Plan {args.node_id} orchestrator triggered")
        return

    _fail("Use a subcommand: create, validate, run.", as_json=args.json)


_HANDLERS = {
    "config": cmd_config,
    "login": cmd_login,
    "logout": cmd_logout,
    "whoami": cmd_whoami,
    "balance": cmd_balance,
    "update": cmd_update,
    "spaces": cmd_spaces,
    "space": cmd_space,
    "pages": cmd_pages,
    "page": cmd_page,
    "canvas": cmd_canvas,
    "nodes": cmd_nodes,
    "connections": cmd_connections,
    "connection": cmd_connection,
    "node": cmd_node,
    "plan": cmd_plan,
    "tools": cmd_tools,
    "tool": cmd_tool,
    "run": cmd_run,
    "wait": cmd_wait,
    "jobs": cmd_jobs,
    "job": cmd_job,
    "status": cmd_status,
    "cancel": cmd_cancel,
    "results": cmd_results,
    "files": cmd_files,
    "logs": cmd_logs,
    "download": cmd_download,
    "download-all": cmd_download_all,
}


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()

    if getattr(args, "profile", None):
        os.environ["MUNI_PROFILE"] = args.profile
    if getattr(args, "api_url", None):
        os.environ["MUNI_API_URL"] = args.api_url
    if getattr(args, "app_url", None):
        os.environ["MUNI_APP_URL"] = args.app_url
    if getattr(args, "supabase_url", None):
        os.environ["MUNI_SUPABASE_URL"] = args.supabase_url
    if getattr(args, "supabase_publishable_key", None):
        os.environ["MUNI_SUPABASE_PUBLISHABLE_KEY"] = args.supabase_publishable_key

    if not args.command:
        parser.print_help()
        raise SystemExit(0)

    handler = _HANDLERS.get(args.command)
    if not handler:
        parser.print_help()
        raise SystemExit(1)

    try:
        handler(args)
    except MuniError as e:
        _emit_error(str(e), as_json=getattr(args, "json", False))
        raise SystemExit(1)
    except KeyboardInterrupt:
        print(file=sys.stderr)
        raise SystemExit(130)
