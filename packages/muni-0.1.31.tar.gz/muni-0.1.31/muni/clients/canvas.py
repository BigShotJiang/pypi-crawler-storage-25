"""CanvasClient — viewport and smart-placement helpers."""

from __future__ import annotations
from typing import Any

from ._base import SDKClientBase


class CanvasClient(SDKClientBase):
    _namespace = "canvas"

    def current_position(self, page_id: str) -> dict:
        """Get the current canvas position the user is looking at."""
        return self._call("currentPosition", pageId=page_id)

    def preview_placement(
        self,
        page_id: str,
        *,
        type: str = "table",
        width: float | None = None,
        height: float | None = None,
        exclude_node_ids: list[str] | None = None,
    ) -> dict:
        """Preview where an unpositioned node would be placed."""
        opts: dict[str, Any] = {"type": type}
        if width is not None:
            opts["width"] = width
        if height is not None:
            opts["height"] = height
        if exclude_node_ids:
            opts["excludeNodeIds"] = exclude_node_ids
        return self._call("previewPlacement", pageId=page_id, opts=opts)
