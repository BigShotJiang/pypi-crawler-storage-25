"""ScriptsClient — delegates to /api/sdk for script generation.

Takes validated primitives (SMILES / text / rows / storage refs) and returns
the canonical TypeScript for a given node kind. The server-side `@muni/sdk`
holds the only implementation, so UI drag-drop, CLI imports, and AI chat all
produce byte-identical output.
"""

from __future__ import annotations

from typing import Any, Literal

from ._base import SDKClientBase

ScriptKind = Literal[
    "compound",
    "instruction",
    "json",
    "table",
    "structure",
    "image",
    "starter",
    "job",
]


class ScriptsClient(SDKClientBase):
    _namespace = "scripts"

    # ── Unified dispatcher ───────────────────────────────────────────

    def build(self, kind: ScriptKind, input: dict[str, Any]) -> str:
        """Generate the canonical script for ``kind`` from ``input`` primitives.

        Args:
            kind: One of "compound", "instruction", "json", "table", "structure", "image".
            input: Primitive shape for the kind. See the per-kind helpers for
                the exact fields.

        Returns:
            TypeScript source ready to save into ``muni_nodes.script``.
        """
        result = self._call("build", kind=kind, input=input)
        if not isinstance(result, str):
            raise TypeError(f"scripts.build: expected string, got {type(result).__name__}")
        return result

    # ── Per-kind convenience (stronger typing at call sites) ────────

    def compound(self, *, smiles: str, label: str | None = None) -> str:
        return self._string_call("compound", {"smiles": smiles, "label": label})

    def instruction(self, *, content: str, label: str | None = None) -> str:
        return self._string_call("instruction", {"content": content, "label": label})

    def json(self, *, data: Any, label: str | None = None) -> str:
        return self._string_call("json", {"data": data, "label": label})

    def table(
        self,
        *,
        columns: list[str],
        rows: list[dict[str, Any]],
        label: str | None = None,
    ) -> str:
        return self._string_call(
            "table",
            {"columns": columns, "rows": rows, "label": label},
        )

    def structure(self, *, bucket: str, path: str, filename: str) -> str:
        return self._string_call(
            "structure",
            {"bucket": bucket, "path": path, "filename": filename},
        )

    # `scripts.image` removed in PR E of node-script-preflight.md — image
    # imports now go through `client.nodes.import_image()`, which uploads
    # bytes + writes the script + submits in one server-side call. The
    # equivalent server-side `scripts.image` SDK method still exists for
    # compatibility with the (unused) browser drag-drop pre-PR-E paths.

    def preflight(
        self,
        *,
        source: str,
        kind: str,
        page_id: str | None = None,
        node_id: str | None = None,
    ) -> dict:
        """Run preflight against a script source without creating a node.

        Returns the same `PreflightReport` shape the server pipeline persists
        to `muni_node_runs.preflight_*`. Use this from the CLI / agents to
        preview diagnostics before submission.

        Args:
            source: TypeScript script source.
            kind: Node kind ('table', 'chart', 'job', etc.).
            page_id: Optional. When set with `node_id`, the server builds a
                graph context and runs the GraphRefs analyzer.
            node_id: Optional. Scopes inbound-connection checks.

        Returns:
            Raw dict (response shape not yet in generated models). Keys:
            ``ok, errorCount, warningCount, infoCount, diagnostics, nextStep,
            durationMs, analyzersRun``.

        PR C of docs/plans/node-flow/node-script-preflight.md.
        """
        payload: dict[str, Any] = {"source": source, "kind": kind}
        if page_id:
            payload["pageId"] = page_id
        if node_id:
            payload["nodeId"] = node_id
        return self._call("preflight", input=payload)

    def starter(self, *, kind: str) -> str:
        """Empty-state scaffold for a node kind (table/python/chart/…)."""
        return self._string_call("starter", {"kind": kind})

    def job(self, *, tool: str, params: dict[str, Any] | None = None) -> str:
        """Job-node declaration bound to a specific Tools API tool + params."""
        return self._string_call("job", {"tool": tool, "params": params or {}})

    # ── Internal ─────────────────────────────────────────────────────

    def _string_call(self, method: str, input_payload: dict[str, Any]) -> str:
        # Drop None values so the server picks its defaults (e.g. label="Molecule").
        cleaned = {k: v for k, v in input_payload.items() if v is not None}
        result = self._call(method, input=cleaned)
        if not isinstance(result, str):
            raise TypeError(f"scripts.{method}: expected string, got {type(result).__name__}")
        return result
