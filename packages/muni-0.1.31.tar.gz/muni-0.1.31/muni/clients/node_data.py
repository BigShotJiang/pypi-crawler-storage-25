"""NodeDataClient — delegates to /api/sdk for all operations."""

from __future__ import annotations
from ._base import SDKClientBase


class NodeDataClient(SDKClientBase):
    _namespace = "nodeData"

    def read(self, node_id: str, output_key: str = "primary") -> dict | None:
        """Read the current output data for a node."""
        return self._call("read", nodeId=node_id, outputKey=output_key)

    def import_data(
        self,
        node_id: str,
        *,
        type: str,
        content: str,
        filename: str | None = None,
    ) -> None:
        """Import data into a node via the unified ingress.

        Valid ``type`` values: ``"csv"``, ``"dataframe"``, ``"image"``,
        ``"text"``, ``"structure"``, ``"compound"``, ``"json"``.

        Content is UTF-8 text for text types and base64 for ``image``. The
        server uploads to the ``muni-node-data`` bucket and records a run via
        the run-recorder — same path the browser drag-drop uses.
        """
        self._call(
            "import",
            nodeId=node_id,
            data={"type": type, "content": content, "filename": filename},
        )

    def upload_blob(
        self,
        node_id: str,
        *,
        content: str,
        content_type: str,
        filename: str,
        base64: bool = False,
        output_key: str = "primary",
    ) -> dict:
        """Upload raw bytes to ``muni-node-data`` for this node.

        Returns ``{"bucket": "muni-node-data", "path": "<space>/<node>/.../..."}``.
        Does NOT write a muni_node_data row — the row is written when the
        node's script runs and emits a ``{__ref: {bucket, path}}`` pointer.

        Used by the script-first import path for large content (structure /
        image / long text) that we don't want to embed inline in the script
        column.
        """
        return self._call(
            "uploadBlob",
            nodeId=node_id,
            data={
                "content": content,
                "contentType": content_type,
                "filename": filename,
                "base64": base64,
                "outputKey": output_key,
            },
        )
