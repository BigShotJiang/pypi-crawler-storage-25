"""Base class for SDK sub-clients that delegate to the app server's /api/sdk endpoint."""

from __future__ import annotations
import json
import urllib.error
import urllib.parse
import urllib.request
from typing import Any, TYPE_CHECKING, TypeVar, overload

from pydantic import BaseModel

from ..exceptions import APIError, AuthError, MuniError, NotFoundError

if TYPE_CHECKING:
    from ..client import MuniClient


ModelT = TypeVar("ModelT", bound=BaseModel)


class SDKClientBase:
    """Base class that routes all calls through POST /api/sdk.

    Sub-clients can opt into typed responses by passing `response_model=<Model>`
    — the response JSON is parsed through the Pydantic model (generated from the
    TS Zod schemas, see muni/_generated/). Without it, the raw dict is returned.
    """

    _namespace: str  # Set by subclasses, e.g. "pages", "nodes"

    def __init__(self, client: MuniClient) -> None:
        self._client = client

    @overload
    def _call(self, method: str, *, response_model: type[ModelT], **args: Any) -> ModelT: ...
    @overload
    def _call(self, method: str, **args: Any) -> Any: ...

    def _call(
        self,
        method: str,
        *,
        response_model: type[BaseModel] | None = None,
        **args: Any,
    ) -> Any:
        """Call an SDK method via the app server.

        Args:
            method: Method name without namespace (e.g. "create", "list").
            response_model: Optional Pydantic model to parse the response through.
                When set, returns a model instance; otherwise returns a raw dict.
            **args: Method arguments as keyword args.
        """
        full_method = f"{self._namespace}.{method}"
        token, _ = self._client._auth()
        app_url = self._client.app_url

        body = json.dumps({"method": full_method, "args": args}).encode()
        req = urllib.request.Request(
            f"{app_url}/api/sdk",
            data=body,
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {token}",
                "User-Agent": "MuniCLI/1.0",
            },
            method="POST",
        )

        try:
            with urllib.request.urlopen(req) as resp:
                payload = json.loads(resp.read())
                result = payload.get("result")
        except urllib.error.HTTPError as exc:
            try:
                err_body = json.loads(exc.read())
                error_msg = err_body.get("error", f"HTTP {exc.code}")
            except Exception:
                error_msg = f"HTTP {exc.code}"

            if exc.code == 401:
                raise AuthError(error_msg) from exc
            if exc.code == 404:
                raise NotFoundError(error_msg) from exc
            if exc.code >= 400:
                raise APIError(error_msg, exc.code) from exc
            raise MuniError(error_msg) from exc
        except urllib.error.URLError as exc:
            parsed_url = urllib.parse.urlparse(app_url)
            endpoint = (
                urllib.parse.urlunparse((parsed_url.scheme, parsed_url.netloc, "", "", "", ""))
                if parsed_url.scheme and parsed_url.netloc
                else app_url
            )
            reason = getattr(exc, "reason", exc)
            raise APIError(f"Unable to reach Muni app at {endpoint}: {reason}") from exc

        if response_model is not None:
            return response_model.model_validate(result)
        return result
