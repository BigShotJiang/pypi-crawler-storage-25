"""Human-readable table/tree formatting for CLI output."""

import json
from typing import Any


def _truncate(s: str, width: int) -> str:
    return s[:width - 1] + "\u2026" if len(s) > width else s


def _pad(s: str, width: int) -> str:
    return s + " " * max(0, width - len(s))


def _format_number(value: Any) -> str:
    if isinstance(value, int):
        return str(value)
    if isinstance(value, float):
        if value.is_integer():
            return str(int(value))
        return f"{value:.1f}"
    return "?"


def _format_position(node: dict[str, Any]) -> str:
    return f"({_format_number(node.get('position_x'))}, {_format_number(node.get('position_y'))})"


def _format_size(node: dict[str, Any]) -> str:
    return f"{_format_number(node.get('width'))}x{_format_number(node.get('height'))}"


def _preview_text(value: str, width: int = 80) -> str:
    compact = " ".join(value.split())
    return _truncate(compact, width)


def _indent_block(text: str, prefix: str = "  ") -> list[str]:
    return [f"{prefix}{line}" if line else prefix.rstrip() for line in text.splitlines()]


def _format_json_block(value: Any) -> list[str]:
    try:
        rendered = json.dumps(value, indent=2, sort_keys=True)
    except TypeError:
        rendered = str(value)
    return _indent_block(rendered)


def format_tools_table(tools: list[dict]) -> str:
    """Format a list of tools as a compact table."""
    if not tools:
        return "No tools found."

    col_name = max(len(t.get("name", "")) for t in tools)
    col_name = max(col_name, 4)  # "Name"
    col_cat = max(len(t.get("category", "")) for t in tools)
    col_cat = max(col_cat, 8)  # "Category"

    lines = [
        f"{_pad('Name', col_name)}  {_pad('Category', col_cat)}  Description",
        f"{'-' * col_name}  {'-' * col_cat}  {'-' * 40}",
    ]
    for t in tools:
        name = _pad(t.get("name", ""), col_name)
        cat = _pad(t.get("category", ""), col_cat)
        desc = _truncate(t.get("description", ""), 60)
        lines.append(f"{name}  {cat}  {desc}")
    return "\n".join(lines)


def format_tool_detail(tool: dict) -> str:
    """Format full tool detail including inputs."""
    lines = [
        f"{tool.get('name', '?')} \u2014 {tool.get('description', '')}",
        f"Category: {tool.get('category', '?')}",
    ]
    if ref := tool.get("reference_url"):
        lines.append(f"Reference: {ref}")

    params = tool.get("parameters", {})
    props = params.get("properties", {})
    required = set(params.get("required", []))

    if props:
        lines.append("")
        lines.append("Inputs:")
        for pname, pdef in props.items():
            ptype = pdef.get("type", "any")
            if isinstance(ptype, list):
                ptype = "/".join(ptype)
            req = "*" if pname in required else " "
            default = ""
            if "default" in pdef:
                default = f" (default: {pdef['default']})"
            desc = pdef.get("description", "")
            enum_vals = pdef.get("enum")
            if enum_vals:
                desc += f" [{', '.join(str(v) for v in enum_vals)}]"
            lines.append(f"  {req} {_pad(pname, 20)} {_pad(ptype, 10)} {desc}{default}")

    contract = format_tool_outputs(tool)
    if contract != "No output contract advertised.":
        lines.append("")
        lines.append(contract)

    return "\n".join(lines)


def _format_output_source(source: dict[str, Any]) -> str:
    source_type = source.get("type", "?")
    path = source.get("path")
    fmt = source.get("format")
    json_path = source.get("json_path")
    parts = [str(source_type)]
    if path:
        parts.append(str(path))
    if json_path:
        parts[-1] = f"{parts[-1]}#{json_path}"
    if fmt:
        parts.append(f"format={fmt}")
    return " ".join(parts)


def format_tool_outputs(tool: dict) -> str:
    """Format advertised output files and canvas views for a tool."""
    outputs = tool.get("outputs") if isinstance(tool.get("outputs"), list) else []
    views = tool.get("views") if isinstance(tool.get("views"), list) else []
    examples = (
        tool.get("materialization_examples")
        if isinstance(tool.get("materialization_examples"), list)
        else []
    )
    if not outputs and not views and not examples:
        return "No output contract advertised."

    lines: list[str] = []
    if outputs:
        lines.append("Outputs:")
        for output in outputs:
            key = output.get("key", "?")
            kind = output.get("kind", "?")
            title = output.get("title")
            source = output.get("source") if isinstance(output.get("source"), dict) else {}
            label = f"  - {key} ({kind})"
            if source:
                label += f" -> {_format_output_source(source)}"
            if title and title != key:
                label += f" — {title}"
            lines.append(label)

    if views:
        if lines:
            lines.append("")
        lines.append("Canvas Views:")
        for view in views:
            key = view.get("key", "?")
            node_type = view.get("view", "?")
            output = view.get("output", "?")
            auto = "auto" if view.get("auto") else "manual"
            title = view.get("title")
            linked_view = view.get("linked_view")
            label = f"  - {key}: {node_type} node from {output} ({auto})"
            if linked_view:
                label += f"; linked to {linked_view}"
            if title and title != key:
                label += f" — {title}"
            lines.append(label)
            if prompt := view.get("prompt"):
                lines.append(f"      Prompt: {_preview_text(str(prompt), 120)}")

    if examples:
        if lines:
            lines.append("")
        lines.append("Materialization Examples:")
        for example in examples:
            title = example.get("title", "Example")
            call_id = example.get("call_id")
            job_id = example.get("job_id")
            label = f"  - {title}"
            refs = [ref for ref in [job_id, call_id] if ref]
            if refs:
                label += f" ({', '.join(refs)})"
            lines.append(label)
            for view in example.get("views") or []:
                view_key = view.get("view_key", "?")
                node_type = view.get("node_type", "?")
                script_path = view.get("script_path")
                script_size = view.get("script_size_bytes")
                line = f"      - {view_key}: {node_type}"
                if script_path:
                    line += f" example {script_path}"
                if script_size:
                    line += f" ({script_size} bytes)"
                lines.append(line)
                context = view.get("example_context")
                if isinstance(context, dict) and context.get("markdown"):
                    lines.append("        context: example_context.markdown")

    return "\n".join(lines)


def format_tool_inputs(tool: dict) -> str:
    """Format just the input parameters table."""
    params = tool.get("parameters", {})
    props = params.get("properties", {})
    required = set(params.get("required", []))

    if not props:
        return "No parameters."

    lines = [
        f"Inputs for {tool.get('name', '?')}:",
        "",
        f"  {'':1} {_pad('Name', 20)} {_pad('Type', 10)} {_pad('Default', 12)} Description",
        f"  {'-':1} {'-' * 20} {'-' * 10} {'-' * 12} {'-' * 30}",
    ]
    for pname, pdef in props.items():
        ptype = pdef.get("type", "any")
        if isinstance(ptype, list):
            ptype = "/".join(ptype)
        req = "*" if pname in required else " "
        default = str(pdef["default"]) if "default" in pdef else "-"
        desc = pdef.get("description", "")
        lines.append(f"  {req} {_pad(pname, 20)} {_pad(ptype, 10)} {_pad(default, 12)} {desc}")

    lines.append("")
    lines.append("  * = required")
    return "\n".join(lines)


def format_examples(tool_name: str, examples: list[dict]) -> str:
    """Format usage examples."""
    if not examples:
        return f"No examples available for {tool_name}."

    lines = [f"Examples for {tool_name}:", ""]
    for ex in examples:
        lines.append(f"  {ex.get('title', 'Example')}:")
        if desc := ex.get("description"):
            lines.append(f"    {desc}")
        params = ex.get("parameters", {})
        if params:
            parts = [f"{k}={_format_value(v)}" for k, v in params.items()]
            lines.append(f"    muni run {tool_name} {' '.join(parts)}")
        lines.append("")
    return "\n".join(lines)


def format_job_nodes(plan: dict) -> str:
    """Format a completed-job canvas node plan."""
    status = plan.get("status", "?")
    if status != "ready":
        message = plan.get("message") or plan.get("error") or "Node plan is not ready."
        return f"Job nodes: {status}\n{message}"

    lines = [
        f"Job nodes for {plan.get('job_id', '?')}",
        f"Tool: {plan.get('tool_name', '?')}",
    ]
    if call_id := plan.get("call_id"):
        lines.append(f"Call ID: {call_id}")

    nodes = plan.get("nodes") if isinstance(plan.get("nodes"), list) else []
    has_agent_examples = False
    if nodes:
        lines.append("")
        lines.append("Nodes:")
        for node in nodes:
            view_key = node.get("view_key", "?")
            output_key = node.get("output_key", "?")
            node_type = node.get("type", "?")
            title = node.get("title")
            label = f"  - {view_key}: {node_type} from {output_key}"
            if title:
                label += f" — {title}"
            lines.append(label)
            source_file = node.get("source_file") if isinstance(node.get("source_file"), dict) else {}
            if source_file:
                exists = "exists" if source_file.get("exists") else "missing"
                path = source_file.get("path", "?")
                lines.append(f"      source: {path} ({exists})")
            renderer = node.get("renderer") if isinstance(node.get("renderer"), dict) else {}
            examples = renderer.get("examples") if isinstance(renderer.get("examples"), list) else []
            if renderer.get("kind") == "agent_prompt":
                lines.append(f"      renderer: agent_prompt ({len(examples)} example{'s' if len(examples) != 1 else ''})")
                if examples:
                    has_agent_examples = True
            if examples:
                for example in examples:
                    lines.append(f"      example: {example.get('title', 'Example')}")
                    for view in example.get("views") or []:
                        if view.get("view_key") != view_key:
                            continue
                        script_path = view.get("script_path")
                        script_size = view.get("script_size_bytes")
                        if script_path:
                            suffix = f" ({script_size} bytes)" if script_size else ""
                            lines.append(f"        script: {script_path}{suffix}")
                        context = view.get("example_context")
                        if isinstance(context, dict) and context.get("markdown"):
                            lines.append("        context: example_context.markdown")
    else:
        lines.append("")
        lines.append("No nodes.")

    skipped = plan.get("skipped") if isinstance(plan.get("skipped"), list) else []
    if skipped:
        lines.append("")
        lines.append("Skipped:")
        for item in skipped:
            lines.append(f"  - {item.get('view_key', '?')}: {item.get('reason', '?')}")

    if has_agent_examples:
        lines.append("")
        lines.append(
            "Tip: re-run with --json to include the full prompt, example_context.markdown, "
            "and inline code examples for agents."
        )

    return "\n".join(lines)


def format_job_nodes_apply(result: dict) -> str:
    """Format the result of applying a job node materialization plan."""
    plan = result.get("plan") if isinstance(result.get("plan"), dict) else {}
    materialization = (
        result.get("materialization")
        if isinstance(result.get("materialization"), dict)
        else {}
    )
    lines = [
        f"Materialized job nodes for {plan.get('callId') or materialization.get('callId') or '?'}",
        f"Status: {materialization.get('status', '?')}",
    ]
    plan_nodes = plan.get("nodes") if isinstance(plan.get("nodes"), list) else []
    plan_by_view = {
        (node.get("outputKey"), node.get("viewKey")): node
        for node in plan_nodes
        if isinstance(node, dict)
    }

    nodes = materialization.get("nodes") if isinstance(materialization.get("nodes"), list) else []
    if nodes:
        lines.append("")
        lines.append("Nodes:")
        for node in nodes:
            node_id = node.get("nodeId") or node.get("node_id") or "?"
            output_key = node.get("outputKey") or node.get("output_key")
            view_key = node.get("viewKey") or node.get("view_key")
            planned = plan_by_view.get((output_key, view_key), {})
            node_type = node.get("type") or planned.get("nodeType") or planned.get("view") or "?"
            title = node.get("title") or planned.get("title") or ""
            status = node.get("status")
            label = f"  - {node_id}: {node_type}"
            if title:
                label += f" — {title}"
            if output_key or view_key:
                label += f" ({output_key or '?'} / {view_key or '?'})"
            if status:
                label += f" [{status}]"
            lines.append(label)

    chart_tasks = (
        result.get("chartRendererTasks")
        if isinstance(result.get("chartRendererTasks"), list)
        else materialization.get("chartRendererTasks")
        if isinstance(materialization.get("chartRendererTasks"), list)
        else []
    )
    if chart_tasks:
        lines.append("")
        lines.append("Chart renderer tasks:")
        for task in chart_tasks:
            node_id = task.get("nodeId") or task.get("node_id") or "?"
            examples = task.get("examples") if isinstance(task.get("examples"), list) else []
            lines.append(f"  - {node_id}: {len(examples)} example{'s' if len(examples) != 1 else ''}")

    pruning = result.get("pruning") if isinstance(result.get("pruning"), dict) else None
    if pruning:
        removed = pruning.get("removedNodeIds") or pruning.get("removed_node_ids") or []
        if removed:
            lines.append("")
            lines.append(f"Pruned stale nodes: {', '.join(map(str, removed))}")

    return "\n".join(lines)


def _format_value(v: Any) -> str:
    if isinstance(v, str):
        return v if " " not in v else f'"{v}"'
    if isinstance(v, (list, dict)):
        return json.dumps(v)
    return str(v)


def format_job_status(data: dict) -> str:
    """Format a job status response."""
    status = data.get("status", "?")
    job_id = data.get("job_id") or data.get("id")
    call_id = data.get("call_id")
    primary = job_id or call_id or "?"
    lines = [f"Job: {primary}", f"Status: {status}"]
    if job_id and call_id and job_id != call_id:
        lines.append(f"Call ID: {call_id}")
    if title := data.get("title"):
        lines.append(f"Title: {title}")
    lines.append(f"Type: {data.get('job_type', '?')}")
    if provider := data.get("provider"):
        lines.append(f"Provider: {provider}")
    if created := data.get("created_at"):
        lines.append(f"Created: {created}")
    if updated := data.get("updated_at"):
        lines.append(f"Updated: {updated}")
    if completed := data.get("completed_at"):
        lines.append(f"Completed: {completed}")
    if runtime := data.get("runtime_seconds"):
        lines.append(f"Runtime: {runtime}s")
    if result_status := data.get("result_status"):
        lines.append(f"Result Status: {result_status}")
    if error := data.get("error"):
        lines.append(f"Error: {error}")
    return "\n".join(lines)


def format_jobs_table(jobs: list[dict]) -> str:
    """Format a list of jobs as a table."""
    if not jobs:
        return "No jobs found."

    lines = [
        f"{_pad('Job ID', 42)}  {_pad('Status', 10)}  {_pad('Type', 28)}  Created",
        f"{'-' * 42}  {'-' * 10}  {'-' * 28}  {'-' * 20}",
    ]
    for j in jobs:
        primary = j.get("id") or j.get("job_id") or j.get("call_id") or "?"
        cid = _pad(_truncate(primary, 42), 42)
        st = _pad(j.get("status", "?"), 10)
        jt = _pad(_truncate(j.get("job_type", "?"), 28), 28)
        created = j.get("created_at", "?")[:19]
        lines.append(f"{cid}  {st}  {jt}  {created}")
    return "\n".join(lines)


def format_file_tree(data: dict, *, path_prefix: str | None = None) -> str:
    """Format the file listing response as a tree.

    If path_prefix is given, only show the subtree under that directory.
    """
    primary = data.get("job_id") or data.get("id") or data.get("call_id") or "?"
    label = f"Files for job {primary}"
    if path_prefix:
        label += f" (path: {path_prefix})"
    lines = [f"{label}:"]
    tree = data.get("tree", [])

    if path_prefix:
        tree = _find_subtree(tree, path_prefix)

    if not tree:
        lines.append("  (no files)")
        return "\n".join(lines)

    def _render(nodes: list, prefix: str = "") -> None:
        for i, node in enumerate(nodes):
            is_last = i == len(nodes) - 1
            connector = "\u2514\u2500 " if is_last else "\u251c\u2500 "
            name = node.get("name", "?")
            size = node.get("size_bytes")
            suffix = f"  ({_human_size(size)})" if size else ""
            lines.append(f"{prefix}{connector}{name}{suffix}")
            children = node.get("children", [])
            if children:
                child_prefix = prefix + ("   " if is_last else "\u2502  ")
                _render(children, child_prefix)

    _render(tree)
    return "\n".join(lines)


def _find_subtree(tree: list[dict], path_prefix: str) -> list[dict]:
    """Walk the tree to find the children of the node matching path_prefix."""
    parts = [p for p in path_prefix.strip("/").split("/") if p]
    nodes = tree
    for part in parts:
        found = None
        for node in nodes:
            if node.get("name") == part:
                found = node
                break
        if found is None:
            return []
        children = found.get("children", [])
        if children:
            nodes = children
        else:
            # Leaf node matched — return it as a single-item list
            return [found]
    return nodes


def _human_size(n: int | None) -> str:
    if n is None:
        return ""
    for unit in ("B", "KB", "MB", "GB"):
        if abs(n) < 1024:
            return f"{n:.0f} {unit}" if unit == "B" else f"{n:.1f} {unit}"
        n /= 1024
    return f"{n:.1f} TB"


def format_balance(data: dict) -> str:
    """Format user balance."""
    balance = data.get("balance", data.get("credits", 0))
    return f"Balance: {balance} credits"


def format_spaces_table(spaces: list[dict], *, active_space_id: str | None = None) -> str:
    """Format spaces list."""
    if not spaces:
        return "No spaces found."

    lines = [
        f"{_pad('Active', 6)}  {_pad('ID', 38)}  {_pad('Name', 30)}  Owner",
        f"{'-' * 6}  {'-' * 38}  {'-' * 30}  {'-' * 36}",
    ]
    for s in spaces:
        marker = "*" if s.get("id") == active_space_id else ""
        sid = _pad(s.get("id", "?"), 38)
        name = _pad(_truncate(s.get("name", "?"), 30), 30)
        owner = s.get("owner_id", "?")
        lines.append(f"{_pad(marker, 6)}  {sid}  {name}  {owner}")
    return "\n".join(lines)


def format_members_table(members: list[dict]) -> str:
    """Format space members."""
    if not members:
        return "No members found."

    lines = [
        f"{_pad('Email', 30)}  {_pad('Role', 10)}  User ID",
        f"{'-' * 30}  {'-' * 10}  {'-' * 36}",
    ]
    for m in members:
        email = _pad(m.get("email", "?"), 30)
        role = _pad(m.get("role", "?"), 10)
        uid = m.get("user_id", "?")
        lines.append(f"{email}  {role}  {uid}")
    return "\n".join(lines)


def format_config_display(cfg: dict[str, Any]) -> str:
    """Format config show output."""
    lines = [
        f"Profile: {cfg.get('profile', '?')}",
        f"API URL: {cfg.get('api_url', '(unset)')}",
        f"App URL: {cfg.get('app_url', '(unset)')}",
        f"Supabase URL: {cfg.get('supabase_url', '(unset)')}",
        f"Supabase Publishable Key: {cfg.get('supabase_publishable_key', '(unset)')}",
    ]
    active_space_id = cfg.get("active_space_id")
    if active_space_id:
        label = cfg.get("active_space_name")
        lines.append(
            f"Active Space: {label} ({active_space_id})" if label else f"Active Space: {active_space_id}"
        )
    else:
        lines.append("Active Space: (unset)")
    active_page_id = cfg.get("active_page_id")
    if active_page_id:
        page_title = cfg.get("active_page_title")
        lines.append(
            f"Active Page: {page_title} ({active_page_id})" if page_title else f"Active Page: {active_page_id}"
        )
    else:
        lines.append("Active Page: (unset)")
    return "\n".join(lines)


def format_results(data: dict) -> str:
    """Format job results."""
    status = data.get("status", "?")
    if status == "failed":
        return f"Job failed: {data.get('error', 'Unknown error')}"
    result = data.get("result")
    if result is None:
        return f"Status: {status} — no results yet"
    return json.dumps(result, indent=2)


def format_job_summary(data: dict) -> str:
    """Format a structured job output summary."""
    lines = [
        f"Job: {data.get('callId', '?')}",
        f"Tool: {data.get('toolName') or '(unknown)'}",
        f"Status: {data.get('status', '?')}",
        f"Files: {data.get('fileCount', 0)}",
    ]

    metrics = data.get("metricsSummary")
    if metrics:
        lines.append("")
        lines.append(f"Rows: {metrics.get('rowCount', 0)}")
        columns = metrics.get("columns", [])
        lines.append(f"Columns ({len(columns)}): {', '.join(columns)}")
        default_cols = metrics.get("defaultColumns", [])
        if default_cols:
            lines.append(f"Default Columns: {', '.join(default_cols)}")
    else:
        lines.append("")
        lines.append("No structured metric data available.")

    hints = data.get("summaryOutput")
    if hints:
        if m := hints.get("metrics"):
            if fmt := m.get("format"):
                lines.append(f"Metric Format: {fmt}")
            if path := m.get("path"):
                lines.append(f"Metric Path: {path}")
        if s := hints.get("structures"):
            lines.append(f"Structures: format={s.get('format', '?')}, path_field={s.get('path_field', '?')}")

    return "\n".join(lines)


def format_job_query(data: dict) -> str:
    """Format job query results as a table."""
    rows = data.get("rows", [])
    columns = data.get("columns", [])
    total = data.get("totalCount", len(rows))
    has_more = data.get("hasMore", False)

    if not rows:
        return f"No data rows. Total: {total}"

    # Compute column widths
    col_widths: dict[str, int] = {}
    for col in columns:
        col_widths[col] = len(col)
    for row in rows:
        for col in columns:
            val = str(row.get(col, ""))
            col_widths[col] = max(col_widths.get(col, 0), min(len(val), 40))

    # Header
    header = "  ".join(_pad(col, col_widths[col]) for col in columns)
    sep = "  ".join("-" * col_widths[col] for col in columns)
    lines = [header, sep]

    # Rows
    for row in rows:
        cells = []
        for col in columns:
            val = row.get(col, "")
            cells.append(_pad(_truncate(str(val), 40), col_widths[col]))
        lines.append("  ".join(cells))

    # Footer
    showing = len(rows)
    footer = f"\nShowing {showing} of {total} rows"
    if has_more:
        footer += " (more available — use --offset and --limit)"
    lines.append(footer)

    return "\n".join(lines)


# ── Pages ────────────────────────────────────────────────────────


def format_pages_table(pages: list[dict], *, active_page_id: str | None = None) -> str:
    """Format a list of pages as a table."""
    if not pages:
        return "No pages found."

    lines = [
        f"{_pad('Active', 6)}  {_pad('ID', 38)}  Title",
        f"{'-' * 6}  {'-' * 38}  {'-' * 30}",
    ]
    for p in pages:
        marker = "*" if p.get("id") == active_page_id else ""
        pid = _pad(p.get("id", "?"), 38)
        title = p.get("title", "(untitled)")
        lines.append(f"{_pad(marker, 6)}  {pid}  {title}")
    return "\n".join(lines)


# ── Nodes ────────────────────────────────────────────────────────


def format_nodes_table(nodes: list[dict]) -> str:
    """Format a list of muni nodes as a table."""
    if not nodes:
        return "No nodes found."

    lines = [
        f"{_pad('ID', 38)}  {_pad('Type', 10)}  {_pad('Title', 30)}  {_pad('Script', 6)}  Position",
        f"{'-' * 38}  {'-' * 10}  {'-' * 30}  {'-' * 6}  {'-' * 16}",
    ]
    for n in nodes:
        nid = _pad(_truncate(n.get("id", "?"), 38), 38)
        ntype = _pad(n.get("type", "?"), 10)
        title = _pad(_truncate(n.get("title", ""), 30), 30)
        has_script = _pad("yes" if n.get("hasScript") else "no", 6)
        pos = f"({_format_number(n.get('positionX'))}, {_format_number(n.get('positionY'))})"
        lines.append(f"{nid}  {ntype}  {title}  {has_script}  {pos}")
    return "\n".join(lines)


def format_node_detail(node: dict) -> str:
    """Format detailed node read view (read_node output)."""
    # Soft-deleted nodes get a short response
    if node.get("isRemoved"):
        return "\n".join([
            f"Node: {node.get('nodeId', node.get('id', '?'))}",
            f"Title: {node.get('title', '(none)')}",
            f"Type: {node.get('type', '?')}",
            "Status: removed",
        ])

    lines = [
        f"Node: {node.get('nodeId', '?')}",
        f"Title: {node.get('title', '(none)')}",
        f"Type: {node.get('type', '?')}",
        f"Position: ({_format_number(node.get('positionX'))}, {_format_number(node.get('positionY'))})",
    ]

    # Runtime
    runtime = node.get("runtime")
    if isinstance(runtime, dict) and runtime:
        if lifecycle := runtime.get("lifecycle"):
            lines.append(f"Lifecycle: {lifecycle}")
        if requested_at := runtime.get("requestedAt"):
            lines.append(f"Requested At: {requested_at}")

    # Gate results
    cr = node.get("compileResult")
    er = node.get("executeResult")
    vr = node.get("validateResult") or node.get("validation")
    if cr or er or vr:
        compile_s = cr.get("status", "—") if isinstance(cr, dict) else "—"
        execute_s = er.get("status", "—") if isinstance(er, dict) else "—"
        validate_s = vr.get("status", "—") if isinstance(vr, dict) else "—"
        lines.append(f"Gates: compile={compile_s}  execute={execute_s}  validate={validate_s}")

    # Render health
    rh = node.get("renderHealth")
    if isinstance(rh, dict):
        msg = f" ({rh['message']})" if rh.get("message") else ""
        lines.append(f"Render: {rh.get('status', '?')}{msg}")

    # Script
    script = node.get("script")
    if script:
        lines.append("")
        lines.append("Script:")
        lines.extend(_indent_block(str(script)))

    # Current Data
    current_data = node.get("currentData")
    if isinstance(current_data, dict) and current_data:
        lines.append("")
        lines.append("Current Data:")
        if data_type := current_data.get("dataType"):
            lines.append(f"  Data Type: {data_type}")
        if row_count := current_data.get("rowCount"):
            lines.append(f"  Row Count: {row_count}")
        column_schema = current_data.get("columnSchema")
        if isinstance(column_schema, list) and column_schema:
            col_names = [c.get("name", "?") for c in column_schema if isinstance(c, dict)]
            lines.append(f"  Columns: {', '.join(col_names[:10])}")
        preview = current_data.get("preview")
        if isinstance(preview, dict) and preview:
            lines.append("  Preview:")
            lines.extend(_format_json_block(preview))
        artifacts = current_data.get("artifacts")
        if isinstance(artifacts, list) and artifacts:
            lines.append(f"  Artifacts: {len(artifacts)}")

    # Python files (code nodes)
    python_files = node.get("pythonFiles") or []
    if python_files:
        lines.append("")
        lines.append(f"Python Files ({len(python_files)}):")
        for pf in python_files:
            path = pf.get("path", "?")
            content = pf.get("content", "")
            line_count = content.count("\n") + 1 if content else 0
            lines.append(f"  {path} ({line_count} lines)")
            lines.extend(_indent_block(content, prefix="    "))

    # Python stdout/stderr (code nodes)
    if isinstance(runtime, dict):
        stdout = runtime.get("pythonStdout")
        stderr = runtime.get("pythonStderr")
        if stdout:
            lines.append("")
            lines.append("Python Stdout:")
            lines.extend(_indent_block(str(stdout)))
        if stderr:
            lines.append("")
            lines.append("Python Stderr:")
            lines.extend(_indent_block(str(stderr)))

    # Connections
    connections = node.get("connections", [])
    if connections:
        lines.append("")
        lines.append(f"Connections ({len(connections)}):")
        for conn in connections:
            kind = conn.get("kind", "?")
            source = conn.get("sourceNodeId") or "(external)"
            lines.append(f"  {conn.get('id', '?')}: {source} -> this ({kind})")

    return "\n".join(lines)


def format_node_create_result(result: dict[str, Any]) -> str:
    """Format a created node summary."""
    base = f"Created node: {result.get('nodeId', '?')} ({result.get('title', '')})"
    if result.get("positionX") is None or result.get("positionY") is None:
        return base
    return (
        f"{base} at "
        f"({_format_number(result.get('positionX'))}, {_format_number(result.get('positionY'))})"
    )


def format_canvas_placement_preview(preview: dict[str, Any]) -> str:
    """Format smart-placement preview details."""
    position = preview.get("position") if isinstance(preview.get("position"), dict) else {}
    center = preview.get("viewportCenter") if isinstance(preview.get("viewportCenter"), dict) else {}
    rect = preview.get("viewportRect") if isinstance(preview.get("viewportRect"), dict) else {}
    size = preview.get("size") if isinstance(preview.get("size"), dict) else {}
    source = preview.get("source") or "?"

    lines = [
        f"Looking at: ({_format_number(center.get('x'))}, {_format_number(center.get('y'))})",
        f"Suggested {preview.get('type', 'node')} placement: ({_format_number(position.get('x'))}, {_format_number(position.get('y'))})",
        f"Reason: {source}",
    ]

    search_column = preview.get("searchColumn")
    search_row = preview.get("searchRow")
    if isinstance(search_column, int) and isinstance(search_row, int) and (search_column or search_row):
        lines.append(f"Search offset: column {search_column}, row {search_row}")

    if size:
        lines.append(f"Node size: {_format_number(size.get('width'))}x{_format_number(size.get('height'))}")
    if rect:
        lines.append(
            "Visible canvas: "
            f"x={_format_number(rect.get('x'))}, y={_format_number(rect.get('y'))}, "
            f"w={_format_number(rect.get('width'))}, h={_format_number(rect.get('height'))}"
        )
    if preview.get("obstacleCount") is not None:
        lines.append(f"Obstacles checked: {preview.get('obstacleCount')}")

    return "\n".join(lines)


def format_canvas_position(result: dict[str, Any]) -> str:
    """Format the current canvas position."""
    position = result.get("position") if isinstance(result.get("position"), dict) else {}
    rect = result.get("viewportRect") if isinstance(result.get("viewportRect"), dict) else {}

    lines = [
        f"Looking at: ({_format_number(position.get('x'))}, {_format_number(position.get('y'))})",
    ]
    if rect:
        lines.append(
            "Visible canvas: "
            f"x={_format_number(rect.get('x'))}, y={_format_number(rect.get('y'))}, "
            f"w={_format_number(rect.get('width'))}, h={_format_number(rect.get('height'))}"
        )

    return "\n".join(lines)


def format_search_results(nodes: list[dict], query: str) -> str:
    """Format search results with a match count header."""
    if not nodes:
        return f'No nodes matching "{query}".'
    header = f'Found {len(nodes)} node{"s" if len(nodes) != 1 else ""} matching "{query}":'
    return header + "\n\n" + format_nodes_table(nodes)
