from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.get_webhook_target_response_200 import GetWebhookTargetResponse200
from ...models.get_webhook_target_response_400 import GetWebhookTargetResponse400
from ...models.get_webhook_target_response_401 import GetWebhookTargetResponse401
from ...models.get_webhook_target_response_403 import GetWebhookTargetResponse403
from ...models.get_webhook_target_response_404 import GetWebhookTargetResponse404
from ...models.get_webhook_target_response_406 import GetWebhookTargetResponse406
from ...models.get_webhook_target_response_409 import GetWebhookTargetResponse409
from ...models.get_webhook_target_response_500 import GetWebhookTargetResponse500
from typing import cast



def _get_kwargs(
    org: str,
    webhook_target_id: str,

) -> dict[str, Any]:
    

    

    

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/{org}/webhook-targets/{webhook_target_id}".format(org=quote(str(org), safe=""),webhook_target_id=quote(str(webhook_target_id), safe=""),),
    }


    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> GetWebhookTargetResponse200 | GetWebhookTargetResponse400 | GetWebhookTargetResponse401 | GetWebhookTargetResponse403 | GetWebhookTargetResponse404 | GetWebhookTargetResponse406 | GetWebhookTargetResponse409 | GetWebhookTargetResponse500 | None:
    if response.status_code == 200:
        response_200 = GetWebhookTargetResponse200.from_dict(response.json())



        return response_200

    if response.status_code == 400:
        response_400 = GetWebhookTargetResponse400.from_dict(response.json())



        return response_400

    if response.status_code == 401:
        response_401 = GetWebhookTargetResponse401.from_dict(response.json())



        return response_401

    if response.status_code == 403:
        response_403 = GetWebhookTargetResponse403.from_dict(response.json())



        return response_403

    if response.status_code == 404:
        response_404 = GetWebhookTargetResponse404.from_dict(response.json())



        return response_404

    if response.status_code == 406:
        response_406 = GetWebhookTargetResponse406.from_dict(response.json())



        return response_406

    if response.status_code == 409:
        response_409 = GetWebhookTargetResponse409.from_dict(response.json())



        return response_409

    if response.status_code == 500:
        response_500 = GetWebhookTargetResponse500.from_dict(response.json())



        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[GetWebhookTargetResponse200 | GetWebhookTargetResponse400 | GetWebhookTargetResponse401 | GetWebhookTargetResponse403 | GetWebhookTargetResponse404 | GetWebhookTargetResponse406 | GetWebhookTargetResponse409 | GetWebhookTargetResponse500]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    org: str,
    webhook_target_id: str,
    *,
    client: AuthenticatedClient | Client,

) -> Response[GetWebhookTargetResponse200 | GetWebhookTargetResponse400 | GetWebhookTargetResponse401 | GetWebhookTargetResponse403 | GetWebhookTargetResponse404 | GetWebhookTargetResponse406 | GetWebhookTargetResponse409 | GetWebhookTargetResponse500]:
    """ Get webhook target

     Get a webhook target by ID

    Args:
        org (str):
        webhook_target_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetWebhookTargetResponse200 | GetWebhookTargetResponse400 | GetWebhookTargetResponse401 | GetWebhookTargetResponse403 | GetWebhookTargetResponse404 | GetWebhookTargetResponse406 | GetWebhookTargetResponse409 | GetWebhookTargetResponse500]
     """


    kwargs = _get_kwargs(
        org=org,
webhook_target_id=webhook_target_id,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    org: str,
    webhook_target_id: str,
    *,
    client: AuthenticatedClient | Client,

) -> GetWebhookTargetResponse200 | GetWebhookTargetResponse400 | GetWebhookTargetResponse401 | GetWebhookTargetResponse403 | GetWebhookTargetResponse404 | GetWebhookTargetResponse406 | GetWebhookTargetResponse409 | GetWebhookTargetResponse500 | None:
    """ Get webhook target

     Get a webhook target by ID

    Args:
        org (str):
        webhook_target_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetWebhookTargetResponse200 | GetWebhookTargetResponse400 | GetWebhookTargetResponse401 | GetWebhookTargetResponse403 | GetWebhookTargetResponse404 | GetWebhookTargetResponse406 | GetWebhookTargetResponse409 | GetWebhookTargetResponse500
     """


    return sync_detailed(
        org=org,
webhook_target_id=webhook_target_id,
client=client,

    ).parsed

async def asyncio_detailed(
    org: str,
    webhook_target_id: str,
    *,
    client: AuthenticatedClient | Client,

) -> Response[GetWebhookTargetResponse200 | GetWebhookTargetResponse400 | GetWebhookTargetResponse401 | GetWebhookTargetResponse403 | GetWebhookTargetResponse404 | GetWebhookTargetResponse406 | GetWebhookTargetResponse409 | GetWebhookTargetResponse500]:
    """ Get webhook target

     Get a webhook target by ID

    Args:
        org (str):
        webhook_target_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetWebhookTargetResponse200 | GetWebhookTargetResponse400 | GetWebhookTargetResponse401 | GetWebhookTargetResponse403 | GetWebhookTargetResponse404 | GetWebhookTargetResponse406 | GetWebhookTargetResponse409 | GetWebhookTargetResponse500]
     """


    kwargs = _get_kwargs(
        org=org,
webhook_target_id=webhook_target_id,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    org: str,
    webhook_target_id: str,
    *,
    client: AuthenticatedClient | Client,

) -> GetWebhookTargetResponse200 | GetWebhookTargetResponse400 | GetWebhookTargetResponse401 | GetWebhookTargetResponse403 | GetWebhookTargetResponse404 | GetWebhookTargetResponse406 | GetWebhookTargetResponse409 | GetWebhookTargetResponse500 | None:
    """ Get webhook target

     Get a webhook target by ID

    Args:
        org (str):
        webhook_target_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetWebhookTargetResponse200 | GetWebhookTargetResponse400 | GetWebhookTargetResponse401 | GetWebhookTargetResponse403 | GetWebhookTargetResponse404 | GetWebhookTargetResponse406 | GetWebhookTargetResponse409 | GetWebhookTargetResponse500
     """


    return (await asyncio_detailed(
        org=org,
webhook_target_id=webhook_target_id,
client=client,

    )).parsed
