from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.update_webhook_target_body import UpdateWebhookTargetBody
from ...models.update_webhook_target_response_200 import UpdateWebhookTargetResponse200
from ...models.update_webhook_target_response_400 import UpdateWebhookTargetResponse400
from ...models.update_webhook_target_response_401 import UpdateWebhookTargetResponse401
from ...models.update_webhook_target_response_403 import UpdateWebhookTargetResponse403
from ...models.update_webhook_target_response_404 import UpdateWebhookTargetResponse404
from ...models.update_webhook_target_response_406 import UpdateWebhookTargetResponse406
from ...models.update_webhook_target_response_409 import UpdateWebhookTargetResponse409
from ...models.update_webhook_target_response_500 import UpdateWebhookTargetResponse500
from typing import cast



def _get_kwargs(
    org: str,
    webhook_target_id: str,
    *,
    body: UpdateWebhookTargetBody,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "patch",
        "url": "/{org}/webhook-targets/{webhook_target_id}".format(org=quote(str(org), safe=""),webhook_target_id=quote(str(webhook_target_id), safe=""),),
    }

    _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> UpdateWebhookTargetResponse200 | UpdateWebhookTargetResponse400 | UpdateWebhookTargetResponse401 | UpdateWebhookTargetResponse403 | UpdateWebhookTargetResponse404 | UpdateWebhookTargetResponse406 | UpdateWebhookTargetResponse409 | UpdateWebhookTargetResponse500 | None:
    if response.status_code == 200:
        response_200 = UpdateWebhookTargetResponse200.from_dict(response.json())



        return response_200

    if response.status_code == 400:
        response_400 = UpdateWebhookTargetResponse400.from_dict(response.json())



        return response_400

    if response.status_code == 401:
        response_401 = UpdateWebhookTargetResponse401.from_dict(response.json())



        return response_401

    if response.status_code == 403:
        response_403 = UpdateWebhookTargetResponse403.from_dict(response.json())



        return response_403

    if response.status_code == 404:
        response_404 = UpdateWebhookTargetResponse404.from_dict(response.json())



        return response_404

    if response.status_code == 406:
        response_406 = UpdateWebhookTargetResponse406.from_dict(response.json())



        return response_406

    if response.status_code == 409:
        response_409 = UpdateWebhookTargetResponse409.from_dict(response.json())



        return response_409

    if response.status_code == 500:
        response_500 = UpdateWebhookTargetResponse500.from_dict(response.json())



        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[UpdateWebhookTargetResponse200 | UpdateWebhookTargetResponse400 | UpdateWebhookTargetResponse401 | UpdateWebhookTargetResponse403 | UpdateWebhookTargetResponse404 | UpdateWebhookTargetResponse406 | UpdateWebhookTargetResponse409 | UpdateWebhookTargetResponse500]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    org: str,
    webhook_target_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateWebhookTargetBody,

) -> Response[UpdateWebhookTargetResponse200 | UpdateWebhookTargetResponse400 | UpdateWebhookTargetResponse401 | UpdateWebhookTargetResponse403 | UpdateWebhookTargetResponse404 | UpdateWebhookTargetResponse406 | UpdateWebhookTargetResponse409 | UpdateWebhookTargetResponse500]:
    """ Update webhook target

     Update a webhook target for the organization. Any provided field replaces its current value; omitted
    fields are left unchanged. Pass `repo_ids: null` to clear the repo filter and make the target org-
    wide.

    Args:
        org (str):
        webhook_target_id (str):
        body (UpdateWebhookTargetBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[UpdateWebhookTargetResponse200 | UpdateWebhookTargetResponse400 | UpdateWebhookTargetResponse401 | UpdateWebhookTargetResponse403 | UpdateWebhookTargetResponse404 | UpdateWebhookTargetResponse406 | UpdateWebhookTargetResponse409 | UpdateWebhookTargetResponse500]
     """


    kwargs = _get_kwargs(
        org=org,
webhook_target_id=webhook_target_id,
body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    org: str,
    webhook_target_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateWebhookTargetBody,

) -> UpdateWebhookTargetResponse200 | UpdateWebhookTargetResponse400 | UpdateWebhookTargetResponse401 | UpdateWebhookTargetResponse403 | UpdateWebhookTargetResponse404 | UpdateWebhookTargetResponse406 | UpdateWebhookTargetResponse409 | UpdateWebhookTargetResponse500 | None:
    """ Update webhook target

     Update a webhook target for the organization. Any provided field replaces its current value; omitted
    fields are left unchanged. Pass `repo_ids: null` to clear the repo filter and make the target org-
    wide.

    Args:
        org (str):
        webhook_target_id (str):
        body (UpdateWebhookTargetBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        UpdateWebhookTargetResponse200 | UpdateWebhookTargetResponse400 | UpdateWebhookTargetResponse401 | UpdateWebhookTargetResponse403 | UpdateWebhookTargetResponse404 | UpdateWebhookTargetResponse406 | UpdateWebhookTargetResponse409 | UpdateWebhookTargetResponse500
     """


    return sync_detailed(
        org=org,
webhook_target_id=webhook_target_id,
client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    org: str,
    webhook_target_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateWebhookTargetBody,

) -> Response[UpdateWebhookTargetResponse200 | UpdateWebhookTargetResponse400 | UpdateWebhookTargetResponse401 | UpdateWebhookTargetResponse403 | UpdateWebhookTargetResponse404 | UpdateWebhookTargetResponse406 | UpdateWebhookTargetResponse409 | UpdateWebhookTargetResponse500]:
    """ Update webhook target

     Update a webhook target for the organization. Any provided field replaces its current value; omitted
    fields are left unchanged. Pass `repo_ids: null` to clear the repo filter and make the target org-
    wide.

    Args:
        org (str):
        webhook_target_id (str):
        body (UpdateWebhookTargetBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[UpdateWebhookTargetResponse200 | UpdateWebhookTargetResponse400 | UpdateWebhookTargetResponse401 | UpdateWebhookTargetResponse403 | UpdateWebhookTargetResponse404 | UpdateWebhookTargetResponse406 | UpdateWebhookTargetResponse409 | UpdateWebhookTargetResponse500]
     """


    kwargs = _get_kwargs(
        org=org,
webhook_target_id=webhook_target_id,
body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    org: str,
    webhook_target_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateWebhookTargetBody,

) -> UpdateWebhookTargetResponse200 | UpdateWebhookTargetResponse400 | UpdateWebhookTargetResponse401 | UpdateWebhookTargetResponse403 | UpdateWebhookTargetResponse404 | UpdateWebhookTargetResponse406 | UpdateWebhookTargetResponse409 | UpdateWebhookTargetResponse500 | None:
    """ Update webhook target

     Update a webhook target for the organization. Any provided field replaces its current value; omitted
    fields are left unchanged. Pass `repo_ids: null` to clear the repo filter and make the target org-
    wide.

    Args:
        org (str):
        webhook_target_id (str):
        body (UpdateWebhookTargetBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        UpdateWebhookTargetResponse200 | UpdateWebhookTargetResponse400 | UpdateWebhookTargetResponse401 | UpdateWebhookTargetResponse403 | UpdateWebhookTargetResponse404 | UpdateWebhookTargetResponse406 | UpdateWebhookTargetResponse409 | UpdateWebhookTargetResponse500
     """


    return (await asyncio_detailed(
        org=org,
webhook_target_id=webhook_target_id,
client=client,
body=body,

    )).parsed
