from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.delete_webhook_target_response_200 import DeleteWebhookTargetResponse200
from ...models.delete_webhook_target_response_400 import DeleteWebhookTargetResponse400
from ...models.delete_webhook_target_response_401 import DeleteWebhookTargetResponse401
from ...models.delete_webhook_target_response_403 import DeleteWebhookTargetResponse403
from ...models.delete_webhook_target_response_404 import DeleteWebhookTargetResponse404
from ...models.delete_webhook_target_response_406 import DeleteWebhookTargetResponse406
from ...models.delete_webhook_target_response_409 import DeleteWebhookTargetResponse409
from ...models.delete_webhook_target_response_500 import DeleteWebhookTargetResponse500
from typing import cast



def _get_kwargs(
    org: str,
    webhook_target_id: str,

) -> dict[str, Any]:
    

    

    

    _kwargs: dict[str, Any] = {
        "method": "delete",
        "url": "/{org}/webhook-targets/{webhook_target_id}".format(org=quote(str(org), safe=""),webhook_target_id=quote(str(webhook_target_id), safe=""),),
    }


    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> DeleteWebhookTargetResponse200 | DeleteWebhookTargetResponse400 | DeleteWebhookTargetResponse401 | DeleteWebhookTargetResponse403 | DeleteWebhookTargetResponse404 | DeleteWebhookTargetResponse406 | DeleteWebhookTargetResponse409 | DeleteWebhookTargetResponse500 | None:
    if response.status_code == 200:
        response_200 = DeleteWebhookTargetResponse200.from_dict(response.json())



        return response_200

    if response.status_code == 400:
        response_400 = DeleteWebhookTargetResponse400.from_dict(response.json())



        return response_400

    if response.status_code == 401:
        response_401 = DeleteWebhookTargetResponse401.from_dict(response.json())



        return response_401

    if response.status_code == 403:
        response_403 = DeleteWebhookTargetResponse403.from_dict(response.json())



        return response_403

    if response.status_code == 404:
        response_404 = DeleteWebhookTargetResponse404.from_dict(response.json())



        return response_404

    if response.status_code == 406:
        response_406 = DeleteWebhookTargetResponse406.from_dict(response.json())



        return response_406

    if response.status_code == 409:
        response_409 = DeleteWebhookTargetResponse409.from_dict(response.json())



        return response_409

    if response.status_code == 500:
        response_500 = DeleteWebhookTargetResponse500.from_dict(response.json())



        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[DeleteWebhookTargetResponse200 | DeleteWebhookTargetResponse400 | DeleteWebhookTargetResponse401 | DeleteWebhookTargetResponse403 | DeleteWebhookTargetResponse404 | DeleteWebhookTargetResponse406 | DeleteWebhookTargetResponse409 | DeleteWebhookTargetResponse500]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    org: str,
    webhook_target_id: str,
    *,
    client: AuthenticatedClient | Client,

) -> Response[DeleteWebhookTargetResponse200 | DeleteWebhookTargetResponse400 | DeleteWebhookTargetResponse401 | DeleteWebhookTargetResponse403 | DeleteWebhookTargetResponse404 | DeleteWebhookTargetResponse406 | DeleteWebhookTargetResponse409 | DeleteWebhookTargetResponse500]:
    """ Delete webhook target

     Delete a webhook target from the organization

    Args:
        org (str):
        webhook_target_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeleteWebhookTargetResponse200 | DeleteWebhookTargetResponse400 | DeleteWebhookTargetResponse401 | DeleteWebhookTargetResponse403 | DeleteWebhookTargetResponse404 | DeleteWebhookTargetResponse406 | DeleteWebhookTargetResponse409 | DeleteWebhookTargetResponse500]
     """


    kwargs = _get_kwargs(
        org=org,
webhook_target_id=webhook_target_id,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    org: str,
    webhook_target_id: str,
    *,
    client: AuthenticatedClient | Client,

) -> DeleteWebhookTargetResponse200 | DeleteWebhookTargetResponse400 | DeleteWebhookTargetResponse401 | DeleteWebhookTargetResponse403 | DeleteWebhookTargetResponse404 | DeleteWebhookTargetResponse406 | DeleteWebhookTargetResponse409 | DeleteWebhookTargetResponse500 | None:
    """ Delete webhook target

     Delete a webhook target from the organization

    Args:
        org (str):
        webhook_target_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeleteWebhookTargetResponse200 | DeleteWebhookTargetResponse400 | DeleteWebhookTargetResponse401 | DeleteWebhookTargetResponse403 | DeleteWebhookTargetResponse404 | DeleteWebhookTargetResponse406 | DeleteWebhookTargetResponse409 | DeleteWebhookTargetResponse500
     """


    return sync_detailed(
        org=org,
webhook_target_id=webhook_target_id,
client=client,

    ).parsed

async def asyncio_detailed(
    org: str,
    webhook_target_id: str,
    *,
    client: AuthenticatedClient | Client,

) -> Response[DeleteWebhookTargetResponse200 | DeleteWebhookTargetResponse400 | DeleteWebhookTargetResponse401 | DeleteWebhookTargetResponse403 | DeleteWebhookTargetResponse404 | DeleteWebhookTargetResponse406 | DeleteWebhookTargetResponse409 | DeleteWebhookTargetResponse500]:
    """ Delete webhook target

     Delete a webhook target from the organization

    Args:
        org (str):
        webhook_target_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeleteWebhookTargetResponse200 | DeleteWebhookTargetResponse400 | DeleteWebhookTargetResponse401 | DeleteWebhookTargetResponse403 | DeleteWebhookTargetResponse404 | DeleteWebhookTargetResponse406 | DeleteWebhookTargetResponse409 | DeleteWebhookTargetResponse500]
     """


    kwargs = _get_kwargs(
        org=org,
webhook_target_id=webhook_target_id,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    org: str,
    webhook_target_id: str,
    *,
    client: AuthenticatedClient | Client,

) -> DeleteWebhookTargetResponse200 | DeleteWebhookTargetResponse400 | DeleteWebhookTargetResponse401 | DeleteWebhookTargetResponse403 | DeleteWebhookTargetResponse404 | DeleteWebhookTargetResponse406 | DeleteWebhookTargetResponse409 | DeleteWebhookTargetResponse500 | None:
    """ Delete webhook target

     Delete a webhook target from the organization

    Args:
        org (str):
        webhook_target_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeleteWebhookTargetResponse200 | DeleteWebhookTargetResponse400 | DeleteWebhookTargetResponse401 | DeleteWebhookTargetResponse403 | DeleteWebhookTargetResponse404 | DeleteWebhookTargetResponse406 | DeleteWebhookTargetResponse409 | DeleteWebhookTargetResponse500
     """


    return (await asyncio_detailed(
        org=org,
webhook_target_id=webhook_target_id,
client=client,

    )).parsed
