from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.create_webhook_target_body import CreateWebhookTargetBody
from ...models.create_webhook_target_response_201 import CreateWebhookTargetResponse201
from ...models.create_webhook_target_response_400 import CreateWebhookTargetResponse400
from ...models.create_webhook_target_response_401 import CreateWebhookTargetResponse401
from ...models.create_webhook_target_response_403 import CreateWebhookTargetResponse403
from ...models.create_webhook_target_response_404 import CreateWebhookTargetResponse404
from ...models.create_webhook_target_response_406 import CreateWebhookTargetResponse406
from ...models.create_webhook_target_response_409 import CreateWebhookTargetResponse409
from ...models.create_webhook_target_response_500 import CreateWebhookTargetResponse500
from typing import cast



def _get_kwargs(
    org: str,
    *,
    body: CreateWebhookTargetBody,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/{org}/webhook-targets".format(org=quote(str(org), safe=""),),
    }

    _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> CreateWebhookTargetResponse201 | CreateWebhookTargetResponse400 | CreateWebhookTargetResponse401 | CreateWebhookTargetResponse403 | CreateWebhookTargetResponse404 | CreateWebhookTargetResponse406 | CreateWebhookTargetResponse409 | CreateWebhookTargetResponse500 | None:
    if response.status_code == 201:
        response_201 = CreateWebhookTargetResponse201.from_dict(response.json())



        return response_201

    if response.status_code == 400:
        response_400 = CreateWebhookTargetResponse400.from_dict(response.json())



        return response_400

    if response.status_code == 401:
        response_401 = CreateWebhookTargetResponse401.from_dict(response.json())



        return response_401

    if response.status_code == 403:
        response_403 = CreateWebhookTargetResponse403.from_dict(response.json())



        return response_403

    if response.status_code == 404:
        response_404 = CreateWebhookTargetResponse404.from_dict(response.json())



        return response_404

    if response.status_code == 406:
        response_406 = CreateWebhookTargetResponse406.from_dict(response.json())



        return response_406

    if response.status_code == 409:
        response_409 = CreateWebhookTargetResponse409.from_dict(response.json())



        return response_409

    if response.status_code == 500:
        response_500 = CreateWebhookTargetResponse500.from_dict(response.json())



        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[CreateWebhookTargetResponse201 | CreateWebhookTargetResponse400 | CreateWebhookTargetResponse401 | CreateWebhookTargetResponse403 | CreateWebhookTargetResponse404 | CreateWebhookTargetResponse406 | CreateWebhookTargetResponse409 | CreateWebhookTargetResponse500]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    org: str,
    *,
    client: AuthenticatedClient | Client,
    body: CreateWebhookTargetBody,

) -> Response[CreateWebhookTargetResponse201 | CreateWebhookTargetResponse400 | CreateWebhookTargetResponse401 | CreateWebhookTargetResponse403 | CreateWebhookTargetResponse404 | CreateWebhookTargetResponse406 | CreateWebhookTargetResponse409 | CreateWebhookTargetResponse500]:
    """ Create webhook target

     Create a webhook target for the organization

    Args:
        org (str):
        body (CreateWebhookTargetBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CreateWebhookTargetResponse201 | CreateWebhookTargetResponse400 | CreateWebhookTargetResponse401 | CreateWebhookTargetResponse403 | CreateWebhookTargetResponse404 | CreateWebhookTargetResponse406 | CreateWebhookTargetResponse409 | CreateWebhookTargetResponse500]
     """


    kwargs = _get_kwargs(
        org=org,
body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    org: str,
    *,
    client: AuthenticatedClient | Client,
    body: CreateWebhookTargetBody,

) -> CreateWebhookTargetResponse201 | CreateWebhookTargetResponse400 | CreateWebhookTargetResponse401 | CreateWebhookTargetResponse403 | CreateWebhookTargetResponse404 | CreateWebhookTargetResponse406 | CreateWebhookTargetResponse409 | CreateWebhookTargetResponse500 | None:
    """ Create webhook target

     Create a webhook target for the organization

    Args:
        org (str):
        body (CreateWebhookTargetBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CreateWebhookTargetResponse201 | CreateWebhookTargetResponse400 | CreateWebhookTargetResponse401 | CreateWebhookTargetResponse403 | CreateWebhookTargetResponse404 | CreateWebhookTargetResponse406 | CreateWebhookTargetResponse409 | CreateWebhookTargetResponse500
     """


    return sync_detailed(
        org=org,
client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    org: str,
    *,
    client: AuthenticatedClient | Client,
    body: CreateWebhookTargetBody,

) -> Response[CreateWebhookTargetResponse201 | CreateWebhookTargetResponse400 | CreateWebhookTargetResponse401 | CreateWebhookTargetResponse403 | CreateWebhookTargetResponse404 | CreateWebhookTargetResponse406 | CreateWebhookTargetResponse409 | CreateWebhookTargetResponse500]:
    """ Create webhook target

     Create a webhook target for the organization

    Args:
        org (str):
        body (CreateWebhookTargetBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CreateWebhookTargetResponse201 | CreateWebhookTargetResponse400 | CreateWebhookTargetResponse401 | CreateWebhookTargetResponse403 | CreateWebhookTargetResponse404 | CreateWebhookTargetResponse406 | CreateWebhookTargetResponse409 | CreateWebhookTargetResponse500]
     """


    kwargs = _get_kwargs(
        org=org,
body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    org: str,
    *,
    client: AuthenticatedClient | Client,
    body: CreateWebhookTargetBody,

) -> CreateWebhookTargetResponse201 | CreateWebhookTargetResponse400 | CreateWebhookTargetResponse401 | CreateWebhookTargetResponse403 | CreateWebhookTargetResponse404 | CreateWebhookTargetResponse406 | CreateWebhookTargetResponse409 | CreateWebhookTargetResponse500 | None:
    """ Create webhook target

     Create a webhook target for the organization

    Args:
        org (str):
        body (CreateWebhookTargetBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CreateWebhookTargetResponse201 | CreateWebhookTargetResponse400 | CreateWebhookTargetResponse401 | CreateWebhookTargetResponse403 | CreateWebhookTargetResponse404 | CreateWebhookTargetResponse406 | CreateWebhookTargetResponse409 | CreateWebhookTargetResponse500
     """


    return (await asyncio_detailed(
        org=org,
client=client,
body=body,

    )).parsed
