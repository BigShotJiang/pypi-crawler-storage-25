from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.list_webhook_targets_response_200 import ListWebhookTargetsResponse200
from ...models.list_webhook_targets_response_400 import ListWebhookTargetsResponse400
from ...models.list_webhook_targets_response_401 import ListWebhookTargetsResponse401
from ...models.list_webhook_targets_response_403 import ListWebhookTargetsResponse403
from ...models.list_webhook_targets_response_404 import ListWebhookTargetsResponse404
from ...models.list_webhook_targets_response_406 import ListWebhookTargetsResponse406
from ...models.list_webhook_targets_response_409 import ListWebhookTargetsResponse409
from ...models.list_webhook_targets_response_500 import ListWebhookTargetsResponse500
from ...types import UNSET, Unset
from typing import cast



def _get_kwargs(
    org: str,
    *,
    cursor: str | Unset = UNSET,
    limit: int | Unset = UNSET,

) -> dict[str, Any]:
    

    

    params: dict[str, Any] = {}

    params["cursor"] = cursor

    params["limit"] = limit


    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}


    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/{org}/webhook-targets".format(org=quote(str(org), safe=""),),
        "params": params,
    }


    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> ListWebhookTargetsResponse200 | ListWebhookTargetsResponse400 | ListWebhookTargetsResponse401 | ListWebhookTargetsResponse403 | ListWebhookTargetsResponse404 | ListWebhookTargetsResponse406 | ListWebhookTargetsResponse409 | ListWebhookTargetsResponse500 | None:
    if response.status_code == 200:
        response_200 = ListWebhookTargetsResponse200.from_dict(response.json())



        return response_200

    if response.status_code == 400:
        response_400 = ListWebhookTargetsResponse400.from_dict(response.json())



        return response_400

    if response.status_code == 401:
        response_401 = ListWebhookTargetsResponse401.from_dict(response.json())



        return response_401

    if response.status_code == 403:
        response_403 = ListWebhookTargetsResponse403.from_dict(response.json())



        return response_403

    if response.status_code == 404:
        response_404 = ListWebhookTargetsResponse404.from_dict(response.json())



        return response_404

    if response.status_code == 406:
        response_406 = ListWebhookTargetsResponse406.from_dict(response.json())



        return response_406

    if response.status_code == 409:
        response_409 = ListWebhookTargetsResponse409.from_dict(response.json())



        return response_409

    if response.status_code == 500:
        response_500 = ListWebhookTargetsResponse500.from_dict(response.json())



        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[ListWebhookTargetsResponse200 | ListWebhookTargetsResponse400 | ListWebhookTargetsResponse401 | ListWebhookTargetsResponse403 | ListWebhookTargetsResponse404 | ListWebhookTargetsResponse406 | ListWebhookTargetsResponse409 | ListWebhookTargetsResponse500]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    org: str,
    *,
    client: AuthenticatedClient | Client,
    cursor: str | Unset = UNSET,
    limit: int | Unset = UNSET,

) -> Response[ListWebhookTargetsResponse200 | ListWebhookTargetsResponse400 | ListWebhookTargetsResponse401 | ListWebhookTargetsResponse403 | ListWebhookTargetsResponse404 | ListWebhookTargetsResponse406 | ListWebhookTargetsResponse409 | ListWebhookTargetsResponse500]:
    """ List webhook targets

     List webhook targets configured for the organization

    Args:
        org (str):
        cursor (str | Unset):
        limit (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ListWebhookTargetsResponse200 | ListWebhookTargetsResponse400 | ListWebhookTargetsResponse401 | ListWebhookTargetsResponse403 | ListWebhookTargetsResponse404 | ListWebhookTargetsResponse406 | ListWebhookTargetsResponse409 | ListWebhookTargetsResponse500]
     """


    kwargs = _get_kwargs(
        org=org,
cursor=cursor,
limit=limit,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    org: str,
    *,
    client: AuthenticatedClient | Client,
    cursor: str | Unset = UNSET,
    limit: int | Unset = UNSET,

) -> ListWebhookTargetsResponse200 | ListWebhookTargetsResponse400 | ListWebhookTargetsResponse401 | ListWebhookTargetsResponse403 | ListWebhookTargetsResponse404 | ListWebhookTargetsResponse406 | ListWebhookTargetsResponse409 | ListWebhookTargetsResponse500 | None:
    """ List webhook targets

     List webhook targets configured for the organization

    Args:
        org (str):
        cursor (str | Unset):
        limit (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ListWebhookTargetsResponse200 | ListWebhookTargetsResponse400 | ListWebhookTargetsResponse401 | ListWebhookTargetsResponse403 | ListWebhookTargetsResponse404 | ListWebhookTargetsResponse406 | ListWebhookTargetsResponse409 | ListWebhookTargetsResponse500
     """


    return sync_detailed(
        org=org,
client=client,
cursor=cursor,
limit=limit,

    ).parsed

async def asyncio_detailed(
    org: str,
    *,
    client: AuthenticatedClient | Client,
    cursor: str | Unset = UNSET,
    limit: int | Unset = UNSET,

) -> Response[ListWebhookTargetsResponse200 | ListWebhookTargetsResponse400 | ListWebhookTargetsResponse401 | ListWebhookTargetsResponse403 | ListWebhookTargetsResponse404 | ListWebhookTargetsResponse406 | ListWebhookTargetsResponse409 | ListWebhookTargetsResponse500]:
    """ List webhook targets

     List webhook targets configured for the organization

    Args:
        org (str):
        cursor (str | Unset):
        limit (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ListWebhookTargetsResponse200 | ListWebhookTargetsResponse400 | ListWebhookTargetsResponse401 | ListWebhookTargetsResponse403 | ListWebhookTargetsResponse404 | ListWebhookTargetsResponse406 | ListWebhookTargetsResponse409 | ListWebhookTargetsResponse500]
     """


    kwargs = _get_kwargs(
        org=org,
cursor=cursor,
limit=limit,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    org: str,
    *,
    client: AuthenticatedClient | Client,
    cursor: str | Unset = UNSET,
    limit: int | Unset = UNSET,

) -> ListWebhookTargetsResponse200 | ListWebhookTargetsResponse400 | ListWebhookTargetsResponse401 | ListWebhookTargetsResponse403 | ListWebhookTargetsResponse404 | ListWebhookTargetsResponse406 | ListWebhookTargetsResponse409 | ListWebhookTargetsResponse500 | None:
    """ List webhook targets

     List webhook targets configured for the organization

    Args:
        org (str):
        cursor (str | Unset):
        limit (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ListWebhookTargetsResponse200 | ListWebhookTargetsResponse400 | ListWebhookTargetsResponse401 | ListWebhookTargetsResponse403 | ListWebhookTargetsResponse404 | ListWebhookTargetsResponse406 | ListWebhookTargetsResponse409 | ListWebhookTargetsResponse500
     """


    return (await asyncio_detailed(
        org=org,
client=client,
cursor=cursor,
limit=limit,

    )).parsed
