from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.get_diff_conflicts import GetDiffConflicts
from ...models.get_diff_response_200 import GetDiffResponse200
from ...models.get_diff_response_400 import GetDiffResponse400
from ...models.get_diff_response_401 import GetDiffResponse401
from ...models.get_diff_response_403 import GetDiffResponse403
from ...models.get_diff_response_404 import GetDiffResponse404
from ...models.get_diff_response_406 import GetDiffResponse406
from ...models.get_diff_response_409 import GetDiffResponse409
from ...models.get_diff_response_500 import GetDiffResponse500
from ...types import UNSET, Unset
from typing import cast



def _get_kwargs(
    org: str,
    repo: str,
    *,
    base_change_id: str,
    head_change_id: str,
    conflicts: GetDiffConflicts | Unset = GetDiffConflicts.INCLUDE,

) -> dict[str, Any]:
    

    

    params: dict[str, Any] = {}

    params["base_change_id"] = base_change_id

    params["head_change_id"] = head_change_id

    json_conflicts: str | Unset = UNSET
    if not isinstance(conflicts, Unset):
        json_conflicts = conflicts.value

    params["conflicts"] = json_conflicts


    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}


    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/{org}/{repo}/diff".format(org=quote(str(org), safe=""),repo=quote(str(repo), safe=""),),
        "params": params,
    }


    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> GetDiffResponse200 | GetDiffResponse400 | GetDiffResponse401 | GetDiffResponse403 | GetDiffResponse404 | GetDiffResponse406 | GetDiffResponse409 | GetDiffResponse500 | None:
    if response.status_code == 200:
        response_200 = GetDiffResponse200.from_dict(response.json())



        return response_200

    if response.status_code == 400:
        response_400 = GetDiffResponse400.from_dict(response.json())



        return response_400

    if response.status_code == 401:
        response_401 = GetDiffResponse401.from_dict(response.json())



        return response_401

    if response.status_code == 403:
        response_403 = GetDiffResponse403.from_dict(response.json())



        return response_403

    if response.status_code == 404:
        response_404 = GetDiffResponse404.from_dict(response.json())



        return response_404

    if response.status_code == 406:
        response_406 = GetDiffResponse406.from_dict(response.json())



        return response_406

    if response.status_code == 409:
        response_409 = GetDiffResponse409.from_dict(response.json())



        return response_409

    if response.status_code == 500:
        response_500 = GetDiffResponse500.from_dict(response.json())



        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[GetDiffResponse200 | GetDiffResponse400 | GetDiffResponse401 | GetDiffResponse403 | GetDiffResponse404 | GetDiffResponse406 | GetDiffResponse409 | GetDiffResponse500]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    org: str,
    repo: str,
    *,
    client: AuthenticatedClient | Client,
    base_change_id: str,
    head_change_id: str,
    conflicts: GetDiffConflicts | Unset = GetDiffConflicts.INCLUDE,

) -> Response[GetDiffResponse200 | GetDiffResponse400 | GetDiffResponse401 | GetDiffResponse403 | GetDiffResponse404 | GetDiffResponse406 | GetDiffResponse409 | GetDiffResponse500]:
    """ Get diff

     Retrieve the diff between two change ids. In the JSON response, conflicted paths are excluded from
    `entries[]` and surface only in `conflicted_entries[]` (with per-side target/base/source content);
    the two arrays are mutually exclusive. When the client requests `Accept: text/plain`, the response
    is a full unified patch that includes every changed path, with conflicted paths rendered inline
    using JJ-style `<<<<<<<` / `>>>>>>>` markers.

    Args:
        org (str):
        repo (str):
        base_change_id (str):
        head_change_id (str):
        conflicts (GetDiffConflicts | Unset):  Default: GetDiffConflicts.INCLUDE.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetDiffResponse200 | GetDiffResponse400 | GetDiffResponse401 | GetDiffResponse403 | GetDiffResponse404 | GetDiffResponse406 | GetDiffResponse409 | GetDiffResponse500]
     """


    kwargs = _get_kwargs(
        org=org,
repo=repo,
base_change_id=base_change_id,
head_change_id=head_change_id,
conflicts=conflicts,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    org: str,
    repo: str,
    *,
    client: AuthenticatedClient | Client,
    base_change_id: str,
    head_change_id: str,
    conflicts: GetDiffConflicts | Unset = GetDiffConflicts.INCLUDE,

) -> GetDiffResponse200 | GetDiffResponse400 | GetDiffResponse401 | GetDiffResponse403 | GetDiffResponse404 | GetDiffResponse406 | GetDiffResponse409 | GetDiffResponse500 | None:
    """ Get diff

     Retrieve the diff between two change ids. In the JSON response, conflicted paths are excluded from
    `entries[]` and surface only in `conflicted_entries[]` (with per-side target/base/source content);
    the two arrays are mutually exclusive. When the client requests `Accept: text/plain`, the response
    is a full unified patch that includes every changed path, with conflicted paths rendered inline
    using JJ-style `<<<<<<<` / `>>>>>>>` markers.

    Args:
        org (str):
        repo (str):
        base_change_id (str):
        head_change_id (str):
        conflicts (GetDiffConflicts | Unset):  Default: GetDiffConflicts.INCLUDE.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetDiffResponse200 | GetDiffResponse400 | GetDiffResponse401 | GetDiffResponse403 | GetDiffResponse404 | GetDiffResponse406 | GetDiffResponse409 | GetDiffResponse500
     """


    return sync_detailed(
        org=org,
repo=repo,
client=client,
base_change_id=base_change_id,
head_change_id=head_change_id,
conflicts=conflicts,

    ).parsed

async def asyncio_detailed(
    org: str,
    repo: str,
    *,
    client: AuthenticatedClient | Client,
    base_change_id: str,
    head_change_id: str,
    conflicts: GetDiffConflicts | Unset = GetDiffConflicts.INCLUDE,

) -> Response[GetDiffResponse200 | GetDiffResponse400 | GetDiffResponse401 | GetDiffResponse403 | GetDiffResponse404 | GetDiffResponse406 | GetDiffResponse409 | GetDiffResponse500]:
    """ Get diff

     Retrieve the diff between two change ids. In the JSON response, conflicted paths are excluded from
    `entries[]` and surface only in `conflicted_entries[]` (with per-side target/base/source content);
    the two arrays are mutually exclusive. When the client requests `Accept: text/plain`, the response
    is a full unified patch that includes every changed path, with conflicted paths rendered inline
    using JJ-style `<<<<<<<` / `>>>>>>>` markers.

    Args:
        org (str):
        repo (str):
        base_change_id (str):
        head_change_id (str):
        conflicts (GetDiffConflicts | Unset):  Default: GetDiffConflicts.INCLUDE.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetDiffResponse200 | GetDiffResponse400 | GetDiffResponse401 | GetDiffResponse403 | GetDiffResponse404 | GetDiffResponse406 | GetDiffResponse409 | GetDiffResponse500]
     """


    kwargs = _get_kwargs(
        org=org,
repo=repo,
base_change_id=base_change_id,
head_change_id=head_change_id,
conflicts=conflicts,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    org: str,
    repo: str,
    *,
    client: AuthenticatedClient | Client,
    base_change_id: str,
    head_change_id: str,
    conflicts: GetDiffConflicts | Unset = GetDiffConflicts.INCLUDE,

) -> GetDiffResponse200 | GetDiffResponse400 | GetDiffResponse401 | GetDiffResponse403 | GetDiffResponse404 | GetDiffResponse406 | GetDiffResponse409 | GetDiffResponse500 | None:
    """ Get diff

     Retrieve the diff between two change ids. In the JSON response, conflicted paths are excluded from
    `entries[]` and surface only in `conflicted_entries[]` (with per-side target/base/source content);
    the two arrays are mutually exclusive. When the client requests `Accept: text/plain`, the response
    is a full unified patch that includes every changed path, with conflicted paths rendered inline
    using JJ-style `<<<<<<<` / `>>>>>>>` markers.

    Args:
        org (str):
        repo (str):
        base_change_id (str):
        head_change_id (str):
        conflicts (GetDiffConflicts | Unset):  Default: GetDiffConflicts.INCLUDE.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetDiffResponse200 | GetDiffResponse400 | GetDiffResponse401 | GetDiffResponse403 | GetDiffResponse404 | GetDiffResponse406 | GetDiffResponse409 | GetDiffResponse500
     """


    return (await asyncio_detailed(
        org=org,
repo=repo,
client=client,
base_change_id=base_change_id,
head_change_id=head_change_id,
conflicts=conflicts,

    )).parsed
