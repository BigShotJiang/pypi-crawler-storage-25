from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.update_change_body import UpdateChangeBody
from ...models.update_change_response_200 import UpdateChangeResponse200
from ...models.update_change_response_400 import UpdateChangeResponse400
from ...models.update_change_response_401 import UpdateChangeResponse401
from ...models.update_change_response_403 import UpdateChangeResponse403
from ...models.update_change_response_404 import UpdateChangeResponse404
from ...models.update_change_response_406 import UpdateChangeResponse406
from ...models.update_change_response_409 import UpdateChangeResponse409
from ...models.update_change_response_500 import UpdateChangeResponse500
from typing import cast



def _get_kwargs(
    org: str,
    repo: str,
    change_id: str,
    *,
    body: UpdateChangeBody,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "patch",
        "url": "/{org}/{repo}/changes/{change_id}".format(org=quote(str(org), safe=""),repo=quote(str(repo), safe=""),change_id=quote(str(change_id), safe=""),),
    }

    _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> UpdateChangeResponse200 | UpdateChangeResponse400 | UpdateChangeResponse401 | UpdateChangeResponse403 | UpdateChangeResponse404 | UpdateChangeResponse406 | UpdateChangeResponse409 | UpdateChangeResponse500 | None:
    if response.status_code == 200:
        response_200 = UpdateChangeResponse200.from_dict(response.json())



        return response_200

    if response.status_code == 400:
        response_400 = UpdateChangeResponse400.from_dict(response.json())



        return response_400

    if response.status_code == 401:
        response_401 = UpdateChangeResponse401.from_dict(response.json())



        return response_401

    if response.status_code == 403:
        response_403 = UpdateChangeResponse403.from_dict(response.json())



        return response_403

    if response.status_code == 404:
        response_404 = UpdateChangeResponse404.from_dict(response.json())



        return response_404

    if response.status_code == 406:
        response_406 = UpdateChangeResponse406.from_dict(response.json())



        return response_406

    if response.status_code == 409:
        response_409 = UpdateChangeResponse409.from_dict(response.json())



        return response_409

    if response.status_code == 500:
        response_500 = UpdateChangeResponse500.from_dict(response.json())



        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[UpdateChangeResponse200 | UpdateChangeResponse400 | UpdateChangeResponse401 | UpdateChangeResponse403 | UpdateChangeResponse404 | UpdateChangeResponse406 | UpdateChangeResponse409 | UpdateChangeResponse500]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    org: str,
    repo: str,
    change_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateChangeBody,

) -> Response[UpdateChangeResponse200 | UpdateChangeResponse400 | UpdateChangeResponse401 | UpdateChangeResponse403 | UpdateChangeResponse404 | UpdateChangeResponse406 | UpdateChangeResponse409 | UpdateChangeResponse500]:
    """ Patch change

     Patch an existing change by updating metadata and/or applying file operations, then snapshot the
    result into a new change-owned commit. File content must be base64-encoded. When the change is
    conflicted, `files` writes are refused; submit a `resolutions` array instead to incrementally
    resolve conflicts — when every contested path is resolved the change becomes clean. `files` and
    `resolutions` are mutually exclusive on a single PATCH. A PATCH on a conflicted change without
    `resolutions` returns 409 MERGE_CONFLICT with a `details.conflict_paths` array listing the still-
    conflicted paths.

    Args:
        org (str):
        repo (str):
        change_id (str):
        body (UpdateChangeBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[UpdateChangeResponse200 | UpdateChangeResponse400 | UpdateChangeResponse401 | UpdateChangeResponse403 | UpdateChangeResponse404 | UpdateChangeResponse406 | UpdateChangeResponse409 | UpdateChangeResponse500]
     """


    kwargs = _get_kwargs(
        org=org,
repo=repo,
change_id=change_id,
body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    org: str,
    repo: str,
    change_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateChangeBody,

) -> UpdateChangeResponse200 | UpdateChangeResponse400 | UpdateChangeResponse401 | UpdateChangeResponse403 | UpdateChangeResponse404 | UpdateChangeResponse406 | UpdateChangeResponse409 | UpdateChangeResponse500 | None:
    """ Patch change

     Patch an existing change by updating metadata and/or applying file operations, then snapshot the
    result into a new change-owned commit. File content must be base64-encoded. When the change is
    conflicted, `files` writes are refused; submit a `resolutions` array instead to incrementally
    resolve conflicts — when every contested path is resolved the change becomes clean. `files` and
    `resolutions` are mutually exclusive on a single PATCH. A PATCH on a conflicted change without
    `resolutions` returns 409 MERGE_CONFLICT with a `details.conflict_paths` array listing the still-
    conflicted paths.

    Args:
        org (str):
        repo (str):
        change_id (str):
        body (UpdateChangeBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        UpdateChangeResponse200 | UpdateChangeResponse400 | UpdateChangeResponse401 | UpdateChangeResponse403 | UpdateChangeResponse404 | UpdateChangeResponse406 | UpdateChangeResponse409 | UpdateChangeResponse500
     """


    return sync_detailed(
        org=org,
repo=repo,
change_id=change_id,
client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    org: str,
    repo: str,
    change_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateChangeBody,

) -> Response[UpdateChangeResponse200 | UpdateChangeResponse400 | UpdateChangeResponse401 | UpdateChangeResponse403 | UpdateChangeResponse404 | UpdateChangeResponse406 | UpdateChangeResponse409 | UpdateChangeResponse500]:
    """ Patch change

     Patch an existing change by updating metadata and/or applying file operations, then snapshot the
    result into a new change-owned commit. File content must be base64-encoded. When the change is
    conflicted, `files` writes are refused; submit a `resolutions` array instead to incrementally
    resolve conflicts — when every contested path is resolved the change becomes clean. `files` and
    `resolutions` are mutually exclusive on a single PATCH. A PATCH on a conflicted change without
    `resolutions` returns 409 MERGE_CONFLICT with a `details.conflict_paths` array listing the still-
    conflicted paths.

    Args:
        org (str):
        repo (str):
        change_id (str):
        body (UpdateChangeBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[UpdateChangeResponse200 | UpdateChangeResponse400 | UpdateChangeResponse401 | UpdateChangeResponse403 | UpdateChangeResponse404 | UpdateChangeResponse406 | UpdateChangeResponse409 | UpdateChangeResponse500]
     """


    kwargs = _get_kwargs(
        org=org,
repo=repo,
change_id=change_id,
body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    org: str,
    repo: str,
    change_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateChangeBody,

) -> UpdateChangeResponse200 | UpdateChangeResponse400 | UpdateChangeResponse401 | UpdateChangeResponse403 | UpdateChangeResponse404 | UpdateChangeResponse406 | UpdateChangeResponse409 | UpdateChangeResponse500 | None:
    """ Patch change

     Patch an existing change by updating metadata and/or applying file operations, then snapshot the
    result into a new change-owned commit. File content must be base64-encoded. When the change is
    conflicted, `files` writes are refused; submit a `resolutions` array instead to incrementally
    resolve conflicts — when every contested path is resolved the change becomes clean. `files` and
    `resolutions` are mutually exclusive on a single PATCH. A PATCH on a conflicted change without
    `resolutions` returns 409 MERGE_CONFLICT with a `details.conflict_paths` array listing the still-
    conflicted paths.

    Args:
        org (str):
        repo (str):
        change_id (str):
        body (UpdateChangeBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        UpdateChangeResponse200 | UpdateChangeResponse400 | UpdateChangeResponse401 | UpdateChangeResponse403 | UpdateChangeResponse404 | UpdateChangeResponse406 | UpdateChangeResponse409 | UpdateChangeResponse500
     """


    return (await asyncio_detailed(
        org=org,
repo=repo,
change_id=change_id,
client=client,
body=body,

    )).parsed
