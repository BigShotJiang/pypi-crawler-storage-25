from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.get_diff_response_200_conflicted_entries_item import GetDiffResponse200ConflictedEntriesItem
  from ..models.get_diff_response_200_entries_item import GetDiffResponse200EntriesItem
  from ..models.get_diff_response_200_stats import GetDiffResponse200Stats





T = TypeVar("T", bound="GetDiffResponse200")



@_attrs_define
class GetDiffResponse200:
    """ 
        Attributes:
            base_change_id (str):
            head_change_id (str):
            stats (GetDiffResponse200Stats):
            truncated (bool): True when the response hit the server entry limit and is incomplete
            entries (list[GetDiffResponse200EntriesItem]): Changed entries only. Unchanged paths are omitted from this list
            conflicted_entries (list[GetDiffResponse200ConflictedEntriesItem]):
     """

    base_change_id: str
    head_change_id: str
    stats: GetDiffResponse200Stats
    truncated: bool
    entries: list[GetDiffResponse200EntriesItem]
    conflicted_entries: list[GetDiffResponse200ConflictedEntriesItem]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.get_diff_response_200_conflicted_entries_item import GetDiffResponse200ConflictedEntriesItem
        from ..models.get_diff_response_200_stats import GetDiffResponse200Stats
        from ..models.get_diff_response_200_entries_item import GetDiffResponse200EntriesItem
        base_change_id = self.base_change_id

        head_change_id = self.head_change_id

        stats = self.stats.to_dict()

        truncated = self.truncated

        entries = []
        for entries_item_data in self.entries:
            entries_item = entries_item_data.to_dict()
            entries.append(entries_item)



        conflicted_entries = []
        for conflicted_entries_item_data in self.conflicted_entries:
            conflicted_entries_item = conflicted_entries_item_data.to_dict()
            conflicted_entries.append(conflicted_entries_item)




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "base_change_id": base_change_id,
            "head_change_id": head_change_id,
            "stats": stats,
            "truncated": truncated,
            "entries": entries,
            "conflicted_entries": conflicted_entries,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.get_diff_response_200_conflicted_entries_item import GetDiffResponse200ConflictedEntriesItem
        from ..models.get_diff_response_200_entries_item import GetDiffResponse200EntriesItem
        from ..models.get_diff_response_200_stats import GetDiffResponse200Stats
        d = dict(src_dict)
        base_change_id = d.pop("base_change_id")

        head_change_id = d.pop("head_change_id")

        stats = GetDiffResponse200Stats.from_dict(d.pop("stats"))




        truncated = d.pop("truncated")

        entries = []
        _entries = d.pop("entries")
        for entries_item_data in (_entries):
            entries_item = GetDiffResponse200EntriesItem.from_dict(entries_item_data)



            entries.append(entries_item)


        conflicted_entries = []
        _conflicted_entries = d.pop("conflicted_entries")
        for conflicted_entries_item_data in (_conflicted_entries):
            conflicted_entries_item = GetDiffResponse200ConflictedEntriesItem.from_dict(conflicted_entries_item_data)



            conflicted_entries.append(conflicted_entries_item)


        get_diff_response_200 = cls(
            base_change_id=base_change_id,
            head_change_id=head_change_id,
            stats=stats,
            truncated=truncated,
            entries=entries,
            conflicted_entries=conflicted_entries,
        )


        get_diff_response_200.additional_properties = d
        return get_diff_response_200

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
