from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from dateutil.parser import isoparse
from typing import cast
import datetime

if TYPE_CHECKING:
  from ..models.get_change_response_200_author import GetChangeResponse200Author
  from ..models.get_change_response_200_committer import GetChangeResponse200Committer





T = TypeVar("T", bound="GetChangeResponse200")



@_attrs_define
class GetChangeResponse200:
    """ 
        Attributes:
            id (str):
            current_commit_oid (str):
            is_conflicted (bool): True when the change current commit still contains unresolved conflicts
            message (str):
            author (GetChangeResponse200Author):
            committer (GetChangeResponse200Committer):
            parents (list[str]):
            created_at (datetime.datetime):
            updated_at (datetime.datetime):
            files (list[str]):
            conflicts (list[str]):
     """

    id: str
    current_commit_oid: str
    is_conflicted: bool
    message: str
    author: GetChangeResponse200Author
    committer: GetChangeResponse200Committer
    parents: list[str]
    created_at: datetime.datetime
    updated_at: datetime.datetime
    files: list[str]
    conflicts: list[str]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.get_change_response_200_author import GetChangeResponse200Author
        from ..models.get_change_response_200_committer import GetChangeResponse200Committer
        id = self.id

        current_commit_oid = self.current_commit_oid

        is_conflicted = self.is_conflicted

        message = self.message

        author = self.author.to_dict()

        committer = self.committer.to_dict()

        parents = self.parents



        created_at = self.created_at.isoformat()

        updated_at = self.updated_at.isoformat()

        files = self.files



        conflicts = self.conflicts




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "current_commit_oid": current_commit_oid,
            "is_conflicted": is_conflicted,
            "message": message,
            "author": author,
            "committer": committer,
            "parents": parents,
            "created_at": created_at,
            "updated_at": updated_at,
            "files": files,
            "conflicts": conflicts,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.get_change_response_200_author import GetChangeResponse200Author
        from ..models.get_change_response_200_committer import GetChangeResponse200Committer
        d = dict(src_dict)
        id = d.pop("id")

        current_commit_oid = d.pop("current_commit_oid")

        is_conflicted = d.pop("is_conflicted")

        message = d.pop("message")

        author = GetChangeResponse200Author.from_dict(d.pop("author"))




        committer = GetChangeResponse200Committer.from_dict(d.pop("committer"))




        parents = cast(list[str], d.pop("parents"))


        created_at = isoparse(d.pop("created_at"))




        updated_at = isoparse(d.pop("updated_at"))




        files = cast(list[str], d.pop("files"))


        conflicts = cast(list[str], d.pop("conflicts"))


        get_change_response_200 = cls(
            id=id,
            current_commit_oid=current_commit_oid,
            is_conflicted=is_conflicted,
            message=message,
            author=author,
            committer=committer,
            parents=parents,
            created_at=created_at,
            updated_at=updated_at,
            files=files,
            conflicts=conflicts,
        )


        get_change_response_200.additional_properties = d
        return get_change_response_200

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
