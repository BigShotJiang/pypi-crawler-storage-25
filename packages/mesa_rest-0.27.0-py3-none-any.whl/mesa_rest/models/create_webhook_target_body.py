from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.create_webhook_target_body_events_item import CreateWebhookTargetBodyEventsItem
from ..types import UNSET, Unset
from typing import cast






T = TypeVar("T", bound="CreateWebhookTargetBody")



@_attrs_define
class CreateWebhookTargetBody:
    """ 
        Attributes:
            url (str):
            name (str | Unset):
            events (list[CreateWebhookTargetBodyEventsItem] | Unset):
            repo_ids (list[str] | Unset):
     """

    url: str
    name: str | Unset = UNSET
    events: list[CreateWebhookTargetBodyEventsItem] | Unset = UNSET
    repo_ids: list[str] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        url = self.url

        name = self.name

        events: list[str] | Unset = UNSET
        if not isinstance(self.events, Unset):
            events = []
            for events_item_data in self.events:
                events_item = events_item_data.value
                events.append(events_item)



        repo_ids: list[str] | Unset = UNSET
        if not isinstance(self.repo_ids, Unset):
            repo_ids = self.repo_ids




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "url": url,
        })
        if name is not UNSET:
            field_dict["name"] = name
        if events is not UNSET:
            field_dict["events"] = events
        if repo_ids is not UNSET:
            field_dict["repo_ids"] = repo_ids

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        url = d.pop("url")

        name = d.pop("name", UNSET)

        _events = d.pop("events", UNSET)
        events: list[CreateWebhookTargetBodyEventsItem] | Unset = UNSET
        if _events is not UNSET:
            events = []
            for events_item_data in _events:
                events_item = CreateWebhookTargetBodyEventsItem(events_item_data)



                events.append(events_item)


        repo_ids = cast(list[str], d.pop("repo_ids", UNSET))


        create_webhook_target_body = cls(
            url=url,
            name=name,
            events=events,
            repo_ids=repo_ids,
        )


        create_webhook_target_body.additional_properties = d
        return create_webhook_target_body

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
