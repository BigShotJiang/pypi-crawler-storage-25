from enum import Enum

class CreateWebhookTargetResponse201EventsItem(str, Enum):
    BOOKMARK_CREATED = "bookmark.created"
    BOOKMARK_DELETED = "bookmark.deleted"
    BOOKMARK_MERGED = "bookmark.merged"
    BOOKMARK_MOVED = "bookmark.moved"
    CHANGE_CREATED = "change.created"
    CHANGE_EVOLVED = "change.evolved"
    PUSH = "push"
    REPO_CREATED = "repo.created"
    REPO_DELETED = "repo.deleted"
    REPO_UPDATED = "repo.updated"

    def __str__(self) -> str:
        return str(self.value)
