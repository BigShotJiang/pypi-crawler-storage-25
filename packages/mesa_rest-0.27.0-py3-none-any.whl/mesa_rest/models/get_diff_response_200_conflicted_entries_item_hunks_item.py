from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.get_diff_response_200_conflicted_entries_item_hunks_item_base_type_0 import GetDiffResponse200ConflictedEntriesItemHunksItemBaseType0
  from ..models.get_diff_response_200_conflicted_entries_item_hunks_item_source_type_0 import GetDiffResponse200ConflictedEntriesItemHunksItemSourceType0
  from ..models.get_diff_response_200_conflicted_entries_item_hunks_item_target_type_0 import GetDiffResponse200ConflictedEntriesItemHunksItemTargetType0





T = TypeVar("T", bound="GetDiffResponse200ConflictedEntriesItemHunksItem")



@_attrs_define
class GetDiffResponse200ConflictedEntriesItemHunksItem:
    """ 
        Attributes:
            hunk_id (str):
            old_start (float):
            old_lines (float):
            new_start (float):
            new_lines (float):
            target (GetDiffResponse200ConflictedEntriesItemHunksItemTargetType0 | None):
            base (GetDiffResponse200ConflictedEntriesItemHunksItemBaseType0 | None):
            source (GetDiffResponse200ConflictedEntriesItemHunksItemSourceType0 | None):
     """

    hunk_id: str
    old_start: float
    old_lines: float
    new_start: float
    new_lines: float
    target: GetDiffResponse200ConflictedEntriesItemHunksItemTargetType0 | None
    base: GetDiffResponse200ConflictedEntriesItemHunksItemBaseType0 | None
    source: GetDiffResponse200ConflictedEntriesItemHunksItemSourceType0 | None
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.get_diff_response_200_conflicted_entries_item_hunks_item_target_type_0 import GetDiffResponse200ConflictedEntriesItemHunksItemTargetType0
        from ..models.get_diff_response_200_conflicted_entries_item_hunks_item_source_type_0 import GetDiffResponse200ConflictedEntriesItemHunksItemSourceType0
        from ..models.get_diff_response_200_conflicted_entries_item_hunks_item_base_type_0 import GetDiffResponse200ConflictedEntriesItemHunksItemBaseType0
        hunk_id = self.hunk_id

        old_start = self.old_start

        old_lines = self.old_lines

        new_start = self.new_start

        new_lines = self.new_lines

        target: dict[str, Any] | None
        if isinstance(self.target, GetDiffResponse200ConflictedEntriesItemHunksItemTargetType0):
            target = self.target.to_dict()
        else:
            target = self.target

        base: dict[str, Any] | None
        if isinstance(self.base, GetDiffResponse200ConflictedEntriesItemHunksItemBaseType0):
            base = self.base.to_dict()
        else:
            base = self.base

        source: dict[str, Any] | None
        if isinstance(self.source, GetDiffResponse200ConflictedEntriesItemHunksItemSourceType0):
            source = self.source.to_dict()
        else:
            source = self.source


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "hunk_id": hunk_id,
            "old_start": old_start,
            "old_lines": old_lines,
            "new_start": new_start,
            "new_lines": new_lines,
            "target": target,
            "base": base,
            "source": source,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.get_diff_response_200_conflicted_entries_item_hunks_item_base_type_0 import GetDiffResponse200ConflictedEntriesItemHunksItemBaseType0
        from ..models.get_diff_response_200_conflicted_entries_item_hunks_item_source_type_0 import GetDiffResponse200ConflictedEntriesItemHunksItemSourceType0
        from ..models.get_diff_response_200_conflicted_entries_item_hunks_item_target_type_0 import GetDiffResponse200ConflictedEntriesItemHunksItemTargetType0
        d = dict(src_dict)
        hunk_id = d.pop("hunk_id")

        old_start = d.pop("old_start")

        old_lines = d.pop("old_lines")

        new_start = d.pop("new_start")

        new_lines = d.pop("new_lines")

        def _parse_target(data: object) -> GetDiffResponse200ConflictedEntriesItemHunksItemTargetType0 | None:
            if data is None:
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                target_type_0 = GetDiffResponse200ConflictedEntriesItemHunksItemTargetType0.from_dict(data)



                return target_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(GetDiffResponse200ConflictedEntriesItemHunksItemTargetType0 | None, data)

        target = _parse_target(d.pop("target"))


        def _parse_base(data: object) -> GetDiffResponse200ConflictedEntriesItemHunksItemBaseType0 | None:
            if data is None:
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                base_type_0 = GetDiffResponse200ConflictedEntriesItemHunksItemBaseType0.from_dict(data)



                return base_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(GetDiffResponse200ConflictedEntriesItemHunksItemBaseType0 | None, data)

        base = _parse_base(d.pop("base"))


        def _parse_source(data: object) -> GetDiffResponse200ConflictedEntriesItemHunksItemSourceType0 | None:
            if data is None:
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                source_type_0 = GetDiffResponse200ConflictedEntriesItemHunksItemSourceType0.from_dict(data)



                return source_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(GetDiffResponse200ConflictedEntriesItemHunksItemSourceType0 | None, data)

        source = _parse_source(d.pop("source"))


        get_diff_response_200_conflicted_entries_item_hunks_item = cls(
            hunk_id=hunk_id,
            old_start=old_start,
            old_lines=old_lines,
            new_start=new_start,
            new_lines=new_lines,
            target=target,
            base=base,
            source=source,
        )


        get_diff_response_200_conflicted_entries_item_hunks_item.additional_properties = d
        return get_diff_response_200_conflicted_entries_item_hunks_item

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
