from enum import Enum

class GetDiffConflicts(str, Enum):
    EXCLUDE = "exclude"
    INCLUDE = "include"
    ONLY = "only"

    def __str__(self) -> str:
        return str(self.value)
