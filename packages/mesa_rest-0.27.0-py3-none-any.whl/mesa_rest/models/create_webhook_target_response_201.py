from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.create_webhook_target_response_201_events_item import CreateWebhookTargetResponse201EventsItem
from dateutil.parser import isoparse
from typing import cast
import datetime






T = TypeVar("T", bound="CreateWebhookTargetResponse201")



@_attrs_define
class CreateWebhookTargetResponse201:
    """ 
        Attributes:
            id (str):
            name (None | str):
            url (str):
            events (list[CreateWebhookTargetResponse201EventsItem]):
            repo_ids (list[str] | None):
            created_at (datetime.datetime):
            updated_at (datetime.datetime):
            secret (str):
     """

    id: str
    name: None | str
    url: str
    events: list[CreateWebhookTargetResponse201EventsItem]
    repo_ids: list[str] | None
    created_at: datetime.datetime
    updated_at: datetime.datetime
    secret: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        id = self.id

        name: None | str
        name = self.name

        url = self.url

        events = []
        for events_item_data in self.events:
            events_item = events_item_data.value
            events.append(events_item)



        repo_ids: list[str] | None
        if isinstance(self.repo_ids, list):
            repo_ids = self.repo_ids


        else:
            repo_ids = self.repo_ids

        created_at = self.created_at.isoformat()

        updated_at = self.updated_at.isoformat()

        secret = self.secret


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "name": name,
            "url": url,
            "events": events,
            "repo_ids": repo_ids,
            "created_at": created_at,
            "updated_at": updated_at,
            "secret": secret,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = d.pop("id")

        def _parse_name(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        name = _parse_name(d.pop("name"))


        url = d.pop("url")

        events = []
        _events = d.pop("events")
        for events_item_data in (_events):
            events_item = CreateWebhookTargetResponse201EventsItem(events_item_data)



            events.append(events_item)


        def _parse_repo_ids(data: object) -> list[str] | None:
            if data is None:
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                repo_ids_type_0 = cast(list[str], data)

                return repo_ids_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[str] | None, data)

        repo_ids = _parse_repo_ids(d.pop("repo_ids"))


        created_at = isoparse(d.pop("created_at"))




        updated_at = isoparse(d.pop("updated_at"))




        secret = d.pop("secret")

        create_webhook_target_response_201 = cls(
            id=id,
            name=name,
            url=url,
            events=events,
            repo_ids=repo_ids,
            created_at=created_at,
            updated_at=updated_at,
            secret=secret,
        )


        create_webhook_target_response_201.additional_properties = d
        return create_webhook_target_response_201

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
