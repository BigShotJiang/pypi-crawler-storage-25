from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.get_diff_response_200_conflicted_entries_item_omitted_reason_type_0 import GetDiffResponse200ConflictedEntriesItemOmittedReasonType0
from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.get_diff_response_200_conflicted_entries_item_hunks_item import GetDiffResponse200ConflictedEntriesItemHunksItem





T = TypeVar("T", bound="GetDiffResponse200ConflictedEntriesItem")



@_attrs_define
class GetDiffResponse200ConflictedEntriesItem:
    """ 
        Attributes:
            path (str):
            hunks (list[GetDiffResponse200ConflictedEntriesItemHunksItem]): Per-hunk conflict detail. Empty when
                omitted_reason is set or the conflict is non-textual (add/delete).
            size_bytes (float | Unset): Approximate size in bytes of the largest side of the conflict. Informational when
                omitted_reason is set.
            omitted_reason (GetDiffResponse200ConflictedEntriesItemOmittedReasonType0 | None | Unset): Why hunks are
                unavailable for this conflicted entry: binary content or per-side content exceeded the response size budget.
                When set, fetch file bytes via GET /content against the target or source change to compose a whole-file
                resolution.
     """

    path: str
    hunks: list[GetDiffResponse200ConflictedEntriesItemHunksItem]
    size_bytes: float | Unset = UNSET
    omitted_reason: GetDiffResponse200ConflictedEntriesItemOmittedReasonType0 | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.get_diff_response_200_conflicted_entries_item_hunks_item import GetDiffResponse200ConflictedEntriesItemHunksItem
        path = self.path

        hunks = []
        for hunks_item_data in self.hunks:
            hunks_item = hunks_item_data.to_dict()
            hunks.append(hunks_item)



        size_bytes = self.size_bytes

        omitted_reason: None | str | Unset
        if isinstance(self.omitted_reason, Unset):
            omitted_reason = UNSET
        elif isinstance(self.omitted_reason, GetDiffResponse200ConflictedEntriesItemOmittedReasonType0):
            omitted_reason = self.omitted_reason.value
        else:
            omitted_reason = self.omitted_reason


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "path": path,
            "hunks": hunks,
        })
        if size_bytes is not UNSET:
            field_dict["size_bytes"] = size_bytes
        if omitted_reason is not UNSET:
            field_dict["omitted_reason"] = omitted_reason

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.get_diff_response_200_conflicted_entries_item_hunks_item import GetDiffResponse200ConflictedEntriesItemHunksItem
        d = dict(src_dict)
        path = d.pop("path")

        hunks = []
        _hunks = d.pop("hunks")
        for hunks_item_data in (_hunks):
            hunks_item = GetDiffResponse200ConflictedEntriesItemHunksItem.from_dict(hunks_item_data)



            hunks.append(hunks_item)


        size_bytes = d.pop("size_bytes", UNSET)

        def _parse_omitted_reason(data: object) -> GetDiffResponse200ConflictedEntriesItemOmittedReasonType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                omitted_reason_type_0 = GetDiffResponse200ConflictedEntriesItemOmittedReasonType0(data)



                return omitted_reason_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(GetDiffResponse200ConflictedEntriesItemOmittedReasonType0 | None | Unset, data)

        omitted_reason = _parse_omitted_reason(d.pop("omitted_reason", UNSET))


        get_diff_response_200_conflicted_entries_item = cls(
            path=path,
            hunks=hunks,
            size_bytes=size_bytes,
            omitted_reason=omitted_reason,
        )


        get_diff_response_200_conflicted_entries_item.additional_properties = d
        return get_diff_response_200_conflicted_entries_item

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
