from enum import Enum

class GetDiffResponse200ConflictedEntriesItemOmittedReasonType0(str, Enum):
    BINARY = "binary"
    TOO_LARGE = "too_large"

    def __str__(self) -> str:
        return str(self.value)
