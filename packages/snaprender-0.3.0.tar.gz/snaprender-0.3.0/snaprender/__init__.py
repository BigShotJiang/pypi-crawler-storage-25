"""Official Python SDK for SnapRender Screenshot API."""

from .client import SnapRender, SnapRenderError

__all__ = ["SnapRender", "SnapRenderError"]
__version__ = "0.3.0"
