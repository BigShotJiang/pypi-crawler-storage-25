#Exp2

import tensorflow as tf

vector_a = tf.constant([1, 2, 3], dtype=tf.int32)
vector_b = tf.constant([4, 5, 6], dtype=tf.int32)

vector_sum = tf.add(vector_a, vector_b)

print("Vector A", vector_a.numpy())
print("Vector B", vector_b.numpy())
print("Vector Addition Result (Keras)", vector_sum.numpy())


#exp3

import numpy as np
from sklearn.datasets import make_classification
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from tensorflow.keras import Sequential, Input
from tensorflow.keras.layers import Dense
import matplotlib.pyplot as plt

X, y = make_classification(n_samples=1000, n_features=20, n_informative=15, random_state=42)

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)

scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

def build(act):
    model = Sequential([
        Input(shape=(20,)),
        Dense(32, activation=act),
        Dense(16, activation=act),
        Dense(1, activation='sigmoid')
    ])
    model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])
    return model

acts = ['sigmoid', 'tanh', 'relu']
hist = {}

for a in acts:
    hist[a] = build(a).fit(
        X_train, y_train,
        epochs=30,
        batch_size=32,
        validation_data=(X_test, y_test),
        verbose=0
    )

for a in acts:
    plt.plot(hist[a].history['val_accuracy'], label=a)

plt.xlabel("Epochs")
plt.ylabel("Validation Accuracy")
plt.title("Activation Function Comparison")
plt.legend()
plt.grid()
plt.show()

for a in acts:
    print(a, round(hist[a].history['val_accuracy'][-1], 4))


#exp4

import numpy as np
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from tensorflow.keras import Sequential
from tensorflow.keras.layers import Dense

X, y = load_iris(return_X_y=True)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)

X_train = StandardScaler().fit_transform(X_train)
X_test = StandardScaler().fit_transform(X_test)

model = Sequential([
    Dense(8, activation='relu', input_shape=(4,)),
    Dense(3, activation='softmax')
])

model.compile(optimizer='adam', loss='sparse_categorical_crossentropy', metrics=['accuracy'])

model.fit(X_train, y_train, epochs=50, verbose=0)

print("Accuracy:", model.evaluate(X_test, y_test, verbose=0)[1])


#exp5

import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers
import matplotlib.pyplot as plt

(X_train, y_train), (X_test, y_test) = keras.datasets.mnist.load_data()

X_train = X_train / 255.0
X_test = X_test / 255.0

X_train = X_train.reshape(-1, 28, 28, 1)
X_test = X_test.reshape(-1, 28, 28, 1)

model = keras.Sequential([
    layers.Conv2D(32, (3,3), activation='relu', input_shape=(28,28,1)),
    layers.MaxPooling2D((2,2)),
    layers.Conv2D(64, (3,3), activation='relu'),
    layers.MaxPooling2D((2,2)),
    layers.Flatten(),
    layers.Dense(64, activation='relu'),
    layers.Dense(10, activation='softmax')
])

model.compile(
    optimizer='adam',
    loss='sparse_categorical_crossentropy',
    metrics=['accuracy']
)

history = model.fit(X_train, y_train, epochs=5, validation_split=0.2)

test_loss, test_acc = model.evaluate(X_test, y_test)
print("Test Accuracy:", test_acc)


#exp6

from tensorflow import keras
from tensorflow.keras import layers, Input
import keras_tuner as kt
import numpy as np

(x_train,y_train),(x_test,y_test)=keras.datasets.mnist.load_data()

x_train = np.array(x_train, dtype=np.float32)/255.0
x_test  = np.array(x_test, dtype=np.float32)/255.0
y_train = np.array(y_train, dtype=np.int32)
y_test  = np.array(y_test, dtype=np.int32)

x_train,x_test=x_train.reshape(-1,784),x_test.reshape(-1,784)

def build(hp):
    m=keras.Sequential([Input(shape=(784,)),
                        layers.Dense(hp.Int('u',32,256,32),'relu')])
    for i in range(hp.Int('l',1,3)):
        m.add(layers.Dense(hp.Int(f'u{i}',32,256,32),'relu'))
    m.add(layers.Dense(10,'softmax'))

    m.compile(
       optimizer='adam',
    loss='sparse_categorical_crossentropy',
    metrics=['accuracy']
    )
    return m

t=kt.RandomSearch(build,'val_accuracy',max_trials=3,
                  directory='tune',project_name='mnist')

t.search(x_train,y_train,epochs=5,
         validation_data=(x_test,y_test),verbose=0)

print("Accuracy:", t.get_best_models(1)[0].evaluate(x_test,y_test,verbose=0)[1])


#exp7

import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
import numpy as np
import matplotlib.pyplot as plt

(X_train, y_train), (X_test, y_test) = keras.datasets.boston_housing.load_data()
print("Train shape:", X_train.shape)
print("Test shape:", X_test.shape)

scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

X_train = np.array(X_train, dtype=np.float32)
X_test = np.array(X_test, dtype=np.float32)
y_train = np.array(y_train, dtype=np.float32)
y_test = np.array(y_test, dtype=np.float32)

model = keras.Sequential([
    keras.Input(shape=(13,)),
    layers.Dense(64, activation='relu'),
    layers.Dense(32, activation='relu'),
    layers.Dense(1)
])

model.compile(
    optimizer='adam',
    loss=keras.losses.MeanSquaredError(),
    metrics=['mae']
)

history = model.fit(
    X_train, y_train,
    epochs=100,
    batch_size=16,
    validation_data=(X_test, y_test),
    verbose=1
)

test_loss, test_mae = model.evaluate(X_test, y_test)
print("Test Loss (MSE):", test_loss)
print("Test MAE:", test_mae)

predictions = model.predict(X_test)
for i in range(5):
    print(f"Actual: {y_test[i]:.2f}, Predicted: {predictions[i][0]:.2f}")

plt.plot(history.history['loss'], label='Training Loss')
plt.plot(history.history['val_loss'], label='Validation Loss')
plt.xlabel('Epochs')
plt.ylabel('Loss')
plt.legend()
plt.show()


#exp8

import numpy as np, pandas as pd, matplotlib.pyplot as plt
from sklearn.preprocessing import MinMaxScaler
from tensorflow.keras import Sequential
from tensorflow.keras.layers import LSTM, Dense

data = pd.read_csv("weatherdataset.csv")['Temperature'].values.reshape(-1,1)

scaler = MinMaxScaler()
data = scaler.fit_transform(data)

X, y = [], []
for i in range(len(data)-10):
    X.append(data[i:i+10])
    y.append(data[i+10])
X, y = np.array(X), np.array(y)

split = int(0.8*len(X))
X_train, X_test = X[:split], X[split:]
y_train, y_test = y[:split], y[split:]

model = Sequential([
    LSTM(50, input_shape=(10,1)),
    Dense(1)
])
model.compile('adam','mse')

model.fit(X_train, y_train, epochs=20, verbose=0)

pred = model.predict(X_test)
pred = scaler.inverse_transform(pred)
y_test = scaler.inverse_transform(y_test)

plt.plot(y_test, label='Actual')
plt.plot(pred, label='Predicted')
plt.legend()
plt.show()



