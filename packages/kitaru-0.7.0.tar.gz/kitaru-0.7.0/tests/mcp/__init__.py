"""MCP-specific test suite."""
