import type { BaseLayoutProps } from 'fumadocs-ui/layouts/shared';

export const gitConfig = {
  user: 'zenml-io',
  repo: 'kitaru',
  branch: 'develop',
};

export function baseOptions(): BaseLayoutProps {
  return {
    nav: {
      title: (props) => (
        <a {...props} href="/">
          <span className="nav-title inline-flex items-center gap-2">
            <svg
              width="24"
              height="24"
              viewBox="0 0 170 170"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              aria-hidden="true"
            >
              <g className="logo-ring">
                <path
                  d="M84.0547 0.885742C37.6324 0.885742 -0.000718234 38.5182 -0.000976562 84.9404C-0.000976562 131.363 37.6323 168.996 84.0547 168.996C130.477 168.996 168.109 131.363 168.109 84.9404C168.109 38.5184 130.477 0.885983 84.0547 0.885742ZM84.0566 24.9014C117.215 24.9014 144.096 51.7817 144.096 84.9404C144.096 118.099 117.215 144.98 84.0566 144.98C50.8978 144.98 24.0176 118.099 24.0176 84.9404C24.0177 51.7817 50.8978 24.9014 84.0566 24.9014Z"
                  fill="#F17829"
                />
              </g>
            </svg>
            <span style={{ fontWeight: 600 }}>Kitaru</span>
          </span>
        </a>
      ),
    },
    githubUrl: `https://github.com/${gitConfig.user}/${gitConfig.repo}`,
  };
}
