import defaultMdxComponents from 'fumadocs-ui/mdx';
import * as Python from 'fumadocs-python/components';
import { Accordion, Accordions } from 'fumadocs-ui/components/accordion';
import { Callout } from 'fumadocs-ui/components/callout';
import { Step, Steps } from 'fumadocs-ui/components/steps';
import { Tab, Tabs } from 'fumadocs-ui/components/tabs';
import type { MDXComponents } from 'mdx/types';
import {
  BuyerMatrixDiagram,
  CheckpointReplayDiagram,
  ComponentsDiagram,
  ExecutionArchitectureDiagram,
  FailedCheckpointDiagram,
  FlowShapeDiagram,
  GatewayStackDiagram,
  HarnessRuntimePlatformDiagram,
  ThreePlanesDiagram,
  WaitResumeDiagram,
} from '@/components/diagrams';

export function getMDXComponents(components?: MDXComponents): MDXComponents {
  return {
    ...defaultMdxComponents,
    ...Python,
    Accordion,
    Accordions,
    Callout,
    Step,
    Steps,
    Tab,
    Tabs,
    FlowShapeDiagram,
    CheckpointReplayDiagram,
    WaitResumeDiagram,
    ComponentsDiagram,
    GatewayStackDiagram,
    ExecutionArchitectureDiagram,
    ThreePlanesDiagram,
    FailedCheckpointDiagram,
    HarnessRuntimePlatformDiagram,
    BuyerMatrixDiagram,
    ...components,
  };
}
