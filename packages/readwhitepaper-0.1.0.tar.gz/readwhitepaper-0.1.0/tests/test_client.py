"""Tests for ReadWhitepaper Python client."""

from __future__ import annotations

import json
import unittest
from unittest.mock import MagicMock, patch

from readwhitepaper import ReadWhitepaperClient
from readwhitepaper.client import ReadWhitepaperError
from readwhitepaper.types import (
    Coverage,
    GlossaryTerm,
    GraphData,
    Language,
    PaginatedResponse,
    SearchResult,
    Stats,
    TocEntry,
    Whitepaper,
    WhitepaperDetail,
)


def _mock_response(data: dict | list) -> MagicMock:
    """Create a mock urllib response."""
    mock = MagicMock()
    mock.read.return_value = json.dumps(data).encode("utf-8")
    mock.__enter__ = lambda s: s
    mock.__exit__ = MagicMock(return_value=False)
    return mock


MOCK_WHITEPAPER = {
    "crypto": {
        "name": "Bitcoin",
        "ticker": "BTC",
        "slug": "bitcoin",
        "website_url": "https://bitcoin.org",
        "brand_color": "#F7931A",
        "market_cap_rank": 1,
    },
    "title": "Bitcoin: A Peer-to-Peer Electronic Cash System",
    "authors": ["Satoshi Nakamoto"],
    "year": 2008,
    "abstract": "A purely peer-to-peer version of electronic cash...",
    "total_sections": 14,
    "available_languages": ["en", "ko", "ja"],
}

MOCK_DETAIL = {
    **MOCK_WHITEPAPER,
    "source_url": "https://bitcoin.org/bitcoin.pdf",
    "sections": [
        {
            "order": 0,
            "section_number": "Abstract",
            "heading_level": 2,
            "heading_text": "Abstract",
            "content": "A purely peer-to-peer version...",
        }
    ],
}


class TestReadWhitepaperClient(unittest.TestCase):
    def setUp(self) -> None:
        self.client = ReadWhitepaperClient()

    @patch("readwhitepaper.client.urllib.request.urlopen")
    def test_list_whitepapers(self, mock_urlopen: MagicMock) -> None:
        mock_urlopen.return_value = _mock_response(
            {"count": 1, "next": None, "previous": None, "results": [MOCK_WHITEPAPER]}
        )
        result = self.client.list_whitepapers()
        assert isinstance(result, PaginatedResponse)
        assert result.count == 1
        assert len(result.results) == 1
        wp = result.results[0]
        assert isinstance(wp, Whitepaper)
        assert wp.crypto.ticker == "BTC"
        assert wp.year == 2008
        assert wp.authors == ["Satoshi Nakamoto"]

    @patch("readwhitepaper.client.urllib.request.urlopen")
    def test_get_whitepaper(self, mock_urlopen: MagicMock) -> None:
        mock_urlopen.return_value = _mock_response(MOCK_DETAIL)
        result = self.client.get_whitepaper("bitcoin")
        assert isinstance(result, WhitepaperDetail)
        assert result.crypto.slug == "bitcoin"
        assert result.source_url == "https://bitcoin.org/bitcoin.pdf"
        assert len(result.sections) == 1
        assert result.sections[0].heading_text == "Abstract"

    @patch("readwhitepaper.client.urllib.request.urlopen")
    def test_get_toc(self, mock_urlopen: MagicMock) -> None:
        mock_urlopen.return_value = _mock_response(
            {
                "slug": "bitcoin",
                "toc": [
                    {
                        "order": 0,
                        "section_number": "Abstract",
                        "heading_level": 2,
                        "anchor_id": "abstract",
                        "heading_en": "Abstract",
                        "heading": "Abstract",
                        "translated": False,
                    }
                ],
            }
        )
        result = self.client.get_toc("bitcoin")
        assert len(result) == 1
        assert isinstance(result[0], TocEntry)
        assert result[0].anchor_id == "abstract"

    @patch("readwhitepaper.client.urllib.request.urlopen")
    def test_get_coverage(self, mock_urlopen: MagicMock) -> None:
        mock_urlopen.return_value = _mock_response(
            {
                "slug": "bitcoin",
                "total_sections": 14,
                "languages": [
                    {"language": "en", "translated_sections": 14, "total_sections": 14, "completion_percent": 100.0}
                ],
            }
        )
        result = self.client.get_coverage("bitcoin")
        assert isinstance(result, Coverage)
        assert result.total_sections == 14
        assert result.languages[0].completion_percent == 100.0

    @patch("readwhitepaper.client.urllib.request.urlopen")
    def test_list_glossary(self, mock_urlopen: MagicMock) -> None:
        mock_urlopen.return_value = _mock_response(
            {
                "count": 1,
                "next": None,
                "previous": None,
                "results": [
                    {
                        "term": "Blockchain",
                        "slug": "blockchain",
                        "category": "networking",
                        "aliases": ["block chain"],
                        "definition": "An append-only ledger of blocks.",
                        "definition_html": "<p>An append-only ledger of blocks.</p>",
                        "occurrence_count": 53,
                    }
                ],
            }
        )
        result = self.client.list_glossary()
        assert result.count == 1
        term = result.results[0]
        assert isinstance(term, GlossaryTerm)
        assert term.category == "networking"

    @patch("readwhitepaper.client.urllib.request.urlopen")
    def test_search(self, mock_urlopen: MagicMock) -> None:
        mock_urlopen.return_value = _mock_response(
            {
                "query": "consensus",
                "language": "en",
                "count": 1,
                "results": [
                    {
                        "slug": "bitcoin",
                        "crypto": "BTC",
                        "section_order": 12,
                        "anchor_id": "conclusion",
                        "language": "en",
                        "heading": "Conclusion",
                        "snippet": "...consensus mechanism.",
                        "url": "/bitcoin/#conclusion",
                    }
                ],
            }
        )
        results = self.client.search("consensus")
        assert len(results) == 1
        assert isinstance(results[0], SearchResult)
        assert results[0].slug == "bitcoin"

    @patch("readwhitepaper.client.urllib.request.urlopen")
    def test_get_stats(self, mock_urlopen: MagicMock) -> None:
        mock_urlopen.return_value = _mock_response(
            {
                "totals": {"active_cryptocurrencies": 30, "whitepapers": 30, "sections": 247, "translations": 3458},
                "supported_languages": ["en", "ko"],
                "by_slug": [{"slug": "bitcoin", "ticker": "BTC", "total_sections": 14, "languages": []}],
            }
        )
        stats = self.client.get_stats()
        assert isinstance(stats, Stats)
        assert stats.whitepapers == 30
        assert stats.translations == 3458
        assert len(stats.by_slug) == 1

    @patch("readwhitepaper.client.urllib.request.urlopen")
    def test_get_languages(self, mock_urlopen: MagicMock) -> None:
        mock_urlopen.return_value = _mock_response(
            {
                "count": 2,
                "results": [
                    {"code": "en", "name": "English", "native_name": "English", "direction": "ltr"},
                    {"code": "ar", "name": "Arabic", "native_name": "العربية", "direction": "rtl"},
                ],
            }
        )
        langs = self.client.get_languages()
        assert len(langs) == 2
        assert isinstance(langs[0], Language)
        assert langs[1].direction == "rtl"

    @patch("readwhitepaper.client.urllib.request.urlopen")
    def test_get_graph(self, mock_urlopen: MagicMock) -> None:
        mock_urlopen.return_value = _mock_response(
            {
                "nodes": [
                    {"id": "wp-bitcoin", "label": "Bitcoin", "type": "whitepaper", "slug": "bitcoin", "ticker": "BTC", "color": "#F7931A", "year": 2008}
                ],
                "edges": [
                    {"source": "wp-bitcoin", "target": "wp-ethereum", "type": "influenced", "weight": 1.0}
                ],
            }
        )
        graph = self.client.get_graph()
        assert isinstance(graph, GraphData)
        assert len(graph.nodes) == 1
        assert len(graph.edges) == 1
        assert graph.nodes[0].ticker == "BTC"

    def test_custom_base_url(self) -> None:
        client = ReadWhitepaperClient(base_url="https://custom.api.com/api/")
        assert client.base_url == "https://custom.api.com/api"

    def test_custom_language(self) -> None:
        client = ReadWhitepaperClient(language="ko")
        assert client.language == "ko"


if __name__ == "__main__":
    unittest.main()
