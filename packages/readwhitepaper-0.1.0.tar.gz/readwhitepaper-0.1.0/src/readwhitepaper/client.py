"""ReadWhitepaper API client — zero dependencies, pure Python."""

from __future__ import annotations

import json
import urllib.error
import urllib.request
from typing import Any
from urllib.parse import urlencode

from readwhitepaper.types import (
    Coverage,
    Crypto,
    GlossaryTerm,
    GraphData,
    GraphEdge,
    GraphNode,
    Language,
    LanguageCoverage,
    PaginatedResponse,
    SearchResult,
    Section,
    Stats,
    TocEntry,
    Whitepaper,
    WhitepaperDetail,
    WhitepaperStats,
)


class ReadWhitepaperError(Exception):
    """Base exception for ReadWhitepaper API errors."""

    def __init__(self, message: str, status_code: int | None = None) -> None:
        super().__init__(message)
        self.status_code = status_code


class ReadWhitepaperClient:
    """Client for the ReadWhitepaper blockchain whitepaper API.

    30 cryptocurrency whitepapers with section-level content,
    163 glossary terms, full-text search, and 15-language translations.

    Args:
        base_url: API base URL. Defaults to https://readwhitepaper.com/api.
        timeout: Request timeout in seconds. Defaults to 30.
        language: Default language code for requests. Defaults to "en".
    """

    def __init__(
        self,
        base_url: str = "https://readwhitepaper.com/api",
        timeout: int = 30,
        language: str = "en",
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.language = language

    def _request(self, path: str, params: dict[str, Any] | None = None) -> Any:
        """Make an HTTP GET request to the API."""
        url = f"{self.base_url}{path}"
        if params:
            filtered = {k: v for k, v in params.items() if v is not None}
            if filtered:
                url = f"{url}?{urlencode(filtered)}"

        req = urllib.request.Request(
            url,
            headers={
                "Accept": "application/json",
                "User-Agent": "readwhitepaper-python/0.1.0",
            },
        )

        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                data: Any = json.loads(resp.read().decode("utf-8"))
                return data
        except urllib.error.HTTPError as e:
            body = e.read().decode("utf-8", errors="replace")
            raise ReadWhitepaperError(
                f"HTTP {e.code}: {body[:200]}",
                status_code=e.code,
            ) from e
        except urllib.error.URLError as e:
            raise ReadWhitepaperError(f"Connection error: {e.reason}") from e

    # ── Whitepapers ──────────────────────────────────────────────

    def list_whitepapers(
        self,
        *,
        limit: int | None = None,
        page: int | None = None,
        language: str | None = None,
    ) -> PaginatedResponse:
        """List all whitepapers.

        Args:
            limit: Number of results per page.
            page: Page number.
            language: Language code for translated fields.

        Returns:
            Paginated list of whitepapers.
        """
        params: dict[str, Any] = {
            "limit": limit,
            "page": page,
            "language": language or self.language,
        }
        data = self._request("/whitepapers/", params)
        results = [self._parse_whitepaper(wp) for wp in data.get("results", [])]
        return PaginatedResponse(
            count=data.get("count", 0),
            next=data.get("next"),
            previous=data.get("previous"),
            results=results,
        )

    def get_whitepaper(self, slug: str, *, language: str | None = None) -> WhitepaperDetail:
        """Get full whitepaper detail with all sections.

        Args:
            slug: Whitepaper slug (e.g. "bitcoin", "ethereum").
            language: Language code for translated content.

        Returns:
            Full whitepaper with sections.
        """
        params: dict[str, Any] = {"language": language or self.language}
        data = self._request(f"/whitepapers/{slug}/", params)
        return self._parse_whitepaper_detail(data)

    def get_sections(self, slug: str, *, language: str | None = None) -> list[Section]:
        """Get whitepaper sections.

        Args:
            slug: Whitepaper slug.
            language: Language code.

        Returns:
            List of sections with content.
        """
        params: dict[str, Any] = {"language": language or self.language}
        data = self._request(f"/whitepapers/{slug}/sections/", params)
        sections: list[dict[str, Any]] = data if isinstance(data, list) else data.get("results", [])
        return [self._parse_section(s) for s in sections]

    def get_toc(self, slug: str, *, language: str | None = None) -> list[TocEntry]:
        """Get table of contents for a whitepaper.

        Args:
            slug: Whitepaper slug.
            language: Language code.

        Returns:
            Table of contents entries.
        """
        params: dict[str, Any] = {"language": language or self.language}
        data = self._request(f"/whitepapers/{slug}/toc/", params)
        toc_list: list[dict[str, Any]] = data.get("toc", [])
        return [self._parse_toc_entry(t) for t in toc_list]

    def get_coverage(self, slug: str) -> Coverage:
        """Get translation coverage for a whitepaper.

        Args:
            slug: Whitepaper slug.

        Returns:
            Coverage data with per-language completion percentages.
        """
        data = self._request(f"/whitepapers/{slug}/coverage/")
        return Coverage(
            slug=data.get("slug", slug),
            total_sections=data.get("total_sections", 0),
            languages=[
                LanguageCoverage(
                    language=lang["language"],
                    translated_sections=lang["translated_sections"],
                    total_sections=lang["total_sections"],
                    completion_percent=lang["completion_percent"],
                )
                for lang in data.get("languages", [])
            ],
        )

    # ── Glossary ─────────────────────────────────────────────────

    def list_glossary(
        self,
        *,
        limit: int | None = None,
        page: int | None = None,
        language: str | None = None,
    ) -> PaginatedResponse:
        """List blockchain glossary terms.

        Args:
            limit: Number of results per page.
            page: Page number.
            language: Language code for translated terms.

        Returns:
            Paginated list of glossary terms.
        """
        params: dict[str, Any] = {
            "limit": limit,
            "page": page,
            "language": language or self.language,
        }
        data = self._request("/glossary/", params)
        results = [self._parse_glossary_term(t) for t in data.get("results", [])]
        return PaginatedResponse(
            count=data.get("count", 0),
            next=data.get("next"),
            previous=data.get("previous"),
            results=results,
        )

    def get_glossary_term(self, slug: str, *, language: str | None = None) -> GlossaryTerm:
        """Get a single glossary term.

        Args:
            slug: Term slug (e.g. "blockchain", "consensus").
            language: Language code.

        Returns:
            Glossary term with definition.
        """
        params: dict[str, Any] = {"language": language or self.language}
        data = self._request(f"/glossary/{slug}/", params)
        return self._parse_glossary_term(data)

    # ── Search ───────────────────────────────────────────────────

    def search(
        self,
        query: str,
        *,
        slug: str | None = None,
        language: str | None = None,
    ) -> list[SearchResult]:
        """Full-text search across all whitepapers.

        Args:
            query: Search query string.
            slug: Limit search to a specific whitepaper.
            language: Language code.

        Returns:
            List of search results with snippets.
        """
        params: dict[str, Any] = {
            "q": query,
            "slug": slug,
            "language": language or self.language,
        }
        data = self._request("/search/", params)
        results_list: list[dict[str, Any]] = data.get("results", [])
        return [
            SearchResult(
                slug=r.get("slug", ""),
                crypto=r.get("crypto", ""),
                section_order=r.get("section_order", 0),
                anchor_id=r.get("anchor_id", ""),
                language=r.get("language", "en"),
                heading=r.get("heading", ""),
                snippet=r.get("snippet", ""),
                url=r.get("url", ""),
            )
            for r in results_list
        ]

    # ── Stats / Languages / Graph ────────────────────────────────

    def get_stats(self) -> Stats:
        """Get platform statistics.

        Returns:
            Overall statistics including counts and per-whitepaper data.
        """
        data = self._request("/stats/")
        totals = data.get("totals", {})
        return Stats(
            active_cryptocurrencies=totals.get("active_cryptocurrencies", 0),
            whitepapers=totals.get("whitepapers", 0),
            sections=totals.get("sections", 0),
            translations=totals.get("translations", 0),
            supported_languages=data.get("supported_languages", []),
            by_slug=[
                WhitepaperStats(
                    slug=s["slug"],
                    ticker=s["ticker"],
                    total_sections=s["total_sections"],
                    languages=s.get("languages", []),
                )
                for s in data.get("by_slug", [])
            ],
        )

    def get_languages(self) -> list[Language]:
        """Get all supported languages.

        Returns:
            List of supported languages with metadata.
        """
        data = self._request("/languages/")
        lang_list: list[dict[str, Any]] = data.get("results", data) if isinstance(data, dict) else data
        return [
            Language(
                code=lang["code"],
                name=lang["name"],
                native_name=lang["native_name"],
                direction=lang["direction"],
            )
            for lang in lang_list
        ]

    def get_graph(self) -> GraphData:
        """Get the whitepaper relationship graph.

        Returns:
            Graph with nodes (whitepapers/concepts) and edges (relationships).
        """
        data = self._request("/graph/")
        nodes = [
            GraphNode(
                id=n["id"],
                label=n.get("label", ""),
                type=n.get("type", ""),
                slug=n.get("slug", ""),
                ticker=n.get("ticker", ""),
                color=n.get("color", ""),
                year=n.get("year", 0),
            )
            for n in data.get("nodes", [])
        ]
        edges = [
            GraphEdge(
                source=e["source"],
                target=e["target"],
                type=e.get("type", ""),
                weight=e.get("weight", 1.0),
            )
            for e in data.get("edges", [])
        ]
        return GraphData(nodes=nodes, edges=edges)

    # ── Parsers ──────────────────────────────────────────────────

    @staticmethod
    def _parse_crypto(data: dict[str, Any]) -> Crypto:
        return Crypto(
            name=data.get("name", ""),
            ticker=data.get("ticker", ""),
            slug=data.get("slug", ""),
            website_url=data.get("website_url", ""),
            brand_color=data.get("brand_color", ""),
            market_cap_rank=data.get("market_cap_rank", 0),
        )

    @classmethod
    def _parse_whitepaper(cls, data: dict[str, Any]) -> Whitepaper:
        return Whitepaper(
            crypto=cls._parse_crypto(data.get("crypto", {})),
            title=data.get("title", ""),
            authors=data.get("authors", []),
            year=data.get("year", 0),
            abstract=data.get("abstract", ""),
            total_sections=data.get("total_sections", 0),
            available_languages=data.get("available_languages", []),
        )

    @classmethod
    def _parse_whitepaper_detail(cls, data: dict[str, Any]) -> WhitepaperDetail:
        return WhitepaperDetail(
            crypto=cls._parse_crypto(data.get("crypto", {})),
            title=data.get("title", ""),
            authors=data.get("authors", []),
            year=data.get("year", 0),
            abstract=data.get("abstract", ""),
            source_url=data.get("source_url", ""),
            total_sections=data.get("total_sections", 0),
            available_languages=data.get("available_languages", []),
            sections=[cls._parse_section(s) for s in data.get("sections", [])],
        )

    @staticmethod
    def _parse_section(data: dict[str, Any]) -> Section:
        return Section(
            order=data.get("order", 0),
            section_number=data.get("section_number", ""),
            heading_level=data.get("heading_level", 2),
            heading_text=data.get("heading_text", data.get("heading", "")),
            content=data.get("content", ""),
        )

    @staticmethod
    def _parse_toc_entry(data: dict[str, Any]) -> TocEntry:
        return TocEntry(
            order=data.get("order", 0),
            section_number=data.get("section_number", ""),
            heading_level=data.get("heading_level", 2),
            anchor_id=data.get("anchor_id", ""),
            heading_en=data.get("heading_en", ""),
            heading=data.get("heading", ""),
            translated=data.get("translated", False),
        )

    @staticmethod
    def _parse_glossary_term(data: dict[str, Any]) -> GlossaryTerm:
        return GlossaryTerm(
            term=data.get("term", ""),
            slug=data.get("slug", ""),
            category=data.get("category", ""),
            aliases=data.get("aliases", []),
            definition=data.get("definition", ""),
            definition_html=data.get("definition_html", ""),
            occurrence_count=data.get("occurrence_count", 0),
            translated_term=data.get("translated_term"),
            translated_definition=data.get("translated_definition"),
            translated_definition_html=data.get("translated_definition_html"),
        )
