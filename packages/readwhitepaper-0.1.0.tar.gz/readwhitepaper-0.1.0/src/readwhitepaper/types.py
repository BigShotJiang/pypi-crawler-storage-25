"""Type definitions for ReadWhitepaper API responses."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True)
class Crypto:
    """Cryptocurrency metadata associated with a whitepaper."""

    name: str
    ticker: str
    slug: str
    website_url: str
    brand_color: str
    market_cap_rank: int


@dataclass(frozen=True)
class Whitepaper:
    """Whitepaper summary from list endpoint."""

    crypto: Crypto
    title: str
    authors: list[str]
    year: int
    abstract: str
    total_sections: int
    available_languages: list[str]


@dataclass(frozen=True)
class Section:
    """A section of whitepaper content."""

    order: int
    section_number: str
    heading_level: int
    heading_text: str
    content: str


@dataclass(frozen=True)
class WhitepaperDetail:
    """Full whitepaper detail including sections."""

    crypto: Crypto
    title: str
    authors: list[str]
    year: int
    abstract: str
    source_url: str
    total_sections: int
    available_languages: list[str]
    sections: list[Section]


@dataclass(frozen=True)
class TocEntry:
    """Table of contents entry."""

    order: int
    section_number: str
    heading_level: int
    anchor_id: str
    heading_en: str
    heading: str
    translated: bool


@dataclass(frozen=True)
class LanguageCoverage:
    """Coverage for a single language."""

    language: str
    translated_sections: int
    total_sections: int
    completion_percent: float


@dataclass(frozen=True)
class Coverage:
    """Translation coverage for a whitepaper."""

    slug: str
    total_sections: int
    languages: list[LanguageCoverage]


@dataclass(frozen=True)
class GlossaryTerm:
    """Blockchain glossary term with definition."""

    term: str
    slug: str
    category: str
    aliases: list[str]
    definition: str
    definition_html: str
    occurrence_count: int
    translated_term: str | None = None
    translated_definition: str | None = None
    translated_definition_html: str | None = None


@dataclass(frozen=True)
class SearchResult:
    """A single search result from full-text search."""

    slug: str
    crypto: str
    section_order: int
    anchor_id: str
    language: str
    heading: str
    snippet: str
    url: str


@dataclass(frozen=True)
class WhitepaperStats:
    """Per-whitepaper statistics."""

    slug: str
    ticker: str
    total_sections: int
    languages: list[dict[str, Any]]


@dataclass(frozen=True)
class Stats:
    """Overall platform statistics."""

    active_cryptocurrencies: int
    whitepapers: int
    sections: int
    translations: int
    supported_languages: list[str]
    by_slug: list[WhitepaperStats]


@dataclass(frozen=True)
class Language:
    """Supported language metadata."""

    code: str
    name: str
    native_name: str
    direction: str


@dataclass(frozen=True)
class GraphNode:
    """Node in the relationship graph."""

    id: str
    label: str
    type: str
    slug: str
    ticker: str
    color: str
    year: int


@dataclass(frozen=True)
class GraphEdge:
    """Edge in the relationship graph."""

    source: str
    target: str
    type: str
    weight: float = 1.0


@dataclass(frozen=True)
class GraphData:
    """Full relationship graph data."""

    nodes: list[GraphNode]
    edges: list[GraphEdge]


@dataclass(frozen=True)
class PaginatedResponse:
    """Paginated API response wrapper."""

    count: int
    next: str | None
    previous: str | None
    results: list[Any] = field(default_factory=list)
