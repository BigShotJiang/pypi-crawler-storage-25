"""ReadWhitepaper — Python client for the blockchain whitepaper database API.

30 cryptocurrency whitepapers, 163 glossary terms, 3,458 translations across 15 languages.

Usage:
    from readwhitepaper import ReadWhitepaperClient

    client = ReadWhitepaperClient()
    whitepapers = client.list_whitepapers()
    bitcoin = client.get_whitepaper("bitcoin")
"""

from readwhitepaper.client import ReadWhitepaperClient
from readwhitepaper.types import (
    Coverage,
    Crypto,
    GlossaryTerm,
    GraphData,
    GraphEdge,
    GraphNode,
    Language,
    PaginatedResponse,
    SearchResult,
    Section,
    Stats,
    TocEntry,
    Whitepaper,
    WhitepaperDetail,
    WhitepaperStats,
)

__all__ = [
    "ReadWhitepaperClient",
    "Coverage",
    "Crypto",
    "GlossaryTerm",
    "GraphData",
    "GraphEdge",
    "GraphNode",
    "Language",
    "PaginatedResponse",
    "SearchResult",
    "Section",
    "Stats",
    "TocEntry",
    "Whitepaper",
    "WhitepaperDetail",
    "WhitepaperStats",
]

__version__ = "0.1.0"
