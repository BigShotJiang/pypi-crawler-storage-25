# Talon

Context intelligence for Agentic Development — graph-based code context for AI coding agents.

## Supported Languages

| Language   | Extensions                     | Parser Features                                                      |
| ---------- | ------------------------------ | -------------------------------------------------------------------- |
| Python     | `.py`                          | Classes, decorators, raise/except, async                             |
| TypeScript | `.ts`, `.tsx`                  | Classes, interfaces, arrow functions, ES imports                     |
| JavaScript | `.js`, `.jsx`, `.mjs`, `.cjs`  | Arrow functions, ES imports/exports, method chains, error paths      |
| Go         | `.go`                          | Structs, receiver methods, interfaces, panic/recover                 |
| Java       | `.java`                        | Annotations, constructors, throws, inheritance, enums                |
| Rust       | `.rs`                          | Structs, traits, impl blocks, enums, panic!/? error paths            |
| C#         | `.cs`                          | Classes, interfaces, attributes, constructors, throw/catch           |
| Kotlin     | `.kt`, `.kts`                  | Data/sealed classes, companion objects, suspend functions             |
| Ruby       | `.rb`                          | Classes, modules, include/extend, singleton methods, rescue          |
| PHP        | `.php`                         | Classes, interfaces, traits, enums, namespace imports                |

All languages get full-depth parsing: classes/structs, functions/methods, imports, call edges, error flow edges, method chain resolution, and cross-module call edges.

## Install

```bash
pip install talon
```

## Quick start

```bash
# Authenticate with cogmeta.ai (opens browser, no copy/paste)
talon-setup auth login

# Generate .mcp.json for your project
talon-setup init --cloud
```

Then restart Claude Code — Talon is active.

## `talon work` — SPECx client-pull dispatcher (new in 0.7.80)

Poll the SPECx work queue, run claimed tickets locally via `claude -p`, stream audit events back, post completion. Closes the loop for client-pull dispatch (Slice 2).

```bash
# Smoke-test: claim + start + audit + complete one ticket without invoking claude
talon work --once --dry-run

# Real run: claim and run one ticket via claude -p (180s hard cap)
talon work --once --timeout-seconds 180

# Long-running worker: drain the queue until interrupted
talon work --poll-seconds 5

# Bounded run: process exactly N tickets then exit
talon work --max-runs 10
```

**Prerequisites for the real path (without `--dry-run`):**

1. `talon auth login` — provisions `~/.talon/credentials.json` with your API key.
2. `claude /login` — your local Claude Code CLI must be authenticated.
3. `~/.claude/settings.json` must have `permissions.defaultMode: "bypassPermissions"` (or you'll see the wrapper report `status=done` with no files produced — see the talonpilot reproduction in `postmortem-slice-2-day-2026-05-16.md`).

**Concurrent agents.** Multiple `talon work` processes can race the same queue safely. Each `--client-id` gets its own per-second polling budget (server-side rate limit is keyed per `client_id`). Verified: 3 concurrent agents, 9 tickets, 173 seconds wall-clock, 6/6 pytest passing on produced code.

**Sandbox first.** `talon work` writes files into the current working directory and creates branches like `specx/T-0042`. Use a clean subdirectory:

```bash
mkdir specx-work && cd specx-work && git init
talon work --once
git log --all --oneline    # see what got produced
```

On SIGINT (Ctrl-C) / SIGTERM the wrapper POSTs `/release` on the active claim so the queue doesn't starve.
