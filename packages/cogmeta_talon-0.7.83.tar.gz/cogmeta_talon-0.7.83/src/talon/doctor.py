"""R-CLIENT-HOOK-CONFLICT — `talon doctor` diagnostic engine.

Surfaces hook collisions, install gotchas, and config drift that would
make first-run UX fail silently. Designed to be the FIRST thing a confused
customer runs after `talon health` confirms cloud reachability.

Checks (each one returns DoctorFinding):

  CLAUDE_SETTINGS_EXISTS    - ~/.claude/settings.json present + parseable
  HOOK_DUPLICATES           - same hook command registered twice
  HOOK_TIMEOUT_MISSING      - any UserPromptSubmit hook lacking a timeout
  MCP_JSON_PROJECT_PRESENT  - project .mcp.json exists where talon expects
  MCP_JSON_TALON_REGISTERED - talon entry actually in mcpServers
  MCP_JSON_OTHER_SERVERS    - count of non-talon servers preserved (S4 lock)
  CREDENTIALS_PRESENT       - ~/.talon/credentials.json + api_key non-empty
  CONFIG_YAML_VALID         - ~/.talon/config.yaml parseable (if present)
  MODE_VALUE_VALID          - mode is one of default|strict|yolo
  CLOUD_REACHABLE           - GET /talon/mcp/health returns 2xx
  VERSION_SKEW              - client/cloud compatibility (R-CLIENT-MCP-VERSION-SKEW)
  PYTHON_VERSION            - Python ≥3.10 for the talon whl

Each finding has:
  level   - "ok" | "warn" | "fail"
  code    - short stable id e.g. "TALON-DOCTOR-HOOK-DUP-001"
  message - one-line human-readable
  fix     - shell snippet or instruction (when known)

Output: print + return list[DoctorFinding] for programmatic callers.
"""
from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from pathlib import Path

from talon.config.env import EnvVar, get_required as _env_get

CLAUDE_SETTINGS = Path.home() / ".claude" / "settings.json"
TALON_CREDS = Path.home() / ".talon" / "credentials.json"
TALON_CONFIG = Path.home() / ".talon" / "config.yaml"


@dataclass
class DoctorFinding:
    level: str   # "ok" | "warn" | "fail"
    code: str
    message: str
    fix: str = ""

    def to_dict(self) -> dict:
        return {"level": self.level, "code": self.code, "message": self.message, "fix": self.fix}


@dataclass
class DoctorReport:
    findings: list[DoctorFinding] = field(default_factory=list)

    @property
    def has_failures(self) -> bool:
        return any(f.level == "fail" for f in self.findings)

    @property
    def has_warnings(self) -> bool:
        return any(f.level == "warn" for f in self.findings)

    def to_dict(self) -> dict:
        return {
            "ok_count": sum(1 for f in self.findings if f.level == "ok"),
            "warn_count": sum(1 for f in self.findings if f.level == "warn"),
            "fail_count": sum(1 for f in self.findings if f.level == "fail"),
            "findings": [f.to_dict() for f in self.findings],
        }


# ---------------------------------------------------------------------------
# Individual checks
# ---------------------------------------------------------------------------

def _read_json(path: Path) -> dict | None:
    try:
        return json.loads(path.read_text())
    except Exception:
        return None


def check_python_version() -> DoctorFinding:
    import sys
    major, minor = sys.version_info.major, sys.version_info.minor
    if (major, minor) >= (3, 10):
        return DoctorFinding("ok", "TALON-DOCTOR-PY-001", f"Python {major}.{minor} ≥ 3.10")
    return DoctorFinding(
        "fail", "TALON-DOCTOR-PY-001",
        f"Python {major}.{minor} too old; talon requires 3.10+",
        "  Install Python 3.10 or newer; e.g. `pyenv install 3.12.1`",
    )


def check_credentials() -> DoctorFinding:
    if not TALON_CREDS.exists():
        return DoctorFinding(
            "fail", "TALON-DOCTOR-AUTH-001",
            "~/.talon/credentials.json missing — not logged in",
            "  Run: talon login",
        )
    data = _read_json(TALON_CREDS)
    if not isinstance(data, dict) or not (data.get("api_key") or "").strip():
        return DoctorFinding(
            "fail", "TALON-DOCTOR-AUTH-002",
            "credentials.json present but api_key is empty",
            "  Run: talon login   (or talon auth sync if rotated)",
        )
    email = data.get("email") or "(unknown)"
    return DoctorFinding("ok", "TALON-DOCTOR-AUTH-001", f"logged in as {email}")


def check_config_yaml() -> DoctorFinding:
    if not TALON_CONFIG.exists():
        return DoctorFinding("ok", "TALON-DOCTOR-CFG-001", "config.yaml not yet written (defaults apply)")
    try:
        import yaml  # type: ignore[import-untyped]
        data = yaml.safe_load(TALON_CONFIG.read_text()) or {}
        if not isinstance(data, dict):
            raise ValueError("config root is not a mapping")
    except Exception as exc:
        return DoctorFinding(
            "fail", "TALON-DOCTOR-CFG-001",
            f"~/.talon/config.yaml unparseable: {exc}",
            "  Inspect the file; either fix the YAML or delete it to fall back to defaults",
        )
    return DoctorFinding("ok", "TALON-DOCTOR-CFG-001", f"config.yaml valid; {len(data)} key(s)")


def check_mode_value() -> DoctorFinding:
    try:
        from talon.mode import VALID_MODES, get_mode
    except Exception:
        return DoctorFinding(
            "warn", "TALON-DOCTOR-MODE-001",
            "talon.mode module not importable",
        )
    m = get_mode()
    if m in VALID_MODES:
        return DoctorFinding("ok", "TALON-DOCTOR-MODE-001", f"mode = {m}")
    return DoctorFinding(
        "fail", "TALON-DOCTOR-MODE-001",
        f"mode={m!r} is not one of {VALID_MODES}",
        "  Run: talon mode set default",
    )


def check_claude_settings() -> list[DoctorFinding]:
    out: list[DoctorFinding] = []
    if not CLAUDE_SETTINGS.exists():
        out.append(DoctorFinding(
            "warn", "TALON-DOCTOR-CLAUDE-001",
            "~/.claude/settings.json not found — Claude Code may not be installed",
            "  Install Claude Code from https://claude.ai/code",
        ))
        return out
    data = _read_json(CLAUDE_SETTINGS)
    if data is None:
        out.append(DoctorFinding(
            "fail", "TALON-DOCTOR-CLAUDE-002",
            "~/.claude/settings.json unparseable JSON",
            "  Inspect the file; fix or back it up + delete to let Claude Code regenerate",
        ))
        return out

    out.append(DoctorFinding("ok", "TALON-DOCTOR-CLAUDE-001", "claude settings.json valid"))

    hooks = data.get("hooks") or {}
    if not isinstance(hooks, dict):
        out.append(DoctorFinding(
            "warn", "TALON-DOCTOR-HOOK-SHAPE",
            "hooks block has unexpected shape — manual review recommended",
        ))
        return out

    # Detect duplicate hook commands across all event types.
    seen: dict[str, list[str]] = {}  # cmd → [event_paths]
    for event, hook_list in hooks.items():
        if not isinstance(hook_list, list):
            continue
        for i, hook in enumerate(hook_list):
            if not isinstance(hook, dict):
                continue
            cmd = (hook.get("hooks") or [{}])[0].get("command") if isinstance(hook.get("hooks"), list) else None
            if not cmd:
                cmd = hook.get("command")
            if cmd:
                seen.setdefault(cmd, []).append(f"{event}[{i}]")

    dups = {cmd: where for cmd, where in seen.items() if len(where) > 1}
    if dups:
        for cmd, where in list(dups.items())[:3]:  # cap output
            out.append(DoctorFinding(
                "warn", "TALON-DOCTOR-HOOK-DUP-001",
                f"hook command {cmd!r} registered {len(where)}× at {', '.join(where)}",
                f"  Open {CLAUDE_SETTINGS}; remove duplicate entries from the `hooks` block",
            ))
    else:
        out.append(DoctorFinding("ok", "TALON-DOCTOR-HOOK-DUP-001", "no hook duplicates"))

    return out


def check_mcp_json(project_path: Path | None = None) -> list[DoctorFinding]:
    out: list[DoctorFinding] = []
    project_path = project_path or Path.cwd()
    mcp_json = project_path / ".mcp.json"

    if not mcp_json.exists():
        out.append(DoctorFinding(
            "warn", "TALON-DOCTOR-MCP-001",
            f"no .mcp.json in {project_path} — talon not initialised here",
            "  Run: talon init   (in the project root)",
        ))
        return out

    data = _read_json(mcp_json)
    if data is None:
        out.append(DoctorFinding(
            "fail", "TALON-DOCTOR-MCP-002",
            f"{mcp_json} unparseable JSON",
            f"  A .mcp.json.bak may already exist; restore it: cp {mcp_json}.bak {mcp_json}",
        ))
        return out

    servers = (data.get("mcpServers") or {}) if isinstance(data.get("mcpServers"), dict) else {}
    if not servers:
        out.append(DoctorFinding(
            "fail", "TALON-DOCTOR-MCP-003",
            ".mcp.json has no mcpServers block",
            "  Run: talon init --force",
        ))
        return out

    talon_keys = [k for k in servers if k.lower().startswith("talon")]
    if not talon_keys:
        out.append(DoctorFinding(
            "fail", "TALON-DOCTOR-MCP-004",
            ".mcp.json present but no talon entry registered",
            "  Run: talon init --force   (preserves your other MCP servers)",
        ))
    else:
        out.append(DoctorFinding(
            "ok", "TALON-DOCTOR-MCP-001",
            f".mcp.json valid; talon registered as {talon_keys[0]}",
        ))

    other = [k for k in servers if not k.lower().startswith("talon")]
    if other:
        out.append(DoctorFinding(
            "ok", "TALON-DOCTOR-MCP-005",
            f"{len(other)} other MCP server(s) preserved: {', '.join(other[:3])}",
        ))

    return out


def check_cloud_and_skew() -> list[DoctorFinding]:
    out: list[DoctorFinding] = []
    creds = _read_json(TALON_CREDS) or {}
    cloud_url = creds.get("cloud_url", _env_get(EnvVar.CLOUD_URL))
    try:
        from talon.version_skew import compare_versions, fetch_cloud_version, get_client_version
    except Exception:
        return out
    cloud_version = fetch_cloud_version(cloud_url)
    if not cloud_version:
        out.append(DoctorFinding(
            "warn", "TALON-DOCTOR-CLOUD-001",
            f"cloud reachability check failed for {cloud_url}",
            "  Check network connectivity; run `talon health` for details",
        ))
        return out

    client_version = get_client_version()
    if not client_version:
        out.append(DoctorFinding("warn", "TALON-DOCTOR-VER-001", "client version unknown"))
        return out

    skew = compare_versions(client_version, cloud_version)
    level_to_finding = {"safe": "ok", "warn": "warn", "error": "fail", "unknown": "warn"}
    out.append(DoctorFinding(
        level_to_finding.get(skew.level.value, "warn"),
        "TALON-DOCTOR-SKEW-001",
        f"client {client_version} ↔ cloud {cloud_version}: {skew.detail}",
        "  Run: talon upgrade" if skew.level.value in ("warn", "error") else "",
    ))
    return out


# ---------------------------------------------------------------------------
# Driver
# ---------------------------------------------------------------------------

def run_doctor(project_path: Path | None = None) -> DoctorReport:
    """Run every check; return collected findings."""
    findings: list[DoctorFinding] = []
    findings.append(check_python_version())
    findings.append(check_credentials())
    findings.append(check_config_yaml())
    findings.append(check_mode_value())
    findings.extend(check_claude_settings())
    findings.extend(check_mcp_json(project_path))
    findings.extend(check_cloud_and_skew())
    return DoctorReport(findings=findings)


def format_report(report: DoctorReport) -> str:
    """Human-readable rendering for the CLI."""
    icon = {"ok": "✓", "warn": "⚠", "fail": "✗"}
    lines = ["TALON DOCTOR", "============"]
    for f in report.findings:
        lines.append(f"  {icon.get(f.level, '?')}  [{f.code}] {f.message}")
        if f.fix and f.level != "ok":
            lines.append(f"     fix: {f.fix.lstrip()}")
    summary = report.to_dict()
    lines.append("")
    lines.append(
        f"  {summary['ok_count']} ok · {summary['warn_count']} warn · {summary['fail_count']} fail"
    )
    if report.has_failures:
        lines.append("")
        lines.append("  → Fix the ✗ items first; warnings (⚠) are advisory.")
    return "\n".join(lines)
