# 🛠️ pytools

A modular collection of Python utilities for **Typer**, **Pydantic**, and **Debugging**. Built for high-performance developer workflows using `uv` and `hatchling`.

`pytools` is designed as a "buffet" library—install only the submodules you need to keep your project dependencies lean.

## 🚀 Quick Start

Add `pytools` to your project using **uv**. You can choose specific "extras" to pull in only the dependencies required for that module.

```bash
# Install just the Typer utilities (and their deps)
uv add "pytools[typer] @ git+ssh://git@github.com/buchanan-solutions/pytools.git"

# Install everything
uv add "pytools[all] @ git+ssh://git@github.com/buchanan-solutions/pytools.git"

```

## 📦 Submodules

| Extra | Description | Key Dependencies |
| --- | --- | --- |
| `core` | Foundational logic used by all modules. | None (Std Lib only) |
| `typer` | CLI helpers, context management, and rich logging. | `typer`, `rich`, `python-dotenv` |
| `pydantic` | Custom validators and base model configurations. | `pydantic` |
| `pydantic-settings` | Environment management and config loading. | `pydantic-settings` |
| `debugging` | Enhanced print utilities and object inspection. | `icecream` |

## 💡 Usage

### Typer Context Helper

Easily grab objects from the Typer context in nested commands:

```python
from pytools.typer.utils.get_from_ctx import get_from_ctx
from my_app.models import Config

@app.command()
def run(ctx: typer.Context):
    # Traverses parent contexts automatically
    config = get_from_ctx(ctx, "config", Config)
    ...

```

### Enhanced Debugging

```python
from pytools.debugging.debug_print import debug_print

data = {"status": "success", "meta": [1, 2, 3]}
debug_print(data) # Beautifully formatted terminal output

```

## 🛠️ Development

This project uses the `src` layout and `hatchling` backend.

```bash
# Clone and sync environment
git clone https://github.com/your-org/pytools.git
cd pytools
uv sync --all-extras

# Run tests
uv run pytest

```

## 📜 License

MIT © 2026 Buchanan Information Systems Inc.