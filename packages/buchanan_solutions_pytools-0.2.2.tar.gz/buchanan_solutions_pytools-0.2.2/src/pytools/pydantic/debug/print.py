from typing import Optional, Union

from pydantic import BaseModel
from rich.console import Console
from rich.panel import Panel
from rich.pretty import Pretty


def pretty_model(
    model: Union[BaseModel, dict],
    *,
    title: Optional[str] = None,
    console: Optional[Console] = None,
    panel: Optional[bool] = False,
) -> None:
    """
    Pretty print a Pydantic model or dict in a blue panel.

    Args:
        model: Pydantic model or dict to print
        console: Optional Rich Console; if None, creates a new one
        title: Title for the panel
    """
    console = console or Console()
    if isinstance(model, BaseModel):
        model_dict = model.model_dump()
        default_title = model.__class__.__name__ or "Unnamed"
    else:
        model_dict = model
        default_title = "Dict"
    
    print_obj = None
    if panel:
        print_obj = Panel(
            Pretty(model_dict, expand_all=True, indent_guides=True),
            border_style="blue",
            title=title or default_title,
            title_align="left",
            padding=(1, 2),
            expand=False,
        )
    else:
        print_obj = Pretty(model_dict, expand_all=True, indent_guides=True)
    
    console.print(print_obj)
