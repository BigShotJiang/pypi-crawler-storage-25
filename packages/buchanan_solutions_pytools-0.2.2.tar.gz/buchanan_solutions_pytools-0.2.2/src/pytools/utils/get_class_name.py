def get_class_name(args):
    if args:
        instance_or_cls = args[0]
        if hasattr(instance_or_cls, "__class__"):
            return instance_or_cls.__class__.__name__
        elif isinstance(instance_or_cls, type):
            return instance_or_cls.__name__
    return None
