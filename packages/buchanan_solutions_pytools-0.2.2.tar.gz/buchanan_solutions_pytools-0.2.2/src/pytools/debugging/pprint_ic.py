try:
    from icecream import ic

    # Configure it to be "pretty" for your team
    ic.configureOutput(prefix='[PYTOOLS DEBUG] | ', includeContext=True)
except ImportError:
    # Fallback if someone didn't install the [debugging] extra
    ic = print 

def pprint_ic(obj):
    """A wrapper for icecream that handles missing deps gracefully."""
    ic(obj)