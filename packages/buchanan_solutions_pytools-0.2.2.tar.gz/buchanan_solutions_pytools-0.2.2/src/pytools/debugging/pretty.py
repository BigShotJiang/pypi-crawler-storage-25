from typing import Any, Optional, Union

from pydantic import BaseModel
from rich.console import Console
from rich.panel import Panel
from rich.pretty import Pretty


def pretty(obj: Any, *, console: Optional[Console] = None) -> None:
    """
    Pretty print any object using Rich's Pretty printer.
    
    Args:
        obj: Object to pretty-print
        console: Optional Rich Console; if None, creates a new one
    """
    console = console or Console()
    console.print(Pretty(obj, expand_all=True, indent_guides=True))


def pretty_console(
    obj: Any,
    *,
    console: Optional[Console] = None,
    title: str = "Object",
) -> None:
    """
    Pretty print any object to console with optional title.

    Args:
        obj: Object to print
        console: Optional Rich Console; if None, creates a new one
        title: Title for the output
    """
    console = console or Console()
    panel = Panel(
        Pretty(obj, expand_all=True, indent_guides=True),
        border_style="green",
        title=title,
        title_align="left",
        padding=(1, 2),
        expand=False,
    )
    console.print(panel)