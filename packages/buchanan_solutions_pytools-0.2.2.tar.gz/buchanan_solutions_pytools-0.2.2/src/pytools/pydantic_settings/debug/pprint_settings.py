# utils/pretty.py
from pydantic import BaseModel
from rich.console import Console
from rich.panel import Panel
from rich.text import Text
from rich.tree import Tree

from pytools.pydantic_settings.utils.internal import _add_model_to_tree


def pprint_settings(
    model: BaseModel,
    *,
    console: Console | None = None,
    title: str = "Settings",
) -> Panel:
    """
    Render settings in a blue-bordered rich Panel with grey text.
    """
    console = console or Console()
    root = Text.assemble(
        (model.__class__.__name__, "grey70"),
        (" configuration", "grey50"),
    )
    tree = Tree(root, guide_style="grey35")
    _add_model_to_tree(tree, model)

    panel = Panel(
        tree,
        border_style="blue",
        style="grey70",
        title=title,
        title_align="left",
        padding=(1, 2),
        expand=False,
    )

    console.print(panel)
    return panel
