# src/pytools/typer/utils.py

try:
    import typer
    from rich.console import Console
except ImportError:
    raise ImportError(
        "The 'typer' extra is required to use this module. "
        "Install it with: pip install 'pytools[typer]'"
    )