from typing import Optional
import typer
from pytools.typer.utils import get_from_ctx
from rich.console import Console


def debug_print(
    ctx: typer.Context,
    message: str,
    style: Optional[str] = None,
    *,
    debug: Optional[bool] = None,
    rich: Optional[bool] = None,
    console: Optional[Console] = None,
) -> None:
    """
    Print a debug message respecting debug and rich settings from context.

    Args:
        ctx: Typer context
        message: Message to print
        style: Rich style (e.g., "cyan", "green", "red")
        debug: Override debug flag from context
        rich: Override rich flag from context
        console: Optional Rich console to use; if None, one is created
    """
    debug = debug if debug is not None else get_from_ctx(ctx, "debug", bool)
    if not debug:
        return

    rich = rich if rich is not None else get_from_ctx(ctx, "rich", bool)
    if rich:
        console = console or Console()
        if style:
            console.print(f"[{style}]{message}[/{style}]")
        else:
            console.print(message)
    else:
        typer.echo(message)