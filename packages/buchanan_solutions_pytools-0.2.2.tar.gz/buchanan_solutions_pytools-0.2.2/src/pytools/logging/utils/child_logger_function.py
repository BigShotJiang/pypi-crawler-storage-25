import inspect
import logging


def child_logger_function(
    parent: logging.Logger | None = None, base_name: str | None = None
) -> logging.Logger:
    """
    Return a child logger with name parent.name + calling function name.
    If no parent is provided, defaults to __name__ + calling function name.
    """
    frame = inspect.currentframe().f_back
    func_name = frame.f_code.co_name

    base_logger = parent or logging.getLogger(
        base_name or frame.f_globals.get("__name__", "__main__")
    )
    return logging.getLogger(f"{base_logger.name}.{func_name}")
