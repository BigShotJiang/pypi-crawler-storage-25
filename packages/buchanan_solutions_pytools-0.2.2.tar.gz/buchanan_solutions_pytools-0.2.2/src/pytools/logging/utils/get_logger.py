import inspect
import logging


def get_logger():
    frame = inspect.currentframe().f_back
    func_name = frame.f_code.co_name
    mod_name = frame.f_globals["__name__"]
    return logging.getLogger(f"{mod_name}.{func_name}")
