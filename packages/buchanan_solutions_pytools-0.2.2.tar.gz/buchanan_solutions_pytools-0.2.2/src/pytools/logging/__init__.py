# src/shared/logging/__init__.py
"""Phased logging infrastructure: bootstrap → resolve → mutate → apply → export."""

import logging

from pytools.logging.apply import apply_config, apply_state
from pytools.logging.bootstrap import bootstrap
from pytools.logging.export import export_config
from pytools.logging.factories import default_console
from pytools.logging.formatters.level_color_formatter import LevelColorFormatter
from pytools.logging.formatters.styles import _LOGGER_STYLE
from pytools.logging.loggable import Loggable
from pytools.logging.mutate import (
    merge_logger_levels,
    merge_logger_specs,
    set_root_handlers,
    set_root_level,
)
from pytools.logging.one_shot import one_shot
from pytools.logging.resolve import resolve_logging_env_path
from pytools.logging.state import LoggingState

logging.getLogger("pytools.logging").setLevel(logging.WARNING)

__all__ = [
    "_LOGGER_STYLE",
    "one_shot",
    "LevelColorFormatter",
    "Loggable",
    "LoggingState",
    "apply_config",
    "apply_state",
    "bootstrap",
    "default_console",
    "export_config",
    "merge_logger_levels",
    "merge_logger_specs",
    "resolve_logging_env_path",
    "set_root_handlers",
    "set_root_level",
]
