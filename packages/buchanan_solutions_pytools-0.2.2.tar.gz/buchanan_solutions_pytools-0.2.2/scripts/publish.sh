#!/bin/bash
# ./scripts/publish.sh

set -euo pipefail

# Parse args: default to test env, use live env only with --live.
LIVE=false
for arg in "$@"; do
  case "$arg" in
    --live)
      LIVE=true
      ;;
    *)
      echo "Unknown argument: $arg" >&2
      echo "Usage: $0 [--live]" >&2
      exit 1
      ;;
  esac
done

# 1. Load the variables
ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
ENV_FILE="$ROOT_DIR/.env.test"
if [ "$LIVE" = true ]; then
  ENV_FILE="$ROOT_DIR/.env"
fi

if [ ! -f "$ENV_FILE" ]; then
  echo "Missing env file: $ENV_FILE" >&2
  exit 1
fi

set -a
source "$ENV_FILE"
set +a

# 2. Run publish
# We don't use -r test because HATCH_INDEX_REPO defines the target
hatch publish

# set -euo pipefail

# ENV_FILE="$(cd "$(dirname "$0")/.." && pwd)/.env"

# set -a
# source "$ENV_FILE"
# set +a

# hatch publish -r test