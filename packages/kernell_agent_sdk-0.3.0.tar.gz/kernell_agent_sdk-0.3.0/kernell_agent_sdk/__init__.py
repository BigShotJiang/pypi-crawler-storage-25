"""
Kernell OS Client Agent SDK
"""

__version__ = "0.1.0"

class LocalMemory:
    def __init__(self, db_path: str):
        self.db_path = db_path

class KernellAgent:
    def __init__(self, name: str, memory: LocalMemory, passport_key: str):
        self.name = name
        self.memory = memory
        self.passport_key = passport_key
        self.skills = []
        
    def add_skill(self, skill):
        self.skills.append(skill)
        
    def connect_to_kap(self, network: str = "mainnet"):
        print(f"Connecting {self.name} to Kernell Agent Protocol ({network})...")
        
    def listen(self):
        print(f"Agent {self.name} is now listening for KAP tasks...")

class KAPProtocol:
    pass
