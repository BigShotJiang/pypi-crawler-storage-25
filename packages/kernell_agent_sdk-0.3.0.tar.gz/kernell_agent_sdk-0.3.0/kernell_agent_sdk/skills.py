"""
Sandboxed Skills for Kernell Agent
"""

class BrowserAutomation:
    def __init__(self, headless: bool = True):
        self.headless = headless
        
class SecureTerminal:
    def __init__(self, allow_commands: list = None):
        self.allow_commands = allow_commands or []
