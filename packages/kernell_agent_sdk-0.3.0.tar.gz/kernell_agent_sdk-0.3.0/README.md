# ⚠️ Deprecation Notice

**`kernell-agent-sdk` has been merged into the monolithic `kernell-os-sdk`.**

Please install the full suite instead:

```bash
pip install kernell-os-sdk
```

All agent functionality, hardware binding, M2M commerce, and zero-trust sandbox features are now centralized in `kernell_os_sdk`. This package now serves as a proxy that automatically installs `kernell-os-sdk`.

Visit the new repository: [Kernell OS SDK](https://github.com/Greco-Italico/kernell-os-sdk)
