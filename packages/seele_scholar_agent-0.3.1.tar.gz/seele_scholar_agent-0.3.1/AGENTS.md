# AGENTS.md - Seele Scholar Agent

This file provides guidelines for AI agents working in this repository.

## Project Overview

- **Type**: Python 3.11+ LangGraph-based academic paper writing agent
- **Package Manager**: uv (recommended), pip
- **Location**: `src/seele_scholar_agent/`

## Build/Lint/Test Commands

### Installation
```bash
# Install all dependencies including dev
uv sync --extra dev

# Or with pip
pip install -e ".[dev]"
```

### Linting (Ruff)
```bash
# Check all source files
ruff check src/

# Fix auto-fixable issues
ruff check --fix src/
```

### Type Checking (MyPy)
```bash
# Run type checker
mypy src/

# With specific config (pyrightconfig.json)
pyright src/
```

### Testing (Pytest)
```bash
# Run all tests
pytest

# Run a single test file
pytest tests/test_graph.py

# Run tests matching a pattern
pytest -k "test_researcher"

# Run with verbose output
pytest -v

# Run async tests
pytest --asyncio-mode=auto
```

### Formatting
```bash
# Format code (if ruff format is added)
ruff format src/
```

### Build Package
```bash
# Build wheel
hatch build

# Or with uv
uv build
```

## Code Style Guidelines

### Python Version
- Minimum: Python 3.11
- Target: 3.11+ (check `pyproject.toml` `requires-python`)

### Line Length
- Max line length: **100 characters** (configured in `ruff`)

### Imports

**Order (per Ruff):**
1. Standard library (`import os`, `from typing import ...`)
2. Third-party (`import pytest`, `from langchain_openai import ...`)
3. Local (`from .module import ...`, `from seele_scholar_agent import ...`)

**Relative vs Absolute:**
- Within `seele_scholar_agent/` package: Use relative imports (`from ..config import ...`)
- External imports: Absolute imports (`from langchain_openai import ...`)

**Example:**
```python
# Standard library
import asyncio
from datetime import datetime
from typing import Any

# Third-party
from langchain_openai import ChatOpenAI
from pydantic import Field

# Local (relative)
from ..config import settings
from ..logging import get_logger
```

### Type Annotations

- **Required**: All function signatures must have type hints
- **Strict mode**: MyPy `strict = true` is enabled
- Use `from typing import ...` for complex types, PEP 604 union syntax (`str | None`) is allowed
- Use `TypedDict` for state dictionaries (see `state.py`)
- Use Pydantic `BaseModel` for data transfer objects

### Naming Conventions

| Type | Convention | Example |
|------|------------|---------|
| Classes | PascalCase | `class PaperMetadata` |
| Functions/methods | snake_case | `def search_papers()` |
| Variables | snake_case | `all_papers` |
| Constants | SCREAMING_SNAKE | `BASE_URL` |
| Type variables | PascalCase | `T = TypeVar('T')` |
| Private methods | _snake_case | `def _parse_response()` |

### Pydantic Models

- Use Pydantic v2 syntax (`model_config`, `Field()`)
- Use `Field(default_factory=list)` for mutable defaults
- Use `Literal` for enum-like string choices
- Example:
```python
class PaperMetadata(BaseModel):
    paper_id: str
    title: str
    authors: list[str]
    source: Literal["arxiv", "semantic_scholar", "openalex"] = "openalex"
    relevance_score: float = 0.0
```

### TypedDict for State

- Use `typing.Annotated` with `operator.add` for list accumulation in LangGraph
- Example from `state.py`:
```python
class AgentState(TypedDict):
    papers: Annotated[list[PaperMetadata], operator.add]
    status: Literal["idle", "researching", "planning", ...]
```

### Error Handling

- Use structured logging via `structlog` (see `logging.py`)
- Never use bare `except:`
- Always log errors with context
- Example:
```python
try:
    result = await client.get(url)
except HTTPStatusError as e:
    logger.error("API request failed", status=e.response.status_code, error=str(e))
    return []
```

### Logging

- Use `get_logger(__name__)` from `seele_scholar_agent.logging`
- Use structured logging (JSON format)
- Log levels: DEBUG for dev details, INFO for operations, WARNING/ERROR for issues
- Example:
```python
from ..logging import get_logger

logger = get_logger(__name__)
logger.info("Processing papers", count=len(papers), topic=topic)
```

### Async Code

- Use `async/await` consistently
- Use `asyncio` for sleep/delays
- Use `httpx.AsyncClient` for HTTP requests
- Configure pytest with `asyncio_mode = "auto"` in `pyproject.toml`

### Docstrings

- Use triple quotes `"""` for module/class/function docs
- Keep concise but informative
- Example:
```python
class ArxivRetriever:
    """Retrieves papers from ArXiv API."""

    def __init__(self, top_k: int = 10):
        self.top_k = top_k
```

## Project Structure

```
src/seele_scholar_agent/
├── __init__.py          # Public API exports
├── config.py            # Settings via pydantic-settings
├── state.py             # TypedDict AgentState + Pydantic models
├── graph.py             # LangGraph workflow definitions
├── logging.py           # structlog configuration
├── nodes/
│   ├── __init__.py
│   ├── planner.py       # Outline planning node
│   ├── researcher.py    # Paper retrieval (ArXiv, OpenAlex, Semantic Scholar)
│   ├── writer.py        # Section writing node
│   ├── reviewer.py      # AI review node
│   └── prompts.py       # LLM prompt templates
└── tools/
    └── retriever.py     # Retrieval utilities
```

## Key Dependencies

- **langgraph**: Workflow orchestration
- **pydantic**: Data validation
- **structlog**: Structured logging
- **httpx**: Async HTTP client
- **langchain-***: LLM integration

## Configuration

Environment variables are loaded from `.env` file (see `.env.example`):
- `OPENAI_API_KEY`: LLM API key (required)
- `OPENAI_MODEL`: Model name (default: `gpt-4o`)
- `OPENAI_BASE_URL`: API endpoint
- `MAX_REVISIONS`: Max review cycles (default: 3)

## Testing Guidelines

- Tests go in `tests/` directory (create if missing)
- Use `pytest` with `pytest-asyncio`
- Mock external API calls when possible
- Test file naming: `test_<module>.py`
