# 使用指南：seele-scholar-agent

`seele-scholar-agent` 是一个基于 LangGraph 的学术论文写作智能体。本指南将介绍如何在你的 Python 项目中集成并使用该包。

## 1. 安装

在你的项目中安装 `seele-scholar-agent`：

```bash
pip install seele-scholar-agent
# 或者使用 uv
uv add seele-scholar-agent
```

## 2. 快速开始

要使用该智能体，你需要提供一个兼容 OpenAI API 的 LLM 实例。

### 基础用法

```python
import asyncio
from uuid import uuid4
from datetime import datetime
from langchain_openai import ChatOpenAI
from seele_scholar_agent.graph import create_writing_graph
from seele_scholar_agent.state import AgentState

async def run_agent():
    # 1. 初始化模型
    model = ChatOpenAI(
        model="gpt-4o",
        api_key="your-api-key",
        base_url="https://api.openai.com/v1"
    )

    # 2. 创建写作图
    app = create_writing_graph(model=model)

    # 3. 准备初始状态
    initial_state: AgentState = {
        "thread_id": str(uuid4()),
        "topic": "深度学习在医学影像中的应用",
        "created_at": datetime.now(),
        # ... 其他必要字段，参考 AgentState 定义
    }

    # 4. 运行
    result = await app.ainvoke(
        initial_state,
        config={"configurable": {"thread_id": initial_state["thread_id"]}}
    )
    print(f"状态: {result.get('status')}")

if __name__ == "__main__":
    asyncio.run(run_agent())
```

## 3. 核心 API 说明

### `create_writing_graph(model, qdrant_client=None, embedding_model=None, ...)`

创建一个包含完整工作流（检索 -> 规划 -> 撰写 -> 审核）的 LangGraph 应用。

**参数：**
- `model` (ChatOpenAI): 必需。用于生成内容的 LLM。
- `qdrant_client` (Optional): 用于 RAG 的 Qdrant 客户端。
- `embedding_model` (Optional): 用于 RAG 的嵌入模型。
- `semantic_scholar_key` (Optional): Semantic Scholar API 密钥。
- `openalex_email` (Optional): OpenAlex API 邮箱。

**返回：**
- `CompiledStateGraph`: 可执行的 LangGraph 应用。

### `create_simple_writing_graph(...)`

与 `create_writing_graph` 类似，但工作流中不包含人工审核断点，适合自动化测试或快速生成。

## 4. 状态管理 (AgentState)

智能体通过 `AgentState` 管理工作流状态。在调用 `ainvoke` 时，你需要提供一个符合 `AgentState` 结构的字典。

主要字段包括：
- `topic`: 研究主题。
- `prompt`: 自定义提示词（可选）。
- `papers`: 检索到的论文列表。
- `outline`: 生成的大纲结构。
- `sections`: 章节列表。
- `status`: 当前工作流状态（如 `idle`, `writing`, `completed` 等）。

## 5. 配置

你可以通过环境变量配置智能体的行为，或者直接在代码中通过 `seele_scholar_agent.config.settings` 访问配置。

| 环境变量 | 说明 |
| :--- | :--- |
| `OPENAI_API_KEY` | OpenAI API 密钥 |
| `OPENAI_MODEL` | 使用的模型名称 |
| `MAX_REVISIONS` | 最大修订轮次 |
| `DEFAULT_TOP_K` | 默认搜索结果数量 |
