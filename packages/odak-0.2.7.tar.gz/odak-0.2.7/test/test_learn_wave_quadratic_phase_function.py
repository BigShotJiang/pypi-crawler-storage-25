import sys
import os
import odak
import torch


def test(
    resolution=[250, 250],
    wavelengths=[639e-9, 515e-9, 473e-9],
    pixel_pitch=3.74e-6,
    number_of_frames=3,
    number_of_depth_layers=10,
    volume_depth=1e-2,
    image_location_offset=3e-2,
    propagation_type="Bandlimited Angular Spectrum",
    propagator_type="forward",
    laser_channel_power=torch.tensor(
        [
            [1.0, 0.0, 0.0],
            [0.0, 1.0, 0.0],
            [0.0, 0.0, 1.0],
        ]
    ),
    offsets=[[-20, -20], [0, 0], [30, 50]],
    lens_focus=[28e-3, 30e-3, 32e-3],
    aperture=None,
    aperture_size=None,
    method="conventional",
    device=torch.device("cpu"),
    output_directory="test_output",
):
    odak.tools.check_directory(output_directory)
    hologram_phases = torch.zeros(
        number_of_frames, resolution[0], resolution[1], device=device
    )
    hologram_amplitudes = torch.ones(
        number_of_frames, resolution[0], resolution[1], device=device
    )
    for frame_id in range(number_of_frames):
        wavelength = wavelengths[frame_id]
        k = odak.learn.wave.wavenumber(wavelength)
        lens_complex = odak.learn.wave.quadratic_phase_function(
            nx=resolution[0],
            ny=resolution[1],
            k=k,
            focal=lens_focus[frame_id],
            dx=pixel_pitch,
            offset=offsets[frame_id],
        )
        lens_phase = odak.learn.wave.calculate_phase(lens_complex).to(device).unsqueeze(
            0
        ) % (2.0 * torch.pi)
        hologram_phases[frame_id] = lens_phase
    odak.learn.tools.save_image(
        "{}/lens_phase.png".format(output_directory),
        hologram_phases,
        cmin=0.0,
        cmax=2.0 * torch.pi,
    )
    propagator = odak.learn.wave.propagator(
        resolution=resolution,
        wavelengths=wavelengths,
        pixel_pitch=pixel_pitch,
        number_of_frames=number_of_frames,
        number_of_depth_layers=number_of_depth_layers,
        volume_depth=volume_depth,
        image_location_offset=image_location_offset,
        propagation_type=propagation_type,
        propagator_type=propagator_type,
        laser_channel_power=laser_channel_power,
        aperture_size=aperture_size,
        aperture=aperture,
        method=method,
        device=device,
    )
    reconstruction_intensities = propagator.reconstruct(
        hologram_phases=hologram_phases, amplitude=hologram_amplitudes
    )
    reconstruction_intensities_rgb = torch.sum(reconstruction_intensities, dim=0)
    for frame_id in range(reconstruction_intensities.shape[0]):
        for depth_id in range(reconstruction_intensities.shape[1]):
            reconstruction_intensity = reconstruction_intensities[frame_id, depth_id]
            odak.learn.tools.save_image(
                "{}/lens_reconstruction_image_{:03d}_{:03d}.png".format(
                    output_directory, frame_id, depth_id
                ),
                reconstruction_intensity,
                cmin=0.0,
                cmax=reconstruction_intensities.max(),
            )
            reconstruction_intensity = reconstruction_intensities_rgb[depth_id]
            odak.learn.tools.save_image(
                "{}/lens_reconstruction_image_rgb_{:03d}.png".format(
                    output_directory, depth_id
                ),
                reconstruction_intensity,
                cmin=0.0,
                cmax=reconstruction_intensities_rgb.max(),
            )

    assert True == True


if __name__ == "__main__":
    sys.exit(test())
