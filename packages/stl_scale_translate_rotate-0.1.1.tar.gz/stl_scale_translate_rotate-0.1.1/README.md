# stl_scale_translate_rotate
translate, scale or rotate stl 3d model, then saved it to .stl file.

## Installation

```bash
pip install stl_scale_translate_rotate
```

## Usage

```python
from stl_scale_translate_rotate import stl_scale
from stl_scale_translate_rotate import stl_translate
from stl_scale_translate_rotate import stl_rotate_quaternion

STL_PATH = "input_filepath.stl"
EXPORT_PATH = "output_filepath.stl"

# Enlarge two times
stl_scale(STL_PATH, 2.0, EXPORT_PATH)

# Move model
stl_translate(STL_PATH, [1.0, 2.0, 3.0], EXPORT_PATH)

# Rotate model by quaternion
stl_rotate_quaternion(STL_PATH, [0.7492992877960205, 0.601024329662323, -0.1564661413431168, 0.2298665046691895], EXPORT_PATH)
```
