import os
import trimesh
import trimesh.transformations as transformations


def stl_translate(
        input_stl_path: str,
        translate_vec: list[float],
        export_stl_path: str):
    """
    Make translation on a stl model then save it to new path.

    Args:
        input_stl_path (str): input stl path.
        translate_vec (list[float]): a 3d translation vector [x, y, z].
        export_stl_path (str): output stl path.
    """

    if not os.path.isfile(input_stl_path):
        raise FileNotFoundError(f"{input_stl_path} is not an available stl file.")

    if not isinstance(translate_vec, list):
        raise TypeError("translate_vec must be a list.")

    if len(translate_vec) != 3:
        raise ValueError("Length of translate_vec must be three.")

    for item in translate_vec:
        if not isinstance(item, int) and not isinstance(item, float):
            raise TypeError("Item of translate_vec must be int or float.")

    # Load Model
    mesh = trimesh.load(input_stl_path)

    # Translate
    mesh.apply_translation(translate_vec)

    # Save it back
    mesh.export(export_stl_path)


def stl_scale(
        input_stl_path: str,
        scale_factor: float,
        export_stl_path: str):
    """
    Apply uniform scaling to an STL model then save to a new path.

    Args:
        input_stl_path (str): Input STL file path.
        scale_factor (float): Uniform scaling factor (greater than 1 = enlarge, less than 1 = shrink).
        export_stl_path (str): Output STL file path.
    """

    if not os.path.isfile(input_stl_path):
        raise FileNotFoundError(f"{input_stl_path} is not an available STL file.")

    if not isinstance(scale_factor, (int, float)):
        raise TypeError("scale_factor must be int or float.")

    # Load model
    mesh = trimesh.load(input_stl_path)

    # Apply uniform scaling
    mesh.apply_scale(scale_factor)

    # Export scaled model
    mesh.export(export_stl_path)


def stl_rotate_quaternion(
        input_stl_path: str,
        quaternion: list[float],
        export_stl_path: str):
    """
    Rotate an STL model around origin using quaternion, then save to new path.
    Quaternion format: [w, x, y, z]

    Args:
        input_stl_path (str): Input STL file path.
        quaternion (list[float]): Quaternion [w, x, y, z].
        export_stl_path (str): Output STL file path.
    """

    if not os.path.isfile(input_stl_path):
        raise FileNotFoundError(f"{input_stl_path} is not an available stl file.")

    if not isinstance(quaternion, list):
        raise TypeError("quaternion must be a list.")

    if len(quaternion) != 4:
        raise ValueError("Length of quaternion must be four [w, x, y, z].")

    for item in quaternion:
        if not isinstance(item, (int, float)):
            raise TypeError("Items in quaternion must be int or float.")

    # Load model
    mesh = trimesh.load(input_stl_path)

    # Convert quaternion to rotation matrix
    rot_matrix = transformations.quaternion_matrix(quaternion)

    # Apply rotation (around origin)
    mesh.apply_transform(rot_matrix)

    # Export rotated model
    mesh.export(export_stl_path)
