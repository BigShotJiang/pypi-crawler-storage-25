# SPDX-FileCopyrightText: UL Research Institutes
# SPDX-License-Identifier: Apache-2.0

import io

import pytest
import ruamel.yaml
from ruamel.yaml.scalarstring import FoldedScalarString

from cici.providers.gitlab.yaml_style import (
    get_fold_positions,
    make_scalar_string,
    style_scalars,
)


# test the folding when handling string literals
@pytest.mark.parametrize(
    "command_text",
    [
        # long command with pipe
        "toolA subcommand with many flags and arguments that make this command exceed "
        "a typical width threshold | toolB --option value --another-option something",
        # long command with multiple pipes
        "cmd1 --foo bar --baz qux | cmd2 --long-option here | cmd3 --final-stage",
        # long command without pipe
        "someverylongcommandname with a lot of arguments and flags that keeps going "
        "and going and going until it is clearly longer than any sane line width",
        # command with && and ;
        "step1 --flag value && step2 --another value ; step3 --final",
    ],
    ids=[
        "long-command-with-pipe",
        "long-command-with-multiple-pipes",
        "long-command-no-pipe",
        "long-command-with-operators",
    ],
)
def test_styled_command_has_no_semantic_newlines(command_text):
    styled = make_scalar_string(command_text)

    # If folding is used, it must be display-only
    if isinstance(styled, FoldedScalarString):
        assert "\n" not in str(styled), (
            "FoldedScalarString must not contain real newlines; "
            "folding must be display-only"
        )


# make sure ruamel dumping never prints the blank line
@pytest.mark.parametrize(
    "command_text",
    [
        "toolA subcommand with many flags and arguments that make this command exceed "
        "a typical width threshold | toolB --option value --another-option something",
        "cmd1 --foo bar --baz qux | cmd2 --long-option here | cmd3 --final-stage",
        "someverylongcommandname with a lot of arguments and flags that keeps going "
        "and going and going until it is clearly longer than any sane line width",
    ],
    ids=[
        "yaml-dump-no-blank-line-case1",
        "yaml-dump-no-blank-line-case2",
        "yaml-dump-no-blank-line-case3",
    ],
)
def test_yaml_dump_has_no_blank_line_in_folded_scalar(command_text):
    styled = make_scalar_string(command_text)

    data = {
        "job": {
            "script": [styled, "echo ok"],
        }
    }

    yaml = ruamel.yaml.YAML(typ="rt")
    yaml.width = 120
    yaml.indent(mapping=2, sequence=4, offset=2)
    yaml.default_flow_style = False

    out = io.StringIO()
    yaml.dump(data, out)
    emitted = out.getvalue()

    lines = emitted.splitlines()

    # Find folded scalar start
    try:
        folded_start = next(
            i for i, line in enumerate(lines) if line.strip() in ("- >-", "- >")
        )
    except StopIteration:
        pytest.skip("No folded scalar emitted; nothing to assert")

    # Inspect a small window of the folded block
    folded_block = lines[folded_start : folded_start + 8]

    # Regression guard: no visually empty line inside folded scalar
    assert not any(line.strip() == "" for line in folded_block[1:]), "\n".join(
        folded_block
    )


@pytest.mark.parametrize(
    "command",
    [
        # generic echo | docker login case
        'echo "password" | docker login "registry" -u "user" --password-stdin',
        # generic long piped command
        'echo "token" | some-tool login --flag-a --flag-b --flag-c --flag-d',
        # generic curl | tar example
        "curl https://example.com/archive.tar.gz | tar -C /usr/local/bin -xzf -",
    ],
    ids=[
        "echo-pipe-docker-login",
        "echo-pipe-generic-tool",
        "curl-pipe-tar",
    ],
)
def test_folded_scalar_does_not_insert_blank_lines(command):
    """
    Folded scalars should:
    - contain no semantic newlines
    - fold visually using >-
    - not introduce blank lines in YAML output
    """

    scalar = make_scalar_string(command)

    # 1. Value must not contain semantic newlines
    assert isinstance(scalar, FoldedScalarString)
    assert "\n" not in str(scalar)

    # 2. Dump YAML
    yaml = ruamel.yaml.YAML()
    yaml.width = 120

    data = {"script": [scalar]}
    stream = io.StringIO()
    yaml.dump(data, stream)
    output = stream.getvalue()

    # 3. Must be folded
    assert ">-" in output

    # 4. Must not contain blank line inside folded block
    # (blank line would show up as double newline)
    assert "\n\n" not in output

    # 5. The command must still appear intact
    for part in command.split():
        assert part in output


def get_path(obj, path: str):
    """Traverse dict/list using dotted paths and [index] access.

    Examples:
      - "job.image"
      - "job.rules[0].if"
      - "job.script[1]"
      - "job.variables.GIT_DEPTH"
    """
    cur = obj
    for part in path.split("."):
        if "[" in part:
            # e.g. rules[0]
            key, rest = part.split("[", 1)
            idx = int(rest.rstrip("]"))
            cur = cur[key][idx]
        else:
            cur = cur[part]
    return cur


@pytest.mark.parametrize(
    "input_data, expected_paths",
    [
        pytest.param(
            {
                "job": {
                    "image": "alpine:3.19",
                    "variables": {
                        "GIT_DEPTH": {"value": "1"},
                        "TOKEN": {"value": "$TOKEN"},
                        "PATHS": {"value": "/certs"},
                    },
                    "script": [
                        'echo "token" | docker login registry -u user --password-stdin',
                        "FOO=bar",
                        "echo ok",
                    ],
                    "rules": [{"if": '$CI_COMMIT_BRANCH == "main"', "when": "always"}],
                    "environment": {"name": "$STATE/apply", "action": "stop"},
                }
            },
            {
                "job.image": "alpine:3.19",
                "job.variables.GIT_DEPTH": "1",
                "job.variables.TOKEN": "$TOKEN",
                "job.variables.PATHS": "/certs",
                "job.script[1]": "FOO=bar",
                "job.rules[0].if": '$CI_COMMIT_BRANCH == "main"',
                "job.environment.name": "$STATE/apply",
                "job.environment.action": "stop",
            },
            id="generic-job-case",
        ),
        pytest.param(
            {
                "job": {
                    "image": "alpine",
                    "script": ["echo hello"],
                }
            },
            {
                "job.image": "alpine",
                "job.script[0]": "echo hello",
            },
            id="minimal-generic-case",
        ),
    ],
)
def test_style_scalars(input_data, expected_paths):

    # send input_data through style_scalars() function
    styled = style_scalars(input_data)

    # send the now styled input_data through the dump() function
    y = ruamel.yaml.YAML()
    y.width = 120
    y.indent(mapping=2, sequence=4, offset=2)

    buf = io.StringIO()
    y.dump(styled, buf)
    emitted = buf.getvalue()

    # parse back the dumped output like GitLab would
    parsed = ruamel.yaml.YAML(typ="safe").load(emitted)

    # read the nested values and compare to expected
    for path, expected in expected_paths.items():
        assert get_path(parsed, path) == expected, f"path {path!r} mismatched"

    # just make sure no blank lines in any folded blocks
    # I already test for this in test_folded_scalar_does_not_insert_blank_lines()
    assert "\n\n" not in emitted


@pytest.mark.parametrize(
    "long_string, width, fold_pos",
    [
        (
            "0123456789012345678901234567890123456789",
            10,
            [],
        ),
        (
            "0 1 2 3 4",
            10,
            [],
        ),
        (
            "012345678901 23456 789012",
            10,
            [12, 18],
        ),
        (
            "012345678 9012345678901234 56789",
            10,
            [9, 26],
        ),
        (
            "012345678 90123456 7890123456789",
            10,
            [9, 18],
        ),
        (
            "0123456789 0123456789 0123456789 0123456789",
            10,
            [10, 21, 32],
        ),
        (
            "0123456789 0123456789 0123456789 01234567890123456789 "
            "01234567890123456789 01234567890123456789 0123b567890123456789 "
            "01234567890123456789 01234567890123456789 01234567890123456789",
            120,
            [116],
        ),
    ],
    ids=[
        "no-spaces",
        "shorter-than-width",
        "start-longer-than-width",
        "middle-longer-than-width",
        "end-longer-than-width",
        "space-every-width",
        "long-width",
    ],
)
def test_get_fold_positions(long_string, width, fold_pos):
    assert get_fold_positions(long_string, width) == fold_pos

    # It is easier to visually inspect folded strings so print
    # folded strings to check fold_pos values
    folded = FoldedScalarString(long_string)
    folded.fold_pos = fold_pos

    y = ruamel.yaml.YAML()
    y.width = width
    buf = io.StringIO()
    y.dump(folded, buf)
    emitted = buf.getvalue()

    assert ">-\n" == emitted[:3]
    emitted = emitted[3:]
    # after removing >-\n, emitted should be long_string + \n
    assert len(emitted) == len(long_string) + 1
    for i in range(len(long_string)):
        print(f"{i} - {emitted[i]}")
        if i in fold_pos:
            assert emitted[i] == "\n"
        else:
            assert emitted[i] != "\n"
