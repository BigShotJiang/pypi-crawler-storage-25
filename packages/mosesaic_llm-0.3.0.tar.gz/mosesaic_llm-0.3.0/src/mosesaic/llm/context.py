from __future__ import annotations

import asyncio
import logging
from typing import TYPE_CHECKING, Any

import anyio

from mosesaic.llm.provider import LLMMessage, LLMResponse

if TYPE_CHECKING:
    from mosesaic.core.cost import AgentCostEvent, CostTracker
    from mosesaic.llm.registry import ProviderRegistry

log = logging.getLogger(__name__)

# How long to wait between retries on rate-limit (seconds): 2, 4, 8, 16, 32
_BACKOFF = [2, 4, 8, 16, 32]

# Max continuation rounds to stitch together a truncated response
_MAX_CONTINUATIONS = 4


def _is_rate_limit(exc: BaseException) -> bool:
    """Return True if the exception looks like a provider rate-limit (429)."""
    name = type(exc).__name__.lower()
    msg = str(exc).lower()
    return (
        "ratelimit" in name
        or "rate_limit" in name
        or "429" in msg
        or "rate limit" in msg
        or "too many requests" in msg
    )


def _is_overload(exc: BaseException) -> bool:
    """Return True if the provider is overloaded (529, 503)."""
    msg = str(exc).lower()
    return "overloaded" in msg or "529" in msg or "503" in msg or "service unavailable" in msg


class LLMContext:
    """The ``ctx.llm`` interface available to agents.

    Wraps the provider registry and cost tracker so agent code never imports
    provider SDKs or tracks costs manually.

    Resilience strategy (applied automatically on every chat() call):
    - Rate-limit / overload: exponential backoff (2→4→8→16→32 s), then try next provider
    - Provider error: immediately try next provider by task_hint ranking
    - Truncation (finish_reason == max_tokens): send continuation messages until complete
    - All providers exhausted: raises the last error — never silently drops the call

    Usage (inside an agent):
        response = await ctx.llm.chat(
            messages=[{"role": "user", "content": "Summarise this..."}],
            task_hint="extraction",
            budget_usd=0.02,
        )
        print(response.content)
    """

    def __init__(
        self,
        registry: ProviderRegistry,
        cost_tracker: CostTracker,
        agent_name: str,
        system_prompt: str | None = None,
        preferred_model: str | None = None,
    ) -> None:
        self._registry = registry
        self._cost_tracker = cost_tracker
        self._agent_name = agent_name
        self._system_prompt = system_prompt
        self._preferred_model = preferred_model

    # ── Public API ─────────────────────────────────────────────────────────────

    async def chat(
        self,
        messages: list[dict[str, str]] | list[LLMMessage],
        task_hint: str = "general",
        budget_usd: float | None = None,
        require: list[str] | None = None,
        max_tokens: int = 4096,
        **kwargs: Any,
    ) -> LLMResponse:
        """Send a chat request to the best available model, with full resilience.

        Args:
            messages: List of {"role": ..., "content": ...} dicts or LLMMessage objects.
            task_hint: Routing hint — "reasoning", "extraction", "vision", "cheap", "general".
            budget_usd: Hard cap for this single call. Raises if estimated cost exceeds it.
            require: List of required capabilities, e.g. ["vision"], ["tools", "thinking"].
            max_tokens: Maximum output tokens per call. Continuation calls use the same limit.

        Returns:
            LLMResponse with content, token counts, and actual cost_usd.
            If the response was truncated, continuation is handled transparently.

        Raises:
            MosesaicBudgetExceeded: If this call would exceed the agent's total budget.
            ValueError: If no model satisfies the routing constraints.
            RuntimeError: If all providers fail after all retries.
        """
        normalised = self._normalise(messages)
        model_id, provider = self._select_model(task_hint, budget_usd, require, max_tokens)

        # Build ranked fallback list (best first), excluding already-selected model
        fallbacks = self._ranked_fallbacks(task_hint, budget_usd, require, max_tokens, exclude=model_id)
        candidates = [(model_id, provider)] + fallbacks

        last_exc: BaseException | None = None

        for mid, prov in candidates:
            response = await self._call_with_retry(prov, mid, normalised, max_tokens, kwargs)
            if isinstance(response, BaseException):
                last_exc = response
                log.warning(
                    "Provider %s/%s failed (%s), trying next candidate.",
                    prov.name, mid, response,
                )
                continue

            # Handle truncation — stitch continuation responses transparently
            if response.finish_reason == "max_tokens":
                response = await self._continue(prov, mid, normalised, response, max_tokens, kwargs)

            self._record(mid, prov, response)
            return response

        raise RuntimeError(
            f"All providers failed for agent={self._agent_name!r}, "
            f"task_hint={task_hint!r}. Last error: {last_exc}"
        ) from last_exc

    # ── Internal helpers ───────────────────────────────────────────────────────

    def _normalise(self, messages: list) -> list[LLMMessage]:
        """Prepend system prompt and normalise to LLMMessage list."""
        result: list[LLMMessage] = []
        if self._system_prompt:
            result.append(LLMMessage(role="system", content=self._system_prompt))
        for m in messages:
            if isinstance(m, dict):
                result.append(LLMMessage(role=m["role"], content=m["content"]))
            else:
                result.append(m)
        return result

    def _select_model(self, task_hint, budget_usd, require, max_tokens):
        """Select primary model — pinned if preferred_model set, otherwise routed."""
        if self._preferred_model is not None:
            model_id = self._preferred_model
            try:
                for mid, prov, _ in self._registry.iter_models():
                    if mid == model_id:
                        return model_id, prov
            except AttributeError:
                pass
            raise ValueError(
                f"preferred_model={model_id!r} is not registered in the ProviderRegistry."
            )
        return self._registry.find(
            task_hint=task_hint,
            budget_usd=budget_usd,
            require=require or [],
            max_output_tokens=max_tokens,
        )

    def _ranked_fallbacks(self, task_hint, budget_usd, require, max_tokens, exclude):
        """Return all other models ranked by score, excluding the primary."""
        from mosesaic.llm.registry import _provider_tier
        candidates = []
        try:
            iter_fn = self._registry.iter_models()
        except AttributeError:
            return []  # mock registry without iter_models — no fallbacks
        for mid, prov, caps in iter_fn:
            if mid == exclude:
                continue
            if not caps.supports(require or []):
                continue
            if budget_usd is not None:
                if caps.estimate_cost(4096, max_tokens) > budget_usd:
                    continue
            tier = _provider_tier(prov.name, task_hint)
            cost = caps.cost_per_1m_input + caps.cost_per_1m_output
            score = tier * 10_000 + cost
            candidates.append((score, mid, prov))
        candidates.sort(key=lambda x: x[0])
        return [(mid, prov) for _, mid, prov in candidates]

    async def _call_with_retry(self, provider, model_id, messages, max_tokens, kwargs) -> LLMResponse | BaseException:
        """Try one provider with exponential backoff on rate-limit / overload errors.

        Returns the response on success, or the last exception on total failure.
        Raises MosesaicBudgetExceeded immediately — never treats it as a provider failure.
        """
        # Budget check before calling — re-raise immediately, never treat as provider failure
        caps = self._registry.all_models().get(model_id)
        estimated = caps.estimate_cost(4096, max_tokens) if caps else 0.0
        self._cost_tracker.check_before_call(
            estimated_cost_usd=estimated,
            call_description=f"llm.chat({model_id})",
        )

        last_exc: BaseException | None = None
        for attempt, wait in enumerate([0] + _BACKOFF):
            if wait:
                log.info(
                    "Rate-limit on %s/%s — waiting %ds (attempt %d).",
                    provider.name, model_id, wait, attempt,
                )
                await anyio.sleep(wait)
            try:
                return await provider.chat(
                    model=model_id,
                    messages=messages,
                    max_tokens=max_tokens,
                    **kwargs,
                )
            except BaseException as exc:
                last_exc = exc
                if _is_rate_limit(exc) or _is_overload(exc):
                    continue   # retry with backoff
                return exc     # non-retriable error — try next provider

        return last_exc  # exhausted all retries for this provider

    async def _continue(self, provider, model_id, original_messages, first_response, max_tokens, kwargs) -> LLMResponse:
        """Stitch continuation responses when the model hit max_tokens.

        Sends follow-up messages asking the model to continue until it stops
        naturally or we hit _MAX_CONTINUATIONS rounds.
        """
        accumulated = first_response.content
        total_input = first_response.input_tokens
        total_output = first_response.output_tokens
        total_cost = first_response.cost_usd
        conversation = list(original_messages)

        for _ in range(_MAX_CONTINUATIONS):
            # Append assistant turn + continuation prompt
            conversation.append(LLMMessage(role="assistant", content=accumulated))
            conversation.append(LLMMessage(
                role="user",
                content="Continue exactly from where you stopped. Do not repeat anything already written.",
            ))

            try:
                part = await provider.chat(
                    model=model_id,
                    messages=conversation,
                    max_tokens=max_tokens,
                    **kwargs,
                )
            except BaseException as exc:
                log.warning("Continuation call failed (%s) — returning partial response.", exc)
                break

            accumulated += part.content
            total_input += part.input_tokens
            total_output += part.output_tokens
            total_cost += part.cost_usd

            if part.finish_reason != "max_tokens":
                break   # natural stop — done

        return LLMResponse(
            content=accumulated,
            model=model_id,
            input_tokens=total_input,
            output_tokens=total_output,
            cost_usd=total_cost,
            finish_reason="stop",
        )

    def _record(self, model_id: str, provider, response: LLMResponse) -> None:
        """Record cost and emit progress event."""
        from mosesaic.core.cost import AgentCostEvent
        self._cost_tracker.record(AgentCostEvent(
            agent_name=self._agent_name,
            model=model_id,
            input_tokens=response.input_tokens,
            output_tokens=response.output_tokens,
            cost_usd=response.cost_usd,
            trace_id=str(id(self)),
        ))

        from mosesaic.core.progress import emit_progress, ProgressEvent
        emit_progress(ProgressEvent(
            type="llm_call",
            agent=self._agent_name,
            model=model_id,
            provider=provider.name,
            input_tokens=response.input_tokens,
            output_tokens=response.output_tokens,
            cost_usd=response.cost_usd,
        ))
