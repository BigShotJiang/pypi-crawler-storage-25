from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any


@dataclass
class Capabilities:
    """What a model can do and what it costs."""

    vision: bool = False
    tools: bool = False
    thinking: bool = False
    context_k: int = 8          # context window in thousands of tokens
    cost_per_1m_input: float = 0.0
    cost_per_1m_output: float = 0.0

    def supports(self, requirements: list[str]) -> bool:
        """Return True if this model satisfies all listed capability requirements."""
        for req in requirements:
            if not getattr(self, req, False):
                return False
        return True

    def estimate_cost(self, input_tokens: int, output_tokens: int) -> float:
        return (
            input_tokens / 1_000_000 * self.cost_per_1m_input
            + output_tokens / 1_000_000 * self.cost_per_1m_output
        )


@dataclass
class LLMMessage:
    """A single message in a conversation."""

    role: str   # "system" | "user" | "assistant"
    content: str


@dataclass
class LLMResponse:
    """The result of a ctx.llm.chat() call."""

    content: str
    model: str
    input_tokens: int
    output_tokens: int
    cost_usd: float
    raw: Any = None                 # provider-specific response object
    finish_reason: str = "stop"     # "stop" | "max_tokens" | "error"


class LLMProvider(ABC):
    """Abstract base for all LLM providers.

    Subclasses implement _chat() for a specific SDK (Anthropic, OpenAI, etc.).
    Never call provider SDKs from agent code — use ctx.llm.chat() instead.
    """

    @property
    @abstractmethod
    def name(self) -> str:
        """Provider name, e.g. 'anthropic', 'openai', 'ollama'."""

    @property
    @abstractmethod
    def models(self) -> dict[str, Capabilities]:
        """Map of model ID → Capabilities."""

    @abstractmethod
    async def chat(
        self,
        model: str,
        messages: list[LLMMessage],
        max_tokens: int = 4096,
        **kwargs: Any,
    ) -> LLMResponse:
        """Call the LLM and return a structured response."""
