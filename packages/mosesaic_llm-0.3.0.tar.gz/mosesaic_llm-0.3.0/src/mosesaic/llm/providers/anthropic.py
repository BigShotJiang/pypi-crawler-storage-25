from __future__ import annotations

from typing import Any

from mosesaic.llm.provider import Capabilities, LLMMessage, LLMProvider, LLMResponse

# Pricing as of 2026 (per 1M tokens)
_ANTHROPIC_MODELS: dict[str, Capabilities] = {
    "claude-opus-4-6": Capabilities(
        vision=True, tools=True, thinking=True,
        context_k=200, cost_per_1m_input=15.00, cost_per_1m_output=75.00,
    ),
    "claude-sonnet-4-6": Capabilities(
        vision=True, tools=True, thinking=True,
        context_k=200, cost_per_1m_input=3.00, cost_per_1m_output=15.00,
    ),
    "claude-haiku-4-5": Capabilities(
        vision=True, tools=True, thinking=False,
        context_k=200, cost_per_1m_input=0.80, cost_per_1m_output=4.00,
    ),
}


class AnthropicProvider(LLMProvider):
    """LLM provider backed by the Anthropic API.

    Usage:
        registry = ProviderRegistry()
        registry.register(AnthropicProvider(api_key=os.environ["ANTHROPIC_API_KEY"]))

    The api_key defaults to the ANTHROPIC_API_KEY environment variable if not passed.
    """

    def __init__(
        self,
        api_key: str | None = None,
        extra_models: dict[str, Capabilities] | None = None,
    ) -> None:
        import anthropic
        self._client = anthropic.AsyncAnthropic(api_key=api_key)
        self._models = {**_ANTHROPIC_MODELS, **(extra_models or {})}

    @property
    def name(self) -> str:
        return "anthropic"

    @property
    def models(self) -> dict[str, Capabilities]:
        return self._models

    async def chat(
        self,
        model: str,
        messages: list[LLMMessage],
        max_tokens: int = 4096,
        **kwargs: Any,
    ) -> LLMResponse:
        # Separate system message from conversation
        system: str | None = None
        conversation: list[dict] = []
        for msg in messages:
            if msg.role == "system":
                system = msg.content
            else:
                conversation.append({"role": msg.role, "content": msg.content})

        call_kwargs: dict[str, Any] = {
            "model": model,
            "max_tokens": max_tokens,
            "messages": conversation,
        }
        if system:
            call_kwargs["system"] = system

        response = await self._client.messages.create(**call_kwargs)

        input_tokens = response.usage.input_tokens
        output_tokens = response.usage.output_tokens
        caps = self._models.get(model, Capabilities())
        cost = caps.estimate_cost(input_tokens, output_tokens)

        finish_reason = "max_tokens" if response.stop_reason == "max_tokens" else "stop"
        return LLMResponse(
            content=response.content[0].text,
            model=model,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            cost_usd=cost,
            raw=response,
            finish_reason=finish_reason,
        )
