from __future__ import annotations
import os
from typing import Any
from mosesaic.llm.provider import Capabilities, LLMMessage, LLMProvider, LLMResponse

# Pricing per 1M tokens (2026)
_OPENAI_MODELS: dict[str, Capabilities] = {
    "gpt-4o": Capabilities(
        vision=True, tools=True, thinking=False,
        context_k=128, cost_per_1m_input=2.50, cost_per_1m_output=10.00,
    ),
    "gpt-4o-mini": Capabilities(
        vision=True, tools=True, thinking=False,
        context_k=128, cost_per_1m_input=0.15, cost_per_1m_output=0.60,
    ),
    "o3-mini": Capabilities(
        vision=False, tools=True, thinking=True,
        context_k=200, cost_per_1m_input=1.10, cost_per_1m_output=4.40,
    ),
}


class OpenAIProvider(LLMProvider):
    """LLM provider backed by the OpenAI API.

    Also used as base for GroqProvider (same SDK, different base_url + models).
    The api_key defaults to the OPENAI_API_KEY environment variable if not passed.
    """

    def __init__(
        self,
        api_key: str | None = None,
        base_url: str | None = None,
        extra_models: dict[str, Capabilities] | None = None,
        provider_name: str = "openai",
    ) -> None:
        if not provider_name:
            raise ValueError("provider_name must be a non-empty string")
        # Resolve key from env if not passed directly (only required for OpenAI endpoint)
        resolved_key = api_key or os.environ.get("OPENAI_API_KEY")
        if resolved_key is None and base_url is None:
            raise ValueError(
                f"No API key provided for {provider_name!r}. "
                "Set api_key or the OPENAI_API_KEY environment variable."
            )
        import openai
        self._client = openai.AsyncOpenAI(api_key=resolved_key, base_url=base_url)
        self._models = {**_OPENAI_MODELS, **(extra_models or {})}
        self._name = provider_name

    @property
    def name(self) -> str:
        return self._name

    @property
    def models(self) -> dict[str, Capabilities]:
        return self._models

    async def chat(
        self,
        model: str,
        messages: list[LLMMessage],
        max_tokens: int = 4096,
        **kwargs: Any,
    ) -> LLMResponse:
        """Call the OpenAI completions API and return a structured response.

        Note: stream=True is not supported — response.usage will be None in
        streaming mode, causing an AttributeError. Use non-streaming calls only.
        """
        payload = [{"role": m.role, "content": m.content} for m in messages]
        response = await self._client.chat.completions.create(
            model=model,
            messages=payload,
            max_tokens=max_tokens,
            **kwargs,
        )
        input_tokens = response.usage.prompt_tokens
        output_tokens = response.usage.completion_tokens
        caps = self._models.get(model, Capabilities())
        cost = caps.estimate_cost(input_tokens, output_tokens)
        fr = response.choices[0].finish_reason or "stop"
        finish_reason = "max_tokens" if fr == "length" else "stop"
        return LLMResponse(
            content=response.choices[0].message.content or "",
            model=model,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            cost_usd=cost,
            raw=response,
            finish_reason=finish_reason,
        )
