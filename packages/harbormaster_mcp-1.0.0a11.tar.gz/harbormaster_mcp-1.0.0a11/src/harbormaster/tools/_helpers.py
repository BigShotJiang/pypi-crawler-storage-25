"""Shared helpers for tool implementations (private to harbormaster.tools).

Translates between the typed Backend interface (which raises BackendError on
failure) and the MCP user-facing string contract (which returns 'Error: ...'
prefixed strings so the envelope stays consistent across tools).
"""
from __future__ import annotations

import os
import time
from pathlib import Path

from harbormaster.backends import BackendError, get_backend
from harbormaster.config import HarbormasterConfig
from harbormaster.projects import resolve_project, validate_project_name
from harbormaster.ssh import is_remote


def _dump_dir() -> Path:
    """Return the directory for truncated-output dumps.

    Uses $XDG_STATE_HOME (or ~/.local/state) by default, NOT /tmp — claude
    output may include private code, secrets, or SSH host data. Creates the
    directory mode 0o700 (owner-only) on first use.
    """
    state = os.environ.get("XDG_STATE_HOME") or str(Path.home() / ".local" / "state")
    d = Path(state) / "harbormaster" / "dumps"
    d.mkdir(parents=True, exist_ok=True, mode=0o700)
    return d


def run_backend(
    *,
    name: str,
    prompt: str,
    max_turns: int,
    host: str | None,
    config: HarbormasterConfig,
    label_prefix: str,
) -> str:
    """Dispatch a prompt to local or remote backend, return the (possibly
    truncated) result text or an 'Error: ...' string.

    No SSH glue here — that's encapsulated inside the backend. This function
    is purely orchestration: validate the project name, pick the backend,
    pick local-vs-remote, dispatch, and translate exceptions to strings at
    the MCP boundary.
    """
    try:
        validate_project_name(name)
    except ValueError as e:
        return f"Error: {e}"

    backend = get_backend(config)
    if backend is None:
        return "Error: backend 'claude' is not enabled in config"
    cap = backend.cfg.output_word_cap

    try:
        if is_remote(host):
            host_cfg = config.hosts.get(host)
            remote_htdocs = host_cfg.remote_htdocs if host_cfg else "~/htdocs"
            connect_timeout = host_cfg.connect_timeout if host_cfg else 10
            total_timeout = host_cfg.total_timeout if host_cfg else 120
            result = backend.ask_remote(
                host=host,
                remote_cwd=f"{remote_htdocs}/{name}",
                prompt=prompt,
                max_turns=max_turns,
                connect_timeout=connect_timeout,
                total_timeout=total_timeout,
            )
            label = f"{label_prefix}-{host}-{name}"
        else:
            try:
                cwd = resolve_project(name, config.projects)
            except ValueError as e:
                return f"Error: {e}"
            result = backend.ask_local(
                cwd=cwd, prompt=prompt, max_turns=max_turns
            )
            label = f"{label_prefix}-{name}"
    except BackendError as e:
        return f"Error: {e}"

    return _truncate(result.output, cap, label)


def _truncate(text: str, word_cap: int, source_label: str) -> str:
    words = text.split()
    if len(words) <= word_cap:
        return text
    truncated = " ".join(words[:word_cap])
    try:
        dump_path = _dump_dir() / f"harbormaster-{source_label}-{int(time.time())}.md"
        dump_path.write_text(text, encoding="utf-8")
        os.chmod(dump_path, 0o600)
        return f"{truncated}\n\n[...truncated, full output: {dump_path}]"
    except OSError:
        return f"{truncated}\n\n[...truncated, dump failed]"
