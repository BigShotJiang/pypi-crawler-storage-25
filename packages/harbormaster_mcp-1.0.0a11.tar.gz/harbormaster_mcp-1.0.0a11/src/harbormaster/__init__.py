"""Harbormaster — MCP server that routes Q&A across many projects and SSH hosts.

Part of the FleetQ ecosystem. Standalone OSS works fully; FleetQ integration is opt-in.
"""

__version__ = "1.0.0a11"
__all__ = ["__version__"]
