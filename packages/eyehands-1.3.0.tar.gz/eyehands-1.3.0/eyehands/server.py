"""
eyehands - Local HTTP server
Gives Claude eyes (screen capture) and hands (mouse + keyboard control)
via Windows SendInput. SendInput goes through the Raw Input pipeline that
pointer lock reads from.

Usage: `python -m eyehands`  (or `python server.py` from a repo checkout)
Then Claude sends: curl -X POST http://localhost:7331/move -d "{\"dx\":10,\"dy\":0}"
"""

# Hardcoded fallback version. The real value is read from package metadata
# below when the package is pip-installed. Keep these in sync with pyproject.toml
# for dev runs from a source checkout without `pip install -e .`.
__version__ = "1.3.0"

import argparse
import atexit
import base64
import ctypes
import ctypes.wintypes as wintypes
import hashlib
import json
import io
import os
import secrets
import subprocess
import sys
import threading
import urllib.parse
from http.server import BaseHTTPRequestHandler, HTTPServer
from socketserver import ThreadingMixIn

import mss
import mss.tools
import time

# Pull the installed version from package metadata when available so the
# single source of truth is pyproject.toml. The hardcoded value above is the
# fallback for source-checkout dev runs without `pip install -e .`.
try:
    from importlib.metadata import version as _pkg_version
    __version__ = _pkg_version("eyehands")
except Exception:
    pass


def _get_data_dir():
    """Return the directory for runtime data files (.license, .eyehands-token, etc.).

    For source checkouts (detected by pyproject.toml next to the package dir)
    we use the repo root, keeping existing dev workflows intact. For installed
    packages we use %APPDATA%/eyehands on Windows (or $HOME/eyehands elsewhere),
    which gives each user a stable per-install data location decoupled from
    the site-packages path.
    """
    module_dir = os.path.dirname(os.path.abspath(__file__))
    parent_dir = os.path.dirname(module_dir)
    if os.path.exists(os.path.join(parent_dir, "pyproject.toml")):
        return parent_dir
    appdata = os.environ.get("APPDATA") or os.environ.get("HOME")
    if appdata:
        data_dir = os.path.join(appdata, "eyehands")
        try:
            os.makedirs(data_dir, exist_ok=True)
            return data_dir
        except Exception:
            pass
    return module_dir


_DATA_DIR = _get_data_dir()

# ── Auth token ────────────────────────────────────────────────────────────────
# A random bearer token is generated on first run and saved to .eyehands-token.
# All endpoints except /ping require Authorization: Bearer <token>.
# This prevents any rogue local process from controlling the desktop.

_TOKEN_FILE = os.path.join(_DATA_DIR, ".eyehands-token")

def _load_or_create_token():
    """Load existing token or generate a new one. Returns the token string."""
    if os.path.exists(_TOKEN_FILE):
        with open(_TOKEN_FILE) as f:
            token = f.read().strip()
            if token:
                return token
    token = secrets.token_urlsafe(32)
    with open(_TOKEN_FILE, "w") as f:
        f.write(token)
    return token

_auth_token = _load_or_create_token()

# Endpoints that skip auth (health check only)
_NO_AUTH_ENDPOINTS = {"/ping"}

# ── License validation ────────────────────────────────────────────────────────
# Pro features: /ui/*, /batch, /click_at, /click_and_wait, /type_and_enter,
#               /ui/click_element, /smooth_move, multi-monitor, FrameBuffer config
# Free: /move, /click, /double_click, /mousedown, /mouseup, /scroll, /key,
#       /type_text, /move_absolute, /screenshot*, /latest*, /ping, /cursor_pos,
#       /view, /find

_LICENSE_API   = "https://portal.fireal.dev/api/licenses"
_PRODUCT_CODE  = "eyehands"
_LICENSE_FILE  = os.path.join(_DATA_DIR, ".license")
_pro_active    = False

# ── Update check ──────────────────────────────────────────────────────────────
# On startup the server hits portal.fireal.dev to learn the latest published
# version. The result is cached in .update_check for 6 hours and surfaced on
# /ping and /latest_b64 so Claude can tell the user when an update exists.
# POST /update will pull the wheel from the portal and self-restart.

_UPDATE_CHECK_URL     = "https://portal.fireal.dev/api/updates/eyehands/check"
_UPDATE_CHECK_FILE    = os.path.join(_DATA_DIR, ".update_check")
_UPDATE_CHECK_TTL     = 6 * 3600  # 6 hours
_UPDATE_HELPER_FILE   = os.path.join(_DATA_DIR, ".update_helper.py")
_UPDATE_LOG_FILE      = os.path.join(_DATA_DIR, ".update_log.txt")
_update_available     = None  # dict {current, latest, download_url} or None

def _machine_id():
    """Stable machine fingerprint from hostname + OS install path."""
    raw = os.environ.get("COMPUTERNAME", "") + os.environ.get("SystemRoot", "")
    return hashlib.sha256(raw.encode()).hexdigest()[:32]

def _activate_license(key):
    """Activate a license key with the portal. Returns (success, message)."""
    import urllib.request
    device = _machine_id()
    import platform
    hostname = platform.node() or os.environ.get("COMPUTERNAME", "unknown")
    payload = json.dumps({"licenseKey": key, "deviceId": device, "deviceName": hostname}).encode()
    req = urllib.request.Request(
        f"{_LICENSE_API}/activate",
        data=payload,
        headers={"Content-Type": "application/json"},
    )
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read())
        if data.get("success"):
            # Save activation locally
            with open(_LICENSE_FILE, "w") as f:
                json.dump({
                    "key": key,
                    "deviceId": device,
                    "activationToken": data.get("activationToken", ""),
                    "productCode": data.get("productCode", _PRODUCT_CODE),
                }, f)
            return True, "License activated"
        return False, data.get("message", "Activation failed")
    except Exception as exc:
        return False, str(exc)

def _validate_license():
    """Check saved license against the portal. Returns True if Pro is active."""
    if not os.path.exists(_LICENSE_FILE):
        return False
    try:
        with open(_LICENSE_FILE) as f:
            lic = json.load(f)
    except Exception:
        return False
    import urllib.request
    payload = json.dumps({
        "licenseKey": lic.get("key", ""),
        "deviceId": lic.get("deviceId", ""),
        "activationToken": lic.get("activationToken", ""),
    }).encode()
    req = urllib.request.Request(
        f"{_LICENSE_API}/validate",
        data=payload,
        headers={"Content-Type": "application/json"},
    )
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read())
        return data.get("success", False)
    except Exception:
        # Offline grace: trust saved license if validation server is unreachable
        return True

def _check_pro():
    """Run license validation and set global _pro_active flag."""
    global _pro_active
    _pro_active = _validate_license()
    tier = "Pro" if _pro_active else "Free"
    print(f"[license] {tier} tier active")
    return _pro_active

def _load_update_cache():
    """Return cached update info if still fresh, else None.
    Invalidates the cache if the running version no longer matches the
    one captured at cache write time (e.g. just after a pip upgrade).
    """
    if not os.path.exists(_UPDATE_CHECK_FILE):
        return None
    try:
        with open(_UPDATE_CHECK_FILE) as f:
            data = json.load(f)
    except Exception:
        return None
    if time.time() - data.get("checked_at", 0) >= _UPDATE_CHECK_TTL:
        return None
    # Stale cache: written by an older running version. Invalidate so the
    # next call hits the portal and we don't keep showing "update available"
    # after the user has already upgraded.
    if data.get("current_version") != __version__:
        try:
            os.remove(_UPDATE_CHECK_FILE)
        except Exception:
            pass
        return None
    return data.get("result")

def _save_update_cache(result):
    """Persist the latest update check result with a timestamp + running version."""
    try:
        with open(_UPDATE_CHECK_FILE, "w") as f:
            json.dump({
                "checked_at": time.time(),
                "current_version": __version__,
                "result": result,
            }, f)
    except Exception:
        pass

def _version_tuple(v):
    """Parse 'X.Y.Z' → (X, Y, Z) for ordered comparison. Non-numeric parts
    compare as 0 so malformed strings sort as oldest."""
    if not v:
        return (0,)
    try:
        return tuple(int(p) for p in v.split("."))
    except (ValueError, AttributeError):
        return (0,)

def _check_for_updates():
    """Hit the portal /check endpoint and return update info dict (or None).
    5-second timeout — must not block startup if portal is slow/down.
    """
    cached = _load_update_cache()
    if cached is not None:
        return cached
    if not os.path.exists(_LICENSE_FILE):
        return None
    try:
        with open(_LICENSE_FILE) as f:
            lic = json.load(f)
    except Exception:
        return None
    payload = json.dumps({
        "licenseKey": lic.get("key", ""),
        "deviceId": lic.get("deviceId", ""),
        "activationToken": lic.get("activationToken", ""),
        "currentVersion": __version__,
    }).encode()
    import urllib.request
    req = urllib.request.Request(
        _UPDATE_CHECK_URL,
        data=payload,
        headers={"Content-Type": "application/json"},
    )
    try:
        with urllib.request.urlopen(req, timeout=5) as resp:
            data = json.loads(resp.read())
    except Exception:
        return None
    latest = data.get("latestVersion")
    # Only report "update available" when the portal's latest is strictly
    # newer than the running version. Proper tuple compare (not ==) so a
    # stale portal cache reporting an older version doesn't spuriously
    # trigger the update banner right after a release.
    if not latest or _version_tuple(latest) <= _version_tuple(__version__):
        result = None
    else:
        result = {
            "current": __version__,
            "latest": latest,
        }
    _save_update_cache(result)
    return result

def _write_update_helper():
    """Write the embedded restart helper script to disk. Returns its path."""
    with open(_UPDATE_HELPER_FILE, "w") as f:
        f.write(_UPDATE_HELPER_PY)
    return _UPDATE_HELPER_FILE

# Helper script that the /update endpoint spawns as a detached process. It
# waits for the parent server to exit, runs `pip install --upgrade eyehands`
# (pulling from PyPI), and relaunches the server via `python -m eyehands`.
# All output goes to .update_log.txt for debugging. `--upgrade` (not
# `--force-reinstall`) is deliberate: a failed install leaves the previous
# version intact so the user can manually relaunch.
_UPDATE_HELPER_PY = '''
import sys, os, time, subprocess

PARENT_PID = int(sys.argv[1])
LOG = sys.argv[2]

def log(msg):
    with open(LOG, "a") as f:
        f.write(f"[helper] {msg}\\n")

# Wait up to 10s for parent to exit on its own
for _ in range(20):
    try:
        os.kill(PARENT_PID, 0)
        time.sleep(0.5)
    except OSError:
        break
else:
    log("parent still alive after 10s, force-killing")
    subprocess.run(["taskkill", "/F", "/PID", str(PARENT_PID)], capture_output=True)
    time.sleep(0.5)

log("running: pip install --upgrade eyehands")
result = subprocess.run(
    [sys.executable, "-m", "pip", "install", "--upgrade", "eyehands"],
    capture_output=True, text=True,
)
log(f"pip return code: {result.returncode}")
if result.stdout: log(f"stdout: {result.stdout}")
if result.stderr: log(f"stderr: {result.stderr}")

if result.returncode != 0:
    log("install failed; not restarting server")
    sys.exit(1)

log("starting new server via python -m eyehands")
subprocess.Popen(
    [sys.executable, "-m", "eyehands"],
    close_fds=True,
    creationflags=subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP,
)
log("done")
'''.lstrip()

_PRO_ENDPOINTS = {
    "/ui/windows", "/ui/find", "/ui/at", "/ui/tree",
    "/ui/click_element",
    "/batch", "/click_at", "/click_and_wait", "/type_and_enter",
    "/smooth_move",
}

def _is_pro_endpoint(path):
    return path.split("?")[0] in _PRO_ENDPOINTS

# ── Patch mss to remove CAPTUREBLT flag (prevents cursor blink) ──────────────
# GDI BitBlt with CAPTUREBLT (0x40000000) forces Windows to hide the cursor
# before each capture and re-show it after, causing visible flicker/blink.
# Removing it uses SRCCOPY alone which captures without touching the cursor.
try:
    import mss.windows as _mss_win
    _mss_win.CAPTUREBLT = 0
except Exception:
    pass

# ── Single-instance enforcement ────────────────────────────────────────────────
_PID_FILE = os.path.join(_DATA_DIR, "server.pid")

def _kill_existing_instance():
    """Kill any previously running server instance recorded in the PID file."""
    if not os.path.exists(_PID_FILE):
        return
    try:
        with open(_PID_FILE) as f:
            old_pid = int(f.read().strip())
        if old_pid == os.getpid():
            return
        print(f"[startup] Killing existing instance (PID {old_pid})...")
        subprocess.run(["taskkill", "/F", "/PID", str(old_pid)],
                       capture_output=True)
        time.sleep(0.5)
    except Exception:
        pass
    try:
        os.remove(_PID_FILE)
    except Exception:
        pass

def _write_pid():
    with open(_PID_FILE, "w") as f:
        f.write(str(os.getpid()))

def _remove_pid():
    try:
        os.remove(_PID_FILE)
    except Exception:
        pass

atexit.register(_remove_pid)

# ── DPI Awareness (must happen before ANY Win32 DPI-sensitive calls) ───────────
# On 4K / high-DPI displays, Windows may report logical (scaled) coordinates to
# DPI-unaware processes while mss captures physical pixels — causing mismatches.
# Per-Monitor v2 forces all Win32 APIs (GetCursorPos, GetSystemMetrics, etc.) to
# return raw physical pixel values that match what mss/DXcam actually captures.
_DPI_CONTEXT_PER_MONITOR_V2 = ctypes.c_void_p(-4)
try:
    ctypes.windll.user32.SetProcessDpiAwarenessContext(_DPI_CONTEXT_PER_MONITOR_V2)
except OSError:
    pass  # Windows 8.1 and earlier don't support this API

# ── Windows UI Automation ──────────────────────────────────────────────────────

_uia_module = None
_uia_lock   = threading.Lock()

def _load_uia():
    global _uia_module
    if _uia_module is not None:
        return _uia_module
    with _uia_lock:
        if _uia_module is None:
            try:
                import uiautomation as uia
                _uia_module = uia
            except ImportError:
                raise ImportError("Run: pip install uiautomation")
    return _uia_module

def _rect_dict(rect):
    l, t, r, b = rect.left, rect.top, rect.right, rect.bottom
    return {"left": l, "top": t, "right": r, "bottom": b,
            "width": r - l, "height": b - t,
            "center_x": (l + r) // 2, "center_y": (t + b) // 2}

def _ctrl_dict(ctrl):
    try:
        rd = _rect_dict(ctrl.BoundingRectangle)
    except Exception:
        rd = {}
    try:
        value = ctrl.GetValuePattern().Value
    except Exception:
        value = None
    return {
        "name":          ctrl.Name,
        "type":          ctrl.ControlTypeName,
        "automation_id": ctrl.AutomationId,
        "center_x":      rd.get("center_x"),
        "center_y":      rd.get("center_y"),
        "rect":          rd,
        "value":         value,
    }

def ui_list_windows():
    uia = _load_uia()
    out = []
    for win in uia.GetRootControl().GetChildren():
        try:
            out.append({"title": win.Name, "type": win.ControlTypeName,
                        "rect": _rect_dict(win.BoundingRectangle)})
        except Exception:
            pass
    return out

def ui_element_at(x, y):
    uia = _load_uia()
    ctrl = uia.ControlFromPoint(x, y)
    return _ctrl_dict(ctrl) if ctrl else None

def ui_find(window_title=None, name=None, control_type=None, depth=6, max_results=20):
    uia = _load_uia()
    if window_title:
        root = uia.WindowControl(searchDepth=1, SubName=window_title)
        root = root if root.Exists(0) else uia.GetRootControl()
    else:
        root = uia.GetRootControl()
    results = []
    def search(ctrl, d):
        if d < 0 or len(results) >= max_results:
            return
        try:
            ok = True
            if name and name.lower() not in ctrl.Name.lower():
                ok = False
            if control_type and control_type.lower() not in ctrl.ControlTypeName.lower():
                ok = False
            if ok and (name or control_type):
                results.append(_ctrl_dict(ctrl))
        except Exception:
            pass
        try:
            for child in ctrl.GetChildren():
                search(child, d - 1)
        except Exception:
            pass
    search(root, depth)
    return results

def ui_tree(window_title=None, depth=3):
    uia = _load_uia()
    if window_title:
        root = uia.WindowControl(searchDepth=1, SubName=window_title)
        if not root.Exists(0):
            return {"error": f"Window '{window_title}' not found"}
    else:
        root = uia.GetRootControl()
    def build(ctrl, d):
        node = _ctrl_dict(ctrl)
        if d > 0:
            try:
                node["children"] = [build(c, d - 1) for c in ctrl.GetChildren()]
            except Exception:
                node["children"] = []
        return node
    return build(root, depth)

# ── Threaded HTTP server ───────────────────────────────────────────────────────

class ThreadingHTTPServer(ThreadingMixIn, HTTPServer):
    """Handle each request in its own thread so slow ops don't block others."""
    daemon_threads = True
    # Disable address reuse — on Windows, allow_reuse_address lets multiple
    # processes bind to the same port simultaneously, causing instance pile-up.
    allow_reuse_address = False

# ── Image helpers (shared by FrameBuffer and on-demand /screenshot) ───────────

_VALID_IMAGE_FORMATS = ("jpeg", "png", "webp")

def _normalize_format(fmt):
    """Lowercase + accept 'jpg' as 'jpeg'. Unknown values fall back to jpeg."""
    f = (fmt or "jpeg").lower()
    if f == "jpg":
        f = "jpeg"
    if f not in _VALID_IMAGE_FORMATS:
        f = "jpeg"
    return f

def _resize_rgb_fast(arr, max_w):
    """Downscale a numpy RGB uint8 array to max_w. Returns (resized_arr, scale).

    Uses cv2.INTER_AREA (the recommended interpolation for downscaling) when
    cv2 is available, Pillow LANCZOS otherwise — both are higher quality than
    BILINEAR at the same CPU budget and match what FrameBuffer already uses.
    """
    h, w = arr.shape[:2]
    if w <= max_w:
        return arr, 1.0
    scale = max_w / w
    new_w = max_w
    new_h = int(h * scale)
    try:
        import cv2
        return cv2.resize(arr, (new_w, new_h), interpolation=cv2.INTER_AREA), scale
    except ImportError:
        from PIL import Image
        import numpy as np
        pil = Image.fromarray(arr).resize((new_w, new_h), Image.LANCZOS)
        return np.asarray(pil), scale

def _encode_rgb(arr, fmt="jpeg", quality=70):
    """Encode a numpy RGB uint8 array into the requested image format.

    Returns (bytes, content_type). Accepts 'jpeg', 'png', 'webp' (and 'jpg').
    JPEG uses simplejpeg when available (2-6x faster) and falls back to Pillow.
    PNG and WebP always go through Pillow.
    """
    fmt = _normalize_format(fmt)
    if fmt == "jpeg":
        try:
            import simplejpeg
            return simplejpeg.encode_jpeg(arr, quality=quality, colorspace="RGB"), "image/jpeg"
        except ImportError:
            from PIL import Image
            buf = io.BytesIO()
            Image.fromarray(arr).save(buf, format="JPEG", quality=quality, optimize=False)
            return buf.getvalue(), "image/jpeg"
    from PIL import Image
    buf = io.BytesIO()
    if fmt == "png":
        # compress_level=1 trades a bit of size for much faster encoding. PNG
        # is still lossless at any level.
        Image.fromarray(arr).save(buf, format="PNG", optimize=False, compress_level=1)
        return buf.getvalue(), "image/png"
    if fmt == "webp":
        # WebP quality uses the same 1-100 scale. Lossy by default; method=4 is
        # a reasonable speed/quality tradeoff.
        Image.fromarray(arr).save(buf, format="WEBP", quality=quality, method=4)
        return buf.getvalue(), "image/webp"
    # Unreachable — _normalize_format already constrained the value
    raise ValueError(f"unknown format: {fmt}")

def _format_extension(fmt):
    """Return filename extension for a format string (for logging/debug only)."""
    fmt = _normalize_format(fmt)
    return {"jpeg": "jpg", "png": "png", "webp": "webp"}[fmt]

# ── Window-scoped capture (PrintWindow) ────────────────────────────────────────

class _RECT(ctypes.Structure):
    _fields_ = [("left",   wintypes.LONG),
                ("top",    wintypes.LONG),
                ("right",  wintypes.LONG),
                ("bottom", wintypes.LONG)]

class _BITMAPINFOHEADER(ctypes.Structure):
    _fields_ = [
        ("biSize",          wintypes.DWORD),
        ("biWidth",         wintypes.LONG),
        ("biHeight",        wintypes.LONG),
        ("biPlanes",        wintypes.WORD),
        ("biBitCount",      wintypes.WORD),
        ("biCompression",   wintypes.DWORD),
        ("biSizeImage",     wintypes.DWORD),
        ("biXPelsPerMeter", wintypes.LONG),
        ("biYPelsPerMeter", wintypes.LONG),
        ("biClrUsed",       wintypes.DWORD),
        ("biClrImportant",  wintypes.DWORD),
    ]

class _BITMAPINFO(ctypes.Structure):
    _fields_ = [("bmiHeader", _BITMAPINFOHEADER),
                ("bmiColors", wintypes.DWORD * 3)]

def _grab_hwnd(hwnd):
    """Capture a specific window by HWND using the Win32 PrintWindow API.

    Returns (rgb_ndarray, left, top) in physical screen pixels. Works even
    when the target window is partially occluded or fully covered — unlike
    mss/DXGI desktop capture, which only sees what's composited on screen.
    Uses PW_RENDERFULLCONTENT (0x2) so hardware-composited windows (Chrome,
    Electron, games using DWM) render correctly; falls back to flags=0 for
    older windows that don't support the flag.
    """
    import numpy as np
    user32 = ctypes.windll.user32
    gdi32  = ctypes.windll.gdi32

    rect = _RECT()
    if not user32.GetWindowRect(hwnd, ctypes.byref(rect)):
        raise OSError(f"GetWindowRect failed for hwnd={hwnd}")

    left, top = rect.left, rect.top
    width  = rect.right - rect.left
    height = rect.bottom - rect.top
    if width <= 0 or height <= 0:
        raise OSError(f"invalid window dimensions {width}x{height} for hwnd={hwnd}")

    hdc_window = user32.GetWindowDC(hwnd)
    if not hdc_window:
        raise OSError(f"GetWindowDC failed for hwnd={hwnd}")

    hdc_mem = None
    hbitmap = None
    try:
        hdc_mem = gdi32.CreateCompatibleDC(hdc_window)
        if not hdc_mem:
            raise OSError("CreateCompatibleDC failed")
        hbitmap = gdi32.CreateCompatibleBitmap(hdc_window, width, height)
        if not hbitmap:
            raise OSError("CreateCompatibleBitmap failed")
        gdi32.SelectObject(hdc_mem, hbitmap)

        PW_RENDERFULLCONTENT = 0x00000002
        ok = user32.PrintWindow(hwnd, hdc_mem, PW_RENDERFULLCONTENT)
        if not ok:
            ok = user32.PrintWindow(hwnd, hdc_mem, 0)
        if not ok:
            raise OSError(f"PrintWindow failed for hwnd={hwnd}")

        bmi = _BITMAPINFO()
        bmi.bmiHeader.biSize        = ctypes.sizeof(_BITMAPINFOHEADER)
        bmi.bmiHeader.biWidth       = width
        bmi.bmiHeader.biHeight      = -height   # negative = top-down DIB
        bmi.bmiHeader.biPlanes      = 1
        bmi.bmiHeader.biBitCount    = 32
        bmi.bmiHeader.biCompression = 0         # BI_RGB

        raw = (ctypes.c_ubyte * (width * height * 4))()
        DIB_RGB_COLORS = 0
        gdi32.GetDIBits(hdc_mem, hbitmap, 0, height, raw, ctypes.byref(bmi),
                        DIB_RGB_COLORS)

        arr = np.frombuffer(raw, dtype=np.uint8).reshape((height, width, 4))
        # BGRX → RGB, drop alpha
        arr = arr[:, :, [2, 1, 0]]
        return np.ascontiguousarray(arr), left, top
    finally:
        if hbitmap:
            gdi32.DeleteObject(hbitmap)
        if hdc_mem:
            gdi32.DeleteDC(hdc_mem)
        user32.ReleaseDC(hwnd, hdc_window)

# ── Background frame capture ───────────────────────────────────────────────────

# Name of the capture backend that won FrameBuffer's startup race. Set by
# whichever _loop_* method successfully starts. Surfaced via /ping so Claude
# and the user can tell whether they're on the fast DXGI path or the slow
# GDI fallback and suggest the fix if it matters.
_capture_backend = "unknown"

# Startup tips are ambient recommendations surfaced on /ping and in the CLI
# banner. They're deduplicated on the client by id. Disabled via --no-tips.
_tips_enabled = True

def _build_tips():
    """Return the current tip list based on runtime state. Empty if disabled."""
    if not _tips_enabled:
        return []
    tips = []
    # Chrome MCP is the most ergonomic transport for Claude's screenshot pipeline:
    # a single tool call per capture vs curl → file → read. We surface it on /ping
    # so the SKILL can hint the user to install the extension if they haven't.
    tips.append({
        "id":  "chrome_mcp",
        "msg": ("For the smoothest screenshot workflow, install Claude's Chrome "
                "extension. eyehands will then be viewable via Chrome MCP with one "
                "tool call per capture instead of curl → save → read."),
    })
    # Nudge users on the slow GDI path toward DXGI capture. bettercam gives
    # roughly 6x the throughput of mss on a typical desktop.
    if _capture_backend == "mss":
        tips.append({
            "id":  "fast_capture",
            "msg": ("You're on the GDI (mss) capture fallback. Install bettercam "
                    "for DXGI capture (~120fps vs ~20fps): pip install bettercam"),
        })
    return tips

class FrameBuffer:
    """Continuously captures the primary monitor into a rolling buffer."""

    def __init__(self, monitor_idx=1, max_w=1920, quality=70, fps=20):
        self.monitor_idx = monitor_idx
        self.max_w       = max_w
        self.quality     = quality
        self.fps         = fps
        self.interval    = 1.0 / fps
        self._lock       = threading.Lock()
        self._frame      = None   # latest JPEG bytes
        self._b64        = None   # latest base64 string
        self._arr        = None   # latest numpy RGB array (for re-encoding to non-JPEG formats)
        self._ts         = 0.0    # capture timestamp
        self._cx         = 0      # cursor x at capture time
        self._cy         = 0      # cursor y at capture time
        self._scale      = 1.0    # downscale factor applied
        self._mon        = {}     # monitor rect used
        self._img_w      = 0      # output image width  (after downscale)
        self._img_h      = 0      # output image height (after downscale)
        self._err_count  = 0      # consecutive capture errors
        t = threading.Thread(target=self._loop, daemon=True)
        t.start()

    def _loop(self):
        """Try BetterCam first, then DXcam, then mss — fastest available wins."""
        try:
            import bettercam
            self._loop_bettercam(bettercam)
            return
        except Exception as exc:
            print(f"[FrameBuffer] BetterCam unavailable ({exc}), trying DXcam")
        try:
            import dxcam
            self._loop_dxcam(dxcam)
            return
        except Exception as exc:
            print(f"[FrameBuffer] DXcam unavailable ({exc}), falling back to mss")
        self._loop_mss()

    def _encode(self, arr):
        """Encode a numpy RGB uint8 array to JPEG bytes at the buffer quality.

        Delegates to the module-level _encode_rgb helper, which uses simplejpeg
        (libturbojpeg) when available and falls back to Pillow on import error.
        """
        data, _ = _encode_rgb(arr, fmt="jpeg", quality=self.quality)
        return data

    def _resize(self, arr):
        """Downscale numpy RGB array to self.max_w, returns (resized_arr, scale).

        Delegates to the module-level _resize_rgb_fast helper (cv2.INTER_AREA
        when available, Pillow LANCZOS otherwise) so FrameBuffer and the
        on-demand /screenshot path share the exact same resize quality.
        """
        return _resize_rgb_fast(arr, self.max_w)

    def _commit(self, arr, scale, mon, cx, cy):
        """Encode and store a frame. Called from each capture backend."""
        data = self._encode(arr)
        b64  = base64.b64encode(data).decode()
        h, w = arr.shape[:2]
        with self._lock:
            self._frame     = data
            self._b64       = b64
            self._arr       = arr   # raw numpy kept for re-encoding at other formats
            self._ts        = time.monotonic()
            self._cx        = cx
            self._cy        = cy
            self._scale     = scale
            self._mon       = mon
            self._img_w     = w
            self._img_h     = h
            self._err_count = 0

    def _get_monitor_origin(self):
        """Return (left, top) of the capture monitor for coordinate mapping."""
        try:
            with mss.mss() as sct:
                mon = sct.monitors[self.monitor_idx]
                return mon["left"], mon["top"]
        except Exception:
            return 0, 0

    def _loop_bettercam(self, bettercam):
        """BetterCam: DXcam fork with high-resolution waitable timer scheduling
        (~120fps avg vs DXcam's ~39fps). Numpy RGB output, no PIL needed."""
        global _capture_backend
        camera = bettercam.create(output_idx=self.monitor_idx - 1, output_color="RGB")
        target = min(self.fps, 60)
        camera.start(target_fps=target, video_mode=True)
        mon_left, mon_top = self._get_monitor_origin()
        _capture_backend = "bettercam"
        print(f"[FrameBuffer] BetterCam started at {target}fps (monitor {self.monitor_idx})")
        try:
            while True:
                try:
                    frame = camera.get_latest_frame()
                    if frame is None:
                        time.sleep(0.001)
                        continue
                    cx, cy    = get_cursor_pos()
                    arr, scale = self._resize(frame)
                    h, w       = arr.shape[:2]
                    mon        = {"left": mon_left, "top": mon_top, "width": w, "height": h}
                    self._commit(arr, scale, mon, cx, cy)
                except Exception as exc:
                    with self._lock:
                        self._err_count += 1
                    print(f"[FrameBuffer/bettercam] error ({self._err_count}): {exc}")
                time.sleep(self.interval)
        finally:
            camera.stop()
            del camera

    def _loop_dxcam(self, dxcam):
        """DXcam: DirectX Desktop Duplication API. Numpy RGB output, no PIL needed."""
        global _capture_backend
        camera = dxcam.create(output_idx=self.monitor_idx - 1, output_color="RGB")
        target = min(self.fps, 60)
        camera.start(target_fps=target, video_mode=True)
        mon_left, mon_top = self._get_monitor_origin()
        _capture_backend = "dxcam"
        print(f"[FrameBuffer] DXcam started at {target}fps (monitor {self.monitor_idx})")
        try:
            while True:
                try:
                    frame = camera.get_latest_frame()
                    if frame is None:
                        time.sleep(0.001)
                        continue
                    cx, cy    = get_cursor_pos()
                    arr, scale = self._resize(frame)
                    h, w       = arr.shape[:2]
                    mon        = {"left": mon_left, "top": mon_top, "width": w, "height": h}
                    self._commit(arr, scale, mon, cx, cy)
                except Exception as exc:
                    with self._lock:
                        self._err_count += 1
                    print(f"[FrameBuffer/dxcam] error ({self._err_count}): {exc}")
                time.sleep(self.interval)
        finally:
            camera.stop()
            del camera

    def _loop_mss(self):
        """Fallback: GDI-based mss with persistent context. Compatible with all setups."""
        global _capture_backend
        from PIL import Image
        import numpy as np
        _capture_backend = "mss"
        with mss.mss() as sct:
            while True:
                t0 = time.monotonic()
                try:
                    cx, cy = get_cursor_pos()
                    mon    = sct.monitors[self.monitor_idx]
                    img    = sct.grab(mon)
                    # Convert BGRA → RGB numpy array without PIL Image overhead
                    arr    = np.frombuffer(img.bgra, dtype=np.uint8)
                    arr    = arr.reshape((img.height, img.width, 4))[:, :, [2, 1, 0]]
                    arr, scale = self._resize(arr)
                    h, w   = arr.shape[:2]
                    self._commit(arr, scale, dict(mon), cx, cy)
                except Exception as exc:
                    with self._lock:
                        self._err_count += 1
                    print(f"[FrameBuffer/mss] error ({self._err_count}): {exc}")
                elapsed = time.monotonic() - t0
                time.sleep(max(0, self.interval - elapsed))

    def latest_b64(self):
        with self._lock:
            return (self._b64, self._ts, self._cx, self._cy,
                    self._scale, dict(self._mon), self._img_w, self._img_h,
                    self._err_count)

    def latest_bytes(self):
        with self._lock:
            return self._frame, self._ts

    def latest_array(self):
        """Return the latest captured numpy RGB array plus metadata.

        The array reference is shared — callers must treat it as read-only.
        Used by /latest and /latest_b64 when the caller asks for a format
        other than cached JPEG (PNG, WebP, custom quality), to avoid paying
        the JPEG decode-and-re-encode roundtrip.
        """
        with self._lock:
            return (self._arr, self._ts, self._cx, self._cy,
                    self._scale, dict(self._mon), self._img_w, self._img_h,
                    self._err_count)

    def frame_hash(self):
        """Return a cheap identity hash of the current frame for change detection."""
        with self._lock:
            return self._ts  # timestamp changes every new frame


# Global buffer — started when server launches
_frame_buf: FrameBuffer | None = None

# Lazy-loaded EasyOCR reader — initialized on first /find request
_ocr_reader = None
# Cached OCR results keyed by frame timestamp
_ocr_cache_ts = 0.0
_ocr_cache_results = []
_ocr_lock = threading.Lock()

# ── Windows input structs ──────────────────────────────────────────────────────

INPUT_MOUSE    = 0
INPUT_KEYBOARD = 1

MOUSEEVENTF_MOVE        = 0x0001
MOUSEEVENTF_LEFTDOWN    = 0x0002
MOUSEEVENTF_LEFTUP      = 0x0004
MOUSEEVENTF_RIGHTDOWN   = 0x0008
MOUSEEVENTF_RIGHTUP     = 0x0010
MOUSEEVENTF_MIDDLEDOWN  = 0x0020
MOUSEEVENTF_MIDDLEUP    = 0x0040
MOUSEEVENTF_WHEEL       = 0x0800
MOUSEEVENTF_VIRTUALDESK = 0x4000   # normalize across entire virtual desktop
MOUSEEVENTF_ABSOLUTE    = 0x8000

KEYEVENTF_KEYUP   = 0x0002
KEYEVENTF_UNICODE = 0x0004

_MODIFIER_VK = {
    "ctrl":  0x11,  # VK_CONTROL
    "shift": 0x10,  # VK_SHIFT
    "alt":   0x12,  # VK_MENU
    "win":   0x5B,  # VK_LWIN
}

class MOUSEINPUT(ctypes.Structure):
    _fields_ = [
        ("dx",          wintypes.LONG),
        ("dy",          wintypes.LONG),
        ("mouseData",   wintypes.DWORD),
        ("dwFlags",     wintypes.DWORD),
        ("time",        wintypes.DWORD),
        ("dwExtraInfo", ctypes.POINTER(wintypes.ULONG)),
    ]

class KEYBDINPUT(ctypes.Structure):
    _fields_ = [
        ("wVk",         wintypes.WORD),
        ("wScan",       wintypes.WORD),
        ("dwFlags",     wintypes.DWORD),
        ("time",        wintypes.DWORD),
        ("dwExtraInfo", ctypes.POINTER(wintypes.ULONG)),
    ]

class _INPUT_UNION(ctypes.Union):
    _fields_ = [("mi", MOUSEINPUT), ("ki", KEYBDINPUT)]

class INPUT(ctypes.Structure):
    _fields_ = [("type", wintypes.DWORD), ("_input", _INPUT_UNION)]

SendInput = ctypes.windll.user32.SendInput
SendInput.argtypes = [wintypes.UINT, ctypes.POINTER(INPUT), ctypes.c_int]
SendInput.restype  = wintypes.UINT

def _send_mouse(flags, dx=0, dy=0, mouse_data=0):
    inp = INPUT(type=INPUT_MOUSE)
    inp._input.mi = MOUSEINPUT(dx=int(dx), dy=int(dy), mouseData=mouse_data,
                               dwFlags=flags, time=0, dwExtraInfo=None)
    SendInput(1, ctypes.byref(inp), ctypes.sizeof(INPUT))

# Cache virtual-desktop metrics at startup — covers all monitors.
# SM_XVIRTUALSCREEN=76, SM_YVIRTUALSCREEN=77 can be negative on multi-monitor.
# SM_CXVIRTUALSCREEN=78, SM_CYVIRTUALSCREEN=79 span all displays.
_vdesk_left   = ctypes.windll.user32.GetSystemMetrics(76)
_vdesk_top    = ctypes.windll.user32.GetSystemMetrics(77)
_vdesk_w      = ctypes.windll.user32.GetSystemMetrics(78)
_vdesk_h      = ctypes.windll.user32.GetSystemMetrics(79)

# ── Public API ─────────────────────────────────────────────────────────────────

def move(dx, dy):
    """Relative mouse movement — works through pointer lock."""
    _send_mouse(MOUSEEVENTF_MOVE, dx, dy)

def click(button="left"):
    if button == "right":
        _send_mouse(MOUSEEVENTF_RIGHTDOWN)
        _send_mouse(MOUSEEVENTF_RIGHTUP)
    elif button == "middle":
        _send_mouse(MOUSEEVENTF_MIDDLEDOWN)
        _send_mouse(MOUSEEVENTF_MIDDLEUP)
    else:
        _send_mouse(MOUSEEVENTF_LEFTDOWN)
        _send_mouse(MOUSEEVENTF_LEFTUP)

def double_click(button="left"):
    click(button)
    time.sleep(0.05)
    click(button)

def mousedown(button="left"):
    if button == "right":
        _send_mouse(MOUSEEVENTF_RIGHTDOWN)
    elif button == "middle":
        _send_mouse(MOUSEEVENTF_MIDDLEDOWN)
    else:
        _send_mouse(MOUSEEVENTF_LEFTDOWN)

def mouseup(button="left"):
    if button == "right":
        _send_mouse(MOUSEEVENTF_RIGHTUP)
    elif button == "middle":
        _send_mouse(MOUSEEVENTF_MIDDLEUP)
    else:
        _send_mouse(MOUSEEVENTF_LEFTUP)

def scroll(dy):
    """dy > 0 = scroll up, dy < 0 = scroll down (Windows WHEEL_DELTA = 120)."""
    _send_mouse(MOUSEEVENTF_WHEEL, mouse_data=int(dy * 120))

def move_absolute(x, y):
    """Move to absolute screen coords — multi-monitor safe via MOUSEEVENTF_VIRTUALDESK.

    Normalises (x, y) across the full virtual desktop (all monitors) to the
    0-65535 range that SendInput requires, then sends ABSOLUTE | VIRTUALDESK
    so the OS maps it correctly even on secondary displays.
    """
    norm_x = int((int(x) - _vdesk_left) * 65535 / max(_vdesk_w - 1, 1))
    norm_y = int((int(y) - _vdesk_top)  * 65535 / max(_vdesk_h - 1, 1))
    norm_x = max(0, min(65535, norm_x))
    norm_y = max(0, min(65535, norm_y))
    _send_mouse(MOUSEEVENTF_MOVE | MOUSEEVENTF_ABSOLUTE | MOUSEEVENTF_VIRTUALDESK,
                norm_x, norm_y)

def keypress(vk_code, modifiers=None):
    """Press and release a virtual key using SendInput (replaces deprecated keybd_event).

    modifiers: optional list of modifier name strings, e.g. ["ctrl", "shift"].
    Modifier keys are held down for the duration of the main key press, then released.
    """
    mods = [_MODIFIER_VK[m.lower()] for m in (modifiers or []) if m.lower() in _MODIFIER_VK]
    # Build: mod_down... + key_down + key_up + mod_up...
    n = len(mods) * 2 + 2
    arr = (INPUT * n)()
    idx = 0
    for mvk in mods:
        arr[idx].type = INPUT_KEYBOARD
        arr[idx]._input.ki = KEYBDINPUT(wVk=mvk, wScan=0, dwFlags=0, time=0, dwExtraInfo=None)
        idx += 1
    arr[idx].type = INPUT_KEYBOARD
    arr[idx]._input.ki = KEYBDINPUT(wVk=vk_code, wScan=0, dwFlags=0, time=0, dwExtraInfo=None)
    idx += 1
    arr[idx].type = INPUT_KEYBOARD
    arr[idx]._input.ki = KEYBDINPUT(wVk=vk_code, wScan=0, dwFlags=KEYEVENTF_KEYUP, time=0, dwExtraInfo=None)
    idx += 1
    for mvk in reversed(mods):
        arr[idx].type = INPUT_KEYBOARD
        arr[idx]._input.ki = KEYBDINPUT(wVk=mvk, wScan=0, dwFlags=KEYEVENTF_KEYUP, time=0, dwExtraInfo=None)
        idx += 1
    SendInput(n, arr, ctypes.sizeof(INPUT))

def type_text(text):
    """Type a unicode string via SendInput KEYEVENTF_UNICODE — handles any character.

    All key-down/key-up events are sent in a single SendInput call so they
    are processed atomically by the OS (no other process can interleave input).
    """
    if not text:
        return
    n = len(text)
    arr = (INPUT * (n * 2))()
    for i, ch in enumerate(text):
        ucode = ord(ch)
        arr[i * 2].type = INPUT_KEYBOARD
        arr[i * 2]._input.ki = KEYBDINPUT(
            wVk=0, wScan=ucode, dwFlags=KEYEVENTF_UNICODE,
            time=0, dwExtraInfo=None)
        arr[i * 2 + 1].type = INPUT_KEYBOARD
        arr[i * 2 + 1]._input.ki = KEYBDINPUT(
            wVk=0, wScan=ucode, dwFlags=KEYEVENTF_UNICODE | KEYEVENTF_KEYUP,
            time=0, dwExtraInfo=None)
    SendInput(n * 2, arr, ctypes.sizeof(INPUT))

def _smooth_move(dx, dy, steps, delay_s):
    """Relative smooth move with Bresenham-style integer accumulation.

    The naive approach of int(dx/steps) per step loses sub-pixel remainders and
    produces zero motion when dx < steps. Accumulating the error ensures the
    total displacement exactly equals (dx, dy) regardless of step count.
    """
    err_x = err_y = 0.0
    for _ in range(steps):
        err_x += dx / steps
        err_y += dy / steps
        sx = int(err_x); err_x -= sx
        sy = int(err_y); err_y -= sy
        move(sx, sy)
        if delay_s > 0:
            time.sleep(delay_s)

class POINT(ctypes.Structure):
    _fields_ = [("x", ctypes.c_long), ("y", ctypes.c_long)]

def get_cursor_pos():
    """Return current cursor position as (x, y) in screen pixels."""
    pt = POINT()
    ctypes.windll.user32.GetCursorPos(ctypes.byref(pt))
    return pt.x, pt.y

def primary_monitor_idx():
    """Return the mss monitor index (1-based) whose origin is (0, 0) — the Windows primary monitor.
    Falls back to 1 if no such monitor is found."""
    try:
        import mss as _mss
        with _mss.mss() as sct:
            for i, m in enumerate(sct.monitors):
                if i == 0:
                    continue  # index 0 is the virtual desktop spanning all monitors
                if m.get("left", -1) == 0 and m.get("top", -1) == 0:
                    return i
    except Exception:
        pass
    return 1

def draw_cursor_overlay(pil_img, screen_x, screen_y, capture_left, capture_top, scale):
    """Draw a red crosshair on pil_img at the given screen cursor position."""
    from PIL import ImageDraw
    ix = int((screen_x - capture_left) * scale)
    iy = int((screen_y - capture_top)  * scale)
    w, h = pil_img.width, pil_img.height
    if 0 <= ix < w and 0 <= iy < h:
        d = ImageDraw.Draw(pil_img)
        r = 10
        d.line([(max(0, ix - r), iy), (min(w - 1, ix + r), iy)], fill=(255, 0, 0), width=2)
        d.line([(ix, max(0, iy - r)), (ix, min(h - 1, iy + r))], fill=(255, 0, 0), width=2)
        d.ellipse([(ix - 3, iy - 3), (ix + 3, iy + 3)], outline=(255, 255, 0), width=1)
    return pil_img

# ── HTTP server ────────────────────────────────────────────────────────────────

_VIEW_HTML = """<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>eyehands</title>
<style>
*{margin:0;padding:0}
html,body{width:100%;height:100%;background:#000;overflow:hidden;cursor:crosshair}
img{display:block;width:100vw;height:100vh;object-fit:contain;image-rendering:pixelated}
</style></head><body>
<img id="s" src="/latest?token=%%TOKEN%%&t=0" draggable="false">
<script>
const TOKEN='%%TOKEN%%';
const QT=TOKEN?('&token='+encodeURIComponent(TOKEN)):'';
const QT1=TOKEN?('?token='+encodeURIComponent(TOKEN)):'';
const img=document.getElementById('s');
function refresh(){img.src='/latest?t='+Date.now()+QT}
setInterval(refresh,%%INTERVAL%%);
// Click math accounts for object-fit:contain letterboxing: the displayed
// image may be smaller than the img element box, centered with black bars.
img.addEventListener('click',async e=>{
  const r=img.getBoundingClientRect();
  const nW=img.naturalWidth, nH=img.naturalHeight;
  if(!nW||!nH) return;
  const bR=r.width/r.height, iR=nW/nH;
  let dW,dH,dL,dT;
  if(iR>bR){dW=r.width; dH=r.width/iR; dL=0;           dT=(r.height-dH)/2;}
  else     {dH=r.height;dW=r.height*iR;dL=(r.width-dW)/2; dT=0;}
  const rX=(e.clientX-r.left-dL)/dW;
  const rY=(e.clientY-r.top-dT)/dH;
  if(rX<0||rX>1||rY<0||rY>1) return;  // click in letterbox → ignore
  const x=Math.round(rX*nW);
  const y=Math.round(rY*nH);
  const meta=await(await fetch('/latest_b64'+QT1)).json();
  const sx=Math.round(meta.cap_left+x/meta.scale);
  const sy=Math.round(meta.cap_top+y/meta.scale);
  await fetch('/click_at'+QT1,{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({x:sx,y:sy,button:e.button===2?'right':'left'})});
  setTimeout(refresh,150);
});
img.addEventListener('contextmenu',e=>e.preventDefault());
</script></body></html>"""


class Handler(BaseHTTPRequestHandler):
    def setup(self):
        super().setup()
        ctypes.windll.ole32.CoInitialize(None)

    def finish(self):
        ctypes.windll.ole32.CoUninitialize()
        super().finish()

    def log_message(self, fmt, *args):
        msg = fmt % args
        # Scrub any ?token=<value> or &token=<value> so the bearer token
        # doesn't end up in stdout logs when browser access is used.
        if "token=" in msg:
            import re
            msg = re.sub(r'([?&]token=)[^ &"\'\s]+', r'\1<scrubbed>', msg)
        print(f"[{self.address_string()}] {msg}")

    def _check_auth(self):
        """Validate bearer token and Host header. Returns True if request is allowed.

        Two auth methods are accepted:
        - `Authorization: Bearer <token>` header (normal programmatic calls)
        - `?token=<token>` query parameter (for browser address-bar access to
          /view and /screenshot, which can't inject custom headers)
        """
        path = self.path.split("?")[0]
        if "*" in _NO_AUTH_ENDPOINTS or path in _NO_AUTH_ENDPOINTS:
            return True
        # Host header validation — mitigates DNS rebinding attacks
        host = self.headers.get("Host", "")
        if host and not host.startswith(("127.0.0.1", "localhost")):
            self.send_response(403)
            self.send_header("Content-Type", "application/json")
            data = json.dumps({"ok": False, "error": "invalid host header"}).encode()
            self.send_header("Content-Length", len(data))
            self.end_headers()
            self.wfile.write(data)
            return False
        # Bearer token check
        if _auth_token is None:
            return True
        auth = self.headers.get("Authorization", "")
        if auth == f"Bearer {_auth_token}":
            return True
        # Fall back to ?token=<token> query parameter so browser address-bar
        # navigation to /view and /screenshot works (Chrome can't inject
        # custom headers when you type a URL into the address bar).
        try:
            query = urllib.parse.urlparse(self.path).query
            query_token = urllib.parse.parse_qs(query).get("token", [None])[0]
        except Exception:
            query_token = None
        if query_token == _auth_token:
            return True
        self.send_response(401)
        self.send_header("Content-Type", "application/json")
        data = json.dumps({"ok": False, "error": "unauthorized — include 'Authorization: Bearer <token>' header or ?token=<token> query param"}).encode()
        self.send_header("Content-Length", len(data))
        self.end_headers()
        self.wfile.write(data)
        return False

    def send_json(self, code, body):
        data = json.dumps(body).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", len(data))
        self.end_headers()
        self.wfile.write(data)

    def send_jpeg(self, data):
        self.send_response(200)
        self.send_header("Content-Type", "image/jpeg")
        self.send_header("Content-Length", len(data))
        self.end_headers()
        self.wfile.write(data)

    def read_body(self):
        length = int(self.headers.get("Content-Length", 0))
        if not length:
            return {}
        raw = self.rfile.read(length)
        try:
            return json.loads(raw)
        except json.JSONDecodeError as exc:
            raise ValueError(f"invalid JSON body: {exc}") from exc

    def _exec_action(self, action):
        """Execute a single action dict. Returns a result dict."""
        t = action.get("action") or action.get("type")
        if t == "move":
            move(action.get("dx", 0), action.get("dy", 0))
        elif t == "move_absolute":
            move_absolute(action.get("x", 0), action.get("y", 0))
        elif t == "click":
            click(action.get("button", "left"))
        elif t == "double_click":
            double_click(action.get("button", "left"))
        elif t == "mousedown":
            mousedown(action.get("button", "left"))
        elif t == "mouseup":
            mouseup(action.get("button", "left"))
        elif t == "scroll":
            scroll(action.get("dy", 0))
        elif t == "key":
            keypress(action.get("vk", 0), action.get("modifiers"))
        elif t == "type_text":
            type_text(action.get("text", ""))
        elif t == "sleep":
            time.sleep(action.get("ms", 0) / 1000.0)
        elif t == "ui_click":
            results = ui_find(
                window_title=action.get("window"),
                name=action.get("name"),
                control_type=action.get("type"),
                depth=action.get("depth", 6),
                max_results=1,
            )
            if results:
                el = results[0]
                cx, cy = el.get("center_x"), el.get("center_y")
                if cx is not None and cy is not None:
                    move_absolute(cx, cy)
                    time.sleep(0.05)
                    click(action.get("button", "left"))
                    return {"ok": True, "clicked": el}
            return {"ok": False, "error": "element not found"}
        elif t == "smooth_move":
            _smooth_move(
                action.get("dx", 0),
                action.get("dy", 0),
                max(1, action.get("steps", 10)),
                action.get("delay_ms", 4) / 1000.0,
            )
        else:
            return {"ok": False, "error": f"unknown action: {t}"}
        return {"ok": True}

    def _require_pro(self, path):
        """Return True (and send 402) if path needs Pro and user doesn't have it."""
        if _is_pro_endpoint(path) and not _pro_active:
            self.send_json(402, {
                "ok": False,
                "error": "Pro license required",
                "endpoint": path,
                "upgrade": "https://portal.fireal.dev",
                "activate": "POST /activate {\"key\": \"YOUR-LICENSE-KEY\"}",
            })
            return True
        return False

    def do_POST(self):
        if not self._check_auth():
            return
        try:
            body = self.read_body()
            path = self.path.split("?")[0]

            if path == "/activate":
                key = body.get("key", "").strip()
                if not key:
                    self.send_json(400, {"ok": False, "error": "key is required"})
                else:
                    ok, msg = _activate_license(key)
                    if ok:
                        _check_pro()
                    self.send_json(200 if ok else 400, {"ok": ok, "message": msg,
                                                         "tier": "Pro" if _pro_active else "Free"})
                return

            if path == "/update":
                # Self-update: spawn a detached helper that waits for us to
                # exit, runs `pip install --upgrade eyehands` (pulling from
                # PyPI), and relaunches via `python -m eyehands`.
                # Refuse if we're running from a git checkout — pip install
                # would install eyehands globally as a side effect but the
                # helper would relaunch via `python -m eyehands` which, from a
                # checkout cwd, picks up the in-tree copy that pip never touches,
                # so the "update" is silently a no-op. Detect checkouts by the
                # presence of pyproject.toml in _DATA_DIR (set by _get_data_dir).
                if os.path.exists(os.path.join(_DATA_DIR, "pyproject.toml")):
                    self.send_json(409, {
                        "ok": False,
                        "error": "running from source checkout — use 'git pull && python -m eyehands' to upgrade",
                    })
                    return
                if not _update_available:
                    self.send_json(409, {"ok": False, "error": "no update available"})
                    return

                helper_path = _write_update_helper()
                target_version = _update_available["latest"]

                subprocess.Popen(
                    [sys.executable, helper_path, str(os.getpid()), _UPDATE_LOG_FILE],
                    close_fds=True,
                    creationflags=subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP,
                )

                self.send_json(200, {
                    "ok": True,
                    "message": f"Installing eyehands {target_version}. Server will restart in a few seconds.",
                    "log_file": ".update_log.txt",
                })
                try:
                    self.wfile.flush()
                except Exception:
                    pass

                # Hard-exit on a delay so the response makes it onto the wire.
                # os._exit skips finally/atexit, which is what we want — the
                # new server's _kill_existing_instance will overwrite the PID
                # file. The helper waits for us to exit before pip install.
                def _exit_soon():
                    time.sleep(1)
                    os._exit(0)
                threading.Thread(target=_exit_soon, daemon=True).start()
                return

            if self._require_pro(path):
                return

            if path == "/move":
                move(body.get("dx", 0), body.get("dy", 0))
                self.send_json(200, {"ok": True})

            elif path == "/click":
                click(body.get("button", "left"))
                self.send_json(200, {"ok": True})

            elif path == "/double_click":
                double_click(body.get("button", "left"))
                self.send_json(200, {"ok": True})

            elif path == "/mousedown":
                mousedown(body.get("button", "left"))
                self.send_json(200, {"ok": True})

            elif path == "/mouseup":
                mouseup(body.get("button", "left"))
                self.send_json(200, {"ok": True})

            elif path == "/scroll":
                scroll(body.get("dy", 0))
                self.send_json(200, {"ok": True})

            elif path == "/key":
                keypress(body.get("vk", 0), body.get("modifiers"))
                self.send_json(200, {"ok": True})

            elif path == "/type_text":
                type_text(body.get("text", ""))
                self.send_json(200, {"ok": True})

            elif path == "/move_absolute":
                move_absolute(body.get("x", 0), body.get("y", 0))
                self.send_json(200, {"ok": True})

            elif path == "/smooth_move":
                _smooth_move(
                    body.get("dx", 0),
                    body.get("dy", 0),
                    max(1, body.get("steps", 10)),
                    body.get("delay_ms", 4) / 1000.0,
                )
                self.send_json(200, {"ok": True})

            elif path == "/ui/click_element":
                results = ui_find(
                    window_title=body.get("window"),
                    name=body.get("name"),
                    control_type=body.get("type"),
                    depth=body.get("depth", 6),
                    max_results=1,
                )
                if not results:
                    self.send_json(404, {"ok": False, "error": "element not found"})
                else:
                    el = results[0]
                    cx, cy = el.get("center_x"), el.get("center_y")
                    if cx is None or cy is None:
                        self.send_json(400, {"ok": False, "error": "element has no bounding rect"})
                    else:
                        move_absolute(cx, cy)
                        time.sleep(0.05)
                        click(body.get("button", "left"))
                        self.send_json(200, {"ok": True, "clicked": el})

            elif path == "/click_at":
                x, y = body.get("x", 0), body.get("y", 0)
                move_absolute(x, y)
                time.sleep(0.05)
                click(body.get("button", "left"))
                self.send_json(200, {"ok": True, "x": x, "y": y})

            elif path == "/click_and_wait":
                x, y = body.get("x", 0), body.get("y", 0)
                timeout_ms = body.get("timeout_ms", 2000)
                move_absolute(x, y)
                time.sleep(0.05)
                click(body.get("button", "left"))
                # Wait until the frame changes or timeout
                ts_before = _frame_buf.frame_hash()
                deadline = time.monotonic() + timeout_ms / 1000.0
                changed = False
                while time.monotonic() < deadline:
                    time.sleep(0.05)
                    if _frame_buf.frame_hash() != ts_before:
                        # Frame changed — wait a bit more for UI to settle
                        time.sleep(0.15)
                        changed = True
                        break
                self.send_json(200, {"ok": True, "x": x, "y": y, "changed": changed})

            elif path == "/type_and_enter":
                txt = body.get("text", "")
                type_text(txt)
                time.sleep(0.03)
                keypress(0x0D)  # VK_RETURN
                self.send_json(200, {"ok": True, "text": txt})

            elif path == "/batch":
                actions    = body.get("actions", [])
                if len(actions) > 100:
                    self.send_json(400, {"ok": False, "error": f"batch limited to 100 actions, got {len(actions)}"})
                    return
                between_ms = body.get("delay_ms", 0) / 1000.0
                results = []
                for act in actions:
                    res = self._exec_action(act)
                    results.append(res)
                    if between_ms > 0:
                        time.sleep(between_ms)
                self.send_json(200, {"ok": True, "results": results})

            else:
                self.send_json(404, {"ok": False, "error": "unknown endpoint"})

        except Exception as e:
            self.send_json(500, {"ok": False, "error": str(e)})

    def _parse_qs(self, path):
        qs = {}
        if "?" in path:
            for part in path.split("?", 1)[1].split("&"):
                if "=" in part:
                    k, v = part.split("=", 1)
                    qs[urllib.parse.unquote(k)] = urllib.parse.unquote(v)
        return qs

    def _grab(self, qs):
        """Capture a screen region (or window) and encode it in the requested format.

        Returns (image_bytes, metadata_dict). Metadata always contains
        cursor_x/y, scale, cap_left/top, img_w/h, format, content_type.

        Query params:
          monitor=N      (1-based, default = primary monitor)
          hwnd=HANDLE    (window handle; takes precedence over monitor/region,
                          captures the window via PrintWindow regardless of z-order)
          x, y, w, h    (region in physical screen pixels; optional, default = full monitor)
          raw=1          (bypass max_w downscale and return physical pixels)
          max_w          (max output width in pixels, default 1920; ignored if raw=1)
          quality        (JPEG/WebP quality 1-95, default 70; ignored for PNG)
          format         (jpeg|png|webp; default jpeg)
          cursor=1       (overlay a red crosshair at the current cursor position)
        """
        import numpy as np
        monitor_idx = int(qs.get("monitor", primary_monitor_idx()))
        max_w       = int(qs.get("max_w", 1920))
        quality     = int(qs.get("quality", 70))
        show_cursor = qs.get("cursor", "0") == "1"
        raw_mode    = qs.get("raw", "0") == "1"
        fmt         = _normalize_format(qs.get("format", "jpeg"))

        cx, cy = get_cursor_pos()

        hwnd_str = qs.get("hwnd")
        if hwnd_str:
            arr, cap_left, cap_top = _grab_hwnd(int(hwnd_str))
        else:
            with mss.mss() as sct:
                monitors = sct.monitors
                mon = monitors[monitor_idx] if monitor_idx < len(monitors) else monitors[1]
                if "x" in qs and "y" in qs and "w" in qs and "h" in qs:
                    region = {
                        "left":   mon["left"] + int(qs["x"]),
                        "top":    mon["top"]  + int(qs["y"]),
                        "width":  int(qs["w"]),
                        "height": int(qs["h"]),
                    }
                else:
                    region = mon
                img = sct.grab(region)
                # BGRA → RGB via numpy, no PIL Image roundtrip.
                buf = np.frombuffer(img.bgra, dtype=np.uint8)
                arr = buf.reshape((img.height, img.width, 4))[:, :, [2, 1, 0]]
                arr = np.ascontiguousarray(arr)
                cap_left = region["left"]
                cap_top  = region["top"]

        scale = 1.0
        if not raw_mode:
            arr, scale = _resize_rgb_fast(arr, max_w)

        if show_cursor:
            # Cursor overlay goes through PIL because ImageDraw is easier than
            # hand-rolled numpy slicing. Only paid when explicitly requested.
            from PIL import Image
            pil_img = draw_cursor_overlay(
                Image.fromarray(arr), cx, cy, cap_left, cap_top, scale
            )
            arr = np.asarray(pil_img)

        data, content_type = _encode_rgb(arr, fmt=fmt, quality=quality)

        h, w = arr.shape[:2]
        meta = {
            "cursor_x":     cx,
            "cursor_y":     cy,
            "scale":        scale,
            "cap_left":     cap_left,
            "cap_top":      cap_top,
            "img_w":        w,
            "img_h":        h,
            "format":       fmt,
            "content_type": content_type,
        }
        return data, meta

    def do_GET(self):
        if not self._check_auth():
            return
        base = self.path.split("?")[0]

        if base == "/license":
            self.send_json(200, {
                "ok": True,
                "tier": "Pro" if _pro_active else "Free",
                "version": __version__,
                "pro_endpoints": sorted(_PRO_ENDPOINTS),
                "upgrade": "https://portal.fireal.dev",
            })
            return

        if self._require_pro(base):
            return

        if base == "/ping":
            self.send_json(200, {
                "ok": True,
                "status": "running",
                "version": __version__,
                "tier": "Pro" if _pro_active else "Free",
                "update_available": _update_available,
                "capture_backend": _capture_backend,
                "tips": _build_tips(),
            })

        elif base == "/cursor_pos":
            x, y = get_cursor_pos()
            self.send_json(200, {"ok": True, "x": x, "y": y})

        elif base == "/screenshot":
            qs = self._parse_qs(self.path)
            try:
                data, meta = self._grab(qs)
                self.send_response(200)
                self.send_header("Content-Type", meta.get("content_type", "image/jpeg"))
                self.send_header("Content-Length", len(data))
                self.end_headers()
                self.wfile.write(data)
            except Exception as e:
                self.send_json(500, {"ok": False, "error": str(e)})

        elif base == "/screenshot_b64":
            qs = self._parse_qs(self.path)
            try:
                data, meta = self._grab(qs)
                self.send_json(200, {"ok": True, "image": base64.b64encode(data).decode(), **meta})
            except Exception as e:
                self.send_json(500, {"ok": False, "error": str(e)})

        elif base == "/latest":
            qs = self._parse_qs(self.path)
            fmt = _normalize_format(qs.get("format", "jpeg"))
            cur_ts = _frame_buf.frame_hash() if _frame_buf else 0.0
            etag = f'"{cur_ts}"'

            # Client-side caching: 304 Not Modified when the caller already has
            # the current frame. Accept either HTTP ETag (If-None-Match) or a
            # ?since=<float> query param so browser-style address-bar polling
            # can participate too.
            since_param = qs.get("since")
            try:
                since_f = float(since_param) if since_param is not None else None
            except ValueError:
                since_f = None
            if_none_match = self.headers.get("If-None-Match", "")
            already_has = (
                (if_none_match and if_none_match == etag) or
                (since_f is not None and cur_ts <= since_f)
            )
            if already_has and cur_ts > 0:
                self.send_response(304)
                self.send_header("ETag", etag)
                self.send_header("X-Frame-Hash", str(cur_ts))
                self.end_headers()
                return

            # Fast path: default JPEG with buffer-native quality → ship cached bytes.
            quality_override = qs.get("quality")
            if fmt == "jpeg" and quality_override is None:
                data, ts = _frame_buf.latest_bytes()
                if data is None:
                    self.send_json(503, {"ok": False, "error": "no frame yet"})
                    return
                content_type = "image/jpeg"
            else:
                arr, ts, _cx, _cy, _sc, _mon, _iw, _ih, _err = _frame_buf.latest_array()
                if arr is None:
                    self.send_json(503, {"ok": False, "error": "no frame yet"})
                    return
                q = int(quality_override) if quality_override is not None else _frame_buf.quality
                data, content_type = _encode_rgb(arr, fmt=fmt, quality=q)

            self.send_response(200)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", len(data))
            self.send_header("X-Timestamp", str(ts))
            self.send_header("X-Frame-Hash", str(ts))
            self.send_header("ETag", f'"{ts}"')
            self.end_headers()
            self.wfile.write(data)

        elif base == "/latest_b64":
            qs = self._parse_qs(self.path)
            fmt = _normalize_format(qs.get("format", "jpeg"))
            quality_override = qs.get("quality")

            if fmt == "jpeg" and quality_override is None:
                b64, ts, cx, cy, scale, mon, img_w, img_h, err = _frame_buf.latest_b64()
                content_type = "image/jpeg"
            else:
                arr, ts, cx, cy, scale, mon, img_w, img_h, err = _frame_buf.latest_array()
                if arr is None:
                    self.send_json(503, {"ok": False, "error": "no frame yet"})
                    return
                q = int(quality_override) if quality_override is not None else _frame_buf.quality
                data, content_type = _encode_rgb(arr, fmt=fmt, quality=q)
                b64 = base64.b64encode(data).decode()

            if b64 is None:
                self.send_json(503, {"ok": False, "error": "no frame yet"})
                return

            resp = {
                "ok":           True,
                "image":        b64,
                "ts":           ts,
                "age_ms":       round((time.monotonic() - ts) * 1000, 1),
                "cursor_x":     cx,
                "cursor_y":     cy,
                "scale":        scale,
                "cap_left":     mon.get("left", 0),
                "cap_top":      mon.get("top", 0),
                "img_w":        img_w,
                "img_h":        img_h,
                "format":       fmt,
                "content_type": content_type,
                "frame_hash":   ts,
            }
            if err:
                resp["capture_errors"] = err
            resp["update_available"] = _update_available
            self.send_json(200, resp)

        elif base == "/ui/windows":
            try:
                self.send_json(200, {"ok": True, "windows": ui_list_windows()})
            except Exception as e:
                self.send_json(500, {"ok": False, "error": str(e)})

        elif base == "/ui/at":
            qs = self._parse_qs(self.path)
            try:
                x = int(qs.get("x", 0))
                y = int(qs.get("y", 0))
                el = ui_element_at(x, y)
                self.send_json(200, {"ok": True, "element": el})
            except Exception as e:
                self.send_json(500, {"ok": False, "error": str(e)})

        elif base == "/ui/find":
            qs = self._parse_qs(self.path)
            try:
                results = ui_find(
                    window_title=qs.get("window"),
                    name=qs.get("name"),
                    control_type=qs.get("type"),
                    depth=int(qs.get("depth", 6)),
                    max_results=int(qs.get("max", 20)),
                )
                self.send_json(200, {"ok": True, "elements": results, "count": len(results)})
            except Exception as e:
                self.send_json(500, {"ok": False, "error": str(e)})

        elif base == "/ui/tree":
            qs = self._parse_qs(self.path)
            try:
                tree = ui_tree(
                    window_title=qs.get("window"),
                    depth=int(qs.get("depth", 3)),
                )
                self.send_json(200, {"ok": True, "tree": tree})
            except Exception as e:
                self.send_json(500, {"ok": False, "error": str(e)})

        elif base == "/view":
            qs = self._parse_qs(self.path)
            interval = int(qs.get("fps", 2))
            interval_ms = max(100, 1000 // max(1, interval))
            html = _VIEW_HTML.replace("%%INTERVAL%%", str(interval_ms))
            # Embed the bearer token server-side so the HTML's own /latest
            # polling, /latest_b64 fetch, and /click_at POST can authenticate
            # via the query-param fallback. See _check_auth() for the match.
            html = html.replace("%%TOKEN%%", _auth_token or "")
            data = html.encode()
            self.send_response(200)
            self.send_header("Content-Type", "text/html")
            self.send_header("Content-Length", len(data))
            self.end_headers()
            self.wfile.write(data)

        elif base == "/find":
            # OCR-based text search — returns exact screen coordinates.
            # Usage: /find?text=Generate
            #        /find?text=Generate&x=140&y=100&w=400&h=300
            # Returns: {"ok": true, "found": true, "matches": [{"label":"...", "x":382, "y":237, "conf":0.9}]}
            # This is the PRIMARY way to locate UI elements in non-UIA apps (games, Godot, Electron).
            qs = self._parse_qs(self.path)
            text = qs.get("text", "")
            if not text:
                self.send_json(400, {"ok": False, "error": "text parameter required"})
            else:
                try:
                    from PIL import Image
                    import numpy as np
                    import base64 as _b64
                    import io as _io

                    # Grab the region (or full screen)
                    grab_qs = {k: v for k, v in qs.items() if k in ("x", "y", "w", "h")}
                    data, meta = self._grab(grab_qs)
                    img = Image.open(_io.BytesIO(data)).convert("RGB")
                    arr = np.array(img)
                    cap_left = meta["cap_left"]
                    cap_top  = meta["cap_top"]
                    scale    = meta["scale"]

                    # Lazy-load EasyOCR — cached after first call
                    global _ocr_reader, _ocr_cache_ts, _ocr_cache_results
                    with _ocr_lock:
                        if _ocr_reader is None:
                            import easyocr
                            _ocr_reader = easyocr.Reader(["en"], gpu=False, verbose=False)

                        # Reuse cached OCR results if frame hasn't changed (full-screen only)
                        cur_ts = _frame_buf.frame_hash() if _frame_buf else 0
                        if not grab_qs and cur_ts == _ocr_cache_ts and _ocr_cache_results:
                            results = _ocr_cache_results
                        else:
                            results = _ocr_reader.readtext(arr)
                            if not grab_qs:
                                _ocr_cache_ts = cur_ts
                                _ocr_cache_results = results
                    query_l = text.lower()
                    matches = []
                    for (bbox, t, conf) in results:
                        if query_l in t.lower():
                            xs = [p[0] for p in bbox]
                            ys = [p[1] for p in bbox]
                            cx = int((min(xs) + max(xs)) / 2)
                            cy = int((min(ys) + max(ys)) / 2)
                            sx = int(cap_left + cx / scale)
                            sy = int(cap_top  + cy / scale)
                            matches.append({"label": t, "x": sx, "y": sy, "conf": round(conf, 3)})

                    self.send_json(200, {"ok": True, "found": len(matches) > 0, "matches": matches})
                except Exception as e:
                    self.send_json(500, {"ok": False, "error": str(e)})

        else:
            self.send_json(404, {"ok": False})


def main():
    """CLI entry point. Parses args, starts the HTTP server, blocks until Ctrl+C."""
    global _auth_token, _update_available, _frame_buf, _tips_enabled

    parser = argparse.ArgumentParser(description="eyehands — give AI agents eyes and hands on Windows")
    parser.add_argument("--host", default="127.0.0.1", help="bind address (default: 127.0.0.1)")
    parser.add_argument("--port", type=int, default=7331, help="listen port (default: 7331)")
    parser.add_argument("--max-w", type=int, default=1920, help="max capture width in pixels (default: 1920)")
    parser.add_argument("--quality", type=int, default=70, help="JPEG quality 1-95 (default: 70)")
    parser.add_argument("--fps", type=int, default=20, help="background capture FPS (default: 20)")
    parser.add_argument("--no-auth", action="store_true", help="disable bearer token auth (not recommended)")
    parser.add_argument("--no-tips", action="store_true", help="suppress startup tips and /ping tips field")
    parser.add_argument("--version", action="version", version=f"eyehands v{__version__}")
    args = parser.parse_args()

    _tips_enabled = not args.no_tips

    # Kill any existing instance before binding — prevents port pile-up.
    _kill_existing_instance()

    host, port = args.host, args.port
    print(f"eyehands v{__version__}")
    print(f"Virtual desktop: left={_vdesk_left} top={_vdesk_top} "
          f"{_vdesk_w}x{_vdesk_h} (spans all monitors)")

    # Auth
    if args.no_auth:
        _auth_token = None  # disable auth
        _NO_AUTH_ENDPOINTS.clear()
        _NO_AUTH_ENDPOINTS.update({"*"})  # sentinel — _check_auth always passes
        print("[auth] DISABLED (--no-auth)")
    else:
        print(f"[auth] Bearer token: {_auth_token}")
        print(f"[auth] Token saved to: {_TOKEN_FILE}")
        print(f"[auth] Usage: curl -H 'Authorization: Bearer {_auth_token}' http://{host}:{port}/screenshot")

    # Validate license (non-blocking — falls back to Free tier on timeout)
    _check_pro()

    # Check for an available update (5s timeout — must not block startup)
    _update_available = _check_for_updates()
    if _update_available:
        print(f"[update] eyehands {_update_available['latest']} is available "
              f"(you're on {_update_available['current']}).")
        print("[update] Run: pip install -U eyehands")
        print(f"[update] Or:  curl -X POST http://{host}:{port}/update -H \"Authorization: Bearer $(cat .eyehands-token)\"")

    print(f"Starting background frame capture ({args.fps} fps)...")
    _frame_buf = FrameBuffer(monitor_idx=primary_monitor_idx(), max_w=args.max_w, quality=args.quality, fps=args.fps)

    try:
        server = ThreadingHTTPServer((host, port), Handler)
    except OSError as e:
        print(f"[error] Could not bind to {host}:{port} — {e}")
        print("[error] Another process may still hold the port.")
        print(f"[error] Run: netstat -ano | findstr {port}  then taskkill /F /PID <pid>")
        raise SystemExit(1)

    _write_pid()
    print(f"eyehands listening on http://{host}:{port}  (PID {os.getpid()})")
    print("Free endpoints:")
    print("  POST: /move  /move_absolute  /click  /double_click  /mousedown  /mouseup")
    print("        /scroll  /key  /type_text")
    print("  GET:  /ping  /cursor_pos  /screenshot  /screenshot_b64  /latest  /latest_b64")
    print("        /view  /find  /license")
    print("Pro endpoints:" + (" [active]" if _pro_active else " [locked — upgrade at portal.fireal.dev]"))
    print("  POST: /smooth_move  /batch  /click_at  /click_and_wait  /type_and_enter")
    print("        /ui/click_element")
    print("  GET:  /ui/windows  /ui/find  /ui/at  /ui/tree")
    if not _pro_active:
        print(f"\nActivate Pro: curl -X POST http://{host}:{port}/activate "
              "-H 'Content-Type: application/json' -d '{\"key\":\"YOUR-KEY\"}'")
    print(f"\nCoordinate mapping: screen_x = cap_left + (img_pixel_x / scale)")

    if _tips_enabled:
        print()
        print("Tip: For the smoothest screenshot workflow, install Claude's Chrome")
        print("     extension. The eyehands skill will then use Chrome MCP + /view")
        print("     for one-tool-call captures instead of curl -> save -> read.")
        print("     (suppress with --no-tips)")

    print("Press Ctrl+C to stop.")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped.")
    finally:
        _remove_pid()


if __name__ == "__main__":
    main()
