"""eyehands — give AI agents eyes and hands on Windows.

Local HTTP server on port 7331 for screen capture, mouse/keyboard input,
Windows UI Automation, and license-gated Pro features.
"""

from .server import __version__

__all__ = ["__version__"]
