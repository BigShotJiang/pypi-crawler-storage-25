"""
eyehands find.py — locate UI elements without visual estimation.

Usage:
    python find.py --text "Generate"
    python find.py --text "Generate" --region 140 100 400 300
    python find.py --color button --region 140 100 400 300
    python find.py --text "Generate" --color button --region 140 100 400 300

Output (JSON to stdout):
    {"found": true, "matches": [{"label": "Generate", "x": 382, "y": 237}]}
    {"found": false, "matches": []}

Coordinates are always in absolute screen pixels, ready for /move_absolute.
"""

import argparse
import base64
import io
import json
import sys
import urllib.request

import numpy as np
from PIL import Image

SERVER = "http://127.0.0.1:7331"


# ── Screenshot ─────────────────────────────────────────────────────────────────

def grab(region=None):
    """Grab a screenshot region. Returns (PIL.Image, cap_left, cap_top, scale)."""
    url = f"{SERVER}/screenshot_b64"
    if region:
        x, y, w, h = region
        url += f"?x={x}&y={y}&w={w}&h={h}"
    with urllib.request.urlopen(url) as r:
        d = json.load(r)
    img = Image.open(io.BytesIO(base64.b64decode(d["image"]))).convert("RGB")
    return img, d.get("cap_left", 0), d.get("cap_top", 0), d.get("scale", 1.0)


# ── OCR ────────────────────────────────────────────────────────────────────────

_ocr_reader = None

def ocr_reader():
    global _ocr_reader
    if _ocr_reader is None:
        import easyocr
        _ocr_reader = easyocr.Reader(["en"], gpu=False, verbose=False)
    return _ocr_reader


def find_text(img, query, cap_left, cap_top, scale):
    """Return list of {label, x, y} for text matches (case-insensitive)."""
    arr = np.array(img)
    results = ocr_reader().readtext(arr)
    query_l = query.lower()
    matches = []
    for (bbox, text, conf) in results:
        if query_l in text.lower():
            # bbox: [[x0,y0],[x1,y0],[x1,y1],[x0,y1]] in image pixels
            xs = [p[0] for p in bbox]
            ys = [p[1] for p in bbox]
            cx = int((min(xs) + max(xs)) / 2)
            cy = int((min(ys) + max(ys)) / 2)
            # convert image pixel → screen pixel
            sx = int(cap_left + cx / scale)
            sy = int(cap_top  + cy / scale)
            matches.append({"label": text, "x": sx, "y": sy, "conf": round(conf, 3)})
    return matches


# ── Color / button detection ───────────────────────────────────────────────────

# Named color targets — add more as needed.
COLOR_PRESETS = {
    # Godot dark-theme button (slightly lighter than background)
    "button":      {"rgb_min": (55, 55, 55),  "rgb_max": (90, 90, 95),  "min_area": 600},
    # Godot active/accent button (blue tint)
    "button_blue": {"rgb_min": (50, 80, 130),  "rgb_max": (90, 130, 200), "min_area": 400},
    # Bright / highlighted button
    "button_bright":{"rgb_min": (100,100,100), "rgb_max": (180,180,190), "min_area": 400},
    # Checkbox (blue tick)
    "checkbox_on": {"rgb_min": (50, 100, 200), "rgb_max": (80, 160, 255), "min_area": 50},
}


def find_color(img, preset_name, cap_left, cap_top, scale):
    """Return list of {label, x, y} for rectangular regions matching a color preset."""
    preset = COLOR_PRESETS.get(preset_name)
    if preset is None:
        return []

    arr = np.array(img)
    lo  = np.array(preset["rgb_min"], dtype=np.uint8)
    hi  = np.array(preset["rgb_max"], dtype=np.uint8)
    min_area = preset["min_area"]

    mask = np.all((arr >= lo) & (arr <= hi), axis=2).astype(np.uint8) * 255

    import cv2
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    matches = []
    for c in contours:
        area = cv2.contourArea(c)
        if area < min_area:
            continue
        rx, ry, rw, rh = cv2.boundingRect(c)
        cx = int(cap_left + (rx + rw / 2) / scale)
        cy = int(cap_top  + (ry + rh / 2) / scale)
        matches.append({
            "label": preset_name,
            "x": cx, "y": cy,
            "w": int(rw / scale), "h": int(rh / scale),
            "area": int(area),
        })
    # sort by area descending (largest first)
    matches.sort(key=lambda m: m["area"], reverse=True)
    return matches


# ── Main ───────────────────────────────────────────────────────────────────────

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--text",   help="Text to find via OCR (case-insensitive)")
    ap.add_argument("--color",  help="Color preset to detect: " + ", ".join(COLOR_PRESETS))
    ap.add_argument("--region", nargs=4, type=int, metavar=("X","Y","W","H"),
                    help="Screen region to search (default: full primary monitor)")
    args = ap.parse_args()

    if not args.text and not args.color:
        print(json.dumps({"error": "specify --text and/or --color"}))
        sys.exit(1)

    img, cap_left, cap_top, scale = grab(args.region)

    matches = []
    if args.text:
        matches += find_text(img, args.text, cap_left, cap_top, scale)
    if args.color:
        matches += find_color(img, args.color, cap_left, cap_top, scale)

    print(json.dumps({"found": len(matches) > 0, "matches": matches}, indent=2))


if __name__ == "__main__":
    main()
