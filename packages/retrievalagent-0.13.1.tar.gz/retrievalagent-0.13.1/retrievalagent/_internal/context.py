"""Boot-time context builder for ``AgenticRAG``.

``AgenticRAG.__init__`` used to inline ~340 lines of config resolution,
schema introspection, LLM chain wiring, and embedder validation. This
module factors those steps into a single ``RAGContext`` value so the
constructor body becomes a thin assignment block.

The builder is deliberately scoped to *value computation* — anything the
constructor can do without referring to ``self``. Instance-bound steps
that depend on mixin state (``_auto_init_filters``, ``_build_graph``,
``_build_agent``) stay in ``__init__``. This keeps the refactor
behaviour-preserving and avoids leaking mixin internals into a helper
that lives outside the class hierarchy.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Callable, Literal

from ..backend import InMemoryBackend, SearchBackend, _MultiBackend
from ..helpers.schema_introspect import (
    _align_embed_fn_with_backend,
    _detect_category_fields,
    _detect_embedder_name,
    _detect_index_signals,
    _has_is_own_brand_field,
    _validate_embedder_name,
)
from ..models import (
    AnswerGrade,
    CloseMatchKeep,
    CollectionIntent,
    FieldPriority,
    FilterIntent,
    MultiQuery,
    NoResultSuggestion,
    ProductCodeQuery,
    QualityAssessment,
    RelevanceCheck,
    Reranker,
    SearchQuery,
    StandaloneQuery,
    SynonymResult,
)

if TYPE_CHECKING:
    from collections.abc import Mapping

    from langchain_core.language_models import BaseChatModel

    from ..config import RAGConfig
    from ..rerankers import CohereReranker, LLMReranker


# Filter intent words copied from core to keep the builder self-contained.
# Keep in sync with ``retrievalagent.core._FILTER_INTENT_WORDS_BY_LANG``.
_FILTER_INTENT_WORDS_BY_LANG: dict[str, frozenset[str]] = {
    "de": frozenset(
        {
            "von",
            "vom",
            "aus",
            "ohne",
            "nicht",
            "kein",
            "keine",
            "für",
            "fur",
            "bei",
            "mit",
        }
    ),
    "fr": frozenset({"de", "du", "des", "sans", "pour", "par", "pas", "avec", "chez"}),
    "it": frozenset({"di", "da", "del", "della", "senza", "non", "per", "con"}),
    "en": frozenset({"from", "without", "not", "no", "for", "by", "of", "with"}),
}


@dataclass(frozen=True)
class RAGContext:
    """Resolved configuration produced before mixin-state init runs.

    Every field is a value the constructor will copy onto ``self`` as-is.
    Frozen so callers can't accidentally mutate intermediate state during
    boot — the agent itself remains mutable after construction.
    """

    # collections / backend
    backend: SearchBackend
    collections: dict[str, SearchBackend] | None
    collection_descriptions: dict[str, str]

    # numeric knobs
    top_k: int
    rerank_top_n: int
    retrieval_factor: int
    min_rerank_pool: int
    memory_relevance_threshold: float
    memory_storage_threshold: float
    max_iter: int
    n_swarm_queries: int
    rerank_chars: int
    hyde_min_words: int
    expert_top_n: int
    expert_threshold: float | None
    rerank_cap_multiplier: float
    short_query_threshold: int
    short_query_sort_tokens: bool
    bm25_fallback_threshold: float | None
    bm25_fallback_semantic_ratio: float
    fast_accept_score: float | None
    fast_accept_confidence: float | None
    rerank_min_score: float | None
    name_field_boost_max: float
    preview_chars: int
    final_grade_threshold: float
    reranker_trust_top_score: float
    reranker_trust_score_gap: float
    n_synonym_variants: int
    close_match_min_top_rerank: float | None
    rerank_timeout_s: float
    llm_timeout_s: float
    semantic_ratio: float

    # flags / strings
    verbose: bool
    fusion: Literal["rrf", "dbsf"]
    instructions: str
    filter: str | None
    group_field: str
    name_field: str
    enable_hyde: bool
    enable_filter_intent: bool
    enable_preprocess_llm: bool
    enable_final_grade: bool
    enable_swarm_grade: bool
    enable_reranker: bool
    enable_elbow_cutoff: bool
    enable_close_match_grader: bool
    close_match_strictness: str
    custom_instructions: str
    embedder_name: str

    # callables / structured data
    embed_fn: Callable[[str], list[float]] | None
    boost_fn: Callable[[dict], float] | None
    sort_fields: list[str]
    num_fields: list[str]
    category_fields: list[str]
    primary_preference_field: str | None
    has_own_brand_field: bool
    filter_intent_words: frozenset[str]
    trace_callback: Callable[[dict[str, Any]], None] | None

    # llms
    llm: "BaseChatModel"
    gen_llm: "BaseChatModel"
    thinking_llm: "BaseChatModel"
    grader_llm: "BaseChatModel"
    reranker: "Reranker | CohereReranker | LLMReranker"
    expert_reranker: "Reranker | CohereReranker | LLMReranker | None"

    # backend index config + structured chains
    index_config: Any
    search_query_chain: Any
    quality_chain: Any
    multi_query_chain: Any
    filter_intent_chain: Any
    select_collection_chain: Any
    field_priority_chain: Any
    relevance_chain: Any
    grade_chain: Any
    product_code_chain: Any
    close_match_chain: Any
    close_match_chain_strong: Any
    synonym_chain: Any
    suggestion_chain: Any
    standalone_chain: Any

    # passthroughs
    checkpointer: Any
    memory_store: Any
    mem0_memory: Any

    # mutable scratch dicts the agent will own after construction
    field_values_cache: dict = field(default_factory=dict)
    filter_values: dict[str, list[str]] = field(default_factory=dict)

    @classmethod
    def build(
        cls,
        *,
        backend: SearchBackend | None,
        collections: "Mapping[str, SearchBackend] | None",
        collection_descriptions: "Mapping[str, str] | None",
        llm: "BaseChatModel | None",
        gen_llm: "BaseChatModel | None",
        reranker: "Reranker | CohereReranker | LLMReranker | None",
        expert_reranker: "Reranker | CohereReranker | LLMReranker | None",
        top_k: int | None,
        rerank_top_n: int | None,
        retrieval_factor: int | None,
        max_iter: int | None,
        instructions: str,
        n_swarm_queries: int | None,
        embed_fn: Callable[[str], list[float]] | None,
        embedder_name: str | None,
        semantic_ratio: float | None,
        boost_fn: Callable[[dict], float] | None,
        sort_fields: list[str] | None,
        filter: str | None,  # noqa: A002
        rerank_chars: int | None,
        hyde_min_words: int | None,
        group_field: str,
        name_field: str,
        category_fields: list[str] | None,
        fusion: Literal["rrf", "dbsf"] | None,
        expert_top_n: int | None,
        expert_threshold: float | None,
        verbose: bool | None,
        checkpointer: Any,
        memory_store: Any,
        mem0_memory: Any,
        config: "RAGConfig | None",
        trace_callback: Callable[[dict[str, Any]], None] | None,
        # static helpers from AgenticRAG — passed in to avoid an import
        # cycle and to keep this module agent-class agnostic.
        resolve_llm: Callable[..., "BaseChatModel"],
        default_llm: Callable[[], "BaseChatModel"],
        default_gen_llm: Callable[[], "BaseChatModel"],
        default_reranker: Callable[[], "Reranker | CohereReranker | LLMReranker"],
        chain_llm: Callable[["BaseChatModel", str], "BaseChatModel"],
    ) -> "RAGContext":
        # --- backend / collections ------------------------------------
        coll_dict: dict[str, SearchBackend] | None
        coll_desc: dict[str, str]
        resolved_backend: SearchBackend
        if collections:
            coll_dict = dict(collections)
            coll_desc = dict(
                collection_descriptions or {name: name for name in collections}
            )
            resolved_backend = _MultiBackend(coll_dict)
        else:
            coll_dict = None
            coll_desc = {}
            resolved_backend = backend or InMemoryBackend()

        # --- embedder ------------------------------------------------
        explicit_embedder_name = embedder_name or os.getenv("RAG_EMBEDDER_NAME")
        if explicit_embedder_name:
            resolved_embedder_name = explicit_embedder_name
            _validate_embedder_name(resolved_backend, explicit_embedder_name)
        else:
            resolved_embedder_name = _detect_embedder_name(
                resolved_backend, fallback="default"
            )

        resolved_embed_fn = _align_embed_fn_with_backend(embed_fn, resolved_backend)
        resolved_category_fields = (
            list(category_fields)
            if category_fields is not None
            else _detect_category_fields(resolved_backend)
        )

        # --- index signals -------------------------------------------
        num_fields: list[str] = []
        primary_bool: str | None = None
        if sort_fields is None and boost_fn is None:
            strategy = (
                getattr(config, "boost_strategy", None) if config is not None else None
            ) or os.getenv("RAG_BOOST_STRATEGY", "log_scale")
            sort_fields, boost_fn, num_fields, primary_bool = _detect_index_signals(
                resolved_backend, strategy=strategy
            )
        resolved_sort_fields = list(sort_fields) if sort_fields is not None else []

        # --- LLM stack -----------------------------------------------
        resolved_gen_llm: "BaseChatModel"
        if gen_llm is not None:
            resolved_gen_llm = gen_llm
        elif config is not None and config.strong_model:
            resolved_gen_llm = resolve_llm(config.strong_model, timeout=60)
        else:
            resolved_gen_llm = default_gen_llm()

        resolved_llm: "BaseChatModel"
        if llm is not None:
            resolved_llm = llm
        elif config is not None and config.weak_model:
            resolved_llm = resolve_llm(config.weak_model, timeout=30)
        else:
            resolved_llm = default_llm()

        if config is not None and config.thinking_model:
            resolved_thinking = resolve_llm(config.thinking_model, timeout=60)
        else:
            resolved_thinking = resolved_llm

        if config is not None and config.grader_model:
            resolved_grader = resolve_llm(config.grader_model, timeout=60)
        else:
            resolved_grader = resolved_thinking

        resolved_reranker = reranker or default_reranker()

        # --- numeric / flag knobs ------------------------------------
        if config is not None:
            top_k_v = config.top_k
            retrieval_factor_v = config.retrieval_factor
            rerank_top_n_v = config.rerank_top_n
            rerank_cap_multiplier_v = config.rerank_cap_multiplier
            semantic_ratio_v = config.semantic_ratio
            fusion_v: Literal["rrf", "dbsf"] = config.fusion
            hyde_min_words_v = config.hyde_min_words or 999
            short_query_threshold_v = config.short_query_threshold
            short_query_sort_tokens_v = config.short_query_sort_tokens
            bm25_fallback_threshold_v = config.bm25_fallback_threshold
            bm25_fallback_semantic_ratio_v = config.bm25_fallback_semantic_ratio
            fast_accept_score_v = config.fast_accept_score
            fast_accept_confidence_v = config.fast_accept_confidence
            rerank_min_score_v = config.rerank_min_score
            filter_intent_words = frozenset(
                w
                for lang in config.query_languages
                for w in _FILTER_INTENT_WORDS_BY_LANG.get(lang, frozenset())
            )
            expert_top_n_v = config.expert_top_n
            expert_threshold_v = config.expert_threshold
            name_field_boost_max_v = config.name_field_boost_max
            enable_hyde_v = config.enable_hyde
            enable_filter_intent_v = config.enable_filter_intent
            enable_preprocess_llm_v = config.enable_preprocess_llm
            enable_final_grade_v = config.enable_final_grade
            final_grade_threshold_v = config.final_grade_threshold
            enable_swarm_grade_v = config.enable_swarm_grade
            enable_reranker_v = bool(getattr(config, "enable_reranker", False)) or (
                reranker is not None
            )
            enable_elbow_cutoff_v = bool(getattr(config, "enable_elbow_cutoff", False))
            reranker_trust_top_score_v = float(
                getattr(config, "reranker_trust_top_score", 0.8)
            )
            reranker_trust_score_gap_v = float(
                getattr(config, "reranker_trust_score_gap", 0.3)
            )
            n_synonym_variants_v = config.n_synonym_variants
            enable_close_match_grader_v = bool(config.enable_close_match_grader)
            close_match_strictness_v = config.close_match_strictness
            close_match_min_top_rerank_v = config.close_match_min_top_rerank
            rerank_timeout_s_v = config.rerank_timeout_s
            llm_timeout_s_v = config.llm_timeout_s
            max_iter_v = config.max_iter
            n_swarm_queries_v = config.n_swarm_queries
            rerank_chars_v = config.rerank_chars
            custom_instructions_v = config.custom_instructions or ""
            preview_chars_v = config.preview_chars
        else:
            top_k_v = top_k or int(os.getenv("RAG_TOP_K", "10"))
            rerank_top_n_v = rerank_top_n or int(os.getenv("RAG_RERANK_TOP_N", "5"))
            retrieval_factor_v = retrieval_factor or int(
                os.getenv("RAG_RETRIEVAL_FACTOR", "4")
            )
            max_iter_v = max_iter or int(os.getenv("RAG_MAX_ITER", "3"))
            n_swarm_queries_v = n_swarm_queries or int(
                os.getenv("RAG_N_SWARM_QUERIES", "4")
            )
            semantic_ratio_v = (
                semantic_ratio
                if semantic_ratio is not None
                else float(os.getenv("RAG_SEMANTIC_RATIO", "0.5"))
            )
            rerank_chars_v = (
                rerank_chars
                if rerank_chars is not None
                else int(os.getenv("RAG_RERANK_CHARS", "2048"))
            )
            hyde_min_words_v = (
                hyde_min_words
                if hyde_min_words is not None
                else int(os.getenv("RAG_HYDE_MIN_WORDS", "8"))
            )
            _fusion_raw = fusion or os.getenv("RAG_FUSION", "rrf")
            fusion_v = "dbsf" if _fusion_raw == "dbsf" else "rrf"
            rerank_cap_multiplier_v = float(
                os.getenv("RAG_RERANK_CAP_MULTIPLIER", "2.0")
            )
            short_query_threshold_v = int(os.getenv("RAG_SHORT_QUERY_THRESHOLD", "6"))
            short_query_sort_tokens_v = bool(
                int(os.getenv("RAG_SHORT_QUERY_SORT_TOKENS", "1"))
            )
            bm25_fallback_threshold_v = float(
                os.getenv("RAG_BM25_FALLBACK_THRESHOLD", "0.4")
            )
            bm25_fallback_semantic_ratio_v = float(
                os.getenv("RAG_BM25_FALLBACK_SEMANTIC_RATIO", "0.9")
            )
            fast_accept_score_v = 0.7
            fast_accept_confidence_v = 0.9
            _rms = os.getenv("RAG_RERANK_MIN_SCORE", "0.2")
            rerank_min_score_v = None if _rms.lower() == "none" else float(_rms)
            langs = [
                lang.strip()
                for lang in os.getenv("RAG_QUERY_LANGUAGES", "de,fr,it,en").split(",")
                if lang.strip()
            ]
            filter_intent_words = frozenset(
                w
                for lang in langs
                for w in _FILTER_INTENT_WORDS_BY_LANG.get(lang, frozenset())
            )
            enable_hyde_v = True
            enable_filter_intent_v = True
            enable_preprocess_llm_v = True
            enable_final_grade_v = False
            final_grade_threshold_v = 0.7
            enable_swarm_grade_v = False
            enable_reranker_v = bool(int(os.getenv("RAG_ENABLE_RERANKER", "0"))) or (
                reranker is not None
            )
            enable_elbow_cutoff_v = bool(int(os.getenv("RAG_ENABLE_ELBOW_CUTOFF", "0")))
            n_synonym_variants_v = int(os.getenv("RAG_N_SYNONYM_VARIANTS", "3"))
            enable_close_match_grader_v = bool(
                int(os.getenv("RAG_ENABLE_CLOSE_MATCH_GRADER", "1"))
            )
            close_match_strictness_v = os.getenv("RAG_CLOSE_MATCH_STRICTNESS", "loose")
            _cmr = os.getenv("RAG_CLOSE_MATCH_MIN_TOP_RERANK")
            close_match_min_top_rerank_v = float(_cmr) if _cmr else None
            reranker_trust_top_score_v = float(
                os.getenv("RAG_RERANKER_TRUST_TOP_SCORE", "0.8")
            )
            reranker_trust_score_gap_v = float(
                os.getenv("RAG_RERANKER_TRUST_SCORE_GAP", "0.3")
            )
            rerank_timeout_s_v = 30.0
            llm_timeout_s_v = 60.0
            name_field_boost_max_v = float(os.getenv("RAG_NAME_FIELD_BOOST_MAX", "0.1"))
            preview_chars_v = int(os.getenv("RAG_PREVIEW_CHARS", "1500"))
            expert_top_n_v = expert_top_n or int(os.getenv("RAG_EXPERT_TOP_N", "10"))
            expert_threshold_v = (
                expert_threshold
                if expert_threshold is not None
                else float(os.getenv("RAG_EXPERT_THRESHOLD", "0.15"))
            )
            custom_instructions_v = ""

        verbose_v = (
            verbose if verbose is not None else bool(int(os.getenv("RAG_VERBOSE", "0")))
        )

        # --- structured chains ---------------------------------------
        index_cfg = resolved_backend.get_index_config()
        _ck = chain_llm
        search_query_chain = _ck(resolved_llm, "rewrite").with_structured_output(
            SearchQuery, method="json_schema"
        )
        quality_chain = _ck(resolved_llm, "quality-gate").with_structured_output(
            QualityAssessment, method="json_schema"
        )
        multi_query_chain = _ck(resolved_llm, "multi-query").with_structured_output(
            MultiQuery, method="json_schema"
        )
        filter_intent_chain = _ck(resolved_llm, "filter-intent").with_structured_output(
            FilterIntent, method="json_schema"
        )
        select_collection_chain = _ck(
            resolved_llm, "select-collection"
        ).with_structured_output(CollectionIntent, method="json_schema")
        field_priority_chain = _ck(
            resolved_llm, "field-priority"
        ).with_structured_output(FieldPriority, method="json_schema")
        relevance_chain = _ck(resolved_llm, "relevance").with_structured_output(
            RelevanceCheck, method="json_schema"
        )
        grade_chain = _ck(resolved_grader, "grader").with_structured_output(
            AnswerGrade, method="json_schema"
        )
        product_code_chain = _ck(resolved_llm, "product-code").with_structured_output(
            ProductCodeQuery, method="json_schema"
        )
        close_match_chain = _ck(resolved_grader, "close-match").with_structured_output(
            CloseMatchKeep, method="json_schema"
        )
        close_match_chain_strong = _ck(
            resolved_thinking, "close-match-strong"
        ).with_structured_output(CloseMatchKeep, method="json_schema")
        synonym_chain = _ck(resolved_llm, "synonym").with_structured_output(
            SynonymResult, method="json_schema"
        )
        suggestion_chain = _ck(
            resolved_llm, "no-result-suggest"
        ).with_structured_output(NoResultSuggestion, method="json_schema")
        standalone_chain = _ck(resolved_llm, "contextualize").with_structured_output(
            StandaloneQuery, method="json_schema"
        )

        return cls(
            backend=resolved_backend,
            collections=coll_dict,
            collection_descriptions=coll_desc,
            top_k=top_k_v,
            rerank_top_n=rerank_top_n_v,
            retrieval_factor=retrieval_factor_v,
            min_rerank_pool=int(os.getenv("RAG_MIN_RERANK_POOL", "24")),
            memory_relevance_threshold=float(
                os.getenv("RAG_MEMORY_RELEVANCE_THRESHOLD", "0.7")
            ),
            memory_storage_threshold=float(
                os.getenv("RAG_MEMORY_STORAGE_THRESHOLD", "0.85")
            ),
            max_iter=max_iter_v,
            n_swarm_queries=n_swarm_queries_v,
            rerank_chars=rerank_chars_v,
            hyde_min_words=hyde_min_words_v,
            expert_top_n=expert_top_n_v,
            expert_threshold=expert_threshold_v,
            rerank_cap_multiplier=rerank_cap_multiplier_v,
            short_query_threshold=short_query_threshold_v,
            short_query_sort_tokens=short_query_sort_tokens_v,
            bm25_fallback_threshold=bm25_fallback_threshold_v,
            bm25_fallback_semantic_ratio=bm25_fallback_semantic_ratio_v,
            fast_accept_score=fast_accept_score_v,
            fast_accept_confidence=fast_accept_confidence_v,
            rerank_min_score=rerank_min_score_v,
            name_field_boost_max=name_field_boost_max_v,
            preview_chars=preview_chars_v,
            final_grade_threshold=final_grade_threshold_v,
            reranker_trust_top_score=reranker_trust_top_score_v,
            reranker_trust_score_gap=reranker_trust_score_gap_v,
            n_synonym_variants=n_synonym_variants_v,
            close_match_min_top_rerank=close_match_min_top_rerank_v,
            rerank_timeout_s=rerank_timeout_s_v,
            llm_timeout_s=llm_timeout_s_v,
            semantic_ratio=semantic_ratio_v,
            verbose=verbose_v,
            fusion=fusion_v,
            instructions=instructions,
            filter=filter,
            group_field=group_field,
            name_field=name_field,
            enable_hyde=enable_hyde_v,
            enable_filter_intent=enable_filter_intent_v,
            enable_preprocess_llm=enable_preprocess_llm_v,
            enable_final_grade=enable_final_grade_v,
            enable_swarm_grade=enable_swarm_grade_v,
            enable_reranker=enable_reranker_v,
            enable_elbow_cutoff=enable_elbow_cutoff_v,
            enable_close_match_grader=enable_close_match_grader_v,
            close_match_strictness=close_match_strictness_v,
            custom_instructions=custom_instructions_v,
            embedder_name=resolved_embedder_name,
            embed_fn=resolved_embed_fn,
            boost_fn=boost_fn,
            sort_fields=resolved_sort_fields,
            num_fields=num_fields,
            category_fields=resolved_category_fields,
            primary_preference_field=primary_bool,
            has_own_brand_field=_has_is_own_brand_field(resolved_backend),
            filter_intent_words=filter_intent_words,
            trace_callback=trace_callback,
            llm=resolved_llm,
            gen_llm=resolved_gen_llm,
            thinking_llm=resolved_thinking,
            grader_llm=resolved_grader,
            reranker=resolved_reranker,
            expert_reranker=expert_reranker,
            index_config=index_cfg,
            search_query_chain=search_query_chain,
            quality_chain=quality_chain,
            multi_query_chain=multi_query_chain,
            filter_intent_chain=filter_intent_chain,
            select_collection_chain=select_collection_chain,
            field_priority_chain=field_priority_chain,
            relevance_chain=relevance_chain,
            grade_chain=grade_chain,
            product_code_chain=product_code_chain,
            close_match_chain=close_match_chain,
            close_match_chain_strong=close_match_chain_strong,
            synonym_chain=synonym_chain,
            suggestion_chain=suggestion_chain,
            standalone_chain=standalone_chain,
            checkpointer=checkpointer,
            memory_store=memory_store,
            mem0_memory=mem0_memory,
        )
