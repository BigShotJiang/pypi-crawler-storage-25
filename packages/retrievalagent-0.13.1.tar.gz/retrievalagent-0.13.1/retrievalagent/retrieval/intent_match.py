"""Document-level checks against a FilterIntent.

Pure functions — no `self` state — so they live as module-level fns
rather than mixin methods. Used by retrieval, rerank, and the
`_reason_route` decision in the LangGraph state machine.
"""

from __future__ import annotations

import re as _re
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from langchain_core.documents import Document

    from ..models import FilterIntent


def _doc_matches_intent(doc: Document, intent: FilterIntent) -> bool:
    field, value, op = intent.field, intent.value, intent.operator
    if not field:
        return True
    actual = doc.metadata.get(field)
    if actual is None:
        return op in ("NOT_CONTAINS", "!=")
    actual_str = str(actual).lower()
    value_str = str(value).lower()
    if op == "=":
        return actual_str == value_str
    if op == "CONTAINS":
        return value_str in actual_str
    if op == "NOT_CONTAINS":
        all_values = [value_str] + [v.lower() for v in intent.extra_excludes]
        for val in all_values:
            if val in actual_str:
                return False
            spaced = _re.sub(r"(?<=[a-z])(?=[A-Z])", " ", val).lower()
            if spaced != val and spaced in actual_str:
                return False
            ws = val.split()
            if len(ws) >= 3 and " ".join(ws[:2]) in actual_str:
                return False
            sw = spaced.split()
            if len(sw) >= 3:
                sp2 = " ".join(sw[:2])
                if sp2 in actual_str:
                    return False
        return True
    if op == "!=":
        return actual_str != value_str
    return True


_NEGATION_PATTERNS = [
    # German: "aber nicht (von) X", "nicht von X", "ohne X", "ausser X", "außer X", "keine X"
    # "aber nicht" is a strong contrast cue — preposition is optional, so
    # "aber nicht ProOne" and "cola aber nicht zero" both match.
    _re.compile(
        r"\baber\s+nicht\s+(?:(?:von|der|aus|mit|von\s+der)\s+)?([^\s,.;:!?]+(?:\s+[A-Za-z0-9][^\s,.;:!?]*){0,2})",
        _re.IGNORECASE,
    ),
    _re.compile(
        r"\bnicht\s+(?:von|der|von der|aus|mit)\s+([^\s,.;:!?]+(?:\s+[A-Za-z0-9][^\s,.;:!?]*){0,2})",
        _re.IGNORECASE,
    ),
    _re.compile(
        r"\bohne\s+([^\s,.;:!?]+(?:\s+[A-Za-z0-9][^\s,.;:!?]*){0,2})", _re.IGNORECASE
    ),
    _re.compile(
        r"\b(?:auss?er|außer)\s+([^\s,.;:!?]+(?:\s+[A-Za-z0-9][^\s,.;:!?]*){0,2})",
        _re.IGNORECASE,
    ),
    _re.compile(
        r"\bkeine?\s+([^\s,.;:!?]+(?:\s+[A-Za-z0-9][^\s,.;:!?]*){0,2})", _re.IGNORECASE
    ),
    # English: "but not X", "not from X", "without X", "except X", "no X"
    _re.compile(
        r"\bbut\s+not\s+(?:from\s+)?([^\s,.;:!?]+(?:\s+[A-Za-z0-9][^\s,.;:!?]*){0,2})",
        _re.IGNORECASE,
    ),
    _re.compile(
        r"\bnot\s+from\s+([^\s,.;:!?]+(?:\s+[A-Za-z0-9][^\s,.;:!?]*){0,2})",
        _re.IGNORECASE,
    ),
    _re.compile(
        r"\bwithout\s+([^\s,.;:!?]+(?:\s+[A-Za-z0-9][^\s,.;:!?]*){0,2})", _re.IGNORECASE
    ),
    _re.compile(
        r"\bexcept\s+(?:for\s+)?([^\s,.;:!?]+(?:\s+[A-Za-z0-9][^\s,.;:!?]*){0,2})",
        _re.IGNORECASE,
    ),
    # French: "sans X", "pas de X", "mais pas X"
    _re.compile(
        r"\bsans\s+([^\s,.;:!?]+(?:\s+[A-Za-z0-9][^\s,.;:!?]*){0,2})", _re.IGNORECASE
    ),
    _re.compile(
        r"\bmais\s+pas\s+(?:de\s+)?([^\s,.;:!?]+(?:\s+[A-Za-z0-9][^\s,.;:!?]*){0,2})",
        _re.IGNORECASE,
    ),
    # Italian: "ma non X", "senza X"
    _re.compile(
        r"\bma\s+non\s+([^\s,.;:!?]+(?:\s+[A-Za-z0-9][^\s,.;:!?]*){0,2})",
        _re.IGNORECASE,
    ),
    _re.compile(
        r"\bsenza\s+([^\s,.;:!?]+(?:\s+[A-Za-z0-9][^\s,.;:!?]*){0,2})", _re.IGNORECASE
    ),
]

# Stopwords that show up after negation cues but aren't real exclusion targets.
_NEGATION_STOP = frozenset(
    {
        "der",
        "die",
        "das",
        "den",
        "dem",
        "des",
        "ein",
        "eine",
        "einem",
        "einen",
        "the",
        "a",
        "an",
        "of",
        "from",
        "this",
        "that",
        "these",
        "those",
        "le",
        "la",
        "les",
        "un",
        "une",
        "des",
        "du",
        "de",
        "il",
        "la",
        "lo",
        "i",
        "gli",
        "le",
        "un",
        "una",
    }
)


_NEGATION_HALT = frozenset(
    {
        "aber",
        "und",
        "oder",
        "but",
        "and",
        "or",
        "mais",
        "ou",
        "et",
        "ma",
        "o",
        "e",
    }
)


def extract_negation_terms(query: str) -> list[str]:
    """Deterministic regex negation extractor — fallback for the synonym LLM.

    Catches common negation cues across DE/EN/FR/IT and returns the
    excluded terms (1–3 words each, stopwords stripped). Designed to
    complement, not replace, the LLM extractor: merges with whatever
    the LLM emits.
    """
    if not query:
        return []
    raw: list[str] = []
    seen_lc: set[str] = set()
    for pat in _NEGATION_PATTERNS:
        for m in pat.finditer(query):
            term = (m.group(1) or "").strip(" ,.;:!?\"'()[]")
            if not term:
                continue
            # Strip leading articles ("von der ProOne" → "ProOne").
            tokens = term.split()
            while tokens and tokens[0].lower() in _NEGATION_STOP:
                tokens = tokens[1:]
            # Truncate at coordinating conjunctions ("proone aber nicht..." → "proone").
            for i, tok in enumerate(tokens):
                if tok.lower() in _NEGATION_HALT:
                    tokens = tokens[:i]
                    break
            if not tokens:
                continue
            term = " ".join(tokens)
            key = term.lower()
            if key in seen_lc:
                continue
            seen_lc.add(key)
            raw.append(term)
    # Drop entries whose lowercased form has another extracted term as
    # a whole-word prefix — the shorter form is the conservative target.
    raw_sorted = sorted(raw, key=len)
    out: list[str] = []
    for term in raw_sorted:
        tl = term.lower()
        if any(
            tl != prev.lower() and tl.startswith(prev.lower() + " ") for prev in out
        ):
            continue
        out.append(term)
    return out


def _content_contains_exclusion(text: str, value: str) -> bool:
    low = text.lower()
    val = value.lower()
    if val in low:
        return True
    spaced = _re.sub(r"(?<=[a-z])(?=[A-Z])", " ", value).lower()
    if spaced != val and spaced in low:
        return True
    words = val.split()
    if len(words) >= 3:
        prefix2 = " ".join(words[:2])
        if prefix2 in low:
            return True
        spaced_words = spaced.split()
        if len(spaced_words) >= 3:
            sp2 = " ".join(spaced_words[:2])
            if sp2 != prefix2 and sp2 in low:
                return True
    return False


def _apply_intent_post_filter(
    docs: list[Document], intent: FilterIntent | None
) -> list[Document]:
    if not intent or not docs:
        return docs
    primary_negates = (
        not intent.field and intent.operator in ("NOT_CONTAINS", "!=") and intent.value
    )
    if primary_negates:
        exclude_vals = [str(intent.value)] + list(intent.extra_excludes)
        docs = [
            d
            for d in docs
            if not any(
                _content_contains_exclusion(d.page_content, v) for v in exclude_vals
            )
        ]
    for af in intent.and_filters:
        if af.operator in ("NOT_CONTAINS", "!=") and af.value:
            af_vals = [str(af.value)] + list(af.extra_excludes)
            docs = [
                d
                for d in docs
                if not any(
                    _content_contains_exclusion(d.page_content, v) for v in af_vals
                )
            ]
    return docs
