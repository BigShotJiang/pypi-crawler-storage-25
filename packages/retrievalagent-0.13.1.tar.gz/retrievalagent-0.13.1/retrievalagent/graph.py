"""LangGraph topology for AgenticRAG — lean parallel pipeline.

Nodes: [read_memory →] prepare → [keyword_search ∥ synonym_search] → evaluate
       → quality_gate → [semantic_backup →] merge_rerank → generate
       → [final_grade →] [write_memory →] END | rewrite → …

Memory nodes only wired when rag._memories is set.
Tier-0 (ID fast-track) detected in prepare; skips fanout → generate directly.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Literal

from langgraph.graph import END, START, StateGraph

from .models import RAGState

if TYPE_CHECKING:
    from .core import AgenticRAG


def _decide_after_generate(state: RAGState) -> Literal["grade", "end"]:
    """Skip final_grade for Tier-0/1 retrievals (already high-confidence)."""
    return "end" if state.tier in (0, 1) else "grade"


def _route_after_prepare(state: RAGState):
    """If docs already set (Tier-0 / pre-injected), skip fanout → generate."""
    if state.documents:
        return "generate"
    return ["keyword_search", "synonym_search"]


def _route_after_rewrite(state: RAGState):
    """After rewrite: if _arewrite populated docs (swarm shortcut), go to
    generate; otherwise fan out to the parallel search again."""
    if state.documents:
        return "generate"
    return ["keyword_search", "synonym_search"]


def build_graph(rag: "AgenticRAG") -> Any:
    store = rag._memory_store
    use_memory = bool(rag._memories)
    g = StateGraph(RAGState)

    # --- nodes ---
    g.add_node("prepare", rag._aprepare_node)
    g.add_node("keyword_search", rag._akeyword_search_node)
    g.add_node("synonym_search", rag._asynonym_search_node)
    g.add_node("evaluate", lambda state: {})  # fan-in sync point  # noqa: ARG005
    g.add_node("semantic_backup", rag._asemantic_backup_node)
    g.add_node("merge_rerank", rag._amerge_rerank_node)
    g.add_node("precision_filter", rag._aprecision_filter_node)
    g.add_node("generate", rag._agenerate)
    g.add_node("final_grade", rag._afinal_grade)
    g.add_node("rewrite", rag._arewrite)
    g.add_node("give_up", rag._agive_up)

    if use_memory:
        g.add_node("read_memory", rag._aread_memory)
        g.add_node("write_memory", rag._awrite_memory)

    # --- entry ---
    if use_memory:
        g.add_edge(START, "read_memory")
        g.add_edge("read_memory", "prepare")
    else:
        g.add_edge(START, "prepare")

    # --- after prepare: Tier-0 / injected → generate; else → parallel fanout ---
    g.add_conditional_edges(
        "prepare",
        _route_after_prepare,
        {
            "generate": "generate",
            "keyword_search": "keyword_search",
            "synonym_search": "synonym_search",
        },
    )

    # --- parallel fan-in: both branches → evaluate ---
    g.add_edge("keyword_search", "evaluate")
    g.add_edge("synonym_search", "evaluate")

    # --- quality gate: high score → skip semantic; low → run semantic backup ---
    g.add_conditional_edges(
        "evaluate",
        rag._quality_gate,
        {"semantic_backup": "semantic_backup", "merge_rerank": "merge_rerank"},
    )
    g.add_edge("semantic_backup", "merge_rerank")

    # --- precision filter: result-aware second-pass filter detection ---
    g.add_edge("merge_rerank", "precision_filter")

    # --- after precision_filter: route on docs + iterations ---
    g.add_conditional_edges(
        "precision_filter",
        rag._route,
        {"generate": "generate", "rewrite": "rewrite", "give_up": "give_up"},
    )

    # --- generate → grade decision ---
    if use_memory:
        g.add_conditional_edges(
            "generate",
            _decide_after_generate,
            {"grade": "final_grade", "end": "write_memory"},
        )
        g.add_conditional_edges(
            "final_grade",
            rag._grade_route,
            {"end": "write_memory", "rewrite": "rewrite"},
        )
        g.add_edge("write_memory", END)
        g.add_edge("give_up", "write_memory")
    else:
        g.add_conditional_edges(
            "generate",
            _decide_after_generate,
            {"grade": "final_grade", "end": END},
        )
        g.add_conditional_edges(
            "final_grade",
            rag._grade_route,
            {"end": END, "rewrite": "rewrite"},
        )
        g.add_edge("give_up", END)

    # --- retry: rewrite → parallel fanout (same nodes, new query) ---
    g.add_conditional_edges(
        "rewrite",
        _route_after_rewrite,
        {
            "generate": "generate",
            "keyword_search": "keyword_search",
            "synonym_search": "synonym_search",
        },
    )

    compiled = g.compile(
        checkpointer=rag._checkpointer,
        store=store if store is not None else None,
    )
    compiled.step_timeout = 120.0 if rag._expert_reranker else 30.0
    return compiled
