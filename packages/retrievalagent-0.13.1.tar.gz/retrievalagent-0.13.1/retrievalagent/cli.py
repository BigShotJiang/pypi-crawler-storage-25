"""Thin entry point — argparse + env detection → Textual app or plain CLI."""

from __future__ import annotations

import argparse
import asyncio
import json
import os
import sys
import warnings
from pathlib import Path
from typing import Any

warnings.filterwarnings(
    "ignore",
    message=r".*Pydantic V1 functionality.*",
    category=UserWarning,
)
warnings.filterwarnings("ignore", category=DeprecationWarning, module="pydantic")

try:
    from dotenv import load_dotenv

    load_dotenv()
except ModuleNotFoundError:
    pass


from . import AgenticRAG  # noqa: E402


def _load_documents_from_path(rag: AgenticRAG, path: str) -> int:
    """Load JSON-array docs into a memory-backend rag. Returns count loaded."""
    p = Path(path).expanduser()
    if not p.is_file():
        raise FileNotFoundError(p)
    data = json.loads(p.read_text())
    if not isinstance(data, list):
        raise ValueError("Expected a JSON array of objects")
    rag.backend.add_documents(data)  # ty: ignore[unresolved-attribute]
    return len(data)


def _build_rag(args: argparse.Namespace, defaults: dict[str, str]) -> AgenticRAG:
    from .factory import init_agent

    cfg: dict[str, Any] = {"index": defaults.get("index", "documents")}
    if defaults.get("backend"):
        cfg["backend"] = defaults["backend"]
    if defaults.get("backend_url"):
        cfg["backend_url"] = defaults["backend_url"]
    if defaults.get("backend_key"):
        cfg["backend_kwargs"] = {"api_key": defaults["backend_key"]}
    if defaults.get("llm"):
        cfg["model"] = defaults["llm"]
    if defaults.get("reranker") and defaults["reranker"] != "none":
        cfg["reranker"] = defaults["reranker"]
    if args.memory:
        cfg["memory"] = True
    try:
        rag = init_agent(**cfg)
    except Exception as exc:
        print(f"Failed to initialise: {exc}", file=sys.stderr)
        sys.exit(1)
    if args.top_k is not None:
        rag.top_k = int(args.top_k)
    if args.load and defaults.get("backend") == "memory":
        try:
            n = _load_documents_from_path(rag, args.load)
            print(f"Loaded {n} documents from {args.load}", file=sys.stderr)
        except Exception as exc:
            print(f"Load failed: {exc}", file=sys.stderr)
    return rag


def _run_retrieve(rag: AgenticRAG, question: str, top_k: int) -> None:
    _, docs = rag.retrieve_documents(question, top_k=top_k)
    for i, d in enumerate(docs, 1):
        m = d.metadata
        _id = m.get("id") or m.get("article_id") or "?"
        _name = (
            m.get("name")
            or m.get("article_name")
            or m.get("title")
            or d.page_content[:120]
        )
        print(f"{i}. {_id}  {_name}")


def _run_query(rag: AgenticRAG, question: str, request_config: Any) -> None:
    async def _go() -> None:
        state = await rag.ainvoke(question, config=request_config)
        print(state.answer or "(no answer)")

    asyncio.run(_go())


def _run_plain(rag: AgenticRAG, request_config: Any) -> None:
    try:
        import readline  # noqa: F401 — enables arrow keys + history on supported platforms
    except ImportError:
        pass

    async def _go() -> None:
        print("retrievalagent — plain mode  (Ctrl+D or 'quit' to exit)\n")
        while True:
            try:
                question = input("> ").strip()
            except (EOFError, KeyboardInterrupt):
                print()
                break
            if not question:
                continue
            if question.lower() in ("quit", "exit", "q"):
                break
            state = await rag.ainvoke(question, config=request_config)
            print(f"\n{state.answer or '(no answer)'}\n")

    asyncio.run(_go())


def main() -> None:
    parser = argparse.ArgumentParser(description="retrievalagent — Agentic RAG")
    parser.add_argument(
        "--collection", "-c", default=None, help="Index/collection name"
    )
    parser.add_argument("--top-k", "-k", type=int, default=None, help="Max documents")
    parser.add_argument(
        "--skip-wizard",
        action="store_true",
        help="Skip the setup screen — build agent from env, jump to chat.",
    )
    parser.add_argument(
        "--verbose",
        "-v",
        action="store_true",
        help="Stream the agent's reasoning trace (sets RAG_VERBOSE=1).",
    )
    parser.add_argument(
        "--memory",
        action="store_true",
        help="Enable long-term memory via mem0 (pip install retrievalagent[memory]).",
    )
    parser.add_argument(
        "--user-id",
        default=None,
        help="User identifier for the memory store (default: 'default').",
    )
    parser.add_argument(
        "--load",
        default=None,
        help="Load JSON docs into the memory backend at startup (path to JSON array).",
    )
    parser.add_argument(
        "--query",
        "-q",
        default=None,
        metavar="TEXT",
        help="Run a single query and print the answer to stdout (no TUI).",
    )
    parser.add_argument(
        "--retrieve",
        "-r",
        default=None,
        metavar="TEXT",
        help="Retrieve top-k documents and print id + name (no LLM generation).",
    )
    parser.add_argument(
        "--plain",
        action="store_true",
        help="Plain text REPL — no Textual TUI. Reads from stdin, prints to stdout.",
    )
    args = parser.parse_args()
    if args.verbose:
        os.environ["RAG_VERBOSE"] = "1"

    from . import app as _app

    defaults = _app.env_defaults()
    if args.collection:
        defaults["index"] = args.collection.split(",")[0].strip()

    user_id = args.user_id or os.getenv("RAG_USER_ID") or "default"
    request_config: dict[str, Any] | None = (
        {"configurable": {"user_id": user_id}} if args.memory else None
    )

    # ── Non-TUI modes: build agent from env, skip Textual entirely ────────────
    if args.query or args.retrieve or args.plain:
        if not _app.env_sufficient(defaults):
            print(
                "Error: environment not configured. Set RAG_BACKEND, RAG_URL, RAG_LLM "
                "(or equivalent) before using --query / --plain.",
                file=sys.stderr,
            )
            sys.exit(1)
        rag = _build_rag(args, defaults)
        if args.retrieve:
            _run_retrieve(rag, args.retrieve, args.top_k or 5)
        elif args.query:
            _run_query(rag, args.query, request_config)
        else:
            _run_plain(rag, request_config)
        return

    # ── TUI mode ──────────────────────────────────────────────────────────────
    rag_tui: AgenticRAG | None = None
    if args.skip_wizard and _app.env_sufficient(defaults):
        rag_tui = _build_rag(args, defaults)

    on_reload: Any = None
    if rag_tui is not None and defaults.get("backend") == "memory" and args.load:
        on_reload = lambda: _load_documents_from_path(rag_tui, args.load)  # noqa: E731

    _app.run_app(
        rag=rag_tui,
        request_config=request_config,
        on_reload=on_reload,
        defaults=defaults,
    )


if __name__ == "__main__":
    main()
