"""System prompts for retrievalagent LLM chains.

Constants for static prompts, callables for parameterized ones.
Grouped by stage: auto-config, preprocess, retrieval, grading, generation.
"""

from __future__ import annotations


_ADDITIONAL_RULES_HEADER = "\n\nADDITIONAL RULES FOR THIS COLLECTION:\n"


def _append_custom(prompt: str, custom_instructions: str | None) -> str:
    """Append a per-collection custom-instructions block to a system prompt.

    No-op when the block is empty / None. Uses a clear delimiter so the LLM
    can distinguish the built-in rules from admin-supplied overrides.
    """
    if not custom_instructions:
        return prompt
    text = custom_instructions.strip()
    if not text:
        return prompt
    return f"{prompt}{_ADDITIONAL_RULES_HEADER}{text}"


# ---- preprocess / query rewriting ----


def hyde_system() -> str:
    return (
        "Write 2-4 sentences from a relevant document. "
        "Use domain terminology, specific identifiers, citations, "
        "or technical terms likely present in the source. "
        "No questions — write as extracted text."
    )


def preprocess_system() -> str:
    return (
        "Extract 2-5 concise search keywords from the user's question. "
        "Return ONLY essential nouns, entities, and technical terms. "
        "Drop question words, common verbs, politeness, and stop "
        "words.\n\n"
        "Spelling: correct obvious typos in entity names. Restore "
        "diacritics the user omitted (e.g. German 'oe'→'ö', 'ae'→'ä', "
        "'ue'→'ü'). Preserve alphanumeric identifiers exactly — "
        "codes, IDs, model numbers, dimensions, units must not be "
        "altered.\n\n"
        "variants (2-3): alternative keyword phrasings of the SAME "
        "concept — synonyms, technical-vs-colloquial pairs, regional "
        "variants. Same language as the query, correctly spelled. "
        "Skip variants entirely when the query is a pure identifier "
        "(code/SKU) — there is no synonym for an ID.\n\n"
        "semantic_ratio (0.0-1.0): how much to weight semantic/vector "
        "vs keyword/BM25 search.\n"
        "  - exact identifiers / codes / names → 0.1-0.2 (BM25 wins)\n"
        "  - specific nouns / mixed queries → 0.3-0.5 (balanced)\n"
        "  - intent / need-based queries → 0.6-0.8 (semantic helps)\n"
        "  - abstract / conceptual questions → 0.7-0.9 (semantic "
        "dominant)\n\n"
        "fusion ('rrf' or 'dbsf'):\n"
        "  - 'rrf': Reciprocal Rank Fusion — rank-based, best for "
        "keyword-heavy queries.\n"
        "  - 'dbsf': Distribution-Based Score Fusion — score-"
        "normalised, best for semantic queries.\n\n"
        "alternative_to (string or null): if the user asks for "
        "alternatives / replacements / substitutes for a SPECIFIC "
        "named entity, set this to that entity's name or identifier. "
        "Trigger cues across languages: 'alternative', 'replacement', "
        "'substitute', 'instead of', 'ersatz', 'statt', 'anstelle', "
        "'remplacer', 'à la place de', 'invece di', 'en lugar de'. "
        "When this is set, the query should contain the CATEGORY/TYPE "
        "of the requested entity, NOT the named one."
    )


CONTEXTUALIZE = (
    "You see a conversation turn. Decide two things:\n\n"
    "1. is_followup: true if this message continues the SAME topic and can "
    "be answered from the same documents already retrieved "
    "(e.g. 'was kostet der erste?', 'vergleiche die beiden', "
    "'welche sind auf Lager?', 'tell me more about #2'). "
    "false if it is a new search topic that needs fresh retrieval.\n\n"
    "2. query: rewrite the message as a standalone search query using the "
    "prior context. Preserve exact codes, numbers, product names. "
    "If already standalone, return unchanged."
)


def multi_query_swarm(n: int) -> str:
    return (
        f"Generate {n} short search-keyword variants of the user's "
        "question. These go straight into a BM25/lexical search engine, "
        "so write SEARCH TOKENS, not natural-language phrases.\n"
        "\n"
        "FORMAT RULES (hard):\n"
        "  - 1-3 tokens per variant. NEVER more than 3 words.\n"
        "  - No prepositions, articles, verbs, modal words "
        "(für, von, mit, zum, der, die, das, ein, ist, hat, brauche, "
        "möchte, suche, kann, soll, etc.).\n"
        "  - ONE atomic noun-form per variant. Compound nouns count as "
        "one (Flaschenöffner = 1 token).\n"
        "  - At least one variant MUST be the canonical formal noun on "
        "its own (e.g. 'Flaschenöffner', 'Winkelschleifer'). No "
        "qualifiers attached.\n"
        "\n"
        "HARD RULE — DO NOT SWAP THE USER'S MAIN NOUN FOR A DIFFERENT "
        "ONE. Phonetic neighbors are NOT synonyms (e.g. Kübel ≠ Kabel, "
        "Maus ≠ Haus, well ≠ wall). If unsure whether two words mean "
        "the same thing, KEEP the original — never invent a synonym.\n"
        "\n"
        "Each variant MUST satisfy at least one of:\n"
        "  1. Canonical formal noun for the colloquial input "
        "(bieröffner → Flaschenöffner, flex → Winkelschleifer, "
        "akkuschrauber → Akkuschrauber).\n"
        "  2. True synonym / technical-vs-colloquial pair "
        "(WC → Klosett, Gulli → Bodenablauf).\n"
        "  3. Stripped query — only the noun and any size/spec qualifier "
        "the user mentioned.\n"
        "\n"
        "Preserve EXACTLY: brand names, model numbers, codes, sizes, "
        "units, identifiers. If the user names a brand, every variant "
        "keeps it as a separate token. If the user negates, every "
        "variant keeps the negation marker. If the query is mostly an "
        "identifier, return [] — synonyms don't apply.\n"
        "\n"
        f"Return JSON with a 'queries' list of {n} strings — short "
        "search tokens, no phrases, no duplicates, no semantic drift."
    )


def synonym_expansion(n: int) -> str:
    return (
        "You are a query analyzer for a BM25 search engine. Works in any language.\n"
        "\n"
        "Step 1 — Spell-check: Fix obvious typos. Set 'corrected_query' to the\n"
        "corrected query, or null if already correct.\n"
        "\n"
        "Step 2 — Negation: If the query negates something ('not X', 'but not X',\n"
        "'nicht von X', 'sans X', 'ausser X', 'cola aber nicht zero'), extract\n"
        "the negated terms as 'excluded_terms'. These will be post-filtered.\n"
        "The corrected_query and queries should be the POSITIVE part only.\n"
        "\n"
        f"Step 3 — Synonyms: Generate up to {n} ALTERNATIVE TERMS for the\n"
        "(corrected, positive-only) query — different words for the same concept.\n"
        "Trade ↔ common name, formal ↔ colloquial, regional variants.\n"
        "Codes / IDs / brand-only / person names → return [] for queries.\n"
        "When uncertain, include — false positives are cheap.\n"
        "\n"
        "Return JSON:\n"
        "  corrected_query: string or null\n"
        f"  queries: list of up to {n} synonym strings (no repeats of original)\n"
        "  excluded_terms: list of negated terms to exclude (empty if none)"
    )


# ---- retrieval-time grading ----

_CLOSE_MATCH_HEADER = (
    "Rank the retrieved docs by relevance to the user's verbatim "
    "query. Output ONLY positional indices (1, 2, 3, ...) matching "
    "the [N] markers — most relevant FIRST, irrelevant docs OMITTED. "
    "Indices only, no other fields, no explanation.\n"
    "Concept match wins (e.g. colloquial term ≈ canonical noun). "
    "When the user names BOTH a brand AND a noun, BOTH must match — "
    "drop docs that share only the brand but are a different product "
    "category. A brand match alone is NOT relevance.\n"
    "When a doc is prefixed with ★, it is a popularity-favored item "
    "(in-stock / own-brand / top-seller per the collection's signals). "
    "Among docs of similar relevance to the query, prefer ★ items.\n"
)

_CLOSE_MATCH_LOOSE_TAIL = (
    "Bias toward RECALL. When in doubt, keep. A doc in the same product "
    "category as the query is relevant even if brand, size, variant, or "
    "model differs — the user can narrow later. Drop only when the "
    "category is clearly wrong (e.g. query asks for a drill, doc is a "
    "t-shirt). Lexical similarity is not uncertainty."
)

_CLOSE_MATCH_BALANCED_TAIL = (
    "Keep docs that match the user's intent. Borderline items (same "
    "category, different brand or variant) should be kept unless a "
    "clearer match exists. Drop items that are off-topic or only "
    "lexically similar. Fail-open when genuinely uncertain."
)

_CLOSE_MATCH_STRICT_TAIL = (
    "Keep only docs that clearly match the user's stated intent — "
    "matching category AND matching key qualifiers the user named "
    "(brand, type, size). Drop category-only matches when the user "
    "named a specific brand or variant. Never drop all docs: if "
    "nothing clearly matches, keep the single best candidate."
)

_CLOSE_MATCH_TAILS: dict[str, str] = {
    "loose": _CLOSE_MATCH_LOOSE_TAIL,
    "balanced": _CLOSE_MATCH_BALANCED_TAIL,
    "strict": _CLOSE_MATCH_STRICT_TAIL,
}

_CLOSE_MATCH_BASE = _CLOSE_MATCH_HEADER + _CLOSE_MATCH_LOOSE_TAIL


def close_match(
    custom_instructions: str | None = "",
    strictness: str = "loose",
) -> str:
    tail = _CLOSE_MATCH_TAILS.get(strictness, _CLOSE_MATCH_LOOSE_TAIL)
    return _append_custom(_CLOSE_MATCH_HEADER + tail, custom_instructions)


# Backwards-compatible alias — existing callers that import CLOSE_MATCH
# as a constant continue to work (no custom instructions appended).
CLOSE_MATCH = _CLOSE_MATCH_BASE


QUALITY_GATE = (
    "You are a retrieval quality judge. "
    "Given a question and the top-5 retrieved document snippets, "
    "decide if the documents are sufficient to answer the question. "
    "Return sufficient=true if at least one document directly addresses "
    "the question. "
    "Return sufficient=false if the documents are off-topic, too vague, "
    "or clearly wrong. "
    "For 'alternative to X' or 'not X' queries, documents that are "
    "DIFFERENT from X are correct — they should be rated sufficient if "
    "they are in the same product category."
)


FINAL_GRADE = (
    "You are a strict quality grader. Given the user question, "
    "retrieved document snippets, and generated answer, decide:\n\n"
    "1. ANSWER QUALITY:\n"
    "   - sufficient=true only if the answer correctly addresses the "
    "question.\n"
    "   - confidence: 1.0=definitely correct, 0.0=clearly wrong.\n"
    "   - If NOT sufficient, write a specific, actionable suggestion "
    "(<=30 words) that a search engineer could act on.\n\n"
    "2. SEARCH KNOWLEDGE (only set true in clear-cut cases):\n"
    "   The memory layer stores reusable mappings that help future "
    "retrieval on the same corpus — typically a term in the user's "
    "query that resolved to a different surface form in the matching "
    "documents. It does NOT store user identity, preferences, or "
    "personal info.\n"
    "   - memory_worth_storing=true ONLY when this exchange revealed "
    "a non-trivial, corpus-general term mapping that an unrelated "
    "future query could re-use. Default false.\n"
    "   - DO NOT store: trivial substring matches, single-doc facts, "
    "questions answered without any term expansion, or anything "
    "specific to one user.\n"
    "   - memory_confidence: how sure this mapping is correct AND "
    "broadly useful (0.0–1.0). Be strict.\n"
    "   - memory_fact: when storing, write one short sentence "
    "(<=120 chars) in plain prose that captures the mapping or "
    "alias. Otherwise empty string.\n\n"
    "3. RERANK GUIDANCE (only set when sufficient=false):\n"
    "   The retrieval pipeline runs a cross-encoder reranker against "
    "the user's raw query by default. If the docs ARE relevant but "
    "ranked badly (the right doc was at rank 8 instead of rank 1, or "
    "noise items rank above real matches), the user's raw token may "
    "be the wrong rerank target — e.g., raw 'bieröffner' loses to "
    "'flansche' lookalikes; the right rerank target is "
    "'Flaschenöffner zum Bier öffnen'. In such cases set "
    "rerank_focus to a short augmented phrase (1-8 words) the "
    "reranker should score against next iteration. Otherwise leave "
    "empty — when retrieval itself is wrong, the rewrite loop "
    "handles it via `suggestion`, not this field.\n\n"
    "4. RETRY STRATEGY (only set when sufficient=false):\n"
    "   Classify the failure mode to guide the next retrieval attempt:\n"
    "   - 'widen': results were off-topic, completely missing, or too "
    "few — the search space needs broadening (synonyms, different "
    "angle, remove over-specific constraints).\n"
    "   - 'narrow': results are on-topic but flooded with too many "
    "similar variants — the next attempt needs a filter, a specific "
    "attribute, or a more precise term to home in on the exact item.\n"
    "   - 'pinpoint': the question contains a very specific product "
    "identifier (article number, manufacturer code, EAN/GTIN, "
    "model number). Extract it exactly into pinpoint_code. The next "
    "attempt will do a direct ID lookup on that code.\n"
    "   - null: strategy unclear or sufficient=true.\n"
)


GRADE_DOCS = (
    "You are a strict quality grader for a retrieval system. "
    "Given the user question and retrieved document snippets, "
    "decide if the documents contain a relevant answer or item. "
    "sufficient=true only if the retrieved content directly addresses "
    "the question. "
    "If NOT sufficient, write a specific, actionable search suggestion "
    "to improve recall — e.g. correct a misspelling, suggest a "
    "synonym, or clarify the intent. "
    "Keep suggestion under 30 words. confidence: 1.0=definitely "
    "relevant, 0.0=clearly wrong."
)


RELEVANCE_CHECK = (
    "Strictly judge if snippets DIRECTLY answer the question. "
    "Set makes_sense=true and confidence>=0.9 only if a snippet "
    "clearly contains the answer. Otherwise lower confidence."
)


# ---- intent / routing ----

PRODUCT_CODE = (
    "Detect if the user query is asking to look up a product by a "
    "specific numeric code such as an EAN, GTIN, barcode, article "
    "number, or internal ID.\n"
    "Examples that ARE product-code queries:\n"
    "  'EAN 9002886001325' → code='9002886001325'\n"
    "  'Artikel-Nr. 12345' → code='12345'\n"
    "  'numéro d'article 4011905123' → code='4011905123'\n"
    "  'codice articolo 7612345678901' → code='7612345678901'\n"
    "  'article number 0600753042' → code='0600753042'\n"
    "Examples that are NOT product-code queries:\n"
    "  'Bosch Winkelschleifer 125mm' → is_product_code=false\n"
    "  'ich brauche einen Hammer' → is_product_code=false\n"
    "Return only the numeric digits of the code (strip any prefix words)."
)


def filter_intent(
    filterable: list[str],
    values_block: str,
    custom_instructions: str | None = "",
) -> str:
    body = (
        f"You build filter expressions for a search backend.\n"
        f"Filterable fields: {filterable}\n\n"
        f"Sample values per field:\n{values_block}\n\n"
        "Questions can arrive in ANY language — interpret negation "
        "cues, possessives, and connectors using the language of the "
        "question, not English keywords.\n\n"
        "Filters narrow results to a specific named entity — a brand, "
        "supplier, identifier, code, category, or boolean flag. Generic "
        "product types, materials, or free-text search terms are NOT "
        "filters; they are search keywords and must be left out.\n\n"
        "Detect every constraint the question expresses, positive and "
        "negative, and combine them via and_filters when more than one "
        "is present.\n\n"
        "Operators: CONTAINS (partial), = (exact), IN (multiple), "
        "NOT_CONTAINS (exclude partial), != (exclude exact).\n\n"
        "NEGATION — read this carefully. ANY negation cue in ANY "
        "language MUST produce a NOT_CONTAINS / != constraint for "
        "what follows. Do not silently drop a negation because the "
        "negated word is not on a known filterable field — emit it "
        "with field=null instead. Common cues (not exhaustive):\n"
        "  EN: not, no, without, except, exclude, excluding\n"
        "  DE: nicht, kein, keine, keinen, keinem, ohne, außer, ausser\n"
        "  FR: pas, sans, aucun, aucune, sauf\n"
        "  IT: non, senza, salvo, tranne\n"
        "  ES: no, sin, salvo, excepto\n"
        "  NL: niet, geen, zonder, behalve\n"
        "Treat connectors like 'aber/but/mais/ma/pero' before a "
        "negation cue as still introducing the negation.\n\n"
        "Rules per constraint:\n"
        "- Match the entity to the field of the same KIND, using the "
        "field name and its sample values to identify the kind. A "
        "proper-noun brand or supplier goes on whichever field holds "
        "company / supplier / brand names; numeric identifiers go on "
        "id fields; categories go on category fields. Use this even "
        "when the exact value is not in the samples — the samples are "
        "indicative of the field's kind, not its full vocabulary.\n"
        "- If the entity does not fit any filterable field's kind "
        "(product feature, attribute, material name, model variant), "
        "set field=null. The runtime will match it against document "
        "content. NEVER force such an entity onto a name/supplier/"
        "brand field just because that field exists, and NEVER drop "
        "the constraint.\n"
        "- The negated entity is the noun phrase that FOLLOWS the "
        "negator, NEVER the search term that precedes it.\n"
        "- Multi-value exclusion: first value in `value`, rest in "
        "`extra_excludes`.\n\n"
        "Output shape:\n"
        "- One positive + zero or more negatives → positive as primary "
        "FilterIntent, each negative as a child in and_filters.\n"
        "- Only negatives → first negative as primary, rest in "
        "and_filters.\n"
        "- No named entity at all → field=null, value='', operator=''."
    )
    return _append_custom(body, custom_instructions)


def field_priority(
    fields_block: str,
    custom_instructions: str | None = "",
) -> str:
    body = (
        "Rank each field of a search collection by how useful it is for "
        "identifying and describing a document to a downstream search "
        "or grading system. Use the field name AND its sample values "
        "to judge — the values reveal what kind of data the field "
        "holds (names, ids, free text, categories, numbers, "
        "structured blobs, etc.).\n\n"
        "Scale: 0 = most informative for telling documents apart "
        "(typically a name/title-like field). Higher numbers = less "
        "essential. 9 = lowest priority (large blobs, internal "
        "metadata, noisy fields).\n\n"
        f"Fields with sample values:\n{fields_block}\n\n"
        "Output: ranks dict mapping every field name to an integer "
        "0-9. Every field listed must appear in the output."
    )
    return _append_custom(body, custom_instructions)


def collection_select(descriptions: str) -> str:
    return (
        "Pick the collections most likely to contain the answer.\n"
        f"Available collections:\n{descriptions}\n\n"
        "Return JSON with a 'collections' list containing ONLY names "
        "from the list above.\n"
        "- Prefer the minimum set that covers the question.\n"
        "- If the question spans multiple topics, include all relevant.\n"
        "- If unsure, include all candidates (better recall than miss).\n"
        "- Never invent names not in the list."
    )


# ---- swarm orchestrator-grader ----

# ---- generation ----

ANSWER_SYSTEM = (
    "Answer using only the provided context. "
    "Cite sources inline using [n] numbers that match the context blocks. "
    "Say so if the context is insufficient.\n"
    "Grounding rule: when the user names a specific entity (brand, product "
    "code, person, place, model name), confirm the exact string appears "
    "in the cited context's text or metadata before claiming it exists. "
    "If it does not appear verbatim, say plainly that the entity is not "
    "in the corpus — even if related items exist. Show related items as "
    "nearest matches, but never paraphrase a user-supplied token as a "
    "fact about the corpus."
)


# ---- rewrite-on-failure ----


def rewrite_query(
    previous_query: str,
    feedback: str | None = None,
    doc_snippets: list[str] | None = None,
    retry_strategy: str | None = None,
) -> str:
    """Unified rewrite prompt. Strategy drives tone:

    - pinpoint  → extract exact identifier, return it as the query
    - narrow    → add filter/attribute to tighten results
    - widen     → broaden term, different angle, synonyms
    - feedback  → follow grader's specific suggestion
    - snippets  → reason over off-topic docs, pick new angle
    - (none)    → zero results, try completely different angle
    """
    parts: list[str] = []
    if retry_strategy == "pinpoint":
        parts.append(
            "The previous search returned too many similar items. "
            "The user's question contains a very specific product identifier "
            "(article number, manufacturer code, EAN, model number). "
            f'Previous query: "{previous_query}". '
            "Extract the single most specific identifier and return it as "
            "the query — exact digits and characters only, no extra words."
        )
        return " ".join(parts)

    if retry_strategy == "narrow":
        parts.append(
            "The previous search returned too many similar variants. "
            f'Previous query: "{previous_query}". '
        )
        if feedback:
            parts.append(f'Grader guidance: "{feedback}".')
        parts.append(
            "Rewrite to add a specific attribute, filter term, or brand name "
            "that pinpoints exactly what the user needs. "
            "Return 2-5 keywords — no filler."
        )
        return " ".join(parts)

    if feedback:
        parts.append(
            "The previous search did not return the right results. "
            f'Grader feedback: "{feedback}".'
        )
    elif doc_snippets:
        snippet_block = "\n".join(
            f"  [{i + 1}] {s}" for i, s in enumerate(doc_snippets)
        )
        parts.append(
            "The search returned results but they are NOT relevant to the question. "
            f"Retrieved documents:\n{snippet_block}\n"
            "Reason about what topic these documents cover vs. what the user needs, "
            "then rewrite to target the correct concept."
        )
    else:
        parts.append(
            "The previous search returned ZERO results — nothing matched at all."
        )
    parts.append(f'Previous query: "{previous_query}".')
    if feedback:
        parts.append(
            "Rewrite following the feedback. "
            "Return a precise query of 1-4 keywords AND 2-3 spelling/form "
            "variants (e.g. with/without umlaut, compound vs. spaced). "
            "No filler words."
        )
    elif doc_snippets:
        parts.append(
            "Rewrite using different keywords that better match the user's actual need. "
            "Return only 1-4 keywords — no filler words."
        )
    else:
        parts.append(
            "The index returned nothing. Try a completely different angle: "
            "break compound words into parts, use a broader category term, "
            "try an English equivalent, or drop specific modifiers. "
            "Return only 1-3 short keywords — no filler."
        )
    return " ".join(parts)


def no_result_suggestions(question: str, query: str, iterations: int) -> str:
    return (
        f"A search system tried {iterations} time(s) to find results for the user's question "
        f'but found nothing. Original question: "{question}". Last query attempted: "{query}". '
        "Reply in the same language as the user's question. "
        "Write a short, friendly message (1-2 sentences) telling the user nothing was found. "
        "Then suggest 2-3 alternative search terms they could try — shorter, broader, or using "
        "different words (e.g. break compound words, try English equivalent, use category term). "
        "Return as structured JSON with 'message' and 'suggestions' fields."
    )
