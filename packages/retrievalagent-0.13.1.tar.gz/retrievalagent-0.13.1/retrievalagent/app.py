"""Textual TUI for retrievalagent.

Two screens:
  - SetupScreen: configure backend / embedder / LLM / reranker; values
    pre-filled from env (`AZURE_OPENAI_*`, `MEILI_URL`, `OPENAI_API_KEY`,
    `COHERE_API_KEY`, …). Submit builds an AgenticRAG via init_agent
    in a worker thread.
  - ChatScreen: scrollable conversation log, animated spinner,
    sources panel, status footer, slash commands.

Slash commands: /help /quit /clear /sources /history /reload /set k=v
Bindings: ctrl+c quit · ctrl+l clear · ctrl+s sources
"""

from __future__ import annotations

import os
import time
from pathlib import Path
from typing import TYPE_CHECKING, Any

from rich.markdown import Markdown
from rich.panel import Panel
from rich.table import Table
from rich.text import Text
from textual import work
from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical, VerticalScroll
from textual.reactive import reactive
from textual.screen import Screen
from textual.widgets import (
    Button,
    Checkbox,
    Footer,
    Header,
    Input,
    Label,
    Select,
    Static,
)

if TYPE_CHECKING:
    from langchain_core.documents import Document

    from .core import AgenticRAG


# ── shared helpers ───────────────────────────────────────────────────────────


_NODE_LABELS: dict[str, str] = {
    "prepare": "Pre-processing",
    "keyword_search": "Keyword search",
    "synonym_search": "Synonym search",
    "evaluate": "Evaluating results",
    "semantic_backup": "Semantic search",
    "merge_rerank": "Merging & reranking",
    "generate": "Generating answer",
    "final_grade": "Grading answer",
    "rewrite": "Rewriting query",
    "give_up": "Giving up",
    "read_memory": "Reading memory",
    "write_memory": "Writing memory",
}


def _logo() -> Text:
    """Diamond-node logo matching the website mark, with orange accent dot."""
    e = "dim white"  # edge
    n = "bold white"  # node
    o = "bold #E8613C"  # orange dot
    t = Text()
    t.append("         ○\n", style=n)
    t.append("        ╱ ╲\n", style=e)
    t.append("       ╱   ╲\n", style=e)
    t.append("      ○     ○ ── ", style=n)
    t.append("●\n", style=o)
    t.append("       ╲   ╱\n", style=e)
    t.append("        ╲ ╱\n", style=e)
    t.append("         ○", style=n)
    return t


def _brand() -> Text:
    t = Text()
    t.append("retrieval", style="bold white")
    t.append("·", style="bold #E8613C")
    t.append("agent", style="bold white")
    return t


def _sources_panel(docs: list[Document]) -> Panel:
    table = Table(box=None, show_header=True, header_style="bold dim", padding=(0, 1))
    table.add_column("#", justify="right", style="bold")
    table.add_column("source")
    table.add_column("score", justify="right", style="dim")
    for i, d in enumerate(docs, 1):
        snippet = d.page_content[:120].replace("\n", " ")
        score = (
            d.metadata.get("_rerank_score") or d.metadata.get("_rankingScore") or 0.0
        )
        table.add_row(str(i), snippet, f"{float(score):.3f}")
    return Panel(table, title="Sources", border_style="#577BC1")


_HELP = {
    "/help": "Show this help",
    "/quit": "Exit",
    "/clear": "Clear conversation history",
    "/sources": "Show sources from last turn",
    "/history": "Show conversation history",
    "/retrieve": "/retrieve <query> — fetch + show ranked docs, no answer",
    "/reload": "Reload documents (memory backend)",
    "/set": "/set key=value — runtime knob (e.g. /set top_k=10)",
}


def _help_panel() -> Panel:
    table = Table(box=None, show_header=False, padding=(0, 2))
    table.add_column(style="bold #E8613C")
    table.add_column(style="dim")
    for cmd, desc in _HELP.items():
        table.add_row(cmd, desc)
    return Panel(table, title="Commands", border_style="#577BC1")


# ── env inference ────────────────────────────────────────────────────────────


def env_defaults() -> dict[str, str]:
    """Sniff env for sensible defaults; returned dict drives SetupScreen prefill."""
    d: dict[str, str] = {}

    if os.getenv("AZURE_OPENAI_API_KEY") and os.getenv("AZURE_OPENAI_ENDPOINT"):
        deploy = os.getenv("AZURE_OPENAI_DEPLOYMENT") or os.getenv(
            "AZURE_OPENAI_CHAT_DEPLOYMENT", "gpt-5.4-mini"
        )
        d["llm"] = f"azure_openai:{deploy}" if deploy else "azure_openai:gpt-5.4-mini"
    elif os.getenv("OPENAI_API_KEY"):
        d["llm"] = f"openai:{os.getenv('OPENAI_MODEL', 'gpt-5.4-mini')}"
    elif os.getenv("ANTHROPIC_API_KEY"):
        d["llm"] = "anthropic:claude-sonnet-4-6"
    elif os.getenv("OLLAMA_HOST") or os.getenv("OLLAMA_URL"):
        d["llm"] = "ollama:llama3.1"

    if os.getenv("AZURE_OPENAI_ENDPOINT") and (
        os.getenv("AZURE_OPENAI_EMBED_DEPLOYMENT")
        or os.getenv("AZURE_OPENAI_EMBEDDING_DEPLOYMENT")
    ):
        d["embedder"] = "azure"
    elif os.getenv("OPENAI_API_KEY"):
        d["embedder"] = "openai"
    elif os.getenv("OLLAMA_HOST") or os.getenv("OLLAMA_URL"):
        d["embedder"] = "ollama"
    else:
        d["embedder"] = "none"

    if os.getenv("MEILI_URL"):
        d["backend"] = "meilisearch"
        d["backend_url"] = os.getenv("MEILI_URL", "")
        d["backend_key"] = os.getenv("MEILI_KEY") or os.getenv("MEILI_MASTER_KEY", "")
    elif os.getenv("QDRANT_URL"):
        d["backend"] = "qdrant"
        d["backend_url"] = os.getenv("QDRANT_URL", "")
    elif os.getenv("DATABASE_URL") or os.getenv("PGVECTOR_DSN"):
        d["backend"] = "pgvector"
        d["backend_url"] = os.getenv("PGVECTOR_DSN") or os.getenv("DATABASE_URL", "")
    elif os.getenv("AZURE_SEARCH_ENDPOINT"):
        d["backend"] = "azure"
        d["backend_url"] = os.getenv("AZURE_SEARCH_ENDPOINT", "")
        d["backend_key"] = os.getenv("AZURE_SEARCH_API_KEY", "")
    else:
        d["backend"] = "memory"

    if (
        os.getenv("AZURE_COHERE_ENDPOINT")
        or os.getenv("AZURE_COHERE_API_KEY")
        or os.getenv("COHERE_API_KEY")
    ):
        # Default to cohere-direct (no `cohere` SDK install required).
        d["reranker"] = "cohere-direct"
    elif os.getenv("JINA_API_KEY"):
        d["reranker"] = "jina"
    else:
        d["reranker"] = "none"

    if os.getenv("RAG_INDEX") or os.getenv("MS_INDEX"):
        d["index"] = os.getenv("RAG_INDEX") or os.getenv("MS_INDEX", "")

    return d


def env_sufficient(d: dict[str, str]) -> bool:
    return bool(d.get("llm")) and bool(d.get("index"))


# ── widgets ──────────────────────────────────────────────────────────────────


class StatusBar(Static):
    model: reactive[str] = reactive("")
    cwd: reactive[str] = reactive("")
    iters: reactive[int] = reactive(0)
    docs: reactive[int] = reactive(0)
    elapsed: reactive[float] = reactive(0.0)

    def render(self) -> Text:
        parts = [
            f"~/{self.cwd}",
            self.model,
            f"iter={self.iters} · docs={self.docs} · {self.elapsed:0.1f}s",
        ]
        return Text(" · ".join(p for p in parts if p), style="dim")


class SpinnerLine(Static):
    """Animated single-line status: 'Retrieving… (1.4s · 3 steps)'."""

    _frames = "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏"
    label: reactive[str] = reactive("")
    started: reactive[float] = reactive(0.0)
    steps: reactive[int] = reactive(0)
    _frame_idx: int = 0
    _timer: Any = None

    def start(self, label: str) -> None:
        self.label = label
        self.started = time.perf_counter()
        self.steps = 0
        if self._timer is None:
            self._timer = self.set_interval(0.1, self._tick)

    def update_label(self, label: str) -> None:
        self.label = label
        self.steps += 1

    def stop(self) -> None:
        if self._timer is not None:
            self._timer.stop()
            self._timer = None
        self.update("")

    def _tick(self) -> None:
        if not self.label:
            return
        self._frame_idx = (self._frame_idx + 1) % len(self._frames)
        glyph = self._frames[self._frame_idx]
        elapsed = time.perf_counter() - self.started
        self.update(
            Text.from_markup(
                f"[bold #577BC1]{glyph} {self.label}…[/] "
                f"[dim]({elapsed:0.1f}s · {self.steps} step"
                f"{'s' if self.steps != 1 else ''})[/dim]"
            )
        )


# ── chat bubbles ─────────────────────────────────────────────────────────────


class UserBubble(Static):
    """A right-aligned 'You' bubble showing the user's question."""

    def __init__(self, question: str) -> None:
        # Set content at construct time so the bubble paints in the same
        # frame it's mounted — no on_mount delay before the user sees
        # their question echoed back.
        super().__init__(Text.from_markup(f"[bold white]You ▸[/] {question}"))
        self.question = question


class AssistantBubble(Vertical):
    """An assistant turn with live status, streaming answer, and sources.

    Layout (top → bottom):
      - status line (small, dim) — pipeline node label / typing indicator
      - body (Static) — streaming answer text, finalized as Markdown
      - sources (Static) — sources panel attached after finalize
    """

    _frames = "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏"

    def __init__(self) -> None:
        super().__init__()
        self._buffer: list[str] = []
        self._status_label: str = "Thinking"
        self._steps: int = 0
        self._started: float = 0.0
        self._frame_idx: int = 0
        self._timer: Any = None
        self._finalized: bool = False

    def compose(self) -> ComposeResult:
        yield Static("", classes="assistant-status")
        yield Static("", classes="assistant-body")
        yield Static("", classes="assistant-sources")

    def on_mount(self) -> None:
        self._started = time.perf_counter()
        self._timer = self.set_interval(0.1, self._tick)
        self._render_body_streaming()

    def set_status(self, label: str) -> None:
        self._status_label = label
        self._steps += 1

    def append_token(self, token: str) -> None:
        self._buffer.append(token)
        self._render_body_streaming()

    def finalize(self, answer: str, docs: list[Document]) -> None:
        """Stop the typing indicator, render Markdown, attach sources."""
        if self._timer is not None:
            self._timer.stop()
            self._timer = None
        self._finalized = True
        # Mirror final answer into the buffer so rendered_text() reflects
        # what the user sees, even when the LLM didn't stream tokens.
        if answer and not self._buffer:
            self._buffer.append(answer)
        # Status: collapse to a quiet "done" line with elapsed/steps.
        elapsed = time.perf_counter() - self._started
        status = self.query_one(".assistant-status", Static)
        status.update(
            Text.from_markup(
                f"[dim]✓ {self._status_label} · "
                f"{elapsed:0.1f}s · {self._steps} step"
                f"{'s' if self._steps != 1 else ''}[/dim]"
            )
        )
        body = self.query_one(".assistant-body", Static)
        if answer:
            try:
                body.update(Markdown(answer))
            except Exception:
                body.update(answer)
        else:
            body.update(Text("(no answer generated)", style="dim"))
        if docs:
            self.query_one(".assistant-sources", Static).update(_sources_panel(docs))

    def fail(self, message: str) -> None:
        if self._timer is not None:
            self._timer.stop()
            self._timer = None
        self._finalized = True
        self.query_one(".assistant-status", Static).update(
            Text("✗ failed", style="bold #E8613C")
        )
        self.query_one(".assistant-body", Static).update(
            Text.from_markup(f"[bold #E8613C]Error:[/] {message}")
        )

    def rendered_text(self) -> str:
        """Plain-text snapshot of the assistant body — used by tests."""
        return "".join(self._buffer)

    def _tick(self) -> None:
        if self._finalized:
            return
        self._frame_idx = (self._frame_idx + 1) % len(self._frames)
        glyph = self._frames[self._frame_idx]
        elapsed = time.perf_counter() - self._started
        status = self.query_one(".assistant-status", Static)
        status.update(
            Text.from_markup(
                f"[bold #577BC1]{glyph}[/] [dim]{self._status_label}… "
                f"({elapsed:0.1f}s · {self._steps} step"
                f"{'s' if self._steps != 1 else ''})[/dim]"
            )
        )

    def _render_body_streaming(self) -> None:
        """While streaming, show plain text — re-render Markdown on finalize.

        Markdown re-rendering on every token is costly; plain text feels
        snappy and the final render gets full Markdown anyway.
        """
        if self._finalized:
            return
        body = self.query_one(".assistant-body", Static)
        text = "".join(self._buffer)
        if text:
            body.update(Text(text))
        else:
            body.update(Text("● ● ●", style="dim #577BC1"))


class TurnContainer(Vertical):
    """One conversational turn: user bubble + assistant bubble."""

    def __init__(self, question: str) -> None:
        super().__init__()
        self.question = question
        self.user_bubble = UserBubble(question)
        self.assistant_bubble = AssistantBubble()

    def compose(self) -> ComposeResult:
        yield self.user_bubble
        yield self.assistant_bubble


# ── setup screen ─────────────────────────────────────────────────────────────


_BACKEND_CHOICES = [
    ("memory — no setup", "memory"),
    ("duckdb — local file", "duckdb"),
    ("chromadb — local/server", "chromadb"),
    ("meilisearch — full-text + vector", "meilisearch"),
    ("qdrant — vector DB", "qdrant"),
    ("pgvector — Postgres + pgvector", "pgvector"),
    ("lancedb — columnar vector", "lancedb"),
    ("azure — Azure AI Search", "azure"),
]

_RERANKER_CHOICES = [
    ("none", "none"),
    (
        "cohere-direct — Cohere via httpx (no SDK install, supports Azure)",
        "cohere-direct",
    ),
    ("cohere — Cohere via official SDK (needs `cohere` pkg)", "cohere"),
    ("jina — API (needs JINA_API_KEY)", "jina"),
    ("huggingface — local cross-encoder", "huggingface"),
    ("llm — uses your chat model", "llm"),
]

_MODE_CHOICES = [
    ("chat — conversational Q&A", "chat"),
    ("retriever — search & inspect ranked docs", "retriever"),
]

# Each entry: pip-importable module name + extras name to suggest.
_BACKEND_REQUIREMENTS: dict[str, tuple[str, str]] = {
    "meilisearch": ("meilisearch", "meilisearch"),
    "qdrant": ("qdrant_client", "qdrant"),
    "chromadb": ("chromadb", "chromadb"),
    "lancedb": ("lancedb", "lancedb"),
    "duckdb": ("duckdb", "duckdb"),
    "pgvector": ("psycopg", "pgvector"),
    "azure": ("azure.search.documents", "azure"),
}

_RERANKER_REQUIREMENTS: dict[str, tuple[str, str]] = {
    "cohere": ("cohere", "cohere"),
    "jina": ("httpx", "jina"),
    "huggingface": ("sentence_transformers", "huggingface"),
    "rerankers": ("rerankers", "rerankers"),
}


def _missing_package(module: str) -> bool:
    try:
        __import__(module)
    except ImportError:
        return True
    return False


class SetupScreen(Screen):
    CSS = """
    SetupScreen { align: center top; layout: vertical; background: #0B0F14; }
    Header { background: #0B0F14; color: #FAF8F4; }
    #setup-form {
        width: 100%;
        max-width: 100;
        padding: 1 4 2 4;
        height: 1fr;
    }
    #setup-actions {
        dock: bottom;
        height: auto;
        width: 100%;
        padding: 1 2;
        background: #11161D;
        border-top: hkey #1f2730;
    }
    .field-label {
        color: #E8613C;
        padding: 1 0 0 0;
        text-style: bold;
    }
    .hint { color: $text-muted; padding-bottom: 1; }
    .option-row { padding: 1 0 0 0; height: auto; }

    Input, Select {
        width: 100%;
        background: #11161D;
        border: tall #1f2730;
        color: #FAF8F4;
    }
    Input:focus, Select:focus { border: tall #E8613C; }
    Select > SelectCurrent { background: #11161D; }

    Checkbox {
        background: transparent;
        color: #FAF8F4;
        border: tall transparent;
        padding: 0 1;
    }
    Checkbox > .toggle--button { color: #E8613C; }
    Checkbox:focus { border: tall #E8613C; }

    #error { color: #E8613C; padding: 0 2 1 2; text-align: center; width: 100%; }
    #building { padding: 0 2 1 2; text-align: center; width: 100%; }

    #buttons {
        width: 100%;
        height: auto;
        align-horizontal: center;
        padding: 0;
    }
    Button {
        margin: 0 1;
        min-width: 16;
        height: 3;
        border: tall #1f2730;
        background: #11161D;
        color: #FAF8F4;
        text-style: bold;
    }
    Button:hover { background: #1a2029; }
    Button:focus { border: tall #E8613C; }

    Button#submit {
        background: #E8613C;
        color: #0B0F14;
        border: tall #E8613C;
    }
    Button#submit:hover {
        background: #ff7a52;
        border: tall #ff7a52;
    }
    Button#submit:focus { border: tall #FAF8F4; }
    """

    BINDINGS = [Binding("ctrl+c", "quit", "Quit", priority=True)]

    def __init__(self, defaults: dict[str, str]) -> None:
        super().__init__()
        self.defaults = defaults
        self.last_error: str = ""

    def compose(self) -> ComposeResult:
        yield Header(show_clock=False)
        with VerticalScroll(id="setup-form"):
            yield Static(_logo())
            yield Static(_brand())
            yield Static(Text("configure — values pre-filled from env", style="dim"))

            yield Label("Index / collection name", classes="field-label")
            yield Input(
                value=self.defaults.get("index", ""),
                placeholder="e.g. my_index",
                id="index",
            )

            yield Label(
                "Extra collections (comma-sep, optional)", classes="field-label"
            )
            yield Input(value="", placeholder="docs,faq", id="collections")

            yield Label("Backend", classes="field-label")
            yield Select(
                _BACKEND_CHOICES,
                value=self.defaults.get("backend", "memory"),
                id="backend",
                allow_blank=False,
            )
            yield Input(
                value=self.defaults.get("backend_url", ""),
                placeholder="backend URL (Meili/Qdrant/Postgres/Azure) — leave blank for memory/duckdb",
                id="backend_url",
            )
            yield Input(
                value=self.defaults.get("backend_key", ""),
                placeholder="backend API key (if applicable)",
                password=True,
                id="backend_key",
            )

            yield Label(
                "LLM model (e.g. azure_openai:gpt-5.4-mini, openai:gpt-5.5, ollama:llama3.1)",
                classes="field-label",
            )
            yield Input(
                value=self.defaults.get("llm", ""),
                placeholder="provider:model",
                id="llm_model",
            )

            yield Label("Reranker", classes="field-label")
            yield Select(
                _RERANKER_CHOICES,
                value=self.defaults.get("reranker", "none"),
                id="reranker",
                allow_blank=False,
            )

            yield Label("Mode", classes="field-label")
            yield Select(
                _MODE_CHOICES,
                value=self.defaults.get("mode", "chat"),
                id="mode",
                allow_blank=False,
            )

            with Horizontal(classes="option-row"):
                yield Checkbox(
                    "Elbow cutoff  [dim](trim noise results after largest score drop)[/]",
                    value=os.getenv("RAG_ENABLE_ELBOW_CUTOFF", "1")
                    in ("1", "true", "yes"),
                    id="elbow_cutoff",
                )

        with Vertical(id="setup-actions"):
            yield Static("", id="error")
            yield Static("", id="building")
            with Horizontal(id="buttons"):
                yield Button("Start", id="submit")
                yield Button("Quit", id="quit")
        yield Footer()

    def on_mount(self) -> None:
        self.query_one("#index", Input).focus()

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "quit":
            self.app.exit()
            return
        if event.button.id == "submit":
            self._submit()

    def on_input_submitted(self, event: Input.Submitted) -> None:
        self._submit()

    def _submit(self) -> None:
        index = self.query_one("#index", Input).value.strip()
        if not index:
            self._error("index is required")
            return
        collections_raw = self.query_one("#collections", Input).value.strip()
        backend = str(self.query_one("#backend", Select).value)
        backend_url = self.query_one("#backend_url", Input).value.strip()
        backend_key = self.query_one("#backend_key", Input).value.strip()
        llm_model = self.query_one("#llm_model", Input).value.strip()
        reranker = str(self.query_one("#reranker", Select).value)
        mode = str(self.query_one("#mode", Select).value)
        elbow_cutoff = self.query_one("#elbow_cutoff", Checkbox).value

        if reranker in {"cohere", "cohere-direct"} and not (
            os.getenv("COHERE_API_KEY")
            or os.getenv("AZURE_COHERE_API_KEY")
            or os.getenv("AZURE_COHERE_ENDPOINT")
        ):
            self._error(
                "no Cohere creds — set COHERE_API_KEY or AZURE_COHERE_ENDPOINT/_API_KEY"
            )
            return
        if reranker == "jina" and not os.getenv("JINA_API_KEY"):
            self._error("JINA_API_KEY not set — choose a different reranker")
            return

        # Backend / reranker package install check.
        if backend in _BACKEND_REQUIREMENTS:
            mod, extra = _BACKEND_REQUIREMENTS[backend]
            if _missing_package(mod):
                self._error(
                    f"backend '{backend}' requires `{mod}` — "
                    f"install with: pip install retrievalagent[{extra}]"
                )
                return
        if reranker in _RERANKER_REQUIREMENTS:
            mod, extra = _RERANKER_REQUIREMENTS[reranker]
            if _missing_package(mod):
                self._error(
                    f"reranker '{reranker}' requires `{mod}` — "
                    f"install with: pip install retrievalagent[{extra}]"
                )
                return

        self._error("")
        self.query_one("#building", Static).update(
            Text("building agent…", style="bold #577BC1")
        )
        self.query_one("#submit", Button).disabled = True

        cfg: dict[str, Any] = {
            "index": index,
            "backend": backend,
        }
        if collections_raw:
            cols = [c.strip() for c in collections_raw.split(",") if c.strip()]
            cfg["collections"] = [index, *cols] if index not in cols else cols
        if backend_url:
            cfg["backend_url"] = backend_url
        if backend_key:
            cfg["backend_kwargs"] = {"api_key": backend_key}
        if llm_model:
            cfg["model"] = llm_model
        if reranker != "none":
            cfg["reranker"] = reranker
        if elbow_cutoff:
            cfg["elbow_cutoff"] = True

        self._build(cfg, mode)

    def _error(self, msg: str) -> None:
        # Plain Text, not from_markup — error strings may contain [extras]
        # brackets that would otherwise be parsed as markup tags.
        self.last_error = msg
        self.query_one("#error", Static).update(
            Text(msg, style="#E8613C") if msg else Text("")
        )

    @work(exclusive=True, thread=True)
    def _build(self, cfg: dict[str, Any], mode: str = "chat") -> None:
        from .embed.factories import _make_azure_embed_fn
        from .factory import init_agent
        from .config import RAGConfig

        enable_elbow = cfg.pop("elbow_cutoff", False)

        if cfg.get("backend") in {"meilisearch", "qdrant"}:
            try:
                cfg.setdefault("embed_fn", _make_azure_embed_fn())
            except Exception:
                pass

        if enable_elbow:
            base = cfg.get("config") or RAGConfig.auto()
            cfg["config"] = base.model_copy(update={"enable_elbow_cutoff": True})

        try:
            rag = init_agent(**cfg)
        except Exception as exc:
            self.app.call_from_thread(self._on_build_error, str(exc))
            return
        self.app.call_from_thread(self._on_build_success, rag, mode)

    def _on_build_error(self, msg: str) -> None:
        self.query_one("#building", Static).update("")
        self.query_one("#submit", Button).disabled = False
        self._error(f"failed to initialise: {msg}")

    def _on_build_success(self, rag: AgenticRAG, mode: str = "chat") -> None:
        self.query_one("#building", Static).update("")
        from_app: RetrievalApp = self.app  # type: ignore[assignment]
        from_app.rag = rag
        if mode == "retriever":
            from_app.push_screen(RetrieverScreen())
        else:
            from_app.push_screen(ChatScreen())


# ── retriever screen ─────────────────────────────────────────────────────────


class RetrieverScreen(Screen):
    CSS = """
    RetrieverScreen { layout: vertical; background: #0B0F14; }
    Header { background: #0B0F14; color: #FAF8F4; }
    Footer { background: #11161D; }
    #ret-scroll {
        height: 1fr;
        padding: 1 3;
        scrollbar-gutter: stable;
    }
    #ret-status {
        height: 1;
        padding: 0 3;
        background: #11161D;
        color: $text-muted;
    }
    #ret-prompt {
        dock: bottom;
        border: tall #1f2730;
        margin: 0 2 1 2;
        padding: 0 1;
        height: 3;
        background: #11161D;
        color: #FAF8F4;
    }
    #ret-prompt:focus { border: tall #E8613C; }
    .ret-spacer { height: 1fr; min-height: 0; }
    .ret-line   { height: auto; padding: 0 3 1 3; }
    """

    BINDINGS = [
        Binding("ctrl+c", "quit", "Quit", priority=True),
        Binding("ctrl+l", "clear", "Clear"),
    ]

    def __init__(self) -> None:
        super().__init__()
        self._spinning: bool = False
        self._frame_idx: int = 0
        self._timer: Any = None

    @property
    def rag(self) -> AgenticRAG:
        return self.app.rag  # type: ignore[attr-defined]

    def compose(self) -> ComposeResult:
        yield Header(show_clock=False)
        yield VerticalScroll(id="ret-scroll")
        yield StatusBar(id="ret-status")
        yield Input(placeholder="Search query…  ctrl+l clear", id="ret-prompt")
        yield Footer()

    async def on_mount(self) -> None:
        self.app.title = "retrieval·agent"
        self.app.sub_title = "retriever"
        scroll = self.query_one("#ret-scroll", VerticalScroll)
        await scroll.mount(Static("", classes="ret-spacer"))
        await scroll.mount(Static(_logo(), classes="ret-line"))
        await scroll.mount(Static(_brand(), classes="ret-line"))
        await scroll.mount(
            Static(
                Text(
                    "enter a query to search and inspect ranked documents.", style="dim"
                ),
                classes="ret-line",
            )
        )
        self.query_one("#ret-prompt", Input).focus()

    async def on_input_submitted(self, event: Input.Submitted) -> None:
        query = event.value.strip()
        event.input.value = ""
        if query:
            await self._run(query)

    async def action_clear(self) -> None:
        scroll = self.query_one("#ret-scroll", VerticalScroll)
        await scroll.remove_children()
        await scroll.mount(Static("", classes="ret-spacer"))
        await scroll.mount(Static(Text("cleared.", style="dim"), classes="ret-line"))

    async def _run(self, query: str) -> None:
        scroll = self.query_one("#ret-scroll", VerticalScroll)
        bar = self.query_one("#ret-status", StatusBar)

        spinner = Static(
            Text.from_markup(f"[bold #577BC1]⠋[/] [dim]{query}…[/]"), classes="ret-line"
        )
        await scroll.mount(spinner)
        scroll.scroll_end(animate=False)

        self._frame_idx = 0
        frames = "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏"
        t0 = time.perf_counter()

        def _tick() -> None:
            self._frame_idx = (self._frame_idx + 1) % len(frames)
            elapsed = time.perf_counter() - t0
            spinner.update(
                Text.from_markup(
                    f"[bold #577BC1]{frames[self._frame_idx]}[/] "
                    f"[dim]{query}… ({elapsed:0.1f}s)[/]"
                )
            )

        timer = self.set_interval(0.1, _tick)
        try:
            result = await self.rag._aretrieve_documents(query)
        except Exception as exc:
            timer.stop()
            spinner.update(Text.from_markup(f"[bold #E8613C]✗ error:[/] {exc}"))
            return
        timer.stop()
        elapsed = time.perf_counter() - t0
        docs = result.docs

        spinner.remove()

        table = Table(
            box=None,
            show_header=True,
            header_style="bold dim",
            padding=(0, 1),
            expand=True,
        )
        table.add_column("#", justify="right", style="bold", width=3)
        table.add_column("score", justify="right", style="dim", width=7)
        table.add_column("source", style="dim", width=28, no_wrap=True)
        table.add_column("content")

        for i, d in enumerate(docs[: self.rag.top_k], 1):
            score = (
                d.metadata.get("_rerank_score")
                or d.metadata.get("_rankingScore")
                or 0.0
            )
            source = (
                d.metadata.get("source")
                or d.metadata.get("title")
                or d.metadata.get("id")
                or "—"
            )
            source = str(source)[-28:]
            snippet = d.page_content[:200].replace("\n", " ")
            table.add_row(str(i), f"{float(score):.3f}", source, snippet)

        panel = Panel(
            table,
            title=Text.assemble(
                (f"{len(docs[: self.rag.top_k])} results  ", "bold white"),
                ("·", "#E8613C"),
                (f"  {query}", "dim"),
                (f"  [{elapsed:0.1f}s]", "dim"),
            ),
            border_style="#577BC1",
        )
        await scroll.mount(Static(panel, classes="ret-line"))
        scroll.scroll_end(animate=False)

        bar.docs = len(docs)
        bar.elapsed = elapsed


# ── chat screen ──────────────────────────────────────────────────────────────


class ChatScreen(Screen):
    CSS = """
    ChatScreen { layout: vertical; background: #0B0F14; }
    Header { background: #0B0F14; color: #FAF8F4; }
    Footer { background: #11161D; }
    #conversation {
        height: 1fr;
        padding: 1 3;
        scrollbar-gutter: stable;
    }
    .conversation-spacer { height: 1fr; min-height: 0; }
    #status {
        height: 1;
        padding: 0 3;
        background: #11161D;
        color: $text-muted;
    }
    #prompt {
        dock: bottom;
        border: tall #1f2730;
        margin: 0 2 1 2;
        padding: 0 1;
        height: 3;
        background: #11161D;
        color: #FAF8F4;
    }
    #prompt:focus { border: tall #E8613C; }
    UserBubble {
        height: auto;
        padding: 1 2 0 2;
        color: #FAF8F4;
        text-style: bold;
    }
    AssistantBubble {
        height: auto;
        padding: 0 2 1 2;
    }
    TurnContainer { height: auto; padding-bottom: 1; }
    .assistant-status  { height: auto; padding: 0 0 1 0; }
    .assistant-body    { height: auto; padding: 0 0 1 0; }
    .assistant-sources { height: auto; }
    .system-line       { height: auto; padding: 0 3; color: $text-muted; }
    """

    BINDINGS = [
        Binding("ctrl+c", "quit", "Quit", priority=True),
        Binding("ctrl+l", "clear_history", "Clear"),
        Binding("ctrl+s", "show_sources", "Sources"),
    ]

    def __init__(self) -> None:
        super().__init__()
        self.history: list[Any] = []
        self.last_docs: list[Document] = []
        self._last_bubble: AssistantBubble | None = None

    @property
    def rag(self) -> AgenticRAG:
        return self.app.rag  # type: ignore[attr-defined]

    @property
    def request_config(self) -> dict[str, Any] | None:
        return getattr(self.app, "request_config", None)

    @property
    def on_reload(self) -> Any:
        return getattr(self.app, "on_reload", None)

    def compose(self) -> ComposeResult:
        yield Header(show_clock=False)
        yield VerticalScroll(id="conversation")
        yield StatusBar(id="status")
        yield Input(placeholder="Ask…  /help for commands", id="prompt")
        yield Footer()

    async def on_mount(self) -> None:
        self.app.title = "retrieval·agent"
        self.app.sub_title = self._collection_label()

        await self._mount_intro()

        bar = self.query_one("#status", StatusBar)
        bar.cwd = Path.cwd().name
        bar.model = self._model_name()

        self.query_one(Input).focus()

    async def _mount_intro(self) -> None:
        convo = self.query_one("#conversation", VerticalScroll)
        # Flexible spacer: takes 1fr when content < viewport so the
        # latest message sticks to the bottom (above the input). Once
        # content overflows, the spacer collapses naturally.
        await convo.mount(Static("", classes="conversation-spacer"))
        await convo.mount(Static(_logo(), classes="system-line"))
        await convo.mount(Static(_brand(), classes="system-line"))
        await convo.mount(
            Static(
                Text("agentic retrieval-augmented generation", style="dim"),
                classes="system-line",
            )
        )
        await convo.mount(
            Static(
                Text.from_markup(
                    "[bold]Tips:[/bold]\n"
                    "1. Ask questions about your indexed corpus.\n"
                    "2. Be specific — include brand, product code, exact wording.\n"
                    "3. [bold #E8613C]/help[/] for commands, "
                    "[bold #E8613C]/quit[/] to exit."
                ),
                classes="system-line",
            )
        )

    def _model_name(self) -> str:
        llm = getattr(self.rag, "_llm", None)
        return (
            getattr(llm, "model_name", None)
            or getattr(llm, "deployment_name", None)
            or type(llm).__name__
        )

    def _collection_label(self) -> str:
        cols = getattr(self.rag, "collections", None)
        if cols:
            return ", ".join(cols.keys())
        return getattr(self.rag, "index", "?")

    async def _write_system(self, content: Any) -> None:
        convo = self.query_one("#conversation", VerticalScroll)
        await convo.mount(Static(content, classes="system-line"))
        convo.scroll_end(animate=False)

    async def on_input_submitted(self, event: Input.Submitted) -> None:
        q = event.value.strip()
        event.input.value = ""
        if not q:
            return
        if q.startswith("/"):
            await self._handle_slash(q)
            return
        await self._run_turn(q)

    async def _handle_slash(self, q: str) -> None:
        cmd, _, rest = q.partition(" ")
        cmd = cmd.lower()
        if cmd in {"/quit", "/exit", "/q"}:
            self.app.exit()
            return
        if cmd == "/help":
            await self._write_system(_help_panel())
            return
        if cmd == "/clear":
            await self.action_clear_history()
            return
        if cmd == "/sources":
            await self.action_show_sources()
            return
        if cmd == "/history":
            await self._render_history()
            return
        if cmd in {"/retrieve", "/r"}:
            await self._run_retrieve_only(rest.strip())
            return
        if cmd == "/reload":
            if callable(self.on_reload):
                self.on_reload()
                await self._write_system(Text("documents reloaded.", style="dim"))
            else:
                await self._write_system(
                    Text("/reload only available with memory backend.", style="dim")
                )
            return
        if cmd == "/set":
            await self._apply_set(rest)
            return
        await self._write_system(
            Text.from_markup(f"[bold #E8613C]unknown command:[/] {cmd}")
        )

    async def action_clear_history(self) -> None:
        self.history.clear()
        self.last_docs = []
        self._last_bubble = None
        convo = self.query_one("#conversation", VerticalScroll)
        await convo.remove_children()
        await self._mount_intro()
        await self._write_system(Text("history cleared.", style="dim"))

    async def action_show_sources(self) -> None:
        if not self.last_docs:
            await self._write_system(Text("(no sources from last turn)", style="dim"))
            return
        await self._write_system(_sources_panel(self.last_docs[: self.rag.top_k]))

    async def _run_retrieve_only(self, query: str) -> None:
        """Run retrieval without generation. Show docs in a sources
        table and skip the LLM answer entirely — useful for evaluating
        ranking quality and avoiding the gen-LLM round-trip."""
        if not query:
            await self._write_system(
                Text.from_markup("[bold #E8613C]usage:[/] /retrieve <query>")
            )
            return
        bar = self.query_one("#status", StatusBar)
        await self._write_system(
            Text.from_markup(f"[bold #E8613C]/retrieve[/] {query}")
        )
        t0 = time.perf_counter()
        try:
            result = await self.rag._aretrieve_documents(query)
        except Exception as exc:
            await self._write_system(
                Text.from_markup(f"[bold #E8613C]retrieve error:[/] {exc}")
            )
            return
        elapsed = time.perf_counter() - t0
        docs = result.docs
        if not docs:
            await self._write_system(Text("(no docs)", style="dim"))
            bar.iters = 0
            bar.docs = 0
            bar.elapsed = elapsed
            return
        await self._write_system(_sources_panel(docs[: self.rag.top_k]))
        bar.iters = 0
        bar.docs = len(docs)
        bar.elapsed = elapsed
        self.last_docs = docs

    async def _render_history(self) -> None:
        if not self.history:
            await self._write_system(Text("(history empty)", style="dim"))
            return
        for i, turn in enumerate(self.history, 1):
            await self._write_system(
                Panel(
                    Text.from_markup(
                        f"[bold #E8613C]Q:[/] {turn.question}\n"
                        f"[bold]A:[/] {turn.answer[:400]}"
                    ),
                    title=f"Turn {i}",
                    border_style="#577BC1",
                )
            )

    async def _apply_set(self, args: str) -> None:
        if "=" not in args:
            await self._write_system(
                Text.from_markup("[bold #E8613C]usage:[/] /set key=value")
            )
            return
        key, _, value = args.partition("=")
        key = key.strip()
        value = value.strip()
        if not hasattr(self.rag, key):
            await self._write_system(
                Text.from_markup(f"[bold #E8613C]no such attribute:[/] {key}")
            )
            return
        current = getattr(self.rag, key)
        try:
            coerced: Any = type(current)(value) if current is not None else value
        except Exception:
            coerced = value
        setattr(self.rag, key, coerced)
        await self._write_system(
            Text.from_markup(f"[bold #E8613C]set[/] [bold]{key}[/] = {coerced!r}")
        )

    async def _run_turn(self, question: str) -> None:
        convo = self.query_one("#conversation", VerticalScroll)

        turn = TurnContainer(question)
        await convo.mount(turn)
        self._last_bubble = turn.assistant_bubble
        convo.scroll_end(animate=False)
        # Defer the rag work until AFTER the next render so the user
        # bubble + assistant spinner paint before any (potentially
        # loop-blocking) graph work begins.
        self.call_after_refresh(self._spawn_work, question, turn)

    def _spawn_work(self, question: str, turn: TurnContainer) -> None:
        self.run_worker(
            self._do_work(question, turn),
            exclusive=False,
            group="rag-turn",
        )

    async def _do_work(self, question: str, turn: TurnContainer) -> None:
        from .models import ConversationTurn

        convo = self.query_one("#conversation", VerticalScroll)
        bar = self.query_one("#status", StatusBar)
        bubble = turn.assistant_bubble

        t0 = time.perf_counter()
        answer_parts: list[str] = []
        last_state: Any = None

        try:
            async for kind, payload in self.rag.astream_events(
                question, history=list(self.history), config=self.request_config
            ):
                if kind == "node":
                    label = _NODE_LABELS.get(str(payload), str(payload))
                    bubble.set_status(label)
                elif kind == "token":
                    answer_parts.append(str(payload))
                    bubble.append_token(str(payload))
                    convo.scroll_end(animate=False)
                elif kind == "state":
                    last_state = payload
        except Exception as exc:
            bubble.fail(str(exc))
            return

        if last_state is None:
            try:
                last_state = await self.rag.ainvoke(
                    question, config=self.request_config
                )
            except Exception as exc:
                bubble.fail(str(exc))
                return

        answer = "".join(answer_parts) or (last_state.answer or "")
        docs = list(last_state.documents or [])
        elapsed = time.perf_counter() - t0

        bubble.finalize(answer, docs[: self.rag.top_k])
        convo.scroll_end(animate=False)

        bar.iters = int(getattr(last_state, "iterations", 0) or 0)
        bar.docs = len(docs)
        bar.elapsed = elapsed

        self.last_docs = docs
        if answer:
            self.history.append(
                ConversationTurn(question=question, answer=answer, documents=docs)
            )


# ── App ──────────────────────────────────────────────────────────────────────


class RetrievalApp(App):
    CSS = ""  # screens carry their own CSS
    TITLE = "retrieval·agent"

    BINDINGS = [
        Binding("ctrl+c", "quit", "Quit", priority=True, show=False),
        Binding("ctrl+q", "quit", "Quit", priority=True, show=True),
    ]

    def __init__(
        self,
        *,
        rag: AgenticRAG | None = None,
        request_config: dict[str, Any] | None = None,
        on_reload: Any = None,
        defaults: dict[str, str] | None = None,
    ) -> None:
        super().__init__()
        self.rag = rag
        self.request_config = request_config
        self.on_reload = on_reload
        self.defaults = defaults or {}

    def on_mount(self) -> None:
        if self.rag is None:
            self.push_screen(SetupScreen(self.defaults))
        else:
            self.push_screen(ChatScreen())


def run_app(
    rag: AgenticRAG | None = None,
    *,
    request_config: dict[str, Any] | None = None,
    on_reload: Any = None,
    defaults: dict[str, str] | None = None,
) -> None:
    """Launch the Textual app. If `rag` is None, SetupScreen runs first."""
    RetrievalApp(
        rag=rag,
        request_config=request_config,
        on_reload=on_reload,
        defaults=defaults,
    ).run()


def is_available() -> bool:
    try:
        import textual  # noqa: F401
    except ImportError:
        return False
    return os.environ.get("TERM", "") not in {"dumb", ""}
