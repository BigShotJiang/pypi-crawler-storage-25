from __future__ import annotations

import re
import warnings
from typing import TYPE_CHECKING, Any, Callable

if TYPE_CHECKING:
    from ..backend import SearchBackend
    from ..embed.embedder import Embedder


_ID_SUFFIXES = ("_id", "_code", "_key", "_num")

_CATEGORY_FIELD_PATTERN = re.compile(
    r"(group|category|kategorie|categorie|categoria|class|klass|type|typ|section|department|rubrik|family)",
    re.IGNORECASE,
)


def _has_is_own_brand_field(backend: SearchBackend) -> bool:
    try:
        return "is_own_brand" in backend.get_index_config().filterable_attributes
    except Exception:
        return False


def _detect_embedder_name(backend: SearchBackend, *, fallback: str) -> str:
    try:
        names = backend.get_index_config().embedders
    except Exception:
        return fallback
    if not names:
        return fallback
    if "default" in names:
        return "default"
    return names[0]


def _validate_embedder_name(backend: SearchBackend, name: str) -> None:
    try:
        names = backend.get_index_config().embedders
    except Exception:
        return
    if names and name not in names:
        warnings.warn(
            f"Configured embedder_name={name!r} is not declared on the index "
            f"(available: {names}). Vector search will silently fall back to "
            f"BM25-only. Set RAG_EMBEDDER_NAME or pass embedder_name= to one "
            f"of the available names.",
            RuntimeWarning,
            stacklevel=3,
        )


def _align_embedder_with_backend(
    embedder: "Embedder | None",
    backend: SearchBackend,
) -> "Embedder | None":
    """Reconcile an Embedder's output dim with the backend's expected dim.

    Returns the same embedder if dims agree (or the backend declares no
    embedder dims), otherwise calls `embedder.with_target_dim(target)`
    so the embedder gets a chance to do a real rebuild (Azure does)
    instead of falling back to slice+renorm.
    """
    if embedder is None:
        return None
    try:
        cfg = backend.get_index_config()
    except Exception:
        return embedder
    dims = set(cfg.embedder_dims.values())
    if not dims:
        return embedder
    try:
        probe = embedder.embed("probe")
    except Exception:
        return embedder
    probe_dim = len(probe)
    if probe_dim in dims:
        return embedder
    if len(dims) != 1:
        warnings.warn(
            f"Embedder returns {probe_dim}-d vectors but index declares "
            f"multiple dims {sorted(dims)}; vector search may miss. "
            "Provide an embedder with a matching dimension.",
            RuntimeWarning,
            stacklevel=3,
        )
        return embedder
    target = next(iter(dims))
    if probe_dim < target:
        warnings.warn(
            f"Embedder returns {probe_dim}-d vectors but index expects "
            f"{target}-d — can't up-project. Use a larger embedder.",
            RuntimeWarning,
            stacklevel=3,
        )
        return embedder

    return embedder.with_target_dim(target)


def _align_embed_fn_with_backend(
    embed_fn: Callable[[str], list[float]] | None,
    backend: SearchBackend,
) -> Callable[[str], list[float]] | None:
    """Legacy wrapper: align a bare callable via the Embedder pipeline.

    Lifts the callable into a CallableEmbedder, runs the alignment,
    then returns an Embedder (which is also callable). Prefer
    `_align_embedder_with_backend` in new code.
    """
    if embed_fn is None:
        return None
    from ..embed.embedder import CallableEmbedder, coerce_embedder

    if hasattr(embed_fn, "embed") and hasattr(embed_fn, "dim"):
        # Already an Embedder — align in place.
        aligned = _align_embedder_with_backend(coerce_embedder(embed_fn), backend)
        return aligned
    wrapped = CallableEmbedder(embed_fn)
    aligned = _align_embedder_with_backend(wrapped, backend)
    if aligned is wrapped:
        return embed_fn  # nothing to adapt; return the original callable
    if aligned is None:
        return None
    return aligned


def _detect_category_fields(backend: SearchBackend) -> list[str]:
    try:
        samples = backend.sample_documents(limit=20)
    except Exception:
        return []
    if not samples:
        return []
    seen: dict[str, int] = {}
    for doc in samples:
        for k, v in doc.items():
            if not isinstance(v, str) or not v:
                continue
            if _CATEGORY_FIELD_PATTERN.search(k):
                seen[k] = seen.get(k, 0) + 1
    if not seen:
        return []

    def rank(k: str) -> tuple[int, int]:
        depth = 0
        for suffix, d in (("_l3", 3), ("_l2", 2), ("_l1", 1)):
            if k.lower().endswith(suffix):
                depth = d
                break
        return (-depth, -seen[k])

    return sorted(seen, key=rank)


def _detect_index_signals(
    backend: SearchBackend,
    *,
    strategy: str = "log_scale",
) -> tuple[list[str] | None, Callable[[dict], float] | None, list[str], str | None]:
    """Detect ranking signals from the backend's sortable_attributes.

    Returns: (sort_fields, boost_fn, num_fields, primary_preference_field)

    `primary_preference_field` is the first SORTABLE BOOL — the schema
    designer's declared "preferred-item" flag (typically `is_own_brand`,
    `is_featured`, etc.). Used by the LLM grader as a ★ tag without
    relying on a magic-number boost threshold.

    `strategy` selects the popularity-boost math: "log_scale" (default,
    tunable coefficients), "percentile" (corpus-distribution rank),
    "zscore" (mean+std normalized via sigmoid), "bayesian" (IMDb-style
    smoothed average), "tie_break" (bool-only tie-breaker), or "none"
    (no boost). See helpers/boost_strategies.py.
    """
    config = backend.get_index_config()
    sortable = config.sortable_attributes
    if not sortable:
        return None, None, [], None

    samples = backend.sample_documents(limit=200)
    if not samples:
        return None, None, [], None

    field_sample: dict[str, Any] = {}
    for doc in samples:
        for f in sortable:
            if f not in field_sample and doc.get(f) is not None:
                field_sample[f] = doc[f]
        if len(field_sample) == len(sortable):
            break

    bool_fields: list[str] = []
    num_fields: list[str] = []
    for f in sortable:
        value = field_sample.get(f)
        if isinstance(value, bool):
            bool_fields.append(f)
        elif (
            isinstance(value, (int, float))
            and value >= 0
            and not any(f.endswith(s) for s in _ID_SUFFIXES)
        ):
            num_fields.append(f)

    if not bool_fields and not num_fields:
        return None, None, [], None

    sort_fields = [f"{f}:desc" for f in bool_fields + num_fields]
    primary_bool = bool_fields[0] if bool_fields else None

    from .boost_strategies import build as build_boost

    boost_fn = build_boost(strategy, bool_fields, num_fields, list(samples))

    return sort_fields, boost_fn, num_fields, primary_bool
