"""Essabu Trade / CRM module."""
