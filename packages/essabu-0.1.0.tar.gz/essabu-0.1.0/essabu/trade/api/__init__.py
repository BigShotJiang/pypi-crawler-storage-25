"""Trade API resources."""
