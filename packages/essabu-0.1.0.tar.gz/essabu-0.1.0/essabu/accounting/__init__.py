"""Essabu Accounting module."""
