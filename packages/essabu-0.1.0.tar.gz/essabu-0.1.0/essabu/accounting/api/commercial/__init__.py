"""Accounting commercial API resources."""
