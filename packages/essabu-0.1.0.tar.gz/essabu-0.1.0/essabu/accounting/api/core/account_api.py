"""API for accounts in the accounting module."""

from __future__ import annotations

from typing import Any, Generator

from essabu.common.models import PageResponse
from essabu.accounting.api.base import BaseAccountingApi


class AccountApi(BaseAccountingApi):
    """CRUD operations for accounts."""

    def list(self, *, page: int = 1, page_size: int = 25, **filters: Any) -> PageResponse:
        """List accounts with pagination."""
        return self._list(self._path("accounts"), page=page, page_size=page_size, params=filters or None)

    def list_all(self, *, page_size: int = 25, **filters: Any) -> Generator[PageResponse, None, None]:
        """Iterate over all pages of accounts."""
        return self._list_all(self._path("accounts"), page_size=page_size, params=filters or None)

    def create(self, **data: Any) -> dict[str, Any]:
        """Create a new account."""
        return self._create(self._path("accounts"), data)

    def retrieve(self, resource_id: str) -> dict[str, Any]:
        """Retrieve a account by ID."""
        return self._retrieve(self._path("accounts", resource_id))

    def update(self, resource_id: str, **data: Any) -> dict[str, Any]:
        """Update a account."""
        return self._update(self._path("accounts", resource_id), data)

    def delete(self, resource_id: str) -> dict[str, Any]:
        """Delete a account."""
        return self._delete(self._path("accounts", resource_id))
