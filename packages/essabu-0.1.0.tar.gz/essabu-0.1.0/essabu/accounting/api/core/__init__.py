"""Accounting core API resources."""
