"""Accounting inventory API resources."""
