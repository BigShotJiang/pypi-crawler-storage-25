"""Accounting API resources."""
