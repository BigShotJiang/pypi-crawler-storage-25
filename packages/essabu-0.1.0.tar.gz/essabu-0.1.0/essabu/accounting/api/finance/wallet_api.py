"""API for wallets in the accounting module."""

from __future__ import annotations

from typing import Any, Generator

from essabu.common.models import PageResponse
from essabu.accounting.api.base import BaseAccountingApi


class WalletApi(BaseAccountingApi):
    """CRUD operations for wallets."""

    def list(self, *, page: int = 1, page_size: int = 25, **filters: Any) -> PageResponse:
        """List wallets with pagination."""
        return self._list(self._path("wallets"), page=page, page_size=page_size, params=filters or None)

    def list_all(self, *, page_size: int = 25, **filters: Any) -> Generator[PageResponse, None, None]:
        """Iterate over all pages of wallets."""
        return self._list_all(self._path("wallets"), page_size=page_size, params=filters or None)

    def create(self, **data: Any) -> dict[str, Any]:
        """Create a new wallet."""
        return self._create(self._path("wallets"), data)

    def retrieve(self, resource_id: str) -> dict[str, Any]:
        """Retrieve a wallet by ID."""
        return self._retrieve(self._path("wallets", resource_id))

    def update(self, resource_id: str, **data: Any) -> dict[str, Any]:
        """Update a wallet."""
        return self._update(self._path("wallets", resource_id), data)

    def delete(self, resource_id: str) -> dict[str, Any]:
        """Delete a wallet."""
        return self._delete(self._path("wallets", resource_id))
