"""E-Invoice API resources."""
