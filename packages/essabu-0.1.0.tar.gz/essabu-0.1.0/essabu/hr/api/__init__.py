"""HR API resources."""
