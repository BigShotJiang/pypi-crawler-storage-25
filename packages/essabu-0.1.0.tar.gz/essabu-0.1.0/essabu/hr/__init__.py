"""Essabu HR module."""
