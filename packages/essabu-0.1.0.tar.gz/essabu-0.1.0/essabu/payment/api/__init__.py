"""Payment API resources."""
