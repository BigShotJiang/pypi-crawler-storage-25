"""Essabu Project module."""
