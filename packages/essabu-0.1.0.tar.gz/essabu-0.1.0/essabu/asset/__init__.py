"""Essabu Asset module."""
