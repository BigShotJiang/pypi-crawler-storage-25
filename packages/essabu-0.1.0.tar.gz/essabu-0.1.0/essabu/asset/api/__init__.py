"""Asset API resources."""
