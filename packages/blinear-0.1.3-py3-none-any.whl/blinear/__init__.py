from .model import BilinearLayer

Bilinear = BilinearLayer

__all__ = [
    "BilinearLayer",
    "Bilinear"
]