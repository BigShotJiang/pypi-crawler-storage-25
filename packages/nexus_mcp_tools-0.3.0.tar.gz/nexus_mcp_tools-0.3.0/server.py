"""Nexus Tools MCP Server - API Tester, Git Hub, and DB Toolkit."""

from typing import Any, Optional

from fastmcp import FastMCP

from shared.errors import NexusToolsError
from tools.api_tester.client import ApiClient
from tools.api_tester.runner import CollectionRunner
from tools.api_tester.validator import ResponseValidator
from tools.db_toolkit.connector import DbConnector
from tools.db_toolkit.inspector import DbInspector
from tools.db_toolkit.migrator import MigrationRunner
from tools.git_hub.branch import BranchManager
from tools.git_hub.commit import CommitManager
from tools.git_hub.pr import PRCreator
from tools.security_scanner.secret_scanner import SecretScanner
from tools.security_scanner.dep_checker import DepChecker
from tools.security_scanner.sa_scanner import SAScanner
from tools.container_mgr.compose import ComposeManager
from tools.container_mgr.health import HealthChecker
from tools.container_mgr.logs import LogManager
from tools.profiler.runner import CodeProfiler
from tools.profiler.memory import MemoryProfiler
from tools.profiler.comparator import ProfileComparator
from tools.test_gen.generator import TestGenerator
from tools.test_gen.runner import TestRunner
from tools.test_gen.coverage import CoverageAnalyzer
from tools.file_toolkit.search import FileSearcher
from tools.file_toolkit.operations import FileOperations
from tools.file_toolkit.replace import FileReplacer
from tools.env_inspector.system import SystemInspector
from tools.code_reviewer.analyzer import CodeAnalyzer
from tools.code_reviewer.dependencies import DependencyAnalyzer
from tools.code_reviewer.metrics import CodeMetrics
from tools.knowledge_base.store import KnowledgeStore
from tools.memory.project_memory import ProjectMemory
from tools.memory.session import SessionTracker
from tools.memory.context_log import ContextLog
from tools.memory.file_tracker import FileChangeTracker
from tools.data_converter.converter import DataConverter

from tools.network_tools.network import NetworkChecker

from tools.process_manager.process import ProcessManager

from tools.excel_toolkit.excel import ExcelToolkit

from tools.crypto_tools.crypto import CryptoToolkit
from tools.agentic_tools import docker_adv as _docker_adv
from tools.agentic_tools import package_mgr as _package_mgr
from tools.agentic_tools import graphql as _graphql
from tools.agentic_tools import cloud as _cloud
from tools import rag_tools as _rag
from tools import desktop_tools as _desktop
from tools import template_engine as _template
mcp = FastMCP("nexus-tools")


@mcp.tool()
def api_request(
    method: str,
    url: str,
    headers: Optional[dict] = None,
    body: Optional[Any] = None,
    timeout: Optional[int] = None,
) -> dict:
    """Make an HTTP request and return the response.

    Args:
        method: HTTP method (GET, POST, PUT, DELETE, etc.)
        url: Target URL
        headers: Optional HTTP headers as dict
        body: Optional request body
        timeout: Optional timeout in seconds

    Returns:
        Dict with status_code, headers, body, duration_ms
    """
    try:
        client = ApiClient(timeout=timeout)
        result = client.request(method, url, headers, body)
        client.close()
        return result
    except NexusToolsError as e:
        return {"error": e.message, "success": False}
    except Exception as e:
        return {"error": str(e), "success": False}


@mcp.tool()
def api_validate(response: dict, schema: Optional[dict] = None) -> dict:
    """Validate an API response against a schema.

    Args:
        response: The API response dict
        schema: Optional schema dict with expected fields

    Returns:
        Dict with valid, errors, missing_fields, extra_fields
    """
    try:
        validator = ResponseValidator()
        return validator.validate(response, schema)
    except Exception as e:
        return {"valid": False, "errors": [str(e)]}


@mcp.tool()
def api_run_collection(collection: dict) -> dict:
    """Run a collection of API requests sequentially.

    Args:
        collection: Dict with requests list and optional variables

    Returns:
        Dict with results list and summary
    """
    try:
        runner = CollectionRunner()
        result = runner.run(collection)
        runner.close()
        return result
    except NexusToolsError as e:
        return {"error": e.message, "success": False}
    except Exception as e:
        return {"error": str(e), "success": False}


@mcp.tool()
def git_status(repo_path: str) -> dict:
    """Get Git status for a repository.

    Args:
        repo_path: Path to the Git repository

    Returns:
        Dict with clean, branch, staged, modified, untracked
    """
    try:
        manager = CommitManager()
        return manager.status(repo_path)
    except NexusToolsError as e:
        return {"error": e.message, "success": False}
    except Exception as e:
        return {"error": str(e), "success": False}


@mcp.tool()
def git_commit(repo_path: str, message: Optional[str] = None, staged_only: bool = True) -> dict:
    """Create a Git commit.

    Args:
        repo_path: Path to the Git repository
        message: Optional commit message
        staged_only: If True, only commit staged changes

    Returns:
        Dict with success, commit_hash, message, files
    """
    try:
        manager = CommitManager()
        return manager.auto_commit(repo_path, message, staged_only)
    except NexusToolsError as e:
        return {"error": e.message, "success": False}
    except Exception as e:
        return {"error": str(e), "success": False}


@mcp.tool()
def git_create_branch(repo_path: str, name: str, base: Optional[str] = None) -> dict:
    """Create a new Git branch.

    Args:
        repo_path: Path to the Git repository
        name: Name of the new branch
        base: Optional base branch to create from

    Returns:
        Dict with success, name, base
    """
    try:
        manager = BranchManager()
        return manager.create(repo_path, name, base)
    except NexusToolsError as e:
        return {"error": e.message, "success": False}
    except Exception as e:
        return {"error": str(e), "success": False}


@mcp.tool()
def git_delete_branch(repo_path: str, name: str, force: bool = False) -> dict:
    """Delete a Git branch.

    Args:
        repo_path: Path to the Git repository
        name: Name of the branch to delete
        force: Force deletion even if not merged

    Returns:
        Dict with success, name
    """
    try:
        manager = BranchManager()
        return manager.delete(repo_path, name, force)
    except NexusToolsError as e:
        return {"error": e.message, "success": False}
    except Exception as e:
        return {"error": str(e), "success": False}


@mcp.tool()
def git_create_pr(
    repo_path: str,
    title: str,
    body: Optional[str] = None,
    base: Optional[str] = None,
    head: Optional[str] = None,
) -> dict:
    """Create a GitHub Pull Request.

    Args:
        repo_path: Path to the Git repository
        title: PR title
        body: Optional PR body/description
        base: Optional base branch
        head: Optional head branch

    Returns:
        Dict with success, title, base, head, url
    """
    try:
        creator = PRCreator()
        return creator.create(repo_path, title, body, base, head)
    except NexusToolsError as e:
        return {"error": e.message, "success": False}
    except Exception as e:
        return {"error": str(e), "success": False}


@mcp.tool()
def db_execute(connection: str, sql: str, params: Optional[dict] = None) -> dict:
    """Execute a SQL statement.

    Args:
        connection: Database connection string
        sql: SQL statement to execute
        params: Optional parameters for the query

    Returns:
        Dict with success, rowcount, rows (if applicable)
    """
    try:
        connector = DbConnector()
        connector.connect(connection)
        result = connector.execute(sql, params)
        connector.close()
        return result
    except NexusToolsError as e:
        return {"error": e.message, "success": False}
    except Exception as e:
        return {"error": str(e), "success": False}


@mcp.tool()
def db_list_tables(connection: str) -> dict:
    """List all tables in the database.

    Args:
        connection: Database connection string

    Returns:
        Dict with tables list and count
    """
    try:
        inspector = DbInspector()
        return inspector.list_tables(connection)
    except NexusToolsError as e:
        return {"error": e.message, "success": False}
    except Exception as e:
        return {"error": str(e), "success": False}


@mcp.tool()
def db_describe_table(connection: str, table: str) -> dict:
    """Describe a table's schema.

    Args:
        connection: Database connection string
        table: Table name

    Returns:
        Dict with table, columns, primary_keys, foreign_keys
    """
    try:
        inspector = DbInspector()
        return inspector.describe_table(connection, table)
    except NexusToolsError as e:
        return {"error": e.message, "success": False}
    except Exception as e:
        return {"error": str(e), "success": False}


@mcp.tool()
def db_run_migrations(connection: str, migration_dir: str) -> dict:
    """Run pending database migrations.

    Args:
        connection: Database connection string
        migration_dir: Directory containing migration files

    Returns:
        Dict with success, applied list, count
    """
    try:
        runner = MigrationRunner()
        return runner.run_migrations(connection, migration_dir)
    except NexusToolsError as e:
        return {"error": e.message, "success": False}
    except Exception as e:
        return {"error": str(e), "success": False}


# Security Scanner Tools

@mcp.tool()
def security_scan_secrets(path: str) -> dict:
    """Scan files for hardcoded secrets and API keys.

    Args:
        path: Path to scan (file or directory)

    Returns:
        Dict with findings, total_files, total_findings
    """
    try:
        scanner = SecretScanner()
        return scanner.scan_path(path)
    except Exception as e:
        return {"error": str(e), "findings": [], "total_files": 0, "total_findings": 0}


@mcp.tool()
def security_check_deps(path: str, dep_type: str = "all") -> dict:
    """Check dependencies for vulnerabilities.

    Args:
        path: Path to scan (directory with package files)
        dep_type: Type of dependencies - 'pip', 'npm', or 'all'

    Returns:
        Dict with vulnerabilities, unversioned, total
    """
    try:
        checker = DepChecker()
        if dep_type == "pip":
            return checker.check_pip(path)
        elif dep_type == "npm":
            return checker.check_npm(path)
        else:
            return checker.check_all(path)
    except Exception as e:
        return {"error": str(e), "vulnerabilities": [], "total": 0}


@mcp.tool()
def security_scan_code(path: str) -> dict:
    """Scan Python files for security issues using AST analysis.

    Args:
        path: Path to scan (file or directory)

    Returns:
        Dict with findings, total_files, total_findings
    """
    try:
        scanner = SAScanner()
        return scanner.scan_directory(path)
    except Exception as e:
        return {"error": str(e), "findings": [], "total_files": 0, "total_findings": 0}


# Container Manager Tools

@mcp.tool()
def container_up(compose_file: str, service: Optional[str] = None, detach: bool = True) -> dict:
    """Start Docker Compose services.

    Args:
        compose_file: Path to docker-compose.yml file
        service: Optional specific service to start
        detach: Run in detached mode

    Returns:
        Dict with success, output, error
    """
    try:
        manager = ComposeManager()
        return manager.up(compose_file, service, detach)
    except Exception as e:
        return {"success": False, "output": "", "error": str(e)}


@mcp.tool()
def container_down(compose_file: str, remove_volumes: bool = False) -> dict:
    """Stop and remove Docker Compose services.

    Args:
        compose_file: Path to docker-compose.yml file
        remove_volumes: Also remove volumes

    Returns:
        Dict with success, output, error
    """
    try:
        manager = ComposeManager()
        return manager.down(compose_file, remove_volumes)
    except Exception as e:
        return {"success": False, "output": "", "error": str(e)}


@mcp.tool()
def container_ps(compose_file: str) -> dict:
    """List Docker Compose services with status.

    Args:
        compose_file: Path to docker-compose.yml file

    Returns:
        Dict with services, error
    """
    try:
        manager = ComposeManager()
        return manager.ps(compose_file)
    except Exception as e:
        return {"services": [], "error": str(e)}


@mcp.tool()
def container_restart(compose_file: str, service: Optional[str] = None) -> dict:
    """Restart Docker Compose services.

    Args:
        compose_file: Path to docker-compose.yml file
        service: Optional specific service to restart

    Returns:
        Dict with success, output, error
    """
    try:
        manager = ComposeManager()
        return manager.restart(compose_file, service)
    except Exception as e:
        return {"success": False, "output": "", "error": str(e)}


@mcp.tool()
def container_check(name: str) -> dict:
    """Check container health status.

    Args:
        name: Container name or ID

    Returns:
        Dict with health, running, error
    """
    try:
        checker = HealthChecker()
        return checker.check_container(name)
    except Exception as e:
        return {"exists": False, "error": str(e)}


@mcp.tool()
def container_stats(name: str) -> dict:
    """Get container resource usage stats.

    Args:
        name: Container name or ID

    Returns:
        Dict with CPU, memory, network stats
    """
    try:
        checker = HealthChecker()
        return checker.stats(name)
    except Exception as e:
        return {"error": str(e)}


@mcp.tool()
def container_logs(service: str, lines: int = 100, pattern: Optional[str] = None, since: Optional[str] = None) -> dict:
    """Get or search container logs.

    Args:
        service: Container name or ID
        lines: Number of lines to retrieve (for tail mode)
        pattern: Optional search pattern (for search mode)
        since: Optional time filter (e.g., "10m", "1h")

    Returns:
        Dict with service, logs, count, error
    """
    try:
        manager = LogManager()
        if pattern:
            return manager.search(service, pattern, since)
        else:
            return manager.tail(service, lines, follow=False)
    except Exception as e:
        return {"service": service, "logs": [], "count": 0, "error": str(e)}


# Agentic Dev Tools - Docker Advanced

@mcp.tool()
def docker_compose_ps(
    compose_file: Optional[str] = None,
    project_name: Optional[str] = None,
) -> dict:
    """List services status in a Docker Compose project.

    Args:
        compose_file: Path to docker-compose.yml (optional)
        project_name: Optional project name filter

    Returns:
        Dict with success flag and service status list
    """
    return _docker_adv.compose_ps(compose_file, project_name)


@mcp.tool()
def docker_compose_logs(
    compose_file: Optional[str] = None,
    service: Optional[str] = None,
    lines: int = 50,
    follow: bool = False,
    tail: bool = True,
) -> dict:
    """Fetch logs from Docker Compose services.

    Args:
        compose_file: Path to docker-compose.yml
        service: Specific service name (optional)
        lines: Number of recent lines (default 50)
        follow: Stream new log lines
        tail: Show tail end of logs

    Returns:
        Dict with log lines
    """
    return _docker_adv.compose_logs(compose_file, service, lines, follow, tail)


@mcp.tool()
def docker_image_inspect(image_ref: str) -> dict:
    """Inspect a Docker image with full metadata.

    Args:
        image_ref: Image name and tag (e.g. 'python:3.12-slim')

    Returns:
        Dict with image metadata (id, size, layers, env, ports, etc.)
    """
    return _docker_adv.image_inspect(image_ref)


@mcp.tool()
def docker_container_exec(
    container_id: str,
    command: str,
    workdir: Optional[str] = None,
    interactive: bool = False,
    env: Optional[list[str]] = None,
) -> dict:
    """Execute a command inside a running container.

    Args:
        container_id: Container name or ID
        command: Command to run (e.g. 'ls -la /app')
        workdir: Working directory inside container
        interactive: Allocate pseudo-TTY
        env: Environment variables (list of 'KEY=VALUE' strings)

    Returns:
        Dict with stdout, stderr, exit code
    """
    return _docker_adv.container_exec(container_id, command, workdir, interactive, env)


@mcp.tool()
def docker_prune(all_resources: bool = False, volumes: bool = False, force: bool = False) -> dict:
    """Clean up unused Docker resources.

    Args:
        all_resources: Prune all unused objects (not just dangling)
        volumes: Also prune unused volumes
        force: Skip confirmation prompt

    Returns:
        Dict with freed space details per resource type
    """
    return _docker_adv.docker_prune(all_resources, volumes, force)


@mcp.tool()
def docker_network_inspect(network_name: str) -> dict:
    """Inspect a Docker network with connected containers.

    Args:
        network_name: Network name or ID

    Returns:
        Dict with network config, driver, subnet, containers
    """
    return _docker_adv.network_inspect(network_name)


@mcp.tool()
def docker_volume_ls(dangling_only: bool = False, driver: Optional[str] = None) -> dict:
    """List Docker volumes with size and mount info.

    Args:
        dangling_only: Show only dangling (unused) volumes
        driver: Filter by driver (e.g. 'local')

    Returns:
        Dict with volumes list and summary
    """
    return _docker_adv.volume_ls(dangling_only, driver)


# Agentic Dev Tools - Package Manager

@mcp.tool()
def pip_list(show_latest: bool = False) -> dict:
    """List installed Python packages.

    Args:
        show_latest: Also check latest available version from PyPI

    Returns:
        Dict with packages list, count, and optional latest versions
    """
    return _package_mgr.pip_list(show_latest)


@mcp.tool()
def pip_show(package: str) -> dict:
    """Show details for an installed Python package.

    Args:
        package: Package name

    Returns:
        Dict with package metadata (version, requires, summary)
    """
    return _package_mgr.pip_show(package)


@mcp.tool()
def npm_list(depth: int = 0, production: bool = False) -> dict:
    """List installed npm packages.

    Args:
        depth: Dependency tree depth (0 = direct deps only)
        production: Show only production dependencies

    Returns:
        Dict with dependency tree and count
    """
    return _package_mgr.npm_list(depth, production)


@mcp.tool()
def npm_outdated() -> dict:
    """List outdated npm packages.

    Returns:
        Dict with outdated packages (current vs wanted vs latest)
    """
    return _package_mgr.npm_outdated()


@mcp.tool()
def uv_deps() -> dict:
    """List dependencies from uv.lock or pyproject.toml using uv.

    Returns:
        Dict with dependency tree lines
    """
    return _package_mgr.uv_deps()


# Agentic Dev Tools - GraphQL

@mcp.tool()
def graphql_query(url: str, query: str, variables: Optional[str] = None, operation_name: Optional[str] = None) -> dict:
    """Execute a GraphQL query or mutation.

    Args:
        url: GraphQL endpoint URL
        query: GraphQL query/mutation string
        variables: Optional JSON string of variables
        operation_name: Optional operation name

    Returns:
        Dict with data, errors, success
    """
    return _graphql.graphql_query(url, query, variables, operation_name)


@mcp.tool()
def graphql_introspect(url: str) -> dict:
    """Introspect a GraphQL endpoint for schema details.

    Args:
        url: GraphQL endpoint URL

    Returns:
        Dict with schema types, queries, mutations
    """
    return _graphql.graphql_introspect(url)


@mcp.tool()
def graphql_schema_dump(url: str) -> dict:
    """Dump full GraphQL schema with type definitions.

    Args:
        url: GraphQL endpoint URL

    Returns:
        Dict with all types and fields
    """
    return _graphql.graphql_schema_dump(url)


@mcp.tool()
def graphql_validate(url: str, query: str) -> dict:
    """Validate a GraphQL query against a schema.

    Args:
        url: GraphQL endpoint URL
        query: GraphQL query to validate

    Returns:
        Dict with valid flag and errors
    """
    return _graphql.graphql_validate(url, query)


# Agentic Dev Tools - Cloud CLI Wrappers

@mcp.tool()
def aws_s3_ls(path: str = "s3://", recursive: bool = False) -> dict:
    """List AWS S3 buckets or objects.

    Args:
        path: S3 path ('s3://' for buckets, 's3://bucket/path' for objects)
        recursive: List recursively

    Returns:
        Dict with listing and count
    """
    return _cloud.aws_s3_ls(path, recursive)


@mcp.tool()
def aws_lambda_list() -> dict:
    """List AWS Lambda functions.

    Returns:
        Dict with function list (name, runtime, memory, timeout)
    """
    return _cloud.aws_lambda_list()


@mcp.tool()
def aws_ec2_ls() -> dict:
    """List AWS EC2 instances with state info.

    Returns:
        Dict with instances (id, state, type, IPs, launch time)
    """
    return _cloud.aws_ec2_ls()


@mcp.tool()
def gcp_storage_ls(path: str = "gs://") -> dict:
    """List GCS buckets or objects.

    Args:
        path: GCS path ('gs://' for buckets, 'gs://bucket/path' for objects)

    Returns:
        Dict with listing and count
    """
    return _cloud.gcp_storage_ls(path)


@mcp.tool()
def gcp_compute_ls() -> dict:
    """List GCE compute instances.

    Returns:
        Dict with instances (name, zone, type, status, IPs)
    """
    return _cloud.gcp_compute_ls()


@mcp.tool()
def gcp_run_ls() -> dict:
    """List Cloud Run services.

    Returns:
        Dict with services (name, region, url)
    """
    return _cloud.gcp_run_ls()


# AI / RAG Infrastructure

@mcp.tool()
def rag_chunk_text(
    text: str,
    chunk_size: int = 500,
    overlap: int = 50,
    method: str = "character",
) -> dict:
    """Split text into overlapping chunks for RAG.

    Args:
        text: Input text to chunk
        chunk_size: Target chunk size in characters (default: 500)
        overlap: Overlap between chunks (default: 50)
        method: 'character' or 'sentence' (default: 'character')

    Returns:
        Dict with chunks list, count, metadata
    """
    return _rag.chunk_text(text, chunk_size, overlap, method)


@mcp.tool()
def rag_ollama_embed(text: str, model: str = "nomic-embed-text") -> dict:
    """Generate text embeddings using local Ollama.

    Args:
        text: Text to embed
        model: Ollama model name (default: nomic-embed-text)

    Returns:
        Dict with embedding vector, dimensions, model
    """
    return _rag.ollama_embed(text, model)


@mcp.tool()
def rag_ollama_models() -> dict:
    """List available Ollama models.

    Returns:
        Dict with models list (name, size, modified)
    """
    return _rag.ollama_models_list()


@mcp.tool()
def rag_vector_create(index_name: str, model: str = "nomic-embed-text") -> dict:
    """Create a new vector index for storing embeddings.

    Args:
        index_name: Name for the index
        model: Embedding model to use

    Returns:
        Dict with index info
    """
    return _rag.vector_store_create(index_name, model)


@mcp.tool()
def rag_vector_add(
    index_name: str,
    documents: list[str],
    embed_model: str = "nomic-embed-text",
) -> dict:
    """Embed documents and add them to a vector index.

    Args:
        index_name: Name of the index
        documents: List of text documents to add
        embed_model: Ollama embedding model

    Returns:
        Dict with added count and index stats
    """
    return _rag.vector_store_add(index_name, documents, embed_model)


@mcp.tool()
def rag_vector_search(
    index_name: str,
    query: str,
    top_k: int = 5,
    embed_model: str = "nomic-embed-text",
) -> dict:
    """Search a vector index by cosine similarity.

    Args:
        index_name: Name of the index
        query: Search query text
        top_k: Number of top results (default: 5)
        embed_model: Ollama embedding model

    Returns:
        Dict with ranked results (text + score)
    """
    return _rag.vector_store_search(index_name, query, top_k, embed_model)


@mcp.tool()
def rag_vector_list() -> dict:
    """List all vector indexes.

    Returns:
        Dict with indexes list and info
    """
    return _rag.vector_store_list()


@mcp.tool()
def rag_vector_delete(index_name: str) -> dict:
    """Delete a vector index.

    Args:
        index_name: Name of the index

    Returns:
        Dict with success/error
    """
    return _rag.vector_store_delete(index_name)


@mcp.tool()
def rag_retrieve(
    text: str,
    query: str,
    chunk_size: int = 500,
    chunk_overlap: int = 50,
    top_k: int = 3,
    embed_model: str = "nomic-embed-text",
    index_name: Optional[str] = None,
) -> dict:
    """End-to-end RAG retrieve: chunk text, embed, search by similarity.

    Args:
        text: Source text to index
        query: Question to answer from the text
        chunk_size: Character chunk size (default: 500)
        chunk_overlap: Overlap between chunks (default: 50)
        top_k: Number of relevant chunks (default: 3)
        embed_model: Ollama embedding model (default: nomic-embed-text)
        index_name: Optional existing index name

    Returns:
        Dict with ranked relevant chunks
    """
    return _rag.rag_retrieve(text, query, chunk_size, chunk_overlap, top_k, embed_model, index_name)


# Profiler Tools

@mcp.tool()
def profile_execute(code: str, timeout: int = 30) -> dict:
    """Execute Python code and profile its performance with cProfile.

    Args:
        code: Python code string to execute
        timeout: Maximum execution time in seconds (default: 30)

    Returns:
        Dict with success, stdout, stderr, duration_ms, ncalls, tottime,
        cumtime, error
    """
    try:
        profiler = CodeProfiler()
        return profiler.profile_execute(code, timeout)
    except Exception as e:
        return {"error": str(e), "success": False}


@mcp.tool()
def profile_memory(code: str) -> dict:
    """Profile memory usage of Python code using tracemalloc.

    Args:
        code: Python code string to execute

    Returns:
        Dict with success, peak_memory_kb, current_memory_kb, top_lines, error
    """
    try:
        profiler = MemoryProfiler()
        return profiler.profile_memory(code)
    except Exception as e:
        return {"error": str(e), "success": False}


@mcp.tool()
def profile_compare(before: dict, after: dict) -> dict:
    """Compare two profiling results to identify performance changes.

    Args:
        before: First profiling result dict
        after: Second profiling result dict

    Returns:
        Dict with changes list and summary
    """
    try:
        comparator = ProfileComparator()
        return comparator.profile_compare(before, after)
    except Exception as e:
        return {"error": str(e), "changes": [], "summary": {}}


# Test Generator Tools

@mcp.tool()
def test_generate(source_path: str) -> dict:
    """Generate pytest tests from a Python source file using AST analysis.

    Args:
        source_path: Path to the Python source file

    Returns:
        Dict with test_path, test_code, tests_count, functions_found,
        classes_found, error
    """
    try:
        generator = TestGenerator()
        return generator.test_generate(source_path)
    except Exception as e:
        return {"error": str(e), "test_path": "", "test_code": "", "tests_count": 0}


@mcp.tool()
def test_run(path: str, verbose: bool = False) -> dict:
    """Run pytest tests on a file or directory.

    Args:
        path: Path to test file or directory
        verbose: Enable verbose output (default: False)

    Returns:
        Dict with success, passed, failed, errors, skipped, total,
        duration_ms, results, error
    """
    try:
        runner = TestRunner()
        return runner.test_run(path, verbose)
    except Exception as e:
        return {"error": str(e), "success": False}


@mcp.tool()
def test_coverage(path: str) -> dict:
    """Run coverage analysis on Python code using coverage.py.

    Args:
        path: Path to Python file or directory

    Returns:
        Dict with files, total_statements, total_missing,
        total_coverage_pct, error
    """
    try:
        analyzer = CoverageAnalyzer()
        return analyzer.test_coverage(path)
    except Exception as e:
        return {"error": str(e), "files": [], "total_statements": 0}


@mcp.tool()
def test_profile_function(func_str: str, args: Optional[list] = None, kwargs: Optional[dict] = None) -> dict:
    """Profile a function by its string definition.

    Args:
        func_str: Python function definition as string
        args: Optional positional arguments to call the function with
        kwargs: Optional keyword arguments to call the function with

    Returns:
        Dict with profiling statistics including total_calls, total_tottime,
        total_cumtime, top_functions, error
    """
    try:
        profiler = CodeProfiler()
        return profiler.profile_function(func_str, args, kwargs)
    except Exception as e:
        return {"error": str(e), "success": False}


# File Toolkit Tools

@mcp.tool()
def file_search(
    path: str,
    pattern: str,
    regex: bool = False,
    include: str = "*.py",
    max_results: int = 100,
) -> dict:
    """Search file contents using fnmatch or regex.

    Args:
        path: Directory path to search in
        pattern: Search pattern (string or regex if regex=True)
        regex: If True, treat pattern as regex; otherwise use fnmatch
        include: Glob pattern for files to include (default: "*.py")
        max_results: Maximum number of results to return

    Returns:
        Dict with results list, total_matches, files_scanned
    """
    try:
        searcher = FileSearcher()
        return searcher.search_files(path, pattern, regex, include, max_results)
    except Exception as e:
        return {"error": str(e), "results": [], "total_matches": 0, "files_scanned": 0}


@mcp.tool()
def file_find(
    path: str,
    glob_pattern: str,
    max_depth: int = 10,
) -> dict:
    """Find files by glob pattern.

    Args:
        path: Directory path to search in
        glob_pattern: Glob pattern to match (e.g., "**/*.py")
        max_depth: Maximum directory depth to search

    Returns:
        Dict with files list and total_count
    """
    try:
        searcher = FileSearcher()
        return searcher.find_files(path, glob_pattern, max_depth)
    except Exception as e:
        return {"error": str(e), "files": [], "total_count": 0}


@mcp.tool()
def file_batch_rename(
    directory: str,
    pattern: str,
    replacement: str,
    dry_run: bool = True,
) -> dict:
    """Rename files matching a pattern.

    Args:
        directory: Directory containing files to rename
        pattern: Pattern to match in filenames (supports fnmatch wildcards)
        replacement: Replacement string for matched files
        dry_run: If True, only show what would be renamed; if False, actually rename

    Returns:
        Dict with renamed list, dry_run status, total count
    """
    try:
        ops = FileOperations()
        return ops.batch_rename(directory, pattern, replacement, dry_run)
    except Exception as e:
        return {"error": str(e), "renamed": [], "dry_run": dry_run, "total": 0}


@mcp.tool()
def file_compare(path_a: str, path_b: str) -> dict:
    """Compare two files using difflib.

    Args:
        path_a: Path to first file
        path_b: Path to second file

    Returns:
        Dict with same boolean, diff list, total_diffs count
    """
    try:
        ops = FileOperations()
        return ops.compare_files(path_a, path_b)
    except Exception as e:
        return {"error": str(e), "same": False, "diff": [], "total_diffs": 0}


@mcp.tool()
def file_info(path: str) -> dict:
    """Get file or directory metadata.

    Args:
        path: Path to file or directory

    Returns:
        Dict with exists, type, size_bytes, modified_at, created_at,
        permissions, extension
    """
    try:
        ops = FileOperations()
        return ops.file_info(path)
    except Exception as e:
        return {"exists": False, "error": str(e)}


@mcp.tool()
def file_search_replace(
    path: str,
    search: str,
    replacement: str,
    regex: bool = False,
    dry_run: bool = True,
) -> dict:
    """Find and replace text in a file.

    Args:
        path: File path to perform search and replace on
        search: Text to search for (string or regex if regex=True)
        replacement: Replacement text
        regex: If True, treat search as regex; otherwise use literal string
        dry_run: If True, only show what would be replaced; if False, actually replace

    Returns:
        Dict with files_changed list, total_replacements, dry_run status
    """
    try:
        replacer = FileReplacer()
        return replacer.search_replace(path, search, replacement, regex, dry_run)
    except Exception as e:
        return {"error": str(e), "files_changed": [], "total_replacements": 0, "dry_run": dry_run}


# Environment Inspector Tools

@mcp.tool()
def env_info() -> dict:
    """Get environment information including Python version, platform, CPU, RAM, and PATH.

    Returns:
        Dict with python_version, platform, cpu_count, path_entries, cwd,
        env_vars (filtered to common patterns), and optional ram info
    """
    try:
        inspector = SystemInspector()
        return inspector.env_check()
    except Exception as e:
        return {"error": str(e)}


@mcp.tool()
def env_has_tools(tools: list[str]) -> dict:
    """Check if specific CLI tools exist on the system.

    Args:
        tools: List of tool names to check (e.g., ["git", "npm", "python"])

    Returns:
        Dict with tools list containing name, found boolean, path;
        also returns all_found boolean
    """
    try:
        inspector = SystemInspector()
        return inspector.env_has_tools(tools)
    except Exception as e:
        return {"error": str(e), "tools": [], "all_found": False}


# Code Reviewer Tools

@mcp.tool()
def review_code(path: str) -> dict:
    """Perform comprehensive static analysis of Python code.

    Args:
        path: Path to a Python file or directory

    Returns:
        Dict with files, issues, summary, and overall_score
    """
    try:
        analyzer = CodeAnalyzer()
        return analyzer.review_code(path)
    except Exception as e:
        return {"error": str(e), "files": [], "summary": {}, "overall_score": 0}


@mcp.tool()
def review_dependencies(path: str) -> dict:
    """Analyze import graph of a Python project.

    Args:
        path: Path to a Python file or directory

    Returns:
        Dict with files, imports, circular, unused, and summary
    """
    try:
        analyzer = DependencyAnalyzer()
        return analyzer.review_dependencies(path)
    except Exception as e:
        return {"error": str(e), "files": [], "circular": [], "unused": [], "summary": {}}


@mcp.tool()
def review_metrics(path: str) -> dict:
    """Calculate code metrics for Python files.

    Args:
        path: Path to a Python file or directory

    Returns:
        Dict with files, metrics, and summary
    """
    try:
        metrics = CodeMetrics()
        return metrics.review_metrics(path)
    except Exception as e:
        return {"error": str(e), "files": [], "summary": {}}


# Knowledge Base Tools

@mcp.tool()
def kb_set(key: str, value: str, namespace: str = "default") -> dict:
    """Save a knowledge item to the knowledge base.

    Args:
        key: The key to store
        value: The value to store
        namespace: The namespace for the key (default: "default")

    Returns:
        Dict with success, key, namespace
    """
    try:
        store = KnowledgeStore()
        return store.kb_set(key, value, namespace)
    except Exception as e:
        return {"success": False, "error": str(e), "key": key, "namespace": namespace}


@mcp.tool()
def kb_get(key: str, namespace: str = "default") -> dict:
    """Retrieve a knowledge item from the knowledge base.

    Args:
        key: The key to retrieve
        namespace: The namespace to look in (default: "default")

    Returns:
        Dict with found, key, value, namespace, created_at, updated_at
    """
    try:
        store = KnowledgeStore()
        return store.kb_get(key, namespace)
    except Exception as e:
        return {"found": False, "error": str(e), "key": key, "namespace": namespace}


@mcp.tool()
def kb_search(query: str, namespace: Optional[str] = None) -> dict:
    """Search for knowledge items in the knowledge base.

    Args:
        query: Search query string
        namespace: Optional namespace to search in (None = all namespaces)

    Returns:
        Dict with results list and total count
    """
    try:
        store = KnowledgeStore()
        return store.kb_search(query, namespace)
    except Exception as e:
        return {"results": [], "total": 0, "error": str(e)}


@mcp.tool()
def kb_list(namespace: str = "default") -> dict:
    """List all keys in a namespace of the knowledge base.

    Args:
        namespace: The namespace to list (default: "default")

    Returns:
        Dict with namespace, items list, total count
    """
    try:
        store = KnowledgeStore()
        return store.kb_list(namespace)
    except Exception as e:
        return {"namespace": namespace, "items": [], "total": 0, "error": str(e)}


@mcp.tool()
def kb_delete(key: str, namespace: str = "default") -> dict:
    """Delete a knowledge item from the knowledge base.

    Args:
        key: The key to delete
        namespace: The namespace to delete from (default: "default")

    Returns:
        Dict with success, key, namespace
    """
    try:
        store = KnowledgeStore()
        return store.kb_delete(key, namespace)
    except Exception as e:
        return {"success": False, "error": str(e), "key": key, "namespace": namespace}


# Memory Manager Tools

@mcp.tool()
def memory_set(key: str, value: str, category: str = "general", project: Optional[str] = None) -> dict:
    """Save a memory to the project memory store.

    Args:
        key: The memory key
        value: The memory value
        category: The category to store under (default: "general")
        project: The project name (default: auto-detect from CWD)

    Returns:
        Dict with success, key, category, project
    """
    try:
        memory = ProjectMemory()
        return memory.memory_set(key, value, category, project)
    except Exception as e:
        return {"success": False, "error": str(e), "key": key, "category": category}


@mcp.tool()
def memory_get(key: str, category: Optional[str] = None, project: Optional[str] = None) -> dict:
    """Retrieve a memory by key from the project memory store.

    Args:
        key: The memory key to retrieve
        category: Optional category to search in (None = search all)
        project: The project name (default: auto-detect from CWD)

    Returns:
        Dict with found, key, value, category, project, created_at, updated_at
    """
    try:
        memory = ProjectMemory()
        return memory.memory_get(key, category, project)
    except Exception as e:
        return {"found": False, "error": str(e), "key": key}


@mcp.tool()
def memory_search(query: str, category: Optional[str] = None, project: Optional[str] = None) -> dict:
    """Search across keys and values in project memory.

    Args:
        query: Search query string
        category: Optional category to search in (None = search all)
        project: The project name (default: auto-detect from CWD)

    Returns:
        Dict with results list and total count
    """
    try:
        memory = ProjectMemory()
        return memory.memory_search(query, category, project)
    except Exception as e:
        return {"results": [], "total": 0, "error": str(e)}


@mcp.tool()
def memory_list(category: Optional[str] = None, project: Optional[str] = None) -> dict:
    """List memories in a category/project.

    Args:
        category: Optional category to list (None = all categories)
        project: The project name (default: auto-detect from CWD)

    Returns:
        Dict with items list and total count
    """
    try:
        memory = ProjectMemory()
        return memory.memory_list(category, project)
    except Exception as e:
        return {"items": [], "total": 0, "error": str(e)}


@mcp.tool()
def memory_forget(key: str, category: Optional[str] = None, project: Optional[str] = None) -> dict:
    """Delete a memory from the project memory store.

    Args:
        key: The memory key to delete
        category: Optional category to delete from (None = search all)
        project: The project name (default: auto-detect from CWD)

    Returns:
        Dict with success, key
    """
    try:
        memory = ProjectMemory()
        return memory.memory_forget(key, category, project)
    except Exception as e:
        return {"success": False, "error": str(e), "key": key}


@mcp.tool()
def memory_categories(project: Optional[str] = None) -> dict:
    """List all categories in project memory.

    Args:
        project: The project name (default: auto-detect from CWD)

    Returns:
        Dict with categories list and total count
    """
    try:
        memory = ProjectMemory()
        return memory.memory_categories(project)
    except Exception as e:
        return {"categories": [], "total": 0, "error": str(e)}


@mcp.tool()
def session_start(name: Optional[str] = None, tags: Optional[list] = None, project: Optional[str] = None) -> dict:
    """Start a new session for tracking activities.

    Args:
        name: Optional session name
        tags: Optional list of tags for the session
        project: Optional project name (default: auto-detect from CWD)

    Returns:
        Dict with session_id, name, start_time
    """
    try:
        tracker = SessionTracker()
        return tracker.session_start(name, tags, project)
    except Exception as e:
        return {"error": str(e), "session_id": None, "name": None, "start_time": None}


@mcp.tool()
def session_event(session_id: str, event_type: str, data: Optional[dict] = None) -> dict:
    """Log an event to a session.

    Args:
        session_id: The session ID
        event_type: Type of event (e.g., "file_created", "tool_called", "test_run", "build")
        data: Optional event data

    Returns:
        Dict with success, session_id, event_count
    """
    try:
        tracker = SessionTracker()
        return tracker.session_event(session_id, event_type, data)
    except Exception as e:
        return {"success": False, "error": str(e), "session_id": session_id}


@mcp.tool()
def session_state_set(session_id: str, key: str, value: str) -> dict:
    """Set a session state variable.

    Args:
        session_id: The session ID
        key: State variable key
        value: State variable value

    Returns:
        Dict with success, key, value
    """
    try:
        tracker = SessionTracker()
        return tracker.session_state_set(session_id, key, value)
    except Exception as e:
        return {"success": False, "error": str(e), "session_id": session_id}


@mcp.tool()
def session_state_get(session_id: str, key: Optional[str] = None) -> dict:
    """Get session state (specific key or all).

    Args:
        session_id: The session ID
        key: Optional specific key to retrieve

    Returns:
        Dict with found, key, value (if key provided) or state dict
    """
    try:
        tracker = SessionTracker()
        return tracker.session_state_get(session_id, key)
    except Exception as e:
        return {"found": False, "error": str(e), "session_id": session_id}


@mcp.tool()
def session_summary(session_id: str) -> dict:
    """Get full session summary.

    Args:
        session_id: The session ID

    Returns:
        Dict with session_id, name, duration_seconds, project, tags,
        state, events_by_type, event_count, closed
    """
    try:
        tracker = SessionTracker()
        return tracker.session_summary(session_id)
    except Exception as e:
        return {"error": str(e), "session_id": session_id}


@mcp.tool()
def session_list(limit: int = 10, project: Optional[str] = None) -> dict:
    """List recent sessions (closed or open).

    Args:
        limit: Maximum number of sessions to return (default: 10)
        project: Optional project filter

    Returns:
        Dict with sessions list and total count
    """
    try:
        tracker = SessionTracker()
        return tracker.session_list(limit, project)
    except Exception as e:
        return {"sessions": [], "total": 0, "error": str(e)}


@mcp.tool()
def session_close(session_id: str) -> dict:
    """End a session.

    Args:
        session_id: The session ID

    Returns:
        Dict with success, session_id, duration_seconds, event_count
    """
    try:
        tracker = SessionTracker()
        return tracker.session_close(session_id)
    except Exception as e:
        return {"success": False, "error": str(e), "session_id": session_id}


@mcp.tool()
def context_log(
    session_id: str,
    tool: str,
    input_summary: str,
    output_summary: str,
    status: str = "success",
) -> dict:
    """Log a tool call to the context log.

    Args:
        session_id: The session ID
        tool: Tool name
        input_summary: Summary of input
        output_summary: Summary of output
        status: Status of the call (default: "success")

    Returns:
        Dict with success, entry_id
    """
    try:
        logger = ContextLog()
        return logger.context_log(session_id, tool, input_summary, output_summary, status)
    except Exception as e:
        return {"success": False, "error": str(e), "entry_id": None}


@mcp.tool()
def context_recent(session_id: str, limit: int = 10) -> dict:
    """Get recent context entries.

    Args:
        session_id: The session ID
        limit: Maximum number of entries to return (default: 10)

    Returns:
        Dict with entries list and total count
    """
    try:
        logger = ContextLog()
        return logger.context_recent(session_id, limit)
    except Exception as e:
        return {"entries": [], "total": 0, "error": str(e)}


@mcp.tool()
def context_search(
    session_id: str,
    tool: Optional[str] = None,
    query: Optional[str] = None,
    status: Optional[str] = None,
) -> dict:
    """Search context log by tool name and/or text in summaries.

    Args:
        session_id: The session ID
        tool: Optional tool name filter
        query: Optional search query
        status: Optional status filter

    Returns:
        Dict with entries list and total count
    """
    try:
        logger = ContextLog()
        return logger.context_search(session_id, tool, query, status)
    except Exception as e:
        return {"entries": [], "total": 0, "error": str(e)}


@mcp.tool()
def context_stats(session_id: str) -> dict:
    """Get context log stats.

    Args:
        session_id: The session ID

    Returns:
        Dict with total_entries, by_tool, by_status, time_span_seconds
    """
    try:
        logger = ContextLog()
        return logger.context_stats(session_id)
    except Exception as e:
        return {
            "total_entries": 0,
            "by_tool": {},
            "by_status": {},
            "time_span_seconds": 0,
            "error": str(e),
        }


@mcp.tool()
def track_start(session_id: str, directory: str) -> dict:
    """Start tracking a directory for file changes.

    Args:
        session_id: The session ID
        directory: Directory path to track

    Returns:
        Dict with success, session_id, directory, files_count
    """
    try:
        tracker = FileChangeTracker()
        return tracker.track_start(session_id, directory)
    except Exception as e:
        return {"success": False, "error": str(e), "session_id": session_id}


@mcp.tool()
def track_changes(session_id: str) -> dict:
    """Compare current state with baseline snapshot.

    Args:
        session_id: The session ID

    Returns:
        Dict with created, modified, deleted, unchanged_count, total_changes
    """
    try:
        tracker = FileChangeTracker()
        return tracker.track_changes(session_id)
    except Exception as e:
        return {
            "created": [],
            "modified": [],
            "deleted": [],
            "unchanged_count": 0,
            "total_changes": 0,
            "error": str(e),
        }


@mcp.tool()
def track_stop(session_id: str) -> dict:
    """Stop tracking, remove snapshot.

    Args:
        session_id: The session ID

    Returns:
        Dict with success, session_id
    """
    try:
        tracker = FileChangeTracker()
        return tracker.track_stop(session_id)
    except Exception as e:
        return {"success": False, "error": str(e), "session_id": session_id}


# Data Converter Tools

@mcp.tool()
def convert_parse_json(text: str) -> dict:
    """Parse a JSON string into a Python structure.

    Args:
        text: JSON string to parse

    Returns:
        Dict with parsed data, type, or error with line/col
    """
    try:
        converter = DataConverter()
        return converter.parse_json(text)
    except Exception as e:
        return {"success": False, "error": str(e)}


@mcp.tool()
def convert_parse_yaml(text: str) -> dict:
    """Parse a YAML string into a Python structure.

    Args:
        text: YAML string to parse

    Returns:
        Dict with parsed data, type, or error
    """
    try:
        converter = DataConverter()
        return converter.parse_yaml(text)
    except Exception as e:
        return {"success": False, "error": str(e)}


@mcp.tool()
def convert_to_json(
    data: str,
    indent: int = 2,
    sort_keys: bool = False,
) -> dict:
    """Convert a string (parsed as JSON-safe literal) to a formatted JSON string.

    Args:
        data: Input string to convert (will be parsed as JSON then re-serialized)
        indent: Indentation level (default: 2, 0 for compact, None for no whitespace)
        sort_keys: Sort object keys alphabetically

    Returns:
        Dict with json_string and length
    """
    try:
        converter = DataConverter()
        try:
            parsed = __import__("json").loads(data)
        except Exception:
            parsed = data
        return converter.to_json(parsed, indent, sort_keys)
    except Exception as e:
        return {"success": False, "error": str(e)}


@mcp.tool()
def convert_to_yaml(
    data: str,
    flow_style: bool = False,
    sort_keys: bool = False,
) -> dict:
    """Convert a string (parsed as JSON-safe literal) to a formatted YAML string.

    Args:
        data: Input string to convert (will be parsed as JSON then converted)
        flow_style: Use YAML flow style (inline) if True
        sort_keys: Sort object keys alphabetically

    Returns:
        Dict with yaml_string and length
    """
    try:
        converter = DataConverter()
        try:
            parsed = __import__("json").loads(data)
        except Exception:
            parsed = data
        default_flow_style = flow_style or None
        return converter.to_yaml(parsed, default_flow_style, sort_keys)
    except Exception as e:
        return {"success": False, "error": str(e)}


@mcp.tool()
def convert_json_to_yaml(json_text: str) -> dict:
    """Convert JSON to YAML.

    Args:
        json_text: JSON string

    Returns:
        Dict with yaml_string or error
    """
    try:
        converter = DataConverter()
        return converter.json_to_yaml(json_text)
    except Exception as e:
        return {"success": False, "error": str(e)}


@mcp.tool()
def convert_yaml_to_json(yaml_text: str, indent: int = 2) -> dict:
    """Convert YAML to JSON.

    Args:
        yaml_text: YAML string
        indent: JSON indentation spaces

    Returns:
        Dict with json_string or error
    """
    try:
        converter = DataConverter()
        return converter.yaml_to_json(yaml_text, indent)
    except Exception as e:
        return {"success": False, "error": str(e)}


@mcp.tool()
def convert_parse_csv(text: str, delimiter: str = ",") -> dict:
    """Parse a CSV string into structured rows.

    Args:
        text: CSV string
        delimiter: Field delimiter (default: ',')

    Returns:
        Dict with headers, rows, total_rows
    """
    try:
        converter = DataConverter()
        return converter.parse_csv(text, delimiter)
    except Exception as e:
        return {"success": False, "error": str(e)}


@mcp.tool()
def convert_to_csv(headers: list, rows: list) -> dict:
    """Create a CSV string from headers and row data.

    Args:
        headers: List of column header strings
        rows: List of row lists (each row is a list of cell values)

    Returns:
        Dict with csv_string and length
    """
    try:
        converter = DataConverter()
        return converter.to_csv(headers, rows)
    except Exception as e:
        return {"success": False, "error": str(e)}


@mcp.tool()
def convert_validate_schema(instance: str, schema: str) -> dict:
    """Validate a JSON string against a JSON Schema.

    Args:
        instance: JSON instance string to validate
        schema: JSON Schema string

    Returns:
        Dict with valid boolean and errors list
    """
    try:
        converter = DataConverter()
        return converter.validate_json_schema(instance, schema)
    except Exception as e:
        return {"valid": False, "errors": [{"message": str(e)}], "error_count": 1}


# Network Tools

@mcp.tool()
def network_dns_lookup(hostname: str, record_type: str = "A") -> dict:
    """Perform a DNS lookup for a hostname.

    Args:
        hostname: Hostname to resolve
        record_type: Record type (A, AAAA, MX, CNAME, NS, TXT)

    Returns:
        Dict with resolved records list, count, ttl, duration_ms
    """
    try:
        checker = NetworkChecker()
        return checker.dns_lookup(hostname, record_type)
    except Exception as e:
        return {"success": False, "error": str(e), "hostname": hostname}


@mcp.tool()
def network_port_check(host: str, port: int, timeout: float = 3.0) -> dict:
    """Check if a TCP port is open on a host.

    Args:
        host: Hostname or IP
        port: TCP port number
        timeout: Connection timeout in seconds

    Returns:
        Dict with open boolean, host, port, duration_ms
    """
    try:
        checker = NetworkChecker()
        return checker.port_check(host, port, timeout)
    except Exception as e:
        return {"host": host, "port": port, "open": False, "error": str(e)}


@mcp.tool()
def network_http_check(url: str, method: str = "HEAD", timeout: float = 10.0) -> dict:
    """Perform an HTTP health check against a URL.

    Args:
        url: Full URL
        method: HTTP method (default: HEAD)
        timeout: Request timeout

    Returns:
        Dict with status_code, duration_ms, content info
    """
    try:
        checker = NetworkChecker()
        return checker.http_check(url, method, timeout)
    except Exception as e:
        return {"success": False, "error": str(e), "url": url}


@mcp.tool()
def network_ssl_info(hostname: str, port: int = 443, timeout: float = 5.0) -> dict:
    """Get SSL/TLS certificate information for a host.

    Args:
        hostname: Server hostname
        port: Port (default: 443)
        timeout: Connection timeout

    Returns:
        Dict with certificate details, issuer, expiry
    """
    try:
        checker = NetworkChecker()
        return checker.ssl_info(hostname, port, timeout)
    except Exception as e:
        return {"success": False, "error": str(e), "hostname": hostname}


@mcp.tool()
def network_whois(query: str) -> dict:
    """Perform a whois lookup for a domain or IP.

    Args:
        query: Domain name or IP address

    Returns:
        Dict with whois information
    """
    try:
        checker = NetworkChecker()
        return checker.whois_lookup(query)
    except Exception as e:
        return {"success": False, "error": str(e), "query": query}


@mcp.tool()
def network_my_ip() -> dict:
    """Look up the public IP address and location info via ip-api.com.

    Returns:
        Dict with ip, location, ISP info
    """
    try:
        checker = NetworkChecker()
        return checker.ip_info()
    except Exception as e:
        return {"success": False, "error": str(e)}


@mcp.tool()
def network_trace(hostname: str, max_hops: int = 15, timeout: float = 3.0) -> dict:
    """Run a traceroute simulation towards a host.

    Args:
        hostname: Target hostname
        max_hops: Maximum hop count (default: 15)
        timeout: Per-hop timeout in seconds

    Returns:
        Dict with hops list showing each routing step
    """
    try:
        checker = NetworkChecker()
        return checker.trace_route(hostname, max_hops, timeout)
    except Exception as e:
        return {"success": False, "error": str(e), "hostname": hostname}


# --- Process Manager (Phase 8a) ---


@mcp.tool()
def ps_list(name_filter: str | None = None, user_filter: str | None = None,
            sort_by: str = "cpu", limit: int = 50) -> list[dict]:
    """List running processes with optional filters.

    Args:
        name_filter: Optional process name substring filter
        user_filter: Optional username filter
        sort_by: Sort field (cpu, memory, pid, name, user)
        limit: Max results (default 50)

    Returns:
        List of process dicts with pid, name, cpu, memory, status
    """
    try:
        mgr = ProcessManager()
        return mgr.list_processes(name_filter, user_filter, sort_by, limit)
    except Exception as e:
        return [{"error": str(e)}]


@mcp.tool()
def ps_find(port: int | None = None, name: str | None = None) -> list[dict]:
    """Find processes by port or name.

    Args:
        port: Find processes listening on this port
        name: Find processes with this name (substring match)

    Returns:
        List of matching process dicts
    """
    try:
        mgr = ProcessManager()
        if port is not None:
            return mgr.find_process_by_port(port)
        if name:
            return mgr.list_processes(name_filter=name, sort_by="name", limit=20)
        return []
    except Exception as e:
        return [{"error": str(e)}]


@mcp.tool()
def ps_info(pid: int) -> dict:
    """Get detailed information about a specific process.

    Args:
        pid: Process ID

    Returns:
        Dict with process details (exe, cwd, memory, threads, etc.)
    """
    try:
        mgr = ProcessManager()
        return mgr.process_info(pid)
    except Exception as e:
        return {"found": False, "pid": pid, "error": str(e)}


@mcp.tool()
def ps_kill(pid: int, force: bool = False) -> dict:
    """Terminate or kill a process.

    Args:
        pid: Process ID to terminate
        force: If True, use SIGKILL; otherwise SIGTERM

    Returns:
        Dict with success status
    """
    try:
        mgr = ProcessManager()
        return mgr.kill_process(pid, force)
    except Exception as e:
        return {"success": False, "error": str(e)}


@mcp.tool()
def ps_tree(root_pid: int | None = None) -> dict:
    """Display the process tree structure.

    Args:
        root_pid: Optional root PID to scope the tree

    Returns:
        Dict with hierarchical process tree
    """
    try:
        mgr = ProcessManager()
        return mgr.process_tree(root_pid)
    except Exception as e:
        return {"success": False, "error": str(e)}


@mcp.tool()
def ps_system_stats() -> dict:
    """Get overall system resource statistics.

    Returns:
        Dict with CPU, memory, disk, network stats, uptime
    """
    try:
        mgr = ProcessManager()
        return mgr.system_stats()
    except Exception as e:
        return {"success": False, "error": str(e)}


@mcp.tool()
def ps_ports() -> list[dict]:
    """List all listening TCP/UDP ports with their owning processes.

    Returns:
        List of port/process entries sorted by port number
    """
    try:
        mgr = ProcessManager()
        return mgr.listening_ports()
    except Exception as e:
        return [{"error": str(e)}]


# --- Excel Toolkit (Phase 8b) ---


@mcp.tool()
def excel_sheets(filepath: str) -> dict:
    """List all sheets in an Excel workbook.

    Args:
        filepath: Path to .xlsx file

    Returns:
        Dict with sheet list and dimensions
    """
    try:
        et = ExcelToolkit()
        return et.sheets(filepath)
    except Exception as e:
        return {"success": False, "error": str(e)}


@mcp.tool()
def excel_read(filepath: str, sheet_name: str | None = None,
               header_row: bool = True, max_rows: int | None = None) -> dict:
    """Read data from an Excel sheet as structured rows.

    Args:
        filepath: Path to .xlsx file
        sheet_name: Sheet name (default: first sheet)
        header_row: If True, first row becomes column headers
        max_rows: Max data rows to read

    Returns:
        Dict with headers, rows, and metadata
    """
    try:
        et = ExcelToolkit()
        return et.read_sheet(filepath, sheet_name, header_row, max_rows)
    except Exception as e:
        return {"success": False, "error": str(e)}


@mcp.tool()
def excel_write(filepath: str, sheet_name: str = "Sheet1",
                headers: list[str] | None = None,
                rows: list[list[str]] | None = None,
                mode: str = "new") -> dict:
    """Write data to an Excel file.

    Args:
        filepath: Output .xlsx path
        sheet_name: Sheet title
        headers: Column headers (optional)
        rows: Data rows as list of string lists
        mode: 'new' creates file, 'append' adds sheet to existing

    Returns:
        Dict with write results
    """
    try:
        et = ExcelToolkit()
        return et.write_sheet(filepath, sheet_name, headers, rows, mode)
    except Exception as e:
        return {"success": False, "error": str(e)}


@mcp.tool()
def excel_merge(filepaths: list[str], output_path: str) -> dict:
    """Merge multiple Excel files into one workbook.

    Args:
        filepaths: List of .xlsx file paths
        output_path: Output .xlsx path

    Returns:
        Dict with merge results
    """
    try:
        et = ExcelToolkit()
        return et.merge_files(filepaths, output_path)
    except Exception as e:
        return {"success": False, "error": str(e)}


@mcp.tool()
def excel_csv_to_xlsx(csv_path: str, xlsx_path: str,
                      sheet_name: str = "Sheet1", delimiter: str = ",") -> dict:
    """Convert a CSV file to Excel format.

    Args:
        csv_path: Input CSV path
        xlsx_path: Output .xlsx path
        sheet_name: Sheet name
        delimiter: CSV delimiter

    Returns:
        Dict with conversion result
    """
    try:
        et = ExcelToolkit()
        return et.csv_to_xlsx(csv_path, xlsx_path, sheet_name, delimiter)
    except Exception as e:
        return {"success": False, "error": str(e)}


@mcp.tool()
def excel_xlsx_to_csv(xlsx_path: str, csv_path: str,
                      sheet_name: str | None = None, delimiter: str = ",") -> dict:
    """Convert an Excel sheet to CSV format.

    Args:
        xlsx_path: Input .xlsx path
        csv_path: Output CSV path
        sheet_name: Sheet to convert (default: first)
        delimiter: CSV delimiter

    Returns:
        Dict with conversion result
    """
    try:
        et = ExcelToolkit()
        return et.xlsx_to_csv(xlsx_path, csv_path, sheet_name, delimiter)
    except Exception as e:
        return {"success": False, "error": str(e)}


# --- Crypto / Hash Tools (Phase 8c) ---


@mcp.tool()
def crypto_hash(text: str, algorithm: str = "sha256", encoding: str = "hex") -> dict:
    """Compute a hash of text using MD5, SHA1, SHA256, SHA384, or SHA512.

    Args:
        text: Input text to hash
        algorithm: Hash algorithm (md5, sha1, sha256, sha384, sha512)
        encoding: Output encoding ('hex' or 'base64')

    Returns:
        Dict with hash result
    """
    try:
        ct = CryptoToolkit()
        return ct.hash_text(text, algorithm, encoding)
    except Exception as e:
        return {"success": False, "error": str(e)}


@mcp.tool()
def crypto_hash_file(filepath: str, algorithm: str = "sha256") -> dict:
    """Compute a file hash using MD5, SHA1, SHA256, SHA384, or SHA512.

    Args:
        filepath: Path to the file
        algorithm: Hash algorithm

    Returns:
        Dict with hash and file metadata
    """
    try:
        ct = CryptoToolkit()
        return ct.hash_file(filepath, algorithm)
    except Exception as e:
        return {"success": False, "error": str(e)}


@mcp.tool()
def crypto_base64_encode(data: str) -> dict:
    """Encode a string to base64.

    Args:
        data: String to encode

    Returns:
        Dict with encoded result
    """
    try:
        ct = CryptoToolkit()
        return ct.base64_encode(data)
    except Exception as e:
        return {"success": False, "error": str(e)}


@mcp.tool()
def crypto_base64_decode(data: str) -> dict:
    """Decode a base64-encoded string.

    Args:
        data: Base64-encoded string

    Returns:
        Dict with decoded result
    """
    try:
        ct = CryptoToolkit()
        return ct.base64_decode(data)
    except Exception as e:
        return {"success": False, "error": str(e)}


@mcp.tool()
def crypto_uuid(version: int = 4, count: int = 1) -> dict:
    """Generate one or more UUIDs.

    Args:
        version: UUID version (4=random, 7=time-ordered)
        count: Number of UUIDs (1-100)

    Returns:
        Dict with list of UUIDs
    """
    try:
        ct = CryptoToolkit()
        return ct.generate_uuid(version, count)
    except Exception as e:
        return {"success": False, "error": str(e)}


@mcp.tool()
def crypto_hmac(key: str, message: str, algorithm: str = "sha256",
                encoding: str = "hex") -> dict:
    """Create an HMAC signature for a message.

    Args:
        key: Secret key
        message: Message to sign
        algorithm: Hash algorithm (sha1, sha256, sha384, sha512)
        encoding: Output encoding ('hex' or 'base64')

    Returns:
        Dict with HMAC signature
    """
    try:
        ct = CryptoToolkit()
        return ct.hmac_sign(key, message, algorithm, encoding)
    except Exception as e:
        return {"success": False, "error": str(e)}


@mcp.tool()
def crypto_random(length: int = 32, output_format: str = "hex") -> dict:
    """Generate cryptographically secure random bytes.

    Args:
        length: Number of bytes (1-4096)
        output_format: 'hex', 'base64', or 'raw'

    Returns:
        Dict with random data
    """
    try:
        ct = CryptoToolkit()
        return ct.random_bytes(length, output_format)
    except Exception as e:
        return {"success": False, "error": str(e)}


# Template Engine  (Jinja2)

@mcp.tool()
def template_render(template: str,
                    context: dict | None = None) -> dict:
    """Render a Jinja2 template string with context variables.

    Undefined variables render as empty strings (safe mode).

    Args:
        template: Jinja2 template text
        context: Dict of variable name -> value

    Returns:
        Dict with rendered text and length
    """
    return _template.template_render(template, context)


@mcp.tool()
def template_render_file(path: str,
                         context: dict | None = None) -> dict:
    """Read a file as a Jinja2 template and render it.

    Args:
        path: Path to template file
        context: Dict of variable name -> value

    Returns:
        Dict with rendered text or error
    """
    return _template.template_render_file(path, context)


@mcp.tool()
def template_validate(template: str) -> dict:
    """Validate Jinja2 template syntax without rendering.

    Args:
        template: Jinja2 template text

    Returns:
        Dict with valid: bool and optional error details
    """
    return _template.template_validate(template)


@mcp.tool()
def template_list_vars(template: str) -> dict:
    """Extract variable names referenced in a Jinja2 template.

    Args:
        template: Jinja2 template text

    Returns:
        Dict with sorted variables list and count
    """
    return _template.template_list_vars(template)


# Desktop / Background Tools  (Phase 9e)

@mcp.tool()
def fs_watch_start(path: str, pattern: str = "*",
                   name: str | None = None) -> dict:
    """Start monitoring a directory for file changes.

    Takes an initial snapshot. Use fs_watch_poll to detect
    added/modified/removed files since last poll.

    Args:
        path: Directory to monitor
        pattern: Glob pattern to filter files (default: *)
        name: Optional watch name (defaults to directory name)

    Returns:
        Dict with watch_id, path, entries_snapped count
    """
    return _desktop.fs_watch_start(path, pattern, name)


@mcp.tool()
def fs_watch_poll(watch_id: str) -> dict:
    """Poll a watch for file changes since last snapshot.

    Returns added, removed, and modified files. Updates the
    stored snapshot after each poll.

    Args:
        watch_id: Watch identifier from fs_watch_start

    Returns:
        Dict with diff (added, removed, modified lists)
    """
    return _desktop.fs_watch_poll(watch_id)


@mcp.tool()
def fs_watch_stop(watch_id: str) -> dict:
    """Stop monitoring and delete the watch state.

    Args:
        watch_id: Watch identifier from fs_watch_start

    Returns:
        Dict confirming deletion
    """
    return _desktop.fs_watch_stop(watch_id)


@mcp.tool()
def fs_watch_list() -> dict:
    """List all active file watches with metadata.

    Returns:
        Dict with watches list and count
    """
    return _desktop.fs_watch_list()


@mcp.tool()
def clipboard_get() -> dict:
    """Get current clipboard text content.

    Windows only (uses PowerShell). Returns text and length.

    Returns:
        Dict with text content and length
    """
    return _desktop.clipboard_get()


@mcp.tool()
def clipboard_set(text: str) -> dict:
    """Set clipboard text content.

    Args:
        text: Text to set on clipboard

    Returns:
        Dict confirming write
    """
    return _desktop.clipboard_set(text)


@mcp.tool()
def clipboard_history(limit: int = 10) -> dict:
    """Show clipboard history entries.

    Entries accumulate from previous clipboard_get calls.
    Call clipboard_get first to snapshot current state.

    Args:
        limit: Max entries to return (default: 10)

    Returns:
        Dict with entries list and total count
    """
    return _desktop.clipboard_history(limit)


@mcp.tool()
def task_schedule(name: str, interval_seconds: float,
                  description: str) -> dict:
    """Schedule a recurring task.

    Task fires every `interval_seconds`. Use task_check()
    to see which tasks are due.

    Args:
        name: Unique task name
        interval_seconds: Repeat interval
        description: Human-readable task description

    Returns:
        Dict confirming schedule
    """
    return _desktop.task_schedule(name, interval_seconds, description)


@mcp.tool()
def task_delayed(name: str, seconds: float, description: str) -> dict:
    """Schedule a one-shot task after a delay.

    Use task_check() to see when it fires.

    Args:
        name: Unique task name
        seconds: Delay before firing
        description: Human-readable task description

    Returns:
        Dict confirming delayed schedule
    """
    return _desktop.task_delayed(name, seconds, description)


@mcp.tool()
def task_cancel(name: str) -> dict:
    """Cancel a scheduled task by name.

    Args:
        name: Task name to cancel

    Returns:
        Dict confirming cancellation
    """
    return _desktop.task_cancel(name)


@mcp.tool()
def task_check() -> dict:
    """Check which scheduled tasks are due.

    Returns due tasks list. Completed one-shot tasks are
    automatically removed. Recurring tasks get their
    next_run_at advanced.

    Returns:
        Dict with due_tasks list and count
    """
    return _desktop.task_check()


def main_entry():
    """Entry point for 'nexus-tools' CLI command (uvx / pipx)."""
    print("Starting Nexus Tools MCP Server...")
    mcp.run()


if __name__ == "__main__":
    main_entry()