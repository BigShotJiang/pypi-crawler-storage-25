"""Smoke test that exercises all 81+ MCP tools with safe defaults.

Runs without Docker, real databases, external URLs, or destructive side effects.
Tests are organized by domain matching the NEXUS TOOLS architecture.
"""

import hashlib
import sys
import textwrap
from pathlib import Path

import pytest

# Add project root to path
PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))
sys.path.insert(0, str(PROJECT_ROOT / "tools"))

TOOLS_DIR = PROJECT_ROOT / "tools"
FIXTURE_PY = TOOLS_DIR / "tests" / "fixture_module.py"


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def tmp_project(tmp_path):
    """Create a temp directory that simulates a project."""
    (tmp_path / "src").mkdir()
    (tmp_path / "src" / "__init__.py").write_text("# package\n")
    (tmp_path / "src" / "greeter.py").write_text(textwrap.dedent("""\
        def greet(name: str) -> str:
            return f"Hello, {name}!"

        def add(a: int, b: int) -> int:
            return a + b

        class Calculator:
            def multiply(self, x: int, y: int) -> int:
                return x * y
    """))
    (tmp_path / "tests").mkdir()
    return tmp_path


@pytest.fixture
def sample_file(tmp_path):
    """A small text file for file-toolkit tests."""
    f = tmp_path / "sample.txt"
    f.write_text("hello world\nline two\nline three\n")
    return str(f)


# ===========================================================================
# Phase 1: API Tester
# ===========================================================================

class TestApiTester:
    def test_api_request_invalid_url(self):
        """Call api_request with an unreachable URL — should not crash."""
        from server import api_request
        result = api_request("GET", "http://192.0.2.1:1/", timeout=1)
        assert isinstance(result, dict)
        # Should have either error or status_code
        assert "error" in result or "status_code" in result

    def test_api_validate_no_schema(self):
        """Validate a response without a schema — should return valid."""
        from server import api_validate
        result = api_validate({"status_code": 200, "body": "ok"})
        assert isinstance(result, dict)
        assert "valid" in result

    def test_api_validate_with_schema(self):
        from server import api_validate
        schema = {"expected_fields": ["status_code"]}
        result = api_validate({"status_code": 200}, schema)
        assert isinstance(result, dict)

    def test_api_run_collection_empty(self):
        from server import api_run_collection
        result = api_run_collection({"requests": []})
        assert isinstance(result, dict)
        assert "results" in result or "summary" in result or "error" in result


# ===========================================================================
# Phase 1: Git Hub
# ===========================================================================

class TestGitHub:
    def test_git_status_not_a_repo(self, tmp_path):
        from server import git_status
        result = git_status(str(tmp_path))
        assert isinstance(result, dict)
        # Either error (not a git repo) or success
        assert "error" in result or "branch" in result

    def test_git_commit_no_repo(self, tmp_path):
        from server import git_commit
        result = git_commit(str(tmp_path), staged_only=True)
        assert isinstance(result, dict)
        assert "error" in result or "success" in result

    def test_git_create_delete_branch(self, tmp_path):
        from server import git_create_branch, git_delete_branch
        # Create branch (will fail, not a repo)
        result = git_create_branch(str(tmp_path), "test-branch")
        assert isinstance(result, dict)
        # Delete branch
        result = git_delete_branch(str(tmp_path), "test-branch", force=True)
        assert isinstance(result, dict)

    def test_git_create_pr_no_remote(self):
        from server import git_create_pr
        # Use tools dir which IS a git repo but has no remote
        tools_dir = str(PROJECT_ROOT)
        result = git_create_pr(tools_dir, "Test PR", "Body")
        assert isinstance(result, dict)


# ===========================================================================
# Phase 1: DB Toolkit
# ===========================================================================

class TestDbToolkit:
    def test_db_execute_sqlite(self, tmp_path):
        """Create an in-memory SQLite DB and run a query."""
        from server import db_execute
        db_path = str(tmp_path / "test.db")
        conn_str = f"sqlite:///{db_path}"

        # Create table
        result = db_execute(conn_str, "CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, name TEXT)")
        assert isinstance(result, dict)
        assert "error" not in result, str(result)

        # Insert
        result = db_execute(conn_str, "INSERT INTO users (name) VALUES ('Alice')")
        assert isinstance(result, dict)

        # Select
        result = db_execute(conn_str, "SELECT * FROM users")
        assert isinstance(result, dict)

    def test_db_list_tables_sqlite(self, tmp_path):
        from server import db_list_tables
        db_path = str(tmp_path / "test2.db")
        conn_str = f"sqlite:///{db_path}"
        result = db_list_tables(conn_str)
        assert isinstance(result, dict)
        assert "error" not in result

    def test_db_describe_table_sqlite(self, tmp_path):
        from server import db_describe_table, db_execute
        db_path = str(tmp_path / "test3.db")
        conn_str = f"sqlite:///{db_path}"
        db_execute(conn_str, "CREATE TABLE IF NOT EXISTS items (id INTEGER PRIMARY KEY, label TEXT NOT NULL)")
        result = db_describe_table(conn_str, "items")
        assert isinstance(result, dict)
        assert "error" not in result

    def test_db_migrations(self, tmp_path):
        from server import db_run_migrations
        db_path = str(tmp_path / "mig.db")
        conn_str = f"sqlite:///{db_path}"
        mig_dir = tmp_path / "migrations"
        mig_dir.mkdir()
        (mig_dir / "001_init.sql").write_text("CREATE TABLE IF NOT EXISTS config (key TEXT, value TEXT);\n")
        result = db_run_migrations(conn_str, str(mig_dir))
        assert isinstance(result, dict)


# ===========================================================================
# Phase 2: Security Scanner
# ===========================================================================

class TestSecurityScanner:
    def test_scan_secrets_finds_nothing(self, tmp_path):
        from server import security_scan_secrets
        f = tmp_path / "clean.py"
        f.write_text("x = 1\ny = 2\n")
        result = security_scan_secrets(str(tmp_path))
        assert isinstance(result, dict)
        assert "findings" in result

    def test_scan_secrets_finds_pattern(self, tmp_path):
        from server import security_scan_secrets
        f = tmp_path / "leaky.py"
        f.write_text('api_key = "sk-1234567890abcdef"\n')
        result = security_scan_secrets(str(f))
        assert isinstance(result, dict)
        assert "error" not in result

    def test_check_deps_no_files(self, tmp_path):
        from server import security_check_deps
        result = security_check_deps(str(tmp_path))
        assert isinstance(result, dict)

    def test_scan_code(self, tmp_path):
        from server import security_scan_code
        f = tmp_path / "vuln.py"
        f.write_text('import os\ndef run(cmd):\n    os.system(cmd)\n')
        result = security_scan_code(str(tmp_path))
        assert isinstance(result, dict)
        assert "findings" in result


# ===========================================================================
# Phase 2: Container Manager
# ===========================================================================

class TestContainerMgr:
    def test_container_up_no_file(self, tmp_path):
        from server import container_up
        result = container_up(str(tmp_path / "nonexistent.yml"), detach=False)
        assert isinstance(result, dict)
        # Should error gracefully (no file)
        assert "error" in result or "success" in result

    def test_container_down_no_file(self, tmp_path):
        from server import container_down
        result = container_down(str(tmp_path / "nonexistent.yml"))
        assert isinstance(result, dict)
        assert "error" in result or "success" in result

    def test_container_ps_no_file(self, tmp_path):
        from server import container_ps
        result = container_ps(str(tmp_path / "nonexistent.yml"))
        assert isinstance(result, dict)

    def test_container_restart_no_file(self, tmp_path):
        from server import container_restart
        result = container_restart(str(tmp_path / "nonexistent.yml"))
        assert isinstance(result, dict)

    def test_container_check_nonexistent(self):
        from server import container_check
        result = container_check("nonexistent_container_xyz123")
        assert isinstance(result, dict)

    def test_container_stats_nonexistent(self):
        from server import container_stats
        result = container_stats("nonexistent_container_xyz123")
        assert isinstance(result, dict)

    def test_container_logs_nonexistent(self):
        from server import container_logs
        result = container_logs("nonexistent_container_xyz123", lines=10)
        assert isinstance(result, dict)
        assert "logs" in result


# ===========================================================================
# Phase 3: Profiler
# ===========================================================================

class TestProfiler:
    def test_profile_execute_simple(self):
        from server import profile_execute
        result = profile_execute("x = sum(range(100))")
        assert isinstance(result, dict)
        # Should succeed
        assert result.get("success", False) or "error" in result

    def test_profile_execute_error(self):
        from server import profile_execute
        result = profile_execute("1/0")
        assert isinstance(result, dict)

    def test_profile_memory_simple(self):
        from server import profile_memory
        result = profile_memory("x = [1, 2, 3]")
        assert isinstance(result, dict)
        assert "error" not in result or result.get("success", False)

    def test_profile_compare_empty(self):
        from server import profile_compare
        result = profile_compare({"ncalls": 10, "tottime": 0.1}, {"ncalls": 20, "tottime": 0.2})
        assert isinstance(result, dict)

    def test_profile_function_simple(self):
        from server import test_profile_function
        func_str = "def hello():\n    return 42"
        result = test_profile_function(func_str)
        assert isinstance(result, dict)


# ===========================================================================
# Phase 3: Test Generator
# ===========================================================================

class TestTestGen:
    def test_generate_from_source(self, tmp_project):
        from server import test_generate
        src = tmp_project / "src" / "greeter.py"
        result = test_generate(str(src))
        assert isinstance(result, dict)
        assert "error" not in result or result.get("tests_count", 0) >= 0

    def test_generate_nonexistent(self):
        from server import test_generate
        result = test_generate("/nonexistent/path.py")
        assert isinstance(result, dict)
        assert "error" in result

    def test_run_no_tests(self, tmp_path):
        from server import test_run
        result = test_run(str(tmp_path))
        assert isinstance(result, dict)

    def test_coverage_on_source(self, tmp_project):
        from server import test_coverage
        path = tmp_project / "src" / "greeter.py"
        result = test_coverage(str(path))
        assert isinstance(result, dict)


# ===========================================================================
# Phase 4: File Toolkit
# ===========================================================================

class TestFileToolkit:
    def test_file_search(self, tmp_project):
        from server import file_search
        result = file_search(str(tmp_project), "def ", include="*.py")
        assert isinstance(result, dict)
        assert "results" in result

    def test_file_find(self, tmp_project):
        from server import file_find
        result = file_find(str(tmp_project), "**/*.py")
        assert isinstance(result, dict)
        assert "files" in result

    def test_file_info_exists(self, sample_file):
        from server import file_info
        result = file_info(sample_file)
        assert isinstance(result, dict)
        assert result["exists"] is True
        assert result["type"] == "file"

    def test_file_info_nonexistent(self, tmp_path):
        from server import file_info
        result = file_info(str(tmp_path / "nope.txt"))
        assert isinstance(result, dict)
        assert result.get("exists") is False

    def test_file_batch_rename_dry_run(self, tmp_path):
        from server import file_batch_rename
        (tmp_path / "foo.txt").write_text("a")
        (tmp_path / "bar.txt").write_text("b")
        result = file_batch_rename(str(tmp_path), "*.txt", "*.bak", dry_run=True)
        assert isinstance(result, dict)
        assert result.get("dry_run") is True

    def test_file_compare_same(self, tmp_path):
        from server import file_compare
        f1 = tmp_path / "a.txt"
        f2 = tmp_path / "b.txt"
        f1.write_text("same content\n")
        f2.write_text("same content\n")
        result = file_compare(str(f1), str(f2))
        assert isinstance(result, dict)
        assert result.get("same") is True or "diff" in result

    def test_file_compare_diff(self, tmp_path):
        from server import file_compare
        f1 = tmp_path / "a.txt"
        f2 = tmp_path / "b.txt"
        f1.write_text("line one\n")
        f2.write_text("line two\n")
        result = file_compare(str(f1), str(f2))
        assert isinstance(result, dict)

    def test_file_search_replace_dry_run(self, sample_file):
        from server import file_search_replace
        result = file_search_replace(sample_file, "hello", "goodbye", dry_run=True)
        assert isinstance(result, dict)
        assert result.get("dry_run") is True


# ===========================================================================
# Phase 4: Environment Inspector
# ===========================================================================

class TestEnvInspector:
    def test_env_info(self):
        from server import env_info
        result = env_info()
        assert isinstance(result, dict)
        assert "python_version" in result or "platform" in result or "error" in result

    def test_env_has_tools(self):
        from server import env_has_tools
        result = env_has_tools(["python", "nonexistent_tool_xyz"])
        assert isinstance(result, dict)
        assert "tools" in result
        # python should be found
        python_found = any(t["name"] == "python" and t["found"] for t in result["tools"])
        nonexistent_found = any(t["name"] == "nonexistent_tool_xyz" and t["found"] for t in result["tools"])
        assert python_found is True  # python should always be findable
        assert nonexistent_found is False  # fake tool should not be found


# ===========================================================================
# Phase 5: Code Reviewer
# ===========================================================================

class TestCodeReviewer:
    def test_review_code(self, tmp_project):
        from server import review_code
        result = review_code(str(tmp_project / "src" / "greeter.py"))
        assert isinstance(result, dict)
        assert "error" not in result or "issues" in result or "summary" in result

    def test_review_dependencies(self, tmp_project):
        from server import review_dependencies
        result = review_dependencies(str(tmp_project / "src" / "greeter.py"))
        assert isinstance(result, dict)

    def test_review_metrics(self, tmp_project):
        from server import review_metrics
        result = review_metrics(str(tmp_project / "src"))
        assert isinstance(result, dict)


# ===========================================================================
# Phase 5: Knowledge Base
# ===========================================================================

class TestKnowledgeBase:
    def test_kb_set_get(self):
        from server import kb_set, kb_get, kb_delete
        key = "_test_key_smoke_"
        # Set
        result = kb_set(key, "test_value")
        assert isinstance(result, dict)
        assert result.get("success") is True or "error" in result
        if result.get("success"):
            # Get
            result = kb_get(key)
            assert isinstance(result, dict)
            assert result.get("found") is True
            assert result.get("value") == "test_value"
            # Delete
            result = kb_delete(key)
            assert isinstance(result, dict)

    def test_kb_get_not_found(self):
        from server import kb_get
        result = kb_get("_nonexistent_key_xyz_")
        assert isinstance(result, dict)
        assert result.get("found") is False

    def test_kb_search(self):
        from server import kb_search, kb_set, kb_delete
        key = "_test_search_smoke_"
        kb_set(key, "searchable content")
        result = kb_search("searchable")
        assert isinstance(result, dict)
        assert "results" in result
        kb_delete(key)

    def test_kb_list(self):
        from server import kb_list
        result = kb_list("default")
        assert isinstance(result, dict)
        assert "items" in result or "namespace" in result


# ===========================================================================
# Phase 6: Project Memory
# ===========================================================================

class TestProjectMemory:
    def test_memory_set_get(self):
        from server import memory_set, memory_get, memory_forget
        key = "_test_mem_smoke_"
        result = memory_set(key, "mem_value")
        assert isinstance(result, dict)
        if result.get("success"):
            result = memory_get(key)
            assert isinstance(result, dict)
            assert result.get("found") is True
            assert result.get("value") == "mem_value"
            memory_forget(key)

    def test_memory_get_not_found(self):
        from server import memory_get
        result = memory_get("_nonexistent_key_xyz_")
        assert isinstance(result, dict)
        assert result.get("found") is False

    def test_memory_search(self):
        from server import memory_set, memory_search, memory_forget
        key = "_test_search_smoke_"
        memory_set(key, "findable value")
        result = memory_search("findable")
        assert isinstance(result, dict)
        assert "results" in result
        memory_forget(key)

    def test_memory_list(self):
        from server import memory_list
        result = memory_list()
        assert isinstance(result, dict)
        assert "items" in result or "total" in result

    def test_memory_categories(self):
        from server import memory_categories
        result = memory_categories()
        assert isinstance(result, dict)
        assert "categories" in result or "total" in result

    def test_memory_forget_not_found(self):
        from server import memory_forget
        result = memory_forget("_nonexistent_xyz_")
        assert isinstance(result, dict)


# ===========================================================================
# Phase 6: Session Tracker
# ===========================================================================

class TestSessionTracker:
    def test_session_lifecycle(self):
        from server import (session_start, session_event, session_state_set,
                           session_state_get, session_summary, session_list, session_close)
        # Start
        result = session_start("smoke test", tags=["test"])
        assert isinstance(result, dict)
        assert result.get("session_id") is not None
        sid = result["session_id"]

        # Event
        result = session_event(sid, "test_event", {"key": "val"})
        assert isinstance(result, dict)
        assert result.get("success") is True

        # State set
        result = session_state_set(sid, "phase", "smoke")
        assert isinstance(result, dict)
        assert result.get("success") is True

        # State get
        result = session_state_get(sid, "phase")
        assert isinstance(result, dict)
        assert result.get("found") is True

        # Summary
        result = session_summary(sid)
        assert isinstance(result, dict)
        assert result.get("session_id") == sid

        # List
        result = session_list(limit=5)
        assert isinstance(result, dict)
        assert "sessions" in result

        # Close
        result = session_close(sid)
        assert isinstance(result, dict)
        assert result.get("success") is True

    def test_session_event_bad_id(self):
        from server import session_event
        result = session_event("bad_id_xyz", "test")
        assert isinstance(result, dict)
        # Should not crash — either success false or error
        if result.get("success") is not None:
            pass


# ===========================================================================
# Phase 6: Context Log
# ===========================================================================

class TestContextLog:
    def test_context_lifecycle(self):
        from server import (session_start, context_log, context_recent,
                           context_search, context_stats, session_close)
        # Need a session first
        s = session_start("ctx test")
        if not s.get("session_id"):
            pytest.skip("session_start failed")
        sid = s["session_id"]

        # Log entries
        for i in range(3):
            context_log(sid, f"tool_{i}", f"input_{i}", f"output_{i}")

        # Recent
        result = context_recent(sid, limit=5)
        assert isinstance(result, dict)
        assert "entries" in result
        assert len(result["entries"]) <= 5

        # Search
        result = context_search(sid, query="input")
        assert isinstance(result, dict)

        # Search by tool
        result = context_search(sid, tool="tool_0")
        assert isinstance(result, dict)

        # Stats
        result = context_stats(sid)
        assert isinstance(result, dict)
        assert "total_entries" in result
        assert result["total_entries"] >= 3

        session_close(sid)


# ===========================================================================
# Phase 6: File Change Tracker
# ===========================================================================

class TestFileTracker:
    def test_track_lifecycle(self, tmp_project):
        from server import (session_start, track_start, track_changes,
                           track_stop, session_close)
        s = session_start("track test")
        if not s.get("session_id"):
            pytest.skip("session_start failed")
        sid = s["session_id"]

        # Start tracking
        result = track_start(sid, str(tmp_project))
        assert isinstance(result, dict)
        assert result.get("success") is True

        # Check changes (none yet)
        result = track_changes(sid)
        assert isinstance(result, dict)
        assert "created" in result or "modified" in result

        # Stop
        result = track_stop(sid)
        assert isinstance(result, dict)
        assert result.get("success") is True

        session_close(sid)


# ===========================================================================
# Phase 7a: Data Converter
# ===========================================================================

class TestDataConverter:
    def test_parse_json_valid(self):
        from server import convert_parse_json
        result = convert_parse_json('{"key": "value", "num": 42}')
        assert isinstance(result, dict)
        assert result.get("success") is True
        assert result.get("data") == {"key": "value", "num": 42}

    def test_parse_json_invalid(self):
        from server import convert_parse_json
        result = convert_parse_json("{invalid}")
        assert isinstance(result, dict)
        assert result.get("success") is False

    def test_parse_yaml(self):
        from server import convert_parse_yaml
        result = convert_parse_yaml("key: value\nnum: 42\n")
        assert isinstance(result, dict)

    def test_to_json(self):
        from server import convert_to_json
        result = convert_to_json('{"a": 1}', indent=2)
        assert isinstance(result, dict)
        assert "json_string" in result or "success" in result

    def test_to_yaml(self):
        from server import convert_to_yaml
        result = convert_to_yaml('{"a": 1, "b": 2}')
        assert isinstance(result, dict)

    def test_json_to_yaml(self):
        from server import convert_json_to_yaml
        result = convert_json_to_yaml('{"hello": "world"}')
        assert isinstance(result, dict)

    def test_yaml_to_json(self):
        from server import convert_yaml_to_json
        result = convert_yaml_to_json("hello: world\n")
        assert isinstance(result, dict)

    def test_parse_csv(self):
        from server import convert_parse_csv
        result = convert_parse_csv("name,age\nAlice,30\nBob,25\n")
        assert isinstance(result, dict)
        assert result.get("success") is True

    def test_to_csv(self):
        from server import convert_to_csv
        result = convert_to_csv(["x", "y"], [["1", "2"], ["3", "4"]])
        assert isinstance(result, dict)
        assert result.get("success") is True

    def test_validate_schema_valid(self):
        from server import convert_validate_schema
        schema = '{"type": "object", "properties": {"name": {"type": "string"}}}'
        instance = '{"name": "Alice"}'
        result = convert_validate_schema(instance, schema)
        assert isinstance(result, dict)
        assert "valid" in result


# ===========================================================================
# Phase 7b: Network Tools
# ===========================================================================

class TestNetworkTools:
    def test_dns_lookup_google(self):
        from server import network_dns_lookup
        result = network_dns_lookup("google.com", "A")
        assert isinstance(result, dict)
        assert "success" in result or "error" in result

    def test_port_check_google_https(self):
        from server import network_port_check
        result = network_port_check("google.com", 443, timeout=2.0)
        assert isinstance(result, dict)
        assert "open" in result

    def test_port_check_refused(self):
        from server import network_port_check
        result = network_port_check("127.0.0.1", 1, timeout=1.0)
        assert isinstance(result, dict)
        assert "open" in result

    def test_ssl_info_google(self):
        from server import network_ssl_info
        result = network_ssl_info("google.com", timeout=3.0)
        assert isinstance(result, dict)
        assert "success" in result

    def test_whois_lookup(self):
        from server import network_whois
        result = network_whois("example.com")
        assert isinstance(result, dict)

    def test_http_check(self):
        from server import network_http_check
        result = network_http_check("https://httpbin.org/get", method="GET", timeout=5.0)
        assert isinstance(result, dict)

    def test_trace_route_local(self):
        from server import network_trace
        result = network_trace("127.0.0.1", max_hops=3, timeout=1.0)
        assert isinstance(result, dict)
        assert "hops" in result


# ===========================================================================
# Phase 8a: Process Manager
# ===========================================================================

class TestProcessManager:
    def test_ps_list_returns_list(self):
        from server import ps_list
        result = ps_list(limit=5)
        assert isinstance(result, list)

    def test_ps_list_with_name_filter(self):
        from server import ps_list
        result = ps_list(name_filter="python", limit=10)
        assert isinstance(result, list)

    def test_ps_list_with_user_filter(self):
        from server import ps_list
        result = ps_list(user_filter="system", limit=10)
        assert isinstance(result, list)

    def test_ps_list_sort_by_memory(self):
        from server import ps_list
        result = ps_list(sort_by="memory", limit=5)
        assert isinstance(result, list)

    def test_ps_find_by_name(self):
        from server import ps_find
        result = ps_find(name="python")
        assert isinstance(result, list)

    def test_ps_find_by_port_nonexistent(self):
        from server import ps_find
        result = ps_find(port=65535)
        assert isinstance(result, list)

    def test_ps_info_current_pid(self):
        from server import ps_info
        result = ps_info(pid=0)
        assert isinstance(result, dict)

    def test_ps_info_nonexistent(self):
        from server import ps_info
        result = ps_info(pid=999999999)
        assert isinstance(result, dict)
        assert result.get("found") is False

    def test_ps_kill_nonexistent(self):
        from server import ps_kill
        result = ps_kill(pid=999999999)
        assert isinstance(result, dict)
        assert result.get("success") is False

    def test_ps_tree(self):
        from server import ps_tree
        result = ps_tree()
        assert isinstance(result, dict)
        assert "success" in result

    def test_ps_tree_specific_pid(self):
        from server import ps_tree
        result = ps_tree(root_pid=0)
        assert isinstance(result, dict)

    def test_ps_system_stats(self):
        from server import ps_system_stats
        result = ps_system_stats()
        assert isinstance(result, dict)
        assert "cpu" in result
        assert "memory" in result
        assert "disk" in result
        assert "network" in result

    def test_ps_ports_returns_list(self):
        from server import ps_ports
        result = ps_ports()
        assert isinstance(result, list)


# ===========================================================================
# Phase 8b: Excel Toolkit
# ===========================================================================

class TestExcelToolkit:
    def test_excel_write_read_roundtrip(self, tmp_path):
        from server import excel_write, excel_read, excel_sheets
        xlsx = str(tmp_path / "test.xlsx")
        headers = ["Name", "Age", "City"]
        rows = [["Alice", "30", "NYC"], ["Bob", "25", "LA"]]

        # Write
        w = excel_write(xlsx, "People", headers, rows)
        assert w.get("success") is True
        assert w.get("rows_written") == 2

        # Read
        r = excel_read(xlsx)
        assert r.get("success") is True
        assert r["headers"] == headers
        assert len(r["rows"]) == 2

        # Sheets
        s = excel_sheets(xlsx)
        assert s.get("success") is True
        assert any(sh["name"] == "People" for sh in s["sheets"])

    def test_excel_sheets_nonexistent(self):
        from server import excel_sheets
        result = excel_sheets(r"C:\nonexistent_dir\no.xlsx")
        assert result.get("success") is False

    def test_excel_write_append(self, tmp_path):
        from server import excel_write
        xlsx = str(tmp_path / "append.xlsx")
        excel_write(xlsx, "Sheet1", ["Col1"], [["a"]])
        r = excel_write(xlsx, "Sheet2", ["Col2"], [["b"]], mode="append")
        assert r.get("success") is True
        assert r.get("rows_written") == 1

    def test_excel_csv_conversion_roundtrip(self, tmp_path):
        from server import excel_csv_to_xlsx, excel_xlsx_to_csv, excel_read
        csv_in = str(tmp_path / "in.csv")
        xlsx = str(tmp_path / "out.xlsx")
        csv_out = str(tmp_path / "back.csv")

        # Create CSV
        with open(csv_in, "w", newline="", encoding="utf-8") as f:
            f.write("a,b,c\n1,2,3\n4,5,6\n")

        # CSV to XLSX
        c = excel_csv_to_xlsx(csv_in, xlsx)
        assert c.get("success") is True

        # Verify content
        r = excel_read(xlsx)
        assert r.get("success") is True
        assert r["headers"] == ["a", "b", "c"]

        # XLSX back to CSV
        c2 = excel_xlsx_to_csv(xlsx, csv_out)
        assert c2.get("success") is True

    def test_excel_merge_files(self, tmp_path):
        from server import excel_write, excel_merge
        f1 = str(tmp_path / "a.xlsx")
        f2 = str(tmp_path / "b.xlsx")
        merged = str(tmp_path / "merged.xlsx")
        excel_write(f1, "S1", ["X"], [["1"]])
        excel_write(f2, "S2", ["Y"], [["2"]])
        m = excel_merge([f1, f2], merged)
        assert m.get("success") is True
        assert m.get("files_merged") == 2


# ===========================================================================
# Phase 8c: Crypto / Hash Tools
# ===========================================================================

class TestCryptoTools:
    def test_hash_sha256(self):
        from server import crypto_hash
        r = crypto_hash("hello", "sha256")
        assert r.get("success") is True
        assert r["hash"] == hashlib.sha256(b"hello").hexdigest()

    def test_hash_md5(self):
        from server import crypto_hash
        r = crypto_hash("test", "md5")
        assert r.get("success") is True
        assert len(r["hash"]) == 32

    def test_hash_bad_algorithm(self):
        from server import crypto_hash
        r = crypto_hash("x", "whirlpool")
        assert r.get("success") is False

    def test_hash_file(self, tmp_path):
        from server import crypto_hash_file
        f = tmp_path / "test.bin"
        f.write_bytes(b"hello world")
        r = crypto_hash_file(str(f), "sha256")
        assert r.get("success") is True
        assert "hash" in r
        assert r["file_size"] == 11

    def test_hash_file_nonexistent(self):
        from server import crypto_hash_file
        r = crypto_hash_file(r"C:\does_not_exist.bin")
        assert r.get("success") is False

    def test_base64_roundtrip(self):
        from server import crypto_base64_encode, crypto_base64_decode
        original = "Hello, World!"
        enc = crypto_base64_encode(original)
        assert enc.get("success") is True
        dec = crypto_base64_decode(enc["result"])
        assert dec.get("success") is True
        assert dec["result"] == original

    def test_base64_decode_invalid(self):
        from server import crypto_base64_decode
        r = crypto_base64_decode("not!base64!!")
        assert r.get("success") is False

    def test_uuid_v4(self):
        from server import crypto_uuid
        r = crypto_uuid(version=4)
        assert r.get("success") is True
        assert r["count"] == 1
        assert len(r["uuids"]) == 1
        assert len(r["uuids"][0]) == 36

    def test_uuid_v4_multiple(self):
        from server import crypto_uuid
        r = crypto_uuid(version=4, count=5)
        assert r.get("success") is True
        assert len(r["uuids"]) == 5

    def test_uuid_v7(self):
        from server import crypto_uuid
        r = crypto_uuid(version=7)
        assert r.get("success") is True
        assert len(r["uuids"]) == 1

    def test_hmac_sha256(self):
        from server import crypto_hmac
        r = crypto_hmac("mykey", "mymessage", "sha256")
        assert r.get("success") is True
        assert "signature" in r

    def test_hmac_bad_algorithm(self):
        from server import crypto_hmac
        r = crypto_hmac("k", "m", "whirlpool")
        assert r.get("success") is False

    def test_hmac_base64_encoding(self):
        from server import crypto_hmac
        r = crypto_hmac("key", "msg", encoding="base64")
        assert r.get("success") is True
        assert r["encoding"] == "base64"

    def test_random_bytes_hex(self):
        from server import crypto_random
        r = crypto_random(16, "hex")
        assert r.get("success") is True
        assert len(r["result"]) == 32  # 16 bytes = 32 hex chars

    def test_random_bytes_base64(self):
        from server import crypto_random
        r = crypto_random(16, "base64")
        assert r.get("success") is True

    def test_random_bytes_invalid_length(self):
        from server import crypto_random
        r = crypto_random(99999)
        assert r.get("success") is False


# ---------------------------------------------------------------------------
# Phase 9a — Docker Advanced (without Docker running, tests graceful failure)
# ---------------------------------------------------------------------------

class TestDockerAdvanced:
    """Test Docker Advanced tools. Docker may not be running."""

    def test_docker_prune(self):
        from server import docker_prune
        r = docker_prune(force=True)
        # Should succeed or fail gracefully if Docker not available
        assert isinstance(r, dict)

    def test_volume_ls(self):
        from server import docker_volume_ls
        r = docker_volume_ls()
        assert isinstance(r, dict)

    def test_network_inspect_not_found(self):
        from server import docker_network_inspect
        r = docker_network_inspect("nonexistent_network_xyz")
        assert isinstance(r, dict)


class TestPackageManager:
    """Package manager tools. Needs pip available."""

    def test_pip_list(self):
        from server import pip_list
        r = pip_list()
        assert r.get("success") is True
        assert "packages" in r
        assert r.get("count", 0) > 0

    def test_pip_show(self):
        from server import pip_show
        r = pip_show("pytest")
        assert r.get("success") is True
        assert r.get("details", {}).get("name", "").lower() == "pytest"

    def test_pip_show_not_found(self):
        from server import pip_show
        # Use a truly obscure package name
        r = pip_show("nonexistent_package_xyz_12345")
        assert r.get("success") is False


class TestGraphQL:
    """GraphQL helpers (without server, tests graceful failure)."""

    def test_graphql_query_fail_no_server(self):
        from server import graphql_query
        r = graphql_query("http://localhost:1/graphql", "{ test }")
        assert r.get("success") is False


# ---------------------------------------------------------------------------
# Phase 9b — RAG / AI Infrastructure
# ---------------------------------------------------------------------------

class TestRAGChunking:
    """RAG text chunking — pure function, no external deps."""

    def test_chunk_small_text(self):
        from server import rag_chunk_text
        r = rag_chunk_text("Hello world", chunk_size=500, overlap=0)
        assert r.get("success") is True
        assert r.get("count") == 1
        assert "Hello world" in r["chunks"][0]

    def test_chunk_medium_text(self):
        from server import rag_chunk_text
        text = "word " * 200  # ~1000 chars
        r = rag_chunk_text(text, chunk_size=300, overlap=30)
        assert r.get("success") is True
        assert r.get("count", 0) >= 3

    def test_chunk_sentence_method(self):
        from server import rag_chunk_text
        text = "First sentence. Second sentence. Third sentence. Fourth one."
        r = rag_chunk_text(text, chunk_size=50, overlap=10, method="sentence")
        assert r.get("success") is True
        assert r.get("count", 0) >= 1

    def test_chunk_empty_text(self):
        from server import rag_chunk_text
        r = rag_chunk_text("", chunk_size=500, overlap=0)
        assert r.get("success") is True
        assert r.get("count") == 0

    def test_chunk_overlap(self):
        from server import rag_chunk_text
        text = "AAAAA " * 100
        r = rag_chunk_text(text, chunk_size=100, overlap=20)
        assert r.get("success") is True
        chunks = r["chunks"]
        # Verify chunks are not empty
        assert all(len(c) > 0 for c in chunks)
        assert r.get("overlap") == 20


class TestRAGVector:
    """Vector store operations (without Ollama)."""

    def test_vector_create(self):
        from server import rag_vector_create
        import tempfile
        import os
        # Use temp to avoid polluting real storage
        os.environ["HOME"] = tempfile.mkdtemp()
        r = rag_vector_create("test_index_unit", model="test-model")
        # May fail due to storage not available in test env, check it's a dict
        assert isinstance(r, dict)

    def test_vector_list_empty(self):
        from server import rag_vector_list
        import tempfile
        import os
        os.environ["HOME"] = tempfile.mkdtemp()
        r = rag_vector_list()
        assert isinstance(r, dict)

    def test_vector_search_no_index(self):
        from server import rag_vector_search
        r = rag_vector_search("_nonexistent_index", "query")
        assert r.get("success") is False
        assert "not found" in r.get("error", "").lower()


class TestRAGRetrieve:
    """RAG pipeline retrieval — pure function test (without Ollama)."""

    def test_retrieve_no_ollama(self):
        from server import rag_retrieve
        r = rag_retrieve("Some sample text to search.", "find the text")
        # Without Ollama running, should fail gracefully
        assert "success" in r
        # If success=False, should have error about Ollama
        if not r.get("success"):
            assert "ollama" in r.get("error", "").lower() or "embed" in r.get("error", "").lower()


class TestFileWatcher:
    """Polling-based file watcher tools."""

    def test_watch_start_nonexistent(self):
        from server import fs_watch_start
        r = fs_watch_start(r"C:\__nonexistent_path_nexus__")
        assert r.get("success") is False
        assert "not found" in r.get("error", "").lower()

    def test_watch_list_empty(self):
        from server import fs_watch_list
        r = fs_watch_list()
        assert r.get("success") is True
        assert isinstance(r.get("watches"), list)

    def test_watch_stop_nonexistent(self):
        from server import fs_watch_stop
        r = fs_watch_stop("_nonexistent_watch_")
        assert r.get("success") is False
        assert "not found" in r.get("error", "").lower()


class TestClipboard:
    """Clipboard get/set/history (Windows-only; may fail gracefully)."""

    def test_clipboard_get(self):
        from server import clipboard_get
        r = clipboard_get()
        # Should work on Windows or fail gracefully elsewhere
        if not r.get("success"):
            assert "power" in r.get("error", "").lower() or "windows" in r.get("error", "").lower()

    def test_clipboard_set(self):
        from server import clipboard_set
        r = clipboard_set("nexus-tools test")
        if not r.get("success"):
            assert "power" in r.get("error", "").lower() or "windows" in r.get("error", "").lower()

    def test_clipboard_history(self):
        from server import clipboard_history
        r = clipboard_history(limit=5)
        assert r.get("success") is True
        assert isinstance(r.get("entries"), list)


class TestScheduler:
    """Task scheduling tools."""

    def test_schedule_and_cancel(self):
        from server import task_schedule, task_cancel
        r = task_schedule("_test_recurring", 3600, "Test recurring task")
        assert r.get("success") is True
        assert r.get("action") in ("scheduled", "updated")
        r2 = task_cancel("_test_recurring")
        assert r2.get("success") is True

    def test_delayed_and_check(self):
        from server import task_delayed, task_check
        # Schedule a one-shot that fires immediately (seconds=0)
        r = task_delayed("_test_oneshot", 0, "Test oneshot")
        assert r.get("success") is True
        # Check should find it due
        r2 = task_check()
        assert r2.get("success") is True
        due = [t for t in r2.get("due_tasks", []) if t["name"] == "_test_oneshot"]
        assert len(due) >= 1
        # Cleanup in case it wasn't consumed
        from server import task_cancel
        task_cancel("_test_oneshot")

    def test_cancel_nonexistent(self):
        from server import task_cancel
        r = task_cancel("_nonexistent_task_")
        assert r.get("success") is False
        assert "not found" in r.get("error", "").lower()

    def test_check_empty(self):
        from server import task_check
        r = task_check()
        assert r.get("success") is True
        assert isinstance(r.get("due_tasks"), list)


class TestTemplateEngine:
    """Jinja2 template rendering tools."""

    def test_render_simple(self):
        from server import template_render
        r = template_render("Hello {{ name }}!", {"name": "World"})
        assert r.get("success") is True
        assert r.get("rendered") == "Hello World!"

    def test_render_undefined_silent(self):
        from server import template_render
        r = template_render("Hello {{ missing }}!", {})
        assert r.get("success") is True
        assert r.get("rendered") == "Hello !"

    def test_render_complex(self):
        from server import template_render
        tpl = "{% for item in items %}{{ item }},{% endfor %}"
        r = template_render(tpl, {"items": ["a", "b", "c"]})
        assert r.get("success") is True
        assert r.get("rendered") == "a,b,c,"

    def test_validate_valid(self):
        from server import template_validate
        r = template_validate("Hello {{ name }}!")
        assert r.get("success") is True
        assert r.get("valid") is True

    def test_validate_invalid(self):
        from server import template_validate
        r = template_validate("Hello {{ name! }}")
        assert r.get("success") is True
        assert r.get("valid") is False
        assert "error" in r

    def test_list_vars(self):
        from server import template_list_vars
        tpl = "Hello {{ name }}! Count: {{ items|length }}"
        r = template_list_vars(tpl)
        assert r.get("success") is True
        vars_list = r.get("variables", [])
        assert "name" in vars_list
        assert "items" in vars_list
        assert "items|length" not in vars_list  # Should strip filter

    def test_render_file_not_found(self):
        from server import template_render_file
        r = template_render_file(r"C:\__nonexistent_template__", {})
        assert r.get("success") is False
        assert "not found" in r.get("error", "").lower()
