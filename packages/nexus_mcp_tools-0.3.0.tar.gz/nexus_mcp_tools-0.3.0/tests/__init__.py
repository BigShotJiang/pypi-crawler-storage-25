"""Smoke tests for NEXUS TOOLS."""
