"""Pure unit tests for RAG logic - chunking, vector math. No external deps needed."""

import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))
sys.path.insert(0, str(PROJECT_ROOT / "tools"))


class TestChunkingLogic:
    """Test chunk_text pure function directly."""

    def test_chunk_character_basic(self, ):
        from tools.rag_tools import chunk_text
        r = chunk_text("Hello world.", chunk_size=100, overlap=0)
        assert r["success"]
        assert r["count"] == 1
        assert r["chunks"][0] == "Hello world."

    def test_chunk_splits_large(self):
        from tools.rag_tools import chunk_text
        text = "word " * 500  # ~2500 chars
        r = chunk_text(text, chunk_size=500, overlap=50)
        assert r["success"]
        assert r["count"] >= 4
        # Verify overlap by checking chunks share content
        chunks_text = " ".join(r["chunks"])
        for w in text.split()[:10]:
            assert w in chunks_text

    def test_chunk_sentence(self):
        from tools.rag_tools import chunk_text
        text = "A. B. C. D. E. F. G. H. I. J."
        r = chunk_text(text, chunk_size=30, overlap=5, method="sentence")
        assert r["success"]
        assert r["count"] >= 1
        assert r["method"] == "sentence"

    def test_chunk_empty(self):
        from tools.rag_tools import chunk_text
        r = chunk_text("", chunk_size=500, overlap=0)
        assert r["success"]
        assert r["count"] == 0

    def test_chunk_whitespace_only(self):
        from tools.rag_tools import chunk_text
        r = chunk_text("   \n\n  ", chunk_size=100, overlap=0)
        assert r["success"]
        assert r["count"] == 0


class TestVectorMath:
    """Test cosine similarity pure function."""

    def test_cosine_identical(self):
        from tools.rag_tools import _cosine_similarity
        v = [1.0, 2.0, 3.0]
        score = _cosine_similarity(v, v)
        assert abs(score - 1.0) < 0.0001

    def test_cosine_orthogonal(self):
        from tools.rag_tools import _cosine_similarity
        v1 = [1.0, 0.0]
        v2 = [0.0, 1.0]
        score = _cosine_similarity(v1, v2)
        assert abs(score - 0.0) < 0.0001

    def test_cosine_opposite(self):
        from tools.rag_tools import _cosine_similarity
        v1 = [1.0, 2.0]
        v2 = [-1.0, -2.0]
        score = _cosine_similarity(v1, v2)
        assert abs(score - (-1.0)) < 0.0001

    def test_cosine_zero_vector(self):
        from tools.rag_tools import _cosine_similarity
        v1 = [1.0, 2.0]
        v2 = [0.0, 0.0]
        score = _cosine_similarity(v1, v2)
        assert score == 0.0

    def test_cosine_empty(self):
        from tools.rag_tools import _cosine_similarity
        score = _cosine_similarity([], [])
        assert score == 0.0

    def test_cosine_dim_mismatch(self):
        from tools.rag_tools import _cosine_similarity
        score = _cosine_similarity([1.0], [1.0, 2.0])
        assert score == 0.0
