"""Nexus Tools CLI — browse, search, and call tools from the terminal.

Usage:
  nexus-tools-cli list                    List all tools grouped by domain
  nexus-tools-cli list <domain>           List tools in a specific domain
  nexus-tools-cli search <query>          Search tools by name/description
  nexus-tools-cli info <name>             Show tool signature and description
  nexus-tools-cli call <name> [json]      Call a tool with JSON arguments
"""

import inspect
import json
import sys
from typing import Any

DOMAIN_ALIASES: dict[str, str] = {
    "agent": "agentic",
    "containers": "docker",
    "converter": "data",
    "convert": "data",
    "watcher": "desktop",
    "clipboard": "desktop",
    "scheduler": "desktop",
    "task": "desktop",
    "templating": "template",
}


def _discover_tools() -> list[dict[str, Any]]:
    """Discover all @mcp.tool() functions from server module by __fastmcp__ marker."""
    import server as _srv
    tools = []
    for name in dir(_srv):
        fn = getattr(_srv, name)
        if not callable(fn) or not hasattr(fn, "__fastmcp__"):
            continue
        meta = fn.__fastmcp__  # type: ignore[reportFunctionMemberAccess]
        if getattr(meta, "type", None) != "tool":
            continue
        sig = inspect.signature(fn)
        params = []
        for p_name, p_param in sig.parameters.items():
            annotation = p_param.annotation
            default = p_param.default
            params.append({
                "name": p_name,
                "type": str(annotation) if annotation is not inspect.Parameter.empty else "Any",
                "required": p_param.default is inspect.Parameter.empty,
                "default": str(default) if default is not inspect.Parameter.empty else None,
            })
        doc = inspect.getdoc(fn) or ""
        summary = doc.split("\n\n")[0].strip() if doc else ""
        domain = _infer_domain(name)
        tools.append({
            "name": name,
            "summary": summary,
            "doc": doc,
            "params": params,
            "domain": domain,
        })
    return sorted(tools, key=lambda t: t["name"])


def _infer_domain(tool_name: str) -> str:
    """Infer domain from tool name prefix."""
    prefix_map = {
        "api_": "api",
        "git_": "git",
        "db_": "db",
        "scan_": "security",
        "dep_": "security",
        "container_": "docker",
        "docker_": "docker",
        "profile_": "profiler",
        "test_": "test_gen",
        "coverage_": "test_gen",
        "file_": "file",
        "env_": "env",
        "review_": "code",
        "kb_": "kb",
        "memory_": "memory",
        "session_": "memory",
        "parse_": "data",
        "to_": "data",
        "validate_": "data",
        "dns_": "network",
        "port_": "network",
        "ssl_": "network",
        "whois_": "network",
        "http_": "network",
        "trace_": "network",
        "my_ip": "network",
        "ps_": "process",
        "excel_": "excel",
        "crypto_": "crypto",
        "hash_": "crypto",
        "base64_": "crypto",
        "uuid_": "crypto",
        "hmac_": "crypto",
        "random_": "crypto",
        "compose_": "docker",
        "image_": "docker",
        "network_": "docker",
        "volume_": "docker",
        "pip_": "agentic",
        "npm_": "agentic",
        "uv_": "agentic",
        "graphql_": "agentic",
        "aws_": "agentic",
        "gcp_": "agentic",
        "rag_": "rag",
        "fs_watch": "desktop",
        "clipboard_": "desktop",
        "task_": "desktop",
        "template_": "template",
    }
    for prefix, domain in prefix_map.items():
        if tool_name.startswith(prefix):
            return domain
    return "other"


def _filter_tools(tools: list[dict], query: str | None = None,
                  domain: str | None = None) -> list[dict]:
    """Filter tools by query string and/or domain."""
    result = tools
    if domain:
        resolved = DOMAIN_ALIASES.get(domain, domain)
        result = [t for t in result if t.get("domain") == resolved]
    if query:
        q = query.lower()
        result = [
            t for t in result
            if q in t["name"].lower() or q in t["summary"].lower()
        ]
    return result


def _print_tool_list(tools: list[dict], group_by_domain: bool = True) -> None:
    """Print tools grouped by domain."""
    if not tools:
        print("No tools found.")
        return

    if group_by_domain:
        by_domain: dict[str, list] = {}
        for t in tools:
            by_domain.setdefault(t["domain"], []).append(t)
        for domain in sorted(by_domain):
            domain_tools = by_domain[domain]
            print(f"\n  [{domain.upper()}]  ({len(domain_tools)} tools)")
            for t in domain_tools:
                summary = t["summary"][:70] + "..." if len(t["summary"]) > 70 else t["summary"]
                print(f"    {t['name']:<28s} {summary}")
    else:
        for t in tools:
            summary = t["summary"][:70] + "..." if len(t["summary"]) > 70 else t["summary"]
            print(f"  {t['name']:<28s}  [{t['domain']}]  {summary}")

    print(f"\n  Total: {len(tools)} tools\n")


def _cmd_list(args: list[str]) -> None:
    """List tools, optionally by domain."""
    tools = _discover_tools()
    domain = args[0] if args else None
    filtered = _filter_tools(tools, domain=domain)
    print(f"\n=== Nexus Tools — {len(filtered)} tools ===")
    _print_tool_list(filtered, group_by_domain=(domain is None))


def _cmd_search(args: list[str]) -> None:
    """Search tools by name or description."""
    if not args:
        print("Usage: nexus-tools-cli search <query>")
        return
    query = " ".join(args)
    tools = _discover_tools()
    filtered = _filter_tools(tools, query=query)
    print(f"\n=== Search results for '{query}' — {len(filtered)} matches ===")
    _print_tool_list(filtered, group_by_domain=False)
    if not filtered:
        print("  (try a different search term)\n")


def _cmd_info(args: list[str]) -> None:
    """Show detailed info about a tool."""
    if not args:
        print("Usage: nexus-tools-cli info <tool_name>")
        return
    name = args[0]
    tools = _discover_tools()
    matches = [t for t in tools if t["name"] == name]
    if not matches:
        print(f"Tool '{name}' not found.")
        # Suggest similar
        similar = _filter_tools(tools, query=name)
        if similar:
            print(f"Did you mean: {', '.join(t['name'] for t in similar[:5])}")
        return

    t = matches[0]
    print(f"\n=== {t['name']} ===")
    print(f"  Domain:     {t['domain']}")
    print(f"  Summary:    {t['summary']}")
    print("\n  Description:")
    doc_lines = t["doc"].split("\n")
    for line in doc_lines:
        print(f"    {line}")

    print("\n  Parameters:")
    if t["params"]:
        for p in t["params"]:
            req = "required" if p["required"] else f'default={p["default"]}'
            print(f"    {p['name']:<20s} {p['type']:<20s} ({req})")
    else:
        print("    (none)")
    print()


def _cmd_call(args: list[str]) -> None:
    """Call a tool with JSON args from the terminal."""
    if not args:
        print("Usage: nexus-tools-cli call <tool_name> [json_args]")
        print("  json_args: optional JSON string of arguments (default: {})")
        return

    name = args[0]
    json_str = " ".join(args[1:]) if len(args) > 1 else "{}"

    # Import the tool function from server
    import server as _server_mod

    fn = getattr(_server_mod, name, None)
    if fn is None or not callable(fn):
        print(f"Error: Tool '{name}' not found in server module.")
        return

    try:
        kwargs = json.loads(json_str) if json_str.strip() else {}
    except json.JSONDecodeError as e:
        print(f"Error: Invalid JSON arguments: {e}")
        return

    if not isinstance(kwargs, dict):
        print("Error: JSON arguments must be an object (dict).")
        return

    try:
        result = fn(**kwargs)
        print(json.dumps(result, indent=2, default=str))
    except Exception as e:
        print(f"Error calling {name}: {e}")


def main() -> None:
    """CLI entry point."""
    args = sys.argv[1:] if len(sys.argv) > 1 else []

    if not args:
        print("Nexus Tools CLI — browse, search, and call MCP tools")
        print()
        print("Usage:")
        print("  nexus-tools        Start MCP server (no args)")
        print("  nexus-tools-cli list                    List all tools")
        print("  nexus-tools-cli list <domain>           List tools by domain")
        print("  nexus-tools-cli search <query>          Search tools")
        print("  nexus-tools-cli info <tool_name>        Tool details")
        print("  nexus-tools-cli call <name> [json]      Call a tool")
        return

    cmd = args[0]
    cmd_args = args[1:]

    commands = {
        "list": _cmd_list,
        "search": _cmd_search,
        "info": _cmd_info,
        "call": _cmd_call,
    }

    if cmd in commands:
        commands[cmd](cmd_args)
    else:
        print(f"Unknown command: {cmd}")
        print("Available: list, search, info, call")


if __name__ == "__main__":
    main()
