"""Dogfood test: start MCP server, handshake, list tools, verify response."""
import json
import os
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SERVER = str(ROOT / "server.py")
VENV_PYTHON = str(ROOT / ".venv" / "Scripts" / "python.exe")
ENV = os.environ.copy()
ENV["PYTHONPATH"] = f"{ROOT};{ROOT / 'tools'}"


def send_msg(proc, msg: dict) -> dict | None:
    """Send a JSON-RPC message and read one response line."""
    line = json.dumps(msg)
    proc.stdin.write((line + "\n").encode("utf-8"))
    proc.stdin.flush()
    deadline = time.time() + 10
    while time.time() < deadline:
        try:
            resp = proc.stdout.readline()
            if resp:
                return json.loads(resp.decode("utf-8"))
        except Exception:
            break
    return None


def check_error(resp: dict | None, phase: str):
    if resp is None:
        stderr_text = proc.stderr.read().decode("utf-8", errors="replace")
        print(f"[dogfood] FAIL: No response during {phase}. Stderr:\n{stderr_text}", file=sys.stderr)
        proc.kill()
        sys.exit(1)
    if "error" in resp:
        print(f"[dogfood] FAIL during {phase}: {resp['error']}", file=sys.stderr)
        proc.kill()
        sys.exit(1)


print(f"[dogfood] Starting MCP server: {SERVER}")
proc = subprocess.Popen(
    [VENV_PYTHON, "-u", SERVER],
    stdin=subprocess.PIPE,
    stdout=subprocess.PIPE,
    stderr=subprocess.PIPE,
    cwd=ROOT,
    env=ENV,
)

time.sleep(2)

# Read banner
try:
    banner = proc.stdout.readline()
    if banner:
        print(f"[dogfood] Banner: {banner.decode('utf-8', errors='replace').strip()}")
except Exception:
    pass

# Step 1: Initialize
print("[dogfood] Step 1: Sending initialize...")
init_resp = send_msg(proc, {
    "jsonrpc": "2.0", "id": 1, "method": "initialize",
    "params": {
        "protocolVersion": "2024-11-05",
        "capabilities": {},
        "clientInfo": {"name": "dogfood-test", "version": "1.0"},
    },
})
check_error(init_resp, "initialize")
print(f"[dogfood] Initialize OK — server protocol: {init_resp['result']['protocolVersion']}")

# Step 2: Initialized notification (no response expected)
print("[dogfood] Step 2: Sending initialized notification...")
proc.stdin.write((json.dumps({
    "jsonrpc": "2.0", "method": "notifications/initialized",
}) + "\n").encode("utf-8"))
proc.stdin.flush()

# Step 3: tools/list
print("[dogfood] Step 3: Sending tools/list...")
list_resp = send_msg(proc, {
    "jsonrpc": "2.0", "id": 2, "method": "tools/list",
})
check_error(list_resp, "tools/list")

tools = list_resp["result"]["tools"]
tool_names = {t["name"] for t in tools}

print(f"[dogfood] SUCCESS: Server returned {len(tools)} tools")

# Verify expected tools from all phases
# Use actual tool names from the server (they include module prefixes)
expected = {
    # Phase 1: API Tester
    "api_request", "api_validate", "api_run_collection",
    # Phase 2: Git Hub + DB Toolkit
    "git_status", "git_commit", "git_create_branch", "git_delete_branch", "git_create_pr",
    "db_execute", "db_list_tables", "db_describe_table", "db_run_migrations",
    # Phase 3: Security Scanner + Container Manager
    "security_scan_secrets", "security_check_deps", "security_scan_code",
    "container_up", "container_down", "container_ps", "container_restart",
    "container_check", "container_stats", "container_logs",
    # Phase 4: Profiler + Test Generator + File Toolkit
    "profile_execute", "profile_memory", "profile_compare", "test_profile_function",
    "test_generate", "test_run", "test_coverage",
    "file_search", "file_find", "file_info", "file_batch_rename",
    "file_compare", "file_search_replace",
    # Phase 5: Environment + Code Reviewer + Knowledge Base
    "env_info", "env_has_tools",
    "review_code", "review_dependencies", "review_metrics",
    "kb_set", "kb_get", "kb_search", "kb_list", "kb_delete",
    # Phase 6: Memory Manager
    "memory_set", "memory_get", "memory_search", "memory_list",
    "memory_forget", "memory_categories",
    "session_start", "session_event", "session_state_get", "session_state_set",
    "session_summary", "session_list", "session_close",
    "context_log", "context_recent", "context_search", "context_stats",
    "track_start", "track_changes", "track_stop",
    # Phase 7: Data Converter + Network Tools
    "convert_parse_json", "convert_parse_yaml", "convert_to_json", "convert_to_yaml",
    "convert_json_to_yaml", "convert_yaml_to_json", "convert_parse_csv", "convert_to_csv",
    "convert_validate_schema",
    "network_dns_lookup", "network_port_check", "network_http_check",
    "network_ssl_info", "network_whois", "network_my_ip", "network_trace",
    # Phase 8a: Process Manager
    "ps_list", "ps_find", "ps_info", "ps_kill", "ps_tree", "ps_system_stats", "ps_ports",
    # Phase 8b: Excel Toolkit
    "excel_sheets", "excel_read", "excel_write", "excel_merge",
    "excel_csv_to_xlsx", "excel_xlsx_to_csv",
    # Phase 8c: Crypto Tools
    "crypto_hash", "crypto_hash_file", "crypto_base64_encode", "crypto_base64_decode",
    "crypto_uuid", "crypto_hmac", "crypto_random",
    # Phase 9a: Agentic Dev - Docker Advanced
    "docker_compose_ps", "docker_compose_logs", "docker_image_inspect",
    "docker_container_exec", "docker_prune", "docker_network_inspect", "docker_volume_ls",
    # Phase 9a: Agentic Dev - Package Manager
    "pip_list", "pip_show", "npm_list", "npm_outdated", "uv_deps",
    # Phase 9a: Agentic Dev - GraphQL
    "graphql_query", "graphql_introspect", "graphql_schema_dump", "graphql_validate",
    # Phase 9a: Agentic Dev - Cloud CLI
    "aws_s3_ls", "aws_lambda_list", "aws_ec2_ls", "gcp_storage_ls", "gcp_compute_ls", "gcp_run_ls",
    # Phase 9b: AI/RAG Infra
    "rag_chunk_text", "rag_ollama_embed", "rag_ollama_models",
    "rag_vector_create", "rag_vector_add", "rag_vector_search",
    "rag_vector_list", "rag_vector_delete", "rag_retrieve",
}

missing = expected - tool_names
extra = tool_names - expected

print("\n[dogfood] Summary:")
print(f"  Total registered: {len(tools)}")
print(f"  Expected: {len(expected)}")
print(f"  Missing: {sorted(missing)}")
print(f"  Extra (unexpected): {sorted(extra)}")
print(f"  Accounted: {len(tool_names & expected)}")

if missing:
    print(f"\n[dogfood] WARNING: {len(missing)} expected tools are missing!")
    sys.exit(1)

# Show domain breakdown
prefixes: dict[str, int] = {}
for name in tool_names:
    prefix = name.split("_")[0]
    prefixes[prefix] = prefixes.get(prefix, 0) + 1
print(f"\n  Domain breakdown: {dict(sorted(prefixes.items()))}")

# Clean up
proc.stdin.close()
proc.terminate()
try:
    proc.wait(timeout=5)
except subprocess.TimeoutExpired:
    proc.kill()

print(f"\n[dogfood] DONE — All {len(tools)} tools verified, 0 missing!")
