"""System inspection utilities - environment info and tool detection."""

import os
import sys
import shutil
from typing import Any


class SystemInspector:
    """System and environment inspection utilities."""

    def env_check(self) -> dict[str, Any]:
        """Get environment information including Python version, platform, CPU, RAM, and PATH.

        Returns:
            Dict with python_version, platform, cpu_count, path_entries list,
            cwd, and env_vars dict (filtered to common patterns)
        """
        try:
            # Get Python version
            python_version = f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"

            # Get platform
            platform = sys.platform

            # Get CPU count
            cpu_count = os.cpu_count() or 1

            # Get PATH entries
            path_entries = os.environ.get("PATH", "").split(os.pathsep)

            # Get current working directory
            cwd = os.getcwd()

            # Filter environment variables to common patterns
            common_patterns = [
                "PATH", "HOME", "USER", "SHELL", "TERM", "EDITOR",
                "PYTHONPATH", "VIRTUAL_ENV", "CONDA",
                "_HOME", "_ROOT", "_VERSION", "JAVA_HOME", "GO_ROOT",
                "NODE_PATH", "npm_config_prefix", "CARGO_HOME", "RUSTUP_HOME",
            ]

            env_vars = {}
            for key, value in os.environ.items():
                # Include if key matches any pattern
                if any(pattern in key.upper() for pattern in common_patterns):
                    # Truncate long values for readability
                    if len(value) > 200:
                        value = value[:200] + "..."
                    env_vars[key] = value

            # Try to get RAM info using psutil if available
            ram_info = None
            try:
                import psutil
                mem = psutil.virtual_memory()
                ram_info = {
                    "total_gb": round(mem.total / (1024**3), 2),
                    "available_gb": round(mem.available / (1024**3), 2),
                    "percent": mem.percent,
                }
            except ImportError:
                pass

            result = {
                "python_version": python_version,
                "platform": platform,
                "cpu_count": cpu_count,
                "path_entries": path_entries,
                "cwd": cwd,
                "env_vars": env_vars,
            }

            if ram_info:
                result["ram"] = ram_info

            return result
        except Exception as e:
            return {"error": str(e)}

    def env_has_tools(self, tools: list[str]) -> dict[str, Any]:
        """Check if specific CLI tools exist on the system.

        Args:
            tools: List of tool names to check (e.g., ["git", "npm", "python"])

        Returns:
            Dict with tools list containing name, found boolean, and path;
            also returns all_found boolean
        """
        try:
            tool_results = []
            all_found = True

            for tool_name in tools:
                tool_path = shutil.which(tool_name)
                found = tool_path is not None

                if not found:
                    all_found = False

                tool_results.append({
                    "name": tool_name,
                    "found": found,
                    "path": tool_path,
                })

            return {
                "tools": tool_results,
                "all_found": all_found,
            }
        except Exception as e:
            return {"error": str(e), "tools": [], "all_found": False}