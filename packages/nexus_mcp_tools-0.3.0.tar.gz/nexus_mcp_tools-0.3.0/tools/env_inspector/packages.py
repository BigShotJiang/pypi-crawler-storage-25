"""Python package inspection utilities."""

import json
import os
import sys
import subprocess
from pathlib import Path
from typing import Any


class PackageInspector:
    """Python package and environment inspection utilities."""

    def env_check_packages(self, path: str | None = None) -> dict[str, Any]:
        """Check installed Python packages.

        Args:
            path: Optional path to requirements.txt file to read from

        Returns:
            Dict with packages list containing name, version, location;
            also returns total count
        """
        try:
            packages = []

            if path:
                # Read from requirements.txt
                req_path = Path(path)
                if not req_path.exists():
                    return {"error": f"Requirements file not found: {path}", "packages": [], "total": 0}

                with open(req_path, "r", encoding="utf-8") as f:
                    for line in f:
                        line = line.strip()
                        if not line or line.startswith("#"):
                            continue

                        # Parse package (handling various formats)
                        # e.g., "package==1.0.0" or "package>=1.0.0"
                        if "==" in line:
                            name, version = line.split("==", 1)
                        elif ">=" in line:
                            name, version = line.split(">=", 1)
                        elif "<=" in line:
                            name, version = line.split("<=", 1)
                        elif "!=" in line:
                            name, version = line.split("!=", 1)
                        else:
                            name = line
                            version = "unspecified"

                        packages.append({
                            "name": name.strip(),
                            "version": version.strip(),
                            "location": "requirements.txt",
                        })
            else:
                # Get installed packages from pip
                try:
                    result = subprocess.run(
                        [sys.executable, "-m", "pip", "list", "--format=json"],
                        capture_output=True,
                        text=True,
                        timeout=30,
                    )

                    if result.returncode == 0:
                        pip_packages = json.loads(result.stdout)
                        for pkg in pip_packages:
                            packages.append({
                                "name": pkg.get("name", ""),
                                "version": pkg.get("version", ""),
                                "location": pkg.get("location", ""),
                            })
                    else:
                        # Fallback: try pip show
                        result = subprocess.run(
                            [sys.executable, "-m", "pip", "list"],
                            capture_output=True,
                            text=True,
                            timeout=30,
                        )
                        if result.returncode == 0:
                            lines = result.stdout.strip().split("\n")[2:]  # Skip header
                            for line in lines:
                                if line:
                                    parts = line.split()
                                    if len(parts) >= 2:
                                        packages.append({
                                            "name": parts[0],
                                            "version": parts[1],
                                            "location": "pip",
                                        })

                except (subprocess.SubprocessError, json.JSONDecodeError, FileNotFoundError, Exception):
                    # Fallback: use importlib.metadata
                    pass

            return {
                "packages": packages,
                "total": len(packages),
            }
        except Exception as e:
            return {"error": str(e), "packages": [], "total": 0}

    def env_check_pythonpath(self, path: str) -> dict[str, Any]:
        """Validate PYTHONPATH/PATH entries.

        Args:
            path: Path string to check (can be semicolon-separated on Windows)

        Returns:
            Dict with entries list containing path, exists boolean, is_dir boolean;
            also returns total and missing counts
        """
        try:
            # Split by OS-specific path separator
            entries = path.split(os.pathsep) if path else []

            results = []
            missing = 0

            for entry in entries:
                entry = entry.strip()
                if not entry:
                    continue

                exists = os.path.exists(entry)
                is_dir = os.path.isdir(entry) if exists else False

                if not exists:
                    missing += 1

                results.append({
                    "path": entry,
                    "exists": exists,
                    "is_dir": is_dir,
                })

            return {
                "entries": results,
                "total": len(results),
                "missing": missing,
            }
        except Exception as e:
            return {"error": str(e), "entries": [], "total": 0, "missing": 0}