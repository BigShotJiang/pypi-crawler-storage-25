"""Cryptographic and encoding utilities using standard library only."""

import base64
import hashlib
import hmac as hmac_mod
import os
import uuid
from typing import Any


class CryptoToolkit:
    """Hashing, encoding, UUID generation, and HMAC utilities."""

    def hash_text(self, text: str, algorithm: str = "sha256",
                  encoding: str = "hex") -> dict[str, Any]:
        """Generate a hash of text using the specified algorithm.

        Args:
            text: Input text to hash
            algorithm: Hash algorithm (md5, sha1, sha256, sha384, sha512)
            encoding: Output encoding ('hex' or 'base64')

        Returns:
            Dict with hash result and metadata
        """
        alg_map = {
            "md5": hashlib.md5,
            "sha1": hashlib.sha1,
            "sha256": hashlib.sha256,
            "sha384": hashlib.sha384,
            "sha512": hashlib.sha512,
        }

        if algorithm.lower() not in alg_map:
            return {"success": False, "error": f"Unsupported algorithm: {algorithm}. "
                    f"Supported: {', '.join(alg_map.keys())}"}

        try:
            h = alg_map[algorithm.lower()]()
            h.update(text.encode("utf-8"))
            digest = h.digest()

            result_hash: str
            if encoding == "base64":
                result_hash = base64.b64encode(digest).decode("ascii")
            else:
                result_hash = h.hexdigest()

            return {
                "success": True,
                "algorithm": algorithm.lower(),
                "input_length": len(text),
                "hash": result_hash,
                "encoding": encoding,
            }
        except Exception as e:
            return {"success": False, "error": str(e)}

    def hash_file(self, filepath: str, algorithm: str = "sha256") -> dict[str, Any]:
        """Generate a hash of a file.

        Args:
            filepath: Path to the file
            algorithm: Hash algorithm (md5, sha1, sha256, sha384, sha512)

        Returns:
            Dict with hash result and file metadata
        """
        alg_map = {
            "md5": hashlib.md5,
            "sha1": hashlib.sha1,
            "sha256": hashlib.sha256,
            "sha384": hashlib.sha384,
            "sha512": hashlib.sha512,
        }

        if algorithm.lower() not in alg_map:
            return {"success": False, "error": f"Unsupported algorithm: {algorithm}"}

        try:
            if not os.path.isfile(filepath):
                return {"success": False, "error": f"File not found: {filepath}"}

            file_size = os.path.getsize(filepath)
            h = alg_map[algorithm.lower()]()
            with open(filepath, "rb") as f:
                for chunk in iter(lambda: f.read(65536), b""):
                    h.update(chunk)

            return {
                "success": True,
                "algorithm": algorithm.lower(),
                "filepath": filepath,
                "file_size": file_size,
                "hash": h.hexdigest(),
            }
        except Exception as e:
            return {"success": False, "error": str(e)}

    def base64_encode(self, data: str | bytes,
                      encoding: str = "utf-8") -> dict[str, Any]:
        """Encode data to base64.

        Args:
            data: Data to encode (string or bytes)
            encoding: Text encoding (default: utf-8)

        Returns:
            Dict with encoded result
        """
        try:
            if isinstance(data, str):
                data_bytes = data.encode(encoding)
            else:
                data_bytes = data
            encoded = base64.b64encode(data_bytes).decode("ascii")
            return {
                "success": True,
                "operation": "encode",
                "input_length": len(data_bytes),
                "output_length": len(encoded),
                "result": encoded,
            }
        except Exception as e:
            return {"success": False, "error": str(e)}

    def base64_decode(self, data: str,
                      output_encoding: str = "utf-8") -> dict[str, Any]:
        """Decode base64-encoded data.

        Args:
            data: Base64-encoded string
            output_encoding: Text encoding for output string

        Returns:
            Dict with decoded result
        """
        try:
            decoded_bytes = base64.b64decode(data)
            try:
                decoded = decoded_bytes.decode(output_encoding)
                return {
                    "success": True,
                    "operation": "decode",
                    "input_length": len(data),
                    "output_length": len(decoded),
                    "result": decoded,
                }
            except UnicodeDecodeError:
                # Binary data — return as hex
                return {
                    "success": True,
                    "operation": "decode",
                    "input_length": len(data),
                    "output_length": len(decoded_bytes),
                    "result": decoded_bytes.hex(),
                    "note": "Binary data returned as hex",
                }
        except Exception as e:
            return {"success": False, "error": str(e)}

    def generate_uuid(self, version: int = 4, count: int = 1) -> dict[str, Any]:
        """Generate one or more UUIDs.

        Args:
            version: UUID version (4=random, 7=time-ordered)
            count: Number of UUIDs to generate (max 100)

        Returns:
            Dict with list of UUIDs
        """
        if version not in (4, 7):
            return {"success": False, "error": "Only versions 4 and 7 are supported"}
        if count < 1 or count > 100:
            return {"success": False, "error": "Count must be between 1 and 100"}

        try:
            uuids: list[str] = []
            for _ in range(count):
                if version == 7:
                    gen = getattr(uuid, "uuid7", uuid.uuid4)
                    uuids.append(str(gen()))
                else:
                    uuids.append(str(uuid.uuid4()))
            return {
                "success": True,
                "version": version,
                "count": count,
                "uuids": uuids,
            }
        except Exception as e:
            return {"success": False, "error": str(e)}

    def hmac_sign(self, key: str, message: str,
                  algorithm: str = "sha256",
                  encoding: str = "hex") -> dict[str, Any]:
        """Create an HMAC signature for a message.

        Args:
            key: Secret key
            message: Message to sign
            algorithm: Hash algorithm (sha1, sha256, sha384, sha512)
            encoding: Output encoding ('hex' or 'base64')

        Returns:
            Dict with HMAC signature
        """
        alg_map = {
            "sha1": hashlib.sha1,
            "sha256": hashlib.sha256,
            "sha384": hashlib.sha384,
            "sha512": hashlib.sha512,
        }
        if algorithm.lower() not in alg_map:
            return {"success": False, "error": f"Unsupported algorithm: {algorithm}"}

        try:
            h = hmac_mod.new(
                key.encode("utf-8"),
                message.encode("utf-8"),
                alg_map[algorithm.lower()],
            )
            if encoding == "base64":
                sig = base64.b64encode(h.digest()).decode("ascii")
            else:
                sig = h.hexdigest()

            return {
                "success": True,
                "algorithm": algorithm.lower(),
                "signature": sig,
                "encoding": encoding,
            }
        except Exception as e:
            return {"success": False, "error": str(e)}

    def random_bytes(self, length: int = 32,
                     output_format: str = "hex") -> dict[str, Any]:
        """Generate cryptographically secure random bytes.

        Args:
            length: Number of random bytes
            output_format: 'hex', 'base64', or 'raw' (hex-encoded)

        Returns:
            Dict with random data
        """
        if length < 1 or length > 4096:
            return {"success": False, "error": "Length must be between 1 and 4096"}

        try:
            data = os.urandom(length)
            if output_format == "base64":
                result = base64.b64encode(data).decode("ascii")
            else:
                result = data.hex()

            return {
                "success": True,
                "length": length,
                "format": output_format,
                "result": result,
            }
        except Exception as e:
            return {"success": False, "error": str(e)}
