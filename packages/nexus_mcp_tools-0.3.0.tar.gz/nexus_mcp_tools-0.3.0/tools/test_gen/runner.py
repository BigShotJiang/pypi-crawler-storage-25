"""Test runner for executing pytest tests and parsing results."""

import json
import subprocess
import time
from pathlib import Path
from typing import Any, Dict, List


class TestRunner:
    """Runner for executing pytest tests."""

    def test_run(
        self, path: str, verbose: bool = False, timeout: int = 60
    ) -> Dict[str, Any]:
        """Run pytest on a file or directory.

        Args:
            path: Path to test file or directory
            verbose: Enable verbose output
            timeout: Timeout in seconds

        Returns:
            Dict with success, passed, failed, errors, skipped, total,
            duration_ms, results
        """
        try:
            test_path = Path(path)

            if not test_path.exists():
                return {
                    "success": False,
                    "passed": 0,
                    "failed": 0,
                    "errors": 0,
                    "skipped": 0,
                    "total": 0,
                    "duration_ms": 0,
                    "results": [],
                    "error": f"Path not found: {path}",
                }

            # Build pytest command
            cmd = ["pytest", str(test_path), "--tb=short", "-v" if verbose else "-q"]

            # Add JSON report if pytest-json-report is available
            json_report = False
            try:
                subprocess.run(
                    ["pytest", "--version"],
                    capture_output=True,
                    check=True,
                )
                json_report = True
            except (subprocess.CalledProcessError, FileNotFoundError):
                pass

            if json_report:
                cmd.extend(["--json-report", "--json-report-file=.pytest_report.json"])

            start_time = time.perf_counter()

            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=timeout,
            )

            end_time = time.perf_counter()
            duration_ms = (end_time - start_time) * 1000

            # Parse output for results
            results: List[Dict[str, Any]] = self._parse_pytest_output(result.stdout)

            # If JSON report exists, read it
            json_file = Path(".pytest_report.json")
            if json_report and json_file.exists():
                try:
                    with open(json_file, "r") as f:
                        json_data = json.load(f)
                        results = self._parse_json_report(json_data)
                    json_file.unlink()  # Clean up
                except Exception:
                    pass

            # Count results
            passed = sum(1 for r in results if r.get("outcome") == "passed")
            failed = sum(1 for r in results if r.get("outcome") == "failed")
            errors = sum(1 for r in results if r.get("outcome") == "error")
            skipped = sum(1 for r in results if r.get("outcome") == "skipped")

            return {
                "success": result.returncode == 0,
                "passed": passed,
                "failed": failed,
                "errors": errors,
                "skipped": skipped,
                "total": len(results),
                "duration_ms": round(duration_ms, 2),
                "results": results,
                "error": None,
            }

        except subprocess.TimeoutExpired:
            return {
                "success": False,
                "passed": 0,
                "failed": 0,
                "errors": 0,
                "skipped": 0,
                "total": 0,
                "duration_ms": 0,
                "results": [],
                "error": f"Test execution timed out after {timeout} seconds",
            }
        except Exception as e:
            return {
                "success": False,
                "passed": 0,
                "failed": 0,
                "errors": 0,
                "skipped": 0,
                "total": 0,
                "duration_ms": 0,
                "results": [],
                "error": str(e),
            }

    def _parse_pytest_output(self, output: str) -> List[Dict[str, Any]]:
        """Parse pytest stdout to extract test results.

        Args:
            output: Pytest stdout text

        Returns:
            List of result dicts
        """
        results: List[Dict[str, Any]] = []
        lines = output.split("\n")

        for line in lines:
            # Look for test result lines like:
            # test_file.py::test_name PASSED
            # test_file.py::test_name FAILED
            if "::" in line and ("PASSED" in line or "FAILED" in line or "ERROR" in line or "SKIPPED" in line):
                parts = line.split("::")
                if len(parts) >= 2:
                    test_name = parts[-1].split()[0] if parts[-1] else ""

                    outcome = "unknown"
                    if "PASSED" in line:
                        outcome = "passed"
                    elif "FAILED" in line:
                        outcome = "failed"
                    elif "ERROR" in line:
                        outcome = "error"
                    elif "SKIPPED" in line:
                        outcome = "skipped"

                    # Get message if any
                    message = ""
                    if " - " in line:
                        msg_parts = line.split(" - ")
                        if len(msg_parts) > 1:
                            message = msg_parts[1].strip()

                    results.append({
                        "name": test_name,
                        "outcome": outcome,
                        "message": message,
                    })

        return results

    def _parse_json_report(self, json_data: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Parse pytest JSON report.

        Args:
            json_data: JSON report data

        Returns:
            List of result dicts
        """
        results: List[Dict[str, Any]] = []

        tests = json_data.get("tests", [])
        for test in tests:
            results.append({
                "name": test.get("nodeid", ""),
                "outcome": test.get("outcome", "unknown"),
                "message": test.get("call", {}).get("longrepr", ""),
            })

        return results