"""Test generator for creating pytest tests from Python source files."""

import ast
from pathlib import Path
from typing import Any, Dict, List


class TestGenerator:
    """Generator for creating pytest test files from Python source."""

    def test_generate(
        self, source_path: str, framework: str = "pytest"
    ) -> Dict[str, Any]:
        """Parse Python source file and generate pytest test file.

        Args:
            source_path: Path to the Python source file
            framework: Test framework to use (default: pytest)

        Returns:
            Dict with test_path, test_code, tests_count, functions_found,
            classes_found
        """
        try:
            source_file = Path(source_path)

            if not source_file.exists():
                return {
                    "test_path": "",
                    "test_code": "",
                    "tests_count": 0,
                    "functions_found": 0,
                    "classes_found": 0,
                    "error": f"Source file not found: {source_path}",
                }

            with open(source_file, "r", encoding="utf-8") as f:
                source_content = f.read()

            # Parse the AST
            tree = ast.parse(source_content, filename=str(source_file))

            # Extract functions and classes
            functions: List[Dict[str, Any]] = []
            classes: List[Dict[str, Any]] = []

            for node in ast.walk(tree):
                if isinstance(node, ast.FunctionDef):
                    if not node.name.startswith("_"):  # Skip private functions
                        functions.append({
                            "name": node.name,
                            "args": [arg.arg for arg in node.args.args],
                            "decorators": [d.id if isinstance(d, ast.Name) else str(d) for d in node.decorator_list],
                        })
                elif isinstance(node, ast.ClassDef):
                    if not node.name.startswith("_"):  # Skip private classes
                        classes.append({
                            "name": node.name,
                            "methods": [n.name for n in node.body if isinstance(n, ast.FunctionDef)],
                        })

            # Generate test code
            test_code = self._generate_test_code(
                source_file.stem,
                functions,
                classes,
                source_file.parent,
            )

            # Write test file
            tests_dir = source_file.parent / "tests"
            tests_dir.mkdir(exist_ok=True)

            test_file_name = f"test_{source_file.stem}.py"
            test_path = tests_dir / test_file_name

            with open(test_path, "w", encoding="utf-8") as f:
                f.write(test_code)

            return {
                "test_path": str(test_path),
                "test_code": test_code,
                "tests_count": len(functions) + sum(len(c.get("methods", [])) for c in classes),
                "functions_found": len(functions),
                "classes_found": len(classes),
                "error": None,
            }

        except Exception as e:
            return {
                "test_path": "",
                "test_code": "",
                "tests_count": 0,
                "functions_found": 0,
                "classes_found": 0,
                "error": str(e),
            }

    def _generate_test_code(
        self,
        module_name: str,
        functions: List[Dict[str, Any]],
        classes: List[Dict[str, Any]],
        source_dir: Path,
    ) -> str:
        """Generate pytest test code from parsed functions and classes.

        Args:
            module_name: Name of the module
            functions: List of function info
            classes: List of class info
            source_dir: Source directory for relative imports

        Returns:
            Generated test code as string
        """
        lines = [
            '"""Auto-generated tests for {}."""'.format(module_name),
            "",
            "import pytest",
            "",
        ]

        # Try to import the module
        try:
            lines.append("from {} import *".format(module_name))
        except ImportError:
            lines.append(f"# Could not auto-import {module_name}, import manually if needed")

        lines.append("")

        # Generate tests for standalone functions
        if functions:
            lines.append("# Standalone function tests")
            for func in functions:
                func_name = func["name"]
                args = func["args"]

                lines.append(f"def test_{func_name}():")
                lines.append(f'    """Test {func_name} function."""')

                if args:
                    # Add basic mock args based on types
                    test_args = ", ".join(self._generate_mock_args(args))
                    lines.append(f"    # result = {func_name}({test_args})")
                    lines.append("    # assert result is not None")
                    lines.append("    pass")
                else:
                    lines.append(f"    # result = {func_name}()")
                    lines.append("    # assert result is not None")
                    lines.append("    pass")

                lines.append("")

        # Generate tests for classes
        if classes:
            lines.append("# Class tests")
            for cls in classes:
                cls_name = cls["name"]
                methods = cls.get("methods", [])

                if methods:
                    lines.append(f"class Test{cls_name}:")
                    lines.append(f'    """Tests for {cls_name} class."""')
                    lines.append("")

                    for method in methods:
                        if not method.startswith("_"):  # Skip private methods
                            lines.append(f"    def test_{method}(self):")
                            lines.append(f'        """Test {method} method."""')
                            lines.append("        pass")
                            lines.append("")

        return "\n".join(lines)

    def _generate_mock_args(self, arg_names: List[str]) -> List[str]:
        """Generate mock arguments based on common naming patterns.

        Args:
            arg_names: List of argument names

        Returns:
            List of mock values as strings
        """
        mocks = []
        for name in arg_names:
            name_lower = name.lower()

            # Common patterns
            if "id" in name_lower:
                mocks.append("1")
            elif "name" in name_lower:
                mocks.append('"test_name"')
            elif "path" in name_lower:
                mocks.append('"/tmp/test"')
            elif "file" in name_lower:
                mocks.append('"test.txt"')
            elif "url" in name_lower:
                mocks.append('"http://example.com"')
            elif "count" in name_lower or "num" in name_lower or "limit" in name_lower:
                mocks.append("10")
            elif "flag" in name_lower or "is_" in name_lower or "enabled" in name_lower:
                mocks.append("True")
            elif "data" in name_lower or "body" in name_lower:
                mocks.append('{"key": "value"}')
            else:
                mocks.append("None")

        return mocks