"""Coverage analyzer for Python code coverage analysis."""

import json
import subprocess
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Any, Dict, List


class CoverageAnalyzer:
    """Analyzer for Python code coverage using coverage.py."""

    def test_coverage(self, path: str) -> Dict[str, Any]:
        """Run coverage analysis on a Python file/directory.

        Args:
            path: Path to Python file or directory

        Returns:
            Dict with files list, total_statements, total_missing,
            total_coverage_pct
        """
        try:
            test_path = Path(path)

            if not test_path.exists():
                return {
                    "files": [],
                    "total_statements": 0,
                    "total_missing": 0,
                    "total_coverage_pct": 0,
                    "error": f"Path not found: {path}",
                }

            # Run coverage with pytest
            # First, check if coverage is available
            try:
                subprocess.run(
                    ["coverage", "--version"],
                    capture_output=True,
                    check=True,
                )
            except (subprocess.CalledProcessError, FileNotFoundError):
                return {
                    "files": [],
                    "total_statements": 0,
                    "total_missing": 0,
                    "total_coverage_pct": 0,
                    "error": "coverage.py not installed. Install with: pip install coverage",
                }

            # Create .coveragerc for minimal config
            coveragerc = Path(".coveragerc")
            if not coveragerc.exists():
                with open(coveragerc, "w") as f:
                    f.write("")

            # Run coverage run
            subprocess.run(
                ["coverage", "run", "-m", "pytest", str(test_path), "-q"],
                capture_output=True,
                text=True,
                timeout=120,
            )

            # Generate JSON report
            subprocess.run(
                ["coverage", "json", "-o", "coverage.json"],
                capture_output=True,
                text=True,
            )

            # Parse JSON report
            json_file = Path("coverage.json")
            files: List[Dict[str, Any]] = []
            total_statements = 0
            total_missing = 0

            if json_file.exists():
                with open(json_file, "r") as f:
                    coverage_data = json.load(f)

                for filename, data in coverage_data.get("files", {}).items():
                    # Skip __init__ and test files
                    if "__init__" in filename or filename.endswith("_test.py") or filename.startswith("test_"):
                        continue

                    statements = data.get("num_statements", 0)
                    missing = data.get("missing_branches", 0) + data.get("missed_statements", 0)
                    covered = statements - missing
                    coverage_pct = (covered / statements * 100) if statements > 0 else 0

                    files.append({
                        "filename": filename,
                        "statements": statements,
                        "missing": missing,
                        "coverage_pct": round(coverage_pct, 2),
                    })

                    total_statements += statements
                    total_missing += missing

                # Clean up
                json_file.unlink()

            # Calculate total coverage
            total_covered = total_statements - total_missing
            total_coverage_pct = (total_covered / total_statements * 100) if total_statements > 0 else 0

            # Try to parse XML for additional info
            xml_file = Path("coverage.xml")
            if xml_file.exists():
                try:
                    tree = ET.parse(xml_file)
                    root = tree.getroot()

                    for package in root.findall(".//class"):
                        filename = package.get("filename", "")
                        if filename and any(f["filename"] == filename for f in files):
                            lines_covered = int(package.get("line-rate", 0) * 100)
                            for f in files:
                                if f["filename"] == filename:
                                    f["line_coverage_pct"] = lines_covered
                except Exception:
                    pass

                xml_file.unlink()

            # Clean up coverage files
            for cov_file in [".coverage", ".coveragerc"]:
                cov_path = Path(cov_file)
                if cov_path.exists():
                    cov_path.unlink()

            return {
                "files": files,
                "total_statements": total_statements,
                "total_missing": total_missing,
                "total_coverage_pct": round(total_coverage_pct, 2),
                "error": None,
            }

        except subprocess.TimeoutExpired:
            return {
                "files": [],
                "total_statements": 0,
                "total_missing": 0,
                "total_coverage_pct": 0,
                "error": "Coverage analysis timed out after 120 seconds",
            }
        except Exception as e:
            return {
                "files": [],
                "total_statements": 0,
                "total_missing": 0,
                "total_coverage_pct": 0,
                "error": str(e),
            }