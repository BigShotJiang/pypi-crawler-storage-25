"""Database inspector for schema inspection."""

from typing import Optional

from sqlalchemy import create_engine, inspect
from sqlalchemy.engine import Engine
from sqlalchemy.pool import StaticPool

from shared.errors import DatabaseError


class DbInspector:
    """Inspector for database schema information."""

    def __init__(self):
        self.engine: Optional[Engine] = None

    def _ensure_connected(self, connection_string: str) -> Engine:
        """Ensure inspector is connected to the database."""
        if self.engine is None:
            if connection_string.startswith("sqlite"):
                self.engine = create_engine(
                    connection_string,
                    connect_args={"check_same_thread": False},
                    poolclass=StaticPool,
                )
            else:
                self.engine = create_engine(connection_string)
        return self.engine

    def list_tables(self, connection: str) -> dict:
        """List all tables in the database.

        Args:
            connection: Database connection string

        Returns:
            Dict with table list
        """
        try:
            engine = self._ensure_connected(connection)
            inspector = inspect(engine)
            tables = inspector.get_table_names()

            return {
                "tables": tables,
                "count": len(tables),
            }
        except Exception as e:
            raise DatabaseError(f"Failed to list tables: {e}")

    def describe_table(self, connection: str, table: str) -> dict:
        """Get detailed information about a table.

        Args:
            connection: Database connection string
            table: Table name

        Returns:
            Dict with table description
        """
        try:
            engine = self._ensure_connected(connection)
            inspector = inspect(engine)

            columns = inspector.get_columns(table)
            primary_keys = inspector.get_pk_constraint(table)
            foreign_keys = inspector.get_foreign_keys(table)

            column_info = []
            for col in columns:
                column_info.append({
                    "name": col["name"],
                    "type": str(col["type"]),
                    "nullable": col["nullable"],
                    "default": col.get("default"),
                })

            return {
                "table": table,
                "columns": column_info,
                "primary_keys": primary_keys.get("constrained_columns", []),
                "foreign_keys": [
                    {
                        "columns": fk["constrained_columns"],
                        "referred_table": fk["referred_table"],
                        "referred_columns": fk["referred_columns"],
                    }
                    for fk in foreign_keys
                ],
            }
        except Exception as e:
            raise DatabaseError(f"Failed to describe table: {e}")

    def list_indexes(self, connection: str, table: Optional[str] = None) -> dict:
        """List all indexes in the database or for a specific table.

        Args:
            connection: Database connection string
            table: Optional table name to get indexes for

        Returns:
            Dict with index list
        """
        try:
            engine = self._ensure_connected(connection)
            inspector = inspect(engine)

            if table:
                indexes = inspector.get_indexes(table)
                return {
                    "table": table,
                    "indexes": indexes,
                    "count": len(indexes),
                }
            else:
                tables = inspector.get_table_names()
                all_indexes = {}

                for tbl in tables:
                    indexes = inspector.get_indexes(tbl)
                    if indexes:
                        all_indexes[tbl] = indexes

                return {
                    "indexes_by_table": all_indexes,
                    "total": sum(len(idx) for idx in all_indexes.values()),
                }
        except Exception as e:
            raise DatabaseError(f"Failed to list indexes: {e}")

    def list_foreign_keys(self, connection: str, table: Optional[str] = None) -> dict:
        """List all foreign keys in the database or for a specific table.

        Args:
            connection: Database connection string
            table: Optional table name to get foreign keys for

        Returns:
            Dict with foreign key list
        """
        try:
            engine = self._ensure_connected(connection)
            inspector = inspect(engine)

            if table:
                foreign_keys = inspector.get_foreign_keys(table)
                return {
                    "table": table,
                    "foreign_keys": foreign_keys,
                    "count": len(foreign_keys),
                }
            else:
                tables = inspector.get_table_names()
                all_fks = {}

                for tbl in tables:
                    fks = inspector.get_foreign_keys(tbl)
                    if fks:
                        all_fks[tbl] = fks

                return {
                    "foreign_keys_by_table": all_fks,
                    "total": sum(len(fks) for fks in all_fks.values()),
                }
        except Exception as e:
            raise DatabaseError(f"Failed to list foreign keys: {e}")