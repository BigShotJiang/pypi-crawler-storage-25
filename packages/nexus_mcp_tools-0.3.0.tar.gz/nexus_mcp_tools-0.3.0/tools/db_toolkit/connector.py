"""Database connector for SQLite and PostgreSQL."""

from typing import List, Optional

from sqlalchemy import create_engine, text
from sqlalchemy.engine import Engine
from sqlalchemy.pool import StaticPool

from shared.config import get_config
from shared.errors import DatabaseError


class DbConnector:
    """Database connector supporting SQLite and PostgreSQL."""

    def __init__(self, connection_string: Optional[str] = None):
        config = get_config()
        self.echo = config.db_echo
        self.engine: Optional[Engine] = None
        self.connection_string = connection_string

    def connect(self, connection_string: Optional[str] = None) -> dict:
        """Connect to a database.

        Args:
            connection_string: Database connection string

        Returns:
            Dict with connection info
        """
        conn_str = connection_string or self.connection_string
        if not conn_str:
            raise DatabaseError("No connection string provided")

        try:
            if conn_str.startswith("sqlite"):
                self.engine = create_engine(
                    conn_str,
                    echo=self.echo,
                    connect_args={"check_same_thread": False},
                    poolclass=StaticPool,
                )
            else:
                self.engine = create_engine(conn_str, echo=self.echo)

            self.connection_string = conn_str

            with self.engine.connect() as conn:
                conn.execute(text("SELECT 1"))

            return {
                "success": True,
                "connection_string": conn_str,
                "dialect": self.engine.dialect.name,
            }
        except Exception as e:
            raise DatabaseError(f"Failed to connect to database: {e}")

    def execute(self, sql: str, params: Optional[dict] = None) -> dict:
        """Execute a SQL statement.

        Args:
            sql: SQL statement to execute
            params: Optional parameters for the query

        Returns:
            Dict with execution result
        """
        if self.engine is None:
            raise DatabaseError("Not connected to database")

        try:
            with self.engine.connect() as conn:
                result = conn.execute(text(sql), params or {})
                conn.commit()

                if result.returns_rows:
                    rows = [dict(row._mapping) for row in result]
                    return {
                        "success": True,
                        "rowcount": result.rowcount,
                        "rows": rows,
                    }
                else:
                    return {
                        "success": True,
                        "rowcount": result.rowcount,
                    }
        except Exception as e:
            raise DatabaseError(f"Failed to execute SQL: {e}")

    def execute_many(self, sql: str, params_list: List[dict]) -> dict:
        """Execute a SQL statement with multiple parameter sets.

        Args:
            sql: SQL statement to execute
            params_list: List of parameter dicts

        Returns:
            Dict with execution result
        """
        if self.engine is None:
            raise DatabaseError("Not connected to database")

        if not params_list:
            raise DatabaseError("No parameters provided")

        try:
            with self.engine.connect() as conn:
                result = conn.execute(text(sql), params_list)
                conn.commit()

                return {
                    "success": True,
                    "rowcount": result.rowcount,
                    "batch_size": len(params_list),
                }
        except Exception as e:
            raise DatabaseError(f"Failed to execute batch SQL: {e}")

    def close(self) -> dict:
        """Close the database connection.

        Returns:
            Dict with close result
        """
        if self.engine is not None:
            self.engine.dispose()
            self.engine = None

        return {
            "success": True,
        }