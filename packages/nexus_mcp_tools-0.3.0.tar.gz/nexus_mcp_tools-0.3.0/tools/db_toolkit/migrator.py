"""Database migration runner."""

import os
from datetime import datetime
from typing import Dict, Optional

from sqlalchemy import create_engine, text
from sqlalchemy.engine import Engine
from sqlalchemy.pool import StaticPool


class MigrationRunner:
    """Runner for database migrations with UP/DOWN markers."""

    def __init__(self):
        self.engine: Optional[Engine] = None

    def _ensure_connected(self, connection_string: str) -> Engine:
        """Ensure runner is connected to the database."""
        if self.engine is None:
            if connection_string.startswith("sqlite"):
                self.engine = create_engine(
                    connection_string,
                    connect_args={"check_same_thread": False},
                    poolclass=StaticPool,
                )
            else:
                self.engine = create_engine(connection_string)
        return self.engine

    def _parse_migration_file(self, content: str) -> Dict[str, str]:
        """Parse a migration file into UP and DOWN sections.

        Args:
            content: Content of migration file

        Returns:
            Dict with 'up' and 'down' SQL
        """
        up_parts = []
        down_parts = []
        current_section = None

        for line in content.split("\n"):
            line = line.strip()

            if line.startswith("--UP"):
                current_section = "up"
            elif line.startswith("--DOWN"):
                current_section = "down"
            elif line.startswith("--") or not line:
                continue
            elif current_section == "up":
                up_parts.append(line)
            elif current_section == "down":
                down_parts.append(line)

        return {
            "up": " ".join(up_parts),
            "down": " ".join(down_parts),
        }

    def create_migration(self, name: str, migration_dir: str) -> dict:
        """Create a new migration file.

        Args:
            name: Migration name (will be prefixed with timestamp)
            migration_dir: Directory to create migration file in

        Returns:
            Dict with migration file path
        """
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"{timestamp}_{name}.sql"
        filepath = os.path.join(migration_dir, filename)

        template = """--UP
-- Your UP migration SQL here
--DOWN
-- Your DOWN migration SQL here
"""

        os.makedirs(migration_dir, exist_ok=True)

        with open(filepath, "w") as f:
            f.write(template)

        return {
            "success": True,
            "filename": filename,
            "path": filepath,
        }

    def list_pending(self, connection: str, migration_dir: str) -> dict:
        """List pending migrations not yet applied.

        Args:
            connection: Database connection string
            migration_dir: Directory containing migration files

        Returns:
            Dict with pending migrations
        """
        engine = self._ensure_connected(connection)

        with engine.connect() as conn:
            conn.execute(text("""
                CREATE TABLE IF NOT EXISTS schema_migrations (
                    version TEXT PRIMARY KEY,
                    applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """))
            conn.commit()

            result = conn.execute(text("SELECT version FROM schema_migrations"))
            applied = {row[0] for row in result}

        if not os.path.isdir(migration_dir):
            return {
                "pending": [],
                "count": 0,
            }

        migration_files = [f for f in os.listdir(migration_dir) if f.endswith(".sql")]
        migration_files.sort()

        pending = [f for f in migration_files if f.replace(".sql", "") not in applied]

        return {
            "pending": pending,
            "count": len(pending),
        }

    def run_migrations(self, connection: str, migration_dir: str) -> dict:
        """Run all pending migrations.

        Args:
            connection: Database connection string
            migration_dir: Directory containing migration files

        Returns:
            Dict with migration results
        """
        pending = self.list_pending(connection, migration_dir)

        if not pending["pending"]:
            return {
                "success": True,
                "applied": [],
                "count": 0,
            }

        engine = self._ensure_connected(connection)
        applied = []

        for migration_file in pending["pending"]:
            filepath = os.path.join(migration_dir, migration_file)

            with open(filepath, "r") as f:
                content = f.read()

            parsed = self._parse_migration_file(content)
            version = migration_file.replace(".sql", "")

            try:
                with engine.connect() as conn:
                    conn.execute(text(parsed["up"]))
                    conn.execute(
                        text("INSERT INTO schema_migrations (version) VALUES (:version)"),
                        {"version": version},
                    )
                    conn.commit()

                applied.append({
                    "file": migration_file,
                    "success": True,
                })
            except Exception as e:
                return {
                    "success": False,
                    "applied": applied,
                    "failed": migration_file,
                    "error": str(e),
                }

        return {
            "success": True,
            "applied": applied,
            "count": len(applied),
        }

    def rollback(self, connection: str, migration_dir: str, steps: int = 1) -> dict:
        """Rollback migrations.

        Args:
            connection: Database connection string
            migration_dir: Directory containing migration files
            steps: Number of migrations to rollback

        Returns:
            Dict with rollback results
        """
        engine = self._ensure_connected(connection)

        with engine.connect() as conn:
            result = conn.execute(
                text("SELECT version FROM schema_migrations ORDER BY applied_at DESC LIMIT :limit"),
                {"limit": steps},
            )
            to_rollback = [row[0] for row in result]

        if not to_rollback:
            return {
                "success": True,
                "rolled_back": [],
                "count": 0,
            }

        rolled_back = []

        for version in to_rollback:
            migration_file = f"{version}.sql"
            filepath = os.path.join(migration_dir, migration_file)

            if not os.path.exists(filepath):
                rolled_back.append({
                    "version": version,
                    "success": False,
                    "error": "Migration file not found",
                })
                continue

            with open(filepath, "r") as f:
                content = f.read()

            parsed = self._parse_migration_file(content)

            try:
                with engine.connect() as conn:
                    if parsed["down"]:
                        conn.execute(text(parsed["down"]))
                    conn.execute(text("DELETE FROM schema_migrations WHERE version = :version"), {"version": version})
                    conn.commit()

                rolled_back.append({
                    "version": version,
                    "success": True,
                })
            except Exception as e:
                return {
                    "success": False,
                    "rolled_back": rolled_back,
                    "error": str(e),
                }

        return {
            "success": True,
            "rolled_back": rolled_back,
            "count": len(rolled_back),
        }