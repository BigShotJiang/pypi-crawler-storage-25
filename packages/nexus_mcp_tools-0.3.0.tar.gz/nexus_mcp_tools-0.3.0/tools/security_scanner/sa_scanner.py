"""Static Analysis Scanner - AST-based security scanning for Python files."""

import ast
from pathlib import Path
from typing import Any


class SAScanner:
    """AST-based static analysis scanner for Python files."""

    # Dangerous patterns to look for
    DANGEROUS_PATTERNS = {
        "eval": {
            "severity": "high",
            "message": "Use of eval() can lead to code injection vulnerabilities",
        },
        "exec": {
            "severity": "high",
            "message": "Use of exec() can lead to code injection vulnerabilities",
        },
    }

    # Dangerous imports
    DANGEROUS_IMPORTS = {
        "pickle": {
            "severity": "high",
            "message": "pickle can execute arbitrary code - use JSON for untrusted data",
        },
        "subprocess": {
            "severity": "high",
            "message": "subprocess can execute shell commands - ensure input is sanitized",
        },
        "shutil": {
            "severity": "medium",
            "message": "shutil can perform dangerous file operations",
        },
        "pty": {
            "severity": "high",
            "message": "pty can create pseudo-terminals - potential for privilege escalation",
        },
        "commands": {
            "severity": "high",
            "message": "commands module is deprecated and unsafe",
        },
        "os.system": {
            "severity": "high",
            "message": "os.system executes shell commands - consider subprocess instead",
        },
    }

    def scan_file(self, path: str) -> dict[str, Any]:
        """Scan a single Python file for security issues.

        Args:
            path: Path to Python file

        Returns:
            Dict with findings, file, total_findings
        """
        findings = []
        path_obj = Path(path)

        if not path_obj.exists():
            return {
                "findings": [],
                "file": path,
                "total_findings": 0,
                "error": f"File does not exist: {path}",
            }

        if path_obj.suffix != ".py":
            return {
                "findings": [],
                "file": path,
                "total_findings": 0,
                "error": "Not a Python file",
            }

        try:
            content = path_obj.read_text(encoding="utf-8")
            tree = ast.parse(content, filename=str(path))
            finder = SecurityFindingVisitor(str(path_obj))
            finder.visit(tree)
            findings = finder.findings

        except SyntaxError as e:
            findings.append({
                "file": str(path),
                "line": e.lineno or 0,
                "type": "syntax_error",
                "message": f"Syntax error: {e.msg}",
                "severity": "low",
            })
        except Exception as e:
            return {
                "findings": [],
                "file": path,
                "total_findings": 0,
                "error": f"Failed to parse: {e}",
            }

        return {
            "findings": findings,
            "file": path,
            "total_findings": len(findings),
        }

    def scan_directory(self, path: str) -> dict[str, Any]:
        """Scan all Python files in a directory.

        Args:
            path: Path to directory

        Returns:
            Dict with findings, total_files, total_findings
        """
        findings = []
        total_files = 0
        path_obj = Path(path)

        if not path_obj.exists():
            return {
                "findings": [],
                "total_files": 0,
                "total_findings": 0,
                "error": f"Path does not exist: {path}",
            }

        if path_obj.is_file():
            result = self.scan_file(str(path_obj))
            return {
                "findings": result.get("findings", []),
                "total_files": 1,
                "total_findings": result.get("total_findings", 0),
            }

        # Scan all .py files in directory
        for py_file in path_obj.rglob("*.py"):
            # Skip common non-source directories
            if any(skip in py_file.parts for skip in [".venv", "venv", "__pycache__", ".git"]):
                continue

            total_files += 1
            result = self.scan_file(str(py_file))
            findings.extend(result.get("findings", []))

        return {
            "findings": findings,
            "total_files": total_files,
            "total_findings": len(findings),
        }


class SecurityFindingVisitor(ast.NodeVisitor):
    """AST visitor to find security issues."""

    def __init__(self, filename: str):
        self.filename = filename
        self.findings: list[dict[str, Any]] = []
        self.in_assert = False

    def visit_Call(self, node: ast.Call) -> None:
        """Check for dangerous function calls."""
        # Check for eval()
        if isinstance(node.func, ast.Name) and node.func.id == "eval":
            self.findings.append({
                "file": self.filename,
                "line": node.lineno or 0,
                "type": "dangerous_function",
                "message": self._get_pattern_info("eval")["message"],
                "severity": self._get_pattern_info("eval")["severity"],
            })

        # Check for exec()
        if isinstance(node.func, ast.Name) and node.func.id == "exec":
            self.findings.append({
                "file": self.filename,
                "line": node.lineno or 0,
                "type": "dangerous_function",
                "message": self._get_pattern_info("exec")["message"],
                "severity": self._get_pattern_info("exec")["severity"],
            })

        # Check for __import__
        if isinstance(node.func, ast.Name) and node.func.id == "__import__":
            self.findings.append({
                "file": self.filename,
                "line": node.lineno or 0,
                "type": "dynamic_import",
                "message": "Dynamic import can execute arbitrary code",
                "severity": "high",
            })

        self.generic_visit(node)

    def visit_Import(self, node: ast.Import) -> None:
        """Check for dangerous imports."""
        for alias in node.names:
            if alias.name in self._get_dangerous_imports():
                info = self._get_dangerous_imports()[alias.name]
                self.findings.append({
                    "file": self.filename,
                    "line": node.lineno or 0,
                    "type": "dangerous_import",
                    "message": info["message"],
                    "severity": info["severity"],
                })

        self.generic_visit(node)

    def visit_ImportFrom(self, node: ast.ImportFrom) -> None:
        """Check for dangerous imports from modules."""
        if node.module:
            # Check for dangerous imports like from os import system
            if node.module == "os" and node.names:
                for alias in node.names:
                    if alias.name == "system":
                        self.findings.append({
                            "file": self.filename,
                            "line": node.lineno or 0,
                            "type": "dangerous_import",
                            "message": self._get_dangerous_imports()["os.system"]["message"],
                            "severity": self._get_dangerous_imports()["os.system"]["severity"],
                        })

            # Check other dangerous modules
            if node.module in self._get_dangerous_imports():
                info = self._get_dangerous_imports()[node.module]
                self.findings.append({
                    "file": self.filename,
                    "line": node.lineno or 0,
                    "type": "dangerous_import",
                    "message": info["message"],
                    "severity": info["severity"],
                })

        self.generic_visit(node)

    def visit_Assert(self, node: ast.Assert) -> None:
        """Check for assert statements (can be disabled in production)."""
        self.findings.append({
            "file": self.filename,
            "line": node.lineno or 0,
            "type": "assert_statement",
            "message": "Assert statements are disabled in optimized Python - use proper validation",
            "severity": "low",
        })
        self.generic_visit(node)

    def visit_Assign(self, node: ast.Assign) -> None:
        """Check for wildcard imports in assignments."""
        # Check for imports like: from xxx import *
        if isinstance(node.value, ast.ImportFrom) and node.value.names:
            for alias in node.value.names:
                if alias.name == "*":
                    self.findings.append({
                        "file": self.filename,
                        "line": node.lineno or 0,
                        "type": "wildcard_import",
                        "message": "Wildcard imports pollute namespace and can cause conflicts",
                        "severity": "medium",
                    })
        self.generic_visit(node)

    def _get_pattern_info(self, pattern: str) -> dict[str, str]:
        """Get pattern information."""
        patterns = {
            "eval": {
                "severity": "high",
                "message": "Use of eval() can lead to code injection vulnerabilities",
            },
            "exec": {
                "severity": "high",
                "message": "Use of exec() can lead to code injection vulnerabilities",
            },
        }
        return patterns.get(pattern, {"severity": "medium", "message": "Unknown issue"})

    def _get_dangerous_imports(self) -> dict[str, dict[str, str]]:
        """Get list of dangerous imports."""
        return {
            "pickle": {
                "severity": "high",
                "message": "pickle can execute arbitrary code - use JSON for untrusted data",
            },
            "subprocess": {
                "severity": "high",
                "message": "subprocess can execute shell commands - ensure input is sanitized",
            },
            "shutil": {
                "severity": "medium",
                "message": "shutil can perform dangerous file operations",
            },
            "pty": {
                "severity": "high",
                "message": "pty can create pseudo-terminals - potential for privilege escalation",
            },
            "commands": {
                "severity": "high",
                "message": "commands module is deprecated and unsafe",
            },
            "os": {
                "severity": "medium",
                "message": "os module has many potentially dangerous functions",
            },
        }