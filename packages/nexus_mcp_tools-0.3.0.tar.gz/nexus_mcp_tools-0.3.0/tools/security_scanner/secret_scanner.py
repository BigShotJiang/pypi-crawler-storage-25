"""Secret Scanner - Scan files for sensitive information leaks."""

import re
from pathlib import Path
from typing import Any


class SecretScanner:
    """Scan files for hardcoded secrets, API keys, and credentials."""

    # Regex patterns for various secret types
    PATTERNS = {
        "AWS_ACCESS_KEY": {
            "pattern": r"(?i)(aws_access_key_id|aws_secret_access_key|aws_access_key)\s*[=:]\s*([A-Z0-9]{16,})",
            "severity": "critical",
            "description": "AWS Access Key",
        },
        "AWS_SECRET": {
            "pattern": r"(?i)aws_secret_access_key\s*[=:]\s*([A-Za-z0-9/+=]{40})",
            "severity": "critical",
            "description": "AWS Secret Key",
        },
        "GITHUB_TOKEN": {
            "pattern": r"(?i)(ghp_|gho_|ghu_|ghs_|ghr_)[A-Za-z0-9_]{36,}",
            "severity": "high",
            "description": "GitHub Token",
        },
        "SLACK_TOKEN": {
            "pattern": r"xox[baprs]-[0-9]{10,}-[0-9]{10,}-[a-zA-Z0-9]{24,}",
            "severity": "high",
            "description": "Slack Token",
        },
        "SSH_PRIVATE_KEY": {
            "pattern": r"-----BEGIN (RSA|DSA|EC|OPENSSH) PRIVATE KEY-----",
            "severity": "critical",
            "description": "SSH Private Key",
        },
        "JWT_TOKEN": {
            "pattern": r"eyJ[A-Za-z0-9-_]+\.eyJ[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+",
            "severity": "high",
            "description": "JWT Token",
        },
        "GENERIC_PASSWORD": {
            "pattern": r"(?i)(password|passwd|pwd|secret)\s*[=:]\s*['\"]?([A-Za-z0-9!@#$%^&*()_+=-]{8,})['\"]?",
            "severity": "medium",
            "description": "Generic Password",
        },
        "API_KEY": {
            "pattern": r"(?i)(api[_-]?key|apikey|api[_-]?secret)\s*[=:]\s*['\"]?([A-Za-z0-9]{20,})['\"]?",
            "severity": "high",
            "description": "API Key",
        },
        "PRIVATE_KEY": {
            "pattern": r"-----BEGIN PRIVATE KEY-----",
            "severity": "critical",
            "description": "Private Key",
        },
    }

    # Directories to skip
    SKIP_DIRS = {".venv", "node_modules", ".git", "__pycache__", ".ruff_cache"}

    # File extensions to scan
    SCANNABLE_EXTENSIONS = {
        ".py", ".js", ".ts", ".json", ".yaml", ".yml", ".txt",
        ".env", ".conf", ".config", ".sh", ".bash", ".zsh",
        ".pem", ".key", ".sql", ".xml", ".properties"
    }

    def scan_path(self, path: str) -> dict[str, Any]:
        """Scan a directory or file for secrets.

        Args:
            path: Path to scan (file or directory)

        Returns:
            Dict with findings, total_files, total_findings
        """
        findings = []
        total_files = 0
        path_obj = Path(path)

        if not path_obj.exists():
            return {
                "findings": [],
                "total_files": 0,
                "total_findings": 0,
                "error": f"Path does not exist: {path}",
            }

        if path_obj.is_file():
            total_files = 1
            findings = self._scan_file(path_obj)
        else:
            for file_path in self._iter_files(path_obj):
                total_files += 1
                file_findings = self._scan_file(file_path)
                findings.extend(file_findings)

        return {
            "findings": findings,
            "total_files": total_files,
            "total_findings": len(findings),
        }

    def _iter_files(self, root: Path) -> list[Path]:
        """Iterate over all scannable files in a directory."""
        files = []
        for item in root.rglob("*"):
            if item.is_file():
                # Skip binary files and non-scannable extensions
                if item.suffix.lower() not in self.SCANNABLE_EXTENSIONS:
                    continue
                # Skip directories in skip list
                if any(skip in item.parts for skip in self.SKIP_DIRS):
                    continue
                files.append(item)
        return files

    def _scan_file(self, file_path: Path) -> list[dict[str, Any]]:
        """Scan a single file for secrets."""
        findings = []

        try:
            # Check if file is binary
            if self._is_binary(file_path):
                return []

            # Read file content
            try:
                content = file_path.read_text(encoding="utf-8", errors="ignore")
            except Exception:
                return []

            # Scan each line
            for line_num, line in enumerate(content.splitlines(), start=1):
                for secret_type, config in self.PATTERNS.items():
                    matches = re.finditer(config["pattern"], line)
                    for match in matches:
                        # Get snippet (surrounding context)
                        snippet = line.strip()
                        if len(snippet) > 100:
                            snippet = snippet[:100] + "..."

                        findings.append({
                            "file": str(file_path),
                            "line": line_num,
                            "type": config["description"],
                            "severity": config["severity"],
                            "snippet": snippet,
                        })

        except Exception:
            pass

        return findings

    def _is_binary(self, file_path: Path) -> bool:
        """Check if a file is binary."""
        try:
            with open(file_path, "rb") as f:
                chunk = f.read(1024)
                # Check for null bytes (common in binary files)
                return b"\x00" in chunk
        except Exception:
            return True