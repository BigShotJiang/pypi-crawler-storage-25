"""Dependency Checker - Scan for vulnerable/outdated packages."""

import re
import json
from pathlib import Path
from typing import Any


class DepChecker:
    """Check dependencies for vulnerabilities and outdated versions."""

    # Mock vulnerability database (in production, would use CVE API)
    KNOWN_VULNERABILITIES = {
        "requests": {
            "<2.20.0": {
                "advisory": "CVE-2018-18074: Insufficient header validation",
                "severity": "high",
            },
            "<2.19.0": {
                "advisory": "CVE-2018-14731: CRLF injection vulnerability",
                "severity": "medium",
            },
        },
        "urllib3": {
            "<1.24": {
                "advisory": "CVE-2019-11236: Open redirect vulnerability",
                "severity": "medium",
            },
            "<1.25.9": {
                "advisory": "CVE-2020-26116: Incomplete fix for CRLF injection",
                "severity": "high",
            },
        },
        "flask": {
            "<0.12.3": {
                "advisory": "CVE-2018-1000656: Debug mode XSS vulnerability",
                "severity": "medium",
            },
            "<1.0": {
                "advisory": "CVE-2017-14695: JSON security vulnerability",
                "severity": "high",
            },
        },
        "django": {
            "<2.2.10": {
                "advisory": "CVE-2020-7471: SQL injection via StringAgg",
                "severity": "critical",
            },
            "<3.0.3": {
                "advisory": "CVE-2020-9315: XSS in admin panel",
                "severity": "high",
            },
        },
        "numpy": {
            "<1.16.0": {
                "advisory": "CVE-2019-6446: Arbitrary code execution",
                "severity": "critical",
            },
        },
        "pillow": {
            "<6.2.0": {
                "advisory": "CVE-2019-10172: Float overflow vulnerability",
                "severity": "high",
            },
        },
        "pyyaml": {
            "<5.3.1": {
                "advisory": "CVE-2020-14343: Arbitrary code execution",
                "severity": "critical",
            },
        },
        "jinja2": {
            "<2.11.3": {
                "advisory": "CVE-2024-22195: XSS vulnerability",
                "severity": "high",
            },
        },
        "setuptools": {
            "<45.0.0": {
                "advisory": "CVE-2020-14339: Remote code execution",
                "severity": "critical",
            },
        },
        "cryptography": {
            "<3.2": {
                "advisory": "CVE-2020-36242: Memory corruption vulnerability",
                "severity": "high",
            },
        },
    }

    # Latest stable versions (mock data)
    LATEST_VERSIONS = {
        "requests": "2.31.0",
        "urllib3": "2.2.2",
        "flask": "3.0.3",
        "django": "5.0.6",
        "numpy": "1.26.4",
        "pillow": "10.3.0",
        "pyyaml": "6.0.1",
        "jinja2": "3.1.4",
        "setuptools": "70.0.0",
        "cryptography": "43.0.0",
        "aiohttp": "3.9.5",
        "sqlalchemy": "2.0.30",
        "fastapi": "0.111.0",
        "uvicorn": "0.30.0",
        "pydantic": "2.7.4",
    }

    def check_pip(self, path: str) -> dict[str, Any]:
        """Check Python dependencies for vulnerabilities.

        Args:
            path: Path to scan (directory with requirements.txt or pyproject.toml)

        Returns:
            Dict with vulnerabilities, unversioned, total
        """
        vulnerabilities = []
        unversioned = []
        path_obj = Path(path)

        # Find dependency files
        req_file = path_obj / "requirements.txt"
        pyproject = path_obj / "pyproject.toml"

        deps = []

        if req_file.exists():
            deps.extend(self._parse_requirements(req_file))
        if pyproject.exists():
            deps.extend(self._parse_pyproject(pyproject))

        # Check each dependency
        for dep in deps:
            pkg_name = dep["name"].lower()
            version = dep.get("version", "")

            # Check for versioned dependency
            if not version:
                unversioned.append(pkg_name)
                continue

            # Check for known vulnerabilities
            if pkg_name in self.KNOWN_VULNERABILITIES:
                for vuln_version, vuln_info in self.KNOWN_VULNERABILITIES[pkg_name].items():
                    if self._version_compare(version, "<", vuln_version):
                        vulnerabilities.append({
                            "package": pkg_name,
                            "current_version": version,
                            "advisory": vuln_info["advisory"],
                            "severity": vuln_info["severity"],
                        })

            # Check if outdated
            if pkg_name in self.LATEST_VERSIONS:
                latest = self.LATEST_VERSIONS[pkg_name]
                if self._version_compare(version, "<", latest):
                    # Only flag as vulnerability if we already found a CVE
                    # Otherwise just note it's outdated
                    has_cve = any(v["package"] == pkg_name for v in vulnerabilities)
                    if not has_cve:
                        vulnerabilities.append({
                            "package": pkg_name,
                            "current_version": version,
                            "advisory": f"Outdated. Latest: {latest}",
                            "severity": "low",
                        })

        return {
            "vulnerabilities": vulnerabilities,
            "unversioned": unversioned,
            "total": len(vulnerabilities) + len(unversioned),
        }

    def check_npm(self, path: str) -> dict[str, Any]:
        """Check npm dependencies for vulnerabilities.

        Args:
            path: Path to scan (directory with package.json)

        Returns:
            Dict with vulnerabilities, unversioned, total
        """
        vulnerabilities = []
        unversioned = []
        path_obj = Path(path)

        pkg_file = path_obj / "package.json"

        if not pkg_file.exists():
            return {
                "vulnerabilities": [],
                "unversioned": [],
                "total": 0,
                "error": "package.json not found",
            }

        try:
            with open(pkg_file, "r", encoding="utf-8") as f:
                pkg_data = json.load(f)
        except Exception as e:
            return {
                "vulnerabilities": [],
                "unversioned": [],
                "total": 0,
                "error": f"Failed to parse package.json: {e}",
            }

        # Check both dependencies and devDependencies
        all_deps = {}
        all_deps.update(pkg_data.get("dependencies", {}))
        all_deps.update(pkg_data.get("devDependencies", {}))

        for pkg_name, version in all_deps.items():
            # Handle version ranges (e.g., "^1.0.0", "~1.0.0")
            if version.startswith(("^", "~", ">=", "<=", ">", "<")):
                unversioned.append(pkg_name)
                continue
            if version == "*" or version == "latest":
                unversioned.append(pkg_name)
                continue

            # Remove any prefix like ^ or ~
            clean_version = re.sub(r"^[\^~]", "", version)

            # Check for mock vulnerabilities
            if pkg_name in self.KNOWN_VULNERABILITIES:
                for vuln_version, vuln_info in self.KNOWN_VULNERABILITIES[pkg_name].items():
                    if self._version_compare(clean_version, "<", vuln_version):
                        vulnerabilities.append({
                            "package": pkg_name,
                            "current_version": clean_version,
                            "advisory": vuln_info["advisory"],
                            "severity": vuln_info["severity"],
                        })

        return {
            "vulnerabilities": vulnerabilities,
            "unversioned": unversioned,
            "total": len(vulnerabilities) + len(unversioned),
        }

    def check_all(self, path: str) -> dict[str, Any]:
        """Run both pip and npm checks.

        Args:
            path: Path to scan

        Returns:
            Combined dict with both pip and npm results
        """
        pip_result = self.check_pip(path)
        npm_result = self.check_npm(path)

        return {
            "pip": pip_result,
            "npm": npm_result,
            "total_issues": pip_result["total"] + npm_result["total"],
        }

    def _parse_requirements(self, req_file: Path) -> list[dict[str, str]]:
        """Parse requirements.txt file."""
        deps = []
        try:
            with open(req_file, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line or line.startswith("#"):
                        continue
                    # Handle various formats: package==version, package>=version, etc.
                    match = re.match(r"([a-zA-Z0-9_-]+)([<>=!~]+)?(.*)?", line)
                    if match:
                        name = match.group(1)
                        version = match.group(3) or ""
                        deps.append({"name": name, "version": version})
        except Exception:
            pass
        return deps

    def _parse_pyproject(self, pyproject: Path) -> list[dict[str, str]]:
        """Parse pyproject.toml for dependencies."""
        deps = []
        try:
            content = pyproject.read_text(encoding="utf-8")

            # Simple regex-based parsing for dependencies section
            # Look for [project.dependencies] or [tool.poetry.dependencies]
            in_deps = False
            for line in content.splitlines():
                line = line.strip()
                if line.startswith("["):
                    in_deps = "dependencies" in line
                    continue
                if in_deps and line:
                    match = re.match(r'([a-zA-Z0-9_-]+)\s*(?:>=|<=|==|>|<)?\s*([0-9.]+)?', line)
                    if match:
                        deps.append({"name": match.group(1), "version": match.group(2) or ""})
        except Exception:
            pass
        return deps

    def _version_compare(self, ver1: str, op: str, ver2: str) -> bool:
        """Simple version comparison."""
        try:
            v1_parts = [int(x) for x in ver1.split(".") if x.isdigit()]
            v2_parts = [int(x) for x in ver2.split(".") if x.isdigit()]

            # Pad with zeros
            max_len = max(len(v1_parts), len(v2_parts))
            v1_parts.extend([0] * (max_len - len(v1_parts)))
            v2_parts.extend([0] * (max_len - len(v2_parts)))

            if op == "<":
                return v1_parts < v2_parts
            elif op == ">":
                return v1_parts > v2_parts
            elif op == "<=":
                return v1_parts <= v2_parts
            elif op == ">=":
                return v1_parts >= v2_parts
            elif op == "==":
                return v1_parts == v2_parts
            return False
        except Exception:
            return False