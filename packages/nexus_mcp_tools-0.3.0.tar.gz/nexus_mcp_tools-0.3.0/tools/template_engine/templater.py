"""Jinja2 template engine — render, validate, extract variables.

Uses SandboxedEnvironment for safe rendering.
"""

import re

from jinja2 import BaseLoader, TemplateSyntaxError, Undefined
from jinja2.sandbox import SandboxedEnvironment


class _SilentUndefined(Undefined):
    """Jinja2 undefined that renders as empty string instead of raising."""

    def __str__(self) -> str:
        return ""

    def __repr__(self) -> str:
        return ""

    def __bool__(self) -> bool:
        return False


def _make_env() -> SandboxedEnvironment:
    """Create a sandboxed Jinja2 environment with no autoescaping."""
    return SandboxedEnvironment(
        loader=BaseLoader(),
        autoescape=False,
        undefined=_SilentUndefined,
    )


# --- MCP tools ---


def template_render(template: str, context: dict | None = None) -> dict:
    """Render a Jinja2 template string with context variables.

    Undefined variables silently render as empty strings.

    Args:
        template: Jinja2 template text
        context: Dict of variable name -> value

    Returns:
        Dict with rendered text or error
    """
    try:
        env = _make_env()
        tpl = env.from_string(template)
        result = tpl.render(**(context or {}))
        return {"success": True, "rendered": result, "length": len(result)}
    except TemplateSyntaxError as e:
        return {"success": False, "error": f"Template syntax error: {e}"}
    except Exception as e:
        return {"success": False, "error": str(e)}


def template_render_file(path: str, context: dict | None = None) -> dict:
    """Read a file as a Jinja2 template and render it.

    Args:
        path: Path to template file
        context: Dict of variable name -> value

    Returns:
        Dict with rendered text or error
    """
    try:
        from pathlib import Path as _Path
        p = _Path(path).resolve()
        if not p.is_file():
            return {"success": False, "error": f"File not found: {path}"}
        text = p.read_text(encoding="utf-8")
        return template_render(text, context)
    except Exception as e:
        return {"success": False, "error": str(e)}


def template_validate(template: str) -> dict:
    """Validate Jinja2 template syntax without rendering.

    Args:
        template: Jinja2 template text

    Returns:
        Dict with valid: bool and optional error details
    """
    try:
        env = _make_env()
        env.from_string(template)
        return {"success": True, "valid": True}
    except TemplateSyntaxError as e:
        return {
            "success": True,
            "valid": False,
            "error": str(e),
            "lineno": e.lineno,
        }
    except Exception as e:
        return {"success": True, "valid": False, "error": str(e)}


def template_list_vars(template: str) -> dict:
    """Extract variable names referenced in a Jinja2 template.

    Uses regex to find {{ var }} patterns and {% set %} assignments.

    Args:
        template: Jinja2 template text

    Returns:
        Dict with variables list
    """
    vars_found: set[str] = set()

    # {{ variable }} patterns (including dotted and subscript access)
    for m in re.finditer(r"\{\{\s*(.+?)\s*\}\}", template):
        expr = m.group(1).strip()
        # Get the root variable name (before . [ or ()
        root = re.split(r"[\.\[\(\|]", expr)[0].strip()
        if root and root not in ("if", "for", "in", "else", "not", "and", "or"):
            vars_found.add(root)

    # {% for var in ... %}
    for m in re.finditer(r"\{%\s*for\s+(\w+)", template):
        vars_found.add(m.group(1))

    # {% set var = ... %}
    for m in re.finditer(r"\{%\s*set\s+(\w+)", template):
        vars_found.add(m.group(1))

    return {
        "success": True,
        "variables": sorted(vars_found),
        "count": len(vars_found),
    }
