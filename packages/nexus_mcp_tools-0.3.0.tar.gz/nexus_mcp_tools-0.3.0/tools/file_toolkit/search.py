"""File searching utilities for content and pattern matching."""

import os
import re
import fnmatch
from pathlib import Path
from typing import Any


class FileSearcher:
    """Search files by content or glob patterns."""

    def search_files(
        self,
        path: str,
        pattern: str,
        regex: bool = False,
        include: str = "*.py",
        max_results: int = 100,
    ) -> dict[str, Any]:
        """Search file contents using fnmatch or regex.

        Args:
            path: Directory path to search in
            pattern: Search pattern (string or regex if regex=True)
            regex: If True, treat pattern as regex; otherwise use fnmatch
            include: Glob pattern for files to include (default: "*.py")
            max_results: Maximum number of results to return

        Returns:
            Dict with results list containing filepath, line, line_number, match;
            also returns total_matches and files_scanned
        """
        try:
            search_path = Path(path)
            if not search_path.exists():
                return {"error": f"Path does not exist: {path}", "results": [], "total_matches": 0, "files_scanned": 0}

            results = []
            files_scanned = 0

            # Compile regex if needed
            regex_obj = None
            if regex:
                try:
                    regex_obj = re.compile(pattern)
                except re.error as e:
                    return {"error": f"Invalid regex pattern: {e}", "results": [], "total_matches": 0, "files_scanned": 0}

            # Walk directory
            for root, _, files in os.walk(search_path):
                for filename in files:
                    # Filter by include pattern
                    if not fnmatch.fnmatch(filename, include):
                        continue

                    filepath = os.path.join(root, filename)
                    files_scanned += 1

                    try:
                        with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
                            for line_num, line in enumerate(f, start=1):
                                if regex_obj:
                                    match = regex_obj.search(line)
                                    if match:
                                        results.append({
                                            "filepath": filepath,
                                            "line": line.strip(),
                                            "line_number": line_num,
                                            "match": match.group(0),
                                        })
                                else:
                                    if pattern.lower() in line.lower():
                                        results.append({
                                            "filepath": filepath,
                                            "line": line.strip(),
                                            "line_number": line_num,
                                            "match": pattern,
                                        })

                                # Check if we've hit max_results
                                if len(results) >= max_results:
                                    return {
                                        "results": results,
                                        "total_matches": len(results),
                                        "files_scanned": files_scanned,
                                        "truncated": True,
                                    }

                    except (IOError, OSError):
                        # Skip files that can't be read
                        continue

            return {
                "results": results,
                "total_matches": len(results),
                "files_scanned": files_scanned,
            }
        except Exception as e:
            return {"error": str(e), "results": [], "total_matches": 0, "files_scanned": 0}

    def find_files(
        self,
        path: str,
        glob_pattern: str,
        max_depth: int = 10,
    ) -> dict[str, Any]:
        """Find files by glob pattern.

        Args:
            path: Directory path to search in
            glob_pattern: Glob pattern to match (e.g., "**/*.py")
            max_depth: Maximum directory depth to search

        Returns:
            Dict with files list containing path, size_bytes, modified_at;
            also returns total_count
        """
        try:
            search_path = Path(path)
            if not search_path.exists():
                return {"error": f"Path does not exist: {path}", "files": [], "total_count": 0}

            files = []
            pattern_path = search_path.glob(glob_pattern)

            for filepath in pattern_path:
                # Skip directories
                if not filepath.is_file():
                    continue

                try:
                    stat = filepath.stat()
                    files.append({
                        "path": str(filepath),
                        "size_bytes": stat.st_size,
                        "modified_at": stat.st_mtime,
                    })
                except (OSError, IOError):
                    # Skip files that can't be stat'd
                    continue

            # Sort by modification time (newest first)
            files.sort(key=lambda x: x["modified_at"], reverse=True)

            return {
                "files": files,
                "total_count": len(files),
            }
        except Exception as e:
            return {"error": str(e), "files": [], "total_count": 0}