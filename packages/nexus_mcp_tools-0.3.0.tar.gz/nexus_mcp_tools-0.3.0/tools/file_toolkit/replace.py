"""File text replacement utilities."""

import re
from pathlib import Path
from typing import Any


class FileReplacer:
    """Find and replace text in files."""

    def search_replace(
        self,
        path: str,
        search: str,
        replacement: str,
        regex: bool = False,
        dry_run: bool = True,
    ) -> dict[str, Any]:
        """Find and replace text in a file.

        Args:
            path: File path to perform search and replace on
            search: Text to search for (string or regex if regex=True)
            replacement: Replacement text
            regex: If True, treat search as regex; otherwise use literal string
            dry_run: If True, only show what would be replaced; if False, actually replace

        Returns:
            Dict with files_changed list containing path and replacements_count;
            also returns total_replacements and dry_run status
        """
        try:
            file_path = Path(path)
            if not file_path.exists():
                return {"error": f"File does not exist: {path}", "files_changed": [], "total_replacements": 0, "dry_run": dry_run}

            # Read file content
            with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
                original_content = f.read()

            # Perform replacement
            if regex:
                try:
                    new_content, count = re.subn(search, replacement, original_content)
                except re.error as e:
                    return {"error": f"Invalid regex: {e}", "files_changed": [], "total_replacements": 0, "dry_run": dry_run}
            else:
                new_content = original_content.replace(search, replacement)
                count = original_content.count(search)

            if count == 0:
                return {
                    "files_changed": [],
                    "total_replacements": 0,
                    "dry_run": dry_run,
                }

            # Write back if not dry run
            if not dry_run:
                with open(file_path, "w", encoding="utf-8") as f:
                    f.write(new_content)

            return {
                "files_changed": [{
                    "path": path,
                    "replacements_count": count,
                }],
                "total_replacements": count,
                "dry_run": dry_run,
            }
        except Exception as e:
            return {"error": str(e), "files_changed": [], "total_replacements": 0, "dry_run": dry_run}

    def replace_in_files(
        self,
        paths: list[str],
        search: str,
        replacement: str,
    ) -> dict[str, Any]:
        """Bulk search and replace across multiple files.

        Args:
            paths: List of file paths to process
            search: Text to search for
            replacement: Replacement text

        Returns:
            Dict with files_changed list containing path and replacements_count;
            also returns total_replacements
        """
        try:
            files_changed = []
            total_replacements = 0

            for path in paths:
                result = self.search_replace(
                    path=path,
                    search=search,
                    replacement=replacement,
                    regex=False,
                    dry_run=False,
                )

                if "error" in result:
                    files_changed.append({
                        "path": path,
                        "replacements_count": 0,
                        "error": result["error"],
                    })
                elif result["total_replacements"] > 0:
                    files_changed.append({
                        "path": path,
                        "replacements_count": result["total_replacements"],
                    })
                    total_replacements += result["total_replacements"]

            return {
                "files_changed": files_changed,
                "total_replacements": total_replacements,
            }
        except Exception as e:
            return {"error": str(e), "files_changed": [], "total_replacements": 0}