"""File operations utilities - rename, compare, and info."""

import difflib
import fnmatch
from pathlib import Path
from typing import Any


class FileOperations:
    """File operations: rename, compare, and metadata retrieval."""

    def batch_rename(
        self,
        directory: str,
        pattern: str,
        replacement: str,
        dry_run: bool = True,
    ) -> dict[str, Any]:
        """Rename files matching a pattern.

        Args:
            directory: Directory containing files to rename
            pattern: Pattern to match in filenames (supports fnmatch wildcards)
            replacement: Replacement string for matched files
            dry_run: If True, only show what would be renamed; if False, actually rename

        Returns:
            Dict with renamed list containing old_name and new_name;
            also returns dry_run status and total count
        """
        try:
            dir_path = Path(directory)
            if not dir_path.exists():
                return {"error": f"Directory does not exist: {directory}", "renamed": [], "dry_run": dry_run, "total": 0}

            renamed = []
            errors = []

            for filepath in dir_path.iterdir():
                if not filepath.is_file():
                    continue

                old_name = filepath.name

                # Check if filename matches pattern
                if fnmatch.fnmatch(old_name, f"*{pattern}*"):
                    new_name = old_name.replace(pattern, replacement, 1)

                    if old_name != new_name:
                        renamed.append({
                            "old_name": old_name,
                            "new_name": new_name,
                        })

                        # Actually rename if not dry run
                        if not dry_run:
                            try:
                                new_path = filepath.parent / new_name
                                filepath.rename(new_path)
                            except (OSError, IOError) as e:
                                errors.append(f"Failed to rename {old_name}: {e}")

            return {
                "renamed": renamed,
                "dry_run": dry_run,
                "total": len(renamed),
                "errors": errors if errors else None,
            }
        except Exception as e:
            return {"error": str(e), "renamed": [], "dry_run": dry_run, "total": 0}

    def compare_files(self, path_a: str, path_b: str) -> dict[str, Any]:
        """Compare two files using difflib.

        Args:
            path_a: Path to first file
            path_b: Path to second file

        Returns:
            Dict with same boolean, diff list with type, line_a, line_b, content;
            also returns total_diffs count
        """
        try:
            file_a_path = Path(path_a)
            file_b_path = Path(path_b)

            if not file_a_path.exists():
                return {"error": f"File does not exist: {path_a}", "same": False, "diff": [], "total_diffs": 0}
            if not file_b_path.exists():
                return {"error": f"File does not exist: {path_b}", "same": False, "diff": [], "total_diffs": 0}

            # Read files
            with open(file_a_path, "r", encoding="utf-8", errors="ignore") as f:
                lines_a = f.readlines()
            with open(file_b_path, "r", encoding="utf-8", errors="ignore") as f:
                lines_b = f.readlines()

            # Use unified_diff for comparison
            diff_lines = list(difflib.unified_diff(
                lines_a,
                lines_b,
                fromfile=path_a,
                tofile=path_b,
                lineterm=""
            ))

            if not diff_lines:
                return {"same": True, "diff": [], "total_diffs": 0}

            # Parse diff output
            diff = []
            for line in diff_lines:
                if line.startswith("---") or line.startswith("+++"):
                    continue
                elif line.startswith("@@"):
                    # This is a hunk header, include it
                    diff.append({
                        "type": "hunk",
                        "line_a": None,
                        "line_b": None,
                        "content": line,
                    })
                elif line.startswith("-"):
                    diff.append({
                        "type": "removed",
                        "line_a": line[1:],
                        "line_b": None,
                        "content": line,
                    })
                elif line.startswith("+"):
                    diff.append({
                        "type": "added",
                        "line_a": None,
                        "line_b": line[1:],
                        "content": line,
                    })
                else:
                    diff.append({
                        "type": "context",
                        "line_a": line[1:] if len(line) > 1 else "",
                        "line_b": line[1:] if len(line) > 1 else "",
                        "content": line,
                    })

            return {
                "same": False,
                "diff": diff,
                "total_diffs": len([d for d in diff if d["type"] in ("added", "removed")]),
            }
        except Exception as e:
            return {"error": str(e), "same": False, "diff": [], "total_diffs": 0}

    def file_info(self, path: str) -> dict[str, Any]:
        """Get file or directory metadata.

        Args:
            path: Path to file or directory

        Returns:
            Dict with exists, type, size_bytes, modified_at, created_at,
            permissions, extension
        """
        try:
            file_path = Path(path)

            if not file_path.exists():
                return {"exists": False}

            stat = file_path.stat()

            # Determine type
            if file_path.is_dir():
                ftype = "directory"
            elif file_path.is_file():
                ftype = "file"
            else:
                ftype = "unknown"

            # Get extension for files
            extension = file_path.suffix if ftype == "file" else None

            # Get permissions (rwx format)
            try:
                mode = stat.st_mode
                perms = ""
                perms += "r" if mode & 0o400 else "-"
                perms += "w" if mode & 0o200 else "-"
                perms += "x" if mode & 0o100 else "-"
            except Exception:
                perms = "unknown"

            return {
                "exists": True,
                "type": ftype,
                "size_bytes": stat.st_size if ftype == "file" else None,
                "modified_at": stat.st_mtime,
                "created_at": stat.st_ctime,
                "permissions": perms,
                "extension": extension,
            }
        except Exception as e:
            return {"exists": False, "error": str(e)}