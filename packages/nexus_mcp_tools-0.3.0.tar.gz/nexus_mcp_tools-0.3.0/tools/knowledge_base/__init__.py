"""Knowledge Base module for persistent key-value storage."""

from tools.knowledge_base.store import KnowledgeStore

__all__ = ["KnowledgeStore"]