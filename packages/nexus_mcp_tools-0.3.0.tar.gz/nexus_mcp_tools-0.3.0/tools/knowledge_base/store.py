"""Knowledge store for persistent key-value storage."""

import json
from datetime import datetime
from pathlib import Path


class KnowledgeStore:
    """Persistent key-value store for knowledge items."""

    def __init__(self):
        self.base_dir = Path.home() / ".nexus-tools" / "knowledge"

    def kb_set(self, key: str, value: str, namespace: str = "default") -> dict:
        """Save a knowledge item.

        Args:
            key: The key to store
            value: The value to store
            namespace: The namespace for the key

        Returns:
            Dict with success, key, namespace
        """
        try:
            # Create namespace directory if it doesn't exist
            ns_dir = self.base_dir / namespace
            ns_dir.mkdir(parents=True, exist_ok=True)

            # Prepare data
            now = datetime.now().isoformat()
            data = {
                "key": key,
                "value": value,
                "namespace": namespace,
                "created_at": now,
                "updated_at": now
            }

            # Check if key already exists for created_at
            file_path = ns_dir / f"{key}.json"
            if file_path.exists():
                try:
                    existing = json.loads(file_path.read_text(encoding="utf-8"))
                    data["created_at"] = existing.get("created_at", now)
                except (json.JSONDecodeError, KeyError):
                    pass

            # Write to file
            file_path.write_text(json.dumps(data, indent=2), encoding="utf-8")

            return {"success": True, "key": key, "namespace": namespace}
        except Exception as e:
            return {"success": False, "error": str(e), "key": key, "namespace": namespace}

    def kb_get(self, key: str, namespace: str = "default") -> dict:
        """Retrieve a knowledge item.

        Args:
            key: The key to retrieve
            namespace: The namespace to look in

        Returns:
            Dict with found, key, value, namespace, created_at, updated_at
        """
        try:
            file_path = self.base_dir / namespace / f"{key}.json"

            if not file_path.exists():
                return {"found": False, "key": key, "namespace": namespace}

            data = json.loads(file_path.read_text(encoding="utf-8"))

            return {
                "found": True,
                "key": data.get("key", key),
                "value": data.get("value", ""),
                "namespace": data.get("namespace", namespace),
                "created_at": data.get("created_at", ""),
                "updated_at": data.get("updated_at", "")
            }
        except FileNotFoundError:
            return {"found": False, "key": key, "namespace": namespace}
        except Exception as e:
            return {"found": False, "error": str(e), "key": key, "namespace": namespace}

    def kb_search(self, query: str, namespace: str | None = None) -> dict:
        """Search for knowledge items.

        Args:
            query: Search query string
            namespace: Optional namespace to search in (None = all namespaces)

        Returns:
            Dict with results list and total count
        """
        try:
            results = []
            query_lower = query.lower()

            # Determine which namespaces to search
            namespaces = []
            if namespace:
                namespaces.append(namespace)
            elif self.base_dir.exists():
                namespaces = [d.name for d in self.base_dir.iterdir() if d.is_dir()]

            for ns in namespaces:
                ns_dir = self.base_dir / ns
                if not ns_dir.is_dir():
                    continue

                for file_path in ns_dir.glob("*.json"):
                    try:
                        data = json.loads(file_path.read_text(encoding="utf-8"))
                        key = data.get("key", "").lower()
                        value = data.get("value", "").lower()

                        # Calculate simple score based on matches
                        score = 0
                        if query_lower in key:
                            score += 2
                        if query_lower in value:
                            score += 1

                        if score > 0:
                            results.append({
                                "key": data.get("key", ""),
                                "value": data.get("value", ""),
                                "namespace": data.get("namespace", ns),
                                "score": score
                            })
                    except (json.JSONDecodeError, OSError):
                        continue

            # Sort by score descending
            results.sort(key=lambda x: x["score"], reverse=True)

            return {"results": results, "total": len(results)}
        except Exception as e:
            return {"results": [], "total": 0, "error": str(e)}

    def kb_list(self, namespace: str = "default") -> dict:
        """List all keys in a namespace.

        Args:
            namespace: The namespace to list

        Returns:
            Dict with namespace, items list, total count
        """
        try:
            ns_dir = self.base_dir / namespace

            if not ns_dir.exists():
                return {"namespace": namespace, "items": [], "total": 0}

            items = []
            for file_path in ns_dir.glob("*.json"):
                try:
                    data = json.loads(file_path.read_text(encoding="utf-8"))
                    value = data.get("value", "")
                    # Preview first 50 chars
                    value_preview = value[:50] + "..." if len(value) > 50 else value

                    items.append({
                        "key": data.get("key", ""),
                        "value_preview": value_preview,
                        "updated_at": data.get("updated_at", "")
                    })
                except (json.JSONDecodeError, OSError):
                    continue

            return {"namespace": namespace, "items": items, "total": len(items)}
        except Exception as e:
            return {"namespace": namespace, "items": [], "total": 0, "error": str(e)}

    def kb_delete(self, key: str, namespace: str = "default") -> dict:
        """Delete a knowledge item.

        Args:
            key: The key to delete
            namespace: The namespace to delete from

        Returns:
            Dict with success, key, namespace
        """
        try:
            file_path = self.base_dir / namespace / f"{key}.json"

            if not file_path.exists():
                return {"success": False, "key": key, "namespace": namespace, "error": "Key not found"}

            file_path.unlink()

            return {"success": True, "key": key, "namespace": namespace}
        except FileNotFoundError:
            return {"success": False, "key": key, "namespace": namespace, "error": "Key not found"}
        except Exception as e:
            return {"success": False, "error": str(e), "key": key, "namespace": namespace}