"""Data conversion utilities - JSON, YAML, CSV parsing and transformation."""

import csv
import io
import json
from typing import Any, Optional  # noqa: F401 - used in method signature


class DataConverter:
    """Convert and validate between JSON, YAML, and CSV formats."""

    def parse_json(self, text: str) -> dict[str, Any]:
        """Parse a JSON string into a Python dict.

        Args:
            text: JSON string to parse

        Returns:
            Dict with parsed data, or error details
        """
        try:
            data = json.loads(text)
            return {"success": True, "data": data, "type": type(data).__name__}
        except json.JSONDecodeError as e:
            return {"success": False, "error": str(e), "line": e.lineno, "col": e.colno}

    def parse_yaml(self, text: str) -> dict[str, Any]:
        """Parse a YAML string into a Python dict.

        Args:
            text: YAML string to parse

        Returns:
            Dict with parsed data, or error details
        """
        try:
            import yaml as _yaml_mod
        except ImportError:
            return {"success": False, "error": "PyYAML is not installed. Run: uv pip install pyyaml"}
        try:
            data = _yaml_mod.safe_load(text)
            return {"success": True, "data": data, "type": type(data).__name__}
        except _yaml_mod.YAMLError as e:
            return {"success": False, "error": str(e)}

    def to_json(
        self,
        data: Any,
        indent: int = 2,
        sort_keys: bool = False,
    ) -> dict[str, Any]:
        """Convert a Python object to a JSON string.

        Args:
            data: Python object to serialize
            indent: Indentation spaces (default: 2, use 0 for compact, None for no whitespace)
            sort_keys: Sort dictionary keys alphabetically

        Returns:
            Dict with json_string result
        """
        try:
            indent_val = None if indent is None else indent
            json_str = json.dumps(data, indent=indent_val, sort_keys=sort_keys, default=str)
            return {"success": True, "json_string": json_str, "length": len(json_str)}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def to_yaml(
        self,
        data: Any,
        default_flow_style: Optional[bool] = None,
        sort_keys: bool = False,
    ) -> dict[str, Any]:
        """Convert a Python object to a YAML string.

        Args:
            data: Python object to serialize
            default_flow_style: YAML flow style (True=inline, False=block, None=auto)
            sort_keys: Sort dictionary keys alphabetically

        Returns:
            Dict with yaml_string result
        """
        try:
            import yaml as _yaml_mod
        except ImportError:
            return {"success": False, "error": "PyYAML is not installed. Run: uv pip install pyyaml"}
        try:
            yaml_str = _yaml_mod.dump(data, default_flow_style=default_flow_style, sort_keys=sort_keys)
            return {"success": True, "yaml_string": yaml_str, "length": len(yaml_str)}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def json_to_yaml(self, json_text: str) -> dict[str, Any]:
        """Convert a JSON string to a YAML string.

        Args:
            json_text: JSON string to convert

        Returns:
            Dict with yaml_string result, or parse error
        """
        parsed = self.parse_json(json_text)
        if not parsed.get("success"):
            return {"success": False, "error": parsed.get("error", "Invalid JSON")}
        return self.to_yaml(parsed["data"])

    def yaml_to_json(self, yaml_text: str, indent: int = 2) -> dict[str, Any]:
        """Convert a YAML string to a JSON string.

        Args:
            yaml_text: YAML string to convert
            indent: JSON indentation spaces

        Returns:
            Dict with json_string result, or parse error
        """
        parsed = self.parse_yaml(yaml_text)
        if not parsed.get("success"):
            return {"success": False, "error": parsed.get("error", "Invalid YAML")}
        return self.to_json(parsed["data"], indent=indent)

    def parse_csv(self, text: str, delimiter: str = ",") -> dict[str, Any]:
        """Parse a CSV string into a list of rows.

        Args:
            text: CSV string to parse
            delimiter: Field delimiter (default: ",")

        Returns:
            Dict with headers and rows, or error
        """
        try:
            reader = csv.DictReader(io.StringIO(text), delimiter=delimiter)
            rows = list(reader)
            if not rows:
                # Try reading as simple rows without headers
                f = io.StringIO(text)
                raw = csv.reader(f, delimiter=delimiter)
                all_rows = list(raw)
                if all_rows:
                    return {
                        "success": True,
                        "headers": all_rows[0],
                        "rows": all_rows[1:],
                        "total_rows": len(all_rows) - 1,
                    }
                return {"success": True, "headers": [], "rows": [], "total_rows": 0}
            return {
                "success": True,
                "headers": list(rows[0].keys()),
                "rows": rows,
                "total_rows": len(rows),
            }
        except Exception as e:
            return {"success": False, "error": str(e)}

    def to_csv(self, headers: list[str], rows: list[list[str]]) -> dict[str, Any]:
        """Convert headers and rows to a CSV string.

        Args:
            headers: List of column headers
            rows: List of row data lists

        Returns:
            Dict with csv_string result
        """
        try:
            output = io.StringIO()
            writer = csv.writer(output)
            writer.writerow(headers)
            writer.writerows(rows)
            csv_str = output.getvalue()
            return {"success": True, "csv_string": csv_str, "length": len(csv_str)}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def validate_json_schema(self, instance_text: str, schema_text: str) -> dict[str, Any]:
        """Validate a JSON instance against a JSON Schema.

        Args:
            instance_text: JSON string to validate
            schema_text: JSON Schema string

        Returns:
            Dict with valid flag and errors if any
        """
        try:
            import jsonschema
            instance = json.loads(instance_text)
            schema = json.loads(schema_text)
            validator = jsonschema.Draft7Validator(schema)
            errors = list(validator.iter_errors(instance))
            if errors:
                return {
                    "valid": False,
                    "errors": [{"path": list(e.path), "message": e.message} for e in errors],
                    "error_count": len(errors),
                }
            return {"valid": True, "errors": [], "error_count": 0}
        except json.JSONDecodeError as e:
            return {"valid": False, "errors": [{"path": [], "message": f"JSON parse error: {e}"}], "error_count": 1}
        except ImportError:
            return {"valid": False, "errors": [{"path": [], "message": "jsonschema is not installed"}], "error_count": 1}
        except Exception as e:
            return {"valid": False, "errors": [{"path": [], "message": str(e)}], "error_count": 1}
