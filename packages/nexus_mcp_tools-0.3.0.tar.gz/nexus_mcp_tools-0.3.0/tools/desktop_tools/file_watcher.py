"""Polling-based file/directory watcher.

Stores directory snapshots (file paths + size + mtime) as JSON
under ~/.nexus-tools/desktop/watches/. On poll, rescans and diffs.

Tools: fs_watch_start, fs_watch_poll, fs_watch_stop, fs_watch_list
"""

import fnmatch
import json
import os
import time
from pathlib import Path

from shared.config import get_data_dir

WATCHES_DIR = get_data_dir() / "desktop" / "watches"


def _ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def _watch_path(watch_id: str) -> Path:
    return WATCHES_DIR / f"{watch_id}.json"


def _snapshot_dir(dir_path: str, pattern: str = "*") -> list[dict]:
    """Walk dir_path and record (rel_path, size, mtime, is_dir) for each entry."""
    entries: list[dict] = []
    base = Path(dir_path).resolve()
    if not base.is_dir():
        return entries
    for root, dirs, files in os.walk(base):
        root_rel = str(Path(root).relative_to(base))
        # Directories (unless root)
        if root_rel != ".":
            if fnmatch.fnmatch(Path(root).name, pattern):
                st = os.stat(root)
                entries.append({
                    "path": root_rel,
                    "size": st.st_size,
                    "mtime": st.st_mtime,
                    "is_dir": True,
                })
        # Files
        for fname in files:
            if fnmatch.fnmatch(fname, pattern):
                fpath = os.path.join(root, fname)
                try:
                    st = os.stat(fpath)
                    rel = str(Path(fpath).relative_to(base))
                    entries.append({
                        "path": rel,
                        "size": st.st_size,
                        "mtime": st.st_mtime,
                        "is_dir": False,
                    })
                except OSError:
                    continue
    return entries


def _diff_snapshots(old: list[dict], new: list[dict]) -> dict:
    """Compare two snapshots, return added/modified/removed/unchanged counts."""
    old_map = {e["path"]: e for e in old}
    new_map = {e["path"]: e for e in new}

    old_paths = set(old_map)
    new_paths = set(new_map)

    added = []
    removed = []
    modified = []
    unchanged = []

    for p in sorted(new_paths - old_paths):
        added.append(p)
    for p in sorted(old_paths - new_paths):
        removed.append(p)
    for p in sorted(old_paths & new_paths):
        o = old_map[p]
        n = new_map[p]
        if o["size"] != n["size"] or o["mtime"] != n["mtime"]:
            modified.append(p)
        else:
            unchanged.append(p)

    return {
        "added": added,
        "removed": removed,
        "modified": modified,
        "unchanged_count": len(unchanged),
        "total_changes": len(added) + len(removed) + len(modified),
    }


def fs_watch_start(path: str, pattern: str = "*", name: str | None = None) -> dict:
    """Start monitoring a directory.

    Takes an initial snapshot. Use fs_watch_poll to detect changes.
    """
    _ensure_dir(WATCHES_DIR)
    resolved = Path(path).resolve()
    if not resolved.is_dir():
        return {"success": False, "error": f"Directory not found: {path}"}

    watch_id = name or resolved.name
    wpath = _watch_path(watch_id)

    snapshot = _snapshot_dir(str(resolved), pattern)
    meta = {
        "path": str(resolved),
        "pattern": pattern,
        "created_at": time.time(),
        "snapshot": snapshot,
    }
    wpath.write_text(json.dumps(meta, indent=2), encoding="utf-8")

    return {
        "success": True,
        "watch_id": watch_id,
        "path": str(resolved),
        "pattern": pattern,
        "entries_snapped": len(snapshot),
    }


def fs_watch_poll(watch_id: str) -> dict:
    """Poll a watch for changes since last snapshot.

    Updates the stored snapshot after returning changes.
    """
    wpath = _watch_path(watch_id)
    if not wpath.exists():
        return {"success": False, "error": f"Watch not found: {watch_id}"}

    meta = json.loads(wpath.read_text(encoding="utf-8"))
    old_snapshot = meta["snapshot"]
    new_snapshot = _snapshot_dir(meta["path"], meta["pattern"])

    diff = _diff_snapshots(old_snapshot, new_snapshot)

    # Update stored snapshot
    meta["snapshot"] = new_snapshot
    meta["last_polled_at"] = time.time()
    wpath.write_text(json.dumps(meta, indent=2), encoding="utf-8")

    return {
        "success": True,
        "watch_id": watch_id,
        "path": meta["path"],
        "diff": diff,
    }


def fs_watch_stop(watch_id: str) -> dict:
    """Stop monitoring and delete the watch state."""
    wpath = _watch_path(watch_id)
    if not wpath.exists():
        return {"success": False, "error": f"Watch not found: {watch_id}"}
    wpath.unlink()
    return {"success": True, "watch_id": watch_id, "action": "stopped"}


def fs_watch_list() -> dict:
    """List all active file watches with metadata."""
    _ensure_dir(WATCHES_DIR)
    watches = []
    for f in sorted(WATCHES_DIR.glob("*.json")):
        try:
            meta = json.loads(f.read_text(encoding="utf-8"))
            watches.append({
                "watch_id": f.stem,
                "path": meta.get("path"),
                "pattern": meta.get("pattern"),
                "entries_snapped": len(meta.get("snapshot", [])),
                "created_at": meta.get("created_at"),
                "last_polled_at": meta.get("last_polled_at"),
            })
        except (json.JSONDecodeError, KeyError):
            continue
    return {"success": True, "watches": watches, "count": len(watches)}
