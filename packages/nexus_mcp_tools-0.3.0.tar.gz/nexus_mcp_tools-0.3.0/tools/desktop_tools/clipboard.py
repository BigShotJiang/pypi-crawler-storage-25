"""Clipboard get/set/history via OS-native APIs (Windows PowerShell).

Cross-platform notes:
  - Windows: uses PowerShell Get-Clipboard / Set-Clipboard (available Win10+)
  - Linux/macOS: will return error — no xclip/pbpaste dependency imposed

Tools: clipboard_get, clipboard_set, clipboard_history
"""

import json
import subprocess as sp
import sys
import time

from shared.config import get_data_dir

HISTORY_FILE = get_data_dir() / "desktop" / "clipboard_history.json"


def _read_history() -> list[dict]:
    if HISTORY_FILE.exists():
        try:
            return json.loads(HISTORY_FILE.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            return []
    return []


def _write_history(entries: list[dict]) -> None:
    HISTORY_FILE.parent.mkdir(parents=True, exist_ok=True)
    # Keep last 100 entries
    HISTORY_FILE.write_text(json.dumps(entries[-100:], indent=2), encoding="utf-8")


def _powershell_get() -> str:
    """Get clipboard text via PowerShell Get-Clipboard."""
    if sys.platform != "win32":
        raise RuntimeError("Clipboard tools only supported on Windows")
    r = sp.run(
        ["powershell", "-NoProfile", "-Command", "Get-Clipboard"],
        capture_output=True, text=True, timeout=5,
    )
    if r.returncode != 0:
        raise RuntimeError(f"Get-Clipboard failed: {r.stderr.strip()}")
    return r.stdout


def _powershell_set(text: str) -> None:
    """Set clipboard text via PowerShell Set-Clipboard using stdin."""
    if sys.platform != "win32":
        raise RuntimeError("Clipboard tools only supported on Windows")
    p = sp.Popen(
        ["powershell", "-NoProfile", "-Command", "$input | Set-Clipboard"],
        stdin=sp.PIPE, stdout=sp.PIPE, stderr=sp.PIPE, text=True,
    )
    _, err = p.communicate(input=text, timeout=5)
    if p.returncode != 0:
        raise RuntimeError(f"Set-Clipboard failed: {err.strip()}")


# --- MCP tools ---


def clipboard_get() -> dict:
    """Get current clipboard text content.

    Also snapshots to history (accessible via clipboard_history).
    """
    try:
        text = _powershell_get()
        # Snapshot to history
        history = _read_history()
        history.append({
            "timestamp": time.time(),
            "text": text,
            "length": len(text),
        })
        _write_history(history)
        return {"success": True, "text": text, "length": len(text)}
    except RuntimeError as e:
        return {"success": False, "error": str(e)}
    except FileNotFoundError:
        return {"success": False, "error": "PowerShell not found (clipboard requires Windows)"}
    except sp.TimeoutExpired:
        return {"success": False, "error": "Clipboard read timed out"}


def clipboard_set(text: str) -> dict:
    """Set clipboard text content."""
    try:
        _powershell_set(text)
        return {"success": True, "length": len(text)}
    except RuntimeError as e:
        return {"success": False, "error": str(e)}
    except FileNotFoundError:
        return {"success": False, "error": "PowerShell not found (clipboard requires Windows)"}
    except sp.TimeoutExpired:
        return {"success": False, "error": "Clipboard write timed out"}


def clipboard_history(limit: int = 10) -> dict:
    """Show recent clipboard history entries.

    Call clipboard_get first to snapshot current state — this
    tool returns previously captured snapshots.
    """
    entries = _read_history()
    recent = entries[-limit:] if limit > 0 else entries
    return {
        "success": True,
        "entries": recent,
        "total_stored": len(entries),
        "returned": len(recent),
    }
