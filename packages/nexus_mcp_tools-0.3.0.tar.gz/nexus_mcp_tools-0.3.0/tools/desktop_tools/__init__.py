"""Desktop & Background tools: File Watcher, Clipboard, Scheduler.

Domains (Phase 9e):
  - File Watcher: polling-based directory monitoring (4 tools)
  - Clipboard: get/set/history via OS-native APIs (3 tools)
  - Scheduler: in-process task scheduling via JSON state (4 tools)

Storage: ~/.nexus-tools/desktop/
"""

from tools.desktop_tools.file_watcher import (
    fs_watch_start,
    fs_watch_poll,
    fs_watch_stop,
    fs_watch_list,
)

from tools.desktop_tools.clipboard import (
    clipboard_get,
    clipboard_set,
    clipboard_history,
)

from tools.desktop_tools.scheduler import (
    task_schedule,
    task_delayed,
    task_cancel,
    task_check,
)

__all__ = [
    "fs_watch_start",
    "fs_watch_poll",
    "fs_watch_stop",
    "fs_watch_list",
    "clipboard_get",
    "clipboard_set",
    "clipboard_history",
    "task_schedule",
    "task_delayed",
    "task_cancel",
    "task_check",
]
