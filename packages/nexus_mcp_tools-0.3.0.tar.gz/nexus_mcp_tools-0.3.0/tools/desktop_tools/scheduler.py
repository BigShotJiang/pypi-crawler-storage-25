"""In-process task scheduler via JSON state file.

No background threads — uses polling pattern: AI assistant calls
task_check() periodically to see which tasks are due.

Tools: task_schedule, task_delayed, task_cancel, task_check
"""

import json
import time

from shared.config import get_data_dir

TASKS_FILE = get_data_dir() / "desktop" / "tasks.json"


def _read_tasks() -> list[dict]:
    if TASKS_FILE.exists():
        try:
            return json.loads(TASKS_FILE.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            return []
    return []


def _write_tasks(tasks: list[dict]) -> None:
    TASKS_FILE.parent.mkdir(parents=True, exist_ok=True)
    TASKS_FILE.write_text(json.dumps(tasks, indent=2), encoding="utf-8")


def _make_task(
    name: str,
    description: str,
    interval_seconds: float | None,
    delay_seconds: float | None = None,
) -> dict:
    now = time.time()
    if delay_seconds is not None:
        next_run = now + delay_seconds
    elif interval_seconds is not None:
        next_run = now + interval_seconds
    else:
        next_run = now

    return {
        "name": name,
        "description": description,
        "interval_seconds": interval_seconds,  # None = one-shot
        "next_run_at": next_run,
        "created_at": now,
        "run_count": 0,
        "last_run_at": None,
    }


# --- MCP tools ---


def task_schedule(name: str, interval_seconds: float, description: str) -> dict:
    """Schedule a recurring task.

    The task fires every `interval_seconds` once started.
    Use task_check() to see which tasks are due.
    """
    tasks = _read_tasks()
    if any(t["name"] == name for t in tasks):
        # Update existing
        for t in tasks:
            if t["name"] == name:
                t["description"] = description
                t["interval_seconds"] = interval_seconds
                t["next_run_at"] = time.time() + interval_seconds
                break
        _write_tasks(tasks)
        return {"success": True, "name": name, "action": "updated"}
    else:
        task = _make_task(name, description, interval_seconds=interval_seconds)
        tasks.append(task)
        _write_tasks(tasks)
        return {
            "success": True,
            "name": name,
            "action": "scheduled",
            "next_run_in_seconds": interval_seconds,
        }


def task_delayed(name: str, seconds: float, description: str) -> dict:
    """Schedule a one-shot task to fire after a delay.

    Use task_check() to see when it fires.
    """
    tasks = _read_tasks()
    task = _make_task(name, description, interval_seconds=None, delay_seconds=seconds)
    tasks.append(task)
    _write_tasks(tasks)
    return {
        "success": True,
        "name": name,
        "action": "scheduled_delayed",
        "fires_in_seconds": seconds,
    }


def task_cancel(name: str) -> dict:
    """Cancel a scheduled task by name."""
    tasks = _read_tasks()
    before = len(tasks)
    tasks = [t for t in tasks if t["name"] != name]
    if len(tasks) == before:
        return {"success": False, "error": f"Task not found: {name}"}
    _write_tasks(tasks)
    return {"success": True, "name": name, "action": "cancelled"}


def task_check() -> dict:
    """Check which scheduled tasks are due.

    Returns tasks whose next_run_at has passed.
    Completed one-shot tasks are removed.
    Recurring tasks have their next_run_at advanced.
    """
    tasks = _read_tasks()
    now = time.time()
    due: list[dict] = []
    remaining: list[dict] = []

    for t in tasks:
        if now >= t["next_run_at"]:
            t["run_count"] += 1
            t["last_run_at"] = now

            due.append({
                "name": t["name"],
                "description": t["description"],
                "run_count": t["run_count"],
            })

            if t["interval_seconds"] is not None:
                # Recurring — advance next run
                t["next_run_at"] = now + t["interval_seconds"]
                remaining.append(t)
            # else one-shot — drop it
        else:
            remaining.append(t)

    _write_tasks(remaining)

    due_sorted = sorted(due, key=lambda x: x["name"])
    return {
        "success": True,
        "due_tasks": due_sorted,
        "count": len(due_sorted),
        "remaining_scheduled": len(remaining),
    }
