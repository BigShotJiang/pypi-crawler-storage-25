"""Excel file manipulation using openpyxl."""

import csv
import os
from pathlib import Path
from typing import Any


class ExcelToolkit:
    """Excel file read, write, merge, and conversion utilities."""

    def sheets(self, filepath: str) -> dict[str, Any]:
        """List all sheets in an Excel workbook.

        Args:
            filepath: Path to .xlsx file

        Returns:
            Dict with sheet list and metadata
        """
        try:
            import openpyxl
            wb = openpyxl.load_workbook(filepath, read_only=True)
            sheet_names = wb.sheetnames
            info: dict[str, Any] = {
                "success": True,
                "filepath": filepath,
                "sheets": [],
            }
            for name in sheet_names:
                ws = wb[name]
                info["sheets"].append({
                    "name": name,
                    "rows": ws.max_row or 0,
                    "cols": ws.max_column or 0,
                })
            wb.close()
            return info
        except ImportError:
            return {"success": False, "error": "openpyxl is not installed"}
        except FileNotFoundError:
            return {"success": False, "error": f"File not found: {filepath}"}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def read_sheet(self, filepath: str, sheet_name: str | None = None,
                   header_row: bool = True, max_rows: int | None = None) -> dict[str, Any]:
        """Read data from an Excel sheet.

        Args:
            filepath: Path to .xlsx file
            sheet_name: Sheet name (default: first sheet)
            header_row: If True, first row becomes column headers
            max_rows: Max data rows to read

        Returns:
            Dict with headers, rows, and metadata
        """
        try:
            import openpyxl
            wb = openpyxl.load_workbook(filepath, read_only=True)

            if sheet_name:
                if sheet_name not in wb.sheetnames:
                    wb.close()
                    return {"success": False, "error": f"Sheet '{sheet_name}' not found"}
                ws = wb[sheet_name]
            else:
                ws = wb.active

            if ws is None:
                wb.close()
                return {"success": False, "error": "Workbook has no active sheet"}
            rows_iter = ws.iter_rows(values_only=True)
            headers: list[str] | None = None
            data: list[list[str]] = []

            if header_row:
                try:
                    raw_header = next(rows_iter)
                    headers = [str(c) if c is not None else "" for c in raw_header]
                except StopIteration:
                    wb.close()
                    return {"success": True, "headers": None, "rows": [], "total_rows": 0}

            count = 0
            for row in rows_iter:
                data.append([str(c) if c is not None else "" for c in row])
                count += 1
                if max_rows and count >= max_rows:
                    break

            # Strip trailing fully-empty rows
            while data and all(cell == "" for cell in data[-1]):
                data.pop()

            wb.close()
            return {
                "success": True,
                "filepath": filepath,
                "sheet": ws.title,
                "headers": headers,
                "rows": data,
                "total_rows": len(data),
            }
        except ImportError:
            return {"success": False, "error": "openpyxl is not installed"}
        except FileNotFoundError:
            return {"success": False, "error": f"File not found: {filepath}"}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def write_sheet(self, filepath: str, sheet_name: str = "Sheet1",
                    headers: list[str] | None = None,
                    rows: list[list[str]] | None = None,
                    mode: str = "new") -> dict[str, Any]:
        """Write data to an Excel file.

        Args:
            filepath: Path to .xlsx file
            sheet_name: Sheet name
            headers: Optional column headers (first row)
            rows: Data rows
            mode: 'new' creates file, 'append' adds sheet to existing

        Returns:
            Dict with result metadata
        """
        try:
            import openpyxl
            from openpyxl.styles import Font, PatternFill
            from openpyxl.utils import get_column_letter

            if mode == "append" and os.path.exists(filepath):
                wb = openpyxl.load_workbook(filepath)
            else:
                wb = openpyxl.Workbook()
                # Remove default sheet if we're creating named sheets
                if sheet_name != "Sheet1" and "Sheet" in wb.sheetnames:
                    del wb["Sheet"]

            if sheet_name in wb.sheetnames:
                ws = wb[sheet_name]
            else:
                ws = wb.create_sheet(title=sheet_name)

            row_data = rows or []

            if headers:
                # Write header row with bold formatting
                ws.append(headers)
                header_font = Font(bold=True)
                header_fill = PatternFill(start_color="D9E1F2", end_color="D9E1F2", fill_type="solid")
                for col_idx in range(1, len(headers) + 1):
                    cell = ws.cell(row=1, column=col_idx)
                    cell.font = header_font
                    cell.fill = header_fill

            for row in row_data:
                ws.append(row)

            # Auto-adjust column widths (simple approach)
            for col_idx, col in enumerate(
                headers or (row_data[0] if row_data else []), start=1
            ):
                max_len = len(str(col)) if col else 10
                for row in ws.iter_rows(min_row=1, max_row=min(len(row_data) + 5, 50),
                                        min_col=col_idx, max_col=col_idx,
                                        values_only=True):
                    for cell_val in row:
                        if cell_val is not None:
                            max_len = max(max_len, min(len(str(cell_val)), 40))
                ws.column_dimensions[get_column_letter(col_idx)].width = max_len + 2

            wb.save(filepath)
            return {
                "success": True,
                "filepath": filepath,
                "sheet": sheet_name,
                "headers_count": len(headers) if headers else 0,
                "rows_written": len(row_data),
            }
        except ImportError:
            return {"success": False, "error": "openpyxl is not installed"}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def merge_files(self, filepaths: list[str], output_path: str) -> dict[str, Any]:
        """Merge multiple Excel files into one workbook with separate sheets.

        Args:
            filepaths: List of .xlsx file paths to merge
            output_path: Output .xlsx file path

        Returns:
            Dict with merge results
        """
        try:
            import openpyxl
            wb = openpyxl.Workbook()
            # Remove default sheet
            if "Sheet" in wb.sheetnames:
                del wb["Sheet"]

            merged_count = 0
            errors: list[str] = []

            for fp in filepaths:
                try:
                    src_wb = openpyxl.load_workbook(fp, read_only=True)
                    for sheet_name in src_wb.sheetnames:
                        ws_src = src_wb[sheet_name]
                        # Create unique sheet name
                        base_name = Path(fp).stem[:20]
                        target_name = f"{base_name}_{sheet_name}"[:31]
                        # Handle name conflicts
                        counter = 1
                        orig_target = target_name
                        while target_name in wb.sheetnames:
                            suffix = f"_{counter}"
                            target_name = f"{orig_target[:31 - len(suffix)]}{suffix}"
                            counter += 1

                        ws_dst = wb.create_sheet(title=target_name)
                        for row in ws_src.iter_rows(values_only=True):
                            ws_dst.append([str(c) if c is not None else "" for c in row])

                    src_wb.close()
                    merged_count += 1
                except Exception as e:
                    errors.append(f"{fp}: {e}")

            wb.save(output_path)
            return {
                "success": True,
                "output_path": output_path,
                "files_merged": merged_count,
                "files_total": len(filepaths),
                "errors": errors if errors else None,
            }
        except ImportError:
            return {"success": False, "error": "openpyxl is not installed"}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def csv_to_xlsx(self, csv_path: str, xlsx_path: str, sheet_name: str = "Sheet1",
                    delimiter: str = ",") -> dict[str, Any]:
        """Convert a CSV file to Excel format.

        Args:
            csv_path: Path to input CSV file
            xlsx_path: Path to output .xlsx file
            sheet_name: Sheet name in output
            delimiter: CSV delimiter

        Returns:
            Dict with result metadata
        """
        try:
            import openpyxl
            from openpyxl.styles import Font, PatternFill

            wb = openpyxl.Workbook()
            ws = wb.active
            if ws is None:
                return {"success": False, "error": "Failed to create worksheet"}
            ws.title = sheet_name

            with open(csv_path, newline="", encoding="utf-8-sig") as f:
                reader = csv.reader(f, delimiter=delimiter)
                first_row = True
                for row in reader:
                    ws.append(row)
                    if first_row:
                        # Bold the header row
                        header_font = Font(bold=True)
                        header_fill = PatternFill(
                            start_color="D9E1F2", end_color="D9E1F2", fill_type="solid"
                        )
                        for col_idx in range(1, len(row) + 1):
                            cell = ws.cell(row=1, column=col_idx)
                            cell.font = header_font
                            cell.fill = header_fill
                        first_row = False

            wb.save(xlsx_path)
            return {
                "success": True,
                "input": csv_path,
                "output": xlsx_path,
                "sheet": sheet_name,
            }
        except ImportError:
            return {"success": False, "error": "openpyxl is not installed"}
        except FileNotFoundError:
            return {"success": False, "error": f"CSV file not found: {csv_path}"}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def xlsx_to_csv(self, xlsx_path: str, csv_path: str,
                    sheet_name: str | None = None,
                    delimiter: str = ",") -> dict[str, Any]:
        """Convert an Excel sheet to CSV format.

        Args:
            xlsx_path: Path to input .xlsx file
            csv_path: Path to output CSV file
            sheet_name: Sheet to convert (default: first sheet)
            delimiter: CSV delimiter

        Returns:
            Dict with result metadata
        """
        try:
            import openpyxl
            wb = openpyxl.load_workbook(xlsx_path, read_only=True)

            if sheet_name:
                if sheet_name not in wb.sheetnames:
                    wb.close()
                    return {"success": False, "error": f"Sheet '{sheet_name}' not found"}
                ws = wb[sheet_name]
            else:
                ws = wb.active

            if ws is None:
                wb.close()
                return {"success": False, "error": "Workbook has no active sheet"}
            with open(csv_path, "w", newline="", encoding="utf-8") as f:
                writer = csv.writer(f, delimiter=delimiter)
                for row in ws.iter_rows(values_only=True):
                    writer.writerow([str(c) if c is not None else "" for c in row])

            wb.close()
            return {
                "success": True,
                "input": xlsx_path,
                "output": csv_path,
                "sheet": ws.title,
            }
        except ImportError:
            return {"success": False, "error": "openpyxl is not installed"}
        except FileNotFoundError:
            return {"success": False, "error": f"XLSX file not found: {xlsx_path}"}
        except Exception as e:
            return {"success": False, "error": str(e)}
