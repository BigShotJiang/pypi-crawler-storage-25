"""RAG / AI Infrastructure Tools - Chunking, embeddings, vector search, RAG pipeline."""

import hashlib
import json
import math
import os
import re
from pathlib import Path
from typing import Any, Optional

import requests

STORAGE_DIR = os.path.expanduser("~/.nexus-tools/rag/")
OLLAMA_BASE = os.environ.get("OLLAMA_HOST", "http://localhost:11434")


def _ensure_storage(subdir: str = "") -> str:
    """Ensure a storage subdirectory exists."""
    path = Path(STORAGE_DIR) / subdir
    path.mkdir(parents=True, exist_ok=True)
    return str(path)


# --- Text Chunking ---

def chunk_text(
    text: str,
    chunk_size: int = 500,
    overlap: int = 50,
    method: str = "character",
) -> dict[str, Any]:
    """Split text into overlapping chunks for RAG.

    Args:
        text: Input text to chunk
        chunk_size: Target chunk size in characters
        overlap: Overlap between consecutive chunks
        method: 'character' (by char count) or 'sentence' (by sentence boundary)

    Returns:
        Dict with chunks list, count, and metadata
    """
    if not text.strip():
        return {"success": True, "chunks": [], "count": 0, "total_chars": 0}

    chunks = []

    if method == "sentence":
        # Split by sentence boundaries, then group into chunks
        sentences = re.split(r"(?<=[.!?])\s+", text)
        current = ""
        for sent in sentences:
            if len(current) + len(sent) >= chunk_size and current:
                chunks.append(current.strip())
                # Overlap: keep last few sentences
                words = current.split()
                overlap_words = words[-max(1, overlap // 5):]
                current = " ".join(overlap_words) + " " if overlap_words else ""
            current += " " + sent if current else sent
        if current.strip():
            chunks.append(current.strip())
    else:
        # Character-based chunking with overlap
        start = 0
        text_len = len(text)
        while start < text_len:
            end = min(start + chunk_size, text_len)
            # Try to break at a word boundary
            if end < text_len:
                # Find last space within the chunk
                last_space = text.rfind(" ", start, end)
                if last_space > start + chunk_size // 2:
                    end = last_space
            chunk = text[start:end].strip()
            if chunk:
                chunks.append(chunk)
            start = end - overlap if end < text_len else text_len

    return {
        "success": True,
        "chunks": chunks,
        "count": len(chunks),
        "total_chars": len(text),
        "method": method,
        "chunk_size": chunk_size,
        "overlap": overlap,
    }


# --- Embeddings via Ollama ---

def _call_ollama_embed(model: str, input_text: str) -> Optional[list[float]]:
    """Call Ollama embeddings API."""
    try:
        resp = requests.post(
            f"{OLLAMA_BASE}/api/embed",
            json={"model": model, "input": input_text},
            timeout=60,
        )
        resp.raise_for_status()
        data = resp.json()
        embeddings = data.get("embeddings", [])
        if embeddings:
            return embeddings[0]
        return None
    except requests.RequestException:
        return None


def ollama_embed(
    text: str,
    model: str = "nomic-embed-text",
) -> dict[str, Any]:
    """Generate embeddings for text using local Ollama.

    Args:
        text: Text to embed
        model: Ollama model name (default: nomic-embed-text)

    Returns:
        Dict with embedding vector, dimensions, model
    """
    embedding = _call_ollama_embed(model, text)
    if embedding is None:
        # Check if model exists
        models = ollama_models_list()
        available = [m.get("name") for m in models.get("models", [])]
        return {
            "success": False,
            "error": f"Failed to get embedding from Ollama model '{model}'",
            "available_models": available,
        }

    return {
        "success": True,
        "embedding": embedding,
        "dimensions": len(embedding),
        "model": model,
    }


def ollama_models_list() -> dict[str, Any]:
    """List available Ollama models.

    Returns:
        Dict with models list (name, size, modified)
    """
    try:
        resp = requests.get(f"{OLLAMA_BASE}/api/tags", timeout=10)
        resp.raise_for_status()
        data = resp.json()

        models = []
        for m in data.get("models", []):
            models.append({
                "name": m.get("name"),
                "size_bytes": m.get("size", 0),
                "modified": m.get("modified_at", ""),
            })
        return {"success": True, "models": models, "count": len(models)}
    except requests.RequestException as e:
        return {"success": False, "error": f"Cannot reach Ollama: {e}"}


# --- Vector Math ---

def _cosine_similarity(a: list[float], b: list[float]) -> float:
    """Compute cosine similarity between two vectors."""
    if not a or not b or len(a) != len(b):
        return 0.0
    dot = sum(ai * bi for ai, bi in zip(a, b))
    norm_a = math.sqrt(sum(ai * ai for ai in a))
    norm_b = math.sqrt(sum(bi * bi for bi in b))
    if norm_a == 0 or norm_b == 0:
        return 0.0
    return dot / (norm_a * norm_b)


# --- Vector Store ---

def vector_store_create(
    index_name: str,
    model: str = "nomic-embed-text",
) -> dict[str, Any]:
    """Create a new vector index.

    Args:
        index_name: Name for the index
        model: Embedding model used

    Returns:
        Dict with index info
    """
    dir_path = _ensure_storage("indexes")
    index_path = Path(dir_path) / f"{index_name}.json"

    if index_path.exists():
        return {"success": False, "error": f"Index '{index_name}' already exists"}

    index_data = {
        "model": model,
        "dimensions": None,
        "documents": [],
    }
    index_path.write_text(json.dumps(index_data, indent=2), encoding="utf-8")
    return {
        "success": True,
        "index_name": index_name,
        "path": str(index_path),
        "documents_count": 0,
    }


def vector_store_add(
    index_name: str,
    documents: list[str],
    embed_model: str = "nomic-embed-text",
) -> dict[str, Any]:
    """Embed documents and add them to a vector index.

    Each document gets embedded and stored with its text and embedding.

    Args:
        index_name: Name of the index
        documents: List of text documents to add
        embed_model: Ollama embedding model

    Returns:
        Dict with added count and index stats
    """
    dir_path = _ensure_storage("indexes")
    index_path = Path(dir_path) / f"{index_name}.json"

    if not index_path.exists():
        return {"success": False, "error": f"Index '{index_name}' not found. Create it first."}

    index_data = json.loads(index_path.read_text(encoding="utf-8"))
    if index_data["dimensions"] is None and documents:
        # Get first embedding to determine dimensions
        first_emb = _call_ollama_embed(embed_model, documents[0])
        if first_emb is None:
            return {"success": False, "error": f"Failed to get embedding from {embed_model}"}
        index_data["dimensions"] = len(first_emb)
        index_data["documents"].append({
            "id": _doc_id(documents[0]),
            "text": documents[0],
            "embedding": first_emb,
        })
        remaining = documents[1:]
    else:
        remaining = documents

    added = 0
    errors = 0
    for doc in remaining:
        emb = _call_ollama_embed(embed_model, doc)
        if emb is None:
            errors += 1
            continue
        index_data["documents"].append({
            "id": _doc_id(doc),
            "text": doc,
            "embedding": emb,
        })
        added += 1

    total = len(index_data["documents"])
    index_path.write_text(json.dumps(index_data, indent=2), encoding="utf-8")

    return {
        "success": True,
        "added": added + (1 if index_data["dimensions"] is not None and documents else 0),
        "errors": errors,
        "total_documents": total,
        "dimensions": index_data["dimensions"],
        "model": index_data["model"],
    }


def vector_store_search(
    index_name: str,
    query: str,
    top_k: int = 5,
    embed_model: str = "nomic-embed-text",
) -> dict[str, Any]:
    """Search a vector index by cosine similarity.

    Args:
        index_name: Name of the index
        query: Search query text
        top_k: Number of top results to return
        embed_model: Ollama embedding model

    Returns:
        Dict with ranked results (text + score)
    """
    dir_path = _ensure_storage("indexes")
    index_path = Path(dir_path) / f"{index_name}.json"

    if not index_path.exists():
        return {"success": False, "error": f"Index '{index_name}' not found"}

    index_data = json.loads(index_path.read_text(encoding="utf-8"))
    docs = index_data.get("documents", [])
    if not docs:
        return {"success": True, "results": [], "count": 0, "message": "Index is empty"}

    # Embed the query
    query_emb = _call_ollama_embed(embed_model, query)
    if query_emb is None:
        return {"success": False, "error": f"Failed to embed query with {embed_model}"}

    # Score all documents
    scored = []
    for doc in docs:
        emb = doc.get("embedding")
        if emb:
            score = _cosine_similarity(query_emb, emb)
            scored.append({
                "id": doc["id"],
                "text": doc["text"],
                "score": round(score, 6),
            })

    # Sort by score descending
    scored.sort(key=lambda x: x["score"], reverse=True)

    return {
        "success": True,
        "results": scored[:top_k],
        "count": len(scored[:top_k]),
        "total_in_index": len(docs),
        "query": query,
    }


def vector_store_list() -> dict[str, Any]:
    """List all vector indexes.

    Returns:
        Dict with indexes list and info
    """
    dir_path = _ensure_storage("indexes")
    indexes = []
    for f in Path(dir_path).glob("*.json"):
        try:
            data = json.loads(f.read_text(encoding="utf-8"))
            indexes.append({
                "name": f.stem,
                "model": data.get("model"),
                "dimensions": data.get("dimensions"),
                "documents": len(data.get("documents", [])),
            })
        except (json.JSONDecodeError, OSError):
            indexes.append({"name": f.stem, "status": "corrupted"})
    return {"success": True, "indexes": indexes, "count": len(indexes)}


def vector_store_delete(index_name: str) -> dict[str, Any]:
    """Delete a vector index.

    Args:
        index_name: Name of the index to delete

    Returns:
        Dict with success/error
    """
    dir_path = _ensure_storage("indexes")
    index_path = Path(dir_path) / f"{index_name}.json"
    if not index_path.exists():
        return {"success": False, "error": f"Index '{index_name}' not found"}
    index_path.unlink()
    return {"success": True, "message": f"Index '{index_name}' deleted"}


# --- Full RAG Pipeline ---

def rag_retrieve(
    text: str,
    query: str,
    chunk_size: int = 500,
    chunk_overlap: int = 50,
    top_k: int = 3,
    embed_model: str = "nomic-embed-text",
    index_name: Optional[str] = None,
) -> dict[str, Any]:
    """End-to-end RAG retrieve: chunk text, embed chunks + query, search by similarity.

    Can use an existing index or create a temporary one.

    Args:
        text: Source text to index
        query: Question or search query
        chunk_size: Character chunk size
        chunk_overlap: Overlap between chunks
        top_k: Number of relevant chunks to return
        embed_model: Ollama embedding model
        index_name: Optional existing index to search (if None, creates temp)

    Returns:
        Dict with ranked relevant chunks and metadata
    """
    if index_name:
        # Search existing index
        return vector_store_search(index_name, query, top_k, embed_model)

    # Create temp in-memory index
    chunk_result = chunk_text(text, chunk_size, chunk_overlap)
    chunks = chunk_result.get("chunks", [])
    if not chunks:
        return {"success": False, "error": "No chunks generated from text"}

    # Embed all chunks
    chunk_embeddings = []
    for chunk in chunks:
        emb = _call_ollama_embed(embed_model, chunk)
        if emb:
            chunk_embeddings.append(emb)

    if not chunk_embeddings:
        return {
            "success": False,
            "error": f"Failed to embed any chunks with {embed_model}. Is Ollama running?",
        }

    # Embed query
    query_emb = _call_ollama_embed(embed_model, query)
    if query_emb is None:
        return {"success": False, "error": "Failed to embed query"}

    # Score and rank
    scored = []
    for i, chunk in enumerate(chunks):
        if i < len(chunk_embeddings):
            score = _cosine_similarity(query_emb, chunk_embeddings[i])
            scored.append({
                "chunk_index": i,
                "text": chunk,
                "score": round(score, 6),
            })

    scored.sort(key=lambda x: x["score"], reverse=True)

    return {
        "success": True,
        "query": query,
        "results": scored[:top_k],
        "count": len(scored[:top_k]),
        "total_chunks": len(chunks),
        "model": embed_model,
        "chunk_size": chunk_size,
        "chunk_overlap": chunk_overlap,
    }


def _doc_id(text: str) -> str:
    """Generate a deterministic document ID from text."""
    return hashlib.sha256(text.encode("utf-8")).hexdigest()[:16]
