"""GraphQL Helpers - Query, validate, and introspect GraphQL APIs."""

import json as _json
import subprocess
from typing import Any, Optional


def _run_graphql(url: str, query: str, variables: Optional[dict] = None) -> dict[str, Any]:
    """Execute a GraphQL query via curl POST."""
    payload: dict[str, Any] = {"query": query}
    if variables:
        payload["variables"] = variables

    try:
        result = subprocess.run(
            ["curl", "-s", "-X", "POST", url,
             "-H", "Content-Type: application/json",
             "-d", _json.dumps(payload)],
            capture_output=True, text=True, timeout=30,
        )
        if result.returncode != 0:
            return {"success": False, "error": result.stderr.strip()}

        data = _json.loads(result.stdout)
        return {
            "success": "errors" not in data,
            "data": data.get("data"),
            "errors": data.get("errors"),
            "error": str(data.get("errors")) if data.get("errors") else None,
        }
    except _json.JSONDecodeError as e:
        return {"success": False, "error": f"Invalid JSON response: {e}"}
    except subprocess.TimeoutExpired:
        return {"success": False, "error": "GraphQL request timed out"}
    except FileNotFoundError:
        return {"success": False, "error": "curl not found in PATH"}
    except Exception as e:
        return {"success": False, "error": str(e)}


def graphql_query(
    url: str,
    query: str,
    variables: Optional[str] = None,
    operation_name: Optional[str] = None,
) -> dict[str, Any]:
    """Execute a GraphQL query or mutation.

    Args:
        url: GraphQL endpoint URL
        query: GraphQL query/mutation string
        variables: Optional JSON string of variables
        operation_name: Optional operation name

    Returns:
        Dict with data, errors, success
    """
    vars_dict: Optional[dict] = None
    if variables:
        try:
            vars_dict = _json.loads(variables)
        except _json.JSONDecodeError as e:
            return {"success": False, "error": f"Invalid variables JSON: {e}"}

    final_query = query
    if operation_name:
        final_query = f"query {operation_name} {query}" if not query.strip().startswith(("query", "mutation")) else query

    return _run_graphql(url, final_query, vars_dict)


def graphql_introspect(url: str) -> dict[str, Any]:
    """Introspect a GraphQL endpoint for schema details.

    Args:
        url: GraphQL endpoint URL

    Returns:
        Dict with schema types, queries, mutations, etc.
    """
    introspection_query = """
    query IntrospectionQuery {
      __schema {
        queryType { name }
        mutationType { name }
        subscriptionType { name }
        types {
          kind
          name
          description
          fields(includeDeprecated: true) {
            name
            description
            type { kind name ofType { kind name } }
          }
        }
      }
    }
    """
    result = _run_graphql(url, introspection_query)
    if not result["success"]:
        return result

    schema = result.get("data", {}).get("__schema", {})
    if not schema:
        return {"success": False, "error": "No schema data returned"}

    types = schema.get("types", [])
    query_type_name = schema.get("queryType", {}).get("name")
    mutation_type_name = schema.get("mutationType", {}).get("name")

    queries = []
    mutations = []
    all_types = []

    for t in types:
        if t.get("name", "").startswith("__"):
            continue
        fields = t.get("fields") or []
        field_names = [f.get("name") for f in fields if f.get("name")]

        if t.get("name") == query_type_name:
            queries = field_names
        elif t.get("name") == mutation_type_name:
            mutations = field_names
        else:
            all_types.append({
                "kind": t.get("kind"),
                "name": t.get("name"),
                "description": t.get("description"),
                "fields_count": len(fields),
                "fields": field_names[:20],
            })

    return {
        "success": True,
        "query_type": query_type_name,
        "queries": queries,
        "queries_count": len(queries),
        "mutation_type": mutation_type_name,
        "mutations": mutations,
        "mutations_count": len(mutations),
        "types": all_types,
        "types_count": len(all_types),
    }


def graphql_schema_dump(url: str) -> dict[str, Any]:
    """Dump full GraphQL schema (types and their fields).

    Args:
        url: GraphQL endpoint URL

    Returns:
        Dict with type definitions in SDL-like format
    """
    result = graphql_introspect(url)
    if not result["success"]:
        return result

    schema_types = result.get("types", [])
    type_defs = []

    for t in schema_types:
        kind = t.get("kind", "")
        name = t.get("name", "")
        fields = t.get("fields", [])
        type_defs.append({
            "kind": kind,
            "name": name,
            "description": t.get("description"),
            "fields": fields,
        })

    # Also include queries and mutations as special
    queries = result.get("queries", [])
    mutations = result.get("mutations", [])

    return {
        "success": True,
        "type_count": len(type_defs),
        "query_count": len(queries),
        "mutation_count": len(mutations),
        "queries": queries,
        "mutations": mutations,
        "types": type_defs,
    }


def graphql_validate(url: str, query: str) -> dict[str, Any]:
    """Validate a GraphQL query against a schema via introspection.

    Uses a __validation query pattern - sends query directly and reports errors.

    Args:
        url: GraphQL endpoint URL
        query: GraphQL query to validate

    Returns:
        Dict with valid flag and any errors
    """
    result = _run_graphql(url, query)
    if result["success"] or result.get("errors"):
        return {
            "success": result["success"],
            "valid": result["success"],
            "errors": result.get("errors"),
            "error": result.get("error"),
        }
    return {
        "success": result["success"],
        "valid": True,
        "errors": None,
    }
