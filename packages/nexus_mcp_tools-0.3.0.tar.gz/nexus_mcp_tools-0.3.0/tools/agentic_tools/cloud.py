"""Cloud CLI Wrappers - AWS, GCP command helpers."""

import json as _json
import subprocess
from typing import Any


def _run(cmd: list[str], timeout: int = 30) -> dict[str, Any]:
    """Run CLI command and parse JSON output."""
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return {
            "success": result.returncode == 0,
            "stdout": result.stdout.strip(),
            "stderr": result.stderr.strip() if result.returncode != 0 else None,
            "exit_code": result.returncode,
        }
    except subprocess.TimeoutExpired:
        return {"success": False, "error": f"Timed out after {timeout}s"}
    except FileNotFoundError:
        return {"success": False, "error": f"Command not found: {cmd[0]}"}
    except Exception as e:
        return {"success": False, "error": str(e)}


def _parse_json(output: str) -> Any:
    """Try to parse a string as JSON, return raw string on failure."""
    if not output:
        return None
    try:
        return _json.loads(output)
    except _json.JSONDecodeError:
        return output


# --- AWS Tools ---

def aws_s3_ls(path: str = "s3://", recursive: bool = False) -> dict[str, Any]:
    """List S3 buckets or objects in a bucket.

    Args:
        path: S3 path (e.g. 's3://' or 's3://my-bucket/path')
        recursive: List recursively

    Returns:
        Dict with listing and count
    """
    cmd = ["aws", "s3", "ls", path]
    if recursive:
        cmd.append("--recursive")

    r = _run(cmd, timeout=30)
    if not r["success"]:
        return r

    lines = [ln for ln in r["stdout"].splitlines() if ln.strip()]
    return {"success": True, "entries": lines, "count": len(lines)}


def aws_lambda_list() -> dict[str, Any]:
    """List AWS Lambda functions.

    Returns:
        Dict with function list and count
    """
    r = _run(["aws", "lambda", "list-functions", "--output", "json"], timeout=30)
    if not r["success"]:
        return r

    data = _parse_json(r["stdout"])
    if isinstance(data, dict):
        functions = [
            {"name": fn.get("FunctionName"), "runtime": fn.get("Runtime"),
             "memory": fn.get("MemorySize"), "timeout": fn.get("Timeout")}
            for fn in data.get("Functions", [])
        ]
        return {"success": True, "functions": functions, "count": len(functions)}
    return {"success": True, "raw": r["stdout"]}


def aws_ec2_ls() -> dict[str, Any]:
    """List EC2 instances with state info.

    Returns:
        Dict with instances list and count
    """
    r = _run(["aws", "ec2", "describe-instances", "--output", "json"], timeout=30)
    if not r["success"]:
        return r

    data = _parse_json(r["stdout"])
    if isinstance(data, dict):
        instances = []
        for reservation in data.get("Reservations", []):
            for inst in reservation.get("Instances", []):
                instances.append({
                    "id": inst.get("InstanceId"),
                    "state": inst.get("State", {}).get("Name"),
                    "type": inst.get("InstanceType"),
                    "az": inst.get("Placement", {}).get("AvailabilityZone"),
                    "public_ip": inst.get("PublicIpAddress"),
                    "private_ip": inst.get("PrivateIpAddress"),
                    "launch_time": inst.get("LaunchTime"),
                    "name": next(
                        (t.get("Value") for t in inst.get("Tags", []) if t.get("Key") == "Name"),
                        "",
                    ),
                })
        return {"success": True, "instances": instances, "count": len(instances)}
    return {"success": True, "raw": r["stdout"]}


# --- GCP Tools ---

def gcp_storage_ls(path: str = "gs://") -> dict[str, Any]:
    """List GCS buckets or objects.

    Args:
        path: GCS path (e.g. 'gs://' or 'gs://my-bucket/path')

    Returns:
        Dict with listing and count
    """
    cmd = ["gcloud", "storage", "ls", path]
    r = _run(cmd, timeout=30)
    if not r["success"]:
        return r

    lines = [ln for ln in r["stdout"].splitlines() if ln.strip()]
    return {"success": True, "entries": lines, "count": len(lines)}


def gcp_compute_ls() -> dict[str, Any]:
    """List GCE instances.

    Returns:
        Dict with instances list and count
    """
    r = _run([
        "gcloud", "compute", "instances", "list",
        "--format", "json",
    ], timeout=30)
    if not r["success"]:
        return r

    data = _parse_json(r["stdout"])
    if isinstance(data, list):
        instances = [
            {
                "name": inst.get("name"),
                "zone": inst.get("zone", "").split("/")[-1],
                "machine_type": inst.get("machineType", "").split("/")[-1],
                "status": inst.get("status"),
                "internal_ip": next(
                    (nic.get("networkIP") for nic in inst.get("networkInterfaces", [])),
                    "",
                ),
                "external_ip": next(
                    (ac.get("natIP") for nic in inst.get("networkInterfaces", [])
                     for ac in nic.get("accessConfigs", [])),
                    "",
                ),
            }
            for inst in data
        ]
        return {"success": True, "instances": instances, "count": len(instances)}
    return {"success": True, "raw": r["stdout"]}


def gcp_run_ls() -> dict[str, Any]:
    """List Cloud Run services.

    Returns:
        Dict with services list and count
    """
    r = _run([
        "gcloud", "run", "services", "list",
        "--format", "json",
    ], timeout=30)
    if not r["success"]:
        return r

    data = _parse_json(r["stdout"])
    if isinstance(data, list):
        services = [
            {
                "name": svc.get("name", "").split("/")[-1],
                "region": svc.get("metadata", {}).get("labels", {}).get("cloud.googleapis.com/location", ""),
                "url": svc.get("status", {}).get("url", ""),
                "last_modified": svc.get("metadata", {}).get("creationTimestamp", ""),
            }
            for svc in data
        ]
        return {"success": True, "services": services, "count": len(services)}
    return {"success": True, "raw": r["stdout"]}
