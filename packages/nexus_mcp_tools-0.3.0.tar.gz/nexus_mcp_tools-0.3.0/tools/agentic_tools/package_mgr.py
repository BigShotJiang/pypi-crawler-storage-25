"""Package Manager Tools - Inspect npm, pip, uv, and other package managers."""

import json as _json
import subprocess
from typing import Any


def _run(cmd: list[str], timeout: int = 30) -> dict[str, Any]:
    """Run a shell command and return structured result."""
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return {
            "success": result.returncode == 0,
            "stdout": result.stdout.strip(),
            "stderr": result.stderr.strip() if result.returncode != 0 else None,
            "exit_code": result.returncode,
        }
    except subprocess.TimeoutExpired:
        return {"success": False, "error": f"Timed out after {timeout}s", "stdout": "", "stderr": ""}
    except FileNotFoundError:
        return {"success": False, "error": f"Command not found: {cmd[0]} not in PATH", "stdout": "", "stderr": ""}
    except Exception as e:
        return {"success": False, "error": str(e), "stdout": "", "stderr": ""}


def pip_list(show_latest: bool = False) -> dict[str, Any]:
    """List installed Python packages.

    Args:
        show_latest: Also check latest available version from PyPI

    Returns:
        Dict with packages list, count, and optional latest versions
    """
    r = _run(["pip", "list", "--format", "json"], timeout=30)
    if not r["success"]:
        return r
    try:
        packages = _json.loads(r["stdout"])
    except _json.JSONDecodeError as e:
        return {"success": False, "error": f"Failed to parse pip list: {e}"}

    result = {
        "success": True,
        "packages": packages,
        "count": len(packages),
    }

    if show_latest:
        outdated = _run(["pip", "list", "--outdated", "--format", "json"], timeout=60)
        if outdated["success"]:
            try:
                outdated_pkgs = _json.loads(outdated["stdout"])
                outdated_map = {p["name"]: p["latest_version"] for p in outdated_pkgs}
                for pkg in packages:
                    pkg["latest_version"] = outdated_map.get(pkg["name"])
            except (_json.JSONDecodeError, KeyError):
                pass

    return result


def pip_show(package: str) -> dict[str, Any]:
    """Show details for an installed Python package.

    Args:
        package: Package name

    Returns:
        Dict with package metadata (version, requires, summary, etc.)
    """
    r = _run(["pip", "show", package], timeout=15)
    if not r["success"]:
        return r

    details = {}
    for line in r["stdout"].splitlines():
        if ":" in line:
            key, _, val = line.partition(":")
            details[key.strip().lower()] = val.strip()

    requires = details.get("requires", "")
    details["requires_list"] = [r.strip() for r in requires.split(",") if r.strip()] if requires else []
    return {"success": True, "details": details}


def npm_list(depth: int = 0, production: bool = False) -> dict[str, Any]:
    """List installed npm packages.

    Args:
        depth: Dependency tree depth (0 = direct deps only)
        production: Show only production dependencies

    Returns:
        Dict with dependency tree and count
    """
    cmd = ["npm", "list", "--json"]
    if depth is not None:
        cmd.append(f"--depth={depth}")
    if production:
        cmd.append("--production")

    r = _run(cmd, timeout=30)
    if not r["success"]:
        return r

    try:
        data = _json.loads(r["stdout"])
    except _json.JSONDecodeError:
        return {"success": False, "error": "Failed to parse npm list output"}

    deps = data.get("dependencies", {})
    summary = _summarize_npm_tree(deps, depth)
    return {"success": True, "dependencies": deps, "summary": summary, "total": len(summary)}


def npm_outdated() -> dict[str, Any]:
    """List outdated npm packages.

    Returns:
        Dict with outdated packages, showing current vs wanted vs latest
    """
    r = _run(["npm", "outdated", "--json"], timeout=30)
    if not r["success"]:
        return r

    try:
        data = _json.loads(r["stdout"]) if r["stdout"] else {}
    except _json.JSONDecodeError:
        data = {}

    if not data:
        return {"success": True, "outdated_packages": [], "count": 0, "message": "All packages are up to date"}

    packages = []
    for name, info in data.items():
        packages.append({
            "name": name,
            "current": info.get("current", ""),
            "wanted": info.get("wanted", ""),
            "latest": info.get("latest", ""),
            "location": info.get("location", ""),
        })
    return {"success": True, "outdated_packages": packages, "count": len(packages)}


def uv_deps() -> dict[str, Any]:
    """List dependencies from uv.lock or pyproject.toml using uv.

    Returns:
        Dict with dependency list from uv
    """
    r = _run(["uv", "tree"], timeout=30)
    if not r["success"]:
        return r

    lines = [ln for ln in r["stdout"].splitlines() if ln.strip()]
    return {"success": True, "tree": lines, "count": len(lines)}


def _summarize_npm_tree(deps: dict, depth: int) -> list[dict]:
    """Flatten npm dependency tree into a summary list."""
    flat = []

    def _walk(tree: dict, current_depth: int):
        for name, info in tree.items():
            flat.append({
                "name": name,
                "version": info.get("version", ""),
                "depth": current_depth,
                "has_deps": bool(info.get("dependencies")),
            })
            if current_depth < depth and info.get("dependencies"):
                _walk(info["dependencies"], current_depth + 1)

    _walk(deps, 0)
    return flat
