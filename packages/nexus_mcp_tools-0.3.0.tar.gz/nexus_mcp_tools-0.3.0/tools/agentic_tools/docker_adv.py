"""Advanced Docker Management Tools - Compose, images, exec, prune, network, volumes."""

import json as _json
import subprocess
from typing import Any, Optional


def _run_docker(cmd: list[str], timeout: int = 60) -> dict[str, Any]:
    """Run a docker command and return structured result."""
    try:
        result = subprocess.run(
            cmd, capture_output=True, text=True, timeout=timeout,
        )
        return {
            "success": result.returncode == 0,
            "output": result.stdout.strip(),
            "error": result.stderr.strip() if result.returncode != 0 else None,
        }
    except subprocess.TimeoutExpired:
        return {"success": False, "error": f"Command timed out after {timeout}s", "output": ""}
    except FileNotFoundError:
        return {"success": False, "error": "Docker not found in PATH", "output": ""}
    except Exception as e:
        return {"success": False, "error": str(e), "output": ""}


def compose_ps(compose_file: Optional[str] = None, project_name: Optional[str] = None) -> dict[str, Any]:
    """List services status in a Docker Compose project.

    Args:
        compose_file: Path to docker-compose.yml (optional, uses default)
        project_name: Optional project name filter

    Returns:
        Dict with success flag and service status list
    """
    cmd = ["docker", "compose"]
    if compose_file:
        cmd += ["-f", compose_file]
    if project_name:
        cmd += ["-p", project_name]
    cmd += ["ps", "--format", "json"]

    result = _run_docker(cmd)
    if not result["success"]:
        return result

    services = []
    for line in result["output"].splitlines():
        line = line.strip()
        if line:
            try:
                services.append(_json.loads(line))
            except _json.JSONDecodeError:
                services.append({"raw": line})
    return {"success": True, "services": services, "count": len(services)}


def compose_logs(
    compose_file: Optional[str] = None,
    service: Optional[str] = None,
    lines: int = 50,
    follow: bool = False,
    tail: bool = True,
) -> dict[str, Any]:
    """Fetch logs from Docker Compose services.

    Args:
        compose_file: Path to docker-compose.yml
        service: Specific service name (optional, all if omitted)
        lines: Number of recent lines (default 50)
        follow: Stream new log lines (default False)
        tail: Show tail end of logs (default True)

    Returns:
        Dict with log output lines
    """
    cmd = ["docker", "compose"]
    if compose_file:
        cmd += ["-f", compose_file]
    cmd += ["logs"]
    if follow:
        cmd.append("--follow")
    if tail:
        cmd += ["--tail", str(lines)]
    if service:
        cmd.append(service)

    result = _run_docker(cmd, timeout=30 if not follow else 10)
    if not result["success"]:
        return result

    log_lines = [line for line in result["output"].splitlines() if line.strip()]
    return {"success": True, "lines": log_lines, "count": len(log_lines)}


def image_inspect(image_ref: str) -> dict[str, Any]:
    """Inspect a Docker image with full metadata.

    Args:
        image_ref: Image name and tag (e.g. 'python:3.12-slim')

    Returns:
        Dict with image metadata (id, size, layers, env, ports, etc.)
    """
    cmd = ["docker", "image", "inspect", image_ref]
    result = _run_docker(cmd)
    if not result["success"]:
        return result

    try:
        data = _json.loads(result["output"])
    except _json.JSONDecodeError as e:
        return {"success": False, "error": f"Failed to parse image inspect: {e}"}

    if not data:
        return {"success": False, "error": f"Image '{image_ref}' not found"}

    img = data[0]
    summary = {
        "id": img.get("Id", ""),
        "repo_tags": img.get("RepoTags", []),
        "created": img.get("Created", ""),
        "size_bytes": img.get("Size", 0),
        "size_human": _human_size(img.get("Size", 0)),
        "os": img.get("Os", ""),
        "architecture": img.get("Architecture", ""),
        "env_vars": img.get("Config", {}).get("Env", []),
        "exposed_ports": list(img.get("Config", {}).get("ExposedPorts", {}).keys()),
        "entrypoint": img.get("Config", {}).get("Entrypoint", []),
        "cmd": img.get("Config", {}).get("Cmd", []),
        "volumes": list(img.get("Config", {}).get("Volumes", {}).keys()),
        "labels": img.get("Config", {}).get("Labels", {}),
        "layer_count": len(img.get("RootFS", {}).get("Layers", [])),
    }
    return {"success": True, "image": summary}


def container_exec(
    container_id: str,
    command: str,
    workdir: Optional[str] = None,
    interactive: bool = False,
    env: Optional[list[str]] = None,
) -> dict[str, Any]:
    """Execute a command inside a running container.

    Args:
        container_id: Container name or ID
        command: Command to run (e.g. 'ls -la /app')
        workdir: Working directory inside container
        interactive: Allocate pseudo-TTY (default False)
        env: Environment variables (list of 'KEY=VALUE' strings)

    Returns:
        Dict with stdout, stderr, exit code
    """
    cmd = ["docker", "exec"]
    if interactive:
        cmd.append("-it")
    if workdir:
        cmd += ["-w", workdir]
    if env:
        for e in env:
            cmd += ["-e", e]
    cmd += [container_id] + command.split()

    result = _run_docker(cmd, timeout=30)
    if not result["success"]:
        return result
    return {"success": True, "stdout": result["output"], "stderr": result.get("error")}


def docker_prune(
    all_resources: bool = False,
    volumes: bool = False,
    force: bool = False,
) -> dict[str, Any]:
    """Clean up unused Docker resources.

    Args:
        all_resources: Prune all unused objects (not just dangling)
        volumes: Also prune unused volumes
        force: Skip confirmation prompt

    Returns:
        Dict with freed space and details per resource type
    """
    results = {}
    total_freed = 0

    # Images
    img_cmd = ["docker", "image", "prune", "--filter", "until=0"]
    if all_resources:
        img_cmd.append("-a")
    if force:
        img_cmd.append("--force")
    img_cmd += ["--format", "{{.ID}} {{.Size}}"]
    r = _run_docker(img_cmd, timeout=60)
    if r["success"]:
        reclaimed = _parse_reclaimed(r["output"])
        results["images"] = {"items": len(r["output"].splitlines()) if r["output"] else 0, "reclaimed_bytes": reclaimed}
        total_freed += reclaimed

    # Containers
    c_cmd = ["docker", "container", "prune", "--force"]
    c_cmd += ["--filter", "until=0h"]
    r = _run_docker(c_cmd, timeout=60)
    if r["success"]:
        reclaimed = _parse_reclaimed(r["output"])
        results["containers"] = {"items": 0, "reclaimed_bytes": reclaimed}
        total_freed += reclaimed

    # Networks
    n_cmd = ["docker", "network", "prune", "--force"]
    r = _run_docker(n_cmd, timeout=60)
    if r["success"]:
        reclaimed = _parse_reclaimed(r["output"])
        results["networks"] = {"items": 0, "reclaimed_bytes": reclaimed}
        total_freed += reclaimed

    # Volumes (optional)
    if volumes:
        v_cmd = ["docker", "volume", "prune", "--force"]
        r = _run_docker(v_cmd, timeout=60)
        if r["success"]:
            reclaimed = _parse_reclaimed(r["output"])
            results["volumes"] = {"items": 0, "reclaimed_bytes": reclaimed}
            total_freed += reclaimed

    return {
        "success": True,
        "total_freed_bytes": total_freed,
        "total_freed_human": _human_size(total_freed),
        "details": results,
    }


def network_inspect(network_name: str) -> dict[str, Any]:
    """Inspect a Docker network and list connected containers.

    Args:
        network_name: Network name or ID

    Returns:
        Dict with network config, driver, subnet, containers, etc.
    """
    cmd = ["docker", "network", "inspect", network_name]
    result = _run_docker(cmd)
    if not result["success"]:
        return result

    try:
        data = _json.loads(result["output"])
    except _json.JSONDecodeError as e:
        return {"success": False, "error": f"Failed to parse network inspect: {e}"}

    if not data:
        return {"success": False, "error": f"Network '{network_name}' not found"}

    net = data[0]
    containers_raw = net.get("Containers", {}) or {}
    containers = []
    for cid, cinfo in containers_raw.items():
        containers.append({
            "id": cid[:12],
            "name": cinfo.get("Name", ""),
            "ipv4": cinfo.get("IPv4Address", ""),
            "ipv6": cinfo.get("IPv6Address", ""),
        })

    ipam = net.get("IPAM", {})
    summary = {
        "id": net.get("Id", "")[:12],
        "name": net.get("Name", ""),
        "driver": net.get("Driver", ""),
        "scope": net.get("Scope", ""),
        "created": net.get("Created", ""),
        "internal": net.get("Internal", False),
        "attachable": net.get("Attachable", False),
        "subnet": ipam.get("Config", [{}])[0].get("Subnet", "") if ipam.get("Config") else "",
        "gateway": ipam.get("Config", [{}])[0].get("Gateway", "") if ipam.get("Config") else "",
        "containers": containers,
        "container_count": len(containers),
        "options": net.get("Options", {}),
        "labels": net.get("Labels", {}),
    }
    return {"success": True, "network": summary}


def volume_ls(dangling_only: bool = False, driver: Optional[str] = None) -> dict[str, Any]:
    """List Docker volumes with size and mount info.

    Args:
        dangling_only: Show only dangling (unused) volumes
        driver: Filter by driver (e.g. 'local')

    Returns:
        Dict with volumes list and summary
    """
    cmd = ["docker", "volume", "ls", "--format", "json"]
    if dangling_only:
        cmd.append("--filter")
        cmd.append("dangling=true")
    if driver:
        cmd += ["--filter", f"driver={driver}"]

    result = _run_docker(cmd)
    if not result["success"]:
        return result

    volumes = []
    for line in result["output"].splitlines():
        line = line.strip()
        if line:
            try:
                volumes.append(_json.loads(line))
            except _json.JSONDecodeError:
                volumes.append({"raw": line})

    return {"success": True, "volumes": volumes, "count": len(volumes)}


def _human_size(bytes_val: int) -> str:
    """Convert bytes to human-readable string."""
    val: float = float(bytes_val)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if val < 1024:
            return f"{val:.1f} {unit}"
        val /= 1024.0
    return f"{val:.1f} PB"


def _parse_reclaimed(output: str) -> int:
    """Parse reclaimed space from docker prune output."""
    import re
    match = re.search(r"(\d+(?:\.\d+)?)\s*(kB|MB|GB|TB|B)", output or "")
    if not match:
        return 0
    val = float(match.group(1))
    unit = match.group(2)
    multipliers = {"B": 1, "kB": 1024, "MB": 1024**2, "GB": 1024**3, "TB": 1024**4}
    return int(val * multipliers.get(unit, 1))
