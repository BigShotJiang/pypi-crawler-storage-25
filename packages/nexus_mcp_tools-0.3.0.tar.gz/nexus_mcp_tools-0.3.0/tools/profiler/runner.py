"""Code profiler for execution timing and performance analysis."""

import cProfile
import io
import pstats
import time
import traceback
from typing import Any, Dict, List, Optional


class CodeProfiler:
    """Profiler for executing and timing Python code."""

    def profile_execute(
        self, code: str, timeout: int = 30, filename: str = "<string>"
    ) -> Dict[str, Any]:
        """Execute Python code string and profile it with cProfile and timeit.

        Args:
            code: Python code string to execute
            timeout: Maximum execution time in seconds
            filename: Filename to use in profiling output

        Returns:
            Dict with success, stdout, stderr, duration_ms, ncalls, tottime,
            cumtime, error
        """
        try:
            # Capture stdout and stderr
            stdout_capture = io.StringIO()
            stderr_capture = io.StringIO()

            # Set up timing with timeit
            start_time = time.perf_counter()

            # Set up cProfile
            profiler = cProfile.Profile()
            profiler.enable()

            # Execute the code with timeout simulation via timeit
            try:
                compiled = compile(code, filename, "exec")

                # Execute in a restricted namespace
                exec_globals: Dict[str, Any] = {}
                exec_locals: Dict[str, Any] = {}

                exec(compiled, exec_globals, exec_locals)

                profiler.disable()

            except Exception as exec_err:
                profiler.disable()
                end_time = time.perf_counter()
                duration_ms = (end_time - start_time) * 1000

                return {
                    "success": False,
                    "stdout": "",
                    "stderr": str(exec_err),
                    "duration_ms": duration_ms,
                    "ncalls": 0,
                    "tottime": 0,
                    "cumtime": 0,
                    "error": str(exec_err),
                }

            end_time = time.perf_counter()
            duration_ms = (end_time - start_time) * 1000

            # Get stdout/stderr
            stdout = stdout_capture.getvalue()
            stderr = stderr_capture.getvalue()

            # Get stats from profiler
            s = io.StringIO()
            stats = pstats.Stats(profiler, stream=s)
            stats.sort_stats("cumulative")
            stats.print_stats(10)

            stats_output = s.getvalue()

            # Extract key metrics
            ncalls = 0
            tottime = 0.0
            cumtime = 0.0

            if stats_output:
                lines = stats_output.split("\n")
                for line in lines:
                    if "function calls" in line:
                        parts = line.split()
                        for i, part in enumerate(parts):
                            if part == "calls":
                                if i > 0:
                                    try:
                                        ncalls = int(parts[i - 1].replace(",", ""))
                                    except ValueError:
                                        pass

            # Get tottime and cumtime from stats object
            stats_list = stats.stats  # type: ignore[attr-defined]
            if stats_list:
                # Get total time from all callers
                total_stats = stats_list.get(("", 0), None)
                if total_stats:
                    tottime = total_stats[3]  # tottime is index 3
                    cumtime = total_stats[2]  # cumtime is index 2

            return {
                "success": True,
                "stdout": stdout,
                "stderr": stderr,
                "duration_ms": round(duration_ms, 2),
                "ncalls": ncalls,
                "tottime": round(tottime, 4),
                "cumtime": round(cumtime, 4),
                "profile_output": stats_output[:1000] if stats_output else "",
                "error": None,
            }

        except Exception as e:
            return {
                "success": False,
                "stdout": "",
                "stderr": traceback.format_exc(),
                "duration_ms": 0,
                "ncalls": 0,
                "tottime": 0,
                "cumtime": 0,
                "error": str(e),
            }

    def profile_function(
        self,
        func_str: str,
        args: Optional[List[Any]] = None,
        kwargs: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Profile a function by its string definition.

        Args:
            func_str: Python function definition as string
            args: Positional arguments to call the function with
            kwargs: Keyword arguments to call the function with

        Returns:
            Dict with profiling statistics including ncalls, tottime, cumtime
        """
        try:
            if args is None:
                args = []
            if kwargs is None:
                kwargs = {}

            # Compile the function definition
            compiled = compile(func_str, "<function>", "exec")

            # Execute to get the function in namespace
            namespace: Dict[str, Any] = {}
            exec(compiled, namespace)

            # Find the function (last defined function in namespace)
            func = None
            for name, obj in namespace.items():
                if callable(obj) and not name.startswith("_"):
                    func = obj
                    break

            if func is None:
                raise ValueError("No function found in provided code")

            # Profile the function call
            profiler = cProfile.Profile()
            profiler.enable()

            result = func(*args, **kwargs)

            profiler.disable()

            # Extract statistics
            stats = pstats.Stats(profiler)
            stats.sort_stats("cumulative")

            # Get aggregate stats
            total_calls = 0
            total_tt = 0.0
            total_ct = 0.0

            for func_obj, (cc, nc, tt, ct, callers) in stats.stats.items():  # type: ignore[attr-defined]
                if nc > 0:
                    total_calls += nc
                    total_tt += tt
                    total_ct += ct

            # Get top functions
            top_functions: List[Dict[str, Any]] = []
            for func_obj, (cc, nc, tt, ct, callers) in sorted(
                stats.stats.items(), key=lambda x: x[1][3], reverse=True  # type: ignore[attr-defined]
            )[:10]:
                if nc > 0:
                    filename, line, name = func_obj
                    top_functions.append({
                        "function": name,
                        "filename": filename,
                        "lineno": line,
                        "ncalls": nc,
                        "tottime": round(tt, 4),
                        "cumtime": round(ct, 4),
                    })

            return {
                "success": True,
                "total_calls": total_calls,
                "total_tottime": round(total_tt, 4),
                "total_cumtime": round(total_ct, 4),
                "top_functions": top_functions,
                "result": str(result)[:500] if result is not None else None,
                "error": None,
            }

        except Exception as e:
            return {
                "success": False,
                "total_calls": 0,
                "total_tottime": 0,
                "total_cumtime": 0,
                "top_functions": [],
                "result": None,
                "error": str(e),
            }