"""Profile comparator for comparing profiling results."""

from typing import Any, Dict, List


class ProfileComparator:
    """Comparator for analyzing differences between profiling runs."""

    def profile_compare(self, before: Dict[str, Any], after: Dict[str, Any]) -> Dict[str, Any]:
        """Compare two profiling result dictionaries.

        Args:
            before: First profiling result
            after: Second profiling result

        Returns:
            Dict with changes list and summary
        """
        try:
            changes: List[Dict[str, Any]] = []

            # Compare duration
            if "duration_ms" in before and "duration_ms" in after:
                before_dur = before.get("duration_ms", 0)
                after_dur = after.get("duration_ms", 0)
                delta = after_dur - before_dur
                pct = (delta / before_dur * 100) if before_dur > 0 else 0
                changes.append({
                    "metric": "duration_ms",
                    "before": before_dur,
                    "after": after_dur,
                    "delta": round(delta, 2),
                    "pct_change": round(pct, 2),
                })

            # Compare ncalls
            if "ncalls" in before and "ncalls" in after:
                before_calls = before.get("ncalls", 0)
                after_calls = after.get("ncalls", 0)
                delta = after_calls - before_calls
                pct = (delta / before_calls * 100) if before_calls > 0 else 0
                changes.append({
                    "metric": "ncalls",
                    "before": before_calls,
                    "after": after_calls,
                    "delta": delta,
                    "pct_change": round(pct, 2),
                })

            # Compare tottime
            if "tottime" in before and "tottime" in after:
                before_tt = before.get("tottime", 0)
                after_tt = after.get("tottime", 0)
                delta = after_tt - before_tt
                pct = (delta / before_tt * 100) if before_tt > 0 else 0
                changes.append({
                    "metric": "tottime",
                    "before": round(before_tt, 4),
                    "after": round(after_tt, 4),
                    "delta": round(delta, 4),
                    "pct_change": round(pct, 2),
                })

            # Compare cumtime
            if "cumtime" in before and "cumtime" in after:
                before_ct = before.get("cumtime", 0)
                after_ct = after.get("cumtime", 0)
                delta = after_ct - before_ct
                pct = (delta / before_ct * 100) if before_ct > 0 else 0
                changes.append({
                    "metric": "cumtime",
                    "before": round(before_ct, 4),
                    "after": round(after_ct, 4),
                    "delta": round(delta, 4),
                    "pct_change": round(pct, 2),
                })

            # Compare total_calls for function profiling
            if "total_calls" in before and "total_calls" in after:
                before_calls = before.get("total_calls", 0)
                after_calls = after.get("total_calls", 0)
                delta = after_calls - before_calls
                pct = (delta / before_calls * 100) if before_calls > 0 else 0
                changes.append({
                    "metric": "total_calls",
                    "before": before_calls,
                    "after": after_calls,
                    "delta": delta,
                    "pct_change": round(pct, 2),
                })

            # Compare memory if present
            if "peak_memory_kb" in before and "peak_memory_kb" in after:
                before_mem = before.get("peak_memory_kb", 0)
                after_mem = after.get("peak_memory_kb", 0)
                delta = after_mem - before_mem
                pct = (delta / before_mem * 100) if before_mem > 0 else 0
                changes.append({
                    "metric": "peak_memory_kb",
                    "before": round(before_mem, 2),
                    "after": round(after_mem, 2),
                    "delta": round(delta, 2),
                    "pct_change": round(pct, 2),
                })

            # Determine summary
            improved = 0
            regressed = 0
            unchanged = 0

            for change in changes:
                pct_change = change.get("pct_change", 0)
                metric = change.get("metric", "")

                # For most metrics, negative is better (faster, less memory)
                # But for ncalls/calls, might want to consider context

                # Simple heuristic: improvement = negative delta for duration/memory
                if metric in ("duration_ms", "tottime", "cumtime", "peak_memory_kb"):
                    if pct_change < -5:
                        improved += 1
                    elif pct_change > 5:
                        regressed += 1
                    else:
                        unchanged += 1
                elif metric in ("ncalls", "total_calls"):
                    if pct_change < -5:
                        improved += 1
                    elif pct_change > 5:
                        regressed += 1
                    else:
                        unchanged += 1

            summary = {
                "improved": improved,
                "regressed": regressed,
                "unchanged": unchanged,
            }

            return {
                "changes": changes,
                "summary": summary,
                "error": None,
            }

        except Exception as e:
            return {
                "changes": [],
                "summary": {"improved": 0, "regressed": 0, "unchanged": 0},
                "error": str(e),
            }