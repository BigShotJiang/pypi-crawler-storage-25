"""Memory profiler for tracking Python memory usage."""

import sys
import tracemalloc
from typing import Any, Dict, List, Optional, Set


class MemoryProfiler:
    """Profiler for tracking Python memory usage."""

    def profile_memory(self, code: str) -> Dict[str, Any]:
        """Profile memory usage of executing code using tracemalloc.

        Args:
            code: Python code string to execute

        Returns:
            Dict with success, peak_memory_kb, current_memory_kb,
            top_lines, error
        """
        try:
            # Start tracing
            tracemalloc.start()

            # Take snapshot before
            snapshot_before = tracemalloc.take_snapshot()

            # Execute the code
            try:
                compiled = compile(code, "<memory_profile>", "exec")
                exec_globals: Dict[str, Any] = {}
                exec_locals: Dict[str, Any] = {}
                exec(compiled, exec_globals, exec_locals)
            except Exception as exec_err:
                tracemalloc.stop()
                return {
                    "success": False,
                    "peak_memory_kb": 0,
                    "current_memory_kb": 0,
                    "top_lines": [],
                    "error": str(exec_err),
                }

            # Take snapshot after
            snapshot_after = tracemalloc.take_snapshot()

            # Stop tracing
            tracemalloc.stop()

            # Calculate memory differences
            top_stats = snapshot_after.compare_to(snapshot_before, "lineno")

            # Calculate peak memory (approximation based on total differences)
            total_diff_kb = sum(stat.size_diff for stat in top_stats) / 1024
            peak_memory_kb = max(0, total_diff_kb)

            # Get current memory
            current_mem = tracemalloc.get_traced_memory()[0]
            current_memory_kb = current_mem / 1024

            # Get top memory consuming lines
            top_lines: List[Dict[str, Any]] = []
            for stat in top_stats[:20]:
                if stat.size_diff > 0:
                    traceback_str = str(stat.traceback)
                    # Extract relevant parts
                    lines = traceback_str.split("\n")[:3]
                    # Get line number from traceback
                    lineno = 0
                    if stat.traceback:
                        for frame in stat.traceback._frames:
                            if hasattr(frame, "lineno"):
                                lineno = frame.lineno
                                break
                    top_lines.append({
                        "filename": str(stat.traceback).split("\n")[0] if stat.traceback else "unknown",
                        "lineno": lineno,
                        "size_kb": round(stat.size_diff / 1024, 2),
                        "traceback": "\n".join(lines),
                    })

            return {
                "success": True,
                "peak_memory_kb": round(peak_memory_kb, 2),
                "current_memory_kb": round(current_memory_kb, 2),
                "top_lines": top_lines,
                "error": None,
            }

        except Exception as e:
            tracemalloc.stop()
            return {
                "success": False,
                "peak_memory_kb": 0,
                "current_memory_kb": 0,
                "top_lines": [],
                "error": str(e),
            }

    def profile_object(self, data: Any) -> Dict[str, Any]:
        """Estimate memory size of a Python object using sys.getsizeof.

        Args:
            data: Python object (passed as JSON-serializable through MCP)

        Returns:
            Dict with total_bytes, type, breakdown
        """
        try:
            breakdown: Dict[str, Any] = {}

            def get_size(obj: Any, seen: Optional[Set[int]] = None) -> int:
                """Recursively calculate size of object."""
                if seen is None:
                    seen = set()

                # Get size of this object
                size = sys.getsizeof(obj)

                # Add size of contained objects
                if isinstance(obj, dict):
                    seen.add(id(obj))
                    for key, value in obj.items():
                        if id(value) not in seen:
                            size += get_size(value, seen)
                        if isinstance(key, str):
                            size += sys.getsizeof(key)
                elif isinstance(obj, (list, tuple, set, frozenset)):
                    seen.add(id(obj))
                    for item in obj:
                        if id(item) not in seen:
                            size += get_size(item, seen)
                elif hasattr(obj, "__dict__"):
                    seen.add(id(obj))
                    size += get_size(obj.__dict__, seen)

                return size

            total_bytes = get_size(data)

            # Create breakdown based on type
            if isinstance(data, dict):
                breakdown = {}
                for key, value in data.items():
                    val_bytes = get_size(value)
                    breakdown[key] = {
                        "bytes": val_bytes,
                        "type": type(value).__name__,
                    }
            elif isinstance(data, list):
                breakdown = {}
                for i, item in enumerate(data):
                    val_bytes = get_size(item)
                    breakdown[f"item_{i}"] = {
                        "bytes": val_bytes,
                        "type": type(item).__name__,
                    }
            elif isinstance(data, (str, int, float, bool)) or data is None:
                breakdown = {"value": {"bytes": total_bytes, "type": type(data).__name__}}
            else:
                breakdown = {"object": {"bytes": total_bytes, "type": type(data).__name__}}

            return {
                "total_bytes": total_bytes,
                "type": type(data).__name__,
                "breakdown": breakdown,
                "error": None,
            }

        except Exception as e:
            return {
                "total_bytes": 0,
                "type": "unknown",
                "breakdown": {},
                "error": str(e),
            }