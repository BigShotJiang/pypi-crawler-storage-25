"""Network inspection utilities - DNS, port checks, SSL, whois, connectivity."""

import socket
import ssl
import time
from datetime import datetime
from typing import Any


class NetworkChecker:
    """Network diagnostics - DNS, port, SSL, whois, HTTP checks."""

    def dns_lookup(self, hostname: str, record_type: str = "A") -> dict[str, Any]:
        """Perform a DNS lookup for a hostname.

        Args:
            hostname: Hostname to resolve
            record_type: DNS record type (A, AAAA, MX, CNAME, NS, TXT)

        Returns:
            Dict with resolved records and timing
        """
        try:
            import dns.resolver
            import dns.rdatatype
            rtype = getattr(dns.rdatatype, record_type.upper(), dns.rdatatype.A)
            start = time.time()
            answers = dns.resolver.resolve(hostname, rtype)
            elapsed = round((time.time() - start) * 1000, 2)
            records = [str(r) for r in answers]
            return {
                "success": True,
                "hostname": hostname,
                "record_type": record_type.upper(),
                "records": records,
                "count": len(records),
                "ttl": answers.rrset.ttl if answers.rrset else None,
                "duration_ms": elapsed,
            }
        except ImportError:
            # Fallback: use socket.getaddrinfo for simple A/AAAA lookups
            if record_type.upper() in ("A", "AAAA"):
                try:
                    start = time.time()
                    family = socket.AF_INET if record_type.upper() == "A" else socket.AF_INET6
                    info = socket.getaddrinfo(hostname, None, family)
                    elapsed = round((time.time() - start) * 1000, 2)
                    records = list(set(i[4][0] for i in info))
                    return {
                        "success": True,
                        "hostname": hostname,
                        "record_type": record_type.upper(),
                        "records": records,
                        "count": len(records),
                        "duration_ms": elapsed,
                        "note": "Fallback: dnspython not installed",
                    }
                except socket.gaierror as e:
                    return {"success": False, "error": str(e), "hostname": hostname}
            return {"success": False, "error": f"dnspython not installed; cannot query {record_type} records"}
        except Exception as e:
            return {"success": False, "error": str(e), "hostname": hostname}

    def port_check(self, host: str, port: int, timeout: float = 3.0) -> dict[str, Any]:
        """Check if a TCP port is open on a host.

        Args:
            host: Hostname or IP address
            port: TCP port number
            timeout: Connection timeout in seconds

        Returns:
            Dict with open status and connection info
        """
        try:
            start = time.time()
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(timeout)
            result = sock.connect_ex((host, port))
            sock.close()
            elapsed = round((time.time() - start) * 1000, 2)
            return {
                "host": host,
                "port": port,
                "open": result == 0,
                "duration_ms": elapsed,
            }
        except socket.gaierror as e:
            return {"host": host, "port": port, "open": False, "error": f"DNS resolution failed: {e}"}
        except Exception as e:
            return {"host": host, "port": port, "open": False, "error": str(e)}

    def http_check(self, url: str, method: str = "HEAD", timeout: float = 10.0) -> dict[str, Any]:
        """Perform an HTTP health check against a URL.

        Args:
            url: Full URL to check
            method: HTTP method (HEAD is default, also GET)
            timeout: Request timeout in seconds

        Returns:
            Dict with status, timing, and response info
        """
        try:
            import httpx
            start = time.time()
            with httpx.Client(timeout=timeout, follow_redirects=True) as client:
                response = client.request(method, url)
            elapsed = round((time.time() - start) * 1000, 2)
            return {
                "success": True,
                "url": url,
                "status_code": response.status_code,
                "duration_ms": elapsed,
                "content_length": len(response.content),
                "content_type": response.headers.get("content-type", ""),
            }
        except ImportError:
            return {"success": False, "error": "httpx is not installed"}
        except Exception as e:
            return {"success": False, "error": str(e), "url": url}

    def ssl_info(self, hostname: str, port: int = 443, timeout: float = 5.0) -> dict[str, Any]:
        """Retrieve SSL/TLS certificate information for a host.

        Args:
            hostname: Server hostname
            port: Port (default: 443)
            timeout: Connection timeout

        Returns:
            Dict with certificate details
        """
        try:
            start = time.time()
            context = ssl.create_default_context()
            with socket.create_connection((hostname, port), timeout=timeout) as sock:
                with context.wrap_socket(sock, server_hostname=hostname) as ssock:
                    cert = ssock.getpeercert()
            elapsed = round((time.time() - start) * 1000, 2)

            if not cert:
                return {"success": True, "hostname": hostname, "port": port, "certificate": None}

            # Extract useful fields
            # cert subject/issuer is a list of lists of (key, value) tuples
            subject = {}
            for sub_list in cert.get("subject") or []:
                for pair in sub_list:
                    if isinstance(pair, tuple) and len(pair) >= 2:
                        subject[str(pair[0])] = str(pair[1])
            issuer = {}
            for sub_list in cert.get("issuer") or []:
                for pair in sub_list:
                    if isinstance(pair, tuple) and len(pair) >= 2:
                        issuer[str(pair[0])] = str(pair[1])
            not_before = str(cert.get("notBefore", ""))
            not_after = str(cert.get("notAfter", ""))

            # Calculate days until expiry
            days_remaining = None
            if not_after:
                try:
                    expiry = datetime.strptime(not_after, "%b %d %H:%M:%S %Y %Z")
                    days_remaining = (expiry - datetime.now()).days
                except (ValueError, TypeError):
                    pass

            return {
                "success": True,
                "hostname": hostname,
                "port": port,
                "duration_ms": elapsed,
                "subject": subject,
                "issuer": issuer,
                "not_before": not_before,
                "not_after": not_after,
                "days_remaining": days_remaining,
                "serial_number": cert.get("serialNumber", ""),
                "version": cert.get("version", ""),
                "san": cert.get("subjectAltName", []),
            }
        except Exception as e:
            return {"success": False, "error": str(e), "hostname": hostname, "port": port}

    def whois_lookup(self, query: str) -> dict[str, Any]:
        """Perform a whois lookup for a domain or IP.

        Args:
            query: Domain name or IP address

        Returns:
            Dict with whois text result
        """
        try:
            from whois import whois as whois_func  # type: ignore[import-untyped]
            start = time.time()
            w = whois_func(query)
            elapsed = round((time.time() - start) * 1000, 2)

            # Convert to serializable dict
            result = {"success": True, "query": query, "duration_ms": elapsed}

            # Extract common fields safely
            for field in ("domain_name", "registrar", "creation_date", "expiration_date",
                          "updated_date", "name_servers", "status", "emails", "org", "country"):
                val = getattr(w, field, None)
                if val:
                    if isinstance(val, list):
                        result[field] = [str(v) for v in val]
                    else:
                        result[field] = str(val)

            # Include the full text for completeness
            result["text"] = str(w)[:5000]
            return result
        except ImportError:
            return {"success": False, "error": "python-whois is not installed. Run: uv pip install whois"}
        except Exception as e:
            return {"success": False, "error": str(e), "query": query}

    def ip_info(self) -> dict[str, Any]:
        """Look up the public IP address and location info.

        Uses ip-api.com (free, no key required, rate-limited to 45 req/min).

        Returns:
            Dict with IP, location, ISP info
        """
        try:
            import httpx
            with httpx.Client(timeout=5.0) as client:
                resp = client.get("http://ip-api.com/json/")
                if resp.status_code == 200:
                    data = resp.json()
                    return {
                        "success": True,
                        "ip": data.get("query", ""),
                        "country": data.get("country", ""),
                        "region": data.get("regionName", ""),
                        "city": data.get("city", ""),
                        "isp": data.get("isp", ""),
                        "org": data.get("org", ""),
                        "lat": data.get("lat"),
                        "lon": data.get("lon"),
                        "timezone": data.get("timezone", ""),
                    }
                return {"success": False, "error": f"ip-api.com returned {resp.status_code}"}
        except ImportError:
            return {"success": False, "error": "httpx is not installed"}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def trace_route(self, hostname: str, max_hops: int = 15, timeout: float = 3.0) -> dict[str, Any]:
        """Run a traceroute simulation using increasing TTL values.

        Args:
            hostname: Target hostname
            max_hops: Maximum number of hops (default: 15)
            timeout: Per-hop timeout in seconds

        Returns:
            Dict with hops list showing each step
        """
        hops = []
        target_ip = None
        try:
            target_ip = socket.gethostbyname(hostname)
        except socket.gaierror as e:
            return {"success": False, "error": str(e), "hostname": hostname}

        for ttl in range(1, max_hops + 1):
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
            sock.settimeout(timeout)
            sock.setsockopt(socket.IPPROTO_IP, socket.IP_TTL, ttl)

            recv_sock = socket.socket(socket.AF_INET, socket.SOCK_RAW, socket.IPPROTO_ICMP)
            recv_sock.settimeout(timeout)
            recv_sock.bind(("0.0.0.0", 0))

            start = time.time()
            try:
                sock.sendto(b"", (hostname, 33434))
                data, addr = recv_sock.recvfrom(512)
                elapsed = round((time.time() - start) * 1000, 2)
                hop_ip = addr[0]
                hops.append({"hop": ttl, "ip": hop_ip, "duration_ms": elapsed})
                if hop_ip == target_ip:
                    hops.append({"hop": ttl, "ip": hop_ip, "message": "Reached destination"})
                    break
            except socket.timeout:
                hops.append({"hop": ttl, "ip": "*", "duration_ms": None, "message": "Timeout"})
            except Exception as e:
                hops.append({"hop": ttl, "ip": "*", "error": str(e)})
            finally:
                sock.close()
                recv_sock.close()

        return {"success": True, "hostname": hostname, "target_ip": target_ip, "hops": hops, "total_hops": len(hops)}
