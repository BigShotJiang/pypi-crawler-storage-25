"""Dependency analyzer for Python import graphs."""

import ast
from collections import defaultdict
from pathlib import Path
from typing import Any


class DependencyAnalyzer:
    """Analyze import graph of a Python project."""

    STDlib_MODULES = frozenset([
        "abc", "argparse", "array", "ast", "asyncio", "base64", "binascii", "bisect",
        "builtins", "cmath", "cmd", "codecs", "collections", "collections.abc",
        "contextlib", "copy", "csv", "datetime", "decimal", "difflib", "dis",
        "enum", "functools", "gc", "getopt", "getpass", "gettext", "glob",
        "hashlib", "heapq", "hmac", "html", "importlib", "inspect", "io",
        "itertools", "json", "keyword", "logging", "math", "mmap", "multiprocessing",
        "operator", "optparse", "os", "pathlib", "pprint", "queue", "random",
        "re", "reprlib", "shutil", "signal", "socket", "sqlite3", "statistics",
        "string", "struct", "subprocess", "sys", "tempfile", "textwrap", "threading",
        "time", "traceback", "typing", "types", "unittest", "urllib", "uuid",
        "warnings", "weakref", "xml", "zipfile", "zlib"
    ])

    def review_dependencies(self, path: str) -> dict:
        """Analyze import graph of a Python project.

        Args:
            path: Path to a Python file or directory

        Returns:
            Dict with files, imports, circular, unused, summary
        """
        try:
            path_obj = Path(path)
            if not path_obj.exists():
                return {"error": f"Path does not exist: {path}", "files": [], "summary": {}}

            if path_obj.is_file():
                if path_obj.suffix != ".py":
                    return {"error": "Not a Python file", "files": [], "summary": {}}
                return self._analyze_file(path_obj)
            else:
                return self._analyze_directory(path_obj)
        except Exception as e:
            return {"error": str(e), "files": [], "summary": {}}

    def _analyze_file(self, file_path: Path) -> dict:
        """Analyze imports in a single Python file."""
        imports = []
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                source = f.read()

            tree = ast.parse(source, filename=str(file_path))
            imports = self._extract_imports(tree)
        except Exception as e:
            return {
                "files": [{
                    "path": str(file_path),
                    "imports": [],
                    "error": str(e)
                }],
                "circular": [],
                "unused": [],
                "summary": {
                    "total_imports": 0,
                    "stdlib": 0,
                    "third_party": 0,
                    "local": 0,
                    "circular_count": 0,
                    "unused_count": 0
                }
            }

        return {
            "files": [{
                "path": str(file_path),
                "imports": imports
            }],
            "circular": [],
            "unused": self._find_unused_imports(file_path, imports),
            "summary": self._calculate_summary(imports)
        }

    def _analyze_directory(self, dir_path: Path) -> dict:
        """Analyze all Python files in a directory."""
        all_files = []
        all_imports = []
        dep_graph = defaultdict(set)
        file_modules = {}

        for py_file in dir_path.rglob("*.py"):
            if "__pycache__" in str(py_file):
                continue

            result = self._analyze_file(py_file)
            file_data = result["files"][0]
            all_files.append(file_data)
            all_imports.extend(file_data["imports"])

            # Build dependency graph
            module_name = self._path_to_module(py_file, dir_path)
            file_modules[module_name] = str(py_file)

            for imp in file_data["imports"]:
                if imp["category"] == "local":
                    dep_graph[module_name].add(imp["name"])

        # Detect circular imports
        circular = self._detect_circular_imports(dep_graph, file_modules)

        # Find unused imports across all files
        all_unused = []
        for f in all_files:
            all_unused.extend(f.get("unused", []))

        summary = self._calculate_summary(all_imports)
        summary["circular_count"] = len(circular)
        summary["unused_count"] = len(all_unused)

        return {
            "files": all_files,
            "circular": circular,
            "unused": all_unused,
            "summary": summary
        }

    def _extract_imports(self, tree: ast.AST) -> list[dict[str, Any]]:
        """Extract all imports from an AST."""
        imports = []

        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    imports.append({
                        "name": alias.name,
                        "category": self._categorize_import(alias.name),
                        "line": node.lineno
                    })

            elif isinstance(node, ast.ImportFrom):
                module = node.module or ""
                for alias in node.names:
                    full_name = f"{module}.{alias.name}" if module else alias.name
                    imports.append({
                        "name": full_name,
                        "category": self._categorize_import(full_name),
                        "line": node.lineno
                    })

        return imports

    def _categorize_import(self, name: str) -> str:
        """Categorize an import as stdlib, third-party, or local."""
        top_level = name.split(".")[0]

        if top_level in self.STDlib_MODULES:
            return "stdlib"

        # Check if it's a local import (relative or project-local)
        if name.startswith("."):
            return "local"

        # Common third-party indicators
        common_third_party = {"pytest", "django", "flask", "requests", "numpy", "pandas",
                             "tensorflow", "torch", "fastapi", "sqlalchemy", "pydantic"}

        if top_level in common_third_party:
            return "third_party"

        return "third_party"

    def _find_unused_imports(self, file_path: Path, imports: list[dict]) -> list[dict[str, Any]]:
        """Find unused imports in a file."""
        unused = []

        try:
            with open(file_path, "r", encoding="utf-8") as f:
                source = f.read()

            tree = ast.parse(source, filename=str(file_path))

            # Collect all used names in the file (excluding imports)
            used_names = set()
            for node in ast.walk(tree):
                if isinstance(node, ast.Name):
                    used_names.add(node.id)
                elif isinstance(node, ast.Attribute):
                    if isinstance(node.value, ast.Name):
                        used_names.add(node.value.id)

            # Check each import
            for imp in imports:
                name = imp["name"]
                top_level = name.split(".")[0]

                # Check if import is used
                if top_level not in used_names and name not in used_names:
                    # Also check if the alias is used
                    alias = name.split(".")[-1]
                    if alias not in used_names:
                        unused.append({
                            "file": str(file_path),
                            "import_name": name,
                            "line": imp["line"]
                        })

        except Exception:
            pass

        return unused

    def _detect_circular_imports(self, dep_graph: dict, file_modules: dict) -> list[dict[str, Any]]:
        """Detect circular imports in the dependency graph."""
        circular = []

        def has_cycle(node: str, visited: set, path: list[str]) -> list[str] | None:
            if node in path:
                cycle_start = path.index(node)
                return path[cycle_start:] + [node]
            if node in visited:
                return None

            visited.add(node)
            path.append(node)

            for dep in dep_graph.get(node, []):
                result = has_cycle(dep, visited, path[:])
                if result:
                    return result

            return None

        for module in dep_graph:
            cycle = has_cycle(module, set(), [])
            if cycle:
                # Avoid duplicate cycles
                cycle_set = set(cycle[:-1])
                if not any(set(c[:-1]) == cycle_set for c in circular):
                    circular.append({"cycle": cycle})

        return circular

    def _path_to_module(self, file_path: Path, base_path: Path) -> str:
        """Convert file path to module name."""
        try:
            rel_path = file_path.relative_to(base_path)
            parts = list(rel_path.parts[:-1])  # Remove .py extension
            if rel_path.stem != "__init__":
                parts.append(rel_path.stem)
            return ".".join(parts) if parts else "__init__"
        except ValueError:
            return file_path.stem

    def _calculate_summary(self, imports: list[dict]) -> dict:
        """Calculate summary statistics."""
        total = len(imports)
        stdlib_count = sum(1 for i in imports if i["category"] == "stdlib")
        third_party = sum(1 for i in imports if i["category"] == "third_party")
        local = sum(1 for i in imports if i["category"] == "local")

        return {
            "total_imports": total,
            "stdlib": stdlib_count,
            "third_party": third_party,
            "local": local,
            "circular_count": 0,
            "unused_count": 0
        }