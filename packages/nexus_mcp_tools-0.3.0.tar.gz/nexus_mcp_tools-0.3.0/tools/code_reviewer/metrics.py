"""Code metrics calculator for Python files."""

import ast
from pathlib import Path
from typing import Any


class CodeMetrics:
    """Calculate code metrics for Python files."""

    def review_metrics(self, path: str) -> dict:
        """Calculate code metrics for Python files.

        Args:
            path: Path to a Python file or directory

        Returns:
            Dict with files, metrics, summary
        """
        try:
            path_obj = Path(path)
            if not path_obj.exists():
                return {"error": f"Path does not exist: {path}", "files": [], "summary": {}}

            if path_obj.is_file():
                if path_obj.suffix != ".py":
                    return {"error": "Not a Python file", "files": [], "summary": {}}
                return self._analyze_file(path_obj)
            else:
                return self._analyze_directory(path_obj)
        except Exception as e:
            return {"error": str(e), "files": [], "summary": {}}

    def _analyze_file(self, file_path: Path) -> dict:
        """Analyze a single Python file."""
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                source = f.read()

            lines = source.split("\n")
            metrics = self._calculate_metrics(source, lines)
            functions = self._analyze_functions(source)
            class_complexity = self._analyze_classes(source)

            return {
                "files": [{
                    "path": str(file_path),
                    "metrics": metrics,
                    "functions": functions,
                    "class_complexity_avg": class_complexity
                }],
                "summary": {
                    "total_sloc": metrics["sloc"],
                    "total_functions": metrics["functions"],
                    "avg_complexity": self._average_complexity(functions),
                    "most_complex": self._most_complex_function(functions)
                }
            }
        except Exception as e:
            return {
                "files": [{
                    "path": str(file_path),
                    "metrics": {},
                    "functions": [],
                    "class_complexity_avg": 0
                }],
                "summary": {"error": str(e)}
            }

    def _analyze_directory(self, dir_path: Path) -> dict:
        """Analyze all Python files in a directory."""
        all_files = []
        total_sloc = 0
        total_functions = 0
        all_complexities = []
        most_complex = {"name": "", "complexity": 0, "file": ""}

        for py_file in dir_path.rglob("*.py"):
            if "__pycache__" in str(py_file):
                continue

            result = self._analyze_file(py_file)
            file_data = result["files"][0]
            all_files.append(file_data)

            total_sloc += file_data["metrics"].get("sloc", 0)
            total_functions += file_data["metrics"].get("functions", 0)

            for func in file_data.get("functions", []):
                all_complexities.append(func["complexity"])
                if func["complexity"] > most_complex["complexity"]:
                    most_complex = {
                        "name": func["name"],
                        "complexity": func["complexity"],
                        "file": str(py_file)
                    }

        avg_complexity = sum(all_complexities) / len(all_complexities) if all_complexities else 0

        return {
            "files": all_files,
            "summary": {
                "total_sloc": total_sloc,
                "total_functions": total_functions,
                "avg_complexity": round(avg_complexity, 2),
                "most_complex": most_complex
            }
        }

    def _calculate_metrics(self, source: str, lines: list[str]) -> dict:
        """Calculate basic code metrics."""
        total_lines = len(lines)
        blank_lines = sum(1 for line in lines if not line.strip())
        comment_lines = sum(1 for line in lines if line.strip().startswith("#"))

        # Code lines = total - blank - comments
        code_lines = total_lines - blank_lines - comment_lines

        try:
            tree = ast.parse(source)
            function_count = sum(1 for node in ast.walk(tree) if isinstance(node, ast.FunctionDef))
            class_count = sum(1 for node in ast.walk(tree) if isinstance(node, ast.ClassDef))

            # Methods = functions inside classes
            method_count = sum(
                sum(1 for n in ast.walk(cls) if isinstance(n, ast.FunctionDef))
                for cls in ast.walk(tree)
                if isinstance(cls, ast.ClassDef)
            )

        except SyntaxError:
            function_count = 0
            class_count = 0
            method_count = 0

        return {
            "sloc": code_lines,
            "comment_lines": comment_lines,
            "blank_lines": blank_lines,
            "functions": function_count,
            "classes": class_count,
            "methods": method_count
        }

    def _analyze_functions(self, source: str) -> list[dict[str, Any]]:
        """Analyze individual functions for complexity."""
        functions = []

        try:
            tree = ast.parse(source)
        except SyntaxError:
            return functions

        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef):
                complexity = self._calculate_cyclomatic_complexity(node)
                param_count = len(node.args.args)

                functions.append({
                    "name": node.name,
                    "complexity": complexity,
                    "line": node.lineno,
                    "params_count": param_count
                })

        return functions

    def _calculate_cyclomatic_complexity(self, func_node: ast.FunctionDef) -> int:
        """Calculate cyclomatic complexity for a function."""
        complexity = 1  # Base complexity

        for node in ast.walk(func_node):
            if isinstance(node, (ast.If, ast.While, ast.For)):
                complexity += 1
            elif isinstance(node, ast.BoolOp):
                complexity += len(node.values) - 1
            elif isinstance(node, ast.ExceptHandler):
                complexity += 1
            elif isinstance(node, ast.With):
                complexity += 1
            elif isinstance(node, ast.Assert):
                complexity += 1
            elif isinstance(node, (ast.ListComp, ast.DictComp, ast.SetComp)):
                complexity += 1

        return complexity

    def _analyze_classes(self, source: str) -> float:
        """Calculate average complexity of classes."""
        try:
            tree = ast.parse(source)
        except SyntaxError:
            return 0.0

        class_complexities = []

        for node in ast.walk(tree):
            if isinstance(node, ast.ClassDef):
                # Calculate complexity for all methods in class
                method_complexities = []
                for child in ast.walk(node):
                    if isinstance(child, ast.FunctionDef):
                        method_complexities.append(self._calculate_cyclomatic_complexity(child))

                if method_complexities:
                    class_complexities.append(sum(method_complexities) / len(method_complexities))

        return sum(class_complexities) / len(class_complexities) if class_complexities else 0.0

    def _average_complexity(self, functions: list[dict]) -> float:
        """Calculate average complexity across all functions."""
        if not functions:
            return 0.0

        total = sum(f["complexity"] for f in functions)
        return round(total / len(functions), 2)

    def _most_complex_function(self, functions: list[dict]) -> dict[str, Any]:
        """Find the most complex function."""
        if not functions:
            return {"name": "", "complexity": 0, "file": ""}

        most = max(functions, key=lambda f: f["complexity"])
        return {
            "name": most["name"],
            "complexity": most["complexity"],
            "line": most["line"]
        }