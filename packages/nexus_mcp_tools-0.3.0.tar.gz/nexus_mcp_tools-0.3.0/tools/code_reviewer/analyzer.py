"""Code analyzer for static analysis of Python code."""

import ast
from pathlib import Path
from typing import Any


class CodeAnalyzer:
    """Comprehensive static analysis of Python files and directories."""

    def review_code(self, path: str) -> dict:
        """Perform comprehensive static analysis of Python code.

        Args:
            path: Path to a Python file or directory

        Returns:
            Dict with files, issues, and overall_score
        """
        try:
            path_obj = Path(path)
            if not path_obj.exists():
                return {"error": f"Path does not exist: {path}", "files": [], "overall_score": 0}

            if path_obj.is_file():
                if path_obj.suffix != ".py":
                    return {"error": "Not a Python file", "files": [], "overall_score": 0}
                return self._analyze_file(path_obj)
            else:
                return self._analyze_directory(path_obj)
        except Exception as e:
            return {"error": str(e), "files": [], "overall_score": 0}

    def _analyze_file(self, file_path: Path) -> dict:
        """Analyze a single Python file."""
        issues = []
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                source = f.read()

            tree = ast.parse(source, filename=str(file_path))
            issues.extend(self._check_naming(tree, file_path))
            issues.extend(self._check_docstrings(tree, source, file_path))
            issues.extend(self._check_complexity(tree, source, file_path))
            issues.extend(self._check_todos(source, file_path))
        except SyntaxError as e:
            issues.append({
                "type": "syntax_error",
                "line": e.lineno or 1,
                "message": f"Syntax error: {e.msg}",
                "severity": "error"
            })
        except Exception as e:
            issues.append({
                "type": "parse_error",
                "line": 1,
                "message": f"Failed to parse: {str(e)}",
                "severity": "error"
            })

        total_issues = len(issues)
        by_severity = {"error": 0, "warning": 0, "info": 0}
        for issue in issues:
            by_severity[issue["severity"]] += 1

        overall_score = self._calculate_score(total_issues, by_severity)

        return {
            "files": [{
                "path": str(file_path),
                "issues": issues
            }],
            "summary": {
                "total_issues": total_issues,
                "by_severity": by_severity
            },
            "overall_score": overall_score
        }

    def _analyze_directory(self, dir_path: Path) -> dict:
        """Analyze all Python files in a directory."""
        all_files = []
        total_issues = 0
        by_severity = {"error": 0, "warning": 0, "info": 0}

        for py_file in dir_path.rglob("*.py"):
            if "__pycache__" in str(py_file):
                continue

            result = self._analyze_file(py_file)
            if "error" in result and "files" not in result:
                continue

            file_data = result["files"][0]
            all_files.append(file_data)
            total_issues += result["summary"]["total_issues"]

            for sev, count in result["summary"]["by_severity"].items():
                by_severity[sev] += count

        overall_score = self._calculate_score(total_issues, by_severity)

        return {
            "files": all_files,
            "summary": {
                "total_issues": total_issues,
                "by_severity": by_severity
            },
            "overall_score": overall_score
        }

    def _check_naming(self, tree: ast.AST, file_path: Path) -> list[dict[str, Any]]:
        """Check naming conventions."""
        issues = []

        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef):
                if not self._is_snake_case(node.name):
                    issues.append({
                        "type": "naming",
                        "line": node.lineno,
                        "message": f"Function '{node.name}' should be snake_case",
                        "severity": "warning"
                    })

            elif isinstance(node, ast.ClassDef):
                if not self._is_pascal_case(node.name):
                    issues.append({
                        "type": "naming",
                        "line": node.lineno,
                        "message": f"Class '{node.name}' should be PascalCase",
                        "severity": "warning"
                    })

            elif isinstance(node, ast.Assign):
                for target in node.targets:
                    if isinstance(target, ast.Name):
                        if self._is_constant(target.id):
                            if not self._is_upper_case(target.id):
                                issues.append({
                                    "type": "naming",
                                    "line": node.lineno,
                                    "message": f"Constant '{target.id}' should be UPPER_CASE",
                                    "severity": "info"
                                })

        return issues

    def _check_docstrings(self, tree: ast.AST, source: str, file_path: Path) -> list[dict[str, Any]]:
        """Check for missing docstrings."""
        issues = []

        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.ClassDef)):
                if not ast.get_docstring(node):
                    issues.append({
                        "type": "missing_docstring",
                        "line": node.lineno,
                        "message": f"{'Class' if isinstance(node, ast.ClassDef) else 'Function'} '{node.name}' lacks docstring",
                        "severity": "info"
                    })

        return issues

    def _check_complexity(self, tree: ast.AST, source: str, file_path: Path) -> list[dict[str, Any]]:
        """Check for overly complex functions."""
        issues = []

        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef):
                # Check nesting depth
                max_depth = self._get_max_nesting(node)
                if max_depth > 4:
                    issues.append({
                        "type": "high_nesting",
                        "line": node.lineno,
                        "message": f"Function '{node.name}' has nesting depth {max_depth} (max 4)",
                        "severity": "warning"
                    })

                # Check function length
                end_line = node.end_lineno or node.lineno
                func_length = end_line - node.lineno + 1
                if func_length > 50:
                    issues.append({
                        "type": "long_function",
                        "line": node.lineno,
                        "message": f"Function '{node.name}' has {func_length} lines (max 50)",
                        "severity": "warning"
                    })

                # Check parameter count
                param_count = len(node.args.args)
                if param_count > 5:
                    issues.append({
                        "type": "too_many_params",
                        "line": node.lineno,
                        "message": f"Function '{node.name}' has {param_count} parameters (max 5)",
                        "severity": "warning"
                    })

        return issues

    def _check_todos(self, source: str, file_path: Path) -> list[dict[str, Any]]:
        """Check for TODO and FIXME comments."""
        issues = []
        source_lines = source.split("\n")

        for i, line in enumerate(source_lines, 1):
            stripped = line.strip()
            if "TODO" in stripped.upper() or "FIXME" in stripped.upper():
                issues.append({
                    "type": "todo",
                    "line": i,
                    "message": stripped,
                    "severity": "info"
                })

        return issues

    def _get_max_nesting(self, node: ast.AST) -> int:
        """Calculate maximum nesting depth of a function."""
        max_depth = 0

        for child in ast.walk(node):
            if isinstance(child, (ast.If, ast.For, ast.While, ast.With, ast.ExceptHandler)):
                depth = self._get_depth_to_node(node, child)
                max_depth = max(max_depth, depth)

        return max_depth

    def _get_depth_to_node(self, parent: ast.AST, target: ast.AST) -> int:
        """Get nesting depth for a target node."""
        # Simple heuristic: count branch nodes between parent and target
        def count_depth(node: ast.AST, target: ast.AST, current: int) -> int:
            if node is target:
                return current
            for child in ast.iter_child_nodes(node):
                result = count_depth(child, target, current + 1)
                if result >= 0:
                    return result
            return -1

        return max(self._count_branch_parents(parent, target, 0), 1)

    def _count_branch_parents(self, parent: ast.AST, target: ast.AST, depth: int) -> int:
        """Count branch nodes in the path to target."""
        if parent is target:
            return depth
        for child in ast.iter_child_nodes(parent):
            result = self._count_branch_parents(child, target, depth)
            if result >= 0:
                if isinstance(parent, (ast.If, ast.For, ast.While, ast.With, ast.ExceptHandler)):
                    return result + 1
                return result
        return -1

    def _is_snake_case(self, name: str) -> bool:
        """Check if name is snake_case."""
        return name.islower() or "_" in name

    def _is_pascal_case(self, name: str) -> bool:
        """Check if name is PascalCase."""
        return name[0].isupper() if name else True

    def _is_upper_case(self, name: str) -> bool:
        """Check if name is UPPER_CASE."""
        return name.isupper() and "_" in name

    def _is_constant(self, name: str) -> bool:
        """Heuristic to check if a name might be a constant."""
        return name.isupper() or (len(name) > 2 and name[0].isupper())

    def _calculate_score(self, total_issues: int, by_severity: dict) -> float:
        """Calculate overall code score (0-100)."""
        if total_issues == 0:
            return 100.0

        # Deduct points based on severity
        deductions = by_severity["error"] * 5 + by_severity["warning"] * 2 + by_severity["info"] * 0.5
        score = max(0.0, 100.0 - deductions)
        return round(score, 2)