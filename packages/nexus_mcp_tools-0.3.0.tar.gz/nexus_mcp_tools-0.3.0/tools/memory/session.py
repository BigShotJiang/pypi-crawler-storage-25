"""Session tracker module - track activities within a coding session.

Inspired by Claude Code's conversation sessions.
"""

import json
import os
import uuid
from datetime import datetime, timezone
from typing import Optional


class SessionTracker:
    """Track activities within a coding session.

    Stores session data in ~/.nexus-tools/sessions/ directory.
    """

    def __init__(self):
        self.sessions_dir = os.path.expanduser("~/.nexus-tools/sessions")
        os.makedirs(self.sessions_dir, exist_ok=True)

    def _get_session_file(self, session_id: str) -> str:
        """Get the path to a session file."""
        return os.path.join(self.sessions_dir, f"{session_id}.json")

    def _load_session(self, session_id: str) -> Optional[dict]:
        """Load a session from file."""
        filepath = self._get_session_file(session_id)
        if os.path.exists(filepath):
            try:
                with open(filepath, "r", encoding="utf-8") as f:
                    return json.load(f)
            except (json.JSONDecodeError, IOError):
                return None
        return None

    def _save_session(self, session_data: dict) -> None:
        """Save a session to file."""
        filepath = self._get_session_file(session_data["session_id"])
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(session_data, f, indent=2, ensure_ascii=False)

    def session_start(
        self,
        name: Optional[str] = None,
        tags: Optional[list] = None,
        project: Optional[str] = None,
    ) -> dict:
        """Start a new session.

        Args:
            name: Optional session name
            tags: Optional list of tags for the session
            project: Optional project name

        Returns:
            Dict with session_id, name, start_time
        """
        try:
            if project is None:
                project = os.path.basename(os.getcwd()) or "default"

            session_id = str(uuid.uuid4())
            now = datetime.now(timezone.utc).isoformat()

            session_data = {
                "session_id": session_id,
                "name": name or f"Session {session_id[:8]}",
                "project": project,
                "tags": tags or [],
                "start_time": now,
                "events": [],
                "state": {},
                "closed": False,
            }

            self._save_session(session_data)

            return {
                "session_id": session_id,
                "name": session_data["name"],
                "start_time": now,
            }
        except Exception as e:
            return {"error": str(e), "session_id": None, "name": None, "start_time": None}

    def session_event(
        self,
        session_id: str,
        event_type: str,
        data: Optional[dict] = None,
    ) -> dict:
        """Log an event to a session.

        Args:
            session_id: The session ID
            event_type: Type of event (e.g., "file_created", "tool_called", "test_run", "build")
            data: Optional event data

        Returns:
            Dict with success, session_id, event_count
        """
        try:
            session_data = self._load_session(session_id)
            if not session_data:
                return {"success": False, "error": "Session not found", "session_id": session_id}

            now = datetime.now(timezone.utc).isoformat()
            event = {
                "timestamp": now,
                "type": event_type,
                "data": data or {},
            }

            session_data["events"].append(event)
            self._save_session(session_data)

            return {
                "success": True,
                "session_id": session_id,
                "event_count": len(session_data["events"]),
            }
        except Exception as e:
            return {"success": False, "error": str(e), "session_id": session_id}

    def session_state_set(
        self,
        session_id: str,
        key: str,
        value: str,
    ) -> dict:
        """Set a session state variable.

        Args:
            session_id: The session ID
            key: State variable key
            value: State variable value

        Returns:
            Dict with success, key, value
        """
        try:
            session_data = self._load_session(session_id)
            if not session_data:
                return {"success": False, "error": "Session not found", "session_id": session_id}

            session_data["state"][key] = value
            self._save_session(session_data)

            return {"success": True, "key": key, "value": value}
        except Exception as e:
            return {"success": False, "error": str(e), "session_id": session_id}

    def session_state_get(
        self,
        session_id: str,
        key: Optional[str] = None,
    ) -> dict:
        """Get session state (specific key or all).

        Args:
            session_id: The session ID
            key: Optional specific key to retrieve

        Returns:
            Dict with found, key, value (if key provided) or state dict
        """
        try:
            session_data = self._load_session(session_id)
            if not session_data:
                return {"found": False, "error": "Session not found", "session_id": session_id}

            if key:
                if key in session_data["state"]:
                    return {"found": True, "key": key, "value": session_data["state"][key]}
                return {"found": False, "key": key}
            else:
                return {"state": session_data["state"]}
        except Exception as e:
            return {"found": False, "error": str(e), "session_id": session_id}

    def session_summary(self, session_id: str) -> dict:
        """Get full session summary.

        Args:
            session_id: The session ID

        Returns:
            Dict with session_id, name, duration_seconds, project, tags,
            state, events_by_type, event_count, closed
        """
        try:
            session_data = self._load_session(session_id)
            if not session_data:
                return {"error": "Session not found", "session_id": session_id}

            start_time = datetime.fromisoformat(session_data["start_time"].replace("Z", "+00:00"))
            end_time = datetime.now(timezone.utc)

            if session_data.get("end_time"):
                end_time = datetime.fromisoformat(session_data["end_time"].replace("Z", "+00:00"))

            duration_seconds = int((end_time - start_time).total_seconds())

            # Count events by type
            events_by_type: dict[str, int] = {}
            for event in session_data["events"]:
                event_type = event.get("type", "unknown")
                events_by_type[event_type] = events_by_type.get(event_type, 0) + 1

            return {
                "session_id": session_data["session_id"],
                "name": session_data["name"],
                "duration_seconds": duration_seconds,
                "project": session_data["project"],
                "tags": session_data["tags"],
                "state": session_data["state"],
                "events_by_type": events_by_type,
                "event_count": len(session_data["events"]),
                "closed": session_data.get("closed", False),
            }
        except Exception as e:
            return {"error": str(e), "session_id": session_id}

    def session_list(
        self,
        limit: int = 10,
        project: Optional[str] = None,
    ) -> dict:
        """List recent sessions (closed or open).

        Args:
            limit: Maximum number of sessions to return
            project: Optional project filter

        Returns:
            Dict with sessions list and total count
        """
        try:
            sessions = []

            for fname in os.listdir(self.sessions_dir):
                if fname.endswith(".json"):
                    session_id = fname[:-5]
                    session_data = self._load_session(session_id)
                    if session_data:
                        if project and session_data.get("project") != project:
                            continue

                        start_time = datetime.fromisoformat(
                            session_data["start_time"].replace("Z", "+00:00")
                        )
                        end_time = None
                        if session_data.get("end_time"):
                            end_time = datetime.fromisoformat(
                                session_data["end_time"].replace("Z", "+00:00")
                            )
                        else:
                            end_time = datetime.now(timezone.utc)

                        duration_seconds = int((end_time - start_time).total_seconds())

                        sessions.append({
                            "session_id": session_data["session_id"],
                            "name": session_data["name"],
                            "start_time": session_data["start_time"],
                            "duration_seconds": duration_seconds,
                            "event_count": len(session_data["events"]),
                            "closed": session_data.get("closed", False),
                        })

            sessions.sort(key=lambda x: x["start_time"], reverse=True)
            sessions = sessions[:limit]

            return {"sessions": sessions, "total": len(sessions)}
        except Exception as e:
            return {"sessions": [], "total": 0, "error": str(e)}

    def session_close(self, session_id: str) -> dict:
        """End a session.

        Args:
            session_id: The session ID

        Returns:
            Dict with success, session_id, duration_seconds, event_count
        """
        try:
            session_data = self._load_session(session_id)
            if not session_data:
                return {"success": False, "error": "Session not found", "session_id": session_id}

            now = datetime.now(timezone.utc).isoformat()
            session_data["closed"] = True
            session_data["end_time"] = now
            self._save_session(session_data)

            start_time = datetime.fromisoformat(session_data["start_time"].replace("Z", "+00:00"))
            end_time = datetime.fromisoformat(now.replace("Z", "+00:00"))
            duration_seconds = int((end_time - start_time).total_seconds())

            return {
                "success": True,
                "session_id": session_id,
                "duration_seconds": duration_seconds,
                "event_count": len(session_data["events"]),
            }
        except Exception as e:
            return {"success": False, "error": str(e), "session_id": session_id}