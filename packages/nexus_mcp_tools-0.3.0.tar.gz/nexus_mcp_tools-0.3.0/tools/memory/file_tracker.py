"""File change tracker module - track file changes in a session.

Inspired by Claude Code's file awareness.
"""

import json
import os
from datetime import datetime, timezone
from typing import Optional


class FileChangeTracker:
    """Track file changes in a session.

    Stores file tracking data in ~/.nexus-tools/filetrack/ directory.
    """

    def __init__(self):
        self.filetrack_dir = os.path.expanduser("~/.nexus-tools/filetrack")
        os.makedirs(self.filetrack_dir, exist_ok=True)

    def _get_tracking_file(self, session_id: str) -> str:
        """Get the path to a tracking file."""
        return os.path.join(self.filetrack_dir, f"{session_id}.json")

    def _load_tracking(self, session_id: str) -> Optional[dict]:
        """Load tracking data for a session."""
        filepath = self._get_tracking_file(session_id)
        if os.path.exists(filepath):
            try:
                with open(filepath, "r", encoding="utf-8") as f:
                    return json.load(f)
            except (json.JSONDecodeError, IOError):
                return None
        return None

    def _save_tracking(self, session_id: str, data: dict) -> None:
        """Save tracking data for a session."""
        filepath = self._get_tracking_file(session_id)
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)

    def _get_file_info(self, directory: str) -> dict:
        """Get file info for all files in a directory recursively."""
        files = {}
        try:
            for root, _, filenames in os.walk(directory):
                for filename in filenames:
                    filepath = os.path.join(root, filename)
                    try:
                        stat = os.stat(filepath)
                        rel_path = os.path.relpath(filepath, directory)
                        files[rel_path] = {
                            "size": stat.st_size,
                            "mtime": stat.st_mtime,
                        }
                    except OSError:
                        pass
        except Exception:
            pass
        return files

    def track_start(
        self,
        session_id: str,
        directory: str,
    ) -> dict:
        """Start tracking a directory.

        Takes a snapshot of all file paths, sizes, and modification times.

        Args:
            session_id: The session ID
            directory: Directory path to track

        Returns:
            Dict with success, session_id, directory, files_count
        """
        try:
            if not os.path.isdir(directory):
                return {"success": False, "error": "Directory not found", "session_id": session_id}

            files = self._get_file_info(directory)

            tracking_data = {
                "session_id": session_id,
                "directory": directory,
                "baseline": files,
                "started_at": datetime.now(timezone.utc).isoformat(),
            }

            self._save_tracking(session_id, tracking_data)

            return {
                "success": True,
                "session_id": session_id,
                "directory": directory,
                "files_count": len(files),
            }
        except Exception as e:
            return {"success": False, "error": str(e), "session_id": session_id}

    def track_changes(self, session_id: str) -> dict:
        """Compare current state with baseline snapshot.

        Detects: new files, deleted files, modified files (by size or mtime).

        Args:
            session_id: The session ID

        Returns:
            Dict with created, modified, deleted, unchanged_count, total_changes
        """
        try:
            tracking_data = self._load_tracking(session_id)
            if not tracking_data:
                return {
                    "created": [],
                    "modified": [],
                    "deleted": [],
                    "unchanged_count": 0,
                    "total_changes": 0,
                    "error": "No tracking session found",
                }

            baseline = tracking_data.get("baseline", {})
            directory = tracking_data.get("directory", "")

            current_files = self._get_file_info(directory)

            created = []
            modified = []
            deleted = []
            unchanged_count = 0

            # Check for new and modified files
            for path, info in current_files.items():
                if path not in baseline:
                    created.append({
                        "path": path,
                        "size": info["size"],
                    })
                else:
                    baseline_info = baseline[path]
                    if info["size"] != baseline_info["size"] or info["mtime"] != baseline_info["mtime"]:
                        modified.append({
                            "path": path,
                            "old_size": baseline_info["size"],
                            "new_size": info["size"],
                        })
                    else:
                        unchanged_count += 1

            # Check for deleted files
            for path in baseline:
                if path not in current_files:
                    deleted.append({
                        "path": path,
                    })

            total_changes = len(created) + len(modified) + len(deleted)

            return {
                "created": created,
                "modified": modified,
                "deleted": deleted,
                "unchanged_count": unchanged_count,
                "total_changes": total_changes,
            }
        except Exception as e:
            return {
                "created": [],
                "modified": [],
                "deleted": [],
                "unchanged_count": 0,
                "total_changes": 0,
                "error": str(e),
            }

    def track_stop(self, session_id: str) -> dict:
        """Stop tracking, remove snapshot.

        Args:
            session_id: The session ID

        Returns:
            Dict with success, session_id
        """
        try:
            filepath = self._get_tracking_file(session_id)
            if os.path.exists(filepath):
                os.remove(filepath)
                return {"success": True, "session_id": session_id}
            return {"success": False, "error": "No tracking session found", "session_id": session_id}
        except Exception as e:
            return {"success": False, "error": str(e), "session_id": session_id}