"""Project memory module - persistent key-value store per project with categories."""

import json
import os
from datetime import datetime, timezone
from typing import Optional


class ProjectMemory:
    """Persistent key-value store per project with categories.

    Inspired by Claude Code's auto memory (~/.claude/projects/<project>/memory/).
    Stores data as JSON files under ~/.nexus-tools/memory/ directory.
    """

    def __init__(self):
        self.base_dir = os.path.expanduser("~/.nexus-tools/memory")

    def _ensure_dir(self, project: str) -> str:
        """Ensure the project directory exists."""
        project_dir = os.path.join(self.base_dir, project)
        os.makedirs(project_dir, exist_ok=True)
        return project_dir

    def _get_project_dir(self, project: str) -> str:
        """Get the project directory path."""
        return os.path.join(self.base_dir, project)

    def _get_memory_file(self, project: str, category: str) -> str:
        """Get the path to the memory JSON file for a category."""
        safe_category = category.replace("/", "_").replace("\\", "_")
        return os.path.join(self._get_project_dir(project), f"{safe_category}.json")

    def _load_category(self, project: str, category: str) -> dict:
        """Load memory entries from a category file."""
        filepath = self._get_memory_file(project, category)
        if os.path.exists(filepath):
            try:
                with open(filepath, "r", encoding="utf-8") as f:
                    return json.load(f)
            except (json.JSONDecodeError, IOError):
                return {}
        return {}

    def _save_category(self, project: str, category: str, data: dict) -> None:
        """Save memory entries to a category file."""
        filepath = self._get_memory_file(project, category)
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)

    def _get_all_categories(self, project: str) -> list[str]:
        """Get all category files in a project directory."""
        project_dir = self._get_project_dir(project)
        if not os.path.exists(project_dir):
            return []
        categories = []
        for fname in os.listdir(project_dir):
            if fname.endswith(".json"):
                categories.append(fname[:-5])  # Remove .json extension
        return categories

    def memory_set(
        self,
        key: str,
        value: str,
        category: str = "general",
        project: Optional[str] = None,
    ) -> dict:
        """Save a memory.

        Args:
            key: The memory key
            value: The memory value
            category: The category to store under (default: "general")
            project: The project name (default: auto-detect from CWD)

        Returns:
            Dict with success, key, category, project
        """
        try:
            if project is None:
                project = os.path.basename(os.getcwd()) or "default"

            self._ensure_dir(project)
            category_data = self._load_category(project, category)

            now = datetime.now(timezone.utc).isoformat()
            existing = category_data.get(key, {})

            category_data[key] = {
                "key": key,
                "value": value,
                "category": category,
                "project": project,
                "created_at": existing.get("created_at", now),
                "updated_at": now,
            }

            self._save_category(project, category, category_data)

            return {
                "success": True,
                "key": key,
                "category": category,
                "project": project,
            }
        except Exception as e:
            return {"success": False, "error": str(e), "key": key, "category": category, "project": project}

    def memory_get(
        self,
        key: str,
        category: Optional[str] = None,
        project: Optional[str] = None,
    ) -> dict:
        """Retrieve a memory by key.

        Args:
            key: The memory key to retrieve
            category: Optional category to search in (None = search all)
            project: The project name (default: auto-detect from CWD)

        Returns:
            Dict with found, key, value, category, project, created_at, updated_at
        """
        try:
            if project is None:
                project = os.path.basename(os.getcwd()) or "default"

            if category:
                category_data = self._load_category(project, category)
                if key in category_data:
                    entry = category_data[key]
                    return {
                        "found": True,
                        "key": entry["key"],
                        "value": entry["value"],
                        "category": entry["category"],
                        "project": entry["project"],
                        "created_at": entry["created_at"],
                        "updated_at": entry["updated_at"],
                    }
                return {"found": False, "key": key, "project": project}
            else:
                # Search all categories
                for cat in self._get_all_categories(project):
                    category_data = self._load_category(project, cat)
                    if key in category_data:
                        entry = category_data[key]
                        return {
                            "found": True,
                            "key": entry["key"],
                            "value": entry["value"],
                            "category": entry["category"],
                            "project": entry["project"],
                            "created_at": entry["created_at"],
                            "updated_at": entry["updated_at"],
                        }
                return {"found": False, "key": key, "project": project}
        except Exception as e:
            return {"found": False, "error": str(e), "key": key, "project": project}

    def memory_search(
        self,
        query: str,
        category: Optional[str] = None,
        project: Optional[str] = None,
    ) -> dict:
        """Search across keys and values (case-insensitive substring match).

        Args:
            query: Search query string
            category: Optional category to search in (None = search all)
            project: The project name (default: auto-detect from CWD)

        Returns:
            Dict with results list and total count
        """
        try:
            if project is None:
                project = os.path.basename(os.getcwd()) or "default"

            query_lower = query.lower()
            results = []
            categories = [category] if category else self._get_all_categories(project)

            for cat in categories:
                category_data = self._load_category(project, cat)
                for key, entry in category_data.items():
                    key_match = query_lower in key.lower()
                    value_match = query_lower in entry.get("value", "").lower()
                    if key_match or value_match:
                        score = 0
                        if key_match:
                            score += 1
                        if query_lower in entry.get("value", "").lower()[:100]:
                            score += 1
                        results.append({
                            "key": entry["key"],
                            "value": entry["value"],
                            "category": entry["category"],
                            "project": entry["project"],
                            "score": score,
                        })

            results.sort(key=lambda x: x["score"], reverse=True)
            return {"results": results, "total": len(results)}
        except Exception as e:
            return {"results": [], "total": 0, "error": str(e)}

    def memory_list(
        self,
        category: Optional[str] = None,
        project: Optional[str] = None,
    ) -> dict:
        """List memories in a category/project.

        Args:
            category: Optional category to list (None = all categories)
            project: The project name (default: auto-detect from CWD)

        Returns:
            Dict with items list and total count
        """
        try:
            if project is None:
                project = os.path.basename(os.getcwd()) or "default"

            items = []
            categories = [category] if category else self._get_all_categories(project)

            for cat in categories:
                category_data = self._load_category(project, cat)
                for key, entry in category_data.items():
                    value_preview = entry.get("value", "")[:100]
                    items.append({
                        "key": entry["key"],
                        "value_preview": value_preview,
                        "category": entry["category"],
                        "updated_at": entry["updated_at"],
                    })

            items.sort(key=lambda x: x["updated_at"], reverse=True)
            return {"items": items, "total": len(items)}
        except Exception as e:
            return {"items": [], "total": 0, "error": str(e)}

    def memory_forget(
        self,
        key: str,
        category: Optional[str] = None,
        project: Optional[str] = None,
    ) -> dict:
        """Delete a memory.

        Args:
            key: The memory key to delete
            category: Optional category to delete from (None = search all)
            project: The project name (default: auto-detect from CWD)

        Returns:
            Dict with success, key
        """
        try:
            if project is None:
                project = os.path.basename(os.getcwd()) or "default"

            if category:
                category_data = self._load_category(project, category)
                if key in category_data:
                    del category_data[key]
                    self._save_category(project, category, category_data)
                    return {"success": True, "key": key}
                return {"success": False, "key": key, "error": "Key not found"}
            else:
                for cat in self._get_all_categories(project):
                    category_data = self._load_category(project, cat)
                    if key in category_data:
                        del category_data[key]
                        self._save_category(project, cat, category_data)
                        return {"success": True, "key": key}
                return {"success": False, "key": key, "error": "Key not found"}
        except Exception as e:
            return {"success": False, "error": str(e), "key": key}

    def memory_categories(
        self,
        project: Optional[str] = None,
    ) -> dict:
        """List all categories.

        Args:
            project: The project name (default: auto-detect from CWD)

        Returns:
            Dict with categories list and total count
        """
        try:
            if project is None:
                project = os.path.basename(os.getcwd()) or "default"

            categories = []
            for cat in self._get_all_categories(project):
                category_data = self._load_category(project, cat)
                categories.append({
                    "name": cat,
                    "count": len(category_data),
                })

            categories.sort(key=lambda x: x["name"])
            return {"categories": categories, "total": len(categories)}
        except Exception as e:
            return {"categories": [], "total": 0, "error": str(e)}