"""Context log module - track tool calls and actions in a session.

Inspired by Claude Code's context window management.
"""

import json
import os
import uuid
from datetime import datetime, timezone
from typing import Optional


class ContextLog:
    """Track tool calls and actions in a session.

    Stores context logs in ~/.nexus-tools/context/ directory.
    """

    def __init__(self):
        self.context_dir = os.path.expanduser("~/.nexus-tools/context")
        os.makedirs(self.context_dir, exist_ok=True)

    def _get_context_file(self, session_id: str) -> str:
        """Get the path to a context log file."""
        return os.path.join(self.context_dir, f"{session_id}.json")

    def _load_context(self, session_id: str) -> list:
        """Load context log entries for a session."""
        filepath = self._get_context_file(session_id)
        if os.path.exists(filepath):
            try:
                with open(filepath, "r", encoding="utf-8") as f:
                    return json.load(f)
            except (json.JSONDecodeError, IOError):
                return []
        return []

    def _save_context(self, session_id: str, entries: list) -> None:
        """Save context log entries for a session."""
        filepath = self._get_context_file(session_id)
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(entries, f, indent=2, ensure_ascii=False)

    def _auto_log_to_session(self, session_id: str, tool: str, status: str) -> None:
        """Auto-log to session as event."""
        try:
            # Import here to avoid circular imports
            from tools.memory.session import SessionTracker
            tracker = SessionTracker()
            tracker.session_event(
                session_id,
                "context_logged",
                {"tool": tool, "status": status}
            )
        except Exception:
            pass  # Silently fail if session logging fails

    def context_log(
        self,
        session_id: str,
        tool: str,
        input_summary: str,
        output_summary: str,
        status: str = "success",
    ) -> dict:
        """Log a tool call to the context log.

        Args:
            session_id: The session ID
            tool: Tool name
            input_summary: Summary of input
            output_summary: Summary of output
            status: Status of the call (default: "success")

        Returns:
            Dict with success, entry_id
        """
        try:
            entries = self._load_context(session_id)

            now = datetime.now(timezone.utc).isoformat()
            entry_id = str(uuid.uuid4())

            entry = {
                "entry_id": entry_id,
                "timestamp": now,
                "tool": tool,
                "input_summary": input_summary,
                "output_summary": output_summary,
                "status": status,
                "session_id": session_id,
            }

            entries.append(entry)
            self._save_context(session_id, entries)

            # Auto-log as event to session
            self._auto_log_to_session(session_id, tool, status)

            return {"success": True, "entry_id": entry_id}
        except Exception as e:
            return {"success": False, "error": str(e), "entry_id": None}

    def context_recent(
        self,
        session_id: str,
        limit: int = 10,
    ) -> dict:
        """Get recent context entries.

        Args:
            session_id: The session ID
            limit: Maximum number of entries to return

        Returns:
            Dict with entries list and total count
        """
        try:
            entries = self._load_context(session_id)
            entries = entries[-limit:]  # Get last N entries

            result_entries = []
            for entry in entries:
                result_entries.append({
                    "timestamp": entry["timestamp"],
                    "tool": entry["tool"],
                    "input_summary": entry["input_summary"],
                    "output_summary": entry["output_summary"],
                    "status": entry["status"],
                })

            return {"entries": result_entries, "total": len(entries)}
        except Exception as e:
            return {"entries": [], "total": 0, "error": str(e)}

    def context_search(
        self,
        session_id: str,
        tool: Optional[str] = None,
        query: Optional[str] = None,
        status: Optional[str] = None,
    ) -> dict:
        """Search context log by tool name and/or text in summaries.

        Args:
            session_id: The session ID
            tool: Optional tool name filter
            query: Optional search query
            status: Optional status filter

        Returns:
            Dict with entries list and total count
        """
        try:
            entries = self._load_context(session_id)
            results = []

            for entry in entries:
                # Filter by tool
                if tool and entry.get("tool") != tool:
                    continue

                # Filter by status
                if status and entry.get("status") != status:
                    continue

                # Filter by query (search in input and output summaries)
                if query:
                    query_lower = query.lower()
                    input_match = query_lower in entry.get("input_summary", "").lower()
                    output_match = query_lower in entry.get("output_summary", "").lower()
                    if not (input_match or output_match):
                        continue

                results.append({
                    "timestamp": entry["timestamp"],
                    "tool": entry["tool"],
                    "input_summary": entry["input_summary"],
                    "output_summary": entry["output_summary"],
                    "status": entry["status"],
                })

            return {"entries": results, "total": len(results)}
        except Exception as e:
            return {"entries": [], "total": 0, "error": str(e)}

    def context_stats(self, session_id: str) -> dict:
        """Get context log stats.

        Args:
            session_id: The session ID

        Returns:
            Dict with total_entries, by_tool, by_status, time_span_seconds
        """
        try:
            entries = self._load_context(session_id)

            by_tool: dict[str, int] = {}
            by_status: dict[str, int] = {}

            for entry in entries:
                tool = entry.get("tool", "unknown")
                by_tool[tool] = by_tool.get(tool, 0) + 1

                status = entry.get("status", "unknown")
                by_status[status] = by_status.get(status, 0) + 1

            # Calculate time span
            time_span_seconds = 0
            if entries:
                first_time = datetime.fromisoformat(entries[0]["timestamp"].replace("Z", "+00:00"))
                last_time = datetime.fromisoformat(entries[-1]["timestamp"].replace("Z", "+00:00"))
                time_span_seconds = int((last_time - first_time).total_seconds())

            return {
                "total_entries": len(entries),
                "by_tool": by_tool,
                "by_status": by_status,
                "time_span_seconds": time_span_seconds,
            }
        except Exception as e:
            return {
                "total_entries": 0,
                "by_tool": {},
                "by_status": {},
                "time_span_seconds": 0,
                "error": str(e),
            }