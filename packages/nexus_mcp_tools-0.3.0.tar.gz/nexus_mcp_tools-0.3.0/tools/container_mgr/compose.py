"""Docker Compose Manager - Manage Docker Compose services."""

import subprocess
from typing import Any, Optional


class ComposeManager:
    """Manage Docker Compose services."""

    def up(
        self,
        compose_file: str,
        service: Optional[str] = None,
        detach: bool = True,
    ) -> dict[str, Any]:
        """Start Docker Compose services.

        Args:
            compose_file: Path to docker-compose.yml file
            service: Optional specific service to start
            detach: Run in detached mode

        Returns:
            Dict with success, output, error
        """
        try:
            cmd = ["docker", "compose", "-f", compose_file, "up"]
            if detach:
                cmd.append("-d")
            if service:
                cmd.append(service)

            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=120,
            )

            return {
                "success": result.returncode == 0,
                "output": result.stdout,
                "error": result.stderr if result.returncode != 0 else None,
            }
        except subprocess.TimeoutExpired:
            return {
                "success": False,
                "output": "",
                "error": "Command timed out after 120 seconds",
            }
        except FileNotFoundError:
            return {
                "success": False,
                "output": "",
                "error": "Docker is not installed or not in PATH",
            }
        except Exception as e:
            return {
                "success": False,
                "output": "",
                "error": str(e),
            }

    def down(
        self,
        compose_file: str,
        remove_volumes: bool = False,
    ) -> dict[str, Any]:
        """Stop and remove Docker Compose services.

        Args:
            compose_file: Path to docker-compose.yml file
            remove_volumes: Also remove volumes

        Returns:
            Dict with success, output, error
        """
        try:
            cmd = ["docker", "compose", "-f", compose_file, "down"]
            if remove_volumes:
                cmd.append("-v")

            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=60,
            )

            return {
                "success": result.returncode == 0,
                "output": result.stdout,
                "error": result.stderr if result.returncode != 0 else None,
            }
        except subprocess.TimeoutExpired:
            return {
                "success": False,
                "output": "",
                "error": "Command timed out after 60 seconds",
            }
        except FileNotFoundError:
            return {
                "success": False,
                "output": "",
                "error": "Docker is not installed or not in PATH",
            }
        except Exception as e:
            return {
                "success": False,
                "output": "",
                "error": str(e),
            }

    def ps(self, compose_file: str) -> dict[str, Any]:
        """List Docker Compose services with status.

        Args:
            compose_file: Path to docker-compose.yml file

        Returns:
            Dict with services, error
        """
        try:
            cmd = ["docker", "compose", "-f", compose_file, "ps", "--format", "json"]

            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=30,
            )

            if result.returncode != 0:
                return {
                    "services": [],
                    "error": result.stderr,
                }

            # Parse JSON output
            import json
            services = []
            for line in result.stdout.strip().split("\n"):
                if line.strip():
                    try:
                        services.append(json.loads(line))
                    except json.JSONDecodeError:
                        pass

            return {
                "services": services,
                "error": None,
            }
        except subprocess.TimeoutExpired:
            return {
                "services": [],
                "error": "Command timed out after 30 seconds",
            }
        except FileNotFoundError:
            return {
                "services": [],
                "error": "Docker is not installed or not in PATH",
            }
        except Exception as e:
            return {
                "services": [],
                "error": str(e),
            }

    def restart(
        self,
        compose_file: str,
        service: Optional[str] = None,
    ) -> dict[str, Any]:
        """Restart Docker Compose services.

        Args:
            compose_file: Path to docker-compose.yml file
            service: Optional specific service to restart

        Returns:
            Dict with success, output, error
        """
        try:
            cmd = ["docker", "compose", "-f", compose_file, "restart"]
            if service:
                cmd.append(service)

            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=60,
            )

            return {
                "success": result.returncode == 0,
                "output": result.stdout,
                "error": result.stderr if result.returncode != 0 else None,
            }
        except subprocess.TimeoutExpired:
            return {
                "success": False,
                "output": "",
                "error": "Command timed out after 60 seconds",
            }
        except FileNotFoundError:
            return {
                "success": False,
                "output": "",
                "error": "Docker is not installed or not in PATH",
            }
        except Exception as e:
            return {
                "success": False,
                "output": "",
                "error": str(e),
            }