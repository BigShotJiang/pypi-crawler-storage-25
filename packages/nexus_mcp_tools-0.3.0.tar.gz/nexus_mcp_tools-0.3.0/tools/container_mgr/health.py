"""Container Health Checker - Check container health and stats."""

import json
import subprocess
from typing import Any


class HealthChecker:
    """Check Docker container health and statistics."""

    def check_container(self, name_or_id: str) -> dict[str, Any]:
        """Get health status of a container using docker inspect.

        Args:
            name_or_id: Container name or ID

        Returns:
            Dict with health status, state, details
        """
        try:
            cmd = [
                "docker", "inspect",
                "--format", "{{json .State}}",
                name_or_id,
            ]

            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=10,
            )

            if result.returncode != 0:
                return {
                    "exists": False,
                    "error": result.stderr.strip() or f"Container not found: {name_or_id}",
                }

            state = json.loads(result.stdout.strip()) if result.stdout.strip() else {}

            # Determine health status
            health_status = state.get("Health", {}).get("Status", "none")
            if health_status == "none":
                # Check if container is running
                health_status = "running" if state.get("Running", False) else "stopped"

            return {
                "exists": True,
                "health": health_status,
                "running": state.get("Running", False),
                "paused": state.get("Paused", False),
                "restarting": state.get("Restarting", False),
                "exit_code": state.get("ExitCode", 0),
                "started_at": state.get("StartedAt", ""),
                "finished_at": state.get("FinishedAt", ""),
                "error": state.get("Error", ""),
            }
        except subprocess.TimeoutExpired:
            return {
                "exists": False,
                "error": "Command timed out after 10 seconds",
            }
        except FileNotFoundError:
            return {
                "exists": False,
                "error": "Docker is not installed or not in PATH",
            }
        except json.JSONDecodeError:
            return {
                "exists": False,
                "error": "Failed to parse Docker response",
            }
        except Exception as e:
            return {
                "exists": False,
                "error": str(e),
            }

    def stats(self, name_or_id: str) -> dict[str, Any]:
        """Get resource usage stats for a container.

        Args:
            name_or_id: Container name or ID

        Returns:
            Dict with CPU, memory, network, block I/O stats
        """
        try:
            cmd = [
                "docker", "stats",
                "--no-stream",
                "--format", "{{json .}}",
                name_or_id,
            ]

            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=10,
            )

            if result.returncode != 0:
                return {
                    "error": result.stderr.strip() or f"Container not found: {name_or_id}",
                }

            if not result.stdout.strip():
                return {
                    "error": f"Container not found: {name_or_id}",
                }

            stats = json.loads(result.stdout.strip())

            # Parse and format stats
            return {
                "container": stats.get("Container", ""),
                "cpu": stats.get("CPUPerc", ""),
                "memory": stats.get("MemPerc", ""),
                "memory_usage": stats.get("MemUsage", ""),
                "network": stats.get("NetIO", ""),
                "block_io": stats.get("BlockIO", ""),
                "pids": stats.get("PIDs", ""),
            }
        except subprocess.TimeoutExpired:
            return {
                "error": "Command timed out after 10 seconds",
            }
        except FileNotFoundError:
            return {
                "error": "Docker is not installed or not in PATH",
            }
        except json.JSONDecodeError:
            return {
                "error": "Failed to parse Docker stats response",
            }
        except Exception as e:
            return {
                "error": str(e),
            }

    def list_containers(self, all: bool = False) -> dict[str, Any]:
        """List Docker containers.

        Args:
            all: Include stopped containers

        Returns:
            Dict with containers list
        """
        try:
            cmd = ["docker", "ps", "--format", "{{json .}}"]
            if all:
                cmd.insert(2, "-a")

            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=10,
            )

            if result.returncode != 0:
                return {
                    "containers": [],
                    "error": result.stderr,
                }

            containers = []
            for line in result.stdout.strip().split("\n"):
                if line.strip():
                    try:
                        containers.append(json.loads(line))
                    except json.JSONDecodeError:
                        pass

            return {
                "containers": containers,
                "count": len(containers),
                "error": None,
            }
        except subprocess.TimeoutExpired:
            return {
                "containers": [],
                "error": "Command timed out after 10 seconds",
            }
        except FileNotFoundError:
            return {
                "containers": [],
                "error": "Docker is not installed or not in PATH",
            }
        except Exception as e:
            return {
                "containers": [],
                "error": str(e),
            }