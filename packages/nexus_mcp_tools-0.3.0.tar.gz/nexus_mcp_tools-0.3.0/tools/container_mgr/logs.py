"""Container Log Manager - Tail and search container logs."""

import subprocess
from typing import Any, Optional


class LogManager:
    """Manage Docker container logs."""

    def tail(
        self,
        service: str,
        lines: int = 100,
        follow: bool = False,
    ) -> dict[str, Any]:
        """Tail logs from a container.

        Args:
            service: Container name or ID
            lines: Number of lines to retrieve
            follow: Follow log output (not recommended for MCP)

        Returns:
            Dict with service, logs, count, error
        """
        try:
            cmd = ["docker", "logs", "--tail", str(lines)]
            if follow:
                cmd.append("-f")
            cmd.append(service)

            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=30,
            )

            if result.returncode != 0:
                return {
                    "service": service,
                    "logs": [],
                    "count": 0,
                    "error": result.stderr.strip() or f"Container not found: {service}",
                }

            # Split logs into lines
            log_lines = (result.stdout + result.stderr).splitlines()

            return {
                "service": service,
                "logs": log_lines[-lines:],  # Return at most 'lines' entries
                "count": len(log_lines),
                "error": None,
            }
        except subprocess.TimeoutExpired:
            return {
                "service": service,
                "logs": [],
                "count": 0,
                "error": "Command timed out after 30 seconds",
            }
        except FileNotFoundError:
            return {
                "service": service,
                "logs": [],
                "count": 0,
                "error": "Docker is not installed or not in PATH",
            }
        except Exception as e:
            return {
                "service": service,
                "logs": [],
                "count": 0,
                "error": str(e),
            }

    def search(
        self,
        service: str,
        pattern: str,
        since: Optional[str] = None,
    ) -> dict[str, Any]:
        """Search for pattern in container logs.

        Args:
            service: Container name or ID
            pattern: Search pattern (regex supported)
            since: Optional time filter (e.g., "10m", "1h")

        Returns:
            Dict with service, logs, count, error
        """
        try:
            # Get all logs
            cmd = ["docker", "logs", "--tail", "1000"]
            if since:
                cmd.extend(["--since", since])
            cmd.append(service)

            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=30,
            )

            if result.returncode != 0:
                return {
                    "service": service,
                    "logs": [],
                    "count": 0,
                    "error": result.stderr.strip() or f"Container not found: {service}",
                }

            # Combine stdout and stderr
            all_logs = (result.stdout + result.stderr).splitlines()

            # Simple string search (case-insensitive)
            matching_lines = [
                line for line in all_logs
                if pattern.lower() in line.lower()
            ]

            return {
                "service": service,
                "logs": matching_lines,
                "count": len(matching_lines),
                "error": None,
            }
        except subprocess.TimeoutExpired:
            return {
                "service": service,
                "logs": [],
                "count": 0,
                "error": "Command timed out after 30 seconds",
            }
        except FileNotFoundError:
            return {
                "service": service,
                "logs": [],
                "count": 0,
                "error": "Docker is not installed or not in PATH",
            }
        except Exception as e:
            return {
                "service": service,
                "logs": [],
                "count": 0,
                "error": str(e),
            }