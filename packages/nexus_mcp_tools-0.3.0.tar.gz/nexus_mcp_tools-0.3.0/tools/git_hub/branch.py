"""Git branch operations."""

import os
from typing import Optional

import git
import git.exc  # pyright: ignore[reportAttributeAccessIssue]

from shared.errors import GitAutomationError


class BranchManager:
    """Manager for Git branch operations."""

    def create(self, repo_path: str, name: str, base: Optional[str] = None) -> dict:
        """Create a new Git branch.

        Args:
            repo_path: Path to the Git repository
            name: Name of the new branch
            base: Base branch to create from (default: current HEAD)

        Returns:
            Dict with branch info
        """
        if not os.path.isdir(repo_path):
            raise GitAutomationError(f"Repository path does not exist: {repo_path}")

        try:
            repo = git.Repo(repo_path)
        except Exception as e:
            raise GitAutomationError(f"Failed to open repository: {e}")

        if name in [b.name for b in repo.branches]:
            raise GitAutomationError(f"Branch '{name}' already exists")

        try:
            if base:
                base_ref = repo.heads[base]
                new_branch = repo.create_head(name, base_ref)
            else:
                new_branch = repo.create_head(name)

            new_branch.checkout()

            return {
                "success": True,
                "name": name,
                "base": base or "HEAD",
            }
        except Exception as e:
            raise GitAutomationError(f"Failed to create branch: {e}")

    def list(self, repo_path: str) -> dict:
        """List all Git branches.

        Args:
            repo_path: Path to the Git repository

        Returns:
            Dict with branch list
        """
        if not os.path.isdir(repo_path):
            raise GitAutomationError(f"Repository path does not exist: {repo_path}")

        try:
            repo = git.Repo(repo_path)
        except Exception as e:
            raise GitAutomationError(f"Failed to open repository: {e}")

        branches = []
        for branch in repo.branches:
            branches.append({
                "name": branch.name,
                "current": branch.name == repo.active_branch.name,
                "commit": str(branch.commit),
            })

        return {
            "branches": branches,
            "count": len(branches),
        }

    def delete(self, repo_path: str, name: str, force: bool = False) -> dict:
        """Delete a Git branch.

        Args:
            repo_path: Path to the Git repository
            name: Name of the branch to delete
            force: Force deletion even if branch is not merged

        Returns:
            Dict with deletion result
        """
        if not os.path.isdir(repo_path):
            raise GitAutomationError(f"Repository path does not exist: {repo_path}")

        try:
            repo = git.Repo(repo_path)
        except Exception as e:
            raise GitAutomationError(f"Failed to open repository: {e}")

        branch = None
        for b in repo.branches:
            if b.name == name:
                branch = b
                break

        if branch is None:
            raise GitAutomationError(f"Branch '{name}' does not exist")

        if branch.name == repo.active_branch.name:
            raise GitAutomationError("Cannot delete the current branch")

        try:
            if force:
                repo.delete_head(name, force=True)
            else:
                repo.delete_head(name)

            return {
                "success": True,
                "name": name,
            }
        except Exception as e:
            raise GitAutomationError(f"Failed to delete branch: {e}")

    def current(self, repo_path: str) -> dict:
        """Get the current branch.

        Args:
            repo_path: Path to the Git repository

        Returns:
            Dict with current branch info
        """
        if not os.path.isdir(repo_path):
            raise GitAutomationError(f"Repository path does not exist: {repo_path}")

        try:
            repo = git.Repo(repo_path)
        except Exception as e:
            raise GitAutomationError(f"Failed to open repository: {e}")

        return {
            "name": repo.active_branch.name,
            "commit": str(repo.active_branch.commit),
        }