"""Git commit operations."""

import os
from typing import Optional

import git
import git.exc  # pyright: ignore[reportAttributeAccessIssue]

from shared.config import get_config
from shared.errors import GitAutomationError


class CommitManager:
    """Manager for Git commit operations."""

    def __init__(self):
        config = get_config()
        self.auto_message = config.git_auto_message

    def _get_auto_message(self, repo: git.Repo) -> str:
        """Generate commit message from staged changes.

        Args:
            repo: Git repository instance

        Returns:
            Auto-generated commit message
        """
        diff = repo.git.diff("--cached", "--stat")
        if not diff:
            return "No staged changes"

        lines = diff.split("\n")
        files = [line for line in lines if line.endswith(".py") or line.endswith(".js")]

        if files:
            return f"Update: {', '.join(files[:5])}"
        return "Update staged changes"

    def auto_commit(self, repo_path: str, message: Optional[str] = None, staged_only: bool = True) -> dict:
        """Create a Git commit.

        Args:
            repo_path: Path to the Git repository
            message: Commit message (auto-generated if not provided)
            staged_only: If True, only stage and commit staged changes

        Returns:
            Dict with commit info
        """
        if not os.path.isdir(repo_path):
            raise GitAutomationError(f"Repository path does not exist: {repo_path}")

        try:
            repo = git.Repo(repo_path)
        except Exception as e:
            raise GitAutomationError(f"Failed to open repository: {e}")

        staged_files = []
        if staged_only:
            staged = repo.index.diff("HEAD")
            if not staged:
                staged = repo.index.diff(None)
            if staged:
                staged_files = [item.a_path for item in staged]
            if not staged_files:
                head_diff = repo.index.diff("HEAD")
                staged_files = [item.a_path for item in head_diff]
            if not staged_files:
                raise GitAutomationError("No staged changes to commit")
        else:
            repo.git.add(all=True)
            head_diff = repo.index.diff("HEAD")
            staged_files = [item.a_path for item in head_diff]
            if not staged_files:
                staged_files = list(repo.untracked_files)
            if not staged_files:
                raise GitAutomationError("No changes to commit")

        if message is None and self.auto_message:
            message = self._get_auto_message(repo)

        if not message:
            message = "Update changes"

        try:
            commit = repo.index.commit(message)
            return {
                "success": True,
                "commit_hash": str(commit),
                "message": message,
                "files": staged_files,
            }
        except Exception as e:
            raise GitAutomationError(f"Failed to create commit: {e}")

    def status(self, repo_path: str) -> dict:
        """Get Git status for repository.

        Args:
            repo_path: Path to the Git repository

        Returns:
            Dict with status info
        """
        if not os.path.isdir(repo_path):
            raise GitAutomationError(f"Repository path does not exist: {repo_path}")

        try:
            repo = git.Repo(repo_path)
        except Exception as e:
            raise GitAutomationError(f"Failed to open repository: {e}")

        is_clean = not repo.is_dirty()
        branch = repo.active_branch.name
        staged = [item.a_path for item in repo.index.diff("HEAD")]
        modified = [item.a_path for item in repo.index.diff(None)]
        untracked = repo.untracked_files

        return {
            "clean": is_clean,
            "branch": branch,
            "staged": staged,
            "modified": modified,
            "untracked": untracked,
        }

    def log(self, repo_path: str, max_count: int = 10) -> dict:
        """Get Git commit log.

        Args:
            repo_path: Path to the Git repository
            max_count: Maximum number of commits to return

        Returns:
            Dict with commit log
        """
        if not os.path.isdir(repo_path):
            raise GitAutomationError(f"Repository path does not exist: {repo_path}")

        try:
            repo = git.Repo(repo_path)
        except Exception as e:
            raise GitAutomationError(f"Failed to open repository: {e}")

        commits = []
        for commit in repo.iter_commits(max_count=max_count):
            commits.append({
                "hash": str(commit),
                "short_hash": commit.hexsha[:7],
                "message": commit.message.strip(),
                "author": str(commit.author),
                "date": commit.committed_datetime.isoformat(),
            })

        return {
            "commits": commits,
            "count": len(commits),
        }