"""GitHub Pull Request operations."""

import os
import subprocess
from typing import Optional

from shared.config import get_config
from shared.errors import GitAutomationError
from tools.git_hub.branch import BranchManager


class PRCreator:
    """Creator for GitHub Pull Requests."""

    def __init__(self):
        config = get_config()
        self.default_branch = config.git_default_branch
        self.branch_manager = BranchManager()

    def _run_gh_command(self, args: list) -> dict:
        """Run a GitHub CLI command.

        Args:
            args: List of command arguments

        Returns:
            Dict with command result
        """
        try:
            result = subprocess.run(
                ["gh"] + args,
                capture_output=True,
                text=True,
                timeout=30,
            )

            if result.returncode != 0:
                return {
                    "success": False,
                    "error": result.stderr.strip(),
                }

            return {
                "success": True,
                "output": result.stdout.strip(),
            }
        except FileNotFoundError:
            raise GitAutomationError("GitHub CLI (gh) not found. Please install gh CLI.")
        except Exception as e:
            raise GitAutomationError(f"Failed to run gh command: {e}")

    def create(
        self,
        repo_path: str,
        title: str,
        body: Optional[str] = None,
        base: Optional[str] = None,
        head: Optional[str] = None,
    ) -> dict:
        """Create a GitHub Pull Request.

        Args:
            repo_path: Path to the Git repository
            title: PR title
            body: PR body/description
            base: Base branch (default: default branch from config)
            head: Head branch (default: current branch)

        Returns:
            Dict with PR info
        """
        if not os.path.isdir(repo_path):
            raise GitAutomationError(f"Repository path does not exist: {repo_path}")

        base = base or self.default_branch
        current_branch = head

        if not current_branch:
            try:
                import git

                repo = git.Repo(repo_path)
                current_branch = repo.active_branch.name
            except Exception:
                raise GitAutomationError("Could not determine current branch")

        if base == current_branch:
            raise GitAutomationError("Cannot create PR: base and head branches are the same")

        body_arg = ["--body", body] if body else []
        result = self._run_gh_command([
            "pr", "create",
            "--title", title,
            "--base", base,
            "--head", current_branch,
        ] + body_arg)

        if not result["success"]:
            return {
                "success": False,
                "error": result.get("error", "Failed to create PR"),
            }

        pr_url = result.get("output", "")
        return {
            "success": True,
            "title": title,
            "base": base,
            "head": current_branch,
            "url": pr_url,
        }

    def create_from_branch(
        self,
        repo_path: str,
        branch_name: str,
        title: Optional[str] = None,
        body: Optional[str] = None,
        base: Optional[str] = None,
    ) -> dict:
        """Create a branch and then a PR from it.

        Args:
            repo_path: Path to the Git repository
            branch_name: Name of the branch to create
            title: PR title (default: branch name)
            body: PR body/description
            base: Base branch to create from

        Returns:
            Dict with branch and PR info
        """
        base = base or self.default_branch

        branch_result = self.branch_manager.create(repo_path, branch_name, base)
        if not branch_result.get("success"):
            return {
                "success": False,
                "error": f"Failed to create branch: {branch_result}",
            }

        title = title or f"PR from {branch_name}"

        pr_result = self.create(
            repo_path=repo_path,
            title=title,
            body=body,
            base=base,
            head=branch_name,
        )

        if not pr_result.get("success"):
            return {
                "success": False,
                "error": f"Failed to create PR: {pr_result}",
            }

        return {
            "success": True,
            "branch": branch_name,
            "base": base,
            "pr_url": pr_result.get("url", ""),
            "title": title,
        }