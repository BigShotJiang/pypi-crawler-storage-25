"""Collection runner for sequential API request execution."""

import re
from typing import Any, Dict, List, Optional

from shared.errors import ApiTestError
from tools.api_tester.client import ApiClient


class CollectionRunner:
    """Runner for executing API request collections."""

    def __init__(self, timeout: Optional[int] = None):
        self.client = ApiClient(timeout=timeout)

    def _interpolate_variables(self, text: str, variables: Dict[str, Any]) -> str:
        """Interpolate variables in text using {{variable}} syntax.

        Args:
            text: Text with variable placeholders
            variables: Dict of variable values

        Returns:
            Text with interpolated variables
        """
        if not variables:
            return text

        pattern = re.compile(r"\{\{(\w+)\}\}")

        def replace(match):
            var_name = match.group(1)
            if var_name in variables:
                return str(variables[var_name])
            return match.group(0)

        return pattern.sub(replace, text)

    def _interpolate_request(self, request: dict, variables: Dict[str, Any]) -> dict:
        """Interpolate variables in a request dict.

        Args:
            request: Request dict with method, url, headers, body
            variables: Dict of variable values

        Returns:
            Request dict with interpolated values
        """
        interpolated = {}

        if "url" in request:
            interpolated["url"] = self._interpolate_variables(request["url"], variables)
        if "method" in request:
            interpolated["method"] = request["method"].upper()
        if "headers" in request:
            headers = request["headers"]
            interpolated["headers"] = {
                self._interpolate_variables(k, variables): self._interpolate_variables(v, variables)
                for k, v in headers.items()
            }
        if "body" in request:
            body = request["body"]
            if isinstance(body, dict):
                interpolated["body"] = {
                    self._interpolate_variables(k, variables): self._interpolate_variables(str(v), variables)
                    for k, v in body.items()
                }
            else:
                interpolated["body"] = self._interpolate_variables(str(body), variables)

        return interpolated

    def run(self, collection: dict) -> dict:
        """Run a collection of requests sequentially.

        Args:
            collection: Dict with requests list and optional variables

        Returns:
            Dict with results list and summary
        """
        requests = collection.get("requests", [])
        variables = collection.get("variables", {})

        if not requests:
            raise ApiTestError("Collection has no requests")

        results: List[dict] = []

        for idx, request in enumerate(requests):
            try:
                interpolated = self._interpolate_request(request, variables)

                method = interpolated.get("method", "GET")
                url = interpolated.get("url", "")
                headers = interpolated.get("headers", {})
                body = interpolated.get("body")

                if not url:
                    raise ApiTestError(f"Request {idx} has no URL")

                result = self.client.request(
                    method=method,
                    url=url,
                    headers=headers,
                    body=body,
                )

                results.append({
                    "index": idx,
                    "name": request.get("name", f"Request {idx}"),
                    "success": True,
                    "result": result,
                })

            except Exception as e:
                results.append({
                    "index": idx,
                    "name": request.get("name", f"Request {idx}"),
                    "success": False,
                    "error": str(e),
                })

            if "set_variables" in request:
                response_result = results[-1].get("result", {})
                response_body = response_result.get("body", {})
                if isinstance(response_body, dict):
                    for var_name, var_path in request["set_variables"].items():
                        parts = var_path.split(".")
                        value = response_body
                        for part in parts:
                            if isinstance(value, dict) and part in value:
                                value = value[part]
                            else:
                                value = None
                                break
                        variables[var_name] = value

        total_requests = len(results)
        successful = sum(1 for r in results if r.get("success"))

        return {
            "total_requests": total_requests,
            "successful": successful,
            "failed": total_requests - successful,
            "results": results,
        }

    def close(self):
        """Close the API client."""
        self.client.close()