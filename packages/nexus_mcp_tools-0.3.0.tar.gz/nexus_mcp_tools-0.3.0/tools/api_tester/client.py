"""HTTP client for API testing."""

import time
from typing import Any, Optional

import httpx

from shared.config import get_config
from shared.errors import ApiTestError


class ApiClient:
    """HTTP client with methods for making API requests."""

    def __init__(self, timeout: Optional[int] = None):
        config = get_config()
        self.timeout = timeout or config.api_timeout
        self.client = httpx.Client(timeout=self.timeout)

    def request(
        self,
        method: str,
        url: str,
        headers: Optional[dict] = None,
        body: Optional[Any] = None,
        timeout: Optional[int] = None,
    ) -> dict:
        """Make an HTTP request and return result dict.

        Args:
            method: HTTP method (GET, POST, PUT, DELETE, etc.)
            url: Target URL
            headers: Optional HTTP headers
            body: Optional request body
            timeout: Optional timeout override

        Returns:
            Dict with status_code, headers, body, duration_ms
        """
        request_timeout = timeout or self.timeout
        client = httpx.Client(timeout=request_timeout)

        try:
            start_time = time.perf_counter()
            response = client.request(
                method=method.upper(),
                url=url,
                headers=headers,
                json=body if body and isinstance(body, (dict, list)) else None,
                content=body if body and not isinstance(body, (dict, list)) else None,
            )
            duration_ms = int((time.perf_counter() - start_time) * 1000)

            try:
                response_body = response.json()
            except Exception:
                response_body = response.text

            return {
                "status_code": response.status_code,
                "headers": dict(response.headers),
                "body": response_body,
                "duration_ms": duration_ms,
            }
        except httpx.TimeoutException as e:
            raise ApiTestError(f"Request timeout: {e}")
        except httpx.RequestError as e:
            raise ApiTestError(f"Request failed: {e}")
        finally:
            client.close()

    def get(self, url: str, headers: Optional[dict] = None, timeout: Optional[int] = None) -> dict:
        """Make a GET request."""
        return self.request("GET", url, headers=headers, timeout=timeout)

    def post(
        self,
        url: str,
        headers: Optional[dict] = None,
        body: Optional[Any] = None,
        timeout: Optional[int] = None,
    ) -> dict:
        """Make a POST request."""
        return self.request("POST", url, headers=headers, body=body, timeout=timeout)

    def put(
        self,
        url: str,
        headers: Optional[dict] = None,
        body: Optional[Any] = None,
        timeout: Optional[int] = None,
    ) -> dict:
        """Make a PUT request."""
        return self.request("PUT", url, headers=headers, body=body, timeout=timeout)

    def delete(self, url: str, headers: Optional[dict] = None, timeout: Optional[int] = None) -> dict:
        """Make a DELETE request."""
        return self.request("DELETE", url, headers=headers, timeout=timeout)

    def close(self):
        """Close the HTTP client."""
        self.client.close()