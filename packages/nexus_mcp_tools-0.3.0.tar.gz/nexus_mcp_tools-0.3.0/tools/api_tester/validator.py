"""Response validation for API testing."""

from typing import List, Optional


class ResponseValidator:
    """Validator for API responses."""

    def validate(self, response: dict, schema: Optional[dict] = None) -> dict:
        """Validate response against a schema.

        Args:
            response: The API response dict with status_code, headers, body
            schema: Optional schema dict with expected fields and types

        Returns:
            Dict with valid, errors, missing_fields, extra_fields
        """
        errors: List[str] = []
        missing_fields: List[str] = []
        extra_fields: List[str] = []

        if not response:
            errors.append("Response is empty")
            return {
                "valid": False,
                "errors": errors,
                "missing_fields": missing_fields,
                "extra_fields": extra_fields,
            }

        if schema is None:
            return {
                "valid": True,
                "errors": [],
                "missing_fields": [],
                "extra_fields": [],
            }

        expected_fields = schema.get("properties", {})
        response_body = response.get("body", {})

        if not isinstance(response_body, dict):
            return {
                "valid": True,
                "errors": [],
                "missing_fields": [],
                "extra_fields": [],
            }

        for field, field_schema in expected_fields.items():
            if field not in response_body:
                if field_schema.get("required", False):
                    missing_fields.append(field)

        for field in response_body:
            if field not in expected_fields:
                extra_fields.append(field)

        if missing_fields or extra_fields:
            if missing_fields:
                errors.append(f"Missing required fields: {missing_fields}")
            if extra_fields:
                errors.append(f"Unexpected fields: {extra_fields}")

        return {
            "valid": len(errors) == 0,
            "errors": errors,
            "missing_fields": missing_fields,
            "extra_fields": extra_fields,
        }

    def validate_status(self, response: dict, expected_range: Optional[str] = None) -> dict:
        """Validate response status code.

        Args:
            response: The API response dict
            expected_range: Expected status code or range (e.g., "200", "2xx", "200-299")

        Returns:
            Dict with valid, status_code, expected
        """
        status_code = response.get("status_code", 0)

        if expected_range is None:
            return {
                "valid": True,
                "status_code": status_code,
                "expected": "any",
            }

        expected_lower = expected_range.lower()

        if expected_lower.startswith("2xx") or expected_lower == "2xx":
            expected_min, expected_max = 200, 299
        elif expected_lower.startswith("3xx") or expected_lower == "3xx":
            expected_min, expected_max = 300, 399
        elif expected_lower.startswith("4xx") or expected_lower == "4xx":
            expected_min, expected_max = 400, 499
        elif expected_lower.startswith("5xx") or expected_lower == "5xx":
            expected_min, expected_max = 500, 599
        elif "-" in expected_range:
            parts = expected_range.split("-")
            expected_min = int(parts[0])
            expected_max = int(parts[1])
        else:
            expected_min = expected_max = int(expected_range)

        valid = expected_min <= status_code <= expected_max

        return {
            "valid": valid,
            "status_code": status_code,
            "expected": expected_range,
        }