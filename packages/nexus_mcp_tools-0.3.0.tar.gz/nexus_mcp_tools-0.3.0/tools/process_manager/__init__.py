"""Process Manager - Process inspection and management tools."""

from tools.process_manager.process import ProcessManager

__all__ = ["ProcessManager"]
