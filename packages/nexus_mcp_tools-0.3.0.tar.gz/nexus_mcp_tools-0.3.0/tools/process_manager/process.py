"""Process inspection and management using psutil."""

import os
import signal
import time
from datetime import datetime
from typing import Any


class ProcessManager:
    """Process inspection and management utilities."""

    def list_processes(self, name_filter: str | None = None, user_filter: str | None = None,
                       sort_by: str = "cpu", limit: int = 50) -> list[dict[str, Any]]:
        """List running processes with optional filters.

        Args:
            name_filter: Optional process name substring filter
            user_filter: Optional username filter
            sort_by: Sort field (cpu, memory, pid, name, user)
            limit: Max results to return

        Returns:
            List of process dicts
        """
        import psutil
        results: list[dict[str, Any]] = []
        for proc in psutil.process_iter(["pid", "name", "username", "cpu_percent",
                                          "memory_percent", "status", "create_time",
                                          "num_threads"]):
            try:
                pinfo = proc.info
                # Apply filters
                if name_filter and name_filter.lower() not in (pinfo["name"] or "").lower():
                    continue
                if user_filter and user_filter.lower() not in (pinfo["username"] or "").lower():
                    continue

                results.append({
                    "pid": pinfo["pid"],
                    "name": pinfo["name"],
                    "user": pinfo["username"],
                    "cpu_percent": pinfo["cpu_percent"] or 0.0,
                    "memory_percent": round(pinfo["memory_percent"] or 0.0, 2),
                    "status": pinfo["status"],
                    "created": datetime.fromtimestamp(pinfo["create_time"]).isoformat() if pinfo["create_time"] else "",
                    "threads": pinfo["num_threads"] or 0,
                })
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue

        # Sort
        sort_key = {
            "cpu": "cpu_percent",
            "memory": "memory_percent",
            "pid": "pid",
            "name": "name",
            "user": "user",
        }.get(sort_by, "cpu_percent")

        reverse = sort_by in ("cpu", "memory", "pid")
        results.sort(key=lambda x: (x.get(sort_key) or 0), reverse=reverse)

        return results[:limit]

    def find_process_by_port(self, port: int) -> list[dict[str, Any]]:
        """Find processes listening on a specific port.

        Args:
            port: TCP port number

        Returns:
            List of process dicts with connection info
        """
        import psutil
        results: list[dict[str, Any]] = []
        for conn in psutil.net_connections(kind="tcp"):
            try:
                if conn.laddr and conn.laddr.port == port and conn.pid:
                    try:
                        proc = psutil.Process(conn.pid)
                        results.append({
                            "pid": conn.pid,
                            "name": proc.name(),
                            "status": conn.status,
                            "local_addr": f"{conn.laddr.ip}:{conn.laddr.port}",
                            "remote_addr": f"{conn.raddr.ip}:{conn.raddr.port}" if conn.raddr else "",
                            "fd": conn.fd,
                        })
                    except (psutil.NoSuchProcess, psutil.AccessDenied):
                        results.append({
                            "pid": conn.pid,
                            "name": "unknown",
                            "status": conn.status,
                            "local_addr": f"{conn.laddr.ip}:{conn.laddr.port}",
                            "remote_addr": "",
                            "fd": conn.fd,
                        })
            except Exception:
                continue
        return results

    def process_info(self, pid: int) -> dict[str, Any]:
        """Get detailed information about a specific process.

        Args:
            pid: Process ID

        Returns:
            Dict with process details
        """
        import psutil
        try:
            proc = psutil.Process(pid)
            with proc.oneshot():
                create_time = datetime.fromtimestamp(proc.create_time()).isoformat()
                # Calculate uptime
                uptime_seconds = int(time.time() - proc.create_time())
                cpu_percent = proc.cpu_percent(interval=0.1)
                memory_info = proc.memory_info()
                mem_rss = memory_info.rss
                mem_vms = memory_info.vms
                io_counters = proc.io_counters()

                result: dict[str, Any] = {
                    "found": True,
                    "pid": pid,
                    "name": proc.name(),
                    "exe": proc.exe(),
                    "cwd": proc.cwd(),
                    "status": proc.status(),
                    "user": proc.username(),
                    "created": create_time,
                    "uptime_seconds": uptime_seconds,
                    "cpu_percent": cpu_percent,
                    "memory_rss": mem_rss,
                    "memory_rss_mb": round(mem_rss / (1024 * 1024), 2),
                    "memory_vms": mem_vms,
                    "memory_vms_mb": round(mem_vms / (1024 * 1024), 2),
                    "memory_percent": round(proc.memory_percent(), 2),
                    "num_threads": proc.num_threads(),
                    "num_fds": None,  # not available on all platforms
                    "children": [c.info["pid"] for c in proc.children()],
                    "connections": len(proc.connections()),
                    "io_read_bytes": io_counters.read_bytes if io_counters else 0,
                    "io_write_bytes": io_counters.write_bytes if io_counters else 0,
                }

                # Try to get command line
                try:
                    result["cmdline"] = " ".join(proc.cmdline())
                except (psutil.AccessDenied, Exception):
                    result["cmdline"] = ""

                return result
        except psutil.NoSuchProcess:
            return {"found": False, "pid": pid, "error": "No such process"}
        except psutil.AccessDenied:
            return {"found": False, "pid": pid, "error": "Access denied"}
        except Exception as e:
            return {"found": False, "pid": pid, "error": str(e)}

    def kill_process(self, pid: int, force: bool = False) -> dict[str, Any]:
        """Terminate or kill a process.

        Args:
            pid: Process ID to terminate
            force: If True, use SIGKILL; otherwise SIGTERM

        Returns:
            Dict with result
        """
        import psutil
        try:
            proc = psutil.Process(pid)
            proc_name = proc.name()
            sig = getattr(signal, "SIGKILL", signal.SIGTERM) if force else signal.SIGTERM
            proc.send_signal(sig)
            return {"success": True, "pid": pid, "name": proc_name,
                    "signal": "SIGKILL" if force else "SIGTERM"}
        except psutil.NoSuchProcess:
            return {"success": False, "error": f"Process {pid} not found"}
        except psutil.AccessDenied:
            return {"success": False, "error": f"Access denied to kill process {pid}"}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def process_tree(self, root_pid: int | None = None) -> dict[str, Any]:
        """Build a process tree. Optionally root at a specific PID.

        Args:
            root_pid: Optional root PID (default: all processes)

        Returns:
            Dict with process tree
        """
        import psutil

        def _build_subtree(pid: int, depth: int = 0, max_depth: int = 10) -> dict[str, Any] | None:
            if depth > max_depth:
                return None
            try:
                proc = psutil.Process(pid)
                node: dict[str, Any] = {
                    "pid": pid,
                    "name": proc.name(),
                    "status": proc.status(),
                    "cpu_percent": proc.cpu_percent(interval=0),
                    "memory_percent": round(proc.memory_percent(), 2),
                }
                children_info: list[dict[str, Any]] = []
                for child in proc.children():
                    child_node = _build_subtree(child.pid, depth + 1, max_depth)
                    if child_node:
                        children_info.append(child_node)
                node["children"] = children_info
                return node
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                return None

        if root_pid is not None:
            root = _build_subtree(root_pid)
            if root:
                return {"success": True, "root_pid": root_pid, "tree": root}
            return {"success": False, "error": f"Process {root_pid} not found"}

        # Build full tree from init/systemd (PID 1 on Unix) or just list PIDs
        # On Windows, build from all top-level PIDs
        top_pids: list[int] = []

        # Find processes with no parent or parent outside our list
        all_pids = psutil.pids()
        all_procs = {}
        for pid in all_pids:
            try:
                proc = psutil.Process(pid)
                all_procs[pid] = proc
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue

        # Identify top-level processes (PPID not in our list)
        for pid, proc in all_procs.items():
            try:
                ppid = proc.ppid()
                if ppid not in all_procs or ppid == pid:
                    top_pids.append(pid)
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                top_pids.append(pid)

        trees: list[dict[str, Any]] = []
        for pid in top_pids[:50]:  # Limit to 50 roots
            node = _build_subtree(pid)
            if node:
                trees.append(node)

        return {"success": True, "total_processes": len(all_procs), "roots": trees}

    def system_stats(self) -> dict[str, Any]:
        """Get overall system resource statistics.

        Returns:
            Dict with CPU, memory, disk, network stats
        """
        import psutil
        import shutil

        # CPU
        cpu_percent = psutil.cpu_percent(interval=0.5)
        cpu_count = psutil.cpu_count()
        cpu_freq = psutil.cpu_freq()
        load_avg = None
        try:
            load_avg = list(os.getloadavg())  # type: ignore[attr-defined]
        except (AttributeError, OSError):
            pass

        # Memory
        mem = psutil.virtual_memory()
        swap = psutil.swap_memory()

        # Disk
        disk_usage = shutil.disk_usage("/")
        disk_io = psutil.disk_io_counters()

        # Network
        net_io = psutil.net_io_counters()

        # Boot time
        boot_time = datetime.fromtimestamp(psutil.boot_time()).isoformat()
        uptime_days = round((time.time() - psutil.boot_time()) / 86400, 1)

        result: dict[str, Any] = {
            "cpu": {
                "percent": cpu_percent,
                "count": cpu_count,
                "frequency_mhz": round(cpu_freq.current, 2) if cpu_freq else None,
                "load_avg": list(load_avg) if load_avg else None,
            },
            "memory": {
                "total": mem.total,
                "total_gb": round(mem.total / (1024**3), 2),
                "available": mem.available,
                "available_gb": round(mem.available / (1024**3), 2),
                "percent": mem.percent,
                "used_gb": round(mem.used / (1024**3), 2),
            },
            "swap": {
                "total_gb": round(swap.total / (1024**3), 2) if swap.total else 0,
                "used_gb": round(swap.used / (1024**3), 2) if swap.total else 0,
                "percent": swap.percent if swap.total else 0,
            },
            "disk": {
                "total_gb": round(disk_usage.total / (1024**3), 2),
                "used_gb": round(disk_usage.used / (1024**3), 2),
                "free_gb": round(disk_usage.free / (1024**3), 2),
                "percent": round(disk_usage.used / disk_usage.total * 100, 1),
            },
            "network": {
                "bytes_sent": net_io.bytes_sent,
                "bytes_recv": net_io.bytes_recv,
                "packets_sent": net_io.packets_sent,
                "packets_recv": net_io.packets_recv,
            },
            "boot_time": boot_time,
            "uptime_days": uptime_days,
            "total_processes": len(psutil.pids()),
        }

        # Disk I/O
        if disk_io:
            result["disk_io"] = {
                "read_bytes": disk_io.read_bytes,
                "write_bytes": disk_io.write_bytes,
                "read_count": disk_io.read_count,
                "write_count": disk_io.write_count,
            }

        return result

    def listening_ports(self) -> list[dict[str, Any]]:
        """List all listening TCP and UDP ports with owning processes.

        Returns:
            List of port/process dicts
        """
        import psutil
        results: list[dict[str, Any]] = []
        seen: set[tuple[str, int, str]] = set()

        for conn in psutil.net_connections(kind="inet"):
            try:
                if conn.laddr and conn.status == "LISTEN":
                    key = (conn.laddr.ip, conn.laddr.port, str(conn.type))
                    if key in seen:
                        continue
                    seen.add(key)

                    entry: dict[str, Any] = {
                        "protocol": "tcp" if conn.type == 1 else "udp",
                        "ip": conn.laddr.ip,
                        "port": conn.laddr.port,
                        "pid": conn.pid,
                    }

                    # Get process name
                    if conn.pid:
                        try:
                            proc = psutil.Process(conn.pid)
                            entry["process_name"] = proc.name()
                        except (psutil.NoSuchProcess, psutil.AccessDenied):
                            entry["process_name"] = "unknown"

                    results.append(entry)
            except Exception:
                continue

        # Sort by port number
        results.sort(key=lambda x: x["port"])
        return results
