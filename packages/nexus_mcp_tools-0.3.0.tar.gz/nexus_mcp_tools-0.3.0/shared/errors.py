"""Custom exceptions for Nexus Tools MCP server."""


class NexusToolsError(Exception):
    """Base exception for all Nexus Tools errors."""

    def __init__(self, message: str):
        self.message = message
        super().__init__(self.message)


class ApiTestError(NexusToolsError):
    """Raised when API testing fails."""

    pass


class GitAutomationError(NexusToolsError):
    """Raised when Git operations fail."""

    pass


class DatabaseError(NexusToolsError):
    """Raised when database operations fail."""

    pass


class ConfigError(NexusToolsError):
    """Raised when configuration is invalid."""

    pass