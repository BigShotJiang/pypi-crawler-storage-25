"""Configuration management for Nexus Tools."""

import os
from pathlib import Path

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

from shared.errors import ConfigError


class Config(BaseSettings):
    """Configuration loaded from environment variables with NEXUS_TOOLS_ prefix."""

    model_config = SettingsConfigDict(env_prefix="NEXUS_TOOLS_", case_sensitive=False)

    api_timeout: int = Field(default=30, description="Default API request timeout in seconds")
    api_max_retries: int = Field(default=3, description="Maximum number of API request retries")
    git_default_branch: str = Field(default="main", description="Default Git branch name")
    git_auto_message: bool = Field(default=True, description="Auto-generate commit messages from diff")
    db_default_pool_size: int = Field(default=5, description="Default database connection pool size")
    db_echo: bool = Field(default=False, description="Echo SQL statements")


def get_config() -> Config:
    """Get the configuration instance."""
    try:
        return Config()
    except Exception as e:
        raise ConfigError(f"Failed to load configuration: {e}")


_DATA_DIR: Path | None = None


def get_data_dir() -> Path:
    """Get the nexus-tools data directory (~/.nexus-tools)."""
    global _DATA_DIR
    if _DATA_DIR is None:
        _DATA_DIR = Path(os.path.expanduser("~/.nexus-tools"))
    return _DATA_DIR