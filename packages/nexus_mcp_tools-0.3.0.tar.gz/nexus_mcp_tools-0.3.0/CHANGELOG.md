# Changelog

## 0.3.0 — 2026-05-23

### Added
- Phase 9e: Desktop/Background Tools (11 tools)
  - File Watcher: fs_watch_start, fs_watch_poll, fs_watch_stop, fs_watch_list
    (Polling-based directory monitoring — no watchdog dep needed)
  - Clipboard: clipboard_get, clipboard_set, clipboard_history
    (Windows PowerShell Get-Clipboard/Set-Clipboard, self-snapshotting history)
  - Scheduler: task_schedule, task_delayed, task_cancel, task_check
    (Recurring + one-shot tasks via JSON state, no background threads)
  - 10 new smoke tests (147 total, all passing)
- Phase 9a: Agentic Dev Tools (22 tools)
  - Docker Advanced: compose_ps, compose_logs, image_inspect, container_exec, prune, network_inspect, volume_ls
  - Package Manager: pip_list, pip_show, npm_list, npm_outdated, uv_deps
  - GraphQL: query, introspect, schema_dump, validate
  - Cloud CLI: aws_s3_ls, aws_lambda_list, aws_ec2_ls, gcp_storage_ls, gcp_compute_ls, gcp_run_ls
- Phase 9b: AI/RAG Infra (9 tools)
  - Text chunking (character + sentence modes with overlap)
  - Ollama embedding via local API
  - Vector store CRUD (create, add, search, list, delete)
  - End-to-end RAG retrieval pipeline (chunk + embed + cosine search)
- Phase 9c: Hardening
  - 20 new smoke tests covering all Phase 9a + 9b tools
  - Dedicated `tests/test_rag_unit.py` for pure-function tests (chunking, cosine similarity)
  - All 137 tests passing (0 failures)
- Phase 8d: Dogfood MCP protocol test
  - End-to-end initialize + tools/list verification over real stdio

### Changed
- Tool count: 143 MCP tools across 31 domains (up from 132)
- pyproject.toml: version 0.3.0, renamed to nexus-mcp-tools (nexus-tools conflicted with nexus-toolkit on PyPI), added openpyxl + requests + jinja2 deps, console script entry points (nexus-mcp-tools, nexus-mcp-tools-cli)
- Storage now includes `~/.nexus-tools/desktop/{watches,tasks}/` for Phase 9e state
- shared/config.py: added get_data_dir() returning Path for centralized data directory

### Fixed
- Pydantic v2 deprecation in shared/config.py
- Unused import warnings (get_config, uuid) cleaned

## 0.1.0 — 2026-05-22

### Added
- Phases 1-6: 65 tools across 16 domains
- Phase 7a: Data Converter (9 tools)
- Phase 7b: Network Tools (7 tools)
- Phases 8a-8c: Process Manager, Excel Toolkit, Crypto Tools (20 tools)
- Full pyright + ruff strict compliance (0 errors)
- README.md with tool inventory
