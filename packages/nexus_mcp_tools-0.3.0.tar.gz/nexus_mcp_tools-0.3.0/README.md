# NEXUS MCP TOOLS

**147 MCP tools · 31 domains · 154 tests · 0 lint/type errors**

A suite of Model Context Protocol (MCP) tools for AI coding assistants — built with Python FastMCP, powered by uv, hardened with ruff+pyright.

---

## Quick Start

```powershell
# One-liner
# pipx install nexus-mcp-tools && nexus-mcp-tools
# or: uvx nexus-mcp-tools

# Local dev
cd C:\Users\mhmdz\Documents\OpenCode\tools
.venv\Scripts\python server.py
```

The server starts on **stdio transport** — it auto-launches with OpenCode TUI via `.opencode/mcp.json`. No ports, no daemons, no setup.

---

## Architecture

```
C:\Users\mhmdz\Documents\OpenCode\tools\
├── server.py                          # FastMCP entry point (132 tools)
├── pyproject.toml                     # Dependencies (fastmcp, httpx, sqlparse, etc.)
├── .opencode/mcp.json                 # MCP registration for OpenCode TUI
├── shared/
│   ├── config.py                      # Paths, defaults, config helpers
│   └── errors.py                      # Reusable error types
├── tools/
│   ├── api_tester/       (Phase 1)    # HTTP request toolkit
│   ├── git_hub/          (Phase 1)    # Git + GitHub operations
│   ├── db_toolkit/       (Phase 1)    # SQL database introspection
│   ├── security_scanner/ (Phase 2)    # SAST + dependency auditing
│   ├── container_mgr/    (Phase 2)    # Docker compose lifecycle
│   ├── profiler/         (Phase 3)    # cProfile timing + memory profiling
│   ├── test_gen/         (Phase 3)    # pytest generation + coverage
│   ├── file_toolkit/     (Phase 4)    # File search, ops, diff, replace
│   ├── env_inspector/    (Phase 4)    # System + package discovery
│   ├── code_reviewer/    (Phase 5)    # AST static analysis
│   ├── knowledge_base/   (Phase 5)    # Persistent key-value store
│   ├── memory/           (Phase 6)    # Project memory + session tracking
│   ├── data_converter/   (Phase 7)    # JSON, YAML, CSV conversion
│   ├── network_tools/    (Phase 7)    # DNS, port, SSL, whois, trace
│   ├── process_manager/  (Phase 8a)   # psutil process inspection
│   ├── excel_toolkit/    (Phase 8b)   # openpyxl read/write/merge
│   ├── crypto_tools/     (Phase 8c)   # hashlib, base64, uuid, hmac
│   ├── agentic_tools/    (Phase 9a)   # Docker, pkg mgr, GraphQL, Cloud
│   └── rag_tools/        (Phase 9b)   # Chunking, embeddings, vector search, RAG
```

---

## Tool Reference

### Phase 1 — Foundation

| Tool | Module | Description |
|------|--------|-------------|
| `api_request` | `api_tester` | Send HTTP requests (GET/POST/PUT/DELETE/PATCH/HEAD/OPTIONS) with headers, body, params |
| `api_validate` | `api_tester` | Validate HTTP response (status code, headers, JSON body, schema, timing) |
| `api_run_collection` | `api_tester` | Run a sequence of API requests with variable substitution |
| `git_status` | `git_hub` | Show working tree status |
| `git_commit` | `git_hub` | Stage and commit changes |
| `git_branch` | `git_hub` | List, create, switch, delete branches |
| `git_pr` | `git_hub` | Create PR, list PRs, view PR details |
| `git_diff` | `git_hub` | Show diff between commits/branches/working tree |
| `db_execute` | `db_toolkit` | Execute SQL query or statement |
| `db_list_tables` | `db_toolkit` | List all tables in a database |
| `db_describe_table` | `db_toolkit` | Show table schema (columns, types, constraints) |
| `db_migrations` | `db_toolkit` | List, create, run migrations |

### Phase 2 — Security & Containers

| Tool | Module | Description |
|------|--------|-------------|
| `security_scan_secrets` | `security_scanner` | Scan for hardcoded secrets, API keys, tokens in files |
| `security_check_deps` | `security_scanner` | Check npm/pip dependencies against advisory databases |
| `security_scan_code` | `security_scanner` | SAST: find common vulnerability patterns (injection, XSS, path traversal) |
| `container_compose` | `container_mgr` | Docker compose lifecycle (up/down/restart/ps) |
| `container_health` | `container_mgr` | Health check for services (port ping, HTTP probe) |
| `container_stats` | `container_mgr` | Live resource stats (CPU, memory, network) for running containers |
| `container_logs` | `container_mgr` | Fetch and filter container logs |
| `container_exec` | `container_mgr` | Run a command inside a running container |
| `container_build` | `container_mgr` | Build a Docker image |
| `container_pull` | `container_mgr` | Pull a Docker image |

### Phase 3 — Profiling & Testing

| Tool | Module | Description |
|------|--------|-------------|
| `profile_run` | `profiler` | Execute Python code under cProfile and return timing stats |
| `profile_memory` | `profiler` | Profile memory usage of a Python expression line-by-line |
| `profile_compare` | `profiler` | Compare two profiling results side by side |
| `test_generate` | `test_gen` | Generate pytest unit tests for a Python module |
| `test_run` | `test_gen` | Run pytest and return results with failure details |
| `test_coverage` | `test_gen` | Run pytest with coverage and return per-file coverage stats |
| `test_assert_templates` | `test_gen` | Return a reference of pytest assertion patterns |

### Phase 4 — Files & Environment

| Tool | Module | Description |
|------|--------|-------------|
| `file_search` | `file_toolkit` | Search file contents by regex pattern |
| `file_find` | `file_toolkit` | Find files by glob pattern, sorted by modification time |
| `file_rename` | `file_toolkit` | Rename or move a file |
| `file_compare` | `file_toolkit` | Diff two files, return unified diff output |
| `file_info` | `file_toolkit` | Get file metadata (size, modified, permissions, type) |
| `file_replace` | `file_toolkit` | Search and replace text in a file with optional regex |
| `env_info` | `env_inspector` | Get system information (OS, Python, CPU, memory, disk, env vars) |
| `env_has_tool` | `env_inspector` | Check if a command-line tool is installed and available |

### Phase 5 — Code Review & Knowledge

| Tool | Module | Description |
|------|--------|-------------|
| `review_analyze` | `code_reviewer` | AST-based static analysis (naming, complexity, docstrings, unused, cyclomatic) |
| `review_dependencies` | `code_reviewer` | Analyze Python import dependencies between modules |
| `review_metrics` | `code_reviewer` | Code metrics (lines, functions, classes, complexity, maintainability index) |
| `kb_store` | `knowledge_base` | Store a knowledge entry with tags |
| `kb_get` | `knowledge_base` | Retrieve a knowledge entry by key |
| `kb_search` | `knowledge_base` | Search knowledge entries by query, tags, or date range |
| `kb_list` | `knowledge_base` | List all knowledge entry keys |
| `kb_delete` | `knowledge_base` | Delete a knowledge entry |

### Phase 6 — Memory Manager

| Tool | Module | Description |
|------|--------|-------------|
| `memory_set` | `memory/project_memory` | Store a value in project memory with category |
| `memory_get` | `memory/project_memory` | Retrieve a value from project memory |
| `memory_search` | `memory/project_memory` | Search memory by query across all categories |
| `memory_list` | `memory/project_memory` | List all keys in a category |
| `memory_forget` | `memory/project_memory` | Delete a key from project memory |
| `memory_categories` | `memory/project_memory` | List all memory categories |
| `session_start` | `memory/session` | Start a new session and return session ID |
| `session_event` | `memory/session` | Log an event to the current session |
| `session_state_set` | `memory/session` | Set a state variable for the current session |
| `session_state_get` | `memory/session` | Get a state variable from current session |
| `session_summary` | `memory/session` | Get a summary of the current session |
| `session_list` | `memory/session` | List recent sessions |
| `session_close` | `memory/session` | Close the current session |
| `context_log` | `memory/context_log` | Log a tool call entry |
| `context_recent` | `memory/context_log` | Get recent context log entries |
| `context_search` | `memory/context_log` | Search context log by query |
| `context_stats` | `memory/context_log` | Statistics about the context log |
| `track_start` | `memory/file_tracker` | Start tracking a file for changes |
| `track_changes` | `memory/file_tracker` | Get changes since last snapshot |
| `track_stop` | `memory/file_tracker` | Stop tracking a file |

### Phase 7 — Data Converter & Network Tools

| Tool | Module | Description |
|------|--------|-------------|
| `convert_parse_json` | `data_converter` | Parse a JSON string into a Python structure |
| `convert_parse_yaml` | `data_converter` | Parse a YAML string into a Python structure |
| `convert_to_json` | `data_converter` | Convert data to formatted JSON string |
| `convert_to_yaml` | `data_converter` | Convert data to YAML string |
| `convert_json_to_yaml` | `data_converter` | Convert JSON string to YAML |
| `convert_yaml_to_json` | `data_converter` | Convert YAML string to JSON |
| `convert_parse_csv` | `data_converter` | Parse CSV string into structured rows |
| `convert_to_csv` | `data_converter` | Create CSV string from headers and rows |
| `convert_validate_schema` | `data_converter` | Validate JSON against JSON Schema |
| `network_dns_lookup` | `network_tools` | DNS resolution (A, AAAA, MX, CNAME, NS, TXT) |
| `network_port_check` | `network_tools` | Check if a TCP port is open |
| `network_http_check` | `network_tools` | HTTP health check with timing |
| `network_ssl_info` | `network_tools` | SSL/TLS certificate details |
| `network_whois` | `network_tools` | Whois lookup for domain or IP |
| `network_my_ip` | `network_tools` | Public IP and location info |
| `network_trace` | `network_tools` | Traceroute simulation |

### Phase 8a — Process Manager

| Tool | Module | Description |
|------|--------|-------------|
| `ps_list` | `process_manager` | List processes with name/user filters |
| `ps_find` | `process_manager` | Find processes by port or name |
| `ps_info` | `process_manager` | Detailed process info (exe, cwd, memory, threads) |
| `ps_kill` | `process_manager` | Terminate or force-kill a process |
| `ps_tree` | `process_manager` | Process hierarchy tree |
| `ps_system_stats` | `process_manager` | CPU, memory, disk, network, uptime |
| `ps_ports` | `process_manager` | Listening ports with owning processes |

### Phase 8b — Excel Toolkit

| Tool | Module | Description |
|------|--------|-------------|
| `excel_sheets` | `excel_toolkit` | List workbook sheets and dimensions |
| `excel_read` | `excel_toolkit` | Read sheet data as structured rows |
| `excel_write` | `excel_toolkit` | Write data to new or existing workbook |
| `excel_merge` | `excel_toolkit` | Merge multiple files into one workbook |
| `excel_csv_to_xlsx` | `excel_toolkit` | Convert CSV to Excel format |
| `excel_xlsx_to_csv` | `excel_toolkit` | Convert Excel sheet to CSV |

### Phase 8c — Crypto Tools

| Tool | Module | Description |
|------|--------|-------------|
| `crypto_hash` | `crypto_tools` | Hash text (MD5, SHA1, SHA256, SHA384, SHA512) |
| `crypto_hash_file` | `crypto_tools` | Hash a file |
| `crypto_base64_encode` | `crypto_tools` | Base64 encode a string |
| `crypto_base64_decode` | `crypto_tools` | Base64 decode a string |
| `crypto_uuid` | `crypto_tools` | Generate UUID v4 or v7 |
| `crypto_hmac` | `crypto_tools` | HMAC signature |
| `crypto_random` | `crypto_tools` | Cryptographically secure random bytes |

### Phase 9a — Agentic Dev Tools :: Docker Advanced

| Tool | Module | Description |
|------|--------|-------------|
| `docker_compose_ps` | `agentic_tools` | List compose services with status |
| `docker_compose_logs` | `agentic_tools` | Fetch compose service logs |
| `docker_image_inspect` | `agentic_tools` | Image metadata (size, layers, env, ports) |
| `docker_container_exec` | `agentic_tools` | Run command inside running container |
| `docker_prune` | `agentic_tools` | Clean unused resources (images, containers, volumes) |
| `docker_network_inspect` | `agentic_tools` | Network details and connected containers |
| `docker_volume_ls` | `agentic_tools` | List volumes with size info |

### Phase 9a — Agentic Dev Tools :: Package Manager

| Tool | Module | Description |
|------|--------|-------------|
| `pip_list` | `agentic_tools` | List installed Python packages |
| `pip_show` | `agentic_tools` | Show package metadata |
| `npm_list` | `agentic_tools` | List npm dependency tree |
| `npm_outdated` | `agentic_tools` | List outdated npm packages |
| `uv_deps` | `agentic_tools` | List uv dependency tree |

### Phase 9a — Agentic Dev Tools :: GraphQL Helpers

| Tool | Module | Description |
|------|--------|-------------|
| `graphql_query` | `agentic_tools` | Execute GraphQL query or mutation |
| `graphql_introspect` | `agentic_tools` | Introspect schema for types/queries/mutations |
| `graphql_schema_dump` | `agentic_tools` | Dump full schema with type definitions |
| `graphql_validate` | `agentic_tools` | Validate query against schema |

### Phase 9a — Agentic Dev Tools :: Cloud CLI Wrappers

| Tool | Module | Description |
|------|--------|-------------|
| `aws_s3_ls` | `agentic_tools` | List S3 buckets or objects |
| `aws_lambda_list` | `agentic_tools` | List Lambda functions |
| `aws_ec2_ls` | `agentic_tools` | List EC2 instances |
| `gcp_storage_ls` | `agentic_tools` | List GCS buckets or objects |
| `gcp_compute_ls` | `agentic_tools` | List GCE compute instances |
| `gcp_run_ls` | `agentic_tools` | List Cloud Run services |

### Phase 9b — AI / RAG Infrastructure

| Tool | Module | Description |
|------|--------|-------------|
| `rag_chunk_text` | `rag_tools` | Split text into overlapping chunks (character or sentence) |
| `rag_ollama_embed` | `rag_tools` | Generate embeddings via local Ollama |
| `rag_ollama_models` | `rag_tools` | List available Ollama models |
| `rag_vector_create` | `rag_tools` | Create a new vector index |
| `rag_vector_add` | `rag_tools` | Embed and add documents to index |
| `rag_vector_search` | `rag_tools` | Cosine similarity search against index |
| `rag_vector_list` | `rag_tools` | List all vector indexes |
| `rag_vector_delete` | `rag_tools` | Delete a vector index |
| `rag_retrieve` | `rag_tools` | End-to-end RAG: chunk + embed + search |

---

## Quality Gates

- **ruff check** — 0 errors across all source files
- **pyright** — 0 errors, 0 warnings, 0 informationals
- **Dependencies** — managed via `uv sync`, locked in `.venv`
- **Storage** — all persistent data lives in `~/.nexus-tools/`

## Design Decisions

| Decision | Choice | Rationale |
|----------|--------|-----------|
| Transport | stdio | Auto-launches with TUI, no port conflicts |
| Framework | FastMCP | Minimal boilerplate, tool registration by decorator |
| Package manager | uv | Fast installs, deterministic locks |
| Linter | ruff | Unified linting + formatting, fast |
| Type checker | pyright | Catches real bugs before runtime |
| File encoding | cp1252 | Windows compatibility, no Unicode in source |
| Parallel delegation | `task` subagent | Avoids session/port issues with `serve`+`attach` |

## MCP Registration

The server is registered in `.opencode/mcp.json`:

```json
{
  "mcpServers": {
    "nexus-tools": {
      "command": "C:\\Users\\mhmdz\\Documents\\OpenCode\\tools\\.venv\\Scripts\\python.exe",
      "args": ["C:\\Users\\mhmdz\\Documents\\OpenCode\\tools\\server.py"],
      "env": {"NEXUS_TOOLS_LOG_LEVEL": "INFO"}
    }
  }
}
```

OpenCode TUI auto-launches this server on startup. No manual activation needed.

---

*Last updated: 2026-05-23*
