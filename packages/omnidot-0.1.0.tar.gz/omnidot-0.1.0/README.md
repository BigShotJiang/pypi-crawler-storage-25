# OmniDot
A multi-scale dot plot visualization tool for comparative genomics. Analyze alignments from genomic fragments and chromosomes down to intragenic micro-structures.

**OmniDot**
 is a comprehensive dot plot visualization tool designed for multi-scale comparative genomics.

Traditional tools often struggle to bridge the gap between whole-genome synteny and sequence-level details. OmniDot is built to provide a unified visualization experience across all genomic dimensions:

* **Chromosomal Level**
: Visualize macro-synteny and large-scale structural variations between genomes.
* **Fragment Level**: efficiently handle and visualize unplaced **genomic fragments (scaffolds/contigs)**
 to assist in assembly validation.
* **Intragenic Level**: Zoom into the micro-scale to reveal **intragenic**
 alignments, exon/intron boundaries, and local repeats.

From broad evolutionary patterns to precise gene-level architecture, OmniDot helps you see the whole picture.



本工具由4个模块组成，基于**Linux 操作系统**编写的工具

## 系统要求

### 软件环境

- **操作系统**：Linux（推荐 Ubuntu 20.04+）、macOS 或 Windows（需 WSL2）

- **Python**：建议使用3.9 

- **必要工具**：minimap2=2.30，AUGUSTUS 3.5.0

  ```
  conda install -c bioconda minimap2=2.30 -y
  sudo apt-get update
  sudo apt-get install -y augustus augustus-data
  ```

  

- 使用需要安装 pandas ，toml，biopython，pysam ，matplotlib，numpy ，click库
  numpy pandas matplotlib biopython pysam click toml

## 核心模块介绍

### 1. Chromosomal Level

**功能**：生成高质量的染色体比对可视化图，支持多种分析模式。核心原理是 **基因组比对数据的坐标映射和可视化**。

- **BLAST模式**：显示基因间的一对一、一对多比对关系

- **共线性模式**：显示基因组间的共线性区块
- **组合模式**：可同时显示BLAST和共线性结果

#### 主要工作流程

1. **数据读取与处理**
   - 读取GFF、染色体长度、比对结果等文件
   - 构建基因位置映射字典
   - 过滤和预处理比对数据
2. **坐标计算**
   - 根据选择的坐标系统（torder或tpos）计算基因位置
   - 处理染色体边界和标签位置
3. **图形生成**
   - 创建主比对图
   - 添加染色体边界、标签
   - 绘制比对点或共线性区块
   - 添加颜色条、图例等辅助元素
4. **布局调整**
   - 调整子图位置和大小
   - 处理重叠和间距
   - 保存最终图像

#### 原理

#### 1. **数据模型与坐标系统**

脚本支持两种基因定位方式：

##### a. **torder（基因顺序）坐标系统**

- **原理**：按基因在染色体上的顺序编号进行定位
- **计算方法**：基因在总坐标系中的位置 = 前序染色体上的基因总数 + 该基因在当前染色体上的顺序号
- **优点**：均匀分布，不受染色体大小影响
- **适用**：基因密度比较、共线性模式分析

##### b. **tpos（物理位置）坐标系统**

- **原理**：按基因在染色体上的实际物理位置（bp）进行定位
- **计算方法**：基因在总坐标系中的位置 = 前序染色体的总长度 + 该基因在当前染色体上的中点位置

- **优点**：反映真实物理距离
- **适用**：物理距离相关的分析、密度计算

#### 2. **染色体坐标系构建**

把所有染色体"首尾相接"地排列在一条直线上，构建了一个连续的坐标空间。

1号染色体的结尾下一位是2号染色体的开头。

```
n = 0  # 累积位置
for 每个染色体 in 物种1:
    染色体起始位置[染色体] = n
    n = n + 染色体长度[染色体]
    染色体标签位置[染色体] = 起始位置 + 染色体长度/2  # 用于显示染色体编号
```

#### 3. **数据映射原理**

```
query基因位置 = query基因所在的染色体起始位置 + query基因在染色体上的位置
subject基因位置 = subject基因所在的染色体起始位置 + subject基因在染色体上的位置
```

每个比对关系在图中表现为一个点：(query位置, subject位置)

#### 4.共线性区块的识别

1. **区块检测**：基于连续的基因对构建共线性区块
2. **区块合并**：根据距离阈值合并相邻的共线性区块
3. **Ks值整合**：计算区块内基因对的Ks统计值（平均值/中位数）

#### 5. **关键算法原理**

##### a. **共线性区块合并算法**

过滤小区块

合并两个距离相近的区块

##### b**对称性与半数显示原理**

当分析同一物种的自身比对时（如全基因组复制分析），比对图具有对称性。利用这一特性：在图上显示2个物种自身比对比对图

### 2. Fragment Level

**功能**：生成序列间的相似性点图，用于直观显示序列间的相似区域。

**点阵图（Dot Plot）**生成工具。点阵图是生物信息学中用于可视化两个序列之间相似性的经典方法。

#### 主要功能

#### **序列比对分析**

#### **自适应窗口大小**

$$
W=⌊A⋅[1+α⋅ln( 
max(L 
1
​
 ,L 
2
​
 )/
 min(L 
1
​
 ,L 
2
​
 )
​
 )]+B⋅( 
min(L 
1
​
 ,L 
2
​
 )/
 (C+min(L 
1
​
 ,L 
2
​
 ))
​
 )⌋
$$

##### **输入变量**

- `L1`, `L2`: 两个输入序列的长度
- `max`: 较长序列的长度 `max(L1, L2)`
- `min`: 较短序列的长度 `min(L1, L2)`
- `ratio = max/min`: 序列长度比值

##### **参数说明**

| 参数      | 名称         | 作用                 | 典型范围                    |
| :-------- | :----------- | :------------------- | :-------------------------- |
| **A**     | 基准窗口常数 | 确定基本窗口大小     | DNA: 20-30 蛋白质: 12-18    |
| **α (J)** | 谨慎程度     | 控制长度差异的敏感性 | 0.15-0.35                   |
| **B**     | 补偿强度     | 调整短序列的补偿量   | -3 至 -10                   |
| **C**     | 补偿饱和点   | 控制补偿的饱和程度   | DNA: 150-300 蛋白质: 50-150 |

##### **第一部分：长度差异调整项**

```
A·[1 + α·ln(ratio)]
```

- **功能**：根据序列长度差异调整窗口大小
- **工作原理**：
  - 当`ratio=1`（序列等长）：`ln(1)=0`，该项简化为`A`
  - 当`ratio>1`（长度不同）：`ln(ratio)>0`，窗口增大
  - `α`控制对长度差异的敏感度

##### **第二部分：短序列补偿项**

```
B·[min/(C + min)]
```

- **功能**：对短序列进行补偿调整
- **工作原理**：
  - 当`min`很小：`min/(C+min) ≈ min/C`，补偿较小
  - 当`min`很大：`min/(C+min) ≈ 1`，达到饱和补偿
  - `B`为负值，实际是减少窗口大小
  - `C`决定补偿的饱和点

####  **公式的生物学意义**

| 序列情况       | 窗口大小趋势 | 原因                             |
| :------------- | :----------- | :------------------------------- |
| **序列等长**   | 接近基准值A  | 不需要特殊调整                   |
| **长度差异大** | 适当增大     | 适应不同尺度的比较               |
| **序列很短**   | 相对较大     | 避免窗口太小失去统计意义         |
| **序列很长**   | 相对较小     | 提高分辨率，避免过大窗口模糊细节 |

#### **数据处理选项**

- **归一化**：可选择是否对得分进行归一化
- **最大值设置**：可使用理论最大值或实际最大值
- **过滤阈值**：可设置显示的下限值
- **值过滤**：基于0自动过滤低信息值

####  **可视化输出**

- 生成高质量点阵图

#### **数据输出**

- 生成三个数据文件：
  - 序列窗口信息（CSV格式）
  - 原始得分矩阵（CSV格式）
  - 归一化后得分矩阵（CSV格式，可选）

#### 核心算法流程

1. **序列预处理**：清理特殊字符，识别序列类型
2. **窗口计算**：根据序列长度自适应计算窗口大小
3. **序列分割**：将序列分割为滑动窗口
4. **比对打分**：使用指定矩阵进行全局比对
5. **数据过滤**：根据阈值过滤低分值点
6. **可视化**：生成点阵图并保存结果

### 3.Intragenic Level

本项目提供了一个完整的基因组片段自比对分析流程，通过4个独立的Python脚本实现了从基因组序列处理到可视化展示的全过程。

#### 文件结构说明

#### 主要脚本文件

###### 1.`make_date_1.py` - 基因组片段切割模块

- **功能**：将大基因组文件按指定参数切割成小片段
  - 输入：完整的染色体FASTA文件
  - 输出：按chunk_size（默认2000bp）切割的片段FASTA文件
  - 关键参数：
    - `new_chr`：目标染色体编号
    - `start/end`：切割的起始和结束位置（可设置为"start"/"end"使用整个染色体）
    - `chunk_size`：每个片段的长度
  - 输出序列ID格式：`chr1:20000000:20002000`（包含位置信息）

######  2.`make_minimap_2.py` - 序列比对模块

**功能**：使用minimap2进行自比对

- 调用minimap2工具将切割后的片段进行自比对
- 参数设置：使用`-ax ava-ont`模式，适合长序列比对
- 输出：SAM格式的比对结果文件

###### 3.`make_date_bed_3.py` - 比对结果解析模块

**功能**：解析SAM文件，提取比对统计信息

- 使用pysam库读取SAM文件
- 解析CS标签获取详细的比对统计：
  - 匹配数、错配数、插入/缺失事件
  - 计算三种同一性百分比（基于匹配、基于事件、总体）
- 对称化处理：使比对结果双向对称
- 输出：TSV格式的比对统计表格

###### 4.`make_fignew_4.py` - 可视化模块

**功能**：生成点图可视化比对结果

- 读取比对统计表格

- 创建带颜色映射的散点图：
  - x轴：比对片段的中点位置
  - y轴：比对片段的距离差
  - 颜色：基于同一性百分比（byevents）

- 添加同一性分布直方图

- 支持四种布局（top/bot/left/right）

- 输出：高分辨率PNG图片

#### 整体流程

完整基因组FASTA
    ↓ (make_date_1.py)
切割成小片段FASTA
    ↓ (make_minimap_2.py)
minimap2自比对 → SAM文件
    ↓ (make_date_bed_3.py)
解析统计信息 → TSV表格
    ↓ (make_fignew_4.py)
生成可视化点图 → PNG图像

### 4.process_file

本项目提供了**过滤和整理基因预测结果**，从基因预测软件（Augustus）输出的 GFF、CDS 和 PEP 文件并处理得到需要的gff,cds, pep和lens文件

###### 7.py

功能:**并行运行 Augustus 基因预测软件**，对输入的基因组序列进行基因结构预测

**自动部署 Augustus**

- 检查 Augustus 可执行文件是否存在
- 如果不存在，自动解压 `augustus.tar.gz` 压缩包
- 设置 `AUGUSTUS_CONFIG_PATH` 环境变量，指向配置文件目录

**序列分割与并行处理**

- 读取输入的 FASTA 文件（默认 `chr.part.fa`）
- 将序列按 CPU 核心数分割成多个小块文件
- 使用 `ProcessPoolExecutor` 并行运行 Augustus
- 每个进程处理一个序列块，大幅提升处理速度

**结果合并与清理**

- 收集所有并行任务生成的 GFF 文件
- 合并成最终的输出文件
- 删除临时文件

###### 2.py,1.py,5.py

过滤和整理基因预测结果，得到需要的的 GFF、CDS 和 PEP 文件

拆分Augustus运行得到的结果

筛选高表达/高置信度的基因

重构基因命名排序

过滤序列文件得到 gff , cds , pep 文件

根据得到的 gff 文件得到lens文件

## 输入文件格式

#### Chromosomal 

##### GFF格式

| 列   | 信息      | 解释                        |
| ---- | --------- | --------------------------- |
| 1    | Chr       | 染色体                      |
| 2    | ID        | 基因名称                    |
| 3    | Start     | 基因的起始位置              |
| 4    | End       | 基因的末端位置              |
| 5    | Direction | 基因序列的方向              |
| 6    | Order     | 每条染色体的顺序，从 1 开始 |
| 7    | told_name | 原始 ID                     |

```
1	  coca01g00001	   390	       1820	      -         1	 Cc01_g00010
```



##### lens

| 列   | 信息   | 解释           |
| ---- | ------ | -------------- |
| 1    | Chr    | 染色体         |
| 2    | Length | 染色体序列长度 |
| 3    | Number | 染色体基因数量 |

```
1       23021474     1399
```

##### Collinearity

```python
# Alignment 1: score=1451 pvalue=0.2214 N=49 1&1 plus
vivi01g00514 514 vivi01g00515 515 1
```

##### KS

```python
id1 id2    ka_NG86    ks_NG86    ka_YN00    ks_YN00
vivi01g00514    vivi01g00515   0.0686 0.1182 0.0678 0.1258
vivi01g00517    vivi01g00516   0.0796 0.137  0.0835 0.1197
vivi01g00518    vivi01g00517   0.0278 0.0306 0.0299 0.0248
```

##### color_dates

| 列   | 信息  | 解释           |
| ---- | ----- | -------------- |
| 1    | ID    | 基因名称       |
| 2    | color | 基因显示的颜色 |

```
coca01g00001    #F09201
```

##### gene_show

| 列   | 信息 | 解释     |
| ---- | ---- | -------- |
| 1    | Chr  | 染色体   |
| 2    | ID   | 基因名称 |

```
1     coca01g00001
```

#### Fragment 

2个标准的只有一个序列的fast文件

```
>schi1g0000008
MSKTGYYLDLCVFLVTLILIITTRTAAKDPSTILSRFQQYLQINTAQPHPNYYEAAEFII
SQAKLLSLESQTLEFVKGKPLILLKWPGKDPTLPSILLNSHTDVVPSEHHKWTHPPFSAH
LDSTTGNIFARGSQDMKCVGLQYLEAIRKLKSYGFRPLRTLYLSFLPDEEIGGNDGARKF
VDSDVFAKMNVGIVLDEGLASPTDNYRAFYGERSPWWLVVKAVGAPGHGAKLYDNTAMEN
LLKSIEIIRRFRAAQFDLVKAGQKAEGEVISVNMVFLKAGTPSPSGFVMNLQPSEAQAGF
DIRVPPTADQASLERLIADEWAPASRNMTFEFKQKVSVNDKLGRPAVTAVDSSNIWWALF
EEAIIKANARLGKPEIFPASTDARYFRERGLPAIGFSPMANTPILLHDHNEFLNKDEYLK
GIDVYESIIKTYASYIQYRRDDASREELKVSLSVNQYFMYDYATHTLVSVVDVSIPYCSN
NQTQFPDEENAKAISLFEDVVHLNDAIEDEAKRMENLVKGIFAGNLFDLGSAQLGNVSKM
THI*
```

```
>schi10g0000796
MESSGELVPFPLLTTPIESNYRACTIPYRFPSDNPKKPTPTELSWIDLFMNSIPSFRKRA
ESDDSVPDAPIRAEKFAQRYSAILEDMKKDPESHGGPPDCILLCRLREQVLREVGFRDIF
KKVKDEENAKAISLFKDVVSLNDAIEDEAKRVENLVRGIFAGNIFDLGSAKLAELFSEDG
ISFLASFQNLVPRPWVIDDLDVFITKWSKKTWKKAVIFVDNSGADVILGILPFARELLRH
GAQVVLAANDLPSINDVTYPELVEIISKLKDEHGKLIGVDTSNLLVANSGNDLPVIDLTT
VSQELAYLASDADLVIVEGMGRGIETNLYARFKCDSLKIGMVKHPEVAQFLGGRLYDCVF
KFNEASS*
```

#### Intragenic 

1个标准的只有一个序列的cds fast文件

```
>chr1
CAGTAAAGTTTGCAAAGAGATTCTGGCAAAGTTGTAATCATCGAATGTGAAATGTCAAGT
AAGTGTAAATGGATTAGTTTGCCAATGGAGGTCGGCAACTCTTTCACATCTGCTCCAAAC
AATTTTAGGACATGCAAGTATTTGAACTTTGATAACATATCATCAGCTATGCCACCCTCC
AGAAATAATGTGCGAAGTGATGCTGATTTTTTTTCATTGATGATTTCCACCATTCTTTCG
GATGAGTATACTGCAAGGTAGCGGTCCTCATTGCTGCTGCTACGATTCAAAATTGATTTT
GCAAAATCGTGCACAAGGTCATGCATTTTATACCTATTTTCTTTTACTTCTTCCAATAAG
GAAGTTTGCAGCAAAATTCTCAAATACTCACATCCTATTTTCTCCATCGTTCTTTCATTT
TGGGAATCCGGTTGAAGAAAGCCTTCAGCCATCCAAAGCTCAACTAGTAGATCTTGTTCC
AACTCAGCATCTTGATCAAAAATTGAGCAATATGCAAAACATTTCTTAACCGGTGCAAGT
GACAGATGATCAAAACTCACCTTAATTATTTGCTCGATCCGACCTTGGTCTCCATTCAAC
AGACTCTCCTCCAAAATAGATTGCCACTCCTCTTTTCTCTTTTTATATAACAAACCTCCA
ATTAACTTTGCTGCCAGAGGTAGACCGTCACATCTTCTTAAAACTCGCTCCCTTATGTCT
TCCAATTCTTTTGGTACTTCTTCCCCTACAGTTGCCCATTTATTAATGATGGACCAGCAA
TCATCATTGCATAGCTTTCCTAGCCCATGGCGAGTAAAATTGATCTGCGGAAGACCGGAC
AGAGTAGTTTCCACTTCTTGCAGACGAGTGGTAACAAGACACCAGCTCCCTTTCTTCGCT
TCGAGTGCCTTCAATGTGGTGAAAAAGTCATCCAATTGTTGATGATTCCACAAATCGTCA
AGAACAAGCAAACATCTTTTTCCCTTGATTTCATTTTGAATTCCTCGAACTATTACGTCC
CTAACATCCGCGTCAGGCTTGTTTCCTGTTGACGATTCTAGAATCATTTTGAAGAGATCC
ATGGTTTCAACTTCTTTAGCCACACAAACCCAAATTTTTTTGTCAAAATGATTATCATTA
AACTGTGGATTGTTGTAAACGGCTTTAG
```

开头必须为     >chr

如  >chr1  >chr2  >chr3  >chr4

#### process_file

1个标准的序列或染色体的fast文件

```
>ctg001900_P
TGATTTTAGATGTGTATGATCATATATGTAATATATTGCTTTTTCAATATATTTATGTCATATTTGAAGATAAAATGGACATCTATGTAAATAAACCCTA
AAAAAAGCGAAAGGAAAGAAAAGAAGTTTAATAAGTGAGAAGAAAAGAGAGAAAATTGAGAGATTGTGCAATTTTGCATCTACTTGATCAATAGCTTGTT
TGGAGGTTGATTAAAGTTCGATTGTGGTGAAGGTACGACGGCATGTTCCCAAGGGTGGAGTTCTTACATTACGAATGGTGGAGATCGAGATTTGGAGGTC
TACAACATCATATTGTATTGGGTATTTGGTAGCCACTTTTAAAGTAGAAGGTTTTCCCTTTTTCTTAACGAAGCCATTAAAGATTGTTTTATCTTGAGCT
GTGTGATAATGTATACCTCTAGTTTTATTTAGAAAGAATTAGGGTGTAAACCATTGTTAATTGATGGTGGAGATTTTGACTTAGGTCTGTGGTTTTTTAC
TCCTTTCCCTCGGAAGGTTTTTCCACTTTATCATTTATTGTTTTACTGTGATCTGTTGATTGTTTCATGTTAGGTTCTCACCGGAGAAGTGGATAATTAC
GTTGTTTCGTATTGATATTTATTCTGATATAAAAAGTTTGTTATATTTATAAATAAATGTTTTTTAATTGAGAGAAGTGAAAATGTGACGGTAAAAATTC
TCAAGGTCTGAATTTGAATCTTGGAATACTTTCTGTTTGTGCTTGTTCGGCTTATTGATTCATTTTGTTAGGTCTAAAATGGGGACATTATTGAATTATA
CACAAATATTTAGGTGGCTTTTATTGGTGTTATTAATTATGATGTTTCTTGATTTAACTTAACTCACATATGTTACGCGTGGTTTATGTGTTGTTTAAAA
```
