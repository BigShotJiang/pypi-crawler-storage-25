#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
OmniDot 主入口
支持 python -m omnidot 运行
"""

import sys

def main():
    """入口函数"""
    try:
        # 从同目录下的 core.py 导入 main 函数
        from .core import main as core_main
        # 运行并返回退出码
        return core_main()
    except ImportError as e:
        print(f"❌ 导入错误: {e}")
        print("   请确保 omnidot 已正确安装")
        return 1
    except KeyboardInterrupt:
        print("\n⚠ 用户中断")
        return 130
    except Exception as e:
        print(f"❌ 运行错误: {e}")
        return 1

if __name__ == "__main__":
    sys.exit(main())