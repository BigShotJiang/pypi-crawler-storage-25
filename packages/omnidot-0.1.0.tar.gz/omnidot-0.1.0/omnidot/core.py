import os
import toml
import subprocess
import sys
import argparse  # 添加这行
from pathlib import Path


def get_package_dir():
    """获取包所在目录"""
    return Path(__file__).parent.absolute()
    # __file__：当前文件的完整路径


def find_config(config_arg=None):
    """查找配置文件

    优先级：
    1. 命令行指定的路径
    2. 用户当前工作目录
    3. 包目录
    """
    # 1. 命令行指定
    if config_arg:
        config_path = Path(config_arg)
        if config_path.exists():
            return config_path.resolve()
        else:
            print(f"⚠ 警告: 指定的配置文件不存在: {config_arg}")

    # 2. 用户当前工作目录
    user_cwd = Path.cwd()
    user_config = user_cwd / "config.toml"
    if user_config.exists():
        return user_config.resolve()

    # 3. 包目录
    package_config = get_package_dir() / "config.toml"
    if package_config.exists():
        return package_config.resolve()

    return None


def run_process_file_mode(config_path):
    """运行 process_file 模式"""
    print("\n🔬 运行 process_file 模式: Augustus 基因预测")
    print("=" * 60)

    script_dir = get_package_dir() / 'process_file/src'
    scripts = [
        ("7.py", "运行 Augustus 基因预测"),
        ("2.py", "处理初步 GFF/CDS/PEP"),
        ("1.py", "处理最终 GFF/CDS/PEP"),
        ("5.py", "生成染色体长度统计")
    ]

    for script, desc in scripts:
        script_path = script_dir / script
        print(f"\n📌 {desc}")

        if not script_path.exists():
            print(f"❌ 错误: 找不到 {script_path}")
            return False

        try:
            # 传递配置文件路径作为参数
            result = subprocess.run(
                [sys.executable, str(script_path), str(config_path)],
                cwd=str(script_dir),
                capture_output=True,
                text=True
            )

            if result.stdout:
                print(result.stdout)
            if result.stderr:
                print(f"⚠️ {result.stderr}")
            if result.returncode != 0:
                print(f"❌ 脚本返回错误码: {result.returncode}")
                return False

        except Exception as e:
            print(f"❌ 执行出错: {e}")
            return False

    return True


def run_chromosomal_mode(config_path):
    """运行 Chromosomal 模式"""
    print("\n🧬 运行 Chromosomal 模式: 共线性分析")
    print("=" * 60)

    script_path = get_package_dir() / 'chromosomal/graph43.py'
    script_dir = script_path.parent

    if not script_path.exists():
        print(f"❌ 错误: 找不到 {script_path}")
        return False

    try:
        # 传递配置文件路径作为参数
        result = subprocess.run(
            [sys.executable, str(script_path), str(config_path)],
            cwd=str(script_dir),
            capture_output=True,
            text=True
        )

        if result.stdout:
            print(result.stdout)
        if result.stderr:
            print(f"⚠️ {result.stderr}")
        if result.returncode != 0:
            print(f"❌ 脚本返回错误码: {result.returncode}")
            return False

    except Exception as e:
        print(f"❌ 执行出错: {e}")
        return False

    return True


def run_fragment_mode(config_path):
    """运行 Fragment 模式"""
    print("\n🧩 运行 Fragment 模式: 片段分析")
    print("=" * 60)

    script_path = get_package_dir() / 'fragment/dotter5.py'
    script_dir = script_path.parent

    if not script_path.exists():
        print(f"❌ 错误: 找不到 {script_path}")
        return False

    try:
        # 传递配置文件路径作为参数
        result = subprocess.run(
            [sys.executable, str(script_path), str(config_path)],
            cwd=str(script_dir),
            capture_output=True,
            text=True
        )

        if result.stdout:
            print(result.stdout)
        if result.stderr:
            print(f"⚠️ {result.stderr}")
        if result.returncode != 0:
            print(f"❌ 脚本返回错误码: {result.returncode}")
            return False

    except Exception as e:
        print(f"❌ 执行出错: {e}")
        return False

    return True


def run_intragenic_mode(config_path):
    """运行 Intragenic 模式"""
    print("\n🧬 运行 Intragenic 模式: 基因内分析")
    print("=" * 60)

    script_dir = get_package_dir() / 'intragenic/project/src'
    scripts = [
        ("make_date_1.py", "切割基因组"),
        ("make_minimap_2.py", "minimap2 比对"),
        ("make_date_bed_3.py", "解析 SAM 文件"),
        ("make_fignew_4.py", "生成可视化")
    ]

    for script, desc in scripts:
        script_path = script_dir / script
        print(f"\n📌 {desc}")

        if not script_path.exists():
            print(f"❌ 错误: 找不到 {script_path}")
            return False

        try:
            # 传递配置文件路径作为参数
            result = subprocess.run(
                [sys.executable, str(script_path), str(config_path)],
                cwd=str(script_dir),
                capture_output=True,
                text=True
            )

            if result.stdout:
                print(result.stdout)
            if result.stderr:
                print(f"⚠️ {result.stderr}")
            if result.returncode != 0:
                print(f"❌ 脚本返回错误码: {result.returncode}")
                return False

        except Exception as e:
            print(f"❌ 执行出错: {e}")
            return False

    return True


def main():
    # ========== 添加命令行参数解析 ==========
    parser = argparse.ArgumentParser(
        description="Omnidot - 基因组共线性分析工具",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  omnidot                         # 自动查找 config.toml
  omnidot --config my_config.toml # 使用指定配置文件
  omnidot -c /path/to/config.toml
  omnidot --help                  # 显示帮助
        """
    )
    parser.add_argument(
        '--config', '-c',
        type=str,
        default=None,
        help='配置文件路径'
    )
    parser.add_argument(
        '--version', '-v',
        action='version',
        version='Omnidot 0.1.0'
    )

    args = parser.parse_args()

    # 默认配置
    config_1 = "Chromosomal"
    config_2 = "blast"
    current_vars = ['config_1', 'config_2']

    # 查找配置文件（优先使用命令行参数）
    config_path = find_config(args.config)

    if config_path:
        try:
            with open(config_path, "r", encoding="utf-8") as f:
                config = toml.load(f)
            if "Config" in config:
                intragenic_config = config["Config"]
                if 'config_1' in intragenic_config:
                    config_1 = intragenic_config['config_1']
                    print(f"📝 从配置读取 config_1 = {config_1}")
                if 'config_2' in intragenic_config:
                    config_2 = intragenic_config['config_2']
                    print(f"📝 从配置读取 config_2 = {config_2}")
            print(f"✅ 加载配置: {config_path}")
        except Exception as e:
            print(f"⚠ 配置加载失败: {e}")
            config_path = None
    else:
        print("⚠ 警告: 未找到 config.toml 文件，使用默认配置")

    # 运行对应模式
    mode_functions = {
        "process_file": run_process_file_mode,
        "Chromosomal": run_chromosomal_mode,
        "Fragment": run_fragment_mode,
        "Intragenic": run_intragenic_mode,
    }

    if config_1 not in mode_functions:
        print(f"❌ 未知模式: {config_1}")
        sys.exit(1)

    print(f"\n🚀 启动 omnidot")
    print(f"📁 工作目录: {Path.cwd()}")
    print(f"🎯 运行模式: {config_1}")

    success = mode_functions[config_1](config_path)

    if success:
        print("\n" + "=" * 60)
        print(f"🎉 恭喜！{config_1} 模式运行成功！")
        print("=" * 60)
    else:
        print(f"\n❌ {config_1} 模式运行失败")
        sys.exit(1)


if __name__ == "__main__":
    main()