#处理初步得到的gff与cds,pep文件得到进一步的gff与cds,pep文件   3
import pandas as pd
from Bio import SeqIO
from Bio.Seq import Seq
from Bio.SeqRecord import SeqRecord
import os                  # 操作系统功能
import toml
import sys
from pathlib import Path

config_file_path = sys.argv[1] if len(sys.argv) > 1 else None
config_abs = os.path.abspath(config_file_path)
config_dir = os.path.dirname(config_abs)
output_base_dir = os.path.join(config_dir, "data_old")
output_gff_1 = os.path.join(output_base_dir, "augustus.gff")     #产生的原始gff中的gff
output_cds_1 = os.path.join(output_base_dir, "augustus.cds")     #产生的原始gff中的cds
output_pep_1 = os.path.join(output_base_dir, "augustus.pep")     #产生的原始gff中的pep

output_new_gff =r'../../augustus_new.gff'      #产生的处理好的gff
output_new_cds = r'../../augustus_new.cds'     #产生的处理好的cds
output_new_pep = r'../../augustus_new.cds'     #产生的处理好的pep

ns = 20

current_vars_1 = ['n']
current_vars_2 = ['output_new_pep','output_new_gff','output_new_cds']

try:
    config_file_path = '../../config.toml'   #配置文件位置
    config_dir = os.path.dirname(os.path.abspath(config_file_path))

    # 加载配置文件（在上级的上级目录）
    with open(config_file_path, "r", encoding="utf-8") as f:
        config = toml.load(f)

    if "process_file" in config:
        make_gff_config = config["process_file"]

        for var_name in current_vars_1:
            if var_name in make_gff_config:
                globals()[var_name] = make_gff_config[var_name]

        for var_name in current_vars_2:
            if var_name in make_gff_config:
                value = make_gff_config[var_name]  # 直接从配置文件获取
                if isinstance(value, str):
                    if not os.path.isabs(value):  # 相对路径
                        value = os.path.join(config_dir, value)
                globals()[var_name] = value  # 总是赋值

except FileNotFoundError:
    print("⚠ 警告: 未找到 config.toml 文件，使用所有默认配置")
except Exception as e:
    print(f"❌ 错误: 配置文件加载失败 - {str(e)}")
    print("⚠ 将使用默认配置继续运行")



new_gffs = pd.read_csv(
        output_gff_1,
        sep='\t',
        header=None,
        names=['seqid', 'source', 'type', 'start', 'end', 'score', 'strand', 'phase', 'attributes']
    )
# 统计CDS数量
new_gffs['parent'] = new_gffs['attributes'].str.extract(r'Parent=([^;]+)')
data = (new_gffs[new_gffs['type'] == 'CDS']
        .groupby('seqid')['parent']
        .nunique()
        .to_dict())
#.groupby('seqid') - 按seqid分组
#.size() - 计算每组有多少行
#.to_dict() - 将结果Series转为字典
# 排序并显示结果
sorted_data = dict(sorted(data.items(), key=lambda x: x[1], reverse=True))
#data.items()  将字典转为可迭代的(key, value)对
#key=lambda x: x[1]  返回每个元组的第二个元素     sorted()  排序 reverse=True  降序排列
datas =[]
if len(sorted_data) >= ns:
    sorted_datas=list(sorted_data.items())
    sorted_datas=sorted_datas[:ns]
    print(sorted_datas)
    for seqid, count in sorted_datas:
        datas.append(seqid)
else:
    sorted_datas = list(sorted_data.items())
    for seqid, count in sorted_datas:
        datas.append(seqid)
new_data = new_gffs[(new_gffs['type'] == 'CDS') & (new_gffs['seqid'].isin(datas))].copy()
new_data['temp_id'] = new_data['attributes'].str.split(';').str[0].str.replace('ID=', '')
new_data['tnew_name'] = new_data['seqid'] + new_data['temp_id'].str.split('.').str[0]
new_data['told_name'] = new_data['tnew_name']
new_data = new_data.drop(columns=['source', 'type', 'score', 'phase','temp_id','attributes'])
new_data = new_data.groupby('tnew_name').agg({
    'seqid': 'first',  # 同一 gene_name 的 seqid 应该相同，取第一个
    'start': 'min',
    'end': 'max',
    'told_name' : 'first',
    'strand': 'first',  # 链应该相同，取第一个
}).reset_index()
new_data['chr'] = new_data['seqid'].str.replace(r'[^\d]', '', regex=True)
new_data['torder'] = new_data['tnew_name'].str.extract(r'.*g(\d+)$').astype(int)
new_data = new_data.drop(columns=['seqid'])
new_data = new_data.sort_values(['chr', 'torder'], ascending=[True, True]).reset_index(drop=True)
new_data = new_data[['chr', 'tnew_name', 'start', 'end', 'strand', 'torder','told_name']]


gene_names_list = new_data['tnew_name'].tolist()  # 或使用 set() 提高效率
cds_records = []
for record in SeqIO.parse(output_cds_1, "fasta"):
    if record.id in gene_names_list:  # 现在检查是否在值列表中
        cds_records.append(record)

pep_records = []
for record in SeqIO.parse(output_pep_1, "fasta"):
    if record.id in gene_names_list:  # 现在检查是否在值列表中
        pep_records.append(record)

print(f"\n找到 {len(new_data)} 条匹配的gff序列")
print(f"\n找到 {len(cds_records)} 条匹配的CDS序列")
new_data.to_csv(output_new_gff, sep='\t', header=False, index=False)
SeqIO.write(cds_records, output_new_cds, "fasta")
SeqIO.write(pep_records, output_new_pep, "fasta")