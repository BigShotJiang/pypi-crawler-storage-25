#处理 AUGUSTUS 产生的文件得到初步的  gff  与  cds,pep 文件   2
import toml
import re
import sys
import os                  # 操作系统功能
from pathlib import Path

output_gff = r"augustus_all.gff"

os.makedirs('data', exist_ok=True)  # exist_ok=True 表示如果目录已存在也不报错
config_file_path = sys.argv[1] if len(sys.argv) > 1 else None
config_abs = os.path.abspath(config_file_path)
config_dir = os.path.dirname(config_abs)
output_base_dir = os.path.join(config_dir, "data_old")
os.makedirs(output_base_dir, exist_ok=True)
output_gff_1 = os.path.join(output_base_dir, "augustus.gff")        #产生的原始gff中的gff
output_cds_1 = os.path.join(output_base_dir, "augustus.cds")        #产生的原始gff中的cds
output_pep_1 = os.path.join(output_base_dir, "augustus.pep")        #产生的原始gff中的pep


current_vars_2 = ['output_gff']

try:
    config_file_path = sys.argv[1] if len(sys.argv) > 1 else None   #配置文件位置
    config_dir = os.path.dirname(os.path.abspath(config_file_path))

    # 加载配置文件（在上级的上级目录）
    with open(config_file_path, "r", encoding="utf-8") as f:
        config = toml.load(f)

    if "process_file" in config:
        make_gff_config = config["process_file"]

        for var_name in current_vars_2:
            if var_name in make_gff_config:
                value = make_gff_config[var_name]  # 直接从配置文件获取
                if isinstance(value, str):
                    if not os.path.isabs(value):  # 相对路径
                        value = os.path.join(config_dir, value)
                globals()[var_name] = value  # 总是赋值

except FileNotFoundError:
    print("⚠ 警告: 未找到 config.toml 文件，使用所有默认配置")
except Exception as e:
    print(f"❌ 错误: 配置文件加载失败 - {str(e)}")
    print("⚠ 将使用默认配置继续运行")

with open(output_gff, 'r') as f_in, open(output_gff_1, 'w') as f_out:
    for line in f_in:
        if not line.startswith('#'):  # 如果行不以#开头
            f_out.write(line)  # 写入新文件

print(f"过滤完成，结果已保存到: {output_gff_1}")

genes = {}
current_gene = None     #基因的名称
current_contig = None   #基因所在的contig
current_cds = ""        #基因的CDS序列
collecting_cds = False  # 标记是否正在收集CDS序列

with open(output_gff, 'r') as f_in:
    for line in f_in:
        line = line.strip()
        # .strip() 去除行首和行尾的空白字符
        if line.startswith('# start gene'):
            #.startswith()  检查字符串是否以指定的前缀开头  返回：布尔值（True 或 False）
            if current_gene and current_cds and current_contig: # 保存上一个基因
                # 清理CDS序列（去除所有空白字符 空格、制表符、换行符等）
                clean_cds = re.sub(r'\s+', '', current_cds)
                # 创建唯一的基因全名（contig + 基因名）
                gene_full_name = f"{current_contig}{current_gene}"
                # 存入字典
                genes[gene_full_name] = clean_cds
            # 开始新基因
            current_gene = line.split()[-1]
            current_cds = ""
            current_contig = None
            collecting_cds = False
        elif not line.startswith('#') and '\t' in line:
            #不是注释行
            fields = line.split('\t')
            # .split() 默认以空白字符（空格、制表符）分割字符串，返回列表
            if len(fields) >= 9 and current_contig is None:
                # 至少有9个制表符分隔的字段 current_contig为空
                current_contig = fields[0] # 提取contig名称（如 ctg000040_P）
        elif '# coding sequence = [' in line or collecting_cds:
            # 使用正则表达式提取方括号内的内容
            if '# coding sequence = [' in line and not collecting_cds:
                # 开始收集CDS序列
                collecting_cds = True

                # 使用正则表达式提取当前行中方括号内的内容
                # re.search() 在字符串中搜索匹配正则表达式的第一个位置
                # 模式：\[(.*) 匹配 '[' 后面的所有字符
                match = re.search(r'\[(.*)', line)
                if match:
                    current_cds += match.group(1)  # group(1) 获取第一个括号匹配的内容

                    # 检查这一行是否已经包含结束符 ']'
                    if ']' in line:
                        collecting_cds = False
            elif collecting_cds:
                # 继续收集多行CDS序列
                # 检查这一行是否包含结束符 ']'
                if ']' in line:
                    # 使用正则表达式提取 ']' 之前的内容
                    match = re.search(r'(.*?)\]', line)
                    if match:
                        current_cds += match.group(1)
                    collecting_cds = False
                else:
                    # 这一行没有结束符，整行都是序列
                    # 移除开头的 '# ' 如果存在
                    seq_part = re.sub(r'^#\s*', '', line)
                    current_cds += seq_part
# 保存最后一个基因
if current_gene and current_cds and current_contig:
    clean_cds = re.sub(r'\s+', '', current_cds)
    gene_full_name = f"{current_contig}{current_gene}"
    genes[gene_full_name] = clean_cds
with open(output_cds_1, 'w', encoding='utf-8') as f_out:
    for gene_name, sequence in genes.items():
        f_out.write(f">{gene_name}\n")
        # 每60个字符换行，使FASTA格式更美观
        clean_sequence = re.sub(r'[^ATGCNatgcn]', '', sequence).upper()
        for i in range(0, len(sequence), 60):
            f_out.write(clean_sequence[i:i+60] + "\n")
print(f"FASTA格式序列已保存到: {output_cds_1}")


genes = {}
current_gene = None     #基因的名称
current_contig = None   #基因所在的contig
current_cds = ""        #基因的CDS序列
collecting_cds = False  # 标记是否正在收集CDS序列

with open(output_gff, 'r') as f_in:
    for line in f_in:
        line = line.strip()
        # .strip() 去除行首和行尾的空白字符
        if line.startswith('# start gene'):
            #.startswith()  检查字符串是否以指定的前缀开头  返回：布尔值（True 或 False）
            if current_gene and current_cds and current_contig: # 保存上一个基因
                # 清理CDS序列（去除所有空白字符 空格、制表符、换行符等）
                clean_cds = re.sub(r'\s+', '', current_cds)
                # 创建唯一的基因全名（contig + 基因名）
                gene_full_name = f"{current_contig}{current_gene}"
                # 存入字典
                genes[gene_full_name] = clean_cds
            # 开始新基因
            current_gene = line.split()[-1]
            current_cds = ""
            current_contig = None
            collecting_cds = False
        elif not line.startswith('#') and '\t' in line:
            #不是注释行
            fields = line.split('\t')
            # .split() 默认以空白字符（空格、制表符）分割字符串，返回列表
            if len(fields) >= 9 and current_contig is None:
                # 至少有9个制表符分隔的字段 current_contig为空
                current_contig = fields[0] # 提取contig名称（如 ctg000040_P）
        elif '# protein sequence = [' in line or collecting_cds:
            # 使用正则表达式提取方括号内的内容
            if '# protein sequence = [' in line and not collecting_cds:
                # 开始收集CDS序列
                collecting_cds = True

                # 使用正则表达式提取当前行中方括号内的内容
                # re.search() 在字符串中搜索匹配正则表达式的第一个位置
                # 模式：\[(.*) 匹配 '[' 后面的所有字符
                match = re.search(r'\[(.*)', line)
                if match:
                    current_cds += match.group(1)  # group(1) 获取第一个括号匹配的内容

                    # 检查这一行是否已经包含结束符 ']'
                    if ']' in line:
                        collecting_cds = False
            elif collecting_cds:
                # 继续收集多行CDS序列
                # 检查这一行是否包含结束符 ']'
                if ']' in line:
                    # 使用正则表达式提取 ']' 之前的内容
                    match = re.search(r'(.*?)\]', line)
                    if match:
                        current_cds += match.group(1)
                    collecting_cds = False
                else:
                    # 这一行没有结束符，整行都是序列
                    # 移除开头的 '# ' 如果存在
                    seq_part = re.sub(r'^#\s*', '', line)
                    current_cds += seq_part
# 保存最后一个基因
if current_gene and current_cds and current_contig:
    clean_cds = re.sub(r'\s+', '', current_cds)
    gene_full_name = f"{current_contig}{current_gene}"
    genes[gene_full_name] = clean_cds


with open(output_pep_1, 'w', encoding='utf-8') as f_out:
    for gene_name, sequence in genes.items():
        f_out.write(f">{gene_name}\n")
        # 每60个字符换行，使FASTA格式更美观
        clean_sequence = re.sub(r'[^ACDEFGHIKLMNPQRSTVWYacdefghiklmnpqrstvwy]', '', sequence).upper()
        for i in range(0, len(clean_sequence), 60):
            f_out.write(clean_sequence[i:i+60] + "\n")
print(f"FASTA格式序列已保存到: {output_pep_1}")

