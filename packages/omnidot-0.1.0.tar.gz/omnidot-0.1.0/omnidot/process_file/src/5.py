#处理最终的gff文件得到 lens   4

import pandas as pd
from Bio import SeqIO
from Bio.Seq import Seq
from Bio.SeqRecord import SeqRecord
import os                  # 操作系统功能
import toml
import sys
output_new_gff =r'../../augustus_new.gff'      #产生的处理好的gff
output_new_lens = r'../../augustus_new.lens'   #产生的处理好的lens


current_vars_2 = ['output_new_gff','output_new_lens']

try:
    config_file_path = sys.argv[1] if len(sys.argv) > 1 else None   #配置文件位置
    config_dir = os.path.dirname(os.path.abspath(config_file_path))

    # 加载配置文件（在上级的上级目录）
    with open(config_file_path, "r", encoding="utf-8") as f:
        config = toml.load(f)

    if "process_file" in config:
        make_gff_config = config["process_file"]

        for var_name in current_vars_2:
            if var_name in make_gff_config:
                value = make_gff_config[var_name]  # 直接从配置文件获取
                if isinstance(value, str):
                    if not os.path.isabs(value):  # 相对路径
                        value = os.path.join(config_dir, value)
                globals()[var_name] = value  # 总是赋值

except FileNotFoundError:
    print("⚠ 警告: 未找到 config.toml 文件，使用所有默认配置")
except Exception as e:
    print(f"❌ 错误: 配置文件加载失败 - {str(e)}")
    print("⚠ 将使用默认配置继续运行")

new_gffs = pd.read_csv(
        output_new_gff,
        sep='\t',
        header=None,
        names=["chr", "tnew_name", "tpos_start", "tpos_end", "tchain", "torder", "told_name"],
        dtype={
            "chr": int,
            "tnew_name": str,
            "tpos_start": int,
            "tpos_end": int,
            "tchain": str,
            "torder": int,
            "told_name": str
        }
    )
lens = new_gffs.groupby('chr').agg(
    chr_length=('tpos_end', 'max'),
    gene_count=('tnew_name', 'count')
).reset_index()

print("染色体大小与基因数量：")
print(lens)
lens.to_csv(output_new_lens, sep='\t', header=False, index=False)
