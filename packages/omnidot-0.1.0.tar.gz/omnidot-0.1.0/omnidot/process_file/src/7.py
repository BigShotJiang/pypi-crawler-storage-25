#运行augustus      1
import subprocess          # 运行外部命令
from pathlib import Path   # 处理文件路径
import os                  # 操作系统功能
from concurrent.futures import ProcessPoolExecutor  # 并行处理
import time                # 计时
from Bio import SeqIO      # Biopython的序列IO模块
import toml
import shutil
import sys
# ============ 1. 默认参数设置 ============
# 默认值
input_fasta = r"../../chr.part.fa"
output_gff = r"../../augustus_all.gff"
cpus = 10  # 使用几个核心
species = 'human'   #指定训练的物种模型。
gff3 = 'on'         # 输出GFF3格式
protein = "on"      # 输出蛋白质序列
codingseq = "on"    # 输出CDS序列
strand = "both"     #预测链的方向。 both（双向），forward 或 backward。

current_vars_1 = ['species','gff3' ,'codingseq', 'protein','strand','cpus']
current_vars_2 = ['input_fasta','output_gff']

try:
    config_file_path = sys.argv[1] if len(sys.argv) > 1 else None   #配置文件位置
    config_dir = os.path.dirname(os.path.abspath(config_file_path))

    # 加载配置文件（在上级的上级目录）
    with open(config_file_path, "r", encoding="utf-8") as f:
        config = toml.load(f)

    if "process_file" in config:
        make_gff_config = config["process_file"]

        # 先处理所有变量
        for var_name in current_vars_1:
            if var_name in make_gff_config:
                globals()[var_name] = make_gff_config[var_name]

        for var_name in current_vars_2:
            if var_name in make_gff_config:
                value = make_gff_config[var_name]  # 直接从配置文件获取
                if isinstance(value, str):
                    if not os.path.isabs(value):  # 相对路径
                        value = os.path.join(config_dir, value)
                globals()[var_name] = value  # 总是赋值

except FileNotFoundError:
    print("⚠ 警告: 未找到 config.toml 文件，使用所有默认配置")
except Exception as e:
    print(f"❌ 错误: 配置文件加载失败 - {str(e)}")
    print("⚠ 将使用默认配置继续运行")

def check_augustus():
    """检查 augustus 是否在 PATH 中"""
    augustus_path = shutil.which('augustus')
    if augustus_path is None:
        print("❌ 错误: 未找到 augustus")
        print("请确保 augustus 已安装并添加到 PATH")
        return None
    print(f"✅ 找到 augustus: {augustus_path}")
    return augustus_path


def get_augustus_config():
    """获取 Augustus 配置目录"""
    # 检查环境变量
    if os.environ.get('AUGUSTUS_CONFIG_PATH'):
        config_path = os.environ['AUGUSTUS_CONFIG_PATH']
        if Path(config_path).exists():
            print(f"✅ 使用配置目录: {config_path}")
            return config_path

    # 尝试常见路径
    common_paths = [
        "/usr/local/share/augustus/config",
        "/usr/share/augustus/config",
        os.path.expanduser("~/augustus/config"),
        os.path.expanduser("~/miniconda3/share/augustus/config"),
        os.path.expanduser("~/miniconda3/config"),
        os.path.expanduser("~/anaconda3/share/augustus/config"),
        os.path.expanduser("~/anaconda3/config"),
    ]

    for path in common_paths:
        if Path(path).exists():
            print(f"✅ 找到配置目录: {path}")
            return path

    print("⚠ 警告: 未找到 Augustus 配置目录")
    print("  请设置环境变量 AUGUSTUS_CONFIG_PATH")
    return None

# 检查 augustus 是否可用
augustus_bin = check_augustus()
if not augustus_bin:
    exit(1)
config_path = get_augustus_config()
# ============ 3. 设置环境变量 ============
env = os.environ.copy()  # os.environ.copy()：复制当前系统的所有环境变量
if config_path:
    env["AUGUSTUS_CONFIG_PATH"] = str(Path(config_path).absolute())  # .absolute()转换为绝对路径
# 分割文件

records = list(SeqIO.parse(input_fasta, "fasta"))
total_records = len(records)
print(f"   总序列数: {total_records}")
# 计算每个chunk的序列数
chunk_size = max(1, total_records // cpus)
chunk_files = []
for i in range(min(cpus, total_records)):
    start = i * chunk_size
    if i < cpus - 1 :
        end = start + chunk_size
    else:
        end = total_records
    #如果不是最后一块：start + chunk_size  如果是最后一块：total_records（确保包含所有剩余序列）
    if start >= total_records:
        break
    chunk_file = f"{input_fasta}.chunk{i + 1}.fa"
    with open(chunk_file,'w') as f:
        SeqIO.write(records[start:end], f, "fasta")
    chunk_files.append(chunk_file)  # 保存文件路径，方便后续使用
#  调用程序

# 使 Augustus 能找到它的配置文件与运行文件
def run_augustus(in_file,i):
    i = i
    out_file = f"{in_file}.gff"
    cmd = [
        "augustus",  # Augustus 程序本身
        f"--species={species}",  # 物种参数（必需）
        # 在这里添加任意多的手动配置参数
        f"--gff3={gff3}",  # 输出 GFF3 格式
        f"--codingseq={codingseq}",  # 输出编码序列
        f"--protein={protein}",  # 输出蛋白质序列
        f"--strand={strand}",  # 双链预测
        in_file  # 输入文件
    ]  # cmd  是一个列表  包含  程序  参数1 参数2 参数3 参数4 等
# 等同于在终端  ./../bin/augustus/bin/augustus --species=human --gff3=on --protein=on --UTR=on chr.part.fa
    with open(out_file,'w') as f :
        result = subprocess.run(  # subprocess.run() 是 Python 中运行外部命令的主要方法
            cmd,  # 要执行的命令
            stdout=f,  # 标准输出重定向到文件
            stderr=subprocess.PIPE,  # 错误信息捕获到变量
            env=env,  # 使用临时环境变量
            text=True,  # 以文本模式处理
            encoding='utf-8',  # 明确指定 UTF-8
            errors='replace'  # 遇到无法解码的字符用 � 代替
        )
    log_file = out_file + ".log"
    with open(log_file, 'w', encoding='utf-8') as log:
        log.write(result.stderr)
        # 检查运行结果
    if result.returncode == 0:  # 返回码/退出码  成功执行的命令 0  失败的命令 非0值（如1, 2, 127等）
        print(f" {in_file} 成功!")
        return out_file
    else:
        print(f" {in_file} 失败: 错误保存到:{log_file}")
        if Path(out_file).exists():
            os.remove(out_file)
        return None  # 失败返回 None


print(f"\n🚀 步骤2: 准备并行运行 (使用 {cpus} 核心)")
start_time = time.time()

with ProcessPoolExecutor(max_workers=cpus) as executor:
    #   ProcessPoolExecutor: 创建进程池执行器，用于并行执行任务
    #   max_workers=cpus: 设置最大工作进程数，通常等于CPU核心数
    futures = []  # 创建一个空列表
    for i, f in enumerate(chunk_files):  # 遍历每个文件  enumerate(chunk_files)生成：(索引, 文件) 对
        # 提交任务到进程池，并获取Future对象
        future = executor.submit(run_augustus, f, i)
        # 将Future对象添加到列表
        futures.append(future)
    out_files = []  # 创建空列表
    failed_count = 0
    for f in futures:  # 遍历每个任务
        result = f.result()  # 等待任务完成，获取返回值
        if result is not None:
            out_files.append(result)  # 把结果添加到列表
        else:
            failed_count += 1
if failed_count > 0:
    print(f"\n❌ 警告: {failed_count} 个任务失败!")

# 5. 合并结果

with open(output_gff, 'w') as out_f:
    for f in out_files:
        with open(f, 'r') as in_f:
            for line in in_f:
                out_f.write(line)

for f in out_files:  # 遍历两个列表合并后的所有文件
    if Path(f).exists():            # 检查文件是否存在
        os.remove(f)                # 如果存在，则删除该文件

print(f"完成augustus! 耗时: {time.time()-start_time:.1f}秒")