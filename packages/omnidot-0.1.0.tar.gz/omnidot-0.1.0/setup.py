from setuptools import setup, find_packages
import os

# 获取当前目录
here = os.path.abspath(os.path.dirname(__file__))

# 读取 requirements.txt
requirements = []
req_path = os.path.join(here, "requirements.txt")
if os.path.exists(req_path):
    with open(req_path, "r") as f:
        requirements = [line.strip() for line in f if line.strip() and not line.startswith("#")]

setup(
    name="omnidot",
    version="0.1.0",
    description="基因组共线性分析工具",
    packages=find_packages(),
    install_requires=requirements,
    entry_points={
        "console_scripts": [
            "omnidot=omnidot.__main__:main",
        ],
    },
    python_requires=">=3.8",
)