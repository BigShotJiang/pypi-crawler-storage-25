#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import sys

from fuse.cli import main

if __name__ == "__main__":
    sys.exit(main())  # Fuse entry point
