# DF2-PLAY-907 — Playground: Batch run (parallel) and summary report

story_uuid: f8c5f416-2c33-483b-b51a-5623eb53ea6e
story_id: DF2-PLAY-907
title: Playground: Batch run (parallel) and summary report
required_planes: [ops, api]

CONTRACT FORMATION MODE: implementation is irrelevant; do not compare against current code/UI. Define user-expected outcomes and test oracles only.

plane_oracles:
- plane: ops
  oracle: "DevFlow can run a batch of scenarios with bounded parallelism and produces a stable summary (passed/failed/skipped, timings) without losing individual run artifacts."
  anchor: "command:devflow play run --batch <selector> --max-parallel N --json"

- plane: api
  oracle: "The batch summary and per-scenario results are persisted as artifacts and can be queried for review and CI gating."
  anchor: "sqlite:.devflow/execution.sqlite artifacts(type=playground.batch_summary)"

## Story statement
As a developer, I want DevFlow to run a batch of playground scenarios (optionally in parallel), so that I can validate a project quickly with a reproducible report.

## Outcome oracle (user-observable)
- A batch run produces a final summary report and links to individual scenario results.

## Preconditions
- Scenario discovery exists.

## Steps
1. Select a batch selector (all, category, tag, story-derived plan).
2. Run `devflow play run --batch ...`.

## Acceptance criteria
1. MUST support bounded parallelism with a deterministic max concurrency.
2. MUST produce a stable summary including counts and identifiers of failing scenarios.
3. MUST persist both batch summary and per-scenario artifacts.
4. MUST NOT exceed configured resource limits (time/memory) without failing with a clear reason.

## Non-goals
- Not implementing a UI dashboard.

## Contract test spec (Given/When/Then)
- Given a batch with at least one passing and one failing scenario
- When I run the batch with `--json`
- Then the summary includes correct counts and lists failing scenario slugs
- And per-scenario artifacts exist and are linked from the batch artifact
