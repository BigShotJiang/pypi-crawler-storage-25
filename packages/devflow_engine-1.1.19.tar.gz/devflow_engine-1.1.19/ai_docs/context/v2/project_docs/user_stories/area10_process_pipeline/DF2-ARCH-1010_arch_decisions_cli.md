story_uuid: 9e2d9c7f-7d10-4b4a-9c2e-2d3b0c3bdf39
story_id: DF2-ARCH-1010
title: Architecture Decisions CLI (register constraints during ideation)
required_planes: [ui, ops]

CONTRACT FORMATION MODE: implementation is irrelevant; do not compare against current code/UI. Define user-expected outcomes and test oracles only.

plane_oracles:
- plane: ui
  oracle: "A user/agent can add/list/remove architecture decisions (constraints) via CLI with clear output and stable ids."
  anchor: "cli:devflow arch decision"
- plane: ops
  oracle: "Decisions are persisted deterministically in a canonical repo file and can be validated in CI without network access."
  anchor: "fs:ai_docs/.../architecture/decisions.yaml"

# DF2-ARCH-1010 — Architecture Decisions CLI

## Story
As a DevFlow operator,
I want a CLI tool to register architecture constraints (e.g., required workflow engine) during ideation,
so that downstream work is shaped and enforceable.

## Command surface
- `devflow arch decision add --key <k> --value <v> [--rationale <text>]`
- `devflow arch decision list [--json]`
- `devflow arch decision remove <decision_id>`

## Acceptance criteria
1. **Canonical storage**
   - Decisions are stored at:
     - `ai_docs/context/v2/project_docs/architecture/decisions.yaml`

2. **Stable ids + deterministic formatting**
   - Each decision has a stable `decision_id` (deterministic or UUID with stored value).
   - File formatting is stable and machine-parseable.

3. **Decision fields**
   - Must include: `decision_id`, `key`, `value`, `rationale`, `created_at` (policy: created_at optional if determinism requires).

4. **Offline**
   - No network calls.

## Contract test spec
- Given a repo
- When decision add/list/remove is invoked
- Then decisions.yaml is updated deterministically and CLI outputs stable identifiers
