story_uuid: 3d545b61-4ac3-4f04-a47e-425ad3dc9724
story_id: DF2-IDEA-503
title: Generate draft baseline user stories per plane from repo analysis (with anchors + evidence)
required_planes: [api, ui]

CONTRACT FORMATION MODE: implementation is irrelevant; do not compare against current code/UI. Define user-expected outcomes and test oracles only.

## Intent
As a DevFlow user,
I want DevFlow to generate a baseline set of *draft* user stories (contracts) per plane for an idea,
so that planning starts from a structured, evidence-backed draft instead of a blank page.

## Scope
- Add a command that converts repo analysis into draft story contracts.
- Draft stories are produced per “plane” (auth/api/ui/integrations/ops; exact set is a DevFlow v2 concept).
- Each story references anchors/evidence produced by the analysis.

## Out of scope
- Auto-merging drafts into canonical contracts (handled by promotion stories).
- Enforcing a single story template; the content must be machine + human readable, but exact markdown layout can vary.

## Contract
### User-visible behavior
- Command: `devflow idea drafts generate --idea <idea_id> --analysis <analysis_id>`
- Optional inputs:
  - `--planes auth,api,ui,...` (defaults to all relevant planes)
  - `--max-stories <n>`
  - `--style <contract|gherkin|hybrid>` (if supported; optional)
- Outputs:
  - prints how many drafts were generated per plane
  - prints where the draft files were written

### Draft story requirements
- Drafts MUST be written as markdown files under the idea workspace, separate from canonical stories, e.g.:
  - `.devflow/ideas/<idea_id>/drafts/<draft_set_id>/<plane>/.../*.md`
- Each draft story MUST include, at minimum:
  - a stable local identifier (`draft_story_id`)
  - title
  - plane
  - intent (who/what/why)
  - acceptance criteria (test oracles)
  - at least one evidence reference:
    - either inline anchors, or an evidence section listing anchors

### Evidence linkage
- Each draft story MUST link back to:
  - the `analysis_id` used
  - a list of anchors used as evidence
- The anchors MUST match the anchor schemes produced by analysis (see DF2-IDEA-502).

plane_oracles:
- plane: api
  oracle: "Given an analysis artifact, the generator creates draft story files with plane metadata and explicit evidence anchors."
  anchor: "api:story-draft-generator(analysis_id→drafts)"
- plane: ui
  oracle: "CLI output clearly indicates draft locations and counts, enabling a human review workflow."
  anchor: "cli:devflow idea drafts generate stdout"

## Acceptance criteria
- MUST provide a draft generation command that writes markdown files.
- MUST generate drafts per plane, with plane declared in each draft.
- MUST include acceptance criteria in each draft.
- MUST include evidence anchors and a backlink to the source `analysis_id`.
- MUST store drafts outside canonical story locations.

## Contract test specs
1) Generates plane-partitioned drafts
   - Given an idea and analysis
   - When `devflow idea drafts generate --idea X --analysis Y` is executed
   - Then draft files exist grouped by plane
   - And each draft contains a plane declaration

2) Evidence required
   - Given a generated draft
   - When the file is inspected
   - Then it contains at least one `anchor:` reference
   - And it contains the `analysis_id`
