story_uuid: 2c4a73b9-3c1d-4a2d-9efb-7b35bb3b1aa5
story_id: DF2-INV-1003
title: Architecture Inventory (canonical seam registry) for routes/services/models/adapters/events/artifacts
required_planes: [ops, api]

CONTRACT FORMATION MODE: implementation is irrelevant; do not compare against current code/UI. Define user-expected outcomes and test oracles only.

plane_oracles:
- plane: ops
  oracle: "A repo has a single, discoverable inventory file listing canonical seams and public surfaces, linked to story_ids/uuids for traceability."
  anchor: "fs:ai_docs/.../architecture/inventory.yaml"
- plane: api
  oracle: "Public API routes and event/artifact kinds referenced by stories are registered and uniquely identified."
  anchor: "inventory:routes + events + artifacts"

# DF2-INV-1003 — Architecture Inventory (canonical seam registry)

## Story
As a DevFlow maintainer,
I want an explicit architecture inventory that registers canonical seams and public surfaces,
so that new work binds to existing pathways instead of creating parallel implementations.

## Inventory contents (minimum)
- routes (API paths + schema ids)
- services (orchestrators / use-cases)
- domain models (entities/state machines)
- adapters (integrations/providers)
- events (canonical event names)
- artifacts (artifact kinds)

## Acceptance criteria
1. **Single canonical file**
   - Inventory exists at a stable path (policy):
     - `ai_docs/context/v2/project_docs/architecture/inventory.yaml`

2. **Link to stories**
   - Each inventory item can include `story_id` and/or `story_uuid` referencing the contract that introduced it.

3. **Uniqueness**
   - Inventory ids must be unique within their category.

4. **Tooling compatibility**
   - Inventory format is machine-parseable and stable.

## Contract test spec
- Given a repo
- When inventory is generated or edited
- Then it validates, is parseable, and contains required categories
