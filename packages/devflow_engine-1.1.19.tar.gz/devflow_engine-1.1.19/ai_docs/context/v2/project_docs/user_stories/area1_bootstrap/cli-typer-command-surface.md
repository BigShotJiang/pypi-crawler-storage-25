story_uuid: 6e50829b-98f4-4f8f-98a0-01df335842b9
story_id: DF2-BOOT-002
title: Typer CLI surface for devflow_engine (helpful defaults + stable command set)
required_planes: [auth, api, ui, integrations, ops]

CONTRACT FORMATION MODE: implementation is irrelevant; do not compare against current code/UI. Define user-expected outcomes and test oracles only.

## Intent
Ensure the `devflow-engine` CLI has a stable, discoverable command surface suitable for iterative expansion.

## User value
As a developer, I can run a small set of safe, deterministic CLI commands (help/version/doctor) to verify installation and environment readiness.

plane_oracles:
- plane: auth
  oracle: "CLI commands in this story (`--help`, `version`, `doctor`) do not require authentication and must not read secrets by default."
  anchor: "cli:doctor (no secrets)"
- plane: api
  oracle: "`devflow-engine version` prints a semver-like version string and exits 0."
  anchor: "cli:devflow-engine version"
- plane: ui
  oracle: "`devflow-engine --help` and subcommand help are readable and include concise descriptions for each command."
  anchor: "cli:help text quality gate"
- plane: integrations
  oracle: "`doctor` performs only local checks (python version, importability, config discovery) and does not call external services."
  anchor: "cli:devflow-engine doctor (offline)"
- plane: ops
  oracle: "All commands have deterministic exit codes: 0 on success, non-zero on failed local readiness checks."
  anchor: "cli:exit codes"

## Acceptance criteria
- MUST provide a top-level `devflow-engine` command that shows help with exit code 0.
- MUST provide a `version` command that prints exactly one line containing the package version and exits 0.
- MUST provide a `doctor` command that:
  - MUST check local, offline readiness (at minimum: package import, config path resolution)
  - MUST exit 0 when all checks pass
  - MUST exit non-zero when a required check fails
- MUST NOT attempt any external HTTP calls for `--help`, `version`, or `doctor`.
- MUST NOT emit stack traces to stdout on expected failures; failures should be summarized and return non-zero.

## Contract test specs
1) Help is available
   - Run: `uv run devflow-engine --help`
   - Expect: exit 0
   - Expect: stdout contains `Commands` (or equivalent Typer help section)

2) Version prints one line
   - Run: `uv run devflow-engine version`
   - Expect: exit 0
   - Expect: stdout matches regex `^\S+\n$` (single non-empty line)

3) Doctor runs offline
   - Run: `uv run devflow-engine doctor`
   - Expect: exit 0 on a healthy local env
   - Expect: stdout/stderr do not include URLs being fetched or network error messages
