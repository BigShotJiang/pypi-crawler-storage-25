story_uuid: be945622-8743-4728-9da0-5648c34a06e6
story_id: DF2-BOOT-003
title: Config hierarchy + discovery for devflow_engine (defaults, env overrides, CLI override)
required_planes: [auth, api, ui, integrations, ops]

CONTRACT FORMATION MODE: implementation is irrelevant; do not compare against current code/UI. Define user-expected outcomes and test oracles only.

## Intent
Define a predictable configuration hierarchy so the engine can be operated consistently across machines and environments.

## Configuration hierarchy (contract)
Precedence from highest → lowest:
1) CLI flags (explicit runtime override)
2) Environment variables
3) User config file (e.g., in an OS-appropriate config directory)
4) Repo/project config file (optional)
5) Built-in defaults

plane_oracles:
- plane: auth
  oracle: "No secret values are required for config discovery; sensitive fields (if any) are never printed in full by default commands."
  anchor: "cli:doctor config summary (redacted)"
- plane: api
  oracle: "The runtime can resolve an effective config and expose it to the CLI for verification (e.g., via `doctor` output)."
  anchor: "cli:doctor shows effective config sources"
- plane: ui
  oracle: "When config is missing/invalid, the CLI prints a human-readable error message describing what to fix and where the config is expected."
  anchor: "cli:config error message"
- plane: integrations
  oracle: "Config discovery supports environment-variable overrides suitable for CI/CD and containers (no interactive prompts)."
  anchor: "env:DEVFLOW_ENGINE_* overrides"
- plane: ops
  oracle: "Config file locations are deterministic and follow platform conventions; the engine documents the search order."
  anchor: "docs:config search paths"

## Acceptance criteria
- MUST define and document a config search order and precedence as listed above.
- MUST support overriding at least one non-sensitive setting via:
  - a config file value
  - an environment variable
  - a CLI flag
  with the expected precedence.
- MUST provide a way to observe which config source won (e.g., `doctor` displays effective value + source).
- MUST NOT require writing a config file to run `devflow-engine --help` or `devflow-engine version`.
- MUST NOT print raw secret values (if present) in normal CLI output; secrets MUST be redacted.

## Contract test specs
1) Precedence: defaults < file < env < CLI
   - Given: a config file sets `log_level=INFO`
   - And: env sets `DEVFLOW_ENGINE_LOG_LEVEL=WARNING`
   - When: run `uv run devflow-engine doctor --log-level ERROR`
   - Then: effective log level reported is `ERROR`

2) Missing config is non-fatal for safe commands
   - Given: no config file exists
   - When: run `uv run devflow-engine --help`
   - Then: exit 0

3) Redaction
   - Given: env sets a value matching a secret field name (if supported)
   - When: run `uv run devflow-engine doctor`
   - Then: output contains a redacted placeholder (e.g., `***`) rather than the raw value
