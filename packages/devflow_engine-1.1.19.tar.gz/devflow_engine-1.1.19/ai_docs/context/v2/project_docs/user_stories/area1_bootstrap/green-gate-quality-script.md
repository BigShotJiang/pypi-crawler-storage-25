story_uuid: d5b56adb-f263-4f6e-b390-2c9997d77aca
story_id: DF2-BOOT-005
title: Green-gate bootstrap script (fast local quality checks: format/lint/test)
required_planes: [auth, api, ui, integrations, ops]

CONTRACT FORMATION MODE: implementation is irrelevant; do not compare against current code/UI. Define user-expected outcomes and test oracles only.

## Intent
Provide a single local command to validate the repo is healthy (tests pass, style checks run) to support rapid iteration during DevFlow v2 development.

## User value
As a contributor, I can run one command to confirm my environment + changes are acceptable before opening a PR.

plane_oracles:
- plane: auth
  oracle: "Quality gates do not require credentials and must not reach out to protected resources."
  anchor: "script:green gate runs offline"
- plane: api
  oracle: "The test suite can be executed in a clean environment and returns a non-zero code on failure."
  anchor: "tests:pytest"
- plane: ui
  oracle: "Script output is concise: it clearly indicates which stage failed (format/lint/test) without overwhelming noise."
  anchor: "script:stage banners"
- plane: integrations
  oracle: "Script does not call external APIs; it only runs local tooling (uv/pytest/linter)."
  anchor: "script:no network"
- plane: ops
  oracle: "Script is deterministic and suitable for CI adoption later (same steps, same exit codes)."
  anchor: "script:exit codes"

## Acceptance criteria
- MUST provide a runnable script (e.g., `scripts/green.sh`) that:
  - MUST run formatting and/or lint checks (or at minimum one of them) and then tests
  - MUST exit 0 when all stages succeed
  - MUST exit non-zero when any stage fails
- MUST document how to run the script from a fresh checkout.
- MUST NOT modify tracked files silently without telling the user; if auto-formatting occurs, the script MUST print that it made changes and exit non-zero (or require an explicit flag).
- MUST NOT require network access beyond dependency installation already performed by `uv sync`.

## Contract test specs
1) Green gate passes on main
   - Given: clean checkout at main branch
   - When: run `./scripts/green.sh`
   - Then: exit 0

2) Green gate fails on a known failing test
   - Given: a deliberate, local breaking change that causes pytest to fail
   - When: run `./scripts/green.sh`
   - Then: exit non-zero
   - And: output indicates the failing stage is `tests`

3) No silent rewrites
   - Given: formatting would change a file
   - When: run `./scripts/green.sh`
   - Then: script explicitly reports that formatting changes are needed (or were applied)
