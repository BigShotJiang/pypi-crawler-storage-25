story_uuid: 0eab64f7-f9e8-4277-a8da-ff76ca50bd0e
story_id: DF2-IDEA-504
title: Draft story storage: separate from canonical, with provenance + reproducibility
required_planes: [api, ops]

CONTRACT FORMATION MODE: implementation is irrelevant; do not compare against current code/UI. Define user-expected outcomes and test oracles only.

## Intent
As a DevFlow user,
I want draft story sets to be stored separately from canonical contracts with clear provenance,
so that experimentation and iteration do not accidentally change the project’s authoritative requirements.

## Scope
- Define a storage policy for drafts vs canonical.
- Record provenance sufficient to reproduce or audit draft generation.
- Enable multiple draft sets for the same idea.

## Out of scope
- Long-term archival to external storage.
- Collaboration/merge conflict resolution beyond filesystem/git.

## Contract
### Separation policy
- Canonical contracts live under the canonical story locations (see DF2-STORY-401).
- Draft story artifacts MUST NOT be written into canonical locations.
- Draft artifacts MUST live under an idea-scoped directory, e.g.:
  - `.devflow/ideas/<idea_id>/drafts/`

### Draft set model
- Drafts are grouped into “draft sets” (one generation run / one editing session), each with its own ID:
  - `draft_set_id`
- Each draft set MUST include a manifest file (machine-readable), e.g.:
  - `.devflow/ideas/<idea_id>/drafts/<draft_set_id>/manifest.json`
- The manifest MUST include at minimum:
  - `draft_set_id`
  - `idea_id`
  - `source_analysis_id` (or `null` if manually created)
  - `created_at` (UTC)
  - `generator` (name/version)
  - `planes` included
  - list of produced draft story file paths

### Reproducibility
- If a draft set is generated from analysis, the manifest MUST include enough info to re-run:
  - input analysis reference
  - git ref/commit SHA used by the analysis
  - generator version

plane_oracles:
- plane: api
  oracle: "Drafts can be enumerated and loaded independently of canonical stories via a draft manifest." 
  anchor: "api:draft-store(list_sets, load_manifest)"
- plane: ops
  oracle: "A repo checkout can be kept clean because canonical story locations are never mutated by draft generation." 
  anchor: "ops:no-canonical-writes"

## Acceptance criteria
- MUST store drafts under idea-scoped directories, never in canonical locations.
- MUST write a draft set manifest with required provenance fields.
- MUST support multiple draft sets per idea.

## Contract test specs
1) No canonical writes
   - Given canonical story files exist
   - When draft generation is executed
   - Then no files under canonical story paths are modified

2) Draft set manifest completeness
   - Given a produced draft set
   - When `manifest.json` is loaded
   - Then it includes `draft_set_id`, `idea_id`, `created_at`, and `planes`
