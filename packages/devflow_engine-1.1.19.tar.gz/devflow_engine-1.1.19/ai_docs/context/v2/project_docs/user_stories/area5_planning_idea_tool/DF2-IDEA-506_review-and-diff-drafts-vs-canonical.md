story_uuid: 4b91a0d2-a8b7-4ee5-98c7-54689b1636b2
story_id: DF2-IDEA-506
title: Review workflow: show diffs between draft stories and canonical contracts
required_planes: [api, ui]

CONTRACT FORMATION MODE: implementation is irrelevant; do not compare against current code/UI. Define user-expected outcomes and test oracles only.

## Intent
As a DevFlow user,
I want to review how a draft story set differs from current canonical contracts,
so that I can understand impact before promotion and avoid unintended contract changes.

## Scope
- Provide a command to compare a draft set to canonical stories.
- Summarize adds/changes/deletes.
- Produce human-readable output; machine-readable output is a plus.

## Out of scope
- Full semantic diffing; text-based diff is acceptable.
- UI beyond CLI output.

## Contract
### User-visible behavior
- Command: `devflow idea drafts diff --idea <idea_id> --draft-set <draft_set_id>`
- Optional inputs:
  - `--format text|json`
  - `--canonical <path>` (override canonical root)
  - `--open` (optional: open diff in pager/editor)
- Output MUST include:
  - a summary count: added/modified/unchanged/conflicting
  - per-story entries showing which canonical story is being compared (or “new”)
  - for modified items, show a readable diff (unified diff or similar)

### Matching strategy
- The tool MUST define a deterministic mapping from draft stories to canonical stories, using at least one of:
  - explicit `story_id` fields
  - stable titles + plane
  - a stored mapping in the draft manifest
- If no match can be found, the story is considered “new” and reported as such.

plane_oracles:
- plane: api
  oracle: "A draft set can be compared against canonical and yields a structured comparison result." 
  anchor: "api:draft-diff(compare_draft_set_to_canonical)"
- plane: ui
  oracle: "CLI output enables a human to decide whether to promote, without manually hunting file paths." 
  anchor: "cli:devflow idea drafts diff output"

## Acceptance criteria
- MUST provide a diff/review command for drafts vs canonical.
- MUST display adds/changes and identify unmatched drafts.
- MUST have deterministic matching rules and document them.

## Contract test specs
1) Summary output
   - Given a canonical story set and a draft set
   - When diff runs
   - Then output contains counts for added/modified (and optionally unchanged)

2) Deterministic matching
   - Given the same canonical and draft inputs
   - When diff runs twice
   - Then the same draft stories map to the same canonical targets
