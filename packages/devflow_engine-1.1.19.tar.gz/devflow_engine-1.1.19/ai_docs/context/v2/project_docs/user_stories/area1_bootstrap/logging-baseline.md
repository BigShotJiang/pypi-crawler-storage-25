story_uuid: ec5d054a-eaad-4ec5-a645-b4aad69fc327
story_id: DF2-BOOT-004
title: Logging baseline for devflow_engine (consistent formatting + level controls)
required_planes: [auth, api, ui, integrations, ops]

CONTRACT FORMATION MODE: implementation is irrelevant; do not compare against current code/UI. Define user-expected outcomes and test oracles only.

## Intent
Provide consistent, controllable logging suitable for local development and future automation (CI, agents, batch runs).

## Logging contract
- Log level is configurable (default + override via env/CLI)
- Logs are emitted once (no duplicate handlers)
- Log format is predictable (includes at least timestamp or level + logger name + message)

plane_oracles:
- plane: auth
  oracle: "Logs MUST NOT emit secret values at INFO level by default; sensitive config values are redacted in logs and CLI summaries."
  anchor: "logging:redaction policy"
- plane: api
  oracle: "A logger can be obtained from the engine and emits messages at the configured level."
  anchor: "python:import devflow_engine.core.logging"
- plane: ui
  oracle: "CLI output remains readable; logging to stderr does not corrupt primary stdout outputs for commands like `version`."
  anchor: "cli:version stdout single-line"
- plane: integrations
  oracle: "Logging can be configured for JSON-friendly output mode (or at minimum stable key/value structure) to support log aggregation later, without requiring external services."
  anchor: "logging:format mode switch"
- plane: ops
  oracle: "Operators can raise verbosity via env or CLI (e.g., DEBUG) to troubleshoot without code changes."
  anchor: "env:DEVFLOW_ENGINE_LOG_LEVEL"

## Acceptance criteria
- MUST provide a default log level that does not spam (e.g., INFO or WARNING) and is documented.
- MUST allow overriding log level via environment variable.
- MUST allow overriding log level via CLI flag (if CLI supports runtime config overrides).
- MUST NOT emit duplicate log lines for a single logging call in normal execution.
- MUST NOT print stack traces for normal, handled errors; stack traces are allowed only at DEBUG (or when explicitly requested).

## Contract test specs
1) Log level override via env
   - Set: `DEVFLOW_ENGINE_LOG_LEVEL=DEBUG`
   - Run: `uv run devflow-engine doctor`
   - Expect: debug-level lines are present (or at minimum more verbose than default)

2) No duplicates
   - Run a command that logs a single known message once
   - Expect: that message appears exactly once in stderr

3) CLI stdout cleanliness
   - Run: `uv run devflow-engine version`
   - Expect: stdout contains only the version line
   - Expect: any logs (if emitted) go to stderr
