story_uuid: f2c79b19-0f65-4c6a-90a6-79b31b8a3c1d
story_id: US-8.3
title: US-8.3 error-queue dedupe-fingerprints
required_planes: [api, ops]

CONTRACT FORMATION MODE: implementation is irrelevant; do not compare against current code/UI. Define user-expected outcomes and test oracles only.

plane_oracles:
- plane: api
  oracle: "The engine exposes deterministic programmatic behavior and data models required by US-8.3_error-queue_dedupe-fingerprints (inputs/outputs and persistence semantics)."
  anchor: "api:US-8.3_error-queue_dedupe-fingerprints"
- plane: ops
  oracle: "Operational side effects for US-8.3_error-queue_dedupe-fingerprints are deterministic and documented (files/dirs created, idempotency, and safe failure modes)."
  anchor: "docs:user_story/US-8.3_error-queue_dedupe-fingerprints"
# US-8.3 — Error Queue: dedupe + fingerprints

## User story
As a DevFlow operator,
I want duplicate errors automatically grouped and de-duplicated,
so that repeated failures don’t spam the queue and I can focus on unique problems.

## Scope
- Define fingerprint generation.
- Define dedupe behavior on ingest.
- Define how duplicates link to a canonical task.

## Out of scope
- ML-based clustering.
- Cross-project dedupe (unless explicitly enabled).

## Contract
### Functional requirements
1. **Fingerprint field**
   - Every error task MUST have `fingerprint` (string, stable).
   - Fingerprint MUST be deterministic for a given “same underlying problem”.

2. **Fingerprint algorithms (by source)**
   - **Execution-derived** tasks:
     - fingerprint inputs SHOULD include:
       - `project_id`
       - `source_kind='execution'`
       - `error_type` (or `source`)
       - normalized `message` (strip IDs/timestamps)
       - optional: top-N stack frames (normalized)
     - Must avoid secrets; sanitize before hashing.
   - **GitHub-derived** tasks:
     - fingerprint SHOULD include:
       - `project_id`
       - `source_kind='github'`
       - repository full name
       - issue number (or stable issue node_id)

3. **Dedupe on ingest**
   - On creating an error task, the system MUST:
     - check for an existing **non-terminal** task with same `(project_id, fingerprint)`.
   - If found:
     - increment `occurrence_count`
     - append an event referencing the new occurrence
     - do NOT create a new top-level task

4. **Explicit duplicate linking**
   - The system MUST support marking task A as duplicate of task B.
   - When A is marked duplicate:
     - `A.status='duplicate'`
     - `A.duplicate_of_error_task_id = B.error_task_id`
     - append events to both A and B

5. **Terminal behavior**
   - If the only matching task is terminal (`closed|ignored|duplicate`) then the system MAY:
     - create a new task (reoccurrence) and add an event referencing the previous terminal task(s)
     - OR reopen the most recent task if policy says so (future policy story)

### Data requirements
- `error_tasks` additions:
  - `fingerprint TEXT NOT NULL`
  - `occurrence_count INTEGER NOT NULL DEFAULT 1`
  - `duplicate_of_error_task_id TEXT NULL`
- Unique index (recommended):
  - `(project_id, fingerprint)` filtered to non-terminal statuses (if DB supports partial indexes)
  - otherwise enforce in application logic with transaction + recheck.

### Observability requirements
- Emit logs on dedupe decisions:
  - `event='error_task.deduped'` with `fingerprint`, `canonical_error_task_id`.

## Acceptance criteria
- [ ] Re-ingesting the same execution failure increments `occurrence_count` and does not create a new task.
- [ ] GitHub issues do not create duplicates when re-seen by the watcher.
- [ ] Explicit duplicate linking sets status + linkage correctly.

## Test plan
- Unit: fingerprint normalization produces stable hashes.
- Integration: ingest same error twice → one task with `occurrence_count=2`.
- Integration: mark duplicate → verify events and linkage.
