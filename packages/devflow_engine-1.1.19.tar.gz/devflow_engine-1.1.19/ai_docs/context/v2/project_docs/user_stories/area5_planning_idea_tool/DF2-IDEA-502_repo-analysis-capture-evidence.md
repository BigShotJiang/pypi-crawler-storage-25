story_uuid: 3db6d4a5-1a89-45c3-b8ba-f690f02039d3
story_id: DF2-IDEA-502
title: "devflow idea analyze" runs repo analysis and captures evidence with anchors
required_planes: [api, ui, ops]

CONTRACT FORMATION MODE: implementation is irrelevant; do not compare against current code/UI. Define user-expected outcomes and test oracles only.

## Intent
As a DevFlow user,
I want to run a repository analysis for an idea,
so that I can ground planning and future story drafts in verifiable evidence (files, symbols, commands, observations) rather than vibes.

## Scope
- Add a command to analyze the repo in the context of an idea.
- Persist analysis results as immutable-ish artifacts with provenance.
- Use “anchors” that point to specific evidence locations (file paths, line ranges, commits, tool outputs).

## Out of scope
- Perfect static analysis for all languages.
- LSP/server-side indexing.
- Internet research (analysis is local to repo by default).

## Contract
### User-visible behavior
- Command: `devflow idea analyze --idea <idea_id>`
- Optional inputs:
  - `--ref <git_ref>` (defaults to current working tree state; policy must be explicit)
  - `--depth <shallow|standard|deep>`
  - `--include <glob>` / `--exclude <glob>`
- Outputs:
  - prints an `analysis_id`
  - prints path to the analysis artifact directory
  - prints a short summary (e.g., languages detected, key directories, test runner hints)

### Evidence artifact requirements
- The analysis MUST be written under the idea workspace, e.g.:
  - `.devflow/ideas/<idea_id>/analysis/<analysis_id>/`
- The artifact directory MUST include:
  - a machine-readable summary (e.g., `analysis.json`)
  - a human-readable report (e.g., `report.md`)
  - a provenance record including at least:
    - `analysis_id`
    - `idea_id`
    - `repo_root`
    - `git_ref` (commit SHA when available)
    - `created_at` (UTC)
    - tool version/build id (when available)

### Anchors
- Evidence items MUST be addressable by anchors that are stable enough to re-check later.
- Anchor formats MUST support at least:
  - `fs:<path>`
  - `fs:<path>#L<start>-L<end>`
  - `git:<sha>:<path>#L<start>-L<end>` (when git is available)
  - `cmd:<command>` with captured stdout/stderr references (not raw secrets)

### Privacy/security
- Analysis artifacts MUST NOT include secrets by default.
- If the repo contains files matching common secret patterns, the analyzer SHOULD redact values and record that redaction occurred.

plane_oracles:
- plane: api
  oracle: "Analysis results can be loaded programmatically and include provenance + a collection of evidence items with anchors."
  anchor: "api:idea-analysis(load_analysis, list_evidence)"
- plane: ui
  oracle: "CLI output makes it easy to locate and read the analysis report without opening the codebase in an IDE."
  anchor: "cli:devflow idea analyze stdout"
- plane: ops
  oracle: "Running analysis in an offline environment produces artifacts deterministically in the local idea workspace."
  anchor: "ops:offline-run"

## Acceptance criteria
- MUST provide `devflow idea analyze` that produces an analysis artifact directory.
- MUST persist provenance including git ref/commit when available.
- MUST persist evidence items with anchors.
- MUST provide at least one human-readable report.
- MUST avoid leaking secrets in stored artifacts by default.

## Contract test specs
1) Analysis creates artifacts
   - Given an initialized idea
   - When `devflow idea analyze --idea <idea_id>` is executed
   - Then `.devflow/ideas/<idea_id>/analysis/<analysis_id>/` exists
   - And `analysis.json` exists and includes provenance fields
   - And `report.md` exists

2) Anchors are present
   - Given `analysis.json`
   - When evidence items are inspected
   - Then each item includes an `anchor` string
   - And at least one anchor references a real repo file path

3) Secret handling
   - Given a fixture repo containing a fake secret in a file
   - When analysis runs
   - Then the stored artifact does not contain the raw secret value
   - And the report indicates redaction occurred (exact wording flexible)
