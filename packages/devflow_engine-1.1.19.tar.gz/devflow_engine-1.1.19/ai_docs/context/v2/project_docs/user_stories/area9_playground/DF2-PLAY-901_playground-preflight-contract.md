# DF2-PLAY-901 — Playground: Preflight contract and runner

story_uuid: a30825b4-52f6-485e-af0f-ab994e0d3140
story_id: DF2-PLAY-901
title: Playground: Preflight contract and runner
required_planes: [ops, api]

CONTRACT FORMATION MODE: implementation is irrelevant; do not compare against current code/UI. Define user-expected outcomes and test oracles only.

plane_oracles:
- plane: ops
  oracle: "Preflight produces a deterministic pass/fail result with actionable diagnostics and remediation hints, without executing the main scenarios when failing."
  anchor: "command:devflow play preflight --json"

- plane: api
  oracle: "Preflight result is persisted as a run artifact and is retrievable by run id for downstream review and error ingestion."
  anchor: "sqlite:.devflow/execution.sqlite artifacts(type=playground.preflight)"

## Story statement
As a developer, I want DevFlow to run a structured preflight before playground scenarios, so that I catch environment/config/migration problems early with clear remediation.

## Outcome oracle (user-observable)
- A user can run `devflow play preflight` and receive a structured report that either:
  - PASS: indicates safe to proceed, or
  - FAIL: explains what failed and what to do next.

## Preconditions
- A project repo exists with `.devflow/` initialized.

## Steps
1. User runs `devflow play preflight`.
2. DevFlow executes the configured checks.
3. DevFlow outputs a human summary and (optionally) JSON.

## Pass/fail conditions
- Pass if all required checks pass.
- Fail if any required check fails.

## Acceptance criteria
1. MUST run preflight checks in a deterministic order and report a stable summary.
2. MUST provide a machine-readable JSON output (`--json`) with per-check results.
3. MUST NOT run playground scenarios when preflight fails.
4. MUST persist the preflight result as an artifact linked to the current run.

## Non-goals
- Not defining the full catalog of checks in this story (that is configured per project).

## Contract test spec (Given/When/Then)
- Given a repo with a failing required preflight check
- When I run `devflow play preflight --json`
- Then the command exits non-zero, outputs a JSON report with the failing check, and no scenario run is started
- And the report is persisted in `.devflow/execution.sqlite` as a preflight artifact
