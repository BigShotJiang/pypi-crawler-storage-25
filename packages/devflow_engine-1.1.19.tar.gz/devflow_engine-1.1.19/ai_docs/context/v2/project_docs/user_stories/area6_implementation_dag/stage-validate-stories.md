story_uuid: 9f5ab7a5-4bf9-4e72-b88f-6d4bbfd7c616
story_id: DF2-IMPL-610
title: Stage: ValidateStories (canonicalize + validate story contracts; auto-repair until pass)
required_planes: [auth, api, ui, integrations, ops]

CONTRACT FORMATION MODE: implementation is irrelevant; do not compare against current code/UI. Define user-expected outcomes and test oracles only.

## Intent
Provide a deterministic, autonomous gate that ensures story contract markdown is canonical, parseable, and complete before the implementation DAG proceeds.

## User value
As a developer, I can trust that downstream stages (Normalize/TestDesign/Red/Green/Review) are operating on validated story contracts without silent skips, missing planes, or unstable anchors.

## Scope
- Input: one or more story markdown files (canonical story locations).
- Output:
  - validation report (human + JSON)
  - repaired story files when needed
  - persisted repair provenance (what changed + evidence)

## Out of scope
- Implementing any feature code.
- Writing tests for product behavior (that’s TestDesign/Red).

plane_oracles:
- plane: auth
  oracle: "Story validation and auto-repair must not require secrets and must not call external services by default."
  anchor: "script:scripts/validate_stories.py"
- plane: api
  oracle: "Validator emits a machine-readable JSON report with issue codes and stable file/line references when possible."
  anchor: "script:scripts/validate_stories.py --json"
- plane: ui
  oracle: "CLI output is concise and actionable: it names the failing story file(s) and issue(s) and summarizes repairs performed."
  anchor: "cli:validate-stories summary"
- plane: integrations
  oracle: "Auto-repair uses only local repo + docs as evidence; it does not reach out to external APIs."
  anchor: "ops:offline gate"
- plane: ops
  oracle: "Gate is deterministic: given the same repo state, it produces the same validation result and the same repairs (if needed)."
  anchor: "ops:validate-stories determinism"

## Acceptance criteria
- MUST ensure `scripts/validate_stories.py` exists and can run from a fresh checkout without installing the package.
- MUST validate canonical story files with hard gates:
  - no silent skips (canonical story files must contain ≥1 parseable story block)
  - contract formation mode line present
  - required_planes + plane_oracles complete (oracle+anchor per required plane)
  - anchor format is a stable address scheme
- If validation fails, MUST autonomously repair until validation passes.
  - No halt / no ask.
  - No placeholders/stubs/TODOs introduced to satisfy validation.
  - Repair is best-effort evidence-based; when ambiguous, make deterministic ranked assertions and proceed.
- MUST persist a repair provenance artifact listing:
  - files changed
  - fields changed
  - sources consulted
  - assertions made + confidence

## Contract test specs
1) Gate runs and produces a JSON report
   - Given a repo with canonical story files
   - When ValidateStories runs
   - Then it emits a JSON report with issue_count and issues[] entries

2) Auto-repair until pass
   - Given at least one story file is non-canonical or missing required fields
   - When ValidateStories runs
   - Then it repairs the story file(s) and re-runs validation until passing
   - And it persists a repair provenance artifact
