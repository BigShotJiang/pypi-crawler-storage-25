# DF2-PLAY-906 — Playground: Preflight/scenarios respect story plane anchors

story_uuid: 54a5cdca-51a4-49fb-b9da-303297432917
story_id: DF2-PLAY-906
title: Playground: Preflight/scenarios respect story plane anchors
required_planes: [ops, api]

CONTRACT FORMATION MODE: implementation is irrelevant; do not compare against current code/UI. Define user-expected outcomes and test oracles only.

plane_oracles:
- plane: ops
  oracle: "Given a story with required planes, DevFlow selects the appropriate preflight checks and scenario sets for those planes (e.g., ops checks for ops plane, integration smoke for integrations plane)."
  anchor: "command:devflow play plan --story <story_uuid> --json"

- plane: api
  oracle: "The computed plan is persisted and reproducible (same story contract hash yields the same selected check/scenario set)."
  anchor: "sqlite:.devflow/execution.sqlite artifacts(type=playground.plan)"

## Story statement
As a developer, I want playground execution to be plane-aware, so that verification matches what the story actually claims (and avoids greenwashing).

## Outcome oracle (user-observable)
- A CLI command shows the derived plan (checks + scenarios) for a story.

## Preconditions
- Story contracts include `required_planes` and `plane_oracles` anchors.

## Steps
1. Run `devflow play plan --story <story_uuid>`
2. Run preflight and scenario batch according to the plan.

## Acceptance criteria
1. MUST compute a plan that includes at least one verification item per required plane.
2. MUST allow a project to override mappings (per config) without changing story contracts.
3. MUST persist the plan as an artifact linked to the story run.
4. MUST NOT claim coverage for a plane unless a corresponding check/scenario is actually scheduled.

## Non-goals
- Not implementing the full coverage gate script here.

## Contract test spec (Given/When/Then)
- Given a story requiring [api, integrations]
- When I run `devflow play plan --story <uuid> --json`
- Then the plan includes api verification and integration verification items
- And the plan is persisted as an artifact and remains stable for the same contract hash
