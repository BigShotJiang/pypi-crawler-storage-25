story_uuid: 62f51fda-a067-489d-80c1-40b26b443dcf
story_id: DF2-BOOT-001
title: Repo bootstrap for devflow_engine (uv-managed project + Typer skeleton)
required_planes: [auth, api, ui, integrations, ops]

CONTRACT FORMATION MODE: implementation is irrelevant; do not compare against current code/UI. Define user-expected outcomes and test oracles only.

## Intent
Create a minimal, repeatable repository bootstrap so any contributor can set up the `devflow_engine` Python package and run the CLI locally using `uv`.

## Scope
- Packaging skeleton is present and discoverable (`pyproject.toml`, `src/` layout)
- `uv` can create and sync a virtual environment from the repo root
- A Typer-based CLI entrypoint exists and is invocable via `uv run`

## Out of scope
- Any production integrations
- Any real auth mechanisms
- Feature-complete CLI commands

plane_oracles:
- plane: auth
  oracle: "Bootstrap does not require secrets or credentials; first-run setup must succeed without prompting for tokens/keys."
  anchor: "docs:first-run"
- plane: api
  oracle: "A CLI entrypoint can be executed and returns help text with exit code 0."
  anchor: "cli:uv run devflow-engine --help"
- plane: ui
  oracle: "CLI help output includes the command name and at least one subcommand (or default command) so a human can discover functionality."
  anchor: "cli:--help output"
- plane: integrations
  oracle: "No external network calls are required for bootstrap beyond standard dependency resolution; the CLI must not attempt to contact third-party APIs on `--help`."
  anchor: "cli:devflow-engine --help (no network)"
- plane: ops
  oracle: "A clean checkout can be set up with a single deterministic command sequence (documented) and produces a runnable environment."
  anchor: "docs:setup commands"

## Acceptance criteria
- MUST provide a `uv`-managed Python project such that `uv sync` completes successfully from the repo root.
- MUST provide a `src/`-layout package importable as `devflow_engine`.
- MUST provide a CLI entrypoint executable as `uv run devflow-engine --help`.
- MUST return exit code 0 for `devflow-engine --help`.
- MUST NOT require any secrets, env vars, or local system configuration beyond installing `uv`.
- MUST NOT perform network calls when running `devflow-engine --help` (beyond what `uv sync` already did during install).

## Contract test specs
1) Environment bootstrap
   - Given a fresh clone
   - When the tester runs `uv sync`
   - Then the command exits 0
   - And a virtual environment is created/updated

2) CLI availability
   - Given dependencies are synced
   - When the tester runs `uv run devflow-engine --help`
   - Then the command exits 0
   - And stdout contains a usage/help header including `devflow-engine`

3) Import smoke test
   - Given dependencies are synced
   - When the tester runs `uv run python -c "import devflow_engine; print(devflow_engine.__name__)"`
   - Then stdout equals `devflow_engine`
