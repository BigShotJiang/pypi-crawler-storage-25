story_uuid: 5fbbd973-56e2-4b9d-afae-e00e1524612a
story_id: DF2-IMPL-606
title: Stage: GitCommit(GREEN) (record a clean, gated commit after Green)
required_planes: [auth, api, ui, integrations, ops]

CONTRACT FORMATION MODE: implementation is irrelevant; do not compare against current code/UI. Define user-expected outcomes and test oracles only.

## Intent
After Green passes, create a git commit that captures the minimal change set that makes tests and gates pass.

## User value
As a developer, I get a reliable checkpoint (“GREEN commit”) that can be reviewed, bisected, or reverted independently of later refactors.

## Scope
- Preconditions:
  - Green stage succeeded
  - Working tree contains changes relevant to implementing Green
- Behavior:
  - verify working tree is in an acceptable state (no unresolved conflicts)
  - create a commit with a standardized message/metadata
  - attach references to run ids/artifacts (as commit message footer or git notes)

## Out of scope
- Pushing to remotes.
- Branch creation/management policies.

plane_oracles:
- plane: auth
  oracle: "Commit creation uses local git only; it must not require GitHub/GitLab auth."
  anchor: "git:local commit"
- plane: api
  oracle: "The commit stage refuses to run if Green did not succeed, preventing bad checkpoints."
  anchor: "api:commit_green requires green_result.status=success"
- plane: ui
  oracle: "CLI prints the created commit hash and the commit message subject line."
  anchor: "cli:commit green output"
- plane: integrations
  oracle: "Commit metadata references the Green artifact id so external review tooling can link code to run evidence."
  anchor: "git:commit footer includes green_artifact_id"
- plane: ops
  oracle: "Commit stage is idempotent for a given run: rerunning it does not create duplicate commits if the same tree is already committed."
  anchor: "ops:commit idempotency"

## Acceptance criteria
- MUST require Green stage success before committing.
- MUST create exactly one commit for the Green checkpoint.
- MUST use a standardized commit subject prefix, e.g., `GREEN:`.
- MUST include machine-parsable footer metadata linking:
  - run id
  - green artifact id (or path)
- MUST fail with actionable instructions if there are no changes to commit.

## Contract test specs
1) Guard on Green success
   - Given Green result status is failure
   - When GitCommit(GREEN) is invoked
   - Then it fails fast with an error mentioning Green precondition

2) Commit metadata
   - Given Green succeeded and there are staged or stageable changes
   - When the stage creates the commit
   - Then `git show -1` contains subject starting with `GREEN:`
   - And contains footer lines `DevFlow-Run:` and `DevFlow-Green-Artifact:`

3) Idempotency
   - Given the stage has already created a GREEN commit for the current tree
   - When run again
   - Then no new commit is created (or the stage reports “already committed”) and returns success
