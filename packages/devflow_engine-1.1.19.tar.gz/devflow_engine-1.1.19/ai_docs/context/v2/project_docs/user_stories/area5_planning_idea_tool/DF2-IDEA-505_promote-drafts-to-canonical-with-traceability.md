story_uuid: 3f5fd707-3cdd-4160-9ce5-9424f8ee9db8
story_id: DF2-IDEA-505
title: Promote a draft story set to canonical contracts (with checks + traceability)
required_planes: [api, ui, ops]

CONTRACT FORMATION MODE: implementation is irrelevant; do not compare against current code/UI. Define user-expected outcomes and test oracles only.

## Intent
As a DevFlow user,
I want to promote a reviewed draft story set into the canonical user story contract set,
so that the project’s authoritative requirements update intentionally, with an audit trail back to the idea and evidence.

## Scope
- Provide a promotion command that moves/copies selected draft stories into canonical locations.
- Require explicit user confirmation and include safety checks.
- Record traceability metadata linking canonical stories to the originating idea/draft set.

## Out of scope
- Git commit automation (optional future).
- Multi-user approvals.

## Contract
### User-visible behavior
- Command: `devflow idea promote --idea <idea_id> --draft-set <draft_set_id>`
- Optional inputs:
  - `--dest <path>` (canonical destination root; defaults to DevFlow v2 canonical path)
  - `--dry-run`
  - `--select <pattern|list>` (promote a subset)
  - `--force` (only to override non-destructive conflicts; default must be safe)
- Outputs:
  - list of files that would be created/updated
  - link/reference to traceability record

### Safety checks
- By default, promotion MUST be non-destructive:
  - if a destination file exists, the tool MUST refuse unless `--force` is provided (or an explicit merge policy is documented).
- Promotion MUST validate that the draft set manifest exists and is well-formed.
- Promotion MUST support `--dry-run` that performs all checks and prints the change plan without writing.

### Canonical writing
- Promoted stories MUST end up in the canonical contract set (see DF2-STORY-401), either:
  - embedded into the canonical markdown, or
  - written as referenced artifacts under `.../user_stories/**` and linked from the canonical index.
- The exact canonical representation is a product decision, but it MUST be deterministic and discoverable.

### Traceability
- Each promoted canonical story MUST include traceability metadata linking back to:
  - `idea_id`
  - `draft_set_id`
  - `source_analysis_id` (when available)
  - evidence anchors used (or a pointer to them)

plane_oracles:
- plane: api
  oracle: "Promotion produces deterministic canonical files and records traceability to idea/draft provenance." 
  anchor: "api:promoter(draft_set→canonical)"
- plane: ui
  oracle: "Dry-run shows an explicit plan; real run prints created/updated paths and how to revert." 
  anchor: "cli:devflow idea promote --dry-run"
- plane: ops
  oracle: "Promotion is safe by default: no overwrites without explicit flags, enabling use in CI/pre-commit contexts." 
  anchor: "ops:safe-defaults"

## Acceptance criteria
- MUST provide a promotion command for draft sets.
- MUST support `--dry-run`.
- MUST be non-destructive by default (no overwrites).
- MUST update canonical story contracts in a deterministic, discoverable way.
- MUST write/attach traceability metadata for each promoted story.

## Contract test specs
1) Dry-run does not write
   - Given an idea with a draft set
   - When `devflow idea promote --dry-run` is executed
   - Then no canonical files are changed
   - And the output enumerates planned file operations

2) Refuse overwrites by default
   - Given a destination canonical file path that already exists
   - When promotion is executed without `--force`
   - Then the command fails with a clear conflict message

3) Traceability present
   - Given a promoted canonical story
   - When the story is inspected
   - Then it contains or references `idea_id` and `draft_set_id`
