story_uuid: 8f3c9c8d-f81c-4a36-9bd0-b0b74843b63e
story_id: US2.8
title: US2.8 project import (blank repo init templates)
required_planes: [ui, ops]

CONTRACT FORMATION MODE: implementation is irrelevant; do not compare against current code/UI. Define user-expected outcomes and test oracles only.

plane_oracles:
- plane: ui
  oracle: "A user can create a new blank repo with a template type and DevFlow prints the created repo root + project_id."
  anchor: "cli:devflow project import --init"
- plane: ops
  oracle: "Repo initialization is deterministic, creates the expected minimal template files for the chosen type, and bootstraps .devflow without external network calls."
  anchor: "fs:template-skeleton + .devflow bootstrap"

# US2.8 — `devflow project import --init` creates a new blank repo from a template and registers it

## Story
As a developer,
I want DevFlow to create a new blank repository using a specified template,
so that I can start a new project with the correct baseline structure and DevFlow tracking.

## Command surface
- `devflow project import <dest_dir> --init <template>`

Where `<template>` is one of:
- `python`
- `typescript`
- `next`
- `react-native`

## Acceptance criteria
1. **Create destination repo**
   - If `<dest_dir>` does not exist, it is created.
   - If it exists and is non-empty, the command fails unless `--force` is provided.

2. **Initialize git repository**
   - `git init` is run in `<dest_dir>`.
   - A minimal initial commit may be created, but must be deterministic and not depend on network.

3. **Template skeletons**
   - `python` creates at minimum:
     - `README.md`
     - `pyproject.toml`
     - `src/<package>/__init__.py` (package name derived deterministically from dest dir)
   - `typescript` creates at minimum:
     - `README.md`
     - `package.json`
     - `tsconfig.json`
     - `src/index.ts`
   - `next` creates at minimum:
     - `README.md`
     - `package.json`
     - `next.config.js` (or `.mjs`)
     - `app/page.tsx` (or the chosen Next baseline)
   - `react-native` creates at minimum:
     - `README.md`
     - `package.json`
     - `app.json` (or equivalent)
     - `src/App.tsx` (or `App.tsx` at repo root; policy must be consistent)

4. **DevFlow bootstrap**
   - The repo contains `.devflow/` with minimum required structure:
     - `.devflow/execution.sqlite`
     - `.devflow/config.yaml` (or `.toml`, canonical)

5. **Register as active project**
   - Same registry upsert behavior as US2.7.
   - Since there is no GitHub remote by default, `remote_url` may be null; workspace hash uses a deterministic local identity.

## Non-goals
- Running `npm install`, `uv sync`, `create-next-app`, `expo init`, or other network-heavy bootstrap.
- Creating the GitHub remote repository via API.

## Determinism notes
- All file contents are minimal, stable, and do not include timestamps unless explicitly part of the contract.
