story_uuid: 7df199c2-2c0d-4fd1-9795-5c47a1e3016b
story_id: US-3.2
title: US-3.2 execution-store schema core-tables
required_planes: [api, ops]

CONTRACT FORMATION MODE: implementation is irrelevant; do not compare against current code/UI. Define user-expected outcomes and test oracles only.

plane_oracles:
- plane: api
  oracle: "The engine exposes deterministic programmatic behavior and data models required by US-3.2_execution-store_schema_core-tables (inputs/outputs and persistence semantics)."
  anchor: "api:US-3.2_execution-store_schema_core-tables"
- plane: ops
  oracle: "Operational side effects for US-3.2_execution-store_schema_core-tables are deterministic and documented (files/dirs created, idempotency, and safe failure modes)."
  anchor: "docs:user_story/US-3.2_execution-store_schema_core-tables"
# US-3.2 — Execution Store: core schema (runs, nodes, artifacts, errors, review_packets)

## User story
As a DevFlow developer/operator,
I want a normalized SQLite schema capturing runs, node executions, artifacts, errors, and review packets,
so that the engine can persist execution results and downstream tooling can query and display them.

## Why
- Provides durable record of what happened during a run.
- Enables drill-down from run → node → tool calls → outputs/artifacts.
- Makes failures, retries, and review workflows auditable.

## Scope
- Define and create core tables:
  - `runs`
  - `nodes`
  - `artifacts`
  - `errors`
  - `review_packets`
- Define primary/foreign keys, timestamps, and essential indexes.
- Document constraints and required fields.

## Out of scope
- Materialized views or advanced analytics.
- Automatic pruning/retention.
- Binary artifact storage inside SQLite (store paths/URIs + metadata instead).

## Contract
### General requirements
- All timestamps are UTC and stored in ISO-8601 text or integer epoch (pick one and standardize).
- Prefer `TEXT` UUIDs/ULIDs for ids.
- All tables include `created_at` and `updated_at` (or equivalent).
- Foreign keys enforced (`PRAGMA foreign_keys=ON`).

### Table: `runs`
Represents a single DAG execution attempt.

**Required columns (minimum):**
- `run_id` (PK, TEXT)
- `dag_id` (TEXT) — stable identifier for the DAG definition
- `dag_version` (TEXT, nullable) — optional hash/version of DAG definition
- `status` (TEXT) — enum-like: `queued|running|succeeded|failed|canceled`
- `started_at` (nullable)
- `finished_at` (nullable)
- `root_correlation_id` (TEXT) — ties logs and store records together
- `config_json` (TEXT, nullable) — sanitized run config (no secrets)
- `created_at`, `updated_at`

**Indexes:**
- `runs(status, created_at)`
- `runs(dag_id, created_at)`

### Table: `nodes`
Represents execution of a node within a run.

**Required columns (minimum):**
- `node_exec_id` (PK, TEXT)
- `run_id` (FK → runs.run_id)
- `node_id` (TEXT) — stable node identifier within the DAG
- `node_name` (TEXT, nullable)
- `status` (TEXT) — `queued|running|succeeded|failed|skipped|canceled`
- `attempt` (INTEGER) — attempt number (1-based)
- `started_at` (nullable)
- `finished_at` (nullable)
- `correlation_id` (TEXT) — node-level correlation id
- `input_json` (TEXT, nullable) — sanitized, size-bounded
- `output_json` (TEXT, nullable) — sanitized, size-bounded
- `created_at`, `updated_at`

**Constraints & indexes:**
- Unique constraint: `(run_id, node_id, attempt)`
- Index: `nodes(run_id, status)`
- Index: `nodes(run_id, node_id)`

### Table: `artifacts`
References externally stored outputs (files, logs, images, tool IO snapshots).

**Required columns (minimum):**
- `artifact_id` (PK, TEXT)
- `run_id` (FK → runs.run_id)
- `node_exec_id` (nullable FK → nodes.node_exec_id)
- `kind` (TEXT) — e.g., `log|file|json|image|tool_trace|review_packet`
- `uri` (TEXT) — file path or URI
- `content_type` (TEXT, nullable)
- `byte_size` (INTEGER, nullable)
- `sha256` (TEXT, nullable)
- `metadata_json` (TEXT, nullable)
- `created_at`, `updated_at`

**Indexes:**
- `artifacts(run_id, kind)`
- `artifacts(node_exec_id)`

### Table: `errors`
Captures errors at run/node/tool boundaries.

**Required columns (minimum):**
- `error_id` (PK, TEXT)
- `run_id` (FK → runs.run_id)
- `node_exec_id` (nullable FK → nodes.node_exec_id)
- `scope` (TEXT) — `run|node|tool|system`
- `error_type` (TEXT) — class/category
- `message` (TEXT)
- `stacktrace` (TEXT, nullable)
- `cause_json` (TEXT, nullable)
- `correlation_id` (TEXT)
- `created_at`

**Indexes:**
- `errors(run_id, created_at)`
- `errors(node_exec_id, created_at)`

### Table: `review_packets`
Stores human/AI review request/response payload references.

**Required columns (minimum):**
- `review_packet_id` (PK, TEXT)
- `run_id` (FK → runs.run_id)
- `node_exec_id` (nullable FK → nodes.node_exec_id)
- `status` (TEXT) — `pending|approved|rejected|superseded`
- `request_json` (TEXT) — sanitized request payload
- `response_json` (TEXT, nullable) — sanitized response payload
- `created_at`, `updated_at`

**Indexes:**
- `review_packets(run_id, status)`
- `review_packets(node_exec_id)`

## Acceptance criteria
- [ ] Schema matches the above minimum columns and constraints.
- [ ] Foreign keys prevent orphaned `nodes`, `errors`, `artifacts`, `review_packets`.
- [ ] Basic queries are performant on modest run history (e.g., list recent runs; list nodes by run; list errors by run).

## Notes / guidance
- JSON columns are for convenience; keep payloads size-bounded and sanitized.
- For large payloads, store as files in `.devflow/` and reference via `artifacts.uri`.

## Test plan
- Migration/init test: schema created successfully.
- Insert/constraint tests:
  - cannot insert node with unknown run
  - unique `(run_id,node_id,attempt)` holds
- Query tests: list latest 20 runs; get node statuses; fetch errors.
