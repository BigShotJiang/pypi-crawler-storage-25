story_uuid: 1b383a1c-dc23-4a92-ae4b-9e70e91b08e2
story_id: DF2-IMPL-605
title: Stage: Green (implement + green gate: tests, mypy, ruff; self-heal loop)
required_planes: [auth, api, ui, integrations, ops]

CONTRACT FORMATION MODE: implementation is irrelevant; do not compare against current code/UI. Define user-expected outcomes and test oracles only.

## Intent
Implement the production code changes required to satisfy the failing tests, and enforce a “green gate” quality bar before progressing.

## User value
As a developer, I get a predictable definition of done for Green: tests pass and baseline quality tools pass, with automated iteration when possible.

## Scope
- Input: Red stage artifacts (failing tests + failure summary) and upstream Normalize/TestDesign.
- Output:
  - production code changes
  - passing tests
  - passing quality gates:
    - unit/integration tests as configured
    - mypy type checks (if enabled)
    - ruff lint/format (if enabled)
  - a Green stage result containing:
    - tool versions/config references
    - gate outcomes
    - diffs/paths touched

## Self-heal loop
- If a gate fails for a fixable reason (format/lint/type), the stage MAY apply automatic corrections and re-run gates.
- The stage MUST have a max-iteration limit and must stop with an actionable summary.

plane_oracles:
- plane: auth
  oracle: "Green stage MUST NOT require external credentials; it operates on local repo + local tools."
  anchor: "stage:green (offline)"
- plane: api
  oracle: "Green stage success means: all configured gates report pass and the previously failing tests now pass."
  anchor: "artifact:green_result.gates[*].status == pass"
- plane: ui
  oracle: "CLI shows a clear gate table: tests/mypy/ruff each marked pass/fail, plus how many self-heal iterations were attempted."
  anchor: "cli:green gate summary"
- plane: integrations
  oracle: "Quality gates are pluggable via adapters, but surface a uniform result schema (name, command, exit_code, stdout/stderr pointers)."
  anchor: "api:gate_adapter"
- plane: ops
  oracle: "Green stage must be safe: it records every command executed and supports rerunning gates without re-implementing changes."
  anchor: "ops:gate command audit log"

## Acceptance criteria
- MUST re-run the same tests that were used in Red (or a superset) and require they pass.
- MUST run configured quality gates (tests + ruff + mypy, as applicable) and require they all pass.
- MUST support a bounded self-heal loop for:
  - ruff formatting/lint fixes
  - mypy-driven type fixes where straightforward
- MUST stop after max iterations with:
  - the last gate outputs
  - a summary of remaining errors
  - the files involved
- MUST persist the Green result artifact.

## Contract test specs
1) Gate enforcement
   - Given a run where tests pass but ruff fails
   - When Green completes
   - Then stage result is failure (not success)
   - And the failing gate is named in the summary

2) Self-heal bounds
   - Given a persistent mypy failure that cannot be auto-fixed
   - When Green runs
   - Then it stops after max iterations
   - And reports “max iterations reached” plus remaining errors

3) Command auditability
   - Given a Green run
   - When reviewing the Green result artifact
   - Then it contains a list of commands executed (or equivalent structured record) with exit codes
