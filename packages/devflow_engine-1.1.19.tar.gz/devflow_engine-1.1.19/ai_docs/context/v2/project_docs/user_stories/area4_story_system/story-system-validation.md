story_uuid: 5180d3df-30e4-4b7e-b19c-6a40167973ef
story_id: DF2-STORY-404
title: Story contract validation (schema + required sections)
required_planes: [auth, api, ui, integrations, ops]

CONTRACT FORMATION MODE: implementation is irrelevant; do not compare against current code/UI. Define user-expected outcomes and test oracles only.

## Intent
As a DevFlow maintainer, I want automated validation of story contracts so that malformed or incomplete story documents cannot silently enter the canonical set.

## Scope
Validate story documents (canonical and artifact) for:
- Required header keys: `story_uuid`, `story_id`, `title`
- Header format validity (UUID parseable; non-empty strings)
- Presence of key sections:
  - `## Intent`
  - `## Scope`
  - `## Acceptance criteria`
  - `## Contract test specs`
- Optional but encouraged:
  - `required_planes`
  - `plane_oracles`

## Out of scope
- Natural language quality grading
- Enforcing exact phrasing
- Enforcing number of acceptance criteria

plane_oracles:
- plane: auth
  oracle: "Validation runs locally without secrets; it only reads files and emits diagnostics."
  anchor: "validator:local"
- plane: api
  oracle: "Validator returns structured diagnostics (file, line/section if possible, error codes) suitable for CI."
  anchor: "api:validate_stories() -> diagnostics"
- plane: ui
  oracle: "CLI output is readable and actionable, pointing to the specific story and missing/invalid elements."
  anchor: "cli:stories validate"
- plane: integrations
  oracle: "CI can run validation and fail builds on errors."
  anchor: "ci:validate step"
- plane: ops
  oracle: "Validation is deterministic and produces stable error codes/messages for the same inputs."
  anchor: "ops:stable diagnostics"

## Acceptance criteria
- MUST validate all canonical and artifact stories.
- MUST fail validation if any story is missing required header keys.
- MUST fail validation if `story_uuid` is not a valid UUID.
- MUST fail validation if required sections are missing.
- MUST emit per-story diagnostics with enough detail to locate the issue.
- SHOULD allow warnings (non-fatal) for recommended-but-missing fields (e.g., missing `plane_oracles`).

## Contract test specs
1) Missing header key
   - Given a story file missing `story_id`
   - When validation runs
   - Then validation fails
   - And diagnostics include the file path and `MISSING_HEADER_KEY:story_id`

2) Invalid UUID
   - Given a story file with `story_uuid: not-a-uuid`
   - When validation runs
   - Then validation fails
   - And diagnostics include `INVALID_UUID`

3) Missing section
   - Given a story file without `## Acceptance criteria`
   - When validation runs
   - Then validation fails
   - And diagnostics include `MISSING_SECTION:Acceptance criteria`

4) Warning-only case
   - Given a story file with required fields but missing `plane_oracles`
   - When validation runs
   - Then validation succeeds
   - And diagnostics include a warning `MISSING_RECOMMENDED_FIELD:plane_oracles`
