story_uuid: 0c0ffcc0-c56d-4c1c-9bba-75c227f28071
story_id: DF2-STORY-405
title: Contract hash for change detection (stable canonical hashing)
required_planes: [auth, api, ui, integrations, ops]

CONTRACT FORMATION MODE: implementation is irrelevant; do not compare against current code/UI. Define user-expected outcomes and test oracles only.

## Intent
As a DevFlow automation user, I want each story to have a stable `contract_hash` so that tooling can detect meaningful changes to a story contract and trigger re-validation, re-planning, or re-execution.

## Scope
- Compute a `contract_hash` per story
- Hash must be stable across machines and runs
- Hash must change when the story’s contract meaningfully changes
- Hash must not change due to irrelevant formatting differences, if normalization is defined

## Out of scope
- Cryptographic signatures or trust chains
- Hashing of external referenced files beyond story content (unless explicitly included by policy)

plane_oracles:
- plane: auth
  oracle: "Hashing uses only local content; no signing keys required."
  anchor: "hash:local"
- plane: api
  oracle: "The index includes `contract_hash` for every story and documents what content is hashed."
  anchor: "api:index.contract_hash"
- plane: ui
  oracle: "CLI can show contract_hash and highlight changed stories between two states."
  anchor: "cli:stories diff"
- plane: integrations
  oracle: "Downstream tools can use contract_hash as a cache key and change detector."
  anchor: "integration:cache invalidation"
- plane: ops
  oracle: "Hash computation is deterministic and pinned to an explicit algorithm + normalization policy."
  anchor: "ops:hash spec"

## Acceptance criteria
- MUST define the hash algorithm (e.g., `sha256`).
- MUST define the normalization policy used before hashing (e.g., normalize newlines to `\n`, trim trailing whitespace, remove leading BOM).
- MUST specify what text is included in the hash:
  - At minimum: the full story document content (header + body) as normalized
  - OR: explicitly-defined subset (if chosen, must be documented)
- MUST produce identical `contract_hash` on macOS and Linux given identical source content.
- SHOULD provide a mechanism to compute hash for canonical stories and artifact stories consistently.

## Contract test specs
1) Stable across runs
   - Given a fixed story file content
   - When contract_hash is computed twice
   - Then the hash values are identical

2) Stable across OS newline conventions
   - Given the same story content with CRLF vs LF line endings
   - When normalization is applied
   - Then computed contract_hash values are identical

3) Changes on meaningful edits
   - Given a story file
   - When acceptance criteria text is edited
   - Then the contract_hash changes

4) Algorithm declared
   - Given the story index output
   - When the tester inspects metadata
   - Then the hash algorithm and normalization policy are documented (in code docs or index schema docs)
