story_uuid: 8f3d9d34-7d4b-4f7a-9c3c-6e66a86c1f5a
story_id: US2.10
title: Project init builds registry DB, registers all imports, dedupes canon/heresy, and (strict) refactors
required_planes: [ops]

CONTRACT FORMATION MODE: implementation is irrelevant; do not compare against current code/UI. Define user-expected outcomes and test oracles only.

plane_oracles:
- plane: ops
  oracle: "Project init deterministically builds an authoritative registry DB from project-owned files, registers every import, uses an LLM to dedupe duplicates into canonical vs heretical entities, and optionally refactors code to canonical in strict mode."
  anchor: "cli:devflow registry init"

# US2.10 — Project init builds registry DB + dedupe + strict refactor

## Story
As a DevFlow operator,
I want a single project init command that bootstraps the registry DB and canonicalizes the codebase,
so that subsequent commit DAG enforcement can be fully deterministic and block until compliant.

## Deprecations / replacements
- `architecture/inventory.yaml` is deprecated.
- `scripts/validate_inventory.py` is deprecated.
- Any prior architecture/inventory validation is replaced by:
  - `devflow registry init` (bootstrap + dedupe)
  - commit DAG enforcement nodes (validate + refactor to canonical)

## Command
- `devflow registry init [--strict] [--root <path> ...]`

## Deterministic scan scope
- Only scan **project-owned** source roots.
- External/generated directories are not scanned by definition.

## Init algorithm
1) Create `.devflow/registry.sqlite`.
2) Scan project files:
   - record every import edge in the DB.
   - register every import target as an entity in the DB.
3) Detect duplicates (functionally equivalent entities) and allow them to exist initially.
4) LLM dedupe pass:
   - choose a canonical entity for each duplicate cluster.
   - mark others as heretical.
   - persist canon/heresy mapping.
5) If `--strict`:
   - refactor usage sites from heretical → canonical.
   - remove/retire heretical entities when safe.
   - run typecheck + lint gates.

## Outputs
- A machine-readable init report (JSON) including:
  - scanned roots
  - counts: files scanned, imports discovered, entities registered
  - dedupe clusters + canonical picks
  - strict refactor summary (if enabled)

## Contract test spec
- Given a repo with imports and a known duplicate pair (e.g., `emailSend` vs `sendEmail`)
- When `devflow project init` runs
  - Then `.devflow/registry.sqlite` exists and contains all discovered imports/entities
  - And the dedupe step records canonical vs heretical mapping
- When `devflow project init --strict` runs
  - Then code is refactored so no heretical usages remain
  - And typecheck + lint succeed (or init fails on those gates)
