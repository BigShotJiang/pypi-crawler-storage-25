# DF2-PLAY-904 — Playground: Scenario runner and artifacts

story_uuid: 20126380-1665-448f-bce2-8ebed3cee299
story_id: DF2-PLAY-904
title: Playground: Scenario runner and artifacts
required_planes: [ops, api]

CONTRACT FORMATION MODE: implementation is irrelevant; do not compare against current code/UI. Define user-expected outcomes and test oracles only.

plane_oracles:
- plane: ops
  oracle: "Running a scenario produces a deterministic run record with start/finish status, stdout/stderr capture, and timing, and can be resumed or retried safely."
  anchor: "command:devflow play run <scenario_slug> + files:.devflow/logs/runs/<run_id>/"

- plane: api
  oracle: "Scenario results are persisted as structured artifacts linked to the run and queryable for review and error ingestion."
  anchor: "sqlite:.devflow/execution.sqlite artifacts(type=playground.scenario_result)"

## Story statement
As a developer, I want DevFlow to run a specific playground scenario and persist its results, so that verification is repeatable and reviewable.

## Outcome oracle (user-observable)
- CLI prints PASS/FAIL and points to logs/artifacts.

## Preconditions
- Preflight has passed (or user overrides explicitly).

## Steps
1. `devflow play run <scenario_slug>`
2. DevFlow executes the scenario.
3. DevFlow stores result artifacts.

## Acceptance criteria
1. MUST capture stdout/stderr to run-scoped logs.
2. MUST persist a structured result artifact (status, key metrics, failure message).
3. MUST NOT lose result data if the process crashes mid-run (partial artifacts are acceptable but must be marked incomplete).
4. MUST support `--json` output for automation.

## Non-goals
- Not defining UI rendering of results.

## Contract test spec (Given/When/Then)
- Given a scenario that fails deterministically
- When I run `devflow play run <scenario_slug> --json`
- Then the command exits non-zero, stores logs under `.devflow/logs/runs/<run_id>/`, and persists a failure artifact linked to the run
