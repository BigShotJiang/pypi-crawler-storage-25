story_uuid: 34e068f1-1f61-48c3-87fe-2d2af6d558e5
story_id: DF2-IMPL-603
title: Stage: TestDesign (derive test oracles + anchors from normalized intent)
required_planes: [auth, api, ui, integrations, ops]

CONTRACT FORMATION MODE: implementation is irrelevant; do not compare against current code/UI. Define user-expected outcomes and test oracles only.

## Intent
Generate a test design artifact that specifies what must be proven (oracles) and where/how to observe it (anchors), without implementing code yet.

## Definitions
- Oracle: a verifiable claim about behavior/outcomes (e.g., "returns 400 with message X").
- Anchor: the observation point for verifying the oracle (e.g., CLI output, API response, DB row, file on disk).

## User value
As a developer, I can review a precise test plan before writing failing tests, reducing ambiguity and wasted implementation work.

## Scope
- Input: Normalize artifact.
- Output: TestDesign artifact containing:
  - a list of test cases with titles
  - for each test case: oracle + anchor + preconditions + fixtures/data
  - explicit “negative space” (what is NOT tested / intentionally omitted)
  - mapping from test cases to derived test target files/modules

## Out of scope
- Actually writing the test code (that is Red).

plane_oracles:
- plane: auth
  oracle: "TestDesign generation must not access secrets; it may read local repo files only as needed for context."
  anchor: "stage:testdesign (offline)"
- plane: api
  oracle: "Every generated test case includes at least one oracle and one anchor; missing anchors are treated as a design failure."
  anchor: "artifact:test_design.test_cases[*].(oracle,anchor)"
- plane: ui
  oracle: "CLI prints an easy-to-review list of test cases (titles + oracles) suitable for human approval."
  anchor: "cli:testdesign preview"
- plane: integrations
  oracle: "External tools can consume the TestDesign artifact (JSON/structured) to generate test files or docs."
  anchor: "artifact:test_design export"
- plane: ops
  oracle: "TestDesign artifact is persisted and versioned; downstream stages refuse to run if schema versions are incompatible."
  anchor: "ops:schema compatibility gate"

## Acceptance criteria
- MUST produce a TestDesign artifact from a Normalize artifact.
- MUST include at least one test case unless the Normalize artifact explicitly indicates no executable change (then it MUST produce a rationale).
- MUST include explicit anchors for each oracle.
- MUST declare which gate checks will be used later (e.g., ruff, mypy, unit tests) so the plan is predictable.
- MUST support persistence for downstream stages.

## Contract test specs
1) Oracle+anchor completeness
   - Given a Normalize artifact for a behavioral change
   - When TestDesign runs
   - Then each test case has non-empty oracle and anchor fields

2) Negative space
   - Given a Normalize artifact with out-of-scope notes
   - When TestDesign runs
   - Then the TestDesign artifact includes a “not tested / out of scope” section reflecting those notes

3) Schema gating
   - Given a TestDesign artifact with an unknown schema_version
   - When a downstream stage is invoked
   - Then it fails fast with an actionable schema incompatibility error
