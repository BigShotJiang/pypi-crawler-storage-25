story_uuid: 57a6cc80-0c22-4c7b-b1af-10fc72cb5e29
story_id: DF2-IMPL-604
title: Stage: Red (materialize failing tests from TestDesign)
required_planes: [auth, api, ui, integrations, ops]

CONTRACT FORMATION MODE: implementation is irrelevant; do not compare against current code/UI. Define user-expected outcomes and test oracles only.

## Intent
Turn the TestDesign artifact into concrete story-scoped tests that assess completeness honestly: either the implementation is already satisfied, the implementation is incomplete, or the tests are too weak and must be strengthened.

## User value
As a developer, I get immediate feedback that my tests truly capture the intended behavior before writing production code.

## Scope
- Input: TestDesign artifact.
- Output:
  - one or more test files created/updated
  - test-validation gate result (pass after auto-repair)
  - execution result classified as `real_green`, `greenwashed_green`, or `real_red`
  - a result summary mapped to story-scoped test sufficiency and test case outcomes

## Out of scope
- Implementing the production code fix (that is Green).

plane_oracles:
- plane: auth
  oracle: "Generating and running tests must not require credentials; tests must not require network by default unless explicitly planned."
  anchor: "stage:red (offline tests)"
- plane: api
  oracle: "Red stage MUST distinguish complete implementations from incomplete ones using story-scoped tests, and it MUST attribute the result to specific test cases."
  anchor: "artifact:red_result.assessment"
- plane: ui
  oracle: "CLI prints a succinct failing summary (which tests failed and why) without overwhelming logs."
  anchor: "cli:red failure summary"
- plane: integrations
  oracle: "Test execution uses a configurable runner adapter (e.g., pytest) but exposes a uniform result contract (passed/failed/errored counts)."
  anchor: "api:test_runner result envelope"
- plane: ops
  oracle: "Red stage enforces a deterministic story-scoped test-validation gate and only passes when story test sufficiency passes."
  anchor: "script:scripts/validate_tests.py"

## Acceptance criteria
### A) Test validation gate (must repair)
- MUST ensure a deterministic test-validation script exists (create if missing) and run it as an exit gate for Red.
  - Anchor: `script:scripts/validate_tests.py`
- If test validation fails, MUST autonomously repair until it passes, then proceed.
  - No halt / no ask.
  - No placeholders/stubs.
  - Repairs include (best-effort, deterministic):
    - adding missing story linkage markers (`story_id`, `story_uuid`, `plane`) to tests
    - aligning story_id usage between tests and canonical story docs
    - fixing story_uuid mismatches
- MUST record repair provenance as an artifact (e.g., which files changed + why) suitable for later audit.

### B) Red produces meaningful failing tests
- MUST create/update test code according to the TestDesign mapping.
- MUST run the tests and obtain a machine-readable result.
- MUST behave as a completeness assessor, not fail by definition.
- MUST classify outcomes as:
  - `real_green`: tests are story-sufficient and already pass because the implementation already satisfies the story
  - `greenwashed_green`: tests pass but story-scoped test sufficiency fails, so Red must strengthen tests instead of treating the implementation as done
  - `real_red`: tests are story-sufficient and fail because the implementation is incomplete
- MUST only pass when story-scoped test sufficiency passes.
- MUST persist:
  - the generated test files
  - the test-validation report
  - the test run result summary

## Contract test specs
0) Test validation gate is enforced (auto-repair)
   - Given a repo where contract tests are missing story linkage markers or reference unknown story ids
   - When Red runs
   - Then it repairs tests/story linkage deterministically and `scripts/validate_tests.py` passes
   - And the validation report is persisted

1) Red classifies real red when implementation is incomplete
   - Given a TestDesign artifact for a new behavior
   - When Red runs
   - Then story-scoped test sufficiency passes
   - And at least one planned test case is marked failing
   - And the result is classified as `real_red`

2) Real green is accepted
   - Given a TestDesign that describes behavior already present
   - When Red runs and the runner exits 0
   - Then Red classifies the result as `real_green`
   - And it does not fail by definition

3) Greenwashed green is blocked
   - Given tests that pass but do not satisfy story-scoped test sufficiency
   - When Red runs
   - Then Red fails with a `greenwashed_green` outcome
   - And the result instructs the system to strengthen tests

4) Failure attribution
   - Given failing tests
   - When the Red result is examined
   - Then each failure is linked to a test file + test name/node id + planned test case id
