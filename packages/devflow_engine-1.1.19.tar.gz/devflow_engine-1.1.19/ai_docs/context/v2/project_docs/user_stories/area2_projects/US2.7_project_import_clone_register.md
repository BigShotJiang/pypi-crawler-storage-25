story_uuid: 6f9f3c9a-7f7b-4e5b-a2d4-7b7b9f4c3f72
story_id: US2.7
title: US2.7 project import (clone + register)
required_planes: [ui, ops]

CONTRACT FORMATION MODE: implementation is irrelevant; do not compare against current code/UI. Define user-expected outcomes and test oracles only.

plane_oracles:
- plane: ui
  oracle: "A user can import a GitHub repo by URL or owner/repo and DevFlow prints a stable, actionable result (project_id + workspace path)."
  anchor: "cli:devflow project import"
- plane: ops
  oracle: "Import deterministically clones into the DevFlow-managed projects root, registers the project, and bootstraps repo-local .devflow state without destructive actions."
  anchor: "fs:~/.devflow/projects + registry + <repo>/.devflow"

# US2.7 — `devflow project import` clones a GitHub repo and registers it as an active project

## Story
As a developer,
I want to import a GitHub repository into DevFlow,
so that it becomes an active DevFlow project with a deterministic workspace and registry entry.

## Command surface
- `devflow project import <repo_spec>`

Where `<repo_spec>` accepts:
- `https://github.com/<owner>/<repo>.git` (or without .git)
- `git@github.com:<owner>/<repo>.git`
- `<owner>/<repo>` (implied GitHub HTTPS clone)

## Acceptance criteria
1. **Clone into DevFlow-managed workspace**
   - DevFlow clones the repo into:
     - `$DEVFLOW_HOME/.devflow/projects/<owner>__<repo>__<hash>/repo/`
   - `<hash>` is deterministic for the repo identity (remote URL normalized).
   - If the target directory already exists and looks like a git repo, import is idempotent (does not reclone; prints existing path).

2. **Register project as active**
   - DevFlow upserts an entry in:
     - `$DEVFLOW_HOME/.devflow/registry/projects.json`
   - The entry includes at minimum:
     - `project_id`
     - `owner`
     - `repo`
     - `workspace_path`
     - `remote_url`
   - The registry write is deterministic (stable JSON formatting and sorted keys).

3. **Bootstrap repo-local DevFlow state**
   - DevFlow ensures that in the cloned repo root (`.../repo/`), a repo-local `.devflow/` directory exists with at minimum:
     - `.devflow/execution.sqlite` (ExecutionStore bootstrap)
     - `.devflow/config.yaml` or `.devflow/config.toml` (one canonical format for repo-local config)

4. **User-visible output**
   - On success, stdout includes:
     - the `project_id`
     - the absolute workspace path to the cloned repo root
     - one next-step hint (e.g., `devflow play preflight --json`)

5. **Failure modes are actionable**
   - If `git` is missing or clone fails, command exits non-zero and prints remediation.

## Non-goals
- Authentication UX beyond letting `git` handle it (SSH keys/token prompts are delegated).
- Multi-remote support.

## Determinism notes
- Workspace path is derived from normalized remote URL; registry formatting is stable; outputs avoid line-wrapping requirements.
