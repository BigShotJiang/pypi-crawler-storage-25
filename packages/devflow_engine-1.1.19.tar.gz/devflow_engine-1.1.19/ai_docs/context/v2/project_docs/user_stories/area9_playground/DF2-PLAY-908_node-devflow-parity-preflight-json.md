# DF2-PLAY-908 — Playground: Node DevFlow parity for preflight JSON + remediation hooks

story_uuid: 6e736537-a688-4102-9bb6-7143993b97f0
story_id: DF2-PLAY-908
title: Playground: Node DevFlow parity for preflight JSON + remediation hooks
required_planes: [ops]

CONTRACT FORMATION MODE: implementation is irrelevant; do not compare against current code/UI. Define user-expected outcomes and test oracles only.

plane_oracles:
- plane: ops
  oracle: "DevFlow v2 emits preflight JSON in a stable schema compatible with the existing DevFlow expectations (human summary + JSON payload), and supports remediation hooks without requiring manual intervention."
  anchor: "file:devFlow/docs/PREFLIGHT_ARCHITECTURE.md (reference) + command:devflow play preflight --json"

## Story statement
As a developer, I want DevFlow v2 playground preflight behavior to match the intent of existing DevFlow preflight semantics, so that migration preserves reliability and diagnostics.

## Outcome oracle (user-observable)
- Preflight JSON output is stable and includes per-check details + summary.

## Preconditions
- Preflight runner exists.

## Steps
1. Run preflight in JSON mode.
2. Observe schema and remediation fields.

## Acceptance criteria
1. MUST emit a stable JSON schema including per-check results and overall success.
2. MUST include remediation attempt fields when auto-remediation is configured.
3. MUST NOT hide failures behind a generic "failed" message; must include check-level detail.

## Non-goals
- Not perfectly matching all old field names if we adopt a versioned schema; but compatibility must be documented and machine-mappable.

## Contract test spec (Given/When/Then)
- Given a failing check with an available remediation
- When I run `devflow play preflight --json`
- Then the JSON includes the failing check, remediationAttempted=true, remediationSuccess=(true|false)
- And the schema version is present
