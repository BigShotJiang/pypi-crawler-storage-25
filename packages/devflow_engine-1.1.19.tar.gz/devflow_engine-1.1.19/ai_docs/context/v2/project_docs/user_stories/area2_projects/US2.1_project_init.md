story_uuid: 9c7f4e51-554f-48fe-88fc-43d9500d467f
story_id: US2.1
title: US2.1 project init
required_planes: [ui, ops]

CONTRACT FORMATION MODE: implementation is irrelevant; do not compare against current code/UI. Define user-expected outcomes and test oracles only.

plane_oracles:
- plane: ui
  oracle: "The user can invoke the documented CLI behavior for US2.1 and receives clear, actionable output on success/failure."
  anchor: "cli:US2.1"
- plane: ops
  oracle: "Operational side effects for US2.1 are deterministic and documented (files/dirs created, idempotency, and safe failure modes)."
  anchor: "docs:user_story/US2.1"
# US2.1 — `devflow project init` creates a DevFlow-managed project

## Story
As a developer,
I want to initialize DevFlow for the current repository,
so that the project has a predictable local workspace layout and DevFlow can track it.

## Scope / Notes
Implementation Task 2 (Project lifecycle). Focus is on: initialize + register a project entry and minimal config scaffolding.

## User-visible behavior
- Command: `devflow project init` (run inside a repo/workdir)
- Output: prints the project id, resolved workspace path, and next steps.

## Acceptance Criteria
1. **Detect context**
   - If the current directory is inside a git repository, DevFlow identifies:
     - repo root path
     - `owner` and `repo` (from `origin` remote when available; fallback to local folder name)
   - If not a git repo, DevFlow fails with a helpful error and remediation.

2. **Create/ensure workspace clone directory**
   - DevFlow ensures a DevFlow-managed workspace directory exists under:
     - `~/.devflow/projects/<owner>__<repo>__<hash>/`
   - The `<hash>` is deterministic for the repo identity (see US2.5).
   - Directory creation is idempotent (safe to run repeatedly).

3. **Write minimal project-local DevFlow config**
   - In the *DevFlow-managed workspace*, DevFlow creates:
     - `.devflow/config.toml` (or `.yaml`—format chosen by DevFlow; must be consistent)
   - The file contains at minimum:
     - `project_id`
     - `source_repo` (remote URL or local path)
     - `created_at`

4. **Register in the DevFlow registry**
   - A registry entry is created/updated for the project (see US2.3).

5. **No destructive actions**
   - `project init` does not delete existing files.
   - If config already exists, DevFlow either:
     - merges non-destructively, or
     - refuses with a clear message and a `--force` instruction (policy choice must be explicit).

## Non-goals
- Full repo cloning strategy (ssh keys, auth prompts) beyond creating the deterministic directory.
- Per-language build scaffolding.

## Edge cases
- Detached HEAD or missing `origin` remote.
- Monorepos: init should bind to the git root, not an arbitrary subdir.

## Telemetry / Logging (local)
- Logs include the resolved `project_id` and workspace path.
