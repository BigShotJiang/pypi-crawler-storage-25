# DF2-PLAY-902 — Playground: Preflight check catalog and per-project config

story_uuid: 8635d2c7-7a4d-48ed-a8fd-b17b0c750d3f
story_id: DF2-PLAY-902
title: Playground: Preflight check catalog and per-project config
required_planes: [ops]

CONTRACT FORMATION MODE: implementation is irrelevant; do not compare against current code/UI. Define user-expected outcomes and test oracles only.

plane_oracles:
- plane: ops
  oracle: "A project can declare preflight checks and their required/optional status, and DevFlow executes them consistently with clear output and exit codes."
  anchor: "file:<repo>/.devflow/config.(json|yaml) preflight section + command:devflow play preflight"

## Story statement
As a developer, I want to configure which preflight checks run for a project, so that DevFlow matches the repo’s reality (language/tooling) and avoids hardcoded assumptions.

## Outcome oracle (user-observable)
- Preflight behavior changes based on project config, without code changes.

## Preconditions
- Project config hierarchy is functioning (DevFlow global + project local).

## Steps
1. Developer edits project config to add checks.
2. Developer runs preflight.

## Acceptance criteria
1. MUST support required vs optional checks.
2. MUST stop-on-failure for required checks, continue for optional checks.
3. MUST include check name/type and a remediation hint in output.
4. MUST NOT require internet access for checks that can be purely local.

## Non-goals
- Not implementing provider-specific checks here (those are separate stories).

## Contract test spec (Given/When/Then)
- Given a project config declaring two required checks and one optional check
- When I run `devflow play preflight --json`
- Then results include all executed checks in order
- And a failure in a required check exits non-zero and marks the optional check as skipped or not-run per policy
