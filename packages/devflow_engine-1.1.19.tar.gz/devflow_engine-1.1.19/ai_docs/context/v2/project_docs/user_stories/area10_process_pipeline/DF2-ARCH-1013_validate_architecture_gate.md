story_uuid: 3f7b6c5a-5cf6-4bb1-a2d7-6d20d2e3a7ff
story_id: DF2-ARCH-1013
title: ValidateArchitecture gate (mechanical lint, no LLM)
required_planes: [ops]

CONTRACT FORMATION MODE: implementation is irrelevant; do not compare against current code/UI. Define user-expected outcomes and test oracles only.

plane_oracles:
- plane: ops
  oracle: "Architecture constraints registered during ideation are enforced via deterministic lint/validators (no LLM judgment) in CI and as a pipeline stage."
  anchor: "script:scripts/validate_architecture.py"

# DF2-ARCH-1013 — ValidateArchitecture gate

## Story
As a DevFlow maintainer,
I want a mechanical validator that enforces registered architecture decisions,
so that project-level constraints (e.g., use GenAI DAG framework) cannot silently drift.

## Acceptance criteria
1. **Inputs**
   - Reads `architecture/decisions.yaml` and `architecture/inventory.yaml`.

2. **Deterministic rules**
   - Enforces rules such as:
     - if decision `workflow_engine=genai_dag` is set,
       then workflow code must import/use the approved framework module(s)
       and disallow custom DAG runner modules unless exempted.

3. **Actionable output**
   - Reports rule id, file path, and suggested remediation.

4. **Exemptions**
   - Supports explicit exemptions with reasons.

## Contract test spec
- Given a repo that declares workflow_engine=genai_dag
- When a custom DAG runner is introduced without exemption
- Then validate_architecture fails with an actionable error
