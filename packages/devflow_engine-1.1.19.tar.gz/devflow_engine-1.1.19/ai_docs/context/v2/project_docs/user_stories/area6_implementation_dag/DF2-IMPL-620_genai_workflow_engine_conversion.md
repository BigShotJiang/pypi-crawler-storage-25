story_uuid: 2a83a5c5-6d3c-4e76-a2e5-2b9d94d0c0bb
story_id: DF2-IMPL-620
title: Implementation DAG runs on GenAI workflow engine (autonomous, non-blocking gates)
required_planes: [ops, integrations]

CONTRACT FORMATION MODE: implementation is irrelevant; do not compare against current code/UI. Define user-expected outcomes and test oracles only.

plane_oracles:
- plane: ops
  oracle: "A story execution produces a complete node timeline for the implementation pipeline and runs end-to-end without stopping, unless a hard error or budget exhaustion occurs."
  anchor: "cli:devflow story execute <uuid> --mode autonomous"
- plane: integrations
  oracle: "Implementation execution uses the GenAI workflow framework’s native node state machine (succeeded/failed/skipped/blocked) rather than a bespoke runner, while preserving ExecutionStore persistence contracts."
  anchor: "docs:genai_workflow_engine"

# DF2-IMPL-620 — Convert Implementation DAG to GenAI workflow engine

## Story
As a DevFlow operator,
I want the implementation pipeline to run on the GenAI workflow framework,
so that node-to-node execution is seamless, resumable, and policy-driven (no interactive halts).

## Context
Current Area6 runner is a bespoke Python function. It halts after Red in interactive TDD semantics.
DevFlow autonomy requires:
- end-to-end execution by default
- gates as policy-controlled transitions, not manual stop points

## Acceptance criteria
1. **GenAI engine integration**
   - Implementation DAG is executed via the GenAI workflow framework graph runner.
   - Each stage is a workflow node with explicit status.

2. **Autonomous default**
   - Default execution mode continues after Red into Green remediation loop.
   - The run only stops early for:
     - hard errors (missing tools/config)
     - budget exhaustion (max iterations/time)

3. **Complete node timeline**
   - The ExecutionStore `nodes` table records each stage attempt with status and timestamps.
   - Even blocked/skipped nodes are recorded (status = blocked/skipped).

4. **Preserve CLI + persistence contracts**
   - `devflow story execute <uuid>` remains the user entrypoint.
   - Review packet + validate gates remain composable.

5. **No LLM judgment for enforcement**
   - Architecture decision “workflow_engine=genai_dag” is enforced by mechanical lint, not LLM.

## Contract test spec
- Given a repo with a registered story and failing tests
- When running story execute in autonomous mode
- Then the pipeline records the full stage timeline and returns a non-zero status with actionable artifacts
