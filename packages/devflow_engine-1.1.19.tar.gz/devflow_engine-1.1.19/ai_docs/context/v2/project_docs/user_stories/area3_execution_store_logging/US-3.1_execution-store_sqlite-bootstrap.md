story_uuid: 2a29bdf2-5803-4d95-86ff-bcbb2e62dc51
story_id: US-3.1
title: US-3.1 execution-store sqlite-bootstrap
required_planes: [api, ops]

CONTRACT FORMATION MODE: implementation is irrelevant; do not compare against current code/UI. Define user-expected outcomes and test oracles only.

plane_oracles:
- plane: api
  oracle: "The engine exposes deterministic programmatic behavior and data models required by US-3.1_execution-store_sqlite-bootstrap (inputs/outputs and persistence semantics)."
  anchor: "api:US-3.1_execution-store_sqlite-bootstrap"
- plane: ops
  oracle: "Operational side effects for US-3.1_execution-store_sqlite-bootstrap are deterministic and documented (files/dirs created, idempotency, and safe failure modes)."
  anchor: "docs:user_story/US-3.1_execution-store_sqlite-bootstrap"
# US-3.1 — Execution Store: SQLite bootstrap + connection policy (WAL/locking)

## User story
As a DevFlow developer/operator,
I want a local execution database created and managed in `.devflow/execution.sqlite`,
so that all runs can persist state durably and be queryable for debugging and UI/CLI features.

## Why
- Enables reproducible run history, troubleshooting, and future UX (e.g., `devflow run list`, `devflow run inspect`).
- Provides a single source of truth for events, errors, and artifacts across DAG/runs/tools.

## Scope
- Create the SQLite file at `.devflow/execution.sqlite` (project-local).
- Enable WAL journaling for concurrent reads while writing.
- Establish a safe locking/concurrency policy (busy_timeout, transaction strategy).
- Define DB initialization and schema versioning mechanism.

## Out of scope (for this story)
- Remote/centralized execution store.
- Full-featured migration framework beyond minimal schema versioning.
- Index tuning beyond baseline indexes needed for common queries.

## Contract
### Functional requirements
1. **Bootstrap**
   - If `.devflow/` does not exist, create it.
   - If `.devflow/execution.sqlite` does not exist, create it and initialize schema.
   - If it exists, validate schema version and apply allowed upgrades (see “Schema versioning”).

2. **SQLite configuration**
   - `PRAGMA journal_mode=WAL`.
   - `PRAGMA synchronous=NORMAL` (or stricter if required by product decision; must be explicitly documented in code).
   - `PRAGMA foreign_keys=ON`.
   - `PRAGMA busy_timeout` set to a non-trivial value (e.g., 2500–10000ms) to reduce transient lock failures.

3. **Connection policy**
   - One connection per process (or per thread) with explicit transaction boundaries.
   - Writes occur in short-lived transactions.
   - Readers do not block writers under WAL mode.

4. **Locking behavior**
   - On `SQLITE_BUSY`/`database is locked`, retry should respect busy_timeout and emit structured logs (see US-3.6).
   - If the store cannot be opened/initialized, fail fast with a clear error message that points to `.devflow/execution.sqlite`.

### Data requirements
- Store a schema version in a dedicated table (e.g., `meta`), including:
  - `schema_version` integer
  - `created_at` timestamp
  - `updated_at` timestamp

### Observability requirements
- On startup, emit an INFO log that includes:
  - store path
  - schema version
  - WAL mode enabled (true/false)
  - busy_timeout value

### Security & privacy
- Execution DB resides inside the project `.devflow/` directory.
- Do not store raw secrets (API keys, tokens) in any table.

## Acceptance criteria
- [ ] Running DevFlow in a fresh repo creates `.devflow/execution.sqlite` with initialized tables.
- [ ] WAL mode is enabled (verified via `PRAGMA journal_mode;`).
- [ ] Foreign keys are enabled.
- [ ] Schema version is readable and validated.
- [ ] Concurrent read while writing does not crash (basic concurrency smoke test).
- [ ] When the DB is locked, DevFlow logs a useful warning/error and either retries or fails with a clear message.

## Implementation notes
- Prefer a single “ExecutionStore” module/class that owns:
  - path resolution
  - connection lifecycle
  - pragma setup
  - schema init/migrations
- Use UTC timestamps consistently.

## Test plan
- Unit test: create store in temp directory → tables present.
- Unit test: open existing store → no destructive changes.
- Integration test: simulate two processes; one writes in a transaction while another reads.
- Failure test: make path unwritable → verify clear error.

## Open questions
- Confirm `synchronous` policy (NORMAL vs FULL) for acceptable durability/performance tradeoff.
