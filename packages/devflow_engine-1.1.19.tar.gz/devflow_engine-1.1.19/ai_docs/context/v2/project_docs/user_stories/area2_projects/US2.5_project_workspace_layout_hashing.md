story_uuid: 8ccc8fd3-95f3-4fed-9b20-2064ae25273b
story_id: US2.5
title: US2.5 project workspace layout hashing
required_planes: [ui, ops]

CONTRACT FORMATION MODE: implementation is irrelevant; do not compare against current code/UI. Define user-expected outcomes and test oracles only.

plane_oracles:
- plane: ui
  oracle: "The user can invoke the documented CLI behavior for US2.5 and receives clear, actionable output on success/failure."
  anchor: "cli:US2.5"
- plane: ops
  oracle: "Operational side effects for US2.5 are deterministic and documented (files/dirs created, idempotency, and safe failure modes)."
  anchor: "docs:user_story/US2.5"
# US2.5 — Deterministic workspace layout under `~/.devflow/projects/<owner>__<repo>__<hash>/`

## Story
As a developer,
I want DevFlow to store projects in a deterministic local path,
so that I can find them reliably and avoid collisions between forks or same-named repos.

## Requirements
DevFlow-managed workspaces live under:
- `~/.devflow/projects/`

Each project gets a directory:
- `~/.devflow/projects/<owner>__<repo>__<hash>/`

## Acceptance Criteria
1. **Name components**
   - `<owner>` and `<repo>` are normalized:
     - lowercase
     - non-alphanumeric replaced with `_`
     - trimmed to a safe max length (implementation-defined)

2. **Hash component**
   - `<hash>` is a stable, deterministic short hash derived from a canonical repo identity string.
   - Canonical identity precedence:
     1) remote URL (normalized; e.g., strip `.git`, normalize ssh/https host, lowercase host)
     2) if no remote: absolute repo root path (normalized)
   - Hash format:
     - hex or base32; 8–12 chars recommended

3. **Collision resistance**
   - Different remotes for same `owner/repo` yield different `<hash>`.
   - Re-running init/register yields the same `<hash>`.

4. **Workspace path recorded**
   - The computed `workspace_path` is stored in the registry entry.

5. **Human ergonomics**
   - Path is readable and grep-able (owner/repo visible).
   - Hash is short but sufficient to disambiguate.

## Non-goals
- Deduplicating storage for identical commit histories.
- Supporting arbitrary user-chosen workspace paths (can be a future story).

## Examples
- `~/.devflow/projects/nuosis__devflow__a1b2c3d4/`
- `~/.devflow/projects/nuosis__devflow__f9e8d7c6/` (fork/alternate remote)
