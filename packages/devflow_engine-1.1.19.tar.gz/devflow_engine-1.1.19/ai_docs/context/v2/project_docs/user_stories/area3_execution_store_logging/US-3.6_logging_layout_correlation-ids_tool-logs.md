story_uuid: d86e018d-1d0f-4f8e-b4d7-82d3b2cf9d5b
story_id: US-3.6
title: US-3.6 logging layout correlation-ids tool-logs
required_planes: [ui, ops]

CONTRACT FORMATION MODE: implementation is irrelevant; do not compare against current code/UI. Define user-expected outcomes and test oracles only.

plane_oracles:
- plane: ui
  oracle: "The user can invoke the documented CLI behavior for US-3.6_logging_layout_correlation-ids_tool-logs and receives clear, actionable output on success/failure."
  anchor: "cli:US-3.6_logging_layout_correlation-ids_tool-logs"
- plane: ops
  oracle: "Operational side effects for US-3.6_logging_layout_correlation-ids_tool-logs are deterministic and documented (files/dirs created, idempotency, and safe failure modes)."
  anchor: "docs:user_story/US-3.6_logging_layout_correlation-ids_tool-logs"
# US-3.6 — Extensive logging: layout, correlation IDs, and tool/run log streams

## User story
As a DevFlow operator and developer,
I want logs written to a predictable on-disk layout with correlation IDs that match DB records,
so that I can debug runs quickly and stitch together engine/node/tool events across files.

## Scope
- Define log directory structure under `.devflow/logs/{dags,runs,tools}`.
- Define correlation ID strategy and propagation.
- Define minimum structured log fields.
- Ensure logs are written even when DB writes fail (best effort).

## Out of scope
- Full log shipping/aggregation.
- UI log viewer.

## Contract
### Directory layout
All logs live under `.devflow/logs/`:

1. **DAG-level logs**
   - `.devflow/logs/dags/{dag_id}/` (optionally include `{dag_version}`)

2. **Run-level logs**
   - `.devflow/logs/runs/{run_id}/`
   - Must include at least:
     - `run.log` (engine + orchestration)
     - `events.jsonl` (structured event stream; one JSON object per line)

3. **Tool-level logs**
   - `.devflow/logs/tools/{run_id}/{node_exec_id}/{tool_name}/`
   - Must include:
     - `tool.log` (human-readable)
     - `io.jsonl` (structured; inputs/outputs summaries)

> Note: filenames may vary, but the directory structure is contractual.

### Correlation IDs
1. **IDs**
   - `root_correlation_id`: assigned per run; stored in `runs.root_correlation_id`.
   - `correlation_id`: assigned per node attempt; stored in `nodes.correlation_id`.
   - Optional `tool_call_id`: assigned per tool invocation (if tool call table exists later; for now must appear in logs).

2. **Propagation rules**
   - Every structured log event emitted during a run must include `run_id` and `root_correlation_id`.
   - Node-scoped events must include `node_exec_id`, `node_id`, `attempt`, and `correlation_id`.
   - Tool-scoped events must include `tool_name` and a stable `tool_call_id`.

### Structured log format (minimum)
- JSON Lines (JSONL) for structured streams.
- Each event JSON object includes:
  - `ts` (UTC timestamp)
  - `level` (debug|info|warn|error)
  - `event` (machine-readable name)
  - `msg` (human-readable)
  - `run_id`
  - `root_correlation_id`
  - optional node/tool fields (as above)

### Coupling logs to the execution store
- The DB is the canonical state; logs are canonical narrative.
- When writing artifacts that reference logs, create `artifacts` rows pointing to:
  - `.devflow/logs/runs/{run_id}/events.jsonl`
  - tool IO logs under `.devflow/logs/tools/...`

### Resilience requirements
- If SQLite is locked/unavailable temporarily, logging still proceeds to disk.
- Log writing should be append-only.

## Acceptance criteria
- [ ] For a run, `.devflow/logs/runs/{run_id}/run.log` and `events.jsonl` exist.
- [ ] For a tool invocation, a directory exists under `.devflow/logs/tools/{run_id}/{node_exec_id}/{tool_name}/`.
- [ ] Structured events include correlation fields and can be joined to DB rows by `run_id` and `node_exec_id`.
- [ ] Logs are written even if DB insert/update fails (best-effort fallback).

## Test plan
- Integration: run a DAG with at least one tool call; verify directories + files exist.
- Integration: inject transient DB lock; verify `events.jsonl` continues to append.
- Unit: validate event schema (required keys present).
