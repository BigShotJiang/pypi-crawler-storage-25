story_uuid: a023eff3-70c3-4fe4-8e63-5cecb61d8b8f
story_id: DF2-STORY-403
title: Story indexer builds a normalized index from canonical + artifacts
required_planes: [auth, api, ui, integrations, ops]

CONTRACT FORMATION MODE: implementation is irrelevant; do not compare against current code/UI. Define user-expected outcomes and test oracles only.

## Intent
As a DevFlow toolchain user, I want a story indexer that produces a normalized, queryable index so that downstream components (planning, validation, execution gating) can reliably reference stories by ID/UUID and detect changes.

## Scope
- An indexer consumes:
  - Canonical markdown at `.../project_docs/user_stories.md`
  - Optional artifact markdown files under `.../project_docs/user_stories/**/*.md`
- The indexer outputs a deterministic “story index” structure containing:
  - `story_uuid`
  - `story_id`
  - `title`
  - `source_path`
  - `contract_hash` (see separate story)
  - `status` or `maturity` (e.g., `draft` vs `canonical`) derived from source

## Out of scope
- Full-text search engine
- Remote registries
- Non-markdown story formats

plane_oracles:
- plane: auth
  oracle: "Indexing must not require secrets; it only reads local markdown files."
  anchor: "indexer:local fs"
- plane: api
  oracle: "Index output is stable and machine-readable (e.g., JSON) and includes required identity fields."
  anchor: "api:build_story_index() -> index"
- plane: ui
  oracle: "A CLI command (or equivalent) can print a human-readable summary of indexed stories including story_id/title/source."
  anchor: "cli:stories list"
- plane: integrations
  oracle: "Downstream steps can depend on the index contract (fields present, deterministic ordering)."
  anchor: "integration:planning uses index"
- plane: ops
  oracle: "Indexer behavior is deterministic across machines given the same repo content."
  anchor: "ops:determinism"

## Acceptance criteria
- MUST index stories from canonical and optional artifacts.
- MUST produce an index where each story is uniquely identified by `story_uuid`.
- MUST detect and reject duplicate `story_uuid` across sources.
- MUST detect and reject duplicate `story_id` across sources (unless explicitly allowed by policy; default: reject).
- MUST include `source_path` for traceability.
- MUST generate deterministic ordering of index entries (e.g., sort by `story_id` then `story_uuid`).

## Contract test specs
1) Index includes canonical stories
   - Given the canonical file contains N stories
   - When the indexer runs
   - Then the index includes those N stories with correct metadata

2) Index includes artifact stories
   - Given there are M artifact story files
   - When the indexer runs
   - Then the index includes those M stories

3) Duplicate UUID rejection
   - Given two sources with the same `story_uuid`
   - When the indexer runs
   - Then it fails with a clear error indicating the conflicting paths

4) Deterministic output
   - Given a fixed repository state
   - When the indexer runs twice
   - Then the produced index content is byte-for-byte identical
