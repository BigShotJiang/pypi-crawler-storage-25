story_uuid: 0d8bb1cf-5b61-4f89-9f14-8f1c6b6e3e3c
story_id: DF2-REG-1031
title: Registry init dedupe selects canon vs heresy; --strict refactors to canon (no failure)
required_planes: [ops]

CONTRACT FORMATION MODE: implementation is irrelevant; do not compare against current code/UI. Define user-expected outcomes and test oracles only.

plane_oracles:
- plane: ops
  oracle: "During init, legacy duplicates are allowed and recorded; a dedupe pass chooses canonical items and marks others heretical; strict mode performs deterministic refactors to remove heretical usages rather than failing the run."
  anchor: "cli:devflow registry init"

# DF2-REG-1031 — Init dedupe + strict refactor

## Story
As a DevFlow operator,
I want registry init to tolerate legacy duplication but then deterministically converge the codebase to canonical entities,
so that import/registration is frictionless for existing repos while development stays compliant.

## Definitions
- **Canonical entity**: the single preferred implementation for a given capability/surface.
- **Heretical entity**: a duplicate implementation that should not be used once canon is chosen.

## Init behavior (non-strict)
Given a freshly imported repo:
1) Scan project-owned source roots and populate the registry DB.
2) Allow duplicate entities to be registered by default (e.g. `emailSend` and `sendEmail`).
3) Run a dedupe classification pass that:
   - selects a canonical entity
   - marks other duplicates heretical
   - records canon/heresy mapping in the registry DB

### Canon selection priority
1) Specs/docs explicitly name the canonical API/service.
2) "Truest path": prefer the entity used by the most upstream canonical service/orchestrator.
3) Most consistent with established code patterns.
4) If still unclear: choose one decisively (no manual review gate).

## Strict init behavior (--strict)
- `devflow registry init --strict` MUST NOT fail solely due to duplicates.
- Instead it must behave like the commit DAG enforcement pass:
  1) identify heretical usages
  2) refactor usages to canonical
  3) remove/retire heretical entities from the codebase when safe
  4) rerun typecheck + lint gates

Outcome:
- After strict init completes, the codebase contains only canonical usages for the deduped capability/surface.

## Contract test spec
- Given a repo where two functions represent the same surface
- When init runs (non-strict)
  - Then both are registered; dedupe mapping marks one canonical and one heretical
- When init runs with `--strict`
  - Then code references are refactored to the canonical entity
  - And no heretical references remain
