story_uuid: 7b98e4a1-2e5b-4c92-8d08-5edb7b95e0c1
story_id: US2.9
title: US2.9 project import (story synthesis from existing repo)
required_planes: [ops, integrations]

CONTRACT FORMATION MODE: implementation is irrelevant; do not compare against current code/UI. Define user-expected outcomes and test oracles only.

plane_oracles:
- plane: ops
  oracle: "Importing an existing repo results in a discoverable set of plane-tagged DevFlow stories produced from the codebase, written under ai_docs/context/v2/project_docs/user_stories/."
  anchor: "fs:ai_docs/context/v2/project_docs/user_stories"
- plane: integrations
  oracle: "Generated stories are valid contracts (parseable + validated) and, when missing, DevFlow creates corresponding red test placeholders that reference the new story ids/uuids." 
  anchor: "cli:devflow plan/story + tests markers"

# US2.9 — Importing an existing repo synthesizes DevFlow user stories (per plane) and creates missing red tests

## Story
As a DevFlow operator,
I want DevFlow to analyze an imported repository and create/update DevFlow user stories,
so that the repo can be onboarded into the plane-based contract workflow.

## Command surface
- `devflow project import <repo_spec> --synthesize-stories`

## Acceptance criteria
1. **Discover or create story docs root**
   - In the imported repo root, DevFlow ensures the docs root exists:
     - `ai_docs/context/v2/project_docs/user_stories/`
   - It is created if missing.

2. **Generate plane-tagged stories**
   - DevFlow generates at least one story file per required plane detected/selected.
   - Planes are the DevFlow planes used elsewhere (e.g., ops, ui, api, integrations, config, filesystem, auth).

3. **Idempotent updates**
   - Re-running synthesis does not duplicate stories; it updates existing artifacts or writes a stable “already exists” result.

4. **Validity**
   - Generated story markdowns are parseable by the story contract parser and pass validation rules.

5. **Red test stubs when missing**
   - If the repo lacks contract tests referencing a generated story id/uuid, DevFlow creates a minimal red test file stub under the repo’s test root (policy-defined, but deterministic) that:
     - includes pytest markers for `story_id`, `story_uuid`, and `plane`
     - contains a failing assertion with a clear TODO message

## Non-goals
- Perfect story quality; initial synthesis can be minimal and conservative.
- Full semantic code understanding.

## Determinism notes
- Story ids/uuids are stable across reruns for the same repo + plane + story slug.
- Output ordering is stable.
