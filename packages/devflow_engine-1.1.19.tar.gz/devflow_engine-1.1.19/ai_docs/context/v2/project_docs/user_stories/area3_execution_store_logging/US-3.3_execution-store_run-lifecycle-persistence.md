story_uuid: 1a0c8750-9ad9-43dc-9130-07d60f2a9b68
story_id: US-3.3
title: US-3.3 execution-store run-lifecycle-persistence
required_planes: [api, ops]

CONTRACT FORMATION MODE: implementation is irrelevant; do not compare against current code/UI. Define user-expected outcomes and test oracles only.

plane_oracles:
- plane: api
  oracle: "The engine exposes deterministic programmatic behavior and data models required by US-3.3_execution-store_run-lifecycle-persistence (inputs/outputs and persistence semantics)."
  anchor: "api:US-3.3_execution-store_run-lifecycle-persistence"
- plane: ops
  oracle: "Operational side effects for US-3.3_execution-store_run-lifecycle-persistence are deterministic and documented (files/dirs created, idempotency, and safe failure modes)."
  anchor: "docs:user_story/US-3.3_execution-store_run-lifecycle-persistence"
# US-3.3 — Persist run lifecycle events (create/start/finish/status)

## User story
As a DevFlow operator,
I want each DAG run’s lifecycle transitions persisted in the execution store,
so that I can reliably determine what happened (and when), even if the process crashes.

## Scope
- Persist the run record at creation time.
- Update status and timestamps on start/finish.
- Record run-level errors.
- Ensure state transitions are consistent and idempotent.

## Out of scope
- Retry orchestration policy (handled by scheduler/engine stories).
- UI/CLI commands (may be built later, but DB contract must support them).

## Contract
### Functional requirements
1. **Create run**
   - On run planning/launch, insert into `runs` with:
     - `status='queued'` (or `running` if immediate)
     - `root_correlation_id`
     - `dag_id` (+ optional `dag_version`)
     - sanitized `config_json`

2. **Start run**
   - When execution begins, transition to `status='running'` and set `started_at` if unset.
   - Must be safe to call multiple times (idempotent).

3. **Finish run**
   - On success: `status='succeeded'`, set `finished_at`.
   - On failure: `status='failed'`, set `finished_at`, and ensure at least one `errors` row exists at scope `run` or `node`.
   - On cancel: `status='canceled'` with `finished_at`.

4. **Crash tolerance**
   - If the process crashes mid-run, the DB must still contain a `runs` row in `running` state with `started_at` set.
   - On next startup, the system can detect “stale running” runs (future story may reconcile; this story only ensures the data exists).

5. **Correlation**
   - The `root_correlation_id` is propagated to all node/tool records and to the on-disk log layout (see US-3.6).

### Data requirements
- Enforce allowed statuses using application-level validation.
- Maintain `updated_at` on each status change.

### Observability requirements
- Emit structured logs for run transitions:
  - `event='run.created'|'run.started'|'run.finished'`
  - `run_id`, `dag_id`, `status`, `root_correlation_id`
  - include reason on failure/cancel

## Acceptance criteria
- [ ] A run row is present before any node execution starts.
- [ ] `started_at` is set when transitioning to running.
- [ ] `finished_at` is set exactly once per run completion.
- [ ] On error, `runs.status='failed'` and a corresponding `errors` row exists.
- [ ] Repeated calls to start/finish do not corrupt state.

## Test plan
- Unit: create/start/finish transitions with idempotency.
- Integration: simulate exception mid-run; verify run row exists and logs are written.
