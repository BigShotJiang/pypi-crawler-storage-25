story_uuid: 7d96d25c-a65b-4a70-84ce-5e3f2178f803
story_id: DF2-STORY-401
title: Canonical user stories document (single source of truth)
required_planes: [auth, api, ui, integrations, ops]

CONTRACT FORMATION MODE: implementation is irrelevant; do not compare against current code/UI. Define user-expected outcomes and test oracles only.

## Intent
As a DevFlow contributor, I want a canonical, stable location for user stories so that tools and humans can reliably discover the current contract set.

## Scope
- Canonical user story content exists at:
  - `devflow_engine/ai_docs/context/v2/project_docs/user_stories.md`
- The canonical document is authoritative for “current contracts”
- The canonical document can reference or embed optional story artifacts stored under:
  - `devflow_engine/ai_docs/context/v2/project_docs/user_stories/**/*.md`

## Out of scope
- How stories are authored (LLM vs human)
- UI for editing stories
- Any external publishing (e.g., website)

plane_oracles:
- plane: auth
  oracle: "Story discovery and reading must not require credentials or secrets; all artifacts are local repo files."
  anchor: "fs:repo checkout"
- plane: api
  oracle: "There is a deterministic programmatic way to load the canonical story set from the canonical markdown."
  anchor: "api:story-loader(canonical_path)"
- plane: ui
  oracle: "A human can open `user_stories.md` and understand where the canonical contracts live and how to navigate to story artifacts."
  anchor: "docs:user_stories.md header + links"
- plane: integrations
  oracle: "Optional per-story artifacts may exist, but their presence must not break canonical discovery."
  anchor: "fs:missing optional artifact"
- plane: ops
  oracle: "A clean checkout includes the canonical file at the fixed path; tooling can depend on it without configuration."
  anchor: "ops:fixed path contract"

## Acceptance criteria
- MUST include a canonical markdown file at `devflow_engine/ai_docs/context/v2/project_docs/user_stories.md`.
- MUST state that the canonical file is the authoritative source of the current user story contracts.
- MUST allow (but not require) additional story markdown files to exist under `.../user_stories/**`.
- MUST define how canonical content relates to optional artifacts (e.g., canonical contains the story headers and references optional artifact files).
- MUST be readable without executing any code (plain markdown).

## Contract test specs
1) Canonical path presence
   - Given a fresh checkout of the repo
   - When the tester checks for `devflow_engine/ai_docs/context/v2/project_docs/user_stories.md`
   - Then the file exists
   - And it is valid UTF-8 text

2) Canonical file declares authority
   - Given the canonical file
   - When the tester reads the top section
   - Then it explicitly states it is the authoritative source of current story contracts

3) Optional artifacts are optional
   - Given the canonical file exists
   - And there are zero files under `.../user_stories/**`
   - When the tooling loads stories
   - Then canonical discovery still succeeds
