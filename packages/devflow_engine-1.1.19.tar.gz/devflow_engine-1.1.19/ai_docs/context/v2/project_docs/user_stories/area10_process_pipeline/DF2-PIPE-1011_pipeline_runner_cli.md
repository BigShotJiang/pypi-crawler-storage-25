story_uuid: 5bfe0f59-94b5-4f7f-b2f0-8fdbe1dcf1b6
story_id: DF2-PIPE-1011
title: Pipeline runner CLI (production pipeline entrypoint)
required_planes: [ops, integrations]

CONTRACT FORMATION MODE: implementation is irrelevant; do not compare against current code/UI. Define user-expected outcomes and test oracles only.

plane_oracles:
- plane: ops
  oracle: "A single CLI entrypoint runs a story through the production pipeline and persists a coherent run timeline."
  anchor: "cli:devflow pipeline run"
- plane: integrations
  oracle: "The pipeline composes existing subflows (impl DAG, review packaging, validators) rather than reimplementing them."
  anchor: "subflow:Area6/Area7/validators"

# DF2-PIPE-1011 — Pipeline runner CLI

## Story
As a DevFlow operator,
I want `devflow pipeline run` to orchestrate the production pipeline for a selected story,
so that delivery is repeatable and traceable.

## Command surface
- `devflow pipeline run --story <story_uuid> [--json]`

## Acceptance criteria
1. **Entrypoint is story_uuid**
   - Command takes a canonical story_uuid.

2. **Node timeline**
   - Command produces a run_id and persists node timeline for each stage:
     - ValidateStories → InventorySync/ValidateInventory → ImplementationDAG → ValidateTests → PackageForReview (policy)

3. **Block/skip semantics**
   - If a gate fails, later nodes are blocked/skipped but still recorded.

4. **JSON mode**
   - In `--json`, emits a stable schema with run_id + per-stage statuses.

## Contract test spec
- Given a repo with a registered story
- When pipeline run is invoked
- Then it writes a run timeline and returns non-zero if any required stage fails
