# DF2-PLAY-903 — Playground: Scenario registry and discovery

story_uuid: 647b55d0-6a96-49b8-84ae-fe8ca265cb06
story_id: DF2-PLAY-903
title: Playground: Scenario registry and discovery
required_planes: [api, ops]

CONTRACT FORMATION MODE: implementation is irrelevant; do not compare against current code/UI. Define user-expected outcomes and test oracles only.

plane_oracles:
- plane: api
  oracle: "DevFlow can enumerate runnable playground scenarios for a project and present stable identifiers (scenario slugs) used to execute them."
  anchor: "command:devflow play list --json"

- plane: ops
  oracle: "Scenario discovery is deterministic and produces reproducible ordering and metadata in the execution store for audit."
  anchor: "sqlite:.devflow/execution.sqlite events(kind=playground.discover)"

## Story statement
As a developer, I want DevFlow to discover and list the project’s playground scenarios, so that I can run specific scenarios or batches reliably.

## Outcome oracle (user-observable)
- A CLI command lists scenarios with slugs and descriptions.

## Preconditions
- Repo contains a recognized playground scenario source (per project conventions).

## Steps
1. Run `devflow play list`.
2. Select a scenario slug.

## Acceptance criteria
1. MUST return stable `scenario_slug` identifiers.
2. MUST include enough metadata to choose a scenario (name/description/category if available).
3. MUST NOT require executing scenarios to list them.

## Non-goals
- Not defining the scenario DSL/source format here.

## Contract test spec (Given/When/Then)
- Given a repo with N discoverable scenarios
- When I run `devflow play list --json`
- Then I receive a JSON list with N items and stable slugs
- And the discovery action is recorded in the execution store
