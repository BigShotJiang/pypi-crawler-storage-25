story_uuid: 090bbc53-7150-4b60-a926-193593d08df1
story_id: US2.4
title: US2.4 project remove
required_planes: [ui, ops]

CONTRACT FORMATION MODE: implementation is irrelevant; do not compare against current code/UI. Define user-expected outcomes and test oracles only.

plane_oracles:
- plane: ui
  oracle: "The user can invoke the documented CLI behavior for US2.4 and receives clear, actionable output on success/failure."
  anchor: "cli:US2.4"
- plane: ops
  oracle: "Operational side effects for US2.4 are deterministic and documented (files/dirs created, idempotency, and safe failure modes)."
  anchor: "docs:user_story/US2.4"
# US2.4 — `devflow project remove` deregisters a project (optionally deletes workspace)

## Story
As a developer,
I want to remove a project from DevFlow,
so that the registry stays clean and I can reclaim disk space safely.

## User-visible behavior
- Command:
  - `devflow project remove <project_id>`
  - Options:
    - `--keep-workspace` (default: keep workspace)
    - `--delete-workspace` (explicit, destructive)
    - `--yes` (skip confirmation for destructive operations)

## Acceptance Criteria
1. **Deregister only (safe default)**
   - Running `devflow project remove <project_id>` removes the registry entry.
   - By default it **does not** delete any files.

2. **Optional workspace deletion**
   - With `--delete-workspace`, DevFlow deletes `workspace_path` for that project.
   - Deletion requires explicit confirmation unless `--yes` is provided.

3. **Guardrails**
   - DevFlow must refuse to delete a workspace if the path:
     - is empty/null
     - is not under `~/.devflow/projects/`
     - resolves via symlink outside the DevFlow projects root

4. **Idempotency**
   - Removing a non-existent `project_id` returns a clear “not found” message and a non-zero exit code.
   - If `--delete-workspace` and the directory is already gone, the command still succeeds after deregistration.

5. **Registry backup**
   - Before rewriting the registry file, DevFlow writes a timestamped backup copy under `~/.devflow/registry/backups/`.

## Non-goals
- Trash/restore UI (but implementers may prefer moving to OS trash over hard delete).
