story_uuid: 9bb3faac-558c-49c0-97a4-1a1746f7a0f6
story_id: DF2-PIPE-1002
title: Production pipeline starts from a specific canonical story (story_uuid)
required_planes: [ops, integrations]

CONTRACT FORMATION MODE: implementation is irrelevant; do not compare against current code/UI. Define user-expected outcomes and test oracles only.

plane_oracles:
- plane: ops
  oracle: "A user/agent can run a single command that drives a selected story through the production pipeline and persists a coherent run timeline."
  anchor: "cli:devflow pipeline run --story <uuid>"
- plane: integrations
  oracle: "The pipeline composes existing subflows (implementation DAG, review packet, validation gates) without duplicating logic or creating parallel code paths."
  anchor: "subflows:Area6+Area7+validators"

# DF2-PIPE-1002 — Production pipeline starts from a story

## Story
As a DevFlow operator,
I want a production pipeline that begins when I select a canonical story,
so that delivery is deterministic and the run is traceable end-to-end.

## Command surface
- `devflow pipeline run --story <story_uuid> [--json]`

## Acceptance criteria
1. **Story as the entrypoint**
   - The pipeline takes a `story_uuid` (canonical contract) as input.

2. **Composes existing DAGs**
   - Pipeline runs (or invokes) the existing Implementation DAG (Area6).
   - Pipeline can optionally package a review packet (Area7 review flow).
   - Pipeline runs validation gates (tests/story/inventory validators).

3. **Single run_id + timeline**
   - The pipeline produces one top-level run_id with node timeline.
   - Subflow runs are linked back to the top-level run.

4. **Gates, not forks**
   - If a gate fails, subsequent nodes are marked blocked/skipped (not reimplemented elsewhere).

## Contract test spec
- Given a registered story
- When pipeline run is invoked
- Then the run persists a node timeline and references subflow artifacts
