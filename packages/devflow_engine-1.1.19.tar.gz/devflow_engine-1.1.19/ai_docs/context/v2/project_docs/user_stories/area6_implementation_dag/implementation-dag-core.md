story_uuid: 6b6a035b-e619-4e2f-a5d2-4ae4b9d31198
story_id: DF2-IMPL-601
title: Implementation DAG core (deterministic stage graph + state transitions)
required_planes: [auth, api, ui, integrations, ops]

CONTRACT FORMATION MODE: implementation is irrelevant; do not compare against current code/UI. Define user-expected outcomes and test oracles only.

## Intent
Provide a deterministic, inspectable “Implementation DAG” that models the default DevFlow v2 TDD workflow stages and their legal transitions.

## User value
As a DevFlow user, I can reliably run an implementation workflow where each stage consumes prior artifacts, produces new artifacts, and either advances or halts with actionable errors.

## Scope
- Define a DAG (or linear graph with explicit edges) containing the default stages:
  1. Normalize
  2. TestDesign (oracle + anchor)
  3. Red (failing tests)
  4. Green (implementation + green gate)
  5. GitCommit(GREEN)
  6. Refactor
  7. VerifyGreen
  8. GitCommit(REFACTOR)
  9. PackageForReview (persist review packet to SQLite)
- Provide machine-readable stage identifiers and ordering constraints.
- Provide a uniform stage result envelope (success/failure + artifacts + telemetry pointers).

## Out of scope
- Any specific test framework implementation (pytest/unittest) beyond contract-level artifacts.
- UI/UX beyond basic CLI visibility into stage progress.

plane_oracles:
- plane: auth
  oracle: "DAG inspection and dry-run planning require no external credentials; no secrets are needed to list stages and edges."
  anchor: "api:impl_dag.describe() (offline)"
- plane: api
  oracle: "The DAG is deterministic: for a given engine version, stage ids, edges, and default order are stable and programmatically retrievable."
  anchor: "python:devflow_engine.impl_dag.get_default_dag()"
- plane: ui
  oracle: "CLI can print a human-readable stage plan showing stage ids, names, and dependencies."
  anchor: "cli:devflow-engine impl plan"
- plane: integrations
  oracle: "Each stage declares its inputs/outputs so external tooling can subscribe to artifact creation (e.g., review packet generation)."
  anchor: "api:stage_contract (io spec)"
- plane: ops
  oracle: "Stage execution is restartable: a failed run can resume from the first failed stage using persisted artifacts/state pointers."
  anchor: "ops:resume-from-stage"

## Acceptance criteria
- MUST define canonical stage identifiers (stable strings) for all default stages listed in Scope.
- MUST define legal transitions/edges between stages (at minimum linear forward edges).
- MUST provide an API to:
  - list stages in execution order
  - list edges/dependencies
  - validate a proposed execution plan
- MUST represent per-stage execution result with:
  - status (success/failure)
  - stage_id
  - produced artifact references (paths/ids)
  - error summary on failure (no stack trace required)
- MUST support a dry-run/plan mode that does not mutate repo state.

## Contract test specs
1) DAG introspection is stable
   - Given a clean checkout
   - When the tester loads the default DAG via the public API
   - Then it contains exactly the default stages from Scope (by stage id)
   - And a deterministic ordered plan can be produced

2) Plan validation
   - Given a plan missing an upstream dependency (e.g., Green without Red)
   - When the tester calls plan validation
   - Then validation fails with an actionable message naming the missing prerequisite stage

3) Dry-run is non-mutating
   - Given a repo with no uncommitted changes
   - When the tester runs a dry-run plan
   - Then git status remains clean
