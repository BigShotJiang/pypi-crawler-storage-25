story_uuid: 7b1be49d-2d00-4cc3-9d99-4e0e9bf4cb93
story_id: DF2-IMPL-611
title: Stage: ValidateTests (contract test linkage + coverage gate; auto-repair until pass)
required_planes: [auth, api, ui, integrations, ops]

CONTRACT FORMATION MODE: implementation is irrelevant; do not compare against current code/UI. Define user-expected outcomes and test oracles only.

## Intent
Provide a deterministic, autonomous gate that ensures the contract test suite is properly linked to story contracts and that there are no orphaned stories or orphaned tests.

## User value
As a developer, I can trust that "RED tests" represent actual contractual coverage and are not drifting, unlabeled, or greenwashing via missing linkage.

## Scope
- Input:
  - canonical story contracts under `ai_docs/context/**/user_stories/**`
  - tests under `tests/**`
- Output:
  - validation report (human + JSON)
  - repaired tests and/or story metadata when needed
  - persisted repair provenance (what changed + evidence)

## Out of scope
- Running the full test suite.
- Implementing product behavior.

plane_oracles:
- plane: auth
  oracle: "Test validation and auto-repair must not require secrets and must not call external services by default."
  anchor: "script:scripts/validate_tests.py"
- plane: api
  oracle: "Validator emits a machine-readable JSON report with issue codes and stable file/line references when possible."
  anchor: "script:scripts/validate_tests.py --json"
- plane: ui
  oracle: "CLI output is concise and actionable: it names the failing test(s)/story_id(s) and summarizes repairs performed."
  anchor: "cli:validate-tests summary"
- plane: integrations
  oracle: "Validator enforces anti-pattern bans (e.g., testing mock behavior) using the canonical in-repo reference doc."
  anchor: "docs:devFlow/docs/TESTING_ANTI_PATTERNS.md"
- plane: ops
  oracle: "Gate enforces bidirectional linkage: no orphaned stories (stories without tests) and no orphaned tests (tests linked to unknown stories)."
  anchor: "script:scripts/validate_tests.py (orphan detection)"

## Acceptance criteria
- MUST ensure `scripts/validate_tests.py` exists and can run from a fresh checkout without installing the package.
- MUST validate bidirectional linkage:
  - every canonical story_id has at least one linked test (no orphaned stories)
  - every linked test references a known canonical story_id (no orphaned tests)
  - if tests include story_uuid markers, they must match canonical story docs
- MUST enforce per-test linkage markers for this repo:
  - `@pytest.mark.story_id("...")`
  - `@pytest.mark.story_uuid("...")`
  - `@pytest.mark.plane("...")`
- MUST emit a JSON report (issue_count + issues[]).
- If validation fails, MUST autonomously repair until validation passes.
  - No halt / no ask.
  - No placeholders/stubs/TODOs introduced to satisfy validation.
  - Repairs are best-effort evidence-based; when ambiguous, make deterministic ranked assertions and proceed.
- MUST enforce testing anti-pattern bans at minimum per `devFlow/docs/TESTING_ANTI_PATTERNS.md`.

## Contract test specs
1) Orphan detection
   - Given a repo with a test linked to a non-existent story_id
   - When ValidateTests runs
   - Then it reports an orphaned-test issue and repairs linkage to a canonical story_id (best-effort) and re-validates

2) Orphaned story detection
   - Given a repo with a canonical story_id that has no tests
   - When ValidateTests runs
   - Then it reports an orphaned-story issue and repairs by materializing at least one linked test (best-effort) and re-validates
