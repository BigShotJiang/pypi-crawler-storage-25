story_uuid: a0baa7d5-ca34-4296-a9d6-022ec9320d98
story_id: US2.6
title: US2.6 config hierarchy resolution
required_planes: [ui, ops]

CONTRACT FORMATION MODE: implementation is irrelevant; do not compare against current code/UI. Define user-expected outcomes and test oracles only.

plane_oracles:
- plane: ui
  oracle: "The user can invoke the documented CLI behavior for US2.6 and receives clear, actionable output on success/failure."
  anchor: "cli:US2.6"
- plane: ops
  oracle: "Operational side effects for US2.6 are deterministic and documented (files/dirs created, idempotency, and safe failure modes)."
  anchor: "docs:user_story/US2.6"
# US2.6 — Config hierarchy: global DevFlow config vs project config

## Story
As a developer,
I want DevFlow to resolve configuration from a clear precedence order,
so that I can set global defaults while allowing projects to override what they need.

## Definitions
- **Global config**: user-level defaults under `~/.devflow/` (e.g., `~/.devflow/config.toml`).
- **Project config**: config stored inside a specific project workspace (e.g., `<workspace>/.devflow/config.toml`).

## Acceptance Criteria
1. **Clear precedence order**
   When DevFlow resolves a config value, it uses (highest → lowest precedence):
   1) CLI flags / environment variables (if supported)
   2) Project config (`<workspace>/.devflow/config.*`)
   3) Global config (`~/.devflow/config.*`)
   4) Built-in defaults

2. **Project lookup**
   - If the user runs a command inside a git repo, DevFlow can determine the associated `project_id` and its workspace.
   - If run outside a repo, the user can specify `--project <project_id>` and DevFlow resolves config accordingly.

3. **Explainability**
   - `devflow config get <key> --explain` shows:
     - final value
     - source layer (global vs project vs default)
     - file path (when applicable)

4. **Safe partial configs**
   - Missing keys in project config fall back to global config.
   - Invalid config file format results in:
     - a clear error message
     - location of the file
     - line/field when available

## Non-goals
- Complex cascading across multiple project configs.
- Secret management (handled elsewhere).

## Test cases
- Key present globally only → resolved.
- Key present in project only → overrides global.
- Key present in both → project wins.
- `--explain` reflects correct source.
