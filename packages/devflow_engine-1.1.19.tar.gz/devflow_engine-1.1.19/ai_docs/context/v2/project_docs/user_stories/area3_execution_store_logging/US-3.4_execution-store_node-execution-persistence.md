story_uuid: a195ca88-f3bd-44e4-9dbb-4ea309a2f5bb
story_id: US-3.4
title: US-3.4 execution-store node-execution-persistence
required_planes: [api, ops]

CONTRACT FORMATION MODE: implementation is irrelevant; do not compare against current code/UI. Define user-expected outcomes and test oracles only.

plane_oracles:
- plane: api
  oracle: "The engine exposes deterministic programmatic behavior and data models required by US-3.4_execution-store_node-execution-persistence (inputs/outputs and persistence semantics)."
  anchor: "api:US-3.4_execution-store_node-execution-persistence"
- plane: ops
  oracle: "Operational side effects for US-3.4_execution-store_node-execution-persistence are deterministic and documented (files/dirs created, idempotency, and safe failure modes)."
  anchor: "docs:user_story/US-3.4_execution-store_node-execution-persistence"
# US-3.4 — Persist node execution attempts (status, timings, inputs/outputs)

## User story
As a DevFlow operator,
I want each node execution attempt persisted (including retries),
so that I can diagnose failures, understand performance, and reproduce results.

## Scope
- Insert/update `nodes` rows for each node attempt.
- Record status transitions and timing.
- Store sanitized, size-bounded input/output summaries.
- Ensure node attempt uniqueness and link to run.

## Contract
### Functional requirements
1. **Node attempt creation**
   - Before a node starts executing, insert `nodes` row:
     - `(run_id, node_id, attempt)`
     - `status='queued'` or `running`
     - `correlation_id` generated for this node attempt
     - optional `node_name`

2. **Node start**
   - Transition to `status='running'`, set `started_at` if unset.

3. **Node finish**
   - Success: set `status='succeeded'`, set `finished_at`.
   - Failure: set `status='failed'`, set `finished_at`, and insert an `errors` row linked to `node_exec_id`.
   - Skip/cancel: set `status='skipped'` or `canceled` with `finished_at`.

4. **Inputs/outputs**
   - Persist sanitized summaries (not full raw prompts/secrets).
   - If payload exceeds size limit, write to a file artifact and store a reference in `artifacts`.

5. **Retry support**
   - Each retry creates a new `nodes` row with incremented `attempt`.
   - Queries can show latest attempt status per `node_id`.

### Observability requirements
- Structured logs for node lifecycle:
  - `event='node.created'|'node.started'|'node.finished'`
  - `run_id`, `node_id`, `node_exec_id`, `attempt`, `status`, `correlation_id`

## Acceptance criteria
- [ ] For each node attempt, a `nodes` row exists with accurate status and timestamps.
- [ ] Unique constraint `(run_id,node_id,attempt)` prevents duplicates.
- [ ] On failure, an `errors` row exists referencing `node_exec_id`.
- [ ] Large IO is stored as artifact references rather than bloating SQLite.

## Test plan
- Unit: create/start/finish for nodes with idempotent updates.
- Unit: retry creates new attempt.
- Integration: run a DAG with multiple nodes; verify node rows and transitions.
