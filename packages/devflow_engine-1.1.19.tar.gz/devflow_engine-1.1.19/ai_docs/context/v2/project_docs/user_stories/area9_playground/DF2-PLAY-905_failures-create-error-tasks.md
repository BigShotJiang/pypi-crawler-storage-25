# DF2-PLAY-905 — Playground: Failures create error tasks

story_uuid: f19de83c-9133-45a4-9bd0-d99c4e6e7862
story_id: DF2-PLAY-905
title: Playground: Failures create error tasks
required_planes: [integrations, ops]

CONTRACT FORMATION MODE: implementation is irrelevant; do not compare against current code/UI. Define user-expected outcomes and test oracles only.

plane_oracles:
- plane: integrations
  oracle: "When a scenario fails, DevFlow creates (or updates) an error task with a stable fingerprint, linking to the run logs and artifacts."
  anchor: "sqlite:.devflow/execution.sqlite errors(fingerprint=...) + artifacts(run_id=...)"

- plane: ops
  oracle: "Error ingestion is idempotent: rerunning the same failing scenario does not create duplicate error tasks; it increments occurrence counters and links new evidence."
  anchor: "command:devflow error list --json"

## Story statement
As a developer, I want failed playground scenarios to automatically generate error tasks, so that remediation is queued and tracked without manual transcription.

## Outcome oracle (user-observable)
- After a failing scenario run, `devflow error list` shows a corresponding error item.

## Preconditions
- Error queue exists.

## Steps
1. Run a scenario that fails.
2. DevFlow creates/updates an error task.

## Acceptance criteria
1. MUST create an error task with a deterministic fingerprint derived from scenario + failure signature.
2. MUST link the error task to the run_id and artifact paths.
3. MUST NOT leak secrets from logs/artifacts into the error summary.
4. MUST dedupe repeated failures into the same error task when fingerprint matches.

## Non-goals
- Not defining the remediation workflow itself.

## Contract test spec (Given/When/Then)
- Given a failing scenario with stable failure signature
- When I run it twice
- Then only one error task exists for the fingerprint and its occurrence count increases
- And both runs are linked as evidence
