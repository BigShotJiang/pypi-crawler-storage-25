story_uuid: 52bbce64-5e59-48ed-8dc4-6a14956e86ee
story_id: US2.3
title: US2.3 project registry list
required_planes: [ui, ops]

CONTRACT FORMATION MODE: implementation is irrelevant; do not compare against current code/UI. Define user-expected outcomes and test oracles only.

plane_oracles:
- plane: ui
  oracle: "The user can invoke the documented CLI behavior for US2.3 and receives clear, actionable output on success/failure."
  anchor: "cli:US2.3"
- plane: ops
  oracle: "Operational side effects for US2.3 are deterministic and documented (files/dirs created, idempotency, and safe failure modes)."
  anchor: "docs:user_story/US2.3"
# US2.3 — `devflow project list` reads the project registry

## Story
As a developer,
I want to list the projects DevFlow knows about,
so that I can quickly see what is registered and where each project lives locally.

## User-visible behavior
- Command: `devflow project list`
- Output: human-readable list by default; optional `--json` for machine use.

## Acceptance Criteria
1. **Registry location**
   - DevFlow stores project registrations in a single local registry file under `~/.devflow/registry/`.
   - Proposed path: `~/.devflow/registry/projects.json` (exact filename can vary, but must be stable and documented).

2. **List includes essential columns**
   - For each project:
     - `project_id`
     - `owner/repo`
     - `workspace_path`
     - `remote_url` or `source_path`
     - `last_used_at` (if tracked)

3. **Stable ordering**
   - Default ordering is deterministic (e.g., by `owner/repo`, then `project_id`) or by recency if `--recent` is used.

4. **Resilience to partial corruption**
   - If the registry file contains an entry missing optional fields, list still works.
   - If the registry file is unreadable/corrupt:
     - DevFlow fails with a clear message and suggests a recovery path (e.g., `registry repair` or manual backup restore).

5. **`--json` contract**
   - `devflow project list --json` outputs a JSON array of objects with a versioned top-level schema field, e.g. `{ "schema_version": 1, "projects": [...] }`.

## Non-goals
- UI beyond CLI output.
- Syncing registry across machines.
