story_uuid: 7b5c11c8-6a8b-4a44-9d45-7d5636b14a1a
story_id: DF2-PROC-1001
title: Ideation/Planning loop produces transitional user stories from an idea
required_planes: [ui, ops]

CONTRACT FORMATION MODE: implementation is irrelevant; do not compare against current code/UI. Define user-expected outcomes and test oracles only.

plane_oracles:
- plane: ui
  oracle: "An agent/user can iteratively refine an idea into a set of traditional (transitional) user stories with clear scope, acceptance criteria, and plane tags using CLI tools."
  anchor: "cli:devflow idea *"
- plane: ops
  oracle: "Planning artifacts are persisted deterministically under .devflow/ideas/<idea_id>/ with provenance and redaction, and can be regenerated without duplicating state."
  anchor: "fs:.devflow/ideas/*"

# DF2-PROC-1001 — Ideation/Planning loop produces transitional user stories

## Story
As a DevFlow operator (human or agent),
I want a dedicated ideation/planning process that turns a fuzzy idea into transitional user stories,
so that I can iterate with a user before committing to the production pipeline.

## Command surface (anchors)
- `devflow idea init --idea <id> --title <title>`
- `devflow idea analyze --idea <id>`
- `devflow idea drafts generate --idea <id> --analysis <analysis_id> --planes <planes>`
- `devflow idea drafts diff ...` (optional)

## Acceptance criteria
1. **Iterative planning loop**
   - The tooling supports repeatable cycles of: edit idea → analyze → generate draft stories.

2. **Traditional/transitional story format**
   - Draft stories may be “traditional” user stories (not yet fully DevFlow-canonical).
   - Each draft includes enough structure to review: intent, scope, acceptance criteria.

3. **Silent DevFlow adaptation (when promoted)**
   - When drafts are promoted into canonical contracts, DevFlow adapts formatting/headers/planes silently.

4. **Offline/deterministic artifacts**
   - No network calls are required.
   - Artifacts are stable and provenance-tagged.

## Non-goals
- Implementing the production pipeline here.

## Contract test spec (Given/When/Then)
- Given an idea and a repo
- When drafts are generated for selected planes
- Then a draft_set is created with per-plane story drafts and a manifest
