story_uuid: 6aa0d743-cb39-4b52-b225-a373c98f0f7d
story_id: DF2-STORY-402
title: Optional per-story artifacts directory layout (user_stories/**/*.md)
required_planes: [auth, api, ui, integrations, ops]

CONTRACT FORMATION MODE: implementation is irrelevant; do not compare against current code/UI. Define user-expected outcomes and test oracles only.

## Intent
As a DevFlow maintainer, I want optional per-story artifact files so that stories can be decomposed into smaller markdown documents (e.g., per area) without losing canonical discovery.

## Scope
- A conventional directory exists for story artifacts:
  - `devflow_engine/ai_docs/context/v2/project_docs/user_stories/`
- Story artifacts under that directory may be organized arbitrarily via subfolders (e.g., `area4_story_system/`)
- Story artifact files follow the “contract” markdown format (YAML-ish header + sections)

## Out of scope
- Enforcing a single folder taxonomy
- Rich metadata extraction beyond what the contract requires

plane_oracles:
- plane: auth
  oracle: "Story artifacts must be plain files; no authentication needed to read them."
  anchor: "fs:local markdown"
- plane: api
  oracle: "Tooling can enumerate optional story artifact files via a stable glob rooted at `.../user_stories/`."
  anchor: "api:glob user_stories/**/*.md"
- plane: ui
  oracle: "A human can navigate by folder (areas) and open a single story file to see the complete contract."
  anchor: "docs:per-story md"
- plane: integrations
  oracle: "Artifacts can be added/removed without requiring updates to unrelated tooling configs (discovery-by-convention)."
  anchor: "integration:convention over config"
- plane: ops
  oracle: "CI can validate story artifacts via deterministic paths and globs."
  anchor: "ops:ci validate stories"

## Acceptance criteria
- MUST define `devflow_engine/ai_docs/context/v2/project_docs/user_stories/` as the root for optional per-story artifact files.
- MUST allow nested subfolders under `user_stories/`.
- MUST specify that artifact markdown files use the same story contract header keys as canonical stories (at minimum: `story_uuid`, `story_id`, `title`).
- MUST specify that artifact filenames and folders are non-authoritative; story identity is based on metadata.

## Contract test specs
1) Artifact root discovery
   - Given a repo checkout
   - When the tester lists `devflow_engine/ai_docs/context/v2/project_docs/user_stories/`
   - Then the directory exists (may be empty)

2) Metadata-based identity
   - Given two artifact files with different filenames
   - And both declare distinct `story_uuid`
   - When tooling indexes stories
   - Then it treats them as distinct stories regardless of filename

3) Non-breaking removals
   - Given a previously indexed artifact file is deleted
   - When tooling re-indexes
   - Then the index updates without error
   - And remaining stories are still discoverable
