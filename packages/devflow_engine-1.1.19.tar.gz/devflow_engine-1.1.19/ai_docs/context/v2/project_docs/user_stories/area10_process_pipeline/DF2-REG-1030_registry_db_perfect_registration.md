story_uuid: 4b6a0b8b-6e90-4f76-a43c-6c9d6ff3a2c1
story_id: DF2-REG-1030
title: Registry DB enforces perfect registration (project-files-only scan; no exceptions)
required_planes: [ops]

CONTRACT FORMATION MODE: implementation is irrelevant; do not compare against current code/UI. Define user-expected outcomes and test oracles only.

plane_oracles:
- plane: ops
  oracle: "A repo is blocked from progressing until all discovered imports/surfaces in project files are registered in the registry DB. No exceptions/ignore-list escape hatch exists."
  anchor: "cli:devflow registry validate"

# DF2-REG-1030 — Registry DB with perfect registration (no exceptions)

## Story
As a DevFlow operator,
I want an authoritative registry database that enforces perfect registration of all discovered imports and seams within project-owned files,
so that nothing can slip through the cracks and the repo is blocked until compliant.

## Registry model
- Authoritative store: repo-local SQLite at `.devflow/registry.sqlite`

Minimum tables:
- `imports` — discovered import edges (importer → specifier)
- `registered_items` — approved internal modules and seam items
- `allowed_packages` — approved external packages

Non-goal: no `exceptions` or `policy_exclusions` tables.

## Policy
1) **No exceptions escape hatch**
   - There is no mechanism to bypass validation for a specific import or file.

2) **Project-files-only scan**
   - Discovery/validation only considers project-owned source roots.
   - External/generated directories are ignored by definition (not by exception).

3) **Perfect registration**
   - Every discovered import must map to:
     - a row in `allowed_packages` (external import specifier) OR
     - a row in `registered_items` (internal module id).
   - Missing mappings fail the validator.

## Command surface
- `devflow registry init` (initial scan + bootstrap registry DB)
- `devflow registry scan` (update DB from current repo state)
- `devflow registry validate` (fail if any unregistered imports exist)
- `devflow registry report --json` (machine-readable reconciliation packet)

## Contract test spec
- Given a repo with an unregistered import in project files
- When validate runs
- Then it fails and emits a reconciliation packet listing missing registrations
