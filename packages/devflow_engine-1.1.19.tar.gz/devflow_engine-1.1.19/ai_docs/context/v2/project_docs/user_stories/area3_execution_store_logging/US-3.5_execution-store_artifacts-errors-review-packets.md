story_uuid: 3b984b7f-e34b-45b6-bb50-9d33d0e55cd3
story_id: US-3.5
title: US-3.5 execution-store artifacts-errors-review-packets
required_planes: [ui, ops]

CONTRACT FORMATION MODE: implementation is irrelevant; do not compare against current code/UI. Define user-expected outcomes and test oracles only.

plane_oracles:
- plane: ui
  oracle: "The user can invoke the documented CLI behavior for US-3.5_execution-store_artifacts-errors-review-packets and receives clear, actionable output on success/failure."
  anchor: "cli:US-3.5_execution-store_artifacts-errors-review-packets"
- plane: ops
  oracle: "Operational side effects for US-3.5_execution-store_artifacts-errors-review-packets are deterministic and documented (files/dirs created, idempotency, and safe failure modes)."
  anchor: "docs:user_story/US-3.5_execution-store_artifacts-errors-review-packets"
# US-3.5 — Persist artifacts, errors, and review packets

## User story
As a DevFlow operator,
I want execution artifacts, structured errors, and review packets recorded consistently,
so that I can inspect outputs, understand failures, and support human-in-the-loop flows.

## Scope
- Define write-path contracts for:
  - `artifacts` (files/URIs + metadata)
  - `errors` (structured error capture)
  - `review_packets` (request/response lifecycle)
- Establish size limits and redaction rules.

## Contract
### Artifacts
1. **Artifact creation**
   - When the engine generates an output worth retaining (logs, tool traces, files, screenshots), it inserts an `artifacts` row.
   - Artifacts are referenced by `uri` (typically path under `.devflow/`), not stored as blobs.

2. **Artifact kinds**
   - Define a small stable set of `kind` values (extensible):
     - `log`, `file`, `json`, `image`, `tool_trace`, `review_packet`

3. **Integrity fields (optional but recommended)**
   - If feasible, compute `sha256` and `byte_size` for files.

4. **Linkage**
   - Every artifact links to `run_id`.
   - Node-specific artifacts also link to `node_exec_id`.

### Errors
1. **Error capture**
   - On exceptions, insert into `errors` with:
     - `scope` (`run|node|tool|system`)
     - `error_type` (class/category)
     - `message` (human-readable)
     - `stacktrace` (string)
     - `cause_json` (optional structured fields)
     - `correlation_id` (run or node correlation)

2. **Redaction**
   - Strip secrets from error messages/stacktraces when possible.
   - Never store raw credentials.

3. **Status coupling**
   - When a node fails, update `nodes.status='failed'` and ensure an `errors` row exists.
   - When a run fails, update `runs.status='failed'` and ensure at least one `errors` row exists for the run.

### Review packets
1. **Create review request**
   - Insert `review_packets` with `status='pending'` and `request_json`.

2. **Complete review**
   - Update with `status='approved'|'rejected'` and `response_json`.

3. **Supersede**
   - If a review is replaced by a new packet, mark prior as `superseded`.

4. **Artifact linkage**
   - Optionally store large review payloads as file artifacts and reference them.

## Acceptance criteria
- [ ] Artifacts can be created and queried per run/node.
- [ ] Errors are inserted with correct scope/linkage and correlation id.
- [ ] Review packets support pending→approved/rejected transitions.
- [ ] Payloads are size-bounded and secrets are not persisted.

## Test plan
- Unit: create artifact rows with/without node linkage.
- Unit: error insertion on exception; verify DB + logs.
- Unit: review packet transitions and supersede behavior.
