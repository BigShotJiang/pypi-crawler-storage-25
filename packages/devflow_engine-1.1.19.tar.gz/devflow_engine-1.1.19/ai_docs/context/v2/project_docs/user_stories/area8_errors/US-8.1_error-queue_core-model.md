story_uuid: 8b9c0f49-7f10-4bff-8f76-0db1d0f74b08
story_id: US-8.1
title: US-8.1 error-queue core-model
required_planes: [api, ops]

CONTRACT FORMATION MODE: implementation is irrelevant; do not compare against current code/UI. Define user-expected outcomes and test oracles only.

plane_oracles:
- plane: api
  oracle: "The engine exposes deterministic programmatic behavior and data models required by US-8.1_error-queue_core-model (inputs/outputs and persistence semantics)."
  anchor: "api:US-8.1_error-queue_core-model"
- plane: ops
  oracle: "Operational side effects for US-8.1_error-queue_core-model are deterministic and documented (files/dirs created, idempotency, and safe failure modes)."
  anchor: "docs:user_story/US-8.1_error-queue_core-model"
# US-8.1 — Error Queue: core model + lifecycle

## User story
As a DevFlow operator,
I want a first-class error queue with a consistent lifecycle,
so that failures from any source (engine runs, external systems, humans) can be triaged, worked, and closed in a repeatable way.

## Scope
- Define the **canonical Error Task** model (“error queue item”) distinct from low-level `errors` captured during execution.
- Define allowed statuses and transitions.
- Define required metadata and linkage to projects/runs/stories.

## Out of scope
- UI (web) presentation.
- Full-text search.
- Auto-remediation logic (covered in US-8.4+).

## Contract
### Definitions
- **Execution error**: a raw captured exception/failure emitted by a run/node/tool (see execution store `errors`).
- **Error task**: a durable queue item representing an actionable problem to be solved (this story).

### Functional requirements
1. **Create error tasks**
   - The system can create an error task from:
     - an execution error (run/node failure)
     - a GitHub issue (see US-8.6)
     - a manual operator action (future CLI/API)

2. **Minimal required fields**
   - Each error task MUST have:
     - `error_task_id` (UUID)
     - `project_id` (nullable only if the source is truly global)
     - `title` (short summary)
     - `status`
     - `severity` (e.g., `low|medium|high|critical`)
     - `source_kind` (e.g., `execution|github|manual`)
     - `source_ref` (string identifier; e.g., `run_id`, `issue_url`)
     - `fingerprint` (stable dedupe key; see US-8.3)
     - `created_at`, `updated_at`

3. **Lifecycle statuses**
   - Allowed statuses (canonical set):
     - `open` — newly created, untriaged
     - `triaged` — categorized, ready to work
     - `in_progress` — actively being worked by an agent/human
     - `blocked` — waiting on external dependency
     - `remediating` — a remediation run is executing (see US-8.4)
     - `resolved` — fix exists; awaiting verification
     - `closed` — verified solved / not actionable
     - `duplicate` — superseded by another error task
     - `ignored` — intentionally not addressed (must record reason)

4. **State transition rules**
   - Transitions MUST be validated and persisted as events (audit log).
   - Minimum allowed transitions:
     - `open → triaged|ignored|duplicate`
     - `triaged → in_progress|blocked|ignored|duplicate`
     - `in_progress → blocked|remediating|resolved|ignored|duplicate`
     - `blocked → in_progress|ignored|duplicate`
     - `remediating → in_progress|resolved|blocked` (depending on outcome)
     - `resolved → closed|in_progress` (reopened)
     - `duplicate|ignored|closed` are terminal unless explicitly reopened by operator.

5. **Assignments (lightweight)**
   - Error tasks MAY include `assignee` and `claimed_at`.
   - The system MUST support “claim” semantics to prevent two workers from taking the same task (see US-8.2).

### Data requirements
- Execution store (or error store) MUST add tables (names indicative):
  - `error_tasks`
  - `error_task_events` (append-only audit log)
- `error_task_events` MUST capture:
  - `event_type` (created/transition/comment/link/etc)
  - `from_status`, `to_status` (when applicable)
  - `actor_kind` (`system|agent|human`)
  - `payload_json` (bounded size)

### Observability requirements
- Emit structured logs on create + transition:
  - `event='error_task.created'|'error_task.transition'`
  - `error_task_id`, `project_id`, `status`, `source_kind`

## Acceptance criteria
- [ ] Error tasks can be created with required fields.
- [ ] Status transitions are validated against the allowed graph.
- [ ] All transitions are recorded in an append-only event log.
- [ ] Terminal statuses cannot change without explicit “reopen” action.

## Test plan
- Unit: validate each permitted transition; reject invalid transitions.
- Integration: create error task → triage → in_progress → resolved → closed; verify events + timestamps.
