story_uuid: 17f7f1ec-ecbb-4572-bb5f-635800ebe469
story_id: US2.2
title: US2.2 project register existing
required_planes: [ui, ops]

CONTRACT FORMATION MODE: implementation is irrelevant; do not compare against current code/UI. Define user-expected outcomes and test oracles only.

plane_oracles:
- plane: ui
  oracle: "The user can invoke the documented CLI behavior for US2.2 and receives clear, actionable output on success/failure."
  anchor: "cli:US2.2"
- plane: ops
  oracle: "Operational side effects for US2.2 are deterministic and documented (files/dirs created, idempotency, and safe failure modes)."
  anchor: "docs:user_story/US2.2"
# US2.2 — `devflow project register` registers an existing repo/path

## Story
As a developer,
I want to register a repository (or an existing local folder) with DevFlow,
so that DevFlow can manage it without requiring me to run commands from inside the repo.

## User-visible behavior
- Command:
  - `devflow project register --path <local_path>`
  - Optional: `--owner <owner> --repo <repo> --remote <url>` (overrides/injection when inference fails)
- Output: prints the created/updated project entry and canonical project id.

## Acceptance Criteria
1. **Input validation**
   - If `--path` does not exist: fail with a clear error.
   - If `--path` exists but is not a git repo:
     - either fail with guidance, or
     - allow registering as a “local-only” project with a path-derived identity (policy must be explicit).

2. **Repo identity inference**
   - If git repo and remote exists, infer:
     - `owner`, `repo`, and `remote_url`
   - If multiple remotes, default to `origin`.
   - If `origin` missing, allow override flags.

3. **Deterministic project id**
   - DevFlow computes `project_id` and workspace directory name deterministically (see US2.5).

4. **Registry write is idempotent**
   - Re-registering the same project does not create duplicate entries.
   - If metadata differs (e.g., updated remote URL), DevFlow updates the existing entry.

5. **No implicit cloning**
   - `project register` does **not** have to clone the repo; it only registers identity + desired workspace.
   - If a workspace exists already, it should be linked.

## Non-goals
- Multi-account Git hosting auth.
- Detecting forks/upstreams beyond identity hashing.

## Data captured in registry
- `project_id`
- `owner`, `repo`
- `remote_url` (optional)
- `source_path` (optional)
- `workspace_path`
- `registered_at`, `updated_at`
