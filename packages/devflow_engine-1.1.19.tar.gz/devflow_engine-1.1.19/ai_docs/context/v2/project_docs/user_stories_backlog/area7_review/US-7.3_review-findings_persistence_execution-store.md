story_uuid: 683d6a30-95c3-4486-9e4a-388fd7dc3dbe
story_id: US-7.3_review-findings_persistence_execution-store
title: US-7.3 review-findings persistence execution-store
required_planes: [ui, ops]

CONTRACT FORMATION MODE: implementation is irrelevant; do not compare against current code/UI. Define user-expected outcomes and test oracles only.

plane_oracles:
- plane: ui
  oracle: "The user can invoke the documented CLI behavior for US-7.3_review-findings_persistence_execution-store and receives clear, actionable output on success/failure."
  anchor: "cli:US-7.3_review-findings_persistence_execution-store"
- plane: ops
  oracle: "Operational side effects for US-7.3_review-findings_persistence_execution-store are deterministic and documented (files/dirs created, idempotency, and safe failure modes)."
  anchor: "docs:user_story/US-7.3_review-findings_persistence_execution-store"
# US-7.3 — Persist review runs and findings in the Execution Store

## User story
As a DevFlow operator,
I want each review run (inputs, outputs, findings) persisted to the execution store,
so that review results are auditable, queryable, and linkable to the implementation run.

## Scope
- Add execution-store entities for:
  - review runs
  - findings
  - artifacts produced by review (report JSON, summary MD, remediation specs)
- Link reviews to the original run (or change ref) being reviewed.

## Out of scope
- Full-text search UI over findings.
- Cross-project analytics dashboards.

## Contract

### Functional requirements
1. **Review run lifecycle**
   - Persist a `review_run` record with:
     - `review_run_id`
     - `status`: `queued|running|succeeded|failed|canceled`
     - timestamps: `created_at|started_at|finished_at`
     - `project_id`
     - link to `run_id` (nullable) and/or `change_ref`
     - `packet_id`, `packet_hash`
     - `story_hash`

2. **Findings persistence**
   - Persist each finding as a row referencing `review_run_id`.
   - Store:
     - `finding_id` (unique per review run)
     - `category`, `severity`, `title`
     - `description` (may be long)
     - `recommendation`
     - `contract_refs_json`
     - `evidence_refs_json`
     - optional `fingerprint` (cross-run stable id)

3. **Artifacts**
   - Store review artifacts using existing execution-store artifact mechanism:
     - `review_report.json`
     - `review_summary.md`
     - `review_packet.json` (canonical)
     - optional prompt logs / model metadata

4. **Idempotency**
   - Re-running the same review (same packet_hash + story_hash + config_hash) should:
     - either create a new `review_run` with a different id but same fingerprints,
     - or optionally “upsert” if configured (default: create a new run).

5. **Privacy + redaction**
   - If packet evidence includes redaction metadata, store that metadata.
   - Do not persist raw secrets; ensure artifacts can be configured to redact.

### Data requirements
- Execution-store schema updates (SQLite initially):
  - `review_runs` table
  - `review_findings` table
  - indexes:
    - `(project_id, created_at)`
    - `(run_id)`
    - `(review_run_id, severity)`
- Foreign keys (where supported):
  - `review_runs.project_id -> projects.id`
  - `review_runs.run_id -> runs.id`

### Observability requirements
- Structured logs:
  - `event='review.persisted'` with `review_run_id`, counts, artifact ids
- Metrics hooks (optional):
  - duration and findings count exported to logs.

## Acceptance criteria
- [ ] A review run is persisted with lifecycle timestamps and status.
- [ ] Findings are persisted and queryable by severity/category.
- [ ] Review artifacts are written and linked to the review run.
- [ ] Linking to an implementation `run_id` works when present.

## Test plan
- Migration test: new tables created in a fresh DB.
- Integration: run review runner and verify rows + artifact links exist.
- Unit: redaction configuration prevents secret strings from being stored.
