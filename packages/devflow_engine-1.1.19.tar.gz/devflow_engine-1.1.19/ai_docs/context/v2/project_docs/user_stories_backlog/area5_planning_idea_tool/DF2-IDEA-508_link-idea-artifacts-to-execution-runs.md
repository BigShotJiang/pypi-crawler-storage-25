story_uuid: 1cd1a8c0-7548-488b-8b45-bfc88be596e8
story_id: DF2-IDEA-508
title: Link idea artifacts to DevFlow executions (analysis/generation provenance)
required_planes: [api, integrations]

CONTRACT FORMATION MODE: implementation is irrelevant; do not compare against current code/UI. Define user-expected outcomes and test oracles only.

## Intent
As a DevFlow user,
I want idea-related actions (analysis, draft generation, promotion) to be linkable to DevFlow execution/run records,
so that I can trace what happened, when, with what inputs, and reproduce it.

## Scope
- For each idea tool action that performs work, record or reference a DevFlow execution/run id.
- Ensure idea artifacts can be traced to runs even if run logs are rotated.

## Out of scope
- Distributed tracing.
- Uploading artifacts to remote stores.

## Contract
### Provenance linkage
- For each of the following commands, the produced artifact MUST record a `run_id` (or equivalent):
  - `devflow idea analyze`
  - `devflow idea drafts generate`
  - `devflow idea promote` (when it writes)
- The `run_id` MUST correspond to an entry in the execution store (see Area 3 stories).

### Minimum recorded fields
- Each artifact’s provenance record MUST include:
  - `run_id`
  - `command` (normalized string)
  - `started_at`, `finished_at` (UTC)
  - success/failure status

### Failure behavior
- If the action fails, an artifact MAY still be written, but it MUST clearly indicate failure and include the `run_id` so logs can be inspected.

plane_oracles:
- plane: api
  oracle: "Idea artifacts include run_id fields that can be resolved against the execution store." 
  anchor: "api:execution-store(resolve_run_id)"
- plane: integrations
  oracle: "Cross-linking between planning artifacts and run logs works without relying on ephemeral console output." 
  anchor: "integration:idea↔execution provenance"

## Acceptance criteria
- MUST include `run_id` in provenance for analysis, draft generation, and promotion.
- MUST include command + timestamps + status.
- MUST support failure cases with a traceable run id.

## Contract test specs
1) run_id present
   - Given an idea analysis artifact
   - When its provenance is inspected
   - Then it contains a `run_id`

2) run_id resolves
   - Given a stored `run_id`
   - When the execution store is queried
   - Then the corresponding run record exists (or a clear error is returned if execution DB missing)
