story_uuid: ce58c867-cfb0-4a2f-b049-b782cd4b3514
story_id: US-7.6_contract-compliance-and-soundness_checks
title: US-7.6 contract-compliance-and-soundness checks
required_planes: [ui, ops]

CONTRACT FORMATION MODE: implementation is irrelevant; do not compare against current code/UI. Define user-expected outcomes and test oracles only.

plane_oracles:
- plane: ui
  oracle: "The user can invoke the documented CLI behavior for US-7.6_contract-compliance-and-soundness_checks and receives clear, actionable output on success/failure."
  anchor: "cli:US-7.6_contract-compliance-and-soundness_checks"
- plane: ops
  oracle: "Operational side effects for US-7.6_contract-compliance-and-soundness_checks are deterministic and documented (files/dirs created, idempotency, and safe failure modes)."
  anchor: "docs:user_story/US-7.6_contract-compliance-and-soundness_checks"
# US-7.6 — Contract compliance & soundness checks (story-driven review)

## User story
As a DevFlow operator,
I want review checks that map directly to story contract requirements,
so that we can automatically validate “done means done” beyond basic unit tests.

## Scope
- Implement baseline checks that:
  - parse story contracts into requirement items
  - verify evidence exists for each requirement
  - flag missing/ambiguous implementations
- Provide a simple “coverage” score for contract requirements.

## Out of scope
- Domain-specific linters for every language/framework.
- Formal verification.

## Contract

### Functional requirements
1. **Story contract parsing**
   - Extract structured requirement items from story contract sections:
     - `Scope`, `Out of scope`, `Contract` (functional/data/observability), `Acceptance criteria`, `Test plan`
   - Each extracted item must have a `contract_ref` anchor:
     - `{story_id}#{section}.{index}` (or equivalent)

2. **Requirement coverage evaluation**
   - For each requirement item, determine one of:
     - `covered` (evidence or implementation clearly present)
     - `uncovered` (no evidence)
     - `uncertain` (ambiguous)
   - Evidence sources:
     - files/paths listed in review packet targets
     - execution-store logs and artifacts (if `run_ref` provided)
     - tests referenced in repo

3. **Findings mapping**
   - For each `uncovered` or `uncertain` requirement, emit a finding:
     - `category='compliance'` for uncovered
     - `category='soundness'` for uncertain correctness/edge cases
     - `contract_refs` must include the requirement anchor

4. **Soundness heuristics**
   - Flag common gaps:
     - missing idempotency
     - lack of error handling
     - missing validation of inputs
     - missing observability requirements (logs/metrics)

5. **Coverage score**
   - Compute:
     - `coverage = covered / (covered + uncovered + uncertain)`
   - Emit as part of review report summary.

### Data requirements
- Review report must include:
  - per-requirement status list with `contract_ref`, `status`, `evidence_refs[]`
  - aggregate coverage score

### Observability requirements
- Log:
  - `event='review.contract.coverage'` with score and counts.

## Acceptance criteria
- [ ] The runner can extract requirement items from a standard story contract markdown.
- [ ] Uncovered requirements generate findings referencing the correct contract anchors.
- [ ] Coverage score is computed and appears in `review_report.json`.

## Test plan
- Unit: markdown contract parsing on fixture contracts.
- Integration: run on a known story with missing requirements and verify uncovered findings.
