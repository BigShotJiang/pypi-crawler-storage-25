story_uuid: 0fd3d375-1ea2-4aa5-8c96-f69f86566af6
story_id: US-7.2_review-runner_core-workflow
title: US-7.2 review-runner core-workflow
required_planes: [ui, ops]

CONTRACT FORMATION MODE: implementation is irrelevant; do not compare against current code/UI. Define user-expected outcomes and test oracles only.

plane_oracles:
- plane: ui
  oracle: "The user can invoke the documented CLI behavior for US-7.2_review-runner_core-workflow and receives clear, actionable output on success/failure."
  anchor: "cli:US-7.2_review-runner_core-workflow"
- plane: ops
  oracle: "Operational side effects for US-7.2_review-runner_core-workflow are deterministic and documented (files/dirs created, idempotency, and safe failure modes)."
  anchor: "docs:user_story/US-7.2_review-runner_core-workflow"
# US-7.2 — Review Runner: consume Story Contract + Review Packet and emit Findings

## User story
As a DevFlow operator,
I want a review runner that evaluates an implementation against the story contract using a review packet,
so that we can detect compliance/soundness/security issues before accepting work.

## Scope
- Implement `ReviewRunner` orchestration that:
  - loads Story Contract (canonical md) + Review Packet (US-7.1)
  - runs a set of review checks
  - produces a **Review Findings Report** (structured) + human-readable summary
- Checks must be pluggable and ordered.
- Review output must be deterministic given the same inputs (best-effort; see “LLM variance” notes).

## Out of scope
- Auto-fixing issues (remediation generation is US-7.4).
- Interactive reviewer UI.

## Contract

### Functional requirements
1. **Inputs**
   - `story_contract` (markdown, parsed into structured sections)
   - `review_packet` (validated object)
   - `review_config` (optional): which checks enabled, severity thresholds, model selection

2. **Core phases**
   - `phase=ingest`: parse inputs and build a `review_context`
   - `phase=analyze`: run checks (static + semantic)
   - `phase=aggregate`: dedupe/merge, compute summary status
   - `phase=emit`: write artifacts + persist to execution store (US-7.3)

3. **Pluggable checks**
   - Define check interface:
     - `check_id`, `name`, `version`
     - `run(context) -> findings[]`
   - Support check categories:
     - `compliance` (matches contract)
     - `soundness` (correctness/edge cases)
     - `security` (secrets, injections, unsafe IO)

4. **Finding fields (minimum)**
   - Each finding must include:
     - `finding_id` (stable hash of key fields)
     - `category`: `compliance|soundness|security|style|observability`
     - `severity`: `info|low|medium|high|critical`
     - `title`, `description`
     - `evidence_refs[]` (pointers into packet evidence or repo paths/line ranges)
     - `contract_refs[]` (link to story contract sections/requirements)
     - `recommendation` (what to do)

5. **Determinism + LLM variance controls**
   - When LLMs are used, runner must:
     - record model name/version and prompt hashes
     - prefer temperature=0 where supported
     - produce stable `finding_id` independent of ordering

6. **Overall review outcome**
   - Compute `review_status`:
     - `pass` if no findings >= configured threshold
     - `fail` otherwise
   - Threshold default: fail on `high` or `critical`.

### Data requirements
- Generate a structured `review_report.json` containing:
  - `review_id`, `packet_hash`, `story_hash`
  - `review_status`, counts by severity/category
  - list of findings
  - tool/model metadata
- Generate `review_summary.md` for humans.

### Observability requirements
- Structured logs:
  - `event='review.started'|'review.check.started'|'review.check.finished'|'review.finished'`
  - `review_id`, `run_id` (if present), `packet_id`, `check_id`, durations
- On failure, log top-N findings (titles only) without leaking sensitive evidence.

## Acceptance criteria
- [ ] Given a valid story contract + review packet, runner produces `review_report.json` and `review_summary.md`.
- [ ] Checks can be enabled/disabled by config.
- [ ] Findings include contract refs and evidence refs.
- [ ] The same inputs yield identical report ordering and stable finding IDs (excluding non-deterministic model text, which must be captured and hashed).

## Test plan
- Unit: check interface + aggregation (dedupe, severity counts).
- Unit: stable `finding_id` hashing.
- Integration: run on a small fixture repo with known violations and verify report contents.
