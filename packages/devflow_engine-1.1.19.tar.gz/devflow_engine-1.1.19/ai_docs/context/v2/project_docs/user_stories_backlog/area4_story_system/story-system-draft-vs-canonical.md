story_uuid: 2ca4672a-a310-41fb-a5b7-3cd23f73d327
story_id: DF2-STORY-406
title: Draft vs canonical separation for user stories (maturity + gating)
required_planes: [auth, api, ui, integrations, ops]

CONTRACT FORMATION MODE: implementation is irrelevant; do not compare against current code/UI. Define user-expected outcomes and test oracles only.

## Intent
As a DevFlow maintainer, I want a clear separation between draft stories and canonical stories so that experimental/unfinished contracts can exist without affecting required validation gates and without confusing downstream automation.

## Scope
- Define “canonical” vs “draft” story sources
- Canonical stories:
  - Are included in the authoritative canonical file (`.../user_stories.md`)
  - Are required to pass validation for CI gates
- Draft stories:
  - May exist under `.../project_docs/user_stories/**` in a designated location (e.g., `drafts/`) or with a metadata flag
  - Are excluded from strict CI gates by default (policy)
  - Can still be indexed and validated in a non-blocking mode

## Out of scope
- Review workflows (PR templates, approvals)
- Story lifecycle beyond draft/canonical (e.g., deprecated)

plane_oracles:
- plane: auth
  oracle: "Draft/canonical handling is a local policy and does not require credentials."
  anchor: "policy:local"
- plane: api
  oracle: "Index entries declare maturity/status so downstream steps can filter canonical-only."
  anchor: "api:index.status"
- plane: ui
  oracle: "CLI can list canonical-only or include drafts via a flag."
  anchor: "cli:stories list --include-drafts"
- plane: integrations
  oracle: "CI gates validate canonical stories strictly while optionally reporting draft warnings."
  anchor: "ci:canonical gate"
- plane: ops
  oracle: "Policy is deterministic and documented: given a file, it is unambiguously draft or canonical."
  anchor: "ops:classification rules"

## Acceptance criteria
- MUST define how a story is classified as canonical vs draft.
- MUST ensure canonical stories are the default set used for required validation gates.
- MUST allow tooling to include drafts for exploration without failing the build (configurable mode).
- MUST document the classification rule in the canonical docs (so humans know where to put drafts).
- SHOULD support an explicit per-story metadata field (e.g., `status: draft`) OR a deterministic path convention (e.g., `user_stories/drafts/`).

## Contract test specs
1) Default behavior excludes drafts
   - Given one canonical story and one draft story
   - When the indexer runs in default mode
   - Then the canonical story is included in the “canonical set”
   - And the draft story is excluded from the canonical set

2) Include-drafts mode
   - Given one canonical story and one draft story
   - When the indexer runs with include-drafts enabled
   - Then both stories are present
   - And each has a correct `status` field

3) CI gating
   - Given a draft story fails validation
   - When CI runs canonical validation gate
   - Then CI still passes (unless configured to fail-on-drafts)
   - And draft validation errors are reported as non-blocking warnings
