story_uuid: dd044fa3-7f65-419a-9f57-2ee207bbbd96
story_id: US-8.6_github-issues_ingestion-watcher
title: US-8.6 github-issues ingestion-watcher
required_planes: [api, ops]

CONTRACT FORMATION MODE: implementation is irrelevant; do not compare against current code/UI. Define user-expected outcomes and test oracles only.

plane_oracles:
- plane: api
  oracle: "The engine exposes deterministic programmatic behavior and data models required by US-8.6_github-issues_ingestion-watcher (inputs/outputs and persistence semantics)."
  anchor: "api:US-8.6_github-issues_ingestion-watcher"
- plane: ops
  oracle: "Operational side effects for US-8.6_github-issues_ingestion-watcher are deterministic and documented (files/dirs created, idempotency, and safe failure modes)."
  anchor: "docs:user_story/US-8.6_github-issues_ingestion-watcher"
# US-8.6 — GitHub Issues ingestion watcher: new issue → error task

## User story
As a DevFlow operator,
I want GitHub issues ingested into the DevFlow error queue,
so that reported bugs and operational issues become actionable error tasks with the same lifecycle as execution-derived failures.

## Scope
- Define a watcher that periodically polls GitHub for new/updated issues.
- Create or update error tasks based on issues.
- Dedupe using fingerprint rules (US-8.3).

## Out of scope
- Two-way sync of comments and labels (future).
- Webhooks (polling is acceptable initially).

## Contract
### Functional requirements
1. **Watcher configuration**
   - Per project, configure:
     - `github_repo` (owner/name)
     - issue query (labels, state=open, since timestamp)
     - optional: label allowlist/blocklist

2. **Polling behavior**
   - Watcher runs on an interval (e.g., every N minutes) and:
     - fetches issues updated since `last_cursor`
     - processes in stable order (by `updated_at`, then id)
     - persists `last_cursor` when a batch completes successfully

3. **Mapping issue → error task**
   - For each matching issue:
     - compute fingerprint (US-8.3; prefer stable `node_id` or `{repo}#{number}`)
     - if a matching task exists: update fields (title, severity hints, status mapping)
     - else: create a new error task with:
       - `source_kind='github'`
       - `source_ref=issue_url`
       - `title=issue.title`
       - `details` including `body`, `labels`, `author`, `created_at`, `updated_at`

4. **Status mapping**
   - GitHub issue state SHOULD map to error task status:
     - issue open → `open` (or `triaged` if labeled)
     - issue closed → `closed` ONLY if DevFlow verification is satisfied; otherwise `resolved` (waiting verification)
   - If mapping is ambiguous, preserve DevFlow status and only store issue state in details.

5. **Idempotency**
   - Re-seeing the same issue MUST NOT create duplicates.
   - Updates MUST be safe to apply repeatedly.

6. **Rate limiting / safety**
   - Watcher MUST respect GitHub API rate limits.
   - On API failure, do not advance cursor; emit an error task for the watcher itself only if failures persist (policy TBD).

### Data requirements
- A table/config store for watchers (indicative): `github_issue_watchers`
  - `project_id`, `repo`, `query_json`, `last_cursor`, `enabled`
- Persist `external_source_state` in JSON for each task (optional) to support future sync.

### Observability requirements
- Emit logs:
  - `event='github_watcher.poll_started'|'github_watcher.poll_finished'|'github_watcher.issue_ingested'`
  - include `repo`, `issue_number`, `error_task_id`.

## Acceptance criteria
- [ ] A new GitHub issue creates exactly one error task.
- [ ] Re-running watcher does not create duplicates.
- [ ] Cursor persists only after successful batch.

## Test plan
- Integration (mock GitHub): first poll ingests issues; second poll is idempotent.
- Failure test: API error does not advance cursor.
