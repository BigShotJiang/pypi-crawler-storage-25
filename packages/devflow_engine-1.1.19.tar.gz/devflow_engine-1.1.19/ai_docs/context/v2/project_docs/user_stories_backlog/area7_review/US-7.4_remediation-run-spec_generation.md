story_uuid: 18c97200-b30d-42b7-8c9d-0d88bf7ef8fd
story_id: US-7.4_remediation-run-spec_generation
title: US-7.4 remediation-run-spec generation
required_planes: [api, ops]

CONTRACT FORMATION MODE: implementation is irrelevant; do not compare against current code/UI. Define user-expected outcomes and test oracles only.

plane_oracles:
- plane: api
  oracle: "The engine exposes deterministic programmatic behavior and data models required by US-7.4_remediation-run-spec_generation (inputs/outputs and persistence semantics)."
  anchor: "api:US-7.4_remediation-run-spec_generation"
- plane: ops
  oracle: "Operational side effects for US-7.4_remediation-run-spec_generation are deterministic and documented (files/dirs created, idempotency, and safe failure modes)."
  anchor: "docs:user_story/US-7.4_remediation-run-spec_generation"
# US-7.4 — Generate remediation Run Spec from review findings

## User story
As a DevFlow operator,
I want the review workflow to generate a remediation run spec when it fails,
so that the system can automatically plan and execute fixes in a traceable way.

## Scope
- Define a **Remediation Run Spec** format that can be handed to the planner/executor.
- Generate remediation specs from review findings:
  - select findings eligible for auto-remediation
  - group into remediation tasks
  - define acceptance targets (what must change to consider fixed)
- Persist remediation spec as an artifact and link to review run (US-7.3).

## Out of scope
- Actually executing remediation (planner/executor stories).
- Advanced dependency resolution across multiple repos.

## Contract

### Functional requirements
1. **Eligibility rules**
   - Only findings with `remediable=true` (or derived rule) can be included.
   - Exclude:
     - policy-only findings requiring human sign-off
     - findings lacking actionable evidence/targets

2. **Run spec structure**
   - Spec must include:
     - `spec_version`
     - `spec_id`
     - `source_review_run_id`
     - `source_packet_hash`, `source_story_hash`
     - `goals[]`: each with `goal_id`, `finding_ids[]`, `instructions`, `target_files[]`
     - `constraints` (safety + scope constraints)
     - `success_criteria` (re-run review must pass; plus goal-level checks)

3. **Traceability**
   - Each goal references the originating finding ids.
   - The remediation run (when executed) must link back to:
     - `review_run_id`
     - `spec_id`

4. **Safety constraints**
   - Spec must encode guardrails:
     - allowed paths to edit
     - forbidden patterns (e.g., writing secrets)
     - max diff size / file count (configurable)

5. **Emission rules**
   - If `review_status=pass`, do not generate remediation spec by default.
   - If `review_status=fail`, generate remediation spec unless `--no-remediation`.

### Data requirements
- Store spec as `remediation_spec.json` artifact.
- Record `remediation_spec_id` on the `review_run` record (nullable).

### Observability requirements
- Logs:
  - `event='review.remediation.spec.generated'` with `review_run_id`, `spec_id`, `goal_count`, `included_findings_count`

## Acceptance criteria
- [ ] A failed review produces a remediation spec artifact with traceable links to findings.
- [ ] Spec enforces safety constraints (allowed targets, max diff, etc.).
- [ ] A passing review does not generate a spec unless explicitly requested.

## Test plan
- Unit: eligibility filter and goal grouping.
- Unit: constraint serialization and validation.
- Integration: run review on fixture with mixed findings; verify only eligible findings appear in spec.
