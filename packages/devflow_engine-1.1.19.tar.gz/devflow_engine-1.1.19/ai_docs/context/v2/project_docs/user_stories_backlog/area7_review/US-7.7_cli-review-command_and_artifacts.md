story_uuid: 3a35bb09-37fc-486a-b9e2-c97782bb42a0
story_id: US-7.7_cli-review-command_and_artifacts
title: US-7.7 cli-review-command and artifacts
required_planes: [ui, ops]

CONTRACT FORMATION MODE: implementation is irrelevant; do not compare against current code/UI. Define user-expected outcomes and test oracles only.

plane_oracles:
- plane: ui
  oracle: "The user can invoke the documented CLI behavior for US-7.7_cli-review-command_and_artifacts and receives clear, actionable output on success/failure."
  anchor: "cli:US-7.7_cli-review-command_and_artifacts"
- plane: ops
  oracle: "Operational side effects for US-7.7_cli-review-command_and_artifacts are deterministic and documented (files/dirs created, idempotency, and safe failure modes)."
  anchor: "docs:user_story/US-7.7_cli-review-command_and_artifacts"
# US-7.7 — CLI: `devflow review` command to run reviews and publish artifacts

## User story
As a DevFlow operator,
I want a CLI command to execute the review workflow end-to-end,
so that reviews can be run locally and in CI with consistent outputs.

## Scope
- Add CLI command surface:
  - `devflow review --packet <path> [--story <path>] [--run-id <id>] [--format json|md|both]`
- Command runs the review runner (US-7.2), persists outputs (US-7.3), and optionally generates remediation spec (US-7.4).
- Provide exit codes appropriate for CI.

## Out of scope
- Rich TUI.
- GitHub Checks annotations (possible later).

## Contract

### Functional requirements
1. **Command behavior**
   - Must:
     - load packet from file
     - resolve story contract from packet or `--story`
     - execute review
     - write artifacts to a deterministic output directory

2. **Output layout**
   - Default output folder:
     - `.devflow/reviews/<review_id>/`
   - Files:
     - `review_report.json`
     - `review_summary.md`
     - `review_packet.canonical.json`
     - `remediation_spec.json` (if generated)

3. **Exit codes**
   - `0`: review pass
   - `2`: review fail (findings at/above threshold)
   - `1`: runner error (exception, invalid packet, IO)

4. **Flags**
   - `--fail-severity <level>` (default `high`)
   - `--no-persist` (skip execution-store persistence; still writes local artifacts)
   - `--no-remediation` (skip remediation spec)
   - `--check <id>` allowlist; `--skip-check <id>` denylist
   - `--json` / `--md` shortcuts (or `--format`)

5. **Human output**
   - Print a concise console summary:
     - status, coverage, top findings (titles), artifact path, review_run_id (if persisted)

### Data requirements
- When persisted, CLI must print `review_run_id` and linkages to `run_id`.

### Observability requirements
- CLI logs must include `review_id` and `packet_id` for correlation.

## Acceptance criteria
- [ ] `devflow review` runs successfully on a fixture packet and produces artifacts.
- [ ] Exit code is `2` when findings exceed threshold.
- [ ] Flags control checks and persistence as specified.

## Test plan
- Unit: argument parsing and config mapping.
- Integration: CLI run in a temp repo, verify output layout and exit codes.
