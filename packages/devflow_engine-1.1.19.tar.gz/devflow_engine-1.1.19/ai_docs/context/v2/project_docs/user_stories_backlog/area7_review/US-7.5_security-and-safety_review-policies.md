story_uuid: f4d9ef78-7db4-4d96-b484-e16c95e4bce4
story_id: US-7.5_security-and-safety_review-policies
title: US-7.5 security-and-safety review-policies
required_planes: [ui, ops]

CONTRACT FORMATION MODE: implementation is irrelevant; do not compare against current code/UI. Define user-expected outcomes and test oracles only.

plane_oracles:
- plane: ui
  oracle: "The user can invoke the documented CLI behavior for US-7.5_security-and-safety_review-policies and receives clear, actionable output on success/failure."
  anchor: "cli:US-7.5_security-and-safety_review-policies"
- plane: ops
  oracle: "Operational side effects for US-7.5_security-and-safety_review-policies are deterministic and documented (files/dirs created, idempotency, and safe failure modes)."
  anchor: "docs:user_story/US-7.5_security-and-safety_review-policies"
# US-7.5 — Review workflow security & safety policies (no secret exfil, safe evidence handling)

## User story
As a security-conscious DevFlow operator,
I want the review workflow to enforce safety policies around secrets, network access, and evidence handling,
so that running reviews does not leak sensitive data or increase attack surface.

## Scope
- Define default security controls for the review runner.
- Ensure review artifacts and logs are safe-by-default.
- Provide configuration hooks to tighten or loosen policies in trusted environments.

## Out of scope
- Full sandbox/VM isolation (may be added later).
- Organization-wide IAM and key management.

## Contract

### Functional requirements
1. **Secret detection + redaction**
   - Scan review inputs (packet evidence + extracted snippets) for secrets using:
     - denylist regexes (API keys, tokens, private keys)
     - entropy heuristics (optional)
   - On detection:
     - redact in logs and in persisted artifacts
     - produce a `security` finding: `severity=high` by default

2. **Network access policy**
   - Default: **no external network fetch** during review checks.
   - Permitlist mode supported via config:
     - allowed domains
     - allowed URL schemes
   - Any attempted blocked network call must:
     - be prevented
     - produce a `security` finding with evidence of the attempted call (without including secrets)

3. **Filesystem scope control**
   - Review checks must only read within:
     - `repo_root`
     - declared evidence paths
     - execution-store artifact cache directory
   - Reading outside scope must be blocked and logged as a security finding.

4. **Prompt and model safety**
   - If LLM prompts include code snippets, they must:
     - use redacted content by default
     - record prompt hashes instead of full raw prompts unless `--store-prompts`

5. **Least-privilege execution**
   - Review runner must not require write access to repo by default.
   - Any write attempt must be explicit and recorded.

### Data requirements
- Store redaction events summary:
  - counts by type (token-like, private key, etc.)
  - locations (file + line range) as metadata
- Store policy configuration used for the review (config hash) to support auditing.

### Observability requirements
- Logs:
  - `event='review.security.blocked'` with `kind='network'|'filesystem'|'secret'`, `review_id`, and sanitized context
- Ensure logs never print full evidence blobs.

## Acceptance criteria
- [ ] Secrets are detected and redacted in persisted artifacts and logs.
- [ ] External network fetches are blocked by default and recorded as findings.
- [ ] Filesystem reads are restricted to explicit scopes.
- [ ] Prompt storage is opt-in; default stores hashes only.

## Test plan
- Unit: secret regexes and redaction.
- Integration: attempt to read `/etc/passwd` via a check; verify blocked + finding.
- Integration: attempt HTTP fetch; verify blocked + finding.
