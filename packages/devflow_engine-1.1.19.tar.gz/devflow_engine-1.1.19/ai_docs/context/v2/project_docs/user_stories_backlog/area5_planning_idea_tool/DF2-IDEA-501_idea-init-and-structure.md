story_uuid: 2dd72d72-37b8-41b3-9f11-038e5266956d
story_id: DF2-IDEA-501
title: "devflow idea init" creates an idea workspace + metadata record
required_planes: [api, ui, ops]

CONTRACT FORMATION MODE: implementation is irrelevant; do not compare against current code/UI. Define user-expected outcomes and test oracles only.

## Intent
As a DevFlow user,
I want to initialize a new “idea” in the current project,
so that I have a predictable place to collect planning artifacts (analysis, draft stories, promotion decisions) before changing canonical requirements.

## Scope
- Add a CLI entrypoint for an “idea tool” (e.g., `devflow idea ...`).
- Provide an `init` (or `new`) command that creates an idea record with a stable ID.
- Create a deterministic filesystem layout for the idea’s artifacts.
- Ensure idempotency and safe re-runs.

## Out of scope
- Any GUI for creating ideas.
- Remote syncing of idea artifacts.
- Executing implementation tasks; this story is about planning artifact scaffolding.

## Contract
### User-visible behavior
- Command: `devflow idea init` (or `devflow idea new`)
- Inputs:
  - optional `--title` (human-readable)
  - optional `--description` (free text)
  - optional `--project <id>` (otherwise inferred from cwd/project config)
- Outputs (stdout):
  - the created/selected `idea_id`
  - the filesystem path for the idea workspace
  - next-step hints (e.g., `devflow idea analyze`, `devflow idea drafts list`)

### Filesystem layout
- An idea workspace directory MUST exist at a stable, tool-discoverable path under the project’s DevFlow workspace, e.g.:
  - `.devflow/ideas/<idea_id>/`
- The directory MUST contain a machine-readable metadata file, e.g.:
  - `.devflow/ideas/<idea_id>/idea.json` (or `.yaml`/`.toml`), containing at least:
    - `idea_id`
    - `title`
    - `description`
    - `project_id`
    - `created_at` (UTC)
    - `updated_at` (UTC)
    - `status` (e.g., `draft|analyzed|promoted|archived` — exact enum may evolve)

### Idempotency & safety
- Re-running `devflow idea init` with the same explicit `idea_id` (if supported) MUST be non-destructive.
- If the tool would overwrite existing idea metadata, it MUST either:
  - refuse with a clear error and remediation, or
  - require an explicit `--force`.

plane_oracles:
- plane: api
  oracle: "There is a deterministic way to compute/resolve the idea workspace path and load idea metadata (idea_id, project_id, timestamps)."
  anchor: "api:idea-store(resolve_path, load_metadata)"
- plane: ui
  oracle: "CLI output includes the idea_id and path, enabling a human to navigate to artifacts without guesswork."
  anchor: "cli:devflow idea init stdout"
- plane: ops
  oracle: "A fresh checkout with a valid project workspace can create idea artifacts locally without network access."
  anchor: "ops:local-fs-only"

## Acceptance criteria
- MUST provide a CLI command to create/initialize an idea.
- MUST persist a machine-readable metadata record with required fields.
- MUST create a stable directory structure for idea artifacts.
- MUST be safe to re-run without data loss unless `--force` is used.

## Contract test specs
1) Create idea workspace
   - Given a DevFlow project workspace
   - When `devflow idea init --title "X"` is executed
   - Then an `idea_id` is printed
   - And `.devflow/ideas/<idea_id>/` exists
   - And the metadata file exists and is parseable

2) Metadata completeness
   - Given an initialized idea
   - When the metadata is loaded
   - Then it includes `idea_id`, `project_id`, `created_at`, `updated_at`

3) Idempotent re-run
   - Given an initialized idea
   - When `devflow idea init` is re-run targeting the same idea
   - Then no artifact files are deleted
   - And the tool either leaves metadata unchanged or updates only `updated_at` (policy must be explicit)
