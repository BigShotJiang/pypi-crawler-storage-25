story_uuid: 2b01f4aa-b88a-4d24-ada3-35586dd7b97e
story_id: US-8.9_node-devflow-semantics_compatibility
title: US-8.9 node-devflow-semantics compatibility
required_planes: [ui, ops]

CONTRACT FORMATION MODE: implementation is irrelevant; do not compare against current code/UI. Define user-expected outcomes and test oracles only.

plane_oracles:
- plane: ui
  oracle: "The user can invoke the documented CLI behavior for US-8.9_node-devflow-semantics_compatibility and receives clear, actionable output on success/failure."
  anchor: "cli:US-8.9_node-devflow-semantics_compatibility"
- plane: ops
  oracle: "Operational side effects for US-8.9_node-devflow-semantics_compatibility are deterministic and documented (files/dirs created, idempotency, and safe failure modes)."
  anchor: "docs:user_story/US-8.9_node-devflow-semantics_compatibility"
# US-8.9 — Compatibility: match existing Node DevFlow error semantics

## User story
As a DevFlow v1/v2 migrator,
I want DevFlow v2’s error workflow to match the existing Node DevFlow semantics where practical,
so that prior automation, mental models, and run records remain consistent.

## Scope
- Define explicit compatibility rules between legacy “Node DevFlow” error concepts and the v2 model.
- Ensure status naming and lifecycle mapping are stable.

## Out of scope
- Full migration scripts.
- Backfilling historical issues.

## Contract
### Functional requirements
1. **Terminology mapping**
   - If legacy system uses “error” to mean “queue item”, v2 MUST:
     - keep a clear separation between raw execution `errors` and `error_tasks`.
     - expose `error_tasks` as the primary queue.

2. **Status mapping**
   - Provide a deterministic mapping table in code/docs (example):
     - legacy `open` → v2 `open`
     - legacy `claimed` → v2 `in_progress` with claim fields set
     - legacy `running_fix` → v2 `remediating`
     - legacy `fixed` → v2 `resolved`
     - legacy `closed` → v2 `closed`
     - legacy `duplicate` → v2 `duplicate`
   - Where legacy statuses are missing, v2 defaults to `open`.

3. **Run kind conventions**
   - Remediation/verification runs MUST use stable `kind` strings that align with legacy conventions where applicable:
     - `error.remediate`, `error.verify`

4. **Event compatibility**
   - v2 MUST emit structured events that can be consumed similarly to legacy logs:
     - include stable keys: `error_id/error_task_id`, `status`, `run_id`, `source`.

5. **Forward-compatible extensions**
   - v2 MUST allow adding fields without breaking older clients:
     - extra JSON in `details_json`
     - append-only events.

### Acceptance criteria
- [ ] A documented status mapping exists and is used by adapters.
- [ ] Remediation run kinds are stable.
- [ ] Legacy clients can interpret v2 error task status at least at coarse granularity.

## Test plan
- Unit: mapping function converts all known legacy statuses.
- Integration: simulate import of a legacy item → v2 task created with correct status + links.
