story_uuid: 86c6f0b7-1f20-44c9-a7e4-f6a84aa89b0d
story_id: DF2-IMPL-608
title: Stage: GitCommit(REFACTOR) (record refactor checkpoint after verification)
required_planes: [auth, api, ui, integrations, ops]

CONTRACT FORMATION MODE: implementation is irrelevant; do not compare against current code/UI. Define user-expected outcomes and test oracles only.

## Intent
After a successful refactor + verification, create a second checkpoint commit capturing the improved design while keeping all gates green.

## User value
As a reviewer, I can compare GREEN vs REFACTOR commits to see “behavioral fix” separated from “cleanup”, improving review clarity.

## Scope
- Preconditions:
  - VerifyGreen succeeded
  - There are refactor changes to commit
- Behavior:
  - create a commit with standardized message/metadata
  - reference prior GREEN commit (hash) and relevant artifact ids

plane_oracles:
- plane: auth
  oracle: "Commit creation is local-only; no remote auth is required."
  anchor: "git:local commit"
- plane: api
  oracle: "Stage refuses to commit if VerifyGreen did not succeed."
  anchor: "api:commit_refactor requires verify_result.status=success"
- plane: ui
  oracle: "CLI prints refactor commit hash + links it to the GREEN commit hash in output."
  anchor: "cli:commit refactor output"
- plane: integrations
  oracle: "Commit metadata includes references usable by packaging/review tools: run id, verify artifact id, base GREEN hash."
  anchor: "git:commit footer metadata"
- plane: ops
  oracle: "The stage does not create a refactor commit if the working tree is unchanged since GREEN (no-op)."
  anchor: "ops:no-op commit prevention"

## Acceptance criteria
- MUST require VerifyGreen success before committing.
- MUST create a commit with subject prefix `REFACTOR:`.
- MUST include footer metadata:
  - `DevFlow-Run:`
  - `DevFlow-Verify-Artifact:`
  - `DevFlow-Base-Green-Commit:`
- MUST fail with an actionable message if there is nothing to commit.

## Contract test specs
1) Guard on VerifyGreen
   - Given VerifyGreen status is failure
   - When GitCommit(REFACTOR) runs
   - Then it fails fast naming VerifyGreen as the unmet precondition

2) Footer metadata present
   - When the REFACTOR commit is created
   - Then `git show -1` includes the required footer lines with non-empty values

3) No-op prevention
   - Given no changes exist after verification
   - When the stage runs
   - Then no commit is created and an actionable message is printed
