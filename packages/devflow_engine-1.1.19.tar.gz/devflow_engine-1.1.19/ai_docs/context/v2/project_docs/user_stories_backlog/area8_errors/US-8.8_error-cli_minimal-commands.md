story_uuid: 7c1840fe-2028-49ab-b904-9236424664e8
story_id: US-8.8_error-cli_minimal-commands
title: US-8.8 error-cli minimal-commands
required_planes: [ui, ops]

CONTRACT FORMATION MODE: implementation is irrelevant; do not compare against current code/UI. Define user-expected outcomes and test oracles only.

plane_oracles:
- plane: ui
  oracle: "The user can invoke the documented CLI behavior for US-8.8_error-cli_minimal-commands and receives clear, actionable output on success/failure."
  anchor: "cli:US-8.8_error-cli_minimal-commands"
- plane: ops
  oracle: "Operational side effects for US-8.8_error-cli_minimal-commands are deterministic and documented (files/dirs created, idempotency, and safe failure modes)."
  anchor: "docs:user_story/US-8.8_error-cli_minimal-commands"
# US-8.8 — Error workflow CLI: list, inspect, claim, transition, remediate

## User story
As a DevFlow operator,
I want a minimal CLI surface for working the error queue,
so that I can triage and remediate errors quickly without building a UI first.

## Scope
- Define CLI command contracts and expected outputs.
- Reuse existing DevFlow CLI semantics (Typer commands, table output).

## Out of scope
- Fancy interactive TUI.
- Authentication/permissions.

## Contract
### Functional requirements
1. **List**
   - `devflow error list --status <status> [--project <id>] [--limit N]`
   - Displays: `error_task_id`, `status`, `severity`, `title`, `occurrence_count`, `updated_at`, `claimed_by`.

2. **Show / inspect**
   - `devflow error show <error_task_id>`
   - Displays:
     - core fields
     - recent events
     - linked runs/artifacts/occurrences

3. **Claim / release**
   - `devflow error claim <error_task_id> [--lease-seconds N]`
   - `devflow error release <error_task_id>`
   - Must use US-8.2 semantics.

4. **Transition**
   - `devflow error set-status <error_task_id> <new_status> [--note TEXT]`
   - Validates transition graph (US-8.1) and records an event.

5. **Remediate**
   - `devflow error remediate <error_task_id> [--force]`
   - Starts remediation run (US-8.4).
   - Prints remediation summary and links to run_id.

6. **Close**
   - `devflow error close <error_task_id> [--note TEXT]`
   - MUST refuse if verification requirement not met (US-8.5).

### Observability requirements
- Each CLI command MUST log a structured event with:
  - command name, actor, error_task_id, resulting status.

## Acceptance criteria
- [ ] Operators can list and inspect queue items.
- [ ] Claiming and guarded transitions prevent conflicting edits.
- [ ] Remediation creates a linked run and updates status.

## Test plan
- CLI integration: create sample tasks in store; list/show/claim/transition.
- CLI integration: close without verification fails with helpful message.
