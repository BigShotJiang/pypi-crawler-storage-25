story_uuid: d65adf8b-a33d-43a5-a31c-2e3d17bd1450
story_id: DF2-IDEA-507
title: Discoverability: list and inspect ideas, analyses, and draft sets
required_planes: [api, ui]

CONTRACT FORMATION MODE: implementation is irrelevant; do not compare against current code/UI. Define user-expected outcomes and test oracles only.

## Intent
As a DevFlow user,
I want to list and inspect existing ideas (and their analyses/draft sets),
so that I can resume planning work and understand current status without remembering IDs.

## Scope
- Provide listing commands for ideas, analyses, and draft sets.
- Provide a “show” command for detailed inspection.

## Out of scope
- Full-text search across all artifacts.
- A web UI.

## Contract
### User-visible behavior
- Commands (exact nouns may vary, but functionality must exist):
  - `devflow idea list`
  - `devflow idea show --idea <idea_id>`
  - `devflow idea analyses list --idea <idea_id>`
  - `devflow idea drafts list --idea <idea_id>`
- List output MUST include:
  - `idea_id`
  - `title` (if present)
  - `status`
  - `updated_at`
- Show output MUST include:
  - metadata fields
  - pointers to latest analysis and latest draft set (if any)
  - filesystem paths to artifacts

### Machine-readable output
- Each list/show command SHOULD support `--format json` for automation.

plane_oracles:
- plane: api
  oracle: "There are programmatic list/show functions that read from the idea workspace and return structured data." 
  anchor: "api:idea-store(list_ideas, show_idea, list_draft_sets, list_analyses)"
- plane: ui
  oracle: "CLI listing makes IDs and paths visible; a user can copy/paste IDs into other commands." 
  anchor: "cli:devflow idea list/show"

## Acceptance criteria
- MUST provide commands to list ideas.
- MUST provide commands to list analyses and draft sets for a given idea.
- MUST provide a show/inspect command exposing artifact paths and status.
- SHOULD provide `--format json` for automation.

## Contract test specs
1) Idea list contains required columns
   - Given at least one initialized idea
   - When `devflow idea list` is executed
   - Then the output contains `idea_id` and `updated_at`

2) Show links artifacts
   - Given an idea with an analysis and draft set
   - When `devflow idea show --idea X` is executed
   - Then the output includes paths to the analysis and drafts
