story_uuid: 6a03e5f8-728b-4c68-ad19-c07dcc68e5d7
story_id: US-7.1_review-packet_schema-and-loader
title: US-7.1 review-packet schema-and-loader
required_planes: [ui, ops]

CONTRACT FORMATION MODE: implementation is irrelevant; do not compare against current code/UI. Define user-expected outcomes and test oracles only.

plane_oracles:
- plane: ui
  oracle: "The user can invoke the documented CLI behavior for US-7.1_review-packet_schema-and-loader and receives clear, actionable output on success/failure."
  anchor: "cli:US-7.1_review-packet_schema-and-loader"
- plane: ops
  oracle: "Operational side effects for US-7.1_review-packet_schema-and-loader are deterministic and documented (files/dirs created, idempotency, and safe failure modes)."
  anchor: "docs:user_story/US-7.1_review-packet_schema-and-loader"
# US-7.1 — Define Review Packet schema and loader

## User story
As a DevFlow operator,
I want a canonical “review packet” format with a loader/validator,
so that review workflows have a consistent, auditable set of inputs.

## Scope
- Define a versioned **Review Packet** schema (JSON/YAML) that can be saved as an artifact.
- Implement a loader that:
  - reads from a file path (and later, from an execution-store artifact reference)
  - validates required fields
  - normalizes paths/refs
  - produces an in-memory object used by the review runner.
- Support including the **story contract** as:
  - an embedded string, **or**
  - a file reference (path), **or**
  - a content-addressed artifact reference.

## Out of scope
- The actual review logic (handled by US-7.2+).
- A rich UI for building packets.

## Contract

### Functional requirements
1. **Packet identity + versioning**
   - Packet must include:
     - `packet_version` (semver string)
     - `packet_id` (UUID or content-hash)
     - `created_at` (ISO8601)
     - `producer` (e.g., `devflow-cli@x.y.z`, `agent@model`)

2. **Required inputs**
   - Packet must include:
     - `project_ref` (project id/name + optional repo root)
     - `run_ref` (the run being reviewed) OR `change_ref` (commit/branch) depending on workflow
     - `story_contract_ref` (see above)
     - `targets` (what is being reviewed): list of file globs / modules / node ids

3. **Evidence bundle**
   - Packet may include `evidence[]` entries containing:
     - `kind`: `"log"|"diff"|"artifact"|"snapshot"|"url"|"note"`
     - `ref`: path, URL, execution-store artifact id, etc.
     - `sha256` (optional but recommended)
     - `redaction` metadata (optional)

4. **Policy context**
   - Packet may include:
     - `policies[]` (ids or embedded text)
     - `risk_tolerance` (e.g., low/med/high)
     - `compliance_regimes[]` (e.g., SOC2, HIPAA) as labels

5. **Validation + normalization**
   - Loader must validate:
     - required fields present
     - refs are well-formed
     - file paths resolve relative to a declared `repo_root` when provided
   - Loader should normalize:
     - relative paths → absolute paths (or repo-root-relative canonical forms)
     - line endings in embedded texts

6. **Deterministic serialization**
   - Provide a `packet_canonical_json()` method to produce stable JSON for hashing/auditing.

### Data requirements
- Store packet JSON as an execution-store artifact (optional in this story; required by US-7.3 for persistence).
- Include a `packet_hash` computed from canonical JSON.

### Observability requirements
- Structured logs:
  - `event='review.packet.loaded'`
  - `packet_id`, `packet_version`, `packet_hash`, `run_ref`, `project_ref`
  - counts: `evidence_count`, `targets_count`

## Acceptance criteria
- [ ] A documented, versioned Review Packet schema exists with an example file.
- [ ] Loader rejects packets missing required fields with actionable errors.
- [ ] Loader normalizes refs deterministically and exposes `packet_hash`.
- [ ] Embedded story contract content and file-path story contract refs are both supported.

## Test plan
- Unit: schema validation (missing fields, invalid enums, bad refs).
- Unit: canonical JSON stability (ordering, whitespace normalization).
- Integration: load a packet pointing at a sample repo root + story contract file.
