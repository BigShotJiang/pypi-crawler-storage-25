story_uuid: d542fdeb-7590-463c-8074-3721d35f42bf
story_id: US-8.2_error-queue_claiming-concurrency
title: US-8.2 error-queue claiming-concurrency
required_planes: [api, ops]

CONTRACT FORMATION MODE: implementation is irrelevant; do not compare against current code/UI. Define user-expected outcomes and test oracles only.

plane_oracles:
- plane: api
  oracle: "The engine exposes deterministic programmatic behavior and data models required by US-8.2_error-queue_claiming-concurrency (inputs/outputs and persistence semantics)."
  anchor: "api:US-8.2_error-queue_claiming-concurrency"
- plane: ops
  oracle: "Operational side effects for US-8.2_error-queue_claiming-concurrency are deterministic and documented (files/dirs created, idempotency, and safe failure modes)."
  anchor: "docs:user_story/US-8.2_error-queue_claiming-concurrency"
# US-8.2 — Error Queue: claiming + concurrency control

## User story
As a DevFlow operator or agent,
I want safe claiming/locking for error tasks,
so that multiple workers can process a shared queue without duplicate effort or conflicting state transitions.

## Scope
- Define claim/lease semantics for `error_tasks`.
- Define idempotent “claim, work, release” operations.

## Out of scope
- Distributed scheduling/priority algorithms.
- Multi-tenant permissions.

## Contract
### Functional requirements
1. **Claim an error task (lease)**
   - Operation: `claim_error_task(error_task_id, claimant_id, lease_seconds)`.
   - If unclaimed OR lease expired, claim succeeds and sets:
     - `claimed_by=claimant_id`
     - `claimed_at=now`
     - `lease_expires_at=now+lease_seconds`
   - Must be atomic.

2. **Heartbeat / extend lease**
   - Operation: `extend_claim(error_task_id, claimant_id, lease_seconds)`.
   - Only the current claimant can extend.
   - Must be atomic; updates `lease_expires_at`.

3. **Release claim**
   - Operation: `release_claim(error_task_id, claimant_id)`.
   - Clears claim fields.
   - Must be safe to call multiple times (idempotent).

4. **Guarded transitions**
   - Transition operations (US-8.1) MUST support an optional guard:
     - “transition only if claimed_by==X (and lease not expired)”
   - If guard fails, return a conflict error.

5. **Abandoned claims**
   - A claim with `lease_expires_at < now` is treated as not claimed.
   - No background janitor is required, but queries MUST ignore expired claims.

### Data requirements
- `error_tasks` fields (additions):
  - `claimed_by TEXT NULL`
  - `claimed_at INTEGER NULL`
  - `lease_expires_at INTEGER NULL`
- Index on `(status, lease_expires_at)` for efficient queue polling.

### Observability requirements
- Emit structured logs:
  - `event='error_task.claimed'|'error_task.released'|'error_task.lease_extended'`
  - include `claimant_id`, `lease_expires_at`.

## Acceptance criteria
- [ ] Two concurrent claimers cannot claim the same task in the same lease window.
- [ ] Lease expiry enables a second worker to claim.
- [ ] Transition operations can enforce “only claimant may change status”.

## Test plan
- Concurrency: attempt parallel claims (two connections/threads) → exactly one succeeds.
- Unit: extend lease by non-claimant fails.
- Integration: claim → transition to `in_progress` guarded → release.
