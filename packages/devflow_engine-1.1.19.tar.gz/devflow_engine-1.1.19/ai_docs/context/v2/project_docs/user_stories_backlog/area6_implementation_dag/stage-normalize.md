story_uuid: cce5cce3-3449-427c-8d8d-5b52a5e3a23f
story_id: DF2-IMPL-602
title: Stage: Normalize (canonicalize inputs + derive implementation targets)
required_planes: [auth, api, ui, integrations, ops]

CONTRACT FORMATION MODE: implementation is irrelevant; do not compare against current code/UI. Define user-expected outcomes and test oracles only.

## Intent
Turn user-provided work inputs (issue/story text, file hints, repo context) into a canonical normalized representation used by downstream stages.

## User value
As a developer, I can provide messy or partial instructions and still get a consistent set of derived targets (files/modules/functions) and constraints for TDD execution.

## Scope
- Input: user story contract(s) + optional hints (paths, module names, failing stack traces).
- **Pre-normalization repair (must):** if the selected story contract is non-canonical or fails story validation, Normalize **repairs it** into canonical form before producing the normalized artifact.
  - Repair is autonomous (no halt / no ask).
  - Repair is “best-effort evidence-based”: consult repo + docs to infer missing/invalid fields.
  - If evidence is insufficient, make an educated assertion and proceed (see Acceptance criteria).
- Output (normalized artifact):
  - canonical objective statement
  - explicit in-scope vs out-of-scope notes
  - derived implementation targets (paths/symbols)
  - derived test targets (test module/file names)
  - risk flags (e.g., migrations, network calls, secret access)
  - provenance: sources consulted + assertions made + confidence ratings

## Out of scope
- Actually writing tests or code.

plane_oracles:
- plane: auth
  oracle: "Normalization + pre-repair MUST NOT require secrets; it must not read secret stores or call external services by default."
  anchor: "stage:normalize (offline)"
- plane: api
  oracle: "Normalization output is machine-readable and versioned (schema_version), enabling downstream compatibility checks."
  anchor: "artifact:normalized_input.schema_version"
- plane: ui
  oracle: "CLI prints a concise summary: objective + derived targets + major risks + confidence, without dumping full raw inputs."
  anchor: "cli:normalize summary"
- plane: integrations
  oracle: "Normalized artifact can be persisted and reloaded to resume a run without re-parsing raw story text."
  anchor: "artifact:normalized_input roundtrip"
- plane: ops
  oracle: "Normalization is deterministic for a fixed input bundle; repeated runs produce identical normalized outputs (modulo timestamps)."
  anchor: "ops:normalize determinism"

## Acceptance criteria
### A) Story contract pre-repair (no halt / no placeholders)
- MUST run story validation against the selected story contract(s) before normalization.
  - Anchor: `script:devflow_engine/scripts/validate_stories.py`
- If validation fails for the selected story contract, MUST **repair** the story markdown into canonical form and re-run validation until it passes.
- MUST NOT introduce placeholders/stubs/TODOs to satisfy validation.
- MUST NOT halt to ask questions.
- MUST make best-effort evidence-based inferences by consulting:
  - the story file itself (filename, H1, intent/acceptance criteria)
  - adjacent docs in `ai_docs/context/**`
  - referenced code/test paths mentioned in the story
  - existing canonical story patterns in the repo
- After best effort, if multiple repairs remain plausible, MUST choose an educated assertion using deterministic ranking rules and proceed.
- MUST record provenance in the normalized artifact:
  - `sources_consulted`: stable addresses (e.g., `file:...`, `docs:...`, `cli:...`, `script:...`)
  - `assertions_made`: what fields were inferred/changed
  - `confidence`: high/medium/low per assertion

### B) Normalization output
- MUST produce a normalized artifact with a stable schema and explicit fields listed in Scope.
- MUST assign deterministic derived targets when hints are provided.
- MUST be able to run with only local repo context and the provided story contract text.
- MUST emit a risk flag when inputs imply:
  - network calls
  - credential usage
  - database migrations
  - destructive file operations
- MUST support persistence of the normalized artifact for later stages.

## Contract test specs
0) Story pre-repair is autonomous and evidence-based
   - Given a selected story file that is non-canonical (missing required headers / missing plane oracles / invalid anchor formats)
   - When Normalize runs
   - Then it repairs the story into canonical form (no placeholders) and `scripts/validate_stories.py` passes
   - And the normalized artifact includes `sources_consulted`, `assertions_made`, and `confidence`

1) Minimal input normalization
   - Given a single story contract markdown and no hints
   - When Normalize runs
   - Then it produces a normalized artifact with objective + scope + at least one derived target or an explicit “no target inferred” reason

2) Determinism
   - Given the same inputs twice
   - When Normalize runs twice
   - Then produced normalized artifacts are identical except for allowed metadata (timestamps/run ids)

3) Risk flagging
   - Given inputs referencing secrets or external HTTP
   - When Normalize runs
   - Then the normalized artifact includes a risk flag naming the category (secrets/network)
