story_uuid: 0b844789-830a-4a19-8234-5f706a7e063d
story_id: DF2-IMPL-607
title: Stages: Refactor + VerifyGreen (improve design without behavior change)
required_planes: [auth, api, ui, integrations, ops]

CONTRACT FORMATION MODE: implementation is irrelevant; do not compare against current code/UI. Define user-expected outcomes and test oracles only.

## Intent
Provide an explicit refactor phase after the GREEN checkpoint where code quality can be improved while keeping behavior constant, followed by a verification phase to ensure the system remains green.

## User value
As a developer, I can confidently restructure code (naming, factoring, modularity) knowing there is a dedicated safety net to confirm no regressions.

## Scope
### Refactor stage
- Inputs: GREEN commit (or green result artifacts) + repo workspace.
- Outputs:
  - code changes intended to be behavior-preserving
  - refactor notes (what was changed and why)

### VerifyGreen stage
- Inputs: post-refactor workspace.
- Behavior:
  - re-run the same green gate checks (tests + configured quality gates)
  - declare success only if all gates pass
- Outputs:
  - verify result artifact (gate outcomes, commands, exit codes)

## Out of scope
- Performance benchmarking.
- Semantic diffing of behavior beyond gates and tests.

plane_oracles:
- plane: auth
  oracle: "Refactor and verification run offline using local tools; no external credentials required."
  anchor: "stage:refactor/verify (offline)"
- plane: api
  oracle: "VerifyGreen must run a gate set that is at least as strict as Green (no weaker)."
  anchor: "api:verify_green gate superset constraint"
- plane: ui
  oracle: "CLI clearly distinguishes refactor edits from verification results, and reports any regression with the gate that failed."
  anchor: "cli:refactor + verify outputs"
- plane: integrations
  oracle: "Verify result artifact is compatible with the Green gate schema so downstream tooling can compare gate outcomes."
  anchor: "artifact:gate_result schema reuse"
- plane: ops
  oracle: "If verification fails, the workflow halts before final packaging/commit, preserving the ability to revert/refine refactor safely."
  anchor: "ops:halt on regression"

## Acceptance criteria
- MUST have a dedicated Refactor stage that may modify code but is documented as behavior-preserving.
- MUST have a VerifyGreen stage that:
  - MUST run the configured gates
  - MUST fail the workflow if any gate fails
  - MUST persist a verify result artifact
- MUST ensure VerifyGreen uses the same tests (or superset) as Green.
- MUST provide a diff summary (files touched) for refactor changes.

## Contract test specs
1) VerifyGreen is not weaker than Green
   - Given the configured Green gates are {tests, ruff, mypy}
   - When VerifyGreen runs
   - Then it executes at least {tests, ruff, mypy} (or a declared strict superset)

2) Regression stops workflow
   - Given a refactor that breaks a test
   - When VerifyGreen runs
   - Then it fails with a summary naming the failing test and stage id

3) Artifact compatibility
   - Given a VerifyGreen result artifact
   - When compared against the Green gate result schema
   - Then it conforms (same fields for name/status/command/exit_code/stdout/stderr pointers)
