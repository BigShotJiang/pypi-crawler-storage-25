story_uuid: 73c833cb-8486-4e18-b80a-f553d1261ec4
story_id: US-8.7_execution-errors_to_error-tasks-ingestion
title: US-8.7 execution-errors to error-tasks-ingestion
required_planes: [api, ops]

CONTRACT FORMATION MODE: implementation is irrelevant; do not compare against current code/UI. Define user-expected outcomes and test oracles only.

plane_oracles:
- plane: api
  oracle: "The engine exposes deterministic programmatic behavior and data models required by US-8.7_execution-errors_to_error-tasks-ingestion (inputs/outputs and persistence semantics)."
  anchor: "api:US-8.7_execution-errors_to_error-tasks-ingestion"
- plane: ops
  oracle: "Operational side effects for US-8.7_execution-errors_to_error-tasks-ingestion are deterministic and documented (files/dirs created, idempotency, and safe failure modes)."
  anchor: "docs:user_story/US-8.7_execution-errors_to_error-tasks-ingestion"
# US-8.7 — Execution failures → error tasks ingestion

## User story
As a DevFlow operator,
I want important execution failures to generate error tasks automatically,
so that recurring failures are visible and trackable beyond a single run’s raw error records.

## Scope
- Convert low-level execution `errors` into error tasks.
- Define which failures should create tasks.
- Link back to the originating run/node/tool.

## Out of scope
- Real-time streaming notifications.
- Complex filtering policies (keep to simple rules).

## Contract
### Functional requirements
1. **Ingestion trigger**
   - When a run finishes with `failed` OR a node/tool error meets policy,
     the engine MUST evaluate whether to create/update an error task.

2. **Policy: what becomes an error task**
   - Default policy SHOULD create tasks for:
     - uncaught exceptions
     - test suite failures (if they block green gate)
     - dependency/install failures
     - repeated flaky failures above a threshold (future enhancement)
   - Policy MUST be configurable per project.

3. **Mapping fields**
   - Error task fields derived from execution:
     - `source_kind='execution'`
     - `source_ref` includes `run_id` and if available `node_exec_id`/tool name
     - `title` is a short summary (error_type + message)
     - `severity` inferred (e.g., green gate failure => high)
     - `details` includes:
       - stacktrace (redacted)
       - pointers to artifacts/logs
       - environment summary

4. **Linkage**
   - Ingested task MUST link to:
     - originating `run_id`
     - any captured `errors.error_id` rows
   - Store these links as events or in a link table.

5. **Dedupe**
   - Use fingerprint/dedupe rules (US-8.3).

### Data requirements
- Add optional table: `error_task_occurrences`
  - captures each occurrence (e.g., each run failure) without creating new tasks
  - fields: `error_task_id`, `run_id`, `node_exec_id`, `error_id`, `created_at`

### Observability requirements
- Emit logs on ingest:
  - `event='execution_error.ingested'` with `run_id`, `error_id`, `error_task_id`.

## Acceptance criteria
- [ ] A failing run creates or updates a single canonical error task.
- [ ] Occurrence records capture every run-level occurrence.
- [ ] Stack traces/artifacts are referenced and secrets are redacted.

## Test plan
- Integration: simulate failing run with stored `errors` → task created and occurrence recorded.
- Integration: same failure in second run → occurrence added; `occurrence_count` increments.
