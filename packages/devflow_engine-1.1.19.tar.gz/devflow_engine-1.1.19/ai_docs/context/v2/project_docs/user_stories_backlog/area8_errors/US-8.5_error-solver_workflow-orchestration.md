story_uuid: 759b3214-9fe4-41e6-8bf1-efed00a3b06f
story_id: US-8.5_error-solver_workflow-orchestration
title: US-8.5 error-solver workflow-orchestration
required_planes: [api, ops]

CONTRACT FORMATION MODE: implementation is irrelevant; do not compare against current code/UI. Define user-expected outcomes and test oracles only.

plane_oracles:
- plane: api
  oracle: "The engine exposes deterministic programmatic behavior and data models required by US-8.5_error-solver_workflow-orchestration (inputs/outputs and persistence semantics)."
  anchor: "api:US-8.5_error-solver_workflow-orchestration"
- plane: ops
  oracle: "Operational side effects for US-8.5_error-solver_workflow-orchestration are deterministic and documented (files/dirs created, idempotency, and safe failure modes)."
  anchor: "docs:user_story/US-8.5_error-solver_workflow-orchestration"

# US-8.5 — Error solver workflow DAG: observability → first-pass → iterative-fix → route → resolve/block

## Why this story exists
We already have a proven error-solving **DAG** in DevFlow’s Electron app.
DFE MUST replicate that DAG’s **node flow, stop/route behavior, and persistence artifacts**.

Canonical reference implementation (DevFlow Electron):
- `devFlow/electron/workflows/error-remediation/error-remediation-workflow.ts`
  - nodes: `BuildObservabilityNode` → `FirstPassNode` → `IterativeFixNode` → `FinalOutcomeRouter` → (`ResolveNode` | `BlockNode`)

## User story
As a DevFlow operator,
I want a standard “error solving” DAG workflow that can be executed by an agent or human,
so that error tasks move predictably from discovery to verification and closure,
**with the same operational semantics as the Electron error-remediation DAG**.

## Scope
- Define the canonical DAG nodes and their order.
- Define router conditions and stop conditions.
- Define required persistence artifacts (context/logs) so remediation is resumable.
- Define verification requirements before closure.

## Out of scope
- UI.
- Advanced prioritization policies.

## Contract

### Functional requirements

#### 1) DAG node flow (MUST match Electron)
The error-solving workflow MUST execute these phases in order:
1. **BuildObservability**
2. **FirstPassFix**
3. **IterativeFix**
4. **FinalOutcomeRoute**
5. Terminal: **Resolve** OR **Block**

#### 2) BuildObservability phase
- MUST ensure the error is **observable** before attempting fixes.
- When the runtime context identifies an associated reachable backend whose logs live on production infrastructure, BuildObservability MUST prefer SSH-accessed remote backend log gathering over local backend repo log scanning.
- Local backend repo log scanning is fallback-only and MAY be used only when remote/SSH backend log access is unavailable, missing, or unreachable.
- MUST either:
  - confirm existing reproduction steps are valid, OR
  - enhance observability by adding deterministic repro hooks (tests/logging) so a fix can be verified.

#### 3) FirstPassFix phase
- MUST attempt a first-pass remediation using the verified reproduction method.
- If fixed, MUST short-circuit to terminal `Resolve`.

#### 4) IterativeFix phase
- MUST attempt multiple hypothesis-driven fixes.
- MUST include **null-hypothesis validation** (do not apply fixes without evidence).
- SHOULD cap attempts per run (Electron reference: 3 iterations with batches like 5+4+3 hypotheses).

#### 5) FinalOutcomeRoute phase
The router MUST route to:
- `Resolve` when the error is verified as fixed, OR
- `Block` when user input is required OR attempts are exhausted.

#### 6) Resolve phase
- MUST mark the error task resolved.
- MUST record verification evidence (at minimum: “green gate” or project-defined equivalent).
- MAY create a git commit when operating in a repo.

#### 7) Block phase
- MUST mark the error task as blocked with a reason.

### Persistence / artifacts (MUST be durable)
The workflow MUST persist a per-error context file capturing node outputs over time:
- Electron reference path: `.devflow/errors/logs/<error_id>/context.json`
- DFE may choose a different store, but MUST preserve:
  - metadata: { workflowStarted, errorId, projectPath, errorType, priority, sessionId, title }
  - per-node outputs keyed by node name
  - lastUpdated timestamp

### Status mapping (coarse)
The workflow MUST expose at least these coarse statuses:
- `open` → `in_progress` → (`resolved` | `blocked`)

### Observability requirements
- Emit workflow-level logs/events:
  - `error_solver.observability_built`
  - `error_solver.first_pass_attempted`
  - `error_solver.iterative_fix_attempted`
  - `error_solver.resolved`
  - `error_solver.blocked`

## Acceptance criteria
- [ ] Node order and router behavior matches Electron reference DAG.
- [ ] Workflow produces durable context artifacts with per-node outputs.
- [ ] Resolve requires recorded verification evidence.
- [ ] Block captures a reason and preserves context.

## Test plan
- Integration: observable error → BuildObservability ok → FirstPass fixes → Resolve.
- Integration: observable error → FirstPass fails → IterativeFix succeeds → Resolve.
- Integration: error requires user input → Block with reason.
- Integration: verification fails → does NOT mark resolved; returns to in_progress with recorded details.
