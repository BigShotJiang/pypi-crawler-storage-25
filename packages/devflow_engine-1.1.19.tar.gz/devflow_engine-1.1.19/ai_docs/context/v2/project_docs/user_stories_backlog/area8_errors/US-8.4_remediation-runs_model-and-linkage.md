story_uuid: 25abb094-4a45-4759-b428-6f6f156f06dc
story_id: US-8.4_remediation-runs_model-and-linkage
title: US-8.4 remediation-runs model-and-linkage
required_planes: [api, ops]

CONTRACT FORMATION MODE: implementation is irrelevant; do not compare against current code/UI. Define user-expected outcomes and test oracles only.

plane_oracles:
- plane: api
  oracle: "The engine exposes deterministic programmatic behavior and data models required by US-8.4_remediation-runs_model-and-linkage (inputs/outputs and persistence semantics)."
  anchor: "api:US-8.4_remediation-runs_model-and-linkage"
- plane: ops
  oracle: "Operational side effects for US-8.4_remediation-runs_model-and-linkage are deterministic and documented (files/dirs created, idempotency, and safe failure modes)."
  anchor: "docs:user_story/US-8.4_remediation-runs_model-and-linkage"
# US-8.4 — Remediation runs: model + linkage to error tasks

## User story
As a DevFlow operator,
I want remediation attempts recorded as first-class runs linked to error tasks,
so that I can see what was tried, what changed, and whether it worked.

## Scope
- Define remediation run records and their relationship to error tasks.
- Define outcome semantics that feed back into the error task lifecycle.

## Out of scope
- The specific remediation actions (lint, tests, formatters, etc.).
- GitHub PR creation.

## Contract
### Functional requirements
1. **Create remediation run**
   - When a remediation is started for an error task, the system MUST:
     - create a new run in the execution store with `kind='error.remediate'` (or similarly namespaced kind)
     - link it to the error task via `error_task_runs` (or equivalent link field)
     - transition the error task to `remediating` (guarded by claim if enabled)

2. **Record remediation steps**
   - Remediation run SHOULD emit structured events/artifacts:
     - commands executed, outputs, diffs, test summaries
   - Large payloads MUST be stored as artifacts and referenced.

3. **Outcome classification**
   - Remediation must end in one of:
     - `succeeded` — remediation checks passed
     - `failed` — remediation checks failed
     - `canceled` — operator canceled
   - On completion, the error task MUST transition:
     - `remediating → resolved` if succeeded
     - `remediating → in_progress` (or `blocked`) if failed/canceled, with reason

4. **Idempotency**
   - Starting remediation for the same error task while one is already `remediating` MUST be rejected unless explicitly forced.

### Data requirements
- Add linkage table (indicative): `error_task_runs`
  - `error_task_id`
  - `run_id`
  - `purpose` (`remediation|verification|repro`) (extensible)
  - `created_at`
- Add `latest_remediation_run_id` to `error_tasks` (optional optimization).

### Observability requirements
- Emit logs:
  - `event='remediation.started'|'remediation.finished'`
  - include `error_task_id`, `run_id`, `outcome`.

## Acceptance criteria
- [ ] Starting remediation creates a run and links it to the error task.
- [ ] Error task status transitions to `remediating` and then to `resolved`/`in_progress` based on outcome.
- [ ] A second remediation cannot start concurrently for the same task.

## Test plan
- Integration: start remediation, simulate success → error task becomes `resolved`.
- Integration: start remediation, simulate failure → error task returns to `in_progress` with event noting failure.
