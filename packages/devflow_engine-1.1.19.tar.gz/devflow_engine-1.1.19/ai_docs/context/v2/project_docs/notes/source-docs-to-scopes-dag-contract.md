# Source Docs To Scopes DAG Contract

Date: 2026-03-12

## Purpose

This note defines the implementation-oriented contract for the **source docs -> scopes** DAG.

This DAG is the first structured planning layer in the intended happy path:

1. the project registration workflow has already run via `devflow project init` or `devflow project import`
2. the project is in `ready_for_source_scope`
3. source material is collected
4. DevFlow extracts and shapes candidate scope items
5. those scope items are validated for coverage and traceability
6. the scope set is registered in the project
7. Marcus/client review and approve the scope boundary
8. approved scope items move into the scope->idea sufficiency/enrichment path

The DAG exists to answer one question:

> **Given messy project inputs, what is the client-affirmable scope boundary for this project?**

It is **not** responsible for:
- story generation
- idea sufficiency itself
- implementation decomposition
- silently collapsing affirmed scope into a more convenient internal taxonomy

Its job is to produce a **durable, reviewable, traceable scope set** that downstream systems can trust once approved.

---

## Proposed `WorkflowSchema` role

This workflow should be implemented as the canonical **source-intake-to-scope-registration** schema inside Datalumina/Launchpad.

The `WorkflowSchema` should make these things explicit:
- **event schema**: what intake payload starts the DAG
- **start node**: deterministic intake/inventory, not agentic interpretation
- **node graph**: visible sequencing for extraction, validation, registration, and approval packaging
- **routing**: explicit accept/revise/escalate branches after coverage validation
- **artifact persistence expectations**: each node emits inspectable artifacts into project-local storage and/or registry-backed records

### Suggested workflow responsibility

`source_docs_to_scopes_workflow` should be the single schema responsible for:
- normalizing intake references
- building a source packet
- extracting scope candidates
- shaping a reviewable scope outline
- validating coverage
- registering the draft scope set
- producing an approval-ready package

It should **not** own downstream ideation or story handoff logic beyond preserving the identifiers and traceability that later DAGs require.

---

## Core doctrine

### 1. Scope is a client-facing planning boundary
This DAG should optimize for:
- coverage
- traceability
- readability
- auditability
- reviewability by Marcus and the client

It should **not** optimize for elegant internal implementation grouping at this stage.

### 2. Use all meaningful source material
The DAG should combine any relevant sources it can resolve, including:
- transcripts
- client-prepared docs
- brownfield repo context
- UI maps / screenshots / design notes
- functional request notes
- prior assumptions if relevant

Polished summaries are useful, but they must not erase workflow nuance present elsewhere.

### 3. No blocking questions
If something is unclear:
- log the question
- infer an assumed answer
- record basis and confidence
- move forward

### 4. Preserve evidence
Every meaningful scope item should be explainable from source evidence.
A human should be able to inspect:
- where a scope item came from
- which source snippets support it
- which assumptions were introduced to make it coherent

### 5. Approval is a real boundary
Once scope is approved, downstream systems may enrich and derive from it, but should not casually replace the approved intent.

---

## Happy-path placement

This DAG sits at the front of the planning chain:

- **source docs -> scopes** ← this DAG
- project must already be `ready_for_source_scope`
- human/client approves scope
- approved scope item -> idea sufficiency / scope->idea enrichment
- accepted idea -> idea-to-story DAG
- story -> implementation DAG

So this DAG is the canonical **source-to-scope extraction, validation, and registration** layer.

---

## TaskContext expectations

`TaskContext` should carry both run-level metadata and references to durable artifacts. Avoid stuffing large raw source bodies directly into ad hoc keys when artifact refs are enough.

### Run-level context
Suggested stable keys:
- `project_id`
- `workflow_run_id`
- `source_intake_id`
- `scope_set_id` (once assigned)
- `approval_status` (`draft`, `ready_for_review`, `approved`, `needs_revision`)
- registered scope records should advance to `ready_for_review` once coverage passes and the approval package is emitted
- `retry_count` for revise loops, if enabled

### Source/input references
Suggested keys:
- `input.source_refs[]`
- `input.raw_text_refs[]`
- `input.repo_refs[]`
- `input.design_refs[]`
- `input.note_refs[]`

### Artifact refs written by nodes
Suggested keys:
- `artifacts.source_inventory_ref`
- `artifacts.normalized_source_packet_ref`
- `artifacts.scope_candidates_ref`
- `artifacts.scope_outline_ref`
- `artifacts.scope_coverage_report_ref`
- `artifacts.scope_registry_record_ref`
- `artifacts.approval_package_ref`

### Context discipline
Downstream nodes may assume:
- artifact refs are stable once written
- artifacts are immutable per run version
- routing decisions are reflected in explicit context state, not hidden in prompt text
- all scope items retain upstream lineage to sources and run ids

---

## Inputs

Expected inputs may include any combination of:
- transcript text
- scope drafts
- project briefs
- proposals
- repo paths / brownfield code context
- screenshots
- UI maps
- design artifacts
- schema docs
- API docs
- notes from Marcus

### Input contract intention
The DAG should accept uneven input quality.
It must work when:
- there is a full transcript but weak docs
- there are docs but no transcript
- there is a brownfield repo and only partial written scope
- there is a polished scope draft plus raw supporting material

### Suggested intake event shape

```json
{
  "project_id": "proj_123",
  "source_refs": [
    {"type": "transcript", "path": "..."},
    {"type": "doc", "path": "..."},
    {"type": "repo", "path": "..."},
    {"type": "image", "path": "..."}
  ],
  "requested_by": "marcus",
  "mode": "draft_scope_generation"
}
```

---

## Outputs

Primary outputs should be:
- a **source inventory** artifact
- a **normalized source packet**
- a **scope candidate set**
- a **reviewable scope outline**
- a **scope coverage report**
- a **scope registry record** for project persistence
- an **approval package** for Marcus/client review
- an **assumptions/questions ledger** either embedded or separately referenced

The key durable object is the **registered draft scope set**, which later becomes the **approved scope set** after human review.

---

# Proposed node sequence

## Workflow graph summary

Recommended happy-path graph:

1. `InventorySources` (`Node`)
2. `NormalizeSourcePacket` (`AgentNode`)
3. `ExtractScopeCandidates` (`AgentNode`)
4. `ShapeScopeDocument` (`AgentNode`)
5. `CoverageGate` (`Node`)
6. `CoverageDecisionRouter` (`RouterNode`)
7. `RegisterScopeSet` (`Node`) — on pass / pass_with_assumptions
8. `ApprovalReadyPackage` (`Node`) — on successful registration
9. `EscalationPackage` (`Node`, optional branch) — on revise/escalate

This is intentionally a mostly linear workflow with **one explicit routing point**. There is no strong reason to force concurrency in v1 unless source normalization itself is split into independent extractors.

---

## Node 1 — `InventorySources` (`Node`)

### Intention
Create a normalized inventory of all source material that should influence scope extraction.

### Why this node exists
Most planning errors start before interpretation:
- a repo was ignored
- a transcript was missing
- a polished summary overshadowed raw operational detail
- images or UI maps were not considered

This node makes source inclusion explicit.

### Why `Node`
This step should be deterministic:
- validate provided references
- classify source types using known rules
- resolve file existence / accessibility
- record missing expected sources

If any fuzzy classification is needed, it should be minimal and not determine the workflow’s meaning.

### Inputs
- intake event payload
- provided file paths, text blobs, repo references, URLs, image references, notes

### Outputs
Artifact: `source_inventory.json`

Suggested fields:
- `project_id`
- `source_intake_id`
- `sources[]`
  - `source_id`
  - `source_type` (`transcript`, `scope_doc`, `repo`, `ui_map`, `image`, `notes`, etc.)
  - `location`
  - `title`
  - `content_ref`
  - `ingest_status`
  - `priority`
  - `notes`
- `inventory_summary`
- `missing_expected_sources[]`
- `warnings[]`

### Success condition
The run clearly shows what material was included, what was missing, and what downstream nodes are allowed to inspect.

### Downstream assumption
Later nodes may assume the inventory is the canonical list of inputs for this run.

---

## Node 2 — `NormalizeSourcePacket` (`AgentNode`)

### Intention
Turn messy multi-source input into a structured planning packet containing facts, source-stated assumptions, contradictions, and open questions paired with assumed answers.

### Why this node exists
Raw docs are noisy. This node creates the first coherent project understanding without pretending uncertainty is gone.

### Why `AgentNode`
This is a real interpretation step. It must:
- reconcile multiple noisy source types
- distinguish facts from assumptions
- surface contradictions
- infer likely missing details without overcommitting

That is exactly what `AgentNode` is for.

### Inputs
- `source_inventory.json`
- resolved source contents / source refs

### Outputs
Artifact: `normalized_source_packet.json`

Suggested fields:
- `project_id`
- `source_inventory_ref`
- `facts[]`
- `source_stated_assumptions[]`
- `open_questions_with_assumptions[]`
  - `question`
  - `assumed_answer`
  - `basis`
  - `confidence`
  - `needs_confirmation`
- `contradictions[]`
- `confidence_notes[]`
- `source_summary`
- `domain_summary`
- `lineage[]`

### Success condition
A human reading this packet should understand:
- what the project appears to be
- what is directly supported by source
- what remains uncertain but was assumed

### Downstream assumption
Later nodes may assume ambiguity has been externalized, not silently swallowed.

---

## Node 3 — `ExtractScopeCandidates` (`AgentNode`)

### Intention
Extract candidate scope items from the normalized packet and source evidence.

### Why this node exists
This is the first place the system shapes client-facing planning units. It should identify likely scope blocks without prematurely merging them into implementation buckets.

### Why `AgentNode`
This requires judgment across:
- explicit headings in docs
- recurring requirements in transcripts
- brownfield behavior implied by repo/design context
- missing-but-obvious boundary items needed for coherence

### Inputs
- `normalized_source_packet.json`
- source references / snippets

### Outputs
Artifact: `scope_candidates.json`

Suggested fields:
- `project_id`
- `source_packet_ref`
- `scope_candidates[]`
  - `candidate_id`
  - `title`
  - `description`
  - `source_support[]`
  - `support_strength`
  - `explicit_or_inferred`
  - `assumptions[]`
  - `notes`
- `candidate_gaps[]`
- `candidate_overlap_notes[]`
- `extraction_notes`

### Success condition
This artifact should answer:
- what are the likely scope units?
- which are explicit vs inferred?
- where are there overlaps or likely missing items?

### Downstream assumption
Candidates are not yet the approved taxonomy; they are the best extracted scope units for shaping and validation.

---

## Node 4 — `ShapeScopeDocument` (`AgentNode`)

### Intention
Turn scope candidates into a reviewable scope structure suitable for Marcus/client review.

### Why this node exists
Scope candidates alone are too raw. This node shapes them into something that reads like a coherent scope outline without drifting away from source-supported coverage.

### Why `AgentNode`
This is not just formatting. It requires judgment about:
- wording clarity
- grouping into a readable scope document
- preserving coverage without over-consolidating
- making each scope item understandable to humans

### Inputs
- `scope_candidates.json`
- `normalized_source_packet.json`

### Outputs
Artifact: `scope_outline.json`

Suggested fields:
- `project_id`
- `scope_set_id`
- `scope_set_title`
- `project_summary`
- `scope_items[]`
  - `scope_id`
  - `title`
  - `description`
  - `rationale`
  - `source_support[]`
  - `assumptions[]`
  - `depends_on[]`
  - `review_status` (`draft`)
- `out_of_scope[]`
- `cross_cutting_constraints[]`
- `review_notes[]`
- `assumptions_ledger_ref` or embedded `assumptions_ledger[]`

Optional human-facing artifact:
- `scope_outline.md`

### Success condition
This should be the first artifact Marcus could plausibly review and say:
- “Yes, this looks like the intended project scope boundary.”

### Downstream assumption
Coverage validation can now operate on a stable draft scope set.

---

## Node 5 — `CoverageGate` (`Node`)

### Intention
Check whether the draft scope covers the major supported source requirements and whether unsupported/inferred items are clearly labeled.

### Why this node exists
A readable scope outline can still be incomplete or dishonest. This gate tests coverage before registration and approval packaging.

### Why `Node`
This should be deterministic as much as possible. The gate should compare structured artifacts and emit explicit pass/fail reasons rather than relying on another hidden LLM judgment.

If fuzzy similarity scoring is used internally, the node should still output deterministic-looking reasons and thresholds.

### Inputs
- `normalized_source_packet.json`
- `scope_outline.json`

### Outputs
Artifact: `scope_coverage_report.json`

Suggested fields:
- `coverage_status` (`pass`, `pass_with_assumptions`, `revise`, `escalate`)
- `covered_requirements[]`
- `weakly_covered_requirements[]`
- `uncovered_requirements[]`
- `over_consolidated_scope_items[]`
- `unsupported_inferred_scope_items[]`
- `review_recommendations[]`
- `gate_reasons[]`
- `gate_metrics`
  - `coverage_ratio`
  - `unsupported_item_count`
  - `weak_coverage_count`

### Success condition
This gate should answer:
- did we miss a major requirement?
- did we merge too aggressively?
- did we invent something without enough support?
- is the draft good enough to register and send to review?

### Downstream assumption
Routing can make an explicit decision from this artifact alone.

---

## Node 6 — `CoverageDecisionRouter` (`RouterNode`)

### Intention
Branch the workflow based on the coverage outcome.

### Why this node exists
Accept / revise / escalate is control flow and should be visible in workflow config, not buried inside node code.

### Why `RouterNode`
This is classic first-match-wins branching:
- if `coverage_status == pass` -> register
- else if `coverage_status == pass_with_assumptions` -> register
- else if `coverage_status == revise` -> emit revision/escalation package
- else if `coverage_status == escalate` -> emit escalation package

### Inputs
- `scope_coverage_report.json`
- run metadata from `TaskContext`

### Outputs
Routing outcome only, plus optional artifact:
- `coverage_decision.json`
  - `decision`
  - `reason`
  - `next_node`

### Success condition
The next action is explicit and inspectable.

### Routing policy
Recommended ordered routes:
1. `pass` -> `RegisterScopeSet`
2. `pass_with_assumptions` -> `RegisterScopeSet`
3. `revise` -> `EscalationPackage`
4. `escalate` -> `EscalationPackage`
5. fallback -> `EscalationPackage`

---

## Node 7 — `RegisterScopeSet` (`Node`)

### Intention
Persist the draft scope set and scope items into DevFlow as durable project artifacts.

### Why this node exists
If the scope is not registered, it cannot become the canonical handoff point for approval, ideation, and traceability.

### Why `Node`
This is deterministic persistence and indexing.

### Inputs
- `scope_outline.json`
- `scope_coverage_report.json`
- project/repo context

### Outputs
Artifact: `scope_registry_record.json`

Suggested fields:
- `project_id`
- `scope_set_id`
- `registered_scope_items[]`
  - `scope_id`
  - `registry_path` or record id
  - `status` (`ready_for_review` once registered and packaged for approval)
  - `source_traceability_refs[]`
- `coverage_status`
- `run_id`
- `registration_timestamp`

### Success condition
After this node, DevFlow can resolve scope artifacts by project and scope id.

### Downstream assumption
Approval packaging may reference stable project records instead of ephemeral run-local files only.

---

## Node 8 — `ApprovalReadyPackage` (`Node`)

### Intention
Produce the review package Marcus can inspect and optionally share for client confirmation.

### Why this node exists
The system needs a clean approval handoff, not just internal JSON.

### Why `Node`
Once the substantive artifacts exist, this should mostly be deterministic packaging and formatting.
A small summarization layer is acceptable, but the package should primarily compose existing artifacts.

### Inputs
- `scope_outline.json`
- `scope_coverage_report.json`
- `scope_registry_record.json`

### Outputs
Artifact: `approval_package.json`

Suggested fields:
- `project_id`
- `scope_set_id`
- `scope_summary`
- `scope_items_for_review[]`
- `key_assumptions_to_confirm[]`
- `known_open_questions[]`
- `coverage_status`
- `recommended_next_action`
- `downstream_ready_if_approved`

Optional human-facing output:
- `approval_package.md`

### Success condition
Marcus can decide:
- approve as-is
- revise before client review
- send for client confirmation

---

## Node 9 — `EscalationPackage` (`Node`, optional branch)

### Intention
Produce a concrete revision/escalation package when the draft scope is not yet trustworthy enough to register for review.

### Why this node exists
A failing or weak coverage result should still leave a durable, actionable artifact rather than a dead-end run.

### Why `Node`
This is deterministic packaging of known deficiencies.

### Inputs
- `scope_coverage_report.json`
- `scope_outline.json`
- `normalized_source_packet.json`

### Outputs
Artifact: `scope_revision_package.json`

Suggested fields:
- `project_id`
- `proposed_status` (`needs_revision`, `human_review_required`)
- `major_gaps[]`
- `unsupported_items[]`
- `recommended_revision_actions[]`
- `manual_review_questions[]`

### Success condition
Marcus has a concrete artifact describing why the draft was not accepted and what to fix next.

---

# Artifact contract summary

## `source_inventory.json`
Tracks what evidence exists and what was actually ingested.

## `normalized_source_packet.json`
Creates shared understanding from noisy materials while preserving facts, assumptions, contradictions, and lineage.

## `scope_candidates.json`
Captures candidate scope units before human-facing shaping.

## `scope_outline.json`
Defines the reviewable scope set intended for registration and approval.

## `scope_coverage_report.json`
Determines whether the draft scope is sufficiently complete and honest.

## `scope_registry_record.json`
Makes the scope durable inside DevFlow.

## `approval_package.json`
Packages the draft scope for Marcus/client approval.

## `scope_revision_package.json`
Documents why the run should be revised or escalated instead of advanced.

---

# Deterministic vs agentic split

## Deterministic `Node`s
Use deterministic nodes for:
- intake normalization and source inventory
- schema validation and artifact registration
- coverage gate logic
- routing inputs / decision packaging
- persistence and approval packaging

These steps should be inspectable, repeatable, and minimally prompt-dependent.

## Agentic `AgentNode`s
Use agent nodes for:
- source reconciliation
- ambiguity handling
- extracting scope candidates from messy evidence
- shaping a readable scope document while preserving fidelity

These are judgment-heavy steps and should remain explicitly agentic.

## Why no `ConcurrentNode` in v1
A `ConcurrentNode` is not necessary in the base design because:
- later steps depend on earlier artifact meaning
- observability matters more than shaving a little latency
- the source set is often heterogeneous enough that a single coherent normalization pass is cleaner

Possible future use:
- parallel extractors for entities/workflows/screens from the same normalized packet
- parallel source-specific analyzers before synthesis

But that should be introduced only if latency or specialization justifies the added complexity.

---

# Approval boundary

## Boundary definition
The approval boundary happens **after registration and approval packaging**, not before extraction.

In practical terms:
- this DAG produces a **registered draft scope set**
- Marcus/client approval changes that set’s status to **approved**
- only then does the scope set become the authoritative planning boundary for downstream systems

## What approval means
Once approved, downstream systems may assume:
- the scope set is the canonical coverage boundary for the project phase
- each scope item has stable ids and source traceability
- assumptions are explicit enough to proceed
- idea-generation may enrich scope items but should not silently rewrite their intent

---

# Routing and retry policy

## Routing policy inside this DAG
The only required router in v1 is the post-coverage decision:
- `pass` -> register + package for approval
- `pass_with_assumptions` -> register + package for approval, clearly flagging assumptions
- `revise` -> produce revision package
- `escalate` -> produce human-review package

## Retry policy
This DAG should **not** hide an internal multi-pass agent retry loop by default.

Reason:
- Marcus primarily needs an honest, inspectable draft scope
- silent retries reduce observability
- the richer bounded retry loop belongs more naturally in the downstream scope->idea enrichment process

If a retry loop is later added here, it should be explicit and bounded:
- max 1-2 regeneration attempts
- critic/gate remains separate from extraction/shaping
- each retry writes a new versioned artifact

---

# What downstream systems may assume after scope approval

After the human approval step, downstream DAGs may assume:

1. **Stable scope identity**
   - `project_id`, `scope_set_id`, and `scope_id` are durable and resolvable.

2. **Coverage boundary is affirmed**
   - the approved scope items represent the intended client-facing project boundary for this phase.

3. **Traceability exists**
   - each scope item can be traced back to source evidence and assumptions.

4. **Assumptions are externalized**
   - open questions do not disappear; they exist with assumed answers and confidence notes.

5. **Default planning rule applies**
   - one approved scope item -> one idea candidate by default.
   - splitting a broad scope item is allowed.
   - many scope items -> one idea requires explicit justification.

6. **Downstream enrichment may elaborate, not replace**
   - scope->idea may add structure, acceptance criteria, users, and constraints.
   - it should not casually redefine the approved scope boundary.

---

# Design rules

## 1. Do not optimize for implementation elegance too early
This DAG should produce the right scope, not the cleverest epic taxonomy.

## 2. One explicit requirement can become one scope item by default
Broad items may split. Multiple requirements should not silently collapse into one scope item without reason.

## 3. Evidence beats vibes
Every scope item should be supported by source references or labeled as an assumption-backed inference.

## 4. Keep assumptions explicit
Questions without paired assumptions are not acceptable.

## 5. Routing should be visible in schema/config
Accept / revise / escalate logic should be visible as workflow control flow, not hidden conditionals inside prompts.

## 6. Registration precedes approval
Draft scope becomes durable before the human approval event so the same artifact ids survive review and downstream handoff.

---

# Open implementation notes

Likely future entrypoint shape may look like:

```bash
devflow scope intake --project <project_id> --from <sources...>
```

or a workflow-native runner that:
- resolves the intake event into `TaskContext`
- runs this DAG
- writes versioned artifacts under project-local storage
- registers the draft scope set/items for later approval and handoff

Potential follow-up docs:
- scope registry contract
- scope approval contract
- source intake event schema
- artifact lineage/storage contract

---

# Bottom line

The source docs -> scopes DAG should be the disciplined front door for planning.

Implemented as a Datalumina/Launchpad `WorkflowSchema`, it should turn messy source evidence into a **registered, reviewable, client-affirmable draft scope set** with:
- explicit node typing
- durable artifacts
- visible routing
- strong traceability
- a real approval boundary

That gives the rest of DevFlow a stable upstream artifact to build on.
