# UI Grounding Runtime Implementation Plan

Date: 2026-03-13

This note maps the existing repo structure to the new UI grounding workflow described in:
- `ai_docs/context/v2/project_docs/notes/ui_grounding_workflow_dag_contract.md`
- `ai_docs/context/v2/project_docs/notes/ui-grounding-workflow-note.md`
- `ai_docs/context/v2/project_docs/notes/idea_to_devflow_story_dag_contract.md`

The goal here is not to invent a fresh architecture. It is to place UI grounding into the current DevFlow runtime in the same contract-oriented style already used by:
- `src/devflow_engine/source_scope/dag.py`
- `src/devflow_engine/scope_idea/dag.py`
- `src/devflow_engine/idea/ideation_dag.py`
- `src/devflow_engine/idea/story_pipeline.py`

---

## 1. Best insertion point

## Recommended workflow placement

Best insertion point: **between accepted idea sufficiency and `idea_to_devflow_stories_dag` handoff**.

Concretely, the cleanest runtime seam is inside:
- `src/devflow_engine/idea/ideation_dag.py`
- current flow: `RouteIdeaNode -> SufficiencyGateNode -> HandoffToStoryPipelineNode`

Recommended future flow:
- `RouteIdeaNode`
- `SufficiencyGateNode`
- `HandoffToUIGroundingNode`
- `UIGroundingDecisionNode`
- router:
  - grounded -> `HandoffToStoryPipelineNode`
  - needs review / blocked -> terminal package + stop

### Why this is the best seam in the current repo

1. `idea/ideation_dag.py` already owns the **pre-story gating boundary**.
2. `idea/story_pipeline.py` currently assumes the input idea is already fit for story generation and DFUS compilation.
3. The UI grounding contract explicitly says the check must happen **before** traditional story -> DFUS compilation fully clears.
4. `scope_idea/dag.py` is too early for direct UI grounding execution because its current job is approved scope -> approved idea registration. That module should stay focused on scope splitting / shaping, while only carrying enough traceability for the next DAG.

### Secondary CLI seam

A dedicated CLI should also exist so the workflow can be run directly on an already-registered idea without going through raw idea intake:
- `devflow idea ui-ground`
  - or `devflow idea ui-grounding run`

That matches the current CLI style where the DAG has both:
- a direct callable runtime function
- a Typer entry point

---

## 2. Existing modules and runtime surfaces to reuse

## DAG/runtime framework

Reuse the same vendored workflow primitives already used elsewhere:
- `src/devflow_engine/vendor/datalumina_genai/core/workflow.py`
- `src/devflow_engine/vendor/datalumina_genai/core/schema.py`
- `src/devflow_engine/vendor/datalumina_genai/core/task.py`
- `src/devflow_engine/vendor/datalumina_genai/core/nodes/base.py`
- `src/devflow_engine/vendor/datalumina_genai/core/nodes/agent.py`
- `src/devflow_engine/vendor/datalumina_genai/core/nodes/router.py`
- optional later: `.../nodes/concurrent.py`

The repo pattern is consistent:
- artifact models in `models.py`
- DAG in `dag.py`
- agent wrappers in `agentic.py`
- `WorkflowSchema` + `NodeConfig`
- event model + `run_*_dag(...)`

## Execution / persistence

Reuse:
- `src/devflow_engine/stores/execution_store.py`
- run/node artifact registration pattern used in:
  - `source_scope/dag.py`
  - `scope_idea/dag.py`
  - `idea/story_pipeline.py`

For model-backed steps, reuse the same agent-run persistence pattern as `scope_idea` and `source_scope`:
- stage-specific agent helper module
- persisted envelopes under pipeline-local `agent_runs/`
- lineage metadata that records `model_backed` vs fallback

## Existing path conventions

Use existing repo-local pipeline storage conventions:
- scopes: `.devflow/scopes/<scope_id>/pipelines/<dag_id>/<pipeline_key>/`
- ideas: `.devflow/ideas/<idea_id>/pipelines/<dag_id>/<pipeline_key>/`

UI grounding should therefore live at:
- `.devflow/ideas/<idea_id>/pipelines/ui_grounding_dag/<pipeline_key>/`

And reuse idea path helpers from:
- `src/devflow_engine/idea/paths.py`

## Upstream/downstream modules to integrate with

### Upstream producer
- `src/devflow_engine/scope_idea/dag.py`
  - already registers approved ideas under `.devflow/ideas/<idea_id>/...`
  - already carries traceability / lineage fields on idea artifacts

### Current pre-story orchestrator
- `src/devflow_engine/idea/ideation_dag.py`
  - best place for first orchestration hookup

### Downstream consumer
- `src/devflow_engine/idea/story_pipeline.py`
  - should later consume grounded UI refs from the idea-side artifacts
  - should eventually refuse to compile UI-bearing stories from ideas marked as blocked for missing UI grounding

## CLI surface to reuse

Extend `src/devflow_engine/cli/app.py`.

Existing patterns suggest either:
1. add a nested idea command:
   - `idea ui-ground`
2. or add a new top-level Typer app:
   - `ui-grounding run`

Most repo-consistent choice: **keep it under `idea`**, because the workflow boundary is idea-centric, not source- or scope-centric.

Recommended CLI shape:
- `devflow idea ui-ground --idea <idea_id>`
- later optional flags:
  - `--force-model`
  - `--allow-pencil-generation`
  - `--from-story-set <story_set_id>`
  - `--planes ui,api`

---

## 3. Target package/module locations

Create a new package:
- `src/devflow_engine/ui_grounding/`

Recommended initial files:
- `src/devflow_engine/ui_grounding/__init__.py`
- `src/devflow_engine/ui_grounding/models.py`
- `src/devflow_engine/ui_grounding/agentic.py`
- `src/devflow_engine/ui_grounding/dag.py`

Optional later if the workflow grows:
- `src/devflow_engine/ui_grounding/discovery.py`
- `src/devflow_engine/ui_grounding/anchors.py`
- `src/devflow_engine/ui_grounding/pencil_bridge.py`

Why a new package instead of stuffing this into `idea/`:
- the repo already splits major workflow domains into dedicated packages (`source_scope`, `scope_idea`, `implementation`, `review`, `errors`)
- the contract here is a real DAG boundary, not just a helper inside story compilation

---

## 4. Proposed DAG name and CLI entry points

## DAG/runtime identifiers

Recommended:
- module constant: `DAG_ID = "ui_grounding_dag"`
- workflow class: `UIGroundingWorkflow`
- event model: `UIGroundingDagEvent`
- result model: `UIGroundingDagResult`
- entry point: `run_ui_grounding_dag(...)`

This matches existing naming in:
- `SourceToScopeDagEvent`
- `ScopeToIdeaDagEvent`
- `IdeaStoryDagEvent`

## CLI entry point

Recommended first-class command:
- `devflow idea ui-ground --idea <idea_id>`

Alternative acceptable shape:
- `devflow idea ui-grounding run --idea <idea_id>`

I would start with the shorter command because the repo already has short workflow verbs such as:
- `idea intake`
- `idea stories pipeline`
- `source-scope run`

---

## 5. Artifact schemas/files to add first

Start with the minimum artifact set that mirrors the contract note and fits existing pipeline persistence patterns.

## First-wave models/files

### `ui_grounding_context.json`
Purpose:
- normalized load artifact for the DAG
- combines idea payload, traceability, and any pre-story context already available

Suggested model:
- `UIGroundingContextArtifact`

Fields to include first:
- `project_id`
- `idea_id`
- `idea_ref`
- `parent_scope_id`
- `title`
- `problem`
- `goal`
- `scope`
- `constraints`
- `acceptance_criteria`
- `traceability`
- `required_planes` or requested planes when available
- `candidate_story_inputs` (optional, empty for v1)

### `ui_surface_derivation.json`
Purpose:
- derived list of UI-bearing surfaces implied by the approved idea

Suggested models:
- `DerivedUISurface`
- `UISurfaceDerivationArtifact`

Fields to include first:
- `surface_id`
- `label`
- `surface_kind` (`screen`, `flow`, `entrypoint`, `interaction_cluster`)
- `why_ui_bearing`
- `evidence_refs`
- `confidence`

### `ui_reference_inventory.json`
Purpose:
- normalized inventory of existing UI references already present in repo/design assets

Suggested models:
- `UIReferenceArtifact`
- `UIReferenceInventoryArtifact`

Fields to include first:
- `reference_id`
- `reference_kind` (`existing_ui`, `design_note`, `pencil`, `wireframe`, `story_anchor`)
- `label`
- `path_or_ref`
- `surface_hints`
- `confidence`

### `ui_grounding_report.json`
Purpose:
- semantic match result between derived surfaces and known refs

Suggested models:
- `UIGroundingMatch`
- `UIGroundingReportArtifact`

Fields to include first:
- `surface_id`
- `status` (`grounded_existing`, `partial`, `missing`)
- `matched_reference_ids`
- `reasoning`
- `assumptions`
- top-level `grounding_status`

### `ui_gap_report.json`
Purpose:
- terminal or review package when enough UI grounding does not exist

Suggested model:
- `UIGapReportArtifact`

Fields to include first:
- `idea_id`
- `missing_surfaces`
- `why_blocked`
- `recommended_next_action`
- `requires_human_review`

### `grounded_story_reference_patch.json`
Purpose:
- non-destructive bridge artifact that later story generation can consume
- v1 should prefer writing a patch/manifest instead of mutating canonical story artifacts

Suggested model:
- `GroundedStoryReferencePatchArtifact`

Fields to include first:
- `idea_id`
- `ui_reference_bindings`
- `surface_to_reference_map`
- `ready_for_story_pipeline`

## What not to add in v1

Do **not** start by implementing full Pencil generation or rich design export schemas.
Start by proving:
1. surface derivation
2. inventory
3. match/gap decision
4. durable patch artifact

That is the smallest coherent slice.

---

## 6. Deterministic vs agentic node split

The repo already uses a healthy pattern:
- deterministic nodes for load/package/register/gate work
- `AgentNode` for interpretation-heavy steps
- `RouterNode` for outcome routing

UI grounding should follow that same split.

## Recommended node sequence for v1

### 1. `LoadUIGroundingContextNode`
Type: deterministic `Node`

Responsibilities:
- load approved idea from `.devflow/ideas/<idea_id>/idea.json` or equivalent
- package the upstream traceability and any available story input context
- write `ui_grounding_context.json`

### 2. `DeriveUISurfacesFromIdeaNode`
Type: `AgentNode`

Responsibilities:
- infer whether the idea implies UI-bearing work
- derive candidate surfaces / screens / flows
- write `ui_surface_derivation.json`

Reason this must be agentic:
- this is interpretation-heavy in the same way `AssessScopeGoldilocksNode` and `DraftIdeaFromScopeNode` are

### 3. `InventoryExistingUIReferencesNode`
Type: deterministic `Node`

Responsibilities:
- inspect repo-relative evidence only at first
- gather existing UI-related references from files / known paths / design notes / prior artifacts
- write `ui_reference_inventory.json`

V1 note:
- this can be intentionally conservative and repo-local
- Pencil/MCP discovery can be phase 2

### 4. `MatchUISurfacesToReferencesNode`
Type: `AgentNode`

Responsibilities:
- semantically match derived UI surfaces to the discovered inventory
- classify each surface as grounded / partial / missing
- write `ui_grounding_report.json`

### 5. `UIGroundingDecisionNode`
Type: deterministic `Node`

Responsibilities:
- collapse report into one of the contract states:
  - `grounded_ready`
  - `pass_with_assumptions`
  - `needs_ui_review`
  - `blocked_missing_ui_grounding`

### 6. `UIGroundingDecisionRouter`
Type: `BaseRouter` + `RouterNode`

Responsibilities:
- route to either final patch/ready package or gap/review package

### 7A. `EmitGroundedStoryReferencePatchNode`
Type: deterministic `Node`

Responsibilities:
- write `grounded_story_reference_patch.json`
- optionally write a lightweight `ui_grounding_summary.json`
- mark downstream ready

### 7B. `EmitUIGapReportNode`
Type: deterministic `Node`

Responsibilities:
- write `ui_gap_report.json`
- stop downstream story progression for UI-bearing work

## Not recommended for v1

- `ConcurrentNode`
  - possible later for independent inventory scans
  - unnecessary for the first slice
- direct Pencil generation node
  - important later, but too much for the first coherent implementation

---

## 7. Minimum viable implementation slice

The smallest slice that fits the contract and the current repo is:

1. create `ui_grounding` package
2. implement artifact models
3. implement `run_ui_grounding_dag(...)`
4. support direct CLI execution for an existing registered idea
5. add idea-ideation orchestration hook **only after** the standalone DAG works
6. for v1, inventory only repo-local / existing-artifact references
7. output a patch artifact and a gap artifact, but do not yet mutate downstream story files

### MVP behavioral rule

- if no UI-bearing surface is derived, the DAG should return a benign ready state with an explicit note that no UI grounding was required
- if UI-bearing surfaces are derived but no credible references are found, emit `ui_gap_report.json` and return a blocked/review outcome
- if enough references are found, emit `grounded_story_reference_patch.json` and return ready

That gives the system a real enforcement boundary without overcommitting to design generation on day one.

---

## 8. Tests to add first

Follow the existing test style:
- DAG-focused tests under an area-specific directory
- filesystem artifact assertions
- explicit status / routing assertions

Recommended new test area:
- `tests/area14_ui_grounding/`

## First tests

### `test_ui_grounding_dag_loads_registered_idea_and_writes_context.py`
Asserts:
- registered idea fixture can be loaded
- pipeline dir created at `.devflow/ideas/<idea_id>/pipelines/ui_grounding_dag/...`
- `ui_grounding_context.json` exists

### `test_ui_grounding_dag_detects_non_ui_idea_and_passes_without_gap.py`
Asserts:
- non-UI idea yields no missing UI block
- report explicitly says UI grounding not required or no UI surfaces detected

### `test_ui_grounding_dag_detects_ui_bearing_idea_and_emits_gap_when_no_refs.py`
Asserts:
- UI-bearing idea produces `ui_surface_derivation.json`
- `ui_gap_report.json` exists
- outcome is `needs_ui_review` or `blocked_missing_ui_grounding`

### `test_ui_grounding_dag_matches_existing_ui_refs_and_emits_patch.py`
Asserts:
- existing fixture refs are inventoried
- match report marks at least one surface as grounded
- `grounded_story_reference_patch.json` exists
- outcome is ready/pass-with-assumptions

### `test_idea_ideation_dag_halts_story_handoff_when_ui_grounding_blocks.py`
This should come **after** standalone DAG tests.

Asserts:
- when orchestration is added, UI block prevents `run_idea_to_devflow_stories_dag_async(...)` handoff
- ideation outcome reports UI grounding block cleanly

### CLI test
- `tests/area14_ui_grounding/test_ui_grounding_cli.py`

Asserts:
- `devflow idea ui-ground --idea <idea_id>` exits 0 for ready/review states as designed
- prints pipeline dir / status json similar to other planning DAGs

---

## 9. Repo-specific implementation notes

## Approved idea loading

The current repo already stores idea artifacts under `.devflow/ideas/<idea_id>/...` and uses:
- `src/devflow_engine/idea/paths.py`

That should be the canonical lookup path for this DAG.

## Traceability preservation

`scope_idea/models.py` already preserves:
- `parent_scope_id`
- `traceability`
- lineage metadata

UI grounding should preserve those references rather than replacing them.

## Story pipeline contract impact

`idea/story_pipeline.py` currently compiles story plane oracles with anchors like:
- `artifact:<relative_story_path>`

That is the exact limitation called out in the contract note.

So the right evolution is:
1. UI grounding writes durable UI refs first
2. story pipeline later consumes those refs when generating UI-plane anchors

Not the reverse.

## CLI gap already visible in repo

There is a CLI for:
- `source-scope run`
- `source-scope gate`
- `idea intake`
- `idea stories pipeline`

But there is **not** yet a first-class CLI for `scope_to_idea_dag`, and there is no UI grounding CLI.

That makes UI grounding a good candidate to establish a reusable direct-workflow CLI pattern for post-approval idea workflows.

---

## 10. Recommended order of implementation

1. `ui_grounding/models.py`
2. `ui_grounding/dag.py` with deterministic loading + fallback-capable agent nodes
3. `ui_grounding/agentic.py`
4. standalone CLI: `devflow idea ui-ground`
5. standalone tests under `tests/area14_ui_grounding/`
6. integrate into `idea/ideation_dag.py` between sufficiency and story handoff
7. update `idea/story_pipeline.py` to consume grounded UI refs for UI-plane anchors
8. only then add Pencil-backed generation / external design fill

---

## 11. Recommendation summary

If starting implementation now, the best coherent first slice is:
- add `src/devflow_engine/ui_grounding/`
- implement a standalone `ui_grounding_dag`
- expose `devflow idea ui-ground --idea <idea_id>`
- write five durable artifacts:
  - `ui_grounding_context.json`
  - `ui_surface_derivation.json`
  - `ui_reference_inventory.json`
  - `ui_grounding_report.json`
  - either `ui_gap_report.json` or `grounded_story_reference_patch.json`
- after that, splice the DAG into `idea/ideation_dag.py` before story handoff

That keeps the implementation aligned with the repo’s current contract-oriented DAG pattern and avoids overreaching into Pencil generation before the runtime seam is proven.
