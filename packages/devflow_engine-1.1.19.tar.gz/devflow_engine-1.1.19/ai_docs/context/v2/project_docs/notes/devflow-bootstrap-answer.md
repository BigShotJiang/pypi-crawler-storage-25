What works today

- `devflow idea init --idea <id> --title "<title>"` can persist a minimal idea record even in a plain directory with no `.git` and no prior `devflow project init`. In a local check, it created `.devflow/execution.sqlite` and `.devflow/ideas/<id>/idea.json`.
- `devflow idea sufficiency --text ...` also works without a project, but it is analysis-only. It returns JSON and exits non-zero for vague input; it does not persist an idea artifact by itself.
- `devflow project init --name <name>` can bootstrap repo-local DevFlow state in the current directory and, in a plain non-git directory, it created `.devflow/config.yaml`, `.devflow/execution.sqlite`, and `.devflow/registry.sqlite`.
- `devflow project import <dest> --init python|typescript|next|react-native` is the command that actually creates a new repo skeleton. In a local check with `--init python`, it created `.git`, `README.md`, `pyproject.toml`, `src/...`, `.devflow/...`, and a global project registry entry in `$DEVFLOW_HOME/.devflow/registry/projects.json`.

What does not work today

- `devflow idea init` does not register a project, create a git repo, or create a real app skeleton. It only stores a minimal `idea.json` with `idea_id` and `title`.
- `devflow idea sufficiency` does not store the idea for later use unless some other command writes `idea.json`.
- `devflow project init --name <name>` does not create `.git` or an application skeleton. It is local DevFlow-state bootstrap, not new-project creation.
- Starting from “just an idea” does not have a single command that both creates the repo/skeleton and records the idea in one step.

Exact recommended flow today

1. Create the project workspace/repo first:
   `devflow project import /absolute/path/to/<project-name> --init python`
   or:
   `devflow project import /absolute/path/to/<project-name> --init typescript`
2. `cd /absolute/path/to/<project-name>`
3. Persist the idea seed if you want a durable idea artifact:
   `devflow idea init --idea <idea-id> --title "<short title>"`
4. Check idea quality from raw text:
   `devflow idea sufficiency --text "<structured idea text>"`
5. Once the idea is specific enough, continue with the idea pipeline inside that repo:
   `devflow idea stories pipeline --idea <idea-id> --text "<structured idea text>" --planes api`

Short answers

- Q1: Yes, partially. Ideation can store a minimal idea artifact without a project/repo, but not a meaningful full project bootstrap.
- Q2: Yes, but not via `project init --name`. The working bootstrap command is `project import <dest> --init <template>`.

Gaps / regressions to fix

- `project import --init ...` now routes through the project-registration workflow and runs repo-local registration against the imported repo root, not the caller cwd.
- Add one explicit “new project from idea” bootstrap command that accepts minimal inputs like project name + template + idea text and wires together repo creation, project registration, and idea persistence.
- Make `idea sufficiency` optionally persist/update `idea.json`, or add a first-class `idea capture` command, so analysis and storage are not split awkwardly.
