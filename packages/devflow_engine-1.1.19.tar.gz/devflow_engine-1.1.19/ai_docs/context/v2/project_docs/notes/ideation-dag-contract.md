# Ideation DAG contract

## Purpose

`idea_ideation_dag` is the first-pass intake gate for software change requests.

It is intentionally thin:

1. Run explicit Devin intake.
2. Route/classify whether the request looks like software-delivery work using a first-class router node.
3. Route non-software / ambiguous requests through the insight arm: `InsightResolutionNode -> DevinAgentLoopNode -> DevinResponsePostNode`.
4. Keep `InsightResolutionNode` deterministic and lightweight: gather compact evidence only, no heavyweight report generation.
5. Run ideation sufficiency on software-suitable requests through the ideation arm.
6. Return structured deficiencies + follow-up questions when insufficient.
7. Post the Devin response into `agent_agent_messages` using the real AAM contract.
8. Run the real Devin agent loop through the configured DevFlow CLI runtime.

The DAG does **not** duplicate the story pipeline. It delegates story generation/registration to the existing DAG and returns the resulting story identifiers.

## CLI entrypoint

```bash
devflow idea intake --idea <idea_id> --text "..."
# or
devflow idea intake --idea <idea_id> --from ./idea.txt
```

Optional:

- `--max-stories 3`
- `--planes api,ui`

## Outcome contract

The command returns a single JSON object with one of these statuses:

### 1) Redirect

Returned when the request does not look software-delivery scoped.

```json
{
  "status": "redirect",
  "idea_id": "...",
  "is_software_dev": false,
  "redirect": {
    "target": "human_or_generalist_agent",
    "reason": "non_software_or_ambiguous_request",
    "suggestion": "..."
  }
}
```

### 2) Needs clarification

Returned when the request is software-related but not sufficient for story generation.

```json
{
  "status": "needs_clarification",
  "idea_id": "...",
  "deficiencies": ["problem", "scope"],
  "follow_up_questions": ["..."],
  "sufficiency": {
    "story_generation_pass": false,
    "identified_gaps": ["problem", "scope"]
  }
}
```

### 3) Accepted

Returned when the request is software-suitable and sufficient, and the downstream story pipeline succeeds.

```json
{
  "status": "accepted",
  "idea_id": "...",
  "ideation_run_id": "run_...",
  "story_pipeline_run_id": "run_...",
  "story_set_id": "tus_...",
  "devflow_story_set_id": "dfs_...",
  "ideation_pipeline_dir": ".../pipelines/idea_ideation_dag/...",
  "story_pipeline_dir": ".../pipelines/idea_to_devflow_stories_dag/..."
}
```

## Node outputs

### `DevinIntake`

Artifact: `devin_intake.json`

Fields:

- `devin_intake_pass`
- `project_id`
- `raw_text`
- `grounded_raw_text`
- `input_meta`
- `history_grounding`
- `route`

### `DevinIntakeRouter`

Artifact: `route.json`

Fields:

- `route_pass`
- `is_software_dev`
- `software_signals`
- `non_software_signals`
- `reason`
- `redirect`

### `IdeaContextResolution`

Artifact: `idea_context_resolution.json`

Fields:

- `source_doc_mutation_request`
- `source_doc_mutation_ref`
- `project_id`
- `active_idea_id`

### `InsightResolution`

Artifact: `insight_resolution.json`

Fields:

- `status=resolved`
- `route`
- `insight_resolution.kind=insight_resolution_packet.v1`
- `insight_resolution.source_doc_paths`
- `insight_resolution.project_doc_paths`
- `insight_resolution.code_paths`
- `insight_resolution.search_hits`
- `insight_resolution.relevance_notes`

### `DevinAgentLoop`

Artifacts:

- `sufficiency.json`
- `devin_response.json`
- `devin_agent_loop_prompt.json`
- `devin_agent_loop_stream.json`
- `devin_agent_loop_terminal.json`
- `agent_runs/devin_agent_loop_response.json`

Fields:

- evaluated sufficiency payload
- persisted working-idea path via `active_idea.artifact_path`
- `response_kind`
- `follow_up_questions`
- `source_doc_state.mutation_ref` for ideation-arm runs
- `insight_resolution` packet for insight-arm redirect runs
- streamed stdout/stderr + log path when the full CLI loop executes
- session id / return code
- terminal status

### `DevinResponsePost`

Artifact: `devin_response_post.json`

Fields:

- `request.session_id`
- `request.from_agent`
- `request.to_agent`
- `request.message`
- `request.metadata`
- `response_record.id`
- `response_record.status`

### `DevinAgentLoop`

Artifacts:

- `devin_agent_loop_prompt.json`
- `devin_agent_loop_stream.json`
- `devin_agent_loop_terminal.json`

Fields:

- configured CLI base/delivery
- streamed stdout/stderr + log path
- session id / return code
- terminal status

### `HandoffStoryPipeline`

Artifact: `handoff.json`

Fields:

- `handoff_pass`
- `story_pipeline_run_id`
- `story_set_id`
- `devflow_story_set_id`
- `pipeline_dir`
- `story_pipeline_message`

## Devin shim usage

A Devin-side shim should call `devflow idea intake` first, not `devflow idea stories pipeline` directly.

Recommended handling:

- `status=redirect` -> respond in chat with the redirect guidance.
- `status=needs_clarification` -> ask the returned follow-up questions and re-submit the improved request.
- `status=accepted` -> persist/forward `story_set_id` and `devflow_story_set_id` as the registered planning output for the change request.

This keeps Devin’s ideation lane conversational while preserving DevFlow as the source of truth for accepted story sets.

---

## Pivot note — scope-preserving enrichment loop

As of 2026-03-12, Marcus is considering a near-term pivot away from treating the new onboarding DAG as the primary top-level grouping engine.

### Why
The first onboarding DAG implementation proved useful for:
- source normalization
- entity / workflow / actor extraction
- assumptions capture
- idea-shaped enrichment

But it also exposed a mismatch with Marcus’s actual workflow:
- source materials + transcripts are synthesized into a scope document
- the client explicitly affirms that scope document
- that affirmed scope means: **"we are on the same page"**
- therefore, scope sections should usually survive as planning units

Marcus explicitly prefers:
- one scope item -> one idea by default
- one broad scope item -> multiple ideas when needed
- many scope items -> one idea only with explicit justification

### Proposed direction
Instead of asking onboarding to invent the final top-level idea grouping, Marcus is considering a loop like this for each scope item:

1. take the affirmed scope block
2. run existing ideation / Devin sufficiency on it
3. inspect the returned insufficiency planes / gaps
4. have an onboarding/enrichment agent review transcripts, source docs, repo context, and existing assumptions
5. enrich the scope block into a better idea-shaped version
6. record any new assumptions needed to proceed
7. feed the revised scope block back into sufficiency
8. repeat with bounded retries until sufficient enough

### Implication for this contract
If this pivot is adopted, `idea_ideation_dag` becomes even more important because it stays the canonical sufficiency gate.

In that model:
- onboarding/enrichment does not replace ideation sufficiency
- onboarding/enrichment improves each affirmed scope unit until ideation sufficiency accepts it
- Devin shim / ideation feedback becomes the pressure test that shapes enriched ideas

That is likely a better fit for Marcus’s real planning flow than early consolidation inside onboarding.

### Happy path placement
In the intended end-to-end flow, this DAG sits after scope approval and before story generation:

1. source materials are converted into registered scope items
2. a human/client approves the scope coverage
3. each approved scope item is submitted to `idea_ideation_dag`
4. if sufficient, the scope item becomes a registered idea
5. if insufficient, onboarding/enrichment revises and resubmits it (up to 3 times)
6. accepted ideas are then handed to the story-generation DAG

So this DAG is the canonical **scope-to-accepted-idea gate** in the happy path.
