# Source Doc Mutation DAG Contract

## Purpose

`source_doc_mutation_dag` should become the canonical, inspectable pipeline that takes a new ideation-arm message and updates:

- canonical source docs under `ai_docs/context/source_docs/`
- derived project docs produced from those source docs
- the assumptions registry tied to those source docs

This DAG exists to remove source-doc mutation and assumption-registration logic from `IdeaContextResolutionNode` in `src/devflow_engine/idea/ideation_dag.py` and replace the current queued helper/process with a first-class workflow contract.

---

## Canonical ideation-arm placement

Marcus's intended ideation arm is:

1. `IdeaContextResolutionNode`
2. `DevinAgentLoopNode`
3. `DevinResponsePostNode`

That sequence already exists in `IdeaIdeationWorkflow`:

- `NodeConfig(node=IdeaContextResolutionNode, connections=[DevinAgentLoopNode])`
- `NodeConfig(node=DevinAgentLoopNode, connections=[DevinResponsePostNode])`
- `NodeConfig(node=DevinResponsePostNode, connections=[])`

The contract for `source_doc_mutation_dag` is therefore:

- it is **invoked by** `IdeaContextResolutionNode`
- it is **not** a replacement for the ideation arm
- it must finish by emitting durable mutation artifacts that `DevinAgentLoopNode` can read or reference
- `DevinResponsePostNode` remains the posting boundary after the real loop completes

This DAG must also be invokable outside conversational ideation during:
- project initialization
- project import
- repo bootstrap before any user message exists

---

## Core doctrine

- Source docs are canonical.
- Derived project docs are downstream renderings, not the source of truth.
- Assumptions are first-class and must be explicitly registered, reconciled, and inspectable.
- `IdeaContextResolutionNode` may prepare the request and persist a lightweight ref, but it must not own ongoing mutation logic.
- `source_doc_mutation_dag` must expose exact artifacts and exact node boundaries.
- Downstream must be able to tell the difference between:
  - explicit grounded source-doc facts
  - inferred heuristic defaults
  - unresolved open assumptions
  - derived/project-doc render output
- No artifact may imply richer synthesis than actually occurred.

---

## Why this DAG exists

Current repo state has two different behaviors mixed together:

### Current inline ideation behavior

`_build_source_doc_state(...)` in `src/devflow_engine/idea/ideation_dag.py` currently:

- reads source docs
- heuristically derives product summary/problem/users/goals/scope
- heuristically seeds workflow/entity drafts
- registers open assumptions
- writes canonical source docs directly
- writes `assumptions_registry.json` directly

This is still inline ideation-owned mutation logic.

### Current queued helper behavior

`_invoke_source_doc_mutation_process(...)` currently does **not** run a standalone DAG. It calls `enqueue_source_doc_update_if_needed(...)` from `src/devflow_engine/source_docs_updater.py`, which only:

- detects changed source-doc files
- optionally enqueues `SOURCE_DOC_UPDATE_TASK_KIND = "project.source_docs.update"`
- later renders markdown/project-doc outputs via `apply_source_doc_updates(...)`
- reconciles assumption status against current explicit source-doc values

So the current "mutation process" is actually:

1. inline source-doc mutation in ideation
2. optional queued project-doc sync/reconciliation helper

That is exactly the transitional split this contract is meant to eliminate.

---

## Exact current-state code grounding

### Existing ideation nodes

From `src/devflow_engine/idea/ideation_dag.py`:

- `IdeaContextResolutionNode` — deterministic `Node`
- `DevinAgentLoopNode` — deterministic wrapper `Node` around actual agent execution / response generation
- `DevinResponsePostNode` — deterministic `Node`

### Existing source-doc schema contract

From `src/devflow_engine/source_docs_schema.py`:

Canonical source-doc filenames are:

- `product_brief.json`
- `user_workflows.json`
- `domain_entities.json`
- `assumptions_registry.json`

Supported mutation section kinds are:

- `string`
- `scalar_list`
- `object`
- `keyed_list`

Canonical mutation helper already exists:

- `apply_source_doc_mutation(...)`

### Existing source-doc/project-doc updater contract

From `src/devflow_engine/source_docs_updater.py`:

Deterministic helper functions already exist for the future DAG:

- `ensure_source_doc_scaffold(...)`
- `detect_source_doc_changes(...)`
- `apply_source_doc_updates(...)`
- `enqueue_source_doc_update_if_needed(...)`
- `handle_source_doc_update_task(...)`

Current updater output types already exist conceptually:

- changed source doc list
- updated derived output list
- updater state file
- reconciled assumptions registry

---

## Current-state vs target-state

## Current state

### What exists today

- `IdeaContextResolutionNode` calls `_build_source_doc_state(...)`
- `_build_source_doc_state(...)` heuristically writes canonical source docs directly
- `_build_source_doc_state(...)` heuristically writes `assumptions_registry.json` directly
- `_invoke_source_doc_mutation_process(...)` only enqueues or noops a source-doc update helper
- `DevinAgentLoopNode` consumes only a lightweight `source_doc_mutation_ref`
- actual mutation artifacts are not yet standardized as first-class DAG outputs

### Important current inconsistencies

1. **Standalone DAG entrypoint now exists**
   - `src/devflow_engine/source_doc_mutation_dag.py` exposes the canonical `source_doc_mutation_dag` entrypoint
   - ideation invokes it directly and persists a lightweight DAG ref

2. **Path contract is now tightened for DAG artifacts**
   - canonical source docs live under `ai_docs/context/source_docs/`
   - DAG-derived project docs render to `ai_docs/context/v2/project_docs/source_docs/`
   - per-run DAG artifacts live under `.devflow/ideas/<idea-or-bootstrap>/pipelines/source_doc_mutation_dag/<pipeline_key>/`
   - the legacy updater helper still uses `ai_docs/context/project_docs/.source_doc_updater_state.json`, but DAG refs/results now point only at real DAG artifact locations

3. **Mutation responsibility is still partially split**
   - ideation performs mutation
   - updater performs change detection / project-doc render / assumption reconciliation
   - no single artifact envelope owns the whole run

## Target state

### What this contract requires

- create a real workflow entrypoint: `source_doc_mutation_dag`
- move source-doc mutation ownership out of `_build_source_doc_state(...)`
- keep `IdeaContextResolutionNode` responsible only for:
  - building the mutation request
  - invoking the DAG
  - storing a lightweight ref
- make the DAG itself own:
  - scaffold/normalization
  - canonical source-doc mutation
  - assumptions registry reconciliation
  - derived project-doc sync
  - final artifact emission
- make `DevinAgentLoopNode` consume the DAG result/ref as the canonical source-doc state envelope

---

## Canonical start and end conditions

## Start condition

`source_doc_mutation_dag` starts when either:

### A) ideation-triggered mutation
`IdeaContextResolutionNode` has:
- accepted ideation-arm routing
- resolved `project_id`
- loaded `raw_text` / grounded context
- built a mutation request packet

### B) init/import/bootstrap-triggered mutation
A project/repo lifecycle flow has:
- resolved `project_id` if available
- resolved `repo_root`
- determined that no user ideation input is available yet or no explicit source-doc mutation payload was provided
- built a bootstrap-mode mutation request packet

## End condition

`source_doc_mutation_dag` ends when it has emitted a terminal result envelope that states:

- whether canonical source docs changed
- which source docs changed
- whether assumptions registry reconciliation succeeded
- whether project-doc sync succeeded
- which artifact files were written
- what trust level downstream should apply

---

## Input contract

Canonical request artifact:

- `source_doc_mutation_request.json`

Minimum fields:

```json
{
  "contract": "source_doc_mutation_dag.request.v1",
  "mode": "ideation_mutation | repo_bootstrap | scaffold_only",
  "project_id": "<project_id>",
  "idea_id": "<idea_id|null>",
  "repo_root": "<repo_root>",
  "raw_text": "<latest ideation message or empty>",
  "grounded_raw_text": "<history-grounded text if available>",
  "history_grounding": {
    "project_id": "<project_id>",
    "history_message_count": 0,
    "included_history_message_count": 0,
    "session_ids": []
  },
  "invoked_from": "IdeaContextResolutionNode | project_init | project_import | repo_bootstrap",
  "source_run_id": "<ideation_run_id or bootstrap_run_id>",
  "message_correlation": {
    "message_id": "<optional>",
    "session_id": "<optional>",
    "pipeline_key": "<optional>"
  }
}
```

Notes:

- `grounded_raw_text` should be preferred over raw text when available.
- The request should carry enough data for the DAG to run without re-reading ideation node-local state.
- The request should not contain inflated inline result payloads from downstream nodes.
- `repo_bootstrap` means: inspect the existing repo/files/code/docs and build initial source docs/project docs if there is enough genuine signal.
- `scaffold_only` means: create source-doc templates, derived project-doc shells/index, and otherwise leave content empty/minimal because the repo is too sparse to support a genuine idea shape.
- If there is no user idea input and no explicit source-doc payload, the DAG should prefer `repo_bootstrap` first and downgrade to `scaffold_only` only when repo evidence is too sparse.

---

## Support-index contract

`source_doc_mutation_dag` must load and expose three canonical support indexes, classified as support docs rather than eval docs:

- `internal_source`
- `internal_project`
- `cross_sourceXproject`

Canonical machine-readable locations:
- `docs/support/source_doc_mutation/internal_source.json`
- `docs/support/source_doc_mutation/internal_project.json`
- `docs/support/source_doc_mutation/cross_sourceXproject.json`

These indexes are pre-generated contract artifacts. They are not derived from current content at runtime.

Runtime requirement:
- `NormalizeAndGatherSupportContextNode` loads them into support context
- `ProjectDocImpactRoutingNode` uses them to map changed source sections into impacted project docs
- downstream project-doc mutation/coherence payloads may carry them forward as support context

The older markdown docs remain human-readable mirrors/support references, but the JSON indexes are the routing contract the DAG should treat as canonical.

## Output artifacts

These are the canonical durable artifacts for `source_doc_mutation_dag`.

### Required v1 artifacts

1. `source_doc_mutation_request.json`
2. `source_doc_inventory.json`
3. `source_doc_mutation_plan.json`
4. `source_doc_change_set.json`
5. `assumptions_delta.json`
6. `project_doc_sync_result.json`
7. `source_doc_mutation_result.json`

### Artifact intent

#### `source_doc_inventory.json`
Snapshot of pre-mutation source-doc state and resolved paths.

#### `source_doc_mutation_plan.json`
Explicit statement of what the DAG intends to mutate, including whether each change is:

- explicit/grounded
- inferred/heuristic
- no-op

#### `source_doc_change_set.json`
Canonical list of source-doc mutations actually applied.

#### `assumptions_delta.json`
List of assumptions added, confirmed, rejected, superseded, or unchanged during this run.

#### `project_doc_sync_result.json`
Deterministic record of which derived docs were regenerated and where.

#### `source_doc_mutation_result.json`
Terminal envelope combining run status, artifact pointers, and trust contract.

---

## Cheap ref artifact returned to ideation arm

`IdeaContextResolutionNode` should store only a lightweight ref in task metadata and its node artifact.

Canonical ref shape:

```json
{
  "contract": "source_doc_mutation_dag.ref.v1",
  "dag_id": "source_doc_mutation_dag",
  "run_id": "<run_id>",
  "status": "queued|running|completed|failed",
  "artifact_root": "<pipeline_dir>",
  "result_artifact": "source_doc_mutation_result.json",
  "change_set_artifact": "source_doc_change_set.json",
  "assumptions_delta_artifact": "assumptions_delta.json",
  "project_doc_sync_artifact": "project_doc_sync_result.json",
  "changed_docs": ["product_brief.json"],
  "trust_level": "source_docs_mutated|no_source_doc_changes|failed"
}
```

Rules:

- no expanded full payload in ideation metadata
- `DevinAgentLoopNode` may dereference artifacts if needed
- the ref must not claim more than the DAG actually completed

---

## Final required node sequence for `source_doc_mutation_dag`

Marcus's planned architecture is the canonical contract for this DAG.

1. `NormalizeAndGatherSupportContextNode` — deterministic `Node`
2. parallel source section agents:
   - `ProductBriefSectionAgentNode` — `AgentNode`
   - `UserWorkflowsSectionAgentNode` — `AgentNode`
   - `DomainEntitiesSectionAgentNode` — `AgentNode`
3. `SourceDocCoherenceNode` — deterministic `Node`
4. `PersistSourceDocsAndAssumptionsNode` — deterministic `Node`
5. `ProjectDocImpactRoutingNode` — deterministic `RouterNode`/routing `Node`
6. `SpawnProjectDocMutationSubagentsNode` — deterministic orchestration `Node`
7. `AwaitProjectDocMutationSubagentsNode` — deterministic barrier `Node`
8. `ProjectDocCoherenceNode` — deterministic `Node`
9. `PersistProjectDocsNode` — deterministic `Node`

Mandatory graph semantics:
- node 2 is a parallel fan-out over the three section agents
- node 8 cannot begin until node 7 confirms all project-doc mutation subagents spawned by node 6 have completed
- helper/module substitutes, collapsed chains, or renamed approximations are not acceptable contract matches

## Transitional implementation note

The checked-in runtime is still behind this contract. At time of writing it still emits an older deterministic chain centered on `ApplyDeterministicMutationNode` plus direct project-doc sync. That runtime should be documented as transitional only; it must not be described as already satisfying the required graph above.

### Why these names

They map to the desired responsibilities rather than the older helper-shaped chain:

- support-context normalization gathers request lineage, current source docs, and bounded grounding evidence once
- the three section agents own source-doc interpretation in parallel instead of collapsing everything into one heuristic mutation step
- source-doc coherence resolves cross-section conflicts before persistence
- source-doc persistence creates the canonical checkpoint for both source docs and assumptions
- project-doc impact routing decides which downstream project docs need mutation
- spawned project-doc mutation subagents handle independent downstream document mutations
- the await barrier enforces completion before any project-doc coherence pass
- final project-doc persistence writes the coherent downstream project-doc state

---

## Node-by-node contract

### 1. `LoadSourceDocMutationRequestNode`
Type: deterministic `Node`

Purpose:
- validate and normalize the mutation request
- resolve repo/project/run lineage

Inputs:
- workflow event
- `source_doc_mutation_request.json`

Outputs:
- normalized request payload in task context
- persisted request artifact

Success condition:
- request is valid and complete enough to continue

Downstream may assume:
- request lineage fields are stable
- `project_id`, `idea_id`, `repo_root`, and message input are available

---

### 2. `LoadSourceDocInventoryNode`
Type: deterministic `Node`

Purpose:
- ensure canonical source-doc scaffold exists
- load current source-doc payloads
- capture pre-mutation hashes/paths

Inputs:
- normalized request

Outputs:
- `source_doc_inventory.json`

Should reuse/align with:
- `ensure_source_doc_scaffold(...)`
- `get_source_doc_paths(...)`
- current source-doc schema normalizers

Success condition:
- all canonical source-doc files are present and normalized

Downstream may assume:
- pre-mutation source docs are loaded and path-resolved

---

### 3. `ApplySourceDocMutationPlanNode`
Type: deterministic `Node` in v1

Purpose:
- apply message-driven source-doc mutations
- register new open assumptions when facts are not explicit
- emit the actual source-doc change set

Inputs:
- normalized request
- loaded source-doc inventory

Outputs:
- updated source docs on disk
- `source_doc_mutation_plan.json`
- `source_doc_change_set.json`

Should absorb current inline logic from:
- `_build_source_doc_state(...)`

V1 execution doctrine:
- deterministic and code-driven
- may reuse heuristic extraction already present in ideation code
- must mark inferred changes as inferred
- must not present inferred values as grounded facts

Success condition:
- source docs are either mutated or explicitly determined unchanged
- assumptions introduced during mutation are recorded

Downstream may assume:
- source docs on disk reflect this run's applied mutation plan
- change set is inspectable

Downstream may **not** assume:
- source docs are fully refined
- heuristic fills are confirmed facts
- unresolved assumptions are settled

---

### 4. `ReconcileAssumptionsRegistryNode`
Type: deterministic `Node`

Purpose:
- reconcile assumption lifecycle after mutation
- classify assumptions as open, confirmed, rejected, or superseded

Inputs:
- updated source docs
- assumptions registry
- changed doc list

Outputs:
- updated `assumptions_registry.json`
- `assumptions_delta.json`

Should reuse/align with:
- `normalize_assumptions_registry(...)`
- `reconcile_assumptions_registry(...)`

Success condition:
- assumptions registry status transitions are correct and inspectable

Downstream may assume:
- assumption statuses in the registry are up to date for this run

Downstream may **not** assume:
- all open assumptions are resolved

---

### 5. `SyncDerivedProjectDocsNode`
Type: deterministic `Node`

Purpose:
- regenerate derived project-doc outputs from canonical source docs
- emit exact sync results

Inputs:
- changed source docs
- normalized source-doc payloads

Outputs:
- regenerated derived docs
- `project_doc_sync_result.json`

Should reuse/align with:
- `apply_source_doc_updates(...)`

Contract requirement:
- this node must standardize the target derived-doc root and stop the current path ambiguity between `context/project_docs` and `context/v2/project_docs`

Success condition:
- derived outputs are refreshed or explicit failure/no-op is recorded

Downstream may assume:
- any listed derived doc was generated from the post-mutation canonical source docs

Downstream may **not** assume:
- derived docs contain additional interpretation beyond what the source docs support

---

### 6. `EmitSourceDocMutationResultNode`
Type: deterministic `Node`

Purpose:
- package the final result envelope
- publish trust contract and artifact refs

Inputs:
- outputs from all prior nodes

Outputs:
- `source_doc_mutation_result.json`
- lightweight ref payload for ideation metadata

Success condition:
- final envelope accurately reports terminal state and trust boundaries

Downstream may assume:
- artifact refs are stable
- trust/not-trust boundaries are explicit

---

## What downstream may trust

After `source_doc_mutation_dag` completes successfully, downstream may trust:

1. the canonical source-doc files exist
2. the source-doc files represent the latest mutation attempt for that ideation message
3. `source_doc_change_set.json` accurately lists what changed vs no-op
4. `assumptions_registry.json` and `assumptions_delta.json` reflect the post-mutation assumption state
5. any derived project docs listed in `project_doc_sync_result.json` were regenerated from the resulting canonical source docs
6. the final result envelope truthfully states whether the run completed, noop'd, or failed

---

## What downstream may not trust

Downstream must **not** assume, unless another artifact explicitly says so, that:

1. all source-doc content is grounded fact
2. inferred defaults are confirmed
3. open assumptions are resolved
4. source docs are sufficient for scope generation or story generation
5. ideation sufficiency has passed
6. agentic interpretation already occurred
7. project docs are canonical
8. the mutation DAG performed any real model-backed synthesis

In other words:

- trust canonical persistence and change traceability
- do **not** trust epistemic certainty beyond what the artifact explicitly claims

---

## Explicit trust labeling requirement

`source_doc_mutation_result.json` must include a section like:

```json
{
  "trust_contract": {
    "may_trust": [
      "canonical_source_docs_written",
      "change_set_recorded",
      "assumptions_registry_reconciled",
      "derived_project_docs_synced_if_listed"
    ],
    "may_not_trust": [
      "all_values_are_grounded_facts",
      "all_open_assumptions_resolved",
      "scope_readiness",
      "downstream_story_readiness",
      "agentic_interpretation_completed"
    ]
  }
}
```

That section should be treated as contract, not commentary.

---

## Technical debt that must be removed

These are the still-inline ideation responsibilities that should be extracted into `source_doc_mutation_dag`.

### Inline technical debt in `idea/ideation_dag.py`

Inside `_build_source_doc_state(...)`:

- heuristic product summary derivation
- heuristic problem derivation / fallback assumption registration
- user derivation and workflow actor seeding
- goal derivation / fallback assumption registration
- scope derivation and source-doc writes
- domain entity token heuristics
- writing canonical source docs directly
- writing `assumptions_registry.json` directly

These behaviors are source-doc mutation pipeline behavior, not ideation-node behavior.

### Transitional helper debt

Inside `_invoke_source_doc_mutation_process(...)`:

- current `contract` string is process-oriented, not DAG-oriented
- current result points at mismatched artifact paths
- current behavior only reports queue state, not full mutation-run state

### Why this debt matters

As long as this logic stays inline:

- ideation owns canonical mutation semantics
- no single mutation result envelope exists
- downstream trust stays fuzzy
- current-state vs target-state is easy to misread

---

## v1 scope vs v2 scope

## v1 scope

Ship the standalone deterministic DAG and make it the sole owner of source-doc mutation + sync.

V1 includes:

- real `source_doc_mutation_dag` workflow entrypoint
- exact node sequence defined above
- request/ref/result artifact standardization
- extraction of `_build_source_doc_state(...)` responsibilities into DAG-owned code
- assumptions reconciliation inside the DAG
- project-doc sync inside the DAG
- exact trust contract in terminal result
- path contract cleanup for derived docs and updater state

V1 does **not** require:

- model-backed mutation synthesis
- scope readiness scoring
- planning summary generation
- open-question ranking beyond assumptions delta

## v2 scope

Layer richer interpretation and downstream readiness artifacts on top of the stable v1 mutation contract.

Likely v2 additions:

- `ComputePlanningSummaryNode`
- `ComputeOpenQuestionsNode`
- `ComputeScopeReadinessNode`
- optional model-backed `AgentNode` enrichment for ambiguous source reconciliation
- richer lineage links from source-doc mutation into source-docs-to-scopes

V2 should only begin after v1 has made mutation ownership and artifact trust explicit.

---

## AgentNode stance

No `AgentNode` is required for v1.

Recommended stance:

- v1: keep the DAG deterministic and honest about heuristic/bootstrap behavior
- v2: introduce a true `AgentNode` only if source-doc mutation must perform ambiguous reconciliation that deterministic logic cannot reasonably own

If a future mutation node becomes agentic, it must:

- have a real model-backed runtime path
- emit prompt/result artifacts
- fail clearly if the runtime fails
- never silently fall back while pretending agentic synthesis happened

---

## Relationship to `source_docs_to_scopes_dag`

`source_docs_to_scopes_dag` in `src/devflow_engine/source_scope/dag.py` already defines a deterministic downstream gate/register workflow.

This contract should make `source_doc_mutation_dag` the clear upstream producer for that family of workflows.

Downstream scope generation may depend on source-doc mutation artifacts, but it must not assume this mutation DAG already established:

- scope coverage sufficiency
- review readiness
- approval readiness

Those remain downstream concerns.

---

## Implementation notes required by this contract

1. Standardize the derived-doc target root.
   - Pick one: `ai_docs/context/project_docs/` or `ai_docs/context/v2/project_docs/`
   - The DAG, updater, and ideation ref must all agree.

2. Standardize the mutation state/result path.
   - Remove the current mismatch between ideation's advertised `state_path` and updater's actual state path.

3. Replace `source_doc_mutation_process` naming with `source_doc_mutation_dag` naming once the workflow exists.

4. Move `_build_source_doc_state(...)` logic behind the DAG boundary.

5. Keep `IdeaContextResolutionNode -> DevinAgentLoopNode -> DevinResponsePostNode` unchanged as the ideation-arm sequence.

---

## Definition of done for this contract

This contract is satisfied when:

- a real `source_doc_mutation_dag` entrypoint exists
- ideation no longer mutates source docs inline
- ideation only writes the mutation request + lightweight ref
- the DAG owns source-doc mutation, assumptions reconciliation, and project-doc sync
- the DAG emits the required artifacts listed above
- downstream trust/not-trust boundaries are present in `source_doc_mutation_result.json`
- artifact paths are internally consistent

---

## Bottom line

The canonical shape is:

- ideation arm stays `IdeaContextResolutionNode -> DevinAgentLoopNode -> DevinResponsePostNode`
- `IdeaContextResolutionNode` invokes `source_doc_mutation_dag`
- `source_doc_mutation_dag` becomes the sole owner of source-doc mutation artifacts
- downstream trusts persistence and traceability, not epistemic certainty
- all remaining inline source-doc mutation logic in ideation is technical debt to remove
