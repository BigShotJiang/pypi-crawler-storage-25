## UI Grounding Next-Sprint Checklist

Date: 2026-03-12

This checklist turns the current UI-grounding/Pencil prep into the next concrete implementation sequence.

## Current state

Already landed:
- UI grounding doctrine and DAG contract docs
- UI grounding MVP runtime and CLI
- Pencil preflight bridge and CLI
- code-to-design opportunity map
- Pencil preflight enforced inside the UI grounding DAG
- code-to-design enrichment branch
- rerun / second-pass matching after code-to-design enrichment

In progress:
- integration of UI grounding into approved-idea -> story / DFUS handoff
- downstream consumption of patched UI anchors

Not yet landed:
- Pencil gap-fill generation path for truly net-new UI
- human review boundary logic for high-consequence generated UI
- richer Pencil generation audit artifacts (`pencil_generation_request.json` / `pencil_generation_result.json`)

---

## Phase 1 — enforce readiness + enrich from existing UI

Status: **implemented**

Landed in repo:
- DAG-level Pencil readiness gating via `EnsurePencilAvailableNode`
- `pencil_preflight.json` pipeline artifact for gated runs
- `code_design_inventory.json` contract and enrichment branch shape
- second-pass matching via effective inventory merge
- stronger patch-anchor preference for generated refs when they outrank plain file anchors

Current limitation of Phase 1:
- enrichment is still adapter-backed / normalization-heavy rather than a full rich Pencil generation flow
- weakness detection is still somewhat heuristic

### 1. Add `EnsurePencilAvailableNode`

Goal:
- UI grounding must be able to verify Pencil readiness before any future Pencil-assisted route is attempted.

Tasks:
- add deterministic node in `src/devflow_engine/ui_grounding/dag.py`
- wire it behind explicit routing/gating, not as an unconditional hard dependency for non-Pencil paths
- persist `pencil_preflight.json` into the pipeline directory when invoked from the DAG
- define clear route outcomes:
  - `ready`
  - `not_requested`
  - `not_installed`
  - `launch_failed`
  - `mcp_unavailable`

Acceptance:
- UI grounding DAG can invoke Pencil preflight deterministically
- non-Pencil grounding paths still work without requiring Pencil
- tests cover success/failure routing

### 2. Add code-to-design enrichment branch

Goal:
- when implemented UI already exists but first-pass grounding is weak, prefer code->design before declaring a real UI gap.

Tasks:
- add artifact contract for `code_design_inventory.json`
- add bridge-backed or adapter-backed node to request code->design generation from Pencil
- only run when:
  - first-pass matching is weak/missing
  - relevant `implemented_ui` references exist
  - Pencil preflight passed
  - feature is explicitly enabled by route/flag

Acceptance:
- workflow can enrich the reference inventory from code-derived design artifacts
- generated refs are normalized back into inventory form
- tests prove branch selection and artifact emission

### 3. Rerun matching after code-to-design enrichment

Goal:
- the enriched inventory should get a second chance to ground the surface before we emit a final gap.

Tasks:
- add a rerun or second-pass matching node / route
- merge `code_design_inventory.json` into `ui_reference_inventory.json` or a second-pass effective inventory
- update final `ui_grounding_report.json`
- ensure `grounded_story_reference_patch.json` uses the strongest resulting anchors

Acceptance:
- workflow can move from `missing_reference` to `grounded_*` after code->design enrichment
- tests prove second-pass grounding changes the final outcome

---

## Phase 2 — integrate into the main planning path

Status: **active implementation frontier**

Critical guardrails from review:
- do not accidentally make Pencil a hard dependency for all UI-grounding runs
- do not emit misleading `grounded_story_reference_patch.json` outputs for blocked runs
- do not let shallow second-pass matches promote low-quality anchors into downstream story truth
- add an actual halt/review gate in the idea -> story / DFUS path rather than treating UI grounding as a sidecar

### 4. Insert UI grounding into approved-idea -> story / DFUS handoff

Goal:
- UI grounding becomes part of the real path, not a sidecar CLI only.

Tasks:
- identify the exact seam in `idea/ideation_dag.py` / story handoff runtime
- run UI grounding for UI-bearing ideas before traditional story -> DFUS progression
- halt or route to review when grounding status is not sufficient

Acceptance:
- UI-bearing ideas cannot silently bypass grounding on the main path

### 5. Make downstream story generation consume patched UI anchors

Goal:
- stronger UI references must survive into canonical story generation.

Tasks:
- teach story/DFUS generation to read `grounded_story_reference_patch.json`
- propagate explicit UI anchors into downstream story artifacts
- reduce reliance on weak provenance-only UI-plane anchors

Acceptance:
- canonical stories can point to concrete UI truth when available

---

## Phase 3 — add true gap filling for net-new UI

### 6. Add Pencil gap-fill generation

Goal:
- when UI is genuinely missing, produce usable wireframe/design artifacts.

Tasks:
- add generation request/result artifacts
- add gated generation node
- require review for high-impact/ambiguous surfaces
- normalize generated refs back into UI anchors

Acceptance:
- truly missing UI can be filled in a controlled, inspectable way

---

## Guardrails

- do not make Pencil a hard dependency for all UI grounding runs
- prefer code->design over speculative wireframe generation when real implemented UI exists
- keep artifact lineage explicit
- preserve approved idea intent; enrich, don’t silently rewrite
- require review for manager/reporting/workflow-defining surfaces

---

## Recommended immediate implementation order

1. `EnsurePencilAvailableNode`
2. `code_design_inventory.json` contract + enrichment node
3. second-pass matching route
4. main-path integration into idea -> story / DFUS
5. downstream patch-artifact consumption
6. net-new Pencil gap-fill generation
