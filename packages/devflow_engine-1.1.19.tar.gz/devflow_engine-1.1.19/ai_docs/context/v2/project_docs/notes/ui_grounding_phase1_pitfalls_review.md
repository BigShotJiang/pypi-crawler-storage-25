## UI Grounding Phase 1 Pitfalls Review

Date: 2026-03-12

This note reviews the current implementation against `ui_grounding_next_sprint_checklist.md`, with emphasis on likely failure modes while implementing Phase 1 steps 1-3.

Grounded sources reviewed:
- `src/devflow_engine/ui_grounding/dag.py`
- `src/devflow_engine/ui_grounding/models.py`
- `src/devflow_engine/ui_grounding/pencil_bridge.py`
- `src/devflow_engine/idea/ideation_dag.py`
- `src/devflow_engine/idea/story_pipeline.py`
- `tests/area14_ui_grounding/test_ui_grounding_dag.py`
- `tests/area14_ui_grounding/test_pencil_bridge.py`

---

## Current repo reality that matters

The current `ui_grounding_dag` is still a straight-line workflow:

1. load context
2. derive surfaces
3. inventory refs
4. match
5. patch
6. finalize

There is **no routing layer** inside the DAG today. That matters because the checklist for Phase 1 assumes explicit route/gating decisions for Pencil preflight, enrichment, and second-pass matching.

Two repo facts make this especially important:

1. `MatchUISurfacesToReferencesNode` can produce a blocked report, but `PatchStoryAndIdeaUIReferencesNode` still runs afterward unconditionally.
2. `story_pipeline.py` still compiles downstream plane anchors as `artifact:<traditional-story-path>`, so if UI grounding gets integrated carelessly, weak anchors will still leak through unless the handoff contract becomes explicit.

---

## 1. Route / gating mistakes to avoid

### A. Do not bolt `EnsurePencilAvailableNode` directly into the linear chain

Current workflow schema in `src/devflow_engine/ui_grounding/dag.py` is unconditional. If `EnsurePencilAvailableNode` is inserted naively between context load and match flow, Pencil becomes a de facto prerequisite for all UI grounding runs.

That would violate the checklist guardrail:
- non-Pencil grounding paths must still work
- Pencil readiness should be checked only for routes that may need Pencil

**What to avoid:**
- `Load -> EnsurePencilAvailable -> Derive -> Inventory -> Match -> ...` as the default path
- treating any non-`ready` Pencil status as terminal for runs that never requested Pencil

**What should exist instead:**
- an explicit route decision after first-pass match, something like:
  - `not_requested`
  - `ready`
  - `not_installed`
  - `launch_failed`
  - `mcp_unavailable`
- a separate boolean or route cause distinguishing:
  - Pencil not needed
  - Pencil allowed but not required
  - Pencil required for chosen recovery path

### B. Do not infer “Pencil requested” from “missing_reference” alone

Today, missing refs just mean the first pass failed. That is **not** enough to justify Pencil work.

Per the current code, many misses can happen because matching is crude:
- `_heuristic_grounding_report()` treats any 1-token overlap as a match
- `_labels_for_path()` only uses stem + parent directory labels
- `_candidate_ui_files()` is a broad filename scan

So a surface can be `missing_reference` either because:
- it is genuinely net-new UI
- implemented UI exists but labels are weak
- the derivation text is noisy
- the repo scan found a file but not a useful screen anchor

If Pencil gets invoked for every first-pass miss, the branch will be noisy and expensive.

**Require all of these before preflight/enrichment:**
- first pass is weak or missing
- there is plausible `implemented_ui` evidence for that surface
- route/flag explicitly enables Pencil assist
- the surface is still UI-bearing after derivation

### C. Do not treat preflight failure as equivalent to “no UI exists”

`run_pencil_preflight()` already distinguishes:
- `not_installed`
- `launch_failed`
- `mcp_unavailable`
- `ready`
- and also a generic `error`

If Phase 1 collapses those into a generic “missing UI” branch, operators will lose the difference between:
- environment/tooling failure
- actual design/reference absence

That distinction matters for routing:
- `not_requested` -> continue non-Pencil path
- `not_installed` / `launch_failed` / `mcp_unavailable` -> preserve the gap as tooling-blocked enrichment, not evidence that UI is absent
- `ready` -> allow code-to-design branch

### D. Do not integrate main-path gating at the ideation seam without a real stop condition

`src/devflow_engine/idea/ideation_dag.py` currently does:
- route
- sufficiency
- `HandoffToStoryPipelineNode`

There is no UI grounding seam yet. If UI grounding is inserted but the handoff node still calls story compilation regardless of UI grounding status, the integration will be fake.

**Mistake to avoid:**
- running UI grounding as a side-effect artifact only, while still allowing story handoff on blocked UI status

**Need before main-path integration:**
- explicit halt / review route when grounding outcome is insufficient
- ideally a dedicated stage artifact at ideation level showing whether story handoff was allowed or blocked by UI grounding

### E. Do not leave unconditional patch generation in place once routes matter

`PatchStoryAndIdeaUIReferencesNode` currently always executes after match, even when the report status is `blocked_missing_ui_grounding`.

That means the DAG can emit:
- `ui_gap_report.json`
- `grounded_story_reference_patch.json`

in the same blocked run.

Even if the patch is empty, this is a bad shape for downstream consumers because existence of a patch file can be misread as “grounding happened.”

**Before Phase 1 main-path use:**
- only emit patch when at least one valid anchor exists
- or emit a route/status field in the patch contract that makes “no usable anchor attached” impossible to misinterpret

---

## 2. Artifact-shape compatibility concerns

### A. `UIReferenceInventoryItem.path` currently assumes file-like refs

Current shape in `models.py`:
- `reference_id`
- `reference_type`
- `path`
- `surface_labels`
- `provenance`
- `approval_status`

This works for repo files and `.pen` files only because `path` is treated like a filesystem-ish locator.

Phase 1 step 2 wants `code_design_inventory.json` to normalize generated refs back into inventory form. But generated design refs may not map cleanly to a simple repo path. They may need:
- pipeline artifact path
- Pencil artifact URI
- screen/subscreen fragment
- original source code path(s)

If the team tries to force code-derived design refs into the existing `path` field without more structure, later matching and patching will blur:
- source code evidence
- generated design artifact
- final screen anchor

**Likely fix:** either extend the inventory item shape or introduce enough metadata in `provenance`/extra fields to distinguish:
- source code path(s)
- generated artifact location
- screen-level anchor identifier

### B. Current reference types are too narrow for second-pass generated design evidence

`ReferenceType` is currently:
- `implemented_ui`
- `design_doc`
- `pencil_artifact`
- `wireframe_package`
- `screenshot_spec`

For code-to-design, the repo will likely need to distinguish at least one of these concepts:
- generated-from-code screen inventory
- generated design snapshot from existing UI
- raw Pencil artifact container vs normalized screen reference

If everything gets shoved into `pencil_artifact`, second-pass matching will not know whether it is matching:
- a reviewed design artifact
- an unreviewed machine-derived anchor
- a container artifact with multiple screens

### C. `GroundedStoryReferencePatchArtifact` is currently incompatible with stronger generated anchors

Current patch node writes anchors like:
- `anchor = "ui:file:<path>"`
- `anchor_type = "ui:file"`
- `origin = "existing_ui"`

That is fine for the MVP, but it is too rigid for step 3.

If second-pass grounding succeeds via code-to-design, the strongest anchor may be:
- `pencil:<artifact>#<screen>`
- or a generated inventory reference, not a raw repo file

If the patch schema stays effectively `ui:file`-only, the implementation will either:
- discard stronger generated anchors
- or lie by flattening them back into repo file anchors

### D. Final outcome math is biased toward first-pass existing-ui only

`FinalizeUIGroundingOutcomeNode` counts grounded surfaces with:
- `row.classification == "grounded_existing"`

That will undercount any future generated / mixed / second-pass success unless classification or summary logic is extended. If Phase 1 lands without fixing this, summary.json will say grounding was weaker than it actually was.

### E. Preflight artifact placement is currently CLI-default, not DAG-native

`pencil_bridge.py` defaults to `.devflow/ui_grounding/pencil_preflight.json`.

Checklist step 1 says DAG invocation must persist `pencil_preflight.json` into the **pipeline directory**. If the Phase 1 node simply reuses the CLI helper without overriding artifact path, the artifact will land outside the per-run pipeline tree and break run-local lineage.

That sounds small, but it matters for:
- reruns
- comparing first-pass and second-pass artifacts
- deterministic test expectations
- main-path auditing

---

## 3. Where second-pass matching could create bad anchors

### A. The current heuristic matcher is permissive enough to over-anchor after inventory inflation

`_heuristic_grounding_report()` currently considers a surface matched if token overlap with an inventory item is at least 1 token.

That is already permissive for first pass. It becomes much riskier after code-to-design adds more labels and more references.

A second-pass inventory will likely contain extra terms such as:
- dashboard
- manager
- report
- help
- participant
- flow

With a 1-token threshold, second pass can easily convert a previously honest miss into a false positive.

**Bad outcome:**
- `missing_reference` becomes `grounded_existing` or future generated-grounded merely because both sides include a generic token like `manager` or `dashboard`

### B. Generated refs can accidentally anchor to the wrong surface family

The current derivation logic uses coarse surface names such as:
- `Manager dashboard`
- `Need Help flow`
- `Participant survey`

Those are broad families, not route-precise identifiers.

If code-to-design emits multiple generated refs from nearby code areas, second-pass matching may incorrectly attach:
- manager-reporting design output to manager-admin settings surfaces
- participant survey output to thank-you / confirmation surfaces
- Need Help support flow output to generic help center pages

This is especially likely because `_labels_for_path()` only derives labels from filename stem and parent folder.

### C. Patch generation currently zips ids and paths without validating anchor strength

`PatchStoryAndIdeaUIReferencesNode` zips:
- `matched_reference_ids`
- `supporting_paths`

and emits all of them as anchors.

If second-pass matching returns mixed-quality references, patching will blindly attach them all. There is no concept of:
- strongest anchor
- primary vs supporting anchor
- generated anchor requiring review
- confidence threshold

That means a bad second-pass match will not stay local to `ui_grounding_report.json`; it will leak directly into `grounded_story_reference_patch.json`.

### D. There is no surface-level provenance telling whether a match came from first pass or second pass

Once Phase 1 adds rerun matching, the final report needs to preserve whether a surface was grounded by:
- original inventory
- code-derived inventory
- mixed evidence

Without that, reviewers cannot tell whether a newly grounded surface is genuinely better or just matched because the inventory got noisier.

### E. Ambiguous manager/reporting surfaces are the easiest place to silently mis-anchor

The repo notes already call out manager/reporting/workflow-defining surfaces as high risk. The current implementation supports that concern:
- file discovery is broad
- labels are shallow
- matching is permissive
- patching is unconditional

So the most likely false-positive anchors in Phase 1 will be around:
- dashboard vs reporting vs admin views
- support/help vs escalation flows
- participant flow vs participant confirmation/thank-you screens

Those surfaces need stricter matching and probably review flags before becoming story truth.

---

## 4. Test cases that must exist before main-path integration

These are the tests that should exist before wiring UI grounding into approved-idea -> story / DFUS handoff.

### A. Preflight gating tests

1. **Non-Pencil path does not invoke preflight**
   - first-pass grounding succeeds
   - Pencil enable flag false or absent
   - no `pencil_preflight.json` is emitted
   - run still succeeds

2. **Pencil allowed but not needed**
   - feature flag true
   - first-pass grounding succeeds strongly
   - code-to-design branch is skipped
   - no enrichment artifacts are emitted

3. **Pencil requested + not installed**
   - first pass weak/missing
   - implemented UI evidence exists
   - route requests Pencil
   - `pencil_preflight.json` lands inside pipeline dir
   - final report stays explicit about missing/weak grounding rather than pretending no UI exists

4. **Pencil requested + MCP unavailable**
   - same as above, but preflight status is `mcp_unavailable`
   - DAG routes to a tooling-blocked enrichment result, not silent success or unconditional hard failure for all UI runs

### B. Enrichment branch selection tests

5. **Weak first pass + relevant implemented UI triggers code-to-design**
   - first-pass report weak/missing
   - inventory contains relevant `implemented_ui`
   - Pencil preflight passes
   - `code_design_inventory.json` emitted

6. **Weak first pass + no implemented UI does not trigger code-to-design**
   - remains a true gap
   - no Pencil enrichment branch runs

7. **Weak first pass + design docs already strong does not trigger enrichment**
   - guards against redundant code-to-design when durable anchors already exist

### C. Second-pass safety tests

8. **Second pass upgrades outcome only when enriched refs are surface-specific**
   - start with `missing_reference`
   - enrich inventory with precise generated ref
   - final report moves to grounded status
   - patch uses strongest anchor

9. **Second pass does not upgrade on generic-token overlap alone**
   - generated ref shares generic tokens like `manager` or `dashboard`
   - final report remains weak/missing
   - this test is important because current 1-token overlap heuristic would likely fail it

10. **Second pass does not cross-anchor sibling surfaces**
   - one generated ref for reporting dashboard
   - another for help/escalation flow
   - ensure each surface maps only to the correct anchor

11. **Final patch prefers stronger generated anchor over raw code-file anchor when appropriate**
   - patch includes a designated primary anchor or otherwise preserves anchor ordering / origin clearly

12. **Blocked runs do not emit misleading patch artifacts**
   - if final status is blocked, either no patch file exists or the patch artifact explicitly records that no usable anchor was attached

### D. Main-path integration tests

13. **Ideation/story handoff halts on blocked UI grounding**
   - UI-bearing idea
   - final status `blocked_missing_ui_grounding`
   - `HandoffToStoryPipelineNode` equivalent is not reached

14. **Ideation/story handoff routes to review on assumption-heavy grounding**
   - not all weakly grounded surfaces should pass automatically

15. **Compiled story output consumes patch anchors**
   - downstream story JSON should no longer rely solely on `artifact:<traditional-story-path>` when a stronger UI grounding patch exists

16. **Non-UI idea path bypasses UI grounding cleanly**
   - no false UI gating on backend-only or non-UI slices

---

## 5. Specific implementation advice for steps 1-3

### Step 1: `EnsurePencilAvailableNode`

Recommended constraints:
- do not add it as a mandatory linear predecessor for the whole DAG
- run it only behind an explicit enrichment route
- always override artifact path to `<pipeline_dir>/pencil_preflight.json`
- preserve checklist route outcomes exactly, even if bridge internals still have an extra `error` status

### Step 2: code-to-design enrichment

Recommended constraints:
- do not merge raw Pencil output directly into `ui_reference_inventory.json`
- normalize through a dedicated `code_design_inventory.json`
- preserve source-code provenance for every generated ref
- require per-surface association, not just repo-wide generated design blobs

### Step 3: rerun matching

Recommended constraints:
- avoid simple inventory append + same old matcher if possible
- if matcher stays heuristic, raise the threshold for second-pass generated refs or require surface-specific labels
- preserve first-pass vs second-pass provenance in the final report
- patch only vetted anchors, not every supporting path returned by matching

---

## Bottom line

The main risk in Phase 1 is **not** that Pencil preflight or code-to-design will fail mechanically.

The main risk is that the repo will appear to support a sophisticated recovery branch while actually doing something much looser:
- unconditional DAG flow
- permissive matching
- noisy inventory growth
- unconditional patch emission
- weak downstream handoff semantics

If that happens, second-pass grounding will create confident-looking but low-trust anchors.

The highest-value fixes before main-path integration are:
1. explicit route/gating states inside `ui_grounding_dag`
2. artifact contracts that can distinguish source code vs generated design vs final screen anchors
3. tests that prove second-pass enrichment improves grounding **without** inflating false positives
4. a real stop/review seam before story/DFUS handoff
