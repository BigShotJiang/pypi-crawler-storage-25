## UI Grounding Code-to-Design Opportunity Map

Date: 2026-03-13

This note answers a narrow repo question:

**Where should Pencil code-to-design plug into the current `ui_grounding_dag`, and what should it produce so the rest of DevFlow can consume it cleanly?**

It is grounded in the current implementation under:
- `src/devflow_engine/ui_grounding/dag.py`
- `src/devflow_engine/ui_grounding/models.py`
- `src/devflow_engine/idea/ideation_dag.py`
- `src/devflow_engine/idea/story_pipeline.py`
- `ai_docs/context/v2/project_docs/notes/pencil_bridge_and_code_to_design_plan.md`

---

## 1. What exists today

The current DAG already has a usable artifact pipeline:

1. `LoadUIGroundingContextNode`
   - writes `ui_grounding_context.json`
2. `DeriveUISurfacesFromIdeaNode`
   - writes `ui_surface_derivation.json`
3. `InventoryExistingUIReferencesNode`
   - writes `ui_reference_inventory.json`
   - currently inventories repo files and optional `--design-ref` inputs
4. `MatchUISurfacesToReferencesNode`
   - writes `ui_grounding_report.json`
   - writes `ui_gap_report.json` when refs are missing
5. `PatchStoryAndIdeaUIReferencesNode`
   - writes `grounded_story_reference_patch.json`
6. `FinalizeUIGroundingOutcomeNode`
   - writes `summary.json`

Today, missing refs go straight from inventory/match to a blocked gap. There is no intermediate recovery step for:
- "implemented UI exists but design truth is weak"
- "repo code could be converted into better design/screen anchors"

That is the best opening for code-to-design.

---

## 2. Exact insertion point in the DAG

### Recommended plug-in point

**Insert code-to-design after initial matching, before final gap/block classification is treated as terminal.**

Repo-specific shape:

1. derive surfaces
2. inventory existing refs
3. match surfaces to refs
4. **if unresolved/missing refs remain, and implemented UI evidence exists, run code-to-design assist**
5. merge generated design refs back into inventory
6. rerun matching
7. emit final report / patch / gap outcome

### Why here

This matches the current code structure better than any earlier or later hook:

- Earlier than inventory: too soon; the repo has not yet proven whether existing refs are already sufficient.
- Earlier than matching: wrong; code-to-design should be a recovery path, not default behavior.
- After patch/finalize: too late; downstream artifacts would already reflect a blocked or incomplete grounding decision.

In `src/devflow_engine/ui_grounding/dag.py`, this means the natural seam is **between**:
- `MatchUISurfacesToReferencesNode`
- `PatchStoryAndIdeaUIReferencesNode`

with a conditional branch only when the first match leaves `missing_reference` or weak/partial coverage.

---

## 3. When code-to-design should be preferred over wireframe generation

### Prefer code-to-design when all of these are true

1. The surface is UI-bearing.
2. `ui_grounding_report.json` says the surface is `missing_reference` or effectively under-grounded.
3. The inventory already contains plausible `implemented_ui` refs for the same surface or nearby route/component area.
4. The real problem is **missing durable design truth**, not missing implementation.

In this repo’s terms:
- if `InventoryExistingUIReferencesNode` found `implemented_ui` files that look relevant
- but `MatchUISurfacesToReferencesNode` still cannot confidently ground the derived surface
- then the next move should be **extract stronger screen truth from code**, not invent a new wireframe

### Prefer wireframe generation instead when

1. No relevant implemented UI exists.
2. The feature is genuinely net-new UI.
3. Existing code is too fragmentary or too low-level to express a real screen.
4. The desired artifact is exploratory gap-fill, not design capture from code.

### Repo-specific rule of thumb

- **Existing screen/route/component already exists** -> try code-to-design first
- **Only backend logic or no credible UI implementation exists** -> do not use code-to-design; keep gap or generate wireframes only if approved

This lines up with the existing note in `pencil_bridge_and_code_to_design_plan.md`: code-to-design is strongest when the repo already has UI code but weak design anchors.

---

## 4. What input artifacts it should consume

Code-to-design should consume the artifacts the current DAG already emits, plus the concrete repo files they point at.

### Required inputs

#### `ui_surface_derivation.json`
Use it as the demand signal:
- which surfaces need grounding
- actor / job context
- rationale and source refs

#### `ui_reference_inventory.json`
Use it as the candidate supply set:
- especially refs with `reference_type: "implemented_ui"`
- optionally nearby `design_doc`, `.pen`, screenshot, or wireframe refs

#### `ui_grounding_report.json` from the first match pass
Use it to scope work only to surfaces that still need help:
- `missing_reference`
- later also `grounded_partial` if that status becomes first-class in practice

#### Repo code paths behind inventoried refs
These are the actual inputs Pencil should derive from:
- route/page files
- screen-level components
- UI docs already in `ai_docs`

### Optional inputs

- `--design-ref` artifacts already passed to `ui-grounding run`
- future story/provisional story JSON paths from `story_paths`
- Pencil preflight state (`pencil_preflight.json`)

---

## 5. What output artifacts it should emit

### Primary new artifact

#### `code_design_inventory.json`
This should be the normalized output of code-to-design assist.

It should capture:
- target surface ids from `ui_surface_derivation.json`
- source repo paths used for derivation
- generated Pencil artifact refs
- normalized screen refs suitable for later inventory merge
- whether each generated ref is a full screen, partial screen, or supporting design extraction
- review-needed flags

This is the most repo-compatible output because it fits between inventory and match.

### Supporting artifacts

#### `pencil_preflight.json`
Required before any Pencil call. This is already proposed in the Pencil bridge plan and should stay separate.

#### `pencil_generation_request.json`
Helpful audit artifact when Pencil is invoked.

#### `pencil_generation_result.json`
Helpful raw bridge result artifact before normalization into DevFlow inventory entries.

### Not the primary output

`wireframe_package.json` should **not** be the default output of code-to-design.
That file is better reserved for true gap-fill generation.

Code-to-design is primarily about producing:
- stronger design refs
- screen inventories
- anchored design artifacts from code

not speculative new wireframes.

---

## 6. How outputs should merge back into current artifacts

### Merge target 1: `ui_reference_inventory.json`

This is the most important merge point.

Code-to-design output should be normalized into additional inventory items using the same basic shape already used by `UIReferenceInventoryItem`:
- stable `reference_id`
- `reference_type` / future `reference_kind`
- path or artifact ref
- surface labels
- provenance
- approval status

Repo-specific recommendation:
- add generated refs as additional entries rather than replacing the original `implemented_ui` entries
- provenance should make the relationship explicit, e.g. source code path + Pencil-generated artifact
- keep both the underlying code anchor and the derived design anchor

That gives matching two shots:
1. raw implemented UI evidence
2. stronger derived design evidence

### Merge target 2: `ui_grounding_report.json`

After inventory merge, rerun matching and update the final report so surfaces can move from:
- `missing_reference` -> `grounded_with_generated_artifacts`
- or possibly `pass_with_assumptions`
- or stay blocked if code-to-design still did not produce sufficient anchors

The report should explicitly say whether grounding came from:
- existing repo UI only
- code-derived design artifacts
- mixed evidence

### Merge target 3: `grounded_story_reference_patch.json`

Patch output should attach the stronger anchors, not just the raw code file path.

Preferred anchor mix:
- keep `ui:file:<repo-path>` when useful
- add a stronger design anchor when generated, e.g. `pencil:<artifact>#<screen>`

Repo-specific recommendation:
- if code-to-design succeeded, patch origin should become `generated_ui` or `mixed`, not remain `existing_ui`
- the patch should preserve both evidence refs and derived design refs so later story compilation can choose the most meaningful anchor

### Merge target 4: downstream story/DFUS artifacts

`src/devflow_engine/idea/story_pipeline.py` currently emits UI-plane anchors like:
- `artifact:<traditional-story-path>`

That is exactly the weak anchor pattern UI grounding is supposed to improve.

So the contract should be:
- UI grounding writes/patches better UI anchors first
- story/DFUS compilation later reads them and emits concrete UI-plane anchors
- story compilation should not try to infer design truth on its own

---

## 7. Review and gating that should exist

### Required gate: Pencil preflight

Before any code-to-design call:
- verify Pencil install
- verify app/process readiness
- verify MCP initialize health

If preflight fails:
- do not silently fall through as if design extraction happened
- keep the UI gap explicit

### Required gate: only run when there is real implemented UI evidence

Do not run code-to-design just because a surface is missing.
Require at least one relevant `implemented_ui` candidate in inventory for the affected surface.

Otherwise the system should either:
- remain blocked
- or route to approved gap-fill wireframe generation

### Recommended review boundary

Auto-accept code-to-design output only when it is clearly derivative of existing commodity UI and used as grounding reinforcement.

Require human review when:
- the generated design artifact materially defines manager/executive/reporting UX
- multiple code areas could map to the same surface and the extraction is ambiguous
- the result appears to reshape workflow semantics rather than documenting existing UI
- the output would become the primary truth for a high-consequence screen

This matches the repo’s own high-risk examples:
- participant experience vs Need Help / Vibe Check separation
- manager dashboard/reporting vs broader manager experience

### Final routing rule

After code-to-design assist:
- if enough grounding exists -> emit patch and continue
- if output is usable but assumption-heavy -> `pass_with_assumptions` or `needs_ui_review`
- if still insufficient -> keep `blocked_missing_ui_grounding`

No silent downgrade.

---

## 8. Concrete implementation recommendation for this repo

### Best next runtime slice

1. Add Pencil preflight support behind `src/devflow_engine/ui_grounding/pencil_bridge.py`
2. Add a `GenerateCodeDesignInventoryNode` between match and patch
3. Write:
   - `pencil_preflight.json`
   - `code_design_inventory.json`
   - optional raw Pencil request/result artifacts
4. Merge normalized generated refs into `ui_reference_inventory.json`
5. Rerun `MatchUISurfacesToReferencesNode`
6. Update `grounded_story_reference_patch.json` origin/anchors accordingly
7. Only after that add true gap-fill wireframe generation

### Why this order is right

Because the current repo already has the minimum loop needed for it:
- derive demand
- inventory supply
- detect mismatch
- patch downstream anchors

Code-to-design belongs in that mismatch-recovery slot.
Wireframe generation should come after that, not before it.

---

## 9. Bottom line

For this repo, Pencil code-to-design is most useful as a **mid-DAG grounding recovery step**, not as a default generator.

It should:
- plug in after first-pass matching
- consume surface derivation + current inventory + failed/weak grounding results + concrete implemented UI paths
- emit `code_design_inventory.json` plus normalized design refs
- merge those refs back into `ui_reference_inventory.json`
- rerun grounding
- patch downstream story anchors with stronger `pencil:` / `ui:file:` evidence

Use it when UI already exists but design truth is weak.

Do **not** use it when the surface is genuinely net-new and needs invention; that is where gap-fill wireframe generation belongs.
