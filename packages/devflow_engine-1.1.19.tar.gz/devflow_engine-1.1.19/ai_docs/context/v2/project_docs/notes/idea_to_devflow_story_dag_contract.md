## Idea To DevFlow Story DAG Contract

This note captures the current contract boundary for the idea to DevFlow-story pipeline.

### Canonical story contract boundary

- Canonical DevFlow stories are only discovered from `ai_docs/context/v2/project_docs/user_stories.md` and `ai_docs/context/v2/project_docs/user_stories/**/*.md`.
- Current hard uniqueness enforcement is on `story_uuid`.
- `story_id` and `title` are expected to remain stable and human-meaningful, but the current indexer does not reject duplicates for them.
- Canonical contracts are the only story artifacts expected to carry `story_uuid`, `story_id`, `title`, `required_planes`, and `plane_oracles` in the Area 4 format.

### Upstream idea artifacts

- `devflow idea sufficiency` evaluates whether raw idea input is structured enough for transitional story generation. It does not create canonical story contracts.
- `devflow idea stories generate` writes transitional user stories under `.devflow/ideas/<idea_id>/traditional_user_stories/<story_set_id>/`.
- Transitional user stories must stay non-canonical:
  - no `story_uuid`
  - no canonical `story_id`
  - no `required_planes`
  - no `plane_oracles`
- Traceability for transitional user stories lives in their manifest until promotion or a future DAG converts them into canonical DevFlow stories.

### Scope-preserving enrichment note

Marcus is considering a pivot where affirmed scope blocks become the default upstream idea units.

If adopted, the likely flow is:
- transcript/docs/repo context -> affirmed scope document
- affirmed scope block -> ideation sufficiency
- insufficiency planes -> onboarding/enrichment agent fills gaps
- revised scope block -> ideation sufficiency re-check
- accepted idea -> existing idea-to-story pipeline

This means upstream idea artifacts may increasingly originate as **scope-preserving enriched ideas** rather than onboarding-generated consolidated buckets.

The important invariant remains:
- upstream ideas can be enriched, clarified, and assumption-backed
- but they should preserve traceability to the original affirmed scope block that produced them

### Happy path placement
In the intended delivery flow, this DAG starts only after an idea has already survived the scope-preserving shaping process.

Happy path:
- source docs -> registered scopes
- approved scope item -> shaped idea(s)
- UI-bearing idea/story candidates are checked for UI grounding
- missing UI references trigger UI artifact creation/discovery (including Pencil/wireframe work when needed)
- accepted/grounded idea -> **this story DAG**
- resulting stories -> implementation DAG

So this DAG remains the approved-idea decomposition layer, not the place where scope ambiguity should be resolved.

### UI grounding note

The current story pipeline already supports a `ui` plane, `plane_oracles`, and `evidence_anchors`, but that is not yet sufficient for strong UI grounding.

Current limitation:
- `ui` plane oracles are currently anchored primarily to story/artifact provenance, not to concrete UI/design artifacts such as existing screens, Pencil references, wireframes, or approved design docs.

Updated doctrine:
- UI artifacts should exist **before** traditional story -> DFUS compilation fully clears for UI-bearing work.
- If an idea or provisional story implies a `ui` plane and lacks a valid UI/design reference, that should raise a UI grounding gap rather than allowing implementation to improvise the interface.
- Pencil-backed wireframes or other approved UI artifacts should be created/discovered upstream, then referenced by the resulting idea/story artifacts.

Planned direction:
- derive needed UI surfaces from ideas and provisional stories
- detect existing UI coverage vs missing UI coverage
- create a UI-gap artifact when grounding is missing
- use Pencil (when appropriate) to build or expand wireframes/screens
- repair idea/story references so the later DFUS/canonical story path carries meaningful UI anchors

### Insight expectations

- `devflow insight` must resolve canonical story context by story path, `story_id`, or `story_uuid`.
- When resolution succeeds, the payload should expose the resolved canonical `story_id`, `story_uuid`, `title`, `required_planes`, and `source_path`.
- Insight output may guide implementation work, but it must treat canonical story contracts as the source of truth for plane requirements.
