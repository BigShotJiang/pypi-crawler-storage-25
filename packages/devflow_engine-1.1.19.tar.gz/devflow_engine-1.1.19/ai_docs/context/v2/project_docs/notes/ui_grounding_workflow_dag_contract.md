## UI Grounding Workflow DAG Contract

Date: 2026-03-12

This note defines the intended contract for a new **UI grounding workflow** that sits between approved ideas and canonical DevFlow user-story (DFUS) compilation for UI-bearing work.

The goal is simple: if work implies a UI surface, downstream story generation and implementation should inherit **real UI anchors**, not vague provenance references.

---

## Purpose

This workflow answers one question:

**Does this approved idea/story slice already have sufficient UI grounding, and if not, what artifact package must be created so DFUS can proceed without UI improvisation?**

It is not a generic design phase.
It is not a replacement for product thinking.
It is a contract-enforcing bridge between:

- approved scope/idea truth
- UI-bearing story decomposition
- durable design references that implementation can trust

---

## Happy-path placement

Recommended delivery path:

1. source docs -> scopes
2. approved scope -> idea(s)
3. idea -> provisional story/UI surface derivation
4. **UI grounding workflow**
5. grounded idea/provisional story set -> traditional story -> DFUS / canonical stories
6. canonical stories -> implementation
7. implementation -> review

This keeps UI grounding:

- later than scope extraction, so we are not designing against unstable scope
- earlier than DFUS clearance, so canonical stories carry concrete UI references
- much earlier than implementation, so coders are not inventing interface behavior ad hoc

---

## Core doctrine

1. **Approved idea remains the anchor**
   - UI grounding may enrich, split, annotate, or attach references.
   - It must not silently rewrite approved business intent.

2. **UI-bearing work must prove UI grounding**
   - A generic `ui` plane flag is not enough.
   - A UI-bearing slice needs concrete references to existing UI, approved design artifacts, or generated wireframes.

3. **Existing UI beats speculative new UI**
   - The workflow should first discover and align to what already exists.
   - Pencil-backed generation is for gap filling, not for gratuitous redesign.

4. **Gap creation is a first-class success path**
   - If the system cannot establish adequate UI grounding, it should emit an explicit gap artifact and route to fill/approval.
   - “Proceed anyway” is the wrong default.

5. **DFUS should inherit meaningful UI anchors**
   - By the time canonical stories are compiled, UI-bearing stories should reference real screen/surface artifacts.

---

## Downstream assumptions this workflow should establish

If the workflow clears a UI-bearing slice as grounded, later DFUS/story layers may assume:

- required UI surfaces have been identified
- known existing UI references have been attached where available
- missing UI references have either been filled or explicitly escalated
- resulting idea/provisional story artifacts contain durable UI anchors suitable for canonical story generation

If it does not clear, downstream DFUS promotion should not silently continue for those UI-bearing slices.

---

## Inputs

Minimum expected inputs:

- approved `scope_context.json` or equivalent upstream scope lineage
- approved idea artifact or `idea_candidate.json` / accepted idea package
- any provisional/traditional story decomposition available for the idea
- repository/context evidence that may expose existing UI:
  - route inventories
  - screen/component docs
  - current frontend files
  - existing design notes
  - prior DFUS / story references
- optional existing design assets:
  - Pencil `.pen` artifacts
  - wireframe exports
  - approved design notes/specs

---

## Outputs

Primary outputs:

- `ui_reference_inventory.json`
- `ui_surface_derivation.json`
- `ui_grounding_report.json`
- `ui_gap_report.json` (only when grounding is incomplete)
- `wireframe_package.json` (when new Pencil/wireframe output is created)
- `grounded_story_reference_patch.json`
- repaired idea/provisional story artifacts carrying durable UI references

Terminal states:

- `grounded_ready` — sufficient UI references exist and are attached
- `grounded_with_generated_artifacts` — gaps filled via Pencil/wireframe package
- `pass_with_assumptions` — enough grounding exists to proceed, but assumptions recorded
- `needs_ui_review` — explicit human/design review required
- `blocked_missing_ui_grounding` — cannot safely proceed to DFUS for affected slices

---

## Proposed node sequence

### 1. LoadUIGroundingContextNode
**Type:** deterministic `Node`

Purpose:
- load approved idea plus upstream traceability
- gather available story decomposition and repo/design context

Inputs:
- approved idea package
- scope lineage
- repo/design context handles

Outputs:
- `ui_grounding_context.json`

Why deterministic:
- pure loading/packaging/registry work

Success condition:
- workflow has a single normalized packet for the rest of the DAG

---

### 2. DeriveUISurfacesFromIdeaNode
**Type:** `AgentNode`

Purpose:
- infer which user-visible surfaces, screens, flows, or interaction touchpoints are implied by the approved idea and provisional stories

Inputs:
- `ui_grounding_context.json`

Outputs:
- `ui_surface_derivation.json`

Why agentic:
- this is interpretation-heavy
- the idea may imply UI without explicitly naming every screen

Success condition:
- outputs a bounded set of candidate UI surfaces with confidence, rationale, and upstream references

Downstream may assume:
- the workflow knows which UI surfaces must be grounded or explicitly rejected as non-UI

---

### 3. InventoryExistingUIReferencesNode
**Type:** deterministic `Node`

Purpose:
- collect existing UI/design evidence from repo and design stores

Inputs:
- `ui_grounding_context.json`
- repo/design sources

Outputs:
- `ui_reference_inventory.json`

Should inventory references such as:
- implemented routes/screens
- component-level screen references
- prior design docs
- Pencil artifacts
- wireframe packages
- approved screenshots/specs

Success condition:
- produces a normalized inventory with stable refs/paths

---

### 4. MatchUISurfacesToReferencesNode
**Type:** `AgentNode`

Purpose:
- reconcile derived UI surfaces against the existing UI reference inventory
- determine which surfaces are already grounded vs partially grounded vs missing

Inputs:
- `ui_surface_derivation.json`
- `ui_reference_inventory.json`

Outputs:
- `ui_grounding_report.json`

Why agentic:
- matching is semantic, not just string-based
- the same surface may be described differently across story text, routes, and design artifacts

Success condition:
- every derived surface is classified as one of:
  - `grounded_existing`
  - `grounded_partial`
  - `missing_reference`
  - `non_ui_or_backend_only`

---

### 5. RouteUIGroundingOutcomeNode
**Type:** `RouterNode`

Routes based on `ui_grounding_report.json`:

- all required UI grounded -> skip generation, go to patch/repair
- some UI partially grounded but recoverable with assumptions -> patch/repair or optional review
- missing required UI references -> create gap artifact and continue to generation/review path
- ambiguous/high-risk grounding -> route to human review

This node makes the “no silent UI improvisation” rule explicit.

---

### 6. CreateUIGapArtifactNode
**Type:** deterministic `Node`

Purpose:
- package missing/partial UI grounding into a durable artifact for fill or review

Inputs:
- `ui_grounding_report.json`

Outputs:
- `ui_gap_report.json`

Should include:
- affected idea/story slices
- missing surfaces
- known constraints
- available upstream evidence
- recommendation: discover existing UI / generate wireframes / human review

---

### 7. GenerateWireframePackageNode
**Type:** `AgentNode`

Purpose:
- create a wireframe/design package for unresolved UI gaps, using Pencil when appropriate

Inputs:
- `ui_gap_report.json`
- `ui_grounding_context.json`
- optional existing design references

Outputs:
- `wireframe_package.json`
- Pencil-backed artifacts or references

Why agentic:
- design synthesis is interpretive
- this should produce actual model-backed UI grounding, not heuristic stubs

Pencil doctrine:
- use Pencil only for true gaps where added UI artifacts materially improve downstream quality
- generated output must preserve linkage back to idea/story slices and constraints

Success condition:
- each missing required surface is either covered by a generated design reference or explicitly escalated

---

### 8. ReviewGeneratedUIArtifactsNode
**Type:** `RouterNode` or approval node boundary

Purpose:
- enforce explicit review when generated UI is high-impact, ambiguous, or project-defining

Possible outcomes:
- approved
- approved_with_assumptions
- revise_generation
- escalate_to_human_review

Doctrine:
- UI generation is not automatically self-ratifying for high-consequence product surfaces

---

### 9. PatchStoryAndIdeaUIReferencesNode
**Type:** deterministic `Node`

Purpose:
- repair/attach UI references back onto the idea and provisional story artifacts

Inputs:
- `ui_grounding_report.json`
- optional `wireframe_package.json`
- approval outcome

Outputs:
- `grounded_story_reference_patch.json`
- patched idea/provisional story artifacts

What gets patched:
- explicit UI refs
- anchor metadata
- evidence lineage
- assumption markers when needed

Success condition:
- later DFUS compilation sees meaningful UI references instead of generic provenance-only anchors

---

### 10. FinalizeUIGroundingOutcomeNode
**Type:** deterministic `Node`

Purpose:
- persist summary outcome and gate readiness for DFUS progression

Outputs:
- finalized `ui_grounding_report.json`
- terminal state summary

Success condition:
- each affected slice is marked `grounded_ready`, `grounded_with_generated_artifacts`, `pass_with_assumptions`, `needs_ui_review`, or `blocked_missing_ui_grounding`

---

## Artifact contracts

### `ui_surface_derivation.json`
Should capture:
- source idea/story refs
- derived UI surfaces
- actor/user role per surface
- primary jobs/tasks supported
- confidence and rationale
- whether each slice appears UI-bearing or not

### `ui_reference_inventory.json`
Should capture:
- normalized reference id
- reference type (`implemented_ui`, `design_doc`, `pencil_artifact`, `wireframe_package`, `screenshot_spec`)
- path/location
- screen/surface labels
- lineage/provenance
- approval status when known

### `ui_grounding_report.json`
Should capture:
- one row/object per derived surface
- matched references
- grounding classification
- unresolved questions
- assumptions
- next required action

### `ui_gap_report.json`
Should capture:
- exact missing surfaces
- why current references are insufficient
- constraints to preserve
- generation/review recommendation
- severity / downstream block status

### `wireframe_package.json`
Should capture:
- artifact id(s)
- tool used (for example Pencil)
- generated screen refs
- mapping from generated screens to idea/story slices
- design assumptions
- review status

### `grounded_story_reference_patch.json`
Should capture:
- target idea/story refs
- attached UI anchor(s)
- anchor type
- supporting evidence refs
- whether the patch originated from existing UI or generated UI

---

## Suggested anchor forms

The current provenance-only pattern is too weak for UI-bearing work.
Preferred future anchor forms include:

- `ui:existing:<route-or-screen>`
- `ui:file:<repo-path>#<component-or-screen>`
- `pencil:<artifact>#<screen>`
- `wireframe:<artifact>#<screen>`
- `design:<doc-or-screen-ref>`
- `screenshot:<artifact>#<screen>`

These may coexist with provenance anchors, but should not be replaced by them.

---

## Retry and routing doctrine

Recommended default:

- surface derivation: 1 primary pass + up to 1 repair/retry
- semantic matching: 1 primary pass + up to 1 repair/retry
- wireframe generation: 1 primary generation + up to 1 revision pass after review

After retries are exhausted, do not silently downgrade quality.
Route to one of:

- `pass_with_assumptions`
- `needs_ui_review`
- `blocked_missing_ui_grounding`

---

## Human approval boundaries

Human review should be explicit when:

- generated UI changes or defines key workflow structure
- multiple plausible UI shapes exist and choice affects business behavior
- the workflow is grounding executive/manager/reporting surfaces with broad downstream impact
- generated artifacts introduce assumptions not strongly supported by source evidence

Human review is usually unnecessary when:

- the workflow is simply attaching obvious existing UI references
- Pencil output is low-risk scaffolding for already-well-understood commodity screens

---

## What this workflow should not do

It should not:

- redesign approved product intent
- convert UI grounding into a full visual design system initiative
- allow canonical story generation to pretend a UI reference exists when it does not
- force Pencil generation for backend-only or CLI-only work
- bury UI uncertainty inside generic `ui` plane metadata

---

## Integration with DFUS generation

After this workflow:

- traditional story -> DFUS compilation should read patched idea/provisional story artifacts
- canonical stories should inherit explicit UI anchors and meaningful plane oracles
- UI-bearing canonical stories should be able to say **which** concrete screen/spec/wireframe they are grounded in

That is the point.

The UI plane is only useful if it points to real UI truth.

---

## Open implementation notes

1. The first implementation can begin as a documentation contract plus artifact schemas before full runtime wiring.
2. `DeriveUISurfacesFromIdeaNode`, `MatchUISurfacesToReferencesNode`, and `GenerateWireframePackageNode` should be treated as genuinely agentic from inception.
3. Pencil integration should be isolated behind a narrow adapter so the workflow contract is not Pencil-exclusive.
4. Repo UI inventory may later benefit from a deterministic extractor over frontend routes/components to improve recall before agentic matching.
5. The likely first risky examples to validate against are:
   - participant experience vs Need Help / Vibe Check separation
   - manager dashboard/reporting vs broader manager experience

Those are good proving grounds because they expose where weak UI grounding can distort downstream stories.
