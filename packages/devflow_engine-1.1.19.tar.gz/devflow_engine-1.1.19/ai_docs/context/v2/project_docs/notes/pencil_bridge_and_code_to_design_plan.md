## Pencil Bridge + Code-to-Design Plan

Date: 2026-03-12

This note defines the next implementation slice after the UI grounding DAG MVP.

Companion repo-specific mapping note:
- `ai_docs/context/v2/project_docs/notes/ui_grounding_code_to_design_opportunity_map.md`

## Why this exists

The new UI grounding DAG can now:
- derive UI-bearing surfaces
- inventory existing UI/design references
- emit grounding and gap artifacts
- patch explicit UI anchors into downstream artifacts

But it does **not** yet:
- invoke Pencil as a first-class rich generation bridge from inside the main approved-idea -> story path
- leverage full code-to-design generation to backfill missing design truth from implemented UI in a non-trivial way
- emit the richer generation audit artifacts and review boundaries needed for high-consequence UI generation

That is the gap this plan covers.

---

## High-value use of Pencil design-to-code / code-to-design

The highest-value immediate use is **code -> design**, not greenfield design generation.

Why:
- many repos already have UI code but weak or missing design artifacts
- UI grounding benefits more from durable screen truth than from speculative redesign
- code-derived design artifacts can become stronger `ui` anchors for DFUS and implementation review

Recommended uses:
1. **Backfill design artifacts from implemented UI**
   - derive screen-oriented design references from existing routes/components
2. **Screen inventory generation**
   - turn current UI code into a durable screen/surface index
3. **Grounding improvement**
   - feed generated design artifacts back into `ui_reference_inventory.json`
4. **Drift detection**
   - compare implemented UI-derived design artifacts against expected story/design anchors
5. **Gap minimization before generation**
   - prefer code->design extraction over new wireframe synthesis when the UI already exists

---

## Core rule

**Do not call Pencil from the DAG unless Pencil availability has been explicitly verified first.**

The runtime must not depend on the app merely happening to be open.

---

## Required new runtime seam

Add a narrow Pencil integration layer under:

- `src/devflow_engine/ui_grounding/pencil_bridge.py`

This module should own:
- app preflight
- MCP/session initialization
- invocation normalization
- result normalization into DevFlow artifacts

The main DAG should not know Pencil-specific startup quirks.

---

## Proposed artifact additions

### `pencil_preflight.json`
Captures:
- app path checked
- app detected or launched
- MCP readiness result
- error details when unavailable

### `code_design_inventory.json`
Captures:
- code-derived screen/design refs extracted from implemented UI
- mapped routes/components/screens
- source code paths used to derive them
- resulting design artifact refs (when produced)

### `pencil_generation_request.json`
Captures:
- requested generation mode (`code_to_design`, `gap_fill_wireframe`, etc.)
- target surfaces
- input refs
- constraints

### `pencil_generation_result.json`
Captures:
- generated artifact refs
- normalized screen refs
- success/failure details
- review-needed flags

---

## Suggested implementation order

### Slice 1: Pencil preflight only
Goal:
- prove the runtime can safely detect/launch/verify Pencil before future generation

Status:
- **implemented**

Landed:
- `EnsurePencilAvailableNode`
- `pencil_bridge.ensure_pencil_ready(...)`
- explicit CLI helper: `devflow ui-grounding pencil-preflight`

Checks include:
- `/Applications/Pencil.app` exists
- app process is running, or can be launched
- bundled MCP endpoint/server responds to initialize

Output:
- `pencil_preflight.json`

What still remains beyond Slice 1:
- richer tool-surface validation beyond initialize handshake
- main-path invocation from approved-idea -> story integration, not just standalone/UI-grounding-sidecar usage

### Slice 2: Code-to-design inventory assist
Goal:
- improve UI grounding by extracting stronger design refs from existing UI code

Status:
- **partially implemented**

Landed:
- `GenerateCodeDesignInventoryNode` branch shape / equivalent enrichment route
- enablement gating for code->design enrichment
- effective inventory merge plus second-pass matching

Current behavior:
- when UI grounding finds missing or weak references, but implemented UI exists, the workflow can enrich inventory and rerun matching before declaring a true gap
- current enrichment remains adapter-backed / normalization-heavy rather than a full rich Pencil generation flow

This should still be preferred over blind wireframe generation when code already exists.

### Slice 3: Gap-fill generation
Goal:
- for genuinely missing UI, use Pencil to generate wireframes/screens

Add only after slices 1-2 are stable.

---

## DAG integration recommendation

Extend the UI grounding DAG with a gated route:

1. derive surfaces
2. inventory existing refs
3. match existing refs
4. if missing refs remain:
   - optionally run Pencil preflight
   - if preflight passes and `allow_pencil_generation` is true:
     - try code-to-design assist first when implemented UI exists
     - otherwise run gap-fill generation
   - else emit explicit gap/review artifact

This makes Pencil usage conditional, explicit, and inspectable.

---

## Suggested node additions

### `EnsurePencilAvailableNode`
**Type:** deterministic `Node`

Purpose:
- verify Pencil installation, process readiness, and MCP initialize health

Inputs:
- repo root
- optional app path override

Outputs:
- `pencil_preflight.json`

Routes:
- `ready`
- `not_installed`
- `launch_failed`
- `mcp_unavailable`

### `GenerateCodeDesignInventoryNode`
**Type:** `AgentNode` or bridge-backed deterministic wrapper depending on Pencil API shape

Purpose:
- derive design/screen references from existing code/UI surfaces

Inputs:
- derived UI surfaces
- matched repo UI refs
- Pencil readiness

Outputs:
- `code_design_inventory.json`

### `GeneratePencilGapFillNode`
**Type:** agentic/bridge-backed generation node

Purpose:
- create wireframe/design artifacts for missing surfaces only after explicit preflight and approval/gating

Outputs:
- `pencil_generation_result.json`

---

## CLI suggestions

Add to the current UI grounding CLI surface:

- `devflow ui-grounding pencil-preflight`
- later optionally:
  - `devflow ui-grounding code-to-design ...`
  - `devflow ui-grounding run --allow-pencil-generation`

The first step should be the preflight command. Keep it boring and reliable.

---

## What success looks like

Short term:
- the system can deterministically say whether Pencil is available and MCP-ready
- no hidden dependency on manual app startup

Medium term:
- UI grounding gets stronger by consuming code-derived design refs
- fewer false UI gaps on repos that already have implemented screens

Long term:
- DFUS and downstream implementation can point to real screen/design truth, whether discovered from existing UI or generated to fill gaps
