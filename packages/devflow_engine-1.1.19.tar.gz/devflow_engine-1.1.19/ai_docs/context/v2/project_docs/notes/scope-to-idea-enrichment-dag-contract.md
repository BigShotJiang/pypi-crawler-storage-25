# Scope To Idea DAG Contract

Date: 2026-03-12

## Purpose

This note defines the intended contract for the **approved scope -> idea** DAG.

This DAG starts only after a scope set has already been:
- extracted from source material
- registered in DevFlow
- reviewed by Marcus
- affirmed as the correct coverage boundary

Its job is:

> **Given an approved scope item, determine the right idea boundary, split if the scope is too broad, and produce fully shaped, traceable idea artifacts.**

This DAG is **not** the canonical idea sufficiency gate.
That responsibility remains downstream in the idea -> DevFlow story DAG.

So this DAG should answer:
- is this scope item already the right idea size?
- is it too broad and in need of splitting?
- is it too narrow and in need of human review or merge recommendation?
- what is the properly shaped idea artifact or idea set that should move downstream?

---

## Why this exists separately from onboarding

The existing onboarding DAG remains untouched for now.
It is still useful as a prototype and comparison point.

But this new DAG is intentionally narrower and more aligned with Marcus’s planning workflow.

### Onboarding DAG tendency
The onboarding DAG tends to:
- synthesize broadly across source material
- consolidate toward internally neat implementation groupings
- act like a first-pass planner/classifier

### Scope -> idea DAG intention
This DAG should instead:
- start from an **approved scope item**
- preserve that scope item as the parent planning boundary
- split only when the scope item is genuinely too broad
- shape ideas cleanly without pretending to own final story sufficiency

### Decision doctrine
If this new DAG produces better ideas than the onboarding DAG, the onboarding DAG may later be removed or heavily reduced.

---

## Core doctrine

### 1. Approved scope is the anchor
The DAG begins from a specific approved scope item.
That scope item is the unit of record.

Default rule:
- one approved scope item -> one idea

Allowed:
- one broad approved scope item -> multiple child ideas

Discouraged unless explicitly justified:
- many approved scope items -> one idea

### 2. Goldilocks assessment happens here
This is the correct layer to decide whether the scope item is:
- `too_broad`
- `just_right`
- `too_narrow`

This decision should happen here, not in story generation.

### 3. This DAG shapes ideas, it does not own canonical sufficiency
This DAG should produce fully shaped ideas with fields such as:
- `problem`
- `users`
- `goal`
- `scope`
- `constraints`
- `acceptance_criteria`
- `assumptions`
- traceability back to the source scope item

But the canonical question:
> “Is this idea sufficient for story generation?”

belongs downstream in the idea -> DevFlow story DAG.

### 4. Preserve traceability
Every generated idea must keep linkage to:
- `project_id`
- `scope_set_id`
- `scope_id`
- source evidence
- assumptions introduced while shaping
- split rationale when a scope item becomes multiple ideas

### 5. Do not silently auto-merge narrow scope items
If a scope item appears too narrow to stand as a healthy idea, prefer:
- explicit operator review
- or merge recommendation metadata

Do **not** silently merge it into something else.

---

## Happy-path placement

This DAG sits in the middle of the planning chain:

- source docs -> scopes
- human/client approves scope
- **approved scope -> shaped idea(s)** ← this DAG
- idea -> DevFlow story DAG (canonical idea sufficiency + story generation)
- story -> implementation DAG

So this DAG is the canonical **scope-to-constructed-idea** bridge, not the canonical idea sufficiency gate.

---

## Inputs

Expected inputs per run:
- approved `scope_item`
- source references linked to that scope item
- normalized source packet or equivalent source context
- assumptions/questions ledger
- project/repo context
- optional neighboring scope references for merge/split reasoning

### Input contract intention
The DAG should be able to start from a scope item that is:
- accurate in business coverage
- possibly broad
- possibly thin
- possibly partially assumption-backed
- still not yet transformed into a proper idea artifact

That is normal and expected.

---

## Outputs

Primary outputs should be:
- a **Goldilocks assessment** of the scope item
- a **split plan** when the scope item is too broad
- one or more fully shaped **idea artifacts**
- an **idea registry artifact** once persisted
- a final **resolution artifact** showing whether the scope item became:
  - one idea
  - many child ideas
  - or a human-review-needed case

The key durable object is the **registered idea artifact(s)** with explicit parent linkage to the approved scope item.

---

# Goldilocks doctrine

## Too broad
A scope item is too broad when one or more of these are true:
- it contains multiple distinct business outcomes
- it naturally decomposes into multiple workflow clusters
- it mixes actor groups with different primary goals
- its acceptance surface would split into unrelated clusters
- it would obviously produce several independent story families

## Too narrow
A scope item is too narrow when one or more of these are true:
- it is basically one story already
- it represents one endpoint/screen/validation detail rather than a business slice
- it has no meaningful internal decomposition
- it reads like an implementation detail rather than an idea boundary

## Just right
A scope item is just right when:
- it has one dominant business outcome
- it has one coherent acceptance surface
- it can plausibly produce multiple stories without becoming vague mush
- its constraints mostly belong together
- it remains recognizable to a human as a valid planning slice

---

# Proposed node sequence

## Node 1 — `LoadApprovedScopeItem`

### Intention
Resolve the approved scope item and gather the exact context needed for Goldilocks assessment and idea shaping.

### Why this node exists
This DAG should start from one explicit, stable planning unit.

### Node type
`Node`

### GenAI need
**None.**
This should be deterministic loading/resolution.

### Inputs
- `project_id`
- `scope_set_id`
- `scope_id`

### Outputs
Artifact: `scope_context.json`

Suggested fields:
- `project_id`
- `scope_set_id`
- `scope_id`
- `scope_title`
- `scope_description`
- `source_support[]`
- `assumptions[]`
- `cross_cutting_constraints[]`
- `neighbor_scope_refs[]`
- `approval_status`

### Success intention
The run has a deterministic context bundle representing exactly one approved scope item.

---

## Node 2 — `AssessScopeGoldilocks`

### Intention
Determine whether the scope item is:
- `too_broad`
- `just_right`
- `too_narrow`

### Why this node exists
This is the core judgment step for the new DAG.
This is where broad scope items are detected before they poison downstream idea quality.

### Node type
`AgentNode`

### GenAI need
**High.**
This is a real interpretation step requiring business judgment.

### Inputs
- `scope_context.json`
- linked source context

### Outputs
Artifact: `goldilocks_assessment.json`

Suggested fields:
- `scope_shape` (`too_broad`, `just_right`, `too_narrow`)
- `reasoning`
- `dominant_outcomes[]`
- `workflow_clusters[]`
- `actor_clusters[]`
- `cohesion_notes[]`
- `split_recommended`
- `recommended_child_idea_count`
- `merge_review_recommended`
- `notes`

### Success intention
The system has an explicit, inspectable view of whether the scope item is a valid idea boundary.

---

## Node 3 — `GoldilocksDecisionRouter`

### Intention
Route based on the Goldilocks outcome.

### Why this node exists
Control flow should be explicit rather than hidden in node internals.

### Node type
`BaseRouter` / `RouterNode`

### Branches
- `too_broad` -> `SplitScopeIntoIdeaCandidates`
- `just_right` -> `DraftIdeaFromScope`
- `too_narrow` -> `NarrowScopeReviewPackage`

### GenAI need
**Low / deterministic.**
This is routing logic.

### Outputs
Artifact: `goldilocks_decision.json`

Suggested fields:
- `decision`
- `reason`
- `next_node`

### Success intention
The next path is visible and justified.

---

## Node 4A — `SplitScopeIntoIdeaCandidates`

### Intention
When the scope item is too broad, split it into multiple child idea candidates.

### Why this node exists
This is the main split point in the planning chain.

### Node type
`AgentNode`

### GenAI need
**High.**
This requires interpretive decomposition without drifting outside the parent scope.

### Inputs
- `scope_context.json`
- `goldilocks_assessment.json`
- linked source context

### Outputs
Artifact: `idea_split_plan.json`

Suggested fields:
- `project_id`
- `scope_set_id`
- `scope_id`
- `parent_scope_id`
- `refs[]`
- `split_required`
- `split_rationale`
- `child_ideas[]`
  - `child_idea_candidate_id`
  - `title`
  - `problem`
  - `users[]`
  - `goal`
  - `scope[]`
  - `constraints[]`
  - `acceptance_criteria[]`
  - `assumptions[]`
  - `traceability[]`
- `coverage_of_parent_scope`
- `remaining_risks[]`

### Success intention
The parent scope item has become a coherent child idea set without losing scope traceability.

---

## Node 4B — `DraftIdeaFromScope`

### Intention
When the scope item is already Goldilocks-sized, shape it directly into one idea.

### Why this node exists
Most healthy scope items should become one idea without forced splitting.

### Node type
`AgentNode`

### GenAI need
**High.**
This requires interpretation and idea shaping.

### Inputs
- `scope_context.json`
- `goldilocks_assessment.json`
- linked source context

### Outputs
Artifact: `idea_candidate.json`

Suggested fields:
- `idea_candidate_id`
- `project_id`
- `scope_set_id`
- `scope_id`
- `parent_scope_id`
- `refs[]`
- `title`
- `problem`
- `users[]`
- `goal`
- `scope[]`
- `constraints[]`
- `acceptance_criteria[]`
- `assumptions[]`
- `traceability[]`

### Success intention
The scope item becomes one properly shaped idea artifact.

---

## Node 5 — `NormalizeIdeaCandidateSet`

### Intention
Normalize both the split path and direct-draft path into one consistent idea candidate set.

### Why this node exists
Downstream persistence and packaging should not care whether one or many ideas were created.

### Node type
`Node`

### GenAI need
**None.**
This is deterministic normalization.

### Inputs
- `idea_split_plan.json` or `idea_candidate.json`

### Outputs
Artifact: `idea_candidate_set.json`

Suggested fields:
- `project_id`
- `scope_set_id`
- `scope_id`
- `parent_scope_id`
- `refs[]`
- `idea_candidates[]`
- `candidate_count`
- `split_applied`
- `split_rationale`

### Success intention
Downstream nodes operate on a stable set format.

---

## Node 6 — `RegisterIdeas`

### Intention
Persist one or more shaped idea artifacts into DevFlow as durable project artifacts.

### Why this node exists
Once shaped, the ideas need stable ids and traceability for downstream story generation.

### Node type
`Node`

### GenAI need
**None.**
This should be deterministic persistence.

### Inputs
- `idea_candidate_set.json`
- `scope_context.json`

### Outputs
Artifact: `idea_registry_record.json`

Suggested fields:
- `project_id`
- `scope_set_id`
- `scope_id`
- `parent_scope_id`
- `refs[]`
- `registered_ideas[]`
  - `idea_id`
  - `source_scope_id`
  - `registry_ref`
  - `status` (`draft`, `ready_for_story_sufficiency`)
- `registration_timestamp`

### Success intention
The shaped ideas are now first-class, registry-backed project artifacts.

---

## Node 7 — `IdeaResolutionPackage`

### Intention
Produce the final outcome package for Marcus.

### Why this node exists
The DAG should end with a human-readable summary of what happened.

### Node type
`Node`

### GenAI need
**Low / optional.**
Mostly formatting/packaging.

### Inputs
- `scope_context.json`
- `goldilocks_assessment.json`
- `idea_candidate_set.json`
- `idea_registry_record.json`

### Outputs
Artifact: `idea_resolution_package.json`

Suggested fields:
- `project_id`
- `scope_set_id`
- `scope_id`
- `parent_scope_id`
- `refs[]`
- `scope_shape`
- `split_applied`
- `registered_idea_count`
- `registered_ideas[]`
- `assumptions_added[]`
- `remaining_risks[]`
- `recommended_next_action`

### Success intention
Marcus can inspect one artifact and understand how the approved scope item became one or more ideas.

---

## Optional node — `NarrowScopeReviewPackage`

### Intention
Handle the too-narrow case without silently auto-merging.

### Why this node exists
Too-narrow scope items are real, but should not be rewritten automatically.

### Node type
`Node`

### GenAI need
**None / low.**
Mostly deterministic packaging of the review recommendation.

### Outputs
Artifact: `narrow_scope_review.json`

Suggested fields:
- `project_id`
- `scope_set_id`
- `scope_id`
- `parent_scope_id`
- `refs[]`
- `reason_too_narrow`
- `suggested_merge_targets[]`
- `human_review_required`
- `recommended_next_action`

### Recommended policy
Prefer human review / merge recommendation rather than silent auto-merge.

---

# Artifact intentions summary

## `scope_context.json`
Loads the exact approved scope unit and its working context.

## `goldilocks_assessment.json`
Captures whether the scope item is too broad, just right, or too narrow.

## `idea_split_plan.json`
Records how a broad scope item was split into child ideas.

## `idea_candidate.json`
Represents one directly shaped idea from a healthy scope item.

## `idea_candidate_set.json`
Unifies one-idea and multi-idea outcomes.

## `idea_registry_record.json`
Registers the shaped ideas as durable project artifacts.

## `idea_resolution_package.json`
Summarizes the final outcome for Marcus.

## `narrow_scope_review.json`
Packages the too-narrow case for explicit human handling.

---

# Node type choices

## `Node`
Use for:
- loading scope context
- normalizing output sets
- persistence and registry writes
- packaging human-readable summaries
- review-only narrow-scope handling

## `AgentNode`
Use for:
- Goldilocks assessment
- splitting broad scope items into idea candidates
- shaping proper idea artifacts from scope

## `RouterNode`
Use for:
- explicit `too_broad` / `just_right` / `too_narrow` branching

## `ConcurrentNode`
Not recommended in v1.
The flow is mostly sequential and artifact-dependent.
Possible future use exists, but concurrency would be premature here.

---

# Compare and contrast with onboarding DAG

## Onboarding DAG
- starts from messy source material
- extracts entities/workflows/actors/assumptions
- tends toward broad synthesis
- historically tried to produce idea-like groupings directly

## Scope -> idea DAG
- starts from an approved scope item
- does not need to rediscover the project from scratch
- focuses narrowly on idea boundary quality
- exists to preserve scope fidelity while allowing justified splitting
- should produce cleaner, more traceable ideas than onboarding when the scope is already approved

## Strategic value of comparison
The reason to leave onboarding untouched for now is to compare outputs:
- if onboarding produces better ideas, keep learning from it
- if the scope -> idea DAG produces cleaner ideas with better traceability, onboarding can likely be reduced or removed

---

# What downstream systems may assume

After this DAG completes successfully, downstream systems may assume:
- every registered idea has an explicit `parent_scope_id`
- every idea is traceable to approved scope and source evidence
- every broad scope split was explicit and recorded
- no silent auto-merges occurred for too-narrow cases
- the idea artifact is fully shaped for downstream review and story-generation intake

Downstream systems should **not** assume that canonical idea sufficiency has already passed.
That remains the job of the idea -> DevFlow story DAG.

---

# Open implementation notes

Likely future entrypoint shape may look like:

```bash
devflow scope ideas --project <project_id> --scope <scope_id>
```

or a workflow-native runner that:
- resolves one approved scope item
- performs Goldilocks assessment
- splits or shapes ideas as needed
- registers the resulting idea artifact(s)

Potential future follow-up docs:
- idea registry contract
- narrow-scope human review contract
- idea-to-story DAG contract updates

---

# Concrete Datalumina / Launchpad implementation mapping

## Proposed module placement

Keep this DAG clearly separate from onboarding:

- `src/devflow_engine/scope_idea/models.py`
- `src/devflow_engine/scope_idea/dag.py`
- pipeline output root: `.devflow/scopes/<scope_id>/pipelines/scope_to_idea_dag/<run_key>/`
- registry output root: `.devflow/ideas/<idea_id>/idea.json`

That separation keeps the onboarding DAG available as a comparison artifact while making the new happy path explicit.

## `WorkflowSchema` shape

Recommended schema identity:

- `DAG_ID = "scope_to_idea_dag"`
- `event_schema = ScopeToIdeaDagEvent`
- `start = LoadApprovedScopeItemNode`

Suggested event fields:

```json
{
  "repo_root": "/repo",
  "project_id": "proj_123",
  "scope_set_id": "scs_123",
  "scope_id": "scp_123",
  "scope_payload_path": "/repo/.devflow/projects/proj_123/scopes/scp_123.json"
}
```

## `NodeConfig` graph

A concrete v1 scaffold can be expressed as:

1. `LoadApprovedScopeItemNode` -> `AssessScopeGoldilocksNode`
2. `AssessScopeGoldilocksNode` -> `GoldilocksDecisionNode`
3. `GoldilocksDecisionNode` -> `GoldilocksDecisionRouter`
4. `GoldilocksDecisionRouter` ->
   - `SplitScopeIntoIdeaCandidatesNode`
   - `DraftIdeaFromScopeNode`
   - `NarrowScopeReviewPackageNode`
5. `SplitScopeIntoIdeaCandidatesNode` -> `NormalizeIdeaCandidateSetNode`
6. `DraftIdeaFromScopeNode` -> `NormalizeIdeaCandidateSetNode`
7. `NormalizeIdeaCandidateSetNode` -> `RegisterIdeasNode`
8. `RegisterIdeasNode` -> `IdeaResolutionPackageNode`
9. `NarrowScopeReviewPackageNode` -> `IdeaResolutionPackageNode`

This is the minimum graph that keeps routing visible while preserving a shared final package node.

## `TaskContext` expectations

Recommended stable keys in `TaskContext.metadata`:

- `scope_context`
- `goldilocks_assessment`
- `goldilocks_decision`
- `idea_split_plan` or `idea_candidate`
- `idea_candidate_set`
- `idea_registry_record`
- `narrow_scope_review`
- `outcome`
- `message`
- `exit_code`

Recommended artifact refs in project systems later:

- `artifacts.scope_context_ref`
- `artifacts.goldilocks_assessment_ref`
- `artifacts.idea_candidate_set_ref`
- `artifacts.idea_registry_record_ref`
- `artifacts.idea_resolution_package_ref`

## Node class choices

### Deterministic `Node`
Use deterministic nodes for:
- loading the approved scope anchor
- emitting the routing decision payload
- normalizing one-vs-many candidates into one set shape
- registry writes and idea id assignment
- narrow-scope review packaging
- final resolution packaging

### `AgentNode`
Use agent nodes for:
- Goldilocks assessment
- broad-scope splitting
- direct idea shaping

Even if the first code scaffold uses deterministic heuristics for safety/testing, these nodes should stay typed as `AgentNode`s because the contract is judgment-heavy and should remain replaceable with real model-backed implementations.

### `RouterNode` / `BaseRouter`
Use a dedicated router for:
- `too_broad`
- `just_right`
- `too_narrow`

That keeps branch logic out of the shaping nodes and aligns with Launchpad first-match-wins routing.

## Artifact outputs and downstream assumptions

Concrete durable artifacts should include:

- `scope_context.json`
- `goldilocks_assessment.json`
- `goldilocks_decision.json`
- `idea_split_plan.json` or `idea_candidate.json`
- `idea_candidate_set.json`
- `idea_registry_record.json`
- `narrow_scope_review.json` when applicable
- `idea_resolution_package.json`
- `summary.json`
- `agent_runs/<node>.json` for each real model-backed scope->idea node when the agent path executes

For inspectability and honest lineage, the agentic artifacts SHOULD carry explicit execution provenance:

- per-agent node artifacts include `execution_lineage`
  - `stage`
  - `origin` = `model|fallback|deterministic`
  - `mode` (for example `agent`, `fallback:pytest_guard`, `fallback:<error>`)
  - `artifact_path`
  - `agent_run_ref` when a model-backed envelope exists
  - `generated_from[]`
- aggregate artifacts such as `idea_candidate_set.json`, `idea_registry_record.json`, and `idea_resolution_package.json` include `lineage[]`
- persisted idea registry payloads SHOULD expose enough lineage to prove whether the final idea came from model-backed shaping or deterministic fallback

Downstream idea->story systems may assume:

- each registered idea has `parent_scope_id`
- split lineage is explicit
- no too-narrow scope was silently merged
- the idea is shaped enough for intake
- canonical idea sufficiency still has **not** been decided here

## Registry assumptions

A pragmatic v1 registry assumption is:

- each shaped idea is persisted as one JSON record under `.devflow/ideas/<idea_id>/idea.json`
- status is initially `ready_for_story_sufficiency`
- the persisted payload includes:
  - `idea_id`
  - `project_id`
  - `scope_set_id`
  - `parent_scope_id`
  - shaped idea fields
  - source/traceability refs

That is intentionally enough to hand ideas into the existing ideation/story machinery later without coupling this DAG to onboarding internals.

---

# Bottom line

The approved scope -> idea DAG should be a disciplined **Goldilocks boundary and idea-shaping workflow**.

Its job is to take an approved scope item, determine whether it is too broad / just right / too narrow, split only when necessary, and produce one or more **fully shaped, traceable ideas**.

That gives the downstream idea -> DevFlow story DAG a much cleaner input while keeping the onboarding DAG available for direct comparison until the better path wins.
