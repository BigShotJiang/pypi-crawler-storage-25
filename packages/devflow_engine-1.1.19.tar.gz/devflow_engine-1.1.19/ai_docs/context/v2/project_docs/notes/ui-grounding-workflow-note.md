# UI Grounding Workflow Note

Date: 2026-03-12

## Purpose

This note captures the intended role of UI grounding in the DevFlow happy path.

Problem:
- implementation agents can miss existing UI
- or invent new UI that is inconsistent with the project
- current `ui` plane support in DFUS is not enough by itself because its anchors are still mostly artifact/provenance anchors rather than concrete design/screen anchors

## Current doctrine

UI artifacts should exist **before** traditional story -> DFUS compilation fully clears for UI-bearing work.

That means:
- the system should detect whether an idea or provisional story implies a `ui` plane
- the system should check whether valid UI references already exist
- if they do not, the system should raise a UI grounding gap
- Pencil or another approved UI artifact path should be used to fill those gaps
- idea/story artifacts should then be repaired so later DFUS/canonical story generation carries meaningful UI references

## What counts as a valid UI reference

Examples:
- existing implemented UI reference
- approved screen/spec artifact
- Pencil `.pen` artifact
- Pencil-derived wireframe package
- approved design note tied to a concrete screen/surface

Not enough on its own:
- generic `ui` plane
- generic `artifact:<story_path>` anchor
- no explicit screen/design reference for a UI-bearing story

## Best insertion point in the happy path

Recommended order:
1. source docs -> scopes
2. approved scope -> idea(s)
3. derive provisional story/UI-bearing slices from ideas
4. detect UI-bearing work and check existing UI grounding
5. raise UI gap artifacts when references are missing
6. use Pencil/wireframe generation or existing design extraction to fill the gaps
7. repair idea/story references so they point at UI artifacts
8. then allow traditional story -> DFUS / canonical story progression

## Why this sits here

Too early:
- running wireframe generation during source -> scope would over-design before idea boundaries are stable

Too late:
- waiting until implementation invites UI improvisation and inconsistency

This midpoint is where the system knows enough to derive needed UI surfaces without designing blindly.

## Planned artifact direction

Potential artifact types:
- `ui_grounding_report.json`
- `ui_gap_report.json`
- `ui_reference_inventory.json`
- `wireframe_package.json`
- repaired idea/story artifacts carrying UI references

Potential future anchor forms:
- `ui:existing:<route-or-screen>`
- `pencil:<artifact>#<screen>`
- `wireframe:<artifact>#<screen>`
- `design:<screen_ref>`

## Pencil’s likely role

Pencil should be used when:
- a story/idea is UI-bearing
- no strong existing UI artifact exists
- and a wireframe or screen reference would materially improve downstream implementation quality

Pencil is therefore best treated as:
- a UI grounding and wireframe-generation aid
- not just a passive design reference

## Bottom line

The `ui` plane already exists in DevFlow stories, but UI grounding does not yet.

The next planning step is to define a workflow that derives needed UI from ideas/stories, detects gaps, uses Pencil to fill them where appropriate, and repairs downstream story references before implementation proceeds.
