# Project Charter: Field Service Job Dispatch App

## Overview

A field service job dispatch application that enables dispatchers to create jobs, assign them to technicians, and track progress through a shared dashboard. The product replaces manual or fragmented dispatch processes with a unified, single-tenant workflow for job creation, assignment, scheduling, and completion tracking.

## Problem / Opportunity

The dispatch team is handling field service jobs through manual or fragmented processes, making job ownership, technician availability, and schedule adherence hard to track. This lack of visibility leads to operational inefficiency — jobs may be unassigned, overdue, or untracked, with no single system providing the team a shared picture of current work.

The opportunity is to deliver a focused tool that gives dispatchers and technicians a reliable, shared workflow for managing the full job lifecycle from intake through completion.

## Target Users

| User | Role | Interaction Model |
|------|------|-------------------|
| **Dispatchers** | Create, assign, schedule, and monitor jobs. Manage the shared job queue. | Active — full operational control |
| **Field Technicians** | Receive assignments, update job status, and capture proof of completion from the field. | Active — field-facing, status-driven |
| **Customers** | Associated with jobs as the service recipient. | Passive — no notifications or direct access in v1 |

**Assumption (asmk_a1_internal_users):** Primary users are internal dispatchers and field technicians, not external customers. This assumption is grounded across product_brief.target_users, domain_entities.ownership_assumptions, and user_workflows.actors.

**Assumption (notifications_deferred):** Customer notifications are deferred past v1. Customers are a passive reference entity only. This supersedes the earlier asmk_a12_customer_notifications assumption — notification triggers and delivery mechanism are moot for v1.

## Goals

1. **Shared dispatch workflow** — Create a shared system so the team can capture, assign, schedule, and complete jobs reliably from a single tool.
2. **Operational visibility** — Give dispatchers visibility into job ownership, technician availability, current job status, and overdue items.
3. **Field-ready technician experience** — Enable technicians to receive job details and update status from the field, including proof-of-completion capture.

## Scope

### In Scope

- Job creation with title, description, priority, and scheduled service time window.
- Assignment of jobs to individual technicians.
- Status tracking through the job lifecycle using the canonical status trio (**open, in_progress, done**) with domain-specific sub-states (intake, scheduled, assigned, en_route, in_progress, completed, cancelled) mapped underneath.
- A shared dispatcher dashboard showing all jobs and their current state.
- Filtering or highlighting overdue jobs in the shared view.
- Technician status updates and proof-of-completion capture from the field.

**Assumption (standardized_statuses):** The canonical status model uses three top-level states: open, in_progress, done. Domain-specific sub-states (intake, scheduled, assigned, en_route, in_progress, completed, cancelled) map into this trio via domain_entities.lifecycle_sub_states. Legacy assumptions asmk_a3_job_lifecycle and asmk_a5_job_statuses remain valid as sub-state detail.

**Assumption (asmk_a6_due_dates):** Scheduled service time windows (scheduled_start, scheduled_end) are a job-level attribute.

### Out of Scope

- Customer notifications of any kind (deferred past v1).
- Advanced workforce planning beyond job assignment and tracking.
- Fully custom reporting outside the core workflow views.
- External customer-facing access or self-service portals.
- Role-based access control or permission enforcement.
- Proactive SLA alerting or escalation systems.
- Invoicing, payroll, or billing.
- Multi-tenant support.

## Non-Goals

- Replace every surrounding back-office process in the first release.
- Optimize for external customer self-service in the first release.
- Build advanced analytics, charting, or resource-planning features.

## Constraints

1. **Simple data model** — The first release should keep the data model simple enough for dependable job creation, assignment, scheduling, and status tracking.
2. **Usability without training** — The UI should be usable without training for non-technical dispatchers and field technicians.
3. **Flat permissions** — All dispatchers share equal permissions in v1; role distinction is informational only.
4. **Single tenant** — The system is scoped to a single dispatch team / tenant. Multi-tenancy is not a v1 concern.

**Assumption (asmk_a4_dispatcher_perms):** Dispatchers share equal permissions in v1; role distinction between dispatchers is informational only. RBAC is out of scope.

**Assumption (asmk_a7_dispatcher_persona):** Manager/lead is a persona distinction, not a permission boundary in v1. Any dispatcher can manage any job.

**Assumption (asmk_a2_single_queue):** A single shared job queue per dispatch team is sufficient for the first release.

**Assumption (single_tenant_scope):** The product is single-tenant. This is fully propagated across product_brief (scope, constraints), domain_entities (ownership_assumptions), and user_workflows (actors, workflow_assumptions).

## Success Criteria

1. Dispatchers can create a job, assign a technician, and schedule a service window without leaving the product.
2. Dispatchers can see who owns each job and which jobs are unassigned or overdue.
3. Technicians can view assigned jobs, update status, and capture completion from the field.
4. The dispatch team can review the current job queue from a shared dashboard view.

## Key Assumptions Surfaced in This Document

| Assumption ID | Summary | Coherence | Impact |
|---------------|---------|-----------|--------|
| asmk_a1_internal_users | Primary users are internal staff, not customers | supported | cross_doc |
| asmk_a2_single_queue | Single shared job queue per team for v1 | supported | section_local |
| asmk_a3_job_lifecycle | Defined job lifecycle with cancelled as terminal | supported | cross_doc (sub-state detail under standardized_statuses) |
| asmk_a4_dispatcher_perms | Flat dispatcher permissions, no RBAC | supported | cross_doc |
| asmk_a5_job_statuses | Canonical job status set | supported | cross_doc (sub-state detail under standardized_statuses) |
| asmk_a6_due_dates | Time windows are job-level attributes | supported | section_local |
| asmk_a7_dispatcher_persona | Manager/lead is persona only, not permission | supported | section_local |
| asmk_a10_overdue | Overdue via dashboard filter; no proactive alerts | supported | cross_doc |
| asmk_a12_customer_notifications | **Superseded** by notifications_deferred | superseded | — |
| single_tenant_scope | Product is single-tenant | supported | cross_doc |
| notifications_deferred | Customer notifications deferred past v1 | supported | cross_doc |
| standardized_statuses | Canonical trio: open, in_progress, done | supported | cross_doc |

## Source Grounding Notes

This charter is grounded primarily in **product_brief.json** for product framing, scope, goals, and success criteria, and **assumptions_registry.json** for explicit assumption surfacing.

Key mutations from prior version:
- **Notifications removed from scope.** The notifications_deferred directive moves all customer notification work out of v1, superseding asmk_a12_customer_notifications. The customer entity remains as a passive reference only.
- **Single-tenant constraint added.** The single_tenant_scope assumption is now an explicit cross-cutting directive reflected in constraints and out-of-scope.
- **Standardized statuses adopted.** The canonical status model is now open/in_progress/done with domain sub-states mapped underneath. This does not change job behavior but establishes the normative status vocabulary across all project docs.

No content in this charter contradicts the canonical source docs. All assumptions are cross-doc consistent per the assumptions registry coherence analysis.