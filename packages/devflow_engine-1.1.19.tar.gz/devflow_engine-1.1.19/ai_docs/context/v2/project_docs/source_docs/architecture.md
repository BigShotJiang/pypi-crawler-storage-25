# Architecture

## System Overview

The field service dispatch application is an internal operations tool that enables dispatchers to create, assign, schedule, and track field service jobs, and enables technicians to receive assignments and update job status from the field. The system is built around a single shared job queue visible to all dispatchers, with a lightweight mobile-friendly surface for technician field use.

The system is single-tenant by design in v1 — one dispatch team operates one shared queue with no multi-tenancy, role-based access control, or permission boundaries. All dispatchers share equal authority over all jobs.

**Core system responsibilities:**
- Job lifecycle management (intake through completion/cancellation)
- Technician assignment and availability tracking
- Shared dispatcher dashboard with filtering and overdue highlighting
- Technician field interface for status updates and proof-of-completion capture
- Customer notification triggers on job status changes (delivery mechanism opaque in v1)

---

## Core Entities / Data Model

### Job
The central entity. Represents a field service work item the dispatch team needs to schedule, assign, and track.

| Attribute | Type | Notes |
|---|---|---|
| id | UUID/PK | System-generated |
| title | string | Required at creation |
| description | text | Optional at creation |
| status | enum | See lifecycle below |
| priority | enum | e.g. low, normal, high, urgent |
| scheduled_start | datetime | Start of service time window |
| scheduled_end | datetime | End of service time window |
| created_at | datetime | System-set |
| updated_at | datetime | System-set on any mutation |
| assigned_technician | FK → Technician | Nullable; set on assignment |
| created_by | FK → Dispatcher | Set at creation |
| customer | FK → Customer | Associated service recipient |

**Job lifecycle states:** `intake` → `scheduled` → `assigned` → `en_route` → `in_progress` → `completed`

- `cancelled` is reachable from any pre-completed status.
- The canonical status trio for coarse reporting is **open** (intake, scheduled), **in_progress** (assigned, en_route, in_progress), **done** (completed, cancelled). This sub-state mapping is an architectural convention, not a user-facing concept.

**Assumption note:** The full lifecycle chain (intake through completed, with cancelled as terminal) is grounded in assumptions `asmk_a3_job_lifecycle` and `asmk_a5_job_statuses`. The coarse trio mapping is from the `standardized_statuses` directive.

### Technician
Represents a field worker who executes jobs on site.

| Attribute | Type | Notes |
|---|---|---|
| id | UUID/PK | System-generated |
| name | string | Display name |
| role | string | Informational only in v1 |
| availability_state | enum | available, en_route, on_site, unavailable |

**Technician lifecycle:** `available` ↔ `en_route` ↔ `on_site` ↔ `unavailable`

Availability state is updated as technicians move through their assigned job workflow. A technician can own many active jobs simultaneously.

### Dispatcher
Represents an internal operator who manages the job queue.

| Attribute | Type | Notes |
|---|---|---|
| id | UUID/PK | System-generated |
| name | string | Display name |
| role | string | Informational only in v1 — no permission distinction |

**Assumption note:** All dispatchers share equal authority (`asmk_a4_dispatcher_perms`, `asmk_a7_dispatcher_persona`). Manager/lead is persona-level, not enforced by the system.

### Customer
Passive reference entity representing the party receiving field service.

| Attribute | Type | Notes |
|---|---|---|
| id | UUID/PK | System-generated |
| name | string | |
| contact_info | string/structured | Phone, email, address as needed |

**Assumption note:** Customers have no direct system access in v1. Notifications are deferred — the notification delivery mechanism is opaque (`asmk_a12_customer_notifications`, `notifications_deferred` directive). The customer entity exists for job association and future notification support.

---

## Key Relationships

### Job → Technician (assignment)
- Each active job may be assigned to **one** technician.
- A technician can own **many** jobs.
- Reassignment changes the link directly — no approval gate required (`asmk_a9_no_approval`).
- Unassigned jobs have a null technician reference and sit in the queue as `intake` or `scheduled`.

### Job → Dispatcher (creation/management)
- Jobs are created by a dispatcher.
- Any dispatcher can manage any job — there is no ownership restriction in v1.
- The `created_by` field is informational/auditable, not an access boundary.

### Job → Customer (service recipient)
- Each job is associated with one customer.
- This link drives future notification targeting but has no behavioral effect in v1 beyond data association.

### Technician availability vs. job assignment
- The system does not enforce scheduling conflict prevention in v1. A technician may have overlapping scheduled jobs if dispatch does not manually check availability. This is a known edge case acknowledged in source docs.

---

## Components / Surfaces

The system implies the following primary components:

### 1. Dispatcher Dashboard (Web)
- Shared view of the full job queue with current status.
- Filtering by status, priority, technician, and overdue state.
- Overdue job highlighting: jobs where `scheduled_end` has passed and status is not `completed` or `cancelled`.
- Job creation, editing, assignment, and rescheduling controls.
- Single-page or minimal-navigation design — usable without training for non-technical dispatchers.

### 2. Technician Field Interface (Mobile-friendly Web or Native)
- View of assigned jobs with route/schedule context.
- Status update controls: mark `en_route`, `in_progress`, `completed`.
- Proof-of-completion capture: notes, photos, signatures as applicable.
- Optimized for field use — minimal input, clear status affordances.

### 3. Job Lifecycle Engine (Backend)
- Enforces valid state transitions on the job entity.
- Records timestamps on status changes.
- Triggers downstream effects (e.g., notification events) on state transitions.
- Handles concurrent access: multiple dispatchers may attempt to assign the same unassigned job — the system should handle this gracefully (last-write-wins or optimistic locking).

### 4. Notification Subsystem (Stub/Opaque in v1)
- Job status changes emit notification events.
- The delivery mechanism (email, SMS, push) is **not defined** in v1.
- This subsystem exists as a boundary/interface that can be implemented later.

**Assumption note:** Customer notifications are explicitly deferred. The architecture should define the event boundary but not the delivery implementation (`notifications_deferred`).

### 5. Data Persistence Layer
- Relational data store for job, technician, dispatcher, and customer entities.
- The data model should be simple enough for dependable CRUD on the core entities (product_brief constraint).
- No advanced analytics, reporting, or warehouse requirements in v1.

---

## Integrations

The source docs define **no external integrations** for v1. The system is self-contained:

- No external calendar/scheduling systems.
- No external workforce management platforms.
- No invoicing, payroll, or billing integrations.
- No external customer portal or self-service access.

The notification subsystem boundary is the only integration-adjacent concern, and its external delivery mechanism is explicitly deferred.

---

## Constraints / Risks

### Constraints (from source docs)
1. **Simple data model** — The first release should keep the data model simple enough for dependable job creation, assignment, scheduling, and status tracking.
2. **Usable without training** — UI must be immediately usable by non-technical dispatchers and field technicians.
3. **Equal permissions** — All dispatchers share equal permissions. Role distinction is informational only (`asmk_a4_dispatcher_perms`).
4. **Single shared queue** — One job queue per dispatch team (`asmk_a2_single_queue`). No partitioning, no multi-team isolation.
5. **No RBAC** — Role-based access control is explicitly out of scope.
6. **No SLA enforcement** — Proactive SLA alerting and escalation systems are out of scope (`asmk_a10_overdue`). Overdue visibility is passive (dashboard filter/highlight).

### Architectural Risks
1. **Concurrent assignment race condition** — Multiple dispatchers may try to assign the same unassigned job simultaneously. The system needs a concurrency strategy (optimistic locking recommended) even though the source docs do not prescribe one.
2. **Technician schedule overlap** — No enforcement of scheduling conflict prevention. Dispatchers must manually check availability. This is acceptable for v1 but creates risk of double-booking.
3. **Notification boundary ambiguity** — The notification subsystem is opaque. If downstream consumers expect real notifications in v1, there will be a gap. The architecture should make the stub nature explicit.
4. **Proof-of-completion storage** — Photos, signatures, and notes require blob/file storage. Source docs mention this capability but do not specify storage constraints. This needs implementation-time decisions on storage backend and size limits.
5. **Offline/field connectivity** — Technician field use implies potentially unreliable connectivity. Source docs do not address offline capability. The architecture should assume online-only for v1 unless otherwise directed.

---

## Open Architectural Assumptions

| # | Assumption | Grounding | Confidence |
|---|---|---|---|
| 1 | Single-tenant, single-team deployment | `single_tenant_scope` directive, `asmk_a1_internal_users` | High — explicitly stated |
| 2 | All dispatchers have equal system authority | `asmk_a4_dispatcher_perms`, `asmk_a7_dispatcher_persona` | High — explicitly stated |
| 3 | Job lifecycle is the defined 7-state chain | `asmk_a3_job_lifecycle`, `asmk_a5_job_statuses` | High — explicitly stated |
| 4 | No approval gates on any workflow | `asmk_a9_no_approval` | High — explicitly stated |
| 5 | Customer notifications are deferred/opaque | `asmk_a12_customer_notifications`, `notifications_deferred` | High — explicitly stated |
| 6 | Overdue detection is passive (query-time, not push) | `asmk_a10_overdue` | High — explicitly stated |
| 7 | Concurrent dispatcher access handled by optimistic locking | Inferred from edge case (concurrent assignment) | Medium — not prescribed by source docs |
| 8 | Online-only for v1 (no offline technician support) | Inferred — source docs do not mention offline | Medium — absence of mention, not explicit exclusion |
| 9 | Proof-of-completion requires blob/file storage | Inferred from technician workflow (photos, signatures) | Medium — capability mentioned but storage not specified |
| 10 | Sparse alternate flows mean minimal backend branching logic | `asmk_a11_sparse_workflow` | High — explicitly stated |