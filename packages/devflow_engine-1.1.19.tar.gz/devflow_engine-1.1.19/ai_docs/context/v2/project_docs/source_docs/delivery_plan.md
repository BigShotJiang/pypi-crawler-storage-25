# Delivery Plan

## Delivery Strategy

This delivery plan sequences the build-out of a single-tenant field service job dispatch application for internal dispatch teams. The strategy is shaped by three priorities drawn from the source docs:

1. **Core loop first.** The intake → assign → execute → complete workflow is the backbone of every dispatcher and technician interaction. Nothing else is useful until this loop works end-to-end.
2. **Visibility before polish.** Dispatchers need a shared dashboard showing job state, ownership, and overdue items before any auxiliary features are layered on.
3. **Narrow scope, tight boundaries.** The product brief explicitly defers RBAC, SLA alerting, advanced analytics, customer self-service, customer notifications, and invoicing. The delivery plan respects those boundaries and does not sequence work toward out-of-scope features.

The plan assumes a single cross-functional team (or a small number of contributors) delivering incrementally against a shared backlog. Phases are sequenced by dependency order and user-value criticality, not by calendar dates — the source docs do not specify timeline commitments.

> **Assumption surfaced (single_tenant_scope):** The system is single-tenant. No multi-tenant data isolation, routing, or tenant-aware configuration is in scope for v1.

> **Assumption surfaced (asmk_a2_single_queue):** A single shared job queue per dispatch team is sufficient for the first release (medium confidence). If multi-queue requirements emerge, Phase 1 data model work may need revisiting.

> **Assumption surfaced (standardized_statuses):** All entity lifecycles use a canonical status trio — **open**, **in_progress**, **done** — with domain-specific sub-states (e.g., intake, scheduled, assigned, en_route, on_site, completed, cancelled) providing granularity underneath. The delivery plan sequences work around this canonical model.

---

## Phases / Milestones

### Phase 1 — Data Model & Job Lifecycle Foundation

**Goal:** Establish the core entities, relationships, and job state machine so that all subsequent features build on a stable foundation.

**Scope:**
- Implement the `Job` entity with key attributes: title, description, status, priority, scheduled_start, scheduled_end, created_at, updated_at.
- Implement the `Technician` entity with key attributes: name, role, availability_state.
- Implement the `Dispatcher` entity with key attributes: name, role.
- Implement the `Customer` entity as a passive reference entity (name, contact_info). Customers have no active system interaction in v1.
- Define the job lifecycle using the canonical status trio:
  - **open** — sub-states: intake, scheduled
  - **in_progress** — sub-states: assigned, en_route, on_site
  - **done** — sub-states: completed, cancelled
- Define technician availability states: available, en_route, on_site, unavailable.
- Establish relationships: job ↔ technician (assignment), job ↔ dispatcher (creator/manager), job ↔ customer (service recipient).

**Key decisions grounded in source docs:**
- All dispatchers share equal permissions; no RBAC enforcement is needed in the data layer (asmk_a4_dispatcher_perms, high confidence).
- Technicians cannot self-assign or reassign jobs; the assignment relationship is dispatcher-controlled (asmk_a8_assignment, high confidence).
- The canonical status trio (open, in_progress, done) is the primary status model. Sub-states provide domain granularity but all queries, filters, and dashboards should work against the canonical trio as the top-level grouping (standardized_statuses).
- Customer entity is passive reference only; no notification infrastructure is needed in the data layer (notifications_deferred).

**Exit criteria:**
- Entities can be created, read, updated via API or equivalent.
- Job status transitions are enforced (valid transitions only, respecting canonical trio boundaries).
- Relationships are queryable (e.g., "which jobs are assigned to technician X?").
- Sub-states map cleanly to their canonical parent status.

---

### Phase 2 — Job Intake & Dispatcher Dashboard

**Goal:** Enable dispatchers to create jobs and see the full job queue from a shared view.

**Scope:**
- **Job intake workflow (wf_intake_job):** Dispatcher creates a new job with title, description, priority, and optional scheduled service time window. Job enters the system at canonical status `open` (sub-state `intake`) and appears in the shared queue.
- **Shared dispatcher dashboard:** A list/table view of all jobs showing current canonical status, sub-state, assigned technician (if any), priority, and scheduled window.
- **Overdue job filtering/highlighting:** Jobs where the scheduled time has passed and canonical status is not `done` are visually flagged (asmk_a10_overdue, high confidence). This is a dashboard filter, not a push alert.

**Key decisions:**
- Dashboard is shared across all dispatchers with no per-dispatcher filtering or ownership segmentation in v1.
- Dashboard grouping and filtering should use the canonical trio (open, in_progress, done) as the primary lens, with sub-state as a secondary detail.
- Overdue visibility is passive (filter/highlight), not proactive (no SLA alerting, no escalation engine — explicitly out of scope per product_brief.scope.out_of_scope).

**Exit criteria:**
- A dispatcher can create a job and see it appear in the shared dashboard.
- The dashboard shows all jobs with accurate canonical status, sub-state, ownership, and schedule information.
- Overdue jobs are visually distinguishable.

---

### Phase 3 — Scheduling, Assignment & Reassignment

**Goal:** Enable dispatchers to assign jobs to technicians, set service windows, and handle reassignment.

**Scope:**
- **Schedule and assign workflow (wf_schedule_and_assign):** Dispatcher sets or confirms the scheduled service time window, assigns job to a technician. Job transitions from `open` to `in_progress` (sub-state `assigned`); technician is notified internally.
- **Reassignment workflow (wf_reschedule_job):** Dispatcher can change the assigned technician or update the scheduled time window on an existing job. Optionally add a note. No approval gate (asmk_a9_no_approval, high confidence).
- **Technician availability visibility:** Dashboard or assignment UI surfaces technician availability state to help dispatchers make informed assignments.

**Key decisions:**
- Reassignment is a direct dispatcher action — no approval workflow exists in v1.
- The system should record assignment changes (previous and new) but source docs do not specify a full audit log requirement; minimal change tracking is sufficient.
- Concurrent assignment conflict (edge case: two dispatchers assigning the same unassigned job) should be handled gracefully, though the exact mechanism is an implementation decision.

> **Edge case surfaced:** Multiple dispatchers may attempt to assign the same unassigned job concurrently (user_workflows.edge_cases). This phase should include at minimum an optimistic concurrency check or last-write-wins with notification.

> **Edge case surfaced:** A technician may have overlapping scheduled jobs if dispatch does not check availability (user_workflows.edge_cases). Phase 3 should surface scheduling conflicts to the dispatcher even if hard prevention is deferred.

**Exit criteria:**
- A dispatcher can assign a job to a technician and set a service window.
- A dispatcher can reassign a job to a different technician.
- Assignment transitions the job from canonical `open` to canonical `in_progress`.
- Assignment and schedule changes are reflected immediately in the dashboard.

---

### Phase 4 — Technician Field Execution & Completion

**Goal:** Enable technicians to view their assigned jobs, update status from the field, and capture proof of completion.

**Scope:**
- **Technician field execution workflow (wf_technician_field_execution):** Technician views assigned job details, marks sub-state `en_route`, marks sub-state `on_site` (work underway), captures proof of completion (notes, photos, signatures as applicable), marks sub-state `completed` (canonical status transitions to `done`).
- **Technician-facing view:** A focused view of the technician's assigned jobs with ability to update status.
- **Proof-of-completion capture:** At minimum, notes. Photos and signatures are implied by the source docs but the exact capture mechanism is an implementation decision.
- **Overdue job handling workflow (wf_handle_overdue_job):** Dispatcher identifies overdue jobs via dashboard filter, reviews and decides to reprioritize, reassign, or update schedule, then updates accordingly.

**Key decisions:**
- Technicians can only update status on their own assigned jobs; they cannot reassign, reschedule, or manage the queue (asmk_a8_assignment).
- The technician view should be usable without training for non-technical field workers (product_brief.constraints).
- Status updates by technicians should be reflected in the dispatcher dashboard in near-real-time.
- No customer notification is triggered on completion in v1 (notifications_deferred). The system records completion state only.

**Exit criteria:**
- A technician can view their assigned jobs.
- A technician can progress a job through en_route → on_site → completed (canonical: in_progress → done).
- Proof of completion (at minimum notes) is captured and visible to dispatchers.
- Job completion is reflected in the shared dashboard.
- Dispatchers can use the overdue filter to find and act on stale jobs.
- The full intake → assign → execute → complete loop works end-to-end.

---

## Implementation Priorities

Priority ordering reflects dependency chains and user-value concentration:

| Priority | Capability | Rationale |
|----------|-----------|----------|
| P0 | Job data model and canonical status trio with sub-states | Everything depends on this |
| P0 | Job intake (create job) | Entry point for all workflows |
| P0 | Shared dispatcher dashboard | Primary visibility surface |
| P1 | Job assignment and scheduling | Core dispatch function |
| P1 | Technician field status updates | Closes the operational loop |
| P1 | Reassignment and rescheduling | Critical exception path |
| P2 | Overdue job highlighting and filtering | Operational hygiene |
| P2 | Proof-of-completion capture | Quality assurance |
| P3 | Concurrent assignment conflict handling | Edge case resilience |
| P3 | Scheduling overlap warnings | Edge case resilience |

> **Removed from v1 priorities:** Customer notifications are fully deferred (notifications_deferred). No notification infrastructure, triggers, or delivery channel work is in scope.

---

## Dependencies

### Internal dependencies (phase-to-phase)

- **Phase 2 depends on Phase 1:** Dashboard and intake require the data model and lifecycle definitions.
- **Phase 3 depends on Phase 2:** Assignment requires jobs to exist and be visible in the dashboard.
- **Phase 4 depends on Phase 3:** Technician execution requires jobs to be assigned.

### Cross-cutting dependencies

- **UI usability constraint** (product_brief.constraints): The UI must be usable without training for non-technical dispatchers and technicians. This applies across Phases 2–4 and should be a continuous design consideration, not a phase-gated activity.
- **Technician availability state management:** Phase 3 surfaces availability; the mechanism for technicians to set their own availability (or for it to be derived from job state) needs to be decided during Phase 1 data model work.
- **Canonical status trio consistency:** All phases must use the canonical trio (open, in_progress, done) as the primary status model. Sub-states are implementation detail visible in the UI but should not drive top-level business logic or routing.

---

## Risks / Watchouts

| Risk | Severity | Mitigation |
|------|----------|------------|
| **Single queue assumption may not hold** — If dispatch teams need separate queues per region, skill, or team, the data model may need partitioning. | Medium | Validate asmk_a2_single_queue early with stakeholders. Design the data model so adding a queue/team dimension is additive, not a rewrite. |
| **Concurrent assignment conflicts** — Two dispatchers assigning the same job simultaneously could cause confusion. | Low–Medium | Implement optimistic concurrency or clear last-write-wins behavior in Phase 3. |
| **Technician scheduling overlaps** — Without hard scheduling conflict prevention, dispatchers may double-book technicians. | Low–Medium | Surface scheduling warnings in Phase 3 UI. Hard prevention can be deferred but the data model should support overlap detection. |
| **Proof-of-completion scope creep** — Photos, signatures, and notes each have different implementation complexity. | Low | Start with text notes. Add photo/signature capture incrementally based on actual field needs. |
| **Sub-state vs. canonical status confusion** — Developers or users may conflate sub-states with canonical statuses, leading to inconsistent filtering or reporting. | Low–Medium | Establish clear naming and documentation in Phase 1. Dashboard and API should expose both levels cleanly. |
| **Single-tenant assumption limits future growth** — No multi-tenant infrastructure means the system cannot serve multiple organizations without rework. | Low (accepted) | This is an explicit v1 scope decision. Design data model cleanly but do not build tenant isolation. |

---

## Recommended Next Steps

1. **Validate the single-queue assumption (asmk_a2_single_queue)** with the dispatch team before locking the data model. This is the highest-leverage assumption to confirm or bust early.
2. **Finalize the sub-state mapping** under the canonical trio. Confirm that the sub-states (intake, scheduled, assigned, en_route, on_site, completed, cancelled) are the correct granularity and that no states are missing.
3. **Begin Phase 1** — data model and lifecycle state machine using the canonical trio. This is prerequisite to all other work and has no external dependencies.
4. **Establish a lightweight acceptance check** per phase exit criteria before proceeding to the next phase, to avoid rework cascades.
5. **Defer notification infrastructure scouting** — customer notifications are explicitly out of v1 scope (notifications_deferred). No notification work should be started or scouted.

---

## Assumptions Reflected in This Plan

The following assumptions materially shape this delivery plan:

- **asmk_a1_internal_users** (high confidence): Primary users are dispatchers and technicians, not external customers. This keeps the UX focused on operational workflows.
- **asmk_a2_single_queue** (medium confidence): Single shared queue per team. If invalidated, Phase 1 data model needs queue partitioning.
- **asmk_a3_job_lifecycle** (medium confidence): Canonical lifecycle with domain-specific sub-states under the trio. Delivery phases are sequenced around this lifecycle.
- **asmk_a4_dispatcher_perms** (high confidence): Equal dispatcher permissions, no RBAC. Simplifies the authorization model across all phases.
- **asmk_a8_assignment** (high confidence): Dispatcher-only assignment authority. Shapes the Phase 3 and Phase 4 boundary.
- **asmk_a9_no_approval** (high confidence): No approval gates on reassignment. Keeps Phase 3 scope tight.
- **asmk_a10_overdue** (high confidence): Overdue visibility is passive filtering, not proactive alerting. Keeps Phase 4 scope bounded.
- **single_tenant_scope** (high confidence): Single-tenant system. No multi-tenant data isolation or routing.
- **notifications_deferred** (high confidence): Customer notifications are fully deferred past v1. No notification infrastructure, triggers, or delivery channel work is in scope. This supersedes asmk_a12_customer_notifications.
- **standardized_statuses** (high confidence): Canonical trio (open, in_progress, done) with domain-specific sub-states. All phases build on this model.

Where confidence is medium, the plan notes the risk and recommends early validation.