# UX Design — Field Service Dispatch App (v1)

## UX Overview

This document defines the user interaction and experience framing for a field service job dispatch application. The product serves two primary internal user types — **dispatchers** and **field technicians**. **Customers** are passive reference entities only in v1; customer notifications are deferred past v1 (assumption: notifications_deferred).

The UX must prioritize:
- **Operational clarity**: dispatchers need to see job status, ownership, and overdue items at a glance.
- **Minimal-training usability**: the UI must be usable without training for non-technical dispatchers and field technicians (product_brief.constraints).
- **Field-ready interaction**: technicians update status and capture completion from mobile/field contexts.

All dispatchers share equal permissions in v1; there is no RBAC or role-gated UI (assumption asmk_a4_dispatcher_perms). The system operates in a single-tenant context — one dispatch team, one shared queue (assumption: single_tenant_scope, asmk_a2_single_queue).

Customer notifications are explicitly deferred past v1 (assumption: notifications_deferred). No UX surfaces for notification preferences, delivery tracking, or customer-facing status views are required.

---

## Primary User Flows

These flows are directly grounded in the canonical user_workflows.json primary_workflows and alternate_flows.

### Flow 1: Job Intake (Dispatcher)
**Source**: wf_intake_job

1. Dispatcher opens the dispatch app and initiates "Create Job."
2. Dispatcher fills in core fields: **title**, **description**, **priority**, and optionally a **scheduled service time window** (scheduled_start / scheduled_end).
3. Dispatcher saves the job.
4. Job appears in the shared dispatch queue with status **open** (sub-state: intake).
5. Job is now visible to all dispatchers.

**UX goal**: Fast, low-friction job capture. The form should default to minimal required fields (title, priority) with description and scheduling as encouraged but not blocking.

### Flow 2: Schedule and Assign (Dispatcher)
**Source**: wf_schedule_and_assign

1. Dispatcher reviews the open job queue or dashboard, filtering for jobs in **open** status (sub-states: intake, scheduled).
2. Dispatcher opens a job and sets or confirms the scheduled service time window.
3. Dispatcher assigns the job to a technician, informed by technician availability state.
4. Job transitions to **in_progress** (sub-state: assigned); technician sees the job in their assigned list.

**UX goal**: Assignment should surface technician availability inline — the dispatcher should not need to leave the job context to check who is available.

**Note on standardized statuses**: The canonical status trio is **open**, **in_progress**, **done**. The domain-specific sub-states (intake, scheduled, assigned, en_route, in_progress, completed, cancelled) provide granularity within these buckets. The UI should display sub-state labels for operational clarity while the underlying system uses the canonical trio for status grouping, filtering, and dashboard layout.

### Flow 3: Technician Field Execution (Technician)
**Source**: wf_technician_field_execution

1. Technician views their assigned jobs with relevant details and route context.
2. Technician marks status **en_route** when traveling.
3. Technician marks status **in_progress** upon arrival.
4. Technician captures proof of completion (notes, photos, signatures as applicable).
5. Technician marks job **completed** (canonical status: done).

**UX goal**: Status transitions should be single-tap actions. Proof-of-completion capture must work in field conditions (potentially low connectivity, mobile device).

**Note**: No customer notification is triggered in v1 (assumption: notifications_deferred). The technician completion flow ends at proof capture and status update.

### Flow 4: Reassign or Reschedule (Dispatcher)
**Source**: wf_reschedule_job

1. Dispatcher opens a job from the queue or dashboard.
2. Dispatcher changes the assigned technician or updates the scheduled time window.
3. Dispatcher optionally adds a note explaining the reassignment reason.
4. Previous and new assignments are recorded.

**UX goal**: Reassignment is a direct action with no approval gate (assumption asmk_a9_no_approval). The UI should make it clear who was previously assigned.

### Flow 5: Handle Overdue Jobs (Dispatcher)
**Source**: wf_handle_overdue_job

1. Dispatcher identifies overdue jobs via the dashboard filter or overdue highlight.
2. Dispatcher reviews blocked or stale jobs.
3. Dispatcher decides to reprioritize, reassign, or update the schedule.
4. Dispatcher updates the job accordingly.

**UX goal**: Overdue jobs must be visually prominent — not buried in the queue. Filtering or highlighting overdue items is in scope; proactive push alerts are not (assumption asmk_a10_overdue).

---

## Key Screens / Views

The following screens are implied by the source workflows and product scope.

### 1. Dispatcher Dashboard (Shared Queue View)
**Purpose**: Central operational view for all dispatchers.

**Content**:
- List/table of all jobs with columns: title, status (sub-state label), priority, assigned technician (or "unassigned"), scheduled window, overdue indicator.
- Filter controls: by canonical status (open / in_progress / done), by sub-state, by assignment state (assigned/unassigned), by overdue flag, by priority.
- Sort controls: by priority, by scheduled time, by creation date.
- Quick-access actions: create new job, open job detail.

**Key design considerations**:
- Overdue jobs should be visually highlighted (color, icon, or badge) without requiring the dispatcher to activate a filter.
- Unassigned jobs should be clearly distinguishable from assigned ones.
- The dashboard must support the shared-queue model — all dispatchers see the same view (assumption asmk_a2_single_queue).
- Status grouping by canonical trio (open / in_progress / done) should be the primary organizational axis, with sub-state labels providing operational detail within each group.

### 2. Job Detail / Edit View
**Purpose**: View and modify a single job's details.

**Content**:
- Job fields: title, description, status (read-only display of current sub-state and canonical status), priority, scheduled_start, scheduled_end, assigned technician, created_at, updated_at.
- Assignment control: select/change technician with visibility into technician availability.
- Status history or audit trail (implied by reassignment tracking).
- Notes section (supports reassignment reason notes).
- Action buttons contextual to current status (e.g., "Assign" when in open/intake, "Reassign" when in_progress/assigned).

### 3. Job Creation Form
**Purpose**: Capture a new job into the system.

**Content**:
- Required fields: title, priority.
- Optional fields: description, scheduled_start, scheduled_end.
- Save action creates the job in **open** status (sub-state: intake).

**Key design considerations**:
- Should be accessible from the dashboard with minimal navigation.
- Form should be simple enough for non-technical dispatchers to complete without training.

### 4. Technician Job List (Field View)
**Purpose**: Technician's view of their assigned work.

**Content**:
- List of jobs assigned to the current technician, ordered by schedule or priority.
- Each job shows: title, status (sub-state label), priority, scheduled window, customer/location info as available.
- Tap into a job to see full details and take status actions.

**Key design considerations**:
- Must be optimized for mobile / field use.
- Should surface the most urgent or next-scheduled job prominently.

### 5. Technician Job Execution View
**Purpose**: Single-job view for field execution and status updates.

**Content**:
- Full job details (title, description, scheduled window, customer info).
- Status transition buttons: "En Route" → "In Progress" → "Complete."
- Proof-of-completion capture: notes field, photo upload, signature capture (as applicable).
- Confirmation before marking complete.

**Key design considerations**:
- Status transitions should be prominent single-tap actions.
- Proof-of-completion capture should tolerate intermittent connectivity.
- No customer notification UI is shown on completion — notifications are deferred past v1.

### 6. Technician Availability View (Dispatcher-Facing)
**Purpose**: Help dispatchers make informed assignment decisions.

**Content**:
- List of technicians with their current availability state (available, en_route, on_site, unavailable).
- Optionally show current job count or next-scheduled job.

**Note**: This may be a standalone view or an inline panel within the job assignment interaction. Source docs do not prescribe the exact surface — this is a UX design decision.

---

## Important Interactions

### Job Status Transitions

The job lifecycle uses a **canonical status trio** — **open**, **in_progress**, **done** — with domain-specific sub-states providing operational granularity (assumption: standardized_statuses).

| Canonical Status | Sub-States | Controlled By |
|---|---|---|
| open | intake, scheduled | Dispatcher |
| in_progress | assigned, en_route, in_progress | Dispatcher (assignment) / Technician (field transitions) |
| done | completed, cancelled | Technician (completion) / Dispatcher (cancellation) |

- Dispatchers control transitions through the open bucket and into in_progress (via scheduling and assignment).
- Technicians control transitions within in_progress through to done/completed (via field execution).
- **Cancelled** is reachable from any pre-completed status and maps to the done bucket as a terminal sub-state.
- The transition from **intake** to **scheduled** may be implicit (setting a time window) or explicit — source docs leave this slightly ambiguous.

**UX recommendation**: Treat **scheduled** as an implicit transition triggered by saving a time window on an intake job. This reduces cognitive overhead for dispatchers. Display the sub-state label in the UI for clarity, but group/filter by canonical status.

### Assignment Interaction
- Dispatchers assign technicians to jobs. Technicians cannot self-assign or reassign (assumption asmk_a8_assignment).
- The assignment interaction should present technician availability inline.
- Reassignment is a direct action — no approval workflow (assumption asmk_a9_no_approval).

### Overdue Highlighting
- A job is overdue when its scheduled time has passed and status is not **done** (completed or cancelled).
- Overdue jobs should be highlighted in the dashboard without requiring a filter action.
- Filtering to show only overdue jobs should also be available.
- Proactive push alerts for overdue jobs are out of scope (assumption asmk_a10_overdue).

### Proof-of-Completion Capture
- Technicians capture notes, photos, and/or signatures when completing a job.
- The exact capture requirements are not fully specified in source docs — implementation should support at minimum a notes field and photo attachment.

---

## Edge / Error Experiences

These are grounded in user_workflows.json edge_cases and relevant assumptions.

### Incomplete Job Creation
**Edge case**: Jobs may be created without enough detail to assign confidently.
**UX response**: Allow saving jobs with minimal fields (title + priority). The job remains in **open** (sub-state: intake) and is visible in the queue. Dispatchers can add detail before assignment. Do not block creation on optional fields.

### Concurrent Assignment Conflict
**Edge case**: Multiple dispatchers may attempt to assign the same unassigned job concurrently.
**UX response**: The UI should handle this gracefully — if a dispatcher attempts to assign a job that was just assigned by another dispatcher, show a clear message (e.g., "This job was just assigned to [technician] by [dispatcher]. Would you like to reassign?"). This is a v1 concern given the shared queue model.

### Overlapping Technician Schedules
**Edge case**: A technician may have overlapping scheduled jobs if the dispatcher does not check availability.
**UX response**: Surface a warning when assigning a job to a technician who has a scheduling conflict. Do not block the assignment (dispatchers have full authority), but make the conflict visible. Source docs note this as an edge case but do not mandate enforcement.

### Overdue / Stale Jobs
**Edge case**: Jobs can become blocked or overdue and need an escalation path.
**UX response**: Visual overdue highlighting in the dashboard. The alternate flow (wf_handle_overdue_job) provides the dispatcher path: review, reprioritize, reassign, or reschedule. No automated escalation in v1.

### Technician Unavailability After Assignment
**Edge case**: Assigned technician becomes unavailable.
**UX response**: The reassignment flow (wf_reschedule_job) handles this. The dispatcher opens the job and reassigns. The UI should record the reassignment with an optional reason note.

### Field Connectivity Issues
**Edge case**: Technician loses connectivity during field execution.
**UX response**: Source docs do not explicitly address offline/connectivity handling. This is a UX assumption area — at minimum, status updates and proof-of-completion capture should degrade gracefully (e.g., queue updates for sync when connectivity returns). **This is noted as thin source grounding; implementation should confirm offline requirements.**

---

## UX Assumptions

The following assumptions materially shape UX decisions in this document:

| Assumption ID | Summary | Impact on UX |
|---|---|---|
| asmk_a1_internal_users | Primary users are dispatchers and technicians, not customers | No customer-facing UI required in v1 |
| asmk_a2_single_queue | Single shared job queue per dispatch team | One dashboard view for all dispatchers; no team/queue segmentation |
| asmk_a4_dispatcher_perms | All dispatchers share equal permissions | No permission-gated UI elements; all dispatchers see and can act on all jobs |
| asmk_a8_assignment | Only dispatchers can assign/reassign | Technician view has no assignment controls |
| asmk_a9_no_approval | No approval gate for reassignment/reschedule | No approval workflow UI needed |
| asmk_a10_overdue | Overdue visibility via filter, not push alerts | Dashboard highlighting and filtering only; no notification center for overdue alerts |
| single_tenant_scope | Single-tenant, single dispatch team | No tenant switching, team selection, or multi-org UI |
| notifications_deferred | Customer notifications deferred past v1 | No notification preferences, delivery tracking, or customer-facing status UI. Supersedes asmk_a12_customer_notifications. |
| standardized_statuses | Canonical trio: open, in_progress, done | UI groups/filters by canonical status; sub-state labels shown for operational detail |

**Additional UX-specific assumptions** (not in source docs but implied by UX decisions):
- The dispatcher dashboard is a web application; the technician field view is optimized for mobile. Source docs do not prescribe platform but workflow context strongly implies this split.
- The **scheduled** status transition is implicit (triggered by setting a time window) rather than a manual step. This resolves the open question on asmk_a3_job_lifecycle in favor of simplicity.
- Offline/low-connectivity support for technician field execution is desirable but not explicitly scoped. Implementation should confirm requirements.

---

## Source Grounding Notes

**Well-grounded areas**:
- Primary user flows (directly mapped from wf_intake_job, wf_schedule_and_assign, wf_technician_field_execution, wf_reschedule_job, wf_handle_overdue_job)
- Job lifecycle and standardized status model (canonical trio with sub-states)
- Dispatcher authority and permission model
- Edge cases (directly from user_workflows.json edge_cases)
- Notifications deferred directive (clearly scoped out of v1 UX)

**Thin source grounding**:
- Proof-of-completion capture specifics (notes, photos, signatures mentioned but not detailed)
- Platform/device context (web vs. mobile not stated; inferred from workflow context)
- Offline/connectivity handling (not addressed in source docs)
- Technician availability view design (entity exists but no workflow prescribes how dispatchers consult it during assignment)
- Exact sub-state display strategy (source docs define the canonical trio and sub-states but do not prescribe how the UI should present the mapping)