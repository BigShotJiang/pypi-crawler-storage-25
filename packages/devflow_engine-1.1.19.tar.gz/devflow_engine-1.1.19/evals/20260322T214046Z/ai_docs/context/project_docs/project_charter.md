# Project Charter: Field Service Job Dispatch App

## Overview

A field service job dispatch application that enables dispatchers to create jobs, assign them to technicians, and track progress through a shared dashboard. Customers receive status notifications as jobs move through their lifecycle. The product replaces manual or fragmented dispatch processes with a unified workflow for job creation, assignment, scheduling, and completion tracking.

## Problem / Opportunity

The dispatch team is handling field service jobs through manual or fragmented processes, making job ownership, technician availability, and schedule adherence hard to track. This lack of visibility leads to operational inefficiency — jobs may be unassigned, overdue, or untracked, with no single system providing the team a shared picture of current work.

The opportunity is to deliver a focused tool that gives dispatchers and technicians a reliable, shared workflow for managing the full job lifecycle from intake through completion.

## Target Users

| User | Role | Interaction Model |
|------|------|-------------------|
| **Dispatchers** | Create, assign, schedule, and monitor jobs. Manage the shared job queue. | Active — full operational control |
| **Field Technicians** | Receive assignments, update job status, and capture proof of completion from the field. | Active — field-facing, status-driven |
| **Customers** | Receive job confirmation and status notifications. | Passive — notification recipients only in v1 |

**Assumption (asmk_a1_internal_users):** Primary users are internal dispatchers and field technicians, not external customers. Customers receive notifications only. This assumption is grounded across product_brief.target_users, domain_entities.ownership_assumptions, and user_workflows.actors.

## Goals

1. **Shared dispatch workflow** — Create a shared system so the team can capture, assign, schedule, and complete jobs reliably from a single tool.
2. **Operational visibility** — Give dispatchers visibility into job ownership, technician availability, current job status, and overdue items.
3. **Field-ready technician experience** — Enable technicians to receive job details and update status from the field, including proof-of-completion capture.

## Scope

### In Scope

- Job creation with title, description, priority, and scheduled service time window.
- Assignment of jobs to individual technicians.
- Status tracking through the job lifecycle: **intake → scheduled → assigned → en_route → in_progress → completed**, with **cancelled** reachable from any pre-completed status.
- A shared dispatcher dashboard showing all jobs and their current state.
- Filtering or highlighting overdue jobs in the shared view.
- Basic customer notifications for job confirmation and status changes.
- Technician status updates and proof-of-completion capture from the field.

**Assumption (asmk_a3_job_lifecycle):** The job lifecycle follows intake → scheduled → assigned → en_route → in_progress → completed, with cancelled as a terminal state reachable from any pre-completed status. This is reconciled across all three source docs. Open question: whether "scheduled" is a distinct state from "intake" or implied by having a time window set.

**Assumption (asmk_a5_job_statuses):** Job statuses are a defined, canonical set: intake, scheduled, assigned, en_route, in_progress, completed, cancelled.

**Assumption (asmk_a6_due_dates):** Scheduled service time windows (scheduled_start, scheduled_end) are a job-level attribute.

### Out of Scope

- Advanced workforce planning beyond job assignment and tracking.
- Fully custom reporting outside the core workflow views.
- External customer-facing access or self-service portals.
- Role-based access control or permission enforcement.
- Proactive SLA alerting or escalation systems.
- Invoicing, payroll, or billing.

## Non-Goals

- Replace every surrounding back-office process in the first release.
- Optimize for external customer self-service in the first release.
- Build advanced analytics, charting, or resource-planning features.

## Constraints

1. **Simple data model** — The first release should keep the data model simple enough for dependable job creation, assignment, scheduling, and status tracking.
2. **Usability without training** — The UI should be usable without training for non-technical dispatchers and field technicians.
3. **Flat permissions** — All dispatchers share equal permissions in v1; role distinction is informational only.

**Assumption (asmk_a4_dispatcher_perms):** Dispatchers share equal permissions in v1; role distinction between dispatchers is informational only. RBAC is out of scope.

**Assumption (asmk_a7_dispatcher_persona):** Manager/lead is a persona distinction, not a permission boundary in v1. Any dispatcher can manage any job.

**Assumption (asmk_a2_single_queue):** A single shared job queue per dispatch team is sufficient for the first release. Confidence: medium.

## Success Criteria

1. Dispatchers can create a job, assign a technician, and schedule a service window without leaving the product.
2. Dispatchers can see who owns each job and which jobs are unassigned or overdue.
3. Technicians can view assigned jobs, update status, and capture completion from the field.
4. The dispatch team can review the current job queue from a shared dashboard view.

## Key Assumptions Surfaced in This Document

| Assumption ID | Summary | Confidence | Impact |
|---------------|---------|------------|--------|
| asmk_a1_internal_users | Primary users are internal staff, not customers | High | cross_doc |
| asmk_a2_single_queue | Single shared job queue per team for v1 | Medium | section_local |
| asmk_a3_job_lifecycle | Defined job lifecycle with cancelled as terminal | Medium | cross_doc |
| asmk_a4_dispatcher_perms | Flat dispatcher permissions, no RBAC | High | cross_doc |
| asmk_a5_job_statuses | Canonical job status set | Medium | cross_doc |
| asmk_a6_due_dates | Time windows are job-level attributes | High | section_local |
| asmk_a7_dispatcher_persona | Manager/lead is persona only, not permission | High | section_local |
| asmk_a10_overdue | Overdue via dashboard filter; no proactive alerts | High | cross_doc |
| asmk_a12_customer_notifications | Notifications triggered by status change; delivery mechanism opaque in v1 | Medium | cross_doc |

## Source Grounding Notes

This charter is grounded primarily in **product_brief.json** for product framing, scope, goals, and success criteria, and **assumptions_registry.json** for explicit assumption surfacing. Where assumptions carry medium confidence or open questions, these are noted inline. No content in this charter contradicts the canonical source docs.