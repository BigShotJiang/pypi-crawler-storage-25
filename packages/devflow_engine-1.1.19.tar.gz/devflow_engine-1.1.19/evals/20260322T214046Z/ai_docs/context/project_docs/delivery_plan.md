# Delivery Plan

## Delivery Strategy

This delivery plan sequences the build-out of a field service job dispatch application for internal dispatch teams. The strategy is shaped by three priorities drawn from the source docs:

1. **Core loop first.** The intake → assign → execute → complete workflow is the backbone of every dispatcher and technician interaction. Nothing else is useful until this loop works end-to-end.
2. **Visibility before polish.** Dispatchers need a shared dashboard showing job state, ownership, and overdue items before any auxiliary features are layered on.
3. **Narrow scope, tight boundaries.** The product brief explicitly defers RBAC, SLA alerting, advanced analytics, customer self-service, and invoicing. The delivery plan respects those boundaries and does not sequence work toward out-of-scope features.

The plan assumes a single cross-functional team (or a small number of contributors) delivering incrementally against a shared backlog. Phases are sequenced by dependency order and user-value criticality, not by calendar dates — the source docs do not specify timeline commitments.

> **Assumption surfaced:** A single shared job queue per dispatch team is sufficient for the first release (asmk_a2_single_queue, medium confidence). If multi-queue requirements emerge, Phase 1 data model work may need revisiting.

---

## Phases / Milestones

### Phase 1 — Data Model & Job Lifecycle Foundation

**Goal:** Establish the core entities, relationships, and job state machine so that all subsequent features build on a stable foundation.

**Scope:**
- Implement the `Job` entity with key attributes: title, description, status, priority, scheduled_start, scheduled_end, created_at, updated_at.
- Implement the `Technician` entity with key attributes: name, role, availability_state.
- Implement the `Dispatcher` entity with key attributes: name, role.
- Implement the `Customer` entity with key attributes: name, contact_info.
- Define the job lifecycle state machine: intake → scheduled → assigned → en_route → in_progress → completed, with cancelled reachable from any pre-completed status.
- Define the technician availability states: available, en_route, on_site, unavailable.
- Establish relationships: job ↔ technician (assignment), job ↔ dispatcher (creator/manager), job ↔ customer (service recipient).

**Key decisions grounded in source docs:**
- All dispatchers share equal permissions; no RBAC enforcement is needed in the data layer (asmk_a4_dispatcher_perms, high confidence).
- Technicians cannot self-assign or reassign jobs; the assignment relationship is dispatcher-controlled (asmk_a8_assignment, high confidence).
- Job lifecycle includes `en_route` as a canonical job-level state; technician `en_route` is derived (asmk_a3_job_lifecycle, medium confidence).

**Exit criteria:**
- Entities can be created, read, updated via API or equivalent.
- Job status transitions are enforced (valid transitions only).
- Relationships are queryable (e.g., "which jobs are assigned to technician X?").

---

### Phase 2 — Job Intake & Dispatcher Dashboard

**Goal:** Enable dispatchers to create jobs and see the full job queue from a shared view.

**Scope:**
- **Job intake workflow (wf_intake_job):** Dispatcher creates a new job with title, description, priority, and optional scheduled service time window. Job enters the system at status `intake` and appears in the shared queue.
- **Shared dispatcher dashboard:** A list/table view of all jobs showing current status, assigned technician (if any), priority, and scheduled window.
- **Overdue job filtering/highlighting:** Jobs where the scheduled time has passed and status is not `completed` or `cancelled` are visually flagged (asmk_a10_overdue, high confidence). This is a dashboard filter, not a push alert.

**Key decisions:**
- Dashboard is shared across all dispatchers with no per-dispatcher filtering or ownership segmentation in v1.
- Overdue visibility is passive (filter/highlight), not proactive (no SLA alerting, no escalation engine — explicitly out of scope per product_brief.scope.out_of_scope).

**Exit criteria:**
- A dispatcher can create a job and see it appear in the shared dashboard.
- The dashboard shows all jobs with accurate status, ownership, and schedule information.
- Overdue jobs are visually distinguishable.

---

### Phase 3 — Scheduling, Assignment & Reassignment

**Goal:** Enable dispatchers to assign jobs to technicians, set service windows, and handle reassignment.

**Scope:**
- **Schedule and assign workflow (wf_schedule_and_assign):** Dispatcher sets or confirms the scheduled service window, assigns job to a technician, job transitions to `assigned`, technician is notified.
- **Reassignment workflow (wf_reschedule_job):** Dispatcher can change the assigned technician or update the scheduled time window on an existing job. Optionally add a note. No approval gate (asmk_a9_no_approval, high confidence).
- **Technician availability visibility:** Dashboard or assignment UI surfaces technician availability state to help dispatchers make informed assignments.

**Key decisions:**
- Reassignment is a direct dispatcher action — no approval workflow exists in v1.
- The system should record assignment changes (previous and new) but source docs do not specify a full audit log requirement; minimal change tracking is sufficient.
- Concurrent assignment conflict (edge case: two dispatchers assigning the same unassigned job) should be handled gracefully, though the exact mechanism is an implementation decision.

> **Edge case surfaced:** Multiple dispatchers may attempt to assign the same unassigned job concurrently (user_workflows.edge_cases). This phase should include at minimum an optimistic concurrency check or last-write-wins with notification.

> **Edge case surfaced:** A technician may have overlapping scheduled jobs if dispatch does not check availability (user_workflows.edge_cases). Phase 3 should surface scheduling conflicts to the dispatcher even if hard prevention is deferred.

**Exit criteria:**
- A dispatcher can assign a job to a technician and set a service window.
- A dispatcher can reassign a job to a different technician.
- Assignment and schedule changes are reflected immediately in the dashboard.

---

### Phase 4 — Technician Field Execution

**Goal:** Enable technicians to view their assigned jobs, update status from the field, and capture proof of completion.

**Scope:**
- **Technician field execution workflow (wf_technician_field_execution):** Technician views assigned job details, marks `en_route`, marks `in_progress`, captures proof of completion (notes, photos, signatures as applicable), marks `completed`.
- **Technician-facing view:** A focused view of the technician's assigned jobs with ability to update status.
- **Proof-of-completion capture:** At minimum, notes. Photos and signatures are implied by the source docs but the exact capture mechanism is an implementation decision.

**Key decisions:**
- Technicians can only update status on their own assigned jobs; they cannot reassign, reschedule, or manage the queue (asmk_a8_assignment).
- The technician view should be usable without training for non-technical field workers (product_brief.constraints).
- Status updates by technicians should be reflected in the dispatcher dashboard in near-real-time.

**Exit criteria:**
- A technician can view their assigned jobs.
- A technician can progress a job through en_route → in_progress → completed.
- Proof of completion (at minimum notes) is captured and visible to dispatchers.
- Job completion is reflected in the shared dashboard.

---

### Phase 5 — Customer Notifications & Overdue Handling

**Goal:** Close the loop with basic customer notifications and formalize the overdue job handling workflow.

**Scope:**
- **Customer notifications:** Triggered by job status changes. Customer receives confirmation and status updates. The notification delivery mechanism (email, SMS, push) is opaque in v1 — the system emits notification events; the delivery channel is an implementation/integration decision (asmk_a12_customer_notifications, medium confidence).
- **Overdue job handling workflow (wf_handle_overdue_job):** Dispatcher identifies overdue jobs via dashboard filter, reviews and decides to reprioritize, reassign, or update schedule, then updates accordingly.

**Key decisions:**
- Customer notifications are for passive recipients only; no customer-facing portal or self-service (product_brief.scope.out_of_scope).
- The notification trigger points are not fully specified in source docs. Open question: every status change or only key milestones (assigned, en_route, completed)? This should be decided during implementation.

> **Unresolved question:** What triggers a customer notification — every status change or only key milestones? Source docs note this is opaque in v1. Recommend starting with key milestones (assigned, en_route, completed) and expanding if needed.

**Exit criteria:**
- Customer notifications fire on job status changes (at least key milestones).
- Dispatchers can use the overdue filter to find and act on stale jobs.
- The full intake → assign → execute → complete → notify loop works end-to-end.

---

## Implementation Priorities

Priority ordering reflects dependency chains and user-value concentration:

| Priority | Capability | Rationale |
|----------|-----------|----------|
| P0 | Job data model and lifecycle state machine | Everything depends on this |
| P0 | Job intake (create job) | Entry point for all workflows |
| P0 | Shared dispatcher dashboard | Primary visibility surface |
| P1 | Job assignment and scheduling | Core dispatch function |
| P1 | Technician field status updates | Closes the operational loop |
| P1 | Reassignment and rescheduling | Critical exception path |
| P2 | Overdue job highlighting and filtering | Operational hygiene |
| P2 | Customer notifications | Stakeholder communication |
| P2 | Proof-of-completion capture | Quality assurance |
| P3 | Concurrent assignment conflict handling | Edge case resilience |
| P3 | Scheduling overlap warnings | Edge case resilience |

---

## Dependencies

### Internal dependencies (phase-to-phase)

- **Phase 2 depends on Phase 1:** Dashboard and intake require the data model and lifecycle definitions.
- **Phase 3 depends on Phase 2:** Assignment requires jobs to exist and be visible in the dashboard.
- **Phase 4 depends on Phase 3:** Technician execution requires jobs to be assigned.
- **Phase 5 depends on Phase 4:** Customer notifications require job completion events; overdue handling requires the full lifecycle to be operational.

### Cross-cutting dependencies

- **UI usability constraint** (product_brief.constraints): The UI must be usable without training for non-technical dispatchers and technicians. This applies across Phases 2–5 and should be a continuous design consideration, not a phase-gated activity.
- **Notification infrastructure:** Phase 5 requires a notification emission mechanism. If an external notification service is used, integration work should be scouted during Phase 3–4 to avoid Phase 5 delays.
- **Technician availability state management:** Phase 3 surfaces availability; the mechanism for technicians to set their own availability (or for it to be derived from job state) needs to be decided during Phase 1 data model work.

---

## Risks / Watchouts

| Risk | Severity | Mitigation |
|------|----------|------------|
| **Single queue assumption may not hold** — If dispatch teams need separate queues per region, skill, or team, the data model may need partitioning. | Medium | Validate asmk_a2_single_queue early with stakeholders. Design the data model so adding a queue/team dimension is additive, not a rewrite. |
| **Concurrent assignment conflicts** — Two dispatchers assigning the same job simultaneously could cause confusion. | Low–Medium | Implement optimistic concurrency or clear last-write-wins behavior in Phase 3. |
| **Technician scheduling overlaps** — Without hard scheduling conflict prevention, dispatchers may double-book technicians. | Low–Medium | Surface scheduling warnings in Phase 3 UI. Hard prevention can be deferred but the data model should support overlap detection. |
| **Notification trigger ambiguity** — Source docs do not specify which status changes trigger customer notifications. | Low | Start with key milestones (assigned, en_route, completed). Make triggers configurable if feasible. |
| **Proof-of-completion scope creep** — Photos, signatures, and notes each have different implementation complexity. | Low | Start with text notes. Add photo/signature capture incrementally based on actual field needs. |
| **`scheduled` vs `intake` state ambiguity** — Source docs raise the question of whether `scheduled` is a distinct state or implied by having a time window set. | Low | Recommend treating `scheduled` as explicit (set when time window is confirmed) to keep the state machine unambiguous. |

---

## Recommended Next Steps

1. **Validate the single-queue assumption (asmk_a2_single_queue)** with the dispatch team before locking the data model. This is the highest-leverage assumption to confirm or bust early.
2. **Define the `scheduled` state semantics** — is it an explicit dispatcher action or implied by the presence of a time window? Resolve the open question from asmk_a3_job_lifecycle.
3. **Decide customer notification trigger points** — every status change or key milestones only? Resolve the open question from asmk_a12_customer_notifications.
4. **Begin Phase 1** — data model and lifecycle state machine. This is prerequisite to all other work and has no external dependencies.
5. **Scout notification infrastructure** during Phase 1–2 to de-risk Phase 5 integration.
6. **Establish a lightweight acceptance check** per phase exit criteria before proceeding to the next phase, to avoid rework cascades.

---

## Assumptions Reflected in This Plan

The following assumptions materially shape this delivery plan:

- **asmk_a1_internal_users** (high confidence): Primary users are dispatchers and technicians, not external customers. This keeps the UX focused on operational workflows.
- **asmk_a2_single_queue** (medium confidence): Single shared queue per team. If invalidated, Phase 1 data model needs queue partitioning.
- **asmk_a3_job_lifecycle** (medium confidence): Canonical lifecycle with `en_route` as a job-level state. Delivery phases are sequenced around this lifecycle.
- **asmk_a4_dispatcher_perms** (high confidence): Equal dispatcher permissions, no RBAC. Simplifies the authorization model across all phases.
- **asmk_a8_assignment** (high confidence): Dispatcher-only assignment authority. Shapes the Phase 3 and Phase 4 boundary.
- **asmk_a9_no_approval** (high confidence): No approval gates on reassignment. Keeps Phase 3 scope tight.
- **asmk_a10_overdue** (high confidence): Overdue visibility is passive filtering, not proactive alerting. Keeps Phase 5 scope bounded.
- **asmk_a12_customer_notifications** (medium confidence): Notification mechanism is opaque in v1. Phase 5 emits events; delivery channel is deferred.

Where confidence is medium, the plan notes the risk and recommends early validation.