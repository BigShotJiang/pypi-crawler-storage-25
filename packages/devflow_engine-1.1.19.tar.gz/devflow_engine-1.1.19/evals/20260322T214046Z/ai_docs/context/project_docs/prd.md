# Product Requirements Document (PRD)

## Product Overview

A field service job dispatch application that enables internal dispatch teams to capture, assign, schedule, and track field service jobs through a shared workflow. Dispatchers create and manage jobs from a centralized dashboard; field technicians receive assignments, update status from the field, and capture proof of completion. Customers are passive recipients of job status notifications.

The product replaces manual or fragmented job-tracking processes with a single shared system that provides operational visibility into job ownership, technician availability, schedule adherence, and overdue work.

---

## User Roles

### Dispatcher

Internal operator who creates, assigns, schedules, and monitors jobs. Has full authority over the entire job lifecycle in v1. All dispatchers share equal permissions — role distinction (e.g., manager vs. lead) is informational only. RBAC is explicitly out of scope.

**Key responsibilities:**
- Create new jobs with sufficient context for scheduling
- Set or confirm scheduled service time windows
- Assign and reassign jobs to technicians
- Monitor the shared job queue and dashboard
- Identify and act on overdue or stale jobs
- Reprioritize, reschedule, or reassign as conditions change

### Field Technician

Field worker who receives job assignments, travels to job sites, performs work, updates job status, and captures proof of completion. Technicians can update their own job status but **cannot** self-assign, reassign, or reschedule jobs.

**Key responsibilities:**
- Review assigned job details and route context
- Update job status through field execution stages (en_route → in_progress → completed)
- Capture proof of completion (notes, photos, signatures as applicable)

### Customer

Passive recipient of job confirmation and status notifications. Customers have no direct system access in v1. The notification delivery mechanism (email, SMS, push) is opaque and deferred to implementation.

> **Assumption [asmk_a1_internal_users]:** Primary users are internal dispatchers and field technicians, not external customers. Customers receive notifications only.

---

## Core User Journeys

### Journey 1: Job Intake

**Actor:** Dispatcher 
**Trigger:** New service request or follow-up work is identified. 
**Workflow key:** `wf_intake_job`

**Steps:**
1. Dispatcher opens the dispatch app and creates a new job record.
2. Dispatcher adds core job details: title, description, priority, and an optional scheduled service time window.
3. Dispatcher saves the job. It becomes visible in the shared dispatch queue with status **intake**.

**Result:** A trackable job exists in the shared system with status `intake`.

**Functional notes:**
- Jobs may be created without enough detail to assign confidently on the first pass (edge case). The system must allow saving partially detailed jobs.
- Scheduled service time window (scheduled_start, scheduled_end) is optional at intake.

### Journey 2: Schedule and Assign

**Actor:** Dispatcher 
**Trigger:** A job in `intake` or `scheduled` status needs a technician assignment. 
**Workflow key:** `wf_schedule_and_assign`

**Steps:**
1. Dispatcher reviews the open job queue or dispatcher dashboard.
2. Dispatcher sets or confirms the scheduled service time window on the job.
3. Dispatcher assigns the job to a technician based on availability and skill.
4. Job transitions to **assigned**; technician is notified.

**Result:** Job has a scheduled window, an assigned technician, and status `assigned`.

**Functional notes:**
- Assignment is a direct dispatcher action with no approval gate.
- Multiple dispatchers may attempt to assign the same unassigned job concurrently (edge case). The system should handle this gracefully — last-write-wins or optimistic locking, to be determined at implementation.
- A technician may have overlapping scheduled jobs if dispatch does not check availability (edge case). v1 does not enforce availability constraints automatically.

### Journey 3: Technician Field Execution

**Actor:** Field Technician 
**Trigger:** Technician receives an assigned job. 
**Workflow key:** `wf_technician_field_execution`

**Steps:**
1. Technician reviews assigned job details and route context.
2. Technician marks status **en_route** when traveling to the job site.
3. Technician marks status **in_progress** upon arrival and beginning work.
4. Technician captures proof of completion (notes, photos, signatures as applicable).
5. Technician marks job **completed**.

**Result:** Job is completed with proof of completion captured. Customer notification is triggered.

**Functional notes:**
- Status transitions follow the defined lifecycle: en_route → in_progress → completed.
- The technician-facing experience must be usable from the field (mobile-friendly).
- Proof-of-completion capture format is not fully specified in source docs — implementation should support at minimum notes, with photos and signatures as stretch.

---

## Functional Requirements

### FR-1: Job Creation

Dispatchers can create a new job with the following attributes:
- **Title** (required)
- **Description** (required)
- **Priority** (required)
- **Scheduled service time window** — `scheduled_start` and `scheduled_end` (optional at creation)

Jobs are created with initial status `intake` and appear immediately in the shared dispatch queue.

### FR-2: Job Assignment

Dispatchers can assign a job to a single technician. Assignment transitions the job to status `assigned` and triggers a notification to the technician.

- Each active job may be assigned to one technician.
- A technician can own many jobs simultaneously.
- Reassignment changes the assignment link directly without approval.

> **Assumption [asmk_a8_assignment]:** Dispatchers can assign and reassign jobs to technicians. Technicians cannot self-assign or reassign.

### FR-3: Job Status Tracking

The system tracks jobs through a defined lifecycle:

| Status | Description |
|---|---|
| `intake` | Job created, not yet scheduled or assigned |
| `scheduled` | Service time window set, not yet assigned |
| `assigned` | Technician assigned, awaiting field execution |
| `en_route` | Technician traveling to job site |
| `in_progress` | Technician on site, work underway |
| `completed` | Job finished, proof of completion captured |
| `cancelled` | Terminal state, reachable from any pre-completed status |

> **Assumption [asmk_a3_job_lifecycle]:** Job lifecycle follows intake → scheduled → assigned → en_route → in_progress → completed, with cancelled as a terminal state reachable from any pre-completed status.

> **Open question:** Is `scheduled` a distinct state from `intake`, or is it implied by having a time window set? Source docs list it as a distinct status, so the system should treat it as such.

### FR-4: Shared Dispatcher Dashboard

A shared dashboard view showing all jobs and their current state. All dispatchers see the same queue.

- Dashboard shows job ownership (assigned technician), status, priority, and scheduled time window.
- Dashboard supports filtering or highlighting overdue jobs (jobs past their scheduled time window that are not `completed` or `cancelled`).

> **Assumption [asmk_a2_single_queue]:** A single shared job queue per dispatch team is sufficient for the first release.

### FR-5: Overdue Job Visibility

Jobs whose scheduled time has passed and whose status is not `completed` or `cancelled` are surfaced as overdue in the shared dashboard view.

- Overdue identification is via dashboard filter or visual highlight.
- Proactive push alerts and SLA escalation are **out of scope**.

> **Assumption [asmk_a10_overdue]:** Overdue job visibility via dashboard filter is in scope; proactive push alerts and SLA escalation are not.

### FR-6: Technician Status Updates

Technicians can update the status of their assigned jobs from the field:
- Mark `en_route` when departing for job site
- Mark `in_progress` when arriving and beginning work
- Mark `completed` when work is finished

Technicians can capture proof of completion (notes, photos, signatures as applicable).

### FR-7: Customer Notifications

Basic customer notifications are triggered by job status changes.

- Notifications cover job confirmation and status updates.
- The notification delivery mechanism is opaque in v1.

> **Assumption [asmk_a12_customer_notifications]:** Customer notifications are triggered by job status changes, but the delivery mechanism is opaque in v1.

> **Open questions from source docs:**
> - What triggers a customer notification — every status change or only key milestones (assigned, en_route, completed)?
> - Is notification delivery email, SMS, or push? Deferred to implementation.

### FR-8: Job Cancellation

Jobs can be cancelled from any pre-completed status. Cancellation is a terminal state. Only dispatchers can cancel jobs (implied by dispatcher authority model).

---

## Alternate / Exceptional Flows

### Alt-1: Reassign or Reschedule a Job

**Workflow key:** `wf_reschedule_job` 
**Actor:** Dispatcher 
**Trigger:** Original technician is unavailable, overloaded, or was assigned in error.

**Steps:**
1. Open the job from the queue or dashboard.
2. Change the assigned technician or update the scheduled time window.
3. Optionally add a note explaining the reassignment reason.

**Result:** Job ownership or schedule is updated; previous and new assignments are recorded.

> **Assumption [asmk_a9_no_approval]:** Reassignment and rescheduling are direct dispatcher actions with no approval gate in v1.

### Alt-2: Handle Overdue Jobs

**Workflow key:** `wf_handle_overdue_job` 
**Actor:** Dispatcher 
**Trigger:** Job scheduled time has passed and status is not `completed` or `cancelled`.

**Steps:**
1. Identify overdue jobs via the dashboard filter or overdue highlight.
2. Review blocked or stale jobs and decide: reprioritize, reassign, or update schedule.
3. Update the job accordingly.

**Result:** Overdue job has a current owner, updated priority or schedule, and is no longer stale.

---

## Acceptance-Oriented Behavior Notes

These notes capture behavior expectations that should inform acceptance criteria for downstream implementation.

1. **Dispatchers can create a job, assign a technician, and schedule a service window without leaving the product.** The end-to-end intake-to-assignment flow must be completable within the application.

2. **Dispatchers can see who owns each job and which jobs are unassigned or overdue.** The dashboard must clearly show assignment state and overdue status.

3. **Technicians can view assigned jobs, update status, and capture completion from the field.** The technician experience must support mobile/field use.

4. **The dispatch team can review the current job queue from a shared dashboard view.** All dispatchers see the same real-time view of the queue.

5. **The UI should be usable without training for non-technical dispatchers and field technicians.** Simplicity is a hard constraint.

6. **Concurrent assignment attempts** by multiple dispatchers should not produce silent data corruption. The system should handle this edge case gracefully.

7. **Technician overlapping schedules** are possible in v1 since the system does not enforce availability constraints automatically. This is a known limitation.

8. **Jobs created with insufficient detail** must still be saveable and visible in the queue for later enrichment before assignment.

---

## Assumptions

The following assumptions materially shape this PRD. They are sourced from the canonical assumptions registry and reflected where relevant throughout this document.

| ID | Assumption | Confidence |
|---|---|---|
| asmk_a1_internal_users | Primary users are internal dispatchers and field technicians, not external customers. | High |
| asmk_a2_single_queue | A single shared job queue per dispatch team is sufficient for v1. | Medium |
| asmk_a3_job_lifecycle | Job lifecycle follows intake → scheduled → assigned → en_route → in_progress → completed, with cancelled as terminal. | Medium |
| asmk_a4_dispatcher_perms | Dispatchers share equal permissions in v1; RBAC is out of scope. | High |
| asmk_a5_job_statuses | Job statuses are the defined set: intake, scheduled, assigned, en_route, in_progress, completed, cancelled. | Medium |
| asmk_a6_due_dates | Scheduled service time windows are a job-level attribute. | High |
| asmk_a7_dispatcher_persona | Manager/lead is a persona distinction, not a permission boundary in v1. | High |
| asmk_a8_assignment | Dispatchers assign/reassign; technicians cannot self-assign or reassign. | High |
| asmk_a9_no_approval | Reassignment and rescheduling have no approval gate in v1. | High |
| asmk_a10_overdue | Overdue visibility via dashboard; proactive alerts out of scope. | High |
| asmk_a11_sparse_workflow | Alternate flows limited to reschedule/reassign and overdue handling. | High |
| asmk_a12_customer_notifications | Notifications triggered by status changes; delivery mechanism opaque. | Medium |

### Explicitly Out of Scope

- Advanced workforce planning beyond job assignment and tracking
- Fully custom reporting outside the core workflow views
- External customer-facing access or self-service portals
- Role-based access control or permission enforcement
- Proactive SLA alerting or escalation systems
- Invoicing, payroll, or billing

---

## Source Grounding Notes

This PRD is grounded primarily in `product_brief.json`, `user_workflows.json`, and `assumptions_registry.json`, with supporting entity/relationship context from `domain_entities.json`. All user journeys trace directly to defined workflows in `user_workflows.json`. Functional requirements trace to `product_brief.json` scope items and `domain_entities.json` attributes. Where source evidence is thin (e.g., notification trigger specifics, proof-of-completion format), this is noted explicitly rather than fabricated.