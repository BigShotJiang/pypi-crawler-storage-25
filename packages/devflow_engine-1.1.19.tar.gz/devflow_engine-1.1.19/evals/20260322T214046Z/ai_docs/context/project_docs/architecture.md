# Architecture

## System Overview

The field service dispatch system is an internal operations tool that enables dispatchers to create, schedule, assign, and track field service jobs, and enables technicians to receive assignments, update job status, and capture proof of completion from the field. Customers are passive notification recipients only.

The system centers on a **shared job queue** managed by a dispatch team. All dispatchers share equal authority over all jobs (no RBAC in v1). The core operational loop is: intake → schedule → assign → field execution → completion, with reassignment and overdue handling as the primary exception paths.

Architecturally, the system is a workflow-driven CRUD application with event-triggered notifications. The data model is intentionally simple: four entities (Job, Technician, Dispatcher, Customer) with well-defined lifecycle states and ownership rules.

---

## Core Entities / Data Model

### Job

The central entity. Represents a field service task that moves through a defined lifecycle.

| Attribute | Type | Notes |
|---|---|---|
| `id` | UUID | Primary key |
| `title` | string | Required |
| `description` | text | Required |
| `status` | enum | `intake`, `scheduled`, `assigned`, `en_route`, `in_progress`, `completed`, `cancelled` |
| `priority` | enum | Values TBD; used for queue ordering and overdue triage |
| `scheduled_start` | datetime | Service time window start |
| `scheduled_end` | datetime | Service time window end |
| `assigned_technician_id` | FK → Technician | Nullable; set on assignment |
| `created_by_dispatcher_id` | FK → Dispatcher | Set on creation |
| `customer_id` | FK → Customer | Associated notification recipient |
| `created_at` | datetime | Immutable |
| `updated_at` | datetime | Auto-updated |

**Lifecycle states:**

```
intake → scheduled → assigned → en_route → in_progress → completed
                                                          ↑
         cancelled ← reachable from any pre-completed status
```

- `intake`: Job created, not yet scheduled or assigned.
- `scheduled`: Time window set, no technician assigned yet.
- `assigned`: Technician assigned; technician notified.
- `en_route`: Technician traveling to job site.
- `in_progress`: Technician on site, work underway.
- `completed`: Work finished, proof of completion captured.
- `cancelled`: Terminal state, reachable from any pre-completed status.

**Open question:** Whether `scheduled` is a distinct persisted state or implied by having `scheduled_start`/`scheduled_end` set. Source docs treat it as an explicit state; the implementation should follow suit unless there is a strong reason to collapse it.

### Technician

Represents a field worker who executes jobs on site.

| Attribute | Type | Notes |
|---|---|---|
| `id` | UUID | Primary key |
| `name` | string | Required |
| `role` | string | Informational only in v1 |
| `availability_state` | enum | `available`, `en_route`, `on_site`, `unavailable` |

Technician `availability_state` is a derived/secondary signal. The canonical tracking point for job progress is the **job's** status, not the technician's state. Technician `en_route` and `on_site` are informational reflections of the technician's current activity and may be derived from the status of their active job(s).

### Dispatcher

Represents an internal operator who manages the job queue.

| Attribute | Type | Notes |
|---|---|---|
| `id` | UUID | Primary key |
| `name` | string | Required |
| `role` | string | Informational only in v1 |

All dispatchers share equal permissions. There is no permission boundary or approval hierarchy in v1. RBAC is explicitly out of scope.

### Customer

Represents the party receiving field service. Passive only in v1.

| Attribute | Type | Notes |
|---|---|---|
| `id` | UUID | Primary key |
| `name` | string | Required |
| `contact_info` | structured/text | Details TBD; must support whatever notification channel is chosen |

Customers have no direct system access. They receive notifications triggered by job status changes.

---

## Key Relationships

### Job → Technician (`job_assigned_to_technician`)

- Each active job may be assigned to **one** technician.
- A technician can own **many** jobs (one-to-many from technician perspective).
- Reassignment changes this link directly **without an approval gate**.
- Unassigned jobs have a null technician reference.

### Job → Dispatcher (`job_created_by_dispatcher`)

- Jobs are created by dispatchers.
- Any dispatcher can manage any job in v1 — the `created_by` field is an audit trail, not an ownership boundary.

### Job → Customer (`job_for_customer`)

- Each job is associated with one customer.
- The customer receives status notifications.
- The customer entity is passive; this relationship exists primarily to support notification routing.

### Ownership Rules

1. Dispatchers have full authority to create, assign, reschedule, and track jobs.
2. Technicians update their own job status and capture completion but **cannot** reassign or reschedule jobs.
3. Any dispatcher can manage any job; role-based restrictions are deferred to post-v1.

---

## Components / Surfaces

The source docs imply the following system surfaces. The exact technology choices are not specified in source docs and are left to implementation.

### Dispatcher Dashboard

- Shared view of all jobs and their current state.
- Supports filtering/highlighting of overdue jobs (jobs past `scheduled_end` that are not `completed` or `cancelled`).
- Supports job creation, assignment, scheduling, reassignment, and rescheduling.
- Must be usable without training for non-technical dispatchers.

### Technician Field Interface

- View of assigned jobs with route/job details.
- Status update capability: `assigned` → `en_route` → `in_progress` → `completed`.
- Proof-of-completion capture (notes, photos, signatures as applicable).
- Must be usable from the field (implies mobile-friendly or mobile-native).

### Notification Service

- Triggered by job status changes.
- Sends notifications to customers.
- The notification delivery mechanism is **opaque in v1** — source docs explicitly defer the channel choice (email, SMS, push).
- Open questions: Which status transitions trigger notifications? Source docs suggest at minimum job confirmation and status changes, but do not specify whether every transition or only key milestones (`assigned`, `en_route`, `completed`) trigger a notification.

### Job Queue / Workflow Engine

- A single shared job queue per dispatch team is the assumed model for v1.
- Jobs flow through the defined lifecycle states.
- State transitions should be validated (e.g., a job cannot move from `intake` directly to `completed`).

---

## Integrations

Source docs do not specify external integrations for v1. The system is self-contained with the following integration surface implied:

- **Notification delivery**: Some outbound integration will be needed to deliver customer notifications. The mechanism is deferred, but the system must emit notification events on relevant status changes.
- **Proof-of-completion storage**: Photos, signatures, and notes captured by technicians imply some form of file/media storage.

Explicitly **out of scope** for v1:
- Invoicing, payroll, or billing integrations.
- External customer-facing portals or APIs.
- Advanced analytics or reporting integrations.
- Workforce planning or resource optimization systems.

---

## Constraints / Risks

### Constraints

1. **Simple data model**: The first release should keep the data model simple enough for dependable job creation, assignment, scheduling, and status tracking. Avoid premature complexity.
2. **Usability without training**: The UI must be usable by non-technical dispatchers and field technicians without training. This constrains the interaction complexity of both surfaces.
3. **Equal dispatcher permissions**: No RBAC in v1. All dispatchers are functionally identical from a permissions standpoint.
4. **Single shared queue**: One job queue per dispatch team. No partitioning, priority lanes, or team-scoped queues.

### Risks

1. **Concurrent assignment conflict**: Multiple dispatchers may attempt to assign the same unassigned job simultaneously. The system needs an optimistic locking or conflict resolution strategy to prevent double-assignment. Source docs identify this as an edge case but do not prescribe a solution.
2. **Overlapping technician schedules**: A technician may receive overlapping scheduled jobs if dispatchers do not check availability. The system should surface technician workload/availability but source docs do not require hard enforcement in v1.
3. **Incomplete job creation**: Jobs may be created without enough detail to assign confidently on the first pass. The system should support jobs sitting in `intake` without requiring all fields upfront.
4. **Notification channel ambiguity**: The notification mechanism is deferred. This is a known gap that will need resolution before implementation. The architecture should isolate notification dispatch behind an interface so the channel can be chosen later without structural changes.
5. **Overdue detection is passive**: Overdue visibility is via dashboard filter only. There are no proactive push alerts or SLA escalation mechanisms in v1. Jobs could go stale if dispatchers do not actively monitor the dashboard.

---

## Open Architectural Assumptions

The following assumptions from source docs materially shape architectural decisions:

| ID | Assumption | Confidence | Architectural Impact |
|---|---|---|---|
| `asmk_a1_internal_users` | Primary users are internal dispatchers and technicians, not external customers | High | No public-facing API or auth flow needed in v1 |
| `asmk_a2_single_queue` | Single shared job queue per dispatch team | Medium | No multi-tenancy or queue partitioning needed, but should be easy to add later |
| `asmk_a3_job_lifecycle` | Job lifecycle: intake → scheduled → assigned → en_route → in_progress → completed; cancelled from any pre-completed state | Medium | State machine must enforce valid transitions; `scheduled` vs `intake` distinction needs implementation decision |
| `asmk_a4_dispatcher_perms` | All dispatchers share equal permissions; RBAC out of scope | High | No authorization layer beyond authentication needed in v1 |
| `asmk_a5_job_statuses` | Job statuses are a defined enum set | Medium | Status field should be a constrained enum, not free text |
| `asmk_a6_due_dates` | Scheduled time windows are job-level attributes | High | `scheduled_start`/`scheduled_end` on job entity; no separate scheduling entity needed |
| `asmk_a8_assignment` | Dispatchers assign/reassign; technicians cannot self-assign | High | Write authorization on assignment must be scoped to dispatcher role |
| `asmk_a9_no_approval` | Reassignment/rescheduling has no approval gate | High | No workflow approval engine needed; direct mutations allowed |
| `asmk_a12_customer_notifications` | Notifications triggered by status changes; delivery mechanism opaque | Medium | Architect a notification event emitter; defer delivery channel implementation |

Where source grounding is thin — particularly around notification triggers, proof-of-completion data model, and technician availability enforcement — the architecture leaves room for implementation decisions without prescribing specifics unsupported by source evidence.