# Project Charter

## Overview

This project delivers a lightweight internal task management application that lets the team create tasks, assign them to staff members, and track progress through a shared view. It replaces an unclear or manual work-tracking process with a single, reliable tool for capturing ownership and status across the team.

## Problem / Opportunity

The team is handling work through an unclear or manual process, making ownership and progress hard to track. Without a shared system, it is difficult to know who owns what, which work is in progress, and what has fallen behind. This lack of visibility creates coordination friction for both operators doing the work and managers responsible for overseeing it.

The opportunity is to provide a simple, shared workflow tool that makes task ownership, status, and overdue items immediately visible—improving day-to-day operational reliability before pursuing more advanced analytics or automation.

## Target Users

- **Internal staff** — team members who perform and complete assigned tasks. These users need a fast, low-friction way to see their assignments and update status.
- **Managers / leads** — team members who create tasks, assign ownership, and monitor progress. These users need visibility into task state, ownership gaps, and overdue items.

All users are internal. External customers are explicitly not served by this product in v1. The distinction between staff and manager is a persona distinction for understanding needs—it is not a permission boundary. All users share equal permissions in v1 (assumption: `A_single_actor_type`, `A6_softened`).

## Goals

1. **Reliable shared workflow** — Create a lightweight shared workflow so the team can capture, assign, and complete work reliably, without falling back to ad-hoc tracking.
2. **Manager visibility** — Give managers clear visibility into task ownership, current status, and overdue items so they can intervene early when work stalls or is unassigned.

## Scope

### In Scope

- Task creation with a title, description, and assignee.
- Assignment of tasks to individual staff members.
- Status tracking through a simple lifecycle: created → assigned → in-progress → done (assumption: `A_simple_lifecycle`, `A_simple_status_model`).
- A shared dashboard view showing all tasks and their current state.
- Filtering or highlighting overdue tasks in the shared view (assumption: `A4_open` — overdue visibility is via dashboard filter; proactive push alerts are not in scope).

### Out of Scope

- Advanced workforce planning beyond task assignment and tracking.
- Fully custom reporting outside the core workflow views.
- External customer-facing access or self-service portals.
- Role-based access control or permission enforcement (deferred; assumption: `A_single_actor_type`).
- Proactive notification or alerting systems.

## Non-Goals

- Replace every surrounding back-office process in the first release. The product is tightly scoped to task creation, assignment, and tracking.
- Optimize for external customer self-service. This is an internal staff tool.
- Build advanced analytics, charting, or resource-planning features. The focus is operational visibility, not reporting.

## Constraints

- **Simple data model** — The first release should keep the data model simple enough for dependable task creation, assignment, and status tracking. A single shared task queue is sufficient (assumption: `A_single_queue`).
- **Usability without training** — The UI should be usable without training for non-technical staff.
- **Flat permission model** — All staff share equal permissions in v1; role distinction is informational only. Any staff member can assign and reassign tasks; role-based restrictions and approval gates are deferred (assumptions: `A_single_actor_type`, `A2_replaced`, `A7_replaced`).
- **Limited alternate flows** — Alternate flows are limited to reassignment and overdue handling until further clarification (assumption: `A_sparse_workflow`).

## Success Criteria

1. Staff can create a task, assign an owner, and update status without leaving the product.
2. Managers can see who owns each task and which work is unassigned or overdue.
3. The team can review the current work queue from a shared dashboard view.

## Assumptions Shaping This Charter

| ID | Assumption | Status |
|---|---|---|
| `A_internal_users` | Primary users are internal staff and managers, not external customers. | Resolved — keep |
| `A_single_queue` | A single shared task queue is sufficient for the first release. | Resolved — keep |
| `A_simple_lifecycle` | Task lifecycle is simple: created → assigned → in-progress → done. | Resolved — keep |
| `A_single_actor_type` | All users share a single 'staff' permission level for v1; RBAC is out of scope. | Resolved — keep |
| `A_simple_status_model` | Task statuses are a small fixed set (created, assigned, in_progress, completed). | Resolved — keep |
| `A9` | Due dates are a task-level attribute. | Resolved — keep |
| `A6_softened` | Manager/lead is a persona distinction, not a permission boundary in v1. | Resolved — softened |
| `A2_replaced` | Any staff member can assign and reassign tasks. Role-based restrictions deferred. | Resolved — replaced |
| `A7_replaced` | Reassignment is a direct staff action with no approval gate in v1. | Resolved — replaced |
| `A4_open` | Overdue visibility via dashboard filter is in scope; proactive push alerts are not. | Resolved — scoped down |
| `A_sparse_workflow` | Alternate flows limited to reassignment and overdue handling until clarified. | Resolved — keep |

These assumptions are all currently resolved and supported by source evidence. No material gaps or contradictions were identified between the product brief and the assumptions registry for charter-level concerns.
