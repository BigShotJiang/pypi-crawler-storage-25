# Architecture

## System Overview

The system is a lightweight internal task management application designed for a small team of staff members (including managers and leads as a persona distinction, not a permission boundary). It provides a shared workspace where staff can create tasks, assign them to individuals, track progress through a simple lifecycle, and surface overdue work.

The architecture is shaped by several governing constraints:
- A single shared task queue serves all users (assumption A_single_queue).
- All users operate at a single permission level; there is no role-based access control in v1 (assumption A_single_actor_type).
- The task lifecycle is a small fixed set: created → assigned → in_progress → completed (assumptions A_simple_lifecycle, A_simple_status_model).
- The system is internal-facing; there is no external customer access (assumption A_internal_users).

Given these constraints, the system can be realized as a standard web application with a relational data store, a server-side API layer, and a browser-based frontend. No complex authorization framework, event bus, or async pipeline is required for v1.

---

## Core Entities / Data Model

### Task

The central domain object. Represents a unit of work the team needs to complete and track.

| Attribute    | Type          | Notes |
|-------------|---------------|-------|
| id          | UUID / PK     | System-generated identifier |
| title       | string        | Required. Short label for the task |
| description | text          | Optional. Longer context for the work |
| status      | enum          | One of: `created`, `assigned`, `in_progress`, `completed` |
| priority    | enum or int   | Relative priority; exact scale TBD but must support sorting |
| due_date    | date/datetime | Optional. Used to derive overdue status |
| created_at  | datetime      | System-set on creation |
| updated_at  | datetime      | System-set on every mutation |
| assignee_id | FK → Assignee | Nullable. Null when task is unassigned |

Lifecycle transitions:
- `created` → `assigned` (when assignee_id is set)
- `assigned` → `in_progress` (when work begins)
- `in_progress` → `completed` (when work is done)
- Reassignment does not reset status; it changes assignee_id while preserving current status.

The lifecycle is intentionally simple. There is no `blocked`, `cancelled`, or `reopened` state in v1. If a task is overdue, that is derived from `due_date < now AND status ≠ completed`, not stored as a separate status.

### Assignee

Represents an internal person who can own tasks.

| Attribute         | Type      | Notes |
|------------------|-----------|-------|
| id               | UUID / PK | System-generated identifier |
| name             | string    | Display name |
| role             | string    | Informational only in v1 (e.g., "manager", "staff"). Not used for permission gating |
| availability_state | enum    | Optional. Could support basic availability signaling (e.g., available, away) |

The role field exists for display and filtering purposes but carries no authorization weight. Any staff member can perform any action (assumption A2_replaced, A_single_actor_type).

---

## Key Relationships

### Task → Assignee (many-to-one)

Each active task may be assigned to at most one current owner. An assignee can own many tasks. The relationship is represented by `assignee_id` on the Task entity.

Reassignment changes this foreign key directly. Per assumption A7_replaced, there is no approval gate on reassignment—it is a direct staff action. The system should record the previous assignee (either via an audit log or a reassignment history table) to support the workflow requirement that "previous and new assignee are recorded" (wf_reassign_task).

**Concurrency consideration:** The edge case of multiple staff attempting to assign themselves to the same unassigned task concurrently (from user_workflows.json edge_cases) should be handled at the data layer. A simple optimistic concurrency control (e.g., version column or conditional update `WHERE assignee_id IS NULL`) is sufficient for v1 given the small team size.

---

## Components / Surfaces

### API Layer

A server-side API exposing CRUD operations on tasks and assignees, plus query endpoints for the dashboard.

Key endpoints (conceptual):
- `POST /tasks` — create a task (status defaults to `created`)
- `GET /tasks` — list/filter tasks (supports status, assignee, overdue filters)
- `PATCH /tasks/:id` — update task fields (status, assignee, priority, due_date)
- `GET /assignees` — list available assignees
- `GET /tasks/overdue` — convenience query: tasks where `due_date < now AND status ≠ completed`

Since there is no RBAC in v1, the API does not enforce per-user permissions beyond basic authentication (confirming the caller is a known staff member).

### Frontend / Dashboard

A browser-based shared view that serves as the primary interaction surface. Must support:
- Viewing all tasks in a queue/list format with current status and owner
- Creating new tasks inline or via a form
- Assigning/reassigning tasks to staff members
- Updating task status
- Filtering or highlighting overdue tasks (product_brief success_criteria[1], scope item)
- Sorting/filtering by priority, status, assignee

The UI should be usable without training for non-technical staff (product_brief constraint).

### Data Store

A relational database (e.g., PostgreSQL, SQLite for early development). The data model is simple enough that a single-database, single-schema approach is appropriate. No read replicas, caching layers, or search indexes are needed for v1.

---

## Integrations

No external integrations are in scope for v1. The system is self-contained:
- No SSO or external identity provider is required (though basic authentication is assumed).
- No notification system (email, Slack, push) — proactive alerts are explicitly out of scope (assumption A4_open, product_brief out_of_scope).
- No external reporting or analytics platform.
- No import/export or API consumption by other systems.

This is a deliberate scope decision. The architecture should not prematurely introduce integration points, but the API-first design leaves room for future integrations without structural changes.

---

## Constraints / Risks

### Constraints
1. **Single permission tier.** All staff share equal permissions. The system must not accidentally introduce permission-gated behavior. This simplifies the architecture but means any user can modify any task — acceptable for a small trusted team.
2. **Simple lifecycle only.** No custom statuses, no state machine configuration. The four-state lifecycle is hardcoded for v1.
3. **No notifications.** Overdue visibility is passive (dashboard filter), not active (push/email). Managers must check the dashboard to see overdue work.
4. **Internal-only access.** No public-facing endpoints, no multi-tenancy, no customer data isolation concerns.

### Risks
1. **Concurrent assignment contention.** Multiple staff claiming the same unassigned task. Mitigation: optimistic locking at the data layer. Low probability given small team size.
2. **Overdue tasks going unnoticed.** Without proactive notifications, overdue tasks rely on someone checking the dashboard. Mitigation: make the overdue filter prominent and defaulted-on in the dashboard view.
3. **Reassignment history loss.** If reassignment simply overwrites `assignee_id` without logging, the "previous assignee recorded" requirement from wf_reassign_task is not met. Mitigation: implement a lightweight task_history or audit_log table.
4. **Role field ambiguity.** The assignee `role` field is informational but could be mistaken for an authorization mechanism. Mitigation: clearly document and label it as display-only.

---

## Open Architectural Assumptions

1. **Authentication mechanism is unspecified.** The source docs confirm internal-only users and no RBAC, but do not specify how users authenticate. A simple session-based auth or shared credentials approach is assumed for v1. This should be clarified before implementation.
2. **Reassignment audit granularity.** The workflow requires recording previous and new assignee on reassignment. Whether this is a full audit log (all field changes) or a narrow reassignment log is an open design choice.
3. **Priority scale.** Priority is listed as a task attribute but the source docs do not define the scale (numeric 1–5? enum of low/medium/high/critical?). Architecture assumes an enum or small integer; exact values should be defined in the PRD.
4. **Availability state usage.** The assignee entity includes `availability_state` but no workflow explicitly consumes it for routing or gating. It may be display-only in v1.
5. **Due date semantics.** Whether due_date is a date (end of day) or a datetime (specific deadline) is not specified. Architecture assumes date-level granularity is sufficient.
6. **Deployment topology.** Source docs do not specify deployment constraints. A single-server deployment is assumed for v1 given the internal, small-team context.

---

*This document is grounded in the canonical source docs (domain_entities.json, product_brief.json, user_workflows.json, assumptions_registry.json) as of the current source-doc state. Where the architecture elaborates beyond source evidence, assumptions are surfaced explicitly above.*