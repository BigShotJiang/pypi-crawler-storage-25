# UX Design

## UX Overview

This document describes the user experience design for a lightweight internal task management application. The product serves a single user type—**Staff Member**—who may act as either a task performer or a manager/lead. The distinction between these personas is informational only; there is no permission boundary in v1 (assumption A_single_actor_type, A6_softened).

The UX is shaped by three core product goals:
1. Let any staff member capture, assign, and complete tasks without leaving the product.
2. Give managers visibility into task ownership, status, and overdue items.
3. Provide a shared dashboard view of the current work queue.

The interface must be usable without training for non-technical staff (product_brief constraint). All interactions assume a flat permission model—every staff member can create, assign, reassign, and update any task.

---

## Primary User Flows

### Flow 1: Capture a New Task (`wf_capture_task`)

**Trigger:** A staff member identifies new work or a follow-up request.

**Steps:**
1. From the shared dashboard, the user clicks a prominent "New Task" action.
2. A task creation form appears with fields: **Title** (required), **Description** (optional but encouraged), **Priority** (selectable, e.g. low/medium/high), **Due Date** (optional date picker), and **Assignee** (optional, can be left unassigned).
3. The user fills in the relevant fields and saves.
4. The new task appears in the shared queue with status `created`.

**Result:** A trackable task exists in the system and is visible to all staff.

### Flow 2: Assign and Track a Task (`wf_assign_and_track_task`)

**Trigger:** A task needs an owner or a status update.

**Steps:**
1. The user opens the shared dashboard and reviews open tasks.
2. The user selects a task to view its detail panel or detail page.
3. The user assigns (or changes) the task owner by selecting a staff member from an assignee picker.
4. As work progresses, the assignee (or any staff member) updates the task status through the lifecycle: `created` → `assigned` → `in_progress` → `completed`.
5. The dashboard reflects the updated status in real time or on refresh.

**Result:** Each active task has a visible owner and current status.

### Flow 3: Reassign a Task (`wf_reassign_task`)

**Trigger:** The original assignee is unavailable, overloaded, or was assigned in error.

**Steps:**
1. The user opens the task from the queue or dashboard.
2. The user changes the assignee to a different staff member using the same assignee picker.
3. Optionally, the user adds a note explaining the reassignment reason.
4. The system records the change (previous and new assignee).

**Result:** Task ownership is transferred. No approval gate is required (assumption A7_replaced, A2_replaced).

### Flow 4: Handle Overdue Tasks (`wf_handle_overdue_task`)

**Trigger:** A task's due date has passed and its status is not `completed`.

**Steps:**
1. The user applies the overdue filter or scans the overdue highlight on the dashboard.
2. The user reviews each overdue task to assess whether it is blocked, stale, or simply late.
3. The user takes one or more corrective actions: reprioritize, reassign to a different owner, or update the due date.
4. The task is updated accordingly and the overdue indicator clears once the due date is current or the task is completed.

**Result:** Overdue tasks are surfaced, triaged, and moved forward.

---

## Key Screens / Views

### 1. Shared Task Dashboard

**Purpose:** The primary landing screen. Provides a single shared view of all tasks and their current state.

**Layout and content:**
- A table or card-based list of all tasks showing: title, assignee (or "Unassigned"), status, priority, and due date.
- Visual status indicators (e.g. color-coded badges for `created`, `assigned`, `in_progress`, `completed`).
- Overdue highlight: tasks past their due date and not completed are visually flagged (e.g. red text, warning icon, or colored row background).
- Filter/sort controls: filter by status, assignee, priority, and overdue. Sort by due date, priority, or creation date.
- A prominent "New Task" button accessible from this screen at all times.

**Design notes:**
- This is the view that satisfies the success criterion: "The team can review the current work queue from a shared dashboard view."
- The overdue filter specifically supports: "Managers can see who owns each task and which work is unassigned or overdue."
- There are no role-based view restrictions. All staff see the same dashboard.

### 2. Task Detail View

**Purpose:** Full view of a single task for reading, editing, and status updates.

**Layout and content:**
- Header: task title (editable inline or via edit mode).
- Fields: description, status (with transition controls), priority, assignee (picker), due date (date picker), created_at (read-only), updated_at (read-only).
- Status transition: a clear control (e.g. dropdown or button group) to move the task through its lifecycle. Only forward transitions should be prominent, but backward transitions (e.g. `in_progress` → `assigned`) should be available if the user needs to correct status.
- Reassignment: changing the assignee is a direct edit on this screen—no separate approval flow.
- Optional notes/context area for reassignment reasons or status update context.

**Design notes:**
- The detail view must support the full task lifecycle and both primary and alternate flows.
- The "save" action should be clear and provide confirmation feedback.

### 3. Task Creation Form

**Purpose:** Focused interface for capturing a new task.

**Layout and content:**
- Title field (required, with validation).
- Description field (multi-line text, optional).
- Priority selector (e.g. low / medium / high).
- Due date picker (optional).
- Assignee picker (optional; task can be saved as unassigned).
- Save and Cancel actions.

**Design notes:**
- Could be implemented as a modal overlay on the dashboard or a dedicated page. A modal is likely sufficient given the small number of fields, and keeps the user in context.
- After save, the user should be returned to the dashboard with the new task visible.

---

## Important Interactions

### Status Transitions
- The task lifecycle is a fixed, small set: `created` → `assigned` → `in_progress` → `completed`.
- The UX should make the current status and available next transitions obvious.
- A task moves to `assigned` when an assignee is set (this could be automatic or manual).
- Completing a task should feel deliberate (e.g. a confirmation or a distinct "Mark Complete" action) to prevent accidental closure.

### Assignee Selection
- The assignee picker should show available staff members by name.
- Unassigned tasks should be clearly distinguishable in the dashboard (e.g. "Unassigned" label or empty avatar placeholder).
- Reassignment is the same interaction as initial assignment—change the picker value. The system records the change.

### Overdue Visibility
- Overdue state is a computed display concern: `due_date < today AND status ≠ completed`.
- The dashboard should support both a dedicated overdue filter and a persistent visual highlight so overdue items are noticeable even without filtering.
- Overdue visibility is passive (dashboard filter/highlight). Proactive push alerts and notifications are explicitly out of scope (assumption A4_open).

### Filtering and Sorting
- The dashboard should support filtering by: status, assignee, priority, and overdue.
- Sorting by due date, priority, and creation date should be available.
- Filters should be combinable (e.g. "show me all high-priority tasks assigned to Jane that are overdue").

---

## Edge / Error Experiences

### Incomplete Task Creation
- Tasks may be created without enough detail to assign confidently (source: edge_cases).
- **UX response:** Title is required; description is strongly encouraged but optional. The system allows saving a minimal task. The dashboard should make sparse tasks visible (e.g. missing description or no assignee) so they can be enriched later.

### Concurrent Assignment Contention
- Multiple staff may attempt to assign themselves to the same unassigned task concurrently (source: edge_cases).
- **UX response:** The system should apply last-write-wins or optimistic concurrency. If a user saves an assignment and the task was already assigned by someone else in the interim, the UI should show an informational message (e.g. "This task was just assigned to [Name]. Your change has been saved and overwrites the previous assignment.") rather than silently failing. The exact conflict resolution strategy is an architectural concern, but the UX should surface the outcome clearly.

### Overdue Tasks Without Clear Resolution
- A task may be overdue and have no assignee, or the assignee may be unavailable.
- **UX response:** The overdue filter surfaces these. The user can reassign or update the due date directly. There is no automated escalation in v1—resolution is manual via the dashboard.

### Blocked or Stale Tasks
- Tasks can become blocked or stale with no explicit "blocked" status in the v1 lifecycle.
- **UX response:** Since the status model is fixed at four states (assumption A_simple_status_model), blocked tasks remain in `in_progress` or `assigned`. The user can update priority, adjust the due date, or add a note to signal the blocked state. A dedicated "blocked" status is not in scope for v1.

### Validation Errors
- If a user attempts to save a task without a title, the form should show an inline validation error and prevent submission.
- Date picker should prevent selecting past dates for new task due dates (optional UX enhancement; not source-mandated).

---

## UX Assumptions

| Assumption | Source | Impact on UX |
|---|---|---|
| All users share a single 'staff' permission level (A_single_actor_type) | assumptions_registry | No role-based UI gating. Every screen and action is available to every user. |
| Manager/lead is a persona distinction, not a permission boundary (A6_softened) | assumptions_registry | Dashboard and task views are identical for all users. "Manager" workflows (monitoring, overdue triage) are supported by filters, not separate screens. |
| Any staff member can assign and reassign tasks (A2_replaced) | assumptions_registry | Assignee picker is always editable. No ownership lock or approval gate. |
| Reassignment requires no approval (A7_replaced) | assumptions_registry | Reassignment is a direct field edit on the task detail view. |
| Overdue visibility via dashboard filter only; no push alerts (A4_open) | assumptions_registry | Overdue handling is entirely pull-based. No toast notifications, emails, or badges outside the dashboard. |
| Task statuses are a small fixed set (A_simple_status_model) | assumptions_registry | Status controls are a simple selector or button group, not a configurable workflow engine. |
| Task lifecycle: created → assigned → in_progress → completed (A_simple_lifecycle) | assumptions_registry | UX enforces or suggests this ordering but allows backward corrections. |
| A single shared task queue is sufficient (A_single_queue) | assumptions_registry | One dashboard view, no team/project/channel segmentation in v1. |
| Due dates are a task-level attribute (A9) | assumptions_registry | Due date is a field on the task, shown in dashboard columns and detail view. |

---

## Relationship to Other Project Docs

- **PRD:** The user flows above map directly to the PRD's core user journeys and functional requirements. Screens support every in-scope workflow.
- **Architecture:** The entity model (Task with title, description, status, priority, due_date, assignee; Assignee with name, role) is reflected in form fields and dashboard columns. The task-to-assignee relationship (one current owner, many tasks per assignee, direct reassignment) shapes the assignee picker and dashboard grouping.
- **Delivery Plan:** The dashboard and task CRUD represent the core deliverable. Overdue filtering and reassignment are the primary alternate-flow surfaces and may be sequenced after the core happy path.
- **Project Charter:** UX scope stays within the charter's boundaries—no external access, no RBAC, no notification system.
