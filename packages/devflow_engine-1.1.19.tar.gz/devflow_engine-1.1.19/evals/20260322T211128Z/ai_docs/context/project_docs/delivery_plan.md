# Delivery Plan

## Delivery Strategy

This delivery plan sequences the build-out of a lightweight internal task management application. The strategy prioritizes a narrow, end-to-end slice first—task creation through status tracking on a shared dashboard—before layering in secondary workflows (reassignment, overdue handling) and polish.

The guiding principle is: **get core value visible early, then harden and extend.** Every phase should leave the product in a usable state for internal staff.

Delivery is organized into three phases:
1. **Foundation** — core entities, basic CRUD, shared dashboard
2. **Workflow Completion** — assignment lifecycle, reassignment, overdue visibility
3. **Hardening & Handoff** — edge cases, concurrency, acceptance validation, release prep

---

## Phases / Milestones

### Phase 1: Foundation

**Goal:** A deployable slice where staff can create tasks, see them in a shared queue, and update status.

| Deliverable | Grounding |
|---|---|
| Task entity with core attributes (title, description, status, priority, due_date, created_at, updated_at) | domain_entities.json — Task entity, key_attributes |
| Assignee entity with core attributes (name, role, availability_state) | domain_entities.json — Assignee entity |
| Task creation flow (wf_capture_task: open app → add details → save) | user_workflows.json — wf_capture_task |
| Simple lifecycle state machine: created → assigned → in_progress → completed | domain_entities.json — Task.lifecycle; assumption A_simple_lifecycle |
| Shared dashboard view listing all tasks with current state | product_brief.json — scope.in_scope (shared dashboard) |
| Single permission level for all users (no RBAC) | assumption A_single_actor_type; product_brief.json — constraints |

**Exit criteria:**
- Staff can create a task with title, description, priority, and optional due date.
- Tasks appear in a shared dashboard with visible status.
- Status can be updated through the lifecycle.

---

### Phase 2: Workflow Completion

**Goal:** Full assignment lifecycle, reassignment, and overdue filtering — completing the primary and alternate workflows.

| Deliverable | Grounding |
|---|---|
| Task-to-Assignee assignment (wf_assign_and_track_task) | user_workflows.json — wf_assign_and_track_task; domain_entities.json — task_assigned_to_assignee relationship |
| Reassignment without approval gate (wf_reassign_task) | user_workflows.json — wf_reassign_task; assumptions A2_replaced, A7_replaced |
| Overdue task filtering/highlighting on dashboard (wf_handle_overdue_task) | user_workflows.json — wf_handle_overdue_task; assumption A4_open (dashboard filter in scope, push alerts not) |
| Dashboard filters: by assignee, by status, by overdue | product_brief.json — success_criteria (managers see ownership, unassigned, overdue) |

**Exit criteria:**
- Tasks can be assigned and reassigned to any staff member.
- Overdue tasks are visually identifiable on the shared dashboard.
- Managers can filter to see unassigned, overdue, or per-assignee views.

---

### Phase 3: Hardening & Handoff

**Goal:** Address edge cases, validate acceptance criteria, and prepare for internal release.

| Deliverable | Grounding |
|---|---|
| Concurrent assignment contention handling | user_workflows.json — edge_cases (multiple staff assign same task) |
| Incomplete-detail task handling (tasks created without enough info to assign) | user_workflows.json — edge_cases |
| Blocked/overdue escalation path validation | user_workflows.json — edge_cases; wf_handle_overdue_task |
| Acceptance walkthrough against success criteria | product_brief.json — success_criteria |
| Usability check: non-technical staff can use without training | product_brief.json — constraints |

**Exit criteria:**
- All three success criteria from the product brief are demonstrably met.
- Known edge cases have been addressed or have explicit, documented handling.
- Product is ready for internal staff use.

---

## Implementation Priorities

Prioritization is derived from the product brief goals and success criteria:

1. **Task creation and shared visibility (highest priority)** — Without this, no other workflow functions. Directly supports success_criteria[0] and success_criteria[2].
2. **Assignment and status tracking** — The core value proposition for managers. Directly supports success_criteria[1].
3. **Overdue filtering** — Explicitly in scope and called out in success_criteria[1]. Scoped to dashboard filter only (assumption A4_open); proactive alerts are out of scope.
4. **Reassignment** — Important alternate flow, but secondary to initial assignment. No approval gate required (assumptions A2_replaced, A7_replaced).
5. **Edge case hardening** — Concurrent assignment contention and incomplete-detail tasks. Important for reliability but not blocking initial utility.

---

## Dependencies

### Internal Dependencies

| Dependency | Blocking | Notes |
|---|---|---|
| Task and Assignee data model must be in place before assignment workflows | Phase 2 blocked by Phase 1 entity work | Lifecycle states and relationship model are prerequisites |
| Dashboard must exist before overdue filtering can be added | Overdue filtering blocked by dashboard | Phase 1 dashboard is the surface; Phase 2 adds filters |
| Assignment must work before reassignment | Reassignment blocked by assignment | wf_reassign_task is an alternate of wf_assign_and_track_task |

### Architectural Dependencies

| Dependency | Notes |
|---|---|
| Concurrency model for task assignment | Needed by Phase 3; should be considered in Phase 1 entity design to avoid rework |
| Single-permission model simplifies auth | No RBAC means no auth dependency beyond basic identity (assumption A_single_actor_type) |

### External / Out-of-Scope Boundaries

The following are explicitly out of scope and should not create delivery dependencies:
- Role-based access control (product_brief.json — out_of_scope)
- Notification/alerting systems (product_brief.json — out_of_scope)
- External customer access (product_brief.json — out_of_scope)
- Advanced analytics or reporting (product_brief.json — non_goals)

---

## Risks / Watchouts

| Risk | Likelihood | Impact | Mitigation |
|---|---|---|---|
| **Concurrent assignment contention** — multiple staff grab the same unassigned task | Medium | Medium | Design the assignment model with optimistic locking or last-write-wins from Phase 1. Validate in Phase 3. |
| **Scope creep toward RBAC** — stakeholders request permission distinctions mid-build | Medium | High | Anchor to assumption A_single_actor_type and product_brief out_of_scope. Manager/lead is persona only (A6_softened). |
| **Overdue handling expectations exceed scope** — stakeholders expect proactive alerts, not just filters | Medium | Medium | Anchor to assumption A4_open: dashboard filter is in scope, push notifications are not. Surface this boundary early. |
| **Incomplete task detail at creation** — tasks created without enough info to assign | High | Low | This is a known edge case (user_workflows.json). Allow tasks to exist in 'created' state without assignee; do not force assignment at creation. |
| **Reassignment audit expectations** — stakeholders may want approval or audit trail | Low | Medium | Assumption A7_replaced explicitly states no approval gate. Record previous and new assignee for traceability but do not build an approval workflow. |
| **Usability for non-technical staff** — constraint that UI should work without training | Medium | Medium | Plan a usability walkthrough in Phase 3. Keep UI interactions minimal and conventional. |

---

## Recommended Next Steps

1. **Validate the Phase 1 entity model** — Confirm Task and Assignee attributes with the architecture doc. Pay early attention to the concurrency model for assignment even though it's formally a Phase 3 concern.
2. **Build the task creation flow and shared dashboard** — This is the minimum viable slice and should be the first thing in front of users.
3. **Align on overdue definition** — The source docs define overdue as "due date has passed and status is not completed." Confirm this is the only trigger; no partial/warning states are implied.
4. **Communicate scope boundaries early** — RBAC, notifications, and external access are out of scope. Proactive alerts for overdue tasks are out of scope. These boundaries should be visible to stakeholders before Phase 2.
5. **Plan a Phase 3 acceptance walkthrough** — Map the three success criteria to concrete test scenarios and validate with actual staff users.

---

## Assumptions Shaping This Plan

The following resolved assumptions materially influence delivery sequencing and scope:

- **A_single_actor_type** — All staff share equal permissions. No auth/RBAC work needed, simplifying every phase.
- **A_simple_lifecycle** — Four fixed statuses (created → assigned → in_progress → completed). No custom status work.
- **A_single_queue** — One shared queue. No multi-team or multi-queue partitioning.
- **A2_replaced / A7_replaced** — Any staff member can assign/reassign without approval. Simplifies the reassignment flow.
- **A4_open** — Overdue visibility is a dashboard filter, not a push notification. Constrains Phase 2 scope.
- **A6_softened** — Manager/lead is a persona distinction only. No permission-tier work.
- **A_sparse_workflow** — Alternate flows limited to reassignment and overdue until clarified. Limits Phase 2 scope.

Where source grounding is thin: the source docs do not specify technology stack, team size, or timeline constraints. This plan sequences by logical dependency and product value rather than calendar dates. Timeline estimation would require additional context not present in the current source docs.