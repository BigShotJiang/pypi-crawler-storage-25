# Product Requirements Document (PRD)

## Product Overview

This product is a lightweight internal task management application that lets the team create tasks, assign them to staff members, and track progress through a shared view. It replaces an unclear or manual process where ownership and progress are hard to track.

The product targets a single release that improves day-to-day operational visibility for internal staff and managers. It is not a customer-facing tool, not a full project management suite, and not an analytics platform.

---

## User Roles

### Staff Member

Any team member who can create, view, assign, reassign, and update tasks. This includes managers and leads as a persona distinction — not a permission boundary.

- All staff share equal permissions in v1.
- Role-based access control (RBAC) is explicitly out of scope.
- The "manager" or "lead" label is informational only and does not gate any functionality.

**Grounding:** `user_workflows.json:actors`, assumption `A_single_actor_type`, `product_brief.json:constraints`.

---

## Core User Journeys

### Journey 1: Capture a New Task (`wf_capture_task`)

**Trigger:** New work or follow-up request is identified.

**Steps:**
1. Staff member opens the task app and creates a new task record.
2. Adds core task details: title, description, priority, and optional due date.
3. Saves the task so it becomes visible in the shared team queue.

**Result:** A trackable task exists in the shared system with status `created`.

**Functional expectations:**
- Title is required.
- Description, priority, and due date are optional at creation but should be encouraged.
- The task is immediately visible in the shared dashboard/queue upon save.
- `created_at` timestamp is set automatically.
- Initial status is `created`.

---

### Journey 2: Assign and Track a Task (`wf_assign_and_track_task`)

**Trigger:** A task needs an owner or updated status.

**Steps:**
1. Staff member reviews the open task queue or dashboard.
2. Assigns the task to a staff owner based on responsibility or availability.
3. Updates task status as work starts, pauses, or completes.
4. Reviews overdue or blocked work and reassigns if needed.

**Result:** Each active task has a visible owner and current status.

**Functional expectations:**
- Any staff member can assign any task to any other staff member (or themselves).
- Status transitions follow the lifecycle: `created` → `assigned` → `in_progress` → `completed`.
- Status updates should be reflected immediately in the shared view.
- `updated_at` timestamp is refreshed on every change.

---

## Functional Requirements

### FR-1: Task Creation
- The system must allow any staff member to create a task with a title.
- Optional fields at creation: description, priority, due date, assignee.
- The system must automatically set `status = created`, `created_at = now()`.

### FR-2: Task Assignment
- Any staff member can assign a task to any other staff member.
- Assignment changes the task status to `assigned` if the task was previously `created`.
- A task has at most one current assignee at any time.

### FR-3: Status Tracking
- The system must support exactly four statuses: `created`, `assigned`, `in_progress`, `completed`.
- Staff can update the status of any task.
- Status changes must update the `updated_at` timestamp.

### FR-4: Shared Dashboard / Queue View
- The system must provide a shared view showing all tasks and their current state.
- The view must display: task title, assignee (or unassigned), status, priority, and due date.
- The view must be usable without training for non-technical staff.

### FR-5: Overdue Visibility
- Tasks whose due date has passed and whose status is not `completed` must be visually identifiable in the shared view.
- The system must support filtering or highlighting overdue tasks.
- Proactive push notifications or alerting for overdue tasks are explicitly out of scope.

### FR-6: Task Detail View
- Staff must be able to open an individual task to see and edit all task attributes.
- Editable attributes: title, description, status, priority, due date, assignee.

---

## Alternate / Exceptional Flows

### Alt-1: Reassign a Task (`wf_reassign_task`)

**Trigger:** Original assignee is unavailable, overloaded, or was assigned in error.

**Steps:**
1. Staff member opens the task from the queue or dashboard.
2. Changes the assignee to a different staff member.
3. Optionally adds a note explaining the reassignment reason.

**Result:** Task ownership is transferred. Previous and new assignee are recorded.

**Behavioral notes:**
- No approval gate is required for reassignment. This is a direct staff action.
- The system should record reassignment history (previous assignee, new assignee, timestamp).
- Reassignment does not reset the task status.

**Grounding:** assumption `A7_replaced` (no approval gate), assumption `A2_replaced` (any staff can reassign).

---

### Alt-2: Handle an Overdue Task (`wf_handle_overdue_task`)

**Trigger:** Task due date has passed and status is not `completed`.

**Steps:**
1. Staff member identifies overdue tasks via the dashboard filter or overdue highlight.
2. Reviews blocked or stale tasks and decides: reprioritize, reassign, or update due date.
3. Updates the task accordingly.

**Result:** Overdue task has a current owner, updated priority or due date, and is no longer stale.

**Behavioral notes:**
- This flow relies on the dashboard's overdue visibility (FR-5), not on proactive alerts.
- There is no automated escalation mechanism in v1.

**Grounding:** assumption `A4_open` (overdue visibility via dashboard filter is in scope; proactive push alerts are not).

---

## Acceptance-Oriented Behavior Notes

### Task lifecycle integrity
- A task must always have exactly one status from the set: `created`, `assigned`, `in_progress`, `completed`.
- Status transitions should follow the defined lifecycle order, though the system should not hard-block out-of-order transitions in v1 (e.g., moving directly from `created` to `in_progress` if no formal assignment step is needed).

### Assignment integrity
- A task may be unassigned (no assignee) or assigned to exactly one staff member.
- Reassignment replaces the current assignee directly.

### Concurrent assignment contention
- Multiple staff may attempt to assign themselves to the same unassigned task concurrently.
- The system should handle this gracefully — last-write-wins is acceptable for v1, but the user should see the current state after their action completes.

**Grounding:** `user_workflows.json:edge_cases` (concurrent self-assignment contention).

### Incomplete task creation
- Tasks may be created without enough detail to assign confidently on the first pass.
- The system should allow saving a minimal task (title only) and enriching it later.

**Grounding:** `user_workflows.json:edge_cases`.

### Dashboard usability
- Staff can create a task, assign an owner, and update status without leaving the product.
- Managers can see who owns each task and which work is unassigned or overdue.
- The team can review the current work queue from a shared dashboard view.

**Grounding:** `product_brief.json:success_criteria`.

---

## Out of Scope (v1)

- Role-based access control or permission enforcement.
- Proactive notification or alerting systems.
- Advanced workforce planning beyond task assignment and tracking.
- Fully custom reporting outside the core workflow views.
- External customer-facing access or self-service portals.
- Advanced analytics, charting, or resource-planning features.

---

## Assumptions

The following assumptions materially shape this PRD:

| ID | Assumption | Impact on PRD |
|---|---|---|
| `A_internal_users` | Primary users are internal staff and managers, not external customers. | All journeys and requirements target internal workflows only. |
| `A_single_queue` | A single shared task queue is sufficient for the first release. | One dashboard view serves all users; no team/project partitioning needed. |
| `A_simple_lifecycle` | Task lifecycle is simple: created → assigned → in-progress → done. | Exactly four statuses; no custom or configurable workflows. |
| `A_single_actor_type` | All users share a single 'staff' permission level for v1. | No permission checks gate any action; role is informational only. |
| `A_simple_status_model` | Task statuses are a small fixed set. | Status field is an enum, not user-configurable. |
| `A2_replaced` | Any staff member can assign and reassign tasks. | No ownership restrictions on assignment actions. |
| `A7_replaced` | Reassignment is a direct staff action with no approval gate. | Reassignment flow has no approval step. |
| `A4_open` | Overdue visibility via dashboard filter is in scope; proactive push alerts are not. | Overdue handling is passive (filter/highlight), not active (notification). |
| `A_sparse_workflow` | Alternate flows limited to reassignment and overdue handling until clarified. | Only two alternate flows are specified; additional exception paths are deferred. |
| `A6_softened` | Manager/lead is a persona distinction, not a permission boundary in v1. | No manager-specific features or views. |
| `A9` | Due dates are a task-level attribute. | Due date is on the Task entity, not a separate scheduling concept. |

---

## Data Model Summary (for PRD-level reference)

### Task
- **Attributes:** title, description, status, priority, due_date, created_at, updated_at
- **Lifecycle:** created → assigned → in_progress → completed
- **Relationship:** assigned to zero or one Assignee

### Assignee
- **Attributes:** name, role, availability_state
- **Relationship:** may own many Tasks

Reassignment changes the task-to-assignee link directly without approval. Previous assignment should be historically traceable.

**Grounding:** `domain_entities.json:entities`, `domain_entities.json:relationships`, `domain_entities.json:ownership_assumptions`.