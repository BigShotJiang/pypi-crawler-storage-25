# UX Design — Service Team Task Dashboard

## UX Overview

This document describes the user interaction design for a service team task management dashboard. The system serves four distinct user roles — operators, managers, office teams, and field teams — each with different interaction needs and permission levels.

The UX is shaped by a core operational lifecycle: requests arrive, operators triage them into tasks, managers assign and schedule work, and teams monitor progress through role-appropriate dashboard views. Reassignment is a controlled, approval-gated process. Status visibility is read-only for non-manager roles.

The interaction model prioritizes operational clarity: surfacing what needs attention, what is overdue, and what is blocked — without requiring users to hunt for information.

---

## Primary User Flows

### 1. Request Triage (Operator)

**Trigger:** A new request arrives in the system through the single intake channel.

**Flow:**
1. Operator sees incoming request in a triage queue view, showing request summary, source, and timestamp.
2. Operator opens the request detail to review context.
3. Operator classifies the request (type, urgency). *[Note: source docs reference classification at triage but domain_entities currently lacks a classification/urgency attribute on Request — see UX Assumptions below.]*
4. Operator routes the classified request to the appropriate queue, which creates a Task (1:1 mapping per assumption A8).
5. Triage queue updates to reflect the request has been processed.

**Key interaction:** Classification and routing should be achievable in minimal clicks. The triage view should clearly separate untriaged requests from those already processed.

### 2. Work Assignment (Manager)

**Trigger:** Manager reviews queued tasks awaiting assignment.

**Flow:**
1. Manager opens the assignment queue, which shows tasks grouped or filterable by queue/type.
2. Manager selects a task and views its detail (origin request, classification, queue).
3. Manager assigns the task to a specific operator, setting a due date.
4. Assignment is recorded (assigned_by, assigned_at). The assigned operator is notified.
5. Task status transitions from queued to assigned.

**Key interaction:** The assignment view must surface queue depth and task age to help managers prioritize. Due date setting should be mandatory (per workflow assumptions) and inline — not buried in a secondary form.

### 3. Reassignment Approval (Manager)

**Trigger:** An operator requests reassignment of a task they are currently assigned to.

**Flow:**
1. Operator initiates a reassignment request from their task detail view, providing a reason.
2. A ReassignmentRequest is created with status `pending`.
3. Manager sees pending reassignment requests in a dedicated approval queue or as flagged items on the dashboard.
4. Manager reviews the request context (original task, current assignee, reason).
5. Manager approves or rejects. On approval, the task is reassigned; on rejection, it remains with the current operator.
6. The requesting operator is notified of the outcome.

**Key interaction:** Reassignment requests must be visually prominent to managers so they do not block work silently. The approve/reject action should be a single interaction, not a multi-step form.

### 4. Self-Assignment (Operator — Alternate Flow)

**Trigger:** An operator picks up an unassigned task from the queue without manager intervention.

**Flow:**
1. Operator browses available (unassigned) tasks in the queue.
2. Operator selects a task and claims it.
3. Task transitions to assigned with the operator as assignee.

**UX Assumption (A2 tension):** Source docs conflict on whether self-assignment bypasses manager approval or is a separately permitted action. The UX should be designed so self-assignment can be feature-flagged or permission-gated without structural changes to the assignment view. If self-assignment is enabled, the queue view should clearly distinguish "assigned to me" from "assigned by manager" tasks.

### 5. Status Tracking (Office Team / Field Team)

**Trigger:** Team member opens the dashboard to check task status.

**Flow:**
1. User lands on a dashboard view filtered by their team type (office or field).
2. Dashboard displays task statuses relevant to their team: in-progress, completed, overdue.
3. User can drill into individual task details (read-only).
4. No edit, assign, or triage actions are available.

**Key interaction:** The dashboard must clearly communicate status at a glance. Color-coding or iconography for overdue, at-risk, and completed tasks is essential. Office and field teams may need different default filters or groupings given their distinct operational contexts (assumption A1).

### 6. Completion Monitoring (Manager)

**Trigger:** Manager reviews task completion rates and overdue items.

**Flow:**
1. Manager opens a monitoring/reporting view.
2. View shows completion metrics: tasks completed on time, overdue tasks, tasks approaching due date.
3. Manager can drill down into specific overdue or at-risk tasks.
4. Overdue items are proactively surfaced (assumption A4) — the view should highlight them without requiring the manager to search.

**Key interaction:** This view should function as a command center. Proactive alerts (approaching due date, overdue) should appear as banner notifications or dashboard badges, not only within drill-down views.

---

## Key Screens / Views

### Operator Views

| Screen | Purpose | Key Elements |
|---|---|---|
| **Triage Queue** | Process incoming requests | Request list (sorted by arrival), classification controls, route-to-queue action |
| **My Tasks** | View and manage assigned work | Task list with status, due date, detail expand, reassignment request action |
| **Available Tasks** | Browse unassigned tasks (if self-assignment enabled) | Queue-filtered task list, claim action |

### Manager Views

| Screen | Purpose | Key Elements |
|---|---|---|
| **Assignment Queue** | Assign queued tasks to operators | Task list by queue, assignee picker, due date setter, queue depth indicators |
| **Reassignment Approvals** | Review and act on reassignment requests | Pending request list, request detail with reason, approve/reject actions |
| **Completion Monitor** | Track progress and overdue risk | Completion metrics, overdue task list, at-risk task list, drill-down to task detail |
| **Team Dashboard** | Overview of all task activity | Aggregate status view, filterable by team/queue/status/date range |

### Office Team / Field Team Views

| Screen | Purpose | Key Elements |
|---|---|---|
| **Team Status Dashboard** | Read-only task status visibility | Task list filtered by team type, status indicators (in-progress, completed, overdue), task detail (read-only) |

### Shared Components

- **Task Detail Panel:** Read-only for office/field teams; includes reassignment request for operators; includes assignment controls for managers. Adapts based on role.
- **Notification Area:** Surfaces assignment notifications, reassignment outcomes, and overdue alerts. *[Note: domain_entities currently lacks a Notification entity — this implies a lightweight notification model needs to be added or handled at the UI layer.]*
- **Due Date Indicators:** Visual treatment (color, icon) for on-track, approaching, and overdue states, consistent across all views.

---

## Important Interactions

### Triage Classification
The triage step requires the operator to classify a request before routing. The UX should provide structured classification controls (dropdowns or chips for type and urgency) rather than free-text, to ensure consistent downstream filtering and reporting. *[Note: the exact classification taxonomy is not defined in source docs — this will need product input.]*

### Due Date Assignment
Due dates are set per-task at assignment time (assumption A9), not at request intake. The manager assignment flow must enforce due date entry as a required field. Visual cues should make the due date prominent on every task card and detail view.

### Reassignment as a Blocking State
When a reassignment request is pending (assumption A10), the task should visually indicate its blocked/pending-reassignment state. The current assignee remains responsible until the manager acts. The UX should make it unambiguous that the task is not "unassigned" while awaiting approval.

### Role-Gated Actions
The interface should suppress or disable actions the current user's role cannot perform, rather than showing them and returning permission errors. Operators should never see assignment controls; office/field teams should never see edit controls.

### Proactive Overdue Surfacing
Overdue and at-risk tasks (assumption A4) should be surfaced proactively through:
- Dashboard badges or counters visible on landing
- Sorted/pinned placement in task lists
- Color-coded due date indicators
- Notification entries for newly-overdue items

*[Note: the mechanism for proactive alerts is implied by workflows but not formally modeled in domain entities. The UX design assumes a lightweight notification/alert layer will exist. If it does not, overdue surfacing will be limited to dashboard indicators only.]*

---

## Edge / Error Experiences

### Field Team Intermittent Connectivity
Source docs note that field team members may have intermittent connectivity. The read-only status dashboard should:
- Clearly indicate data freshness (last-synced timestamp)
- Degrade gracefully when offline (show last-known state, not an error screen)
- Avoid interactions that would fail silently without connectivity

*[Note: domain_entities does not model an offline-capable status layer. This edge case implies either a service worker / local cache strategy or acceptance that field team views may be stale. This needs architectural alignment.]*

### Reassignment Request on Already-Reassigned Task
If a task is reassigned while a reassignment request is still pending, the UX should prevent conflicting state. Only one active reassignment request per task should be permitted, and the UI should disable the reassignment action while a request is pending.

### Triage of Duplicate or Invalid Requests
The triage flow should allow operators to reject or mark requests as duplicate, preventing them from becoming tasks. The 1:1 Request-to-Task mapping (assumption A8) means a rejected request should not create a task — the triage view needs a "reject/close" path in addition to "classify and route."

### Empty States
- **Triage queue empty:** Clear message confirming no pending requests.
- **Assignment queue empty:** Indicate all tasks are assigned.
- **No overdue tasks:** Positive confirmation in completion monitor.
- **No reassignment requests:** Clean state in approval queue.

### Permission Denied
If a user somehow reaches an action they cannot perform (e.g., deep link, stale UI), display a clear, non-technical explanation of why the action is not available for their role.

---

## UX Assumptions

The following assumptions materially shape this UX design:

| ID | Assumption | Impact on UX | Coherence |
|---|---|---|---|
| A1 | Office and field teams have distinct status visibility needs | Separate dashboard filters/views per team type | Supported |
| A2 | Only managers can assign work and approve reassignments | Assignment and approval controls are manager-only; however, self-assignment alternate flow creates tension — UX must support permission-gating this capability | Tension |
| A3 | Triage is a discrete step before assignment | Triage queue and assignment queue are separate views with separate entry points | Supported |
| A4 | Due-date tracking includes proactive alerts | Dashboard badges, color-coded indicators, and notification entries for overdue/at-risk items | Partially supported (no Notification entity in domain model) |
| A5 | Office/field teams have read-only access | No edit/assign/triage controls shown to these roles | Supported |
| A7 | Reassignment requires manager approval | Reassignment is a request-then-approve flow, not a direct operator action | Supported |
| A8 | Each request maps to exactly one task | Triage creates one task per request; UX does not need to model splitting or merging | Supported |
| A9 | Due dates are per-task, not per-request | Due date controls appear at assignment time, not at triage | Supported |
| A10 | Reassignment blocks on manager approval | Pending-reassignment is a visible task state; task remains with current assignee until resolved | Supported |

### Grounding Gaps

The following areas are implied by the UX flows but not fully grounded in current source docs:

1. **Request classification taxonomy** — Triage workflow references classification (type, urgency) but domain_entities lacks these attributes on the Request entity. UX designs classification controls speculatively.
2. **Queue model** — Workflows reference routing to queues and queue visibility, but no Queue entity exists in domain_entities. UX assumes queues exist as a grouping/filtering concept.
3. **Notification mechanism** — Workflows reference notifications on assign, reassign, and overdue events. Domain_entities has no Notification entity. UX assumes some notification delivery exists but cannot specify its persistence or delivery model.
4. **Offline/degraded experience** — Field team connectivity edge case is noted but not modeled. UX recommends graceful degradation but cannot specify implementation without architectural input.
