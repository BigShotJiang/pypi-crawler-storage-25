# Project Charter

## Overview

This project delivers an internal work-management system that provides structured request intake, task assignment, status tracking, and controlled reassignment for operational teams. The system replaces ad-hoc coordination by introducing a defined lifecycle from incoming request through triage, assignment, execution, and completion — with role-appropriate visibility at every stage.

The product serves four distinct user groups: operators who triage incoming requests, managers who assign work and approve reassignments, and office and field teams who consume task-status dashboards.

## Problem / Opportunity

Operational teams currently lack a unified system for managing work requests end-to-end. Key pain points include:

- **No structured intake**: requests arrive without a consistent triage step, making it difficult to classify, prioritize, and route work.
- **Opaque assignment**: managers lack a controlled mechanism to assign tasks, set due dates, and approve reassignments — leading to unclear ownership.
- **Fragmented status visibility**: office and field teams cannot easily see what work is in progress, approaching deadlines, or overdue.
- **Uncontrolled reassignment**: when work needs to shift between assignees, there is no approval workflow to maintain accountability.

Without addressing these gaps, teams risk missed deadlines, duplicated effort, and poor cross-team coordination.

## Target Users

| Role | Primary Responsibility |
|------|------------------------|
| **Operators** | Triage incoming requests, classify and route to appropriate queues |
| **Managers** | Assign work to team members, set due dates, approve or reject reassignment requests, monitor completion |
| **Office teams** | View task status dashboards for office-relevant work |
| **Field teams** | View task status dashboards for field-relevant work |

**Assumption (A6):** Managers and operators are distinct roles with different permissions. This is well-supported across source docs.

**Assumption (A1):** Office and field teams have distinct status visibility needs, implying separate or filtered dashboard views rather than a single undifferentiated status page.

## Goals

1. **Structured request intake** — provide a consistent triage workflow that classifies incoming requests before they become assigned tasks.
2. **Controlled task assignment** — enable managers to assign triaged requests as tasks with ownership and due dates.
3. **Due-date tracking and visibility** — surface approaching and overdue deadlines so at-risk work is caught early.
4. **Role-appropriate status dashboards** — expose task status to office and field teams through filtered, read-only views.
5. **Managed reassignment** — support a reassignment request and approval flow so task ownership changes are deliberate and auditable.
6. **Completion monitoring** — allow managers to track task completion and drill into overdue or stalled work.

## Scope

### In scope

- Request triage workflow (intake → classification → routing)
- Task assignment with manager-driven ownership and due-date setting
- Due-date tracking with proactive surfacing of at-risk items
- Status dashboards differentiated for office and field teams
- Reassignment request and approval workflow
- Completion monitoring and overdue drill-down
- Core entities: Request, Task, Assignment, ReassignmentRequest, Team, User

### Out of scope

- Notification/alert delivery infrastructure (source docs reference notifications on assign, reassign, and overdue events, but no Notification entity or delivery mechanism is currently modeled — this is a known gap)
- Offline/intermittent-connectivity support for field teams (referenced as an edge case in workflows but not modeled in entities)
- Self-assignment by operators without manager involvement (an alternate flow exists in user_workflows but directly tensions with the manager-authority assumption — see Assumptions below)
- Request classification taxonomy (no entity or attribute captures request type/urgency during triage, though the workflow implies it)
- Queue management entity (workflows reference routing to queues, but no Queue entity is defined)

## Non-Goals

- Building a customer-facing or external-facing product; this is an internal operational tool.
- Replacing existing communication channels; the system manages work lifecycle, not messaging.
- Automating triage decisions; triage remains a human-driven step.
- Providing analytics or reporting beyond status dashboards and completion monitoring.

## Constraints

- **Role-based permissions are foundational**: the system must enforce the operator/manager/viewer permission model from the start, not bolt it on later.
- **1:1 request-to-task cardinality (A8)**: each request maps to exactly one task after triage. This simplifies the data model but may need revisiting if requests can spawn multiple tasks.
- **Due dates live on tasks, not requests (A9)**: due-date tracking activates after triage, not at intake.
- **Read-only status views for office and field teams (A5)**: these teams consume dashboards but do not modify tasks directly.
- **Reassignment blocks on manager approval (A7, A10)**: reassignment is a controlled state transition, not a free-form edit.

## Success Criteria

1. Every incoming request passes through a discrete triage step before becoming an assigned task.
2. Managers can assign tasks with due dates and the system surfaces tasks approaching or past their deadlines.
3. Office and field teams can view task status through appropriately filtered, read-only dashboards.
4. Reassignment requests require and receive explicit manager approval or rejection before taking effect.
5. Completion status is tracked per task, and managers can identify overdue or stalled work.
6. The entity model (Request, Task, Assignment, ReassignmentRequest, Team, User) supports all in-scope workflows without silent contradictions.

## Assumptions Surfaced in This Document

| ID | Assumption | Coherence | Note |
|----|-----------|-----------|------|
| A1 | Office and field teams have distinct status visibility needs | Supported | Separate dashboard scope items and Team.team_type reinforce this |
| A2 | Only managers can assign work and approve reassignments | **Tension** | user_workflows alternate flow 'self_assignment' allows operators to pick up tasks without manager intervention — needs clarification |
| A3 | Triage is a discrete workflow step before task assignment | Supported | Request and Task as separate entities with triages_into relationship model this |
| A4 | Due-date tracking includes proactive alerts for approaching/overdue deadlines | Partially supported | Workflows reference overdue notifications but no Notification entity exists to model delivery |
| A5 | Office and field teams have read-only access to task status | Supported | Consistent across product brief and workflow assumptions |
| A6 | Managers are a distinct role from operators | Supported | User.role attribute and distinct ownership assumptions confirm this |
| A7 | Reassignment is a controlled process requiring approval | Supported | ReassignmentRequest entity with status and approved_by models this |
| A8 | Each request maps to exactly one task after triage | Supported | 1:1 cardinality on Request-to-Task relationship |
| A9 | Due dates are per-task, not per-request | Supported | due_date attribute is on Task only |

## Source Grounding Note

This charter is grounded primarily in `product_brief.json` and `assumptions_registry.json`, with supplementary signal from `user_workflows.json` and `domain_entities.json` cross-references. The source docs at this stage contain structured cross-reference metadata and coherence assessments rather than full narrative briefs. Where this charter elaborates beyond what is explicitly stated in source docs, the elaboration is flagged as assumption-dependent. No content in this charter silently contradicts the source record.