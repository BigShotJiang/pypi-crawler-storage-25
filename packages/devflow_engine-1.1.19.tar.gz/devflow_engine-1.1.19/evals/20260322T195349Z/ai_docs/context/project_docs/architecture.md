# Architecture

## System Overview

This system is an internal operational tool for managing the lifecycle of work requests—from intake and triage through assignment, execution, status tracking, and completion monitoring. It serves a multi-role user base (operators, managers, office teams, field teams) with role-differentiated access. The system shape is a request-processing pipeline backed by a relational data model, with role-based dashboards for status visibility.

The core operational flow is:
1. Requests arrive through a single intake channel
2. Operators triage requests into actionable tasks
3. Managers assign tasks to workers with due dates
4. Teams track task status through filtered, read-only dashboards
5. Managers monitor completion and approve reassignments when needed

---

## Core Entities / Data Model

### User
Represents any person interacting with the system. Distinguished by a `role` attribute that governs permissions and available actions.

- **Attributes**: `user_id`, `name`, `role` (operator | manager | office_team | field_team)
- **Role semantics**: Operators perform triage. Managers assign work, set due dates, approve reassignments, and monitor completion. Office and field team members have read-only status visibility.
- **Assumption (A6)**: Managers and operators are distinct roles. This is well-supported across source docs.

### Request
The intake entity representing an inbound work item before triage.

- **Attributes**: `request_id`, `submitted_at`, `description`, `source`
- **Lifecycle**: Created on intake → triaged by operator → produces exactly one Task
- **Known gap**: Source docs reference request classification (type, urgency) during triage, but no explicit attributes model this on the Request entity. This should be resolved before implementation—recommend adding `request_type` and `urgency` attributes.

### Task
The operational work unit created from a triaged request. Central entity in the system.

- **Attributes**: `task_id`, `status`, `due_date`, `completed_at`, `description`
- **Status values**: Implied lifecycle states include at minimum: pending, assigned, in_progress, completed
- **Assumption (A9)**: Due dates are per-task, not per-request. The `due_date` is set during assignment, not at intake.

### Assignment
Captures the binding of a task to a worker.

- **Attributes**: `assignment_id`, `assigned_by`, `assigned_at`, `assignee`
- **Ownership**: The `assigned_by` field references a manager-role User.
- **Assumption (A2, tension)**: Source docs state only managers can assign work, but `user_workflows.json` includes a `self_assignment` alternate flow allowing operators to pick up tasks without manager intervention. This tension must be resolved in the permission model. Recommend modeling self-assignment as a distinct permitted action with an explicit flag, rather than silently overriding manager-only assignment.

### ReassignmentRequest
Models the controlled process of moving a task from one assignee to another.

- **Attributes**: `reassignment_id`, `status` (pending | approved | rejected), `approved_by`, `requested_at`, `reason`
- **Assumption (A7, A10)**: Reassignment blocks on manager approval. This is a state transition, not a direct update—the reassignment stays pending until a manager acts.

### Team
Organizational grouping for status visibility.

- **Attributes**: `team_id`, `name`, `team_type` (office | field)
- **Assumption (A1)**: Office and field teams have distinct status visibility needs. This implies filtered dashboard views scoped by `team_type`.

---

## Key Relationships

| Relationship | From | To | Cardinality | Notes |
|---|---|---|---|---|
| `triages_into` | Request | Task | 1:1 | Each request produces exactly one task after triage (A8) |
| `assigned_to` | Assignment | Task | N:1 | A task may be reassigned, creating a new Assignment record |
| `assigned_by` | Assignment | User (manager) | N:1 | Manager who made the assignment |
| `reassignment_of` | ReassignmentRequest | Task | N:1 | Links reassignment to its task |
| `approved_by` | ReassignmentRequest | User (manager) | N:1 | Manager who approved/rejected |
| `monitors` | User (manager) | Task | N:N | Completion monitoring relationship |
| `belongs_to` | User | Team | N:1 | User membership in office/field teams |

**Known gap — Queue entity**: Workflows reference "routes request to appropriate queue" during triage and "queued requests" during assignment, but no Queue entity exists in the domain model. If queue-based routing is required, a `Queue` entity with attributes like `queue_id`, `name`, and `priority_order` should be introduced, with Request and Task having queue membership relationships.

---

## Components / Surfaces

### Request Intake Surface
- Single intake channel for submitting new requests
- Captures request description and metadata
- Source docs assume a single intake channel; multi-channel intake is not currently modeled

### Triage Interface
- Operator-facing view of incoming requests
- Supports classifying, prioritizing, and converting requests into tasks
- **Gap**: Request classification attributes (type, urgency) are referenced in workflows but not yet modeled on the entity. The triage interface design depends on resolving this.

### Assignment Console
- Manager-facing view for assigning tasks to workers
- Includes setting due dates at assignment time
- Must support the reassignment approval workflow (review pending ReassignmentRequests)
- **Open question**: If self-assignment (A2 tension) is permitted, operators need a "pick up task" affordance here or on a separate queue view

### Status Dashboards
- **Office team dashboard**: Read-only view of task statuses filtered by office team scope (A5)
- **Field team dashboard**: Read-only view of task statuses filtered by field team scope (A1)
- Both dashboards are view-only; these users do not modify tasks directly
- Dashboard views should be scoped by `Team.team_type`

### Completion Monitoring View
- Manager-facing view for tracking task completion
- Supports drill-down into individual tasks (`completion_monitoring` workflow)
- Shows tasks approaching or past due dates

---

## Integrations

Source docs do not explicitly define external integrations. The system appears to be a standalone internal operational tool at this stage.

**Notification delivery**: Workflows reference notifications on assign, reassign, and overdue events (A4). No Notification entity or event log exists in the domain model to persist these. If notifications are in scope, the system needs:
- A `Notification` or `Event` entity to model notification state
- An integration point for delivery (email, push, in-app—unspecified in source docs)
- Logic for proactive due-date alerts (approaching and overdue)

This is a genuine gap in the source docs, not an architectural elaboration. The source grounding for notification mechanics is thin.

**Offline/connectivity**: One edge case references "field team member has intermittent connectivity," which implies the field team dashboard may need offline-capable status reads or graceful degradation. Source docs do not elaborate on this, so it should be treated as an open architectural question rather than a requirement.

---

## Constraints / Risks

### Permission Model Complexity
The role-based permission model has a known tension. The primary flow requires manager-only assignment and reassignment approval, but the `self_assignment` alternate flow allows operators to bypass this. The permission model must explicitly handle both paths without creating security gaps or UX confusion. **Risk**: Building only one model and retrofitting the other is expensive.

### 1:1 Request-to-Task Cardinality
The current model assumes each request maps to exactly one task (A8). This simplifies triage but may be limiting if real-world requests sometimes require splitting into multiple tasks or merging multiple requests. **Risk**: If this assumption is wrong, the data model requires a cardinality change (1:N or N:1) that would affect triage, assignment, and status tracking.

### Missing Notification Infrastructure
Workflows describe notifications as expected system behavior, but no entity or delivery mechanism is modeled. **Risk**: If notifications are deferred entirely, the dashboard becomes passive and overdue tasks may go unnoticed (A4).

### Missing Queue Abstraction
Workflows reference queue-based routing, but no Queue entity exists. **Risk**: Without a queue model, triage routing and assignment prioritization may need to be handled ad-hoc in the application layer rather than as a first-class domain concept.

### Entity Completeness
The domain entity model is coherent for the core triage→assign→track→complete flow but has known gaps:
- No request classification attributes (type, urgency)
- No Notification/Alert entity
- No Queue entity
- No offline/sync model for field teams

These gaps are documented in source-doc cross-references and should be resolved before detailed implementation design.

---

## Open Architectural Assumptions

| ID | Assumption | Status | Architectural Impact |
|---|---|---|---|
| A1 | Office and field teams have distinct status visibility needs | Supported | Requires team-type-scoped dashboard views |
| A2 | Only managers can assign work and approve reassignments | **Tension** | Permission model must reconcile with self-assignment alternate flow |
| A3 | Triage is a discrete workflow step before assignment | Supported | Request and Task are separate entities with explicit triage transition |
| A4 | Due-date tracking includes proactive alerts | Partially supported | Requires Notification entity not yet in domain model |
| A5 | Office/field teams have read-only status access | Supported | Dashboard permission scoping |
| A7 | Reassignment requires manager approval | Supported | ReassignmentRequest entity with blocking approval state |
| A8 | Each request maps to exactly one task | Supported | 1:1 cardinality on triages_into; risk if wrong |
| A9 | Due dates are per-task, not per-request | Supported | due_date attribute on Task only |
| A10 | Reassignment blocks on manager approval | Supported | State transition model on ReassignmentRequest |

**Assumptions not yet modeled in architecture that should be watched**:
- Whether self-assignment is a first-class permitted action or an exception
- Whether queue-based routing is required or merely illustrative language in workflows
- Whether notifications are in scope for initial delivery or deferred
- Whether field team offline access is a real requirement or an edge case to handle gracefully