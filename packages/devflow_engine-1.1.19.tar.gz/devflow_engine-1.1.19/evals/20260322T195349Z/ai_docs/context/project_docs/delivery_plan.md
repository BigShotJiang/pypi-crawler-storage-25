# Delivery Plan

## Delivery Strategy

This delivery plan sequences the implementation of the task management and work-assignment system described in the product brief and supporting source docs. The strategy is to build foundational data and permission infrastructure first, then layer workflow capabilities in order of operational dependency, and finish with visibility/reporting surfaces that depend on populated data.

The sequencing principle is: **entities before workflows, workflows before dashboards, core path before edge cases**.

Delivery is organized into four phases. Each phase produces a usable vertical slice that can be validated before the next phase begins.

---

## Phases / Milestones

### Phase 1 — Core Data Model and Permissions Foundation

**Goal:** Establish the entity layer and role-based access control so that all subsequent workflow features have a stable substrate.

**Scope:**
- Implement core entities: User, Request, Task, Team, Assignment, ReassignmentRequest
- Implement entity relationships: Request `triages_into` Task (1:1 cardinality per A8), User `assigned_to` Task, Team membership, Assignment ownership
- Implement role model: operator, manager, office team, field team (per A6 — managers are a distinct role from operators)
- Implement permission boundaries: managers can assign/approve; office and field teams have read-only status access (per A5/A11); operators can create and triage requests
- Seed data and migration scripts

**Milestone:** All entities persistable; role-based access enforceable at the API layer; automated tests confirm permission boundaries.

**Assumption dependency:**
- A6 (managers distinct from operators) — directly shapes role model
- A5/A11 (read-only team access) — directly shapes permission layer
- A8 (1:1 Request-to-Task) — directly shapes entity cardinality

---

### Phase 2 — Request Intake and Triage Workflow

**Goal:** Deliver the request-to-task pipeline so that work items can enter the system and be triaged into actionable tasks.

**Scope:**
- Implement request creation (operator-initiated)
- Implement triage workflow: operator reviews request → classifies → converts to Task via `triages_into` relationship
- Set due date on Task during or after triage (per A9 — due dates are per-task, not per-request)
- Implement the triage-before-assignment gate (per A3 — triage is a discrete step before assignment)

**Known gap (source-doc grounding):** Domain entities currently lack a classification attribute (type, urgency) on Request, despite the triage workflow implying classification occurs at step 3. Additionally, no Queue entity exists despite workflows referencing routing to queues. **Recommendation:** Resolve these entity gaps before or during this phase. If deferred, triage will lack structured classification and queue routing.

**Milestone:** A request can be created, triaged, and converted into a task with a due date. Triage is enforced as a prerequisite to assignment.

**Assumption dependency:**
- A3 (triage is discrete before assignment)
- A9 (due dates per-task)

---

### Phase 3 — Assignment, Reassignment, and Notification Workflows

**Goal:** Enable managers to assign work and handle reassignment requests, and deliver notifications for key lifecycle events.

**Scope:**
- Implement work assignment workflow: manager assigns task to operator, creating Assignment record with `assigned_by` and `assigned_at`
- Implement reassignment request workflow: operator requests reassignment → ReassignmentRequest created → manager approves/rejects (per A7, A10 — reassignment blocks on manager approval)
- Implement notification events for: assignment, reassignment request, reassignment decision, overdue alerts
- **Self-assignment decision point:** The alternate flow `self_assignment` allows operators to pick tasks without manager approval, which is in tension with A2 (only managers assign). This tension must be resolved before implementation. Options: (a) self-assignment is a separate permitted action that does not require approval, (b) self-assignment is removed from scope, (c) self-assignment requires lightweight manager confirmation. **This is a blocking design decision.**

**Known gap (source-doc grounding):** Domain entities have no Notification entity or event log. Proactive due-date alerting (A4) is only partially supported — workflows reference overdue notifications but the entity model does not persist them. **Recommendation:** Introduce a Notification or Event entity during this phase to support alert persistence and delivery.

**Milestone:** Full assignment lifecycle works end-to-end. Reassignment requires and blocks on manager approval. Notifications fire for key events. Self-assignment policy is resolved and implemented.

**Assumption dependency:**
- A2 (manager-only assignment — in tension with self-assignment alternate flow)
- A7 (reassignment requires approval)
- A10 (reassignment blocks on approval)
- A4 (proactive due-date alerts — partially supported)

---

### Phase 4 — Status Dashboards and Completion Monitoring

**Goal:** Deliver the visibility layer for all user roles — status dashboards for office and field teams, and completion monitoring for managers.

**Scope:**
- Implement status tracking views filtered by Team.team_type (per A1 — office and field teams have distinct visibility needs)
- Enforce read-only access for office and field team dashboard consumers (per A5)
- Implement completion monitoring: manager drill-down into task completion status using Task.completed_at and the `monitors` relationship
- Implement overdue/at-risk surfacing on dashboards (connecting to notification infrastructure from Phase 3)

**Known gap (source-doc grounding):** The edge case noting that field team members may have intermittent connectivity implies an offline-capable status model. This is not reflected in any current entity or workflow definition. **Recommendation:** If offline field access is in scope, it should be designed explicitly — it is not currently grounded enough to implement without additional source-doc input.

**Milestone:** Office and field teams can view task status through role-appropriate dashboards. Managers can monitor completion and see at-risk items. Overdue alerts surface on dashboards.

**Assumption dependency:**
- A1 (distinct visibility needs for office vs field)
- A5/A11 (read-only access)
- A4 (proactive alerts — realized here in dashboard form)

---

## Implementation Priorities

Priority ordering within and across phases:

1. **Highest priority — entity model and permissions (Phase 1).** Everything depends on this. No workflow can be built without stable entities and enforced roles.
2. **High priority — request intake and triage (Phase 2).** This is the entry point for all work. Without it, nothing enters the system.
3. **High priority — assignment workflow (Phase 3, core path).** The primary operational workflow. Managers assigning work is the central use case.
4. **Medium priority — reassignment and notifications (Phase 3, secondary paths).** Important for operational resilience but depends on core assignment working first.
5. **Medium priority — status dashboards (Phase 4).** High user-facing value but depends on populated data from earlier phases.
6. **Lower priority — completion monitoring and overdue alerting (Phase 4, latter half).** Valuable but requires all upstream workflows to be functioning.

**Self-assignment resolution** is a priority gate — it blocks Phase 3 design finalization and should be resolved during Phase 2 implementation at the latest.

---

## Dependencies

### Internal sequencing dependencies

| Downstream capability | Depends on |
|---|---|
| Triage workflow | Core entities (Request, Task) and role model |
| Assignment workflow | Triage workflow (tasks must exist), Assignment entity, permission model |
| Reassignment workflow | Assignment workflow (assignments must exist), ReassignmentRequest entity |
| Notifications | Assignment + reassignment workflows (events to notify about), Notification entity (currently missing) |
| Status dashboards | Task status populated via workflows, Team.team_type for filtering, read-only permission enforcement |
| Completion monitoring | Task.completed_at populated, monitors relationship, dashboard infrastructure |
| Overdue alerting | Due dates set during triage/assignment, notification infrastructure, dashboard rendering |

### Entity model gaps to resolve

These gaps are documented in source-doc cross-references and must be resolved to avoid downstream implementation blockers:

1. **No classification attribute on Request** — needed for triage workflow step 3
2. **No Queue entity** — workflows reference queue routing but no entity models it
3. **No Notification/Event entity** — needed for assignment, reassignment, and overdue alert notifications
4. **No offline model** — field team intermittent connectivity edge case has no entity support

---

## Risks / Watchouts

### Design risks

- **Self-assignment tension (A2 vs. alternate flow).** This is the most significant unresolved design tension in the source docs. If not resolved cleanly, the permission model will either be too restrictive (blocking a useful operator workflow) or too permissive (undermining manager oversight). Resolve before Phase 3.

- **Notification entity gap.** Three workflows depend on notifications (assignment, reassignment, overdue), but no entity currently models notification persistence or delivery. If this is deferred past Phase 3, notifications will be ad-hoc or missing.

- **Queue routing gap.** Triage and assignment workflows reference queues, but no Queue entity exists. If queue-based routing is truly needed, the entity model must be extended. If it is not needed, the workflow descriptions should be updated to remove the reference.

### Scope risks

- **Offline field access.** The edge case about intermittent field connectivity is noted in workflows but has no entity or architectural support. Building offline-capable status views is a significantly larger effort than building online-only dashboards. This should be explicitly scoped in or out.

- **Proactive alerting depth.** A4 assumes proactive alerts for approaching and overdue deadlines. The current source docs partially support this (workflows mention it, entities do not model it). The depth of alerting — simple overdue flags vs. configurable thresholds vs. push notifications — is unspecified and could significantly affect scope.

### Assumption risks

- **A8 (1:1 Request-to-Task).** If real operations produce requests that split into multiple tasks, the 1:1 cardinality will need to change, affecting triage workflow and entity relationships. Currently supported by source docs but worth validating with domain stakeholders.

- **A5/A11 duplication.** These are duplicate assumptions (both state read-only team access). Recommend consolidating to avoid confusion in downstream implementation.

---

## Recommended Next Steps

1. **Resolve the self-assignment design tension (A2 vs. self_assignment alternate flow).** This is the single highest-priority design decision. Produce a clear policy and update source docs accordingly.

2. **Extend the entity model** to address the three identified gaps: Request classification attributes, Queue entity (or explicit removal from workflow descriptions), and Notification/Event entity.

3. **Scope the offline field access question.** Either add it to a future phase with explicit entity/architecture support, or explicitly mark it out of scope.

4. **Begin Phase 1 implementation** — entity model, role model, permission boundaries. This can proceed in parallel with the design decisions above as long as the entity extensions are incorporated before Phase 1 is closed.

5. **Validate A8 (1:1 Request-to-Task cardinality)** with domain stakeholders before triage workflow implementation locks in the constraint.

6. **Consolidate duplicate assumptions A5 and A11** in the assumptions registry to maintain clarity.
