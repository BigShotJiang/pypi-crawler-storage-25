# Product Requirements Document (PRD)

---

## Product Overview

This product is an internal task management and work-dispatch system designed to give operations teams a structured, transparent workflow from incoming request through task completion. It replaces ad-hoc or fragmented coordination by formalizing request intake, triage, assignment, due-date tracking, reassignment approval, and completion monitoring into a single system with role-appropriate visibility.

The system serves four distinct user groups—operators, managers, office teams, and field teams—each with specific capabilities and visibility boundaries. Its core value proposition is operational clarity: every request is triaged before assignment, every assignment has a due date, every reassignment requires approval, and every stakeholder sees status appropriate to their role.

---

## User Roles

### Operator
- Receives and triages incoming requests
- Classifies requests and routes them to the appropriate queue
- May, under certain conditions, self-assign tasks (see Assumptions below for open tension on this point)

### Manager
- Assigns triaged tasks to team members with due dates
- Approves or rejects reassignment requests
- Monitors task completion and overdue status
- Has full read-write authority over assignments and reassignment decisions

### Office Team
- Views task status filtered to office-relevant work
- Read-only access; does not modify tasks or assignments directly

### Field Team
- Views task status filtered to field-relevant work
- Read-only access; does not modify tasks or assignments directly
- May operate under intermittent connectivity conditions (see Edge Cases)

> **Assumption [A6]:** Managers and operators are distinct roles with non-overlapping primary responsibilities. This is well-supported across source docs.

> **Assumption [A1]:** Office and field teams have distinct status visibility needs, implying filtered or separate dashboard views rather than a single shared view.

---

## Core User Journeys

### Journey 1: Request Triage
**Actor:** Operator

1. Operator receives an incoming request through the single intake channel.
2. Operator reviews the request details.
3. Operator classifies the request (type, urgency).
4. Operator routes the request to the appropriate queue.
5. System creates a Task entity linked to the originating Request via a 1:1 `triages_into` relationship.
6. Task enters a "triaged, awaiting assignment" state.

**Postcondition:** A discrete Task exists, decoupled from the raw Request, ready for manager assignment.

> **Assumption [A3]:** Triage is a discrete step that precedes assignment. Request and Task are separate entities. This is strongly supported by entity modeling (Request → triages_into → Task).

> **Assumption [A8]:** Each request maps to exactly one task after triage. 1:1 cardinality is enforced.

> **Source gap noted:** The domain entities do not currently model request classification attributes (type, urgency) or a Queue entity, despite workflows referencing both. These will need to be addressed in architecture/implementation.

### Journey 2: Work Assignment
**Actor:** Manager

1. Manager reviews queued, triaged tasks.
2. Manager selects a task and assigns it to a team member.
3. Manager sets a due date on the task.
4. System creates an Assignment record linking the task to the assignee, capturing `assigned_by` and `assigned_at`.
5. Assignee is notified of the new assignment.

**Postcondition:** Task has an owner, a due date, and an active assignment record.

> **Assumption [A9]:** Due dates are set per-task (not per-request) and are established during the assignment step.

> **Assumption [A2 — tension]:** Source docs state that only managers can assign work. However, `user_workflows.json` includes an alternate flow for operator self-assignment. This PRD treats manager assignment as the primary flow and self-assignment as an alternate (see below). This tension must be resolved.

### Journey 3: Status Tracking
**Actors:** Office Team, Field Team

1. Team member opens the status dashboard.
2. System displays tasks filtered by the team member's team type (office or field).
3. Team member views current task statuses, assignees, and due dates.
4. View is read-only; no modification actions are available.

**Postcondition:** Stakeholder has current visibility into relevant task status without needing to contact managers.

> **Assumption [A5/A11]:** Office and field teams have read-only access. They do not modify tasks directly.

### Journey 4: Reassignment Approval
**Actors:** Assignee (initiator), Manager (approver)

1. Current assignee or manager initiates a reassignment request.
2. System creates a ReassignmentRequest with status `pending`.
3. Manager reviews the reassignment request.
4. Manager approves or rejects the request.
5. If approved, system updates the task assignment to the new assignee. If rejected, the original assignment remains.
6. Relevant parties are notified of the outcome.

**Postcondition:** Task assignment is updated (if approved) with full audit trail via ReassignmentRequest entity.

> **Assumption [A7/A10]:** Reassignment is a controlled, approval-gated process. The task remains assigned to the original owner until a manager explicitly approves the change.

### Journey 5: Completion Monitoring
**Actor:** Manager

1. Manager opens the completion monitoring view.
2. System surfaces tasks approaching or past their due dates.
3. Manager can drill down into individual tasks to review status and history.
4. System proactively highlights overdue or at-risk tasks.

**Postcondition:** Manager has actionable visibility into completion health and can intervene on at-risk work.

> **Assumption [A4 — partially supported]:** Due-date tracking is expected to include proactive alerts for approaching or overdue deadlines. Workflows reference overdue notifications, but the domain entity model currently lacks a Notification or Alert entity. This gap must be resolved in architecture.

---

## Functional Requirements

### Request Intake & Triage
- **FR-1:** The system shall provide a single intake channel for incoming requests.
- **FR-2:** Operators shall be able to review, classify, and route requests.
- **FR-3:** Triage shall produce a Task entity linked 1:1 to the originating Request.
- **FR-4:** Triaged tasks shall be visible in assignment queues for managers.

### Assignment
- **FR-5:** Managers shall be able to assign triaged tasks to team members.
- **FR-6:** Every assignment shall require a due date to be set on the task.
- **FR-7:** Assignment shall record the assigning manager (`assigned_by`) and timestamp (`assigned_at`).
- **FR-8:** Assignees shall be notified upon assignment.

### Due-Date Tracking & Alerts
- **FR-9:** The system shall track due dates per task.
- **FR-10:** The system shall proactively surface tasks that are approaching or past their due date.
- **FR-11:** Overdue notifications shall be delivered to relevant parties (manager at minimum).

### Status Dashboards
- **FR-12:** Office team members shall see a filtered, read-only view of task status relevant to office work.
- **FR-13:** Field team members shall see a filtered, read-only view of task status relevant to field work.
- **FR-14:** Dashboard views shall display task status, assignee, and due-date information.
- **FR-15:** Dashboard content shall be filterable by team type.

### Reassignment
- **FR-16:** The system shall allow reassignment requests to be created for assigned tasks.
- **FR-17:** Reassignment requests shall require manager approval before taking effect.
- **FR-18:** Approved reassignments shall update the task's active assignment.
- **FR-19:** Rejected reassignments shall preserve the original assignment unchanged.
- **FR-20:** Reassignment outcomes shall be communicated to relevant parties.

### Completion Monitoring
- **FR-21:** Managers shall have a monitoring view showing task completion status.
- **FR-22:** The monitoring view shall enable drill-down into individual task details.
- **FR-23:** Tasks marked complete shall record a `completed_at` timestamp.

---

## Alternate / Exceptional Flows

### Operator Self-Assignment
**Source:** `user_workflows.json` alternate flow `self_assignment`

An operator may pick up and assign a task to themselves without manager intervention. This flow is in **tension** with assumption A2 (only managers assign work). The product must resolve whether:
- Self-assignment bypasses manager approval entirely (permitted action for operators), or
- Self-assignment creates a pending assignment that still requires manager confirmation, or
- Self-assignment is restricted to specific task types or conditions.

> **Resolution needed:** This tension is documented but unresolved in source docs. Implementation should not proceed on this flow without explicit product decision.

### Request Rejection at Triage
If an incoming request is invalid, duplicate, or out of scope, the operator should be able to close the request without creating a task. Source docs do not explicitly model this flow, but it is a natural implication of a triage step.

> **Source grounding: thin.** No explicit reject/close path is described in workflows or entities. This is an inferred requirement.

### Reassignment Request Withdrawn
If the initiator of a reassignment request withdraws it before manager review, the request should be closeable without requiring an approve/reject decision.

> **Source grounding: thin.** Workflows model approve/reject but do not mention withdrawal.

---

## Acceptance-Oriented Behavior Notes

### Triage Boundary
- A Request that has not been triaged must not appear in the assignment queue.
- A Task must not exist without a parent Request.
- Triage is a one-time, irreversible transition per request (1:1 cardinality).

### Assignment Integrity
- A Task cannot be assigned without a due date.
- A Task cannot have more than one active assignment at a time.
- Assignment records are immutable audit artifacts; reassignment creates a new Assignment, not an update to the old one.

### Reassignment Gating
- A reassignment request in `pending` status must block any other reassignment attempt for the same task.
- Manager approval is the only path to changing an active assignment (aside from the unresolved self-assignment alternate flow).

### Dashboard Access Control
- Office and field team members must not have access to any write/modify actions on tasks.
- Dashboard filtering by team type must not leak tasks belonging to the other team type.

### Notification Expectations
- Notifications are expected on: assignment, reassignment outcome (approved/rejected), and overdue status.
- The notification delivery mechanism is not specified in source docs. This is an open implementation decision.

### Connectivity Edge Case
- Field team members may experience intermittent connectivity.
- The status dashboard should degrade gracefully under poor connectivity (e.g., show last-known state, indicate staleness).

> **Source grounding: thin.** The edge case is mentioned in `user_workflows.json` cross-references but no offline-capable model is described in domain entities.

---

## Assumptions

The following assumptions materially shape this PRD. All are sourced from the assumptions registry and cross-reference analysis.

| ID | Assumption | Coherence | Notes |
|----|-----------|-----------|-------|
| A1 | Office and field teams have distinct status visibility needs | Supported | Implies separate or filtered dashboard views |
| A2 | Only managers can assign work and approve reassignments | **Tension** | Self-assignment alternate flow contradicts this; needs resolution |
| A3 | Triage is a discrete workflow step before task assignment | Supported | Request and Task are separate entities |
| A4 | Due-date tracking includes proactive alerts | Partially supported | Workflows reference alerts; entity model lacks Notification entity |
| A5 | Office and field teams have read-only status access | Supported | Explicit in workflow assumptions |
| A6 | Managers are a distinct role from operators | Supported | Role attribute and ownership assumptions confirm |
| A7 | Reassignment requires manager approval | Supported | ReassignmentRequest entity models this |
| A8 | Each request maps to exactly one task | Supported | 1:1 cardinality enforced |
| A9 | Due dates are per-task, not per-request | Supported | due_date attribute is on Task only |
| A10 | Reassignment blocks on manager approval | Supported | Status attribute and workflow confirm |

### Known Source-Doc Gaps Affecting This PRD

1. **No request classification model.** Workflows reference classifying requests by type and urgency during triage, but no entity attributes capture this. FR-2 assumes this will be addressed.
2. **No Queue entity.** Workflows reference routing to queues and viewing queued requests, but no Queue entity exists. FR-4 assumes queues will be modeled.
3. **No Notification entity.** Multiple workflows reference notifications, but the entity model has no Notification or Alert entity. FR-10/FR-11 assume this will be addressed in architecture.
4. **No offline/connectivity model.** Field team connectivity edge case is flagged but unmodeled.
5. **Self-assignment tension unresolved.** A2 and the self_assignment alternate flow directly conflict. This must be resolved before implementation.

---

*This PRD is grounded in product_brief.json, user_workflows.json, domain_entities.json, and assumptions_registry.json. Where source evidence is thin, this is noted explicitly. No content in this document intentionally contradicts source-doc assertions.*