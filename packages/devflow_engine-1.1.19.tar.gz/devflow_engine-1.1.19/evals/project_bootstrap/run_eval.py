from __future__ import annotations

import argparse
import json
import os
import subprocess
import tempfile
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml

REPO_ROOT = Path(__file__).resolve().parents[2]
DEVFLOW_BIN = REPO_ROOT / ".venv" / "bin" / "devflow"

REQUIRED_CASE_IDS = {
    "new_python",
    "new_typescript",
    "new_monorepo_py_ts",
    "existing_repo_import",
}
SUPPORTED_FLOW_TYPES = {"NEW_PROJECT", "IMPORT_EXISTING_REPO"}
SUPPORTED_EXECUTION_STATUSES = {"PASS", "FAIL", "STUBBED", "KNOWN_GAP", "NOT_IMPLEMENTED"}
COPY_PROVISION_STRATEGY = "COPY_PROVISION_SCRIPT"
LOCAL_ONLY_UNTIL_APPROVED = "LOCAL_ONLY_UNTIL_APPROVED"
VERCEL_FREE_TIER = "VERCEL_FREE_TIER"
EXCLUDED = "EXCLUDED"
REAL_LOCAL = "REAL_LOCAL"
EXISTING_REPO_STORY_SYNTHESIS_RULE = (
    "Existing repo import should explicitly exclude story synthesis expectations "
    "because that flow is intentionally stubbed."
)
CLARIFY_COMMAND_REFERENCE = (
    "python3 <(gh api repos/Nuosis/clarify/contents/scripts/provision_from_template.py "
    "--jq '.content' | base64 -d)"
)
BACKEND_PROVISION_FIXTURE = REPO_ROOT / "tests" / "fixtures" / "backend_provision" / "provision_from_template.py"


class DatasetValidationError(ValueError):
    """Raised when the eval dataset shape or required rules are invalid."""


@dataclass(frozen=True)
class CommandRecord:
    argv: list[str]
    cwd: str
    returncode: int
    stdout: str
    stderr: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "argv": list(self.argv),
            "cwd": self.cwd,
            "returncode": self.returncode,
            "stdout": self.stdout,
            "stderr": self.stderr,
        }


@dataclass(frozen=True)
class CaseReport:
    case_id: str
    flow_type: str
    status: str
    checks: list[str]
    notes: list[str]
    commands: list[CommandRecord]
    duration_ms: int

    def to_dict(self) -> dict[str, Any]:
        return {
            "case_id": self.case_id,
            "flow_type": self.flow_type,
            "status": self.status,
            "checks": list(self.checks),
            "notes": list(self.notes),
            "duration_ms": self.duration_ms,
            "commands": [command.to_dict() for command in self.commands],
        }


@dataclass
class EvalContext:
    commands: list[CommandRecord]

    def run(self, argv: list[str], *, cwd: Path, env: dict[str, str]) -> subprocess.CompletedProcess[str]:
        proc = subprocess.run(argv, cwd=str(cwd), env=env, capture_output=True, text=True, check=False)
        self.commands.append(
            CommandRecord(
                argv=list(argv),
                cwd=str(cwd),
                returncode=proc.returncode,
                stdout=proc.stdout,
                stderr=proc.stderr,
            )
        )
        return proc


def load_dataset(dataset_path: Path) -> dict[str, Any]:
    payload = yaml.safe_load(dataset_path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise DatasetValidationError("Dataset root must be a mapping.")
    return payload


def validate_dataset(dataset: dict[str, Any]) -> list[str]:
    checks: list[str] = []

    defaults = _require_mapping(dataset, "defaults")
    cases = dataset.get("cases")
    if not isinstance(cases, list) or not cases:
        raise DatasetValidationError("Dataset must contain a non-empty 'cases' list.")

    if defaults.get("execution_mode") != "real_local_with_explicit_gaps":
        raise DatasetValidationError(
            "defaults.execution_mode must be 'real_local_with_explicit_gaps'."
        )
    checks.append("defaults.execution_mode")

    supported_flow_types = set(_require_list(defaults, "supported_flow_types"))
    if supported_flow_types != SUPPORTED_FLOW_TYPES:
        raise DatasetValidationError(
            f"defaults.supported_flow_types must be exactly {sorted(SUPPORTED_FLOW_TYPES)}."
        )
    checks.append("defaults.supported_flow_types")

    supported_statuses = set(_require_list(defaults, "supported_execution_statuses"))
    if supported_statuses != SUPPORTED_EXECUTION_STATUSES:
        raise DatasetValidationError(
            f"defaults.supported_execution_statuses must be exactly {sorted(SUPPORTED_EXECUTION_STATUSES)}."
        )
    checks.append("defaults.supported_execution_statuses")

    if defaults.get("backend_python_provisioning_rule") != (
        "For Python backend scaffolds in this eval work, use Clarify provisioning by COPY/provision script, not clone."
    ):
        raise DatasetValidationError(
            "defaults.backend_python_provisioning_rule must match the required policy exactly."
        )
    checks.append("defaults.backend_python_provisioning_rule")

    if defaults.get("clarify_provisioning_command_reference") != CLARIFY_COMMAND_REFERENCE:
        raise DatasetValidationError(
            "defaults.clarify_provisioning_command_reference must match the required command exactly."
        )
    checks.append("defaults.clarify_provisioning_command_reference")

    if defaults.get("backend_default_deploy_behavior") != (
        "local only until explicit user approval for production; when approved later, review README auto-deploy steps."
    ):
        raise DatasetValidationError(
            "defaults.backend_default_deploy_behavior must match the required deploy behavior exactly."
        )
    checks.append("defaults.backend_default_deploy_behavior")

    if defaults.get("frontend_default_deploy_target") != "Vercel free tier":
        raise DatasetValidationError("defaults.frontend_default_deploy_target must be 'Vercel free tier'.")
    checks.append("defaults.frontend_default_deploy_target")

    if defaults.get("existing_repo_import_story_synthesis_rule") != EXISTING_REPO_STORY_SYNTHESIS_RULE:
        raise DatasetValidationError(
            "defaults.existing_repo_import_story_synthesis_rule must match the required exception exactly."
        )
    checks.append("defaults.existing_repo_import_story_synthesis_rule")

    seen_case_ids: set[str] = set()
    for case in cases:
        if not isinstance(case, dict):
            raise DatasetValidationError("Each case must be a mapping.")
        case_id = _require_string(case, "case_id")
        if case_id in seen_case_ids:
            raise DatasetValidationError(f"Duplicate case_id: {case_id}")
        seen_case_ids.add(case_id)
        flow_type = _require_string(case, "flow_type")
        if flow_type not in SUPPORTED_FLOW_TYPES:
            raise DatasetValidationError(f"Unsupported flow_type for {case_id}: {flow_type}")
        _require_mapping(case, "stack")
        _require_mapping(case, "inputs")
        expectations = _require_mapping(case, "expectations")
        _validate_case_expectations(case_id=case_id, expectations=expectations)
        checks.append(f"case:{case_id}")

    missing_case_ids = REQUIRED_CASE_IDS - seen_case_ids
    if missing_case_ids:
        raise DatasetValidationError(f"Dataset is missing required cases: {sorted(missing_case_ids)}")
    checks.append("required_case_ids")
    return checks


def build_case_report(case: dict[str, Any]) -> CaseReport:
    case_id = str(case["case_id"])
    flow_type = str(case["flow_type"])
    expectations = dict(case["expectations"])
    checks = ["dataset_shape_valid"]
    notes = list(expectations.get("required_notes", []))
    start = time.monotonic()
    ctx = EvalContext(commands=[])

    if case_id == "new_typescript":
        status, extra_checks, extra_notes = _execute_new_typescript_case(ctx)
    elif case_id == "existing_repo_import":
        status, extra_checks, extra_notes = _execute_existing_repo_import_case(ctx)
    elif case_id == "new_python":
        status, extra_checks, extra_notes = _execute_new_python_case(ctx)
    elif case_id == "new_monorepo_py_ts":
        status, extra_checks, extra_notes = _execute_new_monorepo_py_ts_case(ctx)
    else:
        status = "NOT_IMPLEMENTED"
        extra_checks = []
        extra_notes = ["No executor is implemented for this case."]

    checks.extend(extra_checks)
    notes.extend(extra_notes)
    duration_ms = int((time.monotonic() - start) * 1000)

    if status not in SUPPORTED_EXECUTION_STATUSES:
        raise DatasetValidationError(f"Case {case_id} produced unsupported status: {status}")
    return CaseReport(
        case_id=case_id,
        flow_type=flow_type,
        status=status,
        checks=checks,
        notes=notes,
        commands=list(ctx.commands),
        duration_ms=duration_ms,
    )


def build_report(dataset: dict[str, Any], dataset_path: Path) -> dict[str, Any]:
    validation_checks = validate_dataset(dataset)
    cases = dataset["cases"]
    case_reports = [build_case_report(case) for case in cases]
    status_counts: dict[str, int] = {}
    for report in case_reports:
        status_counts[report.status] = status_counts.get(report.status, 0) + 1

    return {
        "suite_id": dataset["suite_id"],
        "dataset_path": str(dataset_path),
        "execution_mode": dataset["defaults"]["execution_mode"],
        "validation": {
            "ok": True,
            "checks": validation_checks,
        },
        "summary": {
            "case_count": len(case_reports),
            "status_counts": status_counts,
        },
        "cases": [report.to_dict() for report in case_reports],
    }


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Real local evaluator for project bootstrap/import cases.")
    parser.add_argument(
        "--dataset",
        type=Path,
        default=Path(__file__).with_name("dataset.yaml"),
        help="Path to the eval dataset YAML.",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        help="Emit the report as JSON instead of text.",
    )
    return parser.parse_args()


def render_text_report(report: dict[str, Any]) -> str:
    lines = [
        f"Suite: {report['suite_id']}",
        f"Dataset: {report['dataset_path']}",
        f"Execution mode: {report['execution_mode']}",
        f"Validation: OK ({len(report['validation']['checks'])} checks)",
        "Summary:",
    ]
    for status, count in sorted(report["summary"]["status_counts"].items()):
        lines.append(f"  - {status}: {count}")
    lines.append("Cases:")
    for case in report["cases"]:
        lines.append(f"  - {case['case_id']} [{case['flow_type']}]: {case['status']} ({case['duration_ms']} ms)")
        if case["checks"]:
            lines.append(f"    checks: {', '.join(case['checks'])}")
        if case["notes"]:
            lines.append(f"    notes: {' | '.join(case['notes'])}")
        if case["commands"]:
            for command in case["commands"]:
                lines.append(
                    "    command: "
                    + " ".join(command["argv"])
                    + f" (cwd={command['cwd']}, rc={command['returncode']})"
                )
    return "\n".join(lines)


def main() -> int:
    args = parse_args()
    try:
        dataset = load_dataset(args.dataset)
        report = build_report(dataset, args.dataset.resolve())
    except (OSError, DatasetValidationError, yaml.YAMLError, AssertionError) as exc:
        error_payload = {"ok": False, "error": str(exc), "dataset_path": str(args.dataset)}
        if args.json:
            print(json.dumps(error_payload, indent=2, sort_keys=True))
        else:
            print(f"ERROR: {exc}")
        return 1

    if args.json:
        print(json.dumps(report, indent=2, sort_keys=True))
    else:
        print(render_text_report(report))
    return 0


def _require_mapping(payload: dict[str, Any], key: str) -> dict[str, Any]:
    value = payload.get(key)
    if not isinstance(value, dict):
        raise DatasetValidationError(f"'{key}' must be a mapping.")
    return value


def _require_list(payload: dict[str, Any], key: str) -> list[Any]:
    value = payload.get(key)
    if not isinstance(value, list):
        raise DatasetValidationError(f"'{key}' must be a list.")
    return value


def _require_string(payload: dict[str, Any], key: str) -> str:
    value = payload.get(key)
    if not isinstance(value, str) or not value.strip():
        raise DatasetValidationError(f"'{key}' must be a non-empty string.")
    return value


def _validate_case_expectations(*, case_id: str, expectations: dict[str, Any]) -> None:
    required_notes = expectations.get("required_notes")
    if not isinstance(required_notes, list) or not required_notes:
        raise DatasetValidationError(f"{case_id}.expectations.required_notes must be a non-empty list.")

    backend_provisioning = expectations.get("backend_provisioning")
    deploy_defaults = expectations.get("deploy_defaults")
    if case_id in {"new_python", "new_monorepo_py_ts"}:
        if not isinstance(backend_provisioning, dict):
            raise DatasetValidationError(f"{case_id}.expectations.backend_provisioning is required.")
        if backend_provisioning.get("strategy") != COPY_PROVISION_STRATEGY:
            raise DatasetValidationError(
                f"{case_id}.expectations.backend_provisioning.strategy must be {COPY_PROVISION_STRATEGY}."
            )
        if backend_provisioning.get("command_reference") != CLARIFY_COMMAND_REFERENCE:
            raise DatasetValidationError(
                f"{case_id}.expectations.backend_provisioning.command_reference "
                "must match the canonical Clarify command."
            )
        if not isinstance(deploy_defaults, dict) or deploy_defaults.get("backend") != LOCAL_ONLY_UNTIL_APPROVED:
            raise DatasetValidationError(
                f"{case_id}.expectations.deploy_defaults.backend must be {LOCAL_ONLY_UNTIL_APPROVED}."
            )

    if case_id in {"new_python", "new_monorepo_py_ts"} and expectations.get("execution_strategy") != REAL_LOCAL:
        raise DatasetValidationError(f"{case_id}.expectations.execution_strategy must be REAL_LOCAL.")

    if case_id in {"new_typescript", "new_monorepo_py_ts"} and (
        not isinstance(deploy_defaults, dict) or deploy_defaults.get("frontend") != VERCEL_FREE_TIER
    ):
        raise DatasetValidationError(
            f"{case_id}.expectations.deploy_defaults.frontend must be {VERCEL_FREE_TIER}."
        )

    if case_id == "existing_repo_import":
        if expectations.get("story_synthesis") != EXCLUDED:
            raise DatasetValidationError("existing_repo_import.expectations.story_synthesis must be EXCLUDED.")
        if expectations.get("execution_strategy") != REAL_LOCAL:
            raise DatasetValidationError(
                "existing_repo_import.expectations.execution_strategy must be REAL_LOCAL."
            )

    if case_id == "new_typescript" and expectations.get("execution_strategy") != REAL_LOCAL:
        raise DatasetValidationError("new_typescript.expectations.execution_strategy must be REAL_LOCAL.")


def _devflow_cmd() -> list[str]:
    if DEVFLOW_BIN.exists():
        return [str(DEVFLOW_BIN)]
    return ["uv", "run", "--project", str(REPO_ROOT), "devflow"]


def _base_env(home: Path) -> dict[str, str]:
    return {
        **os.environ,
        "DEVFLOW_HOME": str(home),
        "HOME": str(home),
        "GIT_CONFIG_NOSYSTEM": "1",
        "DEVFLOW_BACKEND_PROVISION_SCRIPT": str(BACKEND_PROVISION_FIXTURE),
    }


def _assert(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def _mk_bare_repo(tmp_path: Path, *, owner: str, repo: str, env: dict[str, str], ctx: EvalContext) -> Path:
    bare_root = tmp_path / "bare"
    bare_repo = bare_root / owner / f"{repo}.git"
    bare_repo.parent.mkdir(parents=True, exist_ok=True)

    r0 = ctx.run(["git", "init", "--bare", bare_repo.name], cwd=bare_repo.parent, env=env)
    _assert(r0.returncode == 0, r0.stderr)

    work = tmp_path / "work"
    work.mkdir()
    _assert(ctx.run(["git", "init"], cwd=work, env=env).returncode == 0, "git init failed")
    _assert(
        ctx.run(["git", "config", "user.email", "devflow@example.com"], cwd=work, env=env).returncode == 0,
        "git config email failed",
    )
    _assert(
        ctx.run(["git", "config", "user.name", "DevFlow"], cwd=work, env=env).returncode == 0,
        "git config name failed",
    )
    (work / "README.md").write_text("hi\n", encoding="utf-8")
    _assert(ctx.run(["git", "add", "README.md"], cwd=work, env=env).returncode == 0, "git add failed")
    _assert(ctx.run(["git", "commit", "-m", "init"], cwd=work, env=env).returncode == 0, "git commit failed")
    _assert(
        ctx.run(["git", "remote", "add", "origin", f"file://{bare_repo}"], cwd=work, env=env).returncode == 0,
        "git remote add failed",
    )
    _assert(
        ctx.run(["git", "push", "-u", "origin", "HEAD:main"], cwd=work, env=env).returncode == 0,
        "git push failed",
    )
    return bare_root


def _execute_new_python_case(ctx: EvalContext) -> tuple[str, list[str], list[str]]:
    with tempfile.TemporaryDirectory(prefix="project-bootstrap-new-python-") as tmp_dir_str:
        tmp_dir = Path(tmp_dir_str)
        home = tmp_dir / "home"
        home.mkdir()
        env = _base_env(home)
        dest = tmp_dir / "pythonproj"
        proc = ctx.run(
            _devflow_cmd() + ["project", "import", str(dest), "--init", "python"],
            cwd=tmp_dir,
            env=env,
        )
        _assert(proc.returncode == 0, proc.stdout + "\n" + proc.stderr)

        _assert(dest.exists(), "new python backend should create the requested workspace")
        _assert((dest / ".git").exists(), "new python backend should initialize a git repo")
        _assert((dest / "README.md").exists(), "new python backend should create README.md")
        _assert((dest / "pyproject.toml").exists(), "new python backend should create pyproject.toml")
        _assert((dest / ".devflow" / "execution.sqlite").exists(), "new python backend should bootstrap repo-local execution DB")

        manifest_path = dest / ".devflow" / "template_bootstrap.json"
        _assert(manifest_path.exists(), "new python backend should record template bootstrap policy")
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        backend = manifest.get("backend_provisioning") if isinstance(manifest, dict) else None
        deploy_defaults = manifest.get("deploy_defaults") if isinstance(manifest, dict) else None
        _assert(isinstance(backend, dict), "new python backend manifest must include backend_provisioning")
        _assert(backend.get("strategy") == COPY_PROVISION_STRATEGY, "python backend manifest must record copy provision strategy")
        _assert(backend.get("command_reference") == CLARIFY_COMMAND_REFERENCE, "python backend manifest must preserve canonical Clarify command reference")
        _assert(isinstance(deploy_defaults, dict), "new python backend manifest must include deploy_defaults")
        _assert(deploy_defaults.get("backend") == LOCAL_ONLY_UNTIL_APPROVED, "python backend deploy default must remain local-only")
        _assert(deploy_defaults.get("review_readme_auto_deploy_steps_after_approval") is True, "python backend deploy policy must require README review after approval")
        _assert((dest / ".devflow-backend-bootstrap.json").exists(), "python backend should record backend bootstrap metadata")
        _assert(
            (dest / "src").exists(),
            "python backend should create deterministic source tree",
        )

        combined = (proc.stdout + "\n" + proc.stderr).lower()
        _assert("project_id" in combined, "new python backend output must mention project_id")
        _assert("workspace" in combined, "new python backend output must mention workspace")

        return (
            "PASS",
            [
                "executed_real_cli_flow",
                "clarify_copy_provision_script_executed",
                "local_only_deploy_policy_recorded",
                "repo_registered",
            ],
            [
                "Real local check ran: devflow project import <dest> --init python.",
                "Python backend scaffold executed through the Clarify copy/provision-script path via a hermetic local fixture override.",
            ],
        )


def _execute_new_monorepo_py_ts_case(ctx: EvalContext) -> tuple[str, list[str], list[str]]:
    with tempfile.TemporaryDirectory(prefix="project-bootstrap-new-monorepo-") as tmp_dir_str:
        tmp_dir = Path(tmp_dir_str)
        home = tmp_dir / "home"
        home.mkdir()
        env = _base_env(home)
        dest = tmp_dir / "monorepo"
        proc = ctx.run(
            _devflow_cmd() + ["project", "import", str(dest), "--init", "monorepo-py-ts"],
            cwd=tmp_dir,
            env=env,
        )
        _assert(proc.returncode == 0, proc.stdout + "\n" + proc.stderr)

        combined = (proc.stdout + "\n" + proc.stderr).lower()
        _assert("project_id" in combined, "new monorepo output must mention project_id")
        _assert("workspace" in combined, "new monorepo output must mention workspace")
        _assert((dest / ".git").exists(), "new monorepo should create a git repo")
        _assert((dest / "README.md").exists(), "new monorepo should create root README.md")
        _assert((dest / "package.json").exists(), "new monorepo should create root package.json")
        _assert((dest / "backend" / "pyproject.toml").exists(), "new monorepo should create backend pyproject.toml")
        _assert((dest / "frontend" / "package.json").exists(), "new monorepo should create frontend package.json")
        _assert((dest / "frontend" / "tsconfig.json").exists(), "new monorepo should create frontend tsconfig.json")
        _assert((dest / "frontend" / "vercel.json").exists(), "new monorepo should create frontend vercel.json")
        _assert((dest / ".devflow" / "bootstrap_manifest.json").exists(), "new monorepo should create root bootstrap manifest")
        _assert((dest / ".devflow" / "execution.sqlite").exists(), "new monorepo should bootstrap repo-local execution DB")

        root_manifest = json.loads((dest / ".devflow" / "bootstrap_manifest.json").read_text(encoding="utf-8"))
        _assert(root_manifest["layout"] == "monorepo_py_ts", "root manifest must declare monorepo_py_ts layout")
        _assert(root_manifest["backend"]["path"] == "backend", "backend subdir must be deterministic")
        _assert(root_manifest["frontend"]["path"] == "frontend", "frontend subdir must be deterministic")
        _assert(
            root_manifest["backend"]["provisioning_strategy"] == COPY_PROVISION_STRATEGY,
            "backend must preserve copy provision strategy",
        )
        _assert(
            root_manifest["backend"]["default_deploy_behavior"] == LOCAL_ONLY_UNTIL_APPROVED,
            "backend default deploy behavior must remain local-only",
        )
        _assert(
            root_manifest["frontend"]["default_deploy_target"] == VERCEL_FREE_TIER,
            "frontend default deploy target must remain Vercel free tier",
        )

        backend_manifest = json.loads((dest / "backend" / ".devflow-backend-bootstrap.json").read_text(encoding="utf-8"))
        _assert(
            backend_manifest["provisioning_strategy"] == COPY_PROVISION_STRATEGY,
            "backend bootstrap metadata must record copy provision strategy",
        )
        _assert(
            backend_manifest["clarify_command_reference"] == CLARIFY_COMMAND_REFERENCE,
            "backend bootstrap metadata must preserve canonical Clarify command reference",
        )
        frontend_manifest = json.loads((dest / "frontend" / ".devflow-frontend-bootstrap.json").read_text(encoding="utf-8"))
        _assert(
            frontend_manifest["default_deploy_target"] == VERCEL_FREE_TIER,
            "frontend bootstrap metadata must record Vercel free tier",
        )

        reg_path = home / ".devflow" / "registry" / "projects.json"
        reg = json.loads(reg_path.read_text(encoding="utf-8"))
        _assert(
            any(Path(str(p.get("workspace_path"))).resolve() == dest.resolve() for p in reg["projects"]),
            "new monorepo should register the workspace",
        )

        return (
            "PASS",
            [
                "executed_real_cli_flow",
                "monorepo_layout_materialized",
                "copy_provision_semantics_recorded",
                "vercel_default_recorded",
                "repo_registered",
            ],
            ["Real local check ran: devflow project import <dest> --init monorepo-py-ts."],
        )


def _execute_new_typescript_case(ctx: EvalContext) -> tuple[str, list[str], list[str]]:
    with tempfile.TemporaryDirectory(prefix="project-bootstrap-new-typescript-") as tmp_dir_str:
        tmp_dir = Path(tmp_dir_str)
        home = tmp_dir / "home"
        home.mkdir()
        env = _base_env(home)
        dest = tmp_dir / "newproj"
        proc = ctx.run(
            _devflow_cmd() + ["project", "import", str(dest), "--init", "typescript"],
            cwd=tmp_dir,
            env=env,
        )
        _assert(proc.returncode == 0, proc.stdout + "\n" + proc.stderr)

        combined = (proc.stdout + "\n" + proc.stderr).lower()
        _assert("project_id" in combined, "project import --init output must mention project_id")
        _assert("workspace" in combined, "project import --init output must mention workspace")
        _assert((dest / ".git").exists(), "typescript import should create a git repo")
        _assert((dest / "README.md").exists(), "typescript import should create README.md")
        _assert((dest / "package.json").exists(), "typescript import should create package.json")
        _assert((dest / "tsconfig.json").exists(), "typescript import should create tsconfig.json")
        _assert((dest / "src" / "index.ts").exists(), "typescript import should create src/index.ts")
        _assert(
            (dest / ".devflow" / "execution.sqlite").exists(),
            "typescript import should bootstrap repo-local execution DB",
        )

        reg_path = home / ".devflow" / "registry" / "projects.json"
        reg = json.loads(reg_path.read_text(encoding="utf-8"))
        projects = reg["projects"]
        _assert(
            any(Path(str(p.get("workspace_path"))).resolve() == dest.resolve() for p in projects),
            "typescript import should register the workspace",
        )

        pkg = json.loads((dest / "package.json").read_text(encoding="utf-8"))
        _assert(bool(pkg.get("name")), "package.json should include a name")
        _assert(isinstance(pkg.get("scripts"), dict), "package.json should include scripts")

        return (
            "PASS",
            [
                "executed_real_cli_flow",
                "typescript_template_materialized",
                "repo_registered",
            ],
            ["Real local check ran: devflow project import <dest> --init typescript."],
        )


def _execute_existing_repo_import_case(ctx: EvalContext) -> tuple[str, list[str], list[str]]:
    with tempfile.TemporaryDirectory(prefix="project-bootstrap-existing-import-") as tmp_dir_str:
        tmp_dir = Path(tmp_dir_str)
        home = tmp_dir / "home"
        home.mkdir()
        env = _base_env(home)
        owner = "nuosis"
        repo = "importfixture"
        bare_root = _mk_bare_repo(tmp_dir, owner=owner, repo=repo, env=env, ctx=ctx)

        gitconfig = tmp_dir / "gitconfig"
        gitconfig.write_text(
            "\n".join(
                [
                    f"[url \"file://{bare_root}/\"]",
                    "    insteadOf = https://github.com/",
                    "",
                ]
            ),
            encoding="utf-8",
        )
        env["GIT_CONFIG_GLOBAL"] = str(gitconfig)

        proc1 = ctx.run(_devflow_cmd() + ["project", "import", f"{owner}/{repo}"], cwd=tmp_dir, env=env)
        _assert(proc1.returncode == 0, proc1.stdout + "\n" + proc1.stderr)
        proc2 = ctx.run(_devflow_cmd() + ["project", "import", f"{owner}/{repo}"], cwd=tmp_dir, env=env)
        _assert(proc2.returncode == 0, proc2.stdout + "\n" + proc2.stderr)

        ws = home / "repos" / repo
        _assert(ws.exists(), "existing repo import should create the workspace")
        _assert((ws / ".git").exists(), "existing repo import should clone a git repo")
        _assert(
            (ws / ".devflow" / "execution.sqlite").exists(),
            "existing repo import should bootstrap repo-local execution DB",
        )

        source_docs = ws / "ai_docs" / "context" / "source_docs"
        project_docs = ws / "ai_docs" / "context" / "project_docs"
        _assert(source_docs.exists(), "existing repo import should create source_docs")
        _assert(project_docs.exists(), "existing repo import should create project_docs")

        for name in [
            "product_brief.json",
            "user_workflows.json",
            "domain_entities.json",
            "assumptions_registry.json",
        ]:
            path = source_docs / name
            _assert(path.exists(), f"existing repo import should seed {name}")
            json.loads(path.read_text(encoding="utf-8"))

        reg_path = home / ".devflow" / "registry" / "projects.json"
        reg = json.loads(reg_path.read_text(encoding="utf-8"))
        matches = [p for p in reg["projects"] if p.get("owner") == owner and p.get("repo") == repo]
        _assert(len(matches) == 1, f"expected 1 registry entry for {owner}/{repo}, got {len(matches)}")
        entry = matches[0]
        _assert(
            entry.get("remote_url") == f"https://github.com/{owner}/{repo}.git",
            "existing repo import should record canonical remote URL",
        )
        _assert(
            Path(str(entry.get("workspace_path"))).resolve() == ws.resolve(),
            "existing repo import should register the cloned workspace path",
        )
        _assert(
            entry.get("registration_state") == "ready_for_source_scope",
            "existing repo import should reach ready_for_source_scope",
        )

        combined = (proc1.stdout + "\n" + proc1.stderr).lower()
        _assert("project_id" in combined, "existing repo import output must mention project_id")
        _assert("workspace" in combined, "existing repo import output must mention workspace")

        return (
            "PASS",
            [
                "executed_real_cli_flow",
                "existing_repo_cloned",
                "idempotent_rerun_verified",
                "story_synthesis_excluded",
            ],
            [
                "Real local check ran: devflow project import <owner/repo> with git url.insteadOf mapping.",
                "Story synthesis remains intentionally excluded from this case and was not treated as a regression.",
            ],
        )


if __name__ == "__main__":
    raise SystemExit(main())
