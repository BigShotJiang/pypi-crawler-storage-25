# Project Bootstrap Eval Dataset Schema

This eval now runs safe local bootstrap/import flows for the cases the product already supports, while keeping unsupported or intentionally excluded flows explicit instead of fake-passing them.

## Top-level fields

- `schema_version`: Dataset schema version string.
- `suite_id`: Stable identifier for the eval suite.
- `suite_title`: Human-readable suite name.
- `defaults`: Shared rules and enum references that apply across the suite unless a case narrows them.
- `cases`: List of concrete eval cases.

## `defaults` fields

- `execution_mode`: Expected runner behavior. This suite uses `real_local_with_explicit_gaps`.
- `default_case_status`: Default placeholder status enum.
- `supported_flow_types`: Allowed `flow_type` values.
- `supported_execution_statuses`: Allowed runner statuses.
- `backend_python_provisioning_rule`: Explicit policy for Python backend scaffolds in this eval.
- `clarify_provisioning_command_reference`: Canonical provisioning command reference. It must be documented exactly as:

```bash
python3 <(gh api repos/Nuosis/clarify/contents/scripts/provision_from_template.py --jq '.content' | base64 -d)
```

- `backend_default_deploy_behavior`: Default backend deploy policy.
- `frontend_default_deploy_target`: Default frontend deploy target.
- `existing_repo_import_story_synthesis_rule`: Explicit import-flow exception for story synthesis.

## Case fields

- `case_id`: Stable identifier for the eval case.
- `title`: Human-readable case name.
- `flow_type`: Enum describing which bootstrap path the case exercises.
- `stack`: Declares the intended backend/frontend/runtime shape.
- `inputs.request`: Plain-language bootstrap/import request this case stands in for.
- `expectations`: Case-specific execution strategy, required policies, exclusions, and notes.

## Execution strategies

### `execution_strategy`

- `REAL_LOCAL`: The runner must execute a real local CLI flow in an isolated temp workspace and verify artifacts.

Cases without `REAL_LOCAL` stay explicit gaps and must report a non-pass status with a reason.

## Enums

### `flow_type`

- `NEW_PROJECT`: New project bootstrap flow.
- `IMPORT_EXISTING_REPO`: Existing repository import flow.

### `backend_provisioning.strategy`

- `COPY_PROVISION_SCRIPT`: Use Clarify provisioning by copy/provision script, not clone.

### `deploy_defaults.backend`

- `LOCAL_ONLY_UNTIL_APPROVED`: Backend stays local-only until explicit user approval for production. If approval is granted later, review README auto-deploy steps before proceeding.

### `deploy_defaults.frontend`

- `VERCEL_FREE_TIER`: Frontend defaults to Vercel free tier.

### `story_synthesis`

- `EXCLUDED`: The runner should not expect story synthesis output for this case.

### Runner status values

- `PASS`: Checks were executed for real and passed.
- `FAIL`: Checks were executed for real and failed.
- `STUBBED`: Recognized but intentionally stubbed. Not success.
- `KNOWN_GAP`: A real product or policy gap is being surfaced honestly. Not success.
- `NOT_IMPLEMENTED`: No safe supported execution path exists yet. Not success.

## How the runner behaves now

### Real executed cases

- `new_python`: runs `devflow project import <dest> --init python` in a temp workspace with a hermetic local provision-script override and verifies the backend provisioning/deploy policy artifacts.
- `new_typescript`: runs `devflow project import <dest> --init typescript` in a temp workspace and verifies repo/bootstrap/registry artifacts.
- `new_monorepo_py_ts`: runs `devflow project import <dest> --init monorepo-py-ts` in a temp workspace with a hermetic local backend provision-script override and verifies deterministic `backend/` and `frontend/` layout plus root bootstrap metadata.
- `existing_repo_import`: creates a local bare repo, redirects `https://github.com/...` cloning through `git url.insteadOf`, runs `devflow project import <owner/repo>` for real, reruns it to verify idempotence, and verifies bootstrap/registry artifacts.

## Required suite rules captured by this eval

- For Python backend scaffolds in this eval work, use Clarify provisioning by COPY/provision script, not clone.
- Provisioning command reference must be documented exactly as:

```bash
python3 <(gh api repos/Nuosis/clarify/contents/scripts/provision_from_template.py --jq '.content' | base64 -d)
```

- Backend default deploy behavior: local only until explicit user approval for production; when approved later, review README auto-deploy steps.
- Frontend default deploy target: Vercel free tier.
- Existing repo import explicitly excludes story synthesis expectations because that flow is intentionally stubbed.
- The runner must never treat excluded or unsupported flows as passing by omission.
