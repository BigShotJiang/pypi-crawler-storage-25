from __future__ import annotations

import importlib.util
import json
from pathlib import Path
from typing import Any

from ..shared.helpers import classify_route, load_node_prompt_text
from ..shared.models import ScenarioResult

SCENARIO_DIR = Path(__file__).with_name('scenarios')


def _load_module(path: Path):
    spec = importlib.util.spec_from_file_location(path.stem, path)
    module = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    spec.loader.exec_module(module)
    return module


def _collect_scenarios() -> list[tuple[Any, Any]]:
    pairs = []
    for scenario_path in sorted(SCENARIO_DIR.glob('*.py')):
        if scenario_path.name.endswith('_evals.py'):
            continue
        eval_path = scenario_path.with_name(f'{scenario_path.stem}_evals.py')
        pairs.append((_load_module(scenario_path), _load_module(eval_path)))
    return pairs


def run_scenario(payload: dict[str, Any]) -> dict[str, Any]:
    route_arm, route_payload = classify_route(str(payload.get('raw_text') or ''))
    return {'route_arm': route_arm, 'reason': route_payload.get('reason'), 'prompt_loaded': bool(load_node_prompt_text(__file__))}


def run_all() -> list[ScenarioResult]:
    results: list[ScenarioResult] = []
    for scenario_module, eval_module in _collect_scenarios():
        actual_output = run_scenario(dict(scenario_module.INPUT_PAYLOAD))
        passed, notes = eval_module.evaluate(actual_output)
        results.append(ScenarioResult(scenario_name=scenario_module.SCENARIO_NAME, passed=passed, actual_output=actual_output, expected_behavior=dict(scenario_module.EXPECTED_BEHAVIOR), notes=notes))
    return results


if __name__ == '__main__':
    print(json.dumps([item.model_dump() for item in run_all()], indent=2, sort_keys=True))
