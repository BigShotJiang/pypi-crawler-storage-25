EVAL_CRITERIA = {'route_arm_must_equal': 'ideation'}

def evaluate(actual_output: dict) -> tuple[bool, list[str]]:
    ok = actual_output.get('route_arm') == 'ideation'
    return ok, ([] if ok else ['expected ideation route'])
