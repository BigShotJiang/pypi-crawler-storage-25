SCENARIO_NAME = 'ideation_routing'
SCENARIO_DESCRIPTION = 'Routes a forward-looking software feature request into the ideation arm.'
INPUT_PAYLOAD = {'raw_text': 'Build a client portal that lets staff triage support requests and track approvals.'}
EXPECTED_BEHAVIOR = {'route_arm': 'ideation', 'reason_contains': 'software'}
