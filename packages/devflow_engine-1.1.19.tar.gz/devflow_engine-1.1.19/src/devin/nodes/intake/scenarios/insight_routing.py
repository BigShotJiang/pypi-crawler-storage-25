SCENARIO_NAME = 'insight_routing'
SCENARIO_DESCRIPTION = 'Routes a repo/operations question into the insight arm.'
INPUT_PAYLOAD = {'raw_text': 'What is the source-doc queue status for this project right now?'}
EXPECTED_BEHAVIOR = {'route_arm': 'insight', 'reason_contains': 'operational'}
