EVAL_CRITERIA = {'route_arm_must_equal': 'insight'}

def evaluate(actual_output: dict) -> tuple[bool, list[str]]:
    ok = actual_output.get('route_arm') == 'insight'
    return ok, ([] if ok else ['expected insight route'])
