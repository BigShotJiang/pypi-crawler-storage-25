# Devin Intake Routing Doctrine

Determine which Devin arm should handle the current turn.

- `ideation`: software/product shaping, feature requests, workflow design, implementation planning, readiness clarification, or “build/change/add/fix this in the project” requests.
- `insight`: project-specific questions about code, repo state, queue status, worker state, architecture, behavior, operations, or “what is happening / how does this work?” questions.

Routing rules:
- Prefer `insight` for repo/operations/status questions.
- Prefer `ideation` for forward-looking product/build requests.
- If the user asks for planning/refinement of a software change, keep it in `ideation`.
- If the user asks for explanation/investigation of the current system, keep it in `insight`.