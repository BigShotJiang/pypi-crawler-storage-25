from __future__ import annotations

from pathlib import Path

from devflow_engine.vendor.datalumina_genai.core.nodes.base import Node
from devflow_engine.vendor.datalumina_genai.core.task import TaskContext
from devflow_engine.idea.sufficiency import load_idea_source
from devin.nodes.shared.router import llm_route
from devin.nodes.shared.helpers import dfs_node_running, load_node_prompt_lines, pipeline_root, resolve_project_id, store_run, write_json

class DevinIntakeNode(Node):
    async def process(self, task_context: TaskContext) -> TaskContext:
        event = task_context.event
        repo_root = Path(event.repo_root)
        store, run_id = store_run()
        node_exec_id = store.create_node_attempt(run_id=run_id, node_id='devin_intake', node_name='DevinIntake', attempt=1)
        project_id = resolve_project_id(repo_root, idea_id=event.idea_id)
        dfs_node_running(project_id=project_id, run_id=run_id, node_id='devin_intake', summary='Running Devin intake', idea_id=event.idea_id)
        raw_text, input_meta = load_idea_source(text=event.raw_text, source_path=Path(event.source_path) if event.source_path else None)
        route_arm, route_payload = llm_route(raw_text=raw_text, repo_root=repo_root, project_id=project_id)
        payload = {'project_id': project_id, 'raw_text': raw_text, 'input_meta': input_meta, 'route': route_payload, 'route_arm': route_arm, 'prompt_lines': load_node_prompt_lines(__file__)}
        out_path = pipeline_root(repo_root, idea_id=event.idea_id, pipeline_key=event.pipeline_key) / 'devin_intake.json'
        write_json(out_path, payload)
        store.add_artifact(run_id=run_id, node_exec_id=node_exec_id, kind='devin_intake', uri=str(out_path), metadata={'route_arm': route_arm, 'project_id': project_id})
        store.mark_node_finished(node_exec_id=node_exec_id, status='succeeded', output=payload)
        task_context.metadata.update(payload)
        return task_context
