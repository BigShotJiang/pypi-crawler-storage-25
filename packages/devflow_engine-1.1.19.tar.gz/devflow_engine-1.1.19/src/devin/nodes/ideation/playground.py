"""IdeationAgent playground — run scenarios against real Spicy-Server project with real PI.

Usage:
  python3 -m devin.nodes.ideation.playground --real-pi --project proj_75f63d30 --repo-root /Users/devflow/repos/Spicy-Server

This runs the real IdeationAgentNode against the Spicy-Server DevFlow project,
exercising the full PI harness with devflow-tools.ts extension enabled.
"""

from __future__ import annotations

import argparse
import asyncio
import importlib.util
import json
from pathlib import Path

from devin.nodes.ideation.node import IdeationAgentNode
from devin.nodes.shared.models import DevinAgentResponse, DevinChatDagEvent, ScenarioResult
from devflow_engine.vendor.datalumina_genai.core.task import TaskContext

SCENARIO_DIR = Path(__file__).with_name('scenarios')


def _parse_tool_calls_from_log(log_path: str | None) -> list[str]:
    """Extract tool call names from a PI JSONL log file.

    The log is JSONL where each line has {"line": ..., "stream": "stderr"|"stdout", "ts": ...}.
    We scan for lines containing tool-use markers (invoke calls in PI output)
    and return a deduplicated list of tool names called.
    """
    if not log_path:
        return []
    import json
    tool_names: list[str] = []
    seen = set()
    try:
        with open(log_path, encoding='utf-8') as fh:
            for line in fh:
                line = line.strip()
                if not line:
                    continue
                try:
                    entry = json.loads(line)
                except Exception:
                    continue
                text = entry.get('line', '')
                # PI devin tool invocations appear in stdout as structured JSON blocks
                # or in the raw output text. Look for tool name patterns.
                # Common patterns: "Using tool: X" or "invoke":{"name":"X"} or tool name prefixes
                for tool in (
                    'devflow_init_idea', 'devflow_amend_idea', 'devflow_commit_idea',
                    'idea_compliance_check', 'goldilocks_check', 'devin_insight',
                    'devflow_read_project_config', 'devflow_read_queue_summary',
                    'devflow_read_story_queue', 'devflow_read_worker_state',
                    'emit_start_working', 'emit_stop_working', 'emit_response',
                ):
                    if tool in text and tool not in seen:
                        seen.add(tool)
                        tool_names.append(tool)
    except Exception:
        pass
    return tool_names


def _load_module(path: Path):
    spec = importlib.util.spec_from_file_location(path.stem, path)
    module = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    spec.loader.exec_module(module)
    return module


def _collect_scenarios():
    pairs = []
    for scenario_path in sorted(SCENARIO_DIR.glob('*.py')):
        if scenario_path.name.endswith('_evals.py'):
            continue
        eval_path = scenario_path.with_name(f'{scenario_path.stem}_evals.py')
        if eval_path.exists():
            pairs.append((_load_module(scenario_path), _load_module(eval_path)))
    return pairs


def _precreate_idea_artifact(repo_root: Path, idea_id: str) -> None:
    """Pre-create a commit-ready idea artifact with drafts/current/manifest.json."""
    import json
    idea_dir = repo_root / '.devflow' / 'ideas' / idea_id
    idea_dir.mkdir(parents=True, exist_ok=True)
    artifact = {
        'idea_id': idea_id,
        'title': 'Client Onboarding Workflow',
        'problem': 'Small professional services firms lose revenue and reputation when client onboarding is slow and inconsistent.',
        'target_users': ['Internal client-facing staff (paralegals, assistants, admin) who manage the onboarding workflow'],
        'user_outcomes': [
            'Clients feel welcomed promptly',
            'Staff spend less time chasing documents',
            'No new client starts with confusion',
        ],
        'scope': 'Onboarding workflow system with document collection, task tracking, client portal, and status notifications.',
        'assumptions': ['Small professional services firms with 15-20 new clients per month'],
        'status': 'shaped',
    }
    (idea_dir / 'idea.json').write_text(json.dumps(artifact, indent=2) + '\n', encoding='utf-8')
    # Also create the drafts/current/manifest.json so devflow idea promote --draft-set current works
    drafts_dir = idea_dir / 'drafts' / 'current'
    drafts_dir.mkdir(parents=True, exist_ok=True)
    manifest = {
        'idea_id': idea_id,
        'draft_set_id': 'current',
        'created_at': '2026-04-22T00:00:00Z',
        'artifact_path': str(idea_dir / 'idea.json'),
        'status': 'shaped',
    }
    (drafts_dir / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')


async def _run_scenario_real_pi(scenario_module, eval_module, repo_root: Path, project_id: str) -> ScenarioResult:
    """Run a single scenario against the real IdeationAgentNode with real PI harness."""
    from devin.nodes.shared.helpers import set_runtime_store
    from devflow_engine.stores.execution_store import ExecutionStore

    input_payload = dict(scenario_module.INPUT_PAYLOAD)
    expected = dict(scenario_module.EXPECTED_BEHAVIOR)

    idea_id = input_payload.get('idea_id', f'{project_id}_scenario_{scenario_module.SCENARIO_NAME}')
    raw_text = input_payload.get('current_user_message', '')

    # Pre-create idea artifact if scenario requires it (mirrors real multi-turn init)
    if input_payload.get('_precreate_artifact'):
        _precreate_idea_artifact(repo_root, idea_id)

    event = DevinChatDagEvent(
        repo_root=str(repo_root),
        idea_id=idea_id,
        raw_text=raw_text,
        pipeline_key=f'scenario-{scenario_module.SCENARIO_NAME}',
    )

    metadata = {
        'raw_text': raw_text,
        'route': {'route_arm': 'ideation'},
        'project_id': project_id,
        'prior_messages': input_payload.get('prior_messages', []),
    }

    task_context = TaskContext(event=event, metadata=metadata)

    # Set up runtime store for this scenario
    db_path = repo_root / '.devflow' / 'execution.sqlite'
    store = ExecutionStore(db_path=db_path)
    import uuid, time
    run_id = store.create_run(
        dag_id='devin_chat_dag',
        dag_version='1.0',
        root_correlation_id=str(uuid.uuid4()),
        config={'project_id': project_id, 'scenario': scenario_module.SCENARIO_NAME},
    )
    set_runtime_store(store, run_id)

    node = IdeationAgentNode(task_context=None)
    try:
        result_ctx = await node.process(task_context)
        response_guidance = result_ctx.metadata.get('response_guidance', {})
        agent_terminal = result_ctx.metadata.get('agent_loop_terminal', {})
    except Exception as exc:
        set_runtime_store(None, None)
        return ScenarioResult(
            scenario_name=scenario_module.SCENARIO_NAME,
            passed=False,
            actual_output={'error': str(exc)},
            expected_behavior=expected,
            notes=[f'Node raised exception: {exc}'],
        )

    set_runtime_store(None, None)

    actual_output = {
        'response_message': response_guidance.get('response_message', ''),
        'response_kind': response_guidance.get('response_kind', agent_terminal.get('status', '')),
        'suggested_next_step': response_guidance.get('suggested_next_step', ''),
        'follow_up_questions': response_guidance.get('follow_up_questions', []),
        'style_notes': response_guidance.get('response_style_notes', []),
        'sufficient_idea': response_guidance.get('sufficient_idea', {}),
        'idea_artifact_exists': response_guidance.get('idea_artifact_exists', False),
        'tool_calls': _parse_tool_calls_from_log(response_guidance.get('invocation_log_path')),
    }

    try:
        passed, notes = eval_module.evaluate(actual_output)
    except Exception as exc:
        passed = False
        notes = [f'Eval raised exception: {exc}']

    return ScenarioResult(
        scenario_name=scenario_module.SCENARIO_NAME,
        passed=passed,
        actual_output=actual_output,
        expected_behavior=expected,
        notes=notes,
    )


def run_all_real_pi(repo_root: Path, project_id: str) -> list[ScenarioResult]:
    """Run all scenarios with real PI against the given project."""
    results = []
    created_ideas: list[str] = []
    for scenario_mod, eval_mod in _collect_scenarios():
        print(f"Running scenario: {scenario_mod.SCENARIO_NAME} ...", flush=True)
        input_payload = dict(scenario_mod.INPUT_PAYLOAD)
        idea_id = input_payload.get('idea_id', f'{project_id}_scenario_{scenario_mod.SCENARIO_NAME}')
        created_ideas.append(idea_id)
        result = asyncio.run(_run_scenario_real_pi(scenario_mod, eval_mod, repo_root, project_id))
        results.append(result)
        status = "PASS" if result.passed else "FAIL"
        print(f"  → {status}", flush=True)
    return results, created_ideas


def cleanup_test_artifacts(repo_root: Path, created_ideas: list[str]) -> None:
    """Remove idea artifacts and any pipeline artifacts created during eval."""
    import shutil
    ideas_dir = repo_root / '.devflow' / 'ideas'
    cleaned = []
    for idea_id in created_ideas:
        idea_path = ideas_dir / idea_id
        if idea_path.exists():
            shutil.rmtree(idea_path)
            cleaned.append(idea_id)
    print(f"\nCleanup: removed {len(cleaned)} test idea artifacts")
    for idea_id in cleaned:
        print(f"  removed: {idea_id}")


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='IdeationAgent playground — real PI against Spicy-Server')
    parser.add_argument('--real-pi', action='store_true', help='Run with real PI harness')
    parser.add_argument('--project', type=str, default='proj_75f63d30', help='DevFlow project ID')
    parser.add_argument('--repo-root', type=str, default='/Users/devflow/repos/Spicy-Server', help='Repo root path')
    args = parser.parse_args()

    if not args.real_pi:
        print("Use --real-pi to run against actual PI harness", file=__import__('sys').stderr)
        exit(1)

    repo_root = Path(args.repo_root)
    project_id = args.project

    print(f"Running IdeationAgent eval against Spicy-Server ({project_id})")
    print(f"Repo root: {repo_root}")
    print("-" * 60)

    results, created_ideas = run_all_real_pi(repo_root, project_id)

    print("-" * 60)
    print(f"\nResults: {sum(1 for r in results if r.passed)}/{len(results)} passed\n")

    for result in results:
        status = "PASS" if result.passed else "FAIL"
        print(f"  [{status}] {result.scenario_name}")
        for note in result.notes:
            print(f"        note: {note}")

    # Always clean up test artifacts
    cleanup_test_artifacts(repo_root, created_ideas)

    print("\n" + json.dumps([item.model_dump() for item in results], indent=2, sort_keys=True))