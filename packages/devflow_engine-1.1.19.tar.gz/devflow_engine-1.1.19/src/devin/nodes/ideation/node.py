"""IdeationAgent — active planning arm of Devin chat DAG."""

from __future__ import annotations

from pathlib import Path

from devflow_engine.devin2.pi_runner import run_devin2_pi_agent
from devflow_engine.idea.sufficiency import extract_sufficient_idea
from devflow_engine.vendor.datalumina_genai.core.nodes.base import Node
from devflow_engine.vendor.datalumina_genai.core.task import TaskContext

from devin.nodes.shared.helpers import (
    dfs_node_running,
    load_node_prompt_lines,
    pipeline_root,
    resolve_project_id,
    store_run,
    write_json,
)
from devin.nodes.shared.models import DevinAgentResponse


def _prior_messages_as_text(prior_messages: list) -> str:
    """Format prior conversation messages into a readable text for sufficiency extraction."""
    if not prior_messages:
        return ''
    lines = []
    for msg in prior_messages:
        role = msg.get('from') or msg.get('role', 'unknown')
        content = msg.get('text') or msg.get('content', '')
        if isinstance(content, list):
            content = ' '.join(c.get('text', '') for c in content if isinstance(c, dict))
        lines.append(f'{role}: {content}')
    return '\n'.join(lines)


def _build_context_for_ideation(input_payload: dict, project_id: str) -> dict:
    """Build context_payload for the IdeationAgent from scenario input.

    In real multi-turn usage, prior_messages carry context from earlier turns.
    When _precreate_artifact is set, an idea artifact already exists and the
    agent should commit it when the user says "create it" / "go ahead" etc.
    """
    sufficient_idea = input_payload.get('_sufficiency') or {}
    has_contract = bool(sufficient_idea) or {'problem', 'target_users', 'user_outcomes', 'scope'}.issubset(
        set(sufficient_idea.keys())
    )
    expected_status = 'ready_for_downstream' if has_contract else 'ideation_contract_response'
    return {
        'expected_status': expected_status,
        'precreated_artifact': input_payload.get('_precreate_artifact', False),
        'prior_messages': input_payload.get('prior_messages', []),
    }


class IdeationAgentNode(Node):
    async def process(self, task_context: TaskContext) -> TaskContext:
        event = task_context.event
        repo_root = Path(event.repo_root)
        store, run_id = store_run()
        node_exec_id = store.create_node_attempt(
            run_id=run_id, node_id='ideation_agent', node_name='IdeationAgent', attempt=1
        )
        project_id = str(
            task_context.metadata.get('project_id')
            or resolve_project_id(repo_root, idea_id=event.idea_id)
        )
        dfs_node_running(
            project_id=project_id,
            run_id=run_id,
            node_id='ideation_agent',
            summary='Running Devin ideation agent',
            idea_id=event.idea_id,
        )

        # Build sufficient_idea from current turn AND prior_messages so multi-turn context is available
        prior_messages = task_context.metadata.get('prior_messages') or []
        prior_text = _prior_messages_as_text(prior_messages)
        raw_text = str(task_context.metadata.get('raw_text') or event.raw_text or '')
        sufficient_idea = extract_sufficient_idea(raw_text, prior_text=prior_text if prior_text else None)

        # Check if idea artifact already exists (persisted in prior turn via devflow_init_idea).
        # If it exists, the agent can commit it regardless of text-extraction completeness —
        # the artifact IS the contract. Load it so we can inject its content into the context.
        idea_json_path = repo_root / '.devflow' / 'ideas' / event.idea_id / 'idea.json'
        idea_exists = idea_json_path.exists()
        persisted_idea: dict[str, Any] = {}
        if idea_exists:
            try:
                import json
                persisted_idea = json.loads(idea_json_path.read_text(encoding='utf-8'))
            except Exception:
                pass

        # Determine if we have enough to commit
        has_contract = {'problem', 'target_users', 'user_outcomes', 'scope'}.issubset(
            set(sufficient_idea.keys())
        )
        if idea_exists:
            has_contract = True
        expected_status = 'ready_for_downstream' if has_contract else 'ideation_contract_response'

        # Build session_id for emit tools
        session_id = f"idea:{project_id}:{event.idea_id}"

        # Load node prompt from prompt.md (matches Insight pattern)
        prompt_lines = load_node_prompt_lines(__file__)

        # Turn-specific operational guidance (kept minimal in node.py; rest is in prompt.md)
        guidance = prompt_lines + [
            f"Return response_kind='{expected_status}'.",
            'Treat inferred details as provisional when not explicitly provided.',
            'Keep momentum — do not re-ask answered questions.',
        ]

        context_payload = {
            'idea_id': event.idea_id,
            'current_user_message': raw_text,
            'route': task_context.metadata.get('route') or {},
            'expected_status': expected_status,
            'project_id': project_id,
            'repo_root': str(repo_root),
            'session_id': session_id,
            # Additional context from scenario input (e.g., pre-fetched insight for eval)
            'insight_context': task_context.metadata.get('insight_context') or '',
            # When idea artifact already exists, inject its actual content so the agent
            # operates on the real persisted idea, not garbled text-extracted fragments
            'persisted_idea': persisted_idea if persisted_idea else None,
            'idea_artifact_exists': idea_exists,
            'idea_artifact_path': str(idea_json_path) if idea_exists else '',
        }

        result = run_devin2_pi_agent(
            repo_root=repo_root,
            stage_name='devin_ideation_response',
            route_arm='ideation',
            context_payload=context_payload,
            operational_guidance=guidance,
            output_model=DevinAgentResponse,
            timeout_seconds=180,
        )

        model = DevinAgentResponse.model_validate(result.response_model.model_dump())
        invocation_log_path = str(result.invocation.log_path) if result.invocation.log_path else None

        # Re-extract sufficient_idea from the agent's response so fabricated content appears in output
        fabricated_idea = extract_sufficient_idea(model.response_message or '', prior_text=None)
        # Merge: use agent-fabricated fields, fall back to pre-computed input-based extraction
        merged_sufficient = {**sufficient_idea}
        for key in ['problem', 'target_users', 'user_outcomes', 'scope', 'assumptions']:
            if fabricated_idea.get(key):
                merged_sufficient[key] = fabricated_idea[key]

        # Build response payload with idea artifact state
        idea_json_path = repo_root / '.devflow' / 'ideas' / event.idea_id / 'idea.json'
        idea_exists = idea_json_path.exists()

        response_payload = {
            'idea_id': event.idea_id,
            'pipeline_dir': str(
                pipeline_root(repo_root, idea_id=event.idea_id, pipeline_key=event.pipeline_key)
            ),
            'sufficient_idea': merged_sufficient,
            'idea_artifact_exists': idea_exists,
            'response_message': model.response_message,
            'response_kind': model.response_kind,
            'suggested_next_step': model.suggested_next_step,
            'follow_up_questions': model.follow_up_questions,
            'response_style_notes': model.style_notes,
            'invocation_log_path': invocation_log_path,
        }

        out_path = (
            pipeline_root(repo_root, idea_id=event.idea_id, pipeline_key=event.pipeline_key)
            / 'ideation_response.json'
        )
        write_json(out_path, response_payload)

        store.add_artifact(
            run_id=run_id,
            node_exec_id=node_exec_id,
            kind='devin_ideation_response',
            uri=str(out_path),
            metadata={'response_kind': model.response_kind},
        )
        store.mark_node_finished(
            node_exec_id=node_exec_id, status='succeeded', output=response_payload
        )

        task_context.metadata['response_guidance'] = response_payload
        task_context.metadata['agent_loop_terminal'] = {
            'status': model.response_kind,
            **response_payload,
        }
        return task_context
