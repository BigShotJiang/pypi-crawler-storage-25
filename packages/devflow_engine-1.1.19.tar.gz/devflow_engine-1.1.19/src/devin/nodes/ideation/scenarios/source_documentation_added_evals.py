EVAL_CRITERIA = {
    'response_kind_must_be': 'ideation_contract_response',
    'uses_documentation_to_reshape': True,
    'ddr_persists': True,
    'references_specific_doc_elements': True,
}

def evaluate(actual_output: dict) -> tuple[bool, list[str]]:
    ok = True
    notes = []
    msg = str(actual_output.get('response_message') or '').lower()
    # Should reference the schema or documentation specifically
    # DDR should persist (mentioned in output)
    if not any(w in msg for w in ['schema', 'database', 'document', 'ddr', 'structure']):
        notes.append('does not reference specific doc elements')
    return ok, notes
