SCENARIO_NAME = 'user_says_create_it'
SCENARIO_DESCRIPTION = 'User and agent have iterated on an idea for several turns. User now says "create it" — agent should commit the idea to ready_for_downstream immediately, no questions.'
INPUT_PAYLOAD = {
    'current_user_message': 'Create it. Make it happen.',
    'idea_id': 'proj_75f63d30_ideas_createit_001',
    'project_id': 'proj_75f63d30',
    'repo_root': '/Users/devflow/repos/Spicy-Server',
    # Prior agent turn calls devflow_init_idea to persist the artifact before user says "create it".
    # This mirrors real multi-turn behavior where ideas are persisted before commitment.
    'prior_messages': [
        {'from': 'user', 'text': 'I want to improve how our team handles onboarding new clients'},
        {'from': 'agent', 'text': 'Let me understand your context better — what type of clients are you working with?'},
        {'from': 'user', 'text': 'Small professional services firms — lawyers, accountants, consultants'},
        {'from': 'agent', 'text': 'Got it. And roughly how many new clients per month are you onboarding?'},
        {'from': 'user', 'text': 'About 15-20 per month across all our advisors'},
        {'from': 'agent', 'text': 'Devflow_Init_Idea called — idea persisted in .devflow/ideas/proj_75f63d30_ideas_createit_001/.\n\nProblem: Small professional services firms lose revenue and reputation when client onboarding is slow and inconsistent.\nTarget users: Internal client-facing staff (paralegals, assistants, admin) who manage the onboarding workflow.\nUser outcomes: Clients feel welcomed promptly, staff spend less time chasing documents, no new client starts with confusion.\nScope: Onboarding workflow system with document collection, task tracking, client portal, and status notifications.'},
        {'from': 'user', 'text': 'Create it. Make it happen.'},
    ],
    # Pre-create the idea artifact so it exists for devflow_commit_idea to commit.
    # In real usage, devflow_init_idea is called in the prior turn and the artifact is created.
    # The eval harness mirrors this by ensuring the artifact exists before the "create it" turn.
    '_precreate_artifact': True,
}
EXPECTED_BEHAVIOR = {
    'response_kind': 'ready_for_downstream',
    'idea_artifact_exists': True,
    'idea_artifact_contains_all_fields': True,
    'no_clarifying_questions': True,
    'devflow_commit_called': True,
}