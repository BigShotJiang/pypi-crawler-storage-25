SCENARIO_NAME = 'vague_idea'
SCENARIO_DESCRIPTION = 'User has a vague idea and needs the agent to move it forward.'
INPUT_PAYLOAD = {
    'current_user_message': 'I want to improve how our team handles onboarding new clients.',
    'idea_id': 'proj_75f63d30_ideas_vague_001',
    'project_id': 'proj_75f63d30',
    'repo_root': '/Users/devflow/repos/Spicy-Server',
}
EXPECTED_BEHAVIOR = {
    'response_kind': 'ideation_contract_response',
    'produces_full_idea_artifact': True,
    'assumptions_traced': True,
    'asks_one_targeted_question': True,
    'no_premature_stories': True,
    'idea_artifact_exists': True,
}