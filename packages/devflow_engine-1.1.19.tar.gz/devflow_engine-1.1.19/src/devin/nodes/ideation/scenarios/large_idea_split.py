SCENARIO_NAME = 'large_idea_split'
SCENARIO_DESCRIPTION = 'User gives a large idea — agent splits into manageable shapes tracked separately.'
INPUT_PAYLOAD = {'current_user_message': 'We need a complete overhaul of how we manage projects end-to-end from first contact through delivery.'}
EXPECTED_BEHAVIOR = {'response_kind': 'ideation_contract_response', 'splits_into_manageable_shapes': True, 'tracks_each_separately': True, 'maintains_global_integrated_conversation': True, 'number_of_sub_ideas': 3}
