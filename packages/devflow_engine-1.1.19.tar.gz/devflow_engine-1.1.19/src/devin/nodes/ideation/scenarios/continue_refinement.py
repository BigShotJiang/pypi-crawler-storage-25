SCENARIO_NAME = 'continue_refinement'
SCENARIO_DESCRIPTION = 'User refines an existing idea — agent explains conversational shape change.'
INPUT_PAYLOAD = {
    'current_user_message': 'Actually, let us make it real-time instead of batch processing. Also we need mobile access.',
    'idea_id': 'proj_75f63d30_ideas_notify_001',
    'project_id': 'proj_75f63d30',
    'prior_messages': [
        {'role': 'user', 'content': 'Add a notification system to the client portal.'},
        {'role': 'assistant', 'content': '{"response_kind": "ideation_contract_response", "response_message": "Great — adding a notification system to the client portal. I need one clarifying question before shaping this: should notifications be real-time (push/live) or batch (daily/periodic digest)?", "follow_up_questions": ["Should notifications be real-time (push/live) or batch (daily/periodic digest)?"], "sufficiency_quotient": 0.4}'},
        {'role': 'user', 'content': 'Batch is fine for now, just needs to be reliable.'},
    ],
}
EXPECTED_BEHAVIOR = {'response_kind': 'ideation_contract_response', 'conversationally_explains_delta': True, 'incorporates_all_changes': True, 'mentions_ddr_persists': True, 'no_re_asking': True}
