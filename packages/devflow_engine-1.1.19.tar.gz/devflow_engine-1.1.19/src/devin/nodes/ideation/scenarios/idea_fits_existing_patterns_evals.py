EVAL_CRITERIA = {
    'response_kind_must_be': 'ideation_contract_response',
    'maps_to_existing_patterns': True,
    'references_codebase_conventions': True,
    'avoids_reinventing': True,
}

def evaluate(actual_output: dict) -> tuple[bool, list[str]]:
    ok = True
    notes = []
    msg = str(actual_output.get('response_message') or '').lower()
    # Must reference existing patterns in the codebase
    if not any(w in msg for w in ['existing', 'pattern', 'already', 'convention', 'structure', 'similar', 'current', 'already']):
        notes.append('does not reference existing codebase patterns')
        ok = False
    return ok, notes
