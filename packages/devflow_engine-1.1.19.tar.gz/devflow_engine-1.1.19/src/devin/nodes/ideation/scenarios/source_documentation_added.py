SCENARIO_NAME = 'source_documentation_added'
SCENARIO_DESCRIPTION = 'User adds source docs and agent reshapes the idea based on that documentation.'
INPUT_PAYLOAD = {'current_user_message': 'Here is the current database schema. Use it to shape the onboarding workflow idea.', 'has_ddr_artifacts': True}
EXPECTED_BEHAVIOR = {'response_kind': 'ideation_contract_response', 'uses_documentation_to_reshape': True, 'ddr_persists': True, 'references_specific_doc_elements': True}
