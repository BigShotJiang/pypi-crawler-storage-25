EVAL_CRITERIA = {
    'response_kind_must_be': 'ideation_contract_response',
    'splits_into_manageable_shapes': True,
    'tracks_each_separately': True,
    'maintains_global_integrated_conversation': True,
    'number_of_sub_ideas': 3,
}

def evaluate(actual_output: dict) -> tuple[bool, list[str]]:
    ok = True
    notes = []
    # Should produce sub-idea tracking
    # Look for indication of splitting in response
    msg = str(actual_output.get('response_message') or '').lower()
    if not any(w in msg for w in ['split', 'break', 'part', 'phase', 'stage', 'first', 'second']):
        notes.append('does not indicate splitting the idea into manageable shapes')
    return ok, notes
