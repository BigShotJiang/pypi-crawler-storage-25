EVAL_CRITERIA = {
    'response_kind_must_be': 'ideation_contract_response',
    'produces_full_idea_artifact': True,  # vague input → agent FABRICATES complete idea
    'assumptions_traced': True,
    'asks_one_targeted_question': True,  # fabricates AND asks one question to verify assumptions
    'no_premature_stories': True,
    'idea_artifact_exists': True,
}


def evaluate(actual_output: dict) -> tuple[bool, list[str]]:
    ok = True
    notes = []

    # Response kind check
    if actual_output.get('response_kind') != 'ideation_contract_response':
        ok = False
        notes.append(f"expected ideation_contract_response, got {actual_output.get('response_kind')}")

    # Must ask exactly one targeted question (the tool fabricates AND asks to validate assumptions)
    fqs = actual_output.get('follow_up_questions') or []
    if len(fqs) != 1:
        ok = False
        notes.append(f'expected exactly one follow-up question, got {len(fqs)}')

    # Must produce a FABRICATED complete idea
    msg = (actual_output.get('response_message') or '').lower()
    has_user_mention = any(w in msg for w in ['client', 'team', 'staff', 'user', 'onboarding', 'person'])
    has_outcome_mention = any(w in msg for w in ['outcome', 'result', 'benefit', 'improve', 'faster', 'reduce', 'consistent'])
    has_scope_mention = any(w in msg for w in ['scope', 'cover', 'include', 'system', 'workflow', 'process', 'portal', 'track'])

    if not has_user_mention:
        ok = False
        notes.append('fabricated idea does not mention who the target users are')
    if not has_outcome_mention:
        ok = False
        notes.append('fabricated idea does not mention intended outcomes or benefits')
    if not has_scope_mention:
        ok = False
        notes.append('fabricated idea does not describe the scope of what to build')

    # Assumptions must be mentioned in response_message (case-insensitive check for assumption mentions)
    assumption_phrases = ['assumption', 'assuming', "i'm assuming", "i assume", 'assumptions traced', 'assumptions:']
    if not any(phrase in msg for phrase in assumption_phrases):
        notes.append('no assumptions traced in fabricated idea')

    return ok, notes