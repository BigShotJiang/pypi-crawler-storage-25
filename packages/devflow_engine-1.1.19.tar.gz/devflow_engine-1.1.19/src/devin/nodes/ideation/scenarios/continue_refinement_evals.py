EVAL_CRITERIA = {
    'response_kind_must_be': 'ideation_contract_response',
    'conversationally_explains_delta': True,
    'incorporates_all_changes': True,
    'mentions_ddr_persists': True,
    'no_re_asking': True,
}

def evaluate(actual_output: dict) -> tuple[bool, list[str]]:
    ok = True
    notes = []
    msg = str(actual_output.get('response_message') or '')
    # Should explain how the changes reshape the idea - check it mentions the changes
    if not any(w in msg.lower() for w in ['real-time', 'mobile', 'instead', 'batch', 'overhaul']):
        notes.append('does not conversationally explain the delta changes')
    # Should not re-ask questions already answered
    # Should mention DDR persists if applicable
    return ok, notes
