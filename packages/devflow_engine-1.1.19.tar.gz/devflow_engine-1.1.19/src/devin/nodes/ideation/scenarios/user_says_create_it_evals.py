EVAL_CRITERIA = {
    'response_kind_must_be': 'ready_for_downstream',
    'no_clarifying_questions': True,
    'devflow_commit_called': True,  # agent returned ready_for_downstream = committed
}


def evaluate(actual_output: dict) -> tuple[bool, list[str]]:
    ok = True
    notes = []

    # Must be ready_for_downstream (agent committed when user said create it)
    if actual_output.get('response_kind') != 'ready_for_downstream':
        ok = False
        notes.append(f"expected ready_for_downstream, got {actual_output.get('response_kind')}")

    # Must not ask clarifying questions — user said create it, agent must commit
    fqs = actual_output.get('follow_up_questions') or []
    if fqs:
        ok = False
        notes.append(f'should not ask questions but got: {fqs}')

    return ok, notes