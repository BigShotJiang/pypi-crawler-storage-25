SCENARIO_NAME = 'idea_fits_existing_patterns'
SCENARIO_DESCRIPTION = 'User provides an idea and agent fits it into existing codebase patterns.'
INPUT_PAYLOAD = {
    'current_user_message': 'Add a notification system to the client portal.',
    'idea_id': 'proj_75f63d30_ideas_notify_002',
    'project_id': 'proj_75f63d30',
    'repo_root': '/Users/devflow/repos/Spicy-Server',
    'codebase_patterns_exist': True,
    # Inline insight context so the agent doesn't need to call devin_insight (which may fail
    # in eval due to --no-tools constraints on the PI subprocess)
    'insight_context': 'Spicy-Server uses FastAPI + Pydantic for APIs, JWT auth, PostgreSQL via Supabase. '
                     'Existing notification patterns: none yet — this would be the first real-time system. '
                     'Auth pattern: JWT Bearer tokens. DB: Supabase Postgres. '
                     'API conventions: routers in app/routers/, schemas in app/schemas/, '
                     'service layer in app/services/. No existing WebSocket infrastructure.',
}
EXPECTED_BEHAVIOR = {'response_kind': 'ideation_contract_response', 'maps_to_existing_patterns': True, 'references_codebase_conventions': True, 'avoids_reinventing': True}
