# Iterate arm contract

## Purpose

`Iterate` is the Devin chat arm for hyper-specific fixes, quick changes, and targeted improvements against an existing surface.

It fills the gap between:
- `Idea`, which shapes planning truth for broader downstream work
- `Insight`, which stays read-only and explanatory

## Recommended route set

Top-level intake routing should become:
- `idea`
- `insight`
- `iterate`
- `neither`

## Route into Iterate when

The user is asking for a bounded change against an existing surface, for example:
- fixing a concrete error
- making a small behavior change
- tweaking a page, component, route, or flow
- improving a narrow interaction without opening broad product planning

## Route away from Iterate when

### To `insight`
- the user only wants explanation, diagnosis, or investigation
- no implementation path is being requested yet

### To `idea`
- the request is broader feature or workflow planning
- the change is no longer task-scale
- success depends on new planning truth rather than a targeted delta

## Core objective

Own a targeted request from framing through verified completion, or stop with an honest blocked or promotion verdict.

## Primary objectives

1. Convert the request into a precise task artifact.
2. Ground the task in evidence, repro, or a red verification seam.
3. Supervise implementation through a bounded coding loop.
4. Keep scope tight and resist turning task work into ideation theater.
5. Preserve ownership boundaries: Iterator owns truth and validation, Coder owns implementation attempts.

## Derived non-goals

- Do not behave like broad ideation intake.
- Do not stay read-only when the user clearly wants a fix or change.
- Do not claim reproducibility without evidence.
- Do not claim completion without scoped verification.
- Do not broaden scope without explicit approval.
- Do not let the implementation worker redefine the task contract.

## Orchestration pattern

Preferred pattern: advisor-primary with one supervised coding subagent.

- Primary: `Iterator`
- Advisors: `Framer`, `Observer`
- Worker subagent: `Coder`

This should remain a simple accountable structure, not a peer swarm.

## Pipeline order for this node

The iterate lane should be designed in this order:
1. objectives and requirements
2. evals
3. tools and boundaries
4. harness and playground
5. prompt content only after the first four are stable

Cross-agent stage docs live in `pipeline/`.
Per-agent stage docs live in `agents/<agent>/`.

## Verification loop

1. Framer produces the task artifact.
2. Observer produces the observation artifact.
3. Iterator decides whether truth is sufficient to proceed.
4. Iterator spawns Coder.
5. Coder attempts the scoped delta.
6. Iterator validates against the observation seam, success criteria, and scope boundary.
7. If repairable but not aligned, Iterator respawns Coder with repair-specific context.
8. If aligned, Iterator returns completion.
9. If no longer task-scale or truth is missing, Iterator blocks or escalates clearly.

## Completion gate

Iterator may only return completion when all are true:
1. the confirmed repro no longer reproduces, or the scoped failing seam is green
2. success criteria are satisfied
3. the implemented change stayed within task scope
4. observation evidence and final behavior agree
5. no blocker remains that invalidates the claim
