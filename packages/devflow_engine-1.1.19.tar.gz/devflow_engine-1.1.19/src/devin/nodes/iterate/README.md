# Iterate node design scaffold

This directory is the design home for the proposed Devin `iterate` arm.

It now reflects Marcus's preferred agent-development pipeline explicitly:

1. objectives and requirements
2. evals
3. tools and boundaries
4. harness and playground
5. prompt deferred until the first four stages are accepted

## Directory map

- `contract.md` , top-level iterate contract, routing boundary, and orchestration shape
- `artifacts.md` , shared artifact contracts across the iterate lane
- `agent-roles.md` , high-level accountability split for Iterator, Framer, Observer, and Coder
- `pipeline/` , cross-agent design docs ordered by development stage
- `agents/` , per-agent design docs, each ordered by development stage
- `eval-plan.md` , consolidated eval inventory spanning routing, framing, observation, supervision, and completion truth
- `playground-contract.md` , lane-level harness and fixture contract
- `scenarios/` , planning docs for future scenario fixtures and eval implementations

## Design rules for this directory

- Design only, no implementation code
- No real prompt content yet
- Objectives lead, non-goals derive from objectives
- Evals come before tool affordances
- Tools are documented as bounded capabilities, not as permission theater
- Harness design tests contracts and truthfulness, not just style

## Current recommended orchestration

- pattern: advisor-primary
- primary owner: `Iterator`
- advisors: `Framer`, `Observer`
- supervised worker: `Coder`

The intent is one accountable owner with specialist artifacts constraining the coding loop, not a flat peer swarm.

## Prompt status

Prompt authoring is intentionally deferred. See `pipeline/05-prompt-deferred.md` for the acceptance rule.
