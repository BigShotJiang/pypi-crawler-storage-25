# Iterate design pipeline

This folder makes the development order explicit for the iterate lane.

Read and review in order:
1. `01-objectives-requirements.md`
2. `02-evals.md`
3. `03-tools-and-boundaries.md`
4. `04-harness-and-playground.md`
5. `05-prompt-deferred.md`

The first four stages are design inputs.
The fifth is a reminder that prompt authoring is intentionally delayed.
