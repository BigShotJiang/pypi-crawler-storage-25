from __future__ import annotations

from pathlib import Path

from devflow_engine.devin2.pi_runner import run_devin2_pi_agent
from devflow_engine.vendor.datalumina_genai.core.nodes.base import Node
from devflow_engine.vendor.datalumina_genai.core.task import TaskContext
from devin.nodes.shared.helpers import (
    dfs_node_running,
    load_node_prompt_lines,
    pipeline_root,
    resolve_project_id,
    store_run,
    write_json,
)
from devin.nodes.shared.models import DevinAgentResponse


class IterateAgentNode(Node):
    async def process(self, task_context: TaskContext) -> TaskContext:
        event = task_context.event
        repo_root = Path(event.repo_root)
        store, run_id = store_run()
        node_exec_id = store.create_node_attempt(
            run_id=run_id,
            node_id='iterate_agent',
            node_name='IterateAgent',
            attempt=1,
        )
        project_id = str(
            task_context.metadata.get('project_id')
            or resolve_project_id(repo_root, idea_id=event.idea_id)
        )
        dfs_node_running(
            project_id=project_id,
            run_id=run_id,
            node_id='iterate_agent',
            summary='Running Devin iterate agent',
            idea_id=event.idea_id,
        )
        guidance = load_node_prompt_lines(__file__) + [
            'Return exactly one truthful outcome kind.',
            'Keep the work task-scale and tied to the existing surface described by the user.',
            'Use available context and artifacts as the only truth source.',
        ]

        session_id = f"iterate:{project_id}:{event.idea_id}"

        context_payload = {
            'idea_id': event.idea_id,
            'current_user_message': str(task_context.metadata.get('raw_text') or event.raw_text or ''),
            'route': task_context.metadata.get('route') or {},
            'project_id': project_id,
            'repo_root': str(repo_root),
            'session_id': session_id,
        }
        result = run_devin2_pi_agent(
            repo_root=repo_root,
            stage_name='devin_iterate_response',
            route_arm='iterate',
            context_payload=context_payload,
            operational_guidance=guidance,
            output_model=DevinAgentResponse,
            timeout_seconds=90,
        )
        model = DevinAgentResponse.model_validate(result.response_model.model_dump())
        response_payload = {
            'idea_id': event.idea_id,
            'pipeline_dir': str(
                pipeline_root(repo_root, idea_id=event.idea_id, pipeline_key=event.pipeline_key)
            ),
            'response_message': model.response_message,
            'response_kind': model.response_kind,
            'suggested_next_step': model.suggested_next_step,
            'follow_up_questions': model.follow_up_questions,
            'response_style_notes': model.style_notes,
        }
        out_path = (
            pipeline_root(repo_root, idea_id=event.idea_id, pipeline_key=event.pipeline_key)
            / 'iterate_response.json'
        )
        write_json(out_path, response_payload)
        store.add_artifact(
            run_id=run_id,
            node_exec_id=node_exec_id,
            kind='devin_iterate_response',
            uri=str(out_path),
            metadata={'response_kind': model.response_kind},
        )
        store.mark_node_finished(
            node_exec_id=node_exec_id,
            status='succeeded',
            output=response_payload,
        )
        task_context.metadata['response_guidance'] = response_payload
        task_context.metadata['agent_loop_terminal'] = {
            'status': model.response_kind,
            **response_payload,
        }
        return task_context
