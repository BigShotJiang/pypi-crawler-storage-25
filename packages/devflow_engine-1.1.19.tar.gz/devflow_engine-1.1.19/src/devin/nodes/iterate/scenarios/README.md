# Iterate scenarios

Runnable scenario modules and evals for the Iterate arm.

## Scenario files

Each scenario has a `.py` file (scenario definition) and a matching `_evals.py` (evaluation criteria and `evaluate()` function).

### Arm-level scenarios
- `devin_iterate_routing.py` — routes to iterate correctly
- `iterate_error_fix.py` — reproducible error fix
- `iterate_quick_change.py` — targeted behavior change
- `iterate_to_insight_reroute.py` — reroute to insight via tool call
- `iterate_to_idea_promotion.py` — promote to idea via tool call

### Subagent scenarios
- `framer_task_framing.py` — vague request → well-formed task_artifact
- `framer_scope_boundary.py` — framer keeps scope bounded
- `observer_evidence_seam.py` — observer identifies failing seam from evidence
- `observer_repro_creation.py` — observer creates narrow, reproducible repro
- `coder_bounded_fix.py` — coder implements targeted fix matching framed task
- `coder_artifact_alignment.py` — coder output aligns with observation_artifact

## Running scenarios

```bash
# Run all scenarios
/Users/devflow/repos/devflow_engine/.venv/bin/python3 \
  /Users/devflow/repos/devflow_engine/playground/iterate_arm_playground.py

# Run specific scenario
/Users/devflow/repos/devflow_engine/.venv/bin/python3 \
  /Users/devflow/repos/devflow_engine/playground/iterate_arm_playground.py \
  --scenario-name <name>

# Run via shell runner
bash /Users/devflow/repos/devflow_engine/playground/run_iterate_scenarios.sh
```
