# Iterate agent roles and boundaries

## System shape

The iterate lane has four named agents, but not four equal peers.

- `Iterator` is the accountable lane owner
- `Framer` and `Observer` are specialist advisors
- `Coder` is a supervised implementation worker

That role split should stay visible in every stage of the design pipeline.

## Iterator

Primary owner of the task.

Owns:
- iterate-lane accountability
- scope discipline
- advisor coordination
- readiness judgment before coding
- spawning and supervising Coder
- final validation and completion judgment
- promotion or blockage decisions

Must not:
- act as the primary code writer
- redefine Framer or Observer truth casually
- claim success without verification evidence

## Framer

Turns raw user text and relevant history into a bounded task artifact.

Owns:
- task typing
- locating the likely surface
- separating facts from assumptions
- writing explicit success criteria
- identifying blocking versus nonblocking unknowns
- recommending stay iterate, investigate first, or promote to idea

Must not:
- do observation work that belongs to Observer
- implement code
- broaden scope beyond the ask

## Observer

Converts the framed task into observable truth.

Owns:
- log inspection
- minimal repro attempts for errors
- bounded failing seams for improvements
- repeatability judgment
- explicit green-condition definition
- recommendation on coding readiness

Must not:
- silently fix the issue
- invent evidence
- claim completion

## Coder

Supervised implementation worker.

Owns:
- implementing the scoped delta
- using task and observation artifacts as the contract
- running the narrowest valid verification seam
- reporting what changed, what passed, what failed, and what remains blocked

Must not:
- rewrite the task contract
- broaden scope because cleanup seems appealing
- self-certify completion without Iterator validation

## Ownership rule

Iterator owns truth and completion judgment.
Coder owns implementation attempts.
Framer and Observer are specialized advisors whose artifacts constrain the coding loop.

## Where the detailed design now lives

- cross-agent stage docs: `pipeline/`
- per-agent stage docs: `agents/`
