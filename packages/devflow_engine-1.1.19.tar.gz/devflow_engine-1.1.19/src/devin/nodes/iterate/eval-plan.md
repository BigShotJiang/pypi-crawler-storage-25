# Iterate eval plan

This file captures the pre-prompt eval targets that should exist before prompt writing or runtime wiring.

## Pipeline stance

The eval layer comes after objectives and requirements, but before tool affordances or playground implementation details.

For the iterate lane, evals should be readable at three levels:
- route and lane level
- per-agent accountability level
- end-to-end truthful completion level

## Route evals

1. route a concrete fix request into `iterate`
2. route an investigation-only request into `insight`
3. promote a broader feature or workflow request into `idea`
4. keep a small request in `iterate` instead of inflating it

## Framing evals

1. turn messy conversational input into a bounded task artifact
2. extract route, page, component, file, or function hints when present
3. distinguish current behavior from desired behavior clearly
4. write observable success criteria rather than vague aspirations
5. surface blocking unknowns when the request is underspecified

## Observation evals

1. confirm a reported error when evidence exists
2. report `not_confirmed` honestly when the error cannot be reproduced
3. create a bounded red seam for a targeted improvement
4. provide repro steps another agent can run
5. avoid inventing evidence when logs are silent
6. ask for more context when truth is genuinely missing

## Iterator supervision evals

1. refuse to spawn Coder before framing and observation are sufficient
2. respawn Coder after a near miss with tighter repair context
3. refuse completion when the observation seam is still red
4. refuse completion when success criteria are unmet
5. block honestly when missing truth prevents safe implementation
6. escalate when the task grows past iterate scale

## Coder evals

1. fix a reproducible error without unrelated drift
2. satisfy a targeted improvement seam
3. report partial progress honestly when the first attempt fails
4. stay within the scoped files and surfaces when the task is narrow
5. return actionable blocker detail when safe completion is impossible
6. improve on a second attempt when respawned with repair context

## Completion truth evals

1. no green claim without green seam
2. no success claim without requested user-visible outcome
3. no completion claim when repro truth was never established but was required
4. no completion claim after unauthorized scope expansion

## Detailed stage mapping

- cross-agent eval design: `pipeline/02-evals.md`
- agent-specific eval design: `agents/*/02-evals.md`
- scenario planning inputs: `scenarios/`

## Expected future repo mapping

When implementation begins, these eval categories should map cleanly into:
- intake routing scenarios for the new `iterate` arm
- iterate scenario fixtures under `src/devin/nodes/iterate/scenarios/`
- eventual `_evals.py` checks that mirror the existing ideation and insight harness style
