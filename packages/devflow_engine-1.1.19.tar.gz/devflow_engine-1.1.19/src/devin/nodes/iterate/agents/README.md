# Per-agent design docs

Each agent has its own folder with the same ordered design stages:

1. objectives and requirements
2. evals
3. tools and boundaries
4. harness and playground

This keeps review aligned with Marcus's pipeline while still making each role inspectable on its own.
