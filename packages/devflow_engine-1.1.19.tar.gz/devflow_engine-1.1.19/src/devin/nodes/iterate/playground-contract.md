# Iterate playground contract

A future Iterate playground should validate the arm as a whole, not just isolated prompt wording.

## Placement in the development pipeline

Harness and playground design is the fourth stage, after:
1. objectives and requirements
2. evals
3. tools and boundaries

This doc stays downstream of those decisions and should not invent them.

## Required scenario coverage

- reproducible error with logs
- non-reproducible reported error
- quick UI or behavior tweak
- targeted improvement with explicit success criteria
- coder first pass fails, second pass succeeds
- request that should route to `idea`
- request that should route to `insight`

## What the playground should verify

- routing correctness
- task artifact completeness
- observation honesty
- iterator supervision behavior
- coder respawn behavior
- completion truthfulness
- scope discipline
- readiness state transitions in `iterator_run`
- monotonic top-level artifact revisions
- promotion linkage through `promotion_handoff.json` when the lane exits to `idea` or `insight`
- attempt-scoped verifier artifact references and summaries
- exact ordinal attempt ids of the form `attempt-001`, `attempt-002`, and so on
- normalized verifier envelopes that stay parseable across verifier types

## Harness expectations

The eventual harness should be able to:
- load prior conversation turns
- provide repo root and project context
- feed a route payload into the iterate arm
- inspect generated artifacts under `.devflow/iterate/<task_id>/`
- inspect `iterator_run.run_state` and `iterator_run.readiness`
- inspect top-level artifact revisions and the exact revisions cited by readiness or promotion decisions
- inspect `promotion_handoff.json` and its source refs when work leaves iterate
- inspect attempt-scoped verification summaries and raw verifier outputs separately
- assert that attempt directories sort in execution order via `attempt-<NNN...>` ids
- read shared verifier-envelope fields such as `overall_result`, `green_condition_alignment`, and `evidence_refs` without depending on verifier-specific payload structure
- inspect tool-call or worker-attempt traces
- evaluate terminal response guidance and disposition

## Fixture expectations

Each fixture should make clear:
- user request
- relevant prior turns
- project and repo context
- expected route outcome
- expected artifact shape
- expected readiness or blocker verdict
- expected completion or escalation behavior

## Per-agent harness hooks

- `Iterator` needs supervision and terminal-verdict inspection
- `Framer` needs task-artifact inspection
- `Observer` needs evidence and green-condition inspection
- `Coder` needs attempt-report and narrow-verification inspection

## Guardrail

The playground should not treat superficial harness success as proof of real coding quality. It should only verify the bounded contract the Iterate arm claims to satisfy.
