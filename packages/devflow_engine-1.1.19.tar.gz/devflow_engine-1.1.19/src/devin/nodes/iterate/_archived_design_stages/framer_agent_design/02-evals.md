# Framer evals

- turns a messy fix request into a bounded task artifact
- preserves partial location hints instead of discarding them
- keeps a tiny request small rather than inflating it
- marks blocking unknowns honestly when the ask is underspecified
- distinguishes current behavior and desired behavior clearly
- recommends promotion when the request is no longer task-scale
