# Iterate harness and playground design

## Purpose

The harness should exercise the lane as an orchestration contract, not just as prompt prose.

## Required harness abilities

- inject route context and prior turns
- inspect authored artifacts at each stage
- inspect iterate artifacts under `.devflow/iterate/<task_id>/`
- simulate coder retries and near misses
- compare terminal claims against observation truth and success criteria
- verify that readiness state transitions happen before and after coder attempts at the right times
- verify monotonic revision bumps on top-level artifacts when framing, observation, or supervision state changes
- inspect `promotion_handoff.json` when work exits to `idea` or `insight`
- read attempt-scoped verifier artifacts without requiring them to be inlined into `iterator_run.json`
- assert deterministic attempt ordering via ordinal ids like `attempt-001`
- parse a shared verifier-artifact envelope before descending into verifier-specific payloads

## Minimum fixture families

- reproducible error fix
- targeted improvement with a bounded failing seam
- ambiguous request needing framing discipline
- non-confirmed issue requiring honest blockage
- broader request that must promote to `idea`
- read-only request that must route to `insight`

## Success condition

The harness is good when it can catch false-positive completions, scope drift, missing-artifact shortcuts, incorrect iterator state transitions, missing promotion linkage, broken artifact revision discipline, non-monotonic attempt ids, and verifier outputs that skip the shared normalization envelope.
