# Iterate tools and boundaries

## Purpose

This is stage 3 in Marcus's iterate design order. By the time this file is written, the lane objective and eval expectations should already be stable.

The point here is not to list every possible runtime permission. The point is to define which capability classes each role needs in order to satisfy the stage-1 and stage-2 contract, and which capability classes would let that role collapse into another role.

## Tooling principle

Describe capabilities in responsibility terms, not vendor or provider terms.

Good examples:
- repo inspection
- log and trace inspection
- bounded test execution
- artifact read and write

Bad examples:
- naming a provider-specific tool without explaining which contract requirement it serves
- granting broad execution rights to compensate for unclear ownership

## Shared lane capability classes

The iterate lane as a whole needs access to these capability classes:
- conversation and history reading
- repository and project surface inspection
- logs, traces, screenshots, and repro surfaces when relevant
- artifact read and write surfaces
- narrow verification seam execution
- supervised implementation execution

These are lane-level needs. They are not automatically granted to every role equally.

## Role capability boundaries

### Iterator
Needs:
- read access to conversation context and shared artifacts
- enough inspection capability to judge route fit, readiness, and final evidence
- authority to spawn or supervise Coder
- write access to iterator-owned run records, monotonic revision updates, promotion handoff records, and final disposition

Must not become:
- the default implementation worker
- the substitute observer who handwaves missing evidence
- the substitute framer who rewrites the task mid-loop to make an attempt look successful

### Framer
Needs:
- conversation and history reading
- project and surface inspection sufficient to localize the ask
- artifact write access for `task_artifact`

Must not have responsibility for:
- running broad repro or verification work that belongs to Observer
- implementation execution
- final completion judgment

### Observer
Needs:
- evidence-source inspection such as logs, traces, screenshots, and repo context
- bounded repro execution and narrow red-seam creation
- artifact write access for `observation_artifact`

Must not have responsibility for:
- silently editing code to make repro disappear
- redefining task scope
- returning final completion on behalf of Iterator

### Coder
Needs:
- repository read and write access within the supervised work area
- implementation execution capability
- narrow verification execution aligned to the task and observation seam
- ability to append implementation and verification notes to the run record

Must not have responsibility for:
- changing route classification
- redefining success criteria
- deciding that missing evidence is good enough
- writing the final verdict as if implementation were the same thing as truth

## Boundary rules that should survive runtime implementation

- missing evidence should trigger context requests, blockage, or promotion, not bluffing
- missing task clarity should trigger framing repair, not coder improvisation
- scope growth should trigger promotion review, not quiet expansion of the task
- read-only user intent should route to `insight`, even if implementation would be easy
- artifact revisions should advance explicitly when durable top-level truth changes, rather than relying on implicit last-write-wins semantics
- only Iterator should stamp promotion linkage or write `promotion_handoff.json`
- provider convenience must not override role boundaries

## Practical anti-collapse checks

A tools design is probably wrong if any of these become normal:
- Iterator frequently edits code directly because it is faster
- Framer runs deep repros because the task artifact was thin
- Observer fixes small issues while inspecting evidence
- Coder rewrites task meaning in order to declare success

Those are not efficiency wins. They are signs that the lane contract is dissolving.

## Minimum acceptance bar for moving to stage 4

This stage is ready for harness and playground design only when reviewers can answer all of these clearly:
- which capability classes are required by the lane overall
- which of those capabilities belong to each role
- which boundary violations would invalidate the advisor-primary model
- how the tools model preserves Iterator as the single accountable owner
