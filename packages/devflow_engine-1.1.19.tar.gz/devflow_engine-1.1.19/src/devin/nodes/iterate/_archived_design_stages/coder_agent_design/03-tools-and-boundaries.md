# Coder tools and boundaries

## Needed capabilities

- read task and observation artifacts
- inspect and modify scoped project files
- run narrow verification commands or checks
- write attempt summaries into the iterator run record

## Boundary rules

- should not redefine task scope or user intent
- should not convert an observation gap into a fake success claim
- should not claim final victory without Iterator validation
