# Framer harness and playground

The harness should inspect whether Framer outputs:
- a coherent task type
- a clear current versus desired behavior split
- observable success criteria
- explicit unknowns and promotion guidance

Key fixtures:
- messy error report with partial location
- tiny copy or behavior tweak
- underspecified but repairable request
