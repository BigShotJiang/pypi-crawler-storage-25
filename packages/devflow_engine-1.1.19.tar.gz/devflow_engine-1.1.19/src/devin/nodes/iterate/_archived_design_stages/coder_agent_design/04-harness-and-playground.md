# Coder harness and playground

The harness should inspect:
- whether the implementation stayed in scope
- whether the chosen verification seam was narrow and relevant
- whether the attempt report is honest about passes, failures, and blockers
- whether repair retries materially improve alignment

Key fixtures:
- reproducible fix succeeds in one pass
- first pass fails, second pass succeeds
- safe completion is impossible and the blocker is reported clearly
