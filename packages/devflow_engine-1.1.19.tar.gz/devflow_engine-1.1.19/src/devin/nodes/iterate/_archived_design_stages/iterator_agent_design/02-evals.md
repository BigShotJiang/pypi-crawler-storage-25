# Iterator evals

- declines to spawn Coder when task artifact is vague
- declines to spawn Coder when observation artifact is inconclusive for a required repro
- respawns Coder with a precise repair reason after a near miss
- refuses completion when the green condition is still red
- refuses completion when success criteria are only partially satisfied
- promotes to `idea` when scope expansion becomes necessary
- returns a blocked verdict when safe progress depends on missing evidence
