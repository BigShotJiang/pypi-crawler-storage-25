# Observer evals

- confirms a reported failure when logs or repro evidence support it
- reports `not_confirmed` honestly when the issue cannot be reproduced
- creates a bounded red seam for a targeted improvement
- provides repro steps another role can execute
- records the expected green condition clearly
- returns `needs_more_context` when truth is genuinely insufficient
