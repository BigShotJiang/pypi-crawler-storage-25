# Prompt deferred

Prompt authoring for the iterate lane is intentionally deferred.

Prompt work should start only after:
1. objectives and requirements are accepted
2. evals are accepted
3. tools and boundaries are accepted
4. harness and playground expectations are accepted

Until then, prompt placeholders are acceptable, but real prompt content is out of scope for this directory pass.
