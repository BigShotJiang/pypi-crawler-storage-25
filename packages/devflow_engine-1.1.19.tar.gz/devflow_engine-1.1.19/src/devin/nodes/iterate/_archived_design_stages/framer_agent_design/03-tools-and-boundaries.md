# Framer tools and boundaries

## Needed capabilities

- read conversation context and project hints
- inspect lightweight repo clues when necessary to localize the surface
- write the task artifact

## Boundary rules

- should not collect evidence that belongs in observation truth
- should not run implementation changes
- should not hide uncertainty behind overconfident framing prose
