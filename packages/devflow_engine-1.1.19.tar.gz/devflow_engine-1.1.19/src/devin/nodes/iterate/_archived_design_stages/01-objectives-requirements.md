# Iterate objectives and requirements

## Why this stage exists

This is stage 1 in Marcus's iterate design order:
1. objectives and requirements
2. evals
3. tools and boundaries
4. harness and playground
5. prompt content only after the first four stages are stable

If this file is vague, every later stage will drift. The point here is to lock the lane objective, routing boundary, role ownership, and completion requirements before anyone talks about tools or prompt wording.

## Lane objective

`iterate` owns a bounded change request on an existing surface and carries it from messy ask to one of three truthful outcomes:
- verified completion
- honest blocked verdict
- explicit promotion out of iterate

This lane is for task-scale execution, not for read-only diagnosis and not for broad product planning.

## What must be true for a request to belong in iterate

A request belongs in `iterate` only when all of these are plausibly true:
- the user wants a change, not just an explanation
- the target is an existing surface, behavior, or failure
- the work can be framed as a bounded task artifact
- success can be checked by a scoped observation seam or equivalent proof
- the change does not require new planning truth at story or feature scale

If any of those fail, routing should change instead of forcing the work through iterate.

## Routing requirements

### Route to `iterate`
Route to `iterate` when the ask is a targeted fix, quick change, or narrow improvement against an existing route, page, component, workflow step, API behavior, or failure mode.

### Route to `insight`
Route to `insight` when the user wants investigation, explanation, diagnosis, or read-only analysis without asking for implementation.

### Route to `idea`
Route to `idea` when framing reveals that the work is no longer task-scale, needs new product or workflow planning, or cannot be truthfully described as a bounded delta on an existing surface.

### Re-route during execution
Initial routing is not permanent. If Framer or Observer discovers that the task is actually read-only or broader-planning work, Iterator must re-route honestly instead of preserving the original lane choice for convenience.

## Truth requirements

### Task truth before coding
A coding attempt requires a bounded `task_artifact` with:
- current behavior
- desired behavior
- explicit success criteria
- known scope boundary
- blocking unknowns called out separately from assumptions

### Observation truth before completion
A completion claim requires an `observation_artifact` that establishes one of these:
- a confirmed repro that later stops reproducing, or
- a bounded red-to-green verification seam for the requested improvement

### Honest uncertainty
If evidence is missing, repro cannot be confirmed, or the green condition is weak, the lane must say that plainly. Missing truth is a blocker signal, not a reason to improvise confidence.

## Supervision requirements

### Iterator is the accountable owner
`Iterator` owns lane judgment, readiness to code, respawn decisions, routing changes, and final disposition.

### Framer and Observer constrain the loop
`Framer` and `Observer` are not optional flavor agents. Their artifacts are the contract that bounds what `Coder` is allowed to do and what `Iterator` is allowed to approve.

### Coder stays subordinate to artifacts
`Coder` implements the scoped delta and reports evidence. `Coder` does not redefine scope, success criteria, readiness, or completion truth.

## Scope requirements

The iterate lane must:
- stay at task scale
- name the affected surface as concretely as possible
- expose scope growth immediately
- prefer blocked or promoted verdicts over fake completion
- resist unrelated cleanup, opportunistic refactors, or stealth feature work

## Required shared artifacts

The lane contract depends on four shared artifacts:
- `task_artifact`, authored by Framer and approved for use by Iterator
- `observation_artifact`, authored by Observer and used by Iterator as the truth seam
- `iterator_run`, owned by Iterator with coder attempts recorded inside it
- `promotion_handoff`, authored by Iterator only when work exits iterate for `idea` or `insight`

These artifacts are the cross-agent operating contract. If an important judgment is not grounded in one of them, the design is underspecified.

All durable top-level iterate artifacts should use monotonic integer revisions so readiness and promotion decisions can point to concrete artifact revisions rather than vague "latest" state.

## Role ownership summary

- `Iterator` owns route fit, readiness, supervision, respawn logic, and final verdict
- `Framer` owns bounded task construction and promotion recommendations discovered during framing
- `Observer` owns evidence, repro, green-condition definition, and coding-readiness recommendation
- `Coder` owns implementation attempts and narrow verification execution under supervision

## Minimum acceptance bar for moving to stage 2

This stage is ready for eval design only when reviewers can answer all of these clearly:
- what counts as iterate versus insight versus idea
- what artifact truth must exist before coding starts
- what completion evidence Iterator is allowed to trust
- what each of the four agents owns and must not absorb
- what conditions force blockage or promotion instead of completion
