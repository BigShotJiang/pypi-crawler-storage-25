# Observer harness and playground

The harness should inspect:
- evidence summaries
- repro steps
- repeatability status
- green-condition definition
- readiness verdict

Key fixtures:
- error confirmed by logs
- user-reported error not confirmed
- targeted improvement with a red seam
