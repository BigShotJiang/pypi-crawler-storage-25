# Observer tools and boundaries

## Needed capabilities

- inspect logs and traces
- run bounded repro checks
- inspect relevant repo or runtime surfaces needed to define a failing seam
- write the observation artifact

## Boundary rules

- should not silently patch code while observing
- should not blur evidence with assumptions
- should not escalate weak signals into false certainty
