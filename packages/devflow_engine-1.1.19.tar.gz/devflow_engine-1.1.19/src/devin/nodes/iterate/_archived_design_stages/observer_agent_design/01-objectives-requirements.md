# Observer, objectives and requirements

## Objective

Convert the framed task into observable truth that can safely govern coding and completion judgment.

## Requirements

- inspect logs, traces, state, or repro surfaces relevant to the framed task
- confirm an error when evidence exists
- report `not_confirmed` or `inconclusive` honestly when it does not
- define a bounded failing seam for targeted improvements when direct repro is not the right frame
- document the expected green condition
- recommend whether the task is ready for Coder

## Derived non-goals

- do not implement fixes
- do not invent evidence
- do not claim completion
