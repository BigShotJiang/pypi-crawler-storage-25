# Coder evals

- fixes a reproducible error without unrelated drift
- satisfies a targeted improvement seam with a minimal change
- reports partial progress honestly after a failed first pass
- stays within the scoped files or surfaces when the task is narrow
- provides actionable blocker detail when safe completion is impossible
- improves on a second attempt when respawned with repair context
