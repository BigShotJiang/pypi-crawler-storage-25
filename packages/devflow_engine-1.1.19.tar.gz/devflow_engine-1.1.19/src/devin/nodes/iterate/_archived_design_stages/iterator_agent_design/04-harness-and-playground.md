# Iterator harness and playground

The harness should be able to inspect:
- readiness decisions
- respawn decisions
- terminal verdict selection
- consistency between verdict, artifacts, and observed verification state

Key fixtures:
- near miss then repair success
- missing truth blocks coding
- unauthorized scope growth forces promotion
