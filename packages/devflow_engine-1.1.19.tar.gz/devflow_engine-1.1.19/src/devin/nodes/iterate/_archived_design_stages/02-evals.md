# Iterate evals by pipeline stage

## Purpose

This is stage 2 in Marcus's iterate design order. Its job is to prove that the stage-1 contract is testable before anyone specifies tools, harnesses, or prompts.

A good eval here answers: "what concrete failure would tell us this iterate design is lying, drifting, or collapsing ownership boundaries?"

## Eval design rules

Every eval in this file should check contract truth, not style.

That means evals should prefer:
- routing correctness over eloquent justification
- artifact quality over generic helpfulness
- ownership discipline over agent enthusiasm
- truthful blocked or promoted outcomes over forced completion

## Eval buckets

### 1. Route selection evals
These test whether intake and re-routing keep iterate limited to bounded change work.

Must pass examples:
- a concrete existing-surface bug fix routes to `iterate`
- a small behavior tweak routes to `iterate`
- a narrow UI improvement on an existing page routes to `iterate`

Must reject examples:
- investigation-only asks route to `insight`
- explanation-only asks route to `insight`
- broad feature or workflow requests route to `idea`
- initially small asks that expand during framing are promoted out of `iterate`

Failure signals:
- `iterate` absorbs read-only diagnostic work
- `iterate` absorbs broad planning work
- lane choice is treated as irreversible after better truth appears

### 2. Task artifact integrity evals
These test Framer's ability to convert a messy ask into a bounded contract.

Required checks:
- the artifact identifies current behavior and desired behavior distinctly
- success criteria are observable and not aspirational
- scope is narrow enough for task-scale execution
- assumptions are separated from facts
- blocking unknowns are separated from nonblocking unknowns
- a promotion recommendation appears when framing reveals non-iterate scope
- task artifact revisions increase monotonically when framing is amended

Failure signals:
- task artifact reads like a vague restatement of the user message
- success criteria cannot be verified later by Observer or Iterator
- scope is so broad that Coder would need to reinterpret the task

### 3. Observation artifact integrity evals
These test whether Observer creates a truthful seam for implementation and validation.

Required checks:
- evidence is grounded in logs, repro steps, failing seam output, or equivalent observable proof
- the artifact can report `not_confirmed` honestly when repro fails
- repeatability status is explicit
- expected green condition is concrete enough for Iterator to validate later
- missing evidence triggers a context request or blocked recommendation, not invented certainty
- observation artifact revisions increase monotonically when new truth is learned

Failure signals:
- repro is implied but not documented
- evidence summary has no traceable source
- green condition is too vague to distinguish success from partial progress

### 4. Supervision integrity evals
These test whether Iterator preserves the advisor-primary model.

Required checks:
- Iterator refuses to start coding before task and observation artifacts are sufficient
- Iterator uses Framer and Observer outputs as constraints, not as optional suggestions
- Iterator respawns Coder only with repair-specific context tied to the artifacts
- Iterator blocks or promotes when truth or scope no longer fits iterate
- promotion or reroute writes an iterate-owned handoff artifact with references back to the exact task and observation revisions used for the decision

Failure signals:
- Iterator bypasses missing artifact truth because coding "might help"
- Iterator lets Coder redefine the task, evidence, or completion bar
- Iterator returns completion after scope drift

### 5. Coder discipline evals
These test whether Coder behaves like a supervised worker instead of a peer decider.

Required checks:
- implementation stays within the bounded task and named surface
- verification stays narrow and relevant to the observation seam
- attempt reports say what changed, what passed, what failed, and what remains blocked
- second attempts respond to repair context rather than restarting from scratch conceptually

Failure signals:
- unrelated refactors or cleanup appear without authorization
- Coder claims success without matching the artifact green condition
- Coder silently broadens the solution to compensate for poor framing

### 6. Completion integrity evals
These test the final truth gate.

Required checks:
- no completion without a green seam or equivalent scoped proof
- no completion when requested user-visible behavior is still missing
- no completion when the observed failure still reproduces
- no completion after unauthorized scope growth
- blocked verdicts are allowed and scored as correct when truth is insufficient
- promotion verdicts are allowed and scored as correct when the task has become planning work

Failure signals:
- the system rewards optimistic claims over truthful disposition
- completion can happen without evidence that corresponds to the original ask

## Cross-agent eval expectations

The four-agent model should be explicitly visible in eval coverage:
- `Framer` evals prove task-bounding quality
- `Observer` evals prove evidence and green-condition quality
- `Coder` evals prove implementation discipline
- `Iterator` evals prove ownership of readiness, supervision, and final judgment

If a behavior matters but cannot be assigned to one of those owners, the contract is still blurry.

## Review rule

A stage-1 requirement is not real until there is a plausible eval that could fail it.

If reviewers cannot describe how a bad route, bad artifact, bad supervision choice, or fake completion would be caught, the iterate design is not ready to advance to stage 3.
