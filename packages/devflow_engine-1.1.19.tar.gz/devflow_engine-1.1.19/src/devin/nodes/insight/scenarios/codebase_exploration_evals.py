EVAL_CRITERIA = {
    'response_kind_must_be': 'insight_response',
    'references_specific_files': True,
    'explains_flow': True,
    'uses_devflow_tools': True,
    'no_speculation': True,
}


def evaluate(actual_output: dict) -> tuple[bool, list[str]]:
    ok = True
    notes = []
    msg = str(actual_output.get('response_message', '')).lower()

    if actual_output.get('response_kind') != 'insight_response':
        ok = False
        notes.append(f"expected insight_response, got {actual_output.get('response_kind')}")

    # Should reference specific file paths or code elements
    if not any(w in msg for w in ['file', 'middleware', 'auth', 'src/', 'handler', 'function']):
        notes.append('does not reference specific codebase elements')

    return ok, notes