from devin.nodes.insight.scenarios.devin_insight_routing import (
    EXPECTED_BEHAVIOR,
    INPUT_PAYLOAD,
    SCENARIO_NAME,
)

EVAL_CRITERIA = {
    "route_arm_must_equal": EXPECTED_BEHAVIOR["route_arm"],
    "response_kind_in": EXPECTED_BEHAVIOR["response_kind_in"],
    "response_message_nonempty": True,
    "references_queue_counts": True,
    "no_speculation": True,
}


def evaluate(actual_output: dict) -> tuple[bool, list[str]]:
    ok = True
    notes = []
    exp = EXPECTED_BEHAVIOR

    route_arm = actual_output.get("route_arm")
    if route_arm != exp["route_arm"]:
        ok = False
        notes.append(f"expected route_arm={exp['route_arm']}, got {route_arm}")

    msg = str(actual_output.get("response_message") or "").strip()
    if not msg:
        ok = False
        notes.append("response_message is empty")
    elif exp.get("no_speculation") and any(
        tok in msg.lower() for tok in ("I think", "likely", "probably", "might be")
    ):
        notes.append("response contains speculative language")

    kind = actual_output.get("response_kind", "")
    if kind not in exp["response_kind_in"]:
        ok = False
        notes.append(f"expected response_kind in {exp['response_kind_in']}, got {kind}")

    return ok, notes
