SCENARIO_NAME = 'codebase_exploration'
SCENARIO_DESCRIPTION = 'User asks how a specific part of the codebase works.'
INPUT_PAYLOAD = {
    'current_user_message': 'How does the auth middleware handle token validation?',
    'idea_id': 'proj_75f63d30_insight_codebase_001',
    'project_id': 'proj_75f63d30',
    'repo_root': '/Users/devflow/repos/Spicy-Server',
}
EXPECTED_BEHAVIOR = {
    'response_kind': 'insight_response',
    'references_specific_files': True,
    'explains_flow': True,
    'uses_devflow_tools': True,
    'no_speculation': True,
}