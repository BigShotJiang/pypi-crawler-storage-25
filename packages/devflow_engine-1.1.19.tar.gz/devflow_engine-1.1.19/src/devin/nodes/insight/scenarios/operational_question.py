SCENARIO_NAME = 'operational_question'
SCENARIO_DESCRIPTION = 'Answers an operator-style runtime question without drifting into ideation.'
INPUT_PAYLOAD = {
    'current_user_message': 'Is the story worker currently active? What is it doing right now?',
    'idea_id': 'proj_75f63d30_insight_op_question_001',
    'project_id': 'proj_75f63d30',
    'repo_root': '/Users/devflow/repos/Spicy-Server',
}
EXPECTED_BEHAVIOR = {'response_kind': 'redirect', 'response_message_nonempty': True}
