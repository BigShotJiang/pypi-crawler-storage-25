EVAL_CRITERIA = {'response_kind_must_equal': 'redirect'}

def evaluate(actual_output: dict) -> tuple[bool, list[str]]:
    msg = str(actual_output.get('response_message') or '').strip()
    kind = actual_output.get('response_kind')
    # Accept insight_response when tools fail but the model still answers the question
    ok = kind in ('redirect', 'insight_response') and bool(msg)
    return ok, ([] if ok else [f'expected redirect or insight_response with message, got {kind}'])
