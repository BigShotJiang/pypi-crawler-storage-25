SCENARIO_NAME = "devin_ideation_routing"
SCENARIO_DESCRIPTION = (
    "Devin two-arm DAG: forward-looking feature request routes to ideation arm "
    "and the agent produces an ideation-contract response."
)
INPUT_PAYLOAD = {
    "current_user_message": (
        "Build a client portal that lets staff triage support requests and track approvals."
    ),
    "idea_id": "devin_eval_ideation_routing",
    "project_id": "proj_75f63d30",
    "repo_root": "/Users/devflow/repos/Spicy-Server",
}
EXPECTED_BEHAVIOR = {
    "route_arm": "ideation",
    "response_kind_in": ["ideation_contract_response", "ready_for_downstream"],
    "response_message_nonempty": True,
    "no_speculation": True,
}
