SCENARIO_NAME = 'operational_debugging'
SCENARIO_DESCRIPTION = 'User asks why something happened or what went wrong with a recent operation.'
INPUT_PAYLOAD = {
    'current_user_message': 'Why did the last story fail? What went wrong?',
    'idea_id': 'proj_75f63d30_insight_debug_001',
    'project_id': 'proj_75f63d30',
    'repo_root': '/Users/devflow/repos/Spicy-Server',
}
EXPECTED_BEHAVIOR = {
    'response_kind': 'insight_response',
    'cites_specific_failure_reason': True,
    'uses_run_logs': True,
    'gives_actionable_guidance': True,
    'no_speculation': True,
}