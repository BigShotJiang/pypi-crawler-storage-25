EVAL_CRITERIA = {
    'response_kind_must_be': 'insight_response',
    'references_queue_counts': True,
    'uses_devflow_tools': True,
    'no_speculation': True,
    'direct_answer': True,
}


def evaluate(actual_output: dict) -> tuple[bool, list[str]]:
    ok = True
    notes = []
    msg = str(actual_output.get('response_message', '')).lower()

    if actual_output.get('response_kind') not in ('insight_response', 'redirect'):
        ok = False
        notes.append(f"expected insight_response or redirect, got {actual_output.get('response_kind')}")

    # Should reference actual queue state, not just say "I don't know"
    if not any(w in msg for w in ['queue', 'story', 'queued', 'in_progress', 'worker', 'running']):
        notes.append('does not reference queue/story state')

    return ok, notes