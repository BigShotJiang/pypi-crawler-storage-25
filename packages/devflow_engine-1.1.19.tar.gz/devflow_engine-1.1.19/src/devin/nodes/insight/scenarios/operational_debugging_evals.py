EVAL_CRITERIA = {
    'response_kind_must_be': 'insight_response',
    'cites_specific_failure_reason': True,
    'uses_run_logs': True,
    'gives_actionable_guidance': True,
    'no_speculation': True,
}


def evaluate(actual_output: dict) -> tuple[bool, list[str]]:
    ok = True
    notes = []
    msg = str(actual_output.get('response_message', '')).lower()

    if actual_output.get('response_kind') not in ('insight_response', 'redirect', 'needs_context'):
        ok = False
        notes.append(f"expected insight_response/redirect/needs_context, got {actual_output.get('response_kind')}")

    # Should cite a specific failure reason, not just "I don't know"
    if 'don\'t know' in msg or 'unable to' in msg or 'cannot determine' in msg:
        notes.append('response does not cite a specific failure reason')

    return ok, notes