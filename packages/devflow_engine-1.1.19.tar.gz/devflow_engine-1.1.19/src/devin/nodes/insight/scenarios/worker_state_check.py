SCENARIO_NAME = 'worker_state_check'
SCENARIO_DESCRIPTION = 'User asks what is currently running on the worker side.'
INPUT_PAYLOAD = {
    'current_user_message': 'What are the workers doing right now?',
    'idea_id': 'proj_75f63d30_insight_worker_001',
    'project_id': 'proj_75f63d30',
    'repo_root': '/Users/devflow/repos/Spicy-Server',
}
EXPECTED_BEHAVIOR = {
    'response_kind': 'insight_response',
    'references_active_workers': True,
    'uses_devflow_tools': True,
    'no_speculation': True,
    'direct_answer': True,
}