EVAL_CRITERIA = {
    'response_kind_must_be': 'insight_response',
    'references_source_docs': True,
    'no_speculation': True,
    'uses_devflow_tools': True,
}


def evaluate(actual_output: dict) -> tuple[bool, list[str]]:
    ok = True
    notes = []
    msg = str(actual_output.get('response_message', '')).lower()

    if actual_output.get('response_kind') not in ('insight_response', 'redirect'):
        ok = False
        notes.append(f"expected insight_response or redirect, got {actual_output.get('response_kind')}")

    if not any(w in msg for w in ['source', 'doc', 'portal', 'notification', 'system']):
        notes.append('does not reference source docs')

    return ok, notes