SCENARIO_NAME = 'architecture_pattern_query'
SCENARIO_DESCRIPTION = 'User asks how the system handles a specific architectural pattern (e.g., retry, backoff, caching).'
INPUT_PAYLOAD = {
    'current_user_message': 'How does the worker system handle retry and backoff when a job fails?',
    'idea_id': 'proj_75f63d30_insight_arch_001',
    'project_id': 'proj_75f63d30',
    'repo_root': '/Users/devflow/repos/Spicy-Server',
}
EXPECTED_BEHAVIOR = {
    'response_kind': 'insight_response',
    'explains_architecture': True,
    'references_specific_implementation': True,
    'uses_devflow_tools': True,
    'no_speculation': True,
}