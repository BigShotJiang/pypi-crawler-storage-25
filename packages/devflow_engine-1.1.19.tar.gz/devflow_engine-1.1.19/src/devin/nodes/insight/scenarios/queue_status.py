SCENARIO_NAME = 'queue_status'
SCENARIO_DESCRIPTION = 'User asks for a high-level view of what is queued, in progress, and completed across the project.'
INPUT_PAYLOAD = {
    'current_user_message': 'What stories are queued and what is currently in progress?',
    'idea_id': 'proj_75f63d30_insight_queuestatus',
    'project_id': 'proj_75f63d30',
    'repo_root': '/Users/devflow/repos/Spicy-Server',
}
EXPECTED_BEHAVIOR = {
    'response_kind': 'insight_response',
    'references_queue_counts': True,
    'uses_devflow_tools': True,
    'no_speculation': True,
    'direct_answer': True,
}