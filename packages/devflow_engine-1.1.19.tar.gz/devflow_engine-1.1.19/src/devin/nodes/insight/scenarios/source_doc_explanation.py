SCENARIO_NAME = 'source_doc_explanation'
SCENARIO_DESCRIPTION = 'User asks what the source documentation says about a specific system or subsystem.'
INPUT_PAYLOAD = {
    'current_user_message': 'What does the source documentation say about the client portal notification system?',
    'idea_id': 'proj_75f63d30_insight_srcdoc_001',
    'project_id': 'proj_75f63d30',
    'repo_root': '/Users/devflow/repos/Spicy-Server',
}
EXPECTED_BEHAVIOR = {
    'response_kind': 'insight_response',
    'references_source_docs': True,
    'no_speculation': True,
    'uses_devflow_tools': True,
}