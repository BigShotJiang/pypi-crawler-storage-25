SCENARIO_NAME = "devin_insight_routing"
SCENARIO_DESCRIPTION = (
    "Devin two-arm DAG: operational/project question routes to insight arm "
    "and the agent produces a grounded insight response."
)
INPUT_PAYLOAD = {
    "current_user_message": (
        "What stories are currently queued for this project?"
    ),
    "idea_id": "devin_eval_insight_routing",
    "project_id": "proj_75f63d30",
    "repo_root": "/Users/devflow/repos/Spicy-Server",
}
EXPECTED_BEHAVIOR = {
    "route_arm": "insight",
    "response_kind_in": ["insight_response", "redirect"],
    "response_message_nonempty": True,
    "references_queue_counts": True,
    "no_speculation": True,
}
