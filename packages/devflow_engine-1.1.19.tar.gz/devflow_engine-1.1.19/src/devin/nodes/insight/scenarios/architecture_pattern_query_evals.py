EVAL_CRITERIA = {
    'response_kind_must_be': 'insight_response',
    'explains_architecture': True,
    'references_specific_implementation': True,
    'uses_devflow_tools': True,
    'no_speculation': True,
}


def evaluate(actual_output: dict) -> tuple[bool, list[str]]:
    ok = True
    notes = []
    msg = str(actual_output.get('response_message', '')).lower()

    if actual_output.get('response_kind') != 'insight_response':
        ok = False
        notes.append(f"expected insight_response, got {actual_output.get('response_kind')}")

    # Should explain the architecture, not generic "it retries"
    if 'retry' in msg and not any(w in msg for w in ['backoff', 'attempt', 'max', 'retry', 'delay', 'exponential', 'circuit']):
        pass  # retry mentioned, but should have specifics
    else:
        notes.append('does not explain the retry/backoff pattern specifically')

    return ok, notes