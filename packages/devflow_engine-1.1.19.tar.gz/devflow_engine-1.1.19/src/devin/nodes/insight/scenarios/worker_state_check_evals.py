EVAL_CRITERIA = {
    'response_kind_must_be': 'insight_response',
    'references_active_workers': True,
    'uses_devflow_tools': True,
    'no_speculation': True,
    'direct_answer': True,
}


def evaluate(actual_output: dict) -> tuple[bool, list[str]]:
    ok = True
    notes = []
    msg = str(actual_output.get('response_message', '')).lower()

    if actual_output.get('response_kind') != 'insight_response':
        ok = False
        notes.append(f"expected insight_response, got {actual_output.get('response_kind')}")

    if not any(w in msg for w in ['worker', 'running', 'idle', 'active', 'process', 'pid']):
        notes.append('does not reference worker state')

    return ok, notes