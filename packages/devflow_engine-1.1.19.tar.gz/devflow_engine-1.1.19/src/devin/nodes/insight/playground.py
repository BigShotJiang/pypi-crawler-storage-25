"""InsightAgent playground — unit test InsightAgentNode against scenario inputs."""

from __future__ import annotations

import argparse
import asyncio
import importlib.util
import json
import uuid
from pathlib import Path

from devin.nodes.insight.node import InsightAgentNode
from devin.nodes.shared.helpers import set_runtime_store
from devin.nodes.shared.models import DevinAgentResponse, DevinChatDagEvent, ScenarioResult
from devflow_engine.stores.execution_store import ExecutionStore
from devflow_engine.vendor.datalumina_genai.core.task import TaskContext

SCENARIO_DIR = Path(__file__).with_name('scenarios')


def _load_module(path: Path):
    spec = importlib.util.spec_from_file_location(path.stem, path)
    module = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    spec.loader.exec_module(module)
    return module


def _collect_scenarios():
    pairs = []
    for scenario_path in sorted(SCENARIO_DIR.glob('*.py')):
        if scenario_path.name.endswith('_evals.py'):
            continue
        eval_path = scenario_path.with_name(f'{scenario_path.stem}_evals.py')
        if eval_path.exists():
            pairs.append((_load_module(scenario_path), _load_module(eval_path)))
    return pairs


async def _run_scenario(scenario_module, eval_module, repo_root: Path, project_id: str) -> ScenarioResult:
    """Run a single scenario against the real InsightAgentNode with proper runtime store."""
    input_payload = dict(scenario_module.INPUT_PAYLOAD)
    expected = dict(scenario_module.EXPECTED_BEHAVIOR)

    idea_id = input_payload.get('idea_id', f'{project_id}_scenario_{scenario_module.SCENARIO_NAME}')
    raw_text = input_payload.get('current_user_message', '')

    event = DevinChatDagEvent(
        repo_root=str(repo_root),
        idea_id=idea_id,
        raw_text=raw_text,
        pipeline_key=f'insight-scenario-{scenario_module.SCENARIO_NAME}',
    )

    metadata = {
        'raw_text': raw_text,
        'route': {'route_arm': 'insight'},
        'project_id': project_id,
    }

    task_context = TaskContext(event=event, metadata=metadata)

    # Set up runtime store for this scenario (matching ideation playground pattern)
    db_path = repo_root / '.devflow' / 'execution.sqlite'
    store = ExecutionStore(db_path=db_path)
    run_id = store.create_run(
        dag_id='devin_chat_two_arm_dag',
        dag_version='1.0',
        root_correlation_id=str(uuid.uuid4()),
        config={'project_id': project_id, 'scenario': scenario_module.SCENARIO_NAME},
    )
    set_runtime_store(store, run_id)

    node = InsightAgentNode(task_context=None)
    try:
        result_ctx = await node.process(task_context)
        response_guidance = result_ctx.metadata.get('response_guidance', {})
        agent_terminal = result_ctx.metadata.get('agent_loop_terminal', {})
    except Exception as exc:
        set_runtime_store(None, None)
        return ScenarioResult(
            scenario_name=scenario_module.SCENARIO_NAME,
            passed=False,
            actual_output={'error': str(exc)},
            expected_behavior=expected,
            notes=[f'Node raised exception: {exc}'],
        )

    set_runtime_store(None, None)

    actual_output = {
        'response_message': response_guidance.get('response_message', ''),
        'response_kind': response_guidance.get('response_kind', agent_terminal.get('status', '')),
        'suggested_next_step': response_guidance.get('suggested_next_step', ''),
        'follow_up_questions': response_guidance.get('follow_up_questions', []),
        'style_notes': response_guidance.get('response_style_notes', []),
    }

    try:
        passed, notes = eval_module.evaluate(actual_output)
    except Exception as exc:
        passed = False
        notes = [f'Eval raised exception: {exc}']

    return ScenarioResult(
        scenario_name=scenario_module.SCENARIO_NAME,
        passed=passed,
        actual_output=actual_output,
        expected_behavior=expected,
        notes=notes,
    )


def run_all() -> list[ScenarioResult]:
    """Run all insight scenarios against the InsightAgentNode."""
    results = []
    for scenario_mod, eval_mod in _collect_scenarios():
        result = asyncio.run(_run_scenario(scenario_mod, eval_mod, Path.cwd(), 'proj_75f63d30'))
        results.append(result)
    return results


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='InsightAgent playground')
    parser.add_argument('--real-pi', action='store_true', help='Run with real PI harness (slower, uses API budget)')
    parser.add_argument('--project', type=str, default='proj_75f63d30', help='DevFlow project ID')
    parser.add_argument('--repo-root', type=str, default='/Users/devflow/repos/Spicy-Server', help='Repo root path')
    args = parser.parse_args()

    repo_root = Path(args.repo_root)
    project_id = args.project

    print(f"Running InsightAgent eval against Spicy-Server ({project_id})")
    print(f"Repo root: {repo_root}")
    print("-" * 60)

    results = []
    for scenario_mod, eval_mod in _collect_scenarios():
        print(f"Running scenario: {scenario_mod.SCENARIO_NAME} ...", flush=True)
        result = asyncio.run(_run_scenario(scenario_mod, eval_mod, repo_root, project_id))
        results.append(result)
        status = "PASS" if result.passed else "FAIL"
        print(f"  → {status}", flush=True)

    print("-" * 60)
    print(f"\nResults: {sum(1 for r in results if r.passed)}/{len(results)} passed\n")

    for result in results:
        status = "PASS" if result.passed else "FAIL"
        print(f"  [{status}] {result.scenario_name}")
        for note in result.notes:
            print(f"        note: {note}")

    print("\n" + json.dumps([item.model_dump() for item in results], indent=2, sort_keys=True))
