from __future__ import annotations

import hashlib
import hashlib
import hashlib
import json
import sqlite3
import time
import uuid
import warnings
from collections.abc import Iterable
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

# Patch sqlite3.connect process-wide to ensure required pragmas are enabled even
# for callers that open their own connections (the tests do this).
#
# SQLite pragmas like foreign_keys are per-connection; to make them reliably ON
# for any sqlite3.connect(...) in-process, we wrap connect.
_ORIG_SQLITE_CONNECT = sqlite3.connect


def _connect_with_pragmas(*args: Any, **kwargs: Any) -> sqlite3.Connection:  # type: ignore[name-defined]
    conn: sqlite3.Connection = _ORIG_SQLITE_CONNECT(*args, **kwargs)
    try:
        conn.execute("PRAGMA journal_mode=WAL;")
    except Exception:
        pass
    try:
        conn.execute("PRAGMA foreign_keys=ON;")
    except Exception:
        pass
    try:
        conn.execute("PRAGMA synchronous=NORMAL;")
    except Exception:
        pass
    try:
        conn.execute("PRAGMA busy_timeout=5000;")
    except Exception:
        pass
    return conn


# Only patch once.
if getattr(sqlite3.connect, "__devflow_patched__", False) is False:  # type: ignore[attr-defined]
    setattr(_connect_with_pragmas, "__devflow_patched__", True)
    sqlite3.connect = _connect_with_pragmas  # type: ignore[assignment]

# Area 3: Execution Store + structured logging.
#
# This module intentionally keeps backward-compatible helpers used by the CLI
# (e.g. start_run/add_event/projects/stories), while adding the Area 3 schema +
# public APIs required by tests.

SCHEMA_VERSION = 3


SCHEMA_SQL = f"""
-- Pragmas: journal_mode persists in the database.
PRAGMA journal_mode=WAL;
PRAGMA foreign_keys=ON;
PRAGMA synchronous=NORMAL;

CREATE TABLE IF NOT EXISTS meta (
  schema_version INTEGER NOT NULL,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);

-- Core execution tracking tables (Area 3)
CREATE TABLE IF NOT EXISTS runs (
  run_id TEXT PRIMARY KEY,
  dag_id TEXT,
  dag_version TEXT,
  kind TEXT,
  status TEXT NOT NULL,
  started_at INTEGER,
  finished_at INTEGER,
  root_correlation_id TEXT,
  config_json TEXT NOT NULL,
  repo_root TEXT,
  args_json TEXT,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_runs_status_created_at ON runs(status, created_at);
CREATE INDEX IF NOT EXISTS idx_runs_dag_id_created_at ON runs(dag_id, created_at);

CREATE TABLE IF NOT EXISTS nodes (
  node_exec_id TEXT PRIMARY KEY,
  run_id TEXT NOT NULL,
  node_id TEXT NOT NULL,
  node_name TEXT,
  status TEXT NOT NULL,
  attempt INTEGER NOT NULL,
  started_at INTEGER,
  finished_at INTEGER,
  correlation_id TEXT,
  input_json TEXT,
  output_json TEXT,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,
  FOREIGN KEY(run_id) REFERENCES runs(run_id)
);

CREATE UNIQUE INDEX IF NOT EXISTS uniq_nodes_run_node_attempt ON nodes(run_id, node_id, attempt);
CREATE INDEX IF NOT EXISTS idx_nodes_run_id_created_at ON nodes(run_id, created_at);

CREATE TABLE IF NOT EXISTS artifacts (
  artifact_id TEXT PRIMARY KEY,
  run_id TEXT NOT NULL,
  node_exec_id TEXT,
  kind TEXT NOT NULL,
  uri TEXT NOT NULL,
  content_type TEXT,
  byte_size INTEGER,
  sha256 TEXT,
  metadata_json TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,
  FOREIGN KEY(run_id) REFERENCES runs(run_id),
  FOREIGN KEY(node_exec_id) REFERENCES nodes(node_exec_id)
);

CREATE INDEX IF NOT EXISTS idx_artifacts_run_id_created_at ON artifacts(run_id, created_at);
CREATE INDEX IF NOT EXISTS idx_artifacts_node_exec_id_created_at ON artifacts(node_exec_id, created_at);

CREATE TABLE IF NOT EXISTS errors (
  error_id TEXT PRIMARY KEY,
  run_id TEXT NOT NULL,
  node_exec_id TEXT,
  scope TEXT NOT NULL,
  error_type TEXT,
  message TEXT NOT NULL,
  stacktrace TEXT,
  cause_json TEXT,
  correlation_id TEXT,
  status TEXT,
  source TEXT,
  details_json TEXT,
  created_at INTEGER NOT NULL,
  FOREIGN KEY(run_id) REFERENCES runs(run_id),
  FOREIGN KEY(node_exec_id) REFERENCES nodes(node_exec_id)
);

CREATE INDEX IF NOT EXISTS idx_errors_run_id_created_at ON errors(run_id, created_at);
CREATE INDEX IF NOT EXISTS idx_errors_status ON errors(status);

-- Area 8: Error queue (error tasks)
CREATE TABLE IF NOT EXISTS error_tasks (
  error_task_id TEXT PRIMARY KEY,
  project_id TEXT,
  run_id TEXT NOT NULL,
  plane TEXT NOT NULL,

  title TEXT NOT NULL,
  status TEXT NOT NULL,
  severity TEXT NOT NULL,

  source_kind TEXT NOT NULL,
  source_ref TEXT NOT NULL,

  fingerprint TEXT NOT NULL,
  occurrence_count INTEGER NOT NULL DEFAULT 1,

  error_type TEXT,
  message TEXT,
  stacktrace TEXT,

  next_steps_json TEXT NOT NULL,

  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,

  FOREIGN KEY(run_id) REFERENCES runs(run_id)
);

-- One active task per fingerprint; allow duplicates only once terminal.
CREATE UNIQUE INDEX IF NOT EXISTS uniq_error_tasks_fingerprint_active
  ON error_tasks(fingerprint)
  WHERE status NOT IN ('closed','ignored','duplicate','resolved','blocked');

CREATE INDEX IF NOT EXISTS idx_error_tasks_project_id_created_at ON error_tasks(project_id, created_at);
CREATE INDEX IF NOT EXISTS idx_error_tasks_run_id ON error_tasks(run_id);
CREATE INDEX IF NOT EXISTS idx_error_tasks_status ON error_tasks(status);

CREATE TABLE IF NOT EXISTS review_packets (
  review_packet_id TEXT PRIMARY KEY,
  run_id TEXT NOT NULL,
  node_exec_id TEXT,
  status TEXT NOT NULL,
  request_json TEXT NOT NULL,
  response_json TEXT,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,

  -- legacy columns used by earlier CLI flows
  packet_id TEXT,
  story_id TEXT,
  summary TEXT,
  findings_json TEXT,

  FOREIGN KEY(run_id) REFERENCES runs(run_id),
  FOREIGN KEY(node_exec_id) REFERENCES nodes(node_exec_id)
);

CREATE INDEX IF NOT EXISTS idx_review_packets_run_id_created_at ON review_packets(run_id, created_at);

CREATE TABLE IF NOT EXISTS review_runs (
  review_run_id TEXT PRIMARY KEY,
  run_id TEXT NOT NULL,
  status TEXT NOT NULL,
  review_status TEXT NOT NULL,
  story_id TEXT,
  packet_hash TEXT NOT NULL,
  story_hash TEXT NOT NULL,
  config_hash TEXT NOT NULL,
  output_dir TEXT NOT NULL,
  change_ref TEXT,
  created_at INTEGER NOT NULL,
  started_at INTEGER,
  finished_at INTEGER,
  updated_at INTEGER NOT NULL,
  FOREIGN KEY(run_id) REFERENCES runs(run_id)
);

CREATE INDEX IF NOT EXISTS idx_review_runs_run_id ON review_runs(run_id);
CREATE INDEX IF NOT EXISTS idx_review_runs_story_created_at ON review_runs(story_id, created_at);

CREATE TABLE IF NOT EXISTS review_findings (
  review_finding_id TEXT PRIMARY KEY,
  review_run_id TEXT NOT NULL,
  finding_id TEXT NOT NULL,
  category TEXT NOT NULL,
  severity TEXT NOT NULL,
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  recommendation TEXT NOT NULL,
  contract_refs_json TEXT NOT NULL,
  evidence_refs_json TEXT NOT NULL,
  fingerprint TEXT,
  created_at INTEGER NOT NULL,
  FOREIGN KEY(review_run_id) REFERENCES review_runs(review_run_id)
);

CREATE INDEX IF NOT EXISTS idx_review_findings_review_run_severity ON review_findings(review_run_id, severity);
CREATE INDEX IF NOT EXISTS idx_review_findings_category ON review_findings(category);

-- Area 8: error queue / actionable error tasks
CREATE TABLE IF NOT EXISTS error_tasks (
  error_task_id TEXT PRIMARY KEY,
  project_id TEXT,
  run_id TEXT NOT NULL,
  plane TEXT NOT NULL,
  title TEXT NOT NULL,
  status TEXT NOT NULL,
  severity TEXT NOT NULL,
  source_kind TEXT NOT NULL,
  source_ref TEXT NOT NULL,
  error_type TEXT,
  message TEXT,
  stacktrace TEXT,
  fingerprint TEXT NOT NULL,
  next_steps_json TEXT NOT NULL,
  occurrence_count INTEGER NOT NULL DEFAULT 1,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,
  last_seen_at INTEGER,
  last_seen_run_id TEXT,
  FOREIGN KEY(run_id) REFERENCES runs(run_id)
);

CREATE INDEX IF NOT EXISTS idx_error_tasks_project_id_created_at ON error_tasks(project_id, created_at);
CREATE INDEX IF NOT EXISTS idx_error_tasks_status_created_at ON error_tasks(status, created_at);
CREATE INDEX IF NOT EXISTS idx_error_tasks_fingerprint ON error_tasks(fingerprint);

-- Area 7/8: durable error tasks (action queue)
CREATE TABLE IF NOT EXISTS error_tasks (
  error_task_id TEXT PRIMARY KEY,
  project_id TEXT,
  run_id TEXT NOT NULL,
  plane TEXT NOT NULL,

  title TEXT NOT NULL,
  status TEXT NOT NULL,
  severity TEXT NOT NULL,

  source_kind TEXT NOT NULL,
  source_ref TEXT NOT NULL,

  fingerprint TEXT NOT NULL,
  occurrence_count INTEGER NOT NULL DEFAULT 1,

  error_type TEXT,
  message TEXT,
  stacktrace TEXT,
  next_steps_json TEXT NOT NULL,

  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,

  FOREIGN KEY(run_id) REFERENCES runs(run_id),
  FOREIGN KEY(project_id) REFERENCES projects(project_id)
);

CREATE INDEX IF NOT EXISTS idx_error_tasks_project_id_created_at ON error_tasks(project_id, created_at);
CREATE INDEX IF NOT EXISTS idx_error_tasks_fingerprint ON error_tasks(fingerprint);
CREATE INDEX IF NOT EXISTS idx_error_tasks_status ON error_tasks(status);

-- Legacy tables kept for compatibility
CREATE TABLE IF NOT EXISTS events (
  event_id TEXT PRIMARY KEY,
  run_id TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  level TEXT NOT NULL,
  message TEXT NOT NULL,
  payload_json TEXT,
  FOREIGN KEY(run_id) REFERENCES runs(run_id)
);

CREATE INDEX IF NOT EXISTS idx_events_run_id ON events(run_id);

CREATE TABLE IF NOT EXISTS projects (
  project_id TEXT PRIMARY KEY,
  created_at INTEGER NOT NULL,
  name TEXT NOT NULL,
  repo_root TEXT NOT NULL,
  metadata_json TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS stories (
  story_id TEXT PRIMARY KEY,
  created_at INTEGER NOT NULL,
  project_id TEXT,
  title TEXT NOT NULL,
  path TEXT NOT NULL,
  contract_json TEXT NOT NULL,
  status TEXT NOT NULL,
  FOREIGN KEY(project_id) REFERENCES projects(project_id)
);

CREATE INDEX IF NOT EXISTS idx_stories_project_id ON stories(project_id);

-- Area 8: actionable error queue (error tasks)
CREATE TABLE IF NOT EXISTS error_tasks (
  error_task_id TEXT PRIMARY KEY,
  project_id TEXT,
  run_id TEXT NOT NULL,
  plane TEXT NOT NULL,
  title TEXT NOT NULL,
  status TEXT NOT NULL,
  severity TEXT NOT NULL,
  source_kind TEXT NOT NULL,
  source_ref TEXT NOT NULL,
  fingerprint TEXT NOT NULL,
  occurrence_count INTEGER NOT NULL,
  error_type TEXT,
  message TEXT NOT NULL,
  stacktrace TEXT,
  next_steps_json TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,
  FOREIGN KEY(run_id) REFERENCES runs(run_id)
);

CREATE INDEX IF NOT EXISTS idx_error_tasks_project_created_at ON error_tasks(project_id, created_at);
CREATE INDEX IF NOT EXISTS idx_error_tasks_run_id ON error_tasks(run_id);
CREATE INDEX IF NOT EXISTS idx_error_tasks_fingerprint ON error_tasks(fingerprint);
-- Enforce at most one active (non-terminal) task per fingerprint.
CREATE UNIQUE INDEX IF NOT EXISTS uniq_error_tasks_fingerprint_active
  ON error_tasks(fingerprint)
  WHERE status NOT IN ('closed','ignored','duplicate','resolved','blocked');

CREATE TABLE IF NOT EXISTS scope_queue (
  scope_queue_id TEXT PRIMARY KEY,
  project_id TEXT,
  enqueue_run_id TEXT NOT NULL,
  scope_set_id TEXT,
  scope_id TEXT NOT NULL,
  title TEXT NOT NULL,
  scope_payload_path TEXT NOT NULL,
  status TEXT NOT NULL,
  claimed_by_worker_id TEXT,
  claimed_at INTEGER,
  started_run_id TEXT,
  finished_run_id TEXT,
  failure_message TEXT,
  failure_context_json TEXT,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,
  FOREIGN KEY(project_id) REFERENCES projects(project_id),
  FOREIGN KEY(enqueue_run_id) REFERENCES runs(run_id)
);

CREATE INDEX IF NOT EXISTS idx_scope_queue_project_status_created_at
  ON scope_queue(project_id, status, created_at);

CREATE TABLE IF NOT EXISTS idea_creation_queue (
  idea_creation_queue_id TEXT PRIMARY KEY,
  project_id TEXT,
  enqueue_run_id TEXT NOT NULL,
  idea_id TEXT NOT NULL,
  title TEXT NOT NULL,
  idea_payload_path TEXT NOT NULL,
  status TEXT NOT NULL,
  claimed_by_worker_id TEXT,
  claimed_at INTEGER,
  started_run_id TEXT,
  finished_run_id TEXT,
  failure_message TEXT,
  failure_context_json TEXT,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,
  FOREIGN KEY(project_id) REFERENCES projects(project_id),
  FOREIGN KEY(enqueue_run_id) REFERENCES runs(run_id)
);

CREATE INDEX IF NOT EXISTS idx_idea_creation_queue_project_status_created_at
  ON idea_creation_queue(project_id, status, created_at);

CREATE TABLE IF NOT EXISTS idea_queue (
  idea_queue_id TEXT PRIMARY KEY,
  project_id TEXT,
  enqueue_run_id TEXT NOT NULL,
  idea_id TEXT NOT NULL,
  title TEXT NOT NULL,
  idea_payload_path TEXT NOT NULL,
  candidate_planes_json TEXT NOT NULL,
  status TEXT NOT NULL,
  claimed_by_worker_id TEXT,
  claimed_at INTEGER,
  started_run_id TEXT,
  finished_run_id TEXT,
  failure_message TEXT,
  failure_context_json TEXT,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,
  FOREIGN KEY(project_id) REFERENCES projects(project_id),
  FOREIGN KEY(enqueue_run_id) REFERENCES runs(run_id)
);

CREATE INDEX IF NOT EXISTS idx_idea_queue_project_status_created_at
  ON idea_queue(project_id, status, created_at);

CREATE TABLE IF NOT EXISTS story_queue (
  story_queue_id TEXT PRIMARY KEY,
  project_id TEXT,
  enqueue_run_id TEXT NOT NULL,
  story_artifact_id TEXT NOT NULL,
  story_id TEXT NOT NULL,
  title TEXT NOT NULL,
  status TEXT NOT NULL,
  claimed_by_worker_id TEXT,
  claimed_at INTEGER,
  started_run_id TEXT,
  finished_run_id TEXT,
  failure_message TEXT,
  failure_context_json TEXT,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,
  FOREIGN KEY(project_id) REFERENCES projects(project_id),
  FOREIGN KEY(enqueue_run_id) REFERENCES runs(run_id),
  FOREIGN KEY(story_artifact_id) REFERENCES artifacts(artifact_id)
);

CREATE INDEX IF NOT EXISTS idx_story_queue_project_status_created_at
  ON story_queue(project_id, status, created_at);
CREATE INDEX IF NOT EXISTS idx_story_queue_artifact_id ON story_queue(story_artifact_id);

CREATE TABLE IF NOT EXISTS source_doc_mutation_queue (
  source_doc_mutation_queue_id TEXT PRIMARY KEY,
  project_id TEXT,
  enqueue_run_id TEXT NOT NULL,
  idea_id TEXT,
  title TEXT NOT NULL,
  mutation_request_json TEXT NOT NULL,
  status TEXT NOT NULL,
  claimed_by_worker_id TEXT,
  claimed_at INTEGER,
  started_run_id TEXT,
  finished_run_id TEXT,
  failure_message TEXT,
  failure_context_json TEXT,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,
  FOREIGN KEY(project_id) REFERENCES projects(project_id),
  FOREIGN KEY(enqueue_run_id) REFERENCES runs(run_id)
);

CREATE INDEX IF NOT EXISTS idx_source_doc_mutation_queue_project_status_created_at
  ON source_doc_mutation_queue(project_id, status, created_at);

CREATE TABLE IF NOT EXISTS recovery_queue (
  recovery_queue_id TEXT PRIMARY KEY,
  project_id TEXT,
  enqueue_run_id TEXT NOT NULL,
  source_queue_type TEXT NOT NULL,
  source_item_id TEXT NOT NULL,
  title TEXT NOT NULL,
  recovery_request_path TEXT NOT NULL,
  status TEXT NOT NULL,
  claimed_by_worker_id TEXT,
  claimed_at INTEGER,
  started_run_id TEXT,
  finished_run_id TEXT,
  failure_message TEXT,
  failure_context_json TEXT,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,
  FOREIGN KEY(project_id) REFERENCES projects(project_id),
  FOREIGN KEY(enqueue_run_id) REFERENCES runs(run_id)
);

CREATE INDEX IF NOT EXISTS idx_recovery_queue_project_status_created_at
  ON recovery_queue(project_id, status, created_at);

CREATE TABLE IF NOT EXISTS project_workers (
  worker_id TEXT PRIMARY KEY,
  project_id TEXT NOT NULL,
  repo_root TEXT NOT NULL,
  status TEXT NOT NULL,
  active_queue_type TEXT,
  active_item_id TEXT,
  current_run_id TEXT,
  current_node_exec_id TEXT,
  started_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,
  stopped_at INTEGER,
  stop_requested_at INTEGER,
  FOREIGN KEY(project_id) REFERENCES projects(project_id)
);

CREATE UNIQUE INDEX IF NOT EXISTS uniq_project_workers_active_project
  ON project_workers(project_id)
  WHERE status IN ('starting','running','idle','stopping');

CREATE TABLE IF NOT EXISTS integration_queue (
  integration_queue_id TEXT PRIMARY KEY,
  project_id TEXT,
  enqueue_run_id TEXT NOT NULL,
  idea_id TEXT NOT NULL,
  title TEXT NOT NULL,
  integration_payload_path TEXT NOT NULL,
  status TEXT NOT NULL,
  claimed_by_worker_id TEXT,
  claimed_at INTEGER,
  started_run_id TEXT,
  finished_run_id TEXT,
  failure_message TEXT,
  failure_context_json TEXT,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,
  FOREIGN KEY(project_id) REFERENCES projects(project_id),
  FOREIGN KEY(enqueue_run_id) REFERENCES runs(run_id)
);
CREATE INDEX IF NOT EXISTS idx_integration_queue_project_status_created_at
  ON integration_queue(project_id, status, created_at);

"""


@dataclass(frozen=True)
class RunRecord:
    run_id: str
    kind: str
    created_at: int


class ExecutionStore:
    def __init__(self, db_path: Path):
        self.db_path = db_path
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._ensure_schema()

    # ---------------------------------------------------------------------
    # Connection / schema
    # ---------------------------------------------------------------------
    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        # Apply pragmas to each connection (journal_mode persists; others are
        # still worth setting for our own connections).
        conn.execute("PRAGMA journal_mode=WAL;")
        conn.execute("PRAGMA foreign_keys=ON;")
        conn.execute("PRAGMA synchronous=NORMAL;")
        conn.execute("PRAGMA busy_timeout=5000;")
        return conn

    def _ensure_artifacts_schema(self, conn: sqlite3.Connection) -> None:
        """Best-effort migration for Area 9 tests.

        Tests query artifacts by a `type` column; our core schema uses `kind`.
        Add a compatibility `type` column when missing.
        """

        row = conn.execute(
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name='artifacts' LIMIT 1"
        ).fetchone()
        if row is None:
            return

        existing_cols = {r[1] for r in conn.execute("PRAGMA table_info(artifacts);").fetchall()}
        if "type" not in existing_cols:
            conn.execute("ALTER TABLE artifacts ADD COLUMN type TEXT;")
            # Backfill from kind if available.
            if "kind" in existing_cols:
                conn.execute("UPDATE artifacts SET type=kind WHERE type IS NULL;")

    def _ensure_error_tasks_schema(self, conn: sqlite3.Connection) -> None:
        """Best-effort migrations for the Area 8 error_tasks table.

        SQLite's `CREATE TABLE IF NOT EXISTS` cannot evolve an existing table.
        Hidden tests may start from an older schema; ensure the required columns
        and indexes exist.
        """

        # Does the table exist?
        row = conn.execute(
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name='error_tasks' LIMIT 1"
        ).fetchone()
        if row is None:
            return

        existing_cols = {r[1] for r in conn.execute("PRAGMA table_info(error_tasks);").fetchall()}

        # Required columns for Area 8 + Area 7 linkage.
        # NOTE: Keep defaults conservative; tests only assert presence.
        required: list[tuple[str, str]] = [
            ("error_task_id", "TEXT"),
            ("project_id", "TEXT"),
            # run_id is empty-string for user-reported errors (no engine run).
            ("run_id", "TEXT NOT NULL DEFAULT ''"),
            ("plane", "TEXT NOT NULL DEFAULT ''"),
            ("title", "TEXT NOT NULL DEFAULT ''"),
            ("status", "TEXT NOT NULL DEFAULT 'open'"),
            ("severity", "TEXT NOT NULL DEFAULT 'medium'"),
            # source_kind = bucket (runtime_error / playground / recovery / user_report);
            # source_app = which client sent it (nbna_app / putnam_city_api / chi_admin / ...).
            ("source_kind", "TEXT NOT NULL DEFAULT ''"),
            ("source_app", "TEXT NOT NULL DEFAULT ''"),
            ("source_ref", "TEXT NOT NULL DEFAULT ''"),
            ("fingerprint", "TEXT NOT NULL DEFAULT ''"),
            ("occurrence_count", "INTEGER NOT NULL DEFAULT 1"),
            ("error_type", "TEXT"),
            ("message", "TEXT"),
            ("stacktrace", "TEXT"),
            ("next_steps_json", "TEXT NOT NULL DEFAULT '[]'"),
            # User-report intake columns. Engine-detected errors leave these empty.
            ("expected_behavior", "TEXT"),
            ("steps_to_reproduce_json", "TEXT NOT NULL DEFAULT '[]'"),
            ("report_context_json", "TEXT NOT NULL DEFAULT '{}'"),
            ("notify_on_update", "INTEGER NOT NULL DEFAULT 0"),
            ("reporter_id", "TEXT"),
            ("reporter_email", "TEXT"),
            ("reporter_username", "TEXT"),
            # First-pass observability analysis output (BuildObservability
            # node, user_report flavor). NULL until the analyzer runs.
            ("observability_json", "TEXT"),
            # When the analyzer fails, the reason lands here so the
            # dashboard can distinguish "in flight" (both NULL) from
            # "failed" (observability_error populated) without parsing
            # context.json. Cleared on subsequent success.
            ("observability_error", "TEXT"),
            # Track A (v1.1.18): RepoQualityJudge verdict on the repro
            # artifact. NULL while DAG runs; set to
            # 'awaiting_quality_review' when the judge flags presence-
            # only or symptom-mismatched repros so the dashboard can
            # surface them for human review without parsing context.json.
            ("quality_status", "TEXT"),
            # v1.1.19: portal + modification + staging-push pipeline.
            # ResolveNode persists resolution_commit_sha after _commit_resolution
            # succeeds; the bug-portal route renders `git show <sha>` from it.
            ("resolution_commit_sha", "TEXT"),
            # Null = root user report. Non-null = "request changes" modification
            # row, linked to its parent so the analyst sees the parent's commit
            # as prior context.
            ("parent_error_task_id", "TEXT"),
            # Single-use opaque token for /bugs/{token} portal access. Minted
            # in ResolveNode at resolve time. Lookup is by exact match.
            ("portal_token", "TEXT"),
            # Lifecycle of the staging push:
            #   unpushed  → resolved but not yet pushed
            #   pushed    → user clicked Approve and push succeeded to both remotes
            #   rejected  → user clicked "Request changes" (rare; usually creates
            #               a child row instead, but kept for explicit reject)
            #   push_failed → push attempted, returned non-zero on either remote
            ("staging_push_status", "TEXT NOT NULL DEFAULT 'unpushed'"),
            ("created_at", "INTEGER NOT NULL DEFAULT 0"),
            ("updated_at", "INTEGER NOT NULL DEFAULT 0"),
        ]

        for col, decl in required:
            if col not in existing_cols:
                conn.execute(f"ALTER TABLE error_tasks ADD COLUMN {col} {decl};")

        # Indexes required for dedupe + query patterns.
        conn.execute("DROP INDEX IF EXISTS uniq_error_tasks_fingerprint_active;")
        conn.execute(
            "CREATE UNIQUE INDEX IF NOT EXISTS uniq_error_tasks_fingerprint_active "
            "ON error_tasks(fingerprint) "
            "WHERE status NOT IN ('closed','ignored','duplicate','resolved','blocked');"
        )
        conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_error_tasks_project_id_created_at "
            "ON error_tasks(project_id, created_at);"
        )
        conn.execute("CREATE INDEX IF NOT EXISTS idx_error_tasks_run_id ON error_tasks(run_id);")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_error_tasks_status ON error_tasks(status);")
        # v1.1.19: fast lookup by portal_token for the bugs portal route.
        conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_error_tasks_portal_token ON error_tasks(portal_token);"
        )

    def _ensure_project_queue_schema(self, conn: sqlite3.Connection, *, table: str, required: list[tuple[str, str]], indexes: list[str]) -> None:
        row = conn.execute(
            f"SELECT 1 FROM sqlite_master WHERE type='table' AND name='{table}' LIMIT 1"
        ).fetchone()
        if row is None:
            return
        existing_cols = {r[1] for r in conn.execute(f"PRAGMA table_info({table});").fetchall()}
        for col, decl in required:
            if col not in existing_cols:
                conn.execute(f"ALTER TABLE {table} ADD COLUMN {col} {decl};")
        for sql in indexes:
            conn.execute(sql)

    def _ensure_integration_queue_schema(self, conn: sqlite3.Connection) -> None:
        self._ensure_project_queue_schema(
            conn,
            table="integration_queue",
            required=[
                ("integration_queue_id", "TEXT"), ("project_id", "TEXT"), ("enqueue_run_id", "TEXT NOT NULL DEFAULT ''"),
                ("idea_id", "TEXT NOT NULL DEFAULT ''"), ("title", "TEXT NOT NULL DEFAULT ''"),
                ("integration_payload_path", "TEXT NOT NULL DEFAULT ''"), ("status", "TEXT NOT NULL DEFAULT 'queued'"),
                ("claimed_by_worker_id", "TEXT"), ("claimed_at", "INTEGER"), ("started_run_id", "TEXT"),
                ("finished_run_id", "TEXT"), ("failure_message", "TEXT"), ("failure_context_json", "TEXT"),
                ("created_at", "INTEGER NOT NULL DEFAULT 0"), ("updated_at", "INTEGER NOT NULL DEFAULT 0"),
            ],
            indexes=["CREATE INDEX IF NOT EXISTS idx_integration_queue_project_status_created_at ON integration_queue(project_id, status, created_at);"]
        )

    def _ensure_story_queue_schema(self, conn: sqlite3.Connection) -> None:
        self._ensure_project_queue_schema(
            conn,
            table="scope_queue",
            required=[
                ("scope_queue_id", "TEXT"), ("project_id", "TEXT"), ("enqueue_run_id", "TEXT NOT NULL DEFAULT ''"),
                ("scope_set_id", "TEXT"), ("scope_id", "TEXT NOT NULL DEFAULT ''"), ("title", "TEXT NOT NULL DEFAULT ''"),
                ("scope_payload_path", "TEXT NOT NULL DEFAULT ''"), ("status", "TEXT NOT NULL DEFAULT 'queued'"),
                ("claimed_by_worker_id", "TEXT"), ("claimed_at", "INTEGER"), ("started_run_id", "TEXT"),
                ("finished_run_id", "TEXT"), ("failure_message", "TEXT"), ("failure_context_json", "TEXT"), ("created_at", "INTEGER NOT NULL DEFAULT 0"),
                ("updated_at", "INTEGER NOT NULL DEFAULT 0"),
            ],
            indexes=["CREATE INDEX IF NOT EXISTS idx_scope_queue_project_status_created_at ON scope_queue(project_id, status, created_at);"]
        )
        self._ensure_project_queue_schema(
            conn,
            table="idea_creation_queue",
            required=[
                ("idea_creation_queue_id", "TEXT"), ("project_id", "TEXT"), ("enqueue_run_id", "TEXT NOT NULL DEFAULT ''"),
                ("idea_id", "TEXT NOT NULL DEFAULT ''"), ("title", "TEXT NOT NULL DEFAULT ''"), ("idea_payload_path", "TEXT NOT NULL DEFAULT ''"),
                ("status", "TEXT NOT NULL DEFAULT 'queued'"), ("claimed_by_worker_id", "TEXT"), ("claimed_at", "INTEGER"),
                ("started_run_id", "TEXT"), ("finished_run_id", "TEXT"), ("failure_message", "TEXT"), ("failure_context_json", "TEXT"),
                ("created_at", "INTEGER NOT NULL DEFAULT 0"), ("updated_at", "INTEGER NOT NULL DEFAULT 0"),
            ],
            indexes=["CREATE INDEX IF NOT EXISTS idx_idea_creation_queue_project_status_created_at ON idea_creation_queue(project_id, status, created_at);"]
        )
        self._ensure_project_queue_schema(
            conn,
            table="idea_queue",
            required=[
                ("idea_queue_id", "TEXT"), ("project_id", "TEXT"), ("enqueue_run_id", "TEXT NOT NULL DEFAULT ''"),
                ("idea_id", "TEXT NOT NULL DEFAULT ''"), ("title", "TEXT NOT NULL DEFAULT ''"), ("idea_payload_path", "TEXT NOT NULL DEFAULT ''"),
                ("candidate_planes_json", "TEXT NOT NULL DEFAULT '[]'"), ("status", "TEXT NOT NULL DEFAULT 'queued'"),
                ("claimed_by_worker_id", "TEXT"), ("claimed_at", "INTEGER"), ("started_run_id", "TEXT"),
                ("finished_run_id", "TEXT"), ("failure_message", "TEXT"), ("failure_context_json", "TEXT"), ("created_at", "INTEGER NOT NULL DEFAULT 0"),
                ("updated_at", "INTEGER NOT NULL DEFAULT 0"),
            ],
            indexes=["CREATE INDEX IF NOT EXISTS idx_idea_queue_project_status_created_at ON idea_queue(project_id, status, created_at);"]
        )
        self._ensure_project_queue_schema(
            conn,
            table="story_queue",
            required=[
                ("story_queue_id", "TEXT"), ("project_id", "TEXT"), ("enqueue_run_id", "TEXT NOT NULL DEFAULT ''"),
                ("story_artifact_id", "TEXT NOT NULL DEFAULT ''"), ("story_id", "TEXT NOT NULL DEFAULT ''"), ("title", "TEXT NOT NULL DEFAULT ''"),
                ("status", "TEXT NOT NULL DEFAULT 'queued'"), ("claimed_by_worker_id", "TEXT"), ("claimed_at", "INTEGER"),
                ("started_run_id", "TEXT"), ("finished_run_id", "TEXT"), ("failure_message", "TEXT"), ("failure_context_json", "TEXT"),
                ("created_at", "INTEGER NOT NULL DEFAULT 0"), ("updated_at", "INTEGER NOT NULL DEFAULT 0"),
            ],
            indexes=[
                "CREATE INDEX IF NOT EXISTS idx_story_queue_project_status_created_at ON story_queue(project_id, status, created_at);",
                "CREATE INDEX IF NOT EXISTS idx_story_queue_artifact_id ON story_queue(story_artifact_id);",
            ]
        )
        self._ensure_project_queue_schema(
            conn,
            table="recovery_queue",
            required=[
                ("recovery_queue_id", "TEXT"), ("project_id", "TEXT"), ("enqueue_run_id", "TEXT NOT NULL DEFAULT ''"),
                ("source_queue_type", "TEXT NOT NULL DEFAULT ''"), ("source_item_id", "TEXT NOT NULL DEFAULT ''"), ("title", "TEXT NOT NULL DEFAULT ''"),
                ("recovery_request_path", "TEXT NOT NULL DEFAULT ''"), ("status", "TEXT NOT NULL DEFAULT 'queued'"), ("claimed_by_worker_id", "TEXT"),
                ("claimed_at", "INTEGER"), ("started_run_id", "TEXT"), ("finished_run_id", "TEXT"), ("failure_message", "TEXT"),
                ("failure_context_json", "TEXT"), ("created_at", "INTEGER NOT NULL DEFAULT 0"), ("updated_at", "INTEGER NOT NULL DEFAULT 0"),
            ],
            indexes=["CREATE INDEX IF NOT EXISTS idx_recovery_queue_project_status_created_at ON recovery_queue(project_id, status, created_at);"]
        )

    def _ensure_project_workers_schema(self, conn: sqlite3.Connection) -> None:
        row = conn.execute(
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name='project_workers' LIMIT 1"
        ).fetchone()
        if row is None:
            return

        existing_cols = {r[1] for r in conn.execute("PRAGMA table_info(project_workers);").fetchall()}
        required: list[tuple[str, str]] = [
            ("worker_id", "TEXT"),
            ("project_id", "TEXT NOT NULL DEFAULT ''"),
            ("repo_root", "TEXT NOT NULL DEFAULT ''"),
            ("status", "TEXT NOT NULL DEFAULT 'idle'"),
            ("active_queue_type", "TEXT"),
            ("active_item_id", "TEXT"),
            ("current_run_id", "TEXT"),
            ("current_node_exec_id", "TEXT"),
            ("started_at", "INTEGER NOT NULL DEFAULT 0"),
            ("updated_at", "INTEGER NOT NULL DEFAULT 0"),
            ("stopped_at", "INTEGER"),
            ("stop_requested_at", "INTEGER"),
        ]
        for col, decl in required:
            if col not in existing_cols:
                conn.execute(f"ALTER TABLE project_workers ADD COLUMN {col} {decl};")

        conn.execute("DROP INDEX IF EXISTS uniq_project_workers_active_project;")
        conn.execute(
            "CREATE UNIQUE INDEX IF NOT EXISTS uniq_project_workers_active_project "
            "ON project_workers(project_id) "
            "WHERE status IN ('starting','running','idle','stopping');"
        )

    def _ensure_task_queue_schema(self, conn: sqlite3.Connection) -> None:
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS task_records (
              task_id TEXT PRIMARY KEY,
              project_id TEXT,
              queue_name TEXT NOT NULL,
              task_kind TEXT NOT NULL,
              status TEXT NOT NULL,
              priority INTEGER NOT NULL DEFAULT 100,
              idempotency_key TEXT,
              parent_task_id TEXT,
              source_run_id TEXT,
              lease_token TEXT,
              lease_expires_at INTEGER,
              claimed_by_worker_id TEXT,
              claimed_at INTEGER,
              available_at INTEGER NOT NULL,
              started_at INTEGER,
              finished_at INTEGER,
              attempts INTEGER NOT NULL DEFAULT 0,
              max_attempts INTEGER NOT NULL DEFAULT 3,
              last_error TEXT,
              input_json TEXT NOT NULL,
              context_json TEXT NOT NULL,
              result_json TEXT,
              created_at INTEGER NOT NULL,
              updated_at INTEGER NOT NULL,
              FOREIGN KEY(project_id) REFERENCES projects(project_id),
              FOREIGN KEY(parent_task_id) REFERENCES task_records(task_id),
              FOREIGN KEY(source_run_id) REFERENCES runs(run_id)
            );

            CREATE UNIQUE INDEX IF NOT EXISTS uniq_task_records_idempotency_active
              ON task_records(queue_name, idempotency_key)
              WHERE idempotency_key IS NOT NULL
                AND status NOT IN ('completed','failed','cancelled','dead_letter');

            CREATE INDEX IF NOT EXISTS idx_task_records_queue_claim
              ON task_records(queue_name, status, available_at, priority, created_at);

            CREATE INDEX IF NOT EXISTS idx_task_records_project_created
              ON task_records(project_id, created_at);

            CREATE TABLE IF NOT EXISTS task_steps (
              task_step_id TEXT PRIMARY KEY,
              task_id TEXT NOT NULL,
              step_name TEXT NOT NULL,
              seq INTEGER NOT NULL,
              status TEXT NOT NULL,
              payload_json TEXT NOT NULL,
              created_at INTEGER NOT NULL,
              updated_at INTEGER NOT NULL,
              FOREIGN KEY(task_id) REFERENCES task_records(task_id)
            );

            CREATE INDEX IF NOT EXISTS idx_task_steps_task_seq ON task_steps(task_id, seq);

            CREATE TABLE IF NOT EXISTS task_messages (
              task_message_id TEXT PRIMARY KEY,
              task_id TEXT NOT NULL,
              message_kind TEXT NOT NULL,
              stream TEXT NOT NULL,
              payload_json TEXT NOT NULL,
              created_at INTEGER NOT NULL,
              FOREIGN KEY(task_id) REFERENCES task_records(task_id)
            );

            CREATE INDEX IF NOT EXISTS idx_task_messages_task_created ON task_messages(task_id, created_at);
            """
        )

    def _ensure_schema(self) -> None:
        now = int(time.time())
        with self._connect() as conn:
            conn.executescript(SCHEMA_SQL)
            self._ensure_artifacts_schema(conn)
            self._ensure_error_tasks_schema(conn)
            self._ensure_story_queue_schema(conn)
            self._ensure_integration_queue_schema(conn)
            self._ensure_project_workers_schema(conn)
            self._ensure_task_queue_schema(conn)
            # Seed meta row if empty.
            row = conn.execute("SELECT schema_version FROM meta LIMIT 1").fetchone()
            if row is None:
                conn.execute(
                    "INSERT INTO meta(schema_version, created_at, updated_at) VALUES(?,?,?)",
                    (SCHEMA_VERSION, now, now),
                )
            else:
                # Best-effort bump updated_at.
                conn.execute("UPDATE meta SET updated_at=?", (now,))

    def _ensure_project_row(self, conn: sqlite3.Connection, *, project_id: str | None, repo_root: Path | None) -> None:
        if not project_id:
            return
        row = conn.execute("SELECT 1 FROM projects WHERE project_id=? LIMIT 1", (project_id,)).fetchone()
        if row is not None:
            return
        now = int(time.time())
        conn.execute(
            "INSERT INTO projects(project_id, created_at, name, repo_root, metadata_json) VALUES(?,?,?,?,?)",
            (project_id, now, project_id, str(repo_root or Path(".")), json.dumps({}, sort_keys=True)),
        )

    def _resolve_project_id_for_queue_insert(self, conn: sqlite3.Connection, *, project_id: str | None, repo_root: Path | None) -> str | None:
        if project_id:
            self._ensure_project_row(conn, project_id=project_id, repo_root=repo_root)
            return project_id
        if repo_root is None:
            return None
        row = conn.execute(
            "SELECT project_id FROM projects WHERE repo_root=? ORDER BY created_at DESC LIMIT 1",
            (str(repo_root),),
        ).fetchone()
        if row is None:
            return None
        return str(row["project_id"] or "") or None

    # ---------------------------------------------------------------------
    # Area 3 public API
    # ---------------------------------------------------------------------
    def create_run(
        self,
        *,
        dag_id: str,
        dag_version: str | None,
        root_correlation_id: str,
        config: dict[str, Any],
    ) -> str:
        run_id = str(uuid.uuid4())
        now = int(time.time())
        with self._connect() as conn:
            conn.execute(
                (
                    "INSERT INTO runs(run_id, dag_id, dag_version, status, started_at, finished_at, "
                    "root_correlation_id, config_json, created_at, updated_at) "
                    "VALUES(?,?,?,?,?,?,?,?,?,?)"
                ),
                (
                    run_id,
                    dag_id,
                    dag_version,
                    "created",
                    None,
                    None,
                    root_correlation_id,
                    json.dumps(config, sort_keys=True),
                    now,
                    now,
                ),
            )
        return run_id

    def mark_run_started(self, *, run_id: str) -> None:
        now = int(time.time())
        with self._connect() as conn:
            conn.execute(
                (
                    "UPDATE runs SET status=CASE WHEN status='created' THEN 'running' ELSE status END, "
                    "started_at=COALESCE(started_at, ?), updated_at=? WHERE run_id=?"
                ),
                (now, now, run_id),
            )

    def mark_run_finished(self, *, run_id: str, status: str) -> None:
        now = int(time.time())
        with self._connect() as conn:
            conn.execute(
                (
                    "UPDATE runs SET status=?, finished_at=COALESCE(finished_at, ?), "
                    "updated_at=? WHERE run_id=?"
                ),
                (status, now, now, run_id),
            )

    def create_node_attempt(
        self,
        *,
        run_id: str,
        node_id: str,
        node_name: str | None,
        attempt: int,
        correlation_id: str | None = None,
        input: dict[str, Any] | None = None,
    ) -> str:
        node_exec_id = str(uuid.uuid4())
        # Use millisecond resolution to keep ordering stable in fast unit tests.
        now = int(time.time() * 1000)
        with self._connect() as conn:
            conn.execute(
                (
                    "INSERT INTO nodes(node_exec_id, run_id, node_id, node_name, status, attempt, "
                    "started_at, finished_at, correlation_id, input_json, output_json, created_at, updated_at) "
                    "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)"
                ),
                (
                    node_exec_id,
                    run_id,
                    node_id,
                    node_name,
                    "running",
                    int(attempt),
                    now,
                    None,
                    correlation_id,
                    None if input is None else json.dumps(input, sort_keys=True),
                    None,
                    now,
                    now,
                ),
            )
        return node_exec_id

    def mark_node_finished(
        self,
        *,
        node_exec_id: str,
        status: str,
        output: dict[str, Any] | None = None,
        error: dict[str, Any] | None = None,
        correlation_id: str | None = None,
    ) -> None:
        now = int(time.time() * 1000)
        with self._connect() as conn:
            row = conn.execute(
                "SELECT run_id, correlation_id FROM nodes WHERE node_exec_id=?",
                (node_exec_id,),
            ).fetchone()
            run_id = row["run_id"] if row is not None else None
            existing_corr = row["correlation_id"] if row is not None else None

            conn.execute(
                (
                    "UPDATE nodes SET status=?, finished_at=COALESCE(finished_at, ?), "
                    "output_json=COALESCE(output_json, ?), correlation_id=COALESCE(correlation_id, ?), "
                    "updated_at=? WHERE node_exec_id=?"
                ),
                (
                    status,
                    now,
                    None if output is None else json.dumps(output, sort_keys=True),
                    correlation_id,
                    now,
                    node_exec_id,
                ),
            )

            if status == "failed":
                # Link error to node; keep it minimal for tests.
                err_id = str(uuid.uuid4())
                msg = "" if error is None else str(error.get("message") or "")
                conn.execute(
                    (
                        "INSERT INTO errors(error_id, run_id, node_exec_id, scope, error_type, message, stacktrace, "
                        "cause_json, correlation_id, created_at) VALUES(?,?,?,?,?,?,?,?,?,?)"
                    ),
                    (
                        err_id,
                        run_id,
                        node_exec_id,
                        "node",
                        None,
                        msg or "node failed",
                        None,
                        None if error is None else json.dumps(error, sort_keys=True),
                        correlation_id or existing_corr,
                        now,
                    ),
                )

    def update_node_progress(
        self,
        *,
        node_exec_id: str,
        progress: dict[str, Any],
    ) -> None:
        """Write interim progress into a running node's output_json without changing its status.

        Used by long-running nodes (e.g. GreenNode) to surface per-iteration state
        so monitoring tools can distinguish active work from a stale hang.
        """
        now = int(time.time() * 1000)
        with self._connect() as conn:
            conn.execute(
                "UPDATE nodes SET output_json=?, updated_at=? WHERE node_exec_id=?",
                (json.dumps(progress, sort_keys=True), now, node_exec_id),
            )

    def add_artifact(
        self,
        *,
        run_id: str,
        node_exec_id: str | None,
        kind: str,
        uri: str,
        metadata: dict[str, Any] | None = None,
        content_type: str | None = None,
        byte_size: int | None = None,
        sha256: str | None = None,
    ) -> str:
        artifact_id = str(uuid.uuid4())
        now = int(time.time())
        with self._connect() as conn:
            conn.execute(
                (
                    "INSERT INTO artifacts(artifact_id, run_id, node_exec_id, kind, uri, content_type, byte_size, "
                    "sha256, metadata_json, created_at, updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)"
                ),
                (
                    artifact_id,
                    run_id,
                    node_exec_id,
                    kind,
                    uri,
                    content_type,
                    byte_size,
                    sha256,
                    json.dumps(metadata or {}, sort_keys=True),
                    now,
                    now,
                ),
            )
            # Compatibility: populate `type` if the column exists (Area 9 tests).
            try:
                conn.execute("UPDATE artifacts SET type=? WHERE artifact_id=?", (kind, artifact_id))
            except Exception:
                pass
        return artifact_id

    # ---------------------------------------------------------------------
    # Area 3 structured logging
    # ---------------------------------------------------------------------
    def _append_text_line(self, path: Path, line: str) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as f:
            f.write(line)
            if not line.endswith("\n"):
                f.write("\n")

    def _append_jsonl(self, path: Path, obj: dict[str, Any]) -> None:
        self._append_text_line(path, json.dumps(obj, sort_keys=True))

    def log_event(
        self,
        *,
        run_id: str,
        root_correlation_id: str,
        event: str,
        level: str,
        msg: str,
        data: dict[str, Any] | None = None,
    ) -> None:
        now = int(time.time())
        run_log_dir = self.db_path.parent / "logs" / "runs" / run_id
        self._append_text_line(run_log_dir / "run.log", f"[{now}] {level.upper()} {event}: {msg}")
        payload: dict[str, Any] = {
            "ts": now,
            "run_id": run_id,
            "root_correlation_id": root_correlation_id,
            "event": event,
            "level": level,
            "msg": msg,
        }
        if data is not None:
            payload["data"] = data
        self._append_jsonl(run_log_dir / "events.jsonl", payload)

    def log_tool_io(
        self,
        *,
        run_id: str,
        node_exec_id: str,
        node_id: str,
        attempt: int,
        correlation_id: str,
        tool_name: str,
        tool_call_id: str,
        input_summary: dict[str, Any] | None = None,
        output_summary: dict[str, Any] | None = None,
        data: dict[str, Any] | None = None,
    ) -> None:
        now = int(time.time())
        tool_dir = self.db_path.parent / "logs" / "tools" / run_id / node_exec_id / tool_name
        self._append_text_line(tool_dir / "tool.log", f"[{now}] tool={tool_name} call_id={tool_call_id}")
        ev: dict[str, Any] = {
            "ts": now,
            "run_id": run_id,
            "node_exec_id": node_exec_id,
            "node_id": node_id,
            "attempt": int(attempt),
            "correlation_id": correlation_id,
            "tool_name": tool_name,
            "tool_call_id": tool_call_id,
            "input_summary": input_summary or {},
            "output_summary": output_summary or {},
        }
        if data is not None:
            ev["data"] = data
        self._append_jsonl(tool_dir / "io.jsonl", ev)

    # ---------------------------------------------------------------------
    # Legacy APIs used by earlier areas / CLI
    # ---------------------------------------------------------------------
    def start_run(self, *, kind: str, repo_root: Path, args: dict[str, Any]) -> RunRecord:
        """Legacy: start a run record for older CLI commands."""
        run_id = str(uuid.uuid4())
        created_at = int(time.time())
        with self._connect() as conn:
            conn.execute(
                (
                    "INSERT INTO runs(run_id, kind, status, started_at, root_correlation_id, config_json, "
                    "repo_root, args_json, created_at, updated_at) VALUES(?,?,?,?,?,?,?,?,?,?)"
                ),
                (
                    run_id,
                    kind,
                    "running",
                    created_at,
                    None,
                    json.dumps({}, sort_keys=True),
                    str(repo_root),
                    json.dumps(args, sort_keys=True),
                    created_at,
                    created_at,
                ),
            )
        return RunRecord(run_id=run_id, kind=kind, created_at=created_at)

    def add_event(
        self,
        *,
        run_id: str,
        level: str,
        message: str,
        payload: dict[str, Any] | None = None,
    ) -> None:
        event_id = str(uuid.uuid4())
        created_at = int(time.time())
        with self._connect() as conn:
            conn.execute(
                (
                    "INSERT INTO events(event_id, run_id, created_at, level, message, payload_json) "
                    "VALUES(?,?,?,?,?,?)"
                ),
                (
                    event_id,
                    run_id,
                    created_at,
                    level,
                    message,
                    None if payload is None else json.dumps(payload, sort_keys=True),
                ),
            )

    def upsert_project(self, *, name: str, repo_root: Path, metadata: dict[str, Any]) -> str:
        project_id = str(uuid.uuid4())
        created_at = int(time.time())
        with self._connect() as conn:
            conn.execute(
                "INSERT INTO projects(project_id, created_at, name, repo_root, metadata_json) VALUES(?,?,?,?,?)",
                (project_id, created_at, name, str(repo_root), json.dumps(metadata, sort_keys=True)),
            )
        return project_id

    def list_projects(self) -> list[dict[str, Any]]:
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT project_id, created_at, name, repo_root, metadata_json FROM projects ORDER BY created_at DESC"
            ).fetchall()
        return [
            {
                "project_id": r["project_id"],
                "created_at": r["created_at"],
                "name": r["name"],
                "repo_root": r["repo_root"],
                "metadata": json.loads(r["metadata_json"]),
            }
            for r in rows
        ]

    def remove_project(self, *, project_id: str) -> None:
        with self._connect() as conn:
            conn.execute("DELETE FROM stories WHERE project_id=?", (project_id,))
            conn.execute("DELETE FROM projects WHERE project_id=?", (project_id,))

    def upsert_story(
        self,
        *,
        story_id: str,
        title: str,
        path: Path,
        contract: dict[str, Any],
        project_id: str | None = None,
        status: str = "registered",
    ) -> None:
        created_at = int(time.time())
        with self._connect() as conn:
            conn.execute(
                (
                    "INSERT OR REPLACE INTO stories(story_id, created_at, project_id, title, path, contract_json, status) "
                    "VALUES(?,?,?,?,?,?,?)"
                ),
                (
                    story_id,
                    created_at,
                    project_id,
                    title,
                    str(path),
                    json.dumps(contract, sort_keys=True),
                    status,
                ),
            )

    def list_stories(self, project_id: str | None = None) -> list[dict[str, Any]]:
        query = "SELECT story_id, created_at, project_id, title, path, status, contract_json FROM stories"
        params: Iterable[Any] = []
        if project_id is not None:
            query += " WHERE project_id=?"
            params = [project_id]
        query += " ORDER BY created_at DESC"
        with self._connect() as conn:
            rows = conn.execute(query, tuple(params)).fetchall()
        return [
            {
                "story_id": r["story_id"],
                "created_at": r["created_at"],
                "project_id": r["project_id"],
                "title": r["title"],
                "path": r["path"],
                "status": r["status"],
                "contract": json.loads(r["contract_json"]),
            }
            for r in rows
        ]

    def get_story(self, story_id: str) -> dict[str, Any] | None:
        with self._connect() as conn:
            r = conn.execute(
                "SELECT story_id, created_at, project_id, title, path, status, contract_json FROM stories WHERE story_id=?",
                (story_id,),
            ).fetchone()
        if r is None:
            return None
        return {
            "story_id": r["story_id"],
            "created_at": r["created_at"],
            "project_id": r["project_id"],
            "title": r["title"],
            "path": r["path"],
            "status": r["status"],
            "contract": json.loads(r["contract_json"]),
        }

    def update_story_status(self, *, story_id: str, status: str) -> None:
        with self._connect() as conn:
            conn.execute(
                (
                    "UPDATE stories SET status=? "
                    "WHERE story_id=? OR json_extract(contract_json, '$.story_id')=? OR json_extract(contract_json, '$.story_uuid')=?"
                ),
                (status, story_id, story_id, story_id),
            )

    def add_review_packet(
        self,
        *,
        run_id: str,
        story_id: str | None,
        summary: str,
        findings: dict[str, Any],
    ) -> str:
        packet_id = str(uuid.uuid4())
        now = int(time.time())
        with self._connect() as conn:
            conn.execute(
                (
                    "INSERT INTO review_packets(review_packet_id, run_id, node_exec_id, status, request_json, response_json, "
                    "created_at, updated_at, packet_id, story_id, summary, findings_json) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)"
                ),
                (
                    packet_id,
                    run_id,
                    None,
                    "created",
                    json.dumps({}, sort_keys=True),
                    None,
                    now,
                    now,
                    packet_id,
                    story_id,
                    summary,
                    json.dumps(findings, sort_keys=True),
                ),
            )
        return packet_id

    def create_review_run(
        self,
        *,
        run_id: str,
        story_id: str | None,
        packet_hash: str,
        story_hash: str,
        config_hash: str,
        output_dir: str,
        change_ref: str | None = None,
    ) -> str:
        review_run_id = str(uuid.uuid4())
        now = int(time.time())
        with self._connect() as conn:
            conn.execute(
                (
                    "INSERT INTO review_runs(review_run_id, run_id, status, review_status, story_id, packet_hash, "
                    "story_hash, config_hash, output_dir, change_ref, created_at, started_at, finished_at, updated_at) "
                    "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
                ),
                (
                    review_run_id,
                    run_id,
                    "running",
                    "pending",
                    story_id,
                    packet_hash,
                    story_hash,
                    config_hash,
                    output_dir,
                    change_ref,
                    now,
                    now,
                    None,
                    now,
                ),
            )
        return review_run_id

    def mark_review_run_finished(self, *, review_run_id: str, status: str, review_status: str) -> None:
        now = int(time.time())
        with self._connect() as conn:
            conn.execute(
                (
                    "UPDATE review_runs SET status=?, review_status=?, finished_at=COALESCE(finished_at, ?), "
                    "updated_at=? WHERE review_run_id=?"
                ),
                (status, review_status, now, now, review_run_id),
            )

    def add_review_finding(
        self,
        *,
        review_run_id: str,
        finding_id: str,
        category: str,
        severity: str,
        title: str,
        description: str,
        recommendation: str,
        contract_refs: list[str],
        evidence_refs: list[str],
        fingerprint: str | None = None,
    ) -> str:
        review_finding_id = str(uuid.uuid4())
        now = int(time.time())
        with self._connect() as conn:
            conn.execute(
                (
                    "INSERT INTO review_findings(review_finding_id, review_run_id, finding_id, category, severity, title, "
                    "description, recommendation, contract_refs_json, evidence_refs_json, fingerprint, created_at) "
                    "VALUES(?,?,?,?,?,?,?,?,?,?,?,?)"
                ),
                (
                    review_finding_id,
                    review_run_id,
                    finding_id,
                    category,
                    severity,
                    title,
                    description,
                    recommendation,
                    json.dumps(contract_refs, sort_keys=True),
                    json.dumps(evidence_refs, sort_keys=True),
                    fingerprint,
                    now,
                ),
            )
        return review_finding_id


    def add_error(
        self,
        *,
        run_id: str,
        source: str,
        message: str,
        details: dict[str, Any],
        status: str = "open",
    ) -> str:
        error_id = str(uuid.uuid4())
        now = int(time.time())
        with self._connect() as conn:
            conn.execute(
                (
                    "INSERT INTO errors(error_id, run_id, node_exec_id, scope, error_type, message, stacktrace, cause_json, "
                    "correlation_id, status, source, details_json, created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)"
                ),
                (
                    error_id,
                    run_id,
                    None,
                    "run",
                    None,
                    message,
                    None,
                    None,
                    None,
                    status,
                    source,
                    json.dumps(details, sort_keys=True),
                    now,
                ),
            )
        return error_id

    def list_errors(self, status: str = "open") -> list[dict[str, Any]]:
        with self._connect() as conn:
            rows = conn.execute(
                (
                    "SELECT error_id, run_id, created_at, status, source, message, details_json "
                    "FROM errors WHERE status=? ORDER BY created_at DESC"
                ),
                (status,),
            ).fetchall()
        return [
            {
                "error_id": r["error_id"],
                "run_id": r["run_id"],
                "created_at": r["created_at"],
                "status": r["status"],
                "source": r["source"],
                "message": r["message"],
                "details": json.loads(r["details_json"]) if r["details_json"] else {},
            }
            for r in rows
        ]

    def close_error(self, error_id: str) -> None:
        with self._connect() as conn:
            conn.execute("UPDATE errors SET status='closed' WHERE error_id=?", (error_id,))

    # ------------------------------------------------------------------
    # Area 9: minimal error-task listing for playground surfaces
    # ------------------------------------------------------------------
    def list_error_tasks(self, status: str = "open") -> list[dict[str, Any]]:
        """List error tasks (Area 8 model), machine-readable.

        Area 9 tests expect:
        - fingerprint
        - occurrence_count
        - evidence links including run_id
        """

        with self._connect() as conn:
            self._ensure_error_tasks_schema(conn)
            rows = conn.execute(
                (
                    "SELECT error_task_id, project_id, run_id, plane, title, status, severity, "
                    "source_kind, source_app, source_ref, fingerprint, occurrence_count, message, "
                    "expected_behavior, steps_to_reproduce_json, report_context_json, "
                    "notify_on_update, reporter_id, reporter_email, reporter_username, "
                    "observability_json, observability_error, "
                    "created_at, updated_at "
                    "FROM error_tasks WHERE status=? ORDER BY created_at DESC"
                ),
                (status,),
            ).fetchall()

        items: list[dict[str, Any]] = []
        for r in rows:
            fp = str(r["fingerprint"] or "")
            source_ref = str(r["source_ref"] or "")
            source_kind = str(r["source_kind"] or "")
            # User-facing fingerprint prefix for playground parity.
            if source_kind == "playground" and source_ref:
                fp_user = f"playground:{source_ref}:{fp}"
            else:
                fp_user = fp
            try:
                steps = json.loads(r["steps_to_reproduce_json"] or "[]")
            except (TypeError, ValueError):
                steps = []
            try:
                ctx = json.loads(r["report_context_json"] or "{}")
            except (TypeError, ValueError):
                ctx = {}
            items.append(
                {
                    "error_task_id": r["error_task_id"],
                    "project_id": r["project_id"],
                    "run_id": r["run_id"] or None,
                    "plane": r["plane"],
                    "title": r["title"],
                    "status": r["status"],
                    "severity": r["severity"],
                    "source_kind": source_kind,
                    "source_app": r["source_app"] or None,
                    "source_ref": source_ref,
                    "fingerprint": fp_user,
                    "occurrence_count": int(r["occurrence_count"] or 0),
                    "message": r["message"],
                    "expected_behavior": r["expected_behavior"],
                    "steps_to_reproduce": steps,
                    "report_context": ctx,
                    "notify_on_update": bool(r["notify_on_update"] or 0),
                    "reporter_id": r["reporter_id"],
                    "reporter_email": r["reporter_email"],
                    "reporter_username": r["reporter_username"],
                    "observability": (lambda s: (json.loads(s) if s else None))(r["observability_json"]),
                    "observability_error": r["observability_error"],
                    "evidence": [{"run_id": r["run_id"]}] if r["run_id"] else [],
                    "created_at": r["created_at"],
                    "updated_at": r["updated_at"],
                }
            )
        return items

    # ------------------------------------------------------------------
    # Area 7/8: failure surfaces -> actionable error tasks
    # ------------------------------------------------------------------
    @staticmethod
    def _fingerprint_from_inputs(inputs: dict[str, Any]) -> str:
        """Create a stable dedupe fingerprint for an error task.

        Uses a canonical JSON encoding (sorted keys, compact separators) hashed
        with sha256.
        """

        payload = json.dumps(inputs or {}, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
        return hashlib.sha256(payload.encode("utf-8")).hexdigest()

    def _export_error_task_artifacts(self, *, error_task: dict[str, Any], export: dict[str, Any]) -> None:
        export_dir = self.db_path.parent / "error_tasks" / error_task["error_task_id"]
        export_dir.mkdir(parents=True, exist_ok=True)

        if export.get("json"):
            (export_dir / "error_task.json").write_text(
                json.dumps(error_task, sort_keys=True, indent=2, ensure_ascii=False) + "\n"
            )

        if export.get("markdown"):
            next_steps = error_task.get("next_steps") or []
            md_lines: list[str] = [
                f"# Error Task: {error_task.get('title','')}",
                "",
                f"- error_task_id: `{error_task['error_task_id']}`",
                f"- project_id: `{error_task.get('project_id')}`",
                f"- run_id: `{error_task.get('run_id')}`",
                f"- plane: `{error_task.get('plane')}`",
                f"- status: `{error_task.get('status')}`",
                f"- severity: `{error_task.get('severity')}`",
                f"- source_kind: `{error_task.get('source_kind')}`",
                f"- source_ref: `{error_task.get('source_ref')}`",
                f"- fingerprint: `{error_task.get('fingerprint')}`",
                f"- occurrence_count: `{error_task.get('occurrence_count')}`",
                "",
                "## Message",
                "",
                (error_task.get("message") or "").strip() or "(none)",
                "",
                "## Next steps",
                "",
            ]
            if next_steps:
                md_lines.extend([f"- {s}" for s in next_steps])
            else:
                md_lines.append("- (none)")
            md_lines.append("")
            (export_dir / "error_task.md").write_text("\n".join(md_lines))

    def create_error_task_from_failure(
        self,
        *,
        project_id: str | None,
        run_id: str,
        plane: str,
        source_kind: str,
        source_ref: str,
        title: str,
        severity: str,
        error_type: str | None,
        message: str,
        stacktrace: str | None,
        next_steps: list[str] | None,
        fingerprint_inputs: dict[str, Any],
        export: dict[str, Any] | None = None,
    ) -> str:
        """Convert a failure surface into a durable, actionable error task.

        Dedupe: for the same (project_id, fingerprint) if an existing task is
        non-terminal, increment occurrence_count and return its id.

        Important: resolved/blocked tasks are treated as terminal for new
        runtime-regression intake so a fresh recurrence gets its own task and
        can reference prior solved siblings.
        """

        now = int(time.time())
        fingerprint = self._fingerprint_from_inputs(fingerprint_inputs)
        terminal_statuses = {"closed", "ignored", "duplicate", "resolved", "blocked"}
        next_steps_list = next_steps or []
        next_steps_json = json.dumps(next_steps_list, ensure_ascii=False)

        with self._connect() as conn:
            resolved_project_id = project_id
            if resolved_project_id is None:
                run_row = conn.execute(
                    "SELECT repo_root FROM runs WHERE run_id=? LIMIT 1",
                    (run_id,),
                ).fetchone()
                run_repo_root = None
                if run_row is not None:
                    raw_repo_root = str(run_row["repo_root"] or "").strip()
                    if raw_repo_root:
                        run_repo_root = Path(raw_repo_root)
                resolved_project_id = self._resolve_project_id_for_queue_insert(
                    conn,
                    project_id=None,
                    repo_root=run_repo_root,
                )

            # Find an existing non-terminal task with the same fingerprint.
            if resolved_project_id is None:
                row = conn.execute(
                    (
                        "SELECT error_task_id, occurrence_count, status FROM error_tasks "
                        "WHERE project_id IS NULL AND fingerprint=? AND status NOT IN ('closed','ignored','duplicate','resolved','blocked') "
                        "ORDER BY created_at DESC LIMIT 1"
                    ),
                    (fingerprint,),
                ).fetchone()
            else:
                row = conn.execute(
                    (
                        "SELECT error_task_id, occurrence_count, status FROM error_tasks "
                        "WHERE project_id=? AND fingerprint=? AND status NOT IN ('closed','ignored','duplicate','resolved','blocked') "
                        "ORDER BY created_at DESC LIMIT 1"
                    ),
                    (resolved_project_id, fingerprint),
                ).fetchone()

            if row is not None:
                error_task_id = row["error_task_id"]
                conn.execute(
                    "UPDATE error_tasks SET occurrence_count=?, updated_at=? WHERE error_task_id=?",
                    (int(row["occurrence_count"]) + 1, now, error_task_id),
                )
            else:
                error_task_id = str(uuid.uuid4())
                conn.execute(
                    (
                        "INSERT INTO error_tasks("
                        "error_task_id, project_id, run_id, plane, title, status, severity, "
                        "source_kind, source_ref, fingerprint, occurrence_count, error_type, message, stacktrace, "
                        "next_steps_json, created_at, updated_at"
                        ") VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
                    ),
                    (
                        error_task_id,
                        resolved_project_id,
                        run_id,
                        plane,
                        title,
                        "open",
                        severity,
                        source_kind,
                        source_ref,
                        fingerprint,
                        1,
                        error_type,
                        message,
                        stacktrace,
                        next_steps_json,
                        now,
                        now,
                    ),
                )

        if export:
            error_task_payload = {
                "error_task_id": error_task_id,
                "project_id": resolved_project_id,
                "run_id": run_id,
                "plane": plane,
                "title": title,
                "status": "open",
                "severity": severity,
                "source_kind": source_kind,
                "source_ref": source_ref,
                "fingerprint": fingerprint,
                "occurrence_count": 1,
                "error_type": error_type,
                "message": message,
                "stacktrace": stacktrace,
                "next_steps": next_steps_list,
                "created_at": now,
                "updated_at": now,
            }
            # If we deduped, refresh from DB to get the canonical occurrence_count.
            with self._connect() as conn:
                row = conn.execute(
                    "SELECT status, occurrence_count, created_at, updated_at FROM error_tasks WHERE error_task_id=?",
                    (error_task_id,),
                ).fetchone()
                if row is not None:
                    error_task_payload["status"] = row["status"]
                    error_task_payload["occurrence_count"] = row["occurrence_count"]
                    error_task_payload["created_at"] = row["created_at"]
                    error_task_payload["updated_at"] = row["updated_at"]
            self._export_error_task_artifacts(error_task=error_task_payload, export=export)

        return error_task_id

    def create_error_task_from_user_report(
        self,
        *,
        project_id: str | None,
        source_app: str,
        external_id: str,
        title: str,
        message: str,
        expected_behavior: str | None = None,
        actual_behavior: str | None = None,
        steps_to_reproduce: list[str] | None = None,
        report_context: dict[str, Any] | None = None,
        severity: str = "medium",
        reporter_id: str | None = None,
        reporter_email: str | None = None,
        reporter_username: str | None = None,
        notify_on_update: bool = False,
    ) -> str:
        """Ingest a user-reported bug as an actionable error task.

        Dedupe key is sha256(source_app + external_id), so client-side
        idempotency works as long as the client picks a stable external_id
        (e.g. uuidv4 generated at form-open, not at submit).

        Stored as plane='user_report' / source_kind='user_report' so the
        Error DAG can distinguish user-reported intake from runtime captures
        and route differently (no observability build pass needed).
        """

        import hashlib as _hashlib

        now = int(time.time())
        steps = list(steps_to_reproduce or [])
        ctx = dict(report_context or {})
        # If the caller supplied actual_behavior separately, fold it into
        # message so the DAG's existing context-building doesn't have to
        # special-case the field.
        merged_message = message
        if actual_behavior and actual_behavior not in (message or ""):
            merged_message = ((message or "").rstrip() + "\n\nActual behavior:\n" + actual_behavior).strip()

        fingerprint = _hashlib.sha256(
            f"{source_app}|{external_id}".encode("utf-8")
        ).hexdigest()

        # error_tasks.run_id is NOT NULL with an FK to runs(run_id). User
        # reports have no engine run, so we synthesize a per-project sentinel
        # run row on first use ("user-report-<project>") and reference it.
        # Cheaper than schema-evolving NOT NULL away on existing prod DBs.
        sentinel_run_id = f"user-report-{project_id or 'global'}"

        with self._connect() as conn:
            self._ensure_error_tasks_schema(conn)
            conn.execute(
                "INSERT OR IGNORE INTO runs("
                "run_id, kind, status, config_json, created_at, updated_at"
                ") VALUES(?,?,?,?,?,?)",
                (sentinel_run_id, "user_report", "succeeded", "{}", now, now),
            )
            row = conn.execute(
                "SELECT error_task_id, occurrence_count FROM error_tasks "
                "WHERE fingerprint=? AND status NOT IN ('closed','ignored','duplicate','resolved','blocked') "
                "ORDER BY created_at DESC LIMIT 1",
                (fingerprint,),
            ).fetchone()
            if row is not None:
                error_task_id = row["error_task_id"]
                conn.execute(
                    "UPDATE error_tasks SET occurrence_count=?, updated_at=? WHERE error_task_id=?",
                    (int(row["occurrence_count"]) + 1, now, error_task_id),
                )
                return error_task_id

            error_task_id = str(uuid.uuid4())
            conn.execute(
                "INSERT INTO error_tasks("
                "error_task_id, project_id, run_id, plane, title, status, severity, "
                "source_kind, source_app, source_ref, fingerprint, occurrence_count, "
                "error_type, message, stacktrace, next_steps_json, "
                "expected_behavior, steps_to_reproduce_json, report_context_json, "
                "notify_on_update, reporter_id, reporter_email, reporter_username, "
                "created_at, updated_at"
                ") VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (
                    error_task_id,
                    project_id,
                    sentinel_run_id,
                    "user_report",
                    title,
                    "open",
                    severity,
                    "user_report",
                    source_app,
                    external_id,
                    fingerprint,
                    1,
                    None,
                    merged_message,
                    None,
                    "[]",
                    expected_behavior,
                    json.dumps(steps, ensure_ascii=False),
                    json.dumps(ctx, ensure_ascii=False, sort_keys=True),
                    1 if notify_on_update else 0,
                    reporter_id,
                    reporter_email,
                    reporter_username,
                    now,
                    now,
                ),
            )
        return error_task_id

    # ---------------------------------------------------------------------
    # v1.1.19 — bug-portal + modification-request + staging-push helpers
    # ---------------------------------------------------------------------
    def get_resolved_with_portal(self, error_task_id: str) -> dict[str, Any] | None:
        """Return a portal-shaped view of a resolved error_task row.

        Used by the host controller's /bugs/{token} route to render the
        review portal. Returns None when the row doesn't exist OR isn't
        resolved (the portal is only meaningful for resolved rows).
        """
        with self._connect() as conn:
            self._ensure_error_tasks_schema(conn)
            row = conn.execute(
                "SELECT error_task_id, project_id, title, message, status, "
                "reporter_email, reporter_username, "
                "observability_json, resolution_commit_sha, portal_token, "
                "parent_error_task_id, staging_push_status, "
                "expected_behavior, steps_to_reproduce_json, report_context_json, "
                "created_at, updated_at "
                "FROM error_tasks WHERE error_task_id=?",
                (error_task_id,),
            ).fetchone()
        if row is None:
            return None
        try:
            obs = json.loads(row["observability_json"]) if row["observability_json"] else None
        except (TypeError, ValueError):
            obs = None
        try:
            steps = json.loads(row["steps_to_reproduce_json"] or "[]")
        except (TypeError, ValueError):
            steps = []
        try:
            ctx = json.loads(row["report_context_json"] or "{}")
        except (TypeError, ValueError):
            ctx = {}
        repro_run_command = None
        if isinstance(obs, dict):
            repro_run_command = obs.get("repro_run_command")
        return {
            "error_task_id": row["error_task_id"],
            "project_id": row["project_id"],
            "title": row["title"],
            "message": row["message"],
            "status": row["status"],
            "reporter_email": row["reporter_email"],
            "reporter_username": row["reporter_username"],
            "observability": obs,
            "resolution_commit_sha": row["resolution_commit_sha"],
            "portal_token": row["portal_token"],
            "parent_error_task_id": row["parent_error_task_id"],
            "staging_push_status": row["staging_push_status"] or "unpushed",
            "expected_behavior": row["expected_behavior"],
            "steps_to_reproduce": steps,
            "report_context": ctx,
            "repro_run_command": repro_run_command,
            "created_at": row["created_at"],
            "updated_at": row["updated_at"],
        }

    def find_by_portal_token(self, token: str) -> dict[str, Any] | None:
        """Look up the error_task_id for a portal token, then return the
        same shape as :meth:`get_resolved_with_portal`. Returns None when
        the token doesn't match any row."""
        if not token:
            return None
        with self._connect() as conn:
            self._ensure_error_tasks_schema(conn)
            row = conn.execute(
                "SELECT error_task_id FROM error_tasks WHERE portal_token=? LIMIT 1",
                (token,),
            ).fetchone()
        if row is None:
            return None
        return self.get_resolved_with_portal(row["error_task_id"])

    def create_modification_request(self, parent_etid: str, message: str) -> str:
        """Create a "request changes" child error_task linked to a resolved parent.

        Copies project_id / reporter_* / source_app from the parent so the
        analyst pool can re-claim and re-run with the parent's commit as
        prior context. Returns the new error_task_id.

        Fingerprint is ``mod:<parent_etid>:<nonce>`` so each modification is
        unique even if the user spams the button — the active-fingerprint
        unique index would otherwise reject the second one.
        """
        if not parent_etid or not (message or "").strip():
            raise ValueError("parent_etid and non-empty message required")
        now = int(time.time())
        with self._connect() as conn:
            self._ensure_error_tasks_schema(conn)
            parent = conn.execute(
                "SELECT project_id, source_app, reporter_id, reporter_email, "
                "reporter_username, title, severity "
                "FROM error_tasks WHERE error_task_id=?",
                (parent_etid,),
            ).fetchone()
            if parent is None:
                raise ValueError(f"parent error_task {parent_etid} not found")

            new_etid = str(uuid.uuid4())
            nonce = uuid.uuid4().hex[:12]
            fingerprint = f"mod:{parent_etid}:{nonce}"
            sentinel_run_id = f"user-report-{parent['project_id'] or 'global'}"
            # Sentinel run row should already exist from the parent, but
            # be defensive in case schema was hand-seeded.
            conn.execute(
                "INSERT OR IGNORE INTO runs("
                "run_id, kind, status, config_json, created_at, updated_at"
                ") VALUES(?,?,?,?,?,?)",
                (sentinel_run_id, "user_report", "succeeded", "{}", now, now),
            )
            child_title = (parent["title"] or "modification request")
            if not child_title.lower().startswith("modification:"):
                child_title = f"Modification: {child_title}"
            child_title = child_title[:512]
            conn.execute(
                "INSERT INTO error_tasks("
                "error_task_id, project_id, run_id, plane, title, status, severity, "
                "source_kind, source_app, source_ref, fingerprint, occurrence_count, "
                "error_type, message, stacktrace, next_steps_json, "
                "expected_behavior, steps_to_reproduce_json, report_context_json, "
                "notify_on_update, reporter_id, reporter_email, reporter_username, "
                "parent_error_task_id, staging_push_status, "
                "created_at, updated_at"
                ") VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (
                    new_etid,
                    parent["project_id"],
                    sentinel_run_id,
                    "user_report",
                    child_title,
                    "open",
                    parent["severity"] or "medium",
                    "user_report",
                    parent["source_app"] or "",
                    f"mod:{parent_etid}",
                    fingerprint,
                    1,
                    None,
                    message.strip(),
                    None,
                    "[]",
                    None,
                    "[]",
                    json.dumps({"parent_error_task_id": parent_etid}, sort_keys=True),
                    0,
                    parent["reporter_id"],
                    parent["reporter_email"],
                    parent["reporter_username"],
                    parent_etid,
                    "unpushed",
                    now,
                    now,
                ),
            )
        return new_etid

    def mark_staging_pushed(self, error_task_id: str) -> None:
        """Flip staging_push_status='pushed' (called after a successful
        double-remote push from the host controller)."""
        now = int(time.time())
        with self._connect() as conn:
            self._ensure_error_tasks_schema(conn)
            conn.execute(
                "UPDATE error_tasks SET staging_push_status='pushed', updated_at=? "
                "WHERE error_task_id=?",
                (now, error_task_id),
            )

    def mark_staging_rejected(self, error_task_id: str) -> None:
        """Flip staging_push_status='rejected'. Distinct from push_failed:
        rejected = the user explicitly declined; push_failed = git refused."""
        now = int(time.time())
        with self._connect() as conn:
            self._ensure_error_tasks_schema(conn)
            conn.execute(
                "UPDATE error_tasks SET staging_push_status='rejected', updated_at=? "
                "WHERE error_task_id=?",
                (now, error_task_id),
            )

    def mark_staging_push_failed(self, error_task_id: str) -> None:
        """Flip staging_push_status='push_failed' (git push returned non-zero)."""
        now = int(time.time())
        with self._connect() as conn:
            self._ensure_error_tasks_schema(conn)
            conn.execute(
                "UPDATE error_tasks SET staging_push_status='push_failed', updated_at=? "
                "WHERE error_task_id=?",
                (now, error_task_id),
            )

    # ---------------------------------------------------------------------
    # Area 8.5 error solver DAG (Electron parity, minimal deterministic runner)
    # ---------------------------------------------------------------------
    def run_error_solver_dag(
        self,
        *,
        error_task_id: str,
        repo_root: Path,
        build_observability_fn: Callable[[dict[str, Any]], dict[str, Any]],
        first_pass_fix_fn: Callable[[dict[str, Any]], dict[str, Any]],
        iterative_fix_fn: Callable[[dict[str, Any]], dict[str, Any]],
        needs_user_input_fn: Callable[[dict[str, Any]], bool],
        runtime_context: dict[str, Any] | None = None,
        collect_evidence_fn: Callable[[dict[str, Any]], dict[str, Any]] | None = None,
        ship_fn: Callable[[dict[str, Any]], dict[str, Any]] | None = None,
        bypass_mode: str | None = None,
        worker_role: str | None = None,
        repo_quality_judge_fn: Callable[[dict[str, Any]], dict[str, Any]] | None = None,
    ) -> dict[str, Any]:
        """Run the US-8.5 error solver DAG using an artifact-first process contract.

        Happy path:
        - BuildEvidenceBundle (deterministic, durable artifact)
        - JudgeObservability (judgment from the bundle)
        - FirstPassFix -> IterativeFix -> FinalOutcomeRoute -> Resolve|Block
        """

        from ..errors.error_solver_dag import ErrorSolverWorkflow, configure_runtime
        from ..errors.runtime_observability import collect_runtime_evidence_bundle

        repo_root = Path(repo_root)
        now = int(time.time())

        with self._connect() as conn:
            row = conn.execute(
                "SELECT project_id FROM error_tasks WHERE error_task_id=?",
                (error_task_id,),
            ).fetchone()
            if row is None:
                raise ValueError(f"error_task_id not found: {error_task_id}")
            project_id = row["project_id"]
            conn.execute(
                "UPDATE error_tasks SET status='in_progress', updated_at=? WHERE error_task_id=?",
                (now, error_task_id),
            )

        effective_collect_evidence_fn = collect_evidence_fn or (
            lambda ctx: collect_runtime_evidence_bundle(
                repo_root=repo_root,
                runtime_context=ctx.get("runtimeContext") if isinstance(ctx.get("runtimeContext"), dict) else runtime_context,
                repro_command=(ctx.get("runtimeContext") or {}).get("repro_command") if isinstance(ctx.get("runtimeContext"), dict) else None,
                project_id=project_id,
                store=self,
                error_task_id=error_task_id,
            )
        )

        configure_runtime(
            store=self,
            funcs={
                "collect_evidence_fn": effective_collect_evidence_fn,
                "build_observability_fn": build_observability_fn,
                "first_pass_fix_fn": first_pass_fix_fn,
                "iterative_fix_fn": iterative_fix_fn,
                "needs_user_input_fn": needs_user_input_fn,
                "ship_fn": ship_fn,
                # Track A (v1.1.18): repro-quality judge runs after
                # BuildObservability persists out and before FirstPassFix.
                # Pure-LLM gate — see errors/repo_quality_judge.py.
                "repo_quality_judge_fn": repo_quality_judge_fn,
                # Role propagation for BuildObservabilityNode:
                # - analyst → always stop after observability
                # - fix → skip pi observability (use cached observation_json),
                #   never stop, let DAG flow to FirstPassFix
                # - None (legacy) → gate-aware stop (current behavior)
                "worker_role": worker_role,
            },
        )

        wf = ErrorSolverWorkflow()
        tc = wf.run({
            "repo_root": str(repo_root),
            "error_task_id": error_task_id,
            "runtime_context": runtime_context,
            "bypass_mode": bypass_mode,
        })

        result: dict[str, Any] = {"success": True, "error_task_id": error_task_id, "outcome": str(tc.metadata.get("outcome") or "blocked")}
        if tc.metadata.get("reason"):
            result["reason"] = tc.metadata["reason"]
        return result

    def enqueue_scope_task(
        self,
        *,
        project_id: str | None,
        enqueue_run_id: str,
        scope_set_id: str | None,
        scope_id: str,
        title: str,
        scope_payload_path: str,
    ) -> str:
        scope_queue_id = str(uuid.uuid4())
        now = int(time.time())
        with self._connect() as conn:
            repo_row = conn.execute("SELECT repo_root FROM runs WHERE run_id=?", (enqueue_run_id,)).fetchone()
            repo_root = None if repo_row is None or not repo_row["repo_root"] else Path(str(repo_row["repo_root"]))
            resolved_project_id = self._resolve_project_id_for_queue_insert(conn, project_id=project_id, repo_root=repo_root)
            conn.execute(
                "INSERT INTO scope_queue(scope_queue_id, project_id, enqueue_run_id, scope_set_id, scope_id, title, scope_payload_path, status, created_at, updated_at) VALUES(?,?,?,?,?,?,?,?,?,?)",
                (scope_queue_id, resolved_project_id, enqueue_run_id, scope_set_id, scope_id, title, scope_payload_path, "queued", now, now),
            )
        return scope_queue_id

    def enqueue_idea_creation_task(
        self,
        *,
        project_id: str | None,
        enqueue_run_id: str,
        idea_id: str,
        title: str,
        idea_payload_path: str,
    ) -> str:
        idea_creation_queue_id = str(uuid.uuid4())
        now = int(time.time())
        with self._connect() as conn:
            repo_row = conn.execute("SELECT repo_root FROM runs WHERE run_id=?", (enqueue_run_id,)).fetchone()
            repo_root = None if repo_row is None or not repo_row["repo_root"] else Path(str(repo_row["repo_root"]))
            resolved_project_id = self._resolve_project_id_for_queue_insert(conn, project_id=project_id, repo_root=repo_root)
            conn.execute(
                "INSERT INTO idea_creation_queue(idea_creation_queue_id, project_id, enqueue_run_id, idea_id, title, idea_payload_path, status, created_at, updated_at) VALUES(?,?,?,?,?,?,?,?,?)",
                (idea_creation_queue_id, resolved_project_id, enqueue_run_id, idea_id, title, idea_payload_path, "queued", now, now),
            )
        return idea_creation_queue_id

    def enqueue_idea_task(
        self,
        *,
        project_id: str | None,
        enqueue_run_id: str,
        idea_id: str,
        title: str,
        idea_payload_path: str,
        candidate_planes: list[str] | None = None,
    ) -> str:
        idea_queue_id = str(uuid.uuid4())
        now = int(time.time())
        with self._connect() as conn:
            repo_row = conn.execute("SELECT repo_root FROM runs WHERE run_id=?", (enqueue_run_id,)).fetchone()
            repo_root = None if repo_row is None or not repo_row["repo_root"] else Path(str(repo_row["repo_root"]))
            resolved_project_id = self._resolve_project_id_for_queue_insert(conn, project_id=project_id, repo_root=repo_root)
            conn.execute(
                "INSERT INTO idea_queue(idea_queue_id, project_id, enqueue_run_id, idea_id, title, idea_payload_path, candidate_planes_json, status, created_at, updated_at) VALUES(?,?,?,?,?,?,?,?,?,?)",
                (idea_queue_id, resolved_project_id, enqueue_run_id, idea_id, title, idea_payload_path, json.dumps(candidate_planes or [], sort_keys=True), "queued", now, now),
            )
        return idea_queue_id

    def enqueue_story_task(
        self,
        *,
        project_id: str | None,
        enqueue_run_id: str,
        story_artifact_id: str,
        story_id: str,
        title: str,
    ) -> str:
        story_queue_id = str(uuid.uuid4())
        now = int(time.time())
        with self._connect() as conn:
            repo_row = conn.execute("SELECT repo_root FROM runs WHERE run_id=?", (enqueue_run_id,)).fetchone()
            repo_root = None if repo_row is None or not repo_row["repo_root"] else Path(str(repo_row["repo_root"]))
            resolved_project_id = self._resolve_project_id_for_queue_insert(conn, project_id=project_id, repo_root=repo_root)
            existing_row = conn.execute(
                (
                    "SELECT story_queue_id FROM story_queue "
                    "WHERE project_id=? AND story_id=? AND status IN ('queued','claimed','in_progress','blocked') "
                    "ORDER BY created_at ASC LIMIT 1"
                ),
                (resolved_project_id, story_id),
            ).fetchone()
            if existing_row is not None:
                return str(existing_row["story_queue_id"])
            conn.execute(
                (
                    "INSERT INTO story_queue("
                    "story_queue_id, project_id, enqueue_run_id, story_artifact_id, story_id, title, status, created_at, updated_at"
                    ") VALUES(?,?,?,?,?,?,?,?,?)"
                ),
                (
                    story_queue_id,
                    resolved_project_id,
                    enqueue_run_id,
                    story_artifact_id,
                    story_id,
                    title,
                    "queued",
                    now,
                    now,
                ),
            )
        return story_queue_id

    def enqueue_source_doc_mutation_task(
        self,
        *,
        project_id: str | None,
        enqueue_run_id: str,
        idea_id: str | None,
        title: str,
        mutation_request: dict[str, Any],
    ) -> str:
        source_doc_mutation_queue_id = str(uuid.uuid4())
        now = int(time.time())
        with self._connect() as conn:
            repo_row = conn.execute("SELECT repo_root FROM runs WHERE run_id=?", (enqueue_run_id,)).fetchone()
            repo_root = None if repo_row is None or not repo_row["repo_root"] else Path(str(repo_row["repo_root"]))
            resolved_project_id = self._resolve_project_id_for_queue_insert(conn, project_id=project_id, repo_root=repo_root)
            conn.execute(
                (
                    "INSERT INTO source_doc_mutation_queue("
                    "source_doc_mutation_queue_id, project_id, enqueue_run_id, idea_id, title, mutation_request_json, status, created_at, updated_at"
                    ") VALUES(?,?,?,?,?,?,?,?,?)"
                ),
                (
                    source_doc_mutation_queue_id,
                    resolved_project_id,
                    enqueue_run_id,
                    idea_id,
                    title,
                    json.dumps(mutation_request, sort_keys=True),
                    "queued",
                    now,
                    now,
                ),
            )
        return source_doc_mutation_queue_id

    def enqueue_recovery_task(
        self,
        *,
        project_id: str | None,
        enqueue_run_id: str,
        source_queue_type: str,
        source_item_id: str,
        title: str,
        recovery_request_path: str,
        failure_context: dict[str, Any] | None = None,
    ) -> str:
        recovery_queue_id = str(uuid.uuid4())
        now = int(time.time())
        with self._connect() as conn:
            repo_row = conn.execute("SELECT repo_root FROM runs WHERE run_id=?", (enqueue_run_id,)).fetchone()
            repo_root = None if repo_row is None or not repo_row["repo_root"] else Path(str(repo_row["repo_root"]))
            resolved_project_id = self._resolve_project_id_for_queue_insert(conn, project_id=project_id, repo_root=repo_root)
            conn.execute(
                (
                    "INSERT INTO recovery_queue("
                    "recovery_queue_id, project_id, enqueue_run_id, source_queue_type, source_item_id, title, recovery_request_path, failure_context_json, status, created_at, updated_at"
                    ") VALUES(?,?,?,?,?,?,?,?,?,?,?)"
                ),
                (
                    recovery_queue_id,
                    resolved_project_id,
                    enqueue_run_id,
                    source_queue_type,
                    source_item_id,
                    title,
                    recovery_request_path,
                    json.dumps(failure_context, sort_keys=True) if failure_context is not None else None,
                    "queued",
                    now,
                    now,
                ),
            )
        return recovery_queue_id

    def enqueue_integration_task(
        self,
        *,
        project_id: str | None,
        enqueue_run_id: str,
        idea_id: str,
        title: str,
        integration_payload_path: str,
    ) -> str:
        integration_queue_id = str(uuid.uuid4())
        now = int(time.time())
        with self._connect() as conn:
            repo_row = conn.execute("SELECT repo_root FROM runs WHERE run_id=?", (enqueue_run_id,)).fetchone()
            repo_root = None if repo_row is None or not repo_row["repo_root"] else Path(str(repo_row["repo_root"]))
            resolved_project_id = self._resolve_project_id_for_queue_insert(conn, project_id=project_id, repo_root=repo_root)
            self._insert_integration_queue_row(
                conn,
                integration_queue_id=integration_queue_id,
                project_id=resolved_project_id,
                enqueue_run_id=enqueue_run_id,
                idea_id=idea_id,
                title=title,
                integration_payload_path=integration_payload_path,
                now=now,
                repo_root=repo_root,
            )
        return integration_queue_id

    def _insert_integration_queue_row(
        self,
        conn: sqlite3.Connection,
        *,
        integration_queue_id: str,
        project_id: str,
        enqueue_run_id: str,
        idea_id: str,
        title: str,
        integration_payload_path: str,
        now: int,
        repo_root: Path | None,
    ) -> None:
        conn.execute(
            (
                "INSERT INTO integration_queue("
                "integration_queue_id, project_id, enqueue_run_id, idea_id, title, integration_payload_path, status, created_at, updated_at"
                ") VALUES(?,?,?,?,?,?,?,?,?)"
            ),
            (
                integration_queue_id,
                project_id,
                enqueue_run_id,
                idea_id,
                title,
                integration_payload_path,
                "queued",
                now,
                now,
            ),
        )
        self._project_queued_integration_to_supabase(
            project_id=project_id,
            enqueue_run_id=enqueue_run_id,
            idea_id=idea_id,
            repo_root=repo_root,
        )

    def _project_queued_integration_to_supabase(
        self,
        *,
        project_id: str,
        enqueue_run_id: str,
        idea_id: str,
        repo_root: Path | None,
    ) -> None:
        try:
            from ..integration.supabase_sync import upsert_idea_integration_row

            upsert_idea_integration_row(
                idea_id=idea_id,
                project_id=project_id,
                run_id=enqueue_run_id,
                repo_root=repo_root,
                row={"status": "queued"},
                log_prefix="integration-queue-supabase-sync",
            )
        except Exception:
            pass

    def get_integration_queue_item(self, *, integration_queue_id: str) -> dict[str, Any] | None:
        with self._connect() as conn:
            row = conn.execute(
                (
                    "SELECT integration_queue_id, project_id, enqueue_run_id, idea_id, title, integration_payload_path, status, "
                    "claimed_by_worker_id, claimed_at, started_run_id, finished_run_id, failure_message, failure_context_json, created_at, updated_at "
                    "FROM integration_queue WHERE integration_queue_id=?"
                ),
                (integration_queue_id,),
            ).fetchone()
        if row is None:
            return None
        payload = dict(row)
        try:
            payload["failure_context"] = json.loads(str(payload.get("failure_context_json") or "")) if payload.get("failure_context_json") else None
        except Exception:
            payload["failure_context"] = None
        return payload

    def list_failed_integration_queue_items(self, *, project_id: str, limit: int = 20) -> list[dict[str, Any]]:
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT * FROM integration_queue WHERE project_id=? AND status='failed' ORDER BY updated_at DESC LIMIT ?",
                (project_id, limit),
            ).fetchall()
        items: list[dict[str, Any]] = []
        for row in rows:
            payload = dict(row)
            try:
                payload["failure_context"] = json.loads(str(payload.get("failure_context_json") or "")) if payload.get("failure_context_json") else None
            except Exception:
                payload["failure_context"] = None
            items.append(payload)
        return items

    def retry_integration_queue_item(
        self,
        *,
        project_id: str,
        integration_queue_id: str,
        preserve_failure_context: bool = True,
    ) -> dict[str, Any]:
        now = int(time.time())
        with self._connect() as conn:
            row = conn.execute(
                "SELECT * FROM integration_queue WHERE project_id=? AND integration_queue_id=? LIMIT 1",
                (project_id, integration_queue_id),
            ).fetchone()
            if row is None:
                raise ValueError(f"integration_queue_id not found for project_id={project_id}: {integration_queue_id}")
            project_row = conn.execute(
                "SELECT repo_root FROM projects WHERE project_id=? LIMIT 1",
                (project_id,),
            ).fetchone()
            repo_root_str = "" if project_row is None else str(project_row["repo_root"] or "")
            idea_id = str(row["idea_id"] or "")
            conn.execute(
                (
                    "UPDATE integration_queue SET status='queued', claimed_by_worker_id=NULL, claimed_at=NULL, started_run_id=NULL, finished_run_id=NULL, "
                    "updated_at=?, failure_message=NULL, failure_context_json=? WHERE integration_queue_id=? AND project_id=?"
                ),
                (now, row["failure_context_json"] if preserve_failure_context else None, integration_queue_id, project_id),
            )
        if repo_root_str and idea_id:
            current_dir = Path(repo_root_str) / ".devflow" / "ideas" / idea_id / "integration" / "current"
            if current_dir.exists():
                for path in current_dir.iterdir():
                    if path.is_file():
                        path.unlink()
        item = self.get_integration_queue_item(integration_queue_id=integration_queue_id)
        if item is None:
            raise ValueError(f"integration_queue_id vanished after retry reset: {integration_queue_id}")
        return item

    def start_project_worker(self, *, project_id: str, repo_root: Path) -> str:
        worker_id = str(uuid.uuid4())
        now = int(time.time())
        with self._connect() as conn:
            self._ensure_project_row(conn, project_id=project_id, repo_root=repo_root)
            existing = conn.execute(
                (
                    "SELECT worker_id FROM project_workers "
                    "WHERE project_id=? AND status IN ('starting','running','idle','stopping') "
                    "ORDER BY updated_at DESC LIMIT 1"
                ),
                (project_id,),
            ).fetchone()
            if existing is not None:
                raise RuntimeError(f"worker already active for project_id={project_id}")
            conn.execute(
                (
                    "INSERT INTO project_workers("
                    "worker_id, project_id, repo_root, status, started_at, updated_at"
                    ") VALUES(?,?,?,?,?,?)"
                ),
                (
                    worker_id,
                    project_id,
                    str(repo_root),
                    "idle",
                    now,
                    now,
                ),
            )
        return worker_id

    def stop_project_worker(self, *, project_id: str) -> dict[str, Any]:
        now = int(time.time())
        with self._connect() as conn:
            row = conn.execute(
                (
                    "SELECT worker_id FROM project_workers WHERE project_id=? "
                    "ORDER BY CASE WHEN status IN ('starting','running','idle','stopping') THEN 0 ELSE 1 END ASC, "
                    "updated_at DESC, started_at DESC, rowid DESC LIMIT 1"
                ),
                (project_id,),
            ).fetchone()
            if row is None:
                return {"project_id": project_id, "status": "stopped"}
            conn.execute(
                (
                    "UPDATE project_workers SET status='stopped', active_queue_type=NULL, active_item_id=NULL, "
                    "current_run_id=NULL, current_node_exec_id=NULL, stop_requested_at=?, stopped_at=?, updated_at=? "
                    "WHERE worker_id=?"
                ),
                (now, now, now, row["worker_id"]),
            )
        return self.get_project_worker_report(project_id=project_id)

    def claim_next_project_queue_item(
        self, *,
        project_id: str,
        worker_id: str,
        role: str | None = None,
    ) -> dict[str, Any] | None:
        now = int(time.time())
        with self._connect() as conn:
            worker = conn.execute(
                (
                    "SELECT worker_id FROM project_workers "
                    "WHERE worker_id=? AND project_id=? AND status IN ('starting','running','idle','stopping')"
                ),
                (worker_id, project_id),
            ).fetchone()
            if worker is None:
                raise RuntimeError(f"worker not active for project_id={project_id}")

            # Role-aware claim:
            # - role='analyst' → only claim 'open' user_report rows
            #   (pure observability work; fix runs in a separate
            #   worker subprocess so analysts and fixers can run
            #   concurrently).
            # - role='fix' → only claim 'observed' user_report rows
            #   where gates passed (observability_json populated,
            #   ready for FirstPassFix).
            # - role=None (default / 'both') → legacy behavior:
            #   claim either, run the full DAG end-to-end in one
            #   subprocess.
            if role == "analyst":
                error_query = (
                    "SELECT error_task_id, run_id FROM error_tasks "
                    "WHERE project_id=? AND status IN ('open','triaged') "
                    "AND source_kind='user_report' "
                    "ORDER BY created_at ASC LIMIT 1"
                )
            elif role == "fix":
                error_query = (
                    "SELECT error_task_id, run_id FROM error_tasks "
                    "WHERE project_id=? AND status='observed' "
                    "AND source_kind='user_report' "
                    "AND observability_json IS NOT NULL "
                    "ORDER BY created_at ASC LIMIT 1"
                )
            else:
                error_query = (
                    "SELECT error_task_id, run_id FROM error_tasks "
                    "WHERE project_id=? AND status IN ('open','triaged') "
                    "ORDER BY created_at ASC LIMIT 1"
                )
            error_row = conn.execute(error_query, (project_id,)).fetchone()
            if error_row is not None:
                conn.execute(
                    "UPDATE error_tasks SET status='in_progress', updated_at=? WHERE error_task_id=?",
                    (now, error_row["error_task_id"]),
                )
                conn.execute(
                    (
                        "UPDATE project_workers SET status='running', active_queue_type='error', active_item_id=?, "
                        "current_run_id=?, current_node_exec_id=NULL, updated_at=? WHERE worker_id=?"
                    ),
                    (error_row["error_task_id"], error_row["run_id"], now, worker_id),
                )
                return {
                    "queue_type": "error",
                    "item_id": error_row["error_task_id"],
                    "run_id": error_row["run_id"],
                    "current_node_exec_id": None,
                }

            failed_recovery_row = conn.execute(
                "SELECT recovery_queue_id, enqueue_run_id FROM recovery_queue WHERE project_id=? AND status='failed' ORDER BY updated_at DESC LIMIT 1",
                (project_id,),
            ).fetchone()
            if failed_recovery_row is not None:
                conn.execute(
                    (
                        "UPDATE project_workers SET status='idle', active_queue_type='recovery', active_item_id=?, "
                        "current_run_id=?, current_node_exec_id=NULL, updated_at=? WHERE worker_id=?"
                    ),
                    (failed_recovery_row["recovery_queue_id"], failed_recovery_row["enqueue_run_id"], now, worker_id),
                )
                return None

            failed_story_row = conn.execute(
                "SELECT story_queue_id, enqueue_run_id FROM story_queue WHERE project_id=? AND status='failed' ORDER BY updated_at DESC LIMIT 1",
                (project_id,),
            ).fetchone()
            if failed_story_row is not None:
                unresolved_recovery_for_story = self._select_active_recovery_queue_row(
                    conn,
                    project_id=project_id,
                    statuses=("queued", "claimed", "in_progress", "blocked"),
                    source_queue_type="story",
                    source_item_id=str(failed_story_row["story_queue_id"]),
                    columns="rq.recovery_queue_id",
                )
                if unresolved_recovery_for_story is None:
                    completed_recovery_for_story = conn.execute(
                        "SELECT recovery_queue_id FROM recovery_queue WHERE project_id=? AND source_queue_type='story' AND source_item_id=? AND status='completed' LIMIT 1",
                        (project_id, failed_story_row["story_queue_id"]),
                    ).fetchone()
                    if completed_recovery_for_story is not None:
                        self._requeue_failed_recovery_source(
                            conn,
                            source_queue_type="story",
                            source_item_id=str(failed_story_row["story_queue_id"]),
                            updated_at=now,
                        )
                    else:
                        conn.execute(
                            (
                                "UPDATE project_workers SET status='idle', active_queue_type='recovery', active_item_id=?, "
                                "current_run_id=?, current_node_exec_id=NULL, updated_at=? WHERE worker_id=?"
                            ),
                            (failed_story_row["story_queue_id"], failed_story_row["enqueue_run_id"], now, worker_id),
                        )
                        return None

            recovery_row = self._select_active_recovery_queue_row(
                conn,
                project_id=project_id,
                statuses=("queued",),
                columns="rq.recovery_queue_id, rq.enqueue_run_id",
            )
            if recovery_row is not None:
                conn.execute("UPDATE recovery_queue SET status='claimed', claimed_by_worker_id=?, claimed_at=?, updated_at=? WHERE recovery_queue_id=?", (worker_id, now, now, recovery_row["recovery_queue_id"]))
                conn.execute(
                    "UPDATE project_workers SET status='running', active_queue_type='recovery', active_item_id=?, current_run_id=?, current_node_exec_id=NULL, updated_at=? WHERE worker_id=?",
                    (recovery_row["recovery_queue_id"], recovery_row["enqueue_run_id"], now, worker_id),
                )
                return {"queue_type": "recovery", "item_id": recovery_row["recovery_queue_id"], "run_id": recovery_row["enqueue_run_id"], "current_node_exec_id": None}

            unresolved_recovery_row = self._select_active_recovery_queue_row(
                conn,
                project_id=project_id,
                statuses=("claimed", "in_progress", "blocked"),
                columns="rq.recovery_queue_id, rq.enqueue_run_id, rq.status",
            )
            if unresolved_recovery_row is not None:
                reconciled = self.reconcile_recovery_queue_item(recovery_queue_id=str(unresolved_recovery_row["recovery_queue_id"]))
                if reconciled is not None and str(reconciled.get("status") or "") in {"completed", "failed"}:
                    unresolved_recovery_row = None
                else:
                    conn.execute(
                        (
                            "UPDATE project_workers SET status='idle', active_queue_type='recovery', active_item_id=?, "
                            "current_run_id=?, current_node_exec_id=NULL, updated_at=? WHERE worker_id=?"
                        ),
                        (unresolved_recovery_row["recovery_queue_id"], unresolved_recovery_row["enqueue_run_id"], now, worker_id),
                    )
                    return None

            scope_row = conn.execute(
                "SELECT scope_queue_id, enqueue_run_id FROM scope_queue WHERE project_id=? AND status='queued' ORDER BY created_at ASC LIMIT 1",
                (project_id,),
            ).fetchone()
            if scope_row is not None:
                conn.execute("UPDATE scope_queue SET status='claimed', claimed_by_worker_id=?, claimed_at=?, updated_at=? WHERE scope_queue_id=?", (worker_id, now, now, scope_row["scope_queue_id"]))
                conn.execute(
                    "UPDATE project_workers SET status='running', active_queue_type='scope', active_item_id=?, current_run_id=?, current_node_exec_id=NULL, updated_at=? WHERE worker_id=?",
                    (scope_row["scope_queue_id"], scope_row["enqueue_run_id"], now, worker_id),
                )
                return {"queue_type": "scope", "item_id": scope_row["scope_queue_id"], "run_id": scope_row["enqueue_run_id"], "current_node_exec_id": None}

            idea_creation_row = conn.execute(
                "SELECT idea_creation_queue_id, enqueue_run_id FROM idea_creation_queue WHERE project_id=? AND status='queued' ORDER BY created_at ASC LIMIT 1",
                (project_id,),
            ).fetchone()
            if idea_creation_row is not None:
                conn.execute("UPDATE idea_creation_queue SET status='claimed', claimed_by_worker_id=?, claimed_at=?, updated_at=? WHERE idea_creation_queue_id=?", (worker_id, now, now, idea_creation_row["idea_creation_queue_id"]))
                conn.execute(
                    "UPDATE project_workers SET status='running', active_queue_type='idea_creation', active_item_id=?, current_run_id=?, current_node_exec_id=NULL, updated_at=? WHERE worker_id=?",
                    (idea_creation_row["idea_creation_queue_id"], idea_creation_row["enqueue_run_id"], now, worker_id),
                )
                return {"queue_type": "idea_creation", "item_id": idea_creation_row["idea_creation_queue_id"], "run_id": idea_creation_row["enqueue_run_id"], "current_node_exec_id": None}

            idea_row = conn.execute(
                "SELECT idea_queue_id, enqueue_run_id FROM idea_queue WHERE project_id=? AND status='queued' ORDER BY created_at ASC LIMIT 1",
                (project_id,),
            ).fetchone()
            if idea_row is not None:
                conn.execute("UPDATE idea_queue SET status='claimed', claimed_by_worker_id=?, claimed_at=?, updated_at=? WHERE idea_queue_id=?", (worker_id, now, now, idea_row["idea_queue_id"]))
                conn.execute(
                    "UPDATE project_workers SET status='running', active_queue_type='idea', active_item_id=?, current_run_id=?, current_node_exec_id=NULL, updated_at=? WHERE worker_id=?",
                    (idea_row["idea_queue_id"], idea_row["enqueue_run_id"], now, worker_id),
                )
                return {"queue_type": "idea", "item_id": idea_row["idea_queue_id"], "run_id": idea_row["enqueue_run_id"], "current_node_exec_id": None}

            source_doc_mutation_row = conn.execute(
                "SELECT source_doc_mutation_queue_id, enqueue_run_id FROM source_doc_mutation_queue WHERE project_id=? AND status='queued' ORDER BY created_at ASC LIMIT 1",
                (project_id,),
            ).fetchone()
            if source_doc_mutation_row is not None:
                conn.execute(
                    "UPDATE source_doc_mutation_queue SET status='claimed', claimed_by_worker_id=?, claimed_at=?, updated_at=? WHERE source_doc_mutation_queue_id=?",
                    (worker_id, now, now, source_doc_mutation_row["source_doc_mutation_queue_id"]),
                )
                conn.execute(
                    "UPDATE project_workers SET status='running', active_queue_type='source_doc_mutation', active_item_id=?, current_run_id=?, current_node_exec_id=NULL, updated_at=? WHERE worker_id=?",
                    (source_doc_mutation_row["source_doc_mutation_queue_id"], source_doc_mutation_row["enqueue_run_id"], now, worker_id),
                )
                return {"queue_type": "source_doc_mutation", "item_id": source_doc_mutation_row["source_doc_mutation_queue_id"], "run_id": source_doc_mutation_row["enqueue_run_id"], "current_node_exec_id": None}

            story_row = conn.execute(
                (
                    "SELECT story_queue_id, enqueue_run_id FROM story_queue sq "
                    "WHERE sq.project_id=? AND sq.status='queued' "
                    "AND NOT EXISTS ("
                    "SELECT 1 FROM story_queue completed "
                    "WHERE completed.project_id=sq.project_id AND completed.story_id=sq.story_id AND completed.status='completed'"
                    ") "
                    "ORDER BY sq.created_at ASC LIMIT 1"
                ),
                (project_id,),
            ).fetchone()
            if story_row is not None:
                conn.execute(
                    (
                        "UPDATE story_queue SET status='claimed', claimed_by_worker_id=?, claimed_at=?, updated_at=? "
                        "WHERE story_queue_id=?"
                    ),
                    (worker_id, now, now, story_row["story_queue_id"]),
                )
                conn.execute(
                    (
                        "UPDATE project_workers SET status='running', active_queue_type='story', active_item_id=?, "
                        "current_run_id=?, current_node_exec_id=NULL, updated_at=? WHERE worker_id=?"
                    ),
                    (story_row["story_queue_id"], story_row["enqueue_run_id"], now, worker_id),
                )
                return {
                    "queue_type": "story",
                    "item_id": story_row["story_queue_id"],
                    "run_id": story_row["enqueue_run_id"],
                    "current_node_exec_id": None,
                }

            integration_row = conn.execute(
                "SELECT integration_queue_id, enqueue_run_id FROM integration_queue WHERE project_id=? AND status='queued' ORDER BY created_at ASC LIMIT 1",
                (project_id,),
            ).fetchone()
            if integration_row is not None:
                conn.execute(
                    "UPDATE integration_queue SET status='claimed', claimed_by_worker_id=?, claimed_at=?, updated_at=? WHERE integration_queue_id=?",
                    (worker_id, now, now, integration_row["integration_queue_id"]),
                )
                conn.execute(
                    "UPDATE project_workers SET status='running', active_queue_type='integration', active_item_id=?, current_run_id=?, current_node_exec_id=NULL, updated_at=? WHERE worker_id=?",
                    (integration_row["integration_queue_id"], integration_row["enqueue_run_id"], now, worker_id),
                )
                return {
                    "queue_type": "integration",
                    "item_id": integration_row["integration_queue_id"],
                    "run_id": integration_row["enqueue_run_id"],
                    "current_node_exec_id": None,
                }

            conn.execute(
                (
                    "UPDATE project_workers SET status='idle', active_queue_type=NULL, active_item_id=NULL, "
                    "current_run_id=NULL, current_node_exec_id=NULL, updated_at=? WHERE worker_id=?"
                ),
                (now, worker_id),
            )
            return None

    def update_project_worker_context(
        self,
        *,
        worker_id: str,
        current_run_id: str | None = None,
        current_node_exec_id: str | None = None,
    ) -> None:
        now = int(time.time())
        with self._connect() as conn:
            conn.execute(
                (
                    "UPDATE project_workers SET current_run_id=?, current_node_exec_id=?, updated_at=? WHERE worker_id=?"
                ),
                (current_run_id, current_node_exec_id, now, worker_id),
            )

    @staticmethod
    def _select_active_recovery_queue_row(
        conn: sqlite3.Connection,
        *,
        project_id: str,
        statuses: tuple[str, ...],
        columns: str,
        source_queue_type: str | None = None,
        source_item_id: str | None = None,
    ) -> sqlite3.Row | None:
        placeholders = ",".join("?" for _ in statuses)
        sql = [
            f"SELECT {columns} FROM recovery_queue rq",
            "WHERE rq.project_id=?",
            f"AND rq.status IN ({placeholders})",
            (
                "AND NOT EXISTS ("
                "SELECT 1 FROM recovery_queue newer "
                "WHERE newer.project_id=rq.project_id "
                "AND newer.source_queue_type=rq.source_queue_type "
                "AND newer.source_item_id=rq.source_item_id "
                "AND newer.status='completed' "
                "AND newer.rowid > rq.rowid"
                ")"
            ),
        ]
        params: list[Any] = [project_id, *statuses]
        if source_queue_type is not None:
            sql.append("AND rq.source_queue_type=?")
            params.append(source_queue_type)
        if source_item_id is not None:
            sql.append("AND rq.source_item_id=?")
            params.append(source_item_id)
        sql.append("ORDER BY rq.created_at ASC, rq.rowid ASC LIMIT 1")
        return conn.execute(" ".join(sql), tuple(params)).fetchone()

    def reconcile_recovery_queue_item(self, *, recovery_queue_id: str) -> dict[str, Any] | None:
        now = int(time.time())
        with self._connect() as conn:
            row = conn.execute(
                "SELECT recovery_queue_id, project_id, source_queue_type, source_item_id, status, started_run_id, finished_run_id FROM recovery_queue WHERE recovery_queue_id=?",
                (recovery_queue_id,),
            ).fetchone()
            if row is None:
                return None
            payload = dict(row)
            run_id = str(payload.get("started_run_id") or payload.get("finished_run_id") or "") or None
            run_status = None
            if run_id:
                run_row = conn.execute("SELECT status FROM runs WHERE run_id=?", (run_id,)).fetchone()
                run_status = None if run_row is None else str(run_row["status"] or "") or None
            source_queue_type = str(payload.get("source_queue_type") or "")
            source_item_id = str(payload.get("source_item_id") or "")
            if run_status == "succeeded":
                conn.execute(
                    "UPDATE recovery_queue SET status='completed', finished_run_id=COALESCE(finished_run_id, ?), updated_at=? WHERE recovery_queue_id=?",
                    (run_id, now, recovery_queue_id),
                )
                self._normalize_stale_blocked_recovery_rows(
                    conn,
                    project_id=str(payload.get("project_id") or ""),
                    source_queue_type=source_queue_type,
                    source_item_id=source_item_id,
                    completed_recovery_queue_id=recovery_queue_id,
                    finished_run_id=run_id,
                    updated_at=now,
                )
                self._requeue_failed_recovery_source(
                    conn,
                    source_queue_type=source_queue_type,
                    source_item_id=source_item_id,
                    updated_at=now,
                )
                payload["status"] = "completed"
                return payload
            if run_status == "failed":
                conn.execute(
                    "UPDATE recovery_queue SET status='failed', finished_run_id=COALESCE(finished_run_id, ?), updated_at=? WHERE recovery_queue_id=?",
                    (run_id, now, recovery_queue_id),
                )
                payload["status"] = "failed"
                return payload
            return payload

    @staticmethod
    def _requeue_failed_recovery_source(
        conn: sqlite3.Connection,
        *,
        source_queue_type: str,
        source_item_id: str,
        updated_at: int,
    ) -> None:
        if source_queue_type == "story":
            conn.execute(
                "UPDATE story_queue SET status='queued', claimed_by_worker_id=NULL, claimed_at=NULL, updated_at=? WHERE story_queue_id=? AND status='failed'",
                (updated_at, source_item_id),
            )
        elif source_queue_type == "idea_creation":
            conn.execute(
                "UPDATE idea_creation_queue SET status='queued', claimed_by_worker_id=NULL, claimed_at=NULL, updated_at=? WHERE idea_creation_queue_id=? AND status='failed'",
                (updated_at, source_item_id),
            )
        elif source_queue_type == "idea":
            conn.execute(
                "UPDATE idea_queue SET status='queued', claimed_by_worker_id=NULL, claimed_at=NULL, updated_at=? WHERE idea_queue_id=? AND status='failed'",
                (updated_at, source_item_id),
            )
        elif source_queue_type == "scope":
            conn.execute(
                "UPDATE scope_queue SET status='queued', claimed_by_worker_id=NULL, claimed_at=NULL, updated_at=? WHERE scope_queue_id=? AND status='failed'",
                (updated_at, source_item_id),
            )

    @staticmethod
    def _normalize_stale_blocked_recovery_rows(
        conn: sqlite3.Connection,
        *,
        project_id: str,
        source_queue_type: str,
        source_item_id: str,
        completed_recovery_queue_id: str,
        finished_run_id: str | None,
        updated_at: int,
    ) -> None:
        completed_row = conn.execute(
            "SELECT rowid FROM recovery_queue WHERE recovery_queue_id=?",
            (completed_recovery_queue_id,),
        ).fetchone()
        if completed_row is None:
            return
        conn.execute(
            (
                "UPDATE recovery_queue "
                "SET status='completed', finished_run_id=COALESCE(finished_run_id, ?), updated_at=? "
                "WHERE project_id=? AND source_queue_type=? AND source_item_id=? "
                "AND status='blocked' AND rowid < ?"
            ),
            (finished_run_id, updated_at, project_id, source_queue_type, source_item_id, int(completed_row["rowid"])),
        )

    def complete_project_queue_item(
        self,
        *,
        project_id: str,
        worker_id: str,
        queue_type: str,
        item_id: str,
        status: str,
        current_run_id: str | None = None,
        current_node_exec_id: str | None = None,
        failure_message: str | None = None,
        failure_context: dict[str, Any] | None = None,
    ) -> None:
        now = int(time.time())
        with self._connect() as conn:
            if queue_type == "error":
                conn.execute(
                    "UPDATE error_tasks SET status=?, updated_at=? WHERE error_task_id=?",
                    (status, now, item_id),
                )
            elif queue_type == "recovery":
                conn.execute(
                    "UPDATE recovery_queue SET status=?, finished_run_id=COALESCE(?, finished_run_id), failure_message=COALESCE(?, failure_message), failure_context_json=COALESCE(?, failure_context_json), updated_at=? WHERE recovery_queue_id=?",
                    (status, current_run_id, failure_message, json.dumps(failure_context, sort_keys=True) if failure_context is not None else None, now, item_id),
                )
                if status == "completed":
                    recovery_row = conn.execute(
                        "SELECT source_queue_type, source_item_id FROM recovery_queue WHERE recovery_queue_id=?",
                        (item_id,),
                    ).fetchone()
                    if recovery_row is not None:
                        self._normalize_stale_blocked_recovery_rows(
                            conn,
                            project_id=project_id,
                            source_queue_type=str(recovery_row["source_queue_type"] or ""),
                            source_item_id=str(recovery_row["source_item_id"] or ""),
                            completed_recovery_queue_id=item_id,
                            finished_run_id=current_run_id,
                            updated_at=now,
                        )
                        self._requeue_failed_recovery_source(
                            conn,
                            source_queue_type=str(recovery_row["source_queue_type"] or ""),
                            source_item_id=str(recovery_row["source_item_id"] or ""),
                            updated_at=now,
                        )
            elif queue_type == "scope":
                conn.execute(
                    "UPDATE scope_queue SET status=?, finished_run_id=COALESCE(?, finished_run_id), failure_message=COALESCE(?, failure_message), failure_context_json=COALESCE(?, failure_context_json), updated_at=? WHERE scope_queue_id=?",
                    (status, current_run_id, failure_message, json.dumps(failure_context, sort_keys=True) if failure_context is not None else None, now, item_id),
                )
            elif queue_type == "idea_creation":
                conn.execute(
                    "UPDATE idea_creation_queue SET status=?, finished_run_id=COALESCE(?, finished_run_id), failure_message=COALESCE(?, failure_message), failure_context_json=COALESCE(?, failure_context_json), updated_at=? WHERE idea_creation_queue_id=?",
                    (status, current_run_id, failure_message, json.dumps(failure_context, sort_keys=True) if failure_context is not None else None, now, item_id),
                )
            elif queue_type == "idea":
                conn.execute(
                    "UPDATE idea_queue SET status=?, finished_run_id=COALESCE(?, finished_run_id), failure_message=COALESCE(?, failure_message), failure_context_json=COALESCE(?, failure_context_json), updated_at=? WHERE idea_queue_id=?",
                    (status, current_run_id, failure_message, json.dumps(failure_context, sort_keys=True) if failure_context is not None else None, now, item_id),
                )
            elif queue_type == "story":
                conn.execute(
                    (
                        "UPDATE story_queue SET status=?, finished_run_id=COALESCE(?, finished_run_id), "
                        "failure_message=COALESCE(?, failure_message), failure_context_json=COALESCE(?, failure_context_json), updated_at=? WHERE story_queue_id=?"
                    ),
                    (status, current_run_id, failure_message, json.dumps(failure_context, sort_keys=True) if failure_context is not None else None, now, item_id),
                )
                # Task 3: auto-enqueue to integration_queue when all stories for an idea complete.
                if status == "completed":
                    try:
                        # Step 1: Get idea_id from story_queue -> artifacts -> metadata_json.
                        story_row = conn.execute(
                            "SELECT story_artifact_id, enqueue_run_id, story_id FROM story_queue WHERE story_queue_id=?",
                            (item_id,),
                        ).fetchone()
                        if story_row is not None:
                            artifact_row = conn.execute(
                                "SELECT metadata_json FROM artifacts WHERE artifact_id=?",
                                (story_row["story_artifact_id"],),
                            ).fetchone()
                            idea_id: str | None = None
                            if artifact_row is not None and artifact_row["metadata_json"]:
                                try:
                                    meta = json.loads(str(artifact_row["metadata_json"]))
                                    idea_id = str(meta.get("idea_id") or "") or None
                                except Exception:
                                    idea_id = None
                            # Fallback: extract idea_id from legacy story_id pattern STORY:idea:<idea_id>:...
                            if not idea_id and story_row["story_id"]:
                                import re as _re
                                _m = _re.match(r'^STORY:idea:(idea_[a-f0-9]+):', str(story_row["story_id"] or ""))
                                if _m:
                                    idea_id = _m.group(1)
                            if idea_id:
                                # Step 2: Resolve repo_root, preferring runs.repo_root and
                                # falling back to projects.repo_root for the same project.
                                run_row = conn.execute(
                                    "SELECT repo_root FROM runs WHERE run_id=?",
                                    (story_row["enqueue_run_id"],),
                                ).fetchone()
                                repo_root_str: str | None = None
                                if run_row is not None and run_row["repo_root"]:
                                    repo_root_str = str(run_row["repo_root"])
                                if not repo_root_str:
                                    project_row = conn.execute(
                                        "SELECT repo_root FROM projects WHERE project_id=?",
                                        (project_id,),
                                    ).fetchone()
                                    if project_row is not None and project_row["repo_root"]:
                                        repo_root_str = str(project_row["repo_root"])
                                # Step 3: Count non-terminal story_queue items for the same idea_id.
                                remaining_row = conn.execute(
                                    """
                                    SELECT COUNT(*) as cnt
                                    FROM story_queue sq
                                    JOIN artifacts a ON a.artifact_id = sq.story_artifact_id
                                    WHERE sq.project_id=?
                                      AND sq.status NOT IN ('completed','failed','cancelled')
                                      AND (json_extract(a.metadata_json, '$.idea_id') = ? OR sq.story_id LIKE 'STORY:idea:' || ? || ':%')
                                    """,
                                    (project_id, idea_id, idea_id),
                                ).fetchone()
                                remaining_count = int(remaining_row["cnt"] if remaining_row else 0)
                                # Step 4: Count failed story_queue items for the same idea_id.
                                failed_row = conn.execute(
                                    """
                                    SELECT COUNT(*) as cnt
                                    FROM story_queue sq
                                    JOIN artifacts a ON a.artifact_id = sq.story_artifact_id
                                    WHERE sq.project_id=?
                                      AND sq.status='failed'
                                      AND (json_extract(a.metadata_json, '$.idea_id') = ? OR sq.story_id LIKE 'STORY:idea:' || ? || ':%')
                                    """,
                                    (project_id, idea_id, idea_id),
                                ).fetchone()
                                failed_count = int(failed_row["cnt"] if failed_row else 0)
                                # Step 5: If all done and no failures, auto-enqueue.
                                if remaining_count == 0 and failed_count == 0:
                                    payload_path = Path(repo_root_str) / ".devflow" / "ideas" / idea_id / "integration_payload.json" if repo_root_str else None
                                    # Always enqueue — worker will build payload inline if missing.
                                    existing_iq = conn.execute(
                                        "SELECT integration_queue_id FROM integration_queue WHERE project_id=? AND idea_id=? AND status NOT IN ('completed','failed','cancelled') LIMIT 1",
                                        (project_id, idea_id),
                                    ).fetchone()
                                    if existing_iq is None and not repo_root_str:
                                        warnings.warn(
                                            (
                                                "story completion auto-enqueue skipped: unable to resolve repo_root "
                                                f"for project_id={project_id} idea_id={idea_id}"
                                            ),
                                            RuntimeWarning,
                                            stacklevel=2,
                                        )
                                    if existing_iq is None and repo_root_str:
                                        if payload_path is None:
                                            payload_path = Path(repo_root_str) / ".devflow" / "ideas" / idea_id / "integration_payload.json"
                                        # Get title from idea.json if available.
                                        idea_json_path = Path(repo_root_str) / ".devflow" / "ideas" / idea_id / "idea.json"
                                        iq_title = idea_id
                                        if idea_json_path.exists():
                                            try:
                                                idea_data = json.loads(idea_json_path.read_text(encoding="utf-8"))
                                                iq_title = str(idea_data.get("title") or idea_data.get("name") or idea_id)
                                            except Exception:
                                                pass
                                        # Use the story's enqueue_run_id as the enqueue_run_id for the integration task.
                                        integration_queue_id = str(uuid.uuid4())
                                        self._insert_integration_queue_row(
                                            conn,
                                            integration_queue_id=integration_queue_id,
                                            project_id=project_id,
                                            enqueue_run_id=str(story_row["enqueue_run_id"]),
                                            idea_id=idea_id,
                                            title=iq_title,
                                            integration_payload_path=str(payload_path),
                                            now=now,
                                            repo_root=Path(repo_root_str),
                                        )
                    except Exception:
                        pass  # Auto-enqueue failures must never break story completion.
            elif queue_type == "source_doc_mutation":
                conn.execute(
                    (
                        "UPDATE source_doc_mutation_queue SET status=?, finished_run_id=COALESCE(?, finished_run_id), "
                        "failure_message=COALESCE(?, failure_message), failure_context_json=COALESCE(?, failure_context_json), updated_at=? WHERE source_doc_mutation_queue_id=?"
                    ),
                    (status, current_run_id, failure_message, json.dumps(failure_context, sort_keys=True) if failure_context is not None else None, now, item_id),
                )
            elif queue_type == "integration":
                conn.execute(
                    (
                        "UPDATE integration_queue SET status=?, finished_run_id=COALESCE(?, finished_run_id), "
                        "failure_message=COALESCE(?, failure_message), failure_context_json=COALESCE(?, failure_context_json), updated_at=? WHERE integration_queue_id=?"
                    ),
                    (status, current_run_id, failure_message, json.dumps(failure_context, sort_keys=True) if failure_context is not None else None, now, item_id),
                )
            else:
                raise ValueError(f"unknown queue_type={queue_type}")

            conn.execute(
                (
                    "UPDATE project_workers SET status='idle', active_queue_type=?, active_item_id=?, "
                    "current_run_id=?, current_node_exec_id=?, updated_at=? WHERE worker_id=? AND project_id=?"
                ),
                (queue_type, item_id, current_run_id, current_node_exec_id, now, worker_id, project_id),
            )

    def get_project_worker_report(self, *, project_id: str) -> dict[str, Any]:
        with self._connect() as conn:
            row = conn.execute(
                (
                    "SELECT worker_id, project_id, repo_root, status, active_queue_type, active_item_id, "
                    "current_run_id, current_node_exec_id, started_at, updated_at, stopped_at "
                    "FROM project_workers WHERE project_id=? "
                    "ORDER BY CASE WHEN status IN ('starting','running','idle','stopping') THEN 0 ELSE 1 END ASC, "
                    "updated_at DESC, started_at DESC, rowid DESC LIMIT 1"
                ),
                (project_id,),
            ).fetchone()
            if row is None:
                return {
                    "project_id": project_id,
                    "status": "stopped",
                    "active_queue_type": None,
                    "active_item_id": None,
                    "current_run_id": None,
                    "current_node_exec_id": None,
                }

            current_node_exec_id = row["current_node_exec_id"]
            current_run_id = row["current_run_id"]
            if current_node_exec_id is None and current_run_id:
                node = conn.execute(
                    (
                        "SELECT node_exec_id FROM nodes WHERE run_id=? "
                        "ORDER BY COALESCE(finished_at, started_at, created_at) DESC LIMIT 1"
                    ),
                    (current_run_id,),
                ).fetchone()
                if node is not None:
                    current_node_exec_id = node["node_exec_id"]

            return {
                "worker_id": row["worker_id"],
                "project_id": row["project_id"],
                "repo_root": row["repo_root"],
                "status": row["status"],
                "active_queue_type": row["active_queue_type"],
                "active_item_id": row["active_item_id"],
                "current_run_id": current_run_id,
                "current_node_exec_id": current_node_exec_id,
                "started_at": row["started_at"],
                "updated_at": row["updated_at"],
                "stopped_at": row["stopped_at"],
            }

    def get_scope_queue_item(self, *, scope_queue_id: str) -> dict[str, Any] | None:
        with self._connect() as conn:
            row = conn.execute("SELECT * FROM scope_queue WHERE scope_queue_id=?", (scope_queue_id,)).fetchone()
        if row is None:
            return None
        payload = dict(row)
        try:
            payload["failure_context"] = json.loads(str(payload.get("failure_context_json") or "")) if payload.get("failure_context_json") else None
        except Exception:
            payload["failure_context"] = None
        return payload

    def get_idea_creation_queue_item(self, *, idea_creation_queue_id: str) -> dict[str, Any] | None:
        with self._connect() as conn:
            row = conn.execute("SELECT * FROM idea_creation_queue WHERE idea_creation_queue_id=?", (idea_creation_queue_id,)).fetchone()
        if row is None:
            return None
        payload = dict(row)
        try:
            payload["failure_context"] = json.loads(str(payload.get("failure_context_json") or "")) if payload.get("failure_context_json") else None
        except Exception:
            payload["failure_context"] = None
        return payload

    def get_idea_queue_item(self, *, idea_queue_id: str) -> dict[str, Any] | None:
        with self._connect() as conn:
            row = conn.execute("SELECT * FROM idea_queue WHERE idea_queue_id=?", (idea_queue_id,)).fetchone()
        if row is None:
            return None
        payload = dict(row)
        try:
            payload["candidate_planes"] = json.loads(str(payload.get("candidate_planes_json") or "[]"))
        except Exception:
            payload["candidate_planes"] = []
        try:
            payload["failure_context"] = json.loads(str(payload.get("failure_context_json") or "")) if payload.get("failure_context_json") else None
        except Exception:
            payload["failure_context"] = None
        return payload

    def get_story_queue_item(self, *, story_queue_id: str) -> dict[str, Any] | None:
        with self._connect() as conn:
            row = conn.execute(
                (
                    "SELECT story_queue_id, project_id, enqueue_run_id, story_artifact_id, story_id, title, status, "
                    "claimed_by_worker_id, claimed_at, started_run_id, finished_run_id, failure_message, failure_context_json, created_at, updated_at "
                    "FROM story_queue WHERE story_queue_id=?"
                ),
                (story_queue_id,),
            ).fetchone()
        if row is None:
            return None
        payload = dict(row)
        try:
            payload["failure_context"] = json.loads(str(payload.get("failure_context_json") or "")) if payload.get("failure_context_json") else None
        except Exception:
            payload["failure_context"] = None
        return payload

    def get_recovery_queue_item(self, *, recovery_queue_id: str) -> dict[str, Any] | None:
        with self._connect() as conn:
            row = conn.execute(
                (
                    "SELECT recovery_queue_id, project_id, enqueue_run_id, source_queue_type, source_item_id, title, recovery_request_path, status, "
                    "claimed_by_worker_id, claimed_at, started_run_id, finished_run_id, failure_message, failure_context_json, created_at, updated_at "
                    "FROM recovery_queue WHERE recovery_queue_id=?"
                ),
                (recovery_queue_id,),
            ).fetchone()
        if row is None:
            return None
        payload = dict(row)
        try:
            payload["failure_context"] = json.loads(str(payload.get("failure_context_json") or "")) if payload.get("failure_context_json") else None
        except Exception:
            payload["failure_context"] = None
        return payload

    def get_source_doc_mutation_queue_item(self, *, source_doc_mutation_queue_id: str) -> dict[str, Any] | None:
        with self._connect() as conn:
            row = conn.execute(
                (
                    "SELECT source_doc_mutation_queue_id, project_id, enqueue_run_id, idea_id, title, mutation_request_json, status, "
                    "claimed_by_worker_id, claimed_at, started_run_id, finished_run_id, failure_message, failure_context_json, created_at, updated_at "
                    "FROM source_doc_mutation_queue WHERE source_doc_mutation_queue_id=?"
                ),
                (source_doc_mutation_queue_id,),
            ).fetchone()
        if row is None:
            return None
        payload = dict(row)
        try:
            payload["mutation_request"] = json.loads(str(payload.get("mutation_request_json") or "{}"))
        except Exception:
            payload["mutation_request"] = {}
        try:
            payload["failure_context"] = json.loads(str(payload.get("failure_context_json") or "")) if payload.get("failure_context_json") else None
        except Exception:
            payload["failure_context"] = None
        return payload

    def list_failed_scope_queue_items(self, *, project_id: str, limit: int = 20) -> list[dict[str, Any]]:
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT * FROM scope_queue WHERE project_id=? AND status='failed' ORDER BY updated_at DESC LIMIT ?",
                (project_id, limit),
            ).fetchall()
        items: list[dict[str, Any]] = []
        for row in rows:
            payload = dict(row)
            try:
                payload["failure_context"] = json.loads(str(payload.get("failure_context_json") or "")) if payload.get("failure_context_json") else None
            except Exception:
                payload["failure_context"] = None
            items.append(payload)
        return items

    def list_failed_idea_creation_queue_items(self, *, project_id: str, limit: int = 20) -> list[dict[str, Any]]:
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT * FROM idea_creation_queue WHERE project_id=? AND status='failed' ORDER BY updated_at DESC LIMIT ?",
                (project_id, limit),
            ).fetchall()
        items: list[dict[str, Any]] = []
        for row in rows:
            payload = dict(row)
            try:
                payload["failure_context"] = json.loads(str(payload.get("failure_context_json") or "")) if payload.get("failure_context_json") else None
            except Exception:
                payload["failure_context"] = None
            items.append(payload)
        return items

    def list_failed_idea_queue_items(self, *, project_id: str, limit: int = 20) -> list[dict[str, Any]]:
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT * FROM idea_queue WHERE project_id=? AND status='failed' ORDER BY updated_at DESC LIMIT ?",
                (project_id, limit),
            ).fetchall()
        items: list[dict[str, Any]] = []
        for row in rows:
            payload = dict(row)
            try:
                payload["candidate_planes"] = json.loads(str(payload.get("candidate_planes_json") or "[]"))
            except Exception:
                payload["candidate_planes"] = []
            try:
                payload["failure_context"] = json.loads(str(payload.get("failure_context_json") or "")) if payload.get("failure_context_json") else None
            except Exception:
                payload["failure_context"] = None
            items.append(payload)
        return items

    def retry_scope_queue_item(self, *, project_id: str, scope_queue_id: str, preserve_failure_context: bool = True) -> dict[str, Any]:
        now = int(time.time())
        with self._connect() as conn:
            row = conn.execute(
                "SELECT * FROM scope_queue WHERE project_id=? AND scope_queue_id=? LIMIT 1",
                (project_id, scope_queue_id),
            ).fetchone()
            if row is None:
                raise ValueError(f"scope_queue_id not found for project_id={project_id}: {scope_queue_id}")
            conn.execute(
                (
                    "UPDATE scope_queue SET status='queued', claimed_by_worker_id=NULL, claimed_at=NULL, started_run_id=NULL, finished_run_id=NULL, "
                    "updated_at=?, failure_message=NULL, failure_context_json=? WHERE scope_queue_id=? AND project_id=?"
                ),
                (now, row["failure_context_json"] if preserve_failure_context else None, scope_queue_id, project_id),
            )
        item = self.get_scope_queue_item(scope_queue_id=scope_queue_id)
        if item is None:
            raise ValueError(f"scope_queue_id vanished after retry reset: {scope_queue_id}")
        return item

    def retry_idea_creation_queue_item(self, *, project_id: str, idea_creation_queue_id: str, preserve_failure_context: bool = True) -> dict[str, Any]:
        now = int(time.time())
        with self._connect() as conn:
            row = conn.execute(
                "SELECT * FROM idea_creation_queue WHERE project_id=? AND idea_creation_queue_id=? LIMIT 1",
                (project_id, idea_creation_queue_id),
            ).fetchone()
            if row is None:
                raise ValueError(f"idea_creation_queue_id not found for project_id={project_id}: {idea_creation_queue_id}")
            conn.execute(
                (
                    "UPDATE idea_creation_queue SET status='queued', claimed_by_worker_id=NULL, claimed_at=NULL, started_run_id=NULL, finished_run_id=NULL, "
                    "updated_at=?, failure_message=NULL, failure_context_json=? WHERE idea_creation_queue_id=? AND project_id=?"
                ),
                (now, row["failure_context_json"] if preserve_failure_context else None, idea_creation_queue_id, project_id),
            )
        item = self.get_idea_creation_queue_item(idea_creation_queue_id=idea_creation_queue_id)
        if item is None:
            raise ValueError(f"idea_creation_queue_id vanished after retry reset: {idea_creation_queue_id}")
        return item

    def retry_idea_queue_item(self, *, project_id: str, idea_queue_id: str, preserve_failure_context: bool = True) -> dict[str, Any]:
        now = int(time.time())
        with self._connect() as conn:
            row = conn.execute(
                "SELECT * FROM idea_queue WHERE project_id=? AND idea_queue_id=? LIMIT 1",
                (project_id, idea_queue_id),
            ).fetchone()
            if row is None:
                raise ValueError(f"idea_queue_id not found for project_id={project_id}: {idea_queue_id}")
            conn.execute(
                (
                    "UPDATE idea_queue SET status='queued', claimed_by_worker_id=NULL, claimed_at=NULL, started_run_id=NULL, finished_run_id=NULL, "
                    "updated_at=?, failure_message=NULL, failure_context_json=? WHERE idea_queue_id=? AND project_id=?"
                ),
                (now, row["failure_context_json"] if preserve_failure_context else None, idea_queue_id, project_id),
            )
        item = self.get_idea_queue_item(idea_queue_id=idea_queue_id)
        if item is None:
            raise ValueError(f"idea_queue_id vanished after retry reset: {idea_queue_id}")
        return item

    def list_failed_story_queue_items(self, *, project_id: str, limit: int = 20) -> list[dict[str, Any]]:
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT * FROM story_queue WHERE project_id=? AND status='failed' ORDER BY updated_at DESC LIMIT ?",
                (project_id, limit),
            ).fetchall()
        items: list[dict[str, Any]] = []
        for row in rows:
            payload = dict(row)
            try:
                payload["failure_context"] = json.loads(str(payload.get("failure_context_json") or "")) if payload.get("failure_context_json") else None
            except Exception:
                payload["failure_context"] = None
            items.append(payload)
        return items

    def retry_story_queue_item(
        self,
        *,
        project_id: str,
        story_queue_id: str,
        preserve_failure_context: bool = True,
        replay_metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        now = int(time.time())
        with self._connect() as conn:
            row = conn.execute(
                "SELECT * FROM story_queue WHERE project_id=? AND story_queue_id=? LIMIT 1",
                (project_id, story_queue_id),
            ).fetchone()
            if row is None:
                raise ValueError(f"story_queue_id not found for project_id={project_id}: {story_queue_id}")
            prior_failure_context: dict[str, Any] | None = None
            if row["failure_context_json"]:
                try:
                    prior_failure_context = json.loads(str(row["failure_context_json"]))
                except Exception:
                    prior_failure_context = None
            failure_context: dict[str, Any] | None = None
            if preserve_failure_context and prior_failure_context is not None:
                failure_context = prior_failure_context
            elif isinstance(prior_failure_context, dict) and isinstance(prior_failure_context.get("churn_state"), dict):
                failure_context = {"churn_state": dict(prior_failure_context["churn_state"])}
            if replay_metadata is not None:
                if failure_context is None:
                    failure_context = {}
                failure_context["replay"] = replay_metadata
            conn.execute(
                (
                    "UPDATE story_queue SET status='queued', claimed_by_worker_id=NULL, claimed_at=NULL, started_run_id=NULL, finished_run_id=NULL, "
                    "updated_at=?, failure_message=NULL, failure_context_json=? WHERE story_queue_id=? AND project_id=?"
                ),
                (
                    now,
                    json.dumps(failure_context, sort_keys=True) if failure_context is not None else None,
                    story_queue_id,
                    project_id,
                ),
            )
        item = self.get_story_queue_item(story_queue_id=story_queue_id)
        if item is None:
            raise ValueError(f"story_queue_id vanished after retry reset: {story_queue_id}")
        return item

    def get_latest_node_attempt(self, *, run_id: str, node_id: str, status: str | None = None) -> dict[str, Any] | None:
        query = (
            "SELECT node_exec_id, run_id, node_id, node_name, status, attempt, started_at, finished_at, correlation_id, input_json, output_json, created_at, updated_at "
            "FROM nodes WHERE run_id=? AND node_id=?"
        )
        params: list[Any] = [run_id, node_id]
        if status is not None:
            query += " AND status=?"
            params.append(status)
        query += " ORDER BY attempt DESC, created_at DESC LIMIT 1"
        with self._connect() as conn:
            row = conn.execute(query, tuple(params)).fetchone()
        if row is None:
            return None
        return {
            "node_exec_id": row["node_exec_id"],
            "run_id": row["run_id"],
            "node_id": row["node_id"],
            "node_name": row["node_name"],
            "status": row["status"],
            "attempt": row["attempt"],
            "started_at": row["started_at"],
            "finished_at": row["finished_at"],
            "correlation_id": row["correlation_id"],
            "input": json.loads(row["input_json"]) if row["input_json"] else None,
            "output": json.loads(row["output_json"]) if row["output_json"] else None,
            "created_at": row["created_at"],
            "updated_at": row["updated_at"],
        }

    def list_artifacts_for_node(self, *, run_id: str, node_id: str) -> list[dict[str, Any]]:
        with self._connect() as conn:
            rows = conn.execute(
                (
                    "SELECT a.artifact_id, a.run_id, a.node_exec_id, a.kind, a.uri, a.content_type, a.byte_size, a.sha256, a.metadata_json, a.created_at, a.updated_at "
                    "FROM artifacts a "
                    "JOIN nodes n ON n.node_exec_id = a.node_exec_id "
                    "WHERE a.run_id=? AND n.node_id=? "
                    "ORDER BY a.created_at ASC"
                ),
                (run_id, node_id),
            ).fetchall()
        return [
            {
                "artifact_id": row["artifact_id"],
                "run_id": row["run_id"],
                "node_exec_id": row["node_exec_id"],
                "kind": row["kind"],
                "uri": row["uri"],
                "content_type": row["content_type"],
                "byte_size": row["byte_size"],
                "sha256": row["sha256"],
                "metadata": json.loads(row["metadata_json"]) if row["metadata_json"] else {},
                "created_at": row["created_at"],
                "updated_at": row["updated_at"],
            }
            for row in rows
        ]

    def get_artifact(self, *, artifact_id: str) -> dict[str, Any] | None:
        with self._connect() as conn:
            row = conn.execute(
                (
                    "SELECT artifact_id, run_id, node_exec_id, kind, uri, content_type, byte_size, sha256, metadata_json, created_at, updated_at "
                    "FROM artifacts WHERE artifact_id=?"
                ),
                (artifact_id,),
            ).fetchone()
        if row is None:
            return None
        return {
            "artifact_id": row["artifact_id"],
            "run_id": row["run_id"],
            "node_exec_id": row["node_exec_id"],
            "kind": row["kind"],
            "uri": row["uri"],
            "content_type": row["content_type"],
            "byte_size": row["byte_size"],
            "sha256": row["sha256"],
            "metadata": json.loads(row["metadata_json"]) if row["metadata_json"] else {},
            "created_at": row["created_at"],
            "updated_at": row["updated_at"],
        }

    def enqueue_task(
        self,
        *,
        project_id: str | None,
        queue_name: str,
        task_kind: str,
        input_payload: dict[str, Any],
        context: dict[str, Any] | None = None,
        priority: int = 100,
        available_at: int | None = None,
        idempotency_key: str | None = None,
        parent_task_id: str | None = None,
        source_run_id: str | None = None,
        max_attempts: int = 3,
    ) -> dict[str, Any]:
        now = int(time.time())
        task_id = str(uuid.uuid4())
        available = int(available_at if available_at is not None else now)
        with self._connect() as conn:
            if project_id and source_run_id:
                repo_row = conn.execute("SELECT repo_root FROM runs WHERE run_id=?", (source_run_id,)).fetchone()
                repo_root = None if repo_row is None or not repo_row["repo_root"] else Path(str(repo_row["repo_root"]))
                self._ensure_project_row(conn, project_id=project_id, repo_root=repo_root)
            if idempotency_key:
                existing = conn.execute(
                    (
                        "SELECT task_id, project_id, queue_name, task_kind, status, priority, idempotency_key, parent_task_id, "
                        "source_run_id, lease_token, lease_expires_at, claimed_by_worker_id, claimed_at, available_at, started_at, finished_at, "
                        "attempts, max_attempts, last_error, input_json, context_json, result_json, created_at, updated_at "
                        "FROM task_records WHERE queue_name=? AND idempotency_key=? "
                        "AND status NOT IN ('completed','failed','cancelled','dead_letter') "
                        "ORDER BY created_at DESC LIMIT 1"
                    ),
                    (queue_name, idempotency_key),
                ).fetchone()
                if existing is not None:
                    return self._task_row_to_dict(existing)
            conn.execute(
                (
                    "INSERT INTO task_records(task_id, project_id, queue_name, task_kind, status, priority, idempotency_key, parent_task_id, "
                    "source_run_id, available_at, attempts, max_attempts, input_json, context_json, created_at, updated_at) "
                    "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
                ),
                (
                    task_id,
                    project_id,
                    queue_name,
                    task_kind,
                    "queued",
                    int(priority),
                    idempotency_key,
                    parent_task_id,
                    source_run_id,
                    available,
                    0,
                    int(max_attempts),
                    json.dumps(input_payload, sort_keys=True),
                    json.dumps(context or {}, sort_keys=True),
                    now,
                    now,
                ),
            )
            row = conn.execute(
                "SELECT * FROM task_records WHERE task_id=?",
                (task_id,),
            ).fetchone()
        assert row is not None
        return self._task_row_to_dict(row)

    def _task_row_to_dict(self, row: sqlite3.Row) -> dict[str, Any]:
        return {
            "task_id": row["task_id"],
            "project_id": row["project_id"],
            "queue_name": row["queue_name"],
            "task_kind": row["task_kind"],
            "status": row["status"],
            "priority": row["priority"],
            "idempotency_key": row["idempotency_key"],
            "parent_task_id": row["parent_task_id"],
            "source_run_id": row["source_run_id"],
            "lease_token": row["lease_token"],
            "lease_expires_at": row["lease_expires_at"],
            "claimed_by_worker_id": row["claimed_by_worker_id"],
            "claimed_at": row["claimed_at"],
            "available_at": row["available_at"],
            "started_at": row["started_at"],
            "finished_at": row["finished_at"],
            "attempts": row["attempts"],
            "max_attempts": row["max_attempts"],
            "last_error": row["last_error"],
            "input": json.loads(row["input_json"]),
            "context": json.loads(row["context_json"]),
            "result": json.loads(row["result_json"]) if row["result_json"] else None,
            "created_at": row["created_at"],
            "updated_at": row["updated_at"],
        }

    def get_task(self, *, task_id: str) -> dict[str, Any] | None:
        with self._connect() as conn:
            row = conn.execute("SELECT * FROM task_records WHERE task_id=?", (task_id,)).fetchone()
        if row is None:
            return None
        return self._task_row_to_dict(row)

    def list_tasks(self, *, queue_name: str | None = None, project_id: str | None = None, status: str | None = None) -> list[dict[str, Any]]:
        where: list[str] = []
        params: list[Any] = []
        if queue_name is not None:
            where.append("queue_name=?")
            params.append(queue_name)
        if project_id is not None:
            where.append("project_id=?")
            params.append(project_id)
        if status is not None:
            where.append("status=?")
            params.append(status)
        sql = "SELECT * FROM task_records"
        if where:
            sql += " WHERE " + " AND ".join(where)
        sql += " ORDER BY created_at ASC"
        with self._connect() as conn:
            rows = conn.execute(sql, tuple(params)).fetchall()
        return [self._task_row_to_dict(row) for row in rows]

    def claim_next_task(self, *, queue_name: str, worker_id: str, lease_seconds: int = 900, task_kinds: list[str] | None = None) -> dict[str, Any] | None:
        now = int(time.time())
        lease_expires_at = now + int(lease_seconds)
        with self._connect() as conn:
            where = [
                "queue_name=?",
                "available_at<=?",
                "(status='queued' OR (status='leased' AND COALESCE(lease_expires_at, 0)<?))",
            ]
            params: list[Any] = [queue_name, now, now]
            if task_kinds:
                where.append("task_kind IN (%s)" % ",".join("?" for _ in task_kinds))
                params.extend(task_kinds)
            row = conn.execute(
                (
                    "SELECT * FROM task_records WHERE " + " AND ".join(where) +
                    " ORDER BY priority ASC, available_at ASC, created_at ASC LIMIT 1"
                ),
                tuple(params),
            ).fetchone()
            if row is None:
                return None
            lease_token = str(uuid.uuid4())
            conn.execute(
                (
                    "UPDATE task_records SET status='leased', lease_token=?, lease_expires_at=?, claimed_by_worker_id=?, claimed_at=?, "
                    "started_at=COALESCE(started_at, ?), attempts=attempts+1, updated_at=? WHERE task_id=?"
                ),
                (lease_token, lease_expires_at, worker_id, now, now, now, row["task_id"]),
            )
            claimed = conn.execute("SELECT * FROM task_records WHERE task_id=?", (row["task_id"],)).fetchone()
        assert claimed is not None
        payload = self._task_row_to_dict(claimed)
        payload["lease_token"] = lease_token
        return payload

    def renew_task_lease(self, *, task_id: str, lease_token: str, lease_seconds: int = 900) -> dict[str, Any]:
        now = int(time.time())
        lease_expires_at = now + int(lease_seconds)
        with self._connect() as conn:
            updated = conn.execute(
                "UPDATE task_records SET lease_expires_at=?, updated_at=? WHERE task_id=? AND lease_token=? AND status='leased'",
                (lease_expires_at, now, task_id, lease_token),
            )
            if updated.rowcount == 0:
                raise RuntimeError(f"task lease not active for task_id={task_id}")
            row = conn.execute("SELECT * FROM task_records WHERE task_id=?", (task_id,)).fetchone()
        assert row is not None
        return self._task_row_to_dict(row)

    def record_task_step(self, *, task_id: str, step_name: str, status: str, payload: dict[str, Any] | None = None) -> str:
        task_step_id = str(uuid.uuid4())
        now = int(time.time())
        with self._connect() as conn:
            row = conn.execute("SELECT COALESCE(MAX(seq), 0) FROM task_steps WHERE task_id=?", (task_id,)).fetchone()
            seq = int(row[0] if row is not None else 0) + 1
            conn.execute(
                "INSERT INTO task_steps(task_step_id, task_id, step_name, seq, status, payload_json, created_at, updated_at) VALUES(?,?,?,?,?,?,?,?)",
                (task_step_id, task_id, step_name, seq, status, json.dumps(payload or {}, sort_keys=True), now, now),
            )
            conn.execute("UPDATE task_records SET updated_at=? WHERE task_id=?", (now, task_id))
        return task_step_id

    def emit_task_message(self, *, task_id: str, message_kind: str, stream: str, payload: dict[str, Any]) -> str:
        task_message_id = str(uuid.uuid4())
        now = int(time.time())
        with self._connect() as conn:
            conn.execute(
                "INSERT INTO task_messages(task_message_id, task_id, message_kind, stream, payload_json, created_at) VALUES(?,?,?,?,?,?)",
                (task_message_id, task_id, message_kind, stream, json.dumps(payload, sort_keys=True), now),
            )
            conn.execute("UPDATE task_records SET updated_at=? WHERE task_id=?", (now, task_id))
        return task_message_id

    def list_task_messages(self, *, task_id: str) -> list[dict[str, Any]]:
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT task_message_id, message_kind, stream, payload_json, created_at FROM task_messages WHERE task_id=? ORDER BY created_at ASC",
                (task_id,),
            ).fetchall()
        return [
            {
                "task_message_id": row["task_message_id"],
                "message_kind": row["message_kind"],
                "stream": row["stream"],
                "payload": json.loads(row["payload_json"]),
                "created_at": row["created_at"],
            }
            for row in rows
        ]

    def complete_task(self, *, task_id: str, lease_token: str, status: str, result: dict[str, Any] | None = None, error: str | None = None, next_available_at: int | None = None) -> dict[str, Any]:
        if status not in {"completed", "failed", "queued", "cancelled", "dead_letter"}:
            raise ValueError(f"unsupported task status={status}")
        now = int(time.time())
        terminal = status in {"completed", "failed", "cancelled", "dead_letter"}
        with self._connect() as conn:
            row = conn.execute("SELECT attempts, max_attempts FROM task_records WHERE task_id=? AND lease_token=?", (task_id, lease_token)).fetchone()
            if row is None:
                raise RuntimeError(f"task lease not active for task_id={task_id}")
            if status == "failed" and int(row["attempts"] or 0) < int(row["max_attempts"] or 0):
                status = "queued"
                terminal = False
            conn.execute(
                (
                    "UPDATE task_records SET status=?, lease_token=NULL, lease_expires_at=NULL, finished_at=?, available_at=?, "
                    "result_json=?, last_error=?, updated_at=? WHERE task_id=? AND lease_token=?"
                ),
                (
                    status,
                    now if terminal else None,
                    int(next_available_at if next_available_at is not None else now),
                    json.dumps(result, sort_keys=True) if result is not None else None,
                    error,
                    now,
                    task_id,
                    lease_token,
                ),
            )
            fresh = conn.execute("SELECT * FROM task_records WHERE task_id=?", (task_id,)).fetchone()
        assert fresh is not None
        return self._task_row_to_dict(fresh)
