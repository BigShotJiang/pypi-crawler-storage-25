from __future__ import annotations

import json
import os
import re
from pathlib import Path
from typing import Any


def devflow_home() -> Path:
    base = os.environ.get("DEVFLOW_HOME") or os.environ.get("HOME")
    if base:
        return Path(base).expanduser().resolve()
    return Path.home().resolve()


def projects_registry_path() -> Path:
    return devflow_home() / ".devflow" / "registry" / "projects.json"


def read_projects_registry() -> dict[str, Any]:
    path = projects_registry_path()
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {"schema_version": 1, "projects": []}
    if not isinstance(raw, dict):
        return {"schema_version": 1, "projects": []}
    projects = raw.get("projects")
    if not isinstance(projects, list):
        projects = []
    return {"schema_version": 1, "projects": projects}


def normalize_github_selector(selector: str) -> str | None:
    s = selector.strip()
    if re.match(r"^[^/]+/[^/]+$", s):
        owner, repo = s.split("/", 1)
        return f"https://github.com/{owner.lower()}/{repo.lower()}.git"
    m = re.match(r"^https://github\.com/(?P<owner>[^/]+)/(?P<repo>[^/]+?)(?:\.git)?/?$", s)
    if m:
        return f"https://github.com/{m.group('owner').lower()}/{m.group('repo').lower()}.git"
    m = re.match(r"^git@github\.com:(?P<owner>[^/]+)/(?P<repo>[^/]+?)(?:\.git)?$", s)
    if m:
        return f"https://github.com/{m.group('owner').lower()}/{m.group('repo').lower()}.git"
    return None


def resolve_project_entry(selector: str) -> dict[str, Any] | None:
    reg = read_projects_registry()
    projects = reg.get("projects", [])
    if not isinstance(projects, list):
        return None

    normalized = normalize_github_selector(selector)
    selector_path = Path(selector).expanduser().resolve() if selector.startswith("/") or selector.startswith(".") else None

    for item in projects:
        if not isinstance(item, dict):
            continue
        if item.get("project_id") == selector:
            return item
        remote_url = str(item.get("remote_url") or "")
        if normalized and remote_url.lower() == normalized:
            return item
        repo_root = item.get("repo_root")
        if selector_path is not None and repo_root:
            try:
                if Path(str(repo_root)).expanduser().resolve() == selector_path:
                    return item
            except Exception:
                continue
        workspace_path = item.get("workspace_path")
        if selector_path is not None and workspace_path:
            try:
                if Path(str(workspace_path)).expanduser().resolve() == selector_path:
                    return item
            except Exception:
                continue
    return None


def find_project_for_repo_root(repo_root: Path) -> dict[str, Any] | None:
    repo_root = repo_root.expanduser().resolve()
    reg = read_projects_registry()
    projects = reg.get("projects", [])
    if not isinstance(projects, list):
        return None

    for item in projects:
        if not isinstance(item, dict):
            continue
        repo_root_raw = item.get("repo_root")
        if repo_root_raw:
            try:
                if Path(str(repo_root_raw)).expanduser().resolve() == repo_root:
                    return item
            except Exception:
                pass
        workspace_raw = item.get("workspace_path")
        if not workspace_raw:
            continue
        try:
            workspace = Path(str(workspace_raw)).expanduser().resolve()
        except Exception:
            continue
        if workspace == repo_root or workspace / "repo" == repo_root:
            return item
    return None
