"""Review workflow support.

DEPRECATED: The `review` CLI surface and this module are non-canonical.
Automated story execution should use the queue-driven worker pipeline
(`devflow worker start`). This module is retained for backward compatibility
and direct debugging only.
"""

from .dag import run_review_dag

__all__ = ["run_review_dag"]
