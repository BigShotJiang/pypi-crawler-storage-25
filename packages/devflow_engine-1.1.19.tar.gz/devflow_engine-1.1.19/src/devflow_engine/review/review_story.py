from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class Finding:
    kind: str
    severity: str
    message: str
    evidence: dict[str, Any]


def _anchor_exists(repo_root: Path, anchor: str) -> bool:
    # For now: treat anchor that looks like a path as filesystem check.
    p = (repo_root / anchor).resolve()
    try:
        p.relative_to(repo_root.resolve())
    except Exception:
        return False
    return p.exists()


def review_story_contract(repo_root: Path, contract: dict[str, Any]) -> list[Finding]:
    findings: list[Finding] = []

    for oracle in contract.get("plane_oracles", []) or []:
        anchor = oracle.get("anchor")
        plane = oracle.get("plane")
        if not isinstance(anchor, str) or not anchor:
            continue
        if _anchor_exists(repo_root, anchor):
            continue
        findings.append(
            Finding(
                kind="missing_anchor",
                severity="medium",
                message=f"Plane oracle anchor not found: {anchor}",
                evidence={"plane": plane, "anchor": anchor},
            )
        )

    # Lightweight security/compliance heuristics.
    sec = (contract.get("planes") or {}).get("security", "")
    comp = (contract.get("planes") or {}).get("compliance", "")
    if isinstance(sec, str) and "TODO" in sec:
        findings.append(
            Finding(
                kind="security_todo",
                severity="low",
                message="Security plane still contains TODO",
                evidence={},
            )
        )
    if isinstance(comp, str) and "TODO" in comp:
        findings.append(
            Finding(
                kind="compliance_todo",
                severity="low",
                message="Compliance plane still contains TODO",
                evidence={},
            )
        )

    return findings
