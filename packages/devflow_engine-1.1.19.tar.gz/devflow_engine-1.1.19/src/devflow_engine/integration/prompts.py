from __future__ import annotations

import re
from pathlib import Path


_REPO_ROOT = Path(__file__).resolve().parents[3]
_PROMPTS_ROOT = _REPO_ROOT / "prompts" / "integration"

_STAGE_PROMPT_LAYOUT: dict[str, tuple[str, str]] = {
    "resolve_side_effects": ("resolve", "resolve_side_effects"),
    "resolve_implicated_users": ("resolve", "resolve_implicated_users"),
    "write_workflows": ("write_workflows", "write_workflows"),
    "build_idea_acceptance_coverage": ("validate", "build_idea_acceptance_coverage"),
    "validate_enrich_gate": ("validate", "validate_enrich_gate"),
    "validate_repair": ("validate", "validate_repair"),
    "red": ("red", "red"),
    "red_repair": ("red", "red_repair"),
    "red_review": ("red_review", "red_review"),
    "green": ("green", "green"),
    "green_enrich": ("green_enrich", "green_enrich"),
}

_NODE_CONFIG_LAYOUT: dict[str, tuple[str, str]] = {
    "resolve": ("resolve", "node_config"),
    "write_workflows": ("write_workflows", "node_config"),
    "validate": ("validate", "node_config"),
    "red": ("red", "node_config"),
    "red_review": ("red_review", "node_config"),
    "green": ("green", "node_config"),
    "green_enrich": ("green_enrich", "node_config"),
}


def integration_prompt_path(*, node: str, agent_name: str) -> Path:
    return _PROMPTS_ROOT / node / agent_name / "prompt.md"


def integration_stage_prompt_path(stage_name: str) -> Path:
    normalized_stage_name = _normalize_stage_name(stage_name)
    try:
        node, agent_name = _STAGE_PROMPT_LAYOUT[normalized_stage_name]
    except KeyError as exc:
        raise KeyError(f"Unknown integration stage prompt mapping: {stage_name}") from exc
    return integration_prompt_path(node=node, agent_name=agent_name)


def integration_node_prompt_path(node: str) -> Path:
    try:
        mapped_node, agent_name = _NODE_CONFIG_LAYOUT[node]
    except KeyError as exc:
        raise KeyError(f"Unknown integration node prompt mapping: {node}") from exc
    return integration_prompt_path(node=mapped_node, agent_name=agent_name)


def load_integration_prompt_markdown(*, node: str, agent_name: str) -> str:
    return integration_prompt_path(node=node, agent_name=agent_name).read_text(encoding="utf-8").strip()


def load_integration_stage_prompt_markdown(stage_name: str) -> str:
    return integration_stage_prompt_path(stage_name).read_text(encoding="utf-8").strip()


def load_integration_node_instruction(node: str) -> str:
    return _parse_prompt_markdown(integration_node_prompt_path(node).read_text(encoding="utf-8"))[0]


def load_integration_stage_guidance(stage_name: str) -> list[str]:
    return _parse_prompt_markdown(integration_stage_prompt_path(stage_name).read_text(encoding="utf-8"))[1]


def load_integration_code_repair_guidance(*, red_mode: bool) -> list[str]:
    node = "red" if red_mode else "validate"
    return _parse_prompt_markdown(
        integration_prompt_path(node=node, agent_name="code_repair").read_text(encoding="utf-8")
    )[1]


def _parse_prompt_markdown(markdown: str) -> tuple[str, list[str]]:
    instruction = ""
    guidance: list[str] = []
    for raw_line in markdown.splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("- "):
            guidance.append(line[2:].strip())
            continue
        if not instruction:
            instruction = line
    if not instruction:
        raise ValueError("Integration prompt markdown is missing an instruction line.")
    return instruction, guidance


def _normalize_stage_name(stage_name: str) -> str:
    if re.fullmatch(r"red_repair_iter\d+", stage_name):
        return "red_repair"
    return stage_name
