from __future__ import annotations

import json
import logging
import os
import subprocess
from datetime import UTC, datetime
from pathlib import Path
from typing import Any
from urllib.request import Request, urlopen

from ..devflow_state import _is_uuid_like
from ..project_registration.dag import _infer_owner_repo, _lookup_supabase_project_uuid
from ..project_registry import find_project_for_repo_root, resolve_project_entry

logger = logging.getLogger(__name__)


def _keychain_get(service: str, account: str) -> str | None:
    try:
        proc = subprocess.run(
            ["security", "find-generic-password", "-s", service, "-a", account, "-w"],
            capture_output=True,
            text=True,
            check=False,
            timeout=10,
        )
    except Exception:
        return None
    if proc.returncode != 0:
        return None
    return proc.stdout.strip() or None


def resolve_supabase_rest_config() -> tuple[str, str] | None:
    if os.environ.get("PYTEST_CURRENT_TEST"):
        return None
    url = (
        os.environ.get("DEVFLOW_SUPABASE_URL")
        or os.environ.get("SUPABASE_URL")
        or _keychain_get("Supabase URL", "Clarity")
    )
    key = (
        os.environ.get("DEVFLOW_SUPABASE_SERVICE_KEY")
        or os.environ.get("SUPABASE_SERVICE_ROLE_KEY")
        or os.environ.get("SUPABASE_SERVICE_KEY")
        or _keychain_get("Supabase Service Key", "Clarity")
    )
    if not url or not key:
        return None
    return url.rstrip("/"), key


def postgrest_request(
    *,
    method: str,
    url: str,
    key: str,
    body: Any | None = None,
    prefer: str | None = None,
) -> Any:
    payload = None if body is None else json.dumps(body).encode("utf-8")
    req = Request(url, data=payload, method=method)
    req.add_header("apikey", key)
    req.add_header("Authorization", f"Bearer {key}")
    if body is not None:
        req.add_header("Content-Type", "application/json")
    if prefer:
        req.add_header("Prefer", prefer)
    with urlopen(req, timeout=30) as resp:
        raw = resp.read().decode("utf-8")
        return json.loads(raw) if raw else None


def resolve_authoritative_project_id(
    *,
    project_id: str,
    repo_root: Path | None,
    url: str,
    key: str,
    log_prefix: str,
    idea_id: str,
    run_id: str,
) -> str | None:
    resolved_project_id = str(project_id or "").strip()
    if not resolved_project_id or resolved_project_id.startswith("unregistered:"):
        return None
    if _is_uuid_like(resolved_project_id):
        return resolved_project_id
    if repo_root is None:
        project_entry = resolve_project_entry(resolved_project_id)
        repo_root_value = str((project_entry or {}).get("repo_root") or "").strip()
        if repo_root_value:
            repo_root = Path(repo_root_value).expanduser()
    if repo_root is None:
        logger.warning(
            "%s: skipping sync for idea_id=%s run_id=%s because local project_id=%s is not canonical and repo_root is unavailable",
            log_prefix,
            idea_id,
            run_id,
            project_id,
        )
        return None
    project_entry = find_project_for_repo_root(repo_root)
    remote_url = str((project_entry or {}).get("remote_url") or "").strip() or None
    project_name = str((project_entry or {}).get("name") or "").strip() or None
    owner, repo = _infer_owner_repo(remote_url, repo_root, project_name)
    try:
        resolved_project_id = _lookup_supabase_project_uuid(
            url=url,
            key=key,
            repo_root=repo_root,
            remote_url=remote_url,
            owner=owner,
            repo=repo,
        ) or ""
    except Exception as exc:
        logger.warning(
            "%s: skipping sync for idea_id=%s run_id=%s because canonical project UUID lookup failed for local project_id=%s: %s",
            log_prefix,
            idea_id,
            run_id,
            project_id,
            exc,
        )
        return None
    if not _is_uuid_like(resolved_project_id):
        logger.warning(
            "%s: skipping sync for idea_id=%s run_id=%s because canonical project UUID could not be resolved from local project_id=%s",
            log_prefix,
            idea_id,
            run_id,
            project_id,
        )
        return None
    return resolved_project_id


def upsert_idea_integration_row(
    *,
    idea_id: str,
    project_id: str,
    run_id: str,
    repo_root: Path | None = None,
    row: dict[str, Any],
    log_prefix: str = "integration-supabase-sync",
) -> None:
    config = resolve_supabase_rest_config()
    if config is None:
        return
    url, key = config
    resolved_project_id = resolve_authoritative_project_id(
        project_id=project_id,
        repo_root=repo_root,
        url=url,
        key=key,
        log_prefix=log_prefix,
        idea_id=idea_id,
        run_id=run_id,
    )
    if not resolved_project_id:
        return
    payload = dict(row)
    payload["idea_id"] = idea_id
    payload["project_id"] = resolved_project_id
    payload["run_id"] = run_id
    payload.setdefault("updated_at", datetime.now(UTC).isoformat())
    try:
        postgrest_request(
            method="POST",
            url=f"{url}/rest/v1/devflow_idea_integrations?on_conflict=idea_id",
            key=key,
            body=[payload],
            prefer="resolution=merge-duplicates",
        )
    except Exception:
        pass
