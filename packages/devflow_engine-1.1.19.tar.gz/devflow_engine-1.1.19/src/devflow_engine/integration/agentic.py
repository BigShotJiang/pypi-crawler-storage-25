from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from pydantic import BaseModel

from ..agentic_runtime import AgentRunEnvelope, run_agent_step
from .prompts import load_integration_code_repair_guidance, load_integration_stage_guidance


def run_integration_agent_step(
    *,
    repo_root: Path,
    stage_name: str,
    output_model: type[BaseModel],
    context_payload: dict[str, Any],
    guidance: list[str],
    timeout_seconds: int | None = None,
) -> tuple[BaseModel, AgentRunEnvelope]:
    return run_agent_step(
        repo_root=repo_root,
        stage_name=f"integration_{stage_name}",
        output_model=output_model,
        context_payload=context_payload,
        guidance=load_integration_stage_guidance(stage_name),
        timeout_seconds=timeout_seconds,
    )


def run_integration_code_repair_step(
    *,
    repo_root: Path,
    output_model: type[BaseModel],
    context_payload: dict[str, Any],
    iteration: int,
    timeout_seconds: int | None = None,
) -> tuple[BaseModel, AgentRunEnvelope]:
    guidance = load_integration_code_repair_guidance(
        red_mode=bool(context_payload.get("failing_packages"))
    ) + [
        f"This is repair iteration {iteration}. Stay on the current failing seam. Do not revisit clean surfaces.",
        "Respect protected_sections and do_not_touch when those fields are present in context_payload.",
    ]
    return run_agent_step(
        repo_root=repo_root,
        stage_name=f"integration_code_repair_iter{iteration}",
        output_model=output_model,
        context_payload=context_payload,
        guidance=guidance,
        timeout_seconds=timeout_seconds,
    )


def persist_agent_run(*, pipeline_root: Path, node_id: str, envelope: AgentRunEnvelope) -> Path:
    path = pipeline_root / f"{node_id}_agent_run.json"
    payload = {
        "node_id": node_id,
        "prompt": envelope.prompt,
        "response": envelope.response,
        "raw_stdout": envelope.raw_stdout,
        "raw_stderr": envelope.raw_stderr,
    }
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return path
