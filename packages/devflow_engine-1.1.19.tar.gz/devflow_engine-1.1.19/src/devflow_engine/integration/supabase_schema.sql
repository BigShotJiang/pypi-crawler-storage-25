CREATE TABLE IF NOT EXISTS devflow_idea_integrations (
  idea_id         TEXT PRIMARY KEY,
  project_id      TEXT NOT NULL,
  run_id          TEXT,
  pipeline_dir    TEXT,
  status          TEXT NOT NULL DEFAULT 'running',
  exit_code       INT,
  iterations_used INT,
  workflow_count  INT,
  side_effect_count INT,
  side_effects    JSONB,
  implicated_users JSONB,
  workflow_inventory JSONB,
  validation_report  JSONB,
  red_package     JSONB,
  red_review      JSONB,
  green_package   JSONB,
  green_enrich    JSONB,
  commit_package  JSONB,
  failure_message TEXT,
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_devflow_idea_integrations_project_status
  ON devflow_idea_integrations(project_id, status, updated_at DESC);

ALTER TABLE devflow_idea_integrations
  ADD COLUMN IF NOT EXISTS repair_cycles INT DEFAULT 0,
  ADD COLUMN IF NOT EXISTS repair_patches_count INT DEFAULT 0,
  ADD COLUMN IF NOT EXISTS repair_summary TEXT;
