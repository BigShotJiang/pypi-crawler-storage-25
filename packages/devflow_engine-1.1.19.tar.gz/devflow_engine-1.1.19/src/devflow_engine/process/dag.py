from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

from ..implementation.dag import run_implementation_dag
from ..stores.execution_store import ExecutionStore


@dataclass(frozen=True)
class ProcessResult:
    exit_code: int
    message: str
    implementation_exit_code: int
    review_exit_code: int
    implementation_run_id: str | None = None
    failed_stage: str | None = None
    failure_context: dict[str, Any] | None = None


def run_process_dag(*, repo_root: Path, store: ExecutionStore, story: dict[str, Any]) -> ProcessResult:
    """Raw process orchestration.

    Current behavior:
    - consume story
    - run implementation DAG
    - stop after implementation; review DAG is deprecated and intentionally not run

    This is written as a developer would (imperative code), before we encode
    canonical workflow semantics via the GenAI workflow framework.
    """

    impl_result = run_implementation_dag(repo_root=repo_root, store=store, story=story)
    impl_exit = impl_result.exit_code
    impl_msg = impl_result.message
    if impl_exit != 0:
        # Implementation failed; stop the process.
        msg = impl_msg or "process failed: implementation step failed\n"
        return ProcessResult(
            exit_code=impl_exit,
            message=msg,
            implementation_exit_code=impl_exit,
            review_exit_code=0,
            implementation_run_id=impl_result.run_id,
            failed_stage=impl_result.failed_stage,
            failure_context=impl_result.failure_context,
        )

    msg = impl_msg or "ok\n"
    return ProcessResult(
        exit_code=0,
        message=msg,
        implementation_exit_code=impl_exit,
        review_exit_code=0,
        implementation_run_id=impl_result.run_id,
        failed_stage=None,
        failure_context=None,
    )
