"""Process DAG orchestration (raw imperative).

This is intentionally *not* implemented using the vendored GenAI workflow framework yet.
It exists to give the module registry real-world "custom orchestration" shapes to detect.
"""
