from __future__ import annotations

import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Literal

from pydantic import BaseModel, ValidationError

from ..idea.traditional_stories import _extract_json
from ..llm.invoke import (
    LlmInvocationRequest,
    LlmInvocationResult,
    invoke_llm,
    resolve_api_tier_request_overrides,
    resolve_canonical_light_tier_model,
)
from .agent_definition import (
    build_artifact_reference_response_prompt_payload,
    build_devin2_agent_prompt_payload,
    build_response_prompt_payload,
)

_DEVIN_AGENT_PROVIDER = "minimax"
_DEVIN_AGENT_DEFAULT_MODEL = "MiniMax-M2.7"
_PI_BASE_CMD = "pi"
_PI_DELIVERY = "argument"
_PI_DEVFLOW_TOOLS_EXT = str(Path.home() / ".pi/agent/extensions/devflow-tools.ts")
_PI_BASE_CMD_WITH_DEVFLOW_TOOLS = f"pi -e {_PI_DEVFLOW_TOOLS_EXT}"
_MAX_PROMPT_CHARS = 120_000
_PI_MODEL_ALIASES: dict[tuple[str | None, str], str] = {
    ("minimax", "MiniMax Token 2.7"): "MiniMax-M2.7",
}


@dataclass(frozen=True)
class Devin2PiRunResult:
    response_model: BaseModel
    prompt_payload: dict[str, Any]
    invocation: LlmInvocationResult


class Devin2PiRunnerError(RuntimeError):
    """Raised when the Devin 2.0 PI harness fails or returns invalid output."""


def _persist_context_artifact(*, repo_root: Path, stage_name: str, context_payload: dict[str, Any]) -> Path:
    artifact_root = repo_root / ".devflow" / "agent_debug" / "devin2_context_artifacts"
    artifact_root.mkdir(parents=True, exist_ok=True)
    safe_stage_name = re.sub(r"[^A-Za-z0-9_.-]+", "_", stage_name).strip("._") or "stage"
    artifact_path = artifact_root / f"{safe_stage_name}.json"
    artifact_path.write_text(json.dumps(context_payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return artifact_path


def _extract_response_json(stdout: str) -> Any:
    extracted = _extract_json(stdout)
    if extracted is None:
        raise Devin2PiRunnerError("Devin 2.0 PI harness returned no JSON payload.")
    try:
        return json.loads(extracted)
    except json.JSONDecodeError as exc:
        raise Devin2PiRunnerError(f"Devin 2.0 PI harness returned invalid JSON: {exc}") from exc


def _build_devin2_prompt_payload(
    *,
    repo_root: Path,
    route_arm: Literal["ideation", "insight", "iterate"],
    stage_name: str,
    context_payload: dict[str, Any],
    operational_guidance: list[str],
    output_model: type[BaseModel],
) -> dict[str, Any]:
    agent_prompt = build_devin2_agent_prompt_payload(repo_root=repo_root, route_arm=route_arm)
    prompt_payload = build_response_prompt_payload(
        stage_name=stage_name,
        context_payload=context_payload,
        operational_guidance=operational_guidance,
        output_model=output_model,
        agent_prompt=agent_prompt,
    )
    serialized = json.dumps(prompt_payload, indent=2, sort_keys=True)
    if len(serialized) <= _MAX_PROMPT_CHARS:
        return prompt_payload

    artifact_path = _persist_context_artifact(
        repo_root=repo_root,
        stage_name=stage_name,
        context_payload=context_payload,
    )
    return build_artifact_reference_response_prompt_payload(
        stage_name=stage_name,
        operational_guidance=operational_guidance,
        output_model=output_model,
        agent_prompt=agent_prompt,
        artifact_path=artifact_path,
    )




def _normalize_pi_model_name(*, provider: str | None, model: str | None) -> str | None:
    normalized = str(model or "").strip()
    if not normalized:
        return None
    return _PI_MODEL_ALIASES.get((provider, normalized), normalized)


def _resolve_devin_agent_model() -> str:
    provider: str | None = None
    model: str | None = None
    try:
        overrides = resolve_api_tier_request_overrides(tier="light")
        provider = str(overrides.get("provider") or "").strip().lower() or None
        model = str(overrides.get("model") or "").strip() or None
    except Exception:
        model = resolve_canonical_light_tier_model()
    if provider and provider != _DEVIN_AGENT_PROVIDER:
        return _DEVIN_AGENT_DEFAULT_MODEL
    if provider is None and model and "minimax" not in str(model).strip().lower():
        return _DEVIN_AGENT_DEFAULT_MODEL
    normalized_model = _normalize_pi_model_name(provider=provider, model=model)
    return normalized_model or _DEVIN_AGENT_DEFAULT_MODEL

def run_devin2_pi_agent(
    *,
    repo_root: Path,
    stage_name: str,
    route_arm: Literal["ideation", "insight", "iterate"],
    context_payload: dict[str, Any],
    operational_guidance: list[str],
    output_model: type[BaseModel],
    timeout_seconds: int | None = None,
) -> Devin2PiRunResult:
    """Run the Devin 2.0 prompt payload through the Clarity MiniMax agent endpoint.

    This seam hard-pins Devin agent execution to Clarity's authenticated
    ``/clarify/minimax/devflow-agent-turn`` route. Clarity owns the MiniMax
    secret and Langfuse instrumentation; DevFlow only sends the prompt payload
    and runtime metadata.
    """
    repo_root.mkdir(parents=True, exist_ok=True)
    prompt_payload = _build_devin2_prompt_payload(
        repo_root=repo_root,
        route_arm=route_arm,
        stage_name=stage_name,
        context_payload=context_payload,
        operational_guidance=operational_guidance,
        output_model=output_model,
    )
    prompt_text = json.dumps(prompt_payload, indent=2, sort_keys=True)
    canonical_light_model = _resolve_devin_agent_model()

    _MAX_PI_ATTEMPTS = 3
    last_error: Exception | None = None
    invocation = None
    for _attempt in range(_MAX_PI_ATTEMPTS):
        invocation = invoke_llm(
            LlmInvocationRequest(
                purpose=stage_name,
                strength="light",
                repo_root=repo_root,
                prompt=prompt_text,
                prompt_payload=prompt_payload,
                delivery_model="final_only",
                interaction_model="agentic",
                response_contract="json_only",
                timeout_seconds=timeout_seconds,
                transport="api",
                provider=_DEVIN_AGENT_PROVIDER,
                model=canonical_light_model,
                event_context={
                    "agent_id": "devin_agent",
                    "stage_name": stage_name,
                    "route_arm": route_arm,
                },
            )
        )
        if not invocation.ok:
            last_error = Devin2PiRunnerError(invocation.stderr or invocation.stdout or "Devin 2.0 PI harness failed.")
            continue
        # Check for parseable JSON in the response
        parsed_json = invocation.parsed_json
        if parsed_json is None:
            try:
                parsed_json = _extract_response_json(invocation.stdout)
            except Devin2PiRunnerError as exc:
                last_error = exc
                continue
        break
    else:
        if last_error is not None:
            raise last_error
        raise Devin2PiRunnerError("Devin 2.0 PI harness failed after all retry attempts.")
    assert invocation is not None
    try:
        response_model = output_model.model_validate(parsed_json)
    except ValidationError as exc:
        raise Devin2PiRunnerError(f"Devin 2.0 PI harness returned schema-invalid JSON: {exc}") from exc

    return Devin2PiRunResult(
        response_model=response_model,
        prompt_payload=prompt_payload,
        invocation=invocation,
    )
