from __future__ import annotations

from pathlib import Path
from typing import Any, Literal

from pydantic import BaseModel

_REPO_ROOT = Path(__file__).resolve().parents[3]
_DEVIN2_PROMPT_PATH = _REPO_ROOT / "docs" / "prompts" / "devin2-agent-prompt.md"
_PROJECT_JOURNAL_RELATIVE_DIR = ".devflow/journal"


class Devin2AgentPromptPayload(BaseModel):
    agent_name: str
    route_arm: Literal["ideation", "insight", "iterate", "neither"]
    prompt_path: str
    prompt_markdown: str
    project_journal: dict[str, Any]
    separation_contract: dict[str, Any]


def devin2_agent_prompt_path() -> Path:
    return _DEVIN2_PROMPT_PATH


def load_devin2_agent_prompt() -> str:
    return _DEVIN2_PROMPT_PATH.read_text(encoding="utf-8").strip()


def build_devin2_agent_prompt_payload(
    *,
    repo_root: Path,
    route_arm: Literal["ideation", "insight", "iterate"],
) -> dict[str, Any]:
    journal_root = repo_root / _PROJECT_JOURNAL_RELATIVE_DIR
    return Devin2AgentPromptPayload(
        agent_name="Devin 2.0",
        route_arm=route_arm,
        prompt_path=str(_DEVIN2_PROMPT_PATH),
        prompt_markdown=load_devin2_agent_prompt(),
        project_journal={
            "relative_dir": _PROJECT_JOURNAL_RELATIVE_DIR,
            "absolute_dir": str(journal_root),
            "entry_pattern": ".devflow/journal/YYYY-MM-DD.md",
            "write_rule": (
                "Persist material assumptions, decisions, and continuity notes here "
                "when they matter across turns or later execution."
            ),
        },
        separation_contract={
            "baseline_path": "docs/prompts/devin-agent-prompt.md",
            "v2_path": "docs/prompts/devin2-agent-prompt.md",
            "prompt_role": "Defines Devin 2.0's conversational stance and ownership split.",
            "operational_guidance_role": (
                "Supplies turn-specific workflow rules, route constraints, and execution caveats."
            ),
            "runtime_contract_role": "Defines the JSON output schema and return contract only.",
        },
    ).model_dump()


def build_inline_agent_prompt_payload(
    *,
    prompt_text: str,
    route_arm: Literal["ideation", "insight", "iterate", "neither"],
) -> dict[str, Any]:
    return {
        "agent_name": "inline_response_agent",
        "route_arm": route_arm,
        "prompt_text": str(prompt_text).strip(),
    }


def build_response_prompt_payload(
    *,
    stage_name: str,
    context_payload: dict[str, Any],
    operational_guidance: list[str],
    output_model: type[BaseModel],
    agent_prompt: dict[str, Any],
) -> dict[str, Any]:
    return {
        "task": stage_name,
        "agent_prompt": agent_prompt,
        "operational_guidance": list(operational_guidance),
        "context": context_payload,
        "runtime_contract": {
            "output_schema": output_model.model_json_schema(),
            "return_format": "json_only",
        },
    }


def build_artifact_reference_response_prompt_payload(
    *,
    stage_name: str,
    operational_guidance: list[str],
    output_model: type[BaseModel],
    agent_prompt: dict[str, Any],
    artifact_path: Path,
) -> dict[str, Any]:
    return {
        "task": stage_name,
        "agent_prompt": agent_prompt,
        "operational_guidance": list(operational_guidance)
        + [
            "The full context was persisted to disk because the prompt exceeded size limits.",
            f"Read context from artifact_path={artifact_path}",
        ],
        "context_artifact": {
            "artifact_path": str(artifact_path),
        },
        "runtime_contract": {
            "output_schema": output_model.model_json_schema(),
            "return_format": "json_only",
        },
    }
