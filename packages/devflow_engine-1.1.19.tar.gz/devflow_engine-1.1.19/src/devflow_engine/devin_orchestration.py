from __future__ import annotations

from pathlib import Path
from typing import Any

from devin.dag_two_arm import run_devin_two_arm_dag as run_devin_chat_dag
from .stores.execution_store import ExecutionStore

DEVIN_QUEUE_NAME = "assistant.devin"
DEVIN_CHAT_TASK_KIND = "devin.chat"


def enqueue_devin_chat_task(
    *,
    store: ExecutionStore,
    project_id: str | None,
    idea_id: str,
    repo_root: Path,
    text: str | None,
    source_path: Path | None,
    max_stories: int,
    planes: list[str],
    source_run_id: str | None = None,
    response_mode_label: str | None = None,
) -> dict[str, Any]:
    idempotency_key = f"{idea_id}:{','.join(sorted(planes))}:{max_stories}:{text or ''}:{str(source_path or '')}:{response_mode_label or ''}"
    return store.enqueue_task(
        project_id=project_id,
        queue_name=DEVIN_QUEUE_NAME,
        task_kind=DEVIN_CHAT_TASK_KIND,
        idempotency_key=idempotency_key,
        source_run_id=source_run_id,
        input_payload={
            "idea_id": idea_id,
            "text": text,
            "source_path": str(source_path) if source_path else None,
            "max_stories": max_stories,
            "planes": planes,
            "response_mode_label": response_mode_label,
        },
        context={"client": "devin", "workflow": "devin_chat"},
    )


def handle_devin_chat_task(store: ExecutionStore, repo_root: Path, task: dict[str, Any]) -> dict[str, Any]:
    payload = dict(task.get("input") or {})
    task_id = str(task["task_id"])
    store.record_task_step(task_id=task_id, step_name="devin_chat.run", status="started", payload=payload)
    result = run_devin_chat_dag(
        repo_root=repo_root,
        store=store,
        idea_id=str(payload.get("idea_id") or ""),
        text=payload.get("text"),
        source_path=Path(str(payload["source_path"])) if payload.get("source_path") else None,
        max_stories=int(payload.get("max_stories") or 3),
        planes=[str(item) for item in (payload.get("planes") or ["api"])],
        response_mode_label=(None if payload.get("response_mode_label") is None else str(payload.get("response_mode_label"))),
    )
    response = {
        "idea_id": str(payload.get("idea_id") or ""),
        "run_id": result.run_id,
        "exit_code": result.exit_code,
        "pipeline_dir": str(result.pipeline_dir),
        "message": result.message,
        "outcome": result.outcome,
    }
    store.emit_task_message(task_id=task_id, message_kind="result", stream="assistant", payload=response)
    store.record_task_step(task_id=task_id, step_name="devin_chat.run", status="finished", payload=response)
    return response
