from __future__ import annotations

import json
import os
import subprocess
from datetime import UTC, datetime
from typing import Any
from urllib.request import Request, urlopen


def _keychain_get(service: str, account: str) -> str | None:
    try:
        proc = subprocess.run(
            ["security", "find-generic-password", "-s", service, "-a", account, "-w"],
            capture_output=True,
            text=True,
            check=False,
            timeout=10,
        )
    except Exception:
        return None
    if proc.returncode != 0:
        return None
    value = proc.stdout.strip()
    return value or None


def _resolve_supabase_rest_config() -> tuple[str, str] | None:
    if os.environ.get("PYTEST_CURRENT_TEST"):
        return None
    url = (
        os.environ.get("DEVFLOW_SUPABASE_URL")
        or os.environ.get("SUPABASE_URL")
        or _keychain_get("Supabase URL", "Clarity")
    )
    key = (
        os.environ.get("DEVFLOW_SUPABASE_SERVICE_KEY")
        or os.environ.get("SUPABASE_SERVICE_ROLE_KEY")
        or os.environ.get("SUPABASE_SERVICE_KEY")
        or _keychain_get("Supabase Service Key", "Clarity")
    )
    if not url or not key:
        return None
    return url.rstrip("/"), key


def _postgrest_request(*, method: str, url: str, key: str, body: Any | None = None, prefer: str | None = None) -> Any:
    payload = None if body is None else json.dumps(body).encode("utf-8")
    req = Request(url, data=payload, method=method)
    req.add_header("apikey", key)
    req.add_header("Authorization", f"Bearer {key}")
    if body is not None:
        req.add_header("Content-Type", "application/json")
    if prefer:
        req.add_header("Prefer", prefer)
    with urlopen(req, timeout=30) as resp:
        raw = resp.read().decode("utf-8")
        return json.loads(raw) if raw else None


def _is_uuid_like(value: str | None) -> bool:
    if not value:
        return False
    import re

    pattern = r"[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}"
    return bool(re.fullmatch(pattern, value.strip()))


def _resolve_dfs_project_id(*, url: str, key: str, project_id: str, display_path: str | None) -> str:
    value = str(project_id or '').strip()
    if _is_uuid_like(value):
        return value
    display_value = str(display_path or '').strip()
    idea_id = None
    if display_value.startswith('idea:'):
        candidate = display_value.split(':', 1)[1].strip()
        if candidate.startswith('idea_'):
            idea_id = candidate
    elif display_value.startswith('story:'):
        candidate = display_value.split(':', 1)[1].strip()
        if candidate.startswith('STORY:idea:'):
            parts = candidate.split(':')
            if len(parts) >= 3 and parts[2].startswith('idea_'):
                idea_id = parts[2]
    if not idea_id:
        return value
    try:
        lookup_url = f"{url}/rest/v1/devflow_project_ideas?select=project_id&idea_id=eq.{idea_id}&limit=1"
        rows = _postgrest_request(method='GET', url=lookup_url, key=key)
    except Exception:
        return value
    if isinstance(rows, list) and rows:
        resolved = str((rows[0] or {}).get('project_id') or '').strip()
        if resolved:
            return resolved
    return value


def publish_devflow_state(
    *,
    project_id: str,
    run_id: str | None,
    current_state: str,
    current_status: str,
    run_summary: str,
    error_message: str | None = None,
    display: str = "project",
    display_path: str | None = None,
) -> None:
    config = _resolve_supabase_rest_config()
    if config is None:
        return
    url, key = config
    resolved_project_id = _resolve_dfs_project_id(url=url, key=key, project_id=project_id, display_path=display_path)
    row = {
        "project_id": resolved_project_id,
        "run_id": run_id,
        "current_state": current_state,
        "current_status": current_status,
        "error_code": None,
        "error_message": error_message,
        "display": display,
        "display_path": display_path,
        "run_summary": run_summary,
        "updated_at": datetime.now(UTC).isoformat(),
    }
    try:
        _postgrest_request(
            method="POST",
            url=f"{url}/rest/v1/devflow_state?on_conflict=project_id",
            key=key,
            body=row,
            prefer="resolution=merge-duplicates",
        )
    except Exception:
        return


def fetch_story_statuses_from_supabase(*, story_ids: list[str]) -> dict[str, str]:
    """Return Supabase story statuses keyed by story_id for the requested story ids."""
    config = _resolve_supabase_rest_config()
    if config is None:
        return {}
    normalized = [str(story_id or "").strip() for story_id in story_ids]
    wanted = sorted({story_id for story_id in normalized if story_id})
    if not wanted:
        return {}

    url, key = config
    rows_by_story_id: dict[str, str] = {}
    try:
        from urllib.parse import quote

        batch_size = 100
        for offset in range(0, len(wanted), batch_size):
            batch = wanted[offset : offset + batch_size]
            encoded_values = ",".join(quote(f'"{story_id}"', safe="") for story_id in batch)
            rows = _postgrest_request(
                method="GET",
                url=(
                    f"{url}/rest/v1/devflow_idea_stories?select=story_id,status"
                    f"&story_id=in.({encoded_values})"
                ),
                key=key,
            )
            if not isinstance(rows, list):
                continue
            for row in rows:
                if not isinstance(row, dict):
                    continue
                story_id = str(row.get("story_id") or "").strip()
                status = str(row.get("status") or "").strip()
                if story_id:
                    rows_by_story_id[story_id] = status
    except Exception:
        return {}
    return rows_by_story_id


def update_story_status_in_supabase(*, story_id: str, status: str) -> None:
    """Mirror story implementation status to Supabase devflow_idea_stories."""
    config = _resolve_supabase_rest_config()
    if config is None:
        return
    url, key = config
    try:
        from urllib.parse import quote

        row = {
            "status": status,
            "updated_at": datetime.now(UTC).isoformat(),
        }
        _postgrest_request(
            method="PATCH",
            url=f"{url}/rest/v1/devflow_idea_stories?story_id=eq.{quote(story_id)}",
            key=key,
            body=row,
        )
    except Exception:
        return  # non-fatal — local state is source of truth
