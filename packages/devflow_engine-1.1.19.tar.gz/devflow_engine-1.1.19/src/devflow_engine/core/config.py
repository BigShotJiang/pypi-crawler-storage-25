from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml


@dataclass(frozen=True)
class EffectiveValue:
    value: Any
    source: str


@dataclass(frozen=True)
class DevflowConfig:
    log_level: str = "INFO"
    api_key: str | None = None


def _read_yaml_file(path: Path) -> dict[str, Any]:
    try:
        raw = yaml.safe_load(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        return {}
    except Exception:
        # Non-fatal for bootstrap; treat as absent.
        return {}
    if raw is None:
        return {}
    if not isinstance(raw, dict):
        return {}
    return raw


def load_effective_config(
    *,
    config_file: Path | None,
    env: dict[str, str] | None = None,
    cli_log_level: str | None = None,
) -> tuple[DevflowConfig, dict[str, EffectiveValue]]:
    """Load config with precedence defaults < file < env < cli.

    Returns (config, meta) where meta contains per-field source/value.
    """

    env = dict(os.environ) if env is None else env

    # Defaults
    data: dict[str, EffectiveValue] = {
        "log_level": EffectiveValue("INFO", "default"),
        "api_key": EffectiveValue(None, "default"),
    }

    # File
    if config_file is not None:
        file_data = _read_yaml_file(config_file)
        if "log_level" in file_data and isinstance(file_data["log_level"], str):
            data["log_level"] = EffectiveValue(file_data["log_level"], f"file:{config_file}")
        if "api_key" in file_data and isinstance(file_data["api_key"], str):
            data["api_key"] = EffectiveValue(file_data["api_key"], f"file:{config_file}")

    # Env
    if (lvl := env.get("DEVFLOW_ENGINE_LOG_LEVEL")):
        data["log_level"] = EffectiveValue(lvl, "env:DEVFLOW_ENGINE_LOG_LEVEL")
    if (key := env.get("DEVFLOW_ENGINE_API_KEY")):
        data["api_key"] = EffectiveValue(key, "env:DEVFLOW_ENGINE_API_KEY")

    # CLI
    if cli_log_level:
        data["log_level"] = EffectiveValue(cli_log_level, "cli:--log-level")

    cfg = DevflowConfig(log_level=str(data["log_level"].value), api_key=data["api_key"].value)
    return cfg, data


def redact_value(key: str, value: Any) -> str:
    if value is None:
        return "<unset>"

    k = key.lower()
    if any(tok in k for tok in ["key", "token", "secret", "password"]):
        return "***"
    return str(value)
