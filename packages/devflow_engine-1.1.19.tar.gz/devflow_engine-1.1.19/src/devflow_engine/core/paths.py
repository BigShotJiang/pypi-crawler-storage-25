from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class DevflowPaths:
    root: Path

    @property
    def devflow_dir(self) -> Path:
        return self.root / ".devflow"

    @property
    def execution_db(self) -> Path:
        return self.devflow_dir / "execution.sqlite"

    @property
    def projects_dir(self) -> Path:
        return self.devflow_dir / "projects"

    @property
    def stories_dir(self) -> Path:
        return self.devflow_dir / "stories"

    @property
    def logs_dir(self) -> Path:
        return self.devflow_dir / "logs"


def find_repo_root(start: Path | None = None) -> Path:
    """Find the repo root (directory containing .git) walking upwards.

    Falls back to current working directory if no .git found.
    """
    here = (start or Path.cwd()).resolve()
    for p in [here, *here.parents]:
        if (p / ".git").exists():
            return p
    return here


def get_paths(start: Path | None = None) -> DevflowPaths:
    return DevflowPaths(root=find_repo_root(start))
