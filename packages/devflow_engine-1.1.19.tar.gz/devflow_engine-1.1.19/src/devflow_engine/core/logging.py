from __future__ import annotations

import logging
from pathlib import Path

from rich.logging import RichHandler


def configure_logging(log_dir: Path | None, level: str = "INFO") -> None:
    """Configure console + optional file logging."""
    handlers: list[logging.Handler] = [
        RichHandler(rich_tracebacks=True, show_time=True, show_level=True, show_path=False)
    ]

    if log_dir is not None:
        log_dir.mkdir(parents=True, exist_ok=True)
        file_path = log_dir / "devflow.log"
        file_handler = logging.FileHandler(file_path)
        file_handler.setFormatter(
            logging.Formatter("%(asctime)s %(levelname)s %(name)s %(message)s")
        )
        handlers.append(file_handler)

    logging.basicConfig(
        level=getattr(logging, level.upper(), logging.INFO),
        format="%(message)s",
        datefmt="[%X]",
        handlers=handlers,
    )
