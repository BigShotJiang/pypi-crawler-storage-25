from __future__ import annotations

from pathlib import Path
from typing import Any


def _toml_quote(s: str) -> str:
    # Minimal TOML basic string quoting.
    return '"' + s.replace('\\', '\\\\').replace('"', '\\"') + '"'


def write_toml_kv(path: Path, data: dict[str, Any]) -> None:
    """Write a minimal TOML file for flat key/value pairs.

    This intentionally supports only string/int/bool keys at the top level.
    Good enough for devflow global config without bringing in a toml writer dep.
    """

    lines: list[str] = []
    for k in sorted(data.keys()):
        v = data[k]
        if isinstance(v, bool):
            vv = "true" if v else "false"
        elif isinstance(v, int):
            vv = str(v)
        elif v is None:
            continue
        else:
            vv = _toml_quote(str(v))
        lines.append(f"{k} = {vv}")

    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
