from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any

from ..devflow_state import fetch_story_statuses_from_supabase
from ..stores.execution_store import ExecutionStore

ACTIVE_STORY_QUEUE_STATUSES = ("queued", "claimed", "in_progress", "blocked")
PURGE_NOTE = "story queue completed locally because Supabase already marks the story implemented"


def _load_active_story_queue_rows(store: ExecutionStore, *, project_id: str | None) -> list[dict[str, Any]]:
    query = (
        "SELECT story_queue_id, project_id, enqueue_run_id, story_artifact_id, story_id, title, status, "
        "claimed_by_worker_id, claimed_at, started_run_id, finished_run_id, failure_message, failure_context_json, "
        "created_at, updated_at "
        "FROM story_queue WHERE status IN ('queued','claimed','in_progress','blocked')"
    )
    params: tuple[Any, ...] = ()
    if project_id is not None:
        query += " AND project_id=?"
        params = (project_id,)
    query += " ORDER BY created_at ASC, story_queue_id ASC"

    with store._connect() as conn:
        rows = conn.execute(query, params).fetchall()

    payloads: list[dict[str, Any]] = []
    for row in rows:
        payload = dict(row)
        try:
            payload["failure_context"] = (
                json.loads(str(payload.get("failure_context_json") or ""))
                if payload.get("failure_context_json")
                else None
            )
        except Exception:
            payload["failure_context"] = None
        payloads.append(payload)
    return payloads


def purge_implemented_story_queue(
    *,
    repo_root: Path,
    project_id: str | None = None,
    apply: bool = False,
) -> dict[str, Any]:
    repo_root = repo_root.expanduser().resolve()
    store = ExecutionStore(repo_root / ".devflow" / "execution.sqlite")
    queue_rows = _load_active_story_queue_rows(store, project_id=project_id)
    story_ids = sorted(
        {
            str(row.get("story_id") or "").strip()
            for row in queue_rows
            if str(row.get("story_id") or "").strip()
        }
    )
    supabase_status_by_story_id = fetch_story_statuses_from_supabase(story_ids=story_ids)

    candidates: list[dict[str, Any]] = []
    implemented_story_ids: set[str] = set()
    for row in queue_rows:
        story_id = str(row.get("story_id") or "").strip()
        supabase_status = str(supabase_status_by_story_id.get(story_id) or "").strip().lower()
        if supabase_status != "implemented":
            continue
        implemented_story_ids.add(story_id)
        candidates.append(
            {
                "story_queue_id": str(row.get("story_queue_id") or ""),
                "project_id": str(row.get("project_id") or ""),
                "story_id": story_id,
                "title": str(row.get("title") or ""),
                "local_status_before": str(row.get("status") or ""),
                "local_status_after": "completed",
                "supabase_status": supabase_status,
                "claimed_by_worker_id": row.get("claimed_by_worker_id"),
                "claimed_at": row.get("claimed_at"),
                "started_run_id": row.get("started_run_id"),
                "finished_run_id": row.get("finished_run_id"),
            }
        )

    applied_changes: list[dict[str, Any]] = []
    if apply and candidates:
        now = int(time.time())
        touched_story_ids: set[str] = set()
        with store._connect() as conn:
            for row in queue_rows:
                story_id = str(row.get("story_id") or "").strip()
                if story_id not in implemented_story_ids:
                    continue
                story_queue_id = str(row.get("story_queue_id") or "")
                failure_context = row.get("failure_context") if isinstance(row.get("failure_context"), dict) else {}
                failure_context.update(
                    {
                        "suppressed_because_supabase_status": "implemented",
                        "suppressed_from_active_execution_queue": True,
                        "suppressed_at": now,
                    }
                )
                cursor = conn.execute(
                    (
                        "UPDATE story_queue SET status='completed', claimed_by_worker_id=NULL, claimed_at=NULL, "
                        "started_run_id=NULL, finished_run_id=NULL, "
                        "failure_message=?, failure_context_json=?, updated_at=? "
                        "WHERE story_queue_id=? AND status IN ('queued','claimed','in_progress','blocked')"
                    ),
                    (PURGE_NOTE, json.dumps(failure_context, sort_keys=True), now, story_queue_id),
                )
                if int(getattr(cursor, "rowcount", 0) or 0) <= 0:
                    continue
                touched_story_ids.add(story_id)
                applied_changes.append(
                    {
                        "story_queue_id": story_queue_id,
                        "story_id": story_id,
                        "project_id": str(row.get("project_id") or ""),
                        "title": str(row.get("title") or ""),
                    }
                )
        for story_id in sorted(touched_story_ids):
            store.update_story_status(story_id=story_id, status="implemented")

    summary = {
        "active_queue_rows_examined": len(queue_rows),
        "active_story_ids_examined": len(story_ids),
        "supabase_status_rows_found": len(supabase_status_by_story_id),
        "implemented_story_ids_matched": len(implemented_story_ids),
        "queue_rows_to_complete": len(candidates),
        "queue_rows_completed": len(applied_changes),
    }

    return {
        "repo_root": str(repo_root),
        "db_path": str((repo_root / ".devflow" / "execution.sqlite").resolve()),
        "project_id": project_id,
        "apply": apply,
        "summary": summary,
        "candidates": candidates,
        "applied_changes": applied_changes,
        "supabase_status_by_story_id": supabase_status_by_story_id,
        "note": PURGE_NOTE,
    }
