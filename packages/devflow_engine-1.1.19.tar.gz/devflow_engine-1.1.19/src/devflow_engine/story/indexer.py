from __future__ import annotations

import json
import sqlite3
from dataclasses import asdict, dataclass
from pathlib import Path

from .discovery import get_story_source_paths
from .hashing import compute_contract_hash
from .markdown_contracts import ParsedStoryBlock, parse_story_contracts_from_markdown


@dataclass(frozen=True)
class StoryIndexEntry:
    story_uuid: str
    story_id: str
    title: str
    source_path: str
    contract_hash: str


@dataclass(frozen=True)
class StoryIndex:
    entries: list[StoryIndexEntry]

    def to_json_bytes(self) -> bytes:
        payload = {"entries": [asdict(e) for e in self.entries]}
        # Deterministic serialization: sort keys + stable separators.
        return json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode(
            "utf-8"
        )


def _iter_story_blocks(repo_root: Path) -> list[ParsedStoryBlock]:
    blocks: list[ParsedStoryBlock] = []
    for p in get_story_source_paths(repo_root):
        text = p.read_text(encoding="utf-8")
        blocks.extend(parse_story_contracts_from_markdown(text, source_path=str(p)))
    return blocks


def build_story_index(repo_root: Path) -> StoryIndex:
    """Build a deterministic story index from canonical + artifact sources.

    Raises:
        ValueError: on duplicate story_uuid across sources.
    """

    repo_root = Path(repo_root)
    blocks = _iter_story_blocks(repo_root)

    seen_uuid_to_path: dict[str, str] = {}
    entries: list[StoryIndexEntry] = []

    for b in blocks:
        c = b.contract
        if c.story_uuid in seen_uuid_to_path:
            first = seen_uuid_to_path[c.story_uuid]
            raise ValueError(
                f"duplicate story_uuid {c.story_uuid} across sources: {first} and {c.source_path}"
            )
        if c.story_uuid:
            seen_uuid_to_path[c.story_uuid] = c.source_path

        entries.append(
            StoryIndexEntry(
                story_uuid=c.story_uuid,
                story_id=c.story_id,
                title=c.title,
                source_path=c.source_path,
                contract_hash=compute_contract_hash(c.raw_text),
            )
        )

    # Deterministic ordering for downstream tools: sort by story_id then uuid.
    entries_sorted = sorted(entries, key=lambda e: (e.story_id, e.story_uuid, e.source_path))
    return StoryIndex(entries=entries_sorted)


def persist_story_index(db_path: Path, index: StoryIndex) -> None:
    db_path = Path(db_path)
    db_path.parent.mkdir(parents=True, exist_ok=True)

    with sqlite3.connect(db_path) as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS story_index (
              story_uuid TEXT PRIMARY KEY,
              story_id TEXT NOT NULL,
              title TEXT NOT NULL,
              source_path TEXT NOT NULL,
              contract_hash TEXT NOT NULL
            )
            """
        )
        conn.execute("DELETE FROM story_index")

        conn.executemany(
            "INSERT INTO story_index (story_uuid, story_id, title, source_path, contract_hash) VALUES (?, ?, ?, ?, ?)",
            [
                (e.story_uuid, e.story_id, e.title, e.source_path, e.contract_hash)
                for e in index.entries
            ],
        )
        conn.commit()
