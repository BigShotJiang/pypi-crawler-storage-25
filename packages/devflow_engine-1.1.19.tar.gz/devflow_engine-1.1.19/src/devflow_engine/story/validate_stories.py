#!/usr/bin/env python3
"""Deterministic story contract validator for devflow_engine.

Hard gates:
- No silent skips: every canonical story file must contain ≥1 parseable story block.
- Contract formation mode line present (verbatim)
- story_uuid uuid-v4, required_planes valid
- plane_oracles present with 1 entry per required plane
- each plane_oracles item has oracle + anchor
- anchor must match a stable-address allowlist (prefix-based)

Output:
- human-readable diagnostics to stdout
- optional JSON report via --json <path>

Exit codes:
- 0 pass
- 2 validation failed
"""

from __future__ import annotations

import argparse
import json
import re
from dataclasses import asdict, dataclass
from pathlib import Path

from devflow_engine.story.contracts import validate_parsed_story_block
from devflow_engine.story.markdown_contracts import iter_canonical_story_paths, parse_story_contracts_from_markdown


ANCHOR_PREFIX_ALLOWLIST = (
    # UI / routing
    "route:",
    # API contracts
    "api:",
    # Integrations boundary oracles
    "outbox:",
    "audit:",
    # CLI and operational commands (common in devflow_engine stories)
    "cli:",
    "command:",
    # Artifacts and files
    "artifact:",
    "file:",
    # Environment + docs + scripts are legitimate stable anchors in story specs
    "env:",
    "docs:",
    "script:",
)

# Also allow short-form HTTP anchors like: "GET /health" or "POST /api/v1/foo"
HTTP_ANCHOR_RE = re.compile(r"^(GET|POST|PUT|PATCH|DELETE)\s+/\S+")
SCHEME_ANCHOR_RE = re.compile(r"^[a-z][a-z0-9_-]{1,32}:")


@dataclass(frozen=True)
class Issue:
    code: str
    message: str
    path: str


def _anchor_is_allowed(anchor: str) -> bool:
    a = (anchor or "").strip()
    if not a:
        return False
    # Prefer scheme-like anchors (stable, parseable addresses), e.g.
    # cli:..., route:..., api:..., outbox:..., docs:..., tests:...
    if SCHEME_ANCHOR_RE.match(a):
        return True
    # Also allow short-form HTTP anchors like "GET /health".
    if HTTP_ANCHOR_RE.match(a):
        return True
    return False


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo-root", default=".")
    ap.add_argument("--json", default=None, help="Write JSON report to this path")
    args = ap.parse_args()

    repo_root = Path(args.repo_root).resolve()

    issues: list[Issue] = []
    story_count = 0

    for p in iter_canonical_story_paths(repo_root):
        text = p.read_text(encoding="utf-8")
        blocks = parse_story_contracts_from_markdown(text, source_path=str(p))

        if not blocks:
            issues.append(
                Issue(
                    code="no_story_blocks",
                    message="No parseable story blocks found (expected a story_uuid: header). This file would otherwise be silently skipped.",
                    path=str(p),
                )
            )
            continue

        for b in blocks:
            story_count += 1
            contract_issues = validate_parsed_story_block(b)
            for ci in contract_issues:
                issues.append(Issue(code=ci.code, message=ci.message, path=ci.path))

            # Additional deterministic semantic gate: anchor must be stable-address formatted.
            c = b.contract
            for idx, po in enumerate(c.plane_oracles):
                if po.anchor and not _anchor_is_allowed(po.anchor):
                    issues.append(
                        Issue(
                            code="invalid_plane_oracle_anchor_format",
                            message=(
                                f"plane_oracles[{idx}].anchor must be a stable address; "
                                f"allowed prefixes={list(ANCHOR_PREFIX_ALLOWLIST)} or HTTP like 'GET /health'"
                            ),
                            path=f"{c.source_path}:{b.start_line}:plane_oracles[{idx}].anchor",
                        )
                    )

    report = {
        "ok": len(issues) == 0,
        "story_count": story_count,
        "issue_count": len(issues),
        "issues": [asdict(i) for i in issues],
    }

    if args.json:
        Path(args.json).write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    if issues:
        print(f"STORY VALIDATION FAILED: {len(issues)} issue(s) across {story_count} story block(s)")
        # Print up to 200 issues to avoid drowning CI logs.
        for i, iss in enumerate(issues[:200]):
            print(f"- {iss.code}: {iss.path}: {iss.message}")
        if len(issues) > 200:
            print(f"... ({len(issues) - 200} more)")
        return 2

    print(f"STORY VALIDATION OK: {story_count} story block(s)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
