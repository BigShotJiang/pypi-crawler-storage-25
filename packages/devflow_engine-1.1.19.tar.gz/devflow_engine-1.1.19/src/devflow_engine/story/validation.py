from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from .discovery import get_story_source_paths
from .markdown_contracts import MANDATORY_CONTRACT_FORMATION_MODE_LINE, parse_story_contracts_from_markdown
from .markdown_contracts import is_uuid4


@dataclass(frozen=True)
class StoryValidationDiagnostic:
    level: str  # "error" | "warning"
    code: str
    message: str
    path: str


@dataclass(frozen=True)
class StoryValidationResult:
    ok: bool
    diagnostics: list[StoryValidationDiagnostic]


_REQUIRED_HEADER_KEYS: list[str] = ["story_uuid", "story_id", "title", "required_planes"]
_REQUIRED_SECTIONS: list[str] = ["Intent", "Scope", "Acceptance criteria", "Contract test specs"]


def _has_header_key(raw_text: str, key: str) -> bool:
    # Search line-start key with optional whitespace.
    prefix = f"{key}:"
    for ln in raw_text.splitlines():
        if ln.strip().startswith(prefix):
            return True
    return False


def _has_section(raw_text: str, section_name: str) -> bool:
    needle = f"## {section_name}"
    return any(ln.strip() == needle for ln in raw_text.splitlines())


def validate_story_sources(repo_root: Path) -> StoryValidationResult:
    """Validate all story sources in repo.

    Area 4 contract differences vs low-level contract validator:
    - missing plane_oracles is a WARNING (recommended), not a hard error
    - required markdown sections must exist (Intent/Scope/Acceptance criteria/Contract test specs)

    Returns a result object with stable diagnostic codes.
    """

    repo_root = Path(repo_root)
    diags: list[StoryValidationDiagnostic] = []

    for p in get_story_source_paths(repo_root):
        text = p.read_text(encoding="utf-8")
        blocks = parse_story_contracts_from_markdown(text, source_path=str(p))
        if not blocks:
            diags.append(
                StoryValidationDiagnostic(
                    level="error",
                    code="NO_STORY_BLOCKS",
                    message="No story_uuid blocks found in markdown",
                    path=str(p),
                )
            )
            continue

        for b in blocks:
            c = b.contract
            raw = c.raw_text
            base_path = f"{c.source_path}:{b.start_line}"

            # Header keys must be present in source text (not just parse output).
            for k in _REQUIRED_HEADER_KEYS:
                if not _has_header_key(raw, k):
                    diags.append(
                        StoryValidationDiagnostic(
                            level="error",
                            code=f"MISSING_HEADER_KEY:{k}",
                            message=f"Missing required header key: {k}",
                            path=base_path,
                        )
                    )

            # UUID validity
            if c.story_uuid and not is_uuid4(c.story_uuid):
                diags.append(
                    StoryValidationDiagnostic(
                        level="error",
                        code="INVALID_UUID",
                        message="story_uuid must be a uuid-v4 string",
                        path=f"{base_path}:story_uuid",
                    )
                )

            # Contract formation mode line must be present.
            if MANDATORY_CONTRACT_FORMATION_MODE_LINE not in raw:
                diags.append(
                    StoryValidationDiagnostic(
                        level="error",
                        code="MISSING_CONTRACT_FORMATION_MODE_LINE",
                        message="Missing mandatory contract formation mode line",
                        path=base_path,
                    )
                )

            # Required sections
            for sec in _REQUIRED_SECTIONS:
                if not _has_section(raw, sec):
                    diags.append(
                        StoryValidationDiagnostic(
                            level="error",
                            code=f"MISSING_SECTION:{sec}",
                            message=f"Missing required section: {sec}",
                            path=base_path,
                        )
                    )

            # plane_oracles recommended (warning)
            if "plane_oracles:" not in raw:
                diags.append(
                    StoryValidationDiagnostic(
                        level="warning",
                        code="MISSING_RECOMMENDED_FIELD:plane_oracles",
                        message="Recommended field plane_oracles is missing",
                        path=f"{base_path}:plane_oracles",
                    )
                )

    ok = not any(d.level == "error" for d in diags)
    return StoryValidationResult(ok=ok, diagnostics=diags)
