from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

from ..llm.execution_context import get_execution_context


def safe_story_id(story_id: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", str(story_id or "").strip()) or "unknown_story"


def story_dir(*, repo_root: Path, story_id: str) -> Path:
    return _story_state_root(repo_root=repo_root) / safe_story_id(story_id)


def _story_state_root(*, repo_root: Path) -> Path:
    ctx = get_execution_context() or {}
    override = str(ctx.get("devflow_story_state_root") or "").strip()
    if override:
        return Path(override)
    return repo_root / ".devflow" / "stories"


def story_verification_path(*, repo_root: Path, story_id: str) -> Path:
    return story_dir(repo_root=repo_root, story_id=story_id) / "verification.json"


def _load_json_if_exists(path: Path) -> dict[str, Any] | None:
    if not path.exists() or not path.is_file():
        return None
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None
    return payload if isinstance(payload, dict) else None


def load_story_verification(*, repo_root: Path, story_id: str) -> dict[str, Any] | None:
    return _load_json_if_exists(story_verification_path(repo_root=repo_root, story_id=story_id))


def persist_story_verification(*, repo_root: Path, story_id: str, payload: dict[str, Any]) -> Path:
    path = story_verification_path(repo_root=repo_root, story_id=story_id)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return path


def record_story_verification(
    *,
    repo_root: Path,
    story_id: str,
    story_uuid: str | None = None,
    source: str,
    test_paths: list[str] | None = None,
    validator: dict[str, Any] | None = None,
    tests: dict[str, Any] | None = None,
) -> tuple[dict[str, Any], Path]:
    current = load_story_verification(repo_root=repo_root, story_id=story_id) or {}
    canonical_test_paths = [
        str(path).strip() for path in (test_paths or current.get("canonical_test_paths") or []) if str(path).strip()
    ]
    latest_result = {
        "source": str(source or "").strip() or "unknown",
        "story_id": story_id,
        "story_uuid": str(story_uuid or current.get("story_uuid") or "").strip() or None,
        "canonical_test_paths": canonical_test_paths,
        "validator": dict(validator or {}),
        "tests": dict(tests or {}),
    }
    passed = bool(latest_result["validator"].get("ok")) and bool(latest_result["tests"].get("ok"))
    latest_result["passed"] = passed

    payload: dict[str, Any] = {
        "schema_version": 1,
        "story_id": story_id,
        "story_uuid": latest_result["story_uuid"],
        "canonical_test_paths": canonical_test_paths,
        "latest_result": latest_result,
        "latest_passing_verification": current.get("latest_passing_verification"),
    }
    if passed:
        payload["latest_passing_verification"] = latest_result
    path = persist_story_verification(repo_root=repo_root, story_id=story_id, payload=payload)
    return payload, path


def resolve_story_verification_state(*, repo_root: Path, story_id: str) -> dict[str, Any]:
    from ..implementation.test_runtime import load_story_test_runtime_contract, story_test_runtime_contract_path

    runtime_contract = load_story_test_runtime_contract(repo_root=repo_root, story_id=story_id) or {}
    verification = load_story_verification(repo_root=repo_root, story_id=story_id) or {}
    canonical_test_paths = [
        str(path).strip()
        for path in (
            runtime_contract.get("test_paths")
            or verification.get("canonical_test_paths")
            or ((verification.get("latest_result") or {}).get("canonical_test_paths"))
            or []
        )
        if str(path).strip()
    ]
    latest_passing_verification = verification.get("latest_passing_verification")
    return {
        "story_id": story_id,
        "runtime_contract_path": str(story_test_runtime_contract_path(repo_root=repo_root, story_id=story_id)),
        "verification_path": str(story_verification_path(repo_root=repo_root, story_id=story_id)),
        "has_runtime_contract": bool(runtime_contract),
        "has_canonical_test_paths": bool(canonical_test_paths),
        "canonical_test_paths": canonical_test_paths,
        "has_verification_evidence": bool(verification),
        "latest_result": dict(verification.get("latest_result") or {}) if isinstance(verification.get("latest_result"), dict) else None,
        "has_latest_passing_verification": isinstance(latest_passing_verification, dict) and bool(latest_passing_verification),
        "latest_passing_verification": dict(latest_passing_verification or {}) if isinstance(latest_passing_verification, dict) else None,
    }
