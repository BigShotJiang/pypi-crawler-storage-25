from __future__ import annotations

import hashlib


def normalize_for_contract_hash(text: str) -> str:
    """Normalize story markdown for stable contract hashing.

    Policy (tests/spec):
    - Remove UTF-8 BOM if present
    - Normalize newlines to '\n'
    - Trim trailing whitespace per line
    - Ensure exactly one trailing newline
    """

    if text.startswith("\ufeff"):
        text = text.lstrip("\ufeff")

    text = text.replace("\r\n", "\n").replace("\r", "\n")

    lines = [ln.rstrip() for ln in text.split("\n")]
    return "\n".join(lines).rstrip("\n") + "\n"


def compute_contract_hash(text: str) -> str:
    normalized = normalize_for_contract_hash(text)
    return hashlib.sha256(normalized.encode("utf-8")).hexdigest()
