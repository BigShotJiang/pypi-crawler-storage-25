from __future__ import annotations

from pathlib import Path


LEGACY_CANONICAL_STORY_PATH = Path("ai_docs/context/v2/project_docs/user_stories.md")
CANONICAL_STORY_SOURCES_DIR_PATH = Path("ai_docs/context/v2/project_docs/user_stories")
GENERATED_STORY_SOURCES_DIR_PATH = CANONICAL_STORY_SOURCES_DIR_PATH / "generated"
RECONCILED_STORY_DOC_PATH = GENERATED_STORY_SOURCES_DIR_PATH / "_reconciled_story_queue.md"

def _iter_story_markdown_paths(stories_dir: Path) -> list[Path]:
    return sorted(
        [p for p in stories_dir.rglob("*.md") if "/.git/" not in p.as_posix()],
        key=lambda p: p.as_posix(),
    )


def canonical_story_reconciliation_doc_path(repo_root: Path) -> Path:
    repo_root = Path(repo_root)
    legacy = repo_root / LEGACY_CANONICAL_STORY_PATH
    if legacy.exists():
        return legacy
    return repo_root / RECONCILED_STORY_DOC_PATH


def canonical_story_generated_dir(repo_root: Path) -> Path:
    return Path(repo_root) / GENERATED_STORY_SOURCES_DIR_PATH


def get_story_source_paths(repo_root: Path) -> list[Path]:
    """Return deterministic story source paths from the current canonical tree.

    Current truth is the markdown set under ``ai_docs/context/v2/project_docs/user_stories/``.
    ``user_stories.md`` is retained as a legacy compatibility source when it exists.
    """

    repo_root = Path(repo_root)
    legacy = repo_root / LEGACY_CANONICAL_STORY_PATH
    stories_dir = repo_root / CANONICAL_STORY_SOURCES_DIR_PATH
    paths = _iter_story_markdown_paths(stories_dir) if stories_dir.exists() else []

    if legacy.exists():
        return [legacy, *paths]
    if paths:
        return paths

    raise FileNotFoundError(f"{stories_dir} (or legacy {legacy})")
