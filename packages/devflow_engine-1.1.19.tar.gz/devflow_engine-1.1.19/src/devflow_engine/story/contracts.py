from __future__ import annotations

from dataclasses import dataclass

from .markdown_contracts import (
    ALLOWED_PLANES,
    MANDATORY_CONTRACT_FORMATION_MODE_LINE,
    ParsedStoryBlock,
    StoryContract,
    is_uuid4,
)


@dataclass(frozen=True)
class ContractIssue:
    code: str
    message: str
    path: str


def validate_story_contract(contract: StoryContract, *, start_line: int = 1) -> list[ContractIssue]:
    issues: list[ContractIssue] = []

    if not contract.story_uuid:
        issues.append(
            ContractIssue(
                "missing_story_uuid",
                "Story contract must include story_uuid",
                f"{contract.source_path}:{start_line}:story_uuid",
            )
        )
    elif not is_uuid4(contract.story_uuid):
        issues.append(
            ContractIssue(
                "invalid_story_uuid",
                "story_uuid must be a uuid-v4 string",
                f"{contract.source_path}:{start_line}:story_uuid",
            )
        )

    if not contract.story_id:
        issues.append(
            ContractIssue(
                "missing_story_id",
                "Story contract must include story_id",
                f"{contract.source_path}:{start_line}:story_id",
            )
        )

    if not contract.title:
        issues.append(
            ContractIssue(
                "missing_title",
                "Story contract must include title",
                f"{contract.source_path}:{start_line}:title",
            )
        )

    if not contract.required_planes:
        issues.append(
            ContractIssue(
                "missing_required_planes",
                "Story contract must include required_planes",
                f"{contract.source_path}:{start_line}:required_planes",
            )
        )
    else:
        invalid = [p for p in contract.required_planes if p not in ALLOWED_PLANES]
        if invalid:
            issues.append(
                ContractIssue(
                    "invalid_required_planes",
                    f"required_planes contains invalid plane(s): {invalid}; allowed={ALLOWED_PLANES}",
                    f"{contract.source_path}:{start_line}:required_planes",
                )
            )

    if not contract.contract_formation_mode_line_present:
        issues.append(
            ContractIssue(
                "missing_contract_formation_mode",
                f"Story must include mandatory line: {MANDATORY_CONTRACT_FORMATION_MODE_LINE}",
                f"{contract.source_path}:{start_line}",
            )
        )

    if not contract.plane_oracles:
        issues.append(
            ContractIssue(
                "missing_plane_oracles",
                "Story must include plane_oracles list block",
                f"{contract.source_path}:{start_line}:plane_oracles",
            )
        )
        return issues

    # Validate one entry per required plane
    seen: dict[str, int] = {}
    for idx, po in enumerate(contract.plane_oracles):
        if not po.plane:
            issues.append(
                ContractIssue(
                    "invalid_plane_oracle_plane",
                    "plane_oracles item missing plane",
                    f"{contract.source_path}:{start_line}:plane_oracles[{idx}].plane",
                )
            )
            continue
        seen[po.plane] = seen.get(po.plane, 0) + 1
        if not po.oracle:
            issues.append(
                ContractIssue(
                    "invalid_plane_oracle_oracle",
                    "plane_oracles item missing oracle",
                    f"{contract.source_path}:{start_line}:plane_oracles[{idx}].oracle",
                )
            )
        if not po.anchor:
            issues.append(
                ContractIssue(
                    "invalid_plane_oracle_anchor",
                    "plane_oracles item missing anchor",
                    f"{contract.source_path}:{start_line}:plane_oracles[{idx}].anchor",
                )
            )

    missing = [p for p in contract.required_planes if seen.get(p, 0) == 0]
    dupes = [p for p, n in seen.items() if n > 1]
    extra = [p for p in seen if p not in contract.required_planes]

    if missing:
        issues.append(
            ContractIssue(
                "missing_plane_oracles_for_required_planes",
                f"Missing plane_oracles entries for required_planes: {missing}",
                f"{contract.source_path}:{start_line}:plane_oracles",
            )
        )
    if dupes:
        issues.append(
            ContractIssue(
                "duplicate_plane_oracles",
                f"Duplicate plane_oracles entries for plane(s): {dupes}",
                f"{contract.source_path}:{start_line}:plane_oracles",
            )
        )
    if extra:
        issues.append(
            ContractIssue(
                "extra_plane_oracles",
                f"plane_oracles contains plane(s) not in required_planes: {extra}",
                f"{contract.source_path}:{start_line}:plane_oracles",
            )
        )

    return issues


def validate_parsed_story_block(block: ParsedStoryBlock) -> list[ContractIssue]:
    return validate_story_contract(block.contract, start_line=block.start_line)
