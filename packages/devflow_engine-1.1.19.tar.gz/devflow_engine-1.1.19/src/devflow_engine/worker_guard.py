from __future__ import annotations

import os
import signal
from dataclasses import dataclass
from pathlib import Path
from typing import Any

try:  # pragma: no cover - python 3.11+
    import tomllib
except Exception:  # pragma: no cover
    tomllib = None  # type: ignore


_TRUE_VALUES = {"1", "true", "yes", "on"}
_FALSE_VALUES = {"0", "false", "no", "off"}


@dataclass(frozen=True)
class WorkerGuardBlock:
    reason: str
    source: str


class WorkerGuardEnabledError(RuntimeError):
    def __init__(self, block: WorkerGuardBlock):
        self.block = block
        super().__init__(block.reason)


def _global_devflow_dir() -> Path:
    home = os.environ.get("DEVFLOW_HOME")
    if home:
        return Path(home).expanduser() / ".devflow"
    return Path.home() / ".devflow"


def _read_toml(path: Path) -> dict[str, object]:
    if tomllib is None or not path.exists():
        return {}
    try:
        with path.open("rb") as fh:
            data = tomllib.load(fh)
    except Exception:
        return {}
    return data if isinstance(data, dict) else {}


def _nested_get(data: dict[str, object], *keys: str) -> object | None:
    cur: object = data
    for key in keys:
        if not isinstance(cur, dict):
            return None
        cur = cur.get(key)
    return cur


def _parse_bool(value: object) -> bool | None:
    if isinstance(value, bool):
        return value
    if value is None:
        return None
    text = str(value).strip().lower()
    if not text:
        return True
    if text in _TRUE_VALUES:
        return True
    if text in _FALSE_VALUES:
        return False
    return None


def _flag_file_enabled(path: Path) -> bool:
    if not path.exists():
        return False
    try:
        raw = path.read_text(encoding="utf-8").strip()
    except Exception:
        return True
    parsed = _parse_bool(raw)
    return True if parsed is None else parsed


def get_worker_guard_block(*, repo_root: Path | None) -> WorkerGuardBlock | None:
    env_value = _parse_bool(os.environ.get("DEVFLOW_DO_NOT_RUN_WORKER"))
    if env_value is True:
        return WorkerGuardBlock(
            reason="Worker start is disabled by DEVFLOW_DO_NOT_RUN_WORKER.",
            source="env:DEVFLOW_DO_NOT_RUN_WORKER",
        )

    global_devflow_dir = _global_devflow_dir()
    global_flag_path = global_devflow_dir / "do-not-run-worker"
    if _flag_file_enabled(global_flag_path):
        return WorkerGuardBlock(
            reason="Worker start is disabled by global flag file ~/.devflow/do-not-run-worker.",
            source=str(global_flag_path),
        )

    global_cfg = _read_toml(global_devflow_dir / "config.toml")
    global_cfg_value = _parse_bool(_nested_get(global_cfg, "worker", "do_not_run"))
    if global_cfg_value is True:
        return WorkerGuardBlock(
            reason="Worker start is disabled by global config worker.do_not_run=true.",
            source=str(global_devflow_dir / "config.toml"),
        )

    if repo_root is None:
        return None

    repo_root = repo_root.expanduser().resolve()
    project_flag_path = repo_root / ".devflow" / "do-not-run-worker"
    if _flag_file_enabled(project_flag_path):
        return WorkerGuardBlock(
            reason=f"Worker start is disabled by project flag file {project_flag_path}.",
            source=str(project_flag_path),
        )

    project_cfg_path = repo_root / ".devflow" / "config.toml"
    project_cfg = _read_toml(project_cfg_path)
    project_cfg_value = _parse_bool(_nested_get(project_cfg, "worker", "do_not_run"))
    if project_cfg_value is True:
        return WorkerGuardBlock(
            reason=f"Worker start is disabled by project config worker.do_not_run=true in {project_cfg_path}.",
            source=str(project_cfg_path),
        )

    return None


def ensure_worker_start_allowed(*, repo_root: Path | None) -> None:
    block = get_worker_guard_block(repo_root=repo_root)
    if block is not None:
        raise WorkerGuardEnabledError(block)


def _check_no_running_worker_process(
    *, repo_root: Path, project_id: str, role: str | None = None,
) -> WorkerGuardBlock | None:
    """Check if a live worker process is already running for this project.

    Role-aware blocking semantics:
    - role=None ('both'): block if ANY worker is running (legacy).
    - role='fix': block if another 'fix' or 'both' worker is running
      (workspace edits can't safely interleave).
    - role='analyst': block ONLY if a 'both' worker is running.
      Multiple analyst processes are allowed (pool semantics) — they
      serialize at the per-row claim level, not at the process level.

    Returns a WorkerGuardBlock if a conflicting worker is found and
    confirmed alive. Stale DB rows (dead PIDs) are cleaned up
    in-place and return None.
    """
    import re
    import sqlite3
    import subprocess
    import time

    repo_root = repo_root.expanduser().resolve()
    db_path = repo_root / ".devflow" / "execution.sqlite"
    if not db_path.exists():
        return None

    try:
        conn = sqlite3.connect(db_path)
        conn.row_factory = sqlite3.Row
    except Exception:
        return None

    try:
        now = int(time.time())
        rows = conn.execute(
            (
                "SELECT worker_id, status, active_queue_type, active_item_id, updated_at "
                "FROM project_workers "
                "WHERE project_id=? AND status='running'"
            ),
            (project_id,),
        ).fetchall()

        if not rows:
            return None

        # Resolve project path to check against running process cmdlines
        resolved_repo = str(repo_root.resolve())

        # ps aux output to find running devflow worker processes
        try:
            ps_output = subprocess.check_output(
                ["ps", "aux"], text=True, stderr=subprocess.DEVNULL
            )
        except Exception:
            ps_output = ""

        for line in ps_output.splitlines():
            if "devflow worker start" not in line:
                continue
            # Extract PID (field 1 in ps aux)
            parts = line.split()
            if len(parts) < 2:
                continue
            try:
                pid = int(parts[1])
            except ValueError:
                continue
            # Check if this process is still alive (signal 0)
            try:
                os.kill(pid, 0)
            except (OSError, ValueError):
                # Process is dead — clean up stale DB row
                stale_ids = [r["worker_id"] for r in rows if r["worker_id"] == str(pid)]
                for wid in stale_ids:
                    conn.execute(
                        "UPDATE project_workers SET status='stopped', stopped_at=?, updated_at=? "
                        "WHERE worker_id=?",
                        (now, now, wid),
                    )
                conn.commit()
                continue
            # Check if it matches our project path
            if resolved_repo not in line:
                continue

            # Detect the running process's role from its cmdline.
            # Format: `... devflow worker start --project ... [--role analyst|fix]`
            if "--role analyst" in line:
                running_role: str | None = "analyst"
            elif "--role fix" in line:
                running_role = "fix"
            else:
                running_role = None  # 'both' (legacy)

            # Apply role-aware blocking rules.
            # incoming role | running role | block?
            # ---------------------------------------
            # None (both)   | anything     | YES (legacy)
            # fix           | fix or None  | YES (workspace edit conflict)
            # fix           | analyst      | NO  (analyst can't write code)
            # analyst       | None (both)  | YES ('both' might be fixing)
            # analyst       | analyst      | NO  (pool — multiple OK)
            # analyst       | fix          | NO  (independent rows)
            should_block = False
            if role is None:
                should_block = True
            elif role == "fix" and running_role in (None, "fix"):
                should_block = True
            elif role == "analyst" and running_role is None:
                should_block = True

            if should_block:
                row = rows[0]
                return WorkerGuardBlock(
                    reason=(
                        f"A worker process (PID {pid}, role={running_role or 'both'}) "
                        f"is already running for this project and is currently handling "
                        f"queue_type={row['active_queue_type']!r}, "
                        f"item_id={row['active_item_id']!r}. "
                        f"Requested role={role or 'both'}."
                    ),
                    source=f"process:PID={pid}",
                )

        # No alive process found matching this project — clean up all stale rows
        for row in rows:
            conn.execute(
                "UPDATE project_workers SET status='stopped', stopped_at=?, updated_at=? "
                "WHERE worker_id=?",
                (now, now, row["worker_id"]),
            )
        conn.commit()
        return None
    finally:
        conn.close()
