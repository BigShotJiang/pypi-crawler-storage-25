from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field


CoverageStatus = Literal["pass", "pass_with_assumptions", "revise", "escalate"]
ResolutionStatus = Literal["ready_for_review", "needs_revision"]
SourceType = Literal["transcript", "doc", "repo", "image", "notes", "design", "unknown"]


class SourceRef(BaseModel):
    type: str
    path: str | None = None
    title: str | None = None
    text: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class SourceInventoryItem(BaseModel):
    source_id: str
    source_type: SourceType
    location: str
    title: str
    content_ref: str
    ingest_status: str
    priority: int = 50
    notes: list[str] = Field(default_factory=list)


class SourceInventoryArtifact(BaseModel):
    project_id: str
    source_intake_id: str
    sources: list[SourceInventoryItem] = Field(default_factory=list)
    inventory_summary: str
    missing_expected_sources: list[str] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)


class AssumptionLedgerItem(BaseModel):
    question: str
    assumed_answer: str
    basis: str
    confidence: str
    needs_confirmation: bool = True


class LineageRef(BaseModel):
    source_id: str
    ref: str
    summary: str | None = None


class NormalizedSourcePacketArtifact(BaseModel):
    project_id: str
    source_inventory_ref: str
    facts: list[str] = Field(default_factory=list)
    source_stated_assumptions: list[str] = Field(default_factory=list)
    open_questions_with_assumptions: list[AssumptionLedgerItem] = Field(default_factory=list)
    contradictions: list[str] = Field(default_factory=list)
    confidence_notes: list[str] = Field(default_factory=list)
    source_summary: str
    domain_summary: str
    lineage: list[LineageRef] = Field(default_factory=list)


class ScopeCandidateArtifactItem(BaseModel):
    candidate_id: str
    title: str
    description: str
    source_support: list[str] = Field(default_factory=list)
    support_strength: str = "medium"
    explicit_or_inferred: Literal["explicit", "inferred"] = "explicit"
    candidate_kind: Literal["product_scope", "migration_scope", "cross_cutting_constraint"] = "product_scope"
    assumptions: list[str] = Field(default_factory=list)
    notes: list[str] = Field(default_factory=list)


class ScopeCandidatesArtifact(BaseModel):
    project_id: str
    source_packet_ref: str
    scope_candidates: list[ScopeCandidateArtifactItem] = Field(default_factory=list)
    candidate_gaps: list[str] = Field(default_factory=list)
    candidate_overlap_notes: list[str] = Field(default_factory=list)
    extraction_notes: list[str] = Field(default_factory=list)


class ScopeOutlineItem(BaseModel):
    scope_id: str
    title: str
    description: str
    rationale: str
    source_support: list[str] = Field(default_factory=list)
    assumptions: list[str] = Field(default_factory=list)
    depends_on: list[str] = Field(default_factory=list)
    review_status: str = "draft"


class ScopeOutlineArtifact(BaseModel):
    project_id: str
    scope_set_id: str
    scope_set_title: str
    project_summary: str
    scope_items: list[ScopeOutlineItem] = Field(default_factory=list)
    migration_scope_items: list[ScopeOutlineItem] = Field(default_factory=list)
    out_of_scope: list[str] = Field(default_factory=list)
    cross_cutting_constraints: list[str] = Field(default_factory=list)
    review_notes: list[str] = Field(default_factory=list)
    assumptions_ledger: list[AssumptionLedgerItem] = Field(default_factory=list)


class ScopeCoverageReportArtifact(BaseModel):
    coverage_status: CoverageStatus
    covered_requirements: list[str] = Field(default_factory=list)
    weakly_covered_requirements: list[str] = Field(default_factory=list)
    uncovered_requirements: list[str] = Field(default_factory=list)
    over_consolidated_scope_items: list[str] = Field(default_factory=list)
    unsupported_inferred_scope_items: list[str] = Field(default_factory=list)
    review_recommendations: list[str] = Field(default_factory=list)
    gate_reasons: list[str] = Field(default_factory=list)
    gate_metrics: dict[str, Any] = Field(default_factory=dict)


class CoverageDecisionArtifact(BaseModel):
    decision: CoverageStatus
    reason: str
    next_node: str


class RegisteredScopeItemArtifact(BaseModel):
    scope_id: str
    registry_ref: str
    status: str
    source_traceability_refs: list[str] = Field(default_factory=list)


class ScopeRegistryRecordArtifact(BaseModel):
    project_id: str
    scope_set_id: str
    registered_scope_items: list[RegisteredScopeItemArtifact] = Field(default_factory=list)
    coverage_status: CoverageStatus
    run_id: str
    registration_timestamp: str
    scope_set_registry_ref: str | None = None


class ApprovalReadyPackageArtifact(BaseModel):
    project_id: str
    scope_set_id: str
    scope_summary: str
    scope_items_for_review: list[dict[str, Any]] = Field(default_factory=list)
    key_assumptions_to_confirm: list[str] = Field(default_factory=list)
    known_open_questions: list[str] = Field(default_factory=list)
    coverage_status: CoverageStatus
    recommended_next_action: str
    downstream_ready_if_approved: str | bool = True
    scope_registry_record_ref: str | None = None


class ScopeRevisionPackageArtifact(BaseModel):
    project_id: str
    scope_set_id: str | None = None
    proposed_status: str
    major_gaps: list[str] = Field(default_factory=list)
    unsupported_items: list[str] = Field(default_factory=list)
    recommended_revision_actions: list[str] = Field(default_factory=list)
    manual_review_questions: list[str] = Field(default_factory=list)
    coverage_status: CoverageStatus | None = None


class SourceScopeDagSummary(BaseModel):
    exit_code: int
    run_id: str
    pipeline_dir: str
    message: str
    outcome: dict[str, Any]
