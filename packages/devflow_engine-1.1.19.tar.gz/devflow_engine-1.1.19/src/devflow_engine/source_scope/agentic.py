from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from pydantic import BaseModel

from ..agentic_prompts import load_agentic_prompt_lines
from ..agentic_runtime import AgentRunEnvelope, run_agent_step


SOURCE_SCOPE_DOCTRINE = load_agentic_prompt_lines("source_scope_doctrine")


def run_source_scope_agent_step(
    *,
    repo_root: Path,
    stage_name: str,
    output_model: type[BaseModel],
    context_payload: dict[str, Any],
    guidance: list[str],
    timeout_seconds: int | None = None,
) -> tuple[BaseModel, AgentRunEnvelope]:
    return run_agent_step(
        repo_root=repo_root,
        stage_name=f"source_scope_{stage_name}",
        output_model=output_model,
        context_payload=context_payload,
        guidance=SOURCE_SCOPE_DOCTRINE + guidance,
        timeout_seconds=timeout_seconds,
    )


def persist_agent_run(*, pipeline_root: Path, node_id: str, envelope: AgentRunEnvelope) -> Path:
    path = pipeline_root / f"{node_id}_agent_run.json"
    payload = {
        "node_id": node_id,
        "prompt": envelope.prompt,
        "response": envelope.response,
        "raw_stdout": envelope.raw_stdout,
        "raw_stderr": envelope.raw_stderr,
    }
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return path
