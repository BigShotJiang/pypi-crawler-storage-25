from __future__ import annotations

"""Deterministic domain name normalization.

Goal: reduce taxonomy entropy without requiring a human in the loop.

Rules:
- slugify (lowercase, hyphens)
- apply small synonym map (config->configuration, etc.)
- collapse trivial plurals/singulars (contract/contracts)

This is intentionally conservative.
"""

import re


_SYNONYMS: dict[str, str] = {
    "config": "configuration",
    "configs": "configuration",
    "configuration": "configuration",
    "planning": "planning",
    "plan": "planning",
    "plans": "planning",
    "validate": "validation",
    "validations": "validation",
    "validation": "validation",
    "contract": "contracts",
    "contracts": "contracts",
    "testing": "testing",
    "test": "testing",
    "tests": "testing",
    "workflow": "workflow",
}


def slugify_domain(name: str) -> str:
    s = (name or "").strip().lower()
    s = s.replace("_", "-")
    s = re.sub(r"[^a-z0-9-]+", "-", s)
    s = re.sub(r"-+", "-", s).strip("-")
    return s


def normalize_domain(name: str) -> str:
    s = slugify_domain(name)
    if not s:
        return "unknown"

    # Direct synonym
    if s in _SYNONYMS:
        return _SYNONYMS[s]

    # Singular/plural fold for simple cases.
    if s.endswith("s") and s[:-1] in _SYNONYMS:
        return _SYNONYMS[s[:-1]]
    if (s + "s") in _SYNONYMS:
        return _SYNONYMS[s + "s"]

    return s
