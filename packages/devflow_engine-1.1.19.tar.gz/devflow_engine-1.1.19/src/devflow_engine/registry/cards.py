from __future__ import annotations

import json
import re
from collections import Counter, defaultdict
from dataclasses import dataclass
from pathlib import Path


_TS_EXPORT_RE = re.compile(
    r"^\s*export\s+(?:default\s+)?(?:(?:async\s+)?function\s+(?P<fn>[A-Za-z_\$][\w\$]*)|class\s+(?P<class>[A-Za-z_\$][\w\$]*)|const\s+(?P<const>[A-Za-z_\$][\w\$]*)|let\s+(?P<let>[A-Za-z_\$][\w\$]*)|var\s+(?P<var>[A-Za-z_\$][\w\$]*)|type\s+(?P<type>[A-Za-z_\$][\w\$]*)|interface\s+(?P<iface>[A-Za-z_\$][\w\$]*))\b"
)

_TS_EXPORT_LIST_RE = re.compile(r"^\s*export\s*\{(?P<body>[^}]+)\}\s*;?\s*$")

_PY_DEF_RE = re.compile(r"^def\s+(?P<fn>[A-Za-z_][\w]*)\s*\(")
_PY_CLASS_RE = re.compile(r"^class\s+(?P<class>[A-Za-z_][\w]*)\s*(\(|:)")


@dataclass(frozen=True)
class ExportSymbol:
    name: str
    kind: str  # function|class|const|type|interface|reexport


def _iter_project_files(repo_root: Path, roots: list[Path]) -> list[Path]:
    exts = {".ts", ".tsx", ".js", ".jsx", ".py"}

    ignore_dirnames = {
        "node_modules",
        ".next",
        "dist",
        "build",
        "coverage",
        ".turbo",
        ".git",
        ".venv",
        "__pycache__",
    }

    import os

    out: list[Path] = []
    for r in roots:
        if not r.exists():
            continue
        for dirpath, dirnames, filenames in os.walk(r):
            dirnames[:] = [d for d in dirnames if d not in ignore_dirnames and not d.startswith(".")]
            for fn in filenames:
                p = Path(dirpath) / fn
                if p.suffix in exts:
                    out.append(p)
    return sorted(out)


def extract_exports(path: Path) -> list[ExportSymbol]:
    """Best-effort export extraction.

    Deterministic + cheap; not a full parser.
    """

    try:
        lines = path.read_text(encoding="utf-8").splitlines()
    except Exception:
        return []

    out: list[ExportSymbol] = []

    if path.suffix == ".py":
        for ln in lines:
            if ln.startswith(" ") or ln.startswith("\t"):
                continue
            if m := _PY_DEF_RE.match(ln):
                out.append(ExportSymbol(name=m.group("fn"), kind="function"))
            elif m := _PY_CLASS_RE.match(ln):
                out.append(ExportSymbol(name=m.group("class"), kind="class"))
        return out

    # TS/JS
    for ln in lines:
        if m := _TS_EXPORT_RE.match(ln):
            for kind, key in [
                ("function", "fn"),
                ("class", "class"),
                ("const", "const"),
                ("const", "let"),
                ("const", "var"),
                ("type", "type"),
                ("interface", "iface"),
            ]:
                name = m.groupdict().get(key)
                if name:
                    out.append(ExportSymbol(name=name, kind=kind))
                    break
            continue

        if m := _TS_EXPORT_LIST_RE.match(ln):
            body = m.group("body")
            parts = [p.strip() for p in body.split(",") if p.strip()]
            for p in parts:
                # handle `a as b`
                name = p.split(" as ")[-1].strip()
                if name:
                    out.append(ExportSymbol(name=name, kind="reexport"))

    # stable
    out.sort(key=lambda s: (s.kind, s.name))
    return out


def make_module_card(
    *,
    repo_root: Path,
    importer_rel: str,
    specifier: str,
    export_symbols: list[ExportSymbol],
    used_by: list[str],
    snippets: list[str],
    external_packages: list[str],
    internal_deps: list[str],
) -> dict[str, object]:
    return {
        "item_id": f"module:{importer_rel}",
        "path": importer_rel,
        "exports": [s.__dict__ for s in export_symbols],
        "usage": {
            "importer_count": len(used_by),
            "top_importers": used_by,
            "snippets": snippets,
        },
        "imports": {
            "external_packages": external_packages,
            "internal_modules": internal_deps,
        },
        "heuristic_summary": {
            "export_count": len(export_symbols),
            "external_pkg_count": len(external_packages),
            "internal_dep_count": len(internal_deps),
            "used_by_count": len(used_by),
        },
    }


def extract_import_snippets(*, text: str, needle: str, context: int = 2, limit: int = 3) -> list[str]:
    lines = text.splitlines()
    out: list[str] = []
    for i, ln in enumerate(lines):
        if needle not in ln:
            continue
        start = max(0, i - context)
        end = min(len(lines), i + context + 1)
        snippet = "\n".join(lines[start:end])
        out.append(snippet)
        if len(out) >= limit:
            break
    return out


def build_module_cards(
    *,
    repo_root: Path,
    roots: list[Path],
    imports_rows: list[tuple[str, str, str, str]],
    usage_snippet_limit: int = 3,
) -> list[dict[str, object]]:
    """Build module cards for internal modules and their usage.

    imports_rows matches schema: (importer, specifier, kind, resolved_id).
    """

    # Build reverse index: resolved_id -> list[(importer, specifier)]
    used_by: dict[str, list[tuple[str, str]]] = defaultdict(list)
    for importer, spec, kind, resolved in imports_rows:
        if kind != "internal":
            continue
        used_by[str(resolved)].append((str(importer), str(spec)))

    # Build per-file imports summary
    per_importer_external: dict[str, Counter[str]] = defaultdict(Counter)
    per_importer_internal: dict[str, Counter[str]] = defaultdict(Counter)
    for importer, spec, kind, resolved in imports_rows:
        if kind == "external":
            pkg = str(resolved).split(":", 1)[1]
            per_importer_external[str(importer)][pkg] += 1
        elif kind == "internal":
            per_importer_internal[str(importer)][str(resolved)] += 1

    cards: list[dict[str, object]] = []
    for p in _iter_project_files(repo_root, roots):
        rel = p.relative_to(repo_root).as_posix()
        rel_no_ext = re.sub(r"\.[a-zA-Z0-9]+$", "", rel)
        item_id = f"module:{rel_no_ext}"

        exports = extract_exports(p)

        # usage (where used)
        importers = sorted({imp for (imp, _spec) in used_by.get(item_id, [])})
        importers_top = importers[:10]

        snippets: list[str] = []
        for imp, spec in used_by.get(item_id, [])[:50]:
            imp_path = repo_root / imp
            if not imp_path.exists():
                continue
            try:
                text = imp_path.read_text(encoding="utf-8")
            except Exception:
                continue
            snippets.extend(extract_import_snippets(text=text, needle=spec, limit=usage_snippet_limit))
            if len(snippets) >= usage_snippet_limit:
                snippets = snippets[:usage_snippet_limit]
                break

        external_pkgs = sorted(per_importer_external.get(rel, Counter()).keys())
        internal_mods = sorted({rid for rid in per_importer_internal.get(rel, Counter()).keys()})

        cards.append(
            make_module_card(
                repo_root=repo_root,
                importer_rel=rel_no_ext,
                specifier="",
                export_symbols=exports,
                used_by=importers_top,
                snippets=snippets,
                external_packages=external_pkgs,
                internal_deps=internal_mods,
            )
        )

    cards.sort(key=lambda c: str(c.get("path") or ""))
    return cards


def write_cards_jsonl(cards: list[dict[str, object]], out_path: Path) -> None:
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with out_path.open("w", encoding="utf-8") as f:
        for c in cards:
            f.write(json.dumps(c, sort_keys=True) + "\n")
