"""Registry helpers (module cards + package policy gate)."""
