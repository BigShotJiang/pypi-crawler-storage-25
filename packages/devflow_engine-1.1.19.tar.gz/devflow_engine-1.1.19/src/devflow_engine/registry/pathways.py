from __future__ import annotations

"""Pathway ("module card") detector.

This is a lightweight, deterministic analyzer over the internal import graph.

Design goals:
- general signals only (graph structure + optional signatures)
- stable output ordering
- easy to test against synthetic graphs

It is *not* a policy enforcer.
"""

from dataclasses import dataclass
from typing import Iterable


@dataclass(frozen=True)
class ModuleSignals:
    module_id: str
    in_degree: int
    out_degree: int
    importers: tuple[str, ...]
    internal_deps: tuple[str, ...]
    exports: tuple[str, ...]
    external_pkgs: tuple[str, ...]


def _jaccard(a: set[str], b: set[str]) -> float:
    if not a and not b:
        return 1.0
    if not a or not b:
        return 0.0
    return len(a & b) / len(a | b)


def _stable_sorted(xs: Iterable[str]) -> list[str]:
    return sorted({str(x) for x in xs if str(x)})


def build_module_graph(
    *,
    imports_rows: list[tuple[str, str, str, str]],
    module_exports: dict[str, list[str]] | None = None,
    module_external_pkgs: dict[str, list[str]] | None = None,
) -> dict[str, ModuleSignals]:
    """Build per-module signals from imports rows.

    imports_rows schema: (importer, specifier, kind, resolved_id)
    - importer is a file path (repo-relative)
    - resolved_id for internal modules is the module item_id (e.g. module:src/x)

    module_exports/module_external_pkgs are optional signature maps keyed by module_id.
    """

    module_exports = module_exports or {}
    module_external_pkgs = module_external_pkgs or {}

    importers: dict[str, set[str]] = {}
    deps: dict[str, set[str]] = {}

    # Initialize keys for any module we see.
    for importer, _spec, kind, resolved_id in imports_rows:
        if kind != "internal":
            continue
        resolved = str(resolved_id)
        importers.setdefault(resolved, set()).add(str(importer))
        # Track deps per importing module if importer itself is a module id.

    # Build deps by mapping importer file path -> module id form if present.
    # For synthetic tests we allow importer to already be a module id.
    for importer, _spec, kind, resolved_id in imports_rows:
        if kind != "internal":
            continue
        importer_s = str(importer)
        if importer_s.startswith("module:"):
            importer_id = importer_s
        else:
            # best-effort normalization: treat as module:<path-without-ext>
            importer_id = "module:" + importer_s.rsplit(".", 1)[0]
        deps.setdefault(importer_id, set()).add(str(resolved_id))
        importers.setdefault(importer_id, importers.get(importer_id, set()))

    out: dict[str, ModuleSignals] = {}
    for mid in sorted(set(importers.keys()) | set(deps.keys())):
        imp = importers.get(mid, set())
        d = deps.get(mid, set())
        exp = _stable_sorted(module_exports.get(mid, []))
        pkgs = _stable_sorted(module_external_pkgs.get(mid, []))
        out[mid] = ModuleSignals(
            module_id=mid,
            in_degree=len(imp),
            out_degree=len(d),
            importers=tuple(sorted(imp)),
            internal_deps=tuple(sorted(d)),
            exports=tuple(exp),
            external_pkgs=tuple(pkgs),
        )

    return out


def _reachable(
    g: dict[str, ModuleSignals], start: str, target: str, *, max_depth: int = 6
) -> bool:
    if start == target:
        return True
    seen: set[str] = set()
    stack: list[tuple[str, int]] = [(start, 0)]
    while stack:
        cur, depth = stack.pop()
        if cur == target:
            return True
        if cur in seen:
            continue
        seen.add(cur)
        if depth >= max_depth:
            continue
        for nxt in g.get(cur).internal_deps if g.get(cur) else []:
            if nxt not in seen:
                stack.append((nxt, depth + 1))
    return False


def detect_pathways(
    *,
    imports_rows: list[tuple[str, str, str, str]],
    module_exports: dict[str, list[str]] | None = None,
    module_external_pkgs: dict[str, list[str]] | None = None,
    module_effect_tokens: dict[str, list[str]] | None = None,
    min_hub_in_degree: int = 2,
    max_hubs: int = 5000,
    competing_importer_jaccard: float = 0.65,
    competing_export_jaccard: float = 0.40,
    overlap_effect_jaccard: float = 0.6,
) -> dict[str, object]:
    """Detect seam candidates + competing seams.

    Output is stable + deterministic.

    Heuristics:
    - hub seam: in_degree >= min_hub_in_degree
    - orchestrator seam: imports multiple internal deps AND depends on at least one hub
    - competing seams: hubs that share importer neighborhoods + (optionally) export signature
    """

    g = build_module_graph(
        imports_rows=imports_rows,
        module_exports=module_exports,
        module_external_pkgs=module_external_pkgs,
    )

    module_effect_tokens = module_effect_tokens or {}

    # Seam candidates
    hubs = [s for s in g.values() if s.in_degree >= int(min_hub_in_degree)]
    hubs.sort(key=lambda s: (-s.in_degree, s.module_id))
    hubs = hubs[: max(0, int(max_hubs))]
    hub_ids = {h.module_id for h in hubs}

    seams: list[dict[str, object]] = []

    for h in hubs:
        seams.append(
            {
                "kind": "hub",
                "module_id": h.module_id,
                "score": float(h.in_degree),
                "evidence": {
                    "in_degree": h.in_degree,
                    "out_degree": h.out_degree,
                    "top_importers": list(h.importers)[:10],
                },
            }
        )

    # Orchestrators: modules that fan out to multiple internal modules (esp hubs)
    # and are themselves used (in_degree>0).
    for s in g.values():
        if s.out_degree < 2 or s.in_degree < 1:
            continue
        dep_hubs = [d for d in s.internal_deps if d in hub_ids]
        if not dep_hubs:
            continue
        # Score: fanout weighted by hub-ness.
        score = 0.0
        for d in dep_hubs:
            score += float(g.get(d).in_degree if g.get(d) else 0)
        score = score + 0.1 * float(s.out_degree)
        seams.append(
            {
                "kind": "orchestrator",
                "module_id": s.module_id,
                "score": float(score),
                "evidence": {
                    "in_degree": s.in_degree,
                    "out_degree": s.out_degree,
                    "hub_deps": sorted(dep_hubs),
                },
            }
        )

    seams.sort(key=lambda r: (-float(r.get("score") or 0.0), str(r.get("kind")), str(r.get("module_id"))))

    # Competing seams among hubs
    competing: list[dict[str, object]] = []
    for i in range(len(hubs)):
        a = hubs[i]
        a_imps = set(a.importers)
        a_exp = set(a.exports)
        for j in range(i + 1, len(hubs)):
            b = hubs[j]
            b_imps = set(b.importers)
            sim_imp = _jaccard(a_imps, b_imps)
            if sim_imp < float(competing_importer_jaccard):
                continue

            # Export similarity is optional; if neither has exports, treat as neutral.
            b_exp = set(b.exports)
            sim_exp = _jaccard(a_exp, b_exp) if (a_exp or b_exp) else 1.0
            if sim_exp < float(competing_export_jaccard):
                continue

            competing.append(
                {
                    "a": a.module_id,
                    "b": b.module_id,
                    "similarity": {
                        "importers_jaccard": round(sim_imp, 4),
                        "exports_jaccard": round(sim_exp, 4),
                    },
                    "evidence": {
                        "a_in_degree": a.in_degree,
                        "b_in_degree": b.in_degree,
                        "shared_importers": sorted(a_imps & b_imps)[:12],
                    },
                }
            )

    competing.sort(key=lambda r: (-float(r["similarity"]["importers_jaccard"]), str(r["a"]), str(r["b"])))

    # Effect-signature overlaps.
    # We consider any module that has effect tokens (not just detected seams),
    # to avoid "missing" layered overlaps when the modules aren't hubs/orchestrators.
    seam_ids = sorted({
        *[str(s.get("module_id")) for s in seams if isinstance(s, dict) and s.get("module_id")],
        *[str(k) for k, v in module_effect_tokens.items() if v],
    })

    overlaps: list[dict[str, object]] = []
    for i in range(len(seam_ids)):
        a = seam_ids[i]
        a_tok = set(module_effect_tokens.get(a, []))
        if not a_tok:
            continue
        for j in range(i + 1, len(seam_ids)):
            b = seam_ids[j]
            b_tok = set(module_effect_tokens.get(b, []))
            if not b_tok:
                continue
            sim = _jaccard(a_tok, b_tok)
            if sim < float(overlap_effect_jaccard):
                continue

            layered = _reachable(g, a, b) or _reachable(g, b, a)
            overlaps.append(
                {
                    "a": a,
                    "b": b,
                    "similarity": {"effects_jaccard": round(sim, 4)},
                    "kind": "layered" if layered else "competing",
                    "evidence": {
                        "shared_effects": sorted(a_tok & b_tok)[:20],
                        "a_effect_count": len(a_tok),
                        "b_effect_count": len(b_tok),
                    },
                }
            )

    overlaps.sort(key=lambda r: (-float(r["similarity"]["effects_jaccard"]), str(r["kind"]), str(r["a"]), str(r["b"])))

    # Union-find clusters of effect-overlap (competing or layered; cluster is informational)
    parent: dict[str, str] = {}

    def find(x: str) -> str:
        parent.setdefault(x, x)
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    def union(a: str, b: str) -> None:
        ra, rb = find(a), find(b)
        if ra != rb:
            parent[rb] = ra

    for p in overlaps:
        union(str(p["a"]), str(p["b"]))

    clusters: dict[str, set[str]] = {}
    for mid in parent.keys():
        clusters.setdefault(find(mid), set()).add(mid)

    overlap_clusters = [sorted(v) for v in clusters.values() if len(v) >= 2]
    overlap_clusters.sort(key=lambda grp: (len(grp), grp))

    return {
        "stats": {
            "modules": len(g),
            "hubs": len(hubs),
            "seams": len(seams),
            "competing_pairs": len(competing),
            "effect_overlap_pairs": len(overlaps),
            "effect_overlap_clusters": len(overlap_clusters),
        },
        "seams": seams,
        "competing": competing,
        "effect_overlap": {
            "pairs": overlaps,
            "clusters": overlap_clusters,
        },
    }
