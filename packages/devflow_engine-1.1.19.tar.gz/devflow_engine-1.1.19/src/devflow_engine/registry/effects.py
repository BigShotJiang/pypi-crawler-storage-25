from __future__ import annotations

"""Cheap static effect-signature extraction.

Goal: provide a general-purpose signal for "what this module does" without
building a full parser or hardcoding repo-specific detectors.

This intentionally uses conservative heuristics (regex-ish token matches).
"""

import re
from pathlib import Path


_EFFECT_PATTERNS: list[tuple[str, re.Pattern[str]]] = [
    ("subprocess.run", re.compile(r"\bsubprocess\.run\b")),
    ("filesystem.write", re.compile(r"\bwrite_text\b|\bwrite_bytes\b|\bopen\([^)]*['\"]w")),
    ("filesystem.read", re.compile(r"\bread_text\b|\bread_bytes\b|\bopen\([^)]*['\"]r")),
    ("execution_store", re.compile(r"\bExecutionStore\b|\bstores\.execution_store\b")),
    ("timeline.events", re.compile(r"\badd_event\b|\badd_error\b")),
    ("story.contract", re.compile(r"\bget_story\b|\bupsert_story\b|\bstory\b.*\bcontract\b")),
    ("devflow.artifacts", re.compile(r"\.devflow/")),
    ("cli.typer", re.compile(r"\btyper\.")),
    ("network.http", re.compile(r"\brequests\b|\bhttpx\b|\burllib\b")),
]


def extract_effect_tokens_from_text(text: str) -> list[str]:
    toks: list[str] = []
    for name, pat in _EFFECT_PATTERNS:
        if pat.search(text):
            toks.append(name)
    return sorted(set(toks))


def read_module_text(repo_root: Path, module_id: str) -> str | None:
    if not module_id.startswith("module:"):
        return None
    rel = module_id.split(":", 1)[1]

    # Try py first, then ts/tsx/js/jsx.
    for ext in [".py", ".ts", ".tsx", ".js", ".jsx"]:
        p = repo_root / (rel + ext)
        if p.exists():
            try:
                return p.read_text(encoding="utf-8")
            except Exception:
                return None

    # Also allow package __init__.py for python packages.
    init = repo_root / rel / "__init__.py"
    if init.exists():
        try:
            return init.read_text(encoding="utf-8")
        except Exception:
            return None

    return None


def extract_effect_tokens(repo_root: Path, module_id: str) -> list[str]:
    text = read_module_text(repo_root, module_id)
    if not text:
        return []
    return extract_effect_tokens_from_text(text)
