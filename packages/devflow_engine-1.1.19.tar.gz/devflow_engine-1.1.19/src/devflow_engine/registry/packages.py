from __future__ import annotations

import json
from collections import Counter, defaultdict
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


@dataclass(frozen=True)
class DomainState:
    domain: str
    packages: list[str]
    canonical: str | None
    allow_multiple: bool


def infer_domain_heuristic(pkg: str) -> tuple[str | None, float]:
    """Heuristic-only domain inference.

    Returns (domain, confidence).

    Important: must avoid substring false-positives (e.g. "jsesc" contains "ses").
    """

    p = pkg.lower().strip()

    email_markers = {
        "mailjet",
        "nodemailer",
        "postmark",
        "mailgun",
        "@sendgrid/mail",
        "sendgrid",
        "@aws-sdk/client-ses",
        "aws-sdk",
    }

    testing_markers = {
        "pytest",
        "vitest",
        "jest",
        "mocha",
        "ava",
        "cypress",
        "playwright",
        "playwright-core",
        "@playwright/test",
    }

    llm_markers = {
        "openai",
        "anthropic",
        "@anthropic-ai/sdk",
        "@google/generative-ai",
        "vertexai",
        "gemini",
        "mistral",
        "cohere",
        "ollama",
    }

    if p in email_markers or any(p.startswith(m + "/") for m in email_markers if m.startswith("@")):
        return ("email", 0.9)
    if p in testing_markers:
        return ("testing", 0.9)
    if p in llm_markers or p.startswith("@google/"):
        return ("llm", 0.8)

    return (None, 0.3)


def refresh_policy(conn) -> dict[str, Any]:
    """Populate/update package_domains/domain_policy/package_status based on imports + allowed_packages.

    Deterministic rule:
    - domain is inferred via package_domains.manual else heuristic.
    - canonical per domain is package with highest import count in imports(kind='external'), tie-break lexicographically.
    - if allow_multiple=0 and multiple packages exist in a domain => non-canonical packages become heretical.

    Safety:
    - ignore invalid "package" strings that can arise from scanning vendor/compiled code.
    """

    now = utc_now_iso()

    def _valid_pkg(s: str) -> bool:
        # npm-style package name (very approximate) with optional scope.
        # Reject templates, paths, and weird punctuation.
        import re

        return bool(re.match(r"^(@[a-z0-9][\w.-]*/)?[a-z0-9][\w.-]*$", s))

    # Ensure schema compatibility (older DBs).
    # - add lane column if missing
    # - add strict-domain tables if missing
    try:
        cols = [r[1] for r in conn.execute("pragma table_info(package_status)").fetchall()]
        if "lane" not in cols:
            conn.execute("alter table package_status add column lane text")
    except Exception:
        pass

    # Create strict-domain tables if missing (older DBs).
    conn.execute(
        "create table if not exists known_domains(domain text primary key, is_controlled integer not null default 1, updated_at text not null)"
    )
    conn.execute(
        "create table if not exists package_purpose(package text primary key, domain text not null, purpose text not null, decided_by text not null, confidence real, updated_at text not null)"
    )
    conn.execute(
        "create table if not exists package_status_overrides(domain text not null, package text not null, status text not null, updated_at text not null, primary key(domain, package))"
    )

    # Clear derived tables (we recompute deterministically each refresh).
    conn.execute("delete from package_status")

    # Import counts per external package
    pkg_counts: Counter[str] = Counter()
    for (resolved_id,) in conn.execute("select resolved_id from imports where kind='external'").fetchall():
        rid = str(resolved_id)
        if rid.startswith("pkg:"):
            pkg = rid.split(":", 1)[1]
            if not _valid_pkg(pkg):
                continue
            pkg_counts[pkg] += 1

    # Ensure allowed_packages includes anything in imports (belt+braces)
    for pkg in pkg_counts.keys():
        conn.execute("insert or ignore into allowed_packages(name) values (?)", (pkg,))

    # Load manual domain overrides
    manual_domains: dict[str, str] = {
        str(pkg): str(dom)
        for pkg, dom in conn.execute("select package, domain from package_domain_overrides").fetchall()
    }

    # Also respect any previously stored manual entries in package_domains.
    for pkg, dom, inferred_by in conn.execute(
        "select package, domain, inferred_by from package_domains where domain is not null"
    ).fetchall():
        if str(inferred_by) == "manual":
            manual_domains.setdefault(str(pkg), str(dom))

    # Upsert package_domains
    domains_to_pkgs: dict[str, list[str]] = defaultdict(list)
    unknown: list[str] = []

    # Ensure inferred domains are tracked (controlled-by-default).
    # We'll upsert discovered domains during the loop below.

    for pkg in sorted({*pkg_counts.keys()}):
        if pkg in manual_domains:
            dom = manual_domains[pkg]
            conf = 1.0
            inferred_by = "manual"
        else:
            dom, conf = infer_domain_heuristic(pkg)
            inferred_by = "heuristic"

        conn.execute(
            "insert or replace into package_domains(package, domain, inferred_by, confidence, updated_at) values (?,?,?,?,?)",
            (pkg, dom, inferred_by, float(conf), now),
        )

        if dom is None:
            unknown.append(pkg)
        else:
            dom_s = str(dom)
            domains_to_pkgs[dom_s].append(pkg)
            # Upsert known domain as controlled-by-default.
            conn.execute(
                "insert or ignore into known_domains(domain, is_controlled, updated_at) values (?,?,?)",
                (dom_s, 1, now),
            )
            # Touch timestamp (keep deterministic but current).
            conn.execute("update known_domains set updated_at=? where domain=?", (now, dom_s))

    # Drop stale domain_policy rows for domains that no longer exist in this repo.
    current_domains = set(domains_to_pkgs.keys())
    for (dom_existing,) in conn.execute("select domain from domain_policy").fetchall():
        if str(dom_existing) not in current_domains:
            conn.execute("delete from domain_policy where domain=?", (str(dom_existing),))

    # Determine canonical per domain by import counts
    for dom, pkgs in domains_to_pkgs.items():
        # ensure a policy row exists
        row = conn.execute("select canonical_package, allow_multiple from domain_policy where domain=?", (dom,)).fetchone()
        if row:
            canonical_existing, allow_multiple = row
            allow_multiple = bool(int(allow_multiple))
        else:
            canonical_existing, allow_multiple = None, False

        # If canonical is unset, compute deterministically
        canonical = str(canonical_existing) if canonical_existing else None
        if canonical is None:
            ranked = sorted(pkgs, key=lambda p: (-pkg_counts.get(p, 0), p))
            canonical = ranked[0] if ranked else None

        conn.execute(
            "insert or replace into domain_policy(domain, canonical_package, allow_multiple, updated_at) values (?,?,?,?)",
            (dom, canonical, 1 if allow_multiple else 0, now),
        )

        # Update package_status for packages in the domain
        # Load any lane assignments
        lanes: dict[str, str] = {
            str(pkg): str(lane)
            for pkg, lane in conn.execute(
                "select package, lane from package_lanes where domain=?",
                (dom,),
            ).fetchall()
        }

        # Load any status overrides
        overrides: dict[str, str] = {
            str(pkg): str(st)
            for pkg, st in conn.execute(
                "select package, status from package_status_overrides where domain=?",
                (dom,),
            ).fetchall()
        }

        for p in pkgs:
            if p in overrides:
                status = overrides[p]
            else:
                status = "canonical" if canonical and p == canonical else "allowed" if allow_multiple else "heretical"

            reason = None
            if status == "heretical":
                reason = f"heretical (non-canonical) in domain {dom}"

            lane = lanes.get(p)
            conn.execute(
                "insert or replace into package_status(package, domain, status, lane, reason, updated_at) values (?,?,?,?,?,?)",
                (p, dom, status, lane, reason, now),
            )

    # Unknown packages
    for pkg in unknown:
        conn.execute(
            "insert or replace into package_status(package, domain, status, lane, reason, updated_at) values (?,?,?,?,?,?)",
            (pkg, None, "unknown", None, "domain_unknown", now),
        )

    conn.commit()

    return {
        "unknown": unknown,
        "domains": {d: sorted(ps) for d, ps in domains_to_pkgs.items()},
        "import_counts": dict(pkg_counts),
    }


def gate_from_db(conn) -> dict[str, Any]:
    """Compute gate report from DB policy tables (refreshing first if needed)."""

    # Always refresh; this is cheap relative to registry init, and keeps autonomy.
    refresh_meta = refresh_policy(conn)

    violations: list[dict[str, Any]] = []

    # domain -> packages
    domain_rows = conn.execute(
        "select domain, canonical_package, allow_multiple from domain_policy order by domain"
    ).fetchall()

    controlled_map = {
        str(d): bool(int(c))
        for d, c in conn.execute("select domain, is_controlled from known_domains").fetchall()
    }

    for dom, canonical, allow_multiple in domain_rows:
        dom = str(dom)
        canonical = str(canonical) if canonical else None
        allow_multiple = bool(int(allow_multiple))
        is_controlled = controlled_map.get(dom, True)

        # Pull statuses+lanes for this domain
        rows = [
            (str(pkg), str(st), (str(lane) if lane is not None else ""))
            for pkg, st, lane in conn.execute(
                "select package, status, lane from package_status where domain=? and status in ('canonical','allowed','heretical') order by package",
                (dom,),
            ).fetchall()
        ]
        pkgs = [r[0] for r in rows]

        if not is_controlled:
            continue

        if len(pkgs) > 1 and not allow_multiple:
            # Strict: must have exactly one non-heretical package.
            non_heresy = [pkg for (pkg, st, _lane) in rows if st in {"canonical", "allowed"}]
            if len(non_heresy) != 1:
                violations.append({"domain": dom, "kind": "domain_not_converged", "packages": rows})
            continue

        if allow_multiple and pkgs:
            # Lane required for all packages
            missing_lane = [pkg for (pkg, _st, lane) in rows if not lane]
            if missing_lane:
                violations.append({"domain": dom, "kind": "missing_lane", "packages": sorted(missing_lane)})
                continue

            # Per-lane: exactly one non-heretical.
            by_lane: dict[str, list[tuple[str, str]]] = {}
            for pkg, st, lane in rows:
                by_lane.setdefault(lane, []).append((pkg, st))

            for lane, items in sorted(by_lane.items()):
                non_heresy = [pkg for (pkg, st) in items if st in {"canonical", "allowed"}]
                if len(non_heresy) != 1:
                    violations.append({"domain": dom, "kind": "lane_not_converged", "lane": lane, "packages": items})

    unknown = [
        str(r[0])
        for r in conn.execute("select package from package_status where status='unknown' order by package").fetchall()
    ]

    # Strict mode: unknown packages are not allowed.
    if unknown:
        violations.append({"kind": "unknown_packages", "packages": unknown})

    return {
        "domains": {
            r[0]: {
                "canonical": r[1],
                "allow_multiple": bool(int(r[2])),
                "controlled": controlled_map.get(str(r[0]), True),
            }
            for r in domain_rows
        },
        "unknown": unknown,
        "violations": violations,
        "refresh": refresh_meta,
    }


def dump_report(report: dict[str, Any]) -> str:
    return json.dumps(report, indent=2, sort_keys=True) + "\n"
