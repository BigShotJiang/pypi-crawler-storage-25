from __future__ import annotations

"""Build a unified enforcement report from the registry DB.

Enforcement is gate-only: it must not run LLM classification or change policy.
It may derive facts from the current import graph + persisted policy.

Report format is designed to be consumed by `devflow refactor`.
"""

from collections import defaultdict


def build_enforce_report(conn, *, changed_importers: set[str] | None = None) -> dict[str, object]:
    """Return a machine-readable enforcement report.

    conn is a sqlite3 connection with registry schema.
    changed_importers (optional) restricts the report to imports originating from
    those importer file paths (repo-relative).
    """

    changed_importers = {str(p) for p in (changed_importers or set())}

    def _importer_ok(importer: str) -> bool:
        return (not changed_importers) or (importer in changed_importers)

    # Missing registration (existing helper query semantics)
    missing: list[dict[str, str]] = []

    # external missing
    for importer, specifier, resolved_id in conn.execute(
        """
        SELECT importer, specifier, resolved_id
        FROM imports
        WHERE kind='external'
        AND substr(resolved_id, 5) NOT IN (SELECT name FROM allowed_packages)
        ORDER BY importer, specifier
        """
    ).fetchall():
        if not _importer_ok(str(importer)):
            continue
        missing.append({"importer": str(importer), "specifier": str(specifier), "resolved_id": str(resolved_id), "kind": "external"})

    # internal missing
    for importer, specifier, resolved_id in conn.execute(
        """
        SELECT importer, specifier, resolved_id
        FROM imports
        WHERE kind='internal'
        AND resolved_id NOT IN (SELECT item_id FROM registered_items)
        ORDER BY importer, specifier
        """
    ).fetchall():
        if not _importer_ok(str(importer)):
            continue
        missing.append({"importer": str(importer), "specifier": str(specifier), "resolved_id": str(resolved_id), "kind": "internal"})

    # Canonical refactor directives
    directives: list[dict[str, object]] = []

    # Packages: if a package is marked heretical, tell the user to refactor to the canonical for that domain/lane.
    pkg_status: dict[str, tuple[str, str, str]] = {}
    for package, domain, status, lane in conn.execute(
        "select package, domain, status, coalesce(lane,'') from package_status where domain is not null"
    ).fetchall():
        pkg_status[str(package)] = (str(domain), str(status), str(lane or ""))

    canonical_by_domain_lane: dict[tuple[str, str], str] = {}
    for package, domain, status, lane in conn.execute(
        "select package, domain, status, coalesce(lane,'') from package_status where status='canonical' and domain is not null"
    ).fetchall():
        canonical_by_domain_lane[(str(domain), str(lane or ""))] = str(package)

    for importer, specifier, resolved_id in conn.execute(
        "select importer, specifier, resolved_id from imports where kind='external' order by importer, specifier"
    ).fetchall():
        if not _importer_ok(str(importer)):
            continue
        pkg = str(resolved_id).split(":", 1)[1]
        st = pkg_status.get(pkg)
        if not st:
            continue
        domain, status, lane = st
        if status != "heretical":
            continue
        canon = canonical_by_domain_lane.get((domain, lane)) or canonical_by_domain_lane.get((domain, ""))
        if not canon or canon == pkg:
            continue
        directives.append(
            {
                "kind": "refactor_external_package",
                "domain": domain,
                "lane": lane,
                "from": pkg,
                "to": canon,
                "evidence": {"importer": str(importer), "specifier": str(specifier)},
            }
        )

    # Modules: if an imported module is heretical in an existing (domain, card_id, lane), refactor to canonical.
    canon_module_by_key: dict[tuple[str, str, str], str] = {}
    for domain, card_id, lane, module_id in conn.execute(
        "select domain, card_id, lane, module_id from module_card_membership where status='canonical'"
    ).fetchall():
        canon_module_by_key[(str(domain), str(card_id), str(lane))] = str(module_id)

    membership: dict[tuple[str, str, str, str], str] = {}
    for domain, card_id, lane, module_id, status in conn.execute(
        "select domain, card_id, lane, module_id, status from module_card_membership"
    ).fetchall():
        membership[(str(domain), str(card_id), str(lane), str(module_id))] = str(status)

    # Build quick module -> keys where it is heretical.
    heretical_keys_by_module: dict[str, list[tuple[str, str, str]]] = defaultdict(list)
    for (domain, card_id, lane, module_id), status in membership.items():
        if status == "heretical":
            heretical_keys_by_module[module_id].append((domain, card_id, lane))

    for importer, specifier, resolved_id in conn.execute(
        "select importer, specifier, resolved_id from imports where kind='internal' order by importer, specifier"
    ).fetchall():
        if not _importer_ok(str(importer)):
            continue
        mid = str(resolved_id)
        for key in heretical_keys_by_module.get(mid, []):
            canon = canon_module_by_key.get(key)
            if not canon or canon == mid:
                continue
            domain, card_id, lane = key
            directives.append(
                {
                    "kind": "refactor_internal_module",
                    "domain": domain,
                    "card_id": card_id,
                    "lane": lane,
                    "from": mid,
                    "to": canon,
                    "evidence": {"importer": str(importer), "specifier": str(specifier)},
                }
            )

    directives.sort(key=lambda d: (str(d.get("kind")), str(d.get("domain")), str(d.get("from")), str(d.get("to")), str(d.get("evidence", {}).get("importer"))))

    ok = (not missing) and (not directives)
    return {
        "ok": bool(ok),
        "missing": missing,
        "directives": directives,
        "stats": {"missing": len(missing), "directives": len(directives)},
    }
