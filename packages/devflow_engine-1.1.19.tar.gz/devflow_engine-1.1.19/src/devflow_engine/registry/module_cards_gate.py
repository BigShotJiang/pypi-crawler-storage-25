from __future__ import annotations

"""Deterministic gate for classified module cards."""

from collections import defaultdict


def gate_classified_module_cards(doc: dict[str, object]) -> dict[str, object]:
    assignments = doc.get("assignments") if isinstance(doc, dict) else None
    if not isinstance(assignments, list):
        return {"ok": False, "violations": [{"kind": "invalid_format", "message": "missing assignments[]"}]}

    violations: list[dict[str, object]] = []

    # Validate required fields and group by (domain, card_id, lane)
    by_key: dict[tuple[str, str, str], list[dict[str, str]]] = defaultdict(list)
    seen_module_in_card: set[tuple[str, str]] = set()  # (card_id, module_id)

    for a in assignments:
        if not isinstance(a, dict):
            continue
        card_id = str(a.get("card_id") or "").strip()
        domain = str(a.get("domain") or "").strip()
        module_id = str(a.get("module_id") or "").strip()
        lane = str(a.get("lane") or "").strip()
        status = str(a.get("status") or "").strip().lower()

        if not card_id or not domain or not module_id or not lane:
            violations.append({"kind": "missing_fields", "assignment": a})
            continue
        if status not in {"canonical", "heretical"}:
            violations.append({"kind": "invalid_status", "assignment": a})
            continue

        if (card_id, module_id) in seen_module_in_card:
            violations.append({"kind": "duplicate_module", "card_id": card_id, "module_id": module_id})
            continue
        seen_module_in_card.add((card_id, module_id))

        by_key[(domain, card_id, lane)].append(
            {"module_id": module_id, "status": status}
        )

    # Convergence per lane.
    for (domain, card_id, lane), items in sorted(by_key.items()):
        canon = [i["module_id"] for i in items if i["status"] == "canonical"]
        if len(canon) != 1:
            violations.append(
                {
                    "kind": "lane_not_converged",
                    "domain": domain,
                    "card_id": card_id,
                    "lane": lane,
                    "canonicals": canon,
                    "members": sorted(items, key=lambda r: (r["status"], r["module_id"])) ,
                }
            )

    return {"ok": not violations, "violations": violations}
