from __future__ import annotations

"""Draft module-card registration artifacts.

This is intentionally *non-destructive*: it does not write to the registry DB.
It produces a stable JSON draft you can inspect, edit, and later "apply".

A draft card is keyed by (domain, card_id, lane) and has exactly one canonical seam.
In v0 drafts, domain is "unknown" and lane is "default".
"""

import re
from dataclasses import dataclass

from .pathways import ModuleSignals, build_module_graph, detect_pathways


@dataclass(frozen=True)
class DraftCard:
    card_id: str
    domain: str
    lane: str
    canonical_module_id: str
    competing_module_ids: tuple[str, ...]
    evidence: dict[str, object]


def _slugify(text: str) -> str:
    t = text.strip().lower()
    t = re.sub(r"[^a-z0-9]+", "-", t)
    t = re.sub(r"-+", "-", t).strip("-")
    return t or "card"


def _module_basename(module_id: str) -> str:
    s = module_id.split(":", 1)[-1]
    return s.split("/")[-1]


def _choose_canonical(module_ids: list[str], g: dict[str, ModuleSignals]) -> str:
    # Deterministic: highest in_degree, tie-break by module_id.
    return sorted(module_ids, key=lambda mid: (-(g.get(mid).in_degree if g.get(mid) else 0), mid))[0]


def draft_module_cards(
    *,
    imports_rows: list[tuple[str, str, str, str]],
    module_exports: dict[str, list[str]] | None = None,
    module_external_pkgs: dict[str, list[str]] | None = None,
    module_effect_tokens: dict[str, list[str]] | None = None,
    focus_module_ids: set[str] | None = None,
    domain_default: str = "unknown",
    lane_default: str = "default",
) -> dict[str, object]:
    """Generate a stable draft module-card plan from import graph signals."""

    report = detect_pathways(
        imports_rows=imports_rows,
        module_exports=module_exports,
        module_external_pkgs=module_external_pkgs,
        module_effect_tokens=module_effect_tokens,
    )

    g = build_module_graph(
        imports_rows=imports_rows,
        module_exports=module_exports,
        module_external_pkgs=module_external_pkgs,
    )

    # Build undirected components from competing pairs.
    # We include both:
    # - "competing" hubs (shared importer neighborhoods)
    # - "effect_overlap" competing pairs (shared effect signatures)
    adj: dict[str, set[str]] = {}

    def _add_edge(a: str, b: str) -> None:
        if not a or not b:
            return
        adj.setdefault(a, set()).add(b)
        adj.setdefault(b, set()).add(a)

    for p in report.get("competing", []):
        _add_edge(str(p.get("a") or ""), str(p.get("b") or ""))

    eo = report.get("effect_overlap", {})
    if isinstance(eo, dict):
        for p in eo.get("pairs", []) if isinstance(eo.get("pairs"), list) else []:
            if not isinstance(p, dict):
                continue
            if str(p.get("kind") or "") != "competing":
                continue
            _add_edge(str(p.get("a") or ""), str(p.get("b") or ""))

    visited: set[str] = set()
    groups: list[list[str]] = []

    for n in sorted(adj.keys()):
        if n in visited:
            continue
        stack = [n]
        comp: set[str] = set()
        while stack:
            cur = stack.pop()
            if cur in visited:
                continue
            visited.add(cur)
            comp.add(cur)
            for nxt in adj.get(cur, set()):
                if nxt not in visited:
                    stack.append(nxt)
        if len(comp) >= 2:
            groups.append(sorted(comp))

    # Any hub seams not in a competing group become singleton cards.
    hub_ids: list[str] = []
    for s in report.get("seams", []):
        if isinstance(s, dict) and s.get("kind") == "hub":
            hub_ids.append(str(s.get("module_id") or ""))
    hub_ids = [h for h in hub_ids if h]

    grouped = {m for grp in groups for m in grp}
    for h in sorted(set(hub_ids)):
        if h not in grouped:
            groups.append([h])

    focus_module_ids = focus_module_ids or None

    # Draft cards
    cards: list[dict[str, object]] = []
    for grp in groups:
        if focus_module_ids is not None:
            if not any(m in focus_module_ids for m in grp):
                continue
        canonical = _choose_canonical(grp, g)
        competitors = [m for m in grp if m != canonical]

        # Stable-ish card id based on canonical basename + first few competitors.
        parts = [_module_basename(canonical)] + [_module_basename(m) for m in competitors[:2]]
        card_id = _slugify("-".join(parts))

        evidence = {
            "canonical": {
                "module_id": canonical,
                "in_degree": g.get(canonical).in_degree if g.get(canonical) else 0,
                "out_degree": g.get(canonical).out_degree if g.get(canonical) else 0,
                "top_importers": list(g.get(canonical).importers)[:10] if g.get(canonical) else [],
            },
            "competing": [
                {
                    "module_id": m,
                    "in_degree": g.get(m).in_degree if g.get(m) else 0,
                    "out_degree": g.get(m).out_degree if g.get(m) else 0,
                }
                for m in competitors
            ],
        }

        cards.append(
            {
                "card_id": card_id,
                "domain": domain_default,
                "lane": lane_default,
                "canonical_module_id": canonical,
                "competing_module_ids": competitors,
                "evidence": evidence,
            }
        )

    cards.sort(key=lambda c: (str(c.get("domain")), str(c.get("lane")), str(c.get("card_id"))))

    return {
        "version": 1,
        "stats": {
            "cards": len(cards),
            "source_modules": report.get("stats", {}).get("modules"),
            "source_hubs": report.get("stats", {}).get("hubs"),
            "source_competing_pairs": report.get("stats", {}).get("competing_pairs"),
            "source_effect_overlap_pairs": report.get("stats", {}).get("effect_overlap_pairs"),
        },
        "cards": cards,
        "raw": {
            "pathways": report,
        },
    }
