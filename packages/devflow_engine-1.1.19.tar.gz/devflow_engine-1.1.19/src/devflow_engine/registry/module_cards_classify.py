from __future__ import annotations

"""Module-card classification (non-destructive).

Takes a draft module-card plan and produces a classified plan:
- assigns each card a domain
- assigns each module within card a lane
- marks exactly one canonical per (domain, card_id, lane)

This mirrors the package policy model (domain + lane + canonical/heretical),
but remains file-based until we decide to persist it.
"""

import json
from dataclasses import dataclass


@dataclass(frozen=True)
class ClassifiedAssignment:
    card_id: str
    domain: str
    module_id: str
    lane: str
    status: str  # canonical|heretical
    reason: str


def _extract_json(text: str) -> str | None:
    # Common case: model wraps JSON in ```json fences.
    if "```" in text:
        parts = text.split("```")
        for i in range(len(parts) - 1):
            body = parts[i + 1]
            body_lines = body.splitlines()
            if body_lines and body_lines[0].strip().lower() in {"json", "javascript"}:
                body = "\n".join(body_lines[1:])
            body = body.strip()
            if body.startswith("{") and body.endswith("}"):
                return body

    start = text.find("{")
    end = text.rfind("}")
    if start != -1 and end != -1 and end > start:
        return text[start : end + 1]

    return None


def build_classify_prompt(*, draft: dict[str, object], domain_enum: list[str] | None = None, allow_new_domains: bool = True) -> str:
    cards = draft.get("cards") if isinstance(draft, dict) else None
    if not isinstance(cards, list):
        cards = []

    # Keep prompt small: only include cards with >1 module (i.e., overlaps).
    overlap_cards: list[dict[str, object]] = []
    for c in cards:
        if not isinstance(c, dict):
            continue
        canon = str(c.get("canonical_module_id") or "").strip()
        comps = c.get("competing_module_ids")
        if not canon:
            continue
        if not isinstance(comps, list) or not comps:
            continue
        overlap_cards.append(
            {
                "card_id": str(c.get("card_id") or "").strip(),
                "canonical_module_id": canon,
                "competing_module_ids": [str(x) for x in comps if str(x)],
                "evidence": c.get("evidence") if isinstance(c.get("evidence"), dict) else {},
            }
        )

    instructions = [
        "Return JSON only (no markdown, no code fences).",
        "For each card, choose a domain.",
        "Lane assignment is the primary goal. Prefer splitting into semantically distinct lanes over marking heresy.",
        "For each module in a card (canonical + competing), assign a lane string.",
        "If two modules are different abstraction levels (primitive vs composite), different surfaces (provider vs consumer), or different sub-flows, they should be in different lanes.",
        "Only when two modules genuinely represent the same concern within the same lane should you mark one canonical and all others heretical.",
        "Within each lane of a card, mark exactly one module as canonical and all other modules in that lane heretical.",
        "Minimize heretical assignments; use them only when lane splitting cannot be justified.",
        "Keep lane names short but expressive; hierarchical lanes are allowed (e.g. navigation.top, navigation.bottom, controls.primitive, controls.composite, context.provider, page.consumer).",
    ]

    if allow_new_domains:
        instructions.extend(
            [
                "You MAY propose a new domain if none of domain_enum fit.",
                "If proposing a new domain, include new_domain with that value (and also set domain to that value).",
                "New domains must be 1-2 words, general (not project-specific), lowercase, and avoid version suffixes.",
            ]
        )
    else:
        instructions.extend(
            [
                "You MUST choose domain from domain_enum. Do not create new domains.",
            ]
        )

    payload: dict[str, object] = {
        "task": "classify_module_cards",
        "domain_enum": domain_enum or [],
        "allow_new_domains": bool(allow_new_domains),
        "cards": overlap_cards,
        "instructions": instructions,
        "output_schema": {
            "assignments": [
                {
                    "card_id": "string",
                    "domain": "string",
                    "new_domain": "string|null",
                    "module_id": "string",
                    "lane": "string",
                    "status": "canonical|heretical",
                    "reason": "string",
                }
            ]
        },
    }

    return json.dumps(payload, indent=2, sort_keys=True)


def parse_classified_output(*, out_text: str) -> dict[str, object]:
    raw = _extract_json(out_text)
    if raw is None:
        raise ValueError("Failed to locate JSON in LLM output")
    parsed = json.loads(raw)
    if not isinstance(parsed, dict):
        raise ValueError("LLM output must be a JSON object")
    assignments = parsed.get("assignments")
    if not isinstance(assignments, list):
        raise ValueError("LLM output missing assignments[]")

    cleaned: list[dict[str, object]] = []
    for a in assignments:
        if not isinstance(a, dict):
            continue
        card_id = str(a.get("card_id") or "").strip()
        domain = str(a.get("domain") or "").strip()
        new_domain = str(a.get("new_domain") or "").strip() or None
        module_id = str(a.get("module_id") or "").strip()
        lane = str(a.get("lane") or "").strip()
        status = str(a.get("status") or "").strip().lower()
        reason = str(a.get("reason") or "").strip()
        if not (card_id and domain and module_id and lane and status in {"canonical", "heretical"}):
            continue
        cleaned.append(
            {
                "card_id": card_id,
                "domain": domain,
                "new_domain": new_domain,
                "module_id": module_id,
                "lane": lane,
                "status": status,
                "reason": reason,
            }
        )

    cleaned.sort(key=lambda r: (str(r["domain"]), str(r["card_id"]), str(r["lane"]), str(r["status"]), str(r["module_id"])))

    new_domains = sorted({str(r["new_domain"]) for r in cleaned if r.get("new_domain")})
    return {"version": 2, "new_domains": new_domains, "assignments": cleaned}
