from __future__ import annotations

from typing import Any

from .stores.execution_store import ExecutionStore


def enqueue_source_doc_mutation_task(
    *,
    store: ExecutionStore,
    project_id: str | None,
    source_run_id: str,
    mutation_request: dict[str, Any],
) -> dict[str, Any]:
    queue_id = store.enqueue_source_doc_mutation_task(
        project_id=project_id,
        enqueue_run_id=source_run_id,
        idea_id=str(mutation_request.get("idea_id") or "").strip() or None,
        title=f"Source doc mutation for {str(mutation_request.get('idea_id') or 'unknown-idea')}",
        mutation_request=mutation_request,
    )
    row = store.get_source_doc_mutation_queue_item(source_doc_mutation_queue_id=queue_id)
    if row is None:
        raise RuntimeError(f"source_doc_mutation_queue row missing after enqueue: {queue_id}")
    return row
