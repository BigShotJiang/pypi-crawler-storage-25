from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from ..story.markdown_contracts import ALLOWED_PLANES


@dataclass(frozen=True)
class RepoSignal:
    path: str
    kind: str


def collect_repo_signals(repo_root: Path, *, max_files: int = 500) -> list[RepoSignal]:
    signals: list[RepoSignal] = []
    count = 0
    for p in sorted(repo_root.rglob("*")):
        if count >= max_files:
            break
        if "/.git/" in p.as_posix() or p.name.startswith(".venv"):
            continue
        if p.is_dir():
            continue
        rel = p.relative_to(repo_root).as_posix()
        kind = "file"
        if rel.endswith("pyproject.toml"):
            kind = "pyproject"
        elif rel.endswith(".py"):
            kind = "python"
        elif rel.endswith(".md"):
            kind = "docs"
        elif rel.endswith(".sql"):
            kind = "sql"
        signals.append(RepoSignal(path=rel, kind=kind))
        count += 1
    return signals


def draft_user_stories(repo_root: Path) -> list[dict]:
    """Produce *draft* story skeletons.

    Drafts are not canonical contracts; they are generated from repo signals and should be
    reviewed/edited into canonical markdown contracts under ai_docs/context/v2/....

    This returns a dict payload that the CLI can serialize to markdown.
    """

    signals = collect_repo_signals(repo_root)
    top_kinds = {s.kind for s in signals}

    # Minimal heuristic: propose one baseline story with evidence anchors taken from repo.
    evidence = sorted({s.path for s in signals if s.kind in {"pyproject", "python", "docs"}})[:10]

    stories: list[dict] = []

    def mk(story_id: str, title: str) -> dict:
        required_planes = [p for p in ALLOWED_PLANES if p in {"api", "ops", "integrations", "auth", "ui"}]
        # default: api+ops for code repos
        if "python" in top_kinds or "pyproject" in top_kinds:
            required_planes = ["api", "ops"]
        if "docs" in top_kinds:
            required_planes = sorted(set(required_planes + ["ui"]))

        plane_oracles = [
            {
                "plane": "ops",
                "oracle": "Green gate passes (tests + typecheck + lint)",
                "anchor": "command:devflow impl gate",
            },
            {
                "plane": "api",
                "oracle": "Primary app entrypoint runs and exposes expected endpoints",
                "anchor": f"evidence:{evidence[0] if evidence else 'repo'}",
            },
        ]
        plane_oracles = [po for po in plane_oracles if po["plane"] in required_planes]

        return {
            "story_id": story_id,
            "title": title,
            "required_planes": required_planes,
            "evidence_anchors": evidence,
            "plane_oracles": plane_oracles,
        }

    stories.append(mk("STORY:devflow:planner:baseline", "Establish baseline DevFlow v2 story contracts"))

    if "python" in top_kinds:
        stories.append(mk("STORY:devflow:planner:python", "Python repo: validate tests/typecheck/lint pipeline"))

    return stories
