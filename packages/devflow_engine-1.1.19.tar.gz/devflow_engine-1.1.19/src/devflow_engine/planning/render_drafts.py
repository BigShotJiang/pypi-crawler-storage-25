from __future__ import annotations

import uuid
from typing import Any

from ..story.markdown_contracts import MANDATORY_CONTRACT_FORMATION_MODE_LINE


def _as_list(value: Any) -> list[str]:
    if isinstance(value, str):
        text = value.strip()
        return [text] if text else []
    if isinstance(value, list):
        items: list[str] = []
        for item in value:
            if isinstance(item, str):
                text = item.strip()
                if text:
                    items.append(text)
        return items
    return []


def render_draft_story_markdown(draft: dict[str, Any]) -> str:
    """Render a *draft* story skeleton as markdown.

    Drafts are intended to be copied/edited into canonical story contracts.
    """

    story_uuid = str(draft.get("story_uuid") or uuid.uuid4())
    story_id = str(draft.get("story_id") or "STORY:todo:todo:todo")
    title = str(draft.get("title") or "TODO")
    required_planes = draft.get("required_planes") or []
    rp = ", ".join(required_planes)

    plane_oracles = draft.get("plane_oracles") or []
    evidence = draft.get("evidence_anchors") or []
    story_statement = str(draft.get("story_statement") or "As a ... I want ... so that ...")
    outcome_oracle = _as_list(draft.get("outcome_oracle")) or ["TODO"]
    preconditions = _as_list(draft.get("preconditions")) or ["TODO"]
    steps = _as_list(draft.get("steps")) or ["TODO"]
    pass_conditions = _as_list(draft.get("pass_conditions")) or ["TODO"]
    fail_conditions = _as_list(draft.get("fail_conditions")) or ["TODO"]
    acceptance_criteria = _as_list(draft.get("acceptance_criteria")) or ["MUST ...", "MUST NOT ..."]
    non_goals = _as_list(draft.get("non_goals")) or ["..."]
    contract_test_spec = _as_list(draft.get("contract_test_spec")) or ["Given ...", "When ...", "Then ..."]

    draft_story_id = str(draft.get("draft_story_id") or f"draft_{story_uuid}")
    plane = str(draft.get("plane") or "")
    source_analysis_id = str(draft.get("source_analysis_id") or "")

    lines: list[str] = []

    # Locked header block for tooling (must be preserved by editors/agents).
    lines.append("DEVFLOW:LOCKED_START")
    lines.append(f"draft_story_id: {draft_story_id}")
    if plane:
        lines.append(f"plane: {plane}")
    if source_analysis_id:
        lines.append(f"source_analysis_id: {source_analysis_id}")
    # Include at least one evidence anchor line when available.
    for a in evidence[:5]:
        lines.append(f"anchor: {a}")
    lines.append("DEVFLOW:LOCKED_END")
    lines.append("")

    lines.append(f"# {title}")
    lines.append("")
    lines.append(f"story_uuid: {story_uuid}")
    lines.append(f"story_id: {story_id}")
    lines.append(f"title: {title}")
    lines.append(f"required_planes: [{rp}]")
    lines.append("")
    lines.append(MANDATORY_CONTRACT_FORMATION_MODE_LINE)
    lines.append("")

    lines.append("plane_oracles:")
    for po in plane_oracles:
        lines.append(f"- plane: {po.get('plane','')}")
        lines.append(f"  oracle: \"{po.get('oracle','')}\"")
        lines.append(f"  anchor: \"{po.get('anchor','')}\"")
        lines.append("")

    if evidence:
        lines.append("## Evidence anchors (repo signals)")
        for e in evidence:
            lines.append(f"- {e}")
        lines.append("")

    lines.append("## Story statement")
    lines.append(story_statement)
    lines.append("")

    lines.append("## Outcome oracle (user-observable)")
    for item in outcome_oracle:
        lines.append(f"- {item}")
    lines.append("")

    lines.append("## Preconditions")
    for item in preconditions:
        lines.append(f"- {item}")
    lines.append("")

    lines.append("## Steps")
    for index, item in enumerate(steps, start=1):
        lines.append(f"{index}. {item}")
    lines.append("")

    lines.append("## Pass/fail conditions")
    lines.append("Pass:")
    for item in pass_conditions:
        lines.append(f"- {item}")
    lines.append("Fail:")
    for item in fail_conditions:
        lines.append(f"- {item}")
    lines.append("")

    lines.append("## Acceptance criteria")
    for index, item in enumerate(acceptance_criteria, start=1):
        lines.append(f"{index}. {item}")
    lines.append("")

    lines.append("## Non-goals")
    for item in non_goals:
        lines.append(f"- {item}")
    lines.append("")

    lines.append("## Contract test spec (Given/When/Then)")
    for item in contract_test_spec:
        lines.append(f"- {item}")
    lines.append("")

    return "\n".join(lines)
