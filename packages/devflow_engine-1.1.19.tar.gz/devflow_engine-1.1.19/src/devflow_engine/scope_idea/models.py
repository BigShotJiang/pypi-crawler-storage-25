from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field


ScopeShape = Literal["too_broad", "just_right", "too_narrow"]
ResolutionStatus = Literal["ideas_registered", "narrow_scope_review_required"]


class SourceEvidenceRef(BaseModel):
    ref: str
    summary: str | None = None


class ArtifactLineage(BaseModel):
    stage: str
    origin: Literal["model", "fallback", "deterministic"]
    mode: str
    artifact_path: str | None = None
    agent_run_ref: str | None = None
    generated_from: list[str] = Field(default_factory=list)
    notes: list[str] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)


class ScopeContextArtifact(BaseModel):
    project_id: str
    scope_set_id: str
    scope_id: str
    scope_title: str
    scope_description: str
    source_support: list[SourceEvidenceRef] = Field(default_factory=list)
    assumptions: list[str] = Field(default_factory=list)
    cross_cutting_constraints: list[str] = Field(default_factory=list)
    neighbor_scope_refs: list[str] = Field(default_factory=list)
    approval_status: str = "approved"


class GoldilocksAssessmentArtifact(BaseModel):
    execution_lineage: ArtifactLineage | None = None
    scope_shape: ScopeShape
    reasoning: str
    dominant_outcomes: list[str] = Field(default_factory=list)
    workflow_clusters: list[str] = Field(default_factory=list)
    actor_clusters: list[str] = Field(default_factory=list)
    outcome_coherence_summary: str | None = None
    business_outcome_signals: list[str] = Field(default_factory=list)
    implementation_detail_signals: list[str] = Field(default_factory=list)
    breadth_signals: list[str] = Field(default_factory=list)
    cohesion_notes: list[str] = Field(default_factory=list)
    split_recommended: bool = False
    recommended_child_idea_count: int = 1
    merge_review_recommended: bool = False
    notes: list[str] = Field(default_factory=list)


class GoldilocksDecisionArtifact(BaseModel):
    decision: ScopeShape
    reason: str
    next_node: str


class IdeaCandidateArtifact(BaseModel):
    execution_lineage: ArtifactLineage | None = None
    idea_candidate_id: str
    project_id: str
    scope_set_id: str
    scope_id: str
    parent_scope_id: str
    refs: list[str] = Field(default_factory=list)
    title: str
    problem: str
    users: list[str]
    goal: str
    scope: list[str]
    constraints: list[str]
    acceptance_criteria: list[str]
    assumptions: list[str]
    traceability: list[str]
    split_rationale: str | None = None


class IdeaSplitPlanArtifact(BaseModel):
    execution_lineage: ArtifactLineage | None = None
    project_id: str
    scope_set_id: str
    scope_id: str
    parent_scope_id: str
    refs: list[str] = Field(default_factory=list)
    split_required: bool
    split_rationale: str
    child_ideas: list[IdeaCandidateArtifact]
    coverage_of_parent_scope: list[str] = Field(default_factory=list)
    remaining_risks: list[str] = Field(default_factory=list)


class IdeaCandidateSetArtifact(BaseModel):
    lineage: list[ArtifactLineage] = Field(default_factory=list)
    project_id: str
    scope_set_id: str
    scope_id: str
    parent_scope_id: str
    refs: list[str] = Field(default_factory=list)
    idea_candidates: list[IdeaCandidateArtifact]
    candidate_count: int
    split_applied: bool
    split_rationale: str | None = None


class RegisteredIdeaArtifact(BaseModel):
    execution_lineage: ArtifactLineage | None = None
    idea_id: str
    source_scope_id: str
    parent_scope_id: str
    idea_candidate_id: str
    title: str
    summary: str
    registry_ref: str
    idea_ref: str
    status: str


class IdeaRegistryRecordArtifact(BaseModel):
    lineage: list[ArtifactLineage] = Field(default_factory=list)
    project_id: str
    scope_set_id: str
    scope_id: str
    parent_scope_id: str
    refs: list[str] = Field(default_factory=list)
    scope_shape: ScopeShape
    registered_ideas: list[RegisteredIdeaArtifact]
    registration_timestamp: str
    registry_root: str


class NarrowScopeReviewArtifact(BaseModel):
    execution_lineage: ArtifactLineage | None = None
    project_id: str
    scope_set_id: str
    scope_id: str
    parent_scope_id: str
    refs: list[str] = Field(default_factory=list)
    reason_too_narrow: str
    suggested_merge_targets: list[str] = Field(default_factory=list)
    human_review_required: bool = True
    recommended_next_action: str


class IdeaResolutionPackageArtifact(BaseModel):
    lineage: list[ArtifactLineage] = Field(default_factory=list)
    project_id: str
    scope_set_id: str
    scope_id: str
    parent_scope_id: str
    refs: list[str] = Field(default_factory=list)
    scope_shape: ScopeShape
    split_applied: bool
    resolution_status: ResolutionStatus
    registered_idea_count: int
    registered_ideas: list[RegisteredIdeaArtifact] = Field(default_factory=list)
    assumptions_added: list[str] = Field(default_factory=list)
    remaining_risks: list[str] = Field(default_factory=list)
    recommended_next_action: str
    review_required: bool = False
    review_package_ref: str | None = None


class ScopeIdeaDagSummary(BaseModel):
    exit_code: int
    run_id: str
    pipeline_dir: str
    message: str
    outcome: dict[str, object]
