from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from pydantic import BaseModel

from ..agentic_prompts import load_agentic_prompt_lines
from ..agentic_runtime import AgentRunEnvelope, run_agent_step


SCOPE_IDEA_DOCTRINE = load_agentic_prompt_lines("scope_idea_doctrine")


def run_scope_idea_agent_step(
    *,
    repo_root: Path,
    stage_name: str,
    output_model: type[BaseModel],
    context_payload: dict[str, Any],
    guidance: list[str],
    timeout_seconds: int | None = None,
) -> tuple[BaseModel, AgentRunEnvelope]:
    return run_agent_step(
        repo_root=repo_root,
        stage_name=f"scope_idea_{stage_name}",
        output_model=output_model,
        context_payload=context_payload,
        guidance=SCOPE_IDEA_DOCTRINE + guidance,
        timeout_seconds=timeout_seconds,
    )


def persist_agent_run(*, pipeline_root: Path, node_id: str, envelope: AgentRunEnvelope) -> Path:
    path = pipeline_root / "agent_runs" / f"{node_id}.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(envelope.model_dump(), indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return path
