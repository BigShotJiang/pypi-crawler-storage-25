from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from ..implementation.green_gate import run_green_gate


@dataclass(frozen=True)
class RemediationResult:
    ok: bool
    summary: str


def remediation_run(repo_root: Path) -> RemediationResult:
    results = run_green_gate(repo_root)
    ok = all(r.ok for r in results.values())
    summary = "; ".join(
        f"{k}={'ok' if v.ok else 'fail'}({v.returncode})" for k, v in results.items()
    )
    return RemediationResult(ok=ok, summary=summary)
