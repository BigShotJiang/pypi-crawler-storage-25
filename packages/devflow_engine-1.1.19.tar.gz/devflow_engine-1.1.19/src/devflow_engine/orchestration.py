from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

from .stores.execution_store import ExecutionStore

TaskHandler = Callable[[ExecutionStore, Path, dict[str, Any]], dict[str, Any]]


@dataclass(frozen=True)
class WorkerTickResult:
    worker_id: str
    queue_name: str
    task: dict[str, Any] | None
    outcome: dict[str, Any] | None


def process_one_task(
    *,
    store: ExecutionStore,
    repo_root: Path,
    queue_name: str,
    worker_id: str,
    handlers: dict[str, TaskHandler],
    lease_seconds: int = 900,
) -> WorkerTickResult:
    task = store.claim_next_task(queue_name=queue_name, worker_id=worker_id, lease_seconds=lease_seconds)
    if task is None:
        return WorkerTickResult(worker_id=worker_id, queue_name=queue_name, task=None, outcome=None)

    lease_token = str(task.get("lease_token") or "")
    task_id = str(task["task_id"])
    task_kind = str(task["task_kind"])
    handler = handlers.get(task_kind)
    if handler is None:
        outcome = store.complete_task(
            task_id=task_id,
            lease_token=lease_token,
            status="dead_letter",
            error=f"no handler registered for task_kind={task_kind}",
            result={"task_kind": task_kind},
        )
        return WorkerTickResult(worker_id=worker_id, queue_name=queue_name, task=task, outcome=outcome)

    store.record_task_step(task_id=task_id, step_name="claim", status="leased", payload={"worker_id": worker_id})
    try:
        result = handler(store, repo_root, task)
        store.record_task_step(task_id=task_id, step_name="complete", status="completed", payload=result)
        outcome = store.complete_task(task_id=task_id, lease_token=lease_token, status="completed", result=result)
        return WorkerTickResult(worker_id=worker_id, queue_name=queue_name, task=task, outcome=outcome)
    except Exception as exc:
        store.record_task_step(task_id=task_id, step_name="complete", status="failed", payload={"error": str(exc)})
        outcome = store.complete_task(
            task_id=task_id,
            lease_token=lease_token,
            status="failed",
            error=str(exc),
            result={"error": str(exc)},
        )
        raise
