from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any, Literal

SectionKind = Literal["string", "scalar_list", "object", "keyed_list"]
MutationMode = Literal["replace", "merge", "remove"]


@dataclass(frozen=True)
class SourceDocSectionSchema:
    kind: SectionKind
    default: Any
    topic_key_field: str | None = None
    nested_scalar_lists: tuple[str, ...] = ()


@dataclass(frozen=True)
class SourceDocSchema:
    filename: str
    sections: dict[str, SourceDocSectionSchema]


def _clone(value: Any) -> Any:
    return json.loads(json.dumps(value))


SOURCE_DOC_SCHEMAS: dict[str, SourceDocSchema] = {
    "product_brief.json": SourceDocSchema(
        filename="product_brief.json",
        sections={
            "product_summary": SourceDocSectionSchema("string", ""),
            "problem_statement": SourceDocSectionSchema("string", ""),
            "target_users": SourceDocSectionSchema("scalar_list", []),
            "goals": SourceDocSectionSchema("scalar_list", []),
            "scope": SourceDocSectionSchema("object", {"in_scope": [], "out_of_scope": []}, nested_scalar_lists=("in_scope", "out_of_scope")),
            "non_goals": SourceDocSectionSchema("scalar_list", []),
            "constraints": SourceDocSectionSchema("scalar_list", []),
            "success_criteria": SourceDocSectionSchema("scalar_list", []),
            "assumptions": SourceDocSectionSchema("scalar_list", []),
        },
    ),
    "user_workflows.json": SourceDocSchema(
        filename="user_workflows.json",
        sections={
            "actors": SourceDocSectionSchema("scalar_list", []),
            "primary_workflows": SourceDocSectionSchema("keyed_list", [], topic_key_field="workflow_key"),
            "alternate_flows": SourceDocSectionSchema("keyed_list", [], topic_key_field="workflow_key"),
            "edge_cases": SourceDocSectionSchema("scalar_list", []),
            "workflow_assumptions": SourceDocSectionSchema("scalar_list", []),
        },
    ),
    "domain_entities.json": SourceDocSchema(
        filename="domain_entities.json",
        sections={
            "entities": SourceDocSectionSchema("keyed_list", [], topic_key_field="entity_key"),
            "relationships": SourceDocSectionSchema("keyed_list", [], topic_key_field="relationship_key"),
            "ownership_assumptions": SourceDocSectionSchema("scalar_list", []),
        },
    ),
    "assumptions_registry.json": SourceDocSchema(
        filename="assumptions_registry.json",
        sections={
            "assumptions": SourceDocSectionSchema("keyed_list", [], topic_key_field="assumption_id"),
        },
    ),
}


def source_doc_template_payloads() -> dict[str, dict[str, Any]]:
    return {name: {section: _clone(spec.default) for section, spec in schema.sections.items()} for name, schema in SOURCE_DOC_SCHEMAS.items()}


def _dedupe_strings(values: list[Any]) -> list[str]:
    out: list[str] = []
    for item in values:
        if not isinstance(item, str):
            continue
        text = item.strip()
        if text and text not in out:
            out.append(text)
    return out


def normalize_source_doc_payload(doc_name: str, payload: Any) -> dict[str, Any]:
    schema = SOURCE_DOC_SCHEMAS[doc_name]
    raw = payload if isinstance(payload, dict) else {}
    normalized: dict[str, Any] = {}
    for section_key, section_schema in schema.sections.items():
        value = raw.get(section_key, _clone(section_schema.default))
        if section_schema.kind == "string":
            normalized[section_key] = str(value).strip() if isinstance(value, str) else str(value).strip() if value not in (None, "") else ""
        elif section_schema.kind == "scalar_list":
            normalized[section_key] = _dedupe_strings(value if isinstance(value, list) else [])
        elif section_schema.kind == "object":
            source = value if isinstance(value, dict) else {}
            section_value = _clone(section_schema.default)
            for nested_key, nested_default in section_value.items():
                nested_value = source.get(nested_key, nested_default)
                if nested_key in section_schema.nested_scalar_lists:
                    section_value[nested_key] = _dedupe_strings(nested_value if isinstance(nested_value, list) else [])
                else:
                    section_value[nested_key] = _clone(nested_value)
            normalized[section_key] = section_value
        elif section_schema.kind == "keyed_list":
            key_field = str(section_schema.topic_key_field)
            items: list[dict[str, Any]] = []
            for item in value if isinstance(value, list) else []:
                if not isinstance(item, dict):
                    continue
                topic_key = str(item.get(key_field) or "").strip()
                if not topic_key or any(existing.get(key_field) == topic_key for existing in items):
                    continue
                clean = _clone(item)
                clean[key_field] = topic_key
                items.append(clean)
            normalized[section_key] = items
        else:
            raise ValueError(f"Unsupported source doc section kind: {section_schema.kind}")
    return normalized


def apply_source_doc_mutation(
    doc_name: str,
    payload: Any,
    *,
    section_key: str,
    topic_key: str | None = None,
    value: Any = None,
    mode: MutationMode = "merge",
) -> tuple[dict[str, Any], bool]:
    schema = SOURCE_DOC_SCHEMAS[doc_name]
    if section_key not in schema.sections:
        raise KeyError(f"Unknown section '{section_key}' for {doc_name}")
    section_schema = schema.sections[section_key]
    normalized = normalize_source_doc_payload(doc_name, payload)
    before = json.dumps(normalized, sort_keys=True)

    if section_schema.kind == "string":
        if topic_key is not None:
            raise ValueError(f"Section '{section_key}' does not support topic_key mutation")
        normalized[section_key] = "" if mode == "remove" else str(value or "").strip()
    elif section_schema.kind == "scalar_list":
        current = list(normalized[section_key])
        if topic_key is not None:
            if mode == "remove":
                normalized[section_key] = [item for item in current if item != topic_key]
            else:
                if value is not None:
                    raise ValueError(f"Section '{section_key}' expects topic_key-only mutation or whole-list value")
                normalized[section_key] = _dedupe_strings(current + [topic_key])
        elif mode == "replace":
            normalized[section_key] = _dedupe_strings(value if isinstance(value, list) else [])
        elif mode == "remove":
            removals = _dedupe_strings(value if isinstance(value, list) else [value])
            normalized[section_key] = [item for item in current if item not in removals]
        else:
            additions = _dedupe_strings(value if isinstance(value, list) else [value])
            normalized[section_key] = _dedupe_strings(current + additions)
    elif section_schema.kind == "object":
        current = dict(normalized[section_key])
        if topic_key is None:
            if mode == "replace":
                current = normalize_source_doc_payload(doc_name, {section_key: value}).get(section_key, _clone(section_schema.default))
            elif isinstance(value, dict):
                merged = current | value
                current = normalize_source_doc_payload(doc_name, {section_key: merged}).get(section_key, _clone(section_schema.default))
            else:
                raise ValueError(f"Section '{section_key}' expects dict value when mutating without topic_key")
        elif topic_key in section_schema.nested_scalar_lists:
            existing = list(current.get(topic_key) or [])
            if mode == "replace":
                current[topic_key] = _dedupe_strings(value if isinstance(value, list) else [])
            elif mode == "remove":
                removals = _dedupe_strings(value if isinstance(value, list) else [value])
                current[topic_key] = [item for item in existing if item not in removals]
            else:
                additions = _dedupe_strings(value if isinstance(value, list) else [value])
                current[topic_key] = _dedupe_strings(existing + additions)
        else:
            raise KeyError(f"Unknown topic '{topic_key}' for section '{section_key}'")
        normalized[section_key] = current
    elif section_schema.kind == "keyed_list":
        key_field = str(section_schema.topic_key_field)
        current = list(normalized[section_key])
        if not topic_key:
            raise ValueError(f"Section '{section_key}' requires topic_key mutation")
        survivors = [item for item in current if str(item.get(key_field) or "") != topic_key]
        if mode == "remove":
            normalized[section_key] = survivors
        else:
            incoming = value if isinstance(value, dict) else {}
            previous = next((item for item in current if str(item.get(key_field) or "") == topic_key), {})
            if mode == "replace":
                merged = dict(incoming)
            else:
                merged = dict(previous)
                merged.update(incoming)
            merged[key_field] = topic_key
            normalized[section_key] = survivors + [merged]
    else:
        raise ValueError(f"Unsupported source doc section kind: {section_schema.kind}")

    normalized = normalize_source_doc_payload(doc_name, normalized)
    after = json.dumps(normalized, sort_keys=True)
    return normalized, before != after
