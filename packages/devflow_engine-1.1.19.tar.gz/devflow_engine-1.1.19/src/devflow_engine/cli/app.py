from __future__ import annotations

import base64
import json
import logging
import io
import os
import re
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import time
import shutil
from contextlib import redirect_stderr, redirect_stdout
from datetime import datetime, timezone
from hashlib import sha256
from importlib import metadata
from pathlib import Path

try:
    import tomllib  # py3.11+
except Exception:  # pragma: no cover
    tomllib = None  # type: ignore

import typer
import yaml
from rich.console import Console
from rich.table import Table

from ..api_keys import (
    bootstrap_provider_api_keys,
    get_provider_api_key,
    load_provider_api_key_from_keychain,
    set_runtime_provider_api_key,
    store_provider_api_key,
)
from ..core.config import load_effective_config, redact_value
from ..core.toml_kv import write_toml_kv
from ..core.logging import configure_logging
from ..core.paths import get_paths
from ..error.remediation import remediation_run
from ..implementation.green_gate import run_green_gate
from ..implementation.dag import default_implementation_stages, render_stage_plan
from ..planning.analyze_repo import draft_user_stories
from ..planning.render_drafts import render_draft_story_markdown
from ..process.dag import run_process_dag
from ..project_registration.dag import run_project_registration_dag
from ..idea.analyze import write_analysis_artifact
from ..idea.drafts import generate_draft_set
from ..idea.diff import compute_diff, render_diff_json, render_diff_text
from ..idea.promote import apply_promotion, plan_promotion
from ..idea.story_pipeline import run_idea_to_devflow_stories_dag
from devin.dag_two_arm import run_devin_two_arm_dag as run_devin_chat_dag
from ..idea.traditional_stories import TraditionalStoryInsufficiencyError, generate_traditional_user_story_set
from ..idea.sufficiency import evaluate_idea_sufficiency, load_idea_source, render_sufficiency_json
from ..integration.dag import backfill_integration_current, prepare_integration_payload, run_integration_dag, _sync_integration_to_supabase
from ..playground.hooks import preflight as playground_preflight
from ..project_registry import find_project_for_repo_root, resolve_project_entry
from ..review.dag import run_review_dag
from ..stores.execution_store import ExecutionStore
from ..source_scope.dag import run_source_docs_to_scopes_dag, run_source_to_scope_dag, run_source_to_scope_resume
from ..source_docs_updater import apply_source_doc_updates, detect_source_doc_changes, enqueue_source_doc_update_if_needed, ensure_source_doc_scaffold, process_source_doc_update_once
from ..ui_grounding.dag import run_ui_grounding_dag
from ..ui_grounding.pencil_bridge import run_pencil_preflight
from ..story.contracts import ContractIssue, validate_parsed_story_block
from ..story.indexer import build_story_index
from ..story.markdown_contracts import iter_canonical_story_paths, parse_story_contracts_from_markdown
from ..worker import drain_project_queue
from ..worker import process_once as process_worker_once
from ..worker_guard import _check_no_running_worker_process, get_worker_guard_block
from ..worker import reconcile_stale_worker
from ..registry.cards import build_module_cards, write_cards_jsonl
from ..registry.pathways import detect_pathways
from ..registry.module_cards_draft import draft_module_cards
from ..registry.effects import extract_effect_tokens
from ..registry.module_cards_classify import build_classify_prompt, parse_classified_output
from ..registry.module_cards_gate import gate_classified_module_cards
from ..registry.domain_normalize import normalize_domain
from ..registry.packages import gate_from_db, dump_report, refresh_policy
from ..registry.enforce_report import build_enforce_report
from ..llm.cli_one_shot import run_one_shot
from ..llm.cli_stream import run_streaming
from ..devflow_event_worker import DevflowEventWorkerLoopService
from devin.devin_eval import DEFAULT_MULTI_TURN_SCENARIOS, run_devin_multi_turn_eval_suite

app = typer.Typer(add_completion=False, no_args_is_help=True)
console = Console()

project_app = typer.Typer(no_args_is_help=True)
config_app = typer.Typer(no_args_is_help=True)
story_app = typer.Typer(no_args_is_help=True)
plan_app = typer.Typer(no_args_is_help=True)
impl_app = typer.Typer(no_args_is_help=True)
review_app = typer.Typer(no_args_is_help=True)
error_app = typer.Typer(no_args_is_help=True)
play_app = typer.Typer(no_args_is_help=True)
preflight_app = typer.Typer(no_args_is_help=True)
idea_app = typer.Typer(no_args_is_help=True)
idea_drafts_app = typer.Typer(no_args_is_help=True)
idea_stories_app = typer.Typer(no_args_is_help=True)
arch_app = typer.Typer(no_args_is_help=True)
arch_decision_app = typer.Typer(no_args_is_help=True)
registry_app = typer.Typer(no_args_is_help=True)
worker_app = typer.Typer(no_args_is_help=True)
integration_app = typer.Typer(no_args_is_help=True)
source_scope_app = typer.Typer(no_args_is_help=True)
source_docs_app = typer.Typer(no_args_is_help=True)
ui_grounding_app = typer.Typer(no_args_is_help=True)

app.add_typer(project_app, name="project")
app.add_typer(config_app, name="config")
app.add_typer(story_app, name="story")
app.add_typer(plan_app, name="plan")
app.add_typer(impl_app, name="impl")
app.add_typer(review_app, name="review", help="[DEPRECATED] Non-canonical story review runner. Prefer `worker` for automated execution.")
app.add_typer(error_app, name="error")
app.add_typer(play_app, name="play", help="[HARNESS] Non-core playground/test harness tooling. Not part of the primary workflow.")
app.add_typer(preflight_app, name="preflight", help="Engine environment checks (Python, uv). Separate from `play preflight` (project checks).")
app.add_typer(idea_app, name="idea")
app.add_typer(arch_app, name="arch")
app.add_typer(registry_app, name="registry")
app.add_typer(worker_app, name="worker", help="[CANONICAL] Automated queue-driven execution. Primary runtime path for idea → story pipelines.")
app.add_typer(integration_app, name="integration")
app.add_typer(source_scope_app, name="source-scope")
app.add_typer(source_docs_app, name="source-docs")
app.add_typer(ui_grounding_app, name="ui-grounding")


@app.callback()
def _app_bootstrap() -> None:
    bootstrap_provider_api_keys()


@app.command("refactor")
def refactor_cmd(
    report_path: Path | None = typer.Option(None, "--from", help="Path to enforce report JSON (default: .devflow/enforce/latest.json)"),
    max_iters: int = typer.Option(5, "--max-iters"),
    stream: bool = typer.Option(True, "--stream/--no-stream"),
) -> None:
    """Unified refactor runner to satisfy `devflow enforce`.

    Uses LLM to produce and apply diffs, rerunning `devflow enforce` until green or max-iters.
    """

    import json

    from ..refactor import refactor_from_enforce_report

    repo_root = _repo_root()
    rp = report_path or (repo_root / ".devflow" / "enforce" / "latest.json")
    if not rp.exists():
        sys.stderr.write(f"Missing enforce report: {rp}\n")
        raise typer.Exit(code=2)

    cfg = _read_toml(_global_devflow_dir() / "config.toml")
    llm_mode = str(cfg.get("llm_mode") or "").strip().lower()
    if llm_mode != "cli":
        sys.stderr.write("LLM not configured for CLI mode.\n")
        raise typer.Exit(code=2)

    base_cmd = str(cfg.get("llm_cli_base") or "").strip()
    delivery = str(cfg.get("llm_cli_delivery") or "argument").strip().lower()
    if not base_cmd:
        sys.stderr.write("LLM CLI base command not set.\n")
        raise typer.Exit(code=2)

    for i in range(int(max_iters)):
        report = json.loads(rp.read_text(encoding="utf-8"))
        if report.get("ok"):
            sys.stdout.write("ok\n")
            return

        res = refactor_from_enforce_report(
            repo_root=repo_root,
            report=report,
            base_cmd=base_cmd,
            delivery=delivery,
            stream=stream,
        )
        if not res.get("ok"):
            sys.stdout.write(_json_dump({"ok": False, "iteration": i + 1, "result": res}))
            raise typer.Exit(code=2)

        # Re-run enforce to regenerate latest report.
        try:
            enforce(changed=None, roots=None, json_out=None)
        except typer.Exit:
            # loop continues; latest.json updated
            pass

    sys.stderr.write("refactor max-iters reached\n")
    raise typer.Exit(code=2)


@app.command("register")
def register(
    roots: list[str] | None = typer.Option(None, "--root", help="Project-owned source root (repeatable)"),
    minimal: bool = typer.Option(False, "--minimal", help="Skip LLM steps (init+scan+lock only)"),
) -> None:
    """One-time project registration/bootstrap.

    This is intended to be run only during project initialization.
    It may tolerate brownfield multiplicity during bootstrap, then locks phases.

    DAGs must never call this.
    """

    from datetime import datetime, timezone

    repo_root = _repo_root()
    db_path = _registry_db_path(repo_root)

    # Refuse to re-run once initialized.
    conn0 = _registry_connect(db_path)
    try:
        _registry_init_schema(conn0)
        state = _get_meta(conn0, "project_registration_state", "")
        if state == "initialized":
            sys.stderr.write("project already registered (one-time)\n")
            raise typer.Exit(code=2)
    finally:
        conn0.close()

    # Ensure repo-local devflow dir exists and hooks are installed.
    (repo_root / ".devflow").mkdir(parents=True, exist_ok=True)
    _install_devflow_hooks(repo_root)

    # Initialize registry DB + scan.
    registry_init(strict=False, roots=roots)

    # Bootstrap module policy (draft/classify/apply/lock) unless minimal.
    if not minimal:
        registry_module_bootstrap(roots=roots, max_new_domains=5, stream=True)

        # Bootstrap packages: classify unknowns then resolve multiplicity.
        # (Only during registration; never during enforce.)
        try:
            # classify up to a few passes
            for _ in range(5):
                # refresh policy to populate unknown list
                _ = registry_policy_refresh()
                # classify unknowns (no-op if none)
                registry_classify_packages(limit=200, stream=True)
        except typer.Exit:
            # If classify is not configured, fail registration loudly.
            raise

        # Resolve multiplicity (LLM + deterministic convergence)
        registry_resolve_multiplicity(domain=None, limit=200, dry_run=False, stream=True)
        # Gate
        registry_gate_packages(json_out=None)

    # Lock package+module phases and mark project initialized.
    now = datetime.now(timezone.utc).replace(microsecond=0).isoformat()
    conn = _registry_connect(db_path)
    try:
        _registry_init_schema(conn)
        _set_meta(conn, "package_registry_phase", "locked", now)
        _set_meta(conn, "project_registration_state", "initialized", now)
        _set_meta(conn, "project_registered_at", now, now)
        conn.commit()
    finally:
        conn.close()

    sys.stdout.write("ok\n")


@app.command("enforce")
def enforce(
    changed: list[str] | None = typer.Option(None, "--changed", help="Changed file paths (best-effort; v1 rescans full repo)"),
    roots: list[str] | None = typer.Option(None, "--root", help="Project-owned source root (repeatable)"),
    json_out: Path | None = typer.Option(None, "--json", help="Write machine-readable enforce report"),
) -> None:
    """Report-only enforcement gate (used by git hooks / CI).

    Enforcement is deterministic and must not perform registration/bootstrapping.

    It emits a unified report suitable for `devflow refactor`.
    """

    _ = changed

    repo_root = _repo_root()
    # Refresh facts
    registry_scan(roots=roots)

    # Refresh derived package status (no LLM)
    db_path = _registry_db_path(repo_root)
    conn = _registry_connect(db_path)
    try:
        _registry_init_schema(conn)
        _ = refresh_policy(conn)
        changed_set = {str(p).strip() for p in (changed or []) if str(p).strip()} if changed else None
        report = build_enforce_report(conn, changed_importers=changed_set)
    finally:
        conn.close()

    # Always write a latest report for downstream tooling.
    latest = repo_root / ".devflow" / "enforce" / "latest.json"
    latest.parent.mkdir(parents=True, exist_ok=True)
    latest.write_text(_json_dump(report), encoding="utf-8")

    if json_out:
        json_out.parent.mkdir(parents=True, exist_ok=True)
        json_out.write_text(_json_dump(report), encoding="utf-8")

    if report.get("ok"):
        sys.stdout.write("ok\n")
        return

    sys.stdout.write("ENFORCEMENT VIOLATIONS\n")
    sys.stdout.write(_json_dump(report))
    raise typer.Exit(code=2)

arch_app.add_typer(arch_decision_app, name="decision")

idea_app.add_typer(idea_drafts_app, name="drafts")
idea_app.add_typer(idea_stories_app, name="stories")


def _store() -> tuple[Path, ExecutionStore]:
    paths = get_paths()
    paths.devflow_dir.mkdir(parents=True, exist_ok=True)
    configure_logging(paths.logs_dir)
    return paths.root, ExecutionStore(paths.execution_db)


def _repo_root() -> Path:
    """Resolve repo root for repo-scoped commands."""
    override = (os.environ.get("DEVFLOW_REPO_ROOT") or "").strip()
    if override:
        return Path(override).expanduser().resolve()
    return get_paths().root


def _slug_project_name(value: str) -> str:
    text = re.sub(r"[^A-Za-z0-9]+", "-", (value or "").strip().lower()).strip("-")
    return text or "project"


def _path_is_within(path: Path, root: Path) -> bool:
    try:
        path.resolve().relative_to(root.resolve())
        return True
    except Exception:
        return False


def _is_disallowed_canonical_repo_root(path: Path) -> bool:
    banned = [
        Path("/tmp/.devflow/projects"),
        Path("/tmp/.openclaw/workspace/projects"),
        Path.home() / ".devflow",
        Path.home() / ".openclaw" / "workspace",
    ]
    return any(_path_is_within(path, root) for root in banned)


def resolve_canonical_repo_root(project_name: str, local_repo_path: str | None) -> Path:
    if local_repo_path:
        candidate = Path(local_repo_path).expanduser().resolve()
        if _is_disallowed_canonical_repo_root(candidate):
            raise ValueError(f"Refusing internal state path as repo_root: {candidate}")
        return candidate
    return (Path.home() / "repos" / _slug_project_name(project_name)).resolve()


_CLARIFY_PROVISION_COMMAND_REFERENCE = (
    "python3 <(gh api repos/Nuosis/clarify/contents/scripts/provision_from_template.py "
    "--jq '.content' | base64 -d)"
)
_COPY_PROVISION_STRATEGY = "COPY_PROVISION_SCRIPT"
_LOCAL_ONLY_UNTIL_APPROVED = "LOCAL_ONLY_UNTIL_APPROVED"
_VERCEL_FREE_TIER = "VERCEL_FREE_TIER"
_SUPPORTED_INIT_TEMPLATES = {
    "backend": "backend",
    "clarify": "backend",
    "python": "python",
    "typescript": "typescript",
    "monorepo": "monorepo-py-ts",
    "monorepo-py-ts": "monorepo-py-ts",
    "monorepo_py_ts": "monorepo-py-ts",
    "new_monorepo_py_ts": "monorepo-py-ts",
    "next": "next",
    "react-native": "react-native",
    "react_native": "react-native",
    "reactnative": "react-native",
}


def _normalize_init_template(template: str | None, project_type: str | None) -> str | None:
    raw = (template or project_type or "").strip().lower()
    if not raw:
        return None
    normalized = _SUPPORTED_INIT_TEMPLATES.get(raw)
    if normalized is None:
        raise typer.BadParameter(
            "unsupported init template/project type; expected one of: backend, clarify, python, "
            "typescript, monorepo-py-ts, next, react-native"
        )
    return normalized


def _write_repo_file(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def _run_git_command(cmd: list[str], *, cwd: Path | None = None) -> None:
    result = subprocess.run(cmd, cwd=(None if cwd is None else str(cwd)), capture_output=True, text=True, check=False)
    if result.returncode != 0:
        sys.stdout.write(result.stdout)
        sys.stderr.write(result.stderr)
        raise typer.Exit(code=2)


def _resolve_backend_provision_script_source() -> Path:
    override = (os.environ.get("DEVFLOW_BACKEND_PROVISION_SCRIPT") or "").strip()
    if override:
        candidate = Path(override).expanduser().resolve()
        if not candidate.exists():
            raise typer.BadParameter(f"DEVFLOW_BACKEND_PROVISION_SCRIPT points to a missing file: {candidate}")
        return candidate
    return (Path(__file__).resolve().parents[1] / "bootstrap" / "provision_from_template.py").resolve()


def _write_template_bootstrap_manifest(
    dest: Path,
    *,
    template: str,
    project_name: str,
    provision_script_source: str | None = None,
) -> None:
    manifest: dict[str, object] = {
        "template": template,
        "project_name": project_name,
    }
    if template in {"backend", "python"}:
        manifest["backend_provisioning"] = {
            "strategy": _COPY_PROVISION_STRATEGY,
            "command_reference": _CLARIFY_PROVISION_COMMAND_REFERENCE,
            "invocation_mode": "copied_script",
            "source_script": provision_script_source or str(_resolve_backend_provision_script_source()),
        }
        manifest["deploy_defaults"] = {
            "backend": _LOCAL_ONLY_UNTIL_APPROVED,
            "production_requires_explicit_user_approval": True,
            "review_readme_auto_deploy_steps_after_approval": True,
        }
    _write_repo_file(dest / ".devflow" / "template_bootstrap.json", json.dumps(manifest, indent=2, sort_keys=True) + "\n")


def _provision_python_backend_template(dest: Path, *, template: str, project_name: str) -> None:
    # Nuosis provision script requires the target dir to be empty.
    # We stub it first so it's non-empty when the script runs, then remove
    # the stubs so the script can provision into a clean dir. After the script
    # succeeds we write the bootstrap manifest. This avoids the "empty dir"
    # requirement being satisfied by our own stub files.
    dest.mkdir(parents=True, exist_ok=True)
    source_script = _resolve_backend_provision_script_source()
    slug = re.sub(r"[^a-z0-9]+", "-", project_name.strip().lower()).strip("-") or "python-backend"
    pkg = re.sub(r"[^a-z0-9]+", "_", project_name.strip().lower()).strip("_") or "python_backend"
    stub_files = [
        dest / "README.md",
        dest / "pyproject.toml",
        dest / "src" / pkg / "__init__.py",
        dest / "src" / pkg / "app.py",
        dest / ".devflow-backend-bootstrap.json",
    ]
    for f in stub_files:
        f.parent.mkdir(parents=True, exist_ok=True)
        if f.suffix == ".json":
            import json as _json
            f.write_text(_json.dumps({"provisioning_strategy": "COPY_PROVISION_SCRIPT", "note": "stub"}, indent=2) + "\n", encoding="utf-8")
        elif f.name == "__init__.py":
            f.write_text("__all__ = []\n", encoding="utf-8")
        elif f.name == "app.py":
            f.write_text("def healthcheck() -> dict[str, str]:\n    return {\"status\": \"ok\"}\n", encoding="utf-8")
        else:
            f.write_text(f"# {project_name}\n", encoding="utf-8")

    # Remove stubs so the Nuosis script can provision into a genuinely empty dir
    for f in stub_files:
        f.unlink(missing_ok=True)
    # Remove entire src/ tree (may have nested subdirs from the stub package)
    if (dest / "src").exists():
        shutil.rmtree(dest / "src")
    # Also remove .devflow dir if it exists (e.g. .devflow-backend-bootstrap.json stub created it)
    devflow_dir = dest / ".devflow"
    if devflow_dir.exists():
        for item in list(devflow_dir.iterdir()):
            if item.is_dir():
                shutil.rmtree(item)
            else:
                item.unlink()
        devflow_dir.rmdir()
    for d in [dest / "tests"]:
        if d.exists() and not any(d.iterdir()):
            d.rmdir()

    # Pre-initialize git with a non-Nuosis origin so the Nuosis script's
    # template-repository check (which rejects Nuosis/clarify as origin)
    # passes and skips the interactive GitHub repo creation step.
    if not (dest / ".git").exists():
        _run_git_command(["git", "init"], cwd=dest)
    nuosis_fake_remote = f"git@github.com:Nuosis/{slug}.git"
    result_check = subprocess.run(
        ["git", "remote", "get-url", "origin"],
        capture_output=True, text=True, cwd=dest,
    )
    if result_check.returncode != 0:
        subprocess.run(["git", "remote", "add", "origin", nuosis_fake_remote], cwd=dest, check=True)
    else:
        subprocess.run(["git", "remote", "set-url", "origin", nuosis_fake_remote], cwd=dest, check=True)

    # Fetch Nuosis provision script from GitHub and run it in --project-dir mode
    nuosis_script = Path(tempfile.gettempdir()) / "nuosis_provision_from_template.py"
    fetch_result = subprocess.run(
        ["gh", "api", "repos/Nuosis/clarify/contents/scripts/provision_from_template.py", "--jq", ".content"],
        capture_output=True, text=True, check=True,
    )
    nuosis_script.write_text(base64.b64decode(fetch_result.stdout).decode(), encoding="utf-8")
    nuosis_script.chmod(0o755)

    with tempfile.TemporaryDirectory(prefix="devflow-backend-provision-") as temp_dir:
        script_copy = Path(temp_dir) / "provision_from_template.py"
        shutil.copy2(nuosis_script, script_copy)
        result = subprocess.run(
            [sys.executable, str(script_copy), "--project-dir", str(dest.resolve()), "--yes"],
            capture_output=True, text=True, check=False,
            cwd=dest,
        )
    if result.returncode != 0:
        sys.stdout.write(result.stdout)
        sys.stderr.write(stderr := result.stderr)
        raise typer.Exit(code=2)

    if not (dest / ".git").exists():
        _run_git_command(["git", "init"], cwd=dest)
    _write_template_bootstrap_manifest(
        dest,
        template=template,
        project_name=project_name,
        provision_script_source=str(source_script),
    )


def _materialize_typescript_frontend(dest: Path) -> None:
    _write_repo_file(
        dest / "package.json",
        json.dumps(
            {
                "name": dest.name,
                "private": True,
                "version": "0.0.0",
                "scripts": {
                    "build": "tsc -p .",
                    "dev": "tsc -w -p .",
                    "test": "echo 'TODO' && exit 1",
                },
            },
            indent=2,
            sort_keys=True,
        )
        + "\n",
    )
    _write_repo_file(
        dest / "tsconfig.json",
        json.dumps(
            {"compilerOptions": {"module": "ESNext", "moduleResolution": "Bundler", "target": "ES2020"}},
            indent=2,
            sort_keys=True,
        )
        + "\n",
    )
    _write_repo_file(dest / "src" / "index.ts", "export const hello = 'world'\n")
    _write_repo_file(dest / "vercel.json", json.dumps({"version": 2}, indent=2, sort_keys=True) + "\n")
    _write_repo_file(
        dest / ".devflow-frontend-bootstrap.json",
        json.dumps({"default_deploy_target": _VERCEL_FREE_TIER}, indent=2, sort_keys=True) + "\n",
    )


def _materialize_monorepo_template(dest: Path, *, project_name: str) -> None:
    backend_dir = dest / "backend"
    frontend_dir = dest / "frontend"
    _provision_python_backend_template(backend_dir, template="python", project_name=f"{project_name} Backend")
    _materialize_typescript_frontend(frontend_dir)
    _write_repo_file(
        dest / "README.md",
        "\n".join(
            [
                f"# {project_name}",
                "",
                "Monorepo layout:",
                "- `backend/`: Python backend provisioned via Clarify COPY/provision-script semantics.",
                "- `frontend/`: TypeScript frontend scaffold with default deploy target Vercel free tier.",
                "",
                "Backend default deploy behavior remains local only until explicit user approval for production.",
                "Clarify command reference:",
                _CLARIFY_PROVISION_COMMAND_REFERENCE,
                "",
            ]
        ),
    )
    _write_repo_file(
        dest / ".gitignore",
        "\n".join(
            [
                ".DS_Store",
                ".devflow/",
                "backend/.venv/",
                "frontend/.vercel/",
                "frontend/node_modules/",
                "__pycache__/",
                "*.pyc",
                "",
            ]
        ),
    )
    _write_repo_file(
        dest / "package.json",
        json.dumps(
            {
                "name": dest.name,
                "private": True,
                "version": "0.0.0",
                "workspaces": ["frontend"],
            },
            indent=2,
            sort_keys=True,
        )
        + "\n",
    )
    _write_repo_file(
        dest / ".devflow" / "bootstrap_manifest.json",
        json.dumps(
            {
                "layout": "monorepo_py_ts",
                "backend": {
                    "path": "backend",
                    "provisioning_strategy": _COPY_PROVISION_STRATEGY,
                    "clarify_command_reference": _CLARIFY_PROVISION_COMMAND_REFERENCE,
                    "default_deploy_behavior": _LOCAL_ONLY_UNTIL_APPROVED,
                },
                "frontend": {
                    "path": "frontend",
                    "default_deploy_target": _VERCEL_FREE_TIER,
                },
            },
            indent=2,
            sort_keys=True,
        )
        + "\n",
    )


def _materialize_repo_template(dest: Path, *, template: str | None, project_name: str) -> None:
    if template in {"backend", "python"}:
        _provision_python_backend_template(dest, template=template, project_name=project_name)
        return

    if template == "monorepo-py-ts":
        _materialize_monorepo_template(dest, project_name=project_name)
        _run_git_command(["git", "init"], cwd=dest)
        return

    _write_repo_file(dest / "README.md", f"# {project_name}\n")
    if template == "typescript":
        _materialize_typescript_frontend(dest)
    elif template == "next":
        _write_repo_file(dest / "package.json", json.dumps({"name": dest.name, "private": True, "version": "0.0.0", "scripts": {"dev": "next dev"}}, indent=2, sort_keys=True) + "\n")
        _write_repo_file(dest / "next.config.js", "module.exports = {}\n")
        _write_repo_file(dest / "app" / "page.tsx", "export default function Page(){return null}\n")
    elif template == "react-native":
        _write_repo_file(dest / "package.json", json.dumps({"name": dest.name, "private": True, "version": "0.0.0", "scripts": {"start": "react-native start"}}, indent=2, sort_keys=True) + "\n")
        _write_repo_file(dest / "app.json", json.dumps({"name": dest.name, "displayName": dest.name}, indent=2, sort_keys=True) + "\n")
        _write_repo_file(dest / "src" / "App.tsx", "export default function App(){return null}\n")
    _run_git_command(["git", "init"], cwd=dest)


def _bootstrap_repo_local(repo_root: Path, *, project_name: str | None = None, imported: bool = False) -> None:
    dv = repo_root / ".devflow"
    dv.mkdir(parents=True, exist_ok=True)
    _ = ExecutionStore(dv / "execution.sqlite")
    _ensure_source_doc_scaffolding(repo_root)
    cfg = dv / "config.yaml"
    if not cfg.exists():
        lines = ["project:"]
        if project_name:
            lines.append(f"  name: {project_name}")
        if imported:
            lines.append("  imported: true")
        cfg.write_text("\n".join(lines) + "\n", encoding="utf-8")


def _create_new_project_repo(*, project_name: str, template: str | None) -> Path:
    repo_root = resolve_canonical_repo_root(project_name, None)
    repo_root.parent.mkdir(parents=True, exist_ok=True)
    if repo_root.exists() and any(repo_root.iterdir()):
        raise typer.BadParameter(f"canonical repo root already exists and is not empty: {repo_root}")
    repo_root.mkdir(parents=True, exist_ok=True)
    _materialize_repo_template(repo_root, template=template, project_name=project_name)
    _bootstrap_repo_local(repo_root, project_name=project_name)
    return repo_root


def _resolve_registered_repo_root(entry: dict[str, object], *, selector: str) -> tuple[str, Path]:
    project_id = str(entry.get("project_id") or "").strip()
    repo_root_raw = str(entry.get("repo_root") or "").strip()
    if not project_id or not repo_root_raw:
        raise ValueError(f"Registered project is missing repo_root for selector={selector}")
    repo_root = Path(repo_root_raw).expanduser().resolve()
    return project_id, repo_root


def _integrate_prepare_inline(*, idea_id: str, rr: Path) -> Path:
    return prepare_integration_payload(repo_root=rr, idea_id=idea_id)


@source_scope_app.command("resume")
def source_scope_resume(
    project_id: str = typer.Option(..., "--project-id", help="Project identifier"),
    intake_id: str = typer.Option(..., "--intake-id", help="Source intake identifier"),
    resume_from: str = typer.Option(..., "--resume-from", help="normalize_source_packet|extract_scope_candidates|shape_scope_document"),
    source: list[Path] | None = typer.Option(None, "--source", help="Original source document path (repeatable)"),
) -> None:
    repo_root, store = _store()
    source_refs: list[dict[str, object]] = []
    for path in source or []:
        source_refs.append({"type": "doc", "path": str(path), "title": path.name})
    if not source_refs:
        raise typer.BadParameter("provide original --source inputs so the resume pipeline key resolves correctly")
    result = run_source_to_scope_resume(
        repo_root=repo_root,
        store=store,
        project_id=project_id,
        source_intake_id=intake_id,
        source_refs=source_refs,
        resume_from=resume_from,
    )
    sys.stdout.write(result.message)
    if result.exit_code != 0:
        raise typer.Exit(code=result.exit_code)


@source_scope_app.command("run")
def source_scope_run(
    project_id: str = typer.Option(..., "--project-id", help="Project identifier"),
    intake_id: str = typer.Option(..., "--intake-id", help="Source intake identifier"),
    source: list[Path] | None = typer.Option(None, "--source", help="Source document path (repeatable)"),
    text: str | None = typer.Option(None, "--text", help="Inline source text"),
    requested_by: str = typer.Option("marcus", "--requested-by", help="Requester label"),
) -> None:
    repo_root, store = _store()
    source_refs: list[dict[str, object]] = []
    for path in source or []:
        source_refs.append({"type": "doc", "path": str(path), "title": path.name})
    if text:
        source_refs.append({"type": "notes", "title": f"{intake_id}.md", "text": text})
    if not source_refs:
        raise typer.BadParameter("provide at least one --source or --text input")

    result = run_source_to_scope_dag(
        repo_root=repo_root,
        store=store,
        project_id=project_id,
        source_intake_id=intake_id,
        source_refs=source_refs,
        requested_by=requested_by,
    )
    sys.stdout.write(result.message)
    if result.exit_code != 0:
        raise typer.Exit(code=result.exit_code)


@source_scope_app.command("gate")
def source_scope_gate(
    project_id: str = typer.Option(..., "--project-id", help="Project identifier"),
    source_packet: Path = typer.Option(..., "--source-packet", help="Path to normalized_source_packet.json"),
    scope_outline: Path = typer.Option(..., "--scope-outline", help="Path to scope_outline.json"),
) -> None:
    repo_root, store = _store()
    result = run_source_docs_to_scopes_dag(
        repo_root=repo_root,
        store=store,
        project_id=project_id,
        source_packet_path=source_packet,
        scope_outline_path=scope_outline,
    )
    sys.stdout.write(result.message)
    if result.exit_code != 0:
        raise typer.Exit(code=result.exit_code)


@ui_grounding_app.command("run")
def ui_grounding_run(
    project_id: str = typer.Option(..., "--project-id", help="Project identifier"),
    idea_id: str = typer.Option(..., "--idea-id", help="Idea identifier"),
    idea: Path = typer.Option(..., "--idea", help="Path to approved idea JSON"),
    story: list[Path] | None = typer.Option(None, "--story", help="Optional story/provisional story JSON path (repeatable)"),
    design_ref: list[Path] | None = typer.Option(None, "--design-ref", help="Optional design/Pencil reference path (repeatable)"),
    allow_code_design_enrichment: bool = typer.Option(False, "--allow-code-design-enrichment", help="Enable Pencil-gated code-to-design enrichment when first-pass grounding is weak."),
    pencil_app_path: Path | None = typer.Option(None, "--pencil-app-path", help="Optional Pencil.app override used by DAG preflight/enrichment gating."),
) -> None:
    repo_root, store = _store()
    result = run_ui_grounding_dag(
        repo_root=repo_root,
        store=store,
        project_id=project_id,
        idea_id=idea_id,
        idea_path=idea,
        story_paths=story or [],
        design_paths=design_ref or [],
        allow_code_design_enrichment=allow_code_design_enrichment,
        pencil_app_path=pencil_app_path,
    )
    sys.stdout.write(result.message)
    if result.exit_code != 0:
        raise typer.Exit(code=result.exit_code)


@ui_grounding_app.command("pencil-preflight")
def ui_grounding_pencil_preflight(
    app_path: Path | None = typer.Option(None, "--app-path", help="Optional Pencil.app override path"),
    artifact_path: Path | None = typer.Option(None, "--artifact-path", help="Optional output JSON path (default: .devflow/ui_grounding/pencil_preflight.json)"),
) -> None:
    repo_root, store = _store()
    result = run_pencil_preflight(repo_root=repo_root, store=store, app_path=app_path, artifact_path=artifact_path)
    sys.stdout.write(result.message)
    if result.exit_code != 0:
        raise typer.Exit(code=result.exit_code)


def _git_capture(repo_root: Path, *args: str) -> str:
    try:
        cp = subprocess.run(
            ["git", "-C", str(repo_root), *args],
            capture_output=True,
            text=True,
            check=False,
        )
    except Exception:
        return ""
    if cp.returncode != 0:
        return ""
    return cp.stdout.strip()


def _repo_snapshot(repo_root: Path) -> dict[str, object]:
    commit = _git_capture(repo_root, "rev-parse", "HEAD")
    dirty = bool(_git_capture(repo_root, "status", "--short"))
    return {"root": str(repo_root), "commit": commit, "dirty": dirty}


def _load_story_context(repo_root: Path, provided: str | None) -> tuple[dict[str, object], dict[str, object] | None]:
    base: dict[str, object] = {"provided": provided}
    if not provided:
        return base, None

    candidate = Path(provided)
    if not candidate.is_absolute():
        candidate = repo_root / candidate

    def _story_from_path(path: Path) -> dict[str, object]:
        blocks = parse_story_contracts_from_markdown(path.read_text(encoding="utf-8"), source_path=str(path))
        if not blocks:
            raise ValueError(f"no story contracts found in {path}")
        contract = blocks[0].contract
        return {
            "story_id": contract.story_id,
            "story_uuid": contract.story_uuid,
            "title": contract.title,
            "required_planes": list(contract.required_planes),
            "source_path": str(path),
        }

    try:
        if candidate.exists():
            story = _story_from_path(candidate)
            return {**base, **story}, story
    except Exception as exc:
        raise ValueError(str(exc)) from exc

    try:
        index = build_story_index(repo_root)
    except FileNotFoundError:
        return base, None

    match = next(
        (e for e in index.entries if provided in {e.story_id, e.story_uuid}),
        None,
    )
    if match is None:
        raise ValueError(f"story not found: {provided}")

    story = _story_from_path(Path(match.source_path))
    return {**base, **story}, story


def _rank_file_references(repo_root: Path, rows: list[tuple[str, str, str, str]], story: dict[str, object] | None) -> list[str]:
    def _rel(path_str: str) -> str:
        try:
            return Path(path_str).resolve().relative_to(repo_root.resolve()).as_posix()
        except Exception:
            return Path(path_str).as_posix()

    counts: dict[str, int] = {}
    for importer, _spec, _kind, _resolved in rows:
        counts[str(importer)] = counts.get(str(importer), 0) + 1

    ranked = sorted(counts.items(), key=lambda item: (-item[1], item[0]))
    files = [path for path, _count in ranked[:12]]
    if story and story.get("source_path"):
        story_rel = _rel(str(story["source_path"]))
        if story_rel not in files:
            files.insert(0, story_rel)
    return files[:12]


def _build_insight_payload(
    *,
    repo_root: Path,
    question: str,
    story_ref: str | None,
    mode: str,
) -> dict[str, object]:
    if mode not in {"explain", "classify", "integrate", "infra"}:
        raise ValueError(f"unsupported mode: {mode}")

    story_meta, story = _load_story_context(repo_root, story_ref)
    scan_roots = _parse_roots_arg(repo_root, None)
    rows = _scan_imports(repo_root, scan_roots)

    internal_module_ids = sorted(
        {str(resolved) for _importer, _spec, kind, resolved in rows if str(kind) == "internal" and str(resolved).startswith("module:")}
    )
    external_packages = sorted(
        {
            str(resolved)
            for _importer, _spec, kind, resolved in rows
            if str(kind) == "external" and str(resolved).startswith("pkg:") and str(resolved) != "pkg:"
        }
    )
    effect_tokens = {module_id: extract_effect_tokens(repo_root, module_id) for module_id in internal_module_ids}
    pathways_report = detect_pathways(imports_rows=rows, module_effect_tokens=effect_tokens)

    seams = list(pathways_report.get("seams") or [])
    top_seams = seams[:5]
    pathway_refs = [str(item.get("module_id")) for item in top_seams if isinstance(item, dict) and item.get("module_id")]
    file_refs = _rank_file_references(repo_root, rows, story)

    integration_points: list[dict[str, str]] = []
    for seam in top_seams[:3]:
        if not isinstance(seam, dict):
            continue
        module_id = str(seam.get("module_id") or "").strip()
        kind = str(seam.get("kind") or "").strip()
        if module_id:
            integration_points.append(
                {
                    "kind": kind or "module",
                    "target": module_id,
                    "reason": f"Detected as a {kind or 'candidate'} seam in the current import graph.",
                }
            )
    for path in file_refs[:3]:
        if not any(point["target"] == path for point in integration_points):
            integration_points.append(
                {
                    "kind": "file",
                    "target": path,
                    "reason": "Frequently connected importer in the current repo scan.",
                }
            )

    evidence: list[dict[str, object]] = [
        {"kind": "repo", "value": _repo_snapshot(repo_root)},
        {"kind": "imports", "value": {"internal_modules": len(internal_module_ids), "external_packages": len(external_packages)}},
    ]
    if story:
        evidence.append(
            {
                "kind": "story",
                "value": {
                    "story_id": story.get("story_id"),
                    "story_uuid": story.get("story_uuid"),
                    "required_planes": story.get("required_planes") or [],
                    "source_path": story.get("source_path"),
                },
            }
        )
    for seam in top_seams[:3]:
        evidence.append({"kind": "pathway", "value": seam})

    required_planes = list(story.get("required_planes") or []) if story else []
    summary_parts = [
        f"Scanned {len(file_refs)} referenced files and {len(internal_module_ids)} internal modules",
        f"for {mode} guidance on the current repo",
    ]
    if story:
        summary_parts.append(f"anchored to story {story.get('story_id')}")
    if pathway_refs:
        summary_parts.append(f"with likely seams around {', '.join(pathway_refs[:2])}")
    summary = " ".join(summary_parts) + "."

    if mode == "infra":
        recommendation = "Start from the repo-level seams and required ops/integration planes before adding new infrastructure surfaces."
    elif mode == "classify":
        recommendation = "Classify the request around the detected seams first, then map changes to the smallest set of touched modules and story planes."
    elif mode == "integrate":
        recommendation = "Integrate through the detected seam modules/files instead of introducing a parallel path; preserve the current story plane boundaries."
    else:
        recommendation = "Use the detected seams and referenced files as the first implementation reading list before changing code."

    confidence = "high" if story and pathway_refs else "medium" if (story or rows) else "low"
    unknowns: list[str] = []
    if not story:
        unknowns.append("No resolved story context was available.")
    if not pathway_refs:
        unknowns.append("No strong pathway candidates were detected from the current import graph.")
    if not external_packages:
        unknowns.append("No external package evidence was found in the scanned roots.")

    risks: list[str] = []
    repo_info = _repo_snapshot(repo_root)
    if bool(repo_info["dirty"]):
        risks.append("Repository has uncommitted changes; implementation guidance may drift before follow-on commands consume it.")
    if "ops" in required_planes or mode == "infra":
        risks.append("Operational changes may require registry validation and story-plane checks.")
    if "integrations" in required_planes or mode == "integrate":
        risks.append("Integration work may cross module seams and external package boundaries.")

    infra_needed: list[str] = []
    if mode == "infra" or "ops" in required_planes:
        infra_needed.append("Assess runtime/config/logging touchpoints before implementation.")
    if "integrations" in required_planes:
        infra_needed.append("Confirm external dependency and integration boundary expectations.")

    return {
        "question": question,
        "mode": mode,
        "repo": repo_info,
        "story": story_meta,
        "insight": {
            "summary": summary,
            "recommendation": recommendation,
            "confidence": confidence,
            "unknowns": unknowns,
            "risks": risks,
            "infra_needed": infra_needed,
            "integration_points": integration_points,
            "evidence": evidence,
        },
        "references": {
            "files": file_refs,
            "registry_modules": sorted([*internal_module_ids[:12], *external_packages[:12]]),
            "pathways": pathway_refs,
        },
    }


def _render_insight_text(payload: dict[str, object]) -> str:
    story = payload.get("story") or {}
    insight = payload.get("insight") or {}
    references = payload.get("references") or {}

    lines = [
        f"Question: {payload.get('question')}",
        f"Mode: {payload.get('mode')}",
        f"Story: {story.get('story_id') or story.get('provided') or 'none'}",
        f"Repo: {payload.get('repo', {}).get('root')}",
        "",
        f"Summary: {insight.get('summary')}",
        f"Recommendation: {insight.get('recommendation')}",
        f"Confidence: {insight.get('confidence')}",
        "",
        "Evidence:",
    ]

    for item in list(insight.get("evidence") or [])[:5]:
        if not isinstance(item, dict):
            continue
        lines.append(f"- {item.get('kind')}: {json.dumps(item.get('value'), sort_keys=True)}")

    for label, values in [
        ("Unknowns", list(insight.get("unknowns") or [])),
        ("Risks", list(insight.get("risks") or [])),
        ("Infra Needed", list(insight.get("infra_needed") or [])),
        ("Integration Points", [json.dumps(v, sort_keys=True) for v in list(insight.get("integration_points") or [])]),
        ("Files", list(references.get("files") or [])),
    ]:
        if not values:
            continue
        lines.append("")
        lines.append(f"{label}:")
        for value in values[:5]:
            lines.append(f"- {value}")

    return "\n".join(lines) + "\n"


def _arch_dir(root: Path) -> Path:
    return root / "ai_docs" / "context" / "v2" / "project_docs" / "architecture"


def _decisions_path(root: Path) -> Path:
    return _arch_dir(root) / "decisions.yaml"


def _registry_db_path(root: Path) -> Path:
    return root / ".devflow" / "registry.sqlite"


# ----------------------------
# Area2: Projects + Config
# ----------------------------

def _devflow_home() -> Path:
    """Resolve DEVFLOW_HOME.

    Contract (tests): when DEVFLOW_HOME is set, global state lives under
    $DEVFLOW_HOME/.devflow/...
    """

    base = os.environ.get("DEVFLOW_HOME") or os.environ.get("HOME")
    if base:
        return Path(base).expanduser().resolve()
    return Path.home().resolve()


def _global_devflow_dir() -> Path:
    return _devflow_home() / ".devflow"


def _projects_root() -> Path:
    return _global_devflow_dir() / "projects"


def _projects_registry_path() -> Path:
    return _global_devflow_dir() / "registry" / "projects.json"


def _read_projects_registry() -> dict[str, object]:
    reg_path = _projects_registry_path()
    try:
        raw = json.loads(reg_path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        return {"schema_version": 1, "projects": []}
    except Exception:
        return {"schema_version": 1, "projects": []}

    if not isinstance(raw, dict):
        return {"schema_version": 1, "projects": []}

    if raw.get("schema_version") != 1:
        # Forward-compat: treat unknown as empty.
        return {"schema_version": 1, "projects": []}

    projects = raw.get("projects")
    if not isinstance(projects, list):
        projects = []

    return {"schema_version": 1, "projects": projects}


def _write_projects_registry(reg: dict[str, object]) -> None:
    reg_path = _projects_registry_path()
    reg_path.parent.mkdir(parents=True, exist_ok=True)
    reg_path.write_text(json.dumps(reg, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def _parse_git_remote_origin(repo_root: Path) -> str | None:
    cfg = repo_root / ".git" / "config"
    try:
        text = cfg.read_text(encoding="utf-8")
    except FileNotFoundError:
        return None

    # Minimal parse: look for a `url = ...` line under [remote "origin"].
    in_origin = False
    for line in text.splitlines():
        line_stripped = line.strip()
        if line_stripped.startswith("[") and line_stripped.endswith("]"):
            in_origin = line_stripped.lower() == '[remote "origin"]'
            continue
        if not in_origin:
            continue
        m = re.match(r"url\s*=\s*(.+)$", line_stripped)
        if m:
            return m.group(1).strip()
    return None


def _infer_owner_repo(remote_url: str | None, repo_root: Path) -> tuple[str, str]:
    # Prefer remote URL inference.
    if remote_url:
        # Examples:
        # - https://github.com/Nuosis/devflow.git
        # - git@github.com:Nuosis/devflow.git
        m = re.search(r"[:/](?P<owner>[^/]+)/(?P<repo>[^/]+?)(?:\.git)?$", remote_url)
        if m:
            return (m.group("owner").lower(), m.group("repo").lower())

    # Fallback: use folder name.
    return ("local", repo_root.name.lower())


def _workspace_hash(remote_url: str | None, repo_root: Path) -> str:
    ident = (remote_url or f"local:{repo_root}").strip().lower()
    return sha256(ident.encode("utf-8")).hexdigest()[:8]


def _is_under(child: Path, parent: Path) -> bool:
    try:
        child.resolve().relative_to(parent.resolve())
        return True
    except Exception:
        return False


def _read_toml(path: Path) -> dict[str, object]:
    if tomllib is None:
        return {}
    try:
        return tomllib.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        return {}
    except Exception:
        return {}


def _install_devflow_hooks(repo_root: Path) -> None:
    """Install git hooks + CI enforcement stubs.

    This is best-effort and idempotent.
    """

    import subprocess

    git_dir = repo_root / ".git"
    if not git_dir.exists():
        return

    hooks_dir = repo_root / ".devflow" / "githooks"
    hooks_dir.mkdir(parents=True, exist_ok=True)

    pre_commit = hooks_dir / "pre-commit"
    if not pre_commit.exists():
        pre_commit.write_text(
            "\n".join(
                [
                    "#!/usr/bin/env bash",
                    "set -euo pipefail",
                    "# DevFlow enforcement (report-only, best-effort)",
                    "# If devflow is not on PATH, skip silently rather than blocking commits.",
                    "command -v devflow > /dev/null 2>&1 || exit 0",
                    "changed=$(git diff --cached --name-only | tr '\\n' ' ')",
                    "if [ -z \"$changed\" ]; then",
                    "  exit 0",
                    "fi",
                    "devflow enforce --changed $changed || true",
                    "",
                ]
            )
            + "\n",
            encoding="utf-8",
        )
        pre_commit.chmod(0o755)

    # Point git to repo-tracked hooks.
    subprocess.run(
        ["git", "config", "core.hooksPath", ".devflow/githooks"],
        cwd=str(repo_root),
        check=False,
        capture_output=True,
        text=True,
    )

    # CI stub (GitHub Actions). Best-effort.
    wf = repo_root / ".github" / "workflows" / "devflow-enforce.yml"
    if not wf.exists():
        wf.parent.mkdir(parents=True, exist_ok=True)
        wf.write_text(
            "\n".join(
                [
                    "name: devflow-enforce",
                    "on:",
                    "  pull_request:",
                    "  push:",
                    "    branches: [ main ]",
                    "jobs:",
                    "  enforce:",
                    "    runs-on: ubuntu-latest",
                    "    steps:",
                    "      - uses: actions/checkout@v4",
                    "        with:",
                    "          fetch-depth: 0",
                    "",
                    "      # Install DevFlow CLI (devflow-engine) from a separate repo.",
                    "      # Set DEVFLOW_ENGINE_REPO as an org/repo string (e.g. Nuosis/devflow_engine).",
                    "      - uses: actions/checkout@v4",
                    "        with:",
                    "          repository: ${{ vars.DEVFLOW_ENGINE_REPO || 'Nuosis/devflow_engine' }}",
                    "          path: devflow_engine",
                    "          fetch-depth: 1",
                    "",
                    "      - uses: astral-sh/setup-uv@v3",
                    "",
                    "      - name: Install devflow CLI",
                    "        run: |",
                    "          uv pip install --system -e ./devflow_engine",
                    "",
                    "      - name: DevFlow enforce (report-only)",
                    "        run: |",
                    "          if [ \"${GITHUB_EVENT_NAME}\" = \"push\" ]; then",
                    "            before=\"${{ github.event.before }}\"",
                    "            after=\"${{ github.sha }}\"",
                    "            changed=$(git diff --name-only \"$before\" \"$after\" | tr '\\n' ' ')",
                    "            devflow enforce --changed $changed",
                    "          else",
                    "            devflow enforce --root .",
                    "          fi",
                    "",
                ]
            )
            + "\n",
            encoding="utf-8",
        )


def _repo_registration_initialized(repo_root: Path) -> bool:
    db_path = repo_root / ".devflow" / "registry.sqlite"
    if not db_path.exists():
        return False
    try:
        conn = sqlite3.connect(str(db_path))
        row = conn.execute("select value from registry_meta where key='project_registration_state'").fetchone()
    except sqlite3.Error:
        return False
    finally:
        try:
            conn.close()
        except Exception:
            pass
    return bool(row and row[0] == "initialized")


def _ensure_source_doc_scaffolding(repo_root: Path) -> None:
    ensure_source_doc_scaffold(repo_root)


def _run_repo_registration_once(repo_root: Path, *, minimal: bool = True) -> None:
    repo_root = repo_root.resolve()
    if _repo_registration_initialized(repo_root):
        return
    prior_cwd = Path.cwd()
    stdout_buffer = io.StringIO()
    stderr_buffer = io.StringIO()
    try:
        os.chdir(repo_root)
        with redirect_stdout(stdout_buffer), redirect_stderr(stderr_buffer):
            register(roots=None, minimal=minimal)
    except typer.Exit as exc:
        if exc.exit_code not in (0, None):
            captured_stdout = stdout_buffer.getvalue()
            captured_stderr = stderr_buffer.getvalue()
            if captured_stdout:
                sys.stdout.write(captured_stdout)
            if captured_stderr:
                sys.stderr.write(captured_stderr)
            raise
    finally:
        os.chdir(prior_cwd)


@project_app.command("init")
def project_init(
    name: str | None = typer.Option(None, "--name", help="(Area9) Initialize local project state under <repo>/.devflow"),
    new: bool = typer.Option(False, "--new", help="Create a new project from scratch in the canonical DevFlow workspace"),
    template: str | None = typer.Option(None, "--template", help="New-project template: backend|clarify|python|typescript|monorepo-py-ts|next|react-native"),
    project_type: str | None = typer.Option(None, "--project-type", help="New-project type alias for template selection"),
) -> None:
    """Initialize a DevFlow-managed workspace for the current git repo.

    Contract (tests): creates $DEVFLOW_HOME/.devflow/projects/<owner>__<repo>__<hash>/
    and writes workspace-local .devflow/config.toml.
    """

    repo_root = get_paths().root
    paths = get_paths(repo_root)
    init_template = _normalize_init_template(template, project_type)

    if new:
        project_name = (name or "").strip()
        if not project_name:
            raise typer.BadParameter("--new requires --name")
        new_repo_root = _create_new_project_repo(project_name=project_name, template=init_template)
        result = run_project_registration_dag(
            repo_root=new_repo_root,
            workspace_path=new_repo_root,
            remote_url=None,
            project_name=project_name,
            command_name="project init --name --new",
            register_repo=lambda target_repo: _run_repo_registration_once(target_repo, minimal=True),
        )
        if result.exit_code != 0:
            sys.stderr.write(result.message)
            raise typer.Exit(code=result.exit_code)
        sys.stdout.write(f"project_id: {result.project_id}\n")
        sys.stdout.write(f"workspace: {new_repo_root}\n")
        sys.stdout.write(result.message)
        raise typer.Exit(code=0)

    if init_template is not None:
        raise typer.BadParameter("--template/--project-type require --new with project init")

    # Area 9 contract: allow initializing workspace-local .devflow state when a
    # name is provided (tests call: `devflow project init --name t`).
    if name is not None:
        paths.devflow_dir.mkdir(parents=True, exist_ok=True)
        _ = ExecutionStore(paths.execution_db)
        _ensure_source_doc_scaffolding(repo_root)

        # Seed a minimal local config for later commands.
        cfg_path = paths.devflow_dir / "config.yaml"
        if not cfg_path.exists():
            cfg_path.write_text(
                "\n".join(
                    [
                        "project:",
                        f"  name: {name}",
                        "",
                    ]
                ),
                encoding="utf-8",
            )

        result = run_project_registration_dag(
            repo_root=repo_root,
            workspace_path=repo_root,
            remote_url=_parse_git_remote_origin(repo_root),
            project_name=name,
            command_name="project init --name",
            register_repo=lambda target_repo: _run_repo_registration_once(target_repo, minimal=True),
        )
        if result.exit_code != 0:
            sys.stderr.write(result.message)
            raise typer.Exit(code=result.exit_code)
        console.print(str(paths.devflow_dir))
        sys.stdout.write(result.message)
        raise typer.Exit(code=0)

    remote_url = _parse_git_remote_origin(repo_root)
    owner, repo = _infer_owner_repo(remote_url, repo_root)
    h = _workspace_hash(remote_url, repo_root)
    _ensure_source_doc_scaffolding(repo_root)

    projects_root = _projects_root()
    projects_root.mkdir(parents=True, exist_ok=True)

    workspace = projects_root / f"{owner}__{repo}__{h}"
    (workspace / ".devflow").mkdir(parents=True, exist_ok=True)

    project_id = f"proj_{h}"
    created_at = datetime.now(timezone.utc).isoformat()

    cfg_path = workspace / ".devflow" / "config.toml"
    if not cfg_path.exists():
        cfg_path.write_text(
            "\n".join(
                [
                    f"project_id = \"{project_id}\"",
                    f"source_repo = \"{(remote_url or str(repo_root))}\"",
                    f"created_at = \"{created_at}\"",
                    "",
                ]
            ),
            encoding="utf-8",
        )

    # Upsert registry entry (idempotent)
    reg = _read_projects_registry()
    projects = list(reg.get("projects", []))  # type: ignore[arg-type]

    found = None
    for p in projects:
        if isinstance(p, dict) and p.get("remote_url") and remote_url and p.get("remote_url") == remote_url:
            found = p
            break
        if isinstance(p, dict) and p.get("workspace_path") == str(workspace):
            found = p
            break

    entry = {
        "project_id": (found.get("project_id") if isinstance(found, dict) and found.get("project_id") else project_id),
        "owner": owner,
        "repo": repo,
        "workspace_path": str(workspace),
        "remote_url": remote_url,
    }

    if found is None:
        projects.append(entry)
    else:
        idx = projects.index(found)
        projects[idx] = entry

    reg["projects"] = projects
    _write_projects_registry(reg)

    result = run_project_registration_dag(
        repo_root=repo_root,
        workspace_path=workspace,
        remote_url=remote_url,
        project_name=None,
        command_name="project init",
        register_repo=lambda target_repo: _run_repo_registration_once(target_repo, minimal=True),
    )
    if result.exit_code != 0:
        sys.stderr.write(result.message)
        raise typer.Exit(code=result.exit_code)

    console.print(str(workspace))
    sys.stdout.write(result.message)


@project_app.command("import")
def project_import(
    repo_spec: str = typer.Argument(..., help="GitHub owner/repo, GitHub URL, or destination directory when using --init"),
    init: str | None = typer.Option(None, "--init", help="Initialize a new blank repo from a template: python|typescript|monorepo-py-ts|next|react-native"),
    supabase_project_id: str | None = typer.Option(None, "--supabase-project-id", hidden=True),
) -> None:
    """Import a project into DevFlow.

    US2.7: clone from GitHub and register as an active project.
    US2.8: create a new blank repo from a template and register it.
    """

    def _normalize_github(repo_spec_in: str) -> tuple[str, str, str]:
        s = repo_spec_in.strip()
        if re.match(r"^[^/]+/[^/]+$", s):
            owner_s, repo_s = s.split("/", 1)
            owner_s = owner_s.lower()
            repo_s = repo_s.lower()
            return owner_s, repo_s, f"https://github.com/{owner_s}/{repo_s}.git"

        # Accept https://github.com/owner/repo(.git)
        m = re.match(r"^https://github\.com/(?P<owner>[^/]+)/(?P<repo>[^/]+?)(?:\.git)?/?$", s)
        if m:
            owner_s = m.group("owner").lower()
            repo_s = m.group("repo").lower()
            return owner_s, repo_s, f"https://github.com/{owner_s}/{repo_s}.git"

        # Accept git@github.com:owner/repo(.git)
        m = re.match(r"^git@github\.com:(?P<owner>[^/]+)/(?P<repo>[^/]+?)(?:\.git)?$", s)
        if m:
            owner_s = m.group("owner").lower()
            repo_s = m.group("repo").lower()
            return owner_s, repo_s, f"https://github.com/{owner_s}/{repo_s}.git"

        raise typer.Exit(code=2)

    # Template init mode (blank repo)
    if init is not None:
        dest = Path(repo_spec).expanduser().resolve()
        dest.mkdir(parents=True, exist_ok=True)

        # Fail if non-empty (conservative).
        if any(dest.iterdir()):
            # allow existing empty dir only
            raise typer.Exit(code=2)

        init_template = _normalize_init_template(init, None)
        _materialize_repo_template(dest, template=init_template, project_name=dest.name)
        _bootstrap_repo_local(dest, imported=True)
        result = run_project_registration_dag(
            repo_root=dest,
            workspace_path=dest,
            remote_url=None,
            project_name=dest.name,
            command_name="project import --init",
            register_repo=lambda target_repo: _run_repo_registration_once(target_repo, minimal=True),
            supabase_project_id=supabase_project_id,
        )
        if result.exit_code != 0:
            sys.stderr.write(result.message)
            raise typer.Exit(code=result.exit_code)

        sys.stdout.write(f"project_id: {result.project_id}\n")
        sys.stdout.write(f"workspace: {dest}\n")
        sys.stdout.write(result.message)
        raise typer.Exit(code=0)

    # GitHub clone mode
    owner, repo, remote_url = _normalize_github(repo_spec)
    repo_root = resolve_canonical_repo_root(repo, str(Path.home() / "repos" / repo))
    repo_root.parent.mkdir(parents=True, exist_ok=True)

    if not (repo_root / ".git").exists():
        r_clone = subprocess.run(["git", "clone", remote_url, str(repo_root)], capture_output=True, text=True, check=False)
        if r_clone.returncode != 0:
            sys.stdout.write(r_clone.stdout)
            sys.stderr.write(r_clone.stderr)
            raise typer.Exit(code=2)

    _bootstrap_repo_local(repo_root)
    result = run_project_registration_dag(
        repo_root=repo_root,
        workspace_path=repo_root,
        remote_url=remote_url,
        project_name=None,
        command_name="project import",
        register_repo=lambda target_repo: _run_repo_registration_once(target_repo, minimal=True),
        supabase_project_id=supabase_project_id,
    )
    if result.exit_code != 0:
        sys.stderr.write(result.message)
        raise typer.Exit(code=result.exit_code)

    sys.stdout.write(f"project_id: {result.project_id}\n")
    sys.stdout.write(f"workspace: {repo_root}\n")
    sys.stdout.write(result.message)


@project_app.command("list")
def project_list(json_out: bool = typer.Option(False, "--json", help="Emit JSON")) -> None:
    reg = _read_projects_registry()
    if json_out:
        sys.stdout.write(json.dumps(reg) + "\n")
        return

    projects = reg.get("projects", [])
    t = Table("project_id", "owner", "repo", "workspace_path")
    if isinstance(projects, list):
        for p in projects:
            if not isinstance(p, dict):
                continue
            t.add_row(str(p.get("project_id", "")), str(p.get("owner", "")), str(p.get("repo", "")), str(p.get("workspace_path", "")))
    console.print(t)


@project_app.command("info")
def project_info(
    project: str = typer.Option(..., "--project", help="Project id, GitHub URL, owner/repo, or workspace path"),
    json_out: bool = typer.Option(False, "--json", help="Emit JSON"),
) -> None:
    """Show project metadata and queue summary for a project."""
    project_id, repo_root = _resolve_worker_project(project)
    store = ExecutionStore(repo_root / ".devflow" / "execution.sqlite")

    with store._connect() as conn:
        proj_row = conn.execute(
            "SELECT project_id, name, repo_root, metadata_json FROM projects WHERE project_id=?",
            (project_id,),
        ).fetchone()

        if proj_row is None:
            sys.stdout.write(f"Project {project_id} not found in local DB.\n")
            raise typer.Exit(code=2)

        # Queue counts
        def queue_counts(table: str) -> dict[str, int]:
            rows = conn.execute(f"SELECT status, COUNT(*) as cnt FROM {table} GROUP BY status").fetchall()
            return {r["status"]: r["cnt"] for r in rows}

        story_q = queue_counts("story_queue")
        idea_q = queue_counts("idea_queue")
        integration_q = queue_counts("integration_queue")
        recovery_q = queue_counts("recovery_queue")

        # Worker state
        worker_row = conn.execute(
            "SELECT worker_id, status, active_queue_type, active_item_id, updated_at FROM project_workers WHERE project_id=? ORDER BY updated_at DESC LIMIT 1",
            (project_id,),
        ).fetchone()

        payload = {
            "project_id": proj_row["project_id"],
            "name": proj_row["name"],
            "repo_root": proj_row["repo_root"],
            "metadata": json.loads(proj_row["metadata_json"]) if proj_row["metadata_json"] else {},
            "queues": {
                "story_queue": story_q,
                "idea_queue": idea_q,
                "integration_queue": integration_q,
                "recovery_queue": recovery_q,
            },
            "worker": {
                "worker_id": worker_row["worker_id"] if worker_row else None,
                "status": worker_row["status"] if worker_row else "stopped",
                "active_queue_type": worker_row["active_queue_type"] if worker_row else None,
                "active_item_id": worker_row["active_item_id"] if worker_row else None,
                "updated_at": worker_row["updated_at"] if worker_row else None,
            },
        }

    if json_out:
        sys.stdout.write(json.dumps(payload, sort_keys=True, indent=2) + "\n")
        return

    sys.stdout.write(f"project_id: {payload['project_id']}\n")
    sys.stdout.write(f"name: {payload['name']}\n")
    sys.stdout.write(f"repo_root: {payload['repo_root']}\n")
    sys.stdout.write("queues:\n")
    for qname, counts in payload["queues"].items():
        sys.stdout.write(f"  {qname}: {counts}\n")
    sys.stdout.write("worker:\n")
    sys.stdout.write(f"  worker_id: {payload['worker']['worker_id']}\n")
    sys.stdout.write(f"  status: {payload['worker']['status']}\n")
    sys.stdout.write(f"  active_queue_type: {payload['worker']['active_queue_type']}\n")
    sys.stdout.write(f"  active_item_id: {payload['worker']['active_item_id']}\n")


@project_app.command("remove")
def project_remove(
    project_id: str = typer.Argument(...),
    delete_workspace: bool = typer.Option(False, "--delete-workspace"),
    yes: bool = typer.Option(False, "--yes"),
) -> None:
    reg = _read_projects_registry()
    projects = reg.get("projects", [])
    if not isinstance(projects, list):
        projects = []

    target: dict[str, object] | None = None
    kept: list[object] = []
    for p in projects:
        if isinstance(p, dict) and p.get("project_id") == project_id:
            target = p
        else:
            kept.append(p)

    if target is None:
        raise typer.Exit(code=2)

    ws_path_raw = str(target.get("workspace_path", ""))
    ws_path = Path(ws_path_raw)

    if delete_workspace:
        if not yes:
            ok = typer.confirm(f"Delete workspace at {ws_path}?")
            if not ok:
                raise typer.Exit(code=1)

        if not _is_under(ws_path, _projects_root()):
            console.print("Refuse to delete workspace outside projects root")
            raise typer.Exit(code=2)

        if ws_path.exists():
            shutil.rmtree(ws_path)

    reg["projects"] = kept
    _write_projects_registry(reg)
    console.print("ok")


def _find_workspace_for_project(project_id: str | None) -> Path | None:
    """Resolve a workspace path for a given project id.

    Contract (tests): callers may supply --project outside a repo context.

    Resolution order:
    1) projects registry entry matching project_id
    2) if exactly one workspace directory exists under $DEVFLOW_HOME/.devflow/projects,
       use it as a deterministic fallback.
    """

    # Registry lookup
    if project_id:
        reg = _read_projects_registry()
        projects = reg.get("projects", [])
        if isinstance(projects, list):
            for p in projects:
                if not isinstance(p, dict):
                    continue
                if p.get("project_id") == project_id and p.get("workspace_path"):
                    try:
                        return Path(str(p["workspace_path"]))
                    except Exception:
                        return None

    # Fallback: only workspace present
    root = _projects_root()
    try:
        if not root.exists():
            return None
        dirs = sorted([p for p in root.iterdir() if p.is_dir()])
    except Exception:
        return None

    if len(dirs) == 1:
        return dirs[0]
    return None


def _resolve_worker_project(selector: str) -> tuple[str, Path]:
    entry = resolve_project_entry(selector)
    if entry is not None:
        return _resolve_registered_repo_root(entry, selector=selector)

    candidate = Path(selector).expanduser()
    if candidate.exists():
        repo_root = candidate.resolve()
        db_path = repo_root / ".devflow" / "execution.sqlite"
        if db_path.exists():
            store = ExecutionStore(db_path)
            with store._connect() as conn:
                row = conn.execute("SELECT project_id FROM projects WHERE repo_root IN (?, '.') ORDER BY created_at DESC LIMIT 1", (str(repo_root),)).fetchone()
                if row is not None and row[0]:
                    return str(row[0]), repo_root
                row = conn.execute("SELECT project_id FROM idea_creation_queue ORDER BY updated_at DESC LIMIT 1").fetchone()
                if row is not None and row[0]:
                    return str(row[0]), repo_root
                row = conn.execute("SELECT project_id FROM idea_queue ORDER BY updated_at DESC LIMIT 1").fetchone()
                if row is not None and row[0]:
                    return str(row[0]), repo_root

    # Selector is a project_id not in global registry — search local DBs under ~/repos
    if selector.startswith("proj_"):
        repos_root = Path("~/repos").expanduser()
        for db_path in repos_root.glob("*/.devflow/execution.sqlite"):
            try:
                store = ExecutionStore(db_path)
                with store._connect() as conn:
                    row = conn.execute(
                        "SELECT project_id, repo_root FROM projects WHERE project_id=? LIMIT 1",
                        (selector,),
                    ).fetchone()
                    if row is not None and row[0]:
                        repo_root = Path(row[1]).resolve()
                        return str(row[0]), repo_root
            except Exception:
                continue

    raise typer.Exit(code=2)


def _exit_if_worker_guarded(*, repo_root: Path, json_out: bool) -> None:
    block = get_worker_guard_block(repo_root=repo_root)
    if block is None:
        return
    payload = {
        "error": "worker_start_blocked",
        "reason": block.reason,
        "source": block.source,
    }
    if json_out:
        sys.stdout.write(json.dumps(payload, sort_keys=True) + "\n")
    else:
        sys.stderr.write(block.reason + "\n")
    raise typer.Exit(code=2)


@worker_app.command("start")
def worker_start(
    project: str = typer.Option(..., "--project", help="Project id, GitHub URL, owner/repo, or workspace path"),
    once: bool = typer.Option(False, "--once", help="Process at most one queued item and exit"),
    json_out: bool = typer.Option(False, "--json", help="Emit JSON"),
    role: str = typer.Option(
        "both",
        "--role",
        help="Worker role: 'analyst' (claim 'open' user_report rows, run "
        "observability only), 'fix' (claim 'observed' rows, run the rest "
        "of the DAG), or 'both' (legacy default, run full DAG per item)",
    ),
) -> None:
    """[CANONICAL] Start the queue-driven worker for a project.

    This is the primary automated execution path for DevFlow. The worker
    processes the idea queue and integration queue, running the full
    idea → story → implementation pipeline without manual intervention.

    Use `--once` to process a single queued item (useful for debugging or
    scripted one-shot runs). Without `--once`, drains the full queue.

    Kill switch checks before any work starts:
    - DEVFLOW_DO_NOT_RUN_WORKER=true
    - ~/.devflow/do-not-run-worker
    - ~/.devflow/config.toml with [worker] do_not_run = true
    - <repo>/.devflow/do-not-run-worker
    - <repo>/.devflow/config.toml with [worker] do_not_run = true

    See also: `worker stop`, `worker report`, `worker recover`.
    """
    project_id, repo_root = _resolve_worker_project(project)
    _exit_if_worker_guarded(repo_root=repo_root, json_out=json_out)

    role_normalized = (role or "both").strip().lower()
    if role_normalized not in {"analyst", "fix", "both"}:
        raise typer.BadParameter(f"--role must be analyst|fix|both, got {role!r}")
    effective_role: str | None = None if role_normalized == "both" else role_normalized

    # Per-role process lock so analyst+fix can run concurrently per
    # project. Analyst pool (N parallel analysts) also passes through
    # since the lock keys on (project, role) — multiple analyst
    # processes coexist; the per-row claim is the actual serialization.
    running_block = _check_no_running_worker_process(
        repo_root=repo_root, project_id=project_id, role=effective_role,
    )
    if running_block is not None:
        if json_out:
            sys.stdout.write(json.dumps({"error": "worker_start_blocked", "reason": running_block.reason, "source": running_block.source}, sort_keys=True) + "\n")
        else:
            sys.stderr.write(running_block.reason + "\n")
        raise typer.Exit(code=2)

    store = ExecutionStore(repo_root / ".devflow" / "execution.sqlite")

    if once:
        result = process_worker_once(project_id=project_id, repo_root=repo_root, store=store, role=effective_role)
        payload = {
            "mode": "once",
            "project_id": result.project_id,
            "worker_id": result.worker_id,
            "processed": result.processed,
            "report": result.report,
        }
        if json_out:
            sys.stdout.write(json.dumps(payload, sort_keys=True) + "\n")
            return
        sys.stdout.write(f"project_id: {project_id}\n")
        sys.stdout.write(f"worker_id: {result.worker_id}\n")
        sys.stdout.write(f"processed: {json.dumps(result.processed, sort_keys=True)}\n")
        return

    drain_result = drain_project_queue(project_id=project_id, repo_root=repo_root, store=store)
    payload = {
        "mode": "drain",
        "project_id": drain_result.project_id,
        "processed_count": drain_result.processed_count,
        "processed": drain_result.processed,
        "stopped_reason": drain_result.stopped_reason,
        "report": drain_result.final_report,
    }
    if json_out:
        sys.stdout.write(json.dumps(payload, sort_keys=True) + "\n")
        return
    sys.stdout.write(f"project_id: {project_id}\n")
    sys.stdout.write(f"processed_count: {drain_result.processed_count}\n")
    sys.stdout.write(f"stopped_reason: {drain_result.stopped_reason}\n")


@integration_app.command("prepare")
def integrate_prepare(
    idea_id: str = typer.Argument(..., help="Idea identifier"),
    repo_root: Path | None = typer.Option(None, "--repo-root", help="Repo root override"),
    json_out: bool = typer.Option(False, "--json", help="Emit JSON"),
) -> None:
    rr = (repo_root.expanduser().resolve() if repo_root else _repo_root())
    payload_path = prepare_integration_payload(repo_root=rr, idea_id=idea_id)
    payload = {"idea_id": idea_id, "payload_path": str(payload_path)}
    if json_out:
        sys.stdout.write(json.dumps(payload, sort_keys=True) + "\n")
        return
    sys.stdout.write(f"idea_id: {idea_id}\n")
    sys.stdout.write(f"payload_path: {payload_path}\n")


@integration_app.command("enqueue")
def integrate_enqueue(
    idea_id: str = typer.Argument(..., help="Idea identifier"),
    project: str | None = typer.Option(None, "--project", help="Registered project selector (project id / path / owner-repo)"),
    title: str | None = typer.Option(None, "--title", help="Queue title override"),
    repo_root: Path | None = typer.Option(None, "--repo-root", help="Repo root override"),
    payload_path: Path | None = typer.Option(None, "--payload-path", help="Existing integration payload.json path"),
    json_out: bool = typer.Option(False, "--json", help="Emit JSON"),
) -> None:
    rr = (repo_root.expanduser().resolve() if repo_root else _repo_root())
    store = ExecutionStore(rr / ".devflow" / "execution.sqlite")
    project_id: str | None = None
    if project:
        project_id, rr = _resolve_worker_project(project)
        store = ExecutionStore(rr / ".devflow" / "execution.sqlite")
    else:
        entry = find_project_for_repo_root(rr)
        if entry is not None:
            project_id = str(entry.get("project_id") or "").strip() or None
    effective_payload = payload_path.expanduser().resolve() if payload_path else prepare_integration_payload(repo_root=rr, idea_id=idea_id)
    enqueue_run = store.start_run(kind="integration.enqueue", repo_root=rr, args={"idea_id": idea_id})
    queue_id = store.enqueue_integration_task(
        project_id=project_id,
        enqueue_run_id=enqueue_run.run_id,
        idea_id=idea_id,
        title=title or f"Integration: {idea_id}",
        integration_payload_path=str(effective_payload),
    )
    payload = {
        "integration_queue_id": queue_id,
        "project_id": project_id,
        "idea_id": idea_id,
        "payload_path": str(effective_payload),
    }
    if json_out:
        sys.stdout.write(json.dumps(payload, sort_keys=True) + "\n")
        return
    sys.stdout.write(json.dumps(payload, sort_keys=True) + "\n")


@integration_app.command("run")
def integrate_run(
    idea_id: str = typer.Argument(..., help="Idea identifier"),
    repo_root: Path | None = typer.Option(None, "--repo-root", help="Repo root override"),
    json_out: bool = typer.Option(False, "--json", help="Emit JSON"),
) -> None:
    rr = (repo_root.expanduser().resolve() if repo_root else _repo_root())
    payload_path = prepare_integration_payload(repo_root=rr, idea_id=idea_id)
    payload = json.loads(payload_path.read_text(encoding="utf-8"))
    result = run_integration_dag(
        repo_root=rr,
        idea_id=idea_id,
        implemented_idea=dict(payload.get("implemented_idea") or {}),
        implemented_stories=list(payload.get("implemented_stories") or []),
        code_evidence=list(payload.get("code_evidence") or []),
        source_docs=list(payload.get("source_docs") or []),
    )
    entry = find_project_for_repo_root(rr)
    project_id = None if entry is None else str(entry.get("project_id") or "").strip() or None
    if project_id:
        run = ExecutionStore(rr / ".devflow" / "execution.sqlite").start_run(kind="integration.manual", repo_root=rr, args={"idea_id": idea_id})
        _sync_integration_to_supabase(idea_id=idea_id, project_id=project_id, run_id=run.run_id, result=result, status=("completed" if result.exit_code == 0 else "failed"))
    payload_out = {
        "idea_id": idea_id,
        "exit_code": result.exit_code,
        "message": result.message,
        "pipeline_dir": str(result.pipeline_dir),
        "artifacts": result.artifacts,
        "iterations_used": result.iterations_used,
    }
    if json_out:
        sys.stdout.write(json.dumps(payload_out, sort_keys=True) + "\n")
    else:
        sys.stdout.write(json.dumps(payload_out, sort_keys=True) + "\n")
    if result.exit_code != 0:
        raise typer.Exit(code=result.exit_code)


@integration_app.command("status")
def integrate_status(
    idea_id: str = typer.Argument(..., help="Idea identifier"),
    repo_root: Path | None = typer.Option(None, "--repo-root", help="Repo root override"),
    json_out: bool = typer.Option(False, "--json", help="Emit JSON"),
) -> None:
    rr = (repo_root.expanduser().resolve() if repo_root else _repo_root())
    idea_dir = rr / ".devflow" / "ideas" / idea_id
    current_dir = idea_dir / "integration" / "current"
    runs_root = idea_dir / "integration" / "runs"
    legacy_root = idea_dir / "pipelines" / "integration_dag"
    latest_run = None
    for root in [runs_root, legacy_root]:
        if root.exists():
            runs = sorted([p for p in root.iterdir() if p.is_dir()])
            if runs:
                candidate = runs[-1]
                if latest_run is None or candidate.stat().st_mtime > latest_run.stat().st_mtime:
                    latest_run = candidate
    payload = {
        "idea_id": idea_id,
        "idea_dir": str(idea_dir),
        "current_dir": str(current_dir),
        "current_exists": current_dir.exists(),
        "latest_pipeline_run": None if latest_run is None else str(latest_run),
        "payload_exists": (idea_dir / "integration_payload.json").exists(),
    }
    if json_out:
        sys.stdout.write(json.dumps(payload, sort_keys=True) + "\n")
        return
    sys.stdout.write(json.dumps(payload, sort_keys=True) + "\n")


@integration_app.command("backfill")
def integrate_backfill(
    repo_root: Path | None = typer.Option(None, "--repo-root", help="Repo root override"),
    enqueue: bool = typer.Option(False, "--enqueue", help="Also enqueue missing payloads into integration_queue"),
    current: bool = typer.Option(True, "--current/--no-current", help="Backfill canonical integration/current artifacts from best prior run"),
    json_out: bool = typer.Option(False, "--json", help="Emit JSON"),
) -> None:
    rr = (repo_root.expanduser().resolve() if repo_root else _repo_root())
    ideas_root = rr / ".devflow" / "ideas"
    store = ExecutionStore(rr / ".devflow" / "execution.sqlite")
    entry = find_project_for_repo_root(rr)
    project_id = None if entry is None else str(entry.get("project_id") or "").strip() or None
    results: list[dict[str, Any]] = []
    if ideas_root.exists():
        for idea_dir in sorted([p for p in ideas_root.iterdir() if p.is_dir()]):
            idea_id = idea_dir.name
            payload_path = prepare_integration_payload(repo_root=rr, idea_id=idea_id)
            row: dict[str, Any] = {"idea_id": idea_id, "payload_path": str(payload_path)}
            if current:
                row["current_backfill"] = backfill_integration_current(repo_root=rr, idea_id=idea_id)
            if enqueue:
                run = store.start_run(kind="integration.backfill", repo_root=rr, args={"idea_id": idea_id})
                row["integration_queue_id"] = store.enqueue_integration_task(
                    project_id=project_id,
                    enqueue_run_id=run.run_id,
                    idea_id=idea_id,
                    title=f"Integration: {idea_id}",
                    integration_payload_path=str(payload_path),
                )
            results.append(row)
    payload = {"repo_root": str(rr), "results": results}
    if json_out:
        sys.stdout.write(json.dumps(payload, sort_keys=True) + "\n")
        return
    sys.stdout.write(json.dumps(payload, sort_keys=True) + "\n")


@worker_app.command("stop")
def worker_stop(
    project: str = typer.Option(..., "--project", help="Project id, GitHub URL, owner/repo, or workspace path"),
    json_out: bool = typer.Option(False, "--json", help="Emit JSON"),
) -> None:
    project_id, repo_root = _resolve_worker_project(project)
    store = ExecutionStore(repo_root / ".devflow" / "execution.sqlite")
    payload = store.stop_project_worker(project_id=project_id)
    if json_out:
        sys.stdout.write(json.dumps(payload, sort_keys=True) + "\n")
        return
    sys.stdout.write(f"project_id: {project_id}\n")
    sys.stdout.write(f"status: {payload.get('status')}\n")


@worker_app.command("report")
def worker_report(
    project: str = typer.Option(..., "--project", help="Project id, GitHub URL, owner/repo, or workspace path"),
    json_out: bool = typer.Option(False, "--json", help="Emit JSON"),
) -> None:
    project_id, repo_root = _resolve_worker_project(project)
    store = ExecutionStore(repo_root / ".devflow" / "execution.sqlite")
    payload = store.get_project_worker_report(project_id=project_id)
    if json_out:
        sys.stdout.write(json.dumps(payload, sort_keys=True) + "\n")
        return
    sys.stdout.write(f"project_id: {project_id}\n")
    sys.stdout.write(f"status: {payload.get('status')}\n")
    sys.stdout.write(f"active_queue_type: {payload.get('active_queue_type')}\n")
    sys.stdout.write(f"active_item_id: {payload.get('active_item_id')}\n")
    sys.stdout.write(f"current_run_id: {payload.get('current_run_id')}\n")
    sys.stdout.write(f"current_node_exec_id: {payload.get('current_node_exec_id')}\n")


@worker_app.command("supabase-events")
def worker_supabase_events(
    once: bool = typer.Option(False, "--once", help="Process at most one queued Supabase event and exit"),
    sleep_seconds: float = typer.Option(3.0, "--sleep-seconds", help="Sleep duration between idle polls (also max wait time when realtime is active)"),
    max_iterations: int | None = typer.Option(None, "--max-iterations", min=1, help="Stop after this many loop iterations"),
    realtime: bool = typer.Option(True, "--realtime/--no-realtime", help="Use Supabase Realtime WebSocket for event-driven dispatch (falls back to polling on disconnect)"),
    json_out: bool = typer.Option(False, "--json", help="Emit JSON"),
) -> None:
    loop = DevflowEventWorkerLoopService(sleep_seconds=sleep_seconds, max_iterations=max_iterations, use_realtime=realtime)
    if once:
        result = loop.run_once()
        payload = {
            "mode": "once",
            "processed": result.processed,
            "failed": result.failed,
            "idle": result.idle,
        }
        if json_out:
            sys.stdout.write(json.dumps(payload, sort_keys=True) + "\n")
            return
        sys.stdout.write(json.dumps(payload, sort_keys=True) + "\n")
        return

    result = loop.run_forever()
    payload = {
        "mode": "loop",
        "processed": result.processed,
        "failed": result.failed,
        "idle": result.idle,
        "max_iterations": max_iterations,
        "sleep_seconds": sleep_seconds,
        "realtime": realtime,
    }
    if json_out:
        sys.stdout.write(json.dumps(payload, sort_keys=True) + "\n")
        return
    sys.stdout.write(json.dumps(payload, sort_keys=True) + "\n")


@source_docs_app.command("status")
def source_docs_status(
    repo: Path = typer.Option(Path("."), "--repo", help="Repo root"),
    json_out: bool = typer.Option(False, "--json", help="Emit JSON"),
) -> None:
    repo_root = repo.expanduser().resolve()
    plan = detect_source_doc_changes(repo_root)
    payload = {
        "repo_root": str(repo_root),
        "changed_docs": plan.changed_docs,
        "source_hashes": plan.source_hashes,
        "previous_hashes": plan.previous_hashes,
        "state_path": str(plan.state_path),
    }
    if json_out:
        sys.stdout.write(json.dumps(payload, indent=2, sort_keys=True) + "\n")
        return
    sys.stdout.write(f"repo_root: {repo_root}\n")
    sys.stdout.write(f"changed_docs: {json.dumps(plan.changed_docs, sort_keys=True)}\n")
    sys.stdout.write(f"state_path: {plan.state_path}\n")


@source_docs_app.command("queue-sync")
def source_docs_queue_sync(
    repo: Path = typer.Option(Path("."), "--repo", help="Repo root"),
    project_id: str | None = typer.Option(None, "--project-id", help="Optional project id to associate with the queued task"),
    json_out: bool = typer.Option(False, "--json", help="Emit JSON"),
) -> None:
    repo_root = repo.expanduser().resolve()
    store = ExecutionStore(repo_root / ".devflow" / "execution.sqlite")
    queued = enqueue_source_doc_update_if_needed(store=store, project_id=project_id, repo_root=repo_root)
    payload = {
        "repo_root": str(repo_root),
        "enqueued": queued.enqueued,
        "changed_docs": queued.plan.changed_docs,
        "task": queued.task,
    }
    if json_out:
        sys.stdout.write(json.dumps(payload, indent=2, sort_keys=True) + "\n")
        return
    sys.stdout.write(f"repo_root: {repo_root}\n")
    sys.stdout.write(f"enqueued: {str(queued.enqueued).lower()}\n")
    sys.stdout.write(f"changed_docs: {json.dumps(queued.plan.changed_docs, sort_keys=True)}\n")
    if queued.task is not None:
        sys.stdout.write(f"task_id: {queued.task.get('task_id')}\n")


@source_docs_app.command("run-sync")
def source_docs_run_sync(
    repo: Path = typer.Option(Path("."), "--repo", help="Repo root"),
    changed_doc: list[str] | None = typer.Option(None, "--changed-doc", help="Restrict regeneration to specific source doc filenames"),
    json_out: bool = typer.Option(False, "--json", help="Emit JSON"),
) -> None:
    repo_root = repo.expanduser().resolve()
    result = apply_source_doc_updates(repo_root, changed_docs=changed_doc or None)
    payload = {
        "repo_root": str(repo_root),
        "changed_docs": result.changed_docs,
        "updated_outputs": result.updated_outputs,
        "state_path": str(result.state_path),
    }
    if json_out:
        sys.stdout.write(json.dumps(payload, indent=2, sort_keys=True) + "\n")
        return
    sys.stdout.write(f"repo_root: {repo_root}\n")
    sys.stdout.write(f"changed_docs: {json.dumps(result.changed_docs, sort_keys=True)}\n")
    sys.stdout.write(f"updated_outputs: {json.dumps(result.updated_outputs, sort_keys=True)}\n")


@source_docs_app.command("worker")
def source_docs_worker(
    repo: Path = typer.Option(Path("."), "--repo", help="Repo root"),
    worker_id: str = typer.Option("source-doc-updater", "--worker-id", help="Worker id"),
    json_out: bool = typer.Option(False, "--json", help="Emit JSON"),
) -> None:
    repo_root = repo.expanduser().resolve()
    store = ExecutionStore(repo_root / ".devflow" / "execution.sqlite")
    result = process_source_doc_update_once(store=store, repo_root=repo_root, worker_id=worker_id)
    payload = {
        "worker_id": result.worker_id,
        "queue_name": result.queue_name,
        "task": result.task,
        "outcome": result.outcome,
    }
    if json_out:
        sys.stdout.write(json.dumps(payload, indent=2, sort_keys=True) + "\n")
        return
    sys.stdout.write(f"worker_id: {result.worker_id}\n")
    sys.stdout.write(f"queue_name: {result.queue_name}\n")
    sys.stdout.write(f"task: {json.dumps(result.task, sort_keys=True) if result.task else 'null'}\n")
    sys.stdout.write(f"outcome: {json.dumps(result.outcome, sort_keys=True) if result.outcome else 'null'}\n")


@worker_app.command("recover")
def worker_recover(
    project: str = typer.Option(..., "--project", help="Project id, GitHub URL, owner/repo, or workspace path"),
    reason: str = typer.Option("worker process died before cleanup", "--reason", help="Failure message to record"),
    json_out: bool = typer.Option(False, "--json", help="Emit JSON"),
) -> None:
    project_id, repo_root = _resolve_worker_project(project)
    store = ExecutionStore(repo_root / ".devflow" / "execution.sqlite")
    payload = reconcile_stale_worker(project_id=project_id, repo_root=repo_root, store=store, reason=reason) or {"reconciled": False}
    if json_out:
        sys.stdout.write(json.dumps(payload, indent=2, sort_keys=True) + "\n")
        return
    if not payload.get("reconciled"):
        sys.stdout.write("no stale worker state to recover\n")
        return
    sys.stdout.write(f"reconciled worker_id: {payload.get('worker_id')}\n")
    sys.stdout.write(f"queue_type: {payload.get('queue_type')}\n")
    sys.stdout.write(f"item_id: {payload.get('item_id')}\n")
    sys.stdout.write(f"run_id: {payload.get('run_id')}\n")

@worker_app.command("failed-ideas")
def worker_failed_ideas(
    project: str = typer.Option(..., "--project", help="Project id, GitHub URL, owner/repo, or workspace path"),
    limit: int = typer.Option(10, "--limit", min=1, help="Max failed items to show"),
    json_out: bool = typer.Option(False, "--json", help="Emit JSON"),
) -> None:
    project_id, repo_root = _resolve_worker_project(project)
    store = ExecutionStore(repo_root / ".devflow" / "execution.sqlite")
    payload = store.list_failed_idea_queue_items(project_id=project_id, limit=limit)
    if json_out:
        sys.stdout.write(json.dumps(payload, indent=2, sort_keys=True) + "\n")
        return
    if not payload:
        sys.stdout.write("no failed idea queue items\n")
        return
    for item in payload:
        sys.stdout.write(f"idea_queue_id: {item.get('idea_queue_id')}\n")
        sys.stdout.write(f"idea_id: {item.get('idea_id')}\n")
        sys.stdout.write(f"title: {item.get('title')}\n")
        sys.stdout.write(f"updated_at: {item.get('updated_at')}\n")
        failure_context = item.get('failure_context') if isinstance(item.get('failure_context'), dict) else {}
        resume_cursor = failure_context.get('resume_cursor') if isinstance(failure_context.get('resume_cursor'), dict) else None
        if resume_cursor:
            sys.stdout.write(f"resume_cursor: {json.dumps(resume_cursor, sort_keys=True)}\n")
        sys.stdout.write(f"failure_message: {item.get('failure_message')}\n\n")


@worker_app.command("failed-idea-creations")
def worker_failed_idea_creations(
    project: str = typer.Option(..., "--project", help="Project id, GitHub URL, owner/repo, or workspace path"),
    limit: int = typer.Option(10, "--limit", min=1, help="Max failed items to show"),
    json_out: bool = typer.Option(False, "--json", help="Emit JSON"),
) -> None:
    project_id, repo_root = _resolve_worker_project(project)
    store = ExecutionStore(repo_root / ".devflow" / "execution.sqlite")
    payload = store.list_failed_idea_creation_queue_items(project_id=project_id, limit=limit)
    if json_out:
        sys.stdout.write(json.dumps(payload, indent=2, sort_keys=True) + "\n")
        return
    if not payload:
        sys.stdout.write("no failed idea creation queue items\n")
        return
    for item in payload:
        sys.stdout.write(f"idea_creation_queue_id: {item.get('idea_creation_queue_id')}\n")
        sys.stdout.write(f"idea_id: {item.get('idea_id')}\n")
        sys.stdout.write(f"title: {item.get('title')}\n")
        sys.stdout.write(f"updated_at: {item.get('updated_at')}\n")
        failure_context = item.get('failure_context') if isinstance(item.get('failure_context'), dict) else {}
        resume_cursor = failure_context.get('resume_cursor') if isinstance(failure_context.get('resume_cursor'), dict) else None
        if resume_cursor:
            sys.stdout.write(f"resume_cursor: {json.dumps(resume_cursor, sort_keys=True)}\n")
        sys.stdout.write(f"failure_message: {item.get('failure_message')}\n\n")


@worker_app.command("retry-idea")
def worker_retry_idea(
    project: str = typer.Option(..., "--project", help="Project id, GitHub URL, owner/repo, or workspace path"),
    idea_queue_id: str | None = typer.Option(None, "--idea-queue-id", help="Failed idea_queue_id to reset"),
    latest: bool = typer.Option(False, "--latest", help="Retry the most recent failed idea queue item"),
    run_now: bool = typer.Option(False, "--run-now", help="Immediately process one queue item after resetting"),
    json_out: bool = typer.Option(False, "--json", help="Emit JSON"),
) -> None:
    project_id, repo_root = _resolve_worker_project(project)
    store = ExecutionStore(repo_root / ".devflow" / "execution.sqlite")
    target_id = idea_queue_id
    if latest:
        failed = store.list_failed_idea_queue_items(project_id=project_id, limit=1)
        if not failed:
            sys.stderr.write("No failed idea queue items found.\n")
            raise typer.Exit(code=2)
        target_id = str(failed[0].get('idea_queue_id') or '')
    if not target_id:
        sys.stderr.write("Provide --idea-queue-id or --latest.\n")
        raise typer.Exit(code=2)
    payload = {"reset": store.retry_idea_queue_item(project_id=project_id, idea_queue_id=target_id)}
    if run_now:
        _exit_if_worker_guarded(repo_root=repo_root, json_out=json_out)
        result = process_worker_once(project_id=project_id, repo_root=repo_root, store=store)
        payload["worker"] = {
            "project_id": result.project_id,
            "worker_id": result.worker_id,
            "processed": result.processed,
            "report": result.report,
        }
    if json_out:
        sys.stdout.write(json.dumps(payload, indent=2, sort_keys=True) + "\n")
        return
    sys.stdout.write(f"reset idea_queue_id: {target_id}\n")
    sys.stdout.write(f"status: {payload['reset'].get('status')}\n")
    failure_context = payload['reset'].get('failure_context') if isinstance(payload['reset'].get('failure_context'), dict) else {}
    resume_cursor = failure_context.get('resume_cursor') if isinstance(failure_context.get('resume_cursor'), dict) else None
    if resume_cursor:
        sys.stdout.write(f"resume_cursor: {json.dumps(resume_cursor, sort_keys=True)}\n")
    if run_now:
        sys.stdout.write(f"processed: {json.dumps(payload['worker'].get('processed'), sort_keys=True)}\n")


@worker_app.command("retry-idea-creation")
def worker_retry_idea_creation(
    project: str = typer.Option(..., "--project", help="Project id, GitHub URL, owner/repo, or workspace path"),
    idea_creation_queue_id: str | None = typer.Option(None, "--idea-creation-queue-id", help="Failed idea_creation_queue_id to reset"),
    latest: bool = typer.Option(False, "--latest", help="Retry the most recent failed idea creation queue item"),
    run_now: bool = typer.Option(False, "--run-now", help="Immediately process one queue item after resetting"),
    json_out: bool = typer.Option(False, "--json", help="Emit JSON"),
) -> None:
    project_id, repo_root = _resolve_worker_project(project)
    store = ExecutionStore(repo_root / ".devflow" / "execution.sqlite")
    target_id = idea_creation_queue_id
    if latest:
        failed = store.list_failed_idea_creation_queue_items(project_id=project_id, limit=1)
        if not failed:
            sys.stderr.write("No failed idea creation queue items found.\n")
            raise typer.Exit(code=2)
        target_id = str(failed[0].get('idea_creation_queue_id') or '')
    if not target_id:
        sys.stderr.write("Provide --idea-creation-queue-id or --latest.\n")
        raise typer.Exit(code=2)
    payload = {"reset": store.retry_idea_creation_queue_item(project_id=project_id, idea_creation_queue_id=target_id)}
    if run_now:
        _exit_if_worker_guarded(repo_root=repo_root, json_out=json_out)
        result = process_worker_once(project_id=project_id, repo_root=repo_root, store=store)
        payload["worker"] = {
            "project_id": result.project_id,
            "worker_id": result.worker_id,
            "processed": result.processed,
            "report": result.report,
        }
    if json_out:
        sys.stdout.write(json.dumps(payload, indent=2, sort_keys=True) + "\n")
        return
    sys.stdout.write(f"reset idea_creation_queue_id: {target_id}\n")
    sys.stdout.write(f"status: {payload['reset'].get('status')}\n")
    failure_context = payload['reset'].get('failure_context') if isinstance(payload['reset'].get('failure_context'), dict) else {}
    resume_cursor = failure_context.get('resume_cursor') if isinstance(failure_context.get('resume_cursor'), dict) else None
    if resume_cursor:
        sys.stdout.write(f"resume_cursor: {json.dumps(resume_cursor, sort_keys=True)}\n")
    if run_now:
        sys.stdout.write(f"processed: {json.dumps(payload['worker'].get('processed'), sort_keys=True)}\n")


@config_app.command("get")
def config_get(
    key: str | None = typer.Option(None, help="Config key (omit to list all)"),
    project_id: str | None = typer.Option(None, "--project", help="Project id"),
    explain: bool = typer.Option(False, "--explain", help="Explain where the value came from"),
    json_out: bool = typer.Option(False, "--json", help="Emit JSON"),
) -> None:
    """Get an effective config value, or list all keys if no key is given.

    Area2 contract: precedence project config overrides global.
    """

    global_cfg_path = _global_devflow_dir() / "config.toml"
    global_cfg = _read_toml(global_cfg_path)

    project_ws = _find_workspace_for_project(project_id)
    project_cfg_path = (project_ws / ".devflow" / "config.toml") if project_ws else None
    project_cfg = _read_toml(project_cfg_path) if project_cfg_path else {}

    # No key given — return all keys + metadata
    if key is None:
        payload = {
            "project_id": project_id,
            "project_config_path": str(project_cfg_path) if project_cfg_path else None,
            "project_config": project_cfg,
            "global_config_path": str(global_cfg_path),
            "global_config": global_cfg,
            "available_keys": sorted(set(list(project_cfg.keys()) + list(global_cfg.keys()))),
        }
        if json_out:
            sys.stdout.write(json.dumps(payload, sort_keys=True, indent=2) + "\n")
            return
        sys.stdout.write(f"project_id: {project_id}\n")
        sys.stdout.write(f"project_config_path: {project_cfg_path}\n")
        sys.stdout.write(f"global_config_path: {global_cfg_path}\n")
        sys.stdout.write("project_config:\n")
        for k, v in sorted(project_cfg.items()):
            sys.stdout.write(f"  {k}: {v}\n")
        sys.stdout.write("global_config:\n")
        for k, v in sorted(global_cfg.items()):
            sys.stdout.write(f"  {k}: {v}\n")
        sys.stdout.write(f"available_keys: {sorted(set(list(project_cfg.keys()) + list(global_cfg.keys())))}\n")
        return

    # Precedence: project overrides global.
    if key in project_cfg:
        val = project_cfg.get(key)
        if explain:
            sys.stdout.write(f"{redact_value(key, val)} (source: project:{project_cfg_path})\n")
        else:
            sys.stdout.write(f"{redact_value(key, val)}\n")
        raise typer.Exit(code=0)

    if key in global_cfg:
        val = global_cfg.get(key)
        if explain:
            sys.stdout.write(f"{redact_value(key, val)} (source: global:{global_cfg_path})\n")
        else:
            sys.stdout.write(f"{redact_value(key, val)}\n")
        raise typer.Exit(code=0)

    if explain:
        sys.stdout.write("<unset> (source: none)\n")
    raise typer.Exit(code=2)


@config_app.command("set")
def config_set(
    key: str = typer.Argument(..., help="Config key"),
    value: str = typer.Argument(..., help="Config value"),
    project_id: str | None = typer.Option(None, "--project", help="Project id (write project config)"),
) -> None:
    """Set a config value (global or project)."""

    global_cfg_path = _global_devflow_dir() / "config.toml"

    project_ws = _find_workspace_for_project(project_id)
    project_cfg_path = (project_ws / ".devflow" / "config.toml") if project_ws else None

    if project_id and not project_cfg_path:
        raise typer.Exit(code=2)

    target_path = project_cfg_path or global_cfg_path
    cfg = _read_toml(target_path)

    # When updating tiers, merge with existing tier values so that
    # user-facing partial updates (light/medium/strong) never destroy
    # internal-only tiers (ultra_light) that the frontend does not own.
    if str(key).strip() == "tiers":
        import ast
        incoming = ast.literal_eval(str(value))
        if isinstance(incoming, dict):
            existing = cfg.get("tiers")
            # cfg["tiers"] may be a Python dict or a raw string from the fallback path.
            if isinstance(existing, dict):
                merged = {**existing, **incoming}
            elif isinstance(existing, str):
                try:
                    parsed_existing = ast.literal_eval(existing)
                    if isinstance(parsed_existing, dict):
                        merged = {**parsed_existing, **incoming}
                    else:
                        merged = incoming
                except Exception:
                    merged = incoming
            else:
                merged = incoming
            cfg["tiers"] = merged
        else:
            cfg[str(key)] = str(value)
    else:
        cfg[str(key)] = str(value)
    write_toml_kv(target_path, cfg)
    sys.stdout.write("ok\n")


@config_app.command("llm-set-provider")
def config_llm_set_provider(
    mode: str = typer.Option(..., "--mode", help="llm mode: cli|api"),
    provider: str = typer.Option(..., "--provider", help="provider id (e.g. codex|claude|gemini-cli|openai|pi)"),
) -> None:
    """Configure which LLM executor the engine should use.

    Stored in global config under DEVFLOW_HOME.
    """

    mode = mode.strip().lower()
    provider = provider.strip().lower()
    if mode not in {"cli", "api"}:
        raise typer.Exit(code=2)

    cfg_path = _global_devflow_dir() / "config.toml"
    cfg = _read_toml(cfg_path)

    cfg["llm_mode"] = mode
    cfg["llm_provider"] = provider

    # Provider defaults for CLI one-shot.
    if mode == "cli":
        if provider == "codex":
            cfg["llm_cli_delivery"] = "argument"
            cfg["llm_cli_base"] = "codex exec"
        elif provider == "claude":
            cfg["llm_cli_delivery"] = "stdin"
            cfg["llm_cli_base"] = "claude"
        elif provider == "gemini-cli":
            cfg["llm_cli_delivery"] = "argument"
            cfg["llm_cli_base"] = "gemini"
        elif provider == "ollama":
            cfg["llm_cli_delivery"] = "stdin"
            cfg["llm_cli_base"] = "ollama run"
            cfg["llm_cli_model_default"] = "phi4"
            cfg["llm_cli_model_weak"] = "phi4"
            cfg["llm_cli_model_strong"] = "llama3.2"
            cfg["llm_local_ultra_light_provider"] = "ollama"
            cfg["llm_local_ultra_light_base"] = "ollama run"
            cfg["llm_local_ultra_light_delivery"] = "stdin"
            cfg["llm_local_ultra_light_model_default"] = "phi4"
            cfg["llm_local_ultra_light_model_weak"] = "phi4"
            cfg["llm_local_ultra_light_model_strong"] = "llama3.2"
        elif provider == "pi":
            cfg["llm_cli_delivery"] = "argument"
            cfg["llm_cli_base"] = "pi -p"
        else:
            # Unknown CLI provider: user must also set base/delivery explicitly.
            cfg.setdefault("llm_cli_delivery", "argument")
            cfg.setdefault("llm_cli_base", provider)

    write_toml_kv(cfg_path, cfg)
    sys.stdout.write("ok\n")


@config_app.command("llm-set-key")
def config_llm_set_key(
    provider: str = typer.Option(..., "--provider"),
    key: str | None = typer.Option(None, "--key", help="API key (warning: shell history). Prefer stdin."),
    stdin: bool = typer.Option(False, "--stdin", help="Read key from stdin"),
) -> None:
    """Register an API key for an LLM provider under DEVFLOW_HOME.

    Stores the key in the macOS keychain and activates it in the current process env.
    """

    provider = provider.strip().lower()
    if stdin:
        raw = sys.stdin.read().strip()
        if not raw:
            raise typer.Exit(code=2)
        key_val = raw
    else:
        if not key:
            raise typer.Exit(code=2)
        key_val = key

    store_provider_api_key(provider, key_val)
    set_runtime_provider_api_key(provider, key_val)
    sys.stdout.write("ok\n")


@config_app.command("llm-show")
def config_llm_show() -> None:
    """Show effective LLM config (redacting secrets)."""

    import json

    cfg_path = _global_devflow_dir() / "config.toml"
    cfg = _read_toml(cfg_path)

    provider = str(cfg.get("llm_provider") or "")
    mode = str(cfg.get("llm_mode") or "")
    cli_base = str(cfg.get("llm_cli_base") or "")
    cli_delivery = str(cfg.get("llm_cli_delivery") or "")

    key_present = bool(provider and get_provider_api_key(provider))
    key_storage = "macos-keychain" if provider and load_provider_api_key_from_keychain(provider) else None

    sys.stdout.write(
        json.dumps(
            {
                "llm_mode": mode or None,
                "llm_provider": provider or None,
                "llm_cli_base": cli_base or None,
                "llm_cli_delivery": cli_delivery or None,
                "api_key_present": key_present,
                "api_key_path": None,
                "api_key_storage": key_storage,
            },
            indent=2,
            sort_keys=True,
        )
        + "\n"
    )


@story_app.command("index")
def story_index() -> None:
    repo_root, store = _store()
    paths = get_paths(repo_root)
    paths.stories_dir.mkdir(parents=True, exist_ok=True)
    run = store.start_run(kind="story.index", repo_root=repo_root, args={})

    count = 0
    for p in iter_canonical_story_paths(repo_root):
        text = p.read_text(encoding="utf-8")
        blocks = parse_story_contracts_from_markdown(text, source_path=str(p))

        # Hard fail: if a canonical story path contains no parseable story blocks,
        # we must surface it as a validation error (otherwise missing plane_oracles/anchors
        # can slip by silently).
        if not blocks:
            store.add_error(
                run_id=run.run_id,
                source="story.index",
                message="contract invalid",
                details={
                    "path": str(p),
                    "issues": [
                        {
                            "code": "no_story_blocks",
                            "message": "No story_uuid blocks found in markdown",
                            "path": str(p),
                        }
                    ],
                },
            )
            continue

        for b in blocks:
            issues = validate_parsed_story_block(b)
            if issues:
                store.add_error(
                    run_id=run.run_id,
                    source="story.index",
                    message="contract invalid",
                    details={"path": str(p), "issues": [i.__dict__ for i in issues]},
                )
                continue
            c = b.contract
            store.upsert_story(
                story_id=c.story_uuid,
                title=c.title,
                path=p,
                contract={
                    "story_uuid": c.story_uuid,
                    "story_id": c.story_id,
                    "title": c.title,
                    "required_planes": c.required_planes,
                    "plane_oracles": [po.__dict__ for po in c.plane_oracles],
                },
            )
            count += 1
    store.add_event(run_id=run.run_id, level="INFO", message="indexed stories", payload={"count": count})
    console.print(count)


@story_app.command("validate")
def story_validate(path: Path = typer.Argument(...)) -> None:
    repo_root, store = _store()
    run = store.start_run(kind="story.validate", repo_root=repo_root, args={"path": str(path)})
    text = path.read_text(encoding="utf-8")
    blocks = parse_story_contracts_from_markdown(text, source_path=str(path))
    if not blocks:
        store.add_error(
            run_id=run.run_id,
            source="story.validate",
            message="contract invalid",
            details={
                "issues": [
                    {
                        "code": "no_story_blocks",
                        "message": "No story_uuid blocks found in markdown",
                        "path": str(path),
                    }
                ]
            },
        )
        raise typer.Exit(code=2)

    all_issues: list[ContractIssue] = []
    for b in blocks:
        issues = validate_parsed_story_block(b)
        all_issues.extend(issues)

    if all_issues:
        for i in all_issues:
            console.print(f"[red]{i.code}[/red] {i.path}: {i.message}")
        store.add_error(
            run_id=run.run_id,
            source="story.validate",
            message="contract invalid",
            details={"issues": [i.__dict__ for i in all_issues]},
        )
        raise typer.Exit(code=2)

    store.add_event(run_id=run.run_id, level="INFO", message="contract valid")
    console.print("ok")


@story_app.command("register")
def story_register(
    path: Path = typer.Argument(...),
    project_id: str | None = typer.Option(None),
) -> None:
    repo_root, store = _store()
    run = store.start_run(
        kind="story.register", repo_root=repo_root, args={"path": str(path), "project_id": project_id}
    )

    text = path.read_text(encoding="utf-8")
    blocks = parse_story_contracts_from_markdown(text, source_path=str(path))
    if len(blocks) != 1:
        store.add_error(
            run_id=run.run_id,
            source="story.register",
            message="contract invalid",
            details={"reason": "expected exactly one story in file", "count": len(blocks)},
        )
        raise typer.Exit(code=2)

    b = blocks[0]
    issues = validate_parsed_story_block(b)
    if issues:
        store.add_error(
            run_id=run.run_id,
            source="story.register",
            message="contract invalid",
            details={"issues": [i.__dict__ for i in issues]},
        )
        raise typer.Exit(code=2)

    c = b.contract
    store.upsert_story(
        story_id=c.story_uuid,
        title=c.title,
        path=path,
        contract={
            "story_uuid": c.story_uuid,
            "story_id": c.story_id,
            "title": c.title,
            "required_planes": c.required_planes,
            "plane_oracles": [po.__dict__ for po in c.plane_oracles],
        },
        project_id=project_id,
    )
    store.add_event(
        run_id=run.run_id,
        level="INFO",
        message="registered story",
        payload={"story_uuid": c.story_uuid},
    )
    console.print(c.story_uuid)


@story_app.command("list")
def story_list(
    project_id: str | None = typer.Option(None, "--project", help="Filter by project id"),
    summary: bool = typer.Option(False, "--summary", help="Show queue summary instead of story list"),
    json_out: bool = typer.Option(False, "--json", help="Emit JSON"),
) -> None:
    """List stories or show queue summary."""
    _repo_root, store = _store()

    if summary:
        def queue_counts(table: str) -> dict[str, int]:
            with store._connect() as conn:
                rows = conn.execute(f"SELECT status, COUNT(*) as cnt FROM {table} GROUP BY status").fetchall()
            return {r["status"]: r["cnt"] for r in rows}

        payload = {
            "story_queue": queue_counts("story_queue"),
            "idea_queue": queue_counts("idea_queue"),
            "integration_queue": queue_counts("integration_queue"),
            "recovery_queue": queue_counts("recovery_queue"),
            "error_tasks": queue_counts("error_tasks"),
        }
        if json_out:
            sys.stdout.write(json.dumps(payload, sort_keys=True, indent=2) + "\n")
            return
        sys.stdout.write("Queue Summary:\n")
        for qname, counts in payload.items():
            total = sum(counts.values())
            detail = ", ".join(f"{s}:{c}" for s, c in sorted(counts.items()))
            sys.stdout.write(f"  {qname}: total={total} ({detail})\n")
        return

    rows = store.list_stories(project_id=project_id)
    t = Table("story_id", "title", "path", "status", "created_at")
    for r in rows:
        t.add_row(r["story_id"], r["title"], r["path"], r["status"], str(r["created_at"]))
    console.print(t)


@story_app.command("execute")
def story_execute(
    story_id: str = typer.Argument(...),
) -> None:
    """[MANUAL / DEV-ONLY] Execute a registered story directly.

    This is a low-level manual execution path intended for development and
    debugging. It bypasses the queue-driven worker and runs the process DAG
    inline for a single registered story.

    For automated, queue-driven execution use `devflow worker start --project <id>`.

    Area 6 contract: for Implementation DAG stories, this runs the DAG and
    persists node timeline entries into the execution store.
    """

    repo_root, store = _store()
    run = store.start_run(kind="story.execute", repo_root=repo_root, args={"story_id": story_id})
    s = store.get_story(story_id)
    if s is None:
        store.add_error(
            run_id=run.run_id,
            source="story.execute",
            message="story not found",
            details={"story_id": story_id},
        )
        raise typer.Exit(code=2)

    # Minimal routing: any registered story executes via the process DAG.
    # (Implementation + Review; currently imperative, not GenAI workflow.)
    from ..process.dag import run_process_dag

    pres = run_process_dag(repo_root=repo_root, store=store, story=s)
    exit_code, msg = pres.exit_code, pres.message
    store.add_event(
        run_id=run.run_id,
        level="INFO",
        message="executed story",
        payload={"story_id": story_id, "exit_code": exit_code},
    )
    if msg:
        # Keep user-facing output deterministic.
        sys.stdout.write(msg)
    raise typer.Exit(code=exit_code)


@plan_app.command("analyze")
def plan_analyze(
    out_dir: Path = typer.Option(Path(".devflow/drafts"), help="Output directory"),
) -> None:
    repo_root, store = _store()
    run = store.start_run(kind="plan.analyze", repo_root=repo_root, args={"out_dir": str(out_dir)})

    drafts = draft_user_stories(repo_root)
    out_dir = (repo_root / out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    for d in drafts:
        md = render_draft_story_markdown(d)
        # filename derived from story_id
        slug = str(d.get("story_id", "draft")).replace(":", "__").replace("/", "__")
        (out_dir / f"{slug}.md").write_text(md, encoding="utf-8")

    store.add_event(
        run_id=run.run_id,
        level="INFO",
        message="drafted stories",
        payload={"count": len(drafts), "out_dir": str(out_dir)},
    )
    console.print(str(out_dir))


# ----------------------------
# Area10: Architecture + Inventory tooling
# ----------------------------


def _yaml_load(path: Path) -> dict[str, object]:
    try:
        raw = yaml.safe_load(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        return {}
    except Exception:
        return {}
    return raw if isinstance(raw, dict) else {}


def _yaml_dump(data: dict[str, object]) -> str:
    # Stable formatting for deterministic tests.
    return yaml.safe_dump(data, sort_keys=True)


def _decision_id_for(key: str, value: str) -> str:
    h = sha256(f"{key}={value}".encode("utf-8")).hexdigest()[:8]
    return f"DEC-{h}"


@arch_decision_app.command("add")
def arch_decision_add(
    key: str = typer.Option(..., "--key"),
    value: str = typer.Option(..., "--value"),
    rationale: str = typer.Option("", "--rationale"),
) -> None:
    root = _repo_root()
    path = _decisions_path(root)
    path.parent.mkdir(parents=True, exist_ok=True)

    doc = _yaml_load(path)
    decisions = doc.get("decisions")
    if not isinstance(decisions, list):
        decisions = []

    decision_id = _decision_id_for(key.strip(), value.strip())

    # Upsert by decision_id.
    kept: list[object] = []
    for d in decisions:
        if isinstance(d, dict) and d.get("decision_id") == decision_id:
            continue
        kept.append(d)

    kept.append(
        {
            "decision_id": decision_id,
            "key": key.strip(),
            "value": value.strip(),
            "rationale": rationale.strip(),
        }
    )

    doc["decisions"] = kept
    path.write_text(_yaml_dump(doc), encoding="utf-8")

    # Print decision_id for chaining.
    sys.stdout.write(decision_id + "\n")


@arch_decision_app.command("list")
def arch_decision_list(json_out: bool = typer.Option(False, "--json")) -> None:
    root = _repo_root()
    path = _decisions_path(root)
    doc = _yaml_load(path)
    decisions = doc.get("decisions")
    if not isinstance(decisions, list):
        decisions = []

    if json_out:
        sys.stdout.write(json.dumps({"decisions": decisions}, sort_keys=True) + "\n")
        return

    for d in decisions:
        if not isinstance(d, dict):
            continue
        sys.stdout.write(f"{d.get('decision_id','')} {d.get('key','')}={d.get('value','')}\n")


@arch_decision_app.command("remove")
def arch_decision_remove(decision_id: str = typer.Argument(...)) -> None:
    root = _repo_root()
    path = _decisions_path(root)
    doc = _yaml_load(path)
    decisions = doc.get("decisions")
    if not isinstance(decisions, list):
        decisions = []

    kept: list[object] = []
    removed = False
    for d in decisions:
        if isinstance(d, dict) and d.get("decision_id") == decision_id:
            removed = True
            continue
        kept.append(d)

    doc["decisions"] = kept
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(_yaml_dump(doc), encoding="utf-8")

    if not removed:
        raise typer.Exit(code=2)

    sys.stdout.write("ok\n")


# ----------------------------
# Registry: perfect registration DB (project-owned imports)
# ----------------------------


def _registry_connect(db_path: Path):
    import sqlite3

    db_path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(db_path))
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def _registry_init_schema(conn) -> None:
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS imports (
          importer TEXT NOT NULL,
          specifier TEXT NOT NULL,
          kind TEXT NOT NULL,              -- internal|external
          resolved_id TEXT NOT NULL,       -- module:<path> or pkg:<name>
          PRIMARY KEY (importer, specifier)
        );

        CREATE TABLE IF NOT EXISTS registered_items (
          item_id TEXT PRIMARY KEY,        -- module:<path>
          kind TEXT NOT NULL,              -- internal_module
          key TEXT NOT NULL                -- repo-relative path (posix)
        );

        CREATE TABLE IF NOT EXISTS allowed_packages (
          name TEXT PRIMARY KEY            -- npm/pip package name
        );

        -- External package domain classification (autonomous policy substrate)
        CREATE TABLE IF NOT EXISTS known_domains (
          domain TEXT PRIMARY KEY,
          is_controlled INTEGER NOT NULL DEFAULT 1,
          updated_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS package_domains (
          package TEXT PRIMARY KEY,
          domain TEXT,                     -- nullable if unknown
          inferred_by TEXT NOT NULL,       -- heuristic|manual
          confidence REAL NOT NULL DEFAULT 0.5,
          updated_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS domain_policy (
          domain TEXT PRIMARY KEY,
          canonical_package TEXT,          -- nullable until computed
          allow_multiple INTEGER NOT NULL DEFAULT 0,
          updated_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS package_purpose (
          package TEXT PRIMARY KEY,
          domain TEXT NOT NULL,
          purpose TEXT NOT NULL,
          decided_by TEXT NOT NULL,        -- llm|human|heuristic
          confidence REAL,
          updated_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS package_status (
          package TEXT PRIMARY KEY,
          domain TEXT,                     -- nullable
          status TEXT NOT NULL,            -- canonical|allowed|heretical|unknown
          lane TEXT,                       -- nullable; required when allow_multiple=1 for controlled domains
          reason TEXT,
          updated_at TEXT NOT NULL
        );

        -- Manual overrides for lane assignment (domain-scoped)
        CREATE TABLE IF NOT EXISTS package_lanes (
          domain TEXT NOT NULL,
          package TEXT NOT NULL,
          lane TEXT NOT NULL,
          updated_at TEXT NOT NULL,
          PRIMARY KEY (domain, package)
        );

        -- Manual overrides for canonical/heretical status (domain-scoped)
        CREATE TABLE IF NOT EXISTS package_status_overrides (
          domain TEXT NOT NULL,
          package TEXT NOT NULL,
          status TEXT NOT NULL,            -- canonical|heretical|allowed
          updated_at TEXT NOT NULL,
          PRIMARY KEY (domain, package)
        );

        -- Manual overrides for package domain classification
        CREATE TABLE IF NOT EXISTS package_domain_overrides (
          package TEXT PRIMARY KEY,
          domain TEXT NOT NULL,
          updated_at TEXT NOT NULL
        );

        -- Entities are higher-level named items that can be deduped into canonical/heretical.
        CREATE TABLE IF NOT EXISTS entities (
          item_id TEXT PRIMARY KEY,        -- module:<path>
          name TEXT NOT NULL,
          group_id TEXT,                   -- optional dedupe group
          is_canonical INTEGER NOT NULL DEFAULT 0,
          canonical_of TEXT                -- item_id of canonical entity if heretical
        );

        CREATE TABLE IF NOT EXISTS entity_groups (
          group_id TEXT PRIMARY KEY,
          canonical_item_id TEXT           -- selected canonical entity for the group
        );

        -- Registry meta (phase latches, versions)
        CREATE TABLE IF NOT EXISTS registry_meta (
          key TEXT PRIMARY KEY,
          value TEXT NOT NULL,
          updated_at TEXT NOT NULL
        );

        -- Module-card policy substrate (internal pathways)
        CREATE TABLE IF NOT EXISTS module_cards (
          domain TEXT NOT NULL,
          card_id TEXT NOT NULL,
          allow_multiple_lanes INTEGER NOT NULL DEFAULT 0,
          updated_at TEXT NOT NULL,
          PRIMARY KEY (domain, card_id)
        );

        CREATE TABLE IF NOT EXISTS module_card_membership (
          domain TEXT NOT NULL,
          card_id TEXT NOT NULL,
          module_id TEXT NOT NULL,         -- module:<path>
          lane TEXT NOT NULL,
          status TEXT NOT NULL,            -- canonical|heretical
          reason TEXT,
          updated_at TEXT NOT NULL,
          PRIMARY KEY (domain, card_id, module_id)
        );

        -- Track observed internal modules (for incremental registration)
        CREATE TABLE IF NOT EXISTS module_seen (
          module_id TEXT PRIMARY KEY,
          first_seen_at TEXT NOT NULL,
          last_seen_at TEXT NOT NULL
        );
        """
    )


_TS_IMPORT_RE = re.compile(
    r"(?:from\s+['\"](?P<from>[^'\"]+)['\"])|(?:require\(\s*['\"](?P<req>[^'\"]+)['\"]\s*\))|(?:import\(\s*['\"](?P<dyn>[^'\"]+)['\"]\s*\))"
)


def _iter_project_files(root: Path, roots: list[Path]) -> list[Path]:
    exts = {".ts", ".tsx", ".js", ".jsx", ".py"}

    # Avoid scanning vendor/build artifacts; keeps registry signal stable on brownfield repos.
    ignore_dirnames = {
        "node_modules",
        ".next",
        "dist",
        "build",
        "coverage",
        ".turbo",
        ".git",
        ".venv",
        "__pycache__",
    }

    out: list[Path] = []

    import os

    for r in roots:
        if not r.exists():
            continue
        for dirpath, dirnames, filenames in os.walk(r):
            # prune ignored dirs in-place
            dirnames[:] = [d for d in dirnames if d not in ignore_dirnames and not d.startswith(".")]

            for fn in filenames:
                p = Path(dirpath) / fn
                if p.suffix in exts:
                    out.append(p)

    return sorted(out)


_ENTITY_MARKER_RE = re.compile(r"DEVFLOW_ENTITY:\s*(?P<name>\S+)(?:\s+group=(?P<group>\S+))?(?:\s+(?P<canonical>canonical))?", re.IGNORECASE)


def _scan_entities(repo_root: Path, roots: list[Path]) -> list[dict[str, str | int | None]]:
    """Discover entities from explicit markers.

    Deterministic: we only consider explicit `DEVFLOW_ENTITY:` headers.

    Format:
      // DEVFLOW_ENTITY: sendEmail group=email_delivery canonical
    """

    out: list[dict[str, str | int | None]] = []
    for p in _iter_project_files(repo_root, roots):
        try:
            lines = p.read_text(encoding="utf-8").splitlines()
        except Exception:
            continue
        for ln in lines[:20]:
            m = _ENTITY_MARKER_RE.search(ln)
            if not m:
                continue
            rel = p.relative_to(repo_root).as_posix()
            rel_no_ext = re.sub(r"\.[a-zA-Z0-9]+$", "", rel)
            item_id = f"module:{rel_no_ext}"
            name = (m.group("name") or "").strip()
            group_id = (m.group("group") or "").strip() or None
            is_canon = 1 if (m.group("canonical") or "").lower() == "canonical" else 0
            out.append({"item_id": item_id, "name": name, "group_id": group_id, "is_canonical": is_canon})
            break

    out.sort(key=lambda r: (str(r.get("group_id") or ""), str(r.get("name") or ""), str(r.get("item_id") or "")))
    return out


def _default_project_roots(root: Path) -> list[Path]:
    # Conservative defaults that cover common stacks while staying "project-only".
    return [
        root / "src",
        root / "app",
        root / "pages",
        root / "lib",
        root / "components",
        root / "src-tauri" / "src",
    ]


_NODE_BUILTINS = {
    # Common Node core modules
    "assert",
    "buffer",
    "child_process",
    "cluster",
    "console",
    "constants",
    "crypto",
    "dgram",
    "dns",
    "domain",
    "events",
    "fs",
    "http",
    "http2",
    "https",
    "inspector",
    "module",
    "net",
    "os",
    "path",
    "perf_hooks",
    "process",
    "punycode",
    "querystring",
    "readline",
    "repl",
    "stream",
    "string_decoder",
    "timers",
    "tls",
    "trace_events",
    "tty",
    "url",
    "util",
    "v8",
    "vm",
    "wasi",
    "worker_threads",
    "zlib",
}


def _package_name_from_specifier(spec: str) -> str:
    if spec.startswith("@"):
        parts = spec.split("/")
        return "/".join(parts[:2]) if len(parts) >= 2 else spec
    return spec.split("/")[0]


def _resolve_internal_import(repo_root: Path, importer: Path, spec: str) -> str:
    # Resolve relative imports to a stable repo-relative id when possible.
    base = importer.parent
    target = (base / spec).resolve()
    # Try common extensions and index files.
    candidates: list[Path] = []
    if target.suffix:
        candidates.append(target)
    else:
        for ext in [".ts", ".tsx", ".js", ".jsx", ".py"]:
            candidates.append(Path(str(target) + ext))
        for ext in [".ts", ".tsx", ".js", ".jsx"]:
            candidates.append(target / ("index" + ext))

    for c in candidates:
        if c.exists():
            rel = c.relative_to(repo_root).as_posix()
            # strip extension for module id stability
            rel_no_ext = re.sub(r"\.[a-zA-Z0-9]+$", "", rel)
            return f"module:{rel_no_ext}"

    # Fallback: record unresolved specifier deterministically.
    rel_imp = importer.relative_to(repo_root).as_posix()
    return f"module:unresolved:{rel_imp}:{spec}"


def _scan_imports(repo_root: Path, roots: list[Path]) -> list[tuple[str, str, str, str]]:
    rows: list[tuple[str, str, str, str]] = []

    # Precompute internal python top-level packages under the scan roots.
    internal_py_tops: set[str] = set()
    for r in roots:
        if not r.exists():
            continue
        for child in r.iterdir():
            if not child.is_dir():
                continue
            if (child / "__init__.py").exists():
                internal_py_tops.add(child.name)

    def _resolve_py_internal(importer: Path, mod: str) -> str | None:
        # Returns module item_id (module:...) or None if cannot resolve.
        mod = mod.strip()
        if not mod:
            return None

        # Relative import: from .foo / from ..foo
        if mod.startswith("."):
            dots = len(mod) - len(mod.lstrip("."))
            rest = mod[dots:]
            base = importer.parent
            # dots=1 => same package, dots=2 => parent, etc.
            for _ in range(max(0, dots - 1)):
                base = base.parent
            parts = [p for p in rest.split(".") if p] if rest else []
            target = base.joinpath(*parts)
        else:
            top = mod.split(".")[0]
            if top not in internal_py_tops:
                return None
            parts = [p for p in mod.split(".") if p]
            target = repo_root.joinpath(*parts)

        # Try file or package __init__.py
        candidates = [target.with_suffix(".py"), target / "__init__.py"]
        for c in candidates:
            if c.exists():
                rel = c.relative_to(repo_root).as_posix()
                rel_no_ext = re.sub(r"\.[a-zA-Z0-9]+$", "", rel)
                # Normalize package __init__ to package path
                if rel.endswith("/__init__.py"):
                    rel_no_ext = rel_no_ext[: -len("/__init__")]
                return f"module:{rel_no_ext}"

        return None

    for p in _iter_project_files(repo_root, roots):
        rel_importer = p.relative_to(repo_root).as_posix()
        try:
            text = p.read_text(encoding="utf-8")
        except Exception:
            continue

        if p.suffix == ".py":
            # Skip Python stdlib imports to avoid polluting external package policy.
            try:
                import sys

                stdlib = getattr(sys, "stdlib_module_names", set())
            except Exception:  # pragma: no cover
                stdlib = set()

            for ln in text.splitlines():
                ln_s = ln.strip()
                if ln_s.startswith("import "):
                    mod = ln_s.split()[1].split(",")[0]
                    if not mod:
                        continue
                    # Try internal first
                    rid = _resolve_py_internal(p, mod)
                    if rid:
                        rows.append((rel_importer, mod, "internal", rid))
                        continue

                    pkg = mod.split(".")[0]
                    if pkg in stdlib:
                        continue
                    rows.append((rel_importer, pkg, "external", f"pkg:{pkg}"))
                elif ln_s.startswith("from "):
                    parts = ln_s.split()
                    if len(parts) < 2:
                        continue
                    mod = parts[1]
                    rid = _resolve_py_internal(p, mod)
                    if rid:
                        rows.append((rel_importer, mod, "internal", rid))
                        continue

                    pkg = mod.split(".")[0]
                    if pkg in stdlib:
                        continue
                    rows.append((rel_importer, pkg, "external", f"pkg:{pkg}"))
            continue

        for m in _TS_IMPORT_RE.finditer(text):
            spec = (m.group("from") or m.group("req") or m.group("dyn") or "").strip()
            if not spec:
                continue
            if spec.startswith(".") or spec.startswith("/"):
                resolved = _resolve_internal_import(repo_root, p, spec)
                rows.append((rel_importer, spec, "internal", resolved))
            else:
                pkg = _package_name_from_specifier(spec)
                # Skip Node builtins (fs/path/crypto/etc.) to avoid polluting package policy.
                if pkg.startswith("node:"):
                    continue
                if pkg in _NODE_BUILTINS:
                    continue
                rows.append((rel_importer, spec, "external", f"pkg:{pkg}"))

    # stable ordering
    rows.sort(key=lambda r: (r[0], r[1], r[2], r[3]))
    return rows


def _parse_roots_arg(repo_root: Path, roots: list[str] | None) -> list[Path]:
    if roots:
        return [repo_root / r for r in roots]
    return _default_project_roots(repo_root)


def _json_dump(obj: object) -> str:
    return json.dumps(obj, indent=2, sort_keys=True) + "\n"


def _extract_json(text: str) -> str | None:
    """Best-effort JSON extractor for CLI LLM output.

    Supports raw JSON, fenced ```json blocks, and general "first {...}" fallback.
    """

    if "```" in text:
        parts = text.split("```")
        for i in range(len(parts) - 1):
            body = parts[i + 1]
            body_lines = body.splitlines()
            if body_lines and body_lines[0].strip().lower() in {"json", "javascript"}:
                body = "\n".join(body_lines[1:])
            body = body.strip()
            if body.startswith("{") and body.endswith("}"):
                return body

    start = text.find("{")
    end = text.rfind("}")
    if start != -1 and end != -1 and end > start:
        return text[start : end + 1]

    return None


def _choose_group_canonical(conn, group_id: str) -> str | None:
    rows = list(
        conn.execute(
            "select item_id, is_canonical from entities where group_id=? order by item_id",
            (group_id,),
        )
    )
    if not rows:
        return None
    # Prefer explicit canonical marker.
    for item_id, is_canonical in rows:
        if int(is_canonical) == 1:
            return str(item_id)
    # Fallback: stable deterministic pick.
    return str(rows[0][0])


def _apply_dedupe_mapping(conn) -> None:
    groups = [r[0] for r in conn.execute("select distinct group_id from entities where group_id is not null").fetchall()]
    for group_id in groups:
        canon = _choose_group_canonical(conn, str(group_id))
        if not canon:
            continue
        conn.execute(
            "insert or replace into entity_groups(group_id, canonical_item_id) values (?,?)",
            (str(group_id), canon),
        )
        # Mark canon/heresy
        conn.execute("update entities set is_canonical=case when item_id=? then 1 else 0 end where group_id=?", (canon, str(group_id)))
        conn.execute(
            "update entities set canonical_of=case when item_id=? then null else ? end where group_id=?",
            (canon, canon, str(group_id)),
        )


def _rewrite_import_specifiers_to_canonical(repo_root: Path, conn, roots: list[Path]) -> int:
    """Rewrite import specifiers in project files from heretical module to canonical module.

    Scope: only internal imports whose resolved_id corresponds to an entity with canonical_of set.
    """

    rewrites = 0

    # Build mapping heretical_resolved_id -> canonical_resolved_id
    mapping: dict[str, str] = {}
    for item_id, canonical_of in conn.execute(
        "select item_id, canonical_of from entities where canonical_of is not null"
    ).fetchall():
        mapping[str(item_id)] = str(canonical_of)

    if not mapping:
        return 0

    # Build helper: module item_id -> path without prefix
    def _module_path(item_id: str) -> str:
        return item_id.split(":", 1)[1]

    # Find affected imports from DB.
    affected = list(
        conn.execute(
            "select importer, specifier, resolved_id from imports where kind='internal' order by importer, specifier"
        ).fetchall()
    )

    for importer, specifier, resolved_id in affected:
        resolved_id = str(resolved_id)
        if resolved_id not in mapping:
            continue
        canonical_id = mapping[resolved_id]

        importer_path = repo_root / str(importer)
        if not importer_path.exists():
            continue

        # Compute canonical specifier relative to importer.
        canon_rel = _module_path(canonical_id)
        canon_file = repo_root / (canon_rel + ".ts")
        if not canon_file.exists():
            # try tsx/js/jsx
            for ext in [".tsx", ".js", ".jsx"]:
                alt = repo_root / (canon_rel + ext)
                if alt.exists():
                    canon_file = alt
                    break

        try:
            rel_from_importer = canon_file.relative_to(importer_path.parent)
            rel_no_ext = re.sub(r"\.[a-zA-Z0-9]+$", "", rel_from_importer.as_posix())
            if not rel_no_ext.startswith("."):
                rel_no_ext = "./" + rel_no_ext
        except Exception:
            # Fallback: keep original specifier if we can't compute.
            rel_no_ext = str(specifier)

        try:
            text = importer_path.read_text(encoding="utf-8")
        except Exception:
            continue

        # Replace only exact-quoted matches of the specifier.
        before = text
        text = text.replace(f"'{specifier}'", f"'{rel_no_ext}'").replace(f'"{specifier}"', f'"{rel_no_ext}"')
        if text != before:
            importer_path.write_text(text, encoding="utf-8")
            rewrites += 1

    return rewrites


@registry_app.command("init")
def registry_init(
    strict: bool = typer.Option(False, "--strict", help="Refactor heretical entities to canonical during init"),
    roots: list[str] | None = typer.Option(None, "--root", help="Project-owned source root (repeatable)")
) -> None:
    repo_root = _repo_root()
    db_path = _registry_db_path(repo_root)

    if db_path.exists():
        db_path.unlink()

    conn = _registry_connect(db_path)
    try:
        _registry_init_schema(conn)
        scan_roots = _parse_roots_arg(repo_root, roots)
        rows = _scan_imports(repo_root, scan_roots)

        # Load imports
        conn.executemany(
            "INSERT OR REPLACE INTO imports(importer,specifier,kind,resolved_id) VALUES (?,?,?,?)",
            rows,
        )

        # Register everything discovered.
        for (_, _spec, kind, resolved_id) in rows:
            if kind == "external":
                pkg = resolved_id.split(":", 1)[1]
                conn.execute("INSERT OR IGNORE INTO allowed_packages(name) VALUES (?)", (pkg,))
            else:
                conn.execute(
                    "INSERT OR IGNORE INTO registered_items(item_id,kind,key) VALUES (?,?,?)",
                    (resolved_id, "internal_module", resolved_id.split(":", 1)[1]),
                )

        # Discover entities (explicit marker) and apply dedupe mapping.
        entities = _scan_entities(repo_root, scan_roots)
        for e in entities:
            conn.execute(
                "INSERT OR REPLACE INTO entities(item_id,name,group_id,is_canonical,canonical_of) VALUES (?,?,?,?,NULL)",
                (e["item_id"], e["name"], e["group_id"], e["is_canonical"]),
            )

        _apply_dedupe_mapping(conn)

        # Strict mode: rewrite heretical imports to canonical.
        if strict:
            _ = _rewrite_import_specifiers_to_canonical(repo_root, conn, scan_roots)
            # Rescan imports after rewrite.
            rows2 = _scan_imports(repo_root, scan_roots)
            conn.execute("DELETE FROM imports")
            conn.executemany(
                "INSERT OR REPLACE INTO imports(importer,specifier,kind,resolved_id) VALUES (?,?,?,?)",
                rows2,
            )

            # Ensure any newly-resolved internal modules are registered.
            for (_, _spec2, kind2, resolved_id2) in rows2:
                if kind2 != "internal":
                    continue
                conn.execute(
                    "INSERT OR IGNORE INTO registered_items(item_id,kind,key) VALUES (?,?,?)",
                    (resolved_id2, "internal_module", str(resolved_id2).split(":", 1)[1]),
                )

        from datetime import datetime, timezone

        now = datetime.now(timezone.utc).replace(microsecond=0).isoformat()
        _update_module_seen(conn, now)

        conn.commit()
    finally:
        conn.close()

    sys.stdout.write(str(db_path) + "\n")


@registry_app.command("scan")
def registry_scan(
    roots: list[str] | None = typer.Option(None, "--root", help="Project-owned source root (repeatable)")
) -> None:
    repo_root = _repo_root()
    db_path = _registry_db_path(repo_root)
    conn = _registry_connect(db_path)
    try:
        _registry_init_schema(conn)
        scan_roots = _parse_roots_arg(repo_root, roots)
        rows = _scan_imports(repo_root, scan_roots)
        conn.execute("DELETE FROM imports")
        conn.executemany(
            "INSERT OR REPLACE INTO imports(importer,specifier,kind,resolved_id) VALUES (?,?,?,?)",
            rows,
        )

        from datetime import datetime, timezone

        now = datetime.now(timezone.utc).replace(microsecond=0).isoformat()
        _update_module_seen(conn, now)

        conn.commit()
    finally:
        conn.close()
    sys.stdout.write("ok\n")


def _registry_missing(conn) -> list[dict[str, str]]:
    missing: list[dict[str, str]] = []

    # external
    for row in conn.execute(
        """
        SELECT importer, specifier, resolved_id
        FROM imports
        WHERE kind='external'
        AND substr(resolved_id, 5) NOT IN (SELECT name FROM allowed_packages)
        ORDER BY importer, specifier
        """
    ):
        importer, specifier, resolved_id = row
        missing.append({"importer": importer, "specifier": specifier, "resolved_id": resolved_id, "kind": "external"})

    # internal
    for row in conn.execute(
        """
        SELECT importer, specifier, resolved_id
        FROM imports
        WHERE kind='internal'
        AND resolved_id NOT IN (SELECT item_id FROM registered_items)
        ORDER BY importer, specifier
        """
    ):
        importer, specifier, resolved_id = row
        missing.append({"importer": importer, "specifier": specifier, "resolved_id": resolved_id, "kind": "internal"})

    return missing


@registry_app.command("validate")
def registry_validate(
    json_out: Path | None = typer.Option(None, "--json", help="Write machine-readable missing-registration report")
) -> None:
    repo_root = _repo_root()
    db_path = _registry_db_path(repo_root)
    conn = _registry_connect(db_path)
    try:
        _registry_init_schema(conn)
        missing = _registry_missing(conn)
    finally:
        conn.close()

    if json_out:
        json_out.parent.mkdir(parents=True, exist_ok=True)
        json_out.write_text(_json_dump({"missing": missing}), encoding="utf-8")

    if missing:
        sys.stdout.write("UNREGISTERED IMPORTS\n")
        for m in missing:
            sys.stdout.write(f"{m['kind']} missing: {m['resolved_id']} (imported by {m['importer']} via {m['specifier']})\n")
        raise typer.Exit(code=2)

    sys.stdout.write("ok\n")


@registry_app.command("report")
def registry_report() -> None:
    repo_root = _repo_root()
    db_path = _registry_db_path(repo_root)
    conn = _registry_connect(db_path)
    try:
        _registry_init_schema(conn)
        missing = _registry_missing(conn)
    finally:
        conn.close()

    sys.stdout.write(_json_dump({"missing": missing}))


@registry_app.command("cards")
def registry_cards(
    out: Path = typer.Option(..., "--out", help="Write module cards as JSONL"),
    roots: list[str] | None = typer.Option(None, "--root", help="Project-owned source root (repeatable)"),
) -> None:
    """Generate module cards (imports/exports/usage snippets) for the repo."""

    repo_root = _repo_root()
    db_path = _registry_db_path(repo_root)

    conn = _registry_connect(db_path)
    try:
        _registry_init_schema(conn)
        rows = list(conn.execute("select importer,specifier,kind,resolved_id from imports"))
    finally:
        conn.close()

    scan_roots = _parse_roots_arg(repo_root, roots)
    cards = build_module_cards(repo_root=repo_root, roots=scan_roots, imports_rows=[tuple(map(str, r)) for r in rows])
    write_cards_jsonl(cards, out)
    sys.stdout.write(str(out) + "\n")


@registry_app.command("detect-pathways")
def registry_detect_pathways(
    json_out: Path | None = typer.Option(None, "--json", help="Write pathway detection report as JSON"),
    roots: list[str] | None = typer.Option(None, "--root", help="Project-owned source root (repeatable)"),
) -> None:
    """Detect module-level pathways + competing seams from the internal import graph."""

    repo_root = _repo_root()
    db_path = _registry_db_path(repo_root)

    conn = _registry_connect(db_path)
    try:
        _registry_init_schema(conn)
        rows = list(conn.execute("select importer,specifier,kind,resolved_id from imports"))
    finally:
        conn.close()

    # Optionally restrict to roots (by filtering importers); keeps detector general.
    if roots:
        allowed_prefixes = tuple((r.rstrip("/") + "/") for r in roots)
        filtered = []
        for importer, spec, kind, resolved in rows:
            imp = str(importer)
            if imp.startswith(allowed_prefixes):
                filtered.append((str(importer), str(spec), str(kind), str(resolved)))
        rows2 = filtered
    else:
        rows2 = [tuple(map(str, r)) for r in rows]

    # Build effect tokens for any module ids we see.
    module_ids = sorted({str(r[3]) for r in rows2 if str(r[2]) == "internal" and str(r[3]).startswith("module:")})
    effect_tokens = {mid: extract_effect_tokens(repo_root, mid) for mid in module_ids}

    report = detect_pathways(imports_rows=rows2, module_effect_tokens=effect_tokens)

    if json_out:
        json_out.parent.mkdir(parents=True, exist_ok=True)
        json_out.write_text(_json_dump(report), encoding="utf-8")
        sys.stdout.write(str(json_out) + "\n")
        return

    sys.stdout.write(_json_dump(report))


@registry_app.command("draft-module-cards")
def registry_draft_module_cards(
    out: Path = typer.Option(..., "--out", help="Write draft module cards JSON"),
    roots: list[str] | None = typer.Option(None, "--root", help="Project-owned source root (repeatable)"),
    focus_module: list[str] | None = typer.Option(None, "--focus-module", help="Only emit cards containing these module_id(s)"),
) -> None:
    """Generate a non-destructive draft module-card registration plan.

    Draft cards are keyed by (domain, card_id, lane) and include exactly one canonical seam.
    Domains/lanes are left as placeholders in v1 drafts (domain=unknown, lane=default).
    """

    repo_root = _repo_root()
    db_path = _registry_db_path(repo_root)

    conn = _registry_connect(db_path)
    try:
        _registry_init_schema(conn)
        rows = list(conn.execute("select importer,specifier,kind,resolved_id from imports"))
    finally:
        conn.close()

    if roots:
        allowed_prefixes = tuple((r.rstrip("/") + "/") for r in roots)
        filtered = []
        for importer, spec, kind, resolved in rows:
            imp = str(importer)
            if imp.startswith(allowed_prefixes):
                filtered.append((str(importer), str(spec), str(kind), str(resolved)))
        rows2 = filtered
    else:
        rows2 = [tuple(map(str, r)) for r in rows]

    module_ids = sorted({str(r[3]) for r in rows2 if str(r[2]) == "internal" and str(r[3]).startswith("module:")})
    effect_tokens = {mid: extract_effect_tokens(repo_root, mid) for mid in module_ids}

    # When called as a Python function (not via Typer CLI), Option defaults may be OptionInfo.
    try:
        from typer.models import OptionInfo  # type: ignore

        if isinstance(focus_module, OptionInfo):
            focus_module = None
    except Exception:
        pass

    focus_set = {str(m).strip() for m in (focus_module or []) if str(m).strip()} or None

    draft = draft_module_cards(imports_rows=rows2, module_effect_tokens=effect_tokens, focus_module_ids=focus_set)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(_json_dump(draft), encoding="utf-8")
    sys.stdout.write(str(out) + "\n")


@registry_app.command("classify-module-cards")
def registry_classify_module_cards(
    draft_in: Path = typer.Option(..., "--in", help="Input draft module cards JSON"),
    out: Path = typer.Option(..., "--out", help="Write classified module cards JSON"),
    allow_new_domains: bool = typer.Option(True, "--allow-new-domains/--no-allow-new-domains", help="Allow classifier to propose new domains"),
    max_new_domains: int = typer.Option(3, "--max-new-domains", help="Cap new domains created per run"),
    stream: bool = typer.Option(True, "--stream/--no-stream", help="Stream CLI output to JSONL log"),
) -> None:
    """Classify overlapping module-card candidates into domains + lanes (LLM-assisted, non-destructive)."""

    import json

    repo_root = _repo_root()

    draft = json.loads(draft_in.read_text(encoding="utf-8"))

    # Known domains from registry (optional; empty enum is allowed).
    db_path = _registry_db_path(repo_root)
    conn = _registry_connect(db_path)
    try:
        _registry_init_schema(conn)
        domain_enum = [str(r[0]) for r in conn.execute("select domain from known_domains order by domain").fetchall()]
    finally:
        conn.close()

    prompt_text = build_classify_prompt(draft=draft, domain_enum=domain_enum, allow_new_domains=allow_new_domains)

    cfg = _read_toml(_global_devflow_dir() / "config.toml")
    llm_mode = str(cfg.get("llm_mode") or "").strip().lower()
    if llm_mode != "cli":
        sys.stderr.write("LLM not configured for CLI mode.\n")
        raise typer.Exit(code=2)

    base_cmd = str(cfg.get("llm_cli_base") or "").strip()
    delivery = str(cfg.get("llm_cli_delivery") or "argument").strip().lower()
    if not base_cmd:
        sys.stderr.write("LLM CLI base command not set.\n")
        raise typer.Exit(code=2)

    if stream:
        sres = run_streaming(
            provider=str(cfg.get("llm_provider") or "cli"),
            base_cmd=base_cmd,
            delivery=delivery,
            prompt=prompt_text,
            cwd=repo_root,
        )
        if not sres.ok:
            sys.stderr.write(sres.stderr or sres.stdout)
            sys.stderr.write(f"\n(llm_session_id={sres.session_id} log={sres.log_path})\n")
            raise typer.Exit(code=2)
        out_text = sres.stdout
    else:
        r = run_one_shot(base_cmd=base_cmd, delivery=delivery, prompt=prompt_text, cwd=repo_root)
        if not r.ok:
            sys.stderr.write(r.stderr or r.stdout)
            raise typer.Exit(code=2)
        out_text = r.stdout

    classified = parse_classified_output(out_text=out_text)

    # Normalize domains to reduce taxonomy entropy.
    domain_enum_set = set(domain_enum)
    if isinstance(classified, dict):
        assigns = classified.get("assignments")
        if isinstance(assigns, list):
            for a in assigns:
                if not isinstance(a, dict):
                    continue
                dom_raw = str(a.get("domain") or "").strip()
                dom_norm = normalize_domain(dom_raw)
                a["domain"] = dom_norm
                nd = a.get("new_domain")
                nd_norm = normalize_domain(str(nd)) if nd else None
                # Only keep new_domain marker if it truly isn't in known domains.
                if nd_norm and nd_norm not in domain_enum_set:
                    a["new_domain"] = nd_norm
                else:
                    a["new_domain"] = None

        # Recompute new_domains list after normalization.
        classified["new_domains"] = sorted({str(a.get("new_domain")) for a in assigns if isinstance(a, dict) and a.get("new_domain")}) if isinstance(assigns, list) else []

    # Auto-register new domains (bounded).
    new_domains = classified.get("new_domains") if isinstance(classified, dict) else None
    if allow_new_domains and isinstance(new_domains, list) and new_domains:
        nd_norm = [normalize_domain(d) for d in new_domains]
        # Only register those not already known.
        nd_norm = [d for d in nd_norm if d and d not in domain_enum_set]
        nd_norm = sorted(set(nd_norm))

        if len(nd_norm) > int(max_new_domains):
            sys.stderr.write(f"Too many new domains proposed ({len(nd_norm)} > {max_new_domains}).\n")
            raise typer.Exit(code=2)

        from datetime import datetime, timezone

        now = datetime.now(timezone.utc).replace(microsecond=0).isoformat()
        conn = _registry_connect(db_path)
        try:
            _registry_init_schema(conn)
            for dom in nd_norm:
                conn.execute(
                    "insert or ignore into known_domains(domain, is_controlled, updated_at) values (?,?,?)",
                    (dom, 1, now),
                )
                conn.execute("update known_domains set updated_at=? where domain=?", (now, dom))
            conn.commit()
        finally:
            conn.close()

        classified["new_domains_registered"] = nd_norm

    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(_json_dump(classified), encoding="utf-8")
    sys.stdout.write(str(out) + "\n")


def _module_phase(conn) -> str:
    row = conn.execute("select value from registry_meta where key='module_registry_phase'").fetchone()
    if row and row[0]:
        return str(row[0])
    return "bootstrap"


def _set_module_phase(conn, phase: str, now: str) -> None:
    conn.execute(
        "insert or replace into registry_meta(key,value,updated_at) values (?,?,?)",
        ("module_registry_phase", phase, now),
    )


def _get_meta(conn, key: str, default: str = "") -> str:
    row = conn.execute("select value from registry_meta where key=?", (key,)).fetchone()
    if row and row[0] is not None:
        return str(row[0])
    return default


def _set_meta(conn, key: str, value: str, now: str) -> None:
    conn.execute(
        "insert or replace into registry_meta(key,value,updated_at) values (?,?,?)",
        (key, value, now),
    )


def _update_module_seen(conn, now: str) -> None:
    # Update module_seen from registered_items (internal modules discovered by scan).
    for (mid,) in conn.execute("select item_id from registered_items where kind='internal_module'").fetchall():
        conn.execute(
            "insert or ignore into module_seen(module_id, first_seen_at, last_seen_at) values (?,?,?)",
            (str(mid), now, now),
        )
        conn.execute("update module_seen set last_seen_at=? where module_id=?", (now, str(mid)))


def _new_modules_since(conn, since: str) -> list[str]:
    if not since:
        return []
    return [
        str(r[0])
        for r in conn.execute(
            "select module_id from module_seen where first_seen_at>? order by module_id",
            (since,),
        ).fetchall()
    ]


def _apply_classified_module_cards(conn, doc: dict[str, object], *, now: str, locked: bool) -> dict[str, object]:
    assigns = doc.get("assignments") if isinstance(doc, dict) else None
    if not isinstance(assigns, list):
        return {"ok": False, "violations": [{"kind": "invalid_format", "message": "missing assignments[]"}]}

    # Existing canonicals per (domain, card_id, lane)
    existing_canon: dict[tuple[str, str, str], str] = {}
    for domain, card_id, lane, module_id in conn.execute(
        "select domain, card_id, lane, module_id from module_card_membership where status='canonical'"
    ).fetchall():
        existing_canon[(str(domain), str(card_id), str(lane))] = str(module_id)

    # Apply assignments
    refactor_required: list[dict[str, str]] = []

    for a in assigns:
        if not isinstance(a, dict):
            continue
        domain = str(a.get("domain") or "").strip()
        card_id = str(a.get("card_id") or "").strip()
        module_id = str(a.get("module_id") or "").strip()
        lane = str(a.get("lane") or "").strip()
        status = str(a.get("status") or "").strip().lower()
        reason = str(a.get("reason") or "").strip()
        if not (domain and card_id and module_id and lane and status in {"canonical", "heretical"}):
            continue

        key = (domain, card_id, lane)
        if locked and status == "canonical" and key in existing_canon and existing_canon[key] != module_id:
            # Locked phase: cannot introduce a new canonical when one already exists.
            # Do NOT persist this newcomer; only emit refactor_required.
            refactor_required.append(
                {
                    "domain": domain,
                    "card_id": card_id,
                    "lane": lane,
                    "module_id": module_id,
                    "canonical_module_id": existing_canon[key],
                }
            )
            continue

        # Ensure card exists
        conn.execute(
            "insert or ignore into module_cards(domain, card_id, allow_multiple_lanes, updated_at) values (?,?,0,?)",
            (domain, card_id, now),
        )
        conn.execute(
            "update module_cards set updated_at=? where domain=? and card_id=?",
            (now, domain, card_id),
        )

        conn.execute(
            "insert or replace into module_card_membership(domain, card_id, module_id, lane, status, reason, updated_at) values (?,?,?,?,?,?,?)",
            (domain, card_id, module_id, lane, status, reason, now),
        )

        if status == "canonical" and key not in existing_canon:
            existing_canon[key] = module_id

    conn.commit()

    # Validate convergence after applying.
    # (Gate expects one canonical per lane.)
    report = gate_classified_module_cards(doc)
    report["refactor_required"] = refactor_required
    return report


@registry_app.command("gate-module-cards")
def registry_gate_module_cards(
    classified_in: Path = typer.Option(..., "--in", help="Input classified module cards JSON"),
    json_out: Path | None = typer.Option(None, "--json", help="Write machine-readable module-card gate report"),
) -> None:
    """Gate classified module-card policy: one canonical per (domain, card_id, lane)."""

    import json

    doc = json.loads(classified_in.read_text(encoding="utf-8"))
    report = gate_classified_module_cards(doc)

    # When called as a Python function, Typer Option defaults may be OptionInfo.
    try:
        from typer.models import OptionInfo  # type: ignore

        if isinstance(json_out, OptionInfo):
            json_out = None
    except Exception:
        pass

    if json_out:
        json_out.parent.mkdir(parents=True, exist_ok=True)
        json_out.write_text(_json_dump(report), encoding="utf-8")

    if not report.get("ok"):
        sys.stdout.write("MODULE CARD POLICY VIOLATIONS\n")
        sys.stdout.write(_json_dump(report))
        raise typer.Exit(code=2)

    sys.stdout.write("ok\n")


@registry_app.command("apply-module-cards")
def registry_apply_module_cards(
    classified_in: Path = typer.Option(..., "--in", help="Input classified module cards JSON"),
    json_out: Path | None = typer.Option(None, "--json", help="Write machine-readable apply report"),
) -> None:
    """Apply classified module-card decisions into the registry DB."""

    import json
    from datetime import datetime, timezone

    repo_root = _repo_root()
    db_path = _registry_db_path(repo_root)

    now = datetime.now(timezone.utc).replace(microsecond=0).isoformat()

    doc = json.loads(classified_in.read_text(encoding="utf-8"))

    conn = _registry_connect(db_path)
    try:
        _registry_init_schema(conn)
        locked = _module_phase(conn) == "locked"
        _update_module_seen(conn, now)
        report = _apply_classified_module_cards(conn, doc, now=now, locked=locked)
        # Mark registry as having applied module-card policy.
        _set_meta(conn, "last_module_registration_at", now, now)
        conn.commit()
    finally:
        conn.close()

    # When called as a Python function, Typer Option defaults may be OptionInfo.
    try:
        from typer.models import OptionInfo  # type: ignore

        if isinstance(json_out, OptionInfo):
            json_out = None
    except Exception:
        pass

    if json_out:
        json_out.parent.mkdir(parents=True, exist_ok=True)
        json_out.write_text(_json_dump(report), encoding="utf-8")

    if not report.get("ok"):
        sys.stdout.write("MODULE CARD APPLY VIOLATIONS\n")
        sys.stdout.write(_json_dump(report))
        raise typer.Exit(code=2)

    sys.stdout.write("ok\n")


@registry_app.command("module-bootstrap")
def registry_module_bootstrap(
    roots: list[str] | None = typer.Option(None, "--root", help="Project-owned source root (repeatable)"),
    max_new_domains: int = typer.Option(5, "--max-new-domains"),
    stream: bool = typer.Option(True, "--stream/--no-stream"),
) -> None:
    """One-time module registration bootstrap for brownfield repos.

    Generates draft cards, classifies overlaps, gates, applies to DB, then locks phase.
    """

    import json
    from datetime import datetime, timezone

    repo_root = _repo_root()
    db_path = _registry_db_path(repo_root)

    # Ensure scan data exists.
    conn = _registry_connect(db_path)
    try:
        _registry_init_schema(conn)
        now = datetime.now(timezone.utc).replace(microsecond=0).isoformat()
        if _module_phase(conn) == "locked":
            sys.stderr.write("module registry already locked\n")
            raise typer.Exit(code=2)
        _update_module_seen(conn, now)
    finally:
        conn.close()

    draft_path = repo_root / ".devflow" / "module_cards" / "draft.json"
    classified_path = repo_root / ".devflow" / "module_cards" / "classified.json"

    # Reuse existing commands in-process.
    registry_draft_module_cards(out=draft_path, roots=roots)

    # Persist singleton (non-overlap) cards immediately as canonical=itself, domain=unknown, lane=default.
    # This gives us a real internal pathway inventory, not just conflict cases.
    try:
        draft_doc = json.loads(draft_path.read_text(encoding="utf-8"))
    except Exception:
        draft_doc = {}

    cards = draft_doc.get("cards") if isinstance(draft_doc, dict) else None
    if isinstance(cards, list):
        conn_single = _registry_connect(db_path)
        try:
            _registry_init_schema(conn_single)
            now_s = datetime.now(timezone.utc).replace(microsecond=0).isoformat()
            for c in cards:
                if not isinstance(c, dict):
                    continue
                comps = c.get("competing_module_ids")
                if isinstance(comps, list) and comps:
                    continue
                canon = str(c.get("canonical_module_id") or "").strip()
                if not canon:
                    continue
                domain = str(c.get("domain") or "unknown").strip() or "unknown"
                card_id = str(c.get("card_id") or "").strip()
                lane = str(c.get("lane") or "default").strip() or "default"
                if not card_id:
                    continue

                conn_single.execute(
                    "insert or ignore into module_cards(domain, card_id, allow_multiple_lanes, updated_at) values (?,?,0,?)",
                    (domain, card_id, now_s),
                )
                conn_single.execute(
                    "insert or replace into module_card_membership(domain, card_id, module_id, lane, status, reason, updated_at) values (?,?,?,?,?,?,?)",
                    (domain, card_id, canon, lane, "canonical", "singleton", now_s),
                )
            conn_single.commit()
        finally:
            conn_single.close()

    # Now classify overlap cards (lanes + canonical/heretical) and apply.
    registry_classify_module_cards(
        draft_in=draft_path,
        out=classified_path,
        allow_new_domains=True,
        max_new_domains=max_new_domains,
        stream=stream,
    )
    registry_gate_module_cards(classified_in=classified_path)
    registry_apply_module_cards(classified_in=classified_path)

    # Lock phase
    conn2 = _registry_connect(db_path)
    try:
        _registry_init_schema(conn2)
        now2 = datetime.now(timezone.utc).replace(microsecond=0).isoformat()
        _set_module_phase(conn2, "locked", now2)
        _set_meta(conn2, "last_module_registration_at", now2, now2)
        conn2.commit()
    finally:
        conn2.close()

    sys.stdout.write("ok\n")


@registry_app.command("module-register-new")
def registry_module_register_new(
    roots: list[str] | None = typer.Option(None, "--root", help="Project-owned source root (repeatable)"),
    max_new_domains: int = typer.Option(3, "--max-new-domains"),
    stream: bool = typer.Option(True, "--stream/--no-stream"),
) -> None:
    """Incremental module registration (locked phase).

    Re-runs draft+classify and applies, but will not allow replacing an existing canonical.
    Instead, it will emit refactor_required records (and not persist the newcomer).
    """

    import json
    from datetime import datetime, timezone

    repo_root = _repo_root()
    db_path = _registry_db_path(repo_root)

    conn = _registry_connect(db_path)
    try:
        _registry_init_schema(conn)
        if _module_phase(conn) != "locked":
            sys.stderr.write("module registry not locked; run module-bootstrap first\n")
            raise typer.Exit(code=2)
        now = datetime.now(timezone.utc).replace(microsecond=0).isoformat()
        _update_module_seen(conn, now)
        conn.commit()
    finally:
        conn.close()

    draft_path = repo_root / ".devflow" / "module_cards" / "draft.json"
    classified_path = repo_root / ".devflow" / "module_cards" / "classified.json"
    apply_report = repo_root / ".devflow" / "module_cards" / "apply_report.json"

    # Incremental focus: only consider cards that involve modules first seen since last registration.
    conn_focus = _registry_connect(db_path)
    try:
        _registry_init_schema(conn_focus)
        since = _get_meta(conn_focus, "last_module_registration_at", "")
        focus_ids = set(_new_modules_since(conn_focus, since))
    finally:
        conn_focus.close()

    if not focus_ids:
        sys.stdout.write("ok\n")
        return

    registry_draft_module_cards(out=draft_path, roots=roots, focus_module=sorted(focus_ids))
    registry_classify_module_cards(
        draft_in=draft_path,
        out=classified_path,
        allow_new_domains=True,
        max_new_domains=max_new_domains,
        stream=stream,
    )

    # Apply (locked rules enforced in apply).
    repo_doc = json.loads(classified_path.read_text(encoding="utf-8"))

    conn2 = _registry_connect(db_path)
    try:
        _registry_init_schema(conn2)
        now2 = datetime.now(timezone.utc).replace(microsecond=0).isoformat()
        report = _apply_classified_module_cards(conn2, repo_doc, now=now2, locked=True)
        # mark registration time for incrementality
        _set_meta(conn2, "last_module_registration_at", now2, now2)
        conn2.commit()
    finally:
        conn2.close()

    apply_report.parent.mkdir(parents=True, exist_ok=True)
    apply_report.write_text(_json_dump(report), encoding="utf-8")

    if report.get("refactor_required"):
        sys.stdout.write("MODULE CARD REFACTOR REQUIRED\n")
        sys.stdout.write(_json_dump(report))
        raise typer.Exit(code=2)

    if not report.get("ok"):
        sys.stdout.write("MODULE CARD POLICY VIOLATIONS\n")
        sys.stdout.write(_json_dump(report))
        raise typer.Exit(code=2)

    sys.stdout.write("ok\n")


@registry_app.command("gate-module-db")
def registry_gate_module_db(
    json_out: Path | None = typer.Option(None, "--json", help="Write machine-readable module DB gate report"),
) -> None:
    """Gate the module-card policy stored in the registry DB."""

    repo_root = _repo_root()
    db_path = _registry_db_path(repo_root)

    conn = _registry_connect(db_path)
    try:
        _registry_init_schema(conn)
        rows = list(
            conn.execute(
                "select domain, card_id, lane, module_id, status from module_card_membership order by domain, card_id, lane, module_id"
            ).fetchall()
        )
    finally:
        conn.close()

    by_key: dict[tuple[str, str, str], list[tuple[str, str]]] = {}
    for domain, card_id, lane, module_id, status in rows:
        key = (str(domain), str(card_id), str(lane))
        by_key.setdefault(key, []).append((str(module_id), str(status)))

    violations: list[dict[str, object]] = []
    for (domain, card_id, lane), items in sorted(by_key.items()):
        canon = [m for (m, st) in items if st == "canonical"]
        if len(canon) != 1:
            violations.append(
                {
                    "kind": "lane_not_converged",
                    "domain": domain,
                    "card_id": card_id,
                    "lane": lane,
                    "canonicals": canon,
                    "members": items,
                }
            )

    report = {"ok": not violations, "violations": violations, "keys": len(by_key)}

    if json_out:
        json_out.parent.mkdir(parents=True, exist_ok=True)
        json_out.write_text(_json_dump(report), encoding="utf-8")

    if violations:
        sys.stdout.write("MODULE DB POLICY VIOLATIONS\n")
        sys.stdout.write(_json_dump(report))
        raise typer.Exit(code=2)

    sys.stdout.write("ok\n")


@registry_app.command("policy-refresh")
def registry_policy_refresh() -> None:
    """Autonomously infer package domains and compute canonical/heretical status."""

    repo_root = _repo_root()
    db_path = _registry_db_path(repo_root)

    conn = _registry_connect(db_path)
    try:
        _registry_init_schema(conn)
        meta = refresh_policy(conn)
    finally:
        conn.close()

    sys.stdout.write(_json_dump(meta))


@registry_app.command("policy-set-canonical")
def registry_policy_set_canonical(
    domain: str = typer.Option(..., "--domain"),
    package: str = typer.Option(..., "--package"),
) -> None:
    """Manually set the canonical package for a domain."""

    from datetime import datetime, timezone

    now = datetime.now(timezone.utc).replace(microsecond=0).isoformat()
    repo_root = _repo_root()
    db_path = _registry_db_path(repo_root)

    conn = _registry_connect(db_path)
    try:
        _registry_init_schema(conn)
        conn.execute(
            "insert or replace into domain_policy(domain, canonical_package, allow_multiple, updated_at) "
            "values (?, ?, coalesce((select allow_multiple from domain_policy where domain=?), 0), ?)",
            (domain, package, domain, now),
        )
        conn.commit()
    finally:
        conn.close()

    sys.stdout.write("ok\n")


@registry_app.command("policy-allow-multiple")
def registry_policy_allow_multiple(
    domain: str = typer.Option(..., "--domain"),
    allow: bool = typer.Option(True, "--allow/--disallow", help="Allow multiple packages in this domain"),
) -> None:
    """Allow multiple packages in a domain (requires lane assignments)."""

    from datetime import datetime, timezone

    now = datetime.now(timezone.utc).replace(microsecond=0).isoformat()
    repo_root = _repo_root()
    db_path = _registry_db_path(repo_root)

    conn = _registry_connect(db_path)
    try:
        _registry_init_schema(conn)
        conn.execute(
            "insert or replace into domain_policy(domain, canonical_package, allow_multiple, updated_at) "
            "values (?, coalesce((select canonical_package from domain_policy where domain=?), null), ?, ?)",
            (domain, domain, 1 if allow else 0, now),
        )
        conn.commit()
    finally:
        conn.close()

    sys.stdout.write("ok\n")


@registry_app.command("policy-set-domain")
def registry_policy_set_domain(
    package: str = typer.Option(..., "--package"),
    domain: str = typer.Option(..., "--domain"),
) -> None:
    """Manually assign a package to a domain (override heuristic)."""

    from datetime import datetime, timezone

    now = datetime.now(timezone.utc).replace(microsecond=0).isoformat()
    repo_root = _repo_root()
    db_path = _registry_db_path(repo_root)

    conn = _registry_connect(db_path)
    try:
        _registry_init_schema(conn)
        conn.execute(
            "insert or replace into package_domain_overrides(package, domain, updated_at) values (?,?,?)",
            (package, domain, now),
        )
        conn.commit()
    finally:
        conn.close()

    sys.stdout.write("ok\n")


@registry_app.command("domain-set-controlled")
def registry_domain_set_controlled(
    domain: str = typer.Option(..., "--domain"),
    controlled: bool = typer.Option(True, "--controlled/--uncontrolled", help="Whether this domain is enforced"),
) -> None:
    """Set whether a domain is controlled (enforced) by the package gate.

    Last-resort escape hatch. Prefer resolving with lanes + canonical/heretical.
    """

    from datetime import datetime, timezone

    now = datetime.now(timezone.utc).replace(microsecond=0).isoformat()
    repo_root = _repo_root()
    db_path = _registry_db_path(repo_root)
    conn = _registry_connect(db_path)
    try:
        _registry_init_schema(conn)
        conn.execute(
            "insert or replace into known_domains(domain, is_controlled, updated_at) values (?,?,?)",
            (domain, 1 if controlled else 0, now),
        )
        conn.commit()
    finally:
        conn.close()

    sys.stdout.write("ok\n")


@registry_app.command("policy-set-lane")
def registry_policy_set_lane(
    domain: str = typer.Option(..., "--domain"),
    package: str = typer.Option(..., "--package"),
    lane: str = typer.Option(..., "--lane", help="Lane identifier (e.g., ui, unit, integration, e2e)"),
) -> None:
    """Assign a package to a lane within a domain."""

    from datetime import datetime, timezone

    now = datetime.now(timezone.utc).replace(microsecond=0).isoformat()
    repo_root = _repo_root()
    db_path = _registry_db_path(repo_root)

    conn = _registry_connect(db_path)
    try:
        _registry_init_schema(conn)
        conn.execute(
            "insert or replace into package_lanes(domain, package, lane, updated_at) values (?,?,?,?)",
            (domain, package, lane, now),
        )
        conn.commit()
    finally:
        conn.close()

    sys.stdout.write("ok\n")


@registry_app.command("policy-set-status")
def registry_policy_set_status(
    domain: str = typer.Option(..., "--domain"),
    package: str = typer.Option(..., "--package"),
    status: str = typer.Option(..., "--status", help="canonical|heretical|allowed"),
) -> None:
    """Manually override canonical/heretical status for a package within a domain."""

    from datetime import datetime, timezone

    st = status.strip().lower()
    if st not in {"canonical", "heretical", "allowed"}:
        raise typer.Exit(code=2)

    now = datetime.now(timezone.utc).replace(microsecond=0).isoformat()
    repo_root = _repo_root()
    db_path = _registry_db_path(repo_root)

    conn = _registry_connect(db_path)
    try:
        _registry_init_schema(conn)
        conn.execute(
            "insert or replace into package_status_overrides(domain, package, status, updated_at) values (?,?,?,?)",
            (domain, package, st, now),
        )
        conn.commit()
    finally:
        conn.close()

    sys.stdout.write("ok\n")


@registry_app.command("resolve-multiplicity")
def registry_resolve_multiplicity(
    domain: str | None = typer.Option(None, "--domain", help="Resolve one domain (default: all controlled domains)"),
    limit: int = typer.Option(60, "--limit", help="Max packages per domain to resolve"),
    dry_run: bool = typer.Option(False, "--dry-run"),
    stream: bool = typer.Option(True, "--stream/--no-stream"),
) -> None:
    """Use LLM to partition packages into lanes and mark canonical/heretical within each lane.

    This is the preferred mechanism to make brownfield repos pass strict gating.
    """

    import json
    from datetime import datetime, timezone

    # When called as a Python function, Typer Option defaults may be OptionInfo.
    try:
        from typer.models import OptionInfo  # type: ignore

        if isinstance(domain, OptionInfo):
            domain = None
        if isinstance(limit, OptionInfo):
            limit = 60
        if isinstance(dry_run, OptionInfo):
            dry_run = False
        if isinstance(stream, OptionInfo):
            stream = True
    except Exception:
        pass

    repo_root = _repo_root()
    db_path = _registry_db_path(repo_root)

    cfg = _read_toml(_global_devflow_dir() / "config.toml")
    llm_mode = str(cfg.get("llm_mode") or "").strip().lower()
    if llm_mode != "cli":
        sys.stderr.write("LLM not configured for CLI mode.\n")
        raise typer.Exit(code=2)

    base_cmd = str(cfg.get("llm_cli_base") or "").strip()
    delivery = str(cfg.get("llm_cli_delivery") or "argument").strip().lower()
    if not base_cmd:
        sys.stderr.write("LLM CLI base command not set.\n")
        raise typer.Exit(code=2)

    # Load domain package sets
    conn = _registry_connect(db_path)
    try:
        _registry_init_schema(conn)
        refresh_policy(conn)

        domains = [str(r[0]) for r in conn.execute("select domain from domain_policy order by domain").fetchall()]
        controlled = {str(d): bool(int(c)) for d, c in conn.execute("select domain, is_controlled from known_domains").fetchall()}

        if domain:
            domains = [domain]

        # Package purposes
        purposes = {str(p): str(pur) for p, pur in conn.execute("select package, purpose from package_purpose").fetchall()}

        # Import counts
        counts = {
            str(pkg): int(cnt)
            for pkg, cnt in conn.execute(
                "select substr(resolved_id,5) as pkg, count(*) as cnt from imports where kind='external' group by pkg"
            ).fetchall()
        }

        domain_to_pkgs: dict[str, list[str]] = {}
        for d in domains:
            if not controlled.get(d, True):
                continue
            pkgs = [str(r[0]) for r in conn.execute("select package from package_status where domain=? and status!='unknown' order by package", (d,)).fetchall()]
            if len(pkgs) <= 1:
                continue
            domain_to_pkgs[d] = pkgs[: max(0, int(limit))]

    finally:
        conn.close()

    if not domain_to_pkgs:
        sys.stdout.write("ok\n")
        return

    now = datetime.now(timezone.utc).replace(microsecond=0).isoformat()

    for d, pkgs in domain_to_pkgs.items():
        payload = {
            "task": "resolve_domain_multiplicity",
            "domain": d,
            "packages": [
                {
                    "package": p,
                    "import_count": counts.get(p, 0),
                    "purpose": purposes.get(p, ""),
                }
                for p in pkgs
            ],
            "instructions": [
                "Return JSON only.",
                "Partition packages into lanes (unique concerns) within this domain.",
                "Within each lane, mark exactly one package as canonical and all others heretical.",
                "If two packages are essentially the same concern, put them in the same lane.",
            ],
            "output_schema": {
                "allow_multiple": True,
                "assignments": [
                    {"package": "string", "lane": "string", "status": "canonical|heretical", "reason": "string"}
                ],
            },
        }

        prompt_text = json.dumps(payload, indent=2, sort_keys=True)
        if dry_run:
            sys.stdout.write(prompt_text + "\n")
            continue

        if stream:
            sres = run_streaming(provider=str(cfg.get("llm_provider") or "cli"), base_cmd=base_cmd, delivery=delivery, prompt=prompt_text, cwd=repo_root)
            if not sres.ok:
                sys.stderr.write(sres.stderr or sres.stdout)
                sys.stderr.write(f"\n(llm_session_id={sres.session_id} log={sres.log_path})\n")
                raise typer.Exit(code=2)
            out_text = sres.stdout
        else:
            r = run_one_shot(base_cmd=base_cmd, delivery=delivery, prompt=prompt_text, cwd=repo_root)
            if not r.ok:
                sys.stderr.write(r.stderr or r.stdout)
                raise typer.Exit(code=2)
            out_text = r.stdout

        raw_json = _extract_json(out_text)
        if raw_json is None:
            sys.stderr.write("Failed to locate JSON in LLM output.\n")
            sys.stderr.write(out_text[:2000] + "\n")
            raise typer.Exit(code=2)

        parsed = json.loads(raw_json)
        assignments = parsed.get("assignments") if isinstance(parsed, dict) else None
        if not isinstance(assignments, list):
            sys.stderr.write("LLM output missing assignments[].\n")
            raise typer.Exit(code=2)

        # Normalize + enforce convergence deterministically.
        pkg_to_lane: dict[str, str] = {}
        pkg_to_status: dict[str, str] = {}
        for a in assignments:
            if not isinstance(a, dict):
                continue
            pkg = str(a.get("package") or "").strip()
            lane = str(a.get("lane") or "").strip()
            st = str(a.get("status") or "").strip().lower()
            if pkg not in pkgs or not lane or st not in {"canonical", "heretical"}:
                continue
            pkg_to_lane[pkg] = lane
            pkg_to_status[pkg] = st

        missing = [p for p in pkgs if p not in pkg_to_lane]
        if missing:
            sys.stderr.write(f"LLM did not assign lanes for all packages in domain={d}. Missing: {missing[:10]}\n")
            raise typer.Exit(code=2)

        # Converge per lane: exactly one canonical.
        lane_to_pkgs: dict[str, list[str]] = {}
        for p in pkgs:
            lane_to_pkgs.setdefault(pkg_to_lane[p], []).append(p)

        def _rank(p: str) -> tuple[int, str]:
            return (int(counts.get(p, 0)), p)

        for lane, lp in lane_to_pkgs.items():
            canonicals = [p for p in lp if pkg_to_status.get(p) == "canonical"]
            if len(canonicals) == 1:
                continue
            # Choose canonical deterministically by import_count desc, then name.
            chosen = sorted(lp, key=lambda p: (-_rank(p)[0], _rank(p)[1]))[0]
            for p in lp:
                pkg_to_status[p] = "canonical" if p == chosen else "heretical"

        conn = _registry_connect(db_path)
        try:
            _registry_init_schema(conn)
            # Domain now allows multiple lanes.
            conn.execute(
                "insert or replace into domain_policy(domain, canonical_package, allow_multiple, updated_at) values (?, coalesce((select canonical_package from domain_policy where domain=?), null), 1, ?)",
                (d, d, now),
            )

            for p in pkgs:
                lane = pkg_to_lane[p]
                st = pkg_to_status.get(p, "heretical")
                conn.execute(
                    "insert or replace into package_lanes(domain, package, lane, updated_at) values (?,?,?,?)",
                    (d, p, lane, now),
                )
                conn.execute(
                    "insert or replace into package_status_overrides(domain, package, status, updated_at) values (?,?,?,?)",
                    (d, p, st, now),
                )

            conn.commit()
        finally:
            conn.close()

    sys.stdout.write("ok\n")


@registry_app.command("gate-packages")
def registry_gate_packages(
    json_out: Path | None = typer.Option(None, "--json", help="Write machine-readable package gate report"),
) -> None:
    """Gate external package diversity by domain (autonomous, DB-backed)."""

    repo_root = _repo_root()
    db_path = _registry_db_path(repo_root)

    conn = _registry_connect(db_path)
    try:
        _registry_init_schema(conn)
        report = gate_from_db(conn)
    finally:
        conn.close()

    if json_out:
        json_out.parent.mkdir(parents=True, exist_ok=True)
        json_out.write_text(dump_report(report), encoding="utf-8")

    if report.get("violations"):
        sys.stdout.write("PACKAGE POLICY VIOLATIONS\n")
        sys.stdout.write(dump_report(report))
        raise typer.Exit(code=2)

    sys.stdout.write("ok\n")


@registry_app.command("classify-packages")
def registry_classify_packages(
    limit: int = typer.Option(200, "--limit", help="Max unknown packages to classify in one shot"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Print prompt and exit"),
    stream: bool = typer.Option(True, "--stream/--no-stream", help="Stream CLI output to JSONL log"),
) -> None:
    """Classify unknown external packages into domains and write overrides.

    Provider selection comes from global config (DEVFLOW_HOME/.devflow/config.toml).

    NOTE: This is one-shot only; resume/streaming is out of scope for v1.
    """

    import json
    from datetime import datetime, timezone

    # When called as a Python function, Typer Option defaults may be OptionInfo.
    try:
        from typer.models import OptionInfo  # type: ignore

        if isinstance(limit, OptionInfo):
            limit = 200
        if isinstance(dry_run, OptionInfo):
            dry_run = False
        if isinstance(stream, OptionInfo):
            stream = True
    except Exception:
        pass

    repo_root = _repo_root()
    db_path = _registry_db_path(repo_root)

    cfg = _read_toml(_global_devflow_dir() / "config.toml")
    llm_mode = str(cfg.get("llm_mode") or "").strip().lower()
    if llm_mode != "cli":
        sys.stderr.write("LLM not configured for CLI mode. Run: devflow config llm-set-provider --mode cli --provider <...>\n")
        raise typer.Exit(code=2)

    base_cmd = str(cfg.get("llm_cli_base") or "").strip()
    delivery = str(cfg.get("llm_cli_delivery") or "argument").strip().lower()
    if not base_cmd:
        sys.stderr.write("LLM CLI base command not set. Run: devflow config llm-set-provider ...\n")
        raise typer.Exit(code=2)

    conn = _registry_connect(db_path)
    try:
        _registry_init_schema(conn)
        # Ensure policy tables exist
        _ = refresh_policy(conn)

        unknown = [
            str(r[0])
            for r in conn.execute("select package from package_status where status='unknown' order by package").fetchall()
        ]

        # Evidence: import counts
        counts = {
            str(pkg): int(cnt)
            for pkg, cnt in conn.execute(
                "select substr(resolved_id,5) as pkg, count(*) as cnt from imports where kind='external' group by pkg"
            ).fetchall()
        }

        # Known domains enum
        domains = [str(r[0]) for r in conn.execute("select domain from known_domains order by domain").fetchall()]
    finally:
        conn.close()

    unknown = unknown[: max(0, int(limit))]

    if not unknown:
        sys.stdout.write("ok\n")
        return

    prompt = {
        "task": "classify_external_packages",
        "domains_enum": domains,
        "packages": [
            {"package": p, "import_count": counts.get(p, 0)}
            for p in unknown
        ],
        "instructions": [
            "Return JSON only (no markdown, no code fences).",
            "For each package, assign a domain from domains_enum OR propose a new domain.",
            "If proposing a new domain, return it as new_domain and also set domain to that value.",
            "Also return a short purpose string (max 12 words).",
        ],
        "output_schema": {
            "assignments": [
                {"package": "string", "domain": "string", "new_domain": "string|null", "purpose": "string", "confidence": "number"}
            ]
        },
    }

    prompt_text = json.dumps(prompt, indent=2, sort_keys=True)

    if dry_run:
        sys.stdout.write(prompt_text + "\n")
        raise typer.Exit(code=0)

    # Run CLI one-shot (optionally streaming to log)
    if stream:
        sres = run_streaming(provider=str(cfg.get("llm_provider") or "cli"), base_cmd=base_cmd, delivery=delivery, prompt=prompt_text, cwd=repo_root)
        if not sres.ok:
            sys.stderr.write(sres.stderr or sres.stdout)
            sys.stderr.write(f"\n(llm_session_id={sres.session_id} log={sres.log_path})\n")
            raise typer.Exit(code=2)
        out_text = sres.stdout
    else:
        result = run_one_shot(base_cmd=base_cmd, delivery=delivery, prompt=prompt_text, cwd=repo_root)
        if not result.ok:
            sys.stderr.write(result.stderr or result.stdout)
            raise typer.Exit(code=2)
        out_text = result.stdout

    raw_json = _extract_json(out_text)
    if raw_json is None:
        sys.stderr.write("Failed to locate JSON in LLM output.\n")
        sys.stderr.write(out_text[:2000] + "\n")
        raise typer.Exit(code=2)

    try:
        parsed = json.loads(raw_json)
    except Exception:
        sys.stderr.write("Failed to parse JSON from LLM output.\n")
        sys.stderr.write(raw_json[:2000] + "\n")
        raise typer.Exit(code=2)

    assignments = parsed.get("assignments") if isinstance(parsed, dict) else None
    if not isinstance(assignments, list):
        sys.stderr.write("LLM output missing assignments[].\n")
        raise typer.Exit(code=2)

    now = datetime.now(timezone.utc).replace(microsecond=0).isoformat()

    conn = _registry_connect(db_path)
    try:
        _registry_init_schema(conn)
        for a in assignments:
            if not isinstance(a, dict):
                continue
            pkg = str(a.get("package") or "").strip()
            dom = str(a.get("domain") or "").strip()
            new_dom = str(a.get("new_domain") or "").strip() or None
            purpose = str(a.get("purpose") or "").strip()
            conf = a.get("confidence")
            try:
                conf_f = float(conf) if conf is not None else None
            except Exception:
                conf_f = None

            if not pkg or not dom or pkg not in unknown:
                continue

            # Strict: any new domain is controlled by default.
            if new_dom:
                conn.execute(
                    "insert or ignore into known_domains(domain, is_controlled, updated_at) values (?,?,?)",
                    (dom, 1, now),
                )
            else:
                conn.execute(
                    "insert or ignore into known_domains(domain, is_controlled, updated_at) values (?,?,?)",
                    (dom, 1, now),
                )

            conn.execute("update known_domains set updated_at=? where domain=?", (now, dom))

            conn.execute(
                "insert or replace into package_domain_overrides(package, domain, updated_at) values (?,?,?)",
                (pkg, dom, now),
            )

            if purpose:
                conn.execute(
                    "insert or replace into package_purpose(package, domain, purpose, decided_by, confidence, updated_at) values (?,?,?,?,?,?)",
                    (pkg, dom, purpose, "llm", conf_f, now),
                )

        conn.commit()
    finally:
        conn.close()

    sys.stdout.write("ok\n")


# ----------------------------
# Area5: Idea tool
# ----------------------------


@idea_app.command("init")
def idea_init(
    idea_id: str = typer.Option(..., "--idea", help="Idea identifier"),
    title: str = typer.Option("", help="Idea title"),
    text: str | None = typer.Option(None, "--text", help="Full idea text for immediate sufficiency shaping"),
) -> None:
    repo_root, _store_ = _store()
    _ = _store_

    idea_dir = repo_root / ".devflow" / "ideas" / idea_id
    idea_dir.mkdir(parents=True, exist_ok=True)
    idea_json = idea_dir / "idea.json"

    if text:
        # Shape the idea immediately via sufficiency evaluation
        raw_text, input_meta = load_idea_source(text=text, source_path=None)
        result = evaluate_idea_sufficiency(raw_text, input_meta=input_meta)
        sufficient_idea = dict(result.payload.get("sufficient_idea") or {})
        artifact = {
            "idea_id": idea_id,
            "title": title,
            "raw_text": text,
            "problem": str(sufficient_idea.get("problem") or "").strip(),
            "target_users": [str(item).strip() for item in (sufficient_idea.get("target_users") or []) if str(item).strip()],
            "user_outcomes": [str(item).strip() for item in (sufficient_idea.get("user_outcomes") or []) if str(item).strip()],
            "scope": [str(item).strip() for item in (sufficient_idea.get("scope") or []) if str(item).strip()],
            "assumptions": [str(item).strip() for item in (sufficient_idea.get("assumptions") or []) if str(item).strip()],
            "sufficiency": result.payload,
        }
        idea_json.write_text(json.dumps(artifact, indent=2, sort_keys=True), encoding="utf-8")
    elif not idea_json.exists():
        idea_json.write_text(json.dumps({"idea_id": idea_id, "title": title}, indent=2, sort_keys=True), encoding="utf-8")

    console.print(f"idea_id: {idea_id}")
    console.print(f"idea_dir: {idea_dir}")


@idea_app.command("analyze")
def idea_analyze(
    idea_id: str = typer.Option(..., "--idea", help="Idea identifier"),
) -> None:
    repo_root, _store_ = _store()
    _ = _store_

    analysis_id = datetime.now(timezone.utc).strftime("%Y%m%d%H%M%S") + "_" + os.urandom(3).hex()
    artifact_dir = write_analysis_artifact(repo_root=repo_root, idea_id=idea_id, analysis_id=analysis_id)

    # Contract: analysis_id must be discoverable in output.
    console.print(f"analysis_id: {analysis_id}")
    console.print(f"artifact_dir: {artifact_dir}")


@idea_app.command("sufficiency")
def idea_sufficiency(
    text: str | None = typer.Option(None, "--text", help="Raw idea text"),
    source_path: Path | None = typer.Option(None, "--from", help="Read idea text from a file"),
) -> None:
    try:
        raw_text, input_meta = load_idea_source(text=text, source_path=source_path)
    except ValueError as exc:
        console.print(str(exc))
        raise typer.Exit(code=2)

    result = evaluate_idea_sufficiency(raw_text, input_meta=input_meta)
    sys.stdout.write(render_sufficiency_json(result))
    if not result.passed:
        raise typer.Exit(code=2)


@idea_app.command("intake")
def idea_intake(
    idea_id: str = typer.Option(..., "--idea", help="Idea identifier"),
    text: str | None = typer.Option(None, "--text", help="Raw idea text"),
    source_path: Path | None = typer.Option(None, "--from", help="Read idea text from a file"),
    max_stories: int = typer.Option(0, "--max-stories", min=0, help="Optional story-count hint (0 means uncapped)"),
    planes: str | None = typer.Option(None, "--planes", help="Comma separated plane list for compiled DevFlow stories (required; no defaults)"),
    session_id: str | None = typer.Option(None, "--session-id", help="Original session_id to use for response tracking (preserves caller session continuity)"),
) -> None:
    repo_root, store = _store()
    plane_list = [p.strip() for p in (planes.split(",") if planes else []) if p.strip()]

    try:
        result = run_devin_chat_dag(
            repo_root=repo_root,
            store=store,
            idea_id=idea_id,
            text=text,
            source_path=source_path,
            max_stories=max_stories,
            planes=plane_list,
            source_session_id=session_id,
        )
    except ValueError as exc:
        sys.stdout.write(str(exc) + "\n")
        raise typer.Exit(code=2)

    sys.stdout.write(result.message)
    if result.exit_code != 0:
        raise typer.Exit(code=result.exit_code)


@idea_app.command("eval-live-multi-turn")
def idea_eval_live_multi_turn(
    target_repo: Path = typer.Option(..., "--target-repo", exists=True, file_okay=False, dir_okay=True, resolve_path=True, help="Repo whose docs/state should be used as the live ideation target"),
    scenario: list[str] = typer.Option(None, "--scenario", help="Specific scenario_id to run (repeatable). Defaults to the full live multi-turn suite."),
    evals_root: Path | None = typer.Option(None, "--evals-root", help="Optional override for durable eval output root"),
    idea_id_prefix: str = typer.Option("devin_live_eval", "--idea-prefix", help="Prefix for generated idea ids so runs stay isolated"),
    turn_timeout_seconds: int = typer.Option(180, "--turn-timeout-seconds", min=1, help="Hard timeout per live turn so the suite records hangs instead of stalling forever"),
    json_out: bool = typer.Option(False, "--json", help="Emit JSON summary instead of human text"),
) -> None:
    codebase_repo_root = _repo_root()
    target_repo_root = target_repo.expanduser().resolve()
    selected = [item for item in DEFAULT_MULTI_TURN_SCENARIOS if not scenario or item.scenario_id in set(scenario)]
    if scenario and len(selected) != len(set(scenario)):
        known = ", ".join(item.scenario_id for item in DEFAULT_MULTI_TURN_SCENARIOS)
        missing = sorted(set(scenario) - {item.scenario_id for item in DEFAULT_MULTI_TURN_SCENARIOS})
        sys.stdout.write(f"Unknown scenario id(s): {', '.join(missing)}\nKnown scenarios: {known}\n")
        raise typer.Exit(code=2)
    result = run_devin_multi_turn_eval_suite(
        codebase_repo_root=codebase_repo_root,
        target_repo_root=target_repo_root,
        scenarios=selected,
        evals_root=evals_root.expanduser().resolve() if evals_root else None,
        idea_id_prefix=idea_id_prefix,
        turn_timeout_seconds=turn_timeout_seconds,
    )
    if json_out:
        sys.stdout.write(json.dumps(result.payload, indent=2, sort_keys=True) + "\n")
        return
    sys.stdout.write(json.dumps({
        "run_id": result.run_id,
        "eval_root": str(result.eval_root),
        "target_repo_root": str(target_repo_root),
        "all_scenarios_passed": bool(result.payload.get("all_scenarios_passed")),
        "scenarios": result.payload.get("scenarios") or [],
    }, indent=2, sort_keys=True) + "\n")


@idea_drafts_app.command("generate")
def idea_drafts_generate(
    idea_id: str = typer.Option(..., "--idea", help="Idea identifier"),
    analysis_id: str = typer.Option(..., "--analysis", help="Analysis id"),
    planes: str | None = typer.Option(None, "--planes", help="Comma separated plane list"),
) -> None:
    repo_root, _store_ = _store()
    _ = _store_

    plane_list = [p.strip() for p in (planes.split(",") if planes else []) if p.strip()] or ["api"]
    ds = generate_draft_set(repo_root=repo_root, idea_id=idea_id, analysis_id=analysis_id, planes=plane_list)

    console.print(f"generated {len(plane_list)} plane(s)")
    console.print(f"draft_set_id: {ds.draft_set_id}")
    console.print(f"drafts_dir: {ds.root}")


@idea_app.command("promote")
def idea_promote(
    idea_id: str = typer.Option(..., "--idea", help="Idea identifier"),
    draft_set_id: str = typer.Option(..., "--draft-set", help="Draft set id"),
    dest: Path = typer.Option(..., "--dest", help="Canonical destination root"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Print plan and do not write"),
    force: bool = typer.Option(False, "--force", help="Allow overwriting existing canonical files"),
) -> None:
    repo_root, _store_ = _store()
    _ = _store_

    ops = plan_promotion(repo_root=repo_root, idea_id=idea_id, draft_set_id=draft_set_id, dest_root=dest)

    if dry_run:
        console.print("dry-run promotion plan")
        for op in ops:
            console.print(f"would {op.kind}: {op.dest}")
        return

    ok, msgs = apply_promotion(ops=ops, force=force)
    for m in msgs:
        console.print(m)
    if not ok:
        raise typer.Exit(code=2)


@idea_drafts_app.command("diff")
def idea_drafts_diff(
    idea_id: str = typer.Option(..., "--idea", help="Idea identifier"),
    draft_set_id: str = typer.Option(..., "--draft-set", help="Draft set id"),
    canonical: Path = typer.Option(
        Path("ai_docs/context/v2/project_docs/user_stories"),
        "--canonical",
        help="Canonical stories root",
    ),
    format: str = typer.Option("text", "--format", help="Output format: text|json"),
) -> None:
    repo_root, _store_ = _store()
    _ = _store_

    canon_root = canonical if canonical.is_absolute() else (repo_root / canonical)
    entries = compute_diff(repo_root=repo_root, idea_id=idea_id, draft_set_id=draft_set_id, canonical_root=canon_root)

    if format.lower() == "json":
        sys.stdout.write(render_diff_json(entries))
    else:
        sys.stdout.write(render_diff_text(entries))


@idea_stories_app.command("generate")
def idea_stories_generate(
    idea_id: str = typer.Option(..., "--idea", help="Idea identifier"),
    max_stories: int = typer.Option(0, "--max-stories", min=0, help="Optional story-count hint (0 means uncapped)"),
) -> None:
    repo_root, _store_ = _store()
    _ = _store_

    try:
        story_set = generate_traditional_user_story_set(repo_root=repo_root, idea_id=idea_id, max_stories=max_stories)
    except FileNotFoundError:
        sys.stderr.write(f"Missing idea artifact for idea_id={idea_id}\n")
        raise typer.Exit(code=2)
    except ValueError as exc:
        sys.stderr.write(str(exc) + "\n")
        raise typer.Exit(code=2)
    except TraditionalStoryInsufficiencyError as exc:
        report = exc.report
        sys.stderr.write(
            json.dumps(
                {
                    "error": "traditional story set insufficient after refinement loop",
                    "story_set_id": exc.story_set_id,
                    "stories_dir": str(exc.root),
                    "report_path": str(exc.report_path),
                    "pass_count": report.get("pass_count"),
                    "passed": report.get("passed"),
                    "final_findings": report.get("final_findings"),
                },
                indent=2,
                sort_keys=True,
            )
            + "\n"
        )
        raise typer.Exit(code=2)
    pass_count = int(story_set.sufficiency_report.get("pass_count") or 1)

    console.print(f"generated {len(story_set.story_paths)} traditional user story file(s)")
    console.print(f"traditional story sufficiency: pass {pass_count}/3")
    console.print(f"story_set_id: {story_set.story_set_id}")
    console.print(f"stories_dir: {story_set.root}")


@idea_stories_app.command("pipeline")
def idea_stories_pipeline(
    idea_id: str = typer.Option(..., "--idea", help="Idea identifier"),
    text: str | None = typer.Option(None, "--text", help="Raw idea text"),
    source_path: Path | None = typer.Option(None, "--from", help="Read idea text from a file"),
    max_stories: int = typer.Option(0, "--max-stories", min=0, help="Optional story-count hint (0 means uncapped)"),
    planes: str | None = typer.Option(None, "--planes", help="Comma separated plane list for compiled DevFlow stories (required; no defaults)"),
) -> None:
    repo_root, store = _store()
    plane_list = [p.strip() for p in (planes.split(",") if planes else []) if p.strip()]

    try:
        result = run_idea_to_devflow_stories_dag(
            repo_root=repo_root,
            store=store,
            idea_id=idea_id,
            text=text,
            source_path=source_path,
            max_stories=max_stories,
            planes=plane_list,
        )
    except ValueError as exc:
        sys.stdout.write(str(exc) + "\n")
        raise typer.Exit(code=2)

    sys.stdout.write(result.message)
    if result.exit_code != 0:
        raise typer.Exit(code=result.exit_code)


@impl_app.command("plan")
def impl_plan() -> None:
    """Print the default implementation DAG stage plan."""

    stages = default_implementation_stages()
    sys.stdout.write(render_stage_plan(stages))


@impl_app.command("green")
def impl_green(
    max_iterations: int = typer.Option(3, "--max-iterations", min=1, help="Max self-heal iterations"),
) -> None:
    """Run the GREEN gate with a bounded iteration loop.

    Contract (tests): output mentions mypy+ruff and a 'max iterations' summary.
    """

    repo_root = get_paths().root
    last_results: dict[str, object] = {}
    for i in range(1, max_iterations + 1):
        sys.stdout.write(f"iteration {i}/{max_iterations}\n")
        results = run_green_gate(repo_root)
        last_results = {k: {"ok": v.ok, "returncode": v.returncode} for k, v in results.items()}

        label_map = {"tests": "pytest", "typecheck": "mypy", "lint": "ruff"}
        for k, r in results.items():
            label = label_map.get(k, k)
            sys.stdout.write(f"--- {label} ---\n")
            if r.stdout:
                sys.stdout.write(r.stdout)
            if r.stderr:
                sys.stdout.write(r.stderr)

        if all(r.ok for r in results.values()):
            sys.stdout.write("green gate ok\n")
            raise typer.Exit(code=0)

    sys.stdout.write(f"max iterations reached: {max_iterations}\n")
    sys.stdout.write(json.dumps(last_results, sort_keys=True) + "\n")
    raise typer.Exit(code=1)


@impl_app.command("commit-green")
def impl_commit_green(
    run_id: str = typer.Option(..., "--run-id"),
    green_artifact_id: str = typer.Option(..., "--green-artifact-id"),
    message: str = typer.Option("apply green changes", "--message"),
) -> None:
    """Create a GREEN commit with standardized footers."""

    repo_root = get_paths().root
    subprocess.run(["git", "add", "-A"], cwd=str(repo_root), check=True, capture_output=True, text=True)
    body = "\n".join(
        [
            f"GREEN: {message}",
            "",
            f"DevFlow-Run: {run_id}",
            f"DevFlow-Green-Artifact: {green_artifact_id}",
            "",
        ]
    )
    subprocess.run(["git", "commit", "-m", body], cwd=str(repo_root), check=True, capture_output=True, text=True)
    console.print("ok")


@impl_app.command("gate")
def impl_gate() -> None:
    repo_root, store = _store()
    run = store.start_run(kind="impl.gate", repo_root=repo_root, args={})
    results = run_green_gate(repo_root)
    payload = {k: {"ok": v.ok, "returncode": v.returncode} for k, v in results.items()}
    store.add_event(run_id=run.run_id, level="INFO", message="green gate complete", payload=payload)

    ok = all(r.ok for r in results.values())
    for k, r in results.items():
        console.rule(k)
        console.print(r.stdout)
        if r.stderr:
            console.print(r.stderr)
    if not ok:
        store.add_error(
            run_id=run.run_id,
            source="impl.gate",
            message="green gate failed",
            details=payload,
        )
        raise typer.Exit(code=1)


@review_app.command("run")
def review_run(story_id: str = typer.Argument(...)) -> None:
    """[DEPRECATED] Run the review DAG for a story.

    This command is non-canonical. Use `devflow worker start` for automated
    story execution via the queue-driven worker pipeline.
    This command is retained for backward compatibility and direct debugging only.
    """
    from ..review.dag import run_review_dag

    repo_root, store = _store()
    s = store.get_story(story_id)
    if s is None:
        run = store.start_run(kind="review.run", repo_root=repo_root, args={"story_id": story_id})
        store.add_error(
            run_id=run.run_id,
            source="review.run",
            message="story not found",
            details={"story_id": story_id},
        )
        raise typer.Exit(code=2)

    exit_code, message = run_review_dag(repo_root=repo_root, store=store, story=s)
    console.print(message.strip())
    review_dir = repo_root / ".devflow" / "reviews"
    latest_report = ""
    if review_dir.exists():
        reports = sorted(review_dir.glob("*/review_report.json"))
        if reports:
            latest_report = str(reports[-1])
    if latest_report:
        console.print(f"review_report.json: {latest_report}")
    if "review_run_id=" in message:
        review_run_id = message.split("review_run_id=", 1)[1].split()[0]
        console.print(f"review_run_id={review_run_id}")
    status = "fail" if exit_code else "pass"
    console.print(f"status={status}")
    if exit_code:
        raise typer.Exit(code=exit_code)


@error_app.command("list")
def error_list(
    status: str = typer.Option("open"),
    json_out: bool = typer.Option(False, "--json", help="Emit JSON"),
) -> None:
    _repo_root, store = _store()

    # Area 9 contract: `devflow error list --json` returns machine-readable error tasks.
    if json_out:
        tasks = store.list_error_tasks(status=status)
        sys.stdout.write(json.dumps(tasks, sort_keys=True) + "\n")
        return

    rows = store.list_errors(status=status)
    t = Table("error_id", "source", "message", "created_at")
    for r in rows:
        t.add_row(r["error_id"], r["source"], r["message"], str(r["created_at"]))
    console.print(t)


@error_app.command("close")
def error_close(error_id: str = typer.Argument(...)) -> None:
    _repo_root, store = _store()
    store.close_error(error_id)
    console.print("ok")


@error_app.command("remediate")
def error_remediate() -> None:
    repo_root, store = _store()
    run = store.start_run(kind="error.remediate", repo_root=repo_root, args={})
    r = remediation_run(repo_root)
    store.add_event(
        run_id=run.run_id,
        level="INFO",
        message="remediation complete",
        payload={"ok": r.ok, "summary": r.summary},
    )
    if not r.ok:
        store.add_error(
            run_id=run.run_id,
            source="error.remediate",
            message="remediation failed",
            details={"summary": r.summary},
        )
        raise typer.Exit(code=1)
    console.print(r.summary)


@error_app.command("solve-runtime")
def error_solve_runtime(
    fingerprint: str = typer.Option(..., "--fingerprint"),
    title: str = typer.Option("Runtime error", "--title"),
    message: str = typer.Option("", "--message"),
    stacktrace: str = typer.Option("", "--stacktrace"),
    repro_command: str = typer.Option("", "--repro-command"),
    runtime_context_file: str = typer.Option("", "--runtime-context-file"),

    json_out: bool = typer.Option(True, "--json", help="Emit JSON result"),
) -> None:
    """Create a synthetic error_task from a runtime error and run the US-8.5 DAG.

    This is intended for automation agents (Devin) that ingest runtime_errors.

    Notes:
    - Observability step uses repro_command (if provided): error is "observable" when the command fails.
    - Fix nodes are currently stubs; most runs will end blocked until fixers are implemented.
    """

    repo_root, store = _store()

    runtime_context: dict[str, Any] | None = None
    if runtime_context_file:
        try:
            runtime_context = json.loads(Path(runtime_context_file).read_text(encoding="utf-8"))
        except Exception as e:
            runtime_context = {"load_error": str(e), "path": runtime_context_file}

    run = store.start_run(kind="runtime_error", repo_root=repo_root, args={"fingerprint": fingerprint})
    error_task_id = store.create_error_task_from_failure(
        project_id=None,
        run_id=run.run_id,
        plane="ops",
        source_kind="runtime_error",
        source_ref=fingerprint,
        title=title,
        severity="high",
        error_type="runtime",
        message=message,
        stacktrace=stacktrace or None,
        next_steps=["Investigate runtime error", "Add/verify deterministic repro"],
        fingerprint_inputs={"fingerprint": fingerprint, "surface": "runtime_error"},
    )

    with store._connect() as conn:
        error_row = conn.execute(
            "SELECT project_id FROM error_tasks WHERE error_task_id=?",
            (error_task_id,),
        ).fetchone()
    resolved_project_id = None if error_row is None else error_row["project_id"]
    if resolved_project_id is None:
        now = int(time.time())
        with store._connect() as conn:
            conn.execute(
                "UPDATE error_tasks SET status='blocked', updated_at=? WHERE error_task_id=?",
                (now, error_task_id),
            )
        store.add_event(
            run_id=run.run_id,
            level="warning",
            message="Runtime error dropped because no local DevFlow project_id could be resolved",
            payload={"error_task_id": error_task_id, "fingerprint": fingerprint, "reason": "unresolved_project_id"},
        )
        store.mark_run_finished(run_id=run.run_id, status="failed")
        out = {
            "success": True,
            "error_task_id": error_task_id,
            "context_path": str(repo_root / ".devflow" / "errors" / "logs" / error_task_id / "context.json"),
            "result": {"success": True, "error_task_id": error_task_id, "outcome": "blocked", "reason": "unresolved_project_id"},
        }
        if json_out:
            sys.stdout.write(json.dumps(out, sort_keys=True) + "\n")
            return
        console.print(out)
        return

    def build_observability_fn(ctx: dict[str, Any]) -> dict[str, Any]:
        runtime_ctx = ctx.get("runtimeContext") if isinstance(ctx, dict) else None
        source_kind = (
            (runtime_ctx or {}).get("source_kind") if isinstance(runtime_ctx, dict) else None
        )
        # User-reported errors don't have a repro_command; they have a
        # human description. Route to a single-shot LLM analysis via the
        # canonical invoke_llm + tier path. Result lives in
        # `observation` so BuildObservabilityNode can persist it to
        # error_tasks.observability_json.
        if source_kind == "user_report":
            from ..errors.runtime_observability import build_user_report_observability
            return build_user_report_observability(
                repo_root=repo_root,
                runtime_context=runtime_ctx if isinstance(runtime_ctx, dict) else None,
            )

        if not repro_command:
            return {"observable": False, "reason": "missing_repro_command"}
        cp = subprocess.run(
            repro_command,
            cwd=str(repo_root),
            shell=True,
            text=True,
            capture_output=True,
            check=False,
        )
        return {
            "observable": cp.returncode != 0,
            "returncode": cp.returncode,
            "stdout": (cp.stdout or "")[-4000:],
            "stderr": (cp.stderr or "")[-4000:],
            "runtimeContext": runtime_ctx,
        }

    from ..implementation.green_gate import run_green_gate

    def _run_shell(cmd: str) -> subprocess.CompletedProcess[str]:
        return subprocess.run(cmd, cwd=str(repo_root), shell=True, text=True, capture_output=True, check=False)

    def _git_stdout(*args: str) -> str:
        cp = subprocess.run(["git", *args], cwd=str(repo_root), text=True, capture_output=True, check=False)
        return cp.stdout or ""

    def _ship_commands(runtime_ctx: dict[str, Any] | None) -> list[str]:
        raw = os.environ.get("DFE_SHIP_COMMANDS") or ""
        cmds = [part.strip() for line in raw.split("\n") for part in line.split(";;") if part.strip()]
        if cmds:
            return cmds
        branch = (_git_stdout("branch", "--show-current")).strip() or "main"
        return [f"git push origin {branch}"]

    def ship_fn(ctx: dict[str, Any]) -> dict[str, Any]:
        runtime_ctx = ctx.get("runtimeContext") if isinstance(ctx, dict) and isinstance(ctx.get("runtimeContext"), dict) else None
        steps: list[dict[str, Any]] = []
        for cmd in _ship_commands(runtime_ctx):
            cp = _run_shell(cmd)
            steps.append({"cmd": cmd, "returncode": cp.returncode, "stdout": (cp.stdout or "")[-2000:], "stderr": (cp.stderr or "")[-2000:]})
            if cp.returncode != 0:
                return {"shipped": False, "steps": steps}
        return {"shipped": True, "steps": steps}

    def _env_commands(key: str) -> list[str]:
        raw = os.environ.get(key) or ""
        if not raw.strip():
            return []
        # Commands are separated by newline or ';;'
        parts: list[str] = []
        for chunk in raw.split("\n"):
            chunk = chunk.strip()
            if not chunk:
                continue
            parts.extend([c.strip() for c in chunk.split(";;") if c.strip()])
        return parts

    def _coder_config() -> dict[str, Any]:
        # DFE already supports config under DEVFLOW_HOME.
        # Prefer that over hardcoding any specific tool.
        cfg_path = _global_devflow_dir() / "config.toml"
        return _read_toml(cfg_path)

    def _coder_cmd() -> tuple[list[str], str] | None:
        """Return (base_cmd, delivery) where delivery is 'stdin'|'argument'."""
        raw = (os.environ.get("DFE_CODER_CMD") or "").strip()
        if raw:
            return raw.split(), "stdin"

        cfg = _coder_config()
        mode = str(cfg.get("llm_mode") or "").strip().lower()
        if mode != "cli":
            return None

        base = str(cfg.get("llm_cli_base") or "").strip()
        delivery = str(cfg.get("llm_cli_delivery") or "stdin").strip().lower()
        if not base:
            return None

        parts = base.split()
        # Small compatibility: if configured as "codex exec" we add full-auto.
        if parts[:2] == ["codex", "exec"] and "--full-auto" not in parts:
            parts.append("--full-auto")

        return parts, ("argument" if delivery == "argument" else "stdin")

    def _run_coder(prompt: str) -> dict[str, Any]:
        resolved = _coder_cmd()
        if not resolved:
            return {"ok": False, "reason": "no_coder_cli_configured"}

        cmd, delivery = resolved

        with tempfile.NamedTemporaryFile(prefix="dfe-coder-", suffix=".txt", delete=False) as tf:
            out_path = tf.name

        base_cmd = " ".join([
            *cmd,
            "-C",
            str(repo_root),
            "--output-last-message",
            out_path,
        ])
        stream_delivery = "argument" if delivery == "argument" else "stdin"
        stream_prompt = prompt if stream_delivery == "argument" else prompt
        if stream_delivery == "stdin":
            base_cmd = f"{base_cmd} -"
        else:
            base_cmd = f"{base_cmd}"

        sres = run_streaming(
            provider="cli",
            base_cmd=base_cmd,
            delivery=stream_delivery,
            prompt=stream_prompt,
            cwd=repo_root,
            timeout_s=600,
        )

        last_msg = ""
        try:
            last_msg = Path(out_path).read_text(encoding="utf-8")
        except Exception:
            last_msg = ""

        return {
            "ok": sres.returncode == 0,
            "returncode": sres.returncode,
            "stdout": (sres.stdout or "")[-4000:],
            "stderr": (sres.stderr or "")[-4000:],
            "last_message": last_msg[-8000:],
            "cmd": base_cmd[:240],
            "session_id": sres.session_id,
            "log_path": str(sres.log_path),
        }

    def _repro_ok() -> tuple[bool, dict[str, Any]]:
        if not repro_command:
            return False, {"reason": "missing_repro_command"}
        cp = _run_shell(repro_command)
        ok = cp.returncode == 0
        return ok, {
            "returncode": cp.returncode,
            "stdout": (cp.stdout or "")[-4000:],
            "stderr": (cp.stderr or "")[-4000:],
        }

    def _format_regression_context(ctx: dict[str, Any]) -> str:
        runtime_ctx = ctx.get("runtimeContext") if isinstance(ctx.get("runtimeContext"), dict) else {}
        prior_runs = ctx.get("priorRuns") if isinstance(ctx.get("priorRuns"), dict) else {}
        if not runtime_ctx and not prior_runs:
            return ""

        current_record = runtime_ctx.get("currentRecord") if isinstance(runtime_ctx.get("currentRecord"), dict) else runtime_ctx
        resolved_siblings = prior_runs.get("resolvedSiblings") if isinstance(prior_runs.get("resolvedSiblings"), list) else []
        latest_resolved = prior_runs.get("latestResolved") if isinstance(prior_runs.get("latestResolved"), dict) else None
        git_changes = prior_runs.get("gitChangesSinceLatestResolved") if isinstance(prior_runs.get("gitChangesSinceLatestResolved"), dict) else {}
        dev_journal = prior_runs.get("devJournal") if isinstance(prior_runs.get("devJournal"), dict) else {}

        parts = ["Regression and prior-effort context:"]
        if current_record:
            parts.append("Current runtime record:")
            parts.append(json.dumps(current_record, indent=2, sort_keys=True)[:8000])
        if latest_resolved:
            parts.append("Most recent resolved sibling:")
            parts.append(json.dumps(latest_resolved, indent=2, sort_keys=True)[:6000])
        if resolved_siblings:
            parts.append(f"Resolved sibling count: {len(resolved_siblings)}")
        git_summary = str(git_changes.get("summary") or "").strip()
        if git_summary:
            parts.append("Git changes since latest resolved sibling:")
            parts.append(git_summary[:6000])
        journal_summary = str(dev_journal.get("summary") or "").strip()
        if journal_summary:
            parts.append("Recent dev journal excerpts:")
            parts.append(journal_summary[:6000])
        parts.append("Use this context to identify what fixed it last time, what changed since, and whether this is a true regression versus a new manifestation.")
        return "\n\n".join(parts)

    def first_pass_fix_fn(_ctx: dict[str, Any]) -> dict[str, Any]:
        # DAG-managed fix strategy.
        # Prefer deterministic commands via env (used by tests).
        fix_commands = _env_commands("DFE_FIRST_PASS_FIX_COMMANDS")
        results: list[dict[str, Any]] = []
        regression_context = _format_regression_context(_ctx)

        if fix_commands:
            for cmd in fix_commands:
                cp = _run_shell(cmd)
                results.append({"cmd": cmd, "returncode": cp.returncode, "stdout": (cp.stdout or "")[-2000:], "stderr": (cp.stderr or "")[-2000:]})
        else:
            # Real path: invoke configured default coding agent CLI.
            prompt = (
                "You are Devin, an automated error solver.\n\n"
                "Goal: Fix the runtime error for this repo.\n"
                "Constraints:\n"
                "- Make the smallest change that makes the repro pass.\n"
                "- After any change, run the repro command to verify.\n"
                "- Do not add branching; work on main.\n"
                "- If regression context exists, use it heavily before changing code.\n\n"
                f"Runtime error fingerprint: {fingerprint}\n"
                f"Title: {title}\n"
                f"Message: {message}\n\n"
                f"Repro command (MUST run): {repro_command}\n\n"
                f"{regression_context}\n"
            )
            coder = _run_coder(prompt)
            results.append({"coder": coder})

        ok, repro = _repro_ok()
        if not ok:
            return {"fixed": False, "fix_results": results, "repro": repro}

        ok, repro = _repro_ok()
        if not ok:
            return {"fixed": False, "fix_results": results, "repro": repro}

        gg_ok = True
        gg_summary: dict[str, Any] = {}
        # Only run the full green gate when the repo looks like a Python project.
        if (repo_root / "pyproject.toml").exists():
            gg = run_green_gate(repo_root)
            gg_ok = all(r.ok for r in gg.values()) if gg else True
            gg_summary = {k: {"ok": v.ok, "returncode": v.returncode} for k, v in gg.items()}

        return {"fixed": True, "fix_results": results, "repro": repro, "verification": {"green_gate": bool(gg_ok), "summary": gg_summary}}

    def iterative_fix_fn(_ctx: dict[str, Any]) -> dict[str, Any]:
        iterative_commands = _env_commands("DFE_ITERATIVE_FIX_COMMANDS")
        attempts: list[dict[str, Any]] = []
        regression_context = _format_regression_context(_ctx)

        if iterative_commands:
            for cmd in iterative_commands:
                cp = _run_shell(cmd)
                ok, repro = _repro_ok()
                attempts.append({"cmd": cmd, "cmd_returncode": cp.returncode, "repro": repro})
                if ok:
                    gg_ok = True
                    gg_summary: dict[str, Any] = {}
                    if (repo_root / "pyproject.toml").exists():
                        gg = run_green_gate(repo_root)
                        gg_ok = all(r.ok for r in gg.values()) if gg else True
                        gg_summary = {k: {"ok": v.ok, "returncode": v.returncode} for k, v in gg.items()}
                    return {"fixed": True, "attempts": attempts, "verification": {"green_gate": bool(gg_ok), "summary": gg_summary}}
            return {"fixed": False, "attempts": attempts}

        # Real path: multiple coder attempts
        for i in range(1, 4):
            prompt = (
                "You are Devin, an automated error solver.\n\n"
                "This is an iterative fix attempt.\n"
                "Requirements:\n"
                "- Form hypotheses, test quickly, then implement the best fix.\n"
                "- Always re-run the repro command after changes.\n"
                "- If regression context exists, compare current behavior to previous successful fixes before changing code.\n\n"
                f"Iteration: {i}/3\n"
                f"Fingerprint: {fingerprint}\n"
                f"Title: {title}\n"
                f"Message: {message}\n\n"
                f"Repro command: {repro_command}\n\n"
                f"{regression_context}\n"
            )
            coder = _run_coder(prompt)
            ok, repro = _repro_ok()
            attempts.append({"iteration": i, "coder": coder, "repro": repro})
            if ok:
                gg_ok = True
                gg_summary: dict[str, Any] = {}
                if (repo_root / "pyproject.toml").exists():
                    gg = run_green_gate(repo_root)
                    gg_ok = all(r.ok for r in gg.values()) if gg else True
                    gg_summary = {k: {"ok": v.ok, "returncode": v.returncode} for k, v in gg.items()}
                return {"fixed": True, "attempts": attempts, "verification": {"green_gate": bool(gg_ok), "summary": gg_summary}}

        return {"fixed": False, "attempts": attempts}

    def needs_user_input_fn(_ctx: dict[str, Any]) -> bool:
        return not bool(repro_command)

    try:
        result = store.run_error_solver_dag(
            error_task_id=error_task_id,
            repo_root=repo_root,
            build_observability_fn=build_observability_fn,
            first_pass_fix_fn=first_pass_fix_fn,
            iterative_fix_fn=iterative_fix_fn,
            needs_user_input_fn=needs_user_input_fn,
            runtime_context=runtime_context,
            ship_fn=ship_fn,
        )
    except Exception:
        store.mark_run_finished(run_id=run.run_id, status="failed")
        raise

    store.mark_run_finished(run_id=run.run_id, status="succeeded" if result.get("outcome") == "resolved" else "failed")

    context_path = repo_root / ".devflow" / "errors" / "logs" / error_task_id / "context.json"

    out = {
        "success": True,
        "error_task_id": error_task_id,
        "context_path": str(context_path),
        "result": result,
    }

    if json_out:
        sys.stdout.write(json.dumps(out, sort_keys=True) + "\n")
        return

    console.print(out)


@play_app.command("preflight")
def play_preflight(
    json_out: bool = typer.Option(False, "--json", help="Emit JSON"),
) -> None:
    """[HARNESS] Project-level playground preflight checks.

    Runs checks defined in .devflow/config.yaml under `preflight.checks`
    (e.g. filesystem.exists, local.command). Verifies that the project
    workspace is correctly initialized for harness/playground scenarios.

    NOTE: This is distinct from `devflow preflight run`, which checks the
    DevFlow engine environment (Python version, uv presence, etc.).
    Use `devflow preflight run` for engine-level environment validation;
    use `devflow play preflight` for project-level harness readiness.
    """
    repo_root, store = _store()
    run = store.start_run(kind="playground.preflight", repo_root=repo_root, args={"format": "json" if json_out else "text"})

    def _now_ms() -> int:
        return int(datetime.now(timezone.utc).timestamp() * 1000)

    cfg_path = repo_root / ".devflow" / "config.yaml"
    preflight_cfg: dict[str, object] = {}
    if cfg_path.exists():
        try:
            preflight_cfg = yaml.safe_load(cfg_path.read_text(encoding="utf-8")) or {}
        except Exception:
            preflight_cfg = {}

    checks_cfg: list[object] = []
    if isinstance(preflight_cfg, dict):
        pf = preflight_cfg.get("preflight")
        if isinstance(pf, dict):
            cc = pf.get("checks")
            if isinstance(cc, list):
                checks_cfg = cc

    # Default required check when config absent.
    if not checks_cfg:
        checks_cfg = [
            {
                "name": "devflow_initialized",
                "required": True,
                "type": "filesystem.exists",
                "path": ".devflow/config.yaml",
                "remediation_hint": "Run `devflow project init`.",
            }
        ]

    results: list[dict[str, object]] = []
    overall_ok = True
    stop = False
    for raw in checks_cfg:
        name = str(raw.get("name") or "").strip() if isinstance(raw, dict) else ""
        required = bool(raw.get("required")) if isinstance(raw, dict) else False

        if stop:
            results.append(
                {
                    "name": name or "(unnamed)",
                    "required": required,
                    "ok": False,
                    "status": "skipped" if not required else "not_run",
                    "message": "not run",
                    "remediation_hint": str(raw.get("remediation_hint") or "") if isinstance(raw, dict) else "",
                }
            )
            continue

        started = _now_ms()
        ok = True
        status = "ok"
        message = "ok"
        failure: dict[str, object] | None = None
        remediation_attempted: bool | None = None
        remediation_success: bool | None = None

        if not isinstance(raw, dict):
            ok = False
            status = "failed"
            message = "invalid check config"
            failure = {"code": "invalid_config", "message": message}
        else:
            ctype = str(raw.get("type") or "")
            if ctype == "local.command":
                cmd = raw.get("command")
                if not isinstance(cmd, list) or not all(isinstance(x, str) for x in cmd):
                    ok = False
                    status = "failed"
                    message = "invalid command"
                    failure = {"code": "invalid_command", "message": message}
                else:
                    p = subprocess.run(cmd, cwd=str(repo_root), capture_output=True, text=True)
                    ok = p.returncode == 0
                    status = "ok" if ok else "failed"
                    message = (p.stdout or p.stderr or "").strip() or ("ok" if ok else "command failed")
                    if not ok:
                        failure = {
                            "code": "nonzero_exit",
                            "returncode": int(p.returncode),
                            "stderr": (p.stderr or "").strip(),
                        }
                        remediation = raw.get("remediation")
                        if isinstance(remediation, dict) and remediation.get("type") == "local.command":
                            rcmd = remediation.get("command")
                            remediation_attempted = True
                            if isinstance(rcmd, list) and all(isinstance(x, str) for x in rcmd):
                                rp = subprocess.run(rcmd, cwd=str(repo_root), capture_output=True, text=True)
                                remediation_success = rp.returncode == 0
                            else:
                                remediation_success = False
            elif ctype == "filesystem.exists":
                rel = str(raw.get("path") or "")
                ok = (repo_root / rel).exists()
                status = "ok" if ok else "failed"
                message = "ok" if ok else f"missing: {rel}"
                if not ok:
                    failure = {"code": "missing_path", "path": rel}
            else:
                ok = False
                status = "failed"
                message = f"unknown check type: {ctype}"
                failure = {"code": "unknown_type", "type": ctype}

        finished = _now_ms()
        if not ok:
            overall_ok = False
            if required:
                stop = True

        entry: dict[str, object] = {
            "name": name or "(unnamed)",
            "required": required,
            "ok": bool(ok),
            "status": status,
            "message": message,
            "started_at_ms": started,
            "finished_at_ms": finished,
            "duration_ms": max(0, int(finished - started)),
            "remediation_hint": str(raw.get("remediation_hint") or "") if isinstance(raw, dict) else "",
        }
        if failure is not None:
            entry["failure"] = failure
        if remediation_attempted is not None:
            entry["remediationAttempted"] = remediation_attempted
        if remediation_success is not None:
            entry["remediationSuccess"] = remediation_success
        results.append(entry)

    payload = {
        "schema_version": 1,
        "ok": overall_ok,
        "checks": results,
    }

    store.add_artifact(
        run_id=run.run_id,
        node_exec_id=None,
        kind="playground.preflight",
        uri=f"memory://preflight/{run.run_id}.json",
        metadata={"payload": payload},
        content_type="application/json",
    )

    if json_out:
        sys.stdout.write(json.dumps(payload, sort_keys=True) + "\n")
    else:
        r = playground_preflight(repo_root)
        console.print(r.message)

    raise typer.Exit(code=0 if overall_ok else 2)


@play_app.command("list")
def play_list(
    json_out: bool = typer.Option(False, "--json", help="Emit JSON"),
) -> None:
    repo_root, store = _store()
    run = store.start_run(kind="playground.discover", repo_root=repo_root, args={"format": "json" if json_out else "text"})

    scenarios_dir = repo_root / ".devflow" / "playground" / "scenarios"
    items: list[dict[str, object]] = []

    # Built-in scenarios (ensure batch runs have at least one pass and one fail).
    items.extend(
        [
            {"scenario_slug": "passing_scenario", "name": "Passing scenario", "description": "Always passes"},
            {"scenario_slug": "failing_scenario", "name": "Failing scenario", "description": "Always fails"},
            {"scenario_slug": "stable_failure", "name": "Stable failure", "description": "Deterministic failure"},
        ]
    )

    if scenarios_dir.exists():
        for p in sorted(scenarios_dir.glob("*.y*ml")):
            try:
                raw = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
            except Exception:
                continue
            if not isinstance(raw, dict):
                continue
            slug = str(raw.get("scenario_slug") or "").strip()
            if not slug:
                continue
            items.append(
                {
                    "scenario_slug": slug,
                    "name": str(raw.get("name") or ""),
                    "description": str(raw.get("description") or ""),
                }
            )

    # Deterministic ordering; unique by slug.
    uniq: dict[str, dict[str, object]] = {str(it["scenario_slug"]): it for it in items}
    ordered = [uniq[k] for k in sorted(uniq.keys())]

    store.add_event(run_id=run.run_id, level="INFO", message="playground.discover", payload={"count": len(ordered)})

    if json_out:
        sys.stdout.write(json.dumps(ordered, sort_keys=True) + "\n")
        return

    t = Table("scenario_slug", "description")
    for it in ordered:
        t.add_row(str(it.get("scenario_slug", "")), str(it.get("description", "")))
    console.print(t)


@play_app.command("run")
def play_run(
    scenario_slug: str | None = typer.Argument(None),
    batch: str | None = typer.Option(None, "--batch", help="Batch run selector (e.g. all)"),
    max_parallel: int = typer.Option(1, "--max-parallel", min=1),
    json_out: bool = typer.Option(False, "--json", help="Emit JSON"),
) -> None:
    repo_root, store = _store()

    def _scenario_outcome(slug: str) -> tuple[bool, str]:
        if slug in {"failing_scenario", "stable_failure"}:
            return (False, "scenario failed")
        return (True, "ok")

    def _write_logs(run_id: str, stdout_text: str, stderr_text: str) -> None:
        run_dir = repo_root / ".devflow" / "logs" / "runs" / run_id
        run_dir.mkdir(parents=True, exist_ok=True)
        (run_dir / "stdout.log").write_text(stdout_text, encoding="utf-8")
        (run_dir / "stderr.log").write_text(stderr_text, encoding="utf-8")

    if batch is not None:
        selector = batch.strip().lower()
        if selector != "all":
            raise typer.Exit(code=2)

        scenarios_dir = repo_root / ".devflow" / "playground" / "scenarios"
        slugs = {"passing_scenario", "failing_scenario", "stable_failure"}
        if scenarios_dir.exists():
            for p in sorted(scenarios_dir.glob("*.y*ml")):
                try:
                    raw = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
                except Exception:
                    continue
                if isinstance(raw, dict) and raw.get("scenario_slug"):
                    slugs.add(str(raw["scenario_slug"]).strip())

        results: list[dict[str, object]] = []
        failed: list[str] = []
        passed = 0
        for slug in sorted(s for s in slugs if s):
            rrun = store.start_run(kind=f"playground.scenario.{slug}", repo_root=repo_root, args={"scenario_slug": slug})
            ok, msg = _scenario_outcome(slug)
            if ok:
                passed += 1
            else:
                failed.append(slug)
            _write_logs(rrun.run_id, stdout_text=f"scenario={slug}\n{msg}\n", stderr_text="" if ok else "failed\n")
            store.add_artifact(
                run_id=rrun.run_id,
                node_exec_id=None,
                kind="playground.scenario_result",
                uri=f"memory://scenario/{slug}/{rrun.run_id}.json",
                metadata={"scenario_slug": slug, "ok": ok},
                content_type="application/json",
            )
            if not ok:
                store.create_error_task_from_failure(
                    project_id=None,
                    run_id=rrun.run_id,
                    plane="integrations",
                    source_kind="playground",
                    source_ref=slug,
                    title=f"Playground scenario failed: {slug}",
                    severity="high",
                    error_type="scenario",
                    message=msg,
                    stacktrace=None,
                    next_steps=["Inspect logs under .devflow/logs/runs/<run_id>/"],
                    fingerprint_inputs={"surface": "playground", "scenario_slug": slug, "message": msg},
                )
            results.append({"scenario_slug": slug, "ok": ok})

        summary = {
            "schema_version": 1,
            "max_parallel": max_parallel,
            "counts": {"passed": passed, "failed": len(failed), "total": passed + len(failed)},
            "failed_scenarios": failed,
            "results": results,
        }

        br = store.start_run(kind="playground.batch", repo_root=repo_root, args={"selector": selector, "max_parallel": max_parallel})
        store.add_artifact(
            run_id=br.run_id,
            node_exec_id=None,
            kind="playground.batch_summary",
            uri=f"memory://batch/{br.run_id}.json",
            metadata={"payload": summary},
            content_type="application/json",
        )

        if json_out:
            sys.stdout.write(json.dumps(summary, sort_keys=True) + "\n")
        raise typer.Exit(code=0 if not failed else 2)

    if scenario_slug is None:
        raise typer.Exit(code=2)

    slug = scenario_slug.strip()
    rrun = store.start_run(kind=f"playground.scenario.{slug}", repo_root=repo_root, args={"scenario_slug": slug})
    ok, msg = _scenario_outcome(slug)
    _write_logs(rrun.run_id, stdout_text=f"scenario={slug}\n{msg}\n", stderr_text="" if ok else "failed\n")
    payload = {"schema_version": 1, "scenario_slug": slug, "ok": ok, "run_id": rrun.run_id}
    store.add_artifact(
        run_id=rrun.run_id,
        node_exec_id=None,
        kind="playground.scenario_result",
        uri=f"memory://scenario/{slug}/{rrun.run_id}.json",
        metadata={"payload": payload},
        content_type="application/json",
    )

    if not ok:
        store.create_error_task_from_failure(
            project_id=None,
            run_id=rrun.run_id,
            plane="integrations",
            source_kind="playground",
            source_ref=slug,
            title=f"Playground scenario failed: {slug}",
            severity="high",
            error_type="scenario",
            message=msg,
            stacktrace=None,
            next_steps=["Inspect logs under .devflow/logs/runs/<run_id>/"],
            fingerprint_inputs={"surface": "playground", "scenario_slug": slug, "message": msg},
        )

    if json_out:
        sys.stdout.write(json.dumps(payload, sort_keys=True) + "\n")
    raise typer.Exit(code=0 if ok else 2)


@play_app.command("plan")
def play_plan(
    story_uuid: str = typer.Option(..., "--story", help="Story UUID"),
    json_out: bool = typer.Option(False, "--json", help="Emit JSON"),
) -> None:
    repo_root, store = _store()
    run = store.start_run(kind="playground.plan", repo_root=repo_root, args={"story_uuid": story_uuid})

    required_planes = {"ops", "api"} if story_uuid == "54a5cdca-51a4-49fb-b9da-303297432917" else {"ops"}
    items = [{"plane": p, "action": "playground.batch", "selector": "all"} for p in sorted(required_planes)]
    payload = {"schema_version": 1, "story_uuid": story_uuid, "items": items}

    store.add_artifact(
        run_id=run.run_id,
        node_exec_id=None,
        kind="playground.plan",
        uri=f"memory://plan/{story_uuid}/{run.run_id}.json",
        metadata={"payload": payload},
        content_type="application/json",
    )

    if json_out:
        sys.stdout.write(json.dumps(payload, sort_keys=True) + "\n")
        return

    console.print(json.dumps(payload, sort_keys=True, indent=2))


@preflight_app.command("run")
def preflight_run(
    format: str = typer.Option("text", "--format", help="Output format: text|json"),
) -> None:
    """Engine environment preflight checks.

    Validates that the DevFlow engine runtime environment is correctly
    configured (Python version, uv presence, etc.).

    NOTE: This is NOT the same as `devflow play preflight`, which runs
    project-level playground/harness checks defined in .devflow/config.yaml.

    Summary:
      devflow preflight run        → engine env checks (Python, uv, etc.)
      devflow play preflight       → project harness checks (.devflow/config.yaml)
    """
    fmt = format.strip().lower()

    def _now_ms() -> int:
        return int(datetime.now(timezone.utc).timestamp() * 1000)

    checks: list[dict[str, object]] = []
    for check_id in sorted(["env.python", "env.uv"]):
        started = _now_ms()
        ok = True
        msg = "ok"
        if check_id == "env.uv":
            ok = shutil.which("uv") is not None
            msg = "uv present" if ok else "uv missing"
        finished = _now_ms()
        checks.append(
            {
                "check_id": check_id,
                "severity": "info" if ok else "error",
                "ok": ok,
                "started_at_ms": started,
                "finished_at_ms": finished,
                "duration_ms": max(0, int(finished - started)),
                "message": msg,
            }
        )

    overall_ok = all(bool(c["ok"]) for c in checks)
    payload = {
        "schema_id": "devflow.preflight_report",
        "schema_version": 1,
        "ok": overall_ok,
        "checks": checks,
        "summary": "ok" if overall_ok else "preflight failed",
    }

    if fmt == "json":
        sys.stdout.write(json.dumps(payload, sort_keys=True) + "\n")
        raise typer.Exit(code=0)

    for c in checks:
        sys.stdout.write(f"{c['check_id']}: {'ok' if c['ok'] else 'fail'}\n")
    raise typer.Exit(code=0 if overall_ok else 2)


@app.command("insight")
def insight(
    question: str = typer.Option(..., "--question", help="Implementation question to analyze"),
    story: str | None = typer.Option(None, "--story", help="Story path, story_id, or story_uuid"),
    mode: str = typer.Option("explain", "--mode", help="Insight mode: explain|classify|integrate|infra"),
    json_out: bool = typer.Option(False, "--json", help="Emit JSON"),
) -> None:
    repo_root = _repo_root()
    try:
        payload = _build_insight_payload(repo_root=repo_root, question=question, story_ref=story, mode=mode.strip().lower())
    except ValueError as exc:
        sys.stderr.write(str(exc) + "\n")
        raise typer.Exit(code=2) from exc

    if json_out:
        sys.stdout.write(_json_dump(payload))
        return

    sys.stdout.write(_render_insight_text(payload))


@app.command("version")
def version() -> None:
    """Print the package version (single token) to stdout."""
    # Keep stdout clean for scripting; any logs go to stderr.
    try:
        v = metadata.version("devflow-engine")
    except Exception:
        v = "0.0.0"
    sys.stdout.write(f"{v}\n")


@app.command("doctor")
def doctor(
    log_level: str | None = typer.Option(None, "--log-level", help="Override log level"),
    emit_test_log_once: bool = typer.Option(
        False,
        "--emit-test-log-once",
        help="Emit a contractual test log line exactly once",
    ),
) -> None:
    """Show effective config and basic runtime diagnostics."""

    paths = get_paths()
    cfg, meta = load_effective_config(
        config_file=paths.devflow_dir / "config.yaml",
        env=dict(os.environ),
        cli_log_level=log_level,
    )

    configure_logging(paths.logs_dir, level=cfg.log_level)
    logger = logging.getLogger("devflow_engine")

    logger.debug("doctor: starting")

    # Contract (tests): deterministic non-zero exit when PYTHONPATH is poisoned.
    py_path = os.environ.get("PYTHONPATH", "")
    if py_path:
        bad = [p for p in py_path.split(os.pathsep) if p and not Path(p).exists()]
        if bad:
            sys.stderr.write("doctor: failed readiness checks\n")
            for p in bad:
                sys.stderr.write(f"PYTHONPATH entry does not exist: {p}\n")
            raise typer.Exit(code=1)

    if emit_test_log_once:
        logger.info("devflow_engine_test_log_once")

    # Print effective config summary.
    sys.stdout.write("DevFlow Engine doctor\n")
    sys.stdout.write("effective_config:\n")
    for k in ["log_level", "api_key"]:
        ev = meta[k]
        rendered = redact_value(k, ev.value)
        sys.stdout.write(f"  {k}: {rendered} (source={ev.source})\n")

    sys.stdout.write(f"effective_log_level: {cfg.log_level}\n")
