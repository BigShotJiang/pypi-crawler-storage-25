from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any

from ..agentic_runtime import _load_llm_cli_config
from ..llm.cli_stream import run_streaming
from ..orchestration import process_one_task
from ..stores.execution_store import ExecutionStore

IDEATION_ENRICHMENT_QUEUE_NAME = "idea.ideation_enrichment"
IDEATION_ENRICHMENT_TASK_KIND = "idea.ideation.enrichment"


def _write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def _load_json_dict(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}
    return payload if isinstance(payload, dict) else {}


def _idea_file_path(repo_root: Path, *, idea_id: str) -> Path:
    return repo_root / ".devflow" / "ideas" / idea_id / "idea.json"


def ideation_enrichment_status_path(repo_root: Path, *, idea_id: str) -> Path:
    return repo_root / ".devflow" / "ideas" / idea_id / "ideation_enrichment.json"


def load_ideation_enrichment_status(repo_root: Path, *, idea_id: str) -> dict[str, Any]:
    return _load_json_dict(ideation_enrichment_status_path(repo_root, idea_id=idea_id))


def _sync_idea_enrichment(repo_root: Path, *, idea_id: str, snapshot: dict[str, Any]) -> None:
    idea_path = _idea_file_path(repo_root, idea_id=idea_id)
    idea_payload = _load_json_dict(idea_path) if idea_path.exists() else {"idea_id": idea_id}
    idea_payload["enrichment"] = dict(snapshot)
    _write_json(idea_path, idea_payload)


def persist_ideation_enrichment_progress(
    *,
    repo_root: Path,
    idea_id: str,
    project_id: str | None,
    pipeline_key: str,
    task_id: str | None,
    status: str,
    stage: str,
    progress_pct: int,
    summary: str,
    prompt_path: str | None = None,
    stream_path: str | None = None,
    terminal_path: str | None = None,
    log_path: str | None = None,
    contract: dict[str, Any] | None = None,
    response_guidance: dict[str, Any] | None = None,
    result_shape: dict[str, Any] | None = None,
    error: str | None = None,
) -> dict[str, Any]:
    now = int(time.time())
    status_path = ideation_enrichment_status_path(repo_root, idea_id=idea_id)
    existing = _load_json_dict(status_path)
    snapshot: dict[str, Any] = {
        **existing,
        "kind": "idea_ideation_enrichment_status.v1",
        "idea_id": idea_id,
        "project_id": project_id,
        "pipeline_key": pipeline_key,
        "task_id": task_id,
        "status": status,
        "stage": stage,
        "progress_pct": max(0, min(int(progress_pct), 100)),
        "summary": summary,
        "inspect_path": str(status_path),
        "updated_at": now,
    }
    if existing.get("queued_at") is None and status == "queued":
        snapshot["queued_at"] = now
    if existing.get("started_at") is None and status == "running":
        snapshot["started_at"] = now
    if status in {"completed", "failed"}:
        snapshot["completed_at"] = now
    if prompt_path:
        snapshot["prompt_path"] = prompt_path
    if stream_path:
        snapshot["stream_path"] = stream_path
    if terminal_path:
        snapshot["terminal_path"] = terminal_path
    if log_path:
        snapshot["log_path"] = log_path
    if contract is not None:
        snapshot["contract"] = dict(contract)
    if response_guidance is not None:
        snapshot["response_guidance"] = dict(response_guidance)
    if result_shape is not None:
        snapshot["result_shape"] = dict(result_shape)
    if error:
        snapshot["error"] = error
    _write_json(status_path, snapshot)
    _sync_idea_enrichment(repo_root, idea_id=idea_id, snapshot=snapshot)
    return snapshot


def enqueue_ideation_enrichment_task(
    *,
    store: ExecutionStore,
    project_id: str | None,
    repo_root: Path,
    idea_id: str,
    pipeline_key: str,
    prompt_payload: dict[str, Any],
    prompt_path: Path,
    response_guidance: dict[str, Any],
    contract: dict[str, Any],
    source_run_id: str | None = None,
) -> dict[str, Any]:
    task = store.enqueue_task(
        project_id=project_id,
        queue_name=IDEATION_ENRICHMENT_QUEUE_NAME,
        task_kind=IDEATION_ENRICHMENT_TASK_KIND,
        idempotency_key=f"{idea_id}:{pipeline_key}:ideation_enrichment",
        source_run_id=source_run_id,
        max_attempts=1,
        input_payload={
            "idea_id": idea_id,
            "project_id": project_id,
            "pipeline_key": pipeline_key,
            "prompt_payload": prompt_payload,
            "prompt_path": str(prompt_path),
            "response_guidance": response_guidance,
            "contract": contract,
        },
        context={"workflow": "idea_ideation_enrichment", "repo_root": str(repo_root)},
    )
    snapshot = persist_ideation_enrichment_progress(
        repo_root=repo_root,
        idea_id=idea_id,
        project_id=project_id,
        pipeline_key=pipeline_key,
        task_id=str(task.get("task_id") or ""),
        status="queued",
        stage="queued",
        progress_pct=5,
        summary="Background ideation enrichment queued.",
        prompt_path=str(prompt_path),
        contract=contract,
        response_guidance=response_guidance,
    )
    return {"task": task, "status": snapshot}


def _extract_json_object(raw_text: str) -> dict[str, Any]:
    candidate = raw_text.strip()
    if "```" in candidate:
        for chunk in candidate.split("```"):
            stripped = chunk.strip()
            if stripped.startswith("json"):
                stripped = stripped[4:].strip()
            if stripped.startswith("{"):
                candidate = stripped
                break
    parsed = json.loads(candidate)
    if not isinstance(parsed, dict):
        raise RuntimeError("ideation enrichment worker expected a JSON object result")
    return parsed


def handle_ideation_enrichment_task(store: ExecutionStore, repo_root: Path, task: dict[str, Any]) -> dict[str, Any]:
    payload = dict(task.get("input") or {})
    task_id = str(task["task_id"])
    idea_id = str(payload.get("idea_id") or "")
    project_id = str(payload.get("project_id") or "").strip() or None
    pipeline_key = str(payload.get("pipeline_key") or "")
    prompt_payload = dict(payload.get("prompt_payload") or {})
    prompt_path = Path(str(payload.get("prompt_path") or ""))
    response_guidance = dict(payload.get("response_guidance") or {})
    contract = dict(payload.get("contract") or {})
    pipeline_root = prompt_path.parent
    stream_path = pipeline_root / "ideation_agent_loop_stream.json"
    terminal_path = pipeline_root / "ideation_agent_loop_terminal.json"

    store.record_task_step(task_id=task_id, step_name="ideation_enrichment.claim", status="started", payload={"idea_id": idea_id, "pipeline_key": pipeline_key})
    persist_ideation_enrichment_progress(
        repo_root=repo_root,
        idea_id=idea_id,
        project_id=project_id,
        pipeline_key=pipeline_key,
        task_id=task_id,
        status="running",
        stage="starting",
        progress_pct=15,
        summary="Background ideation enrichment started.",
        prompt_path=str(prompt_path),
        contract=contract,
        response_guidance=response_guidance,
    )
    _write_json(prompt_path, prompt_payload)
    store.emit_task_message(task_id=task_id, message_kind="partial", stream="ideation_enrichment", payload={"status": "running", "stage": "prompt_written", "prompt_path": str(prompt_path)})
    persist_ideation_enrichment_progress(
        repo_root=repo_root,
        idea_id=idea_id,
        project_id=project_id,
        pipeline_key=pipeline_key,
        task_id=task_id,
        status="running",
        stage="prompt_written",
        progress_pct=25,
        summary="Background ideation enrichment prompt persisted.",
        prompt_path=str(prompt_path),
        contract=contract,
        response_guidance=response_guidance,
    )

    base_cmd, delivery = _load_llm_cli_config()
    store.record_task_step(task_id=task_id, step_name="ideation_enrichment.run", status="started", payload={"delivery": delivery, "base_cmd": base_cmd})
    persist_ideation_enrichment_progress(
        repo_root=repo_root,
        idea_id=idea_id,
        project_id=project_id,
        pipeline_key=pipeline_key,
        task_id=task_id,
        status="running",
        stage="agent_running",
        progress_pct=45,
        summary="Background ideation enrichment is running.",
        prompt_path=str(prompt_path),
        contract=contract,
        response_guidance=response_guidance,
    )
    stream_result = run_streaming(
        provider="cli",
        base_cmd=base_cmd,
        delivery=delivery,
        prompt=json.dumps(prompt_payload, indent=2, sort_keys=True),
        cwd=repo_root,
        timeout_s=900,
    )
    stream_payload = {
        "base_cmd": base_cmd,
        "delivery": delivery,
        "session_id": stream_result.session_id,
        "returncode": stream_result.returncode,
        "ok": stream_result.ok,
        "log_path": str(stream_result.log_path),
        "stdout": stream_result.stdout,
        "stderr": stream_result.stderr,
    }
    _write_json(stream_path, stream_payload)
    store.emit_task_message(task_id=task_id, message_kind="partial", stream="ideation_enrichment", payload={"status": "running", "stage": "stream_persisted", "stream_path": str(stream_path), "session_id": stream_result.session_id})
    if not stream_result.ok:
        failure = {
            "status": "failed",
            "idea_id": idea_id,
            "task_id": task_id,
            "pipeline_key": pipeline_key,
            "session_id": stream_result.session_id,
            "log_path": str(stream_result.log_path),
            "returncode": stream_result.returncode,
            "stdout": stream_result.stdout,
            "stderr": stream_result.stderr,
            "response_guidance": response_guidance,
        }
        _write_json(terminal_path, failure)
        persist_ideation_enrichment_progress(
            repo_root=repo_root,
            idea_id=idea_id,
            project_id=project_id,
            pipeline_key=pipeline_key,
            task_id=task_id,
            status="failed",
            stage="failed",
            progress_pct=100,
            summary="Background ideation enrichment failed.",
            prompt_path=str(prompt_path),
            stream_path=str(stream_path),
            terminal_path=str(terminal_path),
            log_path=str(stream_result.log_path),
            contract=contract,
            response_guidance=response_guidance,
            error=f"returncode={stream_result.returncode}",
        )
        store.record_task_step(task_id=task_id, step_name="ideation_enrichment.run", status="failed", payload={"returncode": stream_result.returncode, "log_path": str(stream_result.log_path)})
        raise RuntimeError(f"ideation enrichment worker failed with returncode={stream_result.returncode}")

    result_shape = _extract_json_object(stream_result.stdout)
    terminal = {
        "status": "completed",
        "idea_id": idea_id,
        "task_id": task_id,
        "pipeline_key": pipeline_key,
        "session_id": stream_result.session_id,
        "log_path": str(stream_result.log_path),
        "returncode": stream_result.returncode,
        "response_guidance": response_guidance,
        "result_shape": result_shape,
        "agent_loop_stream": stream_payload,
    }
    _write_json(terminal_path, terminal)
    snapshot = persist_ideation_enrichment_progress(
        repo_root=repo_root,
        idea_id=idea_id,
        project_id=project_id,
        pipeline_key=pipeline_key,
        task_id=task_id,
        status="completed",
        stage="completed",
        progress_pct=100,
        summary=str(result_shape.get("summary") or "Background ideation enrichment completed."),
        prompt_path=str(prompt_path),
        stream_path=str(stream_path),
        terminal_path=str(terminal_path),
        log_path=str(stream_result.log_path),
        contract=contract,
        response_guidance=response_guidance,
        result_shape=result_shape,
    )
    response = {
        "idea_id": idea_id,
        "pipeline_key": pipeline_key,
        "status": "completed",
        "status_path": str(ideation_enrichment_status_path(repo_root, idea_id=idea_id)),
        "terminal_path": str(terminal_path),
        "stream_path": str(stream_path),
        "result_shape": result_shape,
        "snapshot": snapshot,
    }
    store.emit_task_message(task_id=task_id, message_kind="result", stream="ideation_enrichment", payload=response)
    store.record_task_step(task_id=task_id, step_name="ideation_enrichment.run", status="completed", payload={"terminal_path": str(terminal_path), "stream_path": str(stream_path)})
    return response


def process_ideation_enrichment_once(
    *,
    store: ExecutionStore,
    repo_root: Path,
    worker_id: str = "idea-ideation-enrichment",
):
    return process_one_task(
        store=store,
        repo_root=repo_root,
        queue_name=IDEATION_ENRICHMENT_QUEUE_NAME,
        worker_id=worker_id,
        handlers={IDEATION_ENRICHMENT_TASK_KIND: handle_ideation_enrichment_task},
    )
