from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

from .paths import get_idea_paths


@dataclass(frozen=True)
class EvidenceItem:
    anchor: str
    kind: str | None = None


def _iso_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def collect_evidence(repo_root: Path, *, max_files: int = 50) -> list[EvidenceItem]:
    """Collect lightweight evidence anchors.

    We deliberately avoid copying raw file contents into artifacts by default
    to reduce secret leakage risk.
    """

    evidence: list[EvidenceItem] = []
    repo_name = repo_root.name

    count = 0
    for p in sorted(repo_root.rglob("*")):
        if count >= max_files:
            break
        # Exclude internal/system paths.
        posix = p.as_posix()
        if "/.git/" in posix or "/.devflow/" in posix or p.name.startswith(".venv"):
            continue
        if p.is_dir():
            continue
        rel = p.relative_to(repo_root).as_posix()
        anchor = f"fs:{repo_name}/{rel}"
        kind = None
        if rel.endswith(".md"):
            kind = "docs"
        elif rel.endswith(".py"):
            kind = "python"
        evidence.append(EvidenceItem(anchor=anchor, kind=kind))
        count += 1

    # Ensure non-empty evidence by falling back to repo root marker.
    if not evidence:
        evidence.append(EvidenceItem(anchor=f"fs:{repo_name}/"))

    return evidence


def write_analysis_artifact(
    *,
    repo_root: Path,
    idea_id: str,
    analysis_id: str,
    git_ref: str | None = None,
) -> Path:
    paths = get_idea_paths(repo_root, idea_id=idea_id)
    artifact_dir = paths.analysis_root / analysis_id
    artifact_dir.mkdir(parents=True, exist_ok=True)

    evidence = collect_evidence(repo_root)
    analysis = {
        "analysis_id": analysis_id,
        "idea_id": idea_id,
        "repo_root": str(repo_root),
        "git_ref": git_ref,
        "created_at": _iso_now(),
        "evidence": [{"anchor": e.anchor, "kind": e.kind} for e in evidence],
    }

    (artifact_dir / "analysis.json").write_text(json.dumps(analysis, indent=2, sort_keys=True), encoding="utf-8")

    report_lines: list[str] = []
    report_lines.append(f"# Analysis {analysis_id}\n")
    report_lines.append("## Provenance\n")
    report_lines.append(f"- idea_id: {idea_id}\n")
    report_lines.append(f"- repo_root: {repo_root}\n")
    report_lines.append("\n## Evidence\n")
    for e in evidence[:25]:
        report_lines.append(f"- anchor: {e.anchor}\n")
    report_lines.append("\n## Redaction\n")
    report_lines.append("Redaction enabled: stored artifacts avoid raw file contents by default.\n")

    (artifact_dir / "report.md").write_text("".join(report_lines), encoding="utf-8")
    return artifact_dir
