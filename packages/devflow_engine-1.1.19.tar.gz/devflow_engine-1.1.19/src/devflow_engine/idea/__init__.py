"""Idea tool (Area 5) artifacts under .devflow/ideas.

This module provides simple, deterministic CLI behaviors needed by tests.
"""
