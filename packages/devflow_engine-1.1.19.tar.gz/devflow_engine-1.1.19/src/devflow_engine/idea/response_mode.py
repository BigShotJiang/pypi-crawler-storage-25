from __future__ import annotations

from contextlib import contextmanager
from contextvars import ContextVar
from typing import Iterator

_RESPONSE_MODE_LABEL: ContextVar[str | None] = ContextVar("devflow_idea_response_mode_label", default=None)
_DEFAULT_RESPONSE_MODE_LABEL = "devin2_pi"


def normalize_response_mode_label(value: str | None) -> str:
    normalized = str(value or "").strip().lower()
    return normalized or _DEFAULT_RESPONSE_MODE_LABEL


def current_response_mode_label(*, env_value: str | None = None) -> str:
    active = _RESPONSE_MODE_LABEL.get()
    if active is not None:
        return normalize_response_mode_label(active)
    return normalize_response_mode_label(env_value)


@contextmanager
def response_mode_context(*, response_mode_label: str | None) -> Iterator[None]:
    normalized = normalize_response_mode_label(response_mode_label)
    token = _RESPONSE_MODE_LABEL.set(normalized)
    try:
        yield
    finally:
        _RESPONSE_MODE_LABEL.reset(token)
