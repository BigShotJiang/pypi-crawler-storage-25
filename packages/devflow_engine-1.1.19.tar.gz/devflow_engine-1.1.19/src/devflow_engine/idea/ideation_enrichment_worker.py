from __future__ import annotations

import argparse
from pathlib import Path

from devflow_engine.idea.devin_chat_dag import run_contract_enrichment_worker


def main() -> int:
    parser = argparse.ArgumentParser(description="Run Devin ideation contract enrichment in the background.")
    parser.add_argument("--repo-root", required=True)
    parser.add_argument("--idea-id", required=True)
    args = parser.parse_args()
    run_contract_enrichment_worker(repo_root=Path(args.repo_root).expanduser().resolve(), idea_id=str(args.idea_id))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
