from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class IdeaPaths:
    repo_root: Path
    devflow_dir: Path
    ideas_root: Path
    idea_dir: Path
    analysis_root: Path
    drafts_root: Path


def get_idea_paths(repo_root: Path, *, idea_id: str) -> IdeaPaths:
    devflow_dir = repo_root / ".devflow"
    ideas_root = devflow_dir / "ideas"
    idea_dir = ideas_root / idea_id
    return IdeaPaths(
        repo_root=repo_root,
        devflow_dir=devflow_dir,
        ideas_root=ideas_root,
        idea_dir=idea_dir,
        analysis_root=idea_dir / "analysis",
        drafts_root=idea_dir / "drafts",
    )
