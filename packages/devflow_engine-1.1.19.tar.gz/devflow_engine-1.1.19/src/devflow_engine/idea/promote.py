from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path

from .drafts import dest_filename_for_draft, parse_locked_header
from .paths import get_idea_paths


@dataclass(frozen=True)
class PromoteOp:
    kind: str  # create|update
    src: Path
    dest: Path


def _load_manifest(repo_root: Path, *, idea_id: str, draft_set_id: str) -> dict:
    paths = get_idea_paths(repo_root, idea_id=idea_id)
    p = paths.drafts_root / draft_set_id / "manifest.json"
    return json.loads(p.read_text(encoding="utf-8"))


def plan_promotion(*, repo_root: Path, idea_id: str, draft_set_id: str, dest_root: Path) -> list[PromoteOp]:
    manifest = _load_manifest(repo_root, idea_id=idea_id, draft_set_id=draft_set_id)
    draft_paths = manifest.get("draft_paths") or []

    ops: list[PromoteOp] = []
    for rel in draft_paths:
        src = repo_root / rel
        header = parse_locked_header(src.read_text(encoding="utf-8", errors="ignore"))
        dest_name = dest_filename_for_draft(src, header=header)
        dest = dest_root / dest_name
        kind = "update" if dest.exists() else "create"
        ops.append(PromoteOp(kind=kind, src=src, dest=dest))

    ops.sort(key=lambda o: (o.dest.as_posix(), o.src.as_posix()))
    return ops


def apply_promotion(*, ops: list[PromoteOp], force: bool) -> tuple[bool, list[str]]:
    messages: list[str] = []
    for op in ops:
        if op.dest.exists() and not force:
            messages.append(f"conflict: destination exists: {op.dest}")
            return False, messages

    for op in ops:
        op.dest.parent.mkdir(parents=True, exist_ok=True)
        op.dest.write_text(op.src.read_text(encoding="utf-8"), encoding="utf-8")
        messages.append(f"{op.kind}: {op.dest}")

    return True, messages
