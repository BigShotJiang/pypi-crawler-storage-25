from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path

from .drafts import dest_filename_for_draft, parse_locked_header
from .paths import get_idea_paths


@dataclass(frozen=True)
class DiffEntry:
    draft_story_id: str
    draft_path: str
    canonical_path: str | None
    status: str  # added|modified|unchanged


def _load_manifest(repo_root: Path, *, idea_id: str, draft_set_id: str) -> dict:
    paths = get_idea_paths(repo_root, idea_id=idea_id)
    p = paths.drafts_root / draft_set_id / "manifest.json"
    return json.loads(p.read_text(encoding="utf-8"))


def compute_diff(
    *,
    repo_root: Path,
    idea_id: str,
    draft_set_id: str,
    canonical_root: Path,
) -> list[DiffEntry]:
    manifest = _load_manifest(repo_root, idea_id=idea_id, draft_set_id=draft_set_id)
    draft_paths = manifest.get("draft_paths") or []

    entries: list[DiffEntry] = []
    for rel in draft_paths:
        draft_path = repo_root / rel
        text = draft_path.read_text(encoding="utf-8", errors="ignore")
        header = parse_locked_header(text)
        draft_story_id = header.get("draft_story_id") or draft_path.stem

        dest_name = dest_filename_for_draft(draft_path, header=header)
        canon_path = canonical_root / dest_name

        if not canon_path.exists():
            status = "added"
            canon = None
        else:
            canon = str(canon_path)
            canon_text = canon_path.read_text(encoding="utf-8", errors="ignore")
            status = "unchanged" if canon_text == text else "modified"

        entries.append(
            DiffEntry(
                draft_story_id=str(draft_story_id),
                draft_path=str(draft_path),
                canonical_path=canon,
                status=status,
            )
        )

    entries.sort(key=lambda e: (e.draft_story_id, e.draft_path))
    return entries


def render_diff_text(entries: list[DiffEntry]) -> str:
    counts = {"added": 0, "modified": 0, "unchanged": 0}
    for e in entries:
        counts[e.status] = counts.get(e.status, 0) + 1

    lines: list[str] = []
    lines.append("Diff summary")
    lines.append(f"added: {counts.get('added', 0)}")
    lines.append(f"modified: {counts.get('modified', 0)}")
    lines.append(f"unchanged: {counts.get('unchanged', 0)}")
    lines.append("")

    for e in entries:
        lines.append(f"- {e.draft_story_id}: {e.status}")
        if e.canonical_path:
            lines.append(f"  canonical: {e.canonical_path}")
        lines.append(f"  draft: {e.draft_path}")

    return "\n".join(lines) + "\n"


def render_diff_json(entries: list[DiffEntry]) -> str:
    data = {
        "entries": [
            {
                "draft_story_id": e.draft_story_id,
                "draft_path": e.draft_path,
                "canonical": e.canonical_path,
                "status": e.status,
            }
            for e in entries
        ]
    }
    return json.dumps(data, indent=2, sort_keys=True) + "\n"
