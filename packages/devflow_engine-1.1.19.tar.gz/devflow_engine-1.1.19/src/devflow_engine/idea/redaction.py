from __future__ import annotations

import re
from dataclasses import dataclass


# Intentionally lightweight, heuristic redaction.
_SECRET_PATTERNS: list[re.Pattern[str]] = [
    re.compile(r"sk_(live|test)_[A-Za-z0-9]{10,}"),
    re.compile(r"AKIA[0-9A-Z]{16}"),
]


@dataclass(frozen=True)
class RedactionResult:
    text: str
    redacted: bool


def redact_text(text: str) -> RedactionResult:
    redacted_any = False
    out = text
    for pat in _SECRET_PATTERNS:
        if pat.search(out):
            redacted_any = True
            out = pat.sub("***REDACTED***", out)
    return RedactionResult(text=out, redacted=redacted_any)
