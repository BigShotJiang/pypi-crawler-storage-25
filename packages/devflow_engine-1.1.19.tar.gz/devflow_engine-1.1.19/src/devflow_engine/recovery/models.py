from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field


QueueItemKind = Literal["scope", "idea_creation", "idea", "story", "integration", "recovery"]
RecoveryDisposition = Literal["replayable", "blocked"]
RecoveryAction = Literal[
    "requeue_without_fix",
    "repair_artifact_then_requeue",
    "adjust_story_shaping_policy_then_requeue",
    "manual_review_required",
    "dead_letter",
    "none",
]
FixScope = Literal["item_local", "systemic"]
ReplayScope = Literal["single_item", "similar_failed_items"]
FailureType = Literal["code_error", "process_error"]
RecoveryStrategy = Literal[
    "handoff_to_code_error",
    "replay_boundary_recovery",
    "state_reconciliation_recovery",
    "artifact_regeneration_recovery",
    "preflight_health_repair_recovery",
    "escalate_process_bug",
]


class FailedQueueItemArtifact(BaseModel):
    queue_type: QueueItemKind
    item_id: str
    project_id: str | None = None
    dfs_project_id: str | None = None
    enqueue_run_id: str
    status: str
    title: str
    payload_ref: str | None = None
    payload_exists: bool = False
    story_id: str | None = None
    failure_message: str | None = None
    failure_context: dict = Field(default_factory=dict)
    raw_row: dict = Field(default_factory=dict)
    discovered_artifacts: dict[str, Any] = Field(default_factory=dict)


class RecoverySuccessCriterion(BaseModel):
    criterion: str
    oracle: str
    evidence_ref: str | None = None


class RecoveryNonConvergenceArtifact(BaseModel):
    summary: str
    reason: str
    attempts_reviewed: int = 0
    same_failure_surface: bool = False
    unchanged_test_surface: bool = False
    wrong_seam: bool = False
    downstream_blocker: bool = False
    downstream_blocker_stage: str | None = None
    schema_or_runtime_drift: bool = False
    measurable_progress: bool = True
    evidence: list[str] = Field(default_factory=list)


class RecoveryInvestigationArtifact(BaseModel):
    queue_type: QueueItemKind
    item_id: str
    summary: str
    failure_nature: str
    evidence: list[str] = Field(default_factory=list)
    primary_evidence_source: str | None = None
    primary_evidence_refs: list[str] = Field(default_factory=list)
    primary_log_insight: str | None = None
    affected_boundary: str | None = None
    likely_failed_stage: str | None = None
    confidence: str = "medium"
    recovery_goal: str
    success_criteria: list[RecoverySuccessCriterion] = Field(default_factory=list)
    verification_evidence: list[str] = Field(default_factory=list)
    replay_path: str | None = None
    escalation_conditions: list[str] = Field(default_factory=list)
    non_convergence: RecoveryNonConvergenceArtifact | None = None


class RecoveryDiagnosisArtifact(BaseModel):
    queue_type: QueueItemKind
    item_id: str
    strategy: RecoveryStrategy
    summary: str
    rationale: str
    verification_targets: list[RecoverySuccessCriterion] = Field(default_factory=list)
    replay_path: str | None = None
    suggested_action: RecoveryAction = "none"
    evidence: list[str] = Field(default_factory=list)


class RemediationPlanArtifact(BaseModel):
    queue_type: QueueItemKind
    action: RecoveryAction
    summary: str
    steps: list[str] = Field(default_factory=list)
    bounded: bool = True
    preserve_failure_context: bool = True
    fix_scope: FixScope = "item_local"
    replay_scope: ReplayScope = "single_item"
    replay_path: str | None = None
    remediation_artifact: str | None = None


class FixApplicationArtifact(BaseModel):
    queue_type: QueueItemKind
    action_taken: RecoveryAction
    changed: bool
    notes: list[str] = Field(default_factory=list)
    remediation_artifact: str | None = None


class RecoveryExecutionArtifact(BaseModel):
    queue_type: QueueItemKind
    item_id: str
    outcome: Literal["reenqueued", "delegated", "blocked"]
    execution_summary: str
    preserve_failure_context: bool = True
    delegation_summary: str | None = None
    attempts_used: int = 1
    success_criteria: list[RecoverySuccessCriterion] = Field(default_factory=list)
    verification_summary: str | None = None
    primary_evidence_source: str | None = None
    primary_evidence_refs: list[str] = Field(default_factory=list)
    primary_log_insight: str | None = None
    recovery_handoff_artifact_path: str | None = None
    recovery_handoff_summary: str | None = None


class PreReplayCheckArtifact(BaseModel):
    queue_type: QueueItemKind
    ready: bool
    checks: list[str] = Field(default_factory=list)
    blocking_reasons: list[str] = Field(default_factory=list)


class ReenqueueArtifact(BaseModel):
    queue_type: QueueItemKind
    item_id: str
    status: str
    failure_context: dict | None = None
    replay_metadata: dict[str, Any] | None = None


class RecoveryHandoffArtifact(BaseModel):
    queue_type: QueueItemKind
    item_id: str
    story_id: str | None = None
    implementation_run_id: str | None = None
    failed_stage: str | None = None
    primary_evidence_source: str | None = None
    primary_evidence_refs: list[str] = Field(default_factory=list)
    key_log_insight: str | None = None
    failing_surface_summary: str
    likely_seam: str | None = None
    disproven_dead_ends: list[str] = Field(default_factory=list)
    verification_blockers: list[str] = Field(default_factory=list)
    non_convergence_insight: str | None = None
    produced_by_recovery_run_id: str | None = None
    consumer_hint: str = "Attach this artifact to the next Green attempt for the same story when present."


class RecoveryOutcomeArtifact(BaseModel):
    queue_type: QueueItemKind
    item_id: str
    project_id: str | None = None
    outcome: Literal["reenqueued", "blocked", "delegated", "recovered"]
    summary: str
    investigation: RecoveryInvestigationArtifact | None = None
    plan: RemediationPlanArtifact | None = None
    reenqueue: ReenqueueArtifact | None = None
    recovery_handoff_artifact_path: str | None = None


class SystemicPatternArtifact(BaseModel):
    failure_signature: str
    is_systemic: bool
    affected_queue_type: str
    affected_item_ids: list[str]
    sample_failure_messages: list[str]
    failed_stages: list[str]
    total_affected: int
    pattern_summary: str


class FilePatch(BaseModel):
    path: str
    content: str


class CodeRootCauseArtifact(BaseModel):
    failure_signature: str
    root_cause_location: str
    root_cause_description: str
    fix_type: Literal["code_fix", "config_fix", "environment_fix", "dead_letter", "item_local_only"]
    specific_fix_plan: str
    files_inspected: list[str]
    confidence: Literal["high", "medium", "low"]
    affects_all_items: bool
    residual_items_needing_attention: list[str]


class RemediationResultArtifact(BaseModel):
    fix_type: str
    fix_applied: bool
    files_changed: list[str]
    fix_summary: str
    verification_notes: str
    ready_to_requeue: bool
    items_to_requeue: list[str]
    items_to_dead_letter: list[str]
    file_patches: list[FilePatch] = Field(default_factory=list)
