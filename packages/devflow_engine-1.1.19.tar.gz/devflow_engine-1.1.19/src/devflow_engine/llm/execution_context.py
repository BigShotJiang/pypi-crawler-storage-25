from __future__ import annotations

from contextlib import contextmanager
from contextvars import ContextVar
from pathlib import Path
from typing import Any, Iterator


_CURRENT_EXECUTION_CONTEXT: ContextVar[dict[str, Any] | None] = ContextVar("devflow_execution_context", default=None)


def get_execution_context() -> dict[str, Any] | None:
    ctx = _CURRENT_EXECUTION_CONTEXT.get()
    return dict(ctx) if isinstance(ctx, dict) else None


@contextmanager
def execution_context(**kwargs: Any) -> Iterator[None]:
    ctx = {k: v for k, v in kwargs.items() if v is not None}
    if "repo_root" in ctx and isinstance(ctx["repo_root"], Path):
        ctx["repo_root"] = str(ctx["repo_root"])
    token = _CURRENT_EXECUTION_CONTEXT.set(ctx)
    try:
        yield
    finally:
        _CURRENT_EXECUTION_CONTEXT.reset(token)
