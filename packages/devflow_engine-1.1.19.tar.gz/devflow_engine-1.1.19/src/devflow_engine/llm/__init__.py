"""LLM execution adapters (CLI one-shot for now)."""
