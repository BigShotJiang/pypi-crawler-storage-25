from __future__ import annotations

import os
import shlex
import subprocess
from dataclasses import dataclass
from pathlib import Path

from ..api_keys import bootstrap_provider_api_keys


@dataclass(frozen=True)
class OneShotResult:
    ok: bool
    stdout: str
    stderr: str
    returncode: int


def _normalize_timeout_output(value: str | bytes | None) -> str:
    if value is None:
        return ""
    if isinstance(value, bytes):
        return value.decode("utf-8", errors="replace")
    return value


def _split_base(cmd: str) -> list[str]:
    parts = shlex.split(cmd)
    return [p for p in parts if p]


def run_one_shot(
    *,
    base_cmd: str,
    delivery: str,
    prompt: str,
    cwd: Path,
    timeout_seconds: int | None = None,
    provider: str | None = None,
) -> OneShotResult:
    """Run a one-shot prompt via an external CLI.

    delivery:
      - argument: append prompt as a final argv element
      - stdin: pass prompt via stdin

    This is intentionally simple; streaming/resume can be added later.
    """

    argv = _split_base(base_cmd)
    if not argv:
        raise RuntimeError("llm cli base command is empty")

    child_env = os.environ.copy()
    if provider:
        bootstrap_provider_api_keys(env=child_env)

    if delivery == "argument":
        argv = argv + [prompt]
        try:
            p = subprocess.run(argv, cwd=str(cwd), text=True, capture_output=True, timeout=timeout_seconds, env=child_env)
        except subprocess.TimeoutExpired as exc:
            return OneShotResult(
                ok=False,
                stdout=_normalize_timeout_output(exc.stdout),
                stderr=_normalize_timeout_output(exc.stderr) + f"\nTIMEOUT after {timeout_seconds}s",
                returncode=124,
            )
        return OneShotResult(ok=p.returncode == 0, stdout=p.stdout, stderr=p.stderr, returncode=p.returncode)

    if delivery == "stdin":
        try:
            p = subprocess.run(argv, cwd=str(cwd), text=True, input=prompt, capture_output=True, timeout=timeout_seconds, env=child_env)
        except subprocess.TimeoutExpired as exc:
            return OneShotResult(
                ok=False,
                stdout=_normalize_timeout_output(exc.stdout),
                stderr=_normalize_timeout_output(exc.stderr) + f"\nTIMEOUT after {timeout_seconds}s",
                returncode=124,
            )
        return OneShotResult(ok=p.returncode == 0, stdout=p.stdout, stderr=p.stderr, returncode=p.returncode)

    raise RuntimeError(f"unsupported delivery: {delivery}")
