from __future__ import annotations

import json
import hashlib
import hmac
import os
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Literal
from urllib import error, request

from ..api_keys import get_provider_api_key


ANTHROPIC_MESSAGES_URL = "https://api.anthropic.com/v1/messages"
ANTHROPIC_VERSION = "2023-06-01"
ANTHROPIC_MODEL_DEFAULT = "claude-sonnet-4-6"
OPENAI_RESPONSES_URL = "https://api.openai.com/v1/responses"
OPENAI_MODEL_DEFAULT = "gpt-5"
OLLAMA_RESPONSES_URL = "http://127.0.0.1:11434/v1/responses"
OLLAMA_MODEL_DEFAULT = "llama3.2"
GOOGLE_GENERATE_CONTENT_URL_TEMPLATE = "https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"
GOOGLE_MODEL_DEFAULT = "gemini-2.5-flash"
CLARITY_MINIMAX_AGENT_PATH = "/clarify/minimax/devflow-agent-turn"
ANTHROPIC_STYLE_PROVIDERS = frozenset({"anthropic", "minimax"})
OPENAI_STYLE_PROVIDERS = frozenset({"openai", "ollama"})
GOOGLE_STYLE_PROVIDERS = frozenset({"google"})
ProviderApiShape = Literal["anthropic", "openai", "google"]


@dataclass(frozen=True)
class AnthropicApiSettings:
    api_key: str
    model: str
    max_tokens: int
    api_url: str = ANTHROPIC_MESSAGES_URL
    api_version: str = ANTHROPIC_VERSION
    provider_label: str = "Anthropic"


@dataclass(frozen=True)
class OpenAiApiSettings:
    api_key: str
    model: str
    api_url: str = OPENAI_RESPONSES_URL
    provider_label: str = "OpenAI"


@dataclass(frozen=True)
class GoogleApiSettings:
    api_key: str
    model: str


@dataclass(frozen=True)
class ClarityMiniMaxSettings:
    backend_url: str
    auth_secret: str           # HMAC fallback (legacy clarity routes)
    model: str
    max_tokens: int = 1_200
    api_token: str | None = None  # Clarity org API token (preferred for MiniMax)


def canonical_provider_api_shape(provider: str | None) -> ProviderApiShape | None:
    normalized = str(provider or "").strip().lower()
    if not normalized:
        return None
    if normalized in ANTHROPIC_STYLE_PROVIDERS:
        return "anthropic"
    if normalized in OPENAI_STYLE_PROVIDERS:
        return "openai"
    if normalized in GOOGLE_STYLE_PROVIDERS:
        return "google"
    return None


def provider_uses_anthropic_api_shape(provider: str | None) -> bool:
    return canonical_provider_api_shape(provider) == "anthropic"


def read_provider_api_key(*, provider: str, repo_root: Path) -> str:
    runtime_key = get_provider_api_key(provider)
    if runtime_key:
        return runtime_key

    del repo_root
    candidate_paths: list[Path] = []
    try:
        from ..idea.traditional_stories import _global_devflow_dir

        candidate_paths.append(_global_devflow_dir() / "keys" / f"{provider}.json")
    except Exception:
        candidate_paths.append(Path.home() / ".devflow" / "keys" / f"{provider}.json")

    for path in candidate_paths:
        if not path.exists():
            continue
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except Exception as exc:  # pragma: no cover - invalid operator-managed secret file is operator error
            raise RuntimeError(f"Failed to read {provider.capitalize()} key file: {path}") from exc
        api_key = str(payload.get("api_key") or "").strip()
        if api_key:
            return api_key
    raise RuntimeError(
        f"{provider.capitalize()} API key not configured. "
        f"Expected runtime env, macOS keychain entry, or global ~/.devflow/keys/{provider}.json."
    )


def read_anthropic_api_key(*, repo_root: Path) -> str:
    return read_provider_api_key(provider="anthropic", repo_root=repo_root)


def load_anthropic_api_settings(
    *,
    repo_root: Path,
    model: str | None = None,
    max_tokens: int = 1_200,
) -> AnthropicApiSettings:
    return AnthropicApiSettings(
        api_key=read_anthropic_api_key(repo_root=repo_root),
        model=str(model or ANTHROPIC_MODEL_DEFAULT).strip() or ANTHROPIC_MODEL_DEFAULT,
        max_tokens=max_tokens,
    )


def load_openai_api_settings(
    *,
    repo_root: Path,
    provider: str = "openai",
    model: str | None = None,
) -> OpenAiApiSettings:
    normalized_provider = str(provider or "openai").strip().lower() or "openai"
    if normalized_provider == "ollama":
        api_key = get_provider_api_key("ollama") or "ollama"
        api_url = OLLAMA_RESPONSES_URL
        provider_label = "Ollama"
        resolved_model = str(model or OLLAMA_MODEL_DEFAULT).strip() or OLLAMA_MODEL_DEFAULT
    else:
        api_key = read_provider_api_key(provider="openai", repo_root=repo_root)
        api_url = OPENAI_RESPONSES_URL
        provider_label = "OpenAI"
        resolved_model = str(model or OPENAI_MODEL_DEFAULT).strip() or OPENAI_MODEL_DEFAULT
    return OpenAiApiSettings(
        api_key=api_key,
        model=resolved_model,
        api_url=api_url,
        provider_label=provider_label,
    )


def load_google_api_settings(
    *,
    repo_root: Path,
    model: str | None = None,
) -> GoogleApiSettings:
    return GoogleApiSettings(
        api_key=read_provider_api_key(provider="google", repo_root=repo_root),
        model=str(model or GOOGLE_MODEL_DEFAULT).strip() or GOOGLE_MODEL_DEFAULT,
    )


def load_clarity_minimax_settings(
    *,
    model: str | None = None,
    max_tokens: int = 1_200,
) -> ClarityMiniMaxSettings:
    backend_url = str(os.environ.get("DEVFLOW_BACKEND_URL") or os.environ.get("CLARITY_BACKEND_URL") or "").strip()
    if not backend_url:
        raise RuntimeError("Clarity MiniMax endpoint is not configured. Set DEVFLOW_BACKEND_URL or CLARITY_BACKEND_URL.")
    # Prefer the org API token (clarity-backend's MiniMax endpoint requires
    # `auth_type=api_token`; HMAC is rejected with 403 AUTHORIZATION_ERROR).
    # Fall back to HMAC for legacy routes that still accept it.
    api_token = str(
        os.environ.get("CLARITY_API_TOKEN")
        or os.environ.get("DEVFLOW_HOST_CLARITY_API_KEY")
        or ""
    ).strip() or None
    auth_secret = str(
        os.environ.get("DEVFLOW_BACKEND_SECRET_KEY")
        or os.environ.get("CLARITY_SECRET_KEY")
        or os.environ.get("SECRET_KEY")
        or ""
    ).strip()
    if not api_token and not auth_secret:
        raise RuntimeError(
            "Clarity MiniMax endpoint auth is not configured. "
            "Set CLARITY_API_TOKEN (preferred) or DEVFLOW_BACKEND_SECRET_KEY/CLARITY_SECRET_KEY/SECRET_KEY."
        )
    resolved_model = str(model or "MiniMax-M2.7").strip() or "MiniMax-M2.7"
    return ClarityMiniMaxSettings(
        backend_url=backend_url.rstrip("/"),
        auth_secret=auth_secret,
        model=resolved_model,
        max_tokens=max_tokens,
        api_token=api_token,
    )


def _build_hmac_bearer_token(*, secret: str, body: bytes) -> str:
    timestamp = str(int(time.time()))
    signature = hmac.new(
        secret.encode("utf-8"),
        f"{timestamp}.".encode("utf-8") + body,
        hashlib.sha256,
    ).hexdigest()
    return f"Bearer {signature}.{timestamp}"


def anthropic_messages_create(
    *,
    settings: AnthropicApiSettings,
    system_prompt: str,
    messages: list[dict[str, Any]],
    tools: list[dict[str, Any]],
    timeout_seconds: int | None,
) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "model": settings.model,
        "max_tokens": settings.max_tokens,
        "system": system_prompt,
        "messages": messages,
        "tools": tools,
    }
    data = json.dumps(payload).encode("utf-8")
    req = request.Request(
        settings.api_url,
        data=data,
        headers={
            "content-type": "application/json",
            "x-api-key": settings.api_key,
            "anthropic-version": settings.api_version,
        },
        method="POST",
    )
    try:
        with request.urlopen(req, timeout=timeout_seconds) as resp:
            raw = resp.read().decode("utf-8")
    except error.HTTPError as exc:
        body = exc.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"{settings.provider_label} API request failed: {exc.code} {body}") from exc
    except error.URLError as exc:
        raise RuntimeError(f"{settings.provider_label} API request failed: {exc}") from exc
    return json.loads(raw)


def clarity_minimax_devflow_agent_turn(
    *,
    settings: ClarityMiniMaxSettings,
    prompt: str,
    timeout_seconds: int | None,
    metadata: dict[str, Any] | None = None,
) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "model": settings.model,
        "max_tokens": settings.max_tokens,
        "messages": [{"role": "user", "content": prompt}],
        "metadata": {
            "agent_id": "devin_agent",
            "runtime": "devflow_engine",
            "langfuse_observation_name": "devin_agent",
            **(metadata or {}),
        },
        "stream": False,
    }
    data = json.dumps(payload, separators=(",", ":")).encode("utf-8")
    # MiniMax endpoint requires api_token auth (HMAC → 403). Use the org
    # API token when set; fall back to HMAC only when no token is plumbed.
    if settings.api_token:
        auth_header = f"Bearer {settings.api_token}"
    else:
        auth_header = _build_hmac_bearer_token(secret=settings.auth_secret, body=data)
    req = request.Request(
        f"{settings.backend_url}{CLARITY_MINIMAX_AGENT_PATH}",
        data=data,
        headers={
            "content-type": "application/json",
            "authorization": auth_header,
        },
        method="POST",
    )
    try:
        with request.urlopen(req, timeout=timeout_seconds) as resp:
            raw = resp.read().decode("utf-8")
    except error.HTTPError as exc:
        body = exc.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"Clarity MiniMax request failed: {exc.code} {body}") from exc
    except error.URLError as exc:
        raise RuntimeError(f"Clarity MiniMax request failed: {exc}") from exc
    return json.loads(raw)


def clarity_minimax_response_text(response: dict[str, Any]) -> str:
    data = response.get("data")
    if isinstance(data, dict):
        text = str(data.get("text") or "").strip()
        if text:
            return text
        raw_response = data.get("raw_response")
        if isinstance(raw_response, dict):
            text = anthropic_response_text(raw_response)
            if text:
                return text
    return json.dumps(response, indent=2, sort_keys=True)


def anthropic_response_text(response: dict[str, Any]) -> str:
    return "\n".join(
        str(block.get("text") or "").strip()
        for block in list(response.get("content") or [])
        if block.get("type") == "text"
    ).strip()


def _openai_text_format_for_response_contract(response_contract: str | None) -> dict[str, Any] | None:
    if response_contract != "json_only":
        return None
    return {
        "format": {
            "type": "json_schema",
            "name": "generic_json_response",
            "schema": {
                "type": "object",
                "additionalProperties": True,
            },
        }
    }


def openai_responses_create(
    *,
    settings: OpenAiApiSettings,
    prompt: str | None = None,
    content_blocks: list[dict[str, Any]] | None = None,
    timeout_seconds: int | None,
    response_contract: str | None = None,
) -> dict[str, Any]:
    """Call OpenAI's Responses API.

    Two input shapes:
    - ``prompt=<str>`` (legacy / default text-only): packed as
      ``input: <str>`` per OpenAI's documented shorthand.
    - ``content_blocks=[{...}]`` (vision / multimodal): packed as
      ``input: [{role: 'user', content: [<blocks>]}]`` per the
      Responses API content-array spec. Each block is a dict with at
      least ``type`` ('input_text' or 'input_image'); image blocks
      use ``image_url`` (data URL or HTTPS URL).

    Callers must supply exactly one of the two; we raise otherwise."""
    if (prompt is None) == (content_blocks is None):
        raise ValueError(
            "openai_responses_create: provide exactly one of prompt= or content_blocks="
        )

    payload: dict[str, Any] = {"model": settings.model}
    if content_blocks is not None:
        payload["input"] = [{"role": "user", "content": content_blocks}]
    else:
        payload["input"] = prompt
    text_format = _openai_text_format_for_response_contract(response_contract)
    if text_format is not None:
        payload["text"] = text_format
    data = json.dumps(payload).encode("utf-8")
    req = request.Request(
        settings.api_url,
        data=data,
        headers={
            "content-type": "application/json",
            "authorization": f"Bearer {settings.api_key}",
        },
        method="POST",
    )
    try:
        with request.urlopen(req, timeout=timeout_seconds) as resp:
            raw = resp.read().decode("utf-8")
    except error.HTTPError as exc:
        body = exc.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"{settings.provider_label} API request failed: {exc.code} {body}") from exc
    except error.URLError as exc:
        raise RuntimeError(f"{settings.provider_label} API request failed: {exc}") from exc
    return json.loads(raw)


def openai_response_text(response: dict[str, Any]) -> str:
    output_text = str(response.get("output_text") or "").strip()
    if output_text:
        return output_text

    collected: list[str] = []
    for item in list(response.get("output") or []):
        for block in list(item.get("content") or []):
            if block.get("type") in {"output_text", "text"}:
                text = str(block.get("text") or "").strip()
                if text:
                    collected.append(text)
    return "\n".join(collected).strip()


def google_generate_content(
    *,
    settings: GoogleApiSettings,
    prompt: str,
    timeout_seconds: int | None,
) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "contents": [
            {
                "role": "user",
                "parts": [{"text": prompt}],
            }
        ]
    }
    data = json.dumps(payload).encode("utf-8")
    req = request.Request(
        GOOGLE_GENERATE_CONTENT_URL_TEMPLATE.format(model=settings.model),
        data=data,
        headers={
            "content-type": "application/json",
            "x-goog-api-key": settings.api_key,
        },
        method="POST",
    )
    try:
        with request.urlopen(req, timeout=timeout_seconds) as resp:
            raw = resp.read().decode("utf-8")
    except error.HTTPError as exc:
        body = exc.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"Google API request failed: {exc.code} {body}") from exc
    except error.URLError as exc:
        raise RuntimeError(f"Google API request failed: {exc}") from exc
    return json.loads(raw)


def google_response_text(response: dict[str, Any]) -> str:
    collected: list[str] = []
    for candidate in list(response.get("candidates") or []):
        content = candidate.get("content") or {}
        for part in list(content.get("parts") or []):
            text = str(part.get("text") or "").strip()
            if text:
                collected.append(text)
    return "\n".join(collected).strip()
