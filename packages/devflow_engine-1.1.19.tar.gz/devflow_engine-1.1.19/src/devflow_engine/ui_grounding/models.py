from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field

GroundingStatus = Literal[
    "grounded_ready",
    "grounded_with_generated_artifacts",
    "pass_with_assumptions",
    "needs_ui_review",
    "blocked_missing_ui_grounding",
]
SurfaceClassification = Literal[
    "grounded_existing",
    "grounded_partial",
    "grounded_with_generated_artifacts",
    "missing_reference",
    "non_ui_or_backend_only",
]
ReferenceType = Literal[
    "implemented_ui",
    "design_doc",
    "pencil_artifact",
    "wireframe_package",
    "screenshot_spec",
]


class UIGroundingContextArtifact(BaseModel):
    project_id: str
    idea_id: str
    idea_title: str
    idea_summary: str
    idea_path: str | None = None
    story_paths: list[str] = Field(default_factory=list)
    story_summaries: list[str] = Field(default_factory=list)
    design_paths: list[str] = Field(default_factory=list)
    repo_root: str
    upstream_refs: list[str] = Field(default_factory=list)


class DerivedUISurface(BaseModel):
    surface_id: str
    name: str
    actor: str = "user"
    jobs: list[str] = Field(default_factory=list)
    ui_bearing: bool = True
    confidence: str = "medium"
    rationale: str
    source_refs: list[str] = Field(default_factory=list)


class UISurfaceDerivationArtifact(BaseModel):
    project_id: str
    idea_id: str
    surfaces: list[DerivedUISurface] = Field(default_factory=list)
    derivation_notes: list[str] = Field(default_factory=list)


class UIReferenceInventoryItem(BaseModel):
    reference_id: str
    reference_type: ReferenceType
    path: str
    surface_labels: list[str] = Field(default_factory=list)
    provenance: list[str] = Field(default_factory=list)
    approval_status: str = "unknown"


class UIReferenceInventoryArtifact(BaseModel):
    project_id: str
    idea_id: str
    references: list[UIReferenceInventoryItem] = Field(default_factory=list)
    inventory_notes: list[str] = Field(default_factory=list)


class CodeDesignGeneratedReference(BaseModel):
    surface_id: str
    source_paths: list[str] = Field(default_factory=list)
    generated_reference_id: str
    generated_anchor: str
    generation_kind: Literal["full_screen", "partial_screen", "supporting_extraction"] = "full_screen"
    review_needed: bool = False
    normalized_reference: UIReferenceInventoryItem


class CodeDesignInventoryArtifact(BaseModel):
    project_id: str
    idea_id: str
    status: Literal[
        "not_requested",
        "skipped_preflight_not_ready",
        "skipped_no_missing_surfaces",
        "skipped_no_relevant_implemented_ui",
        "generated",
    ]
    target_surface_ids: list[str] = Field(default_factory=list)
    generated_references: list[CodeDesignGeneratedReference] = Field(default_factory=list)
    notes: list[str] = Field(default_factory=list)


class UIGroundingSurfaceResult(BaseModel):
    surface_id: str
    name: str
    classification: SurfaceClassification
    matched_reference_ids: list[str] = Field(default_factory=list)
    supporting_paths: list[str] = Field(default_factory=list)
    assumptions: list[str] = Field(default_factory=list)
    unresolved_questions: list[str] = Field(default_factory=list)
    next_required_action: str


class UIGroundingReportArtifact(BaseModel):
    project_id: str
    idea_id: str
    status: GroundingStatus
    surfaces: list[UIGroundingSurfaceResult] = Field(default_factory=list)
    summary: str
    assumptions: list[str] = Field(default_factory=list)
    next_actions: list[str] = Field(default_factory=list)


class UIGapReportArtifact(BaseModel):
    project_id: str
    idea_id: str
    missing_surfaces: list[str] = Field(default_factory=list)
    reasons: list[str] = Field(default_factory=list)
    recommendation: str
    blocked: bool = True


UIScreenSurfaceClass = Literal[
    "admin_web",
    "field_tablet",
    "customer_secure_link",
    "customer_portal",
    "internal_support_tool",
    "general_web",
    "non_ui_or_backend_only",
]
UIScreenPlatform = Literal[
    "web_desktop",
    "web_mobile_responsive",
    "tablet",
    "multi_platform",
    "not_applicable",
]
UIScreenFidelity = Literal["low", "medium", "high"]
UIScreenAudience = Literal["internal_exploration", "customer_review", "implementation_handoff"]


class UIStructureScreenItem(BaseModel):
    surface_id: str
    screen_id: str
    name: str
    surface_class: UIScreenSurfaceClass
    platform: UIScreenPlatform = "web_desktop"
    actor: str = "user"
    journey_stage: str
    required: bool = True
    source_refs: list[str] = Field(default_factory=list)
    grounding_refs: list[str] = Field(default_factory=list)
    target_fidelity: UIScreenFidelity = "medium"
    target_audience: UIScreenAudience = "customer_review"
    confidence: str = "medium"
    confidence_reason: str = "Derived from UI grounding status and source wording."
    open_questions: list[str] = Field(default_factory=list)
    assumption_tags: list[str] = Field(default_factory=list)
    notes: list[str] = Field(default_factory=list)
    flow_id: str = "primary"
    shell_id: str | None = None
    variant_ids: list[str] = Field(default_factory=list)
    dependency_screen_ids: list[str] = Field(default_factory=list)


class UIStructureContractArtifact(BaseModel):
    project_id: str
    idea_id: str
    status: Literal["ready_for_generation", "needs_ui_review", "non_ui_only"]
    default_minimum_fidelity: UIScreenFidelity = "medium"
    primary_audience: UIScreenAudience = "customer_review"
    screens: list[UIStructureScreenItem] = Field(default_factory=list)
    flow_order: list[str] = Field(default_factory=list)
    shared_shells: list[dict[str, Any]] = Field(default_factory=list)
    structural_notes: list[str] = Field(default_factory=list)
    unresolved_questions: list[str] = Field(default_factory=list)


class UIFlowMapArtifact(BaseModel):
    project_id: str
    idea_id: str
    flows: list[dict[str, Any]] = Field(default_factory=list)


class UIScreenRelationshipsArtifact(BaseModel):
    project_id: str
    idea_id: str
    relationships: list[dict[str, Any]] = Field(default_factory=list)


class UIGenerationManifestArtifact(BaseModel):
    project_id: str
    idea_id: str
    primary_audience: UIScreenAudience = "customer_review"
    default_minimum_fidelity: UIScreenFidelity = "medium"
    review_packet_outputs: list[str] = Field(default_factory=list)
    screen_generation_items: list[dict[str, Any]] = Field(default_factory=list)


class GroundedStoryReferencePatchArtifact(BaseModel):
    project_id: str
    idea_id: str
    target_refs: list[str] = Field(default_factory=list)
    attached_ui_anchors: list[dict[str, Any]] = Field(default_factory=list)
    supporting_evidence_refs: list[str] = Field(default_factory=list)
    origin: Literal["existing_ui", "generated_ui", "mixed"] = "existing_ui"


class UIGroundingDagSummary(BaseModel):
    exit_code: int
    run_id: str
    pipeline_dir: str
    message: str
    outcome: dict[str, Any]
