from __future__ import annotations

import json
import os
import shutil
import subprocess
import time
from pathlib import Path
from typing import Any

from pydantic import BaseModel, Field

from ..stores.execution_store import ExecutionStore

DEFAULT_PENCIL_APP_PATH = Path("/Applications/Pencil.app")
DEFAULT_LAUNCH_TIMEOUT_SECONDS = 15.0
DEFAULT_MCP_TIMEOUT_SECONDS = 15.0
DEFAULT_ARTIFACT_PATH = Path(".devflow/ui_grounding/pencil_preflight.json")


class PencilMCPProbeResult(BaseModel):
    server_path: str | None = None
    initialize_sent: bool = False
    initialize_acknowledged: bool = False
    server_name: str | None = None
    server_version: str | None = None
    protocol_version: str | None = None
    error: str | None = None


class PencilPreflightArtifact(BaseModel):
    ok: bool
    status: str
    repo_root: str
    artifact_path: str
    pencil_app_path: str
    app_exists: bool
    process_running_before: bool
    launched: bool = False
    process_running_after: bool = False
    mcp: PencilMCPProbeResult = Field(default_factory=PencilMCPProbeResult)
    checked_at_epoch: float
    errors: list[str] = Field(default_factory=list)


class PencilPreflightResult(BaseModel):
    exit_code: int
    message: str
    artifact_path: str
    artifact: PencilPreflightArtifact


def _write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def _artifact_path(repo_root: Path, artifact_path: Path | None) -> Path:
    if artifact_path is not None:
        return artifact_path if artifact_path.is_absolute() else repo_root / artifact_path
    return repo_root / DEFAULT_ARTIFACT_PATH


def resolve_pencil_app_path(app_path: Path | None = None) -> Path:
    override = app_path or (Path(os.environ["DEVFLOW_PENCIL_APP_PATH"]) if os.environ.get("DEVFLOW_PENCIL_APP_PATH") else None)
    return override or DEFAULT_PENCIL_APP_PATH


def _pgrep_name_candidates(app_path: Path) -> list[str]:
    names = [app_path.stem]
    if app_path.stem.endswith('.app'):
        names.append(app_path.stem[:-4])
    return [name for name in names if name]


def is_pencil_running(app_path: Path) -> bool:
    for name in _pgrep_name_candidates(app_path):
        cp = subprocess.run(["pgrep", "-x", name], capture_output=True, text=True, check=False)
        if cp.returncode == 0 and cp.stdout.strip():
            return True
    return False


def launch_pencil(app_path: Path) -> None:
    subprocess.run(["open", "-a", str(app_path)], capture_output=True, text=True, check=True)


def ensure_pencil_running(app_path: Path, *, timeout_seconds: float = DEFAULT_LAUNCH_TIMEOUT_SECONDS) -> tuple[bool, bool]:
    was_running = is_pencil_running(app_path)
    launched = False
    if not was_running:
        launch_pencil(app_path)
        launched = True
        deadline = time.monotonic() + timeout_seconds
        while time.monotonic() < deadline:
            if is_pencil_running(app_path):
                break
            time.sleep(0.25)
    return was_running, is_pencil_running(app_path) and launched


def locate_mcp_server(app_path: Path) -> Path | None:
    bundled = app_path / "Contents" / "Resources" / "app.asar.unpacked" / "out" / "mcp-server-darwin-arm64"
    return bundled if bundled.exists() else None


def probe_pencil_mcp(*, app_path: Path, timeout_seconds: float = DEFAULT_MCP_TIMEOUT_SECONDS) -> PencilMCPProbeResult:
    server_path = locate_mcp_server(app_path)
    if server_path is None:
        return PencilMCPProbeResult(error="bundled Pencil MCP server not found")
    if not os.access(server_path, os.X_OK):
        return PencilMCPProbeResult(server_path=str(server_path), error="bundled Pencil MCP server is not executable")

    req = {
        "jsonrpc": "2.0",
        "id": 1,
        "method": "initialize",
        "params": {
            "protocolVersion": "2024-11-05",
            "capabilities": {},
            "clientInfo": {"name": "devflow-engine", "version": "0.1.0"},
        },
    }
    try:
        cp = subprocess.run(
            [str(server_path), "-app", str(app_path)],
            input=json.dumps(req) + "\n",
            capture_output=True,
            text=True,
            check=False,
            timeout=timeout_seconds,
        )
    except subprocess.TimeoutExpired:
        return PencilMCPProbeResult(server_path=str(server_path), initialize_sent=True, error="timed out waiting for MCP initialize response")
    except Exception as exc:
        return PencilMCPProbeResult(server_path=str(server_path), initialize_sent=True, error=f"failed to run bundled MCP server: {exc}")

    stdout_lines = [line.strip() for line in cp.stdout.splitlines() if line.strip()]
    for line in stdout_lines:
        try:
            payload = json.loads(line)
        except json.JSONDecodeError:
            continue
        if payload.get("id") != 1:
            continue
        if payload.get("jsonrpc") != "2.0":
            continue
        if "result" in payload and isinstance(payload["result"], dict):
            result = payload["result"]
            server_info = result.get("serverInfo") or {}
            return PencilMCPProbeResult(
                server_path=str(server_path),
                initialize_sent=True,
                initialize_acknowledged=True,
                server_name=server_info.get("name"),
                server_version=server_info.get("version"),
                protocol_version=result.get("protocolVersion"),
            )
        if "error" in payload:
            return PencilMCPProbeResult(server_path=str(server_path), initialize_sent=True, error=json.dumps(payload["error"], sort_keys=True))

    detail = cp.stderr.strip() or stdout_lines[-1] if stdout_lines else "no initialize response received"
    return PencilMCPProbeResult(server_path=str(server_path), initialize_sent=True, error=detail)


def run_pencil_preflight(*, repo_root: Path, store: ExecutionStore | None = None, app_path: Path | None = None, artifact_path: Path | None = None) -> PencilPreflightResult:
    resolved_app_path = resolve_pencil_app_path(app_path)
    resolved_artifact_path = _artifact_path(repo_root, artifact_path)
    errors: list[str] = []
    process_running_before = is_pencil_running(resolved_app_path) if shutil.which("pgrep") else False

    artifact = PencilPreflightArtifact(
        ok=False,
        status="starting",
        repo_root=str(repo_root),
        artifact_path=str(resolved_artifact_path),
        pencil_app_path=str(resolved_app_path),
        app_exists=resolved_app_path.exists(),
        process_running_before=process_running_before,
        checked_at_epoch=time.time(),
    )

    if not artifact.app_exists:
        artifact.status = "not_installed"
        errors.append(f"Pencil.app not found at {resolved_app_path}")
        artifact.errors = errors
        _write_json(resolved_artifact_path, artifact.model_dump())
        return PencilPreflightResult(exit_code=2, message=json.dumps({"status": artifact.status, "artifact_path": str(resolved_artifact_path)}) + "\n", artifact_path=str(resolved_artifact_path), artifact=artifact)

    try:
        before_running = is_pencil_running(resolved_app_path)
        artifact.process_running_before = before_running
        launched = False
        if not before_running:
            launch_pencil(resolved_app_path)
            launched = True
            deadline = time.monotonic() + DEFAULT_LAUNCH_TIMEOUT_SECONDS
            while time.monotonic() < deadline:
                if is_pencil_running(resolved_app_path):
                    break
                time.sleep(0.25)
        artifact.launched = launched
        artifact.process_running_after = is_pencil_running(resolved_app_path)
        if not artifact.process_running_after:
            artifact.status = "launch_failed"
            errors.append("Pencil.app is not running after launch attempt")
        else:
            artifact.mcp = probe_pencil_mcp(app_path=resolved_app_path)
            if artifact.mcp.initialize_acknowledged:
                artifact.ok = True
                artifact.status = "ready"
            else:
                artifact.status = "mcp_unavailable"
                if artifact.mcp.error:
                    errors.append(artifact.mcp.error)
    except subprocess.CalledProcessError as exc:
        artifact.status = "launch_failed"
        errors.append(exc.stderr.strip() or exc.stdout.strip() or str(exc))
    except Exception as exc:
        artifact.status = "error"
        errors.append(str(exc))

    artifact.errors = errors
    _write_json(resolved_artifact_path, artifact.model_dump())

    if store is not None:
        run_id = store.create_run(
            dag_id="ui_grounding_pencil_preflight",
            dag_version="v1",
            root_correlation_id=f"pencil_preflight:{resolved_app_path}",
            config={"repo_root": str(repo_root), "pencil_app_path": str(resolved_app_path)},
        )
        store.mark_run_started(run_id=run_id)
        store.add_artifact(
            run_id=run_id,
            node_exec_id=None,
            kind="ui_grounding.pencil_preflight",
            uri=str(resolved_artifact_path),
            metadata=artifact.model_dump(),
            content_type="application/json",
            byte_size=resolved_artifact_path.stat().st_size,
        )
        store.mark_run_finished(run_id=run_id, status="succeeded" if artifact.ok else "failed")

    exit_code = 0 if artifact.ok else 2
    message = json.dumps({"status": artifact.status, "artifact_path": str(resolved_artifact_path)}, sort_keys=True) + "\n"
    return PencilPreflightResult(exit_code=exit_code, message=message, artifact_path=str(resolved_artifact_path), artifact=artifact)
