"""Pi-driven fix for source_kind='user_report' rows that passed the
observability gates (observed=true + no deferred questions).

The observability gate loop already produced:
- ``repro_artifact_path`` — a real test file inside the workspace
  that exercises the bug.
- ``repro_run_command`` — the exact bash invocation; currently exits
  non-zero (the bug reproduces).
- ``likely_location`` — file:line of the suspected root cause.
- ``affected_files`` — paths the model expects the fix to touch.

This module wires those into a focused pi invocation that:

1. Reads the observation + the affected files.
2. Writes the smallest change that makes the repro pass.
3. Runs ``repro_run_command``; success = exit 0.
4. Iterates up to a small budget if the first attempt doesn't flip
   the repro.
5. Returns the standard ErrorSolverWorkflow fix-fn shape
   (``{"fixed": bool, "fix_results": [...], "verification": {...}}``).

Shared between worker.py (queue-driven) and any future per-row CLI;
keeps the prompt + tool wiring out of both call sites."""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any


logger = logging.getLogger(__name__)


_MAX_FIX_ITERATIONS = 3
_PI_TIMEOUT_SECONDS = 1800


def _load_observation(*, observation: dict[str, Any] | None) -> dict[str, Any]:
    """Pull the observation fields we care about, with defaults so the
    prompt always has something coherent to render."""
    obs = observation or {}
    return {
        "summary": obs.get("summary") or "",
        "likely_location": obs.get("likely_location") or "",
        "affected_files": obs.get("affected_files") or [],
        "repro_artifact_path": obs.get("repro_artifact_path") or "",
        "repro_run_command": obs.get("repro_run_command") or "",
        "repro_output_when_bug_present": obs.get("repro_output") or "",
    }


def build_first_pass_fix_payload(
    *,
    error_task: dict[str, Any],
    observation: dict[str, Any],
    iteration_budget: int = _MAX_FIX_ITERATIONS,
) -> dict[str, Any]:
    """Render the prompt payload for pi. Separate from the invoke so
    tests can pin the prompt shape without spinning a model."""
    obs = _load_observation(observation=observation)
    return {
        "task": "fix_user_reported_bug",
        "instruction": (
            "Fix this user-reported bug. The observability pass already "
            "identified the location AND produced a repro test that "
            "currently FAILS (reproducing the bug). Your job is to "
            "make the smallest change that flips that repro from FAIL "
            "to PASS. Workflow (use your tools — read/edit/write/bash):"
            " (1) Read the affected files listed below. (2) Verify the "
            "current repro failure by running the supplied "
            "repro_run_command — confirm the bug is still reproducing. "
            "(3) Edit the smallest scope of code that addresses the "
            "root cause; prefer `edit` over `write` for surgical "
            "changes. Do NOT add new files unless strictly necessary. "
            "(4) Re-run repro_run_command. Exit 0 = fixed. (5) If the "
            "repro still fails, refine your fix and try again. You "
            "have at most {iter} attempts within this turn. (6) Emit "
            "the final JSON."
        ).format(iter=iteration_budget),
        "output_contract": (
            "Emit ONE final JSON OBJECT (and nothing else after it) "
            "with these keys: fixed (bool — true ONLY if your last "
            "repro_run_command exited 0), files_changed (list of str — "
            "workspace-relative paths you edited or wrote), "
            "verification_output (str — captured stdout+stderr from "
            "the LAST repro run, truncated ~3000 chars), iterations_used "
            "(int — how many fix attempts you made, 1..{iter}), "
            "refinement_notes (str — what you tried, what worked, "
            "what didn't, and any caveats the reviewer should know)."
        ).format(iter=iteration_budget),
        "bug_report": {
            "title": error_task.get("title"),
            "message": error_task.get("message"),
            "expected_behavior": error_task.get("expected_behavior"),
        },
        "observation": obs,
        "workspace_root": "/workspace",
        "iteration_budget": iteration_budget,
        "rules": [
            "If repro_run_command is empty, you cannot verify a fix — emit "
            "fixed=false with refinement_notes explaining the gap.",
            "Do NOT modify the repro test file itself to make it pass.",
            "Do NOT commit, push, or run git operations.",
            "Stay inside the workspace; do not touch .devflow/ except "
            "to read prior analysis artifacts.",
        ],
    }


def run_user_report_first_pass_fix(
    *,
    repo_root: Path,
    error_task: dict[str, Any],
    observation: dict[str, Any],
) -> dict[str, Any]:
    """Single fix attempt via pi (medium tier). Returns the
    ErrorSolverWorkflow fix-fn contract:
    ``{"fixed": bool, "fix_results": [...], "verification": {...}}``.

    Pi handles its own iteration within ``_MAX_FIX_ITERATIONS`` per the
    prompt (it can write → run → refine inside one turn). The outer
    DAG handles failover into IterativeFixNode if this returns
    ``fixed=False``.
    """
    # Local import — keeps the module cheap when only the observability
    # path is exercised (tests, smoke).
    from ..llm.invoke import LlmInvocationRequest, invoke_llm

    if not observation:
        return {
            "fixed": False,
            "fix_results": [],
            "verification": {"reason": "no_observation"},
        }

    if not (observation.get("repro_run_command") or "").strip():
        return {
            "fixed": False,
            "fix_results": [],
            "verification": {"reason": "no_repro_command"},
        }

    payload = build_first_pass_fix_payload(
        error_task=error_task, observation=observation,
    )

    try:
        result = invoke_llm(
            LlmInvocationRequest(
                purpose="user_report_first_pass_fix",
                repo_root=repo_root,
                prompt="",
                prompt_payload=payload,
                delivery_model="final_only",
                interaction_model="agentic",
                response_contract="json_only",
                timeout_seconds=_PI_TIMEOUT_SECONDS,
                strength="medium",
            )
        )
    except Exception as exc:  # noqa: BLE001
        logger.warning("first_pass_fix invoke raised: %s", exc)
        return {
            "fixed": False,
            "fix_results": [],
            "verification": {"reason": f"invoke_raised: {type(exc).__name__}: {exc}"},
        }

    if not result.ok:
        return {
            "fixed": False,
            "fix_results": [],
            "verification": {
                "reason": f"llm_not_ok: rc={result.returncode}",
                "stderr": (result.stderr or "")[:500],
            },
        }

    parsed = result.parsed_json
    if not isinstance(parsed, dict):
        return {
            "fixed": False,
            "fix_results": [],
            "verification": {
                "reason": "schema_invalid",
                "raw_stdout": (result.stdout or "")[:500],
            },
        }

    fixed = bool(parsed.get("fixed"))
    return {
        "fixed": fixed,
        "fix_results": [{
            "files_changed": parsed.get("files_changed") or [],
            "iterations_used": parsed.get("iterations_used"),
            "refinement_notes": parsed.get("refinement_notes"),
        }],
        "verification": {
            "repro_run_command": observation.get("repro_run_command"),
            "verification_output": (parsed.get("verification_output") or "")[:3000],
            "passed": fixed,
            # ResolveNode reads `green_gate` as the "did verification
            # succeed" signal — for user_report rows the repro test
            # IS the verification, so this mirrors `passed`. Without
            # this, a passing repro still lands the row at
            # status='in_progress' instead of 'resolved'.
            "green_gate": fixed,
        },
    }


def run_user_report_iterative_fix(
    *,
    repo_root: Path,
    error_task: dict[str, Any],
    observation: dict[str, Any],
) -> dict[str, Any]:
    """Second-line fix attempt when FirstPassFix returns fixed=False.

    Same shape as the first pass but with a "you've already tried once
    and it didn't work" framing, encouraging pi to consider whether the
    analysis itself was wrong (in which case it should flag the
    misanalysis rather than thrash on a wrong-angle fix)."""
    if not observation:
        return {"fixed": False, "attempts": [], "verification": {"reason": "no_observation"}}

    from ..llm.invoke import LlmInvocationRequest, invoke_llm

    payload = build_first_pass_fix_payload(
        error_task=error_task, observation=observation,
        iteration_budget=_MAX_FIX_ITERATIONS,
    )
    payload["task"] = "iterative_fix_user_reported_bug"
    payload["instruction"] = (
        "The first-pass fix attempt for this bug did NOT make the repro "
        "pass. Reconsider before spending more attempts: was the "
        "analysis correct about the root cause? If you think the "
        "likely_location is wrong, say so in refinement_notes and emit "
        "fixed=false with a misanalysis_suspected flag. Otherwise: try "
        "a different angle (different file, different approach). "
        "Re-run repro_run_command after every change. Same tool set "
        "(read/edit/write/bash) and same iteration budget."
    )
    payload["output_contract"] = (
        "Emit ONE final JSON OBJECT with: fixed (bool), files_changed "
        "(list), verification_output (str), iterations_used (int), "
        "refinement_notes (str), misanalysis_suspected (bool — true if "
        "you concluded the observability analysis pointed at the wrong "
        "root cause)."
    )

    try:
        result = invoke_llm(
            LlmInvocationRequest(
                purpose="user_report_iterative_fix",
                repo_root=repo_root,
                prompt="",
                prompt_payload=payload,
                delivery_model="final_only",
                interaction_model="agentic",
                response_contract="json_only",
                timeout_seconds=_PI_TIMEOUT_SECONDS,
                strength="medium",
            )
        )
    except Exception as exc:  # noqa: BLE001
        return {"fixed": False, "attempts": [], "verification": {"reason": f"invoke_raised: {exc}"}}

    if not result.ok or not isinstance(result.parsed_json, dict):
        return {
            "fixed": False, "attempts": [],
            "verification": {
                "reason": "llm_not_ok" if not result.ok else "schema_invalid",
                "rc": result.returncode,
                "stderr": (result.stderr or "")[:500],
            },
        }

    parsed = result.parsed_json
    fixed = bool(parsed.get("fixed"))
    return {
        "fixed": fixed,
        "attempts": [{
            "files_changed": parsed.get("files_changed") or [],
            "iterations_used": parsed.get("iterations_used"),
            "refinement_notes": parsed.get("refinement_notes"),
            "misanalysis_suspected": bool(parsed.get("misanalysis_suspected")),
        }],
        "verification": {
            "repro_run_command": observation.get("repro_run_command"),
            "verification_output": (parsed.get("verification_output") or "")[:3000],
            "passed": fixed,
            "green_gate": fixed,
        },
    }
