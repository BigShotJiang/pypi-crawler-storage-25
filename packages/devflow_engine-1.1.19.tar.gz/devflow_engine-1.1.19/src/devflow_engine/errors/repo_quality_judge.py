"""Repro-quality LLM judge for the error-solver DAG (Track A).

Scores a reproduction artifact along two dimensions BEFORE FirstPassFix runs:

  - behavioral_vs_presence: does the repro assert observable behavior, or
    does it merely check that a symbol exists in the codebase?
  - fails_for_described_reason: does the failure produced by the repro
    match the bug-report symptom described by the user?

Failure mode in the wild: LLM-authored repros that grep for a string
("last_login_at found in User model: True") pass the boolean green-gate
oracle while proving nothing about the actual bug. This judge catches
those cases at intake.

The judge is PURE LLM — no regex / heuristic fallback. Per project rule
(feedback_no_regex_first): never propose regex-first content classification.
The configured medium-tier provider (MiniMax) is the source of truth
(feedback_no_provider_swap_suggestions).
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Literal

from pydantic import BaseModel, Field, ValidationError

from ..llm.invoke import LlmInvocationRequest, invoke_llm

BehavioralVsPresence = Literal["behavioral", "presence", "ambiguous"]
FailsForDescribedReason = Literal["yes", "no", "unclear"]


class RepoQualityJudgment(BaseModel):
    behavioral_vs_presence: BehavioralVsPresence
    fails_for_described_reason: FailsForDescribedReason
    rationale: str = Field(default="")
    judge_ok: bool = Field(default=True)
    judge_error: str | None = Field(default=None)

    def is_healthy(self) -> bool:
        """Both dimensions must be green for the DAG to advance to fix."""
        return (
            self.judge_ok
            and self.behavioral_vs_presence == "behavioral"
            and self.fails_for_described_reason == "yes"
        )


_PROMPT_INSTRUCTIONS = """\
You are auditing a bug reproduction (repro) script before any fix is attempted.

You are given:
  - the user's bug report (title, message, expected_behavior, steps_to_reproduce)
  - the repro artifact: its source code and the path where it was written

Score the repro on TWO dimensions:

1. behavioral_vs_presence  ∈ {behavioral, presence, ambiguous}
   - "behavioral"  → the repro executes the system and asserts on observable
                     behavior (HTTP response, DB row state after an action,
                     function return value, raised exception, log entry).
   - "presence"    → the repro merely checks that a symbol / string / file
                     exists in the codebase. Examples that are "presence":
                       * grep for a field name in a model file
                       * `assert "last_login_at" in open("user.py").read()`
                       * importing a module and asserting an attribute exists
                     These prove nothing about the bug — they pass on the
                     string match even when behavior is still broken.
   - "ambiguous"   → mixed / cannot tell from the artifact alone.

2. fails_for_described_reason ∈ {yes, no, unclear}
   - "yes"     → the failure mode the repro produces, when run against the
                 current code, would manifest as the symptom the user described.
   - "no"      → the repro fails for an unrelated reason (e.g. ImportError,
                 missing fixture, wrong assertion target).
   - "unclear" → cannot determine without running it.

Return STRICT JSON with these exact keys:
{
  "behavioral_vs_presence": "<behavioral|presence|ambiguous>",
  "fails_for_described_reason": "<yes|no|unclear>",
  "rationale": "<one or two sentences citing the specific code patterns you saw>"
}

No prose outside the JSON. No code fences. No additional keys.
"""


def _read_repro_artifact(repo_root: Path, error_task_id: str) -> tuple[str | None, str | None]:
    """Look for the repro artifact in the canonical user-report observability sandbox.

    Returns (path_str, source_text) or (None, None) if absent.
    """
    base = repo_root / ".devflow" / "observability" / error_task_id
    for ext in ("py", "test.ts", "test.tsx"):
        candidate = base / f"repro.{ext}"
        if candidate.exists():
            try:
                return str(candidate), candidate.read_text(encoding="utf-8")
            except OSError:
                return str(candidate), None
    return None, None


def _build_prompt_payload(
    *,
    bug_report: dict[str, Any],
    observation: dict[str, Any] | None,
    repro_path: str | None,
    repro_source: str | None,
) -> dict[str, Any]:
    return {
        "instructions": _PROMPT_INSTRUCTIONS,
        "bug_report": {
            "title": bug_report.get("title"),
            "message": bug_report.get("message"),
            "expected_behavior": bug_report.get("expected_behavior"),
            "steps_to_reproduce": bug_report.get("steps_to_reproduce") or [],
            "report_context": bug_report.get("report_context") or {},
        },
        "observation_summary": {
            "summary": (observation or {}).get("summary"),
            "likely_location": (observation or {}).get("likely_location"),
            "repro_run_command": (observation or {}).get("repro_run_command"),
        },
        "repro_artifact": {
            "path": repro_path,
            "source": repro_source,
        },
    }


def _persist_judgment(
    *,
    repo_root: Path,
    error_task_id: str,
    judgment: RepoQualityJudgment,
) -> Path:
    out_dir = repo_root / ".devflow" / "observability" / error_task_id
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / "repo_quality.json"
    out_path.write_text(
        json.dumps(judgment.model_dump(), indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    return out_path


def judge_repro_quality(
    *,
    repo_root: Path,
    error_task_id: str,
    bug_report: dict[str, Any],
    observation: dict[str, Any] | None = None,
    repro_path: str | None = None,
    repro_source: str | None = None,
) -> RepoQualityJudgment:
    """Run the LLM judge over a repro artifact and persist the judgment.

    Pure LLM — no fallback heuristics. If the LLM call fails or returns
    unparseable JSON, the judgment is marked judge_ok=False and dimensions
    fall back to the safe-stop default (ambiguous / unclear) so the DAG
    holds for human review rather than advancing on weak evidence.
    """
    repo_root = Path(repo_root)
    if repro_path is None and repro_source is None:
        repro_path, repro_source = _read_repro_artifact(repo_root, error_task_id)

    payload = _build_prompt_payload(
        bug_report=bug_report,
        observation=observation,
        repro_path=repro_path,
        repro_source=repro_source,
    )

    request = LlmInvocationRequest(
        purpose="error_solver.repo_quality_judge",
        repo_root=repo_root,
        prompt="",
        prompt_payload=payload,
        strength="medium",
        response_contract="json_only",
        interaction_model="request_response",
        timeout_seconds=180,
    )

    try:
        result = invoke_llm(request)
    except Exception as exc:  # pragma: no cover — surface-level transport failures
        judgment = RepoQualityJudgment(
            behavioral_vs_presence="ambiguous",
            fails_for_described_reason="unclear",
            rationale="judge invocation failed",
            judge_ok=False,
            judge_error=str(exc)[:500],
        )
        _persist_judgment(repo_root=repo_root, error_task_id=error_task_id, judgment=judgment)
        return judgment

    parsed: Any = result.parsed_json
    if parsed is None or not isinstance(parsed, dict):
        judgment = RepoQualityJudgment(
            behavioral_vs_presence="ambiguous",
            fails_for_described_reason="unclear",
            rationale="judge response was not JSON object",
            judge_ok=False,
            judge_error=(result.contract_error or "non-json response")[:500],
        )
        _persist_judgment(repo_root=repo_root, error_task_id=error_task_id, judgment=judgment)
        return judgment

    try:
        judgment = RepoQualityJudgment(
            behavioral_vs_presence=parsed.get("behavioral_vs_presence"),
            fails_for_described_reason=parsed.get("fails_for_described_reason"),
            rationale=str(parsed.get("rationale") or ""),
            judge_ok=True,
            judge_error=None,
        )
    except ValidationError as exc:
        judgment = RepoQualityJudgment(
            behavioral_vs_presence="ambiguous",
            fails_for_described_reason="unclear",
            rationale="judge response failed schema validation",
            judge_ok=False,
            judge_error=str(exc)[:500],
        )

    _persist_judgment(repo_root=repo_root, error_task_id=error_task_id, judgment=judgment)
    return judgment


def build_default_repo_quality_judge_fn(
    *,
    repo_root: Path,
    error_task_id: str,
) -> "callable":
    """Factory that closes over repo_root/etid so callers can pass a single
    (context) → judgment function into the error-solver runtime."""

    def _fn(context: dict[str, Any]) -> dict[str, Any]:
        runtime_context = context.get("runtimeContext") if isinstance(context.get("runtimeContext"), dict) else {}
        user_report = runtime_context.get("user_report") if isinstance(runtime_context.get("user_report"), dict) else {}
        observability = context.get("BuildObservability") if isinstance(context.get("BuildObservability"), dict) else {}
        out = observability.get("output") if isinstance(observability.get("output"), dict) else {}
        observation = out.get("observation") if isinstance(out.get("observation"), dict) else None
        judgment = judge_repro_quality(
            repo_root=repo_root,
            error_task_id=error_task_id,
            bug_report=user_report,
            observation=observation,
        )
        return judgment.model_dump()

    return _fn
