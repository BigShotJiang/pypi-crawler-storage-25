"""Runtime observability bundle builder for the error-solver DAG."""
from __future__ import annotations

import subprocess
from pathlib import Path
from typing import Any


def build_runtime_observability(
    *,
    repo_root: Path,
    runtime_context: dict[str, Any] | None = None,
    repro_command: str | None = None,
    project_id: str | None = None,
    store: Any = None,
    error_task_id: str | None = None,
) -> dict[str, Any]:
    """Gather observable runtime context for the error-solver DAG.

    Returns a structured evidence bundle that the error-solver DAG passes to
    its build_observability_fn hook so diagnose/fix nodes have environment
    context (git status, recent logs, runtime_context payload, etc.).
    """
    git_status: str = ""
    git_log: str = ""
    try:
        r = subprocess.run(["git", "status", "--short"], cwd=str(repo_root), capture_output=True, text=True, check=False)
        git_status = r.stdout.strip()
    except Exception:
        pass
    try:
        r = subprocess.run(["git", "log", "--oneline", "-10"], cwd=str(repo_root), capture_output=True, text=True, check=False)
        git_log = r.stdout.strip()
    except Exception:
        pass

    return {
        "artifactVersion": "runtime_evidence_bundle/v1",
        "observable": True,
        "repo_root": str(repo_root),
        "project_id": project_id,
        "error_task_id": error_task_id,
        "runtime_context": runtime_context or {},
        "repro_command": repro_command,
        "git_status": git_status,
        "git_log": git_log,
    }


def collect_runtime_evidence_bundle(
    *,
    repo_root: Path,
    runtime_context: dict[str, Any] | None = None,
    repro_command: str | None = None,
    project_id: str | None = None,
    store: Any = None,
    error_task_id: str | None = None,
) -> dict[str, Any]:
    """Compatibility wrapper for the error-solver DAG import path."""
    return build_runtime_observability(
        repo_root=repo_root,
        runtime_context=runtime_context,
        repro_command=repro_command,
        project_id=project_id,
        store=store,
        error_task_id=error_task_id,
    )


_PHASE1_REQUIRED_KEYS = (
    "summary", "affected_files", "likely_location",
    "repro_tests", "open_questions", "confidence",
)

# Phase 3 may answer some questions previously raised by phase 2;
# 'deferred_questions' replaces phase 1's 'open_questions' for downstream
# consumers. observed/repro_* fields are the actual observation payload.
_FINAL_REQUIRED_KEYS = (
    "summary", "affected_files", "likely_location",
    "repro_tests", "deferred_questions", "confidence",
    "observed", "repro_artifact_path", "repro_run_command", "repro_output",
)


def _looks_like_file_hit(item: Any) -> bool:
    return (
        isinstance(item, dict)
        and isinstance(item.get("path"), str)
        and isinstance(item.get("reason"), str)
    )


def _normalize_user_report_payload(parsed: Any) -> Any:
    """Wrap MiniMax's recurring bare-list-of-file-hits response in the
    expected envelope. Tolerance is visible in the output (low confidence,
    explicit open_question) — nothing is invented."""
    if isinstance(parsed, dict):
        return parsed
    if isinstance(parsed, list) and parsed and all(_looks_like_file_hit(it) for it in parsed):
        return {
            "summary": (
                "Model returned a bare list of affected files without the "
                "response envelope; wrapped client-side. Re-run for a full "
                "analysis."
            ),
            "affected_files": parsed,
            "likely_location": None,
            "repro_tests": [],
            "open_questions": [
                "Model response was a bare list and missed the response "
                "envelope — re-run, or tighten the prompt, to get "
                "summary / likely_location / repro_tests.",
            ],
            "confidence": "low",
        }
    return parsed


def _invoke_pi_phase(
    *,
    repo_root: Path,
    purpose: str,
    prompt_payload: dict[str, Any],
    timeout_seconds: int = 1800,
) -> tuple[Any, dict[str, Any] | None]:
    """Single pi invocation. Returns (parsed_json, error_dict).

    error_dict is None on success; otherwise a {observable: False, reason,
    details} envelope ready to bubble up. parsed_json is the model's final
    JSON output on success."""
    from ..llm.invoke import LlmInvocationRequest, invoke_llm

    try:
        result = invoke_llm(
            LlmInvocationRequest(
                purpose=purpose,
                repo_root=repo_root,
                prompt="",
                prompt_payload=prompt_payload,
                delivery_model="final_only",
                interaction_model="agentic",
                response_contract="json_only",
                timeout_seconds=timeout_seconds,
                strength="medium",
            )
        )
    except Exception as exc:  # noqa: BLE001 — surface as reason
        return None, {
            "observable": False,
            "reason": f"llm_invoke_raised[{purpose}]: {type(exc).__name__}: {exc!s}".splitlines()[0],
        }
    if not result.ok:
        return None, {
            "observable": False,
            "reason": f"llm_not_ok[{purpose}]: rc={result.returncode} stderr={(result.stderr or '')[:300]}",
        }
    parsed = _normalize_user_report_payload(result.parsed_json)
    if parsed is None:
        return None, {
            "observable": False,
            "reason": f"schema_invalid[{purpose}]: no JSON in response",
            "details": {"raw_stdout": (result.stdout or "")[:400]},
        }
    return parsed, None


def _phase1_initial_analysis(
    *,
    repo_root: Path,
    user_report: dict[str, Any],
) -> tuple[dict[str, Any] | None, dict[str, Any] | None]:
    """Pi inspects /workspace and produces a structured analysis."""
    payload = {
        "task": "user_report_observability_phase1_analysis",
        "instruction": (
            "You are diagnosing a user-reported bug in a real codebase. "
            "Your working directory is the project repo — USE YOUR TOOLS "
            "(ls, find, grep, read) to actually locate the relevant code "
            "before answering. Do NOT guess paths or function names. "
            "Workflow: (1) ls / find the area of the codebase the report "
            "names; (2) grep for the symptoms (endpoint name, error "
            "string, component name); (3) read the specific files that "
            "match to confirm the root cause; (4) only then emit the "
            "final JSON. Every entry in affected_files must be a path you "
            "verified exists. likely_location must include a file path "
            "AND the function/line where the bug lives. Every repro_test "
            "must reference a real test file (read the existing test "
            "tree to pick the right home). open_questions should ONLY "
            "contain things you couldn't determine after reading the code "
            "— not things you didn't bother to look up. 'high' confidence "
            "requires named function + verified repro path."
        ),
        "output_contract": (
            "After your investigation, emit ONE final JSON OBJECT with "
            "keys: summary (str), affected_files (list of {path, "
            "reason}), likely_location (str — file path + function/line), "
            "repro_tests (list of {name, file, rationale, language}), "
            "open_questions (list of str), confidence "
            "('low'|'medium'|'high')."
        ),
        "error_report": user_report,
        "workspace_root": str(repo_root),
    }
    parsed, err = _invoke_pi_phase(
        repo_root=repo_root,
        purpose="user_report_observability_phase1",
        prompt_payload=payload,
    )
    if err is not None:
        return None, err
    if not isinstance(parsed, dict):
        return None, {
            "observable": False,
            "reason": f"schema_invalid[phase1]: response is {type(parsed).__name__}, expected object",
        }
    missing = [k for k in _PHASE1_REQUIRED_KEYS if k not in parsed]
    if missing:
        return None, {
            "observable": False,
            "reason": f"schema_invalid[phase1]: missing keys {missing}",
            "details": {"raw_keys": sorted(parsed.keys())},
        }
    return parsed, None


_LOOP_MAX_ITERATIONS = 5


def _loop_observe_and_resolve(
    *,
    repo_root: Path,
    analysis: dict[str, Any],
    error_task_id: str,
) -> tuple[dict[str, Any] | None, dict[str, Any] | None]:
    """Combined gate loop: question-resolution and bug-observation are
    co-equal exit conditions — each iteration may need the other. Pi
    receives the current state + last test result and decides what to do
    next: answer a code-answerable open question, edit/run the repro
    test, or mark a question genuinely runtime-deferred. Exit when both
    gates pass (every question resolved AND observed=true) or after
    _LOOP_MAX_ITERATIONS attempts.

    Why both gates loop together: running the test often reveals concrete
    runtime data that answers a previously-open question; answering a
    question often changes which test (or which angle of the same test)
    is correct. Sequential phases would have to throw the state away
    between rounds — fusing them lets each iteration converge."""
    sandbox = repo_root / ".devflow" / "observability" / error_task_id
    sandbox.mkdir(parents=True, exist_ok=True)
    sandbox_rel = str(sandbox.relative_to(repo_root))

    state: dict[str, Any] = {
        "summary": analysis.get("summary"),
        "affected_files": analysis.get("affected_files") or [],
        "likely_location": analysis.get("likely_location"),
        "repro_tests": analysis.get("repro_tests") or [],
        "confidence": analysis.get("confidence"),
        "open_questions": list(analysis.get("open_questions") or []),
        "deferred_questions": [],
        "answered_questions": [],
        "observed": False,
        "repro_artifact_path": None,
        "repro_run_command": None,
        "repro_output": None,
        "refinement_notes": None,
    }
    iteration_history: list[dict[str, Any]] = []

    for iteration in range(1, _LOOP_MAX_ITERATIONS + 1):
        # Exit condition: both gates pass. Questions gate = no
        # unresolved open questions (every Q has been answered or
        # deferred-as-runtime). Observation gate = observed=true with
        # captured repro evidence.
        questions_resolved = not state["open_questions"]
        observed = bool(state["observed"]) and bool(state["repro_output"])
        if questions_resolved and observed:
            break

        payload = {
            "task": "user_report_observability_combined_gate_loop",
            "instruction": (
                "Two co-equal gates must pass before this analysis is "
                "complete: (A) every open question is either ANSWERED "
                "(from code/tools) or marked DEFERRED (genuinely needs "
                "runtime info you cannot get from static inspection). "
                "(B) the bug is OBSERVED — you wrote a repro test in "
                "the sandbox, ran it, and the captured output matches "
                "the reported failure pattern. The two gates feed each "
                "other: running the test often surfaces concrete data "
                "that answers an open question; answering a question "
                "often changes which test to write or how to run it. "
                "Look at the current state (analysis + open questions + "
                "last test result) and do the SINGLE most useful thing "
                "next: answer a question (with tools), edit or write "
                "the repro test (sandbox path provided), run the test "
                "(bash), or mark a question deferred. After that one "
                "action, evaluate and emit the updated state. You will "
                "be re-invoked with your updated state until BOTH gates "
                "pass — do NOT try to do everything in one pass."
            ),
            "output_contract": (
                "Emit ONE final JSON OBJECT with the FULL updated state. "
                "Keys: summary (str — may revise as you learn), "
                "affected_files (list of {path, reason} — may grow/"
                "shrink), likely_location (str), repro_tests (list of "
                "{name, file, rationale, language}), confidence "
                "('low'|'medium'|'high'), open_questions (list of str "
                "— questions still unresolved this iteration), "
                "answered_questions (cumulative list of {question, "
                "answer, evidence}), deferred_questions (cumulative "
                "list of str — only questions genuinely needing runtime "
                "info), observed (bool — true ONLY if you ran the repro "
                "test and the output matched the reported failure), "
                "repro_artifact_path (str|null — path relative to "
                "workspace, e.g. '.devflow/observability/<id>/repro.py'), "
                "repro_run_command (str|null — the bash command), "
                "repro_output (str|null — captured stdout/stderr of "
                "the last test run, truncated to ~3000 chars), "
                "refinement_notes (str — what you did this iteration "
                "and why)."
            ),
            "current_state": state,
            "iteration": iteration,
            "iteration_budget": _LOOP_MAX_ITERATIONS,
            "iterations_remaining": _LOOP_MAX_ITERATIONS - iteration,
            "sandbox_absolute_path": str(sandbox),
            "sandbox_relative_path": sandbox_rel,
            "workspace_root": str(repo_root),
            "error_report_summary": (
                "(see analysis.summary above for the bug under "
                "investigation; refer back to the user's original report "
                "if you need the exact wording — it should be on disk "
                "via the previous phase but you can also re-read "
                "affected files for context)"
            ),
        }
        parsed, err = _invoke_pi_phase(
            repo_root=repo_root,
            purpose=f"user_report_observability_loop_iter{iteration}",
            prompt_payload=payload,
        )
        iteration_history.append({
            "iteration": iteration,
            "ok": err is None,
            "error": err.get("reason") if err else None,
            "notes": parsed.get("refinement_notes") if isinstance(parsed, dict) else None,
        })
        if err is not None:
            # Loop invoke failure mid-iteration — keep the state we have
            # and stop. Caller will surface as observation_inconclusive
            # if state has at least an analysis.
            state["refinement_notes"] = (
                f"loop aborted at iteration {iteration}: {err.get('reason')}"
            )
            break
        if not isinstance(parsed, dict):
            state["refinement_notes"] = (
                f"loop aborted at iteration {iteration}: response was "
                f"{type(parsed).__name__}, expected object"
            )
            break
        # Merge: trust pi's full state echo. Only enforce the cumulative
        # nature of answered_questions / deferred_questions defensively.
        prev_answered = state.get("answered_questions") or []
        prev_deferred = state.get("deferred_questions") or []
        for k in ("summary", "affected_files", "likely_location", "repro_tests",
                  "confidence", "open_questions", "answered_questions",
                  "deferred_questions", "observed", "repro_artifact_path",
                  "repro_run_command", "repro_output", "refinement_notes"):
            if k in parsed:
                state[k] = parsed[k]
        # Defensive: never let the model shrink the cumulative lists.
        merged_answered = list(prev_answered)
        for item in (state.get("answered_questions") or []):
            if item not in merged_answered:
                merged_answered.append(item)
        merged_deferred = list(prev_deferred)
        for item in (state.get("deferred_questions") or []):
            if item not in merged_deferred:
                merged_deferred.append(item)
        state["answered_questions"] = merged_answered
        state["deferred_questions"] = merged_deferred

    state["_loop_iterations_used"] = len(iteration_history)
    state["_loop_history"] = iteration_history
    # Empty out open_questions on exit if the loop ran to budget — any
    # still-unresolved questions become deferred (the loop is over;
    # they're now runtime-or-later questions by default).
    if state.get("open_questions"):
        remaining = state.pop("open_questions")
        for q in remaining:
            if q not in state["deferred_questions"]:
                state["deferred_questions"].append(q)
    else:
        state.pop("open_questions", None)
    return state, None


def build_user_report_observability(
    *,
    repo_root: Path,
    runtime_context: dict[str, Any] | None,
) -> dict[str, Any]:
    """Observability for source_kind='user_report' rows.

    Phase 1 — initial analysis: pi inspects the codebase and emits a
    structured hypothesis (summary, affected files, likely location,
    proposed repro tests, open questions, confidence).

    Phase 2 — combined gate loop: pi iterates on TWO co-equal exit
    conditions, doing the single most useful action per iteration:
    answer a code-answerable open question, edit/write/run the repro
    test, or mark a question genuinely runtime-deferred. The two
    gates feed each other — running the test surfaces concrete data
    that answers questions; answering questions changes which test
    angle is right. Both must pass to exit:
      (A) every open question is answered or deferred-as-runtime
      (B) observed=true with captured repro evidence
    Cap: 5 iterations. If exhausted, remaining questions become
    deferred and observed may stay false (→ observation_inconclusive
    status on the row).

    Returns:
    - ``{observable: True, observation: <dict>, details: {...}}`` when
      phase 1 succeeds (loop may exit with observed=false; that's still
      observable — just inconclusive).
    - ``{observable: False, reason: <str>, details: {...}}`` on phase
      1 invoke/schema failure.

    Both worker.py (queue-driven processing) and cli/app.py
    (`devflow error solve-runtime`) inject this for user_report rows.
    """
    runtime_ctx = runtime_context or {}
    ur = runtime_ctx.get("user_report") if isinstance(runtime_ctx.get("user_report"), dict) else {}
    error_task_id = str(runtime_ctx.get("error_task_id") or "unknown")

    user_report = {
        "title": ur.get("title"),
        "message": ur.get("message"),
        "expected_behavior": ur.get("expected_behavior"),
        "steps_to_reproduce": ur.get("steps_to_reproduce") or [],
        "report_context": ur.get("report_context") or {},
    }

    # Phase 1 — initial analysis. A hard failure here aborts; we can't
    # loop without a hypothesis to refine.
    analysis, err = _phase1_initial_analysis(repo_root=repo_root, user_report=user_report)
    if err is not None:
        err.setdefault("details", {})["runtimeContext"] = runtime_ctx
        return err
    assert analysis is not None

    # Phase 2 — combined gate loop. Non-fatal: if it errors mid-loop,
    # we still have phase 1's analysis to surface.
    looped, _ = _loop_observe_and_resolve(
        repo_root=repo_root, analysis=analysis, error_task_id=error_task_id,
    )
    assert looped is not None

    final = {
        "summary": looped.get("summary"),
        "affected_files": looped.get("affected_files"),
        "likely_location": looped.get("likely_location"),
        "repro_tests": looped.get("repro_tests"),
        "confidence": looped.get("confidence"),
        "answered_questions": looped.get("answered_questions") or [],
        "deferred_questions": looped.get("deferred_questions") or [],
        "observed": bool(looped.get("observed")),
        "repro_artifact_path": looped.get("repro_artifact_path"),
        "repro_run_command": looped.get("repro_run_command"),
        "repro_output": looped.get("repro_output"),
        "refinement_notes": looped.get("refinement_notes"),
        "loop_iterations_used": looped.get("_loop_iterations_used"),
        "loop_history": looped.get("_loop_history"),
    }

    return {
        "observable": True,
        "observation": final,
        "details": {"runtimeContext": runtime_ctx},
    }
