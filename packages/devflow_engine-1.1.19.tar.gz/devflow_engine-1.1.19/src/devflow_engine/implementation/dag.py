from __future__ import annotations

import asyncio
import ast
import json
import os
import re
import shutil
import sqlite3
import subprocess
import sys
import time
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

from pydantic import BaseModel
import tomllib

from ..agentic_prompts import load_agentic_prompt_lines
from ..stores.execution_store import ExecutionStore
from ..devflow_state import publish_devflow_state
from ..implementation.green_gate import GateResult, run_green_gate
from ..implementation.test_runtime import (
    discover_story_scoped_test_paths,
    infer_test_runtime_contract,
    normalize_story_runtime_contract,
    persist_story_runtime_contract,
    resolve_story_runtime_contract,
    runtime_contract_cwd,
    runtime_contract_env,
    runtime_contract_test_args,
    story_test_runtime_contract_path,
)
from ..implementation.alembic_preflight import run_alembic_preflight
from ..implementation.prompts import (
    load_implementation_node_instruction,
    load_implementation_review_guidance,
    load_implementation_review_instruction,
    load_implementation_stage_guidance,
    load_implementation_stage_instruction,
)
from ..llm.execution_context import execution_context, get_execution_context
from ..llm.cli_stream import run_streaming
from ..llm.invoke import _parse_tiers, _tier_config
from ..idea.traditional_stories import _global_devflow_dir, _read_toml
from ..agentic_runtime import AgentRunEnvelope, normalize_llm_cli_base, run_agent_step, _shrink_for_prompt, _resolve_strength_model, _apply_model_flag
from ..registry.packages import refresh_policy
from ..story.evidence import record_story_verification
from ..vendor.datalumina_genai.core.nodes.base import Node
from ..vendor.datalumina_genai.core.nodes.agent import AgentConfig, AgentNode
from ..vendor.datalumina_genai.core.nodes.router import BaseRouter, RouterNode
from ..vendor.datalumina_genai.core.schema import NodeConfig, WorkflowSchema
from ..vendor.datalumina_genai.core.task import TaskContext
from ..vendor.datalumina_genai.core.workflow import Workflow
from ..story.markdown_contracts import ALLOWED_PLANES


@dataclass(frozen=True)
class Stage:
    node_id: str
    name: str
    deps: list[str]


@dataclass(frozen=True)
class ImplementationDagResult:
    exit_code: int
    message: str
    run_id: str
    failed_stage: str | None = None
    failure_context: dict[str, Any] | None = None


def default_implementation_stages() -> list[Stage]:
    """Canonical Area 6 implementation DAG stages.

    IDs are stable and intentionally match the story contracts/tests.
    """

    return [
        Stage("normalize", "Normalize", []),
        Stage("setupdoc", "SetupDoc", ["normalize"]),
        Stage("preflight", "Preflight", ["setupdoc"]),
        Stage("dependencyassessment", "DependencyAssessment", ["preflight"]),
        Stage("storyimplementationplanning", "StoryImplementationPlanning", ["dependencyassessment"]),
        Stage("testdesign", "TestDesign", ["storyimplementationplanning"]),
        Stage("red", "Red", ["testdesign"]),
        Stage("redreview", "RedReview", ["red"]),
        Stage("storysufficiencyreconciliation", "StorySufficiencyReconciliation", ["redreview"]),
        Stage("green", "Green", ["storysufficiencyreconciliation"]),
        Stage("refactor", "Refactor", ["green"]),
        Stage("security", "Security", ["refactor"]),
        Stage("gitcommit(refactor)", "GitCommit(REFACTOR)", ["security"]),
    ]


def render_stage_plan(stages: list[Stage]) -> str:
    lines: list[str] = []
    for s in stages:
        deps = ",".join(s.deps) if s.deps else "-"
        lines.append(f"{s.node_id}  ({s.name})  deps=[{deps}]")
    return "\n".join(lines) + "\n"


def _resolve_devflow_cmd(repo_root: Path) -> list[str]:
    found = shutil.which("devflow")
    if found:
        return [found]
    candidates = [
        repo_root / ".venv" / "bin" / "devflow",
        Path(sys.executable).parent / "devflow",
        Path(__file__).resolve().parents[3] / ".venv" / "bin" / "devflow",
    ]
    for candidate in candidates:
        if candidate.exists():
            return [str(candidate)]
    return ["devflow"]


def _run_cmd(repo_root: Path, cmd: list[str], *, env: dict[str, str] | None = None) -> subprocess.CompletedProcess[str]:
    if cmd and cmd[0] == "devflow":
        cmd = [*_resolve_devflow_cmd(repo_root), *cmd[1:]]
    return subprocess.run(cmd, cwd=str(repo_root), text=True, capture_output=True, check=False, env=env)


def _run_cmd_in_dir(
    repo_root: Path,
    cmd: list[str],
    *,
    cwd: Path,
    env: dict[str, str] | None = None,
) -> subprocess.CompletedProcess[str]:
    if cwd == repo_root:
        return _run_cmd(repo_root, cmd, env=env)
    if cmd and cmd[0] == "devflow":
        cmd = [*_resolve_devflow_cmd(repo_root), *cmd[1:]]
    return subprocess.run(cmd, cwd=str(cwd), text=True, capture_output=True, check=False, env=env)


_MAX_PRIOR_PASS_OUTPUT_CHARS = 50_000


def _truncate_output(text: str, *, label: str = "output", limit: int = _MAX_PRIOR_PASS_OUTPUT_CHARS) -> str:
    """Truncate subprocess output to *limit* chars for inclusion in agent prompts."""
    if not text or len(text) <= limit:
        return text
    half = limit // 2
    omitted = len(text) - limit
    return (
        text[:half]
        + f"\n\n... [{omitted:,} chars of {label} truncated] ...\n\n"
        + text[-half:]
    )


def _journal_env(*, repo_root: Path, run_id: str, node_exec_id: str | None, story: dict[str, Any], dag_id: str = "implementation_dag", implementation_planning_path: str | None = None) -> dict[str, str]:
    env = dict(os.environ)
    story_ctx = _story_context(story)
    env.update(
        {
            "DEVFLOW_RUN_ID": run_id,
            "DEVFLOW_DAG_ID": dag_id,
            "DEVFLOW_REPO_ROOT": str(repo_root),
        }
    )
    if node_exec_id:
        env["DEVFLOW_NODE_EXEC_ID"] = node_exec_id
    if story_ctx.get("story_id"):
        env["DEVFLOW_STORY_ID"] = str(story_ctx["story_id"])
    if story_ctx.get("story_uuid"):
        env["DEVFLOW_STORY_UUID"] = str(story_ctx["story_uuid"])
    if story_ctx.get("story_title"):
        env["DEVFLOW_STORY_TITLE"] = str(story_ctx["story_title"])
    if implementation_planning_path:
        env["DEVFLOW_IMPLEMENTATION_PLANNING_PATH"] = implementation_planning_path
    return env


class ImplementationEvent(BaseModel):
    repo_root: str
    story: dict[str, Any]


class DependencyAssessmentDecision(BaseModel):
    assessment_status: str
    summary: str
    internal_dependencies: list[dict[str, Any]] = []
    external_dependencies: list[dict[str, Any]] = []
    unresolved_internal_dependencies: list[dict[str, Any]] = []
    blocked_external_dependencies: list[dict[str, Any]] = []
    inferred_capabilities: list[str] = []
    preferred_pathways: list[dict[str, Any]] = []
    blocking_issues: list[dict[str, Any]] = []
    downstream_contract: dict[str, Any] = {}


class StoryImplementationPlanningDecision(BaseModel):
    planning_status: str
    summary: str
    inferred_capabilities: list[str] = []
    internal_findings: list[dict[str, Any]] = []
    external_findings: list[dict[str, Any]] = []
    preferred_pathways: list[dict[str, Any]] = []
    queue_after_story_id: str | None = None
    prerequisite_story_request: dict[str, Any] | None = None
    blocker: dict[str, Any] | None = None
    blocking_issues: list[dict[str, Any]] = []
    downstream_contract: dict[str, Any] = {}


class HealthCheckEntry(BaseModel):
    name: str
    url: str
    expected_status: int = 200


class MigrationConfig(BaseModel):
    command: str
    check_command: str


class EnvRequirement(BaseModel):
    path: str
    required: bool


class GitConfig(BaseModel):
    require_clean: bool


class HealthFailRepairConfig(BaseModel):
    """Repair recipe triggered when health check failure logs match a pattern."""
    patterns: list[str]  # regex patterns to match against service logs
    repair_command: str  # shell command to repair (e.g. "docker compose build backend")
    volume_reset: list[str] = []  # Docker volume names to remove before repair
    max_repair_attempts: int = 1


class LocalSetupContract(BaseModel):
    schema_version: int
    health_checks: list[HealthCheckEntry]
    start_command: str
    stop_command: str
    migration: MigrationConfig | None = None
    env_requirements: list[EnvRequirement] = []
    git: GitConfig | None = None
    dependency_manager: str | None = None  # e.g. "uv", "pip", "npm" — informational
    on_health_fail_repair: HealthFailRepairConfig | None = None


class TestDesignBundle(BaseModel):
    bundle_id: str
    planes: list[str] = []
    runtime_family: str = "default"
    runtime_contract: dict[str, Any] = {}
    file_targets: list[str] = []
    must_cover: list[str] = []
    must_avoid: list[str] = []
    test_cases: list[dict[str, Any]] = []


class TestDesignArtifact(BaseModel):
    summary: str
    test_cases: list[dict[str, Any]] = []
    bundles: list[TestDesignBundle] = []
    design_notes: list[str] = []
    story_scoping_notes: list[str] = []
    must_cover: list[str] = []
    must_avoid: list[str] = []


class StoryVerificationBundle(BaseModel):
    bundle_id: str
    planes: list[str] = []
    runtime_family: str = "default"
    runtime_contract: dict[str, Any] = {}
    runtime_contract_path: str | None = None
    file_targets: list[str] = []
    must_cover: list[str] = []
    must_avoid: list[str] = []
    test_cases: list[dict[str, Any]] = []
    registered_files: list[dict[str, Any]] = []
    test_paths: list[str] = []
    red_generation: dict[str, Any] = {}
    redreview: dict[str, Any] = {}


class StoryVerificationReconciliationArtifact(BaseModel):
    schema_version: int = 1
    story_id: str | None = None
    story_uuid: str | None = None
    summary: str
    bundle_count: int
    story_test_cases: list[dict[str, Any]] = []
    story_must_cover: list[str] = []
    story_must_avoid: list[str] = []
    bundles: list[StoryVerificationBundle] = []


class RedTestFile(BaseModel):
    path: str
    content: str
    rationale: str = ""


class RedTestGenerationArtifact(BaseModel):
    summary: str
    files: list[RedTestFile]
    notes: list[str] = []


class RedReviewFileDecision(BaseModel):
    path: str
    covered_planes: list[str]
    register_for_validation: bool
    rationale: str = ""


class RedReviewArtifact(BaseModel):
    summary: str
    files: list[RedReviewFileDecision]
    notes: list[str] = []


def _implementation_pipeline_root(*, repo_root: Path, story_id: str) -> Path:
    safe_story_id = re.sub(r"[^A-Za-z0-9_.-]+", "_", story_id) or "unknown_story"
    return _story_state_root(repo_root=repo_root) / safe_story_id


def _story_state_root(*, repo_root: Path) -> Path:
    ctx = get_execution_context() or {}
    override = str(ctx.get("devflow_story_state_root") or "").strip()
    if override:
        return Path(override)
    return repo_root / ".devflow" / "stories"


def _devflow_publish_enabled() -> bool:
    ctx = get_execution_context() or {}
    return not bool(ctx.get("devflow_isolated_harness"))


def _persist_implementation_agent_run(*, pipeline_root: Path, node_id: str, envelope: AgentRunEnvelope) -> Path:
    path = pipeline_root / "agent_runs" / f"{node_id}.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(envelope.model_dump(), indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return path


def _dependency_assessment_timeout_seconds() -> int:
    raw = os.environ.get("DEVFLOW_DEPENDENCY_ASSESSMENT_AGENT_TIMEOUT")
    if not raw:
        return 900
    try:
        value = int(raw)
    except ValueError:
        return 900
    return value if value > 0 else 900


def _implementation_planning_timeout_seconds() -> int:
    raw = os.environ.get("DEVFLOW_IMPLEMENTATION_PLANNING_AGENT_TIMEOUT")
    if not raw:
        return 1800
    try:
        value = int(raw)
    except ValueError:
        return 1800
    return value if value > 0 else 1800


def _test_design_timeout_seconds() -> int:
    raw = os.environ.get("DEVFLOW_TEST_DESIGN_AGENT_TIMEOUT")
    if not raw:
        return 900
    try:
        value = int(raw)
    except ValueError:
        return 900
    return value if value > 0 else 900


def _build_test_cases(story: dict[str, Any]) -> list[dict[str, Any]]:
    contract = story.get("contract") or {}
    plane_oracles = contract.get("plane_oracles") or []
    test_cases: list[dict[str, Any]] = []
    for po in plane_oracles:
        if not isinstance(po, dict):
            continue
        test_cases.append(
            {
                "title": f"{po.get('plane', 'unknown')} oracle",
                "oracle": str(po.get("oracle") or "").strip(),
                "anchor": str(po.get("anchor") or "").strip(),
                "plane": po.get("plane"),
            }
        )

    if not test_cases:
        test_cases = [
            {
                "title": "default test case",
                "oracle": "Non-empty oracle",
                "anchor": "Non-empty anchor",
                "plane": "api",
            }
        ]
    return test_cases


def _dedupe_strings(values: list[Any]) -> list[str]:
    seen: set[str] = set()
    ordered: list[str] = []
    for value in values:
        text = str(value or "").strip()
        if not text or text in seen:
            continue
        seen.add(text)
        ordered.append(text)
    return ordered


def _safe_bundle_id(bundle_id: str | None, *, fallback: str = "default") -> str:
    value = re.sub(r"[^A-Za-z0-9_.-]+", "_", str(bundle_id or "").strip())
    return value or fallback


def _runtime_family_from_contract(runtime_contract: dict[str, Any]) -> str:
    framework = str(runtime_contract.get("framework") or "").strip().lower()
    if framework == "vitest":
        return "frontend"
    if framework == "pytest":
        return "backend"
    return framework or "default"


def _bundle_planes_from_cases(test_cases: list[dict[str, Any]]) -> list[str]:
    return _dedupe_strings([case.get("plane") for case in test_cases if isinstance(case, dict)])


def _bundle_runtime_contract_path(*, repo_root: Path, story_id: str, bundle_id: str) -> Path:
    safe_story_id = re.sub(r"[^A-Za-z0-9_.-]+", "_", story_id) or "unknown_story"
    safe_bundle = _safe_bundle_id(bundle_id, fallback="default")
    return _story_state_root(repo_root=repo_root) / safe_story_id / "runtime_bundles" / f"{safe_bundle}.json"


def _select_bundle_test_cases(*, bundle_planes: list[str], candidate_cases: list[dict[str, Any]]) -> list[dict[str, Any]]:
    if not bundle_planes:
        return [dict(case) for case in candidate_cases if isinstance(case, dict)]
    selected = [
        dict(case)
        for case in candidate_cases
        if isinstance(case, dict) and str(case.get("plane") or "").strip() in bundle_planes
    ]
    return selected or [dict(case) for case in candidate_cases if isinstance(case, dict)]


def _normalize_test_design_bundles(*, repo_root: Path, story: dict[str, Any], artifact: TestDesignArtifact) -> list[dict[str, Any]]:
    base_runtime_contract = _resolve_story_test_runtime_contract(repo_root=repo_root, story=story)
    story_contract = dict(story.get("contract") or {})
    base_cases = [dict(case) for case in (artifact.test_cases or _build_test_cases(story)) if isinstance(case, dict)]
    raw_bundles = list(artifact.bundles or [])
    normalized: list[dict[str, Any]] = []

    if not raw_bundles:
        runtime_family = _runtime_family_from_contract(base_runtime_contract)
        normalized.append(
            TestDesignBundle(
                bundle_id="default",
                planes=_bundle_planes_from_cases(base_cases) or _dedupe_strings(story_contract.get("required_planes") or []),
                runtime_family=runtime_family,
                runtime_contract={},
                file_targets=[],
                must_cover=_dedupe_strings(list(artifact.must_cover or [])),
                must_avoid=_dedupe_strings(list(artifact.must_avoid or [])),
                test_cases=base_cases,
            ).model_dump()
        )
        return normalized

    seen_bundle_ids: set[str] = set()
    for index, raw_bundle in enumerate(raw_bundles, start=1):
        bundle = raw_bundle if isinstance(raw_bundle, TestDesignBundle) else TestDesignBundle.model_validate(raw_bundle)
        bundle_id = _safe_bundle_id(bundle.bundle_id, fallback=f"bundle_{index:02d}")
        if bundle_id in seen_bundle_ids:
            bundle_id = _safe_bundle_id(f"{bundle_id}_{index}", fallback=f"bundle_{index:02d}")
        seen_bundle_ids.add(bundle_id)
        bundle_test_cases = [dict(case) for case in bundle.test_cases if isinstance(case, dict)]
        if not bundle_test_cases:
            bundle_test_cases = _select_bundle_test_cases(bundle_planes=list(bundle.planes or []), candidate_cases=base_cases)
        normalized.append(
            TestDesignBundle(
                bundle_id=bundle_id,
                planes=_dedupe_strings(list(bundle.planes or []) or _bundle_planes_from_cases(bundle_test_cases) or story_contract.get("required_planes") or []),
                runtime_family=str(bundle.runtime_family or _runtime_family_from_contract(bundle.runtime_contract or base_runtime_contract) or "default").strip() or "default",
                runtime_contract=dict(bundle.runtime_contract or {}),
                file_targets=_dedupe_strings(list(bundle.file_targets or [])),
                must_cover=_dedupe_strings(list(bundle.must_cover or artifact.must_cover or [])),
                must_avoid=_dedupe_strings(list(bundle.must_avoid or artifact.must_avoid or [])),
                test_cases=bundle_test_cases,
            ).model_dump()
        )
    return normalized


def _flatten_bundle_test_cases(bundles: list[dict[str, Any]]) -> list[dict[str, Any]]:
    flattened: list[dict[str, Any]] = []
    seen: set[str] = set()
    for bundle in bundles:
        for case in bundle.get("test_cases") or []:
            if not isinstance(case, dict):
                continue
            key = json.dumps(case, sort_keys=True)
            if key in seen:
                continue
            seen.add(key)
            flattened.append(dict(case))
    return flattened


def _load_bundle_runtime_contract(
    *,
    repo_root: Path,
    story: dict[str, Any],
    bundle_id: str,
    fallback: dict[str, Any],
) -> dict[str, Any] | None:
    story_ctx = _story_context(story)
    story_id = str(story_ctx.get("story_id") or "").strip()
    if not story_id:
        return None
    path = _bundle_runtime_contract_path(repo_root=repo_root, story_id=story_id, bundle_id=bundle_id)
    if not path.exists() or not path.is_file():
        return None
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None
    if not isinstance(payload, dict):
        return None
    return normalize_story_runtime_contract(
        repo_root=repo_root,
        contract=payload,
        story_id=story_id,
        story_uuid=str(payload.get("story_uuid") or story_ctx.get("story_uuid") or "").strip() or None,
        source=str(payload.get("source") or f"bundle:{bundle_id}"),
        fallback=fallback,
    )


def _persisted_bundle_runtime_ids(*, repo_root: Path, story: dict[str, Any]) -> list[str]:
    story_ctx = _story_context(story)
    story_id = str(story_ctx.get("story_id") or "").strip()
    if not story_id:
        return []
    runtime_dir = _bundle_runtime_contract_path(repo_root=repo_root, story_id=story_id, bundle_id="default").parent
    if not runtime_dir.exists() or not runtime_dir.is_dir():
        return []
    bundle_ids: list[str] = []
    for path in sorted(runtime_dir.glob("*.json")):
        bundle_id = str(path.stem or "").strip()
        if bundle_id:
            bundle_ids.append(bundle_id)
    return bundle_ids


def _preserve_rip_to_green_bundle_identity(
    *,
    repo_root: Path,
    story: dict[str, Any],
    test_design: dict[str, Any],
    bundle: dict[str, Any],
) -> dict[str, Any]:
    preserved = dict(bundle)
    explicit_bundles = [dict(item) for item in (test_design.get("bundles") or []) if isinstance(item, dict)]
    if explicit_bundles:
        return preserved
    bundle_id = str(preserved.get("bundle_id") or "default").strip() or "default"
    if bundle_id != "default":
        return preserved
    persisted_bundle_ids = [item for item in _persisted_bundle_runtime_ids(repo_root=repo_root, story=story) if item != "default"]
    if len(persisted_bundle_ids) != 1:
        return preserved
    preserved["bundle_id"] = persisted_bundle_ids[0]
    return preserved


def _resolve_rip_to_green_bundle_test_paths(
    *,
    repo_root: Path,
    story: dict[str, Any],
    bundle: dict[str, Any],
) -> list[str]:
    bundle_runtime_contract = _resolve_bundle_runtime_contract(
        repo_root=repo_root,
        story=story,
        bundle=bundle,
        test_paths=None,
    )
    bundle_test_paths = [
        str(path)
        for path in (bundle_runtime_contract.get("test_paths") or [])
        if str(path).strip()
    ]
    if bundle_test_paths:
        return bundle_test_paths

    story_runtime_contract = _resolve_story_test_runtime_contract(
        repo_root=repo_root,
        story=story,
    )
    bundle_test_paths = [
        str(path)
        for path in (story_runtime_contract.get("test_paths") or [])
        if str(path).strip()
    ]
    if bundle_test_paths:
        return bundle_test_paths

    discovered = _discover_story_scoped_test_paths(repo_root=repo_root, story=story)
    if len(discovered) <= 1:
        return discovered

    bundle_planes = [str(plane) for plane in (bundle.get("planes") or []) if str(plane) in ALLOWED_PLANES]
    if not bundle_planes:
        return discovered

    plane_pattern = re.compile(r"pytest\.mark\.plane\((['\"])([^'\"]+)\1\)")
    filtered: list[str] = []
    for file_path in discovered:
        try:
            content = (repo_root / file_path).read_text(encoding="utf-8")
        except Exception:
            continue
        marked_planes = {
            str(match.group(2)).strip()
            for match in plane_pattern.finditer(content)
            if str(match.group(2)).strip() in ALLOWED_PLANES
        }
        if marked_planes.intersection(bundle_planes):
            filtered.append(file_path)
    return filtered or discovered


def _resolve_bundle_runtime_contract(
    *,
    repo_root: Path,
    story: dict[str, Any],
    bundle: dict[str, Any],
    test_paths: list[str] | None = None,
) -> dict[str, Any]:
    story_ctx = _story_context(story)
    base_contract = _resolve_story_test_runtime_contract(
        repo_root=repo_root,
        story=story,
        test_paths=test_paths,
    )
    bundle_id = str(bundle.get("bundle_id") or "default").strip() or "default"
    persisted_bundle_contract = _load_bundle_runtime_contract(
        repo_root=repo_root,
        story=story,
        bundle_id=bundle_id,
        fallback=base_contract,
    )
    if persisted_bundle_contract is not None:
        resolved = persisted_bundle_contract
    else:
        bundle_contract = dict(bundle.get("runtime_contract") or {})
        if not bundle_contract:
            resolved = dict(base_contract)
        else:
            resolved = normalize_story_runtime_contract(
                repo_root=repo_root,
                contract=bundle_contract,
                story_id=str(story_ctx.get("story_id") or ""),
                story_uuid=str(story_ctx.get("story_uuid") or "") or None,
                source=str(bundle_contract.get("source") or f"bundle:{bundle_id}"),
                fallback=base_contract,
            )
    if test_paths is not None:
        resolved["test_paths"] = [str(path) for path in test_paths if str(path).strip()]
    return resolved


def _persist_bundle_runtime_contract(
    *,
    repo_root: Path,
    story: dict[str, Any],
    bundle: dict[str, Any],
    test_paths: list[str] | None = None,
    source: str | None = None,
) -> tuple[dict[str, Any], Path | None]:
    story_ctx = _story_context(story)
    story_id = str(story_ctx.get("story_id") or "").strip()
    if not story_id:
        return _resolve_bundle_runtime_contract(repo_root=repo_root, story=story, bundle=bundle, test_paths=test_paths), None
    contract = _resolve_bundle_runtime_contract(repo_root=repo_root, story=story, bundle=bundle, test_paths=test_paths)
    if source:
        contract = dict(contract)
        contract["source"] = source
    path = _bundle_runtime_contract_path(repo_root=repo_root, story_id=story_id, bundle_id=str(bundle.get("bundle_id") or "default"))
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(contract, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return contract, path


def _persist_test_design_bundle_runtime_contracts(
    *,
    repo_root: Path,
    story: dict[str, Any],
    test_design: dict[str, Any],
) -> list[dict[str, Any]]:
    persisted: list[dict[str, Any]] = []
    for bundle in _test_design_bundles(repo_root=repo_root, story=story, test_design=test_design):
        contract, path = _persist_bundle_runtime_contract(
            repo_root=repo_root,
            story=story,
            bundle=bundle,
        )
        persisted.append(
            {
                "bundle_id": str(bundle.get("bundle_id") or "default"),
                "runtime_contract": contract,
                "runtime_contract_path": None if path is None else str(path),
            }
        )
    return persisted


def _test_design_bundles(*, repo_root: Path, story: dict[str, Any], test_design: dict[str, Any]) -> list[dict[str, Any]]:
    bundles = [dict(bundle) for bundle in (test_design.get("bundles") or []) if isinstance(bundle, dict)]
    if bundles:
        return bundles
    artifact = TestDesignArtifact(
        summary=str(test_design.get("summary") or "normalized bundle view"),
        test_cases=[dict(case) for case in (test_design.get("test_cases") or []) if isinstance(case, dict)],
        design_notes=[str(item) for item in (test_design.get("design_notes") or []) if str(item).strip()],
        story_scoping_notes=[str(item) for item in (test_design.get("story_scoping_notes") or []) if str(item).strip()],
        must_cover=[str(item) for item in (test_design.get("must_cover") or []) if str(item).strip()],
        must_avoid=[str(item) for item in (test_design.get("must_avoid") or []) if str(item).strip()],
    )
    normalized = _normalize_test_design_bundles(repo_root=repo_root, story=story, artifact=artifact)
    if len(normalized) == 1:
        normalized[0] = _preserve_rip_to_green_bundle_identity(
            repo_root=repo_root,
            story=story,
            test_design=test_design,
            bundle=normalized[0],
        )
    return normalized


_CURRENT_STORE: ExecutionStore | None = None
_CURRENT_RUN_ID: str | None = None


def _store_run() -> tuple[ExecutionStore, str]:
    if _CURRENT_STORE is None or _CURRENT_RUN_ID is None:
        raise RuntimeError("implementation workflow missing runtime store/run_id")
    return _CURRENT_STORE, _CURRENT_RUN_ID


def _story_context(story: dict[str, Any]) -> dict[str, Any]:
    contract = story.get("contract") or {}
    return {
        "story_id": str(contract.get("story_id") or story.get("story_id") or "").strip() or None,
        "story_uuid": str(contract.get("story_uuid") or story.get("story_uuid") or "").strip() or None,
        "story_title": str(contract.get("title") or story.get("title") or "").strip() or None,
        "project_id": str(contract.get("project_id") or story.get("project_id") or "").strip() or None,
    }


def _story_replay_metadata(story: dict[str, Any]) -> dict[str, Any]:
    replay = story.get("replay")
    if not isinstance(replay, dict):
        return {}
    return replay


def _canonical_stage_ids() -> set[str]:
    return {stage.node_id for stage in default_implementation_stages()}


def _story_replay_resume_from_stage(story: dict[str, Any]) -> str | None:
    replay = _story_replay_metadata(story)
    value = str(replay.get("resume_from_stage") or "").strip().lower()
    if value and value in _canonical_stage_ids():
        return value
    return None


def _story_replay_prior_stage_valid(story: dict[str, Any], stage_id: str) -> bool:
    replay = _story_replay_metadata(story)
    valid_prior_stages = replay.get("valid_prior_stages")
    if not isinstance(valid_prior_stages, list):
        return False
    return stage_id in {str(item).strip().lower() for item in valid_prior_stages if str(item).strip()}


def _safe_story_artifact_id(story_id: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", story_id) or "unknown_story"


def _load_json_if_exists(path: Path) -> dict[str, Any] | None:
    if not path.exists() or not path.is_file():
        return None
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None
    return payload if isinstance(payload, dict) else None


def _red_complete_checkpoint_path(*, repo_root: Path, story_id: str) -> Path:
    safe_story_id = re.sub(r"[^A-Za-z0-9_.-]+", "_", story_id) or "unknown_story"
    return _story_state_root(repo_root=repo_root) / safe_story_id / "red_complete.json"


def _write_red_complete_checkpoint(*, repo_root: Path, story_id: str, payload: dict[str, Any]) -> None:
    path = _red_complete_checkpoint_path(repo_root=repo_root, story_id=story_id)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def _load_red_complete_checkpoint(*, repo_root: Path, story_id: str) -> dict[str, Any] | None:
    path = _red_complete_checkpoint_path(repo_root=repo_root, story_id=story_id)
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        if isinstance(data, dict) and data.get("red_complete"):
            return data
    except Exception:
        pass
    return None


def _load_agent_run_response(path: Path) -> tuple[dict[str, Any] | None, dict[str, Any] | None]:
    envelope = _load_json_if_exists(path)
    if not isinstance(envelope, dict):
        return None, None
    response = envelope.get("response")
    return (dict(response), envelope) if isinstance(response, dict) else (None, envelope)


def _accepted_redreview_registered_files(*, review: RedReviewArtifact) -> list[dict[str, Any]]:
    registered: list[dict[str, Any]] = []
    for file in review.files:
        file_path = str(file.path or "").strip()
        if not file.register_for_validation or not file_path:
            continue
        rel = Path(file_path)
        if rel.is_absolute() or ".." in rel.parts:
            continue
        normalized_planes = list(dict.fromkeys(plane for plane in file.covered_planes if plane in ALLOWED_PLANES))
        if not normalized_planes:
            continue
        registered.append(
            {
                "path": file_path,
                "covered_planes": normalized_planes,
                "register_for_validation": True,
                "rationale": file.rationale,
            }
        )
    return registered


def _load_story_local_redreview_registered_files(
    *,
    repo_root: Path,
    story: dict[str, Any],
    bundle_id: str,
) -> list[dict[str, Any]]:
    story_ctx = _story_context(story)
    story_id = str(story_ctx.get("story_id") or "").strip()
    if not story_id:
        return []
    pipeline_root = _implementation_pipeline_root(repo_root=repo_root, story_id=story_id)
    node_ref = f"redreview.{_safe_bundle_id(bundle_id)}"
    response, _envelope = _load_agent_run_response(pipeline_root / "agent_runs" / f"{node_ref}.json")
    if response is None:
        return []
    try:
        review = RedReviewArtifact.model_validate(response)
    except Exception:
        return []
    return _accepted_redreview_registered_files(review=review)


def _repair_reconciled_bundle_artifacts_from_story_local_redreview(
    *,
    repo_root: Path,
    story: dict[str, Any],
    reconciled_verification: dict[str, Any],
) -> dict[str, Any]:
    bundle_plans = [dict(bundle) for bundle in (reconciled_verification.get("bundles") or []) if isinstance(bundle, dict)]
    if len(bundle_plans) <= 1:
        return reconciled_verification

    repaired_bundles: list[dict[str, Any]] = []
    repaired = False
    for raw_bundle in bundle_plans:
        bundle = dict(raw_bundle)
        test_paths = [str(path) for path in (bundle.get("test_paths") or []) if str(path).strip()]
        registered_files = [dict(item) for item in (bundle.get("registered_files") or []) if isinstance(item, dict)]
        if test_paths and registered_files:
            repaired_bundles.append(bundle)
            continue

        recovered_registered_files = _load_story_local_redreview_registered_files(
            repo_root=repo_root,
            story=story,
            bundle_id=str(bundle.get("bundle_id") or "default"),
        )
        if not recovered_registered_files:
            repaired_bundles.append(bundle)
            continue

        if not registered_files:
            bundle["registered_files"] = recovered_registered_files
            repaired = True
        if not test_paths:
            bundle["test_paths"] = [
                str(item.get("path"))
                for item in recovered_registered_files
                if str(item.get("path") or "").strip()
            ]
            repaired = True
        repaired_bundles.append(bundle)

    if not repaired:
        return reconciled_verification
    repaired_payload = dict(reconciled_verification)
    repaired_payload["bundles"] = repaired_bundles
    return repaired_payload


def _checkpoint_bundle_artifacts_are_complete(bundle_payload: dict[str, Any]) -> bool:
    test_paths = [str(path) for path in (bundle_payload.get("test_paths") or []) if str(path).strip()]
    registered_files = [dict(item) for item in (bundle_payload.get("registered_files") or []) if isinstance(item, dict)]
    return bool(test_paths and registered_files)


def _repair_red_complete_checkpoint_bundle_artifacts(
    *,
    repo_root: Path,
    story: dict[str, Any],
    test_design: dict[str, Any],
    checkpoint: dict[str, Any],
) -> dict[str, Any]:
    bundle_reports = [dict(report) for report in (checkpoint.get("bundle_redreview_reports") or []) if isinstance(report, dict)]
    bundles = _test_design_bundles(repo_root=repo_root, story=story, test_design=test_design)
    if len(bundle_reports) <= 1 or len(bundles) <= 1:
        return checkpoint

    report_map = {str(report.get("bundle_id") or "default"): dict(report) for report in bundle_reports}
    repaired = False
    repaired_reports: list[dict[str, Any]] = []
    latest_registered_files: list[dict[str, Any]] = []

    for raw_bundle in bundles:
        bundle = _preserve_rip_to_green_bundle_identity(
            repo_root=repo_root,
            story=story,
            test_design=test_design,
            bundle=dict(raw_bundle),
        )
        bundle_id = str(bundle.get("bundle_id") or "default")
        report = dict(report_map.get(bundle_id) or {"bundle_id": bundle_id})
        if _checkpoint_bundle_artifacts_are_complete(report):
            repaired_reports.append(report)
            latest_registered_files.extend(
                dict(item) for item in (report.get("registered_files") or []) if isinstance(item, dict)
            )
            continue

        bundle_test_paths = _resolve_rip_to_green_bundle_test_paths(
            repo_root=repo_root,
            story=story,
            bundle=bundle,
        )
        if not bundle_test_paths:
            repaired_reports.append(report)
            continue

        runtime_contract, runtime_contract_path, _command_probe, _command_attempts = _establish_verified_bundle_test_runtime_contract(
            repo_root=repo_root,
            story=story,
            bundle=bundle,
            test_paths=bundle_test_paths,
            source=f"red_complete_checkpoint:{bundle_id}",
        )
        verified_test_paths = [
            str(path)
            for path in (runtime_contract.get("test_paths") or bundle_test_paths)
            if str(path).strip()
        ]
        registered_files = [
            {
                "path": path,
                "covered_planes": list(bundle.get("planes") or []),
                "register_for_validation": True,
                "rationale": "red-complete checkpoint repair recovered accepted bundle-scoped tests from canonical story artifacts",
            }
            for path in verified_test_paths
        ]
        if not registered_files:
            repaired_reports.append(report)
            continue

        repaired = True
        latest_registered_files.extend(registered_files)
        history = [dict(item) for item in (report.get("history") or []) if isinstance(item, dict)]
        if history:
            last_history = dict(history[-1])
            last_history["registered_files"] = registered_files
            last_history["validator_input_paths"] = verified_test_paths
            last_history["test_runtime_contract"] = runtime_contract
            last_history["runtime_contract_path"] = None if runtime_contract_path is None else str(runtime_contract_path)
            history[-1] = last_history
        else:
            history = [
                {
                    "checkpoint_repair": True,
                    "registered_files": registered_files,
                    "validator_input_paths": verified_test_paths,
                    "assessment": dict(report.get("assessment") or {}),
                    "test_runtime_contract": runtime_contract,
                    "runtime_contract_path": None if runtime_contract_path is None else str(runtime_contract_path),
                }
            ]
        report["registered_files"] = registered_files
        report["validator_input_paths"] = verified_test_paths
        report["runtime_contract"] = runtime_contract
        report["runtime_contract_path"] = None if runtime_contract_path is None else str(runtime_contract_path)
        report["history"] = history
        repaired_reports.append(report)

    if not repaired:
        return checkpoint

    repaired_checkpoint = dict(checkpoint)
    repaired_checkpoint["bundle_redreview_reports"] = repaired_reports
    repaired_checkpoint["redreview_registered_files"] = latest_registered_files

    redreview_report = dict(repaired_checkpoint.get("redreview_report") or {})
    if redreview_report.get("bundle_reports") or repaired_reports:
        redreview_report["bundle_reports"] = repaired_reports
    if latest_registered_files:
        redreview_report["registered_files"] = latest_registered_files
    repaired_checkpoint["redreview_report"] = redreview_report

    repaired_checkpoint["story_verification_reconciliation"] = _build_story_verification_reconciliation(
        repo_root=repo_root,
        story=story,
        test_design=test_design,
        bundle_reports=repaired_reports,
    ).model_dump()

    story_ctx = _story_context(story)
    story_id = str(story_ctx.get("story_id") or "").strip()
    if story_id:
        _write_red_complete_checkpoint(
            repo_root=repo_root,
            story_id=story_id,
            payload=repaired_checkpoint,
        )
    return repaired_checkpoint


def _artifact_backed_replay_state(*, repo_root: Path, story: dict[str, Any], stage_id: str) -> dict[str, Any] | None:
    if stage_id not in {
        "normalize",
        "setupdoc",
        "dependencyassessment",
        "storyimplementationplanning",
        "testdesign",
    }:
        return None

    story_ctx = _story_context(story)
    story_id = str(story_ctx.get("story_id") or "").strip()
    if not story_id:
        return None

    pipeline_root = _implementation_pipeline_root(repo_root=repo_root, story_id=story_id)
    setup_json_path = repo_root / ".devflow" / "local_setup.json"
    preflight_path = pipeline_root / "preflight.json"
    implementation_planning_path = pipeline_root / "implementation_planning.json"
    dependency_agent_run_path = pipeline_root / "agent_runs" / "dependencyassessment.json"
    planning_agent_run_path = pipeline_root / "agent_runs" / "storyimplementationplanning.json"
    testdesign_agent_run_path = pipeline_root / "agent_runs" / "testdesign.json"

    def _artifact_state(*, artifact_kind: str, artifact_path: Path, metadata: dict[str, Any]) -> dict[str, Any]:
        return {
            "replay_source": "artifact",
            "node": {
                "output": {
                    "artifact_source": "canonical_story_artifacts",
                    "artifact_path": str(artifact_path),
                }
            },
            "artifacts": [
                {
                    "kind": artifact_kind,
                    "uri": str(artifact_path),
                    "metadata": metadata,
                }
            ],
            "artifact_paths": [str(artifact_path)],
        }

    if stage_id == "normalize":
        source_paths = [
            preflight_path,
            implementation_planning_path,
            dependency_agent_run_path,
            planning_agent_run_path,
            testdesign_agent_run_path,
        ]
        first_existing = next((path for path in source_paths if path.exists()), None)
        if first_existing is None:
            return None
        normalize_meta = {
            "schema_version": 1,
            "story_uuid": story_ctx.get("story_uuid"),
            "title": story_ctx.get("story_title"),
        }
        return _artifact_state(artifact_kind="normalize", artifact_path=first_existing, metadata=normalize_meta)

    if stage_id == "setupdoc":
        if not setup_json_path.exists():
            return None
        try:
            existing = LocalSetupContract.model_validate_json(setup_json_path.read_text(encoding="utf-8"))
        except Exception:
            return None
        if existing.schema_version != 1:
            return None
        return _artifact_state(
            artifact_kind="setupdoc",
            artifact_path=setup_json_path,
            metadata={"schema_version": 1, "reused": True, "path": str(setup_json_path)},
        )

    if stage_id == "dependencyassessment":
        response, envelope = _load_agent_run_response(dependency_agent_run_path)
        if response is None:
            return None
        prompt = envelope.get("prompt") if isinstance(envelope, dict) else {}
        context = prompt.get("context") if isinstance(prompt, dict) else {}
        heuristic_evidence = context.get("heuristic_evidence") if isinstance(context, dict) else {}
        assessment_status = str(response.get("assessment_status") or "").strip() or "ready"
        assessment = {
            "schema_version": 2,
            "story_id": story_ctx.get("story_id"),
            "story_uuid": story_ctx.get("story_uuid"),
            "story_title": story_ctx.get("story_title"),
            "mode": "model_backed",
            "agent_run_ref": str(dependency_agent_run_path),
            "outcome": assessment_status,
            "summary": response.get("summary"),
            "internal_dependencies": list(response.get("internal_dependencies") or []),
            "external_dependencies": list(response.get("external_dependencies") or []),
            "unresolved_internal_dependencies": list(response.get("unresolved_internal_dependencies") or []),
            "blocked_external_dependencies": list(response.get("blocked_external_dependencies") or []),
            "deferred": assessment_status != "ready",
            "inferred_capabilities": list(response.get("inferred_capabilities") or []),
            "preferred_pathways": list(response.get("preferred_pathways") or []),
            "blocking_issues": list(response.get("blocking_issues") or []),
            "downstream_contract": dict(response.get("downstream_contract") or {}),
            "lineage": {
                "heuristic_evidence": dict(heuristic_evidence or {}),
                "model_backed": True,
            },
        }
        return _artifact_state(
            artifact_kind="dependency_assessment",
            artifact_path=dependency_agent_run_path,
            metadata=assessment,
        )

    if stage_id == "storyimplementationplanning":
        planning = _load_json_if_exists(implementation_planning_path)
        if planning is None:
            return None
        return _artifact_state(
            artifact_kind="implementation_planning",
            artifact_path=implementation_planning_path,
            metadata=planning,
        )

    if stage_id == "testdesign":
        response, envelope = _load_agent_run_response(testdesign_agent_run_path)
        if response is None:
            return None
        prompt = envelope.get("prompt") if isinstance(envelope, dict) else {}
        context = prompt.get("context") if isinstance(prompt, dict) else {}
        artifact = TestDesignArtifact.model_validate(response)
        bundles = _normalize_test_design_bundles(repo_root=repo_root, story=story, artifact=artifact)
        td_meta = {
            "schema_version": 3,
            "mode": "model_backed",
            "agent_run_ref": str(testdesign_agent_run_path),
            "story_id": story_ctx.get("story_id"),
            "story_uuid": story_ctx.get("story_uuid"),
            "summary": artifact.summary,
            "test_cases": _flatten_bundle_test_cases(bundles),
            "bundles": bundles,
            "design_notes": artifact.design_notes,
            "story_scoping_notes": artifact.story_scoping_notes,
            "must_cover": artifact.must_cover,
            "must_avoid": artifact.must_avoid,
            "dependency_assessment": dict(context.get("dependency_assessment") or {}),
            "implementation_planning": dict(context.get("implementation_planning") or {}),
        }
        return _artifact_state(
            artifact_kind="test_design",
            artifact_path=testdesign_agent_run_path,
            metadata=td_meta,
        )

    return None


def _load_replay_stage_state(*, store: ExecutionStore, repo_root: Path, story: dict[str, Any], stage_id: str) -> dict[str, Any] | None:
    # Preflight includes live health validation and must always execute at runtime.
    if stage_id == "preflight":
        return None
    replay = _story_replay_metadata(story)
    prior_run_id = str(replay.get("prior_run_id") or "").strip()
    if prior_run_id and _story_replay_prior_stage_valid(story, stage_id):
        prior_node = store.get_latest_node_attempt(run_id=prior_run_id, node_id=stage_id, status="succeeded")
        if prior_node is not None:
            artifacts = store.list_artifacts_for_node(run_id=prior_run_id, node_id=stage_id)
            if artifacts:
                return {
                    "replay_source": "prior_run",
                    "prior_run_id": prior_run_id,
                    "node": prior_node,
                    "artifacts": artifacts,
                }
            # Prior node has no registered artifacts (it was itself a replay from disk).
            # Prefer canonical disk artifact if available; otherwise keep the prior_run ref
            # so at least the node is marked replayed rather than re-run.
            artifact_state = _artifact_backed_replay_state(repo_root=repo_root, story=story, stage_id=stage_id)
            if artifact_state is not None:
                return artifact_state
            return {
                "replay_source": "prior_run",
                "prior_run_id": prior_run_id,
                "node": prior_node,
                "artifacts": [],
            }
    return _artifact_backed_replay_state(repo_root=repo_root, story=story, stage_id=stage_id)


def _replay_artifact_metadata(stage_state: dict[str, Any], kind: str) -> dict[str, Any] | None:
    for artifact in reversed(stage_state.get("artifacts") or []):
        if str(artifact.get("kind") or "") == kind:
            return dict(artifact.get("metadata") or {})
    return None


def _mark_replayed_node(*, store: ExecutionStore, run_id: str, node_id: str, node_name: str, stage_state: dict[str, Any], output: dict[str, Any] | None = None) -> str:
    node_exec_id = store.create_node_attempt(run_id=run_id, node_id=node_id, node_name=node_name, attempt=1)
    replay_payload = {
        "replayed": True,
        "replay_source": str(stage_state.get("replay_source") or "prior_run"),
        "prior_run_id": stage_state.get("prior_run_id"),
        "prior_node_exec_id": (stage_state.get("node") or {}).get("node_exec_id"),
        "prior_output": (stage_state.get("node") or {}).get("output"),
    }
    artifact_paths = [str(path) for path in (stage_state.get("artifact_paths") or []) if str(path).strip()]
    if artifact_paths:
        replay_payload["artifact_paths"] = artifact_paths
    if output:
        replay_payload.update(output)
    store.mark_node_finished(node_exec_id=node_exec_id, status="succeeded", output=replay_payload)
    return node_exec_id


def _story_project_id(repo_root: Path, story: dict[str, Any]) -> str | None:
    ctx = _story_context(story)
    project_id = str(ctx.get("project_id") or "").strip()
    if project_id:
        return project_id
    try:
        store, _ = _store_run()
        for project in store.list_projects():
            if Path(str(project.get("repo_root") or "")).expanduser().resolve() == repo_root.expanduser().resolve():
                value = str(project.get("project_id") or "").strip()
                if value:
                    return value
    except Exception:
        return None
    return None


def _clean_dfs_summary(text: str) -> str:
    cleaned = re.sub(r"\[<more repeated useless text>\]", "", str(text or ""), flags=re.IGNORECASE)
    cleaned = re.sub(r"\s+", " ", cleaned).strip()
    return cleaned[:240] if cleaned else "Processing implementation"


def _dfs_node_running(*, repo_root: Path, story: dict[str, Any], run_id: str, node_id: str, summary: str) -> None:
    if not _devflow_publish_enabled():
        return
    project_id = _story_project_id(repo_root, story)
    if not project_id:
        return
    publish_devflow_state(
        project_id=project_id,
        run_id=run_id,
        current_state="running",
        current_status="processing",
        run_summary=_clean_dfs_summary(summary),
        display="project",
        display_path=f"story:{_story_context(story).get('story_id') or _story_context(story).get('story_uuid') or 'unknown'}",
    )


def _dfs_terminal(*, repo_root: Path, story: dict[str, Any], run_id: str, exit_code: int, summary: str) -> None:
    if not _devflow_publish_enabled():
        return
    project_id = _story_project_id(repo_root, story)
    if not project_id:
        return
    publish_devflow_state(
        project_id=project_id,
        run_id=run_id,
        current_state="completed" if exit_code == 0 else "failed",
        current_status="completed" if exit_code == 0 else "failed",
        run_summary=_clean_dfs_summary(summary),
        error_message=None if exit_code == 0 else _clean_dfs_summary(summary),
        display="project",
        display_path=f"story:{_story_context(story).get('story_id') or _story_context(story).get('story_uuid') or 'unknown'}",
    )


def _normalize_dependency_entries(raw: Any) -> list[dict[str, Any]]:
    if not isinstance(raw, list):
        return []
    normalized: list[dict[str, Any]] = []
    for item in raw:
        if isinstance(item, str):
            value = item.strip()
            if value:
                normalized.append({"id": value})
            continue
        if isinstance(item, dict):
            normalized.append(dict(item))
    return normalized


def _normalize_implementation_planning(planning: Any) -> dict[str, Any]:
    if not isinstance(planning, dict):
        return {}
    normalized = dict(planning)
    status = str(normalized.get("planning_status") or "").strip()
    if status != "ready":
        return normalized
    normalized["planning_status"] = "ready_for_implementation"
    queue_decision = normalized.get("queue_decision")
    if isinstance(queue_decision, dict) and str(queue_decision.get("state") or "").strip() == "ready":
        normalized["queue_decision"] = {**queue_decision, "state": "ready_for_implementation"}
    return normalized


def _find_story_by_reference(*, store: ExecutionStore, story_ref: str, project_id: str | None) -> dict[str, Any] | None:
    ref = str(story_ref or "").strip()
    if not ref:
        return None
    row = store.get_story(ref)
    if row is not None:
        return row
    candidate_sets = [store.list_stories(project_id=project_id)]
    if project_id is not None:
        candidate_sets.append(store.list_stories(project_id=None))
    for candidates in candidate_sets:
        for candidate in candidates:
            contract = candidate.get("contract") or {}
            if ref in {
                str(candidate.get("story_id") or "").strip(),
                str(contract.get("story_id") or "").strip(),
                str(contract.get("story_uuid") or "").strip(),
            }:
                return candidate
    return None


def _reconcile_implementation_planning_with_current_state(*, store: ExecutionStore, story: dict[str, Any], planning: Any) -> dict[str, Any]:
    normalized = _normalize_implementation_planning(planning)
    if str(normalized.get("planning_status") or "").strip() != "waiting_for_provider_story":
        return normalized

    queue_decision = normalized.get("queue_decision") if isinstance(normalized.get("queue_decision"), dict) else {}
    provider_refs: list[str] = []
    for value in (
        queue_decision.get("queue_after_story_id"),
        *[
            item.get("provider_story_id")
            for item in (normalized.get("preferred_pathways") or [])
            if isinstance(item, dict)
        ],
        *[
            item.get("provider_story_id") or item.get("story_ref")
            for item in (normalized.get("blocking_issues") or [])
            if isinstance(item, dict) and str(item.get("kind") or "").strip() == "waiting_for_provider_story"
        ],
    ):
        ref = str(value or "").strip()
        if ref and ref not in provider_refs:
            provider_refs.append(ref)
    if not provider_refs:
        return normalized

    project_id = story.get("project_id") or (story.get("contract") or {}).get("project_id")
    if not project_id:
        current_story_id = str((_story_context(story).get("story_id") or _story_context(story).get("story_uuid") or "")).strip()
        if current_story_id:
            current_queue_row = _find_story_queue_row_for_story(store=store, story_id=current_story_id)
            project_id = None if current_queue_row is None else current_queue_row.get("project_id")
    queue_status_index = _load_project_story_queue_status_index(store=store, project_id=str(project_id or "") or None)
    provider_completed = False
    for ref in provider_refs:
        provider_story = _find_story_by_reference(store=store, story_ref=ref, project_id=str(project_id or "") or None)
        queue_summary = _story_queue_summary(queue_status_index=queue_status_index, story_row=provider_story, story_ref=ref)
        effective_status = str((queue_summary or {}).get("effective_status") or (provider_story or {}).get("status") or "").strip()
        if _story_status_is_resolved(effective_status) or _story_is_resolved(provider_story):
            provider_completed = True
            break
    if not provider_completed:
        return normalized

    reconciled = dict(normalized)
    reconciled["planning_status"] = "ready_for_implementation"
    reconciled["blocking_issues"] = [
        dict(item)
        for item in (normalized.get("blocking_issues") or [])
        if isinstance(item, dict) and str(item.get("kind") or "").strip() != "waiting_for_provider_story"
    ]
    if isinstance(normalized.get("queue_decision"), dict):
        reconciled["queue_decision"] = {
            **dict(normalized["queue_decision"]),
            "state": "ready_for_implementation",
            "queue_after_story_id": None,
            "requeue_recommendation": False,
        }
        reconciled["queue_decision"].pop("requeue_story_queue_id", None)
    downstream_contract = normalized.get("downstream_contract")
    if isinstance(downstream_contract, dict):
        reconciled_contract = dict(downstream_contract)
        for key, value in list(reconciled_contract.items()):
            if isinstance(value, list):
                reconciled_contract[key] = [
                    "planning_status=ready_for_implementation"
                    if item == "planning_status=waiting_for_provider_story"
                    else item
                    for item in value
                ]
        reconciled["downstream_contract"] = reconciled_contract
    return reconciled


def _extract_internal_dependencies(story: dict[str, Any]) -> list[dict[str, Any]]:
    contract = story.get("contract") or {}
    candidates = [
        contract.get("depends_on"),
        story.get("depends_on"),
        contract.get("dependencies"),
        story.get("dependencies"),
    ]
    deps: list[dict[str, Any]] = []
    for raw in candidates:
        for item in _normalize_dependency_entries(raw):
            dep_type = str(item.get("type") or item.get("dependency_type") or "internal").strip().lower()
            if dep_type in {"", "internal", "story"}:
                dep_id = str(item.get("story_id") or item.get("story_uuid") or item.get("id") or item.get("ref") or "").strip()
                if dep_id:
                    deps.append({"story_ref": dep_id, "title": str(item.get("title") or "").strip() or None})
    deduped: list[dict[str, Any]] = []
    seen: set[str] = set()
    for dep in deps:
        key = dep["story_ref"]
        if key in seen:
            continue
        seen.add(key)
        deduped.append(dep)
    return deduped


def _extract_external_dependencies(story: dict[str, Any]) -> list[dict[str, Any]]:
    contract = story.get("contract") or {}
    candidates = [
        contract.get("external_dependencies"),
        story.get("external_dependencies"),
        contract.get("dependencies"),
        story.get("dependencies"),
    ]
    deps: list[dict[str, Any]] = []
    for raw in candidates:
        for item in _normalize_dependency_entries(raw):
            dep_type = str(item.get("type") or item.get("dependency_type") or "").strip().lower()
            package = str(item.get("package") or item.get("name") or item.get("id") or item.get("ref") or "").strip()
            if dep_type == "external" and package:
                deps.append({"package": package, "domain": str(item.get("domain") or "").strip() or None})
    deduped: list[dict[str, Any]] = []
    seen: set[str] = set()
    for dep in deps:
        key = dep["package"]
        if key in seen:
            continue
        seen.add(key)
        deduped.append(dep)
    return deduped


def _story_is_resolved(story_row: dict[str, Any] | None) -> bool:
    if not story_row:
        return False
    status = str(story_row.get("status") or "").strip().lower()
    return status in {"done", "completed", "implemented", "ready_for_review", "succeeded"}


def _story_reference_keys(*, story_row: dict[str, Any] | None = None, story_ref: str | None = None) -> set[str]:
    keys: set[str] = set()
    if story_ref:
        ref = str(story_ref).strip()
        if ref:
            keys.add(ref)
    if not story_row:
        return keys
    contract = story_row.get("contract") or {}
    for value in (
        story_row.get("story_id"),
        contract.get("story_id"),
        contract.get("story_uuid"),
    ):
        key = str(value or "").strip()
        if key:
            keys.add(key)
    return keys


def _story_status_is_resolved(status: str | None) -> bool:
    return str(status or "").strip().lower() in {"done", "completed", "implemented", "ready_for_review", "succeeded"}


def _story_idea_id(*, story: dict[str, Any] | None = None) -> str | None:
    if not isinstance(story, dict):
        return None
    contract = story.get("contract") if isinstance(story.get("contract"), dict) else {}
    for value in (
        story.get("idea_id"),
        contract.get("idea_id"),
        story.get("story_id"),
        contract.get("story_id"),
    ):
        text = str(value or "").strip()
        if not text:
            continue
        match = re.match(r"^STORY:idea:([^:]+):", text)
        if match:
            return str(match.group(1) or "").strip() or None
    return None


def _load_project_story_queue_status_index(*, store: ExecutionStore, project_id: str | None) -> dict[str, dict[str, Any]]:
    if not project_id:
        return {}
    with store._connect() as conn:
        rows = conn.execute(
            "SELECT story_id, status, story_queue_id, created_at, updated_at FROM story_queue WHERE project_id=? ORDER BY updated_at DESC, created_at DESC",
            (project_id,),
        ).fetchall()
    by_story_id: dict[str, list[dict[str, Any]]] = {}
    for row in rows:
        story_id = str(row["story_id"] or "").strip()
        if not story_id:
            continue
        by_story_id.setdefault(story_id, []).append(
            {
                "story_queue_id": str(row["story_queue_id"] or ""),
                "status": str(row["status"] or ""),
                "created_at": int(row["created_at"] or 0),
                "updated_at": int(row["updated_at"] or 0),
            }
        )

    summaries: dict[str, dict[str, Any]] = {}
    for story_id, entries in by_story_id.items():
        statuses = [str(entry.get("status") or "") for entry in entries]
        effective_status = "completed" if any(status == "completed" for status in statuses) else (statuses[0] if statuses else None)
        summaries[story_id] = {
            "effective_status": effective_status,
            "statuses": statuses,
            "has_queue_row": bool(entries),
            "queue_item_ids": [str(entry["story_queue_id"]) for entry in entries],
        }
    return summaries


def _story_queue_summary(
    *,
    queue_status_index: dict[str, dict[str, Any]],
    story_row: dict[str, Any] | None = None,
    story_ref: str | None = None,
) -> dict[str, Any] | None:
    keys = _story_reference_keys(story_row=story_row, story_ref=story_ref)
    for key in keys:
        summary = queue_status_index.get(key)
        if summary is not None:
            return summary
    return None


def _candidate_provider_stories(*, store: ExecutionStore, project_id: str | None, current_story: dict[str, Any] | None = None) -> list[dict[str, Any]]:
    queue_status_index = _load_project_story_queue_status_index(store=store, project_id=project_id)
    candidates: list[dict[str, Any]] = []
    for candidate in store.list_stories(project_id=None):
        contract = candidate.get("contract") or {}
        queue_summary = _story_queue_summary(queue_status_index=queue_status_index, story_row=candidate)
        if project_id and queue_summary is None:
            continue
        candidates.append(
            {
                "idea_id": _story_idea_id(story=candidate),
                "story_id": candidate.get("story_id"),
                "contract_story_id": contract.get("story_id"),
                "story_uuid": contract.get("story_uuid"),
                "title": candidate.get("title"),
                "status": (queue_summary or {}).get("effective_status") or candidate.get("status"),
                "queue_statuses": list((queue_summary or {}).get("statuses") or []),
                "summary": {
                    "depends_on": contract.get("depends_on") or candidate.get("depends_on") or [],
                    "external_dependencies": contract.get("external_dependencies") or candidate.get("external_dependencies") or [],
                },
            }
        )
    return candidates


def _dependency_assessment_report_path(*, repo_root: Path, run_id: str, story_id: str) -> Path:
    safe_story_id = re.sub(r"[^A-Za-z0-9_.-]+", "_", story_id) or "unknown_story"
    return repo_root / ".devflow" / "runs" / run_id / "dependency_assessment" / safe_story_id / "assessment.json"


def _load_registry_package_statuses(repo_root: Path) -> dict[str, dict[str, Any]]:
    db_path = repo_root / ".devflow" / "registry.sqlite"
    if not db_path.exists():
        return {}
    conn = sqlite3.connect(str(db_path))
    try:
        refresh_policy(conn)
        rows = conn.execute(
            "select package, domain, status, coalesce(lane,''), coalesce(reason,'') from package_status"
        ).fetchall()
        return {
            str(pkg): {
                "domain": str(domain) if domain is not None else None,
                "status": str(status),
                "lane": str(lane or "") or None,
                "reason": str(reason or "") or None,
            }
            for pkg, domain, status, lane, reason in rows
        }
    finally:
        conn.close()


def _assess_story_dependencies(*, repo_root: Path, store: ExecutionStore, story: dict[str, Any]) -> dict[str, Any]:
    story_ctx = _story_context(story)
    project_id = story.get("project_id") or (story.get("contract") or {}).get("project_id")
    queue_status_index = _load_project_story_queue_status_index(store=store, project_id=str(project_id or "") or None)
    internal_dependencies = _extract_internal_dependencies(story)
    external_dependencies = _extract_external_dependencies(story)

    internal_results: list[dict[str, Any]] = []
    unresolved_internal: list[dict[str, Any]] = []
    for dep in internal_dependencies:
        ref = dep["story_ref"]
        row = store.get_story(ref)
        if row is None:
            # Try UUID/story_id alternate if dependency was registered under the other identifier.
            for candidate in store.list_stories(project_id=story.get("project_id")):
                contract = candidate.get("contract") or {}
                if ref in {str(candidate.get("story_id") or ""), str(contract.get("story_id") or ""), str(contract.get("story_uuid") or "")}:
                    row = candidate
                    break
        queue_summary = _story_queue_summary(queue_status_index=queue_status_index, story_row=row, story_ref=ref)
        effective_status = (queue_summary or {}).get("effective_status") or (None if row is None else row.get("status"))
        resolved = _story_is_resolved(row) or _story_status_is_resolved(effective_status)
        result = {
            "story_ref": ref,
            "resolved": resolved,
            "status": effective_status,
            "matched_story_id": None if row is None else row.get("story_id"),
            "matched_contract_story_id": None if row is None else (row.get("contract") or {}).get("story_id"),
        }
        internal_results.append(result)
        if not resolved:
            unresolved_internal.append(result)

    package_statuses = _load_registry_package_statuses(repo_root)
    external_results: list[dict[str, Any]] = []
    blocked_external: list[dict[str, Any]] = []
    for dep in external_dependencies:
        package = dep["package"]
        status_row = package_statuses.get(package)
        policy_status = None if status_row is None else status_row.get("status")
        allowed = policy_status in {"canonical", "allowed"}
        result = {
            "package": package,
            "domain": dep.get("domain") or (None if status_row is None else status_row.get("domain")),
            "policy_status": policy_status,
            "allowed": allowed,
            "reason": None if status_row is None else status_row.get("reason"),
        }
        external_results.append(result)
        if not allowed:
            blocked_external.append(result)

    deferred = bool(unresolved_internal or blocked_external)
    reasons: list[str] = []
    if unresolved_internal:
        refs = ", ".join(sorted(item["story_ref"] for item in unresolved_internal))
        reasons.append(f"unresolved internal dependencies: {refs}")
    if blocked_external:
        refs = ", ".join(sorted(item["package"] for item in blocked_external))
        reasons.append(f"external dependencies blocked by registration policy: {refs}")

    return {
        "schema_version": 2,
        "story_id": story_ctx.get("story_id"),
        "story_uuid": story_ctx.get("story_uuid"),
        "story_title": story_ctx.get("story_title"),
        "internal_dependencies": internal_results,
        "external_dependencies": external_results,
        "unresolved_internal_dependencies": unresolved_internal,
        "blocked_external_dependencies": blocked_external,
        "deferred": deferred,
        "outcome": "deferred" if deferred else "ready",
        "message": "; ".join(reasons) if reasons else "all declared dependencies satisfied",
    }


def _implementation_planning_report_path(*, repo_root: Path, story_id: str) -> Path:
    safe_story_id = re.sub(r"[^A-Za-z0-9_.-]+", "_", story_id) or "unknown_story"
    return _story_state_root(repo_root=repo_root) / safe_story_id / "implementation_planning.json"


def _prerequisite_story_request_path(*, repo_root: Path, story_id: str) -> Path:
    safe_story_id = re.sub(r"[^A-Za-z0-9_.-]+", "_", story_id) or "unknown_story"
    return _story_state_root(repo_root=repo_root) / safe_story_id / "prerequisite_story_request.json"


def _blocker_artifact_path(*, repo_root: Path, story_id: str) -> Path:
    safe_story_id = re.sub(r"[^A-Za-z0-9_.-]+", "_", story_id) or "unknown_story"
    return _story_state_root(repo_root=repo_root) / safe_story_id / "implementation_blocker.json"


def _preflight_report_path(*, repo_root: Path, story_id: str) -> Path:
    safe_story_id = re.sub(r"[^A-Za-z0-9_.-]+", "_", story_id) or "unknown_story"
    return _story_state_root(repo_root=repo_root) / safe_story_id / "preflight.json"


def _read_text_if_exists(path: Path, *, limit: int = 8000) -> str:
    if not path.exists() or not path.is_file():
        return ""
    try:
        text = path.read_text(encoding="utf-8")
    except Exception:
        return ""
    return _truncate_output(text, label=str(path.name), limit=limit)



def _repo_structure_snapshot(repo_root: Path) -> dict[str, Any]:
    interesting = ["src", "app", "services", "tests", "docker", ".devflow"]
    top_level = []
    for path in sorted(repo_root.iterdir()):
        if path.name.startswith(".") and path.name != ".devflow":
            continue
        top_level.append({"name": path.name, "kind": "dir" if path.is_dir() else "file"})
    return {
        "top_level": top_level[:40],
        "interesting_existing": [name for name in interesting if (repo_root / name).exists()],
        "docker_files": [p.name for p in sorted(repo_root.glob("Docker*"))[:10]],
        "compose_files": [p.name for p in sorted(repo_root.glob("*compose*.y*ml"))[:10]],
        "env_files": [p.name for p in sorted(repo_root.glob(".env*"))[:10]],
    }


def _runtime_setup_signals(repo_root: Path) -> dict[str, Any]:
    package_json = repo_root / "package.json"
    pyproject_toml = repo_root / "pyproject.toml"
    signals: dict[str, Any] = {
        "cwd": str(repo_root),
        "python_executable": sys.executable,
        "venv_present": (repo_root / ".venv").exists(),
        "node_modules_present": (repo_root / "node_modules").exists(),
        "dockerfile_present": any(repo_root.glob("Docker*")),
        "compose_present": any(repo_root.glob("*compose*.y*ml")),
        "package_json_present": package_json.exists(),
        "pyproject_present": pyproject_toml.exists(),
        "git_dir_present": (repo_root / ".git").exists(),
        "devflow_dir_present": (repo_root / ".devflow").exists(),
    }
    if package_json.exists():
        try:
            pkg = json.loads(package_json.read_text(encoding="utf-8"))
        except Exception:
            pkg = {}
        signals["package_scripts"] = sorted(list((pkg.get("scripts") or {}).keys()))[:20]
    if pyproject_toml.exists():
        try:
            cfg = tomllib.loads(pyproject_toml.read_text(encoding="utf-8"))
        except Exception:
            cfg = {}
        project = cfg.get("project") if isinstance(cfg.get("project"), dict) else {}
        signals["python_dependencies"] = [str(item) for item in (project.get("dependencies") or [])[:20]]
    env_example = repo_root / ".env.example"
    if env_example.exists():
        missing_env: list[str] = []
        for line in env_example.read_text(encoding="utf-8").splitlines():
            key = line.split("=", 1)[0].strip()
            if not key or key.startswith("#"):
                continue
            if os.environ.get(key) is None:
                missing_env.append(key)
        signals["env_example_missing_in_process"] = missing_env[:20]
    return signals


def _load_prior_failure_evidence(*, store: ExecutionStore, story: dict[str, Any]) -> list[dict[str, Any]]:
    story_ctx = _story_context(story)
    story_id = str(story_ctx.get("story_id") or "").strip()
    if not story_id:
        return []
    evidence: list[dict[str, Any]] = []
    with store._connect() as conn:
        rows = conn.execute(
            "SELECT run_id, status, config_json, created_at FROM runs WHERE dag_id='implementation_dag' ORDER BY created_at DESC LIMIT 10"
        ).fetchall()
    for row in rows:
        config = json.loads(str(row[2] or "{}")) if row[2] else {}
        if str(config.get("story_id") or "") != story_id:
            continue
        run_id = str(row[0])
        with store._connect() as conn:
            conn.row_factory = sqlite3.Row
            node_rows = conn.execute(
                "SELECT node_id, status, output_json FROM nodes WHERE run_id=? ORDER BY created_at ASC",
                (run_id,),
            ).fetchall()
        failed = [
            {"node_id": item["node_id"], "status": item["status"], "output": item["output_json"]}
            for item in node_rows
            if str(item["status"] or "") == "failed"
        ]
        evidence.append({"run_id": run_id, "status": row[1], "created_at": row[3], "failed_nodes": failed[:6]})
    return evidence[:5]




def _find_story_queue_row_for_story(*, store: ExecutionStore, story_id: str) -> dict[str, Any] | None:
    with store._connect() as conn:
        row = conn.execute(
            "SELECT story_queue_id, project_id, story_artifact_id, story_id, title, status FROM story_queue WHERE story_id=? ORDER BY created_at DESC LIMIT 1",
            (story_id,),
        ).fetchone()
    return None if row is None else dict(row)


def _find_provider_story(*, store: ExecutionStore, story: dict[str, Any], hints: list[str]) -> dict[str, Any] | None:
    project_id = story.get("project_id") or (story.get("contract") or {}).get("project_id")
    for candidate in _candidate_provider_stories(store=store, project_id=str(project_id or "") or None):
        haystacks = [
            str(candidate.get("story_id") or ""),
            str(candidate.get("title") or ""),
            json.dumps(candidate.get("contract") or {}, sort_keys=True),
        ]
        lowered = "\n".join(haystacks).lower()
        if any(hint.strip().lower() in lowered for hint in hints if hint.strip()):
            return candidate
    return None


def _build_dependency_assessment_context(*, repo_root: Path, store: ExecutionStore, story: dict[str, Any]) -> dict[str, Any]:
    story_ctx = _story_context(story)
    heuristic_assessment = _assess_story_dependencies(repo_root=repo_root, store=store, story=story)
    project_id = story.get("project_id") or (story.get("contract") or {}).get("project_id")
    return {
        "story": {
            "story_id": story_ctx.get("story_id"),
            "story_uuid": story_ctx.get("story_uuid"),
            "story_title": story_ctx.get("story_title"),
            "contract": story.get("contract") or {},
            "path": str((story.get("path") or (story.get("contract") or {}).get("path") or "").strip() or ""),
        },
        "heuristic_evidence": heuristic_assessment,
        "registry_state": {
            "package_statuses": _load_registry_package_statuses(repo_root),
        },
        "candidate_provider_stories": _candidate_provider_stories(
            store=store,
            project_id=str(project_id or "") or None,
            current_story=story,
        ),
    }


def _run_dependency_assessment_agent(*, repo_root: Path, pipeline_root: Path, assessment_context: dict[str, Any]) -> tuple[DependencyAssessmentDecision, Path]:
    artifact, envelope = run_agent_step(
        repo_root=repo_root,
        stage_name="implementation_dependency_assessment",
        strength="medium",
        output_model=DependencyAssessmentDecision,
        context_payload=assessment_context,
        guidance=load_agentic_prompt_lines("implementation_dependency_assessment"),
        timeout_seconds=_dependency_assessment_timeout_seconds(),
    )
    return artifact, _persist_implementation_agent_run(pipeline_root=pipeline_root, node_id="dependencyassessment", envelope=envelope)


def _build_story_planning_context(*, repo_root: Path, store: ExecutionStore, story: dict[str, Any], dependency_assessment: dict[str, Any] | None) -> dict[str, Any]:
    story_ctx = _story_context(story)
    assessment = dependency_assessment or _assess_story_dependencies(repo_root=repo_root, store=store, story=story)
    project_id = story.get("project_id") or (story.get("contract") or {}).get("project_id")
    return {
        "story": {
            "story_id": story_ctx.get("story_id"),
            "story_uuid": story_ctx.get("story_uuid"),
            "story_title": story_ctx.get("story_title"),
            "contract": story.get("contract") or {},
            "path": str((story.get("path") or (story.get("contract") or {}).get("path") or "").strip() or ""),
        },
        "dependency_assessment": assessment,
        "registry_state": {
            "package_statuses": _load_registry_package_statuses(repo_root),
        },
        "candidate_provider_stories": _candidate_provider_stories(
            store=store,
            project_id=str(project_id or "") or None,
            current_story=story,
        ),
    }


def _run_story_implementation_planning_agent(*, repo_root: Path, pipeline_root: Path, planning_context: dict[str, Any]) -> tuple[StoryImplementationPlanningDecision, Path]:
    artifact, envelope = run_agent_step(
        repo_root=repo_root,
        stage_name="implementation_story_planning",
        strength="medium",
        output_model=StoryImplementationPlanningDecision,
        context_payload=planning_context,
        guidance=load_agentic_prompt_lines("implementation_story_planning"),
        timeout_seconds=_implementation_planning_timeout_seconds(),
    )
    return artifact, _persist_implementation_agent_run(pipeline_root=pipeline_root, node_id="storyimplementationplanning", envelope=envelope)


def _build_implementation_planning(*, repo_root: Path, store: ExecutionStore, story: dict[str, Any], dependency_assessment: dict[str, Any] | None) -> tuple[dict[str, Any], dict[str, Any] | None, dict[str, Any] | None]:
    story_ctx = _story_context(story)
    pipeline_root = _implementation_pipeline_root(repo_root=repo_root, story_id=str(story_ctx.get("story_id") or "unknown_story"))
    planning_context = _build_story_planning_context(
        repo_root=repo_root,
        store=store,
        story=story,
        dependency_assessment=dependency_assessment,
    )
    decision, agent_run_path = _run_story_implementation_planning_agent(
        repo_root=repo_root,
        pipeline_root=pipeline_root,
        planning_context=planning_context,
    )
    assessment = planning_context["dependency_assessment"]
    planning_status = decision.planning_status
    prerequisite_request = decision.prerequisite_story_request
    blocker = decision.blocker
    if planning_status == "blocked" and blocker is None:
        blocker = {"story_id": story_ctx.get("story_id"), "blocking_issues": decision.blocking_issues, "summary": decision.summary}

    registry_expectations = []
    for item in decision.preferred_pathways:
        if not isinstance(item, dict):
            continue
        registry_expectations.append({
            "package": item.get("package"),
            "domain": item.get("domain"),
            "provider_story_id": item.get("provider_story_id"),
            "pathway": item.get("pathway"),
            "rationale": item.get("rationale"),
        })

    planning = {
        "schema_version": 2,
        "story_id": story_ctx.get("story_id"),
        "story_uuid": story_ctx.get("story_uuid"),
        "story_title": story_ctx.get("story_title"),
        "planning_status": planning_status,
        "mode": "model_backed",
        "agent_run_ref": str(agent_run_path),
        "inferred_capabilities": decision.inferred_capabilities,
        "summary": decision.summary,
        "dependency_findings": {
            "internal": decision.internal_findings or list(assessment.get("internal_dependencies") or []),
            "external": decision.external_findings or list(assessment.get("external_dependencies") or []),
            "registry_expectations": registry_expectations,
        },
        "queue_decision": {
            "state": planning_status,
            "queue_after_story_id": decision.queue_after_story_id,
            "requeue_recommendation": planning_status in {"waiting_for_provider_story", "create_prerequisite_story"},
        },
        "blocking_issues": decision.blocking_issues,
        "downstream_contract": decision.downstream_contract or {
            "test_design_must_assume": [f"planning_status={planning_status}"],
            "red_must_not_do": ["Do not invent workaround dependencies or bypass canonical registry expectations."],
            "green_must_honor": [f"preferred_pathways={json.dumps(registry_expectations, sort_keys=True)}"],
            "git_commit_must_verify": ["Treat implementation planning findings as enforce preconditions."],
        },
        "lineage": {
            "dependency_assessment_outcome": assessment.get("outcome"),
            "dependency_assessment_artifact": planning_context.get("dependency_assessment_artifact"),
            "source_story_path": planning_context["story"].get("path") or "",
            "model_backed": True,
        },
    }
    return planning, prerequisite_request, blocker if planning_status == "blocked" else None


def _build_test_design_context(
    *,
    story: dict[str, Any],
    dependency_assessment: dict[str, Any],
    implementation_planning: dict[str, Any],
) -> dict[str, Any]:
    story_ctx = _story_context(story)
    repo_root = Path(story.get("repo_root") or os.getcwd())
    setup_json_path = repo_root / ".devflow" / "local_setup.json"
    local_setup: dict[str, Any] = {}
    if setup_json_path.is_file():
        try:
            local_setup = json.loads(setup_json_path.read_text(encoding="utf-8"))
        except Exception:
            pass
    return {
        "story": {
            "story_id": story_ctx.get("story_id"),
            "story_uuid": story_ctx.get("story_uuid"),
            "story_title": story_ctx.get("story_title"),
            "contract": story.get("contract") or {},
        },
        "dependency_assessment": dependency_assessment,
        "implementation_planning": implementation_planning,
        "heuristic_test_cases": _build_test_cases(story),
        "local_setup": local_setup,
    }


def _run_test_design_agent(*, repo_root: Path, pipeline_root: Path, test_design_context: dict[str, Any]) -> tuple[TestDesignArtifact, Path]:
    artifact, envelope = run_agent_step(
        repo_root=repo_root,
        stage_name="implementation_test_design",
        strength="medium",
        output_model=TestDesignArtifact,
        context_payload=test_design_context,
        guidance=load_agentic_prompt_lines("implementation_test_design"),
        timeout_seconds=_test_design_timeout_seconds(),
    )
    return artifact, _persist_implementation_agent_run(pipeline_root=pipeline_root, node_id="testdesign", envelope=envelope)


class NormalizeNode(Node):
    async def process(self, task_context: TaskContext) -> TaskContext:
        repo_root = Path(task_context.event.repo_root)
        store, run_id = _store_run()
        story = dict(task_context.event.story)
        _dfs_node_running(repo_root=repo_root, story=story, run_id=run_id, node_id="normalize", summary="Normalizing story context")

        replay_state = _load_replay_stage_state(store=store, repo_root=repo_root, story=story, stage_id="normalize")
        if replay_state is not None:
            normalize_meta = _replay_artifact_metadata(replay_state, "normalize") or {
                "schema_version": 1,
                "story_uuid": task_context.event.story.get("story_id"),
                "title": task_context.event.story.get("title"),
            }
            _mark_replayed_node(store=store, run_id=run_id, node_id="normalize", node_name="Normalize", stage_state=replay_state, output={"artifact": "normalize"})
            task_context.metadata["normalize"] = normalize_meta
            task_context.metadata["repo_root"] = str(repo_root)
            return task_context

        node_exec_id = store.create_node_attempt(run_id=run_id, node_id="normalize", node_name="Normalize", attempt=1)
        normalize_meta = {
            "schema_version": 1,
            "story_uuid": task_context.event.story.get("story_id"),
            "title": task_context.event.story.get("title"),
        }
        store.add_artifact(run_id=run_id, node_exec_id=node_exec_id, kind="normalize", uri="db://artifacts/normalize", metadata=normalize_meta)
        store.mark_node_finished(node_exec_id=node_exec_id, status="succeeded", output={"artifact": "normalize"})

        task_context.metadata["normalize"] = normalize_meta
        task_context.metadata["repo_root"] = str(repo_root)
        return task_context


class SetupDocNode(AgentNode):
    """Model-backed node that generates .devflow/local_setup.json if missing or invalid."""

    def get_agent_config(self) -> AgentConfig:
        return AgentConfig(
            instructions="Explore the repository and produce a LocalSetupContract JSON describing how to start, stop, and health-check the project."
        )

    async def process(self, task_context: TaskContext) -> TaskContext:
        repo_root = Path(task_context.event.repo_root)
        store, run_id = _store_run()
        story = dict(task_context.event.story)
        _dfs_node_running(repo_root=repo_root, story=story, run_id=run_id, node_id="setupdoc", summary="Generating local setup contract")

        setup_json_path = repo_root / ".devflow" / "local_setup.json"
        setup_md_path = repo_root / ".devflow" / "local_setup.md"

        # Replay path
        replay_state = _load_replay_stage_state(store=store, repo_root=repo_root, story=story, stage_id="setupdoc")
        if replay_state is not None and setup_json_path.exists():
            try:
                existing = LocalSetupContract.model_validate_json(setup_json_path.read_text(encoding="utf-8"))
                if existing.schema_version == 1:
                    meta = {"schema_version": 1, "reused": True, "path": str(setup_json_path)}
                    _mark_replayed_node(store=store, run_id=run_id, node_id="setupdoc", node_name="SetupDoc", stage_state=replay_state, output={"artifact": "setupdoc", "setupdoc": meta})
                    task_context.metadata["setupdoc"] = meta
                    return task_context
            except Exception:
                pass  # fall through to generation

        # Reuse path: valid contract already on disk (no replay state needed)
        if setup_json_path.exists():
            try:
                existing = LocalSetupContract.model_validate_json(setup_json_path.read_text(encoding="utf-8"))
                if existing.schema_version == 1:
                    node_exec_id = store.create_node_attempt(run_id=run_id, node_id="setupdoc", node_name="SetupDoc", attempt=1)
                    meta = {"schema_version": 1, "reused": True, "path": str(setup_json_path)}
                    store.add_artifact(run_id=run_id, node_exec_id=node_exec_id, kind="setupdoc", uri=str(setup_json_path), metadata=meta)
                    store.mark_node_finished(node_exec_id=node_exec_id, status="succeeded", output={"artifact": "setupdoc", "setupdoc": meta})
                    task_context.metadata["setupdoc"] = meta
                    return task_context
            except Exception:
                pass

        # Agent-backed generation with up to 3 retry attempts
        story_ctx = _story_context(story)
        pipeline_root = _implementation_pipeline_root(repo_root=repo_root, story_id=str(story_ctx.get("story_id") or "unknown_story"))
        context_payload = {
            "repo_structure": _repo_structure_snapshot(repo_root),
            "runtime_setup_signals": _runtime_setup_signals(repo_root),
        }

        max_attempts = 3
        last_error = ""
        for attempt in range(1, max_attempts + 1):
            node_exec_id = store.create_node_attempt(run_id=run_id, node_id="setupdoc", node_name="SetupDoc", attempt=attempt)

            guidance = list(load_agentic_prompt_lines("implementation_setupdoc"))
            if last_error:
                guidance.append(f"Previous attempt failed validation: {last_error}. Fix the issue.")

            try:
                artifact, envelope = run_agent_step(
                    repo_root=repo_root,
                    stage_name="setupdoc",
        strength="light",
                    output_model=LocalSetupContract,
                    context_payload=context_payload,
                    guidance=guidance,
                    timeout_seconds=900,
                )
                _persist_implementation_agent_run(pipeline_root=pipeline_root, node_id="setupdoc", envelope=envelope)
            except Exception as exc:
                last_error = str(exc)[:500]
                store.mark_node_finished(node_exec_id=node_exec_id, status="failed", output={"error": last_error, "attempt": attempt})
                if attempt == max_attempts:
                    task_context.metadata["exit_code"] = 1
                    task_context.metadata["message"] = f"SetupDocNode failed after {max_attempts} attempts: {last_error}\n"
                    task_context.stop_workflow()
                    return task_context
                continue

            # Deterministic validation: schema_version must be 1
            if artifact.schema_version != 1:
                last_error = f"schema_version must be 1, got {artifact.schema_version}"
                store.mark_node_finished(node_exec_id=node_exec_id, status="failed", output={"error": last_error, "attempt": attempt})
                if attempt == max_attempts:
                    task_context.metadata["exit_code"] = 1
                    task_context.metadata["message"] = f"SetupDocNode failed after {max_attempts} attempts: {last_error}\n"
                    task_context.stop_workflow()
                    return task_context
                continue

            # Success — write machine contract and human-readable doc
            setup_json_path.parent.mkdir(parents=True, exist_ok=True)
            setup_json_path.write_text(artifact.model_dump_json(indent=2), encoding="utf-8")

            md_lines = [
                "# Local Setup Contract\n",
                f"**Start:** `{artifact.start_command}`\n",
                f"**Stop:** `{artifact.stop_command}`\n",
            ]
            if artifact.health_checks:
                md_lines.append("\n## Health Checks\n")
                for hc in artifact.health_checks:
                    md_lines.append(f"- **{hc.name}**: {hc.url} (expect {hc.expected_status})")
            if artifact.migration:
                md_lines.append("\n## Migration\n")
                md_lines.append(f"- **Run:** `{artifact.migration.command}`")
                md_lines.append(f"- **Check:** `{artifact.migration.check_command}`")
            if artifact.env_requirements:
                md_lines.append("\n## Env Requirements\n")
                for env_req in artifact.env_requirements:
                    md_lines.append(f"- `{env_req.path}` (required={env_req.required})")
            if artifact.git:
                md_lines.append("\n## Git\n")
                md_lines.append(f"- require_clean: {artifact.git.require_clean}")
            setup_md_path.write_text("\n".join(md_lines) + "\n", encoding="utf-8")

            meta = {"schema_version": 1, "reused": False, "path": str(setup_json_path)}
            store.add_artifact(run_id=run_id, node_exec_id=node_exec_id, kind="setupdoc", uri=str(setup_json_path), metadata=meta)
            store.mark_node_finished(node_exec_id=node_exec_id, status="succeeded", output={"artifact": "setupdoc", "setupdoc": meta})
            task_context.metadata["setupdoc"] = meta
            return task_context

        # Unreachable safety net
        task_context.metadata["exit_code"] = 1
        task_context.metadata["message"] = f"SetupDocNode exhausted {max_attempts} attempts\n"
        task_context.stop_workflow()
        return task_context


_DEFAULT_FATAL_LOG_PATTERNS = [
    r"ModuleNotFoundError",
    r"ImportError",
    r"Cannot find module",
    r"SyntaxError",
    r"cannot open shared object file",
]


def _get_docker_service_logs(service_name: str, repo_root: Path, lines: int = 50) -> str:
    """Get recent Docker logs for a service. Returns empty string on any failure."""
    try:
        result = subprocess.run(
            ["docker", "compose", "logs", "--no-color", "--tail", str(lines), service_name],
            cwd=str(repo_root), capture_output=True, text=True, check=False, timeout=10,
        )
        if result.returncode == 0 and result.stdout.strip():
            return result.stdout
        # Fallback: derive container name from compose convention
        safe_dir = repo_root.name.replace("_", "-")
        container_name = f"{safe_dir}-{service_name}-1"
        result2 = subprocess.run(
            ["docker", "logs", "--tail", str(lines), container_name],
            capture_output=True, text=True, check=False, timeout=10,
        )
        return result2.stdout + result2.stderr
    except Exception:
        return ""


def _logs_match_fatal_patterns(logs: str, patterns: list[str]) -> str | None:
    """Returns the first matching pattern string if found in logs, else None."""
    import re
    for pattern in patterns:
        if re.search(pattern, logs):
            return pattern
    return None


class PreflightNode(Node):
    """Deterministic node that reads .devflow/local_setup.json and verifies readiness."""

    async def process(self, task_context: TaskContext) -> TaskContext:
        import urllib.request
        import urllib.error

        repo_root = Path(task_context.event.repo_root)
        store, run_id = _store_run()
        story = dict(task_context.event.story)
        _dfs_node_running(repo_root=repo_root, story=story, run_id=run_id, node_id="preflight", summary="Running deterministic preflight checks")
        story_ctx = _story_context(story)

        # Replay path
        replay_state = _load_replay_stage_state(store=store, repo_root=repo_root, story=story, stage_id="preflight")
        if replay_state is not None:
            preflight = _replay_artifact_metadata(replay_state, "preflight") or {}
            _mark_replayed_node(store=store, run_id=run_id, node_id="preflight", node_name="Preflight", stage_state=replay_state, output={"preflight": preflight, "reused": True})
            task_context.metadata["preflight"] = preflight
            if str(preflight.get("effective_status", "")) != "ready":
                task_context.metadata["exit_code"] = 1
                task_context.metadata["message"] = str(task_context.metadata.get("message") or "") + f"preflight blocked: {json.dumps(preflight.get('blocking_issues') or [], sort_keys=True)}\n"
                task_context.stop_workflow()
            return task_context

        node_exec_id = store.create_node_attempt(run_id=run_id, node_id="preflight", node_name="Preflight", attempt=1)

        # Load contract (guaranteed valid by upstream SetupDocNode)
        setup_json_path = repo_root / ".devflow" / "local_setup.json"
        try:
            contract = LocalSetupContract.model_validate_json(setup_json_path.read_text(encoding="utf-8"))
        except Exception as exc:
            preflight_meta = {
                "schema_version": 3, "mode": "deterministic", "effective_status": "blocked",
                "blocking_issues": [{"kind": "setup_contract_missing", "message": f"Cannot read {setup_json_path}: {exc}"}],
            }
            store.mark_node_finished(node_exec_id=node_exec_id, status="failed", output={"preflight": preflight_meta})
            task_context.metadata["preflight"] = preflight_meta
            task_context.metadata["exit_code"] = 1
            task_context.metadata["message"] = "preflight blocked: setup contract invalid or missing\n"
            task_context.stop_workflow()
            return task_context

        blocking: list[dict[str, str]] = []

        # Step 1: Health checks
        def _check_health(hc: HealthCheckEntry) -> bool:
            try:
                req = urllib.request.Request(hc.url, method="GET")
                with urllib.request.urlopen(req, timeout=5) as resp:
                    return resp.status == hc.expected_status
            except Exception:
                return False

        initial_failures = [hc for hc in contract.health_checks if not _check_health(hc)]

        # Step 2: If any health checks fail, inspect logs and potentially repair or retry
        if initial_failures:
            # Inspect Docker logs for non-retryable fatal patterns before wasting retries
            fatal_match: str | None = None
            fatal_logs: str = ""
            for hc in initial_failures:
                service_hint = hc.name.split("-")[0]
                logs = _get_docker_service_logs(service_hint, repo_root)
                check_patterns = (
                    contract.on_health_fail_repair.patterns
                    if contract.on_health_fail_repair
                    else _DEFAULT_FATAL_LOG_PATTERNS
                )
                match = _logs_match_fatal_patterns(logs, check_patterns)
                if match:
                    fatal_match = match
                    fatal_logs = logs[-2000:]
                    break

            if fatal_match and contract.on_health_fail_repair:
                # Attempt repair per recipe
                repair = contract.on_health_fail_repair
                repaired = False
                for _attempt in range(max(1, repair.max_repair_attempts)):
                    for vol in repair.volume_reset:
                        subprocess.run(
                            ["docker", "volume", "rm", vol],
                            capture_output=True, check=False, timeout=30,
                        )
                    subprocess.run(
                        ["/bin/sh", "-lc", repair.repair_command],
                        cwd=str(repo_root), capture_output=True, text=True,
                        check=False, timeout=600,
                    )
                    subprocess.run(
                        ["/bin/sh", "-lc", contract.start_command],
                        cwd=str(repo_root), capture_output=True, text=True,
                        check=False, timeout=600,
                    )
                    time.sleep(15)
                    still_failing_after_repair = [hc for hc in contract.health_checks if not _check_health(hc)]
                    if not still_failing_after_repair:
                        repaired = True
                        initial_failures = []
                        break
                if not repaired:
                    blocking.append({
                        "kind": "fatal_dependency_error",
                        "message": (
                            f"Non-retryable service failure matched {fatal_match!r}. "
                            f"Repair attempted but failed. Log tail: {fatal_logs[-500:]}"
                        ),
                        "non_retryable": True,
                    })
                    preflight_meta = {
                        "schema_version": 3, "mode": "deterministic",
                        "effective_status": "blocked", "blocking_issues": blocking,
                    }
                    store.mark_node_finished(node_exec_id=node_exec_id, status="failed", output={"preflight": preflight_meta})
                    task_context.metadata["preflight"] = preflight_meta
                    task_context.metadata["exit_code"] = 1
                    task_context.metadata["message"] = f"preflight blocked (repair failed): {json.dumps(blocking, sort_keys=True)}\n"
                    task_context.stop_workflow()
                    return task_context

            elif fatal_match:
                # Fatal pattern but no repair recipe — hard block immediately
                blocking.append({
                    "kind": "fatal_import_or_dependency_error",
                    "message": (
                        f"Non-retryable failure in service logs matched {fatal_match!r}. "
                        f"No repair recipe in local_setup.json. Log tail: {fatal_logs[-500:]}"
                    ),
                    "non_retryable": True,
                })
                preflight_meta = {
                    "schema_version": 3, "mode": "deterministic",
                    "effective_status": "blocked", "blocking_issues": blocking,
                }
                store.mark_node_finished(node_exec_id=node_exec_id, status="failed", output={"preflight": preflight_meta})
                task_context.metadata["preflight"] = preflight_meta
                task_context.metadata["exit_code"] = 1
                task_context.metadata["message"] = f"preflight blocked (non-retryable): {json.dumps(blocking, sort_keys=True)}\n"
                task_context.stop_workflow()
                return task_context

            else:
                # No fatal pattern — existing retry logic
                subprocess.run(
                    ["/bin/sh", "-lc", contract.start_command],
                    cwd=str(repo_root), capture_output=True, text=True,
                    check=False, timeout=600,
                )
                still_failing = initial_failures
                for attempt in range(12):
                    still_failing = [hc for hc in contract.health_checks if not _check_health(hc)]
                    if not still_failing:
                        break
                    if attempt < 11:
                        time.sleep(5)
                for hc in still_failing:
                    blocking.append({
                        "kind": "health_check_failed",
                        "message": f"{hc.name}: {hc.url} did not return {hc.expected_status}",
                    })

        # Step 4: Run migration if present
        migration_meta: dict[str, Any] | None = None
        if contract.migration:
            migration_result = run_alembic_preflight(
                repo_root=repo_root,
                migration_command=contract.migration.command,
                check_command=contract.migration.check_command,
            )
            migration_meta = migration_result.to_metadata()
            if not migration_result.ok:
                blocking.extend(migration_result.validation_errors)

        # Step 5: Validate env_requirements files exist
        for env_req in contract.env_requirements:
            env_path = repo_root / env_req.path if not os.path.isabs(env_req.path) else Path(env_req.path)
            if env_req.required and not env_path.exists():
                blocking.append({"kind": "env_file_missing", "message": f"Required env file missing: {env_req.path}"})

        # Step 6: Check git.require_clean
        if contract.git and contract.git.require_clean:
            git_result = subprocess.run(["git", "status", "--porcelain"], cwd=str(repo_root), capture_output=True, text=True, check=False, timeout=15)
            if git_result.stdout.strip():
                blocking.append({"kind": "git_not_clean", "message": "git working tree is not clean"})

        ready = len(blocking) == 0
        preflight_meta = {
            "schema_version": 3,
            "story_id": story_ctx.get("story_id"),
            "mode": "deterministic",
            "effective_status": "ready" if ready else "blocked",
            "blocking_issues": blocking,
            "health_checks_verified": [{"name": hc.name, "url": hc.url} for hc in contract.health_checks],
            "migration_preflight": migration_meta,
        }
        report_path = _preflight_report_path(repo_root=repo_root, story_id=str(story_ctx.get("story_id") or "unknown_story"))
        _write_json(report_path, preflight_meta)
        store.add_artifact(
            run_id=run_id, node_exec_id=node_exec_id, kind="preflight", uri=str(report_path),
            metadata=preflight_meta, content_type="application/json",
            byte_size=len(json.dumps(preflight_meta, sort_keys=True)),
        )
        store.mark_node_finished(node_exec_id=node_exec_id, status="succeeded" if ready else "failed", output={"preflight": preflight_meta})
        task_context.metadata["preflight"] = preflight_meta
        if not ready:
            task_context.metadata["exit_code"] = 1
            task_context.metadata["message"] = str(task_context.metadata.get("message") or "") + f"preflight blocked: {json.dumps(blocking, sort_keys=True)}\n"
            task_context.stop_workflow()
        return task_context


class DependencyAssessmentNode(AgentNode):
    def get_agent_config(self) -> AgentConfig:
        return AgentConfig(
            instructions=(
                "Dependency assessment is a real GenAI gate: interpret story dependencies, canonical providers, and registry posture before implementation planning."
            )
        )

    async def process(self, task_context: TaskContext) -> TaskContext:
        repo_root = Path(task_context.event.repo_root)
        store, run_id = _store_run()
        story = dict(task_context.event.story)
        _dfs_node_running(repo_root=repo_root, story=story, run_id=run_id, node_id="dependencyassessment", summary="Assessing dependencies")
        story_ctx = _story_context(story)
        pipeline_root = _implementation_pipeline_root(repo_root=repo_root, story_id=str(story_ctx.get("story_id") or "unknown_story"))

        replay_state = _load_replay_stage_state(store=store, repo_root=repo_root, story=story, stage_id="dependencyassessment")
        if replay_state is not None:
            assessment = _replay_artifact_metadata(replay_state, "dependency_assessment") or {}
            _mark_replayed_node(
                store=store,
                run_id=run_id,
                node_id="dependencyassessment",
                node_name="DependencyAssessment",
                stage_state=replay_state,
                output={"assessment": assessment, "reused": True},
            )
            report_path = str((replay_state.get("node") or {}).get("output", {}).get("report_path") or assessment.get("agent_run_ref") or "")
            task_context.metadata["dependency_assessment"] = assessment
            if report_path:
                task_context.metadata["dependency_assessment_artifact"] = report_path
            return task_context

        node_exec_id = store.create_node_attempt(
            run_id=run_id,
            node_id="dependencyassessment",
            node_name="DependencyAssessment",
            attempt=1,
        )

        assessment_context = _build_dependency_assessment_context(repo_root=repo_root, store=store, story=story)
        decision, agent_run_path = _run_dependency_assessment_agent(
            repo_root=repo_root,
            pipeline_root=pipeline_root,
            assessment_context=assessment_context,
        )
        assessment = {
            "schema_version": 2,
            "story_id": story_ctx.get("story_id"),
            "story_uuid": story_ctx.get("story_uuid"),
            "story_title": story_ctx.get("story_title"),
            "mode": "model_backed",
            "agent_run_ref": str(agent_run_path),
            "outcome": decision.assessment_status,
            "summary": decision.summary,
            "internal_dependencies": decision.internal_dependencies,
            "external_dependencies": decision.external_dependencies,
            "unresolved_internal_dependencies": decision.unresolved_internal_dependencies,
            "blocked_external_dependencies": decision.blocked_external_dependencies,
            "deferred": decision.assessment_status != "ready",
            "inferred_capabilities": decision.inferred_capabilities,
            "preferred_pathways": decision.preferred_pathways,
            "blocking_issues": decision.blocking_issues,
            "downstream_contract": decision.downstream_contract,
            "lineage": {
                "heuristic_evidence": assessment_context.get("heuristic_evidence") or {},
                "model_backed": True,
            },
        }
        report_path = _dependency_assessment_report_path(
            repo_root=repo_root,
            run_id=run_id,
            story_id=str(story_ctx.get("story_id") or "unknown_story"),
        )
        _write_json(report_path, assessment)
        artifact_id = store.add_artifact(
            run_id=run_id,
            node_exec_id=node_exec_id,
            kind="dependency_assessment",
            uri=str(report_path),
            metadata=assessment,
            content_type="application/json",
            byte_size=len(json.dumps(assessment, sort_keys=True)),
        )

        task_context.metadata["dependency_assessment"] = assessment
        task_context.metadata["dependency_assessment_artifact"] = str(report_path)

        output = {
            "artifact_id": artifact_id,
            "report_path": str(report_path),
            "assessment": assessment,
        }
        store.mark_node_finished(node_exec_id=node_exec_id, status="succeeded", output=output)

        task_context.metadata["message"] = (
            str(task_context.metadata.get("message") or "")
            + f"dependency_assessment_report: {report_path}\n"
        )
        return task_context


class StoryImplementationPlanningNode(Node):
    async def process(self, task_context: TaskContext) -> TaskContext:
        repo_root = Path(task_context.event.repo_root)
        store, run_id = _store_run()
        story = dict(task_context.event.story)
        _dfs_node_running(repo_root=repo_root, story=story, run_id=run_id, node_id="storyimplementationplanning", summary="Planning implementation")
        story_ctx = _story_context(story)

        replay_state = _load_replay_stage_state(store=store, repo_root=repo_root, story=story, stage_id="storyimplementationplanning")
        if replay_state is not None:
            planning = _reconcile_implementation_planning_with_current_state(
                store=store,
                story=story,
                planning=_replay_artifact_metadata(replay_state, "implementation_planning") or {},
            )
            report_path = None
            for artifact in replay_state.get("artifacts") or []:
                if str(artifact.get("kind") or "") == "implementation_planning":
                    report_path = str(artifact.get("uri") or "") or None
            _mark_replayed_node(
                store=store,
                run_id=run_id,
                node_id="storyimplementationplanning",
                node_name="StoryImplementationPlanning",
                stage_state=replay_state,
                output={"planning": planning, "reused": True},
            )
            task_context.metadata["implementation_planning"] = planning
            if report_path:
                task_context.metadata["implementation_planning_artifact"] = report_path
            return task_context

        node_exec_id = store.create_node_attempt(
            run_id=run_id,
            node_id="storyimplementationplanning",
            node_name="StoryImplementationPlanning",
            attempt=1,
        )

        dependency_assessment = task_context.metadata.get("dependency_assessment") or {}
        planning, prerequisite_request, blocker = _build_implementation_planning(
            repo_root=repo_root,
            store=store,
            story=story,
            dependency_assessment=dependency_assessment,
        )
        planning = _reconcile_implementation_planning_with_current_state(
            store=store,
            story=story,
            planning=planning,
        )
        planning.setdefault("lineage", {})["dependency_assessment_artifact"] = task_context.metadata.get("dependency_assessment_artifact")
        report_path = _implementation_planning_report_path(repo_root=repo_root, story_id=str(story_ctx.get("story_id") or "unknown_story"))
        _write_json(report_path, planning)
        artifact_ids = {
            "implementation_planning": store.add_artifact(
                run_id=run_id,
                node_exec_id=node_exec_id,
                kind="implementation_planning",
                uri=str(report_path),
                metadata=planning,
                content_type="application/json",
                byte_size=len(json.dumps(planning, sort_keys=True)),
            )
        }

        if prerequisite_request is not None:
            prereq_path = _prerequisite_story_request_path(repo_root=repo_root, story_id=str(story_ctx.get("story_id") or "unknown_story"))
            _write_json(prereq_path, prerequisite_request)
            artifact_ids["prerequisite_story_request"] = store.add_artifact(
                run_id=run_id,
                node_exec_id=node_exec_id,
                kind="prerequisite_story_request",
                uri=str(prereq_path),
                metadata=prerequisite_request,
                content_type="application/json",
                byte_size=len(json.dumps(prerequisite_request, sort_keys=True)),
            )
        if blocker is not None:
            blocker_path = _blocker_artifact_path(repo_root=repo_root, story_id=str(story_ctx.get("story_id") or "unknown_story"))
            _write_json(blocker_path, blocker)
            artifact_ids["implementation_blocker"] = store.add_artifact(
                run_id=run_id,
                node_exec_id=node_exec_id,
                kind="implementation_blocker",
                uri=str(blocker_path),
                metadata=blocker,
                content_type="application/json",
                byte_size=len(json.dumps(blocker, sort_keys=True)),
            )

        if planning["queue_decision"].get("requeue_recommendation"):
            queue_row = _find_story_queue_row_for_story(store=store, story_id=str(story_ctx.get("story_id") or ""))
            if queue_row is not None and queue_row.get("project_id") and queue_row.get("story_artifact_id"):
                planning["queue_decision"]["requeue_story_queue_id"] = store.enqueue_story_task(
                    project_id=str(queue_row["project_id"]),
                    enqueue_run_id=run_id,
                    story_artifact_id=str(queue_row["story_artifact_id"]),
                    story_id=str(queue_row["story_id"]),
                    title=str(queue_row["title"]),
                )
                _write_json(report_path, planning)

        task_context.metadata["implementation_planning"] = planning
        task_context.metadata["implementation_planning_artifact"] = str(report_path)

        store.mark_node_finished(
            node_exec_id=node_exec_id,
            status="succeeded",
            output={"artifact_ids": artifact_ids, "planning": planning},
        )
        return task_context


class _RoutePlanningReady(RouterNode):
    def determine_next_node(self, task_context: TaskContext) -> Node | None:
        if (task_context.metadata.get("implementation_planning") or {}).get("planning_status") == "ready_for_implementation":
            return TestDesignNode(task_context=task_context)
        return None


class _RoutePlanningWaiting(RouterNode):
    def determine_next_node(self, task_context: TaskContext) -> Node | None:
        if (task_context.metadata.get("implementation_planning") or {}).get("planning_status") == "waiting_for_provider_story":
            return WaitingForProviderStoryNode(task_context=task_context)
        return None


class _RoutePlanningCreatePrerequisite(RouterNode):
    def determine_next_node(self, task_context: TaskContext) -> Node | None:
        if (task_context.metadata.get("implementation_planning") or {}).get("planning_status") == "create_prerequisite_story":
            return CreatePrerequisiteStoryNode(task_context=task_context)
        return None


class _RoutePlanningBlocked(RouterNode):
    def determine_next_node(self, task_context: TaskContext) -> Node | None:
        if (task_context.metadata.get("implementation_planning") or {}).get("planning_status") == "blocked":
            return BlockedImplementationNode(task_context=task_context)
        return None


class StoryImplementationPlanningRouter(BaseRouter):
    def __init__(self) -> None:
        self.routes = [
            _RoutePlanningReady(),
            _RoutePlanningWaiting(),
            _RoutePlanningCreatePrerequisite(),
            _RoutePlanningBlocked(),
        ]
        self.fallback = BlockedImplementationNode()


class WaitingForProviderStoryNode(Node):
    async def process(self, task_context: TaskContext) -> TaskContext:
        planning = task_context.metadata.get("implementation_planning") or {}
        task_context.metadata["exit_code"] = 1
        task_context.metadata["message"] = str(task_context.metadata.get("message") or "") + f"implementation planning queued story behind provider: {planning.get('queue_decision', {}).get('queue_after_story_id')}\n"
        task_context.stop_workflow()
        return task_context


class CreatePrerequisiteStoryNode(Node):
    async def process(self, task_context: TaskContext) -> TaskContext:
        planning = task_context.metadata.get("implementation_planning") or {}
        task_context.metadata["exit_code"] = 1
        task_context.metadata["message"] = str(task_context.metadata.get("message") or "") + "implementation planning requested prerequisite story creation before implementation\n"
        task_context.metadata["prerequisite_story_request"] = planning
        task_context.stop_workflow()
        return task_context


class BlockedImplementationNode(Node):
    async def process(self, task_context: TaskContext) -> TaskContext:
        planning = task_context.metadata.get("implementation_planning") or {}
        task_context.metadata["exit_code"] = 1
        task_context.metadata["message"] = str(task_context.metadata.get("message") or "") + f"implementation planning blocked story: {json.dumps(planning.get('blocking_issues') or [], sort_keys=True)}\n"
        task_context.stop_workflow()
        return task_context


class TestDesignNode(AgentNode):
    def get_agent_config(self) -> AgentConfig:
        return AgentConfig(
            instructions=(
                "TestDesign is a real GenAI node: derive story-scoped tests, oracles, and anchors from the implementation contract before Red."
            )
        )

    async def process(self, task_context: TaskContext) -> TaskContext:
        repo_root = Path(task_context.event.repo_root)
        store, run_id = _store_run()
        story = dict(task_context.event.story)
        _dfs_node_running(repo_root=repo_root, story=story, run_id=run_id, node_id="testdesign", summary="Designing tests")
        story_ctx = _story_context(story)
        pipeline_root = _implementation_pipeline_root(repo_root=repo_root, story_id=str(story_ctx.get("story_id") or "unknown_story"))

        replay_state = _load_replay_stage_state(store=store, repo_root=repo_root, story=story, stage_id="testdesign")
        if replay_state is not None:
            td_meta = _replay_artifact_metadata(replay_state, "test_design") or {}
            _persist_test_design_bundle_runtime_contracts(
                repo_root=repo_root,
                story=story,
                test_design=td_meta,
            )
            _mark_replayed_node(
                store=store,
                run_id=run_id,
                node_id="testdesign",
                node_name="TestDesign",
                stage_state=replay_state,
                output={"test_design": td_meta, "reused": True},
            )
            task_context.metadata["test_design"] = td_meta
            return task_context

        node_exec_id = store.create_node_attempt(run_id=run_id, node_id="testdesign", node_name="TestDesign", attempt=1)
        test_design_context = _build_test_design_context(
            story=story,
            dependency_assessment=task_context.metadata.get("dependency_assessment") or {},
            implementation_planning=task_context.metadata.get("implementation_planning") or {},
        )
        artifact, agent_run_path = _run_test_design_agent(
            repo_root=repo_root,
            pipeline_root=pipeline_root,
            test_design_context=test_design_context,
        )
        bundles = _normalize_test_design_bundles(repo_root=repo_root, story=story, artifact=artifact)
        td_meta = {
            "schema_version": 3,
            "mode": "model_backed",
            "agent_run_ref": str(agent_run_path),
            "story_id": story_ctx.get("story_id"),
            "story_uuid": story_ctx.get("story_uuid"),
            "summary": artifact.summary,
            "test_cases": _flatten_bundle_test_cases(bundles),
            "bundles": bundles,
            "design_notes": artifact.design_notes,
            "story_scoping_notes": artifact.story_scoping_notes,
            "must_cover": artifact.must_cover,
            "must_avoid": artifact.must_avoid,
            "dependency_assessment": task_context.metadata.get("dependency_assessment") or {},
            "implementation_planning": task_context.metadata.get("implementation_planning") or {},
        }
        td_artifact_id = store.add_artifact(
            run_id=run_id,
            node_exec_id=node_exec_id,
            kind="test_design",
            uri="db://artifacts/test_design",
            metadata=td_meta,
            content_type="application/json",
            byte_size=len(json.dumps(td_meta)),
        )
        _persist_test_design_bundle_runtime_contracts(
            repo_root=repo_root,
            story=story,
            test_design=td_meta,
        )
        task_context.metadata["test_design"] = td_meta
        store.mark_node_finished(node_exec_id=node_exec_id, status="succeeded", output={"artifact_id": td_artifact_id, "test_design": td_meta})
        return task_context


def _run_story_test_validator(
    *,
    engine_root: Path,
    repo_root: Path,
    story_id: str,
    report_path: Path | None = None,
    test_paths: list[str] | None = None,
    required_planes: list[str] | None = None,
) -> subprocess.CompletedProcess[str]:
    """Run the story-scoped test validator.

    Args:
        required_planes: When set, restricts the orphan_plane_coverage check to
            only these planes (passed as --plane flags). Use when validating a
            single bundle so sibling-bundle planes do not cause spurious failures.
    """
    env = dict(os.environ)
    env.setdefault("UV_CACHE_DIR", str(repo_root / ".devflow" / "uv-cache"))
    cmd = [
        sys.executable or "python3",
        "-m",
        "devflow_engine.story.validate_tests_story",
        story_id,
        "--repo-root",
        str(repo_root),
    ]
    if report_path is not None:
        cmd.extend(["--json", str(report_path)])
    for test_path in test_paths or []:
        cmd.extend(["--test-path", test_path])
    for plane in required_planes or []:
        cmd.extend(["--plane", plane])
    return subprocess.run(cmd, cwd=str(repo_root), text=True, capture_output=True, check=False, env=env)


def _write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def _red_sufficiency_report_path(*, repo_root: Path, run_id: str, story_id: str) -> Path:
    safe_story_id = re.sub(r"[^A-Za-z0-9_.-]+", "_", story_id) or "unknown_story"
    return repo_root / ".devflow" / "runs" / run_id / "red" / safe_story_id / "sufficiency_report.json"


def _load_json_report(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    return json.loads(path.read_text(encoding="utf-8"))


def _red_timeout_seconds() -> int:
    raw = os.environ.get("DEVFLOW_RED_AGENT_TIMEOUT")
    if not raw:
        return 1800
    try:
        value = int(raw)
    except ValueError:
        return 1800
    return value if value > 0 else 1800


def _detect_test_runtime_contract(repo_root: Path) -> dict[str, Any]:
    return infer_test_runtime_contract(repo_root)


_STORY_SCOPED_TEST_SUFFIXES = {".py", ".js", ".ts", ".jsx", ".tsx", ".mjs", ".cjs"}


def _story_test_search_roots(repo_root: Path) -> list[Path]:
    roots = [
        repo_root / "tests",
        repo_root / "fastapi_backend" / "tests",
        repo_root / "frontend" / "tests",
        repo_root / "backend" / "tests",
    ]
    deduped: list[Path] = []
    seen: set[Path] = set()
    for root in roots:
        normalized = root.resolve()
        if normalized in seen:
            continue
        seen.add(normalized)
        deduped.append(root)
    return deduped


def _discover_story_scoped_test_paths(*, repo_root: Path, story: dict[str, Any]) -> list[str]:
    story_ctx = _story_context(story)
    return discover_story_scoped_test_paths(
        repo_root=repo_root,
        story_id=str(story_ctx.get("story_id") or "").strip() or None,
        story_uuid=str(story_ctx.get("story_uuid") or "").strip() or None,
    )


def _resolve_story_test_runtime_contract(
    *,
    repo_root: Path,
    story: dict[str, Any],
    test_paths: list[str] | None = None,
    prefer_story_contract: bool = True,
) -> dict[str, Any]:
    story_ctx = _story_context(story)
    story_id = str(story_ctx.get("story_id") or "").strip()
    if not story_id:
        return _detect_test_runtime_contract(repo_root)
    return resolve_story_runtime_contract(
        repo_root=repo_root,
        story_id=story_id,
        story_uuid=str(story_ctx.get("story_uuid") or "").strip() or None,
        test_paths=test_paths,
        prefer_story_contract=prefer_story_contract,
    )


def _persist_story_test_runtime_contract(
    *,
    repo_root: Path,
    story: dict[str, Any],
    test_paths: list[str] | None = None,
    source: str | None = None,
    prefer_story_contract: bool = True,
) -> tuple[dict[str, Any], Path | None]:
    story_ctx = _story_context(story)
    story_id = str(story_ctx.get("story_id") or "").strip()
    if not story_id:
        return _detect_test_runtime_contract(repo_root), None
    contract = _resolve_story_test_runtime_contract(
        repo_root=repo_root,
        story=story,
        test_paths=test_paths,
        prefer_story_contract=prefer_story_contract,
    )
    if source:
        contract = dict(contract)
        contract["source"] = source
    path = persist_story_runtime_contract(repo_root=repo_root, contract=contract)
    return contract, path


def _candidate_run_cmds_for_framework(*, framework: str, preferred: list[str]) -> list[list[str]]:
    candidates: list[list[str]] = []

    def _append(cmd: list[str]) -> None:
        normalized = [str(part) for part in cmd if str(part).strip()]
        if normalized and normalized not in candidates:
            candidates.append(normalized)

    _append(preferred)
    normalized_framework = str(framework or "").strip().lower()
    if normalized_framework == "vitest":
        for cmd in (
            ["npx", "vitest", "run"],
            ["pnpm", "vitest", "run"],
            ["npm", "exec", "--", "vitest", "run"],
            ["vitest", "run"],
        ):
            _append(list(cmd))
    else:
        for cmd in (
            [sys.executable or "python3", "-m", "pytest"],
            ["python3", "-m", "pytest"],
            ["python", "-m", "pytest"],
            ["pytest"],
        ):
            _append(list(cmd))
    return candidates


def _completed_process_argv(args: Any) -> list[str]:
    if isinstance(args, (list, tuple)):
        return [str(item) for item in args if str(item).strip()]
    if isinstance(args, str) and args.strip():
        return [args]
    return []


def _runtime_probe_looks_working(*, completed: subprocess.CompletedProcess[str]) -> bool:
    if int(completed.returncode) not in {0, 1}:
        return False
    return _classify_invalid_red_runtime(
        stdout=str(completed.stdout or ""),
        stderr=str(completed.stderr or ""),
        returncode=int(completed.returncode),
    ) is None


def _probe_runtime_contract(
    *,
    repo_root: Path,
    runtime_contract: dict[str, Any],
    test_paths: list[str],
) -> tuple[subprocess.CompletedProcess[str] | None, str | None]:
    try:
        completed = _run_story_scoped_tests(
            repo_root=repo_root,
            runtime_contract=runtime_contract,
            test_paths=test_paths,
        )
    except FileNotFoundError as exc:
        return None, str(exc)
    except OSError as exc:
        return None, str(exc)
    return completed, None


def _runtime_contract_matches_verified_command(
    *,
    repo_root: Path,
    runtime_contract: dict[str, Any],
    verified_runtime_contract: dict[str, Any],
) -> bool:
    claimed_run_cmd = [str(item) for item in (runtime_contract.get("run_cmd") or []) if str(item).strip()]
    verified_run_cmd = [str(item) for item in (verified_runtime_contract.get("run_cmd") or []) if str(item).strip()]
    if not claimed_run_cmd or claimed_run_cmd != verified_run_cmd:
        return False
    return runtime_contract_cwd(repo_root=repo_root, runtime_contract=runtime_contract) == runtime_contract_cwd(
        repo_root=repo_root,
        runtime_contract=verified_runtime_contract,
    )


def _annotate_verified_runtime_contract(
    *,
    repo_root: Path,
    runtime_contract: dict[str, Any],
    verified_runtime_contract: dict[str, Any],
    test_paths: list[str],
    completed: subprocess.CompletedProcess[str],
) -> dict[str, Any]:
    annotated = dict(runtime_contract)
    verified_run_cmd = [str(item) for item in (verified_runtime_contract.get("run_cmd") or []) if str(item).strip()]
    argv = _completed_process_argv(completed.args) or [
        *verified_run_cmd,
        *runtime_contract_test_args(runtime_contract=verified_runtime_contract, test_paths=test_paths),
    ]
    runtime_cwd = runtime_contract_cwd(repo_root=repo_root, runtime_contract=verified_runtime_contract)
    command_verified = _runtime_contract_matches_verified_command(
        repo_root=repo_root,
        runtime_contract=runtime_contract,
        verified_runtime_contract=verified_runtime_contract,
    )
    annotated["command_verified"] = command_verified
    annotated["command_verification_mode"] = "canonical" if command_verified else "fallback"
    annotated["verified_run_cmd"] = list(verified_run_cmd)
    if verified_runtime_contract.get("source") or runtime_contract.get("source"):
        annotated["source"] = str(verified_runtime_contract.get("source") or runtime_contract.get("source") or "")
    annotated["canonical_test_cmd"] = argv
    try:
        annotated["canonical_test_cwd"] = str(runtime_cwd.relative_to(repo_root))
    except ValueError:
        annotated["canonical_test_cwd"] = str(runtime_cwd)
    return annotated


def _runtime_contract_execution_plan(
    *,
    repo_root: Path,
    runtime_contract: dict[str, Any],
    test_paths: list[str],
) -> tuple[list[str], Path]:
    canonical_test_cmd = [str(item) for item in (runtime_contract.get("canonical_test_cmd") or []) if str(item).strip()]
    canonical_test_cwd = str(runtime_contract.get("canonical_test_cwd") or "").strip()
    contract_test_paths = [str(path) for path in (runtime_contract.get("test_paths") or []) if str(path).strip()]
    verification_mode = str(runtime_contract.get("command_verification_mode") or "").strip().lower()
    has_verified_command_truth = bool(canonical_test_cmd) and (
        bool(runtime_contract.get("command_verified"))
        or bool(runtime_contract.get("verified_run_cmd"))
        or verification_mode in {"canonical", "fallback"}
    )
    use_canonical = has_verified_command_truth
    if use_canonical and contract_test_paths:
        use_canonical = contract_test_paths == [str(path) for path in test_paths if str(path).strip()]
    if use_canonical:
        runtime_cwd = Path(canonical_test_cwd) if canonical_test_cwd else runtime_contract_cwd(repo_root=repo_root, runtime_contract=runtime_contract)
        if not runtime_cwd.is_absolute():
            runtime_cwd = repo_root / runtime_cwd
        return canonical_test_cmd, runtime_cwd
    run_cmd = list(runtime_contract.get("run_cmd") or [sys.executable or "python3", "-m", "pytest"])
    runtime_cwd = runtime_contract_cwd(repo_root=repo_root, runtime_contract=runtime_contract)
    return [*run_cmd, *runtime_contract_test_args(runtime_contract=runtime_contract, test_paths=test_paths)], runtime_cwd


def _verify_story_runtime_contract(
    *,
    repo_root: Path,
    story: dict[str, Any],
    test_paths: list[str],
    source: str,
    prefer_story_contract: bool = True,
) -> tuple[dict[str, Any], subprocess.CompletedProcess[str], list[dict[str, Any]]]:
    base_contract = _resolve_story_test_runtime_contract(
        repo_root=repo_root,
        story=story,
        test_paths=test_paths,
        prefer_story_contract=prefer_story_contract,
    )
    detected_contract = normalize_story_runtime_contract(
        repo_root=repo_root,
        contract=_detect_test_runtime_contract(repo_root),
        story_id=str(base_contract.get("story_id") or _story_context(story).get("story_id") or ""),
        story_uuid=str(base_contract.get("story_uuid") or _story_context(story).get("story_uuid") or "").strip() or None,
        source="inferred",
    )
    candidate_contracts: list[dict[str, Any]] = []
    for candidate in (detected_contract, base_contract):
        for cmd in _candidate_run_cmds_for_framework(
            framework=str(candidate.get("framework") or base_contract.get("framework") or "pytest"),
            preferred=list(candidate.get("run_cmd") or []),
        ):
            proposal = dict(candidate)
            proposal["test_paths"] = [str(path) for path in test_paths if str(path).strip()]
            proposal["run_cmd"] = list(cmd)
            proposal["source"] = source
            if proposal not in candidate_contracts:
                candidate_contracts.append(proposal)

    attempts: list[dict[str, Any]] = []
    for candidate in candidate_contracts:
        completed, launch_error = _probe_runtime_contract(
            repo_root=repo_root,
            runtime_contract=candidate,
            test_paths=test_paths,
        )
        attempt: dict[str, Any] = {
            "run_cmd": list(candidate.get("run_cmd") or []),
            "cwd": str(candidate.get("cwd") or "."),
            "framework": str(candidate.get("framework") or ""),
        }
        if launch_error is not None:
            attempt["launch_error"] = launch_error
            attempts.append(attempt)
            continue
        if completed is None:
            attempt["launch_error"] = "unknown runtime probe failure"
            attempts.append(attempt)
            continue
        attempt["returncode"] = int(completed.returncode)
        attempt["stdout"] = _truncate_output(str(completed.stdout or ""), label="runtime probe stdout", limit=1000)
        attempt["stderr"] = _truncate_output(str(completed.stderr or ""), label="runtime probe stderr", limit=1000)
        attempt["working"] = _runtime_probe_looks_working(completed=completed)
        attempts.append(attempt)
        if attempt["working"]:
            return _annotate_verified_runtime_contract(
                repo_root=repo_root,
                runtime_contract=base_contract,
                verified_runtime_contract=candidate,
                test_paths=test_paths,
                completed=completed,
            ), completed, attempts
    attempted = "; ".join(" ".join(attempt.get("run_cmd") or []) for attempt in attempts) or "<none>"
    raise RuntimeError(f"unable to verify a working story test command; attempted: {attempted}")


def _establish_verified_story_test_runtime_contract(
    *,
    repo_root: Path,
    story: dict[str, Any],
    test_paths: list[str],
    source: str,
    prefer_story_contract: bool = True,
) -> tuple[dict[str, Any], Path | None, subprocess.CompletedProcess[str], list[dict[str, Any]]]:
    story_ctx = _story_context(story)
    story_id = str(story_ctx.get("story_id") or "").strip()
    if not story_id:
        contract = _detect_test_runtime_contract(repo_root)
        completed, launch_error = _probe_runtime_contract(repo_root=repo_root, runtime_contract=contract, test_paths=test_paths)
        if completed is None or launch_error is not None or not _runtime_probe_looks_working(completed=completed):
            raise RuntimeError(launch_error or "unable to verify a working story test command without story_id")
        verified = _annotate_verified_runtime_contract(
            repo_root=repo_root,
            runtime_contract=contract,
            verified_runtime_contract=contract,
            test_paths=test_paths,
            completed=completed,
        )
        return verified, None, completed, []
    verified, completed, attempts = _verify_story_runtime_contract(
        repo_root=repo_root,
        story=story,
        test_paths=test_paths,
        source=source,
        prefer_story_contract=prefer_story_contract,
    )
    path = persist_story_runtime_contract(repo_root=repo_root, contract=verified)
    return verified, path, completed, attempts


def _establish_verified_bundle_test_runtime_contract(
    *,
    repo_root: Path,
    story: dict[str, Any],
    bundle: dict[str, Any],
    test_paths: list[str],
    source: str,
) -> tuple[dict[str, Any], Path | None, subprocess.CompletedProcess[str], list[dict[str, Any]]]:
    story_ctx = _story_context(story)
    story_id = str(story_ctx.get("story_id") or "").strip()
    bundle_id = str(bundle.get("bundle_id") or "default")
    base_contract = _resolve_bundle_runtime_contract(
        repo_root=repo_root,
        story=story,
        bundle=bundle,
        test_paths=test_paths,
    )
    persisted_runtime_contract_path: Path | None = None
    if story_id:
        candidate_path = _bundle_runtime_contract_path(repo_root=repo_root, story_id=story_id, bundle_id=bundle_id)
        if candidate_path.exists() and candidate_path.is_file():
            persisted_runtime_contract_path = candidate_path
    if persisted_runtime_contract_path is not None:
        authoritative_args, _authoritative_cwd = _runtime_contract_execution_plan(
            repo_root=repo_root,
            runtime_contract=base_contract,
            test_paths=test_paths,
        )
        return (
            base_contract,
            persisted_runtime_contract_path,
            subprocess.CompletedProcess(args=authoritative_args, returncode=0, stdout="", stderr=""),
            [
                {
                    "bundle_id": bundle_id,
                    "run_cmd": list(base_contract.get("run_cmd") or []),
                    "cwd": str(base_contract.get("cwd") or "."),
                    "framework": str(base_contract.get("framework") or ""),
                    "authoritative_contract": True,
                    "skipped_probe": True,
                    "runtime_contract_path": str(persisted_runtime_contract_path),
                }
            ],
        )
    detected_contract = normalize_story_runtime_contract(
        repo_root=repo_root,
        contract=_detect_test_runtime_contract(repo_root),
        story_id=str(base_contract.get("story_id") or story_id),
        story_uuid=str(base_contract.get("story_uuid") or _story_context(story).get("story_uuid") or "").strip() or None,
        source="inferred",
        fallback=base_contract,
    )
    candidate_contracts: list[dict[str, Any]] = []
    for candidate in (detected_contract, base_contract):
        for cmd in _candidate_run_cmds_for_framework(
            framework=str(candidate.get("framework") or base_contract.get("framework") or "pytest"),
            preferred=list(candidate.get("run_cmd") or []),
        ):
            proposal = dict(candidate)
            proposal["test_paths"] = [str(path) for path in test_paths if str(path).strip()]
            proposal["run_cmd"] = list(cmd)
            proposal["source"] = source
            if proposal not in candidate_contracts:
                candidate_contracts.append(proposal)

    attempts: list[dict[str, Any]] = []
    for candidate in candidate_contracts:
        completed, launch_error = _probe_runtime_contract(
            repo_root=repo_root,
            runtime_contract=candidate,
            test_paths=test_paths,
        )
        attempt: dict[str, Any] = {
            "bundle_id": bundle_id,
            "run_cmd": list(candidate.get("run_cmd") or []),
            "cwd": str(candidate.get("cwd") or "."),
            "framework": str(candidate.get("framework") or ""),
        }
        if launch_error is not None:
            attempt["launch_error"] = launch_error
            attempts.append(attempt)
            continue
        if completed is None:
            attempt["launch_error"] = "unknown runtime probe failure"
            attempts.append(attempt)
            continue
        attempt["returncode"] = int(completed.returncode)
        attempt["stdout"] = _truncate_output(str(completed.stdout or ""), label="runtime probe stdout", limit=1000)
        attempt["stderr"] = _truncate_output(str(completed.stderr or ""), label="runtime probe stderr", limit=1000)
        attempt["working"] = _runtime_probe_looks_working(completed=completed)
        attempts.append(attempt)
        if attempt["working"]:
            verified = _annotate_verified_runtime_contract(
                repo_root=repo_root,
                runtime_contract=base_contract,
                verified_runtime_contract=candidate,
                test_paths=test_paths,
                completed=completed,
            )
            if not story_id:
                return verified, None, completed, attempts
            path = _bundle_runtime_contract_path(repo_root=repo_root, story_id=story_id, bundle_id=bundle_id)
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(json.dumps(verified, indent=2, sort_keys=True) + "\n", encoding="utf-8")
            return verified, path, completed, attempts

    attempted = "; ".join(" ".join(attempt.get("run_cmd") or []) for attempt in attempts) or "<none>"
    raise RuntimeError(f"unable to verify a working bundle test command for {bundle_id}; attempted: {attempted}")


def _run_story_scoped_tests(*, repo_root: Path, runtime_contract: dict[str, Any], test_paths: list[str]) -> subprocess.CompletedProcess[str]:
    run_cmd = list(runtime_contract.get("run_cmd") or [sys.executable or "python3", "-m", "pytest"])
    if not test_paths:
        return subprocess.CompletedProcess(
            args=run_cmd,
            returncode=1,
            stdout="",
            stderr="No story-scoped tests discovered for story gate.",
        )
    setup_cmd = list(runtime_contract.get("setup_cmd") or [])
    env = runtime_contract_env(runtime_contract)
    argv, runtime_cwd = _runtime_contract_execution_plan(
        repo_root=repo_root,
        runtime_contract=runtime_contract,
        test_paths=test_paths,
    )
    if setup_cmd:
        setup_cp = _run_cmd_in_dir(
            repo_root,
            setup_cmd,
            cwd=runtime_cwd,
            env=env,
        )
        if setup_cp.returncode != 0:
            return setup_cp
    return _run_cmd_in_dir(
        repo_root,
        argv,
        cwd=runtime_cwd,
        env=env,
    )


def _run_story_scoped_gate(
    *,
    repo_root: Path,
    story: dict[str, Any],
    registered_test_paths: list[str] | None = None,
    trust_red_contract: bool = False,
) -> tuple[dict[str, GateResult], dict[str, Any]]:
    engine_root = Path(__file__).resolve().parents[3]
    story_ctx = _story_context(story)
    story_id = str(story_ctx.get("story_id") or "").strip()
    test_paths = [str(path) for path in (registered_test_paths or []) if str(path).strip()]
    runtime_contract = _resolve_story_test_runtime_contract(repo_root=repo_root, story=story, test_paths=test_paths or None)
    if not test_paths:
        test_paths = [str(path) for path in (runtime_contract.get("test_paths") or []) if str(path).strip()]
    if not test_paths:
        test_paths = _discover_story_scoped_test_paths(repo_root=repo_root, story=story)
        runtime_contract, _runtime_path = _persist_story_test_runtime_contract(
            repo_root=repo_root,
            story=story,
            test_paths=test_paths,
            source="story_runtime_contract",
        )
    elif list(runtime_contract.get("test_paths") or []) != test_paths and story_id:
        runtime_contract, _runtime_path = _persist_story_test_runtime_contract(
            repo_root=repo_root,
            story=story,
            test_paths=test_paths,
            source=str(runtime_contract.get("source") or "story_runtime_contract"),
        )

    if story_id and not trust_red_contract:
        validator_cp = _run_story_test_validator(
            engine_root=engine_root,
            repo_root=repo_root,
            story_id=story_id,
            test_paths=test_paths,
        )
    else:
        validator_cp = subprocess.CompletedProcess(
            args=["validator"],
            returncode=2,
            stdout="",
            stderr="Missing story_id for story-scoped validation.",
        )
    test_cp = _run_story_scoped_tests(repo_root=repo_root, runtime_contract=runtime_contract, test_paths=test_paths)

    results = {
        "story_tests": GateResult(
            ok=test_cp.returncode == 0,
            stdout=test_cp.stdout,
            stderr=test_cp.stderr,
            returncode=test_cp.returncode,
        ),
    }
    validator_payload = (
        {
            "ok": True,
            "trusted_redreview_contract": True,
            "source": "accepted_red_artifacts",
            "returncode": 0,
            "stdout": "",
            "stderr": "",
        }
        if trust_red_contract
        else {
            "ok": validator_cp.returncode == 0,
            "returncode": validator_cp.returncode,
            "stdout": validator_cp.stdout,
            "stderr": validator_cp.stderr,
        }
    )
    if not trust_red_contract:
        results["story_test_validation"] = GateResult(
            ok=validator_cp.returncode == 0,
            stdout=validator_cp.stdout,
            stderr=validator_cp.stderr,
            returncode=validator_cp.returncode,
        )
    verification_path: str | None = None
    if story_id:
        _verification, verification_file = record_story_verification(
            repo_root=repo_root,
            story_id=story_id,
            story_uuid=str(story_ctx.get("story_uuid") or "").strip() or None,
            source="story_scoped_gate",
            test_paths=test_paths,
            validator=validator_payload,
            tests={
                "ok": results["story_tests"].ok,
                "returncode": results["story_tests"].returncode,
                "stdout": results["story_tests"].stdout,
                "stderr": results["story_tests"].stderr,
            },
        )
        verification_path = str(verification_file)
    gate_meta = {
        "story_id": story_id,
        "test_paths": test_paths,
        "runtime_framework": runtime_contract.get("framework"),
        "run_cmd": list(runtime_contract.get("run_cmd") or []),
        "runtime_contract_path": None if not story_id else str(story_test_runtime_contract_path(repo_root=repo_root, story_id=story_id)),
        "runtime_contract_source": runtime_contract.get("source"),
        "verification_path": verification_path,
    }
    return results, gate_meta


def _green_timeout_seconds() -> int:
    raw = os.environ.get("DEVFLOW_GREEN_AGENT_TIMEOUT")
    if not raw:
        return 1800
    try:
        value = int(raw)
    except ValueError:
        return 1800
    return value if value > 0 else 1800


def _green_max_iterations() -> int:
    raw = os.environ.get("DEVFLOW_GREEN_MAX_ITERATIONS")
    if not raw:
        return 3
    try:
        value = int(raw)
    except ValueError:
        return 3
    return value if value > 0 else 3


def _refactor_timeout_seconds() -> int:
    raw = os.environ.get("DEVFLOW_REFACTOR_AGENT_TIMEOUT")
    if not raw:
        return 1800
    try:
        value = int(raw)
    except ValueError:
        return 1800
    return value if value > 0 else 1800


def _security_timeout_seconds() -> int:
    raw = os.environ.get("DEVFLOW_SECURITY_AGENT_TIMEOUT")
    if not raw:
        return 1800
    try:
        value = int(raw)
    except ValueError:
        return 1800
    return value if value > 0 else 1800


def _refactor_max_iterations() -> int:
    raw = os.environ.get("DEVFLOW_REFACTOR_MAX_ITERATIONS")
    if not raw:
        return 2
    try:
        value = int(raw)
    except ValueError:
        return 2
    return value if value > 0 else 2




def _summarize_prior_passes(prior_passes: list[dict[str, Any]]) -> list[dict[str, Any]]:
    summaries: list[dict[str, Any]] = []
    for item in prior_passes:
        assessment = item.get("assessment") if isinstance(item.get("assessment"), dict) else {}
        validator_report = item.get("validator_report") if isinstance(item.get("validator_report"), dict) else {}
        summaries.append({
            "pass_index": item.get("pass_index"),
            "agent_run_ref": item.get("agent_run_ref"),
            "generation_summary": item.get("generation_summary"),
            "generation_notes": list(item.get("generation_notes") or [])[:6],
            "written_paths": list(item.get("written_paths") or [])[:12],
            "validator_input_paths": list(item.get("validator_input_paths") or [])[:12],
            "validator_returncode": item.get("validator_returncode"),
            "pytest_returncode": item.get("pytest_returncode"),
            "assessment": {
                "outcome": assessment.get("outcome"),
                "passed": assessment.get("passed"),
                "test_validation_passed": assessment.get("test_validation_passed"),
                "pytest_passed": assessment.get("pytest_passed"),
            },
            "validator_report": {
                "outcome": validator_report.get("outcome"),
                "orphan_plane_coverage": validator_report.get("orphan_plane_coverage"),
                "unknown_story_id": validator_report.get("unknown_story_id"),
                "missing_story_oracles": validator_report.get("missing_story_oracles"),
                "errors": validator_report.get("errors"),
            },
            "pytest_stdout_excerpt": _truncate_output(str(item.get("pytest_stdout") or ""), label="pytest stdout", limit=4000),
            "pytest_stderr_excerpt": _truncate_output(str(item.get("pytest_stderr") or ""), label="pytest stderr", limit=2000),
            "validator_stdout_excerpt": _truncate_output(str(item.get("validator_stdout") or ""), label="validator stdout", limit=2000),
            "validator_stderr_excerpt": _truncate_output(str(item.get("validator_stderr") or ""), label="validator stderr", limit=2000),
        })
    return summaries

def _build_red_generation_context(*, repo_root: Path, story: dict[str, Any], test_design: dict[str, Any], implementation_planning: dict[str, Any], prior_passes: list[dict[str, Any]]) -> dict[str, Any]:
    story_ctx = _story_context(story)
    contract = dict(story.get("contract") or {})
    runtime_contract = _resolve_story_test_runtime_contract(repo_root=repo_root, story=story)

    story_uuid = story_ctx.get("story_uuid") or ""
    story_id_str = story_ctx.get("story_id") or ""

    existing_tests: list[dict[str, Any]] = []
    test_search_roots = [
        repo_root / "tests",
        repo_root / "fastapi_backend" / "tests",
        repo_root / "frontend" / "tests",
        repo_root / "backend" / "tests",
    ]
    for tests_dir in test_search_roots:
        if not tests_dir.exists():
            continue
        for path in sorted(tests_dir.rglob("*")):
            if not path.is_file() or path.name.startswith("."):
                continue
            if path.suffix not in {".py", ".js", ".ts", ".jsx", ".tsx", ".mjs", ".cjs"}:
                continue
            try:
                content = path.read_text(encoding="utf-8")
                if (story_uuid and story_uuid in content) or (story_id_str and story_id_str in content):
                    existing_tests.append({"path": str(path.relative_to(repo_root)), "content": content})
            except Exception:
                continue
    context = {
        "story": {
            "story_id": story_ctx.get("story_id"),
            "story_uuid": story_ctx.get("story_uuid"),
            "story_title": story_ctx.get("story_title"),
            "contract": contract,
        },
        "test_design": _compact_test_design(test_design),
        "implementation_planning": implementation_planning,
        "test_runtime_contract": runtime_contract,
        "existing_tests": existing_tests,
        "prior_passes": _summarize_prior_passes(prior_passes),
    }
    if any(
        str((item.get("assessment") or {}).get("outcome") or "").strip() == "runtime_command_unverified"
        for item in prior_passes
        if isinstance(item, dict)
    ):
        context["success_pattern_docs"] = _load_repo_success_pattern_docs(repo_root=repo_root)
    return context


def _run_red_agent(*, repo_root: Path, pipeline_root: Path, red_generation_context: dict[str, Any], node_ref: str = "red") -> tuple[RedTestGenerationArtifact, Path]:
    artifact, envelope = run_agent_step(
        repo_root=repo_root,
        stage_name="implementation_red",
        strength="medium",
        output_model=RedTestGenerationArtifact,
        context_payload=red_generation_context,
        guidance=load_agentic_prompt_lines("implementation_red"),
        timeout_seconds=_red_timeout_seconds(),
    )
    return artifact, _persist_implementation_agent_run(pipeline_root=pipeline_root, node_id=node_ref, envelope=envelope)


# Matches known LLM placeholder phrases emitted instead of actual file content, e.g.:
#   "see file written above", "see written file above", "see written file"
#   "(written above)", "(written)", "see above", "(see written file)"
_RED_FILE_PLACEHOLDER_RE = re.compile(
    r"^\W*(?:"
    r"see\s+(?:file\s+written|written\s+file)(?:\s+above)?"
    r"|written\s+above"
    r"|see\s+above"
    r"|\(written(?:\s+above)?\)"
    r"|\(see\s+(?:file\s+written|written\s+file|above)\)"
    r")\W*$",
    re.IGNORECASE,
)

_RED_PLACEHOLDER_KEYWORDS = frozenset({"import", "def ", "class ", "test_", "describe(", "it(", "expect(", "assert"})


def _is_red_test_placeholder_content(content: str) -> bool:
    stripped = content.strip()
    if not stripped:
        return False
    # Short strings that could be placeholders but aren't empty
    if len(stripped) < 50 and _RED_FILE_PLACEHOLDER_RE.fullmatch(stripped):
        return True
    # Defensive heuristic: very short single-line strings with no code keywords are likely
    # novel placeholder variants not yet covered by the regex (e.g. "(written above)").
    if len(stripped) < 100 and "\n" not in stripped:
        if not any(kw in stripped for kw in _RED_PLACEHOLDER_KEYWORDS):
            return True
    return False


def _apply_red_test_generation(*, repo_root: Path, artifact: RedTestGenerationArtifact) -> list[str]:
    pending_writes: list[tuple[Path, Path, str]] = []
    written_paths: list[str] = []
    for file in artifact.files:
        rel = Path(file.path)
        if rel.is_absolute() or ".." in rel.parts:
            raise ValueError(f"red generated invalid path: {file.path}")
        content = file.content
        if _is_red_test_placeholder_content(content):
            # The agent wrote the file to disk via a tool call but emitted a placeholder
            # in the structured response content field. Fall back to the on-disk version
            # if it exists and is non-trivial (> 100 chars).
            on_disk = repo_root / rel
            if on_disk.is_file():
                disk_content = on_disk.read_text(encoding="utf-8")
                if len(disk_content.strip()) > 100 and not _is_red_test_placeholder_content(disk_content):
                    content = disk_content
                else:
                    raise ValueError(f"red generated placeholder content for path: {file.path}")
            else:
                raise ValueError(f"red generated placeholder content for path: {file.path}")
        if rel.suffix == ".py":
            content = _normalize_red_python_test_content(file_path=file.path, content=content)
        dest = repo_root / rel
        pending_writes.append((rel, dest, content))
    for rel, dest, content in pending_writes:
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_text(content, encoding="utf-8")
        written_paths.append(str(rel))
    return written_paths


def _build_bundle_red_generation_context(
    *,
    repo_root: Path,
    story: dict[str, Any],
    test_design: dict[str, Any],
    bundle: dict[str, Any],
    implementation_planning: dict[str, Any],
    prior_passes: list[dict[str, Any]],
) -> dict[str, Any]:
    context = _build_red_generation_context(
        repo_root=repo_root,
        story=story,
        test_design=test_design,
        implementation_planning=implementation_planning,
        prior_passes=prior_passes,
    )
    context["bundle"] = dict(bundle)
    context["bundle_runtime_contract"] = _resolve_bundle_runtime_contract(repo_root=repo_root, story=story, bundle=bundle)
    return context


def _red_bundle_attempt_artifact_path(*, pipeline_root: Path, bundle_id: str, attempt: int) -> Path:
    return pipeline_root / "red_bundle_attempts" / _safe_bundle_id(bundle_id) / f"attempt_{attempt:03d}.json"


def _persist_red_bundle_attempt_artifact(
    *,
    pipeline_root: Path,
    bundle: dict[str, Any],
    attempt: int,
    artifact: RedTestGenerationArtifact,
    agent_run_path: Path,
    apply_error: str | None = None,
    written_paths: list[str] | None = None,
) -> Path:
    bundle_id = str(bundle.get("bundle_id") or "default")
    path = _red_bundle_attempt_artifact_path(pipeline_root=pipeline_root, bundle_id=bundle_id, attempt=attempt)
    payload = {
        "bundle_id": bundle_id,
        "attempt": attempt,
        "runtime_family": str(bundle.get("runtime_family") or "default"),
        "planes": list(bundle.get("planes") or []),
        "agent_run_ref": str(agent_run_path),
        "artifact": artifact.model_dump(),
        "apply_error": apply_error,
        "written_paths": list(written_paths or []),
    }
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return path


def _run_red_bundle_generation_with_repair_loop(
    *,
    repo_root: Path,
    pipeline_root: Path,
    story: dict[str, Any],
    bundle: dict[str, Any],
    test_design: dict[str, Any],
    implementation_planning: dict[str, Any],
    max_attempts: int = 3,
) -> dict[str, Any]:
    bundle_id = str(bundle.get("bundle_id") or "default")
    attempt_history: list[dict[str, Any]] = []
    latest_error: str | None = None
    last_agent_run_ref: str | None = None
    last_attempt_artifact_path: str | None = None

    for attempt in range(1, max_attempts + 1):
        prior_passes = list(attempt_history)
        red_generation_context = _build_bundle_red_generation_context(
            repo_root=repo_root,
            story=story,
            test_design=test_design,
            bundle=bundle,
            implementation_planning=implementation_planning,
            prior_passes=prior_passes,
        )
        if latest_error:
            red_generation_context["bundle_failure"] = {
                "bundle_id": bundle_id,
                "attempt": attempt - 1,
                "error": latest_error,
                "prior_attempts": prior_passes,
            }
        generated_tests, agent_run_path = _run_red_agent(
            repo_root=repo_root,
            pipeline_root=pipeline_root,
            red_generation_context=red_generation_context,
            node_ref=(
                f"red.{_safe_bundle_id(bundle_id)}"
                if attempt == 1
                else f"red.{_safe_bundle_id(bundle_id)}.repair_{attempt}"
            ),
        )
        last_agent_run_ref = str(agent_run_path)
        try:
            written_paths = _apply_red_test_generation(repo_root=repo_root, artifact=generated_tests)
            attempt_artifact_path = _persist_red_bundle_attempt_artifact(
                pipeline_root=pipeline_root,
                bundle=bundle,
                attempt=attempt,
                artifact=generated_tests,
                agent_run_path=agent_run_path,
                apply_error=None,
                written_paths=written_paths,
            )
            last_attempt_artifact_path = str(attempt_artifact_path)
            runtime_contract, runtime_contract_path, _command_probe, command_attempts = _establish_verified_bundle_test_runtime_contract(
                repo_root=repo_root,
                story=story,
                bundle=bundle,
                test_paths=written_paths,
                source=f"red_bundle:{bundle_id}",
            )
            return {
                "bundle_id": bundle_id,
                "runtime_family": str(bundle.get("runtime_family") or "default"),
                "planes": list(bundle.get("planes") or []),
                "agent_run_ref": str(agent_run_path),
                "summary": generated_tests.summary,
                "notes": list(generated_tests.notes or []),
                "written_paths": written_paths,
                "runtime_contract": runtime_contract,
                "runtime_contract_path": None if runtime_contract_path is None else str(runtime_contract_path),
                "verified_command_probe": {
                    "returncode": int(_command_probe.returncode),
                    "stdout": _truncate_output(str(_command_probe.stdout or ""), label="runtime probe stdout", limit=1000),
                    "stderr": _truncate_output(str(_command_probe.stderr or ""), label="runtime probe stderr", limit=1000),
                    "attempts": command_attempts,
                },
                "attempts_used": attempt,
                "status": "succeeded",
                "attempt_history": attempt_history + [
                    {
                        "attempt": attempt,
                        "status": "succeeded",
                        "error": None,
                        "agent_run_ref": str(agent_run_path),
                        "artifact_path": str(attempt_artifact_path),
                        "written_paths": written_paths,
                    }
                ],
            }
        except Exception as exc:
            latest_error = str(exc)
            attempt_artifact_path = _persist_red_bundle_attempt_artifact(
                pipeline_root=pipeline_root,
                bundle=bundle,
                attempt=attempt,
                artifact=generated_tests,
                agent_run_path=agent_run_path,
                apply_error=latest_error,
                written_paths=[],
            )
            last_attempt_artifact_path = str(attempt_artifact_path)
            attempt_history.append(
                {
                    "attempt": attempt,
                    "status": "failed",
                    "error": latest_error,
                    "agent_run_ref": str(agent_run_path),
                    "artifact_path": str(attempt_artifact_path),
                    "written_paths": [],
                    "summary": generated_tests.summary,
                    "notes": list(generated_tests.notes or []),
                }
            )

    return {
        "bundle_id": bundle_id,
        "runtime_family": str(bundle.get("runtime_family") or "default"),
        "planes": list(bundle.get("planes") or []),
        "agent_run_ref": last_agent_run_ref,
        "summary": "",
        "notes": [],
        "written_paths": [],
        "runtime_contract": {},
        "runtime_contract_path": None,
        "attempts_used": max_attempts,
        "status": "failed",
        "error": latest_error,
        "failed_bundle": True,
        "artifact_path": last_attempt_artifact_path,
        "attempt_history": attempt_history,
    }


_INVALID_RED_RUNTIME_PATTERNS = (
    r"SyntaxError",
    r"ModuleNotFoundError",
    r"ImportError",
    r"Cannot find module",
    r"ERROR collecting",
    r"Failed to import test module",
    r"collection .*? error",
    r"No story-scoped tests discovered",
)


_MISSING_TARGET_IMPLEMENTATION_PATTERNS = (
    r"Cannot find module ['\"](\.{1,2}/[^'\"]+)['\"]",
    r"Failed to resolve import ['\"](\.{1,2}/[^'\"]+)['\"]",
)


def _is_missing_target_implementation_runtime(*, stdout: str, stderr: str) -> bool:
    combined = f"{stdout}\n{stderr}"
    return any(
        re.search(pattern, combined, re.IGNORECASE)
        for pattern in _MISSING_TARGET_IMPLEMENTATION_PATTERNS
    )


def _classify_invalid_red_runtime(*, stdout: str, stderr: str, returncode: int) -> str | None:
    if returncode == 0:
        return None
    if _is_missing_target_implementation_runtime(stdout=stdout, stderr=stderr):
        return None
    combined = f"{stdout}\n{stderr}"
    for pattern in _INVALID_RED_RUNTIME_PATTERNS:
        if re.search(pattern, combined, re.IGNORECASE):
            return pattern
    return None


def _redreview_timeout_seconds() -> int:
    raw = os.environ.get("DEVFLOW_RED_REVIEW_AGENT_TIMEOUT")
    if not raw:
        return 900
    try:
        value = int(raw)
    except ValueError:
        return 900
    return value if value > 0 else 900


def _load_redreview_candidate_files(*, repo_root: Path, written_paths: list[str]) -> list[dict[str, Any]]:
    candidates: list[dict[str, Any]] = []
    for raw in written_paths:
        rel = Path(raw)
        if rel.is_absolute() or ".." in rel.parts:
            continue
        path = repo_root / rel
        if not path.exists() or not path.is_file():
            continue
        candidates.append({"path": str(rel), "content": path.read_text(encoding="utf-8")})
    return candidates


_SUCCESS_PATTERN_DOC_CANDIDATES = (
    "README.md",
    "scripts/validate_tests_story.py",
    "scripts/validate_tests.py",
    "docs/story-implementation-planning-node.md",
    "ai_docs/context/v2/project_docs/user_stories/area6_implementation_dag/implementation-dag-core.md",
    "ai_docs/context/v2/project_docs/user_stories/area6_implementation_dag/stage-red-failing-tests.md",
    "ai_docs/context/v2/project_docs/user_stories/area6_implementation_dag/stage-validate-tests.md",
    "ai_docs/context/v2/project_docs/user_stories/area6_implementation_dag/stage-green-implement-and-gate.md",
)


def _load_repo_success_pattern_docs(*, repo_root: Path, limit: int = 4) -> list[dict[str, str]]:
    docs: list[dict[str, str]] = []
    for raw in _SUCCESS_PATTERN_DOC_CANDIDATES:
        path = repo_root / raw
        if not path.exists() or not path.is_file():
            continue
        try:
            content = path.read_text(encoding="utf-8")
        except Exception:
            continue
        docs.append(
            {
                "path": raw,
                "excerpt": _truncate_output(content, label=f"success pattern doc: {raw}", limit=2000),
            }
        )
        if len(docs) >= limit:
            break
    return docs


def _runtime_command_repair_assessment(*, message: str) -> dict[str, Any]:
    return {
        "outcome": "runtime_command_unverified",
        "passed": False,
        "stop_workflow": True,
        "message": f"story-scoped runtime command is still unresolved: {message}",
    }


def _build_redreview_context(*, repo_root: Path, story: dict[str, Any], red_generation: dict[str, Any], test_design: dict[str, Any], implementation_planning: dict[str, Any], prior_passes: list[dict[str, Any]]) -> dict[str, Any]:
    story_ctx = _story_context(story)
    candidate_paths = list(red_generation.get("written_paths") or [])
    return {
        "story": {
            "story_id": story_ctx.get("story_id"),
            "story_uuid": story_ctx.get("story_uuid"),
            "story_title": story_ctx.get("story_title"),
            "contract": dict(story.get("contract") or {}),
        },
        "allowable_planes": list(ALLOWED_PLANES),
        "red_generation": red_generation,
        "test_design": _compact_test_design(test_design),
        "implementation_planning": implementation_planning,
        "candidate_test_files": _load_redreview_candidate_files(repo_root=repo_root, written_paths=candidate_paths),
        "success_pattern_docs": _load_repo_success_pattern_docs(repo_root=repo_root),
        "prior_passes": _summarize_prior_passes(prior_passes),
    }


def _run_redreview_agent(*, repo_root: Path, pipeline_root: Path, redreview_context: dict[str, Any], node_ref: str = "redreview") -> tuple[RedReviewArtifact, Path]:
    artifact, envelope = run_agent_step(
        repo_root=repo_root,
        stage_name="implementation_redreview",
        strength="medium",
        output_model=RedReviewArtifact,
        context_payload=redreview_context,
        guidance=load_agentic_prompt_lines("implementation_redreview"),
        timeout_seconds=_redreview_timeout_seconds(),
    )
    return artifact, _persist_implementation_agent_run(pipeline_root=pipeline_root, node_id=node_ref, envelope=envelope)


_REDREVIEW_LOCAL_QUALITY_OUTCOMES = {"insufficient_story_tests", "greenwashed_green", "invalid_red_artifact", "runtime_command_unverified"}


def _is_redreview_local_quality_outcome(assessment: dict[str, Any] | None) -> bool:
    outcome = str((assessment or {}).get("outcome") or "").strip()
    return outcome in _REDREVIEW_LOCAL_QUALITY_OUTCOMES


def _build_redreview_repair_context(
    *,
    repo_root: Path,
    story: dict[str, Any],
    red_generation: dict[str, Any],
    test_design: dict[str, Any],
    implementation_planning: dict[str, Any],
    prior_passes: list[dict[str, Any]],
    review: RedReviewArtifact,
    assessment: dict[str, Any],
    validator_report: dict[str, Any],
    validator_returncode: int,
    validator_stdout: str,
    validator_stderr: str,
    pytest_returncode: int,
    pytest_stdout: str,
    pytest_stderr: str,
    runtime_contract: dict[str, Any],
) -> dict[str, Any]:
    context = _build_redreview_context(
        repo_root=repo_root,
        story=story,
        red_generation=red_generation,
        test_design=test_design,
        implementation_planning=implementation_planning,
        prior_passes=prior_passes,
    )
    context["latest_redreview"] = review.model_dump()
    context["repair_target"] = {
        "assessment": dict(assessment or {}),
        "validator": {
            "returncode": validator_returncode,
            "stdout": _truncate_output(validator_stdout, label="validator stdout"),
            "stderr": _truncate_output(validator_stderr, label="validator stderr"),
            "report": validator_report,
        },
        "pytest": {
            "returncode": pytest_returncode,
            "stdout": _truncate_output(pytest_stdout, label="pytest stdout"),
            "stderr": _truncate_output(pytest_stderr, label="pytest stderr"),
        },
        "runtime_contract": dict(runtime_contract or {}),
    }
    if str((assessment or {}).get("outcome") or "").strip() == "runtime_command_unverified":
        context["repair_target"]["runtime_command_issue"] = {
            "message": str((assessment or {}).get("message") or "").strip(),
            "success_pattern_docs": _load_repo_success_pattern_docs(repo_root=repo_root),
        }
    return context


def _run_redreview_repair_agent(*, repo_root: Path, pipeline_root: Path, repair_context: dict[str, Any], node_ref: str) -> tuple[RedTestGenerationArtifact, Path]:
    artifact, envelope = run_agent_step(
        repo_root=repo_root,
        stage_name="implementation_redreview_repair",
        strength="medium",
        output_model=RedTestGenerationArtifact,
        context_payload=repair_context,
        guidance=load_agentic_prompt_lines("implementation_redreview_repair"),
        timeout_seconds=_redreview_timeout_seconds(),
    )
    return artifact, _persist_implementation_agent_run(pipeline_root=pipeline_root, node_id=node_ref, envelope=envelope)


def _canonical_marker_lines(*, runtime_contract: dict[str, Any], story_id: str, story_uuid: str, planes: list[str]) -> list[str]:
    marker_format = str(runtime_contract.get("marker_format") or "pytest_decorator")
    if marker_format == "comment":
        return [f"// @story_id: {story_id}", f"// @story_uuid: {story_uuid}", *[f"// @plane: {plane}" for plane in planes]]
    return [
        "pytestmark = [",
        f'    pytest.mark.story_id("{story_id}"),',
        f'    pytest.mark.story_uuid("{story_uuid}"),',
        *[f'    pytest.mark.plane("{plane}"),' for plane in planes],
        "]",
    ]


def _is_story_pytest_marker_line(line: str) -> bool:
    stripped = line.strip()
    return stripped.startswith("@pytest.mark.story_id(") or stripped.startswith("@pytest.mark.story_uuid(") or stripped.startswith("@pytest.mark.plane(")


def _remove_bare_story_pytest_decorators(text: str) -> str:
    return "\n".join(line for line in text.splitlines() if not _is_story_pytest_marker_line(line))


def _extract_non_story_pytestmark_assignment(text: str) -> tuple[str, str | None]:
    try:
        module = ast.parse(text)
    except SyntaxError:
        return text, None

    lines = text.splitlines()
    removal_ranges: list[tuple[int, int]] = []
    preserved_rhs: str | None = None
    for node in module.body:
        target_names: list[str] = []
        value = None
        if isinstance(node, ast.Assign):
            target_names = [target.id for target in node.targets if isinstance(target, ast.Name)]
            value = node.value
        elif isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name):
            target_names = [node.target.id]
            value = node.value
        if "pytestmark" not in target_names or value is None:
            continue
        start = getattr(node, "lineno", 1) - 1
        end = getattr(node, "end_lineno", start + 1)
        segment = ast.get_source_segment(text, value) or ""
        if any(token in segment for token in ("pytest.mark.story_id(", "pytest.mark.story_uuid(", "pytest.mark.plane(")):
            removal_ranges.append((start, end))
            continue
        preserved_rhs = segment.strip() or preserved_rhs
        removal_ranges.append((start, end))

    if not removal_ranges:
        return text, preserved_rhs

    kept_lines: list[str] = []
    removal_iter = iter(sorted(removal_ranges))
    current = next(removal_iter, None)
    for idx, line in enumerate(lines):
        while current is not None and idx >= current[1]:
            current = next(removal_iter, None)
        if current is not None and current[0] <= idx < current[1]:
            continue
        kept_lines.append(line)
    return "\n".join(kept_lines), preserved_rhs


def _line_starts_module_docstring(line: str) -> bool:
    stripped = line.lstrip()
    return stripped.startswith('"""') or stripped.startswith("'''")


def _find_pytestmark_insert_index(lines: list[str]) -> int:
    def _consume_import_statement(start_index: int) -> int:
        index = start_index
        paren_balance = lines[index].count("(") - lines[index].count(")")
        continuation = lines[index].rstrip().endswith("\\")
        index += 1
        while index < len(lines) and (paren_balance > 0 or continuation):
            paren_balance += lines[index].count("(") - lines[index].count(")")
            continuation = lines[index].rstrip().endswith("\\")
            index += 1
        return index

    index = 0
    if index < len(lines) and lines[index].startswith("#!"):
        index += 1
    if index < len(lines) and re.match(r"#.*coding[:=]", lines[index]):
        index += 1
    while index < len(lines) and not lines[index].strip():
        index += 1
    if index < len(lines) and _line_starts_module_docstring(lines[index]):
        quote = '"""' if lines[index].lstrip().startswith('"""') else "'''"
        if lines[index].count(quote) >= 2:
            index += 1
        else:
            index += 1
            while index < len(lines):
                if quote in lines[index]:
                    index += 1
                    break
                index += 1
        while index < len(lines) and not lines[index].strip():
            index += 1
    while index < len(lines):
        stripped = lines[index].strip()
        if not stripped or stripped.startswith("#"):
            index += 1
            continue
        if stripped.startswith("import ") or stripped.startswith("from "):
            index = _consume_import_statement(index)
            continue
        break
    return index


def _build_pytestmark_block(*, runtime_contract: dict[str, Any], story_id: str, story_uuid: str, planes: list[str], preserved_rhs: str | None) -> list[str]:
    marker_lines = _canonical_marker_lines(runtime_contract=runtime_contract, story_id=story_id, story_uuid=story_uuid, planes=planes)
    if not preserved_rhs:
        return marker_lines
    return [
        "_devflow_existing_pytestmark = " + preserved_rhs,
        *marker_lines[:-1],
        "] + (_devflow_existing_pytestmark if isinstance(_devflow_existing_pytestmark, list) else [_devflow_existing_pytestmark])",
    ]


def _extract_pytestmark_assignment_block(lines: list[str], start_index: int) -> tuple[int, list[str]]:
    block = [lines[start_index]]
    bracket_balance = lines[start_index].count("[") - lines[start_index].count("]")
    end_index = start_index + 1
    while end_index < len(lines) and bracket_balance > 0:
        block.append(lines[end_index])
        bracket_balance += lines[end_index].count("[") - lines[end_index].count("]")
        end_index += 1
    return end_index, block


def _repair_pytestmark_embedded_in_parenthesized_import(text: str) -> str:
    lines = text.splitlines()
    cleaned_lines: list[str] = []
    extracted_blocks: list[list[str]] = []
    index = 0
    changed = False

    while index < len(lines):
        stripped = lines[index].strip()
        if not (stripped.startswith("import ") or stripped.startswith("from ")):
            cleaned_lines.append(lines[index])
            index += 1
            continue

        import_end = index + 1
        paren_balance = lines[index].count("(") - lines[index].count(")")
        continuation = lines[index].rstrip().endswith("\\")
        while import_end < len(lines) and (paren_balance > 0 or continuation):
            paren_balance += lines[import_end].count("(") - lines[import_end].count(")")
            continuation = lines[import_end].rstrip().endswith("\\")
            import_end += 1

        import_block = lines[index:import_end]
        block_index = 0
        while block_index < len(import_block):
            if block_index > 0 and re.match(r"^\s*pytestmark\s*=", import_block[block_index]):
                assignment_end, assignment_block = _extract_pytestmark_assignment_block(import_block, block_index)
                extracted_blocks.append(assignment_block)
                block_index = assignment_end
                changed = True
                continue
            cleaned_lines.append(import_block[block_index])
            block_index += 1
        index = import_end

    if not changed:
        return text

    repaired_lines = list(cleaned_lines)
    for assignment_block in extracted_blocks:
        insert_at = _find_pytestmark_insert_index(repaired_lines)
        prefix = repaired_lines[:insert_at]
        suffix = repaired_lines[insert_at:]
        block_lines = list(assignment_block)
        if prefix and prefix[-1].strip():
            prefix.append("")
        if suffix and suffix[0].strip():
            block_lines.append("")
        repaired_lines = prefix + block_lines + suffix
    return "\n".join(repaired_lines)


def _normalize_red_python_test_content(*, file_path: str, content: str) -> str:
    repaired = _repair_pytestmark_embedded_in_parenthesized_import(content)
    try:
        compile(repaired, file_path, "exec")
    except SyntaxError as exc:
        raise ValueError(
            f"red generated invalid python test file {file_path}: {exc.msg} (line {exc.lineno})"
        ) from exc
    except ValueError as exc:
        raise ValueError(f"red generated invalid python test file {file_path}: {exc}") from exc
    return repaired


def _apply_canonical_test_markers(*, repo_root: Path, runtime_contract: dict[str, Any], story_id: str, story_uuid: str, file_path: str, covered_planes: list[str]) -> None:
    rel = Path(file_path)
    if rel.is_absolute() or ".." in rel.parts:
        raise ValueError(f"redreview generated invalid path: {file_path}")
    dest = repo_root / rel
    text = dest.read_text(encoding="utf-8")
    marker_format = str(runtime_contract.get("marker_format") or "pytest_decorator")
    if marker_format == "comment":
        lines = [ln for ln in text.splitlines() if not ln.strip().startswith("// @story_id:") and not ln.strip().startswith("// @story_uuid:") and not ln.strip().startswith("// @plane:")]
        new_text = "\n".join([*_canonical_marker_lines(runtime_contract=runtime_contract, story_id=story_id, story_uuid=story_uuid, planes=covered_planes), *lines]).rstrip() + "\n"
        dest.write_text(new_text, encoding="utf-8")
        return

    stripped_text = _remove_bare_story_pytest_decorators(text)
    stripped_text, preserved_rhs = _extract_non_story_pytestmark_assignment(stripped_text)
    filtered = stripped_text.splitlines()
    while filtered and not filtered[0].strip():
        filtered.pop(0)

    insert_at = _find_pytestmark_insert_index(filtered)
    marker_lines = _build_pytestmark_block(
        runtime_contract=runtime_contract,
        story_id=story_id,
        story_uuid=story_uuid,
        planes=covered_planes,
        preserved_rhs=preserved_rhs,
    )
    prefix = filtered[:insert_at]
    suffix = filtered[insert_at:]
    updated = prefix + ([""] if prefix and prefix[-1].strip() else []) + marker_lines + [""] + suffix
    dest.write_text("\n".join(updated).rstrip() + "\n", encoding="utf-8")


def _register_redreview_files(*, repo_root: Path, runtime_contract: dict[str, Any], story: dict[str, Any], review: RedReviewArtifact) -> list[dict[str, Any]]:
    story_ctx = _story_context(story)
    story_id = str(story_ctx.get("story_id") or "")
    story_uuid = str(story_ctx.get("story_uuid") or "")
    registered: list[dict[str, Any]] = []
    for file in review.files:
        normalized_planes = list(dict.fromkeys(plane for plane in file.covered_planes if plane in ALLOWED_PLANES))
        if not file.register_for_validation or not normalized_planes:
            continue
        _apply_canonical_test_markers(
            repo_root=repo_root,
            runtime_contract=runtime_contract,
            story_id=story_id,
            story_uuid=story_uuid,
            file_path=file.path,
            covered_planes=normalized_planes,
        )
        registered.append({
            "path": file.path,
            "covered_planes": normalized_planes,
            "register_for_validation": True,
            "rationale": file.rationale,
        })
    return registered


def _summarize_bundle_assessment(bundle_reports: list[dict[str, Any]]) -> dict[str, Any]:
    assessments = [dict(report.get("assessment") or {}) for report in bundle_reports]
    if not assessments:
        return {
            "outcome": "insufficient_story_tests",
            "passed": False,
            "stop_workflow": True,
            "message": "bundle review produced no sufficiency outcomes",
        }
    if any(not bool(assessment.get("passed")) for assessment in assessments):
        failed = next(assessment for assessment in assessments if not bool(assessment.get("passed")))
        return {
            "outcome": str(failed.get("outcome") or "insufficient_story_tests"),
            "passed": False,
            "stop_workflow": True,
            "message": str(failed.get("message") or "story-scoped test sufficiency failed; strengthen tests before proceeding"),
        }
    if assessments and all(str(assessment.get("outcome") or "") == "real_green" for assessment in assessments):
        return {
            "outcome": "real_green",
            "passed": True,
            "stop_workflow": True,
            "message": "real green: every bundle verification plan is sufficient and already passes",
        }
    return {
        "outcome": "real_red",
        "passed": True,
        "stop_workflow": False,
        "message": "real red: bundle verification plans are sufficient and expose incomplete implementation",
    }


def _run_redreview_bundle_sufficiency_loop(
    *,
    repo_root: Path,
    engine_root: Path,
    pipeline_root: Path,
    run_id: str,
    story: dict[str, Any],
    story_id: str,
    bundle: dict[str, Any],
    test_design: dict[str, Any],
    implementation_planning: dict[str, Any],
    initial_red_generation: dict[str, Any],
) -> dict[str, Any]:
    bundle_id = str(bundle.get("bundle_id") or "default")
    history: list[dict[str, Any]] = []
    assessment: dict[str, Any] = {
        "outcome": "insufficient_story_tests",
        "passed": False,
        "stop_workflow": True,
        "message": f"bundle {bundle_id} failed story-scoped test sufficiency",
    }
    final_validator_report: dict[str, Any] = {}
    final_agent_run_path: Path | None = None
    red_generation = dict(initial_red_generation)
    runtime_contract = _resolve_bundle_runtime_contract(
        repo_root=repo_root,
        story=story,
        bundle=bundle,
        test_paths=[str(path) for path in (initial_red_generation.get("written_paths") or []) if str(path).strip()],
    )
    runtime_contract_path: Path | None = None
    run_cmd = list(runtime_contract.get("run_cmd") or [sys.executable or "python3", "-m", "pytest"])
    final_tv = subprocess.CompletedProcess(args=["validator"], returncode=2, stdout="", stderr="")
    final_pytest = subprocess.CompletedProcess(args=run_cmd, returncode=1, stdout="", stderr="")

    for pass_index in range(1, 4):
        validator_report_path = _red_sufficiency_report_path(repo_root=repo_root, run_id=run_id, story_id=story_id).parent / f"{_safe_bundle_id(bundle_id)}_validator_pass_{pass_index:03d}.json"
        validator_report_path.parent.mkdir(parents=True, exist_ok=True)
        review_context = _build_redreview_context(
            repo_root=repo_root,
            story=story,
            red_generation=red_generation,
            test_design={**_compact_test_design(test_design), "bundle": dict(bundle)},
            implementation_planning=implementation_planning,
            prior_passes=history,
        )
        review_context["bundle"] = dict(bundle)
        review_context["bundle_runtime_contract"] = runtime_contract
        review, agent_run_path = _run_redreview_agent(
            repo_root=repo_root,
            pipeline_root=pipeline_root,
            redreview_context=review_context,
            node_ref=f"redreview.{_safe_bundle_id(bundle_id)}",
        )
        final_agent_run_path = agent_run_path
        registered_files = _register_redreview_files(
            repo_root=repo_root,
            runtime_contract=runtime_contract,
            story=story,
            review=review,
        )
        registered_paths = [str(item["path"]) for item in registered_files]
        validator_report: dict[str, Any] = {}
        try:
            runtime_contract, runtime_contract_path, command_probe, command_attempts = _establish_verified_bundle_test_runtime_contract(
                repo_root=repo_root,
                story=story,
                bundle=bundle,
                test_paths=registered_paths,
                source=f"redreview_bundle:{bundle_id}",
            )
            tv = _run_story_test_validator(
                engine_root=engine_root,
                repo_root=repo_root,
                story_id=story_id,
                report_path=validator_report_path,
                test_paths=registered_paths,
                required_planes=list(bundle.get("planes") or []) or None,
            )
            run_cmd = list(runtime_contract.get("run_cmd") or run_cmd)
            p = _run_story_scoped_tests(repo_root=repo_root, runtime_contract=runtime_contract, test_paths=registered_paths)
            validator_report = _load_json_report(validator_report_path)
            assessment = _assess_red_candidate_outcome(validator_cp=tv, test_cp=p)
            history.append(
                {
                    "bundle_id": bundle_id,
                    "pass_index": pass_index,
                    "agent_run_ref": str(agent_run_path),
                    "generation_summary": red_generation.get("summary"),
                    "generation_notes": list(red_generation.get("notes") or []),
                    "written_paths": list(red_generation.get("written_paths") or []),
                    "redreview_summary": review.summary,
                    "redreview_notes": list(review.notes or []),
                    "registered_files": registered_files,
                    "validator_input_paths": registered_paths,
                    "validator_returncode": tv.returncode,
                    "validator_stdout": _truncate_output(tv.stdout, label="validator stdout"),
                    "validator_stderr": _truncate_output(tv.stderr, label="validator stderr"),
                    "validator_report_path": str(validator_report_path),
                    "validator_report": validator_report,
                    "pytest_returncode": p.returncode,
                    "pytest_stdout": _truncate_output(p.stdout, label="pytest stdout"),
                    "pytest_stderr": _truncate_output(p.stderr, label="pytest stderr"),
                    "assessment": assessment,
                    "test_runtime_contract": runtime_contract,
                    "runtime_contract_path": None if runtime_contract_path is None else str(runtime_contract_path),
                    "verified_command_probe": {
                        "returncode": int(command_probe.returncode),
                        "stdout": _truncate_output(str(command_probe.stdout or ""), label="runtime probe stdout", limit=1000),
                        "stderr": _truncate_output(str(command_probe.stderr or ""), label="runtime probe stderr", limit=1000),
                        "attempts": command_attempts,
                    },
                }
            )
            final_validator_report = validator_report
            final_tv = tv
            final_pytest = p
        except Exception as exc:
            assessment = _runtime_command_repair_assessment(message=str(exc))
            final_tv = subprocess.CompletedProcess(args=["validator"], returncode=2, stdout="", stderr=str(exc))
            final_pytest = subprocess.CompletedProcess(args=run_cmd, returncode=2, stdout="", stderr=str(exc))
            history.append(
                {
                    "bundle_id": bundle_id,
                    "pass_index": pass_index,
                    "agent_run_ref": str(agent_run_path),
                    "generation_summary": red_generation.get("summary"),
                    "generation_notes": list(red_generation.get("notes") or []),
                    "written_paths": list(red_generation.get("written_paths") or []),
                    "redreview_summary": review.summary,
                    "redreview_notes": list(review.notes or []),
                    "registered_files": registered_files,
                    "validator_input_paths": registered_paths,
                    "assessment": assessment,
                    "test_runtime_contract": dict(runtime_contract or {}),
                    "runtime_contract_path": None if runtime_contract_path is None else str(runtime_contract_path),
                    "command_verification_attempts": [],
                    "runtime_command_error": str(exc),
                }
            )
        repair_required = _is_redreview_local_quality_outcome(assessment)
        if assessment["outcome"] in {"real_green", "real_red"} or pass_index >= 3 or not repair_required:
            break
        repair_context = _build_redreview_repair_context(
            repo_root=repo_root,
            story=story,
            red_generation=red_generation,
            test_design={**_compact_test_design(test_design), "bundle": dict(bundle)},
            implementation_planning=implementation_planning,
            prior_passes=history,
            review=review,
            assessment=assessment,
            validator_report=validator_report,
            validator_returncode=final_tv.returncode,
            validator_stdout=final_tv.stdout,
            validator_stderr=final_tv.stderr,
            pytest_returncode=final_pytest.returncode,
            pytest_stdout=final_pytest.stdout,
            pytest_stderr=final_pytest.stderr,
            runtime_contract=runtime_contract,
        )
        generated_tests, repair_agent_run_path = _run_redreview_repair_agent(
            repo_root=repo_root,
            pipeline_root=pipeline_root,
            repair_context=repair_context,
            node_ref=f"redreview.{_safe_bundle_id(bundle_id)}.repair_{pass_index + 1}",
        )
        written_paths = _apply_red_test_generation(repo_root=repo_root, artifact=generated_tests)
        red_generation = {
            "bundle_id": bundle_id,
            "summary": generated_tests.summary,
            "notes": list(generated_tests.notes or []),
            "written_paths": written_paths,
            "repair_agent_run_ref": str(repair_agent_run_path),
            "repair_source": "redreview_internal_loop",
        }
        history[-1]["repair"] = {
            "agent_run_ref": str(repair_agent_run_path),
            "summary": generated_tests.summary,
            "notes": list(generated_tests.notes or []),
            "written_paths": written_paths,
            "source": "redreview_internal_loop",
        }

    report = {
        "bundle_id": bundle_id,
        "runtime_family": str(bundle.get("runtime_family") or "default"),
        "planes": list(bundle.get("planes") or []),
        "mode": "model_backed",
        "agent_run_ref": None if final_agent_run_path is None else str(final_agent_run_path),
        "passed": bool(assessment.get("passed")),
        "pass_count": len(history),
        "history": history,
        "registered_files": list(history[-1].get("registered_files") or []) if history else [],
        "validator_input_paths": list(history[-1].get("validator_input_paths") or []) if history else [],
        "final_validator_report": final_validator_report,
        "assessment": assessment,
        "runtime_contract": runtime_contract,
        "runtime_contract_path": None if runtime_contract_path is None else str(runtime_contract_path),
        "red_generation": red_generation,
        "final_runs": {
            "validator": {"returncode": final_tv.returncode, "stdout": final_tv.stdout, "stderr": final_tv.stderr},
            "pytest": {"returncode": final_pytest.returncode, "stdout": final_pytest.stdout, "stderr": final_pytest.stderr},
        },
    }
    return report


def _order_bundle_redreview_reports(
    *,
    repo_root: Path,
    story: dict[str, Any],
    test_design: dict[str, Any],
    bundle_reports: list[dict[str, Any]],
) -> tuple[list[dict[str, Any]], list[str]]:
    expected_bundles = _test_design_bundles(repo_root=repo_root, story=story, test_design=test_design)
    expected_ids = [str(bundle.get("bundle_id") or "default") for bundle in expected_bundles]
    report_map: dict[str, dict[str, Any]] = {}
    duplicates: list[str] = []
    for raw_report in bundle_reports:
        bundle_id = str(raw_report.get("bundle_id") or "default")
        if bundle_id in report_map:
            duplicates.append(bundle_id)
            continue
        report_map[bundle_id] = dict(raw_report)
    missing = [bundle_id for bundle_id in expected_ids if bundle_id not in report_map]
    unexpected = [bundle_id for bundle_id in report_map if bundle_id not in set(expected_ids)]
    errors: list[str] = []
    if missing:
        errors.append(f"missing bundle redreview reports: {', '.join(missing)}")
    if duplicates:
        errors.append(f"duplicate bundle redreview reports: {', '.join(_dedupe_strings(duplicates))}")
    if unexpected:
        errors.append(f"unexpected bundle redreview reports: {', '.join(unexpected)}")
    return [report_map[bundle_id] for bundle_id in expected_ids if bundle_id in report_map], errors


def _build_story_verification_reconciliation(
    *,
    repo_root: Path,
    story: dict[str, Any],
    test_design: dict[str, Any],
    bundle_reports: list[dict[str, Any]],
) -> StoryVerificationReconciliationArtifact:
    story_ctx = _story_context(story)
    bundles_by_id = {str(bundle.get("bundle_id") or "default"): dict(bundle) for bundle in _test_design_bundles(repo_root=repo_root, story=story, test_design=test_design)}
    reconciled_bundles: list[StoryVerificationBundle] = []
    for report in bundle_reports:
        bundle_id = str(report.get("bundle_id") or "default")
        bundle = bundles_by_id.get(bundle_id, {"bundle_id": bundle_id})
        registered_files = [dict(item) for item in (report.get("registered_files") or []) if isinstance(item, dict)]
        reconciled_bundles.append(
            StoryVerificationBundle(
                bundle_id=bundle_id,
                planes=list(bundle.get("planes") or []),
                runtime_family=str(bundle.get("runtime_family") or report.get("runtime_family") or "default"),
                runtime_contract=dict(report.get("runtime_contract") or _resolve_bundle_runtime_contract(repo_root=repo_root, story=story, bundle=bundle, test_paths=report.get("validator_input_paths") or [])),
                runtime_contract_path=str(report.get("runtime_contract_path")) if report.get("runtime_contract_path") else None,
                file_targets=list(bundle.get("file_targets") or []),
                must_cover=list(bundle.get("must_cover") or []),
                must_avoid=list(bundle.get("must_avoid") or []),
                test_cases=[dict(case) for case in (bundle.get("test_cases") or []) if isinstance(case, dict)],
                registered_files=registered_files,
                test_paths=[str(path) for path in (report.get("validator_input_paths") or []) if str(path).strip()],
                red_generation=dict(report.get("red_generation") or {}),
                redreview={
                    "passed": bool(report.get("passed")),
                    "pass_count": int(report.get("pass_count") or 0),
                    "assessment": dict(report.get("assessment") or {}),
                    "history": list(report.get("history") or []),
                },
            )
        )
    summary = f"Reconciled {len(reconciled_bundles)} runtime bundle verification plans for Green."
    return StoryVerificationReconciliationArtifact(
        story_id=str(story_ctx.get("story_id") or "") or None,
        story_uuid=str(story_ctx.get("story_uuid") or "") or None,
        summary=summary,
        bundle_count=len(reconciled_bundles),
        story_test_cases=[dict(case) for case in (test_design.get("test_cases") or []) if isinstance(case, dict)],
        story_must_cover=_dedupe_strings([*list(test_design.get("must_cover") or []), *[item for bundle in _test_design_bundles(repo_root=repo_root, story=story, test_design=test_design) for item in bundle.get("must_cover") or []]]),
        story_must_avoid=_dedupe_strings([*list(test_design.get("must_avoid") or []), *[item for bundle in _test_design_bundles(repo_root=repo_root, story=story, test_design=test_design) for item in bundle.get("must_avoid") or []]]),
        bundles=reconciled_bundles,
    )


def _normalize_streaming_cli_base(base_cmd: str) -> str:
    return normalize_llm_cli_base(base_cmd)


def _streaming_agent_config(*, strength_override: str | None = None) -> tuple[str, str]:
    """Resolve streaming CLI base_cmd and delivery from tier config.

    Uses tier.cliProfile as the primary model source (mirrors _resolve_cli_from_tier).
    Falls back to top-level llm_cli_model_<strength> only when tier has no cliProfile.
    """
    raw = str(os.environ.get("DFE_CODER_CMD") or "").strip()
    if raw:
        return _normalize_streaming_cli_base(raw), "stdin"
    cfg = _read_toml(_global_devflow_dir() / "config.toml")
    mode = str(cfg.get("llm_mode") or "").strip().lower()
    if mode != "cli":
        raise RuntimeError("LLM not configured for CLI mode.")
    base_cmd = str(cfg.get("llm_cli_base") or "").strip()
    if not base_cmd:
        raise RuntimeError("LLM CLI base command not set.")
    delivery = str(cfg.get("llm_cli_delivery") or "stdin").strip().lower()
    effective_strength = strength_override if strength_override is not None else "default"

    # Primary: get model from tier cliProfile (same source as _resolve_cli_from_tier)
    tier_cfg = _tier_config(effective_strength, cfg)
    tier_model = str(tier_cfg.get("cliProfile") or "").strip() if tier_cfg else ""
    # Fallback: top-level llm_cli_model_<strength> (legacy TOML layout)
    top_model = _resolve_strength_model(cfg, base_cmd, strength_override=effective_strength)
    model = tier_model or top_model

    extra_flags = str(cfg.get(f"llm_cli_model_{effective_strength}_extra_flags") or "").strip()
    base_cmd = _normalize_streaming_cli_base(_apply_model_flag(base_cmd, model))
    if extra_flags:
        base_cmd = f"{base_cmd} {extra_flags}"
    return base_cmd, ("argument" if delivery == "argument" else "stdin")


def _run_streaming_cli_attempt(*, repo_root: Path, prompt: str, timeout_seconds: int, strength: str | None = None) -> dict[str, Any]:
    base_cmd, delivery = _streaming_agent_config(strength_override=strength)
    result = run_streaming(
        provider="cli",
        base_cmd=base_cmd,
        delivery=delivery,
        prompt=prompt,
        cwd=repo_root,
        timeout_s=timeout_seconds,
    )
    return {
        "ok": result.returncode == 0,
        "returncode": result.returncode,
        "stdout": result.stdout,
        "stderr": result.stderr,
        "session_id": result.session_id,
        "log_path": str(result.log_path),
        "cmd": base_cmd[:240],
        "timeout_seconds": timeout_seconds,
    }


def _run_devflow_refactor_attempt(*, repo_root: Path, prompt: str, timeout_seconds: int) -> dict[str, Any]:
    cmd_env = os.environ.copy()
    cmd_env["DEVFLOW_REFACTOR_PROMPT"] = prompt
    cmd_env["DEVFLOW_REPO_ROOT"] = str(repo_root)
    enforce_cmd = ["devflow", "enforce"]
    enforce_result = _run_cmd(repo_root, enforce_cmd, env=cmd_env)
    latest_report = repo_root / ".devflow" / "enforce" / "latest.json"
    if not latest_report.exists():
        return {
            "ok": False,
            "returncode": enforce_result.returncode,
            "stdout": enforce_result.stdout,
            "stderr": (enforce_result.stderr or "") + f"\nMissing enforce report after enforce run: {latest_report}",
            "session_id": None,
            "log_path": None,
            "cmd": " ".join(enforce_cmd),
            "timeout_seconds": timeout_seconds,
            "enforce_returncode": enforce_result.returncode,
            "enforce_stdout": enforce_result.stdout,
            "enforce_stderr": enforce_result.stderr,
        }

    cmd = ["devflow", "refactor", "--max-iters", "3"]
    result = _run_cmd(repo_root, cmd, env=cmd_env)
    return {
        "ok": result.returncode == 0,
        "returncode": result.returncode,
        "stdout": result.stdout,
        "stderr": result.stderr,
        "session_id": None,
        "log_path": None,
        "cmd": " ".join(cmd),
        "timeout_seconds": timeout_seconds,
        "enforce_returncode": enforce_result.returncode,
        "enforce_stdout": enforce_result.stdout,
        "enforce_stderr": enforce_result.stderr,
    }


def _set_failure_context_field(payload: dict[str, Any], key: str, value: Any) -> None:
    if value is None:
        return
    if isinstance(value, str) and not value.strip():
        return
    if isinstance(value, (list, tuple, set, dict)) and not value:
        return
    payload[key] = value


def _dedupe_strings(values: list[Any]) -> list[str]:
    seen: set[str] = set()
    ordered: list[str] = []
    for raw in values:
        value = str(raw or "").strip()
        if not value or value in seen:
            continue
        seen.add(value)
        ordered.append(value)
    return ordered


def _collect_artifact_paths(payload: Any) -> list[str]:
    paths: list[str] = []

    def _walk(value: Any, *, key: str | None = None) -> None:
        if isinstance(value, dict):
            for child_key, child_value in value.items():
                _walk(child_value, key=str(child_key))
            return
        if isinstance(value, list):
            for item in value:
                _walk(item, key=key)
            return
        if not isinstance(value, str):
            return
        lowered = str(key or "").lower()
        if lowered.endswith("_path") or lowered.endswith("_paths") or lowered.endswith("_uri") or lowered.endswith("_uris") or lowered in {
            "path",
            "paths",
            "uri",
            "uris",
            "log_path",
            "report_path",
            "verification_path",
            "artifact_path",
            "artifact_paths",
            "agent_run_ref",
            "recovery_request_path",
        }:
            paths.append(value)

    _walk(payload)
    return _dedupe_strings(paths)


def _extract_gate_returncodes(final_gate: dict[str, Any] | None) -> tuple[int | None, int | None, list[str]]:
    if not isinstance(final_gate, dict):
        return None, None, []
    validator_codes: list[int] = []
    pytest_codes: list[int] = []
    bundle_ids: list[str] = []
    for gate_key, raw_gate in final_gate.items():
        if not isinstance(raw_gate, dict):
            continue
        parts = str(gate_key).split(":", 1)
        if len(parts) == 2:
            bundle_ids.append(parts[0])
            suffix = parts[1]
        else:
            suffix = parts[0]
        try:
            returncode = int(raw_gate.get("returncode"))
        except (TypeError, ValueError):
            continue
        if suffix == "story_test_validation":
            validator_codes.append(returncode)
        elif suffix == "story_tests":
            pytest_codes.append(returncode)
    validator_returncode = validator_codes[0] if len(set(validator_codes)) == 1 and validator_codes else None
    pytest_returncode = pytest_codes[0] if len(set(pytest_codes)) == 1 and pytest_codes else None
    return validator_returncode, pytest_returncode, _dedupe_strings(bundle_ids)


def _implementation_failure_kind(*, failed_stage: str | None, node_output: dict[str, Any], metadata: dict[str, Any]) -> str:
    stage = str(failed_stage or "").strip().lower()
    if stage == "preflight":
        return "preflight_blocked"
    if stage == "red":
        if node_output.get("failed_bundles"):
            return "bundle_generation_failed"
        return "test_generation_failed"
    if stage == "redreview":
        assessment = node_output.get("assessment") if isinstance(node_output.get("assessment"), dict) else {}
        outcome = str(assessment.get("outcome") or "").strip()
        if outcome:
            return outcome
        return "test_sufficiency_failed"
    if stage == "green":
        if str(node_output.get("status") or "").strip() == "accepted_red_artifacts_missing":
            return "accepted_red_artifacts_missing"
        return "gate_check_failed"
    if stage == "gitcommit(refactor)":
        status = str(node_output.get("status") or "").strip()
        if status.startswith("blocked_"):
            return "precondition_failed"
        return "command_failed"
    if stage in {"setupdoc", "dependencyassessment", "storyimplementationplanning", "testdesign"}:
        return "agent_generation_failed"
    if stage == "normalize":
        return "validation_failed"
    if stage == "security":
        return "security_check_failed"
    if stage == "refactor":
        return "refactor_failed"
    if metadata.get("exit_code"):
        return "stage_failed"
    return "implementation_failed"


def _redreview_failure_blocks_locally(*, node_output: dict[str, Any]) -> bool:
    assessment = node_output.get("assessment") if isinstance(node_output.get("assessment"), dict) else {}
    outcome = str(assessment.get("outcome") or "").strip()
    if outcome not in _REDREVIEW_LOCAL_QUALITY_OUTCOMES:
        return False
    sufficiency = node_output.get("sufficiency") if isinstance(node_output.get("sufficiency"), dict) else {}
    try:
        pass_count = int(sufficiency.get("pass_count") or 0)
    except (TypeError, ValueError):
        pass_count = 0
    return pass_count >= 3


def _normalize_failure_node_for_churn(node_id: str | None) -> str | None:
    raw = str(node_id or "").strip()
    if not raw:
        return None
    if "." in raw:
        raw = raw.split(".", 1)[0]
    return raw


def _actual_failed_node_for_run(*, store: ExecutionStore, run_id: str, failed_stage: str | None) -> str | None:
    with store._connect() as conn:
        row = conn.execute(
            (
                "SELECT node_id FROM nodes WHERE run_id=? AND status='failed' "
                "ORDER BY COALESCE(finished_at, updated_at, created_at) DESC, created_at DESC LIMIT 1"
            ),
            (run_id,),
        ).fetchone()
    if row is not None:
        normalized = _normalize_failure_node_for_churn(str(row["node_id"] or ""))
        if normalized:
            return normalized
    return _normalize_failure_node_for_churn(failed_stage)


def _build_implementation_failure_context(
    *,
    store: ExecutionStore,
    run_id: str,
    failed_stage: str | None,
    metadata: dict[str, Any],
) -> dict[str, Any]:
    payload: dict[str, Any] = {}
    _set_failure_context_field(payload, "failed_stage", failed_stage)
    _set_failure_context_field(payload, "implementation_run_id", run_id)
    _set_failure_context_field(payload, "actual_failed_node", _actual_failed_node_for_run(store=store, run_id=run_id, failed_stage=failed_stage))

    stage = str(failed_stage or "").strip()
    node = store.get_latest_node_attempt(run_id=run_id, node_id=stage) if stage else None
    node_output = node.get("output") if isinstance(node, dict) and isinstance(node.get("output"), dict) else {}

    _set_failure_context_field(
        payload,
        "failure_kind",
        _implementation_failure_kind(failed_stage=failed_stage, node_output=node_output, metadata=metadata),
    )

    bundle_ids: list[str] = []
    bundle_id = str(node_output.get("bundle_id") or "").strip()
    if bundle_id:
        bundle_ids.append(bundle_id)

    failed_bundles = node_output.get("failed_bundles") if isinstance(node_output.get("failed_bundles"), list) else []
    bundle_ids.extend(str(item.get("bundle_id") or "").strip() for item in failed_bundles if isinstance(item, dict))

    bundle_reports = node_output.get("bundle_reports") if isinstance(node_output.get("bundle_reports"), list) else []
    failed_reports = [
        report for report in bundle_reports
        if isinstance(report, dict) and not bool(report.get("passed", report.get("assessment", {}).get("passed")))
    ]
    bundle_ids.extend(str(item.get("bundle_id") or "").strip() for item in failed_reports if isinstance(item, dict))

    validator_returncode, pytest_returncode, gate_bundle_ids = _extract_gate_returncodes(
        metadata.get("green_report", {}).get("final_gate") if isinstance(metadata.get("green_report"), dict) else None
    )
    bundle_ids.extend(gate_bundle_ids)
    bundle_ids = _dedupe_strings(bundle_ids)
    if len(bundle_ids) == 1:
        _set_failure_context_field(payload, "bundle_id", bundle_ids[0])
    elif bundle_ids:
        _set_failure_context_field(payload, "bundle_ids", bundle_ids)

    if failed_stage == "red":
        attempts_used = [item.get("attempts_used") for item in failed_bundles if isinstance(item, dict) and item.get("attempts_used") is not None]
        if len(set(int(v) for v in attempts_used if isinstance(v, int))) == 1 and attempts_used:
            _set_failure_context_field(payload, "iterations_used", int(attempts_used[0]))
            _set_failure_context_field(payload, "max_iterations", int(attempts_used[0]))
    elif failed_stage == "redreview":
        if isinstance(node_output.get("test_validation_returncode"), int):
            validator_returncode = int(node_output["test_validation_returncode"])
        elif len(failed_reports) == 1:
            final_runs = failed_reports[0].get("final_runs") if isinstance(failed_reports[0].get("final_runs"), dict) else {}
            validator = final_runs.get("validator") if isinstance(final_runs.get("validator"), dict) else {}
            if isinstance(validator.get("returncode"), int):
                validator_returncode = int(validator["returncode"])
        if isinstance(node_output.get("pytest_returncode"), int):
            pytest_returncode = int(node_output["pytest_returncode"])
        elif len(failed_reports) == 1:
            final_runs = failed_reports[0].get("final_runs") if isinstance(failed_reports[0].get("final_runs"), dict) else {}
            pytest_run = final_runs.get("pytest") if isinstance(final_runs.get("pytest"), dict) else {}
            if isinstance(pytest_run.get("returncode"), int):
                pytest_returncode = int(pytest_run["returncode"])
        sufficiency = node_output.get("sufficiency") if isinstance(node_output.get("sufficiency"), dict) else {}
        _set_failure_context_field(payload, "iterations_used", sufficiency.get("pass_count"))
        _set_failure_context_field(payload, "max_iterations", 3 if sufficiency else None)
    elif failed_stage == "green":
        report = metadata.get("green_report") if isinstance(metadata.get("green_report"), dict) else {}
        _set_failure_context_field(payload, "iterations_used", report.get("iterations_used"))
        _set_failure_context_field(payload, "max_iterations", report.get("max_iterations"))
    elif failed_stage == "refactor":
        report = metadata.get("refactor_report") if isinstance(metadata.get("refactor_report"), dict) else {}
        _set_failure_context_field(payload, "iterations_used", report.get("iterations_used"))
        _set_failure_context_field(payload, "max_iterations", report.get("max_iterations"))
    elif failed_stage == "security":
        report = metadata.get("security_report") if isinstance(metadata.get("security_report"), dict) else {}
        _set_failure_context_field(payload, "iterations_used", report.get("iterations_used"))
        _set_failure_context_field(payload, "max_iterations", report.get("max_iterations"))
    elif isinstance(node, dict) and node.get("attempt") is not None:
        _set_failure_context_field(payload, "iterations_used", node.get("attempt"))

    _set_failure_context_field(payload, "validator_returncode", validator_returncode)
    _set_failure_context_field(payload, "pytest_returncode", pytest_returncode)

    if failed_stage == "redreview" and _redreview_failure_blocks_locally(node_output=node_output):
        _set_failure_context_field(payload, "recovery_disposition", "blocked_at_redreview")
        _set_failure_context_field(payload, "queue_status", "blocked")
        _set_failure_context_field(payload, "redreview_local_failure", True)

    timeout_by_stage = {
        "dependencyassessment": _dependency_assessment_timeout_seconds(),
        "storyimplementationplanning": _implementation_planning_timeout_seconds(),
        "testdesign": _test_design_timeout_seconds(),
        "red": _red_timeout_seconds(),
        "redreview": _redreview_timeout_seconds(),
        "green": _green_timeout_seconds(),
        "refactor": _refactor_timeout_seconds(),
        "security": _security_timeout_seconds(),
    }
    _set_failure_context_field(payload, "timeout_seconds", timeout_by_stage.get(str(failed_stage or "").strip().lower()))

    artifacts = list(store.list_artifacts_for_node(run_id=run_id, node_id=stage)) if stage else []
    artifact_paths = _collect_artifact_paths(node_output)
    artifact_paths.extend(_collect_artifact_paths(metadata))
    artifact_paths.extend(str(item.get("uri") or "").strip() for item in artifacts if isinstance(item, dict))
    artifact_paths = _dedupe_strings(artifact_paths)
    _set_failure_context_field(payload, "artifact_paths", artifact_paths)

    return payload


def _run_green_agent(*, repo_root: Path, prompt: str, strength: str | None = None) -> dict[str, Any]:
    return _run_streaming_cli_attempt(repo_root=repo_root, prompt=prompt, timeout_seconds=_green_timeout_seconds(), strength=strength)


_MAX_STREAMING_PROMPT_CHARS = 100_000


def _compact_test_design(test_design: dict[str, Any]) -> dict[str, Any]:
    """Strip redundant nested artifacts from test_design to avoid prompt bloat.

    The test_design metadata embeds full copies of dependency_assessment and
    implementation_planning which are already passed as separate top-level keys
    in the streaming prompt payload.  Remove them here to eliminate duplication.
    """
    td = dict(test_design)
    td.pop("dependency_assessment", None)
    td.pop("implementation_planning", None)
    return td


def _recovery_handoff_artifact_path(*, repo_root: Path, story_id: str) -> Path:
    safe_story_id = re.sub(r"[^A-Za-z0-9_.-]+", "_", story_id) or "unknown_story"
    return _story_state_root(repo_root=repo_root) / safe_story_id / "recovery_handoff.json"


def _green_outcome_review_artifact_path(*, repo_root: Path, story_id: str, iteration: int) -> Path:
    safe_story_id = re.sub(r"[^A-Za-z0-9_.-]+", "_", story_id) or "unknown_story"
    return _story_state_root(repo_root=repo_root) / safe_story_id / f"green_outcome_review_iter{iteration:03d}.json"


def _green_latest_outcome_review_artifact_path(*, repo_root: Path, story_id: str) -> Path:
    safe_story_id = re.sub(r"[^A-Za-z0-9_.-]+", "_", story_id) or "unknown_story"
    return _story_state_root(repo_root=repo_root) / safe_story_id / "green_outcome_review_latest.json"


def _story_state_artifact_read_path(*, repo_root: Path, story_id: str, relative_parts: tuple[str, ...]) -> Path:
    safe_story_id = re.sub(r"[^A-Za-z0-9_.-]+", "_", story_id) or "unknown_story"
    story_root = _story_state_root(repo_root=repo_root) / safe_story_id
    primary = story_root.joinpath(*relative_parts)
    if primary.exists() and primary.is_file():
        return primary

    quarantine_dirs = [
        path
        for path in story_root.iterdir()
        if path.is_dir() and path.name.startswith(".") and "quarantine_" in path.name
    ] if story_root.exists() and story_root.is_dir() else []
    for quarantine_dir in sorted(quarantine_dirs, key=lambda path: path.name, reverse=True):
        candidate = quarantine_dir.joinpath(*relative_parts)
        if candidate.exists() and candidate.is_file():
            return candidate
    return primary


def _load_recovery_handoff_artifact(*, repo_root: Path, story: dict[str, Any]) -> dict[str, Any] | None:
    story_ctx = _story_context(story)
    story_id = str(story_ctx.get("story_id") or "").strip()
    if not story_id:
        return None
    path = _story_state_artifact_read_path(
        repo_root=repo_root,
        story_id=story_id,
        relative_parts=("recovery_handoff.json",),
    )
    if not path.exists() or not path.is_file():
        return None
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None
    if not isinstance(payload, dict):
        return None
    payload.setdefault("artifact_path", str(path))
    return payload


def _load_json_artifact_dict(path: Path) -> dict[str, Any] | None:
    if not path.exists() or not path.is_file():
        return None
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None
    return payload if isinstance(payload, dict) else None


def _green_latest_agent_run_artifact_path(*, repo_root: Path, story_id: str) -> Path:
    return _implementation_pipeline_root(repo_root=repo_root, story_id=story_id) / "agent_runs" / "green.json"


def _green_compact_outcome_review(review: dict[str, Any] | None) -> dict[str, Any]:
    payload = dict(review or {})
    return {
        "progress_made": _string_list(payload.get("progress_made"), limit=4),
        "resolved_failures": _string_list(payload.get("resolved_failures"), limit=4),
        "remaining_failures": _string_list(payload.get("remaining_failures"), limit=6),
        "new_failures": _string_list(payload.get("new_failures"), limit=4),
        "likely_next_seam": str(payload.get("likely_next_seam") or "").strip(),
        "do_not_revisit": _string_list(payload.get("do_not_revisit"), limit=6),
        "recommended_next_actions": _string_list(payload.get("recommended_next_actions"), limit=6),
    }


def _green_recovery_review_from_handoff(recovery_handoff: dict[str, Any] | None) -> dict[str, Any]:
    payload = dict(recovery_handoff or {})
    insights = [
        str(payload.get("key_log_insight") or "").strip(),
        str(payload.get("non_convergence_insight") or "").strip(),
    ]
    recommended = _string_list(
        [item for item in insights if item] + _string_list(payload.get("verification_blockers"), limit=4),
        limit=6,
    )
    return {
        "progress_made": [],
        "resolved_failures": [],
        "remaining_failures": _string_list([payload.get("failing_surface_summary")], limit=4),
        "new_failures": [],
        "likely_next_seam": str(payload.get("likely_seam") or "").strip(),
        "do_not_revisit": _string_list(payload.get("disproven_dead_ends"), limit=6),
        "recommended_next_actions": recommended,
    }


def _green_recovery_handoff_is_actionable(recovery_handoff: dict[str, Any] | None) -> bool:
    payload = dict(recovery_handoff or {})
    likely_next_seam = str(payload.get("likely_seam") or "").strip()
    if not likely_next_seam:
        return False
    if str(payload.get("failing_surface_summary") or "").strip():
        return True
    if _string_list(payload.get("disproven_dead_ends"), limit=1):
        return True
    if _string_list(payload.get("verification_blockers"), limit=1):
        return True
    if str(payload.get("key_log_insight") or "").strip():
        return True
    if str(payload.get("non_convergence_insight") or "").strip():
        return True
    return False


def _green_evidence_source_run_id(*sources: dict[str, Any] | None) -> str:
    for payload in sources:
        if not isinstance(payload, dict):
            continue
        for key in ("source_run_id", "implementation_run_id", "prior_run_id", "run_id"):
            value = str(payload.get(key) or "").strip()
            if value:
                return value
    return ""


def _select_green_prior_run_evidence(
    *,
    repo_root: Path,
    story: dict[str, Any],
    recovery_handoff: dict[str, Any] | None = None,
) -> dict[str, Any] | None:
    story_ctx = _story_context(story)
    story_id = str(story_ctx.get("story_id") or "").strip()
    if not story_id:
        return None
    if recovery_handoff is None:
        recovery_handoff = _load_recovery_handoff_artifact(repo_root=repo_root, story=story)

    latest_review_path = _story_state_artifact_read_path(
        repo_root=repo_root,
        story_id=story_id,
        relative_parts=("green_outcome_review_latest.json",),
    )
    latest_review = _load_json_artifact_dict(latest_review_path)
    if isinstance(latest_review, dict):
        latest_review.setdefault("artifact_path", str(latest_review_path))

    agent_run_path = _story_state_artifact_read_path(
        repo_root=repo_root,
        story_id=story_id,
        relative_parts=("agent_runs", "green.json"),
    )
    agent_run = _load_json_artifact_dict(agent_run_path)
    if isinstance(agent_run, dict):
        agent_run.setdefault("artifact_path", str(agent_run_path))
        transcript_excerpt = _tail_streaming_attempt_log(agent_attempt=agent_run)
        recovered_failures = _recover_failing_assertions_from_transcript_excerpt(
            transcript_excerpt=transcript_excerpt,
            limit=6,
        )
        if transcript_excerpt and recovered_failures:
            supplemental_review = _green_compact_outcome_review(latest_review)
            handoff_review = _green_recovery_review_from_handoff(recovery_handoff)
            review = {
                "progress_made": _string_list(
                    [f"Recovered prior streamed transcript evidence from {agent_run['artifact_path']}"]
                    + supplemental_review.get("progress_made", []),
                    limit=4,
                ),
                "resolved_failures": supplemental_review.get("resolved_failures", []),
                "remaining_failures": recovered_failures,
                "new_failures": supplemental_review.get("new_failures", []),
                "likely_next_seam": str(
                    supplemental_review.get("likely_next_seam")
                    or handoff_review.get("likely_next_seam")
                    or ""
                ).strip(),
                "do_not_revisit": _string_list(
                    supplemental_review.get("do_not_revisit", []) + handoff_review.get("do_not_revisit", []),
                    limit=6,
                ),
                "recommended_next_actions": _string_list(
                    supplemental_review.get("recommended_next_actions", []) + handoff_review.get("recommended_next_actions", []),
                    limit=6,
                ),
            }
            source_run_id = _green_evidence_source_run_id(agent_run, latest_review, recovery_handoff)
            return {
                "strength": "strong",
                "source_type": "streamed_log_transcript",
                "source_artifact_path": str(agent_run.get("artifact_path") or agent_run_path),
                "source_log_path": str(agent_run.get("log_path") or "").strip(),
                "source_run_id": source_run_id or None,
                "review": review,
                "transcript_excerpt": transcript_excerpt,
                "supplemental_review_artifact_path": str((latest_review or {}).get("artifact_path") or "").strip() or None,
            }

    if isinstance(latest_review, dict):
        source_run_id = _green_evidence_source_run_id(latest_review, recovery_handoff)
        return {
            "strength": "strong",
            "source_type": "green_outcome_review",
            "source_artifact_path": str(latest_review.get("artifact_path") or latest_review_path),
            "source_run_id": source_run_id or None,
            "review": _green_compact_outcome_review(latest_review),
            "reviewed_iteration": latest_review.get("reviewed_iteration") or latest_review.get("iteration"),
        }

    if _green_recovery_handoff_is_actionable(recovery_handoff):
        source_run_id = _green_evidence_source_run_id(recovery_handoff)
        return {
            "strength": "strong",
            "source_type": "recovery_handoff_summary",
            "source_artifact_path": str((recovery_handoff or {}).get("artifact_path") or "").strip() or None,
            "source_run_id": source_run_id or None,
            "review": _green_recovery_review_from_handoff(recovery_handoff),
        }

    return None


def _compact_streaming_payload(payload: dict[str, Any], *, repo_root: Path | None = None) -> dict[str, Any]:
    """Shrink a streaming prompt payload so it fits within context limits."""
    serialized = json.dumps(payload, indent=2, sort_keys=True)
    if len(serialized) <= _MAX_STREAMING_PROMPT_CHARS:
        return payload
    compacted = _shrink_for_prompt(payload)
    serialized = json.dumps(compacted, indent=2, sort_keys=True)
    if len(serialized) <= _MAX_STREAMING_PROMPT_CHARS or repo_root is None:
        return compacted
    # Persist to artifact and return a reference instead
    debug_root = repo_root / ".devflow" / "agent_debug" / "streaming_context"
    debug_root.mkdir(parents=True, exist_ok=True)
    artifact_path = debug_root / "large_context.json"
    artifact_path.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
    return {
        "context_artifact_path": str(artifact_path),
        "context_artifact_note": "The full context was persisted to disk because the prompt exceeded size limits. Read the file at the path above for detailed context.",
    }


def _string_list(values: list[Any] | None, *, limit: int | None = None) -> list[str]:
    items = [str(item).strip() for item in (values or []) if str(item).strip()]
    deduped = list(dict.fromkeys(items))
    if limit is None:
        return deduped
    return deduped[:limit]


def _green_story_summary(*, story: dict[str, Any], test_design: dict[str, Any], implementation_planning: dict[str, Any]) -> str:
    contract = dict(story.get("contract") or {})
    candidates = [
        implementation_planning.get("summary"),
        test_design.get("summary"),
        story.get("summary"),
        contract.get("summary"),
        contract.get("goal"),
        story.get("description"),
    ]
    for candidate in candidates:
        text = str(candidate or "").strip()
        if text:
            return text
    return ""


def _collect_green_primary_seams(*, story: dict[str, Any], test_design: dict[str, Any], implementation_planning: dict[str, Any], reconciled_verification: dict[str, Any] | None = None, recovery_handoff: dict[str, Any] | None = None) -> list[str]:
    candidates: list[str] = []

    def _push(value: Any) -> None:
        if isinstance(value, str) and value.strip():
            candidates.append(value.strip())
        elif isinstance(value, list):
            for item in value:
                _push(item)
        elif isinstance(value, dict):
            for key in ("path", "file", "target_file", "target_path", "module", "component", "provider", "implementation_file"):
                if value.get(key):
                    _push(value.get(key))
            for key in ("paths", "files", "targets", "file_targets", "implementation_targets", "seams"):
                if value.get(key):
                    _push(value.get(key))

    _push(test_design.get("file_targets"))
    for bundle in (test_design.get("bundles") or []):
        if isinstance(bundle, dict):
            _push(bundle.get("file_targets"))
    for pathway in (implementation_planning.get("preferred_pathways") or []):
        _push(pathway)
    for finding in (implementation_planning.get("internal_findings") or []):
        _push(finding)
    for bundle in ((reconciled_verification or {}).get("bundles") or []):
        if isinstance(bundle, dict):
            _push(bundle.get("file_targets"))
            _push(bundle.get("red_generation"))
    replay = story.get("replay") if isinstance(story.get("replay"), dict) else {}
    _push(replay.get("repaired_artifacts"))
    if isinstance(recovery_handoff, dict):
        _push(recovery_handoff.get("likely_seam"))
        _push(recovery_handoff.get("primary_evidence_refs"))
    return _string_list(candidates, limit=10)


def _extract_failure_signal_lines(*, text: str, limit: int = 8) -> list[str]:
    matches: list[str] = []
    patterns = (
        re.compile(r"^FAILED\s+.+"),
        re.compile(r"^E\s+.+"),
        re.compile(r"^AssertionError.*"),
        re.compile(r"^assert\s+.+"),
        re.compile(r"^Error:\s+.+"),
        re.compile(r"^\s*Expected:.+"),
        re.compile(r"^\s*Received:.+"),
    )
    for raw_line in text.splitlines():
        line = raw_line.rstrip()
        stripped = line.strip()
        if not stripped:
            continue
        if any(pattern.match(stripped) for pattern in patterns):
            matches.append(stripped)
            continue
        if "AssertionError" in stripped or "Traceback" in stripped:
            matches.append(stripped)
    if not matches:
        tail = [line.strip() for line in text.splitlines() if line.strip()]
        matches = tail[-min(limit, len(tail)):]
    return _string_list(matches, limit=limit)


def _recover_failing_assertions_from_transcript_excerpt(*, transcript_excerpt: list[str], limit: int = 8) -> list[str]:
    matches: list[str] = []
    patterns = (
        re.compile(r"\bFAILED\s+.+"),
        re.compile(r"\bAssertionError\b.+"),
        re.compile(r"\bassert\s+.+"),
        re.compile(r"\bError:\s+.+"),
    )
    for item in transcript_excerpt:
        text = str(item or "").strip()
        if not text:
            continue
        if any(pattern.search(text) for pattern in patterns):
            matches.append(text)
    return _string_list(matches, limit=limit)


def _verification_command_text(*, repo_root: Path, runtime_contract: dict[str, Any], test_paths: list[str]) -> str:
    argv, runtime_cwd = _runtime_contract_execution_plan(
        repo_root=repo_root,
        runtime_contract=runtime_contract,
        test_paths=test_paths,
    )
    rendered = json.dumps(argv)
    if runtime_cwd is not None and runtime_cwd != repo_root:
        try:
            rel = runtime_cwd.relative_to(repo_root)
            return f"(cd {rel} && {rendered})"
        except ValueError:
            return f"(cd {runtime_cwd} && {rendered})"
    return rendered


def _collect_green_verification_commands(*, repo_root: Path, story: dict[str, Any], registered_test_paths: list[str] | None, reconciled_verification: dict[str, Any] | None = None) -> list[str]:
    commands: list[str] = []
    bundles = [dict(bundle) for bundle in ((reconciled_verification or {}).get("bundles") or []) if isinstance(bundle, dict)]
    if bundles:
        for bundle in bundles:
            test_paths = _string_list(bundle.get("test_paths") or [item.get("path") for item in (bundle.get("registered_files") or []) if isinstance(item, dict)])
            if not test_paths:
                continue
            runtime_contract = dict(bundle.get("runtime_contract") or {})
            commands.append(f"{str(bundle.get('bundle_id') or 'default')}: {_verification_command_text(repo_root=repo_root, runtime_contract=runtime_contract, test_paths=test_paths)}")
        return _string_list(commands, limit=8)

    test_paths = _string_list(registered_test_paths)
    runtime_contract = _resolve_story_test_runtime_contract(repo_root=repo_root, story=story, test_paths=test_paths or None)
    if not test_paths:
        test_paths = _string_list(runtime_contract.get("test_paths"))
    if not test_paths:
        test_paths = _discover_story_scoped_test_paths(repo_root=repo_root, story=story)
    if test_paths:
        commands.append(_verification_command_text(repo_root=repo_root, runtime_contract=runtime_contract, test_paths=test_paths))
    return _string_list(commands, limit=8)


def _collect_green_failure_surface(
    *,
    gate_results: dict[str, GateResult],
    registered_test_paths: list[str] | None,
    redreview_report: dict[str, Any] | None,
    bundle_redreview_reports: list[dict[str, Any]] | None,
    reconciled_verification: dict[str, Any] | None,
    recovery_handoff: dict[str, Any] | None = None,
) -> dict[str, Any]:
    failing_test_files: list[str] = []
    failing_details: list[str] = []
    failing_checks: dict[str, Any] = {}

    for name, result in gate_results.items():
        if result.ok:
            continue
        failing_checks[name] = {
            "returncode": result.returncode,
            "stdout": _truncate_output(result.stdout[-4000:], label=f"{name} stdout", limit=4000),
            "stderr": _truncate_output(result.stderr[-4000:], label=f"{name} stderr", limit=4000),
        }
        failing_details.extend(_extract_failure_signal_lines(text=f"{result.stdout}\n{result.stderr}"))

    failing_test_files.extend(_string_list(registered_test_paths))

    for bundle in ((reconciled_verification or {}).get("bundles") or []):
        if not isinstance(bundle, dict):
            continue
        failing_test_files.extend(_string_list(bundle.get("test_paths")))
        failing_test_files.extend(_string_list([item.get("path") for item in (bundle.get("registered_files") or []) if isinstance(item, dict)]))

    reports = [dict(report) for report in (bundle_redreview_reports or []) if isinstance(report, dict)]
    if not reports and isinstance(redreview_report, dict):
        if isinstance(redreview_report.get("bundle_reports"), list):
            reports = [dict(report) for report in redreview_report.get("bundle_reports") if isinstance(report, dict)]
        else:
            reports = [dict(redreview_report)]

    for report in reports:
        history = report.get("history") if isinstance(report.get("history"), list) else []
        latest = history[-1] if history else report
        if not isinstance(latest, dict):
            continue
        failing_test_files.extend(_string_list(latest.get("validator_input_paths")))
        failing_test_files.extend(_string_list([item.get("path") for item in (latest.get("registered_files") or []) if isinstance(item, dict)]))
        assessment = latest.get("assessment") if isinstance(latest.get("assessment"), dict) else {}
        if assessment.get("message"):
            failing_details.append(str(assessment.get("message")))
        for key in ("validator_stdout", "validator_stderr", "pytest_stdout", "pytest_stderr"):
            failing_details.extend(_extract_failure_signal_lines(text=str(latest.get(key) or "")))

    if isinstance(recovery_handoff, dict):
        if recovery_handoff.get("failing_surface_summary"):
            failing_details.append(str(recovery_handoff.get("failing_surface_summary")))
        failing_test_files.extend(_string_list(recovery_handoff.get("primary_evidence_refs")))

    return {
        "failing_test_files": _string_list(failing_test_files, limit=12),
        "failing_details": _string_list(failing_details, limit=12),
        "failing_checks": failing_checks,
    }


def _collect_green_recovery_guidance(*, story: dict[str, Any], prior_attempts: list[dict[str, Any]], recovery_handoff: dict[str, Any] | None = None) -> list[str]:
    notes: list[str] = []
    replay = story.get("replay") if isinstance(story.get("replay"), dict) else {}
    if replay.get("resume_from_stage"):
        notes.append(f"resume_from_stage={replay['resume_from_stage']}")
    if replay.get("invalidated_stages"):
        notes.append(f"invalidated_stages={', '.join(_string_list(replay.get('invalidated_stages')))}")
    failure_context = story.get("failure_context") if isinstance(story.get("failure_context"), dict) else {}
    for key in ("actual_failed_node", "failed_stage", "failure_kind", "recovery_disposition"):
        value = str(failure_context.get(key) or "").strip()
        if value:
            notes.append(f"{key}={value}")
    recovery_runtime = failure_context.get("recovery_runtime") if isinstance(failure_context.get("recovery_runtime"), dict) else {}
    strategy_history = recovery_runtime.get("strategy_history") if isinstance(recovery_runtime.get("strategy_history"), list) else []
    for item in strategy_history[-3:]:
        if not isinstance(item, dict):
            continue
        strategy = str(item.get("strategy") or "").strip()
        outcome = str(item.get("outcome") or item.get("status") or "").strip()
        message = str(item.get("message") or item.get("summary") or "").strip()
        bits = [bit for bit in [strategy, outcome, message] if bit]
        if bits:
            notes.append("recovery: " + " | ".join(bits))
    if isinstance(recovery_handoff, dict):
        for key in ("key_log_insight", "non_convergence_insight"):
            value = str(recovery_handoff.get(key) or "").strip()
            if value:
                notes.append(value)
        for item in (recovery_handoff.get("disproven_dead_ends") or []):
            text = str(item or "").strip()
            if text:
                notes.append(f"dead end: {text}")
        for item in (recovery_handoff.get("verification_blockers") or []):
            text = str(item or "").strip()
            if text:
                notes.append(f"verification blocker: {text}")
    for attempt in prior_attempts[-3:]:
        if not isinstance(attempt, dict):
            continue
        gate = attempt.get("gate") if isinstance(attempt.get("gate"), dict) else {}
        still_failing = [name for name, payload in gate.items() if isinstance(payload, dict) and not bool(payload.get("ok"))]
        if still_failing:
            notes.append(f"green attempt {attempt.get('iteration')}: still failing -> {', '.join(still_failing)}")
        agent = attempt.get("agent") if isinstance(attempt.get("agent"), dict) else {}
        stderr = str(agent.get("stderr") or "").strip()
        if stderr:
            notes.extend(_extract_failure_signal_lines(text=stderr, limit=2))
    return _string_list(notes, limit=8)


def _append_green_prompt_section(lines: list[str], label: str, items: list[str]) -> None:
    values = _string_list(items)
    if not values:
        return
    if len(values) == 1:
        lines.append(f"- {label}: {values[0]}")
        return
    lines.append(f"- {label}:")
    lines.extend(f"  - {value}" for value in values)


def _tail_streaming_attempt_log(*, agent_attempt: dict[str, Any], limit: int = 8) -> list[str]:
    log_path_raw = str(agent_attempt.get("log_path") or "").strip()
    if not log_path_raw:
        return []
    log_path = Path(log_path_raw)
    if not log_path.exists() or not log_path.is_file():
        return []
    lines: list[str] = []
    try:
        for raw_line in log_path.read_text(encoding="utf-8").splitlines():
            try:
                record = json.loads(raw_line)
            except Exception:
                continue
            if not isinstance(record, dict):
                continue
            text = str(record.get("line") or "").strip()
            if not text:
                continue
            stream = str(record.get("stream") or "").strip() or "log"
            lines.append(f"{stream}: {text}")
    except Exception:
        return []
    return _string_list(lines[-limit:], limit=limit)


def _git_worktree_delta_summary(*, repo_root: Path) -> tuple[list[str], list[str]]:
    if not (repo_root / ".git").exists():
        return [], []
    status_cp = subprocess.run(
        ["git", "status", "--short"],
        cwd=str(repo_root),
        check=False,
        capture_output=True,
        text=True,
    )
    diff_cp = subprocess.run(
        ["git", "diff", "--stat", "--compact-summary"],
        cwd=str(repo_root),
        check=False,
        capture_output=True,
        text=True,
    )
    changed_files: list[str] = []
    for raw_line in (status_cp.stdout or "").splitlines():
        line = raw_line.rstrip()
        if not line:
            continue
        changed_files.append(line)
    diff_summary = [line.strip() for line in (diff_cp.stdout or "").splitlines() if line.strip()]
    return _string_list(changed_files, limit=12), _string_list(diff_summary, limit=12)


def _failing_gate_names(gate_payload: dict[str, Any] | None) -> list[str]:
    names: list[str] = []
    for name, payload in (gate_payload or {}).items():
        if isinstance(payload, dict) and not bool(payload.get("ok")):
            names.append(str(name))
    return _string_list(names)


def _select_green_likely_next_seam(*, changed_files: list[str], primary_seams: list[str], recovery_handoff: dict[str, Any] | None = None) -> str:
    normalized_changed = [line.split()[-1] for line in changed_files if line.split()]
    for candidate in normalized_changed:
        if candidate in primary_seams:
            return candidate
    for candidate in primary_seams:
        if candidate:
            return candidate
    for candidate in normalized_changed:
        if candidate:
            return candidate
    if isinstance(recovery_handoff, dict):
        return str(recovery_handoff.get("likely_seam") or "").strip()
    return ""


def _build_green_outcome_review(
    *,
    repo_root: Path,
    story: dict[str, Any],
    test_design: dict[str, Any],
    implementation_planning: dict[str, Any],
    iteration: int,
    agent_attempt: dict[str, Any],
    gate_results: dict[str, GateResult],
    prior_attempts: list[dict[str, Any]],
    registered_test_paths: list[str] | None = None,
    redreview_report: dict[str, Any] | None = None,
    bundle_redreview_reports: list[dict[str, Any]] | None = None,
    reconciled_verification: dict[str, Any] | None = None,
    recovery_handoff: dict[str, Any] | None = None,
) -> dict[str, Any]:
    story_ctx = _story_context(story)
    story_id = str(story_ctx.get("story_id") or "unknown_story")
    failure_surface = _collect_green_failure_surface(
        gate_results=gate_results,
        registered_test_paths=registered_test_paths,
        redreview_report=redreview_report,
        bundle_redreview_reports=bundle_redreview_reports,
        reconciled_verification=reconciled_verification,
        recovery_handoff=recovery_handoff,
    )
    primary_seams = _collect_green_primary_seams(
        story=story,
        test_design=test_design,
        implementation_planning=implementation_planning,
        reconciled_verification=reconciled_verification,
        recovery_handoff=recovery_handoff,
    )
    changed_files, diff_summary = _git_worktree_delta_summary(repo_root=repo_root)
    transcript_excerpt = _tail_streaming_attempt_log(agent_attempt=agent_attempt)
    previous_gate = prior_attempts[-1].get("gate") if prior_attempts and isinstance(prior_attempts[-1], dict) else {}
    previous_review = prior_attempts[-1].get("outcome_review") if prior_attempts and isinstance(prior_attempts[-1], dict) and isinstance(prior_attempts[-1].get("outcome_review"), dict) else {}
    current_gate_payload = {k: {"ok": v.ok, "returncode": v.returncode} for k, v in gate_results.items()}
    current_failed = _failing_gate_names(current_gate_payload)
    previous_failed = _failing_gate_names(previous_gate if isinstance(previous_gate, dict) else {})
    resolved_failures = [name for name in previous_failed if name not in current_failed]
    new_failures = [name for name in current_failed if name not in previous_failed]
    remaining_failures = failure_surface["failing_details"] or current_failed
    prior_failing_assertions = _string_list(previous_review.get("remaining_failures") if isinstance(previous_review, dict) else None, limit=8)

    progress_made: list[str] = []
    if changed_files:
        progress_made.append("Changed files: " + ", ".join(changed_files[:6]))
    if resolved_failures:
        progress_made.append("Resolved failing checks: " + ", ".join(resolved_failures))
    if transcript_excerpt:
        progress_made.append("Latest transcript evidence: " + transcript_excerpt[-1])

    do_not_revisit = _string_list(
        ((recovery_handoff or {}).get("disproven_dead_ends") or [])
        + ((previous_review or {}).get("do_not_revisit") or []),
        limit=8,
    )
    if changed_files and remaining_failures and not resolved_failures:
        do_not_revisit = _string_list(
            do_not_revisit + [f"Do not repeat the same edit shape in {', '.join(changed_files[:4])} without new evidence."],
            limit=8,
        )

    likely_next_seam = _select_green_likely_next_seam(
        changed_files=changed_files,
        primary_seams=primary_seams,
        recovery_handoff=recovery_handoff,
    )
    verification_commands = _collect_green_verification_commands(
        repo_root=repo_root,
        story=story,
        registered_test_paths=registered_test_paths,
        reconciled_verification=reconciled_verification,
    )
    recommended_next_actions: list[str] = []
    if likely_next_seam:
        recommended_next_actions.append(f"Inspect {likely_next_seam} against the remaining failing assertion/error evidence.")
    if remaining_failures:
        recommended_next_actions.append(f"Target the unresolved failures: {', '.join(remaining_failures[:3])}")
    if verification_commands:
        recommended_next_actions.append(f"Re-run verification with {verification_commands[0]}")

    review = {
        "schema_version": 1,
        "kind": "green_outcome_review",
        "story_id": story_id,
        "iteration": iteration,
        "reviewed_iteration": iteration,
        "progress_made": _string_list(progress_made, limit=8),
        "resolved_failures": _string_list(resolved_failures, limit=8),
        "remaining_failures": _string_list(remaining_failures, limit=8),
        "new_failures": _string_list(new_failures, limit=8),
        "likely_next_seam": likely_next_seam,
        "environment_blockers": [],
        "do_not_revisit": do_not_revisit,
        "recommended_next_actions": _string_list(recommended_next_actions, limit=8),
        "evidence": {
            "transcript_excerpt": transcript_excerpt,
            "gate_failures": current_gate_payload,
            "prior_failing_assertions": prior_failing_assertions,
            "changed_files": changed_files,
            "diff_summary": diff_summary,
            "agent_log_path": str(agent_attempt.get("log_path") or "").strip() or None,
        },
    }
    artifact_path = _green_outcome_review_artifact_path(repo_root=repo_root, story_id=story_id, iteration=iteration)
    latest_path = _green_latest_outcome_review_artifact_path(repo_root=repo_root, story_id=story_id)
    review["artifact_path"] = str(artifact_path)
    review["latest_artifact_path"] = str(latest_path)
    _write_json(artifact_path, review)
    _write_json(latest_path, review)
    return review


def _append_green_outcome_review_section(lines: list[str], review: dict[str, Any]) -> None:
    lines.append(load_implementation_review_instruction("green_outcome_review"))
    for item in load_implementation_review_guidance("green_outcome_review"):
        lines.append(f"- {item}")
    _append_green_prompt_section(lines, "Progress made last iteration", review.get("progress_made") if isinstance(review, dict) else [])
    _append_green_prompt_section(lines, "Resolved failures", review.get("resolved_failures") if isinstance(review, dict) else [])
    _append_green_prompt_section(lines, "Remaining failures", review.get("remaining_failures") if isinstance(review, dict) else [])
    _append_green_prompt_section(lines, "New failures", review.get("new_failures") if isinstance(review, dict) else [])
    likely_next_seam = str(review.get("likely_next_seam") or "").strip() if isinstance(review, dict) else ""
    if likely_next_seam:
        lines.append(f"- Likely next seam: {likely_next_seam}")
    _append_green_prompt_section(lines, "Do not revisit", review.get("do_not_revisit") if isinstance(review, dict) else [])
    _append_green_prompt_section(lines, "Recommended next actions", review.get("recommended_next_actions") if isinstance(review, dict) else [])


def _append_green_prior_run_review_section(lines: list[str], prior_run_evidence: dict[str, Any]) -> None:
    review = dict(prior_run_evidence.get("review") or {})
    lines.append(load_implementation_review_instruction("green_prior_run_review"))
    for item in load_implementation_review_guidance("green_prior_run_review"):
        lines.append(f"- {item}")
    source_bits = [str(prior_run_evidence.get("source_type") or "").strip()]
    source_run_id = str(prior_run_evidence.get("source_run_id") or "").strip()
    source_artifact_path = str(prior_run_evidence.get("source_artifact_path") or "").strip()
    source_log_path = str(prior_run_evidence.get("source_log_path") or "").strip()
    if source_run_id:
        source_bits.append(f"run={source_run_id}")
    if source_artifact_path:
        source_bits.append(f"artifact={source_artifact_path}")
    if source_log_path:
        source_bits.append(f"log={source_log_path}")
    if source_bits:
        lines.append("- Selected prior evidence: " + " | ".join(bit for bit in source_bits if bit))
    _append_green_prompt_section(lines, "Progress made previously", review.get("progress_made") if isinstance(review, dict) else [])
    _append_green_prompt_section(lines, "Recovered remaining failures", review.get("remaining_failures") if isinstance(review, dict) else [])
    likely_next_seam = str(review.get("likely_next_seam") or "").strip()
    if likely_next_seam:
        lines.append(f"- Likely next seam: {likely_next_seam}")
    _append_green_prompt_section(lines, "Do not revisit", review.get("do_not_revisit") if isinstance(review, dict) else [])
    _append_green_prompt_section(lines, "Recommended next actions", review.get("recommended_next_actions") if isinstance(review, dict) else [])
    _append_green_prompt_section(lines, "Transcript excerpt", prior_run_evidence.get("transcript_excerpt") if isinstance(prior_run_evidence, dict) else [])


def _build_green_agent_prompt(
    *,
    repo_root: Path,
    story: dict[str, Any],
    test_design: dict[str, Any],
    implementation_planning: dict[str, Any],
    gate_results: dict[str, GateResult],
    prior_attempts: list[dict[str, Any]],
    registered_test_paths: list[str] | None = None,
    redreview_report: dict[str, Any] | None = None,
    bundle_redreview_reports: list[dict[str, Any]] | None = None,
    reconciled_verification: dict[str, Any] | None = None,
    recovery_handoff: dict[str, Any] | None = None,
    prior_iteration_review: dict[str, Any] | None = None,
    selected_prior_run_evidence: dict[str, Any] | None = None,
    prompt_mode: str | None = None,
) -> str:
    contract = dict(story.get("contract") or {})
    story_summary = _green_story_summary(story=story, test_design=test_design, implementation_planning=implementation_planning)
    failure_surface = _collect_green_failure_surface(
        gate_results=gate_results,
        registered_test_paths=registered_test_paths,
        redreview_report=redreview_report,
        bundle_redreview_reports=bundle_redreview_reports,
        reconciled_verification=reconciled_verification,
        recovery_handoff=recovery_handoff,
    )
    verification_commands = _collect_green_verification_commands(
        repo_root=repo_root,
        story=story,
        registered_test_paths=registered_test_paths,
        reconciled_verification=reconciled_verification,
    )
    primary_seams = _collect_green_primary_seams(
        story=story,
        test_design=test_design,
        implementation_planning=implementation_planning,
        reconciled_verification=reconciled_verification,
        recovery_handoff=recovery_handoff,
    )
    recovery_guidance = _collect_green_recovery_guidance(story=story, prior_attempts=prior_attempts, recovery_handoff=recovery_handoff)
    effective_prompt_mode = str(prompt_mode or "").strip().lower()
    if effective_prompt_mode not in {"start", "refine"}:
        effective_prompt_mode = "refine" if (prior_iteration_review or selected_prior_run_evidence) else "start"
    payload = {
        "story": {
            "story_id": contract.get("story_id") or story.get("story_id"),
            "story_uuid": contract.get("story_uuid") or story.get("story_uuid"),
            "title": contract.get("title") or story.get("title"),
            "summary": story_summary,
            "required_planes": _string_list(contract.get("required_planes")),
        },
        "green_focus": {
            "failing_test_files": failure_surface["failing_test_files"],
            "failing_assertions_or_errors": failure_surface["failing_details"],
            "verification_commands": verification_commands,
            "primary_seam_files": primary_seams,
            "recovery_guidance": recovery_guidance,
        },
        "test_design": {
            "summary": str(test_design.get("summary") or "").strip(),
            "must_cover": _string_list(test_design.get("must_cover"), limit=12),
            "must_avoid": _string_list(test_design.get("must_avoid"), limit=12),
            "bundles": [
                {
                    "bundle_id": str(bundle.get("bundle_id") or "default"),
                    "planes": _string_list(bundle.get("planes")),
                    "runtime_family": str(bundle.get("runtime_family") or "default"),
                    "file_targets": _string_list(bundle.get("file_targets"), limit=8),
                    "must_cover": _string_list(bundle.get("must_cover"), limit=8),
                }
                for bundle in (test_design.get("bundles") or [])
                if isinstance(bundle, dict)
            ],
        },
        "implementation_planning": {
            "planning_status": implementation_planning.get("planning_status"),
            "summary": str(implementation_planning.get("summary") or "").strip(),
            "preferred_pathways": implementation_planning.get("preferred_pathways") or [],
            "blocking_issues": implementation_planning.get("blocking_issues") or [],
        },
        "reconciled_verification": {
            "summary": str((reconciled_verification or {}).get("summary") or "").strip(),
            "bundle_count": (reconciled_verification or {}).get("bundle_count"),
            "bundles": [
                {
                    "bundle_id": str(bundle.get("bundle_id") or "default"),
                    "planes": _string_list(bundle.get("planes")),
                    "runtime_family": str(bundle.get("runtime_family") or "default"),
                    "test_paths": _string_list(bundle.get("test_paths"), limit=8),
                    "registered_files": _string_list([item.get("path") for item in (bundle.get("registered_files") or []) if isinstance(item, dict)], limit=8),
                    "file_targets": _string_list(bundle.get("file_targets"), limit=8),
                }
                for bundle in ((reconciled_verification or {}).get("bundles") or [])
                if isinstance(bundle, dict)
            ],
        },
        "recovery_handoff": {
            "failing_surface_summary": str((recovery_handoff or {}).get("failing_surface_summary") or "").strip(),
            "likely_seam": str((recovery_handoff or {}).get("likely_seam") or "").strip(),
            "disproven_dead_ends": _string_list((recovery_handoff or {}).get("disproven_dead_ends"), limit=8),
            "verification_blockers": _string_list((recovery_handoff or {}).get("verification_blockers"), limit=8),
            "primary_evidence_refs": _string_list((recovery_handoff or {}).get("primary_evidence_refs"), limit=8),
            "key_log_insight": str((recovery_handoff or {}).get("key_log_insight") or "").strip(),
            "non_convergence_insight": str((recovery_handoff or {}).get("non_convergence_insight") or "").strip(),
        },
        "green_prompt_mode": effective_prompt_mode,
        "selected_prior_run_evidence": dict(selected_prior_run_evidence or {}),
        "prior_iteration_outcome_review": dict(prior_iteration_review or {}),
        "failing_green_checks": failure_surface["failing_checks"],
        "prior_attempts": prior_attempts[-3:],
    }
    payload = _compact_streaming_payload(payload, repo_root=repo_root)
    brief_lines = [load_implementation_stage_instruction("green")]
    for line in load_implementation_stage_guidance("green"):
        if line == "Hard rules:":
            brief_lines.append(line)
        else:
            brief_lines.append(f"- {line}")
    if isinstance(prior_iteration_review, dict) and prior_iteration_review:
        _append_green_outcome_review_section(brief_lines, prior_iteration_review)
    elif isinstance(selected_prior_run_evidence, dict) and selected_prior_run_evidence:
        _append_green_prior_run_review_section(brief_lines, selected_prior_run_evidence)
    brief_lines.extend(
        [
            "Priority brief:",
            f"- Story: {contract.get('story_id') or story.get('story_id') or 'unknown'} — {contract.get('title') or story.get('title') or 'Untitled story'}",
        ]
    )
    if story_summary:
        brief_lines.append(f"- Story summary: {story_summary}")
    _append_green_prompt_section(brief_lines, "Failing test files", failure_surface["failing_test_files"])
    _append_green_prompt_section(brief_lines, "Failing assertions/errors", failure_surface["failing_details"])
    _append_green_prompt_section(brief_lines, "Verify with", verification_commands)
    _append_green_prompt_section(brief_lines, "Likely primary seam files", primary_seams)
    _append_green_prompt_section(brief_lines, "Recovery / prior-attempt guidance", recovery_guidance)
    brief_lines.extend([
        "Compact context JSON:",
        json.dumps(payload, indent=2, sort_keys=True),
    ])
    return "\n".join(brief_lines)


def _run_green_sufficiency_loop(
    *,
    repo_root: Path,
    story: dict[str, Any],
    test_design: dict[str, Any],
    implementation_planning: dict[str, Any],
    registered_test_paths: list[str] | None = None,
    redreview_report: dict[str, Any] | None = None,
    on_iteration_complete: "Callable[[int, int, list[dict[str, Any]], dict[str, Any]], None] | None" = None,
) -> tuple[dict[str, Any], bool]:
    """Run the green agent loop against story-scoped tests only.

    Green's job is implementation: make this story's registered tests pass.
    Repo-wide regression checking belongs to integration, not here.

    Green trusts the accepted RED contract. It should first verify whether the
    accepted story-scoped tests already pass against the current repo state.
    If they do, Green should short-circuit successfully and avoid unnecessary
    agent churn. Otherwise it proceeds into implementation work, then validates
    the post-change result against the same registered story-scoped tests.

    Args:
        registered_test_paths: test paths registered by RedReview for this story.
            If absent, discovered from the story's test_runtime contract.
        on_iteration_complete: optional callback fired after each iteration with
            (iteration, max_iterations, history_so_far, gate_payload).
            Used for mid-loop progress updates to the execution store.
    """
    history: list[dict[str, Any]] = []
    max_iterations = _green_max_iterations()
    latest_results, _gate_meta = _run_story_scoped_gate(
        repo_root=repo_root,
        story=story,
        registered_test_paths=registered_test_paths or None,
        trust_red_contract=True,
    )
    if latest_results and all(v.ok for v in latest_results.values()):
        final_payload = {k: {"ok": v.ok, "returncode": v.returncode} for k, v in latest_results.items()}
        return {
            "mode": "model_backed",
            "max_iterations": max_iterations,
            "iterations_used": 0,
            "history": history,
            "final_gate": final_payload,
            "status": "passed",
            "short_circuited": True,
            "short_circuit_reason": "story_tests_already_passing",
        }, True

    recovery_handoff = _load_recovery_handoff_artifact(repo_root=repo_root, story=story)
    selected_prior_run_evidence = _select_green_prior_run_evidence(
        repo_root=repo_root,
        story=story,
        recovery_handoff=recovery_handoff,
    )
    initial_prompt_mode = "refine" if selected_prior_run_evidence else "start"
    latest_outcome_review: dict[str, Any] | None = None
    for iteration in range(1, max_iterations + 1):
        prompt_mode = "refine" if (iteration > 1 or selected_prior_run_evidence) else "start"
        prompt = _build_green_agent_prompt(
            repo_root=repo_root,
            story=story,
            test_design=test_design,
            implementation_planning=implementation_planning,
            gate_results=latest_results,
            prior_attempts=history,
            registered_test_paths=registered_test_paths,
            redreview_report=redreview_report,
            recovery_handoff=recovery_handoff,
            prior_iteration_review=latest_outcome_review,
            selected_prior_run_evidence=selected_prior_run_evidence if iteration == 1 else None,
            prompt_mode=prompt_mode,
        )
        agent_attempt = _run_green_agent(repo_root=repo_root, prompt=prompt, strength=("strong" if iteration > 1 else None))
        latest_results, _gate_meta = _run_story_scoped_gate(
            repo_root=repo_root,
            story=story,
            registered_test_paths=registered_test_paths or None,
            trust_red_contract=True,
        )
        gate_payload = {k: {"ok": v.ok, "returncode": v.returncode} for k, v in latest_results.items()}
        iter_entry = {
            "iteration": iteration,
            "agent": agent_attempt,
            "gate": gate_payload,
            "prompt_mode": prompt_mode,
        }
        if iteration == 1 and selected_prior_run_evidence:
            iter_entry["selected_prior_run_evidence"] = selected_prior_run_evidence
        if not all(v.ok for v in latest_results.values()):
            latest_outcome_review = _build_green_outcome_review(
                repo_root=repo_root,
                story=story,
                test_design=test_design,
                implementation_planning=implementation_planning,
                iteration=iteration,
                agent_attempt=agent_attempt,
                gate_results=latest_results,
                prior_attempts=history,
                registered_test_paths=registered_test_paths,
                redreview_report=redreview_report,
                recovery_handoff=recovery_handoff,
            )
            iter_entry["outcome_review"] = latest_outcome_review
        history.append(iter_entry)

        if on_iteration_complete is not None:
            try:
                on_iteration_complete(iteration, max_iterations, history, gate_payload)
            except Exception:
                pass  # progress updates are best-effort; never abort the loop

        if all(v.ok for v in latest_results.values()):
            break

    final_payload = {k: {"ok": v.ok, "returncode": v.returncode} for k, v in latest_results.items()}
    ok = all(v.ok for v in latest_results.values()) if latest_results else True
    report = {
        "mode": "model_backed",
        "max_iterations": max_iterations,
        "iterations_used": len(history),
        "initial_prompt_mode": initial_prompt_mode,
        "selected_prior_run_evidence": selected_prior_run_evidence,
        "history": history,
        "outcome_reviews": [dict(item.get("outcome_review")) for item in history if isinstance(item, dict) and isinstance(item.get("outcome_review"), dict)],
        "latest_outcome_review": latest_outcome_review,
        "final_gate": final_payload,
        "status": "passed" if ok else "failed",
    }
    return report, ok


def _run_bundle_story_scoped_gate(
    *,
    repo_root: Path,
    story: dict[str, Any],
    bundle_plan: dict[str, Any],
) -> tuple[dict[str, GateResult], dict[str, Any]]:
    engine_root = Path(__file__).resolve().parents[3]
    story_ctx = _story_context(story)
    story_id = str(story_ctx.get("story_id") or "").strip()
    bundle_id = str(bundle_plan.get("bundle_id") or "default")
    test_paths = [str(path) for path in (bundle_plan.get("test_paths") or []) if str(path).strip()]
    runtime_contract = dict(bundle_plan.get("runtime_contract") or {})
    if not runtime_contract:
        runtime_contract, runtime_contract_path, _command_probe, _command_attempts = _establish_verified_bundle_test_runtime_contract(
            repo_root=repo_root,
            story=story,
            bundle=bundle_plan,
            test_paths=test_paths,
            source=f"green_bundle:{bundle_id}",
        )
    else:
        runtime_contract_path = Path(str(bundle_plan.get("runtime_contract_path"))) if bundle_plan.get("runtime_contract_path") else None
    bundle_planes = [str(p) for p in (bundle_plan.get("planes") or []) if str(p).strip()]
    validator_cp = _run_story_test_validator(
        engine_root=engine_root,
        repo_root=repo_root,
        story_id=story_id,
        test_paths=test_paths,
        required_planes=bundle_planes or None,
    ) if story_id else subprocess.CompletedProcess(args=["validator"], returncode=2, stdout="", stderr="Missing story_id for story-scoped validation.")
    test_cp = _run_story_scoped_tests(repo_root=repo_root, runtime_contract=runtime_contract, test_paths=test_paths)
    results = {
        f"{bundle_id}:story_test_validation": GateResult(ok=validator_cp.returncode == 0, stdout=validator_cp.stdout, stderr=validator_cp.stderr, returncode=validator_cp.returncode),
        f"{bundle_id}:story_tests": GateResult(ok=test_cp.returncode == 0, stdout=test_cp.stdout, stderr=test_cp.stderr, returncode=test_cp.returncode),
    }
    return results, {
        "bundle_id": bundle_id,
        "test_paths": test_paths,
        "runtime_framework": runtime_contract.get("framework"),
        "run_cmd": list(runtime_contract.get("run_cmd") or []),
        "runtime_contract_path": None if runtime_contract_path is None else str(runtime_contract_path),
        "runtime_family": bundle_plan.get("runtime_family"),
    }


def _run_reconciled_green_loop(
    *,
    repo_root: Path,
    story: dict[str, Any],
    test_design: dict[str, Any],
    implementation_planning: dict[str, Any],
    reconciled_verification: dict[str, Any],
    bundle_redreview_reports: list[dict[str, Any]] | None = None,
    on_iteration_complete: "Callable[[int, int, list[dict[str, Any]], dict[str, Any]], None] | None" = None,
) -> tuple[dict[str, Any], bool]:
    history: list[dict[str, Any]] = []
    max_iterations = _green_max_iterations()
    bundle_plans = [dict(bundle) for bundle in (reconciled_verification.get("bundles") or []) if isinstance(bundle, dict)]

    def _run_all_bundle_gates() -> tuple[dict[str, GateResult], dict[str, Any]]:
        merged_results: dict[str, GateResult] = {}
        bundle_meta: dict[str, Any] = {}
        for bundle_plan in bundle_plans:
            bundle_results, meta = _run_bundle_story_scoped_gate(repo_root=repo_root, story=story, bundle_plan=bundle_plan)
            merged_results.update(bundle_results)
            bundle_meta[str(bundle_plan.get("bundle_id") or "default")] = meta
        return merged_results, bundle_meta

    latest_results, latest_meta = _run_all_bundle_gates()
    if latest_results and all(v.ok for v in latest_results.values()):
        final_payload = {k: {"ok": v.ok, "returncode": v.returncode} for k, v in latest_results.items()}
        return {
            "mode": "model_backed",
            "max_iterations": max_iterations,
            "iterations_used": 0,
            "history": history,
            "final_gate": final_payload,
            "bundle_gate_meta": latest_meta,
            "status": "passed",
            "short_circuited": True,
            "short_circuit_reason": "story_tests_already_passing",
        }, True

    recovery_handoff = _load_recovery_handoff_artifact(repo_root=repo_root, story=story)
    selected_prior_run_evidence = _select_green_prior_run_evidence(
        repo_root=repo_root,
        story=story,
        recovery_handoff=recovery_handoff,
    )
    initial_prompt_mode = "refine" if selected_prior_run_evidence else "start"
    latest_outcome_review: dict[str, Any] | None = None
    for iteration in range(1, max_iterations + 1):
        prompt_mode = "refine" if (iteration > 1 or selected_prior_run_evidence) else "start"
        prompt = _build_green_agent_prompt(
            repo_root=repo_root,
            story=story,
            test_design=test_design,
            implementation_planning=implementation_planning,
            gate_results=latest_results,
            prior_attempts=history,
            registered_test_paths=[
                str(path)
                for bundle in bundle_plans
                for path in (bundle.get("test_paths") or [])
                if str(path).strip()
            ],
            bundle_redreview_reports=[dict(report) for report in (bundle_redreview_reports or []) if isinstance(report, dict)],
            reconciled_verification=reconciled_verification,
            recovery_handoff=recovery_handoff,
            prior_iteration_review=latest_outcome_review,
            selected_prior_run_evidence=selected_prior_run_evidence if iteration == 1 else None,
            prompt_mode=prompt_mode,
        )
        agent_attempt = _run_green_agent(repo_root=repo_root, prompt=prompt, strength=("strong" if iteration > 1 else None))
        latest_results, latest_meta = _run_all_bundle_gates()
        gate_payload = {k: {"ok": v.ok, "returncode": v.returncode} for k, v in latest_results.items()}
        iter_entry = {
            "iteration": iteration,
            "agent": agent_attempt,
            "gate": gate_payload,
            "bundle_gate_meta": latest_meta,
            "prompt_mode": prompt_mode,
        }
        if iteration == 1 and selected_prior_run_evidence:
            iter_entry["selected_prior_run_evidence"] = selected_prior_run_evidence
        if not all(v.ok for v in latest_results.values()):
            latest_outcome_review = _build_green_outcome_review(
                repo_root=repo_root,
                story=story,
                test_design=test_design,
                implementation_planning=implementation_planning,
                iteration=iteration,
                agent_attempt=agent_attempt,
                gate_results=latest_results,
                prior_attempts=history,
                registered_test_paths=[
                    str(path)
                    for bundle in bundle_plans
                    for path in (bundle.get("test_paths") or [])
                    if str(path).strip()
                ],
                bundle_redreview_reports=[dict(report) for report in (bundle_redreview_reports or []) if isinstance(report, dict)],
                reconciled_verification=reconciled_verification,
                recovery_handoff=recovery_handoff,
            )
            iter_entry["outcome_review"] = latest_outcome_review
        history.append(iter_entry)
        if on_iteration_complete is not None:
            try:
                on_iteration_complete(iteration, max_iterations, history, gate_payload)
            except Exception:
                pass
        if all(v.ok for v in latest_results.values()):
            break

    final_payload = {k: {"ok": v.ok, "returncode": v.returncode} for k, v in latest_results.items()}
    ok = all(v.ok for v in latest_results.values()) if latest_results else True
    return {
        "mode": "model_backed",
        "max_iterations": max_iterations,
        "iterations_used": len(history),
        "initial_prompt_mode": initial_prompt_mode,
        "selected_prior_run_evidence": selected_prior_run_evidence,
        "history": history,
        "outcome_reviews": [dict(item.get("outcome_review")) for item in history if isinstance(item, dict) and isinstance(item.get("outcome_review"), dict)],
        "latest_outcome_review": latest_outcome_review,
        "final_gate": final_payload,
        "bundle_gate_meta": latest_meta,
        "status": "passed" if ok else "failed",
    }, ok


def _collect_refactor_guardrails(
    *,
    story: dict[str, Any],
    test_design: dict[str, Any],
    implementation_planning: dict[str, Any],
) -> list[str]:
    contract = dict(story.get("contract") or {})
    guardrails: list[str] = ["Do not change approved behavior; keep this refactor behavior-preserving."]

    for value in (
        test_design.get("must_avoid"),
        implementation_planning.get("must_avoid"),
        implementation_planning.get("guardrails"),
        implementation_planning.get("do_not_change"),
        contract.get("guardrails"),
        contract.get("do_not_change"),
        story.get("guardrails"),
        story.get("do_not_change"),
    ):
        if isinstance(value, list):
            guardrails.extend(str(item).strip() for item in value if str(item).strip())
        else:
            text = str(value or "").strip()
            if text:
                guardrails.append(text)

    return _string_list(guardrails, limit=8)


def _collect_refactor_success_criteria(
    *,
    test_design: dict[str, Any],
    verification_commands: list[str],
    story: dict[str, Any],
    implementation_planning: dict[str, Any],
) -> list[str]:
    contract = dict(story.get("contract") or {})
    criteria: list[str] = []
    if verification_commands:
        criteria.append("Run the listed verification command(s) successfully after the refactor.")

    for value in (
        test_design.get("must_cover"),
        implementation_planning.get("success_criteria"),
        contract.get("success_criteria"),
        story.get("success_criteria"),
        story.get("acceptance_criteria"),
        contract.get("acceptance_criteria"),
    ):
        if isinstance(value, list):
            criteria.extend(str(item).strip() for item in value if str(item).strip())
        else:
            text = str(value or "").strip()
            if text:
                criteria.append(text)

    return _string_list(criteria, limit=8)


def _build_refactor_agent_prompt(
    *,
    repo_root: Path,
    story: dict[str, Any],
    test_design: dict[str, Any],
    implementation_planning: dict[str, Any],
    prior_attempts: list[dict[str, Any]],
    reconciled_verification: dict[str, Any] | None = None,
) -> str:
    del prior_attempts
    contract = dict(story.get("contract") or {})
    story_summary = _green_story_summary(
        story=story,
        test_design=test_design,
        implementation_planning=implementation_planning,
    )
    objective = str(
        implementation_planning.get("summary")
        or test_design.get("summary")
        or story_summary
        or "Improve the implementation structure while preserving approved behavior."
    ).strip()
    verification_commands = _collect_green_verification_commands(
        repo_root=repo_root,
        story=story,
        registered_test_paths=None,
        reconciled_verification=reconciled_verification,
    )
    success_criteria = _collect_refactor_success_criteria(
        test_design=test_design,
        verification_commands=verification_commands,
        story=story,
        implementation_planning=implementation_planning,
    )
    guardrails = _collect_refactor_guardrails(
        story=story,
        test_design=test_design,
        implementation_planning=implementation_planning,
    )
    payload = {
        "story": {
            "story_id": contract.get("story_id") or story.get("story_id"),
            "story_uuid": contract.get("story_uuid") or story.get("story_uuid"),
            "title": contract.get("title") or story.get("title"),
            "summary": story_summary,
        },
        "verification_commands": verification_commands,
        "refactor_objective": objective,
        "success_criteria": success_criteria,
        "guardrails": guardrails,
    }
    payload = _compact_streaming_payload(payload, repo_root=repo_root)
    brief_lines = [
        "You are the implementation Refactor node for DevFlow Engine.",
        "Goal: improve structure and maintainability without changing approved behavior.",
        "Refactor brief:",
        "- Story: "
        f"{contract.get('story_id') or story.get('story_id') or 'unknown'}"
        " — "
        f"{contract.get('title') or story.get('title') or 'Untitled story'}",
    ]
    if story_summary:
        brief_lines.append(f"- Story summary: {story_summary}")
    _append_green_prompt_section(brief_lines, "Verify with", verification_commands)
    brief_lines.append(f"- Refactor objective: {objective}")
    _append_green_prompt_section(brief_lines, "Success criteria", success_criteria)
    _append_green_prompt_section(brief_lines, "Guardrails / do not change", guardrails)
    brief_lines.extend(
        [
            "Hard rules:",
            "- Refactor only; do not change scope or invent new behavior.",
            "- No mocks, stubs, heuristics, or fallback refactoring paths.",
            "- Make direct repo edits only; keep changes minimal.",
            "- Do not emit markdown; just do the work in the repo.",
            "Compact context JSON:",
            json.dumps(payload, indent=2, sort_keys=True),
        ]
    )
    return "\n".join(brief_lines)


def _run_refactor_agent(*, repo_root: Path, prompt: str, strength: str | None = None) -> dict[str, Any]:
    return _run_streaming_cli_attempt(repo_root=repo_root, prompt=prompt, timeout_seconds=_refactor_timeout_seconds(), strength=strength)


def _collect_security_changed_seams_and_files(
    *,
    story: dict[str, Any],
    test_design: dict[str, Any],
    implementation_planning: dict[str, Any],
    refactor_report: dict[str, Any],
) -> list[str]:
    candidates: list[str] = []

    def _push(value: Any) -> None:
        if isinstance(value, str) and value.strip():
            candidates.append(value.strip())
        elif isinstance(value, list):
            for item in value:
                _push(item)
        elif isinstance(value, dict):
            for key in (
                "changed_seam",
                "likely_seam",
                "path",
                "file",
                "target_file",
                "target_path",
                "module",
                "component",
                "implementation_file",
            ):
                if value.get(key):
                    _push(value.get(key))
            for key in (
                "changed_seams",
                "changed_files",
                "modified_files",
                "touched_files",
                "edited_files",
                "paths",
                "files",
                "targets",
                "file_targets",
                "implementation_targets",
                "seams",
            ):
                if value.get(key):
                    _push(value.get(key))

    _push(refactor_report.get("changed_seam"))
    _push(refactor_report.get("changed_seams"))
    _push(refactor_report.get("changed_files"))
    _push(refactor_report.get("modified_files"))
    _push(refactor_report.get("touched_files"))
    _push(refactor_report.get("edited_files"))
    for entry in (refactor_report.get("history") or []):
        if isinstance(entry, dict):
            _push(entry.get("changed_files"))
            agent = entry.get("agent") if isinstance(entry.get("agent"), dict) else {}
            _push(agent.get("changed_files"))
            _push(agent.get("modified_files"))
    if not candidates:
        candidates.extend(
            _collect_green_primary_seams(
                story=story,
                test_design=test_design,
                implementation_planning=implementation_planning,
            )
        )
    return _string_list(candidates, limit=10)


def _collect_security_verification_commands(*, repo_root: Path, story: dict[str, Any], test_design: dict[str, Any], reconciled_verification: dict[str, Any] | None = None) -> list[str]:
    if isinstance(reconciled_verification, dict) and (reconciled_verification.get("bundles") or []):
        return _collect_green_verification_commands(
            repo_root=repo_root,
            story=story,
            registered_test_paths=None,
            reconciled_verification=reconciled_verification,
        )
    commands: list[str] = []
    for bundle in (test_design.get("bundles") or []):
        if not isinstance(bundle, dict):
            continue
        test_paths = _string_list(bundle.get("test_paths") or [item.get("path") for item in (bundle.get("registered_files") or []) if isinstance(item, dict)])
        if not test_paths:
            continue
        runtime_contract = dict(bundle.get("runtime_contract") or {})
        commands.append(f"{str(bundle.get('bundle_id') or 'default')}: {_verification_command_text(repo_root=repo_root, runtime_contract=runtime_contract, test_paths=test_paths)}")
    if commands:
        return _string_list(commands, limit=8)
    return _collect_green_verification_commands(repo_root=repo_root, story=story, registered_test_paths=_string_list(test_design.get("test_paths")))


def _collect_security_success_criteria(*, verification_commands: list[str], story: dict[str, Any], test_design: dict[str, Any], implementation_planning: dict[str, Any]) -> list[str]:
    contract = dict(story.get("contract") or {})
    criteria: list[str] = []
    if verification_commands:
        criteria.append("Run the listed verification command(s) successfully and only claim remediation that those results support.")
    else:
        criteria.append("If the required verification command is unavailable, report the blocker honestly instead of claiming closure.")
    for value in (
        implementation_planning.get("success_criteria"),
        test_design.get("must_cover"),
        story.get("success_criteria"),
        contract.get("success_criteria"),
        story.get("acceptance_criteria"),
        contract.get("acceptance_criteria"),
    ):
        if isinstance(value, list):
            criteria.extend(str(item).strip() for item in value if str(item).strip())
        else:
            text = str(value or "").strip()
            if text:
                criteria.append(text)
    return _string_list(criteria, limit=8)


def _collect_security_guardrails(*, story: dict[str, Any], test_design: dict[str, Any], implementation_planning: dict[str, Any]) -> list[str]:
    contract = dict(story.get("contract") or {})
    guardrails: list[str] = [
        "Do not change approved behavior, scope, or architecture beyond the minimum security repair.",
        "Do not treat py_compile, lint-only checks, or source inspection as real closure when required verification commands exist or were expected.",
        "No mocks, stubs, heuristics, or fallback security-review paths.",
    ]
    for value in (
        test_design.get("must_avoid"),
        implementation_planning.get("must_avoid"),
        implementation_planning.get("guardrails"),
        implementation_planning.get("do_not_change"),
        contract.get("guardrails"),
        contract.get("do_not_change"),
        story.get("guardrails"),
        story.get("do_not_change"),
    ):
        if isinstance(value, list):
            guardrails.extend(str(item).strip() for item in value if str(item).strip())
        else:
            text = str(value or "").strip()
            if text:
                guardrails.append(text)
    return _string_list(guardrails, limit=8)


def _build_security_agent_prompt(*, repo_root: Path, story: dict[str, Any], test_design: dict[str, Any], implementation_planning: dict[str, Any], refactor_report: dict[str, Any], prior_attempts: list[dict[str, Any]], reconciled_verification: dict[str, Any] | None = None) -> str:
    del prior_attempts
    contract = dict(story.get("contract") or {})
    story_summary = _green_story_summary(story=story, test_design=test_design, implementation_planning=implementation_planning)
    changed_surface = _collect_security_changed_seams_and_files(
        story=story,
        test_design=test_design,
        implementation_planning=implementation_planning,
        refactor_report=refactor_report,
    )
    verification_commands = _collect_security_verification_commands(
        repo_root=repo_root,
        story=story,
        test_design=test_design,
        reconciled_verification=reconciled_verification,
    )
    security_objective = str(
        implementation_planning.get("security_objective")
        or test_design.get("security_objective")
        or story.get("security_objective")
        or contract.get("security_objective")
        or "Review the changed seam for concrete security issues, fix any real problems inline, and verify honestly."
    ).strip()
    checklist = [
        "Authn/authz enforcement on the changed seam",
        "Input validation, injection, and unsafe deserialization risks",
        "Secrets handling and sensitive-data exposure",
        "Unsafe file, network, subprocess, or shell behavior",
    ]
    success_criteria = _collect_security_success_criteria(
        verification_commands=verification_commands,
        story=story,
        test_design=test_design,
        implementation_planning=implementation_planning,
    )
    guardrails = _collect_security_guardrails(
        story=story,
        test_design=test_design,
        implementation_planning=implementation_planning,
    )
    payload = {
        "story": {
            "story_id": contract.get("story_id") or story.get("story_id"),
            "story_uuid": contract.get("story_uuid") or story.get("story_uuid"),
            "title": contract.get("title") or story.get("title"),
            "summary": story_summary,
        },
        "changed_surface": changed_surface,
        "verification_commands": verification_commands,
        "security_objective": security_objective,
        "security_checklist": checklist,
        "success_criteria": success_criteria,
        "guardrails": guardrails,
        "refactor_status": str(refactor_report.get("status") or "").strip(),
    }
    payload = _compact_streaming_payload(payload, repo_root=repo_root)
    brief_lines = [
        "You are the implementation Security node for DevFlow Engine.",
        "Goal: review the changed implementation for real security issues, repair them inline, and verify honestly.",
        "Security brief:",
        f"- Story: {contract.get('story_id') or story.get('story_id') or 'unknown'} — {contract.get('title') or story.get('title') or 'Untitled story'}",
    ]
    if story_summary:
        brief_lines.append(f"- Story summary: {story_summary}")
    _append_green_prompt_section(brief_lines, "Changed seam / files", changed_surface)
    _append_green_prompt_section(brief_lines, "Verify with", verification_commands)
    brief_lines.append(f"- Security objective: {security_objective}")
    _append_green_prompt_section(brief_lines, "Security checklist", checklist)
    _append_green_prompt_section(brief_lines, "Success criteria", success_criteria)
    _append_green_prompt_section(brief_lines, "Guardrails / do not change", guardrails)
    brief_lines.extend(
        [
            "Hard rules:",
            "- Respect contract-first TDD: story, test design, and implementation planning remain binding.",
            "- Fix only real security issues in the changed seam; keep edits minimal and repo-local.",
            "- Verification honesty is mandatory: do not claim closure you did not earn.",
            "- If a required verification command cannot be run, report that blocker honestly.",
            "- Do not treat py_compile, source inspection, or reading code as equivalent to running the required verification command(s).",
            "- Do not emit markdown; just do the work in the repo.",
            "Compact context JSON:",
            json.dumps(payload, indent=2, sort_keys=True),
        ]
    )
    return "\n".join(brief_lines)


def _run_security_agent(*, repo_root: Path, prompt: str, strength: str | None = None) -> dict[str, Any]:
    return _run_streaming_cli_attempt(repo_root=repo_root, prompt=prompt, timeout_seconds=_security_timeout_seconds(), strength=strength)


def _run_security_loop(*, repo_root: Path, story: dict[str, Any], test_design: dict[str, Any], implementation_planning: dict[str, Any], refactor_report: dict[str, Any], reconciled_verification: dict[str, Any] | None = None) -> tuple[dict[str, Any], bool]:
    history: list[dict[str, Any]] = []
    max_iterations = 3
    for iteration in range(1, max_iterations + 1):
        prompt = _build_security_agent_prompt(
            repo_root=repo_root,
            story=story,
            test_design=test_design,
            implementation_planning=implementation_planning,
            refactor_report=refactor_report,
            prior_attempts=history,
            reconciled_verification=reconciled_verification,
        )
        agent_attempt = _run_security_agent(repo_root=repo_root, prompt=prompt, strength=("strong" if iteration > 1 else None))
        history.append({"iteration": iteration, "agent": agent_attempt})
        if agent_attempt.get("ok"):
            report = {
                "mode": "model_backed",
                "max_iterations": max_iterations,
                "iterations_used": len(history),
                "history": history,
                "status": "passed",
                "security_applied": True,
            }
            return report, True

    report = {
        "mode": "model_backed",
        "max_iterations": max_iterations,
        "iterations_used": len(history),
        "history": history,
        "status": "no_op",
        "security_applied": False,
    }
    return report, True


def _run_refactor_loop(*, repo_root: Path, story: dict[str, Any], test_design: dict[str, Any], implementation_planning: dict[str, Any], reconciled_verification: dict[str, Any] | None = None) -> tuple[dict[str, Any], bool]:
    history: list[dict[str, Any]] = []
    max_iterations = _refactor_max_iterations()
    for iteration in range(1, max_iterations + 1):
        prompt = _build_refactor_agent_prompt(
            repo_root=repo_root,
            story=story,
            test_design=test_design,
            implementation_planning=implementation_planning,
            prior_attempts=history,
            reconciled_verification=reconciled_verification,
        )
        agent_attempt = _run_refactor_agent(repo_root=repo_root, prompt=prompt, strength=("strong" if iteration > 1 else None))
        history.append({"iteration": iteration, "agent": agent_attempt})
        if agent_attempt.get("ok"):
            report = {
                "mode": "model_backed",
                "max_iterations": max_iterations,
                "iterations_used": len(history),
                "history": history,
                "status": "passed",
                "refactor_applied": True,
            }
            return report, True

    report = {
        "mode": "model_backed",
        "max_iterations": max_iterations,
        "iterations_used": len(history),
        "history": history,
        "status": "no_op",
        "refactor_applied": False,
    }
    return report, True


def _run_redreview_sufficiency_loop(
    *,
    repo_root: Path,
    engine_root: Path,
    pipeline_root: Path,
    run_id: str,
    story: dict[str, Any],
    story_id: str,
    test_design: dict[str, Any],
    implementation_planning: dict[str, Any],
    initial_red_generation: dict[str, Any],
) -> tuple[dict[str, Any], dict[str, Any], Path, Path | None]:
    story_ctx = _story_context(story)
    report_path = _red_sufficiency_report_path(repo_root=repo_root, run_id=run_id, story_id=story_id)
    history: list[dict[str, Any]] = []
    assessment: dict[str, Any] = {
        "outcome": "insufficient_story_tests",
        "passed": False,
        "stop_workflow": True,
        "message": "story-scoped test sufficiency failed; strengthen tests before proceeding",
    }
    final_validator_report: dict[str, Any] = {}
    test_runtime_contract = _resolve_story_test_runtime_contract(
        repo_root=repo_root,
        story=story,
        test_paths=[str(path) for path in (initial_red_generation.get("written_paths") or []) if str(path).strip()],
    )
    runtime_contract_path: Path | None = None
    run_cmd = list(test_runtime_contract.get("run_cmd") or [sys.executable or "python3", "-m", "pytest"])
    final_tv = subprocess.CompletedProcess(args=["validator"], returncode=2, stdout="", stderr="")
    final_pytest = subprocess.CompletedProcess(args=run_cmd, returncode=1, stdout="", stderr="")
    final_agent_run_path: Path | None = None
    red_generation = dict(initial_red_generation)

    for pass_index in range(1, 4):
        validator_report_path = report_path.parent / f"validator_pass_{pass_index:03d}.json"
        validator_report_path.parent.mkdir(parents=True, exist_ok=True)
        review_context = _build_redreview_context(
            repo_root=repo_root,
            story=story,
            red_generation=red_generation,
            test_design=test_design,
            implementation_planning=implementation_planning,
            prior_passes=history,
        )
        review, agent_run_path = _run_redreview_agent(
            repo_root=repo_root,
            pipeline_root=pipeline_root,
            redreview_context=review_context,
        )
        final_agent_run_path = agent_run_path
        registered_files = _register_redreview_files(
            repo_root=repo_root,
            runtime_contract=test_runtime_contract,
            story=story,
            review=review,
        )
        registered_paths = [str(item["path"]) for item in registered_files]
        validator_report: dict[str, Any] = {}
        try:
            test_runtime_contract, runtime_contract_path, command_probe, command_attempts = _establish_verified_story_test_runtime_contract(
                repo_root=repo_root,
                story=story,
                test_paths=registered_paths,
                source="red_route",
            )
            tv = _run_story_test_validator(
                engine_root=engine_root,
                repo_root=repo_root,
                story_id=story_id,
                report_path=validator_report_path,
                test_paths=registered_paths,
            )
            run_cmd = list(test_runtime_contract.get("run_cmd") or run_cmd)
            p = command_probe
            validator_report = _load_json_report(validator_report_path)
            assessment = _assess_red_candidate_outcome(validator_cp=tv, test_cp=p)
            verification_payload, verification_file = record_story_verification(
                repo_root=repo_root,
                story_id=story_id,
                story_uuid=str(story_ctx.get("story_uuid") or "").strip() or None,
                source="redreview",
                test_paths=registered_paths,
                validator={
                    "ok": tv.returncode == 0,
                    "returncode": tv.returncode,
                    "stdout": tv.stdout,
                    "stderr": tv.stderr,
                    "report_path": str(validator_report_path),
                    "report": validator_report,
                },
                tests={
                    "ok": p.returncode == 0,
                    "returncode": p.returncode,
                    "stdout": p.stdout,
                    "stderr": p.stderr,
                },
            )
            history.append(
                {
                    "pass_index": pass_index,
                    "agent_run_ref": str(agent_run_path),
                    "generation_summary": red_generation.get("summary"),
                    "generation_notes": list(red_generation.get("notes") or []),
                    "written_paths": list(red_generation.get("written_paths") or []),
                    "redreview_summary": review.summary,
                    "redreview_notes": list(review.notes or []),
                    "registered_files": registered_files,
                    "validator_input_paths": registered_paths,
                    "validator_returncode": tv.returncode,
                    "validator_stdout": _truncate_output(tv.stdout, label="validator stdout"),
                    "validator_stderr": _truncate_output(tv.stderr, label="validator stderr"),
                    "validator_report_path": str(validator_report_path),
                    "validator_report": validator_report,
                    "pytest_returncode": p.returncode,
                    "pytest_stdout": _truncate_output(p.stdout, label="pytest stdout"),
                    "pytest_stderr": _truncate_output(p.stderr, label="pytest stderr"),
                    "assessment": assessment,
                    "test_runtime_contract": test_runtime_contract,
                    "runtime_contract_path": None if runtime_contract_path is None else str(runtime_contract_path),
                    "verified_command_probe": {
                        "args": _completed_process_argv(command_probe.args),
                        "returncode": int(command_probe.returncode),
                    },
                    "command_verification_attempts": command_attempts,
                    "story_verification": verification_payload,
                    "story_verification_path": str(verification_file),
                }
            )
            final_validator_report = validator_report
            final_tv = tv
            final_pytest = p
        except Exception as exc:
            assessment = _runtime_command_repair_assessment(message=str(exc))
            final_tv = subprocess.CompletedProcess(args=["validator"], returncode=2, stdout="", stderr=str(exc))
            final_pytest = subprocess.CompletedProcess(args=run_cmd, returncode=2, stdout="", stderr=str(exc))
            history.append(
                {
                    "pass_index": pass_index,
                    "agent_run_ref": str(agent_run_path),
                    "generation_summary": red_generation.get("summary"),
                    "generation_notes": list(red_generation.get("notes") or []),
                    "written_paths": list(red_generation.get("written_paths") or []),
                    "redreview_summary": review.summary,
                    "redreview_notes": list(review.notes or []),
                    "registered_files": registered_files,
                    "validator_input_paths": registered_paths,
                    "assessment": assessment,
                    "test_runtime_contract": dict(test_runtime_contract or {}),
                    "runtime_contract_path": None if runtime_contract_path is None else str(runtime_contract_path),
                    "command_verification_attempts": [],
                    "runtime_command_error": str(exc),
                }
            )
        repair_required = _is_redreview_local_quality_outcome(assessment)
        if assessment["outcome"] in {"real_green", "real_red"} or pass_index >= 3 or not repair_required:
            break
        repair_context = _build_redreview_repair_context(
            repo_root=repo_root,
            story=story,
            red_generation=red_generation,
            test_design=test_design,
            implementation_planning=implementation_planning,
            prior_passes=history,
            review=review,
            assessment=assessment,
            validator_report=validator_report,
            validator_returncode=final_tv.returncode,
            validator_stdout=final_tv.stdout,
            validator_stderr=final_tv.stderr,
            pytest_returncode=final_pytest.returncode,
            pytest_stdout=final_pytest.stdout,
            pytest_stderr=final_pytest.stderr,
            runtime_contract=test_runtime_contract,
        )
        generated_tests, repair_agent_run_path = _run_redreview_repair_agent(
            repo_root=repo_root,
            pipeline_root=pipeline_root,
            repair_context=repair_context,
            node_ref=f"redreview.repair_{pass_index + 1}",
        )
        written_paths = _apply_red_test_generation(repo_root=repo_root, artifact=generated_tests)
        red_generation = {
            "summary": generated_tests.summary,
            "notes": list(generated_tests.notes or []),
            "written_paths": written_paths,
            "repair_agent_run_ref": str(repair_agent_run_path),
            "repair_source": "redreview_internal_loop",
        }
        history[-1]["repair"] = {
            "agent_run_ref": str(repair_agent_run_path),
            "summary": generated_tests.summary,
            "notes": list(generated_tests.notes or []),
            "written_paths": written_paths,
            "source": "redreview_internal_loop",
        }

    report = {
        "story_id": story_id,
        "mode": "model_backed",
        "agent_run_ref": None if final_agent_run_path is None else str(final_agent_run_path),
        "passed": bool(assessment.get("passed")),
        "pass_count": len(history),
        "history": history,
        "final_validator_input_paths": list(history[-1].get("validator_input_paths") or []) if history else [],
        "final_validator_report": final_validator_report,
        "final_assessment": assessment,
        "runtime_contract_path": None if runtime_contract_path is None else str(runtime_contract_path),
    }
    _write_json(report_path, report)
    return report, {"validator": final_tv, "pytest": final_pytest}, report_path, final_agent_run_path


def _assess_red_outcome(*, test_validation_returncode: int, pytest_returncode: int) -> dict[str, Any]:
    if test_validation_returncode != 0 and pytest_returncode == 0:
        return {
            "outcome": "greenwashed_green",
            "passed": False,
            "stop_workflow": True,
            "message": "greenwashed green: tests passed, but story-scoped test sufficiency failed; strengthen tests",
        }
    if test_validation_returncode != 0:
        return {
            "outcome": "insufficient_story_tests",
            "passed": False,
            "stop_workflow": True,
            "message": "story-scoped test sufficiency failed; strengthen tests before proceeding",
        }
    if pytest_returncode == 0:
        return {
            "outcome": "real_green",
            "passed": True,
            "stop_workflow": True,
            "message": "real green: story-scoped tests are sufficient and already pass",
        }
    return {
        "outcome": "real_red",
        "passed": True,
        "stop_workflow": False,
        "message": "real red: story-scoped tests are sufficient and expose incomplete implementation",
    }


def _assess_red_candidate_outcome(
    *,
    validator_cp: subprocess.CompletedProcess[str],
    test_cp: subprocess.CompletedProcess[str],
) -> dict[str, Any]:
    if validator_cp.returncode != 0 and test_cp.returncode == 0:
        return _assess_red_outcome(
            test_validation_returncode=validator_cp.returncode,
            pytest_returncode=test_cp.returncode,
        )
    runtime_issue = _classify_invalid_red_runtime(
        stdout=str(test_cp.stdout or ""),
        stderr=str(test_cp.stderr or ""),
        returncode=int(test_cp.returncode),
    )
    if runtime_issue is not None:
        return {
            "outcome": "invalid_red_artifact",
            "passed": False,
            "stop_workflow": True,
            "message": f"story-scoped test runtime validation failed before clean red completion ({runtime_issue})",
        }
    return _assess_red_outcome(
        test_validation_returncode=validator_cp.returncode,
        pytest_returncode=test_cp.returncode,
    )


def _run_red_sufficiency_loop(
    *,
    repo_root: Path,
    engine_root: Path,
    pipeline_root: Path,
    run_id: str,
    story: dict[str, Any],
    story_id: str,
    test_design: dict[str, Any],
    implementation_planning: dict[str, Any],
    max_passes: int = 3,
) -> tuple[dict[str, Any], dict[str, Any], Path, Path | None, dict[str, Any]]:
    report_path = _red_sufficiency_report_path(repo_root=repo_root, run_id=run_id, story_id=story_id)
    history: list[dict[str, Any]] = []
    assessment: dict[str, Any] = {
        "outcome": "insufficient_story_tests",
        "passed": False,
        "stop_workflow": True,
        "message": "story-scoped test sufficiency failed; strengthen tests before proceeding",
    }
    final_validator_report: dict[str, Any] = {}
    final_tv = subprocess.CompletedProcess(args=["validator"], returncode=2, stdout="", stderr="")
    final_pytest = subprocess.CompletedProcess(args=["pytest"], returncode=1, stdout="", stderr="")
    final_agent_run_path: Path | None = None
    final_runtime_contract: dict[str, Any] = {}
    runtime_contract_path: Path | None = None
    latest_red_generation: dict[str, Any] = {"summary": "", "notes": [], "written_paths": []}

    for pass_index in range(1, max_passes + 1):
        validator_report_path = report_path.parent / f"validator_pass_{pass_index:03d}.json"
        validator_report_path.parent.mkdir(parents=True, exist_ok=True)
        red_generation_context = _build_red_generation_context(
            repo_root=repo_root,
            story=story,
            test_design=test_design,
            implementation_planning=implementation_planning,
            prior_passes=history,
        )
        generated_tests, agent_run_path = _run_red_agent(
            repo_root=repo_root,
            pipeline_root=pipeline_root,
            red_generation_context=red_generation_context,
            node_ref="red" if pass_index == 1 else f"red.repair_{pass_index}",
        )
        final_agent_run_path = agent_run_path
        try:
            written_paths = _apply_red_test_generation(repo_root=repo_root, artifact=generated_tests)
            runtime_contract, runtime_contract_path, command_probe, command_attempts = _establish_verified_story_test_runtime_contract(
                repo_root=repo_root,
                story=story,
                test_paths=written_paths,
                source="red_route",
            )
            tv = _run_story_test_validator(
                engine_root=engine_root,
                repo_root=repo_root,
                story_id=story_id,
                report_path=validator_report_path,
                test_paths=written_paths,
            )
            p = command_probe
            validator_report = _load_json_report(validator_report_path)
            assessment = _assess_red_candidate_outcome(validator_cp=tv, test_cp=p)
            latest_red_generation = {
                "summary": generated_tests.summary,
                "notes": list(generated_tests.notes or []),
                "written_paths": written_paths,
            }
            history.append(
                {
                    "pass_index": pass_index,
                    "agent_run_ref": str(agent_run_path),
                    "generation_summary": generated_tests.summary,
                    "generation_notes": list(generated_tests.notes or []),
                    "written_paths": written_paths,
                    "validator_input_paths": written_paths,
                    "validator_returncode": tv.returncode,
                    "validator_stdout": _truncate_output(tv.stdout, label="validator stdout"),
                    "validator_stderr": _truncate_output(tv.stderr, label="validator stderr"),
                    "validator_report_path": str(validator_report_path),
                    "validator_report": validator_report,
                    "pytest_returncode": p.returncode,
                    "pytest_stdout": _truncate_output(p.stdout, label="pytest stdout"),
                    "pytest_stderr": _truncate_output(p.stderr, label="pytest stderr"),
                    "assessment": assessment,
                    "test_runtime_contract": runtime_contract,
                    "runtime_contract_path": None if runtime_contract_path is None else str(runtime_contract_path),
                    "verified_command_probe": {
                        "args": _completed_process_argv(command_probe.args),
                        "returncode": int(command_probe.returncode),
                    },
                    "command_verification_attempts": command_attempts,
                }
            )
            final_validator_report = validator_report
            final_tv = tv
            final_pytest = p
            final_runtime_contract = runtime_contract
            if assessment["outcome"] in {"real_green", "real_red"}:
                break
        except Exception as exc:
            assessment = {
                "outcome": "invalid_red_artifact",
                "passed": False,
                "stop_workflow": True,
                "message": str(exc),
            }
            history.append(
                {
                    "pass_index": pass_index,
                    "agent_run_ref": str(agent_run_path),
                    "generation_summary": generated_tests.summary,
                    "generation_notes": list(generated_tests.notes or []),
                    "written_paths": [],
                    "apply_error": str(exc),
                    "assessment": assessment,
                }
            )
        if pass_index >= max_passes:
            break

    report = {
        "story_id": story_id,
        "mode": "model_backed",
        "agent_run_ref": None if final_agent_run_path is None else str(final_agent_run_path),
        "passed": bool(assessment.get("passed")),
        "pass_count": len(history),
        "history": history,
        "final_validator_input_paths": list(history[-1].get("validator_input_paths") or []) if history else [],
        "final_validator_report": final_validator_report,
        "final_assessment": assessment,
        "runtime_contract": final_runtime_contract,
        "runtime_contract_path": None if runtime_contract_path is None else str(runtime_contract_path),
    }
    _write_json(report_path, report)
    return report, {"validator": final_tv, "pytest": final_pytest}, report_path, final_agent_run_path, latest_red_generation


class RedNode(AgentNode):
    def get_agent_config(self) -> AgentConfig:
        return AgentConfig(
            instructions=(
                "Red node writes/mutates candidate tests first. It is a real model-backed node and does not perform deterministic plane assessment or story-scoped validation."
            )
        )

    async def process(self, task_context: TaskContext) -> TaskContext:
        repo_root = Path(task_context.event.repo_root)
        store, run_id = _store_run()
        story = dict(task_context.event.story)

        # Red-complete checkpoint: if a prior run fully completed RED (RedReview + reconciliation
        # passed), skip RED generation entirely and restore metadata for downstream nodes.
        _red_story_ctx = _story_context(story)
        _red_story_id = str(_red_story_ctx.get("story_id") or "").strip()
        if _red_story_id:
            _red_checkpoint = _load_red_complete_checkpoint(repo_root=repo_root, story_id=_red_story_id)
            if _red_checkpoint is not None:
                _dfs_node_running(repo_root=repo_root, story=story, run_id=run_id, node_id="red", summary="Red-complete checkpoint found — skipping RED generation")
                _synthetic_ckpt: dict[str, Any] = {"prior_run_id": None, "node": None, "artifacts": []}
                _mark_replayed_node(
                    store=store,
                    run_id=run_id,
                    node_id="red",
                    node_name="Red",
                    stage_state=_synthetic_ckpt,
                    output={"red_complete_checkpoint": True, "checkpoint_path": str(_red_complete_checkpoint_path(repo_root=repo_root, story_id=_red_story_id))},
                )
                task_context.metadata["red_complete_checkpoint"] = _red_checkpoint
                return task_context

        # Rip-to-green: sufficiency gate only (validator, not pytest).
        # Red tests are expected to FAIL — that is their purpose. The correct rip-to-green
        # condition is test *sufficiency* (do the tests cover the story plan?), not test
        # *passage* (do they pass?). Running pytest here would always block rip-to-green for
        # any story with a proper red test suite. Use _run_story_test_validator alone.
        _rip_story_ctx = _story_context(story)
        _rip_story_id = str(_rip_story_ctx.get("story_id") or "").strip()
        _rip_engine_root = Path(__file__).resolve().parents[3]
        _rip_runtime_contract = _resolve_story_test_runtime_contract(repo_root=repo_root, story=story, test_paths=None)
        _rip_test_paths = [str(p) for p in (_rip_runtime_contract.get("test_paths") or []) if str(p).strip()]
        if not _rip_test_paths:
            _rip_test_paths = _discover_story_scoped_test_paths(repo_root=repo_root, story=story)
        if _rip_story_id and _rip_test_paths:
            _validator_cp = _run_story_test_validator(
                engine_root=_rip_engine_root,
                repo_root=repo_root,
                story_id=_rip_story_id,
                test_paths=_rip_test_paths,
            )
            if _validator_cp.returncode == 0:
                _dfs_node_running(repo_root=repo_root, story=story, run_id=run_id, node_id="red", summary="Rip-to-green: test sufficiency gate passes, skipping red agent")
                _synthetic: dict[str, Any] = {"prior_run_id": None, "node": None, "artifacts": []}
                _mark_replayed_node(
                    store=store,
                    run_id=run_id,
                    node_id="red",
                    node_name="Red",
                    stage_state=_synthetic,
                    output={
                        "rip_to_green": True,
                        "gate_results": {"story_test_validation": {"ok": True, "returncode": 0}},
                        "story_gate": {
                            "story_id": _rip_story_id,
                            "test_paths": _rip_test_paths,
                            "validator_rc": 0,
                            "validator_stdout": _validator_cp.stdout,
                            "gate_type": "sufficiency_only",
                        },
                    },
                )
                task_context.metadata["rip_to_green"] = True
                return task_context

        _dfs_node_running(repo_root=repo_root, story=story, run_id=run_id, node_id="red", summary="Generating red tests")
        node_exec_id = store.create_node_attempt(run_id=run_id, node_id="red", node_name="Red", attempt=1)

        story_ctx = _story_context(story)
        pipeline_root = _implementation_pipeline_root(repo_root=repo_root, story_id=str(story_ctx.get("story_id") or "unknown_story"))
        test_design = task_context.metadata.get("test_design") or {}
        bundles = _test_design_bundles(repo_root=repo_root, story=story, test_design=test_design)

        if len(bundles) == 1:
            engine_root = Path(__file__).resolve().parents[3]
            sufficiency_report, final_runs, report_path, agent_run_path, red_generation = _run_red_sufficiency_loop(
                repo_root=repo_root,
                engine_root=engine_root,
                pipeline_root=pipeline_root,
                run_id=run_id,
                story=story,
                story_id=str(story_ctx.get("story_id") or ""),
                test_design=test_design,
                implementation_planning=task_context.metadata.get("implementation_planning") or {},
            )
            tv = final_runs["validator"]
            p = final_runs["pytest"]
            assessment = dict(sufficiency_report.get("final_assessment") or {})
            runtime_contract = dict(sufficiency_report.get("runtime_contract") or {})
            runtime_contract_path = sufficiency_report.get("runtime_contract_path")
            written_paths = list(red_generation.get("written_paths") or [])
            bundle_generation = {
                "bundle_id": str(bundles[0].get("bundle_id") or "default"),
                "runtime_family": str(bundles[0].get("runtime_family") or "default"),
                "planes": list(bundles[0].get("planes") or []),
                "agent_run_ref": None if agent_run_path is None else str(agent_run_path),
                "summary": str(red_generation.get("summary") or ""),
                "notes": list(red_generation.get("notes") or []),
                "written_paths": written_paths,
                "runtime_contract": runtime_contract,
                "runtime_contract_path": runtime_contract_path,
            }
            output: dict[str, Any] = {
                "mode": "model_backed",
                "agent_run_ref": None if agent_run_path is None else str(agent_run_path),
                "implementation_planning": task_context.metadata.get("implementation_planning") or {},
                "test_design": test_design,
                "test_generation": {
                    "wrote": bool(written_paths),
                    "written_paths": written_paths,
                    "summary": str(red_generation.get("summary") or ""),
                    "notes": list(red_generation.get("notes") or []),
                },
                "bundle_generations": [bundle_generation],
                "test_runtime_contract": runtime_contract,
                "test_runtime_contract_path": runtime_contract_path,
                "validator_input_paths": list(sufficiency_report.get("final_validator_input_paths") or []),
                "test_validation_returncode": tv.returncode,
                "test_validation_stdout": tv.stdout,
                "test_validation_stderr": tv.stderr,
                "pytest_returncode": p.returncode,
                "pytest_stdout": p.stdout,
                "pytest_stderr": p.stderr,
                "sufficiency": {
                    "passed": bool(sufficiency_report.get("passed")),
                    "pass_count": int(sufficiency_report.get("pass_count") or 0),
                    "history": list(sufficiency_report.get("history") or []),
                    "report_path": str(report_path),
                },
                "assessment": assessment,
            }
            task_context.metadata["red_generation"] = output["test_generation"]
            task_context.metadata["red_generation_bundles"] = [bundle_generation]
            msg_parts = [str(task_context.metadata.get("message") or "")]
            if tv.returncode != 0:
                msg_parts.append(tv.stdout)
                msg_parts.append(tv.stderr)
            if p.returncode != 0 and str(assessment.get("outcome") or "") == "invalid_red_artifact":
                msg_parts.append(p.stdout)
                msg_parts.append(p.stderr)
            msg_parts.append(f"red_story_test_sufficiency_pass: {output['sufficiency']['pass_count']}/3\n")
            msg_parts.append(f"red_story_test_sufficiency_report: {report_path}\n")
            msg_parts.append(str(assessment.get("message") or "") + "\n")
            task_context.metadata["message"] = "".join(msg_parts)
            store.add_artifact(
                run_id=run_id,
                node_exec_id=node_exec_id,
                kind="red_test_sufficiency_report",
                uri=str(report_path),
                metadata=sufficiency_report,
                content_type="application/json",
                byte_size=len(json.dumps(sufficiency_report, sort_keys=True)),
            )
            store.mark_node_finished(node_exec_id=node_exec_id, status="succeeded" if bool(assessment.get("passed")) else "failed", output=output)
            if not bool(assessment.get("passed")):
                task_context.metadata["exit_code"] = 1
            if bool(assessment.get("stop_workflow")):
                task_context.stop_workflow()
            return task_context

        bundle_generations = await asyncio.gather(
            *[
                asyncio.to_thread(
                    _run_red_bundle_generation_with_repair_loop,
                    repo_root=repo_root,
                    pipeline_root=pipeline_root,
                    story=story,
                    bundle=bundle,
                    test_design=test_design,
                    implementation_planning=task_context.metadata.get("implementation_planning") or {},
                )
                for bundle in bundles
            ]
        )
        flat_written_paths = [
            str(path)
            for bundle_generation in bundle_generations
            for path in (bundle_generation.get("written_paths") or [])
            if str(path).strip()
        ]
        failed_bundles = [dict(bundle_generation) for bundle_generation in bundle_generations if str(bundle_generation.get("status") or "") == "failed"]
        output = {
            "mode": "model_backed",
            "implementation_planning": task_context.metadata.get("implementation_planning") or {},
            "test_design": test_design,
            "bundle_generations": bundle_generations,
            "failed_bundles": failed_bundles,
            "test_generation": {
                "wrote": bool(flat_written_paths),
                "written_paths": flat_written_paths,
                "summary": f"generated runtime-specific tests for {len(bundle_generations)} bundles",
                "notes": [f"bundle:{bundle_generation.get('bundle_id')}:{bundle_generation.get('status') or 'succeeded'}" for bundle_generation in bundle_generations],
            },
        }
        task_context.metadata["red_generation"] = output["test_generation"]
        task_context.metadata["red_generation_bundles"] = bundle_generations
        if failed_bundles:
            failure_summary = "; ".join(
                f"{bundle.get('bundle_id')}: {bundle.get('error') or 'bundle generation failed'}"
                for bundle in failed_bundles
            )
            task_context.metadata["exit_code"] = 1
            task_context.metadata["message"] = str(task_context.metadata.get("message") or "") + f"red bundle generation failed: {failure_summary}\n"
            store.mark_node_finished(node_exec_id=node_exec_id, status="failed", output=output)
            task_context.stop_workflow()
            return task_context
        store.mark_node_finished(node_exec_id=node_exec_id, status="succeeded", output=output)
        return task_context


class RedReviewNode(AgentNode):
    def get_agent_config(self) -> AgentConfig:
        return AgentConfig(
            instructions=(
                "RedReview is a real GenAI node: inspect actual test file contents from Red, classify covered planes using the allowable plane vocabulary, then hand registered files to deterministic marker writing and validation."
            )
        )

    async def process(self, task_context: TaskContext) -> TaskContext:
        repo_root = Path(task_context.event.repo_root)
        store, run_id = _store_run()

        # Red-complete checkpoint propagation: if RedNode skipped via checkpoint,
        # restore the saved redreview metadata so downstream nodes (StorySufficiencyReconciliation,
        # GreenNode) receive the correct registered files and bundle reports.
        _ckpt = task_context.metadata.get("red_complete_checkpoint")
        if _ckpt is not None:
            _ckpt_story = dict(task_context.event.story)
            _ckpt = _repair_red_complete_checkpoint_bundle_artifacts(
                repo_root=repo_root,
                story=_ckpt_story,
                test_design=task_context.metadata.get("test_design") or {},
                checkpoint=dict(_ckpt),
            )
            task_context.metadata["red_complete_checkpoint"] = _ckpt
            _dfs_node_running(repo_root=repo_root, story=_ckpt_story, run_id=run_id, node_id="redreview", summary="Red-complete checkpoint — restoring RedReview metadata")
            _ckpt_synthetic: dict[str, Any] = {"prior_run_id": None, "node": None, "artifacts": []}
            _mark_replayed_node(
                store=store,
                run_id=run_id,
                node_id="redreview",
                node_name="RedReview",
                stage_state=_ckpt_synthetic,
                output={"red_complete_checkpoint": True},
            )
            task_context.metadata["bundle_redreview_reports"] = _ckpt.get("bundle_redreview_reports") or []
            task_context.metadata["redreview_registered_files"] = _ckpt.get("redreview_registered_files") or []
            task_context.metadata["redreview_report"] = _ckpt.get("redreview_report") or {"replayed": True, "passed": True, "red_complete_checkpoint": True}
            return task_context

        # Rip-to-green propagation
        if task_context.metadata.get("rip_to_green"):
            story = dict(task_context.event.story)
            test_design = task_context.metadata.get("test_design") or {}
            bundles = _test_design_bundles(repo_root=repo_root, story=story, test_design=test_design)
            bundle_reports: list[dict[str, Any]] = []
            latest_registered_files: list[dict[str, Any]] = []
            if len(bundles) == 1:
                bundle = _preserve_rip_to_green_bundle_identity(
                    repo_root=repo_root,
                    story=story,
                    test_design=test_design,
                    bundle=dict(bundles[0]),
                )
                bundle_id = str(bundle.get("bundle_id") or "default")
                bundle_test_paths = _resolve_rip_to_green_bundle_test_paths(
                    repo_root=repo_root,
                    story=story,
                    bundle=bundle,
                )
                runtime_contract, runtime_contract_path, _command_probe, _command_attempts = _establish_verified_bundle_test_runtime_contract(
                    repo_root=repo_root,
                    story=story,
                    bundle=bundle,
                    test_paths=bundle_test_paths,
                    source=f"rip_to_green:{bundle_id}",
                )
                latest_registered_files = [
                    {
                        "path": path,
                        "covered_planes": list(bundle.get("planes") or []),
                        "register_for_validation": True,
                        "rationale": "rip-to-green retained existing story-scoped tests for downstream reconciliation",
                    }
                    for path in bundle_test_paths
                ]
                assessment = {
                    "outcome": "real_green",
                    "passed": True,
                    "stop_workflow": False,
                    "message": "rip-to-green reused existing story-scoped tests for downstream verification",
                }
                bundle_reports = [
                    {
                        "bundle_id": bundle_id,
                        "runtime_family": str(bundle.get("runtime_family") or "default"),
                        "planes": list(bundle.get("planes") or []),
                        "registered_files": latest_registered_files,
                        "validator_input_paths": bundle_test_paths,
                        "assessment": assessment,
                        "pass_count": 1,
                        "history": [
                            {
                                "rip_to_green": True,
                                "registered_files": latest_registered_files,
                                "validator_input_paths": bundle_test_paths,
                                "assessment": assessment,
                                "test_runtime_contract": runtime_contract,
                                "runtime_contract_path": None if runtime_contract_path is None else str(runtime_contract_path),
                            }
                        ],
                        "runtime_contract": runtime_contract,
                        "runtime_contract_path": None if runtime_contract_path is None else str(runtime_contract_path),
                        "red_generation": {},
                    }
                ]
            else:
                for raw_bundle in bundles:
                    bundle = _preserve_rip_to_green_bundle_identity(
                        repo_root=repo_root,
                        story=story,
                        test_design=test_design,
                        bundle=dict(raw_bundle),
                    )
                    bundle_id = str(bundle.get("bundle_id") or "default")
                    bundle_test_paths = _resolve_rip_to_green_bundle_test_paths(
                        repo_root=repo_root,
                        story=story,
                        bundle=bundle,
                    )
                    runtime_contract, runtime_contract_path, _command_probe, _command_attempts = _establish_verified_bundle_test_runtime_contract(
                        repo_root=repo_root,
                        story=story,
                        bundle=bundle,
                        test_paths=bundle_test_paths,
                        source=f"rip_to_green:{bundle_id}",
                    )
                    verified_test_paths = [
                        str(path)
                        for path in (runtime_contract.get("test_paths") or bundle_test_paths)
                        if str(path).strip()
                    ]
                    registered_files = [
                        {
                            "path": path,
                            "covered_planes": list(bundle.get("planes") or []),
                            "register_for_validation": True,
                            "rationale": "rip-to-green retained existing bundle-scoped tests for downstream reconciliation",
                        }
                        for path in verified_test_paths
                    ]
                    latest_registered_files.extend(registered_files)
                    assessment = {
                        "outcome": "real_green",
                        "passed": True,
                        "stop_workflow": False,
                        "message": "rip-to-green reused existing bundle-scoped tests for downstream verification",
                    }
                    bundle_reports.append(
                        {
                            "bundle_id": bundle_id,
                            "runtime_family": str(bundle.get("runtime_family") or "default"),
                            "planes": list(bundle.get("planes") or []),
                            "registered_files": registered_files,
                            "validator_input_paths": verified_test_paths,
                            "assessment": assessment,
                            "pass_count": 1,
                            "history": [
                                {
                                    "rip_to_green": True,
                                    "registered_files": registered_files,
                                    "validator_input_paths": verified_test_paths,
                                    "assessment": assessment,
                                    "test_runtime_contract": runtime_contract,
                                    "runtime_contract_path": None if runtime_contract_path is None else str(runtime_contract_path),
                                }
                            ],
                            "runtime_contract": runtime_contract,
                            "runtime_contract_path": None if runtime_contract_path is None else str(runtime_contract_path),
                            "red_generation": {},
                        }
                    )
            _dfs_node_running(repo_root=repo_root, story=dict(task_context.event.story), run_id=run_id, node_id="redreview", summary="Rip-to-green: skipping redreview")
            _synthetic: dict[str, Any] = {"prior_run_id": None, "node": None, "artifacts": []}
            _mark_replayed_node(
                store=store,
                run_id=run_id,
                node_id="redreview",
                node_name="RedReview",
                stage_state=_synthetic,
                output={
                    "rip_to_green": True,
                    "bundle_reports": bundle_reports,
                    "registered_files": latest_registered_files,
                },
            )
            task_context.metadata["redreview_registered_files"] = latest_registered_files
            task_context.metadata["redreview_report"] = {"replayed": True, "passed": True, "rip_to_green": True, "bundle_reports": bundle_reports}
            task_context.metadata["bundle_redreview_reports"] = bundle_reports
            return task_context

        _dfs_node_running(repo_root=repo_root, story=dict(task_context.event.story), run_id=run_id, node_id="redreview", summary="Reviewing red tests")
        engine_root = Path(__file__).resolve().parents[3]
        node_exec_id = store.create_node_attempt(run_id=run_id, node_id="redreview", node_name="RedReview", attempt=1)

        story = dict(task_context.event.story)
        contract = story.get("contract") or {}
        story_id = str(contract.get("story_id") or story.get("story_id") or "").strip()
        story_ctx = _story_context(story)
        pipeline_root = _implementation_pipeline_root(repo_root=repo_root, story_id=str(story_ctx.get("story_id") or "unknown_story"))
        test_design = task_context.metadata.get("test_design") or {}
        implementation_planning = task_context.metadata.get("implementation_planning") or {}
        bundles = _test_design_bundles(repo_root=repo_root, story=story, test_design=test_design)

        if len(bundles) == 1:
            sufficiency_report, final_runs, report_path, agent_run_path = _run_redreview_sufficiency_loop(
                repo_root=repo_root,
                engine_root=engine_root,
                pipeline_root=pipeline_root,
                run_id=run_id,
                story=story,
                story_id=story_id,
                test_design=test_design,
                implementation_planning=implementation_planning,
                initial_red_generation=task_context.metadata.get("red_generation") or {},
            )
            tv = final_runs["validator"]
            p = final_runs["pytest"]
            history = list(sufficiency_report.get("history") or [])
            assessment = dict(sufficiency_report.get("final_assessment") or _assess_red_outcome(test_validation_returncode=tv.returncode, pytest_returncode=p.returncode))
            latest_registered_files = list(history[-1].get("registered_files") or []) if history else []
            bundle_reports = [
                {
                    "bundle_id": str(bundles[0].get("bundle_id") or "default"),
                    "runtime_family": str(bundles[0].get("runtime_family") or "default"),
                    "planes": list(bundles[0].get("planes") or []),
                    "registered_files": latest_registered_files,
                    "validator_input_paths": [str(item.get("path")) for item in latest_registered_files],
                    "assessment": assessment,
                    "pass_count": int(sufficiency_report.get("pass_count") or 0),
                    "history": history,
                    "runtime_contract": task_context.metadata.get("red_generation_bundles", [{}])[0].get("runtime_contract") if task_context.metadata.get("red_generation_bundles") else {},
                    "runtime_contract_path": task_context.metadata.get("red_generation_bundles", [{}])[0].get("runtime_contract_path") if task_context.metadata.get("red_generation_bundles") else None,
                    "red_generation": task_context.metadata.get("red_generation_bundles", [{}])[0] if task_context.metadata.get("red_generation_bundles") else {},
                }
            ]
            output: dict[str, Any] = {
                "mode": "model_backed",
                "agent_run_ref": None if agent_run_path is None else str(agent_run_path),
                "bundle_reports": bundle_reports,
                "registered_files": latest_registered_files,
                "validator_input_paths": [str(item.get("path")) for item in latest_registered_files],
                "test_validation_returncode": tv.returncode,
                "test_validation_stdout": tv.stdout,
                "test_validation_stderr": tv.stderr,
                "pytest_returncode": p.returncode,
                "pytest_stdout": p.stdout,
                "pytest_stderr": p.stderr,
                "sufficiency": {
                    "passed": bool(sufficiency_report.get("passed")),
                    "pass_count": int(sufficiency_report.get("pass_count") or 0),
                    "history": history,
                    "report_path": str(report_path),
                },
                "assessment": assessment,
            }
            task_context.metadata["redreview_registered_files"] = latest_registered_files
            task_context.metadata["redreview_report"] = sufficiency_report
            task_context.metadata["bundle_redreview_reports"] = bundle_reports
            msg_parts = [str(task_context.metadata.get("message") or "")]
            if tv.returncode != 0:
                msg_parts.append(tv.stdout)
                msg_parts.append(tv.stderr)
            msg_parts.append(f"redreview_story_test_sufficiency_pass: {output['sufficiency']['pass_count']}/3\n")
            msg_parts.append(f"redreview_story_test_sufficiency_report: {report_path}\n")
            msg_parts.append(str(assessment["message"]) + "\n")
            task_context.metadata["message"] = "".join(msg_parts)
            store.add_artifact(
                run_id=run_id,
                node_exec_id=node_exec_id,
                kind="redreview_test_sufficiency_report",
                uri=str(report_path),
                metadata=sufficiency_report,
                content_type="application/json",
                byte_size=len(json.dumps(sufficiency_report, sort_keys=True)),
            )
            store.mark_node_finished(node_exec_id=node_exec_id, status="succeeded" if bool(assessment["passed"]) else "failed", output=output)
            if not bool(assessment["passed"]):
                task_context.metadata["exit_code"] = 1
            if bool(assessment["stop_workflow"]):
                task_context.stop_workflow()
            return task_context

        red_generation_by_bundle = {
            str(item.get("bundle_id") or "default"): dict(item)
            for item in (task_context.metadata.get("red_generation_bundles") or [])
            if isinstance(item, dict)
        }
        bundle_reports = await asyncio.gather(
            *[
                asyncio.to_thread(
                    _run_redreview_bundle_sufficiency_loop,
                    repo_root=repo_root,
                    engine_root=engine_root,
                    pipeline_root=pipeline_root,
                    run_id=run_id,
                    story=story,
                    story_id=story_id,
                    bundle=bundle,
                    test_design=test_design,
                    implementation_planning=implementation_planning,
                    initial_red_generation=red_generation_by_bundle.get(str(bundle.get("bundle_id") or "default"), {"bundle_id": str(bundle.get("bundle_id") or "default"), "written_paths": [], "summary": "", "notes": []}),
                )
                for bundle in bundles
            ]
        )
        assessment = _summarize_bundle_assessment(bundle_reports)
        latest_registered_files = [
            dict(item)
            for report in bundle_reports
            for item in (report.get("registered_files") or [])
            if isinstance(item, dict)
        ]
        report_path = _red_sufficiency_report_path(repo_root=repo_root, run_id=run_id, story_id=story_id)
        sufficiency_report = {
            "story_id": story_id,
            "mode": "model_backed",
            "passed": bool(assessment.get("passed")),
            "pass_count": max((int(report.get("pass_count") or 0) for report in bundle_reports), default=0),
            "bundle_reports": bundle_reports,
            "final_assessment": assessment,
        }
        _write_json(report_path, sufficiency_report)
        output = {
            "mode": "model_backed",
            "bundle_reports": bundle_reports,
            "registered_files": latest_registered_files,
            "validator_input_paths": [str(item.get("path")) for item in latest_registered_files],
            "sufficiency": {
                "passed": bool(assessment.get("passed")),
                "pass_count": max((int(report.get("pass_count") or 0) for report in bundle_reports), default=0),
                "bundle_pass_counts": {str(report.get("bundle_id") or "default"): int(report.get("pass_count") or 0) for report in bundle_reports},
                "history": [{"bundle_id": str(report.get("bundle_id") or "default"), "history": list(report.get("history") or [])} for report in bundle_reports],
                "report_path": str(report_path),
            },
            "assessment": assessment,
        }
        task_context.metadata["redreview_registered_files"] = latest_registered_files
        task_context.metadata["redreview_report"] = sufficiency_report
        task_context.metadata["bundle_redreview_reports"] = bundle_reports
        task_context.metadata["message"] = str(task_context.metadata.get("message") or "") + f"redreview_story_test_sufficiency_report: {report_path}\n" + str(assessment.get("message") or "") + "\n"
        store.add_artifact(
            run_id=run_id,
            node_exec_id=node_exec_id,
            kind="redreview_test_sufficiency_report",
            uri=str(report_path),
            metadata=sufficiency_report,
            content_type="application/json",
            byte_size=len(json.dumps(sufficiency_report, sort_keys=True)),
        )
        store.mark_node_finished(node_exec_id=node_exec_id, status="succeeded" if bool(assessment.get("passed")) else "failed", output=output)
        if not bool(assessment.get("passed")):
            task_context.metadata["exit_code"] = 1
        if bool(assessment.get("stop_workflow")):
            task_context.stop_workflow()
        return task_context


class StorySufficiencyReconciliationNode(Node):
    async def process(self, task_context: TaskContext) -> TaskContext:
        repo_root = Path(task_context.event.repo_root)
        store, run_id = _store_run()
        story = dict(task_context.event.story)

        # Red-complete checkpoint: if a full checkpoint with story_verification_reconciliation
        # is present, skip re-running reconciliation and restore metadata from the checkpoint.
        _recon_ckpt = task_context.metadata.get("red_complete_checkpoint")
        if _recon_ckpt is not None:
            _recon_ckpt = _repair_red_complete_checkpoint_bundle_artifacts(
                repo_root=repo_root,
                story=story,
                test_design=task_context.metadata.get("test_design") or {},
                checkpoint=dict(_recon_ckpt),
            )
            task_context.metadata["red_complete_checkpoint"] = _recon_ckpt
        if _recon_ckpt is not None and _recon_ckpt.get("story_verification_reconciliation"):
            _recon_payload = _recon_ckpt["story_verification_reconciliation"]
            if len([dict(bundle) for bundle in (_recon_payload.get("bundles") or []) if isinstance(bundle, dict)]) > 1 and any(
                not _checkpoint_bundle_artifacts_are_complete(dict(bundle))
                for bundle in (_recon_payload.get("bundles") or [])
                if isinstance(bundle, dict)
            ):
                _recon_payload = {}
            if _recon_payload:
                _dfs_node_running(repo_root=repo_root, story=story, run_id=run_id, node_id="storysufficiencyreconciliation", summary="Red-complete checkpoint — restoring reconciliation")
                _recon_synthetic: dict[str, Any] = {"prior_run_id": None, "node": None, "artifacts": []}
                _mark_replayed_node(
                    store=store,
                    run_id=run_id,
                    node_id="storysufficiencyreconciliation",
                    node_name="StorySufficiencyReconciliation",
                    stage_state=_recon_synthetic,
                    output={"red_complete_checkpoint": True},
                )
                task_context.metadata["story_verification_reconciliation"] = _recon_payload
                task_context.metadata["redreview_registered_files"] = [
                    dict(item)
                    for bundle in (_recon_payload.get("bundles") or [])
                    for item in (bundle.get("registered_files") or [])
                    if isinstance(item, dict)
                ]
                return task_context

        _dfs_node_running(repo_root=repo_root, story=story, run_id=run_id, node_id="storysufficiencyreconciliation", summary="Reconciling story-wide verification plan")
        node_exec_id = store.create_node_attempt(run_id=run_id, node_id="storysufficiencyreconciliation", node_name="StorySufficiencyReconciliation", attempt=1)

        test_design = task_context.metadata.get("test_design") or {}
        ordered_bundle_reports, reconciliation_errors = _order_bundle_redreview_reports(
            repo_root=repo_root,
            story=story,
            test_design=test_design,
            bundle_reports=[dict(report) for report in (task_context.metadata.get("bundle_redreview_reports") or []) if isinstance(report, dict)],
        )
        if reconciliation_errors:
            error_message = "story sufficiency reconciliation requires model-backed RedReview reports for every test-design bundle"
            task_context.metadata["exit_code"] = 1
            task_context.metadata["message"] = str(task_context.metadata.get("message") or "") + error_message + ": " + "; ".join(reconciliation_errors) + "\n"
            store.mark_node_finished(
                node_exec_id=node_exec_id,
                status="failed",
                output={"error": error_message, "details": reconciliation_errors},
            )
            task_context.stop_workflow()
            return task_context

        artifact = _build_story_verification_reconciliation(
            repo_root=repo_root,
            story=story,
            test_design=test_design,
            bundle_reports=ordered_bundle_reports,
        )
        payload = artifact.model_dump()
        registered_files = [dict(item) for bundle in payload.get("bundles") or [] for item in (bundle.get("registered_files") or []) if isinstance(item, dict)]
        task_context.metadata["story_verification_reconciliation"] = payload
        task_context.metadata["redreview_registered_files"] = registered_files
        store.add_artifact(
            run_id=run_id,
            node_exec_id=node_exec_id,
            kind="story_sufficiency_reconciliation",
            uri="db://artifacts/story_sufficiency_reconciliation",
            metadata=payload,
            content_type="application/json",
            byte_size=len(json.dumps(payload, sort_keys=True)),
        )
        store.mark_node_finished(node_exec_id=node_exec_id, status="succeeded", output=payload)

        # Persist red_complete checkpoint so future re-queues can skip RED → RedReview →
        # StorySufficiencyReconciliation and resume directly at the Green phase.
        _recon_story_ctx = _story_context(story)
        _recon_story_id = str(_recon_story_ctx.get("story_id") or "").strip()
        if _recon_story_id:
            _write_red_complete_checkpoint(
                repo_root=repo_root,
                story_id=_recon_story_id,
                payload={
                    "red_complete": True,
                    "story_id": _recon_story_id,
                    "run_id": run_id,
                    "story_verification_reconciliation": payload,
                    "redreview_registered_files": registered_files,
                    "bundle_redreview_reports": [dict(r) for r in (task_context.metadata.get("bundle_redreview_reports") or []) if isinstance(r, dict)],
                    "redreview_report": dict(task_context.metadata.get("redreview_report") or {}),
                },
            )

        return task_context


def _accepted_red_artifacts_missing_report(*, errors: list[str]) -> dict[str, Any]:
    return {
        "mode": "model_backed",
        "max_iterations": _green_max_iterations(),
        "iterations_used": 0,
        "history": [],
        "final_gate": {},
        "status": "accepted_red_artifacts_missing",
        "errors": [str(error) for error in errors if str(error).strip()],
    }


class GreenNode(AgentNode):
    def get_agent_config(self) -> AgentConfig:
        return AgentConfig(
            instructions=load_implementation_node_instruction("green")
        )

    async def process(self, task_context: TaskContext) -> TaskContext:
        repo_root = Path(task_context.event.repo_root)
        store, run_id = _store_run()
        story = dict(task_context.event.story)
        reconciled_verification = _repair_reconciled_bundle_artifacts_from_story_local_redreview(
            repo_root=repo_root,
            story=story,
            reconciled_verification=task_context.metadata.get("story_verification_reconciliation") or {},
        )
        task_context.metadata["story_verification_reconciliation"] = reconciled_verification
        if reconciled_verification.get("bundles"):
            task_context.metadata["redreview_registered_files"] = [
                dict(item)
                for bundle in (reconciled_verification.get("bundles") or [])
                if isinstance(bundle, dict)
                for item in (bundle.get("registered_files") or [])
                if isinstance(item, dict)
            ]
        registered_test_paths = [
            str(item.get("path"))
            for item in (task_context.metadata.get("redreview_registered_files") or [])
            if isinstance(item, dict) and str(item.get("path") or "").strip()
        ]
        bundle_plans = [dict(bundle) for bundle in (reconciled_verification.get("bundles") or []) if isinstance(bundle, dict)]

        if bundle_plans and len(bundle_plans) > 1:
            missing_bundle_paths = [
                str(bundle.get("bundle_id") or "default")
                for bundle in bundle_plans
                if not [str(path) for path in (bundle.get("test_paths") or []) if str(path).strip()]
            ]
            if missing_bundle_paths:
                _dfs_node_running(repo_root=repo_root, story=story, run_id=run_id, node_id="green", summary="Blocked: accepted RED artifacts missing")
                node_exec_id = store.create_node_attempt(run_id=run_id, node_id="green", node_name="Green", attempt=1)
                report = _accepted_red_artifacts_missing_report(errors=[f"missing accepted RED test paths for bundles: {', '.join(missing_bundle_paths)}"])
                store.mark_node_finished(node_exec_id=node_exec_id, status="failed", output=report)
                task_context.metadata["green_report"] = report
                task_context.metadata["green_passed"] = False
                task_context.metadata["exit_code"] = 1
                task_context.metadata["message"] = str(task_context.metadata.get("message") or "") + "green blocked: accepted RED artifacts missing/corrupt\\n"
                task_context.stop_workflow()
                return task_context

            _dfs_node_running(repo_root=repo_root, story=story, run_id=run_id, node_id="green", summary="Implementing to green")
            node_exec_id = store.create_node_attempt(run_id=run_id, node_id="green", node_name="Green", attempt=1)
            persisted_review_paths: set[str] = set()

            def _on_green_iteration(iteration: int, max_iterations: int, history: list[dict[str, Any]], gate: dict[str, Any]) -> None:
                gate_summary = {k: ("✓" if v.get("ok") else "✗") for k, v in gate.items()}
                latest_review = history[-1].get("outcome_review") if history and isinstance(history[-1], dict) and isinstance(history[-1].get("outcome_review"), dict) else None
                selected_prior_run_evidence = history[0].get("selected_prior_run_evidence") if history and isinstance(history[0], dict) and isinstance(history[0].get("selected_prior_run_evidence"), dict) else None
                initial_prompt_mode = str(history[0].get("prompt_mode") or "").strip() if history and isinstance(history[0], dict) else ""
                if isinstance(latest_review, dict):
                    artifact_path = str(latest_review.get("artifact_path") or "").strip()
                    if artifact_path and artifact_path not in persisted_review_paths:
                        persisted_review_paths.add(artifact_path)
                        store.add_artifact(
                            run_id=run_id,
                            node_exec_id=node_exec_id,
                            kind="green_outcome_review",
                            uri=artifact_path,
                            metadata=latest_review,
                            content_type="application/json",
                            byte_size=len(json.dumps(latest_review, sort_keys=True)),
                        )
                store.update_node_progress(
                    node_exec_id=node_exec_id,
                    progress={
                        "in_progress": True,
                        "iteration": iteration,
                        "max_iterations": max_iterations,
                        "initial_prompt_mode": initial_prompt_mode or None,
                        "selected_prior_run_evidence": selected_prior_run_evidence,
                        "gate_summary": gate_summary,
                        "latest_outcome_review": latest_review,
                        "history": history,
                    },
                )

            report, ok = _run_reconciled_green_loop(
                repo_root=repo_root,
                story=story,
                test_design=task_context.metadata.get("test_design") or {},
                implementation_planning=task_context.metadata.get("implementation_planning") or {},
                reconciled_verification=reconciled_verification,
                bundle_redreview_reports=[
                    dict(report)
                    for report in (task_context.metadata.get("bundle_redreview_reports") or [])
                    if isinstance(report, dict)
                ],
                on_iteration_complete=_on_green_iteration,
            )
            store.mark_node_finished(node_exec_id=node_exec_id, status="succeeded" if ok else "failed", output=report)
            task_context.metadata["green_report"] = report
            task_context.metadata["green_passed"] = bool(ok)
            task_context.metadata["green_outcome_reviews"] = [dict(item) for item in (report.get("outcome_reviews") or []) if isinstance(item, dict)]
            task_context.metadata["latest_green_outcome_review"] = dict(report.get("latest_outcome_review") or {}) if isinstance(report.get("latest_outcome_review"), dict) else None
            if not ok:
                task_context.metadata["exit_code"] = 1
                task_context.metadata["message"] = str(task_context.metadata.get("message") or "") + f"green failed after {report.get('iterations_used')}/{report.get('max_iterations')} model-backed attempts\n"
                task_context.stop_workflow()
            return task_context

        if not registered_test_paths:
            _dfs_node_running(repo_root=repo_root, story=story, run_id=run_id, node_id="green", summary="Blocked: accepted RED artifacts missing")
            node_exec_id = store.create_node_attempt(run_id=run_id, node_id="green", node_name="Green", attempt=1)
            report = _accepted_red_artifacts_missing_report(errors=["missing accepted RED test paths from RedReview"]) 
            store.mark_node_finished(node_exec_id=node_exec_id, status="failed", output=report)
            task_context.metadata["green_report"] = report
            task_context.metadata["green_passed"] = False
            task_context.metadata["exit_code"] = 1
            task_context.metadata["message"] = str(task_context.metadata.get("message") or "") + "green blocked: accepted RED artifacts missing/corrupt\\n"
            task_context.stop_workflow()
            return task_context

        _dfs_node_running(repo_root=repo_root, story=story, run_id=run_id, node_id="green", summary="Implementing to green")

        node_exec_id = store.create_node_attempt(run_id=run_id, node_id="green", node_name="Green", attempt=1)
        persisted_review_paths: set[str] = set()

        def _on_green_iteration(iteration: int, max_iterations: int, history: list[dict[str, Any]], gate: dict[str, Any]) -> None:
            """Write per-iteration progress to the DB so monitors see active work, not a stale timestamp."""
            gate_summary = {k: ("✓" if v.get("ok") else "✗") for k, v in gate.items()}
            latest_review = history[-1].get("outcome_review") if history and isinstance(history[-1], dict) and isinstance(history[-1].get("outcome_review"), dict) else None
            selected_prior_run_evidence = history[0].get("selected_prior_run_evidence") if history and isinstance(history[0], dict) and isinstance(history[0].get("selected_prior_run_evidence"), dict) else None
            initial_prompt_mode = str(history[0].get("prompt_mode") or "").strip() if history and isinstance(history[0], dict) else ""
            if isinstance(latest_review, dict):
                artifact_path = str(latest_review.get("artifact_path") or "").strip()
                if artifact_path and artifact_path not in persisted_review_paths:
                    persisted_review_paths.add(artifact_path)
                    store.add_artifact(
                        run_id=run_id,
                        node_exec_id=node_exec_id,
                        kind="green_outcome_review",
                        uri=artifact_path,
                        metadata=latest_review,
                        content_type="application/json",
                        byte_size=len(json.dumps(latest_review, sort_keys=True)),
                    )
            store.update_node_progress(
                node_exec_id=node_exec_id,
                progress={
                    "in_progress": True,
                    "iteration": iteration,
                    "max_iterations": max_iterations,
                    "initial_prompt_mode": initial_prompt_mode or None,
                    "selected_prior_run_evidence": selected_prior_run_evidence,
                    "gate_summary": gate_summary,
                    "latest_outcome_review": latest_review,
                    "history": history,
                },
            )

        report, ok = _run_green_sufficiency_loop(
            repo_root=repo_root,
            story=dict(task_context.event.story),
            test_design=task_context.metadata.get("test_design") or {},
            implementation_planning=task_context.metadata.get("implementation_planning") or {},
            registered_test_paths=registered_test_paths or None,
            redreview_report=dict(task_context.metadata.get("redreview_report") or {}),
            on_iteration_complete=_on_green_iteration,
        )
        store.mark_node_finished(node_exec_id=node_exec_id, status="succeeded" if ok else "failed", output=report)
        task_context.metadata["green_report"] = report
        task_context.metadata["green_passed"] = bool(ok)
        task_context.metadata["green_outcome_reviews"] = [dict(item) for item in (report.get("outcome_reviews") or []) if isinstance(item, dict)]
        task_context.metadata["latest_green_outcome_review"] = dict(report.get("latest_outcome_review") or {}) if isinstance(report.get("latest_outcome_review"), dict) else None
        if not ok:
            task_context.metadata["exit_code"] = 1
            task_context.metadata["message"] = str(task_context.metadata.get("message") or "") + f"green failed after {report.get('iterations_used')}/{report.get('max_iterations')} model-backed attempts\n"
            task_context.stop_workflow()
        return task_context


class GitCommitGreenNode(Node):
    async def process(self, task_context: TaskContext) -> TaskContext:
        repo_root = Path(task_context.event.repo_root)
        store, run_id = _store_run()
        node_exec_id = store.create_node_attempt(run_id=run_id, node_id="gitcommit(green)", node_name="GitCommit(GREEN)", attempt=1)
        cmd_env = _journal_env(
            repo_root=repo_root,
            run_id=run_id,
            node_exec_id=node_exec_id,
            story=dict(task_context.event.story),
            implementation_planning_path=str(task_context.metadata.get("implementation_planning_artifact") or "") or None,
        )

        def _enforce() -> subprocess.CompletedProcess[str]:
            cp = subprocess.run(
                ["git", "diff", "--cached", "--name-only"],
                cwd=str(repo_root),
                check=False,
                capture_output=True,
                text=True,
            )
            changed = [p for p in (cp.stdout or "").splitlines() if p.strip()]
            if not changed:
                return subprocess.run(["devflow", "enforce"], cwd=str(repo_root), check=False, capture_output=True, text=True, env=cmd_env)
            return subprocess.run(["devflow", "enforce", "--changed", *changed], cwd=str(repo_root), check=False, capture_output=True, text=True, env=cmd_env)

        def _refactor() -> subprocess.CompletedProcess[str]:
            return subprocess.run(["devflow", "refactor", "--max-iters", "3"], cwd=str(repo_root), check=False, capture_output=True, text=True, env=cmd_env)

        def _commit() -> subprocess.CompletedProcess[str]:
            subprocess.run(["git", "add", "-A"], cwd=str(repo_root), check=False, capture_output=True, text=True)
            return subprocess.run(
                ["git", "commit", "--no-verify", "-m", f"GREEN: apply green changes\n\nDevFlow-Run: {run_id}\n"],
                cwd=str(repo_root),
                check=False,
                capture_output=True,
                text=True,
            )

        enf1 = _enforce()
        if enf1.returncode == 0:
            p = _commit()
            store.mark_node_finished(
                node_exec_id=node_exec_id,
                status="succeeded" if p.returncode == 0 else "failed",
                output={
                    "attempt": 1,
                    "enforce_returncode": enf1.returncode,
                    "enforce_stdout": enf1.stdout,
                    "enforce_stderr": enf1.stderr,
                    "commit_returncode": p.returncode,
                    "commit_stdout": p.stdout,
                    "commit_stderr": p.stderr,
                },
            )
            if p.returncode != 0:
                task_context.metadata["exit_code"] = 1
            return task_context

        ref = _refactor()
        enf2 = _enforce()
        if enf2.returncode != 0:
            store.mark_node_finished(
                node_exec_id=node_exec_id,
                status="failed",
                output={
                    "attempt": 2,
                    "enforce_returncode": enf2.returncode,
                    "enforce_stdout": enf2.stdout,
                    "enforce_stderr": enf2.stderr,
                    "refactor_returncode": ref.returncode,
                    "refactor_stdout": ref.stdout,
                    "refactor_stderr": ref.stderr,
                },
            )
            task_context.metadata["exit_code"] = 1
            return task_context

        p2 = _commit()
        store.mark_node_finished(
            node_exec_id=node_exec_id,
            status="succeeded" if p2.returncode == 0 else "failed",
            output={
                "attempt": 2,
                "enforce_returncode": enf2.returncode,
                "enforce_stdout": enf2.stdout,
                "enforce_stderr": enf2.stderr,
                "refactor_returncode": ref.returncode,
                "refactor_stdout": ref.stdout,
                "refactor_stderr": ref.stderr,
                "commit_returncode": p2.returncode,
                "commit_stdout": p2.stdout,
                "commit_stderr": p2.stderr,
            },
        )
        if p2.returncode != 0:
            task_context.metadata["exit_code"] = 1
        return task_context


class RefactorNode(AgentNode):
    def get_agent_config(self) -> AgentConfig:
        return AgentConfig(
            instructions=(
                "Refactor is a real GenAI implementation node: use a model-backed coding agent to perform the primary refactoring and repair work; keep deterministic logic limited to validation/gating/persistence."
            )
        )

    async def process(self, task_context: TaskContext) -> TaskContext:
        repo_root = Path(task_context.event.repo_root)
        store, run_id = _store_run()

        # Rip-through propagation
        if task_context.metadata.get("rip_through"):
            _dfs_node_running(repo_root=repo_root, story=dict(task_context.event.story), run_id=run_id, node_id="refactor", summary="Rip-through: skipping refactor agent")
            _synthetic: dict[str, Any] = {"prior_run_id": None, "node": None, "artifacts": []}
            _mark_replayed_node(store=store, run_id=run_id, node_id="refactor", node_name="Refactor", stage_state=_synthetic, output={"rip_through": True})
            task_context.metadata["refactor_passed"] = True
            task_context.metadata["refactor_report"] = {"replayed": True, "refactor_applied": False, "iterations_used": 0, "max_iterations": 0}
            return task_context

        _dfs_node_running(repo_root=repo_root, story=dict(task_context.event.story), run_id=run_id, node_id="refactor", summary="Refactoring implementation")
        node_exec_id = store.create_node_attempt(run_id=run_id, node_id="refactor", node_name="Refactor", attempt=1)

        report, ok = _run_refactor_loop(
            repo_root=repo_root,
            story=dict(task_context.event.story),
            test_design=task_context.metadata.get("test_design") or {},
            implementation_planning=task_context.metadata.get("implementation_planning") or {},
            reconciled_verification=task_context.metadata.get("story_verification_reconciliation") or {},
        )
        report["started_green"] = bool(task_context.metadata.get("green_passed"))
        store.mark_node_finished(node_exec_id=node_exec_id, status="succeeded", output=report)
        task_context.metadata["refactor_report"] = report
        task_context.metadata["refactor_passed"] = True
        if not bool(report.get("refactor_applied")):
            task_context.metadata["message"] = str(task_context.metadata.get("message") or "") + f"refactor completed with no-op after {report.get('iterations_used')}/{report.get('max_iterations')} model-backed attempts\n"
        return task_context


class VerifyGreenNode(Node):
    async def process(self, task_context: TaskContext) -> TaskContext:
        repo_root = Path(task_context.event.repo_root)
        store, run_id = _store_run()
        node_exec_id = store.create_node_attempt(run_id=run_id, node_id="verifygreen", node_name="VerifyGreen", attempt=1)
        results = run_green_gate(
            repo_root,
            runtime_contract=_resolve_story_test_runtime_contract(repo_root=repo_root, story=dict(task_context.event.story)),
        )
        payload = {k: {"ok": v.ok, "returncode": v.returncode} for k, v in results.items()}
        ok = all(v.ok for v in results.values()) if results else True
        store.mark_node_finished(node_exec_id=node_exec_id, status="succeeded" if ok else "failed", output=payload)
        if not ok:
            task_context.metadata["exit_code"] = 1
        return task_context


class SecurityNode(AgentNode):
    def get_agent_config(self) -> AgentConfig:
        return AgentConfig(
            instructions=(
                "Security is a real GenAI implementation node: detect, repair, and verify security concerns inline using the same business logic shape as the devFlow Electron review security stage."
            )
        )

    async def process(self, task_context: TaskContext) -> TaskContext:
        repo_root = Path(task_context.event.repo_root)
        store, run_id = _store_run()

        # Rip-through propagation
        if task_context.metadata.get("rip_through"):
            _dfs_node_running(repo_root=repo_root, story=dict(task_context.event.story), run_id=run_id, node_id="security", summary="Rip-through: skipping security agent")
            _synthetic: dict[str, Any] = {"prior_run_id": None, "node": None, "artifacts": []}
            _mark_replayed_node(store=store, run_id=run_id, node_id="security", node_name="Security", stage_state=_synthetic, output={"rip_through": True})
            task_context.metadata["security_passed"] = True
            task_context.metadata["security_report"] = {"replayed": True, "security_applied": False, "iterations_used": 0, "max_iterations": 0}
            return task_context

        _dfs_node_running(repo_root=repo_root, story=dict(task_context.event.story), run_id=run_id, node_id="security", summary="Reviewing security")
        node_exec_id = store.create_node_attempt(run_id=run_id, node_id="security", node_name="Security", attempt=1)
        report, _ok = _run_security_loop(
            repo_root=repo_root,
            story=dict(task_context.event.story),
            test_design=task_context.metadata.get("test_design") or {},
            implementation_planning=task_context.metadata.get("implementation_planning") or {},
            refactor_report=task_context.metadata.get("refactor_report") or {},
            reconciled_verification=task_context.metadata.get("story_verification_reconciliation") or {},
        )
        store.mark_node_finished(node_exec_id=node_exec_id, status="succeeded", output=report)
        task_context.metadata["security_report"] = report
        task_context.metadata["security_passed"] = True
        if not bool(report.get("security_applied")):
            task_context.metadata["message"] = str(task_context.metadata.get("message") or "") + f"security completed with no-op after {report.get('iterations_used')}/{report.get('max_iterations')} model-backed attempts\n"
        return task_context


class GitCommitRefactorNode(Node):
    async def process(self, task_context: TaskContext) -> TaskContext:
        repo_root = Path(task_context.event.repo_root)
        store, run_id = _store_run()
        node_exec_id = store.create_node_attempt(run_id=run_id, node_id="gitcommit(refactor)", node_name="GitCommit(REFACTOR)", attempt=1)
        cmd_env = _journal_env(
            repo_root=repo_root,
            run_id=run_id,
            node_exec_id=node_exec_id,
            story=dict(task_context.event.story),
            implementation_planning_path=str(task_context.metadata.get("implementation_planning_artifact") or "") or None,
        )

        if not bool(task_context.metadata.get("refactor_passed")):
            store.mark_node_finished(
                node_exec_id=node_exec_id,
                status="failed",
                output={
                    "status": "blocked_missing_refactor_precondition",
                    "refactor_passed": bool(task_context.metadata.get("refactor_passed")),
                },
            )
            task_context.metadata["exit_code"] = 1
            return task_context
        if not bool(task_context.metadata.get("security_passed")):
            store.mark_node_finished(
                node_exec_id=node_exec_id,
                status="failed",
                output={
                    "status": "blocked_missing_security_precondition",
                    "security_passed": bool(task_context.metadata.get("security_passed")),
                },
            )
            task_context.metadata["exit_code"] = 1
            return task_context

        def _run_devflow_refactor() -> subprocess.CompletedProcess[str]:
            return _run_cmd(repo_root, ["devflow", "refactor", "--max-iters", "3"], env=cmd_env)

        def _commit() -> subprocess.CompletedProcess[str]:
            subprocess.run(["git", "add", "-A"], cwd=str(repo_root), check=False, capture_output=True, text=True)
            return subprocess.run(
                ["git", "commit", "--no-verify", "-m", f"REFACTOR: apply refactors\n\nDevFlow-Run: {run_id}\n"],
                cwd=str(repo_root),
                check=False,
                capture_output=True,
                text=True,
            )

        refactor_cp = _run_devflow_refactor()
        _refactor_enforce_missing = refactor_cp.returncode != 0 and (
            "Missing enforce report" in (refactor_cp.stderr or "")
            or "devflow: command not found" in (refactor_cp.stderr or "")
            or "devflow: not found" in (refactor_cp.stderr or "")
        )
        if refactor_cp.returncode != 0 and not _refactor_enforce_missing:
            store.mark_node_finished(
                node_exec_id=node_exec_id,
                status="failed",
                output={
                    "devflow_refactor_returncode": refactor_cp.returncode,
                    "devflow_refactor_stdout": refactor_cp.stdout,
                    "devflow_refactor_stderr": refactor_cp.stderr,
                },
            )
            task_context.metadata["exit_code"] = 1
            return task_context

        p = _commit()
        store.mark_node_finished(
            node_exec_id=node_exec_id,
            status="succeeded" if p.returncode == 0 else "failed",
            output={
                "devflow_refactor_returncode": refactor_cp.returncode,
                "devflow_refactor_stdout": refactor_cp.stdout,
                "devflow_refactor_stderr": refactor_cp.stderr,
                "devflow_refactor_enforce_skipped": _refactor_enforce_missing,
                "commit_returncode": p.returncode,
                "commit_stdout": p.stdout,
                "commit_stderr": p.stderr,
            },
        )
        if p.returncode != 0:
            task_context.metadata["exit_code"] = 1
        return task_context


class ImplementationWorkflow(Workflow):
    workflow_schema = WorkflowSchema(
        description="DevFlow Engine implementation DAG (GenAI workflow framework)",
        event_schema=ImplementationEvent,
        start=NormalizeNode,
        nodes=[
            NodeConfig(node=NormalizeNode, connections=[SetupDocNode]),
            NodeConfig(node=SetupDocNode, connections=[PreflightNode]),
            NodeConfig(node=PreflightNode, connections=[DependencyAssessmentNode]),
            NodeConfig(node=DependencyAssessmentNode, connections=[StoryImplementationPlanningNode]),
            NodeConfig(node=StoryImplementationPlanningNode, connections=[StoryImplementationPlanningRouter]),
            NodeConfig(node=StoryImplementationPlanningRouter, connections=[TestDesignNode, WaitingForProviderStoryNode, CreatePrerequisiteStoryNode, BlockedImplementationNode], is_router=True),
            NodeConfig(node=WaitingForProviderStoryNode, connections=[]),
            NodeConfig(node=CreatePrerequisiteStoryNode, connections=[]),
            NodeConfig(node=BlockedImplementationNode, connections=[]),
            NodeConfig(node=TestDesignNode, connections=[RedNode]),
            NodeConfig(node=RedNode, connections=[RedReviewNode]),
            NodeConfig(node=RedReviewNode, connections=[StorySufficiencyReconciliationNode]),
            NodeConfig(node=StorySufficiencyReconciliationNode, connections=[GreenNode]),
            NodeConfig(node=GreenNode, connections=[RefactorNode]),
            NodeConfig(node=RefactorNode, connections=[SecurityNode]),
            NodeConfig(node=SecurityNode, connections=[GitCommitRefactorNode]),
            NodeConfig(node=GitCommitRefactorNode, connections=[]),
        ],
    )


def run_implementation_dag(
    *,
    repo_root: Path,
    store: ExecutionStore,
    story: dict[str, Any],
) -> ImplementationDagResult:
    """Execute Area 6 implementation DAG via the vendored GenAI workflow framework."""

    root_corr = f"corr_{uuid.uuid4()}"
    story_ctx = _story_context(story)
    run_id = store.create_run(
        dag_id="implementation_dag",
        dag_version="v1",
        root_correlation_id=root_corr,
        config={
            "story_id": story_ctx.get("story_id"),
            "story_uuid": story_ctx.get("story_uuid"),
            "replay": _story_replay_metadata(story),
        },
    )
    store.mark_run_started(run_id=run_id)

    wf = ImplementationWorkflow()

    global _CURRENT_STORE, _CURRENT_RUN_ID
    _CURRENT_STORE = store
    _CURRENT_RUN_ID = run_id
    try:
        with execution_context(
            run_id=run_id,
            dag_id="implementation_dag",
            repo_root=repo_root,
            story_id=story_ctx.get("story_id"),
            story_uuid=story_ctx.get("story_uuid"),
            story_title=story_ctx.get("story_title"),
        ):
            ctx = wf.run({"repo_root": str(repo_root), "story": story})
    finally:
        _CURRENT_STORE = None
        _CURRENT_RUN_ID = None

    exit_code = int(ctx.metadata.get("exit_code") or 0)
    msg = str(ctx.metadata.get("message") or "")
    failed_stage = None
    if exit_code != 0:
        for stage in reversed(default_implementation_stages()):
            node = store.get_latest_node_attempt(run_id=run_id, node_id=stage.node_id)
            if node is not None and str(node.get("status") or "") == "failed":
                failed_stage = stage.node_id
                break
            if node is not None and str(node.get("status") or "") == "succeeded":
                break
        failed_stage = failed_stage or _story_replay_resume_from_stage(story) or "red"

    store.mark_run_finished(run_id=run_id, status="succeeded" if exit_code == 0 else "failed")
    terminal_summary = "Story implemented" if exit_code == 0 else "Story implementation failed"
    _dfs_terminal(repo_root=repo_root, story=story, run_id=run_id, exit_code=exit_code, summary=terminal_summary)
    failure_context = None
    if exit_code != 0:
        failure_context = _build_implementation_failure_context(
            store=store,
            run_id=run_id,
            failed_stage=failed_stage,
            metadata=ctx.metadata,
        )
    return ImplementationDagResult(exit_code=exit_code, message=msg, run_id=run_id, failed_stage=failed_stage, failure_context=failure_context)
