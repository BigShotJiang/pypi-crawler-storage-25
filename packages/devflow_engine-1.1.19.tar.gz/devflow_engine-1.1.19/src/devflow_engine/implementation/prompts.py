from __future__ import annotations

from pathlib import Path


_REPO_ROOT = Path(__file__).resolve().parents[3]
_PROMPTS_ROOT = _REPO_ROOT / "prompts" / "implementation"

_STAGE_PROMPT_LAYOUT: dict[str, tuple[str, str]] = {
    "green": ("green", "green"),
}

_NODE_CONFIG_LAYOUT: dict[str, tuple[str, str]] = {
    "green": ("green", "node_config"),
}

_REVIEW_PROMPT_LAYOUT: dict[str, tuple[str, str]] = {
    "green_outcome_review": ("green_review", "outcome_review"),
    "green_prior_run_review": ("green_review", "prior_run_review"),
}


def implementation_prompt_path(*, node: str, agent_name: str) -> Path:
    return _PROMPTS_ROOT / node / agent_name / "prompt.md"


def implementation_stage_prompt_path(stage_name: str) -> Path:
    try:
        node, agent_name = _STAGE_PROMPT_LAYOUT[stage_name]
    except KeyError as exc:
        raise KeyError(f"Unknown implementation stage prompt mapping: {stage_name}") from exc
    return implementation_prompt_path(node=node, agent_name=agent_name)


def implementation_node_prompt_path(node: str) -> Path:
    try:
        mapped_node, agent_name = _NODE_CONFIG_LAYOUT[node]
    except KeyError as exc:
        raise KeyError(f"Unknown implementation node prompt mapping: {node}") from exc
    return implementation_prompt_path(node=mapped_node, agent_name=agent_name)


def load_implementation_prompt_markdown(*, node: str, agent_name: str) -> str:
    return implementation_prompt_path(node=node, agent_name=agent_name).read_text(encoding="utf-8").strip()


def load_implementation_stage_prompt_markdown(stage_name: str) -> str:
    return implementation_stage_prompt_path(stage_name).read_text(encoding="utf-8").strip()


def load_implementation_node_instruction(node: str) -> str:
    return _parse_prompt_markdown(implementation_node_prompt_path(node).read_text(encoding="utf-8"))[0]


def implementation_review_prompt_path(review_name: str) -> Path:
    try:
        node, agent_name = _REVIEW_PROMPT_LAYOUT[review_name]
    except KeyError as exc:
        raise KeyError(f"Unknown implementation review prompt mapping: {review_name}") from exc
    return implementation_prompt_path(node=node, agent_name=agent_name)


def load_implementation_stage_instruction(stage_name: str) -> str:
    return _parse_prompt_markdown(implementation_stage_prompt_path(stage_name).read_text(encoding="utf-8"))[0]


def load_implementation_stage_guidance(stage_name: str) -> list[str]:
    return _parse_prompt_markdown(implementation_stage_prompt_path(stage_name).read_text(encoding="utf-8"))[1]


def load_implementation_review_instruction(review_name: str) -> str:
    return _parse_prompt_markdown(implementation_review_prompt_path(review_name).read_text(encoding="utf-8"))[0]


def load_implementation_review_guidance(review_name: str) -> list[str]:
    return _parse_prompt_markdown(implementation_review_prompt_path(review_name).read_text(encoding="utf-8"))[1]


def _parse_prompt_markdown(markdown: str) -> tuple[str, list[str]]:
    instruction = ""
    guidance: list[str] = []
    for raw_line in markdown.splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("- "):
            guidance.append(line[2:].strip())
            continue
        if not instruction:
            instruction = line
    if not instruction:
        raise ValueError("Implementation prompt markdown is missing an instruction line.")
    return instruction, guidance
