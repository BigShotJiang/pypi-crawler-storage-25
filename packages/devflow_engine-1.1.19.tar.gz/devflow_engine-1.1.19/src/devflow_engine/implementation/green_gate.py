from __future__ import annotations

import shutil
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path

from .test_runtime import (
    infer_test_runtime_contract,
    runtime_contract_cwd,
    runtime_contract_env,
)


@dataclass(frozen=True)
class GateResult:
    ok: bool
    stdout: str
    stderr: str
    returncode: int


def _resolve_devflow_cmd(repo_root: Path) -> list[str]:
    found = shutil.which("devflow")
    if found:
        return [found]
    candidates = [
        repo_root / ".venv" / "bin" / "devflow",
        Path(sys.executable).parent / "devflow",
        Path(__file__).resolve().parents[3] / ".venv" / "bin" / "devflow",
    ]
    for candidate in candidates:
        if candidate.exists():
            return [str(candidate)]
    return ["devflow"]


def run_cmd(repo_root: Path, cmd: list[str], *, cwd: Path | None = None, env: dict[str, str] | None = None) -> GateResult:
    if cmd and cmd[0] == "devflow":
        cmd = [*_resolve_devflow_cmd(repo_root), *cmd[1:]]
    p = subprocess.run(
        cmd,
        cwd=str(cwd or repo_root),
        text=True,
        capture_output=True,
        env=env,
    )
    return GateResult(
        ok=p.returncode == 0,
        stdout=p.stdout,
        stderr=p.stderr,
        returncode=p.returncode,
    )


def _run_runtime_contract_setup(repo_root: Path, runtime_contract: dict[str, object]) -> GateResult | None:
    setup_cmd = runtime_contract.get("setup_cmd")
    if not isinstance(setup_cmd, list) or not setup_cmd:
        return None
    return run_cmd(
        repo_root,
        [str(item) for item in setup_cmd],
        cwd=runtime_contract_cwd(repo_root=repo_root, runtime_contract=runtime_contract),
        env=runtime_contract_env(runtime_contract),
    )


def run_green_gate(repo_root: Path, runtime_contract: dict[str, object] | None = None) -> dict[str, GateResult]:
    """Run 'green' definition: registry + package policy + tests + typecheck + lint."""

    results: dict[str, GateResult] = {}
    python_cmd = sys.executable or "python3"
    runtime_contract = runtime_contract or infer_test_runtime_contract(repo_root)

    # If a repo-local registry exists, it is part of the definition of green.
    if (repo_root / ".devflow" / "registry.sqlite").exists():
        results["registry"] = run_cmd(repo_root, ["devflow", "registry", "validate"])
        results["package_policy"] = run_cmd(repo_root, ["devflow", "registry", "gate-packages"])

    setup_result = _run_runtime_contract_setup(repo_root, runtime_contract)
    if setup_result is not None and not setup_result.ok:
        results["tests"] = setup_result
    else:
        results["tests"] = run_cmd(
            repo_root,
            [str(item) for item in (runtime_contract.get("run_cmd") or [python_cmd, "-m", "pytest"])],
            cwd=runtime_contract_cwd(repo_root=repo_root, runtime_contract=runtime_contract),
            env=runtime_contract_env(runtime_contract),
        )
    results["typecheck"] = run_cmd(repo_root, [python_cmd, "-m", "mypy", "."])
    results["lint"] = run_cmd(repo_root, [python_cmd, "-m", "ruff", "check", "."])
    return results
