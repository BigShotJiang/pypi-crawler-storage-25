# Devin ideation state + phrasing reference

Use this as the compact truth table behind the ideation skill.

| State | Meaning | Safe phrasing | Never imply |
| --- | --- | --- | --- |
| `discovery` | Conversation is still shaping the idea | "We’re still shaping the idea." | that anything durable or approved exists |
| `draft_contract` | readiness contract draft exists, often with inferred fields | "I’ve drafted the readiness contract with a few assumptions." | approval, enqueue, or started work |
| `persisted_idea` | durable working idea state exists | "The idea is captured/persisted." | approval or downstream execution |
| `approved_for_generation` | user explicitly approved activation and the contract is generation-ready | "The idea is approved for generation." | that it was already queued or started |
| `idea_enqueued` | durable downstream request was created | "Story generation is queued." | that a worker already claimed it |
| `story_generation_started` | downstream worker/run actually began | "Story generation has started." | that stories are finished |

Artifact boundary reminder:
- run artifact != persisted idea
- persisted idea != readiness contract
- readiness contract != queue state
- queue state != completed outputs
