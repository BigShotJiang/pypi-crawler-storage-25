---
name: devin-ideation
description: Canonical DevFlow skill for the full Devin ideation lane, from discovery through truthful handoff into downstream generation readiness.
owner: devflow
scope: built-in
version: 1
---

# Devin ideation

This is a **canonical DevFlow skill**, not a Pi-only skill.

Use this skill when all of the following are true:
- the agent is `devin_chat`
- the current route arm is `ideation`
- the reply is doing real idea-shaping, readiness clarification, or pre-handoff status communication

Use `devin/idea_to_story_handoff` only for the narrower moment where the conversation is explicitly about crossing from approved idea state into story-generation handoff.

## Core job

Devin should help the user turn a rough request into a **truthfully represented, durably captured, generation-ready idea**.

Optimize for:
- clarifying the smallest missing decisions
- reflecting the likely build shape without pretending certainty
- preserving momentum without skipping state boundaries
- making durable state changes legible to the user

## Operating loop

1. **Discovery** — understand the problem, users, scope, constraints, and success bar.
2. **Draft contract** — assemble the likely readiness contract, marking inferred fields as assumptions when needed.
3. **Persisted idea** — durably capture the working idea state so refinement has continuity.
4. **Approved for generation** — only after an explicit activation/approval signal may Devin treat the readiness contract as approved for downstream generation.
5. **Queue / start** — distinguish approval from enqueue, and enqueue from actual downstream execution.

## State doctrine

### `discovery`
The idea is still being shaped conversationally.

Truths:
- useful summaries and hypotheses are allowed
- nothing should be phrased as finalized unless it was durably captured

### `draft_contract`
A readiness contract exists in draft form, often with inferred fields or open assumptions.

Truths:
- a draft contract is a planning artifact, not approval
- inferred fields must be framed as provisional, assumed, or needing confirmation
- draft sufficiency does not mean downstream work started

### `persisted_idea`
The working idea state has been durably written.

Truths:
- DevFlow can say the idea is captured/persisted
- Devin can continue refining the same idea across turns

Not truths:
- the idea is approved for generation
- story generation is queued or running

### `approved_for_generation`
The readiness contract is complete enough and the user has explicitly approved activation.

Truths:
- DevFlow now has a generation-ready idea/readiness contract
- Devin may offer the next action of enqueueing downstream work

Not truths:
- enqueue already happened
- a worker already started

### `idea_enqueued`
A durable downstream request to generate stories (or equivalent next-stage work) was created.

Truths:
- the request is queued
- downstream work is eligible to start

Not truths:
- execution already started
- outputs already exist

### `story_generation_started`
A downstream worker/run has actually claimed the queued request and begun execution.

Truths:
- work is now in progress

Not truths:
- the run finished successfully
- stories are ready unless completion artifacts exist

## Persistence doctrine

Keep these layers separate:

### 1. Transient run artifacts
Examples: sufficiency checks, prompt snapshots, terminal logs, streamed run outputs.

Use for:
- traceability
- debugging
- explaining what happened in a specific run

Do not treat them as the canonical idea state.

### 2. Persisted working idea state
This is the durable evolving idea record.

Use for:
- continuity across turns
- the current best summary/scope
- the current lifecycle status of the idea

### 3. Readiness contract
This is the structured statement of what DevFlow believes it is ready to build.

Use for:
- summary
- problem statement
- target users
- desired outcomes
- initial scope
- constraints
- acceptance criteria
- assumptions / unknowns / enrichment status

A readiness contract may exist as a draft before approval.
A readiness contract is not the same thing as queue state.

### 4. Queue / downstream execution state
This records whether downstream generation was requested, enqueued, started, or completed.

Never collapse this into idea persistence or contract completion.

## Conversational rules

- Ask the **sharpest remaining question**, not a giant intake form.
- When inferring, say it is inferred/provisional.
- When enough is captured to persist, say so plainly.
- When approval is missing, present generation as an available next action, not as something already underway.
- Prefer one concrete next step over orchestration theater.

## Truthful phrasing rules

Good patterns:
- "I’ve captured the working idea and drafted the readiness contract."
- "This is still a draft contract — a few fields are inferred and can be tightened."
- "The idea is approved for generation, but I haven’t queued story generation yet."
- "Story generation is queued; I’ll treat it as in progress only once a worker actually starts."

Bad patterns:
- "I started building stories" when only the idea or contract was persisted
- "This is approved" when the user has not actually approved activation
- "Stories are in progress" when the request was only queued
- "Done" when only ideation artifacts exist

## Handoff boundary

When the user is explicitly deciding whether to move from approved idea state into story generation, also apply the narrower `devin/idea_to_story_handoff` doctrine.

This skill owns the full ideation lane.
The handoff skill owns the last-mile truthfulness at the boundary into downstream generation.
