---
name: devflow-queue-integration
description: Operational DevFlow skill for kicking, observing, and investigating integration_queue work and integration DAG outputs.
owner: devflow
scope: built-in
version: 1
---

# DevFlow queue: integration

Use this skill when the task is about **integration follow-through for an implemented idea**.

## Core job

Determine whether integration work for an `idea_id` has:
- had a payload prepared
- been enqueued
- started via worker execution
- completed with durable current artifacts
- failed and handed off to recovery

## How to start / kick the lane

Current repo surfaces:
- `devflow integration prepare <idea_id>`
- `devflow integration enqueue <idea_id> --project <project_id>`
- `devflow worker start --project <project_id> --once`

Manual direct run exists but is not the queue path:
- `devflow integration run <idea_id>`

When operating the queue lane, prefer enqueue + worker over claiming queue progress from a manual run.

## Observe status

Check in this order:

1. `devflow integration status <idea_id>`
2. `devflow worker report --project <project_id>`
3. `integration_queue` row in `.devflow/execution.sqlite`
4. correlated run of kind `worker.integration`
5. idea-local integration artifacts

High-value artifact locations:
- `.devflow/ideas/<idea_id>/integration_payload.json`
- `.devflow/ideas/<idea_id>/integration/current/`
- `.devflow/ideas/<idea_id>/integration/runs/`
- legacy fallback location: `.devflow/ideas/<idea_id>/pipelines/integration_dag/`

Good first SQL snapshot:

```sql
select integration_queue_id, idea_id, status, started_run_id, finished_run_id, failure_message, updated_at
from integration_queue
where project_id = '<project_id>'
order by updated_at desc;
```

## Investigate failures

Look first at:
1. `integration_queue.failure_message`
2. `integration_queue.failure_context_json`
3. `integration_payload.json`
4. latest pipeline run directory
5. run/node/artifact/error rows for `worker.integration`
6. recovery queue state if the failure already escalated

Common real failure shapes:
- payload missing or stale for the `idea_id`
- implemented-story evidence incomplete
- integration DAG failed after starting
- queue row failed but current artifacts partially exist

## Primary evidence to inspect first

1. `integration_queue` row
2. `devflow integration status <idea_id>` output
3. payload path
4. latest integration run dir
5. correlated DB run/artifact/error records

## What counts as success

Only treat the lane as successful when:
- `integration_queue.status = completed`
- the integration run succeeded
- `.devflow/ideas/<idea_id>/integration/current/` exists or equivalent latest durable current state exists
- any registered-project sync side effects completed when expected

## What counts as blockage

Treat these as blocked/problem states:
- queue row failed
- payload cannot be prepared/resolved
- latest run exists but current durable integration state was not updated
- recovery is now the active owner of the failed integration item

## Strong future tool candidates

- `idea_id` -> integration status summary
- integration payload validator/locator
- latest integration run summary
- integration queue retry / inspect helper
- queue-to-artifact correlation helper
