---
name: devflow-queue-runtime-core
description: Canonical DevFlow operations skill for shared queue/runtime doctrine across worker control, queue observation, and truthful status claims.
owner: devflow
scope: built-in
version: 1
---

# DevFlow queue/runtime core

Use this skill when the task is about **operating, observing, or truthfully describing** DevFlow runtime state.

Applies across:
- queue kick / drain
- worker status
- queue failure triage
- recovery follow-through
- integration/runtime investigation

This skill is harness-agnostic by default.
CLI and SQLite examples below are the current repo surfaces, not the only valid harness.

## Core doctrine

Preserve these facts strictly:
- `queued` is not `started`
- `claimed` is not `finished`
- worker state is not proof of queue completion
- run creation is not proof of downstream success
- artifact existence is not proof the terminal queue row reconciled correctly
- conversational optimism is not runtime truth

Always prefer **deterministic observation before progress claims**.

## Runtime sources of truth

Check these in this order:

1. **Active worker state**
   - `devflow worker report --project <project_id>`
   - `project_workers` row in `.devflow/execution.sqlite`
2. **Queue row for the lane being discussed**
   - `idea_queue`
   - `story_queue`
   - `integration_queue`
   - `recovery_queue`
3. **Run records**
   - `runs`
   - `nodes`
   - `artifacts`
   - `errors`
4. **Flow-local durable artifacts**
   - idea/story/integration/recovery files under `.devflow/...`
5. **Rich logs / transcripts** when investigating failure or churn
   - `/Users/devflow/.devflow/llm_logs/*.jsonl`
   - `/Users/devflow/.devflow/llm_sessions.sqlite`

Do not invert that order and then speak as though state were verified.

## Standard operator loop

1. Identify the flow and concrete item id if possible.
2. Read worker state.
3. Read the relevant queue row.
4. Correlate the queue row to the run id(s).
5. Inspect artifacts/logs appropriate to the flow.
6. Only then classify the state as:
   - queued
   - running
   - completed
   - failed
   - blocked
   - stale / needs reconciliation

## Standard commands

Common control surface:
- `devflow worker report --project <project_id>`
- `devflow worker start --project <project_id> --once`
- `devflow worker start --project <project_id>`
- `devflow worker stop --project <project_id>`
- `devflow worker recover --project <project_id>`
- `devflow worker supabase-events --once`
- `devflow worker supabase-events --no-realtime`

Core DB location:
- `<repo_root>/.devflow/execution.sqlite`

## Observation rules

### Worker report rule

`worker report` tells you:
- whether a project worker is active
- which queue type/item it thinks it owns
- which run id is active

It does **not** by itself prove that the queue row moved to a terminal state.

### Queue row rule

The queue table is the durable answer to whether the item is:
- still pending
- in progress
- completed
- failed
- blocked

### Run correlation rule

A queue row may point to a wrapper/orchestration run whose child DAG run does the real work.
Do not assume there is only one relevant run id.

## Stale-state rule

Use `devflow worker recover --project <project_id>` when the worker process died or left stale ownership state.
That command is for **worker-state reconciliation**, not for forcing business success.

## Kill-switch rule

Before trying to start a worker, remember the worker may be intentionally blocked by:
- `DEVFLOW_DO_NOT_RUN_WORKER=true`
- `~/.devflow/do-not-run-worker`
- `~/.devflow/config.toml` with worker disablement
- `<repo>/.devflow/do-not-run-worker`
- `<repo>/.devflow/config.toml` with worker disablement

Do not misdiagnose a guardrail as spontaneous failure.

## What counts as success

A queue/runtime operation is successful only when the durable system state matches the claim being made.
Examples:
- "queued" -> queue row is queued
- "running" -> worker/run actually claimed and started the item
- "completed" -> queue row is terminal-complete and required outputs exist
- "recovered" -> recovery row completed and the source lane is reconciled/re-enqueued as intended

## What counts as blockage

Treat these as blocked states:
- queue row explicitly `blocked`
- repeated no-material-change churn
- stale worker ownership preventing pickup
- recovery row active but not converging
- required artifacts missing after a claimed success
- logs show the agent kept operating on the wrong seam

## Strong future tool candidates

- `devflow_read_worker_state`
- `devflow_read_queue_item_state`
- `devflow_read_run_correlation`
- `devflow_read_latest_failure_evidence`
- `devflow_detect_stale_worker_state`
