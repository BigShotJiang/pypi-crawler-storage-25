---
name: devflow-queue-idea-to-story
description: Operational DevFlow skill for starting, observing, and investigating the idea-to-story queue lane.
owner: devflow
scope: built-in
version: 1
---

# DevFlow queue: idea -> story

Use this skill when the task is about the **runtime lane that turns an already-approved idea into story outputs**.

This skill starts at the queue/runtime boundary.
It does **not** replace:
- `devin/ideation`
- `devin/idea_to_story_handoff`

Those own conversational approval truth.
This skill owns operational inspection after the idea payload exists or the queue lane is being discussed.

## Core job

Determine whether an idea has:
- been queued for story generation
- been claimed and started
- produced durable story outputs
- failed, blocked, or stalled

## How to start / kick the lane

Primary runtime path:
- ensure an `idea_queue` item exists for the `idea_id`
- run `devflow worker start --project <project_id> --once` for one-step pickup
- or `devflow worker start --project <project_id>` to drain the queue

Supabase/control-plane path in this repo:
- `devflow worker supabase-events`
- supported request event: `devflow.idea.stories.generate.request`

Do not say story generation started just because the idea was approved in conversation.
Runtime start begins when the queue item is claimed and the worker starts `worker.idea_to_story`.

## Observe status

Check in this order:

1. `devflow worker report --project <project_id>`
2. `idea_queue` row in `<repo_root>/.devflow/execution.sqlite`
3. correlated run in `runs` for kind `worker.idea_to_story`
4. generated idea/story artifacts under `.devflow/ideas/<idea_id>/...`
5. canonical story outputs under `ai_docs/context/v2/project_docs/user_stories/`

Good first SQL snapshot:

```sql
select idea_queue_id, idea_id, status, started_run_id, finished_run_id, failure_message, updated_at
from idea_queue
where project_id = '<project_id>'
order by updated_at desc;
```

High-value artifact locations:
- `.devflow/ideas/<idea_id>/traditional_user_stories/<story_set_id>/`
- `.devflow/ideas/<idea_id>/devflow_story_sets/<devflow_story_set_id>/`
- `ai_docs/context/v2/project_docs/user_stories/`

## Investigate failures

Look first at:
1. `idea_queue.failure_message`
2. `idea_queue.failure_context_json`
3. `runs` / `nodes` / `artifacts` for the correlated run
4. any `resume_cursor` recorded in failure context
5. story-generation artifacts in the idea directory

Helpful current commands:
- `devflow worker failed-ideas --project <project_id>`
- `devflow worker retry-idea --project <project_id> --latest`
- `devflow worker retry-idea --project <project_id> --latest --run-now`

If the lane failed after partial output, verify whether the failure happened in:
- traditional story decomposition
- story-plane adjudication
- DevFlow story compilation
- downstream sync/publication after story artifacts already exist

## Primary evidence to inspect first

1. `idea_queue` row
2. run + node records
3. `.devflow/ideas/<idea_id>/traditional_user_stories/...`
4. `.devflow/ideas/<idea_id>/devflow_story_sets/...`
5. canonical generated story docs

If richer agent logs exist for the failure, prefer those over summary fields.

## What counts as success

Only treat the lane as successful when:
- the `idea_queue` row is terminal-complete
- the run finished successfully
- durable story outputs exist for the idea
- the canonical generated story surface was updated when that step belongs to the run

## What counts as blockage

Treat these as blocked/problem states:
- `idea_queue.status = failed`
- repeated retries with the same `resume_cursor` and no new durable outputs
- story artifacts exist but queue/run reconciliation is inconsistent
- the idea payload is missing or stale for the referenced `idea_id`
- recovery has taken over the lane

## Strong future tool candidates

- latest `idea_queue` summary for an `idea_id`
- `resume_cursor` explainer
- story-output locator for an `idea_id`
- latest failed idea retry helper
- queue-row -> run/artifact correlation helper
