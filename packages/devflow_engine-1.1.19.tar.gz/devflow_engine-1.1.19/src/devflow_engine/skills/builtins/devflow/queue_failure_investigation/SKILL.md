---
name: devflow-queue-failure-investigation
description: Cross-cutting DevFlow skill for failure/log investigation across queue lanes, with log-first evidence order and run-correlation doctrine.
owner: devflow
scope: built-in
version: 1
---

# DevFlow queue: failure investigation / logs

Use this skill when the task is to answer:
- what failed
- where it failed
- whether the queue state matches the real failure
- whether recovery is acting on the correct seam
- whether a run is actually stuck, stale, or merely mis-correlated

This is the cross-cutting investigation module for all queue lanes.

## Core doctrine

Do not start from summary rows alone when richer evidence exists.
Prefer this evidence order:

1. **Primary:** streamed LLM / agent logs and session evidence
   - `/Users/devflow/.devflow/llm_logs/*.jsonl`
   - `/Users/devflow/.devflow/llm_sessions.sqlite`
2. **Secondary:** node-level artifacts and errors
   - `artifacts`
   - `errors`
   - `nodes`
3. **Tertiary:** queue rows and worker summary state
   - `idea_queue`
   - `story_queue`
   - `integration_queue`
   - `recovery_queue`
   - `project_workers`

## Standard investigation loop

1. Identify the lane and durable item id.
2. Read the queue row and current worker state.
3. Correlate to the wrapper/orchestration run.
4. Search for the real child DAG run if the wrapper is thin.
5. Read logs/artifacts for the failing stage.
6. Classify the failure as one of:
   - real code/runtime failure
   - stale worker / reconciliation failure
   - wrong-run investigation
   - repeated churn with no material change
   - blocked by prerequisite/state boundary

## Wrapper-vs-child run rule

Never assume the user-facing wrapper run id is the same as the actual child DAG run id.
Check for mismatch explicitly.

Correlate on:
- queue item id
- `story_id` or `idea_id` when relevant
- repo root
- created-at time window
- artifact paths
- node sequence

A wrapper run can look stranded even while the child DAG succeeded correctly.
Do not call the whole flow failed until both layers are checked.

## First inspection targets

### For any failed lane
- queue row `failure_message`
- queue row `failure_context_json`
- matching run(s) in `runs`
- matching node rows in `nodes`
- matching `errors`
- high-value `artifacts`

### For story churn
- `actual_failed_node`
- `churn_state`
- streamed transcripts for Green/Refactor/Security/etc.
- whether the edits hit the correct seam

### For recovery churn
- recovery diagnosis/execution artifacts
- durable churn-gate evidence
- whether the same failure signature repeated without material repo/state change

## What counts as success

A failure investigation is successful when it produces a grounded answer to:
- the failing boundary
- the best primary evidence
- whether the state is real failure vs stale/mis-correlated state
- the next correct lane: retry, recovery, escalate, or declare blocked

## What counts as blockage

Treat the investigation itself as blocked when:
- the queue item cannot be correlated to any relevant run or artifact
- logs are missing and DB evidence is internally inconsistent
- the worker/report state is stale and must be reconciled first
- the operator is still looking at the wrong wrapper run

## Strong future tool candidates

- log-first failure packet reader
- queue item -> run/artifact/session correlation helper
- wrapper-child mismatch detector
- churn explainer for story/recovery lanes
- lane-specific first-evidence summary helper
