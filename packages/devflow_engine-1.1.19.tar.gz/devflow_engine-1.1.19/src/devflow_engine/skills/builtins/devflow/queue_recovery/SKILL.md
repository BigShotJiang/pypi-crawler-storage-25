---
name: devflow-queue-recovery
description: Operational DevFlow skill for recovery_queue execution, recovery outcome classification, and recovery handoff inspection.
owner: devflow
scope: built-in
version: 1
---

# DevFlow queue: recovery

Use this skill when the task is about **post-failure recovery work** in `recovery_queue`.

This skill complements `docs/recovery-dag-contract.md`.
That doc explains the DAG contract.
This skill explains how to operate and inspect the recovery lane concretely.

## Core job

Determine whether a failed queue item has:
- been handed off into `recovery_queue`
- started a real recovery run
- been re-enqueued, delegated, blocked, or fully recovered
- produced the expected recovery handoff artifact

## How to start / kick the lane

Normal path:
- recovery items are enqueued automatically when a queue lane fails
- run `devflow worker start --project <project_id> --once` or drain the worker

Separate command with different purpose:
- `devflow worker recover --project <project_id>` repairs **stale worker ownership state**
- it does **not** itself run the business recovery DAG for a fresh failure

Do not bypass recovery state with direct SQL edits unless the task is explicitly DB repair.

## Observe status

Check in this order:

1. `devflow worker report --project <project_id>`
2. `recovery_queue` row in `.devflow/execution.sqlite`
3. correlated recovery run, usually `post_queue_failure_recovery_dag`
4. recovery execution metadata / artifacts
5. recovery handoff artifact on disk
6. source queue row after recovery action

Good first SQL snapshot:

```sql
select recovery_queue_id, source_queue_type, source_item_id, status, started_run_id, finished_run_id, failure_message, updated_at
from recovery_queue
where project_id = '<project_id>'
order by updated_at desc;
```

High-value handoff artifact locations:
- story-scoped: `.devflow/stories/<story_id>/recovery_handoff.json`
- non-story fallback: `.devflow/recovery_handoffs/<queue_type>/<item_id>.json`

## Investigate failures

Look first at:
1. `recovery_queue` row
2. correlated recovery run + node/artifact/error records
3. recovery handoff artifact
4. source queue item state after attempted recovery
5. rich logs gathered during recovery investigation/execution

Important recovery outcomes to classify correctly:
- `reenqueued`
- `delegated`
- `blocked`
- `recovered`

Do not compress those into a generic "fixed" claim.

## Primary evidence to inspect first

1. `recovery_queue.status`
2. recovery run status
3. published recovery summary / handoff artifact
4. source queue row reconciliation
5. churn/no-material-change evidence if retries repeat

## What counts as success

Only treat recovery as successful when the durable result matches the declared outcome:
- `reenqueued` -> source queue row was actually reset/re-queued
- `delegated` -> the handoff/delegation artifact exists and the target lane is explicit
- `recovered` -> the recovery row completed and the source item is reconciled as intended

## What counts as blockage

Treat these as blocked/problem states:
- `recovery_queue.status = failed` or `blocked`
- durable churn gate fired for repeated no-material-change recovery
- recovery kept acting on the wrong seam
- handoff artifact is missing despite a claimed publish step
- source queue row did not reconcile to the declared outcome

## Strong future tool candidates

- latest recovery queue item summary
- source queue item -> recovery chain reader
- recovery handoff locator
- recovery outcome explainer
- durable churn-gate state reader
