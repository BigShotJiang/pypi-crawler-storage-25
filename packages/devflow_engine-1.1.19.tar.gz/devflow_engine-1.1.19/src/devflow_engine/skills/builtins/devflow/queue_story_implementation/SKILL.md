---
name: devflow-queue-story-implementation
description: Operational DevFlow skill for story_queue execution, implementation status, and implementation failure investigation.
owner: devflow
scope: built-in
version: 1
---

# DevFlow queue: story implementation

Use this skill when the task is about **executing or inspecting story implementation work** in `story_queue`.

## Core job

Determine whether a story:
- is queued for implementation
- is actively being implemented
- completed and was marked implemented
- failed and handed off to recovery
- is blocked by churn, prerequisites, or review-stage failure

## How to start / kick the lane

Normal path:
- ensure the story exists in `story_queue`
- run `devflow worker start --project <project_id> --once`
- or drain with `devflow worker start --project <project_id>`

The worker claims `story_queue` items and starts a wrapper run of kind:
- `worker.story.execute`

Do not confuse presence in `story_queue` with active execution.
Execution begins only after the row is claimed and the worker updates it to `in_progress`.

## Observe status

Check in this order:

1. `devflow worker report --project <project_id>`
2. `story_queue` row in `.devflow/execution.sqlite`
3. wrapper run `worker.story.execute`
4. actual child DAG run(s) and their `nodes` / `artifacts` / `errors`
5. story-local artifacts under `.devflow/stories/<story_id>/`
6. canonical story source state under `ai_docs/context/v2/project_docs/user_stories/`

Good first SQL snapshot:

```sql
select story_queue_id, story_id, status, started_run_id, finished_run_id, failure_message, updated_at
from story_queue
where project_id = '<project_id>'
order by updated_at desc;
```

## Investigation doctrine

### Wrapper-vs-child rule

Do **not** stop at the outer `worker.story.execute` run.
Always verify whether the real child DAG run used a different run id.

Correlate on:
- `story_id`
- queue item id
- repo root
- created-at window
- artifact paths
- node sequence

### Log-first rule

For story churn or repeated failures, inspect rich streamed logs first:
- `/Users/devflow/.devflow/llm_logs/*.jsonl`
- `/Users/devflow/.devflow/llm_sessions.sqlite`

Use queue summary state only as corroboration.

### Failure-context rule

High-value fields often live in `story_queue.failure_context_json`, including:
- `failed_stage`
- `implementation_run_id`
- `actual_failed_node`
- `churn_state`
- `recovery_disposition`
- prior replay details

## Primary evidence to inspect first

1. `story_queue` row
2. wrapper run record
3. child DAG run record(s)
4. `errors` and `artifacts` rows for the failing stage
5. story-local state under `.devflow/stories/<story_id>/`
6. streamed agent logs

If the story has `implementation_planning.json`, read it before calling the story under-specified or wrongly ordered.

## What counts as success

Only treat the lane as successful when:
- `story_queue.status = completed`
- the relevant run(s) finished successfully
- the story was advanced to implemented state
- the resulting repo/artifacts support the claim being made

## What counts as blockage

Treat these as blocked/problem states:
- `story_queue.status = blocked`
- churn state says `blocked_for_churn`
- failure disposition is `blocked_at_redreview`
- the wrapper run looks failed/stale even though the child run succeeded and reconciliation has not caught up
- the implementation kept editing the wrong seam

## Strong future tool candidates

- story queue row + child run correlation reader
- latest implementation transcript finder for a `story_id`
- churn-state explainer
- story-local artifact summary reader
- wrapper/child mismatch detector
