from __future__ import annotations

from pathlib import Path


# Prefer the package-local prompts dir (bundled into the wheel by
# hatch's force-include) so installed users find them; fall back to
# the repo-root copy for editable / dev installs where this file
# lives at <repo>/src/devflow_engine/agentic_prompts.py.
_REPO_ROOT = Path(__file__).resolve().parents[2]
_PACKAGE_PROMPTS_ROOT = Path(__file__).resolve().parent / "prompts"
_PROMPTS_ROOT = _PACKAGE_PROMPTS_ROOT if _PACKAGE_PROMPTS_ROOT.is_dir() else (_REPO_ROOT / "prompts")

_PROMPT_LAYOUT: dict[str, tuple[str, str]] = {
    "idea_response_doctrine": ("idea", "response_doctrine"),
    "idea_api_ideation_agent": ("idea", "api_ideation_agent"),
    "idea_api_insight_agent": ("idea", "api_insight_agent"),
    "idea_generic_response_agent": ("devin", "generic"),
    "idea_insight_response_agent": ("devin", "insight"),
    "idea_ideation_response_agent": ("devin", "ideation"),
    "idea_devin_ideation_agent_loop": ("devin", "ideation_loop"),
    "source_scope_doctrine": ("source_scope", "doctrine"),
    "scope_idea_doctrine": ("scope_idea", "doctrine"),
    "ui_grounding_doctrine": ("ui_grounding", "doctrine"),
    "implementation_dependency_assessment": ("implementation", "dependency_assessment"),
    "implementation_story_planning": ("implementation", "story_planning"),
    "implementation_test_design": ("implementation", "test_design"),
    "implementation_setupdoc": ("implementation", "setupdoc"),
    "implementation_red": ("implementation", "red"),
    "implementation_redreview": ("implementation", "redreview"),
    "implementation_redreview_repair": ("implementation", "redreview_repair"),
    "recovery_diagnosis": ("recovery", "diagnosis"),
    "recovery_preflight_health_repo_repair": ("recovery", "preflight_health_repo_repair"),
    "recovery_failure_investigation": ("recovery", "failure_investigation"),
    "recovery_root_cause_investigation": ("recovery", "root_cause_investigation"),
    "recovery_remediation_execution": ("recovery", "remediation_execution"),
    "recovery_execution": ("recovery", "execution"),
    "recovery_execution_verification": ("recovery", "execution_verification"),
    "source_doc_mutation_project_doc_render": ("source_doc_mutation", "project_doc_render"),
    "source_doc_mutation_product_brief": ("source_doc_mutation", "product_brief"),
    "source_doc_mutation_user_workflows": ("source_doc_mutation", "user_workflows"),
    "source_doc_mutation_domain_entities": ("source_doc_mutation", "domain_entities"),
    "source_doc_mutation_source_doc_coherence": ("source_doc_mutation", "source_doc_coherence"),
    "source_doc_mutation_source_doc_enrichment_coherence": ("source_doc_mutation", "source_doc_enrichment_coherence"),
    "source_doc_mutation_project_doc_coherence": ("source_doc_mutation", "project_doc_coherence"),
    "devin_eval_assessment": ("devin_eval", "assessment"),
    "source_doc_eval_document": ("source_doc_eval", "document"),
    "source_doc_eval_targeted_mutation": ("source_doc_eval", "targeted_mutation"),
}


def agentic_prompt_path(prompt_name: str) -> Path:
    direct = Path(prompt_name).expanduser()
    if direct.suffix.lower() == ".md":
        if not direct.is_absolute():
            direct = (_REPO_ROOT / direct).resolve()
        return direct
    try:
        group, agent_name = _PROMPT_LAYOUT[prompt_name]
    except KeyError as exc:
        raise KeyError(f"Unknown agentic prompt mapping: {prompt_name}") from exc
    return _PROMPTS_ROOT / group / agent_name / "prompt.md"


def load_agentic_prompt_markdown(prompt_name: str) -> str:
    return agentic_prompt_path(prompt_name).read_text(encoding="utf-8").strip()


def load_agentic_prompt_lines(prompt_name: str) -> list[str]:
    items = _parse_prompt_markdown(load_agentic_prompt_markdown(prompt_name))
    if not items:
        raise ValueError(f"Agentic prompt markdown is empty: {prompt_name}")
    return items


def load_agentic_prompt_text(prompt_name: str) -> str:
    return "\n".join(load_agentic_prompt_lines(prompt_name))


def _parse_prompt_markdown(markdown: str) -> list[str]:
    items: list[str] = []
    for raw_line in markdown.splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("- "):
            items.append(line[2:].strip())
            continue
        items.append(line)
    return items
