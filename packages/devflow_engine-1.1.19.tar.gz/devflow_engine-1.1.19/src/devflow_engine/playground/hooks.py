from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class PreflightResult:
    ok: bool
    message: str


def preflight(repo_root: Path) -> PreflightResult:
    # Minimal: verify .devflow exists.
    df = repo_root / ".devflow"
    if not df.exists():
        return PreflightResult(
            ok=False,
            message=".devflow not initialized. Run `devflow project init`.",
        )
    return PreflightResult(ok=True, message="ok")


def run_scenario(_name: str) -> None:
    # Placeholder hook for future integration.
    return
