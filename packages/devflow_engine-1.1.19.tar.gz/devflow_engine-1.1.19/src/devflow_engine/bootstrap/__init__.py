"""Bootstrap helpers for project initialization flows."""

