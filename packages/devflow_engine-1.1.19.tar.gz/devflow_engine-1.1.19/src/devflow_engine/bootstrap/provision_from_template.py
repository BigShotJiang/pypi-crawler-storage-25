from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

CLARIFY_COMMAND_REFERENCE = (
    "python3 <(gh api repos/Nuosis/clarify/contents/scripts/provision_from_template.py "
    "--jq '.content' | base64 -d)"
)
COPY_PROVISION_STRATEGY = "COPY_PROVISION_SCRIPT"
LOCAL_ONLY_UNTIL_APPROVED = "LOCAL_ONLY_UNTIL_APPROVED"


def _write(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def _slug(value: str) -> str:
    raw = re.sub(r"[^a-z0-9]+", "-", value.strip().lower()).strip("-")
    return raw or "python-backend"


def _pkg_name(value: str) -> str:
    raw = re.sub(r"[^a-z0-9]+", "_", value.strip().lower()).strip("_")
    return raw or "python_backend"


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Provision a deterministic Python backend scaffold.")
    parser.add_argument("--dest", required=True, type=Path)
    parser.add_argument("--project-name", required=True)
    args = parser.parse_args(argv)

    dest = args.dest.resolve()
    project_name = args.project_name.strip() or "Python Backend"
    slug = _slug(project_name)
    package_name = _pkg_name(project_name)

    _write(dest / "README.md", f"# {project_name}\n\nProvisioned via Clarify COPY/provision-script semantics.\n")
    _write(
        dest / "pyproject.toml",
        "\n".join(
            [
                "[project]",
                f'name = "{slug}"',
                'version = "0.1.0"',
                'requires-python = ">=3.11"',
                "",
                "[build-system]",
                'requires = ["hatchling"]',
                'build-backend = "hatchling.build"',
                "",
            ]
        ),
    )
    _write(dest / "src" / package_name / "__init__.py", "__all__ = []\n")
    _write(
        dest / "src" / package_name / "app.py",
        "def healthcheck() -> dict[str, str]:\n"
        "    return {\"status\": \"ok\"}\n",
    )
    _write(
        dest / ".devflow-backend-bootstrap.json",
        json.dumps(
            {
                "provisioning_strategy": COPY_PROVISION_STRATEGY,
                "clarify_command_reference": CLARIFY_COMMAND_REFERENCE,
                "backend_default_deploy_behavior": LOCAL_ONLY_UNTIL_APPROVED,
                "project_name": project_name,
                "package_name": package_name,
            },
            indent=2,
            sort_keys=True,
        )
        + "\n",
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
