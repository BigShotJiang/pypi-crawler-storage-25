from __future__ import annotations

"""Unified refactor runner.

Consumes a `devflow enforce` report (missing + directives) and asks an LLM to
produce a unified diff to fix the issues.

This intentionally does not attempt to be clever per-kind; it is one refactor
loop for packages + modules.
"""

import json
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .llm.cli_stream import run_streaming
from .llm.cli_one_shot import run_one_shot


def _extract_diff(text: str) -> str | None:
    # Prefer fenced ```diff blocks.
    if "```" in text:
        parts = text.split("```")
        for i in range(len(parts) - 1):
            body = parts[i + 1]
            lines = body.splitlines()
            if lines and lines[0].strip().lower() in {"diff", "patch"}:
                body = "\n".join(lines[1:])
            body = body.strip("\n")
            if body.startswith("diff --git"):
                return body + "\n"
    # Fallback: find first diff header.
    idx = text.find("diff --git")
    if idx != -1:
        return text[idx:].strip("\n") + "\n"
    return None


def _run(cmd: list[str], *, cwd: Path) -> subprocess.CompletedProcess[str]:
    return subprocess.run(cmd, cwd=str(cwd), text=True, capture_output=True, check=False)


def refactor_from_enforce_report(
    *,
    repo_root: Path,
    report: dict[str, object],
    base_cmd: str,
    delivery: str,
    stream: bool,
) -> dict[str, object]:
    prompt = {
        "task": "refactor_to_satisfy_devflow_enforce",
        "repo_root": str(repo_root),
        "enforce_report": report,
        "instructions": [
            "You must output ONLY a unified git diff (no commentary).",
            "Fix the enforce_report issues by refactoring code:",
            "- For refactor_internal_module: rewrite imports/specifiers to use the canonical module path.",
            "- For refactor_external_package: remove usage/imports of the forbidden package and migrate to the canonical one.",
            "- For missing imports: either remove the dependency or replace it with already-registered canonical pathways.",
            "Prefer small, safe edits.",
        ],
    }

    prompt_text = json.dumps(prompt, indent=2, sort_keys=True)

    if stream:
        sres = run_streaming(provider="cli", base_cmd=base_cmd, delivery=delivery, prompt=prompt_text, cwd=repo_root)
        if not sres.ok:
            return {"ok": False, "stderr": sres.stderr or sres.stdout, "stdout": sres.stdout, "log_path": sres.log_path}
        out_text = sres.stdout
    else:
        r = run_one_shot(base_cmd=base_cmd, delivery=delivery, prompt=prompt_text, cwd=repo_root)
        if not r.ok:
            return {"ok": False, "stderr": r.stderr or r.stdout, "stdout": r.stdout}
        out_text = r.stdout

    diff = _extract_diff(out_text)
    if not diff:
        return {"ok": False, "stderr": "LLM did not return a diff", "stdout": out_text}

    # Apply diff.
    patch_path = repo_root / ".devflow" / "refactor" / "last.patch"
    patch_path.parent.mkdir(parents=True, exist_ok=True)
    patch_path.write_text(diff, encoding="utf-8")

    cp = _run(["git", "apply", "--whitespace=nowarn", str(patch_path)], cwd=repo_root)
    if cp.returncode != 0:
        return {"ok": False, "stderr": cp.stderr, "stdout": cp.stdout, "patch": str(patch_path)}

    return {"ok": True, "patch": str(patch_path)}
