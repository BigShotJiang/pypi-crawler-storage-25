# Project-Doc Agent Contracts

## Purpose

This document defines the helper contracts for the planned project-doc mutation subagents and project-doc coherence node.

These are reference contracts for the LLM/runtime and supporting tests.

---

## Shared project-doc agent doctrine

Each project-doc mutation agent:
- owns one project-doc area
- reads the canonical source docs and the routed impact packet
- produces a rich, complete project-doc update for its assigned doc
- must not silently contradict source docs
- may elaborate and synthesize where appropriate
- must surface assumptions explicitly inside the document where relevant

Each project-doc mutation agent should output:
- `doc_payload_markdown`
- `source_doc_dependencies`
- `assumptions_used`
- `impact_rationale`
- `confidence_notes`

---

## 1. `ProjectCharterMutationAgent`

Owns:
- `project_charter.md`

Must answer:
- what are we building?
- why does it matter?
- who is it for?
- what are the goals/scope/boundaries?

Should be primarily grounded in:
- `product_brief.json`
- relevant assumptions

---

## 2. `PRDMutationAgent`

Owns:
- `prd.md`

Must answer:
- how is the product expected to behave?
- what user journeys and functional requirements matter?
- what alternates/exceptions are relevant?

Should be primarily grounded in:
- `product_brief.json`
- `user_workflows.json`
- relevant assumptions

---

## 3. `ArchitectureMutationAgent`

Owns:
- `architecture.md`

Must answer:
- what system shape is implied?
- what entities/relationships/integrations matter?
- what technical constraints and risks exist?

Should be primarily grounded in:
- `domain_entities.json`
- `product_brief.json`
- relevant assumptions

---

## 4. `UXDesignMutationAgent`

Owns:
- `ux_design.md`

Must answer:
- what are the key user flows?
- what screens/views/interactions are implied?
- what edge/error experiences matter?

Should be primarily grounded in:
- `user_workflows.json`
- `product_brief.json`
- relevant assumptions

---

## 5. `DeliveryPlanMutationAgent`

Owns:
- `delivery_plan.md`

Must answer:
- how should delivery be sequenced?
- what priorities/dependencies/risks exist?
- what should happen next?

Should be primarily grounded in:
- `product_brief.json`
- `user_workflows.json`
- `domain_entities.json`
- relevant assumptions

---

## `ProjectDocCoherenceNode`

Purpose:
- align the five project-doc outputs into one coherent doc family
- ensure consistent language, scope, assumptions, priorities, and constraints

Must check:
- charter aligns with PRD
- PRD aligns with UX and architecture
- architecture aligns with entities/workflows
- delivery plan aligns with scope/constraints/priorities
- assumptions do not materially conflict across docs

Output artifact suggestion:
- `project_doc_coherence_resolution.json`
