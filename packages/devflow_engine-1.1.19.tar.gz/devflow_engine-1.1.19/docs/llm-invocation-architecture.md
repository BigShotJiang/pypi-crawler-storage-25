# Unified LLM Invocation Architecture

## Goal

DevFlow Engine should converge on a single canonical LLM invocation surface inside DFE:

- one request model
- one invocation method
- one journaling/event bridge
- one policy point for provider selection, auth, prompt persistence, timeouts, and audit metadata

This is the migration target for "one ring to rule them all".

## Non-negotiables

- Canonical DFX worker is DFE-side only.
- Deprecated Clarity worker paths are not part of the target architecture.
- Source of truth for DFX event work is `devflow_execution_events`.
- Any worker-driven LLM action must be attributable back to the DFE worker/event/run lineage.

## Current State

The repo currently has multiple live LLM invocation seams:

1. CLI one-shot primitive: [`src/devflow_engine/llm/cli_one_shot.py`](/Users/devflow/repos/devflow_engine/src/devflow_engine/llm/cli_one_shot.py)
2. CLI streaming primitive: [`src/devflow_engine/llm/cli_stream.py`](/Users/devflow/repos/devflow_engine/src/devflow_engine/llm/cli_stream.py)
3. Current canonical agent seam for many DFE DAG nodes: [`src/devflow_engine/agentic_runtime.py`](/Users/devflow/repos/devflow_engine/src/devflow_engine/agentic_runtime.py)
4. Direct provider API exception for ideation/insight arm: [`src/devflow_engine/idea/agentic.py`](/Users/devflow/repos/devflow_engine/src/devflow_engine/idea/agentic.py)
5. Several direct bypasses that call `run_one_shot` or `run_streaming` without going through `run_agent_step`

That state is functional, but it is not a single invocation surface.

## Target Architecture

Introduce one canonical method:

`devflow_engine.llm.invoke.invoke_llm(request: LlmInvocationRequest) -> LlmInvocationResult`

## Migration Progress

Current hardening slice implemented:

- `src/devflow_engine/llm/invoke.py` now exists as the canonical one-shot CLI entrypoint
- `src/devflow_engine/llm/invoke.py` now centers canonical `delivery_model` and `interaction_model` fields
- `src/devflow_engine/llm/invoke.py` now supports `delivery_model="streaming"` by delegating to the existing `run_streaming(...)` transport and returning session/log metadata on the canonical result
- `src/devflow_engine/llm/invoke.py` now supports the first real API-backed execution path for `transport="api"`: Anthropic one-shot requests using shared provider HTTP machinery
- `src/devflow_engine/agentic_runtime.py` routes `run_agent_step(...)` and its JSON/schema repair retries through `invoke_llm(...)`
- `invoke_llm(...)` now validates request invariants up front, normalizes explicit CLI invocations, and reports response-contract metadata for `text` and `json_only`
- direct CLI bypasses still remain and should migrate in later slices

The request should own:

- first-class canonical execution semantics:
  - `delivery_model`: `final_only | streaming`
  - `interaction_model`: `request_response | agentic`
- explicit execution selectors:
  - `transport`: `cli | api`
  - `provider`: canonical provider family, currently intended to be one of `anthropic | openai | google | minimax | ollama`
  - `model`
- runtime selection fields retained for now:
  - `provider_mode`: `cli | provider_api | local_ultra_light`
- `purpose`: stable stage/task identifier
- `repo_root`
- `prompt_payload`
- `response_contract`
- `timeout_seconds`
- `strength`
- `event_context`
- `journal_context`
- `artifact_policy`

The result should own:

- resolved `transport/provider/model/delivery_model/interaction_model`
- normalized `ok/returncode/status`
- parsed structured response when applicable
- raw stdout/stderr or provider transcript
- session/log/journal paths
- provider/model metadata
- timing and retry metadata

## Supported After This Pass

What `invoke_llm(...)` currently supports:

- explicit canonical request/result fields for:
  - `transport`
  - `provider`
  - `model`
  - `delivery_model`
  - `interaction_model`
- `transport="cli"`
- `delivery_model="final_only"` for final-only execution
- `delivery_model="streaming"` for CLI-backed streaming execution, using the existing streaming log/journal machinery
- `transport="api"` with canonical provider-shape dispatch in one-shot mode:
  - Anthropic-shaped providers: `anthropic` is wired today via the shared Anthropic messages transport
  - `minimax` is recognized as Anthropic-shaped for canonical dispatch, but its provider-specific HTTP wiring is still intentionally pending
  - OpenAI-shaped providers: `openai`
  - Google-shaped providers: `google`
- `provider_mode="cli"` and `provider_mode="local_ultra_light"` remain supported for existing callers
- `provider_mode="provider_api"` now resolves to API transport and can reuse configured `llm_provider`
- config-driven CLI resolution
- explicit `base_cmd` + `delivery` override for callers that already resolved CLI transport elsewhere
- explicit `model` override for config-driven CLI and local ultra-light CLI requests
- explicit `model` override for wired API transports
- strength-aware model selection for config-driven CLI and local ultra-light invocations
- response contracts:
  - `None`: raw transport result only
  - `text`: marks the contract as satisfied for normal text responses
  - `json_only`: attempts JSON extraction/parsing, including fenced JSON, and reports `parsed_json`, `contract_ok`, and `contract_error`
- prompt fallback from `prompt_payload` when callers omit the serialized prompt string
- stream transport metadata on the result:
  - `session_id`
  - `log_path`

## `delivery_model` vs `interaction_model`

These fields answer different questions:

- `delivery_model` answers: "How is the result delivered back to the caller?"
  - `final_only`: return one completed result payload
  - `streaming`: stream output and return stream/session metadata
- `interaction_model` answers: "What kind of workflow is this call participating in?"
  - `request_response`: a normal ask-for-an-answer call
  - `agentic`: a delegated/tool-using/repair-loop step inside a larger workflow

Plain-language rule:

- use `delivery_model` for output shape and timing
- use `interaction_model` for caller intent and workflow semantics

That separation is why the old one-shot terminology was confusing. It mixed together:

- delivery behavior: "not streaming"
- workflow shape: "just give me one answer"

Those are not the same thing. A delegated agent step can still be `final_only`, and a normal request/response call can be `streaming`. The canonical fields replace that overloaded terminology with two independent decisions.

Canonical semantic mapping:

- `interaction_model="request_response"` means a direct prompt/response exchange where the caller is asking for one answer.
- `interaction_model="agentic"` means the call is part of a delegated agent step or repair loop owned by a higher-level workflow.
- `delivery_model="final_only"` means the canonical result is a completed response payload.
- `delivery_model="streaming"` means the canonical result is delivered through streaming transport and includes stream session metadata.

Avoid confusing these two similarly named fields:

- `delivery_model` is the user-visible response delivery semantic.
- `delivery` remains the low-level CLI prompt transport (`stdin` vs `argument`) used only when the resolved transport is CLI.

## Migration Guide

Use the canonical fields directly.

Final-only request/response call:

```python
LlmInvocationRequest(
    purpose="summarize_diff",
    repo_root=repo_root,
    prompt=prompt,
    delivery_model="final_only",
    interaction_model="request_response",
)
```

Streaming call:

```python
LlmInvocationRequest(
    purpose="live_refactor",
    repo_root=repo_root,
    prompt=prompt,
    delivery_model="streaming",
    interaction_model="request_response",
)
```

Agentic / delegated use:

```python
LlmInvocationRequest(
    purpose="agent_step",
    repo_root=repo_root,
    prompt=prompt,
    delivery_model="final_only",
    interaction_model="agentic",
)
```

In practice:

- old "final answer only" calls become `delivery_model="final_only"`
- old streaming calls become `delivery_model="streaming"`
- old "this is part of an agent/delegated workflow" intent moves to `interaction_model="agentic"`
- most plain prompt/response calls should set `interaction_model="request_response"`

What still remains:

- provider-specific HTTP wiring for Anthropic-shaped providers beyond Anthropic itself, including MiniMax
- API streaming
- centralized journaling, prompt/response artifact persistence, and retry metadata on the canonical result
- canonical JSON repair / schema-repair policy owned entirely inside `invoke_llm(...)`

Implemented vs scaffolded API matrix:

- Implemented:
  - `transport="api"`, `provider="anthropic"`, `delivery_model="final_only"`
  - `transport="api"`, `provider="openai"`, `delivery_model="final_only"`
  - `transport="api"`, `provider="google"`, `delivery_model="final_only"`
- Canonically recognized but not fully wired yet:
  - `transport="api"`, `provider="minimax"` uses the Anthropic-shaped interaction contract, but provider-specific HTTP wiring is still pending
- Scaffolded but not implemented yet:
  - `transport="api"` for `provider="ollama"`
  - `transport="api"` with `delivery_model="streaming"`

## Required Responsibilities Of The Canonical Method

`invoke_llm(...)` must be the only place that:

- resolves LLM config and provider selection
- applies model-strength policy
- decides CLI vs provider API transport
- writes LLM logs and journal rows
- stamps DFE run/node/event metadata
- performs JSON extraction/repair policy
- persists prompt/response artifacts for replay
- enforces timeout and retry policy

Everything else should become a thin prompt-building wrapper.

## Worker And Event Integration

For DFX-triggered work:

- the DFE event worker remains the only worker authority
- event intake starts from `devflow_execution_events`
- event metadata must flow into the invocation request as first-class context
- the invocation result must preserve enough metadata to correlate:
  - `event_id`
  - `run_id`
  - `node_exec_id`
  - `story_id`
  - `story_uuid`
  - `dag_id`
  - `repo_root`

This keeps worker ownership DFE-side and prevents drift back toward deprecated Clarity-worker semantics.

## Migration Rules

Allowed steady state:

- prompt-shaping wrappers call `invoke_llm(...)`
- wrappers may specify different output contracts or response modes

Not allowed in the target state:

- direct `run_one_shot(...)` calls outside the canonical invocation module
- direct `run_streaming(...)` calls outside the canonical invocation module
- direct provider HTTP calls outside the canonical invocation module
- worker code reaching around DFE event lineage

## Current Exceptions To Migrate

These are live today and should migrate into the canonical surface:

- ideation contract completion and route classification in [`src/devflow_engine/idea/devin_chat_dag.py`](/Users/devflow/repos/devflow_engine/src/devflow_engine/idea/devin_chat_dag.py)
- actor/story generation helpers in [`src/devflow_engine/idea/actors.py`](/Users/devflow/repos/devflow_engine/src/devflow_engine/idea/actors.py) and [`src/devflow_engine/idea/traditional_stories.py`](/Users/devflow/repos/devflow_engine/src/devflow_engine/idea/traditional_stories.py)
- story-plane adjudication in [`src/devflow_engine/idea/story_pipeline.py`](/Users/devflow/repos/devflow_engine/src/devflow_engine/idea/story_pipeline.py)
- ideation enrichment worker in [`src/devflow_engine/idea/ideation_enrichment.py`](/Users/devflow/repos/devflow_engine/src/devflow_engine/idea/ideation_enrichment.py)
- registry/refactor/error-solver command paths in [`src/devflow_engine/cli/app.py`](/Users/devflow/repos/devflow_engine/src/devflow_engine/cli/app.py) and [`src/devflow_engine/refactor.py`](/Users/devflow/repos/devflow_engine/src/devflow_engine/refactor.py)
- ideation/insight direct Anthropic API transport in [`src/devflow_engine/idea/agentic.py`](/Users/devflow/repos/devflow_engine/src/devflow_engine/idea/agentic.py)

## What Counts As Complete

The migration is complete when:

1. every live LLM call path is routed through one canonical method
2. the audit script reports no live direct-bypass paths
3. provider-specific transport exists only behind the canonical surface
4. DFX event-triggered invocations preserve DFE worker and `devflow_execution_events` lineage
