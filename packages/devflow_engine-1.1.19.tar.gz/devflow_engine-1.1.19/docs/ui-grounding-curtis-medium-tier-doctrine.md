# UI grounding follow-on note: Curtis medium-tier wireframe doctrine

Context: the recent Curtis wireframe pass surfaced a gap in the current `ui_grounding_dag` contract. The repo already does a solid first step for **surface derivation**, **reference inventory**, **Pencil preflight**, **gap reporting**, and **grounded story patching** (`src/devflow_engine/ui_grounding/dag.py`, `src/devflow_engine/ui_grounding/models.py`, `tests/area14_ui_grounding/*`). What it does **not** yet contract clearly is the minimum useful output level for customer-facing wireframe generation.

This note proposes the next contract layer so DFE can move from "surface exists / missing" into "surface packaged at the right fidelity for the right audience."

## What the Curtis pass taught us

1. A skeletal low-fi surface list is useful for internal orientation, but it is usually **not enough** for customer-facing review.
2. The system needs a durable, machine-readable **screen inventory artifact** so downstream generation/review steps are operating on the same set of surfaces.
3. "UI surface" is too weak as a classification. Curtis required stronger distinction between:
   - internal admin/web surfaces
   - field/tablet operational surfaces
   - customer secure-link / external portal surfaces
4. Generated wireframes need explicit **confidence** and **open-question** tagging so reviewers can quickly see which screens are solid vs inferred.
5. A customer review loop benefits from a packaged artifact set, not just one-off screens.

## Proposed contract addition

Add a post-grounding / pre-wireframe planning artifact such as:

- `.devflow/ideas/<idea_id>/pipelines/ui_grounding_dag/<run>/ui_screen_inventory.json`

This should sit conceptually beside:

- `ui_surface_derivation.json`
- `ui_reference_inventory.json`
- `ui_grounding_report.json`
- `grounded_story_reference_patch.json`

The intent is:

- `ui_surface_derivation.json` answers: **what surfaces seem to exist?**
- `ui_grounding_report.json` answers: **which are grounded vs missing?**
- `ui_screen_inventory.json` answers: **what exact screens/packages should be produced, at what fidelity, for whom, and with what uncertainty tags?**

## Proposed `ui_screen_inventory.json` shape

Example contract sketch:

```json
{
  "project_id": "proj_curtis",
  "idea_id": "idea_quotes_secure_link",
  "status": "ready_for_wireframe_generation",
  "default_minimum_fidelity": "medium",
  "primary_audience": "customer_review",
  "surfaces": [
    {
      "surface_id": "surface_01",
      "screen_id": "cust_quote_secure_link_summary",
      "name": "Customer quote review summary",
      "surface_class": "customer_secure_link",
      "platform": "web_mobile_responsive",
      "actor": "customer",
      "journey_stage": "review_and_approve_quote",
      "required": true,
      "source_refs": ["idea:idea_quotes_secure_link"],
      "grounding_refs": ["ui:file:app/quotes/approve/page.tsx"],
      "target_fidelity": "medium",
      "target_audience": "customer_review",
      "confidence": "medium",
      "open_questions": [
        "Should financing options appear before or after signature?"
      ],
      "notes": [
        "Use realistic content blocks and CTA hierarchy, not generic boxes."
      ]
    }
  ],
  "review_packet_outputs": [
    "wireframe_index.md",
    "customer_review_packet.json",
    "screen_comment_matrix.json"
  ]
}
```

## Fidelity + audience doctrine

The current DAG is mostly a grounding/gap detector. The follow-on planning contract should make fidelity explicit.

### Fidelity levels

- `low`
  - purpose: structure discovery, fast branching, internal concept sorting
  - acceptable output: rough layout, major blocks, navigation assumptions, missing info list
  - not enough for: default customer-facing wireframe review

- `medium`
  - purpose: minimum useful customer-facing wireframe generation
  - acceptable output:
    - recognizable page purpose
    - real section hierarchy
    - realistic labels and CTA placement
    - meaningful form/grouping decisions
    - state-aware notes where relevant
    - enough specificity for customer validation and story refinement
  - this should be the **default minimum** for customer-facing generation

- `high`
  - purpose: implementation handoff or polished stakeholder walkthrough
  - acceptable output:
    - stronger component detail
    - state variants
    - denser content realism
    - implementation-oriented annotations
  - not always required by default because it costs more and can imply false precision too early

### Audience targets

- `internal_exploration`
  - often allowed to stop at `low`
- `customer_review`
  - default minimum must be `medium`
- `implementation_handoff`
  - usually `medium` plus selected `high` detail on risky or ambiguous screens

## Default minimum behavior

For any run classified as **customer-facing wireframe generation**, the planner should default to:

- `primary_audience = customer_review`
- `default_minimum_fidelity = medium`

In other words: if the system knows it is preparing customer-consumable wireframes, it should not stop after skeletal low-fi structure unless the operator explicitly requests that mode.

Recommended rule:

- if `surface_class in {"customer_secure_link", "customer_portal", "admin_web", "field_tablet"}` and output is intended for customer/stakeholder review, generate at least `medium`
- low-fi-only output should require either:
  - explicit user request, or
  - an upstream discovery flag such as `exploratory_branching = true`

## When low-fi -> mid-fi is useful vs when to start at mid-fi

### Use low-fi first, then mid-fi when:

- the workflow is still ambiguous and multiple route structures are plausible
- the team is comparing major IA / flow options
- the surface count is large and a quick breadth-first pass is needed
- the repo/requirements are under-grounded and unresolved questions dominate
- the reviewer explicitly wants concept sorting before detail

In these cases low-fi should be treated as a **staging step**, not the finish line.

### Start directly at mid-fi when:

- the surface is customer-facing and likely to be shown outside the product team
- the flow already has strong business grounding from idea/story/spec inputs
- the goal is validation of wording, hierarchy, CTA sequence, approval states, or trust signals
- the system is packaging a reviewable wireframe set rather than just discovering possible screens
- the cost of customer confusion from overly skeletal artifacts is higher than the cost of extra generation effort

That last bullet describes most Curtis-style review packets.

## Stronger surface classification

The current models already track `actor`, `surface_id`, and grounding references. The Curtis pass suggests the next artifact should promote an explicit `surface_class` / `channel_class` field, for example:

- `admin_web`
  - desktop-first internal coordination, scheduling, reporting, back-office workflow
- `field_tablet`
  - technician/crew operational surfaces, touch targets, intermittent attention, job-site use
- `customer_secure_link`
  - link-based review/approval/payment surfaces with trust and clarity demands
- `customer_portal`
  - authenticated ongoing customer account area
- `internal_support_tool`
  - support/CSR workflows not exposed to customers

Why this matters:

- fidelity defaults differ by surface class
- trust/clarity expectations differ by surface class
- layout assumptions differ sharply between admin desktop vs field tablet vs external secure-link screens

Recommended default mapping:

- `customer_secure_link` => start at `medium`
- `field_tablet` => start at `medium`
- `admin_web` => low or medium depending on audience, but `medium` for stakeholder review
- `internal_support_tool` => low acceptable for exploration, medium for committed review

## Confidence and unresolved-question tagging

The repo already carries `confidence` on `DerivedUISurface` and `unresolved_questions` on `UIGroundingSurfaceResult`. The follow-on artifact should preserve and tighten that discipline at the screen level.

For each generated screen/package item, include:

- `confidence`: `high | medium | low`
- `confidence_reason`: why the screen is well-grounded or speculative
- `open_questions`: explicit unanswered design/business questions
- `assumption_tags`: short machine-readable assumptions, e.g.
  - `assume_signature_required`
  - `assume_photo_upload_optional`
  - `assume_tablet_landscape_primary`

Rule of thumb:

- low confidence should never be hidden behind polished artifacts
- unresolved questions should travel with the generated screen, not be buried in a summary blob

## Customer review packet outputs

For Curtis-like customer review flows, the generation path should be able to emit a small packet rather than a single artifact.

Suggested packet outputs:

- `customer_review_packet.json`
  - machine-readable package manifest
- `wireframe_index.md`
  - screen list, order, rationale, and what feedback is needed
- `screen_comment_matrix.json`
  - per-screen feedback slots / review prompts
- `screen_inventory_snapshot.json`
  - frozen copy of `ui_screen_inventory.json` used to drive generation
- `wireframe_package/` or equivalent
  - actual generated frames/images/Pencil exports

Optional additions:

- `review_agenda.md`
- `known_unknowns.md`
- `customer_walkthrough_order.json`

## Suggested DAG evolution

A sensible next step without rewriting the current area14 flow:

1. keep existing area14 grounding contract intact
2. add a new planner node after grounding success or partial grounding review:
   - `PlanWireframeOutputNode`
3. emit `ui_screen_inventory.json`
4. use that inventory to drive Pencil / wireframe generation
5. emit a customer review packet when `primary_audience = customer_review`

Conceptually:

```text
Load context
-> Derive UI surfaces
-> Inventory existing refs
-> Match refs / gap report
-> Optional code->design enrichment
-> Plan wireframe output (NEW)
-> Generate wireframe package (future)
-> Patch story/idea refs + finalize
```

## Concrete implementation direction for this repo

Short-term changes that fit current repo structure:

- extend `src/devflow_engine/ui_grounding/models.py` with a `UIScreenInventoryArtifact` model and per-screen item model
- keep `UIGroundingReportArtifact` focused on grounding truth, not presentation planning
- let the new screen inventory artifact carry:
  - `surface_class`
  - `target_fidelity`
  - `target_audience`
  - `confidence`
  - `open_questions`
  - `review_packet_outputs`
- preserve existing tests in `tests/area14_ui_grounding/` and add new ones around:
  - medium default for customer-facing surfaces
  - low-fi staging allowed only when explicitly requested / discovery mode
  - secure-link vs admin vs tablet classification
  - confidence/open-question propagation

## Decision statement

For DFE customer-facing wireframe generation, the default minimum useful output should be **medium-tier**, not skeletal low-fi.

Low-fi remains valid as an internal staging technique, but it should be a deliberate step in the pipeline, not the silent default endpoint.
