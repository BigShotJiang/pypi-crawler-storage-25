# Source-to-Project-Doc Impact Map

## Purpose

This reference defines how changes in canonical source-doc sections should map to downstream project-doc mutation work.

This is intended for the planned deterministic routing node that identifies impacted project-doc areas and spawns asynchronous project-doc mutation work.

---

## Doctrine

- Source docs are canonical.
- Project docs are derived.
- Project-doc mutation should be targeted, not full-regeneration by default.
- A change in a source-doc section should map to one or more impacted project-doc areas.
- Downstream project-doc mutation workers may run asynchronously and need not be awaited by the source-doc mutation DAG.

---

## High-level project-doc areas

Suggested project-doc areas:
- `project_charter`
- `prd`
- `architecture`
- `design`
- `delivery_plan`
- `user_stories` / story-planning artifacts

---

## Mapping reference

### `product_brief.product_summary`
Impacts:
- `project_charter`
- `prd`

### `product_brief.problem_statement`
Impacts:
- `project_charter`
- `prd`
- possibly `design` if UX motivation shifts materially

### `product_brief.target_users`
Impacts:
- `prd`
- `design`
- `user_stories`

### `product_brief.goals`
Impacts:
- `project_charter`
- `prd`
- `delivery_plan`

### `product_brief.scope`
Impacts:
- `prd`
- `delivery_plan`
- `user_stories`

### `product_brief.non_goals`
Impacts:
- `project_charter`
- `prd`
- `delivery_plan`

### `product_brief.constraints`
Impacts:
- `architecture`
- `design`
- `delivery_plan`
- `prd`

### `product_brief.success_criteria`
Impacts:
- `project_charter`
- `prd`
- `delivery_plan`

### `user_workflows.actors`
Impacts:
- `prd`
- `design`
- `user_stories`

### `user_workflows.primary_workflows`
Impacts:
- `prd`
- `design`
- `user_stories`
- possibly `architecture` if workflow shape implies system behaviors

### `user_workflows.alternate_flows`
Impacts:
- `prd`
- `design`
- `user_stories`

### `user_workflows.edge_cases`
Impacts:
- `design`
- `architecture`
- `user_stories`

### `domain_entities.entities`
Impacts:
- `architecture`
- `prd`
- `user_stories`

### `domain_entities.relationships`
Impacts:
- `architecture`
- `design`
- `user_stories`

### `domain_entities.ownership_assumptions`
Impacts:
- `architecture`
- `prd`

---

## Routing output shape

Suggested deterministic routing artifact:
- `project_doc_impact_routing.json`

Containing:
- changed source-doc sections/topics
- impacted project-doc areas
- downstream mutation task specs
- whether a full refresh is warranted or only targeted mutation

---

## Important note

This mapping is an implementation helper/reference. It should be refined as the actual project-doc contracts become more explicit.
