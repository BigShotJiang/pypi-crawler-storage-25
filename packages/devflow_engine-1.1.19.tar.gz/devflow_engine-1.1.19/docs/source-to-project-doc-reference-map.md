# Source-to-Project-Doc Reference Map

## Purpose

This document provides a stronger cross-reference map from canonical source-doc sections to the project docs they should inform, enrich, or mutate.

It is intended to support:
- deterministic project-doc impact routing
- project-doc mutation agent grounding
- coherence checks
- acceptance tests

---

## Canonical source docs
- `product_brief.json`
- `user_workflows.json`
- `domain_entities.json`
- `assumptions_registry.json`

## Project-doc family
- `project_charter.md`
- `prd.md`
- `architecture.md`
- `ux_design.md`
- `delivery_plan.md`

---

## Mapping by source section

### `product_brief.product_summary`
Primary downstream docs:
- `project_charter.md`
- `prd.md`

### `product_brief.problem_statement`
Primary downstream docs:
- `project_charter.md`
- `prd.md`
- `delivery_plan.md` (priority framing)

### `product_brief.target_users`
Primary downstream docs:
- `project_charter.md`
- `prd.md`
- `ux_design.md`

### `product_brief.goals`
Primary downstream docs:
- `project_charter.md`
- `prd.md`
- `delivery_plan.md`

### `product_brief.scope.in_scope`
Primary downstream docs:
- `project_charter.md`
- `prd.md`
- `delivery_plan.md`

### `product_brief.scope.out_of_scope`
Primary downstream docs:
- `project_charter.md`
- `prd.md`
- `delivery_plan.md`

### `product_brief.non_goals`
Primary downstream docs:
- `project_charter.md`
- `prd.md`
- `delivery_plan.md`

### `product_brief.constraints`
Primary downstream docs:
- `architecture.md`
- `ux_design.md`
- `delivery_plan.md`
- `prd.md`

### `product_brief.success_criteria`
Primary downstream docs:
- `project_charter.md`
- `prd.md`
- `delivery_plan.md`

---

### `user_workflows.actors`
Primary downstream docs:
- `prd.md`
- `ux_design.md`

### `user_workflows.primary_workflows`
Primary downstream docs:
- `prd.md`
- `ux_design.md`
- `delivery_plan.md`
- `architecture.md` where system behavior is materially implied

### `user_workflows.alternate_flows`
Primary downstream docs:
- `prd.md`
- `ux_design.md`
- `architecture.md`

### `user_workflows.edge_cases`
Primary downstream docs:
- `prd.md`
- `ux_design.md`
- `architecture.md`
- `delivery_plan.md` where risk/priority is affected

### `user_workflows.workflow_assumptions`
Primary downstream docs:
- `prd.md`
- `ux_design.md`
- `delivery_plan.md`

---

### `domain_entities.entities`
Primary downstream docs:
- `architecture.md`
- `prd.md`

### `domain_entities.relationships`
Primary downstream docs:
- `architecture.md`
- `ux_design.md`
- `prd.md`

### `domain_entities.ownership_assumptions`
Primary downstream docs:
- `architecture.md`
- `prd.md`
- `delivery_plan.md`

---

### `assumptions_registry.assumptions`
Primary downstream docs:
- all project docs as needed

Rule:
- assumptions should not dominate every project doc
- but where an assumption materially shapes the document, it should be reflected explicitly

---

## Routing guidance

For deterministic routing, each source-doc change should emit:
- changed doc
- changed section
- changed topic(s)
- directly impacted project docs
- second-order impacted project docs if applicable

Suggested artifact:
- `project_doc_impact_routing.json`
