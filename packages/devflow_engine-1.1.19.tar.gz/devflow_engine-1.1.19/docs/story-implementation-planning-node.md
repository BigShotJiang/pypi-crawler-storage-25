# StoryImplementationPlanningNode

## Purpose

`StoryImplementationPlanningNode` is a **per-story planning/gating node** that runs immediately before downstream implementation nodes and decides whether a story is:

- ready for implementation
- must wait behind another story
- needs a prerequisite story created
- blocked

It does **not** write code.
It does **not** directly import/install/register dependencies in implementation files.
It produces durable planning artifacts that downstream nodes must obey.

## Placement in implementation DAG

```text
LoadStoryContext
  -> StoryImplementationPlanningNode
  -> StoryImplementationPlanningRouter
      -> READY_FOR_IMPLEMENTATION   -> TestDesign -> Red -> Green -> GitCommit(GREEN) -> Refactor -> VerifyGreen -> GitCommit(REFACTOR)
      -> WAITING_FOR_PROVIDER_STORY -> RequeueStory
      -> CREATE_PREREQUISITE_STORY  -> RegisterPrerequisiteAndRequeue
      -> BLOCKED                    -> MarkBlocked / Escalate
```

This node belongs **after story/context load and before `TestDesign` / `Red`**.

## Core doctrine

1. **Per-story, not repo-wide**
   - evaluates only the current story in current repo state
2. **Planning/gating only**
   - informs downstream work
   - does not implement
3. **Prefer existing canonical pathways**
   - reuse existing registered/canonical providers/packages/pathways whenever possible
4. **Registry-aware, not registry-mutating**
   - reviews registry state
   - if something truly new is needed, records that downstream implementation must register/canonicalize it or commit enforcement will fail
   - does not perform that registration itself
5. **Infer dependencies when story metadata is thin**
   - especially on first pass when dependencies are absent
6. **Resolve missing internal capabilities through stories**
   - if an existing story likely provides it → queue after that story
   - if none exists → create prerequisite story and queue after it
   - if unresolved → block clearly
7. **Downstream nodes must treat this as contract**
   - `TestDesign`, `Red`, `Green`, `GitCommit` consume this node’s outputs explicitly

## Node types

### `StoryImplementationPlanningNode` → `AgentNode`
Use a real model-backed node for:
- inferring implicit dependencies from story intent
- judging canonical reuse vs true missing capability
- identifying likely provider story
- drafting prerequisite-story proposal when needed

### `StoryImplementationPlanningRouter` → deterministic `RouterNode`
Branch only from explicit artifact state:
- `ready_for_implementation`
- `waiting_for_provider_story`
- `create_prerequisite_story`
- `blocked`

### Persistence / queue mutation nodes → deterministic `Node`
Examples:
- `RegisterPrerequisiteStoryNode`
- `RequeueStoryNode`
- `MarkStoryBlockedNode`

## Inputs

Minimum required:
- current story artifact
- story backlog / story registry snapshot
- registry / canonical provider state snapshot
- repo root / repo context

Suggested typed input:

```ts
type StoryImplementationPlanningInput = {
  repo_root: string
  story_id: string
  story_artifact: {
    id: string
    title: string
    summary?: string
    description?: string
    acceptance_criteria?: string[]
    existing_dependencies?: {
      internal_story_ids?: string[]
      external_dependencies?: string[]
      capabilities?: string[]
    }
    status?: string
  }
  story_queue_snapshot: {
    queued_story_ids: string[]
    in_progress_story_ids: string[]
    completed_story_ids: string[]
    blocked_story_ids?: string[]
  }
  story_registry_snapshot: {
    stories: Array<{
      id: string
      title: string
      status: string
      summary?: string
      capability_hints?: string[]
    }>
  }
  registry_snapshot: {
    canonical_packages?: Array<{ name: string; purpose?: string }>
    canonical_providers?: Array<{ name: string; purpose?: string }>
    canonical_pathways?: Array<{ key: string; path: string; purpose?: string }>
    enforcement_mode?: string
  }
  repo_context: {
    relevant_modules?: string[]
    architecture_docs?: string[]
    source_doc_refs?: string[]
  }
}
```

## Primary output artifact

Prefer sidecar over story-schema redesign:

```text
.devflow/stories/<story_id>/implementation_planning.json
```

Suggested shape:

```json
{
  "story_id": "story_123",
  "planning_status": "ready_for_implementation",
  "planning_generated_at": "2026-03-22T22:33:00Z",
  "mode": "model_backed",
  "inferred_capabilities": [],
  "dependency_findings": {
    "internal": [],
    "external": [],
    "registry_expectations": []
  },
  "queue_decision": {
    "state": "ready_for_implementation",
    "queue_after_story_id": null,
    "requeue_recommendation": false
  },
  "blocking_issues": [],
  "downstream_contract": {
    "test_design_must_assume": [],
    "red_must_not_do": [],
    "green_must_honor": [],
    "git_commit_must_verify": []
  },
  "lineage": {
    "source_story_path": ".devflow/stories/story_123/story.json"
  }
}
```

Optional companion when needed:

```text
.devflow/stories/<story_id>/prerequisite_story_request.json
```

for:
- proposed title
- rationale
- missing capability
- dependent story linkage

## Branch outcomes

### `READY_FOR_IMPLEMENTATION`
Use when:
- dependencies are satisfied, or
- required external/internal canon already exists, and
- no prerequisite story is needed

Effect:
- continue to `TestDesign`

### `WAITING_FOR_PROVIDER_STORY`
Use when:
- a missing internal capability appears to be owned by an existing story

Effect:
- queue current story after provider story
- stop before `TestDesign`

### `CREATE_PREREQUISITE_STORY`
Use when:
- a real missing internal capability exists
- no existing story covers it
- enough evidence exists to define a prerequisite story safely

Effect:
- create/register prerequisite story artifact
- link dependency
- queue current story after it
- stop before `TestDesign`

### `BLOCKED`
Use when:
- unresolved registry/compliance conflict
- ambiguous provider ownership
- insufficient context
- external dependency unapproved / unresolved

Effect:
- mark blocked
- persist blocker artifact
- stop downstream flow

## Downstream node contracts

### `TestDesign`
Must read `implementation_planning.json` and:
- design tests only for the current story’s valid implementation envelope
- avoid designing tests that assume unresolved prerequisites already exist
- respect registry expectations when framing interfaces/contracts

### `Red`
Must:
- fail on the actual story delta, not on known unmet prerequisite work
- avoid inventing workaround paths that bypass canonical registry expectations
- avoid creating tests that pressure `Green` into heretical imports/pathways

### `Green`
Must:
- implement only within the planning packet’s allowed envelope
- prefer existing canonical providers/packages/pathways named in `registry_expectations`
- if a new dependency/provider is required, ensure downstream implementation performs the required registration/canonicalization work before commit viability is claimed

### `GitCommit(GREEN)` / `GitCommit(REFACTOR)`
Must:
- treat `registry_expectations` as preconditions for successful `devflow enforce`
- expect commit enforcement to fail if required canonicalization/registration was ignored
- use planning output as the explanation layer for why enforce failure was predictable

## Minimal metadata additions

Prefer sidecars, but if needed add only lightweight story metadata such as:
- `dependency_status`
- `dependency_plan_ref`
- `blocked_by_story_ids`

Do **not** redesign the core story schema.

## Practical v1 behavior

### External
- check registry for canonical candidate
- if found: record that downstream must use it
- if not found: record that downstream must register/canonicalize a new dependency/provider or commit enforcement will fail

### First pass, no dependencies listed
- infer missing dependencies/capabilities
- persist them on story-side artifacts
- scan for existing provider story
- if found: queue current story after it
- if not found: create prerequisite story and queue after it

### Otherwise
- mark blocked
- write clear blocker artifact
