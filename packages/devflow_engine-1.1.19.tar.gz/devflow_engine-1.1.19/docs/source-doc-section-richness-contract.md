# Source-Doc Section Richness Contract

## Purpose

This document defines what each canonical source-doc section must answer in order to count as **rich and deep** rather than thin scaffolding.

It is intended to be used by:
- source-doc section agent nodes
- coherence/cross-section review nodes
- downstream quality gates
- acceptance tests

Source docs are canonical under:
- `ai_docs/context/source_docs/`

Canonical files:
- `product_brief.json`
- `user_workflows.json`
- `domain_entities.json`
- `assumptions_registry.json`

---

## Global doctrine

For every section:
- capture what is explicitly supported by user input, code, docs, or existing artifacts
- fill missing required depth with explicit assumptions when necessary
- do not leave sections half-baked when the contract expects a complete planning surface
- do not silently present assumptions as explicit fact
- section output must be useful enough to support downstream project-doc generation

Each section should be evaluated against:
1. **coverage** — did it answer the section’s required questions?
2. **depth** — is the content substantial, not just a label?
3. **specificity** — is it concrete enough to be useful?
4. **traceability** — are assumptions identifiable as assumptions?
5. **consistency** — does it align with other sections?

---

# `product_brief.json`

## `product_summary`
Must answer:
- what is the product/system?
- who is it for?
- what primary outcome does it create?

Rich/deep standard:
- includes product type or operating shape
- identifies the primary user/operator group
- states the main value/outcome
- ideally states the context in which it is used

Thin if:
- generic one-liner with no actor or outcome

## `problem_statement`
Must answer:
- what pain/problem exists now?
- what friction/failure/manual burden is being addressed?
- why it matters operationally/business-wise?

Rich/deep standard:
- names current-state pain concretely
- ties the pain to a user/workflow context
- explains why the problem matters

Thin if:
- only says “needs a better system” or equivalent vagueness

## `target_users`
Must answer:
- who uses it directly?
- who benefits indirectly?
- who administers or oversees it?

Rich/deep standard:
- distinguishes primary vs secondary roles where relevant
- role names are specific enough to matter to workflow design
- aligns with actors in `user_workflows.json`

Thin if:
- generic labels like `users` or `staff` with no breakdown

## `goals`
Must answer:
- what outcomes should improve?
- what business or operational result is desired?

Rich/deep standard:
- outcome-oriented, not just feature-oriented
- usually includes multiple goal dimensions when appropriate
- clear enough to derive success criteria later

Thin if:
- feature list disguised as goals

## `scope.in_scope`
Must answer:
- what capabilities/flows are in the intended solution or release?

Rich/deep standard:
- enough detail to anchor workflows and stories
- capability statements are concrete, not just nouns
- bounded enough to distinguish from non-goals/out-of-scope

Thin if:
- only one or two vague bullets

## `scope.out_of_scope`
Must answer:
- what is explicitly excluded for now?

Rich/deep standard:
- meaningful exclusions that reduce ambiguity and scope creep

Thin if:
- empty despite an otherwise substantial product definition

## `non_goals`
Must answer:
- what adjacent problems are not being solved?
- what is not being optimized for?

Rich/deep standard:
- usefully constrains interpretation and expansion

Thin if:
- absent when the solution space is broad

## `constraints`
Must answer:
- what technical, business, compliance, operational, timeline, or platform limits apply?

Rich/deep standard:
- includes real limiting factors if known or reasonably assumed
- constraints are specific enough to affect solution shape

Thin if:
- absent despite obvious context that implies limits

## `success_criteria`
Must answer:
- how will we know the solution worked?
- what observable outcomes indicate success?

Rich/deep standard:
- measurable or clearly observable
- maps back to goals/problem statement

Thin if:
- just restates goals without validation framing

## `assumptions`
Must answer:
- what product-level assumptions were required to make this section complete?

Rich/deep standard:
- assumptions are specific and actionable
- assumptions are traceable to real gaps

---

# `user_workflows.json`

## `actors`
Must answer:
- who participates in workflows?

Rich/deep standard:
- aligns with target users
- distinguishes roles with meaningfully different behavior

Thin if:
- actor list is generic or obviously incomplete relative to workflows

## `primary_workflows`
Must answer:
- what are the main user jobs/processes?
- how do they progress from trigger to completion?

Rich/deep standard:
Each workflow should make clear:
- trigger
- actor
- key steps
- important decision points
- outputs/results
- happy path

Thin if:
- workflow names only, with no flow shape

## `alternate_flows`
Must answer:
- what important variants/branches exist?

Rich/deep standard:
- captures meaningful non-primary cases
- reflects reassignment, exception, role-variant, approval, or channel variation when relevant

Thin if:
- absent despite obvious branch points

## `edge_cases`
Must answer:
- what goes wrong or becomes non-standard?

Rich/deep standard:
- captures operationally relevant exceptions and failure conditions

Thin if:
- empty despite non-trivial workflow complexity

## `workflow_assumptions`
Must answer:
- what workflow-level assumptions were required to make workflows rich and complete?

Rich/deep standard:
- specific assumptions tied to missing steps/branches/rules

---

# `domain_entities.json`

## `entities`
Must answer:
- what are the core business objects?
- what do they represent?
- why do they matter?

Rich/deep standard:
For each entity, enough detail exists to understand:
- purpose
- structured attributes/fields if known (name + type/required-ness when practical)
- lifecycle hints if relevant
- relation to workflows
- integrity/business/authority rules when those shape the model
- unresolved/model questions when sparse input leaves important gaps

Thin if:
- just a noun list with no semantics
- relationship-shaped concepts are emitted as pseudo-entities without clarifying whether they are records vs views/projections

## `relationships`
Must answer:
- how do entities relate to one another?
- what ownership/linkage/dependency exists?

Rich/deep standard:
- enough relationship definition exists to inform design and workflow reasoning
- relationship records carry cardinality and rule/authority hints when those are material
- projections/views are modeled explicitly as derived shapes rather than confused with source-of-truth entities

Thin if:
- entities exist but relationship model is absent

## `ownership_assumptions`
Must answer:
- what ownership/data-authority assumptions were needed?

Rich/deep standard:
- clarifies unresolved responsibility/visibility/tenancy assumptions

---

# `assumptions_registry.json`

## `assumptions`
Each assumption must answer:
- what is being assumed?
- where does it apply?
- why is the assumption reasonable?
- what evidence informed it?
- how confident are we?
- what is its current lifecycle status?

Minimum fields:
- `assumption_id`
- `status`
- `confidence`
- `source`
- `impact`
- `doc_path`
- `section_key`
- `topic_key`
- `current_value`
- `reason` / `reasoning`
- `affected_docs`
- `affected_sections`
- `linkage`
- `last_updated_from_message_id`

Rich/deep standard:
- assumptions are precise, localizable, and reviewable
- assumptions do not masquerade as explicit facts
- status semantics distinguish unresolved, confirmed, rejected, superseded, and stale assumptions rather than collapsing everything into a generic resolved state

---

## Cross-document completion standard

To count as rich and deep source docs overall:
- product, workflows, and entities align
- assumptions are explicit where gaps were filled
- source docs are detailed enough to support full project-doc generation
- a reviewer can tell what is known vs inferred without guessing
