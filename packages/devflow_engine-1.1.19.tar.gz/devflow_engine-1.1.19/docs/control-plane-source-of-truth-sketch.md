# DevFlow control plane + source-of-truth sketch

## Purpose
A short working sketch for how DevFlow Engine should relate to the shared control plane and frontend.

## Core rule
There should not be two sources of truth for execution.

Use this split:
- **DevFlow Engine SQLite** = authoritative execution runtime + authoritative execution event history
- **Supabase shared tables** = planning/control-plane state plus mirrored execution projections for UI/realtime consumption

## Plane responsibilities

### 1. DevFlow Engine / executor plane
Authoritative for:
- execution runs
- execution stages
- execution artifacts
- execution event history
- local worker/runtime bookkeeping

Storage:
- local SQLite inside DevFlow Engine

Important rule:
- execution events originate here first
- shared systems should mirror/project from this plane rather than invent parallel execution truth

### 2. Shared control plane
Authoritative for:
- project registry / metadata
- change requests / requested work
- planning and chat messages
- shared read models used by frontend

Likely tables:
- `devflow_projects`
- `change_requests`
- `agent_agent_messages`
- shared execution-event mirror table
- `devflow_state`

Important rule:
- this plane decides what work should happen
- it does not replace engine-local execution authority

## Table roles

### `devflow_projects`
Shared registry of DevFlow-managed projects.

Use for:
- project identity
- repo metadata
- preview/deploy metadata
- operator-visible project registration

Not for:
- detailed execution progress truth

### `change_requests`
Control-plane intake for requested work.

Use for:
- repo investigation
- ideation requests
- story generation requests
- execution requests
- review/fix requests

This is the control-plane "what should happen" table.

### `agent_agent_messages`
Planning/chat plane.

Use for:
- chat with Devin
- clarification loops
- ideation results
- approvals
- execution handoff messages

This is not the execution progress ledger.

### shared execution-event mirror table
Append-only shared mirror of execution facts originating from engine-local SQLite.

Use for:
- realtime subscriptions
- timeline/event inspection
- projection into `devflow_state`

Important rule:
- mirror from engine execution events
- do not let the shared table become a second independently-authored execution history

### `devflow_state`
Shared projection/read model for frontend use.

Use for:
- current status
- current stage
- active run id
- worker identity
- latest error summary
- latest artifact summary
- dashboard hydration

Important rule:
- derived from execution events
- not directly hand-mutated as workflow truth

## Registration workflow placement
Project registration should be treated as a real DevFlow Engine workflow, not an ad hoc frontend side effect.

GenAI DAG doctrine for this workflow:
- keep project-shell creation deterministic
- keep repo/workspace binding deterministic
- use GenAI only if a later registration phase must interpret ambiguous source material or thin intake text
- make approval/binding boundaries explicit
- persist durable registration artifacts instead of hiding state in transient UI logic
- execute the workflow as a real Engine DAG with explicit node attempts, artifact refs, and run failure states in `execution.sqlite`

Recommended registration states:
1. `draft_unbound` — control-plane shell exists in `devflow_projects`
2. `binding_requested` — frontend/operator is attaching or creating repo/workspace
3. `engine_registered` — DevFlow Engine has run the registration workflow / `project init` / `project import`
4. `ready_for_source_scope` — project can enter the planning happy path

## Sync rule
Keep the planes in sync with a one-way execution flow:

1. control plane creates or updates the project shell
2. project registration workflow reaches DevFlow Engine
3. DevFlow Engine executes authoritative registration/runtime steps locally
4. DevFlow Engine records authoritative execution events locally
5. those events are mirrored to shared infra
6. `devflow_state` is projected from mirrored execution events
7. frontend reads/subscribes to shared projections and shared mirrored events

## Source-of-truth summary
- **project truth:** `devflow_projects`
- **planning truth:** `agent_agent_messages` + `change_requests`
- **execution truth:** DevFlow Engine local SQLite
- **shared execution visibility:** mirrored event table
- **frontend current-state view:** `devflow_state`

## Current recommendation
For now:
- keep authoritative execution events inside DevFlow Engine SQLite
- do not move execution authority into Supabase yet
- add shared mirrored execution events + `devflow_state` for frontend/control-plane visibility

## Existing precedent: runtime error solving control plane
A good working example already exists in Clarity's runtime-error solving pipeline.

That control plane already uses this general pattern:
- shared DB intake/state (`runtime_errors`)
- worker-driven execution
- generic execution/event tracking (`events`, `task_executions`, `task_execution_steps`)
- selected/claimed/resolved/blocked lifecycle handling

Why it matters:
- this proves the control-plane -> worker -> execution-tracking shape already works operationally
- DevFlow should copy the architectural pattern, while using DevFlow-specific tables and projections
- the runtime-error plane is the right comparison point when deciding how much state belongs in shared infra vs executor-local runtime

## Reason
This keeps execution coherent and local while still giving the frontend the event-driven shared plane it needs.
