# Source-Doc Section Agent Contracts

## Purpose

This document defines the source-section agent contracts inside the canonical `source_doc_mutation_dag` Marcus specified.

Required enclosing architecture:
1. `NormalizeAndGatherSupportContextNode`
2. parallel source section agents:
   - `ProductBriefSectionAgentNode`
   - `UserWorkflowsSectionAgentNode`
   - `DomainEntitiesSectionAgentNode`
3. `SourceDocCoherenceNode`
4. `SourceDocEnrichmentCoherenceNode`
5. `PersistSourceDocsAndAssumptionsNode`
6. `ProjectDocImpactRoutingNode`
7. `SpawnProjectDocMutationSubagentsNode`
8. `AwaitProjectDocMutationSubagentsNode`
9. `ProjectDocCoherenceNode`
10. `PersistProjectDocsNode`

Status honesty:
- this is the required contract for the current `source_doc_mutation_dag`
- the checked-in runtime has not fully landed this graph yet
- these contracts must not be read as evidence that helper substitutes or the old deterministic chain are acceptable

---

## Shared agent doctrine

Each section agent is responsible only for its owned source-doc contract.

Each section agent must:
1. consume the normalized source/support context prepared by `NormalizeAndGatherSupportContextNode`
2. inspect the bounded evidence packet provided upstream
3. identify explicit facts relevant to its section
4. fill required missing depth using grounded assumptions sourced from:
   - existing code
   - existing docs
   - user input/history
   - domain best practices when clearly marked as assumptions
5. produce section-complete output suitable for downstream source-doc persistence
6. mark assumptions explicitly
7. avoid drifting into other sections except where necessary to cite dependency/context

Each section agent should output:
- `explicit_facts`
- `assumed_facts`
- `rationale`
- `confidence_notes`
- `section_payload`
- `assumption_entries`
- `cross_section_dependencies`

Parallelism contract:
- `ProductBriefSectionAgentNode`, `UserWorkflowsSectionAgentNode`, and `DomainEntitiesSectionAgentNode` are parallel siblings
- none of the three may depend on another sibling's in-flight output during the same phase
- cross-section tensions are resolved by `SourceDocCoherenceNode`, not by hidden ordering between section agents

---

## 1. `ProductBriefSectionAgentNode`

Owns:
- `product_summary`
- `problem_statement`
- `target_users`
- `goals`
- `scope`
- `non_goals`
- `constraints`
- `success_criteria`
- product-level assumptions

Questions it must answer:
- what is the product/system?
- who is it for?
- what problem does it solve?
- what outcomes matter?
- what is in/out of scope?
- what limits and success criteria define it?

Must not:
- author detailed workflow step logic beyond what belongs in product framing
- author detailed entity structure except where needed to reference business objects at a high level

Output artifact suggestion:
- `product_brief_section_resolution.json`

---

## 2. `UserWorkflowsSectionAgentNode`

Owns:
- `actors`
- `primary_workflows`
- `alternate_flows`
- `edge_cases`
- workflow-level assumptions

Questions it must answer:
- who acts in the system?
- what are the main flows?
- what common variations exist?
- what failure/exception scenarios matter?

Must not:
- redefine product goals/scope except where required to align workflow intent
- invent domain entity semantics without surfacing them as cross-section dependencies

Output artifact suggestion:
- `user_workflows_section_resolution.json`

---

## 3. `DomainEntitiesSectionAgentNode`

Owns:
- `entities`
- `relationships`
- `ownership_assumptions`

Questions it must answer:
- what core business/data objects exist?
- how do they relate?
- what ownership/data-authority assumptions are required?

Must not:
- redefine workflows except where workflow/entity linkage needs to be cited
- redefine product-level scope unless a dependency/conflict must be flagged

Output artifact suggestion:
- `domain_entities_section_resolution.json`

---

## Shared completion standard

A section agent should be considered successful only if:
- the owned section contract is materially complete
- assumptions are explicit where gaps were filled
- the section is rich enough to support downstream source-doc persistence and project-doc impact routing
- the output makes clear what is fact vs assumption

If the section is still thin after one pass, that should be visible in its artifact and surfaced to `SourceDocCoherenceNode` for retry/escalation.

---

## Downstream boundary contracts

### `SourceDocCoherenceNode`
Must:
- reconcile conflicts across the three parallel section outputs
- decide whether source-doc sections are coherent enough to persist
- make unresolved tensions visible instead of silently collapsing them

### `SourceDocEnrichmentCoherenceNode`
Must:
- run after `SourceDocCoherenceNode` but before persistence and project-doc routing
- strengthen sparse source docs only where needed for downstream project-doc sync
- improve cross-doc sufficiency without bloating source docs into pseudo-project-docs
- leave enrichment assumptions explicit and inspectable

### `PersistSourceDocsAndAssumptionsNode`
Must:
- persist canonical source docs plus assumptions together as one inspectable checkpoint
- avoid implying project-doc mutation is already complete

### `ProjectDocImpactRoutingNode`
Must:
- determine which project docs need mutation based on the now-coherent source-doc outputs
- prepare a concrete routing package for spawned project-doc mutation subagents

### `SpawnProjectDocMutationSubagentsNode`
Must:
- launch the required project-doc mutation subagents from the impact routing package
- record what was spawned and what outputs are expected back

### `AwaitProjectDocMutationSubagentsNode`
Must:
- block progress until all spawned project-doc mutation subagents have finished
- reject partial completion as sufficient for moving to project-doc coherence

### `ProjectDocCoherenceNode`
Must:
- reconcile the complete set of project-doc mutation outputs only after the await barrier is satisfied
- make any remaining cross-doc inconsistency explicit

### `PersistProjectDocsNode`
Must:
- persist the coherent final project-doc set as the terminal project-doc checkpoint for this DAG run
