# DevFlow skill overlays/adapters

Use overlays/adapters only when a selected harness needs a real delta from the canonical skill.

## Rule of thumb

Start with canonical skills such as:

```text
src/devflow_engine/skills/builtins/devin/ideation/SKILL.md
src/devflow_engine/skills/builtins/devin/idea_to_story_handoff/SKILL.md
```

Only add a harness-specific overlay if the harness genuinely needs something extra, such as:
- tool formatting constraints
- envelope/response-shape constraints
- harness-specific invocation instructions

## Tiny example structure

```text
src/devflow_engine/skills/
  builtins/
    devin/
      ideation/
        SKILL.md
      idea_to_story_handoff/
        SKILL.md
  overlays/
    pi/
      devin/
        ideation.adapter.md
        idea_to_story_handoff.adapter.md
```

## Intent

- the built-in skill stays canonical and harness-agnostic
- registry matching stays context-based
- harness selection stays separate
- the selected harness gets the resolved skill set plus any explicitly allowed thin overlay
- do not duplicate full skills per harness unless there is a truly irreducible divergence
