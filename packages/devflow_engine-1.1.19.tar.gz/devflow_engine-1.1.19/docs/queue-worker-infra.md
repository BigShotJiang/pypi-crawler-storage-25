# Queue + worker infrastructure

## Supabase execution-event listener

### Purpose

`devflow worker supabase-events` is the DFE-side listener/dispatcher for the
`devflow_execution_events` Supabase table.  It is the single process that bridges the
control-plane (Supabase) to the local DevFlow engine — polling for queued events and dispatching
the appropriate local workflow for each one.

### Supported event types

| `event_type` | Workflow dispatched |
|---|---|
| `devflow.project.init.request` | `project_init` |
| `devflow.project.import.request` | `project_import` |
| `devflow.project.repo_tree.request` | `project_repo_tree` |
| `devflow.project.source_docs.add.request` | `source_docs_add` |
| `devflow.source_scope.run.request` | `source_scope_run` |
| `devflow.idea.intake.request` | `idea_intake` |
| `devflow.idea.stories.generate.request` | `idea_stories_generate` |
| `devflow_settings_changed` | `settings_changed` |
| `devflow_API_KEY` | `api_key` |

`devflow_settings_changed` is handled on the DFE side through the current DFE config pipeline for non-secret settings.

`devflow_API_KEY` is recognized and claimed by the DFE worker, decrypted with the transient transport grant, stored durably in the macOS keychain, and activated in the current DFE runtime env.

Events with any other `event_type` are skipped without claiming.

### Event claim contract

The worker only picks up rows where:
- `status = queued`
- `run_id IS NULL`

It claims a row with an atomic `PATCH status=processing` (optimistic-lock style) before
dispatching, so multiple concurrent worker processes will not double-process the same event.

### Realtime WebSocket behavior

When `--realtime` is active (the default), the worker opens a Supabase Realtime WebSocket
subscription (`realtime:public:devflow_execution_events`) using the Phoenix channel protocol.  Any
`INSERT` on the table triggers an immediate wakeup of the dispatch loop, bypassing the normal
poll-sleep interval.

```
INSERT arrives in Supabase
        │
        ▼
Realtime WebSocket → on_event() callback → _wakeup.set()
        │
        ▼
dispatch loop wakes immediately → fetch & claim next queued event
```

If the WebSocket connection drops, `SupabaseRealtimeListener` reconnects automatically after a
5-second back-off.  **Polling continues as the fallback during any reconnect gap** — no events are
lost, only latency increases by at most `--sleep-seconds`.

The `websockets` Python package is required for realtime. If it is not installed, the listener
logs a warning and silently falls back to polling-only mode without crashing.

### Running the worker

**Continuous loop (normal production usage):**
```bash
devflow worker supabase-events
```

**Single-shot (process one event and exit):**
```bash
devflow worker supabase-events --once
```

**Polling only (no WebSocket):**
```bash
devflow worker supabase-events --no-realtime
```

**All options:**
| Flag | Default | Description |
|---|---|---|
| `--once` | off | Process at most one event then exit |
| `--sleep-seconds N` | `3.0` | Idle sleep between polls; also caps max realtime wake latency |
| `--max-iterations N` | unlimited | Exit after N loop iterations (useful for tests/scripts) |
| `--realtime / --no-realtime` | `--realtime` | Enable/disable the WebSocket listener |
| `--json` | off | Emit JSON summary on exit |

### Troubleshooting: queued events not being picked up

1. **Worker not running** — confirm a live `devflow worker supabase-events` process exists.
2. **Bad credentials** — verify `SUPABASE_URL` and `SUPABASE_SERVICE_KEY` (or equivalent config)
   are set and valid.  The worker will error immediately on first poll if credentials are wrong.
3. **Event not eligible** — check the `devflow_execution_events` row: `status` must be `queued`
   and `run_id` must be `NULL`.  Any other state means it was already claimed or completed.
4. **Unsupported event type** — confirm the row's `event_type` is in the supported set above.
   Unsupported types are silently skipped.
5. **Quick manual test** — run `devflow worker supabase-events --once` and inspect stdout/stderr
   for the dispatch result.
6. **Realtime false-wake / missed-wake** — if you suspect the WebSocket is the culprit, run with
   `--no-realtime` to isolate the polling path.  The polling loop should pick up the event within
   `--sleep-seconds` regardless of Realtime state.

### Implementation files

| File | Role |
|---|---|
| `src/devflow_engine/devflow_event_worker.py` | `DevflowEventWorkerService`, `DevflowEventWorkerLoopService`, `SupabaseRealtimeListener` |
| `src/devflow_engine/cli/app.py` | `worker_supabase_events` Typer command (`devflow worker supabase-events`) |
| `tests/test_devflow_event_worker.py` | Unit tests for the event worker |

---

# Generic queue + worker infrastructure

This adds a first-pass reusable orchestration layer on top of the existing durable SQLite execution store.

## Why this exists

The repo already had:
- durable run / node / artifact records
- story-specific queue tables
- a project worker path

What was missing was a generic task model that can support assistant-style workflows without inventing a new table per workflow.

## Durable model

### `task_records`
The durable source of truth for queued work.

Key fields:
- `task_id`
- `queue_name` — logical queue, for example `assistant.devin`
- `task_kind` — handler key, for example `devin.idea.ideation`
- `status` — `queued | leased | completed | failed | cancelled | dead_letter`
- `priority`
- `idempotency_key` — dedupe while active
- `source_run_id` — optional link back to a run that created the task
- `lease_token`, `lease_expires_at`, `claimed_by_worker_id` — claim/lease state
- `input_json`, `context_json`, `result_json`
- `attempts`, `max_attempts`, `last_error`

### `task_steps`
Append-only workflow progress markers for multi-step state transitions.

Examples:
- `claim`
- `devin_chat.run`
- future planner / coder / reviewer substeps

### `task_messages`
Structured emitted outputs while a task runs or when it completes.

This is the write-back channel for assistant/orchestration use cases.

## Lifecycle

1. `enqueue_task(...)`
2. worker calls `claim_next_task(...)`
3. record steps and emit messages while work runs
4. complete via `complete_task(...)`
   - `failed` auto-requeues while `attempts < max_attempts`
   - terminal failures become `failed`
   - unknown handlers become `dead_letter`

## Lease contract

- claiming returns a `lease_token`
- completion and renewal require the current token
- expired leases become claimable again
- this is intentionally DB-backed and durable first

If Redis is added later, it should accelerate wakeups / fanout, not replace `task_records` as the durable source of truth.

## Worker contract

`process_one_task(...)` takes:
- an `ExecutionStore`
- repo root
- queue name
- worker id
- handler map keyed by `task_kind`

Handler contract:
- input: `(store, repo_root, task_dict)`
- output: serializable result dict
- handlers can write intermediate steps/messages through the store

## Devin ideation as first client

Implemented in `src/devflow_engine/devin_orchestration.py`:
- queue: `assistant.devin`
- task kind: `devin.idea.ideation`
- enqueue helper: `enqueue_devin_chat_task(...)`
- handler: `handle_devin_chat_task(...)`

Current behavior:
- stores the ideation request as a generic task
- worker claims it through the generic queue API
- handler runs `run_devin_chat_dag(...)`
- final response is written back to `task_messages` and `task_records.result_json`

## Architectural choice

This does **not** replace the existing story/error worker path yet.
It establishes a reusable task substrate first, so later migrations can move story execution, review, fixes, or external assistant workflows onto the same model incrementally.

## DAG run investigation rule

When checking a DevFlow DAG execution, do **not** stop at the outer wrapper run alone (for example `story.execute`).

Always trace both:
- the wrapper/orchestration run
- the actual child DAG run(s)

### Why this matters

A wrapper run can be stranded or left `running` even when the actual DAG child run succeeded and persisted node outputs correctly.

### Do not assume same run UUID

Explicitly check for **wrapper-vs-child run UUID mismatch**.

The wrapper run id and the actual DAG child run id may differ. Do **not** call them the same run unless the UUIDs actually match.

### Correlation checklist

To verify whether two runs belong to the same execution, correlate on:
- story UUID
- story ID
- repo root
- creation time window
- node sequence
- artifact paths

### Practical investigation order

1. Check the wrapper run row (`runs`) for the user-facing command invocation.
2. If it is missing node/artifact/error rows, search nearby runs by:
   - same story UUID
   - same story ID
   - same repo root
   - same creation timestamp window
3. Inspect child DAG runs for:
   - persisted `nodes`
   - persisted `artifacts`
   - persisted `errors`
4. Verify story-scoped artifact paths and run-scoped artifact paths point to the same story execution.
5. Only after that conclude whether:
   - the DAG itself failed,
   - the wrapper reconciliation failed,
   - or the investigation was looking at the wrong run id.

## Story churn / failure investigation evidence order

When explaining why a story/process is churning, review the **actual streamed agent logs first**.

Evidence priority:
1. Primary: streamed LLM logs / sessions / transcripts for the relevant Green/Refactor/Security/etc. agent runs when available.
   - Log files: `/Users/devflow/.devflow/llm_logs/*.jsonl`
   - Session DB: `/Users/devflow/.devflow/llm_sessions.sqlite`
2. Secondary: node artifacts.
3. Tertiary: DB queue rows / summary state.

Do **not** lead with queue-table status or summary rows when richer streamed logs exist; use DB state to corroborate, not to replace, the underlying run transcript.
