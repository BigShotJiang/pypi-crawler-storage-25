# Source Doc Mutation Support-Index Contract

## Purpose

`source_doc_mutation_dag` now has three canonical support indexes for routing and downstream project-doc mutation support.

These are support docs, not eval docs.

Canonical machine-readable artifacts:
- `docs/support/source_doc_mutation/internal_source.json`
- `docs/support/source_doc_mutation/internal_project.json`
- `docs/support/source_doc_mutation/cross_sourceXproject.json`

## Index set

### `internal_source`
Contract-driven inventory of canonical source docs and their supported sections.

### `internal_project`
Contract-driven inventory of the derived project-doc family and each doc's primary source-doc dependencies.

### `cross_sourceXproject`
Contract-driven cross-index from `source_doc:section` → impacted project docs.

## Contract rules

- machine-readable JSON is canonical
- indexes are pre-generated from contract, not synthesized from current repo content
- classification must stay `support_doc`
- the DAG must load these indexes into support context before routing
- project-doc routing must use `cross_sourceXproject` section mappings, not just doc-level heuristics
- project-doc mutation payloads may carry the support indexes forward for downstream grounding/coherence

## Current DAG usage

`NormalizeAndGatherSupportContextNode` loads the three indexes into the run's support payload.

`PersistSourceDocsAndAssumptionsNode` computes concrete `changed_sections` from the canonical source-doc diff.

`ProjectDocImpactRoutingNode` uses `cross_sourceXproject` plus `internal_project` to:
- map changed source sections to impacted project docs
- compute routed section refs per target
- assemble supporting source-doc packets for subagent mutation

The run artifacts expose the loaded support indexes in:
- `source_doc_mutation_plan.json`
- `project_doc_sync_result.json`
- `source_doc_mutation_result.json`

## Why this exists

The older markdown reference docs remain useful human mirrors:
- `docs/source-to-project-doc-reference-map.md`
- `docs/project-doc-cross-reference-rules.md`

But the JSON support indexes are now the canonical routing contract the DAG actually uses.
