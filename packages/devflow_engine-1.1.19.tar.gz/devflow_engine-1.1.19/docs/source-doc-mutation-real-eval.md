# Source Doc Mutation real-LLM evaluation

`source_doc_mutation_dag` now supports an explicit runtime split:

- `agent_runtime_mode="stub"` for cheap structural/unit coverage
- `agent_runtime_mode="real"` for actual configured DevFlow CLI LLM execution

The real path is not a renamed stub. In `real` mode the DAG calls the configured DevFlow CLI runtime for:

- `ProductBriefSectionAgentNode`
- `UserWorkflowsSectionAgentNode`
- `DomainEntitiesSectionAgentNode`
- `SourceDocCoherenceNode`
- `ProjectDocCoherenceNode`
- spawned project-doc markdown render subprocesses
- eval scoring passes that score quality/completeness and mutation accuracy matrices

If the configured runtime is missing or fails, the run fails. It does **not** silently downgrade to heuristic fallback.

## Eval artifact layout

Each eval run now gets a stable start timestamp that is also the eval run id.
All eval artifacts for that run live under:

```text
<evals_root>/<run_id>/
  ai_docs/context/source_docs/
  ai_docs/context/project_docs/
  indexes/
  metrics/
  matrices/        # targeted-mutation eval only
  eval_manifest.json
```

Durable path contract:

- `run_sparse_input_eval(...)` and `run_targeted_mutation_eval(...)` write to `<repo_root>/evals/<run_id>` by default.
- Passing `evals_root=...` overrides the base directory and writes to `<evals_root>/<run_id>`.
- `playground/source_doc_mutation_eval.py` now defaults to `playground/eval_runs/<run_id>` whenever `--repo-root` is omitted, so the copied eval snapshot and per-document metrics survive after the temporary repo is cleaned up.

The copied `ai_docs/context/...` tree is the eval snapshot. The DAG still keeps its own pipeline artifacts under `.devflow/...`, and `eval_manifest.json` records both the eval run id/timestamp and the underlying DAG run ids.

## Sparse-input eval

```bash
python3 playground/source_doc_mutation_eval.py \
  --eval-type sparse_input \
  --agent-runtime-mode real \
  --text "Build a task app that lets me create tasks and assign them to staff."
```

Artifacts include:

- `indexes/source_docs_index.json`
- `indexes/project_docs_index.json`
- `metrics/quality.json`
- `metrics/completeness.json`

Those metrics contain:

- per-document quality/completeness
- overall `source_docs` mean
- overall `project_docs` mean
- overall mean across all docs

## Targeted-mutation eval

Targeted mutation now uses a preserved sparse-input eval snapshot as the baseline instead of regenerating the base docs from `--base-text`.
By default it resolves the latest `sparse_input` run under `--evals-root` (or `<repo-root>/evals`).
You can pin an explicit baseline with `--baseline-eval-root <evals_root>/<run_id>`.

```bash
python3 playground/source_doc_mutation_eval.py \
  --eval-type targeted_mutation \
  --agent-runtime-mode real \
  --base-text "Build a task app that lets me create tasks and assign them to staff." \
  --mutation-text "Add due dates, priority levels, and reassignment approvals."
```

Optional explicit baseline:

```bash
python3 playground/source_doc_mutation_eval.py \
  --eval-type targeted_mutation \
  --agent-runtime-mode real \
  --baseline-eval-root playground/eval_runs/20260322T211128Z \
  --mutation-text "Add due dates, priority levels, and reassignment approvals."
```

In addition to quality/completeness artifacts, targeted-mutation eval writes:

- `matrices/appropriate_update.json`
- `matrices/thoroughness.json`
- `matrices/accuracy.json`

Where:

- `appropriate_update` = targeted-area update correctness
- `thoroughness` = whether all areas that should have been updated were updated
- `accuracy` = average of `appropriate_update` and `thoroughness`

Targeted-mutation manifests now also record:

- `baseline_eval_root` = sparse-input snapshot used as the mutation baseline
- `artifacts.baseline_source_docs_root` = preserved pre-mutation source docs copied into the eval run
- `artifacts.baseline_project_docs_root` = preserved pre-mutation project docs copied into the eval run

The runner copies both baseline `source_docs` and `project_docs` into the working repo before it runs the mutation DAG, then snapshots both the preserved baseline and the post-mutation docs in the eval output.

## Pytest real evaluation

```bash
DEVFLOW_REAL_LLM_EVAL=1 pytest -q tests/test_source_doc_mutation_real_eval.py
```

This test intentionally runs only when `DEVFLOW_REAL_LLM_EVAL=1` is set.

## Cheap stub/unit path

Existing structural/unit tests should pass `agent_runtime_mode="stub"` explicitly. That keeps CI cheap and makes the fake-vs-real split visible in code instead of pretending they are equivalent.
