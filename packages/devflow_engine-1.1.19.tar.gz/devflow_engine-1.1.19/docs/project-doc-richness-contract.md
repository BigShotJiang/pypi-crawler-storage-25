# Project-Doc Richness Contract

## Purpose

This document defines the minimum but solid suite of project docs and what each document must answer to count as complete, useful, and richly developed.

These project docs are derived from canonical source docs and are intended to support:
- planning clarity
- implementation readiness
- delivery sequencing
- downstream story generation

Minimum project-doc suite:
- `project_charter.md`
- `prd.md`
- `architecture.md`
- `ux_design.md`
- `delivery_plan.md`

---

## Global doctrine

Project docs are:
- derived from canonical source docs
- richer and more human-oriented than source docs
- allowed to elaborate and synthesize
- not allowed to silently contradict source docs

Every project doc should be evaluated against:
1. **coverage** — does it answer the required headings?
2. **depth** — is the content substantial enough to guide work?
3. **specificity** — is it concrete rather than generic filler?
4. **traceability** — can the reader see how it relates back to source docs?
5. **consistency** — does it align with the rest of the doc family?

---

# 1. `project_charter.md`

## Purpose
Executive framing of what is being built and why.

## Required headings
- Overview
- Problem / Opportunity
- Target Users
- Goals
- Scope
- Non-Goals
- Constraints
- Success Criteria

## Rich/deep standard
- clearly explains the product in business/operator terms
- frames the problem concretely
- defines why the work matters
- gives enough scope boundary to anchor delivery
- avoids devolving into technical details better suited to architecture

---

# 2. `prd.md`

## Purpose
Detailed product behavior and requirement framing.

## Required headings
- Product Overview
- User Roles
- Core User Journeys
- Functional Requirements
- Alternate / Exceptional Flows
- Acceptance-Oriented Behavior Notes
- Assumptions

## Rich/deep standard
- captures how the product is expected to behave
- connects user roles to journeys and requirements
- contains meaningful detail for downstream implementation/stories
- includes exceptions/variants where relevant

---

# 3. `architecture.md`

## Purpose
Technical/system realization of the product.

## Required headings
- System Overview
- Core Entities / Data Model
- Key Relationships
- Components / Surfaces
- Integrations
- Constraints / Risks
- Open Architectural Assumptions

## Rich/deep standard
- enough system shape to reason about implementation
- entities and relationships are explained, not just listed
- integration and constraint considerations are captured
- aligns with source-doc entities/workflows

---

# 4. `ux_design.md`

## Purpose
User interaction and experience framing.

## Required headings
- UX Overview
- Primary User Flows
- Key Screens / Views
- Important Interactions
- Edge / Error Experiences
- UX Assumptions

## Rich/deep standard
- sufficiently clear to imagine the experience
- primary flows connect back to source workflows
- screens/views are motivated by user tasks
- edge/error behavior is considered where relevant

---

# 5. `delivery_plan.md`

## Purpose
Phased execution and sequencing bridge from planning into implementation.

## Required headings
- Delivery Strategy
- Phases / Milestones
- Implementation Priorities
- Dependencies
- Risks / Watchouts
- Recommended Next Steps

## Rich/deep standard
- gives a believable order of operations
- highlights sequencing and dependencies
- helps turn planning into actual work
- is grounded in scope, workflows, and architecture

---

## Cross-document completion standard

To count as a complete and solid project-doc suite:
- the five docs all exist
- they are mutually consistent
- they elaborate source docs without contradicting them
- they are detailed enough to support story generation / implementation planning
- they remain assumption-aware when details were inferred
