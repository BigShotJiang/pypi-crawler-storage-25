# Devin intake vs ideation boundary

See also:
- [Devin chat principles](./devin-chat-principles.md)
- [Devin chat eval rubric](./evals/devin-chat-rubric.md)

## Happy path

Devin is the external conversational worker.
`devflow_engine` is the internal planning engine and tooling substrate.

The happy path is:

1. **Devin intake entrypoint** receives the latest user/request message.
2. **Devin intake** loads prior Devin conversation history for the project, grounds the latest message against that history, and performs the top-level route decision.
3. **Devin intake router** is a first-class router node in the workflow schema and routes to exactly one arm:
   - **insight arm** for redirects / analysis-advice responses that do not start ideation-to-stories execution
   - **ideation arm** for software-delivery planning intake
4. **Ideation arm** starts only after intake already supplied:
   - the normalized request text
   - the history-grounded request text
   - the route decision
   - the project identifier
5. **Ideation arm** resolves source-doc mutation context, runs the real Devin agent loop against the produced artifacts/state, and only then posts Devin’s reply into `agent_agent_messages`.

## Hard boundary

The ideation arm does **not**:

- fetch top-level Devin history on its own
- decide insight vs ideation on its own
- re-run top-level routing heuristics
- act as the external Devin entrypoint

The Devin intake layer owns:

- history collection
- history grounding
- top-level request routing
- creation of the explicit handoff contract into the ideation arm

The ideation arm owns:

- source-doc mutation request construction
- source-doc mutation invocation / tracking
- lightweight mutation ref recording
- ideation sufficiency evaluation inside the real agent-loop stage
- idea artifact persistence inside the real agent-loop stage
- response preparation from the already-authorized ideation context inside the real agent-loop stage

## Current implementation rule

Inside this repo, any ideation DAG node that performs history collection or top-level route selection is violating the intended architecture.

The required implementation shape is:

- an explicit **Devin intake node/layer** before ideation-context assembly
- an explicit **router node/layer** after intake and before any arm-specific work
- separate **insight arm** and **ideation arm** branches in `WorkflowSchema` / `NodeConfig`
- an explicit **ideation preparation node/layer** that consumes the intake handoff
- downstream ideation nodes that trust the intake handoff instead of recreating it

## Required node contract

The intake-to-ideation handoff must carry, at minimum:

- `project_id`
- `raw_text`
- `grounded_raw_text`
- `input_meta`
- `history_grounding`
- `route_payload`

Downstream ideation nodes may enrich this state, but they must not replace the intake decision boundary.
