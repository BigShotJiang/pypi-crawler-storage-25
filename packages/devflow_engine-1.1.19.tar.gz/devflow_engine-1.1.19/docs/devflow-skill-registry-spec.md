# DevFlow-native skill registry spec

## Purpose

This document defines how **DevFlow-owned `SKILL.md` artifacts** live in the repo and how they are resolved for runtime use.

Related doc boundary:
- runtime skill artifacts are specified here and live under `src/devflow_engine/skills/...`
- prompt anti-pattern guidance lives under `docs/prompts/anti-patterns.md`

Core architecture correction:
- canonical core skills are **harness-agnostic by default**
- **skill resolution is context-based**
- **harness resolution is separate** from skill resolution
- the selected harness receives the resolved skill set through the **canonical invocation seam**
- harness-specific behavior should use **thin optional overlays/adapters only when there is a real harness delta**

This is a DevFlow runtime concept, not an OpenClaw skill concept.

A DevFlow skill is:
- a repo-owned instruction artifact
- selected by explicit runtime context
- injected through normal prompt construction before invocation
- observable in invocation metadata
- not hidden as opaque magic inside `invoke_llm(...)`

## Non-goals

This spec does **not**:
- implement a full loader/runtime in this slice
- make harness choice the primary identity of a skill
- turn `invoke_llm(...)` into a hidden skill resolver
- duplicate the same skill per harness when the doctrine is the same
- replace existing prompt docs or route docs

## What a DevFlow skill is

A DevFlow skill is a small instruction package centered on a `SKILL.md` file and optionally a few adjacent reference files.

Its job is to express reusable behavior such as:
- conversational doctrine for a bounded situation
- handoff rules
- state-truthfulness rules
- structured response expectations
- constraints on what the agent may or may not imply

A DevFlow skill does **not** own:
- model selection
- harness selection
- tool registration
- provider transport
- queue execution
- durable state transitions

Those remain normal runtime responsibilities.

## Canonical storage locations

Three storage classes are allowed.

### 1. Built-in DevFlow skills

Canonical location inside this repo:

`src/devflow_engine/skills/builtins/<domain>/<skill_slug>/SKILL.md`

Examples:

- `src/devflow_engine/skills/builtins/devin/ideation/SKILL.md`
- `src/devflow_engine/skills/builtins/devin/idea_to_story_handoff/SKILL.md`

Use built-ins for:
- DevFlow doctrine the repo wants to version and ship
- default behavior that should travel with the engine
- stable skills referenced by canonical registry bindings

### 2. Local/internal skills

Canonical location relative to repo root:

`.devflow/skills/internal/<domain>/<skill_slug>/SKILL.md`

Use internal skills for:
- org-local overlays
- non-public operational doctrine
- deployment-specific or private behavior that should not live in git-tracked product docs

### 3. Optional project-local skills

Canonical location relative to the registered project root:

`<project_root>/.devflow/skills/<domain>/<skill_slug>/SKILL.md`

Use project-local skills for:
- repo-specific behavior
- project-specific language, boundaries, or workflow doctrine
- narrow overlays that should only apply when operating on that project

## Proposed built-in repo layout

Built-in skills should live under a small, explicit tree:

```text
src/devflow_engine/skills/
  builtins/
    devin/
      ideation/
        SKILL.md
        state-and-phrasing-reference.md
      idea_to_story_handoff/
        SKILL.md
  registry.example.yaml
```

Optional harness-specific overlays, when truly needed, should stay thin and separate from the canonical skill body:

```text
src/devflow_engine/skills/
  builtins/
    devin/
      idea_to_story_handoff/
        SKILL.md
  overlays/
    pi/
      devin/
        idea_to_story_handoff.adapter.md
```

Rule:
- prefer one canonical skill
- add an overlay/adapter only when the selected harness needs a real delta in wording, formatting, tool constraints, or invocation contract
- do not fork whole skills per harness by default

## Registry/config model

The registry/config binds a skill ref to an explicit **execution context**, not 1:1 to a harness.

Primary matching dimensions are:
- `agent`
- `route`
- `purpose`
- optional repo/project context such as `repo_root`, `project_type`, or `project_tags`

Optional compatibility filters may further constrain where a matched skill may be injected:
- `allowed_harnesses`
- `disallowed_harnesses`

Additional ordering/policy controls may include:
- `priority`
- `enabled`
- `adapter_policy`

### Canonical skill refs

Bindings should prefer explicit refs over implicit name lookup.

Canonical ref forms:
- `builtin:<domain>/<skill_slug>`
- `internal:<domain>/<skill_slug>`
- `project:<domain>/<skill_slug>`

Examples:
- `builtin:devin/ideation`
- `builtin:devin/idea_to_story_handoff`
- `internal:clarity/pi_deployment_overlay`
- `project:checkout/risk_doctrine`

This avoids silent precedence games.

## Resolution flow

Resolution should be deterministic and happen **before prompt invocation**.

### Inputs to resolution

The selector context should be explicit and serializable, for example:
- `repo_root`
- `project_root` if present
- `project_type` or `project_tags` if available
- `agent`
- `route`
- `purpose`
- stable workflow facts needed for gating

Harness information may also be present, but only as a **separate compatibility/applicability input**, not the primary identity of the skill.

### Selection + harness flow

1. Build a `SkillSelectionContext` from already-known runtime facts.
2. Resolve the execution harness separately using the normal runtime/harness-routing logic.
3. Load registry bindings.
4. Filter bindings by context match rules.
5. Apply optional harness compatibility filters such as `allowed_harnesses` / `disallowed_harnesses`.
6. Resolve each bound `skill_ref` to a filesystem path.
7. Read the matched canonical `SKILL.md` files.
8. Optionally resolve thin harness overlays/adapters for the selected harness if the binding or skill policy allows them.
9. Materialize ordered skill instruction blocks.
10. Pass those blocks into normal prompt construction.
11. Call `invoke_llm(...)` with the already-composed prompt payload plus optional skill metadata for observability.

### Important architecture rule

Selection is **not** a hidden side effect of `invoke_llm(...)`.

`invoke_llm(...)` may receive:
- already-injected skill text inside the prompt payload
- resolved skill ids/paths in metadata for journaling/audit
- optional overlay/adapter metadata describing any harness-specific deltas applied

But `invoke_llm(...)` should **not**:
- discover skills on disk by itself
- decide whether a skill applies
- silently change prompt behavior based on hidden registry rules

That keeps skill behavior visible at the workflow/prompt-building layer.

## Selection vs harness resolution vs injection

The intended split is:

### Skill resolution happens first-class in the prep layer

Skill resolution belongs in the route/prompt-preparation layer, for example:
- after route selection is already known
- after the agent identity is already known
- before prompt serialization is finalized

### Harness resolution is separate

Harness resolution remains a runtime concern.

The runtime may choose a harness based on its own rules, capability constraints, transport availability, or execution policy.

That choice may affect compatibility filtering and optional overlays/adapters, but it should not redefine the canonical identity of the skill.

### Injection happens through the canonical invocation seam

Injection means the resolved canonical skills, plus any thin selected overlay/adapter deltas, become part of the prompt payload passed into the canonical invocation seam.

So the architecture rule is:
- **context-based skill resolution outside `invoke_llm(...)`**
- **separate harness resolution**
- **prompt injection through the request passed to `invoke_llm(...)`**

This preserves Marcus's constraint that skill behavior must not become opaque magic trapped inside the lowest-level invocation helper.

## Overlay / adapter guidance

Overlays/adapters are optional and should be rare.

Use one only when there is a real harness-specific delta such as:
- tool availability or tool-call formatting differences
- message envelope differences
- strict token/formatting constraints imposed by one harness
- a harness-specific invocation contract that cannot be expressed cleanly in the generic skill body

Do **not** use overlays/adapters to:
- create per-harness duplicates of the same doctrine
- move core business logic out of the canonical skill
- treat harness choice as a replacement for context-based skill matching

A small adapter policy surface is sufficient, for example:
- `forbid`
- `allow`
- `require_explicit`

## Truthful state semantics for idea -> story handoff

Skills must not blur workflow truth.

For ideation and handoff behavior, the state vocabulary should remain explicit:

### `idea_persisted`

Meaning:
- the current idea/source-doc state has been durably written
- DevFlow can truthfully say the idea shape was captured

Does **not** mean:
- story generation was requested
- queue work is running
- stories already exist

### `story_generation_enqueued`

Meaning:
- a durable downstream request was created for story generation
- the request can be inspected/retried by the normal worker substrate

Does **not** mean:
- a worker has started processing it yet
- generation is actively running
- story outputs exist yet

### `story_generation_started`

Meaning:
- a worker/run has actually claimed and begun the downstream generation step

Does **not** mean:
- stories finished successfully

### Communication doctrine

Allowed examples:
- "I’ve captured the idea and can start story generation when you’re ready."
- "The idea is persisted and story generation has been queued."
- "Story generation has started."

Not allowed:
- saying story generation started when the idea was only persisted
- saying work is underway when it was only enqueued
- implying stories exist when generation has not completed

## Devin chat ideation skills

For the concrete case discussed here, the built-in ideation skills are **canonical DevFlow skills**, not Pi-only skills.

### Canonical ideation match context
- `agent = devin_chat`
- `route = ideation`
- `purpose = devin.chat.ideation.reply` (or the final canonical purpose string chosen by runtime)

The broader ideation skill owns:
- discovery
- draft-contract doctrine
- persisted-idea doctrine
- approval vs queue vs started truthfulness

### Canonical handoff match context
- `agent = devin_chat`
- `route = ideation`
- `purpose = devin.chat.ideation.handoff`

### Optional harness compatibility
A binding may still say this skill is only compatible with certain harnesses for now, for example if one route currently runs only on `pi`.

That is a **compatibility constraint on injection**, not the primary identity of the skill.

### Expected behavior

When Devin is responding in the ideation arm, the registry may bind the broader ideation skill to:
- keep Devin forward-moving through discovery and contract-shaping
- distinguish transient run artifacts, persisted idea state, readiness contract state, and queue state
- prevent fake-progress language before approval or enqueue

When Devin is specifically at the idea->story boundary, the registry may additionally bind the narrower handoff skill to:
- sharpen the approval boundary
- make the enqueue threshold explicit
- preserve truthful distinctions between persisted idea, queued downstream work, and started downstream work

## Minimal binding schema

See `src/devflow_engine/skills/registry.example.yaml` for a concrete example.

Required top-level concepts:
- registry `version`
- canonical roots for `builtins`, `internal`, and `project_local`
- `bindings[]`

Each binding should support at least:
- `binding_id`
- `skill_ref`
- `enabled`
- `match.agent`
- `match.route`
- `match.purpose`
- optional `match.repo_root` / `match.project_type` / `match.project_tags`
- optional `allowed_harnesses[]`
- optional `disallowed_harnesses[]`
- `priority`
- `adapter_policy`
- `injection.mode`

## Recommended minimal runtime seam

When the runtime slice is implemented, keep it small:
- a pure resolver that turns selection context + registry into ordered canonical skill paths/content
- optional overlay resolution for the already-selected harness when explicitly allowed
- prompt assembly that incorporates the resolved skill text
- optional invocation metadata capturing which skills and overlays were applied

That is enough to make the feature real without overbuilding a full skill framework first.
