# Devin Ideation → Source Docs Architecture

See also:
- [Devin chat principles](./devin-chat-principles.md)
- [Devin chat eval rubric](./evals/devin-chat-rubric.md)

## Current implementation status

This document describes the intended direction, not a fully completed implementation.

What is implemented now:

- source-doc and project-doc scaffolding exists
- ideation writes/patches source-doc JSON files during intake
- assumptions are recorded in `assumptions_registry.json`
- Devin response preparation can acknowledge changed source docs and open assumptions
- a separate queued updater exists for deriving markdown project docs from source docs

What is **not** fully implemented end-to-end yet:

- source-doc synthesis is still largely heuristic/bootstrap logic in `devin_chat_dag.py`, not a robust LLM-first source-doc synthesizer
- assumption reconciliation is mostly append/update of open assumptions, not full lifecycle management
- ideation does not currently trigger the queued project-doc updater from the main DAG
- scope generation is not yet demonstrated here as consuming source docs as its canonical input path
- playground fake/stub modes are harnesses only and must not be treated as production-complete ideation behavior

Read the rest of this doc as architecture/target-state guidance unless a section explicitly says it is already implemented.

## Goal

Shift Devin ideation away from directly forcing vague conversational input into idea primitives.

Instead, Devin should:

1. route between **insight** and **ideation**
2. use ideation to build and maintain structured **source docs**
3. track and surface assumptions explicitly
4. update source docs incrementally as the conversation evolves
5. let existing downstream DevFlow pipelines consume those source docs to generate:
   - scopes
   - ideas
   - stories

This keeps Devin conversational and fast while preserving the existing DevFlow DAG chain:

- source docs → scopes
- scopes → ideas
- ideas → stories

## Core principle

Source docs are the canonical planning-intake layer.

They should be:

- structured
- mutation-friendly
- assumption-aware
- incrementally updated
- usable as direct input to scope generation

Project docs should be derived from source docs in the background.

## Directory shape

On both:

- new repo initialization
- repo import

ensure these directories exist:

- `ai_docs/context/source_docs/`
- `ai_docs/context/project_docs/`

## Source docs format

Use **JSON**, not markdown/MDX, for source docs.

Reason:

- easier mutation
- section/topic-level targeting
- explicit tracing of assumptions
- safer incremental updates
- easier downstream evaluation and diffing

## Initial source docs

Recommended canonical set:

- `ai_docs/context/source_docs/product_brief.json`
- `ai_docs/context/source_docs/user_workflows.json`
- `ai_docs/context/source_docs/domain_entities.json`
- `ai_docs/context/source_docs/assumptions_registry.json`

Optional later:

- `ui_model.json`
- `integrations.json`
- `constraints.json`

## Initial state

At repo init/import, create these files as structured templates with empty content.

Important nuance:

- structure exists immediately
- content can be empty until first user ideation input arrives

Once the first user idea arrives, the current implementation attempts to fill the source docs as completely as possible using:

- explicit user input
- grounded inference
- clearly registered assumptions

Important caveat: today this filling is still driven by heuristic/bootstrap helpers for classification and field inference. It is acceptable only if presented as provisional source-doc bootstrapping rather than authoritative semantic understanding.

## Assumption model

Assumptions must be first-class.

Each assumption should include at least:

- `assumption_id`
- `status`: `open | confirmed | rejected | superseded`
- `confidence`
- `source`
- `doc_path`
- `section_key`
- `topic_key`
- `current_value`
- `reasoning`
- `last_updated_from_message_id`

This allows Devin and background jobs to update only the affected parts of docs when assumptions change.

## Devin ideation target behavior

Devin should be tuned as a conversational source-doc synthesizer.

Not:

- force one idea primitive immediately
- regenerate every planning artifact on every turn

Instead:

- gather input
- maintain/update source docs
- maintain/update assumptions
- surface the most relevant open assumption/question
- respond quickly from current state
- allow asynchronous background synthesis to continue

## Foreground vs background split

### Foreground path

The synchronous path should be lightweight and responsive.

On each new ideation message:

1. load source docs
2. load assumptions
3. determine whether the message updates the active planning thread
4. run the first-class `source_doc_mutation_dag` node chain to patch relevant source-doc sections
5. patch assumption registry
6. produce a user-facing response

Current implemented DAG skeleton:
- `NormalizeMutationRequestNode`
- `InventorySourceDocsNode`
- `DetermineMutationPlanNode`
- `ApplyExplicitPayloadNode`
- `ApplyDeterministicMutationNode` (transitional heuristic node; not a real agentic happy path)
- `ReconcileAssumptionsNode`
- `PersistSourceDocsNode`
- `SyncDerivedProjectDocsNode`
- `FinalizeMutationArtifactsNode`

That response should:

- acknowledge what changed
- surface one most relevant assumption/question
- optionally surface candidate scopes/ideas emerging from the docs

### Background path

The asynchronous path should do heavier derived work.

Target behavior: trigger whenever source docs change.

Note: there is updater infrastructure for this, but the ideation DAG is not yet wired as a reliable automatic trigger for that queue.

1. recompute/update derived project docs
2. reconcile assumption status changes
3. recompute scope-generation readiness
4. optionally refresh candidate scopes
5. optionally refresh downstream planning summaries

This allows Devin to respond quickly without waiting for all derived docs to regenerate.

## Project docs role

`project_docs` are derived artifacts.

Suggested examples:

- `project_charter.md`
- `prd.md`
- `architecture.md`
- `design.md`

They should be updated in the background from source docs.

Source docs remain canonical.
Project docs are synchronized planning artifacts.

## Recommended Devin ideation flow

### Outer route still exists

Keep the high-level router:

- message → `insight` or `ideation`

### Ideation path target shape

1. history/context grounding
2. load source docs + assumptions
3. patch source docs from latest message
4. patch assumption registry
5. determine one most relevant next clarification
6. generate conversational response
7. emit background regeneration trigger for derived project docs

This is the source-doc conversation loop.

## Relationship to scopes / ideas / stories

This proposal does **not** replace the established downstream primitives.

Instead it clarifies their order:

- **source docs** = intake/conversational planning truth
- **scopes** = first planning decomposition layer
- **ideas** = shaped units derived from scopes
- **stories** = executable implementation decomposition

Recommendation:

- Devin should tune for **source-doc creation and maintenance**
- not direct idea-first intake from vague conversation

## Implementation tracks

### Track 1: source-doc scaffolding

Implement:

- init/import ensures `source_docs/` and `project_docs/`
- JSON templates created automatically

### Track 2: assumption registry

Implement:

- structured `assumptions_registry.json`
- section/topic-linked assumptions
- mutation/update helpers

### Track 3: ideation refactor

Refactor Devin ideation to:

- update source docs instead of forcing idea primitives first
- produce response guidance from source-doc state + assumptions

### Track 4: background project-doc updater

Implement background process or queued worker that:

- watches source doc changes
- incrementally updates derived project docs

## Suggested source doc schemas

### `product_brief.json`

Contains:

- product summary
- problem statement
- target users
- goals
- scope
- non-goals
- constraints
- success criteria
- assumptions linked by section

### `user_workflows.json`

Contains:

- actors
- primary workflows
- alternate flows
- edge cases
- workflow assumptions

### `domain_entities.json`

Contains:

- entities
- fields/concepts
- relationships
- ownership assumptions

### `assumptions_registry.json`

Contains:

- canonical list of all active assumptions
- links back to source doc sections/topics
- confidence/status metadata

## Important operating rules

- do not regenerate all docs on every turn
- patch targeted sections instead
- source docs are canonical
- project docs are derived
- assumptions must be explicit and traceable
- user should be able to “pull the trigger” at any point and have reasonably complete source docs available, even if still assumption-heavy

## Near-term success criteria

This direction will be working when:

1. repo init/import always creates source-doc/project-doc scaffolding
2. first vague ideation input creates a populated source-doc state
3. each message incrementally patches that state
4. Devin surfaces one relevant assumption/question at a time
5. project docs update asynchronously from source docs via the actual ideation path, not only standalone updater commands
6. source docs are sufficient to generate scopes without requiring manual doc authoring first

As of now, items 1-4 are partially in place, item 5 is only partially wired, and item 6 should be treated as target-state rather than established fact.
