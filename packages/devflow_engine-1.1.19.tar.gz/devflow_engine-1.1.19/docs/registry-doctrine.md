# Registry Doctrine

## What the registry is for

The registry is primarily an **architectural conformance and enforcement substrate**.

Its job is to let implementation proceed, then gate the resulting diff against the repo's canonical architecture before commit.

In practice, the registry exists to answer questions like:

- Which external package is the canonical choice for a domain?
- Which internal module/pathway is the canonical way to perform a responsibility?
- Did a change introduce a heretical package, module, or pathway that should be refactored back to canon?

It is **not** best understood as a general planning graph or a complete story dependency system.

## Core behavior

The intended flow is:

1. bootstrap a registry for the repo during init/import
2. inventory imports, internal modules, and pathway candidates
3. establish canonical module cards and package policy
4. during implementation, allow the agent to work freely
5. before commit, run enforcement against the resulting diff
6. if the diff uses heretical packages or pathways, fail enforcement and drive refactor toward the canonical path

This is an **architectural drift control mechanism**.

## Concrete examples

### External package canon

If an agent implements a feature using a new icon set, but the repo already has a canonical icon package, the registry should allow enforcement to flag the new icon package and direct refactor toward the canonical one.

### Internal pathway canon

If an agent imports a deprecated or heretical internal service path to perform a responsibility, enforcement should flag that usage and direct refactor toward the canonical internal pathway.

Example shape:

- wrong path: `create_new_agent`
- canonical path: `create_new_skill`

The registry should support gating the wrong import/pathway and pushing the implementation back to the canonical one.

## How this appears in code today

The code path in `devflow_engine.cli.app` shows this sequence:

- `devflow register`
  - installs git hooks
  - runs `registry_init(...)`
  - optionally runs module bootstrap
  - refreshes/classifies package policy
  - resolves multiplicity
  - gates packages
  - locks phases and marks project initialized

The important implementation detail is that **implementation DAG commit nodes call `devflow enforce` directly before commit**.

That means registry enforcement matters even when git hooks are bypassed.

## Commit-node behavior

Inside the implementation DAG:

- `GitCommit(GREEN)` runs `devflow enforce`
- `GitCommit(REFACTOR)` runs `devflow enforce`
- commits are created with `git commit --no-verify`

So the authoritative enforcement path during DAG execution is **explicit `devflow enforce` inside the commit nodes**, not reliance on the pre-commit hook.

## What the registry is not yet

The registry is **not yet a complete story dependency graph**.

Today it is much closer to:

- import inventory
- module/pathway inventory
- package-domain policy
- canonical vs heretical architecture enforcement

A future dependency system may build on top of registry data, but that is a separate layer.

## Multi-root repo warning

For multi-root repos, registration/bootstrap must be run with explicit `--root` values for each project-owned source root.

Otherwise a repo can appear `initialized` while producing an empty or misleading registry.

Example failure mode:

- repo is marked initialized
- `.devflow/registry.sqlite` exists
- but scan roots were wrong or incomplete
- so imports/modules were never meaningfully registered

This makes the registry look valid while being operationally useless.

## Practical mental model

When reorienting later, think of registry like this:

> **Registry defines architectural canon. Enforcement checks the diff against that canon before commit. Refactor moves the diff back onto the sanctioned path.**

That is the cleanest way to understand its role in the current system.
