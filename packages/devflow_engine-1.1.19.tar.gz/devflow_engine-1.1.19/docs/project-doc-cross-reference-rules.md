# Project-Doc Cross-Reference Rules

## Purpose

This helper/reference doc defines the internal cross-reference expectations across the minimum project-doc family.

It is intended for:
- project-doc mutation agents
- project-doc coherence node
- review/testing

---

## Core doctrine

The project-doc family should read like one planning system, not five unrelated essays.

Cross-reference expectations:
- `project_charter.md` frames the project at an executive/product level
- `prd.md` expands that into behavior and requirements
- `architecture.md` explains system realization
- `ux_design.md` explains human interaction shape
- `delivery_plan.md` explains sequencing and execution

No project doc should silently redefine another doc’s core assertions.

---

## Required cross-reference expectations

### Charter ↔ PRD
- the product described in the charter must match the product described in the PRD
- goals and scope must align
- target users must align

### PRD ↔ UX Design
- user journeys and interaction flows must align
- UX screens/views should clearly support PRD workflows
- UX assumptions should not contradict PRD requirements

### PRD ↔ Architecture
- functional requirements should be realizable in the architecture doc
- architecture entities/components should support the PRD behaviors

### Architecture ↔ UX Design
- UX flow assumptions should not contradict system/component reality
- architecture constraints that affect UX should be reflected in UX/design considerations

### Delivery Plan ↔ all others
- sequencing should align with scope and priorities
- dependencies should align with architecture and workflow complexity
- risks/watchouts should reflect real product/technical constraints

---

## Coherence failure examples

Examples of coherence failure:
- charter says internal staff tool, PRD reads like customer-facing SaaS
- PRD requires approvals, UX design omits any approval interactions
- workflows imply assignments, architecture omits task ownership model
- delivery plan phases ignore high-risk dependencies stated in architecture

---

## Coherence success condition

Project-doc coherence is good when:
- the docs can be read together without contradiction
- the same users, workflows, entities, scope, and priorities recur consistently
- assumptions are visible where they materially shape a doc
- delivery sequencing makes sense in light of the product and technical story
