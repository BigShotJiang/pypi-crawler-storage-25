# Source-Doc Coherence Node Contract

## Purpose

The coherence/cohesion node exists to ensure the section-by-section source-doc outputs form one internally consistent planning model.

It is not responsible for writing all source docs from scratch.
It is responsible for aligning, resolving, and tightening the section outputs produced upstream.

---

## Inputs

Expected upstream section artifacts:
- `product_brief_section_resolution.json`
- `user_workflows_section_resolution.json`
- `domain_entities_section_resolution.json`

Optional supporting context:
- existing canonical source docs
- current assumptions registry
- repo evidence packet
- input/history grounding packet

---

## What it must check

### Product ↔ workflows consistency
- do target users align with workflow actors?
- do goals align with primary workflows?
- does scope align with actual workflow shape?

### Workflows ↔ entities consistency
- do workflows imply entities that are missing?
- do entity relationships support the workflows described?
- do ownership assumptions fit the workflow behavior?

### Product ↔ entities consistency
- does the product framing imply data/business objects that are absent?
- do constraints/non-goals conflict with entity assumptions?

### Assumption consistency
- do assumptions contradict one another?
- are the same gaps assumed differently in different sections?
- are assumptions specific enough to support persistence?

### Richness consistency
- is one section still too thin relative to the others?
- would downstream project-doc generation break because one section is materially underdeveloped?

---

## Outputs

Suggested artifact:
- `source_doc_coherence_resolution.json`

Should contain:
- merged source-doc section payloads
- cross-section conflicts found
- conflict resolutions applied
- assumptions normalized/aligned
- remaining thinness or escalation reasons if any

---

## Success condition

The node succeeds when:
- section outputs no longer materially contradict each other
- the combined source-doc set is coherent enough to persist canonically
- assumptions are explicit and non-conflicting
- downstream project-doc generation can trust the merged source-doc model as a usable planning base

---

## Failure / escalation condition

The node should fail or escalate when:
- section outputs fundamentally conflict and cannot be reconciled credibly
- one or more sections remain too thin to support a coherent whole
- assumptions required for coherence would be too speculative to justify

---

## Important doctrine

This node may improve consistency and depth, but it must not silently erase traceability.
If it resolves conflicts by choosing one assumption/model over another, that resolution should remain visible in the artifact.
