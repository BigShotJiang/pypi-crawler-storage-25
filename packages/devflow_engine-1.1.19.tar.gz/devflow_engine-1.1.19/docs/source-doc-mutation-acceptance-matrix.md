# Source Doc Mutation DAG Acceptance Matrix

Grounded against the current first-class `source_doc_mutation_dag` workflow contract and its emitted artifacts.

## Required architecture contract

Marcus's planned canonical DAG for `source_doc_mutation_dag` is:

1. `NormalizeAndGatherSupportContextNode`
2. parallel source section agents:
   - `ProductBriefSectionAgentNode`
   - `UserWorkflowsSectionAgentNode`
   - `DomainEntitiesSectionAgentNode`
3. `SourceDocCoherenceNode`
4. `PersistSourceDocsAndAssumptionsNode`
5. `ProjectDocImpactRoutingNode`
6. `SpawnProjectDocMutationSubagentsNode`
7. `AwaitProjectDocMutationSubagentsNode`
8. `ProjectDocCoherenceNode`
9. `PersistProjectDocsNode`

Mandatory semantics:
- the three section agent nodes are parallel siblings under the same source-context packet
- all project-doc mutation subagents spawned by node 6 must complete before node 8 begins
- helper substitutes, collapsed chains, or renamed pseudo-equivalents are not acceptable contract matches

## Current runtime status

The checked-in runtime is still transitional and does **not** yet implement the required graph above.

Current emitted node list:

1. `NormalizeMutationRequestNode`
2. `InventorySourceDocsNode`
3. `DetermineMutationPlanNode`
4. `ApplyExplicitPayloadNode`
5. `ApplyDeterministicMutationNode`
6. `ReconcileAssumptionsNode`
7. `PersistSourceDocsNode`
8. `SyncDerivedProjectDocsNode`
9. `FinalizeMutationArtifactsNode`

Current doctrine:
- nodes 1-4 and 6-9 are deterministic contract/persistence/rendering steps
- `ApplyDeterministicMutationNode` is an explicitly transitional deterministic heuristic node kept only so the current runtime still works
- the runtime must not be described as already satisfying the planned agentic section-node architecture
- project-doc mutation subagents, project-doc coherence, and the required await barrier are still absent from the live DAG

## Artifacts currently emitted

- `source_doc_inventory.json`
- `source_doc_mutation_plan.json`
- `source_doc_mutation_result.json`
- `source_doc_change_set.json`
- `assumptions_delta.json`
- `project_doc_sync_result.json`

## Scenario matrix

1. **New project idea bootstrap (ideation_mutation)**
   - Input: fresh repo + vague idea (`Need a platform for office and field teams.`)
   - Asserted:
     - canonical source docs scaffold exists
     - derived v2 project docs render
     - `product_brief.json` is populated
     - assumptions registry is created and populated with open gaps for problem and scope
   - Notes:
     - aligned to current deterministic ideation mutation behavior, not the required future agent-backed section architecture

2. **Existing grounded CHI source docs (ideation_mutation over already-grounded docs)**
   - Input: repo-local CHI fixture copied from `chi-webapp` source docs + grounded CHI dashboard prompt
   - Asserted:
     - canonical docs remain grounded and render into derived docs
     - no fake assumptions are invented for already-established CHI facts
     - leadership/board users and dashboard/report constraints remain intact
   - Notes:
     - validates current grounded behavior only

3. **Well-formed docs + targeted mutation + assumption update (ideation_mutation)**
   - Input: schema-valid scaffold + pre-existing stale open goal assumption + vague intake
   - Asserted:
     - only affected artifacts mutate (`product_brief.json`, `assumptions_registry.json`)
     - same-topic inferred goal assumption remains open and gets refreshed from the new message id
     - unaffected workflow/entity docs stay untouched
     - derived docs rerender for changed artifacts
   - Notes:
     - matches the current runtime's limited deterministic mutation capability

4. **Repo bootstrap from genuine repo evidence (repo_bootstrap)**
   - Input: no user message + fixture repo with README/docs describing service-team dashboard workflows
   - Asserted:
     - DAG inspects repo files first
     - request stays in `repo_bootstrap`
     - initial source docs are grounded from repo evidence rather than invented from thin air
     - derived project docs/index are emitted under the v2 path
   - Notes:
     - current threshold is deterministic: require README signal, at least 2 matched signal files, at least 3 distinct domain tokens, and at least 3 signal buckets across product/workflow/entity/scope terms

5. **Sparse repo scaffold downgrade (repo_bootstrap -> scaffold_only)**
   - Input: no user message + sparse repo with insufficient evidence
   - Asserted:
     - DAG explicitly downgrades to `scaffold_only`
     - source docs stay empty/minimal templates
     - derived project docs are shell-only renders with an index that explicitly says scaffold-only fallback
     - artifacts record the downgrade and `no_source_doc_changes` trust level
   - Notes:
     - required anti-hallucination case for init/import/bootstrap flows

6. **Required architecture alignment**
   - Status: explicitly blocked / xfail until the implementation mutation lands
   - Required assertions:
     - `dag_shape.start_node == "NormalizeAndGatherSupportContextNode"`
     - `dag_shape.node_sequence` exactly matches the required nine-step architecture above
     - `dag_shape.parallel_source_section_nodes == ["ProductBriefSectionAgentNode", "UserWorkflowsSectionAgentNode", "DomainEntitiesSectionAgentNode"]`
     - `dag_shape.project_doc_subagent_barrier.all_spawned_subagents_must_complete_before == "ProjectDocCoherenceNode"`
   - Why blocked:
     - live runtime still emits the old deterministic chain instead of the planned graph

7. **Contradiction handling**
   - Status: explicitly blocked / xfail
   - Why blocked:
     - current `source_doc_mutation_dag` does not emit contradiction-specific routing, gates, or artifacts
     - pretending otherwise would be fake-success acceptance

## Fixture provenance

- `tests/fixtures/source_doc_mutation/chi/*` is grounded from:
  - `/Users/devflow/repos/chi-webapp/ai_docs/context/source_docs/*.json`
- `tests/fixtures/source_doc_mutation/bootstrap_repo/*` is local deterministic repo evidence used to exercise repo-bootstrap behavior

## Runtime gap called out explicitly

The current deterministic source-doc mutation path can:
- scaffold source docs
- patch limited source-doc fields heuristically (`product_brief` plus actor-list extension when directly grounded)
- extend richer workflow/entity sections only when they are supplied explicitly via source-doc payloads
- reconcile linked assumptions against changed canonical docs during the same DAG run
- render derived markdown docs
- bootstrap from repo README/docs when enough deterministic signal exists
- downgrade cleanly to scaffold-only when repo evidence is too sparse

It cannot currently, by contract:
- satisfy Marcus's required node graph
- run the three source section nodes as parallel agent nodes
- route project-doc impact into spawned mutation subagents plus a required await barrier
- run project-doc coherence after all spawned project-doc mutations finish
- reason over contradictions as a first-class outcome
- emit contradiction review packages
- treat heuristic workflow/entity synthesis from token matches as an authorized happy path
- prove assumptions against broader repo code/docs beyond the deterministic repo-evidence threshold
