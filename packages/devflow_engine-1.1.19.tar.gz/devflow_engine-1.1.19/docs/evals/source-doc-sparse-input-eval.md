# Eval: Sparse Input -> Rich Source Docs + Project Docs

## Purpose

Evaluate whether a sparse initial request still produces:
- rich/deep canonical source docs
- a complete five-document project-doc suite
- explicit assumptions where detail had to be inferred

This eval is intended to drive prompt, contract, coherence, and downstream project-doc improvements.

---

## Scenario

Input:

> Build a task app that lets me create tasks and assign them to staff.

Mode:
- real LLM runtime only
- no stub fallback accepted for quality evaluation

---

## Expected source-doc outcomes

### `product_brief.json`
Must be fully formed and materially populated:
- `product_summary`
- `problem_statement`
- `target_users`
- `goals`
- `scope.in_scope`
- `scope.out_of_scope`
- `non_goals`
- `constraints`
- `success_criteria`
- `assumptions`

Quality expectations:
- target users are roleful/specific, not just a generic blob
- problem statement is concrete
- scope contains meaningful capabilities, not only one vague line
- assumptions are explicit where sparse input forced inference

### `user_workflows.json`
Must include:
- `actors`
- `primary_workflows`
- `alternate_flows`
- `edge_cases`
- `workflow_assumptions`

Quality expectations:
- at least one primary workflow has clear trigger/actor/steps/result shape
- alternate/edge behavior is not empty if it is clearly implied
- workflow assumptions are explicit where behavior had to be filled in

### `domain_entities.json`
Must include:
- `entities`
- `relationships`
- `ownership_assumptions`

Quality expectations:
- entities have meaning, not just names
- relationships exist and are relevant
- ownership assumptions are explicit where needed

### `assumptions_registry.json`
Must include explicit localized assumptions for the major inferred gaps.

Quality expectations:
- assumptions are linked to doc/section/topic
- assumptions are specific enough to explain why the docs are complete despite sparse input

---

## Expected project-doc outcomes

Must produce all five:
- `project_charter.md`
- `prd.md`
- `architecture.md`
- `ux_design.md`
- `delivery_plan.md`

### `project_charter.md`
Must contain:
- Overview
- Problem / Opportunity
- Target Users
- Goals
- Scope
- Non-Goals
- Constraints
- Success Criteria

### `prd.md`
Must contain:
- Product Overview
- User Roles
- Core User Journeys
- Functional Requirements
- Alternate / Exceptional Flows
- Acceptance-Oriented Behavior Notes
- Assumptions

### `architecture.md`
Must contain:
- System Overview
- Core Entities / Data Model
- Key Relationships
- Components / Surfaces
- Integrations
- Constraints / Risks
- Open Architectural Assumptions

### `ux_design.md`
Must contain:
- UX Overview
- Primary User Flows
- Key Screens / Views
- Important Interactions
- Edge / Error Experiences
- UX Assumptions

### `delivery_plan.md`
Must contain:
- Delivery Strategy
- Phases / Milestones
- Implementation Priorities
- Dependencies
- Risks / Watchouts
- Recommended Next Steps

---

## Pass / fail criteria

### Hard pass
- all four canonical source docs exist
- all five project docs exist
- all required headings are present
- source-doc sections are materially populated, not shell-only
- assumptions are explicit and localized
- project docs are materially populated, not thin mirrors

### Hard fail
- any required source-doc section materially empty
- any required project doc missing
- any required heading missing
- shell/scaffold output presented as complete rich docs
- hidden inference with no assumptions trail

---

## Quality review checklist

- Are target users specific enough to guide design/workflow work?
- Are workflows concrete enough to drive PRD + UX?
- Are entities/relationships concrete enough to support architecture?
- Are assumptions reasonable and useful rather than generic filler?
- Do the five project docs read like a coherent family?
- Would a downstream implementation agent have enough context to begin work?

---

## Notes

This eval should prefer quality over speed.
The goal is not proving the DAG runs; the goal is proving the output is genuinely useful.
