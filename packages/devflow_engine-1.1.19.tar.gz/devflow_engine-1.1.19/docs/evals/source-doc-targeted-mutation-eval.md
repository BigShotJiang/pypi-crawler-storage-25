# Eval: Targeted Mutation -> Accurate Cross-Document Propagation

## Purpose

Evaluate whether a focused update causes meaningful, accurate changes across all affected source docs and project docs without unrelated drift.

---

## Scenario

### Base input

> Build a task app that lets me create tasks and assign them to staff.

### Mutation input

> Add due dates, priority levels, and reassignment approvals.

Mode:
- real LLM runtime only
- no stub fallback accepted for quality evaluation

---

## Expected mutation behavior

The update should propagate into all relevant planning artifacts.
It should be:
- meaningful
- accurate
- surgical where possible
- coherent across source docs and project docs

It should not:
- rewrite unrelated sections gratuitously
- drop prior planning content without reason
- leave obvious affected docs unchanged

---

## Expected source-doc changes

### `product_brief.json`
Likely changed sections:
- `scope.in_scope`
- possibly `constraints`
- possibly `success_criteria`
- `assumptions` if new inferred behavior is required

### `user_workflows.json`
Likely changed sections:
- `primary_workflows`
- `alternate_flows`
- `edge_cases`
- `workflow_assumptions`

Expected meaning:
- due dates affect task lifecycle/use flow
- priority levels affect sorting/urgency behavior
- reassignment approvals affect decision points and alternate flows

### `domain_entities.json`
Likely changed sections:
- `entities`
- `relationships`
- `ownership_assumptions`

Expected meaning:
- task entity likely gains due date + priority attributes
- reassignment approval may imply approval/assignment state or relationship changes

### `assumptions_registry.json`
Expected:
- new assumptions added only where needed
- existing assumptions updated/superseded if the mutation clarifies prior uncertainty

---

## Expected project-doc changes

### `project_charter.md`
Should change only if the mutation materially changes high-level scope framing.

### `prd.md`
Should definitely change.
Expected updates:
- functional requirements
- user journeys / alternate flows
- assumptions

### `architecture.md`
Should change if:
- entities change
- relationships change
- approval behavior implies new system/state structure

### `ux_design.md`
Should change if:
- due dates/priority/approvals change user interactions, views, or edge states

### `delivery_plan.md`
Should change if:
- mutation adds sequencing/dependency/risk implications

---

## Pass / fail criteria

### Hard pass
- affected source docs changed in the expected areas
- affected project docs changed in the expected areas
- unrelated docs remain materially stable unless truly impacted
- assumptions updated correctly
- resulting doc family remains coherent

### Hard fail
- mutation does not propagate to obviously affected artifacts
- unrelated artifacts drift substantially
- prior content is overwritten or lost without reason
- assumptions remain stale when the mutation should alter them
- project docs contradict updated source docs

---

## Quality review checklist

- Did due dates appear in workflows, requirements, UX, and architecture where appropriate?
- Did priority levels appear where they materially affect behavior or structure?
- Did reassignment approvals affect workflows, PRD, architecture, and possibly delivery planning?
- Were changes narrow and meaningful rather than broad and sloppy?
- Are source docs and project docs still aligned after mutation?
- If assumptions changed, are those changes visible and reasonable?

---

## Notes

This eval is intended to prove that mutation is not just rewriting docs, but intelligently propagating specific changes across the planning set.
