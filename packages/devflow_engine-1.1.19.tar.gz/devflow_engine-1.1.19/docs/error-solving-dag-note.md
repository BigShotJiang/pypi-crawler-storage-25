# Error-Solving DAG Note

## Current state in `devflow_engine`

`devflow_engine` does **not** currently have a first-class error-solving DAG module comparable to the recovery DAG.

What exists today is legacy inline/service-style error-solving logic in:
- `src/devflow_engine/cli/app.py`

Relevant clue in code:
- around `app.py:4870+`
- prompt text includes:
  - `You are Devin, an automated error solver.`

This means the existing error-solving path in `devflow_engine` is:
- present
- story/error oriented
- but **not** modeled as a proper standalone DAG/module yet

## Important architecture note

This was identified as legacy/problematic architecture.

The intended long-term direction is **not** to keep growing the inline/service implementation in `cli/app.py`.
Instead, error solving should be reimplemented as a first-class DAG with a clean queue/worker contract, parallel to the new recovery DAG work.

## External reference / source of truth for intended pattern

The legacy DevFlow Electron app has a **first-party error-solving DAG** implementation (written in Node).
That app should be treated as the reference implementation to inspect when porting/implementing the proper error-solving DAG in `devflow_engine`.

## Why this note exists

We traced multiple clues while trying to place an error-solving queue after recovery:
- `runtime_errors` helped identify the old error-solving path
- but that path led to inline/service logic in `cli/app.py`, not a proper DAG module

This distinction matters:
- the recovery queue can be implemented cleanly now
- the error-solving queue should **not** be wired to the legacy inline/service flow as if it were already a proper DAG substrate
- instead, the proper next step is to port/implement the first-party error-solving DAG pattern from the Electron app into `devflow_engine`

## Recommendation

When this work is picked up:
1. inspect the Node-based first-party error-solving DAG in the legacy DevFlow Electron app
2. document its input contract, node sequence, and queue contract
3. implement a real error-solving DAG in `devflow_engine`
4. only then add a first-class error-solving queue to sit after recovery and before source-doc mutation in queue priority
