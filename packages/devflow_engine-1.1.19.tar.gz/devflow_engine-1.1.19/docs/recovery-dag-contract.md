# Recovery DAG Contract

## Purpose

Recover failed queue items without assuming a deterministic-first repair path.

## Core doctrine

Recovery is agentic first:
1. load failed queue item
2. investigate failure agentically
3. route code error vs process error
4. diagnose recovery strategy agentically
5. execute recovery agentically
6. verify recovery agentically
7. publish outcome

## Node sequence

- `LoadFailedQueueItemNode`
- `AgenticFailureInvestigationNode`
- `FailureTypeRouter`
- `AgenticRecoveryDiagnosisNode` (process path)
- `RecoveryStrategyRouter`
- `AgenticRecoveryExecutionNode`
- `RecoveryVerificationNode`
- `PublishRecoveryStateNode`

## Routing

### `FailureTypeRouter`
- `code_error` -> `AgenticRecoveryExecutionNode` with delegation outcome
- `process_error` -> `AgenticRecoveryDiagnosisNode`

### `RecoveryStrategyRouter`
- `handoff_to_code_error`
- `replay_boundary_recovery`
- `state_reconciliation_recovery`
- `artifact_regeneration_recovery`
- `escalate_process_bug`

## Agentic nodes

These nodes are model-backed and must not be heuristic stubs:
- `AgenticFailureInvestigationNode`
- `AgenticRecoveryDiagnosisNode`
- `AgenticRecoveryExecutionNode`
- `RecoveryVerificationNode`

## Durable artifacts

- `FailedQueueItemArtifact`
- `RecoveryInvestigationArtifact`
- `RecoveryDiagnosisArtifact`
- `RecoveryExecutionArtifact`
- `PreReplayCheckArtifact`
- `ReenqueueArtifact`
- `RecoveryOutcomeArtifact`

## Outcome doctrine

Recovery may end in:
- `reenqueued`
- `delegated`
- `blocked`
- `recovered`

`PublishRecoveryStateNode` is responsible for surfacing the terminal recovery state into DFS.
