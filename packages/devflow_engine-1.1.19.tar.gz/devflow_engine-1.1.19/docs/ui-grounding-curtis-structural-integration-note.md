# UI grounding follow-on note: structural integration layer

Context: the Curtis medium-tier note established that customer-facing wireframe output should default to medium fidelity, not skeletal low-fi. The next gap is not more rendering detail. It is the missing layer between **planning/discovery** and **development/rendering implementation**.

Cross-link: see `docs/ui-grounding-curtis-medium-tier-doctrine.md`.

## Revision plan

The DFE UI path should explicitly separate three artifact classes:

### 1. Planning / discovery artifacts
Purpose: decide **what** surfaces exist, why they matter, and what is still unknown.

Examples:
- `ui_surface_derivation.json`
- `ui_reference_inventory.json`
- `ui_grounding_report.json`
- `ui_screen_inventory.json` from the Curtis medium-tier doctrine

These artifacts are about:
- candidate screens and journeys
- grounding strength and gaps
- target fidelity / audience
- open questions and assumptions

They should not pretend implementation structure already exists.

### 2. Structural design integration artifacts
Purpose: translate the planning package into a durable, implementation-adjacent UI contract that says **how the screen set hangs together** before actual rendering work starts.

This is the missing layer.

It should define things like:
- canonical screen set and screen ordering
- flow / transition relationships
- shared layout shells
- reusable sections / regions
- state variants that must exist
- data/interaction dependencies at the screen level
- traceability back to grounding and planning inputs

This layer is where design intent becomes a stable integration contract rather than staying a loose planning inventory.

### 3. Development / rendering implementation artifacts
Purpose: produce the actual implementation-facing or renderer-facing outputs.

Examples:
- Pencil files / exports
- rendered wireframe images
- component/layout specs
- implementation annotations
- downstream story / DFUS patches that depend on the integrated screen structure

These artifacts answer **what gets built or rendered**, not **how the design package is structurally organized**.

## Proposed missing node

Add a node after planning/grounding and before rendering generation:

- `IntegrateUIScreenStructureNode`

Recommended placement:

```text
Load context
-> Derive UI surfaces
-> Inventory existing refs
-> Match refs / gap report
-> Optional code->design enrichment
-> Plan wireframe output
-> Integrate UI screen structure (NEW)
-> Generate wireframe / design package
-> Patch story refs + finalize
```

## What `IntegrateUIScreenStructureNode` should do

Inputs:
- `ui_grounding_report.json`
- `ui_screen_inventory.json`
- any approved design refs / code-derived refs / story refs already in the run

Responsibilities:
1. Freeze the canonical screen list for this package.
2. Group screens into flows / subflows / review packet order.
3. Define shared shells, regions, and repeated structural patterns.
4. Expand required state variants where planning already implies them.
5. Record screen-to-screen transitions and dependency edges.
6. Carry forward confidence, assumptions, and unresolved questions at the structural level.
7. Emit a clean package that rendering/implementation steps can consume without re-interpreting planning intent.

## Byproduct artifacts the node should emit

Minimum suggested outputs:

- `ui_structure_contract.json`
  - canonical integrated screen package
  - screen ordering, flow grouping, transition graph, shared regions, required states

- `ui_flow_map.json`
  - explicit journey/transition map for customer, admin, field, or support flows

- `ui_screen_relationships.json`
  - parent/child, variant, shared-shell, and dependency relationships

- `ui_generation_manifest.json`
  - renderer-facing manifest that says exactly which screens/variants should now be generated

Optional but useful:

- `ui_open_questions_register.json`
  - unresolved questions promoted from planning into structural review

- `ui_traceability_map.json`
  - links integrated screens back to surface derivation, grounding refs, and story refs

## Why this split matters

Without the structural integration layer, the system tends to collapse two different jobs into one:
- planning artifacts try to do too much implementation work
- rendering steps have to infer structure that should have been explicit upstream

That leads to brittle output, hidden assumptions, and inconsistent screen packages.

The cleaner rule is:
- planning/discovery decides **what exists and what is grounded**
- structural integration decides **how the approved screen set coheres**
- rendering/implementation decides **how to materialize it**

## Decision statement

The next DFE UI-grounding revision should add an explicit **structural design integration** stage, not jump directly from planning artifacts to rendering artifacts.

`ui_screen_inventory.json` is the right planning output.
`IntegrateUIScreenStructureNode` and its structural byproducts are the missing bridge into reliable generation and downstream implementation.