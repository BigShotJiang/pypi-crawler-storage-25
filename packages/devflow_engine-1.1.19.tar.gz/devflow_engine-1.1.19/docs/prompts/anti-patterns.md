# Prompt anti-patterns

This is the canonical home for prompt anti-pattern notes in `devflow_engine`.

Scope split:
- prompt design guidance and anti-patterns live under `docs/prompts/`
- runtime skill artifacts live under `src/devflow_engine/skills/...` as described in `docs/devflow-skill-registry-spec.md`

Keep this list short and concrete. Add an entry when it changes prompt quality or agent correctness in a recurring way.

## Context smuggling

**Definition:** leaking author-side orchestration, internal jargon, or non-local workflow context into a node/agent prompt that does not actually have that local context.

Common examples:
- telling an agent to "use the output from Node 1" or "continue what Node 2 already established" when that material is not present in the prompt payload
- referencing GenAI DAG internals, route names, or pipeline stage assumptions that are meaningful to the prompt author but not to the receiving agent
- writing prompts that depend on hidden repo/process knowledge instead of the explicitly provided task inputs

Why it is harmful:
- creates fake coherence: the prompt sounds specific, but the agent cannot actually ground the references
- encourages hallucinated continuity and invented dependencies
- makes prompts brittle when nodes are reused, reordered, or evaluated in isolation
- hides the real contract the node needs in order to work correctly

Preferred correction:
- restate the local task in terms of the inputs the node actually receives
- pass required upstream artifacts explicitly instead of naming invisible pipeline steps
- replace internal orchestration references with bounded, self-contained instructions
- if an agent truly needs workflow metadata, include that metadata as explicit input, not implied context

## Hidden approval boundary

Stub: prompts that imply permission to proceed across a human approval gate without explicitly stating whether approval has been given.

## State inflation

Stub: prompts that collapse distinct states such as drafted, persisted, queued, started, and completed into one vague notion of "in progress".

## Tool-shaped prompt leakage

Stub: prompts that bake in harness/tool mechanics too early, instead of expressing the task and only layering tool-specific constraints where they are actually required.
