# DevFlow queue operations skill tree

## Purpose

This adds the next concrete DevFlow skill layer for **queue/runtime operations and investigation**.

The shape is intentionally **skills-first, tools-second**:
- the first thing operators/agents need is correct doctrine about what to inspect, what state means, and what not to claim
- the same operational recipe may be executed through CLI, SQL, a future helper, or a harness-specific tool surface
- building tools before the doctrine would hard-code shaky assumptions about queue truth, success, and failure boundaries

These artifacts are therefore **canonical operational skills/modules**, not a new runtime framework.

## Tree

```text
src/devflow_engine/skills/builtins/devflow/
  queue_runtime_core/
    SKILL.md
  queue_idea_to_story/
    SKILL.md
  queue_story_implementation/
    SKILL.md
  queue_integration/
    SKILL.md
  queue_recovery/
    SKILL.md
  queue_failure_investigation/
    SKILL.md
```

## Why this split

### 1. One shared core doctrine

`devflow/queue_runtime_core` owns the cross-cutting runtime truths:
- worker state is not queue state
- queued is not started
- started is not finished
- deterministic observation comes before progress claims
- DB state, run state, artifacts, and logs must be correlated instead of blurred together

### 2. Flow modules stay operationally concrete

Each flow module answers the same operator questions for its lane:
- how to kick the flow
- how to observe it
- where to look first when it fails
- what success/blockage actually means
- which repeated actions deserve a future helper/tool

### 3. Tools remain downstream of doctrine

These skills explicitly name strong future tool candidates, but do not require a single tool surface.
That keeps the doctrine:
- harness-agnostic
- reusable in prompt assembly
- valid whether the operator uses CLI, SQL, or a later DevFlow-native helper

## Flow boundaries

### Existing Devin ideation / handoff skills

Already present:
- `devin/ideation`
- `devin/idea_to_story_handoff`

Those skills own:
- conversational ideation behavior
- approval/readiness truthfulness
- the boundary between persisted idea state and downstream queue state

The new queue-operation skills start **after** or **around** runtime execution concerns:
- queue kick / drain
- worker observation
- failure investigation
- recovery
- integration follow-through

So the overlap is intentional but non-redundant:
- **Devin ideation skills** explain what may be said and promised in conversation
- **DevFlow queue operation skills** explain how to operate and inspect the actual runtime lane

### Queue lane mapping

- `queue_idea_to_story` -> `idea_queue` and the story-generation pipeline
- `queue_story_implementation` -> `story_queue` and `worker.story.execute`
- `queue_integration` -> `integration_queue` and integration DAG runs
- `queue_recovery` -> `recovery_queue` and post-failure recovery execution
- `queue_failure_investigation` -> cross-cutting inspection doctrine for failed/blocked/churning work

## Core repo surfaces these skills reference

Current operational anchors in this repo:
- worker control: `devflow worker start|stop|report|recover`
- Supabase event ingestion: `devflow worker supabase-events`
- integration helpers: `devflow integration prepare|enqueue|run|status|backfill`
- execution DB: `.devflow/execution.sqlite`
- primary runtime tables:
  - `project_workers`
  - `runs`
  - `nodes`
  - `artifacts`
  - `errors`
  - `idea_creation_queue`
  - `idea_queue`
  - `story_queue`
  - `integration_queue`
  - `recovery_queue`
- log-first investigation surfaces:
  - `/Users/devflow/.devflow/llm_logs/*.jsonl`
  - `/Users/devflow/.devflow/llm_sessions.sqlite`

## Strong future tool/helper candidates

Repeated actions that are good future tool candidates:
- worker snapshot / active-item summary
- queue row summary per flow with run correlation
- failed-item inspection with first evidence links
- wrapper-run to child-run correlation for story execution
- recovery handoff locator / summary reader
- integration payload and latest-run status reader
- latest failed idea / idea-creation retry helpers
- queue blockage/churn explainer

## Non-goals of this slice

This slice does **not**:
- add new queue runtime code paths
- add a new hidden resolver/runtime layer
- replace existing docs like `docs/recovery-dag-contract.md`
- claim all queue flows are fully normalized already

It adds the canonical operational skill tree so future bindings/helpers can target something stable.
