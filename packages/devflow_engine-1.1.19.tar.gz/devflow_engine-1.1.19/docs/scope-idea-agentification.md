# Scope->Idea agentification notes

This pass makes the interpretation-heavy scope->idea nodes genuinely model-backed on the primary runtime path:

- `AssessScopeGoldilocksNode`
- `SplitScopeIntoIdeaCandidatesNode`
- `DraftIdeaFromScopeNode`

## Runtime contract

- Primary path: `scope_idea.agentic.run_scope_idea_agent_step(...)`
- Envelope persistence when model-backed path succeeds: `.devflow/scopes/<scope_id>/pipelines/scope_to_idea_dag/<pipeline_key>/agent_runs/<node>.json`
- Deterministic shaping remains explicit fallback only
- Approved scope remains the anchor
- Canonical idea sufficiency remains downstream
- Onboarding implementation stays untouched

## What is still fallback / heuristic

Deterministic logic still exists for:

1. `AssessScopeGoldilocksNode`
   - `_heuristic_goldilocks(...)` provides test-safe scaffolding and failure fallback
   - used when pytest guard is active unless `DEVFLOW_ENABLE_SCOPE_IDEA_AGENT=1`
   - used when agent execution/config/output validation fails

2. `SplitScopeIntoIdeaCandidatesNode`
   - `_group_scope_bullets(...)` and related deterministic idea shaping provide fallback child-idea packaging
   - used only if the model-backed step is unavailable/fails or when pytest guard blocks live execution

3. `DraftIdeaFromScopeNode`
   - deterministic candidate drafting from scope bullets remains fallback packaging
   - used only if the model-backed step is unavailable/fails or when pytest guard blocks live execution

## Test doctrine

Tests do not require live model execution.

- area12 tests monkeypatch `scope_idea.agentic.run_scope_idea_agent_step` to return validated artifacts plus persisted envelopes
- an explicit fallback test verifies deterministic behavior still works when the agent step fails
