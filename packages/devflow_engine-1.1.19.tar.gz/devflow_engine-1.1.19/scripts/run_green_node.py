#!/usr/bin/env python3
from __future__ import annotations

import argparse
import asyncio
import json
import os
import shutil
import sys
import tempfile
import uuid
from pathlib import Path
import re

REPO_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO_ROOT / "src"))

from run_red_node import _load_latest_artifact_metadata, _load_story_from_canonical_docs
from devflow_engine.implementation import dag as implementation_dag
from devflow_engine.stores.execution_store import ExecutionStore
from devflow_engine.llm.execution_context import execution_context
from devflow_engine.vendor.datalumina_genai.core.task import TaskContext


def _effective_global_devflow_dir() -> Path:
    devflow_home = os.environ.get("DEVFLOW_HOME")
    if devflow_home:
        return Path(devflow_home).expanduser() / ".devflow"
    return Path.home() / ".devflow"


def _seed_isolated_global_config(*, isolated_root: Path) -> None:
    source_config_path = _effective_global_devflow_dir() / "config.toml"
    if not source_config_path.exists():
        return
    isolated_devflow = isolated_root / ".devflow"
    isolated_devflow.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source_config_path, isolated_devflow / "config.toml")


def main() -> int:
    ap = argparse.ArgumentParser(description="Run only the implementation Green node for a registered story")
    ap.add_argument("story_id")
    ap.add_argument("--repo-root", required=True)
    args = ap.parse_args()

    repo_root = Path(args.repo_root).resolve()
    source_db_path = repo_root / ".devflow" / "execution.sqlite"
    story = _load_story_from_canonical_docs(repo_root, args.story_id)
    if story is None:
        raise SystemExit(f"story not found: {args.story_id}")

    test_design = _load_latest_artifact_metadata(source_db_path, kind="test_design", story_id=args.story_id)
    implementation_planning = _load_latest_artifact_metadata(source_db_path, kind="implementation_planning", story_id=args.story_id)
    red_result = _load_latest_artifact_metadata(source_db_path, kind="red_report", story_id=args.story_id)
    story_verification_reconciliation = _load_latest_artifact_metadata(source_db_path, kind="story_sufficiency_reconciliation", story_id=args.story_id)

    with tempfile.TemporaryDirectory(prefix="devflow-green-harness-") as tmp_dir:
        isolated_root = Path(tmp_dir)
        isolated_devflow = isolated_root / ".devflow"
        isolated_story_state_root = isolated_devflow / "stories"
        _seed_isolated_global_config(isolated_root=isolated_root)
        safe_story_id = re.sub(r"[^A-Za-z0-9_.-]+", "_", args.story_id) or "unknown_story"
        source_story_state_dir = repo_root / ".devflow" / "stories" / safe_story_id
        if source_story_state_dir.exists() and source_story_state_dir.is_dir():
            shutil.copytree(
                source_story_state_dir,
                isolated_story_state_root / safe_story_id,
                dirs_exist_ok=True,
            )
        store = ExecutionStore(isolated_devflow / "execution.sqlite")
        run_id = store.create_run(
            dag_id="implementation_green_harness",
            dag_version="v1",
            root_correlation_id=f"green_harness:{uuid.uuid4()}",
            config={
                "story_id": story.get("story_id"),
                "story_uuid": (story.get("contract") or {}).get("story_uuid"),
                "isolated_harness": True,
            },
        )
        store.mark_run_started(run_id=run_id)

        implementation_dag._CURRENT_STORE = store
        implementation_dag._CURRENT_RUN_ID = run_id
        prior_devflow_home = os.environ.get("DEVFLOW_HOME")
        os.environ["DEVFLOW_HOME"] = str(isolated_root)
        try:
            with execution_context(
                run_id=run_id,
                dag_id="implementation_green_harness",
                repo_root=repo_root,
                story_id=story.get("story_id"),
                story_uuid=(story.get("contract") or {}).get("story_uuid"),
                story_title=story.get("title"),
                devflow_story_state_root=str(isolated_story_state_root),
                devflow_isolated_harness=True,
            ):
                ctx = TaskContext(event=implementation_dag.ImplementationEvent(repo_root=str(repo_root), story=story))
                ctx.metadata["test_design"] = test_design
                ctx.metadata["implementation_planning"] = implementation_planning
                if red_result:
                    ctx.metadata["red_report"] = red_result
                if story_verification_reconciliation:
                    ctx.metadata["story_verification_reconciliation"] = story_verification_reconciliation
                    ctx.metadata["redreview_registered_files"] = [
                        dict(item)
                        for bundle in (story_verification_reconciliation.get("bundles") or [])
                        if isinstance(bundle, dict)
                        for item in (bundle.get("registered_files") or [])
                        if isinstance(item, dict)
                    ]
                result = asyncio.run(implementation_dag.GreenNode().process(ctx))
        finally:
            if prior_devflow_home is None:
                os.environ.pop("DEVFLOW_HOME", None)
            else:
                os.environ["DEVFLOW_HOME"] = prior_devflow_home
            implementation_dag._CURRENT_STORE = None
            implementation_dag._CURRENT_RUN_ID = None

        exit_code = int(result.metadata.get("exit_code") or 0)
        store.mark_run_finished(run_id=run_id, status="succeeded" if exit_code == 0 else "failed")
        sys.stdout.write(json.dumps({
            "run_id": run_id,
            "exit_code": exit_code,
            "message": str(result.metadata.get("message") or ""),
            "story_id": story.get("story_id"),
            "isolated": True,
            "story_state_root": str(isolated_story_state_root),
            "test_design_story_id": test_design.get("story_id"),
            "implementation_planning_story_id": implementation_planning.get("story_id"),
            "green_report": result.metadata.get("green_report"),
        }, indent=2) + "\n")
        return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
