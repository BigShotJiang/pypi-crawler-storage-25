#!/usr/bin/env python3

from __future__ import annotations

import sys
from pathlib import Path

import yaml


def _repo_root() -> Path:
    return Path.cwd().resolve()


def _decisions_path(root: Path) -> Path:
    return root / "ai_docs" / "context" / "v2" / "project_docs" / "architecture" / "decisions.yaml"


def _load_decisions(root: Path) -> list[dict[str, object]]:
    p = _decisions_path(root)
    try:
        raw = yaml.safe_load(p.read_text(encoding="utf-8"))
    except FileNotFoundError:
        return []
    except Exception:
        return []
    if not isinstance(raw, dict):
        return []
    dec = raw.get("decisions")
    if not isinstance(dec, list):
        return []
    out: list[dict[str, object]] = []
    for d in dec:
        if isinstance(d, dict):
            out.append(d)
    return out


def _has_decision(decisions: list[dict[str, object]], *, key: str, value: str) -> bool:
    for d in decisions:
        if str(d.get("key")) == key and str(d.get("value")) == value:
            return True
    return False


def _scan_disallowed_custom_dag_runners(root: Path) -> list[Path]:
    hits: list[Path] = []
    for p in root.rglob("*.py"):
        if "/.venv/" in str(p) or "/node_modules/" in str(p):
            continue
        try:
            text = p.read_text(encoding="utf-8")
        except Exception:
            continue

        if "DEVFLOW_CUSTOM_DAG_RUNNER" not in text:
            continue

        # Exemption: a line like `# DEVFLOW_ARCH_EXEMPT: DEC-001 reason=...`
        if "DEVFLOW_ARCH_EXEMPT:" in text:
            continue

        hits.append(p)
    return hits


def _scan_bespoke_impl_dag_runner(root: Path) -> list[Path]:
    """Detect bespoke implementation DAG runners.

    If the architecture decision workflow_engine=genai_dag is set, bespoke DAG
    runners should be refactored to the GenAI workflow framework.

    We start with a concrete, deterministic rule for this repo:
    - disallow devflow_engine/src/devflow_engine/implementation/dag.py unless explicitly exempted.
    """

    target = root / "devflow_engine" / "src" / "devflow_engine" / "implementation" / "dag.py"
    if not target.exists():
        return []

    try:
        text = target.read_text(encoding="utf-8")
    except Exception:
        return [target]

    if "DEVFLOW_ARCH_EXEMPT:" in text:
        return []

    # Heuristic: if it contains the runner symbol, treat as bespoke.
    if "run_implementation_dag" in text:
        return [target]

    return []


def main(argv: list[str]) -> int:
    _ = argv
    root = _repo_root()
    decisions = _load_decisions(root)

    if _has_decision(decisions, key="workflow_engine", value="genai_dag"):
        hits = _scan_disallowed_custom_dag_runners(root)
        hits.extend(_scan_bespoke_impl_dag_runner(root))
        if hits:
            sys.stdout.write("VALIDATE_ARCHITECTURE FAILED\n")
            sys.stdout.write("decision workflow_engine=genai_dag requires using the GenAI DAG framework\n")
            for p in hits:
                sys.stdout.write(f"disallowed dag implementation: {p}\n")
            return 2

    sys.stdout.write("VALIDATE_ARCHITECTURE OK\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
