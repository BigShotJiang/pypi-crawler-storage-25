#!/usr/bin/env python3
from __future__ import annotations

import argparse
import asyncio
import json
import traceback
from pathlib import Path

from devflow_engine.scope_idea import dag as scope_idea_dag
from devflow_engine.scope_idea.dag import DraftIdeaFromScopeNode, ScopeToIdeaDagEvent, _pipeline_root
from devflow_engine.scope_idea.models import GoldilocksAssessmentArtifact, ScopeContextArtifact
from devflow_engine.stores.execution_store import ExecutionStore
from devflow_engine.vendor.datalumina_genai.core.task import TaskContext


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser()
    p.add_argument("--repo-root", required=True)
    p.add_argument("--project-id", required=True)
    p.add_argument("--scope-id", required=True)
    p.add_argument("--scope-set-id", required=True)
    p.add_argument("--pipeline-key", required=True)
    return p.parse_args()


def main() -> int:
    args = parse_args()
    repo_root = Path(args.repo_root)
    pipeline_root = _pipeline_root(repo_root, scope_id=args.scope_id, pipeline_key=args.pipeline_key)
    scope_context = ScopeContextArtifact.model_validate(json.loads((pipeline_root / "scope_context.json").read_text()))
    goldilocks = GoldilocksAssessmentArtifact.model_validate(json.loads((pipeline_root / "goldilocks_assessment.json").read_text()))

    event = ScopeToIdeaDagEvent(
        repo_root=str(repo_root),
        project_id=args.project_id,
        scope_set_id=args.scope_set_id,
        scope_id=args.scope_id,
        pipeline_key=args.pipeline_key,
    )
    store = ExecutionStore(repo_root / ".devflow" / "execution.sqlite")
    run_id = store.create_run(
        dag_id="scope_to_idea_dag_debug_draft",
        dag_version="debug",
        root_correlation_id=f"debug_draft_{args.scope_id}",
        config={"project_id": args.project_id, "scope_id": args.scope_id, "pipeline_key": args.pipeline_key},
    )
    store.mark_run_started(run_id=run_id)
    scope_idea_dag._CURRENT_STORE = store
    scope_idea_dag._CURRENT_RUN_ID = run_id
    ctx = TaskContext(event=event, metadata={"scope_context": scope_context, "goldilocks_assessment": goldilocks})
    node = DraftIdeaFromScopeNode(task_context=ctx)
    print(json.dumps({"stage": "before_agent_call", "pipeline_root": str(pipeline_root), "run_id": run_id}, indent=2))
    try:
        result = asyncio.run(node.process(ctx))
        artifact = result.metadata.get("idea_candidate")
        store.mark_run_finished(run_id=run_id, status="succeeded")
        print(json.dumps({"stage": "after_agent_call", "artifact": artifact.model_dump() if artifact else None}, indent=2))
        return 0
    except Exception as exc:
        store.mark_run_finished(run_id=run_id, status="failed")
        print(json.dumps({"stage": "exception", "error_type": type(exc).__name__, "error": str(exc), "traceback": traceback.format_exc()}, indent=2))
        return 1
    finally:
        scope_idea_dag._CURRENT_STORE = None
        scope_idea_dag._CURRENT_RUN_ID = None


if __name__ == "__main__":
    raise SystemExit(main())
