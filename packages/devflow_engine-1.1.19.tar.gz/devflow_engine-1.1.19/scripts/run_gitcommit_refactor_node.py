#!/usr/bin/env python3
from __future__ import annotations

import argparse
import asyncio
import json
import sqlite3
import sys
import uuid
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO_ROOT / "src"))

from run_red_node import _ensure_canonical_story_doc, _load_latest_artifact_metadata, _load_story
from devflow_engine.implementation import dag as implementation_dag
from devflow_engine.stores.execution_store import ExecutionStore
from devflow_engine.llm.execution_context import execution_context
from devflow_engine.vendor.datalumina_genai.core.task import TaskContext


def _load_latest_node_output(db_path: Path, *, dag_id: str, node_id: str) -> dict:
    with sqlite3.connect(db_path) as conn:
        conn.row_factory = sqlite3.Row
        row = conn.execute(
            """
            SELECT n.output_json
            FROM nodes n
            JOIN runs r ON r.run_id = n.run_id
            WHERE r.dag_id = ? AND n.node_id = ?
            ORDER BY n.created_at DESC
            LIMIT 1
            """,
            (dag_id, node_id),
        ).fetchone()
    if row is None:
        return {}
    return json.loads(row["output_json"] or "{}")


def main() -> int:
    ap = argparse.ArgumentParser(description="Run only the implementation GitCommit(REFACTOR) node for a registered story")
    ap.add_argument("story_id")
    ap.add_argument("--repo-root", required=True)
    ap.add_argument("--green-run-id")
    ap.add_argument("--refactor-run-id")
    ap.add_argument("--security-run-id")
    args = ap.parse_args()

    repo_root = Path(args.repo_root).resolve()
    store = ExecutionStore(repo_root / ".devflow" / "execution.sqlite")
    story = _load_story(store, args.story_id)
    if story is None:
        raise SystemExit(f"story not found: {args.story_id}")

    _ensure_canonical_story_doc(repo_root, story)
    implementation_planning = _load_latest_artifact_metadata(store.db_path, kind="implementation_planning", story_id=args.story_id)

    def load_specific(run_id: str | None, node_id: str, default_dag: str) -> dict:
        if run_id:
            with sqlite3.connect(store.db_path) as conn:
                conn.row_factory = sqlite3.Row
                row = conn.execute("SELECT output_json FROM nodes WHERE run_id=? AND node_id=? ORDER BY created_at DESC LIMIT 1", (run_id, node_id)).fetchone()
            if row is not None:
                return json.loads(row["output_json"] or "{}")
        return _load_latest_node_output(store.db_path, dag_id=default_dag, node_id=node_id)

    green_report = load_specific(args.green_run_id, "green", "implementation_green_harness")
    refactor_report = load_specific(args.refactor_run_id, "refactor", "implementation_refactor_harness")
    security_report = load_specific(args.security_run_id, "security", "implementation_security_harness")

    run_id = store.create_run(
        dag_id="implementation_gitcommit_refactor_harness",
        dag_version="v1",
        root_correlation_id=f"gitcommit_refactor_harness:{uuid.uuid4()}",
        config={"story_id": story.get("story_id"), "story_uuid": (story.get("contract") or {}).get("story_uuid")},
    )
    store.mark_run_started(run_id=run_id)

    implementation_dag._CURRENT_STORE = store
    implementation_dag._CURRENT_RUN_ID = run_id
    try:
        with execution_context(
            run_id=run_id,
            dag_id="implementation_gitcommit_refactor_harness",
            repo_root=repo_root,
            story_id=story.get("story_id"),
            story_uuid=(story.get("contract") or {}).get("story_uuid"),
            story_title=story.get("title"),
        ):
            ctx = TaskContext(event=implementation_dag.ImplementationEvent(repo_root=str(repo_root), story=story))
            ctx.metadata["implementation_planning"] = implementation_planning
            ctx.metadata["green_report"] = green_report
            ctx.metadata["green_passed"] = bool(green_report.get("status") == "passed")
            ctx.metadata["refactor_report"] = refactor_report
            ctx.metadata["refactor_passed"] = bool(refactor_report.get("status") == "passed")
            ctx.metadata["security_report"] = security_report
            ctx.metadata["security_passed"] = bool(security_report.get("status") == "passed")
            result = asyncio.run(implementation_dag.GitCommitRefactorNode().process(ctx))
    finally:
        implementation_dag._CURRENT_STORE = None
        implementation_dag._CURRENT_RUN_ID = None

    exit_code = int(result.metadata.get("exit_code") or 0)
    store.mark_run_finished(run_id=run_id, status="succeeded" if exit_code == 0 else "failed")
    with sqlite3.connect(store.db_path) as conn:
        conn.row_factory = sqlite3.Row
        row = conn.execute("SELECT output_json FROM nodes WHERE run_id=? AND node_id='gitcommit(refactor)' ORDER BY created_at DESC LIMIT 1", (run_id,)).fetchone()
    output = json.loads(row["output_json"] or "{}") if row is not None else {}
    sys.stdout.write(json.dumps({
        "run_id": run_id,
        "exit_code": exit_code,
        "story_id": story.get("story_id"),
        "green_report_status": green_report.get("status"),
        "refactor_report_status": refactor_report.get("status"),
        "security_report_status": security_report.get("status"),
        "gitcommit_refactor_output": output,
    }, indent=2) + "\n")
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
