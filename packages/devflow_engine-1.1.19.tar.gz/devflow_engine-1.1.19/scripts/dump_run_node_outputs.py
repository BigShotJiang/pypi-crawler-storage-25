#!/usr/bin/env python3
"""Dump per-node output_json for one execution run into readable files.

Usage:
  python scripts/dump_run_node_outputs.py --run-id <run_uuid>
  python scripts/dump_run_node_outputs.py --dag-id <dag_id>
  python scripts/dump_run_node_outputs.py --dag-id <dag_id> --latest-index 2
  python scripts/dump_run_node_outputs.py --run-id <run_uuid> --output-root /tmp/devflow-dumps
"""
from __future__ import annotations

import argparse
import json
import re
import sqlite3
import sys
from datetime import UTC, datetime
from pathlib import Path
from typing import Any


REPO_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_DB_PATH = REPO_ROOT / ".devflow" / "execution.sqlite"
DEFAULT_OUTPUT_ROOT = REPO_ROOT / ".devflow" / "node_output_dumps"
UUIDISH_RE = re.compile(
    r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$|"
    r"^(run|idea|scope|story|project|dfs|trad)_[0-9a-f]{8,}$",
    re.IGNORECASE,
)
HEX_SUFFIX_RE = re.compile(r"^[a-z][a-z0-9_-]*_[0-9a-f]{6,}$", re.IGNORECASE)
NUMERIC_SUFFIX_RE = re.compile(r"^[a-z][a-z0-9_-]*_[0-9]{4,}[a-z]?$", re.IGNORECASE)


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Dump nodes.output_json for a run into readable files.",
    )
    selector = parser.add_mutually_exclusive_group(required=True)
    selector.add_argument("--run-id", help="Run UUID from runs.run_id")
    selector.add_argument(
        "--dag-id",
        help="Dump the latest run for the given dag_id instead of specifying a run_id",
    )
    parser.add_argument(
        "--latest-index",
        type=int,
        default=1,
        help="With --dag-id, choose the Nth most recent run (default: 1 = latest)",
    )
    parser.add_argument(
        "--db",
        type=Path,
        default=DEFAULT_DB_PATH,
        help=f"SQLite path (default: {DEFAULT_DB_PATH})",
    )
    parser.add_argument(
        "--output-root",
        type=Path,
        default=DEFAULT_OUTPUT_ROOT,
        help=f"Base output directory (default: {DEFAULT_OUTPUT_ROOT})",
    )
    args = parser.parse_args()
    if args.latest_index < 1:
        parser.error("--latest-index must be >= 1")
    if args.latest_index != 1 and not args.dag_id:
        parser.error("--latest-index can only be used with --dag-id")
    return args


def _slugify(value: str, *, default: str) -> str:
    collapsed = re.sub(r"[^a-zA-Z0-9._-]+", "-", value.strip().lower()).strip("-._")
    return collapsed[:80] or default


def _timestamp_slug(epoch_seconds: int | None) -> str:
    if not epoch_seconds:
        return "unknown-time"
    return datetime.fromtimestamp(epoch_seconds, tz=UTC).strftime("%Y%m%d_%H%M%SZ")


def _looks_like_id(value: str) -> bool:
    candidate = value.strip()
    if not candidate:
        return False
    if UUIDISH_RE.match(candidate):
        return True
    lowered = candidate.lower()
    if "-" in lowered and UUIDISH_RE.match(lowered.replace("_", "-")):
        return True
    if HEX_SUFFIX_RE.match(lowered) or NUMERIC_SUFFIX_RE.match(lowered):
        return True
    return False


def _candidate_label_values(config: dict[str, Any]) -> list[str]:
    preferred_keys = (
        "label",
        "name",
        "title",
        "idea_title",
        "scope_title",
        "story_title",
    )
    values: list[str] = []
    for key in preferred_keys:
        raw = config.get(key)
        if isinstance(raw, str) and raw.strip():
            values.append(raw.strip())
    return values


def _choose_label(config: dict[str, Any]) -> str:
    for candidate in _candidate_label_values(config):
        if _looks_like_id(candidate):
            continue
        return _slugify(candidate, default="run")
    return "run"


def _load_run(conn: sqlite3.Connection, run_id: str) -> sqlite3.Row:
    row = conn.execute(
        """
        SELECT run_id, dag_id, started_at, finished_at, created_at, config_json
        FROM runs
        WHERE run_id = ?
        """,
        (run_id,),
    ).fetchone()
    if row is None:
        raise SystemExit(f"run not found: {run_id}")
    return row


def _load_run_for_dag(conn: sqlite3.Connection, dag_id: str, latest_index: int) -> sqlite3.Row:
    row = conn.execute(
        """
        SELECT run_id, dag_id, started_at, finished_at, created_at, config_json
        FROM runs
        WHERE dag_id = ?
        ORDER BY COALESCE(started_at, created_at, finished_at) DESC, run_id DESC
        LIMIT 1 OFFSET ?
        """,
        (dag_id, latest_index - 1),
    ).fetchone()
    if row is None:
        qualifier = f"latest index {latest_index}" if latest_index > 1 else "latest run"
        raise SystemExit(f"no {qualifier} found for dag_id: {dag_id}")
    return row


def _load_nodes(conn: sqlite3.Connection, run_id: str) -> list[sqlite3.Row]:
    return list(
        conn.execute(
            """
            SELECT node_exec_id, node_id, node_name, attempt, status, created_at, output_json
            FROM nodes
            WHERE run_id = ?
            ORDER BY created_at ASC, node_id ASC, attempt ASC
            """,
            (run_id,),
        )
    )


def _load_artifacts(conn: sqlite3.Connection, run_id: str) -> list[sqlite3.Row]:
    return list(
        conn.execute(
            """
            SELECT artifact_id, node_exec_id, kind, uri, created_at
            FROM artifacts
            WHERE run_id = ?
            ORDER BY created_at ASC, artifact_id ASC
            """,
            (run_id,),
        )
    )


def _choose_dag_segment(dag_id: str) -> str:
    candidate = (dag_id or "").strip()
    if not candidate or _looks_like_id(candidate):
        return "dag"
    return _slugify(candidate, default="dag")



def _build_output_dir(*, output_root: Path, dag_id: str, label: str, timestamp: str) -> Path:
    base_dir = output_root / _choose_dag_segment(dag_id) / label / timestamp
    candidate = base_dir
    suffix = 2
    while candidate.exists():
        candidate = Path(f"{base_dir}-{suffix}")
        suffix += 1
    return candidate


def _write_json_file(path: Path, payload: Any) -> None:
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def _parse_json_maybe(raw: str | None) -> tuple[Any, bool]:
    if raw is None or raw == "":
        return None, True
    try:
        return json.loads(raw), True
    except json.JSONDecodeError:
        return raw, False


def _extract_prompt_payload(payload: Any) -> dict[str, Any] | None:
    if not isinstance(payload, dict):
        return None
    prompt = payload.get("prompt")
    if isinstance(prompt, dict):
        return {
            "payload": prompt,
            "source_kind": "exact",
            "source_detail": "agent_run_envelope.prompt",
        }
    request = payload.get("request")
    if isinstance(request, dict) and isinstance(request.get("prompt"), dict):
        return {
            "payload": request["prompt"],
            "source_kind": "exact",
            "source_detail": "agent_run_request.prompt",
        }
    return None


def _candidate_prompt_artifacts_for_node(node_row: sqlite3.Row, artifacts: list[sqlite3.Row]) -> list[sqlite3.Row]:
    node_exec_id = node_row["node_exec_id"]
    node_id = str(node_row["node_id"] or "")
    candidates: list[tuple[int, sqlite3.Row]] = []
    for artifact in artifacts:
        uri = Path(str(artifact["uri"] or ""))
        if "agent_runs" not in uri.parts or uri.suffix.lower() != ".json":
            continue
        score = 100
        if node_exec_id and artifact["node_exec_id"] == node_exec_id:
            score = 0
        stem = uri.stem
        if stem == node_id:
            score = min(score, 1)
        elif node_id and stem.startswith(f"{node_id}_"):
            score = min(score, 2)
        elif node_id and node_id in stem:
            score = min(score, 10)
        if score >= 100:
            continue
        candidates.append((score, artifact))
    candidates.sort(key=lambda item: (item[0], item[1]["created_at"], item[1]["artifact_id"]))
    return [artifact for _, artifact in candidates]


def _dump_node_outputs(output_dir: Path, nodes: list[sqlite3.Row], artifacts: list[sqlite3.Row]) -> list[dict[str, Any]]:
    manifest_nodes: list[dict[str, Any]] = []
    for index, row in enumerate(nodes, start=1):
        node_id = row["node_id"]
        attempt = int(row["attempt"] or 0)
        filename = f"{index:02d}-{_slugify(node_id, default='node')}"
        if attempt > 1:
            filename += f"--attempt-{attempt}"
        output_json = row["output_json"]
        file_path = output_dir / f"{filename}.json"

        parsed_payload, parsed_as_json = _parse_json_maybe(output_json)
        if parsed_as_json:
            _write_json_file(file_path, parsed_payload)
        else:
            file_path = output_dir / f"{filename}.txt"
            file_path.write_text(str(parsed_payload), encoding="utf-8")
            parsed_payload = None

        prompt_entries: list[dict[str, Any]] = []
        candidate_artifacts = _candidate_prompt_artifacts_for_node(row, artifacts)
        seen_prompt_sources: set[tuple[str, str]] = set()
        for prompt_index, artifact in enumerate(candidate_artifacts, start=1):
            prompt_uri = Path(str(artifact["uri"] or ""))
            if not prompt_uri.exists():
                continue
            prompt_payload, is_json = _parse_json_maybe(prompt_uri.read_text(encoding="utf-8"))
            if not is_json:
                continue
            extracted = _extract_prompt_payload(prompt_payload)
            if not extracted:
                continue
            dedupe_key = (json.dumps(extracted["payload"], sort_keys=True), extracted["source_detail"])
            if dedupe_key in seen_prompt_sources:
                continue
            seen_prompt_sources.add(dedupe_key)
            suffix = ".prompt.json" if prompt_index == 1 else f".prompt-{prompt_index}.json"
            prompt_file = output_dir / f"{filename}{suffix}"
            _write_json_file(prompt_file, extracted["payload"])
            prompt_entries.append(
                {
                    "file": prompt_file.name,
                    "source_kind": extracted["source_kind"],
                    "source_detail": extracted["source_detail"],
                    "artifact_uri": str(prompt_uri),
                }
            )

        if not prompt_entries and isinstance(parsed_payload, dict) and isinstance(parsed_payload.get("prompt"), dict):
            prompt_file = output_dir / f"{filename}.prompt.json"
            _write_json_file(prompt_file, parsed_payload["prompt"])
            prompt_entries.append(
                {
                    "file": prompt_file.name,
                    "source_kind": "exact",
                    "source_detail": "node_output.prompt",
                }
            )

        manifest_entry = {
            "node_id": node_id,
            "node_name": row["node_name"],
            "attempt": attempt,
            "status": row["status"],
            "created_at": row["created_at"],
            "file": file_path.name,
        }
        if prompt_entries:
            manifest_entry["prompt_files"] = prompt_entries
        manifest_nodes.append(manifest_entry)
    return manifest_nodes


def main() -> int:
    args = _parse_args()
    db_path = args.db.resolve()
    if not db_path.exists():
        raise SystemExit(f"sqlite db not found: {db_path}")

    with sqlite3.connect(db_path) as conn:
        conn.row_factory = sqlite3.Row
        run = _load_run(conn, args.run_id) if args.run_id else _load_run_for_dag(conn, args.dag_id, args.latest_index)
        nodes = _load_nodes(conn, run["run_id"])
        artifacts = _load_artifacts(conn, run["run_id"])

    config = json.loads(run["config_json"] or "{}")
    label = _choose_label(config)
    timestamp = _timestamp_slug(run["started_at"] or run["created_at"] or run["finished_at"])
    output_dir = _build_output_dir(
        output_root=args.output_root.resolve(),
        dag_id=str(run["dag_id"] or "unknown-dag"),
        label=label,
        timestamp=timestamp,
    )
    output_dir.mkdir(parents=True, exist_ok=False)

    manifest_nodes = _dump_node_outputs(output_dir, nodes, artifacts)
    _write_json_file(
        output_dir / "manifest.json",
        {
            "run_id": run["run_id"],
            "dag_id": run["dag_id"],
            "label": label,
            "timestamp": timestamp,
            "db_path": str(db_path),
            "output_dir": str(output_dir),
            "node_count": len(manifest_nodes),
            "config_json": config,
            "nodes": manifest_nodes,
        },
    )

    selector = f"run {run['run_id']}"
    if args.dag_id:
        which = f"latest #{args.latest_index}" if args.latest_index > 1 else "latest"
        selector = f"{which} run {run['run_id']} for dag {run['dag_id']}"
    print(f"wrote {len(manifest_nodes)} node output file(s) for {selector} to {output_dir}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
