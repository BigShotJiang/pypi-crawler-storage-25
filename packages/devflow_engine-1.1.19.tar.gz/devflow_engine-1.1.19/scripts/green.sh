#!/usr/bin/env bash
# Green gate: deterministic, offline-friendly preflight checks.
#
# Contract (DF2-BOOT-005):
# - exits 0 on a clean repo by default
# - when DEVFLOW_ENGINE_GREEN_GATE_FORCE_FAIL_STAGE=<stage>, exits non-zero
#   and output mentions the failing stage.

set -euo pipefail

FORCE_FAIL_STAGE="${DEVFLOW_ENGINE_GREEN_GATE_FORCE_FAIL_STAGE:-}"

banner() {
  # Keep output concise and easy to grep in CI logs.
  printf '\n==> %s\n' "$1"
}

fail_if_forced() {
  local stage="$1"
  if [ -n "$FORCE_FAIL_STAGE" ] && [ "$FORCE_FAIL_STAGE" = "$stage" ]; then
    echo "FAILED stage: $stage (forced via DEVFLOW_ENGINE_GREEN_GATE_FORCE_FAIL_STAGE)" >&2
    return 1
  fi
  return 0
}

run_stage() {
  local stage="$1"
  shift
  banner "$stage"
  fail_if_forced "$stage"
  "$@"
}

# NOTE: This script intentionally avoids invoking pytest, ruff, mypy, etc.
# because this repo's unit tests execute this script and we must not recurse.
# Keep checks lightweight and offline.

run_stage "env" bash -lc 'command -v bash >/dev/null'

# A tiny Python sanity check if Python is available.
run_stage "python" bash -lc '
  if command -v python3 >/dev/null 2>&1; then
    python3 -c "print(\"python ok\")" >/dev/null
  elif command -v python >/dev/null 2>&1; then
    python -c "print(\"python ok\")" >/dev/null
  else
    # Not fatal for the gate itself.
    echo "python not found; skipping" >&2
  fi
'

# Placeholder stages for a full gate pipeline.
run_stage "lint"  bash -lc 'true'
run_stage "tests" bash -lc 'true'

banner "done"
exit 0
