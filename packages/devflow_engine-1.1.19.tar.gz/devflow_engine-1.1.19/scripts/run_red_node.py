#!/usr/bin/env python3
from __future__ import annotations

import argparse
import asyncio
import json
import sqlite3
import sys
import tempfile
import uuid
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO_ROOT / "src"))

from devflow_engine.implementation import dag as implementation_dag
from devflow_engine.stores.execution_store import ExecutionStore
from devflow_engine.llm.execution_context import execution_context
from devflow_engine.story.discovery import canonical_story_generated_dir
from devflow_engine.story.markdown_contracts import parse_story_contracts_from_markdown
from devflow_engine.story.discovery import get_story_source_paths
from devflow_engine.vendor.datalumina_genai.core.task import TaskContext


def _ensure_canonical_story_doc(repo_root: Path, story: dict) -> Path:
    contract = dict(story.get("contract") or {})
    story_id = str(contract.get("story_id") or story.get("story_id") or "")
    story_uuid = str(contract.get("story_uuid") or "")
    title = str(contract.get("title") or story.get("title") or story_id)
    required_planes = list(contract.get("required_planes") or [])
    plane_oracles = list(contract.get("plane_oracles") or [])

    out_dir = canonical_story_generated_dir(repo_root)
    out_dir.mkdir(parents=True, exist_ok=True)
    slug = story_id.replace(":", "_").replace("/", "_")
    out_path = out_dir / f"{slug}.md"
    lines = [
        "DEVFLOW:LOCKED_START",
        *(f"plane: {plane}" for plane in required_planes),
        "DEVFLOW:LOCKED_END",
        "",
        f"# {title}",
        "",
        f"story_id: {story_id}",
        f"story_uuid: {story_uuid}",
        f"title: {title}",
        f"required_planes: [{', '.join(required_planes)}]",
        "",
        "plane_oracles:",
    ]
    for oracle in plane_oracles:
        lines.extend(
            [
                f"- plane: {oracle.get('plane','')}",
                f"  oracle: {oracle.get('oracle','')}",
                f"  anchor: {oracle.get('anchor','')}",
            ]
        )
    out_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return out_path


def _load_story(store: ExecutionStore, story_id: str) -> dict | None:
    story = store.get_story(story_id)
    if story is not None:
        return story
    with sqlite3.connect(store.db_path) as conn:
        conn.row_factory = sqlite3.Row
        row = conn.execute(
            "SELECT story_id, title, story_artifact_id, status FROM story_queue WHERE story_id=? ORDER BY created_at DESC LIMIT 1",
            (story_id,),
        ).fetchone()
    if row is None:
        return None
    artifact_id = row["story_artifact_id"]
    artifact = store.get_artifact(artifact_id=artifact_id) if artifact_id else None
    if artifact is None:
        # Fallback: look up by generated_devflow_story_json kind matching story_id
        with sqlite3.connect(store.db_path) as conn2:
            conn2.row_factory = sqlite3.Row
            art_row = conn2.execute(
                "SELECT artifact_id, uri FROM artifacts WHERE kind='generated_devflow_story_json' ORDER BY created_at DESC",
            ).fetchall()
        for ar in art_row:
            uri = str(ar["uri"] or "")
            if not uri:
                continue
            p = Path(uri)
            if p.exists():
                try:
                    payload = json.loads(p.read_text(encoding="utf-8"))
                    if payload.get("story_id") == story_id:
                        artifact = {"uri": uri}
                        break
                except Exception:
                    continue
    if artifact is None:
        return None
    uri = str(artifact.get("uri") or "")
    if not uri:
        return None
    path = Path(uri)
    if not path.is_absolute():
        path = store.db_path.parent.parent / uri
    payload = json.loads(path.read_text(encoding="utf-8"))
    contract = dict(payload.get("contract") or {})
    if not contract:
        contract = {
            "story_id": payload.get("story_id") or row["story_id"],
            "story_uuid": payload.get("story_uuid"),
            "title": payload.get("title") or row["title"],
            "required_planes": payload.get("required_planes") or ([payload["plane"]] if payload.get("plane") else []),
            "plane_oracles": payload.get("plane_oracles") or [],
            "acceptance_criteria": payload.get("acceptance_criteria") or [],
        }
    return {
        "story_id": payload.get("story_id") or row["story_id"],
        "title": payload.get("title") or row["title"],
        "status": row["status"],
        "contract": contract,
        **payload,
    }


def _load_latest_artifact_metadata(db_path: Path, *, kind: str, story_id: str) -> dict:
    with sqlite3.connect(db_path) as conn:
        conn.row_factory = sqlite3.Row
        rows = conn.execute(
            "SELECT metadata_json FROM artifacts WHERE kind=? ORDER BY created_at DESC",
            (kind,),
        ).fetchall()
    for row in rows:
        meta = json.loads(row["metadata_json"] or "{}")
        if meta.get("story_id") == story_id:
            return meta
    return {}


def _load_story_from_canonical_docs(repo_root: Path, story_id: str) -> dict | None:
    for path in get_story_source_paths(repo_root):
        try:
            parsed = parse_story_contracts_from_markdown(path.read_text(encoding="utf-8"), source_path=str(path))
        except Exception:
            continue
        for block in parsed:
            contract = block.contract
            if contract.story_id != story_id:
                continue
            return {
                "story_id": contract.story_id,
                "story_uuid": contract.story_uuid,
                "title": contract.title or story_id,
                "contract": {
                    "story_id": contract.story_id,
                    "story_uuid": contract.story_uuid,
                    "title": contract.title or story_id,
                    "required_planes": list(contract.required_planes or []),
                    "plane_oracles": [
                        {"plane": item.plane, "oracle": item.oracle, "anchor": item.anchor}
                        for item in (contract.plane_oracles or [])
                    ],
                },
                "status": "registered",
                "source_path": contract.source_path,
            }
    return None


def main() -> int:
    ap = argparse.ArgumentParser(description="Run only the implementation Red node for a registered story")
    ap.add_argument("story_id")
    ap.add_argument("--repo-root", required=True)
    ap.add_argument("--dry-run", action="store_true", help="Load story and print metadata without running the LLM")
    args = ap.parse_args()

    repo_root = Path(args.repo_root).resolve()
    story = _load_story_from_canonical_docs(repo_root, args.story_id)
    if story is None:
        raise SystemExit(f"story not found: {args.story_id}")

    _ensure_canonical_story_doc(repo_root, story)

    if args.dry_run:
        sys.stdout.write(json.dumps({
            "dry_run": True,
            "story_id": story.get("story_id"),
            "title": story.get("title"),
            "isolated": True,
        }, indent=2) + "\n")
        return 0

    with tempfile.TemporaryDirectory(prefix="devflow-red-harness-") as tmp_dir:
        isolated_root = Path(tmp_dir)
        isolated_devflow = isolated_root / ".devflow"
        isolated_story_state_root = isolated_devflow / "stories"
        store = ExecutionStore(isolated_devflow / "execution.sqlite")
        test_design = _load_latest_artifact_metadata(store.db_path, kind="test_design", story_id=args.story_id)
        implementation_planning = _load_latest_artifact_metadata(store.db_path, kind="implementation_planning", story_id=args.story_id)
        run_id = store.create_run(
            dag_id="implementation_red_harness",
            dag_version="v1",
            root_correlation_id=f"red_harness:{uuid.uuid4()}",
            config={
                "story_id": story.get("story_id"),
                "story_uuid": (story.get("contract") or {}).get("story_uuid"),
                "isolated_harness": True,
            },
        )
        store.mark_run_started(run_id=run_id)

        implementation_dag._CURRENT_STORE = store
        implementation_dag._CURRENT_RUN_ID = run_id
        try:
            with execution_context(
                run_id=run_id,
                dag_id="implementation_red_harness",
                repo_root=repo_root,
                story_id=story.get("story_id"),
                story_uuid=(story.get("contract") or {}).get("story_uuid"),
                story_title=story.get("title"),
                devflow_story_state_root=str(isolated_story_state_root),
                devflow_isolated_harness=True,
            ):
                ctx = TaskContext(event=implementation_dag.ImplementationEvent(repo_root=str(repo_root), story=story))
                ctx.metadata["test_design"] = test_design
                ctx.metadata["implementation_planning"] = implementation_planning
                result = asyncio.run(implementation_dag.RedNode().process(ctx))
        finally:
            implementation_dag._CURRENT_STORE = None
            implementation_dag._CURRENT_RUN_ID = None

        exit_code = int(result.metadata.get("exit_code") or 0)
        store.mark_run_finished(run_id=run_id, status="succeeded" if exit_code == 0 else "failed")
        sys.stdout.write(json.dumps({
            "run_id": run_id,
            "exit_code": exit_code,
            "message": str(result.metadata.get("message") or ""),
            "story_id": story.get("story_id"),
            "isolated": True,
            "story_state_root": str(isolated_story_state_root),
            "execution_db": str(store.db_path),
            "test_design_story_id": test_design.get("story_id"),
            "implementation_planning_story_id": implementation_planning.get("story_id"),
        }, indent=2) + "\n")
        return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
