#!/usr/bin/env python3
"""Run one story through the implementation DAG with recovery disabled.
On failure: alert via openclaw system event and exit non-zero.
Usage: python scripts/run_once_no_recovery.py [project_id_or_path]
"""
from __future__ import annotations

import json
import subprocess
import sys
import traceback
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO_ROOT / "src"))

# Patch recovery out BEFORE importing worker
import devflow_engine.worker as _worker
_worker._enqueue_recovery_request = lambda **_kw: None  # no-op

from devflow_engine.stores.execution_store import ExecutionStore
from devflow_engine.worker import process_once

PROJECT = sys.argv[1] if len(sys.argv) > 1 else "100d4b1a-a7ec-42e6-97e9-ef8c56e23965"
CHI_ROOT = Path("~/repos/chi-webapp").expanduser()


def _alert(msg: str) -> None:
    print(f"ALERT: {msg}", flush=True)
    try:
        subprocess.run(
            ["openclaw", "system", "event", "--text", msg, "--mode", "now"],
            timeout=10,
        )
    except Exception as e:
        print(f"  (alert send failed: {e})", flush=True)


def main() -> int:
    store = ExecutionStore(CHI_ROOT / ".devflow" / "execution.sqlite")

    print(f"Running one story (no recovery) for project {PROJECT}", flush=True)
    try:
        result = process_once(project_id=PROJECT, repo_root=CHI_ROOT, store=store)
    except Exception as exc:
        tb = traceback.format_exc()
        _alert(f"CHI impl DAG CRASHED before completing: {type(exc).__name__}: {exc}")
        print(tb, file=sys.stderr)
        return 1

    processed = result.processed
    print(f"processed: {json.dumps(processed, sort_keys=True)}", flush=True)

    if processed is None:
        _alert("CHI impl DAG: worker found nothing to process (queue empty or all claimed)")
        return 0

    # Check if the story completed successfully
    item_id = str(processed.get("item_id") or "")
    queue_type = str(processed.get("queue_type") or "")

    if queue_type == "story" and item_id:
        import sqlite3
        with store._connect() as conn:
            conn.row_factory = sqlite3.Row
            row = conn.execute(
                "SELECT status, failure_message FROM story_queue WHERE story_queue_id=?",
                (item_id,),
            ).fetchone()
        if row:
            d = dict(row)
            if d["status"] == "completed":
                print(f"SUCCESS: story {item_id[:12]} completed.", flush=True)
                _alert(f"CHI impl DAG: single story smoke test PASSED ✓ ({item_id[:12]})")
                return 0
            else:
                msg = str(d.get("failure_message") or "unknown failure")
                print(f"FAILED: story {item_id[:12]} status={d['status']} msg={msg}", flush=True)
                _alert(f"CHI impl DAG FAILED at story {item_id[:12]}: {msg[:200]}")
                return 1

    print(f"Done (queue_type={queue_type})", flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
