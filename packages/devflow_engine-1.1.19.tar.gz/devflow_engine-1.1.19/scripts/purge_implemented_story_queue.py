#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO_ROOT / "src"))

from devflow_engine.story.implemented_queue_purge import purge_implemented_story_queue  # noqa: E402


def _default_report_path(repo_root: Path, project_id: str | None) -> Path:
    suffix = "all" if not project_id else project_id.replace("/", "_")
    return repo_root / ".devflow" / "reports" / f"purge_implemented_story_queue_{suffix}.json"


def main() -> int:
    parser = argparse.ArgumentParser(
        description=(
            "Inspect the local story_queue, reconcile active rows against Supabase devflow_idea_stories, "
            "and complete queue rows whose stories are already implemented upstream."
        )
    )
    parser.add_argument("--repo-root", required=True, help="Target repo root")
    parser.add_argument("--project-id", help="Optional project id filter")
    parser.add_argument("--apply", action="store_true", help="Apply queue completions instead of dry-run inventory")
    parser.add_argument("--report-path", help="Optional JSON report output path")
    args = parser.parse_args()

    repo_root = Path(args.repo_root).expanduser().resolve()
    report = purge_implemented_story_queue(
        repo_root=repo_root,
        project_id=args.project_id,
        apply=bool(args.apply),
    )

    report_path = (
        Path(args.report_path).expanduser().resolve()
        if args.report_path
        else _default_report_path(repo_root, args.project_id)
    )
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    summary = report["summary"]
    sys.stdout.write(f"repo_root: {report['repo_root']}\n")
    sys.stdout.write(f"project_id: {report.get('project_id') or 'all'}\n")
    sys.stdout.write(f"apply: {str(bool(report['apply'])).lower()}\n")
    sys.stdout.write(f"report_path: {report_path}\n")
    sys.stdout.write(f"active_queue_rows_examined: {summary['active_queue_rows_examined']}\n")
    sys.stdout.write(f"active_story_ids_examined: {summary['active_story_ids_examined']}\n")
    sys.stdout.write(f"supabase_status_rows_found: {summary['supabase_status_rows_found']}\n")
    sys.stdout.write(f"implemented_story_ids_matched: {summary['implemented_story_ids_matched']}\n")
    sys.stdout.write(f"queue_rows_to_complete: {summary['queue_rows_to_complete']}\n")
    sys.stdout.write(f"queue_rows_completed: {summary['queue_rows_completed']}\n")
    if report["candidates"]:
        sys.stdout.write("planned_changes:\n")
        for row in report["candidates"]:
            sys.stdout.write(
                "- "
                f"story_queue_id={row['story_queue_id']} "
                f"story_id={row['story_id']} "
                f"status={row['local_status_before']}->{row['local_status_after']} "
                f"title={json.dumps(row['title'])}\n"
            )
    else:
        sys.stdout.write("planned_changes: none\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
