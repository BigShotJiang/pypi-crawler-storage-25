#!/usr/bin/env python3
from __future__ import annotations

import argparse
import asyncio
import json
import sqlite3
import sys
import uuid
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO_ROOT / "src"))

from devflow_engine.implementation import dag as implementation_dag
from devflow_engine.stores.execution_store import ExecutionStore
from devflow_engine.llm.execution_context import execution_context
from devflow_engine.vendor.datalumina_genai.core.task import TaskContext


def _ensure_canonical_story_doc(repo_root: Path, story: dict) -> Path:
    contract = dict(story.get("contract") or {})
    story_id = str(contract.get("story_id") or story.get("story_id") or "")
    story_uuid = str(contract.get("story_uuid") or "")
    title = str(contract.get("title") or story.get("title") or story_id)
    required_planes = list(contract.get("required_planes") or [])
    plane_oracles = list(contract.get("plane_oracles") or [])

    out_dir = repo_root / "ai_docs" / "context" / "v2" / "project_docs" / "user_stories" / "generated"
    out_dir.mkdir(parents=True, exist_ok=True)
    slug = story_id.replace(":", "_").replace("/", "_")
    out_path = out_dir / f"{slug}.md"
    lines = [
        "DEVFLOW:LOCKED_START",
        *(f"plane: {plane}" for plane in required_planes),
        "DEVFLOW:LOCKED_END",
        "",
        f"# {title}",
        "",
        f"story_id: {story_id}",
        f"story_uuid: {story_uuid}",
        f"title: {title}",
        f"required_planes: [{', '.join(required_planes)}]",
        "",
        "plane_oracles:",
    ]
    for oracle in plane_oracles:
        lines.extend(
            [
                f"- plane: {oracle.get('plane','')}",
                f"  oracle: {oracle.get('oracle','')}",
                f"  anchor: {oracle.get('anchor','')}",
            ]
        )
    out_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return out_path


def _load_story(store: ExecutionStore, story_id: str) -> dict | None:
    story = store.get_story(story_id)
    if story is not None:
        return story
    with sqlite3.connect(store.db_path) as conn:
        conn.row_factory = sqlite3.Row
        row = conn.execute(
            "SELECT story_id, title, story_artifact_id, status FROM story_queue WHERE story_id=? ORDER BY created_at DESC LIMIT 1",
            (story_id,),
        ).fetchone()
    if row is None:
        return None
    artifact_id = row["story_artifact_id"]
    if not artifact_id:
        return None
    artifact = store.get_artifact(artifact_id=artifact_id)
    if artifact is None:
        return None
    uri = str(artifact.get("uri") or "")
    if not uri:
        return None
    path = Path(uri)
    if not path.is_absolute():
        path = store.db_path.parent.parent / uri
    payload = json.loads(path.read_text(encoding="utf-8"))
    contract = dict(payload.get("contract") or {})
    if not contract:
        contract = {
            "story_id": payload.get("story_id") or row["story_id"],
            "story_uuid": payload.get("story_uuid"),
            "title": payload.get("title") or row["title"],
            "required_planes": payload.get("required_planes") or ([payload["plane"]] if payload.get("plane") else []),
            "plane_oracles": payload.get("plane_oracles") or [],
            "acceptance_criteria": payload.get("acceptance_criteria") or [],
        }
    return {
        "story_id": payload.get("story_id") or row["story_id"],
        "title": payload.get("title") or row["title"],
        "status": row["status"],
        "contract": contract,
        **payload,
    }


def main() -> int:
    ap = argparse.ArgumentParser(description="Run only the implementation Preflight node for a registered story")
    ap.add_argument("story_id")
    ap.add_argument("--repo-root", required=True)
    args = ap.parse_args()

    repo_root = Path(args.repo_root).resolve()
    store = ExecutionStore(repo_root / ".devflow" / "execution.sqlite")
    story = _load_story(store, args.story_id)
    if story is None:
        raise SystemExit(f"story not found: {args.story_id}")

    _ensure_canonical_story_doc(repo_root, story)

    run_id = store.create_run(
        dag_id="implementation_preflight_harness",
        dag_version="v1",
        root_correlation_id=f"preflight_harness:{uuid.uuid4()}",
        config={"story_id": story.get("story_id"), "story_uuid": (story.get("contract") or {}).get("story_uuid")},
    )
    store.mark_run_started(run_id=run_id)

    implementation_dag._CURRENT_STORE = store
    implementation_dag._CURRENT_RUN_ID = run_id
    try:
        with execution_context(
            run_id=run_id,
            dag_id="implementation_preflight_harness",
            repo_root=repo_root,
            story_id=story.get("story_id"),
            story_uuid=(story.get("contract") or {}).get("story_uuid"),
            story_title=story.get("title"),
        ):
            ctx = TaskContext(event=implementation_dag.ImplementationEvent(repo_root=str(repo_root), story=story))
            result = asyncio.run(implementation_dag.PreflightNode().process(ctx))
    finally:
        implementation_dag._CURRENT_STORE = None
        implementation_dag._CURRENT_RUN_ID = None

    exit_code = int(result.metadata.get("exit_code") or 0)
    preflight = result.metadata.get("preflight") or {}
    store.mark_run_finished(run_id=run_id, status="succeeded" if exit_code == 0 else "failed")
    sys.stdout.write(json.dumps({
        "run_id": run_id,
        "exit_code": exit_code,
        "message": str(result.metadata.get("message") or ""),
        "story_id": story.get("story_id"),
        "preflight_status": preflight.get("effective_status"),
        "preflight_summary": preflight.get("summary"),
    }, indent=2) + "\n")
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
