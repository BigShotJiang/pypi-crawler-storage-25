#!/usr/bin/env python3
from devflow_engine.story.validate_tests_story import main

if __name__ == "__main__":
    raise SystemExit(main())
