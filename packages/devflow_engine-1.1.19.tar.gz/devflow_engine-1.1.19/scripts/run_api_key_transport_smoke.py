#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sys

from devflow_engine.api_key_flow_harness import ApiKeyTransportSmokeScenario, run_api_key_transport_smoke


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Deterministically verify the DevFlow API-key transport path without the frontend save flow.",
    )
    parser.add_argument("--provider", default="openai", help="Provider name to seed into the transport event")
    parser.add_argument("--api-key", default="smoke-openai-key-12345678", help="Credential used for the seeded transport payload")
    parser.add_argument("--tier", default="light", help="Secret tier for the seeded payload")
    parser.add_argument(
        "--storage-mode",
        choices=("mock", "real"),
        default="mock",
        help="Use mocked storage by default; 'real' writes to the actual keychain/runtime env path.",
    )
    parser.add_argument(
        "--failure-mode",
        choices=("success", "caller_contract", "grant_resolution", "decrypt", "storage"),
        default="success",
        help="Inject a deterministic failure to isolate the seam under test.",
    )
    return parser.parse_args()


def main() -> int:
    args = _parse_args()
    result = run_api_key_transport_smoke(
        ApiKeyTransportSmokeScenario(
            provider=args.provider,
            api_key=args.api_key,
            tier=args.tier,
            storage_mode=args.storage_mode,
            failure_mode=args.failure_mode,
        )
    )
    print(json.dumps(result.to_dict(), indent=2, sort_keys=True))
    return 0 if result.ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
