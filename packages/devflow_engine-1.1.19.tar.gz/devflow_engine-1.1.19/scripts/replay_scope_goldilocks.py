#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import traceback
from pathlib import Path

from devflow_engine.scope_idea import dag as scope_idea_dag
from devflow_engine.scope_idea.dag import (
    AssessScopeGoldilocksNode,
    ScopeToIdeaDagEvent,
    _load_scope_payload,
    _pipeline_root,
    _scope_context_from_payload,
)
from devflow_engine.stores.execution_store import ExecutionStore
from devflow_engine.vendor.datalumina_genai.core.task import TaskContext


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Replay the scope->idea goldilocks node for a specific scope payload.")
    parser.add_argument("--repo-root", required=True)
    parser.add_argument("--project-id", required=True)
    parser.add_argument("--scope-id", required=True)
    parser.add_argument("--scope-set-id", required=True)
    parser.add_argument("--scope-payload-path", required=True)
    parser.add_argument("--pipeline-key", default="debug_replay")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    repo_root = Path(args.repo_root)
    payload_path = Path(args.scope_payload_path)

    event = ScopeToIdeaDagEvent(
        repo_root=str(repo_root),
        project_id=args.project_id,
        scope_set_id=args.scope_set_id,
        scope_id=args.scope_id,
        scope_payload_path=str(payload_path),
        scope_payload_inline=None,
        pipeline_key=args.pipeline_key,
    )

    payload = _load_scope_payload(inline_payload=None, payload_path=payload_path)
    scope_context = _scope_context_from_payload(
        payload=payload,
        project_id=args.project_id,
        scope_set_id=args.scope_set_id,
        scope_id=args.scope_id,
    )

    pipeline_root = _pipeline_root(repo_root, scope_id=args.scope_id, pipeline_key=args.pipeline_key)
    pipeline_root.mkdir(parents=True, exist_ok=True)

    store = ExecutionStore(repo_root / ".devflow" / "execution.sqlite")
    debug_run = store.create_run(
        dag_id="scope_to_idea_dag_debug_replay",
        dag_version="debug",
        root_correlation_id=f"debug_{args.scope_id}",
        config={
            "project_id": args.project_id,
            "scope_set_id": args.scope_set_id,
            "scope_id": args.scope_id,
            "pipeline_key": args.pipeline_key,
        },
    )
    store.mark_run_started(run_id=debug_run)
    scope_idea_dag._CURRENT_STORE = store
    scope_idea_dag._CURRENT_RUN_ID = debug_run

    context = TaskContext(
        event=event,
        metadata={
            "scope_context": scope_context,
        },
    )

    node = AssessScopeGoldilocksNode(task_context=context)

    print(json.dumps({
        "stage": "before_agent_call",
        "scope_id": args.scope_id,
        "scope_title": scope_context.scope_title,
        "scope_description": scope_context.scope_description,
        "source_support": [item.model_dump() for item in scope_context.source_support],
        "pipeline_root": str(pipeline_root),
    }, indent=2))

    try:
        result = node.process(context)
        if hasattr(result, "__await__"):
            import asyncio
            result = asyncio.run(result)
        assessment = result.metadata.get("goldilocks_assessment")
        store.mark_run_finished(run_id=debug_run, status="succeeded")
        print(json.dumps({
            "stage": "after_agent_call",
            "run_id": debug_run,
            "assessment": assessment.model_dump() if assessment is not None else None,
        }, indent=2))
        return 0
    except Exception as exc:
        store.mark_run_finished(run_id=debug_run, status="failed")
        print(json.dumps({
            "stage": "exception",
            "run_id": debug_run,
            "error_type": type(exc).__name__,
            "error": str(exc),
            "traceback": traceback.format_exc(),
        }, indent=2))
        return 1
    finally:
        scope_idea_dag._CURRENT_STORE = None
        scope_idea_dag._CURRENT_RUN_ID = None


if __name__ == "__main__":
    raise SystemExit(main())
