#!/usr/bin/env python3
"""Deterministic validation for contract tests.

Goal: prevent "tests drift" by ensuring tests are explicitly mapped to story
contracts (story_id/story_uuid + plane), and by flagging common testing
anti-patterns.

This script is intentionally conservative and static-analysis based.
It should be fast, deterministic, and runnable without requiring pytest.

Exit codes:
  0 = OK
  2 = Validation failed (issues found)
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Iterable

# Allow running as a script without installing the package.
REPO_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO_ROOT / "src"))

from devflow_engine.story.markdown_contracts import parse_story_contracts_from_markdown  # noqa: E402


# ---------------------------------------------------------------------------
# Regexes / heuristics
# ---------------------------------------------------------------------------

MARK_STORY_ID_RE = re.compile(r"@pytest\.mark\.story_id\(\"([^\"]+)\"\)")
MARK_STORY_UUID_RE = re.compile(r"@pytest\.mark\.story_uuid\(\"([^\"]+)\"\)")
MARK_PLANE_RE = re.compile(r"@pytest\.mark\.plane\(\"([^\"]+)\"\)")
DEF_TEST_RE = re.compile(r"^def\s+(test_[a-zA-Z0-9_]+)\s*\(")

# Anti-pattern heuristics (best-effort; false positives are possible)
# 1) Testing mock behavior: asserting on .called/.call_count/assert_called*
MOCK_ASSERT_RE = re.compile(
    r"assert\s+.*\.(called|call_count|assert_called|assert_called_once|assert_called_with|mock_calls)\b"
)
# 2) Strong signals that mocks are being used
MOCK_IMPORT_RE = re.compile(r"from\s+unittest\.mock\s+import\s+|import\s+unittest\.mock")
PATCH_RE = re.compile(r"\bpatch\(")


@dataclass(frozen=True)
class Issue:
    code: str
    message: str
    path: str
    line: int | None = None
    context: str | None = None


@dataclass(frozen=True)
class Result:
    issue_count: int
    issues: list[Issue]
    story_count: int
    test_file_count: int
    test_count: int


def _iter_story_files(user_stories_dir: Path) -> Iterable[Path]:
    for p in sorted(user_stories_dir.rglob("*.md")):
        if p.name.startswith("."):
            continue
        yield p


def _load_story_index(user_stories_dir: Path) -> dict[str, dict[str, object]]:
    """Return mapping: story_id -> canonical story metadata."""
    idx: dict[str, dict[str, object]] = {}
    for p in _iter_story_files(user_stories_dir):
        md = p.read_text("utf-8")
        blocks = parse_story_contracts_from_markdown(md, source_path=str(p))
        for b in blocks:
            c = b.contract
            # story_id is expected to be stable. If duplicates exist, later will overwrite;
            # the story validator should prevent duplicates in the future.
            idx[c.story_id] = {
                "story_uuid": c.story_uuid,
                "required_planes": list(c.required_planes or []),
                "path": str(p),
            }
    return idx


def _scan_tests(tests_dir: Path) -> tuple[list[Issue], dict[str, set[str]], dict[str, set[str]], dict[str, set[str]]]:
    """Scan tests and return issues + maps.

    Returns:
      issues
      story_id -> set(test_file_paths)
      story_id -> set(story_uuid_markers_seen)
      story_id -> set(planes_seen)
    """
    issues: list[Issue] = []
    story_to_files: dict[str, set[str]] = {}
    story_to_uuids: dict[str, set[str]] = {}
    story_to_planes: dict[str, set[str]] = {}

    for p in sorted(tests_dir.rglob("*.py")):
        if p.name.startswith("."):
            continue
        rel = str(p)
        text = p.read_text("utf-8")
        lines = text.splitlines()

        # Anti-pattern scan (file-level)
        if MOCK_IMPORT_RE.search(text) or PATCH_RE.search(text):
            for i, line in enumerate(lines, start=1):
                if MOCK_ASSERT_RE.search(line):
                    issues.append(
                        Issue(
                            code="testing_anti_pattern_mock_assertion",
                            message=(
                                "Possible anti-pattern: asserting on mock call behavior "
                                "(tests should verify real behavior, not that mocks were called)."
                            ),
                            path=rel,
                            line=i,
                            context=line.strip()[:200],
                        )
                    )

        # Marker scan (test-level)
        current_story_id: str | None = None
        current_story_uuid: str | None = None
        current_plane: str | None = None

        def flush_if_test_boundary(boundary_line: int) -> None:
            # Called when we hit a new test def or EOF.
            nonlocal current_story_id, current_story_uuid, current_plane
            if current_story_id is None and current_story_uuid is None and current_plane is None:
                return

            # Markers should be present as a coherent triple.
            if current_story_id is None:
                issues.append(
                    Issue(
                        code="missing_story_id_marker",
                        message="Test is missing @pytest.mark.story_id(\"...\") marker.",
                        path=rel,
                        line=boundary_line,
                    )
                )
            if current_story_uuid is None:
                issues.append(
                    Issue(
                        code="missing_story_uuid_marker",
                        message="Test is missing @pytest.mark.story_uuid(\"...\") marker.",
                        path=rel,
                        line=boundary_line,
                    )
                )
            if current_plane is None:
                issues.append(
                    Issue(
                        code="missing_plane_marker",
                        message="Test is missing @pytest.mark.plane(\"...\") marker.",
                        path=rel,
                        line=boundary_line,
                    )
                )

            if current_story_id is not None:
                story_to_files.setdefault(current_story_id, set()).add(rel)
            if current_story_id is not None and current_story_uuid is not None:
                story_to_uuids.setdefault(current_story_id, set()).add(current_story_uuid)
            if current_story_id is not None and current_plane is not None:
                story_to_planes.setdefault(current_story_id, set()).add(current_plane)

            current_story_id = None
            current_story_uuid = None
            current_plane = None

        for i, line in enumerate(lines, start=1):
            m_id = MARK_STORY_ID_RE.search(line)
            if m_id:
                current_story_id = m_id.group(1)

            m_uuid = MARK_STORY_UUID_RE.search(line)
            if m_uuid:
                current_story_uuid = m_uuid.group(1)

            m_plane = MARK_PLANE_RE.search(line)
            if m_plane:
                current_plane = m_plane.group(1)

            if DEF_TEST_RE.match(line.strip()):
                # Validate markers collected immediately above this test.
                flush_if_test_boundary(i)

        # EOF flush: if file ends after markers without another def
        flush_if_test_boundary(len(lines) if lines else 1)

    return issues, story_to_files, story_to_uuids, story_to_planes


def validate(*, repo_root: Path) -> Result:
    user_stories_dir = repo_root / "ai_docs" / "context" / "v2" / "project_docs" / "user_stories"
    tests_dir = repo_root / "tests"

    issues: list[Issue] = []

    if not user_stories_dir.exists():
        issues.append(
            Issue(
                code="missing_user_stories_dir",
                message=f"Expected user stories directory not found: {user_stories_dir}",
                path=str(user_stories_dir),
            )
        )
        return Result(issue_count=len(issues), issues=issues, story_count=0, test_file_count=0, test_count=0)

    if not tests_dir.exists():
        issues.append(
            Issue(
                code="missing_tests_dir",
                message=f"Expected tests directory not found: {tests_dir}",
                path=str(tests_dir),
            )
        )
        return Result(issue_count=len(issues), issues=issues, story_count=0, test_file_count=0, test_count=0)

    story_index = _load_story_index(user_stories_dir)

    scan_issues, story_to_files, story_to_uuids, story_to_planes = _scan_tests(tests_dir)
    issues.extend(scan_issues)

    # Cross-check: all story_ids referenced in tests exist in story docs.
    for story_id in sorted(story_to_files.keys()):
        if story_id not in story_index:
            issues.append(
                Issue(
                    code="unknown_story_id_in_tests",
                    message=f"Tests reference story_id {story_id!r} which does not exist in canonical story docs.",
                    path=str(tests_dir),
                )
            )

    # Coverage: every canonical story should have at least one test.
    for story_id in sorted(story_index.keys()):
        if story_id not in story_to_files:
            issues.append(
                Issue(
                    code="missing_tests_for_story",
                    message=f"No tests found for story_id {story_id!r}.",
                    path=str(user_stories_dir),
                )
            )

    # Plane coverage: for stories that declare required_planes, ensure at least one test per plane.
    for story_id, meta in sorted(story_index.items()):
        required = [str(p) for p in (meta.get("required_planes") or [])]
        if not required:
            continue
        seen = story_to_planes.get(story_id, set())
        missing = [p for p in required if p not in seen]
        if missing:
            issues.append(
                Issue(
                    code="orphan_plane_coverage",
                    message=(
                        f"Orphan plane coverage: story_id {story_id!r} requires plane(s) {missing!r} "
                        f"but tests only cover {sorted(seen)!r}."
                    ),
                    path=str(meta.get("path") or user_stories_dir),
                )
            )

    # UUID consistency: if tests provide story_uuid marker, it must match story doc uuid.
    for story_id, uuids in sorted(story_to_uuids.items()):
        meta = story_index.get(story_id)
        expected_uuid = None if meta is None else str(meta.get("story_uuid") or "")
        if expected_uuid and expected_uuid not in uuids:
            issues.append(
                Issue(
                    code="story_uuid_mismatch",
                    message=(
                        f"Tests for story_id {story_id!r} declare story_uuid(s) {sorted(uuids)!r} "
                        f"but story doc uuid is {expected_uuid!r}."
                    ),
                    path=str(tests_dir),
                )
            )

    test_file_count = len(list(tests_dir.rglob("*.py")))
    # Best-effort count of tests (functions starting with test_)
    test_count = 0
    for p in tests_dir.rglob("*.py"):
        text = p.read_text("utf-8")
        test_count += len(re.findall(r"\ndef\s+test_", text))

    return Result(
        issue_count=len(issues),
        issues=issues,
        story_count=len(story_index),
        test_file_count=test_file_count,
        test_count=test_count,
    )


def main() -> int:
    ap = argparse.ArgumentParser(description="Validate contract tests vs canonical story docs")
    ap.add_argument(
        "--repo-root",
        default=str(Path(__file__).resolve().parents[1]),
        help="Path to devflow_engine repo root (default: inferred)",
    )
    ap.add_argument(
        "--json",
        dest="json_path",
        default=None,
        help="Write JSON report to path",
    )
    args = ap.parse_args()

    repo_root = Path(args.repo_root).resolve()
    r = validate(repo_root=repo_root)

    if args.json_path:
        out = {
            "issue_count": r.issue_count,
            "story_count": r.story_count,
            "test_file_count": r.test_file_count,
            "test_count": r.test_count,
            "issues": [asdict(i) for i in r.issues],
        }
        Path(args.json_path).write_text(json.dumps(out, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    if r.issue_count:
        print(f"TEST VALIDATION FAILED: {r.issue_count} issue(s)")
        # Stable output ordering
        for i in r.issues:
            loc = f"{i.path}:{i.line}" if i.line else i.path
            ctx = f" :: {i.context}" if i.context else ""
            print(f"- {i.code}: {loc}: {i.message}{ctx}")
        return 2

    print(f"TEST VALIDATION OK: {r.story_count} story_id(s) covered")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
