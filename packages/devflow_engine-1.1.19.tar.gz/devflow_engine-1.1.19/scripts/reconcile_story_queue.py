#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path


REPO_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO_ROOT / "src"))

from devflow_engine.story.reconciliation import reconcile_story_queue  # noqa: E402


def _default_report_path(repo_root: Path, project_id: str | None) -> Path:
    suffix = "all" if not project_id else project_id.replace("/", "_")
    return repo_root / ".devflow" / "reports" / f"story_reconciliation_{suffix}.json"


def main() -> int:
    parser = argparse.ArgumentParser(description="Inventory and repair duplicate story_queue rows and stale story artifact URIs.")
    parser.add_argument("--repo-root", required=True, help="Target repo root")
    parser.add_argument("--project-id", help="Optional project id filter")
    parser.add_argument("--apply", action="store_true", help="Apply repairs instead of inventory-only")
    parser.add_argument("--report-path", help="Optional JSON report output path")
    args = parser.parse_args()

    repo_root = Path(args.repo_root).expanduser().resolve()
    report = reconcile_story_queue(
        repo_root=repo_root,
        project_id=args.project_id,
        apply=bool(args.apply),
    )

    report_path = Path(args.report_path).expanduser().resolve() if args.report_path else _default_report_path(repo_root, args.project_id)
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    summary = report["summary"]
    sys.stdout.write(f"repo_root: {report['repo_root']}\n")
    sys.stdout.write(f"project_id: {report.get('project_id') or 'all'}\n")
    sys.stdout.write(f"apply: {str(bool(report['apply'])).lower()}\n")
    sys.stdout.write(f"report_path: {report_path}\n")
    sys.stdout.write(f"story_count: {summary['story_count']}\n")
    sys.stdout.write(f"story_ids_with_duplicate_queue_rows: {summary['story_ids_with_duplicate_queue_rows']}\n")
    sys.stdout.write(f"story_ids_with_duplicate_active_queue_rows: {summary['story_ids_with_duplicate_active_queue_rows']}\n")
    sys.stdout.write(f"story_ids_with_broken_story_json_paths: {summary['story_ids_with_broken_story_json_paths']}\n")
    sys.stdout.write(f"story_ids_with_unknown_story_id_risk: {summary['story_ids_with_unknown_story_id_risk']}\n")
    sys.stdout.write(f"story_ids_with_canonical_doc_mismatch: {summary['story_ids_with_canonical_doc_mismatch']}\n")
    sys.stdout.write(f"artifact_uri_updates: {summary['artifact_uri_updates']}\n")
    sys.stdout.write(f"queue_rows_inerted: {summary['queue_rows_inerted']}\n")
    sys.stdout.write(f"canonical_doc_repairs: {summary['canonical_doc_repairs']}\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
