#!/usr/bin/env python3
from __future__ import annotations

import argparse
import ast
import json
import sys
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Literal


REPO_ROOT = Path(__file__).resolve().parents[1]

TARGET_CALLS = {
    "run_one_shot",
    "run_streaming",
    "invoke_llm",
    "run_agent_step",
    "_anthropic_messages_create",
}


@dataclass(frozen=True)
class InventoryRow:
    id: str
    file: str
    function: str
    invocation: str
    classification: str
    live_status: Literal["live", "live_opt_in"]
    owner: str
    notes: str
    tests: tuple[str, ...]


INVENTORY: tuple[InventoryRow, ...] = (
    InventoryRow(
        id="llm.cli_one_shot.run_one_shot",
        file="src/devflow_engine/llm/cli_one_shot.py",
        function="run_one_shot",
        invocation="subprocess.run",
        classification="primitive_cli_boundary",
        live_status="live",
        owner="DFE LLM primitive",
        notes="Low-level one-shot CLI transport. Canonical target should wrap this rather than call it directly from feature code.",
        tests=("tests/test_llm_cli_one_shot.py",),
    ),
    InventoryRow(
        id="llm.cli_stream.run_streaming",
        file="src/devflow_engine/llm/cli_stream.py",
        function="run_streaming",
        invocation="subprocess.Popen",
        classification="primitive_cli_boundary",
        live_status="live",
        owner="DFE LLM primitive",
        notes="Low-level streaming CLI transport with journaling.",
        tests=("tests/test_llm_cli_stream_logging.py", "tests/test_llm_cli_stream_journal_sqlite.py"),
    ),
    InventoryRow(
        id="agentic_runtime.run_agent_step",
        file="src/devflow_engine/agentic_runtime.py",
        function="run_agent_step",
        invocation="invoke_llm",
        classification="canonical_wrapper",
        live_status="live",
        owner="DFE canonical seam today",
        notes="Thin wrapper around the new canonical invocation surface for model-backed DFE DAG nodes.",
        tests=("tests/test_agentic_runtime.py",),
    ),
    InventoryRow(
        id="agentic_runtime._repair_json_decode_error",
        file="src/devflow_engine/agentic_runtime.py",
        function="_repair_json_decode_error",
        invocation="invoke_llm",
        classification="canonical_wrapper",
        live_status="live",
        owner="DFE canonical seam today",
        notes="JSON repair retry routed through the canonical invocation surface.",
        tests=("tests/test_agentic_runtime.py",),
    ),
    InventoryRow(
        id="agentic_runtime._repair_validation_error",
        file="src/devflow_engine/agentic_runtime.py",
        function="_repair_validation_error",
        invocation="invoke_llm",
        classification="canonical_wrapper",
        live_status="live",
        owner="DFE canonical seam today",
        notes="Schema-repair retry routed through the canonical invocation surface.",
        tests=("tests/test_agentic_runtime.py",),
    ),
    InventoryRow(
        id="llm.invoke.invoke_llm",
        file="src/devflow_engine/llm/invoke.py",
        function="invoke_llm",
        invocation="run_one_shot",
        classification="canonical_invocation_surface",
        live_status="live",
        owner="DFE canonical invocation surface",
        notes="First-pass canonical LLM entrypoint. Currently owns one-shot CLI dispatch and CLI config resolution.",
        tests=("tests/test_llm_invoke.py",),
    ),
    InventoryRow(
        id="integration.agentic.run_integration_agent_step",
        file="src/devflow_engine/integration/agentic.py",
        function="run_integration_agent_step",
        invocation="run_agent_step",
        classification="canonical_wrapper",
        live_status="live",
        owner="DFE integration DAG",
        notes="Thin wrapper around current canonical seam.",
        tests=("tests/integration/test_integration_dag.py", "tests/integration/test_integration_dag_nodes.py"),
    ),
    InventoryRow(
        id="integration.agentic.run_integration_code_repair_step",
        file="src/devflow_engine/integration/agentic.py",
        function="run_integration_code_repair_step",
        invocation="run_agent_step",
        classification="canonical_wrapper",
        live_status="live",
        owner="DFE integration DAG",
        notes="Thin wrapper around current canonical seam.",
        tests=("tests/integration/test_integration_dag.py", "tests/integration/test_integration_dag_nodes.py"),
    ),
    InventoryRow(
        id="scope_idea.agentic.run_scope_idea_agent_step",
        file="src/devflow_engine/scope_idea/agentic.py",
        function="run_scope_idea_agent_step",
        invocation="run_agent_step",
        classification="canonical_wrapper",
        live_status="live",
        owner="DFE scope->idea DAG",
        notes="Thin wrapper around current canonical seam.",
        tests=("tests/area12_scope_idea/test_scope_to_idea_dag.py",),
    ),
    InventoryRow(
        id="source_scope.agentic.run_source_scope_agent_step",
        file="src/devflow_engine/source_scope/agentic.py",
        function="run_source_scope_agent_step",
        invocation="run_agent_step",
        classification="canonical_wrapper",
        live_status="live",
        owner="DFE source-scope DAG",
        notes="Thin wrapper around current canonical seam.",
        tests=("tests/area13_source_scope/test_source_to_scope_dag.py", "tests/area13_source_scope/test_source_docs_to_scopes_dag.py"),
    ),
    InventoryRow(
        id="ui_grounding.agentic.run_ui_grounding_agent_step",
        file="src/devflow_engine/ui_grounding/agentic.py",
        function="run_ui_grounding_agent_step",
        invocation="run_agent_step",
        classification="canonical_wrapper",
        live_status="live",
        owner="DFE UI grounding DAG",
        notes="Thin wrapper around current canonical seam.",
        tests=("tests/area14_ui_grounding/test_ui_grounding_dag.py", "tests/area14_ui_grounding/test_ui_grounding_cli_e2e.py"),
    ),
    InventoryRow(
        id="source_doc_mutation_dag._run_source_doc_agent",
        file="src/devflow_engine/source_doc_mutation_dag.py",
        function="_run_source_doc_agent",
        invocation="run_agent_step",
        classification="canonical_wrapper",
        live_status="live",
        owner="DFE source-doc mutation DAG",
        notes="Current canonical seam use for source-doc section agents.",
        tests=("tests/test_source_doc_mutation_dag.py", "tests/test_source_doc_mutation_acceptance.py"),
    ),
    InventoryRow(
        id="source_doc_mutation_dag._run_project_doc_subagent_cli",
        file="src/devflow_engine/source_doc_mutation_dag.py",
        function="_run_project_doc_subagent_cli",
        invocation="run_agent_step",
        classification="canonical_wrapper",
        live_status="live",
        owner="DFE source-doc mutation DAG",
        notes="Current canonical seam use for project-doc mutation subagents.",
        tests=("tests/test_source_doc_mutation_dag.py", "tests/test_source_doc_mutation_acceptance.py"),
    ),
    InventoryRow(
        id="implementation.dag._run_dependency_assessment_agent",
        file="src/devflow_engine/implementation/dag.py",
        function="_run_dependency_assessment_agent",
        invocation="run_agent_step",
        classification="canonical_wrapper",
        live_status="live",
        owner="DFE implementation DAG",
        notes="Current canonical seam for dependency assessment.",
        tests=("tests/area6_implementation_dag/test_df2_impl_area6_red.py",),
    ),
    InventoryRow(
        id="implementation.dag._run_story_implementation_planning_agent",
        file="src/devflow_engine/implementation/dag.py",
        function="_run_story_implementation_planning_agent",
        invocation="run_agent_step",
        classification="canonical_wrapper",
        live_status="live",
        owner="DFE implementation DAG",
        notes="Current canonical seam for planning.",
        tests=("tests/area6_implementation_dag/test_df2_impl_area6_red.py",),
    ),
    InventoryRow(
        id="implementation.dag._run_test_design_agent",
        file="src/devflow_engine/implementation/dag.py",
        function="_run_test_design_agent",
        invocation="run_agent_step",
        classification="canonical_wrapper",
        live_status="live",
        owner="DFE implementation DAG",
        notes="Current canonical seam for test design.",
        tests=("tests/area6_implementation_dag/test_df2_impl_area6_red.py",),
    ),
    InventoryRow(
        id="implementation.dag.SetupDocNode.process",
        file="src/devflow_engine/implementation/dag.py",
        function="process",
        invocation="run_agent_step",
        classification="canonical_wrapper",
        live_status="live",
        owner="DFE implementation DAG",
        notes="SetupDoc node still invokes the current canonical seam directly.",
        tests=("tests/area6_implementation_dag/test_df2_impl_area6_red.py",),
    ),
    InventoryRow(
        id="implementation.dag._run_red_agent",
        file="src/devflow_engine/implementation/dag.py",
        function="_run_red_agent",
        invocation="run_agent_step",
        classification="canonical_wrapper",
        live_status="live",
        owner="DFE implementation DAG",
        notes="Current canonical seam for red generation.",
        tests=("tests/area6_implementation_dag/test_df2_impl_area6_red.py",),
    ),
    InventoryRow(
        id="implementation.dag._run_redreview_agent",
        file="src/devflow_engine/implementation/dag.py",
        function="_run_redreview_agent",
        invocation="run_agent_step",
        classification="canonical_wrapper",
        live_status="live",
        owner="DFE implementation DAG",
        notes="Current canonical seam for red-review.",
        tests=("tests/area6_implementation_dag/test_df2_impl_area6_red.py",),
    ),
    InventoryRow(
        id="implementation.dag._run_streaming_cli_attempt",
        file="src/devflow_engine/implementation/dag.py",
        function="_run_streaming_cli_attempt",
        invocation="run_streaming",
        classification="streaming_special_case",
        live_status="live",
        owner="DFE implementation DAG",
        notes="Streaming green/refactor/security path. Should collapse into the future canonical invocation surface.",
        tests=("tests/area6_implementation_dag/test_df2_impl_streaming_path_usage.py", "tests/area6_implementation_dag/test_df2_impl_refactor_commit_flow.py"),
    ),
    InventoryRow(
        id="recovery.dag.run_agent_step_family",
        file="src/devflow_engine/recovery/dag.py",
        function="multiple",
        invocation="run_agent_step",
        classification="canonical_wrapper",
        live_status="live",
        owner="DFE recovery DAG",
        notes="Failure classification, diagnosis, strategy, execution, and verification all route through the current canonical seam.",
        tests=("tests/area10_process_pipeline/test_failure_recovery_dag.py", "tests/area10_process_pipeline/test_recovery_dag_model_tier.py"),
    ),
    InventoryRow(
        id="devin.devin_eval._assess_response",
        file="src/devflow_engine/devin/devin_eval.py",
        function="_assess_response",
        invocation="run_agent_step",
        classification="canonical_wrapper_eval",
        live_status="live_opt_in",
        owner="Opt-in eval harness",
        notes="Opt-in real-eval harness; not worker-happy-path, but still a live invocation path when explicitly enabled.",
        tests=("tests/test_devin_real_eval.py",),
    ),
    InventoryRow(
        id="source_doc_mutation_eval._assess_doc",
        file="src/devflow_engine/source_doc_mutation_eval.py",
        function="_assess_doc",
        invocation="run_agent_step",
        classification="canonical_wrapper_eval",
        live_status="live_opt_in",
        owner="Opt-in eval harness",
        notes="Opt-in real-eval harness for source-doc mutation quality.",
        tests=("tests/test_source_doc_mutation_eval.py", "tests/test_source_doc_mutation_real_eval.py"),
    ),
    InventoryRow(
        id="idea.agentic._anthropic_messages_create",
        file="src/devflow_engine/idea/agentic.py",
        function="_anthropic_messages_create",
        invocation="urllib.request.urlopen",
        classification="direct_provider_api_exception",
        live_status="live",
        owner="DFE ideation/insight arm",
        notes="Direct Anthropic HTTP transport. Current exception that must migrate into the future canonical invocation surface.",
        tests=("tests/area10_process_pipeline/test_df2_proc_1002_ideation_api_agent.py",),
    ),
    InventoryRow(
        id="idea.agentic._run_api_agent",
        file="src/devflow_engine/idea/agentic.py",
        function="_run_api_agent",
        invocation="_anthropic_messages_create",
        classification="direct_provider_api_exception",
        live_status="live",
        owner="DFE ideation/insight arm",
        notes="Structured tool-loop over the direct Anthropic transport.",
        tests=("tests/area10_process_pipeline/test_df2_proc_1002_ideation_api_agent.py",),
    ),
    InventoryRow(
        id="idea.actors._call_json_llm",
        file="src/devflow_engine/idea/actors.py",
        function="_call_json_llm",
        invocation="run_one_shot",
        classification="direct_cli_bypass",
        live_status="live",
        owner="Idea actor normalization",
        notes="Direct one-shot bypass around the canonical seam.",
        tests=("tests/area5_planning_idea_tool/test_dfe_command_1_ideation_sufficiency_red.py",),
    ),
    InventoryRow(
        id="idea.traditional_stories._call_json_agent",
        file="src/devflow_engine/idea/traditional_stories.py",
        function="_call_json_agent",
        invocation="run_one_shot",
        classification="direct_cli_bypass",
        live_status="live",
        owner="Traditional story generation helpers",
        notes="Direct one-shot bypass around the canonical seam.",
        tests=("tests/area5_planning_idea_tool/test_dfe_command_2_traditional_user_story_generation_red.py", "tests/idea/test_actor_specificity_warning.py"),
    ),
    InventoryRow(
        id="idea.story_pipeline._adjudicate_story_planes",
        file="src/devflow_engine/idea/story_pipeline.py",
        function="_adjudicate_story_planes",
        invocation="run_one_shot",
        classification="direct_cli_bypass",
        live_status="live",
        owner="Idea story pipeline",
        notes="Direct one-shot bypass around the canonical seam.",
        tests=("tests/area10_process_pipeline/test_df2_proc_1001_idea_story_dag_red.py",),
    ),
    InventoryRow(
        id="idea.devin_chat_dag._llm_classify_route",
        file="src/devflow_engine/idea/devin_chat_dag.py",
        function="_llm_classify_route",
        invocation="run_one_shot",
        classification="direct_cli_bypass",
        live_status="live",
        owner="Devin chat DAG",
        notes="Direct route-classifier bypass around the canonical seam.",
        tests=("tests/area10_process_pipeline/test_df2_proc_1002_route_classifier.py",),
    ),
    InventoryRow(
        id="idea.devin_chat_dag._complete_contract_via_llm",
        file="src/devflow_engine/idea/devin_chat_dag.py",
        function="_complete_contract_via_llm",
        invocation="run_one_shot",
        classification="direct_cli_bypass",
        live_status="live",
        owner="Devin chat DAG",
        notes="Direct contract-completion bypass around the canonical seam.",
        tests=("tests/area10_process_pipeline/test_df2_proc_1002_route_classifier.py",),
    ),
    InventoryRow(
        id="idea.devin_chat_dag.IdeationAgentLoopNode.process",
        file="src/devflow_engine/idea/devin_chat_dag.py",
        function="process",
        invocation="run_streaming",
        classification="direct_cli_bypass",
        live_status="live",
        owner="Devin chat DAG",
        notes="Streaming ideation follow-through bypass around the canonical seam.",
        tests=("tests/area10_process_pipeline/test_df2_proc_1002_ideation_intake_dag_red.py",),
    ),
    InventoryRow(
        id="idea.ideation_enrichment.handle_ideation_enrichment_task",
        file="src/devflow_engine/idea/ideation_enrichment.py",
        function="handle_ideation_enrichment_task",
        invocation="run_streaming",
        classification="direct_cli_bypass",
        live_status="live",
        owner="Ideation enrichment worker",
        notes="Background ideation enrichment worker still streams directly.",
        tests=("tests/test_ideation_enrichment.py",),
    ),
    InventoryRow(
        id="refactor.refactor_from_enforce_report",
        file="src/devflow_engine/refactor.py",
        function="refactor_from_enforce_report",
        invocation="run_streaming/run_one_shot",
        classification="direct_cli_bypass",
        live_status="live",
        owner="Refactor command",
        notes="Refactor command still calls CLI primitives directly.",
        tests=("tests/test_refactor_llm_path.py",),
    ),
    InventoryRow(
        id="cli.registry_classify_module_cards",
        file="src/devflow_engine/cli/app.py",
        function="registry_classify_module_cards",
        invocation="run_streaming/run_one_shot",
        classification="direct_cli_bypass",
        live_status="live",
        owner="Registry CLI",
        notes="Command-layer LLM call bypassing canonical seam.",
        tests=("tests/test_registry_llm_commands.py",),
    ),
    InventoryRow(
        id="cli.registry_resolve_multiplicity",
        file="src/devflow_engine/cli/app.py",
        function="registry_resolve_multiplicity",
        invocation="run_streaming/run_one_shot",
        classification="direct_cli_bypass",
        live_status="live",
        owner="Registry CLI",
        notes="Command-layer LLM call bypassing canonical seam.",
        tests=("tests/test_registry_llm_commands.py",),
    ),
    InventoryRow(
        id="cli.registry_classify_packages",
        file="src/devflow_engine/cli/app.py",
        function="registry_classify_packages",
        invocation="run_streaming/run_one_shot",
        classification="direct_cli_bypass",
        live_status="live",
        owner="Registry CLI",
        notes="Command-layer LLM call bypassing canonical seam.",
        tests=("tests/test_registry_llm_commands.py",),
    ),
    InventoryRow(
        id="cli.error_solve_runtime._run_coder",
        file="src/devflow_engine/cli/app.py",
        function="_run_coder",
        invocation="run_streaming",
        classification="direct_cli_bypass",
        live_status="live",
        owner="Runtime error solver CLI",
        notes="Nested runtime-fix coder path. Still a live direct streaming bypass.",
        tests=("tests/test_error_solve_runtime_coder_path.py",),
    ),
)


def _find_call_sites(repo_root: Path) -> dict[tuple[str, str], list[int]]:
    found: dict[tuple[str, str], list[int]] = {}
    src_root = repo_root / "src" / "devflow_engine"
    for path in sorted(src_root.rglob("*.py")):
        rel = str(path.relative_to(repo_root))
        tree = ast.parse(path.read_text(encoding="utf-8"))
        parents: dict[ast.AST, ast.AST] = {}
        for node in ast.walk(tree):
            for child in ast.iter_child_nodes(node):
                parents[child] = node
        for node in ast.walk(tree):
            if not isinstance(node, ast.Call):
                continue
            callee = None
            if isinstance(node.func, ast.Name):
                callee = node.func.id
            elif isinstance(node.func, ast.Attribute):
                callee = node.func.attr
            if callee not in TARGET_CALLS:
                continue
            current: ast.AST | None = node
            fn_name = None
            while current in parents:
                current = parents[current]
                if isinstance(current, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    fn_name = current.name
                    break
            if fn_name is None:
                continue
            found.setdefault((rel, fn_name), []).append(node.lineno)
    return found


def _find_function_defs(repo_root: Path) -> dict[tuple[str, str], int]:
    found: dict[tuple[str, str], int] = {}
    src_root = repo_root / "src" / "devflow_engine"
    for path in sorted(src_root.rglob("*.py")):
        rel = str(path.relative_to(repo_root))
        tree = ast.parse(path.read_text(encoding="utf-8"))
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                found.setdefault((rel, node.name), node.lineno)
    return found


def _check_tests(repo_root: Path, tests: tuple[str, ...]) -> tuple[list[str], bool]:
    missing: list[str] = []
    for test_path in tests:
        if not (repo_root / test_path).exists():
            missing.append(test_path)
    return missing, not missing


def build_report(repo_root: Path) -> dict[str, object]:
    call_sites = _find_call_sites(repo_root)
    function_defs = _find_function_defs(repo_root)
    rows: list[dict[str, object]] = []
    missing_inventory_sites: list[str] = []
    uncovered_live_rows: list[str] = []

    for row in INVENTORY:
        key = (row.file, row.function)
        lines = sorted(call_sites.get(key, []))
        if not lines and row.classification == "primitive_cli_boundary":
            def_line = function_defs.get(key)
            lines = [def_line] if def_line is not None else []
        if not lines and row.id == "idea.agentic._anthropic_messages_create":
            def_line = function_defs.get(key)
            lines = [def_line] if def_line is not None else []
        if not lines and row.id == "recovery.dag.run_agent_step_family":
            lines = sorted(
                line
                for (file_name, _function_name), file_lines in call_sites.items()
                if file_name == row.file
                for line in file_lines
            )
        if not lines:
            missing_inventory_sites.append(row.id)
        missing_tests, covered = _check_tests(repo_root, row.tests)
        row_payload = {
            **asdict(row),
            "lines": lines,
            "tests": list(row.tests),
            "coverage_ok": covered,
            "missing_tests": missing_tests,
        }
        rows.append(row_payload)
        if row.live_status.startswith("live") and not covered:
            uncovered_live_rows.append(row.id)

    return {
        "repo_root": str(repo_root),
        "inventory_count": len(INVENTORY),
        "rows": rows,
        "missing_inventory_sites": missing_inventory_sites,
        "uncovered_live_rows": uncovered_live_rows,
        "audit_complete": not missing_inventory_sites and not uncovered_live_rows,
    }


def _render_text(report: dict[str, object]) -> str:
    lines = [
        "LLM invocation audit",
        f"inventory_count={report['inventory_count']}",
        f"audit_complete={report['audit_complete']}",
    ]
    for row in report["rows"]:
        lines.append(
            " | ".join(
                [
                    str(row["id"]),
                    str(row["classification"]),
                    str(row["live_status"]),
                    str(row["file"]),
                    f"lines={','.join(str(x) for x in row['lines']) or 'missing'}",
                    f"coverage_ok={row['coverage_ok']}",
                ]
            )
        )
    if report["missing_inventory_sites"]:
        lines.append(f"missing_inventory_sites={','.join(report['missing_inventory_sites'])}")
    if report["uncovered_live_rows"]:
        lines.append(f"uncovered_live_rows={','.join(report['uncovered_live_rows'])}")
    return "\n".join(lines) + "\n"


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Enumerate live LLM invocation paths and attached test coverage.")
    parser.add_argument("--json", action="store_true", help="Emit JSON")
    args = parser.parse_args(argv)

    report = build_report(REPO_ROOT)
    if args.json:
        sys.stdout.write(json.dumps(report, indent=2, sort_keys=True) + "\n")
    else:
        sys.stdout.write(_render_text(report))
    return 0 if report["audit_complete"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
