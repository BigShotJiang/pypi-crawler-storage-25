# Scope Idea Doctrine

- Approved scope is the anchor; enrich or split from it without silently replacing intent.
- Return JSON only. No markdown. No prose outside JSON.
- Canonical idea sufficiency remains downstream; do not pretend scope->idea output is story-ready.
- Prefer evidence-backed interpretation over deterministic hints when the approved scope supports it.
- Keep all assumptions explicit and preserve traceability to the approved scope and source evidence.
