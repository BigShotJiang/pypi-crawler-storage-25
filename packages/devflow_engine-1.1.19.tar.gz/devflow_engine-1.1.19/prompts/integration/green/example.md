# Green node assembled payload

## Provenance

Reconstructed from:

- `prompts/integration/green/green/prompt.md`
- `src/devflow_engine/integration/dag.py` green agent call
- `src/devflow_engine/agentic_runtime.py`
- `GreenArtifact` in `src/devflow_engine/integration/dag.py`

Not copied from a persisted past-run integration prompt.

## Stable doctrine vs actual payload

- Stable node doctrine file: `prompts/integration/green/node_config/prompt.md`
- Actual `instructions` come from `green/green/prompt.md`
- Actual `context` comes from `task_context.metadata` + `event.*`
- No skills or tools are injected here

```json
{
  "task": "integration_green",
  "instructions": [
    "Produce exactly one green package per reviewed workflow package.",
    "Distinguish implementation changes, harness support changes, passing strategy, and proof artifacts.",
    "Keep proposed changes aligned to the validated workflow, red review, and available evidence.",
    "If a required seam or observable is missing, say so explicitly.",
    "Do not fake passability.",
    "Return JSON only."
  ],
  "context": {
    "idea_id": "idea_checkout_recovery_v1",
    "validated_workflows": [
      {
        "workflow_id": "wf_recovery_email_sent",
        "side_effect": { "id": "se_recovery_email_sent", "name": "Recovery email sent" },
        "interaction_points": [
          { "kind": "endpoint", "name": "POST /api/carts/{cart_id}/recover", "implemented": true }
        ]
      }
    ],
    "red_review_artifact": {
      "idea_id": "idea_checkout_recovery_v1",
      "summary": "One package needs stronger observability.",
      "reviewed_packages": [],
      "findings": [
        {
          "workflow_id": "wf_recovery_email_sent",
          "verdict": "needs_repair",
          "findings": ["Current proof does not observe durable email-delivery completion."],
          "repair_directions": ["Add a delivery-status artifact or background observer seam."]
        }
      ]
    },
    "code_evidence": [
      { "path": "src/jobs/recovery_email_job.py", "side_effect_ids": [], "interaction_points": [] },
      { "path": "src/notifications/email_delivery.py", "side_effect_ids": [], "interaction_points": [] }
    ],
    "implemented_stories": [
      { "story_id": "STORY-recovery-email-send", "title": "Send recovery reminder email", "side_effect_ids": ["se_recovery_email_sent"], "required_planes": [] }
    ]
  },
  "output_schema": "GreenArtifact.model_json_schema()",
  "return_format": "json_only"
}
```
