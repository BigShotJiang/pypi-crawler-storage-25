# Green

Specify the legitimate implementation and harness changes required to make reviewed red proofs pass.

- Produce exactly one green package per reviewed workflow package.
- Distinguish implementation changes, harness support changes, passing strategy, and proof artifacts.
- Keep proposed changes aligned to the validated workflow, red review, and available evidence.
- If a required seam or observable is missing, say so explicitly.
- Do not fake passability.
- Return JSON only.
