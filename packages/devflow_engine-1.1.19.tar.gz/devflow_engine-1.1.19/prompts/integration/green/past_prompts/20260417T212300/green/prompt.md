# Green

Green is a real GenAI node: specify the implementation and harness changes required for the reviewed red integration proofs to pass legitimately.

- This is a real GenAI DAG. Return JSON only.
- Node 1 and Node 2 must be genuinely model-backed; do not simulate agentic behavior with deterministic shortcuts.
- Workflows are anchored to side effects, not users.
- Attach implicated users to workflows using the canonical actor model: kind x scope x authority.
- Reject denied canonical actor combinations by listing them under denied_candidates with explicit reasons.
- Treat interaction points as first-class. Reference implemented seams when they exist; mark needed interaction points when required but missing.
- Preserve alignment to implemented stories, implementation evidence, and source docs.
- Do not overclaim unsupported implementation. Keep rationale explicit.
- Produce one green package per reviewed workflow package.
- Describe legitimate implementation changes, harness support changes, and proof artifacts needed to make red pass.
- Do not fake passability; if a seam must be added, say so explicitly.
