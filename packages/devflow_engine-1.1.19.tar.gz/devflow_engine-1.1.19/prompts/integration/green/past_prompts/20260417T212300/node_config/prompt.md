# Green Node Contract

Green is a real GenAI node: specify the implementation and harness changes required for the reviewed red integration proofs to pass legitimately.

## What this file is

Stable node doctrine loaded by:

- `load_integration_node_instruction("green")`
- `GreenNode.get_agent_config()`

## What actually reaches the model

The model-facing payload is assembled from:

- stage bullets in `prompts/integration/green/green/prompt.md`
- runtime `context_payload` from `src/devflow_engine/integration/dag.py`
- `GreenArtifact.model_json_schema()`
- `return_format: "json_only"`

## Real injected runtime components

`context_payload` fields:

- `idea_id` ← `event.idea_id`
- `validated_workflows` ← `task_context.metadata["workflows"]`
- `red_review_artifact` ← `task_context.metadata["red_review_artifact"]`
- `code_evidence` ← `event.code_evidence`
- `implemented_stories` ← `event.implemented_stories`

`instructions` source:

- bullets parsed from `prompts/integration/green/green/prompt.md`

`output_schema` source:

- `GreenArtifact.model_json_schema()`

## Tools / skills / config

- No integration-specific skills are injected.
- No tool definitions are injected.
