# Write Workflows

Write one workflow per implemented side effect from the provided evidence.

- Write exactly one workflow per side effect.
- Keep each workflow anchored to its side effect and attach the implicated users to that workflow.
- Use only supported story_backing, code_backing, and source_doc_backing.
- Include concrete interaction_points when implemented; otherwise use needed_interaction_points.
- Capture process_sequence, branches when real, and resulting_artifacts; include mermaid only when it adds clarity.
- Do not invent seams, unsupported implementation facts, or anchor_user.
- Return JSON only.
