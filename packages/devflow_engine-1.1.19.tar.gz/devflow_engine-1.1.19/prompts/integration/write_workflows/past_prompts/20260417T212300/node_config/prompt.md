# Write Workflows Node Contract

Write one workflow artifact per side effect from implementation evidence.

## What this file is

Stable node doctrine loaded by:

- `load_integration_node_instruction("write_workflows")`
- `WriteWorkflowPerSideEffectNode.get_agent_config()`

## What actually reaches the model

The assembled prompt for this node is built from:

- stage bullets in `prompts/integration/write_workflows/write_workflows/prompt.md`
- runtime `context_payload` from `src/devflow_engine/integration/dag.py`
- `WorkflowSetArtifact.model_json_schema()`
- `return_format: "json_only"`

## Real injected runtime components

`context_payload` fields:

- `idea_id` ← `event.idea_id`
- `side_effects_artifact` ← `task_context.metadata["side_effects_artifact"]`
- `implicated_users_artifact` ← `task_context.metadata["implicated_users_artifact"]`
- `implemented_stories` ← `event.implemented_stories`
- `code_evidence` ← `event.code_evidence`
- `source_docs` ← `event.source_docs`

`instructions` source:

- bullets parsed from `prompts/integration/write_workflows/write_workflows/prompt.md`

`output_schema` source:

- `WorkflowSetArtifact.model_json_schema()`

## Tools / skills / config

- No integration-specific skills are injected.
- No tool definitions are injected.
- Provider/model/runtime transport is resolved later by `src/devflow_engine/llm/invoke.py`.
