# Write Workflows node assembled payload

## Provenance

Reconstructed from:

- `prompts/integration/write_workflows/write_workflows/prompt.md`
- `src/devflow_engine/integration/dag.py` write-workflows `context_payload`
- `src/devflow_engine/agentic_runtime.py` prompt envelope builder
- `WorkflowSetArtifact` in `src/devflow_engine/integration/dag.py`

Not copied from a persisted past-run prompt artifact.

## Stable doctrine vs actual payload

- Stable node doctrine file: `prompts/integration/write_workflows/node_config/prompt.md`
- Actual `instructions` come from `write_workflows/write_workflows/prompt.md`
- Actual `context` comes from `task_context.metadata` + `event.*` in `integration/dag.py`
- No skills or tools are injected here

```json
{
  "task": "integration_write_workflows",
  "instructions": [
    "Write exactly one workflow per side effect.",
    "Keep each workflow anchored to its side effect and attach the implicated users to that workflow.",
    "Use only supported story_backing, code_backing, and source_doc_backing.",
    "Include concrete interaction_points when implemented; otherwise use needed_interaction_points.",
    "Capture process_sequence, branches when real, and resulting_artifacts; include mermaid only when it adds clarity.",
    "Do not invent seams, unsupported implementation facts, or anchor_user.",
    "Return JSON only."
  ],
  "context": {
    "idea_id": "idea_checkout_recovery_v1",
    "side_effects_artifact": {
      "idea_id": "idea_checkout_recovery_v1",
      "side_effects": [
        {
          "id": "se_recovery_email_sent",
          "name": "Recovery email sent",
          "rationale": "The implementation sends a recovery reminder after abandonment criteria are met.",
          "interaction_points": [
            {
              "kind": "endpoint",
              "name": "POST /api/carts/{cart_id}/recover",
              "implemented": true
            }
          ],
          "needed_interaction_points": [],
          "process_sequence": [
            "customer abandons cart",
            "recovery endpoint or job is triggered",
            "email delivery job is enqueued"
          ],
          "resulting_artifacts": ["queued recovery email job"]
        }
      ],
      "alignment_context": {
        "implemented_story_count": 2,
        "code_evidence_count": 2,
        "source_doc_count": 1
      }
    },
    "implicated_users_artifact": {
      "idea_id": "idea_checkout_recovery_v1",
      "implicated_users": [
        {
          "kind": "human",
          "scope": "customer_account",
          "authority": "self",
          "rationale": "The customer receives a reminder about their own abandoned cart."
        }
      ],
      "denied_candidates": []
    },
    "implemented_stories": [
      {
        "story_id": "STORY-recovery-email-send",
        "title": "Send recovery reminder email",
        "side_effect_ids": ["se_recovery_email_sent"],
        "required_planes": []
      }
    ],
    "code_evidence": [
      {
        "path": "src/jobs/recovery_email_job.py",
        "side_effect_ids": [],
        "interaction_points": []
      }
    ],
    "source_docs": [
      {
        "path": "ai_docs/context/v2/project_docs/user_workflows.md"
      }
    ]
  },
  "output_schema": "WorkflowSetArtifact.model_json_schema() from src/devflow_engine/integration/dag.py",
  "return_format": "json_only"
}
```
