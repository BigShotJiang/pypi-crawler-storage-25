# Green Enrich node assembled payload

## Provenance

Reconstructed from:

- `prompts/integration/green_enrich/green_enrich/prompt.md`
- `src/devflow_engine/integration/dag.py` green-enrich agent call
- `src/devflow_engine/agentic_runtime.py`
- `GreenEnrichArtifact` in `src/devflow_engine/integration/dag.py`

Not copied from a persisted past-run integration prompt.

## Stable doctrine vs actual payload

- Stable node doctrine file: `prompts/integration/green_enrich/node_config/prompt.md`
- Actual `instructions` come from `green_enrich/green_enrich/prompt.md`
- Actual `context` comes from `task_context.metadata` + `event.idea_id`
- No skills or tools are injected here

```json
{
  "task": "integration_green_enrich",
  "instructions": [
    "Strengthen each workflow package using the validated workflows, green artifact, and red review artifact.",
    "Improve assertions, anchors, and observability only where the evidence supports it.",
    "Reduce brittleness explicitly.",
    "Do not merely restate the green package or invent unsupported seams.",
    "Return JSON only."
  ],
  "context": {
    "idea_id": "idea_checkout_recovery_v1",
    "validated_workflows": [
      {
        "workflow_id": "wf_recovery_email_sent",
        "side_effect": { "id": "se_recovery_email_sent", "name": "Recovery email sent" },
        "interaction_points": [
          { "kind": "endpoint", "name": "POST /api/carts/{cart_id}/recover", "implemented": true }
        ]
      }
    ],
    "green_artifact": {
      "idea_id": "idea_checkout_recovery_v1",
      "summary": "Green package proposes observability improvements.",
      "packages": [
        {
          "workflow_id": "wf_recovery_email_sent",
          "side_effect_id": "se_recovery_email_sent",
          "implementation_changes": [
            { "path": "src/notifications/email_delivery.py", "change": "persist delivery status by cart_id" }
          ],
          "harness_support_changes": [
            { "kind": "background_observer", "change": "observe durable delivery completion event" }
          ],
          "passing_strategy": ["assert endpoint acceptance", "assert durable delivery artifact"],
          "proof_artifacts": [
            { "kind": "artifact_probe", "name": "delivery_status.json" }
          ]
        }
      ]
    },
    "red_review_artifact": {
      "idea_id": "idea_checkout_recovery_v1",
      "summary": "One package needs stronger observability.",
      "reviewed_packages": [],
      "findings": [
        {
          "workflow_id": "wf_recovery_email_sent",
          "verdict": "needs_repair",
          "findings": ["Current proof relies on brittle log inspection."],
          "repair_directions": ["Replace log-only proof with durable observable artifact."]
        }
      ]
    }
  },
  "output_schema": "GreenEnrichArtifact.model_json_schema()",
  "return_format": "json_only"
}
```
