# Green Enrich Node Contract

GreenEnrich is a real GenAI node: strengthen the integration proof, assertions, and observability while reducing brittleness.

## What this file is

Stable node doctrine loaded by:

- `load_integration_node_instruction("green_enrich")`
- `GreenEnrichNode.get_agent_config()`

## What actually reaches the model

The model-facing payload is assembled from:

- stage bullets in `prompts/integration/green_enrich/green_enrich/prompt.md`
- runtime `context_payload` from `src/devflow_engine/integration/dag.py`
- `GreenEnrichArtifact.model_json_schema()`
- `return_format: "json_only"`

## Real injected runtime components

`context_payload` fields:

- `idea_id` ← `event.idea_id`
- `validated_workflows` ← `task_context.metadata["workflows"]`
- `green_artifact` ← `task_context.metadata["green_artifact"]`
- `red_review_artifact` ← `task_context.metadata["red_review_artifact"]`

`instructions` source:

- bullets parsed from `prompts/integration/green_enrich/green_enrich/prompt.md`

`output_schema` source:

- `GreenEnrichArtifact.model_json_schema()`

## Tools / skills / config

- No integration-specific skills are injected.
- No tool definitions are injected.
