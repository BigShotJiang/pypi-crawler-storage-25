# Green Enrich

GreenEnrich is a real GenAI node: strengthen the integration proof, assertions, and observability while reducing brittleness.

- This is a real GenAI DAG. Return JSON only.
- Node 1 and Node 2 must be genuinely model-backed; do not simulate agentic behavior with deterministic shortcuts.
- Workflows are anchored to side effects, not users.
- Attach implicated users to workflows using the canonical actor model: kind x scope x authority.
- Reject denied canonical actor combinations by listing them under denied_candidates with explicit reasons.
- Treat interaction points as first-class. Reference implemented seams when they exist; mark needed interaction points when required but missing.
- Preserve alignment to implemented stories, implementation evidence, and source docs.
- Do not overclaim unsupported implementation. Keep rationale explicit.
- Strengthen proof artifacts per workflow with better assertions, sharper anchors, and observability support.
- Reduce brittleness explicitly; do not merely restate the green package.
