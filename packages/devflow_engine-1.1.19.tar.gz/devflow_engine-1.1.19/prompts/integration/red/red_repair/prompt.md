# Red Repair

Re-generate only the failing red proof packages.

- Repair the current failing package surface with the smallest package delta.
- Keep each package anchored to the same workflow side effect and the strongest supported interaction point.
- Treat the package's current failing interaction point as the primary seam; if none is credible, make the gap explicit instead of broadening the package.
- Do not revisit passing packages, settled claims, or unrelated workflows.
- Do not turn artifact repair into product-code repair or runtime repair.
- Keep missing interaction-point gaps explicit instead of implying passability.
- Failing artifacts and assertions must still prove the side effect, not implementation trivia.
- Return JSON only.
