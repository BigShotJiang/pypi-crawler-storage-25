# Red

Generate failing integration proof packages for the validated workflows.

- Emit exactly one red package per validated workflow.
- Anchor each package to the workflow's side effect and the strongest real interaction point.
- Use only these harness_kind values: playwright, endpoint_harness, cli_harness, artifact_probe, background_observer, integration_harness.
- Use integration_harness only when no concrete interaction point kind fits.
- If a required interaction point is missing, keep the package failing and make the gap explicit in harness_selection.gap_explicit and gap_notes.
- Failing artifacts and assertions must prove the side effect, not implementation trivia.
- Return JSON only.
