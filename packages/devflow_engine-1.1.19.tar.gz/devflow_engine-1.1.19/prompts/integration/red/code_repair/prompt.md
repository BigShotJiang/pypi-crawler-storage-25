# Red Code Repair

Repair product code only when a red proof failure exposes a real code seam problem.

- Patch the smallest real code change that fixes the current failing workflow surface.
- Choose one primary failing seam from validation_errors, failing_packages, failing_workflows, and code_evidence; keep edits there unless the same failure forces one adjacent file.
- Prefer files already named by the failing workflow, package interaction point, or code evidence.
- Update updated_workflows only when the repaired code changes workflow truth.
- Do not repair proof-package artifacts here. Do not edit engine, runtime, orchestration, or prompt-loading layers unless the failure explicitly originates there.
- If the failure is artifact-only, harness-only, or runtime-only, leave code unchanged and explain it in unresolvable_failures.
- Return only changed files with full contents, updated_workflows, and unresolvable_failures.
- Return JSON only.
