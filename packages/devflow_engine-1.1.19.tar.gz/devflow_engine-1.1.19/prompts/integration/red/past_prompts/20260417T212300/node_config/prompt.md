# Red Node Contract

Red is a real GenAI node: generate failing integration proof artifacts anchored to validated workflows and real interaction points.

## What this file is

Stable node doctrine loaded by:

- `load_integration_node_instruction("red")`
- `RedNode.get_agent_config()`

## What actually reaches the model

The current runtime uses three red-related model payloads:

1. red generation pass (`integration_red`)
2. red code repair pass (`integration_code_repair_iter<N>` when red mode is active)
3. red re-generation pass (`integration_red_repair_iter<N>`)

## Real injected runtime components

### Red generation pass

`context_payload` fields:

- `idea_id` ← `event.idea_id`
- `validated_workflows` ← `task_context.metadata["workflows"]`
- `validation_report` ← `task_context.metadata["validation_report"]`
- `side_effects_artifact` ← `task_context.metadata["side_effects_artifact"]`
- `implicated_users_artifact` ← `task_context.metadata["implicated_users_artifact"]`
- `code_evidence` ← `event.code_evidence`

`instructions` source:

- bullets parsed from `prompts/integration/red/red/prompt.md`

`output_schema` source:

- `RedArtifact.model_json_schema()`

### Red code repair pass

`context_payload` fields:

- `failing_packages` ← selected from invalid red packages
- `validation_errors` ← `report["errors"]`
- `failing_workflows` ← workflows matching failing packages
- `side_effects_artifact` ← `task_context.metadata["side_effects_artifact"]`
- `implicated_users_artifact` ← `task_context.metadata["implicated_users_artifact"]`
- `code_evidence` ← `event.code_evidence`

`instructions` source:

- bullets parsed from `prompts/integration/red/code_repair/prompt.md`
- plus runtime-appended repair-iteration line

`output_schema` source:

- `CodeRepairArtifact.model_json_schema()`

### Red re-generation pass

`context_payload` fields:

- `idea_id` ← `event.idea_id`
- `validated_workflows` ← failing workflows only
- `validation_report` ← `task_context.metadata["validation_report"]`
- `side_effects_artifact` ← `task_context.metadata["side_effects_artifact"]`
- `implicated_users_artifact` ← `task_context.metadata["implicated_users_artifact"]`
- `code_evidence` ← `event.code_evidence`

`instructions` source:

- bullets parsed from `prompts/integration/red/red_repair/prompt.md`

`output_schema` source:

- `RedArtifact.model_json_schema()`

## Tools / skills / config

- No integration-specific skills are injected.
- No tool definitions are injected.
- Repair operates by returning full-file patches in JSON, not by model tool calls.
