# Red Repair

Red is a real GenAI node: generate failing integration proof artifacts anchored to validated workflows and real interaction points.

- This is a real GenAI DAG. Return JSON only.
- Node 1 and Node 2 must be genuinely model-backed; do not simulate agentic behavior with deterministic shortcuts.
- Workflows are anchored to side effects, not users.
- Attach implicated users to workflows using the canonical actor model: kind x scope x authority.
- Reject denied canonical actor combinations by listing them under denied_candidates with explicit reasons.
- Treat interaction points as first-class. Reference implemented seams when they exist; mark needed interaction points when required but missing.
- Preserve alignment to implemented stories, implementation evidence, and source docs.
- Do not overclaim unsupported implementation. Keep rationale explicit.
- Emit one red package per validated workflow.
- Choose harnesses from the real interaction points. Use ONLY these canonical harness_kind values: playwright, endpoint_harness, cli_harness, artifact_probe, background_observer, integration_harness.
- This is a repair re-generation pass.
