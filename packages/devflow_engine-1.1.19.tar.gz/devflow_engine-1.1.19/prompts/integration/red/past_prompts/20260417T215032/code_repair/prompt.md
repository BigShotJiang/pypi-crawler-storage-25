# Red Code Repair

Repair the code so the listed failing workflows can pass validation.

- Use validation_errors and the provided code evidence to identify the minimal real code changes.
- For MISSING_INTERACTION_POINTS, create or declare the real seam and update interaction_points in the repaired workflow.
- For STORY_ALIGNMENT_MISMATCH, patch the code and workflow description to match supported story intent.
- For MISSING_CODE_BACKING, implement the missing seam with real code, not stubs.
- Return only changed files with full contents, updated_workflows for repaired workflows, and unresolvable_failures for anything code cannot fix.
- Return JSON only.
