# Red Repair

Re-generate failing integration proof packages for repaired workflows.

- Emit exactly one red package per validated workflow.
- Anchor each package to the workflow's side effect and the strongest real interaction point.
- Use only these harness_kind values: playwright, endpoint_harness, cli_harness, artifact_probe, background_observer, integration_harness.
- Use integration_harness only when no concrete interaction point kind fits.
- Keep missing interaction-point gaps explicit instead of implying passability.
- Failing artifacts and assertions must still prove the side effect, not implementation trivia.
- Return JSON only.
