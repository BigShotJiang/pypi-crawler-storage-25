# Red node assembled payloads

## Provenance

Reconstructed from:

- `prompts/integration/red/red/prompt.md`
- `prompts/integration/red/red_repair/prompt.md`
- `prompts/integration/red/code_repair/prompt.md`
- `src/devflow_engine/integration/dag.py` red generation / repair / re-generation calls
- `src/devflow_engine/agentic_runtime.py`
- `RedArtifact` and `CodeRepairArtifact` in `src/devflow_engine/integration/dag.py`

Not copied from a persisted past-run integration prompt.

## Stable doctrine vs actual payload

- Stable node doctrine file: `prompts/integration/red/node_config/prompt.md`
- Actual `instructions` come from stage prompt markdown; repair mode also gets a runtime-appended iteration line
- Actual `context` comes from validation outputs, workflow artifacts, and repair selections in `integration/dag.py`
- No skills or tools are injected here

## Assembled payload: `integration_red`

```json
{
  "task": "integration_red",
  "instructions": [
    "Emit exactly one red package per validated workflow.",
    "Anchor each package to the workflow's side effect and the strongest real interaction point.",
    "Use only these harness_kind values: playwright, endpoint_harness, cli_harness, artifact_probe, background_observer, integration_harness.",
    "Use integration_harness only when no concrete interaction point kind fits.",
    "If a required interaction point is missing, keep the package failing and make the gap explicit in harness_selection.gap_explicit and gap_notes.",
    "Failing artifacts and assertions must prove the side effect, not implementation trivia.",
    "Return JSON only."
  ],
  "context": {
    "idea_id": "idea_checkout_recovery_v1",
    "validated_workflows": [
      {
        "workflow_id": "wf_recovery_email_sent",
        "side_effect": { "id": "se_recovery_email_sent", "name": "Recovery email sent" },
        "interaction_points": [
          { "kind": "endpoint", "name": "POST /api/carts/{cart_id}/recover", "implemented": true }
        ]
      }
    ],
    "validation_report": { "passed": true, "errors": [] },
    "side_effects_artifact": { "idea_id": "idea_checkout_recovery_v1", "side_effects": [{ "id": "se_recovery_email_sent" }] },
    "implicated_users_artifact": { "idea_id": "idea_checkout_recovery_v1", "implicated_users": [{ "kind": "human", "scope": "customer_account", "authority": "self", "rationale": "customer receives reminder" }], "denied_candidates": [] },
    "code_evidence": [
      { "path": "src/jobs/recovery_email_job.py", "side_effect_ids": [], "interaction_points": [] }
    ]
  },
  "output_schema": "RedArtifact.model_json_schema()",
  "return_format": "json_only"
}
```

## Assembled payload: `integration_code_repair_iter1` (red repair mode)

```json
{
  "task": "integration_code_repair_iter1",
  "instructions": [
    "Patch the smallest real code change that fixes the current failing workflow surface.",
    "Choose one primary failing seam from validation_errors, failing_packages, failing_workflows, and code_evidence; keep edits there unless the same failure forces one adjacent file.",
    "Prefer files already named by the failing workflow, package interaction point, or code evidence.",
    "Update updated_workflows only when the repaired code changes workflow truth.",
    "Do not repair proof-package artifacts here. Do not edit engine, runtime, orchestration, or prompt-loading layers unless the failure explicitly originates there.",
    "If the failure is artifact-only, harness-only, or runtime-only, leave code unchanged and explain it in unresolvable_failures.",
    "Return only changed files with full contents, updated_workflows, and unresolvable_failures.",
    "This is repair iteration 1. Stay on the current failing seam. Do not revisit clean surfaces.",
    "Return JSON only."
  ],
  "context": {
    "failing_packages": [
      {
        "workflow_id": "wf_recovery_email_sent",
        "side_effect_id": "se_recovery_email_sent",
        "status": "failing",
        "harness_selection": {
          "harness_kind": "integration_harness",
          "interaction_point_ref": "POST /api/carts/{cart_id}/recover",
          "interaction_point_kind": "endpoint",
          "rationale": "placeholder harness selection",
          "gap_explicit": false
        },
        "failing_artifacts": [],
        "expected_assertions": [],
        "implicated_user_routes": [],
        "gap_notes": []
      }
    ],
    "validation_errors": [
      "red harness mismatch for wf_recovery_email_sent: expected endpoint_harness"
    ],
    "failing_workflows": [
      {
        "workflow_id": "wf_recovery_email_sent",
        "interaction_points": [
          { "kind": "endpoint", "name": "POST /api/carts/{cart_id}/recover", "implemented": true }
        ]
      }
    ],
    "side_effects_artifact": { "idea_id": "idea_checkout_recovery_v1", "side_effects": [{ "id": "se_recovery_email_sent" }] },
    "implicated_users_artifact": { "idea_id": "idea_checkout_recovery_v1", "implicated_users": [{ "kind": "human", "scope": "customer_account", "authority": "self", "rationale": "customer receives reminder" }], "denied_candidates": [] },
    "code_evidence": [
      { "path": "src/jobs/recovery_email_job.py", "side_effect_ids": [], "interaction_points": [] }
    ]
  },
  "output_schema": "CodeRepairArtifact.model_json_schema()",
  "return_format": "json_only"
}
```

## Assembled payload: `integration_red_repair_iter1`

```json
{
  "task": "integration_red_repair_iter1",
  "instructions": [
    "Repair the current failing package surface with the smallest package delta.",
    "Keep each package anchored to the same workflow side effect and the strongest supported interaction point.",
    "Treat the package's current failing interaction point as the primary seam; if none is credible, make the gap explicit instead of broadening the package.",
    "Do not revisit passing packages, settled claims, or unrelated workflows.",
    "Do not turn artifact repair into product-code repair or runtime repair.",
    "Keep missing interaction-point gaps explicit instead of implying passability.",
    "Failing artifacts and assertions must still prove the side effect, not implementation trivia.",
    "Return JSON only."
  ],
  "context": {
    "idea_id": "idea_checkout_recovery_v1",
    "validated_workflows": [
      {
        "workflow_id": "wf_recovery_email_sent",
        "interaction_points": [
          { "kind": "endpoint", "name": "POST /api/carts/{cart_id}/recover", "implemented": true }
        ]
      }
    ],
    "validation_report": { "passed": true, "errors": [] },
    "side_effects_artifact": { "idea_id": "idea_checkout_recovery_v1", "side_effects": [{ "id": "se_recovery_email_sent" }] },
    "implicated_users_artifact": { "idea_id": "idea_checkout_recovery_v1", "implicated_users": [{ "kind": "human", "scope": "customer_account", "authority": "self", "rationale": "customer receives reminder" }], "denied_candidates": [] },
    "code_evidence": [
      { "path": "src/jobs/recovery_email_job.py", "side_effect_ids": [], "interaction_points": [] }
    ]
  },
  "output_schema": "RedArtifact.model_json_schema()",
  "return_format": "json_only"
}
```
