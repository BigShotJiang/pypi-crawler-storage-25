# Integration prompt assembly: concrete runtime shape

This directory contains two different kinds of prompt artifacts, and they do **not** play the same role.

## 1) Stable node doctrine (`node_config/prompt.md`)

For each integration node, `node_config/prompt.md` is loaded by:

- `src/devflow_engine/integration/prompts.py` → `load_integration_node_instruction(node)`
- consumed in `src/devflow_engine/integration/dag.py` via `get_agent_config()`

Example:

- `ResolveSideEffectsAndImplicatedUsersNode.get_agent_config()` loads `prompts/integration/resolve/node_config/prompt.md`
- `ValidateEnrichGateNode.get_agent_config()` loads `prompts/integration/validate/node_config/prompt.md`

**Current code-grounded reality:** this node doctrine is stored on `AgentConfig.instructions`, but the current integration runtime path does **not** inject that string into the JSON prompt envelope built by `run_agent_step(...)`.

The vendored `AgentNode`/`AgentConfig` surface is currently a compatibility stub in:

- `src/devflow_engine/vendor/datalumina_genai/core/nodes/agent.py`

So `node_config/prompt.md` is best understood as **stable node doctrine / node contract documentation**, not as the literal prompt body the model sees.

## 2) Stable stage prompt bullets (`<stage>/<prompt.md>`)

These files *do* feed the assembled model payload.

They are loaded by:

- `src/devflow_engine/integration/prompts.py` → `load_integration_stage_guidance(stage_name)`
- called from `src/devflow_engine/integration/agentic.py` → `run_integration_agent_step(...)`
- passed into `src/devflow_engine/agentic_runtime.py` → `run_agent_step(...)`
- serialized into the prompt envelope as `instructions`

Examples:

- `prompts/integration/resolve/resolve_side_effects/prompt.md`
- `prompts/integration/validate/validate_enrich_gate/prompt.md`
- `prompts/integration/red/red/prompt.md`
- `prompts/integration/red/code_repair/prompt.md`

## 3) Runtime-built context (`context_payload`)

This is the largest injected component, and it is built in `src/devflow_engine/integration/dag.py` immediately before each agent call.

Concrete examples:

- Resolve node injects:
  - `idea_id`
  - `implemented_idea`
  - `implemented_stories`
  - `code_evidence`
  - `source_docs`
  - `canonical_actor_allowed_combinations`
- Write Workflows injects:
  - `idea_id`
  - `side_effects_artifact`
  - `implicated_users_artifact`
  - `implemented_stories`
  - `code_evidence`
  - `source_docs`
- Validate enrich injects:
  - `idea_id`
  - `side_effects_artifact`
  - `implicated_users_artifact`
  - `workflows`
  - `implemented_stories`
  - `code_evidence`
  - `source_docs`
- Validate code repair injects:
  - `failing_workflows`
  - `validation_errors`
  - `code_evidence_files`
  - `side_effects_artifact`
  - `implicated_users_artifact`
  - `implemented_stories`
- Red injects:
  - `idea_id`
  - `validated_workflows`
  - `validation_report`
  - `side_effects_artifact`
  - `implicated_users_artifact`
  - `code_evidence`
- Red code repair injects:
  - `failing_packages`
  - `validation_errors`
  - `failing_workflows`
  - `side_effects_artifact`
  - `implicated_users_artifact`
  - `code_evidence`
- Red review injects:
  - `idea_id`
  - `validated_workflows`
  - `red_artifact`
  - `validation_report`
- Green injects:
  - `idea_id`
  - `validated_workflows`
  - `red_review_artifact`
  - `code_evidence`
  - `implemented_stories`
- Green enrich injects:
  - `idea_id`
  - `validated_workflows`
  - `green_artifact`
  - `red_review_artifact`

Those fields are sourced from a mix of:

- the incoming integration event (`event.idea_id`, `event.implemented_idea`, `event.implemented_stories`, `event.code_evidence`, `event.source_docs`)
- prior node outputs stored in `task_context.metadata`
- repo files loaded earlier in the pipeline (for example via prepared integration payloads and written artifacts)
- repair-time file reads such as `_load_code_evidence_for_workflows(...)`

## 4) Output schema contract

`run_agent_step(...)` always injects the expected output schema as:

- `output_schema = output_model.model_json_schema()`

For integration, the concrete model classes live in `src/devflow_engine/integration/dag.py`:

- `SideEffectsArtifact`
- `ImplicatedUsersArtifact`
- `WorkflowSetArtifact`
- `ValidateEnrichArtifact`
- `CodeRepairArtifact`
- `RedArtifact`
- `RedReviewArtifact`
- `GreenArtifact`
- `GreenEnrichArtifact`

## 5) Return-format contract

`src/devflow_engine/agentic_runtime.py` injects:

- `return_format: "json_only"`

and calls `invoke_llm(...)` with:

- `response_contract="json_only"`
- `interaction_model="agentic"`
- `delivery_model="streaming"`

## 6) Tools / skills / runtime config: what actually applies here

For the **current integration runtime path**:

- No integration-specific skill bundle is injected into the prompt payload.
- No tool list is assembled by `integration/agentic.py` or `agentic_runtime.py`.
- If the provider path is Anthropic API, `src/devflow_engine/llm/invoke.py` calls `anthropic_messages_create(...)` with:
  - `system_prompt=""`
  - `messages=[{"role": "user", "content": <assembled JSON prompt>}]`
  - `tools=[]`
- Model/provider/base command selection is runtime config, not prompt doctrine. It is resolved in `src/devflow_engine/llm/invoke.py` from `LlmInvocationRequest(...)` plus global LLM config/tier config.

So for integration, the useful separation is:

- **Stable node doctrine:** `node_config/prompt.md`
- **Stable prompt text that actually reaches the model:** stage `prompt.md` bullet lines
- **Runtime-built context:** `context_payload` from `integration/dag.py`
- **Runtime config:** provider/model/CLI/API transport chosen by `invoke_llm(...)`
- **Tools/skills:** none currently injected by the integration path

## 7) Size-management behavior

If the prompt envelope is too large, `src/devflow_engine/agentic_runtime.py` may:

1. compact large strings/lists/dicts in `context`, or
2. persist the full context to `.devflow/agent_debug/context_artifacts/<stage>_context.json`
   and replace inline `context` with:
   - `context_artifact_path`
   - `context_artifact_note`

## 8) Example files

Each integration node directory includes an `example.md` showing the **assembled payload shape** the model actually receives for that node.

Each example explicitly labels:

- what came from stable stage prompt markdown
- what came from runtime-built context
- what schema/model contract was injected
- what was reconstructed from code rather than copied from a captured past run
