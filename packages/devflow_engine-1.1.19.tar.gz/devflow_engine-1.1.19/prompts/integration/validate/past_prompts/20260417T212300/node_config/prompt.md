# Validate Node Contract

Enrich and repair integration workflows to ensure they have complete story backing, code backing, and interaction point coverage before the deterministic gate.

## What this file is

Stable node doctrine loaded by:

- `load_integration_node_instruction("validate")`
- `ValidateEnrichGateNode.get_agent_config()`

## What actually reaches the model

The current integration runtime uses two validate-node prompt shapes:

1. enrich/validate pass (`integration_validate_enrich_gate`)
2. code repair pass (`integration_code_repair_iter<N>`)

Those model-facing payloads are assembled from stage bullets + runtime context + output schema.

## Real injected runtime components

### Validate enrich pass

`context_payload` fields:

- `idea_id` ← `event.idea_id`
- `side_effects_artifact` ← `task_context.metadata["side_effects_artifact"]`
- `implicated_users_artifact` ← `task_context.metadata["implicated_users_artifact"]`
- `workflows` ← `task_context.metadata["workflows"]`
- `implemented_stories` ← `event.implemented_stories`
- `code_evidence` ← `event.code_evidence`
- `source_docs` ← `event.source_docs`

`instructions` source:

- bullets parsed from `prompts/integration/validate/validate_enrich_gate/prompt.md`

`output_schema` source:

- `ValidateEnrichArtifact.model_json_schema()`

### Validate code repair pass

`context_payload` fields:

- `failing_workflows` ← derived from validation failures against `enriched_workflows`
- `validation_errors` ← `report["errors"]`
- `code_evidence_files` ← `_load_code_evidence_for_workflows(...)`
- `side_effects_artifact` ← `task_context.metadata["side_effects_artifact"]`
- `implicated_users_artifact` ← `task_context.metadata["implicated_users_artifact"]`
- `implemented_stories` ← `event.implemented_stories`

`instructions` source:

- bullets parsed from `prompts/integration/validate/code_repair/prompt.md`
- plus runtime-appended line: `This is repair iteration <N>. Be precise and targeted.`

`output_schema` source:

- `CodeRepairArtifact.model_json_schema()`

## Tools / skills / config

- No integration-specific skills are injected.
- No tool definitions are injected.
- File content reaches repair through `code_evidence_files`, not through an interactive tool surface.
