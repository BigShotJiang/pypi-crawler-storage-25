# Validate Enrich Gate

Enrich and repair integration workflows to ensure they have complete story backing, code backing, and interaction point coverage before the deterministic gate.

- This is a real GenAI DAG. Return JSON only.
- Node 1 and Node 2 must be genuinely model-backed; do not simulate agentic behavior with deterministic shortcuts.
- Workflows are anchored to side effects, not users.
- Attach implicated users to workflows using the canonical actor model: kind x scope x authority.
- Reject denied canonical actor combinations by listing them under denied_candidates with explicit reasons.
- Treat interaction points as first-class. Reference implemented seams when they exist; mark needed interaction points when required but missing.
- Preserve alignment to implemented stories, implementation evidence, and source docs.
- Do not overclaim unsupported implementation. Keep rationale explicit.
- Review every workflow using the real model-backed runtime path and return enriched_workflows plus findings.
- You may enrich rationale, story/code/source-doc backing, process sequencing clarity, branches, resulting artifacts, and interaction-point descriptions when the evidence supports it.
- Do not invent unsupported seams, actor coverage, or implementation facts.
- Keep blocking findings explicit when a workflow is under-supported, inconsistent, or overclaims coverage.
- Preserve workflow identity and side-effect anchoring; return exactly one enriched workflow per input workflow.
