# Validate Repair

Enrich and repair integration workflows to ensure they have complete story backing, code backing, and interaction point coverage before the deterministic gate.

- This is a real GenAI DAG. Return JSON only.
- Node 1 and Node 2 must be genuinely model-backed; do not simulate agentic behavior with deterministic shortcuts.
- Workflows are anchored to side effects, not users.
- Attach implicated users to workflows using the canonical actor model: kind x scope x authority.
- Reject denied canonical actor combinations by listing them under denied_candidates with explicit reasons.
- Treat interaction points as first-class. Reference implemented seams when they exist; mark needed interaction points when required but missing.
- Preserve alignment to implemented stories, implementation evidence, and source docs.
- Do not overclaim unsupported implementation. Keep rationale explicit.
- You are performing a repair pass on the enriched_workflows.
- Resolve every repair source listed in repair_sources, including deterministic validation errors and blocking agentic findings.
- Use deterministic_errors for structural/deterministic validation failures and blocking_findings for agentic blocking findings.
- Return enriched_workflows with the same workflow_ids; do not add or remove workflows.
