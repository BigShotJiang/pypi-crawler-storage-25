# Validate Repair

Repair enriched workflows so they are structurally ready for deterministic validation.

- Resolve every repair source listed in repair_sources.
- Use deterministic_errors for structural failures and blocking_findings for agentic blocking findings.
- Return enriched_workflows with the same workflow_ids.
- Repair unsupported claims, missing backing, and missing interaction points without inventing evidence.
- Return JSON only.
