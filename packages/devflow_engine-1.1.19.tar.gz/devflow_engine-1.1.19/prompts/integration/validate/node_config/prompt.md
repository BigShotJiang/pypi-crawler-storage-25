# Validate / VEG Node Contract

Agentic VEG builder + deterministic gate for idea-acceptance validation.

## What this file is

Stable node doctrine loaded by:

- `load_integration_node_instruction("validate")`
- `BuildIdeaAcceptanceCoverageNode.get_agent_config()`

## What actually reaches the model

The current integration runtime uses two validate-area model-facing prompt shapes:

1. VEG idea-acceptance builder (`integration_build_idea_acceptance_coverage`)
2. validate repair pass (`integration_validate_repair`)

The checker/gate itself is deterministic Python (`ValidateEnrichGateNode`) and is not model-backed.

## Real injected runtime components

### VEG idea-acceptance builder

`context_payload` fields:

- `idea_id`
- `implemented_idea`
- `implemented_stories`
- `side_effects_artifact`
- `implicated_users_artifact`
- `workflows`
- `code_evidence`
- `source_docs`

`instructions` source:

- bullets parsed from `prompts/integration/validate/build_idea_acceptance_coverage/prompt.md`

`output_schema` source:

- `VegIdeaAcceptanceBuilderArtifact.model_json_schema()`

### Validate repair pass

`context_payload` fields:

- `enriched_workflows`
- `idea_acceptance_coverage`
- `failing_workflows`
- `failing_idea_acceptance_criteria`
- `deterministic_errors`
- `repair_sources`
- `protected_sections`
- `do_not_touch`

`instructions` source:

- bullets parsed from `prompts/integration/validate/validate_repair/prompt.md`

`output_schema` source:

- `VegIdeaAcceptanceBuilderArtifact.model_json_schema()`

### Validate code repair pass

`context_payload` fields:

- `failing_workflows`
- `validation_errors`
- `repair_sources`
- `protected_sections`
- `do_not_touch`
- `code_evidence_files`
- `side_effects_artifact`
- `implicated_users_artifact`
- `implemented_stories`
- `idea_acceptance_coverage`
- `failing_idea_acceptance_criteria`

`instructions` source:

- bullets parsed from `prompts/integration/validate/code_repair/prompt.md`

`output_schema` source:

- `CodeRepairArtifact.model_json_schema()`
