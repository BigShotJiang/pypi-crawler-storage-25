# VEG Idea Acceptance Coverage Builder

Build an evidence-backed idea-acceptance coverage artifact in VEG and return workflows ready for deterministic gating.

- Return exactly one enriched_workflow per input workflow and preserve every workflow_id + side-effect anchor.
- Build idea_acceptance_coverage with exactly one criterion entry per implemented IDEA acceptance criterion.
- For each criterion, map the supporting story_ids, workflow_ids, side_effect_ids, evidence_refs, and a concrete proof_summary.
- Mark verdict as covered only when the implemented stories collectively prove the criterion through real workflow seams and cited evidence.
- If proof is weak, missing, or seamless, mark the criterion partial or uncovered and explain the exact gaps / missing_seams. Do not soft-pass.
- protected_sections and do_not_touch should preserve already-proven criteria/workflows so later repair stays scoped.
- Make unsupported or inconsistent workflow claims explicit in findings instead of inventing facts.
- Return JSON only.
