# Validate Enrich Gate

Enrich workflows so they are evidence-backed and ready for deterministic validation.

- Review every workflow and return exactly one enriched_workflow per input workflow.
- Preserve workflow identity and side-effect anchoring.
- Improve rationale, backing, sequencing, branches, resulting artifacts, and interaction-point descriptions only where the evidence supports it.
- Make unsupported, inconsistent, or under-supported areas explicit in findings.
- Do not invent seams, actors, or implementation facts.
- Return JSON only.
