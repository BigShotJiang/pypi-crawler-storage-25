# Validate Code Repair

Repair product code for the current validation failure.

- Patch the smallest real code change that fixes the current failing workflow surface.
- Choose one primary failing seam from validation_errors, failing_workflows, repair_sources, and code_evidence_files; keep edits there unless the same failure forces one adjacent file.
- Treat protected_sections as immutable context and obey every item in do_not_touch.
- Prefer files already named in code_evidence_files, workflow backing, or the failing interaction seam.
- Update updated_workflows only when the repaired code changes workflow truth.
- Do not repair red-package artifacts here. Do not edit engine, runtime, orchestration, or prompt-loading layers unless the failure explicitly originates there.
- If the issue is workflow-only, artifact-only, or runtime-only, leave code unchanged and explain it in unresolvable_failures.
- Return only changed files with full contents, updated_workflows, and unresolvable_failures.
- Return JSON only.
