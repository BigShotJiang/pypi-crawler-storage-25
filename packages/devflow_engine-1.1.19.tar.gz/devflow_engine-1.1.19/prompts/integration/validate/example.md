# Validate node assembled payloads

## Provenance

Reconstructed from:

- `prompts/integration/validate/validate_enrich_gate/prompt.md`
- `prompts/integration/validate/code_repair/prompt.md`
- `src/devflow_engine/integration/dag.py` validate gate + code repair calls
- `src/devflow_engine/agentic_runtime.py`
- `ValidateEnrichArtifact` and `CodeRepairArtifact` in `src/devflow_engine/integration/dag.py`

Not copied from a persisted past-run integration prompt.

## Stable doctrine vs actual payload

- Stable node doctrine file: `prompts/integration/validate/node_config/prompt.md`
- Actual `instructions` come from stage prompt markdown plus the runtime repair-iteration line on repair passes
- Actual `context` comes from validate-time artifacts and repair-time derived data in `integration/dag.py`
- No skills or tools are injected here

## Assembled payload: `integration_validate_enrich_gate`

```json
{
  "task": "integration_validate_enrich_gate",
  "instructions": [
    "Review every workflow and return exactly one enriched_workflow per input workflow.",
    "Preserve workflow identity and side-effect anchoring.",
    "Improve rationale, backing, sequencing, branches, resulting artifacts, and interaction-point descriptions only where the evidence supports it.",
    "Make unsupported, inconsistent, or under-supported areas explicit in findings.",
    "Do not invent seams, actors, or implementation facts.",
    "Return JSON only."
  ],
  "context": {
    "idea_id": "idea_checkout_recovery_v1",
    "side_effects_artifact": {
      "idea_id": "idea_checkout_recovery_v1",
      "side_effects": [
        {
          "id": "se_recovery_email_sent",
          "interaction_points": [
            { "kind": "endpoint", "name": "POST /api/carts/{cart_id}/recover", "implemented": true }
          ]
        }
      ]
    },
    "implicated_users_artifact": {
      "idea_id": "idea_checkout_recovery_v1",
      "implicated_users": [
        { "kind": "human", "scope": "customer_account", "authority": "self", "rationale": "customer receives reminder" }
      ],
      "denied_candidates": []
    },
    "workflows": [
      {
        "workflow_id": "wf_recovery_email_sent",
        "idea_id": "idea_checkout_recovery_v1",
        "side_effect": { "id": "se_recovery_email_sent", "name": "Recovery email sent" },
        "implicated_users": [
          { "kind": "human", "scope": "customer_account", "authority": "self" }
        ],
        "story_backing": [
          { "story_id": "STORY-recovery-email-send", "title": "Send recovery reminder email" }
        ],
        "code_backing": [
          { "path": "src/jobs/recovery_email_job.py" }
        ],
        "source_doc_backing": [
          { "path": "ai_docs/context/v2/project_docs/user_workflows.md" }
        ],
        "interaction_points": [
          { "kind": "endpoint", "name": "POST /api/carts/{cart_id}/recover", "implemented": true }
        ],
        "needed_interaction_points": [],
        "process_sequence": ["cart abandoned", "job scheduled", "email sent"],
        "branches": [],
        "resulting_artifacts": ["queued recovery email job"],
        "mermaid": null
      }
    ],
    "implemented_stories": [
      { "story_id": "STORY-recovery-email-send", "title": "Send recovery reminder email", "side_effect_ids": ["se_recovery_email_sent"], "required_planes": [] }
    ],
    "code_evidence": [
      { "path": "src/jobs/recovery_email_job.py", "side_effect_ids": [], "interaction_points": [] }
    ],
    "source_docs": [
      { "path": "ai_docs/context/v2/project_docs/user_workflows.md" }
    ]
  },
  "output_schema": "ValidateEnrichArtifact.model_json_schema()",
  "return_format": "json_only"
}
```

## Assembled payload: `integration_code_repair_iter1` (validate repair mode)

```json
{
  "task": "integration_code_repair_iter1",
  "instructions": [
    "Patch the smallest real code change that fixes the current failing workflow surface.",
    "Choose one primary failing seam from validation_errors, failing_workflows, and code_evidence_files; keep edits there unless the same failure forces one adjacent file.",
    "Prefer files already named in code_evidence_files, workflow backing, or the failing interaction seam.",
    "Update updated_workflows only when the repaired code changes workflow truth.",
    "Do not repair red-package artifacts here. Do not edit engine, runtime, orchestration, or prompt-loading layers unless the failure explicitly originates there.",
    "If the issue is workflow-only, artifact-only, or runtime-only, leave code unchanged and explain it in unresolvable_failures.",
    "Return only changed files with full contents, updated_workflows, and unresolvable_failures.",
    "This is repair iteration 1. Stay on the current failing seam. Do not revisit clean surfaces.",
    "Return JSON only."
  ],
  "context": {
    "failing_workflows": [
      {
        "workflow_id": "wf_recovery_email_sent",
        "side_effect": { "id": "se_recovery_email_sent", "name": "Recovery email sent" },
        "needed_interaction_points": [
          { "kind": "endpoint", "name": "POST /api/carts/{cart_id}/recover" }
        ]
      }
    ],
    "validation_errors": [
      "wf_recovery_email_sent: MISSING_INTERACTION_POINTS endpoint route not declared"
    ],
    "code_evidence_files": [
      {
        "path": "src/cart/recovery.py",
        "content": "def recover_cart(cart_id: str):
    queue_recovery_email(cart_id)
"
      }
    ],
    "side_effects_artifact": { "idea_id": "idea_checkout_recovery_v1", "side_effects": [{ "id": "se_recovery_email_sent" }] },
    "implicated_users_artifact": { "idea_id": "idea_checkout_recovery_v1", "implicated_users": [{ "kind": "human", "scope": "customer_account", "authority": "self", "rationale": "customer receives reminder" }], "denied_candidates": [] },
    "implemented_stories": [
      { "story_id": "STORY-recovery-email-send", "title": "Send recovery reminder email", "side_effect_ids": ["se_recovery_email_sent"], "required_planes": [] }
    ]
  },
  "output_schema": "CodeRepairArtifact.model_json_schema()",
  "return_format": "json_only"
}
```
