# Validate Repair

Repair only the failing workflow and idea-acceptance coverage surfaces so deterministic validation can continue.

- Resolve every item in repair_sources with the smallest workflow + coverage delta that fixes the current failure.
- Stay on the primary failing seam for each workflow and failing idea acceptance criterion; work only on remaining failing criteria/workflows and leave clean or already-proven sections untouched.
- Treat protected_sections as immutable context and obey every item in do_not_touch.
- When idea-acceptance failures are present, repair only the workflows/coverage entries needed to cover the failing criteria or restore the missing seam.
- Do not re-summarize the full artifact on repair passes; update only the scoped enriched_workflows and scoped idea_acceptance_coverage entries you were given.
- Do not revisit already-stable criteria unless you can cite a contradiction in the current artifact, and if you do, cite that contradiction explicitly in repair_delta_ledger.contradiction_citations.
- Preserve workflow_ids, side-effect anchoring, criterion_index, criterion text, and any supported evidence.
- Make missing code, runtime, or orchestration causes explicit instead of smuggling them into workflow or coverage edits.
- Do not invent evidence, broaden workflow scope, or rewrite adjacent workflows/criteria.
- Return enriched_workflows with the same workflow_ids and an updated idea_acceptance_coverage artifact.
- Return repair_delta_ledger with all of:
  - verdict_changes: every criterion/workflow verdict change made in this pass.
  - evidence_changes: every new, removed, or corrected evidence reference used in this pass.
  - newly_resolved_seams: each seam newly resolved in this pass.
  - contradiction_citations: only contradictions in the current artifact that justify revisiting a stable criterion.
- Return JSON only.
