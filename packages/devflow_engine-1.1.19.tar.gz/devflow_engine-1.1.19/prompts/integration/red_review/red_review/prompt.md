# Red Review

Review red integration proof packages for alignment, adequacy, and coverage.

- Review every red package against its workflow and side effect.
- Find overreach, under-assertion, weak interaction-point anchoring, and missing actor-route coverage.
- Return reviewed_packages plus findings and repair_directions per workflow.
- Keep critiques evidence-based; do not invent unsupported failures.
- Return JSON only.
