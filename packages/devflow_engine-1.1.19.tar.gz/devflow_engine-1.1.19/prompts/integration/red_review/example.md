# Red Review node assembled payload

## Provenance

Reconstructed from:

- `prompts/integration/red_review/red_review/prompt.md`
- `src/devflow_engine/integration/dag.py` red review agent call
- `src/devflow_engine/agentic_runtime.py`
- `RedReviewArtifact` in `src/devflow_engine/integration/dag.py`

Not copied from a persisted past-run integration prompt.

## Stable doctrine vs actual payload

- Stable node doctrine file: `prompts/integration/red_review/node_config/prompt.md`
- Actual `instructions` come from `red_review/red_review/prompt.md`
- Actual `context` comes from `task_context.metadata` + `event.idea_id`
- No skills or tools are injected here

```json
{
  "task": "integration_red_review",
  "instructions": [
    "Review every red package against its workflow and side effect.",
    "Find overreach, under-assertion, weak interaction-point anchoring, and missing actor-route coverage.",
    "Return reviewed_packages plus findings and repair_directions per workflow.",
    "Keep critiques evidence-based; do not invent unsupported failures.",
    "Return JSON only."
  ],
  "context": {
    "idea_id": "idea_checkout_recovery_v1",
    "validated_workflows": [
      {
        "workflow_id": "wf_recovery_email_sent",
        "side_effect": { "id": "se_recovery_email_sent", "name": "Recovery email sent" },
        "interaction_points": [
          { "kind": "endpoint", "name": "POST /api/carts/{cart_id}/recover", "implemented": true }
        ]
      }
    ],
    "red_artifact": {
      "idea_id": "idea_checkout_recovery_v1",
      "summary": "Generated one failing package.",
      "packages": [
        {
          "workflow_id": "wf_recovery_email_sent",
          "side_effect_id": "se_recovery_email_sent",
          "status": "failing",
          "harness_selection": {
            "harness_kind": "endpoint_harness",
            "interaction_point_ref": "POST /api/carts/{cart_id}/recover",
            "interaction_point_kind": "endpoint",
            "rationale": "Workflow is entered through an API endpoint.",
            "gap_explicit": false
          },
          "failing_artifacts": [],
          "expected_assertions": [
            { "assertion_id": "assert_response_accepted", "summary": "response indicates recovery request accepted", "evidence_anchor": "HTTP 202" }
          ],
          "implicated_user_routes": [],
          "gap_notes": []
        }
      ]
    },
    "validation_report": { "passed": true, "errors": [] }
  },
  "output_schema": "RedReviewArtifact.model_json_schema()",
  "return_format": "json_only"
}
```
