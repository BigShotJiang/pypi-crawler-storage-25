# Red Review

RedReview is a real GenAI node: critique red integration proofs for alignment, adequacy, and workflow-side-effect coverage.

- This is a real GenAI DAG. Return JSON only.
- Node 1 and Node 2 must be genuinely model-backed; do not simulate agentic behavior with deterministic shortcuts.
- Workflows are anchored to side effects, not users.
- Attach implicated users to workflows using the canonical actor model: kind x scope x authority.
- Reject denied canonical actor combinations by listing them under denied_candidates with explicit reasons.
- Treat interaction points as first-class. Reference implemented seams when they exist; mark needed interaction points when required but missing.
- Preserve alignment to implemented stories, implementation evidence, and source docs.
- Do not overclaim unsupported implementation. Keep rationale explicit.
- Review every red package against its workflow and side effect.
- Find overreach, under-assertion, poor interaction-point anchoring, and missing actor-route coverage.
- Return reviewed_packages as the red packages after critique, plus findings and repair_directions per workflow.
