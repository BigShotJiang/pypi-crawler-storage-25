# Red Review Node Contract

Review red integration proof packages for alignment, adequacy, and coverage.

## What this file is

Stable node doctrine loaded by:

- `load_integration_node_instruction("red_review")`
- `RedReviewNode.get_agent_config()`

## What actually reaches the model

The model-facing payload is assembled from:

- stage bullets in `prompts/integration/red_review/red_review/prompt.md`
- runtime `context_payload` from `src/devflow_engine/integration/dag.py`
- `RedReviewArtifact.model_json_schema()`
- `return_format: "json_only"`

## Real injected runtime components

`context_payload` fields:

- `idea_id` ← `event.idea_id`
- `validated_workflows` ← `task_context.metadata["workflows"]`
- `red_artifact` ← `task_context.metadata["red_artifact"]`
- `validation_report` ← `task_context.metadata["validation_report"]`

`instructions` source:

- bullets parsed from `prompts/integration/red_review/red_review/prompt.md`

`output_schema` source:

- `RedReviewArtifact.model_json_schema()`

## Tools / skills / config

- No integration-specific skills are injected.
- No tool definitions are injected.
