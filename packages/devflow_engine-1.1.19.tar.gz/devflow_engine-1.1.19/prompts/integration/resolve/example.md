# Resolve node assembled payloads

## Provenance

This file is **reconstructed from code**, not copied from a captured integration agent run.

Concrete sources used:

- stage prompt bullets:
  - `prompts/integration/resolve/resolve_side_effects/prompt.md`
  - `prompts/integration/resolve/resolve_implicated_users/prompt.md`
- runtime context assembly:
  - `src/devflow_engine/integration/dag.py` (`run_integration_agent_step(... context_payload=...)` for resolve)
- prompt envelope assembly:
  - `src/devflow_engine/agentic_runtime.py` → `_build_prompt(...)`
- output schema source:
  - `src/devflow_engine/integration/dag.py` → `SideEffectsArtifact`, `ImplicatedUsersArtifact`

## Stable doctrine vs actual payload

- Stable node doctrine file: `prompts/integration/resolve/node_config/prompt.md`
- Actual `instructions` in the model payload come from the stage prompt files above.
- Actual `context` comes from `integration/dag.py`.
- Current integration path injects no skills and no tools here.

## Assembled payload: `integration_resolve_side_effects`

```json
{
  "task": "integration_resolve_side_effects",
  "instructions": [
    "Use only supported evidence from the implemented idea, implemented stories, code evidence, and source docs.",
    "Return every side effect the implementation actually accomplishes.",
    "For each side effect, include concise rationale and supported story_ids.",
    "Include concrete interaction_points when implemented; otherwise use needed_interaction_points.",
    "Populate alignment_context with brief counts or notes that help downstream validation.",
    "Return JSON only."
  ],
  "context": {
    "idea_id": "idea_checkout_recovery_v1",
    "implemented_idea": {
      "idea_id": "idea_checkout_recovery_v1",
      "title": "Recover abandoned checkout carts",
      "summary": "Detect abandoned carts and send recovery reminders when consent is present."
    },
    "implemented_stories": [
      {
        "story_id": "STORY-cart-abandonment-detection",
        "title": "Detect abandoned carts",
        "side_effect_ids": ["se_cart_marked_abandoned"]
      },
      {
        "story_id": "STORY-recovery-email-send",
        "title": "Send recovery reminder email",
        "side_effect_ids": ["se_recovery_email_sent"]
      }
    ],
    "code_evidence": [
      { "path": "src/cart/recovery.py", "side_effect_ids": [], "interaction_points": [] },
      { "path": "src/jobs/recovery_email_job.py", "side_effect_ids": [], "interaction_points": [] }
    ],
    "source_docs": [
      { "path": "ai_docs/context/v2/project_docs/user_workflows.md" },
      { "path": "ai_docs/context/v2/project_docs/domain_entities.md" }
    ],
    "canonical_actor_allowed_combinations": [
      ["human", "customer_account", "self"],
      ["human", "organization_workspace", "admin"],
      ["system", "organization_workspace", "service"],
      ["system", "platform", "service"]
    ]
  },
  "output_schema": "SideEffectsArtifact.model_json_schema() from src/devflow_engine/integration/dag.py",
  "return_format": "json_only"
}
```

## Assembled payload: `integration_resolve_implicated_users`

Same runtime context fields, but different stage prompt bullets and different output schema:

```json
{
  "task": "integration_resolve_implicated_users",
  "instructions": [
    "Use only supported evidence from the implemented idea, implemented stories, code evidence, and source docs.",
    "Resolve implicated users into the canonical actor model only: kind, scope, authority, rationale.",
    "Only emit canonical actor combinations allowed by the provided context.",
    "Put rejected combinations in denied_candidates with explicit reasons.",
    "Do not invent story-local role labels or unsupported actors.",
    "Return JSON only."
  ],
  "context": "same field set and sources as integration_resolve_side_effects",
  "output_schema": "ImplicatedUsersArtifact.model_json_schema() from src/devflow_engine/integration/dag.py",
  "return_format": "json_only"
}
```

## Transport/runtime config that is separate from the prompt body

At `run_agent_step(...)` call time:

- `delivery_model="streaming"`
- `interaction_model="agentic"`
- `response_contract="json_only"`

If Anthropic API transport is selected later by `invoke_llm(...)`, the HTTP payload uses:

- `system_prompt=""`
- one user message containing the JSON prompt above
- `tools=[]`
