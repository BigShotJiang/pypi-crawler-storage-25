# Resolve Side Effects

Identify implemented side effects from the provided evidence.

- Use only supported evidence from the implemented idea, implemented stories, code evidence, and source docs.
- Return every side effect the implementation actually accomplishes.
- For each side effect, include concise rationale and supported story_ids.
- Include concrete interaction_points when implemented; otherwise use needed_interaction_points.
- Populate alignment_context with brief counts or notes that help downstream validation.
- Return JSON only.
