# Resolve Implicated Users

Identify implicated canonical actors from the provided evidence.

- Use only supported evidence from the implemented idea, implemented stories, code evidence, and source docs.
- Resolve implicated users into the canonical actor model only: kind, scope, authority, rationale.
- Only emit canonical actor combinations allowed by the provided context.
- Put rejected combinations in denied_candidates with explicit reasons.
- Do not invent story-local role labels or unsupported actors.
- Return JSON only.
