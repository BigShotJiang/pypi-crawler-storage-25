# Resolve Node Contract

Identify implemented side effects and implicated canonical actors from the provided evidence.

## What this file is

This file is the stable node doctrine for the Resolve node.

It is loaded by:

- `src/devflow_engine/integration/prompts.py` → `load_integration_node_instruction("resolve")`
- `src/devflow_engine/integration/dag.py` → `ResolveSideEffectsAndImplicatedUsersNode.get_agent_config()`

## What this file is not

It is **not** the literal prompt body sent to the model by the current integration runtime.

The current model-facing prompt is assembled from:

- stage prompt bullets in:
  - `prompts/integration/resolve/resolve_side_effects/prompt.md`
  - `prompts/integration/resolve/resolve_implicated_users/prompt.md`
- runtime `context_payload` built in `src/devflow_engine/integration/dag.py`
- `output_schema` injected by `src/devflow_engine/agentic_runtime.py`
- `return_format: "json_only"` injected by `src/devflow_engine/agentic_runtime.py`

## Real injected runtime components for this node

### Resolve side effects stage

`context_payload` fields:

- `idea_id` ← `event.idea_id`
- `implemented_idea` ← `event.implemented_idea`
- `implemented_stories` ← `event.implemented_stories`
- `code_evidence` ← `event.code_evidence`
- `source_docs` ← `event.source_docs`
- `canonical_actor_allowed_combinations` ← sorted `CANONICAL_ACTOR_ALLOWED_COMBINATIONS`

`instructions` source:

- bullets parsed from `prompts/integration/resolve/resolve_side_effects/prompt.md`

`output_schema` source:

- `SideEffectsArtifact.model_json_schema()`

### Resolve implicated users stage

Same `context_payload` sources as above.

`instructions` source:

- bullets parsed from `prompts/integration/resolve/resolve_implicated_users/prompt.md`

`output_schema` source:

- `ImplicatedUsersArtifact.model_json_schema()`

## Tools / skills / config

- No integration-specific skills are injected here.
- No tool definitions are assembled here.
- Runtime model/provider selection is handled separately by `src/devflow_engine/llm/invoke.py`.
