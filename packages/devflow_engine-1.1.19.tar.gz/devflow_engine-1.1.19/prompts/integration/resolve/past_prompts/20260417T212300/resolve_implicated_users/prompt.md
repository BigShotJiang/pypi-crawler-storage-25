# Resolve Implicated Users

Resolve implemented idea side effects and implicated canonical actors from implementation evidence.

- This is a real GenAI DAG. Return JSON only.
- Node 1 and Node 2 must be genuinely model-backed; do not simulate agentic behavior with deterministic shortcuts.
- Workflows are anchored to side effects, not users.
- Attach implicated users to workflows using the canonical actor model: kind x scope x authority.
- Reject denied canonical actor combinations by listing them under denied_candidates with explicit reasons.
- Treat interaction points as first-class. Reference implemented seams when they exist; mark needed interaction points when required but missing.
- Preserve alignment to implemented stories, implementation evidence, and source docs.
- Do not overclaim unsupported implementation. Keep rationale explicit.
- Resolve implicated users into the canonical actor model only: kind, scope, authority, rationale.
- Reject non-listed canonical actor combinations into denied_candidates with explicit reasons.
- Do not invent story-local role labels as canonical actor classes.
