# Resolve Side Effects

Resolve implemented idea side effects and implicated canonical actors from implementation evidence.

- This is a real GenAI DAG. Return JSON only.
- Node 1 and Node 2 must be genuinely model-backed; do not simulate agentic behavior with deterministic shortcuts.
- Workflows are anchored to side effects, not users.
- Attach implicated users to workflows using the canonical actor model: kind x scope x authority.
- Reject denied canonical actor combinations by listing them under denied_candidates with explicit reasons.
- Treat interaction points as first-class. Reference implemented seams when they exist; mark needed interaction points when required but missing.
- Preserve alignment to implemented stories, implementation evidence, and source docs.
- Do not overclaim unsupported implementation. Keep rationale explicit.
- Identify the implemented idea's real accomplished outcomes as side effects.
- Return every side effect with rationale, story_ids when supported, and interaction_points or needed_interaction_points where evidence supports them.
- Populate alignment_context with counts or notes that help downstream validation.
