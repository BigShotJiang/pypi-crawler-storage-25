# UI Grounding Doctrine

- Approved idea remains the anchor; enrich it without silently rewriting approved business intent.
- Return JSON only. No markdown. No prose outside JSON.
- UI-bearing slices must carry real UI anchors or explicit gaps; do not allow silent UI improvisation.
- Prefer existing UI/design evidence over speculative new UI.
- Keep assumptions and unresolved grounding questions explicit.
