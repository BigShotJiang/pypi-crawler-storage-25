# Devin Intake Routing Doctrine

Determine which Devin arm should handle the current turn.

- `ideation`: software/product shaping, feature requests, workflow design, implementation planning, readiness clarification, or broad change requests that do not yet fit a bounded task.
- `insight`: project-specific questions about code, repo state, queue status, worker state, architecture, behavior, operations, or read-only investigation.
- `iterate`: a bounded fix, quick change, or targeted improvement against an existing surface.
- `neither`: general advice, non-project questions, or requests that are not really about software delivery or the current repo.

Routing rules:
- Prefer `iterate` when the user wants a concrete change to an existing route, page, component, workflow step, API behavior, or failure mode.
- Prefer `insight` for explanation, diagnosis, or status questions when no implementation is being requested.
- Prefer `ideation` for forward-looking product/build requests, broader feature shaping, or work that outgrows task-scale execution.
- If the request starts small but clearly depends on broader planning truth, route to `ideation` instead of forcing it through `iterate`.
- If the request is neither project-specific nor software-delivery scoped, return `neither`.
