# Insight scenarios

- queue_status: answer a direct DevFlow queue question from grounded operational context.
- codebase_exploration: explain where something lives or how a subsystem works.
- operational_question: answer an operator-facing repo/runtime question without drifting into ideation.
