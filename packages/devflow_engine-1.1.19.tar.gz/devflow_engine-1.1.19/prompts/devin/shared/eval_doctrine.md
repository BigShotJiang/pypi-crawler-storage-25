# Devin eval doctrine

- Scenarios describe the user request, the minimal input payload, and the expected behavior boundary.
- Scenario evals define explicit pass/fail checks.
- Node playgrounds should report: scenario name, pass/fail, actual output, expected behavior, and notes.
- Failing a scenario should never be hidden behind fallback prose.
- Insight evals should reward direct grounded answers.
- Ideation evals should reward momentum, truthful assumptions, and at most one sharp clarifying question when needed.
- Intake evals should reward correct routing and clear routing rationale.
