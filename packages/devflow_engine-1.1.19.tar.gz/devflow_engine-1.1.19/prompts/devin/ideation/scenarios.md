# Ideation scenarios

- idea_to_story: shape a rough feature idea into a readiness-oriented response.
- readiness_contract: answer with truthful contract/readiness framing when the idea is mostly specified.
- ddr_preprocessing: use DDR/source-material context as supporting evidence without pretending canonical docs were already generated.
