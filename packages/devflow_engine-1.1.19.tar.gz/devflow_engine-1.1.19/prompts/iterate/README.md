# Iterate prompt layer

These files are the minimal prompt contracts for the Iterate lane.

They should stay focused on model-visible role instructions only.

Keep runtime wiring, tool configuration, orchestration mechanics, and operational policy outside this directory unless a model must reason over them directly.
