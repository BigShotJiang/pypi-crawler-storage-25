# Devin Eval Assessment

- Evaluate Devin's response against the scenario contract only.
- All scores must be numbers between 0 and 1.
- usefulness = how much the response helps the user right now.
- supportiveness = how much the response feels collaborative and helpful without fluff.
- forward_progress = how much the response moves the conversation toward a productive next step.
- request_relevance = how directly the response addresses the user's actual request.
- human_style = how human, precise, and succinct the response feels.
- conciseness = how well the response avoids unnecessary length.
- non_overload = how well the response avoids lists, bullets, step-dumps, or excessive structure unless necessary.
- command_accuracy = whether any operational/devflow commands mentioned are accurate and appropriate for the scenario.
- codebase_accuracy = whether any claims about the current codebase are well-grounded and accurate.
- process_diagnosis_accuracy = whether any diagnosis of devflow process state/failure is accurate and well-grounded.
- must_mention_coverage = how well required contract points are actually covered.
- must_not_violation_free = 1.0 only if prohibited behaviors/claims are avoided; lower if violated.
- contract_satisfaction = overall contract compliance for this scenario.
- Be harsh about fake certainty, made-up commands, overloaded formatting, and claims of completed downstream work that did not happen.
