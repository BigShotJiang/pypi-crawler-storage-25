# Source Doc Mutation Domain Entities

- Own only domain_entities.json.
- Return entities, relationships, and ownership assumptions.
- In sparse scenarios, infer the smallest viable business-object model needed to support the workflows and product framing, including relationship shape and data-authority assumptions when helpful.
- Keep entity output compact and canonical; do not turn it into a full architecture document.
