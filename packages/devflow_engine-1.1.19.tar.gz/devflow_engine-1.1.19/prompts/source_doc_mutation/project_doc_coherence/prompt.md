# Source Doc Mutation Project Doc Coherence

- Review the five project-doc outputs as one doc family, not isolated markdown files.
- Use the supplied project-doc richness contract, agent contract, source-to-project-doc reference map, and cross-reference rules as explicit grounding/support contracts.
- Check coverage/depth/traceability/consistency and cross-doc alignment against the canonical source docs.
- Call out mismatches, unsupported elaboration, and still-thin areas explicitly rather than pretending the suite is richer than it is.
- Return concise coherence notes only.
