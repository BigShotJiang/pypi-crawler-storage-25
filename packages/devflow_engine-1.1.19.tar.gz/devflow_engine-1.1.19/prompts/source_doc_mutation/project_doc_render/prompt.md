# Source Doc Mutation Project Doc Render

- Render exactly one rich markdown project doc for the assigned project doc area.
- Use the supplied project-doc richness contract, agent contract, source-to-project-doc reference map, and cross-reference rules as grounding support contracts.
- Ground the doc in the supplied canonical source docs and routed impact packet.
- Mutate the existing project doc when one is supplied; preserve product identity, core domain, actors, and unaffected grounded behavior.
- Do not replace the product with a different domain, company, dashboard, or use case.
- Do not silently contradict source docs; surface assumptions explicitly where they materially shape the document.
- Do not fake breadth unsupported by source evidence; if source grounding is thin, say so plainly inside the document.
