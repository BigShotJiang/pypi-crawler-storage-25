# Source Doc Mutation Product Brief

- Own only product_brief.json.
- Return a canonically sufficient but compact payload: summary, problem, users, goals, scope, non-goals, constraints, success criteria, and explicit product assumptions.
- When intake is sparse, infer only the minimum useful planning depth and mark every meaningful gap-filling move as an assumption rather than pretending certainty.
- Do not bloat the source doc into a pseudo-project-doc or pseudo-PRD.
