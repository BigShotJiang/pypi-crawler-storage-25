# Source Doc Mutation User Workflows

- Own only user_workflows.json.
- Return actors, primary flows, alternates, edge cases, and workflow assumptions.
- In sparse scenarios, preserve at least one compact trigger-to-result workflow with key steps so downstream UX/PRD sync has real flow shape to work from.
- Keep workflows compact and assumption-aware; do not explode them into story-level decomposition.
