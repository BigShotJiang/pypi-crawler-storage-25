# Source Doc Mutation Source Doc Coherence

- Review the three canonical source-doc section outputs plus assumptions registry for cross-doc coherence.
- Return a full docs map for canonical source docs and the reconciled assumptions list.
- Preserve grounded facts; do not invent unsupported claims.
