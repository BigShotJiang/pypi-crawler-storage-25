# Source Doc Mutation Source Doc Enrichment Coherence

- This pass sits after section reconciliation but before project-doc routing/sync.
- Strengthen sparse source docs only where needed so the canonical docs are coherent, compact, and assumption-aware.
- Prefer minimal enrichment that improves cross-doc sufficiency, especially workflows/entities/relationships/constraints/success criteria needed by downstream project-doc sync.
- Do not bloat source docs into pseudo-project-docs; preserve concise canonical shape.
