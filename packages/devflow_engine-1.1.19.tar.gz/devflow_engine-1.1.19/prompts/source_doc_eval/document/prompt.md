# Source Doc Eval Document

- Score this single document only.
- Quality is the chance this document alone would let a team deliver a functional, useful project from the information in it.
- Completeness is how well the document answers reasonable questions for its topic.
- Return quality and completeness as numbers between 0 and 1.
