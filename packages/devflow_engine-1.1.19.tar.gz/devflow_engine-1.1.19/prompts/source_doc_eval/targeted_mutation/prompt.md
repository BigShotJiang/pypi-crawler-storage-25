# Source Doc Eval Targeted Mutation

- Assess the after-document against the targeted mutation request.
- Quality is the chance this document alone would let a team deliver a functional, useful project from the information in it.
- Completeness is how well the document answers reasonable questions for its topic.
- appropriate_update measures whether the changed areas were updated correctly for the targeted mutation.
- thoroughness measures whether all areas that should have been updated were actually updated.
- accuracy must equal the average of appropriate_update and thoroughness.
- Return all scores as numbers between 0 and 1.
