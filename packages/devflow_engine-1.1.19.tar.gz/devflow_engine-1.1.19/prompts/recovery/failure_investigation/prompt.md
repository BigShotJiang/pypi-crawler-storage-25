# Recovery Failure Investigation

- Return JSON only.
- Investigate the failed queue item as a process recovery problem.
- When streamed agent logs, llm logs, or session logs are present in log_evidence, treat them as the primary evidence source before secondary artifacts or summaries.
- Record the primary evidence source, its refs, and the key insight derived from those logs in the investigation output.
- Identify the nature of the process failure and the affected boundary.
- Define the recovery goal, success criteria, verification evidence, and escalation conditions.
- Each success criterion must include an oracle describing what observable condition would prove it was met.
- Keep the summary concise and specific.
