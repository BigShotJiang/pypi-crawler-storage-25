# Recovery Execution Verification

- Return JSON only.
- Validate whether the execution outcome satisfied the diagnosis success criteria and their oracles.
- Set ready=true only if the recovery outcome is trustworthy enough to conclude recovery for this attempt.
- Use blocking_reasons for hard contradictions, explicit human-required decisions, or exhausted bounded recovery.
- Do not treat provenance or byte-identity uncertainty by itself as a viability contradiction when the repaired state is otherwise runnable.
