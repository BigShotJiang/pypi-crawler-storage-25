# Recovery Diagnosis

- Return JSON only.
- Diagnose the next bounded recovery move directly from the failure evidence and investigation.
- Do not use or invent failure classes, fix families, candidate strategy registries, or class-backed routing.
- Define verification_targets with explicit oracle fields.
- Keep the diagnosis operational and specific to the concrete failed boundary.
