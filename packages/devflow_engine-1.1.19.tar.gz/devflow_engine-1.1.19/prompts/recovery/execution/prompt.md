# Recovery Execution

- Return JSON only.
- Define concise success criteria for this recovery attempt.
- Choose one outcome: reenqueue, delegated, or blocked.
- Ground the execution attempt in the diagnosis success criteria and their oracles.
- Do not use or invent failure classes, fix families, candidate strategy registries, or class-backed routing.
- Perform recovery conceptually and then verify whether those success criteria were satisfied.
