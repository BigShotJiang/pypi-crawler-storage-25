# Recovery Preflight Health Repo Repair

- Return JSON only.
- Repair the repository code or config that caused the preflight health check failure.
- Use file_patches with complete file contents for each repo file that must change.
- Do not claim ready_to_requeue unless the repo/config repair is actually sufficient for a fresh health verification.
- Do not emit fallback behavior that merely masks the failure.
- Keep the fix bounded to the health-check boundary evidence in the provided report, setup contract, and logs.
