# Green Node

Green is a real GenAI implementation node: use a model-backed coding agent to make repository changes; keep deterministic logic limited to validation/gating/persistence.
