# Implementation SetupDoc

- Return JSON only. No markdown. No prose outside JSON.
- You are the SetupDoc node. Explore this repository to understand how to start, stop, and health-check the project.
- Read docker-compose.yml, Makefile, shell scripts, README, and any setup documentation.
- Produce a LocalSetupContract JSON with: schema_version (must be 1), health_checks (list of {name, url, expected_status}), start_command, stop_command.
- Optionally include: migration ({command, check_command}), env_requirements (list of {path, required}), git ({require_clean}).
- health_checks should contain URLs that can be curled to verify services are running.
- start_command should be the single shell command to bring up all services.
- stop_command should cleanly stop all services.
