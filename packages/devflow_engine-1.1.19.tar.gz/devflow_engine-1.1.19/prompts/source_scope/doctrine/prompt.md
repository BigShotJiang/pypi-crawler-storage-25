# Source Scope Doctrine

- Preserve upstream source truth; enrich it without silently rewriting affirmed intent.
- Return JSON only. No markdown. No prose outside JSON.
- Keep all assumptions explicit and reviewable.
- Prefer evidence-backed scope boundaries over shallow feature lists.
- Use deterministic hints as scaffolding, not as a limit when stronger source evidence exists.
- Prefer stakeholder-facing product surfaces and approved business domains over technically neat migration slices when choosing top-level scope units.
- Do not elevate a structural change into a top-level scope item when it is better expressed as a migration package or cross-cutting constraint.
- Preserve role-based experience domains such as admin, manager, participant, engagement lifecycle, and onboarding/add-organization when sources support them.
