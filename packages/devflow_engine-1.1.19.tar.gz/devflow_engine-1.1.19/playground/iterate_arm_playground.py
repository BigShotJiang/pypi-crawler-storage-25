from __future__ import annotations

import argparse
import asyncio
import importlib.util
import json
import sys
import types
from contextlib import contextmanager
from pathlib import Path
from typing import Any
import uuid

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from devin.nodes.iterate import node as iterate_node_module
from devflow_engine.devin2 import pi_runner as pi_runner_module
from devflow_engine.llm import cli_one_shot
from devin.nodes.iterate.node import IterateAgentNode
from devin.nodes.shared.helpers import set_runtime_store
from devin.nodes.shared.models import DevinAgentResponse, DevinChatDagEvent, ScenarioResult
from devflow_engine.stores.execution_store import ExecutionStore
from devflow_engine.vendor.datalumina_genai.core.task import TaskContext

SCENARIO_DIR = ROOT / "src" / "devin" / "nodes" / "iterate" / "scenarios"
PLAYGROUND_LIMITATION_NOTE = (
    "BUSINESS-LOGIC-ONLY playground: validates iterate orchestration, lane decisions, and contract wiring; "
    "it does NOT validate real LLM response quality or real agent behavior."
)


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=f"Run iterate arm playground ({PLAYGROUND_LIMITATION_NOTE})")
    parser.add_argument("--repo-root", type=str, default="/Users/devflow/repos/Spicy-Server")
    parser.add_argument("--project", type=str, default="proj_75f63d30")
    parser.add_argument("--scenario-name", action="append", default=[], help="Run only the named scenario (repeatable)")
    parser.add_argument("--scenario-file", action="append", default=[], help="Run only the given scenario file path (repeatable)")
    parser.add_argument("--output-file", type=str, default="", help="Write full result JSON to this file")
    parser.add_argument("--real-llm", action="store_true", help="Run with real LLM (skip stub). Validates actual model behavior.")
    parser.add_argument("--timeout", type=int, default=300, help="Timeout per scenario in seconds for real-llm mode (default 300)")
    return parser.parse_args()


def _module_name_for(path: Path) -> str:
    rel = path.relative_to(SRC).with_suffix("")
    return ".".join(rel.parts)


def _load_module(module_name: str, path: Path):
    spec = importlib.util.spec_from_file_location(module_name, path)
    module = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    return module


def _normalize_expected_behavior(module: types.ModuleType) -> None:
    expected = getattr(module, "EXPECTED_BEHAVIOR", None)
    if not isinstance(expected, dict):
        return
    if expected.get("calls_tool") == "devin_insight":
        expected.setdefault("response_kind", "route_to_insight")
        expected.setdefault("target_lane", "insight")
        expected.setdefault("response_kind_in", ["completed", "blocked", "needs_more_context"])
    if expected.get("uses_tool") == "call_devin_ideation":
        expected.setdefault("response_kind", "promote_to_idea")
        expected.setdefault("target_lane", "idea")
        expected.setdefault("response_kind_in", ["completed", "blocked", "needs_more_context"])


def _collect_scenarios(
    *,
    selected_names: set[str],
    selected_files: set[Path],
) -> list[tuple[types.ModuleType, types.ModuleType]]:
    pairs: list[tuple[types.ModuleType, types.ModuleType]] = []
    wanted_files = {path.resolve() for path in selected_files}
    for scenario_path in sorted(SCENARIO_DIR.glob("*.py")):
        if scenario_path.name.endswith("_evals.py"):
            continue
        if selected_names and scenario_path.stem not in selected_names:
            continue
        if wanted_files and scenario_path.resolve() not in wanted_files:
            continue

        eval_path = scenario_path.with_name(f"{scenario_path.stem}_evals.py")
        if not eval_path.exists():
            continue

        scenario_module = _load_module(_module_name_for(scenario_path), scenario_path)
        _normalize_expected_behavior(scenario_module)
        eval_module = _load_module(_module_name_for(eval_path), eval_path)
        pairs.append((scenario_module, eval_module))

    return pairs


def _stubbed_response_for(*, scenario_name: str, input_payload: dict[str, Any], pipeline_dir: Path) -> dict[str, Any]:
    if scenario_name == "devin_iterate_routing":
        return {
            "response_message": "Completed the routing request inside iterate.",
            "response_kind": "completed",
            "suggested_next_step": "Proceed with a bounded fix on the existing surface.",
            "follow_up_questions": [],
            "style_notes": ["deterministic_playground_stub", "iterate_routing"],
            "target_lane": "iterate",
            "tool_calls": [],
        }

    if scenario_name == "iterate_error_fix":
        raw = str(input_payload.get("current_user_message") or "").strip()
        return {
            "response_message": (
                "Completed a bounded reproducible error-fix path in iterate. "
                f"Preserved request context: {raw[:120] if raw else 'reported bug context'}"
            ),
            "response_kind": "completed",
            "suggested_next_step": "Verify the failing route now resolves and existing behavior is preserved.",
            "follow_up_questions": [],
            "style_notes": ["deterministic_playground_stub", "error_fix"],
            "target_lane": "iterate",
            "tool_calls": [],
            "preserved_error_context": bool(raw),
        }

    if scenario_name == "iterate_to_insight_reroute":
        promotion_handoff = {
            "task_id": f"task-{scenario_name}",
            "target_lane": "insight",
            "decided_by": "Iterator",
            "reason": "Current request needs grounded diagnosis before code changes.",
            "handoff_summary": "Investigate whether current behavior is correct before repairing.",
            "downstream": {
                "lane": "insight",
                "downstream_id": "insight-subagent-001",
                "downstream_artifact_ref": str(pipeline_dir / "insight_response.json"),
            },
            "source_refs": {
                "iterator_run_ref": str(pipeline_dir / "iterator_run.json"),
                "task_artifact_ref": str(pipeline_dir / "task_artifact.json"),
                "observation_artifact_ref": str(pipeline_dir / "observation_artifact.json"),
            },
        }
        handoff_path = pipeline_dir / "promotion_handoff.json"
        handoff_path.parent.mkdir(parents=True, exist_ok=True)
        handoff_path.write_text(json.dumps(promotion_handoff, indent=2, sort_keys=True) + "\n", encoding="utf-8")

        return {
            "response_message": "Iterate is staying owner, but the next step is insight-backed diagnosis.",
            "response_kind": "route_to_insight",
            "suggested_next_step": "Review the insight findings before deciding on code changes.",
            "follow_up_questions": [],
            "style_notes": ["deterministic_playground_stub", "tool:devin_insight"],
            "target_lane": "insight",
            "tool_calls": ["devin_insight"],
            "run_state": "promoted",
            "promotion_handoff": promotion_handoff,
            "handoff_ref": str(handoff_path),
            "insight_response": {
                "response_kind": "insight_response",
                "response_message": "Tax-like behavior was reviewed and remains the current implementation path.",
                "suggested_next_step": "Use this diagnosis to decide whether implementation is justified.",
                "follow_up_questions": [],
                "style_notes": ["deterministic_insight_tool_sim"],
            },
        }

    if scenario_name == "iterate_to_idea_promotion":
        promotion_handoff = {
            "task_id": f"task-{scenario_name}",
            "target_lane": "idea",
            "decided_by": "Iterator",
            "reason": "Request expands from a narrow change into broader workflow planning.",
            "handoff_summary": "Promote to ideation for configurable export workflow planning.",
            "downstream": {
                "lane": "idea",
                "downstream_id": "idea-promote-001",
                "downstream_artifact_ref": str(pipeline_dir / "idea_promotion.json"),
            },
            "source_refs": {
                "iterator_run_ref": str(pipeline_dir / "iterator_run.json"),
                "task_artifact_ref": str(pipeline_dir / "task_artifact.json"),
                "observation_artifact_ref": str(pipeline_dir / "observation_artifact.json"),
            },
        }
        handoff_path = pipeline_dir / "promotion_handoff.json"
        handoff_path.parent.mkdir(parents=True, exist_ok=True)
        handoff_path.write_text(json.dumps(promotion_handoff, indent=2, sort_keys=True) + "\n", encoding="utf-8")

        return {
            "response_message": "This request should be promoted to idea for broader workflow planning.",
            "response_kind": "promote_to_idea",
            "suggested_next_step": "Validate the broader feature shape before implementation.",
            "follow_up_questions": [],
            "style_notes": ["deterministic_playground_stub", "tool:call_devin_ideation"],
            "target_lane": "idea",
            "tool_calls": ["call_devin_ideation"],
            "run_state": "promoted",
            "promotion_handoff": promotion_handoff,
            "handoff_ref": str(handoff_path),
            "idea_response": {
                "response_kind": "ideation_contract_response",
                "response_message": "This scope looks larger than a narrow iterate task and needs idea shaping.",
                "suggested_next_step": "Collect required detail and finalize idea scope.",
                "follow_up_questions": ["What are the desired success criteria for the broader workflow?"],
                "style_notes": ["deterministic_ideation_tool_sim"],
            },
        }

    if scenario_name == "framer_scope_boundary":
        return {
            "response_message": "Framed the request as a bounded existing-surface label change to stay in iterate.",
            "response_kind": "completed",
            "suggested_next_step": "Proceed with the label update only.",
            "follow_up_questions": [],
            "style_notes": ["deterministic_playground_stub", "framer"],
            "target_lane": "iterate",
            "tool_calls": [],
            "recommended_next_step": "stay_iterate",
            "task_artifact": {
                "task_type": "quick_change",
                "summary": "Rename the dashboard KPI label without broader edits.",
                "surface": "dashboard KPI card label",
                "scope_boundary": "Change label text only.",
                "non_goals": ["No layout changes", "No analytics logic changes"],
            },
        }

    if scenario_name == "framer_task_framing":
        return {
            "response_message": "Framed the vague request as a bounded repair task with explicit unknowns.",
            "response_kind": "completed",
            "suggested_next_step": "Investigate the failing invite flow seam before coding.",
            "follow_up_questions": [],
            "style_notes": ["deterministic_playground_stub", "framer"],
            "target_lane": "iterate",
            "tool_calls": [],
            "recommended_next_step": "investigate_first",
            "task_artifact": {
                "task_type": "error_fix",
                "summary": "Diagnose and fix the invite flow behavior without redesigning the page.",
                "surface": "invite flow",
                "scope_boundary": "Bounded to existing invite flow surface.",
                "current_behavior": "Invite flow fails inconsistently.",
                "desired_behavior": "Invite flow completes consistently.",
                "success_criteria": ["Invite flow completes end-to-end"],
                "unknowns": {
                    "blocking": ["Exact failing seam still pending validation"],
                    "non_blocking": ["Root cause unknown"],
                },
                "non_goals": ["No page overhaul"],
            },
        }

    if scenario_name == "iterate_quick_change":
        return {
            "response_message": "Completed the bounded existing-surface change in iterate.",
            "response_kind": "completed",
            "suggested_next_step": "Confirm the surface still supports the original workflows.",
            "follow_up_questions": [],
            "style_notes": ["deterministic_playground_stub", "quick_change"],
            "target_lane": "iterate",
            "tool_calls": [],
            "task_artifact": {
                "task_type": "quick_change",
                "summary": "Small table default adjustment completed.",
                "surface": "invoices table filter",
                "scope_boundary": "No broader table redesign.",
            },
        }

    if scenario_name == "observer_evidence_seam":
        return {
            "response_message": "Observed a bounded failing seam with sufficient evidence to hand off for coder repair.",
            "response_kind": "completed",
            "suggested_next_step": "Repair the confirmed seam and re-verify green condition.",
            "follow_up_questions": [],
            "style_notes": ["deterministic_playground_stub", "observer"],
            "target_lane": "iterate",
            "tool_calls": [],
            "observation_artifact": {
                "status": "ready_for_coder",
                "failing_seam": "POST /api/invites/accept returns 500 when accepted_at is None.",
                "expected_green_condition": "Invite token reaches 200 and completes activation for valid requests.",
                "ready_for_coder": True,
                "evidence_summary": "Invite acceptance fails with a 500 tied to accepted_at handling.",
                "route": "POST /api/invites/accept",
                "log_excerpt": "TypeError: invite.accepted_at must be datetime, got None",
            },
        }

    if scenario_name == "observer_repro_creation":
        return {
            "response_message": "Created a narrow deterministic repro artifact for the import seam.",
            "response_kind": "completed",
            "suggested_next_step": "Use this repro artifact before any code change.",
            "follow_up_questions": [],
            "style_notes": ["deterministic_playground_stub", "observer"],
            "target_lane": "iterate",
            "tool_calls": [],
            "observation_artifact": {
                "status": "ready_for_coder",
                "repro_steps": [
                    "Upload CSV with email value ' alice@example.com '.",
                    "Open import preview.",
                    "Observe validation behavior for the whitespace case.",
                    "Apply trim rule and confirm valid import behavior.",
                ],
                "expected_green_condition": "Trimmed emails are accepted by validation; invalid addresses remain rejected.",
                "ready_for_coder": True,
                "evidence_summary": "Whitespace-only email row is rejected before trim.",
                "failing_seam": "Email validation runs before trim step.",
                "repro": [
                    "Upload CSV with trailing spaces",
                    "Preview import",
                    "Capture rejection",
                    "Add trim and re-run",
                ],
            },
            "task_artifact": input_payload.get("task_artifact") or {},
        }

    if scenario_name == "coder_artifact_alignment":
        return {
            "response_message": "Aligned coder work to the provided observation artifact and prepared a narrow report.",
            "response_kind": "completed",
            "suggested_next_step": "Apply only email trim logic in CSV import preview.",
            "follow_up_questions": [],
            "style_notes": ["deterministic_playground_stub", "coder"],
            "target_lane": "iterate",
            "tool_calls": [],
            "changed_files": ["src/import_wizard.py"],
            "verification": "CSV preview now accepts trimmed email values before validation and rejects malformed rows.",
            "summary": "Aligned changes to the observed CSV import artifact seam.",
            "what_changed": "trim() now runs before email validation in import parsing.",
            "what_passed": "Emails with trailing spaces import successfully.",
            "what_failed": "No unrelated import scope was altered.",
            "task_artifact": input_payload.get("task_artifact") or {},
        }

    if scenario_name == "coder_bounded_fix":
        return {
            "response_message": "Applied a tight invite acceptance fix based on the observation artifact.",
            "response_kind": "completed",
            "suggested_next_step": "Re-verify the invite acceptance path for valid tokens.",
            "follow_up_questions": [],
            "style_notes": ["deterministic_playground_stub", "coder"],
            "target_lane": "iterate",
            "tool_calls": [],
            "changed_files": ["src/invites/acceptance.py"],
            "verification": "Invite acceptance now sets accepted_at before persistence and returns 200 for valid token paths.",
            "summary": "Scoped the fix to invite acceptance only.",
            "what_changed": "Added guarded normalization before persistence when accepted_at is missing.",
            "what_passed": "invite acceptance passes for valid token.",
            "what_failed": "No unrelated modules were altered.",
            "remaining_blockers": "",
            "task_artifact": input_payload.get("task_artifact") or {},
        }

    return {
        "response_message": "Completed the bounded iterate request without rerouting or promoting.",
        "response_kind": "completed",
        "suggested_next_step": "Verify this iterate-owned change stays within the existing surface.",
        "follow_up_questions": [],
        "style_notes": ["deterministic_playground_stub", "iterate_fallback"],
        "target_lane": "iterate",
        "tool_calls": [],
    }


@contextmanager
def _patched_iterate_runner(*, scenario_name: str, input_payload: dict[str, Any]):
    original_runner = iterate_node_module.run_devin2_pi_agent
    original_dfs = iterate_node_module.dfs_node_running
    stubbed_holder: dict[str, Any] = {}

    def _fake_runner(
        *,
        repo_root: Path,
        stage_name: str,
        route_arm: str,
        context_payload: dict[str, Any],
        operational_guidance: list[str],
        output_model: type[DevinAgentResponse],
        timeout_seconds: int | None = None,
    ):
        del operational_guidance, stage_name, route_arm, timeout_seconds
        idea_id = str(context_payload.get("idea_id") or "playground_idea")
        pipeline_key = f"iterate-scenario-{scenario_name}"
        pipeline_dir = Path(repo_root) / ".devflow" / "ideas" / idea_id / "pipelines" / "devin_chat_dag" / pipeline_key
        pipeline_dir.mkdir(parents=True, exist_ok=True)

        stubbed = _stubbed_response_for(
            scenario_name=scenario_name,
            input_payload=input_payload,
            pipeline_dir=pipeline_dir,
        )
        stubbed_holder["value"] = stubbed

        required_fields = {
            "response_message": "Missing response",
            "response_kind": "completed",
            "suggested_next_step": "Proceed with a deterministic fallback next step.",
            "follow_up_questions": [],
            "style_notes": ["deterministic_playground_stub"],
        }
        response_payload = {k: stubbed.get(k, default) for k, default in required_fields.items()}
        response_model = output_model.model_validate(response_payload)

        return types.SimpleNamespace(
            response_model=response_model,
            prompt_payload={
                "playground_mode": "deterministic_stub",
                "scenario_name": scenario_name,
                "current_user_message": context_payload.get("current_user_message") or "",
            },
            invocation=types.SimpleNamespace(
                ok=True,
                stdout=json.dumps(response_payload),
                stderr="",
                parsed_json=response_payload,
            ),
        )

    iterate_node_module.run_devin2_pi_agent = _fake_runner
    iterate_node_module.dfs_node_running = lambda **kwargs: None
    try:
        yield stubbed_holder
    finally:
        iterate_node_module.run_devin2_pi_agent = original_runner
        iterate_node_module.dfs_node_running = original_dfs


async def _run_scenario(
    scenario_module: types.ModuleType,
    eval_module: types.ModuleType,
    repo_root_default: Path,
    args: argparse.Namespace,
) -> ScenarioResult:
    input_payload = dict(getattr(scenario_module, "INPUT_PAYLOAD", {}))
    expected = dict(getattr(scenario_module, "EXPECTED_BEHAVIOR", {}))
    scenario_name = str(getattr(scenario_module, "SCENARIO_NAME", "unknown"))

    repo_root = Path(str(input_payload.get("repo_root") or str(repo_root_default))).expanduser().resolve()
    idea_id = str(input_payload.get("idea_id") or f"{scenario_name}-playground")
    raw_text = str(input_payload.get("current_user_message") or input_payload.get("text") or "")
    pipeline_key = f"iterate-scenario-{scenario_name}"

    event = DevinChatDagEvent(
        repo_root=str(repo_root),
        idea_id=idea_id,
        raw_text=raw_text,
        pipeline_key=pipeline_key,
    )
    metadata = {
        "raw_text": raw_text,
        "route": {"route_arm": "iterate"},
        "project_id": str(input_payload.get("project_id") or "proj_75f63d30"),
    }
    task_context = TaskContext(event=event, metadata=metadata)

    db_path = repo_root / ".devflow" / "execution.sqlite"
    store = ExecutionStore(db_path=db_path)
    run_id = store.create_run(
        dag_id="devin_chat_dag",
        dag_version="1.0",
        root_correlation_id=str(uuid.uuid4()),
        config={
            "project_id": metadata["project_id"],
            "scenario": scenario_name,
            "playground": "iterate",
        },
    )
    set_runtime_store(store, run_id)

    node = IterateAgentNode(task_context=None)
    try:
        if getattr(args, "real_llm", False):
            import sys
            print('[REAL-LLM] real_llm branch entered, patching...', flush=True, file=sys.stderr)
            custom_timeout = int(getattr(args, "timeout", 300))
            # The devflow-tools.ts extension hangs on multi-word prompts containing keyword
            # patterns like "account settings page" or "save button does nothing".
            # Strip -e devflow-tools.ts from base_cmd in real-llm mode.
            # --no-extensions alone is NOT sufficient when -e flag is also given;
            # the extension still loads and causes the hang.
            _original_runner = pi_runner_module.run_devin2_pi_agent
            _original_one_shot = cli_one_shot.run_one_shot

            def _timeout_wrapped_runner(**kw):
                kw["timeout_seconds"] = custom_timeout
                return _original_runner(**kw)

            def _one_shot_wrapper(**kw):
                # Strip -e devflow-tools.ts completely; --no-extensions alone is not
                # sufficient when the -e flag is also given
                import sys
                base_cmd = kw.get("base_cmd", "")
                print(f'[REAL-LLM] _one_shot_wrapper called: base_cmd={base_cmd!r}', flush=True, file=sys.stderr)
                if "-e" in base_cmd and "devflow-tools" in base_cmd:
                    parts = base_cmd.split()
                    clean = []
                    skip_next = False
                    for p in parts:
                        if skip_next:
                            skip_next = False
                            continue
                        if p == "-e":
                            skip_next = True
                            continue
                        if p.startswith("/Users/devflow/.pi/agent/extensions/devflow"):
                            continue
                        clean.append(p)
                    clean_cmd = " ".join(clean)
                    print(f'[REAL-LLM] _one_shot_wrapper STRIPPED extension: {clean_cmd!r}', flush=True, file=sys.stderr)
                    kw["base_cmd"] = clean_cmd
                return _original_one_shot(**kw)

            # Patch invoke_llm's local reference since it does:
            # from .cli_one_shot import run_one_shot at import time
            import devflow_engine.llm.invoke as invoke_module
            _original_invoke_one_shot = invoke_module.run_one_shot
            def _invoke_one_shot_wrapper(**kw):
                import sys
                base_cmd = kw.get("base_cmd", "")
                print(f'[REAL-LLM] invoke one_shot wrapper: base_cmd={base_cmd!r}', flush=True, file=sys.stderr)
                # Strip -e devflow-tools.ts completely if present; --no-extensions is NOT
                # sufficient when -e flag is also given (extension still loads and hangs
                # on multi-word prompts with certain keyword patterns)
                if "-e" in base_cmd and "devflow-tools" in base_cmd:
                    parts = base_cmd.split()
                    clean = []
                    skip_next = False
                    for p in parts:
                        if skip_next:
                            skip_next = False
                            continue
                        if p == "-e":
                            skip_next = True
                            continue
                        if p.startswith("/Users/devflow/.pi/agent/extensions/devflow"):
                            continue
                        clean.append(p)
                    clean_cmd = " ".join(clean)
                    print(f'[REAL-LLM] invoke one_shot STRIPPED extension: {clean_cmd!r}', flush=True, file=sys.stderr)
                    kw["base_cmd"] = clean_cmd
                return _original_invoke_one_shot(**kw)
            invoke_module.run_one_shot = _invoke_one_shot_wrapper

            pi_runner_module.run_devin2_pi_agent = _timeout_wrapped_runner
            iterate_node_module.run_devin2_pi_agent = _timeout_wrapped_runner
            cli_one_shot.run_one_shot = _one_shot_wrapper
            try:
                result_ctx = await node.process(task_context)
            finally:
                pi_runner_module.run_devin2_pi_agent = _original_runner
                iterate_node_module.run_devin2_pi_agent = _original_runner
                cli_one_shot.run_one_shot = _original_one_shot
                invoke_module.run_one_shot = _original_invoke_one_shot
            response_guidance = dict(result_ctx.metadata.get("response_guidance") or {})
            stubbed = {}
        else:
            with _patched_iterate_runner(scenario_name=scenario_name, input_payload=input_payload) as fake:
                result_ctx = await node.process(task_context)
            response_guidance = dict(result_ctx.metadata.get("response_guidance") or {})
            stubbed = dict(fake.get("value") or _stubbed_response_for(
                scenario_name=scenario_name,
                input_payload=input_payload,
                pipeline_dir=repo_root / ".devflow" / "ideas" / idea_id / "pipelines" / "devin_chat_dag" / pipeline_key,
            ))
    except Exception as exc:
        return ScenarioResult(
            scenario_name=scenario_name,
            passed=False,
            actual_output={"error": str(exc)},
            expected_behavior=expected,
            notes=[f"Node raised exception: {exc}"],
        )
    finally:
        set_runtime_store(None, None)

    actual_output: dict[str, Any] = {
        "route_arm": "iterate",
        "response_message": response_guidance.get("response_message", ""),
        "response_kind": response_guidance.get("response_kind", ""),
        "suggested_next_step": response_guidance.get("suggested_next_step", ""),
        "follow_up_questions": response_guidance.get("follow_up_questions", []),
        "style_notes": response_guidance.get("response_style_notes", []),
    }
    for key, value in stubbed.items():
        if key not in actual_output:
            actual_output[key] = value

    try:
        passed, notes = eval_module.evaluate(actual_output)
    except Exception as exc:
        passed = False
        notes = [f"Eval raised exception: {exc}"]

    return ScenarioResult(
        scenario_name=scenario_name,
        passed=passed,
        actual_output=actual_output,
        expected_behavior=expected,
        notes=notes,
    )


def main() -> None:
    args = _parse_args()
    selected_names = {item.strip() for item in args.scenario_name if item.strip()}
    selected_files = {Path(item).expanduser().resolve() for item in args.scenario_file if str(item).strip()}

    scenarios = _collect_scenarios(selected_names=selected_names, selected_files=selected_files)
    if not scenarios:
        raise SystemExit("No iterate scenarios matched the requested filters.")

    repo_root_default = Path(args.repo_root).expanduser().resolve()

    print(PLAYGROUND_LIMITATION_NOTE)
    print("Running iterate arm eval harness (BUSINESS-LOGIC-ONLY) for", len(scenarios), "scenarios")
    print("-" * 60)

    results: list[ScenarioResult] = []
    for scenario_mod, eval_mod in scenarios:
        scenario_name = getattr(scenario_mod, "SCENARIO_NAME", "unknown")
        print(f"Running scenario: {scenario_name} ...", flush=True)
        result = asyncio.run(_run_scenario(scenario_mod, eval_mod, repo_root_default, args))
        print(f"  → {'PASS' if result.passed else 'FAIL'}", flush=True)
        results.append(result)

    passed_count = sum(1 for item in results if item.passed)
    print("-" * 60)
    print(f"Results: {passed_count}/{len(results)} passed")
    for result in results:
        status = "PASS" if result.passed else "FAIL"
        print(f"  [{status}] {result.scenario_name}")
        for note in result.notes:
            print(f"        note: {note}")

    output = json.dumps(
        {
            "results": [item.model_dump() for item in results],
            "validation_scope": {
                "label": "BUSINESS-LOGIC-ONLY",
                "summary": PLAYGROUND_LIMITATION_NOTE,
                "validates": ["iterate_orchestration", "lane_decisions", "contract_wiring"],
                "does_not_validate": ["real_llm_response_quality", "real_agent_behavior"],
            },
        },
        indent=2,
        sort_keys=True,
    )
    if args.output_file:
        out_path = Path(args.output_file).expanduser().resolve()
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(output + "\n", encoding="utf-8")
    print("\n" + output)

    if passed_count != len(results):
        raise SystemExit(1)


if __name__ == "__main__":
    main()
