from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parent
PROBE = ROOT / "ideation_arm_playground.py"


def _parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(
        description=(
            "Run DevFlow ideation arm scenarios "
            "(BUSINESS-LOGIC-ONLY: validates orchestration, business logic, and contract wiring; "
            "not real LLM response quality or real agent behavior)"
        )
    )
    p.add_argument("--scenarios-file", required=True, help="JSON file containing an array of ideation scenarios")
    p.add_argument("--fake-llm", action="store_true", help="Run scenarios with a deterministic fake LLM for BUSINESS-LOGIC-ONLY validation")
    p.add_argument("--stub-echo", action="store_true", help="Run scenarios in BUSINESS-LOGIC-ONLY stub echo mode")
    return p.parse_args()


def main() -> None:
    args = _parse_args()
    print(
        "BUSINESS-LOGIC-ONLY scenario runner: validates orchestration/business logic/contracts, "
        "not real LLM response quality or real agent behavior."
    )
    scenarios = json.loads(Path(args.scenarios_file).expanduser().resolve().read_text(encoding="utf-8"))
    if not isinstance(scenarios, list):
        raise SystemExit("scenarios file must be a JSON array")

    failures: list[str] = []
    for scenario in scenarios:
        if not isinstance(scenario, dict):
            continue
        name = str(scenario.get("name") or "<unnamed>")
        scenario_path = ROOT / ".tmp_ideation_scenario.json"
        scenario_path.write_text(json.dumps(scenario, indent=2) + "\n", encoding="utf-8")
        cmd = [sys.executable, str(PROBE), "--scenario-file", str(scenario_path)]
        if args.fake_llm and args.stub_echo:
            raise SystemExit("choose only one of --fake-llm or --stub-echo")
        if args.fake_llm:
            cmd.append("--fake-llm")
        elif args.stub_echo:
            cmd.append("--stub-echo")
        print(f"\n=== Scenario: {name} ===")
        res = subprocess.run(cmd, check=False)
        if res.returncode != 0:
            failures.append(name)
        scenario_path.unlink(missing_ok=True)

    if failures:
        print("\nFAILURES:")
        for item in failures:
            print(f"- {item}")
        raise SystemExit(1)
    print("\nALL SCENARIOS PASSED")


if __name__ == "__main__":
    main()
