from __future__ import annotations

import argparse
import json
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from devflow_engine.source_doc_mutation_eval import run_sparse_input_eval, run_targeted_mutation_eval

PLAYGROUND_LIMITATION_NOTE = (
    "BUSINESS-LOGIC-ONLY playground eval: validates orchestration, business logic, and contract wiring; "
    "it does NOT validate real LLM response quality or real agent behavior."
)

DURABLE_PLAYGROUND_EVALS_ROOT = ROOT / "playground" / "eval_runs"
DEFAULT_TARGETED_BASELINE_ROOT = ROOT / "evals"


def _resolve_evals_root(*, repo_root: Path, repo_root_supplied: bool, evals_root_arg: str) -> Path:
    if evals_root_arg:
        return Path(evals_root_arg).expanduser().resolve()
    if repo_root_supplied:
        return repo_root / "evals"
    return DURABLE_PLAYGROUND_EVALS_ROOT


def _resolve_default_targeted_baseline_root(*, repo_root_supplied: bool) -> Path | None:
    if repo_root_supplied:
        return None
    return DEFAULT_TARGETED_BASELINE_ROOT if DEFAULT_TARGETED_BASELINE_ROOT.exists() else None


def _parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description=f"Run source-doc mutation evals in stub or real LLM mode ({PLAYGROUND_LIMITATION_NOTE})")
    p.add_argument("--repo-root", type=str, default="", help="Existing repo root to use")
    p.add_argument("--eval-type", choices=["sparse_input", "targeted_mutation"], default="sparse_input")
    p.add_argument("--project-id", type=str, default="proj_source_doc_eval")
    p.add_argument("--idea-id", type=str, default="playground_source_doc_eval")
    p.add_argument("--pipeline-key", type=str, default="source_doc_eval")
    p.add_argument("--text", type=str, default="")
    p.add_argument("--base-text", type=str, default="")
    p.add_argument("--mutation-text", type=str, default="")
    p.add_argument("--agent-runtime-mode", choices=["real", "stub"], default="real")
    p.add_argument("--output-file", type=str, default="")
    p.add_argument("--evals-root", type=str, default="", help="Directory under which durable eval snapshots are written. Defaults to <repo-root>/evals, or playground/eval_runs when --repo-root is omitted.")
    p.add_argument("--baseline-eval-root", type=str, default="", help="For targeted_mutation, explicit sparse_input eval root to use as the baseline snapshot. Defaults to the latest sparse_input run under --evals-root.")
    return p.parse_args()


def main() -> None:
    args = _parse_args()
    temp_repo_ctx = None
    if args.repo_root:
        repo_root = Path(args.repo_root).expanduser().resolve()
        repo_root.mkdir(parents=True, exist_ok=True)
    else:
        temp_repo_ctx = tempfile.TemporaryDirectory(prefix="devflow-source-doc-eval-")
        repo_root = Path(temp_repo_ctx.name) / "repo"
        repo_root.mkdir(parents=True, exist_ok=True)

    evals_root = _resolve_evals_root(repo_root=repo_root, repo_root_supplied=bool(args.repo_root), evals_root_arg=args.evals_root)
    evals_root.mkdir(parents=True, exist_ok=True)

    if args.eval_type == "targeted_mutation":
        base_text = args.base_text or "Build a task app that lets me create tasks and assign them to staff."
        mutation_text = args.mutation_text or "Add due dates, priority levels, and reassignment approvals."
        baseline_eval_root = Path(args.baseline_eval_root).expanduser().resolve() if args.baseline_eval_root else _resolve_default_targeted_baseline_root(repo_root_supplied=bool(args.repo_root))
        result = run_targeted_mutation_eval(
            repo_root=repo_root,
            base_text=base_text,
            mutation_text=mutation_text,
            agent_runtime_mode=args.agent_runtime_mode,
            project_id=args.project_id,
            idea_id=args.idea_id,
            pipeline_key_prefix=args.pipeline_key,
            evals_root=evals_root,
            baseline_eval_root=baseline_eval_root,
        )
    else:
        text = args.text or "Build a task app that lets me create tasks and assign them to staff."
        result = run_sparse_input_eval(
            repo_root=repo_root,
            text=text,
            agent_runtime_mode=args.agent_runtime_mode,
            project_id=args.project_id,
            idea_id=args.idea_id,
            pipeline_key=args.pipeline_key,
            evals_root=evals_root,
        )

    payload = dict(result.payload)
    payload["validation_scope"] = {
        "label": "BUSINESS-LOGIC-ONLY",
        "summary": PLAYGROUND_LIMITATION_NOTE,
        "validates": ["orchestration", "business_logic", "contract_wiring"],
        "does_not_validate": ["real_llm_response_quality", "real_agent_behavior"],
    }
    output = json.dumps(payload, indent=2, sort_keys=True)
    if args.output_file:
        out = Path(args.output_file).expanduser().resolve()
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(output + "\n", encoding="utf-8")
    print(output)

    if temp_repo_ctx is not None:
        temp_repo_ctx.cleanup()


if __name__ == "__main__":
    main()
