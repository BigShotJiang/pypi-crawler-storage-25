from __future__ import annotations

import argparse
import json
import os
import sqlite3
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from devflow_engine.idea import devin_chat_dag
from devflow_engine.stores.execution_store import ExecutionStore


PLAYGROUND_LIMITATION_NOTE = (
    "BUSINESS-LOGIC-ONLY playground: validates orchestration, business logic, and contract wiring; "
    "it does NOT validate real LLM response quality or real agent behavior."
)


def _parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description=f"Run DevFlow ideation arm playground ({PLAYGROUND_LIMITATION_NOTE})")
    p.add_argument("--scenario-file", type=str, default="", help="Path to JSON scenario file")
    p.add_argument("--idea-id", type=str, default="playground_idea")
    p.add_argument("--text", type=str, default="")
    p.add_argument("--text-file", type=str, default="")
    p.add_argument("--plane", action="append", default=[])
    p.add_argument("--max-stories", type=int, default=3)
    p.add_argument("--repo-root", type=str, default="", help="Existing repo root to use")
    p.add_argument("--fake-llm", action="store_true", help="Install deterministic fake LLM config for BUSINESS-LOGIC-ONLY playground validation")
    p.add_argument("--stub-echo", action="store_true", help="Install BUSINESS-LOGIC-ONLY stub mode that echoes the prompt payload it received")
    p.add_argument("--history-file", type=str, default="", help="JSON file with Devin message history rows")
    p.add_argument("--output-file", type=str, default="", help="Write full report JSON to this file")
    return p.parse_args()


FAKE_LLM_SCRIPT = """import json\nimport sys\nprompt = json.loads(sys.stdin.read() or '{}')\ntask = prompt.get('task')\ncontext = prompt.get('context') or {}\nif task == 'route_classification':\n    raw_text = str(prompt.get('raw_text') or '').lower()\n    grounded = str(prompt.get('grounded_raw_text') or '').lower()\n    history_summary = str(prompt.get('history_summary') or '').lower()\n    ideation_tokens = ['build', 'feature', 'app', 'workflow', 'intake', 'triage', 'automate', 'manual', 'operators', 'support']\n    insight_tokens = ['how many', 'queue', 'status', 'insight']\n    generic_tokens = ['python', 'pytest', 'virtualenv', '3.11', '3.12', 'eslint']\n    follow_up_tokens = ['yes', 'yep', 'keep it', 'internal only', 'for now', 'route support', 'route tickets', 'proceed', 'go for it']\n    if any(token in raw_text for token in insight_tokens):\n        arm = 'insight'\n    elif any(token in raw_text for token in ideation_tokens):\n        arm = 'ideation'\n    elif any(token in raw_text for token in generic_tokens):\n        arm = 'neither'\n    elif any(token in raw_text for token in follow_up_tokens) and any(token in ' '.join([grounded, history_summary]) for token in ideation_tokens):\n        arm = 'ideation'\n    elif any(token in grounded for token in ideation_tokens) and not any(token in grounded for token in insight_tokens):\n        arm = 'ideation'\n    else:\n        arm = 'neither'\n    sys.stdout.write(json.dumps({'route_arm': arm, 'confidence': 0.95, 'reasoning': 'deterministic fake playground classification'}))\n    raise SystemExit(0)\nif task == 'ideation_contract_completion':\n    raw = str(prompt.get('grounded_raw_text') or prompt.get('raw_text') or '').strip()\n    existing = prompt.get('existing_idea') or {}\n    gaps = list(prompt.get('gaps_to_fill') or [])\n    completed = {\n        'summary': str(existing.get('summary') or raw.splitlines()[0] or 'Playground ideation request').strip(),\n        'problem_statement': 'Manual intake and routing work should be automated through software support.',\n        'target_users': ['Operators'],\n        'desired_outcomes': ['Reduce manual triage effort', 'Route requests consistently'],\n        'initial_scope': {'in_scope': ['Capture incoming requests', 'Classify and route requests'], 'out_of_scope': ['External launch', 'Advanced ML optimization']},\n        'constraints': ['Keep the first version internal-only'],\n        'acceptance_criteria': ['Operators can submit, review, and route requests from one place'],\n    }\n    payload = {k: v for k, v in completed.items() if k in gaps}\n    assumptions = [{'field': k, 'value': v, 'reasoning': 'deterministic fake playground contract completion'} for k, v in payload.items()]\n    sys.stdout.write(json.dumps({'completed_fields': payload, 'assumptions': assumptions}))\n    raise SystemExit(0)\nif task == 'idea_activation_judgment':\n    raw_text = str(prompt.get('raw_text') or '').lower()\n    grounded = str(prompt.get('grounded_raw_text') or '').lower()\n    recent = ' '.join(str((item or {}).get('message') or '').lower() for item in (prompt.get('recent_turn_context') or []))\n    approval_tokens = ['go for it', 'proceed', 'approved', 'go ahead', 'build it', \"let's build\", 'lets build']\n    ideation_context = ' '.join([raw_text, grounded, recent])\n    activate = any(token in raw_text for token in approval_tokens) and any(token in ideation_context for token in ['build', 'app', 'workflow', 'intake', 'triage', 'support', 'operators'])\n    sys.stdout.write(json.dumps({'decision': 'activate' if activate else 'hold', 'activation_detected': activate, 'confidence': 0.96 if activate else 0.9, 'reasoning': 'deterministic fake playground activation judgment', 'requires_strong_review': False}))\n    raise SystemExit(0)\nif task == 'idea_devin_post_context_response':\n    expected = context.get('expected_status') or 'ready_for_downstream'\n    suff = context.get('sufficiency') or {}\n    mode = ((context.get('response_runtime') or {}).get('mode_label') or 'fake').strip()\n    questions = list(suff.get('follow_up_questions') or [])\n    top = suff.get('top_follow_up_question')\n    if expected == 'redirect':\n        message = 'FAKE BUSINESS-LOGIC-ONLY playground response: I am answering this outside the ideation handoff path, so nothing is being sent into downstream story generation. This validates orchestration/business logic/contracts only, not real LLM response quality or real agent behavior.'\n        next_step = 'Return to the product idea when you want to keep shaping the software request.'\n    elif expected == 'needs_clarification':\n        message = f'FAKE BUSINESS-LOGIC-ONLY playground response: I updated the working idea, but I still need one key detail first: {top or "answer the follow-up questions"}. This validates orchestration/business logic/contracts only, not real LLM response quality or real agent behavior.'\n        next_step = 'Reply with the missing problem, users, scope, constraints, and acceptance criteria.'\n    elif expected == 'ideation_contract_response':\n        message = 'FAKE BUSINESS-LOGIC-ONLY playground response: I updated the working idea and source-doc assumptions, but I am not treating it as downstream-ready until you explicitly approve activation. This validates orchestration/business logic/contracts only, not real LLM response quality or real agent behavior.'\n        next_step = 'Refine the idea or say proceed/go for it when you want to activate downstream generation.'\n    else:\n        message = 'FAKE BUSINESS-LOGIC-ONLY playground response: explicit approval received, so the idea can move into downstream story generation. This validates orchestration/business logic/contracts only, not real LLM response quality or real agent behavior.'\n        next_step = 'Proceed to story generation using the approved idea.'\n    sys.stdout.write(json.dumps({'response_message': message, 'response_kind': expected, 'suggested_next_step': next_step, 'follow_up_questions': questions, 'style_notes': [f'mode:{mode}', 'deterministic fake playground response']}))\n    raise SystemExit(0)\nif task == 'generate_traditional_story_coverage_requirements':\n    users = [str(item).strip() for item in ((prompt.get('sufficient_idea') or {}).get('target_users') or []) if str(item).strip()]\n    requirements = []\n    for idx, user in enumerate(users, start=1):\n        requirements.append({'requirement_id': f'actor_{idx:03d}', 'category': 'actor', 'actor_requirement_id': None, 'subject': user, 'requirement': f'Cover the {user} actor.', 'rationale': 'Actor named in sufficient idea.'})\n    sys.stdout.write(json.dumps({'requirements': requirements}))\n    raise SystemExit(0)\nif task == 'evaluate_traditional_story_coverage_deficiencies':\n    sys.stdout.write(json.dumps({'passed': True, 'findings': [], 'covered_requirement_ids': [item.get('requirement_id') for item in ((prompt.get('coverage_requirements') or {}).get('requirements') or [])], 'uncovered_requirement_ids': [], 'weak_requirement_ids': [], 'deficiencies': []}))\n    raise SystemExit(0)\nif task == 'evaluate_traditional_story_decomposition':\n    sys.stdout.write(json.dumps({'passed': True, 'findings': [], 'issues': []}))\n    raise SystemExit(0)\nif task == 'evaluate_traditional_user_story_sufficiency':\n    sys.stdout.write(json.dumps({'passed': True, 'findings': [], 'coverage': {'actors': {'expected': [], 'covered': [], 'missing': []}, 'outcomes': {'expected': [], 'covered': [], 'missing': []}, 'gates': {'expected': [], 'covered': [], 'missing': []}, 'flows': {'expected': [], 'covered': [], 'missing': []}, 'story_count': 0}}))\n    raise SystemExit(0)\nif task == 'adjudicate_story_planes':\n    candidates = prompt.get('candidate_planes') or []\n    story = prompt.get('story') or {}\n    text = (' '.join([str(story.get('title') or ''), str(story.get('statement') or '')])).lower()\n    required = []\n    if 'api' in candidates:\n        required.append('api')\n    if any(token in text for token in ['page', 'screen', 'ui', 'redirect', 'display']) and 'ui' in candidates:\n        required.append('ui')\n    if any(token in text for token in ['restricted', 'access', 'verified', 'operator']) and 'auth' in candidates:\n        required.append('auth')\n    required = sorted(set(required))\n    sys.stdout.write(json.dumps({'required_planes': required, 'included_planes': [{'plane': p, 'rationale': 'Required by this story wording.'} for p in required], 'excluded_planes': [{'plane': p, 'rationale': 'Not required by this story wording.'} for p in candidates if p not in required]}))\n    raise SystemExit(0)\npayload = {'stories': [{'title': 'Playground story one', 'actor': 'Operator', 'goal': 'see ideation output', 'benefit': 'validate the harness', 'user_value': 'A stable output exists.', 'acceptance_criteria': ['A stable story set is produced.'], 'coverage_tags': ['actor:operator']}] }\nsys.stdout.write(json.dumps(payload))\n"""

STUB_ECHO_LLM_SCRIPT = """import json\nimport sys\nprompt = json.loads(sys.stdin.read() or '{}')\ncontext = prompt.get('context') or {}\nif prompt.get('task') == 'route_classification':\n    raw_text = str(prompt.get('raw_text') or '').lower()\n    grounded = str(prompt.get('grounded_raw_text') or '').lower()\n    history_summary = str(prompt.get('history_summary') or '').lower()\n    ideation_tokens = ['build', 'feature', 'app', 'workflow', 'intake', 'triage', 'automate', 'manual', 'operators', 'support']\n    insight_tokens = ['how many', 'queue', 'status', 'insight']\n    generic_tokens = ['python', 'pytest', 'virtualenv', '3.11', '3.12', 'eslint']\n    follow_up_tokens = ['yes', 'yep', 'keep it', 'internal only', 'for now', 'route support', 'route tickets', 'proceed', 'go for it']\n    if any(token in raw_text for token in insight_tokens):\n        arm = 'insight'\n    elif any(token in raw_text for token in ideation_tokens):\n        arm = 'ideation'\n    elif any(token in raw_text for token in generic_tokens):\n        arm = 'neither'\n    elif any(token in raw_text for token in follow_up_tokens) and any(token in ' '.join([grounded, history_summary]) for token in ideation_tokens):\n        arm = 'ideation'\n    elif any(token in grounded for token in ideation_tokens) and not any(token in grounded for token in insight_tokens):\n        arm = 'ideation'\n    else:\n        arm = 'neither'\n    sys.stdout.write(json.dumps({'route_arm': arm, 'confidence': 0.95, 'reasoning': 'stub_echo playground classification'}))\n    raise SystemExit(0)\nif prompt.get('task') == 'ideation_contract_completion':\n    completed = {\n        'summary': 'Stubbed playground ideation request',\n        'problem_statement': 'A stubbed playground run still needs a valid ideation contract.',\n        'target_users': ['Operators'],\n        'desired_outcomes': ['Verify end-to-end ideation harness behavior'],\n        'initial_scope': {'in_scope': ['Echo prompt payloads', 'Preserve intake-to-ideation handoff'], 'out_of_scope': ['Real production planning output']},\n        'constraints': ['Stub mode is for harness verification only'],\n        'acceptance_criteria': ['The ideation arm completes with explicit stubbed artifacts'],\n    }\n    gaps = list(prompt.get('gaps_to_fill') or [])\n    payload = {k: v for k, v in completed.items() if k in gaps}\n    assumptions = [{'field': k, 'value': v, 'reasoning': 'stub_echo playground contract completion'} for k, v in payload.items()]\n    sys.stdout.write(json.dumps({'completed_fields': payload, 'assumptions': assumptions}))\n    raise SystemExit(0)\nif prompt.get('task') == 'idea_activation_judgment':\n    raw_text = str(prompt.get('raw_text') or '').lower()\n    grounded = str(prompt.get('grounded_raw_text') or '').lower()\n    recent = ' '.join(str((item or {}).get('message') or '').lower() for item in (prompt.get('recent_turn_context') or []))\n    activate = any(token in raw_text for token in ['go for it', 'proceed', 'approved', 'go ahead', 'build it']) and any(token in ' '.join([raw_text, grounded, recent]) for token in ['build', 'app', 'workflow', 'intake', 'triage', 'support'])\n    sys.stdout.write(json.dumps({'decision': 'activate' if activate else 'hold', 'activation_detected': activate, 'confidence': 0.95 if activate else 0.9, 'reasoning': 'stub_echo playground activation judgment', 'requires_strong_review': False}))\n    raise SystemExit(0)\nexpected = context.get('expected_status') or 'ready_for_downstream'\nnext_step = 'Inspect the echoed payload for harness verification only.'\nif expected == 'ideation_contract_response':\n    next_step = 'This is still pre-activation in stub mode; inspect the payload instead of treating it as downstream-ready.'\nelif expected == 'ready_for_downstream':\n    next_step = 'Stub mode observed explicit activation; inspect the payload rather than treating it as production-complete.'\npayload = {'response_message': f'STUB BUSINESS-LOGIC-ONLY echo response for {expected}. Inspect echo payload instead of treating this as a real reply. This validates orchestration/business logic/contracts only, not real LLM response quality or real agent behavior.', 'response_kind': expected, 'suggested_next_step': next_step, 'follow_up_questions': list(((context.get('sufficiency') or {}).get('follow_up_questions') or [])), 'style_notes': ['stub_echo_mode'], 'echo': prompt, 'task': prompt.get('task')}\nsys.stdout.write(json.dumps(payload))\n"""


def _load_json(path: str) -> Any:
    return json.loads(Path(path).expanduser().resolve().read_text(encoding="utf-8"))


def _build_scenario(args: argparse.Namespace) -> dict[str, Any]:
    if args.scenario_file:
        data = _load_json(args.scenario_file)
        if not isinstance(data, dict):
            raise SystemExit("scenario file must be a JSON object")
        return data
    text = args.text
    if args.text_file:
        text = Path(args.text_file).expanduser().resolve().read_text(encoding="utf-8")
    if not text.strip():
        raise SystemExit("provide --text, --text-file, or --scenario-file")
    history_rows = _load_json(args.history_file) if args.history_file else []
    return {
        "name": "adhoc",
        "idea_id": args.idea_id,
        "text": text,
        "planes": args.plane or ["api"],
        "max_stories": args.max_stories,
        "history_rows": history_rows,
    }


def _prepare_repo(repo_root: Path) -> None:
    repo_root.mkdir(parents=True, exist_ok=True)
    (repo_root / ".git").mkdir(exist_ok=True)


def _install_cli_llm(repo_root: Path, *, temp_home: Path, script_name: str, script_body: str, provider: str) -> None:
    script_path = repo_root / script_name
    script_path.write_text(script_body, encoding="utf-8")
    config_dir = temp_home / ".devflow"
    config_dir.mkdir(parents=True, exist_ok=True)
    config = "\n".join([
        'llm_mode = "cli"',
        f'llm_cli_base = "{sys.executable} {script_path}"',
        'llm_cli_delivery = "stdin"',
        f'llm_provider = "{provider}"',
        f'llm_local_ultra_light_provider = "{provider}"',
        f'llm_local_ultra_light_base = "{sys.executable} {script_path} --model phi4"',
        'llm_local_ultra_light_delivery = "stdin"',
    ]) + "\n"
    (config_dir / "config.toml").write_text(config, encoding="utf-8")
    keys_dir = config_dir / "keys"
    keys_dir.mkdir(parents=True, exist_ok=True)
    (keys_dir / "anthropic.json").write_text(json.dumps({"provider": "anthropic", "api_key": "test-key"}) + "\n", encoding="utf-8")
    os.environ["DEVFLOW_HOME"] = str(temp_home)


def _sqlite_summary(db_path: Path) -> dict[str, Any]:
    if not db_path.exists():
        return {"db_exists": False}
    conn = sqlite3.connect(str(db_path))
    conn.row_factory = sqlite3.Row
    try:
        runs = [dict(r) for r in conn.execute("SELECT dag_id, status FROM runs ORDER BY created_at ASC").fetchall()]
        artifacts = [dict(r) for r in conn.execute("SELECT kind, uri FROM artifacts ORDER BY created_at ASC").fetchall()]
    finally:
        conn.close()
    return {"db_exists": True, "runs": runs, "artifacts": artifacts}


def main() -> None:
    args = _parse_args()
    scenario = _build_scenario(args)

    temp_repo_ctx = None
    repo_root: Path
    if args.repo_root:
        repo_root = Path(args.repo_root).expanduser().resolve()
        _prepare_repo(repo_root)
    else:
        temp_repo_ctx = tempfile.TemporaryDirectory(prefix="devflow-ideation-playground-")
        repo_root = Path(temp_repo_ctx.name) / "repo"
        _prepare_repo(repo_root)

    temp_home_ctx = tempfile.TemporaryDirectory(prefix="devflow-ideation-home-")
    llm_mode = "real"
    if args.fake_llm and args.stub_echo:
        raise SystemExit("choose only one of --fake-llm or --stub-echo")
    if args.fake_llm:
        _install_cli_llm(repo_root, temp_home=Path(temp_home_ctx.name), script_name="fake_playground_llm.py", script_body=FAKE_LLM_SCRIPT, provider="playground_fake")
        llm_mode = "fake"
    elif args.stub_echo:
        _install_cli_llm(repo_root, temp_home=Path(temp_home_ctx.name), script_name="stub_echo_playground_llm.py", script_body=STUB_ECHO_LLM_SCRIPT, provider="playground_stub_echo")
        llm_mode = "stub_echo"
    os.environ["DEVFLOW_IDEATION_RESPONSE_MODE_LABEL"] = llm_mode

    original_messages_create = devin_chat_dag.idea_agentic._anthropic_messages_create
    if llm_mode in {"fake", "stub_echo"}:
        def _playground_fake_messages_create(*, settings, system_prompt, messages, tools, timeout_seconds):
            del settings, system_prompt, tools, timeout_seconds
            prompt = json.loads(str(messages[0]["content"]))
            context = dict(prompt.get("context") or {})
            expected = str(context.get("expected_status") or "ready_for_downstream")
            suff = dict(context.get("sufficiency") or {})
            top = suff.get("top_follow_up_question")
            if expected == "redirect":
                message = f"{llm_mode.upper()} BUSINESS-LOGIC-ONLY playground response: I am answering this outside the ideation handoff path, so nothing is being sent into downstream story generation. This validates orchestration/business logic/contracts only, not real LLM response quality or real agent behavior."
                next_step = "Return to the product idea when you want to keep shaping the software request."
            elif expected == "needs_clarification":
                message = f"{llm_mode.upper()} BUSINESS-LOGIC-ONLY playground response: I updated the working idea, but I still need one key detail first: {top or 'answer the follow-up questions'}. This validates orchestration/business logic/contracts only, not real LLM response quality or real agent behavior."
                next_step = "Reply with the missing problem, users, scope, constraints, and acceptance criteria."
            elif expected == "ideation_contract_response":
                message = f"{llm_mode.upper()} BUSINESS-LOGIC-ONLY playground response: I updated the working idea and source-doc assumptions, but I am not treating it as downstream-ready until you explicitly approve activation. This validates orchestration/business logic/contracts only, not real LLM response quality or real agent behavior."
                next_step = "Refine the idea or say proceed/go for it when you want to activate downstream generation."
            else:
                message = f"{llm_mode.upper()} BUSINESS-LOGIC-ONLY playground response: explicit approval received, so the idea can move into downstream story generation. This validates orchestration/business logic/contracts only, not real LLM response quality or real agent behavior."
                next_step = "Proceed to story generation using the approved idea."
            return {
                "content": [
                    {
                        "type": "text",
                        "text": json.dumps(
                            {
                                "response_message": message,
                                "response_kind": expected,
                                "suggested_next_step": next_step,
                                "follow_up_questions": list(suff.get("follow_up_questions") or []),
                                "style_notes": [f"mode:{llm_mode}", "playground_fake_api_agent"],
                            }
                        ),
                    }
                ]
            }

        devin_chat_dag.idea_agentic._anthropic_messages_create = _playground_fake_messages_create

    history_rows = scenario.get("history_rows") or []
    if not isinstance(history_rows, list):
        raise SystemExit("history_rows must be a JSON array")

    original_fetch = devin_chat_dag._fetch_project_devin_history
    devin_chat_dag._fetch_project_devin_history = lambda **kwargs: history_rows
    try:
        store = ExecutionStore(repo_root / ".devflow" / "execution.sqlite")
        result = devin_chat_dag.run_devin_chat_dag(
            repo_root=repo_root,
            store=store,
            idea_id=str(scenario.get("idea_id") or "playground_idea"),
            text=str(scenario.get("text") or ""),
            source_path=None,
            max_stories=int(scenario.get("max_stories") or 3),
            planes=[str(p) for p in (scenario.get("planes") or ["api"])],
        )
    finally:
        devin_chat_dag._fetch_project_devin_history = original_fetch
        devin_chat_dag.idea_agentic._anthropic_messages_create = original_messages_create

    report = {
        "scenario": {
            "name": scenario.get("name") or "adhoc",
            "idea_id": scenario.get("idea_id") or "playground_idea",
            "planes": scenario.get("planes") or ["api"],
            "history_message_count": len(history_rows),
        },
        "result": {
            "exit_code": result.exit_code,
            "run_id": result.run_id,
            "pipeline_dir": str(result.pipeline_dir),
            "message": result.message,
            "outcome": result.outcome,
        },
        "execution_store": _sqlite_summary(repo_root / ".devflow" / "execution.sqlite"),
        "repo_root": str(repo_root),
        "llm_mode": llm_mode,
        "validation_scope": {
            "label": "BUSINESS-LOGIC-ONLY",
            "summary": PLAYGROUND_LIMITATION_NOTE,
            "validates": ["orchestration", "business_logic", "contract_wiring"],
            "does_not_validate": ["real_llm_response_quality", "real_agent_behavior"],
        },
    }

    output = json.dumps(report, indent=2, sort_keys=True)
    if args.output_file:
        out_path = Path(args.output_file).expanduser().resolve()
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(output + "\n", encoding="utf-8")
    print(output)

    if temp_repo_ctx is not None:
        temp_repo_ctx.cleanup()
    temp_home_ctx.cleanup()


if __name__ == "__main__":
    main()
