"""Smoke tests for the KBStore class."""

import os
import tempfile
from pathlib import Path

import pytest

from persistent_kb_mcp.db import KBStore


@pytest.fixture()
def store(tmp_path):
    db = tmp_path / "test.sqlite"
    s = KBStore(db)
    s.ensure_schema()
    return s


def test_add_and_search(store):
    r = store.add(title="Hello", content="A note about agents.", kind="lesson", tags="t1,t2")
    assert r["id"] >= 1

    rows = store.search("agents")
    assert len(rows) == 1
    assert rows[0]["title"] == "Hello"


def test_show(store):
    r = store.add(title="Item", content="Body", kind="reference", tags="alpha,beta")
    full = store.show(r["id"])
    assert full["title"] == "Item"
    assert set(full["tags"]) == {"alpha", "beta"}


def test_list(store):
    store.add(title="A", content="x", kind="lesson", tags="x")
    store.add(title="B", content="y", kind="reference", tags="y")
    items = store.list(limit=10)
    assert len(items) == 2

    only_lesson = store.list(kind="lesson", limit=10)
    assert len(only_lesson) == 1
    assert only_lesson[0]["title"] == "A"


def test_update_tags(store):
    r = store.add(title="T", content="x")
    store.update_tags(r["id"], add="alpha,beta")
    full = store.show(r["id"])
    assert set(full["tags"]) == {"alpha", "beta"}

    store.update_tags(r["id"], remove="alpha", add="gamma")
    full = store.show(r["id"])
    assert set(full["tags"]) == {"beta", "gamma"}


def test_invalid_kind_rejected(store):
    with pytest.raises(ValueError):
        store.add(title="T", content="x", kind="bogus")


def test_show_missing(store):
    with pytest.raises(LookupError):
        store.show(9999)
