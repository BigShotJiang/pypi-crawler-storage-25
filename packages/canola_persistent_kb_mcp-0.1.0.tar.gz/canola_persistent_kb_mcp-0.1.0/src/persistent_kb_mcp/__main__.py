"""Entrypoint: `python -m persistent_kb_mcp` runs the stdio MCP server."""

import asyncio

from mcp.server.stdio import stdio_server

from .db import KBStore
from .server import build_server


async def _main() -> None:
    store = KBStore()
    store.ensure_schema()
    app = build_server(store)
    async with stdio_server() as (read, write):
        await app.run(read, write, app.create_initialization_options())


def main() -> None:
    asyncio.run(_main())


if __name__ == "__main__":
    main()
