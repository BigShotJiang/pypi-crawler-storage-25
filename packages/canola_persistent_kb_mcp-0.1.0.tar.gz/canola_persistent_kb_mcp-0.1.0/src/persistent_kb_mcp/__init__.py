"""persistent-kb-mcp: cross-session knowledge base over Model Context Protocol."""
__version__ = "0.1.0"
