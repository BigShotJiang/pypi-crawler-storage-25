"""MCP server exposing the persistent-kb knowledge base."""

from __future__ import annotations

import json
from typing import Any

from mcp.server import Server
from mcp.types import TextContent, Tool

from .db import VALID_KINDS, KBStore

KIND_ENUM = list(VALID_KINDS)


def build_server(store: KBStore) -> Server:
    """Construct an MCP server bound to a KBStore. Separated for testability."""
    app = Server("persistent-kb")

    @app.list_tools()
    async def list_tools() -> list[Tool]:
        return [
            Tool(
                name="kb_add",
                description=(
                    "Save a fact, lesson, decision, or reference to the local persistent knowledge base. "
                    "Content survives across agent sessions, context compactions, and machine reboots. "
                    "Use when the user says 'remember this', or when the agent encounters a non-obvious finding."
                ),
                inputSchema={
                    "type": "object",
                    "required": ["title", "content"],
                    "properties": {
                        "title": {"type": "string", "description": "Short, descriptive title."},
                        "kind": {
                            "type": "string",
                            "enum": KIND_ENUM,
                            "default": "note",
                            "description": "Type of entry. Use 'lesson' for insights, 'reference' for external info, 'decision' for choices, 'incident' for failures.",
                        },
                        "tags": {
                            "type": "string",
                            "description": "Comma-separated tags, e.g. 'discovered,topic1,topic2'.",
                            "default": "",
                        },
                        "content": {"type": "string", "description": "Full body of the entry."},
                    },
                },
            ),
            Tool(
                name="kb_search",
                description=(
                    "Full-text search over the persistent knowledge base via SQLite FTS5. "
                    "Use when looking for previously saved facts on a topic before re-doing the work."
                ),
                inputSchema={
                    "type": "object",
                    "required": ["query"],
                    "properties": {
                        "query": {"type": "string", "description": "FTS5 query string."},
                        "top": {"type": "integer", "default": 10, "minimum": 1, "maximum": 50},
                        "kind": {"type": "string", "enum": KIND_ENUM},
                        "tag": {"type": "string"},
                    },
                },
            ),
            Tool(
                name="kb_show",
                description="Retrieve a single entry's full content, tags, and metadata by id.",
                inputSchema={
                    "type": "object",
                    "required": ["id"],
                    "properties": {"id": {"type": "integer"}},
                },
            ),
            Tool(
                name="kb_list",
                description="List recent entries with optional filters by kind, tag, or date.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "kind": {"type": "string", "enum": KIND_ENUM},
                        "tag": {"type": "string"},
                        "since": {
                            "type": "string",
                            "description": "ISO date 'YYYY-MM-DD'; only entries on/after are returned.",
                        },
                        "limit": {"type": "integer", "default": 20, "minimum": 1, "maximum": 200},
                    },
                },
            ),
            Tool(
                name="kb_tag",
                description="Add or remove tags on an existing entry.",
                inputSchema={
                    "type": "object",
                    "required": ["id"],
                    "properties": {
                        "id": {"type": "integer"},
                        "add": {"type": "string", "description": "Comma-separated tags to add."},
                        "remove": {"type": "string", "description": "Comma-separated tags to remove."},
                    },
                },
            ),
        ]

    @app.call_tool()
    async def call_tool(name: str, arguments: dict[str, Any]) -> list[TextContent]:
        try:
            if name == "kb_add":
                result = store.add(
                    title=arguments["title"],
                    content=arguments["content"],
                    kind=arguments.get("kind", "note"),
                    tags=arguments.get("tags", ""),
                )
                return [TextContent(type="text", text=json.dumps(result, ensure_ascii=False))]

            if name == "kb_search":
                rows = store.search(
                    query=arguments["query"],
                    top=int(arguments.get("top", 10)),
                    kind=arguments.get("kind"),
                    tag=arguments.get("tag"),
                )
                if not rows:
                    return [TextContent(type="text", text="(no matches)")]
                return [TextContent(type="text", text=json.dumps(rows, ensure_ascii=False, indent=2))]

            if name == "kb_show":
                row = store.show(int(arguments["id"]))
                return [TextContent(type="text", text=json.dumps(row, ensure_ascii=False, indent=2))]

            if name == "kb_list":
                rows = store.list(
                    kind=arguments.get("kind"),
                    tag=arguments.get("tag"),
                    since=arguments.get("since"),
                    limit=int(arguments.get("limit", 20)),
                )
                return [TextContent(type="text", text=json.dumps(rows, ensure_ascii=False, indent=2))]

            if name == "kb_tag":
                result = store.update_tags(
                    entry_id=int(arguments["id"]),
                    add=arguments.get("add", ""),
                    remove=arguments.get("remove", ""),
                )
                return [TextContent(type="text", text=json.dumps(result, ensure_ascii=False))]

            raise ValueError(f"Unknown tool: {name}")

        except (LookupError, ValueError) as exc:
            return [TextContent(type="text", text=f"Error: {exc}")]

    return app
