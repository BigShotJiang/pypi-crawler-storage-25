"""SQLite-backed knowledge base store. Reused from the persistent-kb skill."""

from __future__ import annotations

import os
import sqlite3
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator

VALID_KINDS = (
    "lesson",
    "reference",
    "decision",
    "incident",
    "note",
    "task-log",
    "summary",
)

SCHEMA_VERSION = 1

SCHEMA_SQL = """
PRAGMA user_version = 1;

CREATE TABLE entries (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  kind TEXT NOT NULL CHECK (kind IN ('lesson','reference','decision','incident','note','task-log','summary')),
  content TEXT NOT NULL,
  superseded_by INTEGER REFERENCES entries(id) ON DELETE SET NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE tags (
  entry_id INTEGER NOT NULL REFERENCES entries(id) ON DELETE CASCADE,
  tag TEXT NOT NULL,
  PRIMARY KEY (entry_id, tag)
);
CREATE INDEX idx_tags_tag ON tags(tag);
CREATE INDEX idx_entries_kind ON entries(kind);

CREATE VIRTUAL TABLE entries_fts USING fts5(
  title, content, content='entries', content_rowid='id', tokenize='porter unicode61'
);
CREATE TRIGGER entries_ai AFTER INSERT ON entries BEGIN
  INSERT INTO entries_fts(rowid, title, content) VALUES (new.id, new.title, new.content);
END;
CREATE TRIGGER entries_au AFTER UPDATE ON entries BEGIN
  UPDATE entries_fts SET title = new.title, content = new.content WHERE rowid = new.id;
END;
CREATE TRIGGER entries_ad AFTER DELETE ON entries BEGIN
  DELETE FROM entries_fts WHERE rowid = old.id;
END;

CREATE TABLE relations (
  src_id INTEGER NOT NULL REFERENCES entries(id) ON DELETE CASCADE,
  dst_id INTEGER NOT NULL REFERENCES entries(id) ON DELETE CASCADE,
  rel_type TEXT NOT NULL,
  PRIMARY KEY (src_id, dst_id, rel_type)
);
"""


def default_db_path() -> Path:
    return Path(os.environ.get("KB_DB", str(Path.home() / ".persistent-kb" / "kb.sqlite")))


class KBStore:
    """Thin wrapper around the persistent-kb SQLite schema.

    Created lazily; connections are short-lived to keep MCP tool calls thread-safe.
    """

    def __init__(self, db_path: Path | None = None):
        self.db_path = Path(db_path) if db_path else default_db_path()

    def ensure_schema(self) -> None:
        """Create the database file and schema if missing. Idempotent."""
        if self.db_path.exists():
            return
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        with sqlite3.connect(self.db_path) as conn:
            conn.executescript(SCHEMA_SQL)

    @contextmanager
    def _conn(self) -> Iterator[sqlite3.Connection]:
        if not self.db_path.exists():
            self.ensure_schema()
        conn = sqlite3.connect(self.db_path)
        conn.execute("PRAGMA foreign_keys = ON;")
        version = conn.execute("PRAGMA user_version;").fetchone()[0]
        if version != SCHEMA_VERSION:
            conn.close()
            raise RuntimeError(
                f"Schema version mismatch (db={version}, expected={SCHEMA_VERSION}). Migration needed."
            )
        try:
            yield conn
        finally:
            conn.close()

    # ---------- mutation ----------

    def add(self, *, title: str, content: str, kind: str = "note", tags: str | list[str] = "") -> dict:
        if kind not in VALID_KINDS:
            raise ValueError(f"kind must be one of {VALID_KINDS}, got {kind!r}")
        if not title.strip():
            raise ValueError("title is required")
        if not content.strip():
            raise ValueError("content is empty")
        tag_list = self._normalize_tags(tags)
        with self._conn() as conn:
            cur = conn.execute(
                "INSERT INTO entries(title, kind, content) VALUES (?, ?, ?)",
                (title, kind, content),
            )
            eid = cur.lastrowid
            for tag in tag_list:
                conn.execute(
                    "INSERT OR IGNORE INTO tags(entry_id, tag) VALUES (?, ?)",
                    (eid, tag),
                )
            conn.commit()
        return {"id": eid, "title": title, "kind": kind, "tags": tag_list}

    def update_tags(self, entry_id: int, *, add: str | list[str] = "", remove: str | list[str] = "") -> dict:
        with self._conn() as conn:
            row = conn.execute("SELECT 1 FROM entries WHERE id = ?", (entry_id,)).fetchone()
            if not row:
                raise LookupError(f"entry {entry_id} not found")
            for tag in self._normalize_tags(add):
                conn.execute(
                    "INSERT OR IGNORE INTO tags(entry_id, tag) VALUES (?, ?)",
                    (entry_id, tag),
                )
            for tag in self._normalize_tags(remove):
                conn.execute(
                    "DELETE FROM tags WHERE entry_id = ? AND tag = ?",
                    (entry_id, tag),
                )
            conn.commit()
            tags = [t for (t,) in conn.execute(
                "SELECT tag FROM tags WHERE entry_id = ? ORDER BY tag", (entry_id,)
            )]
        return {"id": entry_id, "tags": tags}

    # ---------- read ----------

    def search(
        self,
        query: str,
        *,
        top: int = 10,
        kind: str | None = None,
        tag: str | None = None,
    ) -> list[dict]:
        if not query.strip():
            return []
        sql = ["SELECT e.id, e.kind, e.title, substr(e.content, 1, 200), e.created_at"]
        sql.append("FROM entries_fts f JOIN entries e ON e.id = f.rowid")
        params: list[object] = [query]
        if tag:
            sql.append("JOIN tags t ON t.entry_id = e.id AND t.tag = ?")
            params.insert(0, tag)
        where = ["entries_fts MATCH ?"]
        if kind:
            if kind not in VALID_KINDS:
                raise ValueError(f"kind must be one of {VALID_KINDS}")
            where.append("e.kind = ?")
            params.append(kind)
        sql.append("WHERE " + " AND ".join(where))
        sql.append("ORDER BY rank")
        sql.append(f"LIMIT {int(top)}")
        with self._conn() as conn:
            rows = conn.execute(" ".join(sql), params).fetchall()
        return [
            {
                "id": eid,
                "kind": k,
                "title": title,
                "preview": (preview or "").replace("\n", " ").strip()[:200],
                "created_at": created,
            }
            for eid, k, title, preview, created in rows
        ]

    def show(self, entry_id: int) -> dict:
        with self._conn() as conn:
            row = conn.execute(
                "SELECT id, title, kind, content, superseded_by, created_at, updated_at FROM entries WHERE id = ?",
                (entry_id,),
            ).fetchone()
            if not row:
                raise LookupError(f"entry {entry_id} not found")
            eid, title, kind, content, superseded, created, updated = row
            tags = [t for (t,) in conn.execute(
                "SELECT tag FROM tags WHERE entry_id = ? ORDER BY tag", (eid,)
            )]
            relations = [
                {"rel_type": rt, "dst_id": dst}
                for rt, dst in conn.execute(
                    "SELECT rel_type, dst_id FROM relations WHERE src_id = ? ORDER BY rel_type", (eid,)
                )
            ]
        return {
            "id": eid,
            "title": title,
            "kind": kind,
            "content": content,
            "tags": tags,
            "relations": relations,
            "superseded_by": superseded,
            "created_at": created,
            "updated_at": updated,
        }

    def list(
        self,
        *,
        kind: str | None = None,
        tag: str | None = None,
        since: str | None = None,
        limit: int = 20,
    ) -> list[dict]:
        sql = ["SELECT e.id, e.kind, e.title, e.created_at FROM entries e"]
        params: list[object] = []
        if tag:
            sql.append("JOIN tags t ON t.entry_id = e.id AND t.tag = ?")
            params.append(tag)
        where = ["1=1"]
        if kind:
            if kind not in VALID_KINDS:
                raise ValueError(f"kind must be one of {VALID_KINDS}")
            where.append("e.kind = ?")
            params.append(kind)
        if since:
            where.append("date(e.created_at) >= date(?)")
            params.append(since)
        sql.append("WHERE " + " AND ".join(where))
        sql.append("ORDER BY e.created_at DESC")
        sql.append(f"LIMIT {int(limit)}")
        with self._conn() as conn:
            rows = conn.execute(" ".join(sql), params).fetchall()
        return [
            {"id": eid, "kind": k, "title": title, "created_at": created}
            for eid, k, title, created in rows
        ]

    # ---------- helpers ----------

    @staticmethod
    def _normalize_tags(tags: str | list[str]) -> list[str]:
        if isinstance(tags, list):
            return [t.strip() for t in tags if t and t.strip()]
        return [t.strip() for t in tags.split(",") if t and t.strip()]
