import json, logging, os, threading, time
from pathlib import Path

logger = logging.getLogger(__name__)

# Minimum seconds between replay attempts to avoid hammering the API
_REPLAY_COOLDOWN = 10


def http_emit(api_url, api_key, fallback_path):
    replay_lock = threading.Lock()
    last_replay_attempt = 0.0

    def _send_one(data_bytes):
        """Send raw JSON bytes to the ingest endpoint. Returns True on success."""
        import urllib.request
        req = urllib.request.Request(
            f"{api_url}/ingest",
            data=data_bytes,
            headers={
                "Content-Type": "application/json",
                "X-API-Key": api_key,
            },
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            return resp.status in (201, 202)

    def _try_replay():
        """Replay buffered fallback events to the API. Best-effort, never raises."""
        nonlocal last_replay_attempt
        now = time.monotonic()
        if now - last_replay_attempt < _REPLAY_COOLDOWN:
            return
        if not replay_lock.acquire(blocking=False):
            return
        try:
            last_replay_attempt = now
            fp = Path(fallback_path)
            if not fp.exists() or fp.stat().st_size == 0:
                return
            lines = fp.read_text().splitlines()
            if not lines:
                return
            remaining = []
            for line in lines:
                line = line.strip()
                if not line:
                    continue
                try:
                    _send_one(line.encode("utf-8"))
                except Exception:
                    remaining.append(line)
            if remaining:
                fp.write_text("\n".join(remaining) + "\n")
            else:
                fp.unlink(missing_ok=True)
            replayed = len(lines) - len(remaining)
            if replayed:
                logger.info(f"wytness: replayed {replayed} fallback events")
        except Exception as e:
            logger.debug(f"wytness: fallback replay error: {e}")
        finally:
            replay_lock.release()

    def _emit(event_dict):
        try:
            data = json.dumps(event_dict, default=str).encode("utf-8")
            if _send_one(data):
                _try_replay()
            else:
                logger.error("HTTP ingest failed: non-201 status")
                _file_emit(fallback_path, event_dict)
        except Exception as e:
            logger.error(f"HTTP ingest error: {e}")
            _file_emit(fallback_path, event_dict)
    return _emit


def file_emit(fallback_path):
    def _emit(event_dict):
        _file_emit(fallback_path, event_dict)
    return _emit


def _file_emit(path, event_dict):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, "a") as f:
        f.write(json.dumps(event_dict, default=str) + "\n")
