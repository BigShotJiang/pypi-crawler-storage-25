from pydantic import BaseModel, Field
from datetime import datetime
from typing import Optional
import uuid


class AuditEvent(BaseModel):
    # Layer 1: Identity
    event_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    agent_id: str
    agent_version: str
    human_operator_id: str
    task_id: str
    session_id: str
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    # Layer 2: Authorization
    scope_token_id: str = "default"
    scope_permissions: list[str] = Field(default_factory=list)
    granted_by: str = "system"
    hitl_approved: bool = False
    # Layer 3: Action
    tool_name: str
    tool_parameters: dict = Field(default_factory=dict)
    reasoning_summary: str = ""
    prompt: str = ""
    # Layer 4: Data
    inputs_hash: str = ""
    inputs_classification: str = "internal"
    inputs_source: str = ""
    outputs_hash: str = ""
    outputs_destination: str = ""
    response: str = ""
    # Layer 5: Outcome
    status: str = "success"
    error_code: Optional[str] = None
    duration_ms: int = 0
    retry_count: int = 0
    # Chain integrity
    prev_event_hash: str = ""
    signature: str = ""
    # Pseudonymization
    encrypted_token_map: str = ""
    pseudonymization_version: str = ""
