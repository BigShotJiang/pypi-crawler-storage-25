import asyncio, base64, functools, hashlib, json, logging, re, time, inspect, uuid
from datetime import datetime
from typing import Optional
from .models import AuditEvent
from .signing import sign_event, load_private_key, load_private_key_from_base64, generate_keypair, save_private_key
from .chain import compute_event_hash
from .emitter import http_emit, file_emit
from .tokenizer import SessionTokenizer
import os
from pathlib import Path

logger = logging.getLogger(__name__)

SECRET_PATTERNS = re.compile(r'(key|secret|token|password|passwd|pwd|credential|auth)', re.IGNORECASE)

# PII patterns for value-level redaction
PII_PATTERNS = [
    (re.compile(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'), '[EMAIL_REDACTED]'),
    (re.compile(r'\b\d{3}[-.\s]?\d{2}[-.\s]?\d{4}\b'), '[SSN_REDACTED]'),         # SSN
    (re.compile(r'\b\d{3}[-.\s]?\d{3}[-.\s]?\d{3}\b'), '[TFN_REDACTED]'),          # AU TFN
    (re.compile(r'\b(?:\d{4}[-\s]?){3}\d{4}\b'), '[CARD_REDACTED]'),               # Credit card
    (re.compile(r'\b(?:\+?\d{1,3}[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}\b'), '[PHONE_REDACTED]'),
]

RESPONSE_MAX_CHARS = 5000


def _redact_pii(text: str) -> str:
    """Scan text for PII patterns and redact matches."""
    for pattern, replacement in PII_PATTERNS:
        text = pattern.sub(replacement, text)
    return text


def _sanitise(params):
    result = {}
    for k, v in params.items():
        if SECRET_PATTERNS.search(str(k)):
            result[k] = "[REDACTED]"
        else:
            val = str(v)[:500]
            result[k] = _redact_pii(val)
    return result


def hash_value(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, default=str).encode()).hexdigest()


class AuditClient:
    def __init__(self, agent_id, agent_version="0.1.0", human_operator_id="unknown",
                 signing_key=None, signing_key_path="./keys/signing.key",
                 fallback_log_path="./audit_fallback.jsonl",
                 http_api_key=None, http_endpoint="https://api.wytness.dev",
                 pii_hmac_secret: Optional[str] = None,
                 encryption_public_key: Optional[str] = None,
                 pii_fields: Optional[list[str]] = None):
        self.agent_id = agent_id
        self.agent_version = agent_version
        self.human_operator_id = human_operator_id
        self._prev_event_hash = ""
        self._session_id = str(uuid.uuid4())
        if signing_key:
            self._private_key = load_private_key_from_base64(signing_key)
        elif not os.path.exists(signing_key_path):
            Path(signing_key_path).parent.mkdir(parents=True, exist_ok=True)
            priv, _ = generate_keypair()
            save_private_key(priv, signing_key_path)
            self._private_key = priv
        else:
            self._private_key = load_private_key(signing_key_path)
        self._pending_requests = []
        if http_api_key:
            self._emit = http_emit(http_endpoint, http_api_key, fallback_log_path)
        else:
            self._emit = file_emit(fallback_log_path)
        # Pseudonymization: requires both HMAC secret and encryption public key
        self._tokenizer: Optional[SessionTokenizer] = None
        if pii_hmac_secret and encryption_public_key:
            hmac_bytes = base64.b64decode(pii_hmac_secret)
            pub_bytes = base64.b64decode(encryption_public_key)
            self._tokenizer = SessionTokenizer(hmac_bytes, pub_bytes, pii_fields or [])

    @property
    def session_id(self):
        return self._session_id

    def record(self, event):
        """Record an audit event. Never raises — errors are logged and swallowed."""
        try:
            d = event.model_dump(mode="json")
            d["prev_event_hash"] = self._prev_event_hash
            d["signature"] = sign_event(d, self._private_key)
            self._prev_event_hash = compute_event_hash(d)
            self._emit(d)
        except Exception as e:
            logger.error(f"wytness: failed to record event: {e}")

    def flush(self, timeout=5.0):
        """Wait for pending HTTP requests to complete. No-op for file emitter.

        Call this before process exit in serverless/short-lived environments
        to ensure all events are delivered.
        """
        # Python emitter is synchronous (urllib), so nothing to flush.
        # This method exists for API consistency with the TypeScript SDK
        # and as a hook for future async transport.
        pass


def _record_event(client, func, args, kwargs, start, status, error_code, result, task_id, prompt):
    sig = inspect.signature(func)
    named = dict(zip(sig.parameters.keys(), args))
    named.update(kwargs)
    # Hash the full result before truncation/redaction for integrity
    outputs_hash = hash_value(result) if result else ""

    tokenizer = client._tokenizer
    if tokenizer:
        # Pseudonymization mode: consistent tokens, encrypted mapping
        # Process params FIRST so declared pii_fields populate the reverse map,
        # then response/prompt can pick up those values via propagation.
        tool_params = tokenizer.pseudonymize_params(named)
        pseudonymized_prompt = tokenizer.pseudonymize_text(prompt) if prompt else ""
        response = ""
        if result is not None:
            response = tokenizer.pseudonymize_text(str(result)[:RESPONSE_MAX_CHARS])
        encrypted_map = tokenizer.encrypt_token_map()
        client.record(AuditEvent(
            agent_id=client.agent_id, agent_version=client.agent_version,
            human_operator_id=client.human_operator_id, task_id=task_id,
            session_id=client.session_id, tool_name=func.__name__,
            tool_parameters=tool_params,
            prompt=pseudonymized_prompt,
            inputs_hash=hash_value({"args": args, "kwargs": kwargs}),
            outputs_hash=outputs_hash,
            response=response,
            status=status, error_code=error_code,
            duration_ms=int((time.monotonic() - start) * 1000),
            encrypted_token_map=encrypted_map,
            pseudonymization_version="1.0",
        ))
    else:
        # Legacy redaction mode
        response = ""
        if result is not None:
            response = _redact_pii(str(result)[:RESPONSE_MAX_CHARS])
        client.record(AuditEvent(
            agent_id=client.agent_id, agent_version=client.agent_version,
            human_operator_id=client.human_operator_id, task_id=task_id,
            session_id=client.session_id, tool_name=func.__name__,
            tool_parameters=_sanitise(named),
            prompt=prompt,
            inputs_hash=hash_value({"args": args, "kwargs": kwargs}),
            outputs_hash=outputs_hash,
            response=response,
            status=status, error_code=error_code,
            duration_ms=int((time.monotonic() - start) * 1000),
        ))


def audit_tool(client, task_id="default", prompt=""):
    def decorator(func):
        if asyncio.iscoroutinefunction(func):
            @functools.wraps(func)
            async def async_wrapper(*args, **kwargs):
                start = time.monotonic()
                status, error_code, result = "success", None, None
                try:
                    result = await func(*args, **kwargs)
                except Exception as e:
                    status, error_code = "failure", type(e).__name__
                    raise
                finally:
                    _record_event(client, func, args, kwargs, start, status, error_code, result, task_id, prompt)
                return result
            return async_wrapper
        else:
            @functools.wraps(func)
            def wrapper(*args, **kwargs):
                start = time.monotonic()
                status, error_code, result = "success", None, None
                try:
                    result = func(*args, **kwargs)
                except Exception as e:
                    status, error_code = "failure", type(e).__name__
                    raise
                finally:
                    _record_event(client, func, args, kwargs, start, status, error_code, result, task_id, prompt)
                return result
            return wrapper
    return decorator
