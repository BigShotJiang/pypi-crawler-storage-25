import base64
import json
import os
import tempfile
from pathlib import Path

from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PrivateKey

from wytness.tokenizer import SessionTokenizer


def _make_keys():
    """Generate test HMAC secret and X25519 keypair."""
    hmac_secret = b"test-hmac-secret-32-bytes-long!!"  # 32 bytes
    private_key = X25519PrivateKey.generate()
    public_key_bytes = private_key.public_key().public_bytes_raw()
    private_key_bytes = private_key.private_bytes_raw()
    return hmac_secret, public_key_bytes, private_key_bytes


def test_same_value_same_pseudonym():
    hmac_secret, pub, _ = _make_keys()
    t = SessionTokenizer(hmac_secret, pub, pii_fields=["name"])
    p1 = t.pseudonymize_value("Ravneet Chalana", "name")
    p2 = t.pseudonymize_value("Ravneet Chalana", "name")
    assert p1 == p2
    assert p1.startswith("PII_")
    assert "Ravneet" not in p1


def test_different_values_different_pseudonyms():
    hmac_secret, pub, _ = _make_keys()
    t = SessionTokenizer(hmac_secret, pub, pii_fields=["name"])
    p1 = t.pseudonymize_value("Ravneet Chalana", "name")
    p2 = t.pseudonymize_value("John Smith", "name")
    assert p1 != p2


def test_cross_session_consistency():
    hmac_secret, pub, _ = _make_keys()
    t1 = SessionTokenizer(hmac_secret, pub, pii_fields=["name"])
    t2 = SessionTokenizer(hmac_secret, pub, pii_fields=["name"])
    p1 = t1.pseudonymize_value("Ravneet Chalana", "name")
    p2 = t2.pseudonymize_value("Ravneet Chalana", "name")
    assert p1 == p2  # Same HMAC secret → same pseudonym across sessions


def test_pii_fields_fully_replaced():
    hmac_secret, pub, _ = _make_keys()
    t = SessionTokenizer(hmac_secret, pub, pii_fields=["customer_name"])
    result = t.pseudonymize_params({"customer_name": "Jane Doe", "amount": "99.99"})
    assert result["customer_name"].startswith("PII_")
    assert "Jane" not in result["customer_name"]
    assert result["amount"] == "99.99"


def test_regex_email_pseudonymized():
    hmac_secret, pub, _ = _make_keys()
    t = SessionTokenizer(hmac_secret, pub)
    text = "Contact user at john@example.com for details"
    result = t.pseudonymize_text(text)
    assert "john@example.com" not in result
    assert "EMAIL_" in result
    assert "Contact user at" in result


def test_reverse_map_propagation():
    hmac_secret, pub, _ = _make_keys()
    t = SessionTokenizer(hmac_secret, pub, pii_fields=["customer_name"])
    # First: pseudonymize in a declared field
    t.pseudonymize_value("Ravneet Chalana", "customer_name")
    # Then: the same name in free text should get the same token
    text = "Found entity: Ravneet Chalana is a director"
    result = t.pseudonymize_text(text)
    assert "Ravneet Chalana" not in result
    assert "PII_" in result
    # The pseudonym should be the same one
    pseudonym = t._reverse_map["Ravneet Chalana"]
    assert pseudonym in result


def test_encrypt_decrypt_roundtrip():
    hmac_secret, pub, priv = _make_keys()
    t = SessionTokenizer(hmac_secret, pub, pii_fields=["name"])
    t.pseudonymize_value("Ravneet Chalana", "name")
    t.pseudonymize_value("Providence Tech", "name")

    encrypted = t.encrypt_token_map()
    assert isinstance(encrypted, str)
    assert len(encrypted) > 50  # non-trivial base64

    decrypted = SessionTokenizer.decrypt_token_map(encrypted, priv)
    assert isinstance(decrypted, dict)
    # Token map has pseudonym → original
    assert "Ravneet Chalana" in decrypted.values()
    assert "Providence Tech" in decrypted.values()


def test_secret_params_still_redacted():
    hmac_secret, pub, _ = _make_keys()
    t = SessionTokenizer(hmac_secret, pub, pii_fields=["name"])
    result = t.pseudonymize_params({
        "name": "Jane Doe",
        "api_key": "sk_live_abc123",
        "query": "search term",
    })
    assert result["api_key"] == "[REDACTED]"
    assert result["name"].startswith("PII_")
    assert result["query"] == "search term"


def test_no_keys_falls_back_to_redaction():
    """When no tokenizer is configured, decorator should use _redact_pii."""
    with tempfile.TemporaryDirectory() as tmpdir:
        from wytness.decorator import AuditClient, audit_tool

        key_path = os.path.join(tmpdir, "signing.key")
        log_path = os.path.join(tmpdir, "audit.jsonl")
        # No pii_hmac_secret or encryption_public_key
        client = AuditClient(
            agent_id="test-agent",
            human_operator_id="user-1",
            signing_key_path=key_path,
            fallback_log_path=log_path,
        )

        @audit_tool(client=client)
        def send_email(to: str):
            return "Sent to john@example.com"

        send_email("john@example.com")
        events = [json.loads(l) for l in Path(log_path).read_text().strip().splitlines()]
        assert len(events) == 1
        # Should use old [EMAIL_REDACTED] behavior
        assert "[EMAIL_REDACTED]" in events[0]["response"]
        assert events[0].get("encrypted_token_map", "") == ""
        assert events[0].get("pseudonymization_version", "") == ""


def test_pseudonymization_in_decorator():
    """When tokenizer is configured, decorator should pseudonymize and attach token map."""
    hmac_secret, pub, priv = _make_keys()
    with tempfile.TemporaryDirectory() as tmpdir:
        from wytness.decorator import AuditClient, audit_tool

        key_path = os.path.join(tmpdir, "signing.key")
        log_path = os.path.join(tmpdir, "audit.jsonl")
        client = AuditClient(
            agent_id="test-agent",
            human_operator_id="user-1",
            signing_key_path=key_path,
            fallback_log_path=log_path,
            pii_hmac_secret=base64.b64encode(hmac_secret).decode(),
            encryption_public_key=base64.b64encode(pub).decode(),
            pii_fields=["customer_name"],
        )

        @audit_tool(client=client)
        def lookup(customer_name: str):
            return f"Found: {customer_name}, email: test@example.com"

        lookup("Ravneet Chalana")
        events = [json.loads(l) for l in Path(log_path).read_text().strip().splitlines()]
        assert len(events) == 1
        event = events[0]
        # Should NOT contain real name
        assert "Ravneet Chalana" not in json.dumps(event["tool_parameters"])
        assert "Ravneet Chalana" not in event["response"]
        # Should contain pseudonyms
        assert "PII_" in event["tool_parameters"]["customer_name"]
        assert "EMAIL_" in event["response"]
        # Should have encrypted token map
        assert event["encrypted_token_map"] != ""
        assert event["pseudonymization_version"] == "1.0"
        # Decrypt and verify
        decrypted = SessionTokenizer.decrypt_token_map(event["encrypted_token_map"], priv)
        assert "Ravneet Chalana" in decrypted.values()
        assert "test@example.com" in decrypted.values()
