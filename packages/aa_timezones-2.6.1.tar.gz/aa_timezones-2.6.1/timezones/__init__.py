"""
Application init
"""

# Django
from django.utils.translation import gettext_lazy as _

__version__ = "2.6.1"
__title__ = "Time Zones"
__title_translated__ = _("Time Zones")
