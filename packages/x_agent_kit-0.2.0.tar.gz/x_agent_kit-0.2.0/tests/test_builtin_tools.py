from pathlib import Path
from unittest.mock import MagicMock
FIXTURES = Path(__file__).parent / "fixtures"

class TestBuiltinLoadSkill:
    def test_load_skill_returns_content(self):
        from x_agent_kit.tools.builtin import create_load_skill_tool
        from x_agent_kit.skills.loader import SkillLoader
        loader = SkillLoader(paths=[str(FIXTURES / ".agent/skills")])
        fn = create_load_skill_tool(loader)
        result = fn(name="my-rules")
        assert "Always be polite" in result

    def test_load_skill_not_found(self):
        from x_agent_kit.tools.builtin import create_load_skill_tool
        from x_agent_kit.skills.loader import SkillLoader
        loader = SkillLoader(paths=[str(FIXTURES / ".agent/skills")])
        fn = create_load_skill_tool(loader)
        result = fn(name="nonexistent")
        assert "not found" in result.lower()

class TestBuiltinListSkills:
    def test_list_skills_returns_names(self):
        from x_agent_kit.tools.builtin import create_list_skills_tool
        from x_agent_kit.skills.loader import SkillLoader
        loader = SkillLoader(paths=[str(FIXTURES / ".agent/skills")])
        fn = create_list_skills_tool(loader)
        result = fn()
        assert "my-rules" in result

class TestBuiltinNotify:
    def test_notify_calls_channel(self):
        from x_agent_kit.tools.builtin import create_notify_tool
        mock_channels = {"default": MagicMock()}
        mock_channels["default"].send_text.return_value = {"ok": True}
        fn = create_notify_tool(mock_channels)
        result = fn(message="hello")
        assert result is True
        mock_channels["default"].send_text.assert_called_once_with("hello")

class TestBuiltinRequestApproval:
    def test_request_approval_sends_card(self):
        from x_agent_kit.tools.builtin import create_request_approval_tool
        mock_channels = {"default": MagicMock()}
        mock_channels["default"].send_approval_card.return_value = {"ok": True}
        fn = create_request_approval_tool(mock_channels)
        result = fn(action="test", details="detail")
        mock_channels["default"].send_approval_card.assert_called_once()
        assert "Approval request sent" in result

    def test_request_approval_queues_when_tool_name_given(self):
        from x_agent_kit.tools.builtin import create_request_approval_tool
        from unittest.mock import MagicMock
        mock_channels = {"default": MagicMock()}
        mock_channels["default"].send_approval_card.return_value = {"ok": True}
        mock_queue = MagicMock()
        fn = create_request_approval_tool(mock_channels, approval_queue=mock_queue)
        result = fn(action="Pause", details="details", tool_name="pause_campaign", tool_args='{"id": "123"}')
        mock_queue.add.assert_called_once()
        call_args = mock_queue.add.call_args[0]
        assert call_args[1] == "Pause"       # action
        assert call_args[3] == "pause_campaign"  # tool_name
        assert call_args[4] == {"id": "123"}     # tool_args
        assert "pause_campaign" in result

class TestBuiltinToolLabels:
    def test_save_memory_has_label(self):
        from x_agent_kit.tools.builtin import create_save_memory_tool
        from unittest.mock import MagicMock
        fn = create_save_memory_tool(MagicMock())
        assert fn._tool_meta.label != ""

    def test_load_skill_has_label(self):
        from x_agent_kit.tools.builtin import create_load_skill_tool
        from unittest.mock import MagicMock
        fn = create_load_skill_tool(MagicMock())
        assert fn._tool_meta.label != ""

    def test_notify_has_label(self):
        from x_agent_kit.tools.builtin import create_notify_tool
        fn = create_notify_tool({"default": MagicMock()})
        assert fn._tool_meta.label != ""

    def test_request_approval_has_label(self):
        from x_agent_kit.tools.builtin import create_request_approval_tool
        fn = create_request_approval_tool({"default": MagicMock()})
        assert fn._tool_meta.label != ""

    def test_create_plan_has_label(self):
        from x_agent_kit.tools.builtin import create_plan_tool
        from unittest.mock import MagicMock
        fn = create_plan_tool(MagicMock())
        assert fn._tool_meta.label != ""
