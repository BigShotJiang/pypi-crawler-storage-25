"""HTPDF API client for Python."""

from __future__ import annotations

import time
from typing import Any, Optional

import httpx


class HTPDFError(Exception):
    """Raised when the HTPDF API returns an error."""

    def __init__(self, status_code: int, error: str, message: str, request_id: str | None = None):
        self.status_code = status_code
        self.error = error
        self.message = message
        self.request_id = request_id
        super().__init__(f"[{status_code}] {error}: {message}")


class HTPDFClient:
    """Synchronous client for the HTPDF API.

    Usage::

        from htpdf import HTPDFClient

        client = HTPDFClient("htpdf_live_...")
        result = client.html_to_pdf("<h1>Hello</h1>")
        print(result["pdf_id"])

        # Download the PDF bytes
        pdf_bytes = client.download(result["pdf_id"])
        with open("output.pdf", "wb") as f:
            f.write(pdf_bytes)
    """

    BASE_URL = "https://api.htpdf.net"

    def __init__(
        self,
        api_key: str,
        *,
        base_url: str | None = None,
        timeout: float = 60.0,
    ):
        self.api_key = api_key
        self.base_url = (base_url or self.BASE_URL).rstrip("/")
        self._client = httpx.Client(
            base_url=self.base_url,
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
                "User-Agent": "htpdf-python/1.0.0",
            },
            timeout=timeout,
        )

    def _request(self, method: str, path: str, **kwargs: Any) -> Any:
        resp = self._client.request(method, path, **kwargs)
        if resp.status_code >= 400:
            body = resp.json() if resp.headers.get("content-type", "").startswith("application/json") else {}
            raise HTPDFError(
                status_code=resp.status_code,
                error=body.get("error", "unknown"),
                message=body.get("message", resp.text),
                request_id=body.get("request_id"),
            )
        return resp

    # ---- PDF Generation ----

    def html_to_pdf(
        self,
        html: str,
        *,
        options: dict | None = None,
        brand_kit_id: str | None = None,
    ) -> dict:
        """Convert HTML to PDF."""
        payload: dict[str, Any] = {"html": html}
        if options:
            payload["options"] = options
        if brand_kit_id:
            payload["brand_kit_id"] = brand_kit_id
        return self._request("POST", "/v1/pdf/html", json=payload).json()

    def url_to_pdf(
        self,
        url: str,
        *,
        options: dict | None = None,
        brand_kit_id: str | None = None,
    ) -> dict:
        """Convert a URL to PDF."""
        payload: dict[str, Any] = {"url": url}
        if options:
            payload["options"] = options
        if brand_kit_id:
            payload["brand_kit_id"] = brand_kit_id
        return self._request("POST", "/v1/pdf/url", json=payload).json()

    def markdown_to_pdf(
        self,
        markdown: str,
        *,
        theme: str = "github",
        options: dict | None = None,
    ) -> dict:
        """Convert Markdown to PDF."""
        payload: dict[str, Any] = {"markdown": markdown, "theme": theme}
        if options:
            payload["options"] = options
        return self._request("POST", "/v1/pdf/markdown", json=payload).json()

    def template_to_pdf(
        self,
        template: str,
        data: dict,
        *,
        options: dict | None = None,
        brand_kit_id: str | None = None,
    ) -> dict:
        """Generate PDF from a template."""
        payload: dict[str, Any] = {"template": template, "data": data}
        if options:
            payload["options"] = options
        if brand_kit_id:
            payload["brand_kit_id"] = brand_kit_id
        return self._request("POST", "/v1/pdf/template", json=payload).json()

    # ---- Async PDF ----

    def async_pdf(
        self,
        source_type: str,
        *,
        callback_url: str | None = None,
        **kwargs: Any,
    ) -> dict:
        """Queue an async PDF generation job (Pro+)."""
        payload: dict[str, Any] = {"source_type": source_type, **kwargs}
        if callback_url:
            payload["callback_url"] = callback_url
        return self._request("POST", "/v1/pdf/async", json=payload).json()

    def get_async_job(self, job_id: str) -> dict:
        """Poll an async job status."""
        return self._request("GET", f"/v1/pdf/async/{job_id}").json()

    def wait_for_async_job(self, job_id: str, *, poll_interval: float = 2.0, timeout: float = 300.0) -> dict:
        """Poll until an async job completes or fails."""
        start = time.monotonic()
        while True:
            job = self.get_async_job(job_id)
            if job["status"] in ("completed", "failed"):
                return job
            if time.monotonic() - start > timeout:
                raise TimeoutError(f"Async job {job_id} did not complete within {timeout}s")
            time.sleep(poll_interval)

    # ---- Download ----

    def download(self, pdf_id: str) -> bytes:
        """Download a generated PDF as bytes."""
        resp = self._request("GET", f"/v1/pdf/{pdf_id}/download")
        return resp.content

    # ---- Screenshots ----

    def html_to_screenshot(self, html: str, *, options: dict | None = None) -> dict:
        """Capture a screenshot from HTML."""
        payload: dict[str, Any] = {"html": html}
        if options:
            payload["options"] = options
        return self._request("POST", "/v1/screenshot/html", json=payload).json()

    def url_to_screenshot(self, url: str, *, options: dict | None = None) -> dict:
        """Capture a screenshot from a URL."""
        payload: dict[str, Any] = {"url": url}
        if options:
            payload["options"] = options
        return self._request("POST", "/v1/screenshot/url", json=payload).json()

    # ---- Document Hosting ----

    def create_hosted_document(
        self,
        pdf_id: str,
        *,
        download_limit: int | None = None,
        expires_in_hours: int | None = None,
        password: str | None = None,
        custom_slug: str | None = None,
    ) -> dict:
        """Create a shareable hosted document link (Pro+)."""
        payload: dict[str, Any] = {"pdf_id": pdf_id}
        if download_limit is not None:
            payload["download_limit"] = download_limit
        if expires_in_hours is not None:
            payload["expires_in_hours"] = expires_in_hours
        if password:
            payload["password"] = password
        if custom_slug:
            payload["custom_slug"] = custom_slug
        return self._request("POST", "/v1/documents", json=payload).json()

    def list_hosted_documents(self) -> dict:
        """List all hosted documents."""
        return self._request("GET", "/v1/documents").json()

    def delete_hosted_document(self, doc_id: str) -> dict:
        """Deactivate a hosted document."""
        return self._request("DELETE", f"/v1/documents/{doc_id}").json()

    # ---- Merge / Split ----

    def merge(self, pdf_ids: list[str], *, filename: str | None = None) -> dict:
        """Merge multiple PDFs into one."""
        payload: dict[str, Any] = {"pdf_ids": pdf_ids}
        if filename:
            payload["filename"] = filename
        return self._request("POST", "/v1/pdf/merge", json=payload).json()

    # ---- Cleanup ----

    def close(self) -> None:
        """Close the underlying HTTP client."""
        self._client.close()

    def __enter__(self) -> "HTPDFClient":
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()
