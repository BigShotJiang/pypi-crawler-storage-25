# HTPDF Python SDK

Generate PDFs, screenshots, and hosted documents via the [HTPDF API](https://htpdf.net).

## Install

```bash
pip install htpdf
```

## Quick Start

```python
from htpdf import HTPDFClient

client = HTPDFClient("htpdf_live_...")

# HTML to PDF
result = client.html_to_pdf("<h1>Hello World</h1>")
print(result["pdf_id"], result["url"])

# Download
pdf_bytes = client.download(result["pdf_id"])
with open("output.pdf", "wb") as f:
    f.write(pdf_bytes)

# URL to PDF
result = client.url_to_pdf("https://example.com")

# Async PDF (Pro+)
job = client.async_pdf("html", html="<h1>Async</h1>")
completed = client.wait_for_async_job(job["job_id"])

# Document Hosting (Pro+)
doc = client.create_hosted_document(result["pdf_id"], expires_in_hours=24)
print(doc["url"])  # /d/abc12345
```

## License

MIT
