"""I/O utility functions for MCP Kyvos."""

import os
from mcp_kyvos_server.utils.logging import setup_logger
from ..utils.constants import InfoLogs, DebugLogs

logger, log_path = setup_logger()

def is_read_only_mode() -> bool:
    """Check if the server is running in read-only mode.

    Read-only mode prevents all write operations (create, update, delete)
    while allowing all read operations. This is useful for working with
    production Kyvos instances where you want to prevent accidental
    modifications.

    Returns:
        True if read-only mode is enabled, False otherwise
    """
    value = os.getenv("READ_ONLY_MODE", "false")
    return value.lower() in ("true", "1", "yes", "y", "on")


def load_prompt(raw_data_query: bool) -> str:
    """
    Load and return the appropriate Kyvos prompt file based on query type.

    Args:
        raw_data_query (bool): Flag indicating whether to use the flexible (raw data) prompt.

    Returns:
        str: The contents of the prompt file.

    Raises:
        FileNotFoundError: If the prompt file does not exist.
    """
    logger.debug(
        InfoLogs.RAW_DATA_QUERY_FLAG.format(raw_data_query=raw_data_query)
    )

    base_dir = os.path.dirname(__file__)

    if raw_data_query:
        prompt_path = os.path.join(
            base_dir, "..", "kyvos", "prompt", "fsm_system_prompt.txt"
        )
        logger.debug(DebugLogs.USING_FLEXIBLE_PROMPT.format(path=prompt_path))
    else:
        prompt_path = os.path.join(
            base_dir, "..", "kyvos", "prompt", "kyvos_prompt.txt"
        )
        logger.debug(DebugLogs.USING_STANDARD_PROMPT.format(path=prompt_path))

    prompt_path = os.path.abspath(prompt_path)

    if not os.path.exists(prompt_path):
        raise FileNotFoundError(f"Prompt file not found: {prompt_path}")

    with open(prompt_path, "r", encoding="utf-8") as f:
        prompt_content = f.read()

    logger.info(InfoLogs.PROMPT_FILE_LOADED_DEFAULT)

    return prompt_content