import argparse

from deepagents import create_deep_agent
from deepagents.backends import FilesystemBackend
from langchain.chat_models import init_chat_model

from openagentic_ai.prompts.prompt import DEEP_AGENT_SYSTEM_PROMPT
from openagentic_ai.subagents.subagents import subagents
from openagentic_ai.subagents.subagents_tools.internet_search import internet_search
from openagentic_ai.utils.utils import base_llm


def build_agent():
    model = init_chat_model(base_llm)
    tools = [internet_search]
    backend = FilesystemBackend(root_dir=".", virtual_mode=True)
    return create_deep_agent(
        model=model,
        tools=tools,
        system_prompt=DEEP_AGENT_SYSTEM_PROMPT,
        subagents=subagents,
        backend=backend,
    )


def main():
    parser = argparse.ArgumentParser(
        prog="open-code",
        description="AI coding assistant powered by deepagents",
    )
    parser.add_argument("query", nargs="?", help="Query to send to the agent (optional, will prompt if omitted)")
    parser.add_argument("--mode", choices=["ask", "auto", "plan"], default="auto", help="Agent mode (default: auto)")
    args = parser.parse_args()

    agent = build_agent()

    query = args.query if args.query else input("Requête : ").strip()

    result = agent.invoke({"messages": [{"role": "user", "content": query}]})
    print(result["messages"][-1].content)


if __name__ == "__main__":
    main()
