import os

from langchain_core.tools import tool

SANDBOX_DIR = "./agent_sandbox"

# --- Outils CRUD pour FileOps ---
@tool
def create_file(path: str, content: str = "") -> str:
    """Create a file at the given path with optional content."""
    full_path = os.path.join(SANDBOX_DIR, path)
    os.makedirs(os.path.dirname(full_path), exist_ok=True)
    with open(full_path, "w") as f:
        f.write(content)
    return f"File {full_path} created."

@tool
def read_file(path: str) -> str:
    """Read and return the content of a file."""
    full_path = os.path.join(SANDBOX_DIR, path)
    if not os.path.exists(full_path):
        return f"File {full_path} not found."
    with open(full_path, "r") as f:
        return f.read()

@tool
def edit_file(path: str, old_string: str, new_string: str) -> str:
    """Replace old_string with new_string in the specified file."""
    full_path = os.path.join(SANDBOX_DIR, path)
    if not os.path.exists(full_path):
        return f"File {full_path} not found."
    with open(full_path, "r") as f:
        content = f.read()
    if old_string not in content:
        return f"String not found in {full_path}."
    with open(full_path, "w") as f:
        f.write(content.replace(old_string, new_string, 1))
    return f"File {full_path} edited."

@tool
def delete_file(path: str) -> str:
    """Delete a file at the given path."""
    full_path = os.path.join(SANDBOX_DIR, path)
    if not os.path.exists(full_path):
        return f"File {full_path} not found."
    os.remove(full_path)
    return f"File {full_path} deleted."

@tool
def grep_file(path: str, pattern: str) -> str:
    """Search for a pattern in a file and return matching lines."""
    full_path = os.path.join(SANDBOX_DIR, path)
    if not os.path.exists(full_path):
        return f"File {full_path} not found."
    results = []
    with open(full_path, "r") as f:
        for i, line in enumerate(f, start=1):
            if pattern in line:
                results.append(f"Line {i}: {line.strip()}")
    return "\n".join(results) if results else f"No matches for '{pattern}'."

@tool
def list_dir(path: str = ".") -> str:
    """List the contents of a directory."""
    full_path = os.path.join(SANDBOX_DIR, path)
    if not os.path.exists(full_path):
        return f"Directory {full_path} not found."
    return "\n".join(os.listdir(full_path))

@tool
def create_dir(path: str) -> str:
    """Create a directory at the given path."""
    full_path = os.path.join(SANDBOX_DIR, path)
    os.makedirs(full_path, exist_ok=True)
    return f"Directory {full_path} created."

@tool
def delete_dir(path: str) -> str:
    """Delete an empty directory at the given path."""
    full_path = os.path.join(SANDBOX_DIR, path)
    if not os.path.exists(full_path):
        return f"Directory {full_path} not found."
    os.rmdir(full_path)
    return f"Directory {full_path} deleted."
