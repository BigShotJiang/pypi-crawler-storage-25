from deepagents import SubAgent
from openagentic_ai.subagents.subagents_tools.crud_tools import (
    create_file, read_file, edit_file, delete_file,
    grep_file, list_dir, create_dir, delete_dir
)
from openagentic_ai.subagents.subagents_tools.internet_search import internet_search
from openagentic_ai.utils.utils import base_llm

subagents: list[SubAgent] = [
    {
        "name": "file-ops-agent",
        "description": "Handles all filesystem operations inside the sandbox directory",
        "system_prompt": "You are a file management specialist. Focus on creating, reading, editing, deleting files and directories...",
        "tools": [
            create_file, read_file, edit_file, delete_file,
            grep_file, list_dir, create_dir, delete_dir
        ],
        "model": base_llm
    },
    {
        "name": "runner-agent",
        "description": "Executes code and commands safely inside a local sandbox",
        "system_prompt": "You are a code execution specialist. Run scripts and commands, capture output, and report results.",
        "model": base_llm
    },
    {
        "name": "research-agent",
        "description": "Conducts research and gathers external information when needed",
        "system_prompt": "You are a research specialist. Use internet_search and document findings in files...",
        "tools": [internet_search, read_file, create_file],
        "model": base_llm
    }
]
