import re
import os
from dotenv import load_dotenv

load_dotenv()


def parse_mentions(text: str) -> list[str]:
    """Parser les mentions @ du user pour sélectionner les fichiers qu'il mentionne."""
    return re.findall(r"@([\w./\\-]+)", text)


def mode_router(mode: str) -> str:
    """Retourne le system prompt additionnel selon le mode ask/auto/plan choisi par le user."""
    modes = {
        "ask": "Only answer questions and explain. Do NOT modify any files or run any commands.",
        "auto": "Work autonomously: plan, edit files, and run commands as needed to complete the task.",
        "plan": "First produce a detailed step-by-step plan and wait for user approval before doing anything.",
    }
    if mode not in modes:
        raise ValueError(f"Unknown mode '{mode}'. Choose from: {list(modes.keys())}")
    return modes[mode]


base_llm = os.environ.get("MISTRAL_MODEL", "mistral-large-latest")
