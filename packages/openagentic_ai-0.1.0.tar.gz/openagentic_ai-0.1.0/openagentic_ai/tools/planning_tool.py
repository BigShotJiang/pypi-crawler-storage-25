from langchain.tools import tool
from typing import List

@tool
def todo_write(tasks: List[str]) -> str:
    """Create a todo list with the given tasks."""
    formatted_tasks = "\n".join([f"- {task}" for task in tasks])
    return f"Todo list created:\n{formatted_tasks}"
