"""
Entry point for `python -m cswn_toolkit` and the `cswn-toolkit` console script.
"""

import sys


def main():
    """Launch the CSWN Net Control Toolkit GUI."""
    # Ensure a QApplication can be created (needed before any Qt import)
    from cswn_toolkit.app import main as _app_main
    _app_main()


if __name__ == "__main__":
    main()
