"""
Colorado Severe Weather Network — Net Control Toolkit
=====================================================

A PyQt6 desktop application for amateur radio net control operators
working with the Colorado Severe Weather Network (CSWN) and NWS Skywarn.

Features:
- Automated net script generation (fetches live NWS AFD & HWO data)
- Regional Weather Roundup (NWS Pueblo RWR) display
- Weather resource toolkit with links to SPC, NWS, radar & satellite
- Built-in web browser for dashboards (requires PyQt6-WebEngine)
- PDF export via pdflatex
- Session save/restore and auto-advance mode

Usage:
    # From command line:
    cswn-toolkit

    # Or from Python:
    from cswn_toolkit import main
    main()

Author:  Jon Poindexter W5ALC <Jon.W5ALC@gmail.com>
Website: https://cswn.net
"""

__version__ = "4.2.0"
__author__ = "Jon Poindexter W5ALC"
__email__ = "Jon.W5ALC@gmail.com"

from cswn_toolkit.__main__ import main

__all__ = ["main", "__version__"]
