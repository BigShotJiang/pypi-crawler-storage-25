#!/usr/bin/env python3
"""
Colorado Severe Weather Network — Net Control Toolkit
Cross-platform (Windows + Linux) edition
"""

import sys
import os
import json
import logging
import requests
import time
import webbrowser
import re
import shutil
import subprocess
import tempfile
import xml.etree.ElementTree as ET

from pathlib import Path
from io import BytesIO
from datetime import datetime
from typing import List, Dict, Optional, Any
from bs4 import BeautifulSoup
from PIL import Image, ImageQt

from PyQt6.QtWidgets import (
    QApplication, QWidget, QLabel, QLineEdit, QTextEdit, QVBoxLayout, QHBoxLayout,
    QPushButton, QFileDialog, QMessageBox, QSpinBox, QGroupBox, QScrollArea,
    QProgressBar, QSplitter, QFontDialog, QTabWidget,
    QFrame, QSizePolicy, QCheckBox, QComboBox, QDialog
)
from PyQt6.QtCore import Qt, QTimer, pyqtSignal, QThread, QUrl, QEventLoop, QMarginsF
from PyQt6.QtGui import QPageLayout, QPageSize
from PyQt6.QtGui import QFont, QPixmap, QKeySequence, QAction

try:
    from PyQt6.QtWebEngineWidgets import QWebEngineView
    from PyQt6.QtWebEngineCore import QWebEngineSettings
    from PyQt6.QtWebEngineCore import QWebEnginePage, QWebEngineProfile
    WEBENGINE_AVAILABLE = True
except ImportError as e:
    print(f"WebEngine not available: {e}")
    WEBENGINE_AVAILABLE = False

try:
    import pytz
    PYTZ_AVAILABLE = True
except ImportError:
    PYTZ_AVAILABLE = False

# ─────────────────────────────────────────────────────────────
# Platform detection
# ─────────────────────────────────────────────────────────────
IS_WINDOWS = sys.platform.startswith("win")
IS_LINUX   = sys.platform.startswith("linux")
IS_MAC     = sys.platform.startswith("darwin")

# Only set FONTCONFIG_PATH on Linux where it's meaningful
if IS_LINUX:
    os.environ.setdefault("FONTCONFIG_PATH", "/etc/fonts")

# ─────────────────────────────────────────────────────────────
# Asset resolution — finds images next to the script or in
# common install locations; returns None silently if missing.
# ─────────────────────────────────────────────────────────────
_SCRIPT_DIR = Path(__file__).resolve().parent

def find_asset(filename: str) -> Optional[Path]:
    candidates = [
        Config.CONFIG_DIR / filename,        # ← add this line first
        _SCRIPT_DIR / filename,
        _SCRIPT_DIR / "assets" / filename,
        Path.home() / "Public" / filename,
        Path.home() / "bin" / filename,
    ]
    for p in candidates:
        if p.exists():
            return p
    return None

# ─────────────────────────────────────────────────────────────
# Font helpers — pick the best available monospace / UI font
# ─────────────────────────────────────────────────────────────
def monospace_font(size: int = 12) -> QFont:
    if IS_WINDOWS:
        preferred = ["Consolas", "Courier New", "Lucida Console"]
    elif IS_LINUX:
        preferred = ["DejaVu Sans Mono", "Liberation Mono", "Courier New", "Monospace"]
    else:
        preferred = ["Menlo", "Monaco", "Courier New"]

    for name in preferred:
        f = QFont(name, size)
        if f.exactMatch():
            return f
    return QFont("Courier New", size)   # guaranteed fallback

# ─────────────────────────────────────────────────────────────
# Configuration
# ─────────────────────────────────────────────────────────────
class Config:
    APP_NAME     = "CSWN Net Control Toolkit"
    ORGANIZATION = "Colorado Severe Weather Network"
    APP_TITLE    = "Weather Outlook Net Toolkit"
    APP_AUTHOR   = "Jon Poindexter W5ALC"
    AUTHOR_EMAIL = "Jon.W5ALC@gmail.com"
    APP_VERSION  = "4.2"

    DEFAULT_CONFIG = {
        "theme": "light",
        "font_size": 18,
        "auto_refresh_mins": 2,
        "window_geometry": "1400x1000+50+50",
        "default_section": "",
        "compact_mode": False,
        "show_tooltips": True,
    }

    DEFAULT_CALLSIGN        = os.environ.get("NET_CONTROL_CALLSIGN", "NC2WX")
    DEFAULT_NAME            = os.environ.get("NET_CONTROL_NAME",     "Gary")
    DEFAULT_LOCATION        = os.environ.get("NET_CONTROL_LOCATION", "Pueblo West in Southeastern Colorado")
    DEFAULT_LOGGER_CALLSIGN = os.environ.get("LOGGER_CALLSIGN",      "W7JPJ")
    DEFAULT_LOGGER_NAME     = os.environ.get("LOGGER_NAME",          "John")
    DEFAULT_LOGGER_LOCATION = os.environ.get("LOGGER_LOCATION",      "Denver, CO")

    NET_DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"]
    NET_TIME = "13:00"

    # Cross-platform config directory
    if IS_WINDOWS:
        CONFIG_DIR = Path(os.environ.get("APPDATA", Path.home())) / "CSWN_Toolkit"
    else:
        CONFIG_DIR = Path.home() / ".colorado_swo"

    LOG_FILE   = CONFIG_DIR / "swo_net.log"
    CONFIG_FILE= CONFIG_DIR / "weather_toolkit_config.json"
    ERROR_LOG  = CONFIG_DIR / "weather_toolkit_error.log"

# ─────────────────────────────────────────────────────────────
# Resource links
# ─────────────────────────────────────────────────────────────
resources = {
    "Net Control Dashboards": {
        "41694 Dashboard": "https://hubnm.skyhublink.com/allmon3/",
        "46079 Dashboard": "https://kg0sky.duckdns.org/allmon2/link.php?nodes=46079",
        "Open YSF Dashboard": "http://ysfbridge.skyhublink.com/",
    },
    "Regional Weather Dashboards": {
        "SPC Convective Outlooks": "https://www.spc.noaa.gov/products/outlook/",
        "SPC Fire Weather": "https://www.spc.noaa.gov/products/fire_wx/overview.html",
        "WPC Excessive Rainfall Outlook": "https://www.wpc.ncep.noaa.gov/qpf/excessive_rainfall_outlook_ero.php",
        "Storm-SAFER Dashboard": "https://www.arcgis.com/apps/dashboards/110ee04d7328448986136cdfea58c5c8",
    },
    "Hazardous Weather Outlooks": {
        "Grand Junction HWO": "https://forecast.weather.gov/product.php?site=NWS&issuedby=GJT&product=HWO",
        "Boulder HWO":        "https://forecast.weather.gov/product.php?site=NWS&issuedby=BOU&product=HWO",
        "Goodland HWO":       "https://forecast.weather.gov/product.php?site=NWS&issuedby=GLD&product=HWO",
        "Pueblo HWO":         "https://forecast.weather.gov/product.php?site=NWS&issuedby=PUB&product=HWO",
        "Cheyenne HWO":       "https://forecast.weather.gov/product.php?site=NWS&issuedby=CYS&product=HWO",
        "North Platte HWO":   "https://forecast.weather.gov/product.php?site=NWS&issuedby=LBF&product=HWO",
        "Albuquerque HWO":    "https://forecast.weather.gov/product.php?site=NWS&issuedby=ABQ&product=HWO",
        "Salt Lake City HWO": "https://forecast.weather.gov/product.php?site=NWS&issuedby=SLC&product=HWO",
        "Riverton HWO":       "https://forecast.weather.gov/product.php?site=NWS&issuedby=RIW&product=HWO",
    },
    "Area Forecast Discussions": {
        "Grand Junction AFD": "https://forecast.weather.gov/product.php?site=GJT&product=AFD&issuedby=GJT",
        "Boulder AFD":        "https://forecast.weather.gov/product.php?site=BOU&product=AFD&issuedby=BOU",
        "Goodland AFD":       "https://forecast.weather.gov/product.php?site=GLD&product=AFD&issuedby=GLD",
        "Pueblo AFD":         "https://forecast.weather.gov/product.php?site=PUB&product=AFD&issuedby=PUB",
        "Cheyenne AFD":       "https://forecast.weather.gov/product.php?site=CYS&product=AFD&issuedby=CYS",
        "North Platte AFD":   "https://forecast.weather.gov/product.php?site=LBF&product=AFD&issuedby=LBF",
        "Albuquerque AFD":    "https://forecast.weather.gov/product.php?site=ABQ&product=AFD&issuedby=ABQ",
        "Salt Lake City AFD": "https://forecast.weather.gov/product.php?site=SLC&product=AFD&issuedby=SLC",
        "Riverton AFD":       "https://forecast.weather.gov/product.php?site=RIW&product=AFD&issuedby=RIW",
    },
    "NWS Office Information": {
        "Grand Junction NWS": "https://www.weather.gov/gjt",
        "Boulder NWS":        "https://www.weather.gov/bou",
        "Goodland NWS":       "https://www.weather.gov/gld",
        "Pueblo NWS":         "https://www.weather.gov/pub",
        "Cheyenne NWS":       "https://www.weather.gov/cys",
        "North Platte NWS":   "https://www.weather.gov/lbf",
        "Albuquerque NWS":    "https://www.weather.gov/abq",
        "Flagstaff NWS":      "https://www.weather.gov/fgz",
        "Salt Lake City NWS": "https://www.weather.gov/slc",
        "Dodge City NWS":     "https://www.weather.gov/ddc",
        "Amarillo NWS":       "https://www.weather.gov/ama",
        "Topeka NWS":         "https://www.weather.gov/top",
        "Las Vegas NWS":      "https://www.weather.gov/vef",
        "Phoenix NWS":        "https://www.weather.gov/psr",
        "Riverton NWS":       "https://www.weather.gov/riw",
    },
    "Radar and Satellite": {
        "NWS Enhanced Radar":   "https://radar.weather.gov/",
        "GOES SLIDER":          "https://rammb-slider.cira.colostate.edu/?sat=goes-16&sec=Colorado",
        "Ventusky Radar":       "https://www.ventusky.com/?p=38.9972;-105.5478;6&l=radar",
        "GOES Geocolor":        "https://cdn.star.nesdis.noaa.gov/GOES19/ABI/CONUS/GEOCOLOR/latest.jpg",
        "RadarScope Web":       "https://web.radarscope.app/",
        "Zoom Earth":           "https://zoom.earth/",
    },
    "Model and Forecast Tools": {
        "HRRR Model Viewer":          "https://rapidrefresh.noaa.gov/hrrr/HRRR/",
        "Tropical Tidbits Models":    "https://www.tropicaltidbits.com/analysis/models/",
        "Pivotal Weather Models":     "https://www.pivotalweather.com/model.php?m=nam",
        "WPC Excessive Rainfall":     "https://www.wpc.ncep.noaa.gov/qpf/excessive_rainfall_outlook_ero.php",
        "NDFD Graphical Forecast":    "https://digital.weather.gov/?zoom=6&lat=38.9972&lon=-105.5478&layers=F00BTTTFFTT&region=0&element=4",
        "College of DuPage Models":   "https://weather.cod.edu/forecast/",
    },
    "SPC and Severe Weather": {
        "SPC Convective Outlooks":        "https://www.spc.noaa.gov/products/outlook/",
        "SPC Mesoanalysis":               "https://www.spc.noaa.gov/exper/mesoanalysis/",
        "SPC Mesoscale Discussions":      "https://www.spc.noaa.gov/products/md/",
        "SPC Storm Reports":              "https://www.spc.noaa.gov/climo/reports/",
        "SPC Watches":                    "https://www.spc.noaa.gov/products/watch/",
        "SPC Hourly Mesoscale Analysis":  "https://www.spc.noaa.gov/exper/hourlymesoanalysis/",
    },
    "Skywarn and Amateur Radio": {
        "Skywarn Spotter's Field Guide":  "https://www.weather.gov/spotterguide/",
        "Skywarn National Page":          "https://www.weather.gov/skywarn/",
        "Colorado ARES":                  "https://www.coloradoares.org/",
        "SkyHubLink Website":             "https://skyhublink.com/",
        "SkyHubLink Live Audio":          "https://hose.brandmeister.network/?subscribe=310847",
        "Colorado Severe WX Hoseline":    "https://hose.brandmeister.network/?subscribe=31083",
        "WinLink Gateway Map":            "https://winlink.org/RMSChannels",
        "Broadcastify Weather Feeds":     "https://www.broadcastify.com/listen/feed/27239",
    },
    "Mesonets and Surface Observations": {
        "MesoWest":                     "https://mesowest.utah.edu/",
        "Weather Underground PWS":      "https://www.wunderground.com/wundermap",
        "Colorado Agricultural Met":    "https://coagmet.colostate.edu/",
        "Aviation Weather Center":      "https://aviationweather.gov/",
        "Tempest Weather Stations":     "https://tempestwx.com/map/",
    },
    "Fire, Flood, and Avalanche": {
        "NWS Fire Weather":             "https://www.weather.gov/fire/",
        "InciWeb Incident Information": "https://inciweb.nwcg.gov/",
        "USGS Colorado Stream Gauges":  "https://waterdata.usgs.gov/co/nwis/rt",
        "NWS River Forecasts":          "https://water.weather.gov/ahps2/index.php?wfo=pub",
        "Colorado Avalanche Info":      "https://avalanche.state.co.us/",
        "SNOTEL Sites":                 "https://www.nrcs.usda.gov/wps/portal/wcc/home/snowClimateMonitoring/snowpack/snowpackandprecipitation",
    },
    "Upper Air and Atmospheric Profiling": {
        "Radiosonde Data":          "https://weather.uwyo.edu/upperair/sounding.html",
        "SPC Composite Sounding":   "https://www.spc.noaa.gov/exper/soundings/",
        "Lightning Detection":      "https://www.lightningmaps.org/",
        "VAD Wind Profiles":        "https://weather.rap.ucar.edu/radar/",
    },
    "Training and Education": {
        "COMET MetEd Training":         "https://www.meted.ucar.edu/",
        "Jetstream Online School":      "https://www.weather.gov/jetstream/",
        "Warning Decision Training":    "https://www.wdtb.noaa.gov/",
        "Skywarn Online Training":      "https://learn.meted.ucar.edu/#/curricula/0302af65-dcad-4841-87a8-77014473fe29",
        "NWS Training Portal":          "https://training.weather.gov/",
    },
}

# ─────────────────────────────────────────────────────────────
# Themes
# ─────────────────────────────────────────────────────────────
themes = {
    "dark": {
        "bg": "#0f1923", "bg_secondary": "#162030",
        "fg": "#e8edf2", "fg_secondary": "#7a90a4",
        "accent": "#00c8e8", "accent_hover": "#00a8c8",
        "button_bg": "qlineargradient(x1:0,y1:0,x2:0,y2:1,stop:0 #1e3040,stop:1 #162030)",
        "button_hover": "qlineargradient(x1:0,y1:0,x2:0,y2:1,stop:0 #243848,stop:1 #1e3040)",
        "button_pressed": "qlineargradient(x1:0,y1:0,x2:0,y2:1,stop:0 #0f1923,stop:1 #162030)",
        "button_fg": "#00c8e8",
        "group_bg": "#162030", "group_border": "#1e4060",
        "entry_bg": "#0f1923", "entry_fg": "#e8edf2",
        "entry_border": "#2a4060", "entry_focus": "#00c8e8",
        "section_fg": "#00c8e8", "status_bg": "#0a1218", "status_fg": "#e8edf2",
        "warning": "#ff4d6a", "watch": "#ff9d3a", "advisory": "#ffd740",
        "success": "#3dd68c", "info": "#4da6ff", "shadow": "rgba(0,0,0,0.5)",
    },
    "light": {
        "bg": "#f0f4f8", "bg_secondary": "#ffffff",
        "fg": "#1a2332", "fg_secondary": "#556070",
        "accent": "#4361ee", "accent_hover": "#3451d1",
        "button_bg": "qlineargradient(x1:0,y1:0,x2:0,y2:1,stop:0 #ffffff,stop:1 #eaf0f6)",
        "button_hover": "qlineargradient(x1:0,y1:0,x2:0,y2:1,stop:0 #eaf0f6,stop:1 #d8e4f0)",
        "button_pressed": "qlineargradient(x1:0,y1:0,x2:0,y2:1,stop:0 #d8e4f0,stop:1 #c8d8e8)",
        "button_fg": "#1a2332",
        "group_bg": "#ffffff", "group_border": "#c8d8e8",
        "entry_bg": "#ffffff", "entry_fg": "#1a2332",
        "entry_border": "#b0c4d8", "entry_focus": "#4361ee",
        "section_fg": "#4361ee", "status_bg": "#e0e8f0", "status_fg": "#1a2332",
        "warning": "#e63357", "watch": "#f07020", "advisory": "#e8a000",
        "success": "#1a9e5c", "info": "#0080c8", "shadow": "rgba(0,0,0,0.08)",
    },
    "blue": {
        "bg": "#07111e", "bg_secondary": "#0d1f35",
        "fg": "#d0e8ff", "fg_secondary": "#7aa0c0",
        "accent": "#38b6ff", "accent_hover": "#18a0f0",
        "button_bg": "qlineargradient(x1:0,y1:0,x2:0,y2:1,stop:0 #153050,stop:1 #0d1f35)",
        "button_hover": "qlineargradient(x1:0,y1:0,x2:0,y2:1,stop:0 #1e4068,stop:1 #153050)",
        "button_pressed": "qlineargradient(x1:0,y1:0,x2:0,y2:1,stop:0 #07111e,stop:1 #0d1f35)",
        "button_fg": "#38b6ff",
        "group_bg": "#0d1f35", "group_border": "#1a3a60",
        "entry_bg": "#0a1828", "entry_fg": "#d0e8ff",
        "entry_border": "#1a3a60", "entry_focus": "#38b6ff",
        "section_fg": "#38b6ff", "status_bg": "#050e18", "status_fg": "#d0e8ff",
        "warning": "#ff3d5a", "watch": "#ff8c20", "advisory": "#ffd020",
        "success": "#30d890", "info": "#38b6ff", "shadow": "rgba(0,0,0,0.6)",
    },
}

# ─────────────────────────────────────────────────────────────
# Logging
# ─────────────────────────────────────────────────────────────
def setup_logging():
    Config.CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(levelname)s - %(message)s",
        handlers=[
            logging.FileHandler(Config.LOG_FILE, encoding="utf-8"),
            logging.StreamHandler(),
        ],
    )

def log_error(msg: str):
    logging.error(msg)

# ─────────────────────────────────────────────────────────────
# Time helpers
# ─────────────────────────────────────────────────────────────
def get_current_mountain_time() -> dict:
    try:
        if PYTZ_AVAILABLE:
            # pytz is already imported at module level; no need to re-import here.
            mt  = pytz.timezone("America/Denver")
            now = datetime.now(mt)
        else:
            # Fallback: use local time (acceptable if machine is set to MT)
            now = datetime.now()

        return {
            "full":     now.strftime("%Y-%m-%d %H:%M:%S MST"),
            "short":    now.strftime("%H:%M"),
            "date":     now.strftime("%A, %B %d, %Y"),
            "time":     now.strftime("%H:%M:%S"),
            "timezone": "MST",
            "day":      now.strftime("%A"),
            "day_short":now.strftime("%a"),
            "weekday":  now.weekday(),
            "month":    now.strftime("%B"),
            "month_short": now.strftime("%b"),
            "year":     now.strftime("%Y"),
            "hour":     now.strftime("%H"),
            "minute":   now.strftime("%M"),
            "second":   now.strftime("%S"),
            "datetime": now,
        }
    except Exception:
        now = datetime.now()
        return {
            "full":     now.strftime("%Y-%m-%d %H:%M:%S"),
            "short":    now.strftime("%H:%M"),
            "date":     now.strftime("%A, %B %d, %Y"),
            "time":     now.strftime("%H:%M:%S"),
            "timezone": "Local",
            "day":      now.strftime("%A"),
            "day_short":now.strftime("%a"),
            "weekday":  now.weekday(),
            "month":    now.strftime("%B"),
            "month_short": now.strftime("%b"),
            "year":     now.strftime("%Y"),
            "hour":     now.strftime("%H"),
            "minute":   now.strftime("%M"),
            "second":   now.strftime("%S"),
            "datetime": now,
        }

def is_net_day() -> bool:
    return get_current_mountain_time()["day"] in Config.NET_DAYS

# ─────────────────────────────────────────────────────────────
# pdflatex detection — cross-platform
# Searches PATH first, then common TeX Live and MiKTeX install
# locations on Windows.  TeX Live is recommended over MiKTeX on
# Windows because it installs completely up-front with no
# on-demand package downloads that can stall subprocess calls.
# ─────────────────────────────────────────────────────────────
def find_pdflatex() -> Optional[str]:
    """Return full path to pdflatex, or None if not installed."""
    # shutil.which checks PATH on both Windows and Linux
    path = shutil.which("pdflatex")
    if path:
        return path
    if IS_WINDOWS:
        extra = [
            # TeX Live (recommended — installs fully, no on-demand downloads)
            r"C:\texlive\2025\bin\windows\pdflatex.exe",
            r"C:\texlive\2024\bin\windows\pdflatex.exe",
            r"C:\texlive\2023\bin\windows\pdflatex.exe",
            r"C:\texlive\2023\bin\win32\pdflatex.exe",
            # Per-user TeX Live installs
            str(Path.home() / "texlive" / "2025" / "bin" / "windows" / "pdflatex.exe"),
            str(Path.home() / "texlive" / "2024" / "bin" / "windows" / "pdflatex.exe"),
            # MiKTeX (fickle — may stall on first run waiting for package downloads)
            r"C:\Program Files\MiKTeX\miktex\bin\x64\pdflatex.exe",
            r"C:\Program Files\MiKTeX 2.9\miktex\bin\x64\pdflatex.exe",
        ]
        for p in extra:
            if Path(p).exists():
                return p
    return None

PDFLATEX = find_pdflatex()   # None means LaTeX not available

# ─────────────────────────────────────────────────────────────
# fpdf2 detection — pure-Python PDF fallback (no LaTeX needed)
# Install: pip install fpdf2
# Used automatically when pdflatex is not found.
# ─────────────────────────────────────────────────────────────
try:
    from fpdf import FPDF, XPos, YPos
    FPDF2_AVAILABLE = True
except ImportError:
    FPDF2_AVAILABLE = False

# True if ANY PDF engine is available (LaTeX or QtWebEngine HTML fallback)
# fpdf2 is kept as an optional install but is no longer used for PDF rendering.
PDF_AVAILABLE = bool(PDFLATEX or WEBENGINE_AVAILABLE)

# ─────────────────────────────────────────────────────────────
# Widgets
# ─────────────────────────────────────────────────────────────
class TimeWidget(QLabel):
    def __init__(self):
        super().__init__()
        self.setStyleSheet(
            "QLabel { font-size: 18px; font-weight: bold; color: #2c3e50; padding: 5px; }"
        )
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._tick)
        self._timer.start(1000)
        self._tick()

    def _tick(self):
        try:
            t = get_current_mountain_time()
            self.setText(f"{t['full']} • {t['date']}")
        except Exception as e:
            self.setText(f"Time error: {e}")


class StatusBar(QFrame):
    def __init__(self):
        super().__init__()
        self.setFrameStyle(QFrame.Shape.StyledPanel)
        self.setMaximumHeight(35)
        lay = QHBoxLayout()
        lay.setContentsMargins(10, 5, 10, 5)
        self._icon  = QLabel("")
        self._icon.setFixedWidth(20)
        self._label = QLabel("Ready")
        self._prog  = QProgressBar()
        self._prog.setVisible(False)
        self._prog.setMaximumWidth(200)
        lay.addWidget(self._icon)
        lay.addWidget(self._label)
        lay.addStretch()
        lay.addWidget(self._prog)
        self.setLayout(lay)

    def show_message(self, msg: str, error: bool = False, progress: bool = False):
        self._label.setText(msg)
        if error:
            self.setStyleSheet("background:#ffebee;color:#c62828;border:1px solid #ef5350;")
            self._icon.setText("⚠️")
        else:
            self.setStyleSheet("background:#e8f5e8;color:#2e7d32;border:1px solid #66bb6a;")
            self._icon.setText("✅")
        self._prog.setVisible(progress)
        if not progress:
            QTimer.singleShot(5000, self.clear_message)

    def set_progress(self, value: int, maximum: int = 100):
        self._prog.setVisible(True)
        self._prog.setMaximum(maximum)
        self._prog.setValue(value)

    def clear_message(self):
        self._label.setText("Ready")
        self._icon.setText("")
        self._prog.setVisible(False)
        self.setStyleSheet("")


class AnimatedButton(QPushButton):
    def __init__(self, text, parent=None):
        super().__init__(text, parent)
        self.setMinimumHeight(40)
        self.setCursor(Qt.CursorShape.PointingHandCursor)


class ModernButton(QPushButton):
    def __init__(self, text, parent=None):
        super().__init__(text, parent)
        self.setMinimumHeight(40)
        self.setCursor(Qt.CursorShape.PointingHandCursor)

    def apply_style(self, theme):
        self.setStyleSheet(f"""
            QPushButton {{
                background: {theme['button_bg']};
                color: {theme['button_fg']};
                border: 2px solid {theme['group_border']};
                border-radius: 8px;
                padding: 8px 16px;
                font-weight: 500;
                font-size: 13px;
            }}
            QPushButton:hover {{
                background: {theme['button_hover']};
                border-color: {theme['accent']};
                color: {theme['accent']};
            }}
            QPushButton:pressed {{
                background: {theme['button_pressed']};
                border-color: {theme['accent_hover']};
            }}
        """)


class ModernGroupBox(QGroupBox):
    def apply_style(self, theme):
        self.setStyleSheet(f"""
            QGroupBox {{
                font-weight: 600;
                font-size: 14px;
                color: {theme['section_fg']};
                border: 2px solid {theme['group_border']};
                border-radius: 12px;
                margin-top: 1ex;
                padding-top: 10px;
                background: {theme['group_bg']};
            }}
            QGroupBox::title {{
                subcontrol-origin: margin;
                subcontrol-position: top left;
                padding: 0 8px;
                background: {theme['group_bg']};
                border-radius: 4px;
            }}
        """)

# ─────────────────────────────────────────────────────────────
# Popups
# ─────────────────────────────────────────────────────────────
class TextPopup(QDialog):
    def __init__(self, parent, url, title, typ, theme, font_size, parse_pre=False):
        super().__init__(parent)
        self.setWindowTitle(f"{typ} Viewer — {title}")
        self.setMinimumSize(1000, 700)
        self.setStyleSheet(f"""
            QDialog {{ background:{theme['bg']}; color:{theme['fg']}; }}
            QTextEdit {{
                background:{theme['entry_bg']}; color:{theme['entry_fg']};
                border:2px solid {theme['entry_border']}; border-radius:8px; padding:10px;
            }}
            QPushButton {{
                background:{theme['button_bg']}; color:{theme['button_fg']};
                border:2px solid {theme['group_border']}; border-radius:8px;
                padding:8px 16px; font-weight:500; margin:2px;
            }}
            QPushButton:hover {{ background:{theme['button_hover']}; border-color:{theme['accent']}; }}
            QLabel {{ color:{theme['accent']}; font-weight:600; padding:5px; }}
        """)
        lay = QVBoxLayout()
        self.status = QLabel(f"Loading {typ}…")
        lay.addWidget(self.status)
        self.text = QTextEdit()
        self.text.setReadOnly(True)
        self.text.setFont(monospace_font(font_size))
        lay.addWidget(self.text)
        ctrl = QHBoxLayout()
        b_copy = QPushButton("Copy All");  b_copy.clicked.connect(self._copy)
        b_save = QPushButton("Save As…"); b_save.clicked.connect(self._save)
        b_close= QPushButton("Close");    b_close.clicked.connect(self.close)
        ctrl.addWidget(b_copy); ctrl.addWidget(b_save)
        ctrl.addStretch();      ctrl.addWidget(b_close)
        lay.addLayout(ctrl)
        self.setLayout(lay)
        QTimer.singleShot(100, lambda: self._load(url, typ, parse_pre))

    def _load(self, url, typ, parse_pre):
        try:
            resp = requests.get(url, timeout=10)
            if parse_pre:
                soup = BeautifulSoup(resp.content, "html.parser")
                pre  = soup.find("pre")
                body = pre.text if pre else f"{typ} content not found."
            else:
                body = resp.text
        except Exception as e:
            body = f"Failed to retrieve {typ}:\n{e}"
            log_error(body)
        self.text.setPlainText(body)
        self.status.setText(f"✅ {typ} loaded")

    def _copy(self):
        QApplication.clipboard().setText(self.text.toPlainText())

    def _save(self):
        fname, _ = QFileDialog.getSaveFileName(self, "Save Text", "", "Text Files (*.txt)")
        if fname:
            try:
                with open(fname, "w", encoding="utf-8") as f:
                    f.write(self.text.toPlainText())
            except Exception as e:
                QMessageBox.warning(self, "Save Error", str(e))


class ImagePopup(QDialog):
    def __init__(self, parent, url, theme, font_size):
        super().__init__(parent)
        self.setWindowTitle("🛰️ GOES Satellite Snapshot")
        self.setMinimumSize(1200, 800)
        lay = QVBoxLayout()
        self.status = QLabel("Loading satellite image…")
        lay.addWidget(self.status)
        self.img_label = QLabel()
        self.img_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lay.addWidget(self.img_label, 1)
        b = QPushButton("Close"); b.clicked.connect(self.close)
        lay.addWidget(b)
        self.setLayout(lay)
        QTimer.singleShot(100, lambda: self._load(url))

    def _load(self, url):
        try:
            resp    = requests.get(url, timeout=15)
            img     = Image.open(BytesIO(resp.content))
            qt_img  = ImageQt.ImageQt(img)
            pix     = QPixmap.fromImage(qt_img)
            self.img_label.setPixmap(
                pix.scaled(1100, 600,
                           Qt.AspectRatioMode.KeepAspectRatio,
                           Qt.TransformationMode.SmoothTransformation)
            )
            self.status.setText("✅ Satellite image loaded")
        except Exception as e:
            log_error(f"Image load error: {e}")
            self.status.setText("❌ Failed to load satellite image")


class WebViewPopup(QDialog):
    def __init__(self, parent, url, title, theme, font_size):
        super().__init__(parent)
        self.setModal(False)
        self.setWindowFlags(
            Qt.WindowType.Window |
            Qt.WindowType.WindowCloseButtonHint |
            Qt.WindowType.WindowMinimizeButtonHint |
            Qt.WindowType.WindowMaximizeButtonHint
        )
        self.setWindowTitle(title)
        self.setMinimumSize(1200, 800)
        lay = QVBoxLayout()
        ctrl = QHBoxLayout()
        self.status = QLabel(f"Loading {title}…")
        ctrl.addWidget(self.status)
        b_back    = QPushButton("⬅ Back")
        b_fwd     = QPushButton("➡ Forward")
        b_reload  = QPushButton("Refresh")
        b_ext     = QPushButton("🌐 Open External")
        b_close   = QPushButton("Close")
        for w in (b_back, b_fwd, b_reload, b_ext, b_close):
            ctrl.addWidget(w)
        lay.addLayout(ctrl)
        # Explicitly set BOTH storage and cache paths so Chromium never falls
        # back to a system location it may not have write access to.
        # On Windows, omitting setCachePath causes:
        #   "Unable to move the cache: Access is denied (0x5)"
        # because QtWebEngine tries a default path under the Qt build tree.
        _profile_path = Config.CONFIG_DIR / "webprofile"
        _cache_path   = Config.CONFIG_DIR / "webcache"
        _profile_path.mkdir(parents=True, exist_ok=True)
        _cache_path.mkdir(parents=True, exist_ok=True)
        self._profile = QWebEngineProfile("CSWN_sessions", self)
        self._profile.setPersistentStoragePath(str(_profile_path))
        self._profile.setCachePath(str(_cache_path))
        self._profile.setPersistentCookiesPolicy(
            QWebEngineProfile.PersistentCookiesPolicy.AllowPersistentCookies
        )
        self._page = QWebEnginePage(self._profile, self)
        self.web = QWebEngineView()
        self.web.setPage(self._page)
        self.web.setUrl(QUrl(url))
        s = self.web.settings()
        s.setAttribute(QWebEngineSettings.WebAttribute.JavascriptEnabled, True)
        s.setAttribute(QWebEngineSettings.WebAttribute.PluginsEnabled, True)
        s.setAttribute(QWebEngineSettings.WebAttribute.LocalContentCanAccessRemoteUrls, True)
        self.web.loadStarted.connect(lambda: self.status.setText("Loading…"))
        self.web.loadFinished.connect(
            lambda ok: self.status.setText("✅ Loaded" if ok else "❌ Failed"))
        self.web.loadProgress.connect(lambda p: self.status.setText(f"Loading… {p}%"))
        b_back.clicked.connect(self.web.back)
        b_fwd.clicked.connect(self.web.forward)
        b_reload.clicked.connect(self.web.reload)
        b_ext.clicked.connect(lambda: webbrowser.open(url))
        b_close.clicked.connect(self.close)
        lay.addWidget(self.web, 1)
        self.setLayout(lay)

# ─────────────────────────────────────────────────────────────
# NWS data classes
# ─────────────────────────────────────────────────────────────
class WeatherForecastTrimmer:
    def _trim(self, text, start_markers, end_triggers):
        if not text or not text.strip():
            return ""
        lines = text.split("\n")
        start_idx, end_idx = 0, len(lines)
        for i, line in enumerate(lines):
            lu = line.strip().upper()
            if any(m in lu for m in start_markers):
                start_idx = i; break
        for i in range(len(lines)-1, start_idx, -1):
            ln = lines[i].strip()
            if ln == "$" or ln.startswith("&&") or any(t in ln.upper() for t in end_triggers):
                end_idx = i; break
            if ln:
                end_idx = i+1; break
        result = lines[start_idx:end_idx]
        while result and not result[0].strip():  result.pop(0)
        while result and not result[-1].strip(): result.pop()
        return "\n".join(result).strip()

    def trim_hwo(self, text):
        return self._trim(text,
            ["THIS HAZARDOUS WEATHER OUTLOOK","HAZARDOUS WEATHER OUTLOOK IS FOR",".DAY ONE",".DAYS TWO THROUGH SEVEN"],
            ["SPOTTER"])

    def remove_between(self, text, start, end):
        pattern = re.escape(start)+".*?"+re.escape(end)
        result  = re.sub(pattern, "", text, flags=re.DOTALL)
        return re.sub(r"\n\s*\n", "\n\n", result).strip()

    def extract_key_messages(self, text):
        if not text:
            return "[Key messages unavailable]"
        lines = text.split("\n")
        in_section, result = False, []
        for line in lines:
            if re.match(r"^\s*\.KEY MESSAGES", line, re.IGNORECASE):
                in_section = True; result.append(line); continue
            if in_section:
                if re.match(r"^\s*\.[A-Z]", line) or line.strip() in ("&&","$"):
                    break
                result.append(line)
        if not result:
            return "[No key messages found in today's AFD]"
        while result and not result[-1].strip(): result.pop()
        return "\n".join(result).strip()

    def detect_discontinued(self, text, wfo_code=""):
        if not text or not text.strip():
            return self._discontinued_notice(wfo_code)
        valid = [".DAY ONE","HAZARDOUS WEATHER OUTLOOK IS FOR",
                 "THIS HAZARDOUS WEATHER OUTLOOK",".DAYS TWO THROUGH SEVEN"]
        if any(m in text.upper() for m in valid):
            return None
        return self._discontinued_notice(wfo_code)

    def _discontinued_notice(self, wfo_code):
        note = "Unfortunately, this text HWO has been discontinued by NWS."
        if wfo_code:
            note += f"\nPlease visit the Graphical HWO at: https://www.weather.gov/erh/ghwo?wfo={wfo_code.lower()}"
        return note


class NWSTextFetcher:
    BASE = "https://forecast.weather.gov/product.php"
    def __init__(self):
        self.session = requests.Session()
        self.session.headers["User-Agent"] = "CSWN-Net-Toolkit/4.2 Educational"

    def fetch_text_product(self, wfo, product_code):
        try:
            resp = self.session.get(self.BASE,
                params={"issuedby": wfo.upper(), "product": product_code.upper(),
                        "site": wfo.lower(), "format": "txt"},
                timeout=10)
            resp.raise_for_status()
            soup = BeautifulSoup(resp.text, "html.parser")
            pre  = soup.find("pre")
            if pre:
                return pre.get_text()
            div = soup.find("div", {"class":"glossaryProduct"}) or soup.find("div", {"id":"textproduct"})
            if div:
                return div.get_text()
            return re.sub(r"\n\s*\n", "\n\n", re.sub("<.*?>","",resp.text)).strip()
        except Exception as e:
            logging.warning(f"Fetch {product_code}/{wfo}: {e}")
            return None

    def fetch_afd(self, wfo): return self.fetch_text_product(wfo, "AFD")
    def fetch_hwo(self, wfo): return self.fetch_text_product(wfo, "HWO")


class RWRFetcher:
    BASE = "https://forecast.weather.gov/product.php"
    def __init__(self):
        self.session = requests.Session()
        self.session.headers["User-Agent"] = "CSWN-Net-Toolkit/4.2 Educational"

    def fetch_rwr_from_pub(self):
        try:
            resp = self.session.get(self.BASE,
                params={"site":"PUB","issuedby":"CO","product":"RWR",
                        "format":"txt","version":"1","glossary":"0"},
                timeout=10)
            resp.raise_for_status()
            soup = BeautifulSoup(resp.text, "html.parser")
            pre  = soup.find("pre")
            if pre:
                text = pre.get_text().strip()
                if "None issued" not in text:
                    return text
            return None
        except Exception as e:
            logging.warning(f"RWR fetch: {e}")
            return None

    def get_rwr_html(self, theme=None, font_size=18):
        return RWRHTMLFormatter(theme=theme, font_size=font_size).format_rwr_to_html(
            self.fetch_rwr_from_pub())

    def get_rwr_with_fallback(self):
        text = self.fetch_rwr_from_pub()
        return text or (
            "No Regional Weather Roundup currently issued by NWS Pueblo\n\n"
            "Visit: https://forecast.weather.gov/product.php?site=PUB&issuedby=CO&product=RWR"
        )


class RWRHTMLFormatter:
    FALLBACK = {
        "bg":"#0f1923","bg_secondary":"#162030","fg":"#e8edf2",
        "fg_secondary":"#7a90a4","accent":"#00c8e8","accent_hover":"#008aaa",
        "group_border":"#1e4060","entry_border":"#2a4060",
        "warning":"#ff4d6a","watch":"#ff9d3a","success":"#3dd68c","info":"#4da6ff",
    }

    def __init__(self, theme=None, font_size=18):
        t = theme or self.FALLBACK
        g = lambda k: t.get(k, self.FALLBACK.get(k,"#888"))
        fs, fss = font_size, max(font_size-3,10)
        self.css = f"""<style>
        body{{font-family:monospace;background:{g('bg')};color:{g('fg')};
              margin:0;padding:18px;font-size:{fs}px;line-height:1.55}}
        .hdr{{text-align:center;margin:0 auto 20px;max-width:960px;padding:16px;
              background:{g('bg_secondary')};border-radius:8px;
              border-left:4px solid {g('accent')};border:1px solid {g('group_border')}}}
        .htitle{{font-size:{fs+6}px;font-weight:bold;color:{g('accent')};
                 text-transform:uppercase;letter-spacing:2px}}
        .hsub{{font-size:{fss}px;color:{g('fg_secondary')}}}
        .sec{{margin:14px auto;max-width:960px;background:{g('bg_secondary')};
              border-radius:8px;padding:14px 16px;
              border-left:4px solid {g('accent')};border:1px solid {g('group_border')}}}
        .sectitle{{font-size:{fs+2}px;font-weight:bold;color:{g('accent')};
                   text-transform:uppercase;letter-spacing:2px;margin-bottom:10px}}
        table{{width:100%;border-collapse:collapse;font-size:{fs}px}}
        th{{background:{g('bg')};color:{g('accent')};padding:9px 10px;text-align:left;
            font-size:{max(fs-2,10)}px;text-transform:uppercase;letter-spacing:1px;
            border-bottom:2px solid {g('accent_hover')}}}
        td{{padding:8px 10px;border-bottom:1px solid {g('entry_border')};color:{g('fg')}}}
        tr:last-child td{{border-bottom:none}}
        .city{{font-weight:bold}} .cond{{color:{g('info')}}}
        .th{{color:{g('warning')};font-weight:bold}} .tl{{color:{g('accent')};font-weight:bold}}
        .wind{{color:{g('watch')}}} .pres{{color:{g('fg_secondary')}}}
        .rmk{{color:{g('success')};font-style:italic}}
        .na{{color:{g('fg_secondary')};opacity:.6;font-style:italic}}
        .foot{{margin:18px auto 0;max-width:960px;padding:11px;
               background:{g('bg_secondary')};border:1px solid {g('group_border')};
               border-radius:8px;text-align:center;font-size:{max(fs-4,9)}px;color:{g('fg_secondary')}}}
        </style>"""

    def _timestamp(self, text):
        for pat in [
            r"(\d{3,4} [AP]M [A-Z]{3} [A-Z]{3} [A-Z]{3} \d{1,2} \d{4})",
            r"(\d{3,4} [AP]M [A-Z]{3}.*?\d{4})",
        ]:
            m = re.search(pat, text, re.IGNORECASE)
            if m:
                ts = re.sub(r"\s+", " ", m.group(1)).strip()
                if len(ts) > 15 and ("AM" in ts or "PM" in ts):
                    return ts
        return "Time not available"

    def format_rwr_to_html(self, rwr_text):
        if not rwr_text:
            return f"<html><body{self.css}<p>No RWR data available.</p></body></html>"
        ts       = self._timestamp(rwr_text)
        sections = self._parse_sections(rwr_text)
        rows     = ""
        for title, cities in sections.items():
            tbody = "".join(self._city_row(c) for c in cities)
            rows += f"""<div class="sec"><div class="sectitle">{title}</div>
            <table><thead><tr>
            <th>City</th><th>Conditions</th><th>Temp</th><th>DP</th>
            <th>RH</th><th>Wind</th><th>Pressure</th><th>Remarks</th>
            </tr></thead><tbody>{tbody}</tbody></table></div>"""
        return f"""<!DOCTYPE html><html><head><meta charset="UTF-8">{self.css}</head><body>
        <div class="hdr"><div class="htitle">Colorado Weather Roundup</div>
        <div class="hsub">National Weather Service Pueblo CO</div>
        <div class="hsub">{ts}</div></div>
        {rows}
        <div class="foot">
        <strong>Note:</strong> "FAIR" = few/no clouds below 12,000 ft, no significant weather.<br>
        Data: National Weather Service</div></body></html>"""

    def _parse_sections(self, text):
        sections, current = {}, None
        for line in text.split("\n"):
            line = line.strip()
            if line.startswith("...") and line.endswith("..."):
                current = line.strip("."); sections[current] = []; continue
            if current and len(line) > 50 and not line.startswith("COZ"):
                d = self._parse_line(line)
                if d: sections[current].append(d)
        return sections

    def _parse_line(self, line):
        if len(line) < 40 or line.startswith("CITY") or not line.strip():
            return None
        try:
            city = line[0:15].strip()
            if not city: return None
            if "NOT AVBL" in line:
                return {k: ("NOT AVBL" if k == "conditions" else "N/A") for k in
                        ["city","conditions","temp","dp","rh","wind","pressure","remarks"]}
            cond = line[15:25].strip() or "N/A"
            return {"city":city,"conditions":cond,
                    "temp":line[25:29].strip() or "N/A",
                    "dp":  line[29:33].strip() or "N/A",
                    "rh":  line[33:36].strip() or "N/A",
                    "wind":line[36:46].strip() or "N/A",
                    "pressure":line[46:53].strip() or "N/A",
                    "remarks": line[53:].strip() if len(line)>53 else ""}
        except Exception:
            return None

    def _city_row(self, d):
        na  = ' class="na"' if d["conditions"] == "NOT AVBL" else ""
        try:   tc = "th" if int(d["temp"]) > 85 else "tl"
        except Exception: tc = "tl"
        return (f'<tr{na}>'
                f'<td class="city">{d["city"]}</td>'
                f'<td class="cond">{d["conditions"]}</td>'
                f'<td class="{tc}">{d["temp"]}</td>'
                f'<td>{d["dp"]}</td>'
                f'<td>{d["rh"]}%</td>'
                f'<td class="wind">{d["wind"]}</td>'
                f'<td class="pres">{d["pressure"]}</td>'
                f'<td class="rmk">{d["remarks"]}</td></tr>')


class AlertFetcher(QThread):
    alerts_loaded   = pyqtSignal(str)
    progress_updated= pyqtSignal(int)

    def __init__(self, url, parse_atom=True, parent=None):
        super().__init__(parent)
        self.url, self.parse_atom = url, parse_atom

    def run(self):
        text = ""
        try:
            self.progress_updated.emit(25)
            resp = requests.get(self.url, timeout=12)
            self.progress_updated.emit(50)
            if self.parse_atom:
                root = ET.fromstring(resp.content)
                ns   = "{http://www.w3.org/2005/Atom}"
                cap  = "{urn:oasis:names:tc:emergency:cap:1.1}"
                for entry in root.findall(f"{ns}entry"):
                    title   = entry.find(f"{ns}title")
                    summary = entry.find(f"{ns}summary")
                    link    = entry.find(f"{ns}link")
                    area    = entry.find(f"{cap}areaDesc")
                    counties= area.text if area is not None and area.text else ""
                    text += (f"🚨 {title.text if title is not None else 'No Title'}\n"
                             f"📝 {summary.text if summary is not None else 'No Summary'}\n"
                             f"🗺️ {counties}\n"
                             f"🔗 {link.attrib.get('href','') if link is not None else ''}\n\n")
            else:
                text = resp.text
            self.progress_updated.emit(100)
        except Exception as e:
            text = f"❌ Failed to fetch alerts:\n{e}"
        self.alerts_loaded.emit(text)


# ─────────────────────────────────────────────────────────────
# Net data
# ─────────────────────────────────────────────────────────────
class NetData:
    def __init__(self):
        self.callsign = self.name = self.location = ""
        self.logger_callsign = self.logger_name = self.logger_location = ""
        self.check_ins: List[str] = []


# ─────────────────────────────────────────────────────────────
# Main window
# ─────────────────────────────────────────────────────────────
class SevereWeatherWindow(QWidget):
    APP_NAME = "Colorado Severe Weather Outlook Net Controller"
    config   = {
        "theme": "light", "font_size": 18,
        "auto_refresh_mins": 2, "compact_mode": False,
    }

    def __init__(self):
        super().__init__()
        self.setWindowTitle(Config.APP_NAME)
        self.setMinimumSize(1200, 800)
        self.resize(1400, 900)

        self.net_data        = NetData()
        self.sections: List  = []
        self.section_idx     = 0
        self._cfg = self._read_config_file()
        self.current_theme   = themes["light"]
        self.theme_dark      = False
        self.auto_advance    = False
        self.auto_advance_delay = 30

        setup_logging()
        logging.info("Application started")

        self._init_ui()
        self._load_settings()
        self._apply_theme()

        self._autosave_timer = QTimer(self)
        self._autosave_timer.timeout.connect(self._auto_save)
        self._autosave_timer.start(60_000)

        # Persistent 30-second timer for net status — more robust than
        # QTimer.singleShot inside _update_net_status which silently stops
        # on any exception.
        self._net_status_timer = QTimer(self)
        self._net_status_timer.timeout.connect(self._update_net_status)
        self._net_status_timer.start(30_000)


    def _read_config_file(self) -> dict:
        try:
            if Config.CONFIG_FILE.exists():
                return json.loads(Config.CONFIG_FILE.read_text(encoding="utf-8"))
        except Exception as e:
            logging.warning(f"Could not read config file: {e}")
        return {}

    # ── UI construction ──────────────────────────────────────
    def _init_ui(self):
        main = QVBoxLayout()
        main.setContentsMargins(10, 10, 10, 10)
        main.setSpacing(10)
        main.addWidget(self._build_header())

        self.tab_widget = QTabWidget()
        self.tab_widget.setTabPosition(QTabWidget.TabPosition.North)
        self._init_setup_tab()
        self._init_combined_tab()
        main.addWidget(self.tab_widget)

        self.status_bar = StatusBar()
        main.addWidget(self.status_bar)
        self.setLayout(main)
        self._setup_shortcuts()
        self.showMaximized()

    def _build_header(self):
        header = QFrame()
        header.setFrameStyle(QFrame.Shape.StyledPanel)
        header.setMaximumHeight(90)
        lay = QHBoxLayout()
        lay.setContentsMargins(15, 10, 15, 10)

        # Logo — cross-platform asset lookup, silent fallback
        logo = QLabel()
        logo_path = find_asset("Skywarn-cyan.png")
        if logo_path:
            pix = QPixmap(str(logo_path))
            logo.setPixmap(pix.scaled(70, 70,
                Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation))
        else:
            logo.setText("📡")
            logo.setStyleSheet("font-size:40px;")

        title_lay = QVBoxLayout()
        title_lay.setSpacing(2)
        t = QLabel("Colorado Severe Weather Network")
        t.setStyleSheet("font-size:28px;font-weight:bold;color:#2c3e50;")
        s = QLabel("Daily Weather Outlook Net • SkyHubLink System • Net Control App")
        s.setStyleSheet("font-size:14px;color:#7f8c8d;font-style:italic;")
        title_lay.addWidget(t); title_lay.addWidget(s)

        self.time_widget = TimeWidget()
        self.net_status  = QLabel("⚪ Checking net status…")
        self.net_status.setStyleSheet("color:#95a5a6;font-weight:bold;font-size:14px;")
        # Defer the blocking HTTP call until after the window is painted.
        # Previously _update_net_status() (which calls _fetch_live_net_status())
        # was called directly from _build_header → __init__, freezing the window
        # before it ever appeared on screen.
        QTimer.singleShot(0, self._update_net_status)

        lay.addWidget(logo)
        lay.addLayout(title_lay)
        lay.addStretch()
        lay.addWidget(self.time_widget)
        lay.addWidget(self.net_status)
        header.setLayout(lay)
        return header

    def _fetch_live_net_status(self):
        try:
            resp  = requests.get("https://www.netlogger.org/", timeout=10)
            resp.raise_for_status()
            cells = [c.get_text(strip=True).lower()
                     for c in BeautifulSoup(resp.text,"html.parser").find_all("td")]
            return "active" if any("skyhublink weather outlook net" in c for c in cells) else "not_found"
        except Exception:
            return "error"

    def _update_net_status(self):
        state = self._fetch_live_net_status()
        ti    = get_current_mountain_time()
        if is_net_day():
            if state == "active":
                self.net_status.setText("🔴 NET ACTIVE (via NetLogger)")
                self.net_status.setStyleSheet("color:#e74c3c;font-weight:bold;font-size:14px;")
            elif state == "not_found":
                h = int(ti["hour"])
                if 12 <= h < 13:
                    self.net_status.setText("🟡 NET SOON")
                    self.net_status.setStyleSheet("color:#f39c12;font-weight:bold;font-size:14px;")
                else:
                    self.net_status.setText("🟢 NET DAY")
                    self.net_status.setStyleSheet("color:#27ae60;font-weight:bold;font-size:14px;")
            else:
                self.net_status.setText("⚪ NET STATUS UNKNOWN")
                self.net_status.setStyleSheet("color:#95a5a6;font-weight:bold;font-size:14px;")
        else:
            self.net_status.setText("⚪ OFF DAY")
            self.net_status.setStyleSheet("color:#95a5a6;font-weight:bold;font-size:14px;")
        # Note: rescheduling is handled by a persistent QTimer started in __init__,
        # not here, so an exception mid-method can't silently kill status updates.

    # ── Setup tab ─────────────────────────────────────────────
    def _init_setup_tab(self):
        self.setup_tab = QWidget()
        outer = QHBoxLayout()
        outer.setSpacing(12); outer.setContentsMargins(10,10,10,10)

        self.net_info_display = QTextEdit()

        # ── LEFT: RWR ──
        left = QVBoxLayout(); left.setSpacing(12)
        cg = QGroupBox("Regional Weather Roundup — NWS Pueblo")
        cl = QVBoxLayout(); cl.setSpacing(6)
        self.conditions_display = QTextEdit()
        self.conditions_display.setReadOnly(True)
        self.conditions_display.setPlainText("Loading Regional Weather Roundup…")
        rb = AnimatedButton("⟳  Refresh Weather Data")
        rb.clicked.connect(self._refresh_weather)
        cl.addWidget(self.conditions_display, stretch=1)
        cl.addWidget(rb)
        cg.setLayout(cl)

        al = QHBoxLayout(); al.setSpacing(12)
        load_btn = AnimatedButton("Load Session"); load_btn.clicked.connect(self._load_session)
        save_btn = AnimatedButton("Save Session"); save_btn.clicked.connect(self._save_session)
        self.start_btn = AnimatedButton("Generate Net Script")
        self.start_btn.setMinimumHeight(50)
        self.start_btn.setStyleSheet("font-size:16px;font-weight:bold;background:#00f6ff;color:#001817;")
        self.start_btn.clicked.connect(self._start_net_script)
        al.addWidget(load_btn); al.addWidget(save_btn)
        al.addStretch();        al.addWidget(self.start_btn)
        left.addWidget(cg, stretch=1); left.addLayout(al)

        # ── RIGHT: Settings ──
        sg = QGroupBox("⚙️ Settings")
        sl = QVBoxLayout(); sl.setSpacing(10); sl.setContentsMargins(12,16,12,12)

        def row(label, widget):
            r = QHBoxLayout()
            lb = QLabel(label); lb.setFixedWidth(90)
            r.addWidget(lb); r.addWidget(widget); return r

        for lbl_text, attr, default in [
            ("Net Control","",""),
            ("Callsign:","default_callsign",Config.DEFAULT_CALLSIGN),
            ("Name:","default_name",Config.DEFAULT_NAME),
            ("Location:","default_location",Config.DEFAULT_LOCATION),
            ("Logger","",""),
            ("Callsign:","default_logger_callsign",Config.DEFAULT_LOGGER_CALLSIGN),
            ("Name:","default_logger_name",Config.DEFAULT_LOGGER_NAME),
            ("Location:","default_logger_location",Config.DEFAULT_LOGGER_LOCATION),
        ]:
            if not attr:
                lbl = QLabel(lbl_text)
                lbl.setStyleSheet("font-weight:bold;margin-top:8px;")
                sl.addWidget(lbl)
            else:
                w = QLineEdit(default)
                setattr(self, attr, w)
                sl.addLayout(row(lbl_text, w))

        lbl_ap = QLabel("Appearance"); lbl_ap.setStyleSheet("font-weight:bold;margin-top:4px;")
        sl.addWidget(lbl_ap)
        self.theme_combo = QComboBox()
        self.theme_combo.addItems(["Light","Dark","Blue"])
        self.theme_combo.setCurrentText("Light")
        self.theme_combo.currentTextChanged.connect(self._change_theme)
        sl.addLayout(row("Theme:", self.theme_combo))
        fb = QPushButton("Select Font"); fb.clicked.connect(self._select_font)
        sl.addLayout(row("Font:", fb))

        lbl_beh = QLabel("Behaviour"); lbl_beh.setStyleSheet("font-weight:bold;margin-top:8px;")
        sl.addWidget(lbl_beh)
        self.auto_save_cb    = QCheckBox("Auto-save session on exit"); self.auto_save_cb.setChecked(True)
        self.confirm_exit_cb = QCheckBox("Confirm before exiting");    self.confirm_exit_cb.setChecked(True)
        sl.addWidget(self.auto_save_cb); sl.addWidget(self.confirm_exit_cb)
        sl.addStretch()

        br = QHBoxLayout()
        rsb = AnimatedButton("Reset Defaults"); rsb.clicked.connect(self._reset_settings)
        svb = AnimatedButton("Save Settings");  svb.clicked.connect(self._save_settings_to_disk)
        br.addWidget(rsb); br.addStretch(); br.addWidget(svb)
        sl.addLayout(br)
        sg.setLayout(sl)
        sg.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Expanding)
        sg.setFixedWidth(450)

        outer.addLayout(left, stretch=1)
        outer.addWidget(sg)
        self.setup_tab.setLayout(outer)
        self.tab_widget.addTab(self.setup_tab, "Weather | Setup")
        QTimer.singleShot(1000, self._refresh_weather)

    # ── Combined Script + Toolkit tab ─────────────────────────
    def _init_combined_tab(self):
        combined = QWidget()
        self.tab_widget.addTab(combined, "Script | Toolkit")
        outer = QVBoxLayout(combined); outer.setContentsMargins(0,0,0,0)
        splitter = QSplitter(Qt.Orientation.Horizontal)
        outer.addWidget(splitter)

        # LEFT — Script
        sw  = QWidget(); sl  = QVBoxLayout(sw); sl.setSpacing(15)
        cpg = QGroupBox("Script Control Panel"); cpl = QHBoxLayout()
        self.prev_btn = AnimatedButton("⬅️ Previous"); self.prev_btn.clicked.connect(self._prev_section); self.prev_btn.setEnabled(False)
        self.next_btn = AnimatedButton("Next ➡️");    self.next_btn.clicked.connect(self._next_section); self.next_btn.setEnabled(False)
        self.section_label = QLabel("Section 1 of 1")
        self.section_label.setStyleSheet("font-size:16px;font-weight:bold;")
        self.auto_advance_cb = QCheckBox("Auto-advance"); self.auto_advance_cb.toggled.connect(self._toggle_auto_advance)
        self.delay_spinbox   = QSpinBox(); self.delay_spinbox.setRange(10,300); self.delay_spinbox.setValue(30); self.delay_spinbox.setSuffix(" sec")
        self.delay_spinbox.valueChanged.connect(self._update_delay)
        for w in (self.prev_btn, self.next_btn, self.section_label): cpl.addWidget(w)
        cpl.addStretch()
        cpl.addWidget(QLabel("Auto-advance:")); cpl.addWidget(self.auto_advance_cb); cpl.addWidget(self.delay_spinbox)
        cpg.setLayout(cpl)

        sg  = QGroupBox("Net Script"); sgl = QVBoxLayout()
        self.script_display = QTextEdit()
        self.script_display.setFont(monospace_font(18))
        self.script_display.setReadOnly(True)
        self.script_display.setPlaceholderText("Generate the net script from the Setup tab to begin…")
        sgl.addWidget(self.script_display); sg.setLayout(sgl)

        sa = QHBoxLayout()
        self.edit_toggle = AnimatedButton("Edit Section"); self.edit_toggle.setCheckable(True); self.edit_toggle.toggled.connect(self._toggle_editing)
        for label, slot in [("Copy Section",self._copy_section),("Copy All",self._copy_all),("Export Script",self._export_script),("Print",self._print_script)]:
            b = AnimatedButton(label); b.clicked.connect(slot); sa.addWidget(b)
        sa.insertWidget(0, self.edit_toggle); sa.addStretch()

        sl.addWidget(cpg); sl.addWidget(sg); sl.addLayout(sa)
        self._auto_advance_timer = QTimer(self); self._auto_advance_timer.timeout.connect(self._next_section)

        # RIGHT — Toolkit
        tw = QWidget(); tl = QVBoxLayout(tw); tl.setSpacing(15)
        hdr = QLabel(self.APP_NAME)
        hdr.setAlignment(Qt.AlignmentFlag.AlignCenter)
        hdr.setStyleSheet("font-size:20px;font-weight:bold;padding:20px;")
        hdr.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)
        tl.addWidget(hdr)
        self.progress_bar = QProgressBar(); self.progress_bar.setVisible(False)
        tl.addWidget(self.progress_bar)

        tk_split = QSplitter(Qt.Orientation.Horizontal)
        lp = QWidget(); ll = QVBoxLayout(lp)
        ll.addWidget(QLabel("Weather Resources"))
        self.section_buttons = {}
        for name in resources:
            btn = ModernButton(name)
            btn.clicked.connect(lambda _, n=name: self._load_section(n))
            self.section_buttons[name] = btn; ll.addWidget(btn)
        ll.addStretch()

        self.right_panel   = QScrollArea(); self.right_panel.setWidgetResizable(True)
        self.right_content = QWidget();     self.right_layout = QVBoxLayout(self.right_content)
        self.right_panel.setWidget(self.right_content)
        welcome = QLabel("Select a category to begin")
        welcome.setAlignment(Qt.AlignmentFlag.AlignCenter)
        welcome.setStyleSheet("font-size:18px;padding:50px;color:#888;")
        self.right_layout.addWidget(welcome); self.right_layout.addStretch()

        tk_split.addWidget(lp); tk_split.addWidget(self.right_panel); tk_split.setSizes([200,500])
        tl.addWidget(tk_split)

        splitter.addWidget(sw); splitter.addWidget(tw)
        splitter.setSizes([700,700]); splitter.setHandleWidth(4)

    # ── Toolkit helpers ──────────────────────────────────────
    def _load_section(self, name):
        self.right_content = QWidget(); self.right_layout = QVBoxLayout(self.right_content)
        self.right_layout.setAlignment(Qt.AlignmentFlag.AlignTop)
        self.right_panel.setWidget(self.right_content)
        if name not in resources: return
        hdr = QLabel(name)
        hdr.setStyleSheet(f"font-size:16px;font-weight:bold;padding:8px;color:{self.current_theme['accent']}")
        self.right_layout.addWidget(hdr)
        for link_name, url in resources[name].items():
            lg = ModernGroupBox(link_name); ll = QVBoxLayout()
            bl = QHBoxLayout()
            if any(x in url for x in ["HWO","AFD","product.php"]):
                vb = ModernButton("View Text")
                vb.clicked.connect(lambda _, u=url,n=link_name: self._show_text_popup(u,n,"NWS Text Product",True))
                bl.addWidget(vb)
            elif url.endswith(".jpg"):
                ib = ModernButton("View Image"); ib.clicked.connect(lambda _,u=url: self._show_image_popup(u)); bl.addWidget(ib)
            wb = ModernButton("View in App"); wb.clicked.connect(lambda _,u=url,n=link_name: self._show_web_popup(u,n)); bl.addWidget(wb)
            ll.addLayout(bl)
            ul = QLabel(f"🔗 {url}")
            ul.setStyleSheet(f"font-size:13px;padding:5px;font-family:monospace;color:{self.current_theme['accent']}")
            ul.setWordWrap(True); ll.addWidget(ul)
            lg.setLayout(ll); self.right_layout.addWidget(lg)
        self._apply_theme_to_section()

    def _apply_theme_to_section(self):
        t = self.current_theme
        for i in range(self.right_layout.count()):
            item = self.right_layout.itemAt(i)
            if item and item.widget() and isinstance(item.widget(), ModernGroupBox):
                item.widget().apply_style(t)
                for j in range(item.widget().layout().count()):
                    si = item.widget().layout().itemAt(j)
                    if si and hasattr(si, "count"):
                        for k in range(si.count()):
                            bi = si.itemAt(k)
                            if bi and isinstance(bi.widget(), ModernButton):
                                bi.widget().apply_style(t)

    def _show_web_popup(self, url, title):
        if not WEBENGINE_AVAILABLE:
            QMessageBox.information(self, "WebEngine Not Available",
                "PyQtWebEngine is not installed. Opening in external browser.\n\n"
                "Install with: pip install PyQtWebEngine")
            webbrowser.open(url); return
        WebViewPopup(self, url, title, self.current_theme, self.config["font_size"]).show()

    def _show_text_popup(self, url, title, typ, parse_pre=False):
        TextPopup(self, url, title, typ, self.current_theme, self.config["font_size"], parse_pre).show()

    def _show_image_popup(self, url):
        ImagePopup(self, url, self.current_theme, self.config["font_size"]).show()

    def _setup_shortcuts(self):
        for seq, slot in [("Ctrl+Right",self._next_section),("Ctrl+Left",self._prev_section),
                          ("Ctrl+S",self._save_session)]:
            a = QAction(self); a.setShortcut(QKeySequence(seq)); a.triggered.connect(slot); self.addAction(a)

    # ── Script generation ────────────────────────────────────
    def _start_net_script(self):
        self.net_data.callsign         = self.default_callsign.text().strip()
        self.net_data.name             = self.default_name.text().strip()
        self.net_data.location         = self.default_location.text().strip()
        self.net_data.logger_callsign  = self.default_logger_callsign.text().strip()
        self.net_data.logger_name      = self.default_logger_name.text().strip()
        self.net_data.logger_location  = self.default_logger_location.text().strip()
        self._generate_script()
        self.tab_widget.setCurrentIndex(1)
        self.section_idx = 0
        self._display_section()
        self.status_bar.show_message("Net script generated successfully!")

    def _generate_script(self):
        fetcher  = NWSTextFetcher()
        trimmer  = WeatherForecastTrimmer()
        nd       = self.net_data
        self.sections = []

        pre_opening = """\
NC: Please use a repeater with which you have a solid signal, since repeaters are usually much more \
reliable. If you have a hotspot, please use it ONLY as backup. Hotspots can be glitchy, which often \
results in frequent digital-side dropouts.

Timeouts are 3 minutes. Watch dashboards or select a countdown timer from your app store.

1235-1240...
1. Have Jon, Bryan or Bucky open SHL Dashboards (NC should also have them open):
   a. https://hubnm.skyhublink.com/allmon3/
   b. https://kg0sky.duckdns.org/allmon2/link.php?nodes=46079
   c. Open YSF Dashboard: http://ysfbridge.skyhublink.com/
2. In AllStar 485322 (Weather Hub): first DISCONNECT 289800, then CONNECT 41694.
3. IN 46079 CONNECT 41304 (WestCO N2KNK System, auto-disconnects at 1330.)

1240-45...
A. Logger or NC open Netlogger, promote the other. List NC and Logger callsigns.
B. Set "Net Official Status" for each and type same in "Remarks".
C. Logger, open Telegram CO Severe Weather Network chatroom. Under 'Check-ins' tab, paste "Net Open".
D. Run comms checks between NC and Logger, see that all dashboards light up.
   If not, contact Bucky @ 303-882-0095 or Jack @ 303-704-3290.

1250-1255... Announce:
"THE WEATHER OUTLOOK NET COVERING THE CENTRAL ROCKIES & HIGH PLAINS REGION WILL AIR ON THESE FREQUENCIES IN (minutes)."

[Open Net following Analog repeater IDs at the top of the hour]

AFTER NET CLOSE:
In AllStar 485322 (Weather Hub): DISCONNECT 41694, CONNECT 289800.
Close Dashboards."""
        self.sections.append(("Setup & Pre-Net Checklist", pre_opening))

        opening = f"""\
Good afternoon and welcome to the Weather Outlook Net from the Colorado Severe Weather Network here on the \
Skyhub repeater-linking system; where we cover the Central Rockies and High Plains Region including the \
eastern UT border counties, CO, southeast WY, and Panhandle Nebraska. Today's Net Control is {nd.name}, {nd.callsign} \
located in {nd.location}. Today's net logger is {nd.logger_name}, {nd.logger_callsign} located in {nd.logger_location}.

This briefing airs Mondays thru Fridays at 1300 MT on the SkyHubLink.com system. Important alerts are \
also announced here as needed. During this net, we provide detailed information to Skywarn Storm Spotters \
for the National Weather Services with whom we are Core Partners in this Region. For those new to this net, \
we usually cover USA wx headlines, usually followed by Regional headlines. Then, we cover each NWS Forecast \
Office in our region.

This is a directed net, all traffic must pass thru Net Control unless otherwise instructed. Should there \
be an emergency, please key-in with 'break-break-break' and we'll suspend the net for your traffic. This \
is a linked system, so please key and wait 1.5 to 2 seconds before speaking and hang onto that PTT for \
an equal time afterward so that everyone hears your entire transmission.

The Severe Weather Network is on air in the CO Severe Weather Ops Room, Reflector xlx303a, when our region \
is under threat. When that occurs, your nearest repeaters will be connected to the room as needed. \
When the Severe Room is active, we will be taking all severe reports through Telegram and amateur radio. \
Severe weather reports can be sent in the CSWN telegram room on the SEVERE REPORTS For NWS Relay tab. \
For more details, visit our website at CSWN.net.

[OPTIONAL — To access the Severe Weather Room at any time at Reflector XLX303a:]
EchoLink NC2WX-L / Node 155536
Droid-STAR XRF/DCS303A
BM/DMR 31083
Allstar Weather Hub 485322 (preferred)
Allstar 289800 xlx303a
Wires-X Room 65045
YSF 30300 (switch to module A, DGID 10)
To monitor the CO Severe Rm go to hose.brandmeister.network, click the player upper right, type 31083."""
        self.sections.append(("Opening", opening))

        self.sections.append(("Check-ins", """\
WE'LL NOW TAKE OVER-THE-AIR CHECKINS FOR THE WEATHER OUTLOOK NET

Please give your callsign twice and — if you use phonetics — use only Standard ITU Phonetics.

If possible, use Netlogger.org or the CO Severe Weather Network chatroom on Telegram in the Check-in Tab.

[Check-ins should end by 1:12]

Western Slope of CO only: NW CO to I-70 > I-70 to Hwy 50 > Hwy 50 and south
Mobiles/portables only — callsign twice, please indicate which type you are.
Analog FM Stations, Analog FM — callsign twice.
Digital Stations, Digital only — callsign once. (Check YSF dashboard for callsign retrieval.)
Any other Check-ins, any mode, any location for the Weather Outlook Net? Callsign twice.

Thanks for being here with us today!

Consult your NWS homepage hazards map and DSS Packet for today's Warnings, Watches, and Advisories.
[Continue with Weather information]"""))

        self.sections.append(("Regional-Central Rockies/High Plains", """\
NOTE: Check the following resources for current regional conditions:

CONVECTIVE OUTLOOKS: https://www.spc.noaa.gov/products/outlook/
- Review Day 1, Day 2, and Day 3 outlooks when applicable

FIRE WEATHER: https://www.spc.noaa.gov/products/fire_wx/overview.html
- Review Day 1, Day 2, and Day 3 fire weather outlooks when applicable

EXCESSIVE RAINFALL: https://www.wpc.ncep.noaa.gov/qpf/excessive_rainfall_outlook_ero.php
- Check Day 1, Day 2, and Day 3 excessive rainfall outlooks when applicable"""))

        wfo_configs = [
            ("GJT","Grand Junction","weather forecast"),
            ("BOU","Boulder","weather forecast"),
            ("GLD","Goodland","weather forecast"),
            ("PUB","Pueblo","weather forecast"),
            ("CYS","Cheyenne","weather forecast"),
        ]
        for code, name_wfo, area_label in wfo_configs:
            logging.info(f"Fetching {code} AFD…")
            afd_raw = fetcher.fetch_text_product(code,"AFD") or f"[AFD unavailable for {code}]"
            clean   = trimmer.extract_key_messages(afd_raw)

            logging.info(f"Fetching {code} HWO…")
            hwo_raw     = fetcher.fetch_text_product(code,"HWO") or f"[HWO unavailable for {code}]"
            discontinued= trimmer.detect_discontinued(hwo_raw, code)
            hwo         = discontinued if discontinued else trimmer.trim_hwo(hwo_raw)

            # Removed: time.sleep(0.5) — was a 2.5-second hard UI freeze across
            # 5 WFOs on the main thread with no benefit (the HTTP calls already
            # have their own network latency).
            self.sections.append((f"{name_wfo} WFO", f"""\
The Area Forecast Discussion for the {name_wfo} {area_label} area:

{clean}

Hazardous Weather Outlook for the {name_wfo} {area_label} area:

{hwo}

Break for repeater reset.
"""))

        closing = f"""\
NET CLOSE

At this time, we will take the last round of check-ins. Any other Check-ins, any mode, any location \
for the Weather Outlook Net? Come now with your callsign twice.

**Recap the Callsigns that have checked in today** once all have been called.

Thanks to all of you for your support and for playing your part on the Colorado Severe Weather Network \
team. We and the NWS appreciate all of you. Let's continue working together to keep amateur radio at the \
forefront of the SKYWARN program, for the benefit of the National Weather Service and public safety.

Visit our website and connect with us at CSWN.net. The legacy webpage will continue for the time being at \
https://skyhublink.com/wx-net. Follow the Colorado Severe Weather Network on Facebook. \
Email us at: CO.SEVERE.WX@gmail.com.

[OPTIONAL — team listing:]
- Gary Maier NC2WX — Coordinator, Colorado Severe Weather Network, NCS
- Bucky Buckwalter W0SUN — Communications, IT, Digital Engineer, Weather Ops Support, Consultant
- Jon Poindexter W5ALC — Technical Systems Specialist & Consultant, Web Design
- Jay Wuensch AI7OF — Technical Support Consultant, Alternate Logger
- Abraham Sandy WX0ABE — Director of Public Relations and Social Media
- John Julian W7JPJ — Telegram Rooms Administrator, Primary Logger, Website Host
- Bryan Gunsher K6SKI — Alternate CSWN NC, HF Weather Net NC
- Terry Koelling AD0A — Weather Information Room / Telegram
- Kathleen 'Kat' Hickman W0KPH — Consultant, Alternate Logger

For the Colorado Severe Weather Network, this is {nd.name} closing the Weather Outlook Net. \
The systems are returned to open use. Have a great day! 73, {nd.callsign} is clear.

POST-CLOSE STEPS:
1. {nd.logger_name}, {nd.logger_callsign} will close out and log all contacts in NetLogger."""
        self.sections.append(("Closing", closing))
        self._update_nav()

    # ── Script display / navigation ──────────────────────────
    def _display_section(self):
        if not self.sections or self.section_idx >= len(self.sections): return
        name, text = self.sections[self.section_idx]
        self.script_display.setPlainText(f"=== {name.upper()} ===\n\n{text}")
        self.section_label.setText(f"Section {self.section_idx+1} of {len(self.sections)}: {name}")
        self.prev_btn.setEnabled(self.section_idx > 0)
        self.next_btn.setEnabled(self.section_idx < len(self.sections)-1)
        if self.auto_advance and self.section_idx < len(self.sections)-1:
            self._auto_advance_timer.start(self.auto_advance_delay * 1000)

    def _next_section(self):
        if self.section_idx < len(self.sections)-1:
            self.section_idx += 1; self._display_section(); self._auto_advance_timer.stop()

    def _prev_section(self):
        if self.section_idx > 0:
            self.section_idx -= 1; self._display_section(); self._auto_advance_timer.stop()

    def _toggle_auto_advance(self, enabled):
        self.auto_advance = enabled
        if not enabled: self._auto_advance_timer.stop()
        elif self.sections and self.section_idx < len(self.sections)-1:
            self._auto_advance_timer.start(self.auto_advance_delay * 1000)

    def _update_delay(self, v):
        self.auto_advance_delay = v
        if self.auto_advance and self._auto_advance_timer.isActive():
            self._auto_advance_timer.start(v * 1000)

    def _update_nav(self):
        has = bool(self.sections)
        self.prev_btn.setEnabled(has and self.section_idx > 0)
        self.next_btn.setEnabled(has and self.section_idx < len(self.sections)-1)

    def _toggle_editing(self, enabled):
        self.script_display.setReadOnly(not enabled)
        if not enabled and self.sections and self.section_idx < len(self.sections):
            full  = self.script_display.toPlainText()
            lines = full.split("\n")
            if lines and lines[0].startswith("=== ") and lines[0].endswith(" ==="):
                content = "\n".join(lines[2:])
                title   = self.sections[self.section_idx][0]
                self.sections[self.section_idx] = (title, content)
        self.status_bar.show_message("Editing " + ("enabled" if enabled else "disabled — changes saved"))

    def _copy_section(self):
        if self.sections and self.section_idx < len(self.sections):
            name, text = self.sections[self.section_idx]
            QApplication.clipboard().setText(f"=== {name.upper()} ===\n\n{text}")
            self.status_bar.show_message(f"Copied '{name}' to clipboard")

    def _copy_all(self):
        if not self.sections:
            QMessageBox.information(self,"No Script","Generate a script first."); return
        full = "".join(f"=== {n.upper()} ===\n\n{t}\n\n{'='*50}\n\n" for n,t in self.sections)
        QApplication.clipboard().setText(full)
        self.status_bar.show_message("Complete script copied to clipboard")

    # ── Export / PDF ─────────────────────────────────────────
    def _export_script(self):
        if not self.sections:
            QMessageBox.information(self,"No Script","Generate a script first."); return
        ti = get_current_mountain_time()
        default_name = f"Colorado_SWO_Net_{ti['datetime'].strftime('%Y%m%d_%H%M')}.pdf"

        # Build filter string based on available PDF engines
        if PDF_AVAILABLE:
            filters = "PDF Files (*.pdf);;LaTeX Files (*.tex);;Text Files (*.txt);;All Files (*)"
        else:
            filters = "Text Files (*.txt);;LaTeX Files (*.tex);;All Files (*)"

        file_path, _ = QFileDialog.getSaveFileName(self, "Export Net Script", default_name, filters)
        if not file_path: return

        if "." not in Path(file_path).name:
            file_path += ".txt"
        ext = Path(file_path).suffix.lower()

        # Content
        header = (f"Colorado Severe Weather Outlook Net Script\n"
                  f"Generated: {ti['date']} at {ti['full']}\n"
                  f"Net Control: {self.net_data.callsign} - {self.net_data.name}\n"
                  f"Location: {self.net_data.location}\n"
                  f"Logger: {self.net_data.logger_callsign} - {self.net_data.logger_name}\n\n"
                  + "="*60 + "\n\n")
        body = "".join(f"=== {n.upper()} ===\n\n{t}\n\n{'='*50}\n\n" for n,t in self.sections)
        content = header + body

        try:
            if ext == ".pdf":
                if not PDF_AVAILABLE:
                    QMessageBox.warning(self, "No PDF Engine Found",
                        "No PDF engine was found on this system.\n\n"
                        "Option A — Pure Python (no extra install needed beyond pip):\n"
                        "  pip install fpdf2\n\n"
                        "Option B — Full LaTeX (best quality):\n"
                        "  Linux:   sudo apt install texlive-latex-extra\n"
                        "  Windows: install TeX Live from tug.org/texlive\n"
                        "           (TeX Live is more reliable than MiKTeX on Windows)\n\n"
                        "Exporting as plain text instead.")
                    file_path = str(Path(file_path).with_suffix(".txt"))
                    ext = ".txt"
                else:
                    ok = self._generate_pdf(content, file_path)
                    if ok:
                        engine = "LaTeX" if PDFLATEX else "fpdf2"
                        self.status_bar.show_message(f"PDF exported ({engine}): {file_path}")
                        QMessageBox.information(self, "Export OK", f"PDF saved to:\n{file_path}")
                    return

            if ext == ".tex":
                with open(file_path, "w", encoding="utf-8") as f:
                    f.write(self._build_latex(content))
            else:
                with open(file_path, "w", encoding="utf-8") as f:
                    f.write(content)

            self.status_bar.show_message(f"Script exported: {file_path}")
            QMessageBox.information(self,"Export OK",f"Saved to:\n{file_path}")

        except Exception as e:
            self.status_bar.show_message(f"Export failed: {e}", error=True)
            QMessageBox.critical(self,"Export Error",str(e))

    def _generate_pdf(self, content, out_path):
        """Route to the best available PDF engine.

        Priority:
          1. pdflatex        — highest quality, TOC, watermark, tcolorbox styling
          2. QtWebEngine     — HTML/CSS rendered by Chromium; no extra install,
                               full Unicode, proper transparency for watermark
        """
        if PDFLATEX:
            return self._generate_pdf_latex(content, out_path)
        if WEBENGINE_AVAILABLE:
            return self._generate_pdf_html(content, out_path)
        # Should not reach here because _export_script guards on PDF_AVAILABLE
        QMessageBox.critical(self, "No PDF Engine",
            "No PDF engine is available.\n\n"
            "Install TeX Live (tug.org/texlive) for full LaTeX output, or\n"
            "ensure PyQtWebEngine is installed for the HTML fallback.")
        return False

    # ── Engine 1: pdflatex ────────────────────────────────────
    def _generate_pdf_latex(self, content, out_path):
        """Compile the net script to PDF via pdflatex (two passes)."""
        with tempfile.TemporaryDirectory() as tmp:
            tmp = Path(tmp)
            tex = tmp / "script.tex"
            tex.write_text(self._build_latex(content), encoding="utf-8")
            self.status_bar.show_message("Compiling PDF (LaTeX)…")
            for _ in range(2):
                try:
                    result = subprocess.run(
                        [PDFLATEX, "-interaction=nonstopmode", "-halt-on-error",
                         "-output-directory", str(tmp), str(tex)],
                        capture_output=True, text=True, timeout=60)
                    if result.returncode != 0:
                        lines = [l for l in result.stdout.split("\n") if "!" in l or "Error" in l]
                        msg   = "\n".join(lines[:5]) or result.stdout[-500:]
                        # fpdf2 fallback removed — it was never implemented.
                        # If LaTeX fails and WebEngine is available, the caller
                        # (_generate_pdf) already routes there automatically.
                        QMessageBox.critical(self, "LaTeX Error",
                            f"Compilation failed:\n\n{msg}\n\n"
                            "Export as .tex and compile manually, or ensure "
                            "PyQtWebEngine is installed for the HTML fallback.")
                        return False
                except subprocess.TimeoutExpired:
                    QMessageBox.critical(self, "Timeout",
                        "pdflatex timed out after 60 s.\n\n"
                        "Export as .tex instead, or use the HTML engine fallback.")
                    return False
                except FileNotFoundError:
                    QMessageBox.critical(self, "Not Found",
                        "pdflatex not found. Export as .tex instead,\n"
                        "or install TeX Live (tug.org/texlive).")
                    return False
            pdf = tmp / "script.pdf"
            if not pdf.exists():
                QMessageBox.critical(self, "Error",
                    "PDF not produced by pdflatex. Export as .tex instead.")
                return False
            shutil.copy2(pdf, out_path)
            return True

    # ── Engine 2: QtWebEngine HTML → PDF ────────────────────────────────────
    def _generate_pdf_html(self, content, out_path):
        """Render an HTML version of the net script to PDF using the embedded
        Chromium engine (QtWebEngine / QWebEnginePage.printToPdf).

        Benefits over fpdf2:
          - Full CSS layout — matches brand colours, fonts, spacing
          - Real transparency for the watermark (CSS opacity)
          - Proper Unicode support (no Latin-1 ceiling)
          - No additional pip install required — WebEngine is already a dep
        """
        if not WEBENGINE_AVAILABLE:
            QMessageBox.critical(self, "WebEngine Not Available",
                "PyQtWebEngine is required for the HTML PDF fallback.\n"
                "Install with: pip install PyQtWebEngine\n\n"
                "Or install TeX Live for full LaTeX output.")
            return False

        self.status_bar.show_message("Generating PDF (HTML engine)…")

        html = self._build_html(content)

        # ── Async printToPdf via a local event loop ────────────────────────
        result_holder = [None]   # [True/False] set by callback

        def _on_done(path, success):
            result_holder[0] = success
            loop.quit()

        loop = QEventLoop()
        # Use a local off-screen profile — self._profile only exists on WebViewPopup,
        # not on SevereWeatherWindow.
        _pdf_profile = QWebEngineProfile("CSWN_pdf_offscreen", self)
        page    = QWebEnginePage(_pdf_profile, self)
        page.pdfPrintingFinished.connect(_on_done)
        page.setHtml(html, QUrl("about:blank"))

        # Wait for page load before printing
        load_holder = [False]
        def _on_load(ok):
            load_holder[0] = ok
            page_loop.quit()

        page_loop = QEventLoop()
        page.loadFinished.connect(_on_load)
        page_loop.exec()

        if not load_holder[0]:
            QMessageBox.critical(self, "HTML Load Error",
                "Failed to render the HTML template.\nTry exporting as .tex instead.")
            return False

        layout = QPageLayout(
            QPageSize(QPageSize.PageSizeId.Letter),
            QPageLayout.Orientation.Portrait,
            QMarginsF(14, 14, 14, 14),   # mm — tight margins, header handles top
        )
        page.printToPdf(str(out_path), layout)
        loop.exec()

        if not result_holder[0]:
            QMessageBox.critical(self, "PDF Error",
                "QtWebEngine could not write the PDF.\n"
                "Check that the output path is writable.")
            return False

        return True

    # ── HTML template builder ─────────────────────────────────────────────
    def _build_html(self, content):
        """Return a print-optimised HTML string for the net script.

        Colour scheme and section logic mirrors _build_latex so the two
        outputs look as similar as possible.
        """
        import html as html_mod

        def h(t):
            """HTML-escape a string."""
            return html_mod.escape(str(t))

        def linkify(text: str) -> str:
            """Wrap bare URLs in <a> tags."""
            import re
            url_re = re.compile(r'(https?://\S+)')
            parts  = url_re.split(text)
            out = []
            for i, part in enumerate(parts):
                if i % 2 == 1:
                    trail = ''
                    while part and part[-1] in '.,;:)>\'"':
                        trail = part[-1] + trail
                        part  = part[:-1]
                    out.append(f'<a href="{h(part)}">{h(part)}</a>{h(trail)}')
                else:
                    out.append(h(part))
            return ''.join(out)

        # ── Meta extraction ────────────────────────────────────────────────
        lines = content.split("\n")

        def _meta(key):
            for l in lines:
                if l.startswith(key):
                    return l.split(key, 1)[1].strip()
            return ""

        date_str = _meta("Generated:")
        nc_str   = _meta("Net Control:")
        loc_str  = _meta("Location:")
        lgr_str  = _meta("Logger:")

        # ── Section parsing ────────────────────────────────────────────────
        TOP_SECTIONS = {
            "PRE-OPENING", "OPENING", "TELEGRAM INFORMATION",
            "CHECK-INS", "REGIONAL-CENTRAL ROCKIES/HIGH PLAINS", "CLOSING",
        }
        sections, current_name, current_body = [], None, []
        in_content = False
        for line in lines:
            if not in_content:
                if "=" * 20 in line:
                    in_content = True
                continue
            if line.startswith("=== ") and line.endswith(" ==="):
                if current_name is not None:
                    sections.append((current_name, "\n".join(current_body)))
                current_name = line.strip("= ")
                current_body = []
            elif line.startswith("=="):
                pass
            else:
                current_body.append(line)
        if current_name is not None:
            sections.append((current_name, "\n".join(current_body)))

        # ── Watermark ─────────────────────────────────────────────────────
        wm_path = None
        config_candidate = Config.CONFIG_DIR / "CSWN-logo-BRAND.png"
        if config_candidate.exists():
            wm_path = config_candidate
        else:
            wm_path = find_asset("CSWN-logo-BRAND.png")

        if wm_path:
            import base64
            try:
                wm_b64   = base64.b64encode(Path(wm_path).read_bytes()).decode()
                wm_style = (
                    f'background-image: url("data:image/png;base64,{wm_b64}"); '
                    "background-repeat: no-repeat; "
                    "background-position: center center; "
                    "background-size: 65%; "
                    "background-attachment: fixed;"
                )
            except Exception:
                wm_style = ""
        else:
            wm_style = ""

        watermark_div = (
            '<div id="watermark"></div>' if wm_path else ""
        )
        if wm_path and wm_style:
            watermark_css = (
                '#watermark { position: fixed; top: 0; left: 0; width: 100%; height: 100%; '
                'background-image: url("data:image/png;base64,' + wm_b64 + '"); '
                'background-repeat: no-repeat; background-position: center center; '
                'background-size: 55%; opacity: 0.06; z-index: -1; pointer-events: none; }'
            )
        else:
            watermark_css = ""

        # ── Section HTML ───────────────────────────────────────────────────
        sec_html = ""
        for sname, sbody in sections:
            IS_TOP = sname.upper() in TOP_SECTIONS or "WFO" in sname.upper()
            tag    = "h2" if IS_TOP else "h3"
            sec_html += f'<{tag}>{h(sname)}</{tag}>\n'

            is_fc = any(k in sbody.lower() for k in
                        [".key messages", ".short term", ".long term",
                         "forecast discussion", "hazardous weather"])

            if is_fc:
                sec_html += (
                    '<div class="forecast-box">\n'
                    '<div class="forecast-label">NWS Forecast</div>\n'
                    f'<pre class="forecast-body">{h(sbody.strip())}</pre>\n'
                    '</div>\n'
                )
            else:
                sec_html += "<p>"
                para_lines = []
                for line in sbody.split("\n"):
                    stripped = line.strip()
                    if not stripped:
                        if para_lines:
                            sec_html += " ".join(para_lines) + "</p>\n<p>"
                            para_lines = []
                    elif stripped.startswith("•"):
                        if para_lines:
                            sec_html += " ".join(para_lines) + "</p>\n"
                            para_lines = []
                            sec_html += "<p>"
                        sec_html += f'<span class="bullet">{linkify(stripped)}</span><br>\n'
                    elif stripped.endswith(":"):
                        if para_lines:
                            sec_html += " ".join(para_lines) + "</p>\n"
                            para_lines = []
                            sec_html += "<p>"
                        sec_html += f'<strong>{linkify(stripped)}</strong><br>\n'
                    else:
                        para_lines.append(linkify(stripped))
                if para_lines:
                    sec_html += " ".join(para_lines)
                sec_html += "</p>\n"

        date_short = h(date_str.split(" at ")[0] if " at " in date_str else date_str)

        return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<style>
  /* ── Reset & base ─────────────────────────────────────── */
  *, *::before, *::after {{ box-sizing: border-box; margin: 0; padding: 0; }}
  body {{
    font-family: "Segoe UI", Arial, Helvetica, sans-serif;
    font-size: 10.5pt;
    line-height: 1.5;
    color: #111;
    background: white;
    padding: 0;
  }}

  /* ── Watermark ────────────────────────────────────────── */
  {watermark_css}

  /* ── Running page header/footer via @page ─────────────── */
  @page {{
    size: letter;
    margin: 18mm 16mm 16mm 16mm;
    @top-left   {{ content: "Colorado Severe Weather Network";
                  font-family: Arial, sans-serif; font-size: 9pt;
                  font-weight: bold; color: white;
                  background: #0066cc; padding: 3px 8px; }}
    @top-right  {{ content: "{date_short}";
                  font-family: Arial, sans-serif; font-size: 9pt;
                  color: white; background: #0066cc; padding: 3px 8px; }}
    @bottom-center {{ content: "Page " counter(page);
                      font-family: Arial, sans-serif; font-size: 8pt;
                      color: #666; }}
  }}

  /* ── Title block ──────────────────────────────────────── */
  .title-block {{
    text-align: center;
    border-bottom: 2px solid #0066cc;
    padding-bottom: 10px;
    margin-bottom: 14px;
  }}
  .title-block h1 {{
    font-size: 18pt;
    color: #0066cc;
    margin-bottom: 8px;
  }}
  .meta-table {{ width: 100%; border-collapse: collapse; text-align: left; }}
  .meta-table td {{ padding: 2px 6px; font-size: 10pt; }}
  .meta-table td:first-child {{ font-weight: bold; width: 120px; color: #333; }}

  /* ── Section headings ─────────────────────────────────── */
  h2 {{
    font-size: 13pt;
    color: #0066cc;
    border-bottom: 1.5px solid #0066cc;
    margin-top: 18px;
    margin-bottom: 6px;
    padding-bottom: 2px;
    page-break-after: avoid;
  }}
  h3 {{
    font-size: 11pt;
    color: #663399;
    border-bottom: 1px solid #663399;
    margin-top: 14px;
    margin-bottom: 5px;
    padding-bottom: 2px;
    page-break-after: avoid;
  }}

  /* ── Body text ────────────────────────────────────────── */
  p {{ margin: 0 0 6px 0; text-align: justify; }}
  a {{ color: #0066cc; }}
  .bullet {{ margin-left: 10px; display: inline-block; }}
  strong {{ color: #222; }}

  /* ── NWS Forecast boxes ───────────────────────────────── */
  .forecast-box {{
    background: #f8f8f8;
    border: 1px solid #0066cc;
    border-radius: 3px;
    margin: 6px 0 10px 0;
    page-break-inside: avoid;
  }}
  .forecast-label {{
    background: #0066cc;
    color: white;
    font-family: Arial, sans-serif;
    font-size: 8pt;
    font-weight: bold;
    padding: 3px 8px;
  }}
  .forecast-body {{
    font-family: "Consolas", "Courier New", Courier, monospace;
    font-size: 8pt;
    padding: 8px 10px;
    white-space: pre-wrap;
    word-break: break-word;
    line-height: 1.45;
    color: #111;
    background: #f8f8f8;
  }}

  /* ── Sign-off ─────────────────────────────────────────── */
  .signoff {{
    text-align: center;
    font-style: italic;
    color: #555;
    margin-top: 24px;
    padding-top: 8px;
    border-top: 1px solid #ccc;
  }}
</style>
</head>
<body>
{watermark_div}

<div class="title-block">
  <h1>Colorado Severe Weather Outlook Net Script</h1>
  <table class="meta-table">
    <tr><td>Generated:</td>  <td>{h(date_str)}</td></tr>
    <tr><td>Net Control:</td><td>{h(nc_str)}</td></tr>
    <tr><td>Location:</td>   <td>{h(loc_str)}</td></tr>
    <tr><td>Logger:</td>     <td>{h(lgr_str)}</td></tr>
  </table>
</div>

{sec_html}

<div class="signoff">73 de Colorado Severe Weather Network</div>
</body>
</html>"""

    def _build_latex(self, content):
        def linkify(text: str) -> str:
            """Escape a line of text for LaTeX, wrapping any URLs in \\url{} so
            they become clickable hyperlinks in the PDF (requires hyperref)."""
            url_re = re.compile(r'(https?://\S+)')
            parts  = url_re.split(text)
            result = []
            for i, part in enumerate(parts):
                if i % 2 == 1:                  # this chunk is a URL
                    # Strip trailing punctuation that belongs to the sentence, not the URL
                    trail = ''
                    while part and part[-1] in '.,;:)>\'\"':
                        trail = part[-1] + trail
                        part  = part[:-1]
                    result.append(f'\\url{{{part}}}')
                    if trail:
                        result.append(escape_latex(trail))
                else:
                    result.append(escape_latex(part))
            return ''.join(result)

        def escape_latex(text: str) -> str:
            replacements = [
                ('\\', r'\textbackslash{}'),
                ('&',  r'\&'),
                ('%',  r'\%'),
                ('$',  r'\$'),
                ('#',  r'\#'),
                ('_',  r'\_'),
                ('{',  r'\{'),
                ('}',  r'\}'),
                ('~',  r'\textasciitilde{}'),
                ('^',  r'\textasciicircum{}'),
            ]
            for old, new in replacements:
                text = text.replace(old, new)
            return text


        def esc(t):
            for old, new in [("\\", r"\textbackslash{}"), ("&", r"\&"), ("%", r"\%"), ("$", r"\$"),
                            ("#", r"\#"), ("_", r"\_"), ("{", r"\{"), ("}", r"\}"),
                            ("~", r"\textasciitilde{}"), (r"^", r"\textasciicircum{}")]:
                t = t.replace(old, new)
            return t

        # ── Logo / watermark — look in config dir first, then fall back to find_asset() ──
        wm_path = None
        config_candidate = Config.CONFIG_DIR / "CSWN-logo-BRAND.png"
        if config_candidate.exists():
            wm_path = config_candidate
        else:
            wm_path = find_asset("CSWN-logo-BRAND.png")   # checks script dir & assets/

        # Only emit the LaTeX packages if the file actually exists on disk
        watermark_pkg = (r"\usepackage{eso-pic}" + "\n" + r"\usepackage{transparent}") if wm_path else ""
        watermark_cmd = (r"""
    \AddToShipoutPictureFG{%
    \AtPageCenter{%
        \makebox(0,0){%
        \transparent{0.06}%
        \includegraphics[height=0.85\paperheight]{""" + str(wm_path).replace("\\", "/") + r"""}%
        }%
    }%
    }""") if wm_path else ""

        # ── Header extraction ────────────────────────────────────
        lines = content.split("\n")
        date  = next((l.split("Generated:",1)[1].strip() for l in lines if "Generated:" in l), "")
        nc    = next((l.split("Net Control:",1)[1].strip() for l in lines if "Net Control:" in l), "")
        loc   = next((l.split("Location:",1)[1].strip() for l in lines if "Location:" in l), "")
        lgr   = next((l.split("Logger:",1)[1].strip() for l in lines if "Logger:" in l), "")
        date_short = esc(date.split(" at ")[0] if " at " in date else date)

        # ── Section parsing ──────────────────────────────────────
        TOP_SECTIONS = {
            "PRE-OPENING", "OPENING", "TELEGRAM INFORMATION",
            "CHECK-INS", "REGIONAL-CENTRAL ROCKIES/HIGH PLAINS", "CLOSING",
        }
        sections, current_name, current_lines = [], None, []
        in_content = False
        for line in lines:
            if not in_content:
                if "=" * 20 in line: in_content = True; continue
            elif line.startswith("=== ") and line.endswith(" ==="):
                if current_name: sections.append((current_name, "\n".join(current_lines)))
                current_name = line.strip("= "); current_lines = []
            elif line.startswith("=="):
                pass
            else:
                current_lines.append(line)
        if current_name: sections.append((current_name, "\n".join(current_lines)))

        # ── Section bodies ───────────────────────────────────────
        sec_tex = ""
        for sname, sbody in sections:
            SNAME_UP = sname.upper()
            if SNAME_UP in TOP_SECTIONS or "WFO" in SNAME_UP:
                sec_tex += f"\n\\section{{{esc(sname)}}}\n\n"
            else:
                sec_tex += f"\n\\subsection{{{esc(sname)}}}\n\n"

            is_fc = any(k in sbody.lower() for k in
                        [".key messages", ".short term", ".long term",
                         "forecast discussion", "hazardous weather"])
            if is_fc:
                sec_tex += (
                    "\\begin{commandbox}\n"
                    "\\begin{lstlisting}[style=netscript,numbers=none]\n"
                    + sbody.strip() +
                    "\n\\end{lstlisting}\n\\end{commandbox}\n\n"
                )
            else:
                for line in sbody.split("\n"):
                    if not line.strip():
                        sec_tex += "\n"
                    elif line.strip().startswith("•"):
                        sec_tex += esc(line) + "\n\n"
                    elif line.strip().endswith(":"):
                        sec_tex += f"\\textbf{{{esc(line)}}}\n\n"
                    else:
                        sec_tex += linkify(line.strip()) + "\n\n"  # linkify before esc

        return rf"""
\documentclass[11pt,letterpaper]{{article}}

% ── Packages ────────────────────────────────────────────────
\usepackage[margin=0.75in]{{geometry}}
\usepackage{{fancyhdr}}
\usepackage{{titlesec}}
\usepackage{{enumitem}}
\usepackage{{xcolor}}
\usepackage{{soul}}
\usepackage[utf8]{{inputenc}}
\usepackage[T1]{{fontenc}}
\usepackage{{microtype}}
\usepackage{{tcolorbox}}
\usepackage{{listings}}
\usepackage{{graphicx}}
\usepackage{{hyperref}}
\usepackage{{fontawesome5}}
\usepackage{{tabularx}}
\usepackage{{booktabs}}
\usepackage{{verbatim}}
\usepackage{{textcomp}}
{watermark_pkg}

% ── Color scheme ─────────────────────────────────────────────
\definecolor{{primary}}{{RGB}}{{0,102,204}}
\definecolor{{secondary}}{{RGB}}{{102,51,153}}
\definecolor{{accent}}{{RGB}}{{255,102,0}}
\definecolor{{codebg}}{{RGB}}{{248,248,248}}
\definecolor{{codegreen}}{{RGB}}{{0,128,0}}
\definecolor{{codeblue}}{{RGB}}{{0,102,204}}
\definecolor{{warningbg}}{{RGB}}{{255,250,205}}
\definecolor{{infobg}}{{RGB}}{{230,244,255}}

% ── Hyperref ─────────────────────────────────────────────────
\hypersetup{{colorlinks=true,linkcolor=primary,urlcolor=primary,citecolor=primary}}

% ── Header / footer ──────────────────────────────────────────
\pagestyle{{fancy}}
\fancyhf{{}}
\fancyhead[L]{{\textbf{{Colorado Severe Weather Network}}}}
\fancyhead[R]{{{date_short}}}
\fancyfoot[C]{{\thepage}}
\renewcommand{{\headrulewidth}}{{0.4pt}}
\renewcommand{{\footrulewidth}}{{0.4pt}}

% ── Section formatting ────────────────────────────────────────
\titleformat{{\section}}{{\color{{primary}}\Large\bfseries}}{{\thesection}}{{1em}}{{}}[\titlerule]
\titleformat{{\subsection}}{{\color{{secondary}}\large\bfseries}}{{\thesubsection}}{{1em}}{{}}
\titlespacing*{{\section}}{{0pt}}{{1em}}{{0.5em}}
\titlespacing*{{\subsection}}{{0pt}}{{0.8em}}{{0.3em}}

% ── Custom boxes ─────────────────────────────────────────────
\tcbuselibrary{{skins,breakable}}

\newtcolorbox{{infobox}}[1][]{{
  colback=infobg,colframe=primary,fonttitle=\bfseries,
  title={{\faInfoCircle\ Information}},breakable,#1}}

\newtcolorbox{{warningbox}}[1][]{{
  colback=warningbg,colframe=accent,fonttitle=\bfseries,
  title={{\faExclamationTriangle\ Warning}},breakable,#1}}

\newtcolorbox{{commandbox}}[1][]{{
  colback=codebg,colframe=codeblue,fonttitle=\bfseries,
  title={{NWS Forecast}},breakable,#1}}

% ── Listing style ─────────────────────────────────────────────
\lstdefinestyle{{netscript}}{{
  basicstyle=\small\ttfamily,
  backgroundcolor=\color{{codebg}},
  keywordstyle=\color{{black}}\bfseries,
  commentstyle=\color{{codegreen}}\itshape,
  stringstyle=\color{{black}},
  showstringspaces=false,
  breaklines=true,
  frame=none,
  tabsize=4,
  captionpos=b
}}

% ── Spacing ───────────────────────────────────────────────────
\setlength{{\parindent}}{{0pt}}
\setlength{{\parskip}}{{0.5em}}

\title{{\textbf{{\Large Colorado Severe Weather Outlook Net Script}}}}
\author{{Net Control: {esc(nc)} \\
         Location:    {esc(loc)} \\
         Logger:      {esc(lgr)}}}

{watermark_cmd}

\begin{{document}}
\maketitle
\thispagestyle{{fancy}}
\tableofcontents
\newpage

{sec_tex}

\vfill
\begin{{center}}\textit{{73 de Colorado Severe Weather Network}}\end{{center}}
\end{{document}}
"""

    def _print_script(self):
        QMessageBox.information(self, "Print",
            "Use Export → PDF then print from your PDF viewer.\n"
            "Ctrl+P printing will be added in a future version.")

    # ── Weather refresh ──────────────────────────────────────
    def _refresh_weather(self):
        self.status_bar.show_message("Refreshing Regional Weather Roundup…", progress=True)
        self.status_bar.set_progress(50)
        html = RWRFetcher().get_rwr_html(theme=self.current_theme, font_size=self.config.get("font_size",18))
        self.conditions_display.setHtml(html)
        self.status_bar.set_progress(100)
        self.status_bar.show_message("Regional Weather Roundup updated")
        QTimer.singleShot(2000, lambda: self.status_bar.set_progress(0))

    # ── Theme ────────────────────────────────────────────────
    def _change_theme(self, name):
        key = name.lower()
        self.current_theme = themes.get(key, themes["light"])
        self.theme_dark    = (key == "dark")
        self.config["theme"] = key
        self._apply_theme()

    def _apply_theme(self):
        t = self.current_theme
        self.setStyleSheet(f"""
            QWidget {{ background-color:{t['bg']}; color:{t['fg']}; }}
            QGroupBox {{
                font-weight:bold; color:{t['section_fg']};
                border:2px solid {t['group_border']}; border-radius:8px;
                margin-top:1ex; padding-top:10px; background-color:{t['group_bg']};
            }}
            QGroupBox::title {{
                subcontrol-origin:margin; subcontrol-position:top left;
                padding:0 8px; background-color:{t['group_bg']}; border-radius:4px;
            }}
            QPushButton {{
                background:{t['button_bg']}; color:{t['button_fg']};
                border:2px solid {t['group_border']}; border-radius:6px;
                padding:8px 16px; font-weight:600;
            }}
            QPushButton:hover {{ background:{t['button_hover']}; border-color:{t['accent']}; color:{t['accent']}; }}
            QPushButton:pressed {{ background:{t['button_pressed']}; }}
            QLineEdit, QTextEdit, QSpinBox, QComboBox {{
                background-color:{t['entry_bg']}; color:{t['entry_fg']};
                border:2px solid {t['entry_border']}; border-radius:4px; padding:5px;
            }}
            QLineEdit:focus, QTextEdit:focus, QSpinBox:focus, QComboBox:focus {{ border-color:{t['entry_focus']}; }}
            QTabWidget::pane {{ border:2px solid {t['group_border']}; background-color:{t['bg']}; }}
            QTabBar::tab {{
                background:{t['button_bg']}; color:{t['button_fg']};
                border:1px solid {t['group_border']}; border-bottom:none;
                padding:8px 18px; margin-right:2px;
                border-top-left-radius:6px; border-top-right-radius:6px;
            }}
            QTabBar::tab:selected {{ background:{t['accent']}; color:{t['bg']}; font-weight:bold; }}
            QTabBar::tab:hover:!selected {{ background:{t['button_hover']}; }}
            QScrollArea {{ border:none; background-color:{t['bg']}; }}
            QSplitter::handle {{ background-color:{t['group_border']}; }}
            QCheckBox, QLabel {{ color:{t['fg']}; background-color:transparent; }}
            QProgressBar {{
                border:1px solid {t['group_border']}; border-radius:4px;
                background-color:{t['entry_bg']}; color:{t['fg']};
            }}
            QProgressBar::chunk {{ background-color:{t['accent']}; border-radius:3px; }}
        """)
        if hasattr(self, "right_layout"):    self._apply_theme_to_section()
        if hasattr(self, "section_buttons"):
            for btn in self.section_buttons.values(): btn.apply_style(t)
        if hasattr(self, "conditions_display"): self._refresh_weather()
        # TimeWidget has a hardcoded color; override it to follow the active theme.
        if hasattr(self, "time_widget"):
            self.time_widget.setStyleSheet(
                f"QLabel {{ font-size: 18px; font-weight: bold; color: {t['fg']}; padding: 5px; }}"
            )
        # Header labels also have hardcoded colours — update them too.
        if hasattr(self, "net_status"):
            # Preserve the current semantic colour (error/warning/ok) already set
            # on net_status; only refresh if it's in a neutral "off" state.
            pass

    def _select_font(self):
        font, ok = QFontDialog.getFont(self.font(), self)
        if ok:
            self.setFont(font)
            self.status_bar.show_message("Font updated")

    # ── Settings persistence ─────────────────────────────────
    def _reset_settings(self):
        if QMessageBox.question(self,"Reset","Reset all settings to defaults?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No) == QMessageBox.StandardButton.Yes:
            self.theme_combo.setCurrentText("Light")
            self.auto_save_cb.setChecked(True)
            self.confirm_exit_cb.setChecked(True)
            self.default_callsign.setText(Config.DEFAULT_CALLSIGN)
            self.default_name.setText(Config.DEFAULT_NAME)
            self.default_location.setText(Config.DEFAULT_LOCATION)
            self.default_logger_callsign.setText(Config.DEFAULT_LOGGER_CALLSIGN)
            self.default_logger_name.setText(Config.DEFAULT_LOGGER_NAME)
            self.default_logger_location.setText(Config.DEFAULT_LOGGER_LOCATION)
            self.status_bar.show_message("Settings reset to defaults")

    def _save_settings_to_disk(self):
        try:
            self._cfg.update({
                "theme":                  self.theme_combo.currentText(),
                "auto_save":              self.auto_save_cb.isChecked(),
                "confirm_exit":           self.confirm_exit_cb.isChecked(),
                "default_callsign":       self.default_callsign.text(),
                "default_name":           self.default_name.text(),
                "default_location":       self.default_location.text(),
                "default_logger_callsign":self.default_logger_callsign.text(),
                "default_logger_name":    self.default_logger_name.text(),
                "default_logger_location":self.default_logger_location.text(),
                "auto_advance":           self.auto_advance,
                "auto_advance_delay":     self.auto_advance_delay,
            })
            Config.CONFIG_DIR.mkdir(parents=True, exist_ok=True)
            Config.CONFIG_FILE.write_text(
                json.dumps(self._cfg, indent=2, ensure_ascii=False), encoding="utf-8"
            )
            self.status_bar.show_message("Settings saved")
        except Exception as e:
            self.status_bar.show_message(f"Failed to save settings: {e}", error=True)

    def _load_settings(self):
        try:
            c = self._cfg
            theme = c.get("theme", "Light")
            if theme not in ("Dark", "Light", "Blue"):
                theme = "Light"
            self.theme_combo.setCurrentText(theme)
            key = theme.lower()
            self.current_theme = themes.get(key, themes["light"])
            self.theme_dark    = (key == "dark")
            self.config["theme"] = key

            self.auto_save_cb.setChecked(   c.get("auto_save",    True))
            self.confirm_exit_cb.setChecked(c.get("confirm_exit", True))

            for attr, key_name, default in [
                ("default_callsign",        "default_callsign",         Config.DEFAULT_CALLSIGN),
                ("default_name",            "default_name",             Config.DEFAULT_NAME),
                ("default_location",        "default_location",         Config.DEFAULT_LOCATION),
                ("default_logger_callsign", "default_logger_callsign",  Config.DEFAULT_LOGGER_CALLSIGN),
                ("default_logger_name",     "default_logger_name",      Config.DEFAULT_LOGGER_NAME),
                ("default_logger_location", "default_logger_location",  Config.DEFAULT_LOGGER_LOCATION),
            ]:
                getattr(self, attr).setText(c.get(key_name, default))

            self.auto_advance       = c.get("auto_advance",       False)
            self.auto_advance_delay = c.get("auto_advance_delay", 30)
            self.auto_advance_cb.setChecked(self.auto_advance)
            self.delay_spinbox.setValue(self.auto_advance_delay)

        except Exception as e:
            logging.error(f"Failed to load settings: {e}")

    # ── Session persistence ──────────────────────────────────
    def _auto_save(self):
        if self.auto_save_cb.isChecked():
            self._save_session(auto=True)

    def _save_session(self, auto=False):
        if auto:
            path = Config.CONFIG_DIR / "last_session.json"
        else:
            ti = get_current_mountain_time()
            default = f"SWO_Session_{ti['datetime'].strftime('%Y%m%d_%H%M')}.json"
            path_str, _ = QFileDialog.getSaveFileName(self,"Save Session",default,"JSON Files (*.json);;All Files (*)")
            if not path_str: return
            path = Path(path_str)

        try:
            Config.CONFIG_DIR.mkdir(parents=True, exist_ok=True)
            # Use the actual visible UI fields (default_callsign etc.), not the
            # phantom hidden QLineEdits that were always empty.
            data = {
                "callsign":        self.default_callsign.text(),
                "name":            self.default_name.text(),
                "location":        self.default_location.text(),
                "logger_callsign": self.default_logger_callsign.text(),
                "logger_name":     self.default_logger_name.text(),
                "logger_location": self.default_logger_location.text(),
                "timestamp":       get_current_mountain_time()["datetime"].isoformat(),
                "version":         Config.APP_VERSION,
            }
            path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
            if not auto:
                self.status_bar.show_message(f"Session saved to {path}")
                QMessageBox.information(self,"Saved",f"Session saved to:\n{path}")
        except Exception as e:
            self.status_bar.show_message(f"Save failed: {e}", error=True)
            if not auto: QMessageBox.critical(self,"Save Error",str(e))

    def _load_session(self):
        path_str, _ = QFileDialog.getOpenFileName(self,"Load Session","","JSON Files (*.json);;All Files (*)")
        if not path_str: return
        try:
            data = json.loads(Path(path_str).read_text(encoding="utf-8"))
            # Write to the actual visible UI fields (default_callsign etc.)
            self.default_callsign.setText(data.get("callsign",""))
            self.default_name.setText(data.get("name",""))
            self.default_location.setText(data.get("location",""))
            self.default_logger_callsign.setText(data.get("logger_callsign",""))
            self.default_logger_name.setText(data.get("logger_name",""))
            self.default_logger_location.setText(data.get("logger_location",""))
            self.status_bar.show_message("Session loaded")
            QMessageBox.information(self,"Loaded","Session loaded successfully!")
        except Exception as e:
            self.status_bar.show_message(f"Load failed: {e}", error=True)
            QMessageBox.critical(self,"Load Error",str(e))

    # ── Close ────────────────────────────────────────────────
    def closeEvent(self, event):
        if self.confirm_exit_cb.isChecked():
            if QMessageBox.question(self,"Confirm Exit","Exit CSWN Net Control Toolkit?",
                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                    QMessageBox.StandardButton.No) == QMessageBox.StandardButton.No:
                event.ignore(); return
        self._save_settings_to_disk()
        if self.auto_save_cb.isChecked(): self._auto_save()
        logging.info("Application closing")
        event.accept()


# ─────────────────────────────────────────────────────────────
# Entry point
# ─────────────────────────────────────────────────────────────
def main():
    app = QApplication(sys.argv)
    app.setApplicationName(Config.APP_NAME)
    app.setApplicationVersion(Config.APP_VERSION)
    app.setOrganizationName(Config.ORGANIZATION)

    window = SevereWeatherWindow()
    window.show()

    # Auto-load last session
    last = Config.CONFIG_DIR / "last_session.json"
    if last.exists():
        try:
            data = json.loads(last.read_text(encoding="utf-8"))
            # Use the real visible UI fields, not the phantom hidden QLineEdits
            for attr, key in [
                ("default_callsign",        "callsign"),
                ("default_name",            "name"),
                ("default_location",        "location"),
                ("default_logger_callsign", "logger_callsign"),
                ("default_logger_name",     "logger_name"),
                ("default_logger_location", "logger_location"),
            ]:
                field = getattr(window, attr)
                if not field.text() and data.get(key):
                    field.setText(data[key])
        except Exception as e:
            logging.warning(f"Could not auto-load session: {e}")

    sys.exit(app.exec())


if __name__ == "__main__":
    main()
