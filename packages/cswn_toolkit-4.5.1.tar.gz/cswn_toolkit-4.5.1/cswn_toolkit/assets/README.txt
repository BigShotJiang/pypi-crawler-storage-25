CSWN Net Toolkit — Asset Files
===============================

Place the following image files in this directory:

  Skywarn-cyan.png        — Skywarn logo shown in the app header
                            (displayed as 70x70 px; source can be larger)

  CSWN-logo-BRAND.png     — CSWN brand logo used as a PDF watermark
                            (semi-transparent, centered on each page)

These files are optional — the app will gracefully fall back to a text
emoji (📡) if Skywarn-cyan.png is missing, and omit the watermark if
CSWN-logo-BRAND.png is missing.

You may also place these files in any of the following locations and
the app will find them automatically (searched in order):

  ~/.colorado_swo/          (Linux / macOS)
  %APPDATA%\CSWN_Toolkit\   (Windows)
  <install_dir>/            (alongside the script)
  <install_dir>/assets/     (this directory)
  ~/Public/
  ~/bin/
