# Changelog

All notable changes to the CSWN Net Control Toolkit will be documented here.

## [4.2.0] — Initial PyPI Release

### Added
- PyPI packaging with `pyproject.toml`, `__init__.py`, `__main__.py`
- `cswn-toolkit` console script entry point
- Optional dependency groups: `webengine`, `timezone`, `all`, `dev`
- Assets directory with bundled image support

### Features (from standalone script 4.2)
- Live NWS AFD and HWO fetching for GJT, BOU, GLD, PUB, CYS WFOs
- Regional Weather Roundup (RWR) HTML display with themed tables
- Section-by-section net script generator with navigation
- Dark / Light / Blue Qt themes
- PDF export via pdflatex with watermark support
- In-app browser via PyQt6-WebEngine (optional)
- Session JSON save/restore with 60-second auto-save
- Auto-advance mode with configurable timer
- Cross-platform (Windows + Linux) with graceful fallbacks
- NWS active alerts via CAP/ATOM feed
