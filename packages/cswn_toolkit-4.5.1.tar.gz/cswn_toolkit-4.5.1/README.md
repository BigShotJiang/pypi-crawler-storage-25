# Colorado Severe Weather Network — Net Control Toolkit

[![PyPI version](https://img.shields.io/pypi/v/cswn-net-toolkit)](https://pypi.org/project/cswn-net-toolkit/)
[![Python](https://img.shields.io/pypi/pyversions/cswn-net-toolkit)](https://pypi.org/project/cswn-net-toolkit/)
[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)

A cross-platform PyQt6 desktop application for amateur radio **net control operators** running the **Colorado Severe Weather Network** daily Weather Outlook Net on the SkyHubLink repeater-linking system.

---

## Features

- **Automated net script generation** — fetches live NWS Area Forecast Discussions (AFD) and Hazardous Weather Outlooks (HWO) for all regional WFOs (GJT, BOU, GLD, PUB, CYS) and builds a complete, section-by-section net script
- **Regional Weather Roundup** — renders the NWS Pueblo RWR as a styled HTML table with color-coded temperature, wind, and conditions columns
- **Weather Resource Toolkit** — categorized quick-access panel linking to SPC convective outlooks, NWS office pages, radar & satellite tools, Skywarn resources, mesonets, and more
- **Built-in web browser** — opens dashboards in-app via `PyQt6-WebEngine` (optional; falls back to external browser)
- **PDF export** — generates a formatted, bookmarked PDF of the net script via `pdflatex` when TeX Live / MiKTeX is installed
- **Session persistence** — save and restore operator callsign, name, and location; auto-saves every 60 seconds
- **Dark / Light / Blue themes** — full Qt stylesheet theming
- **Auto-advance mode** — steps through script sections on a configurable timer
- **Cross-platform** — tested on Windows 10/11 and Linux (Ubuntu 22.04+)

---

## Installation

### Standard (no web engine)

```bash
pip install cswn-net-toolkit
```

### With in-app browser support

```bash
pip install "cswn-net-toolkit[webengine]"
```

### With timezone-aware Mountain Time display

```bash
pip install "cswn-net-toolkit[all]"
```

---

## Running

```bash
# Console script (installed automatically by pip):
cswn-toolkit

# Or as a Python module:
python -m cswn_toolkit
```

---

## Optional Dependencies

| Extra | Package | Purpose |
|-------|---------|---------|
| `webengine` | `PyQt6-WebEngine` | In-app browser for dashboards |
| `timezone` | `pytz` | Accurate Mountain Time display |
| `all` | Both above | Full feature set |

---

## Optional Assets (image files)

The app will look for the following image files in these locations (in order):

- `~/.colorado_swo/` (Linux/macOS) or `%APPDATA%\CSWN_Toolkit\` (Windows)
- The package `assets/` directory
- `~/Public/` or `~/bin/`

| File | Purpose |
|------|---------|
| `Skywarn-cyan.png` | Header logo (falls back to 📡 emoji if absent) |
| `CSWN-logo-BRAND.png` | PDF watermark (omitted if absent) |

---

## PDF Export

PDF export requires `pdflatex`. Install it with:

- **Linux:** `sudo apt install texlive-latex-recommended texlive-fonts-recommended`
- **Windows:** [MiKTeX](https://miktex.org/) or [TeX Live](https://tug.org/texlive/)
- **macOS:** `brew install --cask mactex`

Plain text (`.txt`) and LaTeX source (`.tex`) export work without any TeX installation.

---

## System Requirements

- Python 3.9 or newer
- PyQt6 ≥ 6.4
- Network access (for fetching NWS data)

---

## About the Colorado Severe Weather Network

The **Colorado Severe Weather Network (CSWN)** is a Skywarn Core Partner network running daily weather briefing nets on the [SkyHubLink](https://skyhublink.com) system at **1300 MT, Monday–Friday**. It serves NWS offices in the Central Rockies and High Plains region.

- Website: [cswn.net](https://cswn.net)
- Email: CO.SEVERE.WX@gmail.com
- Facebook: Colorado Severe Weather Network

---

## Author

**Jon Poindexter W5ALC** — Technical Systems Specialist & Consultant  
Jon.W5ALC@gmail.com

---

## License

[MIT License](LICENSE) — free to use, modify, and distribute with attribution.
