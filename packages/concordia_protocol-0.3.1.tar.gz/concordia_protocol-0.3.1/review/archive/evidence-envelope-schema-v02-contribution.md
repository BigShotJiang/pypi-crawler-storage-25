# Evidence Interchange RFC v0.2 — Schema Contribution

**For:** A2A Discussion #1734 (kenneives's pending v0.2 draft) and #1725 (JKHeadley's Concordia intake)
**Contributor:** Erik Newton (Verascore / Concordia Protocol)
**Target categories:** `transactional`, `sovereignty`
**Envelope schema version:** 1.0.0 (per thread consensus 2026-04-10)
**RFC iteration:** v0.2 (kenneives's draft pending, incorporating contributions through 2026-04-10)
**Status:** Final for posting — updated 2026-04-10 to reflect thread evolution through the addition of `graph_structural`, `compliance_risk`, and `wallet_state` categories; `refresh_hint` and `visibility` field-name alignment; revocation mechanism consensus; and verdict-TTL cascade rule.

---

## 1. Common envelope (shared across all categories)

The envelope is a JSON object with a detached JWS signature over its canonical form (RFC 8785 JCS, minus the `signature` field). This lets the envelope be human-readable and machine-verifiable without double-encoding the payload.

```json
{
  "envelope_version": "1.0.0",
  "envelope_id": "urn:uuid:01HZABCDE1234FGHJK5MNPQRST",
  "issued_at": "2026-04-10T18:30:00Z",
  "expires_at": "2026-04-17T18:30:00Z",
  "refresh_hint": {
    "strategy": "event_driven",
    "events": ["session_completed", "dispute_raised"],
    "max_age_seconds": 604800
  },
  "provider": {
    "did": "did:web:verascore.ai",
    "category": "transactional",
    "kid": "verascore-scoring-v1",
    "name": "Verascore"
  },
  "subject": {
    "did": "did:key:z6MkhaXgBZDvotDkL5257faiztiGiC2QtKLGpbnnEGta2doK"
  },
  "category": "transactional",
  "visibility": "public",
  "references": [
    {
      "kind": "source_session",
      "urn": "urn:concordia:session:01HZXYZ...",
      "hash": "sha256:a3f5..."
    },
    {
      "kind": "related_attestation",
      "urn": "urn:evidence:verascore:prior-transactional:01HZ..."
    }
  ],
  "payload": { /* category-specific — see §2 and §3 */ },
  "signature": {
    "alg": "EdDSA",
    "kid": "verascore-scoring-v1",
    "value": "base64url-detached-JWS-over-canonical-envelope-minus-signature"
  }
}
```

### Field definitions

| Field | Type | Required | Notes |
|---|---|---|---|
| `envelope_version` | semver string | yes | `1.0.0` per thread consensus 2026-04-10. Consumers MUST reject unknown major versions. Gateways SHOULD support at least one prior major version during 6-month deprecation windows. |
| `envelope_id` | URN | yes | Globally unique, UUIDv7 recommended for time-orderability. |
| `issued_at` | RFC 3339 UTC | yes | When the provider signed this envelope. |
| `expires_at` | RFC 3339 UTC | yes | Hard expiration. Consumers MUST NOT honor beyond this time. |
| `refresh_hint.strategy` | enum | yes | `event_driven` \| `periodic` \| `ttl_only`. Tells consumers how this attestation updates. |
| `refresh_hint.events` | string array | conditional | Required when `strategy = event_driven`. Names the events that invalidate this envelope. |
| `refresh_hint.max_age_seconds` | int | yes | Soft freshness budget — stricter than `expires_at`, consumer-enforced. |
| `provider.did` | DID | yes | The attestation issuer. Publishes JWKS at `{did-to-url}/.well-known/jwks.json`. |
| `provider.category` | enum | yes | The provider's primary declared category in the taxonomy. |
| `provider.kid` | string | yes | Key identifier matching an entry in the provider's JWKS. |
| `subject.did` | DID | yes | The agent this envelope describes. |
| `category` | enum | yes | The category of THIS envelope. Providers SHOULD emit separate envelopes per category rather than combining — see §5 on dual-homing. |
| `visibility` | enum | yes | `public` \| `restricted` \| `private`. See §4. (`restricted` refines JKHeadley's proposal with a context-URN requirement.) |
| `references` | array | no | Cross-links to source sessions, prior attestations, or supporting evidence. Each entry MUST include `kind` and `urn`; `hash` is strongly recommended. |
| `payload` | object | yes | Category-specific body. See §2 and §3. |
| `signature.alg` | JOSE alg | yes | `EdDSA` (Ed25519) is the recommended default; `ES256`, `ES256K` are also acceptable. |
| `signature.kid` | string | yes | MUST match `provider.kid`. |
| `signature.value` | base64url | yes | Detached JWS over RFC 8785 canonical form of the envelope with `signature` field removed. |

### Canonicalization and verification

1. Remove the `signature` field from the envelope JSON.
2. Serialize the remaining object using RFC 8785 JSON Canonicalization Scheme (JCS).
3. The detached JWS signature in `signature.value` is computed over the JCS bytes.
4. To verify: strip `signature`, re-serialize with JCS, fetch the provider's JWKS, locate the key by `kid`, verify the signature.

This matches the approach in Verascore's `/api/attestations/ingest` pipeline today and should align cleanly with kenneives's envelope scope from the v0.2 draft comment.

---

## 2. Category: `transactional`

### Definition

The `transactional` category attests to the outcome of structured agent-to-agent transactions — primarily negotiations producing binding commitments, but generalizable to any completed multi-round exchange with a signed result.

**What this category is for:**

- Negotiation outcomes from protocols like Concordia, A2CN, or any future structured-agreement protocol
- Binding commitment records where two agents reached a verifiable result
- Dispute signaling against prior commitments
- Counterparty-rating data that feeds composite trust scores

**What this category is NOT for:**

- Generic interaction history or behavioral observations (that's `behavioral` — MoltBridge's territory)
- Trust-graph topology (that's `graph_structural` — JKHeadley's category)
- Identity claims (`identity` category)
- Compliance risk posture (`compliance_risk` — AlexanderLawson17/Revettr's territory)
- On-chain solvency or wallet condition evaluation (`wallet_state` — InsumerAPI's territory)
- Security scans or static analysis (`static_analysis` — AgentGraph's territory)

### Payload schema

```json
{
  "session_id": "urn:concordia:session:01HZXYZ...",
  "session_protocol": "concordia",
  "session_protocol_version": "0.3.0",
  "outcome": "ACCEPTED",
  "counterparty_did": "did:key:z6Mko...",
  "completion_timestamp": "2026-04-10T18:15:00Z",
  "rounds_to_completion": 3,
  "commitment": {
    "committed": true,
    "commitment_hash": "sha256:b91c...",
    "honored": true,
    "honored_verified_at": "2026-04-10T18:25:00Z",
    "dispute_signal": null
  },
  "quality_signals": {
    "concession_magnitude": 0.42,
    "reasoning_quality": 0.85,
    "response_latency_p50_ms": 12000,
    "response_latency_p95_ms": 28000
  },
  "privacy_guarantees": {
    "deal_terms_disclosed": false,
    "counterparty_identity_disclosed": true,
    "zk_proof_available": true
  }
}
```

### Field definitions

| Field | Type | Required | Notes |
|---|---|---|---|
| `session_id` | URN | yes | Unique identifier for the underlying session. Protocol-specific prefix (`urn:concordia:session:`, `urn:a2cn:session:`, etc.). |
| `session_protocol` | enum | yes | `concordia` \| `a2cn` \| `acp` \| `ap2` \| `other`. Identifies the negotiation protocol. |
| `session_protocol_version` | semver string | yes | Protocol version the session ran under. |
| `outcome` | enum | yes | `ACCEPTED` \| `REJECTED` \| `WITHDRAWN` \| `IMPASSE` \| `DISPUTED` \| `TIMEOUT`. |
| `counterparty_did` | DID | yes | The other party in the session. |
| `completion_timestamp` | RFC 3339 UTC | yes | When the session reached its terminal state. |
| `rounds_to_completion` | int | no | Round count for protocols with a round model. |
| `commitment.committed` | bool | yes | Whether a binding commitment was produced. |
| `commitment.commitment_hash` | sha256 | conditional | Required when `committed = true`. Hash of the canonical commitment document. |
| `commitment.honored` | bool \| null | no | `null` means not yet verifiable. |
| `commitment.honored_verified_at` | RFC 3339 | conditional | Required when `honored` is `true` or `false`. |
| `commitment.dispute_signal` | object \| null | no | When a dispute is raised, this object carries the dispute URN and hash. |
| `quality_signals.concession_magnitude` | float 0.0–1.0 | no | How much the subject moved from opening position. |
| `quality_signals.reasoning_quality` | float 0.0–1.0 | no | Protocol-specific scoring of argument quality. |
| `quality_signals.response_latency_p50_ms` / `p95_ms` | int | no | Statistical latency distribution within the session. |
| `privacy_guarantees.deal_terms_disclosed` | bool | yes | MUST be `false` for sovereignty-preserving attestations. Deal terms never appear in the envelope. |
| `privacy_guarantees.counterparty_identity_disclosed` | bool | yes | Whether the counterparty DID is revealed in the envelope. |
| `privacy_guarantees.zk_proof_available` | bool | no | Whether a ZK competence proof is available on request. |

### TTL and refresh semantics

- **Default TTL:** 7 days from `completion_timestamp` (aligned to the thread's category-default table). Longer TTLs are permitted per provider policy but consumers SHOULD treat anything beyond 30 days as archival, not active signal.
- **Refresh strategy:** `event_driven`. The events that invalidate a transactional envelope are `dispute_raised`, `commitment_verified` (status transition), `new_settlement` (supersession), and `envelope_revoked`.
- **Verdict cascade rule:** per thread consensus, any verdict consuming this envelope MUST expire no later than this envelope's `expires_at`. Gateways that produce composite verdicts inherit the shortest TTL in their evidence bundle.
- **Stale handling:** Beyond `expires_at`, consumers MUST treat the envelope as historical and MUST NOT weight it in real-time scoring. Providers SHOULD re-issue before expiration with a fresh `issued_at`.

### Reference implementation

Concordia Protocol v0.3.0+ emits transactional envelopes from every terminated session via `concordia_session_receipt_export`. The Concordia receipt format already carries every field in the payload schema above; the v1.0.0 envelope wrapper is a pure re-packaging with no lossy conversion. Concordia receipts sign with Ed25519 by default.

---

## 3. Category: `sovereignty`

### Definition

The `sovereignty` category attests to an agent's structural sovereignty posture — whether the agent controls its own keys, isolates its own operations, discloses selectively, and carries portable reputation. It is a capability-level attestation, not a behavioral one.

**What this category is for:**

- Sanctuary Health Report (SHR) data and equivalents
- L1 (cognitive sovereignty) / L2 (operational isolation) / L3 (selective disclosure) / L4 (verifiable reputation) layer status
- Capability manifest attestations
- Key custody and identity-control claims

**What this category is NOT for:**

- Runtime performance, availability, or behavioral observations (that's `behavioral` / `continuous_monitoring`)
- Trust-graph topology (that's `graph_structural`)
- Negotiation competence (that's `transactional`)
- Compliance posture, sanctions screening, or regulatory signals (that's `compliance_risk`)
- On-chain solvency or wallet condition evaluation (that's `wallet_state`)
- Security vulnerability scans or static analysis (that's `static_analysis`)

### Payload schema

```json
{
  "framework": "sanctuary",
  "framework_version": "0.7.0",
  "shr_version": "1.2",
  "overall_rating": "MINIMUM_VIABLE",
  "layers": {
    "l1_cognitive": {
      "status": "FULL",
      "score": 100,
      "capabilities_present": ["self_hosted_weights", "prompt_isolation", "key_custody"],
      "capabilities_missing": [],
      "evidence_hash": "sha256:a1b2..."
    },
    "l2_operational_isolation": {
      "status": "DEGRADED",
      "score": 60,
      "capabilities_present": ["sandbox", "network_policy"],
      "capabilities_missing": ["tee"],
      "evidence_hash": "sha256:c3d4..."
    },
    "l3_selective_disclosure": {
      "status": "FULL",
      "score": 100,
      "capabilities_present": ["schnorr", "pedersen_commitment", "range_proofs"],
      "capabilities_missing": [],
      "evidence_hash": "sha256:e5f6..."
    },
    "l4_verifiable_reputation": {
      "status": "FULL",
      "score": 100,
      "capabilities_present": ["ed25519_identity", "did_resolution", "attestation_publish"],
      "capabilities_missing": [],
      "evidence_hash": "sha256:g7h8..."
    }
  },
  "capability_manifest_hash": "sha256:i9j0...",
  "attestation_mode": "self_attested",
  "verifier": null,
  "known_degradations": [
    {
      "layer": "l2",
      "reason": "no_tee_available",
      "severity": "partial",
      "compensating_controls": ["process_isolation", "syscall_filter"]
    }
  ]
}
```

### Field definitions

| Field | Type | Required | Notes |
|---|---|---|---|
| `framework` | enum | yes | `sanctuary` \| `custom` \| `other`. Names the sovereignty framework the attestation is based on. |
| `framework_version` | semver | yes | Version of the framework used to produce the attestation. |
| `shr_version` | string | conditional | Required when `framework = sanctuary`. |
| `overall_rating` | enum | yes | `FULL` \| `MINIMUM_VIABLE` \| `DEGRADED` \| `NONE`. Derived, not independently signed. |
| `layers.lN.status` | enum | yes | Per-layer status. Same enum as overall. |
| `layers.lN.score` | int 0–100 | yes | Quantitative score for the layer. |
| `layers.lN.capabilities_present` | string array | yes | Named capabilities verified present. Vocabulary is framework-defined. |
| `layers.lN.capabilities_missing` | string array | yes | Named capabilities expected but absent. |
| `layers.lN.evidence_hash` | sha256 | yes | Hash of the underlying evidence document (audit log excerpt, capability probe output, etc.). Evidence itself is fetched via `references`. |
| `capability_manifest_hash` | sha256 | yes | Hash of the agent's capability manifest at the time of attestation. Changes in this hash MUST trigger re-issuance. |
| `attestation_mode` | enum | yes | `self_attested` \| `verifier_attested` \| `peer_attested`. |
| `verifier` | object \| null | conditional | Required when `attestation_mode != self_attested`. Carries verifier DID and tool identifier. |
| `known_degradations` | array | no | Enumerates intentional or environmental degradations with compensating controls. |

### TTL and refresh semantics

- **Default TTL:** no fixed TTL (aligned to the thread's category-default table for sovereignty). Sovereignty posture is stable across runtime lifetimes and changes only on explicit config events.
- **Refresh strategy:** `event_driven` with `ttl_only` fallback. Trigger events: `capability_manifest_changed`, `runtime_reconfigured`, `key_rotated`, `framework_upgraded`, `policy_change`.
- **Verdict cascade rule:** per thread consensus, any verdict consuming this envelope MUST expire no later than this envelope's `expires_at`. Providers issuing open-ended sovereignty attestations SHOULD nonetheless set `expires_at` to bound downstream verdict lifetimes (suggested: 30 days with event-driven re-issuance).
- **Stale handling:** Beyond `expires_at`, consumers MUST treat sovereignty claims as unverified. Self-attested envelopes should be weighted lower than verifier-attested envelopes.

### Reference implementation

Sanctuary Framework v0.7.0+ emits sovereignty envelopes via the `audit_export_siem` and `reputation_publish` tools. Sanctuary SHR data populates every field in the payload above directly; the envelope wrapper is a pure re-packaging. Sanctuary signs with Ed25519. Verifier-attested envelopes can be produced by running Sanctuary's audit tools against a target agent and signing with the auditor's key rather than the subject's.

---

## 4. `visibility` field semantics

This field adopts JKHeadley's `public|restricted|private` naming from the thread, with `restricted` refined to carry an explicit context URN requirement.

| Value | Meaning | Consumer obligations |
|---|---|---|
| `public` | The envelope is safe to display in any aggregation surface, leaderboard, or public score. | No restrictions. |
| `restricted` | The envelope is only valid in the context of a specific relationship or session. The `references` array MUST name the context. | Consumers MUST verify the context URN before honoring. |
| `private` | The envelope is addressed to a specific consumer and should not be redistributed. The consumer DID MUST appear in the envelope's `references` array with `kind: addressed_to`. | Consumers MUST NOT republish or aggregate. |

Transactional envelopes carrying commitment or dispute data SHOULD default to `restricted` unless both parties have agreed to public disclosure. Sovereignty envelopes SHOULD default to `public` — sovereignty is a capability advertisement.

---

## 5. Positions, adoptions, and remaining open questions

### Adopted from thread consensus (2026-04-10)

1. **Envelope revocation (resolved).** The thread converged on a v1 status-endpoint mechanism: `GET /attestation/{id}/status` returning `active | revoked | expired`. This contribution adopts that mechanism without modification. v2 may add event-driven push revocation for high-stakes categories (compliance_risk explicitly, sovereignty on key-compromise events). Consumers MUST check revocation status before honoring any envelope within its `expires_at` window.

2. **Dual-homing position.** The thread flagged dual-homing (multiple categories per envelope) as unresolved. This contribution takes an explicit position: **providers SHOULD emit separate envelopes per category**, not combine. A Concordia session that produces both a transactional outcome and a sovereignty posture change should emit two envelopes cross-linked via `references`. Rationale: separate envelopes preserve clean provenance, allow category-specific TTLs to apply independently, and match the verdict-cascade rule without ambiguity about which expiration dominates.

3. **v0.3 category grouping preview.** The thread previewed (but deferred) a pre-interaction / runtime / post-interaction grouping. Under that grouping, `sovereignty` belongs in **runtime** (capability posture at the time of invocation) and `transactional` belongs in **post-interaction** (evidence of a completed exchange). Both categories in this contribution are authored with that grouping in mind; no schema change should be required when v0.3 lands.

4. **Vocabulary crosswalks.** The thread established `aeoess/agent-governance-vocabulary` as the crosswalk repository between the RFC taxonomy and existing signal vocabularies (notably the MULTI-ATTESTATION-SPEC). Concordia and Sanctuary SHOULD contribute crosswalks mapping Concordia's `session_protocol` values and Sanctuary's SHR layer identifiers to the canonical vocabulary entries.

### Still open, requesting RFC resolution

5. **Cross-category references.** A transactional envelope may want to reference a sovereignty envelope of the counterparty ("I negotiated with an MVS-level agent"). The `references` array supports this but the RFC should specify the expected resolution behavior — do consumers fetch the referenced envelope automatically, or only on demand? I lean on-demand with a consumer-controlled fetch budget.

6. **Aggregation semantics.** When multiple providers emit envelopes for the same subject in the same category, how should a consumer reconcile conflicts? I proposed a weight-by-provider-category approach (3x verified, 1.5x cross-corroboration, 10% diversity bonus) in Verascore; the RFC should document a default reconciliation pattern or leave it explicitly to consumers.

7. **Protocol-layer binding.** Should the envelope mandate a specific transport binding (HTTPS + content-type), or is it transport-agnostic? I lean transport-agnostic — the envelope should be valid over email, IPFS, or any byte-carrying channel as long as the signature verifies.

---

## 6. Notes for Erik before posting

- **Length:** ~5 pages printed. Longer than the typical thread post but appropriate for a schema contribution. I recommend posting a condensed version to #1734 (just §1, §2, §3 headline blocks) and linking to the full document on GitHub Gist or Concordia's `docs/` directory for the full spec.
- **Cross-posting to #1725:** The `transactional` section is exactly what JKHeadley asked for — the JWS receipt intake schema for Concordia negotiation outcomes. When you reply to him in #1725, reference this document and say "the Concordia receipt format is the reference implementation for the `transactional` category in the RFC I'm contributing to #1734."
- **Conservatism markers:** I kept all the category definitions narrow and explicit about what they are NOT. This prevents scope creep from other contributors and gives you the authority to push back when someone tries to stuff behavioral or security data into `transactional`/`sovereignty`.
- **Ed25519 positioning:** I made Ed25519 the recommended default in §1 but the envelope accepts `ES256` and `ES256K` as acceptable alternates. This lets A2CN (ES256) and Revettr (ES256) compose without friction while keeping the ecosystem-composability argument for Ed25519 intact.
- **Two missing pieces for you to decide:**
  1. Do you want to include `session_protocol_version` as required or optional in the transactional schema? Required is more rigorous but forces every emitter to declare a version. I made it required; easy to relax.
  2. `quality_signals.reasoning_quality` is subjective and protocol-specific. Keeping it in the schema gives Concordia a differentiator (Concordia can score reasoning quality; competing protocols may not). Cutting it keeps the schema cleaner and vendor-neutral. I kept it in — your call.

---

## 7. Publication plan

1. Save this document as canonical source at `Concordia/docs/evidence-envelope-v0.2.md` (move out of `review/` after Erik approval).
2. Post condensed §1/§2/§3 summary + link to the full doc as a comment in A2A Discussion #1734 **before kenneives finalizes the pending v0.2 draft** — the thread is actively consolidating contributions and this should land before the draft freezes.
3. Reply to JKHeadley in #1725 referencing this document as the Concordia receipt intake schema and the `transactional` category reference implementation.
4. Contribute Concordia and Sanctuary vocabulary crosswalks to `aeoess/agent-governance-vocabulary` — map `session_protocol` values and SHR layer identifiers to canonical vocabulary entries.
5. Once #1734 v0.2 lands, diff the kenneives draft against this contribution and log any divergences in `Wiki/projects/evidence-interchange-rfc.md` (create this entry at that time; it has crossed the traction threshold).
