# A2A Discussion #1734 — Reply (April 11, 2026)

**For:** Public post on `a2aproject/A2A` Discussion #1734
**Responding to:** AlexanderLawson17's live Revettr round-trip ask, his adoption of transactional/sovereignty, nanookclaw's validity_temporal framing, aeoess's verification pass, douglasborthwick-crypto's Section 3.x ratification, the trust-evidence-format org spin-up
**Status:** Draft for Erik's review. Nothing posted yet. Monday delivery window on the engineering commitments.

---

@AlexanderLawson17 — picking up the live round-trip ask directly, because it's the most concrete thing on the thread, and I want to be honest about the shape of it rather than overpromise a plug-and-play experience you'd then have to debug.

**Verascore intake: current state and what needs to ship by Monday.**

The endpoint exists: `POST https://verascore.ai/api/attestations/ingest`. But the round-trip you're asking for is gated on three small code changes on my side, and rather than hand-wave them, here they are explicitly:

1. **Revettr is not currently in the Verascore provider registry.** Four providers are seeded today — AgentGraph, MoltBridge, Concordia, Sanctuary. Adding Revettr is a small registry entry: issuer DID `did:web:revettr.com`, JWKS URL `https://revettr.com/.well-known/jwks.json`, `providerType: compliance_risk`, kid `revettr-attest-v1`. Without this entry, the POST returns `unknown_provider`.
2. **The current verifier only accepts EdDSA.** The JWS verification path in `jwks-cache.ts` has `algorithms: ["EdDSA"]` hard-coded. Your envelope is ES256 (which is the right choice for Revettr's key material) and the verifier needs `ES256` added to the allowed list. This is the Concordia-side ES256 commitment I'm making in #1737 cashed out on the Verascore side as well.
3. **Today's intake accepts a wrapped JSON body, not a bare detached JWS.** The current shape is `{ provider, subjectDid, attestationType, scope, jws, evidenceUrl }` where the JWS compact-form token you posted above goes in the `jws` field, with `provider: "revettr"`, `subjectDid: "did:pkh:eip155:1:0xd8da6bf26964af9d7eed9e03e53415d37aa96045"` (mapping the raw EOA into a `did:pkh`), `attestationType: "compliance_risk"`, `scope: "agent"`. I'd rather converge on the flat schema the v0.2 envelope is landing on — the JWS as the source of truth, with the wrapper extracting `provider.did`, `provider.category`, `signature.alg`, `signature.kid`, `subject.id`, `issued_at`, `expires_at`, `payload` as top-level fields — and I'm going to add that flat-shape intake path alongside the current wrapped one so both work during the transition.

**Delivery window:** I'm offline this weekend on family commitments, so the honest target for all three changes is **Monday, April 13**. I'll land them as a single PR, ping you here when it's live, and the round-trip on the envelope you posted above should round-trip cleanly on first POST after that; if it doesn't, the failure mode will be fast and debuggable. If you want to exercise the wrapped intake before Monday with a bare EdDSA-signed test envelope against the four already-seeded providers (just to confirm the wrapper contract from your side), the code path is live today and you're welcome to use it — just not against the ES256 Revettr envelope specifically.

**On the two gaps you self-flagged in your envelope:**

1. **`references[]` field.** Lock the shape now. Key name is `references`, array-valued, each element is an object with at minimum `{kind, urn}` where `kind` is a controlled vocabulary (`source_session`, `list_update`, `chain_state`, `upstream_envelope`, `mandate_proof` — extensible) and `urn` is a stable identifier the downstream consumer can dereference. For `list_update` specifically, the URN shape I'd propose is `urn:<authority>:<list>:<YYYY-MM-DD>`, which matches your `urn:ofac:sdn:2026-04-10` example exactly. Optional fields per element: `verified_at` (integer unix seconds), `verifier_did` (if a third party verified the reference), and `hash` (SHA-256 over the referenced artifact's canonical form, for content-binding). Ship it ahead of v0.2 whenever you're ready — I'll mirror the exact same shape in Concordia's transactional envelopes so the verifier path is identical across categories.

2. **Outer wrapper.** Normalize to the flat schema per the structure above, not the `@context` + provider object form. That's the shape the Monday PR will add on the intake side, and it's the shape I'll mirror in Concordia v0.4.0 outputs.

**On @nanookclaw's `validity_temporal` framing.** Adopting it for transactional and sovereignty envelopes as well. The sequence-vs-windowed split is exactly right: transactional envelopes that cover a single negotiation session are `mode: sequence` with the session identifier as the sequence key, while sovereignty envelopes that cover a standing capability posture (L1–L4 health) are `mode: windowed` with a refresh cadence bound to capability-change events rather than wall-clock. `aliasing_risk: boundary` + `minimum_window: PT1H` maps cleanly onto the sovereignty contract "the L3 posture you see right now reflects state at most PT1H ago, refresh if you need tighter." Credit to nanookclaw — the framing generalizes beyond wallet_state and I'd support landing it as a cross-category primitive in the v0.2 envelope rather than a category-specific field.

@nanookclaw — if you're open to generalizing `validity_temporal` into a cross-category block for v0.2, I'd like to co-author that section with you. Low overhead on your side, just a shared definition and a note that `transactional`, `sovereignty`, `compliance_risk`, and `wallet_state` all adopt it. Say the word and I'll draft.

**On the Revettr scope reconciliation (RETRACTED row 1 + re-homing to row 3 `wallet_intelligence`).** The move is clean and the discipline is worth naming. "Revettr produces summary statistics, not predicate outcomes against caller-supplied conditions" is the right scope line, and landing RETRACTED as a historical marker rather than a silent rewrite is how you preserve the reasoning trail for the next reviewer. Same discipline I'd want applied if I were on the other side of a scope misreading. No objection, and the `dual_home_candidate` framing on row 3 may indeed need revisiting once your Revettr entry lands — flagging as a reviewer note for the v0.2 pass, not a blocker, same as @douglasborthwick-crypto's read.

**On @aeoess's findings-rather-than-silent-reconciliation pass.** This is the right verification posture for a multi-issuer spec, and I'd like the pattern to survive the venue move. Findings A–D are handled correctly: A as part of 3.x ratification not piecemeal, B as PR #4 on the vocabulary repo, C as a known count slip that landed anyway, D preserved verbatim as a WG decision surface. The per-system-authorship discipline ("each issuer's row is theirs to confirm, not mine to confirm on their behalf") is how this scales past three contributors without fracturing, and it's a governance norm worth writing into the trust-evidence-format org charter when we spin it up.

**On the trust-evidence-format org spin-up.** Committing here on the public thread to what I said earlier in the session: I'm in on co-founding the org with @kenneives and @AlexanderLawson17, and I'll drive the concrete spin-up steps starting Monday. Proposed shape:

1. **Name.** `trust-evidence-format` as the org handle. Not attached — if @kenneives has a preference, his call.
2. **Repo structure.** `spec/` (the RFC itself, currently #1734), `vocabulary/` (moved from `aeoess/agent-governance-vocabulary` via explicit rename/transfer per @aeoess and @douglasborthwick-crypto's ask, not fork-and-archive), `reference-implementations/` (one subdirectory per contributing issuer, commit rights passed day-one to each maintainer), `governance/` (the org charter, contribution norms, and the partner-tier framework Alexander raised).
3. **Founders and initial committers.** @kenneives, @eriknewton, @AlexanderLawson17 as initial co-owners. @douglasborthwick-crypto and @aeoess as initial committers with commit rights to their respective reference implementations and vocabulary sections from day one. I'd like to invite @JKHeadley (MoltBridge) as initial committer on the graph-structural side and @nanookclaw on the validity_temporal/PDR side, if they're interested.
4. **Migration governance.** The vocabulary repo moves as an explicit, pre-announced transfer — every prior contributor gets advance notice with PR history intact under the new URL, no fork-and-archive. Same for any reference implementation that wants to relocate.
5. **Partner-tier framework (per Alexander's side note).** The org charter will carry a reciprocal partner / reference-impl tier between contributing issuers, so co-authors of the same spec aren't metering each other on standard pay-as-you-go. Exact shape to be drafted with Alexander separately before it lands in the charter, since this is the piece most likely to have commercial-structure implications for each issuer.

**Rough timeline for the spin-up** (Monday-start, since I'm offline this weekend):

- **Mon Apr 13:** Org created, initial owners and committers invited, README + governance placeholder committed. Verascore intake PR (Revettr registry + ES256 + flat-shape path) landed in parallel.
- **Mon Apr 13–Fri Apr 17:** Vocabulary transfer announcement drafted and circulated to every prior contributor with a two-week notice window before the actual transfer.
- **Fri Apr 17–Fri May 1:** Vocabulary transfer window. Anyone with a landed PR or in-flight PR has two weeks to flag concerns or request an alternative destination.
- **Mon May 4:** Vocabulary transfer executed. v0.2 drafting starts under the new org.

If anyone wants to block any of this, speak up now — I'd rather catch objections in the open thread than after the transfer. If anyone wants to accelerate, say so and I'll compress where possible; the weekend gap is a hard constraint but the weekday plan is adjustable.

**On Concordia adopting ES256 as alternate.** Committing it here publicly as well: Concordia v0.4.0 will accept ES256 alongside EdDSA for envelope signing, with a matching commitment on the A2CN side under discussion via a separate channel. Net effect by v0.2 ratification: any issuer in this thread can sign with either suite, and verifiers can run a single verification path across all eight categories (five v0.1 + `transactional`, `sovereignty`, `compliance_risk`, `wallet_state`, plus `graph-structural` if that lands as a ninth).

**Standing asks I owe specific people:**

- **@AlexanderLawson17:** Verascore intake PR (Revettr provider registry + ES256 verifier + flat-shape intake path) landing Monday. Will ping here when it's live. Round-trip should work on first POST after that. Also — on the partner-tier side note, acknowledged and fully agreed; drafting a first cut of that reciprocal structure as part of the org charter and will email you separately before it lands in the governance repo.
- **@kenneives:** Ready to co-sign on the org spin-up as soon as you confirm the name and the initial committer list above. Your call on the handle.
- **@douglasborthwick-crypto:** Standing by for the PR #4 merge and the 3.x ratification. Acknowledging the Finding A deferral to 3.x is the right move, and the RETRACTED historical-marker approach on row 1 is the discipline I want the whole spec to inherit.
- **@aeoess:** Your verification posture is the one I want the org to inherit. Would you be willing to land the governance norms around findings-rather-than-silent-reconciliation and per-system-authorship as a first PR into `governance/` after the org spin-up? You're the natural author.
- **@nanookclaw:** The `validity_temporal` framing is the right primitive for more than wallet_state. If you're open to co-authoring a cross-category block for the v0.2 envelope, let's sync early next week.

Good convergence on this thread. The spec is getting sharper every pass, and the governance norms are landing cleanly alongside the technical ones, which is rarer than it should be.

— Erik

Erik Newton
Concordia Protocol · Verascore
github.com/eriknewton
