# Concordia Multi-Party Commit (CMPC)

**A proposed extension to Concordia for general multi-party commitment between agents.**

**Status:** Draft for external review and discussion. Not a finalized specification.
**Author:** Erik Newton
**Date:** 2026-04-10
**Version:** 0.1 (draft)

---

## 1. Summary

Concordia today defines a bilateral negotiation protocol: two agents exchange structured proposals, reach terms, and produce signed session receipts. This document proposes a small family of primitives that extend Concordia to general multi-party commitment — negotiations in which three or more agents must bind together, with each party's commitment conditional on the commitments of others, and with atomic activation of the whole set or none of it.

The proposed extension is named **Concordia Multi-Party Commit (CMPC)**. Its goal is to give agents a clean, cryptographically-grounded way to coordinate commitments across dependent chains — for example, a manufacturer, its suppliers, and its suppliers' suppliers agreeing simultaneously rather than sequentially. The primitives are designed to compose with existing Concordia bilateral primitives and with existing agent communication transports (A2A, ACP, ANP, MCP) without replacing any of them.

CMPC does not require a blockchain. It builds on published work in optimistic fair exchange, conditional commitment games, atomic commitment across distributed systems, and certificate transparency. The intended contribution is the composition of these primitives into a single coherent family targeted at agent-native negotiation, not the invention of new cryptographic machinery.

This draft is circulated for technical review and discussion. Feedback on primitive shape, naming, trust model, and prior-art coverage is invited before any of it is hardened into a specification.

## 2. Problem statement

Bilateral negotiation captures only a fraction of real commercial coordination. Most meaningful commitments sit inside chains where each party's willingness to bind depends on other parties' willingness to bind. A manufacturer cannot safely commit to raw material volumes without knowing its customers will take the finished goods; those customers cannot safely commit without their own downstream commitments; the dependency compounds through every tier of the chain.

Current practice resolves this with out-of-band coordination — phone calls, letters of intent, conditional contracts, standing inventory buffers, safety stock, and the general coordination premium that shows up in supply chain literature as the bullwhip effect. These mechanisms work but are slow, expensive, opaque, and ill-suited to automation by agents.

An agent-native protocol for multi-party commitment should let an agent:

- propose a commitment that binds if and only if other named commitments exist and verify,
- participate in a shared session where the topology and state of a multi-party negotiation are explicit,
- selectively disclose the information each counterparty needs to evaluate the commitment, without leaking anything else,
- observe the chain atomically activate (or not) based on a pre-declared condition over all commitments in the session,
- recover gracefully if the chain partially fails after activation.

No open protocol currently provides this. Bilateral negotiation protocols (Concordia v0.3, A2CN) provide the pairwise primitives but not the multi-party composition. General atomic commitment protocols from distributed databases provide the atomicity machinery but not the negotiation, disclosure, or reputation primitives. Multi-party contract signing protocols from cryptography provide the fairness and non-repudiation but are not designed for agent-era message transports or for the open-ended topologies of supply chain negotiation. This proposal attempts to close that gap.

## 3. Design goals

1. **Composability over invention.** Every primitive should extend a published result from cryptography, game theory, distributed systems, or web infrastructure. The contribution is the coherent composition, not new cryptographic machinery.
2. **Optionality over mandate.** The coordinator role, selective disclosure level, and atomicity guarantees are all per-session configurations. A deployment should be able to run CMPC with a trusted coordinator, with a witness network, or entirely peer-to-peer.
3. **No blockchain required.** The base protocol must provide append-only, tamper-evident history using Certificate Transparency-style Merkle logs. Blockchain anchoring is permitted as an optional plug-in for deployments that want additional durability.
4. **LLM-tractable predicates.** The language used to express activation conditions must be one that language models can generate and reason about reliably, which rules out Turing-complete scripting and favors restricted boolean-arithmetic expressions over named envelope fields.
5. **Transport-agnostic.** CMPC primitives must work above any message substrate (A2A, ACP, ANP, MCP, or a proprietary channel). No dependency on a specific agent communication protocol.
6. **Non-coupling with adjacent layers.** CMPC must not require Sanctuary, Verascore, or any other reputation or sovereignty layer. It should compose with any of them cleanly, but an agent that only runs CMPC must be able to participate fully.
7. **Honest sacrifices.** Where classical impossibility results (Myerson-Satterthwaite, CAP) force a tradeoff, the protocol should make the sacrifice explicit in the specification rather than hiding it.

## 4. The primitive set

CMPC proposes ten primitives, organized into three tiers. The first four are load-bearing and define the new capability. The next three are supporting and refine its behavior. The final three are infrastructure primitives that either exist in Concordia today or are already scheduled for the next point release.

### 4.1 Load-bearing primitives

**Commitment Envelope.** A typed, signed, timestamped object representing an offer or commitment. Fields include: issuer DID, envelope type, content hash, predicate reference, nonce, expiration, disclosure policy reference, mandate proof reference, and signature. The Commitment Envelope is the atomic unit of multi-party negotiation. It generalizes the session receipt already defined in Concordia v0.3 and adds a predicate reference field.

**Conditional Commitment.** A Commitment Envelope whose predicate reference points to a Closure Predicate over other Commitment Envelopes in the same session. Semantics: the commitment binds the issuer if and only if the referenced predicate evaluates true against the current state of the session. Until the predicate is satisfied, the commitment is valid, signed, and binding-if-activated, but not yet binding. When the predicate is satisfied, the commitment activates atomically across the session. This is a two-phase commit primitive for agreements, directly analogous to atomic commit in distributed databases and to the conditional commitment devices formalized in Oesterheld and Conitzer's work on commitment games.

**Closure Predicate.** A boolean-arithmetic expression over a set of Commitment Envelope hashes in a session. The expression language is intentionally not Turing-complete. It supports conjunction, disjunction, negation, counted-subset predicates ("any k of n"), and threshold conditions over numeric envelope fields. The restriction on expressive power serves four purposes: predicate satisfaction is decidable in bounded time, any participant with session state can evaluate the predicate, predicate satisfaction can be proven in zero-knowledge using existing commitment schemes without revealing the values that satisfied it, and language models can generate and reason about predicates reliably.

**Chain Session.** A shared coordination object representing a multi-party negotiation. A Chain Session contains: a session identifier, a topology expressed as a directed acyclic graph of participant DIDs and commitment dependency edges, a list of Commitment Envelopes, a list of Closure Predicates, the current session state, the unwind rules agreed at session creation, an optional coordinator reference, and a pointer to the session's transparency log. Every Commitment Envelope in a multi-party negotiation references exactly one Chain Session. The session defines the scope of atomicity.

### 4.2 Supporting primitives

**Disclosure Policy.** A per-participant rule set attached to a Commitment Envelope specifying which fields of the envelope each counterparty, role, or coordinator is allowed to see. Disclosure Policies are enforced via selective disclosure primitives already available in the broader Concordia ecosystem: Pedersen commitments for hidden values, range proofs for "value is in [a,b] without revealing value," Schnorr proofs for predicate satisfaction without value revelation. Disclosure Policies compose with Closure Predicates: a predicate can be proven satisfied without any participant learning the values that satisfied it.

**Atomic Activation Proof.** A signed object asserting that the Closure Predicate of a specific Chain Session became satisfied at a specific timestamp, listing the content hashes of the activating commitments. The proof is signed either by every participant or by a coordinator acting on their behalf, depending on the deployment mode. This is the artifact that survives the session and anchors enforceability in downstream legal or settlement systems. In most deployments it is the only object that needs durable, long-term storage.

**Unwind Protocol.** Pre-declared rules in the Chain Session specifying what happens if a Commitment Envelope fails after activation. Supported modes include all-or-nothing (any failure cascades the entire chain), partition-tolerant (specified subsets can survive independently), and graceful-degradation (activated commitments hold, failed commitments trigger pre-specified substitutions). Unwind rules are part of the Chain Session object, signed by all participants at session creation, and cannot be unilaterally changed after commitments are made.

### 4.3 Infrastructure primitives

**Ed25519 Session Receipts.** Already defined in Concordia v0.3. Reused as the signing substrate for Commitment Envelopes and Atomic Activation Proofs.

**Transparency Log Anchor.** An append-only Merkle-structured log holding Commitment Envelope hashes, Atomic Activation Proofs, and unwind signals, with periodic checkpoints signed by the log operator. The log design follows Certificate Transparency (RFC 6962) and its successors. Log operators can be federated. Independent monitors watch for equivocation. Sessions may share a log or maintain individual logs depending on deployment needs.

**Mandate Proof.** A verifiable credential demonstrating that an agent has authority from its principal to issue commitments of a specified class up to a specified magnitude. Mandate verification is load-bearing for multi-party sessions because the invalidity of a single commitment (due to an agent exceeding its mandate) can invalidate a whole chain. Mandate Proof is already scheduled for inclusion in the next Concordia point release following coordination with the A2CN protocol authors.

## 5. Trust, atomicity, and deployment modes

CMPC supports three trust modes for Chain Session coordination, selected per session at creation time. The choice reflects standard tradeoffs from the atomic commitment and fair exchange literature.

**Peer mode.** No coordinator. Participants exchange Commitment Envelopes directly and each evaluates the Closure Predicate independently. When any participant detects predicate satisfaction, it broadcasts a signed Atomic Activation Proof. Other participants verify and countersign. This mode is most trust-minimizing but has the highest message complexity and is most sensitive to network partitions.

**Optimistic coordinator mode.** A designated coordinator observes session state and proposes Atomic Activation Proofs when it detects predicate satisfaction. Participants verify and sign. The coordinator is not trusted to bind any participant; its role is to reduce message complexity and drive convergence on the happy path. This mirrors the optimistic fair exchange model of Asokan, Shoup, and Waidner, and the related work of Garay and MacKenzie, in which a trusted third party is only invoked to resolve disputes and is otherwise bypassed.

**Witness network mode.** A federation of neutral witness agents observes the session and jointly signs the Atomic Activation Proof using a threshold signature scheme. This replaces a single trusted coordinator with a collective that can tolerate some fraction of witness failure or malice. The design follows Zakhary et al.'s AC3WN approach to atomic commitment across blockchains and adapts it to agent-era negotiation sessions. Witness networks compose naturally with existing agent reputation systems for witness selection.

In all three modes, atomicity guarantees under network partition are bounded by the CAP theorem. Chain Sessions may configure a `consistency_mode` parameter with values `strict`, `eventual`, or `byzantine`, with corresponding tradeoffs in latency, availability, and fault tolerance. The specification should make these tradeoffs explicit rather than hiding them behind a single default.

## 6. The transparency log and why no blockchain is required

CMPC's transparency log is the single most consequential design decision for production deployment. The goal is an append-only, tamper-evident, publicly-verifiable record of all Commitment Envelopes, Atomic Activation Proofs, and unwind signals associated with a session, without requiring distributed consensus.

Certificate Transparency has provided exactly this service for the global web PKI since 2013 without a blockchain. The CT architecture consists of append-only Merkle trees operated by independent log operators, Signed Certificate Timestamps issued by logs as a promise to include a certificate within a bounded maximum merge delay, monitors that periodically download logs and watch for misbehavior, and auditors that verify individual inclusion proofs. The same architecture transfers directly to commitment envelopes.

CMPC proposes to rename Signed Certificate Timestamps as **Signed Commitment Timestamps**, preserving the semantics. Each Commitment Envelope, upon being logged, produces an SCT that the issuer can include in signed communications as proof that the envelope is globally visible. Monitors watch for log equivocation. Gossip protocols between clients and auditors detect inconsistent log states without requiring consensus.

The cryptographic primitives CMPC already requires — Ed25519 signatures, Merkle commitments, DIDs, portable receipts — provide everything blockchains would provide except append-only global ordering with public verifiability, and Certificate Transparency provides that cleanly at internet scale with a decade of operational evidence.

For deployments that want additional durability guarantees, the CMPC transparency log root may optionally be periodically anchored to a public blockchain. In this configuration, only the log root hash is written on-chain — no commitment content, no participant identifiers, no envelope data. Anchoring is a plug-in, not a dependency. Deployments that cannot or prefer not to use a blockchain run the base protocol without one.

## 7. Honest sacrifices

The protocol makes three tradeoffs explicit.

**Myerson-Satterthwaite.** No multi-party negotiation mechanism can simultaneously be fully efficient, individually rational, incentive-compatible, and budget-balanced. CMPC sacrifices full efficiency and preserves the other three. The protocol finds good-enough solutions rather than provably optimal ones. This should be stated plainly in any specification derived from this draft.

**CAP and partition tolerance.** Distributed atomic commitment cannot simultaneously provide fast convergence, full privacy, and guaranteed atomicity under arbitrary network partition. CMPC exposes the tradeoff as a per-session configuration rather than picking one point silently.

**Scope of what the protocol binds.** CMPC binds agents to their commitments. It does not eliminate demand uncertainty upstream of the chain, does not replace human legal review for high-value agreements, and does not resolve jurisdictional conflicts between participants in different legal regimes. The protocol compresses the human review cycle by making the commitment object itself carry enforceability primitives, but it does not remove the human entirely from consequential negotiations and should not claim to.

## 8. Relation to prior work

CMPC draws on a substantial body of published research. The contribution is the composition; the primitives are borrowed.

**Optimistic fair exchange.** Asokan, Shoup, and Waidner (1998) and Garay and MacKenzie (1999) established the foundational cryptographic framework for multi-party contract signing with an optional trusted third party invoked only on dispute. The coordinator role in CMPC's optimistic mode and the vocabulary of abort and resolve tokens are taken directly from this line of work.

**Commitment games with conditional information disclosure.** Oesterheld and Conitzer (AAAI 2023) formalize conditional commitment devices game-theoretically and prove sufficient conditions for ex-post efficient cooperation without a third-party mediator. The Closure Predicate primitive is a cryptographic implementation of their conditional commitment device. CMPC inherits their theoretical framing.

**Atomic commitment across distributed systems.** Classical two-phase and three-phase commit protocols from database systems provide the atomicity machinery CMPC adapts. Zakhary et al.'s AC3WN (VLDB 2020) extends this to cross-blockchain atomic commitment with a witness network, and their witness-network design is the direct ancestor of CMPC's witness network mode.

**Multi-party contract signing.** The broader MPCS literature, including the fair exchange protocols of Asokan-Shoup-Waidner and the subsequent work of Garay, MacKenzie, and others, provides the cryptographic foundation for binding multiple parties to a shared agreement. CMPC positions itself as the agent-era realization of this line of work.

**Certificate Transparency.** RFC 6962 and its successors define the append-only Merkle log architecture CMPC's transparency log borrows wholesale. Signed Certificate Timestamps become Signed Commitment Timestamps. The monitor and auditor roles transfer directly.

**Ripple Effect Protocol.** Chopra et al. (MIT Project Iceberg, arxiv 2510.16572, October 2025) introduce a coordination protocol in which agents share lightweight sensitivity signals expressing how their decisions would shift if environmental variables moved. REP is a discovery primitive: it helps populations of agents converge on good joint plans without central coordination. CMPC is a commitment primitive: it provides the cryptographic binding once a plan has been found. The two compose naturally along a layered architecture in which REP-style discovery feeds CMPC-style commitment, which in turn feeds downstream settlement layers. This draft proposes an optional **Sensitivity Envelope** primitive that rides alongside the Commitment Envelope during a session's discovery phase and is directly inspired by REP. CMPC also adopts the Beer Game, Movie Scheduling, and Fishbanks benchmarks from the REP paper as reference evaluations for any prototype implementation, so that results are directly comparable across the two protocols.

**Consensus-seeking LLM agents in supply chains.** Recent empirical work (Taylor & Francis 2025) shows that language-model agents can balance self-interested and systemic objectives through structured conversation in supply chain contexts. This provides experimental evidence that the coordination phase of multi-party commitment is feasible with current models, which in turn supports the case for standardizing the commitment phase as CMPC proposes.

**Agent Capability Negotiation and Binding Protocol.** ACNBP (arxiv 2506.13590) addresses bilateral agent capability negotiation with credential verification via an Agent Name Service. CMPC's Mandate Proof primitive is compatible with ACNBP-style credential verification for deployments that use ANS, and is equally compatible with DID-based approaches for deployments that do not.

**A2CN Protocol.** Ongoing work by Christian Magorrian (cmagorr1) on an open negotiation protocol for procurement contexts introduces a mandate verification primitive and an ES256 signing suite. CMPC's Mandate Proof is intended to be compatible with A2CN's mandate primitive, and CMPC itself is proposed as a candidate shared extension above both Concordia and A2CN, with both protocols implementing it in parallel so that multi-party negotiations can span both ecosystems.

## 9. Open design questions

This draft raises a number of questions that should be resolved through review and discussion before any specification is finalized.

**Predicate language expressiveness.** What is the right point on the tradeoff between expressive power and tractability for the Closure Predicate language? SQL-WHERE-clause-level expressiveness is attractive for LLM generation but may be insufficient for some real-world activation conditions. A richer grammar increases complexity and harms decidability guarantees.

**Coordinator selection and accountability.** In optimistic coordinator mode, how is the coordinator selected, and what accountability mechanisms detect and penalize coordinator misbehavior? Reputation-based selection composes cleanly with existing agent reputation systems but introduces a dependency the base protocol has tried to avoid.

**Witness network parameters.** What are appropriate defaults for witness network size, threshold, and rotation? Too small a witness set is easy to compromise; too large is expensive. The right default may vary by deployment context.

**Cross-jurisdiction enforceability.** Participants in a Chain Session may live in different legal regimes with different contract law requirements. What, if anything, should the protocol specify about governing law, enforceability hooks, and jurisdiction-specific commitment templates? This is simultaneously a protocol design question and a legal design question.

**Topology discovery.** CMPC assumes a Chain Session topology is known before commitments are exchanged. In practice, topologies must often be discovered or negotiated. Should topology discovery be part of the CMPC scope, or should it be delegated to a separate discovery protocol (for example, the Ripple Effect Protocol) with CMPC composing above it?

**Settlement composition.** Once a Chain Session activates, downstream settlement systems must be triggered atomically. What is the clean interface between CMPC's Atomic Activation Proof and settlement protocols such as ACP or AP2? This should be sketched in the specification even if the settlement protocols themselves are out of scope.

**Sensitivity Envelope semantics.** If the Sensitivity Envelope primitive is adopted, what is its precise semantics, and how does it interact with Disclosure Policy? The REP paper defines sensitivities at a high level but leaves the cryptographic treatment open.

**Predicate satisfaction proofs.** The claim that Closure Predicates can be proven satisfied in zero-knowledge using existing commitment primitives needs to be verified against the full expressiveness of the predicate language. Some predicates may admit efficient ZK proofs; others may require heavier machinery.

## 10. Status and next steps

This document is a draft for external review. Reactions are invited on primitive shape, naming, trust model, coverage of prior art, and the open design questions in section 9. A bilateral reference prototype of Conditional Commitment is in planning and will target the Beer Game benchmark from the REP paper for direct comparability. A standalone transparency log library following RFC 6962 is also in planning and will ship independently of the full CMPC primitive set.

Comments, corrections, and objections are welcome. Please direct them to the author.

---

## References

- Asokan, N., Shoup, V., Waidner, M. *Optimistic Fair Exchange of Digital Signatures.* EUROCRYPT 1998.
- Garay, J., MacKenzie, P. *Abuse-Free Multi-Party Contract Signing.* DISC 1999.
- Oesterheld, C., Conitzer, V. *Commitment Games with Conditional Information Disclosure.* AAAI 2023. arxiv 2204.03484.
- Zakhary, V. et al. *Atomic Commitment Across Blockchains.* VLDB 2020. arxiv 1905.02847.
- Laurie, B. et al. *Certificate Transparency.* RFC 6962 (2013) and successors.
- Chopra, A. et al. *Ripple Effect Protocol: Coordinating Agent Populations.* MIT Project Iceberg, October 2025. arxiv 2510.16572.
- *Agentic LLMs in the supply chain: towards autonomous multi-agent consensus-seeking.* Taylor & Francis, 2025.
- *Agent Capability Negotiation and Binding Protocol (ACNBP).* arxiv 2506.13590.
- Magorrian, C. *A2CN Protocol.* a2cn.io, 2026.
- Concordia Protocol. github.com/eriknewton/concordia-protocol.
