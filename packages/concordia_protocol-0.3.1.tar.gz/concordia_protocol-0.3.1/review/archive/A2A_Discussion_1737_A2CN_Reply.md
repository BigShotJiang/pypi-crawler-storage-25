# Reply to A2A Discussion #1737 — A2CN Protocol thread

**Post as:** eriknewton on github.com/a2aproject/A2A/discussions/1737
**Replying to:** cmagorr1 (Christian Magorrian) — proposing A2CN protocol for commercial negotiation between agents, mandate verification, dual-signed transaction records, neutral Meeting Place infrastructure.
**Context:** cmagorr1 mentioned Concordia explicitly and said he's reaching out directly to coordinate. First open-standard negotiation player to engage with Concordia by name.
**Tone:** Erik — warm, substantive, collaborative (not territorial), answers his three questions with a real POV, opens the coordination door, pushes back on two specifics that matter.

---

@cmagorr1 — thanks for the direct acknowledgment of Concordia in your write-up and for reaching out off-thread. I spent the morning reading the A2CN spec and the reference implementation notes, and my first reaction is that the overlap is real but the divergences are complementary rather than competitive. A few reactions, then direct answers to your three questions.

**Where A2CN and Concordia clearly converge.** Both protocols give agents a formal state machine for propose/counter/accept/reject/reject with signed receipts on commit. Both are Apache-2.0, both are DID-anchored, both treat the session as a first-class object. That's the right shape. I don't think the world needs two protocols fighting over the same ground, and if you're open to it I think the right move is to find the layering where we compose cleanly.

**Where you have something I don't.** A2CN's **mandate verification** — cryptographic proof that an agent has authority to commit its organization — is the right primitive and Concordia doesn't have an explicit equivalent yet. I've been treating authorization as orthogonal to negotiation mechanics, but you're correct that in commercial settings "is this agent authorized to sign?" has to be answered inside the protocol, not outside it. I'd like to understand your mandate format more deeply and see if Concordia should adopt it directly or bridge to it. Either way it's a gap on my side that you've identified cleanly.

**Where I'd push back gently.** Two things:

1. **ES256 vs Ed25519.** Both are fine cryptographically, but Ed25519 is the native key type for the DID ecosystem — `did:key`, `did:web`, most VC implementations, and the Sanctuary Framework identity layer all default to it. ES256 forces a translation layer anywhere an agent wants to reuse a single keypair across negotiation, identity, attestation, and reputation signals. Concordia, Verascore's `/api/publish` signing, and Sanctuary's L1 identity are all Ed25519 specifically because the same keypair then composes across the whole stack without key rotation or multi-algo glue. I'd encourage A2CN to at least accept Ed25519 as an alternate signing suite even if ES256 stays the default — the spec cost is trivial and the composability win is large.

2. **"Neutral Meeting Place."** The concept is right — neither party should control the authoritative record — but I'd want to understand who runs the Meeting Place and how trust in that operator is established. Concordia's approach is "both parties hold their own Ed25519-signed copies, and the content hash is published to a reputation layer (Verascore) so the record is verifiable without a trusted intermediary." That's one valid answer. A neutral escrow is another. Worth comparing the two models directly.

**Your three questions, with direct answers:**

> "Is the DataPart + extension URI approach the right mapping for session state machines?"

It's the pragmatic mapping if you want to ride on top of A2A without forcing A2A itself to grow a negotiation state machine. Concordia takes a similar view — we're building a negotiation *layer* that composes with A2A rather than asking A2A to absorb commercial negotiation semantics. DataPart + extension URI is a reasonable carrier. The real question is whether A2A gains a formal extension registry so that agents can announce "speaks A2CN" or "speaks Concordia" at discovery time.

> "Where is A2A's auth model heading on cross-org mandate verification?"

I don't think A2A should try to own mandate verification — it's a cross-cutting concern that applies to more than just commercial commits. Mandate verification is really an identity-layer concern (who can this agent act for, and under what constraints) and it belongs with the identity/sovereignty layer, not with the transport layer. In the Sanctuary Framework we treat delegation/mandate as part of the Principal Policy + identity layer. A2CN's mandate primitive could live there and be referenced by any protocol that needs it — Concordia included.

> "Is commercial negotiation between agents in scope for A2A extensions, or separate protocol?"

Separate protocol, composed via extension. A2A is about agent communication. Negotiation is a vertical on top. The ACP/AP2 settlement crowd, Concordia on the structured-agreement side, and A2CN on the commercial-negotiation side are all examples of layers that should compose with A2A rather than live inside it. A2A's job is to give them a clean extension mechanism.

**Concrete next step I'd propose:** a short comparison of the two state machines, the two receipt formats, and the mandate verification primitive. I think there's a version of this where Concordia adopts A2CN's mandate verification, A2CN accepts Ed25519 as an alternate signing suite, and we co-author a composition note that gives procurement platforms (Pactum/Fairmarkit/Keelvar) and general agent negotiation (Concordia's broader scope) a shared foundation. If the right answer turns out to be "these are actually two different protocols for two different use cases," that's also fine — but let's figure it out together before either of us entrenches.

Happy to take this to email or a call. My handle here is the fastest way to reach me, and my Concordia work is at `github.com/eriknewton/concordia-protocol`.

---

## Post-send followups

1. **Create wiki competitive stub** — `Wiki/competitive/a2cn-protocol-STUB.md` with full comparison table. (drafting in parallel)
2. **If cmagorr1 accepts the working session offer**, schedule within 7 days. High priority — first external open-standard negotiation player engaging with Concordia.
3. **Concordia mandate verification gap** — this is now a real gap in the Concordia spec. Add to Concordia roadmap: either adopt A2CN's mandate format directly or design an equivalent primitive that composes with Sanctuary's Principal Policy layer. Don't let this drift; mandate verification will come up again with every enterprise customer.
4. **ES256 compatibility question** — decide whether Concordia should accept ES256 as an alternate signing suite for interop with A2CN. Likely yes, low cost, high composability value. Add to Concordia v0.4.0 scope.
5. **Compose note opportunity** — if the working session goes well, co-author a "Concordia + A2CN composition" note that positions the two protocols at different layers. This is the kind of cross-vendor artifact that creates standards gravity.
6. **Email cmagorr1 directly** — he said he reached out, so the email is likely already in Erik's inbox. Surface it and reply before the public thread reply goes out if possible, so the working-session offer isn't cold.
