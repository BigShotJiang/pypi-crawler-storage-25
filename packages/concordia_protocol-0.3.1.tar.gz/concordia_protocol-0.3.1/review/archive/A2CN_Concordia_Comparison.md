# A2CN and Concordia: A Technical Comparison

**Author:** Erik Newton (Concordia Protocol)
**For:** Christian Magorrian (A2CN Protocol) — as a working document for the coordination session proposed in A2A Discussion #1737
**Date:** April 2026
**Concordia version:** 0.3.0
**A2CN version:** v0.2.0 (spec) / v0.2.0 (reference implementation, 202 tests passing)
**Status:** Draft for discussion. Not a normative comparison — an honest attempt to find the composition shape.

---

## Purpose

This document is the concrete follow-up promised in my reply to #1737: a technical side-by-side of A2CN and Concordia covering the three places I think the conversation has the most leverage — the state machine, the signed-receipt format, and the mandate verification primitive. It's written to be useful for both of us. Where A2CN is stronger, I try to say so without hedging. Where Concordia has made a different choice for good reasons, I try to explain those reasons without defending them past the point of honesty.

The goal is to find the layering. If after reading this we conclude that these are two different protocols for two different use cases, that's a legitimate outcome and we should say so publicly. If we conclude there's a composition shape — same underlying primitives, different vertical profiles — that's what I'd prefer, because the cost to both of our user bases of having two fragmented open negotiation standards is higher than either of us would pay individually.

I'll note up front where my research is secondhand: the A2CN homepage, the #1737 discussion post, and the published v0.2.0 spec fragment at `github.com/A2CN-protocol/A2CN/blob/main/spec/a2cn-spec-v0.2.0.md`. Where the spec points to normative schemas in `spec/schemas/` that I couldn't fully read, I've flagged the gap rather than guessed. Corrections are welcome and expected.

---

## 1. State machine comparison

Both protocols model negotiation as a finite state machine over a session object, with signed messages advancing state and terminal states producing a record. The shapes are close enough that the differences are mostly about emphasis and granularity, not fundamental semantics.

### 1.1 Side-by-side state table

| Concern | Concordia | A2CN |
|---|---|---|
| Pre-acceptance states | `PROPOSED` → `ACTIVE` | `initialized` → `awaiting_response` ↔ `responding` |
| Working state | `ACTIVE` (all offers, counters, signals, inquires, constrains) | `awaiting_response` / `responding` (alternating by turn) |
| Successful terminal | `AGREED` | `accepted` |
| Unsuccessful terminal | `REJECTED`, `EXPIRED`, `WITHDRAWN` (via `.withdraw` → `REJECTED`) | `rejected`, `withdrawn`, `impasse` |
| Reactivation state | `DORMANT` (reactivatable failed session) | None (no direct equivalent) |
| Turn-taking enforcement | Not protocol-enforced; tracked in transcript; bad-faith non-concession is made *visible* via concession trajectory but not blocked | Hard enforcement: "In round 1, ONLY the initiator MAY send an Offer. After round 1, ONLY the party that received the most recent Offer or Counteroffer MAY respond." |
| Impasse detection | Implicit (concession trajectory flatlines; either party may `.withdraw`) | Explicit: default 10-round cap, configurable per deal type via `max_rounds_by_deal_type` |
| Round limit | `max_rounds` in `negotiate.open` body (default 20) | `max_rounds_by_deal_type` in discovery document |
| Session timeout | `session_ttl` (default 24h) + `offer_ttl` (default 1h); negotiable in open | `expires_at` on messages and sessions |
| Withdrawal | `negotiate.withdraw` from any party at any time → `REJECTED` | `Withdrawal` message from either party at any time regardless of turn |
| Mediator / resolution | First-class: `negotiate.propose_mediator`, `negotiate.resolve`, Split/FOA/Trade-off mechanisms (§8) | Not specified |
| Preference signaling | First-class: `negotiate.signal` + `priority_ranking`, `flexibility`, `aspiration`, `reservation` | Not specified |
| Constraint declaration | First-class: `negotiate.constrain` — cryptographically signed hard boundaries | Not specified |
| Dispute signaling | Handled post-commit via fulfillment attestations (§9.6.4) and external reputation layer | Handled via Transaction Record terminal state; dispute semantics TBD |

### 1.2 The three categories

**(a) Isomorphic — same semantic, different label.**

- Concordia `PROPOSED` ≈ A2CN `initialized`. Both are the pre-acceptance invitation state.
- Concordia `ACTIVE` is a superset of A2CN `awaiting_response` / `responding` — both represent the working round-exchange phase.
- Concordia `WITHDRAWN` (via `.withdraw` → `REJECTED`) ≈ A2CN `withdrawn`. The rejection path is the same concept in both.
- `session_ttl` and `expires_at` are the same idea with different scoping: Concordia applies TTL to the session and to individual offers; A2CN puts `expires_at` on messages.

**(b) States one protocol has and the other doesn't.**

- A2CN has an explicit `impasse` terminal state. Concordia has no formal impasse state — when rounds run out or concession flatlines, either party walks via `.withdraw` and the transcript becomes a `REJECTED` session with full concession trajectory in the attestation. A2CN's explicit state is more honest about a common outcome; Concordia's implicit handling compresses impasse and rejection into one terminal. **Concordia should probably add this.** A dedicated `IMPASSE` terminal is a trivial addition and a cleaner signal to downstream reputation consumers than inferring it from round count and zero concession magnitude.
- A2CN enforces turn-taking at the protocol layer. Concordia doesn't. I'll cover why below.
- Concordia has `DORMANT` — a "reactivatable" wrapper on failed sessions that says "I can't deal now, ping me if conditions change." This is a matchmaking affordance, not a negotiation state, and it's arguably out of scope for A2CN's commercial-procurement focus where sessions are usually one-shot. Worth discussing whether this should live in Concordia at all or move to the Want Registry layer.
- Concordia has a first-class resolution layer (mediator, Split the Difference, Final Offer Arbitration, Trade-Off Optimization via Nash Bargaining). A2CN has none of this in v0.2.0. This is the biggest divergence in scope — Concordia treats "what happens when two agents are stuck" as a protocol problem; A2CN treats it as out of scope or deferred.
- Concordia has `negotiate.signal`, `negotiate.constrain`, and `negotiate.inquire` as distinct message types. A2CN has only `Offer`, `Counteroffer`, `Acceptance`, `Rejection`, `Withdrawal`. This reflects different philosophical bets about what a negotiation is — Concordia is closer to a collaborative search for Pareto-optimal outcomes, A2CN is closer to a structured commercial offer exchange. Both are legitimate; the composition shape depends on whether A2CN wants to adopt Concordia's collaborative primitives or whether Concordia wants to profile down to A2CN's minimum for a procurement vertical.

**(c) Same name, different semantics.**

- `accept` / `acceptance`: semantically equivalent in both. Both mean "this specific offer is the final agreement, produce the signed record now." No divergence here.
- `reject` / `rejected`: close but not identical. In A2CN, `rejected` is a state that implies "negotiation may continue" (a rejection of the current offer doesn't end the session unless the protocol times out or either party withdraws). In Concordia, `REJECTED` is a terminal session state. The round-level "I reject your current offer and propose a counter" is handled in Concordia by `negotiate.counter`, not `negotiate.reject`. **This is a real semantic mismatch** and worth being explicit about if we try to map receipts between the two protocols — an A2CN `rejected` state is closer to a Concordia offer-level rejection followed by a counter, not to Concordia's session-terminal `REJECTED`.
- `withdraw` / `withdrawn`: equivalent. Either party terminates unilaterally.

### 1.3 The turn-taking question

A2CN hard-enforces turn-taking at the protocol layer. Concordia doesn't, and I want to be explicit about why and then concede that A2CN may have the better answer for its use case.

Concordia's design principle is that good-faith negotiation is **structurally rewarded, not rule-enforced**. The concession trajectory is computed from the transcript and surfaced in the reputation attestation. An agent that makes no concessions over many rounds generates a bad-faith reputation signal that follows it. An agent that spams offers out of turn produces a messy transcript that reputation services can penalize. The enforcement is at the trust layer, not the protocol layer.

A2CN's design principle is that in commercial procurement, ambiguity about whose turn it is creates legal risk and audit headaches. If both parties send offers simultaneously, which one is binding? Hard turn-taking eliminates the question. For EU AI Act Article 13 and SOX audit logs, strict turn alternation produces a cleaner record that maps directly to "offer, counteroffer, acceptance" in traditional contract law.

**My honest read:** A2CN is right for the commercial procurement use case. Concordia is right for the broader agent-negotiation surface (P2P marketplaces, multiparty supply-chain coordination, negotiations where more than two parties are active at once, negotiations that include mediators). The composition shape might be: "Concordia's state machine profiles down to A2CN's turn-taking discipline for the commercial-procurement extension, and Concordia's broader primitives (signal, constrain, mediate) stay available for other verticals." I'm not committing to this yet — I want to hear your take first — but it's where my thinking lands.

### 1.4 Summary of state machine divergence

| Category | Items |
|---|---|
| **Isomorphic** | open/init, working state, accept, withdraw, TTL |
| **A2CN has, Concordia doesn't** | Explicit `impasse` state, hard turn-taking, configurable round caps per deal type |
| **Concordia has, A2CN doesn't** | `DORMANT` reactivation, mediator/resolution layer, signal/constrain/inquire message types, multiparty semantics |
| **Same name, different semantics** | `rejected` (A2CN: round-level, continuable; Concordia: session-terminal) |

---

## 2. Receipt format comparison

This is where the two protocols have made the most substantively different architectural choices. Both produce a cryptographically signed artifact at the end of a successful session. What gets signed, how it's canonicalized, who holds it, and how it composes with upstream trust layers — those are all different.

### 2.1 Side-by-side receipt schema

| Dimension | Concordia | A2CN |
|---|---|---|
| **What gets signed** | Every message (envelope + body); transcript is a hash chain; attestation at session end is countersigned by both parties | Every offer, counteroffer, acceptance, rejection, withdrawal; transaction record at acceptance is dual-signed |
| **Granularity** | Per-message signing + session-level attestation | Per-message signing + terminal transaction record |
| **Canonicalization** | JSON canonicalization over the envelope; format specified in §4.1 of SPEC.md; aligned with RFC 8785 JCS in the v1.0.0 evidence envelope wrapper (#1734 contribution) | RFC 8785 JSON Canonicalization Scheme (JCS), mandatory for all signed JSON objects |
| **Signature algorithm** | Ed25519 (default, required for Concordia Core conformance) | ES256 (ECDSA with SHA-256 over P-256) |
| **Envelope structure** | `{concordia, type, id, session_id, timestamp, from, to, body, signature}` with optional `in_reply_to`, `prev_hash`, `reasoning` | `{session_id, round_number, sender_did, timestamp, expires_at, message_type, terms, signature}` |
| **Content addressing** | Transcript hash chain (`prev_hash` links each message); attestation includes `transcript_hash` as sha256 root | Transaction Record is content-addressed via `record_hash` (sha256 over JCS-canonical form) |
| **Storage / custody** | Both parties hold Ed25519-signed copies of every message and the final attestation; content hash published to Verascore (or any reputation layer) for public verifiability without trust in an intermediary | Both parties hold dual-signed copies of the Transaction Record; in v0.2.0 storage is bilateral; v0.3 plans "Meeting Place" — neutral third-party host for record storage, mandate management, compliance export |
| **Upstream composition** | Attestations roll up via `§9.6.7` reputation query interface to any number of independent reputation services; the same Ed25519 key used for negotiation is reused at Sanctuary L1, Verascore publish, and DID identity layers — no rotation or multi-algo glue | Transaction Records roll up via compliance audit log for EU AI Act Article 13 / SOX; Meeting Place offers "compliance export" as a planned v0.3 service |
| **Privacy** | Attestations explicitly exclude deal specifics — only behavioral signals, bucketed value ranges, and outcome status (§9.6.6); ZK competence proofs supported for aggregate claims (§9.6.6a) | Transaction Record carries the full `final_terms` of the accepted deal; privacy is per-deployment and depends on who holds the record |

### 2.2 What each protocol optimizes for

Concordia's receipt design is optimized for **portable reputation across arbitrary verticals without ever exposing deal specifics**. The attestation is a privacy-preserving behavioral record. It tells a reputation consumer "this agent negotiates in good faith, provides reasoning, honors commitments" without telling them *what* the agent was buying or selling or *for how much*. This is important because Concordia wants the same reputation signal to work for a $50 used-camera sale and a $500K procurement contract, without the agent having to maintain two reputations in two privacy regimes.

A2CN's receipt design is optimized for **legally defensible audit records for regulated commercial procurement**. The Transaction Record is effectively a contract artifact. It contains the agreed terms in full because that's what the audit regime requires. An EU AI Act Article 13 log needs to show "these are the terms the agent committed my organization to." A SOX audit needs the same. Stripping deal specifics from the record would defeat the purpose.

**These are not incompatible goals.** They're two different artifacts at two different layers. The right composition, I think, is:

1. A2CN's Transaction Record is the **contract artifact** — full deal terms, dual-signed, held bilaterally and optionally at a neutral Meeting Place for compliance export.
2. Concordia's Attestation is the **reputation artifact** — behavioral signals, no deal specifics, published to a reputation layer for portable trust scoring.
3. **Both can be emitted from the same session.** A Concordia-compliant A2CN session would produce both artifacts: the Transaction Record for compliance, and the privacy-preserving Attestation for reputation. They'd be cross-linked by session ID and transcript hash.

### 2.3 Mapping A2CN receipts into the v1.0.0 evidence envelope

This is concrete and worth walking through, because it's the actual composition story. I recently posted a contribution to A2A #1734 defining a v1.0.0 evidence envelope with a `transactional` category payload schema. That schema is already designed to accommodate both Concordia and A2CN receipts — it's vendor-neutral at the envelope layer and protocol-specific at the payload layer.

Here's how an A2CN Transaction Record maps into the envelope:

```json
{
  "envelope_version": "1.0.0",
  "envelope_id": "urn:uuid:...",
  "issued_at": "2026-04-10T18:30:00Z",
  "expires_at": "2026-04-17T18:30:00Z",
  "refresh_hint": {
    "strategy": "event_driven",
    "events": ["dispute_raised", "commitment_verified"],
    "max_age_seconds": 604800
  },
  "provider": {
    "did": "did:web:a2cn-meeting-place.example",
    "category": "transactional",
    "kid": "a2cn-meeting-place-v1",
    "name": "A2CN Meeting Place"
  },
  "subject": {
    "did": "did:web:acme-corp.com"
  },
  "category": "transactional",
  "visibility": "restricted",
  "references": [
    { "kind": "source_session", "urn": "urn:a2cn:session:<uuid>", "hash": "sha256:..." }
  ],
  "payload": {
    "session_id": "urn:a2cn:session:<uuid>",
    "session_protocol": "a2cn",
    "session_protocol_version": "0.2.0",
    "outcome": "ACCEPTED",
    "counterparty_did": "did:web:other-party.example",
    "completion_timestamp": "2026-04-10T18:15:00Z",
    "rounds_to_completion": 3,
    "commitment": {
      "committed": true,
      "commitment_hash": "sha256:<a2cn-record-hash>",
      "honored": null,
      "honored_verified_at": null,
      "dispute_signal": null
    },
    "quality_signals": {
      "response_latency_p50_ms": 12000,
      "response_latency_p95_ms": 28000
    },
    "privacy_guarantees": {
      "deal_terms_disclosed": false,
      "counterparty_identity_disclosed": true,
      "zk_proof_available": false
    }
  },
  "signature": {
    "alg": "ES256",
    "kid": "a2cn-meeting-place-v1",
    "value": "base64url-detached-JWS"
  }
}
```

Things to notice:

1. **The envelope accepts `ES256` as a signature algorithm.** The #1734 contribution lists `EdDSA` as the recommended default and `ES256` and `ES256K` as acceptable alternates precisely so A2CN and Concordia can share the same evidence surface without one of us having to rotate keys.
2. **The `session_protocol` field distinguishes the two protocols at the payload layer.** A consumer (Verascore, any other `transactional`-category gateway, or a compliance export tool) can fetch both envelopes, know which protocol produced each, and treat them uniformly for reputation-scoring purposes.
3. **The `commitment_hash` carries the A2CN `record_hash` verbatim.** If a downstream consumer wants to verify the underlying Transaction Record, the hash points to the canonical document, and the `references` array can include a pointer to where it can be fetched (Meeting Place URL, bilateral storage URL, etc.).
4. **`deal_terms_disclosed: false`** is set because the envelope payload itself doesn't carry deal terms — the full `final_terms` stay in the Transaction Record, protected by whatever privacy/access-control regime the two parties negotiated. The envelope is the reputation-layer artifact; the record is the contract artifact.
5. **The Meeting Place can be the envelope provider.** That's a clean way to sidestep "who signs the reputation-layer artifact." The Meeting Place already has a cryptographic role in the A2CN architecture; extending it to sign transactional-category envelopes is a small step and gives the commercial procurement use case a natural reputation surface without forcing A2CN users onto a different reputation service.

**Concrete claim:** A Verascore instance (or any other `transactional`-category gateway) could consume these envelopes today without any A2CN-specific code. The only glue needed is the `session_protocol = "a2cn"` discriminator at the payload level, and that discriminator is already in the #1734 schema.

### 2.4 The Ed25519 vs ES256 question, honestly

I pushed on this in my reply to #1737 and I want to hold myself to an honest evaluation here, not a biased one.

**The case for Ed25519 (Concordia's choice):**

- Native key type for the W3C DID ecosystem. `did:key`, `did:web`, and most Verifiable Credential implementations default to it.
- Smaller keys (32 bytes) and smaller signatures (64 bytes).
- Deterministic signing — no nonce reuse vulnerabilities, no RNG-failure class.
- Fast in software. No sidechannel concerns in typical deployments.
- Reuses cleanly across the Sanctuary → Concordia → Verascore stack with zero key rotation or format conversion. The same 32-byte key signs a Sanctuary identity, a Concordia negotiation, and a Verascore publish request.
- Native to the cryptographic primitives used in Merkle commitments, Pedersen commitments, and range proofs in Concordia's ZK competence proof system (§9.6.6a). These primitives are defined over Edwards-25519 or Ristretto.

**The case for ES256 (A2CN's choice) — and I want to be fair here:**

- **WebAuthn compatibility.** WebAuthn is ES256-first; if a procurement workflow wants to bind an agent's mandate to a human principal's hardware security key, ES256 is the path of least resistance. Ed25519 is supported in WebAuthn Level 3 but adoption is thinner.
- **Hardware security module (HSM) support.** Enterprise HSMs, PKCS#11 tokens, and cloud KMS offerings (AWS KMS, GCP KMS, Azure Key Vault) have universal ES256/P-256 support. Ed25519 is widely supported now but was a second-class citizen for years and many enterprise procurement environments still run on older HSMs that only do P-256.
- **FIPS 140-2/140-3 compliance.** ES256 has had FIPS validation since 2013. Ed25519 got FIPS 186-5 approval in 2023, but many enterprise compliance regimes still lag. If A2CN's target deployments include federal procurement or SOX-regulated financial services, ES256 is genuinely the safer bet right now.
- **X.509 certificate interop.** P-256 keys drop straight into existing X.509 PKI. Ed25519 requires RFC 8410 support, which is widespread but not universal in legacy stacks.
- **IETF JOSE/COSE standards ubiquity.** ES256 is "the" default for JWS/JWT in the wild. Ed25519 (EdDSA alg) is standardized (RFC 8037) but less universal.

**My read after going through this honestly:** ES256 is the right choice if your deployments are enterprise procurement platforms that need to drop into existing compliance infrastructure tomorrow. Ed25519 is the right choice if your deployments are agent-native and compose across a DID-first trust stack. **Neither protocol is wrong.** The composition story isn't "one of us should switch" — it's that both protocols should accept both signature suites as alternates, and consumers should be able to verify either. The v1.0.0 evidence envelope already does this; the underlying protocol specs should match.

**My concrete ask for A2CN:** accept `EdDSA`/Ed25519 as an alternate signing suite in the normative spec. The cost is small (the spec already uses JCS for canonicalization, which is signature-agnostic; the verification method lookup already goes through DID documents, which support both key types natively). The composability win is large: agents that live in DID-first stacks can use one key across A2CN and everything else.

**My concrete commitment for Concordia:** Concordia will accept `ES256` as an alternate signing suite in v0.4.0. I'll specify this in the conformance section so that any Concordia implementation targeting procurement interop can use the same key a procurement deployment is already provisioning through its HSM. Core implementations still default to Ed25519; the alternate is for interop.

### 2.5 The Meeting Place, and custody models

A2CN's Meeting Place (planned v0.3) is a neutral third party that hosts transaction records, manages mandates, and exports compliance packages. Concordia's model is that both parties hold their own signed copies, and the content hash is published to a reputation layer (Verascore or any equivalent) that serves as a verifiable-without-trusted-intermediary public anchor.

These are not the same thing and they serve different purposes. Let me be direct about tradeoffs.

**Meeting Place advantages:**
- Single source of truth for dispute resolution. If two parties later disagree about what they signed, the Meeting Place holds the canonical record.
- Natural home for compliance export — the Meeting Place can produce EU AI Act Article 13 bundles on demand without either party having to rebuild the log.
- Mandate management (issuance, rotation, revocation) has a natural home.
- Fits the procurement vertical's expectations: "the system of record lives somewhere neutral, not on either party's infrastructure."

**Meeting Place tradeoffs:**
- Requires trust in the operator. Who runs it? Under what jurisdiction? What's the subpoena surface? What happens if the operator is acquired or goes out of business? These questions are answerable, but they're non-trivial and they'll come up the first time a regulated customer asks.
- Introduces a new trust anchor that didn't exist before. The cryptography proves the agreement, yes — but the *availability* of the record depends on the Meeting Place staying up, staying honest, and not being a single point of failure.
- Federation is possible but unspecified in v0.2.0. If the Meeting Place is a single operator, A2CN has a centralization problem. If it's federated, we're back to specifying who the federation members are and how they coordinate.

**Concordia's distributed model advantages:**
- No trusted operator. Both parties hold signed copies; if either loses their copy, the other can produce the complete transcript and the hash chain makes it independently verifiable.
- The reputation layer (Verascore or equivalent) is queried post-hoc for public verifiability, but even if the reputation layer disappears, the parties still have the cryptographic record.
- The reputation layer is explicitly *not* a system of record. It's a content-hash anchor. Its failure mode is "the public verifier is down," not "the contract vanished."

**Concordia's distributed model tradeoffs:**
- Dispute resolution is harder. If two parties disagree, there's no neutral third-party copy to appeal to — each party produces their transcript and the hash chain has to be independently verified by whoever is adjudicating.
- Compliance export is harder. Each party has to assemble its own EU AI Act log from its own transcript store. There's no "push a button and get the compliance bundle" affordance.
- Enterprise procurement teams often *want* a trusted intermediary. "Nobody is holding the record" is a feature to crypto-native users and a bug to compliance-native users.

**My read:** both models are defensible, and they're probably better together. A Meeting Place can coexist with bilateral holding and a reputation-layer hash anchor. In fact, the cleanest shape is:

1. Both parties hold their own signed copies (Concordia's bilateral model).
2. A Meeting Place (A2CN's neutral host) optionally holds a third copy for dispute resolution and compliance export. This is opt-in per session, not mandatory.
3. The content hash is published to a reputation layer (Verascore or equivalent) for public anchoring. This is opt-in per session, not mandatory.

Any of these three can fail without the others failing. An agent can walk away with a cryptographically complete transcript even if both the Meeting Place and the reputation layer are down. This is the composition story I think we should both be pushing: the Meeting Place as an **optional service** that adds convenience for regulated verticals, not a **mandatory component** that creates a new trust dependency.

---

## 3. Mandate verification primitive comparison

This is the most important section because it's the one place where A2CN has a protocol primitive that Concordia genuinely lacks. I want to treat this honestly and not handwave.

### 3.1 Why mandate verification matters

In any commercial negotiation, a counterparty needs to answer two questions before trusting an offer:

1. **Identity** — is this the agent I think it is? (Handled by DID resolution in both protocols.)
2. **Authority** — is this agent authorized to commit its principal to this deal, within these parameters?

Question 2 is where most real-world procurement disputes originate. "My assistant sent that email but they weren't authorized to agree to those terms." "The junior engineer signed the PO but couldn't approve anything over $10K." In traditional commerce this is handled by corporate signing authority, purchase order approval workflows, and signed delegation-of-authority documents. In agent commerce, it has to be handled cryptographically, in-band, at negotiation time.

A2CN has a primitive for this. Concordia doesn't, currently.

### 3.2 How A2CN implements mandate verification

From the published spec, A2CN's mandate verification is a two-tier system:

**Tier 1 — Declared Mandate (self-asserted):**
```
{
  "scope": "<authorization boundary>",
  "principal_did": "<organization DID>",
  "valid_until": "<expiration timestamp>"
}
```
The agent asserts its own authority. The declaration is signed by the agent's key, which is referenced through the discovery document's `verification_method` pointing to a key in the DID document. The declaration tells a counterparty "I claim authority from this principal, within this scope, until this date." Trust in the declaration is trust in the agent's self-report.

**Tier 2 — DID VC Mandate (verifiable credential):**
```
{
  "credential": { /* W3C VC object */ },
  "proof": { /* cryptographic proof from issuer */ }
}
```
The agent presents a Verifiable Credential issued by its principal, with a cryptographic proof chain back to the principal's DID document verification methods. This is the strong form: the counterparty can verify that the principal actually delegated authority to this agent, within this scope, without having to trust the agent's self-report.

**Binding to sessions:**
- SessionInit carries a JWT with `kid` matching a verification method in the DID document, `iss` = initiator DID, signed by the private key corresponding to the discovery document verification method.
- Anti-replay: nonce in SessionInit, `timestamp` + `expires_at` on all messages, server-side nonce tracking.
- Discovery document declares which mandate methods the agent supports (`["declared"]` or `["declared", "did_vc"]`).

**Scope semantics** are not fully detailed in the v0.2.0 spec fragment I could read — the `scope` field is typed as "authorization boundary" without a normative schema. The rich cases (monetary limits, deal-type limits, counterparty-specific limits, time-window limits) aren't explicitly schema'd, but the extension point is clearly there.

**What I like about this design:**
- It's structurally simple. Two tiers, clear distinction between self-asserted and credential-backed.
- It composes with W3C VCs without reinventing the credential stack.
- It's bound to the session cryptographically (the JWT in SessionInit), so you can't retroactively claim authority that didn't exist at session start.
- The `valid_until` field forces explicit expiration, which matches how real-world corporate signing authority works.

**What I think needs more definition (for A2CN to be deployable in regulated verticals):**
- Normative schema for `scope`. Monetary limits, per-deal-type limits, counterparty allowlists, time windows. These will come up immediately in procurement.
- Revocation path. If a principal revokes an agent's mandate mid-session, what happens to in-flight offers? What happens to commitments that have already been signed but not yet settled?
- Delegation chain semantics. Can an agent-with-mandate further delegate to a sub-agent? A2A's deployment patterns include agent-subagent architectures; mandate verification should address this.

### 3.3 What Concordia has today (and doesn't)

Concordia has no explicit mandate verification primitive. The spec assumes that "authorization" is an identity-layer concern that's handled before the negotiation begins. In the Sanctuary-composed deployment model, delegation and authority are handled by Sanctuary's Principal Policy layer — a separate primitive that can be referenced from a Concordia session but isn't part of the Concordia protocol itself.

**This is a real gap.** Concordia-standalone agents (agents that use Concordia without the Sanctuary composition) have no built-in way to express "I am authorized to commit on behalf of X, within these parameters, until this date." They have to rely on out-of-band authorization, which defeats the purpose of having a cryptographic negotiation protocol.

The gap matters most in exactly the deployment context where A2CN is focused: regulated commercial procurement. Procurement systems don't accept "trust us, the agent is authorized" — they require a cryptographic delegation chain from a known principal, with scope limits, verifiable at the moment of commitment.

Concordia v0.4.0 should close this gap. The question is how.

### 3.4 Three options for Concordia

**Option A: Adopt A2CN's mandate format directly as a Concordia extension.**

Concordia would reference A2CN's `Declared` and `DID VC` mandate schemas verbatim and require that Concordia `negotiate.open` messages optionally carry an A2CN-format mandate in a new `body.mandate` field. Agents in procurement contexts present mandates; agents in P2P marketplace contexts ignore the field.

- **Pros:** Fastest. No new schema design. Maximum composability with A2CN — a single mandate document is valid under both protocols. Co-authored deployments become trivial. Signals that composition is the frame.
- **Cons:** Ties Concordia's mandate format to A2CN's choices. If A2CN's mandate schema evolves in a direction Concordia doesn't want (e.g., ES256-only scope signing), Concordia inherits the problem. Also: A2CN's mandate uses ES256 throughout, so adopting it directly means Concordia has to accept ES256 signatures on mandate envelopes — which, per §2.4 above, I'm already proposing we do anyway. So this cost isn't unique to this option.

**Option B: Design a Concordia-native mandate primitive that bridges to Sanctuary's Principal Policy layer.**

Concordia would define its own `mandate` schema (likely a superset of A2CN's — adding Sanctuary delegation-chain references, ZK scope proofs, and multi-principal authorization) and specify a bridge format that maps A2CN mandates to Concordia mandates and vice versa.

- **Pros:** Cleaner sovereignty story. Native support for Sanctuary's principal-delegation model (hierarchical delegation, pre-rotation, scope proofs). Not tied to A2CN's future decisions. Concordia retains full protocol control over its trust-layer primitives.
- **Cons:** Slower. Requires schema design that I'd want to run past you and any other interested parties. The bridge format is extra work that Option A avoids. Risk of over-engineering: Concordia doesn't need every feature the Sanctuary layer has.

**Option C: Leave mandate verification to a compositional layer outside both protocols.**

Both protocols agree that mandate verification lives in a separate specification (maybe a joint A2CN+Concordia "Agent Mandate Specification" document) that both protocols reference. Neither protocol builds the primitive natively.

- **Pros:** Minimal protocol change. Forces a clean separation between negotiation mechanics and authorization mechanics. Opens space for other protocols (ACP, AP2, etc.) to adopt the same mandate spec.
- **Cons:** Leaves a gap that procurement deployments hit immediately. Doesn't solve the problem, just moves it. The Concordia-standalone user (no Sanctuary, no external mandate spec) still can't negotiate in regulated contexts. Procurement teams will ask "where's your mandate story?" and a pointer to a separate spec isn't an acceptable answer.

### 3.5 My recommendation

**Option A, with a caveat:** adopt A2CN's two-tier mandate format as a Concordia extension in v0.4.0, with an explicit commitment to co-evolve the mandate schema jointly. Specifically:

1. Concordia v0.4.0 defines `concordia.ext.mandate` extension that adopts A2CN's `Declared` and `DID VC` mandate shapes verbatim.
2. The `negotiate.open` message body gains an optional `mandate` field carrying the A2CN mandate document.
3. Concordia accepts both Ed25519 and ES256 on mandate signatures (per §2.4).
4. Concordia and A2CN jointly author a "Agent Mandate Specification" document that becomes the canonical shared source of truth — co-authored, co-maintained, under both protocols' governance.
5. In parallel, Concordia specifies a bridge from the shared mandate spec to Sanctuary's Principal Policy layer for deployments that want the deeper sovereignty guarantees. This bridge is specified in Sanctuary's documentation, not Concordia's — it's an optional composition, not a protocol dependency.

**Why this over Option B:** speed and composition. If I'm building a Concordia-native primitive from scratch, I'm making decisions that you've already made and I'm taking on the cost of specifying something you've already specified. The work is wasted unless the Concordia-native version is substantially better than A2CN's, and honestly, it wouldn't be — A2CN's two-tier design is the right shape. The Sanctuary bridge is the place where I want to add value, and I can do that without forking the underlying mandate format.

**Why this over Option C:** procurement teams will hit the gap immediately. Pointing them at a separate spec that neither protocol implements natively is going to cost both of us credibility. Adopting the primitive in-protocol is the only way to tell a procurement team "yes, we handle this."

**Scope estimate for Concordia v0.4.0 under Option A:**
- Extension spec (`concordia.ext.mandate`): ~2 weeks of spec work, including normative schemas for `scope` (monetary limits, deal-type limits, counterparty scopes, time windows).
- Reference implementation in the `concordia-protocol` Python package: ~1 week (verification logic, DID resolution, JWT validation, anti-replay — most of which Concordia already has in other contexts).
- Integration tests against A2CN's reference implementation: ~1 week, assuming you're willing to run a joint test harness with shared fixtures. This is the highest-leverage activity — a shared test suite proves the composition at the code level and gives both protocols a mutual conformance check.
- Documentation + migration notes: ~1 week.
- **Total: ~5 weeks for v0.4.0 scope, targetable to a late-May 2026 release.** Non-blocking for current Concordia work; can be developed in parallel with other v0.4.0 items.

**One forward-looking note on why the joint mandate spec matters beyond bilateral.** In parallel with this comparison document, I'm circulating an early-stage draft for a primitive family that extends the bilateral pattern both our protocols use into multi-party atomic commitment — conditional commitments that bind if and only if a chain of related commitments across N agents all close. Mandate verification is load-bearing in that setting because the invalidity of a single mandate can invalidate an entire chain session, and there's no clean way to bolt it on later. If we co-author the Agent Mandate Specification now with the multi-party use case in mind, we get a primitive that works for bilateral procurement today *and* extends cleanly into supply-chain-scale coordination tomorrow, without either of us having to rework it. I'm sending the multi-party draft alongside this document so the two can be read together — it is explicitly an open draft and the primitive family is proposed as jointly-owned infrastructure above both Concordia and A2CN, not a Concordia-private extension. Happy to discuss naming, governance, and authorship openly; I have no attachment to the placeholder name or to unilateral ownership.

### 3.6 What I want from you

Three things, if you're open to them:

1. **Share the full v0.2.0 spec fragment I couldn't read** — specifically the `scope` schema, the JWT claims structure, the revocation path (if any), and whether there's a delegation-chain model. I want to make sure "adopt verbatim" is actually feasible before I commit to the option.
2. **Agree in principle to co-authoring a joint Agent Mandate Specification** as a standalone document, co-maintained, referenced by both protocols. I'd want this to be explicitly not under either protocol's sole governance — both names on the document, both governance processes involved.
3. **Accept Ed25519 as an alternate signing suite in A2CN v0.3.0 or a minor update.** This is the mirror commitment to my v0.4.0 commitment to accept ES256 in Concordia. If we both accept both, the composition story writes itself and the #1734 evidence envelope already has the right shape.

---

## 4. Highest-leverage decisions for Erik

At the end of this exercise, three decisions stand out as the ones that will determine how the composition actually shakes out. I'm flagging them here because they're mine to make, not A2CN's.

### 4.1 Should Concordia v0.4.0 include a `mandate_verification` primitive, and which option?

**My recommendation: Option A (adopt A2CN's format as a Concordia extension, co-author a joint Agent Mandate Specification).**

- Ships fastest (~5 weeks).
- Maximum composability with A2CN — single mandate document valid under both.
- Leaves room for Sanctuary Principal Policy bridge as an optional composition (non-breaking).
- Forces the collaboration frame: if we co-author the spec, we can't end up with fragmented mandate formats three versions from now.

**The alternative worth considering** is Option B if you think Concordia's trust-layer story needs to differentiate from A2CN's more clearly. My read is that it doesn't — the differentiation is at the reputation/privacy layer (§9.6 in the Concordia spec), not at the mandate layer. Option A gives us the mandate primitive without costing any differentiation.

### 4.2 Should Concordia accept ES256 as an alternate signing suite for A2CN interop?

**My recommendation: Yes, specify ES256 as an accepted alternate signing suite in Concordia v0.4.0.**

- The case for ES256 in enterprise procurement (WebAuthn, HSM, FIPS, X.509 interop) is genuine.
- The #1734 evidence envelope already accepts both; making Concordia match is a one-paragraph change in the Conformance section.
- Ed25519 stays the default and the required suite for Concordia Core conformance. ES256 is opt-in for deployments that need it.
- Mirror commitment: ask A2CN to accept Ed25519 in v0.3.0. If both protocols accept both suites, the composition is frictionless.

**The cost is small** (canonicalization is already signature-agnostic; DID documents already support both key types natively). The benefit is that any agent provisioned through an enterprise HSM can use the same key across both protocols without a multi-algo glue layer.

### 4.3 Should we propose a joint namespace or vocabulary crosswalk between Concordia and A2CN receipts?

**My recommendation: Yes, contribute crosswalks to `aeoess/agent-governance-vocabulary` (the vocabulary repo established in the #1734 thread) and propose a joint naming convention for shared primitives.**

Specifically:
1. Contribute a Concordia crosswalk mapping Concordia's `session_protocol = concordia` value, state names, and receipt fields to the canonical vocabulary.
2. Invite A2CN to contribute the equivalent A2CN crosswalk.
3. Propose a shared naming convention for primitives that both protocols adopt jointly — starting with the mandate specification (§3.5 above) and extending to any future shared artifacts (evidence envelope payload extensions, composite audit log formats, ZK proof envelopes).
4. Explicitly do *not* propose a unified state machine or unified message format. The state machines are different for good reasons (§1) and forcing a unified format would dilute both protocols. The crosswalk is about shared vocabulary for cross-protocol tooling, not about merging the protocols.

**Why this matters now:** there's a standards-shaping window in Q2-Q3 2026 where the agent-negotiation vocabulary is still being defined. If A2CN and Concordia establish a joint crosswalk early, any subsequent protocol that enters the space is going to reference it. If we each publish separate vocabularies, we're inviting a third fragmenting actor to define the terms and arbitrate between us. The crosswalk is cheap and it locks in the composition narrative.

---

## 5. What I'm not proposing

A few things worth being explicit about, because they've come up in my head during this analysis and I want to rule them out cleanly:

- **Merging the two protocols into one.** No. They have different scopes and different design principles. Concordia's mutual-flourishing framing and Pareto-optimization resolution mechanisms are a genuine differentiator for the broader negotiation surface. A2CN's turn-taking discipline and compliance-first receipt model are a genuine differentiator for regulated procurement. Trying to merge them would produce a protocol that's worse at both jobs. Composition, not merger.
- **Concordia adopting A2CN's Meeting Place as a required component.** No — the Meeting Place is a great optional component and I'm happy to specify a bridge to it, but Concordia's distributed-custody model has to stay the default. Enterprise customers who want a Meeting Place can opt in per-session. Crypto-native users who don't want a trusted intermediary shouldn't be forced to use one.
- **A2CN adopting Concordia's resolution mechanisms (Split, FOA, Trade-off Optimization) as required.** No. These are Concordia-specific and they serve the broader negotiation use case. Forcing them on commercial procurement would add complexity A2CN's users don't need. Concordia's resolution layer stays a Concordia affordance.
- **Either protocol becoming a dependency of the other.** Absolute no. The non-dependency principle is sacred for both of us, I think, and I want to preserve it. Composition means "these two protocols work together when both are present" — never "this protocol requires the other."

---

## 6. Open questions I'd like to discuss

1. **Revocation semantics for mandates.** If a principal revokes an agent's mandate mid-session, what happens to in-flight offers? To already-signed commitments that haven't been settled? Does A2CN have a revocation path in v0.2.0, or is this deferred?
2. **Meeting Place federation.** Is the v0.3 Meeting Place designed to be federated across multiple operators, centralized on a single operator, or user-hosted (each organization runs its own)? The answer substantially changes the trust model and the composition story.
3. **Delegation chains.** Can a mandated agent further delegate scope to a sub-agent? Both protocols will need to answer this — it's standard in A2A deployments and it's where the real-world delegation-of-authority patterns live.
4. **Dispute signaling.** Concordia has fulfillment attestations that run post-settlement and can carry dispute signals. A2CN's Transaction Record has terminal states but dispute semantics seem TBD. How does A2CN plan to handle "the commitment was signed but the counterparty didn't deliver"?
5. **Multiparty negotiation and atomic multi-party commitment.** Concordia supports 3+ party negotiations at the session level (§3.3, extension `concordia.ext.multiparty`), but the harder problem — conditional, atomic, cryptographically-bound commitment across a chain of N agents where each party's binding is contingent on the whole chain closing — is not addressed by either of our v0.2/v0.3 specs today. I've been drafting an early-stage primitive family for exactly this (working name: Multi-Party Commit, with primitives like Commitment Envelope, Conditional Commitment, Closure Predicate, Chain Session, and an Unwind Protocol), and I'm circulating that draft to you alongside this comparison. I'm explicitly *not* proposing it as a Concordia-private extension — the draft is framed as jointly-owned infrastructure above both Concordia and A2CN, the name is a placeholder, and governance is open for discussion. The reason it's relevant to the bilateral comparison is that mandate verification (§3) is load-bearing in the multi-party setting — an invalid mandate in one link can invalidate an entire chain — and I'd rather we co-design the mandate spec with both bilateral and chain use cases in mind from the start. Does A2CN consider multi-party / chain-scale procurement in scope at all, and if so is this the kind of layer you'd want to co-own?
6. **Test harness sharing.** Would you be open to running a joint integration test suite that exercises both reference implementations against shared fixtures? I think this is the single highest-leverage thing we could do together — it proves the composition at the code level and gives both protocols a mutual conformance check that no single-vendor spec comparison can match.

---

## 7. Next steps I'd propose

If this document lands well, the next steps I'd suggest:

1. **Working session** — a real call (video or voice), 60-90 minutes. Walk through this document together. Identify the items where we agree, the items where we don't, and the items where we need more information.
2. **Joint Agent Mandate Specification** — if we agree on Option A in §3, start a shared document (GitHub repo under both our names, or a neutral org) and draft the normative mandate schema together.
3. **Vocabulary crosswalk contribution** — both of us contribute to `aeoess/agent-governance-vocabulary` with crosswalks for our respective protocols. Low-cost, high-signal.
4. **Signature suite alignment** — Concordia commits to accepting ES256 as alternate in v0.4.0; A2CN commits to accepting Ed25519 as alternate in v0.3 or a minor update. Mirror commitments, small specs, large composability win.
5. **Joint test harness** — a shared Python integration test suite that runs the A2CN reference implementation and the Concordia reference implementation through composition scenarios (A2CN session producing a Concordia attestation, Concordia session with A2CN-format mandate, shared evidence envelope consumption). This is the proof point for everything above.
6. **Public composition note** — once the above is stable, co-author a short piece (blog post, conference submission, or thread post) that describes the composition shape publicly. This is the standards-gravity artifact — it tells procurement platforms, A2A participants, and other protocol authors that the two open negotiation standards are composable, not competing.
7. **Read the Multi-Party Commit draft alongside this document** — I'm sending the early-stage multi-party draft as a companion artifact to this comparison. It's deliberately rough, deliberately not Concordia-branded in its intended final form, and deliberately sent to you before it goes anywhere public (MIT / Project Iceberg, W3C AIVS, or A2A). If the layered-architecture framing lands, the obvious next move is to co-author the multi-party primitive family and position it publicly as a joint A2CN/Concordia proposal rather than letting either of our projects, or an academic third party, stake out the N-party territory unilaterally.

---

*This document is a draft for discussion. It's not a normative specification and nothing in it commits either protocol to anything until we agree explicitly. Corrections, pushback, and better ideas are all welcome.*

*Erik Newton*
*Concordia Protocol*
*github.com/eriknewton/concordia-protocol*
