Just posted the Concordia receipt intake schema you asked for as a contribution to #1734, under the `transactional` category. The full payload shape is there with field definitions, TTL, and verdict-cascade semantics.

Short version: Concordia v0.3.0+ already emits these from every terminated session via `concordia_session_receipt_export`, signed with Ed25519 over RFC 8785 JCS canonical form. The v1.0.0 envelope wrapper is a pure re-packaging with no lossy conversion, so you can consume Concordia receipts directly as `transactional` category envelopes without any transform layer.

Give it a read and let me know if the shape works for Verascore's intake pipeline or if there are fields you'd like moved/renamed for cleaner aggregation. Happy to iterate before kenneives's v0.2 draft freezes.
