Contributing concrete schema for the two categories I'm maintaining reference implementations for — `transactional` (Concordia Protocol) and `sovereignty` (Sanctuary Framework). Aligned to the thread consensus on envelope version 1.0.0, `refresh_hint` shape, `visibility` enum, and the verdict-cascade rule.

### Common envelope

Detached JWS signature over RFC 8785 JCS canonical form (envelope minus the `signature` field).

```json
{
  "envelope_version": "1.0.0",
  "envelope_id": "urn:uuid:01HZABCDE1234FGHJK5MNPQRST",
  "issued_at": "2026-04-10T18:30:00Z",
  "expires_at": "2026-04-17T18:30:00Z",
  "refresh_hint": {
    "strategy": "event_driven",
    "events": ["session_completed", "dispute_raised"],
    "max_age_seconds": 604800
  },
  "provider": {
    "did": "did:web:verascore.ai",
    "category": "transactional",
    "kid": "verascore-scoring-v1",
    "name": "Verascore"
  },
  "subject": { "did": "did:key:z6MkhaXgBZDvotDkL5257faiztiGiC2QtKLGpbnnEGta2doK" },
  "category": "transactional",
  "visibility": "public",
  "references": [
    { "kind": "source_session", "urn": "urn:concordia:session:01HZXYZ...", "hash": "sha256:a3f5..." }
  ],
  "payload": { "...": "category-specific, see below" },
  "signature": {
    "alg": "EdDSA",
    "kid": "verascore-scoring-v1",
    "value": "base64url-detached-JWS-over-canonical-envelope-minus-signature"
  }
}
```

Ed25519 (`EdDSA`) is the recommended default; `ES256` and `ES256K` are acceptable alternates so A2CN, Revettr, and other ES256-native providers compose without friction.

### Category: `transactional`

Attests to the outcome of a structured agent-to-agent transaction — primarily negotiations producing binding commitments, generalizable to any completed multi-round exchange with a signed result.

**What it's for:** negotiation outcomes from protocols like Concordia or A2CN, binding commitment records, dispute signaling, counterparty-rating data.

**What it is NOT for:** behavioral observations (`behavioral`), trust-graph topology (`graph_structural`), identity claims (`identity`), compliance posture (`compliance_risk`), wallet solvency (`wallet_state`), static analysis (`static_analysis`).

```json
{
  "session_id": "urn:concordia:session:01HZXYZ...",
  "session_protocol": "concordia",
  "session_protocol_version": "0.3.0",
  "outcome": "ACCEPTED",
  "counterparty_did": "did:key:z6Mko...",
  "completion_timestamp": "2026-04-10T18:15:00Z",
  "rounds_to_completion": 3,
  "commitment": {
    "committed": true,
    "commitment_hash": "sha256:b91c...",
    "honored": true,
    "honored_verified_at": "2026-04-10T18:25:00Z",
    "dispute_signal": null
  },
  "quality_signals": {
    "concession_magnitude": 0.42,
    "reasoning_quality": 0.85,
    "response_latency_p50_ms": 12000,
    "response_latency_p95_ms": 28000
  },
  "privacy_guarantees": {
    "deal_terms_disclosed": false,
    "counterparty_identity_disclosed": true,
    "zk_proof_available": true
  }
}
```

**TTL:** 7-day default aligned to the thread's category table. **Refresh strategy:** `event_driven`, triggered by `dispute_raised`, `commitment_verified`, `new_settlement`, `envelope_revoked`. **Verdict cascade:** any verdict consuming this envelope MUST expire no later than this envelope's `expires_at`.

**Reference implementation:** Concordia Protocol v0.3.0+ emits these via `concordia_session_receipt_export`. The receipt format already carries every field in the payload above; the v1.0.0 envelope is a pure re-packaging with no lossy conversion.

### Category: `sovereignty`

Attests to an agent's structural sovereignty posture — whether it controls its own keys, isolates its own operations, discloses selectively, and carries portable reputation. Capability-level, not behavioral.

**What it's for:** Sanctuary Health Report (SHR) data and equivalents, per-layer status (L1 cognitive / L2 operational isolation / L3 selective disclosure / L4 verifiable reputation), capability manifest attestations, key custody claims.

**What it is NOT for:** runtime performance (`behavioral`/`continuous_monitoring`), trust-graph topology (`graph_structural`), negotiation competence (`transactional`), compliance posture (`compliance_risk`), wallet solvency (`wallet_state`), security scans (`static_analysis`).

```json
{
  "framework": "sanctuary",
  "framework_version": "0.7.0",
  "shr_version": "1.2",
  "overall_rating": "MINIMUM_VIABLE",
  "layers": {
    "l1_cognitive":             { "status": "FULL",     "score": 100, "capabilities_present": ["self_hosted_weights","prompt_isolation","key_custody"], "capabilities_missing": [], "evidence_hash": "sha256:a1b2..." },
    "l2_operational_isolation": { "status": "DEGRADED", "score": 60,  "capabilities_present": ["sandbox","network_policy"], "capabilities_missing": ["tee"], "evidence_hash": "sha256:c3d4..." },
    "l3_selective_disclosure":  { "status": "FULL",     "score": 100, "capabilities_present": ["schnorr","pedersen_commitment","range_proofs"], "capabilities_missing": [], "evidence_hash": "sha256:e5f6..." },
    "l4_verifiable_reputation": { "status": "FULL",     "score": 100, "capabilities_present": ["ed25519_identity","did_resolution","attestation_publish"], "capabilities_missing": [], "evidence_hash": "sha256:g7h8..." }
  },
  "capability_manifest_hash": "sha256:i9j0...",
  "attestation_mode": "self_attested",
  "verifier": null,
  "known_degradations": [
    { "layer": "l2", "reason": "no_tee_available", "severity": "partial", "compensating_controls": ["process_isolation","syscall_filter"] }
  ]
}
```

**TTL:** no fixed TTL per the thread's category table — sovereignty is stable across runtime lifetimes, changes only on explicit config events. Providers SHOULD nonetheless set `expires_at` (suggested: 30 days) to bound downstream verdict lifetimes. **Refresh strategy:** `event_driven` with `ttl_only` fallback, triggered by `capability_manifest_changed`, `runtime_reconfigured`, `key_rotated`, `framework_upgraded`, `policy_change`. **Verdict cascade:** same rule applies.

**Reference implementation:** Sanctuary Framework v0.7.0+ emits these via `audit_export_siem` and `reputation_publish`. SHR data populates every field directly; the envelope is a pure re-packaging.

### Positions on open thread questions

1. **Revocation (adopting thread consensus):** v1 = `GET /attestation/{id}/status → active|revoked|expired`. v2 can add event-driven push for high-stakes categories (compliance_risk explicitly, sovereignty on key-compromise events). Consumers MUST check revocation status before honoring any envelope within its `expires_at` window.

2. **Dual-homing:** providers SHOULD emit **separate envelopes per category**, not combine. A Concordia session that produces both a transactional outcome and a sovereignty posture change should emit two envelopes cross-linked via `references`. Separate envelopes preserve clean provenance, let category-specific TTLs apply independently, and match the verdict-cascade rule without ambiguity about which expiration dominates.

3. **v0.3 category grouping preview:** under the previewed pre-interaction/runtime/post-interaction grouping, `sovereignty` belongs in runtime and `transactional` belongs in post-interaction. Both categories in this contribution are authored with that grouping in mind; no schema change should be required when v0.3 lands.

4. **Vocabulary crosswalks:** Concordia and Sanctuary will contribute crosswalks to `aeoess/agent-governance-vocabulary` mapping `session_protocol` values and SHR layer identifiers to canonical vocabulary entries.

### Still open, would like RFC resolution

- **Cross-category references.** A transactional envelope may want to reference a sovereignty envelope of the counterparty. I lean on-demand consumer-controlled fetch, but the RFC should specify.
- **Aggregation semantics.** When multiple providers emit envelopes for the same subject in the same category, the RFC should document a default reconciliation pattern or leave it explicitly to consumers. Verascore's weighting (3x verified, 1.5x cross-corroboration, 10% diversity bonus) is one pattern.
- **Transport binding.** I lean transport-agnostic — the envelope should be valid over HTTPS, email, IPFS, or any byte-carrying channel as long as the signature verifies.

Happy to iterate on any of the field shapes above. The `transactional` payload is the Concordia receipt format with zero loss; the `sovereignty` payload is the Sanctuary SHR with zero loss. Both are producing live envelopes today, so changes to field naming are easy but changes to semantics are load-bearing for downstream consumers.
