# Email draft to Christian Magorrian (A2CN)

**To:** [cmagorr1 email — get from his public #1737 reply]
**From:** eriknewton@gmail.com
**Subject:** A2CN ↔ Concordia technical comparison + a companion draft

---

Christian,

Thanks again for reaching out on #1737. I said I'd put together something concrete on the three places I thought the conversation had the most leverage — state machine, receipt format, and mandate verification — and it turned into a longer document than a thread comment could hold, so I'm sending it directly instead.

Two attachments:

1. **`A2CN_Concordia_Comparison.md`** — the technical comparison I promised. It's an honest side-by-side, not a marketing document. Where A2CN is stronger I try to say so. Where Concordia has made a different choice I try to explain why without over-defending it. The three biggest concrete proposals are in §4: (a) Concordia adopts your mandate verification primitive as Option A — minimal normative definition, optional DID-VC tier — under co-authorship as a joint "Agent Mandate Specification"; (b) both protocols accept each other's signature suites as alternates (ES256 in Concordia, Ed25519 in A2CN) so the evidence envelope from #1734 can carry either; (c) we contribute a joint vocabulary crosswalk to `aeoess/agent-governance-vocabulary`. Everything else in the document is context for those three asks.

2. **`MULTI_PARTY_COMMIT_EXTERNAL_DRAFT.md`** — an early-stage draft on a primitive family for atomic multi-party commitment (N-party chain sessions where each party's binding is conditional on the whole chain closing). This is genuinely rough and I'm sending it to you *before* it goes anywhere public because the bilateral work in document #1 is load-bearing for it — mandate verification specifically is load-bearing, which is why I'd rather we co-design the mandate spec with both bilateral and chain use cases in view from the start. The working name is a placeholder, the governance is open, and I'm explicitly framing it as jointly-owned infrastructure above both Concordia and A2CN rather than a Concordia extension. If the layered framing in document #1 lands for you, the obvious next move is to co-author this one as a joint A2CN/Concordia proposal rather than letting either of our projects — or an academic third party — stake out the N-party territory unilaterally. If the framing doesn't land, the MPC draft is easy to set aside; nothing in the comparison document depends on it.

A few notes on what I'm *not* proposing, because I want to be direct about it:

- I'm not proposing a merger of the protocols. Concordia has abstract negotiation primitives that A2CN deliberately doesn't have, and A2CN has commercial-procurement specificity that Concordia deliberately doesn't have. Those are good reasons for both to exist.
- I'm not proposing that Concordia adopt Meeting Place or that A2CN adopt Concordia's distributed custody model. Different trust assumptions, different use cases, both legitimate.
- I'm not proposing cross-dependency. The whole point of the composition framing is that either protocol should remain usable standalone.

What I'd like, concretely, is a 60–90 minute working session — video or voice, whenever works for you in the next couple of weeks — to walk through the comparison document together, agree or disagree on the three proposals in §4, and figure out whether there's enough alignment to start a shared repo for the joint Agent Mandate Specification. If the MPC draft is interesting to you, we can talk about that in the same session; if it's not, we drop it and just work on the bilateral piece.

On public coordination: I think the right shape is to keep this initial exchange private until we've agreed on next steps, then post a short joint summary back to #1737 together. That way the A2A audience sees "two protocol authors coordinated and here's what they're doing" rather than watching us negotiate the composition in the thread. But I'm open to whatever sequencing you prefer.

No rush on a reply. I know you have a reference implementation to ship and a spec to publish, and I'd rather you respond thoughtfully than quickly. If any of the three proposals in §4 is a hard no for you, say so bluntly — that's still a useful outcome and saves both of us time.

Looking forward to the conversation.

Erik

Erik Newton
Concordia Protocol
github.com/eriknewton/concordia-protocol
