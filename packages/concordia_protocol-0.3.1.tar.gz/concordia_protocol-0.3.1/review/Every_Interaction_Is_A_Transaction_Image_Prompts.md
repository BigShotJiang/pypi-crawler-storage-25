# Image Prompts — "Every Interaction Is a Transaction"

Generate one image for use as the social card across all three channels. Choose from the options below.

## Option 1: Architectural (Recommended)

A minimalist architectural diagram rendered as editorial art. Two abstract geometric forms — faceted polyhedra in deep navy (#030604) — face each other across a narrow gap. Between them, a thin luminous thread of AI Blue (#3B82F6) connects in a structured handshake pattern, with small glowing nodes along the thread representing proposal, counter, accept, commit. The background is deep matte black with a subtle grid pattern suggesting protocol structure. The gap between the forms is narrow but precise — engineered, not accidental. Quiet authority. No text. High-end technology publication aesthetic. Aspect ratio 1.91:1.

## Option 2: Abstract Flow

A dark composition on near-black (#030604) background. Two streams of structured data — represented as parallel lines of varying thickness in muted silver (#DDE2F2) — flow from opposite edges of the frame toward a central convergence point. At the convergence, the lines interweave into a tight braid pattern that glows AI Blue (#3B82F6) and Security Green (#10B981), suggesting structured agreement emerging from separate intentions. The braid continues downward briefly before fanning out again, now unified in color. The overall feeling is of order emerging from complexity. No text. No faces. No screens. Editorial illustration quality. Aspect ratio 1.91:1.

## Option 3: Symbolic Receipt

A single sheet of translucent material — somewhere between paper and crystal — floating against a deep navy-black void. The sheet has faint structured lines visible within it, like a protocol receipt rendered in light. One edge glows AI Blue (#3B82F6), the other Security Green (#10B981). A subtle cryptographic hash pattern is barely visible along one margin, like a watermark. The sheet catches light from an unseen source, creating a sense of quiet permanence — this is a record that endures. Minimal, restrained, authoritative. No text. Aspect ratio 1.91:1.

## Color Reference (Obsidian Intelligence Palette)

- Background: #030604 (near-black)
- Primary accent: #3B82F6 (AI Blue)
- Secondary accent: #10B981 (Security Green)
- Text/structure: #DDE2F2 (silver-white)
- Headlines font reference: Space Grotesk
- Body font reference: Inter

## Usage

- Social card (all channels): 1.91:1 aspect ratio
- Square crop available for profile-friendly contexts
