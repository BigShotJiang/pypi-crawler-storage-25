# Every Interaction Is a Transaction

**Author:** Erik Newton
**For:** LinkedIn (long-form) + X (thread version below)
**Date:** April 1, 2026
**Status:** DRAFT — awaiting Erik's review

---

Every interaction between agents is a transaction.

Not metaphorically. Not in the loose business-speak sense where "transaction" means "something happened between two parties." Structurally. Every time one agent asks another to do something — retrieve information, perform a task, share a resource, make a decision — there's an implicit negotiation happening. Terms are being set. Expectations are being established. Commitments are being made.

Right now, those negotiations happen in natural language. An agent sends a message. The other agent interprets it. Maybe they agree. Maybe they don't. Maybe they agree to something slightly different from what was asked. Nobody knows for sure, because there's no structure, no receipt, no binding commitment. Just vibes.

That works when you have two agents in a sandbox doing a demo. It does not work when you have ten thousand agents negotiating ten million interactions per hour across organizational boundaries, where the outcomes are consequential and the stakes are real.

## The Scale Problem Nobody Is Talking About

We're building toward a world where autonomous agents handle procurement, logistics, scheduling, resource allocation, legal compliance, financial settlement, and a hundred other domains — not as tools executing human commands, but as principals acting on behalf of humans and organizations, making decisions at machine speed.

The numbers are staggering. Enterprise procurement alone involves millions of multi-party negotiations annually — price, delivery, quality, liability, compliance. Each one is a transaction with terms, counteroffers, conditions, and commitments. Today, those negotiations take days or weeks of human time. Tomorrow, they'll take seconds. Agents will negotiate with other agents, settle terms, and execute — continuously, autonomously, at scale.

Every single one of those interactions needs structure. Not just communication structure (A2A gives us that). Not just payment structure (ACP and Stripe give us that). Agreement structure. The ability to propose terms, counteroffer, accept or reject, commit to what was agreed, and prove later what the agreement was.

This is the layer nobody is building.

## What "Agent-Native" Actually Means

When I say agent-native, I mean something specific. I mean negotiation primitives designed for how agents actually operate — not human UX patterns retrofitted for machine-to-machine interaction.

Agent-native negotiation means proposals are structured data, not paragraphs. Counteroffers modify specific fields, not entire conversations. Acceptance is cryptographically binding, not a message that says "sounds good." Session receipts are machine-verifiable, not email threads you'd have to parse to reconstruct what was agreed.

It means the protocol handles the reality that agents fail, networks partition, and not every negotiation reaches agreement. Graceful degradation isn't an error state — it's a first-class protocol feature. When one agent doesn't speak the protocol, the other agent doesn't crash. It falls back, documents the gap, and proceeds with whatever structure is available.

It means composability. A negotiation between two agents can be embedded inside a larger negotiation between ten agents. Terms from one agreement can flow into the conditions of another. The protocol composes because the primitives were designed to compose — propose, counter, accept, reject, commit. Five verbs. Infinite combinations.

And it means extensibility. The protocol doesn't prescribe what you negotiate about. Price, access, data sharing, SLAs, compliance requirements, resource allocation — the domain is a parameter, not a constraint. New transaction types emerge as agents enter new domains, and the protocol accommodates them without version bumps or breaking changes.

## The Gap in the Stack

The agentic protocol stack is converging fast. MCP owns tool integration — 97 million monthly SDK downloads. A2A owns inter-agent communication — Linux Foundation governance, 150+ backing organizations. ACP and Stripe own checkout and settlement. Each layer is maturing.

But between communication and settlement, there's a gap. A2A tells agents how to find each other and coordinate tasks. ACP tells agents how to pay each other. Nobody tells agents how to reach agreement on what they're paying for, under what terms, with what commitments, and with what recourse if things go wrong.

That gap is where every consequential agent interaction lives. It's where procurement happens, where partnerships form, where service-level agreements get negotiated, where compliance requirements get verified, where trust gets established between agents that have never met.

## Concordia Exists

Concordia Protocol is the open negotiation standard for autonomous agents. It's not a whitepaper. It's not a proposal. It's shipped.

48 MCP tools. Structured negotiation with binding commitments. Session receipts that cryptographically prove what was agreed. Graceful degradation for mixed-protocol environments. Multi-party negotiation support. Composable primitives. Domain-agnostic extensibility.

Published on PyPI. Open source, Apache-2.0. 587 tests passing.

The protocol is simple because the problem is clear: agents need to agree on terms before they transact, and those agreements need to be structured, binding, and verifiable. Everything else follows from that.

Nobody else is building this. An arXiv survey of agent communication protocols published this month confirms what we already knew — there is no open standard for agent negotiation. Proprietary procurement platforms (Keelvar, Zycus) validate that the market for machine-to-machine negotiation exists, but they're closed systems for specific verticals, not open protocols for the agentic economy.

## The Window

The agentic economy doesn't wait for standards bodies to convene. The window for establishing the agreement layer is open now — while A2A is still defining its boundaries, while ACP is focused on payments, while enterprises are just starting to deploy agents that need to negotiate with each other.

Concordia is already in that gap. The question isn't whether agents will need structured negotiation. The question is whether the standard will be open, composable, and agent-native — or whether it will be a proprietary afterthought bolted onto whatever communication layer wins.

We're building for the first one. Because every interaction is a transaction — and transactions need structure.

`pip install concordia-protocol`

---

*Erik Newton is the author of Sanctuary Framework and Concordia Protocol — open infrastructure for the agentic economy. He is a licensed California attorney and the cofounder of CIMC.ai*

---

## X Article Version

Your agent can talk to other agents. It can pay other agents. But it can't agree on terms with other agents.

That's the gap in the agentic stack right now. MCP handles tools. A2A handles communication. ACP and Stripe handle settlement. Nobody handles the part where two agents actually negotiate — propose terms, counteroffer, commit, and prove what was agreed.

This matters because we're not building chatbots anymore. We're building agents that handle procurement, logistics, compliance, and resource allocation at machine speed, across organizational boundaries. Enterprise procurement alone involves millions of multi-party negotiations annually. Every one of them has price, delivery, quality, and liability terms that need to be agreed before anything gets paid.

Right now, agents "negotiate" in natural language. One sends a message. The other interprets it. Maybe they agree. Maybe they agree to something slightly different. Nobody knows, because there's no structure — just vibes. That's fine for demos. It's not fine for the real economy.

Agent-native negotiation looks different. Proposals are structured data, not paragraphs. Counteroffers modify specific fields, not entire conversations. Acceptance is cryptographically binding. Session receipts are machine-verifiable. And when the other agent doesn't speak the protocol, the system degrades gracefully instead of crashing — documenting the gap and proceeding with whatever structure is available.

An arXiv survey of agent communication protocols published this month confirms what the stack diagram makes obvious: there is no open standard for agent negotiation. Proprietary procurement platforms like Keelvar and Zycus validate that the market exists, but they're closed systems for single verticals — not an open protocol for the agentic economy.

Concordia Protocol is that open standard. Not a whitepaper — shipped software. 48 MCP tools, binding commitments, session receipts, multi-party support, domain-agnostic extensibility. Open source, Apache-2.0.

The window for establishing the agreement layer is open now. It won't stay open long.

`pip install concordia-protocol`

github.com/eriknewton/concordia-protocol
