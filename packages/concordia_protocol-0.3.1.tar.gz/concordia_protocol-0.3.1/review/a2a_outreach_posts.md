# A2A Composition Outreach Posts

**Date:** April 1, 2026
**Source content:** `Concordia/docs/A2A_COMPOSITION.md`
**Status:** DRAFT — awaiting Erik's review

---

## 1. A2A GitHub Discussions Post

**Title:** Concordia Protocol: An Open Agreement Layer That Composes with A2A

**Body:**

Hi all — I've been building in the agentic protocol space and wanted to share some thinking on how A2A's task coordination composes with structured negotiation.

**The gap:** A2A handles communication and task lifecycle. ACP/Stripe handle settlement. But between "we can talk" and "pay now," there's a missing step — agreeing on terms. Price, timeline, SLAs, scope, liability. When two agents need to negotiate before one assigns a task to the other, there's no open standard for that interaction.

**Concordia Protocol** is an open negotiation standard designed to compose with A2A, not compete with it. The handoff is clean:

1. **Discovery** — Agent B finds Agent A via A2A Agent Card
2. **Negotiation** — Concordia session: propose → counter → accept (structured, multi-attribute, signed)
3. **Commitment** — Signed agreement record with hash-chained transcript
4. **Execution** — A2A Task referencing the Concordia commitment ID
5. **Settlement** — Payment via ACP

No protocol overlap. Each layer does one thing.

**What Concordia provides that A2A deliberately doesn't:**
- Structured multi-attribute offers (not unstructured messages)
- Counteroffers that modify specific fields
- Cryptographically binding commitment records
- Behavioral reputation attestations from completed negotiations
- Graceful degradation when the other agent doesn't speak the protocol
- Demand-side discovery (want registry — complement to Agent Cards)

**Composition patterns we've built:**
- Negotiation before task assignment
- Renegotiation during execution (Concordia sub-session linked to A2A task ID)
- Multi-party negotiation using Concordia semantics over A2A transport
- "Concordia Preferred" field in Agent Cards for protocol discovery

The full composition story is here: [Concordia + A2A: The Agreement Layer the Protocol Stack Is Missing](https://github.com/eriknewton/concordia-protocol/blob/main/docs/A2A_COMPOSITION.md)

The protocol is shipped — 48 MCP tools, 587 tests, Apache-2.0. `pip install concordia-protocol`

Interested in feedback from anyone building enterprise agent workflows where terms need to be negotiated before execution — procurement, service contracting, resource allocation, SLA negotiation.

GitHub: https://github.com/eriknewton/concordia-protocol
Spec: https://github.com/eriknewton/concordia-protocol/blob/main/SPEC.md

---

## 2. Hacker News Post

**Title:** Concordia Protocol – Open negotiation standard for autonomous agents (composes with A2A)

**URL:** https://github.com/eriknewton/concordia-protocol

**HN Comment (post immediately after submission):**

Author here. The agentic protocol stack is converging — MCP for tools, A2A for communication, ACP for settlement — but there's no open standard for the part where agents actually agree on terms before transacting.

Concordia fills that gap. Structured multi-attribute negotiation with binding commitments, session receipts, and graceful degradation. Designed to compose with A2A (negotiation before task assignment, renegotiation mid-flight, multi-party via A2A transport) rather than compete with it.

The composition story in detail: https://github.com/eriknewton/concordia-protocol/blob/main/docs/A2A_COMPOSITION.md

An arxiv survey of agent interoperability protocols published in February mapped MCP, A2A, ACP, and ANP — and found no general-purpose negotiation protocol. Meanwhile proprietary procurement agents (Keelvar, Zycus) are building closed negotiation systems. The window for an open standard is now.

48 MCP tools, 587 tests, Apache-2.0. `pip install concordia-protocol`

Happy to answer questions about the protocol design, the A2A composition patterns, or the competitive landscape.

---

## 3. DEV.to Article

**Title:** The Agentic Protocol Stack Has a Gap. Here's How to Fill It.

**Tags:** ai, agents, protocols, opensource

**Body:**

The agentic protocol stack is converging fast:

- **MCP** (Anthropic) — tool integration, 97M monthly SDK downloads
- **A2A** (Google → Linux Foundation) — inter-agent communication, 150+ backing orgs
- **ACP** (OpenAI/Stripe) — checkout and settlement

Each layer is well-funded, maturing, and converging on a standard. But look at the stack and you'll notice something missing:

```
  Settlement    ACP · Stripe · Lightning
  ─────────────────────────────────────────
  Agreement     ???
  ─────────────────────────────────────────
  Communication A2A · HTTPS · JSON-RPC
  ─────────────────────────────────────────
  Discovery     Agent Cards · Well-Known URIs
  ─────────────────────────────────────────
  Tools         MCP
```

Between "we can talk to each other" and "pay now" — where do agents agree on terms?

### The problem is real and immediate

Enterprise procurement agents are already being deployed at scale. These agents discover suppliers, compare options, and execute purchases. But the negotiation step — price, timeline, SLAs, quality requirements, liability — is handled by proprietary, closed systems. There's no open protocol for it.

A2A deliberately doesn't handle this. Its scope is task coordination: create task, report status, pass artifacts. That's the right design. Negotiation is a different problem with different primitives.

ACP assumes the price is already known. It's a checkout protocol. That works for retail. It doesn't work for B2B, where every deal has negotiated terms.

### Concordia Protocol

[Concordia](https://github.com/eriknewton/concordia-protocol) is an open negotiation standard for autonomous agents. Five core verbs: **propose, counter, accept, reject, commit.** Simple primitives, infinite composition.

What it provides:

- **Structured offers** — Multi-attribute proposals (price, timeline, scope, SLAs) as machine-readable data, not natural language
- **Counteroffers** — Modify specific fields, not entire conversations
- **Binding commitments** — Cryptographically signed agreement records with hash-chained transcripts
- **Session receipts** — Machine-verifiable proof of what was agreed
- **Reputation attestations** — Behavioral records from completed negotiations, portable across platforms
- **Graceful degradation** — When the other agent doesn't speak Concordia, the system falls back gracefully instead of failing
- **Want registry** — Demand-side discovery (complement to A2A's supply-side Agent Cards)

### Composing with A2A

Concordia doesn't compete with A2A — it composes. The natural workflow:

```
1. Discovery     Agent Card (A2A)
2. Negotiation   propose → counter → accept (Concordia)
3. Commitment    Signed agreement record (Concordia)
4. Execution     Task lifecycle (A2A)
5. Settlement    Payment (ACP)
```

No overlap. Each protocol handles its layer.

This also works for renegotiation mid-task (Concordia sub-session linked to A2A task ID), multi-party negotiations over A2A transport, and protocol discovery via a "Concordia Preferred" field in Agent Cards.

Full composition details: [Concordia + A2A Composition Story](https://github.com/eriknewton/concordia-protocol/blob/main/docs/A2A_COMPOSITION.md)

### Try it

```bash
pip install concordia-protocol
```

48 MCP tools. 587 tests. Apache-2.0. The [spec](https://github.com/eriknewton/concordia-protocol/blob/main/SPEC.md) is designed to be implementable by any agent that can read JSON and hold Ed25519 keys.

The negotiation gap won't stay open forever. Proprietary procurement platforms are already building closed negotiation systems. The question is whether the standard will be open or locked in.

We're building for open.

[GitHub](https://github.com/eriknewton/concordia-protocol) · [Spec](https://github.com/eriknewton/concordia-protocol/blob/main/SPEC.md) · [A2A Composition Story](https://github.com/eriknewton/concordia-protocol/blob/main/docs/A2A_COMPOSITION.md)
