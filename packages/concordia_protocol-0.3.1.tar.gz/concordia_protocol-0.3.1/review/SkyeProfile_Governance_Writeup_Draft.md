# SkyeProfile Governance Write-up — Reference Issuer vs Reference Orchestrator

**Status:** DRAFT — Erik reviews Monday 2026-04-13 morning, edits to taste, posts to #1734 as the promised Monday write-up responding to @douglasborthwick-crypto's Apr 11 proposal.

**Context:** Douglas offered SkyeProfile as a second reference implementation. He flagged a governance question: does `reference-implementations/` carry one entry type (issuers only) or two (issuers + orchestrators)? Erik's ack post said "yes pending Monday write-up" and reserved the full answer.

---

## What this is about (non-technical context for Erik)

Douglas built two different things that he's offering to contribute to the new trust-evidence-format org. They serve very different roles, and that difference raises a governance question about what the org's `reference-implementations/` folder should contain.

**InsumerAPI** is a "reference issuer" — think of it like a credit bureau that *produces* credit reports. It takes raw data about an agent, runs its analysis, and signs a structured attestation saying "here's what we found." It's a factory that stamps out trust evidence.

**SkyeProfile** is a "reference orchestrator" — think of it like a loan officer's dashboard that *consumes* credit reports from multiple bureaus, cross-checks them, handles the quirks of each bureau's format, and presents a unified view. It doesn't produce attestations — it assembles them into something a human or agent can act on.

The governance question: should the `reference-implementations/` folder only contain factories (issuers), or should it also contain dashboards (orchestrators)?

**My recommendation in the draft: both, as flat peers.** A standard that only shows people how to produce trust evidence but not how to consume it is half a standard. InsumerAPI teaches "here's how to sign." SkyeProfile teaches "here's how to verify and compose." Both are essential for anyone adopting the format. The lightweight governance mechanism is just a `role:` label in each project's README — either "issuer" or "orchestrator" — so future contributors know which learning path each reference serves.

Douglas already maintains both projects. This just extends his existing scoped-committer arrangement to cover the second one.

---

## Post Text

**Reference implementations — issuers and orchestrators**

@douglasborthwick-crypto — the SkyeProfile governance question you raised is the right question at the right time. Here's where I land.

**Yes to both entry types, at a flat peer level.**

`reference-implementations/` should carry both reference issuers and reference orchestrators. They serve different learning paths and validate different parts of the spec:

- A **reference issuer** (InsumerAPI) teaches: "here is how to sign a conforming 10-dimension attestation envelope, implement `/v1/attest` + `/v1/trust` + wallet-resolve, and emit evidence that consumers can verify."
- A **reference orchestrator** (SkyeProfile) teaches: "here is how to consume attestations from multiple issuers, verify binding signatures, handle coordination patterns (warm-then-attest, reverse by-wallet index, kid rotation), and compose them into a consumer-facing interface."

Both are essential. A spec that only shows how to sign but not how to consume is half a spec. The evidence envelope format needs to be validated from both sides — and SkyeProfile already does this with 10 signed dimensions, three-state badge UI, and live coordination across APS, RNWY, SAR, and AgentGraph payloads.

**Directory structure:**

```
reference-implementations/
  insumerapi/          # reference issuer
    README.md          # role: issuer, scope, maintainer, setup
    ...
  skyeprofile/         # reference orchestrator  
    README.md          # role: orchestrator, scope, maintainer, setup
    ...
```

Each subdirectory carries a `README.md` with a `role:` field at the top — either `issuer` or `orchestrator`. That's the only structural distinction. No separate directories, no hierarchy between them. Flat peers, different roles, same governance rules.

**Scoping rule for future contributions:** any reference implementation that lands in this directory should declare its role in the README header and scope its contribution to that role. An issuer implementation doesn't need to show consumption. An orchestrator doesn't need to show signing. If someone builds a full-stack reference that does both, it declares both roles and the README explains which parts serve which purpose.

**On the practical question of who maintains what:** Douglas, you've already scoped yourself to `reference-implementations/insumerapi/` and the wallet_state/InsumerAPI crosswalk sections. I'm comfortable extending that to `reference-implementations/skyeprofile/` under the same scoped-committer arrangement — you maintain both, with the same review norms that apply to everything else in the org.

Welcome to have others weigh in before this lands in `governance/`, but I wanted to get the directional answer out on the Monday I promised it.

---

**Notes for Erik's review:**
- This resolves the governance question with a clear "yes, both, flat peers" answer
- The `role:` field in README.md is a lightweight governance mechanism that scales — future contributors just declare their role
- Keeps Douglas's scoped-committer arrangement clean — he maintains both InsumerAPI and SkyeProfile
- Mentions RNWY naturally (SkyeProfile already consumes their payloads) — reinforces the ecosystem-is-real signal
- The "welcome to have others weigh in" close invites nanookclaw and kenneives to engage without demanding it
- No CIMC attribution
- Tone: decisive but inviting of input, lawyer-who-structures-things energy


{monday note from Erik: this looks correct, but I need a non-technical explanation, please}
