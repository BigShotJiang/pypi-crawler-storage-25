

# Vocabulary Transfer Announcement — Draft for #1734

**Status:** DRAFT — Erik reviews Monday 2026-04-13 morning, edits to taste, posts to #1734.

**Context:** This announces the transfer of `aeoess/agent-governance-vocabulary` to the new `trust-evidence-format` GitHub org. Two-week notice window: announce Mon 4/13, circulate by Fri 4/17, notice runs 4/17→5/1, execution Mon 5/4. Per Erik's #1734 commitment, this is a rename/transfer, NOT a fork-and-archive.

---

## What this is about (non-technical context for Erik)

The A2A trust-evidence-format ecosystem needs a shared vocabulary — agreed-upon names for things like "what kind of trust signal is this?" and "what dimensions does an attestation cover?" Without it, every provider invents their own terms and nothing interoperates cleanly.

A contributor named aeoess already built a solid v0.1 vocabulary in his personal GitHub repo (`aeoess/agent-governance-vocabulary`). Four people contributed to it: aeoess himself, QueBallSharken, Douglas (douglasborthwick-crypto), and MoltyCel. It has a clean three-layer design: canonical terms at the top, a multi-issuer spec in the middle, and per-system translation mappings at the bottom.

You committed in #1734 to moving this vocabulary into the new `trust-evidence-format` org so everything lives under one roof — the spec, the vocabulary, the reference implementations, and the governance docs. This is a *transfer* (GitHub moves the repo and preserves all history, contributors, and URLs via automatic redirects), not a fork (which would create a copy and abandon the original).

The announcement below gives all contributors formal notice, names them explicitly so no one's work gets lost in the move, and opens a two-week comment window before execution. This is standard open-source governance practice — you don't move a shared repo without telling the people who built it.

QueBallSharken and MoltyCel haven't been active in #1734, so they may not see this post. Consider DMing them directly as a courtesy.

---

## Post Text

**Vocabulary transfer — two-week notice**

As discussed in this thread, we're moving `aeoess/agent-governance-vocabulary` into the `trust-evidence-format` org so the canonical vocabulary lives under the same roof as the spec, reference implementations, and governance docs.

This is a **rename/transfer**, not a fork. All existing commit history, PRs, and contributor attribution will be preserved. The new home will be `trust-evidence-format/agent-governance-vocabulary` (exact org name pending final confirmation from @kenneives).

**What this means for contributors:**

The v0.1 vocabulary draft was shaped by @aeoess (APS focus), @QueBallSharken (descriptor dimensions and BBIS distinctions), @douglasborthwick-crypto (InsumerAPI/SkyeProfile architecture), and @MoltyCel (MolTrust/AAE schema work). Your contributions carry forward intact — same Apache-2.0 license, same commit history, same authorship. Nothing is being rewritten or re-attributed.

**Timeline:**

- **Now → Fri Apr 17:** Open comment period. If you have concerns about the transfer or the org structure, raise them here or DM me directly.
- **Fri Apr 17 → Fri May 1:** Formal two-week notice window. GitHub redirects from the old URL will be automatic.
- **Mon May 4:** Transfer executed.

**Org structure reminder** (from my earlier post): the `trust-evidence-format` org will have `spec/`, `vocabulary/`, `reference-implementations/`, and `governance/` at the top level. The vocabulary repo slots into `vocabulary/` as the canonical term registry. Crosswalks, per-system mappings, and the three-layer architecture (canonical → multi-issuer spec → per-system crosswalk) all carry forward as-is.

If you contributed to the vocabulary and I haven't named you above, please flag it — I want the record correct before we move.

---

**Notes for Erik's review:**
- Tone is direct and warm, respects contributor work, doesn't over-explain
- Explicitly names all four v0.1 co-authors from the vocabulary repo
- Two-week notice window matches what you committed to in #1734
- The "[exact org name pending]" hedge is there because kenneives hasn't confirmed yet — remove the parenthetical once he does
- No CIMC attribution anywhere
- Consider whether @QueBallSharken and @MoltyCel need a direct DM in addition to the public post — they haven't been active in #1734

{Erik will need some non-technical context here as well}