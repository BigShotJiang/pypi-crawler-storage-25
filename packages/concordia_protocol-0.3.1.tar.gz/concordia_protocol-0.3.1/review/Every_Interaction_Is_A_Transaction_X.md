# Every Interaction Is a Transaction

Your agent can talk to other agents. It can pay other agents. But it can't agree on terms with other agents.

That's the gap in the agentic stack. MCP handles tools (97M monthly SDK downloads). A2A handles communication (Linux Foundation, 150+ orgs). ACP and Stripe handle settlement. Nobody handles the part where two agents actually negotiate — propose terms, counteroffer, commit, and prove what was agreed.

This matters because we're not building chatbots anymore. We're building agents that handle procurement, logistics, compliance, and resource allocation at machine speed, across organizational boundaries. Enterprise procurement alone involves millions of multi-party negotiations annually. Every one has price, delivery, quality, and liability terms that need to be agreed before anything gets paid.

Right now, agents "negotiate" in natural language. One sends a message. The other interprets it. Maybe they agree. Maybe they agree to something slightly different. Nobody knows, because there's no structure — just vibes. Fine for demos. Not fine for the real economy.

Agent-native negotiation looks different. Proposals are structured data, not paragraphs. Counteroffers modify specific fields, not entire conversations. Acceptance is cryptographically binding. Session receipts are machine-verifiable. When the other agent doesn't speak the protocol, the system degrades gracefully — documenting the gap and proceeding with whatever structure is available.

Those session receipts do double duty. Each one is cryptographic proof of what was agreed, by whom, when. Feed them into a reputation layer and you get trust scores that are earned through verifiable behavior, not self-reported. We built Verascore for exactly this: multi-provider attestation aggregation, adversarial scoring weights, portable W3C DID identity. Six providers integrated. Public trust score endpoint. No API key for reads.

The loop: Concordia produces structured agreements → receipts become trust evidence → Verascore aggregates into reputation scores → scores inform the next negotiation. Agreement, evidence, reputation, agreement.

Two weeks ago I would have said "nobody else is building this." That's no longer true. In the A2A Discussion forums, contributors from multiple organizations are now collaborating on trust evidence formats, shared governance vocabulary, and standardized attestation envelopes. A GitHub org is forming this week to steward those shared specs. An ecosystem is converging on the primitives.

An arXiv survey of agent communication protocols published last month still confirms: no other open standard for agent negotiation exists. But the surrounding trust infrastructure is being built by a community now, not just a solo project. Stronger foundation.

One more thing. EU AI Act full enforcement: August 2, 2026. Sixteen weeks. High-risk AI systems need documented decision-making processes, risk assessments, accountability chains. Agents negotiating autonomously need provable agreement records. Structured negotiation with binding receipts isn't just good engineering — it's becoming a regulatory requirement.

Concordia Protocol: 56 MCP tools, binding commitments, session receipts, agent discovery, multi-party support, graceful degradation, domain-agnostic extensibility. Open source, Apache-2.0. 705 tests passing.

The window for establishing the agreement layer is open now. An ecosystem is forming around it.

`pip install concordia-protocol`

github.com/eriknewton/concordia-protocol
