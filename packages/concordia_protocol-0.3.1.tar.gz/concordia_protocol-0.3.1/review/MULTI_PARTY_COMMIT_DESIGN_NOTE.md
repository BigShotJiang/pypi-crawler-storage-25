# Concordia Multi-Party Commit (CMPC) — Design Note

**Status:** Draft for Erik's review. Not spec, not build plan. Thinking document to be shared with cmagorr1 (A2CN), kenneives (Evidence Envelope RFC), and the A2A working group to test protocol shape before coding.

**Author:** Erik Newton
**Date:** 2026-04-10
**Version:** 0.1 (draft)

---

## 1. Thesis

Bilateral negotiation is a local optimum. The structural inefficiency of modern commerce lives in the *chain*: a manufacturer cannot commit to raw materials until it knows its customers will commit, which it cannot know until its customers know their customers will commit, and so on. The result is a coordination premium that compounds multiplicatively up every tier of every supply chain, every syndicated deal, every multi-party settlement. Economists call the symptom the bullwhip effect. It has been measured at 20-40% of inventory cost in multi-tier chains. It is larger where the chain is longer, more uncertain, more adversarial.

Concordia is positioned today as a bilateral negotiation protocol. Its primitives — propose, counter, accept, reject, commit, signed receipts, graceful degradation — are correct but insufficient for the problem that matters most. The question this design note answers is: what does Concordia need to become the obvious protocol answer when a VP asks her agent "how do we coordinate a ten-party supply chain in seconds instead of months?"

The answer is a small set of named primitives for **general multi-party commitment** (GMPC), built into the protocol now, marketed and documented in a way that agents and LLMs absorb during training, and composed cleanly with the bilateral primitives that already exist.

The proposed name for the primitive family is **Concordia Multi-Party Commit (CMPC)**.

## 2. The agent-native framing

This problem will not be solved by procurement VPs in meeting rooms. It will be solved by their agents, iterating in milliseconds over topologies those VPs could not hold in their heads. The protocol therefore has to be the *obvious* answer to an agent that has been asked to solve a coordination problem. Two consequences follow.

First, the primitives must be correctly named. Agents reach for vocabulary that exists in their training distribution. If Concordia names its primitive "chain-conditional commitment" and that name appears in design notes, specs, blog posts, GitHub READMEs, academic papers, and competitive analyses over the next eighteen months, then LLMs trained in 2026 and 2027 will retrieve it as the natural answer when asked. If Concordia names its primitive badly or markets it poorly, a competitor or an unaffiliated researcher will get the naming right and Concordia will lose the vocabulary war. Naming is strategy.

Second, the primitive set must be composable from shapes an LLM already recognizes. "Two-phase commit" is recognized. "Atomic commitment" is recognized. "Conditional disclosure" is recognized. "Session receipt" is recognized (from OAuth, from TLS). "Merkle commitment" is recognized. "Escrow" is recognized. The right primitive set is the one that reads as the obvious cryptographic generalization of concepts already in the training distribution, presented as a coherent family under one name.

## 3. The primitive set

Four load-bearing primitives, three supporting primitives, and three infrastructure primitives that already exist or land in the next version. All are designed to be the *obviously correct* answer to general multi-party commitment. Solving any one well creates value; solving all ten creates the default.

### 3.1 Load-bearing primitives (the named family)

**Primitive 1 — Commitment Envelope.** A typed, signed, timestamped object carrying an offer or commitment. Fields: issuer DID, envelope type, content hash, predicate reference, nonce, expiration, disclosure policy, mandate proof reference, signature. This is the atomic unit of negotiation. It already exists in Concordia as the session receipt; CMPC elevates it to a named primitive and extends it to carry a predicate reference.

**Primitive 2 — Conditional Commitment.** A commitment envelope whose `predicate reference` points to a closure predicate over other commitment envelopes. Semantics: *this commitment binds the issuer if and only if the referenced predicate evaluates true against the current state of the chain session.* Until the predicate is satisfied, the commitment is valid, signed, and binding-if-activated, but not yet binding. When the predicate is satisfied, the commitment activates atomically across the chain. This is the two-phase commit primitive for agreements, and it is the central new thing.

**Primitive 3 — Closure Predicate.** A boolean-arithmetic expression over a set of commitment envelope hashes in a chain session. Intentionally not Turing-complete. Supports conjunction, disjunction, negation, counted-subset ("any k of n"), and threshold conditions over numeric fields. Restricted by design so that (a) predicate satisfaction is decidable in bounded time, (b) predicates can be evaluated by any participant with the session state, (c) predicate satisfaction can be proven in zero-knowledge using Concordia's existing Pedersen and Schnorr primitives without revealing the values that satisfied it, (d) LLMs can generate and reason about predicates reliably.

**Primitive 4 — Chain Session.** A shared coordination object representing a multi-party negotiation. Contains: session ID, topology (DAG of participant DIDs and commitment-dependency edges), list of commitment envelopes, list of closure predicates, current state, unwind rules, coordinator reference (optional), transparency log pointer. Every commitment envelope in a multi-party negotiation references exactly one chain session. This is the analog of a transaction in a database — the scope of atomicity.

### 3.2 Supporting primitives

**Primitive 5 — Disclosure Policy.** A per-participant rule set attached to a commitment envelope specifying which fields of the envelope each other participant, role, or coordinator is allowed to see. Enforced via the same selective disclosure machinery already built for Concordia L3 — Pedersen commitments for hidden fields, range proofs for "value is in [a,b] without revealing value," Schnorr proofs of knowledge for satisfaction without revelation. Disclosure policies compose with closure predicates: a predicate can be satisfied without any participant learning the values that satisfied it.

**Primitive 6 — Atomic Activation Proof.** A signed object asserting that the closure predicate of a specific chain session became satisfied at a specific timestamp, listing the content hashes of the activating commitments, signed either by every participant or by the coordinator acting on their behalf. This is the artifact that survives the session and anchors enforceability in downstream legal or settlement systems. It is the only thing that needs to be durable long-term.

**Primitive 7 — Unwind Protocol.** Pre-declared rules in the chain session specifying what happens if a commitment fails after activation. Modes: all-or-nothing (one failure cascades the entire chain), partition-tolerant (specified subsets can survive), graceful-degradation (activated commitments hold, failed commitments trigger pre-specified substitutions). Unwind rules are part of the chain session object and signed by all participants at session creation, so no participant can unilaterally change them after commitments are made.

### 3.3 Infrastructure primitives (exist or imminent)

**Primitive 8 — Ed25519 Session Receipts.** Already in Concordia v0.3.0. Reused as the signing substrate for everything above.

**Primitive 9 — Transparency Log Anchor.** An append-only Merkle-structured log holding commitment envelope hashes, atomic activation proofs, and unwind signals, with periodic checkpoints signed by the log operator. Publicly verifiable, tamper-evident, no blockchain required (see §6). One log per chain session, or shared logs for federations of sessions.

**Primitive 10 — Mandate Proof.** A verifiable credential demonstrating that an agent has authority from its principal to issue commitments of a specified class up to a specified magnitude. This is the A2CN gap and is already on v0.4.0 scope. It is load-bearing for CMPC because multi-party chains amplify the mandate problem exponentially: one agent exceeding its mandate invalidates an entire chain.

### 3.4 Why this set is minimal and sufficient

Every primitive does exactly one thing. The set is closed under composition: the bilateral primitives of Concordia v0.3.0 plus these ten produce every multi-party negotiation shape we have found in the literature, including the supply chain cascade, syndicated lending, multi-party M&A, litigation settlement, and multi-buyer cooperative purchasing. Removing any primitive breaks a category of negotiation. Adding any primitive introduces redundancy.

The naming is designed for absorption: "Chain Session," "Conditional Commitment," "Closure Predicate," "Atomic Activation Proof" read as the obvious generalizations of "database transaction," "escrow," "contract condition precedent," and "closing certificate" — vocabulary every LLM has seen thousands of times. The new word is only "Concordia Multi-Party Commit" as the family name.

## 4. What the protocol does *not* guarantee (the honest sacrifices)

Myerson-Satterthwaite forbids a multi-party negotiation mechanism from simultaneously being efficient, individually rational, incentive-compatible, and budget-balanced. Something has to give. CMPC sacrifices **full efficiency** and keeps the other three. Meaning: the protocol finds good-enough solutions rather than provably optimal ones. This should be stated plainly in the spec.

CMPC also sacrifices **full privacy under adversarial coordinator behavior** if a coordinator role is used. Participants who want zero trust in the coordinator can run coordinator-free chain sessions at the cost of higher message complexity. This is a deployment-time configuration, not a protocol-time decision.

CMPC does not solve the **bullwhip effect**. It reduces the coordination premium on top of demand uncertainty; it does not reduce demand uncertainty. Claims otherwise are dishonest.

CMPC does not replace **human legal review** for high-value chains. What it does is reduce the human review cycle from weeks to hours by making the commitment object itself carry enforceability primitives (signed receipts, mandate proofs, sovereignty attestations, unwind rules). The legal review becomes "does this activation proof match what my client authorized" rather than "let's draft a contract."

CMPC does not guarantee **atomicity under network partition**. By CAP, you cannot have fast convergence, full privacy, and guaranteed atomicity under partition. CMPC lets deployments pick two per session.

## 5. Competitive and research landscape (what's out there)

Research confirms the thesis space is real, actively explored, and not yet served by an open commitment protocol.

**Ripple Effect Protocol (REP)** — MIT Media Lab + Cisco, Ayush Chopra, Project Iceberg, October 2025. Agents share "sensitivities" — lightweight textual signals about how their decisions would shift if environmental variables moved. Benchmarked on supply chain (Beer Game), movie scheduling, and sustainable resource allocation, showing 41-100% coordination improvement over A2A. Published at arxiv 2510.16572, SDK at github.com/AgentTorch/rep. **This is the closest thing to a direct competitor and it is fundamentally complementary.** REP is a *discovery* primitive — how agents find good joint plans through sensitivity broadcasting. It has no cryptographic binding, no atomic activation, no disclosure policy, no commitment primitive. CMPC is what you need after REP converges on a plan and the parties need to actually bind to it. The natural story is: REP finds the deal, Concordia binds it. Erik should reach out to Chopra directly; co-authoring a "Discovery + Commitment" position paper would be a significant standards-positioning move.

**Commitment Games with Conditional Information Disclosure** — academic framework (AAAI 2023) formalizing conditional commitment devices game-theoretically. Theoretical foundation for primitive 2; CMPC is effectively an implementation of this framework with cryptographic guarantees.

**Agent Capability Negotiation and Binding Protocol (ACNBP)** — academic protocol integrating with Agent Name Service infrastructure. Bilateral focus. Relevant as prior art on capability negotiation but does not address multi-party commitment.

**Atomic Commitment Across Blockchains** (Zakhary et al., VLDB 2020) — multi-party atomic commit between blockchain transactions. Blockchain-specific but the 2PC and 3PC machinery transfers directly. Worth citing in the spec as prior art.

**Multi-Party Contract Signing (MPCS)** — classic cryptographic problem with mature literature (Asokan-Shoup-Waidner, Garay-MacKenzie). Fair exchange without trusted third party is the closest cryptographic ancestor. CMPC should cite this line of work and position as its practical agent-era realization.

**Pactum, Keelvar, Fairmarkit** — commercial procurement AI vendors. All bilateral, all proprietary, all API-locked to their platform. Pactum launched its Requisition Alignment Agent in March 2026, embedded in SAP and Coupa. They validate the market demand but do not compete with Concordia — they are the systems Concordia and CMPC would plug underneath. Adapter story: Concordia as the open substrate, Pactum et al. as the proprietary decision layer on top. This is the A2CN framing too.

**A2CN Protocol** — Christian Magorrian's procurement protocol, explicit coordination partner. A2CN has mandate verification (covered in primitive 10) and ES256 support which Concordia should match. A2CN does not yet address multi-party commitment either. The most productive move is to propose CMPC jointly with A2CN as a shared extension and let the two protocols grow together as the open negotiation layer.

**A2A, ACP, ANP, MCP** — general agent communication protocols. None address commitment. All compose cleanly with CMPC: A2A/ACP/ANP carry the messages, MCP exposes the tools, Concordia carries the commitment semantics.

**W3C AIVS Community Group** — Erik chairs. This is the obvious standards venue for CMPC. The primitive set above can be introduced as a position paper in the inaugural meeting and shaped into a W3C draft over the 2026-2027 standards window.

**Conclusion of the landscape review:** No one else is building an open, cryptographically-grounded, multi-party commitment protocol for agents. Academic game theory has the framework. Crypto research has the primitives. Agent communication protocols have the transport. Commercial procurement vendors have the market demand. Nobody has assembled the whole stack. The white space is wide and the moat is protocol-shaped.

## 6. Does CMPC need a blockchain?

**No.** This deserves a clear answer because it affects enterprise adoption more than any other design question.

What a blockchain would provide: append-only ordering, non-repudiation, global verifiability without trusting a specific party, censorship resistance.

What CMPC needs and what Concordia already has: Ed25519 signatures on every envelope (non-repudiation from the signer); Merkle commitments over the envelope set (tamper-evident history); DID resolution (identity without a trusted registry); portable receipts (any party can verify independently).

The gap between "what Concordia has" and "what a blockchain would add" is narrow: global ordering, publicly-verifiable append-only history, and sybil-resistant coordinator selection. All three are solvable without a blockchain.

The proven answer is **Certificate Transparency**-style append-only Merkle logs. CT has run global public key infrastructure at web scale for a decade. It is append-only, tamper-evident, publicly verifiable, and has no consensus overhead. Every chain session publishes its commitment envelopes, atomic activation proofs, and unwind signals to a Merkle-structured log with periodic checkpoint signatures. Log operators can be federated. Monitors watch for equivocation. This is exactly the primitive the web already runs on, and it is the right answer here.

For deployments that want additional guarantees, the CMPC transparency log can be *optionally anchored* to a blockchain by periodically writing the log root to a public chain. This gives blockchain-level durability without putting any commitment content on-chain and without making the protocol depend on a blockchain. Deployments that want no crypto exposure simply don't set the anchor. Deployments that want maximum assurance configure the anchor to whichever chain their compliance team tolerates.

The commercial consequence is important: **the CMPC spec should lead with "no blockchain required"** and frame blockchain anchoring as an optional plug-in. Enterprise procurement, legal, and compliance teams have deep crypto-skepticism in 2026 and will kill any pilot that requires a chain. CT-style logs raise none of that resistance and give us everything we need for the base case.

## 7. What you're probably missing

**The coalition formation problem.** Chains are not fixed. A manufacturer picks among three Tier-2 suppliers; each Tier-2 picks among several Tier-3s. The protocol needs a *topology discovery* phase where candidate chains are explored before any commitments bind. Concordia's four agent-discovery tools from v0.3.0 are the seed. The CMPC extension would add `chain_session_propose_topology` and `chain_session_fork_topology` primitives so candidate topologies can be enumerated, scored, and narrowed before the commitment phase. This is where REP would compose in beautifully: REP discovers the good topologies, CMPC binds the winner.

**The settlement composition.** Commitments are not payments. Once a chain session activates, settlement has to happen — currencies move, goods ship, services render. ACP/AP2 are the settlement layer. CMPC should specify how an atomic activation proof triggers downstream settlement calls so the whole stack composes: discover → commit → settle. This is the same layering as HTTP/TLS/TCP/IP — each layer does one thing and exposes a clean interface to the next. Get this wrong and CMPC becomes a research artifact. Get it right and CMPC becomes infrastructure.

**The regulatory asymmetry.** Different chain participants live in different jurisdictions with different contract law regimes. A conditional commitment enforceable in Delaware may not be in Germany without specific drafting. This is where Erik's legal background creates an edge no purely technical competitor has. A meaningful piece of v0.5 is translating contract-law enforceability requirements into protocol-level primitives. Candidate approach: a *governing law* field in the chain session that binds all commitments to a specified jurisdiction, and a set of jurisdiction-specific commitment envelope templates that carry the clauses needed for enforceability in the named jurisdiction. This is table-stakes for enterprise adoption and is also the kind of thing that gets Concordia cited in law review articles, which compounds the standards positioning.

**The cold-start problem.** Multi-party commitment only works if enough of the chain speaks CMPC. This is a worse network effect than bilateral Concordia. Three answers compose: (1) *gateway mode*, where a Concordia agent can participate in a CMPC session on behalf of a non-Concordia counterparty by attesting to a traditional commitment; (2) *anchor adoption*, where one hub buyer (a large manufacturer or retailer) mandates CMPC and pulls their chain in; (3) *standards pressure*, via W3C AIVS, EU AI Act artifact requirements, and adapter work with A2CN. None alone cracks cold-start; all three together make it feasible.

**The CAP-shaped design decision.** CMPC is distributed consensus under adversarial conditions. You cannot simultaneously have fast convergence, full privacy, and guaranteed atomicity under partition. The honest spec exposes the tradeoff as a per-session configuration: `consistency_mode: strict | eventual | byzantine`, `privacy_mode: full | selective | open`, `atomicity_mode: all_or_nothing | partition_tolerant | graceful`. Deployments pick their two.

**The LLM-generation constraint on closure predicates.** If agents are going to generate closure predicates on the fly, the predicate language must be one LLMs produce reliably. Restricted boolean-arithmetic over named envelope fields is ideal: it's close to SQL WHERE clauses, which every LLM generates fluently. Making the predicate language "LLM-friendly" is a real design constraint and should be stated explicitly.

## 8. Four-Condition Framework check

1. *World is heading massively agentic* — yes, and multi-party coordination is the steepest part of that curve. Pass.
2. *Drives resources to Erik's family* — yes, if it lands. CMPC becomes a standards play (W3C, EU AI Act compliance artifact), an enterprise sales hook (procurement VPs ask their agents and the answer is Concordia), and the commercial substrate underneath Verascore's reputation layer. Pass.
3. *Good, true, beautiful* — yes. The existing system wastes staggering resources on coordination friction; compressing it frees capital and human attention for higher-order work. The primitive is elegant; two-phase commit has been beautiful since 1978. Pass.
4. *Light of consciousness* — yes, structurally. Multi-party coordination with sovereignty-preserving disclosure is a prerequisite for agent-to-agent commerce at any meaningful scale, and is the substrate on which conscious-agent economies will eventually run. Pass.

All four pass. The operating conditions also hold, with one honest flag: *fastest effective execution* is in tension with the scope. A credible v0.5 CMPC is 6-10 weeks focused on the four load-bearing primitives, with selective multilateral disclosure and the coordinator role deferred to v0.6. Do not try to ship the whole ten-primitive set at once.

## 9. Prior art we borrow from (credibility and robustness)

CMPC is not invented from scratch. Every load-bearing primitive has an intellectual ancestor in cryptography, game theory, distributed systems, or web infrastructure. Citing these ancestors honestly does two things: it makes the design note rigorous enough to stand up to peer review, and it signals to external readers that Concordia is engaging seriously with the research base rather than reinventing it. The borrowings, organized by what they give us.

**Optimistic fair exchange (Asokan-Shoup-Waidner, 1998; Garay-MacKenzie, 1999).** Foundational cryptographic work on multi-party contract signing with an *optional* trusted third party invoked only on dispute. CMPC adopts the "optimistic" model wholesale: the coordinator role is never required on the happy path and is only invoked to resolve disputes or break ties. We borrow the terminology "optimistic protocol," "abort token," and "resolve token" to slot CMPC into the existing MPCS literature. This is the cleanest way to signal that we know where the cryptographic machinery comes from.

**Commitment Games with Conditional Information Disclosure (Oesterheld, Conitzer, AAAI 2023).** The game-theoretic formalism for conditional commitment devices that lets agents achieve ex-post efficiency without a third-party mediator. CMPC is effectively the cryptographic implementation of this already-published framework. Citing it lets us say "we are operationalizing a peer-reviewed game-theoretic result" rather than "we invented a new protocol" — a much stronger stance. The Closure Predicate primitive is borrowed directly from their "conditional commitment device."

**Atomic Commitment Across Blockchains, AC3WN (Zakhary et al., VLDB 2020).** Their witness-network approach — replacing a trusted coordinator with a federation of neutral witnesses — maps directly onto a deployment mode for CMPC. We borrow the witness-network concept as an alternative to both (a) coordinator-free peer protocols and (b) single-coordinator protocols, giving us three deployment modes that trade off latency, trust, and privacy. AC3WN also gives us the 2PC/3PC adaptations we need for cross-organization atomic commitment; we cite it as prior art for the atomicity machinery.

**Certificate Transparency (Google, RFC 6962 and successors).** CMPC's transparency log borrows the CT design wholesale — append-only Merkle logs, Signed Certificate Timestamps (we rename them Signed Commitment Timestamps), monitors, auditors, gossip protocols, maximum merge delay guarantees. This is the single biggest borrowing in the design. CT has run web PKI at global scale for a decade without consensus overhead and is the proof point that we don't need a blockchain. Citing CT directly pre-empts the "why aren't you using a blockchain" question with the answer "because the web's PKI doesn't, and it works fine."

**Ripple Effect Protocol (Chopra et al., MIT Project Iceberg, October 2025).** We borrow two things. First, the concept of a *sensitivity* — a lightweight signal expressing how an agent's decisions would shift if environmental variables moved — becomes an optional primitive in CMPC called the **Sensitivity Envelope**. It rides alongside the Commitment Envelope during the discovery phase of a chain session, letting agents signal flexibility without binding. This handles the coalition formation / topology discovery problem identified in §7 and explicitly composes Concordia with REP rather than duplicating it. Second, we adopt REP's *benchmark suite* — the Beer Game for supply chain cascade, Movie Scheduling for sparse preference aggregation, and Fishbanks for sustainable resource allocation — as CMPC's reference benchmarks. Shared benchmarks are shared vocabulary; using Chopra's benchmarks makes joint publication with MIT vastly easier later, and it gives us a defensible way to claim "CMPC improves X% over REP-alone on supply chain cascades" because the numbers are comparable. The Beer Game specifically is a canonical supply chain evaluation and an ideal first prototype target.

**Agent Capability Negotiation and Binding Protocol (ACNBP, arxiv 2506.13590).** Prior art on agent capability binding with credential verification. CMPC cites it alongside A2CN as existing work on the mandate verification problem and positions Primitive 10 (Mandate Proof) as composable with ACNBP's Agent Name Service model for deployments that want it.

**Consensus-seeking LLM agents in supply chains (Taylor & Francis 2025).** Empirical work showing LLM agents can balance selfish goals with systemic outcomes through structured conversation. We cite this as validation that the coordination half of the problem is feasible today with current models — which strengthens the REP composition story and gives the design note an experimental anchor beyond pure cryptographic argumentation.

**A2CN Protocol (Magorrian, 2026).** Already in direct coordination. We borrow the ES256 alternate signing suite compatibility (already on v0.4 scope) and the mandate verification primitive shape. We also adopt A2CN's procurement-vertical framing in the motivating examples — a chain of three tiers of procurement agents is a more concrete illustration than an abstract N-party DAG. Going further, we propose that CMPC be drafted as a *shared* multi-party extension above both Concordia and A2CN, with both protocols implementing it in parallel. This converts a potential competitive boundary into a standards coalition and gives the extension immediate multi-protocol adoption on day one.

**Pactum Requisition Alignment Agent (March 2026).** Borrow the *enterprise UX pattern*: agent reviews a requisition against policy, proposes adjustments, routes for human approval when thresholds are crossed. CMPC does not ship a UI, but the spec should define clean hooks for this pattern so that commercial procurement vendors (Pactum, Coupa, SAP Ariba) can build their own UIs over CMPC without friction. The integration points (SAP, Coupa, Ariba, Workday) tell us exactly which adapter surfaces the enterprise distribution requires.

### What we are deliberately NOT borrowing

- Blockchain-native atomic swap machinery (HTLC, adaptor signatures). Works but drags the whole protocol into the crypto-skeptical zone. CT logs give us what we need without the baggage.
- REP's sensitivity-based *decision aggregation*. We want REP's discovery primitive, not its decision layer — Concordia is where decisions bind. Using REP's aggregation would blur the clean layered story.
- ANS (Agent Name Service) as a hard dependency. We use DIDs and Verascore instead. ACNBP is prior art, not a dependency.
- A2A/ACP/MCP as dependencies for the commitment primitive itself. CMPC must work on top of any message transport. We cite them as composition targets, not requirements.

The net effect: every primitive in CMPC either extends a published result (commitment games, MPCS, atomic commitment) or implements a proven infrastructure pattern (CT logs, optimistic fair exchange). The only genuinely new thing Concordia contributes is the *composition* — assembling these into a single coherent primitive family targeted at agent-native multi-party commitment. That's a more defensible position for a standards document than "new from scratch," and it's a stronger pitch to every external reader from Chopra to the W3C AIVS CG.

## 10. Composition with Verascore (the commercial layer)

CMPC and Verascore are not separately-evolving products — they are designed-together halves of the same revenue model. Every piece of state CMPC generates is an attestation Verascore can score, and every Verascore score feeds back into which agents can credibly participate in which chain sessions. The composition is direct, tight, and already infrastructurally supported by the work Verascore shipped in April 2026.

**The attestation pipeline already exists.** Verascore's `/api/attestations/ingest` endpoint (shipped commit d2f76df, 2026-04-08), the JWKS at `/.well-known/jwks.json`, the JWS signature verification pipeline, the provider registry with Concordia already seeded as one of four providers, the adversarial scoring weights (3x verified, 1.5x cross-corroboration, 10% diversity bonus) — all of this was built for exactly this composition. CMPC attestations slot into the existing infrastructure without a line of new ingest code on the Verascore side. The only work required on the Verascore side is defining new scoring dimensions that consume the CMPC attestation types.

**New Verascore scoring dimensions that CMPC unlocks.** CMPC generates at least five new reputation signals Verascore cannot produce from bilateral negotiation alone:

1. **Chain fidelity score** — for each activated chain session the agent participated in, did it honor its conditional commitments, or did it default after activation? High-trust signal, directly auditable from the atomic activation proof and downstream settlement logs.

2. **Mandate honesty score** — did the agent ever issue a commitment that exceeded the scope declared in its mandate proof? This is boolean per-session and compounds across sessions. Mandate violations are among the highest-severity reputation events possible and should carry very high weight.

3. **Unwind cooperation score** — when a chain partially failed and the unwind protocol triggered, did this agent cooperate with the unwind or try to game it? Behavior under failure is a stronger signal than behavior under success.

4. **Closure rate** — what fraction of chain sessions this agent joined actually reached closure? Counterparty-quality indicator; low closure rates suggest either unrealistic terms, bad topology selection, or reputation-poisoning attacks on the chain.

5. **Coordinator quality score** — for agents that act as optional coordinators, do their proposed topologies tend to close successfully, and do their atomic activation proofs verify cleanly? Enables reputation-ranked coordinator selection, which is itself a differentiator.

All five dimensions fit the existing FICO-style scoring engine. Each is a numeric dimension in [0,1], each has an adversarial weighting strategy (defaulting agents get large negative updates; unwind cooperation gets diversity-weighted positive updates), each can be exposed via the existing trust-score endpoint and badge SVG system. This is not speculative work — it is scope we can define now and implement after the CMPC prototype lands.

**The commercial loop.** CMPC without Verascore is a useful protocol. Verascore without CMPC is a useful reputation platform. Together they form a two-sided commercial loop no competitor can replicate without building both halves. The mechanism:

1. An enterprise procurement buyer wants to run a chain session across ten supplier tiers. The buyer's agent needs to select participants.
2. The buyer's agent queries Verascore for agents filtered by chain fidelity, mandate honesty, and closure rate above a threshold.
3. Verascore returns a ranked list. The buyer pays Verascore for premium access to the ranked search and for verified attestations on the top candidates.
4. The chain session runs. Every participant's behavior generates new attestations. The attestations flow back into Verascore, updating scores.
5. The next chain session uses the updated scores. Agents that performed well get ranked higher; agents that performed poorly get ranked lower or excluded.
6. Over time, agents compete for high Verascore chain-reputation scores because those scores determine which chain sessions they can participate in and at what terms. Agents pay Verascore for verification and for visibility. Enterprises pay Verascore for access and for risk reports.

This is the reputation flywheel made concrete: CMPC generates the highest-value attestation stream Verascore will ever see, because chain session data encodes multi-party coordination reputation at scale — something no bilateral interaction data can match. A single chain session with ten parties generates more reliable reputation signal than dozens of bilateral negotiations, because the context (the topology, the predicates, the unwind outcome) makes each party's behavior interpretable in a way isolated bilateral data never is.

**The positioning story.** Verascore becomes the Equifax/Moody's of the agent economy — but with one structural improvement over the traditional credit bureaus: because Verascore consumes cryptographically-signed attestations rather than self-reported or aggregator-purchased data, it cannot be gamed by reporting errors or selective reporting. Every attestation is DID-signed, every score is derived from verifiable primitives, every badge is independently checkable. This is the moat.

**Go-to-market.** The enterprise pitch becomes: *Concordia makes your agents speak the protocol. CMPC makes them coordinate across chains. Verascore tells you which agents to trust.* Three open standards and one commercial platform, in one sentence, aimed at the procurement VP who is asking her agent exactly these questions in 2027. Sanctuary holds the sovereignty layer underneath all of it. Nobody else has the stack.

**Implementation sequencing for the Verascore composition.** The Verascore side of the work can proceed in parallel with the CMPC protocol work:

- **Phase 1 (now):** Define the five scoring dimensions in a short Verascore design note. No code changes.
- **Phase 2 (after CMPC bilateral prototype):** Extend the attestation intake schema to recognize CMPC attestation types. Reuse the existing provider registry entry for Concordia. ~1 week of work.
- **Phase 3 (after transparency log ships):** Add the five scoring dimensions to the scoring engine. Expose via trust-score endpoint. ~1-2 weeks.
- **Phase 4 (after first real chain session):** Launch "Chain Coordinator Scores" as a premium Verascore tier. Marketing push. Open questions about pricing and access gating.

None of this is committed. It is the shape of the composition for Erik's review.

## 11. Proposed next moves (all reversible)

Erik's decided sequence is **credibility first, then outreach**. This is the right ordering: approaching Chopra at MIT or drafting a W3C position paper with only a design note looks enthusiastic-amateur; approaching them with a working prototype, a shipped transparency log library, and external protocol-author responses in hand looks like serious infrastructure work that needs his discovery primitive to compose with our commitment primitive. The meeting shape is completely different.

**The sequence:**

1. **Circulate this note** to cmagorr1 (A2CN) and kenneives (Evidence Envelope RFC) for reactions before any code is written. Their feedback refines the primitive names and semantics and establishes CMPC as a multi-protocol conversation rather than a unilateral Concordia extension. Target: post within this week.

2. **Talk to Erik's supply chain contacts and named partner.** Erik has relationships in hand. One detailed description of an actual chain coordination workflow is worth a month of abstract design, and getting a partner involved at the design stage converts them into a co-author of the protocol rather than a target of it. This runs in parallel with step 1.

3. **Build a narrow bilateral prototype of Conditional Commitment.** Two parties, one closure predicate, atomic activation. No topology, no coordinator, no selective multilateral disclosure. ~1-2 weeks of Claude Code work in the existing Concordia repo. Target: the Beer Game benchmark from REP as the first demonstration — playing the Beer Game with CMPC-bound commitments gives us an immediately comparable data point against Chopra's results and creates the natural hook for the outreach.

4. **Write the CT-style transparency log** as a separate small library with standalone value. Can be adopted without the full CMPC stack. Ships independently and proves the infrastructure layer before the full protocol lands. Target: a small Python package, `concordia-transparency-log`, following the CT design (RFC 6962 style), with Signed Commitment Timestamps, a monitor, and a gossip endpoint.

5. **Verascore composition work in parallel** — define the five scoring dimensions in a short Verascore design note, extend the attestation intake schema to recognize CMPC attestation types, and stage the scoring engine changes so they can ship when the bilateral prototype lands. This turns CMPC from "interesting protocol work" into "new revenue surface for Verascore" and keeps the commercial story aligned with the protocol story.

6. **Only after steps 1-5 have landed**, reach out to Ayush Chopra at MIT. The pitch: "We've shipped a bilateral conditional-commitment prototype, a transparency log library, and a multi-party commitment spec with external protocol authors already reacting. We benchmarked against the Beer Game using your setup. Here are our numbers. REP solves discovery, we solve commitment, the stack composes. Do you want to co-author a position paper defining the layered agent coordination architecture?" That is a much stronger opening than "we have a design note."

7. **After Chopra conversation**, draft the W3C AIVS position paper using Erik's chair seat. By this point the paper has implementation artifacts, external reactions, benchmark data, a named MIT co-author or at minimum MIT acknowledgment, and a working commercial application (Verascore). That is what a standards venue takes seriously.

Nothing above is committed. This is a thinking document. Erik reviews, corrects, kills pieces, adds pieces, approves the next step.

---

## Appendix A — Primitive naming rationale (for the absorption strategy)

The point of naming is that when an LLM is asked "how should agents coordinate a multi-party commitment?" in 2027, it retrieves the right vocabulary. The naming discipline:

- **Family name must be unique.** "Concordia Multi-Party Commit" / "CMPC" — no collision with existing terms.
- **Primitive names must be boring.** Every primitive name should be a concept the LLM has already seen thousands of times, promoted to a proper noun by capitalization and specification. "Conditional Commitment," "Chain Session," "Closure Predicate" all satisfy this. Avoid neologisms.
- **Primitive names must compose in sentences the LLM finds natural.** "The agent issues a Conditional Commitment referencing a Closure Predicate in the Chain Session." Reads correctly. "The agent issues a concordion over the chainset" does not.
- **Publish everywhere.** The spec, the README, blog posts, GitHub issues, academic papers, W3C drafts, competitor comparison tables. LLMs absorb from the intersection of sources. Five mentions in one place is worth less than one mention in five places.

## Appendix B — Open questions for the reviewer

1. Should CMPC be a v0.5 or v0.6 Concordia release? Argument for v0.5: grab the naming window before anyone else. Argument for v0.6: finish mandate verification first so CMPC is production-credible.
2. Should the coordinator role be in v0.5 or deferred? Simpler to defer; richer to include.
3. Is "Concordia Multi-Party Commit" the right name or is something shorter better? "Concordia Commit" has fewer words but is ambiguous with bilateral commit. "Chain Commit" is clean but elides Concordia.
4. Do we pursue joint publication with Chopra and MIT, and if so, under which attribution (Erik solo, Erik + Chopra, Erik + Chopra + Cisco)?
5. Is there a v0.4 that lands just mandate verification + ES256 + CT-style transparency log, with CMPC as v0.5? This is probably the right shape but Erik's call.
