# Build Prompt: MCP Registry Listing — Concordia Protocol

**Paste this into a Claude Code session pointed at `~/Desktop/Claude/Concordia`.**

---

## Context

Concordia Protocol is already published on PyPI (`pip install concordia-protocol`). We need to list it on the official MCP Registry at registry.modelcontextprotocol.io so it auto-indexes into LobeHub, Smithery, Glama.ai, and other downstream directories.

## Steps

### 1. Check if mcp-publisher CLI is available

```bash
pip install mcp-publisher --break-system-packages
```

If `mcp-publisher` doesn't exist on PyPI, we'll need to create a `server.json` manually and submit via the registry's GitHub-based flow.

### 2. Create `server.json` metadata

Create a `server.json` in the repo root following the MCP Registry spec:

```json
{
  "name": "io.github.eriknewton/concordia-protocol",
  "displayName": "Concordia Protocol",
  "description": "Open negotiation standard for AI agents. 56 MCP tools for structured negotiation (propose, counter, accept, reject, commit) with binding commitments, session receipts, and graceful degradation.",
  "version": "0.3.0",
  "publisher": {
    "id": "eriknewton",
    "name": "Erik Newton",
    "url": "https://github.com/eriknewton"
  },
  "repository": {
    "type": "git",
    "url": "https://github.com/eriknewton/concordia-protocol"
  },
  "packages": {
    "pypi": "concordia-protocol"
  },
  "tools": 56,
  "categories": ["negotiation", "trust", "agent-coordination", "sovereignty"],
  "license": "Apache-2.0"
}
```

Adjust the schema if the MCP Registry spec requires different fields. Check the spec at https://modelcontextprotocol.io/registry/quickstart.

### 3. If mcp-publisher exists, register:

```bash
mcp-publisher init  # if server.json needs adjustment
mcp-publisher login  # GitHub OAuth
mcp-publisher publish
```

### 4. If mcp-publisher doesn't exist, document the manual path:

Write a note in `review/MCP_REGISTRY_SUBMISSION.md` with:
- The server.json we created
- The manual submission URL or GitHub PR target
- Any namespace verification requirements (GitHub OAuth or DNS challenge for domain ownership)

### 5. Also create an awesome-mcp-servers PR draft

Create `review/AWESOME_MCP_SERVERS_PR.md` with the entry text for a PR to `wong2/awesome-mcp-servers`:

```markdown
### Concordia Protocol

Open negotiation standard for AI agents. 56 MCP tools for structured propose/counter/accept/reject/commit with binding commitments, session receipts, ZK competence proofs, and graceful degradation.

- [GitHub](https://github.com/eriknewton/concordia-protocol)
- [PyPI](https://pypi.org/project/concordia-protocol/)
```

## Acceptance criteria

- `server.json` exists in repo root with correct metadata
- Either registered on MCP Registry or manual submission path documented
- awesome-mcp-servers PR draft ready
- No CIMC attribution in any file

## Commit convention

```
Co-Authored-By: Claude <noreply@anthropic.com>
```
