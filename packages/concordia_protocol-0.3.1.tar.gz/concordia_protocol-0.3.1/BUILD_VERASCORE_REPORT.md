# Concordia → Verascore Report Tool — Claude Code Prompt

**Copy this entire file as a prompt to Claude Code. Run from `~/Desktop/Claude/Concordia/`.**

---

You are adding a Verascore reporting tool to Concordia Protocol. When a negotiation completes, this tool lets an agent push the session receipt to Verascore's transaction ingestion API, building portable reputation from real negotiations.

**Repo:** `~/Desktop/Claude/Concordia/`
**Stack:** Python, FastMCP, Ed25519 signing
**Attribution:** Erik Newton is the sole author. Never reference CIMC.

Read these files first:
- `concordia/mcp_server.py` (all 48 existing tools — understand the pattern)
- `concordia/receipt_bundle.py` (ReceiptBundle and BundleSummary dataclasses)
- `concordia/signing.py` (Ed25519 signing functions)
- `concordia/session.py` (NegotiationSession — how sessions track state)
- `CLAUDE.md` (hard constraints — especially #1: no external data without user intent, and #8: no raw deal terms in attestations)

## Build 1 feature: `concordia_verascore_report` MCP tool

### New file: `concordia/verascore.py`

This module handles the HTTP POST to Verascore. Concordia currently has no HTTP client dependency, so:

1. Use `urllib.request` (stdlib) — do NOT add `requests` or `aiohttp` as a dependency
2. Create a `VeRASCOReClient` class with:
   - `__init__(self, base_url: str = "https://verascore.ai")` — configurable endpoint
   - `report_concordia_receipt(self, session_data: dict, agent_private_key: bytes, agent_did: str) -> dict` — signs and posts

### Verascore API contract

POST `{base_url}/api/publish` with JSON body:

```json
{
  "type": "concordia-receipt",
  "did": "did:key:z6Mk...",
  "timestamp": "2026-04-06T...",
  "signature": "<ed25519 hex signature of payload>",
  "payload": {
    "session_id": "<negotiation session ID>",
    "counterparty_did": "<other party's DID>",
    "outcome": "agreed|rejected|expired|withdrawn",
    "rounds": 5,
    "duration_seconds": 120,
    "terms_count": 3,
    "concessions_made": 2,
    "fulfillment_status": "fulfilled|disputed|pending",
    "negotiation_competence": 85
  }
}
```

The `signature` covers the canonical JSON of the payload (use the same canonical serialization pattern from `signing.py`).

**CRITICAL:** The payload must NEVER include raw deal terms, prices, counterparty names, or any content from the negotiation itself. Only behavioral metadata (rounds, duration, concession count, outcome). This is hard constraint #8 from CLAUDE.md.

### Computing `negotiation_competence` (0-100)

Extract from session state:
- `base = 50`
- `+15` if outcome is "agreed"
- `+10` if fulfillment_status is "fulfilled"
- `+5` per round (max +15) — deeper negotiations show more skill
- `+10` if concessions_made > 0 (willingness to negotiate)
- `-20` if outcome is "expired" or "withdrawn" (penalize abandonment)
- Clamp to 0-100

### MCP tool in `mcp_server.py`

Add the tool registration at the end of the existing tool block:

```python
@mcp.tool(
    name="concordia_verascore_report",
    description=(
        "Report a completed negotiation to Verascore for reputation scoring. "
        "Extracts behavioral metadata from the session receipt (never raw deal terms) "
        "and posts it signed with the agent's Ed25519 key. "
        "Requires VERASCORE_ENABLED=true environment variable."
    ),
)
def tool_verascore_report(
    session_id: str,
    agent_id: str,
    fulfillment_status: str = "pending",
    verascore_url: str = "https://verascore.ai",
) -> str:
```

Requirements:
- Check `os.environ.get("VERASCORE_ENABLED", "false").lower() == "true"` — return friendly message if not enabled (respects hard constraint #1: no external data without user intent)
- Look up session from the relay's session registry
- Extract session metadata: counterparty, outcome, rounds, duration, terms count, concessions
- Compute negotiation_competence score
- Sign with agent's Ed25519 key (look up from signing module)
- POST via VeRASCOReClient
- Return success message with Verascore profile URL, or error details

### Error handling

- If session not found: return clear error
- If session still in progress (not finalized): return "Session must be finalized before reporting"
- If HTTP POST fails: return error with status code but DO NOT retry automatically
- If signing fails: return error (never fall back to unsigned)

## After building:

1. Run `python -m pytest tests/ -x` — fix any failures
2. Run `python -m mypy concordia/verascore.py --ignore-missing-imports` if mypy is available
3. Commit with message: "Add concordia_verascore_report tool — push negotiation receipts to Verascore"
4. Do NOT bump version or publish to PyPI — that's a separate step

## Code style rules:
- Match existing patterns in mcp_server.py exactly (docstring style, error handling, return format)
- Type hints on all function signatures
- No new dependencies (stdlib urllib.request only)
- Respect all 8 hard constraints from CLAUDE.md
- The tool count will go from 50 to 51
