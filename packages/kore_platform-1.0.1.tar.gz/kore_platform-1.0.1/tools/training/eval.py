"""Evaluate fine-tuned model on validation set and benchmark prompts.

Metrics measured:
    - val_loss:           Loss on the held-out validation set.
    - syntax_valid_rate:  Percentage of generated files that parse with ast.parse.
    - structure_score:    Percentage of outputs rated A or B by AnalyzeStructureSkill.
    - import_valid_rate:  Percentage of imports referencing existing modules in
                          the generated project.
    - file_completeness:  Percentage of outputs that include a pyproject.toml and
                          at least 3 files.

IMPORTANT: We do NOT compare string-exact against the reference completion.
The model may generate correct but structurally different code.

Usage:
    python -m tools.training.eval
    python -m tools.training.eval --model models/kore-coder-7b-lora
    python -m tools.training.eval --config tools/training/config.yaml
"""

from __future__ import annotations

import argparse
import ast
import json
import logging
import os
import re
import sys
from pathlib import Path
from typing import Any

import yaml

logger = logging.getLogger(__name__)

PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
DEFAULT_CONFIG = PROJECT_ROOT / "tools" / "training" / "config.yaml"


# ---------------------------------------------------------------------------
# Lazy imports
# ---------------------------------------------------------------------------

def _lazy_import(name: str):
    """Import *name* and return the module, or exit with a helpful message."""
    try:
        import importlib
        return importlib.import_module(name)
    except ImportError:
        print(
            f"[ERROR] Required package '{name}' is not installed.\n"
            f"  Install it with:  pip install {name}\n"
            f"  Or install the full training extras:  pip install -e '.[train]'"
        )
        sys.exit(1)


# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

def load_config(path: str | Path) -> dict[str, Any]:
    """Load evaluation/training config from YAML."""
    path = Path(path)
    if not path.is_absolute():
        path = PROJECT_ROOT / path
    if not path.exists():
        raise FileNotFoundError(f"Config file not found: {path}")
    with open(path, "r", encoding="utf-8") as fh:
        return yaml.safe_load(fh)


def _resolve_path(raw: str) -> Path:
    """Resolve a path relative to PROJECT_ROOT if not absolute."""
    p = Path(raw)
    if not p.is_absolute():
        p = PROJECT_ROOT / p
    return p


# ---------------------------------------------------------------------------
# Parsing helpers
# ---------------------------------------------------------------------------

FILE_TAG_RE = re.compile(
    r'<FILE\s+path="(?P<path>[^"]+)">\s*(?P<content>.*?)\s*</FILE>',
    re.DOTALL,
)


def parse_file_tags(text: str) -> dict[str, str]:
    """Parse ``<FILE path="...">content</FILE>`` tags from generated output.

    Parameters
    ----------
    text:
        Raw model output potentially containing FILE tags.

    Returns
    -------
    dict[str, str]
        Mapping of file path to file content.
    """
    files: dict[str, str] = {}
    for match in FILE_TAG_RE.finditer(text):
        fpath = match.group("path").strip()
        content = match.group("content")
        files[fpath] = content
    return files


# ---------------------------------------------------------------------------
# Metric functions
# ---------------------------------------------------------------------------

def check_syntax(files: dict[str, str]) -> float:
    """Try ``ast.parse`` on each Python file; return ratio of successful parses.

    Non-Python files are excluded from the count.

    Parameters
    ----------
    files:
        Mapping of filename to source code.

    Returns
    -------
    float
        Ratio in [0.0, 1.0].  Returns 1.0 if there are no Python files.
    """
    py_files = {k: v for k, v in files.items() if k.endswith(".py")}
    if not py_files:
        return 1.0

    valid = 0
    for fpath, source in py_files.items():
        try:
            ast.parse(source)
            valid += 1
        except SyntaxError as exc:
            logger.debug("Syntax error in %s: %s", fpath, exc)
    return valid / len(py_files)


def check_imports(files: dict[str, str]) -> float:
    """Check that imports reference modules that exist in the generated project.

    For each Python file we extract ``import X`` and ``from X import ...``
    statements and check whether ``X`` (the top-level module name) matches
    any filename stem in the generated file set.  Standard-library and
    third-party imports are ignored (only internal cross-references count).

    Parameters
    ----------
    files:
        Mapping of filename to source code.

    Returns
    -------
    float
        Ratio of valid internal imports in [0.0, 1.0].
        Returns 1.0 if there are no internal imports detected.
    """
    py_files = {k: v for k, v in files.items() if k.endswith(".py")}
    if not py_files:
        return 1.0

    # Build set of known module stems from all generated files
    known_stems: set[str] = set()
    for fpath in files:
        stem = Path(fpath).stem
        if stem != "__init__":
            known_stems.add(stem)
        # Also add dot-separated package paths
        parts = Path(fpath).with_suffix("").parts
        for i in range(len(parts)):
            known_stems.add(".".join(parts[i:]))

    total_internal = 0
    valid_internal = 0

    for fpath, source in py_files.items():
        try:
            tree = ast.parse(source)
        except SyntaxError:
            continue

        for node in ast.walk(tree):
            module_name: str | None = None
            if isinstance(node, ast.Import):
                for alias in node.names:
                    module_name = alias.name.split(".")[0]
            elif isinstance(node, ast.ImportFrom):
                if node.module:
                    module_name = node.module.split(".")[0]

            if module_name is None:
                continue

            # Only count imports that look internal (match a known stem)
            if module_name in known_stems:
                total_internal += 1
                # The module is known -- valid
                valid_internal += 1
            elif _looks_internal(module_name, known_stems):
                total_internal += 1
                # Looks like it tried to reference an internal module but
                # the target does not exist
                logger.debug(
                    "Possibly broken internal import '%s' in %s",
                    module_name,
                    fpath,
                )

    if total_internal == 0:
        return 1.0
    return valid_internal / total_internal


def _looks_internal(name: str, known_stems: set[str]) -> bool:
    """Heuristic: does *name* look like it is trying to reference a project module?

    We check if any known stem is a substring or vice versa, which catches
    cases like ``from app.models import ...`` when we have ``models.py``.
    """
    for stem in known_stems:
        if stem in name or name in stem:
            return True
    return False


def check_completeness(files: dict[str, str]) -> float:
    """Check for ``pyproject.toml`` and minimum file count.

    Returns 1.0 if the output contains a ``pyproject.toml`` AND at least 3
    files; 0.5 if only one condition is met; 0.0 otherwise.

    Parameters
    ----------
    files:
        Mapping of filename to content.

    Returns
    -------
    float
        Completeness score in {0.0, 0.5, 1.0}.
    """
    has_pyproject = any("pyproject.toml" in f for f in files)
    has_min_files = len(files) >= 3
    if has_pyproject and has_min_files:
        return 1.0
    if has_pyproject or has_min_files:
        return 0.5
    return 0.0


def check_structure(files: dict[str, str]) -> float:
    """Return the fraction of outputs that receive an A or B structure rating.

    Uses ``AnalyzeStructureSkill`` from the complexity agent.  If the skill
    is not importable (e.g. running outside the project venv), this metric
    is skipped and ``-1.0`` is returned as a sentinel value.

    Parameters
    ----------
    files:
        Mapping of filename to source code.

    Returns
    -------
    float
        Ratio in [0.0, 1.0], or -1.0 if the skill is unavailable.
    """
    try:
        from kore_platform.agents.complexity.skills.analyze_structure import (
            AnalyzeStructureSkill,
        )
    except ImportError:
        logger.warning(
            "AnalyzeStructureSkill not available -- skipping structure_score. "
            "Install the project with:  pip install -e '.[dev]'"
        )
        return -1.0

    skill = AnalyzeStructureSkill()
    try:
        result = skill.run(files=files)
        rating = result.get("rating", "F") if isinstance(result, dict) else "F"
        return 1.0 if rating in ("A", "B") else 0.0
    except Exception as exc:
        logger.warning("AnalyzeStructureSkill failed: %s", exc)
        return -1.0


# ---------------------------------------------------------------------------
# Generation helper
# ---------------------------------------------------------------------------

def _generate(model, tokenizer, prompt: str, max_new_tokens: int = 8192) -> str:
    """Generate text from the model given a prompt string."""
    torch = _lazy_import("torch")

    messages = [{"role": "user", "content": prompt}]
    text = tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
    inputs = tokenizer(text, return_tensors="pt").to(model.device)

    with torch.no_grad():
        output_ids = model.generate(
            **inputs,
            max_new_tokens=max_new_tokens,
            do_sample=False,
            temperature=1.0,
            pad_token_id=tokenizer.pad_token_id or tokenizer.eos_token_id,
        )
    # Decode only the new tokens
    generated_ids = output_ids[0][inputs["input_ids"].shape[1]:]
    return tokenizer.decode(generated_ids, skip_special_tokens=True)


# ---------------------------------------------------------------------------
# Main evaluation
# ---------------------------------------------------------------------------

def evaluate(
    model_path: str | Path | None = None,
    val_path: str | Path | None = None,
    config_path: str | Path = DEFAULT_CONFIG,
) -> dict[str, Any]:
    """Run full evaluation and return metrics dictionary.

    Parameters
    ----------
    model_path:
        Path to LoRA adapter directory (or merged model).  Defaults to
        ``config.model.output_dir``.
    val_path:
        Path to validation JSONL.  Defaults to ``config.dataset.val_path``.
    config_path:
        Path to the YAML config file.

    Returns
    -------
    dict[str, Any]
        Evaluation metrics.
    """

    # -- Config ----------------------------------------------------------------
    cfg = load_config(config_path)
    model_cfg = cfg["model"]
    quant_cfg = cfg["quantization"]
    train_cfg = cfg["training"]
    eval_cfg = cfg.get("eval", {})

    if model_path is None:
        model_path = _resolve_path(model_cfg["output_dir"])
    else:
        model_path = Path(model_path)
    if val_path is None:
        val_path = _resolve_path(cfg["dataset"]["val_path"])
    else:
        val_path = Path(val_path)

    # -- Lazy imports ----------------------------------------------------------
    torch = _lazy_import("torch")
    transformers = _lazy_import("transformers")
    peft = _lazy_import("peft")
    datasets_lib = _lazy_import("datasets")

    AutoModelForCausalLM = transformers.AutoModelForCausalLM
    AutoTokenizer = transformers.AutoTokenizer
    BitsAndBytesConfig = transformers.BitsAndBytesConfig
    PeftModel = peft.PeftModel

    # -- Load model + tokenizer ------------------------------------------------
    logger.info("Loading base model: %s", model_cfg["base"])
    compute_dtype = getattr(torch, quant_cfg.get("bnb_4bit_compute_dtype", "bfloat16"))
    bnb_config = BitsAndBytesConfig(
        load_in_4bit=quant_cfg.get("load_in_4bit", True),
        bnb_4bit_compute_dtype=compute_dtype,
        bnb_4bit_quant_type=quant_cfg.get("bnb_4bit_quant_type", "nf4"),
        bnb_4bit_use_double_quant=quant_cfg.get("bnb_4bit_use_double_quant", True),
    )

    base_model = AutoModelForCausalLM.from_pretrained(
        model_cfg["base"],
        quantization_config=bnb_config,
        device_map="auto",
        trust_remote_code=True,
        torch_dtype=compute_dtype,
    )

    logger.info("Loading LoRA adapter from %s", model_path)
    model = PeftModel.from_pretrained(base_model, str(model_path))
    model.eval()

    tokenizer = AutoTokenizer.from_pretrained(
        model_cfg["base"],
        trust_remote_code=True,
        padding_side="right",
    )
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    # -- Validation loss -------------------------------------------------------
    val_loss = None
    if val_path.exists():
        logger.info("Computing validation loss on %s", val_path)
        val_ds = datasets_lib.load_dataset("json", data_files=str(val_path), split="train")
        total_loss = 0.0
        count = 0
        for example in val_ds:
            prompt = example.get("prompt", "")
            completion = example.get("completion", "")
            text = (
                f"<|im_start|>user\n{prompt}<|im_end|>\n"
                f"<|im_start|>assistant\n{completion}<|im_end|>"
            )
            inputs = tokenizer(
                text,
                return_tensors="pt",
                truncation=True,
                max_length=train_cfg.get("max_seq_length", 16384),
            ).to(model.device)
            with torch.no_grad():
                outputs = model(**inputs, labels=inputs["input_ids"])
            total_loss += outputs.loss.item()
            count += 1
        val_loss = total_loss / max(count, 1)
        logger.info("Validation loss: %.4f (%d examples)", val_loss, count)
    else:
        logger.warning("Validation file not found: %s -- skipping val_loss.", val_path)

    # -- Generation-based metrics on validation set ----------------------------
    syntax_scores: list[float] = []
    import_scores: list[float] = []
    completeness_scores: list[float] = []
    structure_scores: list[float] = []

    if val_path.exists():
        val_ds = datasets_lib.load_dataset("json", data_files=str(val_path), split="train")
        logger.info("Running generation-based metrics on %d val examples...", len(val_ds))
        for i, example in enumerate(val_ds):
            prompt = example.get("prompt", "")
            logger.info("  [%d/%d] Generating for: %.80s...", i + 1, len(val_ds), prompt)
            output = _generate(model, tokenizer, prompt)
            files = parse_file_tags(output)
            if not files:
                logger.debug("  No FILE tags found in output, using raw output.")
                syntax_scores.append(0.0)
                import_scores.append(0.0)
                completeness_scores.append(0.0)
                structure_scores.append(0.0)
                continue

            syntax_scores.append(check_syntax(files))
            import_scores.append(check_imports(files))
            completeness_scores.append(check_completeness(files))

            struct = check_structure(files)
            if struct >= 0:
                structure_scores.append(struct)

    # -- Benchmark prompts -----------------------------------------------------
    benchmark_prompts = eval_cfg.get("benchmark_prompts", [])
    bench_syntax: list[float] = []
    bench_import: list[float] = []
    bench_completeness: list[float] = []
    bench_structure: list[float] = []

    if benchmark_prompts:
        logger.info("Running %d benchmark prompts...", len(benchmark_prompts))
        for i, prompt in enumerate(benchmark_prompts):
            logger.info("  [bench %d/%d] %s", i + 1, len(benchmark_prompts), prompt)
            output = _generate(model, tokenizer, prompt)
            files = parse_file_tags(output)
            if not files:
                logger.debug("  No FILE tags in benchmark output.")
                bench_syntax.append(0.0)
                bench_import.append(0.0)
                bench_completeness.append(0.0)
                bench_structure.append(0.0)
                continue

            bench_syntax.append(check_syntax(files))
            bench_import.append(check_imports(files))
            bench_completeness.append(check_completeness(files))

            struct = check_structure(files)
            if struct >= 0:
                bench_structure.append(struct)

    # -- Aggregate results -----------------------------------------------------
    def _avg(lst: list[float]) -> float | None:
        return sum(lst) / len(lst) if lst else None

    results: dict[str, Any] = {
        "val_loss": val_loss,
        "val_examples": len(syntax_scores),
        "syntax_valid_rate": _avg(syntax_scores),
        "import_valid_rate": _avg(import_scores),
        "file_completeness": _avg(completeness_scores),
        "structure_score": _avg(structure_scores) if structure_scores else None,
        "benchmark": {
            "num_prompts": len(benchmark_prompts),
            "syntax_valid_rate": _avg(bench_syntax),
            "import_valid_rate": _avg(bench_import),
            "file_completeness": _avg(bench_completeness),
            "structure_score": _avg(bench_structure) if bench_structure else None,
        },
    }

    # -- Print report ----------------------------------------------------------
    logger.info("=" * 60)
    logger.info("EVALUATION RESULTS")
    logger.info("=" * 60)
    for key, value in results.items():
        if isinstance(value, dict):
            logger.info("  %s:", key)
            for k, v in value.items():
                logger.info("    %s: %s", k, _format_metric(v))
        else:
            logger.info("  %s: %s", key, _format_metric(value))
    logger.info("=" * 60)

    # Save results to JSON alongside the model
    results_path = model_path / "eval_results.json"
    with open(results_path, "w", encoding="utf-8") as fh:
        json.dump(results, fh, indent=2)
    logger.info("Results saved to %s", results_path)

    return results


def _format_metric(value: Any) -> str:
    """Format a metric value for display."""
    if value is None:
        return "N/A"
    if isinstance(value, float):
        return f"{value:.4f}"
    return str(value)


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------

def main() -> None:
    """Parse arguments and run evaluation."""
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )

    parser = argparse.ArgumentParser(
        description="Evaluate fine-tuned KORE model on validation and benchmarks.",
    )
    parser.add_argument(
        "--model",
        type=str,
        default=None,
        help="Path to LoRA adapter or merged model directory.",
    )
    parser.add_argument(
        "--val",
        type=str,
        default=None,
        help="Path to validation JSONL file.",
    )
    parser.add_argument(
        "--config",
        type=str,
        default=str(DEFAULT_CONFIG),
        help="Path to config YAML (default: tools/training/config.yaml).",
    )
    args = parser.parse_args()
    evaluate(
        model_path=args.model,
        val_path=args.val,
        config_path=args.config,
    )


if __name__ == "__main__":
    main()
