"""Quantize a merged HuggingFace model to GGUF format for Ollama distribution.

Uses llama.cpp tools (convert_hf_to_gguf.py + llama-quantize) to produce a
quantized GGUF file suitable for local inference via Ollama.

Usage:
    python -m tools.training.quantize
    python -m tools.training.quantize --model models/kore-coder-7b-merged \
        --output models/kore-coder-7b-gguf --quant Q4_K_M
"""

from __future__ import annotations

import argparse
import logging
import os
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any

import yaml

logger = logging.getLogger(__name__)

PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
DEFAULT_CONFIG = PROJECT_ROOT / "tools" / "training" / "config.yaml"

# Common locations where llama.cpp might be installed
LLAMA_CPP_SEARCH_PATHS = [
    Path.home() / "llama.cpp",
    Path("/opt/llama.cpp"),
    Path("/usr/local/lib/llama.cpp"),
    PROJECT_ROOT / "vendor" / "llama.cpp",
]


# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

def load_config(path: str | Path) -> dict[str, Any]:
    """Load config from YAML."""
    path = Path(path)
    if not path.is_absolute():
        path = PROJECT_ROOT / path
    if not path.exists():
        raise FileNotFoundError(f"Config file not found: {path}")
    with open(path, "r", encoding="utf-8") as fh:
        return yaml.safe_load(fh)


def _resolve_path(raw: str) -> Path:
    """Resolve a path relative to PROJECT_ROOT if not absolute."""
    p = Path(raw)
    if not p.is_absolute():
        p = PROJECT_ROOT / p
    return p


# ---------------------------------------------------------------------------
# llama.cpp discovery
# ---------------------------------------------------------------------------

def _find_llama_cpp() -> Path | None:
    """Locate the llama.cpp directory.

    Checks the ``LLAMA_CPP_PATH`` environment variable first, then falls back
    to a list of common installation paths.

    Returns
    -------
    Path or None
        Path to the llama.cpp root directory, or None if not found.
    """
    env_path = os.environ.get("LLAMA_CPP_PATH")
    if env_path:
        p = Path(env_path)
        if p.exists():
            return p

    for candidate in LLAMA_CPP_SEARCH_PATHS:
        if candidate.exists():
            return candidate

    return None


def _find_convert_script(llama_cpp_dir: Path) -> Path | None:
    """Find the convert_hf_to_gguf.py script inside the llama.cpp tree."""
    candidates = [
        llama_cpp_dir / "convert_hf_to_gguf.py",
        llama_cpp_dir / "scripts" / "convert_hf_to_gguf.py",
    ]
    for c in candidates:
        if c.exists():
            return c
    return None


def _find_quantize_binary(llama_cpp_dir: Path) -> Path | None:
    """Find the llama-quantize (or quantize) binary."""
    candidates = [
        llama_cpp_dir / "build" / "bin" / "llama-quantize",
        llama_cpp_dir / "build" / "bin" / "quantize",
        llama_cpp_dir / "llama-quantize",
        llama_cpp_dir / "quantize",
    ]
    # Also check PATH
    which_result = shutil.which("llama-quantize")
    if which_result:
        candidates.insert(0, Path(which_result))

    for c in candidates:
        if c.exists() and os.access(c, os.X_OK):
            return c
    return None


def _print_install_instructions() -> None:
    """Print instructions for compiling llama.cpp."""
    instructions = """
    llama.cpp tools not found. To install:

    1. Clone the repository:
       git clone https://github.com/ggerganov/llama.cpp.git ~/llama.cpp

    2. Build:
       cd ~/llama.cpp
       cmake -B build
       cmake --build build --config Release

    3. Install Python dependencies for the conversion script:
       pip install -r ~/llama.cpp/requirements.txt

    4. (Optional) Set the environment variable:
       export LLAMA_CPP_PATH=~/llama.cpp

    After installation, re-run this script.
    """
    print(instructions)


# ---------------------------------------------------------------------------
# Quantize
# ---------------------------------------------------------------------------

def quantize_gguf(
    model_path: str | Path | None = None,
    output_path: str | Path | None = None,
    quant_type: str | None = None,
    config_path: str | Path = DEFAULT_CONFIG,
) -> Path:
    """Quantize a merged HuggingFace model to GGUF format.

    Steps
    -----
    1. Load config for default paths and quantization type.
    2. Locate llama.cpp tools (convert script + quantize binary).
    3. Convert HF model to f16 GGUF with ``convert_hf_to_gguf.py``.
    4. Quantize the f16 GGUF to the target type (default: Q4_K_M).
    5. Report output file size.

    Parameters
    ----------
    model_path:
        Path to the merged HuggingFace model directory.
        Defaults to ``config.model.merged_dir``.
    output_path:
        Directory for the output GGUF files.
        Defaults to ``config.model.gguf_dir``.
    quant_type:
        GGUF quantization type (e.g. Q4_K_M, Q5_K_M, Q8_0).
        Defaults to ``config.gguf.quant_type``.
    config_path:
        Path to the YAML config file.

    Returns
    -------
    Path
        Absolute path to the final quantized GGUF file.

    Raises
    ------
    FileNotFoundError
        If the model directory, llama.cpp tools, or conversion script
        cannot be found.
    subprocess.CalledProcessError
        If the conversion or quantization command fails.
    """

    # -- Config ----------------------------------------------------------------
    cfg = load_config(config_path)
    model_cfg = cfg["model"]
    gguf_cfg = cfg.get("gguf", {})
    dist_cfg = cfg.get("distribution", {})

    if model_path is None:
        model_path = _resolve_path(model_cfg["merged_dir"])
    else:
        model_path = Path(model_path)
    if output_path is None:
        output_path = _resolve_path(model_cfg["gguf_dir"])
    else:
        output_path = Path(output_path)
    if quant_type is None:
        quant_type = gguf_cfg.get("quant_type", "Q4_K_M")

    # -- Validate model path ---------------------------------------------------
    if not model_path.exists():
        raise FileNotFoundError(
            f"Merged model directory not found: {model_path}\n"
            f"  Run merge first:  python -m tools.training.merge"
        )

    # -- Locate llama.cpp tools ------------------------------------------------
    llama_cpp_dir = _find_llama_cpp()
    if llama_cpp_dir is None:
        logger.error("llama.cpp installation not found.")
        _print_install_instructions()
        sys.exit(1)

    logger.info("Found llama.cpp at: %s", llama_cpp_dir)

    convert_script = _find_convert_script(llama_cpp_dir)
    if convert_script is None:
        logger.error("convert_hf_to_gguf.py not found in %s", llama_cpp_dir)
        _print_install_instructions()
        sys.exit(1)

    quantize_binary = _find_quantize_binary(llama_cpp_dir)
    if quantize_binary is None:
        logger.error("llama-quantize binary not found in %s", llama_cpp_dir)
        _print_install_instructions()
        sys.exit(1)

    logger.info("Convert script: %s", convert_script)
    logger.info("Quantize binary: %s", quantize_binary)

    # -- Prepare output directory ----------------------------------------------
    output_path.mkdir(parents=True, exist_ok=True)

    # Derive filenames
    model_name = dist_cfg.get("gguf_filename", "model.Q4_K_M.gguf")
    base_stem = model_name.rsplit(".", 2)[0] if "." in model_name else "model"
    f16_gguf = output_path / f"{base_stem}.f16.gguf"
    quant_gguf = output_path / f"{base_stem}.{quant_type}.gguf"

    # -- Step 1: Convert HF -> f16 GGUF ----------------------------------------
    logger.info("Converting HuggingFace model to f16 GGUF...")
    logger.info("  Input:  %s", model_path)
    logger.info("  Output: %s", f16_gguf)

    convert_cmd = [
        sys.executable,
        str(convert_script),
        str(model_path),
        "--outtype", "f16",
        "--outfile", str(f16_gguf),
    ]
    logger.info("  Command: %s", " ".join(convert_cmd))

    result = subprocess.run(
        convert_cmd,
        capture_output=True,
        text=True,
        check=False,
    )
    if result.returncode != 0:
        logger.error("Conversion failed (exit code %d):", result.returncode)
        logger.error("  stdout: %s", result.stdout)
        logger.error("  stderr: %s", result.stderr)
        raise subprocess.CalledProcessError(
            result.returncode, convert_cmd, result.stdout, result.stderr,
        )

    f16_size = f16_gguf.stat().st_size / (1024 ** 3)
    logger.info("  f16 GGUF created: %.2f GB", f16_size)

    # -- Step 2: Quantize f16 -> target type -----------------------------------
    logger.info("Quantizing to %s...", quant_type)
    logger.info("  Input:  %s", f16_gguf)
    logger.info("  Output: %s", quant_gguf)

    quantize_cmd = [
        str(quantize_binary),
        str(f16_gguf),
        str(quant_gguf),
        quant_type,
    ]
    logger.info("  Command: %s", " ".join(quantize_cmd))

    result = subprocess.run(
        quantize_cmd,
        capture_output=True,
        text=True,
        check=False,
    )
    if result.returncode != 0:
        logger.error("Quantization failed (exit code %d):", result.returncode)
        logger.error("  stdout: %s", result.stdout)
        logger.error("  stderr: %s", result.stderr)
        raise subprocess.CalledProcessError(
            result.returncode, quantize_cmd, result.stdout, result.stderr,
        )

    quant_size = quant_gguf.stat().st_size / (1024 ** 3)
    logger.info("  Quantized GGUF created: %.2f GB", quant_size)

    # -- Cleanup: optionally remove the f16 intermediate -----------------------
    logger.info(
        "Intermediate f16 file kept at %s (%.2f GB). "
        "Delete manually if not needed.",
        f16_gguf,
        f16_size,
    )

    # -- Report ----------------------------------------------------------------
    logger.info("=" * 60)
    logger.info("GGUF QUANTIZATION COMPLETE")
    logger.info("=" * 60)
    logger.info("  Model:     %s", model_path)
    logger.info("  Quant:     %s", quant_type)
    logger.info("  Output:    %s", quant_gguf)
    logger.info("  Size:      %.2f GB", quant_size)
    logger.info("=" * 60)

    return quant_gguf.resolve()


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------

def main() -> None:
    """Parse arguments and run GGUF quantization."""
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )

    parser = argparse.ArgumentParser(
        description="Quantize merged model to GGUF format for Ollama.",
    )
    parser.add_argument(
        "--model",
        type=str,
        default=None,
        help="Path to the merged HuggingFace model directory.",
    )
    parser.add_argument(
        "--output",
        type=str,
        default=None,
        help="Output directory for GGUF files.",
    )
    parser.add_argument(
        "--quant",
        type=str,
        default=None,
        help="Quantization type (e.g. Q4_K_M, Q5_K_M, Q8_0). Default from config.",
    )
    parser.add_argument(
        "--config",
        type=str,
        default=str(DEFAULT_CONFIG),
        help="Path to config YAML (default: tools/training/config.yaml).",
    )
    args = parser.parse_args()
    quantize_gguf(
        model_path=args.model,
        output_path=args.output,
        quant_type=args.quant,
        config_path=args.config,
    )


if __name__ == "__main__":
    main()
