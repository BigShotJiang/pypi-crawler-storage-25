"""Fine-tune Qwen 7B with LoRA/QLoRA for KORE code generation.

All hyperparameters are loaded from config.yaml -- nothing is hardcoded.

Usage:
    python -m tools.training.train
    python -m tools.training.train --config tools/training/config.yaml
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import sys
from pathlib import Path
from typing import Any

import yaml

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Project root: two levels up from this file (tools/training/train.py)
# ---------------------------------------------------------------------------
PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
DEFAULT_CONFIG = PROJECT_ROOT / "tools" / "training" / "config.yaml"


# ---------------------------------------------------------------------------
# Lazy imports — heavy deps loaded only when needed
# ---------------------------------------------------------------------------

def _lazy_import(name: str):
    """Import *name* and return the module, or exit with a helpful message."""
    try:
        import importlib
        return importlib.import_module(name)
    except ImportError:
        print(
            f"[ERROR] Required package '{name}' is not installed.\n"
            f"  Install it with:  pip install {name}\n"
            f"  Or install the full training extras:  pip install -e '.[train]'"
        )
        sys.exit(1)


# ---------------------------------------------------------------------------
# Config helpers
# ---------------------------------------------------------------------------

def load_config(path: str | Path) -> dict[str, Any]:
    """Load training config from YAML.

    Parameters
    ----------
    path:
        Absolute or project-relative path to the YAML config file.

    Returns
    -------
    dict
        Parsed configuration dictionary.
    """
    path = Path(path)
    if not path.is_absolute():
        path = PROJECT_ROOT / path
    if not path.exists():
        raise FileNotFoundError(f"Config file not found: {path}")
    with open(path, "r", encoding="utf-8") as fh:
        cfg = yaml.safe_load(fh)
    logger.info("Loaded config from %s", path)
    return cfg


def _resolve_path(raw: str) -> Path:
    """Resolve a path relative to PROJECT_ROOT if not absolute."""
    p = Path(raw)
    if not p.is_absolute():
        p = PROJECT_ROOT / p
    return p


# ---------------------------------------------------------------------------
# Dataset formatting
# ---------------------------------------------------------------------------

def format_example(example: dict[str, str]) -> dict[str, str]:
    """Format a dataset example into the chat template expected by SFTTrainer.

    Each JSONL record has ``prompt`` and ``completion`` fields.  We return
    a single ``text`` field with the standard chat-ML structure:

        <|im_start|>user
        {prompt}<|im_end|>
        <|im_start|>assistant
        {completion}<|im_end|>

    Parameters
    ----------
    example:
        Dictionary with ``prompt`` and ``completion`` keys.

    Returns
    -------
    dict
        Dictionary with a single ``text`` key ready for tokenization.
    """
    prompt = example.get("prompt", "")
    completion = example.get("completion", "")
    text = (
        f"<|im_start|>user\n{prompt}<|im_end|>\n"
        f"<|im_start|>assistant\n{completion}<|im_end|>"
    )
    return {"text": text}


# ---------------------------------------------------------------------------
# Main training routine
# ---------------------------------------------------------------------------

def train(config_path: str | Path = DEFAULT_CONFIG) -> None:
    """Run LoRA/QLoRA fine-tuning.

    Steps
    -----
    1. Load config from YAML.
    2. Load dataset from ``data/dataset/train.jsonl`` (+ optional val split).
    3. Load base model with 4-bit quantization (``BitsAndBytesConfig``).
    4. Apply LoRA config (``peft``).
    5. Configure ``SFTTrainer`` from ``trl``.
    6. Train (with checkpoint resume if checkpoint dir exists).
    7. Save adapter weights to ``models/kore-coder-7b-lora/``.
    8. Log final metrics.

    If the ``WANDB_API_KEY`` environment variable is set, metrics are logged to
    Weights & Biases.  Otherwise TensorBoard is used (logs written to the
    output directory).
    """

    # -- 0. Load config -------------------------------------------------------
    cfg = load_config(config_path)
    model_cfg = cfg["model"]
    lora_cfg = cfg["lora"]
    train_cfg = cfg["training"]
    quant_cfg = cfg["quantization"]
    dataset_cfg = cfg["dataset"]

    output_dir = _resolve_path(model_cfg["output_dir"])
    output_dir.mkdir(parents=True, exist_ok=True)

    train_path = _resolve_path(dataset_cfg["train_path"])
    val_path = _resolve_path(dataset_cfg["val_path"]) if dataset_cfg.get("val_path") else None

    # -- 1. Lazy imports -------------------------------------------------------
    torch = _lazy_import("torch")
    transformers = _lazy_import("transformers")
    peft = _lazy_import("peft")
    trl = _lazy_import("trl")
    datasets_lib = _lazy_import("datasets")
    _lazy_import("bitsandbytes")
    _lazy_import("accelerate")

    AutoModelForCausalLM = transformers.AutoModelForCausalLM
    AutoTokenizer = transformers.AutoTokenizer
    BitsAndBytesConfig = transformers.BitsAndBytesConfig
    TrainingArguments = transformers.TrainingArguments
    LoraConfig = peft.LoraConfig
    get_peft_model = peft.get_peft_model
    prepare_model_for_kbit_training = peft.prepare_model_for_kbit_training
    SFTTrainer = trl.SFTTrainer

    # -- 2. Reporting ----------------------------------------------------------
    use_wandb = bool(os.environ.get("WANDB_API_KEY"))
    report_to = "wandb" if use_wandb else "tensorboard"
    if use_wandb:
        logger.info("WANDB_API_KEY detected -- logging to Weights & Biases.")
    else:
        logger.info("No WANDB_API_KEY -- logging to TensorBoard at %s", output_dir)

    # -- 3. Load dataset -------------------------------------------------------
    logger.info("Loading training data from %s", train_path)
    train_ds = datasets_lib.load_dataset("json", data_files=str(train_path), split="train")
    train_ds = train_ds.map(format_example, remove_columns=train_ds.column_names)

    val_ds = None
    if val_path and val_path.exists():
        logger.info("Loading validation data from %s", val_path)
        val_ds = datasets_lib.load_dataset("json", data_files=str(val_path), split="train")
        val_ds = val_ds.map(format_example, remove_columns=val_ds.column_names)

    logger.info("Train examples: %d", len(train_ds))
    if val_ds is not None:
        logger.info("Validation examples: %d", len(val_ds))

    # -- 4. Quantization config (QLoRA) ----------------------------------------
    compute_dtype = getattr(torch, quant_cfg.get("bnb_4bit_compute_dtype", "bfloat16"))
    bnb_config = BitsAndBytesConfig(
        load_in_4bit=quant_cfg.get("load_in_4bit", True),
        bnb_4bit_compute_dtype=compute_dtype,
        bnb_4bit_quant_type=quant_cfg.get("bnb_4bit_quant_type", "nf4"),
        bnb_4bit_use_double_quant=quant_cfg.get("bnb_4bit_use_double_quant", True),
    )

    # -- 5. Load base model ----------------------------------------------------
    base_model_name = model_cfg["base"]
    logger.info("Loading base model: %s (4-bit quantized)", base_model_name)

    model = AutoModelForCausalLM.from_pretrained(
        base_model_name,
        quantization_config=bnb_config,
        device_map="auto",
        trust_remote_code=True,
        torch_dtype=compute_dtype,
    )
    model = prepare_model_for_kbit_training(
        model, use_gradient_checkpointing=train_cfg.get("gradient_checkpointing", True),
    )

    tokenizer = AutoTokenizer.from_pretrained(
        base_model_name,
        trust_remote_code=True,
        padding_side="right",
    )
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    # -- 6. LoRA config --------------------------------------------------------
    lora_config = LoraConfig(
        r=lora_cfg["r"],
        lora_alpha=lora_cfg["lora_alpha"],
        lora_dropout=lora_cfg.get("lora_dropout", 0.05),
        target_modules=lora_cfg["target_modules"],
        task_type=lora_cfg.get("task_type", "CAUSAL_LM"),
        bias="none",
    )
    model = get_peft_model(model, lora_config)
    model.print_trainable_parameters()

    # -- 7. Training arguments -------------------------------------------------
    training_args = TrainingArguments(
        output_dir=str(output_dir),
        num_train_epochs=train_cfg["num_epochs"],
        per_device_train_batch_size=train_cfg["per_device_train_batch_size"],
        gradient_accumulation_steps=train_cfg["gradient_accumulation_steps"],
        learning_rate=train_cfg["learning_rate"],
        lr_scheduler_type=train_cfg["lr_scheduler_type"],
        warmup_ratio=train_cfg.get("warmup_ratio", 0.05),
        bf16=train_cfg.get("bf16", True),
        gradient_checkpointing=train_cfg.get("gradient_checkpointing", True),
        logging_steps=train_cfg.get("logging_steps", 10),
        save_strategy=train_cfg.get("save_strategy", "epoch"),
        eval_strategy=train_cfg.get("eval_strategy", "epoch") if val_ds else "no",
        report_to=report_to,
        remove_unused_columns=False,
        optim="paged_adamw_8bit",
        max_grad_norm=1.0,
        seed=42,
        load_best_model_at_end=bool(val_ds),
        metric_for_best_model="eval_loss" if val_ds else None,
        greater_is_better=False if val_ds else None,
    )

    # -- 8. SFTTrainer ---------------------------------------------------------
    trainer = SFTTrainer(
        model=model,
        tokenizer=tokenizer,
        args=training_args,
        train_dataset=train_ds,
        eval_dataset=val_ds,
        max_seq_length=train_cfg.get("max_seq_length", 16384),
        dataset_text_field="text",
        packing=False,
    )

    # -- 9. Resume from checkpoint if available --------------------------------
    last_checkpoint = None
    if output_dir.exists():
        checkpoints = sorted(output_dir.glob("checkpoint-*"))
        if checkpoints:
            last_checkpoint = str(checkpoints[-1])
            logger.info("Resuming from checkpoint: %s", last_checkpoint)

    # -- 10. Train! ------------------------------------------------------------
    logger.info("Starting training...")
    train_result = trainer.train(resume_from_checkpoint=last_checkpoint)

    # -- 11. Save adapter weights ----------------------------------------------
    logger.info("Saving adapter weights to %s", output_dir)
    trainer.save_model(str(output_dir))
    tokenizer.save_pretrained(str(output_dir))

    # -- 12. Log final metrics -------------------------------------------------
    metrics = train_result.metrics
    trainer.log_metrics("train", metrics)
    trainer.save_metrics("train", metrics)
    trainer.save_state()

    if val_ds is not None:
        eval_metrics = trainer.evaluate()
        trainer.log_metrics("eval", eval_metrics)
        trainer.save_metrics("eval", eval_metrics)

    logger.info("Training complete. Adapter saved to %s", output_dir)
    logger.info("Final training metrics: %s", json.dumps(metrics, indent=2))


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------

def main() -> None:
    """Parse arguments and launch training."""
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )

    parser = argparse.ArgumentParser(
        description="Fine-tune Qwen 7B with LoRA/QLoRA for KORE code generation.",
    )
    parser.add_argument(
        "--config",
        type=str,
        default=str(DEFAULT_CONFIG),
        help="Path to training config YAML (default: tools/training/config.yaml).",
    )
    args = parser.parse_args()
    train(config_path=args.config)


if __name__ == "__main__":
    main()
