"""Merge LoRA adapter weights with the base model into a standalone model.

The merged model can be used directly with HuggingFace transformers (no
adapter loading required) and serves as input for GGUF quantization.

Usage:
    python -m tools.training.merge
    python -m tools.training.merge --base Qwen/Qwen2.5-Coder-7B-Instruct \
        --lora models/kore-coder-7b-lora --output models/kore-coder-7b-merged
"""

from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path
from typing import Any

import yaml

logger = logging.getLogger(__name__)

PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
DEFAULT_CONFIG = PROJECT_ROOT / "tools" / "training" / "config.yaml"


# ---------------------------------------------------------------------------
# Lazy imports
# ---------------------------------------------------------------------------

def _lazy_import(name: str):
    """Import *name* and return the module, or exit with a helpful message."""
    try:
        import importlib
        return importlib.import_module(name)
    except ImportError:
        print(
            f"[ERROR] Required package '{name}' is not installed.\n"
            f"  Install it with:  pip install {name}\n"
            f"  Or install the full training extras:  pip install -e '.[train]'"
        )
        sys.exit(1)


# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

def load_config(path: str | Path) -> dict[str, Any]:
    """Load config from YAML."""
    path = Path(path)
    if not path.is_absolute():
        path = PROJECT_ROOT / path
    if not path.exists():
        raise FileNotFoundError(f"Config file not found: {path}")
    with open(path, "r", encoding="utf-8") as fh:
        return yaml.safe_load(fh)


def _resolve_path(raw: str) -> Path:
    """Resolve a path relative to PROJECT_ROOT if not absolute."""
    p = Path(raw)
    if not p.is_absolute():
        p = PROJECT_ROOT / p
    return p


# ---------------------------------------------------------------------------
# Merge
# ---------------------------------------------------------------------------

def merge_lora(
    base_model: str | None = None,
    lora_path: str | Path | None = None,
    output_path: str | Path | None = None,
    config_path: str | Path = DEFAULT_CONFIG,
) -> Path:
    """Merge LoRA adapter weights with the base model.

    Parameters
    ----------
    base_model:
        HuggingFace model ID or local path for the base model.
        Defaults to ``config.model.base``.
    lora_path:
        Path to the LoRA adapter directory.
        Defaults to ``config.model.output_dir``.
    output_path:
        Directory where the merged model will be saved.
        Defaults to ``config.model.merged_dir``.
    config_path:
        Path to the YAML config file.

    Returns
    -------
    Path
        Absolute path to the saved merged model directory.
    """

    # -- Config ----------------------------------------------------------------
    cfg = load_config(config_path)
    model_cfg = cfg["model"]

    if base_model is None:
        base_model = model_cfg["base"]
    if lora_path is None:
        lora_path = _resolve_path(model_cfg["output_dir"])
    else:
        lora_path = Path(lora_path)
    if output_path is None:
        output_path = _resolve_path(model_cfg["merged_dir"])
    else:
        output_path = Path(output_path)

    # -- Lazy imports ----------------------------------------------------------
    torch = _lazy_import("torch")
    transformers = _lazy_import("transformers")
    peft = _lazy_import("peft")

    AutoModelForCausalLM = transformers.AutoModelForCausalLM
    AutoTokenizer = transformers.AutoTokenizer
    PeftModel = peft.PeftModel

    # -- Validate paths --------------------------------------------------------
    if not Path(lora_path).exists():
        raise FileNotFoundError(
            f"LoRA adapter directory not found: {lora_path}\n"
            f"  Run training first:  python -m tools.training.train"
        )

    # -- 1. Load base model (full precision for merging) -----------------------
    logger.info("Loading base model: %s (full precision for merge)", base_model)
    model = AutoModelForCausalLM.from_pretrained(
        base_model,
        torch_dtype=torch.float16,
        device_map="auto",
        trust_remote_code=True,
    )

    # -- 2. Load tokenizer -----------------------------------------------------
    logger.info("Loading tokenizer from %s", base_model)
    tokenizer = AutoTokenizer.from_pretrained(
        base_model,
        trust_remote_code=True,
    )

    # -- 3. Load LoRA adapter --------------------------------------------------
    logger.info("Loading LoRA adapter from %s", lora_path)
    model = PeftModel.from_pretrained(model, str(lora_path))

    # -- 4. Merge and unload ---------------------------------------------------
    logger.info("Merging LoRA weights into base model...")
    model = model.merge_and_unload()

    # -- 5. Save merged model --------------------------------------------------
    output_path.mkdir(parents=True, exist_ok=True)
    logger.info("Saving merged model to %s", output_path)
    model.save_pretrained(str(output_path), safe_serialization=True)
    tokenizer.save_pretrained(str(output_path))

    # Report size
    total_bytes = sum(f.stat().st_size for f in output_path.rglob("*") if f.is_file())
    total_gb = total_bytes / (1024 ** 3)
    logger.info(
        "Merge complete. Saved to %s (%.2f GB, %d files)",
        output_path,
        total_gb,
        sum(1 for _ in output_path.rglob("*") if _.is_file()),
    )

    return output_path.resolve()


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------

def main() -> None:
    """Parse arguments and merge LoRA with base model."""
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )

    parser = argparse.ArgumentParser(
        description="Merge LoRA adapter weights with base model into standalone model.",
    )
    parser.add_argument(
        "--base",
        type=str,
        default=None,
        help="HuggingFace model ID or local path for the base model.",
    )
    parser.add_argument(
        "--lora",
        type=str,
        default=None,
        help="Path to the LoRA adapter directory.",
    )
    parser.add_argument(
        "--output",
        type=str,
        default=None,
        help="Directory where the merged model will be saved.",
    )
    parser.add_argument(
        "--config",
        type=str,
        default=str(DEFAULT_CONFIG),
        help="Path to config YAML (default: tools/training/config.yaml).",
    )
    args = parser.parse_args()
    merge_lora(
        base_model=args.base,
        lora_path=args.lora,
        output_path=args.output,
        config_path=args.config,
    )


if __name__ == "__main__":
    main()
