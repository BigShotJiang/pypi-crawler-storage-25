"""
KORE Dataset Curation Pipeline
===============================

Orchestrates the full dataset curation pipeline:
    scraper -> filter -> analyzer -> extractor

Each stage reads from the previous stage's output directory and writes
to its own output directory under data/:
    scrape   : GitHub API  -> data/raw/*.json
    filter   : data/raw/   -> data/filtered/*.json
    analyze  : data/filtered/ -> data/analyzed/*.json
    extract  : data/analyzed/ -> data/dataset/{train,val}.jsonl

Usage:
    python tools/dataset/pipeline.py                # Run all stages
    python tools/dataset/pipeline.py --stage scrape
    python tools/dataset/pipeline.py --stage filter
    python tools/dataset/pipeline.py --stage analyze
    python tools/dataset/pipeline.py --stage extract
    python tools/dataset/pipeline.py --stats         # Print statistics only
"""

from __future__ import annotations

import argparse
import asyncio
import importlib
import json
import logging
import sys
import time
import traceback
from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

import yaml

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger("kore.pipeline")

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

CONFIG_PATH = Path(__file__).parent / "config.yaml"
PROJECT_ROOT = Path(__file__).resolve().parents[2]  # kore-platform/

DATA_RAW = PROJECT_ROOT / "data" / "raw"
DATA_FILTERED = PROJECT_ROOT / "data" / "filtered"
DATA_ANALYZED = PROJECT_ROOT / "data" / "analyzed"
DATA_DATASET = PROJECT_ROOT / "data" / "dataset"

STAGES = ("scrape", "filter", "analyze", "extract")


# ---------------------------------------------------------------------------
# Helpers: safe module loading
# ---------------------------------------------------------------------------

def _import_module(dotted_path: str):
    """Import a module by its dotted path, returning None on failure."""
    try:
        return importlib.import_module(dotted_path)
    except ImportError as exc:
        logger.error("Cannot import %s: %s", dotted_path, exc)
        return None


def _load_config(config_path: Path) -> Dict[str, Any]:
    """Load and return the YAML configuration file."""
    if not config_path.exists():
        logger.warning("Config file not found at %s -- using empty config.", config_path)
        return {}
    with open(config_path, "r", encoding="utf-8") as fh:
        return yaml.safe_load(fh) or {}


def _json_files(directory: Path) -> List[Path]:
    """Return sorted list of .json files in *directory*."""
    if not directory.is_dir():
        return []
    return sorted(directory.glob("*.json"))


# ---------------------------------------------------------------------------
# Stage result tracking
# ---------------------------------------------------------------------------

@dataclass
class StageResult:
    """Accumulates per-stage statistics."""
    stage: str
    succeeded: int = 0
    failed: int = 0
    skipped: int = 0
    errors: List[str] = field(default_factory=list)
    extra: Dict[str, Any] = field(default_factory=dict)

    @property
    def total(self) -> int:
        return self.succeeded + self.failed + self.skipped

    def summary_line(self) -> str:
        return (
            f"[{self.stage}] {self.succeeded} succeeded, "
            f"{self.failed} failed, {self.skipped} skipped "
            f"(total: {self.total})"
        )


# ---------------------------------------------------------------------------
# DatasetPipeline
# ---------------------------------------------------------------------------

class DatasetPipeline:
    """Orchestrates scraper -> filter -> analyzer -> extractor."""

    def __init__(self, config_path: Path = CONFIG_PATH) -> None:
        self.config_path = config_path
        self.config = _load_config(config_path)
        self.results: Dict[str, StageResult] = {}

        # Ensure data directories exist
        for d in (DATA_RAW, DATA_FILTERED, DATA_ANALYZED, DATA_DATASET):
            d.mkdir(parents=True, exist_ok=True)

    # ------------------------------------------------------------------
    # Stage 1: scrape
    # ------------------------------------------------------------------

    def run_scraper(self) -> StageResult:
        """Run the GitHub scraper and write raw repo JSON files to data/raw/."""
        result = StageResult(stage="scrape")
        logger.info("=== Stage 1/4: SCRAPE ===")

        mod = _import_module("tools.dataset.scraper")
        if mod is None:
            result.errors.append("Module tools.dataset.scraper not importable.")
            result.failed = 1
            self.results["scrape"] = result
            return result

        try:
            scraper_cfg = self.config.get("scraper", {})
            # The scraper module exposes load_config() and GitHubScraper.
            # If load_config exists, use it to build the config; otherwise
            # pass our YAML section directly.
            if hasattr(mod, "load_config"):
                scraper_cfg = mod.load_config(self.config_path)

            scraper = mod.GitHubScraper(scraper_cfg)

            # GitHubScraper.run() may be sync or async -- handle both.
            if asyncio.iscoroutinefunction(getattr(scraper, "run", None)):
                repos = asyncio.run(scraper.run())
            else:
                repos = scraper.run()

            result.succeeded = repos if isinstance(repos, int) else len(_json_files(DATA_RAW))
            logger.info("Scraper finished: %d repos collected.", result.succeeded)

        except Exception as exc:
            logger.error("Scraper failed: %s", exc)
            logger.debug(traceback.format_exc())
            result.errors.append(str(exc))
            result.failed = 1

        self.results["scrape"] = result
        return result

    # ------------------------------------------------------------------
    # Stage 2: filter
    # ------------------------------------------------------------------

    def run_filter(self) -> StageResult:
        """Filter data/raw/*.json through quality gates into data/filtered/."""
        result = StageResult(stage="filter")
        logger.info("=== Stage 2/4: FILTER ===")

        mod = _import_module("tools.dataset.filter")
        if mod is None:
            result.errors.append("Module tools.dataset.filter not importable.")
            result.failed = 1
            self.results["filter"] = result
            return result

        filter_cfg = self.config.get("filter", {})
        if hasattr(mod, "load_config"):
            filter_cfg = mod.load_config(self.config_path)

        raw_files = _json_files(DATA_RAW)
        if not raw_files:
            logger.warning("No raw JSON files found in %s -- nothing to filter.", DATA_RAW)
            result.skipped = 1
            self.results["filter"] = result
            return result

        logger.info("Filtering %d raw repos ...", len(raw_files))

        for path in raw_files:
            repo_name = path.stem
            try:
                with open(path, "r", encoding="utf-8") as fh:
                    repo_data = json.load(fh)

                passed = mod.filter_repo(repo_data, filter_cfg)

                if passed:
                    out_path = DATA_FILTERED / path.name
                    # filter_repo may return the (possibly enriched) dict or True
                    payload = passed if isinstance(passed, dict) else repo_data
                    with open(out_path, "w", encoding="utf-8") as fh:
                        json.dump(payload, fh, indent=2, ensure_ascii=False)
                    result.succeeded += 1
                else:
                    result.skipped += 1

            except Exception as exc:
                logger.error("Filter failed on %s: %s", repo_name, exc)
                logger.debug(traceback.format_exc())
                result.errors.append(f"{repo_name}: {exc}")
                result.failed += 1

        logger.info(
            "Filter done: %d passed, %d rejected, %d errors.",
            result.succeeded, result.skipped, result.failed,
        )
        self.results["filter"] = result
        return result

    # ------------------------------------------------------------------
    # Stage 3: analyze
    # ------------------------------------------------------------------

    def run_analyzer(self) -> StageResult:
        """Analyze data/filtered/*.json with the ComplexityAgent, writing to data/analyzed/."""
        result = StageResult(stage="analyze")
        logger.info("=== Stage 3/4: ANALYZE ===")

        mod = _import_module("tools.dataset.analyzer")
        if mod is None:
            result.errors.append("Module tools.dataset.analyzer not importable.")
            result.failed = 1
            self.results["analyze"] = result
            return result

        analyzer_cfg = self.config.get("analyzer", {})
        if hasattr(mod, "load_config"):
            analyzer_cfg = mod.load_config(self.config_path)

        filtered_files = _json_files(DATA_FILTERED)
        if not filtered_files:
            logger.warning("No filtered JSON files found in %s -- nothing to analyze.", DATA_FILTERED)
            result.skipped = 1
            self.results["analyze"] = result
            return result

        logger.info("Analyzing %d filtered repos ...", len(filtered_files))

        rating_counter: Counter = Counter()

        async def _analyze_all():
            for path in filtered_files:
                repo_name = path.stem
                try:
                    with open(path, "r", encoding="utf-8") as fh:
                        repo_data = json.load(fh)

                    # analyze_repo may be sync or async
                    if asyncio.iscoroutinefunction(mod.analyze_repo):
                        analysis = await mod.analyze_repo(repo_data, analyzer_cfg)
                    else:
                        analysis = mod.analyze_repo(repo_data, analyzer_cfg)

                    # Determine if the repo passes quality threshold
                    if hasattr(mod, "passes_quality"):
                        passed = mod.passes_quality(analysis, analyzer_cfg)
                    else:
                        # Fallback: check rating against pass_ratings list
                        rating = analysis.get("rating", "F") if isinstance(analysis, dict) else "F"
                        pass_ratings = analyzer_cfg.get("pass_ratings", ["A", "B"])
                        conditional = analyzer_cfg.get("conditional_rating", "C")
                        conditional_min = analyzer_cfg.get("conditional_min_stars", 500)
                        passed = (
                            rating in pass_ratings
                            or (
                                rating == conditional
                                and repo_data.get("stars", 0) >= conditional_min
                            )
                        )

                    rating = (
                        analysis.get("rating", "?") if isinstance(analysis, dict) else "?"
                    )
                    rating_counter[rating] += 1

                    if passed:
                        enriched = repo_data.copy()
                        if isinstance(analysis, dict):
                            enriched["analysis"] = analysis
                        out_path = DATA_ANALYZED / path.name
                        with open(out_path, "w", encoding="utf-8") as fh:
                            json.dump(enriched, fh, indent=2, ensure_ascii=False)
                        result.succeeded += 1
                    else:
                        result.skipped += 1

                except Exception as exc:
                    logger.error("Analyzer failed on %s: %s", repo_name, exc)
                    logger.debug(traceback.format_exc())
                    result.errors.append(f"{repo_name}: {exc}")
                    result.failed += 1

        asyncio.run(_analyze_all())

        result.extra["ratings"] = dict(rating_counter)
        logger.info(
            "Analyzer done: %d passed, %d rejected, %d errors. Ratings: %s",
            result.succeeded, result.skipped, result.failed, dict(rating_counter),
        )
        self.results["analyze"] = result
        return result

    # ------------------------------------------------------------------
    # Stage 4: extract
    # ------------------------------------------------------------------

    def run_extractor(self) -> StageResult:
        """Extract data/analyzed/*.json into train/val JSONL pairs."""
        result = StageResult(stage="extract")
        logger.info("=== Stage 4/4: EXTRACT ===")

        mod = _import_module("tools.dataset.extractor")
        if mod is None:
            result.errors.append("Module tools.dataset.extractor not importable.")
            result.failed = 1
            self.results["extract"] = result
            return result

        extractor_cfg = self.config.get("extractor", {})
        if hasattr(mod, "load_config"):
            extractor_cfg = mod.load_config(self.config_path)

        analyzed_files = _json_files(DATA_ANALYZED)
        if not analyzed_files:
            logger.warning("No analyzed JSON files in %s -- nothing to extract.", DATA_ANALYZED)
            result.skipped = 1
            self.results["extract"] = result
            return result

        logger.info("Extracting training pairs from %d analyzed repos ...", len(analyzed_files))

        pairs: List[Dict[str, Any]] = []
        token_counts: List[int] = []

        for path in analyzed_files:
            repo_name = path.stem
            try:
                with open(path, "r", encoding="utf-8") as fh:
                    repo_data = json.load(fh)

                pair = mod.build_pair(repo_data, extractor_cfg)
                if pair is None:
                    result.skipped += 1
                    continue

                pairs.append(pair)

                # Track token count if present
                tokens = pair.get("total_tokens", pair.get("tokens", 0))
                if tokens:
                    token_counts.append(tokens)

                result.succeeded += 1

            except Exception as exc:
                logger.error("Extractor failed on %s: %s", repo_name, exc)
                logger.debug(traceback.format_exc())
                result.errors.append(f"{repo_name}: {exc}")
                result.failed += 1

        # Split into train / val and write JSONL files
        if pairs:
            try:
                train_set, val_set = mod.split_dataset(pairs, extractor_cfg)

                train_path = DATA_DATASET / "train.jsonl"
                val_path = DATA_DATASET / "val.jsonl"

                _write_jsonl(train_path, train_set)
                _write_jsonl(val_path, val_set)

                logger.info(
                    "Wrote %d train pairs to %s", len(train_set), train_path,
                )
                logger.info(
                    "Wrote %d val pairs to %s", len(val_set), val_path,
                )

                result.extra["train_count"] = len(train_set)
                result.extra["val_count"] = len(val_set)

            except Exception as exc:
                logger.error("Dataset split/write failed: %s", exc)
                logger.debug(traceback.format_exc())
                result.errors.append(f"split/write: {exc}")
                result.failed += 1

        if token_counts:
            result.extra["token_stats"] = {
                "total": sum(token_counts),
                "mean": sum(token_counts) / len(token_counts),
                "min": min(token_counts),
                "max": max(token_counts),
                "count": len(token_counts),
            }

        logger.info(
            "Extractor done: %d pairs built, %d skipped, %d errors.",
            result.succeeded, result.skipped, result.failed,
        )
        self.results["extract"] = result
        return result

    # ------------------------------------------------------------------
    # run_all
    # ------------------------------------------------------------------

    def run_all(self) -> Dict[str, StageResult]:
        """Execute every stage sequentially, collecting results."""
        t0 = time.monotonic()

        self.run_scraper()
        self.run_filter()
        self.run_analyzer()
        self.run_extractor()

        elapsed = time.monotonic() - t0
        logger.info("Pipeline completed in %.1f s", elapsed)
        self._print_summary()
        return self.results

    # ------------------------------------------------------------------
    # Statistics / summary
    # ------------------------------------------------------------------

    def print_stats(self) -> None:
        """Print statistics for all data directories without running anything."""
        raw_count = len(_json_files(DATA_RAW))
        filtered_count = len(_json_files(DATA_FILTERED))
        analyzed_count = len(_json_files(DATA_ANALYZED))

        train_path = DATA_DATASET / "train.jsonl"
        val_path = DATA_DATASET / "val.jsonl"
        train_count = _count_jsonl_lines(train_path)
        val_count = _count_jsonl_lines(val_path)

        print("\n" + "=" * 60)
        print("  KORE Dataset Pipeline -- Current Statistics")
        print("=" * 60)
        print(f"  Raw repos       (data/raw/)       : {raw_count}")
        print(f"  Filtered repos  (data/filtered/)   : {filtered_count}")
        print(f"  Analyzed repos  (data/analyzed/)   : {analyzed_count}")
        print(f"  Training pairs  (data/dataset/)    : {train_count} train, {val_count} val")

        if raw_count > 0:
            pass_ratio = filtered_count / raw_count * 100
            print(f"\n  Filter pass rate : {pass_ratio:.1f}% ({filtered_count}/{raw_count})")

        if filtered_count > 0:
            analyze_ratio = analyzed_count / filtered_count * 100
            print(f"  Analyze pass rate: {analyze_ratio:.1f}% ({analyzed_count}/{filtered_count})")

        # Rating distribution from analyzed files
        rating_dist = self._collect_rating_distribution()
        if rating_dist:
            print("\n  Rating distribution:")
            for rating, count in sorted(rating_dist.items()):
                print(f"    {rating}: {count}")

        # Token distribution from dataset files
        token_stats = self._collect_token_stats()
        if token_stats:
            print("\n  Token distribution (training pairs):")
            print(f"    Total tokens : {token_stats['total']:,}")
            print(f"    Mean / pair  : {token_stats['mean']:,.0f}")
            print(f"    Min          : {token_stats['min']:,}")
            print(f"    Max          : {token_stats['max']:,}")
            print(f"    Pairs        : {token_stats['count']:,}")

        print("=" * 60 + "\n")

    def _collect_rating_distribution(self) -> Dict[str, int]:
        """Read ratings from analyzed JSON files."""
        counter: Counter = Counter()
        for path in _json_files(DATA_ANALYZED):
            try:
                with open(path, "r", encoding="utf-8") as fh:
                    data = json.load(fh)
                rating = data.get("analysis", {}).get("rating", "?")
                counter[rating] += 1
            except Exception:
                pass
        return dict(counter)

    def _collect_token_stats(self) -> Optional[Dict[str, Any]]:
        """Read token counts from train.jsonl."""
        train_path = DATA_DATASET / "train.jsonl"
        if not train_path.exists():
            return None
        counts = []
        try:
            with open(train_path, "r", encoding="utf-8") as fh:
                for line in fh:
                    line = line.strip()
                    if not line:
                        continue
                    obj = json.loads(line)
                    tokens = obj.get("total_tokens", obj.get("tokens", 0))
                    if tokens:
                        counts.append(tokens)
        except Exception:
            return None
        if not counts:
            return None
        return {
            "total": sum(counts),
            "mean": sum(counts) / len(counts),
            "min": min(counts),
            "max": max(counts),
            "count": len(counts),
        }

    def _print_summary(self) -> None:
        """Print a summary table of all stage results."""
        print("\n" + "=" * 60)
        print("  KORE Dataset Pipeline -- Run Summary")
        print("=" * 60)
        for stage in STAGES:
            res = self.results.get(stage)
            if res is None:
                print(f"  {stage:<10s}: (not run)")
            else:
                print(f"  {res.summary_line()}")
                if res.extra.get("ratings"):
                    print(f"    Ratings: {res.extra['ratings']}")
                if res.extra.get("token_stats"):
                    ts = res.extra["token_stats"]
                    print(
                        f"    Tokens: {ts['total']:,} total, "
                        f"{ts['mean']:,.0f} mean, "
                        f"range [{ts['min']:,} .. {ts['max']:,}]"
                    )
                if res.extra.get("train_count") is not None:
                    print(
                        f"    Dataset split: "
                        f"{res.extra['train_count']} train / "
                        f"{res.extra['val_count']} val"
                    )
                if res.errors:
                    print(f"    First errors:")
                    for err in res.errors[:5]:
                        print(f"      - {err}")
                    if len(res.errors) > 5:
                        print(f"      ... and {len(res.errors) - 5} more")
        print("=" * 60 + "\n")


# ---------------------------------------------------------------------------
# Utility functions
# ---------------------------------------------------------------------------

def _write_jsonl(path: Path, records: List[Dict[str, Any]]) -> None:
    """Write a list of dicts as a JSONL file."""
    with open(path, "w", encoding="utf-8") as fh:
        for record in records:
            fh.write(json.dumps(record, ensure_ascii=False) + "\n")


def _count_jsonl_lines(path: Path) -> int:
    """Count non-empty lines in a JSONL file."""
    if not path.exists():
        return 0
    count = 0
    with open(path, "r", encoding="utf-8") as fh:
        for line in fh:
            if line.strip():
                count += 1
    return count


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="pipeline",
        description="KORE Dataset Curation Pipeline: scrape -> filter -> analyze -> extract",
    )
    parser.add_argument(
        "--stage",
        choices=STAGES,
        default=None,
        help="Run a single stage instead of the full pipeline.",
    )
    parser.add_argument(
        "--stats",
        action="store_true",
        help="Print current pipeline statistics and exit.",
    )
    parser.add_argument(
        "--config",
        type=Path,
        default=CONFIG_PATH,
        help="Path to config YAML (default: tools/dataset/config.yaml).",
    )
    return parser


def main(argv: Optional[List[str]] = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    pipeline = DatasetPipeline(config_path=args.config)

    if args.stats:
        pipeline.print_stats()
        return 0

    stage_methods = {
        "scrape": pipeline.run_scraper,
        "filter": pipeline.run_filter,
        "analyze": pipeline.run_analyzer,
        "extract": pipeline.run_extractor,
    }

    if args.stage:
        logger.info("Running single stage: %s", args.stage)
        result = stage_methods[args.stage]()
        pipeline._print_summary()
        return 1 if result.failed > 0 and result.succeeded == 0 else 0
    else:
        pipeline.run_all()
        # Return non-zero only if every stage had failures with no successes
        any_total_failure = any(
            r.failed > 0 and r.succeeded == 0
            for r in pipeline.results.values()
        )
        return 1 if any_total_failure else 0


if __name__ == "__main__":
    sys.exit(main())
