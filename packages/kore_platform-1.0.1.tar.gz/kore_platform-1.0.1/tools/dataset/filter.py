"""Quality filter for scraped Python repositories.

Reads repos from data/raw/*.json, applies configurable quality filters
using ast.parse for code analysis, and writes passing repos to data/filtered/.
All thresholds are loaded from tools/dataset/config.yaml.
"""

from __future__ import annotations

import ast
import json
import logging
import sys
from pathlib import Path
from typing import Any

import yaml

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Resolve project root (two levels up from this file: tools/dataset/filter.py)
# ---------------------------------------------------------------------------
_THIS_DIR = Path(__file__).resolve().parent
_PROJECT_ROOT = _THIS_DIR.parent.parent
_DEFAULT_CONFIG = _THIS_DIR / "config.yaml"
_RAW_DIR = _PROJECT_ROOT / "data" / "raw"
_FILTERED_DIR = _PROJECT_ROOT / "data" / "filtered"


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

def load_config(path: str | Path = _DEFAULT_CONFIG) -> dict[str, Any]:
    """Load the filter section from the pipeline config YAML.

    Parameters
    ----------
    path:
        Absolute or relative path to the YAML config file.

    Returns
    -------
    dict with filter-specific thresholds.
    """
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Config not found: {path}")
    with open(path, encoding="utf-8") as fh:
        full = yaml.safe_load(fh)
    if "filter" not in full:
        raise KeyError("Config YAML does not contain a 'filter' section")
    return full["filter"]


# ---------------------------------------------------------------------------
# AST-based analysis helpers
# ---------------------------------------------------------------------------

def has_type_hints(source: str) -> bool:
    """Return True if the source contains at least one type-annotated function.

    Uses ``ast.parse`` to inspect ``arg.annotation`` on parameters and the
    ``returns`` attribute on ``FunctionDef`` / ``AsyncFunctionDef`` nodes.
    """
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return False

    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            # Check return annotation
            if node.returns is not None:
                return True
            # Check argument annotations (excluding 'self' / 'cls' by convention)
            for arg in node.args.args + node.args.posonlyargs + node.args.kwonlyargs:
                if arg.annotation is not None:
                    return True
            if node.args.vararg and node.args.vararg.annotation is not None:
                return True
            if node.args.kwarg and node.args.kwarg.annotation is not None:
                return True
    return False


def has_docstrings(source: str) -> float:
    """Return the ratio of functions/classes that have a docstring.

    A docstring is detected when the first statement in the body is an
    ``ast.Expr`` whose value is an ``ast.Constant`` with a ``str`` value.

    Returns 0.0 when there are no functions or classes in the source (avoids
    division by zero) and 1.0 is possible if everything is documented.
    """
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return 0.0

    total = 0
    documented = 0

    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            total += 1
            if (
                node.body
                and isinstance(node.body[0], ast.Expr)
                and isinstance(node.body[0].value, ast.Constant)
                and isinstance(node.body[0].value.value, str)
            ):
                documented += 1

    if total == 0:
        return 0.0
    return documented / total


def count_stub_functions(source: str) -> tuple[int, int]:
    """Count stub functions (body is only ``pass``) versus total functions.

    Parameters
    ----------
    source:
        Python source code to analyse.

    Returns
    -------
    (stubs, total) where *stubs* is the number of functions whose entire body
    consists of a single ``Pass`` statement (optionally preceded by a docstring).
    """
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return (0, 0)

    stubs = 0
    total = 0

    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            total += 1
            body = node.body

            # A stub is: either just `pass`, or docstring + `pass`
            effective = body
            if (
                len(body) >= 1
                and isinstance(body[0], ast.Expr)
                and isinstance(body[0].value, ast.Constant)
                and isinstance(body[0].value.value, str)
            ):
                # Skip the docstring when checking for stub-ness
                effective = body[1:]

            if len(effective) == 1 and isinstance(effective[0], ast.Pass):
                stubs += 1

    return (stubs, total)


# ---------------------------------------------------------------------------
# File-level classification helpers
# ---------------------------------------------------------------------------

def _is_test_file(filename: str) -> bool:
    """Return True if the filename looks like a test file."""
    name = Path(filename).name
    return name.startswith("test_") or name.endswith("_test.py") or name == "conftest.py"


def _is_init_file(filename: str) -> bool:
    return Path(filename).name == "__init__.py"


def _is_python_source(filename: str) -> bool:
    """Return True for .py files that are neither __init__ nor test files."""
    return (
        filename.endswith(".py")
        and not _is_init_file(filename)
        and not _is_test_file(filename)
    )


# ---------------------------------------------------------------------------
# Main filter logic
# ---------------------------------------------------------------------------

def filter_repo(repo: dict[str, Any], config: dict[str, Any]) -> tuple[bool, str]:
    """Decide whether a repository passes quality filters.

    Parameters
    ----------
    repo:
        Repository dict as produced by the scraper. Expected keys include
        ``files`` (list of dicts with ``path`` and ``content``),
        ``metadata`` (dict with GitHub metadata), and optionally ``readme``.
    config:
        Filter thresholds from ``load_config()``.

    Returns
    -------
    (passes, reason) -- ``passes`` is True when the repo is acceptable,
    ``reason`` explains why it was discarded (empty string when it passes).
    """
    raw_files = repo.get("files", {})
    metadata: dict[str, Any] = repo.get("metadata", {})
    readme: str = repo.get("readme", "")

    # Normalize files to {path: content} dict — scraper outputs dict, but
    # accept list-of-dicts [{path, content}] too for flexibility.
    if isinstance(raw_files, dict):
        file_map: dict[str, str] = raw_files
    elif isinstance(raw_files, list):
        file_map = {f["path"]: f.get("content", "") for f in raw_files}
    else:
        file_map = {}

    # Classify files
    py_files = [p for p in file_map if p.endswith(".py")]
    source_files = [p for p in py_files if _is_python_source(p)]
    test_files = [p for p in py_files if _is_test_file(p)]
    notebook_files = [p for p in file_map if p.endswith(".ipynb")]

    # ------------------------------------------------------------------
    # 1. Structure minimum
    # ------------------------------------------------------------------
    if len(source_files) < config.get("min_python_files", 3):
        return (False, f"Too few source files: {len(source_files)} < {config['min_python_files']}")

    if len(test_files) < config.get("min_test_files", 1):
        return (False, f"Too few test files: {len(test_files)} < {config['min_test_files']}")

    min_readme = config.get("min_readme_chars", 200)
    if len(readme) < min_readme:
        return (False, f"README too short: {len(readme)} chars < {min_readme}")

    # ------------------------------------------------------------------
    # 2. Quality indicators
    # ------------------------------------------------------------------
    # Packaging
    if config.get("require_packaging", True):
        packaging_files = {"pyproject.toml", "setup.py", "setup.cfg"}
        has_packaging = any(
            Path(p).name in packaging_files for p in file_map
        )
        if not has_packaging:
            return (False, "Missing packaging file (pyproject.toml / setup.py / setup.cfg)")

    # Type hints -- ratio of source files that contain at least one annotation
    if source_files:
        typed_count = sum(
            1 for p in source_files if has_type_hints(file_map.get(p, ""))
        )
        hint_ratio = typed_count / len(source_files)
        required_ratio = config.get("type_hint_ratio", 0.30)
        if hint_ratio < required_ratio:
            return (False, f"Type hint ratio too low: {hint_ratio:.2f} < {required_ratio}")

    # Docstrings -- average ratio across all source files
    if source_files:
        doc_ratios = [
            has_docstrings(file_map.get(p, "")) for p in source_files
        ]
        avg_doc_ratio = sum(doc_ratios) / len(doc_ratios)
        required_doc = config.get("docstring_ratio", 0.20)
        if avg_doc_ratio < required_doc:
            return (False, f"Docstring ratio too low: {avg_doc_ratio:.2f} < {required_doc}")

    # ------------------------------------------------------------------
    # 3. Testing indicators
    # ------------------------------------------------------------------
    # Real tests (not just stubs) -- at least one test file must contain "def test_"
    real_test_files = [
        p for p in test_files
        if "def test_" in file_map.get(p, "")
    ]
    if not real_test_files:
        return (False, "No test files contain real test functions (def test_)")

    # Test-to-source ratio
    if source_files:
        ts_ratio = len(test_files) / len(source_files)
        required_ts = config.get("test_source_ratio", 0.30)
        if ts_ratio < required_ts:
            return (False, f"Test/source ratio too low: {ts_ratio:.2f} < {required_ts}")

    # ------------------------------------------------------------------
    # 4. Anti-patterns
    # ------------------------------------------------------------------
    # Stub ratio across all source files
    total_stubs = 0
    total_funcs = 0
    for p in source_files:
        s, t = count_stub_functions(file_map.get(p, ""))
        total_stubs += s
        total_funcs += t

    if total_funcs > 0:
        stub_ratio = total_stubs / total_funcs
        max_stub = config.get("max_stub_ratio", 0.50)
        if stub_ratio > max_stub:
            return (False, f"Stub ratio too high: {stub_ratio:.2f} > {max_stub}")

    # Notebook-only repos (no real .py source)
    if notebook_files and not source_files:
        return (False, "Notebook-only repo without real .py source files")

    # Fork detection (metadata)
    if metadata.get("fork", False):
        return (False, "Repository is a fork")

    return (True, "")


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main() -> None:
    """Process all repos in data/raw/ and save passing ones to data/filtered/."""
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)-8s %(name)s  %(message)s",
        stream=sys.stderr,
    )

    config = load_config()
    logger.info("Config loaded: %s", config)

    _RAW_DIR.mkdir(parents=True, exist_ok=True)
    _FILTERED_DIR.mkdir(parents=True, exist_ok=True)

    raw_files = sorted(_RAW_DIR.glob("*.json"))
    if not raw_files:
        logger.warning("No .json files found in %s", _RAW_DIR)
        return

    total = 0
    passed = 0
    reasons: dict[str, int] = {}

    for raw_path in raw_files:
        try:
            with open(raw_path, encoding="utf-8") as fh:
                repo = json.load(fh)
        except (json.JSONDecodeError, OSError) as exc:
            logger.error("Skipping %s: %s", raw_path.name, exc)
            continue

        total += 1
        ok, reason = filter_repo(repo, config)

        if ok:
            passed += 1
            out_path = _FILTERED_DIR / raw_path.name
            with open(out_path, "w", encoding="utf-8") as fh:
                json.dump(repo, fh, ensure_ascii=False)
            logger.debug("PASS  %s", raw_path.name)
        else:
            reasons[reason] = reasons.get(reason, 0) + 1
            logger.debug("FAIL  %s -- %s", raw_path.name, reason)

    # Summary
    logger.info("Filter complete: %d / %d passed (%.1f%%)",
                passed, total, (passed / total * 100) if total else 0)
    if reasons:
        logger.info("Rejection reasons:")
        for reason, count in sorted(reasons.items(), key=lambda x: -x[1]):
            logger.info("  %4d  %s", count, reason)


if __name__ == "__main__":
    main()
