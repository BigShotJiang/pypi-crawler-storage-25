"""Analyze structural complexity of filtered repos using KORE's AnalyzeStructureSkill.

Reads repos from data/filtered/*.json, runs the ComplexityAgent's
AnalyzeStructureSkill on each, filters by rating, and writes passing
repos (enriched with complexity data) to data/analyzed/.

Usage:
    python tools/dataset/analyzer.py
    python -m tools.dataset.analyzer
"""

from __future__ import annotations

import asyncio
import json
import logging
import sys
import time
from pathlib import Path
from typing import Any

import yaml

from kore_platform.agents.complexity.skills.analyze_structure import (
    AnalyzeStructureSkill,
)

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------

ROOT = Path(__file__).resolve().parent.parent.parent
CONFIG_PATH = Path(__file__).resolve().parent / "config.yaml"
FILTERED_DIR = ROOT / "data" / "filtered"
OUTPUT_DIR = ROOT / "data" / "analyzed"

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------


def load_config(path: str | Path = CONFIG_PATH) -> dict[str, Any]:
    """Load the analyzer section from the pipeline configuration YAML.

    Parameters
    ----------
    path:
        Path to the YAML configuration file.  Defaults to
        ``tools/dataset/config.yaml``.

    Returns
    -------
    dict
        The ``analyzer`` section of the config, with keys
        ``pass_ratings``, ``conditional_rating``, and
        ``conditional_min_stars``.
    """
    with open(path, encoding="utf-8") as fh:
        raw = yaml.safe_load(fh)
    return raw["analyzer"]


# ---------------------------------------------------------------------------
# Analysis helpers
# ---------------------------------------------------------------------------


async def analyze_repo(
    repo: dict[str, Any],
    skill: AnalyzeStructureSkill,
) -> dict[str, Any]:
    """Run AnalyzeStructureSkill on a single repo's files.

    Parameters
    ----------
    repo:
        Repository dict that must contain a ``"files"`` key mapping
        file paths to source code.
    skill:
        A pre-instantiated AnalyzeStructureSkill (reused across repos).

    Returns
    -------
    dict
        A *copy* of *repo* enriched with a ``"complexity"`` key holding
        the full skill result (metrics, rating, warnings, graph).
    """
    files = repo.get("files", {})
    result = await skill.execute(
        inputs={"files": files},
        context={},
    )
    enriched = {**repo, "complexity": result}
    return enriched


def passes_quality(
    repo: dict[str, Any],
    config: dict[str, Any],
) -> tuple[bool, str]:
    """Decide whether a repo passes the quality gate based on its rating.

    Rules (driven entirely by config):
    - Ratings in ``pass_ratings`` (default A, B) always pass.
    - The ``conditional_rating`` (default C) passes only when the repo's
      star count exceeds ``conditional_min_stars``.
    - Everything else (D, F, or unknown) is discarded.

    Parameters
    ----------
    repo:
        Repo dict that has been enriched with a ``"complexity"`` key.
    config:
        The ``analyzer`` section of config.yaml.

    Returns
    -------
    tuple[bool, str]
        ``(accepted, reason)`` where *reason* is a human-readable
        explanation suitable for logging.
    """
    rating = repo.get("complexity", {}).get("rating", "F")
    pass_ratings: list[str] = config.get("pass_ratings", ["A", "B"])
    conditional_rating: str = config.get("conditional_rating", "C")
    conditional_min_stars: int = config.get("conditional_min_stars", 500)

    if rating in pass_ratings:
        return True, f"rating={rating} (auto-pass)"

    if rating == conditional_rating:
        stars = repo.get("stars", 0)
        if stars > conditional_min_stars:
            return True, f"rating={rating} stars={stars} > {conditional_min_stars} (conditional pass)"
        return False, f"rating={rating} stars={stars} <= {conditional_min_stars} (conditional fail)"

    return False, f"rating={rating} (discarded)"


# ---------------------------------------------------------------------------
# Main pipeline
# ---------------------------------------------------------------------------


async def main() -> None:
    """Orchestrate the full analyze-and-filter pipeline.

    Steps:
        1. Load config.
        2. Read all repos from ``data/filtered/*.json``.
        3. Instantiate AnalyzeStructureSkill once.
        4. Run the skill on every repo (sequentially to keep memory steady).
        5. Filter repos through the quality gate.
        6. Write passing repos to ``data/analyzed/``.
        7. Print summary statistics.
    """
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )

    # -- 1. Config -----------------------------------------------------------
    config = load_config()
    logger.info(
        "Config cargado: pass_ratings=%s conditional=%s min_stars=%d",
        config.get("pass_ratings"),
        config.get("conditional_rating"),
        config.get("conditional_min_stars"),
    )

    # -- 2. Read filtered repos ----------------------------------------------
    if not FILTERED_DIR.exists():
        logger.error("Directorio no encontrado: %s", FILTERED_DIR)
        sys.exit(1)

    json_files = sorted(FILTERED_DIR.glob("*.json"))
    if not json_files:
        logger.error("No se encontraron archivos JSON en %s", FILTERED_DIR)
        sys.exit(1)

    repos: list[dict[str, Any]] = []
    for jf in json_files:
        with open(jf, encoding="utf-8") as fh:
            data = json.load(fh)
        # Support both a single repo dict and a list of repos per file
        if isinstance(data, list):
            repos.extend(data)
        elif isinstance(data, dict):
            repos.append(data)
    logger.info("Repos cargados: %d (de %d archivos)", len(repos), len(json_files))

    # -- 3. Skill instance ---------------------------------------------------
    skill = AnalyzeStructureSkill()

    # -- 4 & 5. Analyze and filter -------------------------------------------
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    passed: list[dict[str, Any]] = []
    stats: dict[str, int] = {"A": 0, "B": 0, "C": 0, "D": 0, "F": 0}
    total = len(repos)
    t0 = time.monotonic()

    for idx, repo in enumerate(repos, start=1):
        repo_name = repo.get("full_name", repo.get("name", f"repo_{idx}"))
        enriched = await analyze_repo(repo, skill)

        rating = enriched.get("complexity", {}).get("rating", "F")
        stats[rating] = stats.get(rating, 0) + 1

        accepted, reason = passes_quality(enriched, config)
        status = "PASS" if accepted else "SKIP"
        logger.info("[%d/%d] %s %s  %s", idx, total, status, repo_name, reason)

        if accepted:
            passed.append(enriched)

    elapsed = time.monotonic() - t0

    # -- 6. Write output -----------------------------------------------------
    output_file = OUTPUT_DIR / "analyzed_repos.json"
    with open(output_file, "w", encoding="utf-8") as fh:
        json.dump(passed, fh, indent=2, ensure_ascii=False)
    logger.info("Repos aceptados guardados en %s", output_file)

    # -- 7. Statistics -------------------------------------------------------
    print("\n" + "=" * 60)
    print("  KORE Dataset Analyzer -- Resumen")
    print("=" * 60)
    print(f"  Repos analizados:  {total}")
    print(f"  Repos aceptados:   {len(passed)}")
    print(f"  Repos descartados: {total - len(passed)}")
    print(f"  Tiempo total:      {elapsed:.1f}s")
    print()
    print("  Distribucion de ratings:")
    for grade in ("A", "B", "C", "D", "F"):
        count = stats.get(grade, 0)
        pct = (count / total * 100) if total else 0
        bar = "#" * int(pct / 2)
        print(f"    {grade}: {count:>5}  ({pct:5.1f}%)  {bar}")
    print("=" * 60)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    asyncio.run(main())
