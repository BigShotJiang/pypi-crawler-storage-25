"""Dataset extractor: transforms analyzed repos into (prompt, completion) pairs.

Reads analyzed repo JSON files from ``data/analyzed/``, builds structured
prompt/completion pairs suitable for fine-tuning, and writes train/val JSONL
splits alongside a ``stats.json`` summary to ``data/dataset/``.

Usage::

    python -m tools.dataset.extractor
    python -m tools.dataset.extractor --config tools/dataset/config.yaml
"""

from __future__ import annotations

import argparse
import json
import logging
import random
import re
from collections import defaultdict
from pathlib import Path

import yaml

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

PROJECT_ROOT = Path(__file__).resolve().parents[2]
DEFAULT_CONFIG_PATH = PROJECT_ROOT / "tools" / "dataset" / "config.yaml"
ANALYZED_DIR = PROJECT_ROOT / "data" / "analyzed"
OUTPUT_DIR = PROJECT_ROOT / "data" / "dataset"

# Section headings that mark the end of the "intro" block in a README.
_STOP_HEADINGS = re.compile(
    r"^#{1,3}\s+"
    r"(install|setup|getting\s+started|usage|quickstart|requirements|prerequisites"
    r"|features|table\s+of\s+contents|documentation|contributing|license)",
    re.IGNORECASE | re.MULTILINE,
)

# Any second-level (or deeper) heading.
_ANY_HEADING = re.compile(r"^#{2,}\s+", re.MULTILINE)

log = logging.getLogger("kore.dataset.extractor")

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------


def load_config(path: str | Path = DEFAULT_CONFIG_PATH) -> dict:
    """Load the ``extractor`` section from the pipeline YAML config.

    Parameters
    ----------
    path:
        Path to the full pipeline ``config.yaml``.

    Returns
    -------
    dict
        The ``extractor`` sub-dictionary with all thresholds.
    """
    config_path = Path(path)
    if not config_path.exists():
        raise FileNotFoundError(f"Config file not found: {config_path}")
    with open(config_path, encoding="utf-8") as fh:
        full = yaml.safe_load(fh)
    if "extractor" not in full:
        raise KeyError("Config file is missing the 'extractor' section")
    return full["extractor"]


# ---------------------------------------------------------------------------
# Token estimation
# ---------------------------------------------------------------------------


def estimate_tokens(text: str) -> int:
    """Return an approximate token count (roughly 4 characters per token)."""
    return len(text) // 4


# ---------------------------------------------------------------------------
# Description extraction (Strategy 1 -- no LLM)
# ---------------------------------------------------------------------------


def extract_description(
    readme: str,
    metadata: dict,
    config: dict,
) -> str:
    """Extract a natural-language project description from the README.

    Strategy (no LLM):
      1. Take the text before the first ``##`` heading **or** before a known
         "stop heading" (Installation, Setup, Getting Started, etc.).
      2. Strip leading title lines (``# Title``), badges, and blank lines.
      3. If the result is shorter than ``min_description_chars``, fall back
         to the GitHub ``description`` field from *metadata*.
      4. If longer than ``max_description_chars``, truncate at the end of
         the first paragraph (double newline boundary).

    Parameters
    ----------
    readme:
        Full text of the repository's README (Markdown).
    metadata:
        Dictionary with at least an optional ``description`` key from the
        GitHub API.
    config:
        The ``extractor`` config dictionary.

    Returns
    -------
    str
        Cleaned description, or an empty string if nothing usable is found.
    """
    min_chars = config.get("min_description_chars", 50)
    max_chars = config.get("max_description_chars", 500)

    desc = _extract_intro_from_readme(readme)

    # Fallback: GitHub repo description.
    if len(desc) < min_chars:
        gh_desc = (metadata.get("description") or "").strip()
        if gh_desc:
            desc = gh_desc

    # Still too short -- give up.
    if len(desc) < min_chars:
        return ""

    # Truncate if too long: cut at first paragraph boundary.
    if len(desc) > max_chars:
        desc = _truncate_at_paragraph(desc, max_chars)

    return desc.strip()


def _extract_intro_from_readme(readme: str) -> str:
    """Return the introductory paragraph(s) from a Markdown README."""
    if not readme:
        return ""

    # Find the earliest "stop" heading.
    stop_match = _STOP_HEADINGS.search(readme)
    # Find the first ## (or ###) heading of any kind.
    heading_match = _ANY_HEADING.search(readme)

    # Choose the earliest cut point.
    cut = len(readme)
    if stop_match:
        cut = min(cut, stop_match.start())
    if heading_match:
        cut = min(cut, heading_match.start())

    intro = readme[:cut]

    # Strip a leading top-level title (``# Project Name``).
    lines = intro.splitlines()
    cleaned: list[str] = []
    skipped_title = False
    for line in lines:
        stripped = line.strip()
        # Skip the first ``# Title`` line.
        if not skipped_title and stripped.startswith("# "):
            skipped_title = True
            continue
        # Skip badge image lines ([![...](...)]).
        if re.match(r"^\[?!\[", stripped):
            continue
        # Skip raw HTML badge tags.
        if stripped.startswith("<") and ("badge" in stripped.lower() or "img" in stripped.lower()):
            continue
        cleaned.append(line)

    return "\n".join(cleaned).strip()


def _truncate_at_paragraph(text: str, max_chars: int) -> str:
    """Truncate *text* at the first paragraph boundary within *max_chars*."""
    # Look for a double-newline before max_chars.
    idx = text.rfind("\n\n", 0, max_chars)
    if idx > 0:
        return text[:idx].strip()
    # No paragraph break found; hard-truncate at a word boundary.
    truncated = text[:max_chars]
    last_space = truncated.rfind(" ")
    if last_space > max_chars // 2:
        return truncated[:last_space].rstrip() + "..."
    return truncated.rstrip() + "..."


# ---------------------------------------------------------------------------
# Completion formatting
# ---------------------------------------------------------------------------

# File extensions / names to include.
_INCLUDE_EXTENSIONS = {".py"}
_INCLUDE_NAMES = {"pyproject.toml"}

# Path segments that cause a file to be excluded.
_EXCLUDE_SEGMENTS = {"test", "tests", "testing", "__pycache__", ".tox", ".nox", "benchmarks"}


def format_completion(files: dict, config: dict) -> str | None:
    """Format repository source files into a ``<FILE>`` block completion string.

    Parameters
    ----------
    files:
        Mapping of ``{relative_path: file_content}`` for every file in the
        analysed repo snapshot.
    config:
        The ``extractor`` config dictionary.

    Returns
    -------
    str or None
        The formatted completion, or ``None`` if the repo exceeds the
        ``max_tokens_per_pair`` budget.
    """
    max_file_kb = config.get("max_file_size_kb", 10)
    max_tokens = config.get("max_tokens_per_pair", 12000)

    selected = _select_files(files, max_file_kb)
    if not selected:
        return None

    # Order: pyproject.toml first, then by path depth, then alphabetically.
    selected_paths = sorted(
        selected.keys(),
        key=lambda p: (0 if p == "pyproject.toml" else 1, p.count("/"), p),
    )

    parts: list[str] = []
    for path in selected_paths:
        content = selected[path]
        parts.append(f'<FILE path="{path}">\n{content}\n</FILE>')

    completion = "\n".join(parts)

    if estimate_tokens(completion) > max_tokens:
        return None

    return completion


def _select_files(files: dict, max_file_kb: int) -> dict:
    """Filter *files* to only those eligible for the completion block."""
    result: dict[str, str] = {}
    max_bytes = max_file_kb * 1024

    for path, content in files.items():
        # Always include pyproject.toml regardless of extension.
        name = path.rsplit("/", 1)[-1] if "/" in path else path
        is_allowed_name = name in _INCLUDE_NAMES
        is_allowed_ext = any(name.endswith(ext) for ext in _INCLUDE_EXTENSIONS)

        if not (is_allowed_name or is_allowed_ext):
            continue

        # Exclude test / benchmark directories.
        path_parts = set(path.lower().replace("\\", "/").split("/"))
        if path_parts & _EXCLUDE_SEGMENTS:
            continue

        # Exclude files that start with "test_" or end with "_test.py".
        if name.startswith("test_") or name.endswith("_test.py"):
            continue

        # Size check.
        if len(content.encode("utf-8", errors="replace")) > max_bytes:
            continue

        result[path] = content

    return result


# ---------------------------------------------------------------------------
# Pair builder
# ---------------------------------------------------------------------------


def build_pair(repo: dict, config: dict) -> dict | None:
    """Build a single (prompt, completion, metadata) pair for a repo.

    Parameters
    ----------
    repo:
        A dictionary representing one analysed repository.  Expected keys:

        - ``owner`` / ``name`` (or ``full_name``): repository identifier.
        - ``readme``: full README text.
        - ``files``: ``{path: content}`` mapping.
        - ``stars``: star count (int).
        - ``complexity_rating``: letter grade (``"A"``, ``"B"``, etc.).
        - Optional ``description``: GitHub short description.

    config:
        The ``extractor`` config dictionary.

    Returns
    -------
    dict or None
        The formatted pair, or ``None`` if the repo should be skipped.
    """
    system_prompt = config.get("system_prompt", "").strip()
    readme = repo.get("readme", "")
    metadata = {
        "description": repo.get("description", ""),
    }

    description = extract_description(readme, metadata, config)
    if not description:
        log.debug("Skipping %s: no usable description", _repo_name(repo))
        return None

    completion = format_completion(repo.get("files", {}), config)
    if completion is None:
        log.debug("Skipping %s: completion too large or no files", _repo_name(repo))
        return None

    prompt = f"<SYSTEM>\n{system_prompt}\n</SYSTEM>\n\n<USER>\n{description}\n</USER>"

    total_tokens = estimate_tokens(prompt + completion)
    max_tokens = config.get("max_tokens_per_pair", 12000)
    if total_tokens > max_tokens:
        log.debug(
            "Skipping %s: total tokens %d > %d",
            _repo_name(repo),
            total_tokens,
            max_tokens,
        )
        return None

    file_count = completion.count("<FILE ")

    return {
        "prompt": prompt,
        "completion": completion,
        "metadata": {
            "repo": _repo_name(repo),
            "stars": repo.get("stars", 0),
            "complexity_rating": repo.get("complexity_rating", "?"),
            "file_count": file_count,
            "token_count": total_tokens,
        },
    }


def _repo_name(repo: dict) -> str:
    """Return ``owner/name`` from a repo dict, tolerating several key layouts."""
    if "full_name" in repo:
        return repo["full_name"]
    owner = repo.get("owner", "unknown")
    name = repo.get("name", "unknown")
    return f"{owner}/{name}"


# ---------------------------------------------------------------------------
# Train / val split (stratified)
# ---------------------------------------------------------------------------

# Size buckets for stratification.
_SIZE_SMALL = "small"    # <5 files
_SIZE_MEDIUM = "medium"  # 5-15 files
_SIZE_LARGE = "large"    # >15 files


def _size_bucket(pair: dict) -> str:
    fc = pair["metadata"]["file_count"]
    if fc < 5:
        return _SIZE_SMALL
    if fc <= 15:
        return _SIZE_MEDIUM
    return _SIZE_LARGE


def split_dataset(
    pairs: list[dict],
    config: dict,
) -> tuple[list[dict], list[dict]]:
    """Split *pairs* into (train, val) with stratification.

    Stratification keys:
      - ``complexity_rating`` (A / B / C / ...)
      - project size bucket (small / medium / large)

    The split is shuffled with the ``random_seed`` from config for
    reproducibility.

    Parameters
    ----------
    pairs:
        List of pair dictionaries as returned by :func:`build_pair`.
    config:
        The ``extractor`` config dictionary.

    Returns
    -------
    tuple[list[dict], list[dict]]
        ``(train_pairs, val_pairs)``
    """
    seed = config.get("random_seed", 42)
    train_ratio = config.get("train_ratio", 0.90)
    rng = random.Random(seed)

    # Group by stratification key.
    strata: dict[str, list[dict]] = defaultdict(list)
    for pair in pairs:
        rating = pair["metadata"].get("complexity_rating", "?")
        bucket = _size_bucket(pair)
        key = f"{rating}_{bucket}"
        strata[key].append(pair)

    train: list[dict] = []
    val: list[dict] = []

    for _key in sorted(strata):
        group = strata[_key]
        rng.shuffle(group)
        split_idx = max(1, round(len(group) * train_ratio))
        # Ensure at least one val sample per stratum when possible.
        if len(group) > 1 and split_idx == len(group):
            split_idx = len(group) - 1
        train.extend(group[:split_idx])
        val.extend(group[split_idx:])

    # Final shuffle so strata are interleaved.
    rng.shuffle(train)
    rng.shuffle(val)

    return train, val


# ---------------------------------------------------------------------------
# I/O helpers
# ---------------------------------------------------------------------------


def _load_analyzed_repos(directory: Path) -> list[dict]:
    """Load all JSON files from the analyzed-repos directory."""
    repos: list[dict] = []
    if not directory.is_dir():
        log.warning("Analyzed directory does not exist: %s", directory)
        return repos
    for json_file in sorted(directory.glob("*.json")):
        try:
            with open(json_file, encoding="utf-8") as fh:
                data = json.load(fh)
            # Support both single-repo dicts and lists of repos.
            if isinstance(data, list):
                repos.extend(data)
            else:
                repos.append(data)
        except (json.JSONDecodeError, OSError) as exc:
            log.warning("Failed to load %s: %s", json_file, exc)
    return repos


def _write_jsonl(pairs: list[dict], path: Path) -> None:
    """Write a list of pair dicts as newline-delimited JSON."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        for pair in pairs:
            fh.write(json.dumps(pair, ensure_ascii=False) + "\n")
    log.info("Wrote %d pairs to %s", len(pairs), path)


def _compute_stats(
    train: list[dict],
    val: list[dict],
) -> dict:
    """Compute summary statistics for the dataset."""
    all_pairs = train + val
    if not all_pairs:
        return {"total_pairs": 0}

    token_counts = [p["metadata"]["token_count"] for p in all_pairs]
    file_counts = [p["metadata"]["file_count"] for p in all_pairs]
    stars = [p["metadata"]["stars"] for p in all_pairs]

    rating_dist: dict[str, int] = defaultdict(int)
    for p in all_pairs:
        rating_dist[p["metadata"]["complexity_rating"]] += 1

    size_dist: dict[str, int] = defaultdict(int)
    for p in all_pairs:
        size_dist[_size_bucket(p)] += 1

    return {
        "total_pairs": len(all_pairs),
        "train_pairs": len(train),
        "val_pairs": len(val),
        "tokens": {
            "min": min(token_counts),
            "max": max(token_counts),
            "mean": round(sum(token_counts) / len(token_counts), 1),
            "median": sorted(token_counts)[len(token_counts) // 2],
        },
        "file_counts": {
            "min": min(file_counts),
            "max": max(file_counts),
            "mean": round(sum(file_counts) / len(file_counts), 1),
        },
        "stars": {
            "min": min(stars),
            "max": max(stars),
            "mean": round(sum(stars) / len(stars), 1),
        },
        "complexity_rating_distribution": dict(sorted(rating_dist.items())),
        "size_bucket_distribution": dict(sorted(size_dist.items())),
    }


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def main(config_path: str | Path = DEFAULT_CONFIG_PATH) -> None:
    """Orchestrate the full extraction pipeline.

    Steps:
      1. Load config.
      2. Load all analysed repo JSON files from ``data/analyzed/``.
      3. Build (prompt, completion) pairs, skipping repos that fail filters.
      4. Split into train / val.
      5. Write ``train.jsonl``, ``val.jsonl``, and ``stats.json``.
    """
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s  %(levelname)-8s  %(name)s  %(message)s",
    )

    config = load_config(config_path)
    log.info("Loaded extractor config from %s", config_path)

    repos = _load_analyzed_repos(ANALYZED_DIR)
    log.info("Loaded %d analyzed repo(s)", len(repos))
    if not repos:
        log.warning("No analyzed repos found in %s -- nothing to do.", ANALYZED_DIR)
        return

    # Build pairs.
    pairs: list[dict] = []
    skipped = 0
    for repo in repos:
        pair = build_pair(repo, config)
        if pair is not None:
            pairs.append(pair)
        else:
            skipped += 1

    log.info("Built %d pairs, skipped %d repos", len(pairs), skipped)
    if not pairs:
        log.warning("No valid pairs produced -- exiting.")
        return

    # Split.
    train, val = split_dataset(pairs, config)
    log.info("Split: %d train, %d val", len(train), len(val))

    # Write outputs.
    _write_jsonl(train, OUTPUT_DIR / "train.jsonl")
    _write_jsonl(val, OUTPUT_DIR / "val.jsonl")

    stats = _compute_stats(train, val)
    stats_path = OUTPUT_DIR / "stats.json"
    stats_path.parent.mkdir(parents=True, exist_ok=True)
    with open(stats_path, "w", encoding="utf-8") as fh:
        json.dump(stats, fh, indent=2, ensure_ascii=False)
    log.info("Wrote dataset stats to %s", stats_path)

    # Print summary to stdout.
    print("\n--- Dataset Summary ---")
    print(f"  Total pairs : {stats['total_pairs']}")
    print(f"  Train       : {stats['train_pairs']}")
    print(f"  Val         : {stats['val_pairs']}")
    print(f"  Avg tokens  : {stats['tokens']['mean']}")
    print(f"  Ratings     : {stats['complexity_rating_distribution']}")
    print(f"  Sizes       : {stats['size_bucket_distribution']}")
    print("---")


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Extract fine-tuning dataset from analyzed repos.",
    )
    parser.add_argument(
        "--config",
        default=str(DEFAULT_CONFIG_PATH),
        help="Path to the pipeline config.yaml (default: %(default)s)",
    )
    args = parser.parse_args()
    main(config_path=args.config)
