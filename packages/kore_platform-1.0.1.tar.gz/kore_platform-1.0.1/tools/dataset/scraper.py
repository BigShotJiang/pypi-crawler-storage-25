"""
GitHub repository scraper for building a KORE fine-tuning dataset.

Searches for Python repositories matching configurable criteria (stars,
license, activity date) and saves structured JSON with source code, tests,
README, and metadata for each qualifying repo.

Usage:
    python -m tools.dataset.scraper
    python tools/dataset/scraper.py
    python tools/dataset/scraper.py --config path/to/config.yaml
"""

from __future__ import annotations

import argparse
import asyncio
import base64
import json
import logging
import os
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import httpx
import yaml

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

GITHUB_API = "https://api.github.com"
SEARCH_ENDPOINT = "/search/repositories"
# GitHub search returns at most 1000 results per query; we paginate with
# date-range slicing to work around this.
SEARCH_PAGE_LIMIT = 1000
ITEMS_PER_PAGE = 100  # max allowed by the API

# ---------------------------------------------------------------------------
# Config loader
# ---------------------------------------------------------------------------


def load_config(config_path: str | Path) -> dict[str, Any]:
    """Load and return the scraper section of the YAML config file.

    Raises ``FileNotFoundError`` if *config_path* does not exist, and
    ``KeyError`` if the ``scraper`` key is missing.
    """
    config_path = Path(config_path)
    if not config_path.exists():
        raise FileNotFoundError(f"Config file not found: {config_path}")

    with open(config_path, "r", encoding="utf-8") as fh:
        raw = yaml.safe_load(fh)

    if "scraper" not in raw:
        raise KeyError("Config file is missing the 'scraper' key")

    return raw["scraper"]


# ---------------------------------------------------------------------------
# Scraper
# ---------------------------------------------------------------------------


class GitHubScraper:
    """Async scraper that queries the GitHub API and persists repo data.

    All numeric thresholds are read from the config dict passed at init time
    so that nothing is hardcoded.
    """

    def __init__(self, config: dict[str, Any], project_root: Path) -> None:
        self.config = config
        self.project_root = project_root

        # Thresholds from config
        self.language: str = config["language"]
        self.min_stars: int = config["min_stars"]
        self.pushed_after: str = config["pushed_after"]
        self.licenses: list[str] = config["licenses"]
        self.max_python_files: int = config["max_python_files"]
        self.max_file_size_kb: int = config["max_file_size_kb"]
        self.max_repos: int = config["max_repos"]
        self.requests_per_second: float = config["requests_per_second"]

        # Derived
        self.max_file_size_bytes: int = self.max_file_size_kb * 1024
        self.min_request_interval: float = 1.0 / self.requests_per_second

        # Paths
        self.checkpoint_path = project_root / config["checkpoint_file"]
        self.output_dir = project_root / "data" / "raw"
        self.output_dir.mkdir(parents=True, exist_ok=True)

        # Token
        self.token: str = os.environ.get("GITHUB_TOKEN", "")
        if not self.token:
            raise EnvironmentError(
                "GITHUB_TOKEN environment variable is not set. "
                "A personal access token is required to use the GitHub API."
            )

        # State
        self._checkpoint: dict[str, Any] = {}
        self._scraped_repos: set[str] = set()
        self._total_saved: int = 0
        self._last_request_ts: float = 0.0

        # httpx client (created in async context)
        self._client: httpx.AsyncClient | None = None

    # -- HTTP helpers -------------------------------------------------------

    async def _ensure_client(self) -> httpx.AsyncClient:
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(
                base_url=GITHUB_API,
                headers={
                    "Accept": "application/vnd.github+json",
                    "Authorization": f"Bearer {self.token}",
                    "X-GitHub-Api-Version": "2022-11-28",
                },
                timeout=httpx.Timeout(30.0, connect=10.0),
            )
        return self._client

    async def _throttle(self) -> None:
        """Sleep enough to respect ``requests_per_second``."""
        now = time.monotonic()
        elapsed = now - self._last_request_ts
        if elapsed < self.min_request_interval:
            await asyncio.sleep(self.min_request_interval - elapsed)
        self._last_request_ts = time.monotonic()

    async def _request(
        self,
        method: str,
        url: str,
        *,
        params: dict[str, Any] | None = None,
        max_retries: int = 6,
    ) -> httpx.Response:
        """Issue an HTTP request with exponential backoff and rate-limit
        awareness.

        Returns the response on success.  Raises after *max_retries*
        consecutive failures.
        """
        client = await self._ensure_client()
        backoff = 1.0

        for attempt in range(1, max_retries + 1):
            await self._throttle()
            try:
                resp = await client.request(method, url, params=params)
            except (httpx.ConnectError, httpx.ReadTimeout, httpx.WriteTimeout) as exc:
                log.warning(
                    "Network error on attempt %d/%d for %s: %s",
                    attempt,
                    max_retries,
                    url,
                    exc,
                )
                await asyncio.sleep(backoff)
                backoff = min(backoff * 2, 120)
                continue

            # Rate-limit handling
            remaining = resp.headers.get("X-RateLimit-Remaining")
            reset_ts = resp.headers.get("X-RateLimit-Reset")

            if resp.status_code == 403 and remaining == "0":
                if reset_ts:
                    wait = max(int(reset_ts) - int(time.time()), 1) + 1
                else:
                    wait = int(backoff)
                log.warning(
                    "Rate limit exhausted. Sleeping %d s until reset.", wait
                )
                await asyncio.sleep(wait)
                backoff = min(backoff * 2, 120)
                continue

            if resp.status_code == 422:
                # GitHub sometimes returns 422 for search pagination beyond
                # 1000 results; treat as non-retryable.
                return resp

            if resp.status_code in (500, 502, 503):
                log.warning(
                    "Server error %d on attempt %d/%d for %s",
                    resp.status_code,
                    attempt,
                    max_retries,
                    url,
                )
                await asyncio.sleep(backoff)
                backoff = min(backoff * 2, 120)
                continue

            # Proactive slow-down when remaining requests are low
            if remaining is not None and int(remaining) < 5:
                if reset_ts:
                    wait = max(int(reset_ts) - int(time.time()), 1) + 1
                    log.info(
                        "Only %s requests remaining. Pausing %d s.",
                        remaining,
                        wait,
                    )
                    await asyncio.sleep(wait)

            return resp

        raise RuntimeError(
            f"Request to {url} failed after {max_retries} retries"
        )

    # -- Checkpoint ---------------------------------------------------------

    def load_checkpoint(self) -> None:
        """Load checkpoint from disk if it exists."""
        if self.checkpoint_path.exists():
            with open(self.checkpoint_path, "r", encoding="utf-8") as fh:
                self._checkpoint = json.load(fh)
            self._scraped_repos = set(self._checkpoint.get("scraped_repos", []))
            self._total_saved = len(self._scraped_repos)
            log.info(
                "Checkpoint loaded: %d repos already scraped.", self._total_saved
            )
        else:
            self._checkpoint = {
                "scraped_repos": [],
                "last_search_cursor": None,
                "started_at": datetime.now(timezone.utc).isoformat(),
            }
            log.info("No checkpoint found. Starting fresh.")

    def save_checkpoint(self) -> None:
        """Persist current progress to the checkpoint file."""
        self.checkpoint_path.parent.mkdir(parents=True, exist_ok=True)
        self._checkpoint["scraped_repos"] = sorted(self._scraped_repos)
        self._checkpoint["updated_at"] = datetime.now(timezone.utc).isoformat()
        tmp = self.checkpoint_path.with_suffix(".tmp")
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(self._checkpoint, fh)
        tmp.replace(self.checkpoint_path)

    # -- Search -------------------------------------------------------------

    def _build_search_query(self, stars_range: str | None = None) -> str:
        """Build the GitHub search query string from config values."""
        parts = [
            f"language:{self.language}",
            f"pushed:>{self.pushed_after}",
        ]
        if stars_range:
            parts.append(f"stars:{stars_range}")
        else:
            parts.append(f"stars:>={self.min_stars}")

        license_clause = " ".join(
            f"license:{lic}" for lic in self.licenses
        )
        # GitHub search OR semantics: multiple license: terms are ORed
        parts.append(license_clause)

        return " ".join(parts)

    async def _search_page(
        self, query: str, page: int
    ) -> tuple[list[dict[str, Any]], int]:
        """Fetch one page of search results.

        Returns ``(items, total_count)``.
        """
        params = {
            "q": query,
            "sort": "stars",
            "order": "desc",
            "per_page": ITEMS_PER_PAGE,
            "page": page,
        }
        resp = await self._request("GET", SEARCH_ENDPOINT, params=params)
        if resp.status_code == 422:
            return [], 0
        resp.raise_for_status()
        data = resp.json()
        return data.get("items", []), data.get("total_count", 0)

    async def search_repos(self) -> list[dict[str, Any]]:
        """Search GitHub for repositories matching the configured criteria.

        Uses star-range slicing so that queries returning more than 1000
        results are automatically split into smaller windows.  Already-
        scraped repos (from checkpoint) are skipped.

        Returns the list of repo metadata dicts collected.
        """
        all_repos: list[dict[str, Any]] = []

        # We slice by star ranges to avoid hitting the 1000-result ceiling.
        # Start with a broad query to find out how big the result set is.
        star_ranges = self._compute_star_ranges()

        for star_range in star_ranges:
            if self._total_saved + len(all_repos) >= self.max_repos:
                break

            query = self._build_search_query(stars_range=star_range)
            log.info("Searching: %s", query)

            page = 1
            while page <= (SEARCH_PAGE_LIMIT // ITEMS_PER_PAGE):
                items, total = await self._search_page(query, page)
                if not items:
                    break

                for item in items:
                    full_name = item["full_name"]
                    if full_name in self._scraped_repos:
                        continue
                    if self._total_saved + len(all_repos) >= self.max_repos:
                        break
                    all_repos.append(item)

                log.info(
                    "  page %d  | batch: %d | accumulated: %d | total hits: %d",
                    page,
                    len(items),
                    len(all_repos),
                    total,
                )

                if len(items) < ITEMS_PER_PAGE:
                    break
                page += 1

        log.info("Search complete. %d new repos to process.", len(all_repos))
        return all_repos

    def _compute_star_ranges(self) -> list[str]:
        """Return a list of star-range strings for search slicing.

        The ranges go from very popular down to ``min_stars`` so that each
        slice stays well under 1000 results.
        """
        boundaries = [
            100_000, 50_000, 20_000, 10_000, 5_000, 2_000, 1_000,
            500, 200, 100, 50, 20, 10,
        ]
        # Filter to only include boundaries >= min_stars
        boundaries = [b for b in boundaries if b >= self.min_stars]
        if not boundaries or boundaries[-1] != self.min_stars:
            boundaries.append(self.min_stars)

        ranges: list[str] = []
        for i, upper in enumerate(boundaries):
            if i == 0:
                ranges.append(f">={upper}")
            else:
                prev = boundaries[i - 1]
                ranges.append(f"{upper}..{prev - 1}")

        return ranges

    # -- Fetch repo content -------------------------------------------------

    async def fetch_repo_content(
        self, repo_meta: dict[str, Any]
    ) -> dict[str, Any] | None:
        """Fetch tree, source files, tests, and README for a single repo.

        Returns ``None`` if the repo does not meet the quality gates (no
        Python files in root/src, too many Python files, etc.).
        """
        full_name: str = repo_meta["full_name"]
        owner, name = full_name.split("/", 1)
        default_branch: str = repo_meta.get("default_branch", "main")

        # 1. Fetch the full file tree (recursive)
        tree = await self._fetch_tree(full_name, default_branch)
        if tree is None:
            log.info("  [skip] %s -- could not fetch tree", full_name)
            return None

        tree_paths: list[str] = [item["path"] for item in tree]

        # 2. Identify Python files
        py_files = [p for p in tree_paths if p.endswith(".py")]

        if len(py_files) > self.max_python_files:
            log.info(
                "  [skip] %s -- too many Python files (%d > %d)",
                full_name,
                len(py_files),
                self.max_python_files,
            )
            return None

        # Gate: must have .py files in root or src/
        has_root_py = any(
            "/" not in p or p.startswith("src/") for p in py_files
        )
        if not has_root_py:
            log.info(
                "  [skip] %s -- no .py files in root or src/", full_name
            )
            return None

        # 3. Partition into source files and test files
        source_paths: list[str] = []
        test_paths: list[str] = []
        for p in py_files:
            basename = p.rsplit("/", 1)[-1]
            parts = p.split("/")
            is_test = (
                basename.startswith("test_")
                or basename.endswith("_test.py")
                or "tests" in parts
                or "test" in parts
            )
            if is_test:
                test_paths.append(p)
            else:
                source_paths.append(p)

        if not source_paths:
            log.info("  [skip] %s -- no source Python files", full_name)
            return None

        # 4. Fetch file contents concurrently (with size gate)
        source_contents = await self._fetch_files(full_name, default_branch, source_paths)
        test_contents = await self._fetch_files(full_name, default_branch, test_paths)

        # 5. Fetch README
        readme = await self._fetch_readme(full_name, default_branch, tree_paths)

        # 6. Build result
        license_info = repo_meta.get("license") or {}
        result: dict[str, Any] = {
            "repo": full_name,
            "stars": repo_meta.get("stargazers_count", 0),
            "license": license_info.get("spdx_id", "UNKNOWN") if isinstance(license_info, dict) else str(license_info),
            "description": repo_meta.get("description") or "",
            "readme": readme,
            "tree": tree_paths,
            "files": source_contents,
            "test_files": test_contents,
            "metadata": {
                "scraped_at": datetime.now(timezone.utc).isoformat(),
                "default_branch": default_branch,
                "topics": repo_meta.get("topics", []),
            },
        }
        return result

    async def _fetch_tree(
        self, full_name: str, branch: str
    ) -> list[dict[str, Any]] | None:
        """Fetch the recursive git tree for a repo.

        Returns a list of tree node dicts, or ``None`` on failure.
        """
        url = f"/repos/{full_name}/git/trees/{branch}"
        resp = await self._request("GET", url, params={"recursive": "1"})
        if resp.status_code == 404:
            return None
        if resp.status_code == 409:
            # Empty repo or git error
            return None
        resp.raise_for_status()
        data = resp.json()
        if data.get("truncated"):
            log.warning("  [warn] %s tree was truncated by the API", full_name)
        return data.get("tree", [])

    async def _fetch_files(
        self,
        full_name: str,
        branch: str,
        paths: list[str],
    ) -> dict[str, str]:
        """Fetch the decoded UTF-8 content of each file path.

        Skips files that exceed ``max_file_size_bytes`` or are not
        decodable as UTF-8.
        """
        results: dict[str, str] = {}
        # Process sequentially to respect rate limits (these are content
        # fetches and there can be many per repo).
        for path in paths:
            url = f"/repos/{full_name}/contents/{path}"
            resp = await self._request(
                "GET", url, params={"ref": branch}
            )
            if resp.status_code != 200:
                continue

            data = resp.json()

            # Size gate
            size = data.get("size", 0)
            if size > self.max_file_size_bytes:
                log.debug(
                    "  [skip file] %s/%s -- %d KB > %d KB",
                    full_name,
                    path,
                    size // 1024,
                    self.max_file_size_kb,
                )
                continue

            content_b64 = data.get("content")
            if not content_b64:
                continue

            try:
                content = base64.b64decode(content_b64).decode("utf-8")
            except (UnicodeDecodeError, ValueError):
                continue

            results[path] = content

        return results

    async def _fetch_readme(
        self,
        full_name: str,
        branch: str,
        tree_paths: list[str],
    ) -> str:
        """Attempt to fetch the repo README, trying common filenames."""
        candidates = [
            p
            for p in tree_paths
            if p.lower() in (
                "readme.md",
                "readme.rst",
                "readme.txt",
                "readme",
            )
        ]
        if not candidates:
            return ""

        # Use the first match (prefer .md)
        candidates.sort(key=lambda p: (not p.lower().endswith(".md"), p))
        path = candidates[0]

        url = f"/repos/{full_name}/contents/{path}"
        resp = await self._request("GET", url, params={"ref": branch})
        if resp.status_code != 200:
            return ""

        data = resp.json()
        content_b64 = data.get("content")
        if not content_b64:
            return ""

        try:
            return base64.b64decode(content_b64).decode("utf-8")
        except (UnicodeDecodeError, ValueError):
            return ""

    # -- Save ---------------------------------------------------------------

    def save_repo(self, data: dict[str, Any]) -> None:
        """Write the repo JSON to ``data/raw/{owner}__{name}.json``.

        Also updates the internal scraped set and persists the checkpoint.
        """
        full_name: str = data["repo"]
        owner, name = full_name.split("/", 1)
        filename = f"{owner}__{name}.json"
        out_path = self.output_dir / filename

        with open(out_path, "w", encoding="utf-8") as fh:
            json.dump(data, fh, ensure_ascii=False, indent=2)

        self._scraped_repos.add(full_name)
        self._total_saved += 1
        self.save_checkpoint()

        log.info(
            "  [saved] %s  (%d files, %d tests) -- total %d",
            full_name,
            len(data["files"]),
            len(data["test_files"]),
            self._total_saved,
        )

    # -- Orchestration ------------------------------------------------------

    async def run(self) -> None:
        """Main entry point: search, fetch, and save repos."""
        self.load_checkpoint()

        repos = await self.search_repos()
        if not repos:
            log.info("No new repos to process.")
            return

        log.info("Processing %d repos ...", len(repos))

        for idx, repo_meta in enumerate(repos, 1):
            full_name = repo_meta["full_name"]
            if full_name in self._scraped_repos:
                continue

            if self._total_saved >= self.max_repos:
                log.info("Reached max_repos limit (%d). Stopping.", self.max_repos)
                break

            log.info(
                "[%d/%d] Fetching %s  (stars=%s) ...",
                idx,
                len(repos),
                full_name,
                repo_meta.get("stargazers_count", "?"),
            )

            try:
                content = await self.fetch_repo_content(repo_meta)
            except Exception:
                log.exception("  [error] Failed to fetch %s", full_name)
                # Record it so we don't retry on resume
                self._scraped_repos.add(full_name)
                self.save_checkpoint()
                continue

            if content is None:
                # Quality gate failed -- record and move on
                self._scraped_repos.add(full_name)
                self.save_checkpoint()
                continue

            self.save_repo(content)

        log.info("Done. %d repos saved in total.", self._total_saved)

    async def close(self) -> None:
        """Shut down the HTTP client."""
        if self._client and not self._client.is_closed:
            await self._client.aclose()


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------


def _resolve_project_root() -> Path:
    """Walk up from this file to find the project root.

    The project root is identified as the directory containing
    ``tools/dataset/config.yaml``.  Falls back to CWD if not found.
    """
    candidate = Path(__file__).resolve().parent.parent.parent
    if (candidate / "tools" / "dataset" / "config.yaml").exists():
        return candidate
    return Path.cwd()


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Scrape GitHub repos for the KORE fine-tuning dataset."
    )
    parser.add_argument(
        "--config",
        type=str,
        default=None,
        help="Path to config.yaml (default: tools/dataset/config.yaml relative to project root)",
    )
    args = parser.parse_args()

    project_root = _resolve_project_root()

    if args.config:
        config_path = Path(args.config)
    else:
        config_path = project_root / "tools" / "dataset" / "config.yaml"

    config = load_config(config_path)
    scraper = GitHubScraper(config, project_root)

    async def _run() -> None:
        try:
            await scraper.run()
        finally:
            await scraper.close()

    asyncio.run(_run())


if __name__ == "__main__":
    main()
