# WordPress Template

Pre-configured WordPress setup with:
- Docker Compose (WordPress + MySQL + phpMyAdmin)
- WooCommerce for e-commerce
- SSL with Let's Encrypt
- Automated backups

## Quick Start
```bash
docker-compose up -d
```
