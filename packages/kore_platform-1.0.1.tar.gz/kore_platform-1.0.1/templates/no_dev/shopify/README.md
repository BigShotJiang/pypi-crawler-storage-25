# Shopify Template

Shopify theme and configuration with:
- Custom Liquid theme
- Product catalog structure
- Payment configuration
- Shipping zones

## Setup
Configure your Shopify store credentials in `.env`
