# Static Site Template

Modern static site with:
- HTML5 + TailwindCSS
- Responsive design
- Contact form (Formspree)
- SEO meta tags
- Deploy to Netlify/Vercel

## Quick Start
```bash
npm install && npm run dev
```
