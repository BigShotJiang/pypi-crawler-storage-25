# Event-Driven Template

Enterprise event-driven architecture with:
- CQRS pattern
- Event Sourcing
- Saga orchestration
- Eventual consistency
- Event store (PostgreSQL)
- Message broker (Kafka/RabbitMQ)
- Read model projections
- Idempotent event handlers
- Full audit trail

## Quick Start
```bash
make infra-up
make migrate
make run
```
