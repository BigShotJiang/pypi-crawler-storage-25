# Hexagonal Python Template

Enterprise-grade Python project with:
- Hexagonal Architecture (Ports & Adapters)
- Domain-Driven Design (tactical patterns)
- Immutable entities (frozen dataclasses)
- Type safety (mypy strict)
- Structured logging (structlog)
- OpenTelemetry tracing
- Prometheus metrics
- 95%+ test coverage
- GitHub Actions CI/CD
- Docker + Kubernetes manifests
- Threat model documentation
- Architecture Decision Records (ADRs)

## Quick Start
```bash
pip install -e ".[dev]"
make test
make lint
```
