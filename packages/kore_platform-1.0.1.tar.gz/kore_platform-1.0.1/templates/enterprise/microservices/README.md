# Microservices Template

Enterprise microservices architecture with:
- Service mesh (Istio)
- API Gateway
- Event bus (Kafka/Redis Streams)
- Service discovery
- Circuit breaker pattern
- Distributed tracing
- Centralized logging
- Helm charts
- ArgoCD GitOps
- Chaos engineering tests

## Quick Start
```bash
make infra-up
make deploy-all
```
