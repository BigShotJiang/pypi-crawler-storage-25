# FastAPI Template

Production-ready FastAPI project with:
- SQLAlchemy + Alembic migrations
- JWT authentication
- Pydantic schemas
- Docker + docker-compose
- pytest + coverage
- OpenAPI docs auto-generated
- GitHub Actions CI/CD

## Quick Start
```bash
pip install -e ".[dev]"
alembic upgrade head
uvicorn app.main:app --reload
```
