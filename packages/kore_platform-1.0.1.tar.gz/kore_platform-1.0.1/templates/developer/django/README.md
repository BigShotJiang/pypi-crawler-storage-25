# Django Template

Production-ready Django project with:
- Django REST Framework
- PostgreSQL + Redis
- Celery for async tasks
- JWT authentication
- Docker + docker-compose
- pytest + factory_boy
- GitHub Actions CI/CD

## Quick Start
```bash
pip install -e ".[dev]"
python manage.py migrate
python manage.py runserver
```
