# Express.js Template

Production-ready Express project with:
- TypeScript
- Prisma ORM
- JWT authentication
- Zod validation
- Jest tests
- Docker
- Swagger docs

## Quick Start
```bash
npm install
npm run dev
```
