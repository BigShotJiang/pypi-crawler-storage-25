# Next.js Template

Production-ready Next.js project with:
- TypeScript
- TailwindCSS
- Prisma ORM
- NextAuth.js
- Jest + Testing Library
- Docker
- Vercel deployment

## Quick Start
```bash
npm install
npm run dev
```
