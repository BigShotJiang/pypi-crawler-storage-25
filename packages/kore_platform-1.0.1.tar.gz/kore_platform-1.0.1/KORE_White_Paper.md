# KORE Platform — White Paper

**Automatic software generation through AI agent orchestration**

Version 1.0 | February 2026 | IAFiscal

---

## Table of Contents

1. [Executive Summary](#1-executive-summary)
2. [The Problem](#2-the-problem)
3. [The Solution: KORE](#3-the-solution-kore)
4. [System Architecture](#4-system-architecture)
5. [Generation Pipeline](#5-generation-pipeline)
6. [The 10 Specialized Agents](#6-the-10-specialized-agents)
7. [Intelligent Interview System](#7-intelligent-interview-system)
8. [Self-Validation Loop](#8-self-validation-loop)
9. [Few-Shot Learning](#9-few-shot-learning)
10. [Security: AEGIS Guardian](#10-security-aegis-guardian)
11. [Tiered Delivery Model](#11-tiered-delivery-model)
12. [User Interface](#12-user-interface)
13. [Privacy: 100% Local Execution](#13-privacy-100-local-execution)
14. [Technology Stack](#14-technology-stack)
15. [Performance and Metrics](#15-performance-and-metrics)
16. [Use Cases](#16-use-cases)
17. [Comparison with Alternatives](#17-comparison-with-alternatives)
18. [Known Limitations](#18-known-limitations)
19. [Roadmap](#19-roadmap)
20. [Installation and Usage](#20-installation-and-usage)
21. [License and Distribution](#21-license-and-distribution)

---

## 1. Executive Summary

KORE Platform is an automatic software generation system that transforms an idea expressed in natural language into a complete, functional project: source code, tests, documentation, deployment configuration, and security scans.

The system orchestrates 10 specialized artificial intelligence agents through a configurable pipeline. Each agent masters one aspect of software development — from requirements analysis to production monitoring — and their artifacts flow between them in a chained fashion, with each phase building upon the previous one.

**Core value proposition:** A user enters a sentence describing what they need. KORE generates a complete project, attempts to validate it by running generated tests against the code, and if it detects failures, retries automatically. The result is a structured starting point that requires human review, not a finished product.

**Key differentiators:**

- **100% local execution.** No servers, no accounts, no personal data in the cloud. The user installs the package and everything runs on their machine.
- **LLM provider agnostic.** Works with Ollama (free, local), OpenAI, or Anthropic. The user chooses.
- **Self-validation.** KORE doesn't just generate code — it executes it, detects errors, and automatically corrects them up to 3 times.
- **Adaptation to technical level.** A restaurant owner with no programming knowledge and a senior engineer receive different deliverables, adapted to their context.

---

## 2. The Problem

### 2.1 The gap between idea and execution

Modern software development is a process that requires multiple coordinated disciplines: requirements analysis, architecture design, implementation, testing, documentation, security, and deployment. Even for an experienced developer, creating a project from scratch involves hours of repetitive work before writing the first line of business logic.

For a non-developer — an entrepreneur, a business manager, a professional from another sector — this barrier is insurmountable. They have the idea, but not the technical knowledge to materialize it.

### 2.2 Limitations of current tools

Existing AI code generation tools present several problems:

| Problem | Description |
|---------|-------------|
| **Fragmented code** | They generate isolated functions, not complete projects |
| **No validation** | Generated code frequently doesn't compile or has errors |
| **No context** | They don't understand implicit domain requirements |
| **Cloud dependency** | They require sending code and data to external servers |
| **Single model** | Tied to a specific AI provider |
| **No adaptation** | They treat a beginner the same as a senior |

### 2.3 The cost of boilerplate

Industry studies estimate that between 40% and 60% of development time on a new project is spent on repetitive tasks: environment configuration, folder structure, framework boilerplate, test setup, Docker configuration, CI/CD, and basic documentation. KORE eliminates this burden entirely.

---

## 3. The Solution: KORE

KORE (Knowledge-Orchestrated Runtime Engine) is a software generation platform that addresses each of these problems systematically.

### 3.1 Design principles

1. **One idea, one complete project.** The input is a sentence. The output is a directory with all the files needed to run the project.

2. **Specialized agents, not a monolithic model.** Instead of asking a single LLM to do everything, KORE breaks the work down into 10 agents, each with prompts optimized for their domain.

3. **Chained artifacts.** Each agent receives the artifacts from the previous one. The architect builds on the requirements. The coder builds on the architecture. The tests are based on the code. This chain guarantees coherence.

4. **Real validation.** KORE executes the generated tests against the generated code. If they fail, it re-invokes the coder agent with the errors so it can fix them. Up to 3 automatic attempts.

5. **Privacy by default.** Everything runs locally. There is no central server. There is no telemetry. No data is sent anywhere except to the LLM that the user configures.

6. **User adaptation.** KORE detects the user's technical level and adapts the execution plan, interview questions, and delivery format.

### 3.2 General flow

```
  User's idea
       |
       v
  [Interview] --- Detects level, generates questions, enriches context
       |
       v
  [Planning] --- Generates plan with N steps based on level
       |
       v
  [Execution] --- 10 agents in sequence/parallel
       |
       v
  [Validation] --- Runs tests, automatically fixes errors
       |
       v
  [Delivery] --- Workspace with complete project
```

---

## 4. System Architecture

### 4.1 Hexagonal Architecture

KORE implements a hexagonal architecture (ports & adapters) with three well-defined layers:

```
+----------------------------------------------------------+
|                    DOMAIN (core)                           |
|  Entities: Job, UserContext, Flow, Agent, Step             |
|  Value Objects: JobId, TechnicalLevel, ExecutionResult     |
|  Events: JobCreated, AgentStarted, StepCompleted          |
|  Services: InterviewService                               |
+----------------------------------------------------------+
|                   APPLICATION                              |
|  Inbound Ports: ExecuteJob, Interview                      |
|  Outbound Ports: LLMClient, Storage, MessageBus, Audit    |
|  Use Cases: ExecuteJobUseCase, InterviewUseCase            |
|  DTOs: JobResultDTO, DeliveryDTO, InterviewDTO             |
+----------------------------------------------------------+
|                 INFRASTRUCTURE                             |
|  LLM Adapters: Ollama, OpenAI, Anthropic                  |
|  Storage: FileStorage, PostgresStorage                     |
|  Bus: MemoryBus, RedisBus                                  |
|  Security: Guardian, SandboxManager, SignatureVerifier      |
|  Observability: Logging, Metrics, Tracing, Health          |
|  Config: Settings (immutable), Container (DI)              |
+----------------------------------------------------------+
```

### 4.2 Immutability as a principle

All domain data structures are immutable (`frozen=True`, `slots=True`). This includes:

- **UserContext**: the user's state after the interview
- **Plan** and **PlanStep**: the execution plan
- **ExecutionResult** and **StepResult**: results of each step
- **JobId**: unique identifier for each job
- **GuardianResult**: result of security validations

Immutability guarantees that no component can accidentally alter the state of another, eliminating an entire class of bugs related to shared state.

### 4.3 Dependency Injection

The `Container` centralizes the creation of all components with lazy initialization. Components are created only when needed:

- **Message bus:** MemoryBus in development, RedisBus in production
- **Audit log:** Append-only, immutable, verifiable
- **LLM Client:** Automatic selection based on `KORE_LLM_PROVIDER`
- **Agent Registry:** 10 agents with automatically injected LLM
- **Workspace Manager:** Management of working directories per job

### 4.4 Directory structure

```
kore-platform/
  src/kore_platform/
    agents/                     # 10 agents, 29 skills
      base/                     # Abstractions: BaseAgent, BaseSkill, few_shot
      examples/                 # Few-shot examples to improve quality
      specs/architect/coder/    # Specialized agents
      tester/reviewer/security/
      deployer/documenter/monitor/complexity/
    application/                # Application layer
      dto/                      # Data transfer objects
      ports/inbound/outbound/   # Hexagonal ports
      use_cases/                # Use cases
    domain/                     # Domain core
      entities/                 # Job, UserContext, Flow, Agent, Step
      events/                   # Domain events
      exceptions/               # Typed exceptions
      services/                 # Domain services
      value_objects/            # Immutable value objects
    infrastructure/             # Concrete adapters
      adapters/inbound/         # CLI, API
      adapters/outbound/        # LLM clients, storage, bus
      config/                   # Settings, Container DI
      observability/            # Logging, metrics, tracing
      security/                 # Guardian, sandbox, crypto
      workspace/                # Workspace management
    orchestration/              # Execution engine
      orchestrator.py           # Main orchestrator
      validation_loop.py        # Self-validation loop
      subprocess_runner.py      # Subprocess execution
      flow_engine.py            # YAML flow engine
      parallel_executor.py      # Parallel execution
    interview/                  # Interview system
      interviewer.py            # Interview orchestrator + LLM
      level_detector.py         # Level detection + LLM
      context_builder.py        # Context building + LLM
      plan_generator.py         # Plan generation
      question_selector.py      # Question selection
    delivery/                   # Delivery packaging
    web.py                      # Local web interface
    cli.py                      # CLI entry point
  tests/                        # 131 tests
  flows/                        # YAML definitions
  questions/                    # Question banks
```

---

## 5. Generation Pipeline

### 5.1 Pipeline phases

The KORE pipeline has 6 main phases:

**Phase 1: Job Creation**
A `Job` entity is created with state `CREATED`. Each job has a unique `JobId` (UUID). The job transitions through immutable states: CREATED -> INTERVIEWING -> PLANNING -> AWAITING_CONFIRMATION -> EXECUTING -> DELIVERING -> COMPLETED.

**Phase 2: Interview**
The interview system detects the user's technical level, selects relevant questions, collects answers (via LLM or demo mode), and builds an immutable `UserContext` with all the necessary information.

**Phase 3: Planning**
The `PlanGenerator` creates an immutable `Plan` with N steps based on the technical level. Each step specifies: agent, skill, description, inputs, timeout, retries, and parallel execution group.

**Phase 4: Execution**
The `Orchestrator` executes each step of the plan:
- Validates the action with the Guardian
- Enriches inputs with artifacts from previous steps
- Invokes the real agent (or stub in demo mode)
- Writes generated files to the workspace
- Publishes events to the message bus

**Phase 5: Validation**
After executing all steps, if there is generated code and tests, the `ValidationLoop` runs them. If the tests fail, it re-invokes the coder with the errors. Up to 3 attempts.

**Phase 6: Delivery**
The `DeliveryFactory` creates the appropriate delivery based on the technical level (Simple, Technical, or Enterprise) and packages everything into an immutable DTO.

### 5.2 Artifact flow between agents

Artifacts flow between agents automatically through the input enrichment system:

```
specs:analyze_requirements  ->  "requirements"  ->  architect:design_architecture
architect:design_architecture  ->  "architecture"  ->  coder:implement_feature
coder:implement_feature  ->  "files", "code"  ->  tester:write_unit_tests
tester:write_unit_tests  ->  "test_files"  ->  tester:run_tests
coder + tester  ->  validation_loop  ->  corrected code
```

This chaining ensures that each agent works with the full context of what previous agents have produced.

### 5.3 Parallel execution

Certain steps can be executed in parallel when they have no dependencies between them. KORE groups these steps using `parallel_group`:

- **Group "review":** code_review + security_review + complexity:analyze_structure (simultaneous). For ENGINEER level, also complexity:detect_bottlenecks.
- **Group "security":** sast_scan + dependency_scan (simultaneous)

The `ParallelExecutor` uses `asyncio.gather` with a configurable semaphore to control maximum concurrency.

---

## 6. The 10 Specialized Agents

Each agent inherits from `BaseAgent` and registers its skills. They all follow the same pattern: they receive inputs + context, call the LLM with specialized prompts, and return structured artifacts.

### 6.1 Specs Agent
**Role:** Requirements analyst
**Skills:** `analyze_requirements`, `generate_user_stories`

Extracts from natural text: functional requirements, non-functional requirements, domain entities, suggested technology stack, and priorities. Produces a structured JSON that feeds the architect.

### 6.2 Architect Agent
**Role:** Software architect
**Skills:** `design_architecture`, `generate_schemas`, `create_api_spec`

Designs the system structure: components, patterns (MVC, hexagonal, CQRS), data models, API specification (endpoints, methods, request/response schemas). Decides folder and module organization.

### 6.3 Coder Agent
**Role:** Senior developer
**Skills:** `implement_feature`, `refactor`, `write_code`

Generates complete source code, file by file. Each file includes correct imports, type hints, docstrings, and complete functional logic. Uses few-shot examples to improve output quality. Supports correction mode: if it receives `fix_errors`, it adjusts the code to resolve reported failures.

### 6.4 Tester Agent
**Role:** QA engineer
**Skills:** `write_unit_tests`, `write_integration_tests`, `run_tests`

Generates unit tests with pytest, including fixtures, mocks, and assertions. The `run_tests` skill executes real tests via subprocess against the generated code, returning real exit_code, stdout, and stderr.

### 6.5 Reviewer Agent
**Role:** Code reviewer
**Skills:** `code_review`, `performance_review`, `security_review`

Analyzes the generated code looking for: code smells, SOLID principle violations, performance issues, security vulnerabilities, and improvement opportunities.

### 6.6 Security Agent
**Role:** Security engineer
**Skills:** `sast_scan`, `dependency_scan`, `secret_scan`

Runs static security analysis: detects SQL injections, XSS, dependency vulnerabilities, and hardcoded secrets in the code.

### 6.7 Deployer Agent
**Role:** DevOps engineer
**Skills:** `deploy_staging`, `deploy_production`, `rollback`

Generates deployment configuration: multi-stage Dockerfile, docker-compose, Kubernetes manifests (for ENGINEER level), and CI/CD scripts.

### 6.8 Documenter Agent
**Role:** Technical writer
**Skills:** `generate_docs`, `generate_manual`, `generate_video_script`

Produces complete documentation: project README, architecture document, API reference, configuration guide, and user manual.

### 6.9 Monitor Agent
**Role:** Observability engineer
**Skills:** `setup_monitoring`, `create_alerts`, `analyze_metrics`

Configures health checks, Prometheus metrics, alerts, and dashboards. Only activated for ENGINEER level.

### 6.10 ComplexityAgent

**Role:** Structural complexity analyzer
**Skills:** `analyze_structure`, `detect_bottlenecks`
**Requires LLM:** No — deterministic CPU-only analysis
**Dependency:** `qubit-algebra` (optional)

The only agent that does not use an LLM. It analyzes the dependency graph of generated code using Clifford algebra (via the `qal` library).

**analyze_structure:**
1. Parses Python files with `ast.parse` (not regex) to extract internal imports
2. Builds a dependency graph between project modules
3. Computes metrics via `qal.GraphAlgebra.structural_complexity()`:
   - Cyclomatic complexity (independent paths)
   - Entanglement (0.0 = decoupled, 1.0 = everything depends on everything)
   - Dependency depth
   - Cycle count (circular dependencies)
4. Assigns an A/B/C/D/F rating with configurable thresholds
5. Generates warnings about circular dependencies and highly coupled modules

**detect_bottlenecks** (ENGINEER only):
1. Uses `qal.GraphAlgebra.pigeonhole_analysis()` to detect overloaded nodes
2. Cross-references with ArchitectAgent output: a "database" module with many dependents is expected; a "utils" module with the same pattern is problematic
3. Generates recommendations: module splitting, connection pooling, etc.

**Fallback:** If `qubit-algebra` is not installed, the agent uses basic cycle detection via DFS and dependency counting. KORE works without this dependency.

| Level | analyze_structure | detect_bottlenecks |
|-------|:-:|:-:|
| NO_DEV | — | — |
| DEV_JUNIOR | — | — |
| DEV_SENIOR | Yes | — |
| ENGINEER | Yes | Yes |

---

## 7. Intelligent Interview System

### 7.1 Technical level detection

KORE automatically classifies the user into 4 levels:

| Level | Description | Example idea |
|-------|-------------|--------------|
| **NO_DEV** | No technical knowledge | "I need an app for my restaurant" |
| **DEV_JUNIOR** | Knows basic concepts | "A task CRUD with React and Node" |
| **DEV_SENIOR** | Uses advanced patterns | "REST API with FastAPI, PostgreSQL, Redis, JWT auth" |
| **ENGINEER** | Enterprise architecture | "Event-driven platform with CQRS, Kafka, K8s, mTLS" |

Detection works in two layers:

1. **LLM (primary):** If an LLM is available, it classifies the message with a specialized prompt. Fast and accurate.
2. **Heuristic (fallback):** Counts discriminative terms by vocabulary. Each level has a set of ~40 terms. If the LLM is unavailable, this heuristic decides.

### 7.2 Answer collection modes

KORE supports three modes for collecting interview answers:

| Mode | Class | Activation | Description |
|------|-------|-----------|-------------|
| **Interactive CLI** | `CLIAnswerProvider` | Default | User answers each question via keyboard |
| **Interactive Web** | `WebAnswerProvider` | Web UI | Answers collected via web form |
| **Auto (LLM)** | `LLMAutoAnswerProvider` | `--auto` flag | LLM simulates the user's answers |

**Interactive mode (default):** KORE detects the technical level, selects appropriate questions, and presents them to the user one by one. Real user answers produce much more accurate context than auto-generated ones.

**Auto mode:** The `LLMAutoAnswerProvider` simulates the user using the LLM. Instead of generic hardcoded answers, it generates contextual answers based on the original idea. This produces richer contexts than static demo answers, but auto-generated answers may not reflect the user's real needs.

The `answer_source` field in `UserContext` tracks the origin: `"user"` (interactive), `"llm_auto"` (auto-mode), `"demo"` (hardcoded), or `"stub"` (empty).

### 7.3 Context enrichment

The `ContextBuilder` uses the LLM to infer implicit requirements that the user didn't mention but are necessary:

- If the idea mentions "API", the LLM infers that authentication, input validation, and error handling are needed.
- If it mentions "e-commerce", it infers that payment management, inventory, and notifications are needed.

Inferred requirements are merged with explicit ones, producing a more complete `UserContext`.

### 7.4 Adaptive plan generation

The execution plan adapts to the technical level:

| Level | Steps | Includes |
|-------|-------|----------|
| NO_DEV | 3 | Specs + Architecture + Code |
| DEV_JUNIOR | 5 | + Tests + Docs |
| DEV_SENIOR | 8 | + Review + Security Review + Deploy + Run Tests |
| ENGINEER | 10 | + SAST + Monitoring + Deploy |

---

## 8. Self-Validation Loop

### 8.1 The quality problem

LLMs generate code that looks correct but frequently has subtle errors: imports that don't exist, misspelled variables, functions that don't respect the expected signature. Without validation, these errors go unnoticed until a human tries to execute the code.

### 8.2 The solution: test-driven auto-correction

KORE implements an automatic validation loop:

```
+----> Write files to workspace
|      |
|      v
|    pip install dependencies
|      |
|      v
|    pytest --tb=short
|      |
|   +--+--+
|   |     |
|  PASS  FAIL
|   |     |
|   v     v
|  OK   Coder receives errors
|        "Fix these failures: ..."
|        |
+--------+  (up to 3 attempts)
```

### 8.3 Components

**SubprocessRunner:** Executes external commands asynchronously with `asyncio.create_subprocess_exec`. Configurable timeout. Full stdout/stderr capture. Robust error and timeout handling.

**ValidationLoop:** Orchestrates the complete cycle:

1. Writes code and test files to the workspace
2. Generates a `requirements-test.txt` with minimal dependencies
3. Installs dependencies in `.deps/` (isolated from the system)
4. Runs `pytest` with `PYTHONPATH` pointing to the workspace
5. If tests pass: returns success
6. If they fail: extracts up to 4000 characters of errors, prioritizing error lines (ImportError, AssertionError, etc.) and passes them to the Coder Agent as `fix_errors`
7. The Coder regenerates the code with the error context
8. Repeats up to 3 times

### 8.4 Error injection in the prompt

When the ValidationLoop detects failures, it adds to the coder's prompt:

```
IMPORTANT: The previous code had these test failures:
[stderr output, smart-extracted up to 4000 chars]

Fix ALL errors. Make sure imports are correct, all referenced
modules exist, and the code passes tests.
```

This gives the LLM concrete context about what to fix, instead of regenerating blindly.

---

## 9. Few-Shot Learning

### 9.1 Why few-shot

LLMs dramatically improve their output when shown a concrete example of the expected format. Without an example, they tend to generate incomplete code, with placeholders, or with incorrect structure.

### 9.2 Implementation

KORE includes two curated examples:

**fastapi_crud.txt:** A complete FastAPI project with 6 functional files:
- `main.py` with startup event and router
- `database.py` with SQLAlchemy async
- `models.py` with SQLAlchemy model
- `schemas.py` with Pydantic v2
- `routes.py` with complete CRUD (5 endpoints)
- `pyproject.toml` with correct dependencies

**pytest_example.txt:** A complete test suite:
- `conftest.py` with async fixtures, test session, and dependency override
- `test_items.py` with 5 real tests (create, list, get, update, delete)

### 9.3 Integration

The `build_few_shot_prompt()` function concatenates the example to the system prompt:

```
[Original system prompt]

--- EXAMPLE OUTPUT (follow this format) ---
[Example content]
--- END EXAMPLE ---
```

The example is truncated to 3000 characters to avoid exceeding the context window. The Coder and Tester skills use these examples automatically.

---

## 10. Security: AEGIS Guardian

### 10.1 Zero-Trust Model

KORE implements a Guardian that validates ALL actions before their execution. No agent is trusted by default.

### 10.2 Validations

**Commands:** Only commands from a whitelist are allowed: `python`, `pip`, `git`, `npm`, `docker`, `pytest`, etc. Any other command is blocked.

**Dangerous patterns:** Patterns such as the following are detected and blocked:
- `rm -rf /`, `sudo`, `chmod 777`
- `curl | bash`, `eval(`, `exec(`, `__import__`
- `DROP TABLE`, `TRUNCATE TABLE`
- `subprocess.call`, `os.system`

**Paths:** Only access to controlled directories is allowed: `/workspace/`, `/tmp/kore/`, `/home/kore/`.

**Agent inputs:** Each agent's inputs are scanned against the same dangerous patterns.

### 10.3 Audit trail

Each validation is recorded in an immutable (append-only) audit log. The complete history of allowed and blocked actions can be queried.

### 10.4 Cryptographic signature

YAML flows can be cryptographically signed. The `SignatureVerifier` verifies the signature before executing a flow, ensuring it has not been modified.

### 10.5 Threat model

The Guardian operates under an explicit threat model documented in the source code (`guardian.py`):

| Adversary | Likelihood | Description | Mitigation |
|-----------|-----------|-------------|------------|
| Prompt injection | High | Crafted user input causing dangerous code | Pattern matching + obfuscation regex + resource limits |
| Hostile LLM output | Medium | LLM hallucinates dangerous constructs | Same as adversary 1 + trivial test detection |
| Supply-chain via pip | Medium | requirements.txt with malicious packages | `--only-binary :all:` (fallback to sdist with warning) |
| Path traversal / symlink | Low | Paths escaping the workspace | `check_symlink_escape()` + path resolution |
| DoS via exhaustion | Medium | Infinite loops, fork bombs, allocations | `resource.setrlimit` + subprocess timeouts |

**Known gaps:** No container-level sandbox (nsjail/bubblewrap planned for v1.1). Pattern matching is bypassable by creative obfuscation. The sdist fallback still executes setup.py (logged as warning).

### 10.6 CSRF protection in the Web UI

The web API implements double CSRF defense:

1. **CSRF Token:** Each server instance generates a unique token (`secrets.token_urlsafe`). Every POST requires an `X-KORE-Token` header.
2. **Origin validation:** If the browser sends an `Origin` header, it is verified to be localhost (`127.0.0.1` or `localhost`). Requests from other origins are rejected with 403.

---

## 11. Tiered Delivery Model

### 11.1 SimpleDelivery (NO_DEV)

For users without technical knowledge. Generates:
- Basic HTML mockup
- Feature summary
- Simple usage instructions

### 11.2 TechnicalDelivery (DEV_JUNIOR / DEV_SENIOR)

For developers. Generates:
- Complete project structure
- Source code with imports, types, docstrings
- Unit tests with pytest
- Dockerfile and docker-compose
- Technical documentation (README, architecture, API reference)
- Browsable workspace at `/tmp/kore/workspace/<project>/`

### 11.3 EnterpriseDelivery (ENGINEER)

For senior engineers. Everything above plus:
- Security scan results (SAST)
- Monitoring and health check configuration
- CI/CD pipeline
- Compliance documentation
- Kubernetes manifests

---

## 12. User Interface

### 12.1 CLI (Command Line Interface)

```bash
kore "Build a REST API for managing books with FastAPI"
```

For developers who prefer the terminal. Shows step-by-step progress, generated files, and total time.

### 12.2 Local Web UI

```bash
kore --ui
```

Opens a browser with a modern web interface at `http://localhost:8080`. Designed for non-technical users:

- Two-step flow: first the user enters their idea, then KORE presents interview questions adapted to their technical level
- Form with idea field, project name, and logo URL
- Dynamic interview questions (vary based on detected level)
- "Generate Project" button that sends idea + answers
- Progress bar with automatic polling
- List of generated files with sizes
- Modern aesthetics (dark theme, gradients, responsive)

**No external dependencies.** The HTML, CSS, and JavaScript are embedded in the Python server. Nothing is loaded from CDNs or external servers.

### 12.3 REST API

For programmatic integrations:

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/health` | GET | Service status |
| `/api/v1/interview` | POST | Detects level and returns questions |
| `/api/v1/generate` | POST | Launches job in background |
| `/api/v1/jobs/{id}` | GET | Job status |
| `/api/v1/jobs/{id}/files` | GET | Generated files |

Jobs run in the background with `asyncio.create_task` and are queried by polling. In-memory storage (MVP).

---

## 13. Privacy: 100% Local Execution

### 13.1 Philosophy

KORE was designed with a fundamental principle: **the user's data never leaves their machine without their explicit consent.**

### 13.2 No central server

There is no centralized KORE server. There are no user accounts. There is no registration. There is no telemetry. The package is installed via `pip install kore-platform` and everything runs locally.

### 13.3 The user controls the LLM

With Ollama, even the LLM calls are local. The model runs on the user's CPU/GPU. No data leaves the machine.

With OpenAI or Anthropic, calls go to their respective APIs under the user's terms with those providers. KORE does not intermediate or store these communications.

### 13.4 No personal data

The local web UI does not ask for name, email, or any personal data. Only the project idea. There are no cookies, no tracking, no analytics.

### 13.5 Important warnings

- **With OpenAI/Anthropic:** The project idea, interview context, and ALL generated code are sent to their APIs. There is no additional encryption beyond TLS. Review their data retention policies.
- **With Ollama:** Everything is local, but 7B models generate lower quality code than GPT-4o or Claude. It is a trade-off between privacy and quality.
- **Auto-generated context:** When KORE uses `LLMAutoAnswerProvider`, the LLM invents context (target users, business requirements) that may not reflect the user's reality. This is indicated with `answer_source: "llm_auto"` in the UserContext.
- **No real telemetry:** KORE does not have an opt-in telemetry system implemented. Quality metrics are not measured in production. Performance claims are estimated, not measured.

---

## 14. Technology Stack

### 14.1 Core

| Component | Technology | Justification |
|-----------|-----------|---------------|
| Language | Python 3.11+ | Native async, type hints, LLM ecosystem |
| Validation | Pydantic v2 | Immutable schemas, high performance |
| HTTP Client | httpx | Async, modern, HTTP/2 support |
| Logging | structlog | Structured JSON, efficient filtering |
| Config | YAML + env vars | Flexibility without complexity |
| Build | Hatchling | PEP 517, fast, PyPI compatible |

### 14.2 LLM Adapters

| Provider | Adapter | Protocol |
|----------|---------|----------|
| Ollama | `OllamaClient` | HTTP REST (localhost) |
| OpenAI | `OpenAIClient` | REST API + httpx async |
| Anthropic | `AnthropicClient` | REST API + httpx async |

All implement `LLMClientPort` with two methods: `chat()` and `structured_output()`.

### 14.2.1 Optional dependencies

| Package | Usage | Group |
|---------|-------|-------|
| `qubit-algebra` | Graph analysis with Clifford algebra (ComplexityAgent) | `analysis` |
| `transformers`, `peft`, `trl`, `datasets`, `bitsandbytes`, `accelerate` | LoRA/QLoRA fine-tuning | `training` |

### 14.3 Web UI

| Component | Technology |
|-----------|-----------|
| Backend | FastAPI |
| Server | Uvicorn |
| Frontend | Embedded HTML/CSS/JS (no frameworks) |
| Jobs | asyncio.create_task (in-memory) |

### 14.4 Testing

| Tool | Usage |
|------|-------|
| pytest | Test framework |
| pytest-asyncio | Async tests |
| pytest-cov | Code coverage |
| ruff | Linting and formatting |
| mypy (strict) | Type checking |

---

## 15. Performance and Metrics

### 15.1 Framework tests

- **131 tests** passing (of the KORE framework, not of the generated code)
- **Test execution time:** < 0.3 seconds
- The tests verify KORE's infrastructure, not the quality of the code it generates

> **Important:** The success rate of generated projects has not been formally measured. KORE's tests verify that the pipeline works, not that the output is correct. The quality of generated code depends on the LLM model and the complexity of the idea.

### 15.2 Generation times (estimated, not verified)

| Level | Steps | Estimated time (Ollama 7B, CPU) | Estimated time (GPT-4o) |
|-------|-------|----------------------------------|--------------------------|
| NO_DEV | 3 | ~5-15 min | ~2-5 min |
| DEV_JUNIOR | 5 | ~10-25 min | ~4-10 min |
| DEV_SENIOR | 8 | ~15-40 min | ~6-15 min |
| ENGINEER | 10 | ~20-60 min | ~8-20 min |

The ranges are wide because they depend on: hardware, LLM model, idea complexity, and number of validation loop retries. On CPU (without GPU), Ollama can be very slow.

### 15.3 Package size

- **Wheel:** ~100 KB (Python only, no models)
- **Required dependencies:** pydantic, pyyaml, httpx, structlog
- **Optional dependencies:** fastapi + uvicorn (for web UI)

### 15.4 Generated code quality (honestly)

The quality of generated code varies dramatically depending on:

| Factor | Impact |
|--------|--------|
| LLM model | 7B local: ~30-40% usable. GPT-4o: ~60-70% usable |
| Idea complexity | Simple CRUD: high. Distributed system: low |
| Few-shot match | If the idea matches an example: notable improvement |
| Validation loop | Fixes import/syntax errors, not logic errors |

"Usable" means: the code runs, tests pass, and the structure is reasonable. It does NOT mean: production-ready, secure, or performant.

---

## 16. Use Cases

### 16.1 Entrepreneur with no technical knowledge

*"I need an app to manage reservations for my restaurant."*

KORE detects NO_DEV level, generates 3 steps (specs + architecture + code), and delivers a basic project with web interface and reservation management. The entrepreneur receives a directory ready to upload to a hosting service.

### 16.2 Junior developer learning

*"A task management system with React and FastAPI."*

KORE detects DEV_JUNIOR level, generates 5 steps that include tests and documentation. The junior receives well-structured code with tests that can be studied as a reference for best practices.

### 16.3 Development team accelerating prototyping

*"Payment processing API with PostgreSQL, Redis, JWT auth, Docker."*

KORE detects DEV_SENIOR level, generates 8 steps with code review, security review, and Docker configuration. The team receives a functional prototype they can iterate on instead of starting from scratch.

### 16.4 Architect validating a design

*"Event-driven platform with CQRS, Kafka, Kubernetes, mTLS, distributed tracing."*

KORE detects ENGINEER level, generates 10 steps with SAST scanning, monitoring, and K8s manifests. The architect receives a reference implementation that validates their design before committing team resources.

### 16.5 Professor in a programming course

Uses KORE to generate example projects that students can study, modify, and extend. Each project comes with tests that serve as an executable specification.

---

## 17. Comparison with Alternatives

> **Honesty note:** KORE is a v1.0 project in its initial phase. The tools listed below have teams of hundreds of engineers, millions of users, and years of iteration. This comparison reflects differences in approach, not maturity.

| Feature | KORE | GitHub Copilot | Cursor | ChatGPT | Devin |
|---------|------|----------------|--------|---------|-------|
| Complete project | Partial* | No (lines) | No (files) | Partial | Yes |
| Self-validation | Basic** | No | No | No | Advanced |
| Local execution | Yes | No | No | No | No |
| Total privacy | With Ollama*** | No | No | No | No |
| LLM agnostic | Yes | No (Codex) | Partial | No (GPT) | No |
| Level adaptation | Yes | No | No | No | No |
| Generated tests | Yes (variable quality) | No | Partial | Partial | Yes |
| Web UI included | Basic | N/A (IDE plugin) | Yes (IDE) | Yes | Yes |
| Price | Free (MIT) | $10/mo | $20/mo | $20/mo | $500/mo |
| Open source | Yes | No | No | No | No |
| Maturity | v1.0 alpha | Production | Production | Production | Beta |
| Community | Nascent | Millions | Millions | Millions | Thousands |

**Unique differentiator:** KORE is the only platform that includes structural complexity analysis based on graph algebra. The ComplexityAgent uses Clifford algebra to calculate module entanglement, detect circular dependencies, and evaluate the architectural quality of generated code — all without LLM, on pure CPU.

\* KORE generates complete projects but the code quality depends heavily on the LLM model used. With small models (7B), the code frequently has errors that self-validation attempts to correct.

\** The self-validation loop runs tests and re-invokes the coder, but it does not have access to a full real environment (no Docker, no DB). The success rate of automatic correction has not been formally measured.

\*** With Ollama, everything is local. With OpenAI/Anthropic, the project idea and generated code are sent to their APIs.

---

## 18. Known Limitations

This section documents the current limitations of KORE v1.0. Transparency about these limitations is fundamental to setting correct expectations.

### 18.1 Generated code quality

- **Generated code is NOT production-ready.** It is a starting point that requires human review.
- With small models (7B), import, type, and logic errors are frequent.
- The self-validation loop corrects syntax and import errors, but does NOT detect logic errors, race conditions, or security vulnerabilities.
- Tests generated by KORE tend to be superficial (happy path). Trivial test detection (`assert True`) partially mitigates this.

### 18.2 Guardian security

- The Guardian uses pattern matching (regex + lists), not semantic analysis. An attacker with prompt access could evade the filters with creative obfuscation.
- There is no real sandboxing (no Docker, no seccomp, no namespaces). The `resource.setrlimit` calls limit consumption but not isolation.
- `pip install --only-binary` prevents execution of malicious `setup.py` files, but does not cover wheels with C extensions.
- Generated code scanning looks for known patterns. Subtle vulnerabilities (logic bugs, IDOR, timing attacks) are not detected.

### 18.3 Self-validation loop

- Only works for Python projects with pytest.
- Does not have access to databases, external services, or Docker. Tests that require these resources fail silently.
- Error truncation to 4000 chars may lose critical context in long logs.
- Does not distinguish between errors in the generated code and environment errors (pip failures, version incompatibilities).

### 18.3.1 ComplexityAgent

- The ComplexityAgent only analyzes Python projects (`ast.parse`). Code generated in other languages is not analyzed.
- `qubit-algebra` is an optional dependency. Without it, the agent uses a basic fallback (DFS cycle detection, no entanglement calculation).
- The rating thresholds (A/B/C/D/F) are heuristic and may not reflect the real complexity perceived by a developer.

### 18.4 Interview and context

- In `--auto` mode, the `LLMAutoAnswerProvider` invents context that the user did not provide. It may generate requirements, target users, and preferences that do not reflect reality.
- Heuristic technical level detection can produce false positives (keywords in incorrect context, mitigated with word boundary regex).
- Interactive mode (CLI and web) depends on the user providing useful answers. Empty or terse answers produce poor context.
- The web answer matching (`WebAnswerProvider`) uses key-based text search, which may fail if keys don't match exactly.

### 18.5 Few-shot and prompts

- Only 5 examples (fastapi_crud, pytest, cli_tool, etl_pipeline, python_library). Projects outside these categories have no relevant example.
- Prompts are in English (the LLM generates better code that way), but a Spanish-speaking user may find the English comments in generated code confusing.
- `max_tokens=16384` in implement_feature allows medium-sized projects. Very complex projects (>15 files with dense logic) may still fall short. With small models (7B), effective generation may be significantly lower than the configured max_tokens — many 7B models degrade output quality beyond ~8K tokens even if their advertised context window is larger.

### 18.6 Scalability

- Jobs in memory: if the process dies, all in-progress jobs are lost.
- There is no state persistence. There is no job queue. There are no distributed workers.
- A single job consumes all LLM capacity. There is no queueing or rate limiting.

### 18.7 Framework testing

- The 131 tests verify the infrastructure, not the output quality.
- There are no integration tests with a real LLM (they would cost money per CI run).
- There are no formal benchmarks for generated code quality.
- Real coverage not measured (80% target is aspirational).

### 18.8 Observability

- No opt-in telemetry is implemented. It is unknown how many projects are generated, how many fail, or why.
- Token cost tracking is estimated (based on a 4 chars/token rule), not precise.
- There are no real Prometheus metrics. Only a basic `/health` endpoint.

---

## 19. Roadmap

### v1.0 (Current — with limitations documented in section 18)
- 10 specialized agents with 29 skills
- Structural complexity analysis (ComplexityAgent, no LLM)
- Complete pipeline: idea -> functional project
- Self-validation loop with auto-correction
- Few-shot learning for code quality
- LLM-powered interview with 3 modes (interactive CLI, web, auto)
- Local web UI with interview flow
- Direct CLI with interactive mode
- Explicit threat model (5 documented adversaries)
- CSRF protection + Origin validation in web
- Internationalization (Spanish + English)
- Fine-tune pipeline: dataset curation (GitHub scraper + quality filter + ComplexityAgent analysis + pair extraction), LoRA training, GGUF quantization, `kore --setup` distribution
- Settings hierarchy: env vars > `~/.kore/config.yaml` > defaults
- 174 tests

### v1.1 (Planned)
- Process isolation via nsjail/bubblewrap for generated code execution
- Multi-language support (TypeScript, Go, Rust)
- Customizable project templates
- LLM result caching to save tokens
- Automatic GitHub export

### v1.2 (Planned)
- Plugin system for custom agents
- IDE integration (VS Code extension)
- Generation metrics dashboard
- Multi-service project support

### v2.0 (Vision)
- Collaborative agents with shared memory
- Conversational iteration ("Now add authentication to it")
- Real automatic deployment (Vercel, Railway, AWS)
- Community agent marketplace

---

## 20. Installation and Usage

### 20.1 Requirements

- Python 3.11 or higher
- An LLM provider (Ollama recommended for local use)

### 20.2 Installation

```bash
pip install kore-platform
```

For the web interface:
```bash
pip install kore-platform[web]
```

For everything (web + LLM APIs + observability):
```bash
pip install kore-platform[all]
```

### 20.3 LLM Configuration

**Ollama (recommended, free, local):**
```bash
# Install Ollama from https://ollama.com
ollama pull qwen2.5-coder:7b-instruct

export KORE_LLM_PROVIDER=ollama
export KORE_LLM_MODEL=qwen2.5-coder:7b-instruct
```

**OpenAI:**
```bash
export KORE_LLM_PROVIDER=openai
export KORE_LLM_MODEL=gpt-4o
export KORE_LLM_API_KEY=sk-...
```

**Anthropic:**
```bash
export KORE_LLM_PROVIDER=anthropic
export KORE_LLM_MODEL=claude-sonnet-4-5-20250929
export KORE_LLM_API_KEY=sk-ant-...
```

### 20.4 CLI Usage

```bash
kore "Build a REST API for managing books with FastAPI"
```

### 20.5 Web UI Usage

```bash
kore --ui
```

It automatically opens `http://localhost:8080` in the browser.

### 20.6 Complete environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| `KORE_LLM_PROVIDER` | `ollama` | Provider: ollama, openai, anthropic |
| `KORE_LLM_MODEL` | `qwen2.5-coder:7b-instruct` | Model to use |
| `KORE_LLM_BASE_URL` | `http://localhost:11434` | LLM server URL |
| `KORE_LLM_API_KEY` | — | API key (OpenAI/Anthropic) |
| `KORE_LLM_TIMEOUT` | `600` | Timeout per LLM call (seconds) |
| `KORE_WORKSPACE_PATH` | `/tmp/kore/workspace` | Output directory |
| `KORE_VALIDATION_MAX_RETRIES` | `3` | Auto-correction attempts |
| `KORE_VALIDATION_TIMEOUT` | `120` | Validation timeout (seconds) |
| `KORE_ENVIRONMENT` | `development` | Environment |
| `KORE_LANG` | `es` | Language: es (Spanish) or en (English) |
| `KORE_LOG_LEVEL` | `INFO` | Logging level |

---

## 21. License and Distribution

### 21.1 License

KORE Platform is distributed under the **MIT** license. This allows:

- Unrestricted commercial use
- Free modification and redistribution
- Inclusion in proprietary products
- No obligation to publish changes

### 21.2 Repository

GitHub: `https://github.com/iafiscal1212/kore-platform`

### 21.3 Distribution

- **PyPI:** `pip install kore-platform`
- **Source code:** Clone repository
- **Wheel:** Available in GitHub releases

---

## Appendix A: Glossary

| Term | Definition |
|------|-----------|
| **Agent** | AI component specialized in one aspect of development |
| **Skill** | Specific ability of an agent (e.g.: `implement_feature`) |
| **Artifact** | Output of an agent that is passed to the next one (e.g.: code, tests) |
| **Pipeline** | Sequence of steps in the execution plan |
| **Job** | Complete execution of an idea, from start to finish |
| **UserContext** | Immutable user state after the interview |
| **Plan** | Sequence of steps to execute (immutable) |
| **Guardian** | Security component that validates all actions |
| **Workspace** | Directory where generated files are written |
| **Few-shot** | Concrete example included in the prompt to improve quality |
| **Self-validation** | Automatic test execution with auto-correction |
| **Delivery** | Final project packaging adapted to the user's level |

---

## Appendix B: Main Class Diagram

```
BaseAgent (ABC)
  |-- SpecsAgent
  |-- ArchitectAgent
  |-- CoderAgent
  |-- TesterAgent
  |-- ReviewerAgent
  |-- SecurityAgent
  |-- DeployerAgent
  |-- DocumenterAgent
  |-- MonitorAgent
  |-- ComplexityAgent

BaseSkill (ABC)
  |-- ImplementFeatureSkill
  |-- WriteUnitTestsSkill
  |-- RunTestsSkill
  |-- DesignArchitectureSkill
  |-- ... (29 skills total)

LLMClientPort (ABC)
  |-- OllamaClient
  |-- OpenAIClient
  |-- AnthropicClient

AnswerProvider (ABC)
  |-- CLIAnswerProvider
  |-- WebAnswerProvider
  |-- LLMAutoAnswerProvider

Orchestrator
  |-- uses ValidationLoop
  |-- uses ParallelExecutor
  |-- uses Guardian

ValidationLoop
  |-- uses SubprocessRunner
```

---

*KORE Platform v1.0 — February 2026 — IAFiscal*
*"Describe your idea. Get a complete project. That's it."*
