# Troubleshooting Guide -- Kore Platform

## Quick Diagnostics

### Health Check

```bash
# Check overall system health
curl http://localhost:8000/api/v1/health | jq

# Check Docker containers
docker compose ps

# Check logs (last 100 lines)
docker compose logs kore-platform --tail=100

# Check Redis connectivity
docker compose exec redis redis-cli -a $REDIS_PASSWORD ping
```

---

## Common Issues

### 1. Job Stuck in INTERVIEWING Status

**Symptoms**: Job created but never progresses past interview phase.

**Possible Causes**:
- LLM API key is invalid or expired
- LLM provider is unreachable (network issue)
- Interview mode is not set to demo (`demo_mode=False` but no I/O adapter connected)

**Diagnosis**:
```bash
# Check logs for LLM errors
docker compose logs kore-platform | grep -i "llm\|anthropic\|openai\|error"

# Check if API key is set
docker compose exec kore-platform env | grep KORE_LLM
```

**Resolution**:
1. Verify `KORE_LLM_API_KEY` is set and valid
2. Test LLM connectivity: `curl https://api.anthropic.com/v1/messages -H "x-api-key: $KORE_LLM_API_KEY"`
3. If running in interactive mode, ensure the inbound adapter (CLI/WebSocket) is connected
4. For demos, ensure `Interviewer.demo_mode=True`

---

### 2. Redis Connection Refused

**Symptoms**: `ConnectionRefusedError` or health check shows Redis unhealthy.

**Possible Causes**:
- Redis container is not running
- Wrong hostname or port
- Authentication failure (wrong password)

**Diagnosis**:
```bash
# Check Redis container
docker compose ps redis

# Test connectivity
docker compose exec redis redis-cli -a $REDIS_PASSWORD ping

# Check Redis logs
docker compose logs redis --tail=50
```

**Resolution**:
1. Restart Redis: `docker compose restart redis`
2. Verify `KORE_REDIS_HOST` matches the service name in Docker Compose (typically `redis`)
3. Verify `KORE_REDIS_PASSWORD` matches `REDIS_PASSWORD` in Redis configuration
4. For development, set `KORE_ENVIRONMENT=development` to use `MemoryBus` (no Redis needed)

---

### 3. Guardian Blocking Legitimate Commands

**Symptoms**: Agent actions return `{"status": "blocked", "reason": "Command not whitelisted: ..."}`.

**Possible Causes**:
- Command binary not in the Guardian whitelist
- Input contains a substring matching a dangerous pattern

**Diagnosis**:
```bash
# Check Guardian audit log
docker compose logs kore-platform | grep "guardian_blocked\|BLOCKED"

# Review allowed commands in source
grep -A 10 "_ALLOWED_COMMANDS" src/kore_platform/infrastructure/security/guardian.py
```

**Resolution**:
1. If the command is legitimate, add it to the `_ALLOWED_COMMANDS` frozenset
2. If input triggered a false positive on dangerous patterns, review `_DANGEROUS_PATTERNS` and adjust
3. For development only: set `KORE_GUARDIAN_ENABLED=false` (never in production)

---

### 4. Flow Signature Verification Failed

**Symptoms**: `SignatureVerificationError: Invalid signature: flows/developer_flow.yaml`

**Possible Causes**:
- Flow file was modified after signing
- Signing key mismatch between build time and runtime
- Signature file is missing or corrupted

**Diagnosis**:
```bash
# Check if signature files exist
ls -la flows/signatures/

# Compare signing key
echo $KORE_SIGNING_KEY | sha256sum

# Verify manually
python -c "
from kore_platform.infrastructure.security.signature_verifier import SignatureVerifier
from pathlib import Path
sv = SignatureVerifier(signing_key=b'your-key')
try:
    sv.verify_and_load(Path('flows/developer_flow.yaml'))
    print('OK')
except Exception as e:
    print(f'FAILED: {e}')
"
```

**Resolution**:
1. Re-sign flows with the current key: `python scripts/sign_flows.py`
2. Ensure `KORE_SIGNING_KEY` is the same in build and runtime environments
3. After any flow YAML edit, re-sign before deploying

---

### 5. Audit Log Integrity Failure

**Symptoms**: `verify_integrity()` returns `False` or `AuditLogTamperingError` is raised.

**Possible Causes**:
- Audit log file was manually edited
- Disk corruption
- Concurrent write without proper locking

**Diagnosis**:
```bash
# Check audit log files
ls -la /data/audit/

# Verify a specific job's audit log
python -c "
import asyncio
from kore_platform.infrastructure.adapters.outbound.immutable_audit_log import ImmutableAuditLog
from pathlib import Path
al = ImmutableAuditLog(log_dir=Path('/data/audit'))
print(asyncio.run(al.verify_integrity('JOB_ID_HERE')))
"

# Inspect raw entries
cat /data/audit/JOB_ID_HERE.jsonl | jq -c .
```

**Resolution**:
1. If the log was accidentally modified, restore from backup
2. If no backup exists, the integrity of that job's audit trail is compromised -- document this in the incident report
3. Check disk health: `dmesg | grep -i error`

---

### 6. Agent Sandbox Creation Failed

**Symptoms**: `create_sandbox()` returns error or times out.

**Possible Causes**:
- Docker daemon not running
- Docker socket not mounted in the container
- Resource limits exceeded (too many sandboxes)

**Diagnosis**:
```bash
# Check Docker daemon
docker info

# Check Docker socket mount
docker compose exec kore-platform ls -la /var/run/docker.sock

# List running sandboxes
docker ps --filter "name=kore-"

# Check resource usage
docker stats --no-stream
```

**Resolution**:
1. Ensure Docker daemon is running: `systemctl start docker`
2. Verify Docker socket is mounted in `docker-compose.yml`: `/var/run/docker.sock:/var/run/docker.sock:ro`
3. Clean up stale sandboxes: `docker rm -f $(docker ps -aq --filter "name=kore-")`
4. Increase Docker memory/CPU limits if resource exhausted

---

### 7. Out of Memory in Agent Sandbox

**Symptoms**: Agent returns error with OOM (Out of Memory) or process killed.

**Possible Causes**:
- Agent task generates large data (e.g., large codebase)
- Memory limit too low (default 512 MB)

**Diagnosis**:
```bash
# Check Docker events for OOM kills
docker events --filter "event=oom" --since 1h

# Check container stats
docker stats --no-stream --filter "name=kore-"
```

**Resolution**:
1. Increase sandbox memory in `SandboxManager`: adjust `max_memory_mb` in the permissions config
2. Optimize the agent task to produce smaller intermediate artifacts
3. Split large tasks into smaller sub-tasks in the flow definition

---

### 8. LLM Rate Limiting

**Symptoms**: LLM API returns 429 (Too Many Requests).

**Possible Causes**:
- Too many concurrent agents making API calls
- API key tier has low rate limits

**Diagnosis**:
```bash
docker compose logs kore-platform | grep -i "429\|rate.limit\|too.many"
```

**Resolution**:
1. Reduce parallel agent count in flow definitions
2. Add delays between LLM calls (configure in agent skill settings)
3. Upgrade LLM API plan for higher rate limits
4. Cache LLM responses via `MessageBusPort.cache_set()` to avoid duplicate calls

---

## Log Analysis

### Structured Log Fields

All logs use structured JSON format with consistent fields:

| Field | Description |
|-------|-------------|
| `job_id` | Job UUID for correlation |
| `agent` | Agent name (e.g., `coder`, `tester`) |
| `skill` | Skill name (e.g., `implement_feature`) |
| `status` | Result status |
| `elapsed_ms` | Duration in milliseconds |
| `error` | Error message if applicable |

### Useful Log Queries

```bash
# All errors for a specific job
docker compose logs kore-platform | jq 'select(.job_id == "JOB_ID") | select(.level == "ERROR")'

# Guardian blocks
docker compose logs kore-platform | grep "guardian_blocked"

# Slow operations (>5 seconds)
docker compose logs kore-platform | jq 'select(.elapsed_ms > 5000)'

# Agent execution timeline
docker compose logs kore-platform | grep "skill_start\|skill_done\|skill_error" | sort
```
