# Incident Response Playbook -- Kore Platform

## Severity Levels

| Level | Definition | Response Time | Examples |
|-------|-----------|---------------|----------|
| **SEV-1** | System down. No jobs can execute. Data integrity at risk. | 15 minutes | Redis down + MemoryBus fails, all agent sandboxes crash, audit log corruption |
| **SEV-2** | Major degradation. Jobs fail intermittently or core functionality broken. | 1 hour | LLM provider outage, sandbox creation failures, signature verification failing |
| **SEV-3** | Minor degradation. Non-critical functionality affected. | 4 hours | Slow LLM responses, cache misses, single agent type failing |
| **SEV-4** | Cosmetic or low-impact issue. | 24 hours | Incorrect log formatting, non-critical health check flapping |

## Incident Response Process

```mermaid
flowchart TD
    DETECT["1. DETECT<br/>Alert fires or user reports issue"] --> TRIAGE
    TRIAGE["2. TRIAGE<br/>Assign severity, notify team"] --> INVESTIGATE
    INVESTIGATE["3. INVESTIGATE<br/>Check logs, health, metrics"] --> MITIGATE
    MITIGATE["4. MITIGATE<br/>Apply immediate fix or workaround"] --> RESOLVE
    RESOLVE["5. RESOLVE<br/>Deploy permanent fix"] --> REVIEW
    REVIEW["6. REVIEW<br/>Post-incident review,<br/>update runbooks"]
```

---

## Playbook: Platform Completely Down (SEV-1)

### Indicators
- Health endpoint returns 503 or is unreachable
- All job submissions fail
- No log output from kore-platform container

### Steps

1. **Verify the issue**
   ```bash
   curl -s http://localhost:8000/api/v1/health | jq
   docker compose ps
   docker compose logs kore-platform --tail=20
   ```

2. **Check infrastructure dependencies**
   ```bash
   # Redis
   docker compose exec redis redis-cli -a $REDIS_PASSWORD ping

   # Docker daemon
   docker info > /dev/null 2>&1 && echo "Docker OK" || echo "Docker DOWN"

   # Disk space
   df -h /data
   ```

3. **Attempt restart**
   ```bash
   docker compose restart kore-platform
   sleep 10
   curl -s http://localhost:8000/api/v1/health | jq
   ```

4. **If restart fails, check container logs for crash cause**
   ```bash
   docker compose logs kore-platform --tail=200 | grep -i "error\|fatal\|traceback"
   ```

5. **If Redis is down**
   ```bash
   docker compose restart redis
   # If data corruption:
   docker compose stop redis
   docker volume rm kore-platform_redis-data
   docker compose up -d redis
   ```

6. **Fallback to development mode** (emergency only)
   ```bash
   # Temporarily use MemoryBus (no Redis needed)
   docker compose exec kore-platform bash -c "KORE_ENVIRONMENT=development python -m kore_platform ..."
   ```

---

## Playbook: Audit Log Integrity Failure (SEV-1)

### Indicators
- `verify_integrity()` returns `False`
- `AuditLogTamperingError` in logs
- Hash chain broken at specific entry

### Steps

1. **Identify the affected job**
   ```bash
   grep "chain_broken\|entry_tampered" /data/logs/kore-platform.log
   ```

2. **Isolate the corrupted audit file**
   ```bash
   # Verify all job audit files
   for f in /data/audit/*.jsonl; do
     job_id=$(basename "$f" .jsonl)
     python -c "
   import asyncio
   from kore_platform.infrastructure.adapters.outbound.immutable_audit_log import ImmutableAuditLog
   from pathlib import Path
   al = ImmutableAuditLog(log_dir=Path('/data/audit'))
   ok = asyncio.run(al.verify_integrity('$job_id'))
   print(f'$job_id: {\"OK\" if ok else \"CORRUPTED\"}')"
   done
   ```

3. **Preserve evidence**
   ```bash
   cp -a /data/audit /data/audit-evidence-$(date +%Y%m%d%H%M%S)
   ```

4. **Restore from backup if available**
   ```bash
   # Restore specific job audit file from backup
   cp /backup/audit/JOB_ID.jsonl /data/audit/JOB_ID.jsonl
   ```

5. **If no backup, document the breach** -- The affected job's audit trail is no longer trustworthy. Create a new audit entry noting the integrity failure.

6. **Investigate root cause**
   - Was the file manually edited?
   - Was there a disk error? (`dmesg | grep -i error`)
   - Was there unauthorized access? (Check SSH logs, Docker events)

---

## Playbook: LLM Provider Outage (SEV-2)

### Indicators
- LLM API calls return 5xx errors or timeout
- Jobs stuck in INTERVIEWING or EXECUTING status
- Provider status page confirms outage

### Steps

1. **Confirm provider outage**
   ```bash
   # Test Anthropic
   curl -s https://api.anthropic.com/v1/messages \
     -H "x-api-key: $KORE_LLM_API_KEY" \
     -H "content-type: application/json" \
     -d '{"model":"claude-sonnet-4-5-20250929","max_tokens":10,"messages":[{"role":"user","content":"test"}]}'

   # Check status pages
   # Anthropic: https://status.anthropic.com
   # OpenAI: https://status.openai.com
   ```

2. **Switch to alternative provider**
   ```bash
   # Switch to OpenAI
   docker compose exec kore-platform bash -c "
     export KORE_LLM_PROVIDER=openai
     export KORE_LLM_API_KEY=sk-your-openai-key
     export KORE_LLM_MODEL=gpt-4o
   "
   docker compose restart kore-platform

   # Or switch to local Ollama
   docker compose exec kore-platform bash -c "
     export KORE_LLM_PROVIDER=ollama
     export KORE_LLM_MODEL=llama3:70b
   "
   ```

3. **Retry failed jobs** -- Jobs that failed during the outage can be resubmitted with the same idea.

4. **Monitor recovery** -- Watch the provider status page. Switch back to the primary provider when the outage is resolved.

---

## Playbook: Sandbox Escape Attempt (SEV-1)

### Indicators
- `SandboxEscapeError` in logs
- Guardian blocks with reason "Path not allowed"
- Agent attempts to access files outside `/workspace`
- Unexpected network connections from sandbox containers

### Steps

1. **Immediately destroy all sandboxes**
   ```bash
   docker rm -f $(docker ps -aq --filter "name=kore-")
   ```

2. **Preserve evidence**
   ```bash
   # Save container logs before removal
   for c in $(docker ps -aq --filter "name=kore-"); do
     docker logs "$c" > /data/evidence/container-$c.log 2>&1
   done

   # Save Guardian audit
   docker compose logs kore-platform | grep "guardian_\|BLOCKED\|ESCAPE" > /data/evidence/guardian-audit.log
   ```

3. **Identify the source**
   ```bash
   # Check which agent and skill triggered the escape
   grep "SANDBOX_ESCAPE\|PATH_BLOCKED" /data/evidence/guardian-audit.log

   # Check the originating job
   grep "job_id" /data/evidence/guardian-audit.log | sort -u
   ```

4. **Review the user input** -- Check the original idea that generated the malicious code. This may be a prompt injection attack.

5. **Strengthen Guardian rules** if the attempt was novel
   - Add new patterns to `_DANGEROUS_PATTERNS`
   - Restrict additional paths in `_ALLOWED_PATHS`
   - Consider tightening sandbox network policy

6. **Resume operations** only after confirming the attack vector is mitigated.

---

## Playbook: Privilege Escalation Attempt (SEV-1)

### Indicators
- `PrivilegeEscalationError` in logs
- Guardian blocks `sudo`, `chmod 777`, or similar commands
- Agent attempts to modify read-only filesystem

### Steps

1. **Kill the offending sandbox**
   ```bash
   # Find the sandbox
   docker ps --filter "name=kore-" --format "{{.Names}} {{.Status}}"

   # Kill it
   docker rm -f SANDBOX_ID
   ```

2. **Review Guardian audit trail**
   ```bash
   docker compose logs kore-platform | grep "PRIVILEGE_ESCALATION\|sudo\|chmod"
   ```

3. **Trace the origin** -- Determine if this was caused by:
   - LLM generating unsafe code (prompt engineering issue)
   - Malicious user input (prompt injection)
   - Bug in agent skill implementation

4. **Apply mitigations** and resume.

---

## Post-Incident Review Template

After every SEV-1 or SEV-2 incident, conduct a blameless post-incident review:

### Header

| Field | Value |
|-------|-------|
| Incident ID | INC-YYYY-NNN |
| Date | YYYY-MM-DD |
| Severity | SEV-N |
| Duration | X hours Y minutes |
| Impact | N jobs affected, M users impacted |

### Timeline

| Time (UTC) | Event |
|------------|-------|
| HH:MM | Alert fired / Issue reported |
| HH:MM | Investigation started |
| HH:MM | Root cause identified |
| HH:MM | Mitigation applied |
| HH:MM | Full resolution confirmed |

### Root Cause

(Describe the root cause objectively)

### What Went Well

- (List positives)

### What Could Be Improved

- (List improvements)

### Action Items

| Action | Owner | Due Date | Status |
|--------|-------|----------|--------|
| (Description) | (Name) | YYYY-MM-DD | Open |

---

## Contact Escalation

| Role | Contact | When |
|------|---------|------|
| On-call engineer | (team rotation) | First responder for all incidents |
| Platform lead | (name) | SEV-1 and SEV-2 escalation |
| Security lead | (name) | Any security-related incident |
| Infrastructure | (name) | Docker/Redis/network issues |
