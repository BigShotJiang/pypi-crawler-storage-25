# Deployment Guide -- Kore Platform

## Prerequisites

- Docker 24+ and Docker Compose v2
- Python 3.12+ (for local development)
- Redis 7+ (production; not needed for development mode)
- PostgreSQL 16+ (production; optional for development)
- At least one LLM API key (Anthropic, OpenAI, or Ollama endpoint)

## Environment Variables

All configuration is via environment variables with the `KORE_` prefix.

### Required

| Variable | Description | Example |
|----------|-------------|---------|
| `KORE_LLM_API_KEY` | API key for the configured LLM provider | `sk-ant-...` |
| `KORE_SIGNING_KEY` | HMAC-SHA256 key for YAML flow signatures | `my-secret-signing-key-change-me` |

### Optional

| Variable | Default | Description |
|----------|---------|-------------|
| `KORE_ENVIRONMENT` | `development` | `development`, `staging`, or `production` |
| `KORE_DEBUG` | `false` | Enable debug mode (`true`/`false`) |
| `KORE_GUARDIAN_ENABLED` | `true` | Enable AEGIS Guardian security validation |
| `KORE_LLM_PROVIDER` | `anthropic` | LLM provider: `anthropic`, `openai`, `ollama` |
| `KORE_LLM_MODEL` | `claude-sonnet-4-5-20250929` | Model identifier |
| `KORE_REDIS_HOST` | `localhost` | Redis server hostname |
| `KORE_REDIS_PORT` | `6379` | Redis server port |
| `KORE_REDIS_PASSWORD` | (empty) | Redis password |
| `KORE_STORAGE_TYPE` | `file` | Storage backend: `file` or `postgres` |
| `KORE_STORAGE_PATH` | `/tmp/kore/data` | Base path for file storage and audit logs |
| `KORE_LOG_LEVEL` | `INFO` | Logging level: `DEBUG`, `INFO`, `WARNING`, `ERROR` |
| `KORE_LOG_JSON` | `true` | Output structured JSON logs |
| `KORE_ENABLE_TRACING` | `false` | Enable OpenTelemetry tracing |
| `KORE_OTLP_ENDPOINT` | (empty) | OTLP collector endpoint (e.g., `http://jaeger:4317`) |

## Local Development

### 1. Clone and Install

```bash
git clone https://github.com/iafiscal1212/kore-platform.git
cd kore-platform
python -m venv .venv
source .venv/bin/activate
pip install -e ".[dev]"
```

### 2. Run in Development Mode

Development mode uses `MemoryBus` (no Redis) and `FileStorage` (no PostgreSQL):

```bash
export KORE_ENVIRONMENT=development
export KORE_LLM_API_KEY=sk-ant-your-key-here
export KORE_SIGNING_KEY=dev-signing-key

# Run via CLI
python -m kore_platform.infrastructure.adapters.inbound.cli_adapter "Build a task management app"
```

### 3. Run Tests

```bash
# Unit tests (no external dependencies)
pytest tests/unit/ -v

# Integration tests (may need Redis)
pytest tests/integration/ -v

# Security tests
pytest tests/security/ -v

# Performance tests
pytest tests/performance/ -v

# All tests
pytest tests/ -v --cov=kore_platform
```

## Docker Deployment

### 1. Build the Image

```bash
docker build -t kore-platform:latest .
```

### 2. Docker Compose (Recommended)

Create a `docker-compose.yml`:

```yaml
version: "3.9"

services:
  kore-platform:
    image: kore-platform:latest
    ports:
      - "8000:8000"   # REST API
      - "8001:8001"   # WebSocket
    environment:
      KORE_ENVIRONMENT: production
      KORE_LLM_API_KEY: ${KORE_LLM_API_KEY}
      KORE_LLM_PROVIDER: anthropic
      KORE_SIGNING_KEY: ${KORE_SIGNING_KEY}
      KORE_REDIS_HOST: redis
      KORE_REDIS_PORT: 6379
      KORE_REDIS_PASSWORD: ${REDIS_PASSWORD}
      KORE_STORAGE_TYPE: file
      KORE_STORAGE_PATH: /data
      KORE_LOG_LEVEL: INFO
      KORE_LOG_JSON: "true"
      KORE_GUARDIAN_ENABLED: "true"
    volumes:
      - kore-data:/data
      - /var/run/docker.sock:/var/run/docker.sock:ro
    depends_on:
      redis:
        condition: service_healthy
    restart: unless-stopped
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8000/api/v1/health"]
      interval: 30s
      timeout: 10s
      retries: 3
      start_period: 15s

  redis:
    image: redis:7-alpine
    command: redis-server --requirepass ${REDIS_PASSWORD}
    ports:
      - "6379:6379"
    volumes:
      - redis-data:/data
    healthcheck:
      test: ["CMD", "redis-cli", "-a", "${REDIS_PASSWORD}", "ping"]
      interval: 10s
      timeout: 5s
      retries: 5
    restart: unless-stopped

volumes:
  kore-data:
  redis-data:
```

### 3. Start the Stack

```bash
# Create .env file
cat > .env << 'EOF'
KORE_LLM_API_KEY=sk-ant-your-key-here
KORE_SIGNING_KEY=your-production-signing-key
REDIS_PASSWORD=your-redis-password
EOF

# Sign flow definitions
python -m kore_platform.infrastructure.security.signature_verifier sign

# Start services
docker compose up -d

# Check health
curl http://localhost:8000/api/v1/health
```

### 4. Verify Deployment

```bash
# Check all services are running
docker compose ps

# Check logs
docker compose logs kore-platform --tail=50

# Test job creation
curl -X POST http://localhost:8000/api/v1/jobs \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -d '{"idea": "A simple task management app"}'

# Check health endpoint
curl http://localhost:8000/api/v1/health | jq
```

## Production Considerations

### Health Checks

The `/api/v1/health` endpoint checks all system components:

```json
{
  "status": "healthy",
  "checks": {
    "redis": {"healthy": true, "latency_ms": 1.2, "message": ""},
    "storage": {"healthy": true, "latency_ms": 3.5, "message": ""},
    "audit_log": {"healthy": true, "latency_ms": 0.8, "message": ""}
  }
}
```

Configure your load balancer to probe this endpoint:
- **Interval**: 30 seconds
- **Timeout**: 10 seconds
- **Unhealthy threshold**: 3 consecutive failures
- **Healthy threshold**: 1 success

### Resource Sizing

| Component | CPU | Memory | Disk |
|-----------|-----|--------|------|
| kore-platform | 2 cores | 2 GB | 10 GB (logs + artifacts) |
| redis | 1 core | 512 MB | 1 GB |
| Agent sandbox (each) | 1 core | 512 MB | 1 GB tmpfs |

### Scaling

- **Horizontal**: Run multiple kore-platform instances behind a load balancer. Redis provides shared state.
- **Agent sandboxes**: Each kore-platform instance creates its own sandboxes. Docker limits prevent resource exhaustion.
- **Redis**: Use Redis Sentinel for high availability or Redis Cluster for horizontal scaling.

### Backup Strategy

| Data | Location | Strategy |
|------|----------|----------|
| Audit logs | `/data/audit/*.jsonl` | Daily backup to S3. Never delete. |
| Job artifacts | `/data/storage/artifacts/` | Backup after job completion. Retain 30 days. |
| Flow definitions | `flows/*.yaml` | Version controlled in Git. |
| Redis data | Redis RDB/AOF | Redis persistence with AOF for durability. |

### Security Checklist

- [ ] Change `KORE_SIGNING_KEY` from default
- [ ] Set strong `REDIS_PASSWORD`
- [ ] Ensure `KORE_LLM_API_KEY` is not committed to version control
- [ ] Enable `KORE_GUARDIAN_ENABLED=true` in production
- [ ] Mount Docker socket as read-only (`:ro`)
- [ ] Use TLS for Redis connections in production
- [ ] Configure network policies to isolate agent sandbox network
- [ ] Set resource limits on Docker containers
- [ ] Enable structured JSON logging for log aggregation
- [ ] Verify flow signatures before deployment
