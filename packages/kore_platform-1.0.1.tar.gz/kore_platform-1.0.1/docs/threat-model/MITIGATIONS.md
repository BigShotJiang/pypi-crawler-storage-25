# Security Mitigations -- Kore Platform

## Overview

This document maps security mitigations to the threats identified in the STRIDE threat model and attack trees. Each mitigation is categorized by defense layer and implementation status.

---

## Mitigation Matrix

### Legend

| Status | Meaning |
|--------|---------|
| IMPLEMENTED | Code exists and is active |
| CONFIGURED | Requires deployment configuration |
| RECOMMENDED | Planned or suggested improvement |

---

## 1. Input Validation and Sanitization

### M-1.1: Idea Field Validation

**Threats mitigated**: S-1, E-2, D-1

| Attribute | Value |
|-----------|-------|
| Status | IMPLEMENTED |
| Component | `APIAdapter.create_job()` |
| File | `infrastructure/adapters/inbound/api_adapter.py` |

**Description**: The API adapter validates that the `idea` field is present and non-empty before creating a job. The OpenAPI spec defines `minLength: 10` and `maxLength: 5000` constraints.

**Code reference**:
```python
idea = request.body.get("idea", "")
if not idea:
    return APIResponse(status_code=400, body={"error": "Field 'idea' is required"}, ...)
```

### M-1.2: WebSocket Message Validation

**Threats mitigated**: S-2, T-3

| Attribute | Value |
|-----------|-------|
| Status | IMPLEMENTED |
| Component | `WebSocketAdapter.on_message()` |
| File | `infrastructure/adapters/inbound/websocket_adapter.py` |

**Description**: WebSocket messages are parsed as JSON. Invalid JSON returns an error. Unknown event types are rejected. Only registered handlers process messages.

---

## 2. Authentication and Authorization

### M-2.1: Bearer Token Authentication

**Threats mitigated**: S-1, S-4, B-1

| Attribute | Value |
|-----------|-------|
| Status | CONFIGURED |
| Component | API middleware |
| File | API gateway / reverse proxy |

**Description**: All API endpoints except `/api/v1/health` require a valid Bearer token. Token validation is delegated to the API gateway or middleware.

### M-2.2: Rate Limiting

**Threats mitigated**: D-1, S-4, D-5

| Attribute | Value |
|-----------|-------|
| Status | RECOMMENDED |
| Component | API gateway |

**Description**: Rate limits should be configured per API key:
- Job creation: 10 requests per minute
- Status queries: 60 requests per minute
- WebSocket connections: 5 concurrent per source IP

---

## 3. AEGIS Guardian -- Command and Path Validation

### M-3.1: Command Whitelist

**Threats mitigated**: E-1, E-2, E-3

| Attribute | Value |
|-----------|-------|
| Status | IMPLEMENTED |
| Component | `Guardian.validate_command()` |
| File | `infrastructure/security/guardian.py` |

**Description**: Only whitelisted command binaries are allowed to execute. The whitelist is a `frozenset` (immutable at runtime):

```python
_ALLOWED_COMMANDS = frozenset({
    "python", "python3", "pip", "pip3",
    "git", "npm", "node", "npx",
    "docker", "pytest", "ruff", "black", "mypy",
    "curl", "wget",
})
```

Any command not in this set is blocked with a logged reason.

### M-3.2: Dangerous Pattern Detection

**Threats mitigated**: E-2, E-1

| Attribute | Value |
|-----------|-------|
| Status | IMPLEMENTED |
| Component | `Guardian.validate_command()`, `Guardian.validate_agent_action()` |
| File | `infrastructure/security/guardian.py` |

**Description**: All commands and agent action inputs are scanned for dangerous patterns:

```python
_DANGEROUS_PATTERNS = frozenset({
    "rm -rf /", "rm -rf ~", "rm -rf *",
    "sudo ", "chmod 777",
    "curl | bash", "curl | sh", "wget | bash", "wget | sh",
    "eval(", "exec(", "__import__", "os.system",
    "subprocess.call", "subprocess.run",
    "drop table", "drop database", "truncate table",
})
```

### M-3.3: Path Validation

**Threats mitigated**: E-1, I-3

| Attribute | Value |
|-----------|-------|
| Status | IMPLEMENTED |
| Component | `Guardian.validate_path()` |
| File | `infrastructure/security/guardian.py` |

**Description**: File access is restricted to allowed path prefixes:

```python
_ALLOWED_PATHS = frozenset({
    "/workspace/", "/tmp/kore/", "/home/kore/",
})
```

### M-3.4: Guardian Audit Trail

**Threats mitigated**: R-2, R-1

| Attribute | Value |
|-----------|-------|
| Status | IMPLEMENTED |
| Component | `Guardian._audit()` |
| File | `infrastructure/security/guardian.py` |

**Description**: Every Guardian decision (both ALLOWED and BLOCKED) is recorded in an in-memory audit list with event type, command, and reason. Blocked actions are also logged at WARNING level.

---

## 4. Sandbox Isolation

### M-4.1: Network Isolation

**Threats mitigated**: I-3, E-1, E-2 (IMPACT1, IMPACT3)

| Attribute | Value |
|-----------|-------|
| Status | IMPLEMENTED |
| Component | `SandboxManager.create()` |
| File | `infrastructure/security/sandbox_manager.py` |

**Description**: Agent sandboxes have network disabled by default:

```python
config = {
    "network": False,  # No network by default
    ...
}
```

This prevents data exfiltration, C2 communication, and lateral movement.

### M-4.2: Read-Only Root Filesystem

**Threats mitigated**: E-1 (A3, D2), E-3

| Attribute | Value |
|-----------|-------|
| Status | IMPLEMENTED |
| Component | `SandboxManager.create()` |

**Description**: Sandbox root filesystem is mounted read-only. Only `/workspace` is writable. This prevents modification of system files, creation of symlinks to escape paths, and installation of persistent backdoors.

### M-4.3: Resource Limits

**Threats mitigated**: D-2, D-4, E-2 (IMPACT2)

| Attribute | Value |
|-----------|-------|
| Status | IMPLEMENTED |
| Component | `SandboxManager.create()` |

**Description**: Each sandbox enforces:
- **Memory**: 512 MB maximum
- **CPU time**: 300 seconds maximum
- **Filesystem**: Restricted to `/workspace`

### M-4.4: Sandbox Lifecycle Management

**Threats mitigated**: D-2

| Attribute | Value |
|-----------|-------|
| Status | IMPLEMENTED |
| Component | `SandboxManager.destroy_all()` |

**Description**: All sandboxes are destroyed when a job completes or fails. The `destroy_all()` method cleans up stale sandboxes to prevent resource leaks.

### M-4.5: Docker Socket Read-Only Mount

**Threats mitigated**: E-5

| Attribute | Value |
|-----------|-------|
| Status | CONFIGURED |
| Component | Docker Compose configuration |

**Description**: The Docker socket is mounted with `:ro` (read-only) flag to prevent the platform from creating privileged containers through the socket.

---

## 5. Cryptographic Integrity

### M-5.1: Flow YAML Signature Verification

**Threats mitigated**: T-1

| Attribute | Value |
|-----------|-------|
| Status | IMPLEMENTED |
| Component | `SignatureVerifier.verify_and_load()` |
| File | `infrastructure/security/signature_verifier.py` |

**Description**: YAML flow definitions are signed with HMAC-SHA256 at build time and verified at runtime before loading:

```python
actual_sig = hmac.new(self.signing_key, content, hashlib.sha256).hexdigest()
if not hmac.compare_digest(actual_sig, expected_sig):
    raise SignatureVerificationError(f"Invalid signature: {config_path}")
```

This uses constant-time comparison (`hmac.compare_digest`) to prevent timing attacks.

### M-5.2: Audit Log Hash Chain

**Threats mitigated**: T-2, R-1, R-2

| Attribute | Value |
|-----------|-------|
| Status | IMPLEMENTED |
| Component | `ImmutableAuditLog` |
| File | `infrastructure/adapters/outbound/immutable_audit_log.py` |

**Description**: Each audit entry contains:
- Its own SHA-256 hash (computed over content + previous hash)
- The hash of the previous entry (`prev_hash`)

This creates a chain where modifying any entry breaks the chain for all subsequent entries. `verify_integrity()` walks the chain and detects tampering.

---

## 6. Secret Management

### M-6.1: Environment Variable Secrets

**Threats mitigated**: I-1

| Attribute | Value |
|-----------|-------|
| Status | IMPLEMENTED |
| Component | `SecretManager` |
| File | `infrastructure/security/secret_manager.py` |

**Description**: All secrets use `KORE_` prefixed environment variables. The `SecretManager` provides:
- `get()` -- optional secret with default
- `require()` -- mandatory secret (fails fast if missing)
- `get_all()` -- returns masked values for debugging (`sk-p***`)

### M-6.2: Secret Masking in Logs

**Threats mitigated**: I-1

| Attribute | Value |
|-----------|-------|
| Status | IMPLEMENTED |
| Component | `SecretManager.get_all()` |

**Description**: `get_all()` masks secret values to first 4 characters plus `***`. The `get()` method logs at DEBUG level with only the key name, never the value.

---

## 7. Immutable Domain Model

### M-7.1: Frozen Dataclasses

**Threats mitigated**: T-3, T-4, Race conditions

| Attribute | Value |
|-----------|-------|
| Status | IMPLEMENTED |
| Component | All domain entities and value objects |

**Description**: All domain objects use `@dataclass(frozen=True, slots=True)`. State transitions create new instances. This prevents:
- Race conditions from concurrent access
- Accidental mutation of shared state
- Agents modifying job context or requirements

### M-7.2: Frozen Collections

**Threats mitigated**: E-3 (C1)

| Attribute | Value |
|-----------|-------|
| Status | IMPLEMENTED |
| Component | Guardian, domain entities |

**Description**: Security-critical collections use `frozenset`:
- `_ALLOWED_COMMANDS` -- cannot add entries at runtime
- `_ALLOWED_PATHS` -- cannot add entries at runtime
- `_DANGEROUS_PATTERNS` -- cannot remove entries at runtime
- `UserContext.security_requirements` -- cannot be weakened

---

## 8. Observability and Detection

### M-8.1: Structured JSON Logging

**Threats mitigated**: R-1, R-2 (detection)

| Attribute | Value |
|-----------|-------|
| Status | IMPLEMENTED |
| Component | `setup_logging()` |
| File | `infrastructure/observability/logging.py` |

**Description**: All logs use structured JSON format with consistent fields (`job_id`, `agent`, `skill`, `status`, `elapsed_ms`). This enables:
- Correlation across components by `job_id`
- Automated alerting on patterns (e.g., `guardian_blocked`)
- Log aggregation in ELK/Loki/CloudWatch

### M-8.2: Health Checks

**Threats mitigated**: D-1, D-2, D-3 (detection)

| Attribute | Value |
|-----------|-------|
| Status | IMPLEMENTED |
| Component | `HealthChecker` |
| File | `infrastructure/observability/health.py` |

**Description**: Pluggable health checks monitor all system components with latency measurement. The `/api/v1/health` endpoint exposes per-component status for load balancers and monitoring.

---

## Mitigation Coverage Summary

```mermaid
graph LR
    subgraph Implemented["Implemented (14)"]
        M1_1["Input validation"]
        M1_2["WS validation"]
        M3_1["Cmd whitelist"]
        M3_2["Pattern detection"]
        M3_3["Path validation"]
        M3_4["Guardian audit"]
        M4_1["Network isolation"]
        M4_2["Read-only root"]
        M4_3["Resource limits"]
        M4_4["Sandbox lifecycle"]
        M5_1["Flow signatures"]
        M5_2["Hash chain audit"]
        M6_1["Env var secrets"]
        M6_2["Secret masking"]
    end

    subgraph Configured["Configured (2)"]
        M2_1["Bearer auth"]
        M4_5["Docker socket RO"]
    end

    subgraph Recommended["Recommended (5)"]
        M2_2["Rate limiting"]
        M_TLS["Redis TLS"]
        M_SECCOMP["Seccomp profiles"]
        M_ROOTLESS["Rootless Docker"]
        M_ROTATE["Key rotation"]
    end
```

## Recommended Improvements

| Priority | Mitigation | Threat | Effort |
|----------|-----------|--------|--------|
| HIGH | Implement API rate limiting | D-1, S-4 | Medium |
| HIGH | Enable Redis TLS | I-2 | Low |
| HIGH | Add seccomp profiles to sandboxes | E-1, C-1, C-2 | Medium |
| MEDIUM | Implement signing key rotation | E-4 | Medium |
| MEDIUM | Add artifact integrity checksums | T-4 | Low |
| MEDIUM | Persist Guardian audit to disk | R-2 | Low |
| MEDIUM | Add user identity to audit entries | R-1 | Low |
| LOW | Switch to rootless Docker | E-5 | High |
| LOW | Add WebSocket connection limits | D-5 | Low |
| LOW | Encrypt audit log entries at rest | I-4 | Medium |
