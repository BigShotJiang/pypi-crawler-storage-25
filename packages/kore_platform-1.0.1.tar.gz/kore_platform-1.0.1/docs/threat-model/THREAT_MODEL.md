# STRIDE Threat Model -- Kore Platform

## Overview

This document applies the STRIDE methodology to the Kore Platform, identifying threats across all system boundaries and components. The analysis covers the unique threat landscape of an AI-powered code generation and execution platform.

## System Boundaries

```mermaid
graph TB
    subgraph EXTERNAL["External (Untrusted)"]
        USER["Users<br/>(No-Dev / Dev / Engineer)"]
        LLM["LLM Providers<br/>(Anthropic / OpenAI / Ollama)"]
    end

    subgraph DMZ["DMZ"]
        API["REST API :8000"]
        WS["WebSocket :8001"]
    end

    subgraph CORE["Trusted Core"]
        ENGINE["Core Engine"]
        GUARD["AEGIS Guardian"]
        AUDIT["Audit Log"]
    end

    subgraph SANDBOX["Sandboxed (Least Privilege)"]
        AGENTS["Agent Containers"]
    end

    subgraph DATA["Data Stores"]
        REDIS["Redis"]
        STORAGE["File/PostgreSQL"]
    end

    USER -->|"B1"| API
    USER -->|"B1"| WS
    LLM -->|"B2"| ENGINE
    API -->|"B3"| ENGINE
    ENGINE -->|"B4"| AGENTS
    ENGINE -->|"B5"| REDIS
    ENGINE -->|"B5"| STORAGE
    ENGINE -->|"B6"| AUDIT
```

**Trust Boundaries**:
- **B1**: Internet to DMZ -- untrusted user input
- **B2**: External LLM to Core -- AI-generated content (potentially adversarial)
- **B3**: DMZ to Core -- validated input crossing into trusted zone
- **B4**: Core to Sandbox -- commands sent to isolated containers
- **B5**: Core to Data Stores -- state persistence
- **B6**: Core to Audit Log -- tamper-evident logging

---

## STRIDE Analysis

### S -- Spoofing

| ID | Threat | Boundary | Component | Impact |
|----|--------|----------|-----------|--------|
| S-1 | Attacker impersonates legitimate user | B1 | API/WebSocket | Unauthorized job creation, access to job results |
| S-2 | Attacker spoofs WebSocket connection ID | B1 | WebSocket Adapter | Intercept interview answers, inject responses |
| S-3 | Agent spoofs another agent's identity on message bus | B4/B5 | Message Bus | Execute actions with wrong agent permissions |
| S-4 | Attacker replays captured API request | B1 | API Adapter | Duplicate job execution, resource exhaustion |

**Existing Mitigations**:
- Bearer token authentication on API endpoints
- WebSocket connection tracking by ID
- Agents publish events with their registered name, enforced by `BaseAgent`

**Gaps**:
- No mutual TLS between agents and message bus
- No request signing/nonce for replay prevention

---

### T -- Tampering

| ID | Threat | Boundary | Component | Impact |
|----|--------|----------|-----------|--------|
| T-1 | Modify YAML flow definitions to skip security scans | B3 | Flow Engine | Deploy unreviewed/insecure code |
| T-2 | Tamper with audit log to hide malicious activity | B6 | Audit Log | Loss of forensic evidence |
| T-3 | Modify agent skill outputs in message bus | B5 | Redis Bus | Corrupt execution results |
| T-4 | Tamper with stored job artifacts | B5 | File Storage | Deliver modified code to user |
| T-5 | Modify environment variables to change LLM provider or model | Host | Settings | Redirect prompts to malicious endpoint |

**Existing Mitigations**:
- **T-1**: HMAC-SHA256 signature verification on YAML flows (`SignatureVerifier`)
- **T-2**: Hash chain in audit log (`ImmutableAuditLog`) detects any modification
- **T-5**: Settings loaded from env vars at startup, frozen after (`@dataclass(frozen=True)`)

**Gaps**:
- T-3: Redis messages are not signed or encrypted
- T-4: File storage does not include integrity checksums

---

### R -- Repudiation

| ID | Threat | Boundary | Component | Impact |
|----|--------|----------|-----------|--------|
| R-1 | User denies submitting a malicious idea | B1 | API | Cannot attribute prompt injection attacks |
| R-2 | Agent denies executing a destructive action | B4 | Agent | Cannot trace responsibility |
| R-3 | Operator denies modifying flow definition | Host | Flow Files | Cannot trace configuration changes |

**Existing Mitigations**:
- **R-1/R-2**: Immutable audit log records every job event with timestamps and hash chain
- **R-2**: Guardian logs all validation decisions (allowed and blocked)
- **R-3**: Flow signatures ensure only holders of the signing key can produce valid flows

**Gaps**:
- No user identity in audit log entries (jobs are currently anonymous)
- Guardian audit is in-memory, not persisted independently

---

### I -- Information Disclosure

| ID | Threat | Boundary | Component | Impact |
|----|--------|----------|-----------|--------|
| I-1 | LLM API key leaked in logs | Host | SecretManager | Financial damage, API abuse |
| I-2 | User ideas/requirements exposed via Redis | B5 | Redis Bus | Privacy violation |
| I-3 | Source code from agent sandbox exfiltrated | B4 | Sandbox | IP theft |
| I-4 | Audit log entries contain sensitive business data | B6 | Audit Log | Privacy violation |
| I-5 | Error messages reveal internal architecture | B1 | API Adapter | Aids attacker reconnaissance |

**Existing Mitigations**:
- **I-1**: `SecretManager` never logs full values (masks to first 4 chars)
- **I-3**: Sandbox network disabled by default; read-only root filesystem
- **I-5**: API returns generic error messages in production

**Gaps**:
- I-2: Redis data is not encrypted at rest or in transit (without TLS)
- I-4: Audit log stores job data in plaintext JSONL files

---

### D -- Denial of Service

| ID | Threat | Boundary | Component | Impact |
|----|--------|----------|-----------|--------|
| D-1 | Submit many large ideas to exhaust LLM tokens | B1 | API | Financial exhaustion, slow response |
| D-2 | Create many sandboxes to exhaust Docker resources | B4 | SandboxManager | Agent execution blocked |
| D-3 | Flood Redis with pub/sub messages | B5 | Redis Bus | Memory exhaustion, other services affected |
| D-4 | Generate large artifacts to fill disk | B4 | File Storage | All jobs fail |
| D-5 | Slow loris attack on WebSocket connections | B1 | WebSocket | Connection pool exhausted |

**Existing Mitigations**:
- **D-2**: Sandbox resource limits (512 MB memory, 300s CPU)
- **D-2**: `destroy_all()` cleanup method

**Gaps**:
- D-1: No rate limiting on API endpoints (noted in OpenAPI spec but not implemented)
- D-3: No Redis maxmemory configuration enforced
- D-4: No disk quota per job
- D-5: No WebSocket connection limits or timeouts

---

### E -- Elevation of Privilege

| ID | Threat | Boundary | Component | Impact |
|----|--------|----------|-----------|--------|
| E-1 | Agent escapes sandbox to access host filesystem | B4 | Docker Runtime | Full host compromise |
| E-2 | Prompt injection causes LLM to generate code with `os.system()` | B2 | LLM Client | Arbitrary code execution |
| E-3 | Agent modifies Guardian whitelist at runtime | B4 | Guardian | Bypass all security controls |
| E-4 | Attacker gains access to signing key | Host | SignatureVerifier | Modify flows, skip security scans |
| E-5 | Container escape via Docker socket access | B4 | Docker Runtime | Full host compromise |

**Existing Mitigations**:
- **E-1**: Sandbox network isolation, read-only root, path restrictions
- **E-2**: Guardian pattern matching blocks `os.system`, `subprocess.call`, `eval()`, `exec()`
- **E-3**: Guardian whitelist is a frozen set (immutable in production)
- **E-5**: Docker socket mounted read-only (`:ro`)

**Gaps**:
- E-1: Docker escape CVEs may bypass container isolation
- E-2: Pattern matching cannot catch all obfuscated malicious code
- E-4: Signing key stored in plain environment variable

---

## Risk Matrix

```mermaid
quadrantChart
    title Threat Risk Assessment
    x-axis Low Likelihood --> High Likelihood
    y-axis Low Impact --> High Impact
    quadrant-1 Manage closely
    quadrant-2 Monitor
    quadrant-3 Accept
    quadrant-4 Mitigate promptly
    S-1: [0.6, 0.7]
    T-1: [0.3, 0.9]
    T-2: [0.2, 0.95]
    I-1: [0.4, 0.8]
    I-2: [0.5, 0.6]
    D-1: [0.7, 0.5]
    D-2: [0.5, 0.7]
    E-1: [0.3, 0.95]
    E-2: [0.7, 0.8]
    E-5: [0.2, 0.99]
```

## Priority Threats

Ranked by risk (likelihood x impact):

1. **E-2**: Prompt injection leading to code execution -- HIGH likelihood, HIGH impact
2. **E-1**: Sandbox escape -- LOW likelihood, CRITICAL impact
3. **D-1**: API abuse / financial exhaustion -- HIGH likelihood, MEDIUM impact
4. **I-1**: API key leakage -- MEDIUM likelihood, HIGH impact
5. **T-1**: Flow tampering -- LOW likelihood, HIGH impact (mitigated by signatures)
