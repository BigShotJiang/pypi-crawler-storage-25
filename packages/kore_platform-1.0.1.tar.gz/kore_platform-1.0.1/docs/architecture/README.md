# Kore Platform Architecture Overview

## Introduction

Kore Platform is an AI-powered software development orchestration system that transforms ideas into deployed applications. The platform interviews users, generates execution plans, and coordinates specialized AI agents to produce production-ready code, tests, documentation, and deployments.

The system is built on **hexagonal architecture** (ports and adapters) with strict immutability guarantees, event-driven communication, and defense-in-depth security.

## High-Level Architecture

```mermaid
graph TB
    subgraph External["External Actors"]
        U_NODEV["No-Dev User"]
        U_DEV["Developer User"]
        U_ENG["Engineer User"]
    end

    subgraph Inbound["Inbound Adapters"]
        CLI["CLI Adapter"]
        API["REST API Adapter"]
        WS["WebSocket Adapter"]
    end

    subgraph Core["Core Engine"]
        subgraph Application["Application Layer"]
            UC_EXEC["ExecuteJobUseCase"]
            UC_INT["InterviewUseCase"]
            UC_PLAN["CreatePlanUseCase"]
            UC_DEL["DeliverResultUseCase"]
        end

        subgraph Domain["Domain Layer"]
            E_JOB["Job Entity"]
            E_FLOW["Flow Entity"]
            E_AGENT["Agent Entity"]
            E_STEP["Step Entity"]
            E_CTX["UserContext"]
            VO["Value Objects"]
            EVT["Domain Events"]
        end

        subgraph Interview["Interview System"]
            INT["Interviewer"]
            LD["LevelDetector"]
            QS["QuestionSelector"]
            CB["ContextBuilder"]
        end
    end

    subgraph Outbound["Outbound Adapters"]
        REDIS["Redis Bus"]
        MEM["Memory Bus"]
        LLM_A["Anthropic Client"]
        LLM_O["OpenAI Client"]
        LLM_L["Ollama Client"]
        DOCK["Docker Runtime"]
        FC["Firecracker Runtime"]
        FS["File Storage"]
        PG["PostgreSQL Storage"]
        AUDIT["Immutable Audit Log"]
    end

    subgraph Security["Security Layer (AEGIS)"]
        GUARD["Guardian"]
        SIG["Signature Verifier"]
        SAND["Sandbox Manager"]
        SEC["Secret Manager"]
    end

    subgraph Agents["Agent Sandboxes"]
        A_SPEC["Specs Agent"]
        A_ARCH["Architect Agent"]
        A_CODE["Coder Agent"]
        A_TEST["Tester Agent"]
        A_REV["Reviewer Agent"]
        A_SEC["Security Agent"]
        A_DEP["Deployer Agent"]
        A_DOC["Documenter Agent"]
        A_MON["Monitor Agent"]
    end

    U_NODEV --> CLI
    U_DEV --> API
    U_ENG --> WS

    CLI --> UC_EXEC
    API --> UC_EXEC
    WS --> UC_EXEC

    UC_EXEC --> UC_INT
    UC_EXEC --> UC_PLAN
    UC_EXEC --> UC_DEL

    UC_INT --> INT
    INT --> LD
    INT --> QS
    INT --> CB

    UC_EXEC --> E_JOB
    UC_EXEC --> E_FLOW
    E_JOB --> VO
    E_JOB --> EVT

    UC_EXEC --> REDIS
    UC_EXEC --> MEM
    UC_EXEC --> AUDIT

    UC_EXEC --> GUARD
    GUARD --> SAND
    SIG --> E_FLOW

    SAND --> DOCK
    SAND --> FC

    A_SPEC --> LLM_A
    A_ARCH --> LLM_A
    A_CODE --> LLM_O
    A_TEST --> LLM_L

    UC_DEL --> FS
    UC_DEL --> PG
```

## Hexagonal Architecture

The platform follows a strict hexagonal (ports and adapters) architecture. The domain and application layers have zero dependencies on infrastructure concerns.

```mermaid
graph LR
    subgraph Driving["Driving Side (Inbound)"]
        CLI["CLI Adapter"]
        API["REST API"]
        WS["WebSocket"]
    end

    subgraph Ports_In["Inbound Ports"]
        P_EXEC["ExecuteJobPort"]
        P_INT["InterviewPort"]
    end

    subgraph App["Application Core"]
        UC["Use Cases"]
        DOM["Domain Model"]
    end

    subgraph Ports_Out["Outbound Ports"]
        P_BUS["MessageBusPort"]
        P_LLM["LLMClientPort"]
        P_RT["AgentRuntimePort"]
        P_STORE["StoragePort"]
        P_AUDIT["AuditLogPort"]
    end

    subgraph Driven["Driven Side (Outbound)"]
        Redis["Redis Bus"]
        MemBus["Memory Bus"]
        Anthropic["Anthropic"]
        OpenAI["OpenAI"]
        Ollama["Ollama"]
        Docker["Docker"]
        Firecracker["Firecracker"]
        FileStore["File Storage"]
        Postgres["PostgreSQL"]
        AuditLog["Immutable Audit Log"]
    end

    CLI --> P_EXEC
    API --> P_EXEC
    WS --> P_INT

    P_EXEC --> UC
    P_INT --> UC
    UC --> DOM

    UC --> P_BUS
    UC --> P_LLM
    UC --> P_RT
    UC --> P_STORE
    UC --> P_AUDIT

    P_BUS --> Redis
    P_BUS --> MemBus
    P_LLM --> Anthropic
    P_LLM --> OpenAI
    P_LLM --> Ollama
    P_RT --> Docker
    P_RT --> Firecracker
    P_STORE --> FileStore
    P_STORE --> Postgres
    P_AUDIT --> AuditLog
```

## Layer Responsibilities

### Domain Layer (`domain/`)

The innermost layer contains pure business logic with zero external dependencies.

| Component | Responsibility |
|-----------|---------------|
| **Entities** | `Job`, `Flow`, `AgentEntity`, `Step`, `UserContext` -- all frozen dataclasses |
| **Value Objects** | `JobId`, `TechnicalLevel`, `AgentSkill`, `ExecutionResult`, `StepResult` |
| **Domain Events** | `JobCreated`, `JobCompleted`, `AgentTaskStarted`, etc. |
| **Domain Services** | `InterviewService` -- orchestrates interview logic |
| **Exceptions** | `SecurityError`, `SignatureVerificationError`, `SandboxEscapeError` |

### Application Layer (`application/`)

Orchestrates use cases by coordinating domain objects through ports.

| Component | Responsibility |
|-----------|---------------|
| **Use Cases** | `ExecuteJobUseCase`, `InterviewUseCase`, `CreatePlanUseCase`, `DeliverResultUseCase` |
| **DTOs** | `JobResultDTO`, `JobStatusDTO`, `InterviewDTO`, `DeliveryDTO` |
| **Inbound Ports** | `ExecuteJobPort`, `InterviewPort` -- protocols for driving adapters |
| **Outbound Ports** | `MessageBusPort`, `LLMClientPort`, `AgentRuntimePort`, `StoragePort`, `AuditLogPort` |

### Infrastructure Layer (`infrastructure/`)

Concrete implementations of all ports plus cross-cutting concerns.

| Component | Responsibility |
|-----------|---------------|
| **Inbound Adapters** | `CLIAdapter`, `APIAdapter`, `WebSocketAdapter` |
| **Outbound Adapters** | `RedisBus`, `MemoryBus`, `AnthropicClient`, `OpenAIClient`, `OllamaClient`, `DockerRuntime`, `FirecrackerRuntime`, `FileStorage`, `PostgresStorage`, `ImmutableAuditLog` |
| **Security** | `Guardian`, `SignatureVerifier`, `SandboxManager`, `SecretManager` |
| **Observability** | `HealthChecker`, `MetricsCollector`, structured logging, OpenTelemetry tracing |
| **Config** | `Settings` (frozen), `Container` (DI) |

## Data Flow

```mermaid
sequenceDiagram
    participant User
    participant Adapter as Inbound Adapter
    participant UseCase as ExecuteJobUseCase
    participant Interview as Interviewer
    participant Orchestrator
    participant Agent as Agent (Sandboxed)
    participant Bus as Message Bus
    participant Audit as Audit Log

    User->>Adapter: Submit idea
    Adapter->>UseCase: execute(idea)
    UseCase->>UseCase: Job.create(idea)
    UseCase->>Audit: append(JOB_CREATED)

    UseCase->>Interview: interview(idea)
    Interview->>Interview: Detect level
    Interview->>Interview: Select questions
    Interview->>Interview: Build UserContext
    Interview-->>UseCase: UserContext (frozen)
    UseCase->>Audit: append(INTERVIEW_COMPLETE)

    UseCase->>Orchestrator: generate_plan(context)
    Orchestrator-->>UseCase: Plan
    UseCase->>Audit: append(PLAN_GENERATED)

    UseCase->>Orchestrator: execute(context, job_id)
    loop For each flow step
        Orchestrator->>Bus: publish(agent:execution)
        Orchestrator->>Agent: execute(skill, inputs)
        Agent->>Agent: Guardian validates
        Agent->>Agent: Execute in sandbox
        Agent-->>Orchestrator: StepResult
        Orchestrator->>Bus: publish(step:completed)
    end
    Orchestrator-->>UseCase: ExecutionResult

    UseCase->>UseCase: Create delivery
    UseCase->>Audit: append(JOB_COMPLETED)
    UseCase-->>Adapter: JobResultDTO
    Adapter-->>User: Result
```

## Immutability Guarantees

All domain objects use `@dataclass(frozen=True, slots=True)`:

- **Job** -- State transitions create new `Job` instances; the original is never mutated
- **UserContext** -- Built once during interview, never modified after
- **Events** -- Append-only event log with hash chain integrity verification
- **Value Objects** -- `JobId`, `TechnicalLevel`, `AgentSkill` are all frozen
- **Settings** -- Application configuration is frozen after load

## Agent System

Nine specialized agents, each running in isolated sandboxes:

| Agent | Skills | Category |
|-------|--------|----------|
| **Specs** | `analyze_requirements`, `generate_user_stories` | ANALYSIS |
| **Architect** | `design_architecture`, `generate_schemas`, `create_api_spec` | DESIGN |
| **Coder** | `implement_feature`, `implement_from_template` | CODING |
| **Tester** | `write_unit_tests`, `write_integration_tests`, `run_tests`, `run_basic_tests` | TESTING |
| **Reviewer** | `code_review`, `security_review`, `performance_review` | REVIEW |
| **Security** | `sast_scan`, `dependency_scan`, `secret_scan` | SECURITY |
| **Deployer** | `deploy_staging`, `deploy_production` | DEPLOYMENT |
| **Documenter** | `generate_docs`, `generate_manual` | DOCUMENTATION |
| **Monitor** | `setup_monitoring`, `create_alerts` | MONITORING |

## Flow Engine

Three predefined flows selected by user technical level:

| Level | Flow | Steps |
|-------|------|-------|
| `NO_DEV` | `simple_flow` | 7 sequential steps |
| `DEV_JUNIOR` / `DEV_SENIOR` | `developer_flow` | 14 steps with parallel execution and decision nodes |
| `ENGINEER` | `enterprise_flow` | 18+ steps with parallel phases, security scans, monitoring |

Flows are defined in signed YAML files and support four step types: `AGENT`, `DECISION`, `PARALLEL`, and `CHECKPOINT`.

## Technology Stack

| Concern | Technology |
|---------|-----------|
| Language | Python 3.12+ |
| Message Bus | Redis (production) / Memory (development) |
| LLM Providers | Anthropic, OpenAI, Ollama |
| Container Runtime | Docker, Firecracker |
| Storage | File system, PostgreSQL |
| Observability | Structured JSON logging, OpenTelemetry, Prometheus metrics |
| Security | HMAC-SHA256 signatures, hash chain audit, sandbox isolation |
