# C4 Container Diagram -- Kore Platform

## Container Overview

The Container diagram shows the major deployable units within the Kore Platform and how they communicate.

```mermaid
C4Container
    title Kore Platform - Container Diagram

    Person(user, "User", "No-Dev / Developer / Engineer")

    Container_Boundary(platform, "Kore Platform") {
        Container(cli, "CLI Interface", "Python, asyncio", "Terminal-based interaction<br/>for local development")
        Container(api, "REST API", "FastAPI/Starlette", "HTTP endpoints for<br/>job management and health")
        Container(ws, "WebSocket Server", "Python, asyncio", "Real-time bidirectional<br/>communication for interviews")

        Container(core, "Core Engine", "Python", "Use cases, domain model,<br/>interview system, orchestrator,<br/>delivery factory")

        Container(guardian, "AEGIS Security", "Python", "Guardian, Sandbox Manager,<br/>Signature Verifier,<br/>Secret Manager")

        Container(bus, "Message Bus", "Redis / Memory", "Pub/sub, task queues,<br/>cache, event streams")

        Container(agents, "Agent Pool", "Python, Docker", "9 specialized agents<br/>running in sandboxes:<br/>Specs, Architect, Coder, Tester,<br/>Reviewer, Security, Deployer,<br/>Documenter, Monitor")

        Container(audit, "Audit Log", "Python, JSONL", "Immutable append-only log<br/>with SHA-256 hash chain<br/>for tamper detection")

        Container(storage, "Storage", "File / PostgreSQL", "Jobs, artifacts,<br/>flow definitions,<br/>execution results")

        Container(obs, "Observability", "Python", "Health checks, metrics,<br/>structured logging,<br/>OpenTelemetry tracing")
    }

    System_Ext(llm, "LLM Providers", "Anthropic, OpenAI, Ollama")
    System_Ext(docker, "Container Runtime", "Docker Engine / Firecracker")
    System_Ext(redis_ext, "Redis Server", "Redis 7+")

    Rel(user, cli, "Runs commands", "Terminal")
    Rel(user, api, "HTTP requests", "HTTPS")
    Rel(user, ws, "Connects", "WSS")

    Rel(cli, core, "execute(idea)")
    Rel(api, core, "execute(idea)")
    Rel(ws, core, "interview()")

    Rel(core, guardian, "Validates all actions")
    Rel(core, bus, "Publishes events,<br/>enqueues tasks")
    Rel(core, agents, "Dispatches skills")
    Rel(core, audit, "Appends entries")
    Rel(core, storage, "Persists state")
    Rel(core, obs, "Reports health/metrics")

    Rel(guardian, agents, "Enforces policies")
    Rel(agents, llm, "AI inference", "HTTPS")
    Rel(agents, docker, "Sandbox execution", "Docker API")
    Rel(bus, redis_ext, "Protocol", "TCP 6379")
```

## Container Details

### Inbound Containers

| Container | Technology | Port | Responsibility |
|-----------|-----------|------|----------------|
| **CLI Interface** | Python asyncio, `input()` | stdin/stdout | Local terminal interaction. Displays plans and results. Collects user input for interview and confirmation steps. |
| **REST API** | FastAPI/Starlette ready | 8000 | `POST /api/v1/jobs` creates jobs. `GET /api/v1/jobs/{id}` checks status. `GET /api/v1/health` returns system health. |
| **WebSocket Server** | Python asyncio, JSON protocol | 8001 | Real-time bidirectional communication. Used for live interview sessions and execution progress streaming. |

### Core Containers

| Container | Technology | Responsibility |
|-----------|-----------|----------------|
| **Core Engine** | Pure Python | Contains use cases (`ExecuteJobUseCase`, `InterviewUseCase`, `CreatePlanUseCase`, `DeliverResultUseCase`), domain model (entities, value objects, events), interview system (level detection, question selection, context building), and orchestration engine. |
| **AEGIS Security** | Pure Python | `Guardian` validates all commands and paths against whitelists. `SandboxManager` creates and monitors agent containers. `SignatureVerifier` checks HMAC-SHA256 signatures on YAML flows. `SecretManager` handles API keys via environment variables. |
| **Message Bus** | Redis / asyncio.Queue | Unified interface (`MessageBusPort`) for pub/sub channels, FIFO task queues, TTL cache, and append-only streams. `RedisBus` for production, `MemoryBus` for development. |
| **Agent Pool** | Python + Docker | Nine agents (`Specs`, `Architect`, `Coder`, `Tester`, `Reviewer`, `Security`, `Deployer`, `Documenter`, `Monitor`) each with registered skills. Agents run in sandboxed containers with restricted network, memory, and filesystem access. |
| **Audit Log** | Python, JSONL files | Append-only log per job. Each entry includes SHA-256 hash of its content plus the hash of the previous entry, forming a chain. `verify_integrity()` detects any tampering. |
| **Storage** | File I/O / PostgreSQL | Persists jobs, execution artifacts, and flow definitions. `FileStorage` for development (JSON files). `PostgresStorage` for production. Supports binary artifact storage. |
| **Observability** | Python, OpenTelemetry | `HealthChecker` with pluggable component checks. `MetricsCollector` for counters and histograms. Structured JSON logging. Optional OTLP tracing export. |

## Communication Patterns

```mermaid
flowchart LR
    subgraph Sync["Synchronous (Request/Response)"]
        CLI -->|"await execute()"| Core
        API -->|"await create_job()"| Core
        Core -->|"await interview()"| Interview
        Core -->|"await execute()"| Agent
    end

    subgraph Async["Asynchronous (Event-Driven)"]
        Core -->|"publish()"| Bus
        Bus -->|"subscribe()"| Agent
        Agent -->|"publish()"| Bus
        Bus -->|"subscribe()"| WS[WebSocket]
    end

    subgraph Stream["Append-Only (Audit)"]
        Core -->|"append()"| Audit
        Audit -->|"verify_integrity()"| Core
    end
```

## Deployment Topology

```mermaid
graph TB
    subgraph Host["Host Machine"]
        subgraph Containers["Docker Compose"]
            APP["kore-platform<br/>:8000 :8001"]
            RED["redis:7-alpine<br/>:6379"]
            PG["postgres:16<br/>:5432"]
        end

        subgraph AgentNet["kore-agent-net (isolated)"]
            S1["agent-sandbox-1"]
            S2["agent-sandbox-2"]
            S3["agent-sandbox-N"]
        end
    end

    APP --> RED
    APP --> PG
    APP -->|"Docker API"| S1
    APP -->|"Docker API"| S2
    APP -->|"Docker API"| S3
```
