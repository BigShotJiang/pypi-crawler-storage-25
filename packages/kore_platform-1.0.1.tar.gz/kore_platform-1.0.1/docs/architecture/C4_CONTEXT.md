# C4 Context Diagram -- Kore Platform

## System Context

The C4 Context diagram shows the Kore Platform system and its relationships with external actors and systems.

```mermaid
C4Context
    title Kore Platform - System Context Diagram

    Person(nodev, "No-Dev User", "Non-technical user who wants<br/>software built from an idea")
    Person(dev, "Developer User", "Junior or senior developer<br/>who provides technical preferences")
    Person(eng, "Engineer User", "Architect/engineer who specifies<br/>architecture, security, compliance")

    System(kore, "Kore Platform", "AI-powered software development<br/>orchestration platform that transforms<br/>ideas into deployed applications")

    System_Ext(llm, "LLM Providers", "Anthropic Claude, OpenAI GPT,<br/>Ollama local models for<br/>AI inference and code generation")
    System_Ext(redis, "Redis", "Message bus for pub/sub,<br/>task queues, caching,<br/>and event streams")
    System_Ext(docker, "Docker / Firecracker", "Container runtime for<br/>sandboxed agent execution<br/>with resource limits")
    System_Ext(storage, "Persistent Storage", "File system or PostgreSQL<br/>for jobs, artifacts,<br/>and audit logs")

    Rel(nodev, kore, "Submits idea via CLI/API", "HTTP/CLI")
    Rel(dev, kore, "Submits idea with tech prefs", "HTTP/WebSocket")
    Rel(eng, kore, "Submits idea with full specs", "HTTP/WebSocket/CLI")

    Rel(kore, llm, "Sends prompts,<br/>receives generated code", "HTTPS")
    Rel(kore, redis, "Publishes events,<br/>enqueues tasks,<br/>caches results", "TCP 6379")
    Rel(kore, docker, "Creates sandboxes,<br/>executes commands", "Docker API / Unix socket")
    Rel(kore, storage, "Persists jobs,<br/>artifacts,<br/>audit entries", "File I/O / TCP 5432")
```

## Narrative

### Users

The platform serves three distinct user personas, each with different technical levels and interaction patterns:

| Persona | Technical Level | Flow | Interaction |
|---------|----------------|------|-------------|
| **No-Dev User** | `NO_DEV` | `simple_flow` (7 steps) | Describes idea in plain language. Platform handles all technical decisions. Receives ready-to-use deployed application with user manual. |
| **Developer User** | `DEV_JUNIOR` / `DEV_SENIOR` | `developer_flow` (14 steps) | Provides idea plus technical preferences (stack, deployment target). Platform generates architecture, code, tests, and deploys with CI/CD. |
| **Engineer User** | `ENGINEER` | `enterprise_flow` (18+ steps) | Specifies architecture patterns, security requirements, compliance needs. Platform produces DDD codebase with 95% coverage, threat model, ADRs, monitoring, and multi-stage deployment. |

### External Systems

| System | Purpose | Protocol | Fallback |
|--------|---------|----------|----------|
| **LLM Providers** | AI inference for code generation, requirements analysis, architecture design | HTTPS REST APIs | Multiple providers (Anthropic, OpenAI, Ollama) |
| **Redis** | Event bus (pub/sub), task queues (lists), response cache (key-value), activity streams (streams) | Redis protocol (TCP 6379) | `MemoryBus` in-memory fallback for development |
| **Docker / Firecracker** | Sandboxed execution of agent tasks with network isolation, memory limits, and read-only root filesystem | Docker Engine API / Firecracker API | Configurable runtime via `AgentRuntimePort` |
| **Persistent Storage** | Job state, execution artifacts, immutable audit log with hash chain | File I/O or PostgreSQL wire protocol | `FileStorage` for local dev, `PostgresStorage` for production |

## Trust Boundaries

```mermaid
graph TB
    subgraph Internet["Untrusted Zone"]
        USER["Users"]
    end

    subgraph DMZ["DMZ / API Gateway"]
        API["REST API / WebSocket"]
    end

    subgraph Platform["Trusted Platform Zone"]
        CORE["Core Engine"]
        GUARD["AEGIS Guardian"]
        AUDIT["Immutable Audit Log"]
    end

    subgraph Sandbox["Sandboxed Zone (Least Privilege)"]
        AGENTS["Agent Containers"]
    end

    subgraph Backend["Backend Services Zone"]
        REDIS["Redis"]
        DB["PostgreSQL"]
        LLM["LLM APIs"]
    end

    USER -->|"HTTPS / TLS"| API
    API -->|"Validated input"| CORE
    CORE -->|"All actions validated"| GUARD
    GUARD -->|"Allowed actions only"| AGENTS
    CORE -->|"Append-only"| AUDIT
    AGENTS -->|"Network isolated"| REDIS
    CORE -->|"Authenticated"| DB
    AGENTS -->|"API key scoped"| LLM
```

### Trust Boundary Rules

1. **Internet to Platform**: All input validated, rate-limited, authenticated
2. **Platform to Sandbox**: Guardian validates every command; only whitelisted commands and paths allowed
3. **Sandbox to Backend**: Network disabled by default; only explicitly enabled for specific agent tasks
4. **Platform to Audit**: Append-only writes; hash chain prevents retroactive modification
5. **Platform to LLM**: API keys managed via `SecretManager`; never logged or exposed
