# Sequence Diagrams -- Kore Platform

## 1. Job Creation Flow

This diagram shows the complete lifecycle of a job from idea submission to delivery.

```mermaid
sequenceDiagram
    autonumber
    participant U as User
    participant A as Inbound Adapter
    participant UC as ExecuteJobUseCase
    participant J as Job Entity
    participant AL as AuditLogPort
    participant I as Interviewer
    participant O as Orchestrator
    participant DF as DeliveryFactory

    U->>A: Submit idea
    A->>UC: execute(idea)

    Note over UC,J: Phase 1: Job Creation
    UC->>J: Job.create(idea)
    J-->>UC: Job(status=CREATED)
    UC->>AL: append(JOB_CREATED, {idea})
    AL-->>UC: hash_0

    Note over UC,I: Phase 2: Interview
    UC->>J: transition_to(INTERVIEWING)
    J-->>UC: Job(status=INTERVIEWING)
    UC->>AL: append(INTERVIEW_START)
    UC->>I: interview(idea)
    I-->>UC: UserContext (frozen)
    UC->>J: transition_to(PLANNING, context)
    J-->>UC: Job(status=PLANNING)
    UC->>AL: append(INTERVIEW_COMPLETE, {level, problem})

    Note over UC,O: Phase 3: Planning
    UC->>O: generate_plan(context)
    O-->>UC: Plan
    UC->>J: transition_to(AWAITING_CONFIRMATION)
    J-->>UC: Job(status=AWAITING_CONFIRMATION)
    UC->>AL: append(PLAN_GENERATED, {plan_summary})

    Note over UC,O: Phase 4: Confirmation
    UC->>O: request_user_confirmation(plan)
    O-->>UC: confirmed=true

    Note over UC,O: Phase 5: Execution
    UC->>J: transition_to(EXECUTING)
    J-->>UC: Job(status=EXECUTING)
    UC->>AL: append(EXECUTION_START)
    UC->>O: execute(context, job_id)
    O-->>UC: ExecutionResult
    UC->>AL: append(EXECUTION_COMPLETE, {steps})

    Note over UC,DF: Phase 6: Delivery
    UC->>J: transition_to(DELIVERING)
    J-->>UC: Job(status=DELIVERING)
    UC->>DF: create_delivery(level, result)
    DF-->>UC: Delivery
    UC->>J: transition_to(COMPLETED)
    J-->>UC: Job(status=COMPLETED)
    UC->>AL: append(JOB_COMPLETED, {delivery_type})

    UC-->>A: JobResultDTO
    A-->>U: Result
```

## 2. Interview Flow

Detailed sequence showing how the interview system detects user level and builds context.

```mermaid
sequenceDiagram
    autonumber
    participant UC as InterviewUseCase
    participant AL as AuditLogPort
    participant I as Interviewer
    participant LD as LevelDetector
    participant QS as QuestionSelector
    participant CB as ContextBuilder

    UC->>AL: append(INTERVIEW_START, {idea})
    UC->>I: interview(idea)

    Note over I,LD: Step 1: Detect Technical Level
    I->>LD: detect(idea)
    Note right of LD: Analyzes idea text<br/>for technical indicators
    LD-->>I: TechnicalLevel.DEV_SENIOR

    Note over I,QS: Step 2: Select Questions
    I->>QS: select(level)
    Note right of QS: Loads from YAML:<br/>base.yaml + developer.yaml<br/>Filters by level
    QS-->>I: [Question, Question, ...]

    Note over I,CB: Step 3: Collect Answers
    alt Demo Mode
        I->>I: _generate_demo_answers(level, idea)
        Note right of I: Uses pre-defined answers<br/>mapped to technical level
    else Interactive Mode
        I->>I: _collect_answers(questions)
        Note right of I: Delegates to I/O adapter<br/>(CLI, WebSocket, API)
    end

    Note over I,CB: Step 4: Build Context
    I->>CB: build(level, idea, answers)
    Note right of CB: Creates frozen UserContext<br/>with all requirements,<br/>stack prefs, security needs
    CB-->>I: UserContext (frozen)

    I-->>UC: UserContext
    UC->>AL: append(INTERVIEW_COMPLETE, {level, req_count})
```

### Interview Decision Tree

```mermaid
graph TD
    START["User submits idea"] --> DETECT["LevelDetector.detect()"]
    DETECT -->|"No technical terms"| NODEV["NO_DEV"]
    DETECT -->|"Basic tech terms"| JUNIOR["DEV_JUNIOR"]
    DETECT -->|"Architecture mentions"| SENIOR["DEV_SENIOR"]
    DETECT -->|"DDD/CQRS/compliance"| ENG["ENGINEER"]

    NODEV --> Q_BASE["Base questions only"]
    JUNIOR --> Q_DEV["Base + developer questions"]
    SENIOR --> Q_DEVX["Base + developer + architecture"]
    ENG --> Q_ENG["All questions + security + compliance"]

    Q_BASE --> CTX["Build UserContext"]
    Q_DEV --> CTX
    Q_DEVX --> CTX
    Q_ENG --> CTX

    CTX --> FLOW{"Select flow"}
    FLOW -->|"NO_DEV"| SIMPLE["simple_flow.yaml"]
    FLOW -->|"DEV_*"| DEVFLOW["developer_flow.yaml"]
    FLOW -->|"ENGINEER"| ENTERPRISE["enterprise_flow.yaml"]
```

## 3. Execution Flow

Shows how the orchestrator executes flow steps, including parallel execution and decision nodes.

```mermaid
sequenceDiagram
    autonumber
    participant O as Orchestrator
    participant SV as SignatureVerifier
    participant G as Guardian
    participant SM as SandboxManager
    participant Bus as MessageBus
    participant Agent as BaseAgent
    participant Skill as BaseSkill
    participant AL as AuditLog

    Note over O,SV: Load and Verify Flow
    O->>SV: verify_and_load(flow.yaml)
    SV->>SV: HMAC-SHA256 signature check
    SV-->>O: Flow definition (verified)

    loop For each FlowStep
        Note over O,Agent: Step Execution

        O->>Bus: publish("job:progress", {step, status})

        alt StepType.AGENT
            O->>G: validate_agent_action(agent, action, inputs)
            G-->>O: GuardianResult(allowed=true)

            O->>SM: create(agent_name, permissions)
            SM-->>O: sandbox_id

            O->>Agent: execute(skill_name, inputs, context)
            Agent->>G: validate_action(action, inputs)
            G-->>Agent: GuardianResult(allowed=true)
            Agent->>Skill: safe_execute(inputs, context)
            Note right of Skill: Timed execution<br/>with error handling
            Skill-->>Agent: {status, output, _meta}
            Agent->>Bus: publish("agent:execution", {skill_completed})
            Agent->>Bus: log("agent:activity", {action, status})
            Agent-->>O: StepResult

            O->>SM: destroy(sandbox_id)
            O->>AL: append(STEP_COMPLETED)

        else StepType.PARALLEL
            par Parallel Execution
                O->>Agent: execute(skill_1, ...)
                Agent-->>O: StepResult_1
            and
                O->>Agent: execute(skill_2, ...)
                Agent-->>O: StepResult_2
            and
                O->>Agent: execute(skill_3, ...)
                Agent-->>O: StepResult_3
            end
            O->>AL: append(PARALLEL_COMPLETED)

        else StepType.DECISION
            O->>O: evaluate_condition(condition)
            alt Condition true
                O->>O: goto on_true step
            else Condition false
                O->>O: goto on_false step
            end

        else StepType.CHECKPOINT
            O->>AL: append(CHECKPOINT)
            O->>O: Save intermediate state
        end
    end

    O->>Bus: publish("job:completed", {result})
    O-->>O: ExecutionResult
```

## 4. Agent Communication Flow

Shows how agents communicate through the message bus during a multi-agent task.

```mermaid
sequenceDiagram
    autonumber
    participant O as Orchestrator
    participant Bus as MessageBus
    participant Specs as Specs Agent
    participant Arch as Architect Agent
    participant Coder as Coder Agent
    participant Test as Tester Agent

    Note over O,Test: Sequential Phase
    O->>Specs: execute("analyze_requirements", {idea})
    Specs->>Bus: publish("agent:execution", {skill_started: analyze_requirements})
    Specs->>Specs: Analyze via LLM
    Specs->>Bus: publish("agent:execution", {skill_completed})
    Specs->>Bus: log("agent:specs:activity", {action, status})
    Specs-->>O: {requirements}

    O->>Arch: execute("design_architecture", {requirements})
    Arch->>Bus: publish("agent:execution", {skill_started: design_architecture})
    Arch->>Arch: Design via LLM
    Arch->>Bus: publish("agent:execution", {skill_completed})
    Arch-->>O: {architecture, schemas}

    Note over O,Test: Parallel Phase
    par Coder + Tester in parallel
        O->>Coder: execute("implement_feature", {architecture, schemas})
        Coder->>Bus: publish("agent:execution", {skill_started: implement_feature})
        Coder->>Coder: Generate code via LLM
        Coder->>Bus: publish("agent:execution", {skill_completed})
        Coder-->>O: {codebase}
    and
        O->>Test: execute("write_unit_tests", {architecture, schemas})
        Test->>Bus: publish("agent:execution", {skill_started: write_unit_tests})
        Test->>Test: Generate tests via LLM
        Test->>Bus: publish("agent:execution", {skill_completed})
        Test-->>O: {unit_tests}
    end

    Note over O,Test: Integration Phase
    O->>Test: execute("run_tests", {codebase, unit_tests})
    Test->>Bus: publish("agent:execution", {skill_started: run_tests})
    Test->>Test: Execute tests in sandbox
    Test->>Bus: publish("agent:execution", {skill_completed})
    Test-->>O: {test_results}
```

## 5. Security Validation Flow

Shows the Guardian pattern validating actions before execution.

```mermaid
sequenceDiagram
    autonumber
    participant O as Orchestrator
    participant G as Guardian
    participant SM as SandboxManager
    participant RT as AgentRuntimePort
    participant Agent as Agent

    O->>G: validate_command("python test.py")
    Note right of G: Check dangerous patterns<br/>Check command whitelist
    G->>G: "python" in allowed_commands? YES
    G->>G: No dangerous patterns detected
    G->>G: _audit("ALLOWED", result)
    G-->>O: GuardianResult(allowed=true)

    O->>G: validate_path("/workspace/src/main.py")
    Note right of G: Check against allowed paths
    G->>G: Starts with "/workspace/"? YES
    G-->>O: GuardianResult(allowed=true)

    O->>SM: create("coder", {network: false})
    SM->>RT: create_sandbox("coder", config)
    Note right of RT: Creates container with:<br/>- No network<br/>- Read-only root<br/>- 512MB memory limit<br/>- 300s CPU limit<br/>- /workspace only
    RT-->>SM: sandbox_id
    SM-->>O: sandbox_id

    O->>Agent: execute("implement_feature", inputs, context)
    Agent->>G: validate_agent_action("coder", "implement_feature", inputs)
    Note right of G: Check inputs for<br/>dangerous patterns
    G-->>Agent: GuardianResult(allowed=true)
    Agent->>Agent: Execute skill in sandbox
    Agent-->>O: StepResult

    Note over O,Agent: Blocked Action Example
    O->>G: validate_command("rm -rf /")
    G->>G: Dangerous pattern: "rm -rf /"
    G->>G: _audit("BLOCKED", result)
    G-->>O: GuardianResult(allowed=false, reason="Dangerous pattern: rm -rf /")
```

## 6. Audit Log Hash Chain

Shows how the immutable audit log maintains integrity through hash chaining.

```mermaid
sequenceDiagram
    autonumber
    participant UC as UseCase
    participant AL as ImmutableAuditLog
    participant FS as File System

    UC->>AL: append(job_id, "JOB_CREATED", data)
    AL->>FS: Read last line of {job_id}.jsonl
    FS-->>AL: (empty -- new file)
    AL->>AL: prev_hash = "genesis"
    AL->>AL: entry = {timestamp, event_type, data, prev_hash}
    AL->>AL: hash_0 = SHA256(entry)
    AL->>AL: entry["hash"] = hash_0
    AL->>FS: Append JSON line
    AL-->>UC: hash_0

    UC->>AL: append(job_id, "INTERVIEW_START", data)
    AL->>FS: Read last line of {job_id}.jsonl
    FS-->>AL: {..., "hash": hash_0}
    AL->>AL: prev_hash = hash_0
    AL->>AL: entry = {timestamp, event_type, data, prev_hash: hash_0}
    AL->>AL: hash_1 = SHA256(entry)
    AL->>AL: entry["hash"] = hash_1
    AL->>FS: Append JSON line
    AL-->>UC: hash_1

    UC->>AL: append(job_id, "JOB_COMPLETED", data)
    AL->>AL: prev_hash = hash_1
    AL->>AL: hash_2 = SHA256(entry)
    AL->>FS: Append JSON line
    AL-->>UC: hash_2

    Note over UC,FS: Integrity Verification
    UC->>AL: verify_integrity(job_id)
    AL->>FS: Read all lines
    loop For each entry
        AL->>AL: Check prev_hash matches previous entry hash
        AL->>AL: Remove stored hash, recalculate, compare
    end
    AL-->>UC: true (chain intact)
```
