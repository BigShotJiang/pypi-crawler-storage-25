# C4 Component Diagram -- Kore Platform

## Component Overview

The Component diagram decomposes the Core Engine container into its internal components, showing domain entities, use cases, ports, and adapters.

```mermaid
C4Component
    title Kore Platform - Component Diagram (Core Engine)

    Container_Boundary(core, "Core Engine") {

        Component(uc_exec, "ExecuteJobUseCase", "Application", "Main orchestrator: create job,<br/>interview, plan, execute, deliver")
        Component(uc_int, "InterviewUseCase", "Application", "Conducts user interview<br/>and produces UserContext")
        Component(uc_plan, "CreatePlanUseCase", "Application", "Generates execution plan<br/>from UserContext")
        Component(uc_del, "DeliverResultUseCase", "Application", "Packages execution results<br/>for delivery")

        Component(e_job, "Job Entity", "Domain", "Frozen dataclass with<br/>status state machine.<br/>Transitions create new instances.")
        Component(e_flow, "Flow Entity", "Domain", "Immutable workflow definition<br/>with FlowSteps and FlowDecisions")
        Component(e_agent, "AgentEntity", "Domain", "Agent description with<br/>name, role, frozenset of skills")
        Component(e_step, "Step Entity", "Domain", "Execution step with type:<br/>AGENT, DECISION, PARALLEL, CHECKPOINT")
        Component(e_ctx, "UserContext", "Domain", "Frozen user requirements:<br/>level, stack, reqs, security")

        Component(vo_id, "JobId", "Value Object", "UUID v4 validated on construction")
        Component(vo_level, "TechnicalLevel", "Value Object", "NO_DEV, DEV_JUNIOR,<br/>DEV_SENIOR, ENGINEER")
        Component(vo_skill, "AgentSkill", "Value Object", "Skill with category,<br/>sandbox flag, timeout")
        Component(vo_result, "ExecutionResult", "Value Object", "Aggregated step results<br/>with artifacts and metrics")

        Component(evt_base, "DomainEvent", "Events", "Base event with UUID,<br/>timestamp, type, data")
        Component(evt_job, "Job Events", "Events", "Created, InterviewStarted,<br/>PlanGenerated, ExecutionStarted,<br/>Completed, Failed, Cancelled")
        Component(evt_agent, "Agent Events", "Events", "TaskStarted, TaskCompleted,<br/>TaskFailed")

        Component(p_exec, "ExecuteJobPort", "Inbound Port", "Protocol: execute(idea) -> JobResultDTO")
        Component(p_int, "InterviewPort", "Inbound Port", "Protocol: interview(idea) -> UserContext")

        Component(p_bus, "MessageBusPort", "Outbound Port", "ABC: publish, subscribe,<br/>enqueue, dequeue,<br/>cache_set/get, log, history")
        Component(p_llm, "LLMClientPort", "Outbound Port", "ABC: chat, structured_output")
        Component(p_rt, "AgentRuntimePort", "Outbound Port", "ABC: create/execute/destroy sandbox")
        Component(p_store, "StoragePort", "Outbound Port", "ABC: save/load/delete,<br/>save/load artifacts")
        Component(p_audit, "AuditLogPort", "Outbound Port", "ABC: append, verify_integrity,<br/>get_entries")

        Component(int_sys, "Interview System", "Interview", "Interviewer, LevelDetector,<br/>QuestionSelector, ContextBuilder")

        Component(dto, "DTOs", "Application", "JobResultDTO, JobStatusDTO,<br/>InterviewDTO, DeliveryDTO")
    }

    Rel(uc_exec, e_job, "Creates and transitions")
    Rel(uc_exec, uc_int, "Delegates interview")
    Rel(uc_exec, uc_plan, "Delegates planning")
    Rel(uc_exec, uc_del, "Delegates delivery")
    Rel(uc_int, int_sys, "Orchestrates")
    Rel(int_sys, e_ctx, "Produces")
    Rel(e_job, vo_id, "Identified by")
    Rel(e_ctx, vo_level, "Classified by")
    Rel(e_agent, vo_skill, "Has skills")
    Rel(uc_exec, evt_job, "Emits")
    Rel(uc_exec, p_bus, "Uses")
    Rel(uc_exec, p_audit, "Uses")
    Rel(uc_exec, dto, "Returns")
```

## Domain Model Detail

```mermaid
classDiagram
    class Job {
        +JobId id
        +JobStatus status
        +UserContext? context
        +Sequence~JobEvent~ events
        +datetime created_at
        +datetime updated_at
        +create(idea) Job$
        +transition_to(status, msg) Job
        +duration_seconds float
    }

    class JobStatus {
        <<enumeration>>
        CREATED
        INTERVIEWING
        PLANNING
        AWAITING_CONFIRMATION
        EXECUTING
        DELIVERING
        COMPLETED
        FAILED
        CANCELLED
    }

    class JobEvent {
        +datetime timestamp
        +JobStatus status
        +str message
        +dict metadata
    }

    class UserContext {
        +TechnicalLevel level
        +str original_idea
        +str problem_to_solve
        +str target_users
        +frozenset preferred_stack
        +str? architecture_pattern
        +str? deployment_target
        +frozenset business_requirements
        +frozenset technical_requirements
        +int test_coverage
        +bool needs_ci_cd
        +bool needs_monitoring
        +frozenset security_requirements
        +frozenset compliance_requirements
        +with_updated_requirements() UserContext
    }

    class TechnicalLevel {
        <<enumeration>>
        NO_DEV
        DEV_JUNIOR
        DEV_SENIOR
        ENGINEER
        +requires_technical_questions bool
        +requires_architecture_decisions bool
        +default_test_coverage int
        +flow_name str
    }

    class Flow {
        +str name
        +str trigger
        +str description
        +Sequence steps
        +tuple alerts
        +str version
        +step_count int
    }

    class FlowStep {
        +str agent
        +str action
        +tuple inputs
        +tuple outputs
        +int timeout_seconds
        +int retries
    }

    class FlowDecision {
        +str name
        +str condition
        +str on_true
        +str on_false
    }

    class Step {
        +str id
        +StepType type
        +str? agent
        +str? action
        +tuple inputs
        +tuple outputs
        +dict config
        +datetime? started_at
        +datetime? completed_at
        +with_start() Step
        +with_completion() Step
    }

    class StepType {
        <<enumeration>>
        AGENT
        DECISION
        PARALLEL
        CHECKPOINT
    }

    class AgentEntity {
        +str name
        +str role
        +frozenset~AgentSkill~ skills
        +int max_concurrent_tasks
        +bool requires_sandbox
        +has_skill(name) bool
        +with_skill(skill) AgentEntity
    }

    class AgentSkill {
        +str name
        +SkillCategory category
        +str description
        +bool requires_sandbox
        +int max_execution_seconds
    }

    class JobId {
        +str value
        +generate() JobId$
    }

    class ExecutionResult {
        +JobId job_id
        +Sequence~StepResult~ steps
        +dict artifacts
        +dict metrics
        +success bool
        +summary str
    }

    class StepResult {
        +str step_id
        +str agent
        +str action
        +str status
        +dict output
        +float duration_ms
        +str? error
    }

    Job --> JobId
    Job --> JobStatus
    Job --> JobEvent
    Job --> UserContext
    UserContext --> TechnicalLevel
    Flow --> FlowStep
    Flow --> FlowDecision
    Step --> StepType
    AgentEntity --> AgentSkill
    ExecutionResult --> JobId
    ExecutionResult --> StepResult
```

## Port Interfaces

### Inbound Ports (Driving)

```mermaid
classDiagram
    class ExecuteJobPort {
        <<protocol>>
        +execute(idea: str) JobResultDTO
    }

    class InterviewPort {
        <<protocol>>
        +interview(idea: str) UserContext
    }

    class CLIAdapter {
        +run(idea) JobResultDTO
        +get_user_input(prompt) str
        +display_plan(plan)
        +display_result(result)
    }

    class APIAdapter {
        +create_job(request) APIResponse
        +get_job_status(job_id) APIResponse
        +health() APIResponse
    }

    class WebSocketAdapter {
        +register_handler(type, handler)
        +on_connect(id, ws)
        +on_disconnect(id)
        +on_message(id, raw)
        +send(id, data)
        +broadcast(data)
    }

    ExecuteJobPort <|.. CLIAdapter
    ExecuteJobPort <|.. APIAdapter
    InterviewPort <|.. WebSocketAdapter
```

### Outbound Ports (Driven)

```mermaid
classDiagram
    class MessageBusPort {
        <<abstract>>
        +publish(channel, message)
        +subscribe(channel, callback)
        +enqueue(queue, task)
        +dequeue(queue, timeout)
        +cache_set(key, value, ttl)
        +cache_get(key)
        +log(stream, entry)
        +history(stream, count)
    }

    class LLMClientPort {
        <<abstract>>
        +chat(messages, model, temp, max_tokens) LLMResponse
        +structured_output(messages, schema, model) dict
    }

    class AgentRuntimePort {
        <<abstract>>
        +create_sandbox(agent, config) str
        +execute_in_sandbox(id, cmd, timeout) dict
        +destroy_sandbox(id)
        +list_sandboxes() list
    }

    class StoragePort {
        <<abstract>>
        +save(collection, key, data)
        +load(collection, key) dict?
        +delete(collection, key)
        +list_keys(collection, prefix) list
        +save_artifact(job_id, name, content) str
        +load_artifact(job_id, name) bytes?
    }

    class AuditLogPort {
        <<abstract>>
        +append(job_id, event_type, data, ts) str
        +verify_integrity(job_id) bool
        +get_entries(job_id, from, to) list
    }

    MessageBusPort <|-- RedisBus
    MessageBusPort <|-- MemoryBus
    LLMClientPort <|-- AnthropicClient
    LLMClientPort <|-- OpenAIClient
    LLMClientPort <|-- OllamaClient
    AgentRuntimePort <|-- DockerRuntime
    AgentRuntimePort <|-- FirecrackerRuntime
    StoragePort <|-- FileStorage
    StoragePort <|-- PostgresStorage
    AuditLogPort <|-- ImmutableAuditLog
```

## Dependency Injection

The `Container` class wires all components together using lazy initialization:

```mermaid
graph TD
    Settings["Settings (frozen)"] --> Container
    Container -->|"property"| Bus["MessageBusPort"]
    Container -->|"property"| AuditLog["AuditLogPort"]
    Container -->|"property"| Storage["StoragePort"]
    Container -->|"property"| Guardian["Guardian"]
    Container -->|"property"| SigVerifier["SignatureVerifier"]
    Container -->|"property"| SecretMgr["SecretManager"]
    Container -->|"property"| Metrics["MetricsCollector"]
    Container -->|"property"| Health["HealthChecker"]

    Bus -->|"development"| MemoryBus
    Bus -->|"production"| RedisBus
    Storage --> FileStorage
    AuditLog --> ImmutableAuditLog
```

The container selects implementations based on `Settings.environment`:
- **development**: `MemoryBus`, `FileStorage`, debug logging
- **production**: `RedisBus`, `PostgresStorage`, JSON logging, tracing enabled
