# ADR 0002: Immutability by Default

## Status

**Accepted** -- 2024-12

## Context

Kore Platform orchestrates multiple AI agents that execute concurrently, communicate asynchronously through a message bus, and produce artifacts that must be auditable. This creates several challenges:

1. **Concurrent access**: Multiple agents may read the same job state simultaneously. Mutable shared state leads to race conditions.
2. **Audit trail**: Regulatory and operational requirements demand a complete, tamper-evident history of every action taken on a job.
3. **Debugging**: When a multi-step flow fails at step 14, developers need to inspect the exact state at every prior transition without worrying that it was modified after the fact.
4. **Agent isolation**: Agents should receive read-only snapshots of context. An agent must not be able to mutate the shared job or user context.

The team considered two approaches:

- **Mutable state with locks**: Use `asyncio.Lock` to protect shared state. Simpler initially but error-prone at scale -- one forgotten lock introduces a data race.
- **Immutable state with transitions**: All domain objects are frozen. State changes produce new objects. History is an append-only sequence.

## Decision

We adopt **immutability by default** across the entire domain model and audit subsystem.

### Implementation Details

#### 1. Frozen Dataclasses

All domain entities and value objects use `@dataclass(frozen=True, slots=True)`:

```python
@dataclass(frozen=True, slots=True)
class Job:
    id: JobId
    status: JobStatus
    context: UserContext | None
    events: Sequence[JobEvent] = field(default_factory=tuple)
```

State transitions return new instances:

```python
def transition_to(self, new_status, message, ...) -> Job:
    return Job(
        id=self.id,
        status=new_status,
        events=(*self.events, new_event),
        ...
    )
```

#### 2. Frozen Collections

- `frozenset` for sets: `preferred_stack`, `skills`, `business_requirements`
- `tuple` for sequences: `events`, `steps`, `inputs`, `outputs`
- No mutable `list` or `dict` in domain objects

#### 3. Append-Only Audit Log

The `ImmutableAuditLog` stores entries in JSONL files with a SHA-256 hash chain:

```json
{"timestamp": "...", "event_type": "JOB_CREATED", "data": {...}, "prev_hash": "genesis", "hash": "a1b2c3..."}
{"timestamp": "...", "event_type": "INTERVIEW_START", "data": {...}, "prev_hash": "a1b2c3...", "hash": "d4e5f6..."}
```

Each entry's `hash` is computed over its content plus the `prev_hash`, creating a chain that detects tampering if any entry is modified or deleted.

#### 4. Hash Chain Verification

```python
async def verify_integrity(self, job_id: str) -> bool:
    # Walks the chain, verifying each link
    prev_hash = "genesis"
    for entry in entries:
        if entry["prev_hash"] != prev_hash:
            return False  # Chain broken
        recalculated = sha256(entry_without_hash)
        if recalculated != entry["hash"]:
            return False  # Entry tampered
        prev_hash = entry["hash"]
    return True
```

## Consequences

### Positive

- **Thread safety**: No race conditions on shared state -- concurrent readers always see a consistent snapshot.
- **Complete history**: Every state transition is recorded. The full evolution of a job is available for debugging and auditing.
- **Tamper detection**: The hash chain ensures that any modification to the audit log (deletion, insertion, alteration) is detectable.
- **Predictable behavior**: Functions that receive frozen objects cannot accidentally modify them. Agent code receives `UserContext` and cannot alter requirements.
- **Easy testing**: Expected state is just an object comparison. No need to mock internal mutation sequences.

### Negative

- **Memory allocation**: Every state transition allocates a new object. For a job with 20 transitions, 20 `Job` instances are created.
- **Verbosity**: `transition_to()` methods must copy all fields, leading to boilerplate. Adding a new field to `Job` requires updating the transition method.
- **Learning curve**: Developers accustomed to mutable OOP may find the pattern unfamiliar initially.
- **Serialization overhead**: Frozen objects require explicit serialization to `dict` for storage and messaging.

### Mitigations

- **Memory**: Python's garbage collector reclaims previous instances quickly. The memory overhead for 20 frozen dataclasses is negligible compared to LLM API call payloads.
- **Verbosity**: Factory methods (`create()`, `transition_to()`, `with_skill()`) encapsulate the copy logic.
- **Learning curve**: This ADR and code examples serve as onboarding documentation.
- **Serialization**: DTOs at the boundary handle conversion. Domain objects stay pure.
