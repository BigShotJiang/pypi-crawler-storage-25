# ADR 0005: YAML Flow Definitions

## Status

**Accepted** -- 2024-12

## Context

Kore Platform orchestrates multi-step workflows where different agent types execute in sequence, parallel, or conditionally. The system needs a way to define these workflows that is:

1. **Human-readable**: Engineers and operators must be able to read and understand flows without running code.
2. **Versionable**: Flows must be tracked in version control with meaningful diffs.
3. **Signable**: Flows must be cryptographically signed to prevent tampering (see ADR 0004).
4. **Extensible**: New step types (parallel, decision, checkpoint) must be addable without code changes to the parser.
5. **Level-adaptive**: Different user technical levels require different workflows.

We evaluated:

| Option | Pros | Cons |
|--------|------|------|
| **Python code** | Full language power, IDE support, type checking | Hard to sign, hard to audit, tempting to add logic |
| **JSON** | Universal, signable | Verbose, no comments, poor readability |
| **YAML** | Human-readable, supports comments, signable, universal tooling | Indentation-sensitive, type coercion gotchas |
| **TOML** | Simple, less ambiguous than YAML | Poor support for nested structures like flow steps |
| **Custom DSL** | Tailored to domain | Requires parser maintenance, learning curve |

## Decision

We adopt **YAML** as the format for flow definitions, with cryptographic HMAC-SHA256 signatures and support for four step types.

### Flow Structure

```yaml
name: Developer Flow
trigger: confirmed_plan
description: Flow for developers -- FastAPI/Django/Next.js with tests and CI/CD
version: "1.0"

steps:
  # Sequential agent step
  - agent: specs
    action: analyze_requirements
    output: requirements

  # Parallel execution block
  - parallel:
    - agent: coder
      action: implement_feature
      input: [architecture, schemas, api_spec]
      output: codebase
    - agent: tester
      action: write_unit_tests
      input: [architecture, schemas]
      output: unit_tests

  # Decision node
  - decision: review_passed
    condition: code_quality_acceptable
    si: continuar
    no: fix_issues

  # Standard agent steps continue...
  - agent: deployer
    action: deploy_production
    input: [codebase, test_results, security_scan]
    output: production_url

alerts:
  - "Developer project built, tested, and deployed"
```

### Step Types

| Type | YAML Syntax | Description |
|------|-------------|-------------|
| **AGENT** | `agent: name, action: name` | Executes a specific skill on a specific agent |
| **PARALLEL** | `parallel: [steps]` | Executes multiple agent steps concurrently |
| **DECISION** | `decision: name, condition: expr` | Conditional branching based on evaluation |
| **CHECKPOINT** | `checkpoint: name` | Saves intermediate state for recovery |

### Flow Catalog

Three predefined flows mapped to user technical levels:

| Level | Flow File | Steps | Features |
|-------|-----------|-------|----------|
| `NO_DEV` | `simple_flow.yaml` | 7 sequential | Template-based, basic tests, staging + production deploy |
| `DEV_JUNIOR` / `DEV_SENIOR` | `developer_flow.yaml` | 14 mixed | Architecture design, parallel coding/testing, code review, security scan |
| `ENGINEER` | `enterprise_flow.yaml` | 18+ mixed | Triple parallel phases, SAST/dependency/secret scans, monitoring setup, runbook generation |

### Cryptographic Signatures

Each flow file has a corresponding `.sig` file:

```
flows/
    simple_flow.yaml
    developer_flow.yaml
    enterprise_flow.yaml
    signatures/
        simple_flow.yaml.sig
        developer_flow.yaml.sig
        enterprise_flow.yaml.sig
```

Signatures are generated at build time:

```python
SignatureVerifier.sign_file(Path("flows/simple_flow.yaml"), signing_key)
```

And verified at runtime:

```python
verifier = SignatureVerifier(signing_key=key)
flow_data = verifier.verify_and_load(Path("flows/simple_flow.yaml"))
# Raises SignatureVerificationError if tampered
```

### Domain Mapping

YAML is parsed into frozen domain entities:

```python
@dataclass(frozen=True, slots=True)
class FlowStep:
    agent: str
    action: str
    inputs: tuple[str, ...] = ()
    outputs: tuple[str, ...] = ()
    timeout_seconds: int = 300
    retries: int = 0

@dataclass(frozen=True, slots=True)
class FlowDecision:
    name: str
    condition: str
    on_true: str
    on_false: str

@dataclass(frozen=True, slots=True)
class Flow:
    name: str
    trigger: str
    description: str
    steps: Sequence[FlowStep | FlowDecision] = ()
    alerts: tuple[str, ...] = ()
    version: str = "1.0"
```

## Consequences

### Positive

- **Readability**: Non-developers can read and understand `simple_flow.yaml`. Engineers can review `enterprise_flow.yaml` in a pull request.
- **Auditability**: Diffs clearly show what changed in a flow. Combined with signatures, unauthorized modifications are detected.
- **Separation of concerns**: Flow definitions are data, not code. Changing the order of steps or adding a new agent does not require modifying Python source.
- **Flexibility**: The parallel, decision, and checkpoint step types cover common orchestration patterns without overcomplicating the format.
- **Version control**: YAML diffs are clean and meaningful in Git.

### Negative

- **YAML pitfalls**: Indentation errors cause parse failures. `"1.0"` must be quoted to avoid being parsed as a float. `yes`/`no` are parsed as booleans in some YAML parsers.
- **No type checking**: Unlike Python code, YAML is not type-checked at write time. Invalid agent names or actions are only caught at runtime.
- **Limited expressiveness**: Complex conditional logic (multi-branch, loops) is awkward in YAML. Decision nodes only support binary branching.
- **Signature management**: Every flow modification requires re-signing, adding a step to the development workflow.

### Mitigations

- **YAML pitfalls**: Use `yaml.safe_load()` (already in place). Version strings are always quoted. Linting with `yamllint` in CI.
- **Type checking**: A flow validation step at startup checks that all referenced agents and actions exist in the agent registry.
- **Expressiveness**: For complex orchestration, the `CHECKPOINT` type allows the orchestrator to save state and implement custom recovery logic in Python.
- **Signatures**: A `scripts/sign_flows.py` utility signs all flows in one command. CI pipeline signs automatically before deployment.
