# ADR 0003: Redis as Message Bus

## Status

**Accepted** -- 2024-12

## Context

Kore Platform requires inter-agent communication across multiple patterns:

1. **Pub/Sub** -- Broadcasting events (e.g., "step completed", "job failed") to multiple subscribers (WebSocket adapter, monitoring, logging).
2. **Task queues** -- Distributing work items to agents in a FIFO order with at-least-once delivery.
3. **Caching** -- Storing LLM responses and intermediate results with TTL expiration to avoid redundant API calls.
4. **Event streams** -- Appending and reading ordered logs of agent activity for debugging and observability.

We evaluated the following options:

| Option | Pros | Cons |
|--------|------|------|
| **Redis** | Single system for all 4 patterns. Pub/Sub, Lists, Strings with TTL, Streams all built-in. Extremely fast. Wide ecosystem. | Single point of failure. No built-in persistence for pub/sub. |
| **RabbitMQ** | Robust message broker with acknowledgments. | Overkill for caching and streams. Adds operational complexity. |
| **Apache Kafka** | Excellent for streams and high-throughput. | Heavy infrastructure. Unnecessary for this scale. |
| **In-memory only** | Zero dependencies. Simplest. | No persistence. No multi-process support. Development only. |

## Decision

We adopt **Redis** as the primary message bus for production, with an **in-memory fallback** (`MemoryBus`) for development and testing.

### Unified Port Interface

A single `MessageBusPort` abstract class exposes all four communication patterns:

```python
class MessageBusPort(ABC):
    # Pub/Sub
    async def publish(self, channel: str, message: dict) -> None: ...
    async def subscribe(self, channel: str, callback: Callable) -> None: ...

    # Task Queues
    async def enqueue(self, queue: str, task: dict) -> None: ...
    async def dequeue(self, queue: str, timeout: float = 0) -> dict | None: ...

    # Cache
    async def cache_set(self, key: str, value: Any, ttl: int | None = None) -> None: ...
    async def cache_get(self, key: str) -> Any | None: ...

    # Streams
    async def log(self, stream: str, entry: dict) -> None: ...
    async def history(self, stream: str, count: int = 50) -> list[dict]: ...
```

### Redis Implementation

The `RedisBus` maps each pattern to a Redis data structure:

| Pattern | Redis Command | Key Prefix | Details |
|---------|--------------|------------|---------|
| Pub/Sub | `PUBLISH` / `SUBSCRIBE` | (channel name) | Fire-and-forget broadcast |
| Task Queue | `RPUSH` / `BLPOP` | `q:{queue}` | FIFO with blocking dequeue |
| Cache | `SET` (with `EX`) / `GET` | `c:{key}` | Default 300s TTL |
| Stream | `XADD` / `XREVRANGE` | `s:{stream}` | Ordered append, reverse read |

### Memory Implementation

The `MemoryBus` uses Python stdlib equivalents:

| Pattern | Python Implementation |
|---------|----------------------|
| Pub/Sub | `dict[str, list[Callable]]` |
| Task Queue | `dict[str, asyncio.Queue]` |
| Cache | `dict[str, tuple[value, expires_at]]` |
| Stream | `dict[str, list[dict]]` |

### Container Selection

```python
@property
def bus(self) -> MessageBusPort:
    if self.settings.environment == "development":
        return MemoryBus()
    else:
        return RedisBus(
            host=self.settings.redis_host,
            port=self.settings.redis_port,
            password=self.settings.redis_password,
        )
```

## Consequences

### Positive

- **Single dependency for four patterns**: Redis replaces what would otherwise require a message broker + cache server + event store.
- **Sub-millisecond latency**: Redis in-memory operations are fast enough for real-time agent communication.
- **Testability**: `MemoryBus` allows full integration tests without Redis. Unit tests mock the port directly.
- **Operational simplicity**: Redis is well-understood, widely deployed, and easy to monitor.
- **Gradual adoption**: Start with `MemoryBus`, switch to `RedisBus` when scaling beyond a single process.

### Negative

- **Pub/Sub is fire-and-forget**: If a subscriber is down when a message is published, it misses the message. Redis Pub/Sub does not persist messages.
- **Single point of failure**: Redis downtime affects all four communication patterns simultaneously.
- **No built-in dead letter queue**: Failed task processing requires custom retry logic.
- **Memory limits**: Large caches or streams can exhaust Redis memory if not properly configured with eviction policies.

### Mitigations

- **Missed messages**: Critical state changes are persisted in the audit log (independent of Redis). Redis Pub/Sub is used for real-time notifications, not as the source of truth.
- **Availability**: Redis Sentinel or Redis Cluster for high availability in production. The `MemoryBus` fallback ensures the system degrades gracefully.
- **Retries**: Agent tasks include retry configuration (`FlowStep.retries`). The orchestrator handles retry logic at the application level.
- **Memory**: Configure Redis `maxmemory-policy allkeys-lru`. Streams use `MAXLEN` trimming. Cache entries have explicit TTLs.
