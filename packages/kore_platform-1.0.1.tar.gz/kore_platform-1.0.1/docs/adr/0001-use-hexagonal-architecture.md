# ADR 0001: Use Hexagonal Architecture

## Status

**Accepted** -- 2024-12

## Context

Kore Platform is a multi-agent orchestration system that must:

1. **Integrate with multiple external systems** -- LLM providers (Anthropic, OpenAI, Ollama), message buses (Redis, in-memory), container runtimes (Docker, Firecracker), storage backends (file system, PostgreSQL), and multiple inbound interfaces (CLI, REST API, WebSocket).

2. **Be independently testable** -- Each component (domain logic, use cases, agents) must be testable in isolation without requiring Docker, Redis, or LLM API keys.

3. **Support runtime swapping** -- Different environments (development, staging, production) require different implementations. Development uses `MemoryBus` and `FileStorage`; production uses `RedisBus` and `PostgresStorage`.

4. **Maintain long-term evolvability** -- As the agent ecosystem grows, new agents, skills, LLM providers, and deployment targets will be added without modifying core business logic.

The team evaluated three architectural approaches:

- **Layered architecture** -- Simple but creates tight coupling between layers and makes adapter swapping difficult.
- **Clean architecture** -- Good separation but prescribes more layers than necessary for this problem.
- **Hexagonal architecture (ports and adapters)** -- Provides the exact primitives needed: inbound ports for driving the application, outbound ports for driven infrastructure, and adapters that implement them.

## Decision

We adopt **hexagonal architecture** (also known as ports and adapters, after Alistair Cockburn's original pattern) as the primary architectural style for Kore Platform.

### Structure

```
src/kore_platform/
    domain/                  # Pure business logic, zero dependencies
        entities/            # Job, Flow, AgentEntity, Step, UserContext
        value_objects/       # JobId, TechnicalLevel, AgentSkill, ExecutionResult
        events/              # DomainEvent, JobCreated, AgentTaskStarted, etc.
        services/            # InterviewService
        exceptions/          # SecurityError, ValidationError

    application/             # Use cases and ports
        use_cases/           # ExecuteJobUseCase, InterviewUseCase, etc.
        ports/
            inbound/         # ExecuteJobPort, InterviewPort (Protocol)
            outbound/        # MessageBusPort, LLMClientPort, etc. (ABC)
        dto/                 # JobResultDTO, InterviewDTO, etc.

    infrastructure/          # Concrete implementations
        adapters/
            inbound/         # CLIAdapter, APIAdapter, WebSocketAdapter
            outbound/        # RedisBus, MemoryBus, AnthropicClient, etc.
        security/            # Guardian, SandboxManager, SignatureVerifier
        config/              # Settings, Container (DI)
        observability/       # Health, Metrics, Logging, Tracing
```

### Rules

1. **Domain has no imports from application or infrastructure.**
2. **Application imports only from domain.** Outbound ports are abstract (ABC). Inbound ports are protocols.
3. **Infrastructure imports from application (to implement ports) and domain (to use entities).**
4. **Dependency injection via `Container`** wires concrete adapters to abstract ports at startup.
5. **All ports use `async/await`** to support concurrent agent execution.

## Consequences

### Positive

- **Testability**: Domain and use cases can be tested with in-memory mocks. No Docker, Redis, or API keys needed for unit tests.
- **Swappability**: `MemoryBus` in dev, `RedisBus` in prod -- one line change in `Container`. New LLM providers require only a new adapter class.
- **Independent deployability**: The CLI, API, and WebSocket adapters can be deployed independently or together.
- **Clear boundaries**: Each developer knows exactly where to add code based on whether it is domain logic, application orchestration, or infrastructure integration.
- **Future-proofing**: Adding Firecracker runtime alongside Docker requires only implementing `AgentRuntimePort` -- zero changes to use cases or domain.

### Negative

- **Initial complexity**: More files and directories than a flat structure. New developers must understand the port/adapter concept.
- **Indirection overhead**: Every external call goes through a port interface, adding a layer of abstraction that may seem unnecessary for simple operations.
- **Mapping cost**: DTOs must be mapped to/from domain objects at adapter boundaries, requiring boilerplate conversion code.

### Mitigations

- Comprehensive documentation (this ADR and architecture diagrams) explains the structure.
- `Container` class provides a single entry point for understanding how everything is wired.
- Naming conventions (`*Port`, `*Adapter`, `*UseCase`) make the role of each class immediately clear.
