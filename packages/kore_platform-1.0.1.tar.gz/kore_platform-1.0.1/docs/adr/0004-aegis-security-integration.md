# ADR 0004: AEGIS Security Integration

## Status

**Accepted** -- 2024-12

## Context

Kore Platform executes AI-generated code inside agent sandboxes. This creates a unique threat landscape:

1. **Prompt injection**: A malicious user could craft an "idea" that causes the LLM to generate code with `os.system("rm -rf /")`, `eval()`, or data exfiltration attempts.
2. **Sandbox escape**: An agent might attempt to access files outside `/workspace`, escalate privileges, or connect to unauthorized network services.
3. **Supply chain attacks**: A generated `requirements.txt` could include a typosquatted malicious package.
4. **Configuration tampering**: If flow YAML files are modified, the execution plan could be altered to skip security scans or deploy to unauthorized targets.
5. **Audit evasion**: An attacker who gains access could modify audit logs to hide their actions.

Traditional security approaches (perimeter firewalls, WAFs) are insufficient because the threat originates from within the system (AI-generated code executing in sandboxes).

## Decision

We implement **AEGIS** (Agent Execution Guardian and Integrity System), a defense-in-depth security framework with four components:

### 1. Guardian -- Command Validation

The `Guardian` validates **every** command and path before execution using a zero-trust approach:

```python
# Allowed commands (whitelist)
_ALLOWED_COMMANDS = frozenset({
    "python", "python3", "pip", "pip3",
    "git", "npm", "node", "npx",
    "docker", "pytest", "ruff", "black", "mypy",
    "curl", "wget",
})

# Allowed paths (whitelist)
_ALLOWED_PATHS = frozenset({
    "/workspace/", "/tmp/kore/", "/home/kore/",
})

# Dangerous patterns (blocklist)
_DANGEROUS_PATTERNS = frozenset({
    "rm -rf /", "sudo ", "chmod 777",
    "curl | bash", "eval(", "exec(",
    "__import__", "os.system",
    "subprocess.call", "subprocess.run",
    "drop table", "drop database",
})
```

Three validation methods:

| Method | Validates | Returns |
|--------|-----------|---------|
| `validate_command(cmd)` | Command against whitelist and dangerous patterns | `GuardianResult(allowed, reason)` |
| `validate_path(path)` | Path against allowed prefixes | `GuardianResult(allowed, reason)` |
| `validate_agent_action(agent, action, inputs)` | Action inputs against dangerous patterns | `GuardianResult(allowed, reason)` |

All validations are audited (both allowed and blocked).

### 2. Sandbox Manager -- Least Privilege Isolation

Every agent executes in a container sandbox with minimal permissions:

```python
config = {
    "network": False,           # No network by default
    "read_only_root": True,     # Read-only root filesystem
    "max_memory_mb": 512,       # Memory limit
    "max_cpu_seconds": 300,     # CPU time limit
    "allowed_paths": ["/workspace"],  # Filesystem restriction
}
```

The `SandboxManager` enforces:
- **Network isolation**: Disabled by default; only enabled for specific agents (e.g., Deployer)
- **Filesystem restriction**: Only `/workspace` is writable
- **Resource limits**: Memory and CPU caps prevent denial-of-service
- **Lifecycle management**: `destroy_all()` cleans up on job completion or failure

### 3. Signature Verifier -- Configuration Integrity

YAML flow definitions are cryptographically signed:

```python
class SignatureVerifier:
    def verify_and_load(self, config_path: Path) -> dict:
        # Load signature from flows/signatures/{name}.yaml.sig
        # Verify HMAC-SHA256(signing_key, file_content) == stored_signature
        # Raise SignatureVerificationError if mismatch
```

- Signatures are generated at build time using `sign_file()`
- The signing key is loaded from `KORE_SIGNING_KEY` environment variable
- Unsigned flows generate a warning but are still loaded (for development)
- Tampered flows raise `SignatureVerificationError` and halt execution

### 4. Secret Manager -- Credential Protection

API keys and secrets are managed through environment variables with a `KORE_` prefix:

```python
class SecretManager:
    def get(self, name: str) -> str:    # Optional, returns default
    def require(self, name: str) -> str: # Required, raises ValueError
    def get_all(self) -> dict:           # Masked values for debug
```

- Values are never logged (only first 4 characters for debugging)
- `require()` fails fast if a mandatory secret is missing
- `get_all()` returns masked values (`sk-p***`) for diagnostics

## Consequences

### Positive

- **Defense in depth**: Four independent security layers. An attacker must bypass all four.
- **Zero trust for agents**: Every agent action is validated before execution, regardless of trust level.
- **Tamper evidence**: YAML signature verification and audit log hash chains detect configuration and log tampering.
- **Least privilege**: Sandboxes restrict agents to the minimum permissions needed.
- **Auditability**: Every Guardian decision (allowed/blocked) is logged with reason and timestamp.

### Negative

- **Performance overhead**: Guardian validation on every command adds latency (microseconds, but non-zero).
- **False positives**: The pattern-based blocklist may flag legitimate code that happens to contain substrings like `eval(`.
- **Key management**: The signing key must be securely distributed and rotated. Loss of the key requires re-signing all flows.
- **Development friction**: Developers must ensure their commands are whitelisted and paths are allowed.

### Mitigations

- **Performance**: Guardian validation is string matching -- microseconds per call. Negligible compared to LLM API latency (seconds).
- **False positives**: The blocklist is configurable via Guardian constructor. Agent-specific overrides can relax patterns where justified.
- **Key management**: Signing keys are injected via environment variables. Rotation is handled by updating `KORE_SIGNING_KEY` and re-signing flows.
- **Development**: Development mode (`guardian_enabled: false` in settings) can bypass Guardian for local testing. Never in production.
