# Security Policy

## Supported Versions

| Version | Supported          |
|---------|--------------------|
| 1.0.x   | Yes                |
| < 1.0   | No                 |

## Reporting a Vulnerability

We take the security of Kore Platform seriously. If you have found a security
vulnerability, please follow responsible disclosure practices.

### How to Report

1. **Do NOT open a public GitHub issue.**
2. Send an email to **security@iafiscal.com** with the following information:
   - A description of the vulnerability.
   - Steps to reproduce the issue.
   - The potential impact.
   - Any suggested fix (optional but appreciated).

### What to Expect

- **Acknowledgement** within 48 hours of your report.
- **Initial assessment** within 5 business days.
- **Resolution timeline** communicated after assessment, typically within 30 days
  for critical issues.
- **Credit** in the release notes (unless you prefer to remain anonymous).

### Scope

The following are in scope for security reports:

- Authentication and authorization bypasses.
- Cryptographic signing/verification weaknesses.
- Remote code execution via flow definitions or agent sandboxing.
- Injection vulnerabilities (YAML deserialization, prompt injection).
- Sensitive data exposure (API keys, credentials, PII in logs).
- Dependency vulnerabilities with a plausible exploit path.

### Out of Scope

- Denial of service via resource exhaustion (unless trivially exploitable).
- Issues in dependencies without a demonstrated exploit in Kore Platform.
- Social engineering.

## Security Features

Kore Platform includes the following security measures:

- **Cryptographic flow signing**: All YAML flow definitions are signed with
  HMAC-SHA256. The engine refuses to execute unsigned or tampered flows.
- **Agent sandboxing**: Agents run with restricted permissions. File system
  access, network calls, and subprocess execution are gated by policy.
- **Input validation**: All configurations are validated through Pydantic v2
  strict schemas before processing.
- **Secret management**: Secrets are never logged. Structured logging redacts
  fields matching configurable patterns.
- **Dependency auditing**: CI pipelines run `pip-audit` and detect-secrets on
  every commit.
- **Non-root containers**: Docker images run as a dedicated unprivileged user.

## Security-Related Configuration

| Environment Variable    | Purpose                                      |
|-------------------------|----------------------------------------------|
| `KORE_SIGNING_KEY`      | HMAC key for flow signing/verification       |
| `KORE_SECRET_PATTERNS`  | Regex patterns for log redaction             |
| `KORE_SANDBOX_POLICY`   | Agent sandbox restriction level              |
| `KORE_TLS_CERT`         | Path to TLS certificate for API server       |
| `KORE_TLS_KEY`          | Path to TLS private key for API server       |
