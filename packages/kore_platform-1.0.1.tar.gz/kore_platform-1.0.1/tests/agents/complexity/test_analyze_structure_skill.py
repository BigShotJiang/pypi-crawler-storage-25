"""Tests for AnalyzeStructureSkill — import parsing, metrics, and rating."""

from __future__ import annotations

import pytest

from kore_platform.agents.complexity.skills.analyze_structure import (
    AnalyzeStructureSkill,
    DEFAULT_THRESHOLDS,
    calculate_metrics,
    compute_rating,
    extract_internal_imports,
    generate_warnings,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

SIMPLE_FILES: dict[str, str] = {
    "main.py": "import db\nimport api\n\ndef run(): pass\n",
    "api.py": "import db\n\ndef get(): pass\n",
    "db.py": "DB_URL = 'sqlite://'\n",
}

CIRCULAR_FILES: dict[str, str] = {
    "auth.py": "import user\n\ndef login(): pass\n",
    "user.py": "import auth\n\ndef get_user(): pass\n",
}

SINGLE_FILE: dict[str, str] = {
    "main.py": "print('hello')\n",
}

SYNTAX_ERROR_FILES: dict[str, str] = {
    "good.py": "import bad\n\ndef ok(): pass\n",
    "bad.py": "def broken(:\n    pass\n",  # SyntaxError
}

STDLIB_AND_EXTERNAL: dict[str, str] = {
    "main.py": "import os\nimport json\nimport requests\nimport db\n",
    "db.py": "import sqlite3\n\nDB = None\n",
}


# ---------------------------------------------------------------------------
# extract_internal_imports
# ---------------------------------------------------------------------------

class TestExtractInternalImports:
    def test_simple_project(self):
        nodes, edges = extract_internal_imports(SIMPLE_FILES)
        assert "main" in nodes
        assert "api" in nodes
        assert "db" in nodes
        assert ("main", "db") in edges
        assert ("main", "api") in edges
        assert ("api", "db") in edges

    def test_single_file_no_edges(self):
        nodes, edges = extract_internal_imports(SINGLE_FILE)
        assert len(nodes) == 1
        assert edges == []

    def test_empty_files(self):
        nodes, edges = extract_internal_imports({})
        assert nodes == []
        assert edges == []

    def test_syntax_error_skipped(self):
        nodes, edges = extract_internal_imports(SYNTAX_ERROR_FILES)
        # bad.py has syntax error but should still appear as a node
        assert "bad" in nodes
        assert "good" in nodes
        # good.py imports bad — edge should exist
        assert ("good", "bad") in edges

    def test_stdlib_filtered(self):
        nodes, edges = extract_internal_imports(STDLIB_AND_EXTERNAL)
        assert "main" in nodes
        assert "db" in nodes
        # os, json, requests, sqlite3 should NOT appear as nodes
        assert "os" not in nodes
        assert "json" not in nodes
        assert "requests" not in nodes
        assert "sqlite3" not in nodes
        # Only internal edge: main -> db
        assert ("main", "db") in edges
        assert len(edges) == 1

    def test_circular_detected(self):
        nodes, edges = extract_internal_imports(CIRCULAR_FILES)
        assert ("auth", "user") in edges
        assert ("user", "auth") in edges

    def test_no_self_edges(self):
        files = {"mod.py": "import mod\n"}
        nodes, edges = extract_internal_imports(files)
        assert edges == []

    def test_init_py_ignored_as_module(self):
        files = {
            "__init__.py": "import foo\n",
            "foo.py": "x = 1\n",
        }
        nodes, edges = extract_internal_imports(files)
        assert "__init__" not in nodes
        assert "foo" in nodes

    def test_from_import(self):
        files = {
            "main.py": "from db import connect\n",
            "db.py": "def connect(): pass\n",
        }
        nodes, edges = extract_internal_imports(files)
        assert ("main", "db") in edges

    def test_no_duplicate_edges(self):
        files = {
            "main.py": "import db\nimport db\nfrom db import x\n",
            "db.py": "x = 1\n",
        }
        nodes, edges = extract_internal_imports(files)
        assert edges.count(("main", "db")) == 1


# ---------------------------------------------------------------------------
# calculate_metrics
# ---------------------------------------------------------------------------

class TestCalculateMetrics:
    def test_empty_graph(self):
        m = calculate_metrics([], [])
        assert m["module_count"] == 0
        assert m["dependency_count"] == 0
        assert m["cyclomatic_complexity"] == 0
        assert m["entanglement"] == 0.0
        assert m["has_circular_dependencies"] is False

    def test_single_node(self):
        m = calculate_metrics(["main"], [])
        assert m["module_count"] == 1
        assert m["entanglement"] == 0.0

    def test_simple_graph_properties(self):
        nodes = ["main", "api", "db"]
        edges = [("main", "api"), ("main", "db"), ("api", "db")]
        m = calculate_metrics(nodes, edges)
        assert m["module_count"] == 3
        assert m["dependency_count"] == 3
        assert m["entanglement"] >= 0.0
        assert m["has_circular_dependencies"] is False

    def test_circular_graph(self):
        nodes = ["a", "b"]
        edges = [("a", "b"), ("b", "a")]
        m = calculate_metrics(nodes, edges)
        assert m["cycle_count"] > 0
        assert m["has_circular_dependencies"] is True

    def test_entanglement_increases_with_edges(self):
        nodes = ["a", "b", "c", "d"]
        sparse = [("a", "b")]
        dense = [("a", "b"), ("a", "c"), ("a", "d"), ("b", "c"), ("b", "d"), ("c", "d")]
        m_sparse = calculate_metrics(nodes, sparse)
        m_dense = calculate_metrics(nodes, dense)
        assert m_dense["entanglement"] > m_sparse["entanglement"]


# ---------------------------------------------------------------------------
# compute_rating
# ---------------------------------------------------------------------------

class TestComputeRating:
    def test_rating_a(self):
        m = {"entanglement": 0.1, "cycle_count": 0, "max_depth": 2}
        assert compute_rating(m) == "A"

    def test_rating_b(self):
        m = {"entanglement": 0.3, "cycle_count": 0, "max_depth": 6}
        assert compute_rating(m) == "B"

    def test_rating_c_via_entanglement(self):
        m = {"entanglement": 0.5, "cycle_count": 2, "max_depth": 6}
        assert compute_rating(m) == "C"

    def test_rating_c_via_cycles(self):
        m = {"entanglement": 0.9, "cycle_count": 1, "max_depth": 6}
        assert compute_rating(m) == "C"

    def test_rating_d(self):
        m = {"entanglement": 0.7, "cycle_count": 5, "max_depth": 10}
        assert compute_rating(m) == "D"

    def test_rating_f(self):
        m = {"entanglement": 0.9, "cycle_count": 5, "max_depth": 10}
        assert compute_rating(m) == "F"

    def test_custom_thresholds(self):
        strict = {
            "A": {"max_entanglement": 0.1, "max_cycles": 0, "max_depth": 2},
            "B": {"max_entanglement": 0.2, "max_cycles": 0},
            "C": {"max_entanglement": 0.3, "max_cycles": 0},
            "D": {"max_entanglement": 0.4, "max_cycles": 0},
        }
        m = {"entanglement": 0.15, "cycle_count": 0, "max_depth": 3}
        assert compute_rating(m, strict) == "B"


# ---------------------------------------------------------------------------
# generate_warnings
# ---------------------------------------------------------------------------

class TestGenerateWarnings:
    def test_no_warnings_clean_graph(self):
        nodes = ["a", "b"]
        edges = [("a", "b")]
        m = {"has_circular_dependencies": False, "entanglement": 0.1}
        w = generate_warnings(m, nodes, edges)
        assert w == []

    def test_circular_warning(self):
        nodes = ["a", "b"]
        edges = [("a", "b"), ("b", "a")]
        m = {"has_circular_dependencies": True, "entanglement": 0.3}
        w = generate_warnings(m, nodes, edges)
        assert any("Circular" in s for s in w)

    def test_high_entanglement_warning(self):
        nodes = ["a", "b"]
        edges = [("a", "b")]
        m = {"has_circular_dependencies": False, "entanglement": 0.75}
        w = generate_warnings(m, nodes, edges)
        assert any("entanglement" in s.lower() for s in w)

    def test_bottleneck_warning(self):
        nodes = ["a", "b", "c", "d", "hub"]
        edges = [("a", "hub"), ("b", "hub"), ("c", "hub"), ("d", "hub")]
        m = {"has_circular_dependencies": False, "entanglement": 0.3}
        w = generate_warnings(m, nodes, edges)
        assert any("hub" in s and "bottleneck" in s.lower() for s in w)


# ---------------------------------------------------------------------------
# AnalyzeStructureSkill.execute
# ---------------------------------------------------------------------------

class TestAnalyzeStructureSkillExecute:
    @pytest.mark.asyncio
    async def test_empty_files(self):
        skill = AnalyzeStructureSkill()
        result = await skill.execute({"files": {}}, {})
        assert result["status"] == "completed"
        assert result["type"] == "complexity_report"
        assert result["rating"] == "A"

    @pytest.mark.asyncio
    async def test_simple_project(self):
        skill = AnalyzeStructureSkill()
        result = await skill.execute({"files": SIMPLE_FILES}, {})
        assert result["status"] == "completed"
        assert result["type"] == "complexity_report"
        assert result["metrics"]["module_count"] == 3
        assert result["rating"] in ("A", "B", "C", "D", "F")
        assert isinstance(result["graph"]["nodes"], list)
        assert isinstance(result["graph"]["edges"], list)

    @pytest.mark.asyncio
    async def test_list_format_files(self):
        skill = AnalyzeStructureSkill()
        files_list = [
            {"path": "main.py", "content": "import db\n"},
            {"path": "db.py", "content": "x = 1\n"},
        ]
        result = await skill.execute({"files": files_list}, {})
        assert result["metrics"]["module_count"] == 2
        assert result["metrics"]["dependency_count"] == 1
