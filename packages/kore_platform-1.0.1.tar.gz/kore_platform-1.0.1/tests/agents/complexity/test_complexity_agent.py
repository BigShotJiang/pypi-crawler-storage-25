"""Tests for ComplexityAgent — registration, no-LLM, integration."""

from __future__ import annotations

import pytest

from kore_platform.agents.complexity.agent import ComplexityAgent


class TestComplexityAgent:
    def test_registers_both_skills(self):
        agent = ComplexityAgent()
        assert agent.has_skill("analyze_structure")
        assert agent.has_skill("detect_bottlenecks")
        assert len(agent.skills) == 2

    def test_no_llm_required(self):
        agent = ComplexityAgent()
        # Agent was created without llm_client — it should work fine
        assert agent._llm_client is None

    def test_name_and_role(self):
        agent = ComplexityAgent()
        assert agent.name == "complexity"
        assert "complexity" in agent.role.lower() or "analyzer" in agent.role.lower()

    @pytest.mark.asyncio
    async def test_execute_analyze_structure(self):
        agent = ComplexityAgent()
        files = {
            "main.py": "import db\n",
            "db.py": "x = 1\n",
        }
        result = await agent.execute("analyze_structure", {"files": files}, {})
        assert result["type"] == "complexity_report"
        assert result["metrics"]["module_count"] == 2

    @pytest.mark.asyncio
    async def test_execute_detect_bottlenecks(self):
        agent = ComplexityAgent()
        files = {
            "main.py": "import db\nimport api\n",
            "api.py": "import db\n",
            "db.py": "x = 1\n",
        }
        result = await agent.execute("detect_bottlenecks", {"files": files}, {})
        assert result["type"] == "bottleneck_report"
        assert isinstance(result["bottlenecks"], list)

    @pytest.mark.asyncio
    async def test_execute_unknown_skill(self):
        agent = ComplexityAgent()
        with pytest.raises(ValueError, match="no encontrada"):
            await agent.execute("nonexistent_skill", {}, {})

    @pytest.mark.asyncio
    async def test_integration_real_mini_project(self):
        """Integration: pass a realistic mini-project through both skills."""
        agent = ComplexityAgent()

        files = {
            "main.py": (
                "from api import router\n"
                "from db import init_db\n"
                "from config import settings\n"
                "\n"
                "def start():\n"
                "    init_db()\n"
                "    router.run()\n"
            ),
            "api.py": (
                "from db import get_session\n"
                "from models import User\n"
                "from config import settings\n"
                "\n"
                "class router:\n"
                "    @staticmethod\n"
                "    def run(): pass\n"
            ),
            "models.py": (
                "from db import Base\n"
                "\n"
                "class User:\n"
                "    pass\n"
            ),
            "db.py": (
                "from config import settings\n"
                "\n"
                "Base = object\n"
                "def init_db(): pass\n"
                "def get_session(): pass\n"
            ),
            "config.py": (
                "settings = {'db_url': 'sqlite://'}\n"
            ),
        }

        # analyze_structure
        report = await agent.execute("analyze_structure", {"files": files}, {})
        assert report["type"] == "complexity_report"
        assert report["metrics"]["module_count"] == 5
        assert report["metrics"]["dependency_count"] > 0
        assert report["rating"] in ("A", "B", "C", "D", "F")
        assert len(report["graph"]["nodes"]) == 5

        # detect_bottlenecks
        arch = {"architecture": {"components": [
            {"name": "db", "type": "database"},
            {"name": "config", "type": "core"},
        ]}}
        bneck = await agent.execute(
            "detect_bottlenecks",
            {"files": files, "architecture": arch},
            {},
        )
        assert bneck["type"] == "bottleneck_report"
        # config and db have highest in-degree — they should be expected
        for b in bneck["bottlenecks"]:
            if b["module"] in ("config", "db"):
                assert b["is_expected"] is True
