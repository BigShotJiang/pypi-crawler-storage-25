"""Tests for DetectBottlenecksSkill."""

from __future__ import annotations

import pytest

from kore_platform.agents.complexity.skills.detect_bottlenecks import (
    DetectBottlenecksSkill,
)


# ---------------------------------------------------------------------------
# Test files
# ---------------------------------------------------------------------------

HUB_FILES: dict[str, str] = {
    "main.py": "import db\nimport api\nimport cache\nimport auth\n",
    "api.py": "import db\n",
    "auth.py": "import db\n",
    "cache.py": "import db\n",
    "db.py": "DB = None\n",
}

FLAT_FILES: dict[str, str] = {
    "a.py": "x = 1\n",
    "b.py": "y = 2\n",
    "c.py": "z = 3\n",
}

SINGLE_FILE: dict[str, str] = {
    "main.py": "print('hello')\n",
}


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

class TestDetectBottlenecksSkill:
    @pytest.mark.asyncio
    async def test_empty_files(self):
        skill = DetectBottlenecksSkill()
        result = await skill.execute({"files": {}}, {})
        assert result["status"] == "completed"
        assert result["type"] == "bottleneck_report"
        assert result["bottlenecks"] == []
        assert result["total_bottlenecks"] == 0

    @pytest.mark.asyncio
    async def test_single_file(self):
        skill = DetectBottlenecksSkill()
        result = await skill.execute({"files": SINGLE_FILE}, {})
        assert result["total_bottlenecks"] == 0

    @pytest.mark.asyncio
    async def test_flat_no_bottlenecks(self):
        skill = DetectBottlenecksSkill()
        result = await skill.execute({"files": FLAT_FILES}, {})
        assert result["total_bottlenecks"] == 0

    @pytest.mark.asyncio
    async def test_hub_detected(self):
        skill = DetectBottlenecksSkill()
        result = await skill.execute({"files": HUB_FILES}, {})
        assert result["total_bottlenecks"] > 0
        module_names = [b["module"] for b in result["bottlenecks"]]
        assert "db" in module_names

    @pytest.mark.asyncio
    async def test_expected_bottleneck_with_architecture(self):
        skill = DetectBottlenecksSkill()
        arch = {
            "architecture": {
                "components": [
                    {"name": "db", "type": "database"},
                    {"name": "api", "type": "service"},
                ],
            },
        }
        result = await skill.execute(
            {"files": HUB_FILES, "architecture": arch}, {},
        )
        db_bottlenecks = [b for b in result["bottlenecks"] if b["module"] == "db"]
        if db_bottlenecks:
            assert db_bottlenecks[0]["is_expected"] is True

    @pytest.mark.asyncio
    async def test_unexpected_bottleneck_without_architecture(self):
        # utils is not in default expected cores if not a common name
        files = {
            "main.py": "import helper\nimport api\nimport worker\n",
            "api.py": "import helper\n",
            "worker.py": "import helper\n",
            "helper.py": "def do(): pass\n",
        }
        skill = DetectBottlenecksSkill()
        result = await skill.execute({"files": files, "architecture": {}}, {})
        # helper may or may not be detected depending on threshold
        for b in result["bottlenecks"]:
            if b["module"] == "helper":
                assert b["is_expected"] is False
                assert "Unexpected" in b["recommendation"]

    @pytest.mark.asyncio
    async def test_list_format_files(self):
        skill = DetectBottlenecksSkill()
        files_list = [
            {"path": "main.py", "content": "import db\n"},
            {"path": "db.py", "content": "x = 1\n"},
        ]
        result = await skill.execute({"files": files_list}, {})
        assert result["status"] == "completed"
        assert result["type"] == "bottleneck_report"
