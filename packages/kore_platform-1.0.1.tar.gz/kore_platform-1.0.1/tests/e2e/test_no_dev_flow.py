"""E2E test: non-developer flow."""

import pytest
from kore_platform.domain.entities.user_context import UserContext
from kore_platform.domain.value_objects.technical_level import TechnicalLevel


class TestNoDevFlow:
    def test_no_dev_context_creation(self, no_dev_context: UserContext) -> None:
        assert no_dev_context.level == TechnicalLevel.NO_DEV
        assert no_dev_context.test_coverage == 80  # default
        assert no_dev_context.preferred_stack == frozenset()

    def test_no_dev_flow_name(self) -> None:
        assert TechnicalLevel.NO_DEV.flow_name == "simple_flow"

    def test_no_dev_no_technical_questions(self) -> None:
        assert TechnicalLevel.NO_DEV.requires_technical_questions is False

    def test_no_dev_no_architecture_decisions(self) -> None:
        assert TechnicalLevel.NO_DEV.requires_architecture_decisions is False
