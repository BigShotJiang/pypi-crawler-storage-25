"""E2E test: developer flow."""

import pytest
from kore_platform.domain.entities.job import Job, JobStatus
from kore_platform.domain.entities.user_context import UserContext
from kore_platform.domain.value_objects.technical_level import TechnicalLevel


class TestDeveloperFlow:
    def test_job_lifecycle(self, sample_context: UserContext) -> None:
        job = Job.create("Build REST API")
        assert job.status == JobStatus.CREATED

        job = job.transition_to(JobStatus.INTERVIEWING, "Interviewing")
        assert job.status == JobStatus.INTERVIEWING

        job = job.transition_to(JobStatus.PLANNING, "Planning", context=sample_context)
        assert job.context is not None
        assert job.context.level == TechnicalLevel.DEV_SENIOR

        job = job.transition_to(JobStatus.EXECUTING, "Executing")
        job = job.transition_to(JobStatus.DELIVERING, "Delivering")
        job = job.transition_to(JobStatus.COMPLETED, "Done")
        assert job.status == JobStatus.COMPLETED
        assert len(job.events) == 6

    def test_developer_flow_name(self) -> None:
        assert TechnicalLevel.DEV_SENIOR.flow_name == "developer_flow"
        assert TechnicalLevel.DEV_JUNIOR.flow_name == "developer_flow"

    def test_developer_coverage(self) -> None:
        assert TechnicalLevel.DEV_SENIOR.default_test_coverage == 80
