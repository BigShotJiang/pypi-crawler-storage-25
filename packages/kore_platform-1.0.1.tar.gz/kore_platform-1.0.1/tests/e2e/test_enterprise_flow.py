"""E2E test: enterprise flow."""

import pytest
from kore_platform.domain.entities.job import Job, JobStatus
from kore_platform.domain.entities.user_context import UserContext
from kore_platform.domain.value_objects.technical_level import TechnicalLevel


class TestEnterpriseFlow:
    def test_engineer_full_lifecycle(self, engineer_context: UserContext) -> None:
        job = Job.create("Hexagonal architecture with CQRS")
        job = job.transition_to(JobStatus.INTERVIEWING, "Interview")
        job = job.transition_to(JobStatus.PLANNING, "Plan", context=engineer_context)
        job = job.transition_to(JobStatus.AWAITING_CONFIRMATION, "Confirm?")
        job = job.transition_to(JobStatus.EXECUTING, "Executing")
        job = job.transition_to(JobStatus.DELIVERING, "Delivering")
        job = job.transition_to(JobStatus.COMPLETED, "Done")

        assert job.status == JobStatus.COMPLETED
        assert job.context is not None
        assert job.context.level == TechnicalLevel.ENGINEER
        assert job.context.test_coverage == 95
        assert job.context.needs_monitoring is True
        assert "threat_model" in job.context.security_requirements
        assert len(job.events) == 7

    def test_enterprise_flow_name(self) -> None:
        assert TechnicalLevel.ENGINEER.flow_name == "enterprise_flow"

    def test_enterprise_requires_architecture(self) -> None:
        assert TechnicalLevel.ENGINEER.requires_architecture_decisions is True

    def test_engineer_context_has_security_reqs(self, engineer_context: UserContext) -> None:
        assert len(engineer_context.security_requirements) > 0
        assert len(engineer_context.compliance_requirements) > 0

    def test_cancellation_flow(self, engineer_context: UserContext) -> None:
        job = Job.create("Build system")
        job = job.transition_to(JobStatus.INTERVIEWING, "Interview")
        job = job.transition_to(JobStatus.PLANNING, "Plan", context=engineer_context)
        job = job.transition_to(JobStatus.CANCELLED, "User cancelled")
        assert job.status == JobStatus.CANCELLED
