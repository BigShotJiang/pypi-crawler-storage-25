"""Security tests — verify immutability constraints."""

import pytest
from kore_platform.domain.entities.user_context import UserContext
from kore_platform.domain.entities.job import Job, JobStatus
from kore_platform.domain.value_objects.job_id import JobId
from kore_platform.domain.value_objects.technical_level import TechnicalLevel
from kore_platform.infrastructure.security.guardian import Guardian


class TestImmutability:
    def test_user_context_frozen(self, sample_context: UserContext) -> None:
        with pytest.raises(AttributeError):
            sample_context.level = TechnicalLevel.ENGINEER  # type: ignore[misc]

    def test_job_id_frozen(self) -> None:
        jid = JobId.generate()
        with pytest.raises(AttributeError):
            jid.value = "hacked"  # type: ignore[misc]

    def test_job_frozen(self) -> None:
        job = Job.create("test")
        with pytest.raises(AttributeError):
            job.status = JobStatus.COMPLETED  # type: ignore[misc]

    def test_job_transition_preserves_original(self) -> None:
        original = Job.create("test")
        modified = original.transition_to(JobStatus.EXECUTING, "go")
        assert original.status == JobStatus.CREATED
        assert modified.status == JobStatus.EXECUTING

    def test_frozenset_requirements(self, sample_context: UserContext) -> None:
        with pytest.raises(AttributeError):
            sample_context.business_requirements.add("hack")  # type: ignore[union-attr]

    def test_guardian_dangerous_patterns_immutable(self) -> None:
        g = Guardian()
        with pytest.raises(AttributeError):
            g.dangerous_patterns.add("new_pattern")  # type: ignore[union-attr]
