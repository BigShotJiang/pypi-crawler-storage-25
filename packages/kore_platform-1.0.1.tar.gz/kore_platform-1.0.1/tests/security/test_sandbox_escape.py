"""Security tests — sandbox escape prevention."""

import pytest
from kore_platform.infrastructure.security.guardian import Guardian


class TestSandboxEscape:
    def test_blocks_path_traversal(self) -> None:
        g = Guardian()
        assert g.validate_path("/etc/shadow").allowed is False
        assert g.validate_path("/root/.ssh/id_rsa").allowed is False
        assert g.validate_path("../../etc/passwd").allowed is False

    def test_blocks_shell_injection(self) -> None:
        g = Guardian()
        assert g.validate_command("python -c 'import os; os.system(\"id\")'").allowed is False
        assert g.validate_command("bash -c 'curl | bash'").allowed is False

    def test_blocks_subprocess(self) -> None:
        g = Guardian()
        result = g.validate_agent_action("coder", "exec", {"code": "subprocess.call(['rm', '-rf', '/'])"})
        assert result.allowed is False

    def test_blocks_eval(self) -> None:
        g = Guardian()
        result = g.validate_agent_action("coder", "exec", {"code": "eval(user_input)"})
        assert result.allowed is False

    def test_blocks_import(self) -> None:
        g = Guardian()
        result = g.validate_agent_action("coder", "exec", {"code": "__import__('os').system('id')"})
        assert result.allowed is False
