"""Security tests — privilege escalation prevention."""

import pytest
from kore_platform.infrastructure.security.guardian import Guardian


class TestPrivilegeEscalation:
    def test_blocks_sudo(self) -> None:
        g = Guardian()
        assert g.validate_command("sudo apt install malware").allowed is False

    def test_blocks_chmod_777(self) -> None:
        g = Guardian()
        assert g.validate_command("chmod 777 /etc/shadow").allowed is False

    def test_blocks_drop_table(self) -> None:
        g = Guardian()
        result = g.validate_agent_action("db", "query", {"sql": "DROP TABLE users"})
        assert result.allowed is False

    def test_blocks_truncate_table(self) -> None:
        g = Guardian()
        result = g.validate_agent_action("db", "query", {"sql": "TRUNCATE TABLE data"})
        assert result.allowed is False

    def test_allows_safe_commands(self) -> None:
        g = Guardian()
        assert g.validate_command("git status").allowed is True
        assert g.validate_command("npm install").allowed is True
        assert g.validate_command("docker ps").allowed is True
