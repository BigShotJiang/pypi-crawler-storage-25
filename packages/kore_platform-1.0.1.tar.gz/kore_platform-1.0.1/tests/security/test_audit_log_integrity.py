"""Security tests — audit log hash chain integrity."""

import json
import pytest
from pathlib import Path
from kore_platform.infrastructure.adapters.outbound.immutable_audit_log import ImmutableAuditLog


class TestAuditLogIntegrity:
    @pytest.mark.asyncio
    async def test_integrity_verified_on_valid_log(self, audit_log: ImmutableAuditLog) -> None:
        job_id = "test-job-1"
        await audit_log.append(job_id, "EVENT_1", {"data": "test1"})
        await audit_log.append(job_id, "EVENT_2", {"data": "test2"})
        await audit_log.append(job_id, "EVENT_3", {"data": "test3"})
        assert await audit_log.verify_integrity(job_id) is True

    @pytest.mark.asyncio
    async def test_integrity_fails_on_tampered_data(self, audit_log: ImmutableAuditLog) -> None:
        job_id = "test-job-2"
        await audit_log.append(job_id, "EVENT_1", {"data": "original"})
        await audit_log.append(job_id, "EVENT_2", {"data": "test2"})

        log_file = audit_log.log_dir / f"{job_id}.jsonl"
        content = log_file.read_text()
        tampered = content.replace('"original"', '"TAMPERED"')
        log_file.write_text(tampered)

        assert await audit_log.verify_integrity(job_id) is False

    @pytest.mark.asyncio
    async def test_integrity_fails_on_deleted_entry(self, audit_log: ImmutableAuditLog) -> None:
        job_id = "test-job-3"
        await audit_log.append(job_id, "EVENT_1", {"data": "1"})
        await audit_log.append(job_id, "EVENT_2", {"data": "2"})
        await audit_log.append(job_id, "EVENT_3", {"data": "3"})

        log_file = audit_log.log_dir / f"{job_id}.jsonl"
        lines = log_file.read_text().strip().split("\n")
        log_file.write_text(lines[0] + "\n" + lines[2] + "\n")

        assert await audit_log.verify_integrity(job_id) is False

    @pytest.mark.asyncio
    async def test_empty_log_is_valid(self, audit_log: ImmutableAuditLog) -> None:
        assert await audit_log.verify_integrity("nonexistent") is True

    @pytest.mark.asyncio
    async def test_hash_chain_continuity(self, audit_log: ImmutableAuditLog) -> None:
        job_id = "test-job-4"
        await audit_log.append(job_id, "A", {})
        await audit_log.append(job_id, "B", {})

        log_file = audit_log.log_dir / f"{job_id}.jsonl"
        lines = log_file.read_text().strip().split("\n")
        entry1 = json.loads(lines[0])
        entry2 = json.loads(lines[1])

        assert entry1["prev_hash"] == "genesis"
        assert entry2["prev_hash"] == entry1["hash"]

    @pytest.mark.asyncio
    async def test_get_entries(self, audit_log: ImmutableAuditLog) -> None:
        job_id = "test-job-5"
        await audit_log.append(job_id, "A", {"n": 1})
        await audit_log.append(job_id, "B", {"n": 2})
        entries = await audit_log.get_entries(job_id)
        assert len(entries) == 2
        assert entries[0]["event_type"] == "A"
