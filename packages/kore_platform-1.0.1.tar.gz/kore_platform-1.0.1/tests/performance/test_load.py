"""Performance tests — ensure operations complete within bounds."""

import asyncio
import time
import pytest

from kore_platform.domain.entities.job import Job, JobStatus
from kore_platform.domain.value_objects.job_id import JobId
from kore_platform.infrastructure.adapters.outbound.memory_bus import MemoryBus
from kore_platform.infrastructure.adapters.outbound.immutable_audit_log import ImmutableAuditLog


class TestPerformance:
    def test_job_creation_under_1ms(self) -> None:
        t0 = time.perf_counter()
        for _ in range(1000):
            Job.create("test idea")
        elapsed = time.perf_counter() - t0
        assert elapsed < 1.0, f"1000 job creations took {elapsed:.3f}s"

    def test_job_id_generation_under_1ms(self) -> None:
        t0 = time.perf_counter()
        for _ in range(1000):
            JobId.generate()
        elapsed = time.perf_counter() - t0
        assert elapsed < 1.0, f"1000 JobId generations took {elapsed:.3f}s"

    def test_state_transitions_under_1ms(self) -> None:
        job = Job.create("test")
        t0 = time.perf_counter()
        for i in range(100):
            job = job.transition_to(JobStatus.EXECUTING, f"step {i}")
        elapsed = time.perf_counter() - t0
        assert elapsed < 0.5, f"100 transitions took {elapsed:.3f}s"

    @pytest.mark.asyncio
    async def test_bus_throughput(self) -> None:
        bus = MemoryBus()
        t0 = time.perf_counter()
        for i in range(1000):
            await bus.enqueue("perf_q", {"i": i})
        for _ in range(1000):
            await bus.dequeue("perf_q")
        elapsed = time.perf_counter() - t0
        assert elapsed < 1.0, f"1000 enqueue+dequeue took {elapsed:.3f}s"

    @pytest.mark.asyncio
    async def test_audit_log_throughput(self, tmp_path) -> None:
        log = ImmutableAuditLog(log_dir=tmp_path / "perf")
        t0 = time.perf_counter()
        for i in range(100):
            await log.append("perf-job", f"EVENT_{i}", {"n": i})
        elapsed = time.perf_counter() - t0
        assert elapsed < 2.0, f"100 audit entries took {elapsed:.3f}s"

        t0 = time.perf_counter()
        assert await log.verify_integrity("perf-job") is True
        elapsed = time.perf_counter() - t0
        assert elapsed < 1.0, f"Integrity check took {elapsed:.3f}s"
