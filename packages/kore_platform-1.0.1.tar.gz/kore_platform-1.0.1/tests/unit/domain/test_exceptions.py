"""Tests for domain exceptions."""

import pytest
from kore_platform.domain.exceptions.base import KorePlatformError, DomainError
from kore_platform.domain.exceptions.security import (
    SecurityError, SignatureVerificationError, AuditLogTamperingError,
)
from kore_platform.domain.exceptions.validation import (
    ValidationError, InvalidJobIdError, InvalidFlowError,
)


class TestExceptions:
    def test_kore_error_has_code(self) -> None:
        err = KorePlatformError("test", code="TEST")
        assert err.code == "TEST"
        assert str(err) == "test"

    def test_domain_error(self) -> None:
        err = DomainError("bad logic")
        assert err.code == "DOMAIN_ERROR"

    def test_security_error(self) -> None:
        err = SecurityError("blocked")
        assert err.code == "SECURITY_ERROR"

    def test_signature_error(self) -> None:
        err = SignatureVerificationError("bad sig")
        assert err.code == "SIGNATURE_INVALID"

    def test_audit_tampering(self) -> None:
        err = AuditLogTamperingError("chain broken")
        assert err.code == "AUDIT_TAMPERED"

    def test_validation_error_has_field(self) -> None:
        err = ValidationError("bad value", field="email")
        assert err.field == "email"

    def test_invalid_job_id(self) -> None:
        err = InvalidJobIdError("abc")
        assert "abc" in str(err)
        assert err.code == "INVALID_JOB_ID"

    def test_hierarchy(self) -> None:
        assert issubclass(SecurityError, KorePlatformError)
        assert issubclass(ValidationError, KorePlatformError)
        assert issubclass(SignatureVerificationError, SecurityError)
