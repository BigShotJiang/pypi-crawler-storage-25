"""Tests for TechnicalLevel value object."""

from kore_platform.domain.value_objects.technical_level import TechnicalLevel


class TestTechnicalLevel:
    def test_no_dev_no_technical_questions(self) -> None:
        assert TechnicalLevel.NO_DEV.requires_technical_questions is False

    def test_engineer_requires_architecture(self) -> None:
        assert TechnicalLevel.ENGINEER.requires_architecture_decisions is True

    def test_senior_requires_technical_questions(self) -> None:
        assert TechnicalLevel.DEV_SENIOR.requires_technical_questions is True

    def test_junior_no_architecture(self) -> None:
        assert TechnicalLevel.DEV_JUNIOR.requires_architecture_decisions is False

    def test_coverage_levels(self) -> None:
        assert TechnicalLevel.NO_DEV.default_test_coverage == 0
        assert TechnicalLevel.DEV_JUNIOR.default_test_coverage == 60
        assert TechnicalLevel.DEV_SENIOR.default_test_coverage == 80
        assert TechnicalLevel.ENGINEER.default_test_coverage == 95

    def test_flow_names(self) -> None:
        assert TechnicalLevel.NO_DEV.flow_name == "simple_flow"
        assert TechnicalLevel.DEV_JUNIOR.flow_name == "developer_flow"
        assert TechnicalLevel.ENGINEER.flow_name == "enterprise_flow"
