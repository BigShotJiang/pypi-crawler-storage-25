"""Tests for Job entity."""

import pytest
from kore_platform.domain.entities.job import Job, JobStatus, JobEvent
from kore_platform.domain.entities.user_context import UserContext
from kore_platform.domain.value_objects.technical_level import TechnicalLevel


class TestJob:
    def test_create_sets_status_created(self) -> None:
        job = Job.create("Build an app")
        assert job.status == JobStatus.CREATED
        assert job.context is None
        assert len(job.events) == 1

    def test_create_records_idea_in_event(self) -> None:
        job = Job.create("Build an app")
        assert job.events[0].metadata["original_idea"] == "Build an app"

    def test_transition_creates_new_job(self) -> None:
        job1 = Job.create("Build an app")
        job2 = job1.transition_to(JobStatus.INTERVIEWING, "Starting")
        assert job1.status == JobStatus.CREATED
        assert job2.status == JobStatus.INTERVIEWING
        assert job1.id == job2.id

    def test_transition_appends_event(self) -> None:
        job = Job.create("x")
        job = job.transition_to(JobStatus.INTERVIEWING, "s1")
        job = job.transition_to(JobStatus.PLANNING, "s2")
        assert len(job.events) == 3

    def test_transition_with_context(self, sample_context: UserContext) -> None:
        job = Job.create("Build API")
        job = job.transition_to(
            JobStatus.PLANNING, "Planned", context=sample_context,
        )
        assert job.context is not None
        assert job.context.level == TechnicalLevel.DEV_SENIOR

    def test_immutable(self) -> None:
        job = Job.create("x")
        with pytest.raises(AttributeError):
            job.status = JobStatus.FAILED  # type: ignore[misc]

    def test_duration(self) -> None:
        job = Job.create("x")
        assert job.duration_seconds >= 0
