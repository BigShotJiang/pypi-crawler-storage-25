"""Tests for domain events."""

from kore_platform.domain.events.base import DomainEvent
from kore_platform.domain.events.job_events import JobCreated, JobCompleted, JobFailed
from kore_platform.domain.events.agent_events import AgentTaskStarted, AgentTaskCompleted


class TestDomainEvents:
    def test_base_event_has_id_and_timestamp(self) -> None:
        event = DomainEvent()
        assert event.event_id
        assert event.timestamp

    def test_event_to_dict(self) -> None:
        event = DomainEvent(aggregate_id="job-1", data={"key": "val"})
        d = event.to_dict()
        assert d["aggregate_id"] == "job-1"
        assert d["data"] == {"key": "val"}

    def test_job_created_event(self) -> None:
        event = JobCreated(idea="Build app")
        assert event.event_type == "job.created"
        assert event.idea == "Build app"

    def test_job_completed_event(self) -> None:
        event = JobCompleted(duration_seconds=42.5, delivery_type="technical")
        assert event.duration_seconds == 42.5

    def test_agent_task_started(self) -> None:
        event = AgentTaskStarted(agent_name="coder", action="write_code")
        assert event.event_type == "agent.task_started"

    def test_events_are_immutable(self) -> None:
        event = JobCreated()
        import pytest
        with pytest.raises(AttributeError):
            event.idea = "modified"  # type: ignore[misc]
