"""Tests for JobId value object."""

import pytest
from kore_platform.domain.value_objects.job_id import JobId


class TestJobId:
    def test_generate_creates_valid_uuid4(self) -> None:
        job_id = JobId.generate()
        assert len(job_id.value) == 36
        assert job_id.value[14] == "4"

    def test_invalid_format_raises(self) -> None:
        with pytest.raises(ValueError, match="Invalid JobId"):
            JobId("not-a-uuid")

    def test_immutable(self) -> None:
        job_id = JobId.generate()
        with pytest.raises(AttributeError):
            job_id.value = "modified"  # type: ignore[misc]

    def test_str_returns_value(self) -> None:
        job_id = JobId.generate()
        assert str(job_id) == job_id.value

    def test_equality(self) -> None:
        val = "12345678-1234-4123-8123-123456789abc"
        assert JobId(val) == JobId(val)

    def test_different_ids_not_equal(self) -> None:
        assert JobId.generate() != JobId.generate()
