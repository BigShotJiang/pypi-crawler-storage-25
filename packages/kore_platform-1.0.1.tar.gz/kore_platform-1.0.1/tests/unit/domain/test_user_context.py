"""Tests for UserContext entity."""

import pytest
from kore_platform.domain.entities.user_context import UserContext
from kore_platform.domain.value_objects.technical_level import TechnicalLevel


class TestUserContext:
    def test_immutable(self, sample_context: UserContext) -> None:
        with pytest.raises(AttributeError):
            sample_context.level = TechnicalLevel.NO_DEV  # type: ignore[misc]

    def test_with_updated_requirements_creates_new(self, sample_context: UserContext) -> None:
        new_reqs = frozenset({"new req"})
        updated = sample_context.with_updated_requirements(business=new_reqs)
        assert updated.business_requirements == new_reqs
        assert sample_context.business_requirements != new_reqs  # original unchanged

    def test_default_values(self) -> None:
        ctx = UserContext(
            level=TechnicalLevel.NO_DEV,
            original_idea="sell paintings",
            problem_to_solve="need online store",
            target_users="art collectors",
        )
        assert ctx.preferred_stack == frozenset()
        assert ctx.architecture_pattern is None
        assert ctx.test_coverage == 80
        assert ctx.needs_ci_cd is True
