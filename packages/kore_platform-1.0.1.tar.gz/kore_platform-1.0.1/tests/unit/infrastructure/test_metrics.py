"""Tests for MetricsCollector."""

from kore_platform.infrastructure.observability.metrics import MetricsCollector


class TestMetricsCollector:
    def test_increment(self) -> None:
        m = MetricsCollector()
        m.increment("requests_total")
        m.increment("requests_total")
        output = m.export_prometheus()
        assert "requests_total 2" in output

    def test_gauge(self) -> None:
        m = MetricsCollector()
        m.gauge("active_jobs", 5)
        output = m.export_prometheus()
        assert "active_jobs 5" in output

    def test_histogram(self) -> None:
        m = MetricsCollector()
        m.observe("request_duration", 0.1)
        m.observe("request_duration", 0.2)
        output = m.export_prometheus()
        assert "request_duration_count 2" in output
        assert "request_duration_sum" in output

    def test_timer(self) -> None:
        m = MetricsCollector()
        with m.timer("op_duration"):
            pass  # instant
        output = m.export_prometheus()
        assert "op_duration_count 1" in output

    def test_labels(self) -> None:
        m = MetricsCollector()
        m.increment("http_requests", labels={"method": "GET", "status": "200"})
        output = m.export_prometheus()
        assert 'method="GET"' in output
