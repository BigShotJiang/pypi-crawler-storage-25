"""Tests for SignatureVerifier."""

import pytest
from pathlib import Path
from kore_platform.infrastructure.security.signature_verifier import SignatureVerifier
from kore_platform.domain.exceptions.security import SignatureVerificationError


class TestSignatureVerifier:
    def test_sign_and_verify(self, tmp_path: Path) -> None:
        key = b"test-signing-key-32-bytes-long!!"
        config_path = tmp_path / "test.yaml"
        config_path.write_text("name: test\nsteps: []")

        SignatureVerifier.sign_file(config_path, key)

        verifier = SignatureVerifier(signing_key=key)
        data = verifier.verify_and_load(config_path)
        assert data["name"] == "test"

    def test_tampered_file_fails(self, tmp_path: Path) -> None:
        key = b"test-signing-key-32-bytes-long!!"
        config_path = tmp_path / "test.yaml"
        config_path.write_text("name: original")

        SignatureVerifier.sign_file(config_path, key)
        config_path.write_text("name: tampered")

        verifier = SignatureVerifier(signing_key=key)
        with pytest.raises(SignatureVerificationError):
            verifier.verify_and_load(config_path)

    def test_unsigned_file_loads_with_warning(self, tmp_path: Path) -> None:
        config_path = tmp_path / "unsigned.yaml"
        config_path.write_text("name: unsigned")

        verifier = SignatureVerifier(signing_key=b"key")
        data = verifier.verify_and_load(config_path)
        assert data["name"] == "unsigned"
