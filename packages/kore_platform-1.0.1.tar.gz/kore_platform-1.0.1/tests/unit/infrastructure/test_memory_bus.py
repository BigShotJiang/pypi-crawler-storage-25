"""Tests for MemoryBus."""

import pytest
from kore_platform.infrastructure.adapters.outbound.memory_bus import MemoryBus


class TestMemoryBus:
    @pytest.mark.asyncio
    async def test_cache_set_and_get(self, bus: MemoryBus) -> None:
        await bus.cache_set("k1", {"x": 42}, ttl=60)
        result = await bus.cache_get("k1")
        assert result == {"x": 42}

    @pytest.mark.asyncio
    async def test_cache_miss(self, bus: MemoryBus) -> None:
        result = await bus.cache_get("nonexistent")
        assert result is None

    @pytest.mark.asyncio
    async def test_queue_enqueue_dequeue(self, bus: MemoryBus) -> None:
        await bus.enqueue("q1", {"task": "test"})
        item = await bus.dequeue("q1")
        assert item is not None
        assert item["task"] == "test"

    @pytest.mark.asyncio
    async def test_queue_empty(self, bus: MemoryBus) -> None:
        result = await bus.dequeue("empty_q")
        assert result is None

    @pytest.mark.asyncio
    async def test_pubsub(self, bus: MemoryBus) -> None:
        received: list[dict] = []

        async def handler(msg: dict) -> None:
            received.append(msg)

        await bus.subscribe("ch1", handler)
        await bus.publish("ch1", {"data": "hello"})
        assert len(received) == 1
        assert received[0]["data"] == "hello"

    @pytest.mark.asyncio
    async def test_log_and_history(self, bus: MemoryBus) -> None:
        await bus.log("stream1", {"event": "test", "n": 1})
        await bus.log("stream1", {"event": "test", "n": 2})
        history = await bus.history("stream1")
        assert len(history) == 2
        assert history[0]["n"] == 1
        assert history[1]["n"] == 2

    @pytest.mark.asyncio
    async def test_history_limit(self, bus: MemoryBus) -> None:
        for i in range(10):
            await bus.log("s", {"i": i})
        history = await bus.history("s", count=3)
        assert len(history) == 3
        assert history[0]["i"] == 7
