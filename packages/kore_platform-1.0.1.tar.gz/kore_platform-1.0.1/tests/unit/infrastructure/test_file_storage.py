"""Tests for FileStorage."""

import pytest
from kore_platform.infrastructure.adapters.outbound.file_storage import FileStorage


class TestFileStorage:
    @pytest.mark.asyncio
    async def test_save_and_load(self, storage: FileStorage) -> None:
        await storage.save("jobs", "j1", {"name": "test"})
        data = await storage.load("jobs", "j1")
        assert data is not None
        assert data["name"] == "test"

    @pytest.mark.asyncio
    async def test_load_missing(self, storage: FileStorage) -> None:
        result = await storage.load("jobs", "missing")
        assert result is None

    @pytest.mark.asyncio
    async def test_delete(self, storage: FileStorage) -> None:
        await storage.save("jobs", "j2", {"x": 1})
        await storage.delete("jobs", "j2")
        assert await storage.load("jobs", "j2") is None

    @pytest.mark.asyncio
    async def test_list_keys(self, storage: FileStorage) -> None:
        await storage.save("col", "a1", {})
        await storage.save("col", "a2", {})
        await storage.save("col", "b1", {})
        keys = await storage.list_keys("col", prefix="a")
        assert len(keys) == 2

    @pytest.mark.asyncio
    async def test_save_and_load_artifact(self, storage: FileStorage) -> None:
        path = await storage.save_artifact("job1", "output.txt", b"hello world")
        assert path
        data = await storage.load_artifact("job1", "output.txt")
        assert data == b"hello world"

    @pytest.mark.asyncio
    async def test_load_missing_artifact(self, storage: FileStorage) -> None:
        result = await storage.load_artifact("nope", "nope.txt")
        assert result is None
