"""Tests for Guardian security."""

from kore_platform.infrastructure.security.guardian import Guardian


class TestGuardian:
    def test_blocks_rm_rf(self) -> None:
        g = Guardian()
        result = g.validate_command("rm -rf /")
        assert result.allowed is False

    def test_blocks_sudo(self) -> None:
        g = Guardian()
        result = g.validate_command("sudo apt install")
        assert result.allowed is False

    def test_allows_python(self) -> None:
        g = Guardian()
        result = g.validate_command("python script.py")
        assert result.allowed is True

    def test_allows_pytest(self) -> None:
        g = Guardian()
        result = g.validate_command("pytest tests/")
        assert result.allowed is True

    def test_blocks_unknown_command(self) -> None:
        g = Guardian()
        result = g.validate_command("malicious_binary --payload")
        assert result.allowed is False

    def test_validates_allowed_path(self) -> None:
        g = Guardian()
        result = g.validate_path("/workspace/project/file.py")
        assert result.allowed is True

    def test_blocks_disallowed_path(self) -> None:
        g = Guardian()
        result = g.validate_path("/etc/passwd")
        assert result.allowed is False

    def test_validates_agent_action_clean(self) -> None:
        g = Guardian()
        result = g.validate_agent_action("coder", "write_code", {"file": "main.py"})
        assert result.allowed is True

    def test_blocks_agent_dangerous_input(self) -> None:
        g = Guardian()
        result = g.validate_agent_action("coder", "exec", {"cmd": "rm -rf /"})
        assert result.allowed is False

    def test_audit_log_records(self) -> None:
        g = Guardian()
        g.validate_command("python test.py")
        g.validate_command("rm -rf /")
        audit = g.get_audit()
        assert len(audit) == 2
        assert audit[0]["allowed"] is True
        assert audit[1]["allowed"] is False
