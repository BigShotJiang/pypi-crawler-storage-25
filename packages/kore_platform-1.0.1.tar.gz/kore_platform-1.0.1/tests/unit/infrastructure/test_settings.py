"""Tests for Settings."""

from kore_platform.infrastructure.config.settings import Settings


class TestSettings:
    def test_defaults(self) -> None:
        s = Settings()
        assert s.environment == "development"
        assert s.debug is False
        assert s.redis_port == 6379

    def test_immutable(self) -> None:
        s = Settings()
        import pytest
        with pytest.raises(AttributeError):
            s.environment = "production"  # type: ignore[misc]

    def test_from_env(self, monkeypatch) -> None:
        monkeypatch.setenv("KORE_ENVIRONMENT", "staging")
        monkeypatch.setenv("KORE_DEBUG", "true")
        s = Settings.from_env()
        assert s.environment == "staging"
        assert s.debug is True
