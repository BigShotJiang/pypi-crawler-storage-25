"""Tests for DTOs."""

from kore_platform.application.dto.job_dto import JobResultDTO, JobStatusDTO
from kore_platform.application.dto.interview_dto import InterviewQuestionDTO, InterviewAnswerDTO
from kore_platform.application.dto.delivery_dto import DeliveryDTO


class TestJobResultDTO:
    def test_to_dict(self) -> None:
        dto = JobResultDTO(job_id="123", status="success", message="Done")
        d = dto.to_dict()
        assert d["job_id"] == "123"
        assert d["status"] == "success"

    def test_immutable(self) -> None:
        dto = JobResultDTO(job_id="123", status="ok")
        import pytest
        with pytest.raises(AttributeError):
            dto.status = "changed"  # type: ignore[misc]


class TestDeliveryDTO:
    def test_to_dict(self) -> None:
        dto = DeliveryDTO(
            type="enterprise",
            artifacts={"repo": "url"},
            urls={"docs": "url"},
        )
        d = dto.to_dict()
        assert d["type"] == "enterprise"
        assert d["artifacts"]["repo"] == "url"


class TestInterviewDTOs:
    def test_question_with_options(self) -> None:
        q = InterviewQuestionDTO(
            id="q1", text="Choose stack",
            options=("Python", "Node", "Go"),
        )
        assert len(q.options) == 3

    def test_answer_confidence(self) -> None:
        a = InterviewAnswerDTO(question_id="q1", answer="Python", confidence=0.95)
        assert a.confidence == 0.95
