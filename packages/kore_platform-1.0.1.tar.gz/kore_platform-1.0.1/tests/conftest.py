"""Shared test fixtures."""

from __future__ import annotations

import asyncio
from pathlib import Path
from typing import Any

import pytest

from kore_platform.domain.entities.user_context import UserContext
from kore_platform.domain.entities.job import Job, JobStatus
from kore_platform.domain.value_objects.job_id import JobId
from kore_platform.domain.value_objects.technical_level import TechnicalLevel
from kore_platform.infrastructure.adapters.outbound.memory_bus import MemoryBus
from kore_platform.infrastructure.adapters.outbound.immutable_audit_log import ImmutableAuditLog
from kore_platform.infrastructure.adapters.outbound.file_storage import FileStorage
from kore_platform.infrastructure.security.guardian import Guardian


@pytest.fixture
def bus() -> MemoryBus:
    return MemoryBus()


@pytest.fixture
def guardian() -> Guardian:
    return Guardian()


@pytest.fixture
def audit_log(tmp_path: Path) -> ImmutableAuditLog:
    return ImmutableAuditLog(log_dir=tmp_path / "audit")


@pytest.fixture
def storage(tmp_path: Path) -> FileStorage:
    return FileStorage(base_path=tmp_path / "storage")


@pytest.fixture
def job_id() -> JobId:
    return JobId.generate()


@pytest.fixture
def sample_context() -> UserContext:
    return UserContext(
        level=TechnicalLevel.DEV_SENIOR,
        original_idea="Build a REST API for managing tasks",
        problem_to_solve="Need task management for our team",
        target_users="Development teams",
        preferred_stack=frozenset({"python", "fastapi", "postgresql"}),
        architecture_pattern="hexagonal",
        deployment_target="docker",
        business_requirements=frozenset({"CRUD tasks", "user auth", "team management"}),
        technical_requirements=frozenset({"REST API", "JWT auth", "PostgreSQL"}),
        test_coverage=80,
        needs_ci_cd=True,
    )


@pytest.fixture
def sample_job() -> Job:
    return Job.create("Build a REST API for managing tasks")


@pytest.fixture
def no_dev_context() -> UserContext:
    return UserContext(
        level=TechnicalLevel.NO_DEV,
        original_idea="I want to sell my paintings online",
        problem_to_solve="Need an online store for art",
        target_users="Art collectors",
    )


@pytest.fixture
def engineer_context() -> UserContext:
    return UserContext(
        level=TechnicalLevel.ENGINEER,
        original_idea="Hexagonal architecture API with CQRS and event sourcing",
        problem_to_solve="Need a scalable event-driven system",
        target_users="Enterprise teams",
        preferred_stack=frozenset({"python", "fastapi", "kafka", "postgresql"}),
        architecture_pattern="hexagonal",
        deployment_target="kubernetes",
        test_coverage=95,
        needs_ci_cd=True,
        needs_monitoring=True,
        security_requirements=frozenset({"threat_model", "sast", "dependency_scan"}),
        compliance_requirements=frozenset({"SOC2"}),
    )
