"""Integration tests for orchestrator."""

import pytest
from kore_platform.infrastructure.adapters.outbound.memory_bus import MemoryBus
from kore_platform.infrastructure.adapters.outbound.immutable_audit_log import ImmutableAuditLog
from kore_platform.infrastructure.security.guardian import Guardian


class TestOrchestratorIntegration:
    @pytest.mark.asyncio
    async def test_bus_and_guardian_together(self, bus: MemoryBus) -> None:
        guardian = Guardian()
        result = guardian.validate_command("python main.py")
        assert result.allowed is True

        await bus.log("guardian", {"action": "validate", "allowed": True})
        history = await bus.history("guardian")
        assert len(history) == 1

    @pytest.mark.asyncio
    async def test_audit_log_with_bus(
        self, bus: MemoryBus, audit_log: ImmutableAuditLog,
    ) -> None:
        job_id = "integration-test-1"
        hash1 = await audit_log.append(job_id, "START", {"bus": "memory"})
        assert hash1
        await bus.cache_set(f"audit:{job_id}", hash1)
        cached = await bus.cache_get(f"audit:{job_id}")
        assert cached == hash1

    @pytest.mark.asyncio
    async def test_full_audit_chain(self, audit_log: ImmutableAuditLog) -> None:
        job_id = "chain-test"
        for i in range(10):
            await audit_log.append(job_id, f"STEP_{i}", {"step": i})
        assert await audit_log.verify_integrity(job_id) is True
        entries = await audit_log.get_entries(job_id)
        assert len(entries) == 10
