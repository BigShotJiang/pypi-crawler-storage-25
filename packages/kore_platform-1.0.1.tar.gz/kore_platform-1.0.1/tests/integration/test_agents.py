"""Integration tests for agents availability."""

import pytest
from pathlib import Path
import importlib


AGENTS_DIR = Path(__file__).resolve().parent.parent.parent / "src" / "kore_platform" / "agents"


class TestAgentsStructure:
    def test_base_agent_exists(self) -> None:
        assert (AGENTS_DIR / "base" / "agent.py").exists()

    def test_all_agent_directories_exist(self) -> None:
        expected = [
            "specs", "architect", "coder", "tester", "reviewer",
            "security", "deployer", "documenter", "monitor",
        ]
        for agent in expected:
            assert (AGENTS_DIR / agent).is_dir(), f"Missing agent: {agent}"

    def test_all_agents_have_init(self) -> None:
        for agent_dir in AGENTS_DIR.iterdir():
            if agent_dir.is_dir() and not agent_dir.name.startswith("_"):
                assert (agent_dir / "__init__.py").exists(), f"Missing __init__.py in {agent_dir.name}"

    def test_all_agents_have_skills_dir(self) -> None:
        skill_agents = [
            "specs", "architect", "coder", "tester", "reviewer",
            "security", "deployer", "documenter", "monitor",
        ]
        for agent in skill_agents:
            skills_dir = AGENTS_DIR / agent / "skills"
            assert skills_dir.is_dir(), f"Missing skills/ in {agent}"
