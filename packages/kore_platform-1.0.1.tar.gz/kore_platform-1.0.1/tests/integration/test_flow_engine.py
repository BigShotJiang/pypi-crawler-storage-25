"""Integration tests for flow engine YAML loading."""

import pytest
from pathlib import Path
import yaml


FLOWS_DIR = Path(__file__).resolve().parent.parent.parent / "flows"


class TestFlowYAML:
    def test_all_flows_are_valid_yaml(self) -> None:
        for flow_file in FLOWS_DIR.glob("*.yaml"):
            with open(flow_file) as f:
                data = yaml.safe_load(f)
            assert "name" in data, f"{flow_file.name} missing 'name'"
            assert "steps" in data, f"{flow_file.name} missing 'steps'"

    def test_simple_flow_exists(self) -> None:
        assert (FLOWS_DIR / "simple_flow.yaml").exists()

    def test_developer_flow_exists(self) -> None:
        assert (FLOWS_DIR / "developer_flow.yaml").exists()

    def test_enterprise_flow_exists(self) -> None:
        assert (FLOWS_DIR / "enterprise_flow.yaml").exists()

    def test_enterprise_flow_has_security_steps(self) -> None:
        with open(FLOWS_DIR / "enterprise_flow.yaml") as f:
            data = yaml.safe_load(f)
        steps_str = str(data["steps"])
        assert "security" in steps_str.lower()
        assert "sast" in steps_str.lower() or "security_review" in steps_str.lower()

    def test_all_flows_have_alerts(self) -> None:
        for flow_file in FLOWS_DIR.glob("*.yaml"):
            with open(flow_file) as f:
                data = yaml.safe_load(f)
            assert "alerts" in data, f"{flow_file.name} missing 'alerts'"
