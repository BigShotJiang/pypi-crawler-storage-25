# Contributing to Kore Platform

Thank you for considering a contribution to Kore Platform. This document explains
the process and expectations so that your contribution can be reviewed and merged
as smoothly as possible.

## Code of Conduct

By participating in this project you agree to treat every contributor with respect
and professionalism. Harassment, discrimination, or hostile behaviour of any kind
will not be tolerated.

## Getting Started

1. **Fork** the repository and clone your fork locally.
2. Create a **virtual environment** and install dev dependencies:

   ```bash
   python3 -m venv .venv
   source .venv/bin/activate
   make dev
   ```

3. Create a **feature branch** from `main`:

   ```bash
   git checkout -b feat/my-feature main
   ```

## Development Workflow

### Branch Naming

| Prefix     | Purpose                  |
|------------|--------------------------|
| `feat/`    | New feature              |
| `fix/`     | Bug fix                  |
| `refactor/`| Code restructuring       |
| `docs/`    | Documentation only       |
| `test/`    | Test additions/changes   |
| `ci/`      | CI/CD pipeline changes   |

### Code Quality

All code must pass the following checks before merging:

```bash
make lint         # Ruff linting
make format       # Auto-format (run before committing)
make type-check   # Mypy strict mode
make test         # Full test suite
```

Pre-commit hooks will enforce most of these automatically. Install them with:

```bash
pre-commit install
```

### Commit Messages

Follow [Conventional Commits](https://www.conventionalcommits.org/):

```
feat(engine): add retry logic for transient LLM failures
fix(signing): handle empty flow body edge case
docs(readme): update architecture diagram
```

### Testing

- Every new feature or bug fix must include tests.
- Maintain coverage above **80%**.
- Use `pytest.mark.integration` for tests that need external services.
- Use `pytest.mark.slow` for long-running tests.

```bash
make coverage   # Run tests with coverage report
```

## Pull Request Process

1. Ensure all CI checks pass.
2. Update `CHANGELOG.md` under an `[Unreleased]` section.
3. Fill out the PR template completely.
4. Request review from at least one maintainer.
5. Squash-merge is the default merge strategy.

### PR Checklist

- [ ] Branch is up to date with `main`.
- [ ] All new and existing tests pass.
- [ ] Linting, formatting, and type checks pass.
- [ ] Documentation is updated if needed.
- [ ] `CHANGELOG.md` is updated.
- [ ] No secrets or credentials are included.

## Security

If you discover a security vulnerability, **do not open a public issue**. Follow
the process described in [SECURITY.md](SECURITY.md).

## Architecture Decisions

Significant changes to architecture should be proposed as an **Architecture
Decision Record (ADR)** in `docs/adr/`. Use the template in
`docs/adr/000-template.md` if available.

## License

By contributing, you agree that your contributions will be licensed under the
[MIT License](LICENSE).
