#!/usr/bin/env bash
# setup_dev.sh -- Bootstrap local development environment for Kore Platform.
#
# Usage:
#   chmod +x scripts/setup_dev.sh
#   ./scripts/setup_dev.sh

set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
VENV_DIR="${REPO_ROOT}/.venv"
PYTHON="${PYTHON:-python3}"

# ── Colours ──────────────────────────────────────────────────────────
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Colour

info()  { echo -e "${GREEN}[INFO]${NC}  $*"; }
warn()  { echo -e "${YELLOW}[WARN]${NC}  $*"; }
error() { echo -e "${RED}[ERROR]${NC} $*" >&2; }

# ── Pre-flight checks ───────────────────────────────────────────────
info "Checking Python version..."
if ! command -v "${PYTHON}" &>/dev/null; then
    error "Python not found. Please install Python 3.11+."
    exit 1
fi

PY_VERSION=$("${PYTHON}" -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')
PY_MAJOR=$("${PYTHON}" -c 'import sys; print(sys.version_info.major)')
PY_MINOR=$("${PYTHON}" -c 'import sys; print(sys.version_info.minor)')

if [ "${PY_MAJOR}" -lt 3 ] || { [ "${PY_MAJOR}" -eq 3 ] && [ "${PY_MINOR}" -lt 11 ]; }; then
    error "Python 3.11+ is required. Found: ${PY_VERSION}"
    exit 1
fi
info "Found Python ${PY_VERSION}"

# ── Virtual environment ──────────────────────────────────────────────
if [ ! -d "${VENV_DIR}" ]; then
    info "Creating virtual environment at ${VENV_DIR}..."
    "${PYTHON}" -m venv "${VENV_DIR}"
else
    warn "Virtual environment already exists at ${VENV_DIR}. Reusing."
fi

# Activate
# shellcheck disable=SC1091
source "${VENV_DIR}/bin/activate"
info "Activated virtual environment."

# ── Upgrade pip ──────────────────────────────────────────────────────
info "Upgrading pip..."
pip install --quiet --upgrade pip setuptools wheel

# ── Install dependencies ─────────────────────────────────────────────
info "Installing kore-platform with all extras + dev tools..."
pip install --quiet -e "${REPO_ROOT}[all,dev]"

# ── Pre-commit hooks ────────────────────────────────────────────────
if command -v pre-commit &>/dev/null; then
    info "Installing pre-commit hooks..."
    pre-commit install
else
    warn "pre-commit not found after install. Skipping hook setup."
fi

# ── Create project directories ───────────────────────────────────────
info "Ensuring project directories exist..."
DIRS=(
    "${REPO_ROOT}/flows"
    "${REPO_ROOT}/docs"
    "${REPO_ROOT}/docs/adr"
    "${REPO_ROOT}/tests"
    "${REPO_ROOT}/tests/unit"
    "${REPO_ROOT}/tests/integration"
    "${REPO_ROOT}/src/kore_platform"
)

for dir in "${DIRS[@]}"; do
    mkdir -p "${dir}"
done

# ── Create placeholder __init__.py files ─────────────────────────────
for init in \
    "${REPO_ROOT}/src/kore_platform/__init__.py" \
    "${REPO_ROOT}/tests/__init__.py" \
    "${REPO_ROOT}/tests/unit/__init__.py" \
    "${REPO_ROOT}/tests/integration/__init__.py"
do
    if [ ! -f "${init}" ]; then
        touch "${init}"
    fi
done

# ── .env.example ─────────────────────────────────────────────────────
ENV_EXAMPLE="${REPO_ROOT}/.env.example"
if [ ! -f "${ENV_EXAMPLE}" ]; then
    info "Creating .env.example..."
    cat > "${ENV_EXAMPLE}" <<'ENVEOF'
# Kore Platform -- Environment Variables
# Copy to .env and fill in real values. Never commit .env!

KORE_SIGNING_KEY=change-me-to-a-real-secret
KORE_LOG_LEVEL=DEBUG
KORE_SANDBOX_POLICY=strict

# LLM providers
OPENAI_API_KEY=
ANTHROPIC_API_KEY=

# Redis
REDIS_URL=redis://localhost:6379/0

# PostgreSQL
DATABASE_URL=postgresql://kore:kore@localhost:5432/kore
ENVEOF
fi

# ── Summary ──────────────────────────────────────────────────────────
echo ""
info "============================================"
info "  Development environment ready!"
info "============================================"
echo ""
echo "  Activate with:  source .venv/bin/activate"
echo "  Run tests:      make test"
echo "  Run linters:    make lint"
echo "  Format code:    make format"
echo ""
