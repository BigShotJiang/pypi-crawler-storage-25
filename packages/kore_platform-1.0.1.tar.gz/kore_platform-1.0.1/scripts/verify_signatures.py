#!/usr/bin/env python3
"""Verify cryptographic signatures of all YAML flows in the flows/ directory.

Checks both the embedded ``__signature__`` field inside each YAML file and the
companion ``.sig`` file (if present).  Exits with code 1 if any flow fails
verification.

Usage:
    export KORE_SIGNING_KEY="your-secret-key"
    python scripts/verify_signatures.py
"""

from __future__ import annotations

import hashlib
import hmac
import os
import sys
from pathlib import Path

import yaml

FLOWS_DIR = Path(__file__).resolve().parent.parent / "flows"
SIGNATURE_FIELD = "__signature__"


def _get_signing_key() -> bytes:
    raw = os.environ.get("KORE_SIGNING_KEY", "")
    if not raw:
        print("ERROR: KORE_SIGNING_KEY environment variable is not set.", file=sys.stderr)
        sys.exit(1)
    return raw.encode("utf-8")


def _canonical_payload(data: dict) -> bytes:
    sanitised = {k: v for k, v in data.items() if k != SIGNATURE_FIELD}
    return yaml.dump(sanitised, default_flow_style=False, sort_keys=True).encode("utf-8")


def _compute_signature(data: dict, key: bytes) -> str:
    payload = _canonical_payload(data)
    return hmac.new(key, payload, hashlib.sha256).hexdigest()


def verify_flow(path: Path, key: bytes) -> bool:
    """Verify a single flow file.  Returns True if valid."""
    with open(path, "r", encoding="utf-8") as fh:
        data = yaml.safe_load(fh)

    if not isinstance(data, dict):
        print(f"  SKIP    {path.name} (not a YAML mapping)")
        return True  # not a flow, nothing to verify

    embedded_sig = data.get(SIGNATURE_FIELD)
    if not embedded_sig:
        print(f"  MISSING {path.name} -- no {SIGNATURE_FIELD} field")
        return False

    expected = _compute_signature(data, key)

    # Compare embedded signature
    if not hmac.compare_digest(embedded_sig, expected):
        print(f"  FAIL    {path.name} -- embedded signature mismatch")
        return False

    # Compare companion .sig file if it exists
    sig_path = path.with_suffix(path.suffix + ".sig")
    if sig_path.exists():
        file_sig = sig_path.read_text(encoding="utf-8").strip()
        if not hmac.compare_digest(file_sig, expected):
            print(f"  FAIL    {path.name} -- .sig file mismatch")
            return False

    print(f"  OK      {path.name}")
    return True


def main() -> None:
    key = _get_signing_key()

    if not FLOWS_DIR.exists():
        print(f"Flows directory not found: {FLOWS_DIR}", file=sys.stderr)
        sys.exit(1)

    flow_files = sorted(
        p for p in FLOWS_DIR.glob("*.y*ml") if p.suffix != ".sig"
    )
    if not flow_files:
        print("No YAML flow files found in flows/.")
        sys.exit(0)

    print(f"Verifying {len(flow_files)} flow(s) in {FLOWS_DIR}\n")

    results = [verify_flow(f, key) for f in flow_files]
    passed = sum(results)
    failed = len(results) - passed

    print(f"\nResults: {passed} passed, {failed} failed out of {len(results)} flow(s).")

    if failed > 0:
        sys.exit(1)


if __name__ == "__main__":
    main()
