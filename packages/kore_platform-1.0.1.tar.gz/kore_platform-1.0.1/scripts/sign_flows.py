#!/usr/bin/env python3
"""Sign all YAML flow definitions in the flows/ directory.

Uses HMAC-SHA256 with the key provided via the KORE_SIGNING_KEY environment
variable. Signatures are written as a ``__signature__`` field at the top level
of each YAML document and also persisted to a companion ``.sig`` file so that
verification can work without modifying the originals.

Usage:
    export KORE_SIGNING_KEY="your-secret-key"
    python scripts/sign_flows.py
"""

from __future__ import annotations

import hashlib
import hmac
import os
import sys
from pathlib import Path

import yaml

FLOWS_DIR = Path(__file__).resolve().parent.parent / "flows"
SIGNATURE_FIELD = "__signature__"


def _get_signing_key() -> bytes:
    raw = os.environ.get("KORE_SIGNING_KEY", "")
    if not raw:
        print("ERROR: KORE_SIGNING_KEY environment variable is not set.", file=sys.stderr)
        sys.exit(1)
    return raw.encode("utf-8")


def _canonical_payload(data: dict) -> bytes:
    """Return a deterministic byte representation of the flow data.

    The ``__signature__`` field is excluded so that signing is idempotent.
    """
    sanitised = {k: v for k, v in data.items() if k != SIGNATURE_FIELD}
    return yaml.dump(sanitised, default_flow_style=False, sort_keys=True).encode("utf-8")


def sign_flow(path: Path, key: bytes) -> str:
    """Sign a single YAML flow file and return the hex signature."""
    with open(path, "r", encoding="utf-8") as fh:
        data = yaml.safe_load(fh)

    if not isinstance(data, dict):
        print(f"  SKIP {path.name} (not a YAML mapping)")
        return ""

    payload = _canonical_payload(data)
    signature = hmac.new(key, payload, hashlib.sha256).hexdigest()

    # Write signature into the YAML document
    data[SIGNATURE_FIELD] = signature
    with open(path, "w", encoding="utf-8") as fh:
        yaml.dump(data, fh, default_flow_style=False, sort_keys=False)

    # Write companion .sig file
    sig_path = path.with_suffix(path.suffix + ".sig")
    sig_path.write_text(signature + "\n", encoding="utf-8")

    return signature


def main() -> None:
    key = _get_signing_key()

    if not FLOWS_DIR.exists():
        print(f"Flows directory not found: {FLOWS_DIR}", file=sys.stderr)
        sys.exit(1)

    flow_files = sorted(FLOWS_DIR.glob("*.y*ml"))
    if not flow_files:
        print("No YAML flow files found in flows/.")
        sys.exit(0)

    print(f"Signing {len(flow_files)} flow(s) in {FLOWS_DIR}\n")

    signed = 0
    for flow_path in flow_files:
        # Skip companion signature files
        if flow_path.suffix == ".sig":
            continue
        sig = sign_flow(flow_path, key)
        if sig:
            print(f"  SIGNED  {flow_path.name}  ->  {sig[:16]}...")
            signed += 1

    print(f"\nDone. {signed} flow(s) signed.")


if __name__ == "__main__":
    main()
