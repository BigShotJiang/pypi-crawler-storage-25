"""KORE Web UI — local web interface + API for project generation.

Security:
- CSRF protection via X-KORE-Token header (required on all POST requests)
- Token generated at startup, injected into HTML
- Idempotency key to prevent duplicate jobs from double-clicks
- Graceful shutdown: tracks running tasks, waits on SIGTERM/SIGINT

Known limitations (MVP):
- Jobs stored in memory — lost on server restart
- No authentication (localhost only — bind to 127.0.0.1, not 0.0.0.0)
- No WebSocket streaming — uses polling
- No job persistence to disk
"""

from __future__ import annotations

import asyncio
import hashlib
import logging
import secrets
import signal
import uuid
import webbrowser
from datetime import datetime, timezone
from typing import Any

from fastapi import FastAPI, Header, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse
from pydantic import BaseModel

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# CSRF token — generated per server instance
# ---------------------------------------------------------------------------

_CSRF_TOKEN = secrets.token_urlsafe(32)

# ---------------------------------------------------------------------------
# API models
# ---------------------------------------------------------------------------

class InterviewRequest(BaseModel):
    idea: str


class InterviewResponse(BaseModel):
    level: str
    questions: list[dict[str, str]]  # [{"key": "...", "text": "..."}]


class GenerateRequest(BaseModel):
    idea: str
    answers: dict[str, str] | None = None  # User's interview answers
    logo_url: str | None = None
    project_name: str | None = None
    idempotency_key: str | None = None  # Prevents duplicate jobs


class JobStatus(BaseModel):
    id: str
    status: str  # pending, running, completed, failed
    created_at: str
    idea: str
    result: dict[str, Any] | None = None
    files: list[dict[str, Any]] | None = None
    error: str | None = None


# ---------------------------------------------------------------------------
# In-memory job store (MVP — documented limitation)
# ---------------------------------------------------------------------------

_jobs: dict[str, dict[str, Any]] = {}
_idempotency_map: dict[str, str] = {}  # idempotency_key -> job_id
_running_tasks: set[asyncio.Task[None]] = set()

# ---------------------------------------------------------------------------
# FastAPI app
# ---------------------------------------------------------------------------

app = FastAPI(
    title="KORE Platform",
    description="AI-Powered Software Generation — Local Interface",
    version="1.0.0",
)


_ALLOWED_ORIGINS: frozenset[str] = frozenset({
    "http://localhost", "http://127.0.0.1",
    "http://localhost:8080", "http://127.0.0.1:8080",
    "http://localhost:3000", "http://127.0.0.1:3000",
})


def _verify_csrf(token: str | None, origin: str | None = None) -> None:
    """Verifica CSRF token y Origin header en requests mutantes.

    Double-submit defense:
    1. X-KORE-Token header must match server-generated token
    2. Origin header (if present) must be localhost
    """
    if token != _CSRF_TOKEN:
        raise HTTPException(status_code=403, detail="Invalid or missing CSRF token")
    if origin is not None:
        # Strip path from origin, keep scheme + host + port
        origin_base = origin.rstrip("/")
        if origin_base not in _ALLOWED_ORIGINS:
            raise HTTPException(
                status_code=403,
                detail=f"Origin '{origin_base}' not allowed (localhost only)",
            )


@app.get("/health")
async def health() -> dict[str, Any]:
    from .agents.base.llm_utils import get_accumulated_usage
    return {
        "status": "ok",
        "service": "kore-platform",
        "active_jobs": sum(1 for j in _jobs.values() if j["status"] == "running"),
        "total_jobs": len(_jobs),
        "llm_usage": get_accumulated_usage(),
    }


@app.post("/api/v1/interview")
async def interview_questions(
    req: InterviewRequest,
    request: Request,
    x_kore_token: str | None = Header(None),
) -> JSONResponse:
    """Detecta nivel tecnico y devuelve preguntas de entrevista."""
    _verify_csrf(x_kore_token, origin=request.headers.get("origin"))

    from .interview.level_detector import LevelDetector
    from .interview.question_selector import QuestionSelector

    detector = LevelDetector()
    level = detector._detect_heuristic(req.idea)

    selector = QuestionSelector()
    questions = selector.select(level)

    return JSONResponse(content={
        "level": level.name,
        "questions": [{"key": q.key, "text": q.text} for q in questions],
    })


@app.post("/api/v1/generate")
async def generate(
    req: GenerateRequest,
    request: Request,
    x_kore_token: str | None = Header(None),
) -> JSONResponse:
    """Lanza un job de generacion en background."""
    _verify_csrf(x_kore_token, origin=request.headers.get("origin"))

    # Idempotency: return existing job if same key
    if req.idempotency_key:
        existing_job_id = _idempotency_map.get(req.idempotency_key)
        if existing_job_id and existing_job_id in _jobs:
            return JSONResponse(
                status_code=200,
                content={"job_id": existing_job_id, "status": _jobs[existing_job_id]["status"], "deduplicated": True},
            )

    job_id = str(uuid.uuid4())[:8]
    _jobs[job_id] = {
        "id": job_id,
        "status": "pending",
        "created_at": datetime.now(timezone.utc).isoformat(),
        "idea": req.idea,
        "logo_url": req.logo_url,
        "project_name": req.project_name,
        "result": None,
        "files": None,
        "error": None,
    }

    if req.idempotency_key:
        _idempotency_map[req.idempotency_key] = job_id

    # Lanzar en background con tracking
    task = asyncio.create_task(_run_job(job_id, req.idea, req.answers))
    _running_tasks.add(task)
    task.add_done_callback(_running_tasks.discard)

    return JSONResponse(
        status_code=202,
        content={"job_id": job_id, "status": "pending"},
    )


@app.get("/api/v1/jobs/{job_id}")
async def get_job(job_id: str) -> JSONResponse:
    """Consulta estado de un job."""
    job = _jobs.get(job_id)
    if job is None:
        return JSONResponse(status_code=404, content={"error": "Job not found"})
    return JSONResponse(content=job)


@app.get("/api/v1/jobs/{job_id}/files")
async def get_job_files(job_id: str) -> JSONResponse:
    """Lista archivos generados de un job."""
    job = _jobs.get(job_id)
    if job is None:
        return JSONResponse(status_code=404, content={"error": "Job not found"})
    return JSONResponse(content={"files": job.get("files", [])})


@app.get("/", response_class=HTMLResponse)
async def ui_root() -> str:
    """Interfaz web local — inyecta CSRF token."""
    return _HTML_UI.replace("__CSRF_TOKEN__", _CSRF_TOKEN)


# ---------------------------------------------------------------------------
# Background job runner
# ---------------------------------------------------------------------------

async def _run_job(job_id: str, idea: str, user_answers: dict[str, str] | None = None) -> None:
    """Ejecuta el pipeline completo en background."""
    _jobs[job_id]["status"] = "running"

    try:
        from .infrastructure.config.settings import Settings
        from .infrastructure.config.container import Container
        from .interview.interviewer import Interviewer, LLMAutoAnswerProvider, WebAnswerProvider
        from .orchestration.orchestrator import Orchestrator
        from .delivery.delivery_factory import DeliveryFactory
        from .application.use_cases.execute_job_use_case import ExecuteJobUseCase
        from .interview.plan_generator import PlanGenerator

        settings = Settings.from_env()
        container = Container(settings=settings)
        container.setup()

        llm_client = container.llm_client

        if user_answers:
            # Usuario respondio preguntas en la web UI
            answer_provider = WebAnswerProvider(answers=user_answers)
        else:
            # Auto-mode: LLM genera respuestas
            answer_provider = LLMAutoAnswerProvider(llm_client=llm_client, idea=idea)

        interviewer = Interviewer(
            demo_mode=False,
            answer_provider=answer_provider,
            llm_client=llm_client,
        )

        orchestrator = Orchestrator(
            bus=container.bus,
            audit_log=container.audit_log,
            guardian=container.guardian,
            plan_generator=PlanGenerator(),
            demo_mode=True,
            agent_registry=container.agent_registry,
            workspace_manager=container.workspace_manager,
        )

        delivery_factory = DeliveryFactory()

        use_case = ExecuteJobUseCase(
            interviewer=interviewer,
            orchestrator=orchestrator,
            delivery_factory=delivery_factory,
            audit_log=container.audit_log,
        )

        result_dto = await use_case.execute(idea)

        # Extraer archivos del workspace
        files: list[dict[str, Any]] = []
        delivery = getattr(result_dto, "delivery", {}) or {}
        workspace_path = delivery.get("metrics", {}).get("workspace")
        if workspace_path:
            from pathlib import Path
            wm = container.workspace_manager
            files = wm.list_files(Path(workspace_path))

        _jobs[job_id]["status"] = "completed"
        _jobs[job_id]["result"] = {
            "status": getattr(result_dto, "status", "unknown"),
            "message": getattr(result_dto, "message", ""),
            "delivery": delivery,
        }
        _jobs[job_id]["files"] = files

    except Exception as exc:
        logger.exception("job_failed job_id=%s", job_id)
        _jobs[job_id]["status"] = "failed"
        _jobs[job_id]["error"] = str(exc)


# ---------------------------------------------------------------------------
# Graceful shutdown
# ---------------------------------------------------------------------------

async def _graceful_shutdown() -> None:
    """Espera a que los jobs en curso terminen antes de cerrar."""
    if _running_tasks:
        logger.info("graceful_shutdown waiting for %d running tasks", len(_running_tasks))
        await asyncio.gather(*_running_tasks, return_exceptions=True)
    logger.info("graceful_shutdown complete")


@app.on_event("shutdown")
async def on_shutdown() -> None:
    await _graceful_shutdown()


# ---------------------------------------------------------------------------
# HTML UI (embedded, sin dependencias externas)
# ---------------------------------------------------------------------------

_HTML_UI = """<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>KORE Platform</title>
<style>
* { box-sizing: border-box; margin: 0; padding: 0; }
body {
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    background: #0f0f1a;
    color: #e0e0e0;
    min-height: 100vh;
}
.container { max-width: 800px; margin: 0 auto; padding: 40px 20px; }
header { text-align: center; margin-bottom: 40px; }
h1 {
    font-size: 2.5em;
    background: linear-gradient(135deg, #667eea, #764ba2);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    margin-bottom: 8px;
}
.subtitle { color: #888; font-size: 1.1em; }
.card {
    background: #1a1a2e;
    border-radius: 12px;
    padding: 32px;
    margin-bottom: 24px;
    border: 1px solid #2a2a4a;
}
label { display: block; font-weight: 600; margin-bottom: 8px; color: #b0b0d0; }
textarea, input[type=text], input[type=url] {
    width: 100%;
    padding: 12px 16px;
    border-radius: 8px;
    border: 1px solid #3a3a5a;
    background: #0f0f1a;
    color: #e0e0e0;
    font-size: 1em;
    margin-bottom: 16px;
    resize: vertical;
}
textarea { min-height: 100px; }
textarea:focus, input:focus {
    outline: none;
    border-color: #667eea;
    box-shadow: 0 0 0 3px rgba(102,126,234,0.2);
}
.btn {
    display: inline-block;
    padding: 14px 32px;
    background: linear-gradient(135deg, #667eea, #764ba2);
    color: white;
    border: none;
    border-radius: 8px;
    font-size: 1.1em;
    font-weight: 600;
    cursor: pointer;
    width: 100%;
    transition: transform 0.15s, box-shadow 0.15s;
}
.btn:hover { transform: translateY(-1px); box-shadow: 0 4px 20px rgba(102,126,234,0.4); }
.btn:disabled { opacity: 0.5; cursor: not-allowed; transform: none; }
#status { margin-top: 24px; padding: 20px; border-radius: 8px; display: none; }
#status.pending { display: block; background: #1a2a1a; border: 1px solid #2a4a2a; }
#status.running { display: block; background: #1a1a2e; border: 1px solid #3a3a6a; }
#status.completed { display: block; background: #1a2a1a; border: 1px solid #2a6a2a; }
#status.failed { display: block; background: #2a1a1a; border: 1px solid #6a2a2a; }
.spinner {
    display: inline-block; width: 20px; height: 20px;
    border: 3px solid #444; border-top-color: #667eea;
    border-radius: 50%; animation: spin 0.8s linear infinite;
    margin-right: 8px; vertical-align: middle;
}
@keyframes spin { to { transform: rotate(360deg); } }
.files-list { margin-top: 16px; max-height: 300px; overflow-y: auto; }
.file-item {
    padding: 8px 12px; background: #0f0f1a; border-radius: 6px;
    margin-bottom: 4px; font-family: monospace; font-size: 0.9em;
    display: flex; justify-content: space-between;
}
.file-size { color: #888; }
footer { text-align: center; margin-top: 40px; color: #555; font-size: 0.9em; }
.warning { background: #2a2a1a; border: 1px solid #4a4a2a; border-radius: 8px; padding: 12px; margin-bottom: 24px; font-size: 0.9em; color: #cc9; }
</style>
</head>
<body>
<div class="container">
    <header>
        <h1>KORE</h1>
        <p class="subtitle">Genera proyectos completos desde una idea</p>
    </header>

    <div class="card" id="ideaCard">
        <label for="idea">Tu idea de proyecto / Your project idea</label>
        <textarea id="idea" placeholder="Ejemplo: Build a REST API for managing books with FastAPI, SQLAlchemy and authentication..."></textarea>

        <label for="name">Nombre del proyecto / Project name (opcional)</label>
        <input type="text" id="name" placeholder="mi-proyecto">

        <label for="logo">URL del logo (opcional)</label>
        <input type="url" id="logo" placeholder="https://ejemplo.com/logo.png">

        <button class="btn" id="interviewBtn" onclick="startInterview()">Siguiente: Entrevista / Next: Interview</button>
    </div>

    <div class="card" id="interviewCard" style="display:none">
        <h3 style="margin-bottom:8px">Entrevista / Interview</h3>
        <p style="color:#888;margin-bottom:16px;font-size:0.9em">
            Nivel detectado / Detected level: <strong id="detectedLevel"></strong>
        </p>
        <div id="questionsContainer"></div>
        <button class="btn" id="generateBtn" onclick="generate()">Generar Proyecto / Generate Project</button>
    </div>

    <div class="card" id="statusCard" style="display:none">
        <div id="status"></div>
    </div>

    <div class="card" id="filesCard" style="display:none">
        <h3 style="margin-bottom:12px">Archivos generados / Generated files</h3>
        <div class="files-list" id="filesList"></div>
    </div>

    <footer>
        KORE Platform v1.0 &mdash; Todo se ejecuta en tu maquina. Sin datos en la nube.<br>
        Everything runs on your machine. No data in the cloud.
    </footer>
</div>

<script>
const CSRF_TOKEN = '__CSRF_TOKEN__';
let currentJobId = null;
let pollInterval = null;
let idempotencyKey = null;
let interviewQuestions = [];

async function startInterview() {
    const idea = document.getElementById('idea').value.trim();
    if (!idea) { alert('Escribe tu idea de proyecto / Write your project idea'); return; }

    const btn = document.getElementById('interviewBtn');
    btn.disabled = true;
    btn.textContent = 'Analizando... / Analyzing...';

    try {
        const resp = await fetch('/api/v1/interview', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'X-KORE-Token': CSRF_TOKEN },
            body: JSON.stringify({ idea: idea })
        });
        const data = await resp.json();
        interviewQuestions = data.questions;
        document.getElementById('detectedLevel').textContent = data.level;

        const container = document.getElementById('questionsContainer');
        container.innerHTML = '';
        for (const q of data.questions) {
            const div = document.createElement('div');
            div.style.marginBottom = '16px';
            div.innerHTML = '<label for="q_' + q.key + '">' + q.text + '</label>' +
                '<input type="text" id="q_' + q.key + '" data-key="' + q.key + '" class="interview-answer" placeholder="Tu respuesta / Your answer...">';
            container.appendChild(div);
        }

        document.getElementById('ideaCard').style.display = 'none';
        document.getElementById('interviewCard').style.display = 'block';
    } catch(e) {
        alert('Error: ' + e.message);
        btn.disabled = false;
        btn.textContent = 'Siguiente: Entrevista / Next: Interview';
    }
}

async function generate() {
    const idea = document.getElementById('idea').value.trim();
    const btn = document.getElementById('generateBtn');
    btn.disabled = true;
    btn.textContent = 'Generando... / Generating...';

    // Recoger respuestas del usuario
    const answers = {};
    document.querySelectorAll('.interview-answer').forEach(input => {
        const key = input.getAttribute('data-key');
        const val = input.value.trim();
        if (val) answers[key] = val;
    });
    // Siempre incluir la idea como "problem"
    answers['problem'] = idea;

    idempotencyKey = Date.now().toString(36) + Math.random().toString(36).substr(2, 8);

    document.getElementById('interviewCard').style.display = 'none';
    document.getElementById('statusCard').style.display = 'block';
    const statusEl = document.getElementById('status');
    statusEl.className = 'running';
    statusEl.innerHTML = '<span class="spinner"></span> Generando proyecto... (esto puede tardar unos minutos) / Generating project...';

    try {
        const resp = await fetch('/api/v1/generate', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'X-KORE-Token': CSRF_TOKEN },
            body: JSON.stringify({
                idea: idea,
                answers: answers,
                project_name: document.getElementById('name').value.trim() || null,
                logo_url: document.getElementById('logo').value.trim() || null,
                idempotency_key: idempotencyKey,
            })
        });
        const data = await resp.json();
        currentJobId = data.job_id;
        pollInterval = setInterval(checkStatus, 3000);
    } catch(e) {
        statusEl.className = 'failed';
        statusEl.innerHTML = 'Error: ' + e.message;
        btn.disabled = false;
        btn.textContent = 'Generar Proyecto / Generate Project';
    }
}

async function checkStatus() {
    if (!currentJobId) return;
    try {
        const resp = await fetch('/api/v1/jobs/' + currentJobId);
        const job = await resp.json();
        const statusEl = document.getElementById('status');

        if (job.status === 'running') {
            statusEl.className = 'running';
            statusEl.innerHTML = '<span class="spinner"></span> Generando proyecto... / Generating project...';
        } else if (job.status === 'completed') {
            clearInterval(pollInterval);
            statusEl.className = 'completed';
            statusEl.innerHTML = 'Proyecto generado con exito! / Project generated successfully!';
            showFiles(job.files || []);
            document.getElementById('generateBtn').disabled = false;
            document.getElementById('generateBtn').textContent = 'Generar Otro / Generate Another';
        } else if (job.status === 'failed') {
            clearInterval(pollInterval);
            statusEl.className = 'failed';
            statusEl.innerHTML = 'Error: ' + (job.error || 'Unknown error');
            document.getElementById('generateBtn').disabled = false;
            document.getElementById('generateBtn').textContent = 'Reintentar / Retry';
        }
    } catch(e) { /* silently retry */ }
}

function showFiles(files) {
    const card = document.getElementById('filesCard');
    const list = document.getElementById('filesList');
    if (files.length === 0) { card.style.display = 'none'; return; }
    card.style.display = 'block';
    list.innerHTML = files.map(f =>
        '<div class="file-item"><span>' + f.path + '</span><span class="file-size">' + f.size + ' bytes</span></div>'
    ).join('');
}
</script>
</body>
</html>"""


# ---------------------------------------------------------------------------
# Launch helper
# ---------------------------------------------------------------------------

def launch_ui(host: str = "127.0.0.1", port: int = 8080) -> None:
    """Lanza el servidor web local y abre el navegador.

    IMPORTANT: Binds to 127.0.0.1 only (not 0.0.0.0) to prevent
    external access. This is intentional for security.
    """
    import uvicorn

    print(f"\n  KORE Web UI: http://{host}:{port}")
    print("  CSRF Token: (auto-injected into UI)")
    print("  WARNING: Jobs are stored in memory. Restart = jobs lost.")
    print("  (Ctrl+C to stop)\n")

    # Abrir navegador en un thread aparte
    import threading
    threading.Timer(1.5, lambda: webbrowser.open(f"http://{host}:{port}")).start()

    uvicorn.run(app, host=host, port=port, log_level="warning")
