"""Entry point: python -m kore_platform 'Build a REST API for TODO items'"""

from __future__ import annotations

import asyncio
import hashlib
import logging
import shutil
import subprocess
import sys
import time
from pathlib import Path

from .infrastructure.config.settings import Settings
from .infrastructure.config.container import Container
from .infrastructure.i18n import t
from .interview.interviewer import Interviewer, LLMAutoAnswerProvider, CLIAnswerProvider
from .orchestration.orchestrator import Orchestrator
from .delivery.delivery_factory import DeliveryFactory
from .application.use_cases.execute_job_use_case import ExecuteJobUseCase

logger = logging.getLogger(__name__)

# -- kore --setup constants --------------------------------------------------

_KORE_DIR = Path.home() / ".kore"
_MODELS_DIR = _KORE_DIR / "models"
_CONFIG_FILE = _KORE_DIR / "config.yaml"


def _print_header() -> None:
    print("\n" + "=" * 64)
    print(f"  {t('header')}")
    print("=" * 64)


def _print_step(step_num: int, total: int, agent: str, action: str, status: str) -> None:
    icon = {"completed": "+", "failed": "X", "blocked": "!", "in_progress": ">"}.get(status, "?")
    print(f"  [{icon}] Step {step_num}/{total}: {agent}:{action} — {status}")


def _print_result(result_dto: object) -> None:
    print("\n" + "=" * 64)
    status = getattr(result_dto, "status", "unknown")
    print(f"  {t('result_label')}: {status.upper()}")
    print("=" * 64)
    message = getattr(result_dto, "message", "")
    if message:
        print(f"  {message}")
    delivery = getattr(result_dto, "delivery", {})
    if delivery:
        dtype = delivery.get("type", "N/A")
        print(f"  {t('delivery_type')}: {dtype}")
        workspace = delivery.get("metrics", {}).get("workspace")
        if workspace:
            print(f"  {t('workspace')}: {workspace}")
    print("=" * 64 + "\n")


async def _run(idea: str) -> None:
    settings = Settings.from_env()

    # Configurar locale desde settings
    from .infrastructure.i18n import set_locale
    set_locale(settings.language)

    print(f"\n  {t('llm_provider')}: {settings.llm_provider}")
    print(f"  {t('llm_model')}:    {settings.llm_model}")
    print(f"  LLM URL:      {settings.llm_base_url}")
    print(f"  {t('workspace')}:    {settings.workspace_base_path}")
    print()

    # Verificar conectividad LLM antes de empezar
    if settings.llm_provider.lower() == "ollama":
        try:
            import httpx
            async with httpx.AsyncClient(timeout=10) as client:
                resp = await client.get(f"{settings.llm_base_url}/api/tags")
                resp.raise_for_status()
                models = [m["name"] for m in resp.json().get("models", [])]
                print(f"  {t('ollama_ok', count=len(models))}")
                if models:
                    print(f"  Models: {', '.join(models[:5])}")
                if settings.llm_model not in models and models:
                    # Intentar match parcial
                    match = [m for m in models if settings.llm_model.split(":")[0] in m]
                    if match:
                        print(f"  Note: using closest match '{match[0]}'")
        except Exception as exc:
            print(f"\n  {t('ollama_error', url=settings.llm_base_url)}")
            print(f"  Detail: {exc}")
            print(f"  {t('ollama_hint')}")
            print("  Or set KORE_LLM_BASE_URL to your Ollama server URL\n")
            return

    container = Container(settings=settings)
    container.setup()

    # Wiring: seleccionar modo de entrevista
    llm_client = container.llm_client
    auto_mode = "--auto" in sys.argv

    if auto_mode:
        # LLM genera respuestas automaticamente (sin interaccion)
        answer_provider = LLMAutoAnswerProvider(llm_client=llm_client, idea=idea)
    else:
        # Modo interactivo: el usuario responde preguntas por teclado
        answer_provider = CLIAnswerProvider()

    interviewer = Interviewer(
        demo_mode=False,
        answer_provider=answer_provider,
        llm_client=llm_client,
    )

    from .interview.plan_generator import PlanGenerator

    orchestrator = Orchestrator(
        bus=container.bus,
        audit_log=container.audit_log,
        guardian=container.guardian,
        plan_generator=PlanGenerator(),
        demo_mode=True,
        agent_registry=container.agent_registry,
        workspace_manager=container.workspace_manager,
    )

    delivery_factory = DeliveryFactory()

    use_case = ExecuteJobUseCase(
        interviewer=interviewer,
        orchestrator=orchestrator,
        delivery_factory=delivery_factory,
        audit_log=container.audit_log,
    )

    print(f"  {t('idea_label')}: {idea}")
    print()
    print(f"  {t('starting_pipeline')}")
    print("-" * 64)

    start = time.monotonic()
    try:
        result_dto = await use_case.execute(idea)
    except Exception as exc:
        elapsed = time.monotonic() - start
        print(f"\n  {t('pipeline_failed', elapsed=elapsed)}")
        print(f"  Error: {exc}")
        logger.exception("pipeline_failed")
        return

    elapsed = time.monotonic() - start

    _print_result(result_dto)
    print(f"  {t('total_time')}: {elapsed:.1f}s")

    # Mostrar archivos generados
    workspace_path = None
    if result_dto.delivery:
        workspace_path = result_dto.delivery.get("metrics", {}).get("workspace")
    if workspace_path:
        from pathlib import Path
        wm = container.workspace_manager
        files = wm.list_files(Path(workspace_path))
        if files:
            print(f"\n  {t('generated_files', count=len(files))}:")
            for f in files:
                print(f"    {f['path']} ({f['size']} bytes)")
    print()


def _load_distribution_config() -> dict[str, str]:
    """Load distribution section from training config.yaml shipped with the package."""
    import yaml

    candidates = [
        Path(__file__).resolve().parent.parent.parent / "tools" / "training" / "config.yaml",
        Path.cwd() / "tools" / "training" / "config.yaml",
    ]
    for p in candidates:
        if p.is_file():
            with open(p) as f:
                data = yaml.safe_load(f) or {}
            return data.get("distribution", {})
    # Fallback defaults
    return {
        "hf_repo": "iafiscal/kore-coder-7b",
        "gguf_filename": "kore-coder-7b.Q4_K_M.gguf",
        "ollama_model_name": "kore-coder",
        "model_url": (
            "https://huggingface.co/iafiscal/kore-coder-7b"
            "/resolve/main/kore-coder-7b.Q4_K_M.gguf"
        ),
        "sha256": "",
        "modelfile_template": (
            'FROM {gguf_path}\n\nPARAMETER temperature 0.3\nPARAMETER top_p 0.9\n'
            'PARAMETER num_ctx 16384\n\nSYSTEM "You are KORE, an expert software '
            'architect and developer. Generate complete Python projects with proper '
            'structure, type hints, docstrings, and working imports. Output each file '
            'wrapped in <FILE path=\\"...\\">...</FILE> tags."'
        ),
    }


def _setup() -> None:
    """Download and install the fine-tuned KORE model for Ollama."""
    dist = _load_distribution_config()
    model_name = dist.get("ollama_model_name", "kore-coder")
    model_url = dist.get("model_url", "")
    gguf_filename = dist.get("gguf_filename", "kore-coder-7b.Q4_K_M.gguf")
    expected_sha = dist.get("sha256", "")
    modelfile_tpl = dist.get("modelfile_template", "FROM {gguf_path}")

    # 1. Verify Ollama is installed
    print("\n  [1/6] Verificando Ollama...")
    if not shutil.which("ollama"):
        print("  ERROR: Ollama no esta instalado.")
        print("  Instala Ollama desde https://ollama.com/download")
        print("  Luego ejecuta: kore --setup\n")
        sys.exit(1)
    print("  Ollama encontrado.")

    # 2. Check if model already exists
    print("  [2/6] Comprobando modelos existentes...")
    try:
        result = subprocess.run(
            ["ollama", "list"], capture_output=True, text=True, timeout=15,
        )
        existing = result.stdout
    except Exception:
        existing = ""

    if model_name in existing:
        answer = input(f"  El modelo '{model_name}' ya existe. Actualizar? [s/N]: ").strip()
        if answer.lower() not in ("s", "si", "y", "yes"):
            print("  Setup cancelado.\n")
            return

    # 3. Download GGUF
    print(f"  [3/6] Descargando {gguf_filename} (~4.5 GB)...")
    _MODELS_DIR.mkdir(parents=True, exist_ok=True)
    gguf_path = _MODELS_DIR / gguf_filename

    if not model_url:
        print("  ERROR: No se ha configurado model_url en training/config.yaml")
        sys.exit(1)

    try:
        import httpx
    except ImportError:
        print("  ERROR: httpx no instalado. Ejecuta: pip install httpx")
        sys.exit(1)

    _download_with_resume(model_url, gguf_path)

    # 4. Verify checksum
    if expected_sha:
        print("  [4/6] Verificando integridad (SHA256)...")
        actual_sha = _sha256(gguf_path)
        if actual_sha != expected_sha:
            print(f"  ERROR: SHA256 no coincide.")
            print(f"    Esperado: {expected_sha}")
            print(f"    Obtenido: {actual_sha}")
            print("  Elimina el archivo y vuelve a ejecutar: kore --setup\n")
            sys.exit(1)
        print("  Checksum correcto.")
    else:
        print("  [4/6] Sin checksum configurado, saltando verificacion.")

    # 5. Create Ollama model
    print(f"  [5/6] Creando modelo '{model_name}' en Ollama...")
    modelfile_path = _MODELS_DIR / "Modelfile"
    modelfile_content = modelfile_tpl.replace("{gguf_path}", str(gguf_path))
    modelfile_path.write_text(modelfile_content)

    try:
        subprocess.run(
            ["ollama", "create", model_name, "-f", str(modelfile_path)],
            check=True, timeout=120,
        )
    except subprocess.CalledProcessError as exc:
        print(f"  ERROR: No se pudo crear el modelo: {exc}")
        sys.exit(1)
    print(f"  Modelo '{model_name}' creado.")

    # 6. Configure KORE
    print("  [6/6] Configurando KORE...")
    _KORE_DIR.mkdir(parents=True, exist_ok=True)

    # If config exists, ask before overwriting LLM settings
    write_config = True
    if _CONFIG_FILE.is_file():
        import yaml

        existing_cfg = yaml.safe_load(_CONFIG_FILE.read_text()) or {}
        if existing_cfg.get("llm_model") and existing_cfg["llm_model"] != model_name:
            answer = input(
                f"  Ya tienes configurado '{existing_cfg['llm_model']}'. "
                f"Cambiar a '{model_name}'? [s/N]: "
            ).strip()
            if answer.lower() not in ("s", "si", "y", "yes"):
                write_config = False

    if write_config:
        import yaml

        cfg = {"llm_provider": "ollama", "llm_model": model_name}
        _CONFIG_FILE.write_text(yaml.dump(cfg, default_flow_style=False))
        print(f"  Configuracion guardada en {_CONFIG_FILE}")

    # Verify
    print("\n  Verificando modelo...")
    try:
        result = subprocess.run(
            ["ollama", "run", model_name, "respond with OK"],
            capture_output=True, text=True, timeout=60,
        )
        if result.returncode == 0:
            print("  Modelo responde correctamente.")
        else:
            print(f"  AVISO: el modelo respondio con codigo {result.returncode}")
            if result.stderr:
                print(f"  {result.stderr[:200]}")
    except Exception as exc:
        print(f"  AVISO: no se pudo verificar el modelo: {exc}")

    print(f"\n  Listo. Ejecuta 'kore <tu idea>' para generar proyectos.\n")


def _download_with_resume(url: str, dest: Path) -> None:
    """Download a large file with resume support and progress reporting."""
    import httpx

    headers: dict[str, str] = {}
    mode = "wb"
    downloaded = 0

    if dest.exists():
        downloaded = dest.stat().st_size
        headers["Range"] = f"bytes={downloaded}-"
        mode = "ab"
        print(f"  Resumiendo descarga desde {downloaded / 1e9:.2f} GB...")

    with httpx.stream("GET", url, headers=headers, follow_redirects=True, timeout=30.0) as resp:
        if resp.status_code == 416:
            # Range not satisfiable — file already complete
            print("  Archivo ya descargado completamente.")
            return

        if resp.status_code not in (200, 206):
            print(f"  ERROR: HTTP {resp.status_code} al descargar {url}")
            sys.exit(1)

        total_str = resp.headers.get("content-length", "0")
        total = int(total_str) + downloaded if resp.status_code == 206 else int(total_str)

        with open(dest, mode) as f:
            for chunk in resp.iter_bytes(chunk_size=1024 * 1024):
                f.write(chunk)
                downloaded += len(chunk)
                if total > 0:
                    pct = downloaded / total * 100
                    bar = "#" * int(pct // 2.5) + "-" * (40 - int(pct // 2.5))
                    print(f"\r  [{bar}] {pct:.1f}% ({downloaded / 1e9:.2f}/{total / 1e9:.2f} GB)", end="", flush=True)

    print()  # Newline after progress bar


def _sha256(path: Path) -> str:
    """Compute SHA256 of a file."""
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024 * 8), b""):
            h.update(chunk)
    return h.hexdigest()


def main() -> None:
    _print_header()

    # Check for --setup flag
    if "--setup" in sys.argv:
        _setup()
        return

    # Check for --ui flag
    if "--ui" in sys.argv:
        sys.argv.remove("--ui")
        from .web import launch_ui
        launch_ui()
        return

    # Parsear flags antes de extraer la idea
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    if not args:
        print(f"\n{t('usage')}\n")
        sys.exit(1)

    idea = " ".join(args)
    asyncio.run(_run(idea))


if __name__ == "__main__":
    main()
