"""CLI entry point for `kore` command."""

from __future__ import annotations

from .__main__ import main

if __name__ == "__main__":
    main()
