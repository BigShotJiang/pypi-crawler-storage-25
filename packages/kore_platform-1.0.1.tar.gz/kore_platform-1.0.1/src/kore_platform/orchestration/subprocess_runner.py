"""Subprocess runner — async wrapper with resource limits and isolation.

Security layers applied to every subprocess:
- CPU time limit (RLIMIT_CPU)
- Memory limit (RLIMIT_AS)
- Max processes/threads (RLIMIT_NPROC)
- Max file size (RLIMIT_FSIZE)
- Max open files (RLIMIT_NOFILE)
- Timeout via asyncio
- No network access hint (PYTHONNOUSERSITE=1)
"""

from __future__ import annotations

import asyncio
import logging
import os
import platform
import sys
from dataclasses import dataclass
from typing import Any

logger = logging.getLogger(__name__)


@dataclass(frozen=True, slots=True)
class RunResult:
    """Resultado inmutable de una ejecucion de subprocess."""

    command: str
    exit_code: int
    stdout: str
    stderr: str
    timed_out: bool = False

    @property
    def success(self) -> bool:
        return self.exit_code == 0 and not self.timed_out


@dataclass(frozen=True, slots=True)
class ResourceLimits:
    """Limites de recursos para subprocesos. Inmutable."""

    cpu_seconds: int = 60          # Max CPU time per process
    memory_mb: int = 512           # Max virtual memory (MB)
    max_processes: int = 32        # Max child processes
    max_file_size_mb: int = 50     # Max file size writable (MB)
    max_open_files: int = 256      # Max open file descriptors


def _apply_resource_limits(limits: ResourceLimits) -> None:
    """Aplica limites de recursos al proceso actual via setrlimit.

    Se llama como preexec_fn en subprocess — se ejecuta en el proceso hijo
    ANTES de que el comando se ejecute.

    Solo funciona en Linux/macOS. En Windows se ignora silenciosamente.
    """
    if platform.system() == "Windows":
        return

    try:
        import resource

        # CPU time limit
        resource.setrlimit(resource.RLIMIT_CPU, (limits.cpu_seconds, limits.cpu_seconds))

        # Virtual memory limit
        mem_bytes = limits.memory_mb * 1024 * 1024
        try:
            resource.setrlimit(resource.RLIMIT_AS, (mem_bytes, mem_bytes))
        except ValueError:
            pass  # Some systems don't support RLIMIT_AS

        # Max child processes
        try:
            resource.setrlimit(resource.RLIMIT_NPROC, (limits.max_processes, limits.max_processes))
        except (ValueError, AttributeError):
            pass  # Not available on macOS

        # Max file size
        fsize_bytes = limits.max_file_size_mb * 1024 * 1024
        resource.setrlimit(resource.RLIMIT_FSIZE, (fsize_bytes, fsize_bytes))

        # Max open files
        resource.setrlimit(resource.RLIMIT_NOFILE, (limits.max_open_files, limits.max_open_files))

    except Exception as exc:
        # Don't crash if setrlimit fails — log and continue
        logger.warning("resource_limits_failed error=%s", exc)


@dataclass(frozen=True, slots=True)
class SubprocessRunner:
    """Ejecuta comandos como subprocesos async con timeout y resource limits.

    Security measures:
    1. asyncio timeout (configurable, default 120s)
    2. OS-level resource limits via setrlimit (CPU, memory, files, processes)
    3. Restricted environment (PYTHONNOUSERSITE, PYTHONDONTWRITEBYTECODE)
    4. Process killed on timeout (SIGKILL after SIGTERM)
    """

    default_timeout: int = 120
    resource_limits: ResourceLimits = ResourceLimits()

    async def run(
        self,
        cmd: list[str],
        cwd: str | None = None,
        env: dict[str, str] | None = None,
        timeout: int | None = None,
        apply_limits: bool = True,
    ) -> RunResult:
        """Ejecuta un comando con resource limits y captura stdout/stderr.

        Parameters
        ----------
        cmd:
            Comando como lista de strings.
        cwd:
            Directorio de trabajo.
        env:
            Variables de entorno adicionales.
        timeout:
            Timeout en segundos. Default: self.default_timeout.
        apply_limits:
            Si True, aplica setrlimit al proceso hijo.

        Returns
        -------
        RunResult
            Resultado con exit_code, stdout, stderr.
        """
        effective_timeout = timeout or self.default_timeout
        cmd_str = " ".join(cmd)

        # Build restricted environment
        run_env = self._build_restricted_env(env)

        logger.info("subprocess_start cmd='%s' cwd=%s timeout=%ds limits=%s",
                     cmd_str, cwd, effective_timeout, apply_limits)

        # preexec_fn for resource limits (Linux/macOS only)
        preexec = None
        if apply_limits and platform.system() != "Windows":
            limits = self.resource_limits
            preexec = lambda: _apply_resource_limits(limits)  # noqa: E731

        try:
            process = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=cwd,
                env=run_env,
                preexec_fn=preexec,
            )

            try:
                stdout_bytes, stderr_bytes = await asyncio.wait_for(
                    process.communicate(),
                    timeout=effective_timeout,
                )
            except asyncio.TimeoutError:
                # Escalate: SIGTERM -> wait 5s -> SIGKILL
                try:
                    process.terminate()
                    await asyncio.sleep(2)
                    if process.returncode is None:
                        process.kill()
                except ProcessLookupError:
                    pass
                await process.wait()
                logger.warning("subprocess_timeout cmd='%s' timeout=%ds", cmd_str, effective_timeout)
                return RunResult(
                    command=cmd_str,
                    exit_code=-1,
                    stdout="",
                    stderr=f"Process timed out after {effective_timeout}s",
                    timed_out=True,
                )

            stdout = stdout_bytes.decode("utf-8", errors="replace") if stdout_bytes else ""
            stderr = stderr_bytes.decode("utf-8", errors="replace") if stderr_bytes else ""
            exit_code = process.returncode or 0

            logger.info(
                "subprocess_done cmd='%s' exit_code=%d stdout_len=%d stderr_len=%d",
                cmd_str, exit_code, len(stdout), len(stderr),
            )

            return RunResult(
                command=cmd_str,
                exit_code=exit_code,
                stdout=stdout,
                stderr=stderr,
            )

        except FileNotFoundError:
            logger.error("subprocess_not_found cmd='%s'", cmd_str)
            return RunResult(
                command=cmd_str,
                exit_code=-1,
                stdout="",
                stderr=f"Command not found: {cmd[0]}",
            )
        except Exception as exc:
            logger.error("subprocess_error cmd='%s' error=%s", cmd_str, exc)
            return RunResult(
                command=cmd_str,
                exit_code=-1,
                stdout="",
                stderr=str(exc),
            )

    @staticmethod
    def _build_restricted_env(extra: dict[str, str] | None) -> dict[str, str]:
        """Construye un entorno restrictivo para el subprocess."""
        env = dict(os.environ)

        # Restrict Python behavior
        env["PYTHONDONTWRITEBYTECODE"] = "1"
        env["PYTHONNOUSERSITE"] = "1"  # Don't add user site-packages

        # Remove potentially dangerous env vars
        for key in ("LD_PRELOAD", "LD_LIBRARY_PATH", "PYTHONSTARTUP"):
            env.pop(key, None)

        # Apply user overrides
        if extra:
            env.update(extra)

        return env
