"""Parallel executor — runs independent steps concurrently."""

from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable, Sequence

from ..domain.value_objects.execution_result import StepResult
from .retry_policy import RetryPolicy

logger = logging.getLogger(__name__)


@dataclass(frozen=True, slots=True)
class ParallelTask:
    """Tarea para ejecucion paralela. Inmutable."""

    step_id: str
    agent: str
    action: str
    inputs: dict[str, Any] = field(default_factory=dict)


@dataclass
class ParallelExecutor:
    """Ejecuta tareas concurrentemente con asyncio.gather.

    Soporta limite de concurrencia y reintentos.
    """

    max_concurrency: int = 5
    retry_policy: RetryPolicy = field(default_factory=RetryPolicy)

    async def execute(
        self,
        tasks: Sequence[ParallelTask],
        executor_fn: Callable[..., Awaitable[dict[str, Any]]] | None = None,
    ) -> list[StepResult]:
        """Ejecuta tareas en paralelo con limite de concurrencia.

        Parameters
        ----------
        tasks:
            Secuencia de tareas a ejecutar.
        executor_fn:
            Funcion asincrona que ejecuta cada tarea.
            Firma: ``(agent, action, inputs) -> dict``.
            Si es None, usa el stub por defecto.

        Returns
        -------
        list[StepResult]
            Resultados de cada tarea.
        """
        if not tasks:
            return []

        fn = executor_fn or self._stub_execute
        semaphore = asyncio.Semaphore(self.max_concurrency)

        async def _run_task(task: ParallelTask) -> StepResult:
            async with semaphore:
                return await self._execute_single(task, fn)

        logger.info(
            "parallel_execute tasks=%d concurrency=%d",
            len(tasks), self.max_concurrency,
        )

        results = await asyncio.gather(
            *[_run_task(t) for t in tasks],
            return_exceptions=True,
        )

        step_results: list[StepResult] = []
        for i, result in enumerate(results):
            if isinstance(result, BaseException):
                step_results.append(StepResult(
                    step_id=tasks[i].step_id,
                    agent=tasks[i].agent,
                    action=tasks[i].action,
                    status="failed",
                    error=str(result),
                ))
            else:
                step_results.append(result)

        completed = sum(1 for r in step_results if r.status == "completed")
        logger.info(
            "parallel_complete total=%d completed=%d failed=%d",
            len(step_results), completed, len(step_results) - completed,
        )
        return step_results

    async def _execute_single(
        self,
        task: ParallelTask,
        executor_fn: Callable[..., Awaitable[dict[str, Any]]],
    ) -> StepResult:
        """Ejecuta una tarea individual con reintentos."""
        start = time.monotonic()
        try:
            output = await self.retry_policy.execute(
                executor_fn,
                task.agent,
                task.action,
                task.inputs,
            )
            elapsed = (time.monotonic() - start) * 1000
            return StepResult(
                step_id=task.step_id,
                agent=task.agent,
                action=task.action,
                status="completed",
                output=output,
                duration_ms=elapsed,
            )
        except Exception as exc:  # noqa: BLE001
            elapsed = (time.monotonic() - start) * 1000
            logger.error(
                "step_failed step=%s agent=%s error=%s",
                task.step_id, task.agent, exc,
            )
            return StepResult(
                step_id=task.step_id,
                agent=task.agent,
                action=task.action,
                status="failed",
                duration_ms=elapsed,
                error=str(exc),
            )

    @staticmethod
    async def _stub_execute(
        agent: str,
        action: str,
        inputs: dict[str, Any],
    ) -> dict[str, Any]:
        """Stub de ejecucion para demos. Simula trabajo con un delay."""
        await asyncio.sleep(0.05)
        return {
            "agent": agent,
            "action": action,
            "status": "completed",
            "message": f"[DEMO] {agent}:{action} ejecutado correctamente",
            "inputs_received": list(inputs.keys()),
        }
