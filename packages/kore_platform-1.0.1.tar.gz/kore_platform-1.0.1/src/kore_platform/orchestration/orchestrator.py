"""Orchestrator — main entry point for plan generation and execution."""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import TYPE_CHECKING, Any

from ..application.ports.outbound.audit_log import AuditLogPort
from ..application.ports.outbound.message_bus import MessageBusPort
from ..domain.entities.user_context import UserContext
from ..domain.value_objects.execution_result import ExecutionResult, StepResult
from ..domain.value_objects.job_id import JobId
from ..infrastructure.security.guardian import Guardian
from ..infrastructure.security.signature_verifier import SignatureVerifier
from ..interview.plan_generator import Plan, PlanGenerator, PlanStep
from .flow_engine import FlowEngine
from .parallel_executor import ParallelExecutor, ParallelTask
from .validation_loop import ValidationLoop

if TYPE_CHECKING:
    from ..agents.base.agent import BaseAgent
    from ..infrastructure.workspace.workspace_manager import WorkspaceManager

logger = logging.getLogger(__name__)


@dataclass
class Orchestrator:
    """Orquestador principal. Genera planes, solicita confirmacion, ejecuta.

    Cuando agent_registry esta configurado, ejecuta agentes reales.
    Cuando no, usa stubs de demo.
    """

    bus: MessageBusPort | None = None
    audit_log: AuditLogPort | None = None
    guardian: Guardian = field(default_factory=Guardian)
    signature_verifier: SignatureVerifier | None = None
    flow_engine: FlowEngine = field(default_factory=FlowEngine)
    plan_generator: PlanGenerator = field(default_factory=PlanGenerator)
    parallel_executor: ParallelExecutor = field(default_factory=ParallelExecutor)
    validation_loop: ValidationLoop = field(default_factory=ValidationLoop)
    demo_mode: bool = True
    agent_registry: dict[str, BaseAgent] = field(default_factory=dict)
    workspace_manager: WorkspaceManager | None = None

    async def generate_plan(self, context: UserContext) -> Plan:
        """Genera un plan de ejecucion a partir del contexto del usuario."""
        logger.info("plan_generation_start level=%s", context.level.name)

        plan = await self.plan_generator.generate(context)

        await self._audit(
            job_id="plan-generation",
            event_type="plan_generated",
            data={
                "plan_id": plan.id,
                "steps": plan.step_count,
                "level": context.level.name,
            },
        )

        await self._publish("orchestrator.plan_generated", {
            "plan_id": plan.id,
            "step_count": plan.step_count,
            "estimated_minutes": plan.estimated_duration_minutes,
        })

        logger.info(
            "plan_generated id=%s steps=%d",
            plan.id, plan.step_count,
        )
        return plan

    async def request_user_confirmation(self, plan: Plan) -> bool:
        """Solicita confirmacion del usuario para ejecutar el plan."""
        if self.demo_mode:
            logger.info("plan_auto_confirmed id=%s (demo_mode)", plan.id)
            await self._audit(
                job_id=plan.id,
                event_type="plan_auto_confirmed",
                data={"plan_id": plan.id, "demo_mode": True},
            )
            return True

        await self._publish("orchestrator.confirmation_requested", {
            "plan_id": plan.id,
            "steps": plan.step_count,
            "estimated_minutes": plan.estimated_duration_minutes,
        })

        logger.info("plan_confirmation_pending id=%s", plan.id)
        return True

    async def execute(
        self,
        plan: Plan,
        context: UserContext,
    ) -> ExecutionResult:
        """Ejecuta un plan completo con agentes reales o stubs."""
        job_id = JobId.generate()
        start = time.monotonic()

        # Crear workspace si tenemos manager
        workspace: Path | None = None
        if self.workspace_manager is not None:
            workspace = self.workspace_manager.create_job_workspace(str(job_id))

        logger.info(
            "execution_start plan=%s job=%s steps=%d workspace=%s",
            plan.id, job_id, plan.step_count, workspace,
        )

        await self._audit(
            job_id=str(job_id),
            event_type="execution_started",
            data={"plan_id": plan.id, "level": context.level.name},
        )

        # Separar pasos secuenciales de paralelos
        sequential_steps: list[PlanStep] = []
        parallel_groups: dict[str, list[PlanStep]] = {}

        for step in plan.steps:
            if step.parallel_group:
                parallel_groups.setdefault(step.parallel_group, []).append(step)
            else:
                sequential_steps.append(step)

        all_results: list[StepResult] = []
        artifacts: dict[str, Any] = {}

        # Ejecutar pasos secuenciales
        for step in sequential_steps:
            # Validar con Guardian
            guard = self.guardian.validate_agent_action(
                agent_name=step.agent,
                action=step.action,
                inputs=step.inputs,
            )
            if not guard.allowed:
                logger.warning(
                    "step_blocked step=%s reason=%s", step.id, guard.reason,
                )
                all_results.append(StepResult(
                    step_id=step.id,
                    agent=step.agent,
                    action=step.action,
                    status="blocked",
                    error=guard.reason,
                ))
                continue

            result = await self._execute_step(step, artifacts, workspace)
            all_results.append(result)
            if result.output:
                artifacts[f"{step.agent}:{step.action}"] = result.output

            # Escribir archivos generados al workspace
            if workspace is not None and self.workspace_manager is not None:
                self._write_artifacts_to_workspace(result.output, workspace)

        # Ejecutar grupos paralelos
        for group_name, group_steps in parallel_groups.items():
            executor_fn = self._make_parallel_executor_fn(artifacts, workspace)
            tasks = [
                ParallelTask(
                    step_id=s.id,
                    agent=s.agent,
                    action=s.action,
                    inputs=s.inputs,
                )
                for s in group_steps
            ]
            group_results = await self.parallel_executor.execute(tasks, executor_fn=executor_fn)
            all_results.extend(group_results)
            for r in group_results:
                if r.output:
                    artifacts[f"{r.agent}:{r.action}"] = r.output

        # ---------------------------------------------------------------
        # Validation loop: si tenemos code + tests, validar
        # ---------------------------------------------------------------
        code_artifact = artifacts.get("coder:implement_feature")
        test_artifact = artifacts.get("tester:write_unit_tests")

        if code_artifact and test_artifact and workspace:
            logger.info("validation_loop_start")
            coder_agent = self.agent_registry.get("coder") if self.agent_registry else None
            # Recopilar inputs originales del coder
            coder_inputs = {}
            for step in plan.steps:
                if step.agent == "coder" and step.action == "implement_feature":
                    coder_inputs = self._enrich_inputs(step.inputs, artifacts)
                    break

            # Pass guardian to validation loop for code scanning
            self.validation_loop.guardian = self.guardian

            validation_result = await self.validation_loop.run(
                code_output=code_artifact,
                test_output=test_artifact,
                coder_agent=coder_agent,
                workspace=workspace,
                workspace_manager=self.workspace_manager,
                original_inputs=coder_inputs,
            )

            # Actualizar artifacts con codigo corregido
            if validation_result.fixed_files:
                code_artifact["files"] = validation_result.fixed_files
                artifacts["coder:implement_feature"] = code_artifact

            # Registrar resultado de validacion
            all_results.append(StepResult(
                step_id="validation-loop",
                agent="validation",
                action="self_validate",
                status="completed" if validation_result.success else "failed",
                output={
                    "success": validation_result.success,
                    "attempts": validation_result.attempts,
                    "last_exit_code": validation_result.last_exit_code,
                    "stdout": validation_result.last_stdout[:500],
                    "stderr": validation_result.last_stderr[:500],
                },
            ))
            logger.info(
                "validation_loop_done success=%s attempts=%d",
                validation_result.success, validation_result.attempts,
            )

        elapsed = (time.monotonic() - start) * 1000

        execution_result = ExecutionResult(
            job_id=job_id,
            steps=tuple(all_results),
            artifacts=artifacts,
            metrics={
                "total_steps": len(all_results),
                "completed": sum(1 for r in all_results if r.status == "completed"),
                "failed": sum(1 for r in all_results if r.status == "failed"),
                "blocked": sum(1 for r in all_results if r.status == "blocked"),
                "total_duration_ms": elapsed,
                "plan_id": plan.id,
                "workspace": str(workspace) if workspace else None,
            },
        )

        await self._audit(
            job_id=str(job_id),
            event_type="execution_completed",
            data={
                "plan_id": plan.id,
                "success": execution_result.success,
                "summary": execution_result.summary,
                "duration_ms": elapsed,
            },
        )

        await self._publish("orchestrator.execution_completed", {
            "job_id": str(job_id),
            "plan_id": plan.id,
            "success": execution_result.success,
            "summary": execution_result.summary,
        })

        logger.info(
            "execution_complete job=%s success=%s summary=%s duration=%.0fms",
            job_id, execution_result.success, execution_result.summary, elapsed,
        )
        return execution_result

    # ------------------------------------------------------------------
    # Internos
    # ------------------------------------------------------------------

    async def _execute_step(
        self,
        step: PlanStep,
        artifacts: dict[str, Any],
        workspace: Path | None = None,
    ) -> StepResult:
        """Ejecuta un paso individual. Usa agentes reales si estan registrados."""
        start = time.monotonic()
        try:
            agent = self.agent_registry.get(step.agent) if self.agent_registry else None
            if agent is not None and agent.has_skill(step.action):
                # Ejecucion REAL con agente
                enriched_inputs = self._enrich_inputs(step.inputs, artifacts)
                exec_context: dict[str, Any] = {}
                if workspace is not None:
                    exec_context["workspace"] = workspace

                output = await agent.execute(step.action, enriched_inputs, exec_context)
                elapsed = (time.monotonic() - start) * 1000
                logger.info(
                    "step_completed agent=%s action=%s elapsed=%.0fms",
                    step.agent, step.action, elapsed,
                )
                return StepResult(
                    step_id=step.id,
                    agent=step.agent,
                    action=step.action,
                    status=output.get("status", "completed"),
                    output=output,
                    duration_ms=elapsed,
                )
            else:
                # Fallback: stub demo
                import asyncio
                await asyncio.sleep(0.02)
                elapsed = (time.monotonic() - start) * 1000
                return StepResult(
                    step_id=step.id,
                    agent=step.agent,
                    action=step.action,
                    status="completed",
                    output={
                        "message": f"[DEMO] {step.agent}:{step.action} completado",
                        "description": step.description,
                    },
                    duration_ms=elapsed,
                )
        except Exception as exc:  # noqa: BLE001
            elapsed = (time.monotonic() - start) * 1000
            logger.error(
                "step_failed agent=%s action=%s error=%s", step.agent, step.action, exc,
            )
            return StepResult(
                step_id=step.id,
                agent=step.agent,
                action=step.action,
                status="failed",
                duration_ms=elapsed,
                error=str(exc),
            )

    @staticmethod
    def _enrich_inputs(
        step_inputs: dict[str, Any],
        artifacts: dict[str, Any],
    ) -> dict[str, Any]:
        """Enriquece inputs de un paso con artifacts de pasos anteriores."""
        enriched = dict(step_inputs)

        # Pasar artefactos relevantes de pasos previos
        for key, value in artifacts.items():
            agent_name, action_name = key.split(":", 1)
            # Mapear outputs comunes al siguiente paso
            if action_name == "analyze_requirements" and "requirements" not in enriched:
                enriched["requirements"] = value
            elif action_name == "generate_user_stories" and "user_stories" not in enriched:
                enriched["user_stories"] = value.get("user_stories", [])
            elif action_name == "design_architecture" and "architecture" not in enriched:
                enriched["architecture"] = value.get("architecture", value)
            elif action_name == "generate_schemas" and "schemas" not in enriched:
                enriched["schemas"] = value.get("schemas", value.get("models", []))
            elif action_name == "create_api_spec" and "api_spec" not in enriched:
                enriched["api_spec"] = value
            elif action_name == "implement_feature" and "files" not in enriched:
                enriched["files"] = value.get("files", [])
                enriched["code"] = value

        return enriched

    def _write_artifacts_to_workspace(
        self,
        output: dict[str, Any],
        workspace: Path,
    ) -> None:
        """Escribe archivos generados al workspace."""
        if not output or self.workspace_manager is None:
            return

        files = output.get("files", [])
        for f in files:
            path = f.get("path", "")
            content = f.get("content", "")
            if path and content:
                self.workspace_manager.write_file(workspace, path, content)

    def _make_parallel_executor_fn(
        self,
        artifacts: dict[str, Any],
        workspace: Path | None,
    ) -> Any:
        """Crea una funcion ejecutora para el ParallelExecutor."""
        agent_registry = self.agent_registry

        async def _executor(
            agent_name: str,
            action: str,
            inputs: dict[str, Any],
        ) -> dict[str, Any]:
            agent = agent_registry.get(agent_name) if agent_registry else None
            if agent is not None and agent.has_skill(action):
                enriched = Orchestrator._enrich_inputs(inputs, artifacts)
                ctx: dict[str, Any] = {}
                if workspace is not None:
                    ctx["workspace"] = workspace
                return await agent.execute(action, enriched, ctx)
            else:
                import asyncio
                await asyncio.sleep(0.02)
                return {
                    "status": "completed",
                    "message": f"[DEMO] {agent_name}:{action} ejecutado",
                }

        return _executor

    async def _audit(
        self,
        job_id: str,
        event_type: str,
        data: dict[str, Any],
    ) -> None:
        """Registra en audit log si esta disponible."""
        if self.audit_log is not None:
            await self.audit_log.append(
                job_id=job_id,
                event_type=event_type,
                data=data,
                timestamp=datetime.now(timezone.utc),
            )

    async def _publish(self, channel: str, message: dict[str, Any]) -> None:
        """Publica en bus de mensajes si esta disponible."""
        if self.bus is not None:
            await self.bus.publish(channel=channel, message=message)
