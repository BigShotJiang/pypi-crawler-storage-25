"""Decision engine — evaluates conditions for flow branching."""

from __future__ import annotations

import logging
import operator
from typing import Any

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Operadores soportados (whitelist para evitar eval/exec)
# ---------------------------------------------------------------------------

_OPERATORS: dict[str, Any] = {
    "==": operator.eq,
    "!=": operator.ne,
    ">": operator.gt,
    ">=": operator.ge,
    "<": operator.lt,
    "<=": operator.le,
    "in": lambda a, b: a in b,
    "not_in": lambda a, b: a not in b,
    "contains": lambda a, b: b in a,
    "is_true": lambda a, _: bool(a),
    "is_false": lambda a, _: not bool(a),
    "is_none": lambda a, _: a is None,
    "is_not_none": lambda a, _: a is not None,
}


class DecisionEngine:
    """Motor de decisiones para flujos. Evalua condiciones de forma segura.

    Todos los metodos son estaticos — no mantiene estado.
    """

    @staticmethod
    def evaluate(
        condition: str,
        context: dict[str, Any],
    ) -> bool:
        """Evalua una condicion contra un contexto.

        Formato de condicion:
            ``"variable operator value"``

        Ejemplos:
            ``"level == ENGINEER"``
            ``"test_coverage > 80"``
            ``"needs_monitoring is_true"``

        Parameters
        ----------
        condition:
            String de condicion a evaluar.
        context:
            Diccionario con variables disponibles.

        Returns
        -------
        bool
            Resultado de la evaluacion.
        """
        parts = condition.strip().split(None, 2)

        if len(parts) < 2:
            logger.warning("invalid_condition condition='%s'", condition)
            return False

        var_name = parts[0]
        op_name = parts[1]
        raw_value = parts[2] if len(parts) > 2 else None

        # Obtener valor de la variable
        actual = context.get(var_name)
        if actual is None and op_name not in ("is_none", "is_not_none"):
            logger.debug("variable_not_found var=%s", var_name)
            return False

        # Obtener operador
        op_func = _OPERATORS.get(op_name)
        if op_func is None:
            logger.warning("unknown_operator op=%s", op_name)
            return False

        # Convertir valor esperado al tipo del actual
        expected = DecisionEngine._coerce(raw_value, type(actual) if actual is not None else str)

        try:
            result = op_func(actual, expected)
            logger.debug(
                "decision_evaluated condition='%s' result=%s",
                condition, result,
            )
            return bool(result)
        except (TypeError, ValueError) as exc:
            logger.warning(
                "decision_evaluation_error condition='%s' error=%s",
                condition, exc,
            )
            return False

    @staticmethod
    def evaluate_all(
        conditions: list[str],
        context: dict[str, Any],
        require_all: bool = True,
    ) -> bool:
        """Evalua multiples condiciones.

        Parameters
        ----------
        conditions:
            Lista de condiciones.
        context:
            Diccionario de contexto.
        require_all:
            Si True, todas deben ser verdaderas (AND).
            Si False, al menos una (OR).
        """
        results = [DecisionEngine.evaluate(c, context) for c in conditions]
        return all(results) if require_all else any(results)

    @staticmethod
    def _coerce(raw: str | None, target_type: type) -> Any:
        """Intenta convertir un string al tipo objetivo."""
        if raw is None:
            return None

        if target_type is bool:
            return raw.lower() in ("true", "1", "yes", "si")
        if target_type is int:
            try:
                return int(raw)
            except ValueError:
                return raw
        if target_type is float:
            try:
                return float(raw)
            except ValueError:
                return raw
        return raw
