"""Retry policy — exponential backoff with jitter."""

from __future__ import annotations

import asyncio
import logging
import random
from dataclasses import dataclass
from typing import Any, Awaitable, Callable, TypeVar

logger = logging.getLogger(__name__)

T = TypeVar("T")


@dataclass(frozen=True, slots=True)
class RetryPolicy:
    """Politica de reintentos con backoff exponencial.

    Inmutable (frozen=True). Cada invocacion a ``execute`` es independiente.
    """

    max_retries: int = 3
    base_delay_seconds: float = 1.0
    max_delay_seconds: float = 30.0
    exponential_base: float = 2.0
    jitter: bool = True

    def _compute_delay(self, attempt: int) -> float:
        """Calcula el delay para el intento dado."""
        delay = self.base_delay_seconds * (self.exponential_base ** attempt)
        delay = min(delay, self.max_delay_seconds)
        if self.jitter:
            delay = delay * (0.5 + random.random() * 0.5)  # noqa: S311
        return delay

    async def execute(
        self,
        func: Callable[..., Awaitable[T]],
        *args: Any,
        **kwargs: Any,
    ) -> T:
        """Ejecuta ``func`` con reintentos y backoff exponencial.

        Parameters
        ----------
        func:
            Funcion asincrona a ejecutar.
        *args, **kwargs:
            Argumentos para la funcion.

        Returns
        -------
        T
            Resultado de la funcion.

        Raises
        ------
        Exception
            La ultima excepcion si se agotan los reintentos.
        """
        last_error: Exception | None = None

        for attempt in range(self.max_retries + 1):
            try:
                return await func(*args, **kwargs)
            except Exception as exc:  # noqa: BLE001
                last_error = exc
                if attempt >= self.max_retries:
                    logger.error(
                        "retry_exhausted func=%s attempts=%d error=%s",
                        getattr(func, "__name__", str(func)),
                        attempt + 1,
                        str(exc),
                    )
                    raise

                delay = self._compute_delay(attempt)
                logger.warning(
                    "retry_attempt func=%s attempt=%d/%d delay=%.2fs error=%s",
                    getattr(func, "__name__", str(func)),
                    attempt + 1,
                    self.max_retries,
                    delay,
                    str(exc),
                )
                await asyncio.sleep(delay)

        # Inalcanzable, pero satisface al type checker
        assert last_error is not None  # noqa: S101
        raise last_error
