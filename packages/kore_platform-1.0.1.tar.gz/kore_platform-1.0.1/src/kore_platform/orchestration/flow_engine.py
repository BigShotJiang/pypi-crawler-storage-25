"""Flow engine — loads YAML flows, validates with Guardian, executes steps."""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Sequence

import yaml

from ..domain.entities.flow import Flow, FlowDecision, FlowStep
from ..domain.value_objects.execution_result import ExecutionResult, StepResult
from ..domain.value_objects.job_id import JobId
from ..infrastructure.security.guardian import Guardian, GuardianResult
from ..infrastructure.security.signature_verifier import SignatureVerifier
from .decision_engine import DecisionEngine
from .parallel_executor import ParallelExecutor, ParallelTask
from .retry_policy import RetryPolicy

logger = logging.getLogger(__name__)


def _parse_flow(data: dict[str, Any]) -> Flow:
    """Parsea un dict (de YAML) a una entidad Flow."""
    raw_steps = data.get("steps", [])
    steps: list[FlowStep | FlowDecision] = []

    for s in raw_steps:
        if "condition" in s:
            steps.append(FlowDecision(
                name=s["name"],
                condition=s["condition"],
                on_true=s["on_true"],
                on_false=s["on_false"],
            ))
        else:
            steps.append(FlowStep(
                agent=s["agent"],
                action=s["action"],
                inputs=tuple(s.get("inputs", [])),
                outputs=tuple(s.get("outputs", [])),
                timeout_seconds=s.get("timeout_seconds", 300),
                retries=s.get("retries", 0),
            ))

    return Flow(
        name=data.get("name", "unnamed"),
        trigger=data.get("trigger", "manual"),
        description=data.get("description", ""),
        steps=tuple(steps),
        alerts=tuple(data.get("alerts", [])),
        version=data.get("version", "1.0"),
    )


@dataclass
class FlowEngine:
    """Motor de flujos. Carga YAML, valida con Guardian, ejecuta paso a paso."""

    guardian: Guardian = field(default_factory=Guardian)
    signature_verifier: SignatureVerifier | None = None
    parallel_executor: ParallelExecutor = field(default_factory=ParallelExecutor)
    retry_policy: RetryPolicy = field(default_factory=RetryPolicy)
    flows_dir: Path | None = None
    agent_registry: dict[str, Any] = field(default_factory=dict)

    def load_flow(self, flow_name: str) -> Flow:
        """Carga un flujo desde YAML o devuelve un flujo demo.

        Parameters
        ----------
        flow_name:
            Nombre del flujo a cargar.

        Returns
        -------
        Flow
            Flujo cargado y parseado.
        """
        if self.flows_dir is not None:
            yaml_path = self.flows_dir / f"{flow_name}.yaml"
            if yaml_path.exists():
                if self.signature_verifier is not None:
                    data = self.signature_verifier.verify_and_load(yaml_path)
                else:
                    with open(yaml_path) as f:
                        data = yaml.safe_load(f)
                logger.info("flow_loaded name=%s path=%s", flow_name, yaml_path)
                return _parse_flow(data)

        # Flujo demo si no hay YAML
        logger.info("flow_demo_fallback name=%s", flow_name)
        return self._demo_flow(flow_name)

    async def execute_flow(
        self,
        flow: Flow,
        context: dict[str, Any],
        job_id: JobId | None = None,
    ) -> ExecutionResult:
        """Ejecuta un flujo paso a paso, validando con Guardian antes de cada paso.

        Parameters
        ----------
        flow:
            Flujo a ejecutar.
        context:
            Contexto de ejecucion (variables disponibles para decisiones).
        job_id:
            ID del job. Se genera uno si no se proporciona.

        Returns
        -------
        ExecutionResult
            Resultado completo de la ejecucion.
        """
        jid = job_id or JobId.generate()
        results: list[StepResult] = []
        artifacts: dict[str, Any] = {}

        logger.info("flow_execute name=%s steps=%d job=%s", flow.name, flow.step_count, jid)

        for i, step in enumerate(flow.steps):
            if isinstance(step, FlowDecision):
                # Evaluar decision
                result = DecisionEngine.evaluate(step.condition, context)
                next_step = step.on_true if result else step.on_false
                logger.info(
                    "decision_evaluated name=%s result=%s next=%s",
                    step.name, result, next_step,
                )
                results.append(StepResult(
                    step_id=f"decision-{i}",
                    agent="decision_engine",
                    action=step.name,
                    status="completed",
                    output={"result": result, "next": next_step},
                ))
                continue

            # Validar con Guardian
            guard_result: GuardianResult = self.guardian.validate_agent_action(
                agent_name=step.agent,
                action=step.action,
                inputs=dict(zip(step.inputs, step.inputs)),
            )

            if not guard_result.allowed:
                logger.warning(
                    "step_blocked agent=%s action=%s reason=%s",
                    step.agent, step.action, guard_result.reason,
                )
                results.append(StepResult(
                    step_id=f"step-{i}",
                    agent=step.agent,
                    action=step.action,
                    status="blocked",
                    error=guard_result.reason,
                ))
                continue

            # Ejecutar paso
            step_result = await self._execute_step(step, i, context)
            results.append(step_result)

            if step_result.output:
                artifacts[f"{step.agent}:{step.action}"] = step_result.output

        return ExecutionResult(
            job_id=jid,
            steps=tuple(results),
            artifacts=artifacts,
            metrics={
                "total_steps": len(results),
                "completed": sum(1 for r in results if r.status == "completed"),
                "failed": sum(1 for r in results if r.status == "failed"),
                "blocked": sum(1 for r in results if r.status == "blocked"),
                "total_duration_ms": sum(r.duration_ms for r in results),
            },
        )

    async def _execute_step(
        self,
        step: FlowStep,
        index: int,
        context: dict[str, Any],
    ) -> StepResult:
        """Ejecuta un paso individual con reintentos."""
        start = time.monotonic()
        try:
            output = await self.retry_policy.execute(
                self._real_or_stub_execute,
                step.agent,
                step.action,
                context,
            )
            elapsed = (time.monotonic() - start) * 1000
            return StepResult(
                step_id=f"step-{index}",
                agent=step.agent,
                action=step.action,
                status="completed",
                output=output,
                duration_ms=elapsed,
            )
        except Exception as exc:  # noqa: BLE001
            elapsed = (time.monotonic() - start) * 1000
            return StepResult(
                step_id=f"step-{index}",
                agent=step.agent,
                action=step.action,
                status="failed",
                duration_ms=elapsed,
                error=str(exc),
            )

    async def _real_or_stub_execute(
        self,
        agent_name: str,
        action: str,
        context: dict[str, Any],
    ) -> dict[str, Any]:
        """Ejecuta con agente real si disponible, sino usa stub."""
        agent = self.agent_registry.get(agent_name) if self.agent_registry else None
        if agent is not None and hasattr(agent, "has_skill") and agent.has_skill(action):
            return await agent.execute(action, context, context)
        return {
            "agent": agent_name,
            "action": action,
            "status": "completed",
            "message": f"[DEMO] {agent_name}:{action} ejecutado correctamente",
        }

    @staticmethod
    def _demo_flow(name: str) -> Flow:
        """Genera un flujo demo minimo."""
        return Flow(
            name=name,
            trigger="manual",
            description=f"Demo flow: {name}",
            steps=(
                FlowStep(agent="architect", action="analyze", inputs=(), outputs=()),
                FlowStep(agent="coder", action="generate", inputs=(), outputs=()),
                FlowStep(agent="tester", action="test", inputs=(), outputs=()),
                FlowStep(agent="delivery", action="package", inputs=(), outputs=()),
            ),
            version="demo",
        )
