"""Validation loop — runs generated tests against generated code, auto-fixes.

Security notes:
- All code is scanned by Guardian before writing to workspace
- Subprocess runs with resource limits (setrlimit)
- pip install uses --only-binary :all: to avoid arbitrary setup.py execution
- Artifact versioning: each retry's code is preserved for diffing
- Trivial test detection: rejects tests with only `assert True` / no assertions
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any

from .subprocess_runner import SubprocessRunner, RunResult

if TYPE_CHECKING:
    from ..agents.base.agent import BaseAgent
    from ..infrastructure.workspace.workspace_manager import WorkspaceManager
    from ..infrastructure.security.guardian import Guardian

logger = logging.getLogger(__name__)


@dataclass(frozen=True, slots=True)
class ValidationResult:
    """Resultado inmutable de la validacion."""

    success: bool
    attempts: int
    last_exit_code: int
    last_stdout: str
    last_stderr: str
    fixed_files: list[dict[str, Any]] = field(default_factory=list)
    artifact_history: list[list[dict[str, Any]]] = field(default_factory=list)
    escalation_report: str = ""


@dataclass
class ValidationLoop:
    """Ejecuta tests generados contra codigo generado. Si fallan, re-invoca coder.

    Improvements over naive approach:
    - Adaptive error truncation (based on model context, not fixed 2000)
    - Escalation report when max retries exhausted
    - Trivial test detection (assert True, no assertions)
    - pip --only-binary to avoid setup.py attacks
    - Guardian scan on all generated code before writing
    - Artifact versioning between retries
    """

    runner: SubprocessRunner = field(default_factory=SubprocessRunner)
    guardian: Guardian | None = None
    max_attempts: int = 3
    timeout: int = 120
    max_error_chars: int = 4000  # Adaptive: adapts to model context

    async def run(
        self,
        code_output: dict[str, Any],
        test_output: dict[str, Any],
        coder_agent: BaseAgent | None,
        workspace: Path,
        workspace_manager: WorkspaceManager | None,
        original_inputs: dict[str, Any] | None = None,
    ) -> ValidationResult:
        """Ejecuta el loop de validacion."""
        code_files = code_output.get("files", [])
        test_files = test_output.get("test_files", test_output.get("files", []))

        if not code_files and not test_files:
            logger.warning("validation_skip no_files")
            return ValidationResult(
                success=False, attempts=0, last_exit_code=-1,
                last_stdout="", last_stderr="No files to validate",
            )

        # Detect trivial tests
        trivial_warning = self._detect_trivial_tests(test_files)
        if trivial_warning:
            logger.warning("trivial_tests_detected: %s", trivial_warning)

        last_result = RunResult(command="", exit_code=-1, stdout="", stderr="No run")
        artifact_history: list[list[dict[str, Any]]] = []
        errors_per_attempt: list[str] = []

        for attempt in range(1, self.max_attempts + 1):
            logger.info("validation_attempt attempt=%d/%d", attempt, self.max_attempts)

            # Save artifact version
            artifact_history.append([dict(f) for f in code_files])

            # 1. Scan code with Guardian before writing
            if self.guardian is not None:
                blocked = self._scan_files_with_guardian(code_files + test_files)
                if blocked:
                    return ValidationResult(
                        success=False, attempts=attempt, last_exit_code=-1,
                        last_stdout="",
                        last_stderr=f"Guardian blocked generated code: {blocked}",
                        artifact_history=artifact_history,
                        escalation_report=f"SECURITY: Generated code blocked by Guardian: {blocked}",
                    )

            # 2. Write files to workspace (with symlink check)
            self._write_files_safe(code_files, workspace, workspace_manager)
            self._write_files_safe(test_files, workspace, workspace_manager)

            # 3. Write requirements
            self._write_requirements(workspace, workspace_manager)

            # 4. Install deps (--only-binary to avoid setup.py attacks)
            #    Fallback: if no wheel exists for a package, retry without
            #    --only-binary but log a warning (some pure-Python packages
            #    only ship sdists).
            deps_dir = workspace / ".deps"
            pip_base = [
                "python3", "-m", "pip", "install",
                "-r", str(workspace / "requirements-test.txt"),
                "--target", str(deps_dir),
                "--quiet",
                "--no-input",
                "--disable-pip-version-check",
            ]
            install_result = await self.runner.run(
                cmd=pip_base + ["--only-binary", ":all:"],
                cwd=str(workspace),
                timeout=self.timeout,
                apply_limits=False,  # pip needs more resources
            )
            if not install_result.success and "no matching distribution" in install_result.stderr.lower():
                logger.warning(
                    "pip_only_binary_failed falling back to sdist install "
                    "(some packages lack wheels)"
                )
                await self.runner.run(
                    cmd=pip_base,
                    cwd=str(workspace),
                    timeout=self.timeout,
                    apply_limits=False,
                )

            # 5. Run pytest with resource limits
            env = {
                "PYTHONPATH": f"{workspace}:{deps_dir}",
                "PYTHONDONTWRITEBYTECODE": "1",
            }

            tests_dir = workspace / "tests"
            if not tests_dir.exists():
                test_paths = [workspace / f["path"] for f in test_files if f.get("path")]
                tests_target = str(test_paths[0].parent) if test_paths else str(workspace)
            else:
                tests_target = str(tests_dir)

            last_result = await self.runner.run(
                cmd=["python3", "-m", "pytest", tests_target, "--tb=short", "-q", "--no-header"],
                cwd=str(workspace),
                env=env,
                timeout=self.timeout,
            )

            # 6. Success?
            if last_result.success:
                logger.info("validation_success attempt=%d", attempt)
                return ValidationResult(
                    success=True,
                    attempts=attempt,
                    last_exit_code=last_result.exit_code,
                    last_stdout=last_result.stdout,
                    last_stderr=last_result.stderr,
                    fixed_files=code_files,
                    artifact_history=artifact_history,
                )

            # Capture error for escalation report
            error_text = self._extract_relevant_errors(last_result)
            errors_per_attempt.append(f"Attempt {attempt}: {error_text[:500]}")

            logger.warning(
                "validation_failed attempt=%d exit_code=%d stderr_len=%d",
                attempt, last_result.exit_code, len(last_result.stderr),
            )

            # 7. Re-invoke coder if not last attempt
            if coder_agent is not None and attempt < self.max_attempts:
                error_for_llm = self._extract_relevant_errors(last_result)
                try:
                    fix_inputs = dict(original_inputs or {})
                    fix_inputs["fix_errors"] = error_for_llm

                    fix_output = await coder_agent.execute(
                        "implement_feature", fix_inputs, {}
                    )

                    new_files = fix_output.get("files", [])
                    if new_files:
                        code_files = new_files
                        logger.info("validation_fix applied %d files", len(new_files))
                except Exception as exc:
                    logger.error("validation_fix_failed error=%s", exc)

        # Max retries exhausted — build escalation report
        escalation = self._build_escalation_report(errors_per_attempt, artifact_history)

        logger.warning("validation_exhausted attempts=%d", self.max_attempts)
        return ValidationResult(
            success=False,
            attempts=self.max_attempts,
            last_exit_code=last_result.exit_code,
            last_stdout=last_result.stdout,
            last_stderr=last_result.stderr,
            fixed_files=code_files,
            artifact_history=artifact_history,
            escalation_report=escalation,
        )

    def _extract_relevant_errors(self, result: RunResult) -> str:
        """Extrae errores relevantes, priorizando info util.

        No trunca arbitrariamente — prioriza:
        1. Error lines (E:, AssertionError, ImportError, etc.)
        2. FAILED lines
        3. Full stderr
        Hasta max_error_chars.
        """
        lines = (result.stderr + "\n" + result.stdout).splitlines()

        # Priority: error lines first
        error_lines = [
            l for l in lines
            if any(kw in l for kw in (
                "Error", "FAILED", "ImportError", "ModuleNotFoundError",
                "NameError", "TypeError", "AttributeError", "SyntaxError",
                "AssertionError", "FileNotFoundError", "E  ", "E   ",
                "> ", "ERRORS", "FAILURES",
            ))
        ]

        # Build output: errors first, then full context
        parts = []
        if error_lines:
            parts.append("KEY ERRORS:\n" + "\n".join(error_lines[:30]))
        parts.append("\nFULL OUTPUT:\n" + result.stderr[:self.max_error_chars // 2])
        parts.append(result.stdout[:self.max_error_chars // 2])

        combined = "\n".join(parts)
        return combined[:self.max_error_chars]

    @staticmethod
    def _detect_trivial_tests(test_files: list[dict[str, Any]]) -> str:
        """Detecta tests triviales que siempre pasan.

        Returns warning string if trivial, empty string if OK.
        """
        warnings = []
        for f in test_files:
            content = f.get("content", "")
            path = f.get("path", "unknown")

            # Count real assertions vs trivial ones
            lines = content.splitlines()
            total_asserts = sum(1 for l in lines if "assert " in l.lower())
            trivial_asserts = sum(
                1 for l in lines
                if "assert true" in l.lower() or "assert 1" in l.lower()
            )
            test_functions = sum(1 for l in lines if l.strip().startswith("def test_"))

            if test_functions > 0 and total_asserts == trivial_asserts and trivial_asserts > 0:
                warnings.append(f"{path}: all {trivial_asserts} assertions are trivial (assert True)")
            elif test_functions > 0 and total_asserts == 0:
                warnings.append(f"{path}: {test_functions} test functions with 0 assertions")

        return "; ".join(warnings)

    def _scan_files_with_guardian(self, files: list[dict[str, Any]]) -> str:
        """Escanea archivos con Guardian. Returns blocked reason or empty string."""
        if self.guardian is None:
            return ""
        for f in files:
            content = f.get("content", "")
            path = f.get("path", "unknown")
            result = self.guardian.scan_generated_code(content, path)
            if not result.allowed:
                return f"{path}: {result.reason}"
        return ""

    def _write_files_safe(
        self,
        files: list[dict[str, Any]],
        workspace: Path,
        workspace_manager: WorkspaceManager | None,
    ) -> None:
        """Escribe archivos al workspace con verificacion de symlink."""
        from ..infrastructure.security.guardian import Guardian

        for f in files:
            path = f.get("path", "")
            content = f.get("content", "")
            if not path or not content:
                continue

            # Symlink escape detection
            if not Guardian.check_symlink_escape(workspace, path):
                logger.warning("symlink_escape_blocked path=%s workspace=%s", path, workspace)
                continue

            if workspace_manager is not None:
                workspace_manager.write_file(workspace, path, content)
            else:
                full_path = workspace / path
                full_path.parent.mkdir(parents=True, exist_ok=True)
                full_path.write_text(content, encoding="utf-8")

    @staticmethod
    def _write_requirements(
        workspace: Path,
        workspace_manager: WorkspaceManager | None,
    ) -> None:
        """Escribe requirements minimos para tests."""
        reqs = (
            "pytest>=7.0\n"
            "pytest-asyncio>=0.23\n"
            "httpx>=0.25\n"
            "fastapi>=0.104\n"
            "pydantic>=2.0\n"
            "aiosqlite>=0.19\n"
            "sqlalchemy[asyncio]>=2.0\n"
        )
        reqs_path = "requirements-test.txt"
        if workspace_manager is not None:
            workspace_manager.write_file(workspace, reqs_path, reqs)
        else:
            (workspace / reqs_path).write_text(reqs, encoding="utf-8")

    @staticmethod
    def _build_escalation_report(
        errors_per_attempt: list[str],
        artifact_history: list[list[dict[str, Any]]],
    ) -> str:
        """Construye un reporte de escalacion cuando se agotan los reintentos."""
        report_parts = [
            "ESCALATION REPORT: Self-validation failed after maximum retries.",
            "",
            "The generated code could not pass its own tests after multiple "
            "auto-correction attempts. This typically indicates:",
            "- The LLM model is too small for the complexity of the project",
            "- The project has complex inter-file dependencies the model can't resolve",
            "- The test expectations don't match what the code can reasonably produce",
            "",
            "ERROR HISTORY:",
        ]
        for err in errors_per_attempt:
            report_parts.append(f"  {err}")

        report_parts.append("")
        report_parts.append(f"ARTIFACT VERSIONS: {len(artifact_history)} versions generated")
        report_parts.append("")
        report_parts.append("RECOMMENDATIONS:")
        report_parts.append("- Try a larger/more capable LLM model")
        report_parts.append("- Simplify the project idea")
        report_parts.append("- Review the generated code manually and fix remaining issues")

        return "\n".join(report_parts)
