"""Documenter agent -- documentation, manuals, and video scripts."""

from .agent import DocumenterAgent

__all__ = ["DocumenterAgent"]
