"""DocumenterAgent -- genera documentacion tecnica, manuales y guiones."""

from __future__ import annotations

from typing import Any

from ...application.ports.outbound.message_bus import MessageBusPort
from ...infrastructure.security.guardian import Guardian
from ..base.agent import BaseAgent
from .skills.generate_docs import GenerateDocsSkill
from .skills.generate_manual import GenerateManualSkill
from .skills.generate_video_script import GenerateVideoScriptSkill


class DocumenterAgent(BaseAgent):
    """Agente Documentador.

    Responsable de generar documentacion tecnica, manuales de usuario
    y guiones de video para tutoriales.
    """

    def __init__(
        self,
        bus: MessageBusPort | None = None,
        guardian: Guardian | None = None,
        llm_client: "LLMClientPort | None" = None,
    ) -> None:
        super().__init__(
            name="documenter",
            role="Redactor Tecnico",
            bus=bus,
            guardian=guardian,
            llm_client=llm_client,
        )
        self.register_skill(GenerateDocsSkill())
        self.register_skill(GenerateManualSkill())
        self.register_skill(GenerateVideoScriptSkill())

    async def handle_message(self, message: dict[str, Any]) -> dict[str, Any]:
        """Interpreta mensajes dirigidos al agente documentador."""
        action = message.get("action", "generate_docs")
        inputs = message.get("inputs", {})
        context = message.get("context", {})
        return await self.execute(action, inputs, context)
