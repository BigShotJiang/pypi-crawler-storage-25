"""Skill: generate technical documentation from source code."""

from __future__ import annotations

import json
from typing import Any

from ....domain.value_objects.agent_skill import SkillCategory
from ...base.skill import BaseSkill
from ...base.llm_utils import llm_json_call


_SYSTEM_PROMPT = """\
You are a technical writer. Generate comprehensive project documentation.

Respond ONLY with JSON:
{
  "files": [
    {
      "path": "docs/README.md",
      "content": "complete markdown content"
    },
    {
      "path": "docs/architecture.md",
      "content": "architecture documentation"
    },
    {
      "path": "docs/api-reference.md",
      "content": "API reference"
    }
  ]
}

Include:
- README.md with project overview, setup instructions, usage examples
- Architecture documentation with diagrams described in text
- API reference for all endpoints
- Configuration guide
"""


class GenerateDocsSkill(BaseSkill):
    """Genera documentacion tecnica a partir del codigo fuente."""

    def __init__(self) -> None:
        super().__init__(
            name="generate_docs",
            category=SkillCategory.DOCUMENTATION,
            description="Genera documentacion tecnica con API reference, arquitectura y ejemplos",
        )

    async def execute(self, inputs: dict[str, Any], context: dict[str, Any]) -> dict[str, Any]:
        """Genera documentacion tecnica."""
        architecture = inputs.get("architecture", {})
        source_files = inputs.get("files", [])
        project_name = inputs.get("project_name", "project")

        if not self.has_llm:
            return self._stub_response(project_name)

        project_context = json.dumps({
            "project_name": project_name,
            "architecture": {k: v for k, v in architecture.items() if k in ("style", "layers", "patterns")} if isinstance(architecture, dict) else architecture,
            "source_files": [f.get("path", "") for f in source_files[:10]],
        }, indent=2, default=str)

        result = await llm_json_call(
            client=self.llm,
            system_prompt=_SYSTEM_PROMPT,
            user_prompt=f"Generate documentation for:\n{project_context}",
            temperature=0.4,
            max_tokens=8192,
        )

        doc_files = result.get("files", [])
        return {
            "status": "completed",
            "project_name": project_name,
            "files": doc_files,
            "total_sections": len(doc_files),
        }

    @staticmethod
    def _stub_response(project_name: str) -> dict[str, Any]:
        return {
            "status": "completed", "project_name": project_name,
            "files": [
                {"path": "docs/README.md", "content": f"# {project_name}\n\nProject documentation.\n"},
                {"path": "docs/architecture.md", "content": "# Architecture\n\nHexagonal architecture.\n"},
            ],
            "total_sections": 2,
        }
