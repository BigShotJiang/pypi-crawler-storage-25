"""Skill: generate user manual."""

from __future__ import annotations

from typing import Any

from ....domain.value_objects.agent_skill import SkillCategory
from ...base.skill import BaseSkill


class GenerateManualSkill(BaseSkill):
    """Genera manual de usuario con instrucciones paso a paso."""

    def __init__(self) -> None:
        super().__init__(
            name="generate_manual",
            category=SkillCategory.DOCUMENTATION,
            description="Genera manual de usuario con capturas, pasos y troubleshooting",
        )

    async def execute(self, inputs: dict[str, Any], context: dict[str, Any]) -> dict[str, Any]:
        """Genera manual de usuario.

        Args:
            inputs: Debe contener ``features`` (list[str]) y ``audience`` (str).
            context: Contexto de ejecucion.

        Returns:
            Manual generado con capitulos y secciones.
        """
        features: list[str] = inputs.get("features", ["instalacion", "configuracion", "uso"])
        audience: str = inputs.get("audience", "desarrollador")
        language: str = inputs.get("language", "es")

        chapters: list[dict[str, Any]] = []
        for i, feature in enumerate(features, start=1):
            chapters.append({
                "number": i,
                "title": feature.title(),
                "sections": [
                    {"title": "Descripcion", "content": f"Descripcion de {feature}."},
                    {"title": "Prerequisitos", "content": f"Prerequisitos para {feature}."},
                    {
                        "title": "Pasos",
                        "content": f"1. Abrir la aplicacion\n2. Navegar a {feature}\n3. Seguir las instrucciones",
                    },
                    {"title": "Troubleshooting", "content": f"Problemas comunes con {feature}."},
                ],
            })

        return {
            "status": "completed",
            "audience": audience,
            "language": language,
            "chapters": chapters,
            "total_chapters": len(chapters),
            "estimated_pages": len(chapters) * 4,
            "files_generated": [
                {"path": "docs/manual/index.md", "type": "table_of_contents"},
                *[
                    {"path": f"docs/manual/ch{c['number']:02d}_{features[c['number']-1]}.md", "type": "chapter"}
                    for c in chapters
                ],
            ],
        }
