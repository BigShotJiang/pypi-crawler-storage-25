"""Skill: generate video tutorial script."""

from __future__ import annotations

from typing import Any

from ....domain.value_objects.agent_skill import SkillCategory
from ...base.skill import BaseSkill


class GenerateVideoScriptSkill(BaseSkill):
    """Genera guion de video tutorial para funcionalidades del proyecto."""

    def __init__(self) -> None:
        super().__init__(
            name="generate_video_script",
            category=SkillCategory.DOCUMENTATION,
            description="Genera guion de video con escenas, narracion y acciones en pantalla",
        )

    async def execute(self, inputs: dict[str, Any], context: dict[str, Any]) -> dict[str, Any]:
        """Genera guion de video tutorial.

        Args:
            inputs: Debe contener ``topic`` (str) y ``duration_minutes`` (int).
            context: Contexto de ejecucion.

        Returns:
            Guion con escenas, tiempos y narracion.
        """
        topic: str = inputs.get("topic", "Introduccion a Kore Platform")
        duration_minutes: int = inputs.get("duration_minutes", 5)
        target_audience: str = inputs.get("target_audience", "desarrolladores")

        scenes: list[dict[str, Any]] = [
            {
                "number": 1,
                "title": "Introduccion",
                "duration_seconds": 30,
                "narration": f"Bienvenidos a este tutorial sobre {topic}.",
                "screen_action": "Mostrar pantalla de inicio de la plataforma",
            },
            {
                "number": 2,
                "title": "Configuracion",
                "duration_seconds": 60,
                "narration": "Primero vamos a configurar el entorno de desarrollo.",
                "screen_action": "Mostrar terminal con comandos de instalacion",
            },
            {
                "number": 3,
                "title": "Demostracion",
                "duration_seconds": duration_minutes * 30,
                "narration": f"Ahora veamos como funciona {topic} en la practica.",
                "screen_action": "Demostracion en vivo del flujo principal",
            },
            {
                "number": 4,
                "title": "Resumen y proximos pasos",
                "duration_seconds": 30,
                "narration": "En resumen, hemos visto las funcionalidades principales. Visiten la documentacion para mas detalles.",
                "screen_action": "Mostrar links a documentacion y repositorio",
            },
        ]

        total_seconds = sum(s["duration_seconds"] for s in scenes)

        return {
            "status": "completed",
            "topic": topic,
            "target_audience": target_audience,
            "scenes": scenes,
            "total_scenes": len(scenes),
            "total_duration_seconds": total_seconds,
            "estimated_duration_minutes": round(total_seconds / 60, 1),
            "files_generated": [
                {"path": f"docs/videos/{topic.lower().replace(' ', '_')}_script.md", "type": "script"},
            ],
        }
