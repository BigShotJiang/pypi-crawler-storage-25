"""Skill: deploy to staging environment — generates Dockerfile + docker-compose."""

from __future__ import annotations

import json
from typing import Any

from ....domain.value_objects.agent_skill import SkillCategory
from ...base.skill import BaseSkill
from ...base.llm_utils import llm_json_call


_SYSTEM_PROMPT = """\
You are a DevOps engineer. Generate Docker deployment files for the given project.

Respond ONLY with JSON:
{
  "files": [
    {
      "path": "Dockerfile",
      "content": "complete Dockerfile content"
    },
    {
      "path": "docker-compose.yaml",
      "content": "complete docker-compose content"
    },
    {
      "path": ".dockerignore",
      "content": "dockerignore content"
    }
  ],
  "deployment": {
    "strategy": "rolling",
    "replicas": 2,
    "health_check": {"endpoint": "/health", "interval": "30s"}
  }
}

Rules:
- Use multi-stage builds for smaller images
- Use non-root user
- Include health checks
- Pin base image versions
- docker-compose should include app + database services
"""


class DeployStagingSkill(BaseSkill):
    """Despliega artefactos al entorno de staging."""

    def __init__(self) -> None:
        super().__init__(
            name="deploy_staging",
            category=SkillCategory.DEPLOYMENT,
            description="Genera Dockerfile y docker-compose para staging deployment",
            requires_sandbox=True,
            max_execution_seconds=600,
        )

    async def execute(self, inputs: dict[str, Any], context: dict[str, Any]) -> dict[str, Any]:
        """Genera archivos de deployment."""
        architecture = inputs.get("architecture", {})
        files = inputs.get("files", [])

        if not self.has_llm:
            return self._stub_response(inputs)

        project_context = json.dumps({
            "architecture": architecture,
            "source_files": [f.get("path", "") for f in files[:20]],
        }, indent=2, default=str)

        result = await llm_json_call(
            client=self.llm,
            system_prompt=_SYSTEM_PROMPT,
            user_prompt=f"Generate deployment files for:\n{project_context}",
            temperature=0.2,
            max_tokens=4096,
        )

        deploy_files = result.get("files", [])
        return {
            "status": "completed",
            "environment": "staging",
            "files": deploy_files,
            "deployment": result.get("deployment", {"strategy": "rolling", "replicas": 2}),
            "rollback_available": True,
        }

    @staticmethod
    def _stub_response(inputs: dict[str, Any]) -> dict[str, Any]:
        artifact = inputs.get("artifact", "kore-platform")
        return {
            "status": "completed", "environment": "staging", "artifact": artifact,
            "files": [
                {"path": "Dockerfile", "content": "FROM python:3.12-slim\nWORKDIR /app\nCOPY . .\nCMD [\"python\", \"-m\", \"uvicorn\", \"src.main:app\"]\n"},
                {"path": "docker-compose.yaml", "content": "version: '3.8'\nservices:\n  app:\n    build: .\n    ports:\n      - '8000:8000'\n"},
            ],
            "deployment": {"strategy": "rolling", "replicas": 2},
            "rollback_available": True,
        }
