"""DeployerAgent -- despliega a staging, produccion y gestiona rollbacks."""

from __future__ import annotations

from typing import Any

from ...application.ports.outbound.message_bus import MessageBusPort
from ...infrastructure.security.guardian import Guardian
from ..base.agent import BaseAgent
from .skills.deploy_staging import DeployStagingSkill
from .skills.deploy_production import DeployProductionSkill
from .skills.rollback import RollbackSkill


class DeployerAgent(BaseAgent):
    """Agente de Despliegue.

    Responsable de desplegar artefactos a staging y produccion,
    y de ejecutar rollbacks en caso de fallos.
    """

    def __init__(
        self,
        bus: MessageBusPort | None = None,
        guardian: Guardian | None = None,
        llm_client: "LLMClientPort | None" = None,
    ) -> None:
        super().__init__(
            name="deployer",
            role="Ingeniero DevOps",
            bus=bus,
            guardian=guardian,
            llm_client=llm_client,
        )
        self.register_skill(DeployStagingSkill())
        self.register_skill(DeployProductionSkill())
        self.register_skill(RollbackSkill())

    async def handle_message(self, message: dict[str, Any]) -> dict[str, Any]:
        """Interpreta mensajes dirigidos al agente de despliegue."""
        action = message.get("action", "deploy_staging")
        inputs = message.get("inputs", {})
        context = message.get("context", {})
        return await self.execute(action, inputs, context)
