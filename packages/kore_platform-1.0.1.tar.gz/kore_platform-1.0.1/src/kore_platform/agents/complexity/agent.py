"""ComplexityAgent — structural complexity analyzer using graph algebra.

Analyses the dependency graph of generated code WITHOUT using an LLM.
Everything is deterministic, CPU-only, based on qubit-algebra (Qal).
"""

from __future__ import annotations

from typing import Any

from ...application.ports.outbound.message_bus import MessageBusPort
from ...infrastructure.security.guardian import Guardian
from ..base.agent import BaseAgent
from .skills.analyze_structure import AnalyzeStructureSkill
from .skills.detect_bottlenecks import DetectBottlenecksSkill


class ComplexityAgent(BaseAgent):
    """Agente de analisis de complejidad estructural.

    Diferencia clave: NO usa LLM. Todo es analisis determinista de grafos.
    Se ejecuta en paralelo con Reviewer y Security (parallel_group="review").
    Solo se incluye en planes DEV_SENIOR y ENGINEER.
    """

    def __init__(
        self,
        bus: MessageBusPort | None = None,
        guardian: Guardian | None = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(
            name="complexity",
            role="Structural complexity analyzer",
            bus=bus,
            guardian=guardian,
            llm_client=None,  # Never uses LLM
        )
        self.register_skill(AnalyzeStructureSkill())
        self.register_skill(DetectBottlenecksSkill())

    async def handle_message(self, message: dict[str, Any]) -> dict[str, Any]:
        action = message.get("action", "analyze_structure")
        inputs = message.get("inputs", {})
        context = message.get("context", {})
        return await self.execute(action, inputs, context)
