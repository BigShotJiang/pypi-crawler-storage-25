"""Skill: detect architectural bottlenecks using pigeonhole analysis."""

from __future__ import annotations

import logging
from typing import Any

from ....domain.value_objects.agent_skill import SkillCategory
from ...base.skill import BaseSkill
from .analyze_structure import extract_internal_imports

logger = logging.getLogger(__name__)


class DetectBottlenecksSkill(BaseSkill):
    """Detecta cuellos de botella arquitectonicos en el codigo generado.

    Usa pigeonhole_analysis() de Qal para detectar nodos sobrecargados
    y cruza con la arquitectura del ArchitectAgent para distinguir
    bottlenecks esperados (core/shared modules) de inesperados.
    """

    def __init__(self) -> None:
        super().__init__(
            name="detect_bottlenecks",
            category=SkillCategory.ANALYSIS,
            description="Detect architectural bottlenecks via pigeonhole analysis",
            requires_sandbox=False,
            max_execution_seconds=30,
        )

    async def execute(
        self,
        inputs: dict[str, Any],
        context: dict[str, Any],
    ) -> dict[str, Any]:
        files = inputs.get("files", {})
        architecture = inputs.get("architecture", {})

        if not files:
            return {
                "status": "completed",
                "type": "bottleneck_report",
                "bottlenecks": [],
                "total_bottlenecks": 0,
                "unexpected_bottlenecks": 0,
            }

        file_map = self._normalize_files(files)
        nodes, edges = extract_internal_imports(file_map)

        if len(nodes) <= 1:
            return {
                "status": "completed",
                "type": "bottleneck_report",
                "bottlenecks": [],
                "total_bottlenecks": 0,
                "unexpected_bottlenecks": 0,
            }

        # Extract expected core modules from architecture
        expected_cores = self._extract_expected_cores(architecture)

        # Try Qal pigeonhole_analysis, fallback to basic in-degree analysis
        try:
            from qal import GraphAlgebra

            ga = GraphAlgebra(nodes)
            ga.add_edges(edges)
            ph = ga.pigeonhole_analysis()
            raw_bottlenecks = ph.get("bottlenecks", [])
        except ImportError:
            logger.warning("qubit-algebra not installed — using fallback bottleneck detection")
            raw_bottlenecks = self._fallback_bottlenecks(nodes, edges)

        # Enrich with is_expected and recommendations
        bottlenecks: list[dict[str, Any]] = []
        for b in raw_bottlenecks:
            module = b.get("node", "")
            in_deg = b.get("in_degree", 0)
            overload = b.get("overload", 0.0)
            is_expected = module.lower() in expected_cores

            if is_expected:
                rec = f"Expected bottleneck ({module} layer). Consider connection pooling or caching."
            else:
                rec = "Unexpected bottleneck. Consider splitting into focused modules."

            bottlenecks.append({
                "module": module,
                "in_degree": in_deg,
                "overload_factor": overload,
                "is_expected": is_expected,
                "recommendation": rec,
            })

        unexpected = sum(1 for b in bottlenecks if not b["is_expected"])

        return {
            "status": "completed",
            "type": "bottleneck_report",
            "bottlenecks": bottlenecks,
            "total_bottlenecks": len(bottlenecks),
            "unexpected_bottlenecks": unexpected,
        }

    @staticmethod
    def _extract_expected_cores(architecture: dict[str, Any]) -> set[str]:
        """Extract module names that are expected to be highly depended upon."""
        cores: set[str] = set()
        # Common names that are expected bottlenecks
        cores.update({"db", "database", "config", "settings", "models", "base", "core", "common", "shared", "utils"})

        # From architecture components marked as "core" or "shared"
        arch = architecture.get("architecture", architecture)
        for comp in arch.get("components", []):
            if isinstance(comp, dict):
                name = comp.get("name", "").lower().replace(" ", "_")
                comp_type = comp.get("type", "").lower()
                if comp_type in ("core", "shared", "infrastructure", "database"):
                    cores.add(name)
                # Also add all component names — architecture-declared modules
                # are by definition "expected"
                if name:
                    cores.add(name)

        return cores

    @staticmethod
    def _fallback_bottlenecks(
        nodes: list[str],
        edges: list[tuple[str, str]],
    ) -> list[dict[str, Any]]:
        """Basic bottleneck detection without Qal."""
        in_deg: dict[str, int] = {n: 0 for n in nodes}
        for _, tgt in edges:
            if tgt in in_deg:
                in_deg[tgt] += 1

        total = len(edges)
        avg = total / len(nodes) if nodes else 0
        bottlenecks: list[dict[str, Any]] = []

        for mod, deg in in_deg.items():
            if avg > 0 and deg > avg * 1.5:
                bottlenecks.append({
                    "node": mod,
                    "in_degree": deg,
                    "out_degree": 0,
                    "overload": round(deg / avg, 2) if avg > 0 else 0,
                })

        return bottlenecks

    @staticmethod
    def _normalize_files(files: Any) -> dict[str, str]:
        if isinstance(files, dict):
            return files
        if isinstance(files, list):
            result: dict[str, str] = {}
            for f in files:
                if isinstance(f, dict) and "path" in f and "content" in f:
                    result[f["path"]] = f["content"]
            return result
        return {}
