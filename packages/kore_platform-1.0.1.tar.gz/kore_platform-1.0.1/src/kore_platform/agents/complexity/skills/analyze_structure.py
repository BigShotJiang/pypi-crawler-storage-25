"""Skill: analyze structural complexity of generated code via graph algebra."""

from __future__ import annotations

import ast
import logging
import os
from typing import Any

from ....domain.value_objects.agent_skill import SkillCategory
from ...base.skill import BaseSkill

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Default rating thresholds — configurable via constructor
# ---------------------------------------------------------------------------

DEFAULT_THRESHOLDS: dict[str, dict[str, Any]] = {
    "A": {"max_entanglement": 0.2, "max_cycles": 0, "max_depth": 4},
    "B": {"max_entanglement": 0.4, "max_cycles": 0},
    "C": {"max_entanglement": 0.6, "max_cycles": 1},
    "D": {"max_entanglement": 0.8, "max_cycles": 3},
    # F: everything else
}


def extract_internal_imports(
    files: dict[str, str],
) -> tuple[list[str], list[tuple[str, str]]]:
    """Parse Python files with ast and extract internal dependency edges.

    Parameters
    ----------
    files:
        Mapping of ``filename -> source_code``.

    Returns
    -------
    tuple[list[str], list[tuple[str, str]]]
        (node_names, edges) where edges are (importer, imported).
    """
    # Build set of known module names (file stems without .py)
    known_modules: dict[str, str] = {}
    for fname in files:
        stem = _file_to_module(fname)
        if stem:
            known_modules[stem] = fname

    nodes = sorted(known_modules.keys())
    edges: list[tuple[str, str]] = []

    for fname, source in files.items():
        importer = _file_to_module(fname)
        if not importer:
            continue

        try:
            tree = ast.parse(source, filename=fname)
        except SyntaxError:
            logger.debug("ast_parse_failed file=%s (skipped)", fname)
            continue

        for node in ast.walk(tree):
            imported_names: list[str] = []

            if isinstance(node, ast.Import):
                for alias in node.names:
                    imported_names.append(alias.name.split(".")[0])

            elif isinstance(node, ast.ImportFrom):
                if node.module:
                    # Relative imports: level > 0 means "from . import X"
                    base = node.module.split(".")[0]
                    imported_names.append(base)

            for imp in imported_names:
                if imp in known_modules and imp != importer:
                    edge = (importer, imp)
                    if edge not in edges:
                        edges.append(edge)

    return nodes, edges


def _file_to_module(fname: str) -> str:
    """Convert a file path to a module name (stem of the basename)."""
    base = os.path.basename(fname)
    if base.endswith(".py") and base != "__init__.py":
        return base[:-3]
    return ""


def calculate_metrics(
    nodes: list[str],
    edges: list[tuple[str, str]],
) -> dict[str, Any]:
    """Calculate structural complexity metrics using Qal GraphAlgebra.

    Returns zeroed metrics for trivial graphs (0 or 1 node).
    Falls back to basic metrics if qubit-algebra is not installed.
    """
    if len(nodes) <= 1:
        return {
            "module_count": len(nodes),
            "dependency_count": len(edges),
            "cyclomatic_complexity": 0,
            "entanglement": 0.0,
            "max_depth": 0,
            "cycle_count": 0,
            "has_circular_dependencies": False,
        }

    try:
        from qal import GraphAlgebra
    except ImportError:
        logger.warning("qubit-algebra not installed — using fallback metrics")
        return _fallback_metrics(nodes, edges)

    ga = GraphAlgebra(nodes)
    ga.add_edges(edges)

    complexity = ga.structural_complexity()

    return {
        "module_count": len(nodes),
        "dependency_count": len(edges),
        "cyclomatic_complexity": complexity["cyclomatic"],
        "entanglement": complexity["entanglement"],
        "max_depth": complexity["depth"],
        "cycle_count": complexity["cycles"],
        "has_circular_dependencies": complexity["cycles"] > 0,
    }


def _fallback_metrics(
    nodes: list[str],
    edges: list[tuple[str, str]],
) -> dict[str, Any]:
    """Basic metrics without Qal — counts only."""
    # Simple cycle detection via DFS
    adj: dict[str, list[str]] = {n: [] for n in nodes}
    for src, tgt in edges:
        adj[src].append(tgt)

    WHITE, GRAY, BLACK = 0, 1, 2
    color = {n: WHITE for n in nodes}
    cycles = 0

    def dfs(u: str) -> None:
        nonlocal cycles
        color[u] = GRAY
        for v in adj[u]:
            if v in color:
                if color[v] == GRAY:
                    cycles += 1
                elif color[v] == WHITE:
                    dfs(v)
        color[u] = BLACK

    for n in nodes:
        if color[n] == WHITE:
            dfs(n)

    return {
        "module_count": len(nodes),
        "dependency_count": len(edges),
        "cyclomatic_complexity": len(edges) - len(nodes) + 2,
        "entanglement": 0.0,  # Cannot compute without Qal
        "max_depth": 0,
        "cycle_count": cycles,
        "has_circular_dependencies": cycles > 0,
    }


def compute_rating(
    metrics: dict[str, Any],
    thresholds: dict[str, dict[str, Any]] | None = None,
) -> str:
    """Compute A/B/C/D/F rating from metrics and configurable thresholds."""
    t = thresholds or DEFAULT_THRESHOLDS
    ent = metrics.get("entanglement", 0.0)
    cyc = metrics.get("cycle_count", 0)
    depth = metrics.get("max_depth", 0)

    a = t.get("A", {})
    if ent < a.get("max_entanglement", 0.2) and cyc <= a.get("max_cycles", 0) and depth <= a.get("max_depth", 4):
        return "A"

    b = t.get("B", {})
    if ent < b.get("max_entanglement", 0.4) and cyc <= b.get("max_cycles", 0):
        return "B"

    c = t.get("C", {})
    if ent < c.get("max_entanglement", 0.6) or cyc <= c.get("max_cycles", 1):
        return "C"

    d = t.get("D", {})
    if ent < d.get("max_entanglement", 0.8) or cyc <= d.get("max_cycles", 3):
        return "D"

    return "F"


def generate_warnings(
    metrics: dict[str, Any],
    nodes: list[str],
    edges: list[tuple[str, str]],
) -> list[str]:
    """Generate human-readable warnings from metrics."""
    warnings: list[str] = []

    if metrics.get("has_circular_dependencies"):
        # Find which nodes participate in cycles (simple heuristic)
        adj: dict[str, list[str]] = {n: [] for n in nodes}
        for src, tgt in edges:
            adj[src].append(tgt)

        for src, tgt in edges:
            if src in adj.get(tgt, []):
                warnings.append(
                    f"Circular dependency detected: {src} <-> {tgt}"
                )

    ent = metrics.get("entanglement", 0.0)
    if ent > 0.6:
        warnings.append(
            f"High entanglement ({ent:.2f}): modules are tightly coupled"
        )

    # Detect high fan-in nodes
    in_degree: dict[str, int] = {n: 0 for n in nodes}
    for _, tgt in edges:
        if tgt in in_degree:
            in_degree[tgt] += 1

    for mod, deg in in_degree.items():
        if deg >= 4:
            warnings.append(
                f"Module '{mod}' has {deg} dependents — potential bottleneck"
            )

    return warnings


class AnalyzeStructureSkill(BaseSkill):
    """Analiza la complejidad estructural del codigo generado."""

    def __init__(
        self,
        thresholds: dict[str, dict[str, Any]] | None = None,
    ) -> None:
        super().__init__(
            name="analyze_structure",
            category=SkillCategory.ANALYSIS,
            description="Analyze structural complexity using graph algebra",
            requires_sandbox=False,
            max_execution_seconds=30,
        )
        self._thresholds = thresholds or DEFAULT_THRESHOLDS

    async def execute(
        self,
        inputs: dict[str, Any],
        context: dict[str, Any],
    ) -> dict[str, Any]:
        files = inputs.get("files", {})

        if not files:
            return {
                "status": "completed",
                "type": "complexity_report",
                "metrics": calculate_metrics([], []),
                "warnings": [],
                "graph": {"nodes": [], "edges": []},
                "rating": "A",
            }

        # Normalize files: accept list-of-dicts or dict
        file_map = self._normalize_files(files)

        nodes, edges = extract_internal_imports(file_map)
        metrics = calculate_metrics(nodes, edges)
        rating = compute_rating(metrics, self._thresholds)
        warnings = generate_warnings(metrics, nodes, edges)

        return {
            "status": "completed",
            "type": "complexity_report",
            "metrics": metrics,
            "warnings": warnings,
            "graph": {
                "nodes": nodes,
                "edges": [[src, tgt] for src, tgt in edges],
            },
            "rating": rating,
        }

    @staticmethod
    def _normalize_files(files: Any) -> dict[str, str]:
        """Accept both dict[str,str] and list[{path, content}] formats."""
        if isinstance(files, dict):
            return files
        if isinstance(files, list):
            result: dict[str, str] = {}
            for f in files:
                if isinstance(f, dict) and "path" in f and "content" in f:
                    result[f["path"]] = f["content"]
            return result
        return {}
