"""ComplexityAgent — structural complexity analyzer using graph algebra."""
