"""MonitorAgent -- configura monitoreo, analiza metricas y gestiona alertas."""

from __future__ import annotations

from typing import Any

from ...application.ports.outbound.message_bus import MessageBusPort
from ...infrastructure.security.guardian import Guardian
from ..base.agent import BaseAgent
from .skills.setup_monitoring import SetupMonitoringSkill
from .skills.analyze_metrics import AnalyzeMetricsSkill
from .skills.create_alerts import CreateAlertsSkill


class MonitorAgent(BaseAgent):
    """Agente de Monitoreo.

    Responsable de configurar la observabilidad del sistema,
    analizar metricas en tiempo real y gestionar alertas.
    """

    def __init__(
        self,
        bus: MessageBusPort | None = None,
        guardian: Guardian | None = None,
        llm_client: "LLMClientPort | None" = None,
    ) -> None:
        super().__init__(
            name="monitor",
            role="Ingeniero de Observabilidad",
            bus=bus,
            guardian=guardian,
            llm_client=llm_client,
        )
        self.register_skill(SetupMonitoringSkill())
        self.register_skill(AnalyzeMetricsSkill())
        self.register_skill(CreateAlertsSkill())

    async def handle_message(self, message: dict[str, Any]) -> dict[str, Any]:
        """Interpreta mensajes dirigidos al agente de monitoreo."""
        action = message.get("action", "setup_monitoring")
        inputs = message.get("inputs", {})
        context = message.get("context", {})
        return await self.execute(action, inputs, context)
