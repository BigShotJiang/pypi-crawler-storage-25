"""Skill: create monitoring alerts and notification rules."""

from __future__ import annotations

from typing import Any

from ....domain.value_objects.agent_skill import SkillCategory
from ...base.skill import BaseSkill


class CreateAlertsSkill(BaseSkill):
    """Crea reglas de alerta y configuracion de notificaciones."""

    def __init__(self) -> None:
        super().__init__(
            name="create_alerts",
            category=SkillCategory.MONITORING,
            description="Crea alertas para SLOs, errores, latencia y saturacion de recursos",
        )

    async def execute(self, inputs: dict[str, Any], context: dict[str, Any]) -> dict[str, Any]:
        """Crea reglas de alerta.

        Args:
            inputs: Debe contener ``services`` (list[str]) y ``slo_targets`` (dict).
            context: Contexto de ejecucion.

        Returns:
            Reglas de alerta creadas con canales de notificacion.
        """
        services: list[str] = inputs.get("services", ["api", "agents"])
        slo_targets: dict[str, float] = inputs.get("slo_targets", {
            "availability": 99.9,
            "latency_p99_ms": 300,
            "error_rate_percent": 0.5,
        })

        alerts: list[dict[str, Any]] = [
            {
                "name": "high_error_rate",
                "severity": "critical",
                "condition": f"error_rate > {slo_targets.get('error_rate_percent', 0.5)}%",
                "duration": "5m",
                "channels": ["slack-critical", "pagerduty"],
                "description": "Tasa de errores supera el SLO definido",
            },
            {
                "name": "high_latency",
                "severity": "warning",
                "condition": f"p99_latency > {slo_targets.get('latency_p99_ms', 300)}ms",
                "duration": "10m",
                "channels": ["slack-warnings"],
                "description": "Latencia p99 supera el objetivo",
            },
            {
                "name": "availability_degraded",
                "severity": "critical",
                "condition": f"availability < {slo_targets.get('availability', 99.9)}%",
                "duration": "1m",
                "channels": ["slack-critical", "pagerduty", "email-oncall"],
                "description": "Disponibilidad por debajo del SLO",
            },
            {
                "name": "resource_saturation",
                "severity": "warning",
                "condition": "cpu_usage > 80% OR memory_usage > 85%",
                "duration": "15m",
                "channels": ["slack-warnings"],
                "description": "Saturacion de recursos cercana al limite",
            },
        ]

        return {
            "status": "completed",
            "services_covered": services,
            "slo_targets": slo_targets,
            "alerts": alerts,
            "total_alerts": len(alerts),
            "notification_channels": {
                "slack-critical": {"type": "slack", "channel": "#kore-critical"},
                "slack-warnings": {"type": "slack", "channel": "#kore-warnings"},
                "pagerduty": {"type": "pagerduty", "service": "kore-platform"},
                "email-oncall": {"type": "email", "address": "oncall@kore.dev"},
            },
            "files_generated": [
                {"path": "monitoring/alerts/rules.yml", "type": "prometheus_rules"},
                {"path": "monitoring/alerts/notification_channels.yml", "type": "config"},
            ],
        }
