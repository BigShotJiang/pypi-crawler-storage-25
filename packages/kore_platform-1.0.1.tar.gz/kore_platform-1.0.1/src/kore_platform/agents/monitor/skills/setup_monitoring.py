"""Skill: setup monitoring infrastructure."""

from __future__ import annotations

import json
from typing import Any

from ....domain.value_objects.agent_skill import SkillCategory
from ...base.skill import BaseSkill
from ...base.llm_utils import llm_json_call


_SYSTEM_PROMPT = """\
You are a DevOps/SRE engineer. Generate monitoring configuration for the project.

Respond ONLY with JSON:
{
  "files": [
    {
      "path": "monitoring/prometheus.yml",
      "content": "prometheus config content"
    },
    {
      "path": "monitoring/docker-compose.monitoring.yml",
      "content": "docker-compose for monitoring stack"
    }
  ],
  "components": {
    "metrics": {"tool": "Prometheus", "retention": "30d"},
    "logging": {"tool": "structured logging", "format": "JSON"},
    "health_checks": [{"endpoint": "/health", "interval": "30s"}]
  }
}
"""


class SetupMonitoringSkill(BaseSkill):
    """Configura la infraestructura de monitoreo y observabilidad."""

    def __init__(self) -> None:
        super().__init__(
            name="setup_monitoring",
            category=SkillCategory.MONITORING,
            description="Configura Prometheus, logging y health checks",
            requires_sandbox=True,
        )

    async def execute(self, inputs: dict[str, Any], context: dict[str, Any]) -> dict[str, Any]:
        """Configura monitoreo."""
        architecture = inputs.get("architecture", {})

        if not self.has_llm:
            return self._stub_response()

        result = await llm_json_call(
            client=self.llm,
            system_prompt=_SYSTEM_PROMPT,
            user_prompt=f"Generate monitoring config for:\n{json.dumps(architecture, indent=2, default=str)}",
            temperature=0.3,
            max_tokens=4096,
        )

        return {
            "status": "completed",
            "files": result.get("files", []),
            "components": result.get("components", {}),
        }

    @staticmethod
    def _stub_response() -> dict[str, Any]:
        return {
            "status": "completed",
            "files": [
                {"path": "monitoring/prometheus.yml", "content": "global:\n  scrape_interval: 15s\n"},
            ],
            "components": {
                "metrics": {"tool": "Prometheus", "retention": "30d"},
                "logging": {"tool": "structured logging", "format": "JSON"},
            },
        }
