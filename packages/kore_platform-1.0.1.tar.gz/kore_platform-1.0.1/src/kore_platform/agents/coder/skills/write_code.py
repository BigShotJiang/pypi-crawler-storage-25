"""Skill: write code from specifications."""

from __future__ import annotations

from typing import Any

from ....domain.value_objects.agent_skill import SkillCategory
from ...base.skill import BaseSkill


class WriteCodeSkill(BaseSkill):
    """Genera codigo fuente a partir de especificaciones."""

    def __init__(self) -> None:
        super().__init__(
            name="write_code",
            category=SkillCategory.CODING,
            description="Genera codigo Python siguiendo las especificaciones proporcionadas",
            requires_sandbox=True,
        )

    async def execute(self, inputs: dict[str, Any], context: dict[str, Any]) -> dict[str, Any]:
        """Genera codigo fuente.

        Args:
            inputs: Debe contener ``spec`` (dict) con la especificacion del modulo.
            context: Contexto de ejecucion con informacion del sandbox.

        Returns:
            Codigo generado con archivos y metadata.
        """
        spec: dict[str, Any] = inputs.get("spec", {})
        language: str = inputs.get("language", "python")
        module_name: str = spec.get("module_name", "module")

        # Stub: genera codigo mock
        code = (
            f'"""Modulo {module_name} -- generado automaticamente."""\n\n'
            f"from __future__ import annotations\n\n"
            f"from dataclasses import dataclass\n"
            f"from typing import Any\n\n\n"
            f"@dataclass(frozen=True, slots=True)\n"
            f"class {module_name.title().replace('_', '')}:\n"
            f'    """Clase principal del modulo {module_name}."""\n\n'
            f"    name: str\n"
            f'    status: str = "active"\n\n'
            f"    def process(self, data: dict[str, Any]) -> dict[str, Any]:\n"
            f'        """Procesa datos de entrada."""\n'
            f'        return {{"processed": True, "module": self.name, "data": data}}\n'
        )

        return {
            "status": "completed",
            "language": language,
            "files": [
                {
                    "path": f"{module_name}.py",
                    "content": code,
                    "lines": code.count("\n") + 1,
                },
            ],
            "total_files": 1,
            "total_lines": code.count("\n") + 1,
        }
