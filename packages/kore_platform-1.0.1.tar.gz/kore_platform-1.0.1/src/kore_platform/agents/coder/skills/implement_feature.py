"""Skill: implement a complete feature from architecture + schemas."""

from __future__ import annotations

import json
from typing import Any

from ....domain.value_objects.agent_skill import SkillCategory
from ...base.skill import BaseSkill
from ...base.llm_utils import llm_json_call
from ...base.few_shot import build_few_shot_prompt


_BASE_SYSTEM_PROMPT = """\
You are a senior Python developer. Given architecture and schema definitions, implement the complete project code.

Generate ALL files needed for a working project. Respond ONLY with JSON:
{
  "files": [
    {
      "path": "src/main.py",
      "content": "full python code as string",
      "type": "entrypoint|module|config|model|schema|route|service|repository|test"
    }
  ]
}

Rules:
- Generate complete, runnable Python code (not pseudocode)
- Use FastAPI for routes, Pydantic for schemas, SQLAlchemy for models where applicable
- Include proper imports, type hints, and docstrings
- Include pyproject.toml with dependencies
- Include database.py for DB connection setup
- Each file must be complete and self-contained (no "# ... rest of code" placeholders)
- Use async/await for all I/O operations
"""

_MANIFEST_PROMPT = """\
You are a senior Python developer. Given architecture and schemas, plan the file manifest for the project.

Respond ONLY with JSON:
{
  "files": [
    {"path": "src/main.py", "description": "FastAPI app entrypoint", "type": "entrypoint"},
    {"path": "src/models.py", "description": "SQLAlchemy models", "type": "model"}
  ]
}

List ALL files that need to be generated for a complete working project.
"""


class ImplementFeatureSkill(BaseSkill):
    """Implementa una feature completa a partir de arquitectura y schemas."""

    def __init__(self) -> None:
        super().__init__(
            name="implement_feature",
            category=SkillCategory.CODING,
            description="Implementa feature completa: modulos, tests y configuracion",
            requires_sandbox=True,
            max_execution_seconds=600,
        )

    async def execute(self, inputs: dict[str, Any], context: dict[str, Any]) -> dict[str, Any]:
        """Implementa codigo completo basado en arquitectura."""
        architecture = inputs.get("architecture", {})
        requirements = inputs.get("requirements", {})

        # Soporte para fix_errors: el validation loop pasa errores de tests
        fix_errors = inputs.get("fix_errors")

        if not self.has_llm:
            return self._stub_response(inputs)

        # Construir resumen compacto para no exceder context window
        req_summary = self._compact_requirements(requirements)
        arch_summary = self._compact_architecture(architecture)

        # Seleccion contextual de few-shot: extraer "idea" de requirements
        idea = self._extract_idea(requirements, architecture)
        system_prompt = build_few_shot_prompt(_BASE_SYSTEM_PROMPT, idea=idea)

        user_prompt = (
            f"Requirements:\n{req_summary}\n\n"
            f"Architecture:\n{arch_summary}\n\n"
            "Generate ALL files with complete, working Python code."
        )

        if fix_errors:
            user_prompt += (
                f"\n\nIMPORTANT: The previous code had these test failures:\n"
                f"{fix_errors}\n\n"
                "Fix ALL errors. Make sure imports are correct, all referenced "
                "modules exist, and the code passes tests."
            )

        # Generar todo el codigo en una sola llamada (sin paso de manifest)
        result = await llm_json_call(
            client=self.llm,
            system_prompt=system_prompt,
            user_prompt=user_prompt,
            temperature=0.2,
            max_tokens=16384,
        )

        files = result.get("files", [])
        return {
            "status": "completed",
            "files": files,
            "total_files": len(files),
            "total_lines": sum(f.get("content", "").count("\n") + 1 for f in files),
            "has_tests": any("test" in f.get("path", "") for f in files),
        }

    @staticmethod
    def _extract_idea(requirements: dict[str, Any] | list[Any], architecture: dict[str, Any]) -> str:
        """Extrae texto representativo del proyecto para seleccion contextual de few-shot."""
        parts: list[str] = []
        if isinstance(requirements, dict):
            if name := requirements.get("project_name"):
                parts.append(str(name))
            for fr in requirements.get("functional_requirements", [])[:3]:
                if isinstance(fr, dict):
                    parts.append(fr.get("title", "") or fr.get("description", ""))
            if stack := requirements.get("suggested_stack", {}):
                parts.append(stack.get("framework", ""))
        if isinstance(architecture, dict):
            arch = architecture.get("architecture", architecture)
            parts.append(arch.get("style", ""))
            for comp in arch.get("components", [])[:3]:
                if isinstance(comp, dict):
                    parts.append(comp.get("name", ""))
        return " ".join(p for p in parts if p)

    @staticmethod
    def _compact_requirements(requirements: dict[str, Any] | list[Any]) -> str:
        """Extrae un resumen compacto de requisitos para no exceder context window."""
        if isinstance(requirements, dict):
            frs = requirements.get("functional_requirements", [])
            entities = requirements.get("entities", [])
            stack = requirements.get("suggested_stack", {})
            name = requirements.get("project_name", "project")
            parts = [f"Project: {name}"]
            parts.extend(f"- {fr.get('title', '')}: {fr.get('description', '')}" for fr in frs[:5])
            if entities:
                parts.append("Entities: " + ", ".join(e.get("name", "") for e in entities[:5]))
            if stack:
                parts.append(f"Stack: {stack.get('framework', 'fastapi')}, {stack.get('database', 'postgresql')}")
            return "\n".join(parts)
        return json.dumps(requirements, default=str)[:500]

    @staticmethod
    def _compact_architecture(architecture: dict[str, Any]) -> str:
        """Extrae un resumen compacto de arquitectura."""
        if isinstance(architecture, dict):
            arch = architecture.get("architecture", architecture)
            parts = [f"Style: {arch.get('style', 'layered')}"]
            comps = arch.get("components", [])
            if comps:
                parts.append("Components: " + ", ".join(
                    c.get("name", "") for c in comps[:8] if isinstance(c, dict)
                ))
            patterns = arch.get("patterns", [])
            if patterns:
                parts.append("Patterns: " + ", ".join(str(p) for p in patterns[:3]))
            return "\n".join(parts)
        return json.dumps(architecture, default=str)[:500]

    @staticmethod
    def _stub_response(inputs: dict[str, Any]) -> dict[str, Any]:
        user_story = inputs.get("user_story", {})
        feature_name = user_story.get("title", "nueva_feature").lower().replace(" ", "_")
        files = [
            {"path": f"src/{feature_name}/__init__.py",
             "content": f'"""Feature: {feature_name}."""\n', "type": "module"},
            {"path": f"src/{feature_name}/service.py",
             "content": f'"""Servicio de {feature_name}."""\n\nclass Service:\n    pass\n',
             "type": "service"},
            {"path": f"tests/test_{feature_name}.py",
             "content": f'"""Tests para {feature_name}."""\n\ndef test_placeholder():\n    assert True\n',
             "type": "test"},
        ]
        return {
            "status": "completed", "feature_name": feature_name,
            "files": files, "total_files": len(files),
            "total_lines": sum(f["content"].count("\n") + 1 for f in files), "has_tests": True,
        }
