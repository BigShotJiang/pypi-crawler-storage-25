"""Skill: refactor existing code."""

from __future__ import annotations

from typing import Any

from ....domain.value_objects.agent_skill import SkillCategory
from ...base.skill import BaseSkill


class RefactorSkill(BaseSkill):
    """Refactoriza codigo existente para mejorar calidad y mantenibilidad."""

    def __init__(self) -> None:
        super().__init__(
            name="refactor",
            category=SkillCategory.CODING,
            description="Refactoriza codigo aplicando patrones, eliminando duplicacion y mejorando tipos",
            requires_sandbox=True,
        )

    async def execute(self, inputs: dict[str, Any], context: dict[str, Any]) -> dict[str, Any]:
        """Refactoriza codigo existente.

        Args:
            inputs: Debe contener ``source_code`` (str) y opcionalmente ``strategy``.
            context: Contexto de ejecucion.

        Returns:
            Codigo refactorizado con lista de cambios aplicados.
        """
        source_code: str = inputs.get("source_code", "")
        file_path: str = inputs.get("file_path", "unknown.py")
        strategy: str = inputs.get("strategy", "general")

        # Stub: retorna el codigo original con sugerencias
        changes: list[dict[str, str]] = [
            {
                "type": "type_hints",
                "description": "Anadido type hints faltantes a funciones publicas",
            },
            {
                "type": "docstrings",
                "description": "Anadido docstrings a clases y metodos publicos",
            },
            {
                "type": "immutability",
                "description": "Convertido dataclasses a frozen=True donde es posible",
            },
        ]

        return {
            "status": "completed",
            "file_path": file_path,
            "strategy": strategy,
            "refactored_code": source_code,
            "changes_applied": changes,
            "total_changes": len(changes),
            "original_lines": source_code.count("\n") + 1 if source_code else 0,
        }
