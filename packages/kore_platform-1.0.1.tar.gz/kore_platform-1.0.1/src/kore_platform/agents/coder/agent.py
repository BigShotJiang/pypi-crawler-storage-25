"""CoderAgent -- genera, refactoriza e implementa codigo."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from ...application.ports.outbound.message_bus import MessageBusPort
from ...infrastructure.security.guardian import Guardian
from ..base.agent import BaseAgent
from .skills.write_code import WriteCodeSkill
from .skills.refactor import RefactorSkill
from .skills.implement_feature import ImplementFeatureSkill

if TYPE_CHECKING:
    from ...application.ports.outbound.llm_client import LLMClientPort


class CoderAgent(BaseAgent):
    """Agente Programador.

    Responsable de generar codigo nuevo, refactorizar codigo existente
    e implementar features completas con tests.
    """

    def __init__(
        self,
        bus: MessageBusPort | None = None,
        guardian: Guardian | None = None,
        llm_client: LLMClientPort | None = None,
    ) -> None:
        super().__init__(
            name="coder",
            role="Programador Senior",
            bus=bus,
            guardian=guardian,
            llm_client=llm_client,
        )
        self.register_skill(WriteCodeSkill())
        self.register_skill(RefactorSkill())
        self.register_skill(ImplementFeatureSkill())

    async def handle_message(self, message: dict[str, Any]) -> dict[str, Any]:
        """Interpreta mensajes dirigidos al agente programador."""
        action = message.get("action", "write_code")
        inputs = message.get("inputs", {})
        context = message.get("context", {})
        return await self.execute(action, inputs, context)
