"""SecurityAgent -- escaneo SAST, dependencias y secretos."""

from __future__ import annotations

from typing import Any

from ...application.ports.outbound.message_bus import MessageBusPort
from ...infrastructure.security.guardian import Guardian
from ..base.agent import BaseAgent
from .skills.sast_scan import SastScanSkill
from .skills.dependency_scan import DependencyScanSkill
from .skills.secret_scan import SecretScanSkill


class SecurityAgent(BaseAgent):
    """Agente de Seguridad.

    Responsable de ejecutar analisis estatico de seguridad (SAST),
    escaneo de dependencias vulnerables y deteccion de secretos en codigo.
    """

    def __init__(
        self,
        bus: MessageBusPort | None = None,
        guardian: Guardian | None = None,
        llm_client: "LLMClientPort | None" = None,
    ) -> None:
        super().__init__(
            name="security",
            role="Ingeniero de Seguridad",
            bus=bus,
            guardian=guardian,
            llm_client=llm_client,
        )
        self.register_skill(SastScanSkill())
        self.register_skill(DependencyScanSkill())
        self.register_skill(SecretScanSkill())

    async def handle_message(self, message: dict[str, Any]) -> dict[str, Any]:
        """Interpreta mensajes dirigidos al agente de seguridad."""
        action = message.get("action", "sast_scan")
        inputs = message.get("inputs", {})
        context = message.get("context", {})
        return await self.execute(action, inputs, context)
