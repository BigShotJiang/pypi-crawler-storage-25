"""Skill: static application security testing (SAST) scan."""

from __future__ import annotations

import json
from typing import Any

from ....domain.value_objects.agent_skill import SkillCategory
from ...base.skill import BaseSkill
from ...base.llm_utils import llm_json_call


_SYSTEM_PROMPT = """\
You are a SAST (Static Application Security Testing) tool. Analyze code for security vulnerabilities.

Respond ONLY with JSON:
{
  "vulnerabilities": [
    {
      "id": "SAST-001",
      "severity": "critical|high|medium|low|info",
      "category": "sql_injection|xss|ssrf|path_traversal|command_injection|input_validation|crypto",
      "cwe": "CWE-XXX",
      "title": "short description",
      "file": "path/to/file.py",
      "line": 45,
      "recommendation": "how to fix"
    }
  ],
  "summary": {"critical": 0, "high": 0, "medium": 0, "low": 1, "info": 0},
  "passed": true
}
"""


class SastScanSkill(BaseSkill):
    """Ejecuta analisis estatico de seguridad sobre el codigo fuente."""

    def __init__(self) -> None:
        super().__init__(
            name="sast_scan",
            category=SkillCategory.SECURITY,
            description="Escaneo SAST con deteccion de inyecciones SQL, XSS, y SSRF",
            requires_sandbox=True,
            max_execution_seconds=600,
        )

    async def execute(self, inputs: dict[str, Any], context: dict[str, Any]) -> dict[str, Any]:
        """Ejecuta escaneo SAST."""
        files = inputs.get("files", [])
        project_path: str = inputs.get("project_path", "/workspace")

        if not self.has_llm:
            return self._stub_response(project_path)

        code_summary = json.dumps(
            [{"path": f.get("path", ""), "content": f.get("content", "")[:3000]} for f in files[:8]],
            indent=2,
        )

        result = await llm_json_call(
            client=self.llm,
            system_prompt=_SYSTEM_PROMPT,
            user_prompt=f"Scan these files for security vulnerabilities:\n{code_summary}",
            temperature=0.2,
            max_tokens=4096,
        )

        vulns = result.get("vulnerabilities", [])
        summary = result.get("summary", {})
        return {
            "status": "completed",
            "scan_target": project_path,
            "vulnerabilities": vulns,
            "summary": summary,
            "total_files_scanned": len(files),
            "passed": result.get("passed", not any(v.get("severity") in ("critical", "high") for v in vulns)),
        }

    @staticmethod
    def _stub_response(project_path: str) -> dict[str, Any]:
        return {
            "status": "completed", "scan_target": project_path,
            "vulnerabilities": [{"id": "SAST-001", "severity": "low", "category": "input_validation",
                                 "cwe": "CWE-20", "title": "Input no validado en endpoint",
                                 "file": f"{project_path}/src/api/handlers.py", "line": 45,
                                 "recommendation": "Agregar validacion con pydantic BaseModel"}],
            "summary": {"critical": 0, "high": 0, "medium": 0, "low": 1, "info": 0},
            "total_files_scanned": 47, "passed": True,
        }
