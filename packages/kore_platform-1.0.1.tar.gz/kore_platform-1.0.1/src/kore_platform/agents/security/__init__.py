"""Security agent -- SAST, dependency scanning, and secret detection."""

from .agent import SecurityAgent

__all__ = ["SecurityAgent"]
