"""SpecsAgent -- analiza requisitos y genera historias de usuario."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from ...application.ports.outbound.message_bus import MessageBusPort
from ...infrastructure.security.guardian import Guardian
from ..base.agent import BaseAgent
from .skills.analyze_requirements import AnalyzeRequirementsSkill
from .skills.generate_user_stories import GenerateUserStoriesSkill

if TYPE_CHECKING:
    from ...application.ports.outbound.llm_client import LLMClientPort


class SpecsAgent(BaseAgent):
    """Agente de Especificaciones.

    Responsable de analizar requisitos del usuario y convertirlos
    en historias de usuario estructuradas y criterios de aceptacion.
    """

    def __init__(
        self,
        bus: MessageBusPort | None = None,
        guardian: Guardian | None = None,
        llm_client: LLMClientPort | None = None,
    ) -> None:
        super().__init__(
            name="specs",
            role="Analista de Requisitos",
            bus=bus,
            guardian=guardian,
            llm_client=llm_client,
        )
        self.register_skill(AnalyzeRequirementsSkill())
        self.register_skill(GenerateUserStoriesSkill())

    async def handle_message(self, message: dict[str, Any]) -> dict[str, Any]:
        """Interpreta mensajes dirigidos al agente de specs."""
        action = message.get("action", "analyze_requirements")
        inputs = message.get("inputs", {})
        context = message.get("context", {})
        return await self.execute(action, inputs, context)
