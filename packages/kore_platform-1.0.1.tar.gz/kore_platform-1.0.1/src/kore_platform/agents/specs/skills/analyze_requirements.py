"""Skill: analyze requirements from user input."""

from __future__ import annotations

from typing import Any

from ....domain.value_objects.agent_skill import SkillCategory
from ...base.skill import BaseSkill
from ...base.llm_utils import llm_json_call


_SYSTEM_PROMPT = """\
You are a senior requirements analyst. Given a project description, extract structured requirements.

Respond ONLY with a JSON object matching this exact schema:
{
  "project_name": "short-kebab-case-name",
  "functional_requirements": [
    {"id": "FR-001", "title": "...", "description": "...", "priority": "high|medium|low"}
  ],
  "non_functional_requirements": [
    {"id": "NFR-001", "title": "...", "description": "...", "category": "performance|security|scalability|reliability"}
  ],
  "entities": [
    {"name": "EntityName", "fields": ["field1: type", "field2: type"], "relationships": ["has_many OtherEntity"]}
  ],
  "suggested_stack": {
    "language": "python",
    "framework": "fastapi",
    "database": "postgresql",
    "extras": ["redis", "celery"]
  },
  "assumptions": ["..."],
  "constraints": ["..."]
}

Be thorough: extract at least 3-5 functional requirements and 2-3 non-functional ones.
Identify ALL domain entities with their fields and relationships.
"""


class AnalyzeRequirementsSkill(BaseSkill):
    """Analiza texto libre del usuario y extrae requisitos estructurados."""

    def __init__(self) -> None:
        super().__init__(
            name="analyze_requirements",
            category=SkillCategory.ANALYSIS,
            description="Analiza texto del usuario y extrae requisitos funcionales y no funcionales",
        )

    async def execute(self, inputs: dict[str, Any], context: dict[str, Any]) -> dict[str, Any]:
        """Analiza requisitos a partir de la descripcion del usuario."""
        description: str = inputs.get("description", "")
        project_name: str = inputs.get("project_name", "unnamed-project")

        if not self.has_llm:
            return self._stub_response(description, project_name)

        result = await llm_json_call(
            client=self.llm,
            system_prompt=_SYSTEM_PROMPT,
            user_prompt=f"Project description:\n{description}\n\nSuggested project name: {project_name}",
            temperature=0.3,
            max_tokens=4096,
        )
        result["status"] = "completed"
        result.setdefault("project_name", project_name)
        return result

    @staticmethod
    def _stub_response(description: str, project_name: str) -> dict[str, Any]:
        return {
            "status": "completed",
            "project_name": project_name,
            "functional_requirements": [
                {"id": "FR-001", "title": "Requisito principal",
                 "description": f"Derivado de: {description[:100]}", "priority": "high"},
                {"id": "FR-002", "title": "Requisito secundario",
                 "description": "Funcionalidad de soporte identificada automaticamente", "priority": "medium"},
            ],
            "non_functional_requirements": [
                {"id": "NFR-001", "title": "Rendimiento",
                 "description": "Tiempo de respuesta < 200ms para el 95%", "category": "performance"},
                {"id": "NFR-002", "title": "Seguridad",
                 "description": "Autenticacion y autorizacion en todos los endpoints", "category": "security"},
            ],
            "entities": [],
            "suggested_stack": {"language": "python", "framework": "fastapi", "database": "postgresql", "extras": []},
            "assumptions": ["El sistema sera desplegado en contenedores"],
            "constraints": ["Python 3.12+ requerido"],
        }
