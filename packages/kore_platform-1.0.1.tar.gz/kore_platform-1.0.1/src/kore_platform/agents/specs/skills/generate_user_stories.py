"""Skill: generate user stories from analyzed requirements."""

from __future__ import annotations

import json
from typing import Any

from ....domain.value_objects.agent_skill import SkillCategory
from ...base.llm_utils import llm_json_call
from ...base.skill import BaseSkill

_SYSTEM_PROMPT = (
    "You are a senior product manager. Given requirements JSON, "
    "generate user stories in Given/When/Then format.\n\n"
    "Return a JSON object with this schema:\n"
    "{\n"
    '  "user_stories": [\n'
    "    {\n"
    '      "id": "US-001",\n'
    '      "title": "...",\n'
    '      "as_a": "...",\n'
    '      "i_want": "...",\n'
    '      "so_that": "...",\n'
    '      "acceptance_criteria": [\n'
    '        {"given": "...", "when": "...", "then": "..."}\n'
    "      ],\n"
    '      "priority": "high|medium|low"\n'
    "    }\n"
    "  ]\n"
    "}"
)


class GenerateUserStoriesSkill(BaseSkill):
    """Genera historias de usuario a partir de requisitos analizados."""

    def __init__(self) -> None:
        super().__init__(
            name="generate_user_stories",
            category=SkillCategory.ANALYSIS,
            description="Genera historias de usuario con criterios de aceptacion desde requisitos",
        )

    async def execute(self, inputs: dict[str, Any], context: dict[str, Any]) -> dict[str, Any]:
        """Genera historias de usuario.

        Args:
            inputs: Debe contener ``requirements`` (dict o list[dict]).
            context: Contexto de ejecucion.

        Returns:
            Lista de historias de usuario con criterios de aceptacion.
        """
        if not self.has_llm:
            return self._stub_response(inputs)

        requirements = inputs.get("requirements", {})
        user_prompt = json.dumps(requirements, ensure_ascii=False, indent=2)

        result = await llm_json_call(
            client=self.llm,
            system_prompt=_SYSTEM_PROMPT,
            user_prompt=user_prompt,
            temperature=0.4,
        )

        return {
            "status": "completed",
            **result,
        }

    @staticmethod
    def _stub_response(inputs: dict[str, Any]) -> dict[str, Any]:
        """Respuesta stub cuando no hay LLM disponible."""
        requirements: list[dict[str, Any]] = inputs.get("requirements", [])
        if isinstance(requirements, dict):
            requirements = requirements.get("items", [requirements])
        persona: str = inputs.get("persona", "usuario")

        stories: list[dict[str, Any]] = []
        for i, req in enumerate(requirements, start=1):
            story_id = f"US-{i:03d}"
            title = req.get("title", f"Historia {i}")
            stories.append({
                "id": story_id,
                "title": title,
                "as_a": persona,
                "i_want": title.lower(),
                "so_that": "obtener valor del sistema",
                "acceptance_criteria": [
                    {
                        "given": f"el {persona} accede al sistema",
                        "when": f"ejecuta la accion de {title.lower()}",
                        "then": "el sistema responde correctamente en < 200ms",
                    },
                ],
                "priority": req.get("priority", "medium"),
            })

        if not stories:
            stories.append({
                "id": "US-001",
                "title": "Historia generica",
                "as_a": persona,
                "i_want": "funcionalidad basica",
                "so_that": "usar el sistema",
                "acceptance_criteria": [
                    {
                        "given": "el usuario esta autenticado",
                        "when": "accede al recurso principal",
                        "then": "ve la informacion correcta",
                    },
                ],
                "priority": "high",
            })

        return {
            "status": "completed",
            "user_stories": stories,
        }
