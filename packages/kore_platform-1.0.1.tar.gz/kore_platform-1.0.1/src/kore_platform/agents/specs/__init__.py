"""Specs agent -- requirements analysis and user story generation."""

from .agent import SpecsAgent

__all__ = ["SpecsAgent"]
