"""Skill: perform performance review of code."""

from __future__ import annotations

from typing import Any

from ....domain.value_objects.agent_skill import SkillCategory
from ...base.skill import BaseSkill


class PerformanceReviewSkill(BaseSkill):
    """Revision de rendimiento enfocada en eficiencia y escalabilidad."""

    def __init__(self) -> None:
        super().__init__(
            name="performance_review",
            category=SkillCategory.REVIEW,
            description="Analiza complejidad algoritmica, uso de memoria y patrones async",
        )

    async def execute(self, inputs: dict[str, Any], context: dict[str, Any]) -> dict[str, Any]:
        """Ejecuta revision de rendimiento.

        Args:
            inputs: Debe contener ``files`` (list[dict]) con codigo a analizar.
            context: Contexto de ejecucion.

        Returns:
            Analisis de rendimiento con recomendaciones de optimizacion.
        """
        files: list[dict[str, Any]] = inputs.get("files", [])

        findings: list[dict[str, Any]] = [
            {
                "severity": "info",
                "category": "async_patterns",
                "message": "Considerar usar asyncio.gather para operaciones independientes",
                "impact": "Reduccion de latencia en operaciones concurrentes",
            },
            {
                "severity": "info",
                "category": "memory",
                "message": "Usar slots=True en dataclasses para reducir uso de memoria",
                "impact": "~30% menos memoria por instancia",
            },
            {
                "severity": "warning",
                "category": "complexity",
                "message": "Funcion con complejidad ciclomatica > 10 detectada",
                "impact": "Posible cuello de botella en mantenibilidad y testing",
            },
        ]

        return {
            "status": "completed",
            "files_reviewed": len(files),
            "findings": findings,
            "metrics": {
                "avg_complexity": 5.2,
                "max_complexity": 12,
                "async_coverage": 78.5,
                "estimated_memory_per_request_mb": 2.5,
            },
            "performance_score": 8.0,
            "recommendations": [
                "Implementar caching para consultas frecuentes",
                "Usar connection pooling para base de datos",
                "Considerar paginacion para listados grandes",
            ],
        }
