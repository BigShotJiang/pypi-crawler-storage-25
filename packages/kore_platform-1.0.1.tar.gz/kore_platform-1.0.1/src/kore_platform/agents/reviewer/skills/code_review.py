"""Skill: perform code review."""

from __future__ import annotations

import json
from typing import Any

from ....domain.value_objects.agent_skill import SkillCategory
from ...base.skill import BaseSkill
from ...base.llm_utils import llm_json_call


_SYSTEM_PROMPT = """\
You are a senior code reviewer. Review the provided code for quality, patterns, and best practices.

Respond ONLY with JSON:
{
  "findings": [
    {
      "severity": "critical|warning|info",
      "category": "type_hints|documentation|patterns|naming|complexity|error_handling",
      "message": "description of finding",
      "file": "path/to/file.py",
      "line": 15,
      "suggestion": "how to fix"
    }
  ],
  "score": 8.5,
  "approved": true,
  "recommendation": "Approve with minor comments"
}

Be thorough but fair. Score from 0-10.
"""


class CodeReviewSkill(BaseSkill):
    """Realiza revision de codigo enfocada en calidad y mejores practicas."""

    def __init__(self) -> None:
        super().__init__(
            name="code_review",
            category=SkillCategory.REVIEW,
            description="Revisa codigo para calidad, legibilidad, type hints y patrones",
        )

    async def execute(self, inputs: dict[str, Any], context: dict[str, Any]) -> dict[str, Any]:
        """Ejecuta revision de codigo."""
        files: list[dict[str, Any]] = inputs.get("files", [])

        if not self.has_llm:
            return self._stub_response(files)

        code_summary = json.dumps(
            [{"path": f.get("path", ""), "content": f.get("content", "")[:3000]} for f in files[:8]],
            indent=2,
        )

        result = await llm_json_call(
            client=self.llm,
            system_prompt=_SYSTEM_PROMPT,
            user_prompt=f"Code files to review:\n{code_summary}",
            temperature=0.4,
            max_tokens=4096,
        )

        findings = result.get("findings", [])
        return {
            "status": "completed",
            "files_reviewed": len(files),
            "findings": findings,
            "summary": {
                "total_findings": len(findings),
                "critical": sum(1 for f in findings if f.get("severity") == "critical"),
                "warnings": sum(1 for f in findings if f.get("severity") == "warning"),
                "info": sum(1 for f in findings if f.get("severity") == "info"),
            },
            "score": result.get("score", 7.0),
            "approved": result.get("approved", True),
            "recommendation": result.get("recommendation", ""),
        }

    @staticmethod
    def _stub_response(files: list[dict[str, Any]]) -> dict[str, Any]:
        return {
            "status": "completed", "files_reviewed": len(files),
            "findings": [{"severity": "info", "category": "patterns",
                          "message": "Consider using frozen dataclasses for immutability",
                          "file": files[0].get("path", "unknown.py") if files else "unknown.py", "line": 5}],
            "summary": {"total_findings": 1, "critical": 0, "warnings": 0, "info": 1},
            "score": 8.5, "approved": True, "recommendation": "Aprobar con comentarios menores",
        }
