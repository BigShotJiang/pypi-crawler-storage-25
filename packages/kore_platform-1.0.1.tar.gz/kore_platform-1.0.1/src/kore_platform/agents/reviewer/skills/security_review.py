"""Skill: perform security review of code."""

from __future__ import annotations

import json
from typing import Any

from ....domain.value_objects.agent_skill import SkillCategory
from ...base.skill import BaseSkill
from ...base.llm_utils import llm_json_call


_SYSTEM_PROMPT = """\
You are a security engineer. Review code for vulnerabilities following OWASP Top 10.

Respond ONLY with JSON:
{
  "findings": [
    {
      "severity": "critical|high|medium|low",
      "category": "injection|auth|xss|ssrf|secrets|crypto|input_validation|logging",
      "cwe": "CWE-XXX",
      "message": "description",
      "recommendation": "how to fix"
    }
  ],
  "security_score": 9.0,
  "compliant": true
}
"""


class SecurityReviewSkill(BaseSkill):
    """Revision de seguridad enfocada en vulnerabilidades comunes."""

    def __init__(self) -> None:
        super().__init__(
            name="security_review",
            category=SkillCategory.REVIEW,
            description="Revisa codigo para vulnerabilidades OWASP, inyecciones y manejo de secretos",
        )

    async def execute(self, inputs: dict[str, Any], context: dict[str, Any]) -> dict[str, Any]:
        """Ejecuta revision de seguridad."""
        files: list[dict[str, Any]] = inputs.get("files", [])

        if not self.has_llm:
            return self._stub_response(files)

        code_summary = json.dumps(
            [{"path": f.get("path", ""), "content": f.get("content", "")[:3000]} for f in files[:8]],
            indent=2,
        )

        result = await llm_json_call(
            client=self.llm,
            system_prompt=_SYSTEM_PROMPT,
            user_prompt=f"Code files for security review:\n{code_summary}",
            temperature=0.3,
            max_tokens=4096,
        )

        findings = result.get("findings", [])
        return {
            "status": "completed",
            "files_reviewed": len(files),
            "findings": findings,
            "summary": {
                "critical": sum(1 for f in findings if f.get("severity") == "critical"),
                "high": sum(1 for f in findings if f.get("severity") == "high"),
                "medium": sum(1 for f in findings if f.get("severity") == "medium"),
                "low": sum(1 for f in findings if f.get("severity") == "low"),
            },
            "security_score": result.get("security_score", 8.0),
            "compliant": result.get("compliant", True),
        }

    @staticmethod
    def _stub_response(files: list[dict[str, Any]]) -> dict[str, Any]:
        return {
            "status": "completed", "files_reviewed": len(files),
            "findings": [{"severity": "low", "category": "input_validation", "cwe": "CWE-20",
                          "message": "Validate user inputs", "recommendation": "Use pydantic for validation"}],
            "summary": {"critical": 0, "high": 0, "medium": 0, "low": 1},
            "security_score": 9.0, "compliant": True,
        }
