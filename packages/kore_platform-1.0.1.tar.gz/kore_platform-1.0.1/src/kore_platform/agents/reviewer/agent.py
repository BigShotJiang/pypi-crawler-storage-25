"""ReviewerAgent -- revision de codigo, seguridad y rendimiento."""

from __future__ import annotations

from typing import Any

from ...application.ports.outbound.message_bus import MessageBusPort
from ...infrastructure.security.guardian import Guardian
from ..base.agent import BaseAgent
from .skills.code_review import CodeReviewSkill
from .skills.security_review import SecurityReviewSkill
from .skills.performance_review import PerformanceReviewSkill


class ReviewerAgent(BaseAgent):
    """Agente Revisor.

    Responsable de revisar codigo para calidad, seguridad
    y rendimiento antes de integracion.
    """

    def __init__(
        self,
        bus: MessageBusPort | None = None,
        guardian: Guardian | None = None,
        llm_client: "LLMClientPort | None" = None,
    ) -> None:
        super().__init__(
            name="reviewer",
            role="Revisor de Codigo Senior",
            bus=bus,
            guardian=guardian,
            llm_client=llm_client,
        )
        self.register_skill(CodeReviewSkill())
        self.register_skill(SecurityReviewSkill())
        self.register_skill(PerformanceReviewSkill())

    async def handle_message(self, message: dict[str, Any]) -> dict[str, Any]:
        """Interpreta mensajes dirigidos al agente revisor."""
        action = message.get("action", "code_review")
        inputs = message.get("inputs", {})
        context = message.get("context", {})
        return await self.execute(action, inputs, context)
