"""Skill: generate data schemas from architecture design."""

from __future__ import annotations

import json
from typing import Any

from ....domain.value_objects.agent_skill import SkillCategory
from ...base.llm_utils import llm_json_call
from ...base.skill import BaseSkill

_SYSTEM_PROMPT = (
    "You are a database architect. Generate SQLAlchemy models and Pydantic schemas "
    "based on the entities and architecture.\n\n"
    "Return a JSON object with this schema:\n"
    "{\n"
    '  "models": [\n'
    "    {\n"
    '      "name": "...",\n'
    '      "file_path": "src/models/...",\n'
    '      "content": "python code as string"\n'
    "    }\n"
    "  ],\n"
    '  "schemas": [\n'
    "    {\n"
    '      "name": "...",\n'
    '      "file_path": "src/schemas/...",\n'
    '      "content": "python code as string"\n'
    "    }\n"
    "  ]\n"
    "}"
)


class GenerateSchemasSkill(BaseSkill):
    """Genera esquemas de datos a partir del diseno arquitectonico."""

    def __init__(self) -> None:
        super().__init__(
            name="generate_schemas",
            category=SkillCategory.DESIGN,
            description="Genera esquemas de base de datos y modelos de datos",
        )

    async def execute(self, inputs: dict[str, Any], context: dict[str, Any]) -> dict[str, Any]:
        """Genera esquemas de datos.

        Args:
            inputs: Debe contener ``entities`` (list) y opcionalmente ``architecture`` (dict).
            context: Contexto de ejecucion.

        Returns:
            Esquemas generados con modelos SQLAlchemy y schemas Pydantic.
        """
        if not self.has_llm:
            return self._stub_response(inputs)

        entities = inputs.get("entities", [])
        architecture = inputs.get("architecture", {})

        user_prompt = json.dumps(
            {"entities": entities, "architecture": architecture},
            ensure_ascii=False,
            indent=2,
        )

        result = await llm_json_call(
            client=self.llm,
            system_prompt=_SYSTEM_PROMPT,
            user_prompt=user_prompt,
            temperature=0.2,
            max_tokens=8192,
        )

        return {
            "status": "completed",
            **result,
        }

    @staticmethod
    def _stub_response(inputs: dict[str, Any]) -> dict[str, Any]:
        """Respuesta stub cuando no hay LLM disponible."""
        entities: list[str] = inputs.get("entities", ["User", "Project", "Task"])
        db_type: str = inputs.get("db_type", "postgresql")

        schemas: list[dict[str, Any]] = []
        for entity in entities:
            entity_lower = entity.lower() if isinstance(entity, str) else str(entity)
            schemas.append({
                "entity": entity,
                "table": f"{entity_lower}s",
                "columns": [
                    {"name": "id", "type": "UUID", "primary_key": True},
                    {"name": "created_at", "type": "TIMESTAMP WITH TIME ZONE", "nullable": False},
                    {"name": "updated_at", "type": "TIMESTAMP WITH TIME ZONE", "nullable": False},
                    {"name": "name", "type": "VARCHAR(255)", "nullable": False},
                    {"name": "status", "type": "VARCHAR(50)", "nullable": False, "default": "'active'"},
                ],
                "indexes": [
                    {"name": f"idx_{entity_lower}s_status", "columns": ["status"]},
                    {"name": f"idx_{entity_lower}s_created", "columns": ["created_at"]},
                ],
            })

        return {
            "status": "completed",
            "db_type": db_type,
            "models": [],
            "schemas": schemas,
            "migration_order": [s["table"] for s in schemas],
            "total_tables": len(schemas),
        }
