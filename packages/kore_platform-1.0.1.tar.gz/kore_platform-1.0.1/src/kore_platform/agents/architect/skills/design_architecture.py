"""Skill: design system architecture from requirements."""

from __future__ import annotations

import json
from typing import Any

from ....domain.value_objects.agent_skill import SkillCategory
from ...base.llm_utils import llm_json_call
from ...base.skill import BaseSkill

_SYSTEM_PROMPT = (
    "You are a senior software architect. Design the system architecture "
    "based on requirements and user stories.\n\n"
    "Return a JSON object with this schema:\n"
    "{\n"
    '  "architecture": {\n'
    '    "style": "...",\n'
    '    "layers": ["..."],\n'
    '    "components": [\n'
    "      {\n"
    '        "name": "...",\n'
    '        "responsibility": "...",\n'
    '        "layer": "...",\n'
    '        "dependencies": ["..."]\n'
    "      }\n"
    "    ],\n"
    '    "file_structure": [\n'
    "      {\n"
    '        "path": "src/...",\n'
    '        "type": "module|package",\n'
    '        "description": "..."\n'
    "      }\n"
    "    ],\n"
    '    "patterns": ["..."],\n'
    '    "decisions": [\n'
    "      {\n"
    '        "id": "ADR-001",\n'
    '        "title": "...",\n'
    '        "rationale": "...",\n'
    '        "status": "accepted"\n'
    "      }\n"
    "    ]\n"
    "  }\n"
    "}"
)


class DesignArchitectureSkill(BaseSkill):
    """Disena la arquitectura del sistema basada en requisitos."""

    def __init__(self) -> None:
        super().__init__(
            name="design_architecture",
            category=SkillCategory.DESIGN,
            description="Disena arquitectura hexagonal con componentes, capas y dependencias",
        )

    async def execute(self, inputs: dict[str, Any], context: dict[str, Any]) -> dict[str, Any]:
        """Genera un diseno arquitectonico.

        Args:
            inputs: Debe contener ``requirements`` y opcionalmente ``user_stories``.
            context: Contexto de ejecucion.

        Returns:
            Diseno arquitectonico con capas, componentes y decisiones.
        """
        if not self.has_llm:
            return self._stub_response(inputs)

        requirements = inputs.get("requirements", {})
        user_stories = inputs.get("user_stories", [])

        user_prompt = json.dumps(
            {"requirements": requirements, "user_stories": user_stories},
            ensure_ascii=False,
            indent=2,
        )

        result = await llm_json_call(
            client=self.llm,
            system_prompt=_SYSTEM_PROMPT,
            user_prompt=user_prompt,
            temperature=0.3,
        )

        return {
            "status": "completed",
            **result,
        }

    @staticmethod
    def _stub_response(inputs: dict[str, Any]) -> dict[str, Any]:
        """Respuesta stub cuando no hay LLM disponible."""
        requirements: list[dict[str, Any]] = inputs.get("requirements", [])

        return {
            "status": "completed",
            "architecture": {
                "style": "hexagonal",
                "layers": [
                    {
                        "name": "domain",
                        "description": "Logica de negocio pura, sin dependencias externas",
                        "components": ["entities", "value_objects", "events", "exceptions", "services"],
                    },
                    {
                        "name": "application",
                        "description": "Casos de uso y puertos",
                        "components": ["use_cases", "ports/inbound", "ports/outbound", "dto"],
                    },
                    {
                        "name": "infrastructure",
                        "description": "Adaptadores y configuracion",
                        "components": ["adapters/inbound", "adapters/outbound", "config", "security"],
                    },
                    {
                        "name": "agents",
                        "description": "Agentes especializados con skills",
                        "components": ["base", "specs", "architect", "coder", "tester"],
                    },
                ],
                "components": [],
                "file_structure": [],
                "patterns": [
                    "Hexagonal Architecture (Ports & Adapters)",
                    "CQRS para separacion de comandos y consultas",
                    "Event Sourcing para auditoria inmutable",
                    "Zero Trust Security con Guardian",
                ],
                "decisions": [
                    {
                        "id": "ADR-001",
                        "title": "Arquitectura hexagonal",
                        "rationale": "Desacoplamiento de dominio e infraestructura",
                        "status": "accepted",
                    },
                    {
                        "id": "ADR-002",
                        "title": "Agentes con sandbox",
                        "rationale": "Aislamiento de ejecucion para seguridad",
                        "status": "accepted",
                    },
                ],
            },
            "requirements_covered": len(requirements) if isinstance(requirements, list) else 0,
        }
