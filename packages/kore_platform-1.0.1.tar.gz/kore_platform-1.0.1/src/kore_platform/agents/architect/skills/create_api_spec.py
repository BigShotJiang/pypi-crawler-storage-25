"""Skill: create OpenAPI specification."""

from __future__ import annotations

import json
from typing import Any

from ....domain.value_objects.agent_skill import SkillCategory
from ...base.llm_utils import llm_json_call
from ...base.skill import BaseSkill

_SYSTEM_PROMPT = (
    "You are an API designer. Generate OpenAPI spec and FastAPI route implementations.\n\n"
    "Return a JSON object with this schema:\n"
    "{\n"
    '  "openapi_spec": "YAML string with the full OpenAPI 3.1 specification",\n'
    '  "routes": [\n'
    "    {\n"
    '      "file_path": "src/routes/...",\n'
    '      "content": "python code"\n'
    "    }\n"
    "  ],\n"
    '  "main_app": {\n'
    '    "file_path": "src/main.py",\n'
    '    "content": "python code"\n'
    "  }\n"
    "}"
)


class CreateApiSpecSkill(BaseSkill):
    """Crea especificacion OpenAPI a partir de la arquitectura."""

    def __init__(self) -> None:
        super().__init__(
            name="create_api_spec",
            category=SkillCategory.DESIGN,
            description="Genera especificacion OpenAPI 3.1 con endpoints, esquemas y seguridad",
        )

    async def execute(self, inputs: dict[str, Any], context: dict[str, Any]) -> dict[str, Any]:
        """Genera especificacion API.

        Args:
            inputs: Debe contener ``architecture`` (dict) y opcionalmente ``schemas`` (list).
            context: Contexto de ejecucion.

        Returns:
            Especificacion OpenAPI, rutas FastAPI e implementacion principal.
        """
        if not self.has_llm:
            return self._stub_response(inputs)

        architecture = inputs.get("architecture", {})
        schemas = inputs.get("schemas", [])

        user_prompt = json.dumps(
            {"architecture": architecture, "schemas": schemas},
            ensure_ascii=False,
            indent=2,
        )

        result = await llm_json_call(
            client=self.llm,
            system_prompt=_SYSTEM_PROMPT,
            user_prompt=user_prompt,
            temperature=0.2,
            max_tokens=8192,
        )

        return {
            "status": "completed",
            **result,
        }

    @staticmethod
    def _stub_response(inputs: dict[str, Any]) -> dict[str, Any]:
        """Respuesta stub cuando no hay LLM disponible."""
        resources: list[str] = inputs.get("resources", ["jobs", "agents", "flows"])
        base_path: str = inputs.get("base_path", "/api/v1")
        title: str = inputs.get("title", "Kore Platform API")

        paths: dict[str, Any] = {}
        for resource in resources:
            resource_path = f"{base_path}/{resource}"
            paths[resource_path] = {
                "get": {
                    "summary": f"Listar {resource}",
                    "operationId": f"list_{resource}",
                    "responses": {
                        "200": {"description": f"Lista de {resource}"},
                        "401": {"description": "No autorizado"},
                    },
                },
                "post": {
                    "summary": f"Crear {resource[:-1] if resource.endswith('s') else resource}",
                    "operationId": f"create_{resource}",
                    "responses": {
                        "201": {"description": "Recurso creado"},
                        "400": {"description": "Datos invalidos"},
                        "401": {"description": "No autorizado"},
                    },
                },
            }
            paths[f"{resource_path}/{{id}}"] = {
                "get": {
                    "summary": f"Obtener {resource} por ID",
                    "operationId": f"get_{resource}_by_id",
                    "parameters": [
                        {"name": "id", "in": "path", "required": True, "schema": {"type": "string", "format": "uuid"}},
                    ],
                    "responses": {
                        "200": {"description": "Recurso encontrado"},
                        "404": {"description": "No encontrado"},
                    },
                },
            }

        return {
            "status": "completed",
            "openapi_spec": {
                "openapi": "3.1.0",
                "info": {"title": title, "version": "1.0.0"},
                "paths": paths,
                "components": {
                    "securitySchemes": {
                        "bearerAuth": {
                            "type": "http",
                            "scheme": "bearer",
                            "bearerFormat": "JWT",
                        },
                    },
                },
                "security": [{"bearerAuth": []}],
            },
            "routes": [],
            "main_app": {},
            "total_endpoints": len(paths),
            "resources": resources,
        }
