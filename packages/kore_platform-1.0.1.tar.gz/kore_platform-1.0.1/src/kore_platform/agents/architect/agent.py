"""ArchitectAgent -- disena arquitectura, esquemas y especificaciones API."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from ...application.ports.outbound.message_bus import MessageBusPort
from ...infrastructure.security.guardian import Guardian
from ..base.agent import BaseAgent
from .skills.design_architecture import DesignArchitectureSkill
from .skills.generate_schemas import GenerateSchemasSkill
from .skills.create_api_spec import CreateApiSpecSkill

if TYPE_CHECKING:
    from ...application.ports.outbound.llm_client import LLMClientPort


class ArchitectAgent(BaseAgent):
    """Agente Arquitecto.

    Responsable de disenar la arquitectura del sistema, generar
    esquemas de datos y crear especificaciones de API.
    """

    def __init__(
        self,
        bus: MessageBusPort | None = None,
        guardian: Guardian | None = None,
        llm_client: LLMClientPort | None = None,
    ) -> None:
        super().__init__(
            name="architect",
            role="Arquitecto de Software",
            bus=bus,
            guardian=guardian,
            llm_client=llm_client,
        )
        self.register_skill(DesignArchitectureSkill())
        self.register_skill(GenerateSchemasSkill())
        self.register_skill(CreateApiSpecSkill())

    async def handle_message(self, message: dict[str, Any]) -> dict[str, Any]:
        """Interpreta mensajes dirigidos al agente arquitecto."""
        action = message.get("action", "design_architecture")
        inputs = message.get("inputs", {})
        context = message.get("context", {})
        return await self.execute(action, inputs, context)
