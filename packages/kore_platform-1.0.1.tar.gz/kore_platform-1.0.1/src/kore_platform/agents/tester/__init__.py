"""Tester agent -- unit tests, integration tests, and test execution."""

from .agent import TesterAgent

__all__ = ["TesterAgent"]
