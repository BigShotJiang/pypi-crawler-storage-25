"""Skill: write integration tests."""

from __future__ import annotations

import json
from typing import Any

from ....domain.value_objects.agent_skill import SkillCategory
from ...base.skill import BaseSkill
from ...base.llm_utils import llm_json_call


_SYSTEM_PROMPT = """\
You are a senior QA engineer. Given source code and unit tests, generate integration tests.

Respond ONLY with JSON:
{
  "test_files": [
    {
      "path": "tests/integration/test_api.py",
      "content": "complete integration test code as string",
      "tests_count": 3,
      "components_tested": ["api", "database"]
    }
  ],
  "total_tests": 5,
  "requires_fixtures": ["database", "http_client"]
}

Rules:
- Use httpx.AsyncClient for HTTP testing
- Test full request/response cycles
- Include fixtures for database and external service setup/teardown
- Test error scenarios and edge cases
"""


class WriteIntegrationTestsSkill(BaseSkill):
    """Genera tests de integracion entre componentes."""

    def __init__(self) -> None:
        super().__init__(
            name="write_integration_tests",
            category=SkillCategory.TESTING,
            description="Genera tests de integracion para validar interaccion entre componentes",
            requires_sandbox=True,
        )

    async def execute(self, inputs: dict[str, Any], context: dict[str, Any]) -> dict[str, Any]:
        """Genera tests de integracion."""
        source_files = inputs.get("files", inputs.get("code", {}).get("files", []))
        test_files_input = inputs.get("test_files", [])

        if not self.has_llm:
            return self._stub_response()

        context_summary = json.dumps({
            "source_files": [{"path": f.get("path", "")} for f in source_files[:10]],
            "existing_tests": [{"path": f.get("path", "")} for f in test_files_input[:5]],
        }, indent=2)

        result = await llm_json_call(
            client=self.llm,
            system_prompt=_SYSTEM_PROMPT,
            user_prompt=f"Project files:\n{context_summary}",
            temperature=0.2,
            max_tokens=8192,
        )

        test_files = result.get("test_files", [])
        return {
            "status": "completed",
            "files": test_files,
            "test_files": test_files,
            "total_tests": result.get("total_tests", len(test_files) * 2),
            "requires_fixtures": result.get("requires_fixtures", []),
        }

    @staticmethod
    def _stub_response() -> dict[str, Any]:
        test_code = (
            '"""Integration tests."""\nimport pytest\n\n'
            '@pytest.mark.asyncio\n@pytest.mark.integration\n'
            'async def test_health():\n    assert True\n'
        )
        return {
            "status": "completed",
            "files": [{"path": "tests/integration/test_integration.py", "content": test_code, "tests_count": 1}],
            "test_files": [{"path": "tests/integration/test_integration.py", "content": test_code, "test_count": 1}],
            "total_tests": 1, "requires_fixtures": ["database", "http_client"],
        }
