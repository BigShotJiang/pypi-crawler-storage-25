"""Skill: run test suites and report results."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from ....domain.value_objects.agent_skill import SkillCategory
from ...base.skill import BaseSkill
from ....orchestration.subprocess_runner import SubprocessRunner


class RunTestsSkill(BaseSkill):
    """Ejecuta suites de tests reales via subprocess."""

    def __init__(self) -> None:
        super().__init__(
            name="run_tests",
            category=SkillCategory.TESTING,
            description="Ejecuta pytest con cobertura y genera reporte de resultados",
            requires_sandbox=True,
            max_execution_seconds=600,
        )
        self._runner = SubprocessRunner()

    async def execute(self, inputs: dict[str, Any], context: dict[str, Any]) -> dict[str, Any]:
        """Ejecuta tests y retorna resultados reales.

        Args:
            inputs: Debe contener ``test_path`` (str) y opcionalmente ``markers``.
            context: Contexto de ejecucion con workspace.

        Returns:
            Resultados de ejecucion con salida real de pytest.
        """
        test_path: str = inputs.get("test_path", "tests/")
        workspace = context.get("workspace")

        if workspace is None:
            return self._stub_response(test_path)

        workspace_path = Path(workspace)
        tests_dir = workspace_path / test_path

        # Si no hay directorio de tests, usar stub
        if not tests_dir.exists():
            return self._stub_response(test_path)

        # Setup PYTHONPATH
        deps_dir = workspace_path / ".deps"
        env = {
            "PYTHONPATH": f"{workspace_path}:{deps_dir}",
            "PYTHONDONTWRITEBYTECODE": "1",
        }

        # Ejecutar pytest real
        result = await self._runner.run(
            cmd=["python", "-m", "pytest", str(tests_dir), "--tb=short", "-q"],
            cwd=str(workspace_path),
            env=env,
            timeout=120,
        )

        # Parsear resultado basico
        passed = 0
        failed = 0
        errors = 0
        for line in result.stdout.splitlines():
            if "passed" in line:
                parts = line.split()
                for i, p in enumerate(parts):
                    if p == "passed" and i > 0:
                        try:
                            passed = int(parts[i - 1])
                        except ValueError:
                            pass
                    elif p == "failed" and i > 0:
                        try:
                            failed = int(parts[i - 1])
                        except ValueError:
                            pass
                    elif p == "error" and i > 0:
                        try:
                            errors = int(parts[i - 1])
                        except ValueError:
                            pass

        return {
            "status": "completed" if result.success else "failed",
            "test_path": test_path,
            "command": result.command,
            "exit_code": result.exit_code,
            "stdout": result.stdout,
            "stderr": result.stderr,
            "results": {
                "total": passed + failed + errors,
                "passed": passed,
                "failed": failed,
                "errors": errors,
                "duration_seconds": 0,
            },
        }

    @staticmethod
    def _stub_response(test_path: str) -> dict[str, Any]:
        """Fallback stub cuando no hay workspace."""
        return {
            "status": "completed",
            "test_path": test_path,
            "command": f"pytest {test_path} --tb=short -q",
            "exit_code": 0,
            "stdout": "No tests directory found. Skipped.",
            "stderr": "",
            "results": {
                "total": 0, "passed": 0, "failed": 0,
                "errors": 0, "duration_seconds": 0,
            },
        }
