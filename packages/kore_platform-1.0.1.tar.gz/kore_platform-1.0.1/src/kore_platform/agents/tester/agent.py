"""TesterAgent -- genera y ejecuta tests unitarios e integracion."""

from __future__ import annotations

from typing import Any

from ...application.ports.outbound.message_bus import MessageBusPort
from ...infrastructure.security.guardian import Guardian
from ..base.agent import BaseAgent
from .skills.write_unit_tests import WriteUnitTestsSkill
from .skills.write_integration_tests import WriteIntegrationTestsSkill
from .skills.run_tests import RunTestsSkill


class TesterAgent(BaseAgent):
    """Agente de Testing.

    Responsable de generar tests unitarios, tests de integracion
    y ejecutar suites de pruebas completas.
    """

    def __init__(
        self,
        bus: MessageBusPort | None = None,
        guardian: Guardian | None = None,
        llm_client: "LLMClientPort | None" = None,
    ) -> None:
        super().__init__(
            name="tester",
            role="Ingeniero de QA",
            bus=bus,
            guardian=guardian,
            llm_client=llm_client,
        )
        self.register_skill(WriteUnitTestsSkill())
        self.register_skill(WriteIntegrationTestsSkill())
        self.register_skill(RunTestsSkill())

    async def handle_message(self, message: dict[str, Any]) -> dict[str, Any]:
        """Interpreta mensajes dirigidos al agente de testing."""
        action = message.get("action", "write_unit_tests")
        inputs = message.get("inputs", {})
        context = message.get("context", {})
        return await self.execute(action, inputs, context)
