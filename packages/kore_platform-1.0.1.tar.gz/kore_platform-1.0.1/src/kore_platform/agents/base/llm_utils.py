"""LLM utility helpers — resilient calls with retry, JSON recovery, cost tracking.

Resilience features:
- Exponential backoff retry (configurable max_retries)
- Partial JSON recovery (tolerant parser)
- Token budget awareness (truncates prompts if needed)
- Cost estimation per call (OpenAI/Anthropic pricing)
- Accumulated usage tracking
"""

from __future__ import annotations

import asyncio
import json
import logging
import re
from dataclasses import dataclass, field
from typing import Any

from ...application.ports.outbound.llm_client import LLMClientPort, LLMMessage

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Cost estimation (per 1M tokens, approximate Feb 2026 prices)
# ---------------------------------------------------------------------------

_COST_PER_1M: dict[str, dict[str, float]] = {
    "gpt-4o": {"input": 2.50, "output": 10.00},
    "gpt-4o-mini": {"input": 0.15, "output": 0.60},
    "claude-sonnet-4-5-20250929": {"input": 3.00, "output": 15.00},
    "claude-haiku-4-5-20251001": {"input": 0.80, "output": 4.00},
    "qwen2.5-coder:7b-instruct": {"input": 0.0, "output": 0.0},  # local
}

# Global usage accumulator
_usage_accumulator: dict[str, int] = {"input_tokens": 0, "output_tokens": 0, "calls": 0}
_cost_accumulator: float = 0.0


def get_accumulated_usage() -> dict[str, Any]:
    """Returns accumulated token usage and estimated cost."""
    return {
        **_usage_accumulator,
        "estimated_cost_usd": round(_cost_accumulator, 4),
    }


def _track_usage(model: str | None, usage: dict[str, int]) -> None:
    """Track token usage and estimate cost."""
    global _cost_accumulator
    input_tokens = usage.get("prompt_tokens", usage.get("input_tokens", 0))
    output_tokens = usage.get("completion_tokens", usage.get("output_tokens", 0))

    _usage_accumulator["input_tokens"] += input_tokens
    _usage_accumulator["output_tokens"] += output_tokens
    _usage_accumulator["calls"] += 1

    # Estimate cost
    if model:
        # Match partial model names
        pricing = None
        for key, prices in _COST_PER_1M.items():
            if key in model.lower():
                pricing = prices
                break
        if pricing:
            cost = (input_tokens * pricing["input"] + output_tokens * pricing["output"]) / 1_000_000
            _cost_accumulator += cost


# ---------------------------------------------------------------------------
# Token budget management
# ---------------------------------------------------------------------------

# Approximate context windows
_CONTEXT_WINDOWS: dict[str, int] = {
    "qwen2.5-coder:7b-instruct": 32_000,
    "gpt-4o": 128_000,
    "gpt-4o-mini": 128_000,
    "claude-sonnet-4-5-20250929": 200_000,
    "claude-haiku-4-5-20251001": 200_000,
}

# Rough chars-per-token ratio (conservative)
_CHARS_PER_TOKEN = 3.5


def estimate_tokens(text: str) -> int:
    """Rough token count estimate from character count."""
    return int(len(text) / _CHARS_PER_TOKEN)


def truncate_to_budget(
    system_prompt: str,
    user_prompt: str,
    max_output_tokens: int,
    model: str | None = None,
) -> tuple[str, str]:
    """Trunca prompts si exceden la ventana de contexto del modelo.

    Prioriza: system_prompt intacto, trunca user_prompt si es necesario.
    """
    context_window = 32_000  # Conservative default
    if model:
        for key, window in _CONTEXT_WINDOWS.items():
            if key in model.lower():
                context_window = window
                break

    # Reserve tokens for output
    available = context_window - max_output_tokens - 500  # 500 token safety margin

    system_tokens = estimate_tokens(system_prompt)
    user_tokens = estimate_tokens(user_prompt)

    if system_tokens + user_tokens <= available:
        return system_prompt, user_prompt

    # Need to truncate user_prompt
    user_budget_tokens = available - system_tokens
    if user_budget_tokens < 200:
        # Even system prompt is too long — truncate both
        system_chars = int(available * 0.3 * _CHARS_PER_TOKEN)
        user_chars = int(available * 0.7 * _CHARS_PER_TOKEN)
        logger.warning("token_budget_critical truncating_both system=%d user=%d", system_chars, user_chars)
        return system_prompt[:system_chars] + "\n...(truncated)", user_prompt[:user_chars] + "\n...(truncated)"

    user_chars = int(user_budget_tokens * _CHARS_PER_TOKEN)
    logger.info("token_budget_truncate user_prompt %d -> %d chars", len(user_prompt), user_chars)
    return system_prompt, user_prompt[:user_chars] + "\n...(truncated for context window)"


# ---------------------------------------------------------------------------
# Retry with exponential backoff
# ---------------------------------------------------------------------------

async def _retry_with_backoff(
    coro_factory: Any,
    max_retries: int = 3,
    base_delay: float = 1.0,
    max_delay: float = 30.0,
) -> Any:
    """Ejecuta una coroutine con reintentos y backoff exponencial."""
    last_exc = None
    for attempt in range(max_retries + 1):
        try:
            return await coro_factory()
        except Exception as exc:
            last_exc = exc
            if attempt >= max_retries:
                break
            delay = min(base_delay * (2 ** attempt), max_delay)
            logger.warning(
                "llm_retry attempt=%d/%d delay=%.1fs error=%s",
                attempt + 1, max_retries, delay, exc,
            )
            await asyncio.sleep(delay)
    raise last_exc  # type: ignore[misc]


# ---------------------------------------------------------------------------
# Main LLM call functions
# ---------------------------------------------------------------------------

async def llm_json_call(
    client: LLMClientPort,
    system_prompt: str,
    user_prompt: str,
    temperature: float = 0.3,
    max_tokens: int = 4096,
    model: str | None = None,
    max_retries: int = 2,
) -> dict[str, Any]:
    """Hace una llamada LLM y extrae JSON robusto de la respuesta.

    Features:
    - Token budget management (auto-truncates if needed)
    - Structured output -> chat fallback
    - Retry with exponential backoff
    - Partial JSON recovery
    - Cost tracking
    """
    # Apply token budget
    system_prompt, user_prompt = truncate_to_budget(
        system_prompt, user_prompt, max_tokens, model,
    )

    messages = [
        LLMMessage(role="system", content=system_prompt),
        LLMMessage(role="user", content=user_prompt),
    ]

    # Attempt 1: structured_output (no retry — often unsupported)
    try:
        result = await client.structured_output(
            messages=messages,
            schema={"type": "object"},
            model=model,
        )
        if isinstance(result, dict):
            return result
    except Exception as exc:
        logger.debug("structured_output failed, falling back to chat: %s", exc)

    # Attempt 2: chat + JSON extraction with retry
    async def _chat_call() -> dict[str, Any]:
        response = await client.chat(
            messages=messages,
            temperature=temperature,
            max_tokens=max_tokens,
            model=model,
        )
        _track_usage(model, response.usage)
        return extract_json(response.content)

    return await _retry_with_backoff(_chat_call, max_retries=max_retries)


async def llm_text_call(
    client: LLMClientPort,
    system_prompt: str,
    user_prompt: str,
    temperature: float = 0.3,
    max_tokens: int = 4096,
    model: str | None = None,
    max_retries: int = 2,
) -> str:
    """Hace una llamada LLM y devuelve el texto raw. Con retry y cost tracking."""
    system_prompt, user_prompt = truncate_to_budget(
        system_prompt, user_prompt, max_tokens, model,
    )

    messages = [
        LLMMessage(role="system", content=system_prompt),
        LLMMessage(role="user", content=user_prompt),
    ]

    async def _call() -> str:
        response = await client.chat(
            messages=messages,
            temperature=temperature,
            max_tokens=max_tokens,
            model=model,
        )
        _track_usage(model, response.usage)
        return response.content

    return await _retry_with_backoff(_call, max_retries=max_retries)


async def llm_code_call(
    client: LLMClientPort,
    system_prompt: str,
    user_prompt: str,
    temperature: float = 0.2,
    max_tokens: int = 8192,
    model: str | None = None,
    max_retries: int = 2,
) -> str:
    """Hace una llamada LLM optimizada para generacion de codigo."""
    raw = await llm_text_call(
        client=client,
        system_prompt=system_prompt,
        user_prompt=user_prompt,
        temperature=temperature,
        max_tokens=max_tokens,
        model=model,
        max_retries=max_retries,
    )
    return extract_code_block(raw)


# ---------------------------------------------------------------------------
# JSON extraction (tolerant)
# ---------------------------------------------------------------------------

def extract_json(text: str) -> dict[str, Any]:
    """Extrae JSON de texto con multiples estrategias de recuperacion.

    Strategies:
    1. Direct parse
    2. ```json blocks
    3. Balanced brace extraction
    4. Partial JSON repair (trailing comma, unclosed strings)
    """
    # Strategy 1: direct parse
    try:
        return json.loads(text)
    except (json.JSONDecodeError, ValueError):
        pass

    # Strategy 2: ```json ... ``` blocks
    match = re.search(r"```(?:json)?\s*\n?(.*?)\n?```", text, re.DOTALL)
    if match:
        try:
            return json.loads(match.group(1).strip())
        except (json.JSONDecodeError, ValueError):
            # Try repair on extracted block
            repaired = _repair_json(match.group(1).strip())
            if repaired is not None:
                return repaired

    # Strategy 3: balanced brace extraction
    brace_start = text.find("{")
    if brace_start >= 0:
        depth = 0
        for i, ch in enumerate(text[brace_start:], brace_start):
            if ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    candidate = text[brace_start:i + 1]
                    try:
                        return json.loads(candidate)
                    except (json.JSONDecodeError, ValueError):
                        # Try repair
                        repaired = _repair_json(candidate)
                        if repaired is not None:
                            return repaired
                    break

    # Strategy 4: find any JSON-like structure and repair
    repaired = _repair_json(text)
    if repaired is not None:
        return repaired

    raise ValueError(f"Could not extract JSON from LLM response: {text[:200]!r}...")


def _repair_json(text: str) -> dict[str, Any] | None:
    """Intenta reparar JSON malformado comun de LLMs.

    Handles:
    - Trailing commas: {"a": 1,} -> {"a": 1}
    - Single quotes: {'a': 1} -> {"a": 1}
    - Unclosed strings
    - Missing closing braces
    """
    # Remove trailing commas before } or ]
    fixed = re.sub(r",\s*([}\]])", r"\1", text)

    # Replace single quotes with double quotes (naive but handles common cases)
    if "'" in fixed and '"' not in fixed:
        fixed = fixed.replace("'", '"')

    # Try adding missing closing braces
    open_count = fixed.count("{") - fixed.count("}")
    if open_count > 0:
        fixed += "}" * open_count

    open_brackets = fixed.count("[") - fixed.count("]")
    if open_brackets > 0:
        fixed += "]" * open_brackets

    try:
        result = json.loads(fixed)
        if isinstance(result, dict):
            return result
    except (json.JSONDecodeError, ValueError):
        pass

    return None


def extract_code_block(text: str) -> str:
    """Extrae codigo de un bloque markdown ```...```."""
    match = re.search(r"```(?:\w+)?\s*\n(.*?)\n```", text, re.DOTALL)
    if match:
        return match.group(1).strip()
    return text.strip()
