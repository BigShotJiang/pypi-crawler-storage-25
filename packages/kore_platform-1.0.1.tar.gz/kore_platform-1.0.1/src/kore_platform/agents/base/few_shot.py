"""Few-shot example loader with contextual selection.

Features:
- Multiple example types (API, CLI, ETL, library, tests)
- Contextual selector: picks best example based on idea keywords
- Smart truncation: never cuts mid-file in JSON examples
- Falls back to no example if no match (avoids confusing the model)
"""

from __future__ import annotations

import json
import logging
from pathlib import Path

logger = logging.getLogger(__name__)

_EXAMPLES_DIR = Path(__file__).resolve().parent.parent / "examples"

# ---------------------------------------------------------------------------
# Example catalog with keywords for contextual matching
# ---------------------------------------------------------------------------

_EXAMPLE_CATALOG: dict[str, dict[str, list[str]]] = {
    "fastapi_crud": {
        "keywords": [
            "api", "rest", "crud", "fastapi", "endpoint", "route",
            "database", "sqlalchemy", "pydantic", "web", "server",
            "backend", "http", "todo", "items", "users", "products",
            "e-commerce", "shop", "store", "booking", "reservation",
        ],
    },
    "cli_tool": {
        "keywords": [
            "cli", "command", "terminal", "argparse", "click",
            "script", "tool", "utility", "batch", "automation",
        ],
    },
    "etl_pipeline": {
        "keywords": [
            "etl", "pipeline", "data", "transform", "extract", "load",
            "csv", "json", "migration", "import", "export", "batch",
            "processing", "analytics", "report",
        ],
    },
    "python_library": {
        "keywords": [
            "library", "package", "module", "sdk", "wrapper",
            "utility", "helper", "validator", "parser",
        ],
    },
}

_TEST_CATALOG: dict[str, dict[str, list[str]]] = {
    "pytest_example": {
        "keywords": ["test", "pytest", "unit", "integration", "coverage"],
    },
}


def select_best_example(idea: str, catalog: dict[str, dict[str, list[str]]] | None = None) -> str | None:
    """Selecciona el ejemplo mas relevante basado en la idea del usuario.

    Returns None if no example matches well enough (>= 1 keyword hit).
    """
    if catalog is None:
        catalog = _EXAMPLE_CATALOG

    idea_lower = idea.lower()
    best_name: str | None = None
    best_score = 0

    for name, meta in catalog.items():
        score = sum(1 for kw in meta["keywords"] if kw in idea_lower)
        if score > best_score:
            best_score = score
            best_name = name

    if best_score < 1:
        return None  # No match — don't inject irrelevant example

    return best_name


def load_example(name: str, max_chars: int = 3000) -> str:
    """Load a few-shot example by name.

    Parameters
    ----------
    name:
        Example filename without extension (e.g. ``"fastapi_crud"``).
    max_chars:
        Maximum characters to return. Uses smart truncation.

    Returns
    -------
    str
        The example text, or empty string if not found.
    """
    path = _EXAMPLES_DIR / f"{name}.txt"
    if not path.exists():
        logger.warning("few_shot_example_not_found name=%s path=%s", name, path)
        return ""
    text = path.read_text(encoding="utf-8")
    if len(text) > max_chars:
        text = _smart_truncate(text, max_chars)
    return text


def _smart_truncate(text: str, max_chars: int) -> str:
    """Trunca JSON sin cortar a mitad de un archivo.

    Intenta parsear el JSON y eliminar archivos del final hasta que quepa.
    Si no puede, trunca con indicador.
    """
    try:
        data = json.loads(text)
        files_key = "files" if "files" in data else "test_files" if "test_files" in data else None
        if files_key and isinstance(data.get(files_key), list):
            files = data[files_key]
            while len(json.dumps(data, indent=2)) > max_chars and len(files) > 1:
                files.pop()
            data[files_key] = files
            return json.dumps(data, indent=2)
    except (json.JSONDecodeError, TypeError):
        pass

    return text[:max_chars] + "\n... (truncated)"


def build_few_shot_prompt(
    base_prompt: str,
    example_name: str | None = None,
    idea: str = "",
    max_chars: int = 3000,
    catalog: dict[str, dict[str, list[str]]] | None = None,
) -> str:
    """Append a contextually-selected few-shot example to a system prompt.

    Parameters
    ----------
    base_prompt:
        The original system prompt.
    example_name:
        Explicit example name. If None, auto-selects based on idea.
    idea:
        User's idea for contextual selection (used if example_name is None).
    max_chars:
        Max chars for the example.
    catalog:
        Optional custom catalog for selection.

    Returns
    -------
    str
        Combined prompt with example appended, or base_prompt if no match.
    """
    # Auto-select if no explicit name
    if example_name is None:
        example_name = select_best_example(idea, catalog)

    if example_name is None:
        return base_prompt  # No match — don't inject irrelevant example

    example = load_example(example_name, max_chars=max_chars)
    if not example:
        return base_prompt

    return (
        f"{base_prompt}\n\n"
        f"--- EXAMPLE OUTPUT (follow this structure and completeness) ---\n"
        f"{example}\n"
        f"--- END EXAMPLE ---"
    )
