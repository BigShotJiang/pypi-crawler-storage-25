"""Sandbox context dataclass for agent execution isolation."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True, slots=True)
class SandboxContext:
    """Contexto de sandbox inmutable para ejecucion aislada de agentes.

    Describe las restricciones y permisos bajo los que un agente opera.
    """

    sandbox_id: str
    agent_name: str
    workspace_path: str = "/workspace"
    network_enabled: bool = False
    read_only_root: bool = True
    max_memory_mb: int = 512
    max_cpu_seconds: int = 300
    allowed_paths: tuple[str, ...] = ("/workspace",)
    environment: dict[str, str] = field(default_factory=dict)

    def allows_path(self, path: str) -> bool:
        """Verifica si el path esta permitido en este sandbox."""
        return any(path.startswith(allowed) for allowed in self.allowed_paths)

    def to_config(self) -> dict[str, Any]:
        """Serializa la configuracion del sandbox."""
        return {
            "sandbox_id": self.sandbox_id,
            "agent_name": self.agent_name,
            "workspace_path": self.workspace_path,
            "network": self.network_enabled,
            "read_only_root": self.read_only_root,
            "max_memory_mb": self.max_memory_mb,
            "max_cpu_seconds": self.max_cpu_seconds,
            "allowed_paths": list(self.allowed_paths),
        }
