"""Abstract base agent -- foundation for all specialized agents."""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any

from ...application.ports.outbound.message_bus import MessageBusPort
from ...domain.entities.agent import AgentEntity
from ...domain.value_objects.agent_skill import AgentSkill
from ...infrastructure.security.guardian import Guardian, GuardianResult
from .skill import BaseSkill

if TYPE_CHECKING:
    from ...application.ports.outbound.llm_client import LLMClientPort

logger = logging.getLogger(__name__)


class BaseAgent(ABC):
    """Clase base abstracta para todos los agentes de la plataforma.

    Proporciona:
    - Registro de skills
    - Validacion de acciones via Guardian
    - Comunicacion via MessageBusPort
    - Ciclo de vida (execute / cleanup)
    """

    def __init__(
        self,
        name: str,
        role: str,
        bus: MessageBusPort | None = None,
        guardian: Guardian | None = None,
        llm_client: LLMClientPort | None = None,
    ) -> None:
        self._name = name
        self._role = role
        self._bus = bus
        self._guardian = guardian or Guardian()
        self._skills: dict[str, BaseSkill] = {}
        self._llm_client = llm_client

    # -- Properties --------------------------------------------------------

    @property
    def name(self) -> str:
        return self._name

    @property
    def role(self) -> str:
        return self._role

    @property
    def bus(self) -> MessageBusPort | None:
        return self._bus

    @property
    def guardian(self) -> Guardian:
        return self._guardian

    @property
    def skills(self) -> list[BaseSkill]:
        return list(self._skills.values())

    @property
    def skill_names(self) -> list[str]:
        return list(self._skills.keys())

    # -- Domain bridge -----------------------------------------------------

    def to_entity(self) -> AgentEntity:
        """Convierte a entidad de dominio."""
        domain_skills: frozenset[AgentSkill] = frozenset(
            s.to_domain() for s in self._skills.values()
        )
        return AgentEntity(
            name=self._name,
            role=self._role,
            skills=domain_skills,
        )

    # -- Skill management --------------------------------------------------

    def register_skill(self, skill: BaseSkill) -> None:
        """Registra una skill en el agente. Propaga llm_client si disponible."""
        if self._llm_client is not None and not skill.has_llm:
            skill.set_llm_client(self._llm_client)
        self._skills[skill.name] = skill
        logger.info("skill_registered agent=%s skill=%s", self._name, skill.name)

    def get_skill(self, skill_name: str) -> BaseSkill | None:
        """Obtiene skill por nombre."""
        return self._skills.get(skill_name)

    def has_skill(self, skill_name: str) -> bool:
        """Verifica si el agente tiene una skill especifica."""
        return skill_name in self._skills

    # -- Guardian integration ----------------------------------------------

    def validate_action(self, action: str, inputs: dict[str, Any]) -> GuardianResult:
        """Valida una accion a traves del Guardian."""
        return self._guardian.validate_agent_action(self._name, action, inputs)

    # -- Bus integration ---------------------------------------------------

    async def publish_event(self, channel: str, event: dict[str, Any]) -> None:
        """Publica evento en el bus si esta disponible."""
        if self._bus is not None:
            enriched = {"agent": self._name, **event}
            await self._bus.publish(channel, enriched)

    async def log_activity(self, entry: dict[str, Any]) -> None:
        """Registra actividad en el stream del agente."""
        if self._bus is not None:
            enriched = {"agent": self._name, **entry}
            await self._bus.log(f"agent:{self._name}:activity", enriched)

    # -- Lifecycle ---------------------------------------------------------

    async def execute(self, skill_name: str, inputs: dict[str, Any], context: dict[str, Any]) -> dict[str, Any]:
        """Ejecuta una skill por nombre, con validacion Guardian.

        Args:
            skill_name: Nombre de la skill a ejecutar.
            inputs: Datos de entrada.
            context: Contexto de ejecucion.

        Returns:
            Resultado de la ejecucion.

        Raises:
            ValueError: Si la skill no existe.
        """
        skill = self.get_skill(skill_name)
        if skill is None:
            raise ValueError(f"Skill '{skill_name}' no encontrada en agente '{self._name}'")

        # Validacion Guardian
        validation = self.validate_action(skill_name, inputs)
        if not validation.allowed:
            logger.warning(
                "action_blocked agent=%s skill=%s reason=%s",
                self._name, skill_name, validation.reason,
            )
            return {
                "status": "blocked",
                "reason": validation.reason,
                "agent": self._name,
                "skill": skill_name,
            }

        await self.publish_event("agent:execution", {
            "event": "skill_started",
            "skill": skill_name,
        })

        result = await skill.safe_execute(inputs, context)

        await self.publish_event("agent:execution", {
            "event": "skill_completed",
            "skill": skill_name,
            "status": result.get("status", "completed"),
        })

        await self.log_activity({
            "action": skill_name,
            "status": result.get("status", "completed"),
        })

        return result

    @abstractmethod
    async def handle_message(self, message: dict[str, Any]) -> dict[str, Any]:
        """Maneja un mensaje entrante dirigido al agente.

        Cada agente concreto decide como interpretar mensajes.
        """
        ...

    async def cleanup(self) -> None:
        """Limpieza de recursos al finalizar."""
        logger.info("agent_cleanup agent=%s", self._name)
        await self.publish_event("agent:lifecycle", {"event": "cleanup"})

    def __repr__(self) -> str:
        skill_count = len(self._skills)
        return f"<{type(self).__name__} name={self._name!r} role={self._role!r} skills={skill_count}>"
