"""Base skill abstraction for agent capabilities."""

from __future__ import annotations

import logging
import time
from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any

from ...domain.value_objects.agent_skill import AgentSkill, SkillCategory

if TYPE_CHECKING:
    from ...application.ports.outbound.llm_client import LLMClientPort

logger = logging.getLogger(__name__)


class BaseSkill(ABC):
    """Clase base para todas las habilidades de agentes.

    Cada skill concreta implementa ``execute`` con logica especifica.
    """

    def __init__(
        self,
        name: str,
        category: SkillCategory,
        description: str = "",
        requires_sandbox: bool = False,
        max_execution_seconds: int = 300,
        llm_client: LLMClientPort | None = None,
    ) -> None:
        self._name = name
        self._category = category
        self._description = description
        self._requires_sandbox = requires_sandbox
        self._max_execution_seconds = max_execution_seconds
        self._llm_client = llm_client

    @property
    def name(self) -> str:
        return self._name

    @property
    def category(self) -> SkillCategory:
        return self._category

    @property
    def description(self) -> str:
        return self._description

    @property
    def llm(self) -> LLMClientPort:
        """Acceso al cliente LLM. Lanza error si no esta configurado."""
        if self._llm_client is None:
            raise RuntimeError(
                f"Skill '{self._name}' requires an LLM client but none was provided. "
                "Set KORE_LLM_PROVIDER and KORE_LLM_BASE_URL environment variables."
            )
        return self._llm_client

    @property
    def has_llm(self) -> bool:
        """Indica si hay un LLM client disponible."""
        return self._llm_client is not None

    def set_llm_client(self, client: LLMClientPort) -> None:
        """Inyecta el cliente LLM post-construccion."""
        self._llm_client = client

    def to_domain(self) -> AgentSkill:
        """Convierte a value object del dominio."""
        return AgentSkill(
            name=self._name,
            category=self._category,
            description=self._description,
            requires_sandbox=self._requires_sandbox,
            max_execution_seconds=self._max_execution_seconds,
        )

    @abstractmethod
    async def execute(self, inputs: dict[str, Any], context: dict[str, Any]) -> dict[str, Any]:
        """Ejecuta la skill con los inputs y contexto dados.

        Args:
            inputs: Datos de entrada especificos de la skill.
            context: Contexto de ejecucion (sandbox, metadata, etc.).

        Returns:
            Diccionario con resultados de la ejecucion.
        """
        ...

    async def safe_execute(self, inputs: dict[str, Any], context: dict[str, Any]) -> dict[str, Any]:
        """Ejecuta con logging y manejo de errores."""
        start = time.monotonic()
        logger.info("skill_start name=%s", self._name)
        try:
            result = await self.execute(inputs, context)
            elapsed_ms = (time.monotonic() - start) * 1000
            logger.info("skill_done name=%s elapsed_ms=%.1f", self._name, elapsed_ms)
            result["_meta"] = {"skill": self._name, "duration_ms": round(elapsed_ms, 1)}
            return result
        except Exception as exc:
            elapsed_ms = (time.monotonic() - start) * 1000
            logger.error("skill_error name=%s error=%s elapsed_ms=%.1f", self._name, exc, elapsed_ms)
            return {
                "status": "error",
                "error": str(exc),
                "_meta": {"skill": self._name, "duration_ms": round(elapsed_ms, 1)},
            }

    def __repr__(self) -> str:
        return f"<{type(self).__name__} name={self._name!r} category={self._category.name}>"
