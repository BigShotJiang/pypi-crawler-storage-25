"""Adapters — concrete implementations connecting to external systems."""
