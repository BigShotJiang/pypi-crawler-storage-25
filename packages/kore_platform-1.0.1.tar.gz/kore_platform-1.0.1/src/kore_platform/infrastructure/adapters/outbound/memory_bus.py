"""In-memory message bus — for demos and tests, no external dependencies."""

from __future__ import annotations

import asyncio
import time
from typing import Any, Awaitable, Callable

from ....application.ports.outbound.message_bus import MessageBusPort


class MemoryBus(MessageBusPort):
    """Bus en memoria usando asyncio.Queue y dicts."""

    def __init__(self) -> None:
        self._channels: dict[str, list[Callable[[dict[str, Any]], Awaitable[None]]]] = {}
        self._queues: dict[str, asyncio.Queue[dict[str, Any]]] = {}
        self._cache: dict[str, tuple[Any, float]] = {}
        self._streams: dict[str, list[dict[str, Any]]] = {}

    async def publish(self, channel: str, message: dict[str, Any]) -> None:
        for cb in self._channels.get(channel, []):
            await cb(message)

    async def subscribe(
        self,
        channel: str,
        callback: Callable[[dict[str, Any]], Awaitable[None]],
    ) -> None:
        self._channels.setdefault(channel, []).append(callback)

    async def enqueue(self, queue: str, task: dict[str, Any]) -> None:
        if queue not in self._queues:
            self._queues[queue] = asyncio.Queue()
        await self._queues[queue].put(task)

    async def dequeue(self, queue: str, timeout: float = 0) -> dict[str, Any] | None:
        q = self._queues.get(queue)
        if q is None or q.empty():
            return None
        return q.get_nowait()

    async def cache_set(self, key: str, value: Any, ttl: int | None = None) -> None:
        expires = time.time() + (ttl or 300)
        self._cache[key] = (value, expires)

    async def cache_get(self, key: str) -> Any | None:
        item = self._cache.get(key)
        if item is None:
            return None
        value, expires = item
        if time.time() > expires:
            del self._cache[key]
            return None
        return value

    async def log(self, stream: str, entry: dict[str, Any]) -> None:
        self._streams.setdefault(stream, []).append({"ts": time.time(), **entry})

    async def history(self, stream: str, count: int = 50) -> list[dict[str, Any]]:
        return self._streams.get(stream, [])[-count:]
