"""Anthropic LLM client adapter."""

from __future__ import annotations

import json
import logging
from typing import Any

from ....application.ports.outbound.llm_client import LLMClientPort, LLMMessage, LLMResponse

logger = logging.getLogger(__name__)


class AnthropicClient(LLMClientPort):
    """Cliente Anthropic Claude. Requiere anthropic package."""

    def __init__(self, api_key: str, default_model: str = "claude-sonnet-4-5-20250929") -> None:
        self._api_key = api_key
        self._default_model = default_model
        self._client: Any = None

    def _get_client(self) -> Any:
        if self._client is None:
            try:
                from anthropic import AsyncAnthropic
                self._client = AsyncAnthropic(api_key=self._api_key)
            except ImportError:
                raise ImportError("pip install anthropic")
        return self._client

    async def chat(
        self,
        messages: list[LLMMessage],
        model: str | None = None,
        temperature: float = 0.7,
        max_tokens: int = 4096,
    ) -> LLMResponse:
        client = self._get_client()
        system_msg = ""
        chat_msgs = []
        for m in messages:
            if m.role == "system":
                system_msg += m.content + "\n"
            else:
                chat_msgs.append({"role": m.role, "content": m.content})

        response = await client.messages.create(
            model=model or self._default_model,
            system=system_msg.strip() or None,
            messages=chat_msgs,
            temperature=temperature,
            max_tokens=max_tokens,
        )
        content = response.content[0].text if response.content else ""
        return LLMResponse(
            content=content,
            model=response.model,
            usage={
                "input_tokens": response.usage.input_tokens,
                "output_tokens": response.usage.output_tokens,
            },
            finish_reason=response.stop_reason or "end_turn",
        )

    async def structured_output(
        self,
        messages: list[LLMMessage],
        schema: dict[str, Any],
        model: str | None = None,
    ) -> dict[str, Any]:
        msgs = [*messages, LLMMessage(
            role="user",
            content=f"Respond ONLY with valid JSON matching this schema: {json.dumps(schema)}",
        )]
        response = await self.chat(msgs, model=model, temperature=0.3)
        return json.loads(response.content)
