"""Redis message bus — production implementation."""

from __future__ import annotations

import json
from typing import Any, Awaitable, Callable

try:
    import redis.asyncio as aioredis
except ImportError:
    aioredis = None  # type: ignore[assignment]

from ....application.ports.outbound.message_bus import MessageBusPort


class RedisBus(MessageBusPort):
    """Bus Redis para producción: pub/sub, listas, cache con TTL, streams."""

    def __init__(
        self, host: str = "localhost", port: int = 6379,
        password: str = "", db: int = 0,
    ) -> None:
        if aioredis is None:
            raise ImportError("pip install redis — se necesita redis[asyncio]")
        self._r = aioredis.Redis(
            host=host, port=port, password=password or None,
            db=db, decode_responses=True,
        )
        self._pubsub = self._r.pubsub()

    async def publish(self, channel: str, message: dict[str, Any]) -> None:
        await self._r.publish(channel, json.dumps(message))

    async def subscribe(
        self,
        channel: str,
        callback: Callable[[dict[str, Any]], Awaitable[None]],
    ) -> None:
        async def _wrapper(msg: dict[str, Any]) -> None:
            if msg["type"] == "message":
                await callback(json.loads(msg["data"]))

        await self._pubsub.subscribe(**{channel: _wrapper})

    async def enqueue(self, queue: str, task: dict[str, Any]) -> None:
        await self._r.rpush(f"q:{queue}", json.dumps(task))

    async def dequeue(self, queue: str, timeout: float = 0) -> dict[str, Any] | None:
        if timeout > 0:
            result = await self._r.blpop(f"q:{queue}", timeout=int(timeout))
            return json.loads(result[1]) if result else None
        data = await self._r.lpop(f"q:{queue}")
        return json.loads(data) if data else None

    async def cache_set(self, key: str, value: Any, ttl: int | None = None) -> None:
        await self._r.set(f"c:{key}", json.dumps(value), ex=ttl or 300)

    async def cache_get(self, key: str) -> Any | None:
        data = await self._r.get(f"c:{key}")
        return json.loads(data) if data else None

    async def log(self, stream: str, entry: dict[str, Any]) -> None:
        flat = {k: json.dumps(v) if not isinstance(v, str) else v for k, v in entry.items()}
        await self._r.xadd(f"s:{stream}", flat)

    async def history(self, stream: str, count: int = 50) -> list[dict[str, Any]]:
        raw = await self._r.xrevrange(f"s:{stream}", count=count)
        results = []
        for _id, fields in raw:
            parsed: dict[str, Any] = {}
            for k, v in fields.items():
                try:
                    parsed[k] = json.loads(v)
                except (json.JSONDecodeError, TypeError):
                    parsed[k] = v
            results.append(parsed)
        results.reverse()
        return results

    async def close(self) -> None:
        await self._pubsub.close()
        await self._r.close()
