"""Docker runtime — runs agent tasks in Docker containers."""

from __future__ import annotations

import logging
import uuid
from typing import Any

from ....application.ports.outbound.agent_runtime import AgentRuntimePort

logger = logging.getLogger(__name__)


class DockerRuntime(AgentRuntimePort):
    """Runtime de agentes basado en Docker.

    Usa docker SDK cuando esta disponible. Fallback a stub si Docker no instalado.
    """

    def __init__(
        self,
        image: str = "python:3.12-slim",
        network: str = "none",
        mem_limit: str = "512m",
    ) -> None:
        self._image = image
        self._network = network
        self._mem_limit = mem_limit
        self._sandboxes: dict[str, Any] = {}
        self._docker_client: Any = None
        self._docker_available = False
        self._init_docker()

    def _init_docker(self) -> None:
        """Intenta conectar con Docker daemon."""
        try:
            import docker
            self._docker_client = docker.from_env()
            self._docker_client.ping()
            self._docker_available = True
            logger.info("docker_connected")
        except Exception as exc:
            logger.info("docker_not_available reason=%s (using stub mode)", exc)
            self._docker_available = False

    @property
    def is_available(self) -> bool:
        return self._docker_available

    async def create_sandbox(self, agent_name: str, config: dict[str, Any]) -> str:
        sandbox_id = f"kore-{agent_name}-{uuid.uuid4().hex[:8]}"

        if self._docker_available and self._docker_client is not None:
            container = self._docker_client.containers.run(
                image=config.get("image", self._image),
                name=sandbox_id,
                detach=True,
                network_mode=self._network,
                mem_limit=self._mem_limit,
                read_only=config.get("read_only", False),
                working_dir="/workspace",
                volumes=config.get("volumes", {}),
                command="sleep infinity",
            )
            self._sandboxes[sandbox_id] = {
                "agent": agent_name,
                "status": "running",
                "container": container,
            }
            logger.info("sandbox_created_docker id=%s agent=%s", sandbox_id, agent_name)
        else:
            self._sandboxes[sandbox_id] = {
                "agent": agent_name,
                "status": "running",
                "config": config,
            }
            logger.info("sandbox_created_stub id=%s agent=%s", sandbox_id, agent_name)

        return sandbox_id

    async def execute_in_sandbox(
        self, sandbox_id: str, command: str, timeout: int = 300,
    ) -> dict[str, Any]:
        sandbox = self._sandboxes.get(sandbox_id)
        if sandbox is None:
            return {"status": "error", "error": f"Sandbox {sandbox_id} not found"}

        if self._docker_available and "container" in sandbox:
            container = sandbox["container"]
            exit_code, output = container.exec_run(
                command,
                workdir="/workspace",
                demux=True,
            )
            stdout = output[0].decode("utf-8", errors="replace") if output[0] else ""
            stderr = output[1].decode("utf-8", errors="replace") if output[1] else ""
            logger.info("sandbox_exec id=%s exit_code=%d", sandbox_id, exit_code)
            return {
                "status": "ok" if exit_code == 0 else "error",
                "exit_code": exit_code,
                "stdout": stdout,
                "stderr": stderr,
            }
        else:
            logger.info("sandbox_exec_stub id=%s cmd=%s", sandbox_id, command[:100])
            return {"status": "ok", "sandbox_id": sandbox_id, "output": f"[stub: {command[:50]}]"}

    async def destroy_sandbox(self, sandbox_id: str) -> None:
        sandbox = self._sandboxes.pop(sandbox_id, None)
        if sandbox and self._docker_available and "container" in sandbox:
            try:
                sandbox["container"].stop(timeout=10)
                sandbox["container"].remove(force=True)
            except Exception as exc:
                logger.warning("sandbox_destroy_error id=%s error=%s", sandbox_id, exc)
        logger.info("sandbox_destroyed id=%s", sandbox_id)

    async def list_sandboxes(self) -> list[dict[str, Any]]:
        return [
            {"id": sid, "agent": info.get("agent"), "status": info.get("status")}
            for sid, info in self._sandboxes.items()
        ]
