"""PostgreSQL storage — production implementation (stub, requires asyncpg)."""

from __future__ import annotations

import logging
from typing import Any

from ....application.ports.outbound.storage import StoragePort

logger = logging.getLogger(__name__)


class PostgresStorage(StoragePort):
    """Almacenamiento PostgreSQL. Requiere asyncpg en producción."""

    def __init__(self, dsn: str) -> None:
        self._dsn = dsn
        self._pool: Any = None

    async def connect(self) -> None:
        try:
            import asyncpg
            self._pool = await asyncpg.create_pool(self._dsn)
            logger.info("postgres_connected dsn=%s", self._dsn[:30])
        except ImportError:
            logger.warning("asyncpg not installed — PostgresStorage unavailable")

    async def save(self, collection: str, key: str, data: dict[str, Any]) -> None:
        if self._pool is None:
            raise RuntimeError("Not connected. Call connect() first.")
        import json
        async with self._pool.acquire() as conn:
            await conn.execute(
                """INSERT INTO kore_data (collection, key, data)
                   VALUES ($1, $2, $3)
                   ON CONFLICT (collection, key) DO UPDATE SET data = $3""",
                collection, key, json.dumps(data),
            )

    async def load(self, collection: str, key: str) -> dict[str, Any] | None:
        if self._pool is None:
            return None
        import json
        async with self._pool.acquire() as conn:
            row = await conn.fetchrow(
                "SELECT data FROM kore_data WHERE collection=$1 AND key=$2",
                collection, key,
            )
            return json.loads(row["data"]) if row else None

    async def delete(self, collection: str, key: str) -> None:
        if self._pool is None:
            return
        async with self._pool.acquire() as conn:
            await conn.execute(
                "DELETE FROM kore_data WHERE collection=$1 AND key=$2",
                collection, key,
            )

    async def list_keys(self, collection: str, prefix: str = "") -> list[str]:
        if self._pool is None:
            return []
        async with self._pool.acquire() as conn:
            rows = await conn.fetch(
                "SELECT key FROM kore_data WHERE collection=$1 AND key LIKE $2 ORDER BY key",
                collection, f"{prefix}%",
            )
            return [r["key"] for r in rows]

    async def save_artifact(self, job_id: str, name: str, content: bytes) -> str:
        if self._pool is None:
            raise RuntimeError("Not connected")
        async with self._pool.acquire() as conn:
            await conn.execute(
                """INSERT INTO kore_artifacts (job_id, name, content)
                   VALUES ($1, $2, $3)
                   ON CONFLICT (job_id, name) DO UPDATE SET content = $3""",
                job_id, name, content,
            )
        return f"pg://{job_id}/{name}"

    async def load_artifact(self, job_id: str, name: str) -> bytes | None:
        if self._pool is None:
            return None
        async with self._pool.acquire() as conn:
            row = await conn.fetchrow(
                "SELECT content FROM kore_artifacts WHERE job_id=$1 AND name=$2",
                job_id, name,
            )
            return row["content"] if row else None
