"""Immutable audit log with hash chain — detects tampering automatically."""

from __future__ import annotations

import asyncio
import hashlib
import json
import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from ....application.ports.outbound.audit_log import AuditLogPort

logger = logging.getLogger(__name__)


@dataclass
class ImmutableAuditLog(AuditLogPort):
    """Audit log inmutable con cadena de hashes. Append-only."""

    log_dir: Path
    _locks: dict[str, asyncio.Lock] = field(default_factory=dict, repr=False)

    def __post_init__(self) -> None:
        self.log_dir.mkdir(parents=True, exist_ok=True)

    async def append(
        self,
        job_id: str,
        event_type: str,
        data: dict[str, Any],
        timestamp: datetime | None = None,
    ) -> str:
        if job_id not in self._locks:
            self._locks[job_id] = asyncio.Lock()

        async with self._locks[job_id]:
            log_file = self.log_dir / f"{job_id}.jsonl"
            prev_hash = self._get_last_hash_sync(log_file)

            entry: dict[str, Any] = {
                "timestamp": (timestamp or datetime.now(timezone.utc)).isoformat(),
                "event_type": event_type,
                "data": data,
                "prev_hash": prev_hash,
            }
            entry_hash = self._calculate_hash(entry)
            entry["hash"] = entry_hash

            with open(log_file, "a") as f:
                f.write(json.dumps(entry, sort_keys=True) + "\n")

            logger.debug(
                "audit_entry job_id=%s event=%s hash=%s",
                job_id, event_type, entry_hash[:16],
            )
            return entry_hash

    async def verify_integrity(self, job_id: str) -> bool:
        log_file = self.log_dir / f"{job_id}.jsonl"
        if not log_file.exists():
            return True

        prev_hash = "genesis"
        line_num = 0

        with open(log_file) as f:
            for line in f:
                line_num += 1
                entry = json.loads(line)

                if entry["prev_hash"] != prev_hash:
                    logger.error(
                        "chain_broken job_id=%s line=%d expected=%s actual=%s",
                        job_id, line_num, prev_hash, entry["prev_hash"],
                    )
                    return False

                stored_hash = entry.pop("hash")
                calculated = self._calculate_hash(entry)
                entry["hash"] = stored_hash

                if stored_hash != calculated:
                    logger.error("entry_tampered job_id=%s line=%d", job_id, line_num)
                    return False

                prev_hash = stored_hash

        logger.info("integrity_ok job_id=%s entries=%d", job_id, line_num)
        return True

    async def get_entries(
        self,
        job_id: str,
        from_timestamp: datetime | None = None,
        to_timestamp: datetime | None = None,
    ) -> list[dict[str, Any]]:
        log_file = self.log_dir / f"{job_id}.jsonl"
        if not log_file.exists():
            return []

        entries: list[dict[str, Any]] = []
        with open(log_file) as f:
            for line in f:
                entry = json.loads(line)
                ts = datetime.fromisoformat(entry["timestamp"])
                if from_timestamp and ts < from_timestamp:
                    continue
                if to_timestamp and ts > to_timestamp:
                    continue
                entries.append(entry)
        return entries

    def _get_last_hash_sync(self, log_file: Path) -> str:
        if not log_file.exists():
            return "genesis"
        last_line = ""
        with open(log_file) as f:
            for line in f:
                last_line = line
        if not last_line.strip():
            return "genesis"
        return json.loads(last_line)["hash"]

    @staticmethod
    def _calculate_hash(entry: dict[str, Any]) -> str:
        return hashlib.sha256(
            json.dumps(entry, sort_keys=True).encode(),
        ).hexdigest()
