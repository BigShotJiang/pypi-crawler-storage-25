"""File-based storage — simple filesystem implementation."""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any

from ....application.ports.outbound.storage import StoragePort

logger = logging.getLogger(__name__)


class FileStorage(StoragePort):
    """Almacenamiento basado en filesystem."""

    def __init__(self, base_path: str | Path) -> None:
        self._base = Path(base_path)
        self._base.mkdir(parents=True, exist_ok=True)

    def _collection_path(self, collection: str) -> Path:
        p = self._base / collection
        p.mkdir(parents=True, exist_ok=True)
        return p

    async def save(self, collection: str, key: str, data: dict[str, Any]) -> None:
        path = self._collection_path(collection) / f"{key}.json"
        path.write_text(json.dumps(data, indent=2, default=str))

    async def load(self, collection: str, key: str) -> dict[str, Any] | None:
        path = self._collection_path(collection) / f"{key}.json"
        if not path.exists():
            return None
        return json.loads(path.read_text())

    async def delete(self, collection: str, key: str) -> None:
        path = self._collection_path(collection) / f"{key}.json"
        if path.exists():
            path.unlink()

    async def list_keys(self, collection: str, prefix: str = "") -> list[str]:
        coll_path = self._collection_path(collection)
        return [
            p.stem for p in sorted(coll_path.glob(f"{prefix}*.json"))
        ]

    async def save_artifact(self, job_id: str, name: str, content: bytes) -> str:
        art_dir = self._base / "artifacts" / job_id
        art_dir.mkdir(parents=True, exist_ok=True)
        path = art_dir / name
        path.write_bytes(content)
        return str(path)

    async def load_artifact(self, job_id: str, name: str) -> bytes | None:
        path = self._base / "artifacts" / job_id / name
        if not path.exists():
            return None
        return path.read_bytes()
