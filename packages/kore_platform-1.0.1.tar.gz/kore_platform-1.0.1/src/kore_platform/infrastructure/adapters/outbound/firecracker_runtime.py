"""Firecracker runtime — runs agent tasks in microVMs (stub)."""

from __future__ import annotations

import logging
import uuid
from typing import Any

from ....application.ports.outbound.agent_runtime import AgentRuntimePort

logger = logging.getLogger(__name__)


class FirecrackerRuntime(AgentRuntimePort):
    """Runtime de agentes basado en Firecracker microVMs."""

    def __init__(self, kernel_path: str = "", rootfs_path: str = "") -> None:
        self._kernel = kernel_path
        self._rootfs = rootfs_path
        self._vms: dict[str, dict[str, Any]] = {}

    async def create_sandbox(self, agent_name: str, config: dict[str, Any]) -> str:
        vm_id = f"fc-{agent_name}-{uuid.uuid4().hex[:8]}"
        self._vms[vm_id] = {"agent": agent_name, "status": "running", "config": config}
        logger.info("microvm_created id=%s agent=%s", vm_id, agent_name)
        return vm_id

    async def execute_in_sandbox(
        self, sandbox_id: str, command: str, timeout: int = 300,
    ) -> dict[str, Any]:
        if sandbox_id not in self._vms:
            return {"status": "error", "error": f"VM {sandbox_id} not found"}
        logger.info("microvm_exec id=%s cmd=%s", sandbox_id, command[:100])
        return {"status": "ok", "sandbox_id": sandbox_id, "output": f"[fc-executed: {command[:50]}]"}

    async def destroy_sandbox(self, sandbox_id: str) -> None:
        self._vms.pop(sandbox_id, None)
        logger.info("microvm_destroyed id=%s", sandbox_id)

    async def list_sandboxes(self) -> list[dict[str, Any]]:
        return [{"id": vid, **info} for vid, info in self._vms.items()]
