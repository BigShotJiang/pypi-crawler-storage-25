"""OpenAI LLM client adapter."""

from __future__ import annotations

import json
import logging
from typing import Any

from ....application.ports.outbound.llm_client import LLMClientPort, LLMMessage, LLMResponse

logger = logging.getLogger(__name__)


class OpenAIClient(LLMClientPort):
    """Cliente OpenAI. Requiere openai package."""

    def __init__(self, api_key: str, default_model: str = "gpt-4") -> None:
        self._api_key = api_key
        self._default_model = default_model
        self._client: Any = None

    def _get_client(self) -> Any:
        if self._client is None:
            try:
                from openai import AsyncOpenAI
                self._client = AsyncOpenAI(api_key=self._api_key)
            except ImportError:
                raise ImportError("pip install openai")
        return self._client

    async def chat(
        self,
        messages: list[LLMMessage],
        model: str | None = None,
        temperature: float = 0.7,
        max_tokens: int = 4096,
    ) -> LLMResponse:
        client = self._get_client()
        response = await client.chat.completions.create(
            model=model or self._default_model,
            messages=[{"role": m.role, "content": m.content} for m in messages],
            temperature=temperature,
            max_tokens=max_tokens,
        )
        choice = response.choices[0]
        return LLMResponse(
            content=choice.message.content or "",
            model=response.model,
            usage={
                "prompt_tokens": response.usage.prompt_tokens,
                "completion_tokens": response.usage.completion_tokens,
            },
            finish_reason=choice.finish_reason or "stop",
        )

    async def structured_output(
        self,
        messages: list[LLMMessage],
        schema: dict[str, Any],
        model: str | None = None,
    ) -> dict[str, Any]:
        msgs = [*messages, LLMMessage(
            role="system",
            content=f"Respond ONLY with valid JSON matching: {json.dumps(schema)}",
        )]
        response = await self.chat(msgs, model=model, temperature=0.3)
        return json.loads(response.content)
