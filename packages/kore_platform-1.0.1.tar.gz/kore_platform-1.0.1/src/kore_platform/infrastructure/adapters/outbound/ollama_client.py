"""Ollama LLM client adapter — local/remote models via Ollama API."""

from __future__ import annotations

import json
import logging
from typing import Any

from ....application.ports.outbound.llm_client import LLMClientPort, LLMMessage, LLMResponse

logger = logging.getLogger(__name__)


class OllamaClient(LLMClientPort):
    """Cliente Ollama para modelos locales o remotos.

    Timeout largo (300s) para generacion de codigo con modelos grandes.
    """

    def __init__(
        self,
        base_url: str = "http://localhost:11434",
        default_model: str = "qwen2.5-coder:14b-instruct",
        timeout: int = 300,
    ) -> None:
        self._base_url = base_url.rstrip("/")
        self._default_model = default_model
        self._timeout = timeout

    async def chat(
        self,
        messages: list[LLMMessage],
        model: str | None = None,
        temperature: float = 0.7,
        max_tokens: int = 4096,
    ) -> LLMResponse:
        try:
            import httpx
        except ImportError as exc:
            raise ImportError("pip install httpx — needed for Ollama client") from exc

        used_model = model or self._default_model

        try:
            async with httpx.AsyncClient(timeout=self._timeout) as client:
                response = await client.post(
                    f"{self._base_url}/api/chat",
                    json={
                        "model": used_model,
                        "messages": [{"role": m.role, "content": m.content} for m in messages],
                        "stream": False,
                        "options": {
                            "temperature": temperature,
                            "num_predict": max_tokens,
                            "num_ctx": 8192,
                        },
                    },
                )
                response.raise_for_status()
                data = response.json()
        except httpx.ConnectError as exc:
            raise ConnectionError(
                f"Cannot connect to Ollama at {self._base_url}. "
                "Is the Ollama server running? Set KORE_LLM_BASE_URL to the correct URL."
            ) from exc
        except httpx.TimeoutException as exc:
            raise TimeoutError(
                f"Ollama request timed out after {self._timeout}s. "
                "The model may be too large or the server too slow. "
                "Try a smaller model or increase timeout."
            ) from exc
        except httpx.HTTPStatusError as exc:
            status = exc.response.status_code
            logger.error("ollama_http_error status=%d model=%s", status, used_model)
            raise RuntimeError(
                f"Ollama returned HTTP {status}. "
                "The prompt may exceed the model's context window. "
                "Try reducing input size or using a model with larger context."
            ) from exc

        content = data.get("message", {}).get("content", "")
        if not content:
            logger.warning("ollama_empty_response model=%s", used_model)

        return LLMResponse(
            content=content,
            model=used_model,
            usage={
                "prompt_tokens": data.get("prompt_eval_count", 0),
                "completion_tokens": data.get("eval_count", 0),
            },
        )

    async def structured_output(
        self,
        messages: list[LLMMessage],
        schema: dict[str, Any],
        model: str | None = None,
    ) -> dict[str, Any]:
        msgs = [*messages, LLMMessage(
            role="user",
            content=(
                "IMPORTANT: Respond ONLY with valid JSON. No markdown, no explanations, "
                f"no code blocks. Just pure JSON matching this structure: {json.dumps(schema)}"
            ),
        )]
        response = await self.chat(msgs, model=model, temperature=0.1)
        try:
            return json.loads(response.content)
        except json.JSONDecodeError:
            # Intentar extraer JSON del contenido
            from ....agents.base.llm_utils import extract_json
            return extract_json(response.content)
