"""Inbound adapters — entry points to the application."""
