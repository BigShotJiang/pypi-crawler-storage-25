"""CLI adapter — command-line entry point with progress display."""

from __future__ import annotations

import asyncio
import logging
import sys
from typing import Any

from ....application.dto.job_dto import JobResultDTO

logger = logging.getLogger(__name__)


class CLIAdapter:
    """Adaptador CLI para interaccion por terminal con display de progreso."""

    def __init__(self, execute_job_use_case: Any) -> None:
        self._use_case = execute_job_use_case
        self._responses: dict[str, str] = {}

    async def run(self, idea: str) -> JobResultDTO:
        """Ejecuta un job desde CLI."""
        logger.info("cli_job_start idea=%s", idea[:100])
        return await self._use_case.execute(idea)

    async def get_user_input(self, prompt: str) -> str:
        """Obtiene input del usuario por terminal."""
        return await asyncio.get_event_loop().run_in_executor(
            None, lambda: input(f"\n{prompt}\n> "),
        )

    def display_plan(self, plan: dict[str, Any]) -> None:
        """Muestra plan al usuario."""
        print("\n" + "=" * 60)
        print("  PLAN DE EJECUCION")
        print("=" * 60)
        print(f"\n  Resumen: {plan.get('name', 'N/A')}")
        print(f"  Pasos: {plan.get('step_count', '?')}")
        print(f"  Tiempo estimado: {plan.get('estimated_minutes', '?')} min")
        print("\n  Pasos:")
        for i, step in enumerate(plan.get("steps", []), 1):
            agent = step.get("agent", "?")
            action = step.get("action", "?")
            desc = step.get("description", f"{agent}:{action}")
            print(f"    {i}. [{agent}] {desc}")
        print("=" * 60)

    def display_result(self, result: JobResultDTO) -> None:
        """Muestra resultado al usuario con formato enriquecido."""
        print("\n" + "=" * 60)
        status_icon = {"success": "+", "failed": "X", "cancelled": "!"}.get(result.status, "?")
        print(f"  [{status_icon}] RESULTADO: {result.status.upper()}")
        print("=" * 60)
        if result.message:
            print(f"  {result.message}")
        if result.delivery:
            dtype = result.delivery.get("type", "N/A")
            print(f"  Tipo de entrega: {dtype}")
            workspace = result.delivery.get("metrics", {}).get("workspace")
            if workspace:
                print(f"  Workspace: {workspace}")
            artifacts = result.delivery.get("artifacts", {})
            if artifacts:
                print(f"  Artefactos: {len(artifacts)}")
        if result.errors:
            print("\n  Errores:")
            for err in result.errors:
                print(f"    - {err}")
        print("=" * 60)

    @staticmethod
    def display_step_progress(
        step_num: int,
        total: int,
        agent: str,
        action: str,
        status: str,
    ) -> None:
        """Muestra progreso de un paso individual."""
        icons = {"completed": "+", "failed": "X", "blocked": "!", "running": ">"}
        icon = icons.get(status, "?")
        bar_filled = int((step_num / total) * 20) if total > 0 else 0
        bar = "#" * bar_filled + "-" * (20 - bar_filled)
        sys.stdout.write(f"\r  [{icon}] [{bar}] {step_num}/{total} {agent}:{action} — {status}")
        sys.stdout.flush()
        if status in ("completed", "failed", "blocked"):
            print()  # newline
