"""API REST adapter — HTTP entry point (FastAPI-ready)."""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any

from ....application.dto.job_dto import JobResultDTO, JobStatusDTO

logger = logging.getLogger(__name__)


@dataclass
class APIRequest:
    """Representa una request HTTP."""

    method: str
    path: str
    body: dict[str, Any]
    headers: dict[str, str]


@dataclass
class APIResponse:
    """Representa una response HTTP."""

    status_code: int
    body: dict[str, Any]
    headers: dict[str, str]


class APIAdapter:
    """Adaptador API REST. Diseñado para integrarse con FastAPI/Starlette."""

    def __init__(self, execute_job_use_case: Any) -> None:
        self._use_case = execute_job_use_case
        self._jobs: dict[str, JobStatusDTO] = {}

    async def create_job(self, request: APIRequest) -> APIResponse:
        """POST /api/v1/jobs — crea y ejecuta un job."""
        idea = request.body.get("idea", "")
        if not idea:
            return APIResponse(
                status_code=400,
                body={"error": "Field 'idea' is required"},
                headers={},
            )

        try:
            result = await self._use_case.execute(idea)
            return APIResponse(
                status_code=201,
                body=result.to_dict(),
                headers={"Location": f"/api/v1/jobs/{result.job_id}"},
            )
        except Exception as exc:
            logger.exception("api_job_failed")
            return APIResponse(
                status_code=500,
                body={"error": str(exc)},
                headers={},
            )

    async def get_job_status(self, job_id: str) -> APIResponse:
        """GET /api/v1/jobs/{id} — obtiene estado de un job."""
        status = self._jobs.get(job_id)
        if status is None:
            return APIResponse(status_code=404, body={"error": "Job not found"}, headers={})
        return APIResponse(status_code=200, body={"job_id": job_id, "status": status.status}, headers={})

    async def health(self) -> APIResponse:
        """GET /api/v1/health"""
        return APIResponse(status_code=200, body={"status": "healthy"}, headers={})
