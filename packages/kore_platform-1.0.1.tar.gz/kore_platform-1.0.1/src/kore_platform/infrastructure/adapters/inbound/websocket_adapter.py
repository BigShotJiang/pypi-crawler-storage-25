"""WebSocket adapter — real-time communication entry point."""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from typing import Any, Callable, Awaitable

logger = logging.getLogger(__name__)


@dataclass
class WebSocketAdapter:
    """Adaptador WebSocket para comunicación en tiempo real."""

    _connections: dict[str, Any] = field(default_factory=dict)
    _handlers: dict[str, Callable[..., Awaitable[None]]] = field(default_factory=dict)

    def register_handler(
        self, event_type: str, handler: Callable[..., Awaitable[None]],
    ) -> None:
        """Registra un handler para un tipo de evento."""
        self._handlers[event_type] = handler

    async def on_connect(self, connection_id: str, websocket: Any) -> None:
        """Nuevo cliente conectado."""
        self._connections[connection_id] = websocket
        logger.info("ws_connected id=%s", connection_id)

    async def on_disconnect(self, connection_id: str) -> None:
        """Cliente desconectado."""
        self._connections.pop(connection_id, None)
        logger.info("ws_disconnected id=%s", connection_id)

    async def on_message(self, connection_id: str, raw_message: str) -> None:
        """Mensaje recibido de un cliente."""
        try:
            message = json.loads(raw_message)
        except json.JSONDecodeError:
            await self.send(connection_id, {"error": "Invalid JSON"})
            return

        event_type = message.get("type", "")
        handler = self._handlers.get(event_type)

        if handler:
            await handler(connection_id, message)
        else:
            await self.send(connection_id, {"error": f"Unknown event: {event_type}"})

    async def send(self, connection_id: str, data: dict[str, Any]) -> None:
        """Envía mensaje a un cliente."""
        ws = self._connections.get(connection_id)
        if ws is not None:
            payload = json.dumps(data)
            logger.debug("ws_send id=%s size=%d", connection_id, len(payload))

    async def broadcast(self, data: dict[str, Any]) -> None:
        """Envía mensaje a todos los clientes."""
        for conn_id in list(self._connections):
            await self.send(conn_id, data)
