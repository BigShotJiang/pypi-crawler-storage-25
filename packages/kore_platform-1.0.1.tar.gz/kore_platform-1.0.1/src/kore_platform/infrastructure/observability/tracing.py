"""Distributed tracing with OpenTelemetry."""

from __future__ import annotations

import logging
from contextlib import contextmanager
from dataclasses import dataclass, field
from typing import Any, Generator

logger = logging.getLogger(__name__)


@dataclass
class Span:
    """Representación de un span de tracing."""

    name: str
    trace_id: str = ""
    span_id: str = ""
    parent_id: str = ""
    attributes: dict[str, Any] = field(default_factory=dict)
    status: str = "ok"


@dataclass
class TracingProvider:
    """Provider de tracing. Usa OpenTelemetry si disponible, sino noop."""

    service_name: str = "kore-platform"
    endpoint: str = ""
    _enabled: bool = False

    def setup(self) -> None:
        """Inicializa OpenTelemetry si está disponible."""
        try:
            from opentelemetry import trace
            from opentelemetry.sdk.trace import TracerProvider
            from opentelemetry.sdk.resources import Resource

            resource = Resource.create({"service.name": self.service_name})
            provider = TracerProvider(resource=resource)
            trace.set_tracer_provider(provider)
            self._enabled = True
            logger.info("tracing_enabled service=%s", self.service_name)
        except ImportError:
            logger.info("tracing_disabled — opentelemetry not installed")

    @contextmanager
    def span(self, name: str, attributes: dict[str, Any] | None = None) -> Generator[Span, None, None]:
        """Crea un span de tracing."""
        s = Span(name=name, attributes=attributes or {})
        logger.debug("span_start name=%s", name)
        try:
            yield s
        except Exception as exc:
            s.status = "error"
            s.attributes["error"] = str(exc)
            raise
        finally:
            logger.debug("span_end name=%s status=%s", name, s.status)
