"""Prometheus-compatible metrics collection."""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any


@dataclass
class MetricsCollector:
    """Colector de métricas en formato Prometheus."""

    _counters: dict[str, float] = field(default_factory=dict, repr=False)
    _gauges: dict[str, float] = field(default_factory=dict, repr=False)
    _histograms: dict[str, list[float]] = field(default_factory=dict, repr=False)

    def increment(self, name: str, value: float = 1.0, labels: dict[str, str] | None = None) -> None:
        key = self._key(name, labels)
        self._counters[key] = self._counters.get(key, 0) + value

    def gauge(self, name: str, value: float, labels: dict[str, str] | None = None) -> None:
        key = self._key(name, labels)
        self._gauges[key] = value

    def observe(self, name: str, value: float, labels: dict[str, str] | None = None) -> None:
        key = self._key(name, labels)
        self._histograms.setdefault(key, []).append(value)

    def timer(self, name: str, labels: dict[str, str] | None = None) -> _Timer:
        return _Timer(self, name, labels)

    def export_prometheus(self) -> str:
        """Exporta métricas en formato Prometheus text."""
        lines: list[str] = []
        for key, val in sorted(self._counters.items()):
            lines.append(f"{key} {val}")
        for key, val in sorted(self._gauges.items()):
            lines.append(f"{key} {val}")
        for key, vals in sorted(self._histograms.items()):
            lines.append(f"{key}_count {len(vals)}")
            lines.append(f"{key}_sum {sum(vals):.6f}")
        return "\n".join(lines) + "\n"

    @staticmethod
    def _key(name: str, labels: dict[str, str] | None = None) -> str:
        if not labels:
            return name
        label_str = ",".join(f'{k}="{v}"' for k, v in sorted(labels.items()))
        return f"{name}{{{label_str}}}"


class _Timer:
    def __init__(self, collector: MetricsCollector, name: str, labels: dict[str, str] | None) -> None:
        self._collector = collector
        self._name = name
        self._labels = labels
        self._start = 0.0

    def __enter__(self) -> _Timer:
        self._start = time.perf_counter()
        return self

    def __exit__(self, *args: Any) -> None:
        duration = time.perf_counter() - self._start
        self._collector.observe(self._name, duration, self._labels)
