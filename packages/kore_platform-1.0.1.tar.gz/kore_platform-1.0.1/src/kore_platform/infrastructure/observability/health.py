"""Health checks for all system components."""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable

logger = logging.getLogger(__name__)


@dataclass(frozen=True, slots=True)
class HealthStatus:
    """Estado de salud de un componente."""

    name: str
    healthy: bool
    latency_ms: float = 0.0
    message: str = ""
    details: dict[str, Any] = field(default_factory=dict)


@dataclass
class HealthChecker:
    """Ejecuta health checks de todos los componentes."""

    _checks: dict[str, Callable[[], Awaitable[bool]]] = field(default_factory=dict, repr=False)

    def register(self, name: str, check: Callable[[], Awaitable[bool]]) -> None:
        self._checks[name] = check

    async def check_all(self) -> list[HealthStatus]:
        results: list[HealthStatus] = []
        for name, check in self._checks.items():
            t0 = time.perf_counter()
            try:
                healthy = await check()
                latency = (time.perf_counter() - t0) * 1000
                results.append(HealthStatus(
                    name=name, healthy=healthy, latency_ms=round(latency, 2),
                ))
            except Exception as exc:
                latency = (time.perf_counter() - t0) * 1000
                results.append(HealthStatus(
                    name=name, healthy=False, latency_ms=round(latency, 2),
                    message=str(exc),
                ))
        return results

    async def is_healthy(self) -> bool:
        results = await self.check_all()
        return all(r.healthy for r in results)

    async def to_dict(self) -> dict[str, Any]:
        results = await self.check_all()
        return {
            "status": "healthy" if all(r.healthy for r in results) else "unhealthy",
            "checks": {r.name: {"healthy": r.healthy, "latency_ms": r.latency_ms, "message": r.message} for r in results},
        }
