"""Application settings — immutable once loaded, validated with Pydantic."""

from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
import os

import yaml


_USER_CONFIG_PATH = Path.home() / ".kore" / "config.yaml"

# Mapping from ~/.kore/config.yaml keys to Settings field names
_YAML_KEY_MAP: dict[str, str] = {
    "llm_provider": "llm_provider",
    "llm_model": "llm_model",
    "llm_base_url": "llm_base_url",
    "llm_api_key": "llm_api_key",
    "llm_timeout": "llm_timeout",
    "language": "language",
    "workspace_path": "workspace_base_path",
}


def _load_user_config() -> dict[str, str]:
    """Load user config from ~/.kore/config.yaml if it exists."""
    if not _USER_CONFIG_PATH.is_file():
        return {}
    try:
        with open(_USER_CONFIG_PATH) as f:
            data = yaml.safe_load(f) or {}
        return {_YAML_KEY_MAP[k]: str(v) for k, v in data.items() if k in _YAML_KEY_MAP}
    except Exception:
        return {}


@dataclass(frozen=True)
class Settings:
    """Configuración de la aplicación. Inmutable."""

    # Environment
    environment: str = "development"
    debug: bool = False

    # Security
    signing_key: str = "default-dev-key-change-in-production!!"
    guardian_enabled: bool = True

    # Redis
    redis_host: str = "localhost"
    redis_port: int = 6379
    redis_password: str = ""

    # LLM
    llm_provider: str = "ollama"
    llm_api_key: str = ""
    llm_model: str = "qwen2.5-coder:7b-instruct"
    llm_base_url: str = "http://localhost:11434"
    llm_timeout: int = 600  # seconds — CPU inference can be very slow

    # Storage
    storage_type: str = "file"
    storage_path: str = "/tmp/kore/data"

    # Workspace
    workspace_base_path: str = "/tmp/kore/workspace"

    # Validation loop
    validation_max_retries: int = 3
    validation_timeout: int = 120

    # Docker sandbox
    docker_enabled: bool = False

    # i18n
    language: str = "es"  # "es" or "en", env: KORE_LANG

    # Observability
    log_level: str = "INFO"
    log_json: bool = True
    enable_tracing: bool = False
    otlp_endpoint: str = ""

    @classmethod
    def from_env(cls) -> Settings:
        """Carga settings con prioridad: env vars > ~/.kore/config.yaml > defaults."""
        user_cfg = _load_user_config()

        def _get(env_key: str, field: str, default: str) -> str:
            """Env var wins over user config, which wins over default."""
            env_val = os.getenv(env_key)
            if env_val is not None:
                return env_val
            return user_cfg.get(field, default)

        return cls(
            environment=os.getenv("KORE_ENVIRONMENT", "development"),
            debug=os.getenv("KORE_DEBUG", "").lower() in ("1", "true"),
            signing_key=os.getenv("KORE_SIGNING_KEY", cls.signing_key),
            guardian_enabled=os.getenv("KORE_GUARDIAN_ENABLED", "true").lower() != "false",
            redis_host=os.getenv("KORE_REDIS_HOST", "localhost"),
            redis_port=int(os.getenv("KORE_REDIS_PORT", "6379")),
            redis_password=os.getenv("KORE_REDIS_PASSWORD", ""),
            llm_provider=_get("KORE_LLM_PROVIDER", "llm_provider", "ollama"),
            llm_api_key=_get("KORE_LLM_API_KEY", "llm_api_key", ""),
            llm_model=_get("KORE_LLM_MODEL", "llm_model", cls.llm_model),
            llm_base_url=_get("KORE_LLM_BASE_URL", "llm_base_url", "http://localhost:11434"),
            llm_timeout=int(_get("KORE_LLM_TIMEOUT", "llm_timeout", "600")),
            storage_type=os.getenv("KORE_STORAGE_TYPE", "file"),
            storage_path=os.getenv("KORE_STORAGE_PATH", "/tmp/kore/data"),
            workspace_base_path=_get(
                "KORE_WORKSPACE_PATH", "workspace_base_path", "/tmp/kore/workspace"
            ),
            validation_max_retries=int(os.getenv("KORE_VALIDATION_MAX_RETRIES", "3")),
            validation_timeout=int(os.getenv("KORE_VALIDATION_TIMEOUT", "120")),
            language=_get("KORE_LANG", "language", "es"),
            docker_enabled=os.getenv("KORE_DOCKER_ENABLED", "").lower() in ("1", "true"),
            log_level=os.getenv("KORE_LOG_LEVEL", "INFO"),
            log_json=os.getenv("KORE_LOG_JSON", "true").lower() != "false",
            enable_tracing=os.getenv("KORE_ENABLE_TRACING", "").lower() in ("1", "true"),
            otlp_endpoint=os.getenv("KORE_OTLP_ENDPOINT", ""),
        )


@lru_cache()
def get_settings() -> Settings:
    return Settings.from_env()
