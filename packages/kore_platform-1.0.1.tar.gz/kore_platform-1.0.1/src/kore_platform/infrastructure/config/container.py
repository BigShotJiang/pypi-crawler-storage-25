"""Dependency injection container — wires everything together."""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any

from .settings import Settings, get_settings
from ..adapters.outbound.memory_bus import MemoryBus
from ..adapters.outbound.immutable_audit_log import ImmutableAuditLog
from ..adapters.outbound.file_storage import FileStorage
from ..adapters.outbound.docker_runtime import DockerRuntime
from ..security.guardian import Guardian
from ..security.signature_verifier import SignatureVerifier
from ..security.sandbox_manager import SandboxManager
from ..security.secret_manager import SecretManager
from ..observability.logging import setup_logging
from ..observability.metrics import MetricsCollector
from ..observability.health import HealthChecker
from ...application.ports.outbound.message_bus import MessageBusPort
from ...application.ports.outbound.audit_log import AuditLogPort
from ...application.ports.outbound.storage import StoragePort
from ...application.ports.outbound.llm_client import LLMClientPort
from ..workspace.workspace_manager import WorkspaceManager

if TYPE_CHECKING:
    from ...agents.base.agent import BaseAgent

logger = logging.getLogger(__name__)


@dataclass
class Container:
    """Contenedor de dependencias. Configura todo el sistema."""

    settings: Settings = field(default_factory=get_settings)

    # Initialized lazily
    _bus: MessageBusPort | None = field(default=None, repr=False)
    _audit_log: AuditLogPort | None = field(default=None, repr=False)
    _storage: StoragePort | None = field(default=None, repr=False)
    _guardian: Guardian | None = field(default=None, repr=False)
    _metrics: MetricsCollector | None = field(default=None, repr=False)
    _health: HealthChecker | None = field(default=None, repr=False)
    _llm_client: LLMClientPort | None = field(default=None, repr=False)
    _agent_registry: dict[str, BaseAgent] | None = field(default=None, repr=False)
    _workspace_manager: WorkspaceManager | None = field(default=None, repr=False)

    def setup(self) -> None:
        """Inicializa todos los componentes."""
        setup_logging(
            level=self.settings.log_level,
            json_output=self.settings.log_json,
        )
        logger.info(
            "container_setup env=%s", self.settings.environment,
        )

    @property
    def bus(self) -> MessageBusPort:
        if self._bus is None:
            if self.settings.environment == "development":
                self._bus = MemoryBus()
            else:
                from ..adapters.outbound.redis_bus import RedisBus
                self._bus = RedisBus(
                    host=self.settings.redis_host,
                    port=self.settings.redis_port,
                    password=self.settings.redis_password,
                )
        return self._bus

    @property
    def audit_log(self) -> AuditLogPort:
        if self._audit_log is None:
            self._audit_log = ImmutableAuditLog(
                log_dir=Path(self.settings.storage_path) / "audit",
            )
        return self._audit_log

    @property
    def storage(self) -> StoragePort:
        if self._storage is None:
            self._storage = FileStorage(
                base_path=Path(self.settings.storage_path) / "storage",
            )
        return self._storage

    @property
    def guardian(self) -> Guardian:
        if self._guardian is None:
            self._guardian = Guardian()
        return self._guardian

    @property
    def signature_verifier(self) -> SignatureVerifier:
        return SignatureVerifier(signing_key=self.settings.signing_key.encode())

    @property
    def secret_manager(self) -> SecretManager:
        return SecretManager()

    @property
    def metrics(self) -> MetricsCollector:
        if self._metrics is None:
            self._metrics = MetricsCollector()
        return self._metrics

    @property
    def health(self) -> HealthChecker:
        if self._health is None:
            self._health = HealthChecker()
        return self._health

    @property
    def workspace_manager(self) -> WorkspaceManager:
        """WorkspaceManager para output de archivos generados."""
        if self._workspace_manager is None:
            self._workspace_manager = WorkspaceManager(
                base_path=self.settings.workspace_base_path,
            )
        return self._workspace_manager

    @property
    def llm_client(self) -> LLMClientPort:
        """Factory que crea el LLM client correcto segun llm_provider."""
        if self._llm_client is None:
            provider = self.settings.llm_provider.lower()
            if provider == "ollama":
                from ..adapters.outbound.ollama_client import OllamaClient
                self._llm_client = OllamaClient(
                    base_url=self.settings.llm_base_url,
                    default_model=self.settings.llm_model,
                    timeout=self.settings.llm_timeout,
                )
            elif provider == "anthropic":
                from ..adapters.outbound.anthropic_client import AnthropicClient
                self._llm_client = AnthropicClient(
                    api_key=self.settings.llm_api_key,
                    default_model=self.settings.llm_model,
                )
            elif provider == "openai":
                from ..adapters.outbound.openai_client import OpenAIClient
                self._llm_client = OpenAIClient(
                    api_key=self.settings.llm_api_key,
                    default_model=self.settings.llm_model,
                )
            else:
                raise ValueError(
                    f"Unknown LLM provider: {provider}. "
                    "Use KORE_LLM_PROVIDER=ollama|anthropic|openai"
                )
            logger.info("llm_client_created provider=%s model=%s", provider, self.settings.llm_model)
        return self._llm_client

    @property
    def agent_registry(self) -> dict[str, BaseAgent]:
        """Registry de todos los agentes, con LLM client inyectado."""
        if self._agent_registry is None:
            from ...agents.specs.agent import SpecsAgent
            from ...agents.architect.agent import ArchitectAgent
            from ...agents.coder.agent import CoderAgent
            from ...agents.tester.agent import TesterAgent
            from ...agents.reviewer.agent import ReviewerAgent
            from ...agents.security.agent import SecurityAgent
            from ...agents.deployer.agent import DeployerAgent
            from ...agents.documenter.agent import DocumenterAgent
            from ...agents.monitor.agent import MonitorAgent
            from ...agents.complexity.agent import ComplexityAgent

            llm = self.llm_client
            bus = self.bus
            guardian = self.guardian

            self._agent_registry = {}
            for agent_cls in [
                SpecsAgent, ArchitectAgent, CoderAgent, TesterAgent,
                ReviewerAgent, SecurityAgent, DeployerAgent, DocumenterAgent,
                MonitorAgent,
            ]:
                agent = agent_cls(bus=bus, guardian=guardian, llm_client=llm)
                self._agent_registry[agent.name] = agent

            # ComplexityAgent does NOT use LLM — register without llm_client
            complexity = ComplexityAgent(bus=bus, guardian=guardian)
            self._agent_registry[complexity.name] = complexity

            logger.info(
                "agent_registry_created agents=%s",
                list(self._agent_registry.keys()),
            )
        return self._agent_registry
