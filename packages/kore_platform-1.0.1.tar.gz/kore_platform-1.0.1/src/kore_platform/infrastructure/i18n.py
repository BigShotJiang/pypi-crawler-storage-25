"""Internationalization — simple locale-based string lookup.

Supports Spanish (es) and English (en). Default: Spanish.
System agent prompts stay in English (LLM works best that way).
Only user-facing text (interview, CLI, web) is translated.
"""

from __future__ import annotations

import locale
import os
import logging
from typing import Any

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Supported locales
# ---------------------------------------------------------------------------

_SUPPORTED = {"es", "en"}
_DEFAULT = "es"

# Detected once at import
_current_locale: str = _DEFAULT


def _detect_locale() -> str:
    """Detect locale from KORE_LANG env var, or system locale."""
    env_lang = os.environ.get("KORE_LANG", "").lower().strip()
    if env_lang in _SUPPORTED:
        return env_lang

    try:
        sys_locale = locale.getdefaultlocale()[0] or ""
        lang = sys_locale.split("_")[0].lower()
        if lang in _SUPPORTED:
            return lang
    except Exception:
        pass

    return _DEFAULT


_current_locale = _detect_locale()


def get_locale() -> str:
    """Return current locale code ('es' or 'en')."""
    return _current_locale


def set_locale(lang: str) -> None:
    """Override the current locale."""
    global _current_locale
    if lang in _SUPPORTED:
        _current_locale = lang
        logger.info("locale_set lang=%s", lang)
    else:
        logger.warning("unsupported_locale lang=%s, keeping %s", lang, _current_locale)


# ---------------------------------------------------------------------------
# Translation catalog
# ---------------------------------------------------------------------------

_CATALOG: dict[str, dict[str, str]] = {
    # CLI / main
    "header": {
        "es": "KORE PLATFORM — Generacion de Software con IA",
        "en": "KORE PLATFORM — AI-Powered Software Generation",
    },
    "llm_provider": {
        "es": "Proveedor LLM",
        "en": "LLM Provider",
    },
    "llm_model": {
        "es": "Modelo LLM",
        "en": "LLM Model",
    },
    "workspace": {
        "es": "Espacio de trabajo",
        "en": "Workspace",
    },
    "idea_label": {
        "es": "Idea",
        "en": "Idea",
    },
    "starting_pipeline": {
        "es": "Iniciando pipeline...",
        "en": "Starting pipeline...",
    },
    "pipeline_failed": {
        "es": "PIPELINE FALLIDO despues de {elapsed:.1f}s",
        "en": "PIPELINE FAILED after {elapsed:.1f}s",
    },
    "result_label": {
        "es": "RESULTADO",
        "en": "RESULT",
    },
    "delivery_type": {
        "es": "Tipo de entrega",
        "en": "Delivery type",
    },
    "total_time": {
        "es": "Tiempo total",
        "en": "Total time",
    },
    "generated_files": {
        "es": "Archivos generados ({count})",
        "en": "Generated files ({count})",
    },
    "usage": {
        "es": ("  Uso: kore 'Tu idea de proyecto aqui'\n"
               "       kore --auto 'idea'  (sin preguntas, LLM responde todo)\n"
               "       kore --ui           (interfaz web)\n"
               "  Ejemplo: kore 'API REST de TODO con FastAPI'"),
        "en": ("  Usage: kore 'Your project idea here'\n"
               "         kore --auto 'idea'  (no questions, LLM answers everything)\n"
               "         kore --ui           (launch web interface)\n"
               "  Example: kore 'Build a REST API for TODO items with FastAPI'"),
    },
    "ollama_ok": {
        "es": "Ollama OK — {count} modelos disponibles",
        "en": "Ollama OK — {count} models available",
    },
    "ollama_error": {
        "es": "ERROR: No se puede conectar a Ollama en {url}",
        "en": "ERROR: Cannot connect to Ollama at {url}",
    },
    "ollama_hint": {
        "es": "Asegurate de que Ollama esta corriendo: ollama serve",
        "en": "Ensure Ollama is running: ollama serve",
    },

    # Interview questions — NO_DEV
    "q_problem_nodev": {
        "es": "Explicame que problema quieres resolver, en tus propias palabras",
        "en": "Tell me what problem you want to solve, in your own words",
    },
    "q_target_users_nodev": {
        "es": "Quienes usaran esto? (clientes, empleados, publico general)",
        "en": "Who will use this? (customers, employees, general public)",
    },
    "q_business_reqs_nodev": {
        "es": "Que es lo mas importante que debe hacer la aplicacion?",
        "en": "What is the most important thing the application must do?",
    },
    "q_look_and_feel": {
        "es": "Como te imaginas la aplicacion? (simple, moderna, profesional)",
        "en": "How do you imagine the application? (simple, modern, professional)",
    },

    # Interview questions — base
    "q_problem": {
        "es": "Describe el problema que quieres resolver",
        "en": "Describe the problem you want to solve",
    },
    "q_target_users": {
        "es": "Quienes seran los usuarios principales?",
        "en": "Who will be the main users?",
    },
    "q_business_reqs": {
        "es": "Cuales son los requisitos de negocio clave?",
        "en": "What are the key business requirements?",
    },

    # Interview questions — junior
    "q_stack_junior": {
        "es": "Que lenguajes o frameworks te gustaria usar?",
        "en": "What languages or frameworks would you like to use?",
    },
    "q_deployment_junior": {
        "es": "Donde quieres desplegar (heroku, vercel, vps)?",
        "en": "Where do you want to deploy (heroku, vercel, vps)?",
    },

    # Interview questions — senior
    "q_stack_senior": {
        "es": "Que stack tecnico prefieres (lenguaje, framework, DB)?",
        "en": "What tech stack do you prefer (language, framework, DB)?",
    },
    "q_architecture_senior": {
        "es": "Que patron de arquitectura quieres (monolito, microservicios, serverless)?",
        "en": "What architecture pattern do you want (monolith, microservices, serverless)?",
    },
    "q_deployment_senior": {
        "es": "Target de despliegue (Docker, K8s, serverless)?",
        "en": "Deployment target (Docker, K8s, serverless)?",
    },
    "q_technical_reqs_senior": {
        "es": "Requisitos tecnicos no funcionales (latencia, throughput, SLA)?",
        "en": "Non-functional technical requirements (latency, throughput, SLA)?",
    },

    # Interview questions — engineer
    "q_stack_engineer": {
        "es": "Stack tecnico preferido (lenguaje, framework, DB, message broker)?",
        "en": "Preferred tech stack (language, framework, DB, message broker)?",
    },
    "q_architecture_engineer": {
        "es": "Patron de arquitectura (hexagonal, CQRS, event-driven, microservices)?",
        "en": "Architecture pattern (hexagonal, CQRS, event-driven, microservices)?",
    },
    "q_deployment_engineer": {
        "es": "Infra target (K8s cluster, cloud provider, IaC tool)?",
        "en": "Infra target (K8s cluster, cloud provider, IaC tool)?",
    },
    "q_technical_reqs_engineer": {
        "es": "NFRs criticos (latencia p99, throughput, availability SLA)?",
        "en": "Critical NFRs (p99 latency, throughput, availability SLA)?",
    },
    "q_security_reqs": {
        "es": "Requisitos de seguridad (auth, encryption, compliance)?",
        "en": "Security requirements (auth, encryption, compliance)?",
    },
    "q_observability": {
        "es": "Que nivel de observabilidad necesitas (logs, metrics, traces, dashboards)?",
        "en": "What observability level do you need (logs, metrics, traces, dashboards)?",
    },
    "q_ci_cd": {
        "es": "Pipeline CI/CD preferido (GitHub Actions, GitLab CI, ArgoCD)?",
        "en": "Preferred CI/CD pipeline (GitHub Actions, GitLab CI, ArgoCD)?",
    },

    # Web UI
    "web_title": {
        "es": "KORE Platform",
        "en": "KORE Platform",
    },
    "web_subtitle": {
        "es": "Generador de proyectos con IA",
        "en": "AI-powered project generator",
    },
    "web_placeholder": {
        "es": "Describe tu idea de proyecto...",
        "en": "Describe your project idea...",
    },
    "web_generate": {
        "es": "Generar Proyecto",
        "en": "Generate Project",
    },
    "web_warning": {
        "es": "Nota: KORE auto-genera contexto via LLM. No simula entrada de usuario real.",
        "en": "Note: KORE auto-generates context via LLM. It does not simulate real user input.",
    },

    # Validation loop
    "validation_success": {
        "es": "Validacion exitosa en intento {attempt}",
        "en": "Validation succeeded on attempt {attempt}",
    },
    "validation_failed": {
        "es": "Validacion fallida despues de {max} intentos",
        "en": "Validation failed after {max} attempts",
    },
}


def t(key: str, **kwargs: Any) -> str:
    """Translate a key to the current locale.

    Parameters
    ----------
    key:
        Translation key (e.g. "header", "q_problem").
    **kwargs:
        Format arguments for the translated string.

    Returns
    -------
    str
        Translated string, or key itself if not found.
    """
    entry = _CATALOG.get(key)
    if entry is None:
        return key

    text = entry.get(_current_locale, entry.get(_DEFAULT, key))

    if kwargs:
        try:
            return text.format(**kwargs)
        except (KeyError, IndexError):
            return text

    return text
