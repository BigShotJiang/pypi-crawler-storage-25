"""Cryptographic signature verifier for YAML flows."""

from __future__ import annotations

import hashlib
import hmac
import logging
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml

from ...domain.exceptions.security import SignatureVerificationError

logger = logging.getLogger(__name__)


@dataclass(frozen=True, slots=True)
class SignatureVerifier:
    """Verificador de firmas criptográficas. Inmutable."""

    signing_key: bytes

    def verify_and_load(self, config_path: Path) -> dict[str, Any]:
        """Verifica firma y carga configuración."""
        sig_path = config_path.parent / "signatures" / f"{config_path.name}.sig"

        if not sig_path.exists():
            logger.warning("no_signature path=%s — loading unsigned", config_path)
            with open(config_path) as f:
                return yaml.safe_load(f)

        content = config_path.read_bytes()
        expected_sig = sig_path.read_text().strip()

        actual_sig = hmac.new(self.signing_key, content, hashlib.sha256).hexdigest()

        if not hmac.compare_digest(actual_sig, expected_sig):
            raise SignatureVerificationError(f"Invalid signature: {config_path}")

        logger.info("signature_verified path=%s", config_path)
        return yaml.safe_load(content)

    @classmethod
    def sign_file(cls, config_path: Path, signing_key: bytes) -> Path:
        """Firma un archivo. Solo para build time."""
        content = config_path.read_bytes()
        sig = hmac.new(signing_key, content, hashlib.sha256).hexdigest()

        sig_dir = config_path.parent / "signatures"
        sig_dir.mkdir(parents=True, exist_ok=True)
        sig_path = sig_dir / f"{config_path.name}.sig"
        sig_path.write_text(sig)

        logger.info("file_signed path=%s sig=%s", config_path, sig_path)
        return sig_path
