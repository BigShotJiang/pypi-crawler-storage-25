"""Sandbox manager — creates and monitors agent sandboxes."""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any

from ...application.ports.outbound.agent_runtime import AgentRuntimePort

logger = logging.getLogger(__name__)


@dataclass
class SandboxManager:
    """Gestiona sandboxes para agentes. Enforce least privilege."""

    runtime: AgentRuntimePort
    _active: dict[str, dict[str, Any]] = field(default_factory=dict, repr=False)

    async def create(
        self, agent_name: str, permissions: dict[str, Any] | None = None,
    ) -> str:
        """Crea sandbox con permisos mínimos."""
        config = {
            "network": False,
            "read_only_root": True,
            "max_memory_mb": 512,
            "max_cpu_seconds": 300,
            "allowed_paths": ["/workspace"],
            **(permissions or {}),
        }

        sandbox_id = await self.runtime.create_sandbox(agent_name, config)
        self._active[sandbox_id] = {"agent": agent_name, "config": config}

        logger.info("sandbox_created id=%s agent=%s", sandbox_id, agent_name)
        return sandbox_id

    async def execute(self, sandbox_id: str, command: str, timeout: int = 300) -> dict[str, Any]:
        """Ejecuta comando en sandbox."""
        if sandbox_id not in self._active:
            return {"status": "error", "error": "Sandbox not found"}
        return await self.runtime.execute_in_sandbox(sandbox_id, command, timeout)

    async def destroy(self, sandbox_id: str) -> None:
        """Destruye sandbox."""
        await self.runtime.destroy_sandbox(sandbox_id)
        self._active.pop(sandbox_id, None)
        logger.info("sandbox_destroyed id=%s", sandbox_id)

    async def destroy_all(self) -> int:
        """Destruye todos los sandboxes activos."""
        count = len(self._active)
        for sid in list(self._active):
            await self.destroy(sid)
        return count
