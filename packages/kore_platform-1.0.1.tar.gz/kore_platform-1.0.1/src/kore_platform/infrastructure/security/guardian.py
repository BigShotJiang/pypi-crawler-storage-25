"""AEGIS Guardian — validates ALL actions before execution. Zero trust.

Defense-in-depth strategy:
- Layer 1: Pattern matching on generated code (this module)
- Layer 2: Resource limits via setrlimit (subprocess_runner)
- Layer 3: Filesystem isolation (symlink detection, path resolution)
- Layer 4: Optional container sandbox (bubblewrap/nsjail)

IMPORTANT: Pattern matching is a COMPLEMENTARY layer, never the sole defense.
All generated code MUST run with resource limits at minimum.

Threat Model
============
Adversary 1 — Malicious prompt injection (high likelihood)
    A user crafts an idea that causes the LLM to emit dangerous code
    (e.g. ``eval(input())``, ``os.system('rm -rf /')``, obfuscated payloads).
    Mitigations: pattern matching + obfuscation regex (this module),
    subprocess resource limits, filesystem path restriction.

Adversary 2 — Hostile LLM output (medium likelihood)
    Even without malicious intent from the user, the LLM may hallucinate
    dangerous constructs (network calls, exec chains, infinite loops).
    Mitigations: same as Adversary 1; additionally, trivial-test detection
    in ValidationLoop to prevent silent pass-through.

Adversary 3 — Supply-chain via pip install (medium likelihood)
    A generated requirements.txt could reference a typosquatted or
    malicious package whose setup.py executes arbitrary code.
    Mitigations: ``--only-binary :all:`` in pip install (falls back to
    sdist with warning when no wheel exists), generated requirements
    limited to a known allowlist of common packages.

Adversary 4 — Path traversal / symlink escape (low likelihood)
    Generated file paths like ``../../etc/cron.d/backdoor`` or symlink
    targets outside the workspace.
    Mitigations: ``check_symlink_escape()`` resolves all paths before
    write; workspace manager restricts writes to project directory.

Adversary 5 — Denial of service via resource exhaustion (medium likelihood)
    Generated code containing infinite loops, fork bombs, or allocations.
    Mitigations: ``resource.setrlimit`` in SubprocessRunner (CPU time,
    memory, file descriptors, process count), timeout on all subprocess
    calls.

Known Gaps (documented, not yet mitigated):
- No container-level sandbox (bubblewrap/nsjail) — planned in roadmap.
- Pattern matching is bypassable by sufficiently creative obfuscation.
- pip sdist fallback still executes setup.py (logged as warning).
"""

from __future__ import annotations

import logging
import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from ...domain.exceptions.security import SecurityError

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Allowed commands whitelist (strict)
# ---------------------------------------------------------------------------

_ALLOWED_COMMANDS: frozenset[str] = frozenset({
    "python", "python3", "pip", "pip3",
    "git", "npm", "node", "npx",
    "docker", "pytest", "ruff", "black", "mypy",
})

# ---------------------------------------------------------------------------
# Allowed paths
# ---------------------------------------------------------------------------

_ALLOWED_PATHS: frozenset[str] = frozenset({
    "/workspace/", "/tmp/kore/", "/home/kore/",
})

# ---------------------------------------------------------------------------
# Dangerous patterns — comprehensive list
# Includes all known code execution vectors in Python
# ---------------------------------------------------------------------------

_DANGEROUS_PATTERNS: frozenset[str] = frozenset({
    # Shell destruction
    "rm -rf /", "rm -rf ~", "rm -rf *",
    "sudo ", "chmod 777", "chown ",
    # Pipe to shell
    "curl | bash", "curl | sh", "wget | bash", "wget | sh",
    # Python code execution
    "eval(", "exec(", "__import__",
    "os.system", "os.popen", "os.exec",
    "subprocess.call", "subprocess.run", "subprocess.popen",
    "subprocess.check_output", "subprocess.check_call",
    "subprocess.getoutput", "subprocess.getstatusoutput",
    # Dynamic import / reflection attacks
    "importlib.import_module", "importlib.reload",
    "__builtins__", "__subclasses__",
    "getattr(os", "getattr(sys", "getattr(subprocess",
    # Dangerous serialization
    "pickle.loads", "pickle.load(",
    "marshal.loads", "marshal.load(",
    "yaml.load(", "yaml.unsafe_load",
    "shelve.open",
    # Code compilation / interpretation
    "compile(", "code.interact",
    "code.interactiveconsole",
    # Native code execution
    "ctypes.", "ctypes.cdll", "ctypes.windll",
    "cffi.", "ffi.dlopen",
    # Network access from generated code
    "socket.socket", "socket.connect",
    "urllib.request.urlopen",
    "http.client.httpconnection",
    # File system attacks
    "os.symlink", "os.link(", "os.rename(",
    "shutil.rmtree", "shutil.move",
    "pathlib.path.unlink", "pathlib.path.rmdir",
    # SQL injection
    "drop table", "drop database", "truncate table",
    "delete from", "; --",
    # Signal/process manipulation
    "os.kill", "os.killpg", "signal.signal",
    "os.fork", "os.spawn",
    # Environment manipulation
    "os.environ[", "os.putenv",
})

# ---------------------------------------------------------------------------
# Regex patterns for obfuscation detection
# Catches: getattr(os, 'sys'+'tem'), __import__('o'+'s'), base64, etc.
# ---------------------------------------------------------------------------

_OBFUSCATION_PATTERNS: list[re.Pattern[str]] = [
    # String concatenation to build dangerous names
    re.compile(r"""getattr\s*\(.*,\s*['"][^'"]*['"]\s*\+""", re.IGNORECASE),
    re.compile(r"""__import__\s*\(\s*['"][^'"]*['"]\s*\+""", re.IGNORECASE),
    # Base64 decode execution
    re.compile(r"""base64\s*\.\s*b64decode""", re.IGNORECASE),
    re.compile(r"""codecs\s*\.\s*decode\s*\(.*,\s*['"]rot""", re.IGNORECASE),
    # Dynamic attribute access on dangerous modules
    re.compile(r"""getattr\s*\(\s*(os|sys|subprocess|shutil|importlib|ctypes|pickle|marshal)""", re.IGNORECASE),
    # eval/exec with encoding
    re.compile(r"""(eval|exec)\s*\(\s*.*\.(decode|encode)\s*\(""", re.IGNORECASE),
    # chr() concatenation to build strings
    re.compile(r"""chr\s*\(\s*\d+\s*\)\s*\+\s*chr""", re.IGNORECASE),
    # bytes().decode() for string construction
    re.compile(r"""bytes\s*\(\s*\[.*\]\s*\)\s*\.\s*decode""", re.IGNORECASE),
    # Infinite loops
    re.compile(r"""while\s+True\s*:\s*pass""", re.IGNORECASE),
    re.compile(r"""while\s+1\s*:\s*pass""", re.IGNORECASE),
    # Fork bombs
    re.compile(r"""os\s*\.\s*fork\s*\(""", re.IGNORECASE),
    # Recursive file operations outside workspace
    re.compile(r"""open\s*\(\s*['"]/etc/""", re.IGNORECASE),
    re.compile(r"""open\s*\(\s*['"]/proc/""", re.IGNORECASE),
    re.compile(r"""open\s*\(\s*['"]/sys/""", re.IGNORECASE),
    re.compile(r"""open\s*\(\s*['"]~""", re.IGNORECASE),
]


@dataclass(frozen=True, slots=True)
class GuardianResult:
    """Resultado de validacion. Inmutable."""

    allowed: bool
    reason: str = ""
    command: str = ""


@dataclass
class Guardian:
    """Guardian de seguridad. Valida TODAS las acciones.

    IMPORTANT: This is a defense-in-depth layer. It is NOT a sandbox.
    Pattern matching can be evaded. Always combine with:
    - Resource limits (setrlimit) in SubprocessRunner
    - Filesystem isolation (resolve symlinks, restrict paths)
    - Optionally: container-based sandboxing (bubblewrap/nsjail)
    """

    allowed_commands: frozenset[str] = _ALLOWED_COMMANDS
    allowed_paths: frozenset[str] = _ALLOWED_PATHS
    dangerous_patterns: frozenset[str] = _DANGEROUS_PATTERNS
    audit_log: list[dict[str, Any]] = field(default_factory=list, repr=False)

    def validate_command(self, command: str) -> GuardianResult:
        """Valida un comando antes de ejecutar."""
        cmd_lower = command.lower()

        for pattern in self.dangerous_patterns:
            if pattern in cmd_lower:
                result = GuardianResult(
                    allowed=False,
                    reason=f"Dangerous pattern: {pattern}",
                    command=command[:100],
                )
                self._audit("BLOCKED", result)
                return result

        first_word = command.split()[0] if command.split() else ""
        base = first_word.rsplit("/", 1)[-1]
        if base and base not in self.allowed_commands:
            result = GuardianResult(
                allowed=False,
                reason=f"Command not whitelisted: {base}",
                command=command[:100],
            )
            self._audit("BLOCKED", result)
            return result

        result = GuardianResult(allowed=True, command=command[:100])
        self._audit("ALLOWED", result)
        return result

    def validate_path(self, path: str) -> GuardianResult:
        """Valida acceso a un path. Resuelve symlinks para evitar escape."""
        # Resolver symlinks ANTES de validar
        try:
            resolved = str(Path(path).resolve())
        except (OSError, ValueError):
            resolved = path

        for allowed in self.allowed_paths:
            if resolved.startswith(allowed):
                return GuardianResult(allowed=True, command=resolved)

        result = GuardianResult(
            allowed=False,
            reason=f"Path not allowed (resolved: {resolved})",
            command=path,
        )
        self._audit("PATH_BLOCKED", result)
        return result

    def validate_agent_action(
        self, agent_name: str, action: str, inputs: dict[str, Any],
    ) -> GuardianResult:
        """Valida accion de un agente contra patrones peligrosos y ofuscacion."""
        inputs_str = str(inputs).lower()

        # Layer 1: Direct pattern matching
        for pattern in self.dangerous_patterns:
            if pattern in inputs_str:
                result = GuardianResult(
                    allowed=False,
                    reason=f"Input contains dangerous pattern: {pattern}",
                    command=f"{agent_name}:{action}",
                )
                self._audit("AGENT_BLOCKED", result)
                return result

        # Layer 2: Obfuscation detection via regex
        inputs_full = str(inputs)
        for regex in _OBFUSCATION_PATTERNS:
            if regex.search(inputs_full):
                result = GuardianResult(
                    allowed=False,
                    reason=f"Input contains obfuscation pattern: {regex.pattern[:60]}",
                    command=f"{agent_name}:{action}",
                )
                self._audit("AGENT_BLOCKED_OBFUSCATION", result)
                return result

        return GuardianResult(allowed=True, command=f"{agent_name}:{action}")

    def scan_generated_code(self, code: str, file_path: str = "") -> GuardianResult:
        """Escanea codigo generado por LLM antes de escribirlo al workspace.

        Debe llamarse sobre CADA archivo antes de escribirlo.
        """
        code_lower = code.lower()

        # Pattern matching
        for pattern in self.dangerous_patterns:
            if pattern in code_lower:
                result = GuardianResult(
                    allowed=False,
                    reason=f"Generated code contains dangerous pattern: {pattern}",
                    command=file_path or "unknown",
                )
                self._audit("CODE_BLOCKED", result)
                return result

        # Obfuscation detection
        for regex in _OBFUSCATION_PATTERNS:
            if regex.search(code):
                result = GuardianResult(
                    allowed=False,
                    reason=f"Generated code contains obfuscation: {regex.pattern[:60]}",
                    command=file_path or "unknown",
                )
                self._audit("CODE_BLOCKED_OBFUSCATION", result)
                return result

        return GuardianResult(allowed=True, command=file_path or "code_scan")

    @staticmethod
    def check_symlink_escape(workspace: Path, file_path: str) -> bool:
        """Detecta si un path escapa del workspace via symlinks.

        Returns True si el path es SEGURO (no escapa).
        Returns False si el path ESCAPA del workspace.
        """
        full = workspace / file_path
        try:
            resolved = full.resolve()
            workspace_resolved = workspace.resolve()
            # Verificar que el path resuelto esta dentro del workspace
            return str(resolved).startswith(str(workspace_resolved))
        except (OSError, ValueError):
            return False

    def _audit(self, event: str, result: GuardianResult) -> None:
        entry = {"event": event, "allowed": result.allowed, "command": result.command}
        if result.reason:
            entry["reason"] = result.reason
        self.audit_log.append(entry)
        if not result.allowed:
            logger.warning("guardian_%s cmd=%s reason=%s", event.lower(), result.command, result.reason)

    def get_audit(self, last_n: int = 50) -> list[dict[str, Any]]:
        return self.audit_log[-last_n:]
