"""Secret manager — secure handling of credentials and API keys."""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class SecretManager:
    """Gestión segura de secretos. Nunca loguea valores."""

    prefix: str = "KORE_"
    _secrets: dict[str, str] | None = None

    def get(self, name: str, default: str = "") -> str:
        """Obtiene un secreto por nombre."""
        full_name = f"{self.prefix}{name.upper()}"
        value = os.environ.get(full_name, default)
        if value and value != default:
            logger.debug("secret_loaded name=%s", full_name)
        else:
            logger.debug("secret_default name=%s", full_name)
        return value

    def require(self, name: str) -> str:
        """Obtiene un secreto obligatorio."""
        value = self.get(name)
        if not value:
            raise ValueError(f"Required secret not set: {self.prefix}{name.upper()}")
        return value

    def get_all(self) -> dict[str, str]:
        """Obtiene todos los secretos KORE_* (valores enmascarados para debug)."""
        return {
            k: f"{v[:4]}***" if len(v) > 4 else "***"
            for k, v in os.environ.items()
            if k.startswith(self.prefix)
            for v in [os.environ[k]]
        }
