"""Workspace management for generated project output."""
