"""WorkspaceManager — manages file output for generated projects."""

from __future__ import annotations

import logging
import uuid
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


class WorkspaceManager:
    """Gestiona directorios de workspace para cada job."""

    def __init__(self, base_path: str = "/tmp/kore/workspace") -> None:
        self._base_path = Path(base_path)

    @property
    def base_path(self) -> Path:
        return self._base_path

    def create_job_workspace(self, job_id: str | None = None) -> Path:
        """Crea un directorio de workspace para un job."""
        job_id = job_id or uuid.uuid4().hex[:12]
        workspace = self._base_path / job_id
        workspace.mkdir(parents=True, exist_ok=True)
        logger.info("workspace_created path=%s", workspace)
        return workspace

    def write_file(self, workspace: Path, relative_path: str, content: str) -> Path:
        """Escribe un archivo en el workspace."""
        file_path = workspace / relative_path
        file_path.parent.mkdir(parents=True, exist_ok=True)
        file_path.write_text(content, encoding="utf-8")
        logger.info("file_written path=%s size=%d", file_path, len(content))
        return file_path

    def list_files(self, workspace: Path) -> list[dict[str, Any]]:
        """Lista todos los archivos en el workspace."""
        files = []
        if workspace.exists():
            for f in sorted(workspace.rglob("*")):
                if f.is_file():
                    files.append({
                        "path": str(f.relative_to(workspace)),
                        "size": f.stat().st_size,
                    })
        return files

    def read_file(self, workspace: Path, relative_path: str) -> str:
        """Lee un archivo del workspace."""
        return (workspace / relative_path).read_text(encoding="utf-8")
