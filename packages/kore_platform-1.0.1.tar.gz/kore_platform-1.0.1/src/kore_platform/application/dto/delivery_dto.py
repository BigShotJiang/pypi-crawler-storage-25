"""Delivery-related DTOs."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True, slots=True)
class DeliveryDTO:
    """Entrega de resultado al usuario."""

    type: str  # "simple", "technical", "enterprise"
    artifacts: dict[str, Any] = field(default_factory=dict)
    urls: dict[str, str] = field(default_factory=dict)
    documentation: dict[str, str] = field(default_factory=dict)
    metrics: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "type": self.type,
            "artifacts": self.artifacts,
            "urls": self.urls,
            "documentation": self.documentation,
            "metrics": self.metrics,
        }
