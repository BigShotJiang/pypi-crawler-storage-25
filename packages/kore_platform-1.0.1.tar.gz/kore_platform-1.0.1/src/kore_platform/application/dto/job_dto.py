"""Job-related DTOs."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True, slots=True)
class JobResultDTO:
    """Resultado de un job."""

    job_id: str
    status: str
    message: str = ""
    delivery: dict[str, Any] = field(default_factory=dict)
    errors: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "job_id": self.job_id,
            "status": self.status,
            "message": self.message,
            "delivery": self.delivery,
            "errors": list(self.errors),
        }


@dataclass(frozen=True, slots=True)
class JobStatusDTO:
    """Estado actual de un job."""

    job_id: str
    status: str
    current_step: str = ""
    progress_pct: float = 0.0
    events: list[dict[str, Any]] = field(default_factory=list)
