"""Data Transfer Objects — immutable data carriers between layers."""

from .job_dto import JobResultDTO, JobStatusDTO
from .interview_dto import InterviewQuestionDTO, InterviewAnswerDTO
from .delivery_dto import DeliveryDTO

__all__ = [
    "JobResultDTO", "JobStatusDTO",
    "InterviewQuestionDTO", "InterviewAnswerDTO",
    "DeliveryDTO",
]
