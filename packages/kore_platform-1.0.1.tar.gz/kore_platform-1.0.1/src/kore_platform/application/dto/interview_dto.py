"""Interview-related DTOs."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True, slots=True)
class InterviewQuestionDTO:
    """Pregunta de entrevista."""

    id: str
    text: str
    category: str = "general"
    required: bool = True
    options: tuple[str, ...] = field(default_factory=tuple)
    hint: str = ""


@dataclass(frozen=True, slots=True)
class InterviewAnswerDTO:
    """Respuesta a pregunta de entrevista."""

    question_id: str
    answer: str
    confidence: float = 1.0
