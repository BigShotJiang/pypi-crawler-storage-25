"""Use case: create an execution plan from user context."""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

from ...domain.entities.user_context import UserContext
from ..ports.outbound.audit_log import AuditLogPort

if TYPE_CHECKING:
    from ...orchestration.orchestrator import Orchestrator

logger = logging.getLogger(__name__)


@dataclass(frozen=True, slots=True)
class Plan:
    """Plan de ejecución inmutable."""

    summary: str
    steps: tuple[dict[str, Any], ...]
    flow_name: str
    estimated_minutes: int

    def to_dict(self) -> dict[str, Any]:
        return {
            "summary": self.summary,
            "steps": list(self.steps),
            "flow_name": self.flow_name,
            "estimated_minutes": self.estimated_minutes,
        }


@dataclass(frozen=True, slots=True)
class CreatePlanUseCase:
    """Caso de uso: crear plan de ejecución."""

    orchestrator: Orchestrator
    audit_log: AuditLogPort

    async def execute(self, context: UserContext, job_id: str) -> Plan:
        """Genera plan basado en contexto del usuario."""
        plan = await self.orchestrator.generate_plan(context)

        await self.audit_log.append(job_id, "PLAN_CREATED", {
            "flow_name": plan.flow_name,
            "steps_count": len(plan.steps),
        })

        logger.info("plan_created job_id=%s flow=%s", job_id, plan.flow_name)
        return plan
