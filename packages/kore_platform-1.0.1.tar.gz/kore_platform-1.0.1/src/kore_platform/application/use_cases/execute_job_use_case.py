"""Use case: execute a job from idea to delivery."""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import TYPE_CHECKING

from ..dto.job_dto import JobResultDTO
from ..ports.outbound.audit_log import AuditLogPort
from ...domain.entities.job import Job, JobStatus

if TYPE_CHECKING:
    from ...interview.interviewer import Interviewer
    from ...orchestration.orchestrator import Orchestrator
    from ...delivery.delivery_factory import DeliveryFactory

logger = logging.getLogger(__name__)


@dataclass(frozen=True, slots=True)
class ExecuteJobUseCase:
    """Caso de uso principal: ejecutar job completo. Inmutable. Sin estado."""

    interviewer: Interviewer
    orchestrator: Orchestrator
    delivery_factory: DeliveryFactory
    audit_log: AuditLogPort

    async def execute(self, idea: str) -> JobResultDTO:
        """Ejecuta job completo: crear - entrevistar - planificar - ejecutar - entregar."""
        job = Job.create(idea)
        await self._log(job, "JOB_CREATED", {"idea": idea})
        logger.info("job_created job_id=%s idea=%s", job.id, idea[:100])

        try:
            # Interview
            job = job.transition_to(JobStatus.INTERVIEWING, "Starting interview")
            await self._log(job, "INTERVIEW_START", {})
            context = await self.interviewer.interview(idea)
            job = job.transition_to(
                JobStatus.PLANNING, "Interview completed", context=context,
            )
            await self._log(job, "INTERVIEW_COMPLETE", {
                "level": context.level.name,
                "problem": context.problem_to_solve,
            })

            # Plan
            plan = await self.orchestrator.generate_plan(context)
            job = job.transition_to(JobStatus.AWAITING_CONFIRMATION, "Plan ready")
            await self._log(job, "PLAN_GENERATED", {"plan_steps": plan.step_count})

            # Confirm
            confirmed = await self.orchestrator.request_user_confirmation(plan)
            if not confirmed:
                job = job.transition_to(JobStatus.CANCELLED, "User cancelled")
                await self._log(job, "JOB_CANCELLED", {"reason": "user_cancelled"})
                return JobResultDTO(
                    job_id=str(job.id), status="cancelled",
                    message="Job cancelled by user",
                )

            # Execute — note: orchestrator.execute takes (plan, context)
            job = job.transition_to(JobStatus.EXECUTING, "Executing flow")
            await self._log(job, "EXECUTION_START", {})
            result = await self.orchestrator.execute(plan, context)
            await self._log(job, "EXECUTION_COMPLETE", {
                "steps": len(result.steps),
            })

            # Deliver via create_and_package
            job = job.transition_to(JobStatus.DELIVERING, "Preparing delivery")
            delivery = await self.delivery_factory.create_and_package(
                level=context.level, result=result,
            )
            job = job.transition_to(JobStatus.COMPLETED, "Job completed")
            await self._log(job, "JOB_COMPLETED", {"delivery_type": delivery.type})

            logger.info(
                "job_completed job_id=%s level=%s duration=%.1fs",
                job.id, context.level.name, job.duration_seconds,
            )

            return JobResultDTO(
                job_id=str(job.id), status="success",
                delivery=delivery.to_dict(),
            )

        except Exception as exc:
            job = job.transition_to(JobStatus.FAILED, f"Failed: {exc}")
            await self._log(job, "JOB_FAILED", {"error": str(exc)})
            logger.exception("job_failed job_id=%s", job.id)
            raise

    async def _log(self, job: Job, event_type: str, data: dict) -> None:
        await self.audit_log.append(
            job_id=str(job.id),
            event_type=event_type,
            data={"status": job.status.name, **data},
        )
