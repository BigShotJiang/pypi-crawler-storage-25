"""Use case: deliver results to the user based on their level."""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import TYPE_CHECKING

from ..dto.delivery_dto import DeliveryDTO
from ..ports.outbound.audit_log import AuditLogPort
from ...domain.value_objects.technical_level import TechnicalLevel
from ...domain.value_objects.execution_result import ExecutionResult

if TYPE_CHECKING:
    from ...delivery.delivery_factory import DeliveryFactory

logger = logging.getLogger(__name__)


@dataclass(frozen=True, slots=True)
class DeliverResultUseCase:
    """Caso de uso: preparar y entregar resultado."""

    delivery_factory: DeliveryFactory
    audit_log: AuditLogPort

    async def execute(
        self,
        level: TechnicalLevel,
        result: ExecutionResult,
        job_id: str,
    ) -> DeliveryDTO:
        """Crea entrega apropiada para el nivel del usuario."""
        delivery = await self.delivery_factory.create_delivery(
            level=level, result=result,
        )

        await self.audit_log.append(job_id, "DELIVERY_CREATED", {
            "type": delivery.type,
            "artifacts_count": len(delivery.artifacts),
        })

        logger.info(
            "delivery_created job_id=%s type=%s", job_id, delivery.type,
        )
        return delivery
