"""Use case: interview a user to gather requirements."""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import TYPE_CHECKING

from ...domain.entities.user_context import UserContext
from ..ports.outbound.audit_log import AuditLogPort

if TYPE_CHECKING:
    from ...interview.interviewer import Interviewer

logger = logging.getLogger(__name__)


@dataclass(frozen=True, slots=True)
class InterviewUseCase:
    """Caso de uso: entrevistar usuario."""

    interviewer: Interviewer
    audit_log: AuditLogPort

    async def execute(self, idea: str, job_id: str) -> UserContext:
        """Realiza entrevista y devuelve contexto."""
        await self.audit_log.append(job_id, "INTERVIEW_START", {"idea": idea[:200]})

        context = await self.interviewer.interview(idea)

        await self.audit_log.append(job_id, "INTERVIEW_COMPLETE", {
            "level": context.level.name,
            "requirements_count": (
                len(context.business_requirements)
                + len(context.technical_requirements)
            ),
        })

        logger.info(
            "interview_complete job_id=%s level=%s",
            job_id, context.level.name,
        )
        return context
