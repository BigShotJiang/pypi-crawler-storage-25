"""Port: execute a job from idea to delivery."""

from __future__ import annotations

from typing import Protocol

from ...dto.job_dto import JobResultDTO


class ExecuteJobPort(Protocol):
    """Puerto de entrada para ejecutar jobs."""

    async def execute(self, idea: str) -> JobResultDTO: ...
