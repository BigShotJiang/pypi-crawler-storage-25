"""Port: interview a user to gather requirements."""

from __future__ import annotations

from typing import Protocol

from ....domain.entities.user_context import UserContext


class InterviewPort(Protocol):
    """Puerto de entrada para entrevistar usuarios."""

    async def interview(self, idea: str) -> UserContext: ...
