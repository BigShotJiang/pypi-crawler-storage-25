"""Ports — interfaces between application and infrastructure."""
