"""Port: message bus for inter-agent communication."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Awaitable, Callable


class MessageBusPort(ABC):
    """Puerto de salida para bus de mensajes."""

    @abstractmethod
    async def publish(self, channel: str, message: dict[str, Any]) -> None: ...

    @abstractmethod
    async def subscribe(
        self,
        channel: str,
        callback: Callable[[dict[str, Any]], Awaitable[None]],
    ) -> None: ...

    @abstractmethod
    async def enqueue(self, queue: str, task: dict[str, Any]) -> None: ...

    @abstractmethod
    async def dequeue(self, queue: str, timeout: float = 0) -> dict[str, Any] | None: ...

    @abstractmethod
    async def cache_set(self, key: str, value: Any, ttl: int | None = None) -> None: ...

    @abstractmethod
    async def cache_get(self, key: str) -> Any | None: ...

    @abstractmethod
    async def log(self, stream: str, entry: dict[str, Any]) -> None: ...

    @abstractmethod
    async def history(self, stream: str, count: int = 50) -> list[dict[str, Any]]: ...
