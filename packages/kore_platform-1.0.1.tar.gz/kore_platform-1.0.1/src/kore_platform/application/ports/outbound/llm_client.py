"""Port: LLM client for AI inference."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True, slots=True)
class LLMMessage:
    """Mensaje para el LLM."""

    role: str  # "system", "user", "assistant"
    content: str


@dataclass(frozen=True, slots=True)
class LLMResponse:
    """Respuesta del LLM."""

    content: str
    model: str
    usage: dict[str, int] = field(default_factory=dict)
    finish_reason: str = "stop"


class LLMClientPort(ABC):
    """Puerto de salida para cliente LLM."""

    @abstractmethod
    async def chat(
        self,
        messages: list[LLMMessage],
        model: str | None = None,
        temperature: float = 0.7,
        max_tokens: int = 4096,
    ) -> LLMResponse: ...

    @abstractmethod
    async def structured_output(
        self,
        messages: list[LLMMessage],
        schema: dict[str, Any],
        model: str | None = None,
    ) -> dict[str, Any]: ...
