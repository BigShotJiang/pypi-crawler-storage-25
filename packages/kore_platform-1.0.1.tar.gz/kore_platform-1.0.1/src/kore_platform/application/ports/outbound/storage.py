"""Port: persistent storage for jobs, artifacts, etc."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any


class StoragePort(ABC):
    """Puerto de salida para almacenamiento persistente."""

    @abstractmethod
    async def save(self, collection: str, key: str, data: dict[str, Any]) -> None: ...

    @abstractmethod
    async def load(self, collection: str, key: str) -> dict[str, Any] | None: ...

    @abstractmethod
    async def delete(self, collection: str, key: str) -> None: ...

    @abstractmethod
    async def list_keys(self, collection: str, prefix: str = "") -> list[str]: ...

    @abstractmethod
    async def save_artifact(self, job_id: str, name: str, content: bytes) -> str:
        """Saves a binary artifact and returns its path/URL."""
        ...

    @abstractmethod
    async def load_artifact(self, job_id: str, name: str) -> bytes | None: ...
