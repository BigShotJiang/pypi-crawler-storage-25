"""Port: agent runtime for executing agent tasks in sandboxes."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any


class AgentRuntimePort(ABC):
    """Puerto de salida para runtime de agentes."""

    @abstractmethod
    async def create_sandbox(self, agent_name: str, config: dict[str, Any]) -> str:
        """Creates a sandbox and returns its ID."""
        ...

    @abstractmethod
    async def execute_in_sandbox(
        self, sandbox_id: str, command: str, timeout: int = 300,
    ) -> dict[str, Any]:
        """Executes a command in a sandbox."""
        ...

    @abstractmethod
    async def destroy_sandbox(self, sandbox_id: str) -> None:
        """Destroys a sandbox."""
        ...

    @abstractmethod
    async def list_sandboxes(self) -> list[dict[str, Any]]:
        """Lists active sandboxes."""
        ...
