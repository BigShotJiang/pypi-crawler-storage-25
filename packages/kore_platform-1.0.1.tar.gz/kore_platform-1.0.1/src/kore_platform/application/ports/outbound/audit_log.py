"""Port: immutable audit log with hash chain verification."""

from __future__ import annotations

from abc import ABC, abstractmethod
from datetime import datetime
from typing import Any


class AuditLogPort(ABC):
    """Puerto de salida para audit log inmutable."""

    @abstractmethod
    async def append(
        self,
        job_id: str,
        event_type: str,
        data: dict[str, Any],
        timestamp: datetime | None = None,
    ) -> str:
        """Appends entry. Returns hash for verification."""
        ...

    @abstractmethod
    async def verify_integrity(self, job_id: str) -> bool:
        """Verifies the hash chain has not been tampered with."""
        ...

    @abstractmethod
    async def get_entries(
        self,
        job_id: str,
        from_timestamp: datetime | None = None,
        to_timestamp: datetime | None = None,
    ) -> list[dict[str, Any]]: ...
