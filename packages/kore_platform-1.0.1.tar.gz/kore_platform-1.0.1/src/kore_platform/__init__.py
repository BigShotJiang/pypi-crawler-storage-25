"""KORE Platform — Enterprise-grade universal development system."""

__version__ = "1.0.0"
