"""Execution result value object — immutable result of a flow execution."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Sequence

from .job_id import JobId


@dataclass(frozen=True, slots=True)
class StepResult:
    """Resultado de un paso individual."""

    step_id: str
    agent: str
    action: str
    status: str
    output: dict[str, Any] = field(default_factory=dict)
    duration_ms: float = 0.0
    error: str | None = None


@dataclass(frozen=True, slots=True)
class ExecutionResult:
    """Resultado completo de ejecución. Inmutable."""

    job_id: JobId
    steps: Sequence[StepResult] = field(default_factory=tuple)
    artifacts: dict[str, Any] = field(default_factory=dict)
    metrics: dict[str, Any] = field(default_factory=dict)

    @property
    def success(self) -> bool:
        return all(s.status == "completed" for s in self.steps)

    @property
    def summary(self) -> str:
        total = len(self.steps)
        ok = sum(1 for s in self.steps if s.status == "completed")
        return f"{ok}/{total} steps completed"
