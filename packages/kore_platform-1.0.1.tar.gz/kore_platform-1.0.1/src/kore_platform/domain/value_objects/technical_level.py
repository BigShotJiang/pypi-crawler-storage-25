"""Technical level of the user — determines flow, questions, and delivery."""

from __future__ import annotations

from enum import Enum, auto


class TechnicalLevel(Enum):
    """Nivel técnico del usuario. Inmutable por diseño (Enum)."""

    NO_DEV = auto()
    DEV_JUNIOR = auto()
    DEV_SENIOR = auto()
    ENGINEER = auto()

    @property
    def requires_technical_questions(self) -> bool:
        return self in (self.DEV_SENIOR, self.ENGINEER)

    @property
    def requires_architecture_decisions(self) -> bool:
        return self == self.ENGINEER

    @property
    def default_test_coverage(self) -> int:
        return {
            TechnicalLevel.NO_DEV: 0,
            TechnicalLevel.DEV_JUNIOR: 60,
            TechnicalLevel.DEV_SENIOR: 80,
            TechnicalLevel.ENGINEER: 95,
        }[self]

    @property
    def flow_name(self) -> str:
        return {
            TechnicalLevel.NO_DEV: "simple_flow",
            TechnicalLevel.DEV_JUNIOR: "developer_flow",
            TechnicalLevel.DEV_SENIOR: "developer_flow",
            TechnicalLevel.ENGINEER: "enterprise_flow",
        }[self]
