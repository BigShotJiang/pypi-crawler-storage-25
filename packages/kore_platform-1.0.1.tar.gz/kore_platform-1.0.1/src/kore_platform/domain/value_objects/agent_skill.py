"""Agent skill value object — describes a capability."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum, auto


class SkillCategory(Enum):
    """Categoría de skill."""

    ANALYSIS = auto()
    DESIGN = auto()
    CODING = auto()
    TESTING = auto()
    REVIEW = auto()
    SECURITY = auto()
    DEPLOYMENT = auto()
    DOCUMENTATION = auto()
    MONITORING = auto()


@dataclass(frozen=True, slots=True)
class AgentSkill:
    """Skill de un agente. Inmutable."""

    name: str
    category: SkillCategory
    description: str = ""
    requires_sandbox: bool = False
    max_execution_seconds: int = 300

    def __str__(self) -> str:
        return f"{self.category.name}:{self.name}"
