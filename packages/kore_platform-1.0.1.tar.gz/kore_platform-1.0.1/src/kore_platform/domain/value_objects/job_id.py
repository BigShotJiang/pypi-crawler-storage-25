"""Unique job identifier — immutable, validated on construction."""

from __future__ import annotations

import re
import uuid
from dataclasses import dataclass


_UUID4_RE = re.compile(
    r"^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$",
    re.IGNORECASE,
)


@dataclass(frozen=True, slots=True)
class JobId:
    """Identificador único de job. Inmutable (frozen=True). Validado."""

    value: str

    def __post_init__(self) -> None:
        if not _UUID4_RE.match(self.value):
            raise ValueError(f"Invalid JobId: {self.value}")

    @classmethod
    def generate(cls) -> JobId:
        return cls(str(uuid.uuid4()))

    def __str__(self) -> str:
        return self.value
