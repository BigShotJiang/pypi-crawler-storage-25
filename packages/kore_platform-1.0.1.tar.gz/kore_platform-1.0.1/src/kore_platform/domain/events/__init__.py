"""Domain events — communicate state changes across boundaries."""

from .base import DomainEvent
from .job_events import (
    JobCreated, JobInterviewStarted, JobPlanGenerated,
    JobExecutionStarted, JobCompleted, JobFailed, JobCancelled,
)
from .agent_events import AgentTaskStarted, AgentTaskCompleted, AgentTaskFailed

__all__ = [
    "DomainEvent",
    "JobCreated", "JobInterviewStarted", "JobPlanGenerated",
    "JobExecutionStarted", "JobCompleted", "JobFailed", "JobCancelled",
    "AgentTaskStarted", "AgentTaskCompleted", "AgentTaskFailed",
]
