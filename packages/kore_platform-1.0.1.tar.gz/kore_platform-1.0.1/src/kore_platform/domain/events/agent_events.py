"""Agent-related domain events."""

from __future__ import annotations

from dataclasses import dataclass

from .base import DomainEvent


@dataclass(frozen=True, slots=True)
class AgentTaskStarted(DomainEvent):
    event_type: str = "agent.task_started"
    agent_name: str = ""
    action: str = ""


@dataclass(frozen=True, slots=True)
class AgentTaskCompleted(DomainEvent):
    event_type: str = "agent.task_completed"
    agent_name: str = ""
    action: str = ""
    duration_ms: float = 0.0


@dataclass(frozen=True, slots=True)
class AgentTaskFailed(DomainEvent):
    event_type: str = "agent.task_failed"
    agent_name: str = ""
    action: str = ""
    error: str = ""
