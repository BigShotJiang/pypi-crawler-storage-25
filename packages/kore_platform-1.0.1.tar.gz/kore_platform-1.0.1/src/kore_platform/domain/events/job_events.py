"""Job-related domain events."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from .base import DomainEvent


@dataclass(frozen=True, slots=True)
class JobCreated(DomainEvent):
    event_type: str = "job.created"
    idea: str = ""


@dataclass(frozen=True, slots=True)
class JobInterviewStarted(DomainEvent):
    event_type: str = "job.interview_started"


@dataclass(frozen=True, slots=True)
class JobPlanGenerated(DomainEvent):
    event_type: str = "job.plan_generated"
    plan_summary: str = ""


@dataclass(frozen=True, slots=True)
class JobExecutionStarted(DomainEvent):
    event_type: str = "job.execution_started"
    flow_name: str = ""
    total_steps: int = 0


@dataclass(frozen=True, slots=True)
class JobCompleted(DomainEvent):
    event_type: str = "job.completed"
    duration_seconds: float = 0.0
    delivery_type: str = ""


@dataclass(frozen=True, slots=True)
class JobFailed(DomainEvent):
    event_type: str = "job.failed"
    error: str = ""
    step: str = ""


@dataclass(frozen=True, slots=True)
class JobCancelled(DomainEvent):
    event_type: str = "job.cancelled"
    reason: str = ""
