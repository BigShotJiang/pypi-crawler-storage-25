"""Flow entity — represents a workflow definition."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Sequence


@dataclass(frozen=True, slots=True)
class FlowDecision:
    """Nodo de decisión dentro de un flujo."""

    name: str
    condition: str
    on_true: str
    on_false: str


@dataclass(frozen=True, slots=True)
class FlowStep:
    """Paso individual dentro de un flujo."""

    agent: str
    action: str
    inputs: tuple[str, ...] = field(default_factory=tuple)
    outputs: tuple[str, ...] = field(default_factory=tuple)
    timeout_seconds: int = 300
    retries: int = 0


@dataclass(frozen=True, slots=True)
class Flow:
    """Flujo completo. Inmutable."""

    name: str
    trigger: str
    description: str
    steps: Sequence[FlowStep | FlowDecision] = field(default_factory=tuple)
    alerts: tuple[str, ...] = field(default_factory=tuple)
    version: str = "1.0"

    @property
    def step_count(self) -> int:
        return len(self.steps)
