"""User context after interview — immutable, contains all info for execution."""

from __future__ import annotations

from dataclasses import dataclass, field

from ..value_objects.technical_level import TechnicalLevel


@dataclass(frozen=True, slots=True)
class UserContext:
    """Contexto del usuario después de la entrevista. Inmutable (frozen=True)."""

    # Identification
    level: TechnicalLevel

    # Problem
    original_idea: str
    problem_to_solve: str
    target_users: str

    # Technical (optional per level)
    preferred_stack: frozenset[str] = field(default_factory=frozenset)
    architecture_pattern: str | None = None
    deployment_target: str | None = None

    # Requirements
    business_requirements: frozenset[str] = field(default_factory=frozenset)
    technical_requirements: frozenset[str] = field(default_factory=frozenset)

    # Preferences
    test_coverage: int = 80
    needs_ci_cd: bool = True
    needs_monitoring: bool = False

    # Security (for engineers)
    security_requirements: frozenset[str] = field(default_factory=frozenset)
    compliance_requirements: frozenset[str] = field(default_factory=frozenset)

    # Metadata: how answers were generated
    answer_source: str = "demo"  # "demo" | "llm_auto" | "user" | "stub"

    def with_updated_requirements(
        self,
        business: frozenset[str] | None = None,
        technical: frozenset[str] | None = None,
    ) -> UserContext:
        """Creates new context with updated requirements. Immutability preserved."""
        return UserContext(
            level=self.level,
            original_idea=self.original_idea,
            problem_to_solve=self.problem_to_solve,
            target_users=self.target_users,
            preferred_stack=self.preferred_stack,
            architecture_pattern=self.architecture_pattern,
            deployment_target=self.deployment_target,
            business_requirements=business if business is not None else self.business_requirements,
            technical_requirements=technical if technical is not None else self.technical_requirements,
            test_coverage=self.test_coverage,
            needs_ci_cd=self.needs_ci_cd,
            needs_monitoring=self.needs_monitoring,
            security_requirements=self.security_requirements,
            compliance_requirements=self.compliance_requirements,
            answer_source=self.answer_source,
        )
