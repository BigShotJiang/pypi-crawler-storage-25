"""Step entity — represents a single execution step."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum, auto
from typing import Any


class StepType(Enum):
    """Tipo de paso."""

    AGENT = auto()
    DECISION = auto()
    PARALLEL = auto()
    CHECKPOINT = auto()


@dataclass(frozen=True, slots=True)
class Step:
    """Paso de ejecución. Inmutable."""

    id: str
    type: StepType
    agent: str | None = None
    action: str | None = None
    inputs: tuple[str, ...] = field(default_factory=tuple)
    outputs: tuple[str, ...] = field(default_factory=tuple)
    config: dict[str, Any] = field(default_factory=dict)
    started_at: datetime | None = None
    completed_at: datetime | None = None

    def with_start(self) -> Step:
        return Step(
            id=self.id, type=self.type, agent=self.agent, action=self.action,
            inputs=self.inputs, outputs=self.outputs, config=self.config,
            started_at=datetime.now(timezone.utc), completed_at=self.completed_at,
        )

    def with_completion(self) -> Step:
        return Step(
            id=self.id, type=self.type, agent=self.agent, action=self.action,
            inputs=self.inputs, outputs=self.outputs, config=self.config,
            started_at=self.started_at, completed_at=datetime.now(timezone.utc),
        )
