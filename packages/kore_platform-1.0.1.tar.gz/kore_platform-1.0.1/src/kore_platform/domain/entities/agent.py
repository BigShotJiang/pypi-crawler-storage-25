"""Agent entity — domain representation of an agent."""

from __future__ import annotations

from dataclasses import dataclass, field

from ..value_objects.agent_skill import AgentSkill


@dataclass(frozen=True, slots=True)
class AgentEntity:
    """Entidad Agente en el dominio. Inmutable."""

    name: str
    role: str
    skills: frozenset[AgentSkill] = field(default_factory=frozenset)
    max_concurrent_tasks: int = 1
    requires_sandbox: bool = True

    def has_skill(self, skill_name: str) -> bool:
        return any(s.name == skill_name for s in self.skills)

    def with_skill(self, skill: AgentSkill) -> AgentEntity:
        return AgentEntity(
            name=self.name,
            role=self.role,
            skills=self.skills | {skill},
            max_concurrent_tasks=self.max_concurrent_tasks,
            requires_sandbox=self.requires_sandbox,
        )
