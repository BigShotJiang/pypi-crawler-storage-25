"""Job entity — represents a development job. Immutable state transitions."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum, auto
from typing import Any, Sequence

from ..value_objects.job_id import JobId
from .user_context import UserContext


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


class JobStatus(Enum):
    """Estado del job."""

    CREATED = auto()
    INTERVIEWING = auto()
    PLANNING = auto()
    AWAITING_CONFIRMATION = auto()
    EXECUTING = auto()
    DELIVERING = auto()
    COMPLETED = auto()
    FAILED = auto()
    CANCELLED = auto()


@dataclass(frozen=True, slots=True)
class JobEvent:
    """Evento de cambio en job. Inmutable."""

    timestamp: datetime
    status: JobStatus
    message: str
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class Job:
    """Entidad Job. Inmutable — cambios de estado crean nuevo Job."""

    id: JobId
    status: JobStatus
    context: UserContext | None
    events: Sequence[JobEvent] = field(default_factory=tuple)
    created_at: datetime = field(default_factory=_utcnow)
    updated_at: datetime = field(default_factory=_utcnow)

    @classmethod
    def create(cls, idea: str) -> Job:
        """Factory method para crear nuevo job."""
        job_id = JobId.generate()
        now = _utcnow()
        event = JobEvent(
            timestamp=now,
            status=JobStatus.CREATED,
            message="Job created",
            metadata={"original_idea": idea},
        )
        return cls(
            id=job_id,
            status=JobStatus.CREATED,
            context=None,
            events=(event,),
            created_at=now,
            updated_at=now,
        )

    def transition_to(
        self,
        new_status: JobStatus,
        message: str,
        context: UserContext | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> Job:
        """Transiciona a nuevo estado. Inmutabilidad: crea nuevo Job."""
        now = _utcnow()
        event = JobEvent(
            timestamp=now,
            status=new_status,
            message=message,
            metadata=metadata or {},
        )
        return Job(
            id=self.id,
            status=new_status,
            context=context or self.context,
            events=(*self.events, event),
            created_at=self.created_at,
            updated_at=now,
        )

    @property
    def duration_seconds(self) -> float:
        return (self.updated_at - self.created_at).total_seconds()
