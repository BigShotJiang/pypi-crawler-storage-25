"""Interview domain service — pure business logic for interviews."""

from __future__ import annotations

from ..entities.user_context import UserContext
from ..value_objects.technical_level import TechnicalLevel


class InterviewService:
    """Servicio de dominio para la lógica de entrevista."""

    VAGUE_INDICATORS: frozenset[str] = frozenset({
        "algo", "cosa", "eso", "no sé", "quizás", "tal vez",
        "something", "thing", "maybe", "not sure", "i don't know",
    })

    @staticmethod
    def needs_clarification(answer: str) -> bool:
        """Determina si una respuesta necesita clarificación."""
        if len(answer.split()) < 3:
            return True
        answer_lower = answer.lower()
        return any(indicator in answer_lower for indicator in InterviewService.VAGUE_INDICATORS)

    @staticmethod
    def build_context(
        level: TechnicalLevel,
        idea: str,
        answers: dict[str, str],
    ) -> UserContext:
        """Construye contexto a partir de respuestas de entrevista."""
        return UserContext(
            level=level,
            original_idea=idea,
            problem_to_solve=answers.get("problem", idea),
            target_users=answers.get("target_users", "general"),
            preferred_stack=frozenset(
                answers.get("stack", "").split(",")
            ) if answers.get("stack") else frozenset(),
            architecture_pattern=answers.get("architecture"),
            deployment_target=answers.get("deployment"),
            business_requirements=frozenset(
                r.strip() for r in answers.get("business_reqs", "").split(",") if r.strip()
            ),
            technical_requirements=frozenset(
                r.strip() for r in answers.get("technical_reqs", "").split(",") if r.strip()
            ),
            test_coverage=level.default_test_coverage,
            needs_ci_cd=level != TechnicalLevel.NO_DEV,
            needs_monitoring=level == TechnicalLevel.ENGINEER,
        )
