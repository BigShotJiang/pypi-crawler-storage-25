"""Validation-related exceptions."""

from .base import KorePlatformError


class ValidationError(KorePlatformError):
    """Data validation failed."""

    def __init__(self, message: str, field: str = "") -> None:
        super().__init__(message, code="VALIDATION_ERROR")
        self.field = field


class InvalidJobIdError(ValidationError):
    """Invalid job ID format."""

    def __init__(self, value: str) -> None:
        super().__init__(f"Invalid JobId: {value}", field="job_id")
        self.code = "INVALID_JOB_ID"


class InvalidFlowError(ValidationError):
    """Invalid flow definition."""

    def __init__(self, message: str) -> None:
        super().__init__(message, field="flow")
        self.code = "INVALID_FLOW"
