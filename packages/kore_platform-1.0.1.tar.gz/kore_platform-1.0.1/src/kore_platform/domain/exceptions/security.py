"""Security-related exceptions."""

from .base import KorePlatformError


class SecurityError(KorePlatformError):
    """Base security error."""

    def __init__(self, message: str) -> None:
        super().__init__(message, code="SECURITY_ERROR")


class SignatureVerificationError(SecurityError):
    """Flow YAML signature verification failed."""

    def __init__(self, message: str) -> None:
        super().__init__(message)
        self.code = "SIGNATURE_INVALID"


class AuditLogTamperingError(SecurityError):
    """Audit log hash chain integrity violation."""

    def __init__(self, message: str) -> None:
        super().__init__(message)
        self.code = "AUDIT_TAMPERED"


class SandboxEscapeError(SecurityError):
    """Agent attempted to escape sandbox."""

    def __init__(self, message: str) -> None:
        super().__init__(message)
        self.code = "SANDBOX_ESCAPE"


class PrivilegeEscalationError(SecurityError):
    """Agent attempted privilege escalation."""

    def __init__(self, message: str) -> None:
        super().__init__(message)
        self.code = "PRIVILEGE_ESCALATION"
