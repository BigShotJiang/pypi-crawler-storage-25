"""Domain exceptions — typed error hierarchy."""

from .base import KorePlatformError, DomainError
from .security import (
    SecurityError, SignatureVerificationError,
    AuditLogTamperingError, SandboxEscapeError, PrivilegeEscalationError,
)
from .validation import ValidationError, InvalidJobIdError, InvalidFlowError

__all__ = [
    "KorePlatformError", "DomainError",
    "SecurityError", "SignatureVerificationError",
    "AuditLogTamperingError", "SandboxEscapeError", "PrivilegeEscalationError",
    "ValidationError", "InvalidJobIdError", "InvalidFlowError",
]
