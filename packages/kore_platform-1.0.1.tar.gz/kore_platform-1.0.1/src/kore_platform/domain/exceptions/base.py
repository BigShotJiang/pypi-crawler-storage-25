"""Base exceptions for the platform."""


class KorePlatformError(Exception):
    """Root exception for all platform errors."""

    def __init__(self, message: str, code: str = "KORE_ERROR") -> None:
        self.code = code
        super().__init__(message)


class DomainError(KorePlatformError):
    """Errors in domain logic."""

    def __init__(self, message: str) -> None:
        super().__init__(message, code="DOMAIN_ERROR")
