"""Technical delivery — for developers (repo, docs, tests)."""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any

from ..application.dto.delivery_dto import DeliveryDTO
from ..domain.value_objects.execution_result import ExecutionResult

logger = logging.getLogger(__name__)


@dataclass(frozen=True, slots=True)
class TechnicalDelivery:
    """Entrega para desarrolladores (junior y senior).

    Incluye:
    - Repositorio con codigo fuente
    - Documentacion tecnica (README, API docs)
    - Suite de tests
    - Configuracion de CI/CD
    """

    async def package(self, result: ExecutionResult) -> DeliveryDTO:
        """Empaqueta el resultado para un desarrollador.

        Parameters
        ----------
        result:
            Resultado de ejecucion del orquestador.

        Returns
        -------
        DeliveryDTO
            Entrega inmutable con repo, docs y tests.
        """
        artifacts = self._extract_artifacts(result)
        repo_name = artifacts.get("app_name", "kore-project")

        delivery = DeliveryDTO(
            type="technical",
            artifacts={
                "repo_name": repo_name,
                "language": artifacts.get("language", "python"),
                "framework": artifacts.get("framework", "fastapi"),
                "test_coverage": artifacts.get("test_coverage", 80),
                "files_generated": artifacts.get("files_generated", 0),
            },
            urls={
                "repo": f"https://github.com/kore-generated/{repo_name}",
                "docs": f"https://github.com/kore-generated/{repo_name}/blob/main/README.md",
                "api_docs": f"https://github.com/kore-generated/{repo_name}/blob/main/docs/api.md",
                "ci_cd": f"https://github.com/kore-generated/{repo_name}/actions",
            },
            documentation={
                "readme": self._generate_readme(artifacts),
                "api_docs": self._generate_api_docs(artifacts),
                "setup_guide": self._generate_setup_guide(artifacts),
                "contributing": self._generate_contributing(artifacts),
            },
            metrics={
                "total_steps": result.metrics.get("total_steps", 0),
                "success": result.success,
                "test_coverage": artifacts.get("test_coverage", 80),
                "files_generated": artifacts.get("files_generated", 0),
                "duration_ms": result.metrics.get("total_duration_ms", 0),
                **self._extract_complexity_metrics(result),
            },
        )

        logger.info(
            "technical_delivery_packaged job=%s repo=%s",
            result.job_id, repo_name,
        )
        return delivery

    @staticmethod
    def _extract_artifacts(result: ExecutionResult) -> dict[str, Any]:
        """Extrae artefactos relevantes del resultado."""
        flat: dict[str, Any] = {}
        for key, value in result.artifacts.items():
            if isinstance(value, dict):
                flat.update(value)
            else:
                flat[key] = value
        return flat

    @staticmethod
    def _generate_readme(artifacts: dict[str, Any]) -> str:
        """Genera README.md tecnico."""
        name = artifacts.get("app_name", "kore-project")
        lang = artifacts.get("language", "python")
        framework = artifacts.get("framework", "fastapi")
        return (
            f"# {name}\n\n"
            f"Generado por Kore Platform.\n\n"
            f"## Stack\n"
            f"- **Lenguaje:** {lang}\n"
            f"- **Framework:** {framework}\n\n"
            f"## Quick Start\n"
            f"```bash\n"
            f"git clone https://github.com/kore-generated/{name}.git\n"
            f"cd {name}\n"
            f"pip install -e '.[dev]'\n"
            f"pytest\n"
            f"```\n\n"
            f"## Estructura\n"
            f"```\n"
            f"src/\n"
            f"  {name.replace('-', '_')}/\n"
            f"    __init__.py\n"
            f"    main.py\n"
            f"    api/\n"
            f"    domain/\n"
            f"    infrastructure/\n"
            f"tests/\n"
            f"```\n\n"
            f"## Tests\n"
            f"```bash\n"
            f"pytest --cov={name.replace('-', '_')} --cov-report=html\n"
            f"```\n"
        )

    @staticmethod
    def _generate_api_docs(artifacts: dict[str, Any]) -> str:
        """Genera documentacion de API."""
        return (
            "# API Documentation\n\n"
            "## Endpoints\n\n"
            "### Health Check\n"
            "```\n"
            "GET /health\n"
            "Response: {\"status\": \"ok\"}\n"
            "```\n\n"
            "### API v1\n"
            "Documentacion interactiva disponible en `/docs` (Swagger UI).\n"
        )

    @staticmethod
    def _generate_setup_guide(artifacts: dict[str, Any]) -> str:
        """Genera guia de setup."""
        return (
            "# Setup Guide\n\n"
            "## Requisitos\n"
            "- Python 3.11+\n"
            "- Docker (opcional)\n\n"
            "## Instalacion\n"
            "1. Clonar el repositorio\n"
            "2. Crear entorno virtual: `python -m venv .venv`\n"
            "3. Activar: `source .venv/bin/activate`\n"
            "4. Instalar: `pip install -e '.[dev]'`\n"
            "5. Ejecutar: `uvicorn main:app --reload`\n"
        )

    @staticmethod
    def _extract_complexity_metrics(result: ExecutionResult) -> dict[str, Any]:
        """Extract complexity report from artifacts if present."""
        for value in result.artifacts.values():
            if isinstance(value, dict) and value.get("type") == "complexity_report":
                return {
                    "complexity_rating": value.get("rating", "N/A"),
                    "complexity_metrics": value.get("metrics", {}),
                }
        return {}

    @staticmethod
    def _generate_contributing(artifacts: dict[str, Any]) -> str:
        """Genera guia de contribucion."""
        return (
            "# Contributing\n\n"
            "## Workflow\n"
            "1. Fork el repo\n"
            "2. Crear branch: `git checkout -b feature/mi-feature`\n"
            "3. Commit: `git commit -m 'Add mi feature'`\n"
            "4. Push: `git push origin feature/mi-feature`\n"
            "5. Crear Pull Request\n\n"
            "## Reglas\n"
            "- Tests obligatorios\n"
            "- Type hints en todo el codigo\n"
            "- Linting con ruff\n"
        )
