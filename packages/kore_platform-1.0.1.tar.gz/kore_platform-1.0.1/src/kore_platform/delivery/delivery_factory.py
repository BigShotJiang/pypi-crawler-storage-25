"""Delivery factory — creates the appropriate delivery based on TechnicalLevel."""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Union

from ..application.dto.delivery_dto import DeliveryDTO
from ..domain.value_objects.execution_result import ExecutionResult
from ..domain.value_objects.technical_level import TechnicalLevel
from .enterprise_delivery import EnterpriseDelivery
from .simple_delivery import SimpleDelivery
from .technical_delivery import TechnicalDelivery

logger = logging.getLogger(__name__)

# Tipo union de todas las entregas
AnyDelivery = Union[SimpleDelivery, TechnicalDelivery, EnterpriseDelivery]


@dataclass(frozen=True, slots=True)
class DeliveryFactory:
    """Factory que crea la entrega adecuada segun el nivel tecnico del usuario.

    Inmutable (frozen=True). Patron Factory Method puro.
    """

    @staticmethod
    def create(level: TechnicalLevel) -> AnyDelivery:
        """Crea la instancia de delivery apropiada para el nivel.

        Parameters
        ----------
        level:
            Nivel tecnico del usuario.

        Returns
        -------
        AnyDelivery
            SimpleDelivery, TechnicalDelivery, o EnterpriseDelivery.
        """
        delivery_map: dict[TechnicalLevel, AnyDelivery] = {
            TechnicalLevel.NO_DEV: SimpleDelivery(),
            TechnicalLevel.DEV_JUNIOR: TechnicalDelivery(),
            TechnicalLevel.DEV_SENIOR: TechnicalDelivery(),
            TechnicalLevel.ENGINEER: EnterpriseDelivery(),
        }

        delivery = delivery_map.get(level)
        if delivery is None:
            logger.warning(
                "unknown_level level=%s falling_back=simple", level,
            )
            delivery = SimpleDelivery()

        logger.info(
            "delivery_created level=%s type=%s",
            level.name, type(delivery).__name__,
        )
        return delivery

    @staticmethod
    async def create_and_package(
        level: TechnicalLevel,
        result: ExecutionResult,
    ) -> DeliveryDTO:
        """Crea la entrega apropiada y empaqueta el resultado en un solo paso.

        Convenience method que combina create() + package().

        Parameters
        ----------
        level:
            Nivel tecnico del usuario.
        result:
            Resultado de ejecucion.

        Returns
        -------
        DeliveryDTO
            DTO de entrega inmutable.
        """
        delivery = DeliveryFactory.create(level)
        dto = await delivery.package(result)
        logger.info(
            "delivery_packaged level=%s type=%s job=%s",
            level.name, dto.type, result.job_id,
        )
        return dto
