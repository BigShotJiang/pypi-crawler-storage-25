"""Simple delivery — for non-dev users (URL, manual, tutorial)."""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any

from ..application.dto.delivery_dto import DeliveryDTO
from ..domain.value_objects.execution_result import ExecutionResult

logger = logging.getLogger(__name__)


@dataclass(frozen=True, slots=True)
class SimpleDelivery:
    """Entrega para usuarios no tecnicos.

    Incluye:
    - URL de la aplicacion desplegada
    - Manual de usuario basico
    - Tutorial paso a paso
    """

    async def package(self, result: ExecutionResult) -> DeliveryDTO:
        """Empaqueta el resultado para un usuario no tecnico.

        Parameters
        ----------
        result:
            Resultado de ejecucion del orquestador.

        Returns
        -------
        DeliveryDTO
            Entrega inmutable con URL, manual y tutorial.
        """
        artifacts = self._extract_artifacts(result)

        delivery = DeliveryDTO(
            type="simple",
            artifacts={
                "app_name": artifacts.get("app_name", "mi-aplicacion"),
                "summary": artifacts.get("summary", "Aplicacion generada correctamente"),
            },
            urls={
                "app": f"https://demo.kore.dev/{artifacts.get('app_name', 'mi-app')}",
                "tutorial": f"https://docs.kore.dev/tutorial/{artifacts.get('app_name', 'mi-app')}",
            },
            documentation={
                "manual": self._generate_user_manual(artifacts),
                "tutorial": self._generate_tutorial(artifacts),
                "faq": self._generate_faq(artifacts),
            },
            metrics={
                "total_steps": result.metrics.get("total_steps", 0),
                "success": result.success,
            },
        )

        logger.info("simple_delivery_packaged job=%s", result.job_id)
        return delivery

    @staticmethod
    def _extract_artifacts(result: ExecutionResult) -> dict[str, Any]:
        """Extrae artefactos relevantes del resultado."""
        flat: dict[str, Any] = {}
        for key, value in result.artifacts.items():
            if isinstance(value, dict):
                flat.update(value)
            else:
                flat[key] = value
        return flat

    @staticmethod
    def _generate_user_manual(artifacts: dict[str, Any]) -> str:
        """Genera un manual de usuario basico."""
        app_name = artifacts.get("app_name", "Tu Aplicacion")
        return (
            f"# Manual de Usuario - {app_name}\n\n"
            f"## Como empezar\n"
            f"1. Abre la URL de tu aplicacion\n"
            f"2. Registrate con tu email\n"
            f"3. Sigue el tutorial interactivo\n\n"
            f"## Funcionalidades principales\n"
            f"- Gestion completa de tu negocio\n"
            f"- Panel de control intuitivo\n"
            f"- Notificaciones por email\n\n"
            f"## Soporte\n"
            f"Si necesitas ayuda, contacta soporte@kore.dev\n"
        )

    @staticmethod
    def _generate_tutorial(artifacts: dict[str, Any]) -> str:
        """Genera un tutorial paso a paso."""
        return (
            "# Tutorial Interactivo\n\n"
            "## Paso 1: Acceder a la aplicacion\n"
            "Abre tu navegador y ve a la URL proporcionada.\n\n"
            "## Paso 2: Crear tu cuenta\n"
            "Rellena el formulario de registro.\n\n"
            "## Paso 3: Configurar tu perfil\n"
            "Personaliza tu experiencia.\n\n"
            "## Paso 4: Empezar a usar\n"
            "Explora las funcionalidades principales.\n"
        )

    @staticmethod
    def _generate_faq(artifacts: dict[str, Any]) -> str:
        """Genera preguntas frecuentes."""
        return (
            "# Preguntas Frecuentes\n\n"
            "**Como cambio mi contrasena?**\n"
            "Ve a Configuracion > Seguridad > Cambiar contrasena.\n\n"
            "**Puedo usar la app en el movil?**\n"
            "Si, la aplicacion es responsive y funciona en cualquier dispositivo.\n\n"
            "**Como exporto mis datos?**\n"
            "Ve a Configuracion > Datos > Exportar.\n"
        )
