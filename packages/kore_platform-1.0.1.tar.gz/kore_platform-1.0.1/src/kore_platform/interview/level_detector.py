"""Level detector — vocabulary-based heuristic + optional LLM classification."""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass
from typing import TYPE_CHECKING

from ..domain.value_objects.technical_level import TechnicalLevel

if TYPE_CHECKING:
    from ..application.ports.outbound.llm_client import LLMClientPort

logger = logging.getLogger(__name__)


def _count_vocabulary_hits(text: str, vocabulary: frozenset[str]) -> int:
    """Count vocabulary hits using word boundaries to avoid false positives.

    E.g. 'class' won't match inside 'classification'.
    Multi-word terms (e.g. 'service mesh') use simple substring match
    since word boundaries don't apply across spaces.
    """
    text_lower = text.lower()
    hits = 0
    for term in vocabulary:
        if " " in term:
            # Multi-word: substring match is correct
            if term in text_lower:
                hits += 1
        else:
            # Single word: use word boundary regex
            if re.search(rf"\b{re.escape(term)}\b", text_lower):
                hits += 1
    return hits

# ---------------------------------------------------------------------------
# Vocabularios discriminativos por nivel (frozensets inmutables)
# ---------------------------------------------------------------------------

ENGINEER_VOCABULARY: frozenset[str] = frozenset({
    "kubernetes", "k8s", "terraform", "helm", "istio", "envoy",
    "service mesh", "sla", "slo", "sli", "observability", "grafana",
    "prometheus", "opentelemetry", "grpc", "protobuf", "cqrs",
    "event sourcing", "saga", "ddd", "bounded context", "aggregate",
    "hexagonal", "zero trust", "mTLS", "vault", "iam", "rbac",
    "threat model", "adr", "rfc", "runbook", "sre", "toil",
    "chaos engineering", "canary", "blue-green", "feature flag",
    "circuit breaker", "bulkhead", "backpressure", "idempotent",
    "exactly-once", "at-least-once", "cdc", "outbox pattern",
    "distributed tracing", "load balancer", "auto-scaling",
    "infrastructure as code", "gitops", "argocd", "flux",
})

SENIOR_DEV_VOCABULARY: frozenset[str] = frozenset({
    "docker", "ci/cd", "pipeline", "github actions", "gitlab ci",
    "redis", "postgresql", "mongodb", "elasticsearch", "rabbitmq",
    "kafka", "celery", "async", "await", "concurrency", "threading",
    "multiprocessing", "orm", "sqlalchemy", "alembic", "migration",
    "middleware", "decorator", "metaclass", "abstract", "interface",
    "dependency injection", "solid", "design pattern", "factory",
    "singleton", "strategy", "observer", "repository pattern",
    "unit test", "integration test", "mock", "fixture", "coverage",
    "profiling", "caching", "cdn", "nginx", "gunicorn", "uvicorn",
    "fastapi", "django", "flask", "express", "nestjs", "graphql",
    "websocket", "rest api", "openapi", "swagger", "jwt", "oauth",
    "microservices", "monorepo", "linting", "type hints", "mypy",
})

JUNIOR_DEV_VOCABULARY: frozenset[str] = frozenset({
    "python", "javascript", "typescript", "java", "react", "vue",
    "angular", "node", "npm", "pip", "git", "github", "html", "css",
    "api", "json", "http", "database", "sql", "function", "class",
    "variable", "loop", "array", "list", "dictionary", "object",
    "frontend", "backend", "fullstack", "framework", "library",
    "package", "module", "import", "export", "component", "state",
    "props", "hook", "route", "endpoint", "crud", "mvc",
    "responsive", "bootstrap", "tailwind", "webpack", "vite",
    "debug", "console", "print", "log", "error", "exception",
})


@dataclass(frozen=True, slots=True)
class LevelDetector:
    """Detecta el nivel tecnico del usuario por vocabulario + LLM opcional."""

    engineer_threshold: int = 3
    senior_threshold: int = 3
    junior_threshold: int = 2

    async def detect(
        self,
        message: str,
        llm_client: LLMClientPort | None = None,
    ) -> TechnicalLevel:
        """Analiza el mensaje y devuelve el nivel tecnico detectado.

        Si hay LLM disponible, lo usa para clasificar. Fallback: heuristica.
        """
        # Intentar con LLM primero
        if llm_client is not None:
            try:
                level = await self._detect_with_llm(message, llm_client)
                logger.info("level_detected_llm level=%s", level.name)
                return level
            except Exception as exc:
                logger.warning("llm_level_detection_failed error=%s, using heuristic", exc)

        return self._detect_heuristic(message)

    async def _detect_with_llm(
        self,
        message: str,
        llm_client: LLMClientPort,
    ) -> TechnicalLevel:
        """Clasifica nivel tecnico con LLM."""
        from ..agents.base.llm_utils import llm_json_call

        result = await llm_json_call(
            client=llm_client,
            system_prompt=(
                "Classify the technical level of the user based on their project description. "
                "Respond ONLY with JSON: {\"level\": \"NO_DEV|DEV_JUNIOR|DEV_SENIOR|ENGINEER\"}\n\n"
                "Levels:\n"
                "- NO_DEV: Non-technical user, uses no technical terms\n"
                "- DEV_JUNIOR: Knows basic programming concepts\n"
                "- DEV_SENIOR: Uses advanced patterns, frameworks, testing\n"
                "- ENGINEER: Enterprise architecture, infrastructure, observability"
            ),
            user_prompt=f"User's project idea: {message[:500]}",
            temperature=0.1,
            max_tokens=50,
        )

        level_str = result.get("level", "NO_DEV").upper()
        level_map = {lv.name: lv for lv in TechnicalLevel}
        return level_map.get(level_str, TechnicalLevel.NO_DEV)

    def _detect_heuristic(self, message: str) -> TechnicalLevel:
        """Deteccion por conteo de terminos discriminativos con word boundaries."""
        engineer_hits = _count_vocabulary_hits(message, ENGINEER_VOCABULARY)
        senior_hits = _count_vocabulary_hits(message, SENIOR_DEV_VOCABULARY)
        junior_hits = _count_vocabulary_hits(message, JUNIOR_DEV_VOCABULARY)

        logger.debug(
            "level_detection engineer=%d senior=%d junior=%d",
            engineer_hits, senior_hits, junior_hits,
        )

        if engineer_hits >= self.engineer_threshold:
            return TechnicalLevel.ENGINEER
        if senior_hits >= self.senior_threshold:
            return TechnicalLevel.DEV_SENIOR
        if junior_hits >= self.junior_threshold:
            return TechnicalLevel.DEV_JUNIOR
        return TechnicalLevel.NO_DEV
