"""Interviewer — main entry point for the interview system."""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from ..domain.entities.user_context import UserContext
from ..domain.value_objects.technical_level import TechnicalLevel
from .context_builder import ContextBuilder
from .level_detector import LevelDetector
from .question_selector import QuestionSelector

if TYPE_CHECKING:
    from ..application.ports.outbound.llm_client import LLMClientPort

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Respuestas auto-generadas para modo demo (sin input real del usuario)
# ---------------------------------------------------------------------------

_DEMO_ANSWERS: dict[str, dict[str, str]] = {
    TechnicalLevel.NO_DEV.name: {
        "problem": "Necesito una app para gestionar reservas de mi restaurante",
        "target_users": "Clientes del restaurante y personal de sala",
        "business_reqs": "Reservas online, confirmacion por email, calendario",
        "look_and_feel": "Moderna y facil de usar, colores calidos",
    },
    TechnicalLevel.DEV_JUNIOR.name: {
        "problem": "Sistema de gestion de tareas con autenticacion",
        "target_users": "Equipos pequenos de desarrollo",
        "business_reqs": "CRUD de tareas, asignacion, estados, filtros",
        "stack": "python,fastapi,postgresql,react",
        "deployment": "vercel,railway",
    },
    TechnicalLevel.DEV_SENIOR.name: {
        "problem": "API de procesamiento de pagos con alta disponibilidad",
        "target_users": "Comercios online, integradores de pagos",
        "business_reqs": "Procesamiento de pagos, reconciliacion, reportes",
        "stack": "python,fastapi,postgresql,redis,celery",
        "architecture": "hexagonal",
        "deployment": "docker,kubernetes",
        "technical_reqs": "latencia p99 < 200ms, 99.9% availability",
    },
    TechnicalLevel.ENGINEER.name: {
        "problem": "Plataforma de trading de alta frecuencia con compliance",
        "target_users": "Traders institucionales, compliance officers",
        "business_reqs": "Order matching, risk management, audit trail, reporting",
        "stack": "python,rust,postgresql,kafka,redis",
        "architecture": "event-driven CQRS con event sourcing",
        "deployment": "kubernetes,terraform,argocd",
        "technical_reqs": "latencia p99 < 10ms, throughput 100k msg/s, 99.99% SLA",
        "security_reqs": "mTLS, encryption at rest, RBAC, audit logging",
        "observability": "distributed tracing, custom metrics, Grafana dashboards",
        "ci_cd": "GitHub Actions, ArgoCD, canary deploys",
    },
}


# ---------------------------------------------------------------------------
# Answer Provider abstraction
# ---------------------------------------------------------------------------

class AnswerProvider(ABC):
    """Abstraccion para obtener respuestas a preguntas de entrevista."""

    @abstractmethod
    async def get_answer(self, question: str, context: str) -> str:
        """Devuelve una respuesta a la pregunta dada.

        Parameters
        ----------
        question:
            Texto de la pregunta.
        context:
            Contexto adicional (idea, nivel, respuestas previas).

        Returns
        -------
        str
            Respuesta del proveedor.
        """
        ...


class CLIAnswerProvider(AnswerProvider):
    """Proveedor interactivo: pregunta al usuario via stdin.

    El usuario real responde cada pregunta de la entrevista por teclado.
    answer_source sera "user".
    """

    async def get_answer(self, question: str, context: str) -> str:
        print(f"\n  > {question}")
        try:
            answer = input("    >> ").strip()
        except (EOFError, KeyboardInterrupt):
            answer = ""
        return answer


class WebAnswerProvider(AnswerProvider):
    """Proveedor de respuestas pre-recogidas via web UI.

    Las respuestas ya fueron recopiladas del usuario en el frontend
    y se pasan como dict. answer_source sera "user".
    """

    def __init__(self, answers: dict[str, str]) -> None:
        self._answers = answers
        self._idx = 0

    async def get_answer(self, question: str, context: str) -> str:
        # Buscar por key en el contexto (la pregunta contiene el texto)
        # Intentar matchear por key directa
        for key, value in self._answers.items():
            if key in question.lower() or question.lower() in key:
                return value
        # Fallback: devolver respuestas en orden
        keys = list(self._answers.keys())
        if self._idx < len(keys):
            answer = self._answers[keys[self._idx]]
            self._idx += 1
            return answer
        return ""


class LLMAutoAnswerProvider(AnswerProvider):
    """Usa un LLM para simular al usuario y generar respuestas ricas.

    Genera respuestas contextuales basadas en la idea original,
    mucho mas ricas que las respuestas hardcodeadas del demo mode.
    """

    def __init__(self, llm_client: LLMClientPort, idea: str) -> None:
        self._llm = llm_client
        self._idea = idea

    async def get_answer(self, question: str, context: str) -> str:
        from ..application.ports.outbound.llm_client import LLMMessage
        from ..agents.base.llm_utils import llm_text_call

        system = (
            "You are a product owner describing your project idea to a software team. "
            "Answer the question concisely but with enough technical detail to be useful. "
            "Base ALL answers on this project idea:\n\n"
            f"IDEA: {self._idea}\n\n"
            f"Previous context:\n{context}\n\n"
            "Answer in the same language as the question. Be specific, not vague."
        )

        answer = await llm_text_call(
            client=self._llm,
            system_prompt=system,
            user_prompt=question,
            temperature=0.4,
            max_tokens=300,
        )
        return answer.strip()


@dataclass
class Interviewer:
    """Entrevistador principal. Orquesta deteccion, preguntas y contexto.

    Modes:
    - demo_mode=True, answer_provider=None: respuestas hardcodeadas (retrocompat)
    - demo_mode=False, answer_provider=LLMAutoAnswerProvider: LLM genera respuestas
    - demo_mode=False, answer_provider=None: stub (respuestas vacias)
    """

    level_detector: LevelDetector = field(default_factory=LevelDetector)
    question_selector: QuestionSelector = field(default_factory=QuestionSelector)
    context_builder: ContextBuilder = field(default_factory=ContextBuilder)
    demo_mode: bool = True
    answer_provider: AnswerProvider | None = None
    llm_client: LLMClientPort | None = None

    async def interview(self, idea: str) -> UserContext:
        """Ejecuta la entrevista completa y devuelve un UserContext inmutable.

        Parameters
        ----------
        idea:
            La idea o descripcion inicial del usuario.

        Returns
        -------
        UserContext
            Contexto completo listo para generacion de plan.
        """
        logger.info("interview_start idea='%s' demo=%s llm=%s",
                     idea[:80], self.demo_mode, self.answer_provider is not None)

        # 1. Detectar nivel tecnico (con LLM si disponible)
        if self.llm_client is not None:
            level = await self.level_detector.detect(idea, llm_client=self.llm_client)
        else:
            level = await self.level_detector.detect(idea)
        logger.info("level_detected level=%s", level.name)

        # 2. Seleccionar preguntas
        questions = self.question_selector.select(level)
        logger.info("questions_selected count=%d", len(questions))

        # 3. Recoger respuestas y determinar fuente
        if isinstance(self.answer_provider, (CLIAnswerProvider, WebAnswerProvider)):
            answers = await self._collect_llm_answers(questions, idea, level)
            answer_source = "user"
        elif self.answer_provider is not None:
            answers = await self._collect_llm_answers(questions, idea, level)
            answer_source = "llm_auto"
        elif self.demo_mode:
            answers = self._generate_demo_answers(level, idea)
            answer_source = "demo"
        else:
            answers = await self._collect_answers(questions)
            answer_source = "stub"

        # 4. Construir contexto (con LLM enrichment si disponible)
        context = await self.context_builder.build(
            level=level,
            idea=idea,
            answers=answers,
            llm_client=self.llm_client,
            answer_source=answer_source,
        )

        logger.info(
            "interview_complete level=%s reqs=%d source=%s",
            context.level.name,
            len(context.business_requirements) + len(context.technical_requirements),
            answer_source,
        )
        return context

    async def _collect_llm_answers(
        self,
        questions: object,
        idea: str,
        level: TechnicalLevel,
    ) -> dict[str, str]:
        """Recolecta respuestas usando el LLM AnswerProvider."""
        from .question_selector import Question

        answers: dict[str, str] = {}
        context_so_far = f"Level: {level.name}\nIdea: {idea}"

        if isinstance(questions, (list, tuple)):
            for q in questions:
                if isinstance(q, Question):
                    answer = await self.answer_provider.get_answer(  # type: ignore[union-attr]
                        question=q.text,
                        context=context_so_far,
                    )
                    answers[q.key] = answer
                    context_so_far += f"\n{q.key}: {answer}"

        # Siempre usar la idea original como problema
        answers["problem"] = idea
        return answers

    def _generate_demo_answers(
        self,
        level: TechnicalLevel,
        idea: str,
    ) -> dict[str, str]:
        """Genera respuestas demo basadas en el nivel detectado."""
        base = dict(_DEMO_ANSWERS.get(level.name, {}))
        # La idea original siempre sobrescribe el problema demo
        base["problem"] = idea
        return base

    async def _collect_answers(
        self,
        questions: object,
    ) -> dict[str, str]:
        """Placeholder para recoleccion interactiva de respuestas.

        En produccion, esto se conectaria a un adaptador de I/O
        (CLI, WebSocket, API) via puerto inbound.
        """
        # Stub: devuelve respuestas vacias para modo no-demo
        from .question_selector import Question

        answers: dict[str, str] = {}
        if isinstance(questions, (list, tuple)):
            for q in questions:
                if isinstance(q, Question):
                    answers[q.key] = ""
        return answers
