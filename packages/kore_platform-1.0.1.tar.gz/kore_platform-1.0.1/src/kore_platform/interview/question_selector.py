"""Question selector — picks interview questions based on technical level."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Mapping, Sequence

from ..domain.value_objects.technical_level import TechnicalLevel
from ..infrastructure.i18n import t

# ---------------------------------------------------------------------------
# Banco de preguntas por nivel (key:i18n_key pairs)
# ---------------------------------------------------------------------------

_BASE_QUESTIONS: tuple[str, ...] = (
    "problem:q_problem",
    "target_users:q_target_users",
    "business_reqs:q_business_reqs",
)

_JUNIOR_QUESTIONS: tuple[str, ...] = (
    *_BASE_QUESTIONS,
    "stack:q_stack_junior",
    "deployment:q_deployment_junior",
)

_SENIOR_QUESTIONS: tuple[str, ...] = (
    *_BASE_QUESTIONS,
    "stack:q_stack_senior",
    "architecture:q_architecture_senior",
    "deployment:q_deployment_senior",
    "technical_reqs:q_technical_reqs_senior",
)

_ENGINEER_QUESTIONS: tuple[str, ...] = (
    *_BASE_QUESTIONS,
    "stack:q_stack_engineer",
    "architecture:q_architecture_engineer",
    "deployment:q_deployment_engineer",
    "technical_reqs:q_technical_reqs_engineer",
    "security_reqs:q_security_reqs",
    "observability:q_observability",
    "ci_cd:q_ci_cd",
)

_NO_DEV_QUESTIONS: tuple[str, ...] = (
    "problem:q_problem_nodev",
    "target_users:q_target_users_nodev",
    "business_reqs:q_business_reqs_nodev",
    "look_and_feel:q_look_and_feel",
)

_QUESTION_BANK: Mapping[TechnicalLevel, tuple[str, ...]] = {
    TechnicalLevel.NO_DEV: _NO_DEV_QUESTIONS,
    TechnicalLevel.DEV_JUNIOR: _JUNIOR_QUESTIONS,
    TechnicalLevel.DEV_SENIOR: _SENIOR_QUESTIONS,
    TechnicalLevel.ENGINEER: _ENGINEER_QUESTIONS,
}


@dataclass(frozen=True, slots=True)
class Question:
    """Una pregunta de entrevista."""

    key: str
    text: str


@dataclass(frozen=True, slots=True)
class QuestionSelector:
    """Selecciona preguntas de entrevista segun el nivel tecnico."""

    extra_questions: Mapping[TechnicalLevel, tuple[str, ...]] = field(
        default_factory=dict,
    )

    def select(self, level: TechnicalLevel) -> Sequence[Question]:
        """Devuelve la secuencia de preguntas para el nivel dado."""
        raw = _QUESTION_BANK.get(level, _BASE_QUESTIONS)
        extra = self.extra_questions.get(level, ())

        questions: list[Question] = []
        for entry in (*raw, *extra):
            key, i18n_key = entry.split(":", 1)
            # Translate the question text; fall back to key if not in catalog
            text = t(i18n_key.strip())
            questions.append(Question(key=key.strip(), text=text))
        return tuple(questions)

    @staticmethod
    def available_levels() -> tuple[TechnicalLevel, ...]:
        """Niveles con preguntas disponibles."""
        return tuple(_QUESTION_BANK.keys())
