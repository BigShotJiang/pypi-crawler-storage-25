"""Context builder — assembles UserContext from interview answers."""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import TYPE_CHECKING

from ..domain.entities.user_context import UserContext
from ..domain.services.interview_service import InterviewService
from ..domain.value_objects.technical_level import TechnicalLevel

if TYPE_CHECKING:
    from ..application.ports.outbound.llm_client import LLMClientPort

logger = logging.getLogger(__name__)


@dataclass(frozen=True, slots=True)
class ContextBuilder:
    """Construye un UserContext inmutable a partir de respuestas de entrevista.

    Delega la logica pura al InterviewService del dominio.
    """

    async def build(
        self,
        level: TechnicalLevel,
        idea: str,
        answers: dict[str, str],
        llm_client: LLMClientPort | None = None,
        answer_source: str = "demo",
    ) -> UserContext:
        """Construye el contexto del usuario.

        Parameters
        ----------
        level:
            Nivel tecnico detectado.
        idea:
            Idea original del usuario.
        answers:
            Mapa ``{question_key: answer_text}``.
        llm_client:
            Cliente LLM opcional para enriquecer contexto.
        answer_source:
            Origen de las respuestas: "demo", "llm_auto", "user", "stub".

        Returns
        -------
        UserContext
            Contexto inmutable listo para ejecucion.
        """
        # Enriquecer respuestas con LLM si disponible
        if llm_client is not None:
            answers = await self._enrich_with_llm(answers, idea, level, llm_client)

        context = InterviewService.build_context(
            level=level,
            idea=idea,
            answers=answers,
        )
        # Anotar fuente de respuestas en el contexto
        context = UserContext(
            level=context.level,
            original_idea=context.original_idea,
            problem_to_solve=context.problem_to_solve,
            target_users=context.target_users,
            preferred_stack=context.preferred_stack,
            architecture_pattern=context.architecture_pattern,
            deployment_target=context.deployment_target,
            business_requirements=context.business_requirements,
            technical_requirements=context.technical_requirements,
            test_coverage=context.test_coverage,
            needs_ci_cd=context.needs_ci_cd,
            needs_monitoring=context.needs_monitoring,
            security_requirements=context.security_requirements,
            compliance_requirements=context.compliance_requirements,
            answer_source=answer_source,
        )

        # Enriquecer con campos de seguridad para ENGINEER
        if level == TechnicalLevel.ENGINEER:
            security_reqs = frozenset(
                r.strip()
                for r in answers.get("security_reqs", "").split(",")
                if r.strip()
            )
            compliance_reqs = frozenset(
                r.strip()
                for r in answers.get("compliance_reqs", "").split(",")
                if r.strip()
            )
            if security_reqs or compliance_reqs:
                # Recrear con campos de seguridad (inmutabilidad preservada)
                context = UserContext(
                    level=context.level,
                    original_idea=context.original_idea,
                    problem_to_solve=context.problem_to_solve,
                    target_users=context.target_users,
                    preferred_stack=context.preferred_stack,
                    architecture_pattern=context.architecture_pattern,
                    deployment_target=context.deployment_target,
                    business_requirements=context.business_requirements,
                    technical_requirements=context.technical_requirements,
                    test_coverage=context.test_coverage,
                    needs_ci_cd=context.needs_ci_cd,
                    needs_monitoring=context.needs_monitoring,
                    security_requirements=security_reqs or context.security_requirements,
                    compliance_requirements=compliance_reqs or context.compliance_requirements,
                    answer_source=answer_source,
                )

        logger.info(
            "context_built level=%s stack=%s",
            context.level.name,
            context.preferred_stack,
        )
        return context

    @staticmethod
    async def _enrich_with_llm(
        answers: dict[str, str],
        idea: str,
        level: TechnicalLevel,
        llm_client: LLMClientPort,
    ) -> dict[str, str]:
        """Infiere requisitos implicitos con LLM."""
        try:
            from ..agents.base.llm_utils import llm_json_call

            existing = "\n".join(f"- {k}: {v}" for k, v in answers.items() if v)

            result = await llm_json_call(
                client=llm_client,
                system_prompt=(
                    "Given a project idea and some answers from the user, infer "
                    "additional implicit requirements. Respond with JSON:\n"
                    '{"business_reqs": "comma-separated list", '
                    '"technical_reqs": "comma-separated list", '
                    '"stack": "comma-separated technologies"}\n'
                    "Only add requirements that are clearly implied but not already stated. "
                    "If nothing to add, return empty strings."
                ),
                user_prompt=(
                    f"Project idea: {idea}\n"
                    f"Technical level: {level.name}\n"
                    f"Current answers:\n{existing}"
                ),
                temperature=0.3,
                max_tokens=300,
            )

            enriched = dict(answers)

            # Merge business reqs
            if result.get("business_reqs"):
                existing_reqs = enriched.get("business_reqs", "")
                if existing_reqs:
                    enriched["business_reqs"] = f"{existing_reqs}, {result['business_reqs']}"
                else:
                    enriched["business_reqs"] = result["business_reqs"]

            # Merge technical reqs
            if result.get("technical_reqs"):
                existing_reqs = enriched.get("technical_reqs", "")
                if existing_reqs:
                    enriched["technical_reqs"] = f"{existing_reqs}, {result['technical_reqs']}"
                else:
                    enriched["technical_reqs"] = result["technical_reqs"]

            # Merge stack (only if not already set)
            if result.get("stack") and not enriched.get("stack"):
                enriched["stack"] = result["stack"]

            logger.info("context_enriched_with_llm added_reqs=%s",
                        bool(result.get("business_reqs") or result.get("technical_reqs")))
            return enriched

        except Exception as exc:
            logger.warning("llm_enrichment_failed error=%s", exc)
            return answers
