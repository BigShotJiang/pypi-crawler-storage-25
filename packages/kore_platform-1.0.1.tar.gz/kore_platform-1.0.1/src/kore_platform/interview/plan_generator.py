"""Plan generator — creates execution plans from UserContext."""

from __future__ import annotations

import logging
import uuid
from dataclasses import dataclass, field
from typing import Any, Sequence

from ..domain.entities.user_context import UserContext
from ..domain.value_objects.technical_level import TechnicalLevel

logger = logging.getLogger(__name__)


@dataclass(frozen=True, slots=True)
class PlanStep:
    """Un paso individual del plan. Inmutable."""

    id: str
    agent: str
    action: str
    description: str
    inputs: dict[str, Any] = field(default_factory=dict)
    timeout_seconds: int = 300
    retries: int = 1
    parallel_group: str | None = None


@dataclass(frozen=True, slots=True)
class Plan:
    """Plan de ejecucion completo. Inmutable (frozen=True)."""

    id: str
    name: str
    description: str
    steps: Sequence[PlanStep] = field(default_factory=tuple)
    estimated_duration_minutes: int = 0
    requires_confirmation: bool = True
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def step_count(self) -> int:
        return len(self.steps)

    @property
    def parallel_groups(self) -> frozenset[str]:
        """Grupos de ejecucion paralela."""
        return frozenset(
            s.parallel_group for s in self.steps if s.parallel_group is not None
        )


def _sid() -> str:
    return f"step-{uuid.uuid4().hex[:8]}"


# ---------------------------------------------------------------------------
# Templates de pasos por nivel — using REAL agent:skill names
# ---------------------------------------------------------------------------

def _base_steps(context: UserContext) -> list[PlanStep]:
    """Pasos comunes a todos los niveles: requirements + architecture + code."""
    return [
        PlanStep(
            id=_sid(),
            agent="specs",
            action="analyze_requirements",
            description="Analizar requisitos del proyecto",
            inputs={"description": context.original_idea, "project_name": context.problem_to_solve[:40]},
            timeout_seconds=120,
        ),
        PlanStep(
            id=_sid(),
            agent="architect",
            action="design_architecture",
            description="Disenar arquitectura del sistema",
            inputs={},
            timeout_seconds=120,
        ),
        PlanStep(
            id=_sid(),
            agent="coder",
            action="implement_feature",
            description="Generar codigo fuente completo",
            inputs={"stack": list(context.preferred_stack)},
            timeout_seconds=600,
        ),
    ]


def _test_steps(context: UserContext) -> list[PlanStep]:
    """Pasos de testing: generar tests + ejecutarlos."""
    if context.test_coverage <= 0:
        return []
    return [
        PlanStep(
            id=_sid(),
            agent="tester",
            action="write_unit_tests",
            description=f"Generar tests unitarios (cobertura: {context.test_coverage}%)",
            inputs={"coverage_target": context.test_coverage},
            timeout_seconds=300,
        ),
        PlanStep(
            id=_sid(),
            agent="tester",
            action="run_tests",
            description="Ejecutar tests generados contra codigo generado",
            inputs={"test_path": "tests/"},
            timeout_seconds=300,
        ),
    ]


def _review_steps(context: UserContext) -> list[PlanStep]:
    """Pasos de code review para DEV_SENIOR+."""
    return [
        PlanStep(
            id=_sid(),
            agent="reviewer",
            action="code_review",
            description="Revision de calidad de codigo",
            inputs={},
            timeout_seconds=180,
            parallel_group="review",
        ),
        PlanStep(
            id=_sid(),
            agent="reviewer",
            action="security_review",
            description="Revision de seguridad",
            inputs={},
            timeout_seconds=180,
            parallel_group="review",
        ),
    ]


def _security_steps(context: UserContext) -> list[PlanStep]:
    """Pasos de seguridad para ENGINEER."""
    return [
        PlanStep(
            id=_sid(),
            agent="security",
            action="sast_scan",
            description="Escaneo SAST de seguridad",
            inputs={},
            timeout_seconds=300,
            parallel_group="security",
        ),
    ]


def _deploy_steps(context: UserContext) -> list[PlanStep]:
    """Pasos de deployment."""
    return [
        PlanStep(
            id=_sid(),
            agent="deployer",
            action="deploy_staging",
            description="Generar Dockerfile y docker-compose",
            inputs={},
            timeout_seconds=300,
        ),
    ]


def _docs_steps(context: UserContext) -> list[PlanStep]:
    """Pasos de documentacion."""
    return [
        PlanStep(
            id=_sid(),
            agent="documenter",
            action="generate_docs",
            description="Generar documentacion del proyecto",
            inputs={},
            timeout_seconds=180,
        ),
    ]


def _monitoring_steps(context: UserContext) -> list[PlanStep]:
    """Pasos de monitoring/observability."""
    if not context.needs_monitoring:
        return []
    return [
        PlanStep(
            id=_sid(),
            agent="monitor",
            action="setup_monitoring",
            description="Configurar monitoring y health checks",
            inputs={},
            timeout_seconds=180,
        ),
    ]


def _complexity_steps(context: UserContext, include_bottlenecks: bool = False) -> list[PlanStep]:
    """Pasos de analisis de complejidad. Solo SENIOR+ (CPU puro, sin LLM)."""
    steps = [
        PlanStep(
            id=_sid(),
            agent="complexity",
            action="analyze_structure",
            description="Analyze structural complexity of generated code",
            inputs={},
            timeout_seconds=30,
            retries=0,
            parallel_group="review",
        ),
    ]
    if include_bottlenecks:
        steps.append(
            PlanStep(
                id=_sid(),
                agent="complexity",
                action="detect_bottlenecks",
                description="Detect architectural bottlenecks",
                inputs={},
                timeout_seconds=30,
                retries=0,
                parallel_group="review",
            ),
        )
    return steps


# ---------------------------------------------------------------------------
# Duraciones estimadas por nivel (minutos)
# ---------------------------------------------------------------------------

_ESTIMATED_DURATIONS: dict[TechnicalLevel, int] = {
    TechnicalLevel.NO_DEV: 5,
    TechnicalLevel.DEV_JUNIOR: 8,
    TechnicalLevel.DEV_SENIOR: 12,
    TechnicalLevel.ENGINEER: 20,
}


@dataclass(frozen=True, slots=True)
class PlanGenerator:
    """Genera planes de ejecucion a partir de un UserContext."""

    async def generate(self, context: UserContext) -> Plan:
        """Genera un Plan completo basado en el contexto del usuario."""
        steps: list[PlanStep] = []

        # Pasos base: requirements + architecture + code (siempre)
        steps.extend(_base_steps(context))

        # Tests (si aplica)
        steps.extend(_test_steps(context))

        # Docs (DEV_JUNIOR+)
        if context.level != TechnicalLevel.NO_DEV:
            steps.extend(_docs_steps(context))

        # Review + complexity (DEV_SENIOR+)
        if context.level in (TechnicalLevel.DEV_SENIOR, TechnicalLevel.ENGINEER):
            steps.extend(_review_steps(context))
            include_bottlenecks = context.level == TechnicalLevel.ENGINEER
            steps.extend(_complexity_steps(context, include_bottlenecks=include_bottlenecks))

        # Seguridad + monitoring (solo ENGINEER)
        if context.level == TechnicalLevel.ENGINEER:
            steps.extend(_security_steps(context))
            steps.extend(_monitoring_steps(context))

        # Deploy (DEV_SENIOR+)
        if context.level in (TechnicalLevel.DEV_SENIOR, TechnicalLevel.ENGINEER):
            steps.extend(_deploy_steps(context))

        plan = Plan(
            id=f"plan-{uuid.uuid4().hex[:8]}",
            name=f"Plan: {context.original_idea[:60]}",
            description=(
                f"Plan de ejecucion para '{context.problem_to_solve}' "
                f"(nivel: {context.level.name}, {len(steps)} pasos)"
            ),
            steps=tuple(steps),
            estimated_duration_minutes=_ESTIMATED_DURATIONS.get(context.level, 10),
            requires_confirmation=True,
            metadata={
                "level": context.level.name,
                "stack": list(context.preferred_stack),
                "test_coverage": context.test_coverage,
            },
        )

        logger.info(
            "plan_generated id=%s steps=%d duration=%dm",
            plan.id, plan.step_count, plan.estimated_duration_minutes,
        )
        return plan
