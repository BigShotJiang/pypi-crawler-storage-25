# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.0] - 2026-02-26

### Added
- Core flow engine with declarative YAML-based flow definitions.
- Pydantic v2 schema validation for all flow configurations.
- Cryptographic flow signing and verification (HMAC-SHA256).
- Multi-model LLM support (OpenAI, Anthropic) via provider abstraction.
- Redis-backed state management and caching layer.
- Agent sandboxing with configurable permission boundaries.
- OpenTelemetry-based distributed tracing integration.
- Prometheus metrics export for observability.
- Structured logging via structlog.
- Docker multi-stage builds with non-root runtime user.
- Docker Compose configurations for development and production.
- Comprehensive CI/CD pipelines (lint, type-check, test, security, release).
- Pre-commit hooks for code quality enforcement.
- Full test suite with pytest, pytest-asyncio, and coverage reporting.
- MIT license.

[1.0.0]: https://github.com/iafiscal1212/kore-platform/releases/tag/v1.0.0
