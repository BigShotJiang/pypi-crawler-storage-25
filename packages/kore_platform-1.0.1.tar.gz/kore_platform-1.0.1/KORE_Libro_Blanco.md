# KORE Platform — Libro Blanco

**Generacion automatica de software mediante orquestacion de agentes IA**

Version 1.0 | Febrero 2026 | IAFiscal

---

## Indice

1. [Resumen Ejecutivo](#1-resumen-ejecutivo)
2. [El Problema](#2-el-problema)
3. [La Solucion: KORE](#3-la-solucion-kore)
4. [Arquitectura del Sistema](#4-arquitectura-del-sistema)
5. [Pipeline de Generacion](#5-pipeline-de-generacion)
6. [Los 10 Agentes Especializados](#6-los-10-agentes-especializados)
7. [Sistema de Entrevista Inteligente](#7-sistema-de-entrevista-inteligente)
8. [Self-Validation Loop](#8-self-validation-loop)
9. [Few-Shot Learning](#9-few-shot-learning)
10. [Seguridad: AEGIS Guardian](#10-seguridad-aegis-guardian)
11. [Modelo de Delivery por Niveles](#11-modelo-de-delivery-por-niveles)
12. [Interfaz de Usuario](#12-interfaz-de-usuario)
13. [Privacidad: Ejecucion 100% Local](#13-privacidad-ejecucion-100-local)
14. [Stack Tecnologico](#14-stack-tecnologico)
15. [Rendimiento y Metricas](#15-rendimiento-y-metricas)
16. [Casos de Uso](#16-casos-de-uso)
17. [Comparativa con Alternativas](#17-comparativa-con-alternativas)
18. [Limitaciones Conocidas](#18-limitaciones-conocidas)
19. [Hoja de Ruta](#19-hoja-de-ruta)
20. [Instalacion y Uso](#20-instalacion-y-uso)
21. [Licencia y Distribucion](#21-licencia-y-distribucion)

---

## 1. Resumen Ejecutivo

KORE Platform es un sistema de generacion automatica de software que transforma una idea expresada en lenguaje natural en un proyecto completo y funcional: codigo fuente, tests, documentacion, configuracion de despliegue y escaneos de seguridad.

El sistema orquesta 10 agentes de inteligencia artificial especializados a traves de un pipeline configurable. Cada agente domina un aspecto del desarrollo de software — desde el analisis de requisitos hasta la monitorizacion en produccion — y sus artefactos fluyen entre ellos de forma encadenada, construyendo cada fase sobre la anterior.

**Propuesta de valor central:** Un usuario introduce una frase describiendo lo que necesita. KORE genera un proyecto completo, intenta validarlo ejecutando tests generados contra el codigo, y si detecta fallos, los re-intenta automaticamente. El resultado es un punto de partida estructurado que requiere revision humana, no un producto terminado.

**Diferenciadores clave:**

- **Ejecucion 100% local.** Sin servidores, sin cuentas, sin datos personales en la nube. El usuario instala el paquete y todo se ejecuta en su maquina.
- **Agnostico de proveedor LLM.** Funciona con Ollama (gratuito, local), OpenAI, o Anthropic. El usuario elige.
- **Self-validation.** KORE no solo genera codigo — lo ejecuta, detecta errores, y los corrige automaticamente hasta 3 veces.
- **Adaptacion al nivel tecnico.** Un restaurador sin conocimientos de programacion y un ingeniero senior reciben entregas diferentes, adaptadas a su contexto.

---

## 2. El Problema

### 2.1 La brecha entre idea y ejecucion

El desarrollo de software moderno es un proceso que requiere multiples disciplinas coordinadas: analisis de requisitos, diseno de arquitectura, implementacion, testing, documentacion, seguridad y despliegue. Incluso para un desarrollador experimentado, crear un proyecto desde cero implica horas de trabajo repetitivo antes de escribir la primera linea de logica de negocio.

Para un no-desarrollador — un emprendedor, un gestor de negocio, un profesional de otro sector — esta barrera es insalvable. Tienen la idea, pero no el conocimiento tecnico para materializarla.

### 2.2 Limitaciones de las herramientas actuales

Las herramientas existentes de generacion de codigo con IA presentan varios problemas:

| Problema | Descripcion |
|----------|-------------|
| **Codigo fragmentario** | Generan funciones aisladas, no proyectos completos |
| **Sin validacion** | El codigo generado frecuentemente no compila o tiene errores |
| **Sin contexto** | No entienden requisitos implicitos del dominio |
| **Dependencia de la nube** | Requieren enviar codigo y datos a servidores externos |
| **Un solo modelo** | Atados a un proveedor de IA especifico |
| **Sin adaptacion** | Tratan igual a un principiante que a un senior |

### 2.3 El coste del boilerplate

Estudios de la industria estiman que entre el 40% y el 60% del tiempo de desarrollo en un nuevo proyecto se dedica a tareas repetitivas: configuracion del entorno, estructura de carpetas, boilerplate de frameworks, setup de tests, configuracion de Docker, CI/CD, y documentacion basica. KORE elimina esta carga por completo.

---

## 3. La Solucion: KORE

KORE (Knowledge-Orchestrated Runtime Engine) es una plataforma de generacion de software que aborda cada uno de estos problemas de forma sistematica.

### 3.1 Principios de diseno

1. **Una idea, un proyecto completo.** El input es una frase. El output es un directorio con todos los archivos necesarios para ejecutar el proyecto.

2. **Agentes especializados, no un modelo monolitico.** En lugar de pedir a un solo LLM que lo haga todo, KORE descompone el trabajo en 10 agentes, cada uno con prompts optimizados para su dominio.

3. **Artefactos encadenados.** Cada agente recibe los artefactos del anterior. El arquitecto construye sobre los requisitos. El coder construye sobre la arquitectura. Los tests se basan en el codigo. Esta cadena garantiza coherencia.

4. **Validacion real.** KORE ejecuta los tests generados contra el codigo generado. Si fallan, re-invoca al agente coder con los errores para que los corrija. Hasta 3 intentos automaticos.

5. **Privacidad por defecto.** Todo se ejecuta localmente. No hay servidor central. No hay telemetria. No se envian datos a ningun sitio salvo al LLM que el usuario configure.

6. **Adaptacion al usuario.** KORE detecta el nivel tecnico del usuario y adapta el plan de ejecucion, las preguntas de entrevista, y el formato de entrega.

### 3.2 Flujo general

```
  Idea del usuario
       |
       v
  [Entrevista] --- Detecta nivel, genera preguntas, enriquece contexto
       |
       v
  [Planificacion] --- Genera plan con N pasos segun nivel
       |
       v
  [Ejecucion] --- 10 agentes en secuencia/paralelo
       |
       v
  [Validacion] --- Ejecuta tests, corrige errores automaticamente
       |
       v
  [Entrega] --- Workspace con proyecto completo
```

---

## 4. Arquitectura del Sistema

### 4.1 Arquitectura Hexagonal

KORE implementa una arquitectura hexagonal (ports & adapters) con tres capas bien definidas:

```
+----------------------------------------------------------+
|                    DOMINIO (core)                          |
|  Entidades: Job, UserContext, Flow, Agent, Step            |
|  Value Objects: JobId, TechnicalLevel, ExecutionResult     |
|  Eventos: JobCreated, AgentStarted, StepCompleted         |
|  Servicios: InterviewService                              |
+----------------------------------------------------------+
|                   APLICACION                               |
|  Puertos Inbound: ExecuteJob, Interview                    |
|  Puertos Outbound: LLMClient, Storage, MessageBus, Audit  |
|  Casos de Uso: ExecuteJobUseCase, InterviewUseCase         |
|  DTOs: JobResultDTO, DeliveryDTO, InterviewDTO             |
+----------------------------------------------------------+
|                 INFRAESTRUCTURA                             |
|  Adaptadores LLM: Ollama, OpenAI, Anthropic               |
|  Storage: FileStorage, PostgresStorage                     |
|  Bus: MemoryBus, RedisBus                                  |
|  Seguridad: Guardian, SandboxManager, SignatureVerifier     |
|  Observabilidad: Logging, Metrics, Tracing, Health         |
|  Config: Settings (inmutable), Container (DI)              |
+----------------------------------------------------------+
```

### 4.2 Inmutabilidad como principio

Todas las estructuras de datos del dominio son inmutables (`frozen=True`, `slots=True`). Esto incluye:

- **UserContext**: el estado del usuario tras la entrevista
- **Plan** y **PlanStep**: el plan de ejecucion
- **ExecutionResult** y **StepResult**: resultados de cada paso
- **JobId**: identificador unico de cada trabajo
- **GuardianResult**: resultado de validaciones de seguridad

La inmutabilidad garantiza que ningun componente puede alterar accidentalmente el estado de otro, eliminando una clase entera de bugs relacionados con estado compartido.

### 4.3 Inyeccion de Dependencias

El `Container` centraliza la creacion de todos los componentes con inicializacion perezosa (lazy). Los componentes se crean solo cuando se necesitan:

- **Bus de mensajes:** MemoryBus en desarrollo, RedisBus en produccion
- **Audit log:** Append-only, inmutable, verificable
- **LLM Client:** Seleccion automatica segun `KORE_LLM_PROVIDER`
- **Agent Registry:** 10 agentes con LLM inyectado automaticamente
- **Workspace Manager:** Gestion de directorios de trabajo por job

### 4.4 Estructura de directorios

```
kore-platform/
  src/kore_platform/
    agents/                     # 10 agentes, 29 skills
      base/                     # Abstracciones: BaseAgent, BaseSkill, few_shot
      examples/                 # Ejemplos few-shot para mejorar calidad
      specs/architect/coder/    # Agentes especializados
      tester/reviewer/security/
      deployer/documenter/monitor/complexity/
    application/                # Capa de aplicacion
      dto/                      # Objetos de transferencia
      ports/inbound/outbound/   # Puertos hexagonales
      use_cases/                # Casos de uso
    domain/                     # Nucleo de dominio
      entities/                 # Job, UserContext, Flow, Agent, Step
      events/                   # Eventos de dominio
      exceptions/               # Excepciones tipadas
      services/                 # Servicios de dominio
      value_objects/            # Objetos de valor inmutables
    infrastructure/             # Adaptadores concretos
      adapters/inbound/         # CLI, API
      adapters/outbound/        # LLM clients, storage, bus
      config/                   # Settings, Container DI
      observability/            # Logging, metricas, tracing
      security/                 # Guardian, sandbox, crypto
      workspace/                # Gestion de workspaces
    orchestration/              # Motor de ejecucion
      orchestrator.py           # Orquestador principal
      validation_loop.py        # Loop de auto-validacion
      subprocess_runner.py      # Ejecucion de subprocesos
      flow_engine.py            # Motor de flujos YAML
      parallel_executor.py      # Ejecucion paralela
    interview/                  # Sistema de entrevista
      interviewer.py            # Orquestador de entrevista + LLM
      level_detector.py         # Deteccion de nivel + LLM
      context_builder.py        # Construccion de contexto + LLM
      plan_generator.py         # Generacion de planes
      question_selector.py      # Seleccion de preguntas
    delivery/                   # Empaquetado de entregas
    web.py                      # Interfaz web local
    cli.py                      # Entry point CLI
  tests/                        # 131 tests
  flows/                        # Definiciones YAML
  questions/                    # Bancos de preguntas
```

---

## 5. Pipeline de Generacion

### 5.1 Fases del pipeline

El pipeline de KORE tiene 6 fases principales:

**Fase 1: Creacion del Job**
Se crea una entidad `Job` con estado `CREATED`. Cada job tiene un `JobId` unico (UUID). El job transiciona por estados inmutables: CREATED -> INTERVIEWING -> PLANNING -> AWAITING_CONFIRMATION -> EXECUTING -> DELIVERING -> COMPLETED.

**Fase 2: Entrevista**
El sistema de entrevista detecta el nivel tecnico del usuario, selecciona preguntas relevantes, recopila respuestas (via LLM o demo mode), y construye un `UserContext` inmutable con toda la informacion necesaria.

**Fase 3: Planificacion**
El `PlanGenerator` crea un `Plan` inmutable con N pasos basados en el nivel tecnico. Cada paso especifica: agente, skill, descripcion, inputs, timeout, reintentos, y grupo de ejecucion paralela.

**Fase 4: Ejecucion**
El `Orchestrator` ejecuta cada paso del plan:
- Valida la accion con el Guardian
- Enriquece los inputs con artefactos de pasos anteriores
- Invoca al agente real (o stub en demo mode)
- Escribe archivos generados al workspace
- Publica eventos al bus de mensajes

**Fase 5: Validacion**
Tras ejecutar todos los pasos, si hay codigo y tests generados, el `ValidationLoop` los ejecuta. Si los tests fallan, re-invoca al coder con los errores. Hasta 3 intentos.

**Fase 6: Entrega**
El `DeliveryFactory` crea la entrega apropiada segun el nivel tecnico (Simple, Technical, o Enterprise) y empaqueta todo en un DTO inmutable.

### 5.2 Flujo de artefactos entre agentes

Los artefactos fluyen entre agentes automaticamente a traves del sistema de enriquecimiento de inputs:

```
specs:analyze_requirements  ->  "requirements"  ->  architect:design_architecture
architect:design_architecture  ->  "architecture"  ->  coder:implement_feature
coder:implement_feature  ->  "files", "code"  ->  tester:write_unit_tests
tester:write_unit_tests  ->  "test_files"  ->  tester:run_tests
coder + tester  ->  validation_loop  ->  codigo corregido
```

Este encadenamiento garantiza que cada agente trabaja con el contexto completo de lo que los agentes anteriores han producido.

### 5.3 Ejecucion paralela

Ciertos pasos se pueden ejecutar en paralelo cuando no tienen dependencias entre si. KORE agrupa estos pasos mediante `parallel_group`:

- **Grupo "review":** code_review + security_review + complexity:analyze_structure (simultaneos). Para nivel ENGINEER, se anade tambien complexity:detect_bottlenecks.
- **Grupo "security":** sast_scan + dependency_scan (simultaneos)

Ejemplo del grupo "review" expandido:

```
parallel_group "review":
  - reviewer:code_review
  - reviewer:security_review
  - complexity:analyze_structure  <-- NUEVO
  - complexity:detect_bottlenecks <-- solo ENGINEER
```

El `ParallelExecutor` usa `asyncio.gather` con un semaforo configurable para controlar la concurrencia maxima.

---

## 6. Los 10 Agentes Especializados

Cada agente hereda de `BaseAgent` y registra sus skills. Todos siguen el mismo patron: reciben inputs + contexto, llaman al LLM con prompts especializados, y devuelven artefactos estructurados.

### 6.1 Specs Agent
**Rol:** Analista de requisitos
**Skills:** `analyze_requirements`, `generate_user_stories`

Extrae del texto natural: requisitos funcionales, no funcionales, entidades del dominio, stack tecnologico sugerido, y prioridades. Produce un JSON estructurado que alimenta al arquitecto.

### 6.2 Architect Agent
**Rol:** Arquitecto de software
**Skills:** `design_architecture`, `generate_schemas`, `create_api_spec`

Disena la estructura del sistema: componentes, patrones (MVC, hexagonal, CQRS), modelos de datos, especificacion de API (endpoints, metodos, schemas de request/response). Decide la organizacion de carpetas y modulos.

### 6.3 Coder Agent
**Rol:** Desarrollador senior
**Skills:** `implement_feature`, `refactor`, `write_code`

Genera codigo fuente completo, archivo por archivo. Cada archivo incluye imports correctos, type hints, docstrings, y logica funcional completa. Utiliza few-shot examples para mejorar la calidad del output. Soporta modo de correccion: si recibe `fix_errors`, ajusta el codigo para resolver los fallos reportados.

### 6.4 Tester Agent
**Rol:** Ingeniero QA
**Skills:** `write_unit_tests`, `write_integration_tests`, `run_tests`

Genera tests unitarios con pytest, incluyendo fixtures, mocks, y assertions. La skill `run_tests` ejecuta los tests reales via subprocess contra el codigo generado, devolviendo exit_code, stdout, y stderr reales.

### 6.5 Reviewer Agent
**Rol:** Revisor de codigo
**Skills:** `code_review`, `performance_review`, `security_review`

Analiza el codigo generado buscando: code smells, violaciones de principios SOLID, problemas de rendimiento, vulnerabilidades de seguridad, y oportunidades de mejora.

### 6.6 Security Agent
**Rol:** Ingeniero de seguridad
**Skills:** `sast_scan`, `dependency_scan`, `secret_scan`

Ejecuta analisis estatico de seguridad: detecta inyecciones SQL, XSS, vulnerabilidades de dependencias, y secretos hardcodeados en el codigo.

### 6.7 Deployer Agent
**Rol:** Ingeniero DevOps
**Skills:** `deploy_staging`, `deploy_production`, `rollback`

Genera configuracion de despliegue: Dockerfile multi-stage, docker-compose, manifiestos de Kubernetes (para nivel ENGINEER), y scripts de CI/CD.

### 6.8 Documenter Agent
**Rol:** Technical writer
**Skills:** `generate_docs`, `generate_manual`, `generate_video_script`

Produce documentacion completa: README del proyecto, documento de arquitectura, referencia de API, guia de configuracion, y manual de usuario.

### 6.9 Monitor Agent
**Rol:** Ingeniero de observabilidad
**Skills:** `setup_monitoring`, `create_alerts`, `analyze_metrics`

Configura health checks, metricas Prometheus, alertas, y dashboards. Solo se activa para nivel ENGINEER.

### 6.10 ComplexityAgent

**Rol:** Analizador de complejidad estructural
**Skills:** `analyze_structure`, `detect_bottlenecks`
**Requiere LLM:** No — analisis determinista en CPU
**Dependencia:** `qubit-algebra` (opcional)

El unico agente que no usa LLM. Analiza el grafo de dependencias del codigo generado usando algebra de Clifford (via la libreria `qal`).

**analyze_structure:**
1. Parsea los archivos Python con `ast.parse` (no regex) para extraer imports internos
2. Construye un grafo de dependencias entre modulos
3. Calcula metricas via `qal.GraphAlgebra.structural_complexity()`:
   - Complejidad ciclomatica (caminos independientes)
   - Entrelazamiento (0.0 = desacoplado, 1.0 = todo depende de todo)
   - Profundidad de dependencias
   - Numero de ciclos (dependencias circulares)
4. Asigna un rating A/B/C/D/F con umbrales configurables
5. Genera warnings sobre dependencias circulares y modulos altamente acoplados

**detect_bottlenecks** (solo ENGINEER):
1. Usa `qal.GraphAlgebra.pigeonhole_analysis()` para detectar nodos sobrecargados
2. Cruza con la arquitectura del ArchitectAgent: un modulo "database" con muchos dependientes es esperable; un modulo "utils" con el mismo patron es problematico
3. Genera recomendaciones: splitting de modulos, connection pooling, etc.

**Fallback:** Si `qubit-algebra` no esta instalado, el agente usa deteccion basica de ciclos por DFS y cuenta de dependencias. KORE funciona sin esta dependencia.

| Nivel | analyze_structure | detect_bottlenecks |
|-------|:-:|:-:|
| NO_DEV | — | — |
| DEV_JUNIOR | — | — |
| DEV_SENIOR | Si | — |
| ENGINEER | Si | Si |

---

## 7. Sistema de Entrevista Inteligente

### 7.1 Deteccion de nivel tecnico

KORE clasifica automaticamente al usuario en 4 niveles:

| Nivel | Descripcion | Ejemplo de idea |
|-------|-------------|-----------------|
| **NO_DEV** | Sin conocimientos tecnicos | "Necesito una app para mi restaurante" |
| **DEV_JUNIOR** | Conoce conceptos basicos | "Un CRUD de tareas con React y Node" |
| **DEV_SENIOR** | Usa patrones avanzados | "API REST con FastAPI, PostgreSQL, Redis, JWT auth" |
| **ENGINEER** | Arquitectura enterprise | "Plataforma event-driven con CQRS, Kafka, K8s, mTLS" |

La deteccion funciona en dos capas:

1. **LLM (primario):** Si hay un LLM disponible, clasifica el mensaje con un prompt especializado. Rapido y preciso.
2. **Heuristica (fallback):** Cuenta terminos discriminativos por vocabulario. Cada nivel tiene un conjunto de ~40 terminos. Si el LLM no esta disponible, esta heuristica decide.

### 7.2 Modos de recoleccion de respuestas

KORE soporta tres modos de recoleccion de respuestas a las preguntas de entrevista:

| Modo | Clase | Activacion | Descripcion |
|------|-------|-----------|-------------|
| **Interactivo CLI** | `CLIAnswerProvider` | Por defecto | El usuario responde cada pregunta por teclado |
| **Interactivo Web** | `WebAnswerProvider` | Web UI | Las respuestas se recogen en un formulario web |
| **Auto (LLM)** | `LLMAutoAnswerProvider` | `--auto` flag | El LLM simula las respuestas del usuario |

**Modo interactivo (por defecto):** KORE detecta el nivel tecnico, selecciona las preguntas apropiadas, y las presenta al usuario una a una. Las respuestas reales del usuario producen contexto mucho mas preciso que las auto-generadas.

**Modo auto:** El `LLMAutoAnswerProvider` simula al usuario usando el LLM. En lugar de respuestas hardcodeadas genericas, genera respuestas contextuales basadas en la idea original. Esto produce contextos mas ricos que las respuestas demo estaticas, pero las respuestas auto-generadas pueden no reflejar las necesidades reales del usuario.

El campo `answer_source` en `UserContext` registra el origen: `"user"` (interactivo), `"llm_auto"` (auto-mode), `"demo"` (hardcodeado), o `"stub"` (vacio).

### 7.3 Enriquecimiento de contexto

El `ContextBuilder` usa el LLM para inferir requisitos implicitos que el usuario no menciono pero que son necesarios:

- Si la idea menciona "API", el LLM infiere que se necesita autenticacion, validacion de inputs, y manejo de errores.
- Si menciona "e-commerce", infiere que se necesita gestion de pagos, inventario, y notificaciones.

Los requisitos inferidos se fusionan con los explicitos, produciendo un `UserContext` mas completo.

### 7.4 Generacion de plan adaptativo

El plan de ejecucion se adapta al nivel tecnico:

| Nivel | Pasos | Incluye |
|-------|-------|---------|
| NO_DEV | 3 | Specs + Architecture + Code |
| DEV_JUNIOR | 5 | + Tests + Docs |
| DEV_SENIOR | 8 | + Review + Security Review + Deploy + Run Tests |
| ENGINEER | 10 | + SAST + Monitoring + Deploy |

---

## 8. Self-Validation Loop

### 8.1 El problema de la calidad

Los LLMs generan codigo que parece correcto pero frecuentemente tiene errores sutiles: imports que no existen, variables mal nombradas, funciones que no respetan la firma esperada. Sin validacion, estos errores pasan desapercibidos hasta que un humano intenta ejecutar el codigo.

### 8.2 La solucion: test-driven auto-correction

KORE implementa un loop de validacion automatica:

```
+----> Escribir archivos al workspace
|      |
|      v
|    pip install dependencias
|      |
|      v
|    pytest --tb=short
|      |
|   +--+--+
|   |     |
|  PASS  FAIL
|   |     |
|   v     v
|  OK   Coder recibe errores
|        "Fix these failures: ..."
|        |
+--------+  (hasta 3 intentos)
```

### 8.3 Componentes

**SubprocessRunner:** Ejecuta comandos externos de forma asincrona con `asyncio.create_subprocess_exec`. Timeout configurable. Captura completa de stdout/stderr. Manejo robusto de errores y timeouts.

**ValidationLoop:** Orquesta el ciclo completo:

1. Escribe los archivos de codigo y tests al workspace
2. Genera un `requirements-test.txt` con dependencias minimas
3. Instala dependencias en `.deps/` (aislado del sistema)
4. Ejecuta `pytest` con `PYTHONPATH` apuntando al workspace
5. Si los tests pasan: retorna exito
6. Si fallan: extrae hasta 4000 caracteres de errores priorizando lineas de error (ImportError, AssertionError, etc.) y los pasa al Coder Agent como `fix_errors`
7. El Coder regenera el codigo con el contexto de los errores
8. Repite hasta 3 veces

### 8.4 Inyeccion de errores en el prompt

Cuando el ValidationLoop detecta fallos, anade al prompt del coder:

```
IMPORTANT: The previous code had these test failures:
[stderr output, smart-extracted up to 4000 chars]

Fix ALL errors. Make sure imports are correct, all referenced
modules exist, and the code passes tests.
```

Esto le da al LLM contexto concreto sobre que corregir, en lugar de regenerar a ciegas.

---

## 9. Few-Shot Learning

### 9.1 Por que few-shot

Los LLMs mejoran dramaticamente su output cuando se les muestra un ejemplo concreto del formato esperado. Sin ejemplo, tienden a generar codigo incompleto, con placeholders, o con estructura incorrecta.

### 9.2 Implementacion

KORE incluye dos ejemplos curados:

**fastapi_crud.txt:** Un proyecto FastAPI completo con 6 archivos funcionales:
- `main.py` con startup event y router
- `database.py` con SQLAlchemy async
- `models.py` con modelo SQLAlchemy
- `schemas.py` con Pydantic v2
- `routes.py` con CRUD completo (5 endpoints)
- `pyproject.toml` con dependencias correctas

**pytest_example.txt:** Suite de tests completa:
- `conftest.py` con fixtures asincroncas, session de test, y override de dependencias
- `test_items.py` con 5 tests reales (create, list, get, update, delete)

### 9.3 Integracion

La funcion `build_few_shot_prompt()` concatena el ejemplo al system prompt:

```
[System prompt original]

--- EXAMPLE OUTPUT (follow this format) ---
[Contenido del ejemplo]
--- END EXAMPLE ---
```

El ejemplo se trunca a 3000 caracteres para no exceder la ventana de contexto. Los skills del Coder y Tester usan estos ejemplos automaticamente.

---

## 10. Seguridad: AEGIS Guardian

### 10.1 Modelo Zero-Trust

KORE implementa un Guardian que valida TODAS las acciones antes de su ejecucion. No se confia en ningun agente por defecto.

### 10.2 Validaciones

**Comandos:** Solo se permiten comandos de una whitelist: `python`, `pip`, `git`, `npm`, `docker`, `pytest`, etc. Cualquier otro comando es bloqueado.

**Patrones peligrosos:** Se detectan y bloquean patrones como:
- `rm -rf /`, `sudo`, `chmod 777`
- `curl | bash`, `eval(`, `exec(`, `__import__`
- `DROP TABLE`, `TRUNCATE TABLE`
- `subprocess.call`, `os.system`

**Paths:** Solo se permite acceso a directorios controlados: `/workspace/`, `/tmp/kore/`, `/home/kore/`.

**Inputs de agentes:** Los inputs de cada agente se escanean contra los mismos patrones peligrosos.

### 10.3 Audit trail

Cada validacion queda registrada en un audit log inmutable (append-only). Se puede consultar el historial completo de acciones permitidas y bloqueadas.

### 10.4 Firma criptografica

Los flujos YAML pueden firmarse criptograficamente. El `SignatureVerifier` verifica la firma antes de ejecutar un flujo, garantizando que no ha sido modificado.

### 10.5 Modelo de amenazas

El Guardian opera bajo un modelo de amenazas explicito documentado en el codigo fuente (`guardian.py`):

| Adversario | Probabilidad | Descripcion | Mitigacion |
|-----------|-------------|-------------|------------|
| Inyeccion de prompt | Alta | Usuario crafteado que causa codigo peligroso | Pattern matching + regex obfuscacion + resource limits |
| Output hostil del LLM | Media | LLM alucina constructos peligrosos | Misma que adversario 1 + deteccion de tests triviales |
| Supply-chain via pip | Media | requirements.txt con paquetes maliciosos | `--only-binary :all:` (fallback a sdist con warning) |
| Path traversal / symlink | Baja | Paths que escapan del workspace | `check_symlink_escape()` + resolucion de paths |
| DoS por agotamiento | Media | Loops infinitos, fork bombs, allocations | `resource.setrlimit` + timeouts en subprocess |

**Gaps conocidos:** No hay sandbox a nivel de contenedor (nsjail/bubblewrap planificado en v1.1). El pattern matching es eludible por ofuscacion creativa. El fallback a sdist ejecuta setup.py (se registra warning).

### 10.6 Proteccion CSRF en la Web UI

La API web implementa doble defensa contra CSRF:

1. **Token CSRF:** Cada instancia del servidor genera un token unico (`secrets.token_urlsafe`). Todo POST requiere header `X-KORE-Token`.
2. **Validacion Origin:** Si el navegador envia header `Origin`, se verifica que sea localhost (`127.0.0.1` o `localhost`). Requests de otros origenes son rechazados con 403.

---

## 11. Modelo de Delivery por Niveles

### 11.1 SimpleDelivery (NO_DEV)

Para usuarios sin conocimientos tecnicos. Genera:
- Mockup HTML basico
- Resumen de funcionalidades
- Instrucciones simples de uso

### 11.2 TechnicalDelivery (DEV_JUNIOR / DEV_SENIOR)

Para desarrolladores. Genera:
- Estructura completa del proyecto
- Codigo fuente con imports, types, docstrings
- Tests unitarios con pytest
- Dockerfile y docker-compose
- Documentacion tecnica (README, arquitectura, API reference)
- Workspace navegable en `/tmp/kore/workspace/<proyecto>/`

### 11.3 EnterpriseDelivery (ENGINEER)

Para ingenieros senior. Todo lo anterior mas:
- Resultados de escaneo de seguridad (SAST)
- Configuracion de monitoring y health checks
- Pipeline de CI/CD
- Documentacion de compliance
- Manifiestos de Kubernetes

---

## 12. Interfaz de Usuario

### 12.1 CLI (Command Line Interface)

```bash
kore "Build a REST API for managing books with FastAPI"
```

Para desarrolladores que prefieren la terminal. Muestra progreso paso a paso, archivos generados, y tiempo total.

### 12.2 Web UI Local

```bash
kore --ui
```

Abre un navegador con una interfaz web moderna en `http://localhost:8080`. Diseñada para usuarios no tecnicos:

- Flujo en dos pasos: primero el usuario introduce su idea, luego KORE presenta preguntas de entrevista adaptadas a su nivel tecnico
- Formulario con campo de idea, nombre del proyecto, y URL de logo
- Preguntas de entrevista dinamicas (varian segun nivel detectado)
- Boton "Generar Proyecto" que envia idea + respuestas
- Barra de progreso con polling automatico
- Lista de archivos generados con tamaños
- Estetica moderna (dark theme, gradientes, responsive)

**Sin dependencias externas.** El HTML, CSS, y JavaScript estan embebidos en el servidor Python. No se carga nada desde CDNs o servidores externos.

### 12.3 API REST

Para integraciones programaticas:

| Endpoint | Metodo | Descripcion |
|----------|--------|-------------|
| `/health` | GET | Estado del servicio |
| `/api/v1/interview` | POST | Detecta nivel y devuelve preguntas |
| `/api/v1/generate` | POST | Lanza job en background |
| `/api/v1/jobs/{id}` | GET | Estado de un job |
| `/api/v1/jobs/{id}/files` | GET | Archivos generados |

Los jobs se ejecutan en background con `asyncio.create_task` y se consultan por polling. Almacenamiento en memoria (MVP).

---

## 13. Privacidad: Ejecucion 100% Local

### 13.1 Filosofia

KORE se diseño con un principio fundamental: **los datos del usuario nunca salen de su maquina sin su consentimiento explicito.**

### 13.2 Sin servidor central

No existe un servidor KORE centralizado. No hay cuentas de usuario. No hay registro. No hay telemetria. El paquete se instala via `pip install kore-platform` y todo se ejecuta localmente.

### 13.3 El usuario controla el LLM

Con Ollama, incluso las llamadas al LLM son locales. El modelo se ejecuta en la CPU/GPU del usuario. Ningun dato sale de la maquina.

Con OpenAI o Anthropic, las llamadas van a sus APIs respectivas bajo los terminos del usuario con esos proveedores. KORE no intermediaria ni almacena estas comunicaciones.

### 13.4 Sin datos personales

La web UI local no pide nombre, email, ni ningun dato personal. Solo la idea del proyecto. No hay cookies, no hay tracking, no hay analytics.

### 13.5 Advertencias importantes

- **Con OpenAI/Anthropic:** La idea del proyecto, el contexto de entrevista, y TODO el codigo generado se envian a sus APIs. No hay cifrado adicional mas alla de TLS. Revisar sus politicas de retencion de datos.
- **Con Ollama:** Todo es local, pero los modelos 7B generan codigo de menor calidad que GPT-4o o Claude. Es un trade-off entre privacidad y calidad.
- **Auto-generated context:** Cuando KORE usa `LLMAutoAnswerProvider`, el LLM inventa contexto (usuarios objetivo, requisitos de negocio) que puede no reflejar la realidad del usuario. Esto se indica con `answer_source: "llm_auto"` en el UserContext.
- **Sin telemetria real:** KORE no tiene un sistema de opt-in telemetry implementado. No se miden metricas de calidad en produccion. Los claims de rendimiento son estimados, no medidos.

---

## 14. Stack Tecnologico

### 14.1 Core

| Componente | Tecnologia | Justificacion |
|------------|------------|---------------|
| Lenguaje | Python 3.11+ | Async nativo, type hints, ecosistema LLM |
| Validacion | Pydantic v2 | Schemas inmutables, alto rendimiento |
| HTTP Client | httpx | Async, moderno, soporte HTTP/2 |
| Logging | structlog | JSON estructurado, filtrado eficiente |
| Config | YAML + env vars | Flexibilidad sin complejidad |
| Build | Hatchling | PEP 517, rapido, compatible PyPI |

### 14.2 LLM Adapters

| Proveedor | Adapter | Protocolo |
|-----------|---------|-----------|
| Ollama | `OllamaClient` | HTTP REST (localhost) |
| OpenAI | `OpenAIClient` | API REST + httpx async |
| Anthropic | `AnthropicClient` | API REST + httpx async |

Todos implementan `LLMClientPort` con dos metodos: `chat()` y `structured_output()`.

### 14.3 Web UI

| Componente | Tecnologia |
|------------|------------|
| Backend | FastAPI |
| Server | Uvicorn |
| Frontend | HTML/CSS/JS embebido (sin frameworks) |
| Jobs | asyncio.create_task (in-memory) |

### 14.4 Testing

| Herramienta | Uso |
|-------------|-----|
| pytest | Framework de tests |
| pytest-asyncio | Tests asincroncas |
| pytest-cov | Cobertura de codigo |
| ruff | Linting y formateo |
| mypy (strict) | Verificacion de tipos |

### 14.5 Dependencias Opcionales

| Paquete | Grupo | Descripcion |
|---------|-------|-------------|
| fastapi + uvicorn | `web` | Interfaz web local |
| `qubit-algebra` | `analysis` | Analisis de grafos con algebra de Clifford (usado por ComplexityAgent, opcional) |
| `transformers`, `peft`, `trl`, etc. | `training` | Fine-tuning LoRA/QLoRA (solo para re-entrenar el modelo, no para uso normal) |

---

## 15. Rendimiento y Metricas

### 15.1 Tests del framework

- **131 tests** pasando (del framework KORE, no del codigo generado)
- **Tiempo de ejecucion de tests:** < 0.3 segundos
- Los tests verifican la infraestructura de KORE, no la calidad del codigo que genera

> **Importante:** No se ha medido formalmente la tasa de exito de los proyectos generados. Los tests de KORE verifican que el pipeline funciona, no que el output sea correcto. La calidad del codigo generado depende del modelo LLM y de la complejidad de la idea.

### 15.2 Tiempos de generacion (estimados, no verificados)

| Nivel | Pasos | Tiempo estimado (Ollama 7B, CPU) | Tiempo estimado (GPT-4o) |
|-------|-------|----------------------------------|--------------------------|
| NO_DEV | 3 | ~5-15 min | ~2-5 min |
| DEV_JUNIOR | 5 | ~10-25 min | ~4-10 min |
| DEV_SENIOR | 8 | ~15-40 min | ~6-15 min |
| ENGINEER | 10 | ~20-60 min | ~8-20 min |

Los rangos son amplios porque dependen de: hardware, modelo LLM, complejidad de la idea, y numero de reintentos del validation loop. En CPU (sin GPU), Ollama puede ser muy lento.

### 15.3 Tamaño del paquete

- **Wheel:** ~100 KB (solo Python, sin modelos)
- **Dependencias requeridas:** pydantic, pyyaml, httpx, structlog
- **Dependencias opcionales:** fastapi + uvicorn (para web UI)

### 15.4 Calidad del codigo generado (honestamente)

La calidad del codigo generado varia dramaticamente segun:

| Factor | Impacto |
|--------|---------|
| Modelo LLM | 7B local: ~30-40% usable. GPT-4o: ~60-70% usable |
| Complejidad de la idea | Simple CRUD: alta. Sistema distribuido: baja |
| Few-shot match | Si la idea coincide con un ejemplo: mejora notable |
| Validation loop | Corrige errores de import/syntax, no errores de logica |

"Usable" significa: el codigo se ejecuta, los tests pasan, y la estructura es razonable. No significa: listo para produccion, seguro, o performante.

---

## 16. Casos de Uso

### 16.1 Emprendedor sin conocimientos tecnicos

*"Necesito una app para gestionar reservas de mi restaurante."*

KORE detecta nivel NO_DEV, genera 3 pasos (specs + architecture + code), y entrega un proyecto basico con interfaz web y gestion de reservas. El emprendedor recibe un directorio listo para subir a un hosting.

### 16.2 Desarrollador junior aprendiendo

*"Un sistema de gestion de tareas con React y FastAPI."*

KORE detecta nivel DEV_JUNIOR, genera 5 pasos que incluyen tests y documentacion. El junior recibe codigo bien estructurado con tests que puede estudiar como referencia de buenas practicas.

### 16.3 Equipo de desarrollo acelerando prototipado

*"API de procesamiento de pagos con PostgreSQL, Redis, JWT auth, Docker."*

KORE detecta nivel DEV_SENIOR, genera 8 pasos con review de codigo, review de seguridad, y configuracion Docker. El equipo recibe un prototipo funcional que pueden iterar en lugar de empezar de cero.

### 16.4 Arquitecto validando un diseno

*"Plataforma event-driven con CQRS, Kafka, Kubernetes, mTLS, distributed tracing."*

KORE detecta nivel ENGINEER, genera 10 pasos con escaneo SAST, monitoring, y manifiestos K8s. El arquitecto recibe una implementacion de referencia que valida su diseno antes de comprometer recursos del equipo.

### 16.5 Profesor en un curso de programacion

Usa KORE para generar proyectos de ejemplo que los alumnos pueden estudiar, modificar, y extender. Cada proyecto viene con tests que sirven como especificacion ejecutable.

---

## 17. Comparativa con Alternativas

> **Nota de honestidad:** KORE es un proyecto v1.0 en fase inicial. Las herramientas listadas abajo tienen equipos de cientos de ingenieros, millones de usuarios, y anos de iteracion. Esta comparativa refleja diferencias de enfoque, no de madurez.

| Caracteristica | KORE | GitHub Copilot | Cursor | ChatGPT | Devin |
|----------------|------|----------------|--------|---------|-------|
| Proyecto completo | Parcial* | No (lineas) | No (archivos) | Parcial | Si |
| Self-validation | Basico** | No | No | No | Avanzado |
| Ejecucion local | Si | No | No | No | No |
| Privacidad total | Con Ollama*** | No | No | No | No |
| Agnostico de LLM | Si | No (Codex) | Parcial | No (GPT) | No |
| Adaptacion por nivel | Si | No | No | No | No |
| Tests generados | Si (calidad variable) | No | Parcial | Parcial | Si |
| Web UI incluida | Basica | N/A (IDE plugin) | Si (IDE) | Si | Si |
| Precio | Gratis (MIT) | $10/mes | $20/mes | $20/mes | $500/mes |
| Open source | Si | No | No | No | No |
| Madurez | v1.0 alpha | Produccion | Produccion | Produccion | Beta |
| Comunidad | Incipiente | Millones | Millones | Millones | Miles |

\* KORE genera proyectos completos pero la calidad del codigo depende fuertemente del modelo LLM usado. Con modelos pequenos (7B), el codigo frecuentemente tiene errores que el self-validation intenta corregir.

\** El self-validation loop ejecuta tests y re-invoca al coder, pero no tiene acceso a un entorno real completo (sin Docker, sin BD). La tasa de exito en la correccion automatica no ha sido medida formalmente.

\*** Con Ollama, todo es local. Con OpenAI/Anthropic, la idea del proyecto y el codigo generado se envian a sus APIs.

**Diferenciador unico:** KORE es la unica plataforma que incluye analisis de complejidad estructural basado en algebra de grafos. El ComplexityAgent usa algebra de Clifford para calcular entrelazamiento entre modulos, detectar dependencias circulares, y evaluar la calidad arquitectonica del codigo generado — todo sin LLM, en CPU puro.

---

## 18. Limitaciones Conocidas

Esta seccion documenta las limitaciones actuales de KORE v1.0. La transparencia sobre estas limitaciones es fundamental para establecer expectativas correctas.

### 18.1 Calidad del codigo generado

- **El codigo generado NO esta listo para produccion.** Es un punto de partida que requiere revision humana.
- Con modelos pequenos (7B), los errores de imports, tipos, y logica son frecuentes.
- El self-validation loop corrige errores de syntax e imports, pero NO detecta errores de logica, race conditions, ni vulnerabilidades de seguridad.
- Los tests generados por KORE tienden a ser superficiales (happy path). La deteccion de tests triviales (`assert True`) mitiga parcialmente esto.

### 18.2 Seguridad del Guardian

- El Guardian usa pattern matching (regex + listas), no analisis semantico. Un atacante con acceso al prompt podria evadir los filtros con ofuscacion creativa.
- No hay sandboxing real (no Docker, no seccomp, no namespaces). Los `resource.setrlimit` limitan consumo pero no aislamiento.
- `pip install --only-binary` previene ejecucion de `setup.py` maliciosos, pero no cubre wheels con extensiones C.
- El escaneo de codigo generado busca patrones conocidos. Vulnerabilidades sutiles (logic bugs, IDOR, timing attacks) no son detectadas.

### 18.3 Self-validation loop

- Solo funciona para proyectos Python con pytest.
- No tiene acceso a base de datos, servicios externos, ni Docker. Tests que requieren estos recursos fallan silenciosamente.
- El truncamiento de errores a 4000 chars puede perder contexto critico en logs largos.
- No distingue entre errores del codigo generado y errores del entorno (pip failures, incompatibilidades de version).

### 18.3b ComplexityAgent

- El ComplexityAgent solo analiza proyectos Python (`ast.parse`). Codigo generado en otros lenguajes no se analiza.
- `qubit-algebra` es dependencia opcional. Sin ella, el agente usa fallback basico (deteccion de ciclos por DFS, sin calculo de entrelazamiento).
- Los umbrales de rating (A/B/C/D/F) son heuristicos y pueden no reflejar la complejidad real percibida por un desarrollador.

### 18.4 Entrevista y contexto

- En modo `--auto`, el `LLMAutoAnswerProvider` inventa contexto que el usuario no proporciono. Puede generar requisitos, usuarios objetivo, y preferencias que no reflejan la realidad.
- La deteccion heuristica de nivel tecnico puede dar falsos positivos (palabras clave en contexto incorrecto, mitigado con regex de word boundary).
- El modo interactivo (CLI y web) depende de que el usuario proporcione respuestas utiles. Respuestas vacias o escuetas producen contexto pobre.
- El matching de respuestas web (`WebAnswerProvider`) usa busqueda por key en texto, que puede fallar si las keys no coinciden exactamente.

### 18.5 Few-shot y prompts

- Solo 5 ejemplos (fastapi_crud, pytest, cli_tool, etl_pipeline, python_library). Proyectos fuera de estas categorias no tienen ejemplo relevante.
- Los prompts estan en ingles (el LLM genera mejor codigo asi), pero el usuario hispanohablante puede encontrar confusos los comentarios en ingles en el codigo generado.
- `max_tokens=16384` en implement_feature permite proyectos medianos. Proyectos muy complejos (>15 archivos con logica densa) pueden aun quedarse cortos. Con modelos pequenos (7B), la generacion efectiva puede ser significativamente menor que el max_tokens configurado — muchos modelos 7B degradan la calidad del output a partir de ~8K tokens aunque su ventana de contexto anunciada sea mayor.

### 18.6 Escalabilidad

- Jobs en memoria: si el proceso muere, se pierden todos los jobs en progreso.
- No hay persistencia de estado. No hay cola de trabajos. No hay workers distribuidos.
- Un solo job consume toda la capacidad LLM. No hay queueing ni rate limiting.

### 18.7 Testing del framework

- Los 131 tests verifican la infraestructura, no la calidad del output.
- No hay tests de integracion con LLM real (costarian dinero por cada ejecucion de CI).
- No hay benchmarks formales de calidad de codigo generado.
- Coverage real no medido (objetivo de 80% es aspiracional).

### 18.8 Observabilidad

- No hay telemetria opt-in implementada. No se sabe cuantos proyectos se generan, cuantos fallan, ni por que.
- El cost tracking de tokens es estimado (basado en regla de 4 chars/token), no preciso.
- No hay metricas Prometheus reales. Solo un `/health` endpoint basico.

---

## 19. Hoja de Ruta

### v1.0 (Actual — con limitaciones documentadas en seccion 18)
- 10 agentes especializados con 29 skills
- Analisis de complejidad estructural (ComplexityAgent, sin LLM)
- Pipeline completo: idea -> proyecto funcional
- Self-validation loop con auto-correccion
- Few-shot learning para calidad de codigo
- LLM-powered interview con 3 modos (interactivo CLI, web, auto)
- Web UI local con flujo de entrevista
- CLI directo con modo interactivo
- Modelo de amenazas explicito (5 adversarios documentados)
- Proteccion CSRF + validacion Origin en web
- Internacionalizacion (espanol + ingles)
- Pipeline de fine-tuning: curacion de dataset (scraper GitHub + filtro de calidad + analisis ComplexityAgent + extraccion de pares), training LoRA, cuantizacion GGUF, distribucion con `kore --setup`
- Jerarquia de configuracion: env vars > `~/.kore/config.yaml` > defaults
- 174 tests

### v1.1 (Planificado)
- Aislamiento de procesos via nsjail/bubblewrap para ejecucion de codigo generado
- Soporte multi-lenguaje (TypeScript, Go, Rust)
- Templates de proyecto personalizables
- Cache de resultados LLM para ahorrar tokens
- Export a GitHub automatico

### v1.2 (Planificado)
- Plugin system para agentes custom
- Integracion con IDEs (VS Code extension)
- Dashboard de metricas de generacion
- Soporte para proyectos multi-servicio
- Generacion multi-llamada: un archivo por invocacion LLM para superar el limite de 16384 tokens

### v2.0 (Vision)
- Agentes colaborativos con memoria compartida
- Iteracion conversacional ("Ahora anadele autenticacion")
- Deploy real automatico (Vercel, Railway, AWS)
- Marketplace de agentes comunitarios

---

## 20. Instalacion y Uso

### 20.1 Requisitos

- Python 3.11 o superior
- Un proveedor LLM (Ollama recomendado para uso local)

### 20.2 Instalacion

```bash
pip install kore-platform
```

Para la interfaz web:
```bash
pip install kore-platform[web]
```

Para todo (web + LLM APIs + observabilidad):
```bash
pip install kore-platform[all]
```

### 20.3 Configuracion del LLM

**Ollama (recomendado, gratuito, local):**
```bash
# Instalar Ollama desde https://ollama.com
ollama pull qwen2.5-coder:7b-instruct

export KORE_LLM_PROVIDER=ollama
export KORE_LLM_MODEL=qwen2.5-coder:7b-instruct
```

**OpenAI:**
```bash
export KORE_LLM_PROVIDER=openai
export KORE_LLM_MODEL=gpt-4o
export KORE_LLM_API_KEY=sk-...
```

**Anthropic:**
```bash
export KORE_LLM_PROVIDER=anthropic
export KORE_LLM_MODEL=claude-sonnet-4-5-20250929
export KORE_LLM_API_KEY=sk-ant-...
```

### 20.4 Uso por CLI

```bash
kore "Build a REST API for managing books with FastAPI"
```

### 20.5 Uso por Web UI

```bash
kore --ui
```

Se abre automaticamente `http://localhost:8080` en el navegador.

### 20.6 Variables de entorno completas

| Variable | Default | Descripcion |
|----------|---------|-------------|
| `KORE_LLM_PROVIDER` | `ollama` | Proveedor: ollama, openai, anthropic |
| `KORE_LLM_MODEL` | `qwen2.5-coder:7b-instruct` | Modelo a usar |
| `KORE_LLM_BASE_URL` | `http://localhost:11434` | URL del servidor LLM |
| `KORE_LLM_API_KEY` | — | Clave API (OpenAI/Anthropic) |
| `KORE_LLM_TIMEOUT` | `600` | Timeout por llamada LLM (segundos) |
| `KORE_WORKSPACE_PATH` | `/tmp/kore/workspace` | Directorio de output |
| `KORE_VALIDATION_MAX_RETRIES` | `3` | Intentos de auto-correccion |
| `KORE_VALIDATION_TIMEOUT` | `120` | Timeout de validacion (segundos) |
| `KORE_ENVIRONMENT` | `development` | Entorno |
| `KORE_LANG` | `es` | Idioma: es (espanol) o en (ingles) |
| `KORE_LOG_LEVEL` | `INFO` | Nivel de logging |

---

## 21. Licencia y Distribucion

### 21.1 Licencia

KORE Platform se distribuye bajo licencia **MIT**. Esto permite:

- Uso comercial sin restricciones
- Modificacion y redistribucion libre
- Inclusion en productos propietarios
- Sin obligacion de publicar cambios

### 21.2 Repositorio

GitHub: `https://github.com/iafiscal1212/kore-platform`

### 21.3 Distribucion

- **PyPI:** `pip install kore-platform`
- **Codigo fuente:** Clonar repositorio
- **Wheel:** Disponible en releases de GitHub

---

## Anexo A: Glosario

| Termino | Definicion |
|---------|-----------|
| **Agente** | Componente IA especializado en un aspecto del desarrollo |
| **Skill** | Habilidad concreta de un agente (ej: `implement_feature`) |
| **Artefacto** | Output de un agente que se pasa al siguiente (ej: codigo, tests) |
| **Pipeline** | Secuencia de pasos del plan de ejecucion |
| **Job** | Ejecucion completa de una idea, de principio a fin |
| **UserContext** | Estado inmutable del usuario tras la entrevista |
| **Plan** | Secuencia de pasos a ejecutar (inmutable) |
| **Guardian** | Componente de seguridad que valida todas las acciones |
| **Workspace** | Directorio donde se escriben los archivos generados |
| **Few-shot** | Ejemplo concreto incluido en el prompt para mejorar calidad |
| **Self-validation** | Ejecucion automatica de tests con auto-correccion |
| **Delivery** | Empaquetado final del proyecto adaptado al nivel del usuario |

---

## Anexo B: Diagrama de Clases Principal

```
BaseAgent (ABC)
  |-- SpecsAgent
  |-- ArchitectAgent
  |-- CoderAgent
  |-- TesterAgent
  |-- ReviewerAgent
  |-- SecurityAgent
  |-- DeployerAgent
  |-- DocumenterAgent
  |-- MonitorAgent
  |-- ComplexityAgent

BaseSkill (ABC)
  |-- ImplementFeatureSkill
  |-- WriteUnitTestsSkill
  |-- RunTestsSkill
  |-- DesignArchitectureSkill
  |-- ... (29 skills total)

LLMClientPort (ABC)
  |-- OllamaClient
  |-- OpenAIClient
  |-- AnthropicClient

AnswerProvider (ABC)
  |-- CLIAnswerProvider
  |-- WebAnswerProvider
  |-- LLMAutoAnswerProvider

Orchestrator
  |-- uses ValidationLoop
  |-- uses ParallelExecutor
  |-- uses Guardian

ValidationLoop
  |-- uses SubprocessRunner
```

---

*KORE Platform v1.0 — Febrero 2026 — IAFiscal*
*"Describe your idea. Get a complete project. That's it."*
