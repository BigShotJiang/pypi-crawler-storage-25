import pickle
from pathlib import Path
from typing import Mapping, Optional, Sequence

import numpy as np
import zmq


class PickleClient:
    """ZeroMQ 기반 간단한 pickle RPC 클라이언트."""

    def __init__(self, hostname: str, port: int = 5558):
        self.hostname = hostname
        self.port = port
        self.context = zmq.Context()
        self.socket = self.context.socket(zmq.REQ)
        self.socket.connect(f"tcp://{self.hostname}:{self.port}")

    def send_data(self, data: dict):
        self.socket.send(pickle.dumps(data))
        response = pickle.loads(self.socket.recv())
        return response

    def close(self):
        self.socket.close()
        self.context.term()


class GraspGeneration:
    """GraspGen Docker 서버용 클라이언트.

    서버가 제공하는 projection 옵션을 모두 전달할 수 있도록 vfm_tester 및 nrmk_graspgen 양쪽을 통합했습니다.
    """

    def __init__(self, hostname: str, port: int = 5558):
        self.client = PickleClient(hostname, port)
        self.intrinsics: Optional[dict] = None
        self.model: Optional[str] = None

    # ---------- 기본 유틸 ----------
    @staticmethod
    def _to_2d_mask(mask):
        if mask is None:
            return None
        if mask.ndim == 3 and mask.shape[-1] == 1:
            return mask[:, :, 0]
        return mask

    @staticmethod
    def _resolve_camera_intrinsics(camera_intrinsics: Optional[dict | Sequence[float] | np.ndarray], intrinsics: Optional[dict]):
        if camera_intrinsics is None:
            if intrinsics is None:
                raise ValueError("Camera intrinsics not set. Call init() or pass camera_intrinsics.")
            return (
                float(intrinsics["fx"]),
                float(intrinsics["fy"]),
                float(intrinsics["cx"]),
                float(intrinsics["cy"]),
            )

        if isinstance(camera_intrinsics, Mapping):
            try:
                return (
                    float(camera_intrinsics["fx"]),
                    float(camera_intrinsics["fy"]),
                    float(camera_intrinsics["cx"]),
                    float(camera_intrinsics["cy"]),
                )
            except KeyError as exc:
                raise ValueError(
                    "camera_intrinsics dict must contain fx, fy, cx, cy."
                ) from exc

        raw = np.asarray(camera_intrinsics)
        if raw.size == 4 and raw.ndim == 1:
            return float(raw[0]), float(raw[1]), float(raw[2]), float(raw[3])

        if raw.size == 9 and raw.shape in {(3, 3), (1, 9)}:
            raw = raw.reshape(3, 3)
            return float(raw[0, 0]), float(raw[1, 1]), float(raw[0, 2]), float(raw[1, 2])

        if raw.size == 16 and raw.shape in {(4, 4), (1, 16)}:
            raw = raw.reshape(4, 4)
            return float(raw[0, 0]), float(raw[1, 1]), float(raw[0, 2]), float(raw[1, 2])

        raise ValueError(
            "camera_intrinsics must be Mapping with keys fx/fy/cx/cy, [fx, fy, cx, cy], or a 3x3/4x4 matrix."
        )

    @staticmethod
    def _parse_mask_or_roi(shape, obj_mask_or_roi):
        if obj_mask_or_roi is None:
            return None
        if isinstance(obj_mask_or_roi, np.ndarray):
            mask = obj_mask_or_roi.astype(bool)
            if mask.ndim == 3:
                mask = GraspGeneration._to_2d_mask(mask)
            if mask.shape != shape:
                raise ValueError("obj_mask_or_roi shape does not match depth shape.")
            return mask

        roi = np.asarray(obj_mask_or_roi)
        if roi.shape != (4,):
            raise ValueError("obj_mask_or_roi must be HxW mask or [x_min, y_min, x_max, y_max] roi.")

        x_min, y_min, x_max, y_max = roi.astype(int)
        if x_min < 0 or y_min < 0 or x_max < 0 or y_max < 0:
            raise ValueError("roi coordinates must be non-negative.")
        if x_max <= x_min or y_max <= y_min:
            raise ValueError("roi must satisfy x_max>x_min and y_max>y_min.")

        mask = np.zeros(shape, dtype=bool)
        h, w = shape
        x_min, x_max = np.clip([x_min, x_max], 0, w)
        y_min, y_max = np.clip([y_min, y_max], 0, h)
        mask[y_min:y_max, x_min:x_max] = True
        return mask

    @staticmethod
    def _transform_point_cloud(point_cloud: np.ndarray, camera_extrinsics: Optional[Sequence[float] | np.ndarray]):
        if camera_extrinsics is None:
            return point_cloud
        transform = np.asarray(camera_extrinsics, dtype=np.float32)
        if transform.shape != (4, 4):
            raise ValueError("camera_extrinsics must be a 4x4 matrix.")

        points = np.asarray(point_cloud, dtype=np.float32)
        if points.size == 0:
            return points
        if points.shape[1] != 3:
            raise ValueError("point_cloud must have shape (N, 3).")

        ones = np.ones((points.shape[0], 1), dtype=np.float32)
        homo = np.concatenate([points, ones], axis=1)
        transformed = (transform @ homo.T).T[:, :3]
        return transformed.astype(np.float32, copy=False)

    def _build_point_clouds_from_rgb_depth(
        self,
        depth: np.ndarray,
        camera_intrinsics: Optional[dict | Sequence[float] | np.ndarray] = None,
        *,
        camera_extrinsics: Optional[Sequence[float] | np.ndarray] = None,
        obj_mask_or_roi=None,
        depth_scale: float = 1.0,
        max_object_points: Optional[int] = None,
        max_scene_points: int = 8192,
        collision_check: bool = False,
    ):
        fx, fy, cx, cy = self._resolve_camera_intrinsics(camera_intrinsics, self.intrinsics)
        mask = self._parse_mask_or_roi(depth.shape[:2], obj_mask_or_roi)

        object_pc = self.depth_to_points(depth, fx, fy, cx, cy, mask=mask, depth_scale=depth_scale)
        object_pc = self._downsample_points(object_pc, max_object_points)
        if not collision_check:
            return (
                self._transform_point_cloud(object_pc, camera_extrinsics),
                None,
            )

        scene_mask = depth > 0
        if mask is not None:
            scene_mask = scene_mask & (~mask)
        scene_pc = self.depth_to_points(depth, fx, fy, cx, cy, mask=scene_mask, depth_scale=depth_scale)
        scene_pc = self._downsample_points(scene_pc, max_scene_points)
        object_pc = self._transform_point_cloud(object_pc, camera_extrinsics)
        scene_pc = self._transform_point_cloud(scene_pc, camera_extrinsics)
        return object_pc, scene_pc

    @staticmethod
    def _downsample_points(points: np.ndarray, max_points: Optional[int]):
        if max_points is None or max_points <= 0:
            return points
        if points.shape[0] <= max_points:
            return points
        idx = np.random.choice(points.shape[0], max_points, replace=False)
        return points[idx]

    @staticmethod
    def depth_to_points(
        depth: np.ndarray,
        fx: float,
        fy: float,
        cx: float,
        cy: float,
        mask: Optional[np.ndarray] = None,
        depth_scale: float = 1.0,
    ) -> np.ndarray:
        depth = depth.astype(np.float32) * depth_scale
        h, w = depth.shape
        xs = np.arange(w)
        ys = np.arange(h)
        xmap, ymap = np.meshgrid(xs, ys)

        valid = depth > 0
        if mask is not None:
            valid = valid & mask

        z = depth[valid]
        if z.size == 0:
            return np.zeros((0, 3), dtype=np.float32)

        x = (xmap[valid] - cx) * z / fx
        y = (ymap[valid] - cy) * z / fy
        return np.stack([x, y, z], axis=1).astype(np.float32)

    def depth_mask_to_point_clouds(
        self,
        depth: np.ndarray,
        mask: np.ndarray,
        fx: float,
        fy: float,
        cx: float,
        cy: float,
        target_object_id: Optional[int] = None,
        depth_scale: float = 1.0,
        remove_object_from_scene: bool = True,
    ) -> tuple[np.ndarray, np.ndarray]:
        mask = self._to_2d_mask(mask)
        if target_object_id is None:
            obj_mask = mask > 0
        else:
            obj_mask = mask == target_object_id

        object_pc = self.depth_to_points(
            depth, fx, fy, cx, cy, mask=obj_mask, depth_scale=depth_scale
        )

        scene_mask = depth > 0
        if remove_object_from_scene:
            scene_mask = scene_mask & (~obj_mask)
        scene_pc = self.depth_to_points(
            depth, fx, fy, cx, cy, mask=scene_mask, depth_scale=depth_scale
        )

        return object_pc, scene_pc

    @staticmethod
    def _mean_knn_distances_numpy(points: np.ndarray, k_eff: int, chunk_size: int = 1024):
        n = points.shape[0]
        mean_dists = np.empty(n, dtype=np.float32)
        for start in range(0, n, chunk_size):
            end = min(start + chunk_size, n)
            diff = points[start:end, None, :] - points[None, :, :]
            dists = np.linalg.norm(diff, axis=-1)
            if k_eff < n:
                idx = np.argpartition(dists, kth=k_eff - 1, axis=1)[:, :k_eff]
                row = np.take_along_axis(dists, idx, axis=1)
            else:
                row = np.sort(dists, axis=1)
            if row.shape[1] > 1:
                mean = row[:, 1:].mean(axis=1)
            else:
                mean = row[:, 0]
            mean_dists[start:end] = mean.astype(np.float32)
        return mean_dists

    def point_cloud_outlier_removal(
        self, obj_pc: np.ndarray, threshold: float = 0.014, k: int = 20
    ) -> tuple[np.ndarray, np.ndarray]:
        obj_pc = np.asarray(obj_pc, dtype=np.float32)
        if obj_pc.ndim != 2 or obj_pc.shape[1] != 3:
            raise ValueError("obj_pc must be Nx3")
        if obj_pc.shape[0] == 0:
            return obj_pc.copy(), obj_pc.copy()

        k_eff = min(k + 1, obj_pc.shape[0])
        mean_dists = None
        try:
            from scipy.spatial import cKDTree

            tree = cKDTree(obj_pc)
            dists, _ = tree.query(obj_pc, k=k_eff)
            if k_eff > 1:
                mean_dists = dists[:, 1:].mean(axis=1)
            else:
                mean_dists = dists[:, 0]
        except Exception:
            mean_dists = self._mean_knn_distances_numpy(obj_pc, k_eff)

        mask = mean_dists < threshold
        filtered_pc = obj_pc[mask]
        removed_pc = obj_pc[~mask]
        return filtered_pc, removed_pc

    # ---------- RPC ----------
    def init(self, fx: float, fy: float, cx: float, cy: float, model: str = "dh_ag_160_95"):
        self.intrinsics = {"fx": fx, "fy": fy, "cx": cx, "cy": cy}
        self.model = model
        payload = {"operation": "init", "model": model, "intrinsics": self.intrinsics}
        return self.client.send_data(payload)

    def get_version(self):
        return self.client.send_data({"operation": "get_version"})

    def get_health(self):
        return self.client.send_data({"operation": "get_health"})

    def _build_inference_payload(
        self,
        object_pc: np.ndarray,
        scene_pc: Optional[np.ndarray] = None,
        collision_check: bool = False,
        grasp_threshold: float = 0.8,
        num_grasps: int = 200,
        return_topk: bool = False,
        topk_num_grasps: int = -1,
        collision_threshold: float = 0.02,
        min_grasps: Optional[int] = None,
        max_tries: Optional[int] = None,
        enable_orientation_projection: Optional[bool] = None,
        enable_translation_projection: Optional[bool] = None,
        approach_axis_index: Optional[int] = None,
        approach_axis_source: Optional[str] = None,
        normal_avg_k: Optional[int] = None,
        target_approach_direction: Optional[Sequence[float]] = None,
        translation_axis: Optional[int] = None,
        desired_offset: Optional[float] = None,
        step_strength_orient: Optional[float] = None,
        step_strength_trans: Optional[float] = None,
        enable_roll_projection: Optional[bool] = None,
        jaw_axis_index: Optional[int] = None,
        target_roll_direction: Optional[Sequence[float] | str] = None,
        roll_target_axis: Optional[int] = None,
        roll_target_axis_sign: Optional[int] = None,
        roll_use_local_tangent: Optional[bool] = None,
        step_strength_roll: Optional[float] = None,
        use_surface_normal_for_approach: Optional[bool] = None,
        contact_proxy_offset: Optional[float] = None,
        pca_axis_sign_ref: Optional[Sequence[float] | str] = None,
        projection_debug: Optional[bool] = None,
    ):
        payload = {
            "operation": "inference",
            "object_pc": object_pc,
            "grasp_threshold": grasp_threshold,
            "num_grasps": num_grasps,
            "return_topk": return_topk,
            "topk_num_grasps": topk_num_grasps,
            "collision_check": collision_check,
            "collision_threshold": collision_threshold,
        }
        if min_grasps is not None:
            payload["min_grasps"] = min_grasps
        if max_tries is not None:
            payload["max_tries"] = max_tries
        if enable_orientation_projection is not None:
            payload["enable_orientation_projection"] = enable_orientation_projection
        if enable_translation_projection is not None:
            payload["enable_translation_projection"] = enable_translation_projection
        if approach_axis_index is not None:
            payload["approach_axis_index"] = approach_axis_index
        if approach_axis_source is not None:
            payload["approach_axis_source"] = approach_axis_source
        if normal_avg_k is not None:
            payload["normal_avg_k"] = normal_avg_k
        if target_approach_direction is not None:
            payload["target_approach_direction"] = target_approach_direction
        if translation_axis is not None:
            payload["translation_axis"] = translation_axis
        if desired_offset is not None:
            payload["desired_offset"] = desired_offset
        if step_strength_orient is not None:
            payload["step_strength_orient"] = step_strength_orient
        if step_strength_trans is not None:
            payload["step_strength_trans"] = step_strength_trans
        if enable_roll_projection is not None:
            payload["enable_roll_projection"] = enable_roll_projection
        if jaw_axis_index is not None:
            payload["jaw_axis_index"] = jaw_axis_index
        if target_roll_direction is not None:
            payload["target_roll_direction"] = target_roll_direction
        if roll_target_axis is not None:
            payload["roll_target_axis"] = roll_target_axis
        if roll_target_axis_sign is not None:
            payload["roll_target_axis_sign"] = roll_target_axis_sign
        if roll_use_local_tangent is not None:
            payload["roll_use_local_tangent"] = roll_use_local_tangent
        if step_strength_roll is not None:
            payload["step_strength_roll"] = step_strength_roll
        if use_surface_normal_for_approach is not None:
            payload["use_surface_normal_for_approach"] = use_surface_normal_for_approach
        if contact_proxy_offset is not None:
            payload["contact_proxy_offset"] = contact_proxy_offset
        if pca_axis_sign_ref is not None:
            payload["pca_axis_sign_ref"] = pca_axis_sign_ref
        if projection_debug is not None:
            payload["projection_debug"] = projection_debug
        if collision_check and scene_pc is not None:
            payload["scene_pc"] = scene_pc
        return payload

    def _build_inference_with_aperture_payload(
        self,
        inference_payload: dict,
        max_aperture: float,
        aperture_margin: float = 0.002,
        aperture_depth_band: float = 0.03,
        aperture_region_mode: str = "closing_regions",
        aperture_unknown_policy: str = "drop",
        aperture_jaw_axis_index: Optional[int] = None,
        aperture_axis_index: Optional[int] = None,
        aperture_min_points: int = 10,
        aperture_chunk_size: Optional[int] = None,
        grasp_chunk_size: Optional[int] = None,
        gripper: Optional[str] = None,
    ):
        if max_aperture is None:
            raise ValueError("max_aperture is required")

        if aperture_region_mode not in {"closing_regions", "depth_band", "all_points"}:
            raise ValueError("aperture_region_mode must be one of: closing_regions, depth_band, all_points")

        if aperture_unknown_policy not in {"drop", "keep"}:
            raise ValueError("aperture_unknown_policy must be one of: drop, keep")

        if aperture_jaw_axis_index is None and aperture_axis_index is not None:
            aperture_jaw_axis_index = aperture_axis_index
        if aperture_jaw_axis_index is None and inference_payload.get("jaw_axis_index") is not None:
            aperture_jaw_axis_index = inference_payload.get("jaw_axis_index")
        if aperture_jaw_axis_index is None:
            aperture_jaw_axis_index = 0

        resolved_chunk_size = aperture_chunk_size
        if resolved_chunk_size is None:
            resolved_chunk_size = grasp_chunk_size if grasp_chunk_size is not None else 256

        aperture_payload = {
            "max_aperture": float(max_aperture),
            "aperture_margin": float(aperture_margin),
            "aperture_depth_band": float(aperture_depth_band),
            "aperture_region_mode": aperture_region_mode,
            "aperture_unknown_policy": aperture_unknown_policy,
            "aperture_jaw_axis_index": int(aperture_jaw_axis_index),
            "aperture_min_points": int(aperture_min_points),
            "aperture_chunk_size": int(resolved_chunk_size),
            "gripper": str(gripper or self.model or "dh_ag_160_95"),
        }
        return {
            "operation": "inference_with_aperture",
            "inference": inference_payload,
            "aperture": aperture_payload,
        }

    def inference_from_point_cloud(
        self,
        object_pc: np.ndarray,
        scene_pc: Optional[np.ndarray] = None,
        collision_check: bool = False,
        grasp_threshold: float = 0.8,
        num_grasps: int = 200,
        return_topk: bool = False,
        topk_num_grasps: int = -1,
        collision_threshold: float = 0.02,
        min_grasps: Optional[int] = None,
        max_tries: Optional[int] = None,
        enable_orientation_projection: Optional[bool] = None,
        enable_translation_projection: Optional[bool] = None,
        approach_axis_index: Optional[int] = None,
        approach_axis_source: Optional[str] = None,
        normal_avg_k: Optional[int] = None,
        target_approach_direction: Optional[Sequence[float]] = None,
        translation_axis: Optional[int] = None,
        desired_offset: Optional[float] = None,
        step_strength_orient: Optional[float] = None,
        step_strength_trans: Optional[float] = None,
        enable_roll_projection: Optional[bool] = None,
        jaw_axis_index: Optional[int] = None,
        target_roll_direction: Optional[Sequence[float] | str] = None,
        roll_target_axis: Optional[int] = None,
        roll_target_axis_sign: Optional[int] = None,
        roll_use_local_tangent: Optional[bool] = None,
        step_strength_roll: Optional[float] = None,
        use_surface_normal_for_approach: Optional[bool] = None,
        contact_proxy_offset: Optional[float] = None,
        pca_axis_sign_ref: Optional[Sequence[float] | str] = None,
        projection_debug: Optional[bool] = None,
    ):
        payload = self._build_inference_payload(
            object_pc=object_pc,
            scene_pc=scene_pc,
            collision_check=collision_check,
            grasp_threshold=grasp_threshold,
            num_grasps=num_grasps,
            return_topk=return_topk,
            topk_num_grasps=topk_num_grasps,
            collision_threshold=collision_threshold,
            min_grasps=min_grasps,
            max_tries=max_tries,
            enable_orientation_projection=enable_orientation_projection,
            enable_translation_projection=enable_translation_projection,
            approach_axis_index=approach_axis_index,
            approach_axis_source=approach_axis_source,
            normal_avg_k=normal_avg_k,
            target_approach_direction=target_approach_direction,
            translation_axis=translation_axis,
            desired_offset=desired_offset,
            step_strength_orient=step_strength_orient,
            step_strength_trans=step_strength_trans,
            enable_roll_projection=enable_roll_projection,
            jaw_axis_index=jaw_axis_index,
            target_roll_direction=target_roll_direction,
            roll_target_axis=roll_target_axis,
            roll_target_axis_sign=roll_target_axis_sign,
            roll_use_local_tangent=roll_use_local_tangent,
            step_strength_roll=step_strength_roll,
            use_surface_normal_for_approach=use_surface_normal_for_approach,
            contact_proxy_offset=contact_proxy_offset,
            pca_axis_sign_ref=pca_axis_sign_ref,
            projection_debug=projection_debug,
        )
        return self.client.send_data(payload)

    def inference_from_point_cloud_with_aperture(
        self,
        object_pc: Optional[np.ndarray] = None,
        max_aperture: Optional[float] = None,
        scene_pc: Optional[np.ndarray] = None,
        collision_check: bool = False,
        grasp_threshold: float = 0.8,
        num_grasps: int = 200,
        return_topk: bool = False,
        topk_num_grasps: int = -1,
        collision_threshold: float = 0.02,
        min_grasps: Optional[int] = None,
        max_tries: Optional[int] = None,
        enable_orientation_projection: Optional[bool] = None,
        enable_translation_projection: Optional[bool] = None,
        approach_axis_index: Optional[int] = None,
        approach_axis_source: Optional[str] = None,
        normal_avg_k: Optional[int] = None,
        target_approach_direction: Optional[Sequence[float]] = None,
        translation_axis: Optional[int] = None,
        desired_offset: Optional[float] = None,
        step_strength_orient: Optional[float] = None,
        step_strength_trans: Optional[float] = None,
        enable_roll_projection: Optional[bool] = None,
        jaw_axis_index: Optional[int] = None,
        target_roll_direction: Optional[Sequence[float] | str] = None,
        roll_target_axis: Optional[int] = None,
        roll_target_axis_sign: Optional[int] = None,
        roll_use_local_tangent: Optional[bool] = None,
        step_strength_roll: Optional[float] = None,
        use_surface_normal_for_approach: Optional[bool] = None,
        contact_proxy_offset: Optional[float] = None,
        pca_axis_sign_ref: Optional[Sequence[float] | str] = None,
        projection_debug: Optional[bool] = None,
        aperture_margin: float = 0.002,
        aperture_axis_index: Optional[int] = None,
        aperture_region_mode: str = "closing_regions",
        aperture_depth_band: float = 0.03,
        aperture_min_points: int = 10,
        aperture_unknown_policy: str = "drop",
        aperture_chunk_size: Optional[int] = None,
        grasp_chunk_size: Optional[int] = None,
        *,
        rgb: Optional[np.ndarray] = None,
        depth: Optional[np.ndarray] = None,
        camera_intrinsics: Optional[dict | Sequence[float] | np.ndarray] = None,
        camera_extrinsics: Optional[Sequence[float] | np.ndarray] = None,
        obj_mask_or_roi=None,
        depth_scale: float = 1.0,
        max_object_points: Optional[int] = None,
        max_scene_points: int = 8192,
        aperture_jaw_axis_index: Optional[int] = None,
        gripper: Optional[str] = None,
    ) -> dict:
        """Run aperture-aware inference from point clouds.

        If RGB/depth/camera parameters are provided, object point cloud is derived from depth using
        `obj_mask_or_roi`:
        - `obj_mask_or_roi=None`: uses depth>0 as object mask.
        - 2D ndarray mask: used directly as object mask.
        - length-4 sequence [x_min, y_min, x_max, y_max]: ROI box converted to mask.
        """
        if max_aperture is None:
            raise ValueError("max_aperture is required")

        if depth is not None or camera_intrinsics is not None or camera_extrinsics is not None or obj_mask_or_roi is not None:
            if depth is None:
                raise ValueError("depth is required when rgb/camera intrinsics/extrinsics/obj_mask_or_roi are used.")
            if rgb is not None and rgb.shape[:2] != depth.shape[:2]:
                raise ValueError("rgb shape must match depth shape.")
            object_pc, scene_pc = self._build_point_clouds_from_rgb_depth(
                depth=depth,
                camera_intrinsics=camera_intrinsics,
                camera_extrinsics=camera_extrinsics,
                obj_mask_or_roi=obj_mask_or_roi,
                depth_scale=depth_scale,
                max_object_points=max_object_points,
                max_scene_points=max_scene_points,
                collision_check=collision_check,
            )
        elif object_pc is None:
            raise ValueError("Either object_pc or (depth + camera_intrinsics) is required.")

        inference_payload = self._build_inference_payload(
            object_pc=object_pc,
            scene_pc=scene_pc if collision_check else None,
            collision_check=collision_check,
            grasp_threshold=grasp_threshold,
            num_grasps=num_grasps,
            return_topk=return_topk,
            topk_num_grasps=topk_num_grasps,
            collision_threshold=collision_threshold,
            min_grasps=min_grasps,
            max_tries=max_tries,
            enable_orientation_projection=enable_orientation_projection,
            enable_translation_projection=enable_translation_projection,
            approach_axis_index=approach_axis_index,
            approach_axis_source=approach_axis_source,
            normal_avg_k=normal_avg_k,
            target_approach_direction=target_approach_direction,
            translation_axis=translation_axis,
            desired_offset=desired_offset,
            step_strength_orient=step_strength_orient,
            step_strength_trans=step_strength_trans,
            enable_roll_projection=enable_roll_projection,
            jaw_axis_index=jaw_axis_index,
            target_roll_direction=target_roll_direction,
            roll_target_axis=roll_target_axis,
            roll_target_axis_sign=roll_target_axis_sign,
            roll_use_local_tangent=roll_use_local_tangent,
            step_strength_roll=step_strength_roll,
            use_surface_normal_for_approach=use_surface_normal_for_approach,
            contact_proxy_offset=contact_proxy_offset,
            pca_axis_sign_ref=pca_axis_sign_ref,
            projection_debug=projection_debug,
        )
        payload = self._build_inference_with_aperture_payload(
            inference_payload,
            max_aperture=max_aperture,
            aperture_margin=aperture_margin,
            aperture_depth_band=aperture_depth_band,
            aperture_region_mode=aperture_region_mode,
            aperture_unknown_policy=aperture_unknown_policy,
            aperture_jaw_axis_index=aperture_jaw_axis_index,
            aperture_axis_index=aperture_axis_index,
            aperture_min_points=aperture_min_points,
            aperture_chunk_size=aperture_chunk_size,
            grasp_chunk_size=grasp_chunk_size,
            gripper=gripper,
        )
        return self.client.send_data(payload)

    def inference_from_depth_mask(
        self,
        depth: np.ndarray,
        mask: np.ndarray,
        fx: Optional[float] = None,
        fy: Optional[float] = None,
        cx: Optional[float] = None,
        cy: Optional[float] = None,
        target_object_id: Optional[int] = None,
        depth_scale: float = 1.0,
        max_object_points: Optional[int] = None,
        max_scene_points: int = 8192,
        collision_check: bool = False,
        grasp_threshold: float = 0.8,
        num_grasps: int = 200,
        return_topk: bool = False,
        topk_num_grasps: int = -1,
        collision_threshold: float = 0.02,
        min_grasps: Optional[int] = None,
        max_tries: Optional[int] = None,
        enable_orientation_projection: Optional[bool] = None,
        enable_translation_projection: Optional[bool] = None,
        approach_axis_index: Optional[int] = None,
        approach_axis_source: Optional[str] = None,
        normal_avg_k: Optional[int] = None,
        target_approach_direction: Optional[Sequence[float]] = None,
        translation_axis: Optional[int] = None,
        desired_offset: Optional[float] = None,
        step_strength_orient: Optional[float] = None,
        step_strength_trans: Optional[float] = None,
        enable_roll_projection: Optional[bool] = None,
        jaw_axis_index: Optional[int] = None,
        target_roll_direction: Optional[Sequence[float] | str] = None,
        roll_target_axis: Optional[int] = None,
        roll_target_axis_sign: Optional[int] = None,
        roll_use_local_tangent: Optional[bool] = None,
        step_strength_roll: Optional[float] = None,
        use_surface_normal_for_approach: Optional[bool] = None,
        contact_proxy_offset: Optional[float] = None,
        pca_axis_sign_ref: Optional[Sequence[float] | str] = None,
        projection_debug: Optional[bool] = None,
    ):
        if self.intrinsics is None and None in (fx, fy, cx, cy):
            raise ValueError("Camera intrinsics not set. Call init() or pass fx,fy,cx,cy.")

        if fx is None:
            fx = self.intrinsics["fx"]
            fy = self.intrinsics["fy"]
            cx = self.intrinsics["cx"]
            cy = self.intrinsics["cy"]

        object_pc, scene_pc = self.depth_mask_to_point_clouds(
            depth,
            mask,
            fx,
            fy,
            cx,
            cy,
            target_object_id=target_object_id,
            depth_scale=depth_scale,
            remove_object_from_scene=True,
        )
        object_pc = self._downsample_points(object_pc, max_object_points)

        if collision_check:
            scene_pc = self._downsample_points(scene_pc, max_scene_points)
        else:
            scene_pc = None

        return self.inference_from_point_cloud(
            object_pc=object_pc,
            scene_pc=scene_pc,
            collision_check=collision_check,
            grasp_threshold=grasp_threshold,
            num_grasps=num_grasps,
            return_topk=return_topk,
            topk_num_grasps=topk_num_grasps,
            collision_threshold=collision_threshold,
            min_grasps=min_grasps,
            max_tries=max_tries,
            enable_orientation_projection=enable_orientation_projection,
            enable_translation_projection=enable_translation_projection,
            approach_axis_index=approach_axis_index,
            approach_axis_source=approach_axis_source,
            normal_avg_k=normal_avg_k,
            target_approach_direction=target_approach_direction,
            translation_axis=translation_axis,
            desired_offset=desired_offset,
            step_strength_orient=step_strength_orient,
            step_strength_trans=step_strength_trans,
            enable_roll_projection=enable_roll_projection,
            jaw_axis_index=jaw_axis_index,
            target_roll_direction=target_roll_direction,
            roll_target_axis=roll_target_axis,
            roll_target_axis_sign=roll_target_axis_sign,
            roll_use_local_tangent=roll_use_local_tangent,
            step_strength_roll=step_strength_roll,
            use_surface_normal_for_approach=use_surface_normal_for_approach,
            contact_proxy_offset=contact_proxy_offset,
            pca_axis_sign_ref=pca_axis_sign_ref,
            projection_debug=projection_debug,
        )

    def inference_from_depth_mask_with_aperture(
        self,
        depth: Optional[np.ndarray],
        mask: Optional[np.ndarray],
        max_aperture: float,
        fx: Optional[float] = None,
        fy: Optional[float] = None,
        cx: Optional[float] = None,
        cy: Optional[float] = None,
        target_object_id: Optional[int] = None,
        depth_scale: float = 1.0,
        max_object_points: Optional[int] = None,
        max_scene_points: int = 8192,
        collision_check: bool = False,
        grasp_threshold: float = 0.8,
        num_grasps: int = 200,
        return_topk: bool = False,
        topk_num_grasps: int = -1,
        collision_threshold: float = 0.02,
        min_grasps: Optional[int] = None,
        max_tries: Optional[int] = None,
        enable_orientation_projection: Optional[bool] = None,
        enable_translation_projection: Optional[bool] = None,
        approach_axis_index: Optional[int] = None,
        approach_axis_source: Optional[str] = None,
        normal_avg_k: Optional[int] = None,
        target_approach_direction: Optional[Sequence[float]] = None,
        translation_axis: Optional[int] = None,
        desired_offset: Optional[float] = None,
        step_strength_orient: Optional[float] = None,
        step_strength_trans: Optional[float] = None,
        enable_roll_projection: Optional[bool] = None,
        jaw_axis_index: Optional[int] = None,
        target_roll_direction: Optional[Sequence[float] | str] = None,
        roll_target_axis: Optional[int] = None,
        roll_target_axis_sign: Optional[int] = None,
        roll_use_local_tangent: Optional[bool] = None,
        step_strength_roll: Optional[float] = None,
        use_surface_normal_for_approach: Optional[bool] = None,
        contact_proxy_offset: Optional[float] = None,
        pca_axis_sign_ref: Optional[Sequence[float] | str] = None,
        projection_debug: Optional[bool] = None,
        aperture_margin: float = 0.002,
        aperture_axis_index: Optional[int] = None,
        aperture_region_mode: str = "closing_regions",
        aperture_depth_band: float = 0.03,
        aperture_min_points: int = 10,
        aperture_unknown_policy: str = "drop",
        aperture_chunk_size: Optional[int] = None,
        grasp_chunk_size: Optional[int] = None,
        *,
        point_cloud: Optional[np.ndarray] = None,
        roi: Optional[np.ndarray] = None,
        aperture_jaw_axis_index: Optional[int] = None,
        gripper: Optional[str] = None,
    ) -> dict:
        """Run aperture-aware inference from depth inputs.

        Use one of the following:
        - `point_cloud`: already prepared object point cloud.
        - `depth` + `mask`/`roi`: will build object/scene point clouds internally.
        """
        if point_cloud is not None:
            if collision_check:
                raise ValueError("collision_check requires scene-point-cloud construction from depth input.")
            object_pc = point_cloud
            if max_object_points is not None:
                object_pc = self._downsample_points(object_pc, max_object_points)
            return self.inference_from_point_cloud_with_aperture(
                object_pc=object_pc,
                max_aperture=max_aperture,
                scene_pc=None,
                collision_check=False,
                grasp_threshold=grasp_threshold,
                num_grasps=num_grasps,
                return_topk=return_topk,
                topk_num_grasps=topk_num_grasps,
                collision_threshold=collision_threshold,
                min_grasps=min_grasps,
                max_tries=max_tries,
                enable_orientation_projection=enable_orientation_projection,
                enable_translation_projection=enable_translation_projection,
                approach_axis_index=approach_axis_index,
                approach_axis_source=approach_axis_source,
                normal_avg_k=normal_avg_k,
                target_approach_direction=target_approach_direction,
                translation_axis=translation_axis,
                desired_offset=desired_offset,
                step_strength_orient=step_strength_orient,
                step_strength_trans=step_strength_trans,
                enable_roll_projection=enable_roll_projection,
                jaw_axis_index=jaw_axis_index,
                target_roll_direction=target_roll_direction,
                roll_target_axis=roll_target_axis,
                roll_target_axis_sign=roll_target_axis_sign,
                roll_use_local_tangent=roll_use_local_tangent,
                step_strength_roll=step_strength_roll,
                use_surface_normal_for_approach=use_surface_normal_for_approach,
                contact_proxy_offset=contact_proxy_offset,
                pca_axis_sign_ref=pca_axis_sign_ref,
                projection_debug=projection_debug,
                aperture_margin=aperture_margin,
                aperture_axis_index=aperture_axis_index,
                aperture_region_mode=aperture_region_mode,
                aperture_depth_band=aperture_depth_band,
                aperture_min_points=aperture_min_points,
                aperture_unknown_policy=aperture_unknown_policy,
                aperture_chunk_size=aperture_chunk_size,
                grasp_chunk_size=grasp_chunk_size,
                aperture_jaw_axis_index=aperture_jaw_axis_index,
                gripper=gripper,
            )

        if depth is None:
            raise ValueError("depth is required when point_cloud is not provided.")
        if mask is None and roi is None:
            raise ValueError("mask or roi is required when depth is provided.")

        if self.intrinsics is None and None in (fx, fy, cx, cy):
            raise ValueError("Camera intrinsics not set. Call init() or pass fx,fy,cx,cy.")

        if fx is None:
            fx = self.intrinsics["fx"]
            fy = self.intrinsics["fy"]
            cx = self.intrinsics["cx"]
            cy = self.intrinsics["cy"]

        if roi is not None:
            mask = roi

        object_pc, scene_pc = self.depth_mask_to_point_clouds(
            depth,
            mask,
            fx,
            fy,
            cx,
            cy,
            target_object_id=target_object_id,
            depth_scale=depth_scale,
            remove_object_from_scene=True,
        )
        object_pc = self._downsample_points(object_pc, max_object_points)

        if collision_check:
            scene_pc = self._downsample_points(scene_pc, max_scene_points)
        else:
            scene_pc = None

        return self.inference_from_point_cloud_with_aperture(
            object_pc=object_pc,
            max_aperture=max_aperture,
            scene_pc=scene_pc,
            collision_check=collision_check,
            grasp_threshold=grasp_threshold,
            num_grasps=num_grasps,
            return_topk=return_topk,
            topk_num_grasps=topk_num_grasps,
            collision_threshold=collision_threshold,
            min_grasps=min_grasps,
            max_tries=max_tries,
            enable_orientation_projection=enable_orientation_projection,
            enable_translation_projection=enable_translation_projection,
            approach_axis_index=approach_axis_index,
            approach_axis_source=approach_axis_source,
            normal_avg_k=normal_avg_k,
            target_approach_direction=target_approach_direction,
            translation_axis=translation_axis,
            desired_offset=desired_offset,
            step_strength_orient=step_strength_orient,
            step_strength_trans=step_strength_trans,
            enable_roll_projection=enable_roll_projection,
            jaw_axis_index=jaw_axis_index,
            target_roll_direction=target_roll_direction,
            roll_target_axis=roll_target_axis,
            roll_target_axis_sign=roll_target_axis_sign,
            roll_use_local_tangent=roll_use_local_tangent,
            step_strength_roll=step_strength_roll,
            use_surface_normal_for_approach=use_surface_normal_for_approach,
            contact_proxy_offset=contact_proxy_offset,
            pca_axis_sign_ref=pca_axis_sign_ref,
            projection_debug=projection_debug,
            aperture_margin=aperture_margin,
            aperture_axis_index=aperture_axis_index,
            aperture_region_mode=aperture_region_mode,
            aperture_depth_band=aperture_depth_band,
            aperture_min_points=aperture_min_points,
            aperture_unknown_policy=aperture_unknown_policy,
            aperture_chunk_size=aperture_chunk_size,
            grasp_chunk_size=grasp_chunk_size,
            aperture_jaw_axis_index=aperture_jaw_axis_index,
            gripper=gripper,
        )

    def reset(self):
        return self.client.send_data({"operation": "reset"})

    def close(self):
        self.client.close()
