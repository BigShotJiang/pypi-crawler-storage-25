import numpy as np
import cv2


def _project_points(points, fx, fy, cx, cy, image_shape):
    z = points[:, 2]
    valid = z > 1e-6
    u = fx * points[:, 0] / z + cx
    v = fy * points[:, 1] / z + cy
    h, w = image_shape
    valid = valid & (u >= 0) & (u < w) & (v >= 0) & (v < h)
    return np.stack([u, v], axis=1), valid


def _get_color_from_score(scores):
    scores = np.clip(scores, 0.0, 1.0)
    colors = np.stack([scores, 1.0 - scores, np.zeros_like(scores)], axis=1) * 255.0
    return colors.astype(np.uint8)


def draw_grasps_overlay(
    rgb,
    grasps,
    scores,
    fx,
    fy,
    cx,
    cy,
    max_grasps=50,
    line_width=2,
    labels=None,
    label_color=(255, 255, 255),
    label_scale=0.5,
    label_thickness=1,
    control_points=None,
):
    """
    RGB 이미지에 grasp를 투영해 시각화합니다.

    Args:
        rgb: HxWx3 uint8 이미지
        grasps: Kx4x4 grasp poses
        scores: K 점수
        control_points: (옵션) list of (M,3) arrays per grasp. 주어지면 해당 선분을 그림.
    """
    if rgb is None or grasps is None or len(grasps) == 0:
        return None

    frame = rgb.copy()
    if frame.dtype != np.uint8:
        frame = np.clip(frame, 0, 255).astype(np.uint8)

    grasps = np.asarray(grasps)
    scores = np.asarray(scores).reshape(-1)
    image_shape = frame.shape[:2]
    order = np.argsort(scores)[::-1]
    if max_grasps > 0:
        order = order[:max_grasps]
    colors = _get_color_from_score(scores[order])

    axis_length_m = 0.05
    axis_colors = [(0, 0, 255), (0, 255, 0), (255, 0, 0)]  # x,y,z

    for idx, grasp_idx in enumerate(order):
        grasp = grasps[grasp_idx]
        origin = grasp[:3, 3]
        color = tuple(int(c) for c in colors[idx])
        origin_uv, origin_valid = _project_points(origin[None, :], fx, fy, cx, cy, image_shape)
        if not origin_valid[0]:
            continue
        ox, oy = int(origin_uv[0][0]), int(origin_uv[0][1])
        cv2.circle(frame, (ox, oy), max(2, line_width + 1), color, line_width)

        rot = grasp[:3, :3]
        for axis_idx, axis_dir in enumerate([rot[:, 0], rot[:, 1], rot[:, 2]]):
            end_pt = origin + axis_dir * axis_length_m
            end_uv, end_valid = _project_points(end_pt[None, :], fx, fy, cx, cy, image_shape)
            if end_valid[0]:
                ex, ey = int(end_uv[0][0]), int(end_uv[0][1])
                cv2.line(frame, (ox, oy), (ex, ey), axis_colors[axis_idx], line_width)

        if control_points is not None and grasp_idx < len(control_points):
            pts = np.asarray(control_points[grasp_idx], dtype=np.float32)
            pts_cam = (grasp[:3, :3] @ pts.T).T + grasp[:3, 3]
            uv, valid = _project_points(pts_cam, fx, fy, cx, cy, image_shape)
            for i in range(len(uv) - 1):
                if valid[i] and valid[i + 1]:
                    p0 = (int(uv[i][0]), int(uv[i][1]))
                    p1 = (int(uv[i + 1][0]), int(uv[i + 1][1]))
                    cv2.line(frame, p0, p1, color, line_width)

        if labels is not None and grasp_idx < len(labels):
            cv2.putText(
                frame,
                str(labels[grasp_idx]),
                (ox + 4, oy - 6),
                cv2.FONT_HERSHEY_SIMPLEX,
                label_scale,
                label_color,
                label_thickness,
                cv2.LINE_AA,
            )
    return frame
