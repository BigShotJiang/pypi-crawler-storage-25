# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import concurrent.futures
from typing import Any

import pytest
from coreason_manifest.spec.ontology import (
    CognitiveAgentNodeProfile,
    ExecutionEnvelopeState,
    StateVectorProfile,
    SwarmTopologyManifest,
    TraceContextState,
)
from temporalio import activity
from temporalio.testing import WorkflowEnvironment
from temporalio.worker import UnsandboxedWorkflowRunner, Worker

from coreason_runtime.orchestration.workflows.swarm_execution_workflow import SwarmExecutionWorkflow


@activity.defn(name="ExecuteNemoclawSwarmIoActivity")
async def stub_execute_nemoclaw_swarm_io_activity(manifest_payload: dict[str, Any]) -> dict[str, Any]:
    return {"status": "success", "iterations": 5, "results": [{"agent": "did:coreason:agent_1", "output": "ok"}]}


@activity.defn(name="EmitSpanIOActivity")
async def stub_emit_span(*args: Any) -> dict[str, Any]:
    return {"status": "ok"}


@activity.defn(name="StoreEpistemicStateIOActivity")
async def stub_store(*args: Any) -> dict[str, Any]:
    return {"status": "ok"}


@pytest.mark.asyncio
async def test_swarm_execution_workflow_success() -> None:
    """Validate SwarmExecutionWorkflow execution and result aggregation."""
    manifest = SwarmTopologyManifest(
        nodes={
            "did:coreason:agent_1": CognitiveAgentNodeProfile(description="Test Agent 1"),
            "did:coreason:agent_2": CognitiveAgentNodeProfile(description="Test Agent 2"),
        }
    )

    envelope = ExecutionEnvelopeState(
        trace_context=TraceContextState(
            causal_clock=1,
            trace_cid="01H00000000000000000000000",
            span_cid="01H00000000000000000000001",
        ),
        state_vector=StateVectorProfile(immutable_matrix={}, mutable_matrix={}),
        payload=manifest.model_dump(mode="json"),
    )

    payload = envelope.model_dump(mode="json")

    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="swarm-queue",
            workflows=[SwarmExecutionWorkflow],
            activities=[stub_execute_nemoclaw_swarm_io_activity, stub_emit_span, stub_store],
            workflow_runner=UnsandboxedWorkflowRunner(),
            activity_executor=concurrent.futures.ThreadPoolExecutor(),
        ):
            result = await env.client.execute_workflow(
                SwarmExecutionWorkflow.run,
                payload,
                id="swarm-test",
                task_queue="swarm-queue",
            )

            assert result["status"] == "success"
            assert result["iterations"] == 5
            assert len(result["results"]) == 1
            assert result["results"][0]["agent"] == "did:coreason:agent_1"
