# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""Physical substrate tests for CausalInferenceWorkflow.

Tests the full Temporal workflow via WorkflowEnvironment.start_time_skipping()
to ensure correct URN routing based on intent type.
"""

import concurrent.futures
from typing import Any

import pytest
from coreason_manifest.spec.ontology import (
    ExecutionEnvelopeState,
    StateVectorProfile,
    TraceContextState,
)
from temporalio import activity
from temporalio.testing import WorkflowEnvironment
from temporalio.worker import UnsandboxedWorkflowRunner, Worker

from coreason_runtime.orchestration.workflows.causal_inference_workflow import (
    CausalInferenceWorkflow,
)


@activity.defn(name="EmitSpanIOActivity")
async def stub_emit_span(*args: Any, **kwargs: Any) -> dict[str, Any]:
    return {"status": "span_emitted"}


@activity.defn(name="ExecuteMCPToolIOActivity")
async def stub_execute_mcp_tool(
    tool_name: str, intent_payload: dict[str, Any], caller_context: dict[str, Any]
) -> dict[str, Any]:
    return {
        "success": True,
        "mcp_urn_called": tool_name,
        "payload_received": intent_payload,
    }


def _build_causal_envelope(intent_type: str, payload_data: dict[str, Any]) -> dict[str, Any]:
    """Build a physically validated ExecutionEnvelopeState."""
    envelope = ExecutionEnvelopeState(
        trace_context=TraceContextState(
            causal_clock=1,
            trace_cid="01H00000000000000000000000",
            span_cid="01H00000000000000000000001",
        ),
        state_vector=StateVectorProfile(immutable_matrix={}, mutable_matrix={}),
        payload={"intent_type": intent_type, "payload": payload_data},
    )
    return envelope.model_dump(mode="json")


class TestCausalInferenceWorkflow:
    """Physical Temporal tests for CausalInferenceWorkflow."""

    @pytest.mark.asyncio
    async def test_workflow_routes_causal_discovery(self) -> None:
        """Workflow correctly routes CausalDiscoveryIntent to causallearn."""
        payload = _build_causal_envelope("CausalDiscoveryIntent", {"data_url": "s3://dataset"})

        async with await WorkflowEnvironment.start_time_skipping() as env:
            async with Worker(
                env.client,
                task_queue="causal-test-queue",
                workflows=[CausalInferenceWorkflow],
                activities=[stub_emit_span, stub_execute_mcp_tool],
                workflow_runner=UnsandboxedWorkflowRunner(),
                activity_executor=concurrent.futures.ThreadPoolExecutor(),
            ):
                result = await env.client.execute_workflow(
                    CausalInferenceWorkflow.run,
                    payload,
                    id="causal-test-workflow-discovery",
                    task_queue="causal-test-queue",
                )

        assert result["status"] == "success"
        assert len(result["results"]) == 1
        assert result["results"][0]["mcp_urn_called"] == "urn:coreason:actionspace:oracle:pywhy_causallearn:v1"

    @pytest.mark.asyncio
    async def test_workflow_routes_dowhy(self) -> None:
        """Workflow correctly routes DoWhyEstimationIntent to dowhy_estimator."""
        payload = _build_causal_envelope("DoWhyEstimationIntent", {"treatment": "X", "outcome": "Y"})

        async with await WorkflowEnvironment.start_time_skipping() as env:
            async with Worker(
                env.client,
                task_queue="causal-test-queue-2",
                workflows=[CausalInferenceWorkflow],
                activities=[stub_emit_span, stub_execute_mcp_tool],
                workflow_runner=UnsandboxedWorkflowRunner(),
                activity_executor=concurrent.futures.ThreadPoolExecutor(),
            ):
                result = await env.client.execute_workflow(
                    CausalInferenceWorkflow.run,
                    payload,
                    id="causal-test-workflow-dowhy",
                    task_queue="causal-test-queue-2",
                )

        assert result["status"] == "success"
        assert len(result["results"]) == 1
        assert result["results"][0]["mcp_urn_called"] == "urn:coreason:actionspace:oracle:pywhy_dowhy_estimator:v1"

    @pytest.mark.asyncio
    async def test_workflow_routes_econml(self) -> None:
        """Workflow correctly routes EconMLCATEIntent to econml."""
        payload = _build_causal_envelope("EconMLCATEIntent", {"model_type": "DML"})

        async with await WorkflowEnvironment.start_time_skipping() as env:
            async with Worker(
                env.client,
                task_queue="causal-test-queue-3",
                workflows=[CausalInferenceWorkflow],
                activities=[stub_emit_span, stub_execute_mcp_tool],
                workflow_runner=UnsandboxedWorkflowRunner(),
                activity_executor=concurrent.futures.ThreadPoolExecutor(),
            ):
                result = await env.client.execute_workflow(
                    CausalInferenceWorkflow.run,
                    payload,
                    id="causal-test-workflow-econml",
                    task_queue="causal-test-queue-3",
                )

        assert result["status"] == "success"
        assert len(result["results"]) == 1
        assert result["results"][0]["mcp_urn_called"] == "urn:coreason:actionspace:oracle:pywhy_econml:v1"
