# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason-runtime

from typing import Any

import pytest
from temporalio import activity
from temporalio.testing import WorkflowEnvironment
from temporalio.worker import UnsandboxedWorkflowRunner, Worker

from coreason_runtime.orchestration.workflows.value_attribution_workflow import ValueAttributionWorkflow


@activity.defn(name="ExecuteShapleyAttributionComputeActivity")
async def stub_shapley(*args: Any) -> list[dict[str, Any]]:
    return [
        {
            "target_node_cid": "did:coreason:agent_1",
            "causal_attribution_score": 0.6,
            "normalized_contribution_percentage": 0.6,
            "confidence_interval_lower": 0.5,
            "confidence_interval_upper": 0.7,
        },
        {
            "target_node_cid": "did:coreason:agent_2",
            "causal_attribution_score": 0.4,
            "normalized_contribution_percentage": 0.4,
            "confidence_interval_lower": 0.3,
            "confidence_interval_upper": 0.5,
        },
    ]


@activity.defn(name="CalculateCollectiveIntelligenceComputeActivity")
async def stub_ci(*args: Any) -> dict[str, Any]:
    return {"synergy_index": 0.5, "information_integration": 0.8}


@activity.defn(name="StoreEpistemicStateIOActivity")
async def stub_store(*args: Any) -> dict[str, Any]:
    return {"status": "ok"}


@pytest.mark.asyncio
async def test_value_attribution_workflow_success() -> None:
    """Validate ValueAttributionWorkflow efficiency axiom and event synthesis."""
    import concurrent.futures

    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="value-queue",
            workflows=[ValueAttributionWorkflow],
            activities=[stub_shapley, stub_ci, stub_store],
            workflow_runner=UnsandboxedWorkflowRunner(),
            activity_executor=concurrent.futures.ThreadPoolExecutor(),
        ):
            payload = {
                "target_outcome_event_cid": "outcome_123",
                "agent_cids": ["did:coreason:agent_1", "did:coreason:agent_2"],
                "outcome_magnitude": 100.0,
            }
            result = await env.client.execute_workflow(
                ValueAttributionWorkflow.execute,
                payload,
                id="value-test",
                task_queue="value-queue",
            )

    assert result["status"] == "success"
    assert result["event_cid"] == "causal_exp_outcome_123"


@pytest.mark.asyncio
async def test_value_attribution_efficiency_failure() -> None:
    """Validate ValueAttributionWorkflow efficiency axiom failure trigger."""

    @activity.defn(name="ExecuteShapleyAttributionComputeActivity")
    async def stub_shapley_fail(*args: Any) -> list[dict[str, Any]]:
        return [
            {
                "target_node_cid": "did:coreason:agent_1",
                "causal_attribution_score": 0.5,
                "normalized_contribution_percentage": 0.5,
                "confidence_interval_lower": 0.4,
                "confidence_interval_upper": 0.6,
            }
        ]

    import concurrent.futures

    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="value-fail-queue",
            workflows=[ValueAttributionWorkflow],
            activities=[stub_shapley_fail, stub_ci, stub_store],
            workflow_runner=UnsandboxedWorkflowRunner(),
            activity_executor=concurrent.futures.ThreadPoolExecutor(),
        ):
            payload = {
                "target_outcome_event_cid": "outcome_123",
                "agent_cids": ["did:coreason:agent_1"],
                "outcome_magnitude": 100.0,
            }
            with pytest.raises(Exception) as exc:
                await env.client.execute_workflow(
                    ValueAttributionWorkflow.execute,
                    payload,
                    id="value-fail-test",
                    task_queue="value-fail-queue",
                )

            # temporalio.client.WorkflowFailureError
            err = exc.value
            cause = getattr(err, "cause", None)
            assert cause is not None
            assert "Efficiency Axiom fractured" in str(cause)
