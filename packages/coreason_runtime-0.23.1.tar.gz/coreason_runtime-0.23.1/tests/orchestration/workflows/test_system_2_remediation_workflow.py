# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""Tests for System2RemediationWorkflow."""

from typing import Any

import pytest
from temporalio import activity
from temporalio.client import WorkflowFailureError
from temporalio.testing import WorkflowEnvironment
from temporalio.worker import UnsandboxedWorkflowRunner, Worker

from coreason_runtime.orchestration.workflows.system_2_remediation_workflow import (
    System2RemediationWorkflow,
    execute_node_regeneration_activity,
)


@activity.defn(name="EmitSpanIOActivity")
async def stub_emit_span(*args: Any, **kwargs: Any) -> dict[str, Any]:
    return {"status": "span_emitted"}


@pytest.mark.asyncio
async def test_system_2_remediation_workflow_invalid_payload() -> None:
    """Test remediation schema conformance."""
    payload = {"dummy": "invalid"}
    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="sys2-test-queue-err",
            workflows=[System2RemediationWorkflow],
            activities=[stub_emit_span, execute_node_regeneration_activity],
            workflow_runner=UnsandboxedWorkflowRunner(),
        ):
            with pytest.raises(WorkflowFailureError) as exc_info:
                await env.client.execute_workflow(
                    System2RemediationWorkflow.run,
                    payload,
                    id="test-val-wf-sys2-err",
                    task_queue="sys2-test-queue-err",
                )
            assert hasattr(exc_info.value, "cause")
            assert getattr(exc_info.value.cause, "type", "") == "ManifestConformanceError"
