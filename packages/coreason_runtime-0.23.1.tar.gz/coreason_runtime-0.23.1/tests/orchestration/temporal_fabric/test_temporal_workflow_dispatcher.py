import json
import typing

import pytest

from coreason_runtime.orchestration.temporal_workflow_dispatcher import KineticExecutionManifold


@pytest.mark.asyncio
async def test_execute_invalid_json(tmp_path: typing.Any) -> None:
    man = KineticExecutionManifold()
    bad_file = tmp_path / "manifest.json"
    bad_file.write_text("{bad_json")

    with pytest.raises(json.JSONDecodeError):
        await man.execute(str(bad_file))

    fake_file = tmp_path / "not_there.json"
    with pytest.raises(FileNotFoundError):
        await man.execute(str(fake_file))
