"""Real tests for standalone activities in activities.py — no mocks.

Tests the module-level activity functions that don't require a Temporal worker.
"""

import pytest


# ---------------------------------------------------------------------------
# execute_silver_transformation_compute_activity
# ---------------------------------------------------------------------------
class TestSilverTransformation:
    """Real Polars-based Silver ETL transformation."""

    @pytest.mark.asyncio
    async def test_success_path(self) -> None:
        from coreason_runtime.orchestration.activities import execute_silver_transformation_compute_activity

        payload = {
            "data": [
                {"first_name": "Alice", "last_name": "Smith", "age": 30},
                {"first_name": "Bob", "last_name": "Jones", "age": 25},
            ],
            "natural_keys": ["first_name", "last_name"],
        }
        result = await execute_silver_transformation_compute_activity(payload)
        assert result["status"] == "success"
        assert result["transformed_rows"] == 2
        assert "entity_uuid" in result["columns_mapped"]

    @pytest.mark.asyncio
    async def test_missing_data(self) -> None:
        from coreason_runtime.orchestration.activities import execute_silver_transformation_compute_activity

        result = await execute_silver_transformation_compute_activity({"data": [], "natural_keys": ["x"]})
        assert result["status"] == "failed"

    @pytest.mark.asyncio
    async def test_missing_natural_keys(self) -> None:
        from coreason_runtime.orchestration.activities import execute_silver_transformation_compute_activity

        result = await execute_silver_transformation_compute_activity({"data": [{"a": 1}], "natural_keys": []})
        assert result["status"] == "failed"

    @pytest.mark.asyncio
    async def test_invalid_keys_rejected(self) -> None:
        from coreason_runtime.orchestration.activities import execute_silver_transformation_compute_activity

        payload = {
            "data": [{"a": 1}],
            "natural_keys": ["nonexistent_column"],
        }
        result = await execute_silver_transformation_compute_activity(payload)
        assert result["status"] == "rejected"


# ---------------------------------------------------------------------------
# execute_spatial_kinematic_compute_activity
# ---------------------------------------------------------------------------
class TestSpatialKinematic:
    @pytest.mark.asyncio
    async def test_always_forbidden(self) -> None:
        from coreason_runtime.orchestration.activities import execute_spatial_kinematic_compute_activity

        result = await execute_spatial_kinematic_compute_activity({"intent": "click"})
        assert result["success"] is False
        assert "forbidden" in result["error"]
