import pytest

from coreason_runtime.orchestration.activities import calculate_cosine_similarity


@pytest.mark.asyncio
async def test_calculate_cosine_similarity() -> None:
    res = await calculate_cosine_similarity([1.0, 0.0], [1.0, 0.0])
    assert res == 1.0
    res2 = await calculate_cosine_similarity([], [])
    assert res2 == 0.0
    res3 = await calculate_cosine_similarity([0.0], [0.0])
    assert res3 == 0.0
