import pytest

from coreason_runtime.orchestration.activities import KineticActivities


@pytest.fixture
def activities() -> KineticActivities:
    return KineticActivities(memory_path="/tmp/mem")
