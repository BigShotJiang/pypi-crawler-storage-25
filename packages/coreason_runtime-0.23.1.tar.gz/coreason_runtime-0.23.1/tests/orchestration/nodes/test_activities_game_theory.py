import pytest

from coreason_runtime.orchestration.activities import (
    execute_collective_intelligence_activity,
    execute_shapley_attribution_compute_activity,
)


@pytest.mark.asyncio
async def test_shapley_attribution() -> None:
    # 1900-1994
    # Test Exact Path: len <= 10
    agent_cids = ["did:agent:agent_a", "did:agent:agent_b", "did:agent:agent_c"]
    res1 = await execute_shapley_attribution_compute_activity("100.0", agent_cids)
    assert len(res1) == 3
    assert res1[0]["target_node_cid"] == "did:agent:agent_a"

    # Test Monte Carlo Path: len > 10
    agent_cids_large = [f"did:agent:node_{i}" for i in range(12)]
    res2 = await execute_shapley_attribution_compute_activity("100.0", agent_cids_large)
    assert len(res2) == 12

    # Characteristic Value Override Path
    res3 = await execute_shapley_attribution_compute_activity("100.0", ["did:agent:node_x"], {"did:agent:node_x": 50.0})
    assert len(res3) == 1

    # Empty agent path
    res4 = await execute_shapley_attribution_compute_activity("100.0", [])
    assert res4 == []

    # Zero Sum Fallback Path natively enforcing lines 1976-1978 egalitarian fallback natively cleanly
    res_zero = await execute_shapley_attribution_compute_activity("0.0", ["did:agent:node_x", "did:agent:node_y"])
    assert len(res_zero) == 2


@pytest.mark.asyncio
async def test_calculate_collective_intelligence() -> None:
    res1 = await execute_collective_intelligence_activity(100.0, 5)
    assert res1["synergy_index"] == 1.15
    res2 = await execute_collective_intelligence_activity(100.0, 1)
    assert res2["synergy_index"] == 1.0
