import pytest

from coreason_runtime.orchestration.activities import (
    KineticActivities,
    execute_spatial_kinematic_compute_activity,
)


@pytest.fixture
def activities() -> KineticActivities:
    return KineticActivities(memory_path="/tmp/mem")


@pytest.mark.asyncio
async def test_spatial_kinematic() -> None:
    # 1711-1719
    res = await execute_spatial_kinematic_compute_activity({})
    assert res["success"] is False
    assert "forbidden" in res["error"]
