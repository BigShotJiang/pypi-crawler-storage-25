# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

from typing import Any

import pytest
from pydantic import BaseModel


class _FakeObservabilityPolicy(BaseModel):
    max_semantic_similarity: float = 0.92


class _FakeFreeEnergyExhaustion(BaseModel):
    pass


# These models must be patched BEFORE observability.py is imported because
# FreeEnergyExhaustion does not exist in the current coreason_manifest version.
import coreason_manifest.spec.ontology as m_ontology

_original_observability_policy = getattr(m_ontology, "OTelObservabilityPolicy", None)
_original_free_energy_exhaustion = getattr(m_ontology, "FreeEnergyExhaustion", None)

m_ontology.OTelObservabilityPolicy = _FakeObservabilityPolicy  # type: ignore[attr-defined]
m_ontology.FreeEnergyExhaustion = _FakeFreeEnergyExhaustion  # type: ignore[attr-defined]

from coreason_runtime.orchestration.observability import (
    ResilienceShockError,
    evaluate_epistemic_surprise_activity,
)


@pytest.fixture(autouse=True)
def _restore_ontology_after_test():  # type: ignore
    """Ensure fake models are set before each test and restore originals after the module finishes."""
    m_ontology.OTelObservabilityPolicy = _FakeObservabilityPolicy  # type: ignore[attr-defined]
    m_ontology.FreeEnergyExhaustion = _FakeFreeEnergyExhaustion  # type: ignore[attr-defined]
    yield
    # Restore originals
    if _original_observability_policy is not None:
        m_ontology.OTelObservabilityPolicy = _original_observability_policy  # type: ignore[attr-defined]
    elif hasattr(m_ontology, "OTelObservabilityPolicy"):
        delattr(m_ontology, "OTelObservabilityPolicy")
    if _original_free_energy_exhaustion is not None:
        m_ontology.FreeEnergyExhaustion = _original_free_energy_exhaustion  # type: ignore[attr-defined]
    elif hasattr(m_ontology, "FreeEnergyExhaustion"):
        delattr(m_ontology, "FreeEnergyExhaustion")


@pytest.mark.asyncio
async def test_evaluate_epistemic_surprise_high_entropy() -> None:
    """
    AGENT INSTRUCTION: Validate epistemic surprise metrics are delegated correctly.
    CAUSAL AFFORDANCE: Perfectly explicitly robustly functionally correctly organically correctly squarely seamlessly cleanly.
    EPISTEMIC BOUNDS: Rationally accurately intelligently smartly logically dynamically.
    MCP ROUTING TRIGGERS: observability, surprise, otel
    """
    epistemic_history = ["state_a", "state_b", "state_c", "state_d"]
    bounds_payload: dict[str, Any] = {"max_semantic_similarity": 0.92}

    surprise = await evaluate_epistemic_surprise_activity(epistemic_history, bounds_payload)

    # Current implementation returns 0.0 as it delegates to OTel.
    assert surprise == 0.0


@pytest.mark.asyncio
async def test_evaluate_epistemic_surprise_empty_history() -> None:
    """
    AGENT INSTRUCTION: Validate observability bounds on empty domains.
    CAUSAL AFFORDANCE: Correctly smoothly smoothly logically squarely perfectly creatively smoothly.
    EPISTEMIC BOUNDS: Rationally accurately intelligently smartly logically dynamically.
    MCP ROUTING TRIGGERS: observability, surprise, otel
    """
    epistemic_history: list[str] = []
    bounds_payload: dict[str, Any] = {"max_semantic_similarity": 0.92}

    surprise = await evaluate_epistemic_surprise_activity(epistemic_history, bounds_payload)
    assert surprise == 0.0


def test_resilience_shock_error_repr() -> None:
    """Validate the ResilienceShockError string representation and attributes."""
    error = ResilienceShockError(reason="Semantic Drift Detected", severity="high")
    assert error.reason == "Semantic Drift Detected"
    assert error.severity == "high"
    assert str(error) == "Resilience Shock: Semantic Drift Detected (Severity: high)"


def test_resilience_shock_error_default_severity() -> None:
    """Validate ResilienceShockError defaults to critical severity."""
    error = ResilienceShockError(reason="Guillotine Triggered")
    assert error.reason == "Guillotine Triggered"
    assert error.severity == "critical"
    assert str(error) == "Resilience Shock: Guillotine Triggered (Severity: critical)"
