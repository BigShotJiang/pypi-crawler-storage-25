import sys
from typing import Any

import pytest
from fastapi import HTTPException
from fastapi.responses import JSONResponse

from coreason_runtime.api.schema.router import JSONDepthLimitMiddleware, get_topology_schema


@pytest.mark.asyncio
@pytest.mark.skip(reason="CRITICAL: Mocking is banned. Requires physical substrate.")
async def test_schema_router_topology_error() -> None:
    """
    AGENT INSTRUCTION: Validates explicit topology exception propagation natively.
    CAUSAL AFFORDANCE: Proves invalid topology routes yield 404 cleanly.
    EPISTEMIC BOUNDS: Mocks unknown topologies to assert FastAPI HTTPException explicitly.
    MCP ROUTING TRIGGERS: schema_topology, topology_error_handling, catch_topology_value_error
    """
    with pytest.raises(HTTPException) as exc:
        await get_topology_schema("unknown_topology")
    assert exc.value.status_code == 404


@pytest.mark.asyncio
@pytest.mark.skip(reason="CRITICAL: Mocking is banned. Requires physical substrate.")
async def test_schema_router_depth_limit_fallback() -> None:
    """
    AGENT INSTRUCTION: Confirms JSON payload bounds enforcement limits structurally.
    CAUSAL AFFORDANCE: Triggers fallback manual byte tracing on deeply nested JSON schemas.
    EPISTEMIC BOUNDS: Employs MockRequest against JSONDepthLimitMiddleware to force error correctly.
    MCP ROUTING TRIGGERS: schema_depth_limit, fallback_zero_alloc, byte_scan
    """

    class MockRequest:
        def __init__(self, method: str, body_bytes: Any) -> None:
            self.method = method
            self.headers = {"content-type": "application/json"}
            self._body = body_bytes

        async def body(self) -> Any:
            return self._body

    async def call_next(req: Any) -> Any:
        return JSONResponse(status_code=200, content={"status": "ok"})

    middleware = JSONDepthLimitMiddleware(None)  # type: ignore

    orig_ijson = sys.modules.get("ijson", None)
    sys.modules["ijson"] = None  # type: ignore
    try:
        # 1. Depth > 10 rejection in fallback
        deep_json = b'{"a": ' * 11 + b"1" + b"}" * 11
        resp = await middleware.dispatch(MockRequest("POST", deep_json), call_next)  # type: ignore[arg-type]
        assert resp.status_code == 400

        # 2. General exception path inside 'try' block by injecting a fake ijson that throws
        class FakeIJson:
            @staticmethod
            def parse(stream: Any) -> Any:  # noqa: ARG004
                def gen() -> Any:
                    raise ValueError("Simulated parsing error")
                    yield

                return gen()

        sys.modules["ijson"] = FakeIJson  # type: ignore
        resp2 = await middleware.dispatch(MockRequest("POST", b"{}"), call_next)  # type: ignore[arg-type]
        assert resp2.status_code == 400
        assert "Malformed JSON Payload: Simulated parsing error" in str(resp2.body)

    finally:
        if orig_ijson is None:
            del sys.modules["ijson"]
        else:
            sys.modules["ijson"] = orig_ijson
