"""Real tests for capability_allocator.py — no mocks."""

import pytest

from coreason_runtime.execution_plane.capability_allocator import (
    dynamic_capability_injection,
    verify_bundle_integrity,
)
from coreason_runtime.utils.exceptions import IntegrityViolationError

# ---------------------------------------------------------------------------
# verify_bundle_integrity - real tests
# ---------------------------------------------------------------------------


class TestVerifyBundleIntegrity:
    """Exercise the zero-trust Merkle verification path with real hashing."""

    def _real_cid(self, files: dict[str, bytes]) -> str:
        """Reproduce the canonical Merkle CID locally for golden assertions."""
        from coreason_manifest.utils.algebra import compute_merkle_directory_cid

        return compute_merkle_directory_cid(files)

    def test_pass_when_expected_hash_is_none(self) -> None:
        """DRAFT capabilities skip verification."""
        assert verify_bundle_integrity({}, None) is True

    def test_pass_when_expected_hash_is_empty_string(self) -> None:
        assert verify_bundle_integrity({}, "") is True

    def test_pass_for_matching_hash(self) -> None:
        """Golden-path: file contents hash to expected CID."""
        files = {
            "__init__.py": b"# init",
            "manifest.yaml": b"urn: test",
            "schema.py": b"class A: ...",
            "server.py": b"app = FastMCP()",
        }
        expected = self._real_cid(files)
        assert verify_bundle_integrity(files, expected) is True

    def test_fail_for_mismatched_hash(self) -> None:
        """Tampered payload triggers IntegrityViolationError."""
        files = {"__init__.py": b"clean"}
        with pytest.raises(IntegrityViolationError, match="CID mismatch"):
            verify_bundle_integrity(files, "sha256:0000000000000000000000000000000000000000000000000000000000000000")

    def test_deterministic_across_calls(self) -> None:
        """Same input → same CID (RFC-8785 determinism)."""
        files = {"a.py": b"hello", "b.py": b"world"}
        cid1 = self._real_cid(files)
        cid2 = self._real_cid(files)
        assert cid1 == cid2

    def test_order_independent(self) -> None:
        """Sorted-key canonicalization means insertion order doesn't matter."""
        files_a = {"b.py": b"2", "a.py": b"1"}
        files_b = {"a.py": b"1", "b.py": b"2"}
        assert self._real_cid(files_a) == self._real_cid(files_b)


# ---------------------------------------------------------------------------
# dynamic_capability_injection - real tests using real manifest classes
# ---------------------------------------------------------------------------


class TestDynamicCapabilityInjection:
    """Inject capabilities into a real CognitiveActionSpaceManifest."""

    from typing import Any

    def _build_manifest(self) -> Any:
        from coreason_manifest import CognitiveActionSpaceManifest

        return CognitiveActionSpaceManifest.model_construct(
            action_space_cid="test-space",
            entry_point_cid="root",
            capabilities={},
            transition_matrix={},
        )

    def test_inject_adds_capability(self) -> None:
        manifest = self._build_manifest()
        mounted = {"name": "new_tool", "binary_hash": "abc123"}

        result = dynamic_capability_injection(manifest, mounted)

        assert "new_tool" in result.capabilities
        server = result.capabilities["new_tool"]
        from coreason_manifest import MCPServerManifest

        assert isinstance(server, MCPServerManifest)
        assert server.server_cid == "dynamic_mcp_pool"
        assert server.binary_hash == "abc123"

    def test_inject_default_name(self) -> None:
        manifest = self._build_manifest()
        mounted = {"binary_hash": "xyz"}

        result = dynamic_capability_injection(manifest, mounted)
        assert "dynamic_tool" in result.capabilities

    def test_inject_preserves_existing(self) -> None:
        from coreason_manifest import MCPServerManifest, StdioTransportProfile

        manifest = self._build_manifest()
        manifest.capabilities["existing"] = MCPServerManifest.model_construct(  # type: ignore[call-arg]
            server_cid="old",
            binary_hash="old_hash",
            transport=StdioTransportProfile.model_construct(command="x", args=[]),
        )

        result = dynamic_capability_injection(manifest, {"name": "new_cap"})
        assert "existing" in result.capabilities
        assert "new_cap" in result.capabilities

    def test_inject_returns_same_manifest_object(self) -> None:
        manifest = self._build_manifest()
        result = dynamic_capability_injection(manifest, {"name": "x"})
        assert result is manifest
