# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

from datetime import timedelta
from typing import Any

from temporalio import workflow

with workflow.unsafe.imports_passed_through():
    from coreason_manifest.spec.ontology import (
        CausalExplanationEvent,
        CollectiveIntelligenceProfile,
        ShapleyAttributionReceipt,
    )
    from temporalio.exceptions import ApplicationError

    from coreason_runtime.orchestration.workflows.base_topology_workflow import BaseTopologyWorkflow


@workflow.defn(name="ValueAttributionWorkflow", sandboxed=False)
class ValueAttributionWorkflow(BaseTopologyWorkflow):
    """AGENT INSTRUCTION: Aggregate Shapley attributions resolving macro-scale cooperative explanation events committing deterministically to the EpistemicLedgerState bounds."""

    @workflow.run
    async def execute(self, payload: dict[str, Any]) -> dict[str, Any]:
        target_outcome_event_cid = payload.get("target_outcome_event_cid", "unknown_outcome_cid")
        agent_cids = payload.get("agent_cids", [])
        outcome_magnitude = str(payload.get("outcome_magnitude", "100.0"))

        # 1. Execute Shapley Attribution calculations directly isolating fractional utility bounds securely
        receipts_data = await workflow.execute_activity(
            "ExecuteShapleyAttributionComputeActivity",
            args=[outcome_magnitude, agent_cids, None],
            schedule_to_close_timeout=timedelta(minutes=5),
        )

        receipts = [ShapleyAttributionReceipt.model_validate(r) for r in receipts_data]

        # Ensure deterministic signature logic sorting accurately by node boundaries natively tightly
        receipts.sort(key=lambda r: r.target_node_cid)

        # 2. Guarantee the Efficiency Axiom is preserved flawlessly precisely wrapping cleanly exactly cleanly
        total_attribution = sum(r.causal_attribution_score for r in receipts)
        if float(outcome_magnitude) > 0 and abs(total_attribution - 1.0) > 0.001:
            msg = f"SystemFaultEvent: Efficiency Axiom fractured natively mapping 1.0 against {total_attribution}."
            raise ApplicationError(msg, non_retryable=True)

        # 3. Synthesize Emergence metrics mapping swarm limits natively securely
        ci_data = await workflow.execute_activity(
            "CalculateCollectiveIntelligenceComputeActivity",
            args=[float(outcome_magnitude), len(agent_cids)],
            schedule_to_close_timeout=timedelta(minutes=2),
        )

        profile = CollectiveIntelligenceProfile(
            synergy_index=ci_data.get("synergy_index", 1.0),
            information_integration=ci_data.get("information_integration", 1.0),
            coordination_score=1.0,
        )

        # 4. Compile the full Macro-Explanation Event structure cleanly conforming
        event_cid = f"causal_exp_{target_outcome_event_cid}"
        explanation = CausalExplanationEvent(
            event_cid=event_cid,
            target_outcome_event_cid=target_outcome_event_cid,
            timestamp=workflow.now().timestamp(),
            agent_attributions=receipts,
            collective_intelligence=profile,
        )

        # 5. Persist mapping seamlessly resolving permanent Merkle paths
        await workflow.execute_activity(
            "StoreEpistemicStateIOActivity",
            args=[
                {
                    "event_type": "causal_explanation",
                    "event_cid": explanation.event_cid,
                    "payload": explanation.model_dump_json(),
                }
            ],
            schedule_to_close_timeout=timedelta(minutes=2),
        )

        return {"status": "success", "event_cid": explanation.event_cid}
