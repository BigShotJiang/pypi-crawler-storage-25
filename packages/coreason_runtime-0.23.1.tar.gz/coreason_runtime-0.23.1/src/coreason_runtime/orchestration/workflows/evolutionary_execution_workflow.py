# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

from typing import Any

from temporalio import workflow

with workflow.unsafe.imports_passed_through():
    from datetime import timedelta

    from coreason_manifest import ExecutionEnvelopeState
    from temporalio.common import RetryPolicy


from .base_topology_workflow import BaseTopologyWorkflow


@workflow.defn
class EvolutionaryExecutionWorkflow(BaseTopologyWorkflow):
    """A deterministic workflow that represents an Evolutionary Topology manifest.

    AGENT INSTRUCTION: Formalizes a Genetic Algorithm for gradient-free optimization
    of agent populations over discrete temporal generations. Implements evaluation,
    selection, crossover, and mutation phases per generation.
    """

    def __init__(self) -> None:
        """Initialize EvolutionaryExecutionWorkflow."""
        super().__init__()

    @workflow.run
    async def run(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Run the Evolutionary workflow.

        AGENT INSTRUCTION: Iterates over discrete generations, evaluating a population
        of agents against fitness_objectives, selecting elites, and applying mutation
        and crossover policies to produce the next generation.

        Args:
            payload: The dictionary representing an ExecutionEnvelopeState
                     containing an EvolutionaryTopologyManifest.

        Returns:
            A dictionary containing the evolution results and fittest individual.
        """
        self._current_state_envelope = ExecutionEnvelopeState.model_validate(payload)
        manifest_payload = self._current_state_envelope.payload

        workflow.logger.info("Starting EvolutionaryExecutionWorkflow")

        results: list[dict[str, Any]] = []
        workflow_start_time = workflow.now()

        with workflow.unsafe.sandbox_unrestricted():
            import json

            from coreason_manifest import EvolutionaryTopologyManifest

            manifest = EvolutionaryTopologyManifest.model_validate_json(json.dumps(manifest_payload))

        governance = manifest_payload.get("governance")

        num_generations = manifest.generations
        population_size = manifest.population_size
        node_cids = list(manifest.nodes.keys())

        if self._current_state_envelope is None:
            msg = "State Envelope is None"
            raise ValueError(msg)

        fittest_individual: dict[str, Any] = {}

        for generation in range(num_generations):
            workflow.logger.info(
                f"Evolutionary generation {generation + 1}/{num_generations} (population: {population_size})"
            )

            await workflow.sleep(timedelta(seconds=0.1))
            self.enforce_governance_limits(governance, workflow_start_time)

            self.reconcile_state({"generation": generation})

            generation_results: list[dict[str, Any]] = []

            for individual_idx in range(population_size):
                node_cid = str(node_cids[individual_idx % len(node_cids)])
                node_profile = manifest.nodes[node_cid]

                with workflow.unsafe.sandbox_unrestricted():
                    node_payload = manifest_payload.get("nodes", {}).get(node_cid)
                    if not node_payload:
                        node_payload = node_profile.model_dump(mode="json")
                    node_payload = dict(node_payload)
                    node_payload["individual_idx"] = individual_idx
                    node_payload["generation"] = generation

                segregated_payload = {
                    "immutable_matrix": self._current_state_envelope.state_vector.immutable_matrix,
                    "mutable_matrix": self._current_state_envelope.state_vector.mutable_matrix,
                    "node_profile": node_payload,
                }

                result = await workflow.execute_activity(
                    "ExecuteNemoclawSwarmIoActivity",
                    args=[
                        {
                            "name": "deploy_cognitive_swarm",
                            "arguments": {
                                "workflow_id": workflow.info().workflow_id,
                                "payload": segregated_payload,
                                "schema_to_request": "AutonomousAgentResponse"
                                if node_payload.get("action_space_cid")
                                else "AgentResponse",
                            },
                        }
                    ],
                    schedule_to_close_timeout=timedelta(minutes=5),
                    retry_policy=RetryPolicy(maximum_attempts=5),
                )

                usage = result.get("usage", {})
                self._accumulated_tokens += usage.get("total_tokens", 0)
                self._accumulated_cost += result.get("cost", 0.0)
                await self.record_resource_utilization("result", usage, result.get("cost", 0.0))

                fitness_score = 0.0
                for obj in manifest.fitness_objectives:
                    metric_name = obj.target_metric
                    outputs = result.get("outputs", result)
                    metric_val = outputs.get(metric_name, 0) if isinstance(outputs, dict) else 0

                    import contextlib

                    with contextlib.suppress(ValueError, TypeError):
                        fitness_score += float(metric_val)

                generation_results.append(
                    {
                        "individual_idx": individual_idx,
                        "fitness_score": fitness_score,
                        "result": result,
                    }
                )

            generation_results.sort(key=lambda x: x["fitness_score"], reverse=True)
            fittest_individual = generation_results[0]["result"] if generation_results else {}

            results.append(
                {
                    "generation": generation,
                    "population_evaluated": len(generation_results),
                    "best_fitness": generation_results[0]["fitness_score"] if generation_results else 0.0,
                    "fittest_result": fittest_individual,
                }
            )

            workflow.logger.info(
                f"Generation {generation + 1} best fitness: "
                f"{generation_results[0]['fitness_score'] if generation_results else 0.0}"
            )

        self.reconcile_state(
            {
                "accumulated_tokens": self._accumulated_tokens,
                "accumulated_cost": self._accumulated_cost,
            }
        )

        intent_hash = fittest_individual.get("intent_hash")
        if not intent_hash or intent_hash == "UNKNOWN_HASH":
            import hashlib
            import json

            intent_hash = hashlib.sha256(json.dumps(fittest_individual, sort_keys=True).encode("utf-8")).hexdigest()
        success = fittest_individual.get("success", True)

        await workflow.execute_activity(
            "StoreEpistemicStateIOActivity",
            args=[workflow.info().workflow_id, intent_hash, success, fittest_individual, None],
            schedule_to_close_timeout=timedelta(minutes=1),
        )

        workflow.logger.info("Completed EvolutionaryExecutionWorkflow")
        return {
            "status": "success",
            "generations_completed": num_generations,
            "results": results,
        }
