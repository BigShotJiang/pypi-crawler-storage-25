# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

from typing import Any

from temporalio import workflow

with workflow.unsafe.imports_passed_through():
    from datetime import timedelta

    from coreason_manifest import ExecutionEnvelopeState
    from temporalio.common import RetryPolicy


import contextlib

from .base_topology_workflow import BaseTopologyWorkflow


@workflow.defn
class DAGExecutionWorkflow(BaseTopologyWorkflow):
    """A deterministic workflow that traverses a DAG manifest sequentially."""

    def __init__(self) -> None:
        """Initialize DAGExecutionWorkflow."""
        super().__init__()

    @workflow.run
    async def run(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Run the DAG workflow.

        AGENT INSTRUCTION: This workflow natively enforces Speculative Boundaries.
        If a node is flagged as a speculative boundary, it acts as a strict execution barrier,
        preventing traversal until all parent topologies are fully resolved.


        AGENT INSTRUCTION: Detect epistemic_yield (inference failure) — these have no
        'success' key but should be treated as failures to avoid validating against
        OracleExecutionReceipt

        Args:
            payload: The dictionary representing an ExecutionEnvelopeState containing a DAGTopologyManifest.

        Returns:
            A dictionary containing the results of all executed nodes.
        """
        import asyncio
        from collections import defaultdict, deque

        try:
            self._current_state_envelope = ExecutionEnvelopeState.model_validate(payload)
        except Exception as e:
            from temporalio.exceptions import ApplicationError

            raise ApplicationError(
                f"Envelope validation failed: {e!s}", type="ValidationError", non_retryable=True
            ) from e
        manifest_payload = self._current_state_envelope.payload

        workflow.logger.info("Starting DAGExecutionWorkflow")

        results: list[dict[str, Any]] = []

        workflow_start_time = workflow.now()

        with workflow.unsafe.sandbox_unrestricted():
            import json

            from coreason_manifest import DAGTopologyManifest

            safe_payload = dict(manifest_payload)
            safe_payload.pop("governance", None)
            safe_payload.pop("allowed_semantic_classifications", None)
            safe_payload.pop("allowed_information_classifications", None)

            try:
                manifest = DAGTopologyManifest.model_validate_json(json.dumps(manifest_payload))
            except Exception as e:
                from temporalio.exceptions import ApplicationError

                raise ApplicationError(
                    f"Manifest validation failed: {e!s}", type="ValidationError", non_retryable=True
                ) from e

        governance = manifest_payload.get("governance")

        allow_cycles = manifest.allow_cycles
        backpressure = manifest.backpressure
        max_depth = manifest.max_depth
        max_fan_out = manifest.max_fan_out
        speculative_boundaries = manifest.speculative_boundaries

        in_degree: dict[str, int] = defaultdict(int)
        out_edges: dict[str, list[str]] = defaultdict(list)
        in_edges: dict[str, list[str]] = defaultdict(list)

        for node_cid in manifest.nodes:
            in_degree[node_cid] = 0

        for edge in manifest.edges:
            out_edges[edge[0]].append(edge[1])
            in_edges[edge[1]].append(edge[0])
            in_degree[edge[1]] += 1

        if not allow_cycles:
            q = deque([n for n, d in in_degree.items() if d == 0])
            visited = 0
            while q:
                curr = q.popleft()
                visited += 1
                for nxt in out_edges[curr]:
                    in_degree[nxt] -= 1
                    if in_degree[nxt] == 0:
                        q.append(nxt)
            if visited < len(manifest.nodes):
                msg = "Cycles detected in DAG but allow_cycles is False."
                from temporalio.exceptions import ApplicationError

                raise ApplicationError(msg, type="TopologyError", non_retryable=True)
            for node_cid in manifest.nodes:
                in_degree[node_cid] = 0
            for edge in manifest.edges:
                in_degree[edge[1]] += 1

        node_depths = dict.fromkeys(manifest.nodes, 0)
        execution_counts = dict.fromkeys(manifest.nodes, 0)
        max_executions_per_node = 5

        queue = deque([n for n, d in in_degree.items() if d == 0])

        if allow_cycles and not queue and manifest.nodes:
            min_deg = min(in_degree.values())
            queue.extend([n for n, d in in_degree.items() if d == min_deg])
            for n in queue:
                in_degree[n] = 0

        node_results: dict[str, Any] = {}

        active_tasks: list[asyncio.Task[Any]] = []
        running_nodes = set()

        while queue or active_tasks:
            # Sovereign Resilience Check: Pause execution if an external observability shock is detected.
            if self._shock_reason:
                from coreason_runtime.orchestration.observability import ResilienceShockError

                raise ResilienceShockError(self._shock_reason)

            current_batch: list[str] = []

            bp_limit = None
            if backpressure:
                bp_val = getattr(backpressure, "value", None)
                if bp_val is None:
                    bp_val = getattr(backpressure, "limit", backpressure)
                bp_limit = int(bp_val) if isinstance(bp_val, (int, str)) else None

            while queue and (not bp_limit or len(active_tasks) + len(current_batch) < bp_limit):
                node_to_run = queue.popleft()

                is_boundary = False
                if speculative_boundaries:
                    for b in speculative_boundaries:
                        b_id = getattr(b, "boundary_cid", getattr(b, "node_cid", b))
                        if b_id == node_to_run:
                            is_boundary = True
                            break

                if is_boundary:
                    if active_tasks or current_batch:
                        queue.appendleft(node_to_run)
                        break
                    workflow.logger.info(f"Node {node_to_run} is a speculative boundary.")

                current_batch.append(node_to_run)
                running_nodes.add(node_to_run)

            async def execute_node(node_cid: str, depth: int) -> tuple[str, dict[str, Any]]:
                if max_depth is not None and depth > max_depth:
                    msg = f"Max depth {max_depth} exceeded at node {node_cid}"
                    from temporalio.exceptions import ApplicationError

                    raise ApplicationError(msg, type="TopologyError", non_retryable=True)

                if max_fan_out is not None and len(out_edges[node_cid]) > max_fan_out:
                    msg = f"Max fan out {max_fan_out} exceeded at node {node_cid}"
                    from temporalio.exceptions import ApplicationError

                    raise ApplicationError(msg, type="TopologyError", non_retryable=True)

                """Resolve lazy upstream dependencies by un-thunking natively prior to execution."""
                for p_id in in_edges[node_cid]:
                    dep_node = manifest_payload.get("nodes", {}).get(p_id, {})
                    is_thunked = isinstance(dep_node, dict) and dep_node.get("status") == "THUNKED"
                    if p_id not in node_results or is_thunked:
                        workflow.logger.info(f"Un-thunking lazy dependency {p_id} prior to {node_cid}.")
                        if isinstance(dep_node, dict):
                            dep_node["status"] = "ACTIVE"
                        _, p_res = await execute_node(p_id, depth)
                        node_results[p_id] = p_res
                        with contextlib.suppress(ValueError):
                            queue.remove(p_id)

                workflow.logger.info(f"Executing inference for node {node_cid} at depth {depth}")
                await workflow.sleep(timedelta(seconds=0.1))

                self.enforce_governance_limits(governance, workflow_start_time)

                node_profile = manifest.nodes[node_cid]
                with workflow.unsafe.sandbox_unrestricted():
                    node_payload = manifest_payload.get("payload", {}).get("nodes", {}).get(node_cid)
                    if not node_payload:
                        node_payload = node_profile.model_dump(mode="json")

                import copy

                enriched_roc = (
                    copy.deepcopy(self._current_state_envelope.state_vector.immutable_matrix)
                    if self._current_state_envelope
                    else {}
                )
                upstream_outputs = {}
                for p_id in in_edges[node_cid]:
                    if p_id in node_results:
                        upstream_outputs[p_id] = node_results[p_id].get("outputs", {})
                enriched_roc["upstream_dependencies"] = upstream_outputs

                segregated_payload = {
                    "node_profile": getattr(node_profile, "model_dump", lambda: node_profile)(),
                    "immutable_matrix": enriched_roc,
                    "mutable_matrix": self._current_state_envelope.state_vector.mutable_matrix
                    if self._current_state_envelope
                    else {},
                }

                node_type = getattr(node_profile, "topology_class", "agent")

                if node_type == "human":
                    workflow.logger.info(f"Node {node_cid} entering Cybernetic Sleep for Oracle intervention")

                    try:
                        timeout_seconds = getattr(node_profile, "fallback_sla_seconds", 3600)
                        fallback_intent = getattr(node_profile, "fallback_intent", "halt")

                        await workflow.wait_condition(
                            lambda: (
                                self._pending_oracle_override is not None or self._current_oracle_resolution is not None
                            ),
                            timeout=timedelta(seconds=timeout_seconds),
                        )
                    except (TimeoutError, asyncio.exceptions.TimeoutError) as err:
                        workflow.logger.warning(f"Oracle SLA breached. Executing FallbackIntent for {node_cid}")
                        if fallback_intent == "halt":
                            msg = f"Oracle SLA timeout on {node_cid} with fallback_intent=halt"
                            from temporalio.exceptions import ApplicationError

                            raise ApplicationError(msg, type="OracleSLAError", non_retryable=True) from err
                        result = {
                            "intent_hash": "FALSPIFFE/SPIREK_HASH",
                            "status": "degraded",
                            "fallback": fallback_intent,
                        }
                    else:
                        if self._pending_oracle_override is not None:
                            result = self._pending_oracle_override
                            self._pending_oracle_override = None
                        else:
                            result = self._current_oracle_resolution or {}
                            self._current_oracle_resolution = None

                elif node_type == "composite":
                    with workflow.unsafe.sandbox_unrestricted():
                        nested_topology = getattr(node_profile, "topology", {})
                        nested_type = getattr(nested_topology, "type", "dag")

                        dump_func = getattr(nested_topology, "model_dump", None)
                        if dump_func is not None:
                            nested_topology_data = dump_func(mode="json")
                        else:
                            nested_topology_data = {"type": nested_type, "nodes": {}}

                        workflow_class_map = {
                            "dag": "DAGExecutionWorkflow",
                            "swarm": "SwarmExecutionWorkflow",
                            "evaluator_optimizer": "EvaluatorOptimizerExecutionWorkflow",
                            "capability_forge": "CapabilityForgeExecutionWorkflow",
                            "council": "CouncilExecutionWorkflow",
                            "digital_twin": "DigitalTwinExecutionWorkflow",
                            "evolutionary": "EvolutionaryExecutionWorkflow",
                            "smpc": "SMPCExecutionWorkflow",
                            "consensus_federation": "ConsensusFederationExecutionWorkflow",
                            "adversarial_market": "AdversarialMarketExecutionWorkflow",
                            "intent_elicitation": "IntentElicitationExecutionWorkflow",
                            "epistemic_sop": "EpistemicSOPExecutionWorkflow",
                            "system_2_remediation": "System2RemediationWorkflow",
                            "causal_inference": "CausalInferenceWorkflow",
                        }
                        child_workflow_class = workflow_class_map.get(nested_type, "DAGExecutionWorkflow")

                    child_payload = {
                        "state_vector": self._current_state_envelope.state_vector.model_dump(by_alias=True)
                        if self._current_state_envelope and getattr(self._current_state_envelope, "state_vector", None)
                        else {},
                        "payload": nested_topology_data,
                        "trace_context": self._current_state_envelope.trace_context.model_dump(by_alias=True)
                        if self._current_state_envelope and getattr(self._current_state_envelope, "trace_context", None)
                        else {},
                    }
                    result = await workflow.execute_child_workflow(
                        child_workflow_class,
                        args=[child_payload],
                        id=f"{workflow.info().workflow_id}-child-{node_cid}",
                    )

                elif node_type == "memoized":
                    with workflow.unsafe.sandbox_unrestricted():
                        target_hash = getattr(node_profile, "target_topology_hash", None)
                        dp = getattr(node_profile, "model_dump", None)
                        p_dump = dp(mode="json") if dp else {}

                        if not target_hash or target_hash == "UNKNOWN_HASH":
                            import hashlib
                            import json

                            target_hash = hashlib.sha256(json.dumps(p_dump, sort_keys=True).encode("utf-8")).hexdigest()

                    cached_state = await workflow.execute_activity(
                        "FetchMemoizedStateIOActivity",
                        args=[target_hash],
                        schedule_to_close_timeout=timedelta(minutes=1),
                    )

                    if cached_state is not None:
                        workflow.logger.info(f"Memoized state found for {node_cid}")
                        result = cached_state
                    else:
                        workflow.logger.info(f"No memoized state found for {node_cid}, executing inference")
                        result = await workflow.execute_activity(
                            "ExecuteNemoclawSwarmIoActivity",
                            args=[
                                {
                                    "name": "deploy_cognitive_swarm",
                                    "arguments": {
                                        "workflow_id": workflow.info().workflow_id,
                                        "payload": node_payload,
                                        "schema_to_request": (
                                            "AutonomousAgentResponse"
                                            if (
                                                node_payload.get("node_profile", {}).get("action_space_cid")
                                                if isinstance(node_payload, dict) and "node_profile" in node_payload
                                                else (
                                                    node_payload.get("action_space_cid")
                                                    if isinstance(node_payload, dict)
                                                    else None
                                                )
                                            )
                                            else "AgentResponse"
                                        ),
                                    },
                                }
                            ],
                            schedule_to_close_timeout=timedelta(minutes=5),
                            retry_policy=RetryPolicy(maximum_attempts=5),
                        )

                        intent_hash = result.get("intent_hash", target_hash) if result else target_hash
                        success = result.get("success", True) if result else False
                        await workflow.execute_activity(
                            "StoreEpistemicStateIOActivity",
                            args=[workflow.info().workflow_id, intent_hash, success, result, None],
                            schedule_to_close_timeout=timedelta(minutes=1),
                        )

                elif node_type == "system":
                    workflow.logger.info(f"Executing system function for {node_cid}")
                    result = await workflow.execute_activity(
                        "ExecuteSystemFunctionComputeActivity",
                        args=[node_payload],
                        schedule_to_close_timeout=timedelta(minutes=5),
                        retry_policy=RetryPolicy(maximum_attempts=5),
                    )

                else:
                    action_space_cid = (
                        segregated_payload.get("node_profile", {}).get("action_space_cid")
                        if isinstance(segregated_payload, dict) and "node_profile" in segregated_payload
                        else (
                            segregated_payload.get("action_space_cid") if isinstance(segregated_payload, dict) else None
                        )
                    )
                    schema_to_request = "AutonomousAgentResponse" if action_space_cid else "AgentResponse"

                    max_agent_loops = 5
                    loop_count = 0

                    while loop_count < max_agent_loops:
                        loop_count += 1

                        result = await workflow.execute_activity(
                            "ExecuteNemoclawSwarmIoActivity",
                            args=[
                                {
                                    "name": "deploy_cognitive_swarm",
                                    "arguments": {
                                        "workflow_id": workflow.info().workflow_id,
                                        "payload": segregated_payload,
                                        "schema_to_request": schema_to_request,
                                    },
                                }
                            ],
                            schedule_to_close_timeout=timedelta(minutes=5),
                            retry_policy=RetryPolicy(maximum_attempts=5),
                        )

                        # OTel-Native Telemetry Enrichment: Project agentic subconscious thoughts to external observability.
                        # This enables external loop detection without proprietary internal compute logic.
                        await workflow.execute_activity(
                            "EmitSpanIOActivity",
                            args=[
                                {
                                    "name": f"agent_thought:{node_cid}",
                                    "agent_cid": action_space_cid or "unknown",
                                    "thought": (result or {}).get("outputs", {}).get("thought", ""),
                                    "environment_hash": (result or {}).get("intent_hash", "UNKNOWN"),
                                    "kind": "INTERNAL",
                                    "status": (result or {}).get("status", "success"),
                                }
                            ],
                            schedule_to_close_timeout=timedelta(seconds=10),
                        )

                        if result is not None and result.get("status") == "epistemic_yield":
                            error_msg = result.get("error", "") if result else ""
                            if "mechanistic_firewall_trip" in error_msg:
                                intent_hash = result.get("node_cid", node_payload.get("node_cid", "")) if result else ""
                                await workflow.execute_activity(
                                    "ApplyDefeasibleCascadeComputeActivity",
                                    args=[intent_hash],
                                    schedule_to_close_timeout=timedelta(minutes=1),
                                )
                                rollback_intent_payload = {
                                    "cascade_cid": f"cascade-{intent_hash}",
                                    "target_event_cid": intent_hash,
                                    "reason": "Mechanistic Firewall Tripped",
                                }
                                await workflow.execute_activity(
                                    "ExecuteRollbackIOActivity",
                                    args=[workflow.info().workflow_id, rollback_intent_payload],
                                    schedule_to_close_timeout=timedelta(minutes=1),
                                )
                            break

                        outputs_payload = result.get("outputs", {}) if result else {}
                        if isinstance(outputs_payload, dict):
                            actuator_name = outputs_payload.get("tool_name")
                            if "target_tool_name" in outputs_payload and outputs_payload.get("target_tool_name"):
                                actuator_query = {
                                    "target_tool_name": outputs_payload.get("target_tool_name"),
                                    "arguments": outputs_payload.get("tool_arguments", {}),
                                }
                            else:
                                actuator_query = outputs_payload.get(  # type: ignore[assignment]
                                    "tool_arguments", outputs_payload.get("tool_query", {})
                                )
                        else:
                            actuator_name = None
                            actuator_query = {}

                        workflow.logger.warning(f"[DEBUG] action_space_cid: {action_space_cid}")
                        if not actuator_name and action_space_cid:
                            out_text = outputs_payload.get("output", "") if isinstance(outputs_payload, dict) else ""

                            workflow.logger.debug(f"action_space_cid: {action_space_cid} | out_text: {out_text!r}")

                            if isinstance(out_text, str) and out_text.strip().startswith("{"):
                                import json

                                try:
                                    parsed_out = json.loads(out_text)
                                    actuator_name = action_space_cid
                                    actuator_query = parsed_out
                                except Exception as e:
                                    workflow.logger.warning(
                                        f"Failed to infer implicit capability edge for dynamic evaluation context: {e}"
                                    )

                        if not actuator_name or actuator_name == "none":
                            break  # Final autonomous yield accomplished.
                        intent_payload = {
                            "jsonrpc": "2.0",
                            "method": "mcp.ui.emit_intent",
                            "params": {"name": actuator_name, "arguments": actuator_query},
                        }
                        if isinstance(outputs_payload, dict) and "holographic_projection" in outputs_payload:
                            intent_payload["holographic_projection"] = outputs_payload["holographic_projection"]

                        tool_receipt = await workflow.execute_activity(
                            "ExecuteMCPToolIOActivity",
                            args=[actuator_name, intent_payload, segregated_payload.get("node_profile", {})],
                            schedule_to_close_timeout=timedelta(minutes=5),
                        )

                        roc = segregated_payload.get("immutable_matrix")
                        if not isinstance(roc, dict):
                            roc = {}

                        safe_roc = dict(roc)

                        tool_history = safe_roc.get("tool_history")
                        tool_history = [] if not isinstance(tool_history, list) else list(tool_history)

                        tool_history.append(
                            {
                                "tool_name": actuator_name,
                                "tool_query": actuator_query,
                                "observation": tool_receipt,
                            }
                        )
                        safe_roc["tool_history"] = tool_history
                        segregated_payload["immutable_matrix"] = safe_roc

                if isinstance(result, dict):
                    roc = segregated_payload.get("immutable_matrix")
                    if (
                        isinstance(roc, dict)
                        and "tool_history" in roc
                        and "outputs" in result
                        and isinstance(result["outputs"], dict)
                    ):
                        result["outputs"]["tool_history"] = roc["tool_history"]

                    usage = result.get("usage", {})
                    cd = result.get("cost_delta")
                    if cd is None:
                        cd = result.get("cost", 0.0)
                    cost_delta = float(cd if cd is not None else 0.0)

                    if "accumulated_tokens" in result:
                        self._accumulated_tokens = int(result["accumulated_tokens"])
                    else:
                        self._accumulated_tokens += usage.get("total_tokens", 0) if isinstance(usage, dict) else 0

                    self._accumulated_cost += cost_delta

                    await self.record_resource_utilization(
                        "result", usage if isinstance(usage, dict) else {}, cost_delta
                    )
                else:
                    await self.record_resource_utilization("result", {}, 0.0)

                self.reconcile_state(
                    {
                        "accumulated_tokens": self._accumulated_tokens,
                        "accumulated_cost": self._accumulated_cost,
                    }
                )

                intent_hash = result.get("intent_hash") if result else None
                if not intent_hash or intent_hash == "UNKNOWN_HASH":
                    import hashlib
                    import json

                    intent_hash = hashlib.sha256(
                        json.dumps(result if result is not None else {}, sort_keys=True).encode("utf-8")
                    ).hexdigest()
                success = result.get("status") != "epistemic_yield" and result.get("success", True) if result else False

                await workflow.execute_activity(
                    "StoreEpistemicStateIOActivity",
                    args=[workflow.info().workflow_id, intent_hash, success, result, None],
                    schedule_to_close_timeout=timedelta(minutes=1),
                )

                return node_cid, result if result is not None else {}

            for node_cid in current_batch:
                execution_counts[node_cid] += 1
                task = asyncio.create_task(execute_node(node_cid, node_depths[node_cid]))
                active_tasks.append(task)

            if not active_tasks:
                break

            class TaskCompletionChecker:
                def __init__(self, tasks: list[asyncio.Task[Any]]) -> None:
                    self.tasks = tasks

                def __call__(self) -> bool:
                    return any(t.done() for t in self.tasks)

            await workflow.wait_condition(TaskCompletionChecker(active_tasks))

            done = [t for t in active_tasks if t.done()]
            active_tasks = [t for t in active_tasks if not t.done()]

            for task in done:
                node_cid, result = task.result()
                results.append(result)
                node_results[node_cid] = result

                running_nodes.remove(node_cid)

                node_success = result.get("success", True)
                if not node_success:
                    workflow.logger.warning(
                        f"Node {node_cid} failed. Epistemic Quarantine triggered. Downstream branches severed."
                    )
                    continue

                for nxt in out_edges[node_cid]:
                    node_depths[nxt] = max(node_depths[nxt], node_depths[node_cid] + 1)

                    if allow_cycles and execution_counts[nxt] < max_executions_per_node:
                        if nxt not in queue and nxt not in running_nodes:
                            queue.append(nxt)
                    elif not allow_cycles:
                        in_degree[nxt] -= 1
                        if in_degree[nxt] == 0:
                            queue.append(nxt)

        workflow.logger.info("Completed DAGExecutionWorkflow")
        return {"status": "success", "results": results}
