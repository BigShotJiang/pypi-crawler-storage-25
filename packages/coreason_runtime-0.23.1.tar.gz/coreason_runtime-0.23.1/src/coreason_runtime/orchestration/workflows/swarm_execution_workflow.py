# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

from typing import Any

from temporalio import workflow

with workflow.unsafe.imports_passed_through():
    from datetime import timedelta

    from coreason_manifest import ExecutionEnvelopeState


from .base_topology_workflow import BaseTopologyWorkflow


@workflow.defn
class SwarmExecutionWorkflow(BaseTopologyWorkflow):
    """A deterministic workflow that represents an agentic swarm manifest."""

    def __init__(self) -> None:
        """Initialize SwarmExecutionWorkflow."""
        super().__init__()

    @workflow.run
    async def run(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Run the Swarm workflow.
        AGENT INSTRUCTION: Unconditionally clamp the budget to the absolute Pydantic Schema Ceiling
        AGENT INSTRUCTION: Yield back standard failure payload so gather doesn't crash entirely.

        AGENT INSTRUCTION: Fetch fresh mutable memory each iteration to accumulate properly after reconcile deepcopies

        Args:
            payload: The dictionary representing an ExecutionEnvelopeState containing a SwarmTopologyManifest.

        Returns:
            A dictionary containing the final execution status and iterations.
        """
        self._current_state_envelope = ExecutionEnvelopeState.model_validate(payload)
        manifest_payload = self._current_state_envelope.payload

        workflow.logger.info("Starting SwarmExecutionWorkflow")
        # Sovereign Resilience Check: Pause execution if an external observability shock is detected.
        if self._shock_reason:
            from coreason_runtime.orchestration.observability import ResilienceShockError

            raise ResilienceShockError(self._shock_reason)

        results: list[dict[str, Any]] = []

        workflow.logger.info("Delegating swarm execution to NemoClaw API...")

        nemoclaw_result = await workflow.execute_activity(
            "ExecuteNemoclawSwarmIoActivity",
            args=[manifest_payload],
            schedule_to_close_timeout=timedelta(minutes=60),
        )

        results = nemoclaw_result.get("results", [])
        iterations = nemoclaw_result.get("iterations", 1)

        workflow.logger.info("Completed SwarmExecutionWorkflow")
        return {"status": "success", "iterations": iterations, "results": results}
