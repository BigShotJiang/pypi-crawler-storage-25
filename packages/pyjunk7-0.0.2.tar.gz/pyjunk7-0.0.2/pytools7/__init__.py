from . import terminal

sub_versions = {
    "terminal": terminal.__version__,
}