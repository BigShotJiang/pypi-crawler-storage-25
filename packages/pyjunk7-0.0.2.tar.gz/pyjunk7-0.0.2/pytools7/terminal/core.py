from colorama import init, Fore, Style

init(autoreset=True)

def warn(msg, beep=True):
    print(Fore.RED + Style.BRIGHT + "w!> " + msg + ("\a" if beep else ""))

def error(msg, beep=True):
    print(Fore.RED + Style.BRIGHT + "e!> " + msg + ("\a" if beep else ""))

def success(msg):
    print(Fore.GREEN + "s> " + msg)

def info(msg):
    print(Fore.YELLOW + "i> " + msg)

def tip(msg):
    print(Fore.BLUE + "t> " + msg)

def debug(msg):
    print(Fore.MAGENTA + "d> " + msg)

def prompt(msg):
    return input(Fore.CYAN + "r> " + msg)

def hold():
    input("Press ENTER to leave ")
    
