from setuptools import setup, find_packages

with open("README.md", "r") as arq:
    readme = arq.read()


setup(name='pyjunk7',
    version='0.0.2',
    license='MIT License',
    author='Filipe Da Silva',
    long_description=readme,
    long_description_content_type="text/markdown",
    author_email='filipesg4.ds@gmail.com',
    keywords='python tools',
    description=u'A simple library with various tools :p',
    packages=find_packages(),
    install_requires=['colorama'])

