# -*- coding: utf-8 -*-
"""
Enigma Protector API 完整封装 (基于官方 enigma_ide.h)
提供所有常量、结构体、函数声明及 Pythonic 辅助类。
"""

import ctypes
import sys
import platform
import logging
from ctypes import (
    c_bool, c_byte, c_char, c_wchar, c_int, c_uint, c_ulong,
    c_char_p, c_wchar_p, c_void_p, POINTER, Structure, byref,
    create_string_buffer, cast
)
from typing import Optional, Tuple, List

# -------------------- 日志配置 --------------------
logging.basicConfig(level=logging.WARNING, format='[EnigmaAPI] %(levelname)s: %(message)s')
logger = logging.getLogger(__name__)

# -------------------- DLL 自动加载 --------------------
def is_executable_64bit(executable_path: Optional[str] = None) -> bool:
    if executable_path is None:
        executable_path = sys.executable
    arch, _ = platform.architecture(executable_path)
    return arch == "64bit"

_dll_name = "enigma_ide64.dll" if is_executable_64bit() else "enigma_ide.dll"
_enigma = None
try:
    _enigma = ctypes.WinDLL(_dll_name)
    logger.info(f"已加载 DLL: {_dll_name}")
except OSError as e:
    logger.error(f"无法加载 DLL {_dll_name}: {e}")
    _enigma = None

# -------------------- 常量定义 (完全对应头文件) --------------------
# 水印类型
WM_PUBLIC  = 1
WM_PRIVATE = 2

# 加密段数量
NUMBER_OF_CRYPTED_SECTIONS = 16

# 哈希算法类型
HASH_XOR32     = 0
HASH_MD2       = 1
HASH_MD5       = 2
HASH_RipeMD160 = 3
HASH_SH1       = 4
HASH_SHA224    = 5
HASH_SHA256    = 6
HASH_SHA384    = 7
HASH_SHA512    = 8

# EP_RegLoadKey 返回值
LOADKEY_SUCCEEDED           = 0
LOADKEY_REGINFONOTFOUND     = 1
LOADKEY_NAMEBUFFERTOOSMALL  = 2
LOADKEY_KEYBUFFERTOOSMALL   = 3

# EP_RegKeyStatus 返回值
KEY_STATUS_DOESNOTEXIST                         = 0
KEY_STATUS_VALID                                = 1
KEY_STATUS_INVALID                              = 2
KEY_STATUS_STOLEN                               = 3
KEY_STATUS_DATEEXPIRED                          = 4
KEY_STATUS_WITHOUTHARDWARELOCK                  = 5
KEY_STATUS_WITHOUTEXPIRATIONDATE                = 6
KEY_STATUS_WITHOUTREGISTERAFTERDATE             = 7
KEY_STATUS_WITHOUTREGISTERBEFOREDATE            = 8
KEY_STATUS_WITHOUTEXECUTIONSLIMIT               = 9
KEY_STATUS_WITHOUTDAYSLIMIT                     = 10
KEY_STATUS_WITHOUTRUNTIMELIMIT                  = 11
KEY_STATUS_WITHOUTGLOBALTIMELIMIT               = 12
KEY_STATUS_WITHOUTCOUNTRYLOCK                   = 13
KEY_STATUS_COUNTRYINVALID                       = 14
KEY_STATUS_REGISTERAFTERFAILED                  = 15
KEY_STATUS_REGISTERBEFOREFAILED                 = 16
KEY_STATUS_EXECUTIONSEXPIRED                    = 17
KEY_STATUS_DAYSEXPIRED                          = 18
KEY_STATUS_RUNTIMEEXPIRED                       = 19
KEY_STATUS_GLOBALTIMEEXPIRED                    = 20
KEY_STATUS_HARDWARECHANGESEXCEEDED_VOLUMESERIAL = 21
KEY_STATUS_HARDWARECHANGESEXCEEDED_VOLUMENAME   = 22
KEY_STATUS_HARDWARECHANGESEXCEEDED_COMPUTERNAME = 23
KEY_STATUS_HARDWARECHANGESEXCEEDED_CPU          = 24
KEY_STATUS_HARDWARECHANGESEXCEEDED_MOTHERBOARD  = 25
KEY_STATUS_HARDWARECHANGESEXCEEDED_WINDOWSKEY   = 26
KEY_STATUS_HARDWARECHANGESEXCEEDED_HDDSERIAL    = 27
KEY_STATUS_HARDWARECHANGESEXCEEDED_USERNAME     = 28
KEY_STATUS_HARDWAREINVALID                      = 29

# EP_RegEncryptRegistrationInformation / EP_RegDecryptRegistrationInformation 返回值
REG_CRYPT_OK                       = 0
REG_CRYPT_INVALID                  = 1
REG_CRYPT_INSUFFICIENT_BUFFER      = 2
REG_CRYPT_INSUFFICIENT_NAME_BUFFER = 3
REG_CRYPT_INSUFFICIENT_KEY_BUFFER  = 4

# 国家代码 (部分常用，完整列表见头文件)
CN_AFGHANISTAN = 114
CN_ALBANIA = 1
CN_ALGERIA = 2
CN_ARGENTINA = 3
CN_ARMENIA = 4
CN_AUSTRALIA = 5
CN_AUSTRIA = 6
CN_AZERBAIJAN = 7
CN_BAHRAIN = 8
CN_BANGLADESH = 115
CN_BELARUS = 9
CN_BELGIUM = 10
CN_BELIZE = 11
CN_BOLIVIA = 116
CN_BOSNIA = 117
CN_BRAZIL = 13
CN_BRUNEI = 14
CN_BULGARIA = 15
CN_CAMBODIA = 16
CN_CANADA = 17
CN_CARRIBEAN = 118
CN_CHILE = 20
CN_CHINA = 21
CN_COLOMBIA = 22
CN_COSTARICA = 23
CN_CROATIA = 24
CN_CZECH = 25
CN_DENMARK = 26
CN_DOMINICAN = 27
CN_ECUADOR = 28
CN_EGYPT = 29
CN_ELSALVADOR = 30
CN_ESTONIA = 31
CN_ETHIOPIA = 119
CN_FAROE = 32
CN_FINLAND = 33
CN_FRANCE = 34
CN_GEORGIA = 35
CN_GERMANY = 36
CN_GREECE = 37
CN_GREENLAND = 120
CN_GUATEMALA = 38
CN_HONDURAS = 39
CN_HONGKONG = 40
CN_HUNGARU = 41
CN_ICELAND = 42
CN_INDIA = 43
CN_INDONESIA = 44
CN_IRAN = 45
CN_IRAQ = 46
CN_IRELAND = 47
CN_ISRAEL = 48
CN_ITALY = 49
CN_JAMAICA = 50
CN_JAPAN = 51
CN_JORDAN = 52
CN_KAZAKHSTAN = 53
CN_KENYA = 54
CN_KOREA = 56
CN_KUWAIT = 57
CN_KYRGYZSTAN = 58
CN_LAOS = 121
CN_LATVIA = 59
CN_LEBANON = 60
CN_LIBYAN = 122
CN_LIECHTENSTEIN = 62
CN_LITHUANIA = 63
CN_LUXEMBOURG = 64
CN_MACAO = 65
CN_MACEDONIA = 66
CN_MALAYSIA = 67
CN_MALDIVES = 123
CN_MALTA = 124
CN_MEXOCI = 68
CN_MONACO = 70
CN_MONGOLIA = 71
CN_MONTENEGRO = 125
CN_MOROCCO = 72
CN_NEPAL = 126
CN_NETHERLANDS = 73
CN_NEWZEALAND = 74
CN_NICARAGUA = 75
CN_NIGERIA = 127
CN_NORWAY = 76
CN_OMAN = 77
CN_PAKISTAN = 78
CN_PANAMA = 79
CN_PARAGUAY = 80
CN_PERY = 81
CN_PHILIPPINES = 82
CN_POLAND = 83
CN_PORTUGAL = 84
CN_PUERTORICO = 85
CN_QATAR = 86
CN_ROMANIA = 87
CN_RUSSIA = 88
CN_RWANDA = 128
CN_SAUDIARABIA = 89
CN_SENEGAL = 129
CN_SERBIA = 130
CN_SERBIAMONTENEGRO = 90
CN_SINGAROPE = 91
CN_SLOVAKIA = 92
CN_SLOVENIA = 93
CN_SOUTHAFRICA = 94
CN_SPAIN = 95
CN_SRILANKA = 131
CN_SWEDEN = 96
CN_SWITZERLAND = 97
CN_SYRIAN = 132
CN_TAIWAN = 98
CN_TAJIKISTAN = 99
CN_THAILAND = 100
CN_TRINIDADTOBAGO = 101
CN_TUNISIA = 102
CN_TURKEY = 103
CN_TURKMENISTAN = 133
CN_UKRAINE = 104
CN_UAE = 105
CN_UNITEDKINGDOM = 106
CN_USA = 107
CN_URUGUAY = 108
CN_UZBEKISTAN = 109
CN_VENEZUELA = 110
CN_VIETNAM = 111
CN_YEMEN = 112
CN_ZIMBABWE = 113

# -------------------- 结构体定义 (完全对应头文件) --------------------
class TWMContent(Structure):
    """水印内容结构体"""
    _fields_ = [
        ("WMType", c_int),
        ("Name", c_char_p),
        ("NameLen", c_int),
        ("Text", c_char_p),
        ("TextLen", c_int),
        ("FileName", c_char_p),
        ("FileNameLen", c_int),
        ("AFile", c_char_p),
        ("AFileLen", c_int),
    ]
PWMContent = POINTER(TWMContent)

class TKeyInformation(Structure):
    """注册密钥信息结构体 (注意: BOOL 为 int 类型)"""
    _fields_ = [
        ("Stolen", c_int),
        ("CreationYear", c_int),
        ("CreationMonth", c_int),
        ("CreationDay", c_int),
        ("UseKeyExpiration", c_int),
        ("ExpirationYear", c_int),
        ("ExpirationMonth", c_int),
        ("ExpirationDay", c_int),
        ("UseHardwareLocking", c_int),
        ("UseExecutionsLimit", c_int),
        ("ExecutionsCount", c_int),
        ("UseDaysLimit", c_int),
        ("DaysCount", c_int),
        ("UseRunTimeLimit", c_int),
        ("RunTimeMinutes", c_int),
        ("UseGlobalTimeLimit", c_int),
        ("GlobalTimeMinutes", c_int),
        ("UseCountyLimit", c_int),
        ("CountryCode", c_int),
        ("UseRegisterAfter", c_int),
        ("RegisterAfterYear", c_int),
        ("RegisterAfterMonth", c_int),
        ("RegisterAfterDay", c_int),
        ("UseRegisterBefore", c_int),
        ("RegisterBeforeYear", c_int),
        ("RegisterBeforeMonth", c_int),
        ("RegisterBeforeDay", c_int),
        ("EncryptedSections", c_int * NUMBER_OF_CRYPTED_SECTIONS),
    ]
PKeyInformation = POINTER(TKeyInformation)

class TKeyCountries(Structure):
    """国家代码映射 (仅用于内部，通常不直接使用)"""
    _fields_ = [
        ("Name", c_char_p),
        ("Code", c_int),
    ]
PKeyCountries = POINTER(TKeyCountries)

# -------------------- 辅助函数 --------------------
def _require_dll(func):
    """装饰器：确保 DLL 已加载，否则返回安全默认值"""
    def wrapper(*args, **kwargs):
        if _enigma is None:
            logger.warning(f"DLL 未加载，调用 {func.__name__} 返回默认值")
            # 根据返回类型推测默认值
            if func.__name__.startswith("is_") or func.__name__.startswith("check_"):
                return False
            elif func.__name__.startswith("get_") and func.__name__.endswith(("_left", "_total", "_status", "_version", "_code")):
                return -1
            elif func.__name__.endswith("_date"):
                return None
            elif func.__name__.endswith("_string"):
                return ""
            else:
                return None
        try:
            return func(*args, **kwargs)
        except Exception as e:
            logger.exception(f"调用 {func.__name__} 时发生异常")
            return None
    return wrapper

def _encode_str(s: str, is_unicode: bool = False) -> bytes:
    """将 Python 字符串编码为 ANSI 或 UTF-16 (Windows Unicode)"""
    if s is None:
        return None
    if is_unicode:
        return s.encode('utf-16-le')  # Windows wchar_t 为 UTF-16 LE
    else:
        return s.encode('mbcs', errors='ignore')

def _decode_cstr(ptr, is_unicode: bool = False) -> str:
    """从 c_char_p 或 c_wchar_p 解码字符串"""
    if not ptr:
        return ""
    if is_unicode:
        return c_wchar_p(ptr).value
    else:
        return c_char_p(ptr).value.decode('mbcs', errors='ignore')

# -------------------- 函数声明注册 (仅在 DLL 加载后设置) --------------------
if _enigma is not None:
    try:
        # ------------------- 标记 API -------------------
        _enigma.EP_Marker.argtypes = [c_char_p]
        _enigma.EP_Marker.restype = None

        # ------------------- 注册 API (基本) -------------------
        _enigma.EP_RegSaveKey.argtypes = [c_char_p, c_char_p]
        _enigma.EP_RegSaveKey.restype = c_int
        _enigma.EP_RegSaveKeyA.argtypes = [c_char_p, c_char_p]
        _enigma.EP_RegSaveKeyA.restype = c_int
        _enigma.EP_RegSaveKeyW.argtypes = [c_wchar_p, c_wchar_p]
        _enigma.EP_RegSaveKeyW.restype = c_int

        _enigma.EP_RegLoadKey.argtypes = [POINTER(c_char_p), POINTER(c_char_p)]
        _enigma.EP_RegLoadKey.restype = c_int
        _enigma.EP_RegLoadKeyA.argtypes = [POINTER(c_char_p), POINTER(c_char_p)]
        _enigma.EP_RegLoadKeyA.restype = c_int
        _enigma.EP_RegLoadKeyW.argtypes = [POINTER(c_wchar_p), POINTER(c_wchar_p)]
        _enigma.EP_RegLoadKeyW.restype = c_int

        _enigma.EP_RegLoadKeyEx.argtypes = [c_char_p, POINTER(c_int), c_char_p, POINTER(c_int)]
        _enigma.EP_RegLoadKeyEx.restype = c_int

        _enigma.EP_RegCheckKey.argtypes = [c_char_p, c_char_p]
        _enigma.EP_RegCheckKey.restype = c_int
        _enigma.EP_RegCheckKeyA.argtypes = [c_char_p, c_char_p]
        _enigma.EP_RegCheckKeyA.restype = c_int
        _enigma.EP_RegCheckKeyW.argtypes = [c_wchar_p, c_wchar_p]
        _enigma.EP_RegCheckKeyW.restype = c_int

        _enigma.EP_RegDeleteKey.argtypes = []
        _enigma.EP_RegDeleteKey.restype = c_int

        _enigma.EP_RegLoadAndCheckKey.argtypes = []
        _enigma.EP_RegLoadAndCheckKey.restype = c_int

        _enigma.EP_RegCheckAndSaveKey.argtypes = [c_char_p, c_char_p]
        _enigma.EP_RegCheckAndSaveKey.restype = c_int
        _enigma.EP_RegCheckAndSaveKeyA.argtypes = [c_char_p, c_char_p]
        _enigma.EP_RegCheckAndSaveKeyA.restype = c_int
        _enigma.EP_RegCheckAndSaveKeyW.argtypes = [c_wchar_p, c_wchar_p]
        _enigma.EP_RegCheckAndSaveKeyW.restype = c_int

        _enigma.EP_RegHardwareID.argtypes = []
        _enigma.EP_RegHardwareID.restype = c_char_p
        _enigma.EP_RegHardwareIDA.argtypes = []
        _enigma.EP_RegHardwareIDA.restype = c_char_p
        _enigma.EP_RegHardwareIDW.argtypes = []
        _enigma.EP_RegHardwareIDW.restype = c_wchar_p

        _enigma.EP_RegKeyCreationDate.argtypes = [POINTER(c_int), POINTER(c_int), POINTER(c_int)]
        _enigma.EP_RegKeyCreationDate.restype = c_int
        _enigma.EP_RegKeyCreationDateEx.argtypes = []
        _enigma.EP_RegKeyCreationDateEx.restype = c_int

        _enigma.EP_RegKeyExpirationDate.argtypes = [POINTER(c_int), POINTER(c_int), POINTER(c_int)]
        _enigma.EP_RegKeyExpirationDate.restype = c_int
        _enigma.EP_RegKeyExpirationDateEx.argtypes = []
        _enigma.EP_RegKeyExpirationDateEx.restype = c_int

        _enigma.EP_RegKeyExecutions.argtypes = [POINTER(c_int), POINTER(c_int)]
        _enigma.EP_RegKeyExecutions.restype = c_int
        _enigma.EP_RegKeyExecutionsTotal.argtypes = []
        _enigma.EP_RegKeyExecutionsTotal.restype = c_int
        _enigma.EP_RegKeyExecutionsLeft.argtypes = []
        _enigma.EP_RegKeyExecutionsLeft.restype = c_int

        _enigma.EP_RegKeyDays.argtypes = [POINTER(c_int), POINTER(c_int)]
        _enigma.EP_RegKeyDays.restype = c_int
        _enigma.EP_RegKeyDaysTotal.argtypes = []
        _enigma.EP_RegKeyDaysTotal.restype = c_int
        _enigma.EP_RegKeyDaysLeft.argtypes = []
        _enigma.EP_RegKeyDaysLeft.restype = c_int

        _enigma.EP_RegKeyRuntime.argtypes = [POINTER(c_int), POINTER(c_int)]
        _enigma.EP_RegKeyRuntime.restype = c_int
        _enigma.EP_RegKeyRuntimeTotal.argtypes = []
        _enigma.EP_RegKeyRuntimeTotal.restype = c_int
        _enigma.EP_RegKeyRuntimeLeft.argtypes = []
        _enigma.EP_RegKeyRuntimeLeft.restype = c_int

        _enigma.EP_RegKeyGlobalTime.argtypes = [POINTER(c_int), POINTER(c_int)]
        _enigma.EP_RegKeyGlobalTime.restype = c_int
        _enigma.EP_RegKeyGlobalTimeTotal.argtypes = []
        _enigma.EP_RegKeyGlobalTimeTotal.restype = c_int
        _enigma.EP_RegKeyGlobalTimeLeft.argtypes = []
        _enigma.EP_RegKeyGlobalTimeLeft.restype = c_int

        _enigma.EP_RegKeyRegisterAfterDate.argtypes = [POINTER(c_int), POINTER(c_int), POINTER(c_int)]
        _enigma.EP_RegKeyRegisterAfterDate.restype = c_int
        _enigma.EP_RegKeyRegisterAfterDateEx.argtypes = []
        _enigma.EP_RegKeyRegisterAfterDateEx.restype = c_int

        _enigma.EP_RegKeyRegisterBeforeDate.argtypes = [POINTER(c_int), POINTER(c_int), POINTER(c_int)]
        _enigma.EP_RegKeyRegisterBeforeDate.restype = c_int
        _enigma.EP_RegKeyRegisterBeforeDateEx.argtypes = []
        _enigma.EP_RegKeyRegisterBeforeDateEx.restype = c_int

        _enigma.EP_RegKeyInformation.argtypes = [c_char_p, c_char_p, PKeyInformation]
        _enigma.EP_RegKeyInformation.restype = c_int
        _enigma.EP_RegKeyInformationA.argtypes = [c_char_p, c_char_p, PKeyInformation]
        _enigma.EP_RegKeyInformationA.restype = c_int
        _enigma.EP_RegKeyInformationW.argtypes = [c_wchar_p, c_wchar_p, PKeyInformation]
        _enigma.EP_RegKeyInformationW.restype = c_int

        _enigma.EP_RegKeyStatus.argtypes = []
        _enigma.EP_RegKeyStatus.restype = c_int

        _enigma.EP_RegShowDialog.argtypes = []
        _enigma.EP_RegShowDialog.restype = None

        _enigma.EP_RegEncryptRegistrationInformation.argtypes = [
            c_char_p, POINTER(c_int), c_char_p, c_int, c_char_p, c_int
        ]
        _enigma.EP_RegEncryptRegistrationInformation.restype = c_int

        _enigma.EP_RegDecryptRegistrationInformation.argtypes = [
            c_char_p, c_int, c_char_p, POINTER(c_int), c_char_p, POINTER(c_int)
        ]
        _enigma.EP_RegDecryptRegistrationInformation.restype = c_int

        _enigma.EP_RegKeySections.argtypes = []
        _enigma.EP_RegKeySections.restype = c_int

        # 加密段检查函数 (1-16)
        _enigma.EP_RegKeySection.argtypes = [c_int]
        _enigma.EP_RegKeySection.restype = c_int
        for i in range(1, 17):
            fn_name = f"EP_RegKeySection{i}" if i > 1 else "EP_RegKeySection"
            # 注意: EP_RegKeySection1 实际上就是 EP_RegKeySection(1)，但头文件也声明了独立函数
            # 我们统一用 EP_RegKeySection 处理，但也可以单独定义
            if hasattr(_enigma, fn_name):
                getattr(_enigma, fn_name).argtypes = []
                getattr(_enigma, fn_name).restype = c_int

        # ------------------- 在线激活 API -------------------
        _enigma.EP_ActivationShowDialog.argtypes = []
        _enigma.EP_ActivationShowDialog.restype = None

        _enigma.EP_ActivationActivate.argtypes = []
        _enigma.EP_ActivationActivate.restype = c_int

        _enigma.EP_ActivationActivateWithId.argtypes = [c_char_p]
        _enigma.EP_ActivationActivateWithId.restype = c_int
        _enigma.EP_ActivationActivateWithIdA.argtypes = [c_char_p]
        _enigma.EP_ActivationActivateWithIdA.restype = c_int
        _enigma.EP_ActivationActivateWithIdW.argtypes = [c_wchar_p]
        _enigma.EP_ActivationActivateWithIdW.restype = c_int

        _enigma.EP_ActivationDeactivate.argtypes = []
        _enigma.EP_ActivationDeactivate.restype = c_int

        _enigma.EP_ActivationDeactivateWithId.argtypes = [c_char_p]
        _enigma.EP_ActivationDeactivateWithId.restype = c_int
        _enigma.EP_ActivationDeactivateWithIdA.argtypes = [c_char_p]
        _enigma.EP_ActivationDeactivateWithIdA.restype = c_int
        _enigma.EP_ActivationDeactivateWithIdW.argtypes = [c_wchar_p]
        _enigma.EP_ActivationDeactivateWithIdW.restype = c_int

        # ------------------- 试用 API -------------------
        _enigma.EP_TrialExecutions.argtypes = [POINTER(c_int), POINTER(c_int)]
        _enigma.EP_TrialExecutions.restype = c_int
        _enigma.EP_TrialExecutionsTotal.argtypes = []
        _enigma.EP_TrialExecutionsTotal.restype = c_int
        _enigma.EP_TrialExecutionsLeft.argtypes = []
        _enigma.EP_TrialExecutionsLeft.restype = c_int

        _enigma.EP_TrialDays.argtypes = [POINTER(c_int), POINTER(c_int)]
        _enigma.EP_TrialDays.restype = c_int
        _enigma.EP_TrialDaysTotal.argtypes = []
        _enigma.EP_TrialDaysTotal.restype = c_int
        _enigma.EP_TrialDaysLeft.argtypes = []
        _enigma.EP_TrialDaysLeft.restype = c_int

        _enigma.EP_TrialExpirationDate.argtypes = [POINTER(c_int), POINTER(c_int), POINTER(c_int)]
        _enigma.EP_TrialExpirationDate.restype = c_int
        _enigma.EP_TrialExpirationDateEx.argtypes = []
        _enigma.EP_TrialExpirationDateEx.restype = c_int

        _enigma.EP_TrialDateTillDate.argtypes = [
            POINTER(c_int), POINTER(c_int), POINTER(c_int),
            POINTER(c_int), POINTER(c_int), POINTER(c_int)
        ]
        _enigma.EP_TrialDateTillDate.restype = c_int
        _enigma.EP_TrialDateTillDateStartEx.argtypes = []
        _enigma.EP_TrialDateTillDateStartEx.restype = c_int
        _enigma.EP_TrialDateTillDateEndEx.argtypes = []
        _enigma.EP_TrialDateTillDateEndEx.restype = c_int

        _enigma.EP_TrialExecutionTime.argtypes = [POINTER(c_int), POINTER(c_int)]
        _enigma.EP_TrialExecutionTime.restype = c_int
        _enigma.EP_TrialExecutionTimeTotal.argtypes = []
        _enigma.EP_TrialExecutionTimeTotal.restype = c_int
        _enigma.EP_TrialExecutionTimeLeft.argtypes = []
        _enigma.EP_TrialExecutionTimeLeft.restype = c_int

        _enigma.EP_TrialClockReversedDays.argtypes = []
        _enigma.EP_TrialClockReversedDays.restype = c_int

        # ------------------- 杂项 API -------------------
        _enigma.EP_MiscGetWatermark.argtypes = [c_int, PWMContent]
        _enigma.EP_MiscGetWatermark.restype = c_int

        _enigma.EP_MiscCountryCode.argtypes = []
        _enigma.EP_MiscCountryCode.restype = c_int

        # ------------------- 保护字符串 API -------------------
        _enigma.EP_ProtectedStringByID.argtypes = [c_int, c_char_p, c_int]
        _enigma.EP_ProtectedStringByID.restype = c_int

        _enigma.EP_ProtectedStringByKey.argtypes = [c_char_p, c_char_p, c_int]
        _enigma.EP_ProtectedStringByKey.restype = c_int

        # ------------------- 加密 API -------------------
        _enigma.EP_CryptHashBuffer.argtypes = [c_int, c_char_p, c_int, c_char_p]
        _enigma.EP_CryptHashBuffer.restype = c_int

        _enigma.EP_CryptHashFileA.argtypes = [c_int, c_char_p, c_char_p]
        _enigma.EP_CryptHashFileA.restype = c_int
        _enigma.EP_CryptHashFileW.argtypes = [c_int, c_wchar_p, c_char_p]
        _enigma.EP_CryptHashFileW.restype = c_int

        _enigma.EP_CryptHashStringA.argtypes = [c_int, c_char_p, c_char_p]
        _enigma.EP_CryptHashStringA.restype = c_int
        _enigma.EP_CryptHashStringW.argtypes = [c_int, c_wchar_p, c_char_p]
        _enigma.EP_CryptHashStringW.restype = c_int

        _enigma.EP_CryptEncryptBuffer.argtypes = [c_char_p, c_int, c_char_p]
        _enigma.EP_CryptEncryptBuffer.restype = None
        _enigma.EP_CryptEncryptBufferEx.argtypes = [c_char_p, c_char_p, c_int, c_char_p, c_int]
        _enigma.EP_CryptEncryptBufferEx.restype = None

        _enigma.EP_CryptDecryptBuffer.argtypes = [c_char_p, c_int, c_char_p]
        _enigma.EP_CryptDecryptBuffer.restype = None
        _enigma.EP_CryptDecryptBufferEx.argtypes = [c_char_p, c_char_p, c_int, c_char_p, c_int]
        _enigma.EP_CryptDecryptBufferEx.restype = None

        # ------------------- 检测 API -------------------
        _enigma.EP_CheckupCopies.argtypes = [POINTER(c_int), POINTER(c_int)]
        _enigma.EP_CheckupCopies.restype = c_int
        _enigma.EP_CheckupCopiesTotal.argtypes = []
        _enigma.EP_CheckupCopiesTotal.restype = c_int
        _enigma.EP_CheckupCopiesCurrent.argtypes = []
        _enigma.EP_CheckupCopiesCurrent.restype = c_int

        _enigma.EP_CheckupIsProtected.argtypes = []
        _enigma.EP_CheckupIsProtected.restype = c_int

        _enigma.EP_CheckupIsEnigmaOk.argtypes = []
        _enigma.EP_CheckupIsEnigmaOk.restype = c_int

        _enigma.EP_CheckupFindProcess.argtypes = [c_char_p, c_char_p, c_char_p]
        _enigma.EP_CheckupFindProcess.restype = c_int
        _enigma.EP_CheckupFindProcessA.argtypes = [c_char_p, c_char_p, c_char_p]
        _enigma.EP_CheckupFindProcessA.restype = c_int
        _enigma.EP_CheckupFindProcessW.argtypes = [c_wchar_p, c_wchar_p, c_wchar_p]
        _enigma.EP_CheckupFindProcessW.restype = c_int

        _enigma.EP_CheckupVirtualizationTools.argtypes = []
        _enigma.EP_CheckupVirtualizationTools.restype = c_int

        # ------------------- Enigma 版本 -------------------
        _enigma.EP_EnigmaVersion.argtypes = []
        _enigma.EP_EnigmaVersion.restype = c_int

        # ------------------- 启动画面 -------------------
        _enigma.EP_SplashScreenShow.argtypes = []
        _enigma.EP_SplashScreenShow.restype = c_int
        _enigma.EP_SplashScreenHide.argtypes = []
        _enigma.EP_SplashScreenHide.restype = None


    except AttributeError as e:
        logger.error(f"函数声明失败，DLL 版本可能不匹配: {e}")
        _enigma = None

# ==============================
# 高级封装类 (Pythonic API)
# ==============================
class EnigmaHelper:
    """Enigma Protector 完整功能封装，提供 Pythonic 访问"""

    @staticmethod
    def is_loaded() -> bool:
        """检查 DLL 是否成功加载"""
        return _enigma is not None

    # ------------------- 基本状态 -------------------
    @staticmethod
    @_require_dll
    def is_protected() -> bool:
        """检查当前进程是否已被 Enigma 保护"""
        return bool(_enigma.EP_CheckupIsProtected())

    @staticmethod
    @_require_dll
    def is_enigma_ok() -> bool:
        """检查保护是否完整（未被破解）"""
        return bool(_enigma.EP_CheckupIsEnigmaOk())

    @staticmethod
    @_require_dll
    def get_version() -> int:
        """获取 Enigma 保护壳版本号"""
        return _enigma.EP_EnigmaVersion()

    # ------------------- 硬件 ID -------------------
    @staticmethod
    @_require_dll
    def get_hardware_id() -> str:
        """获取当前机器硬件指纹"""
        ptr = _enigma.EP_RegHardwareID()
        return _decode_cstr(ptr)

    # ------------------- 注册信息加载/保存 -------------------
    @staticmethod
    @_require_dll
    def load_key() -> Tuple[str, str]:
        """从注册表加载已保存的用户名和注册码 (返回 (Name, Key) 或 ("", ""))"""
        name_ptr = c_char_p()
        key_ptr = c_char_p()
        if _enigma.EP_RegLoadKey(byref(name_ptr), byref(key_ptr)):
            return _decode_cstr(name_ptr), _decode_cstr(key_ptr)
        return "", ""

    @staticmethod
    @_require_dll
    def save_key(name: str, key: str) -> bool:
        """仅保存注册信息，不校验"""
        return bool(_enigma.EP_RegSaveKey(_encode_str(name), _encode_str(key)))

    @staticmethod
    @_require_dll
    def delete_key() -> bool:
        """删除已保存的注册信息"""
        return bool(_enigma.EP_RegDeleteKey())

    # ------------------- 注册验证 -------------------
    @staticmethod
    @_require_dll
    def check_key(name: str, key: str) -> bool:
        """验证用户名和注册码是否匹配（不保存）"""
        return bool(_enigma.EP_RegCheckKey(_encode_str(name), _encode_str(key)))

    @staticmethod
    @_require_dll
    def check_and_save_key(name: str, key: str) -> bool:
        """验证并保存注册码"""
        return bool(_enigma.EP_RegCheckAndSaveKey(_encode_str(name), _encode_str(key)))

    @staticmethod
    @_require_dll
    def load_and_check_key() -> bool:
        """加载已保存的注册码并验证有效性"""
        return bool(_enigma.EP_RegLoadAndCheckKey())

    @staticmethod
    @_require_dll
    def show_registration_dialog() -> None:
        """弹出内置注册对话框"""
        _enigma.EP_RegShowDialog()

    # ------------------- 注册状态查询 -------------------
    @staticmethod
    @_require_dll
    def get_reg_status() -> int:
        """获取注册状态码（参见 KEY_STATUS_* 常量）"""
        return _enigma.EP_RegKeyStatus()

    @staticmethod
    @_require_dll
    def get_reg_creation_date() -> Optional[Tuple[int, int, int]]:
        """获取注册码创建日期 (年, 月, 日)"""
        y, m, d = c_int(), c_int(), c_int()
        if _enigma.EP_RegKeyCreationDate(byref(y), byref(m), byref(d)):
            return y.value, m.value, d.value
        return None

    @staticmethod
    @_require_dll
    def get_reg_expiration_date() -> Optional[Tuple[int, int, int]]:
        """获取注册码过期日期"""
        y, m, d = c_int(), c_int(), c_int()
        if _enigma.EP_RegKeyExpirationDate(byref(y), byref(m), byref(d)):
            return y.value, m.value, d.value
        return None

    @staticmethod
    @_require_dll
    def get_reg_executions() -> Tuple[int, int]:
        """返回 (总次数, 剩余次数)"""
        total, left = c_int(), c_int()
        _enigma.EP_RegKeyExecutions(byref(total), byref(left))
        return total.value, left.value

    @staticmethod
    @_require_dll
    def get_reg_executions_left() -> int:
        return _enigma.EP_RegKeyExecutionsLeft()

    @staticmethod
    @_require_dll
    def get_reg_executions_total() -> int:
        return _enigma.EP_RegKeyExecutionsTotal()

    @staticmethod
    @_require_dll
    def get_reg_days() -> Tuple[int, int]:
        total, left = c_int(), c_int()
        _enigma.EP_RegKeyDays(byref(total), byref(left))
        return total.value, left.value

    @staticmethod
    @_require_dll
    def get_reg_days_left() -> int:
        return _enigma.EP_RegKeyDaysLeft()

    @staticmethod
    @_require_dll
    def get_reg_days_total() -> int:
        return _enigma.EP_RegKeyDaysTotal()

    @staticmethod
    @_require_dll
    def get_reg_runtime() -> Tuple[int, int]:
        total, left = c_int(), c_int()
        _enigma.EP_RegKeyRuntime(byref(total), byref(left))
        return total.value, left.value

    @staticmethod
    @_require_dll
    def get_reg_runtime_left() -> int:
        return _enigma.EP_RegKeyRuntimeLeft()

    @staticmethod
    @_require_dll
    def get_reg_global_time() -> Tuple[int, int]:
        total, left = c_int(), c_int()
        _enigma.EP_RegKeyGlobalTime(byref(total), byref(left))
        return total.value, left.value

    @staticmethod
    @_require_dll
    def get_reg_global_time_left() -> int:
        return _enigma.EP_RegKeyGlobalTimeLeft()

    @staticmethod
    @_require_dll
    def get_reg_key_information(name: str, key: str) -> Optional[TKeyInformation]:
        """获取注册码的完整信息结构体"""
        info = TKeyInformation()
        if _enigma.EP_RegKeyInformation(_encode_str(name), _encode_str(key), byref(info)):
            return info
        return None

    @staticmethod
    @_require_dll
    def is_registered() -> bool:
        """检查是否已注册且有效 (状态码为 KEY_STATUS_VALID)"""
        return _enigma.EP_RegKeyStatus() == KEY_STATUS_VALID

    # ------------------- 加密段 -------------------
    @staticmethod
    @_require_dll
    def is_section_decrypted(section: int) -> bool:
        """检查指定加密段是否已解密 (1-16)"""
        if 1 <= section <= 16:
            fn = getattr(_enigma, f"EP_RegKeySection{section}" if section > 1 else "EP_RegKeySection")
            return bool(fn())
        return False

    @staticmethod
    @_require_dll
    def get_decrypted_sections_mask() -> int:
        """返回一个位掩码表示哪些段已解密"""
        return _enigma.EP_RegKeySections()

    # ------------------- 试用信息 -------------------
    @staticmethod
    @_require_dll
    def get_trial_days_left() -> int:
        return _enigma.EP_TrialDaysLeft()

    @staticmethod
    @_require_dll
    def get_trial_days_total() -> int:
        return _enigma.EP_TrialDaysTotal()

    @staticmethod
    @_require_dll
    def get_trial_executions_left() -> int:
        return _enigma.EP_TrialExecutionsLeft()

    @staticmethod
    @_require_dll
    def get_trial_executions_total() -> int:
        return _enigma.EP_TrialExecutionsTotal()

    @staticmethod
    @_require_dll
    def get_trial_expiration_date() -> Optional[Tuple[int, int, int]]:
        y, m, d = c_int(), c_int(), c_int()
        if _enigma.EP_TrialExpirationDate(byref(y), byref(m), byref(d)):
            return y.value, m.value, d.value
        return None

    @staticmethod
    @_require_dll
    def get_trial_date_till_date() -> Tuple[Optional[Tuple[int,int,int]], Optional[Tuple[int,int,int]]]:
        sy, sm, sd = c_int(), c_int(), c_int()
        ey, em, ed = c_int(), c_int(), c_int()
        if _enigma.EP_TrialDateTillDate(byref(sy), byref(sm), byref(sd), byref(ey), byref(em), byref(ed)):
            return (sy.value, sm.value, sd.value), (ey.value, em.value, ed.value)
        return None, None

    @staticmethod
    @_require_dll
    def get_trial_execution_time_left() -> int:
        return _enigma.EP_TrialExecutionTimeLeft()

    @staticmethod
    @_require_dll
    def get_trial_clock_reversed_days() -> int:
        return _enigma.EP_TrialClockReversedDays()

    # ------------------- 保护字符串 -------------------
    @staticmethod
    @_require_dll
    def get_protected_string_by_id(str_id: int) -> str:
        size = _enigma.EP_ProtectedStringByID(str_id, None, 0)
        if size <= 0:
            return ""
        buf = create_string_buffer(size)
        _enigma.EP_ProtectedStringByID(str_id, buf, size)
        return buf.value.decode('utf-8', errors='ignore')

    @staticmethod
    @_require_dll
    def get_protected_string_by_key(key: str) -> str:
        key_bytes = _encode_str(key)
        size = _enigma.EP_ProtectedStringByKey(key_bytes, None, 0)
        if size <= 0:
            return ""
        buf = create_string_buffer(size)
        _enigma.EP_ProtectedStringByKey(key_bytes, buf, size)
        return buf.value.decode('utf-8', errors='ignore')

    # ------------------- 加密/解密缓冲区 -------------------
    @staticmethod
    @_require_dll
    def encrypt_buffer(data: bytes, key: str) -> bytes:
        """就地加密字节数据（需传入可变缓冲区）"""
        if not data:
            return data
        buf = create_string_buffer(data, len(data))
        _enigma.EP_CryptEncryptBuffer(buf, len(data), _encode_str(key))
        return buf.raw[:len(data)]

    @staticmethod
    @_require_dll
    def decrypt_buffer(data: bytes, key: str) -> bytes:
        """就地解密字节数据"""
        if not data:
            return data
        buf = create_string_buffer(data, len(data))
        _enigma.EP_CryptDecryptBuffer(buf, len(data), _encode_str(key))
        return buf.raw[:len(data)]

    # ------------------- 哈希 -------------------
    @staticmethod
    @_require_dll
    def hash_buffer(hash_type: int, data: bytes) -> bytes:
        """计算缓冲区哈希，返回原始字节摘要（长度取决于算法）"""
        # 常见哈希长度：MD5=16, SHA1=20, SHA256=32, SHA512=64
        digest_size = {HASH_MD5: 16, HASH_SH1: 20, HASH_SHA256: 32, HASH_SHA512: 64}.get(hash_type, 32)
        digest = create_string_buffer(digest_size)
        ret = _enigma.EP_CryptHashBuffer(hash_type, data, len(data), digest)
        if ret > 0:
            return digest.raw[:ret]
        return b''

    @staticmethod
    @_require_dll
    def hash_string(hash_type: int, text: str) -> bytes:
        """计算字符串哈希"""
        text_bytes = _encode_str(text)
        digest_size = {HASH_MD5: 16, HASH_SH1: 20, HASH_SHA256: 32, HASH_SHA512: 64}.get(hash_type, 32)
        digest = create_string_buffer(digest_size)
        ret = _enigma.EP_CryptHashStringA(hash_type, text_bytes, digest)
        if ret > 0:
            return digest.raw[:ret]
        return b''

    # ------------------- 杂项 -------------------
    @staticmethod
    @_require_dll
    def get_country_code() -> int:
        """获取当前系统国家代码"""
        return _enigma.EP_MiscCountryCode()

    @staticmethod
    @_require_dll
    def find_process(file_name: str = "", window_text: str = "", window_class: str = "") -> bool:
        """检测指定进程是否存在"""
        return bool(_enigma.EP_CheckupFindProcess(
            _encode_str(file_name) if file_name else None,
            _encode_str(window_text) if window_text else None,
            _encode_str(window_class) if window_class else None
        ))

    @staticmethod
    @_require_dll
    def is_virtualization_tools_present() -> bool:
        """检测是否运行在虚拟机中"""
        return bool(_enigma.EP_CheckupVirtualizationTools())

    @staticmethod
    @_require_dll
    def load_configuration(file_path: str) -> bool:
        """加载外部 .enigma 配置文件"""
        return bool(_enigma.EP_LoadConfiguration(_encode_str(file_path)))

    @staticmethod
    @_require_dll
    def show_splash_screen() -> None:
        _enigma.EP_SplashScreenShow()

    @staticmethod
    @_require_dll
    def hide_splash_screen() -> None:
        _enigma.EP_SplashScreenHide()

    # ------------------- 在线激活 (可选) -------------------
    @staticmethod
    @_require_dll
    def show_activation_dialog() -> None:
        _enigma.EP_ActivationShowDialog()

    @staticmethod
    @_require_dll
    def activate() -> bool:
        return bool(_enigma.EP_ActivationActivate())

    @staticmethod
    @_require_dll
    def activate_with_id(activation_id: str) -> bool:
        return bool(_enigma.EP_ActivationActivateWithId(_encode_str(activation_id)))

    @staticmethod
    @_require_dll
    def deactivate() -> bool:
        return bool(_enigma.EP_ActivationDeactivate())