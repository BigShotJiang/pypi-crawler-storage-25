# NoGit

Git sans le bloat — snapshots ZIP + diff intelligent.

NoGit surveille ton dossier de travail et crée des snapshots ZIP automatiquement ou manuellement. Pas de commits, pas de branches, pas de rebases. Juste des ZIPs horodatés et un diff lisible.

---

## Installation

```bash
pip install nogit
```

Ou avec pipx :

```bash
pipx install nogit
```

---

## Commandes

### `nogit` ou `nogit backups`
Liste les snapshots du dossier courant. Propose de lancer un diff ou un restore.

### `nogit snapshot`
Crée un snapshot ZIP complet du dossier courant (mode manuel uniquement).

### `nogit automatic`
Active le watcher — surveille le dossier et crée un snapshot incrémental à chaque modification détectée. Lance un terminal dédié avec les logs en temps réel. Un snapshot complet est créé au démarrage.

> Le watcher utilise `st_mtime` + SHA-256 pour détecter les vraies modifications et éviter les faux positifs (auto-save, restore, etc.).

### `nogit manual`
Désactive le watcher et repasse en mode snapshot manuel.

### `nogit backups --global`
Liste tous les projets NoGit enregistrés sur la machine. Nettoie automatiquement les projets dont le dossier a été supprimé.

### `nogit backups --external`
Configure un dossier de backup externe (second disque, NAS...). Les snapshots y sont copiés automatiquement après chaque création.

### `nogit diff <snap1> <snap2>`
Compare deux snapshots ZIP. Si un des snapshots est incrémental, reconstitue automatiquement l'état complet depuis la chaîne avant de comparer.

Le snapshot le plus ancien est toujours utilisé comme référence (A), le plus récent comme cible (B). Ainsi `added` signifie "apparu dans le temps", `deleted` signifie "disparu dans le temps".

Génère un dossier dans `.nogit/diff/` :

```
.nogit/diff/
  2026-05-23T01_vs_2026-05-23T02/
    diff.txt              — rapport lisible global
    summary.json          — index des fichiers touchés (pour une IA)
    mon_fichier.diff.json — hunks détaillés par fichier modifié
```

### `nogit restore <numéro>`
Restaure le projet depuis un snapshot (le numéro correspond à l'ordre affiché dans `nogit backups`). Si le snapshot est incrémental, remonte automatiquement la chaîne jusqu'au dernier full. Vérifie les MD5 des fichiers binaires et signale les divergences.

Le restore peut aussi être lancé directement depuis `nogit backups` en choisissant `r`.

---

## Structure du dossier

```
projet/
  .nogit/
    snapshots/                          — ZIPs horodatés (full ou incrémentaux)
    diff/
      snap_a_vs_snap_b/                 — un dossier par diff lancé
        diff.txt                        — rapport lisible
        summary.json                    — index des fichiers touchés
        mon_fichier.py.diff.json        — hunks par fichier modifié
  .nogitignore                          — fichiers/dossiers exclus des snapshots
```

Le dossier `.nogit` suit le projet — il peut être partagé ou copié tel quel.

---

## Snapshots

**Full** — contient tous les fichiers du projet (créé par `nogit snapshot` ou au démarrage de `nogit automatic`).

**Incrémental** — contient uniquement les fichiers modifiés depuis le dernier snapshot (créé par le watcher en mode automatique).

Chaque ZIP contient un `nogit.meta.json` indiquant son type (`full` ou `incremental`).

Les fichiers binaires et les fichiers > 10 MB ne sont pas inclus dans le ZIP — un `.meta.json` avec leur taille et MD5 est stocké à la place.

---

## Registry global

NoGit maintient un registre global des projets dans `%USERPROFILE%\.nogit\registry.json` (ou `~/.nogit/registry.json` sur Linux/macOS). Ce fichier est automatiquement synchronisé vers le backup externe si configuré.

---

## Backup externe

Quand un dossier externe est configuré via `nogit backups --external`, la structure suivante est créée :

```
dossier_externe/
  .nogitbackups/
    configs/
      registry.json       — copie du registry global
    NomProjet_abc123/
      snapshots/          — copies des ZIPs
```

---

## Licence

Ce projet est distribué sous licence [GNU AGPL v3 or later](LICENSE). Voir le fichier `LICENSE` pour les détails.

---

## Crédits

Dataset MIME types basé sur [micnic/mime.json](https://github.com/micnic/mime.json) par Nicu Micleușanu, modifié pour inclure les extensions de langages de programmation manquantes.
