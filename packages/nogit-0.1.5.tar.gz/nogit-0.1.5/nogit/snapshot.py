"""nogit snapshot — crée un ZIP du dossier courant."""

import json
import zipfile
import os
from datetime import datetime
from pathlib import Path

from nogit.utils import MAX_FILE_SIZE, is_binary, md5_file, register_project, update_registry_snapshots, get_project_mode, copy_to_external
from nogit.ignore import ensure_nogitignore, load_patterns, is_ignored

NOGIT_META = "nogit.meta.json"


def _write_zip_meta(zf: zipfile.ZipFile, type_: str):
    zf.writestr(NOGIT_META, json.dumps({"type": type_}, indent=2))


def run_full(project_root: Path):
    """Full snapshot sans vérification du mode — utilisé par le watcher au démarrage."""
    nogit_dir = project_root / ".nogit" / "snapshots"
    nogit_dir.mkdir(parents=True, exist_ok=True)

    ensure_nogitignore(project_root)
    dir_patterns, file_patterns = load_patterns(project_root)

    timestamp = datetime.now().strftime("%Y-%m-%dT%H-%M-%S")
    zip_path = nogit_dir / f"{timestamp}.zip"

    register_project(project_root)

    stats = {"included": 0, "meta": 0, "skipped": 0}

    print(f"[nogit] Snapshot initial → {zip_path.name}")

    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        _write_zip_meta(zf, "full")
        for root, dirs, files in os.walk(project_root):
            root_path = Path(root)
            dirs[:] = [
                d for d in dirs
                if not is_ignored(root_path / d, project_root, dir_patterns, file_patterns)
            ]
            for filename in files:
                file_path = root_path / filename
                if is_ignored(file_path, project_root, dir_patterns, file_patterns):
                    stats["skipped"] += 1
                    continue
                relative = file_path.relative_to(project_root)
                size = file_path.stat().st_size
                if size > MAX_FILE_SIZE or is_binary(file_path):
                    meta = {
                        "path": str(relative).replace("\\", "/"),
                        "size_bytes": size,
                        "modified_at": datetime.fromtimestamp(file_path.stat().st_mtime).isoformat(timespec="seconds"),
                        "md5": md5_file(file_path),
                    }
                    zf.writestr(str(relative).replace("\\", "/") + ".meta.json", json.dumps(meta, indent=2))
                    stats["meta"] += 1
                else:
                    zf.write(file_path, relative)
                    stats["included"] += 1

    update_registry_snapshots(project_root)
    copy_to_external(project_root, zip_path)

    total = stats["included"] + stats["meta"] + stats["skipped"]
    size_mb = zip_path.stat().st_size / (1024 * 1024)
    print(f"[nogit] ✓ {zip_path.name}")
    print(f"        {stats['included']} fichiers inclus, {stats['meta']} méta, {stats['skipped']} ignorés ({total} total)")
    print(f"        Taille ZIP : {size_mb:.2f} MB")


def run():
    project_root = Path.cwd()

    mode, _ = get_project_mode(project_root)
    if mode == "auto":
        print("[nogit] Ce projet est en mode automatique — utilisez le watcher pour les snapshots.")
        print("        Faites 'nogit manual' pour repasser en mode manuel.")
        return

    nogit_dir = project_root / ".nogit" / "snapshots"
    nogit_dir.mkdir(parents=True, exist_ok=True)

    ensure_nogitignore(project_root)
    dir_patterns, file_patterns = load_patterns(project_root)

    timestamp = datetime.now().strftime("%Y-%m-%dT%H-%M-%S")
    zip_path = nogit_dir / f"{timestamp}.zip"

    register_project(project_root)

    stats = {"included": 0, "meta": 0, "skipped": 0}

    print(f"[nogit] Snapshot en cours → {zip_path.name}")

    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        _write_zip_meta(zf, "full")
        for root, dirs, files in os.walk(project_root):
            root_path = Path(root)
            dirs[:] = [
                d for d in dirs
                if not is_ignored(root_path / d, project_root, dir_patterns, file_patterns)
            ]
            for filename in files:
                file_path = root_path / filename
                if is_ignored(file_path, project_root, dir_patterns, file_patterns):
                    stats["skipped"] += 1
                    continue
                relative = file_path.relative_to(project_root)
                size = file_path.stat().st_size
                if size > MAX_FILE_SIZE or is_binary(file_path):
                    meta = {
                        "path": str(relative).replace("\\", "/"),
                        "size_bytes": size,
                        "modified_at": datetime.fromtimestamp(file_path.stat().st_mtime).isoformat(timespec="seconds"),
                        "md5": md5_file(file_path),
                    }
                    zf.writestr(str(relative).replace("\\", "/") + ".meta.json", json.dumps(meta, indent=2))
                    stats["meta"] += 1
                else:
                    zf.write(file_path, relative)
                    stats["included"] += 1

    update_registry_snapshots(project_root)
    copy_to_external(project_root, zip_path)

    total = stats["included"] + stats["meta"] + stats["skipped"]
    size_mb = zip_path.stat().st_size / (1024 * 1024)
    print(f"[nogit] ✓ {zip_path.name}")
    print(f"        {stats['included']} fichiers inclus, {stats['meta']} méta, {stats['skipped']} ignorés ({total} total)")
    print(f"        Taille ZIP : {size_mb:.2f} MB")


def run_incremental(project_root: Path, changed_paths: set[str]):
    """Snapshot incrémental — seuls les fichiers modifiés sont inclus."""
    nogit_dir = project_root / ".nogit" / "snapshots"
    nogit_dir.mkdir(parents=True, exist_ok=True)

    ensure_nogitignore(project_root)
    dir_patterns, file_patterns = load_patterns(project_root)

    timestamp = datetime.now().strftime("%Y-%m-%dT%H-%M-%S")
    zip_path = nogit_dir / f"{timestamp}.zip"

    register_project(project_root)

    stats = {"included": 0, "meta": 0, "skipped": 0}

    print(f"[nogit] Snapshot incrémental → {zip_path.name}")

    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        _write_zip_meta(zf, "incremental")
        for file_path_str in changed_paths:
            file_path = Path(file_path_str)

            if not file_path.exists():
                continue

            if is_ignored(file_path, project_root, dir_patterns, file_patterns):
                stats["skipped"] += 1
                continue

            relative = file_path.relative_to(project_root)
            rel_str = str(relative).replace("\\", "/")

            try:
                size = file_path.stat().st_size
            except OSError:
                stats["skipped"] += 1
                continue

            if size > MAX_FILE_SIZE or is_binary(file_path):
                meta = {
                    "path": rel_str,
                    "size_bytes": size,
                    "modified_at": datetime.fromtimestamp(
                        file_path.stat().st_mtime
                    ).isoformat(timespec="seconds"),
                    "md5": md5_file(file_path),
                }
                zf.writestr(rel_str + ".meta.json", json.dumps(meta, indent=2))
                stats["meta"] += 1
            else:
                zf.write(file_path, relative)
                stats["included"] += 1

    update_registry_snapshots(project_root)
    copy_to_external(project_root, zip_path)

    total = stats["included"] + stats["meta"] + stats["skipped"]
    size_mb = zip_path.stat().st_size / (1024 * 1024)
    print(f"[nogit] ✓ {zip_path.name}")
    print(f"        {stats['included']} modifié(s), {stats['meta']} méta, {stats['skipped']} ignorés ({total} total)")
    print(f"        Taille ZIP : {size_mb:.2f} MB")
