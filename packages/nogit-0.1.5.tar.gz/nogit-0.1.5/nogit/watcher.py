"""nogit watcher — surveille un dossier et crée des snapshots automatiques."""

import hashlib
import os
import sys
import time
from pathlib import Path

from nogit.ignore import ensure_nogitignore, load_patterns, is_ignored
from nogit.utils import MAX_FILE_SIZE, is_restoring


_DEBOUNCE_SECONDS = 1.0
_POLL_INTERVAL = 1.0


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def _collect_state(project_path: Path) -> dict[str, tuple[float, str | None]]:
    """Retourne {chemin: (mtime, sha)} pour tous les fichiers surveillés."""
    ensure_nogitignore(project_path)
    dir_patterns, file_patterns = load_patterns(project_path)
    state = {}

    for root, dirs, files in os.walk(project_path):
        root_path = Path(root)
        dirs[:] = [
            d for d in dirs
            if not is_ignored(root_path / d, project_path, dir_patterns, file_patterns)
        ]
        for filename in files:
            file_path = root_path / filename
            if is_ignored(file_path, project_path, dir_patterns, file_patterns):
                continue
            try:
                st = file_path.stat()
                if st.st_size > MAX_FILE_SIZE:
                    continue
                state[str(file_path)] = (st.st_mtime, None)
            except OSError:
                continue

    return state


def _compute_shas(paths: list[str]) -> dict[str, str]:
    result = {}
    for p in paths:
        try:
            result[p] = _sha256(Path(p))
        except OSError:
            pass
    return result


def run(project_path: Path):
    from nogit.utils import set_watcher_pid

    # Enregistrer notre propre PID (le terminal intermédiaire a un PID différent)
    set_watcher_pid(project_path, os.getpid())

    print(f"[nogit] Watcher actif → {project_path}")
    print(f"[nogit] PID : {os.getpid()}")
    print("[nogit] Ctrl+C pour arrêter.")
    print()

    state = _collect_state(project_path)
    shas = _compute_shas(list(state.keys()))

    while True:
        time.sleep(_POLL_INTERVAL)

        if is_restoring(project_path):
            state = _collect_state(project_path)
            shas = _compute_shas(list(state.keys()))
            continue

        new_state = _collect_state(project_path)
        changed_paths = []

        all_paths = set(state) | set(new_state)
        for p in all_paths:
            old = state.get(p)
            new = new_state.get(p)
            if old is None or new is None:
                changed_paths.append(p)
            elif old[0] != new[0]:
                changed_paths.append(p)

        if not changed_paths:
            state = new_state
            continue

        # Debounce — attendre que les écritures soient finies
        time.sleep(_DEBOUNCE_SECONDS)
        new_state = _collect_state(project_path)

        # Vérifier les SHAs des fichiers modifiés
        new_shas = _compute_shas(changed_paths)
        really_changed = [
            p for p in changed_paths
            if new_shas.get(p) != shas.get(p)
        ]

        if really_changed:
            from datetime import datetime
            from nogit.snapshot import run_incremental
            print(f"\n[nogit] {datetime.now().strftime('%H:%M:%S')} — {len(really_changed)} fichier(s) modifié(s) :")
            for p in really_changed:
                path_obj = Path(p)
                try:
                    size = path_obj.stat().st_size
                    rel = path_obj.relative_to(project_path)
                    print(f"  ~ {rel}  ({size} octets)")
                except OSError:
                    print(f"  ~ {p}  (supprimé)")
            print()
            run_incremental(project_path, set(really_changed))
            shas.update(new_shas)

        state = new_state
