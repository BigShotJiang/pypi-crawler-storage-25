"""Constantes et utilitaires partagés."""

import os
import sys
import shutil
import hashlib
import json
from pathlib import Path
from importlib.resources import files

# Charger le dataset MIME types (index.json embarqué dans le package)
_mime_data: dict[str, str] = {}
try:
    _mime_json = files("nogit.data").joinpath("mime_types.json").read_text(encoding="utf-8")
    _mime_data = json.loads(_mime_json)
except Exception:
    pass

# MIME types textuels connus même sous application/
_TEXT_APPLICATION_MIMES = {
    "application/json",
    "application/xml",
    "application/javascript",
    "application/x-javascript",
    "application/typescript",
    "application/x-sh",
    "application/x-python",
    "application/x-ruby",
    "application/x-perl",
    "application/x-php",
    "application/toml",
    "application/yaml",
    "application/x-yaml",
    "application/graphql",
    "application/ld+json",
    "application/manifest+json",
    "application/geo+json",
    "application/x-httpd-php",
    "application/x-tex",
    "application/x-latex",
    "application/sql",
    "application/x-sql",
}

# Dossier global NoGit dans le profil utilisateur Windows
GLOBAL_NOGIT_DIR = Path(os.environ.get("USERPROFILE", Path.home())) / ".nogit"
REGISTRY_FILE = GLOBAL_NOGIT_DIR / "registry.json"

# Limite de taille pour inclure un fichier dans le ZIP (10 MB)
MAX_FILE_SIZE = 10 * 1024 * 1024

# Contenu par défaut du .nogitignore
DEFAULT_NOGITIGNORE = """\
# VCS
.git/
.nogit/

# Python
.venv/
venv/
env/
.env/
__pycache__/
*.pyc
*.pyo
*.pyd
*.egg-info/
*.egg/
.tox/
.eggs/
.mypy_cache/
.ruff_cache/
.pytest_cache/
htmlcov/
.coverage

# Node / JS / TS
node_modules/
.npm/
.yarn/
*.min.js
*.min.css
.next/
.nuxt/
.svelte-kit/
out/
.parcel-cache/
.cache/

# Rust
target/

# C / C++
*.o
*.obj
*.a
*.lib
*.so
*.dll
*.exe
*.out
*.pdb
*.ilk
*.exp

# C# / .NET
bin/
obj/
*.user
*.suo
.vs/
*.nupkg
_ReSharper*/

# Java / Kotlin
*.class
*.jar
*.war
*.aar
.gradle/
gradle/
gradlew
gradlew.bat

# Build générique
dist/
build/
out/
release/
debug/

# Logs & temp
*.log
*.tmp
*.temp
*.swp
*.bak
Thumbs.db
.DS_Store

# Lock files
package-lock.json
yarn.lock
pnpm-lock.yaml
Cargo.lock
poetry.lock
Pipfile.lock
composer.lock

# IDE
.idea/
.vscode/
*.iml
"""

# Extensions binaires connues (sindresorhus/binary-extensions)
BINARY_EXTENSIONS = {
    "3dm","3ds","3g2","3gp","7z","a","aac","adp","afdesign","afphoto","afpub",
    "ai","aif","aiff","alz","ape","apk","appimage","ar","arj","asf","au","avi",
    "bak","baml","bh","bin","bk","bmp","br","bz2","cab","caf","cgm","class",
    "cmx","cpio","cr2","cur","dat","dcm","deb","dex","djvu","dll","dmg","dng",
    "doc","docm","docx","dot","dotm","dra","DS_Store","dsk","dts","dtshd","dvb",
    "dwg","dxf","ecelp4800","ecelp7470","ecelp9600","egg","eol","eot","epub",
    "exe","f4v","fbs","fh","fla","flac","flatpak","fli","flv","fpx","fst","fvt",
    "g3","gh","gif","graffle","gz","gzip","h261","h263","h264","icns","ico",
    "ief","img","ipa","iso","jar","jpeg","jpg","jpgv","jpm","jxr","key","ktx",
    "lha","lib","lvp","lz","lzh","lzma","lzo","m3u","m4a","m4v","mar","mdi",
    "mht","mid","midi","mj2","mka","mkv","mmr","mng","mobi","mov","movie","mp3",
    "mp4","mp4a","mpeg","mpg","mpga","mxu","nef","npx","numbers","nupkg","o",
    "odp","ods","odt","oga","ogg","ogv","otf","pages","pbm","pcx","pdb","pdf",
    "pea","pgm","pic","png","pnm","pot","potm","potx","ppa","ppam","ppm","pps",
    "ppsm","ppsx","ppt","pptm","pptx","psd","pya","pyc","pyd","pyo","pyp",
    "qxd","rar","ras","raw","resources","rgb","rip","rlc","rmf","rmvb","rpm",
    "rtf","rz","s3m","s7z","scpt","sgi","shar","sil","sketch","slk","smv","snk",
    "so","stl","suo","sub","swf","tar","tbz","tbz2","tga","tgz","thmx","tif",
    "tiff","tlz","ttc","ttf","txz","udf","uvh","uvi","uvm","uvp","uvs","uvu",
    "viv","vob","war","wav","wax","wbmp","wdp","weba","webm","webp","whl","wim",
    "wm","wma","wmv","wmx","woff","woff2","wrm","wvx","xbm","xif","xla","xlam",
    "xls","xlsb","xlsm","xlsx","xlt","xltm","xltx","xm","xmind","xpi","xpm",
    "xwd","xz","z","zip","zipx",
}


def md5_file(path: Path) -> str:
    """Calcule le MD5 d'un fichier par chunks."""
    h = hashlib.md5()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def is_binary_by_content(path: Path) -> bool:
    """Détecte si un fichier est binaire via les 8000 premiers bytes (heuristique octet nul)."""
    try:
        with open(path, "rb") as f:
            chunk = f.read(8000)
        return b"\x00" in chunk
    except (OSError, PermissionError):
        return True


def is_binary(path: Path) -> bool:
    """
    Retourne True si le fichier est binaire.
    Ordre de priorité :
      1. MIME type depuis le dataset (index.json)
      2. Liste hardcodée BINARY_EXTENSIONS
      3. Heuristique octet nul
    """
    ext = path.suffix.lstrip(".").lower()

    # 1. Vérification via le dataset MIME
    mime = _mime_data.get(ext, "")
    if mime:
        if mime.startswith("text/"):
            return False
        if mime in _TEXT_APPLICATION_MIMES:
            return False
        if mime.startswith(("image/", "audio/", "video/", "application/")):
            return True

    # 2. Liste hardcodée
    if ext in BINARY_EXTENSIONS:
        return True

    # 3. Heuristique octet nul
    return is_binary_by_content(path)


def load_registry() -> dict:
    """Charge le registre global des projets."""
    GLOBAL_NOGIT_DIR.mkdir(parents=True, exist_ok=True)
    if not REGISTRY_FILE.exists():
        return {}
    try:
        return json.loads(REGISTRY_FILE.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return {}


def save_registry(registry: dict) -> None:
    """Sauvegarde le registre global et le copie vers le backup externe si configuré."""
    GLOBAL_NOGIT_DIR.mkdir(parents=True, exist_ok=True)
    content = json.dumps(registry, indent=2, ensure_ascii=False)
    REGISTRY_FILE.write_text(content, encoding="utf-8")

    ext_path_str = registry.get("_external_backup_dir")
    if ext_path_str:
        try:
            configs_dir = Path(ext_path_str) / ".nogitbackups" / "configs"
            configs_dir.mkdir(parents=True, exist_ok=True)
            (configs_dir / "registry.json").write_text(content, encoding="utf-8")
        except OSError:
            pass


def register_project(project_path: Path) -> None:
    """Enregistre un projet dans le registre global s'il n'y est pas déjà."""
    registry = load_registry()
    key = str(project_path.resolve())
    if key not in registry:
        registry[key] = {"snapshots": []}
        save_registry(registry)


def update_registry_snapshots(project_path: Path) -> None:
    """Met à jour la liste des snapshots d'un projet dans le registre."""
    registry = load_registry()
    key = str(project_path.resolve())
    snap_dir = project_path / ".nogit" / "snapshots"
    snapshots = sorted(snap_dir.glob("*.zip"), reverse=True) if snap_dir.exists() else []
    entry = registry.get(key, {})
    if not isinstance(entry, dict):
        entry = {}
    entry["snapshots"] = [str(p) for p in snapshots]
    registry[key] = entry
    save_registry(registry)


def is_watcher_alive(pid: int) -> bool:
    """Vérifie si le process watcher est encore en vie."""
    if pid <= 0:
        return False
    if sys.platform == "win32":
        import ctypes
        SYNCHRONIZE = 0x00100000
        handle = ctypes.windll.kernel32.OpenProcess(SYNCHRONIZE, False, pid)
        if not handle:
            return False
        ctypes.windll.kernel32.CloseHandle(handle)
        return True
    try:
        os.kill(pid, 0)
        return True
    except (OSError, ProcessLookupError):
        return False


def get_project_mode(project_path: Path) -> tuple[str, int]:
    """Retourne ('auto', pid) ou ('manual', 0) pour un projet."""
    registry = load_registry()
    key = str(project_path.resolve())
    entry = registry.get(key, {})
    if not isinstance(entry, dict):
        return "manual", 0
    pid = entry.get("watcher_pid", 0)
    if pid and is_watcher_alive(pid):
        return "auto", pid
    if pid:
        # PID mort — nettoyer
        entry.pop("watcher_pid", None)
        registry[key] = entry
        save_registry(registry)
    return "manual", 0


def set_watcher_pid(project_path: Path, pid: int) -> None:
    """Enregistre le PID du watcher pour un projet."""
    registry = load_registry()
    key = str(project_path.resolve())
    entry = registry.get(key, {})
    if not isinstance(entry, dict):
        entry = {}
    entry["watcher_pid"] = pid
    registry[key] = entry
    save_registry(registry)


def clear_watcher_pid(project_path: Path) -> None:
    """Supprime le PID du watcher pour un projet."""
    registry = load_registry()
    key = str(project_path.resolve())
    entry = registry.get(key, {})
    if isinstance(entry, dict):
        entry.pop("watcher_pid", None)
        registry[key] = entry
        save_registry(registry)


def project_id(project_path: Path) -> str:
    """Génère un ID projet stable : NomDossier_hash6."""
    resolved = str(project_path.resolve())
    short = hashlib.sha256(resolved.encode()).hexdigest()[:6]
    return f"{project_path.resolve().name}_{short}"


def get_external_backup_dir() -> Path | None:
    """Retourne le dossier de backup externe configuré, ou None."""
    registry = load_registry()
    path_str = registry.get("_external_backup_dir")
    return Path(path_str) if path_str else None


def set_external_backup_dir(path: Path) -> None:
    registry = load_registry()
    registry["_external_backup_dir"] = str(path.resolve())
    save_registry(registry)


def copy_to_external(project_path: Path, zip_path: Path) -> None:
    """Copie un ZIP vers le dossier de backup externe si configuré."""
    ext_dir = get_external_backup_dir()
    if not ext_dir:
        return
    pid = project_id(project_path)
    dest_dir = ext_dir / ".nogitbackups" / pid / "snapshots"
    try:
        dest_dir.mkdir(parents=True, exist_ok=True)
        shutil.copy2(zip_path, dest_dir / zip_path.name)
    except OSError as e:
        print(f"[nogit] Avertissement : backup externe échoué — {e}")


def get_snap_type(zip_path: Path) -> str:
    import zipfile as _zipfile
    with _zipfile.ZipFile(zip_path, "r") as zf:
        if "nogit.meta.json" in zf.namelist():
            return json.loads(zf.read("nogit.meta.json"))["type"]
    return "full"


def resolve_snapshot_contents(zip_path: Path) -> dict[str, str | dict]:
    """Reconstitue l'état complet d'un snapshot en remontant la chaîne si incrémental."""
    import zipfile as _zipfile

    snap_dir = zip_path.parent
    all_snaps = sorted(snap_dir.glob("*.zip"))

    if zip_path not in all_snaps:
        chain = [zip_path]
    elif get_snap_type(zip_path) == "full":
        chain = [zip_path]
    else:
        idx = all_snaps.index(zip_path)
        chain = []
        for snap in reversed(all_snaps[: idx + 1]):
            chain.insert(0, snap)
            if get_snap_type(snap) == "full":
                break

    # Appliquer les ZIPs dans l'ordre — les plus récents écrasent les anciens
    contents = {}
    for snap in chain:
        with _zipfile.ZipFile(snap, "r") as zf:
            for name in zf.namelist():
                if name == "nogit.meta.json":
                    continue
                if name.endswith(".meta.json"):
                    data = json.loads(zf.read(name).decode("utf-8"))
                    original = name[: -len(".meta.json")]
                    contents[original] = {"_meta": True, **data}
                else:
                    try:
                        contents[name] = zf.read(name).decode("utf-8", errors="replace")
                    except Exception:
                        contents[name] = ""

    return contents


def set_restoring(project_path: Path, value: bool) -> None:
    registry = load_registry()
    key = str(project_path.resolve())
    entry = registry.get(key, {})
    if not isinstance(entry, dict):
        entry = {}
    if value:
        entry["restoring"] = True
    else:
        entry.pop("restoring", None)
    registry[key] = entry
    save_registry(registry)


def is_restoring(project_path: Path) -> bool:
    registry = load_registry()
    key = str(project_path.resolve())
    entry = registry.get(key, {})
    return isinstance(entry, dict) and entry.get("restoring", False)
