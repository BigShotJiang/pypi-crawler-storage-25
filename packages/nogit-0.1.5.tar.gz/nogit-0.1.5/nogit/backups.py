"""nogit backups — liste les snapshots d'un projet ou de tous les projets."""

import sys
from pathlib import Path
from datetime import datetime
from nogit.utils import load_registry, save_registry, get_project_mode, get_external_backup_dir, set_external_backup_dir


def _is_interactive() -> bool:
    return sys.stdin.isatty()


def _format_date(stem: str) -> str:
    try:
        dt = datetime.strptime(stem, "%Y-%m-%dT%H-%M-%S")
        return dt.strftime("%d/%m/%Y %H:%M:%S")
    except ValueError:
        return stem


def _format_size(size_bytes: int) -> str:
    if size_bytes < 1024 * 1024:
        return f"{size_bytes / 1024:.1f} KB"
    return f"{size_bytes / (1024 * 1024):.1f} MB"


def _list_snapshots(project_path: Path) -> list[Path]:
    """Retourne les snapshots d'un projet triés du plus récent au plus ancien."""
    snap_dir = project_path / ".nogit" / "snapshots"
    if not snap_dir.exists():
        return []
    return sorted(snap_dir.glob("*.zip"), reverse=True)


def _show_snapshots_and_diff(project_path: Path):
    from nogit import diff as diff_module
    from nogit import restore as restore_module

    snapshots = _list_snapshots(project_path)
    if not snapshots:
        print("  Aucun snapshot trouvé.")
        return

    print(f"\n  Snapshots de {project_path}")
    print()
    for i, snap in enumerate(snapshots, 1):
        size = _format_size(snap.stat().st_size)
        date_str = _format_date(snap.stem)
        print(f"  {i:>3}. {date_str}  ({size})")

    print()
    if not _is_interactive():
        return
    action = input("  > [d]iff / [r]estore / Entrée pour annuler : ").strip().lower()
    if not action:
        return

    if action in ("d", "diff"):
        choice = input("  > diff entre (ex: 1 2) : ").strip()
        parts = choice.split()
        if len(parts) != 2:
            print("  Format invalide. Exemple : 1 2")
            return
        try:
            a, b = int(parts[0]) - 1, int(parts[1]) - 1
            if not (0 <= a < len(snapshots) and 0 <= b < len(snapshots)):
                print("  Numéros invalides.")
                return
            # snap A = le plus ancien (index le plus grand car liste inversée)
            older, newer = sorted([a, b], reverse=True)
            diff_module.run(str(snapshots[older]), str(snapshots[newer]))
        except ValueError:
            print("  Numéros invalides.")

    elif action in ("r", "restore"):
        choice = input("  > numéro du snapshot à restaurer : ").strip()
        try:
            idx = int(choice)
            restore_module.run(idx)
        except ValueError:
            print("  Numéro invalide.")


def run(global_: bool = False, external: bool = False):
    if external:
        _run_external()
    elif global_:
        _run_global()
    else:
        _run_local()


def _run_external():
    ext_dir = get_external_backup_dir()
    if ext_dir:
        print(f"\n[nogit] Backup externe configuré : {ext_dir}")
        if ext_dir.exists():
            print(f"        Dossier accessible.")
        else:
            print(f"        Avertissement : dossier introuvable (disque déconnecté ?)")
        print()
        if not _is_interactive():
            return
        answer = input("  Changer le chemin ? [o/N] : ").strip().lower()
        if answer not in ("o", "oui", "y", "yes"):
            return
    else:
        print("\n[nogit] Aucun backup externe configuré.")
        print()

    if not _is_interactive():
        return
    new_path = input("  Chemin du dossier de backup externe : ").strip().strip('"')
    if not new_path:
        print("[nogit] Annulé.")
        return

    dest = Path(new_path)
    if not dest.exists():
        if not _is_interactive():
            print("[nogit] Dossier introuvable.")
            return
        answer = input(f"  Ce dossier n'existe pas. Le créer ? [o/N] : ").strip().lower()
        if answer not in ("o", "oui", "y", "yes"):
            print("[nogit] Annulé.")
            return
        dest.mkdir(parents=True, exist_ok=True)

    set_external_backup_dir(dest)
    print(f"[nogit] ✓ Backup externe configuré → {dest}")


def _run_local():
    project_path = Path.cwd()
    mode, _ = get_project_mode(project_path)
    label = "[auto]" if mode == "auto" else "[manuel]"
    print(f"\n  {project_path}  {label}")
    _show_snapshots_and_diff(project_path)


def _run_global():
    registry = load_registry()

    if not registry:
        print("[nogit] Aucun projet enregistré.")
        return

    projects = [k for k in registry.keys() if not k.startswith("_")]
    orphans = []
    valid_projects = []
    print()
    for i, project in enumerate(projects, 1):
        path = Path(project)
        nogit_dir = path / ".nogit"

        if not nogit_dir.exists():
            print(f"  {i:>3}. {project}")
            print(f"         [supprimé] le dossier .nogit n'existe plus — cette entrée sera retirée au prochain lancement")
            orphans.append(project)
            continue

        valid_projects.append(project)
        entry = registry[project]
        if isinstance(entry, dict):
            snapshots_paths = [Path(p) for p in entry.get("snapshots", [])]
            count = len(snapshots_paths)
        else:
            snapshots_paths = _list_snapshots(path)
            count = len(snapshots_paths)
        mode, _ = get_project_mode(path)
        mode_label = "[auto]" if mode == "auto" else "[manuel]"
        label = f"{count} snapshot{'s' if count != 1 else ''}"
        print(f"  {i:>3}. {project}  ({label})  {mode_label}")
        for snap in snapshots_paths[:3]:
            date_str = _format_date(Path(snap).stem)
            print(f"         {date_str}")
        if len(snapshots_paths) > 3:
            print(f"         ... {len(snapshots_paths) - 3} snapshot(s) supplémentaire(s)")

    if orphans:
        for project in orphans:
            del registry[project]
        save_registry(registry)
        projects = valid_projects

    print()
    if not _is_interactive():
        return
    choice = input("  > numéro du projet (ou Entrée pour annuler) : ").strip()
    if not choice:
        return

    try:
        idx = int(choice) - 1
        if not (0 <= idx < len(projects)):
            print("  Numéro invalide.")
            return
        _show_snapshots_and_diff(Path(projects[idx]))
    except ValueError:
        print("  Numéro invalide.")
