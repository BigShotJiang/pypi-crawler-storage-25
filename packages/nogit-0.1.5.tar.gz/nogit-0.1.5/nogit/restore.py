"""nogit restore — reconstruit l'état du projet à partir d'un snapshot."""

import hashlib
import json
import zipfile
from pathlib import Path

from nogit.snapshot import NOGIT_META
from nogit.utils import set_restoring, get_snap_type


def _find_chain(snap_path: Path) -> list[Path]:
    snap_dir = snap_path.parent
    all_snaps = sorted(snap_dir.glob("*.zip"))
    idx = all_snaps.index(snap_path)
    chain = []
    for snap in reversed(all_snaps[: idx + 1]):
        chain.insert(0, snap)
        if get_snap_type(snap) == "full":
            break
    return chain


def _md5_file(path: Path) -> str:
    h = hashlib.md5()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def _check_binaries(chain: list[Path], project_root: Path):
    """Compare les MD5 des binaires du snapshot avec les fichiers actuels sur le disque."""
    seen = {}
    for zip_path in chain:
        with zipfile.ZipFile(zip_path, "r") as zf:
            for name in zf.namelist():
                if name == NOGIT_META or not name.endswith(".meta.json"):
                    continue
                meta = json.loads(zf.read(name))
                original = name[: -len(".meta.json")]
                seen[original] = meta

    warnings = []
    for rel_path, meta in seen.items():
        file_path = project_root / rel_path
        expected_md5 = meta.get("md5")
        if not expected_md5:
            continue
        if not file_path.exists():
            warnings.append(f"  ~ {rel_path}  (fichier introuvable)")
        else:
            actual_md5 = _md5_file(file_path)
            if actual_md5 != expected_md5:
                warnings.append(f"  ~ {rel_path}  (MD5 différent — fichier modifié)")

    if warnings:
        print(f"\n[nogit] Avertissement — {len(warnings)} fichier(s) binaire(s) non restauré(s) et modifié(s) :")
        for w in warnings:
            print(w)


def _extract_zip(zip_path: Path, dest: Path):
    with zipfile.ZipFile(zip_path, "r") as zf:
        for name in zf.namelist():
            if name == NOGIT_META or name.endswith(".meta.json"):
                continue
            target = dest / name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(zf.read(name))


def run(snap_index: int):
    project_root = Path.cwd()
    snap_dir = project_root / ".nogit" / "snapshots"

    snaps = sorted(snap_dir.glob("*.zip"), reverse=True)
    if not snaps:
        print("[nogit] Aucun snapshot trouvé.")
        return

    if not (1 <= snap_index <= len(snaps)):
        print(f"[nogit] Numéro invalide. Choisissez entre 1 et {len(snaps)}.")
        return

    target = snaps[snap_index - 1]
    snap_type = get_snap_type(target)

    print(f"\n[nogit] Snapshot cible : {target.name}  [{snap_type}]")

    if snap_type == "incremental":
        chain = _find_chain(target)
        print(f"[nogit] Chaîne à appliquer ({len(chain)} snapshot(s)) :")
        for s in chain:
            t = get_snap_type(s)
            marker = "[full]" if t == "full" else "[incr]"
            print(f"        {marker} {s.name}")
    else:
        chain = [target]

    print()
    answer = input("  Restaurer dans le dossier courant ? Les fichiers existants seront écrasés. [o/N] : ").strip().lower()
    if answer not in ("o", "oui", "y", "yes"):
        print("[nogit] Annulé.")
        return

    set_restoring(project_root, True)
    try:
        for snap in chain:
            print(f"[nogit] Application de {snap.name}...")
            _extract_zip(snap, project_root)
    finally:
        set_restoring(project_root, False)

    print(f"[nogit] ✓ Restauration terminée.")
    _check_binaries(chain, project_root)
