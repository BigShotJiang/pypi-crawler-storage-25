"""nogit automatic / manual — gère le watcher de snapshots automatiques."""

import os
import sys
import subprocess
from pathlib import Path

from nogit.utils import (
    register_project,
    get_project_mode,
    set_watcher_pid,
    clear_watcher_pid,
)
from nogit.ignore import ensure_nogitignore, load_patterns, is_ignored


def _show_tree(project_path: Path, max_depth: int = 3) -> int:
    """Affiche l'arborescence surveillée. Retourne la profondeur max trouvée."""
    ensure_nogitignore(project_path)
    dir_patterns, file_patterns = load_patterns(project_path)
    max_found = [0]

    def _walk(path: Path, depth: int, prefix: str):
        if depth > max_depth:
            max_found[0] = max(max_found[0], depth)
            return
        try:
            entries = sorted(path.iterdir(), key=lambda p: (p.is_file(), p.name))
        except PermissionError:
            return
        entries = [
            e for e in entries
            if not is_ignored(e, project_path, dir_patterns, file_patterns)
        ]
        for i, entry in enumerate(entries):
            max_found[0] = max(max_found[0], depth)
            connector = "└── " if i == len(entries) - 1 else "├── "
            print(f"  {prefix}{connector}{entry.name}")
            if entry.is_dir():
                extension = "    " if i == len(entries) - 1 else "│   "
                _walk(entry, depth + 1, prefix + extension)

    print(f"\n  {project_path}")
    _walk(project_path, 1, "")
    return max_found[0]


def run_automatic(project_path: Path):
    mode, pid = get_project_mode(project_path)
    if mode == "auto":
        print(f"[nogit] Watcher déjà actif (PID {pid}).")
        return

    if project_path == project_path.parent:
        answer = input(f"  Attention : vous lancez nogit depuis la racine de votre disque ({project_path}). Continuer ? [o/N] : ").strip().lower()
        if answer not in ("o", "oui", "y", "yes"):
            print("[nogit] Annulé.")
            return
        answer2 = input(f"  Vraiment ? Cela va surveiller tout votre disque. Confirmer ? [o/N] : ").strip().lower()
        if answer2 not in ("o", "oui", "y", "yes"):
            print("[nogit] Annulé.")
            return

    print(f"\n[nogit] Arborescence qui sera surveillée :\n")
    depth = _show_tree(project_path)
    print()
    if depth > 3:
        answer = input(f"  Attention : ce dossier a une profondeur de {depth}. Êtes-vous sûr d'être dans le bon dossier ? [o/N] : ").strip().lower()
    else:
        answer = input("  Activer le watcher automatique ? [o/N] : ").strip().lower()
    if answer not in ("o", "oui", "y", "yes"):
        print("[nogit] Annulé.")
        return

    register_project(project_path)

    # Snapshot initial full
    from nogit.snapshot import run_full
    run_full(project_path)

    # Lancer le watcher dans un terminal visible
    cmd = [sys.executable, "-m", "nogit._watcher_entry", str(project_path)]
    if sys.platform == "win32":
        proc = subprocess.Popen(
            ["cmd", "/c", "start", "nogit watcher", sys.executable, "-m", "nogit._watcher_entry", str(project_path)],
            creationflags=subprocess.CREATE_NEW_PROCESS_GROUP,
        )
    else:
        terminals = ["gnome-terminal", "xterm", "konsole"]
        launched = False
        for term in terminals:
            try:
                proc = subprocess.Popen(
                    [term, "--", sys.executable, "-m", "nogit._watcher_entry", str(project_path)],
                    start_new_session=True,
                )
                launched = True
                break
            except FileNotFoundError:
                continue
        if not launched:
            proc = subprocess.Popen(
                cmd,
                start_new_session=True,
                close_fds=True,
            )

    print(f"[nogit] Watcher démarré dans un nouveau terminal.")


def run_manual(project_path: Path):
    mode, pid = get_project_mode(project_path)
    if mode == "manual":
        print("[nogit] Ce projet est déjà en mode manuel.")
        return

    # Tuer le watcher
    try:
        if sys.platform == "win32":
            subprocess.run(["taskkill", "/PID", str(pid), "/F"], capture_output=True)
        else:
            os.kill(pid, 15)  # SIGTERM
    except OSError:
        pass

    clear_watcher_pid(project_path)
    print(f"[nogit] Watcher arrêté. Projet repassé en mode manuel.")
