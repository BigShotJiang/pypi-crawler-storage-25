"""Lecture et application du .nogitignore."""

from pathlib import Path
from nogit.utils import DEFAULT_NOGITIGNORE


def ensure_nogitignore(project_root: Path) -> Path:
    """Crée le .nogitignore avec les défauts s'il n'existe pas encore."""
    nogitignore = project_root / ".nogitignore"
    if not nogitignore.exists():
        nogitignore.write_text(DEFAULT_NOGITIGNORE, encoding="utf-8")
        print("[nogit] .nogitignore créé avec les règles par défaut.")
    return nogitignore


def load_patterns(project_root: Path) -> tuple[list[str], list[str]]:
    """
    Charge les patterns du .nogitignore.
    Retourne (dir_patterns, file_patterns).
    """
    nogitignore = project_root / ".nogitignore"
    if not nogitignore.exists():
        return [], []

    dir_patterns = []
    file_patterns = []

    for line in nogitignore.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if line.endswith("/"):
            dir_patterns.append(line.rstrip("/"))
        else:
            file_patterns.append(line)

    return dir_patterns, file_patterns


def is_ignored(path: Path, project_root: Path, dir_patterns: list[str], file_patterns: list[str]) -> bool:
    """Retourne True si le chemin doit être ignoré."""
    from fnmatch import fnmatch

    relative = path.relative_to(project_root)
    parts = relative.parts

    # Vérifier chaque partie du chemin contre les patterns de dossiers
    for part in parts[:-1]:  # tous sauf le fichier lui-même
        for pattern in dir_patterns:
            if fnmatch(part, pattern):
                return True

    # Vérifier le nom du fichier contre les patterns de fichiers
    filename = parts[-1]
    for pattern in file_patterns:
        if fnmatch(filename, pattern):
            return True

    return False
