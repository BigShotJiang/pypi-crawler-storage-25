"""nogit diff — compare deux snapshots ZIP et ouvre le résultat."""

import difflib
import json
import os
import re
import subprocess
import sys
from pathlib import Path

from nogit.utils import resolve_snapshot_contents, get_snap_type


def _open_file(path: str):
    """Ouvre un fichier dans l'éditeur par défaut (Windows/Linux/macOS)."""
    try:
        if sys.platform == "win32":
            os.startfile(path)
        elif sys.platform == "darwin":
            subprocess.run(["open", path])
        else:
            subprocess.run(["xdg-open", path])
    except (FileNotFoundError, OSError):
        pass



def _parse_hunks(a_lines: list[str], b_lines: list[str]) -> list[dict]:
    """Extrait les hunks depuis un diff unifié sous forme structurée."""
    raw = list(difflib.unified_diff(a_lines, b_lines, lineterm=""))
    hunks = []
    current = None

    for line in raw:
        m = re.match(r"^@@ -(\d+)(?:,\d+)? \+(\d+)(?:,\d+)? @@", line)
        if m:
            if current:
                hunks.append(current)
            current = {
                "start_a": int(m.group(1)),
                "start_b": int(m.group(2)),
                "removed": [],
                "added": [],
            }
        elif current:
            if line.startswith("-"):
                current["removed"].append(line[1:])
            elif line.startswith("+"):
                current["added"].append(line[1:])

    if current:
        hunks.append(current)

    return hunks


def run(snap1: str, snap2: str):
    snap1_path = Path(snap1)
    snap2_path = Path(snap2)

    type_a = get_snap_type(snap1_path)
    type_b = get_snap_type(snap2_path)

    print("[nogit] Diff entre :")
    print(f"        A : {snap1}  [{type_a}]")
    print(f"        B : {snap2}  [{type_b}]")
    if type_a == "incremental" or type_b == "incremental":
        print("        (reconstruction de l'état complet depuis la chaîne...)")
    print()

    a_contents = resolve_snapshot_contents(snap1_path)
    b_contents = resolve_snapshot_contents(snap2_path)

    all_files = sorted(set(a_contents) | set(b_contents))

    output_lines = [
        "nogit diff",
        f"A : {snap1}",
        f"B : {snap2}",
        "=" * 60,
        "",
    ]

    added = deleted = modified = unchanged = meta_changed = 0
    json_files = []

    for filepath in all_files:
        in_a = filepath in a_contents
        in_b = filepath in b_contents

        if not in_a:
            output_lines.append("[AJOUTÉ]   " + filepath)
            json_files.append({"path": filepath, "status": "added"})
            added += 1
            continue

        if not in_b:
            output_lines.append(f"[SUPPRIMÉ] {filepath}")
            json_files.append({"path": filepath, "status": "deleted"})
            deleted += 1
            continue

        a_val = a_contents[filepath]
        b_val = b_contents[filepath]

        # Les deux sont des méta
        if isinstance(a_val, dict) and isinstance(b_val, dict):
            if a_val.get("md5") != b_val.get("md5"):
                output_lines.append(f"[MODIFIÉ]  {filepath}  (binaire/lourd)")
                output_lines.append(f"           taille : {a_val.get('size_bytes')} → {b_val.get('size_bytes')} bytes")
                output_lines.append(f"           md5    : {a_val.get('md5')} → {b_val.get('md5')}")
                json_files.append({
                    "path": filepath,
                    "status": "modified",
                    "type": "binary",
                    "size_a": a_val.get("size_bytes"),
                    "size_b": b_val.get("size_bytes"),
                    "md5_a": a_val.get("md5"),
                    "md5_b": b_val.get("md5"),
                })
                meta_changed += 1
            else:
                unchanged += 1
            continue

        # Les deux sont du texte
        if isinstance(a_val, str) and isinstance(b_val, str):
            if a_val == b_val:
                unchanged += 1
                continue

            a_lines = a_val.splitlines()
            b_lines = b_val.splitlines()
            diff = list(difflib.unified_diff(
                a_lines, b_lines,
                fromfile=f"A/{filepath}",
                tofile=f"B/{filepath}",
                lineterm="",
            ))
            output_lines.append(f"[MODIFIÉ]  {filepath}")
            output_lines.extend(diff)
            output_lines.append("")
            json_files.append({
                "path": filepath,
                "status": "modified",
                "type": "text",
                "hunks": _parse_hunks(a_lines, b_lines),
            })
            modified += 1
            continue

        # Type changé (texte → méta ou inverse)
        output_lines.append(f"[MODIFIÉ]  {filepath}  (type changé)")
        json_files.append({"path": filepath, "status": "modified", "type": "type_changed"})
        modified += 1

    summary = {
        "snap_a": snap1,
        "snap_b": snap2,
        "added": added,
        "deleted": deleted,
        "modified": modified + meta_changed,
        "unchanged": unchanged,
        "files": [{"path": f["path"], "status": f["status"], "type": f.get("type")} for f in json_files],
    }

    output_lines += [
        "",
        "=" * 60,
        f"Résumé : {added} ajouté(s), {deleted} supprimé(s), {modified + meta_changed} modifié(s), {unchanged} inchangé(s)",
    ]

    output = "\n".join(output_lines)

    # Dossier de diff nommé d'après les deux snapshots
    diff_dir = Path.cwd() / ".nogit" / "diff"
    snap_a_stem = Path(snap1).stem
    snap_b_stem = Path(snap2).stem
    base_name = f"{snap_a_stem}_vs_{snap_b_stem}"
    out_dir = diff_dir / base_name
    out_dir.mkdir(parents=True, exist_ok=True)

    # .diff.txt global
    txt_path = out_dir / "diff.txt"
    txt_path.write_text(output, encoding="utf-8")

    # summary.json — index lisible par une IA
    (out_dir / "summary.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8"
    )

    # Un .diff.json par fichier modifié
    for entry in json_files:
        if entry["status"] == "unchanged":
            continue
        safe_name = entry["path"].replace("/", "_").replace("\\", "_")
        file_json_path = out_dir / f"{safe_name}.diff.json"
        file_json_path.write_text(
            json.dumps(entry, indent=2, ensure_ascii=False), encoding="utf-8"
        )

    print(f"[nogit] Diff écrit → {out_dir}/")
    print(f"        {len(json_files)} fichier(s) — summary.json + un .diff.json par fichier")
    _open_file(str(txt_path))
