"""Point d'entrée du watcher lancé en process détaché."""

import sys
from pathlib import Path

if __name__ == "__main__":
    project_path = Path(sys.argv[1])
    from nogit.watcher import run
    run(project_path)
