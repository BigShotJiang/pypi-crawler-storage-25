"""NoGit CLI — git sans le bloat."""

import sys
import argparse
from pathlib import Path
from nogit import snapshot, backups, diff, automatic, restore


_GPL_NOTICE = (
    "NoGit  Copyright (C) 2026  Mehdi. A\n"
    "This program comes with ABSOLUTELY NO WARRANTY; for details type `nogit show w'.\n"
    "This is free software, and you are welcome to redistribute it\n"
    "under certain conditions; type `nogit show c' for details.\n"
)


class _Parser(argparse.ArgumentParser):
    def print_help(self, file=None):
        print(_GPL_NOTICE)
        super().print_help(file)


def main():
    parser = _Parser(
        prog="nogit",
        description="Git sans le bloat — snapshots ZIP + diff intelligent.",
        formatter_class=lambda prog: argparse.HelpFormatter(prog, max_help_position=60),
    )
    subparsers = parser.add_subparsers(dest="command", metavar="commande")

    # nogit snapshot
    subparsers.add_parser(
        "snapshot",
        help="Crée un snapshot ZIP complet du dossier courant (mode manuel uniquement)."
    )

    # nogit backups
    backups_parser = subparsers.add_parser(
        "backups",
        help="Liste les snapshots du dossier courant. Permet de lancer un diff ou un restore. --global : tous les projets de la machine. --external : configurer un backup secondaire."
    )
    backups_parser.add_argument(
        "--global", dest="global_", action="store_true",
        help="Liste tous les projets NoGit enregistrés sur la machine. Nettoie automatiquement les projets supprimés."
    )
    backups_parser.add_argument(
        "--external", dest="external", action="store_true",
        help="Configure le dossier de backup externe (disque secondaire, NAS...). Les snapshots y sont copiés automatiquement."
    )

    # nogit diff
    diff_parser = subparsers.add_parser(
        "diff",
        help="Compare deux snapshots ZIP. Génère un dossier dans .nogit/diff/ avec diff.txt, summary.json et un .diff.json par fichier modifié."
    )
    diff_parser.add_argument("snap1", help="Premier snapshot ZIP.")
    diff_parser.add_argument("snap2", help="Deuxième snapshot ZIP.")

    # nogit automatic
    subparsers.add_parser(
        "automatic",
        help="Active le watcher : surveille le dossier et crée un snapshot incrémental à chaque modification détectée."
    )

    # nogit manual
    subparsers.add_parser(
        "manual",
        help="Désactive le watcher et repasse en mode snapshot manuel."
    )

    # nogit restore
    restore_parser = subparsers.add_parser(
        "restore",
        help="Restaure le projet depuis un snapshot. Remonte automatiquement la chaîne si le snapshot est incrémental."
    )
    restore_parser.add_argument("index", type=int, help="Numéro du snapshot affiché dans 'nogit backups'.")

    args = parser.parse_args()

    if args.command == "snapshot":
        snapshot.run()
    elif args.command == "backups":
        backups.run(global_=args.global_, external=args.external)
    elif args.command == "diff":
        snap_dir = Path.cwd() / ".nogit" / "snapshots"
        snapshots = sorted(snap_dir.glob("*.zip"), reverse=True) if snap_dir.exists() else []

        def resolve_snap(arg: str) -> str:
            if arg.isdigit():
                idx = int(arg) - 1
                if not (0 <= idx < len(snapshots)):
                    print(f"[nogit] Numéro invalide : {arg}")
                    raise SystemExit(1)
                return str(snapshots[idx])
            return arg

        diff.run(resolve_snap(args.snap1), resolve_snap(args.snap2))
    elif args.command == "automatic":
        automatic.run_automatic(Path.cwd())
    elif args.command == "manual":
        automatic.run_manual(Path.cwd())
    elif args.command == "restore":
        restore.run(args.index)
    else:
        backups.run()


if __name__ == "__main__":
    main()
