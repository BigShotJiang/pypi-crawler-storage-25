# NoGit

Git without the bloat — ZIP snapshots + smart diff.

NoGit watches your working directory and creates ZIP snapshots automatically or manually. No commits, no branches, no rebases. Just timestamped ZIPs and a readable diff.

---

## Installation

```bash
pip install nogit
```

Or with pipx:

```bash
pipx install nogit
```

---

## Commands

### `nogit` or `nogit backups`
Lists snapshots for the current directory. Offers to launch a diff or restore.

### `nogit snapshot`
Creates a full ZIP snapshot of the current directory (manual mode only).

### `nogit automatic`
Enables the watcher — monitors the directory and creates an incremental snapshot on every detected change. Launches a dedicated terminal with live logs. A full snapshot is created on startup.

> The watcher uses `st_mtime` + SHA-256 to detect real changes and avoid false positives (auto-save, restore, etc.).

### `nogit manual`
Disables the watcher and switches back to manual snapshot mode.

### `nogit backups --global`
Lists all NoGit projects registered on the machine. Automatically cleans up projects whose directory has been deleted.

### `nogit backups --external`
Configures an external backup folder (second drive, NAS...). Snapshots are automatically copied there after each creation.

### `nogit diff <snap1> <snap2>`
Compares two ZIP snapshots. If either snapshot is incremental, automatically reconstructs the full state from the chain before comparing.

The oldest snapshot is always used as the reference (A), the most recent as the target (B). So `added` means "appeared over time", `deleted` means "disappeared over time".

Generates a folder in `.nogit/diff/`:

```
.nogit/diff/
  2026-05-23T01_vs_2026-05-23T02/
    diff.txt              — human-readable global report
    summary.json          — index of changed files (for AI)
    my_file.diff.json     — detailed hunks per modified file
```

### `nogit restore <number>`
Restores the project from a snapshot (the number matches the order shown in `nogit backups`). If the snapshot is incremental, automatically walks the chain back to the last full snapshot. Verifies MD5 hashes of binary files and reports divergences.

Restore can also be launched directly from `nogit backups` by choosing `r`.

---

## Directory Structure

```
project/
  .nogit/
    snapshots/                          — timestamped ZIPs (full or incremental)
    diff/
      snap_a_vs_snap_b/                 — one folder per diff run
        diff.txt                        — human-readable report
        summary.json                    — index of changed files
        my_file.py.diff.json            — hunks per modified file
  .nogitignore                          — files/folders excluded from snapshots
```

The `.nogit` folder follows the project — it can be shared or copied as-is.

---

## Snapshots

**Full** — contains all project files (created by `nogit snapshot` or at `nogit automatic` startup).

**Incremental** — contains only files modified since the last snapshot (created by the watcher in automatic mode).

Each ZIP contains a `nogit.meta.json` indicating its type (`full` or `incremental`).

Binary files and files > 10 MB are not included in the ZIP — a `.meta.json` with their size and MD5 is stored instead.

---

## Global Registry

NoGit maintains a global registry of projects at `%USERPROFILE%\.nogit\registry.json` (or `~/.nogit/registry.json` on Linux/macOS). This file is automatically synced to the external backup if configured.

---

## External Backup

When an external folder is configured via `nogit backups --external`, the following structure is created:

```
external_folder/
  .nogitbackups/
    configs/
      registry.json       — copy of the global registry
    ProjectName_abc123/
      snapshots/          — copies of the ZIPs
```

---

## License

This project is distributed under the [GNU GPL v3](LICENSE) license. See the `LICENSE` file for details.

---

## Credits

MIME types dataset based on [micnic/mime.json](https://github.com/micnic/mime.json) by Nicu Micleușanu, modified to include missing programming language extensions.
