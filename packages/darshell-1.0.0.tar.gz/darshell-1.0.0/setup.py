from setuptools import setup, find_packages

setup(
    name="darshell",
    version="1.0.0",
    author="Darshan",
    description="Android MAD Lab Code Generator",
    packages=find_packages(),
    include_package_data=True,

    package_data={
        "darshell": ["templates/**/*"],
    },

    entry_points={
        "console_scripts": [
            "darshell=darshell.cli:main"
        ]
    },
)