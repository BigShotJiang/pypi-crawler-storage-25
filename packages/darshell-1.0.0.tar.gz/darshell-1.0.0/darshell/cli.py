from darshell.generator import create_project

topics = {
    1: "progressbar",
    2: "animations",
    3: "autocomplete_textview",
    4: "canvas",
    5: "checkbox",
    6: "custom_checkbox",
    7: "custom_toast",
    8: "database",
    9: "datepicker_and_timepicker",
    10: "explicit_and_implicit_intents",
    11: "image_view_listener",
    12: "menu",
    13: "radio_button",
    14: "sharedpreferences",
    15: "spinner",
    16: "toggle_button",
    17: "alertdialog",
    18: "fragments"
}

def main():

    print("\n=== DARSH Android Generator ===\n")

    for key, value in topics.items():
        print(f"{key}. {value}")

    try:
        choice = int(input("\nEnter your choice: "))

        if choice in topics:
            create_project(topics[choice])

        else:
            print("Invalid choice")

    except Exception as e:
        print("Error:", e)