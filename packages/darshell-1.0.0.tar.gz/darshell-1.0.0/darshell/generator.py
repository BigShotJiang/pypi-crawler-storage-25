import os
import shutil

BASE_DIR = os.path.dirname(__file__)

def create_project(topic):
    template_path = os.path.join(BASE_DIR, "templates", topic)
    target_path = os.path.join(os.getcwd(), topic)

    if not os.path.exists(template_path):
        print("❌ Template not found!")
        return

    if os.path.exists(target_path):
        print("⚠️ Folder already exists!")
        return

    shutil.copytree(template_path, target_path)

    print(f"\n✅ {topic} project created successfully!")