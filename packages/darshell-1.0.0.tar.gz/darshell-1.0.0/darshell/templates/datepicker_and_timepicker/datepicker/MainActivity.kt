package com.example.datepicker1

import android.os.Build
import android.os.Bundle
import android.widget.DatePicker
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import java.util.*

class MainActivity : AppCompatActivity() {

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val datePicker =
            findViewById<DatePicker>(R.id.datePicker)

        datePicker.setOnDateChangedListener {
                datePicker, year, month, day ->

            val monthValue = month + 1

            Toast.makeText(
                applicationContext,
                "Date Is: $day/$monthValue/$year",
                Toast.LENGTH_SHORT
            ).show()
        }
    }
}