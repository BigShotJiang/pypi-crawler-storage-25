package com.example.timepicker1

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.TimePicker
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val timePicker =
            findViewById<TimePicker>(R.id.timePicker)

        timePicker.setOnTimeChangedListener { _, hour, minute ->

            val am_pm = ""

            val hourValue =
                if (hour < 10) "0$hour" else hour

            val min =
                if (minute < 10) "0$minute" else minute

            val msg = "Time is: $hourValue : $min $am_pm"

            Toast.makeText(
                this@MainActivity,
                msg,
                Toast.LENGTH_SHORT
            ).show()
        }
    }
}