package com.example.explicitandimplicitintentsbypassingdata

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class MainActivity2 : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        // get data from intent
        val intent = intent
        val name = intent.getStringExtra("Name")
        val email = intent.getStringExtra("Email")
        val phone = intent.getStringExtra("Phone")

        // display data
        val resultTv = findViewById<TextView>(R.id.resultTv)
        resultTv.text = "Name: $name\nEmail: $email\nPhone: $phone"
    }
}