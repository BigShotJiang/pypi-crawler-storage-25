package com.example.customcheckbox

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btn = findViewById<Button>(R.id.button1)

        btn.setOnClickListener {
            val ckb3 = findViewById<CheckBox>(R.id.checkBox3)
            val ckb4 = findViewById<CheckBox>(R.id.checkBox4)

            val sb = StringBuilder()

            if (ckb3.isChecked)
                sb.append(" ${ckb3.text}")

            if (ckb4.isChecked)
                sb.append(" ${ckb4.text}")

            Toast.makeText(this, sb.toString(), Toast.LENGTH_LONG).show()
        }
    }
}