package com.example.sharedpeferences1

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText

class MainActivity : AppCompatActivity() {

    private lateinit var name: EditText
    private lateinit var age: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        name = findViewById(R.id.edit1)
        age = findViewById(R.id.edit2)
    }

    // Fetch stored data when app resumes
    override fun onResume() {
        super.onResume()

        val sh = getSharedPreferences("MySharedPref", MODE_PRIVATE)

        val s1 = sh.getString("name", "")
        val a = sh.getInt("age", 0)

        name.setText(s1)
        age.setText(a.toString())
    }

    // Store data when app pauses
    override fun onPause() {
        super.onPause()

        val sharedPreferences = getSharedPreferences("MySharedPref", MODE_PRIVATE)
        val myEdit = sharedPreferences.edit()

        myEdit.putString("name", name.text.toString())
        myEdit.putInt("age", age.text.toString().toInt())

        myEdit.apply()
    }
}