//using Paint



val pCircle = Paint()
pCircle.setColor(Color.BLACK)
canvas.drawCircle(30f, 30f, 30f, pCircle)



val pBackground = Paint()
pBackground.color = Color.RED
canvas.drawRect(450f, 450f, 500f, 500f, pBackground)