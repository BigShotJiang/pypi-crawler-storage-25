import os
import subprocess
from setuptools import setup
from setuptools.command.build_py import build_py
from setuptools.dist import Distribution
from wheel.bdist_wheel import bdist_wheel


def is_elf(filepath):
    try:
        with open(filepath, "rb") as f:
            return f.read(4) == b"\x7fELF"
    except IOError:
        return False


def strip_symbols(filepath):
    subprocess.run(["strip", "--strip-unneeded", filepath], check=True)


class BinaryDistribution(Distribution):
    """Force a platform tag (linux_x86_64) without binding to a Python ABI."""
    def has_ext_modules(self):
        return True


class PyAgnosticWheel(bdist_wheel):
    """Tag the wheel py3-none-<plat>: no specific Python ABI is required
    because libmufem.so contains no Python symbols."""
    def get_tag(self):
        _, _, plat = super().get_tag()
        return ("py3", "none", plat)


class CustomBuildPy(build_py):
    def run(self):
        super().run()

        lib_dir = os.path.join(self.build_lib, "libmufem", "lib")
        # Third-party libs sit next to libmufem.so under libmufem/lib/.
        # rpath = $ORIGIN points back at the same directory so they can
        # resolve each other (e.g. libhypre needs libmpi).
        if os.path.exists(lib_dir):
            for f in os.listdir(lib_dir):
                fp = os.path.join(lib_dir, f)
                if not os.path.isfile(fp):
                    continue
                if f.endswith(".a"):
                    os.remove(fp)
                elif f.endswith(".so") or ".so." in f:
                    subprocess.run(
                        ["patchelf", "--set-rpath", "$ORIGIN", fp], check=True
                    )
                    strip_symbols(fp)

        # libmufem.so is one level up; it needs to find third-party libs in
        # the lib/ subdir at runtime.
        engine = os.path.join(self.build_lib, "libmufem", "libmufem.so")
        if os.path.exists(engine):
            subprocess.run(
                ["patchelf", "--set-rpath", "$ORIGIN/lib", engine], check=True
            )
            strip_symbols(engine)

        # Open MPI launchers (mpiexec, mpirun, ompi_info, …) live in bin/ and
        # depend on libmpi etc. — set rpath so they find them in ../lib/.
        bin_dir = os.path.join(self.build_lib, "libmufem", "bin")
        if os.path.exists(bin_dir):
            for exe in os.listdir(bin_dir):
                exe_path = os.path.join(bin_dir, exe)
                if os.path.isfile(exe_path) and is_elf(exe_path):
                    subprocess.run(
                        ["patchelf", "--set-rpath", "$ORIGIN/../lib", exe_path],
                        check=True,
                    )
                    strip_symbols(exe_path)


version = os.getenv("GIT_TAG", "0.0.0")

with open("libmufem-description.md", "r", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="libmufem",
    version=version,
    description="Native engine library for mufem — interpreter-independent.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="Raiden Numerics LLC",
    author_email="mufem@raiden-numerics.com",
    license="Proprietary",
    url="https://www.raiden-numerics.com/mufem/",
    project_urls={
        "Documentation": "https://www.raiden-numerics.com/mufem/",
        "Examples": "https://github.com/Raiden-Numerics/mufem-examples",
        "Source": "https://github.com/Raiden-Numerics/mufem",
    },
    keywords=[
        "finite element",
        "mfem",
        "fem",
        "multiphysics",
        "electromagnetics",
        "thermal",
        "cfd",
    ],
    python_requires=">=3.12",
    packages=["libmufem"],
    package_data={
        "libmufem": [
            "__init__.py",
            "libmufem.so",
            "lib/**/*",
            # bin/ holds mpiexec / mpirun (Open MPI launchers); pymufem
            # invokes them at runtime, so they must ship with the engine.
            "bin/**/*",
            "share/**/*",
        ],
    },
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Science/Research",
        "License :: Other/Proprietary License",
        "Operating System :: POSIX :: Linux",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3 :: Only",
        "Programming Language :: Python :: 3.12",
        "Programming Language :: Python :: 3.13",
        "Programming Language :: Python :: 3.14",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
    distclass=BinaryDistribution,
    cmdclass={
        "build_py": CustomBuildPy,
        "bdist_wheel": PyAgnosticWheel,
    },
)
