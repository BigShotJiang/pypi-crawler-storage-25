import os
from pathlib import Path

import pytest
from helpers import RattlerBuild, get_extracted_package


@pytest.mark.skipif(
    os.name == "nt", reason="recipe does not support execution on windows"
)
def test_perl_tests(
    rattler_build: RattlerBuild, recipes: Path, tmp_path: Path, snapshot
):
    rattler_build.build(recipes / "perl-test", tmp_path)
    pkg = get_extracted_package(tmp_path, "perl-call-context")

    assert (pkg / "info" / "tests" / "tests.yaml").exists()
    content = (pkg / "info" / "tests" / "tests.yaml").read_text()

    assert snapshot == content


def test_source_files_copied_to_test(
    rattler_build: RattlerBuild, recipes: Path, tmp_path: Path
):
    """Test that files.source: ['./'] copies all source files to the test directory (issue #2085)."""
    rattler_build.build(recipes / "test-source-files", tmp_path)
    pkg = get_extracted_package(tmp_path, "test-source-files")

    # Verify the test files were packaged
    assert (
        pkg / "etc" / "conda" / "test-files" / "test-source-files" / "0" / "data.txt"
    ).exists()


@pytest.mark.skipif(os.name == "nt", reason="recipe uses build.sh (unix only)")
def test_conditional_script_empty(
    rattler_build: RattlerBuild, recipes: Path, tmp_path: Path, snapshot
):
    """Test that a conditional test script evaluating to empty does not fall back to build.sh."""
    rattler_build.build(
        recipes / "test-conditional-script-empty",
        tmp_path,
        extra_args=["--test=skip"],
    )
    pkg = get_extracted_package(tmp_path, "test-conditional-script-empty")

    assert (pkg / "info" / "tests" / "tests.yaml").exists()
    content = (pkg / "info" / "tests" / "tests.yaml").read_text()

    # The test script must not contain the build script content
    assert "Hello" not in content
    assert snapshot == content


def test_env_vars_in_test_scripts(
    rattler_build: RattlerBuild, recipes: Path, tmp_path: Path
):
    """Test that variant env vars, platform vars, and CONDA_BUILD are set in test scripts (issue #1317)."""
    rattler_build.build(recipes / "test-env-vars-in-tests", tmp_path)


@pytest.mark.skipif(
    os.name != "nt", reason="recipe does not support execution on windows"
)
def test_win_errorlevel_injection(
    rattler_build: RattlerBuild, recipes: Path, tmp_path: Path, snapshot
):
    rattler_build.build(
        recipes / "test-errorlevel-injection", tmp_path, extra_args=["--test=skip"]
    )
    pkg = get_extracted_package(tmp_path, "test-errorlevel-injection")

    assert (pkg / "info" / "tests" / "tests.yaml").exists()
    content = (pkg / "info" / "tests" / "tests.yaml").read_text()

    assert snapshot == content


@pytest.mark.skipif(os.name == "nt", reason="recipe uses unix commands")
def test_noarch_variant_test_skip(
    rattler_build: RattlerBuild, recipes: Path, tmp_path: Path
):
    """Test that noarch packages with platform-conditional tests don't fail.

    When a noarch package has variants (e.g., build_win: [true, false]) that add
    platform-specific virtual package dependencies (__win / __unix), the test for
    the variant whose virtual package is unavailable on the build platform must
    not attempt to create a test environment.

    Regression test for https://github.com/prefix-dev/rattler-build/issues/2388
    """
    rattler_build.build(recipes / "noarch-test-skip", tmp_path)
