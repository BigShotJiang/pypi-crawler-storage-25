echo "Hello from Nushell!"
