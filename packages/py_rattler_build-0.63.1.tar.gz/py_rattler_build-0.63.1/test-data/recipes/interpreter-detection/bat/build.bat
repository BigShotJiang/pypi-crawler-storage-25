@echo Hello from Cmd!
