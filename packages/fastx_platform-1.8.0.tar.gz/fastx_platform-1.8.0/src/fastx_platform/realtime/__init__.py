"""Taxonomy section package (see :mod:`fastx_platform.taxonomy`)."""

from .abstraction import IRealtime

__all__ = ["IRealtime"]
