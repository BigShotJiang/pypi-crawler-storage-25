"""Abstractions for high-frequency market data and generic event streams."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, AsyncGenerator, Dict

from .abstraction import IStreams

if TYPE_CHECKING:
    from .market import MarketDataHub


@dataclass
class Tick:
    """Represents the Tick class."""

    symbol: str
    price: float
    size: float
    side: str  # "bid" / "ask" / "trade"
    ts: float


@dataclass
class OrderEvent:
    """Represents the OrderEvent class."""

    tenant_id: str
    order_id: str
    symbol: str
    side: str  # "buy" / "sell"
    status: str  # "new" / "filled" / "canceled" / ...
    ts: float
    data: Dict[str, Any]


class IMarketDataFeed(IStreams, ABC):
    """Interface for external market data providers (Kafka, Redis streams, FIX, etc.)."""

    @abstractmethod
    async def run(self, hub: MarketDataHub) -> None:  # pragma: no cover - interface
        """Connect to an external feed and push ticks into the hub."""


class IEventStream(IStreams, ABC):
    """Generic high-frequency event stream abstraction."""

    @abstractmethod
    async def publish(self, event: Any) -> None:  # pragma: no cover - interface
        """Execute publish operation.

        Args:
            event: The event parameter.

        Returns:
            The result of the operation.
        """
        raise NotImplementedError

    @abstractmethod
    async def subscribe(self) -> AsyncGenerator[Any, None]:  # pragma: no cover - interface
        """Execute subscribe operation.

        Returns:
            The result of the operation.
        """
        raise NotImplementedError


__all__ = [
    "Tick",
    "OrderEvent",
    "IMarketDataFeed",
    "IEventStream",
]
