"""Taxonomy section package (see :mod:`fastx_platform.taxonomy`).

Application utilities (auth, audit, tracing, encryption, database helpers, webhooks,
registry, metrics, health, etc.) live in sibling modules under this package, for example
:mod:`fastx_platform.core.auth` and :mod:`fastx_platform.core.tracing`. The
``fast_dashboards.core`` namespace re-exports them for backward compatibility; new code
should import from ``fastx_platform.core`` (or the specific submodule).
"""

from .abstraction import ICore

__all__ = ["ICore"]
