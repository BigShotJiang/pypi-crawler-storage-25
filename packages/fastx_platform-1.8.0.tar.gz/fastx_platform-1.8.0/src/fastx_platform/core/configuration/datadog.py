"""Singleton accessor for Datadog configuration."""

from __future__ import annotations

from ..constants import SERVICE_NAME
from typing import Optional, Type

from ..dtos import DatadogConfigurationDTO

from .abstraction import ConfigurationSingletonBase


class DatadogConfiguration(ConfigurationSingletonBase[DatadogConfigurationDTO]):
    """Represents the DatadogConfiguration class."""

    _instance: Optional["DatadogConfiguration"] = None
    _section: str = "datadog"
    _env_key: str = "DATADOG"
    _dto: Type[DatadogConfigurationDTO] = DatadogConfigurationDTO
