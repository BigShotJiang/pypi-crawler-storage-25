from __future__ import annotations

"""Request Profiler middleware for development and debugging.

Provides per-request profiling of SQL queries, cache operations, timing,
memory usage, and N+1 detection. Includes an HTML dashboard and JSON API
for inspecting recent requests.

Quick start::

    from fastx_platform.core.profiler import ProfilerMiddleware, profiler_router

    app.add_middleware(ProfilerMiddleware)
    app.mount("/__profile__", profiler_router)

    # Optional: hook into SQLAlchemy for automatic query tracking
    from fastx_platform.core.profiler import install_sqlalchemy_hooks
    install_sqlalchemy_hooks(engine)
"""

from .report import ProfileReport, QueryInfo
from .tracker import RequestProfiler, install_sqlalchemy_hooks
from .middleware import ProfilerMiddleware
from .endpoint import profiler_router

__all__ = [
    "ProfileReport",
    "QueryInfo",
    "RequestProfiler",
    "ProfilerMiddleware",
    "profiler_router",
    "install_sqlalchemy_hooks",
]
