from __future__ import annotations

"""Profile viewer endpoints for inspecting recent profiled requests.

Mount the ``profiler_router`` as a sub-application under ``/__profile__``.
Provides both a human-readable HTML dashboard and a JSON API.
"""

import html
from typing import Any, Dict, List, Optional, TYPE_CHECKING

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse

if TYPE_CHECKING:
    from .middleware import ProfilerMiddleware

profiler_router = APIRouter()


def _get_middleware(request: Request) -> ProfilerMiddleware:
    """Retrieve the ProfilerMiddleware instance from app state."""
    middleware: Optional[ProfilerMiddleware] = getattr(
        request.app.state, "_profiler_middleware", None
    )
    if middleware is None:
        raise HTTPException(
            status_code=503,
            detail="ProfilerMiddleware is not attached to the application.",
        )
    return middleware


# ------------------------------------------------------------------
# JSON API
# ------------------------------------------------------------------


@profiler_router.get("/api", response_class=JSONResponse)
async def list_reports(request: Request) -> JSONResponse:
    """Return all recent profile reports as JSON."""
    middleware = _get_middleware(request)
    reports = [r.to_dict() for r in reversed(middleware.reports)]
    return JSONResponse(content=reports)


@profiler_router.get("/api/{request_id}", response_class=JSONResponse)
async def get_report(request: Request, request_id: str) -> JSONResponse:
    """Return a single profile report by request_id."""
    middleware = _get_middleware(request)
    report = middleware.get_report(request_id)
    if report is None:
        raise HTTPException(status_code=404, detail="Report not found")
    return JSONResponse(content=report.to_dict())


# ------------------------------------------------------------------
# HTML dashboard
# ------------------------------------------------------------------

_DASHBOARD_HTML = """\
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Request Profiler</title>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
         background: #f5f5f5; color: #333; padding: 24px; }
  h1 { margin-bottom: 16px; font-size: 1.5rem; }
  .meta { color: #888; font-size: 0.85rem; margin-bottom: 16px; }
  table { width: 100%%; border-collapse: collapse; background: #fff;
          box-shadow: 0 1px 3px rgba(0,0,0,0.1); border-radius: 6px; overflow: hidden; }
  th, td { text-align: left; padding: 10px 14px; font-size: 0.9rem; }
  th { background: #fafafa; font-weight: 600; border-bottom: 2px solid #eee; }
  tr:not(:last-child) td { border-bottom: 1px solid #f0f0f0; }
  tr:hover td { background: #fafafa; }
  .warn { color: #e67e22; font-weight: 600; }
  .ok { color: #27ae60; }
  .slow { color: #e74c3c; font-weight: 600; }
  a { color: #2980b9; text-decoration: none; }
  a:hover { text-decoration: underline; }
  .badge { display: inline-block; padding: 2px 8px; border-radius: 10px;
           font-size: 0.75rem; font-weight: 600; }
  .badge-warn { background: #fef3e2; color: #e67e22; }
  .badge-ok { background: #eafaf1; color: #27ae60; }
  .empty { text-align: center; padding: 40px; color: #aaa; }
</style>
</head>
<body>
<h1>Request Profiler</h1>
<p class="meta">Showing last %(count)d profiled requests.
   <a href="/__profile__/api">JSON API</a></p>
%(table)s
</body>
</html>
"""


def _render_table(reports: List[Dict[str, Any]]) -> str:
    """Render the reports as an HTML table."""
    if not reports:
        return '<div class="empty">No profiled requests yet.</div>'

    rows: list[str] = []
    for r in reports:
        n1_count = len(r.get("n_plus_one_warnings") or [])
        slow_count = len(r.get("slow_queries") or [])
        time_ms = r["total_time_ms"]

        time_cls = "slow" if time_ms > 500 else ("warn" if time_ms > 200 else "ok")
        n1_badge = (
            f'<span class="badge badge-warn">{n1_count} N+1</span>'
            if n1_count
            else '<span class="badge badge-ok">0</span>'
        )
        slow_badge = (
            f'<span class="badge badge-warn">{slow_count}</span>'
            if slow_count
            else '<span class="badge badge-ok">0</span>'
        )

        rid = html.escape(r["request_id"])
        path = html.escape(r["path"])
        method = html.escape(r["method"])
        ts = html.escape(r.get("timestamp", ""))

        rows.append(
            f"<tr>"
            f'<td><a href="/__profile__/api/{rid}">{rid}</a></td>'
            f"<td>{method}</td>"
            f"<td>{path}</td>"
            f"<td>{r.get('status_code', '')}</td>"
            f'<td class="{time_cls}">{time_ms:.1f} ms</td>'
            f"<td>{r['db_query_count']}</td>"
            f"<td>{r['db_total_time_ms']:.1f} ms</td>"
            f"<td>{n1_badge}</td>"
            f"<td>{slow_badge}</td>"
            f"<td>{r.get('cache_hits', 0)}/{r.get('cache_misses', 0)}</td>"
            f"<td>{r.get('memory_delta_kb', 0):.1f} KB</td>"
            f"<td>{ts}</td>"
            f"</tr>"
        )

    header = (
        "<thead><tr>"
        "<th>ID</th><th>Method</th><th>Path</th><th>Status</th>"
        "<th>Time</th><th>Queries</th><th>DB Time</th>"
        "<th>N+1</th><th>Slow</th><th>Cache H/M</th>"
        "<th>Mem Delta</th><th>Timestamp</th>"
        "</tr></thead>"
    )
    return f"<table>{header}<tbody>{''.join(rows)}</tbody></table>"


@profiler_router.get("/", response_class=HTMLResponse)
async def dashboard(request: Request) -> HTMLResponse:
    """Render the HTML profiler dashboard."""
    middleware = _get_middleware(request)
    reports = [r.to_dict() for r in reversed(middleware.reports)]
    table_html = _render_table(reports)
    page = _DASHBOARD_HTML % {"count": len(reports), "table": table_html}
    return HTMLResponse(content=page)


__all__ = [
    "profiler_router",
]
