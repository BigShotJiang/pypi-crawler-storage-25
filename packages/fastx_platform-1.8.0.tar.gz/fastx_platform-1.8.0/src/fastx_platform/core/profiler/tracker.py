from __future__ import annotations

"""Request profiler that tracks SQL queries, cache operations, and timing.

Wraps SQLAlchemy engine events to capture query execution details,
detects N+1 patterns, and identifies slow queries.
"""

import re
import time
import tracemalloc
import uuid
from collections import defaultdict
from contextvars import ContextVar
from typing import Any, Dict, List, Optional, Tuple

from loguru import logger

from .report import ProfileReport, QueryInfo

# Context variable so the profiler is accessible from SQLAlchemy event handlers
_active_profiler: ContextVar[Optional[RequestProfiler]] = ContextVar(
    "active_profiler", default=None
)


def _normalize_sql(sql: str) -> str:
    """Normalize SQL by replacing literal values with placeholders.

    Used to group similar queries for N+1 detection.
    """
    # Replace quoted strings
    normalized = re.sub(r"'[^']*'", "'?'", sql)
    # Replace numeric literals
    normalized = re.sub(r"\b\d+\b", "?", normalized)
    # Collapse IN (...) lists
    normalized = re.sub(r"IN\s*\([^)]+\)", "IN (?)", normalized, flags=re.IGNORECASE)
    return normalized.strip()


class RequestProfiler:
    """Context manager that profiles a single request lifecycle.

    Tracks:
    - Total wall-clock time
    - All SQL queries with individual durations
    - Cache hit/miss counts
    - N+1 query pattern detection
    - Slow query identification
    - Memory allocation delta

    Usage::

        async with RequestProfiler(method="GET", path="/users") as profiler:
            # ... handle request ...
            profiler.record_cache_hit()
        report = profiler.report
    """

    def __init__(
        self,
        method: str = "GET",
        path: str = "/",
        request_id: Optional[str] = None,
        slow_query_threshold_ms: float = 100.0,
        n_plus_one_threshold: int = 3,
    ) -> None:
        self.method = method
        self.path = path
        self.request_id = request_id or uuid.uuid4().hex[:16]
        self.slow_query_threshold_ms = slow_query_threshold_ms
        self.n_plus_one_threshold = n_plus_one_threshold

        # Internal tracking state
        self._queries: List[QueryInfo] = []
        self._pending_queries: Dict[int, Tuple[float, str, int]] = {}
        self._cache_hits: int = 0
        self._cache_misses: int = 0

        self._start_time: float = 0.0
        self._end_time: float = 0.0
        self._mem_snapshot_start: Optional[tracemalloc.Snapshot] = None
        self._mem_start_kb: float = 0.0
        self._report: Optional[ProfileReport] = None

    # ------------------------------------------------------------------
    # Context manager interface
    # ------------------------------------------------------------------

    async def __aenter__(self) -> RequestProfiler:
        self._start()
        return self

    async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        self._stop()

    def __enter__(self) -> RequestProfiler:
        self._start()
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        self._stop()

    def _start(self) -> None:
        """Begin profiling."""
        _active_profiler.set(self)
        self._start_time = time.perf_counter()

        # Memory tracking – best-effort, tracemalloc may already be running
        if not tracemalloc.is_tracing():
            try:
                tracemalloc.start()
            except RuntimeError:
                pass
        current, _ = tracemalloc.get_traced_memory()
        self._mem_start_kb = current / 1024.0

    def _stop(self) -> None:
        """Finish profiling and build the report."""
        self._end_time = time.perf_counter()
        _active_profiler.set(None)

        # Memory delta
        current, _ = tracemalloc.get_traced_memory()
        mem_end_kb = current / 1024.0
        memory_delta_kb = mem_end_kb - self._mem_start_kb

        total_time_ms = (self._end_time - self._start_time) * 1000.0

        # Identify slow queries
        slow_queries = [
            q for q in self._queries if q.duration_ms > self.slow_query_threshold_ms
        ]

        # Detect N+1 patterns
        n_plus_one_warnings = self._detect_n_plus_one()

        db_total_time_ms = sum(q.duration_ms for q in self._queries)

        self._report = ProfileReport(
            request_id=self.request_id,
            method=self.method,
            path=self.path,
            total_time_ms=total_time_ms,
            db_queries=list(self._queries),
            db_query_count=len(self._queries),
            db_total_time_ms=db_total_time_ms,
            cache_hits=self._cache_hits,
            cache_misses=self._cache_misses,
            n_plus_one_warnings=n_plus_one_warnings,
            slow_queries=slow_queries,
            memory_delta_kb=memory_delta_kb,
        )

    # ------------------------------------------------------------------
    # Public API for recording events
    # ------------------------------------------------------------------

    def record_query_start(self, conn_id: int, sql: str, params_count: int) -> None:
        """Record the start of a SQL query execution."""
        self._pending_queries[conn_id] = (time.perf_counter(), sql, params_count)

    def record_query_end(self, conn_id: int) -> None:
        """Record the completion of a SQL query execution."""
        pending = self._pending_queries.pop(conn_id, None)
        if pending is None:
            return
        start_ts, sql, params_count = pending
        duration_ms = (time.perf_counter() - start_ts) * 1000.0
        qi = QueryInfo(
            sql=sql,
            duration_ms=duration_ms,
            params_count=params_count,
            timestamp=start_ts,
        )
        self._queries.append(qi)

    def record_cache_hit(self) -> None:
        """Record a cache hit."""
        self._cache_hits += 1

    def record_cache_miss(self) -> None:
        """Record a cache miss."""
        self._cache_misses += 1

    # ------------------------------------------------------------------
    # N+1 detection
    # ------------------------------------------------------------------

    def _detect_n_plus_one(self) -> List[str]:
        """Detect N+1 patterns by grouping queries by their normalized SQL."""
        pattern_counts: Dict[str, int] = defaultdict(int)
        pattern_samples: Dict[str, str] = {}

        for q in self._queries:
            key = _normalize_sql(q.sql)
            pattern_counts[key] += 1
            if key not in pattern_samples:
                pattern_samples[key] = q.sql

        warnings: List[str] = []
        for key, count in pattern_counts.items():
            if count > self.n_plus_one_threshold:
                sample = pattern_samples[key]
                truncated = sample[:120] + ("..." if len(sample) > 120 else "")
                warnings.append(
                    f"Potential N+1: query pattern repeated {count} times – {truncated}"
                )
        return warnings

    # ------------------------------------------------------------------
    # Result
    # ------------------------------------------------------------------

    @property
    def report(self) -> Optional[ProfileReport]:
        """The completed profile report (available after exiting the context)."""
        return self._report


# ------------------------------------------------------------------
# SQLAlchemy event integration
# ------------------------------------------------------------------

def install_sqlalchemy_hooks(engine: Any) -> None:
    """Install before/after cursor execute hooks on a SQLAlchemy engine.

    These hooks feed query data into whichever ``RequestProfiler`` is active
    in the current context (if any).

    Args:
        engine: A SQLAlchemy ``Engine`` instance.
    """
    try:
        from sqlalchemy import event
    except ImportError:
        logger.warning("SQLAlchemy not installed – profiler query tracking disabled")
        return

    @event.listens_for(engine, "before_cursor_execute")
    def _before_cursor_execute(
        conn: Any,
        cursor: Any,
        statement: str,
        parameters: Any,
        context: Any,
        executemany: bool,
    ) -> None:
        profiler = _active_profiler.get()
        if profiler is None:
            return
        params_count = 0
        if parameters is not None:
            if isinstance(parameters, (list, tuple)):
                params_count = len(parameters)
            elif isinstance(parameters, dict):
                params_count = len(parameters)
        profiler.record_query_start(id(cursor), statement, params_count)

    @event.listens_for(engine, "after_cursor_execute")
    def _after_cursor_execute(
        conn: Any,
        cursor: Any,
        statement: str,
        parameters: Any,
        context: Any,
        executemany: bool,
    ) -> None:
        profiler = _active_profiler.get()
        if profiler is None:
            return
        profiler.record_query_end(id(cursor))

    logger.debug("SQLAlchemy profiler hooks installed on engine")


__all__ = [
    "RequestProfiler",
    "install_sqlalchemy_hooks",
]
