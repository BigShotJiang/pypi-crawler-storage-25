from __future__ import annotations

"""Profile report data structures for request profiling."""

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional


@dataclass
class QueryInfo:
    """Information about a single tracked SQL query."""

    sql: str
    duration_ms: float
    params_count: int
    timestamp: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        """Serialize to dictionary."""
        return {
            "sql": self.sql,
            "duration_ms": round(self.duration_ms, 3),
            "params_count": self.params_count,
            "timestamp": self.timestamp,
        }


@dataclass
class ProfileReport:
    """Complete profile report for a single HTTP request.

    Captures timing, database queries, cache usage, N+1 patterns,
    slow queries, and memory usage for a single request lifecycle.
    """

    request_id: str
    method: str
    path: str
    total_time_ms: float
    db_queries: List[QueryInfo] = field(default_factory=list)
    db_query_count: int = 0
    db_total_time_ms: float = 0.0
    cache_hits: int = 0
    cache_misses: int = 0
    n_plus_one_warnings: List[str] = field(default_factory=list)
    slow_queries: List[QueryInfo] = field(default_factory=list)
    memory_delta_kb: float = 0.0
    timestamp: datetime = field(default_factory=datetime.utcnow)
    status_code: int = 0

    def to_dict(self) -> Dict[str, Any]:
        """Serialize to dictionary for JSON responses."""
        return {
            "request_id": self.request_id,
            "method": self.method,
            "path": self.path,
            "total_time_ms": round(self.total_time_ms, 3),
            "db_queries": [q.to_dict() for q in self.db_queries],
            "db_query_count": self.db_query_count,
            "db_total_time_ms": round(self.db_total_time_ms, 3),
            "cache_hits": self.cache_hits,
            "cache_misses": self.cache_misses,
            "n_plus_one_warnings": self.n_plus_one_warnings,
            "slow_queries": [q.to_dict() for q in self.slow_queries],
            "memory_delta_kb": round(self.memory_delta_kb, 2),
            "timestamp": self.timestamp.isoformat(),
            "status_code": self.status_code,
        }


__all__ = [
    "QueryInfo",
    "ProfileReport",
]
