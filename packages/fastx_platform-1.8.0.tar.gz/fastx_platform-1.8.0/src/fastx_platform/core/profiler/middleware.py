from __future__ import annotations

"""Starlette/FastAPI middleware that wraps each request in a RequestProfiler.

Only activates when ``APP_ENV=development`` or ``PROFILER_ENABLED=true``.
Stores the last *N* profile reports in an in-memory ring buffer and injects
profiling headers into every response.
"""

import os
import time
from collections import deque
from typing import Any, Deque, List, Optional

from loguru import logger
from starlette.requests import Request
from starlette.types import ASGIApp, Message, Receive, Scope, Send

from .report import ProfileReport
from .tracker import RequestProfiler


def _is_profiler_enabled() -> bool:
    """Check whether profiling should be active based on environment."""
    if os.environ.get("PROFILER_ENABLED", "").lower() in ("true", "1", "yes"):
        return True
    if os.environ.get("APP_ENV", "").lower() == "development":
        return True
    return False


class ProfilerMiddleware:
    """ASGI middleware that profiles every HTTP request.

    Configuration:
    - ``max_reports``: number of reports to keep in the ring buffer (default 100).
    - ``slow_query_threshold_ms``: threshold in ms for flagging a slow query (default 100).
    - ``skip_paths``: set of path prefixes to skip profiling (e.g. healthchecks).

    Response headers added:
    - ``X-Profile-Time``: total request time in milliseconds.
    - ``X-DB-Query-Count``: number of SQL queries executed.
    """

    def __init__(
        self,
        app: ASGIApp,
        max_reports: int = 100,
        slow_query_threshold_ms: float = 100.0,
        skip_paths: Optional[List[str]] = None,
    ) -> None:
        self.app = app
        self.max_reports = max_reports
        self.slow_query_threshold_ms = slow_query_threshold_ms
        self.skip_paths = set(skip_paths or ["/__profile__", "/health", "/ready"])
        self._reports: Deque[ProfileReport] = deque(maxlen=max_reports)
        self._enabled = _is_profiler_enabled()

        if self._enabled:
            logger.info(
                "ProfilerMiddleware enabled – storing last {} reports",
                max_reports,
            )

    # ------------------------------------------------------------------
    # Public accessors (used by the endpoint module)
    # ------------------------------------------------------------------

    @property
    def reports(self) -> Deque[ProfileReport]:
        """Read-only access to the ring buffer of profile reports."""
        return self._reports

    def get_report(self, request_id: str) -> Optional[ProfileReport]:
        """Look up a single report by request_id."""
        for report in self._reports:
            if report.request_id == request_id:
                return report
        return None

    # ------------------------------------------------------------------
    # ASGI interface
    # ------------------------------------------------------------------

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http" or not self._enabled:
            await self.app(scope, receive, send)
            return

        request = Request(scope, receive)

        # Skip certain paths
        for prefix in self.skip_paths:
            if request.url.path.startswith(prefix):
                await self.app(scope, receive, send)
                return

        profiler = RequestProfiler(
            method=request.method,
            path=request.url.path,
            slow_query_threshold_ms=self.slow_query_threshold_ms,
        )

        # Capture the status code from the response
        captured_status: int = 200

        async def send_with_headers(message: Message) -> None:
            nonlocal captured_status
            if message["type"] == "http.response.start":
                captured_status = message.get("status", 200)

                # Inject profiling headers
                headers = list(message.get("headers", []))
                report = profiler.report
                if report is not None:
                    headers.append(
                        (
                            b"x-profile-time",
                            str(round(report.total_time_ms, 3)).encode(),
                        )
                    )
                    headers.append(
                        (
                            b"x-db-query-count",
                            str(report.db_query_count).encode(),
                        )
                    )
                else:
                    # Report not yet built – inject elapsed time so far
                    elapsed_ms = (time.perf_counter() - profiler._start_time) * 1000.0
                    headers.append(
                        (b"x-profile-time", str(round(elapsed_ms, 3)).encode())
                    )
                message = {**message, "headers": headers}
            await send(message)

        async with profiler:
            await self.app(scope, receive, send_with_headers)

        # Finalize report with the status code
        if profiler.report is not None:
            profiler.report.status_code = captured_status
            self._reports.append(profiler.report)


__all__ = [
    "ProfilerMiddleware",
]
