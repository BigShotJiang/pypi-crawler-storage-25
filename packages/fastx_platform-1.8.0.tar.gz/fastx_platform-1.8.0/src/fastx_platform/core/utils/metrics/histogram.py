"""In-memory histogram of raw observations."""

from __future__ import annotations

from dataclasses import dataclass, field
from threading import Lock
from typing import List

from .abstraction import IMetricsUtility

__all__ = ["Histogram"]


@dataclass
class Histogram(IMetricsUtility):
    """Simple histogram storing raw observations (in-memory)."""

    name: str
    _observations: List[float] = field(default_factory=list)
    _lock: Lock = field(default_factory=Lock, repr=False)

    def observe(self, value: float) -> None:
        """Execute observe operation.

        Args:
            value: The value parameter.

        Returns:
            The result of the operation.
        """
        with self._lock:
            self._observations.append(value)

    def snapshot(self) -> List[float]:
        """Execute snapshot operation.

        Returns:
            The result of the operation.
        """
        with self._lock:
            return list(self._observations)
