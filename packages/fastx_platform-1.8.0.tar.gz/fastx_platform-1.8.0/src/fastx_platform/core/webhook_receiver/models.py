from __future__ import annotations

"""Webhook event data model for incoming webhook processing."""

import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone


@dataclass
class WebhookEvent:
    """Represents a received webhook event.

    Attributes:
        id: Unique identifier for the event (UUID4).
        event_type: The type/name of the event (e.g. ``payment.completed``).
        payload: Parsed JSON payload from the webhook request body.
        received_at: UTC timestamp when the event was received.
        source: Identifier for the webhook source (e.g. ``stripe``, ``github``).
        verified: Whether the signature verification passed.
        processed: Whether the event was successfully dispatched to handlers.
        error: Error message if processing failed, otherwise ``None``.
    """

    event_type: str
    payload: dict
    source: str = ""
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    received_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    verified: bool = False
    processed: bool = False
    error: str | None = None
