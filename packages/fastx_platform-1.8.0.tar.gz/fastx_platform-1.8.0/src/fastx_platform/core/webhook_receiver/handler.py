from __future__ import annotations

"""Webhook handler registry and dispatcher.

Provides a decorator-based registration pattern for mapping webhook event
types to async handler callables, and a dispatcher that fans out events to
all matching handlers with per-handler error isolation.
"""

import logging
from collections import defaultdict
from typing import Any, Callable, Coroutine

logger = logging.getLogger(__name__)

# Type alias for an async handler function.
HandlerFunc = Callable[[dict], Coroutine[Any, Any, Any]]


def webhook_handler(
    event_type: str,
) -> Callable[[HandlerFunc], HandlerFunc]:
    """Class-independent decorator that registers a handler on the *default*
    :class:`WebhookHandler` instance (``default_handler``).

    Usage::

        @webhook_handler("payment.completed")
        async def on_payment(payload: dict) -> None:
            ...

    The decorated function is returned unchanged so it can still be called
    directly in tests.
    """

    def decorator(func: HandlerFunc) -> HandlerFunc:
        default_handler.register(event_type, func)
        return func

    return decorator


class WebhookHandler:
    """Registry and dispatcher for webhook event handlers.

    Multiple handlers can be registered for the same event type.  When an
    event is dispatched, all matching handlers are invoked sequentially.
    If a handler raises an exception it is logged and the remaining
    handlers continue to execute.

    Usage::

        handler = WebhookHandler()

        @handler.on("order.created")
        async def handle_order(payload: dict) -> None:
            ...

        results = await handler.dispatch("order.created", {"id": "ord_123"})
    """

    def __init__(self) -> None:
        self._handlers: dict[str, list[HandlerFunc]] = defaultdict(list)

    # ------------------------------------------------------------------
    # Registration
    # ------------------------------------------------------------------

    def register(self, event_type: str, func: HandlerFunc) -> None:
        """Register *func* as a handler for *event_type*."""
        self._handlers[event_type].append(func)
        logger.debug("Registered handler %s for event %r", func.__qualname__, event_type)

    def on(self, event_type: str) -> Callable[[HandlerFunc], HandlerFunc]:
        """Decorator form of :meth:`register`.

        Usage::

            @handler.on("invoice.paid")
            async def process_invoice(payload: dict) -> None:
                ...
        """

        def decorator(func: HandlerFunc) -> HandlerFunc:
            self.register(event_type, func)
            return func

        return decorator

    # ------------------------------------------------------------------
    # Dispatch
    # ------------------------------------------------------------------

    async def dispatch(self, event_type: str, payload: dict) -> list[Any]:
        """Invoke all handlers registered for *event_type*.

        Args:
            event_type: The event type string (e.g. ``payment.completed``).
            payload: Parsed JSON payload to pass to each handler.

        Returns:
            A list of return values from handlers that completed
            successfully.  Handlers that raised are represented by
            ``None`` in the list (their errors are logged).
        """
        handlers = self._handlers.get(event_type, [])
        if not handlers:
            logger.warning("No handlers registered for event %r", event_type)
            return []

        results: list[Any] = []
        for func in handlers:
            try:
                result = await func(payload)
                results.append(result)
            except Exception:
                logger.exception(
                    "Handler %s failed for event %r",
                    func.__qualname__,
                    event_type,
                )
                results.append(None)

        return results

    # ------------------------------------------------------------------
    # Introspection helpers
    # ------------------------------------------------------------------

    @property
    def registered_events(self) -> list[str]:
        """Return a sorted list of event types with registered handlers."""
        return sorted(self._handlers.keys())

    def handlers_for(self, event_type: str) -> list[HandlerFunc]:
        """Return the list of handlers for a given event type."""
        return list(self._handlers.get(event_type, []))


# Module-level default instance used by the ``@webhook_handler`` decorator.
default_handler = WebhookHandler()
