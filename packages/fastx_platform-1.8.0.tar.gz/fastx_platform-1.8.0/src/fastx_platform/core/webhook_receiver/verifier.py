from __future__ import annotations

"""Signature verification strategies for incoming webhooks.

Each verifier implements :class:`WebhookVerifier` and encapsulates the
provider-specific logic (header names, signing scheme, replay-attack
tolerance windows).
"""

import hashlib
import hmac
import time
from abc import ABC, abstractmethod


class WebhookVerifier(ABC):
    """Abstract base for webhook signature verifiers."""

    @abstractmethod
    async def verify(self, payload: bytes, headers: dict) -> bool:
        """Return ``True`` when the request signature is valid.

        Args:
            payload: Raw request body bytes.
            headers: Request headers (keys should be lowercased by the
                     caller or handled case-insensitively by the
                     implementation).

        Returns:
            ``True`` if the signature is valid, ``False`` otherwise.
        """
        ...


# ---------------------------------------------------------------------------
# Stripe
# ---------------------------------------------------------------------------

class StripeVerifier(WebhookVerifier):
    """Verify Stripe webhook signatures.

    Stripe sends a ``Stripe-Signature`` header in the format::

        t=<timestamp>,v1=<signature>[,v1=<signature>...]

    The signed payload is ``<timestamp>.<raw_body>``.
    """

    def __init__(self, secret: str, *, tolerance_seconds: int = 300) -> None:
        self._secret = secret.encode()
        self._tolerance = tolerance_seconds

    async def verify(self, payload: bytes, headers: dict) -> bool:
        sig_header = headers.get("stripe-signature") or headers.get("Stripe-Signature")
        if not sig_header:
            return False

        elements: dict[str, list[str]] = {}
        for item in sig_header.split(","):
            key, _, value = item.strip().partition("=")
            elements.setdefault(key, []).append(value)

        timestamp = elements.get("t", [None])[0]  # type: ignore[list-item]
        if timestamp is None:
            return False

        # Replay-attack check
        try:
            ts = int(timestamp)
        except (ValueError, TypeError):
            return False
        if abs(time.time() - ts) > self._tolerance:
            return False

        # Compute expected signature
        signed_payload = f"{timestamp}.".encode() + payload
        expected = hmac.new(self._secret, signed_payload, hashlib.sha256).hexdigest()

        signatures = elements.get("v1", [])
        return any(hmac.compare_digest(expected, sig) for sig in signatures)


# ---------------------------------------------------------------------------
# GitHub
# ---------------------------------------------------------------------------

class GitHubVerifier(WebhookVerifier):
    """Verify GitHub webhook signatures (``X-Hub-Signature-256``).

    GitHub signs the raw body with HMAC-SHA256 and sends the result
    prefixed with ``sha256=``.
    """

    def __init__(self, secret: str) -> None:
        self._secret = secret.encode()

    async def verify(self, payload: bytes, headers: dict) -> bool:
        sig_header = (
            headers.get("x-hub-signature-256")
            or headers.get("X-Hub-Signature-256")
        )
        if not sig_header:
            return False

        # Strip the "sha256=" prefix
        if sig_header.startswith("sha256="):
            sig_header = sig_header[7:]

        expected = hmac.new(self._secret, payload, hashlib.sha256).hexdigest()
        return hmac.compare_digest(expected, sig_header)


# ---------------------------------------------------------------------------
# Slack
# ---------------------------------------------------------------------------

class SlackVerifier(WebhookVerifier):
    """Verify Slack webhook signatures (``X-Slack-Signature``).

    Slack signs ``v0:<timestamp>:<body>`` with HMAC-SHA256 and sends the
    result prefixed with ``v0=``.  A timestamp tolerance check prevents
    replay attacks.
    """

    def __init__(self, signing_secret: str, *, tolerance_seconds: int = 300) -> None:
        self._secret = signing_secret.encode()
        self._tolerance = tolerance_seconds

    async def verify(self, payload: bytes, headers: dict) -> bool:
        sig_header = (
            headers.get("x-slack-signature")
            or headers.get("X-Slack-Signature")
        )
        timestamp = (
            headers.get("x-slack-request-timestamp")
            or headers.get("X-Slack-Request-Timestamp")
        )
        if not sig_header or not timestamp:
            return False

        # Replay-attack check
        try:
            ts = int(timestamp)
        except (ValueError, TypeError):
            return False
        if abs(time.time() - ts) > self._tolerance:
            return False

        # Compute expected signature
        base_string = f"v0:{timestamp}:{payload.decode()}".encode()
        expected = "v0=" + hmac.new(self._secret, base_string, hashlib.sha256).hexdigest()

        return hmac.compare_digest(expected, sig_header)


# ---------------------------------------------------------------------------
# Generic HMAC
# ---------------------------------------------------------------------------

class GenericHMACVerifier(WebhookVerifier):
    """Configurable HMAC verifier for arbitrary webhook providers.

    Args:
        secret: The shared secret.
        header_name: Name of the header containing the signature.
        algorithm: Hash algorithm name (``sha256`` or ``sha512``).
        signature_prefix: Optional prefix to strip from the header value
            (e.g. ``"sha256="``).
    """

    _ALGORITHMS = {
        "sha256": hashlib.sha256,
        "sha512": hashlib.sha512,
    }

    def __init__(
        self,
        secret: str,
        *,
        header_name: str = "X-Signature",
        algorithm: str = "sha256",
        signature_prefix: str = "",
    ) -> None:
        if algorithm not in self._ALGORITHMS:
            raise ValueError(
                f"Unsupported algorithm {algorithm!r}. "
                f"Choose from: {', '.join(self._ALGORITHMS)}"
            )
        self._secret = secret.encode()
        self._header_name = header_name
        self._hash_func = self._ALGORITHMS[algorithm]
        self._prefix = signature_prefix

    async def verify(self, payload: bytes, headers: dict) -> bool:
        sig_header = (
            headers.get(self._header_name.lower())
            or headers.get(self._header_name)
        )
        if not sig_header:
            return False

        # Strip prefix if configured
        if self._prefix and sig_header.startswith(self._prefix):
            sig_header = sig_header[len(self._prefix):]

        expected = hmac.new(self._secret, payload, self._hash_func).hexdigest()
        return hmac.compare_digest(expected, sig_header)
