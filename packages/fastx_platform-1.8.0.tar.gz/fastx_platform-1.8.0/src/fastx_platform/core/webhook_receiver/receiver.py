from __future__ import annotations

"""FastAPI router factory for receiving and processing webhooks.

The :func:`create_webhook_endpoint` function wires together a
:class:`~.verifier.WebhookVerifier` and a
:class:`~.handler.WebhookHandler` into a ready-to-mount
:class:`~fastapi.APIRouter`.
"""

import json
import logging
import uuid
from datetime import datetime, timezone
from typing import Any

from fastapi import APIRouter, Request, Response

from .handler import WebhookHandler
from .models import WebhookEvent
from .verifier import WebhookVerifier

logger = logging.getLogger(__name__)


class WebhookReceiver:
    """Encapsulates the creation of webhook-receiving endpoints.

    Args:
        verifier: Signature verification strategy.
        handler: Event handler registry / dispatcher.
        event_type_field: Dot-separated path into the JSON payload that
            holds the event type string.  For example Stripe uses
            ``"type"`` while a custom provider might use ``"event.name"``.
        source: Human-readable label for logging (e.g. ``"stripe"``).
    """

    def __init__(
        self,
        verifier: WebhookVerifier,
        handler: WebhookHandler,
        *,
        event_type_field: str = "type",
        source: str = "",
    ) -> None:
        self.verifier = verifier
        self.handler = handler
        self.event_type_field = event_type_field
        self.source = source

    # ------------------------------------------------------------------
    # Payload helpers
    # ------------------------------------------------------------------

    def _extract_event_type(self, payload: dict) -> str | None:
        """Walk *event_type_field* (dot-separated) into *payload*."""
        current: Any = payload
        for part in self.event_type_field.split("."):
            if isinstance(current, dict):
                current = current.get(part)
            else:
                return None
        return str(current) if current is not None else None

    # ------------------------------------------------------------------
    # Router factory
    # ------------------------------------------------------------------

    def create_router(self, path: str = "/webhook") -> APIRouter:
        """Build and return a :class:`~fastapi.APIRouter` with a single
        ``POST`` endpoint at *path*.

        The endpoint:

        1. Reads the raw request body.
        2. Verifies the signature via the configured verifier.
        3. Parses the body as JSON.
        4. Extracts the event type from the payload.
        5. Dispatches to registered handlers.
        6. Returns **200** on success, **400** on bad signature,
           **500** on handler errors.
        """
        router = APIRouter()

        @router.post(path)
        async def _receive_webhook(request: Request) -> Response:
            raw_body = await request.body()
            headers = dict(request.headers)
            event_id = str(uuid.uuid4())
            now = datetime.now(timezone.utc)

            # --- Step 1: Verify signature ---
            try:
                verified = await self.verifier.verify(raw_body, headers)
            except Exception:
                logger.exception(
                    "Webhook verification raised an exception | event_id=%s source=%s",
                    event_id,
                    self.source,
                )
                verified = False

            if not verified:
                logger.warning(
                    "Webhook signature verification failed | event_id=%s source=%s",
                    event_id,
                    self.source,
                )
                return Response(
                    content='{"error": "invalid signature"}',
                    status_code=400,
                    media_type="application/json",
                )

            # --- Step 2: Parse JSON payload ---
            try:
                payload: dict = json.loads(raw_body)
            except (json.JSONDecodeError, UnicodeDecodeError) as exc:
                logger.error(
                    "Webhook body is not valid JSON | event_id=%s source=%s error=%s",
                    event_id,
                    self.source,
                    exc,
                )
                return Response(
                    content='{"error": "invalid JSON body"}',
                    status_code=400,
                    media_type="application/json",
                )

            # --- Step 3: Extract event type ---
            event_type = self._extract_event_type(payload)
            if event_type is None:
                logger.error(
                    "Could not extract event type (field=%r) | event_id=%s source=%s",
                    self.event_type_field,
                    event_id,
                    self.source,
                )
                return Response(
                    content='{"error": "missing event type"}',
                    status_code=400,
                    media_type="application/json",
                )

            # Build the event model for logging / auditing purposes.
            event = WebhookEvent(
                id=event_id,
                event_type=event_type,
                payload=payload,
                received_at=now,
                source=self.source,
                verified=True,
            )

            # --- Step 4: Dispatch to handlers ---
            try:
                await self.handler.dispatch(event_type, payload)
                event.processed = True
            except Exception:
                logger.exception(
                    "Webhook handler error | event_id=%s event_type=%s source=%s",
                    event_id,
                    event_type,
                    self.source,
                )
                event.error = "handler error"
                return Response(
                    content='{"error": "internal handler error"}',
                    status_code=500,
                    media_type="application/json",
                )

            logger.info(
                "Webhook processed successfully | event_id=%s event_type=%s source=%s timestamp=%s",
                event_id,
                event_type,
                self.source,
                now.isoformat(),
            )
            return Response(
                content='{"status": "ok"}',
                status_code=200,
                media_type="application/json",
            )

        return router


def create_webhook_endpoint(
    path: str,
    verifier: WebhookVerifier,
    handler: WebhookHandler,
    *,
    event_type_field: str = "type",
    source: str = "",
) -> APIRouter:
    """Convenience wrapper around :class:`WebhookReceiver`.

    Returns a :class:`~fastapi.APIRouter` ready to be included in a
    FastAPI application::

        from fastx_platform.core.webhook_receiver import (
            create_webhook_endpoint, GitHubVerifier, WebhookHandler,
        )

        handler = WebhookHandler()

        @handler.on("push")
        async def on_push(payload: dict) -> None:
            ...

        router = create_webhook_endpoint(
            "/hooks/github",
            verifier=GitHubVerifier(secret="whsec_..."),
            handler=handler,
            event_type_field="action",
            source="github",
        )
        app.include_router(router)
    """
    receiver = WebhookReceiver(
        verifier=verifier,
        handler=handler,
        event_type_field=event_type_field,
        source=source,
    )
    return receiver.create_router(path)
