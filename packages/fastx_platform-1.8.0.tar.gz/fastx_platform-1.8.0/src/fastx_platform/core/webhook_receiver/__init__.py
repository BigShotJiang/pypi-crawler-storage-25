from __future__ import annotations

"""Webhook receiver utilities for incoming webhook processing.

This package provides signature verification, handler registration /
dispatch, and a FastAPI router factory for receiving webhooks from
third-party providers (Stripe, GitHub, Slack, or any HMAC-based source).
"""

from .handler import WebhookHandler, webhook_handler
from .models import WebhookEvent
from .receiver import WebhookReceiver, create_webhook_endpoint
from .verifier import (
    GenericHMACVerifier,
    GitHubVerifier,
    SlackVerifier,
    StripeVerifier,
    WebhookVerifier,
)

__all__ = [
    "WebhookReceiver",
    "WebhookHandler",
    "WebhookVerifier",
    "StripeVerifier",
    "GitHubVerifier",
    "GenericHMACVerifier",
    "SlackVerifier",
    "WebhookEvent",
    "create_webhook_endpoint",
    "webhook_handler",
]
