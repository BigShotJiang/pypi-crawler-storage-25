"""Lightweight cron expression parser.

Parses standard 5-field cron expressions and common shortcuts into the
next :class:`~datetime.datetime` at which the expression matches.  No
external dependencies are required -- the implementation uses a simple
forward-scanning algorithm.

Supported field format (per POSIX cron)::

    minute  hour  day_of_month  month  day_of_week
    0-59    0-23  1-31          1-12   0-6 (0 = Sunday)

Each field accepts: literal values, ranges (``1-5``), steps (``*/15``,
``1-30/5``), comma-separated lists (``1,15,30``), and wildcard (``*``).

Shortcut aliases::

    @hourly   -> 0 * * * *
    @daily    -> 0 0 * * *
    @weekly   -> 0 0 * * 0
    @monthly  -> 0 0 1 * *
"""

from __future__ import annotations

import re
from datetime import datetime, timedelta
from typing import Sequence

_SHORTCUTS: dict[str, str] = {
    "@hourly": "0 * * * *",
    "@daily": "0 0 * * *",
    "@midnight": "0 0 * * *",
    "@weekly": "0 0 * * 0",
    "@monthly": "0 0 1 * *",
    "@yearly": "0 0 1 1 *",
    "@annually": "0 0 1 1 *",
}

_FIELD_RANGES: list[tuple[int, int]] = [
    (0, 59),   # minute
    (0, 23),   # hour
    (1, 31),   # day of month
    (1, 12),   # month
    (0, 6),    # day of week  (0 = Sunday)
]

_CRON5 = re.compile(r"^(\S+)\s+(\S+)\s+(\S+)\s+(\S+)\s+(\S+)$")


class CronParseError(ValueError):
    """Raised when a cron expression cannot be parsed."""


# ------------------------------------------------------------------
# Internal helpers
# ------------------------------------------------------------------

def _parse_field(token: str, lo: int, hi: int) -> set[int]:
    """Expand a single cron field token into an explicit set of integers.

    Handles ``*``, ranges (``1-5``), steps (``*/10``, ``1-30/5``), and
    comma-separated lists.
    """
    values: set[int] = set()
    for part in token.split(","):
        part = part.strip()
        if not part:
            raise CronParseError(f"empty sub-expression in field '{token}'")

        step: int | None = None
        if "/" in part:
            base, step_str = part.split("/", 1)
            try:
                step = int(step_str)
            except ValueError as exc:
                raise CronParseError(f"invalid step value '{step_str}'") from exc
            if step <= 0:
                raise CronParseError(f"step must be > 0, got {step}")
            part = base

        if part == "*":
            start, end = lo, hi
        elif "-" in part:
            range_parts = part.split("-", 1)
            try:
                start, end = int(range_parts[0]), int(range_parts[1])
            except ValueError as exc:
                raise CronParseError(f"invalid range '{part}'") from exc
        else:
            try:
                val = int(part)
            except ValueError as exc:
                raise CronParseError(f"invalid literal '{part}'") from exc
            if step is not None:
                start, end = val, hi
            else:
                values.add(val)
                continue

        if step is None:
            step = 1
        for v in range(start, end + 1, step):
            values.add(v)

    # Clamp to valid range
    out = {v for v in values if lo <= v <= hi}
    if not out:
        raise CronParseError(
            f"field '{token}' produced no valid values in range [{lo}, {hi}]"
        )
    return out


def _parse_expression(expression: str) -> list[set[int]]:
    """Parse a full 5-field cron expression into a list of value sets."""
    expr = _SHORTCUTS.get(expression.strip().lower(), expression).strip()
    match = _CRON5.match(expr)
    if not match:
        raise CronParseError(
            f"cron expression must contain exactly 5 fields: '{expression}'"
        )
    fields: list[set[int]] = []
    for idx in range(5):
        lo, hi = _FIELD_RANGES[idx]
        fields.append(_parse_field(match.group(idx + 1), lo, hi))
    return fields


def _matches(dt: datetime, fields: list[set[int]]) -> bool:
    """Return True if *dt* satisfies every field in *fields*."""
    # Python weekday: Monday=0 .. Sunday=6
    # Cron weekday:   Sunday=0 .. Saturday=6
    cron_dow = (dt.weekday() + 1) % 7
    return (
        dt.minute in fields[0]
        and dt.hour in fields[1]
        and dt.day in fields[2]
        and dt.month in fields[3]
        and cron_dow in fields[4]
    )


# ------------------------------------------------------------------
# Public API
# ------------------------------------------------------------------

def parse_cron(expression: str, after: datetime | None = None) -> datetime:
    """Return the next :class:`~datetime.datetime` matching *expression*.

    Args:
        expression: A 5-field cron string or a shortcut alias
            (``@hourly``, ``@daily``, etc.).
        after: The reference point.  Defaults to :func:`datetime.now` if
            not provided.  The returned time is strictly *after* this value.

    Returns:
        The next matching minute-aligned ``datetime``.

    Raises:
        CronParseError: If *expression* is syntactically invalid.
        RuntimeError: If no match is found within ~4 years (safety guard).
    """
    fields = _parse_expression(expression)
    now = after if after is not None else datetime.now()

    # Start scanning from the next whole minute after *now*.
    candidate = now.replace(second=0, microsecond=0) + timedelta(minutes=1)

    # Safety ceiling: scan up to 4 years ahead (enough for any valid
    # cron expression, including ``0 0 29 2 *``).
    ceiling = candidate + timedelta(days=366 * 4)

    while candidate <= ceiling:
        if _matches(candidate, fields):
            return candidate

        # Fast-forward logic: skip ahead when month/day clearly won't match
        if candidate.month not in fields[3]:
            # Jump to the 1st of next month
            if candidate.month == 12:
                candidate = candidate.replace(
                    year=candidate.year + 1, month=1, day=1, hour=0, minute=0,
                )
            else:
                candidate = candidate.replace(
                    month=candidate.month + 1, day=1, hour=0, minute=0,
                )
            continue

        if candidate.day not in fields[2]:
            candidate = candidate.replace(hour=0, minute=0) + timedelta(days=1)
            continue

        if candidate.hour not in fields[1]:
            candidate = candidate.replace(minute=0) + timedelta(hours=1)
            continue

        candidate += timedelta(minutes=1)

    raise RuntimeError(
        f"no matching datetime found within 4 years for expression '{expression}'"
    )
