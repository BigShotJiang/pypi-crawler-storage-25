"""Backend abstractions for job state and distributed locking.

Two concrete implementations are provided out of the box:

* :class:`InMemoryCronBackend` -- suitable for single-process deployments
  and local development.
* :class:`RedisCronBackend` -- uses Redis for persisted state and
  distributed locking so that only one worker fires a given job per
  scheduled tick, even across multiple processes or hosts.
"""

from __future__ import annotations

import abc
import logging
import time
from datetime import datetime
from typing import Any, Optional

logger = logging.getLogger(__name__)


class CronBackend(abc.ABC):
    """Abstract interface for scheduler state persistence and locking."""

    @abc.abstractmethod
    async def get_last_run(self, job_name: str) -> datetime | None:
        """Return the last successful run timestamp for *job_name*, or ``None``."""

    @abc.abstractmethod
    async def set_last_run(self, job_name: str, timestamp: datetime) -> None:
        """Persist *timestamp* as the last run time for *job_name*."""

    @abc.abstractmethod
    async def acquire_lock(self, job_name: str, ttl_seconds: int = 300) -> bool:
        """Attempt to acquire an execution lock for *job_name*.

        Returns ``True`` if the lock was acquired, ``False`` if another
        worker already holds it.  The lock should auto-expire after
        *ttl_seconds* to prevent deadlocks.
        """

    @abc.abstractmethod
    async def release_lock(self, job_name: str) -> None:
        """Release the execution lock for *job_name*."""


# ------------------------------------------------------------------
# In-memory backend
# ------------------------------------------------------------------

class InMemoryCronBackend(CronBackend):
    """Dict-based backend for single-process schedulers.

    All state is lost when the process exits.  Locking is trivially
    implemented with a :class:`set` since there is only one event loop.
    """

    def __init__(self) -> None:
        self._last_runs: dict[str, datetime] = {}
        self._locks: set[str] = set()

    async def get_last_run(self, job_name: str) -> datetime | None:
        return self._last_runs.get(job_name)

    async def set_last_run(self, job_name: str, timestamp: datetime) -> None:
        self._last_runs[job_name] = timestamp

    async def acquire_lock(self, job_name: str, ttl_seconds: int = 300) -> bool:
        if job_name in self._locks:
            return False
        self._locks.add(job_name)
        return True

    async def release_lock(self, job_name: str) -> None:
        self._locks.discard(job_name)


# ------------------------------------------------------------------
# Redis backend
# ------------------------------------------------------------------

class RedisCronBackend(CronBackend):
    """Redis-backed state and distributed locking.

    Prevents duplicate job execution across multiple worker processes by
    using ``SET NX EX`` for distributed locks and Redis strings for
    last-run timestamps.

    Args:
        redis_client: An ``redis.asyncio.Redis`` instance.  The caller
            is responsible for connection lifecycle.
        key_prefix: Namespace prefix for all keys written by this
            backend.
    """

    def __init__(
        self,
        redis_client: Any,
        key_prefix: str = "fastx:cron:",
    ) -> None:
        self._redis = redis_client
        self._prefix = key_prefix

    def _key(self, kind: str, job_name: str) -> str:
        return f"{self._prefix}{kind}:{job_name}"

    # -- last run --------------------------------------------------

    async def get_last_run(self, job_name: str) -> datetime | None:
        raw = await self._redis.get(self._key("last_run", job_name))
        if raw is None:
            return None
        try:
            ts = float(raw)
            return datetime.fromtimestamp(ts)
        except (ValueError, TypeError, OSError):
            logger.warning("corrupt last_run value for '%s': %r", job_name, raw)
            return None

    async def set_last_run(self, job_name: str, timestamp: datetime) -> None:
        ts = timestamp.timestamp()
        await self._redis.set(self._key("last_run", job_name), str(ts))

    # -- distributed lock ------------------------------------------

    async def acquire_lock(self, job_name: str, ttl_seconds: int = 300) -> bool:
        """Use ``SET NX EX`` for an atomic, auto-expiring lock."""
        key = self._key("lock", job_name)
        result = await self._redis.set(key, str(time.time()), nx=True, ex=ttl_seconds)
        return result is not None and result is not False

    async def release_lock(self, job_name: str) -> None:
        key = self._key("lock", job_name)
        await self._redis.delete(key)
