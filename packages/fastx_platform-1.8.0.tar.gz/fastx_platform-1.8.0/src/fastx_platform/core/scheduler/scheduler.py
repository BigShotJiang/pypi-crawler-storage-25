"""Core scheduler engine.

:class:`CronScheduler` is the main entry-point.  It manages a
collection of :class:`ScheduledJob` instances, evaluates their cron
expressions once per tick, and dispatches due jobs as ``asyncio`` tasks
with timeout enforcement and retry logic.

Typical usage::

    from fastx_platform.core.scheduler import CronScheduler, cron

    @cron("*/5 * * * *")
    async def cleanup():
        ...

    scheduler = CronScheduler()
    scheduler.discover()       # picks up @cron-decorated functions
    await scheduler.start()    # runs until cancelled
"""

from __future__ import annotations

import asyncio
import logging
from datetime import datetime
from typing import Any

from .backends import CronBackend, InMemoryCronBackend
from .decorator import get_registered_jobs
from .job import ScheduledJob
from .parser import parse_cron

logger = logging.getLogger(__name__)


class CronScheduler:
    """Asyncio-based cron scheduler.

    Args:
        backend: Persistence/locking backend.  Defaults to
            :class:`InMemoryCronBackend` when ``None``.
        tick_seconds: Interval between schedule checks (default 30).
    """

    def __init__(
        self,
        backend: CronBackend | None = None,
        tick_seconds: float = 30,
    ) -> None:
        self._backend: CronBackend = backend or InMemoryCronBackend()
        self._tick_seconds = tick_seconds
        self._jobs: dict[str, ScheduledJob] = {}
        self._running = False
        self._task: asyncio.Task[None] | None = None
        self._active_tasks: dict[str, asyncio.Task[Any]] = {}

    # ------------------------------------------------------------------
    # Registration
    # ------------------------------------------------------------------

    def register(self, job: ScheduledJob) -> None:
        """Add a job to the scheduler.

        Args:
            job: The :class:`ScheduledJob` to manage.

        Raises:
            ValueError: If a job with the same name is already registered.
        """
        if job.name in self._jobs:
            raise ValueError(f"job '{job.name}' is already registered")
        self._jobs[job.name] = job
        logger.info("registered cron job '%s' [%s]", job.name, job.cron_expression)

    def discover(self) -> int:
        """Import all ``@cron``-decorated jobs from the global registry.

        Returns:
            The number of newly registered jobs.
        """
        registered = get_registered_jobs()
        count = 0
        for name, job in registered.items():
            if name not in self._jobs:
                self._jobs[name] = job
                count += 1
                logger.info(
                    "discovered cron job '%s' [%s]", name, job.cron_expression,
                )
        return count

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def start(self) -> None:
        """Start the scheduler loop.

        The loop runs indefinitely until :meth:`stop` is called or the
        task is cancelled.  Each tick it evaluates every registered job
        and spawns an ``asyncio.Task`` for any that are due.
        """
        if self._running:
            logger.warning("scheduler is already running")
            return
        self._running = True
        logger.info("cron scheduler starting (%d jobs)", len(self._jobs))

        # Pre-compute initial next_run for every job
        now = datetime.now()
        for job in self._jobs.values():
            if job.next_run is None:
                job.next_run = parse_cron(job.cron_expression, after=now)

        self._task = asyncio.current_task()
        try:
            while self._running:
                await self._tick()
                await asyncio.sleep(self._tick_seconds)
        except asyncio.CancelledError:
            logger.info("scheduler loop cancelled")
        finally:
            self._running = False
            logger.info("cron scheduler stopped")

    async def stop(self) -> None:
        """Gracefully shut down the scheduler.

        Waits for all in-flight job tasks to complete (up to 30 s) before
        returning.
        """
        self._running = False
        logger.info("cron scheduler shutting down")

        # Wait for active tasks to finish
        if self._active_tasks:
            logger.info(
                "waiting for %d active job(s) to complete", len(self._active_tasks),
            )
            done, pending = await asyncio.wait(
                self._active_tasks.values(),
                timeout=30,
            )
            for t in pending:
                t.cancel()
                logger.warning("cancelled lingering job task: %s", t.get_name())

        self._active_tasks.clear()

    async def run_job(self, job_name: str) -> None:
        """Manually trigger a job by name, bypassing the schedule.

        Args:
            job_name: Name of a registered job.

        Raises:
            KeyError: If *job_name* is not registered.
        """
        if job_name not in self._jobs:
            raise KeyError(f"unknown job '{job_name}'")
        job = self._jobs[job_name]
        logger.info("manually triggering job '%s'", job_name)
        await self._execute_job(job)

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    async def _tick(self) -> None:
        """Evaluate all jobs and dispatch those whose next_run has passed."""
        now = datetime.now()
        for job in list(self._jobs.values()):
            if not job.enabled:
                continue
            if job.name in self._active_tasks:
                # Already running -- skip until the current run finishes.
                task = self._active_tasks[job.name]
                if not task.done():
                    continue
                # Clean up finished task reference.
                del self._active_tasks[job.name]

            if job.next_run is not None and now >= job.next_run:
                task = asyncio.create_task(
                    self._guarded_execute(job),
                    name=f"cron:{job.name}",
                )
                self._active_tasks[job.name] = task

    async def _guarded_execute(self, job: ScheduledJob) -> None:
        """Acquire lock, execute with retries, then release lock."""
        acquired = await self._backend.acquire_lock(
            job.name, ttl_seconds=job.timeout_seconds,
        )
        if not acquired:
            logger.debug(
                "skipping job '%s': lock held by another worker", job.name,
            )
            return

        try:
            await self._execute_with_retries(job)
        finally:
            await self._backend.release_lock(job.name)
            # Advance next_run regardless of success/failure.
            job.last_run = datetime.now()
            job.next_run = parse_cron(job.cron_expression, after=job.last_run)
            await self._backend.set_last_run(job.name, job.last_run)

    async def _execute_with_retries(self, job: ScheduledJob) -> None:
        """Run *job.func* with timeout and retry logic."""
        last_exc: BaseException | None = None
        attempts = 1 + job.max_retries

        for attempt in range(1, attempts + 1):
            try:
                logger.info(
                    "executing job '%s' (attempt %d/%d)",
                    job.name,
                    attempt,
                    attempts,
                )
                await asyncio.wait_for(
                    job.func(),
                    timeout=job.timeout_seconds,
                )
                logger.info("job '%s' completed successfully", job.name)
                return
            except asyncio.TimeoutError:
                last_exc = asyncio.TimeoutError(
                    f"job '{job.name}' timed out after {job.timeout_seconds}s",
                )
                logger.warning(
                    "job '%s' timed out (attempt %d/%d)",
                    job.name,
                    attempt,
                    attempts,
                )
            except Exception as exc:
                last_exc = exc
                logger.exception(
                    "job '%s' failed (attempt %d/%d): %s",
                    job.name,
                    attempt,
                    attempts,
                    exc,
                )

            if attempt < attempts:
                # Brief backoff before retry: 2^attempt seconds, capped at 60.
                delay = min(2 ** attempt, 60)
                await asyncio.sleep(delay)

        logger.error(
            "job '%s' exhausted all %d attempts; last error: %s",
            job.name,
            attempts,
            last_exc,
        )

    async def _execute_job(self, job: ScheduledJob) -> None:
        """Single-shot execution (used by :meth:`run_job`)."""
        await self._execute_with_retries(job)
        job.last_run = datetime.now()
        job.next_run = parse_cron(job.cron_expression, after=job.last_run)
        await self._backend.set_last_run(job.name, job.last_run)
