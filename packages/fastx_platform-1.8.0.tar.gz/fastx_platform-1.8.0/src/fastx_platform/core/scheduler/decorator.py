"""Cron decorator for declarative job registration.

Provides the :func:`cron` decorator which marks an async function as a
scheduled job and registers it in a global registry so that
:class:`CronScheduler` can discover it automatically.

Example::

    @cron("*/5 * * * *", name="token-cleanup")
    async def cleanup_expired_tokens():
        await db.execute("DELETE FROM tokens WHERE expires_at < NOW()")

    @cron("@daily")
    async def send_daily_digest():
        ...
"""

from __future__ import annotations

import functools
import logging
from typing import Any, Callable, TypeVar

from .job import ScheduledJob
from .parser import parse_cron

logger = logging.getLogger(__name__)

F = TypeVar("F", bound=Callable[..., Any])

# Global registry populated by the @cron decorator.  The scheduler
# calls :func:`get_registered_jobs` to collect them.
_registry: dict[str, ScheduledJob] = {}


def cron(
    expression: str,
    *,
    name: str | None = None,
    enabled: bool = True,
    max_retries: int = 3,
    timeout_seconds: int = 300,
    metadata: dict[str, Any] | None = None,
) -> Callable[[F], F]:
    """Decorator that registers an async function as a cron job.

    Args:
        expression: 5-field cron string or shortcut (``@hourly``, etc.).
        name: Unique job name.  Defaults to ``module.qualname``.
        enabled: Whether the job is active.
        max_retries: Retry attempts on failure.
        timeout_seconds: Per-run wall-clock timeout.
        metadata: Arbitrary key/value pairs attached to the job.

    Returns:
        The original function, unmodified at runtime.  A
        :class:`ScheduledJob` is stored in the module-level registry.
    """

    def decorator(fn: F) -> F:
        job_name = name or f"{fn.__module__}.{fn.__qualname__}"

        # Validate the expression eagerly so typos surface at import time.
        parse_cron(expression)

        job = ScheduledJob(
            name=job_name,
            cron_expression=expression,
            func=fn,
            enabled=enabled,
            max_retries=max_retries,
            timeout_seconds=timeout_seconds,
            metadata=metadata or {},
        )

        if job_name in _registry:
            logger.warning(
                "cron job '%s' registered more than once; overwriting previous definition",
                job_name,
            )
        _registry[job_name] = job

        # Stash reference on the function for introspection.
        fn._scheduled_job = job  # type: ignore[attr-defined]

        @functools.wraps(fn)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            return fn(*args, **kwargs)

        # Preserve the scheduled-job marker on the wrapper.
        wrapper._scheduled_job = job  # type: ignore[attr-defined]
        return wrapper  # type: ignore[return-value]

    return decorator


def get_registered_jobs() -> dict[str, ScheduledJob]:
    """Return a shallow copy of the global job registry."""
    return dict(_registry)


def clear_registry() -> None:
    """Remove all registered jobs (useful in tests)."""
    _registry.clear()
