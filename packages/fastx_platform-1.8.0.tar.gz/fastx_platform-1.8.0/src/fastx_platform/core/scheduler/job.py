"""Scheduled job definition.

Provides the :class:`ScheduledJob` dataclass that describes a single
cron-scheduled unit of work, including its schedule, retry policy,
timeout, and runtime metadata.
"""

from __future__ import annotations

import dataclasses
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Callable


@dataclass
class ScheduledJob:
    """A single scheduled job managed by :class:`CronScheduler`.

    Attributes:
        name: Human-readable identifier (must be unique within a scheduler).
        cron_expression: Standard 5-field cron string or shortcut
            (``@hourly``, ``@daily``, ``@weekly``, ``@monthly``).
        func: The async callable to execute when the job fires.
        enabled: Whether the scheduler should consider this job.
        max_retries: Number of retry attempts on failure (0 = no retries).
        timeout_seconds: Maximum wall-clock seconds before the job is
            considered timed out.
        last_run: Timestamp of the most recent execution (populated at
            runtime).
        next_run: Precomputed timestamp of the next scheduled execution.
        metadata: Arbitrary key/value bag for application-specific data
            (e.g. owner, tags, alert channel).
    """

    name: str
    cron_expression: str
    func: Callable[..., Any]
    enabled: bool = True
    max_retries: int = 3
    timeout_seconds: int = 300
    last_run: datetime | None = None
    next_run: datetime | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Validate required fields after initialisation."""
        if not self.name:
            raise ValueError("ScheduledJob.name must be a non-empty string")
        if not self.cron_expression:
            raise ValueError("ScheduledJob.cron_expression must be a non-empty string")
        if not callable(self.func):
            raise TypeError("ScheduledJob.func must be callable")
