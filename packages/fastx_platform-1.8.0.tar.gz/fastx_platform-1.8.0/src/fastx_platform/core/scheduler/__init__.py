"""Cron/scheduled jobs module for fastx_platform.

Provides a lightweight, asyncio-native cron scheduler with pluggable
backends for job state persistence and distributed locking.

Quick start::

    from fastx_platform.core.scheduler import CronScheduler, cron

    @cron("*/5 * * * *")
    async def cleanup_expired_tokens():
        ...

    scheduler = CronScheduler()
    scheduler.discover()
    await scheduler.start()

For multi-worker deployments, use :class:`RedisCronBackend` to prevent
duplicate job execution::

    from fastx_platform.core.scheduler import CronScheduler, RedisCronBackend

    backend = RedisCronBackend(redis_client=my_redis)
    scheduler = CronScheduler(backend=backend)
"""

from __future__ import annotations

from .backends import CronBackend, InMemoryCronBackend, RedisCronBackend
from .decorator import cron
from .job import ScheduledJob
from .scheduler import CronScheduler

__all__ = [
    "CronBackend",
    "CronScheduler",
    "InMemoryCronBackend",
    "RedisCronBackend",
    "ScheduledJob",
    "cron",
]
