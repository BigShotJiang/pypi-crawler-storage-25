from __future__ import annotations

"""Simple email template loading and rendering.

Templates are loaded from a ``templates/email/`` directory relative to the
working directory (or a configurable base path). Rendering is done via
Jinja2 when available, falling back to Python's :meth:`str.format_map`.
"""

import logging
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

_DEFAULT_TEMPLATE_DIR = Path("templates/email")

try:
    from jinja2 import Environment, FileSystemLoader, TemplateNotFound

    _JINJA2_AVAILABLE = True
except ImportError:  # pragma: no cover
    _JINJA2_AVAILABLE = False


def _resolve_template_dir(base_dir: Path | None = None) -> Path:
    """Resolve the template directory path.

    Args:
        base_dir: Optional override for the template directory. Defaults to
            ``templates/email/`` relative to the current working directory.

    Returns:
        The resolved template directory path.
    """
    return base_dir if base_dir is not None else _DEFAULT_TEMPLATE_DIR


def load_template(name: str, *, base_dir: Path | None = None) -> str:
    """Load a raw template string from disk.

    Args:
        name: Template file name (e.g. ``"welcome.html"``). The ``.html``
            extension is appended automatically when absent.
        base_dir: Optional override for the template directory.

    Returns:
        The raw template content as a string.

    Raises:
        FileNotFoundError: If the template file does not exist.
    """
    template_dir = _resolve_template_dir(base_dir)
    if not name.endswith(".html"):
        name = f"{name}.html"
    template_path = template_dir / name

    if not template_path.is_file():
        raise FileNotFoundError(f"Email template not found: {template_path}")

    content = template_path.read_text(encoding="utf-8")
    logger.debug("Loaded email template '%s' (%d chars)", name, len(content))
    return content


def render_template(
    name: str,
    context: dict[str, Any],
    *,
    base_dir: Path | None = None,
) -> str:
    """Render an email template with the given context variables.

    Uses Jinja2 if available for full template support (conditionals, loops,
    filters, etc.). Falls back to :meth:`str.format_map` for simple
    ``{variable}`` substitution when Jinja2 is not installed.

    Args:
        name: Template file name (e.g. ``"welcome.html"`` or ``"welcome"``).
        base_dir: Optional override for the template directory.
        context: Dictionary of variables to inject into the template.

    Returns:
        The rendered template as a string.

    Raises:
        FileNotFoundError: If the template file does not exist.
    """
    template_dir = _resolve_template_dir(base_dir)
    if not name.endswith(".html"):
        name = f"{name}.html"

    if _JINJA2_AVAILABLE:
        try:
            env = Environment(
                loader=FileSystemLoader(str(template_dir)),
                autoescape=True,
            )
            template = env.get_template(name)
            rendered = template.render(**context)
            logger.debug("Rendered email template '%s' with Jinja2", name)
            return rendered
        except TemplateNotFound:
            raise FileNotFoundError(f"Email template not found: {template_dir / name}")
    else:
        logger.debug("Jinja2 not available, falling back to str.format_map")
        raw = load_template(name, base_dir=base_dir)
        return raw.format_map(context)
