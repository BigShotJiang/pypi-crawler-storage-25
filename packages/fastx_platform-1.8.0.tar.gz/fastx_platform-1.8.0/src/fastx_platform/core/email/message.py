from __future__ import annotations

"""Email message dataclass for structured email composition.

Provides a type-safe, immutable representation of an email message
with support for HTML bodies, attachments, CC/BCC, and custom headers.
"""

import logging
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)


@dataclass
class EmailMessage:
    """Represents a single email message.

    Attributes:
        to: List of recipient email addresses.
        subject: Email subject line.
        body: Plain-text body content.
        from_email: Sender email address. If None, the provider default is used.
        cc: List of CC recipient email addresses.
        bcc: List of BCC recipient email addresses.
        html_body: Optional HTML body content. When provided, the message is
            sent as multipart/alternative with both plain-text and HTML parts.
        attachments: List of (filename, data, mime_type) tuples representing
            file attachments.
        reply_to: Optional Reply-To email address.
        headers: Additional custom headers to include in the message.
    """

    to: list[str]
    subject: str
    body: str
    from_email: str | None = None
    cc: list[str] = field(default_factory=list)
    bcc: list[str] = field(default_factory=list)
    html_body: str | None = None
    attachments: list[tuple[str, bytes, str]] = field(default_factory=list)
    reply_to: str | None = None
    headers: dict[str, str] = field(default_factory=dict)

    @property
    def all_recipients(self) -> list[str]:
        """Return a combined list of all recipients (to + cc + bcc)."""
        return self.to + self.cc + self.bcc

    def validate(self) -> list[str]:
        """Validate the message and return a list of error descriptions.

        Returns:
            An empty list if the message is valid, otherwise a list of
            human-readable validation error strings.
        """
        errors: list[str] = []
        if not self.to:
            errors.append("At least one recipient is required in 'to'.")
        if not self.subject:
            errors.append("Subject must not be empty.")
        if not self.body and not self.html_body:
            errors.append("Either 'body' or 'html_body' must be provided.")
        return errors
