from __future__ import annotations

"""Email provider abstraction for FastX Platform.

Public API:
    - :class:`EmailMessage` -- structured email message dataclass.
    - :class:`EmailProvider` -- abstract base for email backends.
    - :class:`EmailService` -- high-level service with template support.
    - :class:`SMTPProvider` -- SMTP backend via ``aiosmtplib``.
    - :class:`SendGridProvider` -- SendGrid v3 API backend.
    - :class:`SESProvider` -- Amazon SES backend via ``boto3``.
    - :class:`MailgunProvider` -- Mailgun API backend.

Providers are lazily imported to avoid hard dependencies on third-party
libraries unless actually used.
"""

from .message import EmailMessage
from .provider import EmailProvider
from .service import EmailService


def __getattr__(name: str):
    if name in ("MailgunProvider", "SendGridProvider", "SESProvider", "SMTPProvider"):
        from . import providers
        return getattr(providers, name)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = [
    "EmailMessage",
    "EmailProvider",
    "EmailService",
    "MailgunProvider",
    "SendGridProvider",
    "SESProvider",
    "SMTPProvider",
]
