from __future__ import annotations

"""Abstract base class for email providers.

All concrete email providers (SMTP, SendGrid, SES, Mailgun) must inherit
from :class:`EmailProvider` and implement :meth:`send`.
"""

import logging
from abc import ABC, abstractmethod

from .message import EmailMessage

logger = logging.getLogger(__name__)


class EmailProvider(ABC):
    """Abstract email provider interface.

    Subclasses must implement :meth:`send`. The default :meth:`send_bulk`
    implementation calls :meth:`send` for each message sequentially; providers
    that support native batch sending should override it.
    """

    @abstractmethod
    async def send(self, message: EmailMessage) -> bool:
        """Send a single email message.

        Args:
            message: The email message to send.

        Returns:
            True if the message was sent successfully, False otherwise.
        """
        ...

    async def send_bulk(self, messages: list[EmailMessage]) -> list[bool]:
        """Send multiple email messages.

        The default implementation sends each message individually via
        :meth:`send`. Providers with native batch APIs should override
        this method for better performance.

        Args:
            messages: List of email messages to send.

        Returns:
            A list of booleans indicating success or failure for each message,
            in the same order as the input list.
        """
        results: list[bool] = []
        for message in messages:
            try:
                result = await self.send(message)
                results.append(result)
            except Exception:
                logger.exception("Unexpected error in send_bulk for message to %s", message.to)
                results.append(False)
        return results
