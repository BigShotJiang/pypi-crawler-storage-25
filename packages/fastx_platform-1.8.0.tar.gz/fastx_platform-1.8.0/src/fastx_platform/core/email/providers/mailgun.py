from __future__ import annotations

"""Mailgun email provider using the Mailgun Messages API via httpx.

Configuration is read from environment variables:
    - ``MAILGUN_API_KEY`` (required)
    - ``MAILGUN_DOMAIN`` (required, e.g. ``mg.example.com``)
    - ``MAILGUN_API_BASE`` (optional, default ``https://api.mailgun.net/v3``)
    - ``MAILGUN_DEFAULT_FROM`` (optional fallback sender address)
"""

import logging
import os

import httpx

from ..message import EmailMessage
from ..provider import EmailProvider

logger = logging.getLogger(__name__)


class MailgunProvider(EmailProvider):
    """Send emails via the Mailgun Messages API.

    Args:
        api_key: Mailgun API key. Falls back to ``MAILGUN_API_KEY`` env var.
        domain: Mailgun sending domain. Falls back to ``MAILGUN_DOMAIN``.
        api_base: Mailgun API base URL.
        default_from: Default sender email address.
    """

    def __init__(
        self,
        *,
        api_key: str | None = None,
        domain: str | None = None,
        api_base: str | None = None,
        default_from: str | None = None,
    ) -> None:
        self._api_key = api_key or os.environ.get("MAILGUN_API_KEY", "")
        self._domain = domain or os.environ.get("MAILGUN_DOMAIN", "")
        self._api_base = api_base or os.environ.get(
            "MAILGUN_API_BASE",
            "https://api.mailgun.net/v3",
        )
        self._default_from = default_from or os.environ.get("MAILGUN_DEFAULT_FROM")

        if not self._api_key:
            logger.warning("MAILGUN_API_KEY is not set; MailgunProvider will fail on send.")
        if not self._domain:
            logger.warning("MAILGUN_DOMAIN is not set; MailgunProvider will fail on send.")

    def _build_form_data(self, message: EmailMessage) -> dict[str, str | list[str]]:
        """Build multipart form data for the Mailgun messages endpoint."""
        from_addr = message.from_email or self._default_from or ""

        data: dict[str, str | list[str]] = {
            "from": from_addr,
            "to": message.to,
            "subject": message.subject,
            "text": message.body,
        }

        if message.html_body:
            data["html"] = message.html_body

        if message.cc:
            data["cc"] = message.cc

        if message.bcc:
            data["bcc"] = message.bcc

        if message.reply_to:
            data["h:Reply-To"] = message.reply_to

        for header_name, header_value in message.headers.items():
            data[f"h:{header_name}"] = header_value

        return data

    async def send(self, message: EmailMessage) -> bool:
        """Send an email via the Mailgun API.

        Args:
            message: The email message to send.

        Returns:
            True when the API returns a 2xx status code, False otherwise.
        """
        url = f"{self._api_base}/{self._domain}/messages"
        data = self._build_form_data(message)

        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                # Build files list for attachments
                files: list[tuple[str, tuple[str, bytes, str]]] = []
                for filename, file_data, mime_type in message.attachments:
                    files.append(("attachment", (filename, file_data, mime_type)))

                response = await client.post(
                    url,
                    auth=("api", self._api_key),
                    data=data,
                    files=files if files else None,
                )

            if response.is_success:
                resp_json = response.json()
                mailgun_id = resp_json.get("id", "unknown")
                logger.info(
                    "Mailgun email sent to %s (id=%s)",
                    message.to,
                    mailgun_id,
                )
                return True

            logger.error(
                "Mailgun API error: status=%d body=%s",
                response.status_code,
                response.text[:500],
            )
            return False
        except httpx.HTTPError:
            logger.exception("HTTP error sending email via Mailgun to %s", message.to)
            return False
        except Exception:
            logger.exception("Unexpected error sending email via Mailgun to %s", message.to)
            return False
