from __future__ import annotations

"""SendGrid email provider using the v3 Mail Send API via httpx.

Configuration is read from environment variables:
    - ``SENDGRID_API_KEY`` (required)
    - ``SENDGRID_DEFAULT_FROM`` (optional fallback sender address)
"""

import base64
import logging
import os

import httpx

from ..message import EmailMessage
from ..provider import EmailProvider

logger = logging.getLogger(__name__)

_SENDGRID_API_URL = "https://api.sendgrid.com/v3/mail/send"


class SendGridProvider(EmailProvider):
    """Send emails via the SendGrid v3 API.

    Args:
        api_key: SendGrid API key. Falls back to ``SENDGRID_API_KEY`` env var.
        default_from: Default sender email address.
    """

    def __init__(
        self,
        *,
        api_key: str | None = None,
        default_from: str | None = None,
    ) -> None:
        self._api_key = api_key or os.environ.get("SENDGRID_API_KEY", "")
        if not self._api_key:
            logger.warning("SENDGRID_API_KEY is not set; SendGridProvider will fail on send.")
        self._default_from = default_from or os.environ.get("SENDGRID_DEFAULT_FROM")

    def _build_payload(self, message: EmailMessage) -> dict:
        """Build the JSON payload for the SendGrid v3 ``/mail/send`` endpoint."""
        from_email = message.from_email or self._default_from or ""

        personalizations: dict = {
            "to": [{"email": addr} for addr in message.to],
        }
        if message.cc:
            personalizations["cc"] = [{"email": addr} for addr in message.cc]
        if message.bcc:
            personalizations["bcc"] = [{"email": addr} for addr in message.bcc]

        content: list[dict] = [{"type": "text/plain", "value": message.body}]
        if message.html_body:
            content.append({"type": "text/html", "value": message.html_body})

        payload: dict = {
            "personalizations": [personalizations],
            "from": {"email": from_email},
            "subject": message.subject,
            "content": content,
        }

        if message.reply_to:
            payload["reply_to"] = {"email": message.reply_to}

        if message.headers:
            payload["headers"] = message.headers

        if message.attachments:
            payload["attachments"] = [
                {
                    "filename": filename,
                    "content": base64.b64encode(data).decode("ascii"),
                    "type": mime_type,
                }
                for filename, data, mime_type in message.attachments
            ]

        return payload

    async def send(self, message: EmailMessage) -> bool:
        """Send an email via the SendGrid v3 API.

        Args:
            message: The email message to send.

        Returns:
            True when the API returns a 2xx status code, False otherwise.
        """
        payload = self._build_payload(message)
        headers = {
            "Authorization": f"Bearer {self._api_key}",
            "Content-Type": "application/json",
        }

        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                response = await client.post(
                    _SENDGRID_API_URL,
                    json=payload,
                    headers=headers,
                )

            if response.is_success:
                logger.info("SendGrid email sent to %s (status %d)", message.to, response.status_code)
                return True

            logger.error(
                "SendGrid API error: status=%d body=%s",
                response.status_code,
                response.text[:500],
            )
            return False
        except httpx.HTTPError:
            logger.exception("HTTP error sending email via SendGrid to %s", message.to)
            return False
        except Exception:
            logger.exception("Unexpected error sending email via SendGrid to %s", message.to)
            return False
