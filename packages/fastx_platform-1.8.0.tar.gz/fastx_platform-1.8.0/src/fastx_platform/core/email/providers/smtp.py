from __future__ import annotations

"""SMTP email provider using aiosmtplib.

Configuration is read from environment variables:
    - ``SMTP_HOST`` (default ``localhost``)
    - ``SMTP_PORT`` (default ``587``)
    - ``SMTP_USER`` (optional)
    - ``SMTP_PASSWORD`` (optional)
    - ``SMTP_USE_TLS`` (default ``true``)
    - ``SMTP_DEFAULT_FROM`` (optional fallback sender address)
"""

import logging
import os
from email.message import EmailMessage as StdlibEmailMessage
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.utils import formataddr

import aiosmtplib

from ..message import EmailMessage
from ..provider import EmailProvider

logger = logging.getLogger(__name__)


class SMTPProvider(EmailProvider):
    """Send emails via an SMTP relay using ``aiosmtplib``.

    All connection parameters can be overridden via constructor kwargs or
    read from environment variables.

    Args:
        host: SMTP server hostname.
        port: SMTP server port.
        username: SMTP authentication username.
        password: SMTP authentication password.
        use_tls: Whether to use STARTTLS.
        default_from: Default sender address if the message has none.
    """

    def __init__(
        self,
        *,
        host: str | None = None,
        port: int | None = None,
        username: str | None = None,
        password: str | None = None,
        use_tls: bool | None = None,
        default_from: str | None = None,
    ) -> None:
        self._host = host or os.environ.get("SMTP_HOST", "localhost")
        self._port = port if port is not None else int(os.environ.get("SMTP_PORT", "587"))
        self._username = username or os.environ.get("SMTP_USER")
        self._password = password or os.environ.get("SMTP_PASSWORD")
        if use_tls is not None:
            self._use_tls = use_tls
        else:
            self._use_tls = os.environ.get("SMTP_USE_TLS", "true").lower() in ("true", "1", "yes")
        self._default_from = default_from or os.environ.get("SMTP_DEFAULT_FROM")

    def _build_mime(self, message: EmailMessage) -> MIMEMultipart:
        """Build a MIME message from an :class:`EmailMessage`."""
        mime = MIMEMultipart("mixed")

        from_addr = message.from_email or self._default_from or ""
        mime["From"] = from_addr
        mime["To"] = ", ".join(message.to)
        mime["Subject"] = message.subject

        if message.cc:
            mime["Cc"] = ", ".join(message.cc)

        if message.reply_to:
            mime["Reply-To"] = message.reply_to

        for header_name, header_value in message.headers.items():
            mime[header_name] = header_value

        # Body (multipart/alternative when HTML is present)
        if message.html_body:
            alt = MIMEMultipart("alternative")
            alt.attach(MIMEText(message.body, "plain", "utf-8"))
            alt.attach(MIMEText(message.html_body, "html", "utf-8"))
            mime.attach(alt)
        else:
            mime.attach(MIMEText(message.body, "plain", "utf-8"))

        # Attachments
        for filename, data, mime_type in message.attachments:
            maintype, _, subtype = mime_type.partition("/")
            attachment = MIMEBase(maintype, subtype or "octet-stream")
            attachment.set_payload(data)
            from email import encoders

            encoders.encode_base64(attachment)
            attachment.add_header(
                "Content-Disposition",
                "attachment",
                filename=filename,
            )
            mime.attach(attachment)

        return mime

    async def send(self, message: EmailMessage) -> bool:
        """Send an email via SMTP.

        Args:
            message: The email message to send.

        Returns:
            True on successful delivery to the SMTP server, False on failure.
        """
        mime = self._build_mime(message)
        recipients = message.all_recipients

        try:
            smtp = aiosmtplib.SMTP(
                hostname=self._host,
                port=self._port,
                use_tls=False,
            )
            await smtp.connect()

            if self._use_tls:
                await smtp.starttls()

            if self._username and self._password:
                await smtp.login(self._username, self._password)

            await smtp.send_message(mime, recipients=recipients)
            await smtp.quit()

            logger.info("SMTP email sent to %s via %s:%d", recipients, self._host, self._port)
            return True
        except aiosmtplib.SMTPException:
            logger.exception("SMTP error sending email to %s", recipients)
            return False
        except Exception:
            logger.exception("Unexpected error sending SMTP email to %s", recipients)
            return False
