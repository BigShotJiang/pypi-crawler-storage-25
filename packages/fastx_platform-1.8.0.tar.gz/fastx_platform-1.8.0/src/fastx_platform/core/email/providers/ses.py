from __future__ import annotations

"""Amazon SES email provider using boto3.

Configuration is read from environment variables (or the default AWS
credential chain):
    - ``AWS_REGION`` (default ``us-east-1``)
    - ``AWS_ACCESS_KEY_ID`` (optional -- boto3 falls back to instance profile)
    - ``AWS_SECRET_ACCESS_KEY`` (optional)
    - ``SES_DEFAULT_FROM`` (optional fallback sender address)
"""

import logging
import os
from email import encoders
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from typing import Any

from ..message import EmailMessage
from ..provider import EmailProvider

logger = logging.getLogger(__name__)


class SESProvider(EmailProvider):
    """Send emails via Amazon Simple Email Service (SES).

    Uses ``boto3`` to interact with the SES ``send_raw_email`` API, which
    supports attachments and full MIME control.

    Args:
        region: AWS region for the SES endpoint.
        access_key_id: AWS access key ID (optional; uses default chain).
        secret_access_key: AWS secret access key (optional).
        default_from: Default sender address.
    """

    def __init__(
        self,
        *,
        region: str | None = None,
        access_key_id: str | None = None,
        secret_access_key: str | None = None,
        default_from: str | None = None,
    ) -> None:
        self._region = region or os.environ.get("AWS_REGION", "us-east-1")
        self._access_key_id = access_key_id or os.environ.get("AWS_ACCESS_KEY_ID")
        self._secret_access_key = secret_access_key or os.environ.get("AWS_SECRET_ACCESS_KEY")
        self._default_from = default_from or os.environ.get("SES_DEFAULT_FROM")
        self._client: Any = None

    def _get_client(self) -> Any:
        """Lazily create and cache the boto3 SES client."""
        if self._client is None:
            import boto3

            kwargs: dict[str, Any] = {"region_name": self._region}
            if self._access_key_id and self._secret_access_key:
                kwargs["aws_access_key_id"] = self._access_key_id
                kwargs["aws_secret_access_key"] = self._secret_access_key
            self._client = boto3.client("ses", **kwargs)
        return self._client

    def _build_raw_message(self, message: EmailMessage) -> str:
        """Build a raw MIME message string for ``send_raw_email``."""
        mime = MIMEMultipart("mixed")

        from_addr = message.from_email or self._default_from or ""
        mime["From"] = from_addr
        mime["To"] = ", ".join(message.to)
        mime["Subject"] = message.subject

        if message.cc:
            mime["Cc"] = ", ".join(message.cc)

        if message.reply_to:
            mime["Reply-To"] = message.reply_to

        for header_name, header_value in message.headers.items():
            mime[header_name] = header_value

        if message.html_body:
            alt = MIMEMultipart("alternative")
            alt.attach(MIMEText(message.body, "plain", "utf-8"))
            alt.attach(MIMEText(message.html_body, "html", "utf-8"))
            mime.attach(alt)
        else:
            mime.attach(MIMEText(message.body, "plain", "utf-8"))

        for filename, data, mime_type in message.attachments:
            maintype, _, subtype = mime_type.partition("/")
            attachment = MIMEBase(maintype, subtype or "octet-stream")
            attachment.set_payload(data)
            encoders.encode_base64(attachment)
            attachment.add_header(
                "Content-Disposition",
                "attachment",
                filename=filename,
            )
            mime.attach(attachment)

        return mime.as_string()

    async def send(self, message: EmailMessage) -> bool:
        """Send an email via Amazon SES.

        Uses ``send_raw_email`` to support full MIME messages with
        attachments. The boto3 call is synchronous; for truly non-blocking
        behaviour in high-throughput scenarios, consider wrapping with
        ``asyncio.to_thread``.

        Args:
            message: The email message to send.

        Returns:
            True on success, False on failure.
        """
        import asyncio

        raw = self._build_raw_message(message)
        from_addr = message.from_email or self._default_from or ""
        recipients = message.all_recipients

        try:
            client = self._get_client()
            response = await asyncio.to_thread(
                client.send_raw_email,
                Source=from_addr,
                Destinations=recipients,
                RawMessage={"Data": raw},
            )

            message_id = response.get("MessageId", "unknown")
            logger.info(
                "SES email sent to %s (MessageId=%s)",
                recipients,
                message_id,
            )
            return True
        except Exception:
            logger.exception("Failed to send email via SES to %s", recipients)
            return False
