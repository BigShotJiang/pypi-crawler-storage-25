from __future__ import annotations

"""Concrete email provider implementations.

Each provider adapts a third-party email service or protocol to the
:class:`~fastx_platform.core.email.provider.EmailProvider` interface.

Providers are lazily imported to avoid hard dependencies on third-party
libraries (aiosmtplib, boto3, httpx) unless actually used.
"""


def __getattr__(name: str):
    if name == "SMTPProvider":
        from .smtp import SMTPProvider
        return SMTPProvider
    if name == "SendGridProvider":
        from .sendgrid import SendGridProvider
        return SendGridProvider
    if name == "SESProvider":
        from .ses import SESProvider
        return SESProvider
    if name == "MailgunProvider":
        from .mailgun import MailgunProvider
        return MailgunProvider
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = [
    "MailgunProvider",
    "SendGridProvider",
    "SESProvider",
    "SMTPProvider",
]
