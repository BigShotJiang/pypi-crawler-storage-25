"""Object / blob storage configuration DTO."""

from __future__ import annotations

from pydantic import ConfigDict, Field

from .abstraction import IDTO
from .azure_storage import AzureBlobStorageDTO
from .gcs_storage import GCSStorageDTO
from .local_storage import LocalStorageDTO
from .s3_storage import S3StorageDTO


class StorageConfigurationDTO(IDTO):
    """Represents the StorageConfigurationDTO class."""

    model_config = ConfigDict(extra="ignore")
    default_backend: str = "gcs"
    s3: S3StorageDTO = Field(default_factory=S3StorageDTO)
    gcs: GCSStorageDTO = Field(default_factory=GCSStorageDTO)
    azure_blob: AzureBlobStorageDTO = Field(default_factory=AzureBlobStorageDTO)
    local: LocalStorageDTO = Field(default_factory=LocalStorageDTO)
