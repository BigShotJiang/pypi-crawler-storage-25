"""Azure Blob Storage subsection."""

from __future__ import annotations

from pydantic import ConfigDict

from .abstraction import IDTO


class AzureBlobStorageDTO(IDTO):
    """Azure Blob Storage configuration for the storage module."""

    model_config = ConfigDict(extra="ignore")
    enabled: bool = False
    container: str = ""
    connection_string: str = ""
    account_url: str = ""
    base_path: str = ""
