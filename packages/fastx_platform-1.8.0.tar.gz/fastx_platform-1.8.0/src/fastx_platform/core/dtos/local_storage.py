"""Local filesystem storage subsection."""

from __future__ import annotations

from pydantic import ConfigDict

from .abstraction import IDTO


class LocalStorageDTO(IDTO):
    """Local storage configuration for the storage module."""

    model_config = ConfigDict(extra="ignore")
    enabled: bool = False
    base_dir: str = "storage"
    base_url: str = ""
