"""Google Cloud Storage subsection."""

from __future__ import annotations

from pydantic import ConfigDict

from .abstraction import IDTO


class GCSStorageDTO(IDTO):
    """GCS configuration for the storage module."""

    model_config = ConfigDict(extra="ignore")
    enabled: bool = False
    bucket: str = ""
    credentials_json_path: str = ""
    base_path: str = ""
