from __future__ import annotations
"""API key data model."""

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any


@dataclass
class ApiKey:
    """Represents an API key with metadata and access controls.

    The ``key`` field stores the **SHA-256 hash** of the raw key string
    (prefix ``fxk_live_…``).  The plaintext key is returned to the caller
    exactly once — at creation time — and is never persisted.
    """

    key: str
    """SHA-256 hex-digest of the raw API key string."""

    name: str
    """Human-readable label (e.g. "CI pipeline – staging")."""

    tenant_id: str | None = None
    """Optional tenant/organisation this key belongs to."""

    scopes: list[str] = field(default_factory=list)
    """Granted scopes, e.g. ``["read", "write", "admin"]``."""

    rate_limit: int | None = None
    """Maximum requests per minute.  ``None`` means unlimited."""

    created_at: datetime = field(default_factory=datetime.utcnow)

    expires_at: datetime | None = None
    """When the key expires.  ``None`` means it never expires."""

    is_active: bool = True

    last_used_at: datetime | None = None

    metadata: dict[str, Any] = field(default_factory=dict)
    """Arbitrary user-defined metadata attached to the key."""
