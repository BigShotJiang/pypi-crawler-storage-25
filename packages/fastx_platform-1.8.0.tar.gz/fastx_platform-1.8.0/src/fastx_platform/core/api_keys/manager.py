from __future__ import annotations
"""High-level API key lifecycle management."""

import hashlib
import logging
import secrets
from dataclasses import replace
from datetime import datetime, timedelta
from typing import Any

from .backends import ApiKeyBackend
from .models import ApiKey

logger = logging.getLogger(__name__)

_KEY_PREFIX = "fxk_live_"


def _hash_key(raw_key: str) -> str:
    """Return the SHA-256 hex-digest of *raw_key*."""
    return hashlib.sha256(raw_key.encode()).hexdigest()


class ApiKeyManager:
    """Create, validate, revoke, rotate, and list API keys.

    All operations delegate persistence to the supplied
    :class:`~.backends.ApiKeyBackend`.
    """

    def __init__(self, backend: ApiKeyBackend) -> None:
        self._backend = backend

    # ------------------------------------------------------------------
    # Create
    # ------------------------------------------------------------------

    async def create_key(
        self,
        name: str,
        *,
        tenant_id: str | None = None,
        scopes: list[str] | None = None,
        rate_limit: int | None = None,
        expires_in_days: int | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> tuple[str, ApiKey]:
        """Generate a new API key and persist its hashed representation.

        Returns a ``(raw_key, api_key)`` tuple.  The *raw_key* is the
        plaintext secret (shown to the user exactly once); *api_key* contains
        the SHA-256 hash stored in the backend.
        """
        raw_key = f"{_KEY_PREFIX}{secrets.token_urlsafe(32)}"
        key_hash = _hash_key(raw_key)

        now = datetime.utcnow()
        expires_at = now + timedelta(days=expires_in_days) if expires_in_days else None

        api_key = ApiKey(
            key=key_hash,
            name=name,
            tenant_id=tenant_id,
            scopes=scopes or [],
            rate_limit=rate_limit,
            created_at=now,
            expires_at=expires_at,
            is_active=True,
            last_used_at=None,
            metadata=metadata or {},
        )

        await self._backend.store(api_key)
        logger.info("Created API key name=%s tenant=%s hash=%s", name, tenant_id, key_hash[:12])
        return raw_key, api_key

    # ------------------------------------------------------------------
    # Validate
    # ------------------------------------------------------------------

    async def validate_key(self, raw_key: str) -> ApiKey | None:
        """Validate a raw API key string.

        Returns the corresponding :class:`ApiKey` if the key exists, is
        active, and has not expired; otherwise returns ``None``.  A
        successful validation also updates ``last_used_at``.
        """
        key_hash = _hash_key(raw_key)
        api_key = await self._backend.get_by_hash(key_hash)
        if api_key is None:
            return None

        if not api_key.is_active:
            logger.debug("Rejected inactive key hash=%s", key_hash[:12])
            return None

        if api_key.expires_at is not None and datetime.utcnow() >= api_key.expires_at:
            logger.debug("Rejected expired key hash=%s", key_hash[:12])
            return None

        # Touch last_used_at
        updated = replace(api_key, last_used_at=datetime.utcnow())
        await self._backend.store(updated)
        return updated

    # ------------------------------------------------------------------
    # Revoke
    # ------------------------------------------------------------------

    async def revoke_key(self, raw_key: str) -> bool:
        """Revoke (deactivate) an API key.

        The key record is soft-deleted by setting ``is_active = False``
        so that audit history is preserved.  Returns ``True`` if the key
        existed and was revoked.
        """
        key_hash = _hash_key(raw_key)
        api_key = await self._backend.get_by_hash(key_hash)
        if api_key is None:
            return False

        revoked = replace(api_key, is_active=False)
        await self._backend.store(revoked)
        logger.info("Revoked API key hash=%s name=%s", key_hash[:12], api_key.name)
        return True

    # ------------------------------------------------------------------
    # List
    # ------------------------------------------------------------------

    async def list_keys(self, tenant_id: str | None = None) -> list[ApiKey]:
        """Return all keys, optionally filtered by *tenant_id*."""
        return await self._backend.list_all(tenant_id=tenant_id)

    # ------------------------------------------------------------------
    # Rotate
    # ------------------------------------------------------------------

    async def rotate_key(self, old_raw_key: str) -> tuple[str, ApiKey]:
        """Rotate an existing key: create a replacement and revoke the old one.

        The new key inherits the name, tenant, scopes, rate limit, and
        metadata of the old key.  Raises :class:`ValueError` if the old
        key cannot be found or is already inactive.
        """
        old_hash = _hash_key(old_raw_key)
        old_key = await self._backend.get_by_hash(old_hash)
        if old_key is None or not old_key.is_active:
            raise ValueError("Cannot rotate: original key not found or already revoked")

        # Determine remaining TTL (if any)
        expires_in_days: int | None = None
        if old_key.expires_at is not None:
            remaining = old_key.expires_at - datetime.utcnow()
            expires_in_days = max(int(remaining.total_seconds() / 86400), 1)

        new_raw_key, new_api_key = await self.create_key(
            name=old_key.name,
            tenant_id=old_key.tenant_id,
            scopes=old_key.scopes,
            rate_limit=old_key.rate_limit,
            expires_in_days=expires_in_days,
            metadata=old_key.metadata,
        )

        await self.revoke_key(old_raw_key)
        logger.info(
            "Rotated API key old_hash=%s -> new_hash=%s",
            old_hash[:12],
            new_api_key.key[:12],
        )
        return new_raw_key, new_api_key
