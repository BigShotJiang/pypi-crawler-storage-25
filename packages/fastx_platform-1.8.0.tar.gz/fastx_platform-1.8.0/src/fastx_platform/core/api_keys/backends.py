from __future__ import annotations
"""Pluggable storage backends for API key persistence."""

import json
import logging
from abc import ABC, abstractmethod
from datetime import datetime
from typing import Any

from .models import ApiKey

logger = logging.getLogger(__name__)


class ApiKeyBackend(ABC):
    """Abstract base class for API key storage."""

    @abstractmethod
    async def store(self, api_key: ApiKey) -> None:
        """Persist an :class:`ApiKey` (keyed by its hash)."""

    @abstractmethod
    async def get_by_hash(self, key_hash: str) -> ApiKey | None:
        """Retrieve an API key by its SHA-256 hash, or ``None``."""

    @abstractmethod
    async def delete(self, key_hash: str) -> bool:
        """Delete a key by hash.  Returns ``True`` if it existed."""

    @abstractmethod
    async def list_all(self, tenant_id: str | None = None) -> list[ApiKey]:
        """Return all keys, optionally filtered by *tenant_id*."""


# ---------------------------------------------------------------------------
# In-memory backend (development / testing)
# ---------------------------------------------------------------------------

class InMemoryApiKeyBackend(ApiKeyBackend):
    """Dictionary-backed backend — useful for tests and local development."""

    def __init__(self) -> None:
        self._store: dict[str, ApiKey] = {}

    async def store(self, api_key: ApiKey) -> None:
        self._store[api_key.key] = api_key
        logger.debug("Stored API key hash=%s name=%s", api_key.key[:12], api_key.name)

    async def get_by_hash(self, key_hash: str) -> ApiKey | None:
        return self._store.get(key_hash)

    async def delete(self, key_hash: str) -> bool:
        try:
            del self._store[key_hash]
            return True
        except KeyError:
            return False

    async def list_all(self, tenant_id: str | None = None) -> list[ApiKey]:
        keys = list(self._store.values())
        if tenant_id is not None:
            keys = [k for k in keys if k.tenant_id == tenant_id]
        return keys


# ---------------------------------------------------------------------------
# Redis backend
# ---------------------------------------------------------------------------

def _serialize_api_key(api_key: ApiKey) -> dict[str, str]:
    """Flatten an :class:`ApiKey` into a Redis-friendly string mapping."""
    return {
        "key": api_key.key,
        "name": api_key.name,
        "tenant_id": api_key.tenant_id or "",
        "scopes": json.dumps(api_key.scopes),
        "rate_limit": str(api_key.rate_limit) if api_key.rate_limit is not None else "",
        "created_at": api_key.created_at.isoformat(),
        "expires_at": api_key.expires_at.isoformat() if api_key.expires_at else "",
        "is_active": "1" if api_key.is_active else "0",
        "last_used_at": api_key.last_used_at.isoformat() if api_key.last_used_at else "",
        "metadata": json.dumps(api_key.metadata),
    }


def _deserialize_api_key(data: dict[str, str]) -> ApiKey:
    """Reconstruct an :class:`ApiKey` from a Redis hash mapping."""
    return ApiKey(
        key=data["key"],
        name=data["name"],
        tenant_id=data["tenant_id"] or None,
        scopes=json.loads(data.get("scopes", "[]")),
        rate_limit=int(data["rate_limit"]) if data.get("rate_limit") else None,
        created_at=datetime.fromisoformat(data["created_at"]),
        expires_at=datetime.fromisoformat(data["expires_at"]) if data.get("expires_at") else None,
        is_active=data.get("is_active", "1") == "1",
        last_used_at=datetime.fromisoformat(data["last_used_at"]) if data.get("last_used_at") else None,
        metadata=json.loads(data.get("metadata", "{}")),
    )


class RedisApiKeyBackend(ApiKeyBackend):
    """Redis hash-based backend with optional TTL support.

    Parameters
    ----------
    redis:
        An ``aioredis``/``redis.asyncio`` client instance.
    prefix:
        Key prefix used in Redis (default ``"fastx:api_key:"``).
    """

    def __init__(self, redis: Any, *, prefix: str = "fastx:api_key:") -> None:
        self._redis = redis
        self._prefix = prefix

    def _redis_key(self, key_hash: str) -> str:
        return f"{self._prefix}{key_hash}"

    async def store(self, api_key: ApiKey) -> None:
        rkey = self._redis_key(api_key.key)
        mapping = _serialize_api_key(api_key)
        await self._redis.hset(rkey, mapping=mapping)

        # Set TTL when the key has an expiry
        if api_key.expires_at is not None:
            ttl_seconds = int((api_key.expires_at - datetime.utcnow()).total_seconds())
            if ttl_seconds > 0:
                await self._redis.expire(rkey, ttl_seconds)

        logger.debug("Redis: stored API key hash=%s name=%s", api_key.key[:12], api_key.name)

    async def get_by_hash(self, key_hash: str) -> ApiKey | None:
        data: dict[bytes | str, bytes | str] = await self._redis.hgetall(self._redis_key(key_hash))
        if not data:
            return None
        # Redis may return bytes — normalise to str.
        str_data: dict[str, str] = {
            (k.decode() if isinstance(k, bytes) else k): (v.decode() if isinstance(v, bytes) else v)
            for k, v in data.items()
        }
        return _deserialize_api_key(str_data)

    async def delete(self, key_hash: str) -> bool:
        result = await self._redis.delete(self._redis_key(key_hash))
        return bool(result)

    async def list_all(self, tenant_id: str | None = None) -> list[ApiKey]:
        keys: list[ApiKey] = []
        async for rkey in self._redis.scan_iter(match=f"{self._prefix}*"):
            data = await self._redis.hgetall(rkey)
            if not data:
                continue
            str_data = {
                (k.decode() if isinstance(k, bytes) else k): (v.decode() if isinstance(v, bytes) else v)
                for k, v in data.items()
            }
            api_key = _deserialize_api_key(str_data)
            if tenant_id is None or api_key.tenant_id == tenant_id:
                keys.append(api_key)
        return keys
