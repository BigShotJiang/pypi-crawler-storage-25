from __future__ import annotations
"""FastAPI middleware for API key authentication, scope checking, and rate limiting."""

import logging
import time
from collections import defaultdict
from typing import Any, Sequence

from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware, RequestResponseEndpoint
from starlette.responses import JSONResponse

from .manager import ApiKeyManager
from .models import ApiKey

logger = logging.getLogger(__name__)

_HEADER_NAME = "X-API-Key"
_QUERY_PARAM = "api_key"


class _RateCounter:
    """Simple sliding-window rate counter (per key hash)."""

    def __init__(self) -> None:
        # key_hash -> list of request timestamps
        self._windows: dict[str, list[float]] = defaultdict(list)

    def is_allowed(self, key_hash: str, limit: int, window_seconds: int = 60) -> bool:
        """Return ``True`` if the key has not exceeded *limit* requests
        in the last *window_seconds*.
        """
        now = time.monotonic()
        cutoff = now - window_seconds
        timestamps = self._windows[key_hash]

        # Prune expired entries
        self._windows[key_hash] = timestamps = [t for t in timestamps if t > cutoff]

        if len(timestamps) >= limit:
            return False

        timestamps.append(now)
        return True


class ApiKeyMiddleware(BaseHTTPMiddleware):
    """Authenticate incoming requests via API key.

    The middleware looks for a key in the ``X-API-Key`` header first, then
    falls back to the ``api_key`` query parameter.

    Parameters
    ----------
    app:
        The ASGI application (injected by Starlette/FastAPI).
    manager:
        An :class:`~.manager.ApiKeyManager` instance used for validation.
    required_scopes:
        If provided, every request must carry a key that has **all** of
        these scopes.  Pass an empty sequence to skip scope enforcement.
    exempt_paths:
        URL paths that bypass authentication entirely (e.g.
        ``["/health", "/docs", "/openapi.json"]``).
    """

    def __init__(
        self,
        app: Any,
        *,
        manager: ApiKeyManager,
        required_scopes: Sequence[str] = (),
        exempt_paths: Sequence[str] = ("/health", "/docs", "/openapi.json", "/redoc"),
    ) -> None:
        super().__init__(app)
        self._manager = manager
        self._required_scopes = set(required_scopes)
        self._exempt_paths = set(exempt_paths)
        self._rate_counter = _RateCounter()

    # ------------------------------------------------------------------
    # Request handler
    # ------------------------------------------------------------------

    async def dispatch(self, request: Request, call_next: RequestResponseEndpoint) -> Response:
        # Skip exempt paths
        if request.url.path in self._exempt_paths:
            return await call_next(request)

        # --- Extract key ---------------------------------------------------
        raw_key = request.headers.get(_HEADER_NAME)
        if raw_key is None:
            raw_key = request.query_params.get(_QUERY_PARAM)

        if raw_key is None:
            logger.debug("No API key provided for %s %s", request.method, request.url.path)
            return JSONResponse(
                status_code=401,
                content={"detail": "API key required. Provide via X-API-Key header or api_key query parameter."},
            )

        # --- Validate key --------------------------------------------------
        api_key: ApiKey | None = await self._manager.validate_key(raw_key)
        if api_key is None:
            logger.warning("Invalid or expired API key for %s %s", request.method, request.url.path)
            return JSONResponse(
                status_code=401,
                content={"detail": "Invalid or expired API key."},
            )

        # --- Check scopes --------------------------------------------------
        if self._required_scopes:
            granted = set(api_key.scopes)
            missing = self._required_scopes - granted
            if missing:
                logger.warning(
                    "Insufficient scopes for key hash=%s: missing %s",
                    api_key.key[:12],
                    missing,
                )
                return JSONResponse(
                    status_code=403,
                    content={
                        "detail": "Insufficient scopes.",
                        "required": sorted(self._required_scopes),
                        "missing": sorted(missing),
                    },
                )

        # --- Rate limiting -------------------------------------------------
        if api_key.rate_limit is not None:
            if not self._rate_counter.is_allowed(api_key.key, api_key.rate_limit):
                logger.warning("Rate limit exceeded for key hash=%s", api_key.key[:12])
                return JSONResponse(
                    status_code=429,
                    content={"detail": "Rate limit exceeded. Please try again later."},
                    headers={"Retry-After": "60"},
                )

        # --- Inject into request state -------------------------------------
        request.state.api_key = api_key

        return await call_next(request)
