"""Taxonomy section package (see :mod:`fastx_platform.taxonomy`)."""

from .abstraction import ISec

__all__ = ["ISec"]
