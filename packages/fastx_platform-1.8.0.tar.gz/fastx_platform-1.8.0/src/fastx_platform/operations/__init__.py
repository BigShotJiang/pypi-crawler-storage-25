"""Taxonomy section package (see :mod:`fastx_platform.taxonomy`)."""

from .abstraction import IOperations

__all__ = ["IOperations"]
