"""Taxonomy section package (see :mod:`fastx_platform.taxonomy`)."""

from .abstraction import IMessaging

__all__ = ["IMessaging"]
