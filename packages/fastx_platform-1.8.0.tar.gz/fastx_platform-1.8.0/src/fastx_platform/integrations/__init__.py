"""Taxonomy section package (see :mod:`fastx_platform.taxonomy`)."""

from .abstraction import IIntegrations

__all__ = ["IIntegrations"]
