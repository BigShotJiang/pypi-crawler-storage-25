"""Compatibility layer for fastx_platform.errors."""

from .core.errors import *
