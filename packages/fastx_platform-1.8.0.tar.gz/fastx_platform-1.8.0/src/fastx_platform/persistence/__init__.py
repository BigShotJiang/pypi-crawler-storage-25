"""Taxonomy section package (see :mod:`fastx_platform.taxonomy`)."""

from .abstraction import IPersistence

__all__ = ["IPersistence"]
