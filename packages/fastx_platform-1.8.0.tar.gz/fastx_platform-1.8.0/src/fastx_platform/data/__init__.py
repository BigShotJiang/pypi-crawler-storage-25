"""Taxonomy section package (see :mod:`fastx_platform.taxonomy`)."""

from .abstraction import IDataPlatform

__all__ = ["IDataPlatform"]
