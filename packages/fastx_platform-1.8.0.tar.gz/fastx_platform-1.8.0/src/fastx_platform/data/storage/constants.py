from typing import Final

S3_BACKEND: Final[str] = "s3"
GCS_BACKEND: Final[str] = "gcs"
AZURE_BLOB_BACKEND: Final[str] = "azure_blob"
LOCAL_BACKEND: Final[str] = "local"
MEMORY_URL_PREFIX: Final[str] = "memory://"
