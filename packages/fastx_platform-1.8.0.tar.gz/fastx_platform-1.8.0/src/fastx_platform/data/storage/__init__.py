"""fast_storage – Object storage (S3, GCS, Azure Blob, local) for FastMVC."""

from fastx_platform import StorageConfiguration, StorageConfigurationDTO

from .base import IStorageBackend, StorageObjectHead, build_storage_backend
from .constants import (
    AZURE_BLOB_BACKEND,
    GCS_BACKEND,
    LOCAL_BACKEND,
    S3_BACKEND,
)
from .local_backend import LocalStorageBackend
from .multipart import multipart_upload_large_file

__version__ = "0.3.0"

__all__ = [
    "AZURE_BLOB_BACKEND",
    "GCS_BACKEND",
    "IStorageBackend",
    "LOCAL_BACKEND",
    "LocalStorageBackend",
    "S3_BACKEND",
    "StorageConfiguration",
    "StorageConfigurationDTO",
    "StorageObjectHead",
    "build_storage_backend",
    "multipart_upload_large_file",
]
