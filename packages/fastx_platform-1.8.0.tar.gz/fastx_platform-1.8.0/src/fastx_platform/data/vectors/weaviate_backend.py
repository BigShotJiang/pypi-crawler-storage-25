"""Weaviate vector store backend."""

from __future__ import annotations

from .constants import WEAVIATE_BACKEND
from ...core.constants import DEFAULT_HOST
from typing import Any, List, Optional

from .base import IVectorStore


class WeaviateVectorStore(IVectorStore):
    """Weaviate client wrapper."""

    name = WEAVIATE_BACKEND

    def __init__(self, url: str = "http://localhost:8080", api_key: Optional[str] = None) -> None:
        """Execute __init__ operation.

        Args:
            url: The url parameter.
            api_key: The api_key parameter.
        """
        try:
            import weaviate
        except ImportError as e:
            raise RuntimeError(
                "weaviate-client required. Install: pip install fast_vectors[weaviate]"
            ) from e
        from urllib.parse import urlparse

        parsed = urlparse(url)
        host = parsed.hostname or DEFAULT_HOST
        port = parsed.port or (443 if parsed.scheme == "https" else 8080)
        if api_key:
            self._client = weaviate.connect_to_weaviate_cloud(
                cluster_url=url.replace("https://", "").replace("http://", "").split(":")[0],
                auth_credentials=weaviate.auth.AuthApiKey(api_key),
            )
        else:
            self._client = weaviate.connect_to_local(host=host, port=port, grpc_port=50051)

    def upsert(
        self, index_name: str, vectors: List[tuple[str, List[float], Optional[dict[str, Any]]]]
    ) -> None:
        """Execute upsert operation.

        Args:
            index_name: The index_name parameter.
            vectors: The vectors parameter.

        Returns:
            The result of the operation.
        """
        with self._client.collections.get(index_name).batch.dynamic() as batch:
            for vid, vec, meta in vectors:
                batch.add_object(properties=meta or {}, vector=vec)

    def query(
        self,
        index_name: str,
        vector: List[float],
        *,
        top_k: int = 10,
        filter: Optional[dict[str, Any]] = None,
    ) -> List[tuple[str, float, Optional[dict[str, Any]]]]:
        """Execute query operation.

        Args:
            index_name: The index_name parameter.
            vector: The vector parameter.
            top_k: The top_k parameter.
            filter: The filter parameter.

        Returns:
            The result of the operation.
        """
        coll = self._client.collections.get(index_name)
        r = coll.query.near_vector(near_vector=vector, limit=top_k)
        return [(str(o.uuid), o.metadata.distance or 0.0, dict(o.properties)) for o in r.objects]

    def delete_index(self, index_name: str) -> None:
        """Execute delete_index operation.

        Args:
            index_name: The index_name parameter.

        Returns:
            The result of the operation.
        """
        self._client.collections.delete(index_name)
