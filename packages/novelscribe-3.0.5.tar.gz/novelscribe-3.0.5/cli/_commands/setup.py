"""Setup commands for first-time configuration."""

import logging
import os
import sys
from pathlib import Path

import click

from cli._helpers.error_handling import handle_cli_exception
from core.language_config import LanguageCode, LanguageResolver
from services.global_settings import (
    _PROVIDER_DEFAULT_URLS,
    GlobalSettings,
    get_default_model,
)

PROVIDER_ENV_MAP = {
    "openai": ("OPENAI_API_KEY", None),
    "anthropic": ("ANTHROPIC_API_KEY", None),
    "google": ("GOOGLE_API_KEY", None),
    "minimax": ("MINIMAX_API_KEY", "MINIMAX_BASE_URL"),
    "zhipu": ("ZHIPUAI_API_KEY", "ZHIPUAI_BASE_URL"),
    "moonshot": ("MOONSHOT_API_KEY", "MOONSHOT_BASE_URL"),
    "ollama": (None, "OLLAMA_BASE_URL"),
    "lm-studio": (None, "LM_STUDIO_BASE_URL"),
}


def _canonicalize_provider(provider: str) -> str:
    normalized = (provider or "").strip().lower()
    if normalized in {"lm-studio", "lmstudio"}:
        return "lm_studio"
    return normalized


def _get_default_url(provider: str) -> str | None:
    """Get default base URL for a provider."""
    canonical = _canonicalize_provider(provider)
    return _PROVIDER_DEFAULT_URLS.get(canonical)


@click.group()
def setup():
    """First-time setup and configuration commands."""
    pass


@setup.command()
@click.pass_context
def interactive(ctx: click.Context):
    """Run interactive setup wizard."""
    logger = logging.getLogger("scribe")

    try:
        from setup_wizard import SetupWizard

        wizard = SetupWizard()
        wizard.run()
    except ImportError:
        logger.error("Setup wizard not available. Please install inquirer3:")
        logger.error("  uv add inquirer3")
        sys.exit(1)
    except Exception as e:
        handle_cli_exception(
            logger,
            f"Setup failed: {e}",
            e,
            debug=(ctx.obj or {}).get("debug", False),
        )


@setup.command()
@click.argument(
    "provider",
    type=click.Choice(sorted(PROVIDER_ENV_MAP.keys())),
)
@click.argument("api_key", required=False, default="")
@click.option("--base-url", default="", help="Custom base URL for the provider.")
@click.option(
    "--model",
    default="",
    help="Default model for this provider (used by `scribe new` when omitted).",
)
@click.pass_context
def apikey(ctx: click.Context, provider: str, api_key: str, base_url: str, model: str):
    """Configure LLM provider API key and endpoint.

    \b
    Cloud providers (require API key):
      scribe setup apikey openai sk-...
      scribe setup apikey anthropic sk-ant-...
      scribe setup apikey google YOUR_GOOGLE_API_KEY
      scribe setup apikey minimax YOUR_MINIMAX_KEY
      scribe setup apikey zhipu YOUR_ZHIPU_KEY
      scribe setup apikey moonshot YOUR_MOONSHOT_KEY

    \b
    Local providers (no key, optional base URL):
      scribe setup apikey ollama
      scribe setup apikey ollama --base-url http://localhost:11434
      scribe setup apikey lm-studio
      scribe setup apikey lm-studio --base-url http://localhost:1234/v1

    \b
    Custom endpoints:
      scribe setup apikey openai sk-... --base-url https://your-proxy/v1
      scribe setup apikey minimax YOUR_KEY --base-url https://your-proxy/v1
    """
    logger = logging.getLogger("scribe")

    env_key, env_base_url_key = PROVIDER_ENV_MAP[provider]
    canonical_provider = _canonicalize_provider(provider)

    if env_key:
        if not api_key:
            logger.error(f"API key is required for {provider}.")
            logger.error(f"Usage: scribe setup apikey {provider} <YOUR_API_KEY>")
            sys.exit(1)
        if provider == "openai" and not api_key.startswith("sk-"):
            logger.error("Invalid OpenAI API key format. Must start with 'sk-'")
            sys.exit(1)
        elif provider == "anthropic" and not api_key.startswith("sk-ant-"):
            logger.error("Invalid Anthropic API key format. Must start with 'sk-ant-'")
            sys.exit(1)
        elif provider == "google" and (len(api_key) != 32 or not api_key.isalnum()):
            logger.error("Invalid Google API key format. Must be 32 alphanumeric characters")
            sys.exit(1)
        os.environ[env_key] = api_key
        logger.info(f"✅ API key set: {env_key}")
    else:
        if api_key:
            logger.warning(f"{provider} does not require an API key. Ignoring provided key.")

    if base_url:
        if env_base_url_key:
            os.environ[env_base_url_key] = base_url
            logger.info(f"✅ Base URL set: {env_base_url_key}={base_url}")
        else:
            logger.warning(f"{provider} does not support custom base URL.")
    elif env_base_url_key and not base_url:
        default_url = _get_default_url(provider)
        if default_url:
            os.environ[env_base_url_key] = default_url
            logger.info(f"✅ Default base URL: {env_base_url_key}={default_url}")

    resolved_model = model.strip() if model.strip() else get_default_model(canonical_provider)

    gs = GlobalSettings.load()
    gs.configure_provider(
        canonical_provider,
        model=resolved_model,
        base_url=base_url if base_url else _get_default_url(provider),
        set_as_default=True,
    )

    logger.info(f"✅ {provider} configured as default provider")
    logger.info(f"   Provider: {canonical_provider}")
    logger.info(f"   Model: {resolved_model}")
    if base_url:
        logger.info(f"   Base URL: {base_url}")
    logger.info(f"   Config saved to: {gs.config_path()}")


@setup.command()
@click.argument("language", type=click.Choice(["en", "zh-CN", "zh-TW"]))
@click.pass_context
def language(ctx: click.Context, language: str):
    """Configure default language.

    Examples:
        scribe setup language en
        scribe setup language zh-CN
        scribe setup language zh-TW
    """
    logger = logging.getLogger("scribe")

    try:
        resolver = LanguageResolver()
        config = resolver.get_config()
        config.default_language = LanguageCode(language)
        resolver.save_config(config)

        gs = GlobalSettings.load()
        gs.language = language
        gs.save()

        logger.info(f"✅ Default language set to: {language}")
        logger.info(f"   Config saved to: {gs.config_path()}")
        logger.info("")
        logger.info("This language will be used for all new projects.")
        logger.info("Use '--lang <code>' to override for individual commands.")

    except Exception as e:
        handle_cli_exception(
            logger,
            f"Failed to set language: {e}",
            e,
            debug=(ctx.obj or {}).get("debug", False),
        )


@setup.command()
@click.pass_context
def install_skill(ctx: click.Context):
    """Install chatbot skill for IDE integration."""
    logger = logging.getLogger("scribe")

    try:
        import shutil

        install_dir = Path(__file__).parent
        skill_file = install_dir / "novel_harness_skill.skill"
        trae_skills_dir = Path.home() / ".trae" / "skills"

        if not skill_file.exists():
            logger.error(f"Skill file not found: {skill_file}")
            logger.info(
                "Make sure you're running this from the Novel Harness installation directory."
            )
            sys.exit(1)

        if not trae_skills_dir.exists():
            logger.error(f"Trae skills directory not found: {trae_skills_dir}")
            logger.info("Make sure Trae is installed.")
            logger.info("You can manually copy the skill file:")
            logger.info(f"  cp {skill_file} ~/.trae/skills/")
            sys.exit(1)

        shutil.copy(skill_file, trae_skills_dir / "novel-harness.skill")

        logger.info("✅ Chatbot skill installed successfully")
        logger.info(f"   Skill file copied to: {trae_skills_dir}")
        logger.info("")
        logger.info("You can now use Novel Harness from VS Code Copilot/Trae:")
        logger.info('  "Create a science fiction novel called Mars Colony"')
        logger.info('  "Start autonomous generation"')
        logger.info('  "Check the status"')

    except Exception as e:
        handle_cli_exception(
            logger,
            f"Failed to install skill: {e}",
            e,
            debug=(ctx.obj or {}).get("debug", False),
        )


@setup.command()
@click.pass_context
def verify(ctx: click.Context):
    """Verify installation and configuration."""
    import importlib.util

    logger = logging.getLogger("scribe")

    logger.info("Verifying Novel Harness installation...")
    logger.info("")

    issues = []

    if sys.version_info < (3, 10):
        issues.append("❌ Python 3.10+ required, found " + sys.version)
    else:
        py_version = f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
        logger.info(f"✅ Python version: {py_version}")

    logger.info("✅ CLI command: scribe")

    try:
        importlib.util.find_spec("click")
        importlib.util.find_spec("yaml")

        logger.info("✅ Core dependencies installed")
    except ImportError as e:
        issues.append(f"❌ Missing dependency: {e}")

    configured = []
    for pname, (env_key, _env_base_url_key) in PROVIDER_ENV_MAP.items():
        if env_key and os.getenv(env_key):
            configured.append(pname)
    if configured:
        logger.info(f"✅ LLM providers configured: {', '.join(configured)}")
    else:
        issues.append("⚠️  No LLM provider configured. Run: scribe setup apikey <provider> <key>")

    gs = GlobalSettings.load()
    config_dir = gs.config_dir()
    if config_dir.exists():
        logger.info(f"✅ Global config directory: {config_dir}")
        if gs.default_provider and gs.default_model:
            logger.info(f"✅ Default provider: {gs.default_provider}")
            logger.info(f"✅ Default model: {gs.default_model}")
    else:
        issues.append("⚠️  Global config directory not found. Will be created on first use.")

    install_dir = Path(__file__).parent
    skill_file = install_dir / "novel_harness_skill.skill"
    if skill_file.exists():
        logger.info("✅ Chatbot skill file present")
    else:
        issues.append("⚠️  Chatbot skill file not found")

    logger.info("")

    if issues:
        logger.warning("Found issues that need attention:")
        for issue in issues:
            logger.warning(issue)
        logger.info("")
        logger.info("Run 'scribe setup apikey <provider> <key>' to configure.")
    else:
        logger.info("🎉 Everything looks good! You're ready to write novels.")
