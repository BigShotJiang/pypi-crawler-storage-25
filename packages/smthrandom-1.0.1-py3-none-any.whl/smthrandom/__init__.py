# smthrandom/__init__.py

from .core import greet, funfact, rotate, spin

print("wheee")
spin(cycles=6)
