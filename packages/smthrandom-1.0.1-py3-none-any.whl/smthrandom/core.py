import random
import time
import rotatescreen as rs

def funfact():
    facts = [
        "Did you know? This package does absolutely nothing!",
        "You just wasted 5 minutes of your life that you'll never get back",
        "Congrats! You've found the most useless package on PyPI."
    ]
    return random.choice(facts)

def greet():
    return "Hello from a completely useless package!"

def rotate(angle: int):
    sc=rs.get_primary_display()
    sc.rotate_to(angle)

def spin(interval:int=1, cycles:int=20):
    sc=rs.get_primary_display()
    for i in range(1,cycles+1):
        time.sleep(interval)
        sc.rotate_to((90*i)%360)
