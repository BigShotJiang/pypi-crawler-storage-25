"""Local HTTP proxy that sits between Claude Code / Codex and the
upstream LLM provider.

Routing
- POST /v1/messages              → forwards to anthropic_upstream/v1/messages
- POST /v1/chat/completions      → forwards to openai_upstream/v1/chat/completions
- POST /v1/responses             → forwards to openai_upstream/v1/responses

Auth: the Authorization header (and any other header) is forwarded
unchanged. This means the user's existing OAuth token (Claude Code
subscription) or API key (Codex / BYO Anthropic) flows through without
the proxy ever inspecting or storing it.

Compression: before forwarding, the request body is rewritten by
compressor.compress() — Tier 1 dedup + truncate. The original body is
never sent if the rewrite produces savings; if it doesn't, the original
is forwarded untouched.

Telemetry: after the response completes, a small metric record is
fire-and-forget'd to api.mintoken.dev/v1/cli-telemetry so the user's
dashboard at mintoken.dev/dashboard reflects the savings.

Streaming: SSE responses are streamed chunk-by-chunk back to the client
without any buffering, so latency is identical to talking to the
upstream directly.
"""

from __future__ import annotations

import json
import logging
import time
from typing import Any

import httpx
from fastapi import FastAPI, Request, Response
from fastapi.responses import JSONResponse, StreamingResponse

from .compressor import compress, CompressionMetrics
from .telemetry import fire as fire_telemetry

logger = logging.getLogger("mintoken_cli.proxy")


# --- Config injected at app build time ------------------------------------

class ProxyConfig:
    def __init__(
        self,
        *,
        mintoken_key: str = "",
        anthropic_upstream: str = "https://api.anthropic.com",
        openai_upstream: str = "https://api.openai.com",
        level: str = "standard",
        forward_timeout_s: float = 600.0,
    ):
        self.mintoken_key = mintoken_key
        self.anthropic_upstream = anthropic_upstream.rstrip("/")
        self.openai_upstream = openai_upstream.rstrip("/")
        self.level = level
        self.forward_timeout_s = forward_timeout_s


# --- Headers we strip before forwarding ----------------------------------

# Hop-by-hop headers + headers the upstream will set itself / that
# would confuse it.
_STRIP_REQUEST_HEADERS = {
    "host",
    "content-length",
    "transfer-encoding",
    "connection",
    "keep-alive",
    "proxy-authorization",
    "proxy-authenticate",
    "te",
    "trailer",
    "upgrade",
}

_STRIP_RESPONSE_HEADERS = {
    "content-length",
    "transfer-encoding",
    "connection",
    "keep-alive",
}


def _filter_request_headers(headers: dict[str, str]) -> dict[str, str]:
    return {k: v for k, v in headers.items() if k.lower() not in _STRIP_REQUEST_HEADERS}


def _filter_response_headers(headers: dict[str, str]) -> dict[str, str]:
    return {k: v for k, v in headers.items() if k.lower() not in _STRIP_RESPONSE_HEADERS}


# --- App factory ---------------------------------------------------------

def build_app(cfg: ProxyConfig) -> FastAPI:
    app = FastAPI(title="mintoken-cli local proxy", docs_url=None, redoc_url=None)

    @app.get("/")
    async def root():
        return {
            "service": "mintoken-cli",
            "level": cfg.level,
            "telemetry_enabled": bool(cfg.mintoken_key),
            "upstreams": {
                "anthropic": cfg.anthropic_upstream,
                "openai": cfg.openai_upstream,
            },
        }

    @app.get("/health")
    async def health():
        return {"status": "ok"}

    @app.post("/v1/messages")
    async def anthropic_messages(request: Request):
        return await _proxy_request(
            request, cfg,
            upstream_base=cfg.anthropic_upstream,
            upstream_path="/v1/messages",
            shape="anthropic",
            endpoint_label="messages",
        )

    @app.post("/v1/chat/completions")
    async def openai_chat(request: Request):
        return await _proxy_request(
            request, cfg,
            upstream_base=cfg.openai_upstream,
            upstream_path="/v1/chat/completions",
            shape="openai",
            endpoint_label="chat-completions",
        )

    @app.post("/v1/responses")
    async def openai_responses(request: Request):
        return await _proxy_request(
            request, cfg,
            upstream_base=cfg.openai_upstream,
            upstream_path="/v1/responses",
            shape="openai",
            endpoint_label="responses",
        )

    return app


# --- Core forward logic --------------------------------------------------

async def _proxy_request(
    request: Request,
    cfg: ProxyConfig,
    *,
    upstream_base: str,
    upstream_path: str,
    shape: str,
    endpoint_label: str,
) -> Response:
    raw_body = await request.body()
    try:
        body = json.loads(raw_body) if raw_body else {}
    except json.JSONDecodeError:
        # Forward as-is — we can't compress what we can't parse.
        return await _forward_passthrough(
            request, raw_body, cfg, upstream_base, upstream_path, shape, endpoint_label
        )

    # Compress
    new_body, metrics = compress(body, shape=shape, level=cfg.level)
    forward_payload = json.dumps(new_body).encode("utf-8")

    # Build upstream request
    upstream_url = f"{upstream_base}{upstream_path}"
    headers = _filter_request_headers(dict(request.headers))
    headers["content-type"] = "application/json"

    is_streaming = bool(body.get("stream"))
    start = time.time()

    if is_streaming:
        return await _forward_streaming(
            upstream_url, headers, forward_payload, cfg, metrics,
            shape, endpoint_label, body, start,
        )
    return await _forward_buffered(
        upstream_url, headers, forward_payload, cfg, metrics,
        shape, endpoint_label, body, start,
    )


async def _forward_buffered(
    url: str,
    headers: dict[str, str],
    payload: bytes,
    cfg: ProxyConfig,
    metrics: CompressionMetrics,
    shape: str,
    endpoint_label: str,
    original_body: dict,
    start_time: float,
) -> Response:
    try:
        async with httpx.AsyncClient(timeout=cfg.forward_timeout_s) as client:
            r = await client.post(url, headers=headers, content=payload)
    except Exception as e:
        logger.error("forward failed: %s", e)
        return JSONResponse(
            status_code=502,
            content={"error": f"mintoken-cli upstream error: {e}"},
        )

    duration_ms = int((time.time() - start_time) * 1000)
    response_headers = _filter_response_headers(dict(r.headers))

    # Add visibility headers so the client can see compression engaged.
    response_headers["x-mintoken-cli-tokens-before"] = str(metrics.tokens_before)
    response_headers["x-mintoken-cli-tokens-after"] = str(metrics.tokens_after)
    response_headers["x-mintoken-cli-tokens-saved"] = str(metrics.tokens_saved)
    if metrics.skipped_reason:
        response_headers["x-mintoken-cli-skipped"] = metrics.skipped_reason

    # Telemetry fire-and-forget.
    try:
        body_json = r.json() if r.headers.get("content-type", "").startswith("application/json") else {}
    except Exception:
        body_json = {}
    _fire(
        cfg, original_body, body_json, metrics,
        shape, endpoint_label, duration_ms, streamed=False,
    )

    return Response(
        content=r.content,
        status_code=r.status_code,
        headers=response_headers,
        media_type=r.headers.get("content-type"),
    )


async def _forward_streaming(
    url: str,
    headers: dict[str, str],
    payload: bytes,
    cfg: ProxyConfig,
    metrics: CompressionMetrics,
    shape: str,
    endpoint_label: str,
    original_body: dict,
    start_time: float,
) -> StreamingResponse:
    # We capture usage events as they stream through so we can record
    # input/output token counts in telemetry without re-reading the body.
    usage_capture: dict[str, int] = {"input": 0, "output": 0}

    async def stream_iter():
        try:
            async with httpx.AsyncClient(timeout=cfg.forward_timeout_s) as client:
                async with client.stream("POST", url, headers=headers, content=payload) as r:
                    async for chunk in r.aiter_raw():
                        if chunk:
                            try:
                                _scrape_usage_from_sse_chunk(chunk, shape, usage_capture)
                            except Exception:
                                pass
                            yield chunk
        except Exception as e:
            logger.error("stream forward failed: %s", e)
            err = json.dumps({"error": f"mintoken-cli upstream error: {e}"}).encode()
            yield err
        finally:
            duration_ms = int((time.time() - start_time) * 1000)
            try:
                fire_telemetry(
                    mintoken_key=cfg.mintoken_key,
                    upstream="anthropic" if shape == "anthropic" else "openai",
                    model=str(original_body.get("model") or "unknown"),
                    endpoint=endpoint_label,
                    intensity=cfg.level,
                    input_tokens=usage_capture.get("input", metrics.tokens_after),
                    output_tokens=usage_capture.get("output", 0),
                    context_tokens_before=metrics.tokens_before,
                    context_tokens_after=metrics.tokens_after,
                    duration_ms=duration_ms,
                    skipped_reason=metrics.skipped_reason,
                )
            except Exception as e:
                logger.warning("telemetry fire failed: %s", e)

    response_headers = {
        "x-mintoken-cli-tokens-before": str(metrics.tokens_before),
        "x-mintoken-cli-tokens-after": str(metrics.tokens_after),
        "x-mintoken-cli-tokens-saved": str(metrics.tokens_saved),
    }
    if metrics.skipped_reason:
        response_headers["x-mintoken-cli-skipped"] = metrics.skipped_reason

    return StreamingResponse(
        stream_iter(),
        status_code=200,
        media_type="text/event-stream",
        headers=response_headers,
    )


async def _forward_passthrough(
    request: Request,
    raw_body: bytes,
    cfg: ProxyConfig,
    upstream_base: str,
    upstream_path: str,
    shape: str,
    endpoint_label: str,
) -> Response:
    """No compression — forward as-is. Used when body isn't valid JSON."""
    url = f"{upstream_base}{upstream_path}"
    headers = _filter_request_headers(dict(request.headers))
    try:
        async with httpx.AsyncClient(timeout=cfg.forward_timeout_s) as client:
            r = await client.post(url, headers=headers, content=raw_body)
    except Exception as e:
        return JSONResponse(status_code=502, content={"error": str(e)})
    return Response(
        content=r.content,
        status_code=r.status_code,
        headers=_filter_response_headers(dict(r.headers)),
        media_type=r.headers.get("content-type"),
    )


# --- Helpers -------------------------------------------------------------

def _fire(
    cfg: ProxyConfig,
    original_body: dict,
    response_body: dict,
    metrics: CompressionMetrics,
    shape: str,
    endpoint_label: str,
    duration_ms: int,
    streamed: bool,
) -> None:
    usage = response_body.get("usage") or {}
    if shape == "anthropic":
        input_tokens = int(usage.get("input_tokens", 0) or 0)
        output_tokens = int(usage.get("output_tokens", 0) or 0)
    else:
        input_tokens = int(usage.get("prompt_tokens", 0) or 0)
        output_tokens = int(usage.get("completion_tokens", 0) or 0)
    fire_telemetry(
        mintoken_key=cfg.mintoken_key,
        upstream="anthropic" if shape == "anthropic" else "openai",
        model=str(original_body.get("model") or "unknown"),
        endpoint=endpoint_label,
        intensity=cfg.level,
        input_tokens=input_tokens or metrics.tokens_after,
        output_tokens=output_tokens,
        context_tokens_before=metrics.tokens_before,
        context_tokens_after=metrics.tokens_after,
        duration_ms=duration_ms,
        skipped_reason=metrics.skipped_reason,
    )


def _scrape_usage_from_sse_chunk(chunk: bytes, shape: str, capture: dict) -> None:
    """Best-effort: extract token usage from streaming SSE events.

    Anthropic's `message_delta` events carry usage in `delta.usage`.
    OpenAI's final `[DONE]`-adjacent chunk includes `usage` if the
    request opted in via stream_options.
    """
    try:
        text = chunk.decode("utf-8", errors="ignore")
    except Exception:
        return
    for line in text.splitlines():
        line = line.strip()
        if not line or not line.startswith("data:"):
            continue
        payload = line[5:].strip()
        if not payload or payload == "[DONE]":
            continue
        try:
            obj = json.loads(payload)
        except Exception:
            continue
        usage = obj.get("usage") or (obj.get("delta") or {}).get("usage") or (obj.get("message") or {}).get("usage")
        if not isinstance(usage, dict):
            continue
        if shape == "anthropic":
            capture["input"] = capture.get("input", 0) + int(usage.get("input_tokens", 0) or 0)
            capture["output"] = capture.get("output", 0) + int(usage.get("output_tokens", 0) or 0)
        else:
            capture["input"] = max(capture.get("input", 0), int(usage.get("prompt_tokens", 0) or 0))
            capture["output"] = max(capture.get("output", 0), int(usage.get("completion_tokens", 0) or 0))
