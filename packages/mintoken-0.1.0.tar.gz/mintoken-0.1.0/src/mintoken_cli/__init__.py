"""Mintoken local-proxy CLI."""

__version__ = "0.1.0"
