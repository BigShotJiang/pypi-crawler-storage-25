"""Persistent config at ~/.mintoken/config.json.

Schema:
{
  "mintoken_key": "mt_live_...",
  "intensity": "full",
  "level": "standard",
  "anthropic_upstream": "https://api.anthropic.com",
  "openai_upstream": "https://api.openai.com"
}
"""

from __future__ import annotations

import json
import os
from pathlib import Path

CONFIG_DIR = Path(os.path.expanduser("~")) / ".mintoken"
CONFIG_PATH = CONFIG_DIR / "config.json"

DEFAULTS = {
    "mintoken_key": "",
    "intensity": "full",
    "level": "standard",
    "anthropic_upstream": "https://api.anthropic.com",
    "openai_upstream": "https://api.openai.com",
}


def load() -> dict:
    if not CONFIG_PATH.exists():
        return dict(DEFAULTS)
    try:
        data = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
        merged = dict(DEFAULTS)
        merged.update({k: v for k, v in data.items() if k in DEFAULTS})
        return merged
    except (json.JSONDecodeError, OSError):
        return dict(DEFAULTS)


def save(cfg: dict) -> None:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    merged = dict(DEFAULTS)
    merged.update({k: v for k, v in cfg.items() if k in DEFAULTS})
    CONFIG_PATH.write_text(json.dumps(merged, indent=2), encoding="utf-8")


def resolve_key(explicit: str | None = None) -> str:
    """mintoken key precedence: --key flag > env > config file."""
    if explicit:
        return explicit.strip()
    env = os.environ.get("MINTOKEN_KEY", "").strip()
    if env:
        return env
    return load().get("mintoken_key", "")
