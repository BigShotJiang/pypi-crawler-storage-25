"""Tiktoken-based token counting for compression decisions.

Uses OpenAI's BPE tokenizer for both OpenAI- and Anthropic-shape requests.
Anthropic's tokenizer is undocumented client-side, so we approximate with
o200k_base (gpt-4o family). The ratios we care about (before vs after)
are accurate enough to drive compression decisions even if absolute
counts drift by a few percent vs the upstream provider's billing.
"""

from __future__ import annotations

import json
from functools import lru_cache
from typing import Any

try:
    import tiktoken
    _TIKTOKEN_AVAILABLE = True
except Exception:  # pragma: no cover
    _TIKTOKEN_AVAILABLE = False


@lru_cache(maxsize=1)
def _get_encoder():
    if not _TIKTOKEN_AVAILABLE:
        return None
    try:
        return tiktoken.get_encoding("o200k_base")
    except Exception:
        try:
            return tiktoken.get_encoding("cl100k_base")
        except Exception:
            return None


def count_tokens(text: str) -> int:
    """Best-effort token count. Falls back to char/4 if tiktoken is missing."""
    if not text:
        return 0
    enc = _get_encoder()
    if enc is None:
        # Crude fallback — every 4 characters = 1 token (matches the
        # rule-of-thumb for English text).
        return max(1, len(text) // 4)
    try:
        return len(enc.encode(text))
    except Exception:
        return max(1, len(text) // 4)


def count_request_tokens(body: dict, shape: str) -> int:
    """Total tokens across all messages/contents in a request body."""
    total = 0
    if shape in ("openai", "openai-chat"):
        for msg in body.get("messages", []) or []:
            total += _count_message_openai(msg)
    elif shape == "anthropic":
        for msg in body.get("messages", []) or []:
            total += _count_message_anthropic(msg)
        # System prompt for Anthropic is a top-level field, not a message.
        sys = body.get("system")
        if isinstance(sys, str):
            total += count_tokens(sys)
        elif isinstance(sys, list):
            for block in sys:
                if isinstance(block, dict):
                    total += count_tokens(str(block.get("text") or ""))
    return total


def _count_message_openai(msg: dict) -> int:
    content = msg.get("content")
    n = 0
    if isinstance(content, str):
        n += count_tokens(content)
    elif isinstance(content, list):
        for block in content:
            if isinstance(block, dict):
                n += count_tokens(str(block.get("text") or block.get("content") or ""))
    # Tool-call structures
    for tc in msg.get("tool_calls", []) or []:
        fn = (tc or {}).get("function") or {}
        n += count_tokens(str(fn.get("name") or ""))
        n += count_tokens(str(fn.get("arguments") or ""))
    return n


def _count_message_anthropic(msg: dict) -> int:
    content = msg.get("content")
    n = 0
    if isinstance(content, str):
        n += count_tokens(content)
    elif isinstance(content, list):
        for block in content:
            if not isinstance(block, dict):
                continue
            btype = block.get("type")
            if btype == "text":
                n += count_tokens(str(block.get("text") or ""))
            elif btype == "tool_use":
                n += count_tokens(str(block.get("name") or ""))
                n += count_tokens(json.dumps(block.get("input") or {}))
            elif btype == "tool_result":
                inner = block.get("content")
                if isinstance(inner, str):
                    n += count_tokens(inner)
                elif isinstance(inner, list):
                    for sb in inner:
                        if isinstance(sb, dict):
                            n += count_tokens(str(sb.get("text") or ""))
            else:
                # Unknown block — best-effort
                n += count_tokens(str(block.get("text") or ""))
    return n
