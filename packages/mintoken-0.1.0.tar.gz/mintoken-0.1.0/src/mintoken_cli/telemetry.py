"""Push tokens-saved telemetry to api.mintoken.dev.

The local proxy compresses requests on the user's own machine — the
upstream provider's auth token (OpenAI key / Anthropic OAuth) never
leaves localhost. But we DO want the user's mintoken.dev dashboard to
reflect the savings so they can see ROI over time. So after every
forwarded request, we POST a small metric record to a dedicated
telemetry endpoint, authenticated with the user's mt_live_ key.

The POST is fire-and-forget — never block the user's request on it,
never raise into the request path, retries are best-effort.
"""

from __future__ import annotations

import asyncio
import logging
import os
from typing import Any

import httpx

logger = logging.getLogger("mintoken_cli.telemetry")

DEFAULT_TELEMETRY_URL = "https://api.mintoken.dev/v1/cli-telemetry"
TELEMETRY_TIMEOUT_SECONDS = 5.0


async def push(
    *,
    mintoken_key: str,
    upstream: str,                       # "anthropic" | "openai"
    model: str,
    endpoint: str,                       # "messages" | "chat-completions" | "responses"
    intensity: str,                      # "full" | "lite" | "ultra" | "none" | "passthrough"
    input_tokens: int,
    output_tokens: int,
    context_tokens_before: int | None,
    context_tokens_after: int | None,
    duration_ms: int,
    skipped_reason: str | None = None,
) -> None:
    """Send one usage record. Does not raise."""
    if not mintoken_key:
        return  # local-only mode, nothing to push
    url = os.environ.get("MINTOKEN_TELEMETRY_URL", DEFAULT_TELEMETRY_URL)
    payload = {
        "upstream": upstream,
        "model": model,
        "endpoint": endpoint,
        "intensity": intensity,
        "input_tokens": int(input_tokens or 0),
        "output_tokens": int(output_tokens or 0),
        "context_tokens_before": int(context_tokens_before) if context_tokens_before is not None else None,
        "context_tokens_after": int(context_tokens_after) if context_tokens_after is not None else None,
        "duration_ms": int(duration_ms or 0),
        "skipped_reason": skipped_reason,
        "client": "mintoken-cli",
    }
    try:
        async with httpx.AsyncClient(timeout=TELEMETRY_TIMEOUT_SECONDS) as client:
            r = await client.post(
                url,
                headers={
                    "Authorization": f"Bearer {mintoken_key}",
                    "Content-Type": "application/json",
                },
                json=payload,
            )
            if r.status_code >= 400:
                logger.warning(
                    "telemetry POST returned %s: %s", r.status_code, r.text[:200]
                )
    except Exception as e:
        logger.warning("telemetry POST failed: %s", e)


def fire(**kwargs) -> None:
    """Spawn the async push as a background task and return immediately."""
    try:
        loop = asyncio.get_running_loop()
        loop.create_task(push(**kwargs))
    except RuntimeError:
        # No running loop (e.g. sync context). Silently skip — better
        # than crashing the request path.
        pass
