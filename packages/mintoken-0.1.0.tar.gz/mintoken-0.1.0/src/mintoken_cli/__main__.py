"""Allow `python -m mintoken_cli` to invoke the CLI."""
from .cli import main

if __name__ == "__main__":
    main()
