"""Tier 1 context compression — heuristic only, no model calls.

Sits inside the local proxy between the LLM client (Claude Code, Codex,
your own agent) and the upstream provider. Rewrites the request body
to reduce the number of tokens the upstream provider has to process.

Two techniques in v1:

1. **Tool-result truncation** — large tool_result blocks (file reads,
   bash output, grep output) get the head + tail and a marker for the
   middle. Inspired by Factory.ai's observation that the middle of a
   long tool output is rarely what the model reasons over.

2. **Duplicate tool-result eviction** — the same file read across
   multiple turns becomes O(N) waste. Keep the latest, replace earlier
   occurrences with a back-reference.

Things this never touches:
- system prompt
- the most recent N messages (recency window)
- tool_use / tool_result pairs that are mid-flight (no result yet)
- short conversations (skip entirely under min_total_tokens)

Provider-aware because OpenAI and Anthropic shape their messages array
differently. OpenAI uses `role: "tool"` messages with string content;
Anthropic uses `tool_result` content blocks inside user messages.
"""

from __future__ import annotations

import hashlib
import logging
import re
from dataclasses import dataclass
from typing import Any

from .token_counter import count_tokens, count_request_tokens

logger = logging.getLogger("mintoken_cli.compressor")


# --- Tunables (per level) ---------------------------------------------------

@dataclass(frozen=True)
class CompressionLevel:
    name: str
    tool_result_max_tokens: int
    min_total_tokens: int
    recency_window: int
    keep_head_lines: int
    keep_tail_lines: int


LEVELS: dict[str, CompressionLevel] = {
    "light": CompressionLevel(
        name="light",
        tool_result_max_tokens=4000,
        min_total_tokens=8000,
        recency_window=8,
        keep_head_lines=80,
        keep_tail_lines=80,
    ),
    "standard": CompressionLevel(
        name="standard",
        tool_result_max_tokens=2000,
        min_total_tokens=4000,
        recency_window=6,
        keep_head_lines=50,
        keep_tail_lines=50,
    ),
    "aggressive": CompressionLevel(
        name="aggressive",
        tool_result_max_tokens=1000,
        min_total_tokens=2000,
        recency_window=4,
        keep_head_lines=25,
        keep_tail_lines=25,
    ),
}


def _resolve_level(level: str | None) -> CompressionLevel:
    return LEVELS.get((level or "standard").lower(), LEVELS["standard"])


# --- Metrics ---------------------------------------------------------------

@dataclass
class CompressionMetrics:
    tokens_before: int = 0
    tokens_after: int = 0
    messages_modified: int = 0
    truncations: int = 0
    deduplications: int = 0
    skipped_reason: str | None = None

    @property
    def tokens_saved(self) -> int:
        return max(0, self.tokens_before - self.tokens_after)


# --- Public entry ----------------------------------------------------------

def compress(body: dict, shape: str, level: str | None = "standard") -> tuple[dict, CompressionMetrics]:
    """Rewrite body to reduce token count. Returns (new_body, metrics).

    `shape` is one of "openai" or "anthropic".
    Original `body` is never mutated.
    """
    cfg = _resolve_level(level)

    tokens_before = count_request_tokens(body, shape)
    metrics = CompressionMetrics(tokens_before=tokens_before, tokens_after=tokens_before)

    if tokens_before < cfg.min_total_tokens:
        metrics.skipped_reason = "below_threshold"
        return body, metrics

    if shape in ("openai", "openai-chat"):
        new_body, m = _compress_openai(body, cfg)
    elif shape == "anthropic":
        new_body, m = _compress_anthropic(body, cfg)
    else:
        metrics.skipped_reason = f"unsupported_shape:{shape}"
        return body, metrics

    metrics.messages_modified = m.messages_modified
    metrics.truncations = m.truncations
    metrics.deduplications = m.deduplications
    metrics.tokens_after = count_request_tokens(new_body, shape)

    if metrics.tokens_after >= metrics.tokens_before:
        # Heuristic backfired — return original to be safe.
        metrics.skipped_reason = "no_savings"
        metrics.tokens_after = metrics.tokens_before
        return body, metrics

    return new_body, metrics


# --- OpenAI shape ----------------------------------------------------------

def _compress_openai(body: dict, cfg: CompressionLevel) -> tuple[dict, CompressionMetrics]:
    metrics = CompressionMetrics()
    messages = body.get("messages") or []
    if not isinstance(messages, list) or not messages:
        return body, metrics

    last_idx = len(messages) - 1
    cutoff_idx = last_idx - cfg.recency_window

    fingerprints: dict[str, list[int]] = {}
    for i, msg in enumerate(messages):
        if i > cutoff_idx:
            continue
        if msg.get("role") == "tool" and isinstance(msg.get("content"), str):
            fp = _hash(msg["content"])
            fingerprints.setdefault(fp, []).append(i)

    dedup_targets: dict[int, str] = {}
    latest_idx_for_fp: dict[str, int] = {}
    for fp, idxs in fingerprints.items():
        if len(idxs) <= 1:
            continue
        latest_idx_for_fp[fp] = idxs[-1]
        for idx in idxs[:-1]:
            dedup_targets[idx] = fp

    new_messages: list[dict] = []
    for i, msg in enumerate(messages):
        if i > cutoff_idx:
            new_messages.append(msg)
            continue
        modified = msg
        if i in dedup_targets:
            replacement = (
                f"[mintoken: identical tool result deduplicated; "
                f"see message index {latest_idx_for_fp[dedup_targets[i]]}]"
            )
            modified = {**msg, "content": replacement}
            metrics.deduplications += 1
            metrics.messages_modified += 1
        elif msg.get("role") == "tool" and isinstance(msg.get("content"), str):
            new_text, was_trunc = _maybe_truncate_text(msg["content"], cfg)
            if was_trunc:
                modified = {**msg, "content": new_text}
                metrics.truncations += 1
                metrics.messages_modified += 1
        new_messages.append(modified)

    new_body = dict(body)
    new_body["messages"] = new_messages
    return new_body, metrics


# --- Anthropic shape -------------------------------------------------------

def _compress_anthropic(body: dict, cfg: CompressionLevel) -> tuple[dict, CompressionMetrics]:
    metrics = CompressionMetrics()
    messages = body.get("messages") or []
    if not isinstance(messages, list) or not messages:
        return body, metrics

    last_idx = len(messages) - 1
    cutoff_idx = last_idx - cfg.recency_window

    fingerprints: dict[str, list[tuple[int, int]]] = {}
    for i, msg in enumerate(messages):
        if i > cutoff_idx:
            continue
        content = msg.get("content")
        if not isinstance(content, list):
            continue
        for j, block in enumerate(content):
            if not isinstance(block, dict) or block.get("type") != "tool_result":
                continue
            text = _anthropic_tool_result_text(block)
            if text:
                fp = _hash(text)
                fingerprints.setdefault(fp, []).append((i, j))

    dedup_targets: dict[tuple[int, int], int] = {}
    for fp, locs in fingerprints.items():
        if len(locs) <= 1:
            continue
        latest_msg_idx = locs[-1][0]
        for loc in locs[:-1]:
            dedup_targets[loc] = latest_msg_idx

    new_messages: list[dict] = []
    for i, msg in enumerate(messages):
        if i > cutoff_idx:
            new_messages.append(msg)
            continue
        content = msg.get("content")
        if not isinstance(content, list):
            new_messages.append(msg)
            continue
        new_blocks: list[Any] = []
        block_changed = False
        for j, block in enumerate(content):
            if not isinstance(block, dict) or block.get("type") != "tool_result":
                new_blocks.append(block)
                continue
            if (i, j) in dedup_targets:
                replacement = (
                    f"[mintoken: identical tool result deduplicated; "
                    f"see message index {dedup_targets[(i, j)]}]"
                )
                new_blocks.append({**block, "content": replacement})
                metrics.deduplications += 1
                block_changed = True
                continue
            text = _anthropic_tool_result_text(block)
            if text:
                new_text, was_trunc = _maybe_truncate_text(text, cfg)
                if was_trunc:
                    new_blocks.append({**block, "content": new_text})
                    metrics.truncations += 1
                    block_changed = True
                    continue
            new_blocks.append(block)
        if block_changed:
            metrics.messages_modified += 1
            new_messages.append({**msg, "content": new_blocks})
        else:
            new_messages.append(msg)

    new_body = dict(body)
    new_body["messages"] = new_messages
    return new_body, metrics


def _anthropic_tool_result_text(block: dict) -> str:
    inner = block.get("content")
    if isinstance(inner, str):
        return inner
    if isinstance(inner, list):
        parts = []
        for sb in inner:
            if isinstance(sb, dict):
                t = sb.get("text")
                if isinstance(t, str):
                    parts.append(t)
        return "\n".join(parts)
    return ""


# --- Helpers ---------------------------------------------------------------

def _hash(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8", errors="replace")).hexdigest()[:32]


def _maybe_truncate_text(text: str, cfg: CompressionLevel) -> tuple[str, bool]:
    if count_tokens(text) <= cfg.tool_result_max_tokens:
        return text, False
    lines = text.splitlines()
    if len(lines) <= cfg.keep_head_lines + cfg.keep_tail_lines + 5:
        return text, False
    head = lines[: cfg.keep_head_lines]
    tail = lines[-cfg.keep_tail_lines:]
    dropped = len(lines) - cfg.keep_head_lines - cfg.keep_tail_lines
    new_text = (
        "\n".join(head)
        + f"\n\n[mintoken: {dropped} lines truncated to keep head + tail of large tool result]\n\n"
        + "\n".join(tail)
    )
    return new_text, True
