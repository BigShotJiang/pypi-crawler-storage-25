"""mintoken CLI entry point.

Subcommands
  mintoken proxy [--port 8788] [--key mt_live_...] [--level standard]
                 [--anthropic-upstream URL] [--openai-upstream URL]
      Run the local proxy. Listens on http://localhost:<port>.

  mintoken login [--key mt_live_...]
      Save your mintoken key to ~/.mintoken/config.json.

  mintoken status
      Show current config + ping the local proxy if it's running.

  mintoken version
      Print version.
"""

from __future__ import annotations

import sys
from typing import Optional

import typer
from rich.console import Console
from rich.panel import Panel
from rich.text import Text

from . import __version__
from . import config as cfg_mod

app = typer.Typer(
    name="mintoken",
    help="Local-proxy CLI for Mintoken — sit between Claude Code / Codex "
         "and the upstream LLM, dedupe + truncate context, save 40-70% on "
         "long agent sessions.",
    no_args_is_help=True,
    add_completion=False,
)

console = Console()


@app.command(help="Run the local proxy.")
def proxy(
    port: int = typer.Option(8788, "--port", "-p", help="Local port to bind."),
    host: str = typer.Option("127.0.0.1", "--host", help="Local host to bind."),
    key: Optional[str] = typer.Option(None, "--key", help="Mintoken key. If unset, reads MINTOKEN_KEY env or config."),
    level: str = typer.Option("standard", "--level", "-l", help="Compression level: light | standard | aggressive."),
    anthropic_upstream: Optional[str] = typer.Option(None, "--anthropic-upstream"),
    openai_upstream: Optional[str] = typer.Option(None, "--openai-upstream"),
):
    import uvicorn  # local import — keeps module-level startup fast

    from .proxy import build_app, ProxyConfig

    persisted = cfg_mod.load()
    mt_key = cfg_mod.resolve_key(key)

    proxy_cfg = ProxyConfig(
        mintoken_key=mt_key,
        anthropic_upstream=anthropic_upstream or persisted["anthropic_upstream"],
        openai_upstream=openai_upstream or persisted["openai_upstream"],
        level=level or persisted["level"],
    )

    masked_key = (mt_key[:12] + "…") if mt_key else "(none — local-only mode)"
    banner = Text()
    banner.append("mintoken-cli ", style="bold orange3")
    banner.append(f"v{__version__}\n", style="dim")
    banner.append("listening on  ", style="dim")
    banner.append(f"http://{host}:{port}\n", style="bold cyan")
    banner.append("level         ", style="dim")
    banner.append(f"{proxy_cfg.level}\n", style="bold")
    banner.append("mintoken key  ", style="dim")
    banner.append(f"{masked_key}\n", style="bold")
    banner.append("anthropic →   ", style="dim")
    banner.append(f"{proxy_cfg.anthropic_upstream}\n")
    banner.append("openai →      ", style="dim")
    banner.append(f"{proxy_cfg.openai_upstream}\n")

    console.print(Panel(banner, title="proxy starting", border_style="orange3"))
    console.print()
    console.print("[dim]To use with Claude Code (subscription or API key):[/dim]")
    console.print(f"  [cyan]$env:ANTHROPIC_BASE_URL = \"http://{host}:{port}\"[/cyan]")
    console.print()
    console.print("[dim]To use with Codex / OpenAI clients:[/dim]")
    console.print(f"  [cyan]$env:OPENAI_BASE_URL = \"http://{host}:{port}/v1\"[/cyan]")
    console.print()

    fastapi_app = build_app(proxy_cfg)
    uvicorn.run(fastapi_app, host=host, port=port, log_level="warning")


@app.command(help="Save your mintoken key to ~/.mintoken/config.json.")
def login(
    key: Optional[str] = typer.Option(None, "--key", help="Mintoken key (mt_live_...)."),
):
    if not key:
        key = typer.prompt("Mintoken key", hide_input=True)
    persisted = cfg_mod.load()
    persisted["mintoken_key"] = key.strip()
    cfg_mod.save(persisted)
    masked = (key.strip()[:12] + "…") if key else "(empty)"
    console.print(f"[green]✓[/green] saved key {masked} to {cfg_mod.CONFIG_PATH}")
    console.print("[dim]you can now run:[/dim]  [cyan]mintoken proxy[/cyan]")


@app.command(help="Show current config and proxy status.")
def status():
    persisted = cfg_mod.load()
    masked_key = (persisted["mintoken_key"][:12] + "…") if persisted.get("mintoken_key") else "(none)"
    console.print(f"[bold]config file:[/bold] {cfg_mod.CONFIG_PATH}")
    console.print(f"[bold]mintoken key:[/bold] {masked_key}")
    console.print(f"[bold]level:[/bold] {persisted.get('level')}")
    console.print(f"[bold]anthropic upstream:[/bold] {persisted.get('anthropic_upstream')}")
    console.print(f"[bold]openai upstream:[/bold] {persisted.get('openai_upstream')}")


@app.command(help="Print version and exit.")
def version():
    console.print(f"mintoken-cli {__version__}")


def main():
    app()


if __name__ == "__main__":
    main()
