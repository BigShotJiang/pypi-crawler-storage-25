"""Unit tests for the compressor — the brain of mintoken-cli.

These are the same kinds of cases the saas-side compressor passes;
keeping them green here protects the local-proxy port from drifting.
"""

from __future__ import annotations

from mintoken_cli.compressor import compress


# A 200-line "file" — comfortably above standard's 2000-token truncate
# threshold so dedup also finds something big enough to matter.
BIG_FILE = (
    "def f():\n    return 1\n\n"
    + "\n".join(f"# line {i}: filler comment to inflate the file" for i in range(220))
)


def _openai_dedup_messages():
    """16-message agent loop with 3 copies of the same big file inside the
    eligible (compressible) range, last 6 messages protected by recency."""
    return [
        {"role": "user", "content": "Refactor f."},
        {"role": "assistant", "content": "Reading.", "tool_calls": [
            {"id": "a", "type": "function",
             "function": {"name": "read", "arguments": "{}"}}
        ]},
        {"role": "tool", "tool_call_id": "a", "content": BIG_FILE},  # idx 2
        {"role": "assistant", "content": "Reading again.", "tool_calls": [
            {"id": "b", "type": "function",
             "function": {"name": "read", "arguments": "{}"}}
        ]},
        {"role": "tool", "tool_call_id": "b", "content": BIG_FILE},  # idx 4 dup
        {"role": "assistant", "content": "Reading once more.", "tool_calls": [
            {"id": "c", "type": "function",
             "function": {"name": "read", "arguments": "{}"}}
        ]},
        {"role": "tool", "tool_call_id": "c", "content": BIG_FILE},  # idx 6 dup
        {"role": "assistant", "content": "Done reading."},
        {"role": "user", "content": "Now summarize."},
        {"role": "assistant", "content": "Drafting."},  # idx 9 — eligible boundary
        {"role": "user", "content": "Recency 1"},
        {"role": "user", "content": "Recency 2"},
        {"role": "user", "content": "Recency 3"},
        {"role": "user", "content": "Recency 4"},
        {"role": "user", "content": "Recency 5"},
        {"role": "user", "content": "Recency 6"},
    ]


def test_skips_short_conversation():
    body = {"model": "gpt-4o", "messages": [{"role": "user", "content": "hi"}]}
    new_body, m = compress(body, shape="openai")
    assert m.tokens_after == m.tokens_before
    assert m.skipped_reason == "below_threshold"
    assert new_body is body  # not rewritten


def test_openai_dedup_engages():
    body = {"model": "gpt-4o", "messages": _openai_dedup_messages()}
    new_body, m = compress(body, shape="openai", level="standard")
    assert m.tokens_saved > 1000, f"expected real savings, got {m.tokens_saved}"
    assert m.deduplications >= 1
    # The last occurrence (idx 6) must still be verbatim.
    assert new_body["messages"][6]["content"] == BIG_FILE
    # idx 2 and 4 must have been replaced with a back-reference.
    for idx in (2, 4):
        assert "deduplicated" in new_body["messages"][idx]["content"]


def test_recency_window_protected():
    """Last 6 messages must NEVER be modified."""
    body = {"model": "gpt-4o", "messages": _openai_dedup_messages()}
    new_body, _ = compress(body, shape="openai", level="standard")
    original = _openai_dedup_messages()
    for i in range(10, 16):  # cutoff_idx = last - 6 = 9, so idx >= 10 is recent
        assert new_body["messages"][i] == original[i], f"recency violated at {i}"


def test_anthropic_shape_dedup():
    """Anthropic content-block-list shape with tool_result blocks."""
    big_block = {"type": "tool_result", "tool_use_id": "x", "content": BIG_FILE}
    msgs = [
        {"role": "user", "content": "go"},
        {"role": "assistant", "content": [{"type": "tool_use", "id": "1", "name": "r", "input": {}}]},
        {"role": "user", "content": [big_block]},  # idx 2
        {"role": "assistant", "content": [{"type": "tool_use", "id": "2", "name": "r", "input": {}}]},
        {"role": "user", "content": [{**big_block, "tool_use_id": "y"}]},  # idx 4 dup
        {"role": "assistant", "content": [{"type": "tool_use", "id": "3", "name": "r", "input": {}}]},
        {"role": "user", "content": [{**big_block, "tool_use_id": "z"}]},  # idx 6 dup
        # 6 protected recency turns
        {"role": "assistant", "content": "ok"},
        {"role": "user", "content": "and"},
        {"role": "assistant", "content": "ok"},
        {"role": "user", "content": "go"},
        {"role": "assistant", "content": "ok"},
        {"role": "user", "content": "final"},
    ]
    body = {"model": "claude-haiku-4-5", "messages": msgs}
    _, m = compress(body, shape="anthropic", level="standard")
    assert m.tokens_saved > 1000, f"expected real anthropic savings, got {m.tokens_saved}"
    assert m.deduplications >= 1


def test_no_savings_returns_original():
    """Heuristic backfire: if compression yields no savings, original returned."""
    msgs = [{"role": "user", "content": "x" * 200} for _ in range(20)]
    body = {"model": "gpt-4o", "messages": msgs}
    new_body, m = compress(body, shape="openai", level="standard")
    # No tool results to dedupe, no big tool result to truncate. Should
    # either skip below threshold (if total small) OR engage but bail.
    assert m.tokens_saved == 0
