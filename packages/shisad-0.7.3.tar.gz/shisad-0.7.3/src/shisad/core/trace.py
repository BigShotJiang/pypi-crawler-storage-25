"""Training-ready trace recorder for LLM request/response capture.

Captures complete per-turn traces (messages sent, LLM response, tool call
decision chains) for conversion to SFT training data. All content fields
are redacted for secrets and PII before writing to disk.

Storage: per-session JSONL at ``data_dir/traces/{session_id}.jsonl``.
"""

from __future__ import annotations

import logging
import os
import uuid
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Literal

from pydantic import BaseModel, Field, model_validator

from shisad.security.firewall.pii import PIIDetector
from shisad.security.firewall.secrets import redact_ingress_secrets

logger = logging.getLogger(__name__)

_pii_detector = PIIDetector()


def _redact_text(text: str) -> str:
    """Apply secret and PII redaction to a text string."""
    redacted, _ = redact_ingress_secrets(text)
    redacted, _ = _pii_detector.redact(redacted)
    return redacted


def _redact_value(value: Any) -> Any:
    """Recursively redact string values inside dicts, lists, and scalars."""
    if isinstance(value, str):
        return _redact_text(value)
    if isinstance(value, dict):
        return {k: _redact_value(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_redact_value(item) for item in value]
    return value


def _redact_tool_call_payload(value: Any, *, persist_arguments: bool) -> Any:
    redacted = _redact_value(value)
    if persist_arguments:
        return redacted
    if isinstance(redacted, dict):
        return {
            key: (
                {}
                if key == "arguments"
                else _redact_tool_call_payload(child, persist_arguments=False)
            )
            for key, child in redacted.items()
        }
    if isinstance(redacted, list):
        return [_redact_tool_call_payload(item, persist_arguments=False) for item in redacted]
    return redacted


# ---------------------------------------------------------------------------
# Pydantic models (frozen where possible for safety)
# ---------------------------------------------------------------------------


class TraceMessage(BaseModel, frozen=True):
    """A single message in the conversation, mirroring OpenAI chat format."""

    role: str
    content: str = ""
    tool_calls: list[dict[str, Any]] = Field(default_factory=list)
    tool_call_id: str | None = None


class TraceToolCall(BaseModel, frozen=True):
    """A tool call proposal with the full decision chain."""

    tool_name: str
    arguments: dict[str, Any] = Field(default_factory=dict)
    pep_decision: str = ""
    monitor_decision: str = ""
    control_plane_decision: str = ""
    final_decision: str = ""
    executed: bool = False
    execution_success: bool | None = None


class TracePersistencePolicy(BaseModel, frozen=True):
    """Durable trace persistence posture for training/demo artifacts."""

    enabled: bool = True
    persist_tool_arguments: bool = True
    promotion_required: bool = True
    posture: Literal["disabled", "redacted_session_trace"] = "redacted_session_trace"

    @model_validator(mode="before")
    @classmethod
    def _default_posture_from_enabled(cls, payload: Any) -> Any:
        if isinstance(payload, dict) and "posture" not in payload:
            updated = dict(payload)
            updated["posture"] = (
                "redacted_session_trace" if bool(updated.get("enabled", True)) else "disabled"
            )
            return updated
        return payload

    @model_validator(mode="after")
    def _validate_posture(self) -> TracePersistencePolicy:
        if self.enabled and self.posture == "disabled":
            raise ValueError("posture=disabled requires enabled=False")
        if not self.enabled and self.posture != "disabled":
            raise ValueError("disabled trace policy requires posture=disabled")
        return self


class TraceTurn(BaseModel):
    """One complete turn: user message → planner → tool evaluation → response."""

    turn_id: str = Field(default_factory=lambda: uuid.uuid4().hex)
    session_id: str = ""
    timestamp: datetime = Field(default_factory=lambda: datetime.now(UTC))
    user_content: str = ""
    messages_sent: list[TraceMessage] = Field(default_factory=list)
    llm_response: str = ""
    usage: dict[str, int] = Field(default_factory=dict)
    finish_reason: str = ""
    tool_calls: list[TraceToolCall] = Field(default_factory=list)
    assistant_response: str = ""
    model_id: str = ""
    risk_score: float = 0.0
    trust_level: str = ""
    taint_labels: list[str] = Field(default_factory=list)
    duration_ms: float = 0.0
    persistence_policy: Literal["disabled", "redacted_session_trace"] = "redacted_session_trace"
    promotion_required: bool = True


# ---------------------------------------------------------------------------
# Recorder
# ---------------------------------------------------------------------------


class TraceRecorder:
    """Append-only per-session JSONL trace writer with automatic redaction.

    Follows the ``TranscriptStore`` pattern: one file per session, append-only.
    All string content fields are redacted for secrets and PII before write.
    File permissions are restricted to 0o600.
    """

    def __init__(
        self,
        traces_dir: Path,
        *,
        policy: TracePersistencePolicy | None = None,
    ) -> None:
        self._traces_dir = traces_dir
        self._policy = policy or TracePersistencePolicy()
        self._traces_dir.mkdir(parents=True, exist_ok=True)

    def record(self, turn: TraceTurn) -> None:
        """Redact and append a TraceTurn to the session's trace file."""
        if not self._policy.enabled:
            return
        redacted = self._redact_turn(turn, policy=self._policy)
        path = self._traces_dir / f"{redacted.session_id}.jsonl"
        line = redacted.model_dump_json() + "\n"

        is_new = not path.exists()
        with path.open("a", encoding="utf-8") as handle:
            handle.write(line)
        if is_new:
            try:
                os.chmod(path, 0o600)
            except OSError:
                logger.debug("Could not set trace file permissions: %s", path)

    def read_turns(self, session_id: str) -> list[TraceTurn]:
        """Read all TraceTurns for a session (for testing/export)."""
        path = self._traces_dir / f"{session_id}.jsonl"
        if not path.exists():
            return []
        turns: list[TraceTurn] = []
        for line in path.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            turns.append(TraceTurn.model_validate_json(line))
        return turns

    @staticmethod
    def _redact_turn(
        turn: TraceTurn,
        *,
        policy: TracePersistencePolicy | None = None,
    ) -> TraceTurn:
        """Return a copy of the turn with all content fields redacted."""
        resolved_policy = policy or TracePersistencePolicy()
        redacted_messages = [
            TraceMessage(
                role=msg.role,
                content=_redact_text(msg.content),
                tool_calls=_redact_tool_call_payload(
                    msg.tool_calls,
                    persist_arguments=resolved_policy.persist_tool_arguments,
                ),
                tool_call_id=msg.tool_call_id,
            )
            for msg in turn.messages_sent
        ]
        redacted_tool_calls = [
            TraceToolCall(
                tool_name=tc.tool_name,
                arguments=(
                    _redact_value(tc.arguments) if resolved_policy.persist_tool_arguments else {}
                ),
                pep_decision=tc.pep_decision,
                monitor_decision=tc.monitor_decision,
                control_plane_decision=tc.control_plane_decision,
                final_decision=tc.final_decision,
                executed=tc.executed,
                execution_success=tc.execution_success,
            )
            for tc in turn.tool_calls
        ]
        return TraceTurn(
            turn_id=turn.turn_id,
            session_id=turn.session_id,
            timestamp=turn.timestamp,
            user_content=_redact_text(turn.user_content),
            messages_sent=redacted_messages,
            llm_response=_redact_text(turn.llm_response),
            usage=dict(turn.usage),
            finish_reason=turn.finish_reason,
            tool_calls=redacted_tool_calls,
            assistant_response=_redact_text(turn.assistant_response),
            model_id=turn.model_id,
            risk_score=turn.risk_score,
            trust_level=turn.trust_level,
            taint_labels=list(turn.taint_labels),
            duration_ms=turn.duration_ms,
            persistence_policy=resolved_policy.posture,
            promotion_required=resolved_policy.promotion_required,
        )
