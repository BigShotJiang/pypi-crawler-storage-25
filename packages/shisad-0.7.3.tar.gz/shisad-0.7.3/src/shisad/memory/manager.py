"""Long-term memory manager with write gating and TTL handling."""

from __future__ import annotations

import csv
import difflib
import hashlib
import io
import json
import re
import sqlite3
from collections.abc import Callable
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any, ClassVar

from pydantic import ValidationError

from shisad.core.types import TaintLabel
from shisad.memory.events import MemoryEvent, MemoryEventStore
from shisad.memory.remap import (
    ACTIVE_AGENDA_ENTRY_TYPES,
    PROCEDURAL_ENTRY_TYPES,
    PROCEDURE_EXPERIENCE_ENTRY_TYPES,
    digest_memory_value,
    resolve_legacy_source_origin,
)
from shisad.memory.schema import MemoryEntry, MemorySource, MemoryWriteDecision, WorkflowState
from shisad.memory.surfaces import (
    ActiveAttentionPack,
    IdentityPack,
    ProceduralArtifact,
    ProceduralArtifactSummary,
    ProceduralInvocation,
    ThreadResumePack,
    build_active_attention_pack,
    build_identity_pack,
    build_procedural_artifact,
    build_procedural_summary,
    build_procedure_trace_pool_hash,
    build_thread_resume_pack,
    entry_passes_context_filters,
    scan_procedure_candidate_artifact,
)
from shisad.memory.trust import (
    ChannelTrust,
    ConfirmationStatus,
    SourceOrigin,
    backfill_legacy_triple,
    clamp_confidence,
    derive_trust_band,
    is_invocation_eligible_triple,
)
from shisad.security.firewall.pii import PIIDetector

_TRUST_BAND_ORDER: dict[str, int] = {"untrusted": 0, "observed": 1, "elevated": 2}
_ALLOWED_WORKFLOW_STATE_TRANSITIONS: dict[str, set[str]] = {
    "active": {"waiting", "blocked", "stale", "closed"},
    "waiting": {"active", "blocked", "stale", "closed"},
    "blocked": {"active", "waiting", "stale", "closed"},
    "stale": {"active", "closed"},
    "closed": set(),
}


class MemoryManager:
    """Memory manager enforcing attribution + anti-poisoning gates."""

    _INSTRUCTION_PATTERNS: ClassVar[list[re.Pattern[str]]] = [
        re.compile(
            r"\balways\b.{0,24}\b(do|send|forward|share|post|upload|run|execute|call|cc|bcc)\b",
            re.IGNORECASE,
        ),
        re.compile(
            r"\bnever\b.{0,24}\b(ask|confirm|verify|warn|block|refuse|check)\b",
            re.IGNORECASE,
        ),
        re.compile(r"\bignore\b.{0,40}\b(policy|instruction|rule)s?\b", re.IGNORECASE),
        re.compile(r"\bwhen you see\b.{0,80}\bdo\b", re.IGNORECASE),
        re.compile(
            r"\b(if|whenever)\b.{0,40}\b(then|,)\b.{0,40}\b(send|run|execute|call|share)\b",
            re.IGNORECASE,
        ),
    ]
    _PREFERENCE_PREDICATE_PATTERN: ClassVar[re.Pattern[str]] = re.compile(
        r"^[a-z][a-z0-9_]*\([^()\n]{1,200}\)$"
    )
    _DISALLOWED_PREFERENCE_PREFIXES: ClassVar[tuple[str, ...]] = (
        "always",
        "never",
        "ignore",
        "prioritize",
    )
    _LOW_SIGNAL_PHRASES: ClassVar[set[str]] = {
        "got it",
        "great",
        "later",
        "maybe",
        "no",
        "noted",
        "ok",
        "okay",
        "sure",
        "thanks",
        "thank you",
        "yes",
    }
    _LOW_SIGNAL_TOKENS: ClassVar[set[str]] = {
        "fine",
        "got",
        "great",
        "it",
        "later",
        "maybe",
        "no",
        "noted",
        "ok",
        "okay",
        "sure",
        "thanks",
        "them",
        "thing",
        "things",
        "this",
        "those",
        "yes",
    }
    _GENERIC_KEY_SEGMENTS: ClassVar[set[str]] = {
        "conversation",
        "entry",
        "fact",
        "item",
        "memory",
        "note",
        "profile",
        "project",
        "record",
        "remembered",
        "summary",
        "user",
        "value",
    }
    _USER_AUTHORED_ORIGINS: ClassVar[set[str]] = {
        "user_direct",
        "user_confirmed",
        "user_corrected",
    }
    _IDENTITY_ENTRY_TYPES: ClassVar[set[str]] = {
        "persona_fact",
        "preference",
        "soft_constraint",
    }

    def __init__(
        self,
        storage_dir: Path,
        *,
        default_ttl_days: int = 30,
        audit_hook: Callable[[str, dict[str, Any]], None] | None = None,
        pii_detector: PIIDetector | None = None,
    ) -> None:
        self._storage_dir = storage_dir
        self._storage_dir.mkdir(parents=True, exist_ok=True)
        self._db_path = self._storage_dir / "memory.sqlite3"
        self._entries: dict[str, MemoryEntry] = {}
        self._ensure_entry_schema()
        self._event_store = MemoryEventStore(
            self._db_path,
            legacy_jsonl_path=self._storage_dir / "memory_events.jsonl",
        )
        self._default_ttl_days = default_ttl_days
        self._audit_hook = audit_hook
        self._pii_detector = pii_detector or PIIDetector()
        self._import_legacy_entry_files_if_needed()
        self._load_existing_entries()

    def write(
        self,
        *,
        entry_type: str,
        key: str,
        value: Any,
        predicate: str | None = None,
        strength: str = "moderate",
        source: MemorySource,
        confidence: float = 0.5,
        user_confirmed: bool = False,
        workflow_state: WorkflowState | None = None,
        invocation_eligible: bool = False,
        supersedes: str | None = None,
    ) -> MemoryWriteDecision:
        source_origin = resolve_legacy_source_origin(
            source.origin,
            source_id=source.source_id,
            extraction_method=source.extraction_method,
        )
        source_origin, channel_trust, confirmation_status = backfill_legacy_triple(
            source_origin=source_origin
        )
        return self.write_with_provenance(
            entry_type=entry_type,
            key=key,
            value=value,
            predicate=predicate,
            strength=strength,
            source=source,
            source_origin=source_origin,
            channel_trust=channel_trust,
            confirmation_status=confirmation_status,
            source_id=source.source_id,
            scope="user",
            confidence=confidence,
            confirmation_satisfied=user_confirmed,
            workflow_state=workflow_state,
            invocation_eligible=invocation_eligible,
            supersedes=supersedes,
        )

    def write_with_provenance(
        self,
        *,
        entry_type: str,
        key: str,
        value: Any,
        predicate: str | None = None,
        strength: str = "moderate",
        source: MemorySource,
        source_origin: SourceOrigin,
        channel_trust: ChannelTrust,
        confirmation_status: ConfirmationStatus,
        source_id: str,
        scope: str,
        confidence: float = 0.5,
        confirmation_satisfied: bool = False,
        taint_labels: list[TaintLabel] | None = None,
        ingress_handle_id: str | None = None,
        content_digest: str | None = None,
        workflow_state: WorkflowState | None = None,
        invocation_eligible: bool = False,
        supersedes: str | None = None,
        allow_trust_upgrade_without_confirmation: bool = False,
        allow_procedure_experience_lifecycle: bool = False,
        allow_instruction_like_procedural_artifact: bool = False,
        user_id: str | None = None,
        workspace_id: str | None = None,
        include_unowned: bool = False,
    ) -> MemoryWriteDecision:
        owner_scope_requested = user_id is not None or workspace_id is not None or include_unowned
        owner_user_id = self._normalize_owner_value(user_id)
        owner_workspace_id = self._normalize_owner_value(workspace_id)
        if owner_scope_requested and (owner_user_id is None or owner_workspace_id is None):
            return MemoryWriteDecision(
                kind="reject",
                reason="owner_scope_requires_user_and_workspace",
            )

        text_value = str(value)
        pending_review = confirmation_status == "pending_review"
        procedure_candidate_entry = entry_type in PROCEDURE_EXPERIENCE_ENTRY_TYPES
        if procedure_candidate_entry and not allow_procedure_experience_lifecycle:
            return MemoryWriteDecision(
                kind="reject",
                reason="procedure_experience_requires_dedicated_lifecycle",
            )
        approved_procedural_artifact = (
            allow_instruction_like_procedural_artifact
            and entry_type in PROCEDURAL_ENTRY_TYPES
            and invocation_eligible
            and confirmation_satisfied
            and is_invocation_eligible_triple(
                source_origin,
                channel_trust,
                confirmation_status,
            )
        )
        if (
            self._looks_instruction_like(text_value)
            and not procedure_candidate_entry
            and not approved_procedural_artifact
        ):
            return MemoryWriteDecision(
                kind="reject",
                reason="instruction_like_content_blocked",
            )

        if source.origin == "external" and not confirmation_satisfied and not pending_review:
            return MemoryWriteDecision(
                kind="require_confirmation",
                reason="external_origin_requires_confirmation",
            )

        suspicious = self._looks_suspicious(text_value)
        if suspicious and not confirmation_satisfied and not pending_review:
            return MemoryWriteDecision(
                kind="require_confirmation",
                reason="suspicious_memory_write_requires_confirmation",
            )

        if source_origin not in self._USER_AUTHORED_ORIGINS and self._fails_minimum_signal(
            key=key,
            value=value,
        ):
            return MemoryWriteDecision(
                kind="reject",
                reason="insufficient_memory_signal",
            )

        stored_value = value
        pii_findings: list[str] = []
        if isinstance(value, str):
            redacted, findings = self._pii_detector.redact(value)
            if findings:
                pii_findings = sorted({finding.kind for finding in findings})
                stored_value = redacted

        expires_at = None
        if source.origin != "user":
            expires_at = datetime.now(UTC) + timedelta(days=self._default_ttl_days)

        resolved_taints = list(taint_labels or [])
        if source.origin != "user" and TaintLabel.UNTRUSTED not in resolved_taints:
            resolved_taints.append(TaintLabel.UNTRUSTED)

        confidence = clamp_confidence(
            confidence,
            source_origin,
            channel_trust,
            confirmation_status,
            fallback=confidence,
        )
        normalized_predicate = predicate.strip() if isinstance(predicate, str) else None
        if entry_type in {"preference", "soft_constraint"}:
            if not normalized_predicate:
                return MemoryWriteDecision(kind="reject", reason="preference_predicate_required")
            if not self._PREFERENCE_PREDICATE_PATTERN.match(normalized_predicate):
                return MemoryWriteDecision(kind="reject", reason="preference_predicate_invalid")
            predicate_name = normalized_predicate.split("(", 1)[0].lower()
            if predicate_name.startswith(self._DISALLOWED_PREFERENCE_PREFIXES):
                return MemoryWriteDecision(kind="reject", reason="preference_predicate_invalid")
            if (
                source_origin not in self._USER_AUTHORED_ORIGINS
                and confirmation_status != "pending_review"
            ):
                return MemoryWriteDecision(
                    kind="require_confirmation",
                    reason="preference_requires_user_provenance",
                )
        elif normalized_predicate is not None:
            return MemoryWriteDecision(
                kind="reject",
                reason="predicate_requires_preference_entry_type",
            )
        if entry_type not in ACTIVE_AGENDA_ENTRY_TYPES and workflow_state is not None:
            return MemoryWriteDecision(
                kind="reject",
                reason="workflow_state_requires_active_agenda_entry_type",
            )
        if entry_type not in PROCEDURAL_ENTRY_TYPES and invocation_eligible:
            return MemoryWriteDecision(
                kind="reject",
                reason="invocation_eligible_requires_procedural_entry_type",
            )
        if invocation_eligible and not is_invocation_eligible_triple(
            source_origin,
            channel_trust,
            confirmation_status,
        ):
            return MemoryWriteDecision(
                kind="reject",
                reason="invocation_eligible_requires_install_triple",
            )
        resolved_trust_band = derive_trust_band(
            source_origin,
            channel_trust,
            confirmation_status,
        )
        prior_entry: MemoryEntry | None = None
        prior_trust_band: str | None = None
        if supersedes is not None:
            prior_entry = self._entries.get(supersedes)
            if prior_entry is None or self._is_deleted(prior_entry):
                return MemoryWriteDecision(kind="reject", reason="supersedes_target_not_found")
            if owner_scope_requested and not self._entry_matches_owner(
                prior_entry,
                user_id=owner_user_id,
                workspace_id=owner_workspace_id,
                include_unowned=include_unowned,
            ):
                return MemoryWriteDecision(kind="reject", reason="supersedes_target_not_found")
            if prior_entry.superseded_by is not None:
                return MemoryWriteDecision(
                    kind="reject",
                    reason="supersedes_target_already_has_successor",
                )
            if prior_entry.entry_type != entry_type or prior_entry.key != key:
                return MemoryWriteDecision(kind="reject", reason="supersedes_target_mismatch")
            prior_trust_band = derive_trust_band(
                prior_entry.source_origin,
                prior_entry.channel_trust,
                prior_entry.confirmation_status,
            )
            if _TRUST_BAND_ORDER[resolved_trust_band] > _TRUST_BAND_ORDER[prior_trust_band]:
                if not allow_trust_upgrade_without_confirmation and confirmation_status not in {
                    "user_confirmed",
                    "user_corrected",
                }:
                    return MemoryWriteDecision(
                        kind="reject",
                        reason="trust_upgrade_requires_user_confirmation",
                    )
                if not ingress_handle_id:
                    return MemoryWriteDecision(
                        kind="reject",
                        reason="trust_upgrade_requires_ingress_handle",
                    )
        if entry_type in ACTIVE_AGENDA_ENTRY_TYPES:
            if workflow_state is not None:
                resolved_workflow_state = workflow_state
            elif prior_entry is not None:
                resolved_workflow_state = prior_entry.workflow_state or "active"
            else:
                resolved_workflow_state = "active"
        else:
            resolved_workflow_state = None
        if (
            prior_entry is not None
            and prior_entry.entry_type in ACTIVE_AGENDA_ENTRY_TYPES
            and resolved_workflow_state is not None
            and prior_entry.workflow_state != resolved_workflow_state
        ):
            allowed_transitions = _ALLOWED_WORKFLOW_STATE_TRANSITIONS.get(
                str(prior_entry.workflow_state),
                set(),
            )
            if prior_entry.workflow_state is not None and (
                resolved_workflow_state not in allowed_transitions
            ):
                return MemoryWriteDecision(
                    kind="reject",
                    reason="invalid_workflow_transition",
                )
        entry = MemoryEntry(
            version=(prior_entry.version + 1) if prior_entry is not None else 1,
            supersedes=supersedes,
            entry_type=entry_type,
            key=key,
            value=stored_value,
            predicate=normalized_predicate,
            strength=strength,
            source=source,
            source_origin=source_origin,
            channel_trust=channel_trust,
            confirmation_status=confirmation_status,
            source_id=source_id,
            confidence=confidence,
            expires_at=expires_at,
            taint_labels=resolved_taints,
            scope=scope,
            user_id=owner_user_id,
            workspace_id=owner_workspace_id,
            ingress_handle_id=ingress_handle_id,
            content_digest=content_digest,
            workflow_state=resolved_workflow_state,
            invocation_eligible=invocation_eligible,
        )
        self._entries[entry.id] = entry
        self._persist_entry(entry)
        if prior_entry is not None:
            prior_entry.superseded_by = entry.id
            self._persist_entry(prior_entry)
            self._record_event(
                entry=prior_entry,
                event_type="superseded",
                ingress_handle_id=entry.ingress_handle_id,
                metadata={
                    "superseded_by": entry.id,
                    "replacement_version": entry.version,
                },
            )
            self._audit(
                "memory.supersede",
                {
                    "entry_id": prior_entry.id,
                    "superseded_by": entry.id,
                    "replacement_version": entry.version,
                },
            )
        self._record_event(
            entry=entry,
            event_type="created",
            ingress_handle_id=ingress_handle_id,
            metadata={
                "status": entry.status,
                "workflow_state": entry.workflow_state,
                "source_origin": entry.source_origin,
                "invocation_eligible": entry.invocation_eligible,
                "supersedes": entry.supersedes,
            },
        )
        if prior_entry is not None and prior_trust_band != resolved_trust_band:
            self._record_event(
                entry=entry,
                event_type="trust_tier_changed",
                ingress_handle_id=ingress_handle_id,
                metadata={
                    "from": prior_trust_band,
                    "to": resolved_trust_band,
                    "supersedes": prior_entry.id,
                },
            )
            self._audit(
                "memory.trust_tier_changed",
                {
                    "entry_id": entry.id,
                    "supersedes": prior_entry.id,
                    "from": prior_trust_band,
                    "to": resolved_trust_band,
                    "ingress_handle_id": ingress_handle_id,
                },
            )
        if entry.entry_type in ACTIVE_AGENDA_ENTRY_TYPES:
            self._record_event(
                entry=entry,
                event_type="workflow_state_changed",
                ingress_handle_id=ingress_handle_id,
                metadata={
                    "from": None,
                    "to": entry.workflow_state,
                    "status": entry.status,
                    "reason": "init_default" if workflow_state is None else "init_explicit",
                },
            )
            self._audit(
                "memory.workflow_state_changed",
                {
                    "entry_id": entry.id,
                    "from": None,
                    "to": entry.workflow_state,
                    "status": entry.status,
                },
            )
        self._audit(
            "memory.write",
            {
                "entry_id": entry.id,
                "key": key,
                "source_origin": source_origin,
                "ingress_handle_id": ingress_handle_id,
                "pii_findings": pii_findings,
            },
        )
        return MemoryWriteDecision(kind="allow", entry=entry)

    def list_entries(
        self,
        *,
        entry_type: str | None = None,
        include_deleted: bool = False,
        include_quarantined: bool = False,
        include_pending_review: bool = False,
        user_id: str | None = None,
        workspace_id: str | None = None,
        include_unowned: bool = False,
        limit: int = 100,
    ) -> list[MemoryEntry]:
        self.purge_expired()
        selected_type = (entry_type or "").strip().lower()
        owner_filter_requested = user_id is not None or workspace_id is not None or include_unowned
        owner_user_id = self._normalize_owner_value(user_id)
        owner_workspace_id = self._normalize_owner_value(workspace_id)
        if owner_filter_requested and (owner_user_id is None or owner_workspace_id is None):
            return []
        rows = []
        for entry in self._entries.values():
            if selected_type and str(entry.entry_type).lower() != selected_type:
                continue
            if self._is_deleted(entry) and not include_deleted:
                continue
            if self._is_quarantined(entry) and not include_quarantined:
                continue
            if self._is_pending_review(entry) and not include_pending_review:
                continue
            if not self._entry_matches_owner(
                entry,
                user_id=owner_user_id,
                workspace_id=owner_workspace_id,
                include_unowned=include_unowned,
            ):
                continue
            rows.append(self._refresh_ttl(entry))
        rows.sort(key=lambda item: item.created_at, reverse=True)
        return rows[:limit]

    def get_entry(
        self,
        entry_id: str,
        *,
        include_deleted: bool = False,
        include_quarantined: bool = False,
        include_pending_review: bool = False,
        user_id: str | None = None,
        workspace_id: str | None = None,
        include_unowned: bool = False,
    ) -> MemoryEntry | None:
        self.purge_expired()
        owner_filter_requested = user_id is not None or workspace_id is not None or include_unowned
        owner_user_id = self._normalize_owner_value(user_id)
        owner_workspace_id = self._normalize_owner_value(workspace_id)
        if owner_filter_requested and (owner_user_id is None or owner_workspace_id is None):
            return None
        entry = self._entries.get(entry_id)
        if entry is None:
            return None
        if self._is_deleted(entry) and not include_deleted:
            return None
        if self._is_quarantined(entry) and not include_quarantined:
            return None
        if self._is_pending_review(entry) and not include_pending_review:
            return None
        if not self._entry_matches_owner(
            entry,
            user_id=owner_user_id,
            workspace_id=owner_workspace_id,
            include_unowned=include_unowned,
        ):
            return None
        return self._refresh_ttl(entry)

    def list_events(
        self,
        *,
        entry_id: str | None = None,
        event_type: str | None = None,
        limit: int = 100,
    ) -> list[MemoryEvent]:
        return self._event_store.list(entry_id=entry_id, event_type=event_type, limit=limit)

    def count_events(
        self,
        *,
        entry_id: str | None = None,
        event_type: str | None = None,
    ) -> int:
        return self._event_store.count(entry_id=entry_id, event_type=event_type)

    def list_review_queue(
        self,
        *,
        limit: int = 100,
        user_id: str | None = None,
        workspace_id: str | None = None,
        include_unowned: bool = False,
    ) -> list[MemoryEntry]:
        self.purge_expired()
        owner_filter_requested = user_id is not None or workspace_id is not None or include_unowned
        owner_user_id = self._normalize_owner_value(user_id)
        owner_workspace_id = self._normalize_owner_value(workspace_id)
        if owner_filter_requested and (owner_user_id is None or owner_workspace_id is None):
            return []
        rows = [
            self._refresh_ttl(entry)
            for entry in self._entries.values()
            if (
                not self._is_deleted(entry)
                and not self._is_quarantined(entry)
                and self._is_pending_review(entry)
                and entry.superseded_by is None
                and self._entry_matches_owner(
                    entry,
                    user_id=owner_user_id,
                    workspace_id=owner_workspace_id,
                    include_unowned=include_unowned,
                )
            )
        ]
        rows.sort(key=lambda item: item.created_at, reverse=True)
        selected = rows[:limit]
        self._audit(
            "memory.review_queue_list",
            {
                "limit": limit,
                "count": len(selected),
                "entry_ids": [entry.id for entry in selected],
            },
        )
        return selected

    def compile_identity(
        self,
        *,
        max_tokens: int = 750,
        user_id: str | None = None,
        workspace_id: str | None = None,
        include_unowned: bool = False,
    ) -> IdentityPack:
        entries = self.list_entries(
            limit=max(1, len(self._entries)),
            user_id=user_id,
            workspace_id=workspace_id,
            include_unowned=include_unowned,
        )
        return build_identity_pack(entries=entries, max_tokens=max_tokens)

    def compile_active_attention(
        self,
        *,
        max_tokens: int = 750,
        scope_filter: set[str] | None = None,
        allowed_channel_trusts: set[str] | None = None,
        channel_binding: str | None = None,
        session_scope_id: str | None = None,
        user_id: str | None = None,
        workspace_id: str | None = None,
        include_unowned: bool = False,
    ) -> ActiveAttentionPack:
        entries = self.list_entries(
            limit=max(1, len(self._entries)),
            user_id=user_id,
            workspace_id=workspace_id,
            include_unowned=include_unowned,
        )
        visible_entries = self._filter_session_scoped_entries(
            entries,
            session_scope_id=session_scope_id,
        )
        return build_active_attention_pack(
            entries=visible_entries,
            max_tokens=max_tokens,
            scope_filter=scope_filter,
            allowed_channel_trusts=allowed_channel_trusts,
            channel_binding=channel_binding,
        )

    def compile_thread_resume(
        self,
        query: str,
        *,
        max_tokens: int = 700,
        scope_filter: set[str] | None = None,
        allowed_channel_trusts: set[str] | None = None,
        channel_binding: str | None = None,
        session_scope_id: str | None = None,
        user_id: str | None = None,
        workspace_id: str | None = None,
        include_unowned: bool = False,
    ) -> ThreadResumePack:
        entries = self.list_entries(
            limit=max(1, len(self._entries)),
            user_id=user_id,
            workspace_id=workspace_id,
            include_unowned=include_unowned,
        )
        visible_entries = self._filter_session_scoped_entries(
            entries,
            session_scope_id=session_scope_id,
        )
        visible_entries = [
            entry
            for entry in visible_entries
            if entry_passes_context_filters(
                entry=entry,
                scope_filter=scope_filter,
                allowed_channel_trusts=allowed_channel_trusts,
                channel_binding=channel_binding,
            )
        ]
        return build_thread_resume_pack(
            entries=visible_entries,
            query=query,
            max_tokens=max_tokens,
        )

    def _filter_session_scoped_entries(
        self,
        entries: list[MemoryEntry],
        *,
        session_scope_id: str | None,
    ) -> list[MemoryEntry]:
        normalized_session_scope_id = (session_scope_id or "").strip()
        return [
            entry
            for entry in entries
            if str(entry.scope) != "session"
            or (
                normalized_session_scope_id
                and self._session_scope_binding(entry.source_id) == normalized_session_scope_id
            )
        ]

    def list_invocable_skills(
        self,
        *,
        query: str | None = None,
        limit: int = 100,
        allowed_scopes: set[str] | None = None,
        session_scope_id: str | None = None,
        user_id: str | None = None,
        workspace_id: str | None = None,
        include_unowned: bool = False,
    ) -> list[ProceduralArtifactSummary]:
        self.purge_expired()
        normalized_query = (query or "").strip().lower()
        owner_filter_requested = user_id is not None or workspace_id is not None or include_unowned
        owner_user_id = self._normalize_owner_value(user_id)
        owner_workspace_id = self._normalize_owner_value(workspace_id)
        if owner_filter_requested and (owner_user_id is None or owner_workspace_id is None):
            return []
        latest_by_group: dict[tuple[str, str, str, str, str, str], MemoryEntry] = {}
        for entry in self._entries.values():
            if (
                entry.entry_type not in PROCEDURAL_ENTRY_TYPES
                or self._is_deleted(entry)
                or self._is_quarantined(entry)
                or self._is_pending_review(entry)
                or entry.superseded_by is not None
            ):
                continue
            if not self._entry_matches_owner(
                entry,
                user_id=owner_user_id,
                workspace_id=owner_workspace_id,
                include_unowned=include_unowned,
            ):
                continue
            refreshed = self._refresh_ttl(entry)
            if not self._procedural_scope_visible(
                refreshed,
                allowed_scopes=allowed_scopes,
                session_scope_id=session_scope_id,
            ):
                continue
            group_key = self._procedural_group_key(refreshed)
            current = latest_by_group.get(group_key)
            if current is None or self._procedural_sort_key(refreshed) > self._procedural_sort_key(
                current
            ):
                latest_by_group[group_key] = refreshed
        ranked: list[tuple[datetime, ProceduralArtifactSummary]] = []
        for refreshed in latest_by_group.values():
            if not refreshed.invocation_eligible:
                continue
            summary = build_procedural_summary(refreshed)
            haystack = f"{summary.name}\n{summary.description}".lower()
            if normalized_query and normalized_query not in haystack:
                continue
            ranked.append(
                (
                    refreshed.last_cited_at or refreshed.created_at,
                    build_procedural_summary(refreshed),
                )
            )
        ranked.sort(key=lambda item: item[0], reverse=True)
        return [summary for _timestamp, summary in ranked[:limit]]

    def describe_skill(
        self,
        skill_id: str,
        *,
        include_pending_review: bool = False,
        allowed_scopes: set[str] | None = None,
        session_scope_id: str | None = None,
        user_id: str | None = None,
        workspace_id: str | None = None,
        include_unowned: bool = False,
    ) -> ProceduralArtifact | None:
        entry, _reason = self._resolve_procedural_entry(
            skill_id,
            include_pending_review=include_pending_review,
            allowed_scopes=allowed_scopes,
            session_scope_id=session_scope_id,
            user_id=user_id,
            workspace_id=workspace_id,
            include_unowned=include_unowned,
        )
        if entry is None:
            return None
        artifact = build_procedural_artifact(entry)
        prior_entry = self._find_active_procedural_predecessor(
            entry,
            allowed_scopes=allowed_scopes,
            session_scope_id=session_scope_id,
            user_id=user_id,
            workspace_id=workspace_id,
            include_unowned=include_unowned,
        )
        if prior_entry is not None:
            artifact.prior_entry_id = prior_entry.id
            prior_content = build_procedural_artifact(prior_entry).content.splitlines()
            current_content = artifact.content.splitlines()
            diff_lines = list(
                difflib.unified_diff(
                    prior_content,
                    current_content,
                    fromfile=prior_entry.id,
                    tofile=entry.id,
                    lineterm="",
                )
            )
            artifact.diff_preview = "\n".join(diff_lines[:40]) if diff_lines else None
        return artifact

    def ingest_procedure_candidate(
        self,
        *,
        key: str,
        artifact: Any,
        target_entry_type: str,
        target_key: str,
        trace_ids: list[str],
        trace_pool_hash: str,
        source: MemorySource,
        source_origin: SourceOrigin,
        channel_trust: ChannelTrust,
        confirmation_status: ConfirmationStatus,
        source_id: str,
        scope: str,
        ingress_handle_id: str,
        content_digest: str | None,
        scanner_verdict: str | None = None,
        scanner_findings: list[str] | None = None,
        diff_preview: str | None = None,
        taint_labels: list[TaintLabel] | None = None,
        user_id: str | None,
        workspace_id: str | None,
        include_unowned: bool = False,
    ) -> MemoryWriteDecision:
        raw_key = str(key)
        raw_target_key = str(target_key)
        normalized_key = raw_key.strip()
        normalized_target_type = str(target_entry_type).strip().lower()
        normalized_target_key = raw_target_key.strip()
        normalized_trace_ids = [str(item).strip() for item in trace_ids if str(item).strip()]
        normalized_trace_pool_hash = str(trace_pool_hash).strip()
        if not normalized_key:
            return MemoryWriteDecision(kind="reject", reason="procedure_candidate_key_required")
        if not self._procedure_candidate_key_safe(raw_key):
            return MemoryWriteDecision(kind="reject", reason="procedure_candidate_key_invalid")
        if not self._procedure_candidate_target_valid(
            normalized_target_type,
            raw_target_key,
        ):
            return MemoryWriteDecision(kind="reject", reason="procedure_candidate_target_invalid")
        if not normalized_trace_ids or not normalized_trace_pool_hash:
            return MemoryWriteDecision(
                kind="reject",
                reason="procedure_candidate_trace_provenance_required",
            )
        expected_trace_pool_hash = build_procedure_trace_pool_hash(
            artifact,
            normalized_trace_ids,
        )
        if normalized_trace_pool_hash != expected_trace_pool_hash:
            return MemoryWriteDecision(
                kind="reject",
                reason="procedure_candidate_trace_provenance_unverified",
            )
        scanner = self._procedure_candidate_scanner_packet(
            artifact,
            scanner_verdict=scanner_verdict,
            scanner_findings=scanner_findings,
        )
        if scanner is None:
            return MemoryWriteDecision(kind="reject", reason="procedure_candidate_scanner_invalid")
        generated_diff_preview = self._procedure_candidate_diff_preview(
            artifact=artifact,
            target_entry_type=normalized_target_type,
            target_key=normalized_target_key,
            scope=scope,
            user_id=user_id,
            workspace_id=workspace_id,
            include_unowned=include_unowned,
        )
        if not generated_diff_preview:
            return MemoryWriteDecision(kind="reject", reason="procedure_candidate_diff_required")
        candidate_value = {
            "artifact": artifact,
            "target_entry_type": normalized_target_type,
            "target_key": normalized_target_key,
            "trace_ids": normalized_trace_ids,
            "trace_pool_hash": normalized_trace_pool_hash,
            "trace_pool_hash_verified": True,
            "scanner": scanner,
            "review": {
                "status": "pending",
                "reviewer": "",
                "approved_at": None,
                "rejected_at": None,
                "rejected_reason": "",
            },
            "promotion": {
                "status": "candidate",
                "promoted_entry_id": "",
                "rollback_entry_id": "",
            },
            "diff_preview": generated_diff_preview,
            "producer_diff_preview": str(diff_preview or ""),
        }
        decision = self.write_with_provenance(
            entry_type="procedure_experience",
            key=normalized_key,
            value=candidate_value,
            source=source,
            source_origin=source_origin,
            channel_trust=channel_trust,
            confirmation_status="pending_review",
            source_id=source_id,
            scope=scope,
            confidence=0.5,
            confirmation_satisfied=confirmation_status == "user_confirmed",
            taint_labels=list(taint_labels or []),
            ingress_handle_id=ingress_handle_id,
            content_digest=content_digest,
            invocation_eligible=False,
            allow_procedure_experience_lifecycle=True,
            user_id=user_id,
            workspace_id=workspace_id,
            include_unowned=include_unowned,
        )
        if decision.kind != "allow" or decision.entry is None:
            return decision
        self._record_event(
            entry=decision.entry,
            event_type="procedure_candidate_ingested",
            ingress_handle_id=ingress_handle_id,
            metadata={
                "target_entry_type": normalized_target_type,
                "target_key": normalized_target_key,
                "trace_ids": normalized_trace_ids,
                "trace_pool_hash": normalized_trace_pool_hash,
                "trace_pool_hash_verified": True,
                "scanner": scanner,
            },
        )
        self._audit(
            "memory.procedure_candidate_ingested",
            {
                "candidate_id": decision.entry.id,
                "target_entry_type": normalized_target_type,
                "target_key": normalized_target_key,
                "scanner_verdict": scanner["verdict"],
                "ingress_handle_id": ingress_handle_id,
            },
        )
        return decision

    def describe_procedure_candidate(
        self,
        candidate_id: str,
        *,
        ingress_handle_id: str | None = None,
        backfill_legacy: bool = False,
        user_id: str | None = None,
        workspace_id: str | None = None,
        include_unowned: bool = False,
    ) -> dict[str, Any]:
        candidate = self.get_entry(
            candidate_id,
            include_pending_review=True,
            include_deleted=True,
            user_id=user_id,
            workspace_id=workspace_id,
            include_unowned=include_unowned,
        )
        if candidate is None or candidate.entry_type not in PROCEDURE_EXPERIENCE_ENTRY_TYPES:
            return {"found": False, "reason": "procedure_candidate_not_found", "candidate": None}
        if not self._procedure_candidate_key_valid(candidate.key):
            return {
                "found": False,
                "reason": "procedure_candidate_key_invalid",
                "candidate": None,
            }
        if not self._procedure_candidate_stored_target_valid(candidate):
            return {
                "found": False,
                "reason": "procedure_candidate_target_invalid",
                "candidate": None,
            }
        packet = self._procedure_candidate_packet(candidate)
        packet = self._backfill_legacy_procedure_candidate_packet(
            candidate,
            packet,
            scope=str(candidate.scope),
            ingress_handle_id=ingress_handle_id,
            user_id=user_id,
            workspace_id=workspace_id,
            include_unowned=include_unowned,
            persist=backfill_legacy,
        )
        approval_payload = self._procedure_candidate_approval_payload(candidate.id, packet)
        return {
            "found": True,
            "reason": "",
            "candidate": {
                "id": candidate.id,
                "entry_type": str(candidate.entry_type),
                "key": candidate.key,
                "status": candidate.status,
                "confirmation_status": candidate.confirmation_status,
                "superseded_by": candidate.superseded_by,
                "target_entry_type": packet["target_entry_type"],
                "target_key": packet["target_key"],
                "artifact": packet["artifact"],
                "trace_ids": packet["trace_ids"],
                "trace_pool_hash": packet["trace_pool_hash"],
                "trace_pool_hash_verified": packet["trace_pool_hash_verified"],
                "producer_trace_pool_hash": packet["producer_trace_pool_hash"],
                "scanner": packet["scanner"],
                "review": packet["review"],
                "promotion": packet["promotion"],
                "diff_preview": packet["diff_preview"],
                "producer_diff_preview": packet["producer_diff_preview"],
                "review_packet_backfill_reason": packet["review_packet_backfill_reason"],
                "approval_payload": approval_payload,
                "approval_digest": self._procedure_candidate_approval_digest(approval_payload),
            },
        }

    def reject_procedure_candidate(
        self,
        candidate_id: str,
        *,
        ingress_handle_id: str | None = None,
        reviewer: str | None = None,
        reason: str | None = None,
        user_id: str | None = None,
        workspace_id: str | None = None,
        include_unowned: bool = False,
    ) -> tuple[bool, str]:
        candidate, resolved_reason = self._resolve_procedure_candidate(
            candidate_id,
            user_id=user_id,
            workspace_id=workspace_id,
            include_unowned=include_unowned,
        )
        if candidate is None:
            return False, resolved_reason
        packet = self._procedure_candidate_packet(candidate)
        timestamp = datetime.now(UTC)
        packet["review"].update(
            {
                "status": "rejected",
                "reviewer": str(reviewer or "").strip(),
                "rejected_at": timestamp.isoformat(),
                "rejected_reason": str(reason or "operator_rejected").strip()
                or "operator_rejected",
            }
        )
        packet["promotion"].update({"status": "rejected", "promoted_entry_id": ""})
        candidate.value = packet
        candidate.deleted_at = timestamp
        candidate.status = "tombstoned"
        self._persist_entry(candidate)
        self._record_event(
            entry=candidate,
            event_type="tombstoned",
            ingress_handle_id=ingress_handle_id,
            metadata={"reason": "procedure_candidate_rejected"},
        )
        self._record_event(
            entry=candidate,
            event_type="procedure_candidate_rejected",
            ingress_handle_id=ingress_handle_id,
            metadata={
                "reviewer": packet["review"]["reviewer"],
                "reason": packet["review"]["rejected_reason"],
            },
        )
        self._audit(
            "memory.procedure_candidate_rejected",
            {
                "candidate_id": candidate.id,
                "reviewer": packet["review"]["reviewer"],
                "reason": packet["review"]["rejected_reason"],
                "ingress_handle_id": ingress_handle_id,
            },
        )
        return True, "procedure_candidate_rejected"

    def promote_procedure_candidate(
        self,
        *,
        candidate_id: str,
        source: MemorySource,
        source_origin: SourceOrigin,
        channel_trust: ChannelTrust,
        confirmation_status: ConfirmationStatus,
        source_id: str,
        scope: str,
        ingress_handle_id: str,
        content_digest: str | None,
        reviewer: str | None = None,
        taint_labels: list[TaintLabel] | None = None,
        user_id: str | None,
        workspace_id: str | None,
        include_unowned: bool = False,
    ) -> MemoryWriteDecision:
        candidate, reason = self._resolve_procedure_candidate(
            candidate_id,
            user_id=user_id,
            workspace_id=workspace_id,
            include_unowned=include_unowned,
        )
        if candidate is None:
            return MemoryWriteDecision(kind="reject", reason=reason)
        if not self._procedure_candidate_key_valid(candidate.key):
            return MemoryWriteDecision(kind="reject", reason="procedure_candidate_key_invalid")
        if not self._procedure_candidate_stored_target_valid(candidate):
            return MemoryWriteDecision(kind="reject", reason="procedure_candidate_target_invalid")
        packet = self._procedure_candidate_packet(candidate)
        scanner = packet["scanner"]
        scanner_findings = scanner.get("findings", [])
        promotion_scanner = self._procedure_candidate_scanner_packet(
            packet["artifact"],
            scanner_verdict=str(scanner.get("verdict", "")).strip().lower(),
            scanner_findings=scanner_findings if isinstance(scanner_findings, list) else [],
        )
        if promotion_scanner is None or promotion_scanner.get("verdict") != "pass":
            return MemoryWriteDecision(kind="reject", reason="procedure_candidate_scan_not_passed")
        if scope != "user":
            return MemoryWriteDecision(
                kind="reject",
                reason="procedure_candidate_promotion_requires_user_scope",
            )
        if confirmation_status not in {"user_confirmed", "user_corrected"}:
            return MemoryWriteDecision(
                kind="reject",
                reason="procedure_candidate_promotion_requires_operator_approval",
            )
        if not is_invocation_eligible_triple(
            source_origin,
            channel_trust,
            confirmation_status,
        ):
            return MemoryWriteDecision(
                kind="reject",
                reason="procedure_candidate_promotion_requires_install_triple",
            )
        effective_user_id = user_id if user_id is not None else candidate.user_id
        effective_workspace_id = (
            workspace_id if workspace_id is not None else candidate.workspace_id
        )
        packet = self._backfill_legacy_procedure_candidate_packet(
            candidate,
            packet,
            scope=scope,
            ingress_handle_id=ingress_handle_id,
            user_id=effective_user_id,
            workspace_id=effective_workspace_id,
            include_unowned=include_unowned,
        )
        if not packet["trace_ids"] or not str(packet["trace_pool_hash"]).strip():
            return MemoryWriteDecision(
                kind="reject",
                reason="procedure_candidate_trace_provenance_required",
            )
        expected_trace_pool_hash = build_procedure_trace_pool_hash(
            packet["artifact"],
            packet["trace_ids"],
        )
        if packet["trace_pool_hash"] != expected_trace_pool_hash:
            return MemoryWriteDecision(
                kind="reject",
                reason="procedure_candidate_trace_provenance_unverified",
            )
        target_entry_type = str(packet["target_entry_type"])
        target_key = str(packet["target_key"])
        expected_diff_preview = self._procedure_candidate_diff_preview(
            artifact=packet["artifact"],
            target_entry_type=target_entry_type,
            target_key=target_key,
            scope=scope,
            user_id=effective_user_id,
            workspace_id=effective_workspace_id,
            include_unowned=include_unowned,
        )
        if not packet["diff_preview"] or packet["diff_preview"] != expected_diff_preview:
            return MemoryWriteDecision(kind="reject", reason="procedure_candidate_diff_stale")
        prior_entry = self._find_latest_active_procedural_by_target(
            target_entry_type=target_entry_type,
            target_key=target_key,
            scope=scope,
            user_id=effective_user_id,
            workspace_id=effective_workspace_id,
            include_unowned=include_unowned,
        )
        rollback_entry_id = prior_entry.id if prior_entry is not None else ""
        decision = self.write_with_provenance(
            entry_type=target_entry_type,
            key=target_key,
            value=packet["artifact"],
            source=source,
            source_origin=source_origin,
            channel_trust=channel_trust,
            confirmation_status=confirmation_status,
            source_id=source_id,
            scope=scope,
            confidence=max(candidate.confidence, 0.70),
            confirmation_satisfied=True,
            taint_labels=list(taint_labels or []),
            ingress_handle_id=ingress_handle_id,
            content_digest=content_digest,
            invocation_eligible=True,
            supersedes=rollback_entry_id or None,
            allow_trust_upgrade_without_confirmation=True,
            allow_instruction_like_procedural_artifact=True,
            user_id=effective_user_id,
            workspace_id=effective_workspace_id,
            include_unowned=include_unowned,
        )
        if decision.kind != "allow" or decision.entry is None:
            return decision
        timestamp = datetime.now(UTC)
        packet["review"].update(
            {
                "status": "approved",
                "reviewer": str(reviewer or "").strip(),
                "approved_at": timestamp.isoformat(),
            }
        )
        packet["promotion"].update(
            {
                "status": "promoted",
                "promoted_entry_id": decision.entry.id,
                "rollback_entry_id": rollback_entry_id,
            }
        )
        candidate.value = packet
        candidate.superseded_by = decision.entry.id
        self._persist_entry(candidate)
        self._record_event(
            entry=candidate,
            event_type="procedure_candidate_promoted",
            ingress_handle_id=ingress_handle_id,
            metadata={
                "promoted_entry_id": decision.entry.id,
                "rollback_entry_id": rollback_entry_id,
                "target_entry_type": target_entry_type,
                "target_key": target_key,
                "reviewer": packet["review"]["reviewer"],
            },
        )
        self._audit(
            "memory.procedure_candidate_promoted",
            {
                "candidate_id": candidate.id,
                "entry_id": decision.entry.id,
                "rollback_entry_id": rollback_entry_id,
                "target_entry_type": target_entry_type,
                "target_key": target_key,
                "ingress_handle_id": ingress_handle_id,
            },
        )
        return decision

    def promote_to_skill(
        self,
        *,
        entry_id: str,
        source: MemorySource,
        source_origin: SourceOrigin,
        channel_trust: ChannelTrust,
        confirmation_status: ConfirmationStatus,
        source_id: str,
        scope: str,
        ingress_handle_id: str,
        content_digest: str | None,
        taint_labels: list[TaintLabel] | None = None,
        user_id: str | None,
        workspace_id: str | None,
        include_unowned: bool = False,
    ) -> MemoryWriteDecision:
        candidate, reason = self._resolve_procedural_entry(
            entry_id,
            include_pending_review=True,
            user_id=user_id,
            workspace_id=workspace_id,
            include_unowned=include_unowned,
        )
        if candidate is None:
            return MemoryWriteDecision(kind="reject", reason=reason)
        if not self._is_pending_review(candidate):
            return MemoryWriteDecision(kind="reject", reason="skill_not_pending_review")
        if scope != "user":
            return MemoryWriteDecision(kind="reject", reason="skill_promotion_requires_user_scope")
        if not is_invocation_eligible_triple(
            source_origin,
            channel_trust,
            confirmation_status,
        ):
            return MemoryWriteDecision(
                kind="reject",
                reason="skill_promotion_requires_install_triple",
            )
        prior_entry = self._find_active_procedural_predecessor(
            candidate,
            user_id=user_id,
            workspace_id=workspace_id,
            include_unowned=include_unowned,
        )
        supersedes_target = prior_entry.id if prior_entry is not None else candidate.id
        decision = self.write_with_provenance(
            entry_type=candidate.entry_type,
            key=candidate.key,
            value=candidate.value,
            predicate=candidate.predicate,
            strength=candidate.strength,
            source=source,
            source_origin=source_origin,
            channel_trust=channel_trust,
            confirmation_status=confirmation_status,
            source_id=source_id,
            scope=scope,
            confidence=max(candidate.confidence, 0.70),
            confirmation_satisfied=True,
            taint_labels=list(taint_labels or []),
            ingress_handle_id=ingress_handle_id,
            content_digest=content_digest,
            invocation_eligible=True,
            supersedes=supersedes_target,
            allow_trust_upgrade_without_confirmation=True,
            allow_instruction_like_procedural_artifact=True,
            user_id=user_id,
            workspace_id=workspace_id,
            include_unowned=include_unowned,
        )
        if decision.kind != "allow" or decision.entry is None:
            return decision
        if candidate.id != supersedes_target:
            candidate.superseded_by = decision.entry.id
            self._persist_entry(candidate)
        self._audit(
            "memory.skill_promoted",
            {
                "entry_id": decision.entry.id,
                "candidate_id": candidate.id,
                "entry_type": str(decision.entry.entry_type),
                "ingress_handle_id": ingress_handle_id,
                "trust_band": str(decision.entry.trust_band),
            },
        )
        return decision

    def invoke_skill(
        self,
        skill_id: str,
        *,
        audit_context: dict[str, Any] | None = None,
        allowed_scopes: set[str] | None = None,
        session_scope_id: str | None = None,
        user_id: str | None = None,
        workspace_id: str | None = None,
        include_unowned: bool = False,
    ) -> ProceduralInvocation:
        caller_context = dict(audit_context or {})
        entry, reason = self._resolve_procedural_entry(
            skill_id,
            include_pending_review=True,
            allowed_scopes=allowed_scopes,
            session_scope_id=session_scope_id,
            user_id=user_id,
            workspace_id=workspace_id,
            include_unowned=include_unowned,
        )
        if entry is None:
            self._audit(
                "memory.skill_invoked",
                {
                    "skill_id": skill_id,
                    "entry_id": "",
                    "entry_type": "",
                    "found": False,
                    "invoked": False,
                    "reason": reason,
                    "trust_band": "",
                    "caller_context": caller_context,
                },
            )
            return ProceduralInvocation(
                skill_id=skill_id,
                found=False,
                invoked=False,
                reason=reason,
            )
        if not entry.invocation_eligible:
            self._audit(
                "memory.skill_invoked",
                {
                    "skill_id": skill_id,
                    "entry_id": entry.id,
                    "entry_type": str(entry.entry_type),
                    "found": True,
                    "invoked": False,
                    "reason": "skill_not_invocation_eligible",
                    "trust_band": str(entry.trust_band),
                    "caller_context": caller_context,
                },
            )
            return ProceduralInvocation(
                skill_id=skill_id,
                found=True,
                invoked=False,
                reason="skill_not_invocation_eligible",
            )

        timestamp = datetime.now(UTC)
        self.record_citations([entry.id], cited_at=timestamp)
        refreshed = self.get_entry(
            entry.id,
            user_id=user_id,
            workspace_id=workspace_id,
            include_unowned=include_unowned,
        )
        if refreshed is None:
            refreshed = entry
        self._record_event(
            entry=refreshed,
            event_type="skill_invoked",
            ingress_handle_id=refreshed.ingress_handle_id,
            metadata={
                "skill_id": refreshed.id,
                "invoked_at": timestamp.isoformat(),
                "caller_context": caller_context,
                "entry_type": str(refreshed.entry_type),
            },
        )
        self._audit(
            "memory.skill_invoked",
            {
                "skill_id": skill_id,
                "entry_id": refreshed.id,
                "entry_type": str(refreshed.entry_type),
                "found": True,
                "invoked": True,
                "reason": "",
                "trust_band": str(refreshed.trust_band),
                "caller_context": caller_context,
            },
        )
        return ProceduralInvocation(
            skill_id=skill_id,
            found=True,
            invoked=True,
            artifact=build_procedural_artifact(refreshed),
        )

    def record_citations(
        self,
        entry_ids: list[str],
        *,
        cited_at: datetime | None = None,
    ) -> int:
        timestamp = cited_at or datetime.now(UTC)
        unique_entry_ids = [entry_id for entry_id in dict.fromkeys(entry_ids) if entry_id]
        changed = 0
        for entry_id in unique_entry_ids:
            entry = self._entries.get(entry_id)
            if entry is None or self._is_deleted(entry):
                continue
            if self._is_retention_quarantined(entry):
                self.unquarantine(entry.id, reason="retention_rejoin_on_citation")
            entry.citation_count += 1
            entry.last_cited_at = timestamp
            self._persist_entry(entry)
            self._record_event(
                entry=entry,
                event_type="cited",
                ingress_handle_id=entry.ingress_handle_id,
                metadata={"cited_at": timestamp.isoformat()},
            )
            changed += 1
        if changed:
            self._audit(
                "memory.citations_recorded",
                {
                    "entry_ids": unique_entry_ids,
                    "count": changed,
                    "cited_at": timestamp.isoformat(),
                },
            )
        return changed

    def promote_identity_candidate(
        self,
        *,
        candidate_id: str,
        source: MemorySource,
        source_origin: SourceOrigin,
        channel_trust: ChannelTrust,
        confirmation_status: ConfirmationStatus,
        source_id: str,
        scope: str,
        ingress_handle_id: str,
        content_digest: str | None,
        taint_labels: list[TaintLabel] | None = None,
        value: Any | None = None,
        user_id: str | None = None,
        workspace_id: str | None = None,
        include_unowned: bool = False,
    ) -> MemoryWriteDecision:
        candidate, reason = self._resolve_identity_candidate(
            candidate_id,
            user_id=user_id,
            workspace_id=workspace_id,
            include_unowned=include_unowned,
        )
        if candidate is None:
            return MemoryWriteDecision(kind="reject", reason=reason)
        if confirmation_status not in {"user_confirmed", "user_corrected"}:
            return MemoryWriteDecision(
                kind="reject",
                reason="candidate_promotion_requires_user_confirmation",
            )

        promoted_value = candidate.value if value is None else value
        confidence_floor = 0.90 if confirmation_status == "user_confirmed" else 0.85
        candidate_user_id = self._normalize_owner_value(candidate.user_id)
        candidate_workspace_id = self._normalize_owner_value(candidate.workspace_id)
        caller_user_id = self._normalize_owner_value(user_id)
        caller_workspace_id = self._normalize_owner_value(workspace_id)
        promoted_user_id = candidate_user_id or caller_user_id
        promoted_workspace_id = candidate_workspace_id or caller_workspace_id
        decision = self.write_with_provenance(
            entry_type=candidate.entry_type,
            key=candidate.key,
            value=promoted_value,
            predicate=candidate.predicate,
            strength=candidate.strength,
            source=source,
            source_origin=source_origin,
            channel_trust=channel_trust,
            confirmation_status=confirmation_status,
            source_id=source_id,
            scope=scope,
            confidence=max(candidate.confidence, confidence_floor),
            confirmation_satisfied=True,
            taint_labels=list(taint_labels or []),
            ingress_handle_id=ingress_handle_id,
            content_digest=content_digest,
            supersedes=candidate.id,
            user_id=promoted_user_id,
            workspace_id=promoted_workspace_id,
            include_unowned=include_unowned,
        )
        if decision.kind != "allow" or decision.entry is None:
            return decision
        self._record_event(
            entry=decision.entry,
            event_type="candidate_promoted",
            ingress_handle_id=ingress_handle_id,
            metadata={
                "candidate_id": candidate.id,
                "confirmation_status": confirmation_status,
                "edited": promoted_value != candidate.value,
            },
        )
        self._audit(
            "memory.candidate_promoted",
            {
                "candidate_id": candidate.id,
                "entry_id": decision.entry.id,
                "confirmation_status": confirmation_status,
                "edited": promoted_value != candidate.value,
                "ingress_handle_id": ingress_handle_id,
            },
        )
        return decision

    def reject_identity_candidate(
        self,
        candidate_id: str,
        *,
        ingress_handle_id: str | None = None,
        user_id: str | None = None,
        workspace_id: str | None = None,
        include_unowned: bool = False,
    ) -> tuple[bool, str]:
        candidate, reason = self._resolve_identity_candidate(
            candidate_id,
            user_id=user_id,
            workspace_id=workspace_id,
            include_unowned=include_unowned,
        )
        if candidate is None:
            return False, reason
        candidate.deleted_at = datetime.now(UTC)
        candidate.status = "tombstoned"
        self._persist_entry(candidate)
        self._record_event(
            entry=candidate,
            event_type="tombstoned",
            ingress_handle_id=ingress_handle_id,
            metadata={
                "reason": "candidate_rejected",
                "workflow_state": candidate.workflow_state,
            },
        )
        backoff_key = candidate.predicate or candidate.key
        self._record_event(
            entry=candidate,
            event_type="candidate_rejected",
            ingress_handle_id=ingress_handle_id,
            metadata={"backoff_key": backoff_key},
        )
        self._audit(
            "memory.candidate_rejected",
            {
                "candidate_id": candidate.id,
                "backoff_key": backoff_key,
                "ingress_handle_id": ingress_handle_id,
            },
        )
        return True, "candidate_rejected"

    def note_identity_candidate_surface(
        self,
        candidate_id: str,
        *,
        surfaced_at: datetime | None = None,
    ) -> tuple[bool, int]:
        candidate, _reason = self._resolve_identity_candidate(candidate_id)
        if candidate is None:
            return False, 0
        timestamp = surfaced_at or datetime.now(UTC)
        surface_count = self._identity_candidate_surface_count(candidate.id) + 1
        self._record_event(
            entry=candidate,
            event_type="candidate_surfaced",
            ingress_handle_id=None,
            metadata={
                "surface_count": surface_count,
                "surfaced_at": timestamp.isoformat(),
            },
        )
        self._audit(
            "memory.candidate_surfaced",
            {
                "candidate_id": candidate.id,
                "surface_count": surface_count,
            },
        )
        return True, surface_count

    def expire_identity_candidate(
        self,
        candidate_id: str,
        *,
        ingress_handle_id: str | None = None,
    ) -> tuple[bool, str]:
        candidate, reason = self._resolve_identity_candidate(candidate_id)
        if candidate is None:
            return False, reason
        candidate.deleted_at = datetime.now(UTC)
        candidate.status = "tombstoned"
        self._persist_entry(candidate)
        surface_count = self._identity_candidate_surface_count(candidate.id)
        self._record_event(
            entry=candidate,
            event_type="tombstoned",
            ingress_handle_id=ingress_handle_id,
            metadata={
                "reason": "candidate_expired",
                "workflow_state": candidate.workflow_state,
            },
        )
        self._record_event(
            entry=candidate,
            event_type="candidate_expired",
            ingress_handle_id=ingress_handle_id,
            metadata={"surface_count": surface_count},
        )
        self._audit(
            "memory.candidate_expired",
            {
                "candidate_id": candidate.id,
                "surface_count": surface_count,
                "ingress_handle_id": ingress_handle_id,
            },
        )
        return True, "candidate_expired"

    def delete(
        self,
        entry_id: str,
        *,
        user_id: str | None = None,
        workspace_id: str | None = None,
        include_unowned: bool = False,
    ) -> bool:
        owner_filter_requested = user_id is not None or workspace_id is not None or include_unowned
        owner_user_id = self._normalize_owner_value(user_id)
        owner_workspace_id = self._normalize_owner_value(workspace_id)
        if owner_filter_requested and (owner_user_id is None or owner_workspace_id is None):
            return False
        entry = self._entries.get(entry_id)
        if entry is None:
            return False
        if not self._entry_matches_owner(
            entry,
            user_id=owner_user_id,
            workspace_id=owner_workspace_id,
            include_unowned=include_unowned,
        ):
            return False
        if self._is_deleted(entry):
            return True
        entry.deleted_at = datetime.now(UTC)
        entry.status = "tombstoned"
        self._persist_entry(entry)
        self._record_event(
            entry=entry,
            event_type="tombstoned",
            ingress_handle_id=entry.ingress_handle_id,
            metadata={"workflow_state": entry.workflow_state},
        )
        self._audit("memory.delete", {"entry_id": entry_id})
        return True

    def verify(
        self,
        entry_id: str,
        *,
        confidence_delta: float = 0.10,
        confidence_cap: float = 0.95,
        user_id: str | None = None,
        workspace_id: str | None = None,
        include_unowned: bool = False,
    ) -> bool:
        owner_filter_requested = user_id is not None or workspace_id is not None or include_unowned
        owner_user_id = self._normalize_owner_value(user_id)
        owner_workspace_id = self._normalize_owner_value(workspace_id)
        if owner_filter_requested and (owner_user_id is None or owner_workspace_id is None):
            return False
        entry = self._entries.get(entry_id)
        if entry is None:
            return False
        if not self._entry_matches_owner(
            entry,
            user_id=owner_user_id,
            workspace_id=owner_workspace_id,
            include_unowned=include_unowned,
        ):
            return False
        previous_confidence = entry.confidence
        entry.user_verified = True
        entry.last_verified_at = datetime.now(UTC)
        entry.confidence = round(
            min(float(confidence_cap), entry.confidence + float(confidence_delta)),
            4,
        )
        self._persist_entry(entry)
        self._record_event(
            entry=entry,
            event_type="verified",
            ingress_handle_id=entry.ingress_handle_id,
            metadata={
                "last_verified_at": entry.last_verified_at.isoformat(),
                "old_value": previous_confidence,
                "new_value": entry.confidence,
            },
        )
        if self._is_retention_quarantined(entry):
            self.unquarantine(
                entry.id,
                reason="retention_rejoin_on_reverify",
                user_id=owner_user_id,
                workspace_id=owner_workspace_id,
                include_unowned=include_unowned,
            )
        self._audit(
            "memory.verify",
            {
                "entry_id": entry_id,
                "old_value": previous_confidence,
                "new_value": entry.confidence,
            },
        )
        return True

    def update_decay_score(
        self,
        entry_id: str,
        decay_score: float,
        *,
        ingress_handle_id: str | None = None,
        reason: str = "consolidation_recompute",
    ) -> bool:
        entry = self._entries.get(entry_id)
        if entry is None or self._is_deleted(entry):
            return False
        previous = entry.decay_score
        entry.decay_score = max(0.0, min(1.0, float(decay_score)))
        self._persist_entry(entry)
        self._record_event(
            entry=entry,
            event_type="score_recomputed",
            ingress_handle_id=ingress_handle_id or entry.ingress_handle_id,
            metadata={"old_value": previous, "new_value": entry.decay_score, "reason": reason},
        )
        self._audit(
            "memory.score_recomputed",
            {"entry_id": entry_id, "old_value": previous, "new_value": entry.decay_score},
        )
        return True

    def update_confidence(
        self,
        entry_id: str,
        confidence: float,
        *,
        event_type: str,
        reference_entry_ids: list[str],
        ingress_handle_id: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> bool:
        entry = self._entries.get(entry_id)
        if entry is None or self._is_deleted(entry):
            return False
        previous = entry.confidence
        entry.confidence = max(0.0, min(0.99, float(confidence)))
        self._persist_entry(entry)
        payload = dict(metadata or {})
        payload.update(
            {
                "old_value": previous,
                "new_value": entry.confidence,
                "reference_entry_ids": list(reference_entry_ids),
            }
        )
        self._record_event(
            entry=entry,
            event_type=event_type,
            ingress_handle_id=ingress_handle_id or entry.ingress_handle_id,
            metadata=payload,
        )
        self._audit(
            f"memory.{event_type}",
            {
                "entry_id": entry_id,
                "old_value": previous,
                "new_value": entry.confidence,
                "reference_entry_ids": list(reference_entry_ids),
            },
        )
        return True

    def mark_conflict(
        self,
        entry_id: str,
        conflicting_entry_id: str,
        *,
        ingress_handle_id: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> bool:
        entry = self._entries.get(entry_id)
        if entry is None or self._is_deleted(entry):
            return False
        if conflicting_entry_id not in entry.conflict_entry_ids:
            entry.conflict_entry_ids.append(conflicting_entry_id)
            entry.conflict_entry_ids.sort()
            self._persist_entry(entry)
        payload = dict(metadata or {})
        payload["conflicting_entry_id"] = conflicting_entry_id
        payload["conflict_entry_ids"] = list(entry.conflict_entry_ids)
        self._record_event(
            entry=entry,
            event_type="contradicted",
            ingress_handle_id=ingress_handle_id or entry.ingress_handle_id,
            metadata=payload,
        )
        self._audit(
            "memory.contradicted",
            {"entry_id": entry_id, "conflicting_entry_id": conflicting_entry_id},
        )
        return True

    def mark_merged(
        self,
        entry_id: str,
        merged_into_id: str,
        *,
        ingress_handle_id: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> bool:
        entry = self._entries.get(entry_id)
        keeper = self._entries.get(merged_into_id)
        if entry is None or keeper is None or entry_id == merged_into_id:
            return False
        if self._is_deleted(keeper):
            return False
        if self._is_deleted(entry):
            return entry.superseded_by == merged_into_id
        timestamp = datetime.now(UTC)
        entry.superseded_by = merged_into_id
        entry.deleted_at = timestamp
        entry.status = "tombstoned"
        self._persist_entry(entry)
        payload = dict(metadata or {})
        payload.update(
            {
                "merged_into_id": merged_into_id,
                "workflow_state": entry.workflow_state,
            }
        )
        self._record_event(
            entry=entry,
            event_type="merged",
            ingress_handle_id=ingress_handle_id or entry.ingress_handle_id,
            metadata=payload,
        )
        self._record_event(
            entry=entry,
            event_type="tombstoned",
            ingress_handle_id=ingress_handle_id or entry.ingress_handle_id,
            metadata={"reason": "merged", "merged_into_id": merged_into_id},
        )
        self._audit(
            "memory.merged",
            {"entry_id": entry_id, "merged_into_id": merged_into_id, **payload},
        )
        return True

    def record_consolidation_event(
        self,
        entry_id: str,
        event_type: str,
        *,
        ingress_handle_id: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> bool:
        entry = self._entries.get(entry_id)
        if entry is None or self._is_deleted(entry):
            return False
        self._record_event(
            entry=entry,
            event_type=event_type,
            ingress_handle_id=ingress_handle_id or entry.ingress_handle_id,
            metadata=dict(metadata or {}),
        )
        self._audit(f"memory.{event_type}", {"entry_id": entry_id, **dict(metadata or {})})
        return True

    def export(
        self,
        *,
        fmt: str = "json",
        user_id: str | None = None,
        workspace_id: str | None = None,
        include_unowned: bool = False,
    ) -> str:
        items = [
            entry.model_dump(mode="json")
            for entry in self.list_entries(
                include_deleted=True,
                user_id=user_id,
                workspace_id=workspace_id,
                include_unowned=include_unowned,
            )
        ]
        for item in items:
            item["value"] = self._redact_export_value(item.get("value"))
        if fmt == "json":
            return json.dumps(items, indent=2)
        if fmt == "csv":
            buffer = io.StringIO()
            writer = csv.DictWriter(
                buffer,
                fieldnames=[
                    "id",
                    "entry_type",
                    "key",
                    "value",
                    "origin",
                    "source_id",
                    "created_at",
                    "expires_at",
                    "user_verified",
                    "deleted_at",
                ],
            )
            writer.writeheader()
            for item in items:
                source = item.get("source", {})
                writer.writerow(
                    {
                        "id": item["id"],
                        "entry_type": item["entry_type"],
                        "key": item["key"],
                        "value": self._redact_export_value(item["value"]),
                        "origin": source.get("origin", ""),
                        "source_id": source.get("source_id", ""),
                        "created_at": item["created_at"],
                        "expires_at": item.get("expires_at"),
                        "user_verified": item["user_verified"],
                        "deleted_at": item.get("deleted_at"),
                    }
                )
            return buffer.getvalue()
        raise ValueError(f"Unsupported export format: {fmt}")

    def reset_storage(self) -> None:
        """Clear persisted memory rows without deleting the shared SQLite file."""
        self._entries.clear()
        with self._connect_db() as conn:
            conn.execute("DELETE FROM memory_entries")
        self._event_store.clear()
        for path in self._storage_dir.glob("*.json"):
            path.unlink(missing_ok=True)

    def quarantine(
        self,
        entry_id: str,
        *,
        reason: str,
        user_id: str | None = None,
        workspace_id: str | None = None,
        include_unowned: bool = False,
    ) -> bool:
        owner_filter_requested = user_id is not None or workspace_id is not None or include_unowned
        owner_user_id = self._normalize_owner_value(user_id)
        owner_workspace_id = self._normalize_owner_value(workspace_id)
        if owner_filter_requested and (owner_user_id is None or owner_workspace_id is None):
            return False
        entry = self._entries.get(entry_id)
        if entry is None:
            return False
        if not self._entry_matches_owner(
            entry,
            user_id=owner_user_id,
            workspace_id=owner_workspace_id,
            include_unowned=include_unowned,
        ):
            return False
        entry.quarantined = True
        entry.status = "quarantined"
        self._persist_entry(entry)
        self._record_event(
            entry=entry,
            event_type="quarantined",
            ingress_handle_id=entry.ingress_handle_id,
            metadata={"reason": reason, "workflow_state": entry.workflow_state},
        )
        self._audit("memory.quarantine", {"entry_id": entry_id, "reason": reason})
        return True

    def unquarantine(
        self,
        entry_id: str,
        *,
        reason: str,
        user_id: str | None = None,
        workspace_id: str | None = None,
        include_unowned: bool = False,
    ) -> bool:
        owner_filter_requested = user_id is not None or workspace_id is not None or include_unowned
        owner_user_id = self._normalize_owner_value(user_id)
        owner_workspace_id = self._normalize_owner_value(workspace_id)
        if owner_filter_requested and (owner_user_id is None or owner_workspace_id is None):
            return False
        entry = self._entries.get(entry_id)
        if entry is None or self._is_deleted(entry):
            return False
        if not self._entry_matches_owner(
            entry,
            user_id=owner_user_id,
            workspace_id=owner_workspace_id,
            include_unowned=include_unowned,
        ):
            return False
        if not self._is_quarantined(entry):
            return True
        if entry.superseded_by is not None or self._has_active_key_collision(
            entry,
            user_id=owner_user_id,
            workspace_id=owner_workspace_id,
            include_unowned=include_unowned,
        ):
            self._audit(
                "memory.unquarantine_blocked",
                {
                    "entry_id": entry_id,
                    "reason": reason,
                    "superseded_by": entry.superseded_by,
                },
            )
            return False
        entry.quarantined = False
        entry.status = "active"
        self._persist_entry(entry)
        self._record_event(
            entry=entry,
            event_type="unquarantined",
            ingress_handle_id=entry.ingress_handle_id,
            metadata={"reason": reason, "workflow_state": entry.workflow_state},
        )
        self._audit("memory.unquarantine", {"entry_id": entry_id, "reason": reason})
        return True

    def set_workflow_state(
        self,
        entry_id: str,
        workflow_state: WorkflowState,
        *,
        user_id: str | None = None,
        workspace_id: str | None = None,
        include_unowned: bool = False,
        reason: str = "",
        allow_closed_reopen: bool = False,
    ) -> bool:
        owner_filter_requested = user_id is not None or workspace_id is not None or include_unowned
        owner_user_id = self._normalize_owner_value(user_id)
        owner_workspace_id = self._normalize_owner_value(workspace_id)
        if owner_filter_requested and (owner_user_id is None or owner_workspace_id is None):
            return False
        entry = self._entries.get(entry_id)
        if entry is None or self._is_deleted(entry):
            return False
        if not self._entry_matches_owner(
            entry,
            user_id=owner_user_id,
            workspace_id=owner_workspace_id,
            include_unowned=include_unowned,
        ):
            return False
        if entry.entry_type not in ACTIVE_AGENDA_ENTRY_TYPES:
            raise ValueError("workflow_state only applies to active-agenda entry types")
        previous_state = entry.workflow_state
        if previous_state == workflow_state:
            return True
        allowed_transitions = _ALLOWED_WORKFLOW_STATE_TRANSITIONS.get(str(previous_state), set())
        thread_reopen_allowed = (
            allow_closed_reopen
            and entry.entry_type == "open_thread"
            and previous_state == "closed"
            and workflow_state == "active"
        )
        if (
            previous_state is not None
            and workflow_state not in allowed_transitions
            and not thread_reopen_allowed
        ):
            raise ValueError(
                f"invalid_workflow_transition: {previous_state or 'none'} -> {workflow_state}"
            )
        entry.workflow_state = workflow_state
        self._persist_entry(entry)
        event_metadata: dict[str, Any] = {
            "from": previous_state,
            "to": workflow_state,
            "status": entry.status,
        }
        if reason.strip():
            event_metadata["reason"] = reason.strip()
        self._record_event(
            entry=entry,
            event_type="workflow_state_changed",
            ingress_handle_id=entry.ingress_handle_id,
            metadata=event_metadata,
        )
        self._audit(
            "memory.workflow_state_changed",
            {
                "entry_id": entry_id,
                "from": previous_state,
                "to": workflow_state,
                "status": entry.status,
                "reason": reason.strip(),
            },
        )
        return True

    def purge_expired(self) -> None:
        now = datetime.now(UTC)
        for entry in self._entries.values():
            if self._is_deleted(entry):
                continue
            if entry.expires_at is not None and entry.expires_at < now:
                entry.deleted_at = now
                entry.status = "tombstoned"
                self._persist_entry(entry)
                self._record_event(
                    entry=entry,
                    event_type="tombstoned",
                    ingress_handle_id=entry.ingress_handle_id,
                    metadata={"reason": "expired", "workflow_state": entry.workflow_state},
                )
                self._audit("memory.expire", {"entry_id": entry.id})

    def _persist_entry(self, entry: MemoryEntry) -> None:
        with self._connect_db() as conn:
            self._upsert_entry(conn, entry)

    def _load_existing_entries(self) -> None:
        self._entries = {}
        with self._connect_db() as conn:
            rows = conn.execute(
                """
                SELECT
                    id,
                    version,
                    supersedes,
                    superseded_by,
                    entry_type,
                    key,
                    value_json,
                    predicate,
                    strength,
                    source_json,
                    source_origin,
                    channel_trust,
                    confirmation_status,
                    source_id,
                    created_at,
                    valid_from,
                    valid_to,
                    last_verified_at,
                    expires_at,
                    confidence,
                    taint_labels_json,
                    citation_count,
                    last_cited_at,
                    decay_score,
                    importance_weight,
                    status,
                    workflow_state,
                    scope,
                    invocation_eligible,
                    ingress_handle_id,
                    content_digest,
                    conflict_entry_ids_json,
                    user_verified,
                    deleted_at,
                    quarantined
                FROM memory_entries
                ORDER BY created_at ASC, id ASC
                """
            ).fetchall()
        for row in rows:
            try:
                entry = MemoryEntry.model_validate(
                    {
                        "id": str(row["id"]),
                        "version": int(row["version"]),
                        "supersedes": row["supersedes"],
                        "superseded_by": row["superseded_by"],
                        "entry_type": str(row["entry_type"]),
                        "key": str(row["key"]),
                        "value": json.loads(str(row["value_json"])),
                        "predicate": row["predicate"],
                        "strength": str(row["strength"]),
                        "source": json.loads(str(row["source_json"])),
                        "source_origin": str(row["source_origin"]),
                        "channel_trust": str(row["channel_trust"]),
                        "confirmation_status": str(row["confirmation_status"]),
                        "source_id": str(row["source_id"]),
                        "created_at": str(row["created_at"]),
                        "valid_from": row["valid_from"],
                        "valid_to": row["valid_to"],
                        "last_verified_at": row["last_verified_at"],
                        "expires_at": row["expires_at"],
                        "confidence": float(row["confidence"]),
                        "taint_labels": json.loads(str(row["taint_labels_json"])),
                        "citation_count": int(row["citation_count"]),
                        "last_cited_at": row["last_cited_at"],
                        "decay_score": float(row["decay_score"]),
                        "importance_weight": float(row["importance_weight"]),
                        "status": str(row["status"]),
                        "workflow_state": row["workflow_state"],
                        "scope": str(row["scope"]),
                        "invocation_eligible": bool(row["invocation_eligible"]),
                        "ingress_handle_id": row["ingress_handle_id"],
                        "content_digest": row["content_digest"],
                        "conflict_entry_ids": json.loads(
                            str(row["conflict_entry_ids_json"] or "[]")
                        ),
                        "user_verified": bool(row["user_verified"]),
                        "deleted_at": row["deleted_at"],
                        "quarantined": bool(row["quarantined"]),
                    }
                )
            except (TypeError, ValueError, ValidationError, json.JSONDecodeError):
                continue
            self._entries[entry.id] = entry
        snapshots = self._event_store.latest_entry_snapshots()
        if not snapshots:
            return
        rebuilt_entries: list[MemoryEntry] = []
        for snapshot in snapshots:
            try:
                entry = MemoryEntry.model_validate(snapshot)
            except (TypeError, ValueError, ValidationError, json.JSONDecodeError):
                continue
            self._entries[entry.id] = entry
            rebuilt_entries.append(entry)
        if not rebuilt_entries:
            return
        with self._connect_db() as conn:
            for entry in rebuilt_entries:
                self._upsert_entry(conn, entry)

    def _connect_db(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self._db_path)
        conn.row_factory = sqlite3.Row
        return conn

    def _ensure_entry_schema(self) -> None:
        with self._connect_db() as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS memory_entries (
                    id TEXT PRIMARY KEY,
                    version INTEGER NOT NULL,
                    supersedes TEXT,
                    superseded_by TEXT,
                    entry_type TEXT NOT NULL,
                    key TEXT NOT NULL,
                    value_json TEXT NOT NULL,
                    predicate TEXT,
                    strength TEXT NOT NULL DEFAULT 'moderate',
                    source_json TEXT NOT NULL,
                    source_origin TEXT NOT NULL,
                    channel_trust TEXT NOT NULL,
                    confirmation_status TEXT NOT NULL,
                    source_id TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    valid_from TEXT,
                    valid_to TEXT,
                    last_verified_at TEXT,
                    expires_at TEXT,
                    confidence REAL NOT NULL,
                    taint_labels_json TEXT NOT NULL,
                    citation_count INTEGER NOT NULL,
                    last_cited_at TEXT,
                    decay_score REAL NOT NULL,
                    importance_weight REAL NOT NULL,
                    status TEXT NOT NULL,
                    workflow_state TEXT,
                    scope TEXT NOT NULL,
                    invocation_eligible INTEGER NOT NULL,
                    ingress_handle_id TEXT,
                    content_digest TEXT,
                    conflict_entry_ids_json TEXT NOT NULL DEFAULT '[]',
                    user_verified INTEGER NOT NULL,
                    deleted_at TEXT,
                    quarantined INTEGER NOT NULL
                )
                """
            )
            columns = {row[1] for row in conn.execute("PRAGMA table_info(memory_entries)")}
            if "predicate" not in columns:
                conn.execute("ALTER TABLE memory_entries ADD COLUMN predicate TEXT")
            if "strength" not in columns:
                conn.execute(
                    "ALTER TABLE memory_entries "
                    "ADD COLUMN strength TEXT NOT NULL DEFAULT 'moderate'"
                )
            if "conflict_entry_ids_json" not in columns:
                conn.execute(
                    "ALTER TABLE memory_entries "
                    "ADD COLUMN conflict_entry_ids_json TEXT NOT NULL DEFAULT '[]'"
                )
            conn.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_memory_entries_type_created
                ON memory_entries (entry_type, created_at)
                """
            )
            conn.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_memory_entries_status_created
                ON memory_entries (status, created_at)
                """
            )
            conn.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_memory_entries_workflow_created
                ON memory_entries (workflow_state, created_at)
                """
            )
            conn.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_memory_entries_trust
                ON memory_entries (source_origin, channel_trust, confirmation_status)
                """
            )
            conn.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_memory_entries_scope_created
                ON memory_entries (scope, created_at)
                """
            )
            conn.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_memory_entries_key_type
                ON memory_entries (entry_type, key)
                """
            )
            conn.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_memory_entries_supersedes
                ON memory_entries (supersedes)
                """
            )
            conn.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_memory_entries_superseded_by
                ON memory_entries (superseded_by)
                """
            )

    def _import_legacy_entry_files_if_needed(self) -> None:
        with self._connect_db() as conn:
            row = conn.execute("SELECT COUNT(*) FROM memory_entries").fetchone()
            existing = int(row[0]) if row is not None else 0
            if existing:
                return
            for path in sorted(self._storage_dir.glob("*.json")):
                try:
                    entry = MemoryEntry.model_validate_json(path.read_text(encoding="utf-8"))
                except (OSError, UnicodeError, ValidationError):
                    continue
                self._upsert_entry(conn, entry)

    @staticmethod
    def _upsert_entry(conn: sqlite3.Connection, entry: MemoryEntry) -> None:
        payload = entry.model_dump(mode="json")
        conn.execute(
            """
            INSERT OR REPLACE INTO memory_entries (
                id,
                version,
                supersedes,
                superseded_by,
                entry_type,
                key,
                value_json,
                predicate,
                strength,
                source_json,
                source_origin,
                channel_trust,
                confirmation_status,
                source_id,
                created_at,
                valid_from,
                valid_to,
                last_verified_at,
                expires_at,
                confidence,
                taint_labels_json,
                citation_count,
                last_cited_at,
                decay_score,
                importance_weight,
                status,
                workflow_state,
                scope,
                invocation_eligible,
                ingress_handle_id,
                content_digest,
                conflict_entry_ids_json,
                user_verified,
                deleted_at,
                quarantined
            ) VALUES (
                ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
                ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?
            )
            """,
            (
                payload["id"],
                payload["version"],
                payload["supersedes"],
                payload["superseded_by"],
                payload["entry_type"],
                payload["key"],
                json.dumps(payload["value"], sort_keys=True),
                payload["predicate"],
                payload["strength"],
                json.dumps(payload["source"], sort_keys=True),
                payload["source_origin"],
                payload["channel_trust"],
                payload["confirmation_status"],
                payload.get("source_id", ""),
                payload["created_at"],
                payload["valid_from"],
                payload["valid_to"],
                payload["last_verified_at"],
                payload["expires_at"],
                payload["confidence"],
                json.dumps(payload["taint_labels"], sort_keys=True),
                payload["citation_count"],
                payload["last_cited_at"],
                payload["decay_score"],
                payload["importance_weight"],
                payload["status"],
                payload["workflow_state"],
                payload["scope"],
                int(bool(payload["invocation_eligible"])),
                payload["ingress_handle_id"],
                payload["content_digest"],
                json.dumps(payload["conflict_entry_ids"], sort_keys=True),
                int(bool(payload["user_verified"])),
                payload["deleted_at"],
                int(bool(payload["quarantined"])),
            ),
        )

    def _record_event(
        self,
        *,
        entry: MemoryEntry,
        event_type: str,
        ingress_handle_id: str | None,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        payload = dict(metadata or {})
        payload["entry_snapshot"] = entry.model_dump(mode="json")
        self._event_store.append(
            MemoryEvent(
                entry_id=entry.id,
                event_type=event_type,
                ingress_handle_id=ingress_handle_id,
                metadata_json=payload,
            )
        )

    def _refresh_ttl(self, entry: MemoryEntry) -> MemoryEntry:
        if entry.source.origin == "user":
            return entry
        if entry.expires_at is not None and not self._is_deleted(entry):
            entry.expires_at = datetime.now(UTC) + timedelta(days=self._default_ttl_days)
            self._persist_entry(entry)
        return entry

    def _resolve_identity_candidate(
        self,
        candidate_id: str,
        *,
        user_id: str | None = None,
        workspace_id: str | None = None,
        include_unowned: bool = False,
    ) -> tuple[MemoryEntry | None, str]:
        candidate = self.get_entry(
            candidate_id,
            include_pending_review=True,
            user_id=user_id,
            workspace_id=workspace_id,
            include_unowned=include_unowned,
        )
        if candidate is None:
            return None, "candidate_not_found"
        if self._is_quarantined(candidate):
            return None, "candidate_not_found"
        if self._is_deleted(candidate):
            return None, "candidate_not_found"
        if candidate.superseded_by is not None:
            return None, "candidate_already_resolved"
        if not self._is_pending_review(candidate):
            return None, "candidate_not_pending_review"
        if candidate.entry_type not in self._IDENTITY_ENTRY_TYPES:
            return None, "candidate_entry_type_invalid"
        return candidate, ""

    def _resolve_procedure_candidate(
        self,
        candidate_id: str,
        *,
        user_id: str | None = None,
        workspace_id: str | None = None,
        include_unowned: bool = False,
    ) -> tuple[MemoryEntry | None, str]:
        candidate = self.get_entry(
            candidate_id,
            include_pending_review=True,
            user_id=user_id,
            workspace_id=workspace_id,
            include_unowned=include_unowned,
        )
        if candidate is None:
            return None, "procedure_candidate_not_found"
        if candidate.entry_type not in PROCEDURE_EXPERIENCE_ENTRY_TYPES:
            return None, "procedure_candidate_not_found"
        if self._is_quarantined(candidate):
            return None, "procedure_candidate_not_found"
        if self._is_deleted(candidate):
            return None, "procedure_candidate_not_found"
        if candidate.superseded_by is not None:
            return None, "procedure_candidate_already_resolved"
        if not self._is_pending_review(candidate):
            return None, "procedure_candidate_not_pending_review"
        return candidate, ""

    def _resolve_procedural_entry(
        self,
        skill_id: str,
        *,
        include_pending_review: bool = False,
        allowed_scopes: set[str] | None = None,
        session_scope_id: str | None = None,
        user_id: str | None = None,
        workspace_id: str | None = None,
        include_unowned: bool = False,
    ) -> tuple[MemoryEntry | None, str]:
        entry = self.get_entry(
            skill_id,
            include_pending_review=include_pending_review,
            user_id=user_id,
            workspace_id=workspace_id,
            include_unowned=include_unowned,
        )
        if entry is None:
            return None, "skill_not_found"
        if entry.entry_type not in PROCEDURAL_ENTRY_TYPES:
            return None, "skill_not_found"
        if entry.superseded_by is not None:
            return None, "skill_not_found"
        refreshed = self._refresh_ttl(entry)
        if not self._procedural_scope_visible(
            refreshed,
            allowed_scopes=allowed_scopes,
            session_scope_id=session_scope_id,
        ):
            return None, "skill_not_found"
        if not self._is_pending_review(refreshed):
            latest_active = self._find_latest_active_procedural_entry(
                refreshed,
                allowed_scopes=allowed_scopes,
                session_scope_id=session_scope_id,
                user_id=user_id,
                workspace_id=workspace_id,
                include_unowned=include_unowned,
            )
            if latest_active is not None and latest_active.id != refreshed.id:
                return None, "skill_not_found"
        return refreshed, ""

    @staticmethod
    def _procedure_candidate_scanner_packet(
        artifact: Any,
        *,
        scanner_verdict: str | None,
        scanner_findings: list[str] | None,
    ) -> dict[str, Any] | None:
        automatic = scan_procedure_candidate_artifact(artifact)
        declared_verdict = (
            str(automatic["verdict"]).strip().lower()
            if scanner_verdict is None
            else str(scanner_verdict).strip().lower()
        )
        if declared_verdict not in {"pass", "fail"}:
            return None
        declared_findings = {
            str(item).strip() for item in list(scanner_findings or []) if str(item).strip()
        }
        automatic_findings = {
            str(item).strip() for item in list(automatic.get("findings", [])) if str(item).strip()
        }
        findings = declared_findings | automatic_findings
        verdict = (
            "fail"
            if declared_verdict == "fail" or automatic["verdict"] == "fail" or declared_findings
            else "pass"
        )
        return {"verdict": verdict, "findings": sorted(findings)}

    @staticmethod
    def _procedure_candidate_target_valid(target_entry_type: str, target_key: str) -> bool:
        normalized_target_type = str(target_entry_type).strip().lower()
        raw_target_key = str(target_key)
        normalized_target_key = raw_target_key.strip()
        return (
            normalized_target_type in PROCEDURAL_ENTRY_TYPES
            and bool(normalized_target_key)
            and MemoryManager._procedure_candidate_key_safe(raw_target_key)
        )

    @staticmethod
    def _procedure_candidate_key_valid(candidate_key: str) -> bool:
        raw_key = str(candidate_key)
        normalized_key = raw_key.strip()
        return bool(normalized_key) and MemoryManager._procedure_candidate_key_safe(raw_key)

    @staticmethod
    def _procedure_candidate_stored_target_valid(candidate: MemoryEntry) -> bool:
        value = candidate.value if isinstance(candidate.value, dict) else {}
        return MemoryManager._procedure_candidate_target_valid(
            str(value.get("target_entry_type", "")),
            str(value.get("target_key", "")),
        )

    @staticmethod
    def _procedure_candidate_key_safe(key: str) -> bool:
        return not any(
            ord(char) < 32 or 0x7F <= ord(char) <= 0x9F or char in {"\u2028", "\u2029"}
            for char in key
        )

    @staticmethod
    def _procedure_candidate_target_key_safe(target_key: str) -> bool:
        return MemoryManager._procedure_candidate_key_safe(target_key)

    @staticmethod
    def _procedure_candidate_approval_payload(candidate_id: str, packet: dict[str, Any]) -> str:
        scanner = packet["scanner"]
        payload = {
            "candidate_id": str(candidate_id),
            "artifact_digest": digest_memory_value(packet["artifact"]),
            "target_entry_type": str(packet["target_entry_type"]),
            "target_key": str(packet["target_key"]),
            "trace_pool_hash": str(packet["trace_pool_hash"]),
            "scanner": {
                "verdict": str(scanner.get("verdict", "")).strip().lower(),
                "findings": sorted(
                    str(item).strip() for item in scanner.get("findings", []) if str(item).strip()
                ),
            },
            "diff_preview": str(packet["diff_preview"]),
        }
        return json.dumps(
            payload,
            sort_keys=True,
            separators=(",", ":"),
            ensure_ascii=False,
            default=str,
        )

    @staticmethod
    def _procedure_candidate_approval_digest(approval_payload: str) -> str:
        return hashlib.sha256(approval_payload.encode("utf-8")).hexdigest()

    @staticmethod
    def _procedure_candidate_packet(entry: MemoryEntry) -> dict[str, Any]:
        value = entry.value if isinstance(entry.value, dict) else {}
        target_entry_type = str(value.get("target_entry_type", "")).strip().lower()
        target_key = str(value.get("target_key", "")).strip()
        raw_scanner = value.get("scanner")
        scanner: dict[str, Any] = raw_scanner if isinstance(raw_scanner, dict) else {}
        raw_review = value.get("review")
        review: dict[str, Any] = raw_review if isinstance(raw_review, dict) else {}
        raw_promotion = value.get("promotion")
        promotion: dict[str, Any] = raw_promotion if isinstance(raw_promotion, dict) else {}
        trace_ids_raw = value.get("trace_ids", [])
        trace_ids = trace_ids_raw if isinstance(trace_ids_raw, list) else []
        scanner_verdict = "scanner_verdict_malformed"
        if isinstance(raw_scanner, dict) and scanner.get("verdict") is not None:
            normalized_scanner_verdict = str(scanner.get("verdict", "")).strip().lower()
            if normalized_scanner_verdict in {"pass", "fail"}:
                scanner_verdict = normalized_scanner_verdict
        scanner_findings = scanner.get("findings")
        if not isinstance(raw_scanner, dict):
            normalized_scanner_findings = ["scanner_packet_malformed"]
        elif "findings" not in scanner or scanner_findings is None:
            normalized_scanner_findings = ["scanner_findings_malformed"]
        elif isinstance(scanner_findings, list):
            normalized_scanner_findings = [
                str(item).strip() for item in scanner_findings if str(item).strip()
            ]
        else:
            normalized_scanner_findings = ["scanner_findings_malformed"]
        return {
            "artifact": value.get("artifact"),
            "target_entry_type": target_entry_type,
            "target_key": target_key,
            "trace_ids": [str(item).strip() for item in trace_ids if str(item).strip()],
            "trace_pool_hash": str(value.get("trace_pool_hash", "")).strip(),
            "trace_pool_hash_verified": bool(value.get("trace_pool_hash_verified", False)),
            "scanner": {
                "verdict": scanner_verdict,
                "findings": normalized_scanner_findings,
            },
            "review": {
                "status": str(review.get("status", "pending")).strip() or "pending",
                "reviewer": str(review.get("reviewer", "")).strip(),
                "approved_at": review.get("approved_at"),
                "rejected_at": review.get("rejected_at"),
                "rejected_reason": str(review.get("rejected_reason", "")).strip(),
            },
            "promotion": {
                "status": str(promotion.get("status", "candidate")).strip() or "candidate",
                "promoted_entry_id": str(promotion.get("promoted_entry_id", "")).strip(),
                "rollback_entry_id": str(promotion.get("rollback_entry_id", "")).strip(),
            },
            "diff_preview": str(value.get("diff_preview", "")),
            "producer_diff_preview": str(value.get("producer_diff_preview", "")),
            "producer_trace_pool_hash": str(value.get("producer_trace_pool_hash", "")).strip(),
            "review_packet_backfill_reason": str(
                value.get("review_packet_backfill_reason", "")
            ).strip(),
        }

    def _backfill_legacy_procedure_candidate_packet(
        self,
        candidate: MemoryEntry,
        packet: dict[str, Any],
        *,
        scope: str,
        ingress_handle_id: str | None,
        user_id: str | None,
        workspace_id: str | None,
        include_unowned: bool,
        persist: bool = True,
    ) -> dict[str, Any]:
        value = candidate.value if isinstance(candidate.value, dict) else {}
        legacy_packet = (
            "trace_pool_hash_verified" not in value
            and "producer_diff_preview" not in value
            and candidate.entry_type in PROCEDURE_EXPERIENCE_ENTRY_TYPES
        )
        if not legacy_packet:
            return packet

        updated = dict(value)
        if packet["trace_ids"]:
            expected_trace_pool_hash = build_procedure_trace_pool_hash(
                packet["artifact"],
                packet["trace_ids"],
            )
            original_hash = str(updated.get("trace_pool_hash", "")).strip()
            if original_hash and original_hash != expected_trace_pool_hash:
                updated["producer_trace_pool_hash"] = original_hash
            updated["trace_pool_hash"] = expected_trace_pool_hash
            updated["trace_pool_hash_verified"] = True

        effective_user_id = user_id if user_id is not None else candidate.user_id
        effective_workspace_id = (
            workspace_id if workspace_id is not None else candidate.workspace_id
        )
        expected_diff_preview = self._procedure_candidate_diff_preview(
            artifact=packet["artifact"],
            target_entry_type=str(packet["target_entry_type"]),
            target_key=str(packet["target_key"]),
            scope=scope,
            user_id=effective_user_id,
            workspace_id=effective_workspace_id,
            include_unowned=include_unowned,
        )
        original_diff_preview = str(updated.get("diff_preview", ""))
        if original_diff_preview and original_diff_preview != expected_diff_preview:
            updated["producer_diff_preview"] = original_diff_preview
        else:
            updated["producer_diff_preview"] = ""
        if expected_diff_preview:
            updated["diff_preview"] = expected_diff_preview
        updated["review_packet_backfill_reason"] = "legacy_procedure_candidate_review_packet"

        if not persist:
            preview = candidate.model_copy(update={"value": updated})
            return self._procedure_candidate_packet(preview)

        candidate.value = updated
        self._persist_entry(candidate)
        review_ingress_handle_id = ingress_handle_id or candidate.ingress_handle_id
        self._record_event(
            entry=candidate,
            event_type="procedure_candidate_review_packet_backfilled",
            ingress_handle_id=review_ingress_handle_id,
            metadata={
                "target_entry_type": str(packet["target_entry_type"]),
                "target_key": str(packet["target_key"]),
                "reason": "legacy_procedure_candidate_review_packet",
            },
        )
        self._audit(
            "memory.procedure_candidate_review_packet_backfilled",
            {
                "candidate_id": candidate.id,
                "target_entry_type": str(packet["target_entry_type"]),
                "target_key": str(packet["target_key"]),
                "ingress_handle_id": review_ingress_handle_id,
            },
        )
        return self._procedure_candidate_packet(candidate)

    @staticmethod
    def _procedural_sort_key(entry: MemoryEntry) -> tuple[int, datetime, str]:
        return (entry.version, entry.created_at, entry.id)

    @staticmethod
    def _procedure_artifact_content(artifact: Any) -> str:
        if isinstance(artifact, bytes):
            return artifact.decode("utf-8", errors="replace")
        if isinstance(artifact, str):
            return artifact
        return json.dumps(artifact, indent=2, sort_keys=True, ensure_ascii=False, default=str)

    def _procedure_candidate_diff_preview(
        self,
        *,
        artifact: Any,
        target_entry_type: str,
        target_key: str,
        scope: str,
        user_id: str | None,
        workspace_id: str | None,
        include_unowned: bool,
    ) -> str:
        prior_entry = self._find_latest_active_procedural_by_target(
            target_entry_type=target_entry_type,
            target_key=target_key,
            scope=scope,
            user_id=user_id,
            workspace_id=workspace_id,
            include_unowned=include_unowned,
        )
        if prior_entry is None:
            prior_lines: list[str] = []
            fromfile = "/dev/null"
        else:
            prior_lines = build_procedural_artifact(prior_entry).content.splitlines()
            fromfile = prior_entry.id
        current_lines = self._procedure_artifact_content(artifact).splitlines()
        diff_lines = list(
            difflib.unified_diff(
                prior_lines,
                current_lines,
                fromfile=fromfile,
                tofile=str(target_key).strip() or "candidate",
                lineterm="",
            )
        )
        return "\n".join(diff_lines[:80]) if diff_lines else ""

    @staticmethod
    def _session_scope_binding(source_id: str) -> str:
        normalized = str(source_id).strip()
        if not normalized:
            return ""
        return normalized.split(":", 1)[0]

    def _procedural_group_key(self, entry: MemoryEntry) -> tuple[str, str, str, str, str, str]:
        entry_scope = str(entry.scope)
        session_binding = (
            self._session_scope_binding(entry.source_id) if entry_scope == "session" else ""
        )
        owner_user = self._normalize_owner_value(entry.user_id) or ""
        owner_workspace = self._normalize_owner_value(entry.workspace_id) or ""
        return (
            entry_scope,
            session_binding,
            owner_user,
            owner_workspace,
            str(entry.entry_type),
            str(entry.key),
        )

    def _procedural_group_key_without_owner(self, entry: MemoryEntry) -> tuple[str, str, str, str]:
        entry_scope = str(entry.scope)
        session_binding = (
            self._session_scope_binding(entry.source_id) if entry_scope == "session" else ""
        )
        return (
            entry_scope,
            session_binding,
            str(entry.entry_type),
            str(entry.key),
        )

    def _procedural_scope_visible(
        self,
        entry: MemoryEntry,
        *,
        allowed_scopes: set[str] | None = None,
        session_scope_id: str | None = None,
    ) -> bool:
        normalized_scopes = allowed_scopes or {"user"}
        entry_scope = str(entry.scope)
        if entry_scope not in normalized_scopes:
            return False
        if entry_scope != "session":
            return True
        normalized_session_scope_id = (session_scope_id or "").strip()
        if not normalized_session_scope_id:
            return False
        return self._session_scope_binding(entry.source_id) == normalized_session_scope_id

    def _find_latest_active_procedural_entry(
        self,
        entry: MemoryEntry,
        *,
        allowed_scopes: set[str] | None = None,
        session_scope_id: str | None = None,
        user_id: str | None = None,
        workspace_id: str | None = None,
        include_unowned: bool = False,
    ) -> MemoryEntry | None:
        group_key = self._procedural_group_key(entry)
        owner_filter_requested = user_id is not None or workspace_id is not None or include_unowned
        owner_user_id = self._normalize_owner_value(user_id)
        owner_workspace_id = self._normalize_owner_value(workspace_id)
        if owner_filter_requested and (owner_user_id is None or owner_workspace_id is None):
            return None
        include_legacy_unowned = (
            include_unowned and owner_user_id is not None and owner_workspace_id is not None
        )
        legacy_group_key = (
            self._procedural_group_key_without_owner(entry) if include_legacy_unowned else None
        )
        latest: MemoryEntry | None = None
        latest_owned: MemoryEntry | None = None
        latest_unowned: MemoryEntry | None = None
        for candidate in self._entries.values():
            if include_legacy_unowned:
                if self._procedural_group_key_without_owner(candidate) != legacy_group_key:
                    continue
            elif self._procedural_group_key(candidate) != group_key:
                continue
            if (
                self._is_deleted(candidate)
                or self._is_quarantined(candidate)
                or self._is_pending_review(candidate)
                or candidate.superseded_by is not None
            ):
                continue
            if not self._entry_matches_owner(
                candidate,
                user_id=owner_user_id,
                workspace_id=owner_workspace_id,
                include_unowned=include_unowned,
            ):
                continue
            refreshed = self._refresh_ttl(candidate)
            if not self._procedural_scope_visible(
                refreshed,
                allowed_scopes=allowed_scopes,
                session_scope_id=session_scope_id,
            ):
                continue
            if include_legacy_unowned:
                candidate_user_id = self._normalize_owner_value(refreshed.user_id)
                candidate_workspace_id = self._normalize_owner_value(refreshed.workspace_id)
                candidate_unowned = candidate_user_id is None and candidate_workspace_id is None
                if candidate_unowned:
                    if latest_unowned is None or self._procedural_sort_key(
                        refreshed
                    ) > self._procedural_sort_key(latest_unowned):
                        latest_unowned = refreshed
                elif latest_owned is None or self._procedural_sort_key(
                    refreshed
                ) > self._procedural_sort_key(latest_owned):
                    latest_owned = refreshed
                continue
            if latest is None or self._procedural_sort_key(refreshed) > self._procedural_sort_key(
                latest
            ):
                latest = refreshed
        if include_legacy_unowned:
            return latest_owned or latest_unowned
        return latest

    def _find_latest_active_procedural_by_target(
        self,
        *,
        target_entry_type: str,
        target_key: str,
        scope: str,
        user_id: str | None = None,
        workspace_id: str | None = None,
        include_unowned: bool = False,
    ) -> MemoryEntry | None:
        normalized_target_type = str(target_entry_type).strip().lower()
        normalized_target_key = str(target_key).strip()
        owner_filter_requested = user_id is not None or workspace_id is not None or include_unowned
        owner_user_id = self._normalize_owner_value(user_id)
        owner_workspace_id = self._normalize_owner_value(workspace_id)
        if owner_filter_requested and (owner_user_id is None or owner_workspace_id is None):
            return None
        include_legacy_unowned = (
            include_unowned and owner_user_id is not None and owner_workspace_id is not None
        )
        latest: MemoryEntry | None = None
        latest_owned: MemoryEntry | None = None
        latest_unowned: MemoryEntry | None = None
        for candidate in self._entries.values():
            if (
                candidate.entry_type != normalized_target_type
                or candidate.key != normalized_target_key
                or candidate.scope != scope
                or self._is_deleted(candidate)
                or self._is_quarantined(candidate)
                or self._is_pending_review(candidate)
                or candidate.superseded_by is not None
            ):
                continue
            if not self._entry_matches_owner(
                candidate,
                user_id=owner_user_id,
                workspace_id=owner_workspace_id,
                include_unowned=include_unowned,
            ):
                continue
            refreshed = self._refresh_ttl(candidate)
            if include_legacy_unowned:
                candidate_user_id = self._normalize_owner_value(refreshed.user_id)
                candidate_workspace_id = self._normalize_owner_value(refreshed.workspace_id)
                candidate_unowned = candidate_user_id is None and candidate_workspace_id is None
                if candidate_unowned:
                    if latest_unowned is None or self._procedural_sort_key(
                        refreshed
                    ) > self._procedural_sort_key(latest_unowned):
                        latest_unowned = refreshed
                elif latest_owned is None or self._procedural_sort_key(
                    refreshed
                ) > self._procedural_sort_key(latest_owned):
                    latest_owned = refreshed
                continue
            if latest is None or self._procedural_sort_key(refreshed) > self._procedural_sort_key(
                latest
            ):
                latest = refreshed
        if include_legacy_unowned:
            return latest_owned or latest_unowned
        return latest

    def _find_active_procedural_predecessor(
        self,
        entry: MemoryEntry,
        *,
        allowed_scopes: set[str] | None = None,
        session_scope_id: str | None = None,
        user_id: str | None = None,
        workspace_id: str | None = None,
        include_unowned: bool = False,
    ) -> MemoryEntry | None:
        latest = self._find_latest_active_procedural_entry(
            entry,
            allowed_scopes=allowed_scopes,
            session_scope_id=session_scope_id,
            user_id=user_id,
            workspace_id=workspace_id,
            include_unowned=include_unowned,
        )
        if latest is None or latest.id == entry.id:
            return None
        return latest

    def _identity_candidate_surface_count(self, candidate_id: str) -> int:
        return self.count_events(
            entry_id=candidate_id,
            event_type="candidate_surfaced",
        )

    @staticmethod
    def _normalize_owner_value(value: str | None) -> str | None:
        if value is None:
            return None
        normalized = str(value).strip()
        return normalized or None

    @staticmethod
    def _entry_matches_owner(
        entry: MemoryEntry,
        *,
        user_id: str | None,
        workspace_id: str | None,
        include_unowned: bool,
    ) -> bool:
        if user_id is None and workspace_id is None:
            return True
        if user_id is None or workspace_id is None:
            return False
        entry_user_id = MemoryManager._normalize_owner_value(entry.user_id)
        entry_workspace_id = MemoryManager._normalize_owner_value(entry.workspace_id)
        entry_unowned = entry_user_id is None and entry_workspace_id is None
        if entry_unowned:
            return include_unowned
        return entry_user_id == user_id and entry_workspace_id == workspace_id

    @staticmethod
    def _is_deleted(entry: MemoryEntry) -> bool:
        return entry.status in {"tombstoned", "hard_deleted"} or entry.deleted_at is not None

    @staticmethod
    def _is_quarantined(entry: MemoryEntry) -> bool:
        return entry.status == "quarantined" or entry.quarantined

    @staticmethod
    def _is_pending_review(entry: MemoryEntry) -> bool:
        return entry.confirmation_status == "pending_review"

    def _has_active_key_collision(
        self,
        entry: MemoryEntry,
        *,
        user_id: str | None = None,
        workspace_id: str | None = None,
        include_unowned: bool = False,
    ) -> bool:
        for candidate in self.list_entries(
            entry_type=entry.entry_type,
            include_pending_review=True,
            limit=max(1, len(self._entries)),
            user_id=user_id,
            workspace_id=workspace_id,
            include_unowned=include_unowned,
        ):
            if (
                candidate.id == entry.id
                or candidate.superseded_by is not None
                or self._is_quarantined(candidate)
                or self._is_deleted(candidate)
            ):
                continue
            if candidate.key == entry.key:
                return True
        return False

    def _is_retention_quarantined(self, entry: MemoryEntry) -> bool:
        if not self._is_quarantined(entry):
            return False
        for event in reversed(self.list_events(entry_id=entry.id, limit=100)):
            if event.event_type == "unquarantined":
                return False
            if event.event_type == "quarantined":
                return event.metadata_json.get("reason") == "consolidation_retention"
        return False

    def _audit(self, action: str, payload: dict[str, Any]) -> None:
        if self._audit_hook is not None:
            self._audit_hook(action, payload)

    def _redact_export_value(self, value: Any) -> Any:
        if not isinstance(value, str):
            return value
        redacted, _ = self._pii_detector.redact(value)
        return redacted

    @classmethod
    def _looks_instruction_like(cls, text: str) -> bool:
        lowered = text.lower()
        if "do not" in lowered and "instructions" in lowered:
            return True
        return any(pattern.search(text) for pattern in cls._INSTRUCTION_PATTERNS)

    @staticmethod
    def _looks_suspicious(text: str) -> bool:
        lowered = text.lower()
        suspicious_tokens = ("cc attacker", "exfiltrate", "bypass", "steal")
        return any(token in lowered for token in suspicious_tokens)

    @classmethod
    def _fails_minimum_signal(cls, *, key: str, value: Any) -> bool:
        if isinstance(value, (dict, list, tuple, set)):
            text = json.dumps(
                value,
                ensure_ascii=False,
                sort_keys=True,
                separators=(",", ":"),
                default=str,
            )
        else:
            text = str(value)
        normalized = " ".join(text.split()).strip()
        if not normalized:
            return True
        lowered = normalized.lower().strip(" \t\r\n.,;:!?\"'")
        if not lowered:
            return True
        if lowered in cls._LOW_SIGNAL_PHRASES:
            return True

        tokens = [token.lower() for token in re.findall(r"[a-z0-9]+", lowered)]
        informative_tokens = [
            token for token in tokens if len(token) >= 3 and token not in cls._LOW_SIGNAL_TOKENS
        ]
        if len(informative_tokens) >= 2:
            return False
        if len(informative_tokens) == 1:
            token = informative_tokens[0]
            if len(token) >= 6:
                return False
            key_segments = [
                segment
                for segment in re.split(r"[._:-]+", key.lower())
                if segment and segment not in cls._GENERIC_KEY_SEGMENTS
            ]
            return not (len(token) >= 4 and bool(key_segments))
        return True
