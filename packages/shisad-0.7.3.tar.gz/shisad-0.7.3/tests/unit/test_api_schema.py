"""M0.T1: Schema validation rejects malformed control API requests."""

from __future__ import annotations

import pytest
from pydantic import ValidationError

from shisad.core.api.schema import (
    ActionConfirmResult,
    ActionPendingResult,
    ActionRejectResult,
    ChannelIngestResult,
    ChannelPairingProposalResult,
    ConfirmationMetricsResult,
    DaemonShutdownResult,
    DaemonStatusResult,
    DashboardMarkFalsePositiveResult,
    DashboardQueryResult,
    DoctorCheckResult,
    GraphExportParams,
    GraphQueryParams,
    JsonRpcRequest,
    LockdownSetResult,
    LockdownStatusResult,
    MemoryConsolidateParams,
    MemoryDeleteResult,
    MemoryEntryParams,
    MemoryExportParams,
    MemoryExportResult,
    MemoryGetResult,
    MemoryIngestParams,
    MemoryIngestProcedureCandidateParams,
    MemoryIngestResult,
    MemoryInvokeSkillParams,
    MemoryLifecycleParams,
    MemoryListParams,
    MemoryListResult,
    MemoryMintIngressParams,
    MemoryPromoteIdentityCandidateParams,
    MemoryPromoteSkillParams,
    MemoryReadOriginalParams,
    MemoryRejectIdentityCandidateParams,
    MemoryRetrieveParams,
    MemoryRetrieveResult,
    MemoryReviewQueueParams,
    MemoryRotateKeyResult,
    MemorySupersedeParams,
    MemoryTimelinePromoteParams,
    MemoryTimelineReadParams,
    MemoryTimelineReadResult,
    MemoryTimelineSearchParams,
    MemoryTimelineSearchResult,
    MemoryVerifyResult,
    MemoryWorkflowStateParams,
    MemoryWriteParams,
    MemoryWriteResult,
    NoteCreateParams,
    NoteEntryParams,
    NoteExportParams,
    NoteListParams,
    NoteSearchParams,
    PolicyExplainResult,
    RealityCheckReadResult,
    RealityCheckSearchResult,
    SessionCreateParams,
    SessionGrantCapabilitiesResult,
    SessionListResult,
    SessionMessageParams,
    SessionRollbackResult,
    SessionSetModeResult,
    SkillInstallResult,
    SkillListResult,
    SkillProfileResult,
    SkillReviewResult,
    SkillRevokeResult,
    TaskCreateParams,
    TaskCreateResult,
    TaskDisableResult,
    TaskListResult,
    TaskPendingConfirmationsResult,
    TaskTriggerEventResult,
    TodoCompleteParams,
    TodoCreateParams,
    TodoEntryParams,
    TodoExportParams,
    TodoListParams,
    ToolExecuteParams,
    ToolExecuteResult,
)


class TestApiSchemaValidation:
    """M0.T1: schema validation rejects malformed control API requests."""

    def test_valid_request(self) -> None:
        req = JsonRpcRequest(method="session.create", params={"user_id": "alice"}, id=1)
        assert req.method == "session.create"
        assert req.id == 1

    def test_missing_method_rejected(self) -> None:
        with pytest.raises(ValidationError):
            JsonRpcRequest.model_validate({"jsonrpc": "2.0", "id": 1})

    def test_session_message_missing_content(self) -> None:
        with pytest.raises(ValidationError):
            SessionMessageParams.model_validate({"session_id": "abc"})

    def test_session_create_defaults(self) -> None:
        params = SessionCreateParams()
        assert params.user_id == ""
        assert params.workspace_id == ""
        assert params.tone is None

    def test_session_create_tone_accepts_known_values(self) -> None:
        params = SessionCreateParams(tone="friendly")
        assert params.tone == "friendly"

    def test_session_create_tone_rejects_unknown_values(self) -> None:
        with pytest.raises(ValidationError):
            SessionCreateParams(tone="casual")

    def test_task_create_requires_workspace_id(self) -> None:
        with pytest.raises(ValidationError):
            TaskCreateParams(
                schedule={"kind": "event", "expression": "message.received"},
                name="scan",
                goal="scan logs",
                policy_snapshot_ref="policy-1",
                created_by="alice",
            )

    def test_tool_execute_rejects_empty_command(self) -> None:
        with pytest.raises(ValidationError):
            ToolExecuteParams.model_validate(
                {
                    "session_id": "s1",
                    "tool_name": "shell_exec",
                    "command": [],
                }
            )

    def test_tool_execute_accepts_structured_arguments_map(self) -> None:
        params = ToolExecuteParams.model_validate(
            {
                "session_id": "s1",
                "tool_name": "retrieve_rag",
                "command": ["python", "-c", "print('ok')"],
                "arguments": {"query": "roadmap", "limit": 3},
            }
        )
        assert params.arguments == {"query": "roadmap", "limit": 3}

    def test_tool_execute_rejects_non_mapping_arguments(self) -> None:
        with pytest.raises(ValidationError):
            ToolExecuteParams.model_validate(
                {
                    "session_id": "s1",
                    "tool_name": "retrieve_rag",
                    "command": ["python", "-c", "print('ok')"],
                    "arguments": ["query", "roadmap"],
                }
            )

    def test_tool_execute_result_preserves_confirmation_fields(self) -> None:
        result = ToolExecuteResult.model_validate(
            {
                "allowed": False,
                "reason": "control_plane_confirmation_required",
                "confirmation_required": True,
                "confirmation_id": "confirm-1",
                "decision_nonce": "nonce-1",
            }
        )
        dumped = result.model_dump(mode="json", exclude_unset=True)
        assert dumped["confirmation_required"] is True
        assert dumped["confirmation_id"] == "confirm-1"

    def test_session_rollback_result_validation(self) -> None:
        result = SessionRollbackResult.model_validate(
            {
                "rolled_back": True,
                "checkpoint_id": "cp-1",
                "session_id": "s1",
                "files_restored": 2,
                "files_deleted": 1,
                "restore_errors": [],
            }
        )
        assert result.rolled_back is True

    def test_session_grant_capabilities_result_defaults(self) -> None:
        result = SessionGrantCapabilitiesResult.model_validate(
            {"session_id": "s1", "granted": True}
        )
        assert result.capabilities == []

    def test_confirmation_result_models_accept_runtime_shapes(self) -> None:
        pending = ActionPendingResult.model_validate({"actions": [{"id": "x"}], "count": 1})
        confirm = ActionConfirmResult.model_validate(
            {
                "confirmed": False,
                "confirmation_id": "c1",
                "reason": "cooldown_active",
                "retry_after_seconds": 0.5,
            }
        )
        reject = ActionRejectResult.model_validate(
            {"rejected": True, "confirmation_id": "c2", "status": "rejected"}
        )
        metrics = ConfirmationMetricsResult.model_validate(
            {"metrics": [{"user_id": "alice"}], "count": 1}
        )
        assert pending.count == 1
        assert confirm.retry_after_seconds == 0.5
        assert reject.status == "rejected"
        assert metrics.count == 1

    def test_m1_additional_result_models_accept_runtime_shapes(self) -> None:
        memory_ingest = MemoryIngestResult.model_validate(
            {
                "chunk_id": "m1",
                "source_id": "src-1",
                "source_type": "user",
                "collection": "user_curated",
                "created_at": "2026-02-13T00:00:00+00:00",
                "content_sanitized": "safe",
                "risk_score": 0.1,
                "original_hash": "h1",
            }
        )
        memory_retrieve = MemoryRetrieveResult.model_validate(
            {
                "results": [
                    {
                        "chunk_id": "m1",
                        "source_id": "src-1",
                        "source_type": "user",
                        "collection": "user_curated",
                        "created_at": "2026-02-13T00:00:00+00:00",
                        "content_sanitized": "safe",
                        "risk_score": 0.1,
                        "original_hash": "h1",
                    }
                ],
                "count": 1,
            }
        )
        memory_write = MemoryWriteResult.model_validate({"kind": "allow", "entry": {"id": "e1"}})
        memory_reject = MemoryWriteResult.model_validate(
            {
                "kind": "reject",
                "reason": "preference_predicate_invalid",
                "reason_detail": "Preference predicates must use function-call form.",
                "hint": "Use prefers(response_style).",
            }
        )
        memory_list = MemoryListResult.model_validate(
            {"entries": [{"id": "e1", "entry_type": "fact", "key": "k1"}], "count": 1}
        )
        memory_get = MemoryGetResult.model_validate({"entry": {"id": "e1"}})
        memory_delete = MemoryDeleteResult.model_validate({"deleted": True, "entry_id": "e1"})
        memory_export = MemoryExportResult.model_validate({"format": "json", "data": {}})
        memory_verify = MemoryVerifyResult.model_validate({"verified": True, "entry_id": "e1"})
        memory_rotate = MemoryRotateKeyResult.model_validate(
            {"rotated": True, "active_key_id": "k1", "reencrypt_existing": False}
        )
        skill_list = SkillListResult.model_validate({"skills": [], "count": 0})
        skill_review = SkillReviewResult.model_validate({"signature": "trusted"})
        skill_install = SkillInstallResult.model_validate({"allowed": True, "status": "installed"})
        skill_profile = SkillProfileResult.model_validate({"network_domains": []})
        skill_revoke = SkillRevokeResult.model_validate(
            {"revoked": True, "skill_name": "s1", "reason": "manual"}
        )
        task_create = TaskCreateResult.model_validate({"id": "t1"})
        task_list = TaskListResult.model_validate(
            {"tasks": [{"id": "t1", "name": "demo", "enabled": True}], "count": 1}
        )
        session_list = SessionListResult.model_validate(
            {"sessions": [{"id": "s1", "state": "active", "user_id": "alice"}]}
        )
        task_disable = TaskDisableResult.model_validate({"disabled": True, "task_id": "t1"})
        task_trigger = TaskTriggerEventResult.model_validate({"runs": [], "count": 0})
        task_pending = TaskPendingConfirmationsResult.model_validate(
            {"task_id": "t1", "pending": [], "count": 0}
        )
        dashboard = DashboardQueryResult.model_validate(
            {
                "count": 1,
                "events": [{"event_type": "SessionCreated", "session_id": "s1"}],
                "alerts": [{"event_id": "evt", "event_type": "AlertRaised"}],
                "timeline": [{"skill_name": "demo", "versions": ["1.0.0"]}],
            }
        )
        dashboard_marked = DashboardMarkFalsePositiveResult.model_validate(
            {"marked": True, "event_id": "evt", "reason": "manual"}
        )
        daemon_status = DaemonStatusResult.model_validate({"status": "running"})
        realitycheck_search = RealityCheckSearchResult.model_validate(
            {
                "ok": True,
                "query": "roadmap",
                "mode": "local",
                "results": [],
            }
        )
        realitycheck_read = RealityCheckReadResult.model_validate(
            {
                "ok": True,
                "path": "/tmp/source.md",
                "content": "hello",
                "sha256": "abc123",
            }
        )
        doctor = DoctorCheckResult.model_validate(
            {
                "status": "ok",
                "component": "realitycheck",
                "checks": {"realitycheck": {"status": "ok"}},
            }
        )
        daemon_shutdown = DaemonShutdownResult.model_validate({"status": "shutting_down"})
        policy_explain = PolicyExplainResult.model_validate(
            {
                "session_id": "s1",
                "tool_name": "shell_exec",
                "action": "run",
                "effective_policy": {},
                "control_plane": {},
                "contributors": {},
            }
        )
        lockdown = LockdownSetResult.model_validate(
            {"session_id": "s1", "level": "caution", "reason": "manual"}
        )
        lockdown_status = LockdownStatusResult.model_validate(
            {
                "statuses": [
                    {
                        "session_id": "s1",
                        "level": "caution",
                        "reason": "manual",
                        "trigger": "monitor",
                        "active": True,
                    }
                ],
                "count": 1,
            }
        )
        risk = ToolExecuteResult.model_validate(
            {"allowed": True, "exit_code": 0, "confirmation_required": False}
        )
        ingest = ChannelIngestResult.model_validate(
            {"session_id": "s1", "response": "ok", "ingress_risk": 0.1}
        )
        set_mode = SessionSetModeResult.model_validate(
            {"session_id": "s1", "mode": "admin_cleanroom", "changed": True}
        )
        pairing = ChannelPairingProposalResult.model_validate(
            {
                "proposal_id": "p1",
                "proposal_path": "/tmp/p1.json",
                "generated_at": "2026-02-15T00:00:00+00:00",
                "entries": [],
                "count": 0,
                "config_patch": {},
                "applied": False,
            }
        )
        assert memory_ingest.chunk_id == "m1"
        assert memory_retrieve.count == 1
        assert memory_write.kind == "allow"
        assert memory_reject.hint == "Use prefers(response_style)."
        assert memory_list.count == 1
        assert memory_list.entries[0].id == "e1"
        assert memory_get.entry == {"id": "e1"}
        assert memory_delete.deleted is True
        assert memory_export.format == "json"
        assert memory_verify.verified is True
        assert memory_rotate.active_key_id == "k1"
        assert skill_list.count == 0
        assert skill_review.signature == "trusted"
        assert skill_install.model_dump(mode="json")["status"] == "installed"
        assert skill_profile.network_domains == []
        assert skill_revoke.revoked is True
        assert task_create.model_dump(mode="json")["id"] == "t1"
        assert task_list.count == 1
        assert task_list.tasks[0].id == "t1"
        assert session_list.sessions[0].id == "s1"
        assert task_disable.disabled is True
        assert task_trigger.count == 0
        assert task_pending.task_id == "t1"
        assert dashboard.model_dump(mode="json")["count"] == 1
        assert dashboard.events[0].session_id == "s1"
        assert dashboard_marked.marked is True
        assert daemon_status.status == "running"
        assert daemon_status.delivery == {}
        assert daemon_status.realitycheck == {}
        assert realitycheck_search.mode == "local"
        assert realitycheck_read.path == "/tmp/source.md"
        assert doctor.component == "realitycheck"
        assert daemon_shutdown.status == "shutting_down"
        assert policy_explain.tool_name == "shell_exec"
        assert lockdown.level == "caution"
        assert lockdown_status.statuses[0].active is True
        inactive_status = LockdownStatusResult.model_validate(
            {"statuses": [{"session_id": "inactive"}], "count": 1}
        )
        assert inactive_status.statuses[0].mode == ""
        assert risk.allowed is True
        assert ingest.ingress_risk == 0.1
        assert set_mode.mode == "admin_cleanroom"
        assert pairing.proposal_id == "p1"

    def test_m1_memory_write_params_accept_ingress_context_shape(self) -> None:
        params = MemoryWriteParams.model_validate(
            {
                "ingress_context": "handle-1",
                "entry_type": "fact",
                "key": "profile.name",
                "value": "alice",
            }
        )

        assert params.ingress_context == "handle-1"
        assert params.derivation_path == "direct"

    def test_m1_memory_write_params_accept_multiuser_entry_types(self) -> None:
        params = MemoryWriteParams.model_validate(
            {
                "ingress_context": "handle-2",
                "entry_type": "inbox_item",
                "key": "inbox:owner-1:item-1",
                "value": {
                    "owner_id": "owner-1",
                    "sender_id": "guest-1",
                    "channel_id": "discord:guild/general",
                    "body": "Deploy is ready.",
                },
            }
        )

        assert params.entry_type == "inbox_item"

    def test_m4_ingest_procedure_candidate_params_reject_control_char_keys(self) -> None:
        base_params = {
            "ingress_context": "handle-procedure",
            "key": "procedure:release-close",
            "artifact": "Release close checklist",
            "target_entry_type": "skill",
            "target_key": "skill:release-close",
            "trace_ids": ["trace-1"],
            "trace_pool_hash": "trace-pool-hash",
            "user_id": "alice",
            "workspace_id": "ws1",
        }

        with pytest.raises(ValidationError, match="key contains unsafe control characters"):
            MemoryIngestProcedureCandidateParams.model_validate(
                {**base_params, "key": "procedure:release-close\u2028forged"}
            )
        with pytest.raises(ValidationError, match="key contains unsafe control characters"):
            MemoryIngestProcedureCandidateParams.model_validate(
                {**base_params, "key": "procedure:release-close\n"}
            )
        with pytest.raises(
            ValidationError,
            match="target_key contains unsafe control characters",
        ):
            MemoryIngestProcedureCandidateParams.model_validate(
                {**base_params, "target_key": "skill:release-close\u2029forged"}
            )
        with pytest.raises(
            ValidationError,
            match="target_key contains unsafe control characters",
        ):
            MemoryIngestProcedureCandidateParams.model_validate(
                {**base_params, "target_key": "\u2028skill:release-close"}
            )

    def test_m1_memory_ingest_params_accept_handle_bound_shape(self) -> None:
        params = MemoryIngestParams.model_validate(
            {
                "ingress_context": "handle-1",
                "content": "remember this",
                "content_digest": "sha256:abc",
                "derivation_path": "summary",
                "parent_digest": "sha256:parent",
            }
        )

        assert params.ingress_context == "handle-1"

    def test_m1_memory_ingest_params_require_ingress_context_and_reject_raw_source_fields(
        self,
    ) -> None:
        with pytest.raises(ValidationError):
            MemoryIngestParams.model_validate({"content": "hello"})

        with pytest.raises(ValidationError):
            MemoryIngestParams.model_validate(
                {
                    "source_id": "src-1",
                    "source_type": "external",
                    "content": "hello",
                }
            )

    def test_m4_memory_read_original_params_require_chunk_id(self) -> None:
        params = MemoryReadOriginalParams.model_validate({"chunk_id": "chunk-1"})

        assert params.chunk_id == "chunk-1"

        with pytest.raises(ValidationError):
            MemoryReadOriginalParams.model_validate({})

        with pytest.raises(ValidationError):
            MemoryReadOriginalParams.model_validate({"chunk_id": "   "})

    def test_m4_memory_invoke_skill_params_require_skill_id(self) -> None:
        params = MemoryInvokeSkillParams.model_validate(
            {"skill_id": "skill-1", "user_id": "alice", "workspace_id": "ws1"}
        )

        assert params.skill_id == "skill-1"
        assert params.user_id == "alice"
        assert params.workspace_id == "ws1"

        with pytest.raises(ValidationError):
            MemoryInvokeSkillParams.model_validate({})

        with pytest.raises(ValidationError):
            MemoryInvokeSkillParams.model_validate({"skill_id": "   "})

        with pytest.raises(ValidationError):
            MemoryInvokeSkillParams.model_validate({"skill_id": "skill-1"})

    def test_m4_memory_promote_skill_params_require_handle_and_entry_id(self) -> None:
        params = MemoryPromoteSkillParams.model_validate(
            {
                "ingress_context": "handle-1",
                "entry_id": "skill-1",
                "user_id": "alice",
                "workspace_id": "ws1",
            }
        )

        assert params.ingress_context == "handle-1"
        assert params.entry_id == "skill-1"
        assert params.user_id == "alice"
        assert params.workspace_id == "ws1"

        with pytest.raises(ValidationError):
            MemoryPromoteSkillParams.model_validate({"entry_id": "skill-1"})

        with pytest.raises(ValidationError):
            MemoryPromoteSkillParams.model_validate({"ingress_context": "handle-1"})

        with pytest.raises(ValidationError):
            MemoryPromoteSkillParams.model_validate(
                {"ingress_context": "handle-1", "entry_id": "skill-1"}
            )

    def test_m1_memory_write_params_require_ingress_context(self) -> None:
        with pytest.raises(ValidationError):
            MemoryWriteParams.model_validate(
                {
                    "entry_type": "fact",
                    "key": "profile.name",
                    "value": "alice",
                }
            )

    def test_m1_memory_mint_ingress_params_accept_user_shape(self) -> None:
        params = MemoryMintIngressParams.model_validate({"content": {"name": "alice"}})

        assert params.source_type == "user"
        assert params.user_confirmed is False

    def test_m1_memory_mint_ingress_params_reject_confirmed_non_user_shapes(self) -> None:
        with pytest.raises(ValidationError, match="user_confirmed requires source_type=user"):
            MemoryMintIngressParams.model_validate(
                {
                    "content": "tool output",
                    "source_type": "tool",
                    "user_confirmed": True,
                }
            )

    def test_m1_memory_write_params_accept_canonical_and_legacy_entry_type_aliases(self) -> None:
        canonical = MemoryWriteParams.model_validate(
            {
                "ingress_context": "handle-1",
                "entry_type": "soft_constraint",
                "key": "behavior.reply_style",
                "value": "keep replies short",
            }
        )
        legacy = MemoryWriteParams.model_validate(
            {
                "ingress_context": "handle-2",
                "entry_type": "context",
                "key": "legacy.context",
                "value": "remember this",
            }
        )

        assert canonical.entry_type == "soft_constraint"
        assert legacy.entry_type == "context"

    def test_m1_memory_write_params_accept_preference_predicate_fields(self) -> None:
        params = MemoryWriteParams.model_validate(
            {
                "ingress_context": "handle-1",
                "entry_type": "preference",
                "key": "food.preference",
                "value": "prefers coffee over tea",
                "predicate": "prefers(coffee, over: tea)",
                "strength": "strong",
            }
        )

        assert params.predicate == "prefers(coffee, over: tea)"
        assert params.strength == "strong"

    def test_m1_memory_write_params_reject_legacy_source_and_orphaned_binding_fields(self) -> None:
        with pytest.raises(ValidationError):
            MemoryWriteParams.model_validate(
                {
                    "entry_type": "fact",
                    "key": "profile.name",
                    "value": "alice",
                    "source": {
                        "origin": "user",
                        "source_id": "msg-1",
                        "extraction_method": "cli",
                    },
                }
            )

        with pytest.raises(ValidationError):
            MemoryWriteParams.model_validate(
                {
                    "entry_type": "fact",
                    "key": "profile.name",
                    "value": "alice",
                    "content_digest": "sha256:abc",
                }
            )

    def test_m1_memory_supersede_params_require_non_empty_target(self) -> None:
        params = MemorySupersedeParams.model_validate(
            {
                "ingress_context": "handle-1",
                "entry_type": "note",
                "key": "note:chain",
                "value": "updated",
                "supersedes": "entry-1",
                "user_id": "alice",
                "workspace_id": "ws1",
            }
        )

        assert params.supersedes == "entry-1"
        assert params.user_id == "alice"
        assert params.workspace_id == "ws1"

        with pytest.raises(ValidationError):
            MemorySupersedeParams.model_validate(
                {
                    "ingress_context": "handle-1",
                    "entry_type": "note",
                    "key": "note:chain",
                    "value": "updated",
                    "supersedes": "",
                    "user_id": "alice",
                    "workspace_id": "ws1",
                }
            )

    def test_m7_review_and_raw_id_mutations_require_owner_scope(self) -> None:
        owner_scope = {"user_id": "alice", "workspace_id": "ws1"}

        assert (
            MemoryReviewQueueParams.model_validate(
                {"limit": 10, "include_unowned": True, **owner_scope}
            ).include_unowned
            is True
        )
        assert (
            MemoryListParams.model_validate(
                {"limit": 10, "include_unowned": True, **owner_scope}
            ).include_unowned
            is True
        )
        assert (
            MemoryPromoteIdentityCandidateParams.model_validate(
                {
                    "ingress_context": "handle-1",
                    "candidate_id": "candidate-1",
                    "include_unowned": True,
                    **owner_scope,
                }
            ).include_unowned
            is True
        )
        assert (
            MemoryPromoteSkillParams.model_validate(
                {
                    "ingress_context": "handle-1",
                    "entry_id": "skill-candidate-1",
                    "include_unowned": True,
                    **owner_scope,
                }
            ).include_unowned
            is True
        )
        assert (
            MemoryRejectIdentityCandidateParams.model_validate(
                {
                    "ingress_context": "handle-1",
                    "candidate_id": "candidate-1",
                    "include_unowned": True,
                    **owner_scope,
                }
            ).include_unowned
            is True
        )
        assert (
            MemoryWriteParams.model_validate(
                {
                    "ingress_context": "handle-1",
                    "entry_type": "note",
                    "key": "note:chain",
                    "value": "updated",
                    "supersedes": "entry-1",
                    **owner_scope,
                }
            ).supersedes
            == "entry-1"
        )
        assert (
            MemoryWorkflowStateParams.model_validate(
                {
                    "entry_id": "entry-1",
                    "workflow_state": "closed",
                    **owner_scope,
                }
            ).user_id
            == "alice"
        )
        assert (
            MemoryWriteParams.model_validate(
                {
                    "ingress_context": "handle-1",
                    "entry_type": "note",
                    "key": "note:chain",
                    "value": "updated",
                    "supersedes": "entry-1",
                    "include_unowned": True,
                    **owner_scope,
                }
            ).include_unowned
            is True
        )
        assert (
            MemoryWorkflowStateParams.model_validate(
                {
                    "entry_id": "entry-1",
                    "workflow_state": "closed",
                    "include_unowned": True,
                    **owner_scope,
                }
            ).include_unowned
            is True
        )
        assert (
            MemoryEntryParams.model_validate({"entry_id": "entry-1", **owner_scope}).user_id
            == "alice"
        )
        assert (
            MemoryEntryParams.model_validate(
                {"entry_id": "entry-1", "include_unowned": True, **owner_scope}
            ).include_unowned
            is True
        )
        assert (
            MemoryLifecycleParams.model_validate(
                {"entry_id": "entry-1", "reason": "manual-review", **owner_scope}
            ).workspace_id
            == "ws1"
        )
        assert (
            MemoryLifecycleParams.model_validate(
                {
                    "entry_id": "entry-1",
                    "reason": "manual-review",
                    "include_unowned": True,
                    **owner_scope,
                }
            ).include_unowned
            is True
        )
        assert (
            MemoryExportParams.model_validate(
                {"format": "json", "include_unowned": True, **owner_scope}
            ).include_unowned
            is True
        )

        ownerless_payloads: list[tuple[type[object], dict[str, object]]] = [
            (MemoryListParams, {"limit": 10}),
            (MemoryListParams, {"limit": 10, "include_unowned": True}),
            (MemoryReviewQueueParams, {"limit": 10}),
            (MemoryReviewQueueParams, {"limit": 10, "include_unowned": True}),
            (MemoryEntryParams, {"entry_id": "entry-1"}),
            (MemoryEntryParams, {"entry_id": "entry-1", "include_unowned": True}),
            (MemoryLifecycleParams, {"entry_id": "entry-1", "reason": "manual-review"}),
            (
                MemoryLifecycleParams,
                {"entry_id": "entry-1", "reason": "manual-review", "include_unowned": True},
            ),
            (MemoryExportParams, {"format": "json"}),
            (MemoryExportParams, {"format": "json", "include_unowned": True}),
            (
                MemoryPromoteIdentityCandidateParams,
                {"ingress_context": "handle-1", "candidate_id": "candidate-1"},
            ),
            (
                MemoryPromoteSkillParams,
                {"ingress_context": "handle-1", "entry_id": "skill-candidate-1"},
            ),
            (
                MemoryRejectIdentityCandidateParams,
                {"ingress_context": "handle-1", "candidate_id": "candidate-1"},
            ),
            (
                MemoryWriteParams,
                {
                    "ingress_context": "handle-1",
                    "entry_type": "note",
                    "key": "note:chain",
                    "value": "updated",
                    "supersedes": "entry-1",
                },
            ),
            (
                MemoryWriteParams,
                {
                    "ingress_context": "handle-1",
                    "entry_type": "note",
                    "key": "note:chain",
                    "value": "updated",
                    "supersedes": "entry-1",
                    "include_unowned": True,
                },
            ),
            (
                MemorySupersedeParams,
                {
                    "ingress_context": "handle-1",
                    "entry_type": "note",
                    "key": "note:chain",
                    "value": "updated",
                    "supersedes": "entry-1",
                },
            ),
            (
                MemoryWorkflowStateParams,
                {"entry_id": "entry-1", "workflow_state": "closed"},
            ),
            (
                MemoryWorkflowStateParams,
                {
                    "entry_id": "entry-1",
                    "workflow_state": "closed",
                    "include_unowned": True,
                },
            ),
        ]
        for params_type, payload in ownerless_payloads:
            with pytest.raises(ValidationError):
                params_type.model_validate(payload)  # type: ignore[attr-defined]

    def test_c2_memory_retrieve_params_accept_owner_scope_fields(self) -> None:
        params = MemoryRetrieveParams.model_validate(
            {
                "query": "owner scoped recall",
                "user_id": "user-1",
                "workspace_id": "ws-1",
            }
        )

        assert params.user_id == "user-1"
        assert params.workspace_id == "ws-1"

        with pytest.raises(ValidationError):
            MemoryRetrieveParams.model_validate(
                {
                    "query": "owner scoped recall",
                    "user_id": "user-1",
                    "workspace_id": "ws-1",
                    "include_unowned": True,
                }
            )

        with pytest.raises(ValidationError):
            MemoryRetrieveParams.model_validate(
                {
                    "query": "owner scoped recall",
                    "owner_id": "user-1",
                }
            )

    def test_m5_memory_timeline_params_require_complete_owner_scope(self) -> None:
        search = MemoryTimelineSearchParams.model_validate(
            {
                "query": "lunch last time",
                "user_id": "alice",
                "workspace_id": "ws-1",
                "context_delivery_target": {
                    "channel": "discord",
                    "recipient": "room-a",
                    "workspace_hint": "guild-1",
                    "thread_id": "thread-1",
                },
            }
        )
        read = MemoryTimelineReadParams.model_validate(
            {
                "handle": "tl-abc",
                "user_id": "alice",
                "workspace_id": "ws-1",
            }
        )
        promote = MemoryTimelinePromoteParams.model_validate(
            {
                "handle": "tl-abc",
                "ingress_context": "ingress-1",
                "entry_type": "fact",
                "key": "timeline:lunch",
                "user_id": "alice",
                "workspace_id": "ws-1",
            }
        )

        assert search.context_channel == "cli"
        assert search.allow_private_history is False
        assert search.limit == 10
        assert read.surrounding == 1
        assert promote.confidence == 0.8
        search_empty_target = MemoryTimelineSearchParams.model_validate(
            {
                "query": "lunch last time",
                "user_id": "alice",
                "workspace_id": "ws-1",
                "context_session_id": " session-1 ",
                "context_delivery_target": {},
            }
        )
        assert search_empty_target.context_session_id == "session-1"
        assert search_empty_target.context_delivery_target is None

        ownerless_payloads: list[tuple[type[object], dict[str, object]]] = [
            (MemoryTimelineSearchParams, {"query": "lunch", "user_id": "alice"}),
            (MemoryTimelineSearchParams, {"query": "lunch", "workspace_id": "ws-1"}),
            (
                MemoryTimelineReadParams,
                {"handle": "tl-abc", "user_id": "alice"},
            ),
            (
                MemoryTimelinePromoteParams,
                {
                    "handle": "tl-abc",
                    "ingress_context": "ingress-1",
                    "entry_type": "fact",
                    "key": "timeline:lunch",
                    "workspace_id": "ws-1",
                },
            ),
        ]
        for params_type, payload in ownerless_payloads:
            with pytest.raises(ValidationError):
                params_type.model_validate(payload)  # type: ignore[attr-defined]

    def test_m5_memory_timeline_result_models_accept_runtime_shapes(self) -> None:
        search = MemoryTimelineSearchResult.model_validate(
            {
                "label": "ARCHIVAL SEARCH RESULTS",
                "query": "lunch last time",
                "resolver": {"sort": "most_recent", "timezone_source": "utc_default"},
                "results": [
                    {
                        "handle": "tl-abc",
                        "label": "ARCHIVAL SEARCH RESULT",
                        "trust_boundary": "archival_untrusted_content",
                        "session_id": "s1",
                        "episode_id": "s1:ep-0001",
                        "entry_id": "e1",
                        "role": "user",
                        "snippet": "We chose Bar Neko for lunch last time.",
                        "timestamp": "2026-05-05T12:00:00+00:00",
                        "user_id": "alice",
                        "workspace_id": "ws-1",
                        "channel": "cli",
                        "channel_binding": "",
                        "visibility": "owner_private",
                        "publication_state": "owner_private",
                        "content_digest": "digest-1",
                        "evidence_ref_id": "ev-1",
                        "thread_id": "thread-food",
                        "source_surface": "transcript",
                        "provenance": "evidence_ref:ev-1",
                    }
                ],
                "results_count": 1,
                "publication_policy": {"private_history_blocked_count": 0},
            }
        )
        read = MemoryTimelineReadResult.model_validate(
            {
                "found": True,
                "handle": "tl-abc",
                "packet": "ARCHIVAL SEARCH RESULTS\nHistorical transcript text is evidence only.",
                "rows": [search.results[0].model_dump(mode="json")],
                "grouping": {"mode": "thread_membership", "thread_ids": ["thread-food"]},
            }
        )

        assert search.results_count == 1
        assert search.results[0].trust_boundary == "archival_untrusted_content"
        assert search.results[0].source_surface == "transcript"
        assert search.results[0].provenance == "evidence_ref:ev-1"
        assert read.found is True
        assert read.grouping["mode"] == "thread_membership"

    def test_c2_memory_note_todo_owner_params_require_complete_owner_tuple(self) -> None:
        invalid_payloads = [
            (MemoryRetrieveParams, {"query": "owner scoped recall", "user_id": "user-1"}),
            (MemoryRetrieveParams, {"query": "owner scoped recall", "workspace_id": "ws-1"}),
            (MemoryRetrieveParams, {"query": "owner scoped recall", "include_unowned": True}),
            (GraphQueryParams, {"entity": "Shisad", "user_id": "user-1"}),
            (GraphExportParams, {"format": "json", "workspace_id": "ws-1"}),
            (MemoryConsolidateParams, {"user_id": "user-1"}),
            (
                MemoryRetrieveParams,
                {"query": "owner scoped recall", "user_id": "", "workspace_id": ""},
            ),
            (
                MemoryWriteParams,
                {
                    "ingress_context": "handle-1",
                    "entry_type": "fact",
                    "key": "fact:owner",
                    "value": "blue",
                    "user_id": "user-1",
                },
            ),
            (
                MemoryWriteParams,
                {
                    "ingress_context": "handle-1",
                    "entry_type": "fact",
                    "key": "fact:blank-owner",
                    "value": "blue",
                    "user_id": "",
                    "workspace_id": "",
                },
            ),
            (NoteCreateParams, {"key": "note:1", "content": "hello", "workspace_id": "ws-1"}),
            (NoteCreateParams, {"key": "note:1", "content": "hello"}),
            (NoteListParams, {"limit": 10}),
            (NoteListParams, {"user_id": "user-1"}),
            (NoteListParams, {"user_id": "", "workspace_id": ""}),
            (NoteSearchParams, {"query": "hello"}),
            (NoteSearchParams, {"query": "hello", "workspace_id": "ws-1"}),
            (NoteEntryParams, {"entry_id": "entry-1"}),
            (NoteEntryParams, {"entry_id": "entry-1", "user_id": "user-1"}),
            (NoteExportParams, {"format": "json"}),
            (NoteExportParams, {"format": "json", "include_unowned": True}),
            (TodoCreateParams, {"title": "task", "user_id": "user-1"}),
            (TodoCreateParams, {"title": "task"}),
            (TodoListParams, {"limit": 10}),
            (TodoListParams, {"workspace_id": "ws-1"}),
            (TodoListParams, {"user_id": "", "workspace_id": ""}),
            (TodoEntryParams, {"entry_id": "entry-1"}),
            (TodoEntryParams, {"entry_id": "entry-1", "user_id": "user-1"}),
            (TodoCompleteParams, {"selector": "task"}),
            (TodoCompleteParams, {"selector": "task", "workspace_id": "ws-1"}),
            (TodoExportParams, {"format": "json"}),
            (TodoExportParams, {"format": "json", "include_unowned": True}),
        ]

        for model_type, payload in invalid_payloads:
            with pytest.raises(ValidationError):
                model_type.model_validate(payload)

        note = NoteExportParams.model_validate(
            {
                "format": "json",
                "user_id": " user-1 ",
                "workspace_id": " ws-1 ",
                "include_unowned": True,
            }
        )
        todo = TodoExportParams.model_validate(
            {
                "format": "csv",
                "user_id": "user-1",
                "workspace_id": "ws-1",
            }
        )

        assert note.user_id == "user-1"
        assert note.workspace_id == "ws-1"
        assert note.include_unowned is True
        assert todo.user_id == "user-1"
        assert todo.workspace_id == "ws-1"

    def test_m1_note_and_todo_params_reject_legacy_trust_fields(self) -> None:
        with pytest.raises(ValidationError):
            NoteCreateParams.model_validate(
                {
                    "key": "note:1",
                    "content": "hello",
                    "origin": "external",
                }
            )

        with pytest.raises(ValidationError):
            TodoCreateParams.model_validate(
                {
                    "title": "task",
                    "origin": "external",
                }
            )

        note = NoteCreateParams.model_validate(
            {
                "key": "note:2",
                "content": "hello",
                "ingress_context": "handle-2",
                "content_digest": "sha256:def",
                "derivation_path": "extracted",
                "parent_digest": "sha256:parent",
                "user_id": "user-1",
                "workspace_id": "ws-1",
            }
        )
        todo = TodoCreateParams.model_validate(
            {
                "title": "task",
                "ingress_context": "handle-3",
                "content_digest": "sha256:ghi",
                "derivation_path": "summary",
                "parent_digest": "sha256:parent",
                "user_id": "user-1",
                "workspace_id": "ws-1",
            }
        )

        assert note.ingress_context == "handle-2"
        assert todo.ingress_context == "handle-3"

        compat_note = NoteCreateParams.model_validate(
            {
                "key": "note:compat",
                "content": "hello",
                "source_id": "session-1",
                "user_confirmed": True,
                "user_id": "user-1",
                "workspace_id": "ws-1",
            }
        )
        compat_todo = TodoCreateParams.model_validate(
            {
                "title": "task",
                "source_id": "session-1",
                "user_confirmed": True,
                "user_id": "user-1",
                "workspace_id": "ws-1",
            }
        )

        assert compat_note.source_id == "session-1"
        assert compat_note.user_confirmed is True
        assert compat_todo.source_id == "session-1"
        assert compat_todo.user_confirmed is True

    def test_m1_memory_lifecycle_params_require_reason_and_valid_workflow_state(self) -> None:
        params = MemoryLifecycleParams.model_validate(
            {
                "entry_id": "entry-1",
                "reason": "manual-review",
                "user_id": "alice",
                "workspace_id": "ws1",
            }
        )
        workflow = MemoryWorkflowStateParams.model_validate(
            {
                "entry_id": "entry-1",
                "workflow_state": "closed",
                "user_id": "alice",
                "workspace_id": "ws1",
            }
        )

        assert params.reason == "manual-review"
        assert workflow.workflow_state == "closed"

        with pytest.raises(ValidationError):
            MemoryLifecycleParams.model_validate(
                {
                    "entry_id": "entry-1",
                    "reason": "",
                    "user_id": "alice",
                    "workspace_id": "ws1",
                }
            )

    def test_m7_memory_retrieve_params_bound_sufficiency_coverage(self) -> None:
        low = MemoryRetrieveParams.model_validate(
            {"query": "release recall", "min_sufficiency_coverage": 0.0}
        )
        high = MemoryRetrieveParams.model_validate(
            {"query": "release recall", "min_sufficiency_coverage": 1.0}
        )

        assert low.min_sufficiency_coverage == 0.0
        assert high.min_sufficiency_coverage == 1.0
        with pytest.raises(ValidationError):
            MemoryRetrieveParams.model_validate(
                {"query": "release recall", "min_sufficiency_coverage": -0.1}
            )
        with pytest.raises(ValidationError):
            MemoryRetrieveParams.model_validate(
                {"query": "release recall", "min_sufficiency_coverage": 1.1}
            )

    def test_m1_memory_list_params_gate_quarantined_reads_on_confirmation(self) -> None:
        with pytest.raises(ValidationError):
            MemoryListParams.model_validate(
                {"include_quarantined": True, "user_id": "alice", "workspace_id": "ws1"}
            )

        params = MemoryListParams.model_validate(
            {
                "include_quarantined": True,
                "confirmed": True,
                "limit": 5,
                "user_id": "alice",
                "workspace_id": "ws1",
            }
        )
        assert params.include_quarantined is True
        assert params.confirmed is True

    def test_m1_memory_entry_params_gate_quarantined_reads_on_confirmation(self) -> None:
        with pytest.raises(ValidationError):
            MemoryEntryParams.model_validate(
                {
                    "entry_id": "e1",
                    "include_quarantined": True,
                    "user_id": "alice",
                    "workspace_id": "ws1",
                }
            )

        params = MemoryEntryParams.model_validate(
            {
                "entry_id": "e1",
                "include_quarantined": True,
                "confirmed": True,
                "user_id": "alice",
                "workspace_id": "ws1",
            }
        )
        assert params.include_quarantined is True
        assert params.confirmed is True

    def test_m4_list_entry_models_preserve_additional_payload_fields(self) -> None:
        memory_list = MemoryListResult.model_validate(
            {
                "entries": [
                    {
                        "entry_id": "e1",
                        "entry_type": "fact",
                        "key": "favorite_color",
                        "value": "blue",
                        "created_at": "2026-02-13T00:00:00+00:00",
                    }
                ],
                "count": 1,
            }
        )
        action_pending = ActionPendingResult.model_validate(
            {
                "actions": [
                    {
                        "confirmation_id": "c1",
                        "status": "pending",
                        "tool_name": "http_request",
                        "extra_runtime_field": "kept",
                    }
                ],
                "count": 1,
            }
        )

        memory_dump = memory_list.model_dump(mode="json")
        action_dump = action_pending.model_dump(mode="json")
        assert memory_dump["entries"][0]["value"] == "blue"
        assert action_dump["actions"][0]["extra_runtime_field"] == "kept"
