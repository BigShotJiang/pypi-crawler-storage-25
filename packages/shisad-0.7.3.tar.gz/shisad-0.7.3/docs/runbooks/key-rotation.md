# Memory Export + Key Rotation Runbook

## 1. When to run this

- Before scheduled key rotation
- Immediately after suspected memory/retrieval data exposure
- Before risky storage maintenance that should have a human-readable backup artifact

## 2. Preparation

- Ensure daemon health is stable:

  ```bash
  shisad status
  shisad audit verify
  ```

- Confirm low active write load if possible.
- Pick an export destination outside the active data dir, for example `/var/backups/shisad/`.
- Select the owner scope to back up. Memory list/export operations are
  owner-scoped; repeat the export for each `(user, workspace)` pair that needs
  a backup. Set `--include-unowned` only when intentionally carrying forward
  legacy ownerless rows into that owner-scoped maintenance export.
- Export artifacts contain raw memory entry values and metadata and may include
  personal data, channel content, or secrets copied into memory. Write them
  only to operator-controlled paths; anyone who can read the backup file can
  read that content.

## 3. Export current memory

Canonical JSON export:

```bash
mkdir -p /var/backups/shisad
SHISAD_MEMORY_USER=alice
SHISAD_MEMORY_WORKSPACE=ws1
shisad memory export \
  --format json \
  --user "$SHISAD_MEMORY_USER" \
  --workspace "$SHISAD_MEMORY_WORKSPACE" \
  > /var/backups/shisad/memory-${SHISAD_MEMORY_USER}-${SHISAD_MEMORY_WORKSPACE}-$(date +%F).json
```

Optional CSV export for spreadsheet/audit review:

```bash
shisad memory export \
  --format csv \
  --user "$SHISAD_MEMORY_USER" \
  --workspace "$SHISAD_MEMORY_WORKSPACE" \
  > /var/backups/shisad/memory-${SHISAD_MEMORY_USER}-${SHISAD_MEMORY_WORKSPACE}-$(date +%F).csv
```

Confirm the export file is non-empty and parseable before continuing.

## 4. Execute rotation

Rotate with re-encryption (preferred):

```bash
shisad memory rotate-key
```

Fast rotation without re-encryption (emergency stopgap):

```bash
shisad memory rotate-key --no-reencrypt
```

## 5. Validation

Validate the audit trail and read-path health:

```bash
shisad dashboard audit --search "memory.rotate_key" --limit 50
shisad memory list --limit 20 --user "$SHISAD_MEMORY_USER" --workspace "$SHISAD_MEMORY_WORKSPACE"
```

Confirm:
- new active key ID emitted
- no decrypt failures on existing entries
- the exported backup artifact is retained with the change record / incident ticket

## 6. Post-rotation

- Record rotation in change log/ticket
- Revoke superseded key material per environment policy
- If emergency path used, schedule full re-encryption follow-up
