# Bundled role definitions
