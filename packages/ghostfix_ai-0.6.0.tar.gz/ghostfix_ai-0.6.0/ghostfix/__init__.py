"""GhostFix package."""

