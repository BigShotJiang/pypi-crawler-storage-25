from typing import List, Optional, Literal
from pathlib import Path
import xarray as xr

import vame
from vame.util.auxiliary import read_states
from vame.io.load_poses import load_vame_dataset
from vame.visualization import (
    visualize_preprocessing_scatter,
    visualize_preprocessing_timeseries,
    visualize_preprocessing_cloud,
    plot_loss,
    visualize_motif_thresholding,
    visualize_hierarchical_tree,
    visualize_umap,
    generate_reports,
)
from vame.logging.logger import VameLogger


logger_config = VameLogger(__name__)
logger = logger_config.logger


class VAMEPipeline:
    """VAME pipeline class."""

    def __init__(
        self,
        project_name: str,
        poses_estimations: List[str],
        source_software: Literal["DeepLabCut", "SLEAP", "LightningPose", "NWB"],
        working_directory: str = ".",
        videos: Optional[List[str]] = None,
        video_type: str = ".mp4",
        fps: Optional[float] = None,
        copy_videos: bool = False,
        processing_module_key: str = "behavior",
        pose_estimation_key: str = "PoseEstimation",
        config_kwargs: Optional[dict] = None,
        save_logs=True,
    ) -> None:
        """
        Initializes the VAME pipeline.

        Parameters
        ----------
        project_name : str
            Project name.
        videos : List[str]
            List of video files.
        poses_estimations : List[str]
            List of pose estimation files.
        source_software : Literal["DeepLabCut", "SLEAP", "LightningPose", "NWB"]
            Source software used for pose estimation. Use "NWB" to read an
            ``ndx-pose`` PoseEstimation from an NWB file.
        working_directory : str, optional
            Working directory, by default ".".
        video_type : str, optional
            Video file type, by default ".mp4".
        fps : int, optional
            Sampling rate of the videos. If not passed, it will be estimated from the video file. By default None.
        copy_videos : bool, optional
            Copy videos, by default False.
        processing_module_key : str, optional
            Only used when ``source_software="NWB"``. Name of the NWB processing
            module that contains the pose estimation container. Defaults to "behavior".
        pose_estimation_key : str, optional
            Only used when ``source_software="NWB"``. Name of the
            ``ndx_pose.PoseEstimation`` object inside the processing module.
            Defaults to "PoseEstimation".
        config_kwargs : Optional[dict], optional
            Additional configuration keyword arguments, by default None.
        save_logs : bool, optional
            Flag indicating whether to save logs. Defaults to True.

        Returns
        -------
        None
        """
        self.save_logs = save_logs
        self.config_path, self.config = vame.init_new_project(
            project_name=project_name,
            poses_estimations=poses_estimations,
            source_software=source_software,
            working_directory=working_directory,
            videos=videos,
            video_type=video_type,
            fps=fps,
            copy_videos=copy_videos,
            processing_module_key=processing_module_key,
            pose_estimation_key=pose_estimation_key,
            config_kwargs=config_kwargs,
        )

    def get_states(self, summary: bool = True) -> dict:
        """
        Returns the pipeline states.

        Returns
        -------
        dict
            Pipeline states.
        """
        states = read_states(self.config)
        if summary and states:
            logger.info("Pipeline states:")
            for key, value in states.items():
                logger.info(f"{key}: {value.get('execution_state', 'Not executed')}")
        return states

    def get_sessions(self) -> List[str]:
        """
        Returns a list of session names.

        Returns
        -------
        List[str]
            Session names.
        """
        return self.config["session_names"]

    def get_raw_datasets(self) -> xr.Dataset:
        """
        Returns a xarray dataset which combines all the raw data from the project.

        Returns
        -------
        dss : xarray.Dataset
            Combined raw dataset.
        """
        sessions = self.get_sessions()
        datasets = list()
        attributes = list()
        for session in sessions:
            ds_path = Path(self.config["project_path"]) / "data" / "raw" / f"{session}.nc"
            ds = load_vame_dataset(ds_path=ds_path)
            ds = ds.expand_dims({"session": [session]})
            datasets.append(ds)
            attributes.append(ds.attrs)
        dss = xr.concat(datasets, dim="session")
        dss_attrs = {}
        for d in attributes:
            for key, value in d.items():
                dss_attrs.setdefault(key, []).append(value)
        for key, values in dss_attrs.items():
            unique_values = unique_in_order(values)  # Maintain order of unique values
            dss_attrs[key] = unique_values[0] if len(unique_values) == 1 else unique_values
        for key, value in dss_attrs.items():
            dss.attrs[key] = value
        return dss

    def preprocessing(
        self,
        centered_reference_keypoint: str = "snout",
        orientation_reference_keypoint: str = "tailbase",
        run_lowconf_cleaning: bool = True,
        run_egocentric_alignment: bool = True,
        run_outlier_cleaning: bool = True,
        run_savgol_filtering: bool = True,
        run_rescaling: bool = False,
    ) -> str:
        """
        Preprocesses the data.

        Parameters
        ----------
        centered_reference_keypoint : str, optional
            Key point to center the data, by default "snout".
        orientation_reference_keypoint : str, optional
            Key point to orient the data, by default "tailbase".
        run_lowconf_cleaning : bool, optional
            Whether to run low confidence cleaning, by default True.
        run_egocentric_alignment : bool, optional
            Whether to run egocentric alignment, by default True.
        run_outlier_cleaning : bool, optional
            Whether to run outlier cleaning, by default True.
        run_savgol_filtering : bool, optional
            Whether to run Savitzky-Golay filtering, by default True.
        run_rescaling : bool, optional
            Whether to run rescaling, by default False.

        Returns
        -------
        variable name of the last-executed preprocessing step output
        """
        self.centered_reference_keypoint = centered_reference_keypoint
        self.orientation_reference_keypoint = orientation_reference_keypoint
        return vame.preprocessing(
            config=self.config,
            centered_reference_keypoint=centered_reference_keypoint,
            orientation_reference_keypoint=orientation_reference_keypoint,
            run_lowconf_cleaning=run_lowconf_cleaning,
            run_egocentric_alignment=run_egocentric_alignment,
            run_outlier_cleaning=run_outlier_cleaning,
            run_savgol_filtering=run_savgol_filtering,
            run_rescaling=run_rescaling,
            save_logs=self.save_logs,
        )

    def create_training_set(
        self,
        test_fraction: float = 0.1,
        split_mode: Literal["mode_1", "mode_2"] = "mode_2",
        read_from_variable: str = "position_processed",
    ) -> None:
        """
        Creates the training set.

        Parameters
        ----------
        test_fraction : float
            Test fraction.
        split_mode : str, optional
            Split mode, by default "mode_2".

        Returns
        -------
        None
        """
        vame.create_trainset(
            config=self.config,
            test_fraction=test_fraction,
            read_from_variable=read_from_variable,
            split_mode=split_mode,
            save_logs=self.save_logs,
        )

    def train_model(self) -> None:
        """
        Trains the model.

        Returns
        -------
        None
        """
        vame.train_model(
            config=self.config,
            save_logs=self.save_logs,
        )

    def evaluate_model(self) -> None:
        """
        Evaluates the model.

        Returns
        -------
        None
        """
        vame.evaluate_model(
            config=self.config,
            save_logs=self.save_logs,
        )

    def run_segmentation(self) -> None:
        """
        Runs the pose estimation segmentation into motifs.

        Returns
        -------
        None
        """
        vame.segment_session(
            config=self.config,
            save_logs=self.save_logs,
        )

    def run_community_clustering(self) -> None:
        """
        Runs the community clustering.

        Returns
        -------
        None
        """
        vame.community(
            config=self.config,
            cut_tree=2,
            save_logs=self.save_logs,
        )

    def generate_motif_videos(
        self,
        video_type: str = ".mp4",
    ) -> None:
        """
        Generates motif videos.

        Parameters
        ----------
        video_type : str, optional
            Video type, by default ".mp4".

        Returns
        -------
        None
        """
        vame.motif_videos(
            config=self.config,
            video_type=video_type,
            save_logs=self.save_logs,
        )

    def generate_community_videos(
        self,
        video_type: str = ".mp4",
    ) -> None:
        """
        Generates community videos.

        Parameters
        ----------
        video_type : str, optional
            Video type, by default ".mp4".

        Returns
        -------
        None
        """
        vame.community_videos(
            config=self.config,
            video_type=video_type,
            save_logs=self.save_logs,
        )

    def generate_videos(
        self,
        video_type: str = ".mp4",
    ) -> None:
        """
        Generates motif and community videos.

        Parameters
        ----------
        video_type : str, optional
            Video type, by default ".mp4".

        Returns
        -------
        None
        """
        self.generate_motif_videos(video_type=video_type)
        self.generate_community_videos(video_type=video_type)

    def visualize_preprocessing(
        self,
        scatter: bool = True,
        timeseries: bool = True,
        cloud: bool = True,
        show_figure: bool = False,
        save_to_file: bool = True,
    ) -> None:
        """
        Visualizes the preprocessing results.

        Parameters
        ----------
        scatter : bool, optional
            Visualize scatter plot, by default True.
        timeseries : bool, optional
            Visualize timeseries plot, by default True.
        cloud : bool, optional
            Visualize cloud plot, by default True.
        show_figure : bool, optional
            Show the figure, by default False.
        save_to_file : bool, optional
            Save the figure to file, by default True.

        Returns
        -------
        None
        """
        if scatter:
            visualize_preprocessing_scatter(
                config=self.config,
                show_figure=show_figure,
                save_to_file=save_to_file,
            )
        if timeseries:
            visualize_preprocessing_timeseries(
                config=self.config,
                show_figure=show_figure,
                save_to_file=save_to_file,
            )
        if cloud:
            visualize_preprocessing_cloud(
                config=self.config,
                show_figure=show_figure,
                save_to_file=save_to_file,
            )

    def visualize_model_losses(
        self,
        save_to_file: bool = True,
        show_figure: bool = True,
    ) -> None:
        """
        Visualizes the model losses.

        Parameters
        ----------
        save_to_file : bool, optional
            Save the figure to file, by default False.
        show_figure : bool, optional
            Show the figure, by default True.

        Returns
        -------
        None
        """
        plot_loss(
            config=self.config,
            model_name="VAME",
            save_to_file=save_to_file,
            show_figure=show_figure,
        )

    def visualize_motif_thresholding(
        self,
        segmentation_algorithm: Literal["hmm", "kmeans"] = "hmm",
        n_clusters: Optional[int] = None,
        threshold: float = 1.0,
        show_figure: bool = True,
        save_to_file: bool = False,
        fig_size: tuple = (10, 6),
    ) -> None:
        """
        Visualizes the motif usage with thresholding.

        Parameters
        ----------
        segmentation_algorithm : Literal["hmm", "kmeans"], optional
            Segmentation algorithm, by default "hmm".
        n_clusters : Optional[int], optional
            Number of clusters, by default None.
        threshold : float, optional
            Threshold, by default 1.0.

        Returns
        -------
        None
        """
        visualize_motif_thresholding(
            config=self.config,
            segmentation_algorithm=segmentation_algorithm,
            n_clusters=n_clusters,
            threshold=threshold,
            show_figure=show_figure,
            save_to_file=save_to_file,
            fig_size=fig_size,
        )

    def visualize_hierarchical_tree(
        self,
        segmentation_algorithm: Literal["hmm", "kmeans"],
    ) -> None:
        """
        Visualizes the hierarchical tree.

        Parameters
        ----------
        segmentation_algorithm : Literal["hmm", "kmeans"]
            Segmentation algorithm.

        Returns
        -------
        None
        """
        visualize_hierarchical_tree(
            config=self.config,
            segmentation_algorithm=segmentation_algorithm,
        )

    def visualize_umap(
        self,
        num_points: int = 30_000,
        save_to_file: bool = True,
        show_figure: Literal["none", "matplotlib", "plotly", "all"] = "none",
    ) -> None:
        """
        Visualizes the UMAP plot.

        Parameters
        ----------
        num_points : int, optional
            Number of data points to visualize. Default is 30,000.
        save_to_file : bool, optional
            Save the figure to file. Default is True.
        show_figure : Literal["none", "matplotlib", "plotly", "all"], optional
            Show the figure. Default is "none".
            - "none": do not show
            - "matplotlib": show with matplotlib
            - "plotly": show with plotly
            - "all": show with both matplotlib and plotly

        Returns
        -------
        None
        """
        visualize_umap(
            config=self.config,
            num_points=num_points,
            save_to_file=save_to_file,
            show_figure=show_figure,
        )

    def report(self) -> None:
        """
        Generates the project report.

        Parameters
        ----------
        segmentation_algorithm : Literal["hmm", "kmeans"], optional
            Segmentation algorithm, by default "hmm".

        Returns
        -------
        None
        """
        generate_reports(config=self.config)

    def run_pipeline(
        self,
        from_step: int = 0,
        preprocessing_kwargs: dict = {},
        trainingset_kwargs: dict = {},
    ) -> None:
        """
        Runs the pipeline.

        Parameters
        ----------
        from_step : int, optional
            Start from step, by default 0.
        preprocessing_kwargs : dict, optional
            Preprocessing keyword arguments, by default {}.
        trainingset_kwargs : dict, optional
            Training set keyword arguments, by default {}.

        Returns
        -------
        None
        """
        if from_step == 0:
            trainingset_kwargs["read_from_variable"] = self.preprocessing(**preprocessing_kwargs)
        if from_step <= 1:
            self.create_training_set(**trainingset_kwargs)
        if from_step <= 2:
            self.train_model()
        if from_step <= 3:
            self.evaluate_model()
        if from_step <= 4:
            self.run_segmentation()
        if from_step <= 5:
            self.run_community_clustering()


def unique_in_order(sequence):
    seen = set()
    result = []
    for item in sequence:
        if item not in seen:
            result.append(item)
            seen.add(item)
    return result
