# neruva-control

Local daemon for **[Neruva Cockpit](https://neruva.io/cockpit)** — the web dashboard for AI that runs your computer and writes code for you.

Cockpit runs in your browser. This daemon runs on your laptop. Together they let an AI:

- **Neruva Computer** — see your screen, click, type, navigate apps (organize files, fill forms, drive Excel, browse the web)
- **Neruva Code** — write code, edit files, run commands, debug — drop it in any project folder
- **Remember what you've done** across sessions so it gets better at your work
- **Take direction mid-task** — type a message while it's working and it adjusts

Everything runs on your machine. The daemon binds to loopback (127.0.0.1) and never opens a network port.

## Install

```bash
pip install "neruva-control[agent]"
neruva-control-install
```

The installer:

1. Generates an auth token at `~/.config/neruva/control.token`
2. Registers a background service (launchd / systemd-user / Task Scheduler)
3. Starts the daemon on `127.0.0.1:7331`
4. Prints a one-time link `https://neruva.io/cockpit#token=<TOKEN>` — open once, browser remembers your machine

The `[agent]` extra installs `pyautogui` + `Pillow` for the Neruva Computer screen control. Skip it if you only want Neruva Code (text/file work).

## How it works

```
[browser at neruva.io/cockpit]
       ↕ WebSocket (loopback :7331, token-authed)
[neruva-control daemon]
   ├─ POST /v1/sessions {agent_type: "code"|"computer", task}
   ├─ Streams every step (screenshots, actions, results) to the browser
   ├─ Accepts mid-flight chat messages — type to redirect
   └─ Records to your Neruva account so the agent learns
       ↕ HTTPS (your Neruva API key only)
[api.neruva.io]
```

The daemon binds to **127.0.0.1 only**. The browser tab at neruva.io/cockpit connects via loopback WebSocket using a one-time token. Sessions never leave your machine in transit.

## Quick start (after install)

1. Open the link the installer printed (or run `neruva-control link` to print it again)
2. In Cockpit, pick a **Mode** — Neruva Code or Neruva Computer
3. Type what you want done:
   - *"Open my budget spreadsheet and add this month's expenses"*
   - *"Write a Python script that renames all photos in this folder by date"*
   - *"Fix the failing test in tests/auth.py"*
4. Watch it work. Type into the chat any time to redirect.

## Configuration

Drop your Neruva API key into `~/.config/neruva/.env` (Linux/macOS) or
`%APPDATA%\neruva\neruva\.env` (Windows). The daemon auto-loads it at
startup so you never touch your shell profile.

```env
NERUVA_API_KEY=nv_...
```

That's the only key you need — everything else is handled server-side.

## Commands

| Command | What it does |
|---|---|
| `neruva-control-install` | One-shot install (generates token, registers service, prints link URL) |
| `neruva-control start` | Run the daemon foreground (used by the background service) |
| `neruva-control status` | Show install + daemon health + version |
| `neruva-control link` | Print the link URL again (re-link or new browser) |
| `neruva-control stop` | Stop the daemon |

## Requirements

- Python ≥3.10
- `[agent]` extra: pyautogui + Pillow (skip if Code-only)
- A Neruva account at [neruva.io](https://neruva.io)

## Privacy

- Daemon listens on `127.0.0.1` only — never on a network interface
- Sessions stream over loopback WebSocket; never leave your machine in transit
- Memory writes are encrypted and tied to your account
- Export or delete everything as a portable `.neruva` file anytime
- For Neruva Computer: screenshots are sent securely to advance the task and not retained beyond that turn

## License

MIT — see [LICENSE](./LICENSE).
