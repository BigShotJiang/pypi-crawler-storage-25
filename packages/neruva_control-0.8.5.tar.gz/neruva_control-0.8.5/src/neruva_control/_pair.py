"""Phone pairing -- WebRTC peer-to-peer transport.

Lets a phone browser talk to this daemon over an encrypted P2P data
channel via the neruva-pair signaling server. The daemon stays on
loopback (no LAN exposure) and the phone never has to install
Tailscale or know the laptop's network.

Architecture:
  1. Daemon calls POST /v1/pair/code on signaling server -> 6-char code
  2. Daemon connects to signaling WS as role=daemon, awaits peer_joined
  3. Phone scans QR -> opens app.neruva.io/cockpit?pair=CODE
  4. Phone connects to signaling WS as role=browser
  5. Daemon creates RTCPeerConnection + data channel, sends offer
  6. SDP/ICE relay through signaling -> direct P2P data channel opens
  7. Daemon sends {kind:"welcome", token:<auth>} so phone has the daemon's auth
  8. Phone sends RPC frames over data channel:
       {id, kind:"http", method, path, headers, body}
       {id, kind:"ws_open", path, headers}
       {id, kind:"ws_send", data}
       {id, kind:"ws_close"}
  9. Daemon proxies each frame to its OWN loopback HTTP/WS endpoint via
     httpx + websockets (no API duplication; reuses every existing route).
 10. Responses go back through the data channel.

Optional dep: pip install neruva-control[pair] (pulls aiortc).
"""
from __future__ import annotations

import asyncio
import contextlib
import json
import logging
import os
import secrets
from typing import Any, Optional

import httpx

from . import _events
from ._config import load_or_create_daemon_id, load_token
from ._trust import mint_device_token, verify_device_token

log = logging.getLogger("neruva_control.pair")


PAIR_BASE_DEFAULT = "https://neruva-pair-mgbxvs4loq-uc.a.run.app"


def _pair_http_base() -> str:
    return os.environ.get("NERUVA_PAIR_BASE", PAIR_BASE_DEFAULT) + "/v1/pair"


def _pair_ws_url(code: str, role: str) -> str:
    base = os.environ.get("NERUVA_PAIR_BASE", PAIR_BASE_DEFAULT)
    return base.replace("https:", "wss:").replace("http:", "ws:") + f"/v1/pair/ws?code={code}&role={role}"


def _presence_ws_url(daemon_id: str) -> str:
    base = os.environ.get("NERUVA_PAIR_BASE", PAIR_BASE_DEFAULT)
    return base.replace("https:", "wss:").replace("http:", "ws:") + f"/v1/pair/presence?daemon_id={daemon_id}"


# Stable ICE servers (free public STUN). TURN added in Phase 5 for double-NAT.
_ICE_SERVERS = [
    {"urls": "stun:stun.l.google.com:19302"},
    {"urls": "stun:stun1.l.google.com:19302"},
]


def _is_pair_available() -> bool:
    try:
        import aiortc  # noqa: F401
        import websockets  # noqa: F401
        return True
    except ImportError:
        return False


# ---------------------------------------------------------------------------
# Active pairings -- one per code. Only one phone per code (the data channel
# is exclusive). To pair multiple phones, the user creates fresh codes.
# ---------------------------------------------------------------------------

_ACTIVE: dict[str, "DaemonPairing"] = {}

# Presence loop singleton state (one per daemon process)
_PRESENCE_TASK: Optional[asyncio.Task] = None
_PRESENCE_DAEMON_PORT: Optional[int] = None


def list_pairings() -> list[dict[str, Any]]:
    return [p.summary() for p in _ACTIVE.values()]


def ensure_presence(daemon_loopback_port: int) -> None:
    """Idempotent. Start the long-lived presence WS to the signaling
    server so phones can rejoin via /v1/pair/rejoin without QR scan.
    Safe to call from sync code (schedules a task if a loop is running)."""
    global _PRESENCE_TASK, _PRESENCE_DAEMON_PORT
    _PRESENCE_DAEMON_PORT = daemon_loopback_port
    if not _is_pair_available():
        return
    if _PRESENCE_TASK is not None and not _PRESENCE_TASK.done():
        return
    try:
        loop = asyncio.get_event_loop()
    except RuntimeError:
        return
    _PRESENCE_TASK = loop.create_task(_presence_loop(daemon_loopback_port))


async def start_pairing(daemon_loopback_port: int) -> dict[str, Any]:
    """Allocate a code, start the WebRTC handshake background task,
    return {code, ttl_secs, expires_at_ms} immediately."""
    if not _is_pair_available():
        raise RuntimeError(
            "Pairing requires aiortc. Install with: pip install neruva-control[pair]"
        )
    async with httpx.AsyncClient(timeout=10.0) as cli:
        r = await cli.post(f"{_pair_http_base()}/code")
        r.raise_for_status()
        data = r.json()
    code = data["code"]
    ttl = int(data.get("ttl_secs", 300))
    pairing = DaemonPairing(code=code, daemon_loopback_port=daemon_loopback_port)
    _ACTIVE[code] = pairing
    asyncio.create_task(pairing.run())
    return {"code": code, "ttl_secs": ttl}


async def stop_pairing(code: str) -> bool:
    p = _ACTIVE.pop(code, None)
    if p is None:
        return False
    await p.close()
    return True


# ---------------------------------------------------------------------------
# Presence loop -- long-lived WS to signaling server for rejoin without QR
# ---------------------------------------------------------------------------

async def _presence_loop(daemon_loopback_port: int) -> None:
    """Maintain a long-lived WebSocket to the signaling presence channel
    so phones can rejoin without a fresh QR scan. Reconnects with
    exponential backoff on failure."""
    import websockets

    daemon_id = load_or_create_daemon_id()
    log.info("presence: daemon_id=%s", daemon_id)
    backoff = 1.0
    while True:
        try:
            async with websockets.connect(_presence_ws_url(daemon_id),
                                          ping_interval=30, ping_timeout=20) as ws:
                log.info("presence: connected")
                backoff = 1.0
                async for raw in ws:
                    try:
                        frame = json.loads(raw)
                    except Exception:
                        continue
                    t = frame.get("type")
                    if t == "rejoin_request":
                        await _handle_rejoin_request(ws, frame, daemon_loopback_port)
                    elif t == "presence_ack":
                        log.debug("presence: ack")
                    # other types are no-op
        except asyncio.CancelledError:
            return
        except Exception as e:
            log.warning("presence: connection lost (%s); retry in %.1fs", e, backoff)
        await asyncio.sleep(backoff)
        backoff = min(backoff * 2.0, 60.0)


async def _handle_rejoin_request(ws: Any, frame: dict, daemon_port: int) -> None:
    rid = frame.get("request_id")
    presented = frame.get("device_token") or ""
    rec = verify_device_token(presented)
    if rec is None:
        try:
            await ws.send(json.dumps({"type": "rejoin_reply", "request_id": rid,
                                      "ok": False, "detail": "unknown device"}))
        except Exception:
            pass
        log.warning("presence: rejoin denied (unknown token)")
        return
    # Mint a fresh pair code and start the WebRTC handshake on it. Phone
    # is told the code via the rejoin POST response and joins as browser.
    try:
        async with httpx.AsyncClient(timeout=10.0) as cli:
            r = await cli.post(f"{_pair_http_base()}/code")
            r.raise_for_status()
            data = r.json()
        code = data["code"]
        pairing = DaemonPairing(code=code, daemon_loopback_port=daemon_port,
                                is_rejoin=True)
        _ACTIVE[code] = pairing
        asyncio.create_task(pairing.run())
        await ws.send(json.dumps({"type": "rejoin_reply", "request_id": rid,
                                  "ok": True, "code": code,
                                  "device_id": rec.get("device_id")}))
        log.info("presence: rejoin ok for device %s -> code %s",
                 rec.get("device_id"), code)
    except Exception as e:
        log.exception("presence: rejoin failed for %s", rec.get("device_id"))
        try:
            await ws.send(json.dumps({"type": "rejoin_reply", "request_id": rid,
                                      "ok": False, "detail": f"server error: {e}"}))
        except Exception:
            pass


# ---------------------------------------------------------------------------
# DaemonPairing -- lifecycle for one paired session
# ---------------------------------------------------------------------------

class DaemonPairing:
    def __init__(self, code: str, daemon_loopback_port: int, *,
                 is_rejoin: bool = False) -> None:
        self.code = code
        self.daemon_port = daemon_loopback_port
        self._is_rejoin = is_rejoin
        self.pc = None
        self.dc = None  # RTCDataChannel
        self.ws_signal = None
        self._closed = False
        # Stream id -> {task, conn} so _handle_ws_send can find the
        # live local WebSocket and forward outbound input to it.
        self._open_ws_streams: dict[str, dict] = {}

    def summary(self) -> dict[str, Any]:
        # Honest state: only "connected" once the data channel is OPEN
        # (P2P actually established). Before that we're either awaiting
        # peer or negotiating.
        if self._closed:
            state = "closed"
        elif self.dc is not None and self.dc.readyState == "open":
            state = "connected"
        elif self.pc is not None and self.pc.connectionState in ("connecting", "new"):
            state = "negotiating"
        else:
            state = "awaiting peer"
        return {
            "code": self.code,
            "state": state,
            "open_streams": len(self._open_ws_streams),
        }

    async def run(self) -> None:
        try:
            await self._run()
        except Exception:
            log.exception("pairing %s crashed", self.code)
        # Signaling loop ended -- BUT the data channel might still be
        # live! That's the whole point of P2P: signaling is only needed
        # for the handshake. Keep this task alive (and thus the pc + dc)
        # until the pc actually dies. Without this, the finally below
        # would tear down a perfectly good P2P connection.
        try:
            while not self._closed and self.pc is not None \
                    and self.pc.connectionState not in ("closed", "failed"):
                await asyncio.sleep(1.0)
        except asyncio.CancelledError:
            pass
        finally:
            await self.close()
            _ACTIVE.pop(self.code, None)

    async def _run(self) -> None:
        from aiortc import RTCPeerConnection, RTCSessionDescription, RTCConfiguration, RTCIceServer
        import websockets

        ice_servers = [RTCIceServer(urls=s["urls"]) for s in _ICE_SERVERS]
        self.pc = RTCPeerConnection(configuration=RTCConfiguration(iceServers=ice_servers))
        # Daemon side INITIATES: create data channel, send offer when peer joins
        self.dc = self.pc.createDataChannel("cockpit", ordered=True)

        @self.dc.on("open")
        def _on_open() -> None:  # noqa: ANN001
            log.info("pair %s: data channel open", self.code)
            # Send the daemon's auth token so the phone is authenticated.
            # Also mint a long-lived device_token + daemon_id so the phone
            # can rejoin without scanning a fresh QR next time.
            try:
                token = load_token()
                payload = {"kind": "welcome", "token": token}
                if not self._is_rejoin:
                    daemon_id = load_or_create_daemon_id()
                    minted = mint_device_token(label="phone")
                    payload["daemon_id"] = daemon_id
                    payload["device_token"] = minted["token"]
                    payload["device_id"] = minted["device_id"]
                    _events.publish("device.paired", device_id=minted["device_id"], label=minted["label"])
                else:
                    payload["daemon_id"] = load_or_create_daemon_id()
                    payload["rejoin"] = True
                self.dc.send(json.dumps(payload))
            except Exception:
                log.exception("pair %s: welcome send failed", self.code)

        @self.dc.on("message")
        def _on_message(message: Any) -> None:  # noqa: ANN001
            if isinstance(message, bytes):
                # binary frames not used in v1
                return
            try:
                frame = json.loads(message)
            except Exception:
                return
            asyncio.create_task(self._handle_rpc(frame))

        @self.dc.on("close")
        def _on_close() -> None:
            log.info("pair %s: data channel closed", self.code)

        @self.pc.on("connectionstatechange")
        async def _on_state() -> None:
            log.info("pair %s: pc state %s", self.code, self.pc.connectionState)
            if self.pc.connectionState in ("failed", "disconnected", "closed"):
                await self.close()

        # Connect to signaling, await peer_joined, do offer/answer/ICE relay
        self.ws_signal = await websockets.connect(_pair_ws_url(self.code, "daemon"))
        log.info("pair %s: signaling open", self.code)

        # Buffer ICE candidates emitted before peer joins
        pending_ice: list[dict] = []

        @self.pc.on("icecandidate")
        async def _on_ice(candidate) -> None:  # noqa: ANN001
            if candidate is None:
                return
            payload = {"type": "ice", "candidate": _ice_to_dict(candidate)}
            try:
                await self.ws_signal.send(json.dumps(payload))
            except Exception:
                pending_ice.append(payload)

        async for raw in self.ws_signal:
            try:
                frame = json.loads(raw)
            except Exception:
                continue
            t = frame.get("type")
            log.debug("pair %s signal IN: %s", self.code, t)

            if t == "error":
                log.warning("pair %s: signaling error: %s", self.code, frame.get("detail"))
                break

            if t == "peer_joined":
                # Drain any buffered ICE
                for p in pending_ice:
                    try: await self.ws_signal.send(json.dumps(p))
                    except Exception: pass
                pending_ice.clear()
                # Create + send offer
                offer = await self.pc.createOffer()
                await self.pc.setLocalDescription(offer)
                await self.ws_signal.send(json.dumps({
                    "type": "offer",
                    "sdp": {"sdp": self.pc.localDescription.sdp, "type": self.pc.localDescription.type},
                }))
                log.info("pair %s: sent offer", self.code)
                continue

            if t == "answer":
                sdp = frame.get("sdp", {})
                await self.pc.setRemoteDescription(
                    RTCSessionDescription(sdp=sdp.get("sdp"), type=sdp.get("type")),
                )
                log.info("pair %s: applied answer", self.code)
                continue

            if t == "ice":
                cand = _dict_to_ice(frame.get("candidate", {}))
                if cand is not None:
                    try: await self.pc.addIceCandidate(cand)
                    except Exception as e:
                        log.warning("pair %s: addIceCandidate failed: %s", self.code, e)
                continue

            if t == "peer_disconnected":
                log.info("pair %s: peer disconnected via signaling", self.code)
                break

        # Signaling done; data channel handles the rest
        try: await self.ws_signal.close()
        except Exception: pass
        self.ws_signal = None

    async def _handle_rpc(self, frame: dict) -> None:
        """Process one RPC frame from the phone. Proxies HTTP via httpx
        to the daemon's own loopback, multiplexes WebSockets via stream
        ids."""
        kind = frame.get("kind")
        if kind == "http":
            await self._handle_http(frame)
        elif kind == "ws_open":
            await self._handle_ws_open(frame)
        elif kind == "ws_send":
            await self._handle_ws_send(frame)
        elif kind == "ws_close":
            await self._handle_ws_close(frame)

    async def _handle_http(self, frame: dict) -> None:
        rid = frame.get("id")
        method = (frame.get("method") or "GET").upper()
        path = frame.get("path") or "/"
        headers = frame.get("headers") or {}
        body = frame.get("body")
        url = f"http://127.0.0.1:{self.daemon_port}{path}"
        try:
            async with httpx.AsyncClient(timeout=30.0) as cli:
                r = await cli.request(
                    method, url, headers=headers,
                    content=body if isinstance(body, (str, bytes)) else
                            (json.dumps(body) if body is not None else None),
                )
            self._send({
                "id": rid, "kind": "http_resp",
                "status": r.status_code,
                "headers": dict(r.headers),
                "body": r.text,
            })
        except Exception as e:
            self._send({"id": rid, "kind": "http_resp", "status": 0,
                        "headers": {}, "body": f"local proxy error: {e}"})

    async def _handle_ws_open(self, frame: dict) -> None:
        rid = frame.get("id")
        if not rid or rid in self._open_ws_streams:
            return
        path = frame.get("path") or "/"
        url = f"ws://127.0.0.1:{self.daemon_port}{path}"
        task = asyncio.create_task(self._ws_pump(rid, url))
        self._open_ws_streams[rid] = {"task": task, "conn": None}

    async def _ws_pump(self, rid: str, url: str) -> None:
        """Open a local WS to the daemon, do the auth handshake using
        the daemon's own token, then pump bidirectionally:
          - daemon WS -> data channel (via _send ws_msg)
          - data channel -> daemon WS (via _handle_ws_send writing here)
        """
        import websockets
        try:
            ws = await websockets.connect(url)
        except Exception as e:
            self._send({"id": rid, "kind": "ws_msg",
                        "data": json.dumps({"type": "ws.error", "detail": f"connect failed: {e}"})})
            self._send({"id": rid, "kind": "ws_close"})
            self._open_ws_streams.pop(rid, None)
            return

        # The local /v1/sessions/{sid} handler expects {type:"auth",token:...}
        # as the FIRST message. Inject it using the daemon's own control
        # token (we have it on disk). Then the handler will start streaming.
        try:
            token = load_token()
            await ws.send(json.dumps({"type": "auth", "token": token}))
        except Exception as e:
            log.warning("pair %s: auth inject failed: %s", self.code, e)

        # Register the live conn so _handle_ws_send can address it
        entry = self._open_ws_streams.get(rid)
        if entry is not None:
            entry["conn"] = ws

        self._send({"id": rid, "kind": "ws_open_ok"})

        try:
            async for msg in ws:
                self._send({"id": rid, "kind": "ws_msg",
                            "data": msg if isinstance(msg, str)
                                   else msg.decode("utf-8", "replace")})
        except Exception as e:
            self._send({"id": rid, "kind": "ws_msg",
                        "data": json.dumps({"type": "ws.error", "detail": str(e)})})
        finally:
            try: await ws.close()
            except Exception: pass
            self._send({"id": rid, "kind": "ws_close"})
            self._open_ws_streams.pop(rid, None)

    async def _handle_ws_send(self, frame: dict) -> None:
        """Forward phone-side input to the local WS for this stream."""
        rid = frame.get("id")
        entry = self._open_ws_streams.get(rid)
        if not entry or not entry.get("conn"):
            log.warning("pair %s: ws_send for unknown/unopened stream %s", self.code, rid)
            return
        ws = entry["conn"]
        data = frame.get("data")
        if data is None:
            return
        try:
            await ws.send(data if isinstance(data, str) else json.dumps(data))
        except Exception as e:
            log.warning("pair %s: ws_send forward failed: %s", self.code, e)

    async def _handle_ws_close(self, frame: dict) -> None:
        rid = frame.get("id")
        entry = self._open_ws_streams.pop(rid, None)
        if not entry:
            return
        if entry.get("conn"):
            try: await entry["conn"].close()
            except Exception: pass
        if entry.get("task"):
            entry["task"].cancel()

    def _send(self, frame: dict) -> None:
        if self.dc is None or self.dc.readyState != "open":
            return
        try: self.dc.send(json.dumps(frame))
        except Exception: pass

    async def close(self) -> None:
        if self._closed:
            return
        self._closed = True
        for entry in list(self._open_ws_streams.values()):
            if entry.get("conn"):
                try: await entry["conn"].close()
                except Exception: pass
            if entry.get("task"):
                entry["task"].cancel()
        self._open_ws_streams.clear()
        if self.dc is not None:
            with contextlib.suppress(Exception):
                self.dc.close()
        if self.pc is not None:
            with contextlib.suppress(Exception):
                await self.pc.close()
        if self.ws_signal is not None:
            with contextlib.suppress(Exception):
                await self.ws_signal.close()


# ---------------------------------------------------------------------------
# ICE candidate (de)serialization between aiortc objects and signaling JSON
# ---------------------------------------------------------------------------

def _ice_to_dict(c: Any) -> dict:
    return {
        "candidate": f"candidate:{c.foundation} {c.component} {c.protocol} "
                     f"{c.priority} {c.ip} {c.port} typ {c.type}",
        "sdpMid": c.sdpMid,
        "sdpMLineIndex": c.sdpMLineIndex,
    }


def _dict_to_ice(d: dict) -> Optional[Any]:
    """Browser sends candidate as an RTCIceCandidate dict. aiortc needs
    parsed components. Use its sdp parser if available."""
    if not d:
        return None
    try:
        from aiortc.sdp import candidate_from_sdp
        cand = candidate_from_sdp(d.get("candidate", "").replace("candidate:", "", 1))
        cand.sdpMid = d.get("sdpMid")
        cand.sdpMLineIndex = d.get("sdpMLineIndex")
        return cand
    except Exception:
        return None
