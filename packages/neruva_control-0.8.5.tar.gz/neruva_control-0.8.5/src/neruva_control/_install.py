"""`neruva-control-install` -- the one-shot install command.

Goals (Kyle: "make sure UX is world class"):
  - User runs `pip install neruva-control && neruva-control-install`
  - We generate a token, write config, register an OS service, start
    the daemon, and print a clickable URL with the token in the
    fragment so the browser can link in one click.
  - No flags needed in the common path. `--help` documents the rare
    overrides (--no-service, --reinstall, --port).

Cross-platform service registration:
  - macOS  : ~/Library/LaunchAgents/io.neruva.control.plist + launchctl load
  - Linux  : ~/.config/systemd/user/neruva-control.service + systemctl --user
  - Windows: schtasks /Create with ONLOGON trigger + immediate start

If service registration fails (rootless containers, weird init systems),
we degrade to "you're set up, but you'll need to run `neruva-control
start` yourself in a background shell".
"""
from __future__ import annotations

import argparse
import os
import shutil
import socket
import subprocess
import sys
import textwrap
import time
from pathlib import Path

from ._config import config_dir, gen_token, write_token, cockpit_link_url, token_path


PORT = 7331


# ---------------------------------------------------------------------------
# Cross-platform service registration
# ---------------------------------------------------------------------------

def _python_exe() -> str:
    return sys.executable or "python"


def _start_cmd() -> list[str]:
    """The command that runs the daemon foreground. Used by service
    registration on every OS."""
    return [_python_exe(), "-m", "neruva_control._cli", "start"]


def _install_macos() -> tuple[bool, str]:
    label = "io.neruva.control"
    plist_dir = Path.home() / "Library" / "LaunchAgents"
    plist_dir.mkdir(parents=True, exist_ok=True)
    plist = plist_dir / f"{label}.plist"
    cmd_args = "".join(f"        <string>{a}</string>\n" for a in _start_cmd())
    plist.write_text(textwrap.dedent(f"""\
        <?xml version="1.0" encoding="UTF-8"?>
        <!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN"
          "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
        <plist version="1.0">
        <dict>
          <key>Label</key><string>{label}</string>
          <key>ProgramArguments</key>
          <array>
{cmd_args}        </array>
          <key>RunAtLoad</key><true/>
          <key>KeepAlive</key><true/>
          <key>StandardOutPath</key>
          <string>{config_dir()}/daemon.log</string>
          <key>StandardErrorPath</key>
          <string>{config_dir()}/daemon.err</string>
        </dict>
        </plist>
    """), encoding="utf-8")
    try:
        # Unload first in case we're re-installing
        subprocess.run(["launchctl", "unload", str(plist)], capture_output=True)
        subprocess.run(["launchctl", "load", str(plist)], check=True, capture_output=True)
        return True, f"launchd: loaded {plist}"
    except Exception as e:
        return False, f"launchctl load failed: {e}"


def _install_linux() -> tuple[bool, str]:
    unit_dir = Path.home() / ".config" / "systemd" / "user"
    unit_dir.mkdir(parents=True, exist_ok=True)
    unit = unit_dir / "neruva-control.service"
    exec_line = " ".join(_start_cmd())
    unit.write_text(textwrap.dedent(f"""\
        [Unit]
        Description=Neruva Control daemon (Cockpit local controller)
        After=network.target

        [Service]
        ExecStart={exec_line}
        Restart=always
        RestartSec=3
        Environment=PYTHONUNBUFFERED=1

        [Install]
        WantedBy=default.target
    """), encoding="utf-8")
    if not shutil.which("systemctl"):
        return False, "systemctl not found; skip auto-service. Run `neruva-control start` manually."
    try:
        subprocess.run(["systemctl", "--user", "daemon-reload"], check=True, capture_output=True)
        subprocess.run(["systemctl", "--user", "enable", "--now", "neruva-control.service"],
                       check=True, capture_output=True)
        return True, f"systemd-user: enabled {unit}"
    except Exception as e:
        return False, f"systemctl --user enable failed: {e}"


def _install_windows() -> tuple[bool, str]:
    """Use schtasks to register an ONLOGON task. Avoids needing admin."""
    task_name = "NeruvaControl"
    cmd_str = " ".join(f'"{a}"' for a in _start_cmd())
    try:
        # Delete any prior task silently
        subprocess.run(["schtasks", "/Delete", "/TN", task_name, "/F"],
                       capture_output=True)
        # Create on-logon task that runs in current session
        subprocess.run([
            "schtasks", "/Create", "/TN", task_name,
            "/SC", "ONLOGON",
            "/TR", cmd_str,
            "/RL", "LIMITED",
            "/F",
        ], check=True, capture_output=True)
        # Run it now so user doesn't need to log out
        subprocess.run(["schtasks", "/Run", "/TN", task_name],
                       check=True, capture_output=True)
        return True, f"Task Scheduler: registered task '{task_name}'"
    except FileNotFoundError:
        return False, "schtasks not on PATH; skipping auto-service"
    except subprocess.CalledProcessError as e:
        msg = (e.stderr or b"").decode(errors="replace").strip()
        return False, f"schtasks /Create failed: {msg or e}"


def _install_service() -> tuple[bool, str]:
    if sys.platform == "darwin":
        return _install_macos()
    if sys.platform == "win32":
        return _install_windows()
    if sys.platform.startswith("linux"):
        return _install_linux()
    return False, f"unsupported platform: {sys.platform}"


def _wait_for_daemon(timeout: float = 10.0) -> bool:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(0.4)
        try:
            s.connect(("127.0.0.1", PORT))
            s.close()
            return True
        except OSError:
            time.sleep(0.3)
    return False


# ---------------------------------------------------------------------------
# Optional capability backends -- Playwright Chromium + Tesseract OCR
# ---------------------------------------------------------------------------

def _install_chromium() -> tuple[bool, str]:
    """Run `playwright install chromium` if playwright is importable.
    Skips cleanly if user didn't install the [agent] extra."""
    try:
        import playwright  # noqa: F401
    except ImportError:
        return False, "playwright not installed (pip install 'neruva-control[agent]')"
    try:
        # Check if already installed by probing the browsers cache dir
        from playwright.sync_api import sync_playwright
        try:
            with sync_playwright() as p:
                if p.chromium.executable_path and Path(p.chromium.executable_path).exists():
                    return True, "Chromium already present"
        except Exception:
            pass
        # Run the installer
        proc = subprocess.run(
            [_python_exe(), "-m", "playwright", "install", "chromium"],
            capture_output=True, text=True, timeout=600, check=False,
        )
        if proc.returncode == 0:
            return True, "Chromium installed"
        return False, f"playwright install failed: {proc.stderr[:200]}"
    except subprocess.TimeoutExpired:
        return False, "Chromium download timed out (try `playwright install chromium` manually)"
    except Exception as e:
        return False, f"chromium setup error: {e}"


def _tesseract_on_path() -> bool:
    return shutil.which("tesseract") is not None


def _install_tesseract_windows() -> tuple[bool, str]:
    """Download + run the UB-Mannheim Tesseract installer silently,
    then add the install dir to the current process's PATH so the
    daemon child (which we're about to launch) sees it. The installer
    also writes to system PATH for future shells."""
    if _tesseract_on_path():
        return True, "Tesseract already on PATH"
    try:
        import urllib.request
        import tempfile
    except Exception as e:
        return False, f"urllib unavailable: {e}"

    # Try GitHub releases first (most reliable), then UB-Mannheim
    # mirror as backup. Both serve the same UB-Mannheim binary.
    urls = [
        "https://github.com/UB-Mannheim/tesseract/releases/download/"
        "v5.4.0.20240606/tesseract-ocr-w64-setup-5.4.0.20240606.exe",
        "https://digi.bib.uni-mannheim.de/tesseract/"
        "tesseract-ocr-w64-setup-5.4.0.20240606.exe",
    ]
    print(f"  [....] Downloading Tesseract OCR (~80MB) -- "
          "one-time install...")
    tmp = Path(tempfile.gettempdir()) / "tesseract-ocr-setup.exe"
    last_err = ""
    req_headers = {"User-Agent": "neruva-control-install/1.0"}
    for url in urls:
        try:
            req = urllib.request.Request(url, headers=req_headers)
            with urllib.request.urlopen(req, timeout=60) as resp, open(tmp, "wb") as out:
                shutil.copyfileobj(resp, out)
            if tmp.stat().st_size > 10_000_000:  # >10MB sanity
                last_err = ""
                break
            last_err = f"download too small from {url}"
        except Exception as e:
            last_err = f"{type(e).__name__}: {e}"
            continue
    if last_err:
        return False, f"Tesseract download failed: {last_err}"
    install_dir = "C:\\Program Files\\Tesseract-OCR"
    print(f"  [....] Launching Tesseract installer with admin prompt "
          "(approve the UAC dialog)...")
    # NSIS installer needs admin to write to Program Files. Three
    # elevation paths, falling back if PowerShell is somehow missing:
    #   1. PowerShell 5.1 (baked into every modern Windows) -- preferred
    #      because Start-Process -Wait blocks until install finishes.
    #   2. PowerShell 7 (`pwsh`) if user has it instead.
    #   3. ctypes ShellExecuteW "runas" verb -- pure Win32, always
    #      available, but fire-and-forget (we poll for completion).
    elev_ok, elev_err = False, ""
    for ps_name in ("powershell", "pwsh"):
        if not shutil.which(ps_name):
            continue
        ps_cmd = (
            f"$p = Start-Process -FilePath '{tmp}' "
            f"-ArgumentList '/S','/D={install_dir}' "
            f"-Verb RunAs -PassThru -Wait; exit $p.ExitCode"
        )
        try:
            proc = subprocess.run(
                [ps_name, "-NoProfile", "-Command", ps_cmd],
                timeout=300, check=False,
            )
            if proc.returncode in (0, None):
                elev_ok = True
                break
            elev_err = f"{ps_name} installer exited {proc.returncode}"
        except subprocess.TimeoutExpired:
            elev_err = f"{ps_name} installer timed out"
        except Exception as e:
            elev_err = f"{ps_name}: {e}"
    if not elev_ok:
        # Native Win32 fallback -- no PowerShell required at all.
        try:
            import ctypes
            args = f'/S /D={install_dir}'
            rc = ctypes.windll.shell32.ShellExecuteW(
                None, "runas", str(tmp), args, None, 0)
            if rc <= 32:
                try: tmp.unlink()
                except Exception: pass
                return False, (f"installer launch failed (ShellExecute "
                               f"rc={rc}); manual install: {tmp}")
            # Poll for the install dir to appear
            print(f"  [....] waiting for installer to finish...")
            for _ in range(60):  # 60 * 5s = 5 min
                time.sleep(5)
                if (Path(install_dir) / "tesseract.exe").exists():
                    elev_ok = True
                    break
            if not elev_ok:
                elev_err = ("installer launched but tesseract.exe didn't "
                            "appear in 5 min")
        except Exception as e:
            elev_err = f"ctypes fallback failed: {e}"
    try: tmp.unlink()
    except Exception: pass
    if not elev_ok:
        return False, (f"Tesseract install failed: {elev_err}. "
                       f"Manual install: https://github.com/UB-Mannheim/tesseract/wiki")
    # Add to PATH for THIS process so a daemon start right after sees
    # it. The installer also writes system PATH, which new shells pick
    # up at next launch.
    if Path(install_dir).exists():
        os.environ["PATH"] = install_dir + os.pathsep + os.environ.get("PATH", "")
    if _tesseract_on_path():
        return True, f"Tesseract installed at {install_dir}"
    return False, (f"Tesseract installed to {install_dir} but not yet "
                   "on PATH. Open a new terminal and re-run.")


def _probe_pyright() -> tuple[bool, str]:
    """Pyright (Python LSP) is shipped as the `pyright` pip package
    which bundles its own Node. Already installed via [agent] extra;
    we just probe it here so users get explicit status."""
    if shutil.which("pyright-langserver"):
        return True, "pyright-langserver on PATH"
    # The pyright PyPI package lazy-installs node on first invocation;
    # firing once primes the cache so first agent call is fast.
    try:
        proc = subprocess.run(
            [_python_exe(), "-m", "pyright", "--version"],
            capture_output=True, text=True, timeout=120, check=False,
        )
        if proc.returncode == 0:
            version = (proc.stdout or "").strip().splitlines()[-1][:60]
            return True, f"pyright primed ({version})"
        return False, "pyright module not importable"
    except subprocess.TimeoutExpired:
        return False, "pyright first-run node download timed out"
    except Exception as e:
        return False, f"pyright probe: {e}"


def _install_capabilities() -> None:
    """Auto-install optional backends (Chromium, Tesseract, pyright).
    Never fatal -- the daemon runs without them; we just enable more
    actions when present."""
    print()
    print("  Installing optional capability backends (one-time):")
    # Playwright Chromium -- cross-platform
    ok, msg = _install_chromium()
    print(f"  {'[ok]  ' if ok else '[skip]'} Playwright Chromium: {msg}")
    # Tesseract -- Windows auto-install; manual on Mac/Linux
    if sys.platform == "win32":
        ok, msg = _install_tesseract_windows()
        print(f"  {'[ok]  ' if ok else '[skip]'} Tesseract OCR: {msg}")
    elif sys.platform == "darwin":
        print("  [skip] Tesseract OCR: `brew install tesseract` to enable "
              "screen-text OCR (optional; ax-tree covers most UIs).")
    else:
        print("  [skip] Tesseract OCR: `sudo apt install tesseract-ocr` "
              "(optional; ax-tree covers most UIs).")
    # Pyright -- prime once so first lsp_* call is fast
    print("  [....] Priming pyright (first-run downloads Node ~30MB)...")
    ok, msg = _probe_pyright()
    print(f"  {'[ok]  ' if ok else '[skip]'} Pyright LSP (Python): {msg}")
    # Heads-up about other LSPs the user can opt into
    print("  [note] Other LSPs (optional, install yourself):")
    print("           TS/JS: `npm i -g typescript-language-server`")
    print("           Go:    `go install golang.org/x/tools/gopls@latest`")
    print("           Rust:  `rustup component add rust-analyzer`")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(
        prog="neruva-control-install",
        description=(
            "One-shot install for the Neruva Control daemon. "
            "Generates a token, registers a background service, and "
            "prints a one-time URL to link your browser to Cockpit."
        ),
    )
    p.add_argument("--no-service", action="store_true",
                   help="Skip OS service registration (run `neruva-control start` yourself).")
    p.add_argument("--reinstall", action="store_true",
                   help="Rotate the token even if one already exists.")
    p.add_argument("--base", default="https://app.neruva.io",
                   help="Cockpit base URL (default: https://app.neruva.io).")
    p.add_argument("--skip-capabilities", action="store_true",
                   help="Skip the one-time download of Playwright Chromium "
                        "+ Tesseract OCR. Some Computer-agent actions "
                        "(browser, ocr_screen) will return 'not installed' "
                        "errors until you run --reinstall.")
    args = p.parse_args(argv)

    print()
    print("Installing Neruva Control...")
    print()

    # 1. Token
    if token_path().exists() and not args.reinstall:
        from ._config import load_token
        token = load_token()
        print(f"  [skip] Token already present at {token_path()}")
        print(f"         (re-run with --reinstall to rotate it)")
    else:
        token = gen_token()
        write_token(token)
        print(f"  [ok]   Token written to {token_path()}")

    # 2. Service registration
    if args.no_service:
        print("  [skip] Service registration (--no-service set)")
        service_msg = "skipped"
        service_ok = False
    else:
        service_ok, service_msg = _install_service()
        marker = "[ok]" if service_ok else "[warn]"
        print(f"  {marker} {service_msg}")

    # 3. Auto-install optional capability backends so the daemon's
    # full action surface works out of the box.
    if not args.skip_capabilities:
        _install_capabilities()
    else:
        print("  [skip] capability backends (--skip-capabilities set)")

    # 4. Wait for daemon to come up (if we just registered + started one)
    if service_ok:
        up = _wait_for_daemon()
        if up:
            print(f"  [ok]   Daemon listening on 127.0.0.1:{PORT}")
        else:
            print(f"  [warn] Daemon didn't come up within 10s; check logs at {config_dir()}/daemon.log")
    else:
        print()
        print(f"  Auto-service didn't register. Start the daemon manually with:")
        print(f"    neruva-control start")
        print(f"  (then re-run this command, or run `neruva-control link`)")

    # 4. Print the fragment URL
    print()
    print("=" * 70)
    print()
    print("Open this URL in your browser to link this machine:")
    print()
    print(f"  {cockpit_link_url(token, args.base)}")
    print()
    print("Same machine, same browser. Token is stashed in localStorage; the")
    print("URL fragment is stripped after first load. Bookmark app.neruva.io/cockpit.")
    print()
    print("=" * 70)
    print()
    return 0 if service_ok or args.no_service else 1


if __name__ == "__main__":
    sys.exit(main())
