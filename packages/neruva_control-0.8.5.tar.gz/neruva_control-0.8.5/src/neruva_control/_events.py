"""Daemon-wide event bus for cross-device live sync.

Anything that mutates daemon state (new session, project change, API key
set, trusted device paired/revoked, ...) calls ``publish(kind, **data)``.
Every connected browser holds an open WS to /v1/events and receives the
frame instantly. No polling.

Single-process, single-loop. Listeners are bounded asyncio.Queues so a
slow consumer can't backpressure the publisher: if the queue is full the
oldest event is dropped (this keeps a hung browser from starving the
others). 256-deep queue is comfortable for spikes during smoke tests etc.
"""
from __future__ import annotations

import asyncio
import logging
import time
from typing import Any

log = logging.getLogger("neruva_control.events")


_QUEUE_DEPTH = 256
_LISTENERS: set[asyncio.Queue] = set()


def subscribe() -> asyncio.Queue:
    q: asyncio.Queue = asyncio.Queue(maxsize=_QUEUE_DEPTH)
    _LISTENERS.add(q)
    log.debug("events: subscriber added (total=%d)", len(_LISTENERS))
    return q


def unsubscribe(q: asyncio.Queue) -> None:
    _LISTENERS.discard(q)
    log.debug("events: subscriber removed (total=%d)", len(_LISTENERS))


def publish(kind: str, **data: Any) -> None:
    """Fire-and-forget broadcast. Safe to call from anywhere in the
    daemon process. If a queue is full, drop the oldest event for that
    listener rather than blocking the publisher."""
    frame = {"kind": kind, "ts_ms": int(time.time() * 1000), **data}
    if not _LISTENERS:
        return
    for q in list(_LISTENERS):
        try:
            q.put_nowait(frame)
        except asyncio.QueueFull:
            try: q.get_nowait()
            except Exception: pass
            try: q.put_nowait(frame)
            except Exception: pass


def listener_count() -> int:
    return len(_LISTENERS)
