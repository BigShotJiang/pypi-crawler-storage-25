"""Centralized tool catalog for MCP-style dynamic discovery.

Today's prompt inlines every action's full description; that's fine
at 20 tools but bloats fast as we add MCP servers, project skills,
custom actions. Anthropic's Claude Code default-on "Tool Search"
pattern: list names + 1-line summaries in the prompt, fetch full
schemas on demand via ``tool_describe({name})``. -85% prompt token
overhead per Anthropic.

The agent's system prompt should reference these by name; full
schemas live here and are returned on demand.
"""
from __future__ import annotations

from typing import Optional


# Action name -> {summary, schema}. Schema is freeform text describing
# args + behavior, not strictly JSON Schema (keeps it cheap to render).
CODE_TOOLS: dict[str, dict] = {
    "read_file": {
        "summary": "Read a file. Always before editing.",
        "schema": "args: {path: str}. Returns {ok, content, n_bytes, path}.",
    },
    "write_file": {
        "summary": "Create or overwrite a file (gated -- user approves).",
        "schema": "args: {path: str, content: str}. Emits pending_approval first.",
    },
    "edit_file": {
        "summary": "Exact-match replace in a file (gated).",
        "schema": "args: {path: str, old: str, new: str}. old must occur exactly once.",
    },
    "glob": {
        "summary": "Find files by glob pattern. 'src/**/*.py'.",
        "schema": "args: {pattern: str, dir?: str}. Returns {paths: [...], n_matches}.",
    },
    "grep": {
        "summary": "Regex search across files.",
        "schema": "args: {pattern, glob?, dir?, output_mode: 'files'|'content'|'count'}.",
    },
    "run_bash": {
        "summary": "Run a shell command. background:true for long runs.",
        "schema": "args: {command, background?}. Returns stdout/stderr or {task_id} when bg.",
    },
    "read_background": {
        "summary": "Read output of a previously-started background bash.",
        "schema": "args: {task_id, tail_lines?}.",
    },
    "web_fetch": {
        "summary": "Fetch a URL, return cleaned text body.",
        "schema": "args: {url}. HTML scripts/styles stripped; first 5KB returned.",
    },
    "browser": {
        "summary": "Real browser (Playwright) for web tasks + E2E tests.",
        "schema": ("args: {verb, args}. verbs: open(url,headless?), navigate(url), "
                   "snapshot, click(selector|text), fill(selector,text), press(key), "
                   "screenshot(path?), wait_for(selector|text), content(selector?), close."),
    },
    "todo_write": {
        "summary": "Create/update a task checklist for multi-step work.",
        "schema": ("args: {items: [{id, content, status}]} -- "
                   "status: pending|in_progress|completed."),
    },
    "subagent": {
        "summary": "Spawn a same-type sub-worker with isolated context.",
        "schema": "args: {task, max_steps?}. Returns {ok, summary, n_steps}.",
    },
    "delegate": {
        "summary": "Hand off to Neruva Computer for screen tasks.",
        "schema": "args: {to: 'computer', task, max_steps?}. Returns {ok, summary}.",
    },
    "repo_map": {
        "summary": "Compact symbol outline of a project. Use FIRST in new codebases.",
        "schema": "args: {dir?, max_files?}. Returns symbol-per-line summary.",
    },
    "index_project": {
        "summary": "Index a project tree into the substrate for semantic search.",
        "schema": ("args: {path, namespace?, max_files?}. Run this BEFORE "
                   "code_search if the project hasn't been indexed yet. "
                   "Chunks files at AST boundaries + pushes to substrate."),
    },
    "code_search": {
        "summary": "Semantic search across an indexed codebase.",
        "schema": ("args: {query, namespace?, top_k?}. If 0 hits, call "
                   "index_project({path: <dir>}) first then retry."),
    },
    "load_skill": {
        "summary": "Load a named skill playbook (skill index appears in prompt).",
        "schema": "args: {name}. Returns full skill body.",
    },
    "lsp_diagnostics": {
        "summary": "Type errors / undefined names / unused imports for a file.",
        "schema": ("args: {path}. Returns {n_errors, n_warnings, "
                   "diagnostics: [{severity, line, col, message, source, code}]}. "
                   "ALWAYS run this on a file you've just written/edited "
                   "before saying you're done."),
    },
    "lsp_hover": {
        "summary": "Get the type signature + docstring at file:line:col.",
        "schema": ("args: {path, line, col}. Use BEFORE calling an unfamiliar "
                   "function -- gives you the real signature so you stop "
                   "hallucinating API shapes."),
    },
    "lsp_goto_definition": {
        "summary": "Resolve a symbol at file:line:col to its actual definition file/line.",
        "schema": ("args: {path, line, col}. Returns [{path, line, col}]. "
                   "Use this BEFORE editing a function you didn't write -- "
                   "find the real source instead of guessing which file."),
    },
    "lsp_find_references": {
        "summary": "Every place a symbol is used in the project.",
        "schema": ("args: {path, line, col}. Use BEFORE renaming or "
                   "refactoring -- see every call site so your edit doesn't "
                   "leave dangling references."),
    },
    "lsp_workspace_symbol": {
        "summary": "Fuzzy search for a symbol name across the whole project.",
        "schema": "args: {query, lang?}. Returns [{name, kind, path, line, col}].",
    },
    "lsp_status": {
        "summary": "Which language servers are installed and ready.",
        "schema": "args: {}. Returns {available: {python: bool, typescript: bool, ...}}.",
    },
    "tool_describe": {
        "summary": "Get the full schema for any action by name.",
        "schema": "args: {name}. Returns this tool's full schema text.",
    },
    "say": {
        "summary": "Final summary to user. ALWAYS your last action.",
        "schema": "args: {text}. Renders as an assistant chat bubble.",
    },
    "done": {
        "summary": "Bare task-complete with NO recap. Prefer 'say'.",
        "schema": "args: {}. Ends the loop with no chat output.",
    },
}

COMPUTER_TOOLS: dict[str, dict] = {
    "click": {
        "summary": "Click at absolute (x,y) pixel coords.",
        "schema": "args: {x, y}. Coords must match the screenshot dimensions.",
    },
    "type": {
        "summary": "Type text via clipboard paste.",
        "schema": "args: {text}.",
    },
    "key": {
        "summary": "Press a key or hotkey.",
        "schema": "args: {keys: str | [str,...]}. e.g. 'enter' or ['ctrl','a'].",
    },
    "scroll": {
        "summary": "Scroll the focused window.",
        "schema": "args: {amount: int}. Positive=up, negative=down.",
    },
    "wait": {
        "summary": "Sleep for N ms.",
        "schema": "args: {ms: int}.",
    },
    "clipboard_get": {
        "summary": "Read the system clipboard.",
        "schema": "args: {}. Returns {text, n_chars, truncated}.",
    },
    "clipboard_set": {
        "summary": "Write text to the system clipboard.",
        "schema": "args: {text}.",
    },
    "window_list": {
        "summary": "List open windows with title/bounds. Use BEFORE clicking blindly.",
        "schema": "args: {}. Returns {windows: [{title, x, y, w, h, active, minimized}]}.",
    },
    "window_focus": {
        "summary": "Focus a window by title substring. Beats taskbar clicks.",
        "schema": "args: {title: str}.",
    },
    "screen_ax": {
        "summary": "Extract accessibility-tree elements (named, bounded UI elts).",
        "schema": ("args: {region?, window_title?, max_elements?}. "
                   "STRONGLY PREFER over guessing coords. Returns "
                   "{elements: [{id, role, name, bbox, ...}]}."),
    },
    "find_element": {
        "summary": "Natural-language element finder (ax-tree, OCR fallback).",
        "schema": ("args: {description}. e.g. 'the Continue button bottom right'. "
                   "Returns {element: {id, center, name, ...}}."),
    },
    "click_ref": {
        "summary": "Click by ax-tree element id. More reliable than {x,y}.",
        "schema": "args: {id}.",
    },
    "ocr_screen": {
        "summary": "OCR a screen region (Tesseract). Fallback when ax-tree empty.",
        "schema": "args: {region?: [x,y,w,h]}. Returns {lines: [{text, bbox, conf}]}.",
    },
    "browser": {
        "summary": "Real browser (Playwright) for web tasks.",
        "schema": ("args: {verb, args}. verbs: open(url), navigate(url), snapshot, "
                   "click(selector|text), fill(selector,text), press(key), "
                   "screenshot(path?), close. Prefer this over a browser screenshot."),
    },
    "delegate": {
        "summary": "Hand off to Neruva Code for file/bash tasks.",
        "schema": "args: {to: 'code', task, max_steps?}. Returns {ok, summary}.",
    },
    "tool_describe": {
        "summary": "Get the full schema for any action by name.",
        "schema": "args: {name}. Returns this tool's full schema text.",
    },
    "say": {
        "summary": "Final summary to user. ALWAYS your last action.",
        "schema": "args: {text}.",
    },
    "done": {
        "summary": "Bare task-complete. Prefer 'say'.",
        "schema": "args: {}.",
    },
}


def describe(agent: str, name: str) -> Optional[dict]:
    catalog = CODE_TOOLS if agent == "code" else COMPUTER_TOOLS
    return catalog.get(name.strip().lower())


def slim_index(agent: str) -> str:
    """Render the slim 'name: summary' index for system prompts."""
    catalog = CODE_TOOLS if agent == "code" else COMPUTER_TOOLS
    lines = []
    for name, meta in catalog.items():
        lines.append(f"  {name}: {meta['summary']}")
    return "\n".join(lines)
