"""Neruva Computer agent loop: screenshot + pyautogui executor +
substrate plan-caching + chat-steering.

The action model itself runs server-side at api.neruva.io. The daemon
sends a screenshot + task + history to /v1/agent/computer/step and
gets back the next action JSON. Vendor identity is fully server-side
(trade-secret IP); the daemon only knows "Neruva Computer."

Flow:
  1. Look up cached plan for `task_text` via substrate.
  2. If hit with score >= 0.85 and success_rate >= 0.8 -> replay
     cached plan locally (skips per-step model call, ~50% cheaper
     per the APC paper).
  3. Else: screenshot -> substrate /computer/step -> pyautogui execute
     -> repeat until 'done' or max_steps.
  4. Save plan (success or fail) to substrate as kind='plan_template'.
"""
from __future__ import annotations

import asyncio
import base64
import io
import json
import os
import time
from typing import Any, Awaitable, Callable, Optional

import httpx

from ._agent_memory import (
    classify_task,
    extract_cached_plan,
    format_lessons_preamble,
    infer_app,
    recall_lessons,
    remember_step_async,
    remember_task_end_async,
)

# Lazy imports for pyautogui + PIL so the daemon module loads even when
# the local environment can't import them (CI / headless). The agent
# endpoint guards on these being available at request time.
try:
    import pyautogui   # type: ignore
    _PYAUTOGUI_OK = True
except Exception as _e:
    pyautogui = None   # type: ignore
    _PYAUTOGUI_OK = False
    _PYAUTOGUI_ERR = str(_e)

try:
    from PIL import Image   # type: ignore
    _PIL_OK = True
except Exception as _e:
    Image = None   # type: ignore
    _PIL_OK = False
    _PIL_ERR = str(_e)


NERUVA_BASE_URL = os.environ.get("NERUVA_URL", "https://api.neruva.io")

# Some action models emit coords normalized to [0, 1000]; we convert
# to absolute pixels using the captured (screen_w, screen_h). Set
# NERUVA_HOLO_NORMALIZED=1 to enable; default is pass-through (most
# models emit absolute pixels matching the screenshot dims).
_NORM_BASIS = 1000

# Default safety guards on the action loop.
_DEFAULT_MAX_STEPS = 20
_DEFAULT_INTER_STEP_SLEEP_S = 0.3
_DEFAULT_STEP_TIMEOUT_S = 60.0
_DEFAULT_SUBSTRATE_TIMEOUT_S = 10.0
_CACHE_SCORE_THRESHOLD = 0.85
_CACHE_SUCCESS_RATE_THRESHOLD = 0.8


def _require_executor() -> Optional[str]:
    """Return None if pyautogui+PIL are importable; else a human error."""
    if not _PYAUTOGUI_OK:
        return f"pyautogui not installed: {_PYAUTOGUI_ERR}"
    if not _PIL_OK:
        return f"Pillow not installed: {_PIL_ERR}"
    return None


def grab_screenshot() -> tuple[bytes, int, int]:
    """Capture the current screen as PNG bytes + (width, height)."""
    img = pyautogui.screenshot()
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return buf.getvalue(), int(img.width), int(img.height)


def pick_action(
    task_text: str,
    png_bytes: bytes,
    history: list[dict],
    *,
    timeout: float = _DEFAULT_STEP_TIMEOUT_S,
    neruva_api_key: Optional[str] = None,
) -> dict:
    """Ask the Neruva Computer action model for ONE next action via
    the substrate proxy. Daemon needs only NERUVA_API_KEY; vendor key
    + identity stay server-side.

    Returns the parsed JSON action dict. Raises on transport failure
    -- caller decides whether to abort the task."""
    api_key = neruva_api_key or os.environ.get("NERUVA_API_KEY", "").strip()
    if not api_key:
        raise RuntimeError(
            "NERUVA_API_KEY not configured. Get one at "
            "https://app.neruva.io and put it in ~/.config/neruva/.env."
        )
    b64 = base64.b64encode(png_bytes).decode()
    # Use the shared retry helper so transient Cloud Run edge 429s
    # (cold start / autoscale burst) don't kill the very first step.
    r = _substrate_post_retry(
        f"{NERUVA_BASE_URL}/v1/agent/computer/step",
        {
            "task_text": task_text,
            "history": history[-6:] if history else [],
            "screenshot_b64": b64,
        },
        api_key,
        timeout=timeout,
    )
    if r is None:
        raise RuntimeError("substrate unreachable after retries")
    r.raise_for_status()
    return r.json().get("action") or {}


# Back-compat alias for internal callers; will be removed in 0.5.0.
holo3_pick_action = pick_action  # noqa: F401


def _parse_action_lenient(body: str) -> dict:
    """Parse an action response, repairing common malformed shapes.
    Server-side parsing usually handles this, but keep a fallback for
    direct/legacy paths. Some models truncate mid-string, wrap in
    ``` fences, or emit text before the JSON object."""
    s = body.strip()
    # Strip code fences.
    if s.startswith("```"):
        s = s.lstrip("`")
        if s.startswith("json"):
            s = s[4:]
        s = s.strip()
    if s.endswith("```"):
        s = s[:-3].strip()
    # Try as-is.
    try:
        return json.loads(s)
    except json.JSONDecodeError:
        pass
    # Extract first {...} object.
    import re as _re
    m = _re.search(r"\{[\s\S]*?\}", s)
    if m:
        try:
            return json.loads(m.group(0))
        except json.JSONDecodeError:
            pass
    # Truncated mid-string: try repairing by closing quote + brace.
    if s.count('"') % 2 == 1:
        try:
            return json.loads(s + '"}')
        except json.JSONDecodeError:
            pass
    # Give up; treat as 'done' so the agent doesn't loop forever.
    return {"action": "done", "reasoning": f"parse failed: {s[:120]}"}


def _pick(action: dict, key: str, default=None):
    """Forgiving param lookup: model may emit args at top level (action.x)
    OR nested under args (action.args.x). Look in both places."""
    if key in action:
        return action[key]
    args = action.get("args") or {}
    return args.get(key, default)


# ---------- Plan-arg-fill (systemic fix for Holo3 dropping args) -----
# Magistral plans every step with args; Holo3 sometimes emits the
# action name without the args. Instead of failing, we look at the
# corresponding plan step and back-fill the missing args. The model's
# decisions (if it DID emit args) always win on conflict.

import re as _re

_PLAN_STEP_RE = _re.compile(r"^\s*(\w+)\s*\(\s*(.*?)\s*\)\s*$", _re.DOTALL)


def _parse_plan_step(step_str: str) -> dict:
    """Parse a Magistral plan-step string like
    `browser({verb:'click',args:{selector:'#x'}})` into
    `{'action': 'browser', 'args': {verb:'click', args:{selector:'#x'}}}`.
    Returns {} on failure -- caller no-ops the merge.

    Robust to: mixed single/double quote nesting (`'input[name="q"]'`),
    JS-style bare keys, trailing commas. Uses ast.literal_eval as the
    last-resort parser since it natively handles Python-style strings."""
    if not step_str or not isinstance(step_str, str):
        return {}
    m = _PLAN_STEP_RE.match(step_str.strip())
    if not m:
        return {}
    action_name = m.group(1)
    body = m.group(2).strip()
    if not body:
        return {"action": action_name, "args": {}}
    # Try 1: ast.literal_eval handles Python-style {} dicts with
    # single OR double quoted strings AND mixed nesting cleanly.
    # Needs bare keys quoted first (turns `verb:'x'` into `'verb':'x'`).
    try:
        import ast as _ast
        py_body = _re.sub(
            r"(?<=[\{,])\s*([A-Za-z_][\w-]*)\s*:", r" '\1':", body)
        # Also handle the leading key (right after '{')
        py_body = _re.sub(
            r"\{\s*([A-Za-z_][\w-]*)\s*:", r"{'\1':", py_body, count=1)
        args = _ast.literal_eval(py_body)
        if isinstance(args, dict):
            return {"action": action_name, "args": args}
    except Exception:
        pass
    # Try 2: best-effort JSON coerce (works when no nested quoting)
    try:
        body_j = _re.sub(r"(?<![\"\\])'", '"', body)
        body_j = _re.sub(r"(\{|,)\s*([A-Za-z_][\w-]*)\s*:", r'\1"\2":', body_j)
        args = json.loads(body_j)
        if isinstance(args, dict):
            return {"action": action_name, "args": args}
    except Exception:
        pass
    return {"action": action_name}


def _deep_merge(base: dict, overlay: dict) -> dict:
    """Recursive dict merge. `overlay` wins on conflict."""
    result = dict(base or {})
    for k, v in (overlay or {}).items():
        if isinstance(v, dict) and isinstance(result.get(k), dict):
            result[k] = _deep_merge(result[k], v)
        else:
            result[k] = v
    return result


def merge_plan_args(action: dict, plan: list[str], step_idx: int) -> dict:
    """If `plan[step_idx]` is the same primitive as `action`, back-fill
    any args the model dropped. The model's emitted values always win;
    we only ADD args that are missing.

    For the common case: Magistral planned
    `browser({verb:'click',args:{selector:'#search a'}})`, Holo3 emitted
    `{action:'browser', args:{verb:'click'}}`. After merge: the selector
    is restored. Holo3 made the high-level decision (click); Magistral's
    arg-knowledge fills the gap."""
    if not plan or step_idx < 0 or step_idx >= len(plan):
        return action
    parsed = _parse_plan_step(plan[step_idx])
    if not parsed or parsed.get("action") != action.get("action"):
        return action
    plan_args = parsed.get("args") or {}
    # Special case for browser: only merge if verbs match. Different
    # verb means Holo3 deviated from the plan -- don't paste in the
    # wrong args.
    if action.get("action") == "browser":
        plan_verb = (plan_args.get("verb") or "")
        emit_verb = ((action.get("args") or {}).get("verb")
                     or action.get("verb") or "")
        if plan_verb and emit_verb and plan_verb != emit_verb:
            return action
    merged = dict(action)
    merged["args"] = _deep_merge(plan_args, action.get("args") or {})
    return merged


# Primitives that operate on the DESKTOP (pyautogui-level). Distinct
# from `browser` (Playwright on its own Chromium instance). When the
# plan says `browser(...)` and Holo3 emits one of these, Holo3 is
# clicking the user's screen instead of the Playwright window -- the
# core "two browsers" failure mode. Plan wins on this conflict.
_DESKTOP_PRIMITIVES = {"click", "type", "key", "scroll", "double_click",
                       "right_click", "drag", "move"}


def enforce_plan_compliance(
    action: dict, plan: list[str], step_idx: int,
) -> tuple[dict, bool]:
    """When the plan says `browser(...)` but Holo3 emitted a raw desktop
    primitive (click/type/key/...), REPLACE the model's action with the
    plan's. Magistral planned around Playwright -- letting Holo3 click
    pixels on the user's desktop instead means we lose the Playwright
    page state AND probably click the wrong window.

    Returns (action, overridden_bool). When overridden=True, caller
    should emit a `plan_enforced` event so the UX surfaces the override
    (otherwise it looks like the model just decided to do that).

    Trusted exceptions (we DON'T override): `say` and `done` -- those
    are intentional Holo3 control-flow decisions, not perception slips."""
    if not plan or step_idx < 0 or step_idx >= len(plan):
        return action, False
    action_type = str(action.get("action", "")).lower()
    if action_type in ("say", "done", "browser", "delegate"):
        return action, False
    parsed = _parse_plan_step(plan[step_idx])
    if not parsed:
        return action, False
    plan_action = str(parsed.get("action", "")).lower()
    if plan_action != "browser":
        return action, False
    # Plan said browser; Holo3 emitted a desktop primitive. Override.
    if action_type in _DESKTOP_PRIMITIVES:
        plan_args = parsed.get("args") or {}
        return {
            "action": "browser",
            "args": plan_args,
            "reasoning": (
                f"plan_enforced: model emitted {action_type!r}, plan says "
                f"browser({plan_args.get('verb', '?')}) -- following plan "
                f"to preserve Playwright state"
            ),
        }, True
    return action, False


def _maybe_normalize_coord(v: int, screen_dim: int) -> int:
    """The Neruva Computer action model emits absolute pixel coords
    matching the screenshot dimensions. We trust the model output as-is
    by default. Set NERUVA_NORM_COORDS=1 to convert from [0, 1000]
    normalized space instead."""
    if os.environ.get("NERUVA_NORM_COORDS") == "1":
        if 0 <= v <= _NORM_BASIS:
            return int(v / _NORM_BASIS * screen_dim)
    return int(v)


def execute_action(action: dict, screen_w: int, screen_h: int) -> dict:
    """Run one action via pyautogui. Returns {ok, ...} or {ok: False, error}.

    Tolerant of two shapes: {action: 'click', x:..., y:...} OR
    {action: 'click', args: {x:..., y:...}}. Both flat + nested are
    accepted by upstream vendors -- normalize here.
    """
    a = str(action.get("action", "")).lower()
    try:
        if a == "click":
            x_raw = int(_pick(action, "x", 0))
            y_raw = int(_pick(action, "y", 0))
            x = _maybe_normalize_coord(x_raw, screen_w)
            y = _maybe_normalize_coord(y_raw, screen_h)
            # Clamp into the visible screen with a 2px safety margin from
            # the edges (pyautogui FAILSAFE triggers on exact corners).
            # Refuse degenerate clicks at (0,0) -- the model probably
            # had nothing to click and we'd just hit the failsafe.
            x = max(2, min(x, screen_w - 2))
            y = max(2, min(y, screen_h - 2))
            if x_raw <= 0 and y_raw <= 0:
                return {"ok": False,
                        "error": "click target (0,0) -- model emitted no coords. Try keyboard win/enter/etc. instead."}
            try:
                pyautogui.click(x, y)
            except Exception as e:
                return {"ok": False,
                        "error": f"pyautogui.click({x},{y}) failed: {type(e).__name__}: {e}"}
            return {"ok": True, "px": [x, y]}
        if a == "type":
            text = str(_pick(action, "text", ""))
            # Clipboard paste is ~10x more reliable than typewrite() on
            # Windows: handles unicode + special chars, doesn't race with
            # newly-focused windows that miss the first few keystrokes.
            # Fall back to typewrite() if pyperclip is unavailable.
            try:
                import pyperclip   # type: ignore
                pyperclip.copy(text)
                pyautogui.hotkey("ctrl", "v")
                return {"ok": True, "typed_n": len(text), "via": "paste"}
            except Exception:
                pyautogui.typewrite(text, interval=0.02)
                return {"ok": True, "typed_n": len(text), "via": "typewrite"}
        if a == "key":
            keys = _pick(action, "keys", _pick(action, "key", ""))
            if isinstance(keys, list):
                pyautogui.hotkey(*[str(k).lower() for k in keys])
            else:
                pyautogui.press(str(keys).lower())
            return {"ok": True, "key": keys}
        if a == "scroll":
            amt = int(_pick(action, "amount", _pick(action, "amt", 0)))
            pyautogui.scroll(amt)
            return {"ok": True, "scrolled": amt}
        if a == "wait":
            ms = int(_pick(action, "ms", _pick(action, "duration_ms", 500)))
            time.sleep(ms / 1000.0)
            return {"ok": True, "waited_ms": ms}
        if a == "clipboard_get":
            try:
                import pyperclip
                text = pyperclip.paste() or ""
                return {"ok": True, "text": text[:4000],
                        "n_chars": len(text), "truncated": len(text) > 4000}
            except Exception as e:
                return {"ok": False, "error": f"clipboard: {e}"}
        if a == "clipboard_set":
            try:
                import pyperclip
                pyperclip.copy(str(_pick(action, "text", "")))
                return {"ok": True}
            except Exception as e:
                return {"ok": False, "error": f"clipboard: {e}"}
        if a == "window_list":
            try:
                import pygetwindow as gw
                wins = []
                for w in gw.getAllWindows():
                    title = (getattr(w, "title", "") or "").strip()
                    if not title:
                        continue
                    wins.append({
                        "title": title[:120],
                        "x": int(getattr(w, "left", 0)),
                        "y": int(getattr(w, "top", 0)),
                        "w": int(getattr(w, "width", 0)),
                        "h": int(getattr(w, "height", 0)),
                        "active": bool(getattr(w, "isActive", False)),
                        "minimized": bool(getattr(w, "isMinimized", False)),
                    })
                return {"ok": True, "n_windows": len(wins), "windows": wins[:40]}
            except Exception as e:
                return {"ok": False,
                        "error": f"window_list unavailable: {e}"}
        if a == "tool_describe":
            from ._tool_catalog import describe
            name = str(_pick(action, "name", "")).strip()
            if not name:
                return {"ok": False, "error": "name required"}
            meta = describe("computer", name)
            if not meta:
                return {"ok": False, "error": f"unknown tool: {name!r}"}
            return {"ok": True, "name": name,
                    "summary": meta["summary"], "schema": meta["schema"]}

        if a == "browser":
            from ._browser import browser_action
            verb = str(_pick(action, "verb", "")).strip() or \
                   str(_pick(action, "command", "")).strip()
            args = _pick(action, "args", {}) or {}
            if not verb:
                for k in ("open", "navigate", "snapshot", "click", "fill",
                          "type", "press", "screenshot", "wait_for",
                          "content", "close"):
                    if k in action:
                        verb = k
                        if isinstance(action.get(k), dict):
                            args = action[k]
                        break
            # Unwrap double-nested args shape: Magistral plans
            # `browser({verb:'fill',args:{selector:...,text:...}})`, so
            # `args` here is `{verb:'fill', args:{selector,text}}`. The
            # selector/text live one level deeper. Flatten to the verb-
            # specific args dict the executor expects.
            if isinstance(args, dict):
                if "verb" in args and isinstance(args.get("args"), dict):
                    # If verb wasn't already set from the top level,
                    # pull it from the nested envelope too.
                    if not verb:
                        verb = str(args.get("verb", "")).strip()
                    args = args["args"]
            return browser_action(verb, args if isinstance(args, dict) else {})

        if a == "ocr_screen":
            from ._ocr import ocr_screen
            region = _pick(action, "region", None)
            if region and isinstance(region, list) and len(region) == 4:
                region_t = tuple(int(v) for v in region)
            else:
                region_t = None
            return ocr_screen(region=region_t)

        if a == "screen_ax":
            from ._axtree import get_axtree
            region = _pick(action, "region", None)
            if region and isinstance(region, list) and len(region) == 4:
                region_t = tuple(int(v) for v in region)
            else:
                region_t = None
            window_title = str(_pick(action, "window_title", "")).strip() or None
            res = get_axtree(region=region_t, window_title=window_title,
                             max_elements=200)
            # Trim element list for prompt size
            if res.get("ok") and len(res.get("elements", [])) > 80:
                res["elements"] = res["elements"][:80]
                res["truncated"] = True
            return res

        if a == "find_element":
            from ._axtree import find_element
            description = str(_pick(action, "description", "")).strip()
            return find_element(description)

        if a == "click_ref":
            # Click the center of an ax-tree element by id (returned by
            # screen_ax / find_element). More reliable than raw coords.
            from ._axtree import get_axtree
            ref_id = str(_pick(action, "id", "")).strip()
            if not ref_id:
                return {"ok": False, "error": "id required"}
            ax = get_axtree(max_elements=300)
            if not ax.get("ok"):
                return {"ok": False, "error": ax.get("error", "ax-tree unavailable")}
            for el in ax.get("elements", []):
                if el.get("id") == ref_id:
                    bx = el["bbox"]
                    cx, cy = bx[0] + bx[2] // 2, bx[1] + bx[3] // 2
                    cx = max(0, min(screen_w - 1, cx))
                    cy = max(0, min(screen_h - 1, cy))
                    pyautogui.click(cx, cy)
                    return {"ok": True, "clicked_ref": ref_id,
                            "name": el.get("name"), "x": cx, "y": cy}
            return {"ok": False, "error": f"no element with id={ref_id}"}

        if a == "window_focus":
            title_q = str(_pick(action, "title", "")).strip().lower()
            if not title_q:
                return {"ok": False, "error": "title required"}
            try:
                import pygetwindow as gw
                matches = [w for w in gw.getAllWindows()
                           if title_q in (getattr(w, "title", "") or "").lower()]
                if not matches:
                    return {"ok": False, "error": f"no window matches {title_q!r}"}
                w = matches[0]
                try:
                    if getattr(w, "isMinimized", False):
                        w.restore()
                    w.activate()
                except Exception:
                    pass
                return {"ok": True, "focused": (w.title or "")[:120]}
            except Exception as e:
                return {"ok": False, "error": f"window_focus: {e}"}
        if a == "done":
            return {"ok": True, "done": True}
        if a == "say":
            text = str(_pick(action, "text", ""))
            return {"ok": True, "said": text}
        return {"ok": False, "error": f"unknown action: {a!r}"}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def _substrate_post_retry(
    url: str, body: dict, api_key: str,
    *, max_attempts: int = 5, base_delay_s: float = 0.5,
    timeout: float = _DEFAULT_SUBSTRATE_TIMEOUT_S,
) -> Optional[httpx.Response]:
    """POST to substrate with exponential backoff on 429s.
    Returns the final Response (success or last failure) or None on
    transport failure across all attempts."""
    delay = base_delay_s
    last_r: Optional[httpx.Response] = None
    for attempt in range(max_attempts):
        try:
            with httpx.Client(timeout=timeout) as cli:
                r = cli.post(
                    url,
                    headers={"Api-Key": api_key,
                             "Content-Type": "application/json"},
                    json=body,
                )
            last_r = r
            if r.status_code != 429:
                return r
        except Exception:
            pass
        # 429 or transport error -- wait and retry.
        time.sleep(delay)
        delay = min(delay * 2, 8.0)
    return last_r


async def _emit(on_step: Optional[Callable[[dict], Awaitable[None]]],
                event: dict) -> None:
    if on_step is None:
        return
    try:
        await on_step(event)
    except Exception:
        pass   # never let UI emit break the loop


async def run_task(
    task_text,
    namespace: str = "cockpit_agent",
    *,
    neruva_api_key: Optional[str] = None,
    max_steps: int = _DEFAULT_MAX_STEPS,
    on_step: Optional[Callable[[dict], Awaitable[None]]] = None,
    use_cache: bool = True,
) -> dict:
    """Run a single Neruva Computer task end-to-end.

    `task_text` accepts either a string (static task) OR a zero-arg
    callable returning a string (dynamic task, re-read on every turn).
    The callable form is how chat-steering works: the SessionManager
    appends pending user directives to the task text on each call so
    they reach the next action-model prompt.

    Returns {ok, n_steps, duration_ms, used_cache, history, plan,
    cost_estimate_usd, model_calls}.
    """
    err = _require_executor()
    if err:
        return {"ok": False, "error": err, "n_steps": 0}

    # Normalize to callable.
    if callable(task_text):
        get_task = task_text
        initial_task_str = task_text()
    else:
        initial_task_str = str(task_text)
        get_task = lambda: initial_task_str   # noqa: E731

    nv_key = neruva_api_key or os.environ.get("NERUVA_API_KEY", "")
    t0 = time.perf_counter()
    plan_used_from_cache = False
    plan: list[dict] = []
    history: list[dict] = []
    success = False
    model_calls = 0
    magistral_plan: list[str] = []

    # Recursive-memory layer: classify task + recall past lessons for
    # the same (task_class, app). These get injected into Holo3's
    # prompt as a `LEARNED:` block so the agent benefits from every
    # past run automatically. See _agent_memory.py for the contract.
    task_class = classify_task(initial_task_str)
    app_hint = infer_app(initial_task_str)
    lessons: list[dict] = []
    if nv_key:
        try:
            lessons = recall_lessons(
                task_text=initial_task_str,
                task_class=task_class, app=app_hint,
                namespace=namespace, api_key=nv_key,
            )
            if lessons:
                await _emit(on_step, {
                    "event": "lessons_loaded",
                    "n": len(lessons),
                    "task_class": task_class, "app": app_hint,
                })
        except Exception:
            pass

    # 1. Plan-cache lookup -- opportunistic only. Tight 2s deadline +
    # 2 retries: if it doesn't return fast, just go live. Cold-start
    # cache lookups should not gate the user's perceived spawn time.
    if use_cache and nv_key:
        try:
            r = _substrate_post_retry(
                f"{NERUVA_BASE_URL}/v1/agent/plan_cache_lookup",
                {"namespace": namespace, "task_text": initial_task_str,
                 "top_k": 1, "min_score": _CACHE_SCORE_THRESHOLD},
                nv_key,
                max_attempts=2, base_delay_s=0.3, timeout=2.0,
            )
            if r is not None and r.status_code == 200:
                hits = r.json().get("hits", [])
                if hits and hits[0]["success_rate"] >= _CACHE_SUCCESS_RATE_THRESHOLD:
                    plan = hits[0]["plan"]
                    plan_used_from_cache = True
                    await _emit(on_step, {
                        "event": "plan_cache_hit",
                        "n_steps": len(plan),
                        "score": hits[0]["score"],
                        "record_id": hits[0]["record_id"],
                    })
        except Exception:
            pass

    # 1a-bis. Cached corrected_plan -- if recall surfaced a past
    # corrected_plan (from a Magistral postmortem of a prior similar
    # failure), USE IT directly and skip the planner. Saves ~4s + a
    # Magistral call AND uses a known-good recipe distilled from a
    # real past failure. The whole point of recursive memory.
    cached_corrected_plan = extract_cached_plan(lessons)
    if cached_corrected_plan and not plan_used_from_cache:
        magistral_plan = cached_corrected_plan
        await _emit(on_step, {
            "event": "magistral_plan",
            "plan": magistral_plan,
            "duration_ms": 0,
            "reasoning": "cached_corrected_plan from past postmortem",
            "vision": False,
            "source": "cached_corrected_plan",
        })

    # 1b. Magistral planner -- if no cache hit AND no recalled corrected
    # plan, ask Mistral's reasoning model for a 5-12 step skeleton plan
    # FIRST, then hand to Holo3. Fixes "agent wanders for 12 browser
    # steps without typing" -- the vision model is great at one-shot
    # perception but weak at multi-step planning. Best-quality-first;
    # planner cost is one Magistral call per task (a few cents) vs
    # paying for 20 lost Holo3 turns.
    #
    # Magistral 1.2 (magistral-medium-2509) has a vision encoder, so we
    # grab the current screen and send it -- screen-aware plans beat
    # blind text plans (e.g. planner sees the app is already open).
    if not plan_used_from_cache and nv_key and not magistral_plan:
        await _emit(on_step, {"event": "planning", "model": "neruva-computer-planner"})
        try:
            png0, _, _ = grab_screenshot()
            plan_shot_b64 = base64.b64encode(png0).decode()
        except Exception:
            plan_shot_b64 = None   # planner falls back to text-only
        try:
            r = _substrate_post_retry(
                f"{NERUVA_BASE_URL}/v1/agent/computer/plan",
                {"task_text": initial_task_str,
                 "screenshot_b64": plan_shot_b64},
                nv_key,
                max_attempts=2, base_delay_s=0.5, timeout=30.0,
            )
            if r is not None and r.status_code == 200:
                pj = r.json()
                magistral_plan = list(pj.get("plan") or [])
                await _emit(on_step, {
                    "event": "magistral_plan",
                    "plan": magistral_plan,
                    "duration_ms": pj.get("duration_ms"),
                    "reasoning": pj.get("reasoning"),
                    "vision": plan_shot_b64 is not None,
                })
        except Exception as e:
            await _emit(on_step, {
                "event": "plan_skipped",
                "error": f"{type(e).__name__}: {e}",
            })

    # Per-step recorder: fire-and-forget POST to /v1/agent/remember.
    # Keeps the loop free of substrate roundtrips while building the
    # cross-session learning corpus. Called from every branch below
    # (cache replay, delegate, say, normal action) so coverage is uniform.
    def _record_step(idx: int, action_dict: dict, result_dict: dict) -> None:
        remember_step_async(
            agent="computer", namespace=namespace,
            task_text=initial_task_str,
            task_class=task_class, app=app_hint,
            step_index=idx, action=action_dict, result=result_dict,
            api_key=nv_key,
        )

    # 2. Execute (cached or live-derived)
    if plan_used_from_cache:
        _, sw, sh = grab_screenshot()
        for i, step in enumerate(plan):
            await _emit(on_step, {
                "event": "step_start", "i": i, "step": step, "source": "cache",
            })
            res = execute_action(step, sw, sh)
            history.append({"step": step, "result": res})
            _record_step(i, step, res)
            await _emit(on_step, {
                "event": "step_done", "i": i, "result": res,
            })
            if not res.get("ok"):
                break
            await asyncio.sleep(_DEFAULT_INTER_STEP_SLEEP_S)
        success = all(h["result"].get("ok") for h in history)
    else:
        # Pre-format Magistral plan once -- it's the same skeleton every
        # turn. The executor sees a steering anchor + the live user task.
        plan_preamble = ""
        if magistral_plan:
            numbered = "\n".join(
                f"  {idx+1}. {step}" for idx, step in enumerate(magistral_plan)
            )
            plan_preamble = (
                "PLAN (Magistral pre-planned this; follow step by step, "
                "adapt if the screen differs):\n" + numbered + "\n\n"
            )
        # Prepend any LEARNED lessons from past runs of similar tasks.
        # This is the recursive-intelligence loop: every past mistake
        # becomes an inline hint for the next attempt.
        lessons_block = format_lessons_preamble(lessons)
        if lessons_block:
            plan_preamble = lessons_block + "\n\n" + plan_preamble
        for i in range(max_steps):
            # If a Playwright browser is open, force its window to the
            # foreground BEFORE we screenshot. Otherwise Holo3 sees
            # Dexpot / user's Chrome and raw click(x,y) lands on the
            # wrong window. The fix is idempotent + cheap (~5ms).
            try:
                from ._browser import focus_browser_window as _focus_pw
                _focus_pw()
            except Exception:
                pass
            png, sw, sh = grab_screenshot()
            await _emit(on_step, {
                "event": "screenshot", "i": i, "screen_wh": [sw, sh],
            })
            # Re-read task on every turn so chat-steering directives land.
            current_task = plan_preamble + get_task()
            try:
                action = pick_action(current_task, png, history,
                                     neruva_api_key=nv_key)
                model_calls += 1
            except Exception as e:
                await _emit(on_step, {
                    "event": "model_error", "i": i,
                    "error": f"{type(e).__name__}: {e}",
                })
                break
            # Plan-arg fill: if Magistral planned this step with full
            # args and Holo3 dropped them, back-fill from the plan.
            # See merge_plan_args docstring for the systemic rationale.
            if magistral_plan:
                action = merge_plan_args(action, magistral_plan, i)
                # Stronger guarantee: if plan says browser(...) but
                # Holo3 emitted a desktop click/type/key, FORCE the
                # plan. Holo3 is clicking the user's desktop instead
                # of the Playwright window -- losing browser state.
                action, plan_overrode = enforce_plan_compliance(
                    action, magistral_plan, i)
                if plan_overrode:
                    await _emit(on_step, {
                        "event": "plan_enforced", "i": i,
                        "note": "model tried desktop click; "
                                "running plan's browser step instead",
                        "action": action,
                    })
            await _emit(on_step, {
                "event": "action", "i": i, "action": action,
                "source": "neruva-computer",
            })
            action_type = str(action.get("action", "")).lower()
            if action_type == "done":
                # Refuse 'done' at step 0 with no work yet -- the model is
                # giving up before trying. Nudge it to act; if it fails
                # again next turn we accept the give-up honestly.
                if i == 0 and not history:
                    history.append({
                        "step": {"action": "done", "reasoning": "premature"},
                        "result": {"ok": False, "error":
                            "you emitted 'done' at step 0 with no work. "
                            "Look at the screenshot and pick a concrete "
                            "first action (click, type, key, scroll, etc.)."},
                    })
                    await _emit(on_step, {
                        "event": "premature_done", "i": i,
                        "note": "model gave up at step 0; nudging",
                    })
                    continue
                # Force a final `say` summary if model is going silent.
                already_summarized = any(
                    str((h.get("step") or {}).get("action", "")).lower() == "say"
                    for h in history
                )
                already_nudged = any(
                    "nudge:summary" == (h.get("step") or {}).get("reasoning", "")
                    for h in history
                )
                if history and not already_summarized and not already_nudged:
                    history.append({
                        "step": {"action": "done", "reasoning": "nudge:summary"},
                        "result": {"ok": False, "error":
                            "Before 'done', emit say({text}) summarizing "
                            "what you saw + what you did. The user wants "
                            "the recap."},
                    })
                    await _emit(on_step, {
                        "event": "summary_nudge", "i": i,
                        "note": "model tried to done without summary",
                    })
                    continue
                success = True
                break
            # ---- Cross-agent delegation: Computer -> Code ----
            if action_type == "delegate":
                args = action.get("args") or {}
                to = str(args.get("to") or action.get("to") or "").lower()
                d_task = str(args.get("task") or action.get("task") or "").strip()
                d_max = int(args.get("max_steps") or action.get("max_steps") or 10)
                d_max = max(2, min(20, d_max))
                if not d_task:
                    d_res = {"ok": False, "error": "delegate: task required"}
                elif to != "code":
                    d_res = {"ok": False, "error":
                             f"delegate: 'to' must be 'code' (got {to!r})"}
                else:
                    from ._code_agent import run_task as run_code_task
                    await _emit(on_step, {"event": "delegate_start",
                                          "i": i, "to": "code",
                                          "task": d_task[:200],
                                          "max_steps": d_max})
                    try:
                        d_result = await run_code_task(
                            d_task, namespace=namespace,
                            neruva_api_key=nv_key, max_steps=d_max,
                            on_step=on_step,
                        )
                    except Exception as e:
                        d_result = {"ok": False,
                                    "error": f"{type(e).__name__}: {e}",
                                    "n_steps": 0, "history": []}
                    d_history = d_result.get("history") or []
                    last_say = ""
                    for h in reversed(d_history):
                        step = h.get("step") or {}
                        if str(step.get("action", "")).lower() == "say":
                            last_say = str((step.get("text") or
                                            (step.get("args") or {}).get("text")
                                            or ""))[:400]
                            break
                    summary = (last_say or
                               f"code agent ran {d_result.get('n_steps', 0)} "
                               f"step(s); ok={d_result.get('ok')}")
                    d_res = {"ok": bool(d_result.get("ok")),
                             "delegated_to": "code",
                             "n_steps": d_result.get("n_steps", 0),
                             "duration_ms": d_result.get("duration_ms", 0),
                             "summary": summary}
                    await _emit(on_step, {"event": "delegate_done",
                                          "i": i, "to": "code",
                                          "result": d_res})
                plan.append(action)
                history.append({"step": action, "result": d_res})
                _record_step(i, action, d_res)
                await _emit(on_step, {"event": "step_done", "i": i,
                                      "result": d_res})
                await asyncio.sleep(_DEFAULT_INTER_STEP_SLEEP_S)
                continue

            # `say` is terminal for this turn -- emit the message, complete,
            # let the session loop wait for the user's next directive.
            if action_type == "say":
                res = execute_action(action, sw, sh)
                plan.append(action)
                history.append({"step": action, "result": res})
                _record_step(i, action, res)
                await _emit(on_step, {
                    "event": "step_done", "i": i, "result": res,
                })
                success = True
                break
            res = execute_action(action, sw, sh)
            plan.append(action)
            history.append({"step": action, "result": res})
            _record_step(i, action, res)
            await _emit(on_step, {
                "event": "step_done", "i": i, "result": res,
            })
            if not res.get("ok"):
                break
            await asyncio.sleep(_DEFAULT_INTER_STEP_SLEEP_S)

    duration_ms = int((time.perf_counter() - t0) * 1000)

    # 3. Save plan -- only if live-derived (cache hits would dupe records).
    # Retry-with-backoff guards against Cloud Run edge 429s from bursty
    # neighbor traffic. We index by the INITIAL task text so subsequent
    # runs of the same task (with no directives) hit the cache.
    saved = False
    if not plan_used_from_cache and nv_key and plan:
        r = _substrate_post_retry(
            f"{NERUVA_BASE_URL}/v1/agent/plan_cache_save",
            {"namespace": namespace, "task_text": initial_task_str,
             "plan": plan, "success": success, "duration_ms": duration_ms},
            nv_key,
        )
        saved = (r is not None and r.status_code == 200)

    # Recursive-memory: write the task summary + (on fail) a lesson
    # record so the next similar task sees `LEARNED:` hints. Both are
    # fire-and-forget; no impact on user-perceived completion latency.
    final_say = ""
    for h in reversed(history):
        step = h.get("step") or {}
        if str(step.get("action", "")).lower() == "say":
            final_say = str((step.get("text") or
                             (step.get("args") or {}).get("text") or ""))[:300]
            break
    plan_summary = " | ".join(
        f"{str((h.get('step') or {}).get('action', '?'))}" for h in history
    )[:400]

    async def _on_postmortem(pm: dict) -> None:
        # Surface in Cockpit so users see "agent learned from this failure"
        await _emit(on_step, {
            "event": "postmortem",
            "failure_class": pm.get("failure_class"),
            "lesson": pm.get("lesson"),
            "corrected_plan": pm.get("corrected_plan") or [],
            "duration_ms": pm.get("duration_ms"),
        })

    remember_task_end_async(
        agent="computer", namespace=namespace,
        task_text=initial_task_str,
        task_class=task_class, app=app_hint,
        ok=success, n_steps=len(plan), duration_ms=duration_ms,
        plan_summary=plan_summary, final_say=final_say,
        api_key=nv_key,
        history=history,
        original_plan=magistral_plan,
        on_postmortem=_on_postmortem,
    )

    final = {
        "ok": success,
        "n_steps": len(plan),
        "duration_ms": duration_ms,
        "used_cache": plan_used_from_cache,
        "model_calls": model_calls,
        "plan_saved_to_substrate": saved if not plan_used_from_cache else False,
        "history": history,
        "plan": plan,
        "task_class": task_class,
        "lessons_used": len(lessons),
    }
    await _emit(on_step, {"event": "task_complete", **final})
    return final
