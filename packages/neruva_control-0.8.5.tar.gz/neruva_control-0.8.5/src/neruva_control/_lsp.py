"""LSP client for Neruva Code agent.

Spawns a language server per (workspace_root, language) and proxies
agent requests to it. This is the single largest code-quality
upgrade per published benchmarks:

  -27% hallucinated APIs (signatures looked up, not invented)
  -33% mislocalized edits (goto_definition finds the right file)

Architecture:
  - One server process per (workspace_root, lang). Lazy-spawned on
    first request, kept warm in _SERVERS module dict, reaped on
    process exit (subprocess.Popen + atexit).
  - JSON-RPC 2.0 over stdio with the LSP Content-Length framing.
  - One reader thread per server pushes parsed messages onto a
    response queue (for responses) and a diagnostics dict (for
    pushed notifications like publishDiagnostics).
  - Requests are correlated by integer id; we await the matching
    response via a per-id event + slot in the result dict.

Language servers shipped (all auto-installable):
  - python: pyright-langserver (`pip install pyright` bundles node)
  - typescript / javascript: typescript-language-server (`npm i -g`)
  - go: gopls (`go install golang.org/x/tools/gopls@latest`)

For the MVP we ship Python only; other languages are a per-language
add-on. Each server cap is enforced by `available_languages()` so
the agent only sees languages it can actually use.
"""
from __future__ import annotations

import atexit
import json
import shutil
import subprocess
import sys
import threading
import time
import urllib.parse
from pathlib import Path
from queue import Queue, Empty
from typing import Any, Optional


# language -> {cmd: [..], file_exts: [..], language_id: str}
_LANG_SERVERS: dict[str, dict[str, Any]] = {
    "python": {
        "cmd_candidates": [
            ["pyright-langserver", "--stdio"],
            [sys.executable, "-m", "pyright.langserver", "--stdio"],
        ],
        "exts": [".py", ".pyi"],
        "language_id": "python",
    },
    "typescript": {
        "cmd_candidates": [["typescript-language-server", "--stdio"]],
        "exts": [".ts", ".tsx", ".js", ".jsx", ".mjs"],
        "language_id": "typescript",
    },
    "go": {
        "cmd_candidates": [["gopls"]],
        "exts": [".go"],
        "language_id": "go",
    },
    "rust": {
        "cmd_candidates": [["rust-analyzer"]],
        "exts": [".rs"],
        "language_id": "rust",
    },
}


def _resolve_cmd(lang: str) -> Optional[list[str]]:
    spec = _LANG_SERVERS.get(lang)
    if not spec:
        return None
    for cmd in spec["cmd_candidates"]:
        head = cmd[0]
        # Absolute path or sys.executable
        if Path(head).is_absolute() or head == sys.executable:
            return cmd
        if shutil.which(head):
            return cmd
    return None


def available_languages() -> dict[str, bool]:
    return {lang: _resolve_cmd(lang) is not None
            for lang in _LANG_SERVERS}


def _detect_lang(path: str) -> Optional[str]:
    p = Path(path)
    ext = p.suffix.lower()
    for lang, spec in _LANG_SERVERS.items():
        if ext in spec["exts"]:
            return lang
    return None


# ---------------------------------------------------------------------------
# LSP server wrapper
# ---------------------------------------------------------------------------


class _LspServer:
    """One language-server subprocess. Thread-safe."""

    def __init__(self, lang: str, root: str) -> None:
        self.lang = lang
        self.root = str(Path(root).resolve())
        cmd = _resolve_cmd(lang)
        if not cmd:
            raise RuntimeError(f"no language server installed for {lang!r}")
        self.proc = subprocess.Popen(
            cmd,
            stdin=subprocess.PIPE, stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            cwd=self.root,
        )
        # Drain stderr in a background thread so the OS pipe buffer
        # doesn't fill up and block the server. Capture last lines for
        # diagnostics on failure.
        self._stderr_tail: list[str] = []

        def _drain_stderr():
            stream = self.proc.stderr
            if stream is None:
                return
            while True:
                line = stream.readline()
                if not line:
                    return
                try:
                    s = line.decode("utf-8", errors="replace").rstrip("\n")
                except Exception:
                    s = ""
                self._stderr_tail.append(s)
                if len(self._stderr_tail) > 200:
                    self._stderr_tail = self._stderr_tail[-100:]

        threading.Thread(target=_drain_stderr, daemon=True).start()
        self._next_id = 1
        self._lock = threading.Lock()
        self._write_lock = threading.Lock()
        # request_id -> (Event, result_holder)
        self._pending: dict[int, tuple[threading.Event, list]] = {}
        # uri -> [{severity, message, range}]
        self.diagnostics: dict[str, list[dict]] = {}
        self._opened: set[str] = set()
        self._reader = threading.Thread(target=self._read_loop, daemon=True)
        self._reader.start()
        self._initialize()

    # ---- I/O ----

    def _write(self, msg: dict) -> None:
        body = json.dumps(msg).encode("utf-8")
        header = f"Content-Length: {len(body)}\r\n\r\n".encode()
        with self._write_lock:
            try:
                assert self.proc.stdin is not None
                self.proc.stdin.write(header + body)
                self.proc.stdin.flush()
            except Exception:
                pass

    def _read_loop(self) -> None:
        stream = self.proc.stdout
        if stream is None:
            return
        while True:
            try:
                # Headers are CRLF-terminated lines. readline() returns
                # one header at a time, blocking only until the next
                # newline -- unlike read(N) which would wait for N bytes.
                content_length = 0
                while True:
                    line = stream.readline()
                    if not line:
                        return
                    if line in (b"\r\n", b"\n"):
                        break  # end of headers
                    decoded = line.decode("utf-8", errors="replace")
                    if decoded.lower().startswith("content-length:"):
                        try:
                            content_length = int(decoded.split(":", 1)[1].strip())
                        except ValueError:
                            content_length = 0
                if content_length <= 0:
                    continue
                # read(N) on a BufferedReader blocks until N bytes; here
                # that's exactly what we want -- the body is fixed-size.
                body = stream.read(content_length)
                if not body or len(body) < content_length:
                    return
                msg = json.loads(body.decode("utf-8"))
            except Exception:
                return
            # Response?
            if "id" in msg and ("result" in msg or "error" in msg):
                rid = msg["id"]
                slot = self._pending.pop(rid, None)
                if slot is not None:
                    ev, holder = slot
                    holder.append(msg)
                    ev.set()
            # Notification?
            elif msg.get("method") == "textDocument/publishDiagnostics":
                params = msg.get("params") or {}
                uri = params.get("uri", "")
                diags = params.get("diagnostics") or []
                self.diagnostics[uri] = diags

    def _request(self, method: str, params: Any,
                 timeout: float = 8.0) -> dict:
        with self._lock:
            rid = self._next_id
            self._next_id += 1
        ev = threading.Event()
        holder: list[dict] = []
        self._pending[rid] = (ev, holder)
        self._write({"jsonrpc": "2.0", "id": rid,
                     "method": method, "params": params})
        if not ev.wait(timeout):
            self._pending.pop(rid, None)
            return {"error": {"code": -32000, "message": f"timeout {timeout}s"}}
        return holder[0]

    def _notify(self, method: str, params: Any) -> None:
        self._write({"jsonrpc": "2.0", "method": method, "params": params})

    # ---- Lifecycle ----

    def _initialize(self) -> None:
        root_uri = _path_to_uri(self.root)
        params = {
            "processId": None,
            "rootUri": root_uri,
            "workspaceFolders": [{"uri": root_uri, "name": Path(self.root).name}],
            "capabilities": {
                "textDocument": {
                    "synchronization": {"didSave": True, "willSave": False,
                                        "willSaveWaitUntil": False},
                    "definition": {"dynamicRegistration": False,
                                   "linkSupport": True},
                    "references": {"dynamicRegistration": False},
                    "hover": {"contentFormat": ["markdown", "plaintext"]},
                    "publishDiagnostics": {"relatedInformation": False,
                                           "versionSupport": False},
                },
                "workspace": {
                    "symbol": {"dynamicRegistration": False},
                    "workspaceFolders": True,
                },
            },
            "clientInfo": {"name": "neruva-control", "version": "0.6"},
        }
        self._request("initialize", params, timeout=15.0)
        self._notify("initialized", {})

    def close(self) -> None:
        try:
            self._request("shutdown", None, timeout=2.0)
            self._notify("exit", None)
        except Exception:
            pass
        try:
            self.proc.terminate()
        except Exception:
            pass

    # ---- Document sync ----

    def _ensure_open(self, file: str) -> str:
        uri = _path_to_uri(file)
        if uri in self._opened:
            # Send didChange with full text so the server sees latest content
            try:
                text = Path(file).read_text(encoding="utf-8", errors="replace")
            except Exception:
                text = ""
            self._notify("textDocument/didChange", {
                "textDocument": {"uri": uri, "version": 2},
                "contentChanges": [{"text": text}],
            })
            return uri
        try:
            text = Path(file).read_text(encoding="utf-8", errors="replace")
        except Exception:
            text = ""
        self._notify("textDocument/didOpen", {
            "textDocument": {
                "uri": uri, "languageId": _LANG_SERVERS[self.lang]["language_id"],
                "version": 1, "text": text,
            },
        })
        self._opened.add(uri)
        # Pause briefly to let diagnostics come in
        time.sleep(0.3)
        return uri

    # ---- Public LSP methods ----

    def hover(self, file: str, line: int, col: int) -> dict:
        uri = self._ensure_open(file)
        return self._request("textDocument/hover", {
            "textDocument": {"uri": uri},
            "position": {"line": line, "character": col},
        })

    def definition(self, file: str, line: int, col: int) -> dict:
        uri = self._ensure_open(file)
        return self._request("textDocument/definition", {
            "textDocument": {"uri": uri},
            "position": {"line": line, "character": col},
        })

    def references(self, file: str, line: int, col: int,
                   include_declaration: bool = True) -> dict:
        uri = self._ensure_open(file)
        return self._request("textDocument/references", {
            "textDocument": {"uri": uri},
            "position": {"line": line, "character": col},
            "context": {"includeDeclaration": include_declaration},
        })

    def workspace_symbol(self, query: str) -> dict:
        return self._request("workspace/symbol", {"query": query})

    def diagnostics_for(self, file: str) -> list[dict]:
        uri = self._ensure_open(file)
        # Give pyright a beat to process and publish
        time.sleep(0.4)
        return self.diagnostics.get(uri, [])


# Module-level server registry: (lang, root) -> _LspServer
_SERVERS: dict[tuple[str, str], _LspServer] = {}
_SERVERS_LOCK = threading.Lock()


def _get_server(lang: str, root: str) -> _LspServer:
    key = (lang, str(Path(root).resolve()))
    with _SERVERS_LOCK:
        srv = _SERVERS.get(key)
        if srv is not None and srv.proc.poll() is None:
            return srv
        srv = _LspServer(lang, root)
        _SERVERS[key] = srv
        return srv


def _shutdown_all() -> None:
    for srv in list(_SERVERS.values()):
        try: srv.close()
        except Exception: pass
    _SERVERS.clear()


atexit.register(_shutdown_all)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _path_to_uri(path: str) -> str:
    p = Path(path).resolve()
    return p.as_uri()


def _uri_to_path(uri: str) -> str:
    parsed = urllib.parse.urlparse(uri)
    if parsed.scheme != "file":
        return uri
    raw = urllib.parse.unquote(parsed.path)
    # Windows: /C:/foo -> C:/foo
    if sys.platform == "win32" and raw.startswith("/") and len(raw) > 2 and raw[2] == ":":
        raw = raw[1:]
    return raw


def _format_location(loc: dict) -> dict:
    uri = loc.get("uri", "")
    rng = loc.get("range") or loc.get("targetSelectionRange") or {}
    start = rng.get("start", {})
    return {
        "path": _uri_to_path(uri),
        "line": start.get("line", 0) + 1,  # 1-based for humans
        "col": start.get("character", 0) + 1,
    }


def _format_diagnostic(d: dict) -> dict:
    sev_names = {1: "error", 2: "warning", 3: "info", 4: "hint"}
    rng = d.get("range") or {}
    start = rng.get("start", {})
    return {
        "severity": sev_names.get(d.get("severity"), "info"),
        "line": start.get("line", 0) + 1,
        "col": start.get("character", 0) + 1,
        "message": d.get("message", ""),
        "source": d.get("source", ""),
        "code": d.get("code", ""),
    }


# ---------------------------------------------------------------------------
# Public agent-facing entry points
# ---------------------------------------------------------------------------


def lsp_status() -> dict:
    """What's installed?"""
    return {"ok": True, "available": available_languages()}


def _common_check(file: str) -> tuple[Optional[str], Optional[dict]]:
    """Return (lang, error_dict_or_None)."""
    p = Path(file)
    if not p.exists():
        return None, {"ok": False, "error": f"file not found: {file}"}
    lang = _detect_lang(file)
    if not lang:
        return None, {"ok": False,
                      "error": f"no language server for {p.suffix}"}
    if not _resolve_cmd(lang):
        return None, {"ok": False,
                      "error": (f"language server for {lang!r} not installed. "
                                f"Python: pip install pyright. "
                                f"TS: npm i -g typescript-language-server. "
                                f"Go: go install golang.org/x/tools/gopls@latest.")}
    return lang, None


def lsp_diagnostics(file: str, project_root: Optional[str] = None) -> dict:
    lang, err = _common_check(file)
    if err:
        return err
    root = project_root or str(Path(file).resolve().parent)
    srv = _get_server(lang, root)
    diags = srv.diagnostics_for(file)
    formatted = [_format_diagnostic(d) for d in diags]
    n_err = sum(1 for d in formatted if d["severity"] == "error")
    n_warn = sum(1 for d in formatted if d["severity"] == "warning")
    return {"ok": True, "file": str(Path(file).resolve()),
            "n_diagnostics": len(formatted),
            "n_errors": n_err, "n_warnings": n_warn,
            "diagnostics": formatted[:40]}


def lsp_hover(file: str, line: int, col: int,
              project_root: Optional[str] = None) -> dict:
    lang, err = _common_check(file)
    if err:
        return err
    root = project_root or str(Path(file).resolve().parent)
    srv = _get_server(lang, root)
    # LSP is 0-based; agent passes 1-based to match grep / IDE
    resp = srv.hover(file, max(0, line - 1), max(0, col - 1))
    if "error" in resp:
        return {"ok": False, "error": resp["error"].get("message", "lsp error")}
    result = resp.get("result") or {}
    contents = result.get("contents") or {}
    if isinstance(contents, dict):
        text = contents.get("value") or ""
    elif isinstance(contents, list):
        text = "\n".join(
            c.get("value", "") if isinstance(c, dict) else str(c)
            for c in contents
        )
    else:
        text = str(contents)
    return {"ok": True, "text": text[:2000], "n_chars": len(text)}


def lsp_goto_definition(file: str, line: int, col: int,
                        project_root: Optional[str] = None) -> dict:
    lang, err = _common_check(file)
    if err:
        return err
    root = project_root or str(Path(file).resolve().parent)
    srv = _get_server(lang, root)
    resp = srv.definition(file, max(0, line - 1), max(0, col - 1))
    if "error" in resp:
        return {"ok": False, "error": resp["error"].get("message", "lsp error")}
    result = resp.get("result") or []
    if isinstance(result, dict):
        result = [result]
    locs = [_format_location(l) for l in result]
    return {"ok": True, "n_locations": len(locs), "locations": locs[:20]}


def lsp_find_references(file: str, line: int, col: int,
                        project_root: Optional[str] = None) -> dict:
    lang, err = _common_check(file)
    if err:
        return err
    root = project_root or str(Path(file).resolve().parent)
    srv = _get_server(lang, root)
    resp = srv.references(file, max(0, line - 1), max(0, col - 1))
    if "error" in resp:
        return {"ok": False, "error": resp["error"].get("message", "lsp error")}
    result = resp.get("result") or []
    locs = [_format_location(l) for l in result]
    return {"ok": True, "n_references": len(locs), "references": locs[:40]}


def lsp_workspace_symbol(query: str, project_root: str,
                         lang: str = "python") -> dict:
    if not _resolve_cmd(lang):
        return {"ok": False, "error": f"no language server for {lang}"}
    srv = _get_server(lang, project_root)
    resp = srv.workspace_symbol(query)
    if "error" in resp:
        return {"ok": False, "error": resp["error"].get("message", "lsp error")}
    result = resp.get("result") or []
    syms = []
    for s in result[:40]:
        loc = s.get("location") or {}
        syms.append({
            "name": s.get("name", ""),
            "kind": s.get("kind"),
            **_format_location(loc),
        })
    return {"ok": True, "n_symbols": len(syms), "symbols": syms}
