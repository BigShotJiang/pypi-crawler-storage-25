"""Browser sub-agent for both Code and Computer agents.

Backed by Playwright (Python). The action surface mirrors the
Playwright CLI / Browser-Use pattern: instead of returning a raw DOM
or screenshot, the agent gets a compact accessibility snapshot (YAML-
like) and works with element refs. This is the same path Microsoft
took with Playwright CLI -- ~4x fewer tokens than Playwright MCP.

Lazy-initialized: the first ``browser_open`` boots Chromium; closes
on session end or explicit ``browser_close``. Single shared instance
per daemon (keeps state across multiple browser_* calls).
"""
from __future__ import annotations

import asyncio
import threading
from typing import Any, Optional


_LOCK = threading.Lock()
_STATE: dict[str, Any] = {"loop": None, "browser": None, "context": None,
                          "page": None, "started": False}


def _ensure_loop() -> asyncio.AbstractEventLoop:
    """Run Playwright's async API on a dedicated background loop. The
    agent calls execute synchronously from any thread."""
    if _STATE.get("loop") and not _STATE["loop"].is_closed():
        return _STATE["loop"]
    loop = asyncio.new_event_loop()
    _STATE["loop"] = loop

    def _runner():
        asyncio.set_event_loop(loop)
        loop.run_forever()

    t = threading.Thread(target=_runner, daemon=True)
    t.start()
    return loop


def _run(coro):
    loop = _ensure_loop()
    fut = asyncio.run_coroutine_threadsafe(coro, loop)
    return fut.result(timeout=120)


async def _start_browser(headless: bool = False):
    if _STATE.get("browser") is not None:
        return
    try:
        from playwright.async_api import async_playwright
    except ImportError as e:
        raise RuntimeError(
            "playwright not installed. Run: pip install playwright "
            "&& playwright install chromium"
        ) from e
    pw = await async_playwright().start()
    _STATE["_pw"] = pw
    browser = await pw.chromium.launch(headless=headless)
    ctx = await browser.new_context(
        viewport={"width": 1280, "height": 800},
        user_agent="Mozilla/5.0 neruva-control browser sub-agent",
    )
    page = await ctx.new_page()
    _STATE["browser"] = browser
    _STATE["context"] = ctx
    _STATE["page"] = page
    _STATE["started"] = True


async def _close_browser():
    page = _STATE.get("page")
    ctx = _STATE.get("context")
    browser = _STATE.get("browser")
    pw = _STATE.get("_pw")
    try:
        if page:
            await page.close()
        if ctx:
            await ctx.close()
        if browser:
            await browser.close()
        if pw:
            await pw.stop()
    except Exception:
        pass
    _STATE["page"] = None
    _STATE["context"] = None
    _STATE["browser"] = None
    _STATE["_pw"] = None
    _STATE["started"] = False


def focus_browser_window() -> bool:
    """Bring the Playwright Chromium window to the OS foreground so
    Holo3's screenshots capture it AND raw click(x,y) actions land on
    it. Without this, clicks land on whatever window was last focused
    (Dexpot, the user's real Chrome, etc).

    Win32 implementation: enumerate windows by title, ShowWindow +
    SetForegroundWindow + BringWindowToTop. Returns True if a window
    was focused. No-op + False on non-Windows or if browser isn't open.
    """
    if not _STATE.get("started"):
        return False
    import sys as _sys
    if _sys.platform != "win32":
        return False
    try:
        import ctypes
        import pygetwindow as gw
    except Exception:
        return False
    try:
        # Playwright Chromium windows are titled "<page_title> - Chromium"
        # (note: Chromium, NOT "Google Chrome"). Filter on that so we
        # don't accidentally grab the user's real Chrome.
        target = None
        for w in gw.getAllWindows():
            t = (w.title or "")
            if " - Chromium" in t or t.endswith("Chromium"):
                target = w
                break
        if not target:
            return False
        hwnd = target._hWnd
        user32 = ctypes.windll.user32
        kernel32 = ctypes.windll.kernel32
        SW_RESTORE = 9
        user32.ShowWindow(hwnd, SW_RESTORE)
        # The AttachThreadInput dance is required because Windows blocks
        # background processes from stealing focus by default. Attach to
        # the foreground thread, do the bring-to-top, then detach.
        try:
            cur_thread = kernel32.GetCurrentThreadId()
            fg_hwnd = user32.GetForegroundWindow()
            fg_thread = user32.GetWindowThreadProcessId(fg_hwnd, None)
            if cur_thread != fg_thread:
                user32.AttachThreadInput(fg_thread, cur_thread, True)
                user32.BringWindowToTop(hwnd)
                user32.SetForegroundWindow(hwnd)
                user32.AttachThreadInput(fg_thread, cur_thread, False)
            else:
                user32.SetForegroundWindow(hwnd)
        except Exception:
            user32.SetForegroundWindow(hwnd)
        return True
    except Exception:
        return False


def browser_available() -> tuple[bool, str]:
    try:
        import playwright  # noqa: F401
        return True, "playwright"
    except ImportError:
        return False, ("playwright not installed (pip install playwright "
                       "&& playwright install chromium)")


def browser_action(verb: str, args: dict) -> dict:
    """Single entry point dispatched on ``verb``:
      open ({url, headless?})
      navigate ({url})
      snapshot ({})                 -- accessibility tree summary
      click ({selector | text})
      fill ({selector, text})
      type ({selector, text})       -- alias for fill
      press ({key})                 -- e.g. Enter, Escape
      screenshot ({path?})          -- saves to path or returns base64
      wait_for ({selector | text, timeout_ms?})
      content ({selector?})         -- innerText (or whole body)
      close ({})
    """
    avail, reason = browser_available()
    if not avail:
        return {"ok": False, "error": reason}
    verb = (verb or "").lower()
    try:
        if verb == "open":
            url = str(args.get("url", "")).strip()
            headless = bool(args.get("headless", False))
            with _LOCK:
                _run(_start_browser(headless=headless))
                if url:
                    _run(_STATE["page"].goto(url, wait_until="domcontentloaded"))
            # Bring Chromium to foreground so raw click(x,y) actions
            # from Holo3 land on it instead of Dexpot / user's Chrome.
            focused = focus_browser_window()
            return {"ok": True, "url": url or "(no url)", "ready": True,
                    "focused": focused}
        if not _STATE.get("started"):
            return {"ok": False, "error": "browser not open. Call browser_open first."}
        page = _STATE["page"]
        if verb == "navigate":
            url = str(args.get("url", "")).strip()
            if not url:
                # No url + page is already open -> treat as a snapshot
                # of the current page (no-op success). This stops the
                # agent from giving up when Holo3 calls a redundant
                # navigate after open. Common failure mode pre-0.7.8.
                cur_url = page.url
                cur_title = _run(page.title())
                return {"ok": True, "url": cur_url, "title": cur_title,
                        "note": "no url given; page already loaded -- "
                                "use browser({verb:'content'}) to read it"}
            _run(page.goto(url, wait_until="domcontentloaded"))
            return {"ok": True, "url": url, "title": _run(page.title())}
        if verb == "snapshot":
            # Accessibility tree -- compact representation
            tree = _run(page.accessibility.snapshot()) or {}

            def _walk(node: dict, depth: int = 0, out: Optional[list] = None,
                      max_n: int = 120) -> list:
                if out is None:
                    out = []
                if len(out) >= max_n:
                    return out
                name = (node.get("name") or "").strip()
                role = node.get("role", "")
                if role and (name or role in ("link", "button", "textbox",
                                              "combobox", "checkbox",
                                              "menuitem", "tab")):
                    out.append({
                        "role": role,
                        "name": name[:80],
                        "depth": depth,
                    })
                for child in (node.get("children") or []):
                    _walk(child, depth + 1, out, max_n)
                return out
            elements = _walk(tree)
            title = _run(page.title())
            url = page.url
            return {"ok": True, "url": url, "title": title,
                    "n_elements": len(elements), "elements": elements}
        if verb == "click":
            selector = args.get("selector")
            text = args.get("text")
            if selector:
                _run(page.click(selector, timeout=8000))
                return {"ok": True, "clicked": str(selector)}
            if text:
                _run(page.get_by_text(str(text), exact=False).first.click(timeout=8000))
                return {"ok": True, "clicked_text": str(text)}
            # No selector + no text -- give the model a useful hint
            # instead of a dead-end. Snapshot the page's interactive
            # elements so the next turn can pick one. Common after a
            # navigate where Holo3 forgets which element to click.
            try:
                tree = _run(page.accessibility.snapshot()) or {}
                cands: list[str] = []
                def _walk(n: dict) -> None:
                    role = n.get("role", "")
                    name = (n.get("name") or "").strip()
                    if role in ("link", "button") and name and len(cands) < 8:
                        cands.append(f"{role}: {name[:60]}")
                    for c in n.get("children") or []:
                        _walk(c)
                _walk(tree)
                hint = (" Pick one via browser({verb:'click',args:"
                        "{text:'<exact label>'}}). Candidates on page: "
                        + (" | ".join(cands) if cands else "(none found)"))
            except Exception:
                hint = (" Call browser({verb:'snapshot'}) first to see "
                        "selectors / clickable elements.")
            return {"ok": False, "error":
                    "browser click needs args.selector or args.text." + hint}
        if verb in ("fill", "type"):
            selector = str(args.get("selector", ""))
            text = str(args.get("text", ""))
            if not selector:
                # Same hint pattern as click -- show the page's input
                # fields so the model can pick one next turn.
                try:
                    tree = _run(page.accessibility.snapshot()) or {}
                    cands: list[str] = []
                    def _walk(n: dict) -> None:
                        role = n.get("role", "")
                        name = (n.get("name") or "").strip()
                        if role in ("textbox", "combobox", "searchbox") and len(cands) < 6:
                            cands.append(f"{role}: {name[:60] or '(unnamed)'}")
                        for c in n.get("children") or []:
                            _walk(c)
                    _walk(tree)
                    hint = (" Input fields on page: "
                            + (" | ".join(cands) if cands else "(none found)"))
                except Exception:
                    hint = (" Call browser({verb:'snapshot'}) to find "
                            "input selectors.")
                return {"ok": False, "error":
                        "browser fill/type needs args.selector + args.text."
                        + hint}
            _run(page.fill(selector, text, timeout=8000))
            return {"ok": True, "filled": selector}
        if verb == "press":
            key = str(args.get("key", "")).strip()
            if not key:
                return {"ok": False, "error": "key required"}
            _run(page.keyboard.press(key))
            return {"ok": True, "pressed": key}
        if verb == "screenshot":
            path = args.get("path")
            if path:
                _run(page.screenshot(path=str(path), full_page=False))
                return {"ok": True, "path": str(path)}
            import base64
            png = _run(page.screenshot(full_page=False))
            return {"ok": True, "png_b64": base64.b64encode(png).decode()[:200_000]}
        if verb == "wait_for":
            sel = args.get("selector")
            txt = args.get("text")
            ms = args.get("ms")
            timeout = int(args.get("timeout_ms", 8000))
            if sel:
                _run(page.wait_for_selector(str(sel), timeout=timeout))
                return {"ok": True, "waited_for": str(sel)}
            if txt:
                _run(page.get_by_text(str(txt), exact=False).first.wait_for(timeout=timeout))
                return {"ok": True, "waited_for_text": str(txt)}
            if ms is not None:
                # Magistral often writes wait_for({ms:N}) for a plain
                # time-based pause. Accept it (cap at 30s for safety)
                # rather than failing -- the agent meant `wait`.
                try:
                    sleep_s = max(0.0, min(float(ms) / 1000.0, 30.0))
                except Exception:
                    sleep_s = 1.0
                import time as _t
                _t.sleep(sleep_s)
                return {"ok": True, "waited_ms": int(sleep_s * 1000)}
            return {"ok": False, "error":
                    "wait_for needs args.selector, args.text, or args.ms"}
        if verb == "content":
            sel = args.get("selector")
            if sel:
                text = _run(page.locator(str(sel)).inner_text(timeout=4000))
            else:
                text = _run(page.evaluate("() => document.body.innerText"))
            text = str(text or "")
            return {"ok": True, "n_chars": len(text), "text": text[:6000]}
        if verb == "close":
            with _LOCK:
                _run(_close_browser())
            return {"ok": True}
        return {"ok": False, "error": f"unknown browser verb: {verb!r}"}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}
