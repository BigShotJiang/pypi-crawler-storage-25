"""FastAPI daemon -- the localhost:7331 server.

Endpoints (see C:/cortex/sandbox/neruva_cockpit/COCKPIT_V1.md):
  GET  /v1/health                   -- unauthed; browser daemon-detect
  GET  /v1/auth/check               -- validate token
  GET  /v1/sessions                 -- list active sessions
  POST /v1/sessions                 -- spawn new session
  WS   /v1/sessions/{sid}           -- bidirectional stream
  POST /v1/sessions/{sid}/input     -- REST fallback for input
  POST /v1/sessions/{sid}/stop      -- terminate session
  GET  /v1/projects                 -- list known project namespaces

Auth: ``Authorization: Bearer <token>`` on every endpoint except /v1/health.
Bind: 127.0.0.1 only (loopback) -- never expose this port to the network.
CORS: allows app.neruva.io + localhost (dev). Browsers in other origins
will be blocked.
"""
from __future__ import annotations

import asyncio
from typing import Optional

from fastapi import (
    Depends,
    FastAPI,
    Header,
    HTTPException,
    WebSocket,
    WebSocketDisconnect,
    status,
)
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

import os

from . import __version__
from ._config import config_dir, load_token, neruva_api_key
from ._sessions import SessionManager
from . import _projects
from . import _events


app = FastAPI(
    title="Neruva Control",
    version=__version__,
    description=(
        "Local controller daemon for Neruva Cockpit. Loopback-only "
        "(127.0.0.1:7331). Spawns and tails Claude Code sessions, "
        "streams them to your browser at app.neruva.io."
    ),
)

# CORS -- only allow the official Cockpit origin + localhost for dev.
# We do NOT use "*" because the daemon holds an auth token; tightly
# scoped origins are the layered defense behind Bearer auth.
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "https://app.neruva.io",
        "https://neruva.io",
        "http://localhost:3000",
        "http://127.0.0.1:3000",
    ],
    allow_credentials=False,  # token is in header, not cookies
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["Authorization", "Content-Type"],
)


_MGR = SessionManager()


def _expected_token() -> Optional[str]:
    try:
        return load_token()
    except FileNotFoundError:
        return None


def require_token(
    authorization: Optional[str] = Header(default=None),
) -> str:
    """FastAPI dependency: validates Authorization: Bearer <token>."""
    expected = _expected_token()
    if not expected:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="daemon not installed (no token); run neruva-control-install",
        )
    if not authorization or not authorization.lower().startswith("bearer "):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="missing Authorization: Bearer <token>",
        )
    presented = authorization[7:].strip()
    if presented != expected:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="invalid token",
        )
    return presented


# -- Public (no token) ----------------------------------------------------

@app.get("/v1/health")
def health() -> dict:
    """Browser daemon-detect endpoint. Intentionally unauthed so the
    browser can tell "is the daemon installed and running"."""
    has_token = _expected_token() is not None
    return {
        "ok": True,
        "service": "neruva-control",
        "version": __version__,
        "installed": has_token,
    }


# -- Authed ---------------------------------------------------------------

@app.get("/v1/auth/check")
def auth_check(_token: str = Depends(require_token)) -> dict:
    return {
        "ok": True,
        "neruva_api_key_set": neruva_api_key() is not None,
    }


class ApiKeyBody(BaseModel):
    api_key: str


@app.post("/v1/config/api_key")
def set_api_key(body: ApiKeyBody, _token: str = Depends(require_token)) -> dict:
    """Browser pushes the user's Neruva API key into the daemon so
    SessionRecorder can auto-record events. Stored at ~/.config/neruva/api.key
    (chmod 600 on Unix). Pick up on next session spawn."""
    key = body.api_key.strip()
    if not key.startswith("nv_") or len(key) < 12:
        raise HTTPException(status_code=400, detail="invalid api key shape")
    p = config_dir() / "api.key"
    p.write_text(key, encoding="utf-8")
    import os
    if os.name == "posix":
        os.chmod(p, 0o600)
    _events.publish("api_key.set")
    return {"ok": True}


@app.get("/v1/sessions")
def list_sessions(_token: str = Depends(require_token)) -> dict:
    return {"sessions": [s.__dict__ for s in _MGR.list()]}


class SpawnBody(BaseModel):
    project: Optional[str] = None       # legacy: namespace name
    project_id: Optional[str] = None    # preferred: Project id
    prompt: Optional[str] = None
    model: Optional[str] = None
    # agent_type: "code" (default, Neruva Code) | "computer" (Neruva
    # Computer GUI loop) | "claude_code_legacy" (back-compat only).
    agent_type: Optional[str] = None
    initial_task: Optional[str] = None  # required when agent_type="computer"
    max_steps: Optional[int] = None     # computer-agent only; default 12


@app.post("/v1/sessions")
async def spawn_session(body: SpawnBody, _token: str = Depends(require_token)) -> dict:
    # Resolve project: prefer project_id, then project name, then default
    proj = None
    if body.project_id:
        proj = _projects.get(body.project_id)
        if not proj:
            raise HTTPException(status_code=404, detail="unknown project_id")
    elif body.project:
        proj = _projects.get_by_name(body.project)
        if not proj:
            # Auto-create a project with this name (back-compat with old caller)
            proj = _projects.create(body.project)
    else:
        proj = _projects.get_or_create_default()
    _projects.touch(proj.id)
    agent_type = (body.agent_type or "code").lower()
    try:
        if agent_type == "computer":
            if not body.initial_task or not body.initial_task.strip():
                raise HTTPException(status_code=400,
                                    detail="initial_task required for computer agent")
            meta = await _MGR.spawn_computer_agent(
                project=proj.namespace,
                initial_task=body.initial_task,
                project_id=proj.id,
                max_steps=int(body.max_steps or 12),
            )
        elif agent_type == "code":
            # Neruva Code: the default code agent. Older subprocess path
            # is available as agent_type="claude_code_legacy" for back-compat.
            if not body.initial_task or not body.initial_task.strip():
                raise HTTPException(status_code=400,
                                    detail="initial_task required for code agent")
            meta = await _MGR.spawn_code_agent(
                project=proj.namespace,
                initial_task=body.initial_task,
                project_id=proj.id,
                cwd=proj.path,
                max_steps=int(body.max_steps or 20),
            )
        elif agent_type == "claude_code_legacy":
            meta = await _MGR.spawn(
                project=proj.namespace,
                prompt=body.prompt,
                model=body.model,
                project_id=proj.id,
                cwd=proj.path,
            )
        else:
            raise HTTPException(status_code=400,
                                detail=f"unknown agent_type: {agent_type!r}")
    except RuntimeError as e:
        raise HTTPException(status_code=400, detail=str(e))
    _events.publish("session.created", session_id=meta.id,
                    project_id=meta.project_id, agent_type=meta.agent_type)
    return meta.__dict__


# -- Projects -------------------------------------------------------------

@app.get("/v1/projects")
def list_projects(_token: str = Depends(require_token)) -> dict:
    return {"projects": [
        {**p.__dict__, "namespace": p.namespace}
        for p in _projects.load_all()
    ]}


class CreateProjectBody(BaseModel):
    name: str
    path: Optional[str] = None


@app.post("/v1/projects")
def create_project(body: CreateProjectBody, _token: str = Depends(require_token)) -> dict:
    try:
        p = _projects.create(body.name.strip(), body.path)
    except ValueError as e:
        raise HTTPException(status_code=409, detail=str(e))
    _events.publish("project.created", project_id=p.id)
    return {**p.__dict__, "namespace": p.namespace}


@app.delete("/v1/projects/{project_id}")
def delete_project(project_id: str, _token: str = Depends(require_token)) -> dict:
    ok = _projects.delete(project_id)
    if not ok:
        raise HTTPException(status_code=404, detail="unknown project")
    _events.publish("project.deleted", project_id=project_id)
    return {"ok": True}


@app.get("/v1/projects/{project_id}")
def get_project(project_id: str, _token: str = Depends(require_token)) -> dict:
    p = _projects.get(project_id)
    if not p:
        raise HTTPException(status_code=404, detail="unknown project")
    return {**p.__dict__, "namespace": p.namespace}


def _safe_join(root: str, rel: str) -> str:
    """Join a relative path under a root, refusing escape attempts."""
    import os.path as op
    base = op.realpath(root)
    target = op.realpath(op.join(base, rel))
    # Strict containment check (root + sep prefix), allow exact root too
    if target != base and not target.startswith(base + os.sep):
        raise HTTPException(status_code=403, detail="path escapes project root")
    return target


_HIDDEN_DIRS = {".git", "node_modules", "__pycache__", ".venv", "venv", "dist", "build", ".next", ".turbo", ".cache"}


@app.get("/v1/projects/{project_id}/files")
def list_files(
    project_id: str,
    path: str = "",
    _token: str = Depends(require_token),
) -> dict:
    """List directory entries under the project's working dir. Hides
    common noise (.git/, node_modules/, etc.) so the UI tree stays clean."""
    p = _projects.get(project_id)
    if not p:
        raise HTTPException(status_code=404, detail="unknown project")
    target = _safe_join(p.path, path or "")
    if not os.path.isdir(target):
        raise HTTPException(status_code=400, detail="not a directory")
    entries: list[dict] = []
    try:
        for name in sorted(os.listdir(target), key=lambda x: (not os.path.isdir(os.path.join(target, x)), x.lower())):
            if name.startswith(".") and name != ".claude" and name != ".env.example":
                continue
            full = os.path.join(target, name)
            is_dir = os.path.isdir(full)
            if is_dir and name in _HIDDEN_DIRS:
                continue
            try:
                size = os.path.getsize(full) if not is_dir else 0
            except OSError:
                size = 0
            entries.append({
                "name": name,
                "is_dir": is_dir,
                "size": size,
            })
    except PermissionError:
        raise HTTPException(status_code=403, detail="permission denied")
    return {"path": path, "entries": entries}


@app.get("/v1/projects/{project_id}/file")
def read_file(
    project_id: str,
    path: str,
    _token: str = Depends(require_token),
) -> dict:
    """Read a small file's content for preview. Cap at 256KB to avoid
    streaming gigabytes back to the browser."""
    p = _projects.get(project_id)
    if not p:
        raise HTTPException(status_code=404, detail="unknown project")
    target = _safe_join(p.path, path)
    if not os.path.isfile(target):
        raise HTTPException(status_code=400, detail="not a file")
    size = os.path.getsize(target)
    if size > 256 * 1024:
        raise HTTPException(status_code=413, detail="file too large for preview (256KB max)")
    try:
        with open(target, "rb") as f:
            raw = f.read()
        # Try UTF-8; if it fails, return as base64 with a flag
        try:
            text = raw.decode("utf-8")
            return {"path": path, "size": size, "text": text}
        except UnicodeDecodeError:
            import base64
            return {"path": path, "size": size, "binary_b64": base64.b64encode(raw).decode("ascii")}
    except OSError as e:
        raise HTTPException(status_code=500, detail=str(e))


class PinBody(BaseModel):
    path: str  # relative to project path


@app.post("/v1/projects/{project_id}/pin")
def pin_file(project_id: str, body: PinBody, _token: str = Depends(require_token)) -> dict:
    p = _projects.pin_file(project_id, body.path)
    if not p:
        raise HTTPException(status_code=404, detail="unknown project")
    _events.publish("project.changed", project_id=project_id, change="pin")
    return {**p.__dict__, "namespace": p.namespace}


@app.post("/v1/projects/{project_id}/unpin")
def unpin_file(project_id: str, body: PinBody, _token: str = Depends(require_token)) -> dict:
    p = _projects.unpin_file(project_id, body.path)
    if not p:
        raise HTTPException(status_code=404, detail="unknown project")
    _events.publish("project.changed", project_id=project_id, change="unpin")
    return {**p.__dict__, "namespace": p.namespace}


# -- Phone pairing (WebRTC) ----------------------------------------------

@app.post("/v1/pair/start")
async def pair_start(_token: str = Depends(require_token)) -> dict:
    """Allocate a pairing code and start the WebRTC handshake background.
    Returns {code, ttl_secs} immediately. Phone joins via
    https://app.neruva.io/cockpit?pair=<code>."""
    from . import _pair
    try:
        return await _pair.start_pairing(daemon_loopback_port=7331)
    except RuntimeError as e:
        raise HTTPException(status_code=503, detail=str(e))


@app.get("/v1/pair/list")
def pair_list(_token: str = Depends(require_token)) -> dict:
    from . import _pair
    return {"pairings": _pair.list_pairings()}


@app.post("/v1/pair/stop/{code}")
async def pair_stop(code: str, _token: str = Depends(require_token)) -> dict:
    from . import _pair
    ok = await _pair.stop_pairing(code)
    if not ok:
        raise HTTPException(status_code=404, detail="unknown code")
    return {"ok": True}


@app.get("/v1/pair/devices")
def pair_devices(_token: str = Depends(require_token)) -> dict:
    """Trusted devices that can rejoin without scanning a fresh code."""
    from . import _trust
    from ._config import load_or_create_daemon_id
    return {"daemon_id": load_or_create_daemon_id(),
            "devices": _trust.list_devices()}


@app.delete("/v1/pair/devices/{device_id}")
def pair_revoke(device_id: str, _token: str = Depends(require_token)) -> dict:
    from . import _trust
    ok = _trust.revoke_device(device_id)
    if not ok:
        raise HTTPException(status_code=404, detail="unknown device")
    _events.publish("device.revoked", device_id=device_id)
    return {"ok": True}


@app.on_event("startup")
async def _start_presence() -> None:
    """Maintain the long-lived signaling presence WS so paired phones
    can rejoin without scanning a fresh QR code each time."""
    from . import _pair
    _pair.ensure_presence(daemon_loopback_port=7331)


class WriteFileBody(BaseModel):
    path: str        # relative to project root
    content: str
    overwrite: bool = False  # default no-clobber


@app.post("/v1/projects/{project_id}/write_file")
def write_project_file(
    project_id: str,
    body: WriteFileBody,
    _token: str = Depends(require_token),
) -> dict:
    """Write text to a file inside the project root. Path-traversal
    protected via _safe_join. By default refuses to overwrite existing
    files (caller must pass overwrite=True). Used by templates to drop
    CLAUDE.md / skills / etc. without spinning up a Claude Code session."""
    p = _projects.get(project_id)
    if not p:
        raise HTTPException(status_code=404, detail="unknown project")
    target = _safe_join(p.path, body.path)
    if os.path.exists(target) and not body.overwrite:
        raise HTTPException(
            status_code=409,
            detail=f"file exists at {body.path}; pass overwrite=true to clobber",
        )
    parent = os.path.dirname(target)
    if parent:
        os.makedirs(parent, exist_ok=True)
    try:
        with open(target, "w", encoding="utf-8", newline="") as f:
            f.write(body.content)
    except OSError as e:
        raise HTTPException(status_code=500, detail=str(e))
    return {"ok": True, "path": body.path, "bytes": len(body.content.encode("utf-8"))}


class InputBody(BaseModel):
    text: str


@app.post("/v1/sessions/{sid}/input")
async def post_input(sid: str, body: InputBody, _token: str = Depends(require_token)) -> dict:
    try:
        await _MGR.send_input(sid, body.text)
    except KeyError:
        raise HTTPException(status_code=404, detail="unknown session")
    except RuntimeError as e:
        raise HTTPException(status_code=409, detail=str(e))
    return {"ok": True}


@app.post("/v1/sessions/{sid}/stop")
async def stop_session(sid: str, _token: str = Depends(require_token)) -> dict:
    await _MGR.stop(sid)
    _events.publish("session.stopped", session_id=sid)
    return {"ok": True}


@app.post("/v1/sessions/{sid}/resume")
async def resume_session(sid: str, _token: str = Depends(require_token)) -> dict:
    """Spawn a fresh Claude Code subprocess that --resume's the prior
    session by its claude_session_id. Returns the NEW Cockpit session
    meta. The old session entry stays around as historical record."""
    src = _MGR.get(sid)
    if not src:
        raise HTTPException(status_code=404, detail="unknown session")
    if not src.claude_session_id:
        raise HTTPException(
            status_code=400,
            detail="no claude_session_id captured for this session (was probably never initialized)",
        )
    proj = _projects.get(src.project_id) if src.project_id else None
    if not proj:
        proj = _projects.get_or_create_default()
    _projects.touch(proj.id)
    try:
        meta = await _MGR.spawn(
            project=proj.namespace,
            project_id=proj.id,
            cwd=proj.path,
            model=src.model,
            resume_claude_session_id=src.claude_session_id,
        )
    except RuntimeError as e:
        raise HTTPException(status_code=400, detail=str(e))
    _events.publish("session.created", session_id=meta.id, project_id=meta.project_id, resumed_from=sid)
    return meta.__dict__




# -- WebSocket ------------------------------------------------------------

@app.websocket("/v1/sessions/{sid}")
async def session_ws(websocket: WebSocket, sid: str) -> None:
    """Bidirectional stream for one session.

    Auth: WS protocol can't easily send Authorization headers from
    browsers, so we accept the token via the first JSON frame the
    client sends: {"type": "auth", "token": "..."}. After that, the
    server pushes session events; client can push {"type": "input",
    "text": "..."} to send to subprocess stdin.
    """
    await websocket.accept()
    try:
        first = await asyncio.wait_for(websocket.receive_json(), timeout=10)
    except (asyncio.TimeoutError, Exception):
        await websocket.close(code=4400, reason="auth handshake timeout")
        return
    expected = _expected_token()
    if not expected or first.get("type") != "auth" or first.get("token") != expected:
        await websocket.close(code=4401, reason="auth failed")
        return
    if not _MGR.get(sid):
        await websocket.close(code=4404, reason="unknown session")
        return

    # Send any buffered history so the UI catches up
    for ev in await _MGR.history(sid):
        await websocket.send_json(ev)

    queue = _MGR.subscribe(sid)
    if queue is None:
        await websocket.close(code=4404, reason="session vanished")
        return

    async def pump_to_client() -> None:
        try:
            while True:
                ev = await queue.get()
                await websocket.send_json(ev)
        except WebSocketDisconnect:
            return
        except Exception:
            return

    async def pump_from_client() -> None:
        try:
            while True:
                msg = await websocket.receive_json()
                if msg.get("type") == "input":
                    text = str(msg.get("text") or "")
                    if text:
                        try:
                            await _MGR.send_input(sid, text)
                        except Exception as e:
                            await websocket.send_json({"type": "input.error", "detail": str(e)})
                elif msg.get("type") == "stop":
                    await _MGR.stop(sid)
        except WebSocketDisconnect:
            return
        except Exception:
            return

    out = asyncio.create_task(pump_to_client())
    inp = asyncio.create_task(pump_from_client())
    try:
        done, pending = await asyncio.wait({out, inp}, return_when=asyncio.FIRST_COMPLETED)
        for t in pending:
            t.cancel()
    finally:
        _MGR.unsubscribe(sid, queue)
        try:
            await websocket.close()
        except Exception:
            pass


@app.websocket("/v1/events")
async def events_ws(websocket: WebSocket) -> None:
    """Daemon-wide event broadcast for cross-device live sync.

    Auth: same handshake as /v1/sessions/{sid} -- first frame must be
    {"type": "auth", "token": "..."}. After that the server pushes
    {"kind": "session.created", ...} etc. for every state mutation.

    Browser uses this to update React state in-place without polling --
    mobile spawns a session, desktop sees it appear instantly.
    """
    await websocket.accept()
    try:
        first = await asyncio.wait_for(websocket.receive_json(), timeout=10)
    except (asyncio.TimeoutError, Exception):
        await websocket.close(code=4400, reason="auth handshake timeout")
        return
    expected = _expected_token()
    if not expected or first.get("type") != "auth" or first.get("token") != expected:
        await websocket.close(code=4401, reason="auth failed")
        return
    queue = _events.subscribe()
    try:
        await websocket.send_json({"kind": "events.ready", "ts_ms": 0})
        async def pump_to_client() -> None:
            try:
                while True:
                    ev = await queue.get()
                    await websocket.send_json(ev)
            except WebSocketDisconnect:
                return
            except Exception:
                return
        async def keepalive_drain() -> None:
            # Drain any client pings so the WS stays open; we don't act on them.
            try:
                while True:
                    await websocket.receive_text()
            except WebSocketDisconnect:
                return
            except Exception:
                return
        out = asyncio.create_task(pump_to_client())
        inp = asyncio.create_task(keepalive_drain())
        done, pending = await asyncio.wait({out, inp}, return_when=asyncio.FIRST_COMPLETED)
        for t in pending:
            t.cancel()
    finally:
        _events.unsubscribe(queue)
        try: await websocket.close()
        except Exception: pass


def serve(host: str = "127.0.0.1", port: int = 7331) -> None:
    """Programmatic entry-point. CLI calls this. Loopback-only by default --
    do not change the host without understanding that the auth token is
    the only thing standing between an attacker on your LAN and arbitrary
    Claude Code spawning + stdin injection."""
    import uvicorn
    uvicorn.run(app, host=host, port=port, log_level="info")
