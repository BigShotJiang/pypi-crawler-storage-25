"""Projects -- the unit of organization in Cockpit.

A Project bundles:
  - A name (also the records substrate namespace)
  - A working directory on disk (the cwd for spawned sessions)
  - A list of sessions (active + recent)
  - A list of "pinned" files the user has attached to context

Persisted at ``~/.config/neruva/projects.json``. Single-user single-
machine for v1; multi-machine sync is post-v1 (decision 23238 #11).

Default project: created lazily on first session spawn if none exist.
"""
from __future__ import annotations

import json
import os
import re
import secrets
import threading
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Optional

from ._config import config_dir


_LOCK = threading.Lock()


@dataclass
class Project:
    id: str
    name: str
    path: str  # absolute working directory
    created_at_ms: int
    last_active_ms: Optional[int] = None
    pinned_files: list[str] = field(default_factory=list)  # paths relative to project path

    @property
    def namespace(self) -> str:
        """Records-substrate namespace. Slug of name; safe for URLs."""
        s = re.sub(r"[^a-z0-9_-]+", "-", self.name.lower()).strip("-")
        return s or self.id


def _projects_path() -> Path:
    return config_dir() / "projects.json"


def load_all() -> list[Project]:
    p = _projects_path()
    if not p.exists():
        return []
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
        return [Project(**d) for d in data.get("projects", [])]
    except Exception:
        return []


def save_all(projects: list[Project]) -> None:
    p = _projects_path()
    p.write_text(
        json.dumps({"projects": [asdict(pr) for pr in projects]}, indent=2),
        encoding="utf-8",
    )
    if os.name == "posix":
        os.chmod(p, 0o600)


def get(project_id: str) -> Optional[Project]:
    for pr in load_all():
        if pr.id == project_id:
            return pr
    return None


def get_by_name(name: str) -> Optional[Project]:
    for pr in load_all():
        if pr.name == name:
            return pr
    return None


def create(name: str, path: Optional[str] = None) -> Project:
    """Create a new project. Path defaults to ~/.neruva/<name>/ which is
    auto-created. If user passes a real existing dir, we use it as-is."""
    with _LOCK:
        all_p = load_all()
        if any(p.name == name for p in all_p):
            raise ValueError(f"project '{name}' already exists")
        if not path:
            base = Path.home() / ".neruva" / "projects" / re.sub(r"[^a-zA-Z0-9_-]+", "-", name)
            base.mkdir(parents=True, exist_ok=True)
            path = str(base.resolve())
        else:
            p = Path(path).expanduser().resolve()
            if not p.exists():
                p.mkdir(parents=True, exist_ok=True)
            path = str(p)
        proj = Project(
            id="p_" + secrets.token_hex(6),
            name=name,
            path=path,
            created_at_ms=int(time.time() * 1000),
        )
        all_p.append(proj)
        save_all(all_p)
        return proj


def delete(project_id: str) -> bool:
    """Remove project entry (does NOT delete files on disk)."""
    with _LOCK:
        all_p = load_all()
        before = len(all_p)
        all_p = [p for p in all_p if p.id != project_id]
        if len(all_p) == before:
            return False
        save_all(all_p)
        return True


def touch(project_id: str) -> None:
    """Mark project as active (updates last_active_ms)."""
    with _LOCK:
        all_p = load_all()
        for p in all_p:
            if p.id == project_id:
                p.last_active_ms = int(time.time() * 1000)
                save_all(all_p)
                return


def get_or_create_default() -> Project:
    """Return an existing 'default' project or create one. Used when a
    session is spawned without an explicit project."""
    existing = get_by_name("default")
    if existing:
        return existing
    return create("default")


def pin_file(project_id: str, rel_path: str) -> Optional[Project]:
    with _LOCK:
        all_p = load_all()
        for p in all_p:
            if p.id == project_id:
                if rel_path not in p.pinned_files:
                    p.pinned_files.append(rel_path)
                save_all(all_p)
                return p
    return None


def unpin_file(project_id: str, rel_path: str) -> Optional[Project]:
    with _LOCK:
        all_p = load_all()
        for p in all_p:
            if p.id == project_id:
                if rel_path in p.pinned_files:
                    p.pinned_files.remove(rel_path)
                save_all(all_p)
                return p
    return None
