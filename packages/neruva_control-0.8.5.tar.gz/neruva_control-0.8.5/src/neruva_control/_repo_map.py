"""Repo map: cheap "tree-sitter-lite" symbol summary of a project.

Walks the dir, parses .py via stdlib ``ast``, regex-scans other common
languages for top-level symbols. Returns a compact bullet outline the
agent can use to navigate the codebase without reading every file --
the Aider "repo map" pattern, simplified to stdlib only.

Honors .gitignore for skip patterns when present.
"""
from __future__ import annotations

import ast
import os
import re
from pathlib import Path
from typing import Optional


_LANG_BY_EXT: dict[str, str] = {
    ".py": "python",
    ".pyi": "python",
    ".ts": "typescript",
    ".tsx": "typescript",
    ".js": "javascript",
    ".jsx": "javascript",
    ".mjs": "javascript",
    ".go": "go",
    ".rs": "rust",
    ".java": "java",
    ".rb": "ruby",
    ".php": "php",
    ".c": "c",
    ".h": "c",
    ".cpp": "cpp",
    ".cc": "cpp",
    ".hpp": "cpp",
    ".cs": "csharp",
    ".swift": "swift",
    ".kt": "kotlin",
}

_SKIP_DIRS = {
    "__pycache__", "node_modules", ".git", ".venv", "venv", "env",
    "dist", "build", "target", ".next", ".nuxt", "coverage",
    ".pytest_cache", ".mypy_cache", ".ruff_cache", ".tox",
    ".idea", ".vscode", "out",
    # User-home noise -- these are massive and almost never the
    # codebase the agent is being asked about.
    "AppData", "OneDrive", "Downloads", "Pictures", "Music", "Videos",
    "Library", ".cache", ".local", ".npm", ".m2", ".gradle", ".cargo",
    ".rustup", ".pyenv", ".rbenv", ".nvm", "Program Files",
    "Program Files (x86)", "Windows", "$Recycle.Bin",
}

_JS_TS_RE = re.compile(
    r"^(?:export\s+)?(?:default\s+)?"
    r"(?:async\s+)?"
    r"(?:function\s+(\w+)|"
    r"class\s+(\w+)|"
    r"(?:const|let|var)\s+(\w+)\s*=\s*(?:async\s*)?(?:function|\([^)]*\)\s*=>))",
    re.MULTILINE,
)

_GO_RE = re.compile(
    r"^(?:func\s+(?:\([^)]+\)\s+)?(\w+)\s*\(|"
    r"type\s+(\w+)\s+(?:struct|interface)|"
    r"var\s+(\w+)\s+|"
    r"const\s+(\w+)\s*=)",
    re.MULTILINE,
)

_RUST_RE = re.compile(
    r"^(?:pub\s+)?(?:async\s+)?"
    r"(?:fn\s+(\w+)|struct\s+(\w+)|enum\s+(\w+)|trait\s+(\w+)|impl\s+(\w+))",
    re.MULTILINE,
)


def _python_symbols(text: str) -> list[str]:
    out: list[str] = []
    try:
        tree = ast.parse(text)
    except Exception:
        return out
    for node in tree.body:
        if isinstance(node, ast.FunctionDef):
            out.append(f"def {node.name}")
        elif isinstance(node, ast.AsyncFunctionDef):
            out.append(f"async def {node.name}")
        elif isinstance(node, ast.ClassDef):
            methods = [n.name for n in node.body
                       if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))]
            if methods:
                out.append(f"class {node.name}({', '.join(methods[:8])})")
            else:
                out.append(f"class {node.name}")
        elif isinstance(node, ast.Assign):
            for t in node.targets:
                if isinstance(t, ast.Name):
                    out.append(t.id)
    return out


def _regex_symbols(text: str, lang: str) -> list[str]:
    if lang in ("typescript", "javascript"):
        pat = _JS_TS_RE
    elif lang == "go":
        pat = _GO_RE
    elif lang == "rust":
        pat = _RUST_RE
    else:
        return []
    out: list[str] = []
    for m in pat.finditer(text):
        name = next((g for g in m.groups() if g), None)
        if name:
            out.append(name)
    # de-dupe preserving order
    seen: set[str] = set()
    deduped = []
    for n in out:
        if n not in seen:
            seen.add(n)
            deduped.append(n)
    return deduped


def _should_skip_dir(d: str) -> bool:
    return d in _SKIP_DIRS or d.startswith(".")


def _gitignore_patterns(root: Path) -> list[str]:
    gi = root / ".gitignore"
    if not gi.exists():
        return []
    try:
        lines = gi.read_text(encoding="utf-8", errors="replace").splitlines()
    except Exception:
        return []
    return [ln.strip() for ln in lines if ln.strip() and not ln.strip().startswith("#")]


def build_repo_map(root: str, max_files: int = 60,
                   max_bytes_per_file: int = 200_000
                   ) -> tuple[str, dict]:
    """Walk root, return (markdown_summary, stats)."""
    root_path = Path(root).resolve()
    if not root_path.exists() or not root_path.is_dir():
        return f"(repo_map: {root_path} not a directory)", {
            "n_files": 0, "n_symbols": 0, "truncated": False,
        }

    files: list[tuple[Path, str]] = []
    # Hard ceiling on directory entries visited so home-dir-style
    # walks don't stat 100k files. Tuned so a real project (~few
    # thousand entries) still completes; a home dir bails early.
    MAX_DIR_VISITS = 5000
    visited = 0
    for dirpath, dirnames, filenames in os.walk(root_path):
        # Prune skipped dirs in place
        dirnames[:] = [d for d in dirnames if not _should_skip_dir(d)]
        visited += len(filenames)
        if visited > MAX_DIR_VISITS:
            break  # bail hard; we'll show whatever we found
        for fn in filenames:
            p = Path(dirpath) / fn
            ext = p.suffix.lower()
            lang = _LANG_BY_EXT.get(ext)
            if not lang:
                continue
            try:
                if p.stat().st_size > max_bytes_per_file:
                    continue
            except OSError:
                continue
            files.append((p, lang))
            if len(files) > max_files * 4:
                break  # rough early stop; we'll trim below
        if len(files) > max_files * 4:
            break

    # Prefer shorter files (likely more informative) up to max_files
    files.sort(key=lambda pl: pl[0].stat().st_size if pl[0].exists() else 0)
    truncated = len(files) > max_files
    files = files[:max_files]

    sections: list[str] = []
    total_symbols = 0
    for p, lang in files:
        try:
            text = p.read_text(encoding="utf-8", errors="replace")
        except Exception:
            continue
        if lang == "python":
            syms = _python_symbols(text)
        else:
            syms = _regex_symbols(text, lang)
        if not syms:
            continue
        rel = str(p.relative_to(root_path))
        total_symbols += len(syms)
        sym_list = ", ".join(syms[:25])
        if len(syms) > 25:
            sym_list += f", ... (+{len(syms) - 25})"
        sections.append(f"- {rel}: {sym_list}")

    header = (f"REPO MAP for {root_path.name}/ "
              f"({len(files)} files{'+' if truncated else ''}, "
              f"{total_symbols} symbols)")
    summary = header + "\n" + "\n".join(sections) if sections else \
              header + "\n(no recognized source files)"
    return summary, {
        "n_files": len(files),
        "n_symbols": total_symbols,
        "truncated": truncated,
    }
