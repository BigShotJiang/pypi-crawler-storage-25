"""OCR overlay for Neruva Computer.

Reads visible text from the screen + bounding boxes so the agent can
target elements by their on-screen labels even when the accessibility
tree is empty (custom-drawn UIs, games, canvas elements, web pages
without ARIA).

Backend selection (cheapest-first):
  1. pytesseract (if Tesseract binary installed) -- cross-platform
  2. Windows OCR via winrt (Win10+) -- TODO
  3. Stub: returns a friendly "not configured" error pointing at install

The agent never needs to know which backend ran; it gets the same
``{ok, lines, n_lines}`` shape either way.
"""
from __future__ import annotations

import sys
from typing import Optional


def _well_known_tesseract_paths() -> list[str]:
    """Fallback locations Tesseract may have been installed to but
    isn't yet on PATH (e.g. fresh install in a long-lived shell)."""
    if sys.platform == "win32":
        return [
            r"C:\Program Files\Tesseract-OCR\tesseract.exe",
            r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe",
        ]
    if sys.platform == "darwin":
        return [
            "/opt/homebrew/bin/tesseract",
            "/usr/local/bin/tesseract",
        ]
    return ["/usr/bin/tesseract", "/usr/local/bin/tesseract"]


def ocr_available() -> tuple[bool, str]:
    try:
        import pytesseract
        # Probe binary on PATH first
        try:
            pytesseract.get_tesseract_version()
            return True, "pytesseract"
        except Exception:
            pass
        # Try well-known install locations
        import os
        for path in _well_known_tesseract_paths():
            if os.path.exists(path):
                pytesseract.pytesseract.tesseract_cmd = path
                try:
                    pytesseract.get_tesseract_version()
                    return True, f"pytesseract ({path})"
                except Exception:
                    continue
        return False, ("pytesseract is installed but Tesseract binary "
                       "is missing -- re-run `neruva-control-install` "
                       "to auto-install on Windows, or "
                       "https://github.com/UB-Mannheim/tesseract/wiki")
    except ImportError:
        return False, ("pytesseract not installed (pip install "
                       "'neruva-control[agent]')")


def ocr_screen(region: Optional[tuple[int, int, int, int]] = None
               ) -> dict:
    """OCR the current screen (or a sub-region). Returns:
      {ok, n_lines, lines: [{text, bbox: [x,y,w,h], conf}]}
    """
    avail, reason = ocr_available()
    if not avail:
        return {"ok": False, "available": False, "error": reason}
    try:
        import pyautogui
        import pytesseract
        from PIL import Image
    except ImportError as e:
        return {"ok": False, "available": False,
                "error": f"OCR deps missing: {e}"}
    try:
        if region:
            x, y, w, h = region
            img: Image.Image = pyautogui.screenshot(region=(x, y, w, h))
        else:
            img = pyautogui.screenshot()
        # image_to_data returns per-word boxes + conf
        data = pytesseract.image_to_data(
            img, output_type=pytesseract.Output.DICT)
        # Group words by (block, par, line) so we get whole-line text.
        lines_by_key: dict[tuple[int, int, int], list[dict]] = {}
        n = len(data.get("text", []))
        offset_x = region[0] if region else 0
        offset_y = region[1] if region else 0
        for i in range(n):
            txt = (data["text"][i] or "").strip()
            if not txt:
                continue
            try:
                conf = int(data["conf"][i])
            except (TypeError, ValueError):
                conf = -1
            if conf < 40:  # noisy
                continue
            key = (data["block_num"][i], data["par_num"][i], data["line_num"][i])
            entry = {
                "text": txt,
                "x": int(data["left"][i]) + offset_x,
                "y": int(data["top"][i]) + offset_y,
                "w": int(data["width"][i]),
                "h": int(data["height"][i]),
                "conf": conf,
            }
            lines_by_key.setdefault(key, []).append(entry)
        lines = []
        for key, words in lines_by_key.items():
            words.sort(key=lambda w: w["x"])
            text = " ".join(w["text"] for w in words)
            x = min(w["x"] for w in words)
            y = min(w["y"] for w in words)
            x2 = max(w["x"] + w["w"] for w in words)
            y2 = max(w["y"] + w["h"] for w in words)
            avg_conf = sum(w["conf"] for w in words) // max(1, len(words))
            lines.append({
                "text": text[:200],
                "bbox": [x, y, x2 - x, y2 - y],
                "conf": avg_conf,
            })
        # Sort top-to-bottom, left-to-right
        lines.sort(key=lambda l: (l["bbox"][1], l["bbox"][0]))
        return {"ok": True, "available": True,
                "backend": "pytesseract",
                "n_lines": len(lines),
                "lines": lines[:200]}
    except Exception as e:
        return {"ok": False, "available": True,
                "error": f"{type(e).__name__}: {e}"}
