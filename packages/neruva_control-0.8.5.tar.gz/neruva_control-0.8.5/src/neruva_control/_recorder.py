"""Substrate auto-recorder -- ships session events to api.neruva.io.

For each session, the daemon spawns a recorder task that:
  - Maps each Claude Code stream-json event to a typed Records entry
    (kind = "llm_turn" | "tool_call" | "tool_result" | "session_start"
    | "session_result"), with tags = [project, session_id, ...].
  - Buffers entries and flushes every 2s (or when 50 entries pending)
    to ``POST /v1/records/{project}/`` with the user's Api-Key.
  - On HTTP failure, drops the batch (best-effort -- substrate billing
    isn't legal-tender accounting; we never block the user's session
    on a recording failure).

Runs in 'no-record' mode (silent no-op) when NERUVA_API_KEY isn't set,
so the daemon still works for users who haven't linked an account.
"""
from __future__ import annotations

import asyncio
import logging
import time
from typing import Any, Iterable

import httpx

from ._config import neruva_api_base, neruva_api_key


log = logging.getLogger("neruva_control.recorder")

FLUSH_INTERVAL_S = 2.0
FLUSH_BATCH = 50
MAX_TEXT_CHARS = 4000  # cap per-record text to keep payloads sane


def _trim(s: str | None, n: int = MAX_TEXT_CHARS) -> str:
    if not s:
        return ""
    return s if len(s) <= n else s[:n] + "..."


def _classify(ev: dict[str, Any]) -> tuple[str, str, dict[str, Any]] | None:
    """Map one stream-json event to (kind, text, meta) for the substrate.
    Returns None for events we don't record (hooks, status, deltas).
    """
    t = ev.get("type")
    if t == "system":
        sub = ev.get("subtype")
        if sub == "init":
            return "session_start", f"model={ev.get('model','?')} cwd={ev.get('cwd','?')}", {
                "session_id": ev.get("session_id"),
                "model": ev.get("model"),
                "tools": (ev.get("tools") or [])[:30],
            }
        return None  # hook_*, status -- skip
    if t == "user.input":
        return "user_turn", _trim(str(ev.get("text") or "")), {}
    if t == "assistant":
        msg = ev.get("message") or {}
        # Pull text from content blocks
        parts: list[str] = []
        for c in (msg.get("content") or []):
            if isinstance(c, dict) and c.get("type") == "text":
                parts.append(c.get("text") or "")
        text = "".join(parts).strip()
        if not text:
            return None
        return "llm_turn", _trim(text), {
            "model": msg.get("model"),
            "message_id": msg.get("id"),
            "usage": msg.get("usage"),
        }
    if t == "tool_use":
        return "tool_call", _trim(str(ev.get("input") or "")), {
            "tool": ev.get("name"),
            "tool_use_id": ev.get("id"),
        }
    if t == "tool_result":
        c = ev.get("content")
        text = c if isinstance(c, str) else str(c)
        return "tool_result", _trim(text), {
            "tool_use_id": ev.get("tool_use_id"),
            "is_error": bool(ev.get("is_error")),
        }
    if t == "result":
        return "session_result", _trim(str(ev.get("result") or "")), {
            "duration_ms": ev.get("duration_ms"),
            "cost_usd": ev.get("total_cost_usd"),
            "is_error": bool(ev.get("is_error")),
            "num_turns": ev.get("num_turns"),
        }
    if t == "session_summary_synth":
        # Synthetic event posted by SessionManager.stop() right before
        # killing the subprocess. Captures end-of-session metadata so the
        # substrate has one queryable summary per Cockpit session.
        text = (
            f"Session ended ({ev.get('ended_via','?')}). "
            f"{ev.get('event_count', 0)} events over "
            f"{(ev.get('duration_ms') or 0) // 1000}s in project '{ev.get('project','?')}'."
        )
        return "session_summary", text, {
            "session_id": ev.get("session_id"),
            "claude_session_id": ev.get("claude_session_id"),
            "project_id": ev.get("project_id"),
            "duration_ms": ev.get("duration_ms"),
            "event_count": ev.get("event_count"),
            "ended_via": ev.get("ended_via"),
        }
    return None


class SessionRecorder:
    """One per session. Buffers events, flushes periodically. Cheap to
    construct (no I/O). Call ``offer(event)`` from the reader task; call
    ``stop()`` when the session terminates to flush remaining."""

    def __init__(self, project: str, session_id: str) -> None:
        self.project = project
        self.session_id = session_id
        self._buf: list[dict[str, Any]] = []
        self._lock = asyncio.Lock()
        self._stopped = False
        self._task: asyncio.Task | None = None
        self._http: httpx.AsyncClient | None = None

    async def start(self) -> None:
        if not neruva_api_key():
            log.info("recorder: NERUVA_API_KEY not set; sessions won't auto-record")
            return
        self._http = httpx.AsyncClient(timeout=10.0)
        self._task = asyncio.create_task(self._run())

    async def stop(self) -> None:
        self._stopped = True
        if self._task:
            try:
                await asyncio.wait_for(self._task, timeout=5)
            except (asyncio.TimeoutError, asyncio.CancelledError):
                self._task.cancel()
        await self.flush()
        if self._http:
            await self._http.aclose()
            self._http = None

    def offer(self, event: dict[str, Any]) -> None:
        # Synchronous append -- fine because asyncio.Lock is only needed
        # at flush time. Append is atomic for CPython lists.
        if self._stopped or not self._http:
            return
        self._buf.append(event)

    async def _run(self) -> None:
        while not self._stopped:
            await asyncio.sleep(FLUSH_INTERVAL_S)
            if len(self._buf) >= 1:
                await self.flush()

    async def flush(self) -> None:
        if not self._http or not self._buf:
            return
        async with self._lock:
            batch = self._buf[:FLUSH_BATCH]
            self._buf = self._buf[FLUSH_BATCH:]
        items: list[dict[str, Any]] = []
        for ev in batch:
            classified = _classify(ev)
            if not classified:
                continue
            kind, text, meta = classified
            items.append({
                "kind": kind,
                "text": text or "(empty)",
                "tags": ["cockpit", f"session:{self.session_id}"],
                "ts": int(time.time() * 1000),
                "meta": meta,
            })
        if not items:
            return
        api_base = neruva_api_base()
        api_key = neruva_api_key()
        if not api_key:
            return
        url = f"{api_base}/v1/records/{self.project}"
        try:
            r = await self._http.post(
                url,
                headers={"Api-Key": api_key, "Content-Type": "application/json"},
                json={"items": items},
            )
            if r.status_code >= 400:
                log.warning("recorder: %s -> %s: %s", url, r.status_code, r.text[:200])
        except Exception as e:
            log.warning("recorder: post failed: %s", e)


def have_api_key() -> bool:
    return neruva_api_key() is not None
