"""Semantic codebase indexer.

CLI entry: ``neruva-control index <path> [--namespace N] [--max-files M]``

Walks a project tree, chunks every recognized source/markdown file at
~400-line boundaries (preferring blank-line breaks), and pushes each
chunk to the substrate as a typed record:

  kind: "code_chunk"
  tags: ["code_index", "lang:<lang>", "path:<rel_path>"]
  meta: {path, lang, lines: "start-end", n_lines}
  text: <chunk source>

The Code agent's ``code_search({query})`` action then queries the
substrate's semantic recall to find the right files / chunks without
reading them all into context. The "Augment Context Engine" pattern
in stdlib + the existing Neruva substrate.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time
from pathlib import Path
from typing import Optional

import httpx

from ._config import neruva_api_key, neruva_api_base
from ._repo_map import _LANG_BY_EXT, _SKIP_DIRS, _should_skip_dir


_INDEX_EXTS = set(_LANG_BY_EXT.keys()) | {".md", ".mdx", ".rst"}
_CHUNK_LINES_TARGET = 400
_CHUNK_LINES_MAX = 600
_MAX_FILE_BYTES = 500_000  # skip files >500KB


def _chunk_text(text: str, target: int = _CHUNK_LINES_TARGET,
                max_lines: int = _CHUNK_LINES_MAX) -> list[tuple[int, int, str]]:
    """Split text into chunks of ~target lines, breaking at blank lines
    when possible. Returns [(start_line, end_line, chunk_text)]."""
    lines = text.splitlines()
    if not lines:
        return []
    chunks: list[tuple[int, int, str]] = []
    i = 0
    n = len(lines)
    while i < n:
        end = min(i + target, n)
        # Walk forward up to max_lines looking for a blank-line break
        if end < n:
            scan_to = min(i + max_lines, n)
            for j in range(end, scan_to):
                if not lines[j].strip():
                    end = j
                    break
        chunk = "\n".join(lines[i:end])
        chunks.append((i + 1, end, chunk))
        i = end
    return chunks


def _walk_files(root: Path, max_files: int) -> list[Path]:
    out: list[Path] = []
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if not _should_skip_dir(d)]
        for fn in filenames:
            p = Path(dirpath) / fn
            ext = p.suffix.lower()
            if ext not in _INDEX_EXTS:
                continue
            try:
                if p.stat().st_size > _MAX_FILE_BYTES:
                    continue
            except OSError:
                continue
            out.append(p)
            if len(out) >= max_files:
                return out
    return out


def index_project(
    root: str,
    namespace: str = "code_index",
    max_files: int = 500,
    project_tag: Optional[str] = None,
    api_key: Optional[str] = None,
    api_base: Optional[str] = None,
    verbose: bool = True,
) -> dict:
    """Index a project tree into the substrate. Returns stats."""
    root_path = Path(root).resolve()
    if not root_path.exists() or not root_path.is_dir():
        raise ValueError(f"not a directory: {root_path}")
    key = api_key or neruva_api_key()
    if not key:
        raise RuntimeError("NERUVA_API_KEY required (run neruva-control-install)")
    base = (api_base or neruva_api_base()).rstrip("/")

    files = _walk_files(root_path, max_files)
    if verbose:
        print(f"[index] {root_path}: {len(files)} files")

    batch: list[dict] = []
    total_chunks = 0
    started = time.perf_counter()

    def _flush(batch: list[dict]) -> None:
        if not batch:
            return
        try:
            with httpx.Client(timeout=30.0) as cli:
                r = cli.post(
                    f"{base}/v1/records/{namespace}",
                    headers={"Api-Key": key,
                             "Content-Type": "application/json"},
                    json={"items": batch},
                )
                if r.status_code >= 400 and verbose:
                    print(f"[index] WARN: substrate {r.status_code}: "
                          f"{r.text[:200]}")
        except Exception as e:
            if verbose:
                print(f"[index] WARN: substrate POST failed: {e}")

    for i, p in enumerate(files):
        ext = p.suffix.lower()
        lang = _LANG_BY_EXT.get(ext) or "markdown"
        try:
            text = p.read_text(encoding="utf-8", errors="replace")
        except Exception:
            continue
        rel = str(p.relative_to(root_path)).replace("\\", "/")
        for start, end, chunk in _chunk_text(text):
            tags = ["code_index", f"lang:{lang}", f"path:{rel}"]
            if project_tag:
                tags.append(f"project:{project_tag}")
            batch.append({
                "kind": "code_chunk",
                "text": chunk[:30_000],
                "tags": tags,
                "meta": {
                    "path": rel,
                    "lang": lang,
                    "lines": f"{start}-{end}",
                    "n_lines": end - start + 1,
                },
            })
            total_chunks += 1
            if len(batch) >= 50:
                _flush(batch)
                batch = []
        if verbose and (i + 1) % 25 == 0:
            print(f"[index] {i + 1}/{len(files)} files, "
                  f"{total_chunks} chunks")

    _flush(batch)
    elapsed = time.perf_counter() - started
    if verbose:
        print(f"[index] done: {len(files)} files, {total_chunks} chunks, "
              f"{elapsed:.1f}s")
    return {
        "files": len(files),
        "chunks": total_chunks,
        "namespace": namespace,
        "duration_s": elapsed,
    }


def main() -> int:
    ap = argparse.ArgumentParser(
        prog="neruva-control index",
        description="Index a project's source files into the Neruva substrate "
                    "for semantic code search.")
    ap.add_argument("path", help="Project root directory")
    ap.add_argument("--namespace", default="code_index",
                    help="Substrate namespace (default: code_index)")
    ap.add_argument("--max-files", type=int, default=500,
                    help="Cap on files to index (default: 500)")
    ap.add_argument("--project-tag", default=None,
                    help="Optional tag to bind chunks to a specific project")
    ap.add_argument("--quiet", action="store_true")
    args = ap.parse_args()
    try:
        stats = index_project(
            args.path,
            namespace=args.namespace,
            max_files=args.max_files,
            project_tag=args.project_tag,
            verbose=not args.quiet,
        )
        print(json.dumps(stats, indent=2))
        return 0
    except Exception as e:
        print(f"index failed: {e}", file=sys.stderr)
        return 1
