"""Config + token I/O for neruva-control.

Single source of truth for where files live (cross-platform via
platformdirs). The token is the shared secret between the daemon
process and the browser at app.neruva.io -- generated once at
install, never rotated unless the user explicitly re-installs.
"""
from __future__ import annotations

import os
import secrets
from pathlib import Path
from platformdirs import user_config_dir


CONFIG_APP = "neruva"
CONFIG_AUTHOR = "neruva"

# Default substrate base. Overridable via NERUVA_API_BASE env (or future
# control.toml setting) for self-hosted / staging.
DEFAULT_API_BASE = "https://api.neruva.io"


def neruva_api_base() -> str:
    return os.environ.get("NERUVA_API_BASE", DEFAULT_API_BASE)


def neruva_api_key() -> str | None:
    """User's Neruva API key for posting recorded events. Read from env
    first, then ~/.config/neruva/api.key as a stable per-machine option.
    Returns None if unset -- daemon then runs in 'no-record' mode."""
    k = os.environ.get("NERUVA_API_KEY")
    if k:
        return k.strip()
    p = config_dir() / "api.key"
    if p.exists():
        try:
            return p.read_text(encoding="utf-8").strip() or None
        except Exception:
            return None
    return None


def config_dir() -> Path:
    p = Path(user_config_dir(CONFIG_APP, CONFIG_AUTHOR))
    p.mkdir(parents=True, exist_ok=True)
    return p


def env_file_path() -> Path:
    """Per-user .env where users can persist HOLO3_API_KEY / MISTRAL_API_KEY
    / NERUVA_API_KEY without touching their shell profile. Auto-loaded by
    load_env_files() at daemon startup."""
    return config_dir() / ".env"


def _parse_env_file(path: Path) -> dict[str, str]:
    """Tiny .env parser (no python-dotenv dep). Supports KEY=value lines,
    strips surrounding single/double quotes, ignores blanks + comments."""
    out: dict[str, str] = {}
    try:
        text = path.read_text(encoding="utf-8")
    except Exception:
        return out
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        # Allow `export KEY=value` style too.
        if line.startswith("export "):
            line = line[7:].lstrip()
        k, _, v = line.partition("=")
        k = k.strip()
        v = v.strip()
        # Strip surrounding quotes if present.
        if len(v) >= 2 and v[0] == v[-1] and v[0] in ('"', "'"):
            v = v[1:-1]
        if k:
            out[k] = v
    return out


def load_env_files() -> int:
    """Load env vars from (in order, lowest -> highest precedence):
        1. ~/.config/neruva/.env  (per-user; default location)
        2. ./.env                  (cwd; dev convenience)
    Existing process env vars take precedence over both. Returns the
    number of variables loaded (newly-set, not pre-existing)."""
    n = 0
    for p in (env_file_path(), Path.cwd() / ".env"):
        if not p.exists():
            continue
        for k, v in _parse_env_file(p).items():
            if k not in os.environ:
                os.environ[k] = v
                n += 1
    return n


def token_path() -> Path:
    return config_dir() / "control.token"


def config_path() -> Path:
    return config_dir() / "control.toml"


def daemon_id_path() -> Path:
    return config_dir() / "daemon_id"


def trusted_devices_path() -> Path:
    return config_dir() / "trusted_devices.json"


def load_or_create_daemon_id() -> str:
    """Stable per-install identifier. Phones use this to find us on the
    signaling presence channel for rejoin without scanning a fresh QR."""
    p = daemon_id_path()
    if p.exists():
        try:
            v = p.read_text(encoding="utf-8").strip()
            if v:
                return v
        except Exception:
            pass
    new = "d_" + secrets.token_urlsafe(12)
    p.write_text(new, encoding="utf-8")
    if os.name == "posix":
        try: os.chmod(p, 0o600)
        except Exception: pass
    return new


def load_token() -> str:
    """Read the shared token. Raises FileNotFoundError if not installed."""
    p = token_path()
    if not p.exists():
        raise FileNotFoundError(
            f"No token at {p}. Run `neruva-control-install` first."
        )
    return p.read_text(encoding="utf-8").strip()


def write_token(token: str) -> Path:
    """Write a new token (overwrite). Returns the path."""
    p = token_path()
    p.write_text(token, encoding="utf-8")
    # chmod 600 on Unix; on Windows ACLs already restrict to user
    if os.name == "posix":
        os.chmod(p, 0o600)
    return p


def gen_token() -> str:
    return secrets.token_urlsafe(32)


def cockpit_link_url(token: str, base: str = "https://app.neruva.io") -> str:
    """Fragment URL the installer prints. Browser reads #token=..., stashes
    in localStorage, then strips via history.replaceState."""
    return f"{base}/cockpit#token={token}"
