"""Agent self-memory layer: every step + task outcome auto-recorded to
substrate, structured for cross-session learning.

Three callable surfaces, all fire-and-forget unless noted:

  - remember_step_async(...)     write one (action, result) tuple
  - remember_task_end_async(...) write task summary + (on fail) lesson
  - recall_lessons(...)          SYNC pre-task lookup of past lessons
                                 for this task class + app
  - classify_task(task_text)     -> task_class string used in tags
  - infer_app(task_text)         -> best-guess app string used in tags

This module is what turns a stateless agent into one that learns from
its own runs. Failures stored here become surfaced as `LEARNED:` hints
in future Holo3/Devstral system prompts via recall_lessons.

Design contract:
  - All async fns swallow exceptions -- substrate down MUST NOT break
    the agent loop. They schedule a task via asyncio.create_task and
    return immediately.
  - Sync recall_lessons has a tight deadline (default 1.2s) -- if the
    substrate is cold, the agent proceeds without lessons.
  - Tags are the join key: every record carries
    [`agent:computer|code`, `task_class:<class>`, `app:<app>`,
    `outcome:ok|fail`, ...]. The substrate's records_query + tags_all
    surface filters efficiently.
"""
from __future__ import annotations

import asyncio
import os
import re
import time
from typing import Any, Optional

import httpx


_BASE_URL = os.environ.get("NERUVA_URL", "https://api.neruva.io").rstrip("/")
_RECALL_TIMEOUT_S = 1.2     # pre-task lesson lookup deadline
_WRITE_TIMEOUT_S = 4.0      # fire-and-forget step / summary writes


# ---------- Classifiers (cheap, local, no LLM) ----------------------

_TASK_PATTERNS: list[tuple[str, re.Pattern]] = [
    ("web_search", re.compile(r"\b(google|search\b.*\bfor|look\s*up)\b", re.I)),
    ("web_read",   re.compile(r"\b(go\s+to|open|fetch|visit|navigate).*\b(\.com|\.io|\.org|https?://)", re.I)),
    ("web_read",   re.compile(r"\b(news\.ycombinator|hacker\s*news)\b", re.I)),
    ("app_launch", re.compile(r"\b(open|launch|start)\s+(notepad|calculator|word|excel|chrome|firefox|edge|terminal)\b", re.I)),
    ("calc",       re.compile(r"\b(calculate|compute|add|subtract|multiply|divide|\d+\s*[+\-*/]\s*\d+)\b", re.I)),
    ("file_edit",  re.compile(r"\b(edit|modify|change|update)\b.*\.(py|js|ts|md|json|tsx|jsx|go|rs)\b", re.I)),
    ("file_read",  re.compile(r"\b(read|show|cat|view)\b.*\.(py|js|ts|md|json|tsx|jsx|go|rs)\b", re.I)),
    ("bash",       re.compile(r"\b(run\b|execute|invoke|bash|shell|npm|pip|git)\b", re.I)),
    ("type_text",  re.compile(r"\btype\s+", re.I)),
]


_APP_PATTERNS: list[tuple[str, re.Pattern]] = [
    ("chrome",     re.compile(r"\b(chrome|google\.com|youtube)\b", re.I)),
    ("firefox",    re.compile(r"\bfirefox\b", re.I)),
    ("edge",       re.compile(r"\b(edge|bing)\b", re.I)),
    ("notepad",    re.compile(r"\bnotepad\b", re.I)),
    ("calculator", re.compile(r"\bcalculator\b", re.I)),
    ("vscode",     re.compile(r"\b(vs\s*code|vscode|code\.exe)\b", re.I)),
    ("terminal",   re.compile(r"\b(terminal|cmd|powershell|pwsh|bash)\b", re.I)),
    ("explorer",   re.compile(r"\b(file\s*explorer|explorer\.exe)\b", re.I)),
    ("browser",    re.compile(r"\b(browser|web|https?://|\.com|\.io|\.org)\b", re.I)),
]


def classify_task(task_text: str) -> str:
    """Cheap regex classifier -- returns the first matching task_class
    or 'other'. Used as a tag for cross-task aggregation."""
    if not task_text:
        return "other"
    for label, pat in _TASK_PATTERNS:
        if pat.search(task_text):
            return label
    return "other"


def infer_app(task_text: str, default: str = "") -> str:
    """Best-guess app name from the task text. Returns '' if unknown."""
    if not task_text:
        return default
    for label, pat in _APP_PATTERNS:
        if pat.search(task_text):
            return label
    return default


# ---------- Substrate transport (fail-quiet) ------------------------

async def _post_async(path: str, body: dict, api_key: str,
                      timeout: float = _WRITE_TIMEOUT_S) -> None:
    """POST to substrate, swallow all errors. Used for fire-and-forget
    writes -- the agent loop never blocks or surfaces failures."""
    try:
        async with httpx.AsyncClient(timeout=timeout) as cli:
            await cli.post(
                f"{_BASE_URL}{path}",
                headers={"Api-Key": api_key,
                         "Content-Type": "application/json"},
                json=body,
            )
    except Exception:
        pass


def _post_sync(path: str, body: dict, api_key: str,
               timeout: float = _RECALL_TIMEOUT_S) -> Optional[dict]:
    """Sync POST with tight deadline; returns parsed JSON or None."""
    try:
        with httpx.Client(timeout=timeout) as cli:
            r = cli.post(
                f"{_BASE_URL}{path}",
                headers={"Api-Key": api_key,
                         "Content-Type": "application/json"},
                json=body,
            )
        if r.status_code != 200:
            return None
        return r.json()
    except Exception:
        return None


# ---------- Public surface ------------------------------------------

def remember_step_async(
    *,
    agent: str,             # "computer" | "code"
    namespace: str,
    task_text: str,
    task_class: str,
    app: str,
    step_index: int,
    action: dict,
    result: dict,
    api_key: Optional[str],
) -> None:
    """Schedule a step record write. Returns immediately. Never raises."""
    if not api_key:
        return
    ok = bool(result.get("ok"))
    action_name = str(action.get("action", "?"))
    # Compact text: action + outcome. Tags carry the structure.
    text_bits: list[str] = [
        f"step {step_index}: {action_name}",
        f"  args: {_compact_dict(action.get('args') or action, max_len=240)}",
        f"  outcome: ok={ok}",
    ]
    if not ok:
        err = str(result.get("error") or "")[:200]
        if err:
            text_bits.append(f"  error: {err}")
    text = "\n".join(text_bits)
    tags = [
        f"agent:{agent}",
        f"task_class:{task_class}",
        f"outcome:{'ok' if ok else 'fail'}",
        f"action:{action_name}",
    ]
    if app:
        tags.append(f"app:{app}")
    body = {
        "namespace": namespace,
        "kind": "agent_step",
        "text": text,
        "tags": tags,
        "extract": "off",   # do NOT pay for KG extraction on each step
    }
    try:
        asyncio.create_task(_post_async("/v1/agent/remember", body, api_key))
    except RuntimeError:
        # No running loop -- caller is in sync land. Skip.
        pass


def remember_task_end_async(
    *,
    agent: str,
    namespace: str,
    task_text: str,
    task_class: str,
    app: str,
    ok: bool,
    n_steps: int,
    duration_ms: int,
    plan_summary: str,
    final_say: str,
    api_key: Optional[str],
    history: Optional[list] = None,
    original_plan: Optional[list[str]] = None,
    on_postmortem: Optional[Any] = None,
) -> None:
    """Schedule a task-summary record. On ok=False, also schedule a
    post-mortem: substrate runs Magistral over (task, plan, history) and
    returns a structured lesson + corrected plan, which get stored as
    kind=lesson + kind=corrected_plan respectively. Next similar task
    surfaces both via recall_lessons.

    `on_postmortem(result: dict)` -- optional async callback the caller
    can pass to await the postmortem result (so Cockpit can render
    "Magistral analyzed your failure" event)."""
    if not api_key:
        return
    text_bits = [
        f"TASK: {task_text[:200]}",
        f"agent: neruva-{agent}",
        f"plan: {plan_summary[:400]}",
        f"outcome: ok={ok}, {n_steps} steps in {duration_ms}ms",
    ]
    if final_say:
        text_bits.append(f"final_say: {final_say[:300]}")
    text = "\n".join(text_bits)
    tags = [
        f"agent:{agent}",
        f"task_class:{task_class}",
        f"outcome:{'ok' if ok else 'fail'}",
    ]
    if app:
        tags.append(f"app:{app}")
    body = {
        "namespace": namespace,
        "kind": "task_summary",
        "text": text,
        "tags": tags,
        "extract": "off",
    }
    try:
        asyncio.create_task(_post_async("/v1/agent/remember", body, api_key))
    except RuntimeError:
        pass

    # On failure: kick off post-mortem distillation. Magistral analyzes
    # (task, plan, history) and returns {failure_class, lesson,
    # corrected_plan}. The lesson is stored as kind=lesson so it's
    # surfaced via recall_lessons next time. The corrected plan is
    # stored as kind=corrected_plan tagged with the task_class so the
    # planner can use it as a starting skeleton.
    if not ok:
        async def _run_postmortem() -> None:
            try:
                pm_body = {
                    "agent": agent,
                    "task_text": task_text,
                    "plan": list(original_plan or []),
                    "history": [h for h in (history or [])][:30],
                    "error": _extract_last_error(history or []),
                    "task_class": task_class,
                    "app": app,
                }
                pm = await _post_async_get("/v1/agent/postmortem",
                                           pm_body, api_key, timeout=90.0)
                if not pm or not isinstance(pm, dict):
                    return
                failure_class = str(pm.get("failure_class") or "unknown")
                lesson_text = str(pm.get("lesson") or "").strip()
                corrected = pm.get("corrected_plan") or []
                if not isinstance(corrected, list):
                    corrected = []
                # Store the distilled lesson as kind=lesson
                if lesson_text:
                    lesson_body = {
                        "namespace": namespace,
                        "kind": "lesson",
                        "text": (
                            f"LESSON [{failure_class}] for "
                            f"{task_class}{('/' + app) if app else ''}:\n"
                            f"  {lesson_text}\n"
                            f"  (from failed: {task_text[:160]})"
                        ),
                        "tags": list(tags) + [
                            f"failure_class:{failure_class}",
                            "source:postmortem",
                        ],
                        "extract": "off",
                    }
                    await _post_async("/v1/agent/remember",
                                       lesson_body, api_key)
                # Store the corrected plan as kind=corrected_plan so a
                # future planner pass can hit it (push 3: semantic
                # plan-cache lookup will consume these).
                if corrected:
                    plan_body = {
                        "namespace": namespace,
                        "kind": "corrected_plan",
                        "text": (
                            f"CORRECTED PLAN for {task_class}"
                            f"{('/' + app) if app else ''}:\n"
                            f"  task: {task_text[:160]}\n  plan:\n  - " +
                            "\n  - ".join(str(s) for s in corrected[:20])
                        ),
                        "tags": list(tags) + [
                            f"failure_class:{failure_class}",
                            "source:postmortem",
                        ],
                        "extract": "off",
                    }
                    await _post_async("/v1/agent/remember",
                                       plan_body, api_key)
                # Notify caller (for Cockpit "🪞 Magistral analyzed..." event)
                if on_postmortem is not None:
                    try:
                        await on_postmortem({
                            "failure_class": failure_class,
                            "lesson": lesson_text,
                            "corrected_plan": list(corrected),
                            "duration_ms": pm.get("duration_ms"),
                        })
                    except Exception:
                        pass
            except Exception:
                pass

        try:
            asyncio.create_task(_run_postmortem())
        except RuntimeError:
            pass


def _extract_last_error(history: list) -> str:
    """Pull the last meaningful error string out of the history."""
    for h in reversed(history or []):
        res = h.get("result") or {}
        if not res.get("ok"):
            err = str(res.get("error") or "").strip()
            if err:
                return err[:300]
    return ""


async def _post_async_get(path: str, body: dict, api_key: str,
                          timeout: float = 60.0) -> Optional[dict]:
    """Like _post_async but returns the parsed JSON. Used for postmortem
    where we need the response to store the lesson."""
    try:
        async with httpx.AsyncClient(timeout=timeout) as cli:
            r = await cli.post(
                f"{_BASE_URL}{path}",
                headers={"Api-Key": api_key,
                         "Content-Type": "application/json"},
                json=body,
            )
        if r.status_code != 200:
            return None
        return r.json()
    except Exception:
        return None


def recall_lessons(
    *,
    task_text: str,
    task_class: str,
    app: str,
    namespace: str,
    api_key: Optional[str],
    top_k: int = 3,
    min_score: float = 0.45,
) -> list[dict]:
    """SYNC pre-task lookup: returns up to top_k matching lessons from
    past runs. Tight deadline -- if substrate is cold, returns [].

    Each hit: {text, score, kind, tags}."""
    if not api_key or not task_text:
        return []
    # Bias the query toward the (task_class, app) we're about to run.
    query = task_text
    if task_class != "other":
        query = f"[{task_class}] {query}"
    if app:
        query = f"[app:{app}] {query}"
    data = _post_sync(
        "/v1/agent/recall",
        {"query": query, "namespace": namespace, "top_k": top_k * 3},
        api_key,
    )
    if not data:
        return []
    out: list[dict] = []
    for r in (data.get("records") or []):
        # Surface both kind=lesson AND kind=corrected_plan -- the
        # corrected plan from a past postmortem is even more useful
        # than the lesson text (it's an actual recipe).
        if str(r.get("kind", "")) not in ("lesson", "corrected_plan"):
            continue
        if float(r.get("score", 0)) < min_score:
            continue
        out.append(r)
        if len(out) >= top_k:
            break
    return out


def extract_cached_plan(lessons: list[dict]) -> list[str]:
    """If any of the recalled lessons is a kind=corrected_plan, parse
    out its plan steps and return them. Returns the FIRST (highest
    score) corrected plan found, or [] if none.

    Skips the planner call entirely when this returns non-empty -- the
    cached plan is by definition a known-good recipe distilled by
    Magistral from a real past failure. Cheaper and more reliable than
    asking Magistral to re-plan from scratch every time."""
    for l in lessons or []:
        if str(l.get("kind", "")) != "corrected_plan":
            continue
        text = str(l.get("text", "") or "")
        # Format from remember_task_end_async:
        #   CORRECTED PLAN for <task_class>[/<app>]:
        #     task: <text>
        #     plan:
        #     - <step1>
        #     - <step2>
        if "plan:" not in text:
            continue
        body = text.split("plan:", 1)[1]
        steps: list[str] = []
        for line in body.splitlines():
            s = line.strip()
            if s.startswith("- "):
                step = s[2:].strip()
                if step:
                    steps.append(step)
        if steps:
            return steps
    return []


def format_lessons_preamble(lessons: list[dict]) -> str:
    """Render up to top_k lessons as a system-prompt preamble. Empty
    string when no lessons -- caller can no-op concatenate."""
    if not lessons:
        return ""
    bits = ["LEARNED from your past runs (apply when relevant):"]
    for i, l in enumerate(lessons, 1):
        text = str(l.get("text", "")).strip().splitlines()
        head = text[0][:140] if text else "(empty lesson)"
        bits.append(f"  {i}. {head}")
    return "\n".join(bits)


# ---------- Helpers ------------------------------------------------

def _compact_dict(d: Any, max_len: int = 200) -> str:
    """Compact one-line repr of a dict for record text."""
    try:
        import json as _json
        s = _json.dumps(d, default=str, ensure_ascii=False)
    except Exception:
        s = repr(d)
    s = re.sub(r"\s+", " ", s)
    if len(s) > max_len:
        s = s[:max_len - 3] + "..."
    return s
