"""Accessibility-tree extraction for Neruva Computer.

Pulls UI elements (name, role, bounding box) directly from the OS
accessibility tree instead of relying on the vision model to read a
raw screenshot. This is the largest single perception upgrade for a
screen-control agent -- UI-TARS-2 uses the same approach to hit 88.2
on Online-Mind2Web.

Platform backends:
  - Windows: uiautomation library (UI Automation API). Required for now.
  - macOS:  pyobjc + ApplicationServices (AX). TODO.
  - Linux:  python-atspi (AT-SPI). TODO.

Returns a list of ``Element`` dicts:
  {id, role, name, bbox: [x,y,w,h], focused, enabled, depth}

The agent uses these to ground actions: pick an element by id and call
``click_ref(id)`` instead of guessing pixel coords.
"""
from __future__ import annotations

import sys
from typing import Any, Optional


_PLATFORM = sys.platform


def axtree_available() -> tuple[bool, str]:
    """Return (available, reason) for the current platform."""
    if _PLATFORM == "win32":
        try:
            import uiautomation  # noqa: F401
            return True, "windows-uia"
        except ImportError:
            return False, "uiautomation not installed (pip install uiautomation)"
    return False, f"ax-tree not yet implemented for {_PLATFORM}"


def _walk_windows(root: Any, max_depth: int, max_elements: int,
                  region: Optional[tuple[int, int, int, int]] = None
                  ) -> list[dict]:
    """Walk a Windows UI Automation tree, returning visible elements
    inside ``region`` (x,y,w,h) if given."""
    out: list[dict] = []
    rid = 0

    def _in_region(rect: Any) -> bool:
        if region is None:
            return True
        rx, ry, rw, rh = region
        return not (rect.right < rx or rect.left > rx + rw or
                    rect.bottom < ry or rect.top > ry + rh)

    def _visit(ctrl: Any, depth: int) -> None:
        nonlocal rid
        if depth > max_depth or len(out) >= max_elements:
            return
        try:
            rect = ctrl.BoundingRectangle
        except Exception:
            rect = None
        if rect is None or rect.width() <= 0 or rect.height() <= 0:
            # Container with no visible bounds -- still recurse into kids
            try:
                for child in ctrl.GetChildren():
                    _visit(child, depth + 1)
            except Exception:
                pass
            return
        if not _in_region(rect):
            return
        try:
            name = (ctrl.Name or "").strip()
        except Exception:
            name = ""
        try:
            role = ctrl.ControlTypeName or ""
        except Exception:
            role = ""
        try:
            enabled = bool(ctrl.IsEnabled)
        except Exception:
            enabled = True
        # Skip purely structural containers with no name
        if name or role in ("ButtonControl", "EditControl", "HyperlinkControl",
                            "MenuItemControl", "ListItemControl", "TabItemControl",
                            "CheckBoxControl", "RadioButtonControl", "ComboBoxControl",
                            "TextControl"):
            out.append({
                "id": f"ax{rid}",
                "role": role.replace("Control", "").lower(),
                "name": name[:120],
                "bbox": [int(rect.left), int(rect.top),
                         int(rect.width()), int(rect.height())],
                "enabled": enabled,
                "depth": depth,
            })
            rid += 1
        try:
            for child in ctrl.GetChildren():
                _visit(child, depth + 1)
        except Exception:
            pass

    _visit(root, 0)
    return out


def get_axtree(region: Optional[tuple[int, int, int, int]] = None,
               max_depth: int = 12, max_elements: int = 300,
               window_title: Optional[str] = None) -> dict:
    """Extract the accessibility tree under the focused window (or a
    specified window by title substring). Returns:
      {ok, available, backend, n_elements, elements, root_title}

    The agent should typically call this BEFORE clicking blindly --
    elements are stable, named, and bounded; pixel coordinates are not.
    """
    avail, reason = axtree_available()
    if not avail:
        return {"ok": False, "available": False, "error": reason}
    if _PLATFORM != "win32":
        return {"ok": False, "available": False,
                "error": f"platform {_PLATFORM} not supported"}
    try:
        import uiautomation as auto  # type: ignore
    except ImportError:
        return {"ok": False, "available": False,
                "error": "uiautomation not installed"}
    try:
        if window_title:
            root = auto.WindowControl(searchDepth=1, SubName=window_title)
            if not root.Exists(maxSearchSeconds=1):
                root = auto.GetRootControl()
        else:
            try:
                root = auto.GetFocusedControl()
                # Walk up to the nearest window for context
                cur = root
                while cur and cur.ControlTypeName != "WindowControl":
                    parent = cur.GetParentControl()
                    if not parent:
                        break
                    cur = parent
                root = cur or auto.GetRootControl()
            except Exception:
                root = auto.GetRootControl()
        title = ""
        try:
            title = (root.Name or "")[:120]
        except Exception:
            pass
        elements = _walk_windows(root, max_depth, max_elements, region)
        return {
            "ok": True, "available": True, "backend": "windows-uia",
            "root_title": title, "n_elements": len(elements),
            "elements": elements,
        }
    except Exception as e:
        return {"ok": False, "available": True,
                "error": f"{type(e).__name__}: {e}"}


def find_element(description: str,
                 region: Optional[tuple[int, int, int, int]] = None
                 ) -> dict:
    """Find a UI element by natural-language description. Ax-tree first
    (name substring match + role hint), OCR second (TODO), pure vision
    third (TODO). Returns:
      {ok, element, matched_by, candidates_considered}
    """
    desc = (description or "").lower().strip()
    if not desc:
        return {"ok": False, "error": "description required"}
    ax = get_axtree(region=region)
    if not ax.get("ok"):
        return {"ok": False, "error": ax.get("error", "ax-tree unavailable"),
                "matched_by": None}
    elements = ax.get("elements", [])
    # Score each element by name overlap with the description.
    desc_words = set(w for w in desc.split() if len(w) > 2)
    scored: list[tuple[int, dict]] = []
    for el in elements:
        if not el.get("enabled", True):
            continue
        name = (el.get("name") or "").lower()
        role = (el.get("role") or "").lower()
        if not name and not role:
            continue
        score = 0
        # Exact phrase match in name = strongest signal
        if name and (desc in name or name in desc):
            score += 10
        # Word overlap in name
        name_words = set(w for w in name.split() if len(w) > 2)
        score += 3 * len(desc_words & name_words)
        # Role hint in description (e.g. "the Submit button")
        if role and role in desc:
            score += 2
        if score > 0:
            scored.append((score, el))
    scored.sort(key=lambda t: -t[0])
    if not scored:
        # Ax-tree miss -- try OCR as fallback (works for canvas / webgl /
        # custom-drawn UIs the accessibility tree doesn't see).
        try:
            from ._ocr import ocr_screen
            ocr_res = ocr_screen(region=region)
        except Exception:
            ocr_res = {"ok": False}
        if ocr_res.get("ok"):
            for line in ocr_res.get("lines", []):
                ltext = (line.get("text") or "").lower()
                if not ltext:
                    continue
                if desc in ltext or ltext in desc:
                    bx = line["bbox"]
                    return {
                        "ok": True,
                        "element": {
                            "id": "ocr0", "role": "text", "name": line["text"],
                            "bbox": bx,
                            "center": [bx[0] + bx[2] // 2, bx[1] + bx[3] // 2],
                            "conf": line.get("conf", 0),
                        },
                        "matched_by": "ocr",
                        "candidates_considered": len(elements) + len(ocr_res["lines"]),
                    }
        return {"ok": False, "error": f"no element matched {description!r}",
                "matched_by": "none",
                "candidates_considered": len(elements)}
    best = scored[0][1]
    bbox = best["bbox"]
    center = [bbox[0] + bbox[2] // 2, bbox[1] + bbox[3] // 2]
    return {
        "ok": True,
        "element": {**best, "center": center},
        "matched_by": "ax-tree",
        "candidates_considered": len(elements),
        "score": scored[0][0],
        "runner_up": (scored[1][1]["name"] if len(scored) > 1 else None),
    }
