"""Agent Skills: filesystem playbooks the agent can load on demand.

A skill is a Markdown file. The first line (after any leading blank
lines) is taken as a one-line summary; the rest is the body.

Skills live in two places, searched in order:

  1. ``<cwd>/.neruva/skills/*.md``  -- project-local skills (e.g. team
     conventions, framework-specific recipes, this codebase's quirks).
  2. ``<config_dir>/skills/*.md``   -- per-user global skills.

The session start scans both, builds a {name: one_line_summary} index,
and injects it into the agent's system prompt so the model knows what
skills exist. The model fetches a skill's full body on demand via the
``load_skill({name})`` action -- this is the "progressive disclosure"
pattern Anthropic uses for Claude Code skills.

Skill name is the file stem with leading underscores stripped (so
``python-uv.md`` -> ``python-uv``, ``_archive_old.md`` -> ignored).
"""
from __future__ import annotations

import os
from pathlib import Path
from typing import Optional

from ._config import config_dir


_MAX_SKILL_BYTES = 64_000  # 64KB skill bodies are plenty


def _skill_dirs(cwd: Optional[str] = None) -> list[Path]:
    """Search order: project-local skills first, then user-global."""
    dirs: list[Path] = []
    if cwd:
        local = Path(cwd) / ".neruva" / "skills"
        if local.exists() and local.is_dir():
            dirs.append(local)
    try:
        cfg = Path(config_dir()) / "skills"
        if cfg.exists() and cfg.is_dir():
            dirs.append(cfg)
    except Exception:
        pass
    return dirs


def _skill_name(p: Path) -> Optional[str]:
    stem = p.stem
    if stem.startswith("_"):
        return None
    return stem


def _summary_of(text: str) -> str:
    """First non-blank, non-heading line; trimmed to 120 chars."""
    for raw in text.splitlines():
        line = raw.strip()
        if not line:
            continue
        # Strip Markdown headings so "# Python uv" -> "Python uv"
        while line.startswith("#"):
            line = line.lstrip("#").strip()
        if not line:
            continue
        return line[:120]
    return ""


def list_skills(cwd: Optional[str] = None) -> list[dict]:
    """Return [{name, summary, source}] for every discoverable skill.

    Project-local skills shadow same-named user-global skills."""
    seen: set[str] = set()
    out: list[dict] = []
    for d in _skill_dirs(cwd):
        try:
            files = sorted(d.glob("*.md"))
        except Exception:
            continue
        for p in files:
            name = _skill_name(p)
            if not name or name in seen:
                continue
            try:
                text = p.read_text(encoding="utf-8", errors="replace")
            except Exception:
                continue
            summary = _summary_of(text)
            if not summary:
                continue
            seen.add(name)
            out.append({
                "name": name,
                "summary": summary,
                "source": "project" if ".neruva" in str(p) else "user",
            })
    return out


def load_skill(name: str, cwd: Optional[str] = None) -> Optional[str]:
    """Load a skill's full body. Returns None if not found."""
    safe = name.strip()
    if not safe or "/" in safe or "\\" in safe or ".." in safe:
        return None
    for d in _skill_dirs(cwd):
        p = d / f"{safe}.md"
        if p.exists() and p.stat().st_size < _MAX_SKILL_BYTES:
            try:
                return p.read_text(encoding="utf-8", errors="replace")
            except Exception:
                continue
    return None


def skills_preamble(cwd: Optional[str] = None) -> str:
    """Render the skills index as a system-prompt preamble. Empty string
    when no skills are installed."""
    items = list_skills(cwd)
    if not items:
        return ""
    lines = ["AVAILABLE SKILLS (call load_skill({name}) to get the full playbook):"]
    for s in items:
        lines.append(f"  - {s['name']}: {s['summary']} [{s['source']}]")
    return "\n".join(lines)
