"""Trusted-device store for Neruva Pair rejoin.

After a successful first-time pair the daemon mints a device_token,
hashes it, and stores the hash here keyed by a short device_id. The
phone keeps the raw token in localStorage. On rejoin the phone presents
(daemon_id, device_token) -> the signaling server forwards to us ->
we hash the presented token and look it up here. Constant-time compare
prevents timing leaks.

trusted_devices.json schema:
    {
        "version": 1,
        "devices": [
            {
                "device_id": "dev_<8 hex>",
                "token_sha256": "<hex>",
                "label": "iPhone (paired 2026-05-15)",
                "paired_at_ms": <int>,
                "last_seen_ms": <int>,
            },
            ...
        ]
    }
"""
from __future__ import annotations

import hashlib
import hmac
import json
import secrets
import time
from typing import Optional

from ._config import trusted_devices_path


def _load() -> dict:
    p = trusted_devices_path()
    if not p.exists():
        return {"version": 1, "devices": []}
    try:
        data = json.loads(p.read_text(encoding="utf-8") or "{}")
    except Exception:
        return {"version": 1, "devices": []}
    data.setdefault("version", 1)
    data.setdefault("devices", [])
    return data


def _save(data: dict) -> None:
    p = trusted_devices_path()
    p.write_text(json.dumps(data, indent=2), encoding="utf-8")


def _sha(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def mint_device_token(label: str = "") -> dict:
    """Create a new trusted-device record. Returns {device_id, token,
    label, paired_at_ms}. Caller (the pairing flow) ships the raw token
    to the phone over the encrypted data channel; we keep only the hash."""
    token = secrets.token_urlsafe(32)
    device_id = "dev_" + secrets.token_hex(4)
    now = int(time.time() * 1000)
    rec = {
        "device_id": device_id,
        "token_sha256": _sha(token),
        "label": label or f"device {device_id[-4:]}",
        "paired_at_ms": now,
        "last_seen_ms": now,
    }
    data = _load()
    data["devices"].append(rec)
    _save(data)
    return {
        "device_id": device_id,
        "token": token,
        "label": rec["label"],
        "paired_at_ms": now,
    }


def verify_device_token(token: str) -> Optional[dict]:
    """Constant-time check of a presented raw token against the trusted
    store. Returns the matching device record (without the hash) or None.
    Updates last_seen_ms on hit."""
    if not token:
        return None
    presented = _sha(token)
    data = _load()
    matched = None
    for rec in data["devices"]:
        if hmac.compare_digest(rec.get("token_sha256", ""), presented):
            matched = rec
            break
    if matched is None:
        return None
    matched["last_seen_ms"] = int(time.time() * 1000)
    _save(data)
    return {
        "device_id": matched["device_id"],
        "label": matched.get("label"),
        "paired_at_ms": matched.get("paired_at_ms"),
        "last_seen_ms": matched["last_seen_ms"],
    }


def list_devices() -> list[dict]:
    data = _load()
    return [
        {
            "device_id": r["device_id"],
            "label": r.get("label"),
            "paired_at_ms": r.get("paired_at_ms"),
            "last_seen_ms": r.get("last_seen_ms"),
        }
        for r in data["devices"]
    ]


def revoke_device(device_id: str) -> bool:
    data = _load()
    n = len(data["devices"])
    data["devices"] = [r for r in data["devices"] if r.get("device_id") != device_id]
    if len(data["devices"]) == n:
        return False
    _save(data)
    return True


def clear_all() -> int:
    data = _load()
    n = len(data["devices"])
    data["devices"] = []
    _save(data)
    return n
