# mimari.ai MCP Server

> Turkey's first building regulations MCP server

**147 regulations** | **3,300+ articles** | **502 architectural standards** | **4 calculation tools**

mimari.ai provides AI-powered access to Turkish building regulations, architectural standards, and construction calculation tools through the [Model Context Protocol (MCP)](https://modelcontextprotocol.io).

## Quick Start

### Remote (Recommended)

Add to your MCP client configuration:

```json
{
  "mcpServers": {
    "mimari-ai": {
      "url": "https://api.mimari.ai/mcp"
    }
  }
}
```

### Local (stdio)

```bash
pip install mimari-ai-mcp
```

```json
{
  "mcpServers": {
    "mimari-ai": {
      "command": "python",
      "args": ["server.py"],
      "env": {
        "API_BASE": "https://api.mimari.ai/api/v1"
      }
    }
  }
}
```

### Claude Code

```bash
claude mcp add mimari-ai --url https://api.mimari.ai/mcp
```

## Tools

| Tool | Description | Example |
|------|-------------|---------|
| `mevzuat_sor` | Ask building regulation questions | "Yangın merdiveni zorunlu mu?" |
| `standart_bul` | Find architectural standards & measurements | "Minimum koridor genişliği?" |
| `hesapla_taks` | Calculate TAKS/KAKS/Floor Area Ratio | arsa: 500m², TAKS: 0.40 |
| `hesapla_otopark` | Calculate parking requirements (Art. 66) | 6 daire x 90m² |
| `hesapla_maliyet` | Estimate construction costs (2026 prices) | 5 kat x 200m², Sınıf 2 |
| `hesapla_ceza` | Calculate building violation penalties | 100m², Sınıf 3 |
| `tasarim_olustur` | Generate architectural designs | "Modern villa cephe tasarımı" |

## IDE Support

| IDE | Config File | Status |
|-----|-------------|--------|
| Claude Desktop | `claude_desktop_config.json` | Full support |
| Claude Code | CLI `claude mcp add` | Full support |
| Cursor | `~/.cursor/mcp.json` | Full support |
| Windsurf | `~/.codeium/windsurf/mcp_config.json` | Full support |
| VS Code (Copilot) | `.vscode/mcp.json` | Preview |

## Coverage

### Regulations (147)
- Planlı Alanlar İmar Yönetmeliği (PAİY)
- Deprem Yönetmeliği (TBDY 2018)
- Yangın Yönetmeliği (BYKHY)
- Otopark Yönetmeliği
- Yapı Denetimi Kanunu
- Enerji Verimliliği Yönetmeliği
- and 141 more...

### Standards (502)
- Neufert Building Design Principles
- TSE Standards (TS 825, TS EN 81, etc.)
- Accessibility standards
- Fire protection standards
- Acoustic & thermal insulation

## Example Usage

### Ask a regulation question
```
User: "5 katlı binada yangın merdiveni zorunlu mu?"
mimari-ai: "Evet, Binaların Yangından Korunması Hakkında Yönetmelik'e göre..."
```

### Calculate TAKS/KAKS
```
User: hesapla_taks(arsa_alani=500, taks=0.40, kaks=2.0)
mimari-ai: "Taban Alanı: 200 m², Toplam İnşaat Alanı: 1000 m², Kat Sayısı: 5"
```

### Calculate parking
```
User: hesapla_otopark(daireler=[{m2: 90, adet: 6}, {m2: 130, adet: 2}])
mimari-ai: "Toplam otopark ihtiyacı: 8 araçlık"
```

## Protocol

- **MCP Version:** 2024-11-05
- **Transport:** Streamable HTTP (remote), stdio (local)
- **Endpoint:** `https://api.mimari.ai/mcp`
- **Discovery:** `GET https://api.mimari.ai/.well-known/mcp/server-card.json`

## Links

- Website: [mimari.ai](https://mimari.ai)
- MCP Endpoint: [api.mimari.ai/mcp](https://api.mimari.ai/mcp)
- Smithery: [smithery.ai](https://smithery.ai)
- Glama: [glama.ai](https://glama.ai)
- mcp.so: [mcp.so](https://mcp.so)

## License

MIT
