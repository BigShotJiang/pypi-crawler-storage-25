"""
Hesaplama Servisi — TAKS/KAKS, Otopark, Maliyet, İmar Ceza
Frontend'teki hesaplama mantığının Python karşılığı.
Hem API endpoint'leri hem MCP server tarafından kullanılır.
"""

from typing import Optional

# ══════════════════════════════════════════════════════════
# 1. TAKS / KAKS / EMSAL HESAPLAMA
# ══════════════════════════════════════════════════════════

def hesapla_taks_kaks(
    arsa_alani: float,
    taks: Optional[float] = None,
    kaks: Optional[float] = None,
    kat_sayisi: Optional[int] = None,
) -> dict:
    """
    TAKS/KAKS/Emsal hesaplama.
    En az 2 parametre girilmeli (taks+kaks, taks+kat, kaks+kat).
    """
    if arsa_alani <= 0:
        return {"error": "Arsa alanı 0'dan büyük olmalıdır."}

    # Eksik parametreyi hesapla
    if taks and kaks and not kat_sayisi:
        kat_sayisi = max(1, round(kaks / taks))
    elif taks and kat_sayisi and not kaks:
        kaks = taks * kat_sayisi
    elif kaks and kat_sayisi and not taks:
        taks = kaks / kat_sayisi
    elif taks and kaks and kat_sayisi:
        pass  # hepsi verilmiş
    else:
        return {"error": "En az 2 parametre girilmelidir (taks+kaks, taks+kat veya kaks+kat)."}

    taban_alani = arsa_alani * taks
    emsal_alani = arsa_alani * kaks
    toplam_insaat = emsal_alani * 1.30  # ortak alan dahil
    kat_basina_alan = emsal_alani / kat_sayisi if kat_sayisi > 0 else taban_alani
    kalan_alan = arsa_alani - taban_alani

    return {
        "arsa_alani": arsa_alani,
        "taks": round(taks, 4),
        "kaks": round(kaks, 4),
        "kat_sayisi": kat_sayisi,
        "taban_alani": round(taban_alani, 2),
        "emsal_alani": round(emsal_alani, 2),
        "toplam_insaat_alani": round(toplam_insaat, 2),
        "kat_basina_alan": round(kat_basina_alan, 2),
        "kalan_alan": round(kalan_alan, 2),
        "aciklama": (
            f"{arsa_alani} m² arsada TAKS {taks:.2f}, KAKS {kaks:.2f}, {kat_sayisi} kat. "
            f"Taban alanı: {taban_alani:.0f} m², Emsal alanı: {emsal_alani:.0f} m², "
            f"Toplam inşaat (ortak alan dahil): {toplam_insaat:.0f} m², "
            f"Boş kalan alan (bahçe): {kalan_alan:.0f} m²."
        ),
    }


# ══════════════════════════════════════════════════════════
# 2. OTOPARK HESAPLAMA
# ══════════════════════════════════════════════════════════

MESKEN_RULES = [
    {"min_m2": 0, "max_m2": 80, "daire_per_otopark": 3, "desc": "Her 3 daire için 1 otopark"},
    {"min_m2": 80, "max_m2": 120, "daire_per_otopark": 2, "desc": "Her 2 daire için 1 otopark"},
    {"min_m2": 120, "max_m2": 180, "daire_per_otopark": 1, "desc": "Her daire için 1 otopark"},
    {"min_m2": 180, "max_m2": 9999, "daire_per_otopark": 0.5, "desc": "Her daire için 2 otopark"},
]


def hesapla_otopark(
    daireler: list[dict],
    otopark_m2: int = 25,
) -> dict:
    """
    Otopark ihtiyacı hesaplama.
    daireler: [{"m2": 90, "adet": 6}, {"m2": 140, "adet": 4}]
    """
    toplam_daire = 0
    toplam_otopark = 0
    detaylar = []

    for d in daireler:
        m2 = d.get("m2", 0)
        adet = d.get("adet", 0)
        if adet <= 0:
            continue

        toplam_daire += adet

        # Uygun kuralı bul
        rule = None
        for r in MESKEN_RULES:
            if r["min_m2"] <= m2 < r["max_m2"]:
                rule = r
                break
        if not rule:
            rule = MESKEN_RULES[0]

        if rule["daire_per_otopark"] == 0.5:
            otopark = adet * 2
        else:
            otopark = -(-adet // int(rule["daire_per_otopark"]))  # ceil division

        toplam_otopark += otopark
        detaylar.append({
            "m2": m2,
            "adet": adet,
            "otopark": otopark,
            "kural": rule["desc"],
        })

    toplam_alan = toplam_otopark * otopark_m2

    return {
        "toplam_daire": toplam_daire,
        "toplam_otopark": toplam_otopark,
        "toplam_alan": toplam_alan,
        "otopark_m2": otopark_m2,
        "detaylar": detaylar,
        "aciklama": (
            f"{toplam_daire} daire için {toplam_otopark} araçlık otopark gereklidir. "
            f"Gerekli otopark alanı: {toplam_alan} m² (araç başı {otopark_m2} m², manevra dahil). "
            f"Kaynak: Planlı Alanlar İmar Yönetmeliği Madde 66."
        ),
    }


# ══════════════════════════════════════════════════════════
# 3. İNŞAAT MALİYET HESAPLAMA
# ══════════════════════════════════════════════════════════

KALITE_SEVIYELERI = {
    "sinif3": {"label": "3. Sınıf (Basit)", "birim_fiyat": 8772},
    "sinif2": {"label": "2. Sınıf (Orta)", "birim_fiyat": 13158},
    "sinif1": {"label": "1. Sınıf (Üst)", "birim_fiyat": 17544},
    "luks": {"label": "Lüks Sınıf", "birim_fiyat": 26316},
}

EK_MALIYETLER = {
    "asansor": {"label": "Asansör", "pct": 6},
    "isitma": {"label": "Merkezi Isıtma/Soğutma", "pct": 8},
    "otopark": {"label": "Kapalı Otopark (Bodrum)", "pct": 12},
    "gunes": {"label": "Güneş Enerjisi Sistemi", "pct": 3},
    "jenerator": {"label": "Jeneratör", "pct": 2},
    "havuz": {"label": "Havuz", "pct": 5},
}


def hesapla_maliyet(
    kat_sayisi: int,
    kat_alani: float,
    kalite: str = "sinif2",
    ekler: Optional[list[str]] = None,
) -> dict:
    """
    İnşaat maliyet tahmini.
    kalite: sinif3, sinif2, sinif1, luks
    ekler: ["asansor", "isitma", "otopark", ...]
    """
    if kalite not in KALITE_SEVIYELERI:
        return {"error": f"Geçersiz kalite: {kalite}. Seçenekler: sinif3, sinif2, sinif1, luks"}

    k = KALITE_SEVIYELERI[kalite]
    toplam_m2 = kat_sayisi * kat_alani
    taban_maliyet = toplam_m2 * k["birim_fiyat"]

    ek_maliyet_toplam = 0
    ek_detay = []
    for ek_key in (ekler or []):
        if ek_key in EK_MALIYETLER:
            em = EK_MALIYETLER[ek_key]
            m = round(taban_maliyet * em["pct"] / 100)
            ek_maliyet_toplam += m
            ek_detay.append({"label": em["label"], "maliyet": m})

    toplam_maliyet = taban_maliyet + ek_maliyet_toplam
    kdv = round(toplam_maliyet * 0.20)
    genel_toplam = toplam_maliyet + kdv
    m2_basina = round(toplam_maliyet / toplam_m2) if toplam_m2 > 0 else 0

    def fmt(n):
        return f"{n:,.0f}".replace(",", ".")

    return {
        "toplam_m2": toplam_m2,
        "kalite": k["label"],
        "birim_fiyat": k["birim_fiyat"],
        "taban_maliyet": taban_maliyet,
        "ek_maliyet_toplam": ek_maliyet_toplam,
        "ek_detay": ek_detay,
        "toplam_maliyet": toplam_maliyet,
        "kdv": kdv,
        "genel_toplam": genel_toplam,
        "m2_basina": m2_basina,
        "aciklama": (
            f"{kat_sayisi} kat × {kat_alani:.0f} m² = {toplam_m2:.0f} m² toplam inşaat alanı. "
            f"Kalite: {k['label']}, Birim fiyat: {fmt(k['birim_fiyat'])} TL/m². "
            f"Taban maliyet: {fmt(taban_maliyet)} TL, Ek maliyetler: {fmt(ek_maliyet_toplam)} TL, "
            f"KDV (%20): {fmt(kdv)} TL. "
            f"Genel toplam: {fmt(genel_toplam)} TL. "
            f"Kaynak: 2026 Çevre ve Şehircilik Bakanlığı birim fiyatları."
        ),
    }


# ══════════════════════════════════════════════════════════
# 4. İMAR PARA CEZASI HESAPLAMA
# ══════════════════════════════════════════════════════════

YAPI_SINIFLARI = [
    {"label": "I. Sınıf A Grubu", "fiyat": 79.72},
    {"label": "I. Sınıf B Grubu", "fiyat": 134.26},
    {"label": "II. Sınıf A Grubu", "fiyat": 215.12},
    {"label": "II. Sınıf B Grubu", "fiyat": 296.35},
    {"label": "III. Sınıf A Grubu", "fiyat": 485.38},
    {"label": "III. Sınıf B Grubu", "fiyat": 539.26},
    {"label": "IV. Sınıf A Grubu", "fiyat": 620.14},
    {"label": "IV. Sınıf B Grubu", "fiyat": 674.58},
    {"label": "IV. Sınıf C Grubu", "fiyat": 836.36},
    {"label": "V. Sınıf A Grubu", "fiyat": 1025.37},
    {"label": "V. Sınıf B Grubu", "fiyat": 1241.86},
    {"label": "V. Sınıf C Grubu", "fiyat": 1404.17},
    {"label": "V. Sınıf D Grubu", "fiyat": 1701.10},
]

ARTIRIM_SEBEPLERI = {
    "hisseli": {"label": "Hisseli parselde yapılan", "oran": 0.20},
    "umumi": {"label": "Umumi hizmet alanlarında", "oran": 0.40},
    "mucavir": {"label": "Mücavir alan dışında", "oran": 0.20},
    "sit": {"label": "Sit alanında yapılan", "oran": 0.60},
    "ruhsatsiz": {"label": "Ruhsat alınmadan yapılan", "oran": 0.80},
    "ruhsataykiri": {"label": "Ruhsata aykırı yapılan", "oran": 0.20},
    "tecavuz": {"label": "Komşu parsele tecavüzlü", "oran": 0.30},
    "cevre": {"label": "Çevre ve görüntü kirliliği", "oran": 0.20},
}


def hesapla_imar_ceza(
    alan: float,
    yapi_sinif_index: int,
    artirimlar: Optional[list[str]] = None,
) -> dict:
    """
    İmar Kanunu 42. Madde para cezası hesaplama.
    yapi_sinif_index: 0-12 arası (YAPI_SINIFLARI listesindeki index)
    artirimlar: ["hisseli", "ruhsatsiz", ...] — artırım sebepler
    """
    if alan <= 0:
        return {"error": "İmara aykırı alan 0'dan büyük olmalıdır."}

    if yapi_sinif_index < 0 or yapi_sinif_index >= len(YAPI_SINIFLARI):
        return {"error": f"Geçersiz yapı sınıfı. 0-{len(YAPI_SINIFLARI)-1} arası olmalı."}

    sinif = YAPI_SINIFLARI[yapi_sinif_index]
    temel_ceza = alan * sinif["fiyat"]

    artirim_detay = []
    for key in (artirimlar or []):
        if key in ARTIRIM_SEBEPLERI:
            s = ARTIRIM_SEBEPLERI[key]
            artirim_detay.append({
                "sebep": s["label"],
                "oran": s["oran"],
                "tutar": round(temel_ceza * s["oran"], 2),
            })

    toplam_artirim = sum(a["tutar"] for a in artirim_detay)
    toplam_ceza = temel_ceza + toplam_artirim

    def fmt(n):
        return f"{n:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")

    return {
        "alan": alan,
        "yapi_sinifi": sinif["label"],
        "birim_fiyat": sinif["fiyat"],
        "temel_ceza": round(temel_ceza, 2),
        "artirim_detay": artirim_detay,
        "toplam_artirim": round(toplam_artirim, 2),
        "toplam_ceza": round(toplam_ceza, 2),
        "aciklama": (
            f"{alan} m² imara aykırı alan, {sinif['label']} ({sinif['fiyat']} TL/m²). "
            f"Temel ceza: {fmt(temel_ceza)} TL. "
            + (f"Artırımlar: {fmt(toplam_artirim)} TL. " if toplam_artirim > 0 else "")
            + f"Toplam ceza: {fmt(toplam_ceza)} TL. "
            f"Kaynak: 3194 sayılı İmar Kanunu, 42. Madde (2026 birim fiyatları)."
        ),
        "yapi_siniflari_listesi": [s["label"] for s in YAPI_SINIFLARI],
        "artirim_secenekleri": list(ARTIRIM_SEBEPLERI.keys()),
    }
