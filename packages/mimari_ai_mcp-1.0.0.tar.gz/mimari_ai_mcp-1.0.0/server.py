"""
mimari.ai MCP Server
Turkey Building Regulations & Architectural Standards

7 tool: mevzuat_sor, standart_bul, hesapla_taks, hesapla_otopark,
        hesapla_maliyet, hesapla_ceza, tasarim_olustur

Transport: Streamable HTTP (production), stdio (local dev)
"""

import os
import sys
import json
import httpx
from typing import Optional

# FastMCP import
try:
    from mcp.server.fastmcp import FastMCP
except ImportError:
    print("MCP SDK not installed. Run: pip install 'mcp[cli]'")
    sys.exit(1)

# Hesaplama servisi — doğrudan import (aynı process içinde)
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))
from app.services.hesaplama_service import (
    hesapla_taks_kaks,
    hesapla_otopark as _hesapla_otopark,
    hesapla_maliyet as _hesapla_maliyet,
    hesapla_imar_ceza,
)

# ── Config ──
API_BASE = os.getenv("API_BASE", "https://mimari.ai/api/v1")

mcp = FastMCP(
    "mimari.ai",
    description=(
        "Türkiye Yapı Mevzuatı ve Mimari Standartlar Asistanı. "
        "147 yönetmelik, 502 standart, 3300+ madde, 2000+ wiki sayfası. "
        "TAKS/KAKS, otopark, maliyet ve imar ceza hesaplama araçları."
    ),
    version="1.0.0",
)


# ══════════════════════════════════════════════════════════
# TOOL 1: Yönetmelik Sorusu
# ══════════════════════════════════════════════════════════

@mcp.tool()
async def mevzuat_sor(soru: str) -> str:
    """
    Türkiye yapı mevzuatı hakkında soru sorun.
    147 yönetmelik, 346 wiki sayfası ve 3300+ madde içinde arama yapar.

    Örnek sorular:
    - "Asansör kaçıncı kattan zorunlu?"
    - "Yangın merdiveni genişliği ne olmalı?"
    - "Çatı katı yapılabilir mi?"
    - "İmar planı değişikliği nasıl yapılır?"
    """
    async with httpx.AsyncClient(timeout=60) as client:
        try:
            resp = await client.post(
                f"{API_BASE}/ask",
                json={"question": soru, "mode": "regulation"},
            )
            data = resp.json()
            return data.get("answer", "Cevap alınamadı.")
        except Exception as e:
            return f"Hata: {str(e)}. Lütfen https://mimari.ai adresinden deneyin."


# ══════════════════════════════════════════════════════════
# TOOL 2: Standart Bilgisi
# ══════════════════════════════════════════════════════════

@mcp.tool()
async def standart_bul(soru: str) -> str:
    """
    Mimari standartlar ve ölçü bilgisi arayın.
    502 standart sayfası: Neufert, Planlı Alanlar İmar Yönetmeliği, TSE standartları.

    Örnek sorular:
    - "Mutfak tezgah yüksekliği kaç cm?"
    - "Merdiven basamak ölçüleri nedir?"
    - "Banyo minimum ölçüleri?"
    - "Engelli rampa eğimi ne olmalı?"
    """
    async with httpx.AsyncClient(timeout=60) as client:
        try:
            resp = await client.post(
                f"{API_BASE}/ask",
                json={"question": soru, "mode": "standartlar"},
            )
            data = resp.json()
            return data.get("answer", "Cevap alınamadı.")
        except Exception as e:
            return f"Hata: {str(e)}. Lütfen https://mimari.ai adresinden deneyin."


# ══════════════════════════════════════════════════════════
# TOOL 3: TAKS/KAKS Hesaplama
# ══════════════════════════════════════════════════════════

@mcp.tool()
def hesapla_taks(
    arsa_alani: float,
    taks: Optional[float] = None,
    kaks: Optional[float] = None,
    kat_sayisi: Optional[int] = None,
) -> str:
    """
    TAKS/KAKS/Emsal hesaplama aracı.
    En az 2 parametre girin: taks+kaks, taks+kat_sayisi veya kaks+kat_sayisi.

    Parametreler:
    - arsa_alani: Arsa alanı (m²)
    - taks: Taban Alanı Kat Sayısı (0-1 arası, ör: 0.40)
    - kaks: Kat Alanı Kat Sayısı / Emsal (ör: 2.00)
    - kat_sayisi: Kat sayısı (ör: 5)

    Örnek: arsa_alani=500, taks=0.40, kat_sayisi=5
    """
    result = hesapla_taks_kaks(arsa_alani, taks, kaks, kat_sayisi)
    if "error" in result:
        return result["error"]
    return result["aciklama"]


# ══════════════════════════════════════════════════════════
# TOOL 4: Otopark Hesaplama
# ══════════════════════════════════════════════════════════

@mcp.tool()
def hesapla_otopark(
    daireler_json: str,
    otopark_m2: int = 25,
) -> str:
    """
    Otopark ihtiyacı hesaplama (İmar Yönetmeliği Madde 66).

    Parametreler:
    - daireler_json: JSON formatında daire listesi, ör: [{"m2": 90, "adet": 6}, {"m2": 140, "adet": 4}]
    - otopark_m2: Araç başı m² (varsayılan 25, manevra dahil)

    Kurallar:
    - 80 m² altı: Her 3 daire için 1 otopark
    - 80-120 m²: Her 2 daire için 1 otopark
    - 120-180 m²: Her daire için 1 otopark
    - 180 m² üzeri: Her daire için 2 otopark
    """
    try:
        daireler = json.loads(daireler_json)
    except json.JSONDecodeError:
        return "Hatalı JSON formatı. Örnek: [{\"m2\": 90, \"adet\": 6}]"

    result = _hesapla_otopark(daireler, otopark_m2)
    return result["aciklama"]


# ══════════════════════════════════════════════════════════
# TOOL 5: İnşaat Maliyet Hesaplama
# ══════════════════════════════════════════════════════════

@mcp.tool()
def hesapla_maliyet(
    kat_sayisi: int,
    kat_alani: float,
    kalite: str = "sinif2",
    ekler: Optional[str] = None,
) -> str:
    """
    İnşaat maliyet tahmini (2026 Bakanlık birim fiyatları).

    Parametreler:
    - kat_sayisi: Kat sayısı (ör: 5)
    - kat_alani: Kat başına alan m² (ör: 200)
    - kalite: sinif3 (Basit), sinif2 (Orta), sinif1 (Üst), luks (Lüks)
    - ekler: Virgülle ayrılmış ek maliyetler: asansor, isitma, otopark, gunes, jenerator, havuz

    Örnek: kat_sayisi=5, kat_alani=200, kalite="sinif2", ekler="asansor,isitma"
    """
    ek_list = [e.strip() for e in ekler.split(",")] if ekler else []
    result = _hesapla_maliyet(kat_sayisi, kat_alani, kalite, ek_list)
    if "error" in result:
        return result["error"]
    return result["aciklama"]


# ══════════════════════════════════════════════════════════
# TOOL 6: İmar Para Cezası
# ══════════════════════════════════════════════════════════

@mcp.tool()
def hesapla_ceza(
    alan: float,
    yapi_sinif_index: int,
    artirimlar: Optional[str] = None,
) -> str:
    """
    İmar Kanunu 42. Madde para cezası hesaplama (2026 birim fiyatları).

    Parametreler:
    - alan: İmara aykırı alan (m²)
    - yapi_sinif_index: Yapı sınıfı (0-12 arası)
      0: I.A (79.72 TL), 1: I.B (134.26 TL), 2: II.A (215.12 TL),
      3: II.B (296.35 TL), 4: III.A (485.38 TL), 5: III.B (539.26 TL),
      6: IV.A (620.14 TL), 7: IV.B (674.58 TL), 8: IV.C (836.36 TL),
      9: V.A (1025.37 TL), 10: V.B (1241.86 TL), 11: V.C (1404.17 TL),
      12: V.D (1701.10 TL)
    - artirimlar: Virgülle ayrılmış artırım sebepleri:
      hisseli, umumi, mucavir, sit, ruhsatsiz, ruhsataykiri, tecavuz, cevre
    """
    art_list = [a.strip() for a in artirimlar.split(",")] if artirimlar else []
    result = hesapla_imar_ceza(alan, yapi_sinif_index, art_list)
    if "error" in result:
        return result["error"]
    return result["aciklama"]


# ══════════════════════════════════════════════════════════
# TOOL 7: Tasarım Oluştur
# ══════════════════════════════════════════════════════════

@mcp.tool()
def tasarim_olustur(prompt: str) -> str:
    """
    AI ile mimari tasarım oluşturma.
    Bu araç mimari.ai'ın Tasarım.ai moduna yönlendirir.

    Parametreler:
    - prompt: Tasarım açıklaması (ör: "Modern 3 katlı villa tasarla")

    Not: Görsel üretim sadece mimari.ai web sitesinde yapılır.
    """
    from urllib.parse import quote
    encoded = quote(prompt)
    return (
        f"Mimari tasarım oluşturmak için mimari.ai'ın Tasarım.ai modunu kullanın:\n\n"
        f"https://mimari.ai/?mode=design&q={encoded}\n\n"
        f"Tasarım.ai, yapay zeka ile mimari görseller üretir. "
        f"Prompt'unuz: \"{prompt}\""
    )


# ── Resources ──

@mcp.resource("mimari://info")
def get_info() -> str:
    """mimari.ai hakkında bilgi."""
    return (
        "mimari.ai — Türkiye'nin Yapı Mevzuatı ve Mimari Standartlar Asistanı\n\n"
        "3 Mod:\n"
        "- Yönetmelik.ai: 147 yönetmelik, 346 wiki, 3300+ madde\n"
        "- Standartlar.ai: 502 standart sayfası (Neufert, TSE, PAIY)\n"
        "- Tasarım.ai: AI ile mimari görsel üretimi\n\n"
        "4 Hesaplama Aracı:\n"
        "- TAKS/KAKS/Emsal Hesaplama\n"
        "- Otopark İhtiyacı Hesaplama\n"
        "- İnşaat Maliyet Tahmini\n"
        "- İmar Para Cezası Hesaplama\n\n"
        "Web: https://mimari.ai\n"
        "Instagram: @mmimari.ai"
    )


# ── Standalone çalıştırma ──

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--transport", default="stdio", choices=["stdio", "streamable-http", "sse"])
    parser.add_argument("--port", type=int, default=8001)
    args = parser.parse_args()

    if args.transport == "stdio":
        mcp.run(transport="stdio")
    else:
        mcp.run(transport=args.transport, port=args.port)
