"""
MCP Endpoint — JSON-RPC over HTTP
SDK bağımlılığı olmadan çalışan basit MCP protokol implementasyonu.
Smithery.ai, Claude Desktop (remote), Cursor (remote) için.
"""

import json
import logging
import httpx
from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse

from app.services.hesaplama_service import (
    hesapla_taks_kaks,
    hesapla_otopark,
    hesapla_maliyet,
    hesapla_imar_ceza,
)

logger = logging.getLogger(__name__)
router = APIRouter()

API_BASE = "https://api.mimari.ai/api/v1"

# ── Tool tanımları ──
TOOLS = [
    {
        "name": "mevzuat_sor",
        "description": "Türkiye yapı mevzuatı hakkında soru sorun. 147 yönetmelik, 346 wiki sayfası ve 3300+ madde içinde arama yapar.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "soru": {"type": "string", "description": "Yönetmelik sorusu"}
            },
            "required": ["soru"],
        },
    },
    {
        "name": "standart_bul",
        "description": "Mimari standartlar ve ölçü bilgisi arayın. 502 standart sayfası: Neufert, TSE, Planlı Alanlar İmar Yönetmeliği.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "soru": {"type": "string", "description": "Standart/ölçü sorusu"}
            },
            "required": ["soru"],
        },
    },
    {
        "name": "hesapla_taks",
        "description": "TAKS/KAKS/Emsal hesaplama. En az 2 parametre girin: taks+kaks, taks+kat_sayisi veya kaks+kat_sayisi.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "arsa_alani": {"type": "number", "description": "Arsa alanı (m²)"},
                "taks": {"type": "number", "description": "TAKS (0-1)"},
                "kaks": {"type": "number", "description": "KAKS / Emsal"},
                "kat_sayisi": {"type": "integer", "description": "Kat sayısı"},
            },
            "required": ["arsa_alani"],
        },
    },
    {
        "name": "hesapla_otopark",
        "description": "Otopark ihtiyacı hesaplama (İmar Yönetmeliği Madde 66).",
        "inputSchema": {
            "type": "object",
            "properties": {
                "daireler": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "m2": {"type": "number"},
                            "adet": {"type": "integer"},
                        },
                    },
                    "description": "Daire grupları [{m2: 90, adet: 6}]",
                },
            },
            "required": ["daireler"],
        },
    },
    {
        "name": "hesapla_maliyet",
        "description": "İnşaat maliyet tahmini (2026 Bakanlık birim fiyatları).",
        "inputSchema": {
            "type": "object",
            "properties": {
                "kat_sayisi": {"type": "integer", "description": "Kat sayısı"},
                "kat_alani": {"type": "number", "description": "Kat başına alan (m²)"},
                "kalite": {"type": "string", "description": "sinif3, sinif2, sinif1, luks"},
                "ekler": {"type": "array", "items": {"type": "string"}, "description": "asansor, isitma, otopark, gunes, jenerator, havuz"},
            },
            "required": ["kat_sayisi", "kat_alani"],
        },
    },
    {
        "name": "hesapla_ceza",
        "description": "İmar Kanunu 42. Madde para cezası hesaplama (2026 birim fiyatları).",
        "inputSchema": {
            "type": "object",
            "properties": {
                "alan": {"type": "number", "description": "İmara aykırı alan (m²)"},
                "yapi_sinif_index": {"type": "integer", "description": "Yapı sınıfı (0-12)"},
                "artirimlar": {"type": "array", "items": {"type": "string"}, "description": "hisseli, umumi, mucavir, sit, ruhsatsiz, ruhsataykiri, tecavuz, cevre"},
            },
            "required": ["alan", "yapi_sinif_index"],
        },
    },
    {
        "name": "tasarim_olustur",
        "description": "AI ile mimari tasarım oluşturma. mimari.ai Tasarım moduna yönlendirir.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "prompt": {"type": "string", "description": "Tasarım açıklaması"},
            },
            "required": ["prompt"],
        },
    },
]

SERVER_INFO = {
    "name": "mimari-ai",
    "version": "1.0.0",
    "protocolVersion": "2024-11-05",
}

SERVER_CAPABILITIES = {
    "tools": {"listChanged": False},
}


# ── Tool çalıştırma ──

async def execute_tool(name: str, arguments: dict) -> str:
    """Tool'u çalıştır, sonucu string olarak döndür."""

    if name == "mevzuat_sor":
        async with httpx.AsyncClient(timeout=60) as client:
            try:
                resp = await client.post(
                    f"{API_BASE}/ask",
                    json={"question": arguments["soru"], "mode": "regulation"},
                )
                data = resp.json()
                return data.get("answer", "Cevap alınamadı.")
            except Exception as e:
                return f"Hata: {str(e)}"

    elif name == "standart_bul":
        async with httpx.AsyncClient(timeout=60) as client:
            try:
                resp = await client.post(
                    f"{API_BASE}/ask",
                    json={"question": arguments["soru"], "mode": "standartlar"},
                )
                data = resp.json()
                return data.get("answer", "Cevap alınamadı.")
            except Exception as e:
                return f"Hata: {str(e)}"

    elif name == "hesapla_taks":
        result = hesapla_taks_kaks(
            arsa_alani=arguments["arsa_alani"],
            taks=arguments.get("taks"),
            kaks=arguments.get("kaks"),
            kat_sayisi=arguments.get("kat_sayisi"),
        )
        return result.get("aciklama", result.get("error", "Hesaplama hatası."))

    elif name == "hesapla_otopark":
        result = hesapla_otopark(
            daireler=arguments["daireler"],
        )
        return result["aciklama"]

    elif name == "hesapla_maliyet":
        result = hesapla_maliyet(
            kat_sayisi=arguments["kat_sayisi"],
            kat_alani=arguments["kat_alani"],
            kalite=arguments.get("kalite", "sinif2"),
            ekler=arguments.get("ekler"),
        )
        return result.get("aciklama", result.get("error", "Hesaplama hatası."))

    elif name == "hesapla_ceza":
        result = hesapla_imar_ceza(
            alan=arguments["alan"],
            yapi_sinif_index=arguments["yapi_sinif_index"],
            artirimlar=arguments.get("artirimlar"),
        )
        return result.get("aciklama", result.get("error", "Hesaplama hatası."))

    elif name == "tasarim_olustur":
        from urllib.parse import quote
        prompt = arguments["prompt"]
        encoded = quote(prompt)
        return (
            f"Mimari tasarım oluşturmak için mimari.ai'ın Tasarım.ai modunu kullanın:\n\n"
            f"https://mimari.ai/?mode=design&q={encoded}\n\n"
            f"Prompt: \"{prompt}\""
        )

    return f"Bilinmeyen tool: {name}"


# ── MCP JSON-RPC Endpoint ──

@router.post("/mcp")
async def mcp_endpoint(request: Request):
    """MCP JSON-RPC endpoint — Smithery, Claude Desktop, Cursor remote için."""
    try:
        body = await request.json()
    except Exception:
        return JSONResponse({"jsonrpc": "2.0", "error": {"code": -32700, "message": "Parse error"}, "id": None})

    method = body.get("method", "")
    params = body.get("params", {})
    req_id = body.get("id")

    # initialize
    if method == "initialize":
        return JSONResponse({
            "jsonrpc": "2.0",
            "id": req_id,
            "result": {
                "protocolVersion": SERVER_INFO["protocolVersion"],
                "serverInfo": {"name": SERVER_INFO["name"], "version": SERVER_INFO["version"]},
                "capabilities": SERVER_CAPABILITIES,
            },
        })

    # notifications (no response needed, but respond anyway for HTTP)
    if method == "notifications/initialized":
        return JSONResponse({"jsonrpc": "2.0", "id": req_id, "result": {}})

    # tools/list
    if method == "tools/list":
        return JSONResponse({
            "jsonrpc": "2.0",
            "id": req_id,
            "result": {"tools": TOOLS},
        })

    # tools/call
    if method == "tools/call":
        tool_name = params.get("name", "")
        arguments = params.get("arguments", {})
        try:
            result_text = await execute_tool(tool_name, arguments)
            return JSONResponse({
                "jsonrpc": "2.0",
                "id": req_id,
                "result": {
                    "content": [{"type": "text", "text": result_text}],
                },
            })
        except Exception as e:
            logger.error(f"MCP tool error: {tool_name} — {e}")
            return JSONResponse({
                "jsonrpc": "2.0",
                "id": req_id,
                "result": {
                    "content": [{"type": "text", "text": f"Hata: {str(e)}"}],
                    "isError": True,
                },
            })

    # unknown method
    return JSONResponse({
        "jsonrpc": "2.0",
        "id": req_id,
        "error": {"code": -32601, "message": f"Method not found: {method}"},
    })


# ── Well-known MCP discovery ──

@router.get("/mcp")
async def mcp_discovery():
    """MCP server discovery — GET /mcp."""
    return JSONResponse({
        "name": SERVER_INFO["name"],
        "version": SERVER_INFO["version"],
        "protocolVersion": SERVER_INFO["protocolVersion"],
        "capabilities": SERVER_CAPABILITIES,
        "tools": [{"name": t["name"], "description": t["description"]} for t in TOOLS],
    })


@router.get("/.well-known/mcp/server-card.json")
async def mcp_server_card():
    """MCP Server Card — otomatik keşif için."""
    return JSONResponse({
        "name": "mimari-ai",
        "description": "Türkiye Yapı Mevzuatı ve Mimari Standartlar Asistanı",
        "version": "1.0.0",
        "url": "https://api.mimari.ai/mcp",
        "transport": "streamable-http",
        "tools": [{"name": t["name"], "description": t["description"]} for t in TOOLS],
    })
