"""
Checkup command — GitHub issue-driven project health check, or local diagnostics.
"""
import click
from pathlib import Path
from typing import Optional, Tuple

from ..agentic_change import _parse_pr_url
from ..agentic_checkup import run_agentic_checkup
from ..agentic_sync import _is_github_issue_url
from ..track_cost import track_cost
from ..core.errors import handle_error


@click.command("checkup")
@click.argument("target", required=False, default=None)
@click.option(
    "--validate-arch-includes",
    "validate_arch_includes",
    is_flag=True,
    default=False,
    help="Cross-check architecture.json against module <include> tags (no GitHub issue).",
)
@click.option(
    "--project-root",
    "project_root",
    type=click.Path(exists=True, path_type=Path, file_okay=False),
    default=None,
    help="With --validate-arch-includes: directory to scan (default: current directory).",
)
@click.option(
    "--strict",
    is_flag=True,
    default=False,
    help="With --validate-arch-includes: also validate bundled sample trees (examples/, …).",
)
@click.option(
    "--no-fix",
    is_flag=True,
    default=False,
    help="Report only, don't apply fixes.",
)
@click.option(
    "--timeout-adder",
    type=float,
    default=0.0,
    help="Additional seconds to add to each step's timeout.",
)
@click.option(
    "--start-step",
    "start_step",
    type=click.Choice(["1", "2", "3", "4", "5", "6.1", "6.2", "6.3", "7", "8"]),
    default=None,
    help="Recovery override: start the legacy checkup workflow from this step.",
)
@click.option(
    "--no-github-state",
    is_flag=True,
    default=False,
    help="Disable GitHub state persistence.",
)
@click.option(
    "--pr",
    "pr_url",
    type=str,
    default=None,
    help=(
        "PR-mode: run the full checkup against this existing pull request "
        "instead of creating a new one. Unless --no-fix is set, eligible "
        "generated fixes are committed and pushed back to the PR head ref. "
        "Requires --issue. TARGET must NOT be passed."
    ),
)
@click.option(
    "--issue",
    "issue_url_opt",
    type=str,
    default=None,
    help=(
        "PR-mode companion to --pr: the original GitHub issue the PR is meant to "
        "resolve. Used as issue context for verification."
    ),
)
@click.option(
    "--test-scope",
    "test_scope",
    type=click.Choice(["full", "targeted"]),
    default="full",
    show_default=True,
    help=(
        "PR-mode test scope. 'full' (default) runs the full discovered "
        "test suite in Step 5 and Step 7. 'targeted' is an opt-in fast "
        "path that passes PR changed-file context into Steps 5/7 so the "
        "agent runs PR-scoped tests only; the final report explicitly "
        "labels verification as targeted (full suite not run). Only "
        "meaningful with --pr."
    ),
)
@click.option(
    "--review-loop",
    is_flag=True,
    default=False,
    help="In PR mode, run the primary-reviewer/fixer loop before returning a verdict.",
)
@click.option(
    "--review-only",
    is_flag=True,
    default=False,
    help=(
        "With --review-loop, run only the primary reviewer first pass and do "
        "not invoke the fixer, commit, or push."
    ),
)
@click.option(
    "--reviewers",
    type=str,
    default="codex,claude",
    show_default=True,
    help="Legacy comma-separated role order for --review-loop: reviewer,fixer.",
)
@click.option(
    "--reviewer",
    type=str,
    default=None,
    show_default=False,
    help="Primary reviewer role for --review-loop. Overrides the first --reviewers role.",
)
@click.option(
    "--fixer",
    type=str,
    default=None,
    show_default=False,
    help="Fixer role for --review-loop. Overrides the second --reviewers role.",
)
@click.option(
    "--reviewer-fallback",
    type=str,
    default=None,
    show_default=False,
    help=(
        "Optional secondary reviewer role to invoke once if the primary reviewer "
        "fails (auth/network/exec/sandbox/rate-limit). Must differ from --reviewer "
        "and --fixer."
    ),
)
@click.option(
    "--fixer-fallback",
    type=str,
    default=None,
    show_default=False,
    help=(
        "Optional secondary fixer role to invoke once if the primary fixer "
        "cannot address the reviewer's findings (e.g. a subscription-tier "
        "credential exhaustion such as Claude Code 'You've hit your limit "
        "· resets …'). Must differ from --fixer and --reviewer to preserve "
        "reviewer/fixer role independence."
    ),
)
@click.option(
    "--max-review-rounds",
    type=int,
    default=5,
    show_default=True,
    help="Maximum primary-reviewer/fixer rounds.",
)
@click.option(
    "--max-review-cost",
    type=float,
    default=50.0,
    show_default=True,
    help="Maximum review-loop LLM cost in USD.",
)
@click.option(
    "--max-review-minutes",
    type=float,
    default=90.0,
    show_default=True,
    help="Maximum wall-clock minutes for the review loop.",
)
@click.option(
    "--require-all-reviewers-clean/--no-require-all-reviewers-clean",
    default=True,
    show_default=True,
    help="Compatibility flag; the primary reviewer is the authoritative ship gate.",
)
@click.option(
    "--continue-on-reviewer-limit",
    is_flag=True,
    default=False,
    help=(
        "Report provider/rate/context-limit/auth/network/sandbox reviewer "
        "failures as degraded instead of failed. This never marks an active "
        "reviewer clean or continues mutation without a completed review."
    ),
)
@click.option(
    "--require-final-fresh-review/--no-require-final-fresh-review",
    default=True,
    show_default=True,
    help="Compatibility flag; the primary reviewer's clean verification is final.",
)
@click.option(
    "--blocking-severities",
    type=str,
    default=None,
    show_default=False,
    help=(
        "Comma-separated highest-priority severities for review-loop reporting "
        "and prompt guidance. The fixer still receives every valid reviewer "
        "finding. Default: blocker,critical,medium. Unknown severities are dropped."
    ),
)
@click.option(
    "--clean-reviewer-states",
    type=str,
    default=None,
    show_default=False,
    help=(
        "Compatibility parser for downstream reviewer-status gates. Default: "
        "clean. The tokens 'failed', 'degraded', and 'missing' are always "
        "treated as not-clean regardless of this flag."
    ),
)
@click.option(
    "--fallback-reviewer-on-failure",
    is_flag=True,
    default=False,
    help=(
        "Opt-in. When the primary reviewer ends in 'failed' or 'missing' "
        "on the initial review pass of a round, run a second review pass "
        "using the configured fixer's identity as a fallback reviewer. "
        "On a clean fallback the rendered reviewer-status line shows the "
        "primary as clean so downstream verdict adapters do not short-"
        "circuit on the primary's outage; the original failure detail "
        "is preserved in the Reviewer Diagnostics block of the final "
        "report. NOTE: 'degraded' is intentionally NOT promoted — "
        "degraded means reduced quality (rate limit, context window, "
        "etc.) and must not silently lose signal. The fallback also does "
        "NOT trigger on the post-fix verification pass: the fixer just "
        "authored the changes being verified, so promoting it to "
        "verifier would collapse the reviewer/fixer independence."
    ),
)
@click.pass_context
@track_cost
def checkup(
    ctx: click.Context,
    target: Optional[str],
    validate_arch_includes: bool,
    project_root: Optional[Path],
    strict: bool,
    no_fix: bool,
    timeout_adder: float,
    start_step: Optional[str],
    no_github_state: bool,
    pr_url: Optional[str],
    issue_url_opt: Optional[str],
    test_scope: str,
    review_loop: bool,
    review_only: bool,
    reviewers: str,
    reviewer: Optional[str],
    fixer: Optional[str],
    reviewer_fallback: Optional[str],
    fixer_fallback: Optional[str],
    max_review_rounds: int,
    max_review_cost: float,
    max_review_minutes: float,
    require_all_reviewers_clean: bool,
    continue_on_reviewer_limit: bool,
    require_final_fresh_review: bool,
    blocking_severities: Optional[str],
    clean_reviewer_states: Optional[str],
    fallback_reviewer_on_failure: bool,
) -> Optional[Tuple[str, float, str]]:
    """
    Run agentic health checkup from a GitHub issue, or local diagnostics.

    \b
    GitHub mode (default): TARGET is an issue URL.
    PR mode: pass --pr <pr-url> and --issue <issue-url> to run the full
             checkup against an existing PR. Unless --no-fix is set, the
             fix/verify loop runs against the PR worktree and any eligible
             generated fixes are committed and pushed back to the PR head
             ref. Step 8 (create PR) is skipped — no second PR is opened.
    Local mode: pass --validate-arch-includes (no TARGET) to cross-validate
    architecture.json entries against module prompt <include> tags.
    """
    ctx.ensure_object(dict)

    if validate_arch_includes:
        if target is not None or pr_url is not None or issue_url_opt is not None:
            raise click.BadParameter(
                "Do not pass TARGET, --pr, or --issue when using --validate-arch-includes.",
                param_hint="'TARGET'",
            )
        root = project_root if project_root is not None else Path.cwd()
        from ..architecture_include_validation import run_validate_arch_includes_cli

        run_validate_arch_includes_cli(root, strict=strict, quiet=ctx.obj.get("quiet", False))
        return "validate-arch-includes: ok", 0.0, ""

    # PR-mode argument validation
    pr_mode = pr_url is not None or issue_url_opt is not None
    if test_scope == "targeted" and not pr_mode:
        raise click.BadParameter(
            "--test-scope targeted requires --pr (PR mode).",
            param_hint="'--test-scope'",
        )
    if review_loop and not pr_mode:
        raise click.BadParameter(
            "--review-loop requires --pr and --issue.",
            param_hint="'--review-loop'",
        )
    if review_loop and start_step is not None:
        raise click.BadParameter(
            "--start-step applies to the legacy checkup workflow, not --review-loop.",
            param_hint="'--start-step'",
        )
    if review_only and not review_loop:
        raise click.BadParameter(
            "--review-only requires --review-loop.",
            param_hint="'--review-only'",
        )
    if review_loop and no_fix and not review_only:
        raise click.BadParameter(
            "--review-loop cannot be combined with --no-fix; the loop owns the fixer step.",
            param_hint="'--review-loop'",
        )
    if review_loop and max_review_rounds < 1:
        raise click.BadParameter(
            "--max-review-rounds must be >= 1.",
            param_hint="'--max-review-rounds'",
        )
    if review_loop and max_review_cost <= 0:
        raise click.BadParameter(
            "--max-review-cost must be > 0.",
            param_hint="'--max-review-cost'",
        )
    if review_loop and max_review_minutes <= 0:
        raise click.BadParameter(
            "--max-review-minutes must be > 0.",
            param_hint="'--max-review-minutes'",
        )
    if pr_mode:
        if target is not None:
            raise click.BadParameter(
                "Do not pass TARGET when using --pr/--issue; they are mutually exclusive.",
                param_hint="'TARGET'",
            )
        if pr_url is None or issue_url_opt is None:
            raise click.BadParameter(
                "--pr and --issue must both be provided in PR mode.",
                param_hint="'--pr/--issue'",
            )
        if _parse_pr_url(pr_url) is None:
            raise click.BadParameter(
                "--pr must be a GitHub pull-request URL "
                "(e.g., https://github.com/org/repo/pull/123).",
                param_hint="'--pr'",
            )
        if not _is_github_issue_url(issue_url_opt):
            raise click.BadParameter(
                "--issue must be a GitHub issue URL "
                "(e.g., https://github.com/org/repo/issues/123).",
                param_hint="'--issue'",
            )
        effective_issue_url = issue_url_opt
    else:
        if not target:
            raise click.UsageError(
                "Missing argument 'TARGET'. For local checks use "
                "`pdd checkup --validate-arch-includes`. For PR verification use "
                "`pdd checkup --pr <pr-url> --issue <issue-url>`."
            )

        if not _is_github_issue_url(target):
            raise click.BadParameter(
                "TARGET must be a GitHub issue URL "
                "(e.g., https://github.com/org/repo/issues/123), "
                "or use --pr/--issue for PR verification, "
                "or --validate-arch-includes for architecture / include validation.",
                param_hint="'TARGET'",
            )
        effective_issue_url = target

    quiet = ctx.obj.get("quiet", False)
    verbose = ctx.obj.get("verbose", False)
    start_step_override = None
    if start_step is not None:
        start_step_override = float(start_step)
        if start_step_override.is_integer():
            start_step_override = int(start_step_override)

    try:
        success, message, cost, model = run_agentic_checkup(
            issue_url=effective_issue_url,
            verbose=verbose,
            quiet=quiet,
            no_fix=no_fix,
            timeout_adder=timeout_adder,
            use_github_state=not no_github_state,
            reasoning_time=ctx.obj.get("time") if ctx.obj.get("time_explicit") else None,
            pr_url=pr_url,
            test_scope=test_scope,
            start_step_override=start_step_override,
            review_loop=review_loop,
            review_only=review_only,
            reviewers=reviewers,
            reviewer=reviewer,
            fixer=fixer,
            reviewer_fallback=reviewer_fallback,
            fixer_fallback=fixer_fallback,
            max_review_rounds=max_review_rounds,
            max_review_cost=max_review_cost,
            max_review_minutes=max_review_minutes,
            require_all_reviewers_clean=require_all_reviewers_clean,
            continue_on_reviewer_limit=continue_on_reviewer_limit,
            require_final_fresh_review=require_final_fresh_review,
            blocking_severities=blocking_severities,
            clean_reviewer_states=clean_reviewer_states,
            fallback_reviewer_on_failure=fallback_reviewer_on_failure,
        )

        if not quiet:
            status = "Success" if success else "Failed"
            click.echo(f"Status: {status}")
            click.echo(f"Message: {message}")
            click.echo(f"Cost: ${cost:.4f}")
            click.echo(f"Model: {model}")

        if not success:
            raise click.exceptions.Exit(1)

        return message, cost, model

    except (click.Abort, click.exceptions.Exit):
        raise
    except Exception as exception:
        handle_error(exception, "checkup", ctx.obj.get("quiet", False))
        return None
