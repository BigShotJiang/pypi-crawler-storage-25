from __future__ import annotations

import glob
import hashlib
import io
import csv
import os
import subprocess
import json
from typing import Optional, List, Dict, Tuple, Callable
from pydantic import BaseModel, Field
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn

# Internal imports based on package structure
from .llm_invoke import llm_invoke
from .load_prompt_template import load_prompt_template
from . import DEFAULT_TIME

console = Console()

# Binary extensions that can't be meaningfully summarized
BINARY_EXTENSIONS = {
    '.png', '.jpg', '.jpeg', '.gif', '.ico', '.webp', '.svg', '.bmp',
    '.mp4', '.webm', '.mov', '.avi', '.mp3', '.wav', '.ogg',
    '.zip', '.tar', '.gz', '.rar', '.7z',
    '.woff', '.woff2', '.ttf', '.eot', '.otf',
    '.pdf', '.exe', '.dll', '.so', '.dylib',
    '.pyc', '.pyo',  # Python bytecode
}


def _get_project_root(directory_path: str) -> Optional[str]:
    """Return the project root for *directory_path*, or None.

    Uses the shared marker-walking logic from path_resolution, which
    recognises .git, .pddrc, pyproject.toml, data/, and .env.
    """
    from .path_resolution import find_project_root_from_path
    return find_project_root_from_path(directory_path)


def _get_files_from_git(directory_path: str) -> Optional[List[str]]:
    """Get tracked files using git ls-files (respects .gitignore)."""
    try:
        abs_path = os.path.abspath(directory_path)

        # Determine the working directory and relative path for git
        if os.path.isdir(abs_path):
            cwd = abs_path
            git_path = '.'
        else:
            cwd = os.path.dirname(abs_path)
            git_path = os.path.basename(abs_path)

        result = subprocess.run(
            ['git', 'ls-files', git_path],
            capture_output=True,
            text=True,
            check=True,
            cwd=cwd,
            timeout=30
        )
        files = [f for f in result.stdout.strip().split('\n') if f]
        # Convert to absolute paths
        return [os.path.join(cwd, f) for f in files]
    except (subprocess.CalledProcessError, subprocess.TimeoutExpired, FileNotFoundError):
        return None  # Not a git repo or git not available


def _get_files_from_glob(directory_path: str) -> List[str]:
    """Fallback: get files using glob with basic filtering."""
    if os.path.isdir(directory_path):
        search_pattern = os.path.join(directory_path, "**", "*")
    else:
        search_pattern = directory_path

    files = glob.glob(search_pattern, recursive=True)

    # Basic directory filtering for non-git fallback
    ignore_dirs = {'node_modules', '.next', '__pycache__', '.git', 'dist', 'build', 'coverage'}

    filtered = []
    for f in files:
        if not os.path.isfile(f):
            continue
        if any(d in f.split(os.sep) for d in ignore_dirs):
            continue
        filtered.append(f)
    return filtered


class FileSummary(BaseModel):
    """Pydantic model for structured LLM output."""
    file_summary: str = Field(..., description="A concise summary of the file contents.")
    key_exports: List[str] = Field(..., description="List of the file's key public exports.")
    dependencies: List[str] = Field(..., description="List of the file's direct import dependencies.")

def _flush_csv_to_disk(results_data: List[Dict[str, str]], csv_path: str) -> None:
    """Write current results_data to disk as a complete CSV, preserving partial progress."""
    output_io = io.StringIO()
    fieldnames = ['full_path', 'file_summary', 'key_exports', 'dependencies', 'content_hash']
    writer = csv.DictWriter(output_io, fieldnames=fieldnames)
    writer.writeheader()
    writer.writerows(results_data)
    with open(csv_path, 'w', encoding='utf-8') as f:
        f.write(output_io.getvalue())


def summarize_directory(
    directory_path: str,
    strength: float,
    temperature: float,
    time: float = DEFAULT_TIME,
    verbose: bool = False,
    csv_file: Optional[str] = None,
    progress_callback: Optional[Callable[[int, int], None]] = None,
    include_docs: bool = False,
    max_workers: int = 1,
    csv_path: Optional[str] = None,
) -> Tuple[str, float, str]:
    """
    Summarizes files in a directory using an LLM, with caching based on content hashes.

    Args:
        directory_path: Path to the directory/files (supports wildcards, e.g., 'src/*.py').
        strength: Float (0-1) indicating LLM model strength.
        temperature: Float controlling LLM randomness.
        time: Float (0-1) controlling thinking effort.
        verbose: Whether to print detailed logs.
        csv_file: Existing CSV content string to check for cache hits.
        progress_callback: Optional callback for progress updates (current, total).
        include_docs: When True, also discover and summarize doc files (.md, .txt, .rst).
        max_workers: When > 1, parallelize LLM calls via ThreadPoolExecutor.
        csv_path: Optional file path to flush CSV results to disk after each file,
            so partial progress survives if the user interrupts mid-run.

    Returns:
        Tuple containing:
        - csv_output (str): The updated CSV content.
        - total_cost (float): Total cost of LLM operations.
        - model_name (str): Name of the model used (from the last successful call).
    """
    
    # Step 1: Input Validation
    if not isinstance(directory_path, str) or not directory_path:
        raise ValueError("Invalid 'directory_path'.")
    if not (0.0 <= strength <= 1.0):
        raise ValueError("Invalid 'strength' value.")
    if not (isinstance(temperature, (int, float)) and temperature >= 0):
        raise ValueError("Invalid 'temperature' value.")
    if not isinstance(verbose, bool):
        raise ValueError("Invalid 'verbose' value.")
    
    # Parse existing CSV if provided to validate format and get cached entries
    existing_data: Dict[str, Dict[str, str]] = {}
    if csv_file:
        try:
            f = io.StringIO(csv_file)
            reader = csv.DictReader(f)
            if reader.fieldnames and not all(field in reader.fieldnames for field in ['full_path', 'file_summary', 'content_hash']):
                 raise ValueError("Missing required columns.")
            for row in reader:
                if 'full_path' in row and 'content_hash' in row:
                    # Default missing columns (old-format entries)
                    # Mark as backfilled so cache logic can force re-summarization
                    if 'key_exports' not in row or 'dependencies' not in row:
                        row.setdefault('key_exports', '[]')
                        row.setdefault('dependencies', '[]')
                        row['_backfilled'] = True
                    # Use normalized path for cache key consistency
                    existing_data[os.path.normpath(row['full_path'])] = row
        except Exception:
            raise ValueError("Invalid CSV file format.")

    # Step 2: Load prompt template
    prompt_template_name = "summarize_file_LLM"
    prompt_template = load_prompt_template(prompt_template_name)
    if not prompt_template:
        raise FileNotFoundError(f"Prompt template '{prompt_template_name}' is empty or missing.")

    # Step 3: Get list of files
    # Try git first (respects .gitignore), fall back to glob
    files = _get_files_from_git(directory_path)
    if files is None:
        files = _get_files_from_glob(directory_path)

    # Documentation extensions — included only when include_docs is True
    doc_extensions = {'.md', '.txt', '.rst'}

    # Filter out binary files and prompt files that can't be summarized
    filtered_files = []
    for f in files:
        if not os.path.isfile(f):
            continue
        _, ext = os.path.splitext(f)
        if ext.lower() in BINARY_EXTENSIONS:
            continue
        # Skip .prompt files — they are the consumers of dependencies, not
        # dependencies themselves.  Including them adds noise to auto-deps.
        if ext.lower() == '.prompt':
            continue
        # Skip doc files unless include_docs is True
        if not include_docs and ext.lower() in doc_extensions:
            continue
        filtered_files.append(f)

    files = filtered_files

    # Step 4: Return early if no files
    if not files:
        # No files discovered, but preserve any existing cached entries
        output_io = io.StringIO()
        fieldnames = ['full_path', 'file_summary', 'key_exports', 'dependencies', 'content_hash']
        writer = csv.DictWriter(output_io, fieldnames=fieldnames)
        writer.writeheader()
        for entry in existing_data.values():
            writer.writerow({k: entry.get(k, '') for k in fieldnames})
        return output_io.getvalue(), 0.0, "None"

    # Determine base directory for relative paths.
    # Prefer project root so that CSV paths are stable across different
    # directory_path values (scanning pdd/ vs context/ vs .).
    # When no project root marker exists, base_dir is None and we store
    # absolute paths — they're unambiguous regardless of which directory
    # is scanned, and convert seamlessly to project-relative paths once
    # a marker (e.g. git init) is added.
    project_root = _get_project_root(directory_path)
    if project_root:
        base_dir = project_root
    else:
        base_dir = None

    results_data: List[Dict[str, str]] = []
    total_cost = 0.0
    last_model_name = "cached"

    # Step 6: Iterate through files with progress reporting
    total_files = len(files)

    def _compute_rel_path(file_path: str) -> str:
        real = os.path.realpath(file_path)
        return os.path.relpath(real, base_dir) if base_dir else real

    def _process_file(i: int, file_path: str) -> Tuple[float, str, List[str]]:
        """Process a single file and accumulate results.

        Returns (cost, model_name, attempted_models). Single-thread callers
        ignore the third element because llm_invoke publishes its own attempts
        via click.get_current_context() in the main thread.
        """
        rel_path = _compute_rel_path(file_path)
        return _process_single_file_logic(
            file_path,
            rel_path,
            existing_data,
            prompt_template,
            strength,
            temperature,
            time,
            verbose,
            results_data
        )

    def _append_attempts_to_ctx_obj(attempts: List[str]) -> None:
        """Append a list of model attempts to the main thread's Click
        context's `attempted_models` list, creating it if necessary.

        Used only by the threaded path: worker threads cannot publish via
        llm_invoke's native `click.get_current_context()` channel (Click
        context is thread-local), so we collect per-worker attempts and
        publish them from the main thread after workers complete. The
        single-thread path doesn't need this helper because llm_invoke is
        called from the main thread, where its incremental publish lands
        attempts on ctx.obj as they happen (including failed substeps —
        llm_invoke no longer rewinds on failure).
        """
        if not attempts:
            return
        try:
            import click as _click_for_publish
            click_ctx = _click_for_publish.get_current_context(silent=True)
        except Exception:
            return
        if click_ctx is None:
            return
        try:
            if click_ctx.obj is None:
                click_ctx.obj = {}
            if isinstance(click_ctx.obj, dict):
                existing = click_ctx.obj.get('attempted_models')
                if isinstance(existing, list):
                    click_ctx.obj['attempted_models'] = existing + list(attempts)
                else:
                    click_ctx.obj['attempted_models'] = list(attempts)
        except Exception:
            pass

    if max_workers > 1:
        import threading
        from concurrent.futures import ThreadPoolExecutor, as_completed
        cost_lock = threading.Lock()

        # Per-worker llm_invoke results carry their own `attempted_models`
        # because Click's context is thread-local and worker threads cannot
        # publish to the main thread's ctx.obj. Collect (submission_idx,
        # attempts) tuples here, sort by submission_idx after all workers
        # finish, then publish the flattened chronological history to the
        # main thread's Click context for track_cost to read.
        worker_attempts: List[Tuple[int, List[str]]] = []
        # last_model_name tracks the model from the highest-submission-idx
        # worker that actually produced output (`model != "cached"`).
        # Terminal-failure workers (model == "cached" with recovered
        # attempts) do NOT bump this — the CSV `model` column is meant to
        # name "the AI model used for the operation" (README), so leaving
        # a failed candidate name there would be misleading. The audit
        # log in `attempted_models` may still end with a failed entry —
        # that's an honest record of what was tried, distinct from the
        # success identity of the operation.
        last_summarized_idx = -1

        def _threaded_process(i: int, file_path: str) -> Tuple[int, float, str, Optional[Dict[str, str]], List[str]]:
            """Thread-safe wrapper that returns index for ordering."""
            rel_path = _compute_rel_path(file_path)
            local_results: List[Dict[str, str]] = []
            cost, model, attempted = _process_single_file_logic(
                file_path,
                rel_path,
                existing_data,
                prompt_template,
                strength,
                temperature,
                time,
                verbose,
                local_results
            )
            return i, cost, model, local_results[0] if local_results else None, attempted

        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            futures = {
                executor.submit(_threaded_process, i, fp): i
                for i, fp in enumerate(files)
            }
            completed = 0
            for future in as_completed(futures):
                idx, cost, model, result_row, attempted = future.result()
                with cost_lock:
                    total_cost += cost
                    if model != "cached" and idx > last_summarized_idx:
                        last_model_name = model
                        last_summarized_idx = idx
                    if result_row:
                        results_data.append(result_row)
                    if csv_path:
                        _flush_csv_to_disk(results_data, csv_path)
                    if attempted:
                        worker_attempts.append((idx, attempted))
                completed += 1
                if progress_callback:
                    progress_callback(completed, total_files)

        # Publish aggregated worker attempts to the main thread's Click
        # context. Order by submission index so the chronological list reads
        # in file-submission order (inter-worker ordering is otherwise
        # ambiguous because as_completed returns in completion order).
        if worker_attempts:
            worker_attempts.sort(key=lambda item: item[0])
            flattened: List[str] = []
            for _idx, models in worker_attempts:
                flattened.extend(models)
            _append_attempts_to_ctx_obj(flattened)
    elif progress_callback:
        for i, file_path in enumerate(files):
            progress_callback(i + 1, total_files)
            cost, model, _file_attempts = _process_file(i, file_path)
            total_cost += cost
            if model != "cached":
                last_model_name = model
            if csv_path:
                _flush_csv_to_disk(results_data, csv_path)
    elif verbose:
        console.print(f"[bold blue]Summarizing {len(files)} files in '{directory_path}'...[/bold blue]")
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TextColumn("{task.percentage:>3.0f}%"),
            console=console
        ) as progress:
            task = progress.add_task("[cyan]Processing files...", total=len(files))
            for i, file_path in enumerate(files):
                cost, model, _file_attempts = _process_file(i, file_path)
                total_cost += cost
                if model != "cached":
                    last_model_name = model
                if csv_path:
                    _flush_csv_to_disk(results_data, csv_path)
                progress.advance(task)
    else:
        for i, file_path in enumerate(files):
            cost, model, _file_attempts = _process_file(i, file_path)
            total_cost += cost
            if model != "cached":
                last_model_name = model
            if csv_path:
                _flush_csv_to_disk(results_data, csv_path)

    # Step 7: Merge in existing entries that were not part of this scan.
    # This preserves cached summaries for files outside the current
    # directory_path / glob scope so they are not silently dropped.
    scanned_paths = set()
    for row in results_data:
        scanned_paths.add(os.path.normpath(row['full_path']))
        # Also track the absolute version so entries keyed by absolute path
        # are recognized as already present when the scan wrote a relative path.
        if base_dir:
            abs_candidate = os.path.normpath(os.path.join(base_dir, row['full_path']))
            scanned_paths.add(abs_candidate)
            # Also track the realpath form for symlink consistency
            scanned_paths.add(os.path.normpath(os.path.realpath(
                os.path.join(base_dir, row['full_path']))))
    fieldnames = ['full_path', 'file_summary', 'key_exports', 'dependencies', 'content_hash']
    for norm_path, entry in existing_data.items():
        if norm_path not in scanned_paths:
            results_data.append({k: entry.get(k, '') for k in fieldnames})

    # Step 8: Generate CSV output
    output_io = io.StringIO()
    writer = csv.DictWriter(output_io, fieldnames=fieldnames)

    writer.writeheader()
    writer.writerows(results_data)

    csv_output = output_io.getvalue()

    return csv_output, total_cost, last_model_name

def _process_single_file_logic(
    file_path: str,
    rel_path: str,
    existing_data: Dict[str, Dict[str, str]],
    prompt_template: str,
    strength: float,
    temperature: float,
    time: float,
    verbose: bool,
    results_data: List[Dict[str, str]]
) -> Tuple[float, str, List[str]]:
    """
    Helper function to process a single file: read, hash, check cache, summarize if needed.
    Returns (cost, model_name, attempted_models).
    The third element carries the per-call `attempted_models` list from llm_invoke
    so that callers running this function in worker threads can surface the
    fallback history to the main thread's Click context (workers cannot publish
    via click.get_current_context() because Click's context is thread-local).
    """
    cost = 0.0
    model_name = "cached"
    attempted_models: List[str] = []

    try:
        # Step 6a: Read file
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()

        # Step 6b: Compute hash
        current_hash = hashlib.sha256(content.encode('utf-8')).hexdigest()

        summary = ""
        key_exports = "[]"
        dependencies = "[]"

        # Step 6c: Check cache (using normalized relative path)
        normalized_path = os.path.normpath(rel_path)
        cache_hit = False

        # Also check absolute path for backward compatibility with older caches.
        # Check both normpath and realpath forms to handle platforms where
        # symlinks cause path divergence (e.g. macOS /var -> /private/var).
        abs_normalized_path = os.path.normpath(file_path)
        abs_realpath = os.path.normpath(os.path.realpath(file_path))

        cached_entry = (
            existing_data.get(normalized_path)
            or existing_data.get(abs_normalized_path)
            or existing_data.get(abs_realpath)
        )

        if cached_entry:
            # Step 6d: Check hash match and that entry was produced by the new format
            # (old-format entries lack key_exports/dependencies columns entirely;
            #  the CSV parser defaults those to '[]' AND sets a marker flag).
            # A new-format entry may legitimately have '[]' for either field.
            if (
                cached_entry.get('content_hash') == current_hash and
                not cached_entry.get('_backfilled')
            ):
                # Step 6e: Reuse summary
                summary = cached_entry.get('file_summary', "")
                key_exports = cached_entry.get('key_exports', "[]")
                dependencies = cached_entry.get('dependencies', "[]")
                cache_hit = True
                if verbose:
                    console.print(f"[dim]Cache hit for {rel_path}[/dim]")

        # Step 6f: Summarize if needed
        if not cache_hit:
            if verbose:
                console.print(f"[dim]Summarizing {rel_path}...[/dim]")
            
            llm_result = llm_invoke(
                prompt=prompt_template,
                input_json={"file_contents": content},
                strength=strength,
                temperature=temperature,
                time=time,
                output_pydantic=FileSummary,
                verbose=verbose
            )
            
            file_summary_obj: FileSummary = llm_result['result']
            summary = file_summary_obj.file_summary
            key_exports = json.dumps(file_summary_obj.key_exports)
            dependencies = json.dumps(file_summary_obj.dependencies)
            
            cost = llm_result.get('cost', 0.0)
            model_name = llm_result.get('model_name', "unknown")
            raw_attempts = llm_result.get('attempted_models') or []
            if isinstance(raw_attempts, list):
                attempted_models = [str(m) for m in raw_attempts]
            if not attempted_models and model_name and model_name != "unknown":
                attempted_models = [model_name]

        # Print verbose per-file summary (only for freshly summarized files)
        if verbose and not cache_hit:
            console.print(f"  [bold]{rel_path}[/bold]")
            console.print(f"    Summary:      {summary}")
            console.print(f"    Dependencies: {dependencies}")
            console.print(f"    Key Exports:  {key_exports}")

        # Step 6g: Store data
        results_data.append({
            'full_path': rel_path,
            'file_summary': summary,
            'key_exports': key_exports,
            'dependencies': dependencies,
            'content_hash': current_hash
        })

    except Exception as e:
        console.print(f"[bold red]Error processing file {file_path}:[/bold red] {e}")
        results_data.append({
            'full_path': rel_path,
            'file_summary': f"Error processing file: {str(e)}",
            'key_exports': "[]",
            'dependencies': "[]",
            'content_hash': "error"
        })
        # llm_invoke attaches its per-call attempt history to the terminal
        # RuntimeError it raises when all candidates are exhausted. Recover
        # those attempts so a terminally-failed worker still contributes
        # its fallback history to the command-level attempted_models list
        # — otherwise the data we promised in cost.csv gets silently
        # dropped for the exact failure mode users most want to investigate.
        # The isinstance check below guarantees iterability at runtime,
        # but `getattr(e, ..., None)` returns `Any | None` and pylint's
        # flow analysis doesn't carry the narrowing through to the
        # comprehension, so we explicitly materialize via `list(...)` —
        # pylint sees a `list` constructor and stops flagging E1133.
        err_attempts = getattr(e, "attempted_models", None)
        if isinstance(err_attempts, list):
            attempted_models = [str(m) for m in list(err_attempts)]

    return cost, model_name, attempted_models
