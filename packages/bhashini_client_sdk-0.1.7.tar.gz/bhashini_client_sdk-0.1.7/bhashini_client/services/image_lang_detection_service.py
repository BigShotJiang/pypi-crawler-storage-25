import os

from ..models_info import validate_model_request
from .service_utils import api_error, input_error, is_error_response


class ImageLanguageDetectionService:
    DEFAULT_SERVICE_ID = "bhashini/iiith/img-lang-detection"
    DEFAULT_URL = "https://dhruva-central-dev.bhashini.co.in/services/inference/pipeline"

    def __init__(self, handler):
        self.handler = handler

    def preprocess(self, input_data):
        if input_data is None or not isinstance(input_data, str):
            return input_error("Image language detection expects a valid image URI string.")
        cleaned_input = input_data.strip()
        if not cleaned_input:
            return input_error("Image URI is empty. Please provide a valid public image URI.")
        if os.path.isfile(cleaned_input):
            return input_error("Local image paths are not supported. Please provide a public image URI.")
        lowered = cleaned_input.lower()
        if lowered.startswith("http://") or lowered.startswith("https://"):
            return cleaned_input
        return input_error("Image input must be a public HTTP or HTTPS image URI.")

    def detect(self, input_data, service_id: str = None):
        processed_input = self.preprocess(input_data)
        if is_error_response(processed_input):
            return processed_input
        model_validation = validate_model_request("image language detection", service_id=service_id)
        if model_validation:
            return model_validation
        response = self.handler.post(
            self._build_payload(processed_input, service_id or self.DEFAULT_SERVICE_ID),
            url=self.DEFAULT_URL,
        )
        if not response:
            return api_error("Image language detection service did not return a valid response.")
        return self.postprocess(response)

    def _build_payload(self, image_uri: str, service_id: str):
        return {
            "pipelineTasks": [
                {
                    "taskType": "img-lang-detection",
                    "config": {
                        "serviceId": service_id,
                    },
                }
            ],
            "inputData": {
                "image": [
                    {
                        "imageUri": image_uri,
                    }
                ]
            },
        }

    def postprocess(self, response):
        try:
            output = response.get("pipelineResponse", [{}])[0].get("output", [{}])[0]
            predictions = output.get("langPrediction", [])
            if predictions:
                return predictions[0].get("langCode") or api_error(
                    "Image language detection response did not include a language code."
                )
            return output.get("langCode") or output.get("source") or api_error(
                "Image language detection response did not include any predictions."
            )
        except Exception:
            return api_error("Image language detection service returned a malformed response.")
