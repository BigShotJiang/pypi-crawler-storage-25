from ..models_info import validate_model_request
from .service_utils import api_error, input_error, is_error_response, require_language, require_text


class NMTService:
    def __init__(self, handler):
        self.handler = handler

    def preprocess(self, input_data):
        return require_text(input_data)

    def translate(
        self,
        input_data,
        source_lang: str,
        target_lang: str,
        service_id: str = None,
        source_script_code: str = None,
        target_script_code: str = None,
        domain: str = None,
    ):
        processed_input = self.preprocess(input_data)
        if is_error_response(processed_input):
            return processed_input
        normalized_source = require_language(source_lang, field_name="source language")
        if is_error_response(normalized_source):
            return normalized_source
        normalized_target = require_language(target_lang, field_name="target language")
        if is_error_response(normalized_target):
            return normalized_target

        model_validation = validate_model_request(
            "nmt",
            service_id=service_id,
            languages=[normalized_source, normalized_target],
        )
        if model_validation:
            return model_validation
        response = self.handler.post(
            self._build_payload(
                processed_input,
                normalized_source,
                normalized_target,
                service_id or self._get_primary_service_id(normalized_source, normalized_target),
                source_script_code=source_script_code,
                target_script_code=target_script_code,
                domain=domain,
            )
        )
        if not response and service_id is None:
            response = self.handler.post(
                self._build_payload(
                    processed_input,
                    normalized_source,
                    normalized_target,
                    self._get_fallback_service_id(normalized_source, normalized_target),
                    source_script_code=source_script_code,
                    target_script_code=target_script_code,
                    domain=domain,
                )
            )
        if not response:
            return api_error("NMT service did not return a valid response.")
        return self.postprocess(response)

    def _build_payload(
        self,
        input_data,
        source_lang: str,
        target_lang: str,
        service_id: str,
        source_script_code=None,
        target_script_code=None,
        domain=None,
    ):
        language_config = {
            "sourceLanguage": source_lang,
            "targetLanguage": target_lang,
        }
        if source_script_code:
            language_config["sourceScriptCode"] = source_script_code
        if target_script_code:
            language_config["targetScriptCode"] = target_script_code
        config = {
            "language": language_config,
            "serviceId": service_id,
        }
        if domain:
            config["domain"] = domain
        return {
            "pipelineTasks": [
                {
                    "taskType": "translation",
                    "config": config,
                }
            ],
            "inputData": {"input": [{"source": input_data}]},
        }

    def _get_primary_service_id(self, source_lang: str, target_lang: str):
        normalized_source = source_lang.strip().lower()
        normalized_target = target_lang.strip().lower()
        if {normalized_source, normalized_target}.issubset({"hi", "en"}):
            return "bhashini/iiith/nmt-all"
        return "bhashini/ai4bharat/indictrans-v3"

    def _get_fallback_service_id(self, source_lang: str, target_lang: str):
        normalized_source = source_lang.strip().lower()
        normalized_target = target_lang.strip().lower()
        if {normalized_source, normalized_target}.issubset({"hi", "en"}):
            return "Bhashini/IIITH/Trans/V1"
        return "ai4bharat/indictrans-v2-all-gpu--t4"

    def postprocess(self, response):
        try:
            return (
                response.get("pipelineResponse", [{}])[0]
                .get("output", [{}])[0]
                .get("target")
            ) or api_error("NMT response did not include translated text.")
        except Exception:
            return api_error("NMT service returned a malformed response.")
