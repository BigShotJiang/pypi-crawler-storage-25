# bhashini-client-sdk

Python SDK for Bhashini inference APIs.

## Features

- ASR
- NMT
- TTS
- Transliteration
- Text Language Detection
- NER
- OCR
- Audio Language Detection
- Speaker Diarization

## Installation

```bash
pip install bhashini-client-sdk
```

## Setup

Set your Bhashini API key before using the client.

```powershell
$env:BHASHINI_API_KEY="your_api_key"
```

Optional sample files for the demo:

```powershell
$env:BHASHINI_SAMPLE_AUDIO="C:\full\path\sample.wav"
$env:BHASHINI_SAMPLE_IMAGE="C:\full\path\sample.png"
```

## Quick Start

```python
from bhashini_client import BhashiniClient

client = BhashiniClient()

print(client.text_language_detection("Hello world"))
print(client.nmt("Hello", "en", "hi"))
print(client.transliteration("namaste", "en", "hi"))
print(client.ner("Narendra Modi went to Delhi.", "en"))
print(client.audio_language_detection("C:\\full\\path\\sample.wav"))
print(client.speaker_diarization("C:\\full\\path\\sample.wav"))
print(client.asr("C:\\full\\path\\sample.wav", "hi"))
```

## Demo

```powershell
python demo.py
```

## Testing

```powershell
python -m pytest tests
```

The test suite writes results to `final_bhashini_test_results.xlsx`.

## Supported Input Notes

- Audio input should be `.wav`
- Expected sampling rate is `16000`
- ASR also expects mono audio
- Services accept file-path input and, where supported, base64 audio input

## Package Contents

- `bhashini_client.BhashiniClient`
- `bhashini_client.get_models_info`

## License

MIT
