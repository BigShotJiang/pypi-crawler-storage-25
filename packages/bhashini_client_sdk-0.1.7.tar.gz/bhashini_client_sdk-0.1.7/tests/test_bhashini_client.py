"""Tests for the top-level client."""

from bhashini_client import BhashiniClient


def test_client_init():
    client = BhashiniClient(api_key="CsFWOur9eN-PjvPQ_taMD0_ewNfnxQP-L3rO8AWOWJEJTKqrtBdnzzPlx0dd-u2S")
    assert client is not None
    assert hasattr(client, "nmt_service")
    assert hasattr(client, "tts_service")
    assert hasattr(client, "transliteration_service")
    assert hasattr(client, "language_detection_service")
    assert hasattr(client, "ocr_service")
    assert hasattr(client, "ner_service")
