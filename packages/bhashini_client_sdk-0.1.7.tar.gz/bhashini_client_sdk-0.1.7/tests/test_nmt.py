from bhashini_client.services.nmt_service import NMTService

from tests.assertions import INPUT_ERROR, assert_service_output
from tests.result_logger import log_test_result


def test_nmt_service_cases():
    long_text = "Hello world " * 100
    cases = [
        ("T015", "Normal text", "Hello", "नमस्ते", "Valid text is translated correctly."),
        ("T016", "Empty string", "", INPUT_ERROR, "Empty text is rejected before API call."),
        ("T017", "Whitespace string", "   ", INPUT_ERROR, "Whitespace-only text is rejected after trimming."),
        ("T018", "Numeric input", 123, INPUT_ERROR, "Numeric input is rejected because translation expects text."),
        ("T019", "Mixed input", "Hello नमस्ते 123", "नमस्ते", "Mixed-language text is still treated as valid translation input."),
        ("T020", "Long text", long_text, "अनुवादित लंबा पाठ", "Long text is accepted and translated cleanly."),
        ("T021", "Invalid input type", {"text": "Hello"}, INPUT_ERROR, "Unsupported input types are rejected before API call."),
    ]

    for test_id, test_case_name, input_value, expected_output, logic_reason in cases:
        service = NMTService(handler=None)
        if test_case_name in {"Normal text", "Mixed input"}:
            service.handler = type(
                "Handler",
                (),
                {"post": lambda self, payload: {"pipelineResponse": [{"output": [{"target": "नमस्ते"}]}]}},
            )()
        elif test_case_name == "Long text":
            service.handler = type(
                "Handler",
                (),
                {"post": lambda self, payload: {"pipelineResponse": [{"output": [{"target": "अनुवादित लंबा पाठ"}]}]}},
            )()
        actual_output = service.translate(input_value, "en", "hi")
        log_test_result(
            test_id,
            "NMT",
            input_value,
            expected_output,
            actual_output,
            test_case_name=test_case_name,
            logic_reason=logic_reason,
            remark="Working correctly" if expected_output == actual_output else "Check translation handling",
        )
        assert_service_output(actual_output, expected_output)


def test_nmt_payload_includes_optional_parameters():
    captured = {}

    class Handler:
        def post(self, payload):
            captured["payload"] = payload
            return {"pipelineResponse": [{"output": [{"target": "Hello"}]}]}

    service = NMTService(Handler())
    actual_output = service.translate(
        "नमस्ते",
        "hi",
        "en",
        service_id="bhashini/iiith/nmt-all",
        source_script_code="Deva",
        target_script_code="Latn",
        domain="general",
    )
    config = captured["payload"]["pipelineTasks"][0]["config"]
    log_test_result(
        "T022",
        "NMT",
        "hi -> en with optional parameters",
        "Hello",
        actual_output,
        test_case_name="Optional parameters",
        logic_reason="Optional language script codes and domain are added to the translation payload.",
        remark="Optional parameters working correctly",
    )
    assert actual_output == "Hello"
    assert config["serviceId"] == "bhashini/iiith/nmt-all"
    assert config["language"]["sourceLanguage"] == "hi"
    assert config["language"]["targetLanguage"] == "en"
    assert config["language"]["sourceScriptCode"] == "Deva"
    assert config["language"]["targetScriptCode"] == "Latn"
    assert config["domain"] == "general"


def test_nmt_uses_hindi_english_service_id():
    captured = {}

    class Handler:
        def post(self, payload):
            captured["serviceId"] = payload["pipelineTasks"][0]["config"]["serviceId"]
            return {"pipelineResponse": [{"output": [{"target": "Hello"}]}]}

    service = NMTService(Handler())
    actual_output = service.translate("नमस्ते", "hi", "en")
    log_test_result(
        "T023",
        "NMT",
        "hi-en service id",
        "Hello",
        actual_output,
        test_case_name="Hindi-English service id",
        logic_reason="The default Hindi-English NMT service id should be used for hi-en translation.",
        remark="Default service id selected correctly",
    )
    assert actual_output == "Hello"
    assert captured["serviceId"] == "bhashini/iiith/nmt-all"
