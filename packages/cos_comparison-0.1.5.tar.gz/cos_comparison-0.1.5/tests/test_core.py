import pytest
import cos_comparison as com

def test_similarity_algorithms():
    a = 4.0
    b = 9.0
    ab = 6.0
    # cos: 6 / sqrt(36)=6/6=1
    assert com._cos(a, b, ab, None) == 1.0
    # mod: 2*sqrt(36)/(13)=12/13≈0.923
    assert abs(com._mod(a, b, ab, None) - 12/13) < 1e-9
    # cosmod: 12/(13)=0.923
    assert abs(com._cosmod(a, b, ab, None) - 12/13) < 1e-9

def test_cos_direct():
    A = [1.0, 2.0, 3.0]
    B = [1.0, 2.0, 3.0]
    assert com.cos(A, B) == 1.0

    A = [1.0, 0.0, 0.0]
    B = [0.0, 1.0, 0.0]
    assert com.cos(A, B, algorithm=cc._cos) == 0.0

def test_passive_3d_output_shape():
    # 3x3x3 dummy data
    data = [[[1.0 for _ in range(3)] for _ in range(3)] for __ in range(3)]
    # window_size (1,1,1) step 1 d (1,0,0)
    result = com.cos_comparison_passive_3d(data, window_size=(1,1,1), d=(1,0,0), algorithm=cc._cosmod)
    # expected output shape: (2, 3, 3) because height: 3-1-1=1 +1? Actually stop = 3-1-1=1, num = (1-0+1)//1=2
    assert len(result) == 2
    assert len(result[0]) == 3
    assert len(result[0][0]) == 3

def test_mean_local():
    data = [1.0, 2.0, 3.0, 4.0]
    res = com.mean_local_1d(data, local_size=(2,), step=(1,))
    # manual: (1+2)/2=1.5, (2+3)/2=2.5, (3+4)/2=3.5
    assert res == [1.5, 2.5, 3.5]