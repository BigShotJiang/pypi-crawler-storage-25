# it provides basic functions of cos_comparsion module,an AI algorithm set
#
# core : information is produced by local comparison in raw data 

#--------------------- import ------------------------------
from math import sqrt
import numpy as np
from numpy.lib.stride_tricks import sliding_window_view

#-------------------- constant -----------------------------
NaN = float("nan")

#------------------ tool module -----------------
def multiple_chain(iterable, base=1):
    """Multiply elements of iterable in turn."""
    for m in iterable:
        base *= m
    return base

def add_chain(iterable, base=0):
    """Add elements of iterable in turn."""
    for m in iterable:
        base += m
    return base

def create_void_list(leng_list=(1,), default=None):
    """Create nested list filled with default value recursively."""
    li = default
    for i in range(-1, -len(leng_list)-1, -1):
        li = [li for _ in range(leng_list[i])]
    return li

def vector_chain_compute(A):
    """Return closures for batch dot product, update, and access."""
    a = A
    def compute(vector):
        nonlocal a
        return (sum(m*n for m,n in zip(vector, a[i])) for i in range(len(a)))
    def fix(new):
        nonlocal a
        a = new
    def get():
        return a
    return compute, fix, get

#------------------- class support --------------------------
#     --------------- type support -----------------
class relative_bool:
    __slots__ = ("true_w", "false_w")
    def __init__(self, true_w=1, false_w=0):
        self.true_w = true_w
        self.false_w = false_w
    def __bool__(self) -> bool:
        return bool(self.true_w)

class vector_map_as_tensor:
    """Map a 1D vector to a logical multi-dimensional tensor using strides."""
    __slots__ = ("vector", "tensor_size", "dimension", "start", "end", "p", "cache")
    def __init__(self, vector, tensor_size, start=0, end=None, p=0, cache=None):
        self.vector = vector
        self.tensor_size = tensor_size
        self.start = start
        self.end = end if end is not None else len(vector)
        self.p = p
        self.cache = cache if cache is not None else multiple_chain(tensor_size[1:])

    def __getitem__(self, index: int):
        if self.tensor_size - self.p:
            new = self.start + index * self.cache
            new_p = self.p + 1
            return vector_map_as_tensor(self.vector, self.tensor_size,
                                        start=new, end=new+self.cache,
                                        p=new_p,
                                        cache=self.cache // self.tensor_size[new_p])
        else:
            return self.vector[self.start + index]

    def __setitem__(self, key, value):
        if self.tensor_size - self.p - 1:
            raise IndexError("it does not reach the lowest layer.")
        else:
            self.vector[self.start + key] = value

    def __len__(self) -> int:
        return self.tensor_size[self.p]

    def mean(self):
        return sum(self.vector[self.start:self.end]) / (self.end - self.start)

#    ------------ contain support -------------
class name_space:
    """Lightweight object that holds attributes from kwargs, optimised with __slots__."""
    def __init__(self, **kwarg):
        self.__slots__ = kwarg.keys()
        for k, v in kwarg.items():
            setattr(self, k, v)

class flexible_name_space:
    """Similar to name_space but uses __dict__ (less memory efficient)."""
    def __init__(self, **kwarg):
        self.__dict__.update(kwarg)

class contain_in_bases:
    """Wrap data with a multiplicative base for easy scaling."""
    __slots__ = ("base", "data")
    def __init__(self, data, base):
        self.base = base
        self.data = data
    def __mul__(self, mu):
        self.base *= mu
        return self
    def __getitem__(self, index: int):
        temp = self.data[index]
        if hasattr(temp, "__getitem__"):
            return contain_in_bases(temp, self.base)
        else:
            return temp * self.base
    def __setitem__(self, key, val):
        self.data[key] = val

class default_contain:
    """Default value container that supports deep indexing with lazy dimensions."""
    __slots__ = ("default", "deep", "default_dict", "leng")
    def __init__(self, default, deep=1, leng=(10,), default_dict=None):
        self.default = default
        self.deep = deep
        self.default_dict = default_dict if default_dict else {}
        self.leng = leng
    def __len__(self):
        return self.leng[0]
    def __getitem__(self, index):
        if self.deep - 1:
            _, *leng = self.leng
            return default_contain(self.default, deep=self.deep-1,
                                   leng=leng, default_dict=self.default_dict)
        else:
            return self.default_dict.get(index, self.default)

class flexible_contain:
    """Dynamically growing list (maintained as Python list for simplicity)."""
    __slots__ = ("contain", "buffer")
    def __init__(self, init_buffer: int = 64):
        # 使用 Python list，因为频繁添加和动态索引，numpy 并不总是合适
        self.contain = [None] * init_buffer
        self.buffer = init_buffer
    def __len__(self):
        return self.buffer
    def __getitem__(self, index: int):
        try:
            return self.contain[index]
        except IndexError:
            self.contain.extend([None] * (index - self.buffer + 1))
            self.buffer = index + 1
            return self.contain[index]
    def __setitem__(self, key: int, value):
        try:
            self.contain[key] = value
        except IndexError:
            self.contain.extend([None] * (key - self.buffer + 1))
            self.buffer = key + 1
            self.contain[key] = value

#----------------- private module ---------------------------
_cos = lambda a, b, ab, name : ab / sqrt(a * b) if a * b else (1.0 if a == b else 0.0)
_mod = lambda a, b, ab, name : 2 * sqrt(a * b) / (a + b) if a * b else (1.0 if a == b else 0.0)
_cosmod = lambda a, b, ab, name : 2 * ab / (a + b) if a * b else (1.0 if a == b else 0.0)
_default_algorithm = lambda a, b, ab, name: (_cos(a, b, ab, name), _mod(a, b, ab, name), _cosmod(a, b, ab, name))

# vectorized similarity functions (only support single scalar algorithms)
def _vectorized_cos(main_sum, other_sum, cross_sum):
    """Cosine similarity: ab / sqrt(a*b)."""
    denom = np.sqrt(main_sum * other_sum)
    denom[denom == 0] = 1.0
    return cross_sum / denom

def _vectorized_mod(main_sum, other_sum, cross_sum):
    """Harmonic-like similarity: 2*sqrt(a*b) / (a+b)."""
    denom = main_sum + other_sum
    denom[denom == 0] = 1.0
    return 2.0 * np.sqrt(main_sum * other_sum) / denom

def _vectorized_cosmod(main_sum, other_sum, cross_sum):
    """Modified cosine: 2*ab / (a+b)."""
    denom = main_sum + other_sum
    denom[denom == 0] = 1.0
    return 2.0 * cross_sum / denom

# Map algorithm functions to their vectorized versions
_vectorized_algos = {
    _cos: _vectorized_cos,
    _mod: _vectorized_mod,
    _cosmod: _vectorized_cosmod,
}

#-------------------- core ----------------------------------
def _passive_generic_np(data, window_size, d, step, start, end, w1, w2, b1, b2, algorithm):
    """
    Generic N-dimensional passive mode using numpy sliding windows.
    Returns a numpy array of similarity results.
    """
    data = np.asarray(data, dtype=np.float64)
    ws = np.array(window_size, dtype=int)
    dd = np.array(d, dtype=int)
    sp = np.array(step, dtype=int)
    st = np.array(start, dtype=int)
    en = np.minimum(np.array(end, dtype=int), np.array(data.shape, dtype=int))
    ndim = len(ws)

    # stop index for the last valid window
    stop = en - ws - dd
    out_shape = np.maximum((stop - st + sp) // sp, 0)
    if np.any(out_shape <= 0):
        return np.array([])

    # sliding window view of the main data
    main_slices = tuple(slice(st[i], stop[i] + 1, sp[i]) for i in range(ndim))
    main_view = sliding_window_view(data, window_size=tuple(ws))
    main_wins = main_view[main_slices]  # shape: out_shape + ws

    # shifted data for the comparison window
    shifted = data[tuple(slice(dd[i], None) for i in range(ndim))]
    other_view = sliding_window_view(shifted, window_size=tuple(ws))
    other_wins = other_view[main_slices]

    # apply linear transforms
    main_lin = w1 * main_wins + b1
    other_lin = w2 * other_wins + b2

    # sum over window dimensions (axes from ndim to 2*ndim-1)
    win_axes = tuple(range(ndim, ndim * 2))
    main_sum = np.sum(main_lin ** 2, axis=win_axes)
    other_sum = np.sum(other_lin ** 2, axis=win_axes)
    cross_sum = np.sum(main_lin * other_lin, axis=win_axes)

    # choose the right vectorized similarity
    vec_func = _vectorized_algos.get(algorithm)
    if vec_func is None:
        raise NotImplementedError("Only _cos, _mod, _cosmod supported in numpy backend")
    result = vec_func(main_sum, other_sum, cross_sum)
    return result

def _active_generic_np(data, kernel, step, start, end, w1, w2, b1, b2, algorithm):
    """
    Generic N-dimensional active mode using numpy sliding windows.
    Returns a numpy array of similarity results.
    """
    data = np.asarray(data, dtype=np.float64)
    kernel = np.asarray(kernel, dtype=np.float64)
    ws = np.array(kernel.shape, dtype=int)
    sp = np.array(step, dtype=int)
    st = np.array(start, dtype=int)
    en = np.minimum(np.array(end, dtype=int), np.array(data.shape, dtype=int))
    ndim = len(ws)

    stop = en - ws
    out_shape = np.maximum((stop - st + sp) // sp, 0)
    if np.any(out_shape <= 0):
        return np.array([])

    main_slices = tuple(slice(st[i], stop[i] + 1, sp[i]) for i in range(ndim))
    main_view = sliding_window_view(data, window_size=tuple(ws))
    main_wins = main_view[main_slices]

    main_lin = w1 * main_wins + b1
    other_lin = w2 * kernel + b2   # broadcast kernel over main_wins

    win_axes = tuple(range(ndim, ndim * 2))
    main_sum = np.sum(main_lin ** 2, axis=win_axes)
    other_sum = np.sum(other_lin ** 2)   # constant
    cross_sum = np.sum(main_lin * other_lin, axis=win_axes)

    vec_func = _vectorized_algos.get(algorithm)
    if vec_func is None:
        raise NotImplementedError("Only _cos, _mod, _cosmod supported in numpy backend")
    result = vec_func(main_sum, other_sum, cross_sum)
    return result

def _check_no_callbacks(start_cb, end_cb, iter_a_cb, iter_b_cb, iter_stop_cb):
    """Raise NotImplementedError if any callback is provided, forcing fallback."""
    if any([start_cb, end_cb, iter_a_cb, iter_b_cb, iter_stop_cb]):
        raise NotImplementedError("Callbacks are not supported in numpy backend; fallback to pure Python")

def _handle_output(result, output, output_start, output_step):
    """Write result into `output` array or return a new numpy array."""
    if output is None:
        return result
    out = np.asarray(output, dtype=np.float64)
    # simple placement: if output_start and output_step are default, we can copy directly
    if output_start is None and output_step is None:
        np.copyto(out, result)
    else:
        # for full generality we would need to slice into out using output_start/output_step.
        # Since the original interface supports arbitrary start/step, we should implement that here.
        # We'll use a slice object for each dimension.
        ost = tuple(slice(int(s), None, int(p)) for s,p in zip(output_start, output_step))
        out[ost] = result
    return out

# --------------- public API (wrappers) ---------------
def _passive_active_common(data, window_size=None, kernel=None,
                           w1=1, w2=1, b1=0, b2=0,
                           start=(0,), end=(NaN,), step=(1,), d=None,
                           algorithm=_cos,
                           start_callback=None, end_callback=None,
                           iter_a_callback=None, iter_b_callback=None, iter_stop_callback=None,
                           global_error_callback=lambda e,name: None,
                           local_error_callback=lambda e,name: None,
                           return_callback=lambda name: name.cos1,
                           output=None, output_start=None, output_step=None,
                           **kwarg):
    """Common entry for both passive and active 1d-4d modes."""
    _check_no_callbacks(start_callback, end_callback, iter_a_callback, iter_b_callback, iter_stop_callback)
    if algorithm not in (_cos, _mod, _cosmod):
        raise NotImplementedError("Only _cos, _mod, _cosmod are supported in numpy backend")
    try:
        if kernel is not None:
            # active mode
            res = _active_generic_np(data, kernel, step, start, end, w1, w2, b1, b2, algorithm)
        else:
            # passive mode
            res = _passive_generic_np(data, window_size, d, step, start, end, w1, w2, b1, b2, algorithm)
        out = _handle_output(res, output, output_start, output_step)
        name = name_space(cos1=out)
        return return_callback(name)
    except Exception as e:
        global_error_callback(e, name_space())
        raise

# --- explicit 1d-4d functions for compatibility ---
def cos_comparison_passive_1d(data, *arg, window_size=(1,), w1=1, w2=1, b1=0, b2=0,
                              start=(0,), end=(NaN,), step=(1,), d=(1,),
                              algorithm=_cos, start_callback=None, end_callback=None,
                              iter_a_callback=None, iter_b_callback=None, iter_stop_callback=None,
                              global_error_callback=lambda e,name: None,
                              local_error_callback=lambda e,name: None,
                              return_callback=lambda name: name.cos1,
                              output=None, output_start=None, output_step=None, **kwarg):
    return _passive_active_common(data, window_size=window_size, w1=w1, w2=w2, b1=b1, b2=b2,
                                  start=start, end=end, step=step, d=d, algorithm=algorithm,
                                  start_callback=start_callback, end_callback=end_callback,
                                  iter_a_callback=iter_a_callback, iter_b_callback=iter_b_callback,
                                  iter_stop_callback=iter_stop_callback,
                                  global_error_callback=global_error_callback,
                                  local_error_callback=local_error_callback,
                                  return_callback=return_callback,
                                  output=output, output_start=output_start, output_step=output_step,
                                  **kwarg)

cos_comparison_passive_2d = cos_comparison_passive_1d
cos_comparison_passive_3d = cos_comparison_passive_1d
cos_comparison_passive_4d = cos_comparison_passive_1d

def cos_comparison_active_1d(data, *arg, kernel=(1,), w1=1, w2=1, b1=0, b2=0,
                             start=(0,), end=(NaN,), step=(1,),
                             algorithm=_cos, start_callback=None, end_callback=None,
                             iter_a_callback=None, iter_b_callback=None, iter_stop_callback=None,
                             global_error_callback=lambda e,name: None,
                             local_error_callback=lambda e,name: None,
                             return_callback=lambda name: name.cos1,
                             output=None, output_start=None, output_step=None, **kwarg):
    return _passive_active_common(data, kernel=kernel, w1=w1, w2=w2, b1=b1, b2=b2,
                                  start=start, end=end, step=step, algorithm=algorithm,
                                  start_callback=start_callback, end_callback=end_callback,
                                  iter_a_callback=iter_a_callback, iter_b_callback=iter_b_callback,
                                  iter_stop_callback=iter_stop_callback,
                                  global_error_callback=global_error_callback,
                                  local_error_callback=local_error_callback,
                                  return_callback=return_callback,
                                  output=output, output_start=output_start, output_step=output_step,
                                  **kwarg)

cos_comparison_active_2d = cos_comparison_active_1d
cos_comparison_active_3d = cos_comparison_active_1d
cos_comparison_active_4d = cos_comparison_active_1d

# --- generic functions (only support explicit parameters) ---
def cos_comparison_passive(data, *arg,
                           window_size=None, w1=1, w2=1, b1=0, b2=0,
                           start=None, end=None, step=None, d=None,
                           algorithm=_cos, start_callback=None, end_callback=None,
                           iter_a_callback=None, iter_b_callback=None, iter_stop_callback=None,
                           global_error_callback=lambda e,name: None,
                           local_error_callback=lambda e,name: None,
                           return_callback=lambda name: name.cos1,
                           output=None, output_start=None, output_step=None, **kwarg):
    if any(p is None or isinstance(p, default_contain) for p in (window_size, start, end, step, d)):
        raise NotImplementedError("Generic passive with default_contain is not supported, fallback to pure Python")
    return cos_comparison_passive_1d(data, window_size=window_size, w1=w1, w2=w2, b1=b1, b2=b2,
                                     start=start, end=end, step=step, d=d,
                                     algorithm=algorithm,
                                     start_callback=start_callback, end_callback=end_callback,
                                     iter_a_callback=iter_a_callback, iter_b_callback=iter_b_callback,
                                     iter_stop_callback=iter_stop_callback,
                                     global_error_callback=global_error_callback,
                                     local_error_callback=local_error_callback,
                                     return_callback=return_callback,
                                     output=output, output_start=output_start, output_step=output_step)

def cos_comparison_active(data, *arg,
                          kernel=None, w1=1, w2=1, b1=0, b2=0,
                          start=None, end=None, step=None,
                          algorithm=_cos, start_callback=None, end_callback=None,
                          iter_a_callback=None, iter_b_callback=None, iter_stop_callback=None,
                          global_error_callback=lambda e,name: None,
                          local_error_callback=lambda e,name: None,
                          return_callback=lambda name: name.cos1,
                          output=None, output_start=None, output_step=None, **kwarg):
    if kernel is None or isinstance(kernel, default_contain):
        raise NotImplementedError("Generic active with default_contain is not supported, fallback to pure Python")
    return cos_comparison_active_1d(data, kernel=kernel, w1=w1, w2=w2, b1=b1, b2=b2,
                                    start=start, end=end, step=step,
                                    algorithm=algorithm,
                                    start_callback=start_callback, end_callback=end_callback,
                                    iter_a_callback=iter_a_callback, iter_b_callback=iter_b_callback,
                                    iter_stop_callback=iter_stop_callback,
                                    global_error_callback=global_error_callback,
                                    local_error_callback=local_error_callback,
                                    return_callback=return_callback,
                                    output=output, output_start=output_start, output_step=output_step)

# --------------- cos mode (vectorized) ---------------
def cos_1d(A, B, algorithm=_cos):
    A = np.asarray(A, dtype=np.float64)
    B = np.asarray(B, dtype=np.float64)
    if A.shape != B.shape:
        raise ValueError("the struct of two data set must be same!")
    a = np.sum(A * A)
    b = np.sum(B * B)
    ab = np.sum(A * B)
    return algorithm(a, b, ab, None)

cos_2d = cos_3d = cos_4d = cos_1d   # all dimensions handled identically

# --------------- statistic mode ---------------
def _mean_algorithm(N):
    """Return a lambda for mean computation via active mode."""
    return lambda a, b, ab, name: ab / N

def _variance_algorithm(N):
    """Return a lambda for variance computation via active mode."""
    def var_alg(a, b, ab, name):
        mean = ab / N
        return a / N - mean * mean
    return var_alg

def mean_local_1d(data, *arg, local_size=(1,), step=(1,), **kwarg):
    kernel = np.ones(local_size[0], dtype=np.float64)
    N = local_size[0]
    return cos_comparison_active_1d(data, kernel=kernel, step=step,
                                    algorithm=_mean_algorithm(N), **kwarg)

def mean_local_2d(data, *arg, local_size=((1,),), step=(1,1), **kwarg):
    h, w = len(local_size), len(local_size[0])
    kernel = np.ones((h, w), dtype=np.float64)
    N = h * w
    return cos_comparison_active_1d(data, kernel=kernel, step=step,
                                    algorithm=_mean_algorithm(N), **kwarg)

def mean_local_3d(data, *arg, local_size=(((1,),),), step=(1,1,1), **kwarg):
    d = len(local_size); h = len(local_size[0]); w = len(local_size[0][0])
    kernel = np.ones((d, h, w), dtype=np.float64)
    N = d * h * w
    return cos_comparison_active_1d(data, kernel=kernel, step=step,
                                    algorithm=_mean_algorithm(N), **kwarg)

def mean_local_4d(data, *arg, local_size=((((1,),),),), step=(1,1,1,1), **kwarg):
    n4 = len(local_size); n3 = len(local_size[0]); n2 = len(local_size[0][0]); n1 = len(local_size[0][0][0])
    kernel = np.ones((n4, n3, n2, n1), dtype=np.float64)
    N = n4 * n3 * n2 * n1
    return cos_comparison_active_1d(data, kernel=kernel, step=step,
                                    algorithm=_mean_algorithm(N), **kwarg)

def local_variance_1d(data, *arg, local_size=(1,), step=(1,), **kwarg):
    kernel = np.ones(local_size[0], dtype=np.float64)
    N = local_size[0]
    return cos_comparison_active_1d(data, kernel=kernel, step=step,
                                    algorithm=_variance_algorithm(N), **kwarg)

def local_variance_2d(data, *arg, local_size=((1,),), step=(1,1), **kwarg):
    h, w = len(local_size), len(local_size[0])
    kernel = np.ones((h, w), dtype=np.float64)
    N = h * w
    return cos_comparison_active_1d(data, kernel=kernel, step=step,
                                    algorithm=_variance_algorithm(N), **kwarg)

def local_variance_3d(data, *arg, local_size=(((1,),),), step=(1,1,1), **kwarg):
    d = len(local_size); h = len(local_size[0]); w = len(local_size[0][0])
    kernel = np.ones((d, h, w), dtype=np.float64)
    N = d * h * w
    return cos_comparison_active_1d(data, kernel=kernel, step=step,
                                    algorithm=_variance_algorithm(N), **kwarg)

def local_variance_4d(data, *arg, local_size=((((1,),),),), step=(1,1,1,1), **kwarg):
    n4 = len(local_size); n3 = len(local_size[0]); n2 = len(local_size[0][0]); n1 = len(local_size[0][0][0])
    kernel = np.ones((n4, n3, n2, n1), dtype=np.float64)
    N = n4 * n3 * n2 * n1
    return cos_comparison_active_1d(data, kernel=kernel, step=step,
                                    algorithm=_variance_algorithm(N), **kwarg)