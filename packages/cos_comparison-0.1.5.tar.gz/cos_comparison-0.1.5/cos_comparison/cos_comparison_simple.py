# cos_comparison_simple.py
# Simplified local similarity module – 1D to 4D hard‑coded loops.
# No callbacks, no name spaces, no external dependencies (only math).
# Works with nested lists (structured data).

from math import sqrt

NaN = float("nan")

# ----------------------------------------------------------------------
#  Similarity kernels (pure functions)
# ----------------------------------------------------------------------
def _cos(a, b, ab):
    if a == 0.0 and b == 0.0:
        return 1.0
    denom = sqrt(a * b)
    return 0.0 if denom == 0.0 else ab / denom

def _mod(a, b, ab):
    if a == 0.0 and b == 0.0:
        return 1.0
    denom = a + b
    return 0.0 if denom == 0.0 else 2.0 * sqrt(a * b) / denom

def _cosmod(a, b, ab):
    if a == 0.0 and b == 0.0:
        return 1.0
    denom = a + b
    return 0.0 if denom == 0.0 else 2.0 * ab / denom

# ----------------------------------------------------------------------
#  Passive mode (fixed dimensions)
# ----------------------------------------------------------------------
def cos_comparison_passive_1d(data, window_size=(1,), w1=1, w2=1, b1=0, b2=0,
                              start=(0,), end=(NaN,), step=(1,), d=(1,),
                              algorithm=_cos):
    ws = window_size[0]
    st = start[0]
    en = end[0] if not (end[0] != end[0]) else len(data)
    sp = step[0]
    dd = d[0]
    L = len(data)
    limit = en if en < L else L
    stop1 = limit - ws - dd
    if stop1 < st:
        return []
    num1 = (stop1 - st + 1) // sp
    out = [None] * num1
    main_sum = other_sum = cross_sum = 0.0
    for h in range(num1):
        m = st + h * sp
        main_sum = 0.0
        other_sum = 0.0
        cross_sum = 0.0
        for n in range(ws):
            x = m + n
            y = x + dd
            mt = w1 * data[x] + b1
            ot = w2 * data[y] + b2
            main_sum += mt * mt
            other_sum += ot * ot
            cross_sum += mt * ot
        out[h] = algorithm(main_sum, other_sum, cross_sum)
    return out


def cos_comparison_passive_2d(data, window_size=(1,1), w1=1, w2=1, b1=0, b2=0,
                              start=(0,0), end=(NaN,NaN), step=(1,1), d=(1,0),
                              algorithm=_cos):
    ws = window_size; st = start; en = end; sp = step; dd = d
    L0 = len(data)
    limit0 = en[0] if not (en[0] != en[0]) else L0
    stop0 = (limit0 if limit0 < L0 else L0) - ws[0] - dd[0]
    if stop0 < st[0]:
        return []
    num0 = (stop0 - st[0] + 1) // sp[0]
    out = [None] * num0
    for h0 in range(num0):
        m0 = st[0] + h0 * sp[0]
        L1 = len(data[m0])
        limit1 = en[1] if not (en[1] != en[1]) else L1
        stop1 = (limit1 if limit1 < L1 else L1) - ws[1] - dd[1]
        if stop1 < st[1]:
            num1 = 0
        else:
            num1 = (stop1 - st[1] + 1) // sp[1]
        out[h0] = [None] * num1
        for h1 in range(num1):
            m1 = st[1] + h1 * sp[1]
            main_sum = other_sum = cross_sum = 0.0
            for n0 in range(ws[0]):
                x0 = m0 + n0; y0 = x0 + dd[0]
                for n1 in range(ws[1]):
                    x1 = m1 + n1; y1 = x1 + dd[1]
                    mt = w1 * data[x0][x1] + b1
                    ot = w2 * data[y0][y1] + b2
                    main_sum += mt * mt
                    other_sum += ot * ot
                    cross_sum += mt * ot
            out[h0][h1] = algorithm(main_sum, other_sum, cross_sum)
    return out


def cos_comparison_passive_3d(data, window_size=(1,1,1), w1=1, w2=1, b1=0, b2=0,
                              start=(0,0,0), end=(NaN,NaN,NaN), step=(1,1,1), d=(1,0,0),
                              algorithm=_cos):
    ws = window_size; st = start; en = end; sp = step; dd = d
    L0 = len(data)
    limit0 = en[0] if not (en[0] != en[0]) else L0
    stop0 = (limit0 if limit0 < L0 else L0) - ws[0] - dd[0]
    if stop0 < st[0]: return []
    num0 = (stop0 - st[0] + 1) // sp[0]
    out = [None] * num0
    for h0 in range(num0):
        m0 = st[0] + h0 * sp[0]
        L1 = len(data[m0])
        limit1 = en[1] if not (en[1] != en[1]) else L1
        stop1 = (limit1 if limit1 < L1 else L1) - ws[1] - dd[1]
        if stop1 < st[1]: num1 = 0
        else: num1 = (stop1 - st[1] + 1) // sp[1]
        out[h0] = [None] * num1
        for h1 in range(num1):
            m1 = st[1] + h1 * sp[1]
            L2 = len(data[m0][m1])
            limit2 = en[2] if not (en[2] != en[2]) else L2
            stop2 = (limit2 if limit2 < L2 else L2) - ws[2] - dd[2]
            if stop2 < st[2]: num2 = 0
            else: num2 = (stop2 - st[2] + 1) // sp[2]
            out[h0][h1] = [None] * num2
            for h2 in range(num2):
                m2 = st[2] + h2 * sp[2]
                main_sum = other_sum = cross_sum = 0.0
                for n0 in range(ws[0]):
                    x0 = m0 + n0; y0 = x0 + dd[0]
                    for n1 in range(ws[1]):
                        x1 = m1 + n1; y1 = x1 + dd[1]
                        for n2 in range(ws[2]):
                            x2 = m2 + n2; y2 = x2 + dd[2]
                            mt = w1 * data[x0][x1][x2] + b1
                            ot = w2 * data[y0][y1][y2] + b2
                            main_sum += mt * mt
                            other_sum += ot * ot
                            cross_sum += mt * ot
                out[h0][h1][h2] = algorithm(main_sum, other_sum, cross_sum)
    return out


def cos_comparison_passive_4d(data, window_size=(1,1,1,1), w1=1, w2=1, b1=0, b2=0,
                              start=(0,0,0,0), end=(NaN,NaN,NaN,NaN), step=(1,1,1,1), d=(1,0,0,0),
                              algorithm=_cos):
    ws = window_size; st = start; en = end; sp = step; dd = d
    L0 = len(data)
    limit0 = en[0] if not (en[0] != en[0]) else L0
    stop0 = (limit0 if limit0 < L0 else L0) - ws[0] - dd[0]
    if stop0 < st[0]: return []
    num0 = (stop0 - st[0] + 1) // sp[0]
    out = [None] * num0
    for h0 in range(num0):
        m0 = st[0] + h0 * sp[0]
        L1 = len(data[m0])
        limit1 = en[1] if not (en[1] != en[1]) else L1
        stop1 = (limit1 if limit1 < L1 else L1) - ws[1] - dd[1]
        if stop1 < st[1]: num1 = 0
        else: num1 = (stop1 - st[1] + 1) // sp[1]
        out[h0] = [None] * num1
        for h1 in range(num1):
            m1 = st[1] + h1 * sp[1]
            L2 = len(data[m0][m1])
            limit2 = en[2] if not (en[2] != en[2]) else L2
            stop2 = (limit2 if limit2 < L2 else L2) - ws[2] - dd[2]
            if stop2 < st[2]: num2 = 0
            else: num2 = (stop2 - st[2] + 1) // sp[2]
            out[h0][h1] = [None] * num2
            for h2 in range(num2):
                m2 = st[2] + h2 * sp[2]
                L3 = len(data[m0][m1][m2])
                limit3 = en[3] if not (en[3] != en[3]) else L3
                stop3 = (limit3 if limit3 < L3 else L3) - ws[3] - dd[3]
                if stop3 < st[3]: num3 = 0
                else: num3 = (stop3 - st[3] + 1) // sp[3]
                out[h0][h1][h2] = [None] * num3
                for h3 in range(num3):
                    m3 = st[3] + h3 * sp[3]
                    main_sum = other_sum = cross_sum = 0.0
                    for n0 in range(ws[0]):
                        x0 = m0 + n0; y0 = x0 + dd[0]
                        for n1 in range(ws[1]):
                            x1 = m1 + n1; y1 = x1 + dd[1]
                            for n2 in range(ws[2]):
                                x2 = m2 + n2; y2 = x2 + dd[2]
                                for n3 in range(ws[3]):
                                    x3 = m3 + n3; y3 = x3 + dd[3]
                                    mt = w1 * data[x0][x1][x2][x3] + b1
                                    ot = w2 * data[y0][y1][y2][y3] + b2
                                    main_sum += mt * mt
                                    other_sum += ot * ot
                                    cross_sum += mt * ot
                    out[h0][h1][h2][h3] = algorithm(main_sum, other_sum, cross_sum)
    return out


# ----------------------------------------------------------------------
#  Active mode (fixed dimensions)
# ----------------------------------------------------------------------
def cos_comparison_active_1d(data, kernel=(1,), w1=1, w2=1, b1=0, b2=0,
                             start=(0,), end=(NaN,), step=(1,),
                             algorithm=_cos):
    ks = len(kernel)
    st = start[0]
    en = end[0] if not (end[0] != end[0]) else len(data)
    sp = step[0]
    L = len(data)
    limit = en if en < L else L
    stop1 = limit - ks
    if stop1 < st: return []
    num1 = (stop1 - st + 1) // sp
    out = [None] * num1
    for h in range(num1):
        m = st + h * sp
        main_sum = other_sum = cross_sum = 0.0
        for n in range(ks):
            mt = w1 * data[m+n] + b1
            ot = w2 * kernel[n] + b2
            main_sum += mt*mt; other_sum += ot*ot; cross_sum += mt*ot
        out[h] = algorithm(main_sum, other_sum, cross_sum)
    return out


def cos_comparison_active_2d(data, kernel=((1,),), w1=1, w2=1, b1=0, b2=0,
                             start=(0,0), end=(NaN,NaN), step=(1,1),
                             algorithm=_cos):
    ks = (len(kernel), len(kernel[0]))
    st = start; en = end; sp = step
    L0 = len(data)
    limit0 = en[0] if not (en[0] != en[0]) else L0
    stop0 = (limit0 if limit0 < L0 else L0) - ks[0]
    if stop0 < st[0]: return []
    num0 = (stop0 - st[0] + 1) // sp[0]
    out = [None] * num0
    for h0 in range(num0):
        m0 = st[0] + h0 * sp[0]
        L1 = len(data[m0])
        limit1 = en[1] if not (en[1] != en[1]) else L1
        stop1 = (limit1 if limit1 < L1 else L1) - ks[1]
        if stop1 < st[1]: num1 = 0
        else: num1 = (stop1 - st[1] + 1) // sp[1]
        out[h0] = [None] * num1
        for h1 in range(num1):
            m1 = st[1] + h1 * sp[1]
            main_sum = other_sum = cross_sum = 0.0
            for n0 in range(ks[0]):
                for n1 in range(ks[1]):
                    mt = w1 * data[m0+n0][m1+n1] + b1
                    ot = w2 * kernel[n0][n1] + b2
                    main_sum += mt*mt; other_sum += ot*ot; cross_sum += mt*ot
            out[h0][h1] = algorithm(main_sum, other_sum, cross_sum)
    return out


def cos_comparison_active_3d(data, kernel=(((1,),),), w1=1, w2=1, b1=0, b2=0,
                             start=(0,0,0), end=(NaN,NaN,NaN), step=(1,1,1),
                             algorithm=_cos):
    ks = (len(kernel), len(kernel[0]), len(kernel[0][0]))
    st = start; en = end; sp = step
    L0 = len(data)
    limit0 = en[0] if not (en[0] != en[0]) else L0
    stop0 = (limit0 if limit0 < L0 else L0) - ks[0]
    if stop0 < st[0]: return []
    num0 = (stop0 - st[0] + 1) // sp[0]
    out = [None] * num0
    for h0 in range(num0):
        m0 = st[0] + h0 * sp[0]
        L1 = len(data[m0])
        limit1 = en[1] if not (en[1] != en[1]) else L1
        stop1 = (limit1 if limit1 < L1 else L1) - ks[1]
        if stop1 < st[1]: num1 = 0
        else: num1 = (stop1 - st[1] + 1) // sp[1]
        out[h0] = [None] * num1
        for h1 in range(num1):
            m1 = st[1] + h1 * sp[1]
            L2 = len(data[m0][m1])
            limit2 = en[2] if not (en[2] != en[2]) else L2
            stop2 = (limit2 if limit2 < L2 else L2) - ks[2]
            if stop2 < st[2]: num2 = 0
            else: num2 = (stop2 - st[2] + 1) // sp[2]
            out[h0][h1] = [None] * num2
            for h2 in range(num2):
                m2 = st[2] + h2 * sp[2]
                main_sum = other_sum = cross_sum = 0.0
                for n0 in range(ks[0]):
                    for n1 in range(ks[1]):
                        for n2 in range(ks[2]):
                            mt = w1 * data[m0+n0][m1+n1][m2+n2] + b1
                            ot = w2 * kernel[n0][n1][n2] + b2
                            main_sum += mt*mt; other_sum += ot*ot; cross_sum += mt*ot
                out[h0][h1][h2] = algorithm(main_sum, other_sum, cross_sum)
    return out


def cos_comparison_active_4d(data, kernel=((((1,),),),), w1=1, w2=1, b1=0, b2=0,
                             start=(0,0,0,0), end=(NaN,NaN,NaN,NaN), step=(1,1,1,1),
                             algorithm=_cos):
    ks = (len(kernel), len(kernel[0]), len(kernel[0][0]), len(kernel[0][0][0]))
    st = start; en = end; sp = step
    L0 = len(data)
    limit0 = en[0] if not (en[0] != en[0]) else L0
    stop0 = (limit0 if limit0 < L0 else L0) - ks[0]
    if stop0 < st[0]: return []
    num0 = (stop0 - st[0] + 1) // sp[0]
    out = [None] * num0
    for h0 in range(num0):
        m0 = st[0] + h0 * sp[0]
        L1 = len(data[m0])
        limit1 = en[1] if not (en[1] != en[1]) else L1
        stop1 = (limit1 if limit1 < L1 else L1) - ks[1]
        if stop1 < st[1]: num1 = 0
        else: num1 = (stop1 - st[1] + 1) // sp[1]
        out[h0] = [None] * num1
        for h1 in range(num1):
            m1 = st[1] + h1 * sp[1]
            L2 = len(data[m0][m1])
            limit2 = en[2] if not (en[2] != en[2]) else L2
            stop2 = (limit2 if limit2 < L2 else L2) - ks[2]
            if stop2 < st[2]: num2 = 0
            else: num2 = (stop2 - st[2] + 1) // sp[2]
            out[h0][h1] = [None] * num2
            for h2 in range(num2):
                m2 = st[2] + h2 * sp[2]
                L3 = len(data[m0][m1][m2])
                limit3 = en[3] if not (en[3] != en[3]) else L3
                stop3 = (limit3 if limit3 < L3 else L3) - ks[3]
                if stop3 < st[3]: num3 = 0
                else: num3 = (stop3 - st[3] + 1) // sp[3]
                out[h0][h1][h2] = [None] * num3
                for h3 in range(num3):
                    m3 = st[3] + h3 * sp[3]
                    main_sum = other_sum = cross_sum = 0.0
                    for n0 in range(ks[0]):
                        for n1 in range(ks[1]):
                            for n2 in range(ks[2]):
                                for n3 in range(ks[3]):
                                    mt = w1 * data[m0+n0][m1+n1][m2+n2][m3+n3] + b1
                                    ot = w2 * kernel[n0][n1][n2][n3] + b2
                                    main_sum += mt*mt; other_sum += ot*ot; cross_sum += mt*ot
                    out[h0][h1][h2][h3] = algorithm(main_sum, other_sum, cross_sum)
    return out

# ----------------------------------------------------------------------
#  Static cosine between two tensors (flattened)
# ----------------------------------------------------------------------
def cos_1d(A, B, algorithm=_cos):
    if len(A) != len(B):
        raise ValueError("the struct of two data set must be same!")
    a = sum(x*x for x in A)
    b = sum(x*x for x in B)
    ab = sum(x*y for x,y in zip(A,B))
    return algorithm(a, b, ab)

def cos_2d(A, B, algorithm=_cos):
    flatA = []; flatB = []
    for ra, rb in zip(A, B):
        flatA.extend(ra); flatB.extend(rb)
    if len(flatA) != len(flatB):
        raise ValueError("mismatched shapes")
    a = sum(x*x for x in flatA)
    b = sum(x*x for x in flatB)
    ab = sum(x*y for x,y in zip(flatA, flatB))
    return algorithm(a, b, ab)

def cos_3d(A, B, algorithm=_cos):
    flatA = []; flatB = []
    for pa, pb in zip(A, B):
        for ra, rb in zip(pa, pb):
            flatA.extend(ra); flatB.extend(rb)
    a = sum(x*x for x in flatA)
    b = sum(x*x for x in flatB)
    ab = sum(x*y for x,y in zip(flatA, flatB))
    return algorithm(a, b, ab)

def cos_4d(A, B, algorithm=_cos):
    flatA = []; flatB = []
    for va, vb in zip(A, B):
        for pa, pb in zip(va, vb):
            for ra, rb in zip(pa, pb):
                flatA.extend(ra); flatB.extend(rb)
    a = sum(x*x for x in flatA)
    b = sum(x*x for x in flatB)
    ab = sum(x*y for x,y in zip(flatA, flatB))
    return algorithm(a, b, ab)

# ----------------------------------------------------------------------
#  Statistics (mean & variance) – built on active mode
# ----------------------------------------------------------------------
def _mean_alg(N):
    return lambda a,b,ab: ab / N

def _var_alg(N):
    def var_alg(a,b,ab):
        mean = ab / N
        return a / N - mean * mean
    return var_alg

def mean_local_1d(data, *arg, local_size=(1,), step=(1,), **kwarg):
    kernel = [1.0] * local_size[0]
    return cos_comparison_active_1d(data, kernel=kernel, step=step,
                                    algorithm=_mean_alg(local_size[0]), **kwarg)

def mean_local_2d(data, *arg, local_size=((1,),), step=(1,1), **kwarg):
    h, w = len(local_size), len(local_size[0])
    kernel = [[1.0]*w for _ in range(h)]
    return cos_comparison_active_2d(data, kernel=kernel, step=step,
                                    algorithm=_mean_alg(h*w), **kwarg)

def mean_local_3d(data, *arg, local_size=(((1,),),), step=(1,1,1), **kwarg):
    d, h, w = len(local_size), len(local_size[0]), len(local_size[0][0])
    kernel = [[[1.0]*w for _ in range(h)] for _ in range(d)]
    return cos_comparison_active_3d(data, kernel=kernel, step=step,
                                    algorithm=_mean_alg(d*h*w), **kwarg)

def mean_local_4d(data, *arg, local_size=((((1,),),),), step=(1,1,1,1), **kwarg):
    n4,n3,n2,n1 = len(local_size), len(local_size[0]), len(local_size[0][0]), len(local_size[0][0][0])
    kernel = [[[[1.0]*n1 for _ in range(n2)] for _ in range(n3)] for _ in range(n4)]
    return cos_comparison_active_4d(data, kernel=kernel, step=step,
                                    algorithm=_mean_alg(n4*n3*n2*n1), **kwarg)

def local_variance_1d(data, *arg, local_size=(1,), step=(1,), **kwarg):
    kernel = [1.0] * local_size[0]
    return cos_comparison_active_1d(data, kernel=kernel, step=step,
                                    algorithm=_var_alg(local_size[0]), **kwarg)

def local_variance_2d(data, *arg, local_size=((1,),), step=(1,1), **kwarg):
    h, w = len(local_size), len(local_size[0])
    kernel = [[1.0]*w for _ in range(h)]
    return cos_comparison_active_2d(data, kernel=kernel, step=step,
                                    algorithm=_var_alg(h*w), **kwarg)

def local_variance_3d(data, *arg, local_size=(((1,),),), step=(1,1,1), **kwarg):
    d, h, w = len(local_size), len(local_size[0]), len(local_size[0][0])
    kernel = [[[1.0]*w for _ in range(h)] for _ in range(d)]
    return cos_comparison_active_3d(data, kernel=kernel, step=step,
                                    algorithm=_var_alg(d*h*w), **kwarg)

def local_variance_4d(data, *arg, local_size=((((1,),),),), step=(1,1,1,1), **kwarg):
    n4,n3,n2,n1 = len(local_size), len(local_size[0]), len(local_size[0][0]), len(local_size[0][0][0])
    kernel = [[[[1.0]*n1 for _ in range(n2)] for _ in range(n3)] for _ in range(n4)]
    return cos_comparison_active_4d(data, kernel=kernel, step=step,
                                    algorithm=_var_alg(n4*n3*n2*n1), **kwarg)

# ----------------------------------------------------------------------
#  Generic aliases (simply call the 3D or 4D version as a fallback)
# ----------------------------------------------------------------------
cos_comparison_passive = cos_comparison_passive_3d   # default to 3D for generic name
cos_comparison_active  = cos_comparison_active_3d
mean_local            = mean_local_3d
local_variance        = local_variance_3d
