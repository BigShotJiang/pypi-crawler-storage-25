import itertools
from typing import List,Tuple

class default_b:
    def __init__(self,count):
        self.count=count
    def __getitem__(self,*a):
        if self.count ==0:
            return self.d
        elif self.count >=0:
            return default_b(self.count,self.d)
        else:
            raise ValueError(f"count must >=0,{self.count}<0")
    def index(self,place:Tuple[int,...]):
        return self.d

def cos_compare_2d(A:List[List[int]],
                   size:Tuple[int,int]=(1,1),
                   step:Tuple[int,int]=(1,0),
                   b=default_b(2,1)) -> List[List[List[float]]]:
    line=[]
    for a in range(len(a)-size[0]):
        g=[]
        for b in range(len(a[0])-size[1]):
            fork=sum(((A[a+m][b+n]+b[a+m][b+n])*(A[a+m+step[0]][b+n+step[1]]+b[a+m+step[0]][b+m+step[1]]) for m in range(size[0]) for n in range(size[1])))
            a=sum(((A[a+m][b+n]+b[a+m][b+m])**2 for m in range(size[0]) for n in range(size[1])))
            b=sum(((A[a+m+step[0]][b+n+step[1]]+b[a+m+step[0]][b+n+step[1]])**2 for m in range(size[0]) for n in range(size[1])))
            g.append(fork/(a*b))
        line.append(g)
    return line

def recursion_depth(A:List) ->int :
    a=A
    n=0
    while type(A) not in (list,tuple):
        a=a[0]
        n+=1
    return n

def forward_number(A:List) ->int:
    return (3**recursion_depth(A)-1)/2

def enum_int(start:Tuple[int,...],
             end:Tuple[int,...],
             step:Tuple[int,...],
             dimension:int=2) ->List(Tuple(int,...)):
    return listitertools.product(*((x for x in range(start[i],end[i],step[i])) for i in range(dimension)))

def enum_int_list(start:Tuple[int,...],
             end:Tuple[int,...],
             step:Tuple[int,...],
             dimension:int=2) ->List(Tuple(int,...)):
    return list(enum_int(start,end,step,dimension=dimension))

class matrix:
    def __init__(self,A:List):
        self.a : List=A
    def dimension(self) ->int:
        return recursion_depth(self.a)
    def index(self,place:Tuple[int,...]):
        a=self.a
        for i in place:
            a=a[i]
        return a

def cos_compare(A:List,
                size:Tuple[int,...],
                step:Tuple[int,...],
                start:Tuple[int,...]=None,
                end:Tuple[int,...]=None,
                b=None) -> List:
    a=matrix(A)
    if b==None:
        b=default_b(a.dimension,1)
    if start=None:
        start=(0 for _ in range(a.dimension))
    if end=None:
        c=matrix(A)
        end=[]
        for _ in range(a.dimension):
            end.append(len(c))
        end=tuple(end)
    for i in enum_int(start,(end[x]-step[x] for x in len(end)),step):
        pass
        
    
    
    
