# cos_comparison package initializer
#
# Dynamic fallback through user‑configurable backends.
# Use set_mode("backend_name") to force a specific implementation,
# or reset_mode() to return to the automatic fallback chain.
# Backends are resolved in order from:
#   1. config.json (a JSON list of backend module names)
#   2. environment variable COS_BACKEND (comma‑separated)
#   3. built‑in default ["cos_comparison"]

import importlib
import json
import os
from typing import Any

# ----------------------------------------------------------------------
#  File context manager (kept from original codebase)
# ----------------------------------------------------------------------
class file_context:
    __slots__ = ("file",)
    def __init__(self, *arg, **kwarg):
        self.file = open(*arg, **kwarg)
    def __enter__(self):
        self.file = self.file.__enter__()
        return self
    def __exit__(self, *arg):
        self.file.__exit__(*arg)
    def __del__(self):
        self.close()
    def __getattr__(self, name):
        return getattr(self.file, name)


# ----------------------------------------------------------------------
#  Backend order resolution (unchanged)
# ----------------------------------------------------------------------
def _get_backend_order() -> list:
    """Return the ordered list of backend module names to try."""
    conf_path = os.path.join(os.path.dirname(__file__), "config.json")
    if os.path.exists(conf_path):
        try:
            with file_context(conf_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, list):
                if data and isinstance(data[0], list):
                    backends, _ = data   # old [backends, plugin_dir] format
                else:
                    backends = data
                if isinstance(backends, list):
                    return backends
        except Exception:
            pass

    env_order = os.environ.get("COS_BACKEND", "").strip()
    if env_order:
        return [name.strip() for name in env_order.split(",") if name.strip()]

    return ["cos_comparison"]


# ----------------------------------------------------------------------
#  Backend manager – retains import cache and manual mode state
# ----------------------------------------------------------------------
class _BackendManager:
    def __init__(self):
        self._order = _get_backend_order()
        self._cache = {}          # name -> module | None
        self._manual = False
        self._current = None

    def import_backend(self, name: str):
        """Import a backend module once, cache the result (None on failure)."""
        if name in self._cache:
            return self._cache[name]
        try:
            if name.startswith("."):
                mod = importlib.import_module(name, package="cos_comparison")
            elif "." in name:
                mod = importlib.import_module(name)
            else:
                mod = importlib.import_module(f".{name}", package="cos_comparison")
            self._cache[name] = mod
            return mod
        except ImportError:
            self._cache[name] = None
            return None

    # ----- Public API -----
    def set_mode(self, name: str) -> bool:
        """Force the use of a specific backend. Returns True on success."""
        mod = self.import_backend(name)
        if mod is not None:
            self._manual = True
            self._current = name
            return True
        return False

    def reset_mode(self):
        """Return to automatic fallback mode."""
        self._manual = False
        self._current = None

    def current_backend(self):
        """Return the currently forced backend name (or None if automatic)."""
        return self._current if self._manual else None

    # ----- Internal lookup used by the wrapper -----
    def _resolve(self, func_name: str, args, kwargs):
        """Return a callable that handles the current resolution strategy."""
        if self._manual:
            mod = self.import_backend(self._current)  # already cached
            if mod is None:
                raise RuntimeError(
                    f"Manually selected backend '{self._current}' is not importable"
                )
            func = getattr(mod, func_name, None)
            if func is None:
                raise AttributeError(
                    f"Backend '{self._current}' does not provide '{func_name}'"
                )
            # In manual mode we always call the function directly, without fallback
            return func(*args, **kwargs)

        # Automatic fallback with import‑failure skipping
        last_exc = None
        for bname in self._order:
            mod = self.import_backend(bname)
            if mod is None:
                continue
            func = getattr(mod, func_name, None)
            if func is None:
                continue
            try:
                return func(*args, **kwargs)
            except NotImplementedError:
                continue
            except Exception as exc:
                last_exc = exc
                continue

        if last_exc is not None:
            raise last_exc
        raise RuntimeError(
            f"No backend among {self._order} provides a working "
            f"implementation for '{func_name}'."
        )


# ----------------------------------------------------------------------
#  Module‑level manager instance
# ----------------------------------------------------------------------
_manager = _BackendManager()

# Expose convenience functions
def set_mode(name: str) -> bool:
    """Force the package to use a specific backend. Returns True if successful."""
    return _manager.set_mode(name)

def reset_mode():
    """Return to automatic backend selection (fallback chain)."""
    _manager.reset_mode()

def current_backend():
    """Return the name of the currently forced backend, or None if in auto mode."""
    return _manager.current_backend()


# ----------------------------------------------------------------------
#  Callable wrapper that delegates to the manager
# ----------------------------------------------------------------------
class _FallbackWrapper:
    __slots__ = ("func_name",)
    def __init__(self, func_name: str):
        self.func_name = func_name
    def __call__(self, *args, **kwargs):
        return _manager._resolve(self.func_name, args, kwargs)


# ----------------------------------------------------------------------
#  Attribute interception (Python 3.7+)
# ----------------------------------------------------------------------
def __getattr__(name: str):
    wrapper = _FallbackWrapper(name)
    globals()[name] = wrapper
    return wrapper


def __dir__() -> list:
    return sorted(set(globals().keys()))
