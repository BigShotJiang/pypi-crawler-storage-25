"""
cos_comparison.py - Generic local similarity framework.
C acceleration is automatically used when a compiled library
(cos_core.so / .dll / .dylib) is present.  Falls back to pure Python
by raising NotImplementedError for unsupported features (callbacks etc.).
"""

import ctypes
import os
from math import sqrt

# -------------------------------------------------------------------
#  Duck‑typed loading of C library (same directory as this file)
# -------------------------------------------------------------------
_lib = None
_lib_dir = os.path.dirname(os.path.abspath(__file__))
# Common patterns – order does not matter, first success wins.
_candidates = [
    "cos_core.so", "cos_core.dll", "cos_core.dylib",
    "libcos_core.so", "libcos_core.dll", "libcos_core.dylib",
]
for _name in _candidates:
    _path = os.path.join(_lib_dir, _name)
    if os.path.isfile(_path):
        try:
            _lib = ctypes.CDLL(_path)
            break
        except OSError:
            continue

# -------------------------------------------------------------------
#  ctypes type definitions (only when library is available)
# -------------------------------------------------------------------
c_int64 = ctypes.c_int64
c_double = ctypes.c_double
c_int = ctypes.c_int

CUSTOM_ALGO_TYPE = ctypes.CFUNCTYPE(c_double, c_double, c_double, c_double, ctypes.c_void_p)

class Callbacks(ctypes.Structure):
    _fields_ = [("start_cb", ctypes.c_void_p),
                ("end_cb", ctypes.c_void_p),
                ("iter_a_cb", ctypes.c_void_p),
                ("iter_b_cb", ctypes.c_void_p),
                ("iter_stop_cb", ctypes.c_void_p),
                ("error_cb", ctypes.c_void_p)]

if _lib:
    _lib.cos_passive_generic.argtypes = [
        ctypes.POINTER(c_double),          # data flat
        ctypes.POINTER(c_int64),           # data_shape
        ctypes.POINTER(c_int64),           # data_strides
        c_int,                             # ndim
        ctypes.POINTER(c_int64),           # window_size
        ctypes.POINTER(c_int64),           # d
        ctypes.POINTER(c_int64),           # step
        ctypes.POINTER(c_int64),           # start
        ctypes.POINTER(c_int64),           # end
        c_double, c_double, c_double, c_double,  # w1,w2,b1,b2
        c_int,                             # algo_type
        ctypes.POINTER(c_double),          # out_data
        ctypes.POINTER(c_int64),           # out_shape
        ctypes.POINTER(c_int64),           # out_strides
        CUSTOM_ALGO_TYPE,                  # custom_algo
        ctypes.c_void_p,                   # custom_user_data
        ctypes.POINTER(Callbacks)          # callbacks
    ]
    _lib.cos_passive_generic.restype = c_int

    _lib.cos_active_generic.argtypes = [
        ctypes.POINTER(c_double),           # data flat
        ctypes.POINTER(c_int64),            # data_shape
        ctypes.POINTER(c_int64),            # data_strides
        ctypes.POINTER(c_double),           # kernel flat
        ctypes.POINTER(c_int64),            # kernel_shape
        ctypes.POINTER(c_int64),            # kernel_strides
        c_int,                              # ndim
        ctypes.POINTER(c_int64),            # step
        ctypes.POINTER(c_int64),            # start
        ctypes.POINTER(c_int64),            # end
        c_double, c_double, c_double, c_double,
        c_int,
        ctypes.POINTER(c_double),           # out_data
        ctypes.POINTER(c_int64),            # out_shape
        ctypes.POINTER(c_int64),            # out_strides
        CUSTOM_ALGO_TYPE,
        ctypes.c_void_p,
        ctypes.POINTER(Callbacks)
    ]
    _lib.cos_active_generic.restype = c_int

# -------------------------------------------------------------------
#  Built‑in similarity functions (also used for pure Python fallback)
# -------------------------------------------------------------------
_cos = lambda a, b, ab, name : ab / sqrt(a * b) if a * b else (1.0 if a == b else 0.0)
_mod = lambda a, b, ab, name : 2 * sqrt(a * b) / (a + b) if a * b else (1.0 if a == b else 0.0)
_cosmod = lambda a, b, ab, name : 2 * ab / (a + b) if a * b else (1.0 if a == b else 0.0)
_default_algorithm = lambda a, b, ab, name: (_cos(a,b,ab,name), _mod(a,b,ab,name), _cosmod(a,b,ab,name))

# -------------------------------------------------------------------
#  Helper: flatten nested list -> ctypes array + shape + strides
# -------------------------------------------------------------------
def _flatten(data):
    """Turn nested list into flat ctypes double array, shape, strides (C-order)."""
    if isinstance(data, (list, tuple)):
        if not data:
            raise ValueError("empty data not supported")
        first = data[0]
        if isinstance(first, (list, tuple)):
            # multi‑dimensional
            sub = [_flatten(sub) for sub in data]
            shapes = [s for _, s, _ in sub]
            # check shape uniformity
            if not all(s == shapes[0] for s in shapes):
                raise ValueError("jagged arrays not supported")
            flat_vals = []
            for arr, _, _ in sub:
                flat_vals.extend(arr)
            shape = (len(data),) + shapes[0]
            total = 1
            for s in shape:
                total *= s
            arr = (c_double * total)(*flat_vals)
            strides = []
            prod = 1
            for s in shape[::-1]:
                strides.insert(0, prod)
                prod *= s
            return arr, tuple(int(s) for s in shape), tuple(strides)
        else:
            # 1D
            arr = (c_double * len(data))(*data)
            return arr, (len(data),), (1,)
    else:
        raise TypeError("data must be nested list")

def _unflatten(flat, shape):
    """Convert flat sequence back to nested list."""
    if len(shape) == 1:
        return [flat[i] for i in range(shape[0])]
    else:
        outer = []
        stride = 1
        for s in shape[1:]:
            stride *= s
        for i in range(shape[0]):
            start = i * stride
            sub = [flat[j] for j in range(start, start + stride)]
            outer.append(_unflatten(sub, shape[1:]))
        return outer

# -------------------------------------------------------------------
#  Compute output shape (passive / active)
# -------------------------------------------------------------------
def _passive_out_shape(data_shape, ws, d, step, start, end):
    shape = []
    for i in range(len(data_shape)):
        L = data_shape[i]
        e = end[i] if i < len(end) else float('nan')
        if e != e:   # NaN
            e = L
        e = min(e, L)
        stop = e - ws[i] - d[i]
        if stop < start[i]:
            return ()
        n = (stop - start[i]) // step[i] + 1
        shape.append(n)
    return tuple(shape)

def _active_out_shape(data_shape, kernel_shape, step, start, end):
    shape = []
    for i in range(len(data_shape)):
        L = data_shape[i]
        e = end[i] if i < len(end) else float('nan')
        if e != e:
            e = L
        e = min(e, L)
        stop = e - kernel_shape[i]
        if stop < start[i]:
            return ()
        n = (stop - start[i]) // step[i] + 1
        shape.append(n)
    return tuple(shape)

def _create_output_array(shape):
    total = 1
    for s in shape:
        total *= s
    arr = (c_double * total)(*([0.0]*total))
    strides = []
    prod = 1
    for s in shape[::-1]:
        strides.insert(0, prod)
        prod *= s
    return arr, tuple(int(s) for s in shape), tuple(strides)

# -------------------------------------------------------------------
#  Custom algorithm wrapper for ctypes
# -------------------------------------------------------------------
_custom_cache = {}
def _wrap_custom(algo):
    if algo in _custom_cache:
        return _custom_cache[algo]
    @CUSTOM_ALGO_TYPE
    def wrapper(a, b, ab, _):
        return algo(a, b, ab, None)
    _custom_cache[algo] = wrapper
    return wrapper

# -------------------------------------------------------------------
#  Core passive / active drivers (return nested list or raise)
# -------------------------------------------------------------------
def _passive_generic(data, window_size, d, step, start, end,
                     w1, w2, b1, b2, algorithm,
                     start_cb, end_cb, iter_a_cb, iter_b_cb, iter_stop_cb, error_cb):
    if _lib is None:
        raise NotImplementedError("C library not available, fallback to Python")
    if any([start_cb, end_cb, iter_a_cb, iter_b_cb, iter_stop_cb, error_cb]):
        raise NotImplementedError("callbacks not supported in C backend, fallback")

    # algo type and custom wrapper
    algo_type = 3
    custom = None
    if algorithm is _cos:       algo_type = 0
    elif algorithm is _mod:     algo_type = 1
    elif algorithm is _cosmod:  algo_type = 2
    else:
        custom = _wrap_custom(algorithm)

    flat, shape, strides = _flatten(data)
    ndim = len(shape)

    # make sure all parameter tuples have length ndim
    def _pad(t, default):
        t = tuple(t)
        if len(t) >= ndim:
            return t[:ndim]
        return t + (default,) * (ndim - len(t))
    ws = _pad(window_size, 1)
    d  = _pad(d, 0)
    sp = _pad(step, 1)
    st = _pad(start, 0)
    en = tuple(end[i] if i < len(end) else float('nan') for i in range(ndim))

    out_shape = _passive_out_shape(shape, ws, d, sp, st, en)
    if not out_shape:
        return [] if ndim == 1 else [[] for _ in range(shape[0])]  # rough empty

    out_arr, out_shape_tuple, out_strides = _create_output_array(out_shape)

    # create ctypes arrays for parameters
    c_ws = (c_int64 * ndim)(*ws)
    c_d  = (c_int64 * ndim)(*d)
    c_sp = (c_int64 * ndim)(*sp)
    c_st = (c_int64 * ndim)(*st)
    en_clamped = [min(e if e == e else L, L) for L, e in zip(shape, en)]
    c_en = (c_int64 * ndim)(*en_clamped)
    c_shape = (c_int64 * ndim)(*shape)
    c_strides = (c_int64 * ndim)(*strides)
    c_out_shape = (c_int64 * ndim)(*out_shape_tuple)
    c_out_strides = (c_int64 * ndim)(*out_strides)

    cbs = Callbacks()
    ret = _lib.cos_passive_generic(flat, c_shape, c_strides, ndim,
                                   c_ws, c_d, c_sp, c_st, c_en,
                                   w1, w2, b1, b2, algo_type,
                                   out_arr, c_out_shape, c_out_strides,
                                   custom or CUSTOM_ALGO_TYPE(),
                                   ctypes.c_void_p() if custom is None else ctypes.c_void_p(),
                                   ctypes.byref(cbs))
    if ret == 0:
        raise NotImplementedError("C computation failed, fallback")

    return _unflatten(out_arr, out_shape_tuple)

def _active_generic(data, kernel, step, start, end,
                    w1, w2, b1, b2, algorithm,
                    start_cb, end_cb, iter_a_cb, iter_b_cb, iter_stop_cb, error_cb):
    if _lib is None:
        raise NotImplementedError("C library not available, fallback to Python")
    if any([start_cb, end_cb, iter_a_cb, iter_b_cb, iter_stop_cb, error_cb]):
        raise NotImplementedError("callbacks not supported in C backend, fallback")

    algo_type = 3
    custom = None
    if algorithm is _cos:       algo_type = 0
    elif algorithm is _mod:     algo_type = 1
    elif algorithm is _cosmod:  algo_type = 2
    else:
        custom = _wrap_custom(algorithm)

    data_flat, data_shape, data_strides = _flatten(data)
    kern_flat, kern_shape, kern_strides = _flatten(kernel)
    ndim = len(data_shape)
    if len(kern_shape) != ndim:
        raise ValueError("kernel must have same number of dimensions as data")

    def _pad(t, default):
        t = tuple(t)
        if len(t) >= ndim:
            return t[:ndim]
        return t + (default,) * (ndim - len(t))
    sp = _pad(step, 1)
    st = _pad(start, 0)
    en = tuple(end[i] if i < len(end) else float('nan') for i in range(ndim))

    out_shape = _active_out_shape(data_shape, kern_shape, sp, st, en)
    if not out_shape:
        return [] if ndim == 1 else [[] for _ in range(data_shape[0])]

    out_arr, out_shape_tuple, out_strides = _create_output_array(out_shape)

    c_sp = (c_int64 * ndim)(*sp)
    c_st = (c_int64 * ndim)(*st)
    en_clamped = [min(e if e == e else L, L) for L, e in zip(data_shape, en)]
    c_en = (c_int64 * ndim)(*en_clamped)
    c_data_shape = (c_int64 * ndim)(*data_shape)
    c_data_strides = (c_int64 * ndim)(*data_strides)
    c_kern_shape = (c_int64 * ndim)(*kern_shape)
    c_kern_strides = (c_int64 * ndim)(*kern_strides)
    c_out_shape = (c_int64 * ndim)(*out_shape_tuple)
    c_out_strides = (c_int64 * ndim)(*out_strides)

    cbs = Callbacks()
    ret = _lib.cos_active_generic(data_flat, c_data_shape, c_data_strides,
                                  kern_flat, c_kern_shape, c_kern_strides,
                                  ndim, c_sp, c_st, c_en,
                                  w1, w2, b1, b2, algo_type,
                                  out_arr, c_out_shape, c_out_strides,
                                  custom or CUSTOM_ALGO_TYPE(),
                                  ctypes.c_void_p() if custom is None else ctypes.c_void_p(),
                                  ctypes.byref(cbs))
    if ret == 0:
        raise NotImplementedError("C computation failed, fallback")

    return _unflatten(out_arr, out_shape_tuple)

# -------------------------------------------------------------------
#  Public API (1d‑4d passive / active) – identical signatures as original
# -------------------------------------------------------------------
def cos_comparison_passive_1d(data, *arg,
                              window_size=(1,), w1=1, w2=1, b1=0, b2=0,
                              start=(0,), end=(float('nan'),), step=(1,), d=(1,),
                              algorithm=_cos,
                              start_callback=None, end_callback=None,
                              iter_a_callback=None, iter_b_callback=None,
                              iter_stop_callback=None,
                              global_error_callback=lambda e,name: None,
                              local_error_callback=lambda e,name: None,
                              return_callback=lambda name: name.cos1,
                              output=None, output_start=None, output_step=None, **kwarg):
    try:
        res = _passive_generic(data, window_size, d, step, start, end,
                               w1, w2, b1, b2, algorithm,
                               start_callback, end_callback,
                               iter_a_callback, iter_b_callback, iter_stop_callback,
                               global_error_callback)
        # wrap result as expected by return_callback
        class Name: pass
        n = Name(); n.cos1 = res
        return return_callback(n)
    except NotImplementedError:
        raise  # let outer fallback handle

cos_comparison_passive_2d = cos_comparison_passive_1d
cos_comparison_passive_3d = cos_comparison_passive_1d
cos_comparison_passive_4d = cos_comparison_passive_1d

def cos_comparison_active_1d(data, *arg,
                             kernel=(1,), w1=1, w2=1, b1=0, b2=0,
                             start=(0,), end=(float('nan'),), step=(1,),
                             algorithm=_cos,
                             start_callback=None, end_callback=None,
                             iter_a_callback=None, iter_b_callback=None,
                             iter_stop_callback=None,
                             global_error_callback=lambda e,name: None,
                             local_error_callback=lambda e,name: None,
                             return_callback=lambda name: name.cos1,
                             output=None, output_start=None, output_step=None, **kwarg):
    try:
        res = _active_generic(data, kernel, step, start, end,
                              w1, w2, b1, b2, algorithm,
                              start_callback, end_callback,
                              iter_a_callback, iter_b_callback, iter_stop_callback,
                              global_error_callback)
        class Name: pass
        n = Name(); n.cos1 = res
        return return_callback(n)
    except NotImplementedError:
        raise

cos_comparison_active_2d = cos_comparison_active_1d
cos_comparison_active_3d = cos_comparison_active_1d
cos_comparison_active_4d = cos_comparison_active_1d

# -------------------------------------------------------------------
#  Generic functions (raise if default_contain is used)
# -------------------------------------------------------------------
class default_contain:  # minimal placeholder (original class retained elsewhere)
    pass

def cos_comparison_passive(data, *arg,
                           window_size=None, w1=1, w2=1, b1=0, b2=0,
                           start=None, end=None, step=None, d=None,
                           algorithm=_cos,
                           start_callback=None, end_callback=None,
                           iter_a_callback=None, iter_b_callback=None,
                           iter_stop_callback=None,
                           global_error_callback=lambda e,name: None,
                           local_error_callback=lambda e,name: None,
                           return_callback=lambda name: name.cos1,
                           output=None, output_start=None, output_step=None, **kwarg):
    if (isinstance(window_size, default_contain) or isinstance(start, default_contain)
        or isinstance(end, default_contain) or isinstance(step, default_contain)
        or isinstance(d, default_contain)):
        raise NotImplementedError("generic mode with default_contain not supported in C, fallback")
    return cos_comparison_passive_1d(data, window_size=window_size, w1=w1, w2=w2, b1=b1, b2=b2,
                                     start=start, end=end, step=step, d=d, algorithm=algorithm,
                                     start_callback=start_callback, end_callback=end_callback,
                                     iter_a_callback=iter_a_callback, iter_b_callback=iter_b_callback,
                                     iter_stop_callback=iter_stop_callback,
                                     global_error_callback=global_error_callback,
                                     local_error_callback=local_error_callback,
                                     return_callback=return_callback,
                                     output=output, output_start=output_start, output_step=output_step)

def cos_comparison_active(data, *arg,
                          kernel=None, w1=1, w2=1, b1=0, b2=0,
                          start=None, end=None, step=None,
                          algorithm=_cos,
                          start_callback=None, end_callback=None,
                          iter_a_callback=None, iter_b_callback=None,
                          iter_stop_callback=None,
                          global_error_callback=lambda e,name: None,
                          local_error_callback=lambda e,name: None,
                          return_callback=lambda name: name.cos1,
                          output=None, output_start=None, output_step=None, **kwarg):
    if isinstance(kernel, default_contain) or kernel is None:
        raise NotImplementedError("generic active with default_contain not supported in C, fallback")
    return cos_comparison_active_1d(data, kernel=kernel, w1=w1, w2=w2, b1=b1, b2=b2,
                                    start=start, end=end, step=step, algorithm=algorithm,
                                    start_callback=start_callback, end_callback=end_callback,
                                    iter_a_callback=iter_a_callback, iter_b_callback=iter_b_callback,
                                    iter_stop_callback=iter_stop_callback,
                                    global_error_callback=global_error_callback,
                                    local_error_callback=local_error_callback,
                                    return_callback=return_callback,
                                    output=output, output_start=output_start, output_step=output_step)

# -------------------------------------------------------------------
#  Static cos functions (pure Python, fast enough)
# -------------------------------------------------------------------
def cos_1d(A, B, algorithm=_cos):
    if len(A) != len(B):
        raise ValueError("the struct of two data set must be same!")
    a = sum(x*x for x in A)
    b = sum(x*x for x in B)
    ab = sum(x*y for x,y in zip(A,B))
    return algorithm(a, b, ab, None)

def cos_2d(A, B, algorithm=_cos):
    # flatten both and compute
    flatA = []
    flatB = []
    for rowA, rowB in zip(A, B):
        flatA.extend(rowA)
        flatB.extend(rowB)
    if len(flatA) != len(flatB):
        raise ValueError("mismatched shapes")
    a = sum(x*x for x in flatA)
    b = sum(x*x for x in flatB)
    ab = sum(x*y for x,y in zip(flatA, flatB))
    return algorithm(a, b, ab, None)

def cos_3d(A, B, algorithm=_cos):
    flatA = []
    flatB = []
    for planeA, planeB in zip(A, B):
        for rowA, rowB in zip(planeA, planeB):
            flatA.extend(rowA)
            flatB.extend(rowB)
    a = sum(x*x for x in flatA)
    b = sum(x*x for x in flatB)
    ab = sum(x*y for x,y in zip(flatA, flatB))
    return algorithm(a, b, ab, None)

def cos_4d(A, B, algorithm=_cos):
    flatA = []
    flatB = []
    for volA, volB in zip(A, B):
        for planeA, planeB in zip(volA, volB):
            for rowA, rowB in zip(planeA, planeB):
                flatA.extend(rowA)
                flatB.extend(rowB)
    a = sum(x*x for x in flatA)
    b = sum(x*x for x in flatB)
    ab = sum(x*y for x,y in zip(flatA, flatB))
    return algorithm(a, b, ab, None)

# -------------------------------------------------------------------
#  Statistic mode (mean / variance) – re‑use active mode via C
# -------------------------------------------------------------------
def _mean_alg(N):
    def inner(a, b, ab, name):
        return ab / N
    return inner

def _var_alg(N):
    def inner(a, b, ab, name):
        mean = ab / N
        return a / N - mean * mean
    return inner

def mean_local_1d(data, *arg, local_size=(1,), step=(1,), **kwarg):
    kernel = [1.0] * local_size[0]
    return cos_comparison_active_1d(data, kernel=kernel, step=step,
                                    algorithm=_mean_alg(local_size[0]), **kwarg)

def mean_local_2d(data, *arg, local_size=((1,),), step=(1,1), **kwarg):
    h, w = len(local_size), len(local_size[0])
    kernel = [[1.0]*w for _ in range(h)]
    return cos_comparison_active_1d(data, kernel=kernel, step=step,
                                    algorithm=_mean_alg(h*w), **kwarg)

def mean_local_3d(data, *arg, local_size=(((1,),),), step=(1,1,1), **kwarg):
    d, h, w = len(local_size), len(local_size[0]), len(local_size[0][0])
    kernel = [[[1.0]*w for _ in range(h)] for _ in range(d)]
    return cos_comparison_active_1d(data, kernel=kernel, step=step,
                                    algorithm=_mean_alg(d*h*w), **kwarg)

def mean_local_4d(data, *arg, local_size=((((1,),),),), step=(1,1,1,1), **kwarg):
    n4, n3, n2, n1 = len(local_size), len(local_size[0]), len(local_size[0][0]), len(local_size[0][0][0])
    kernel = [[[[1.0]*n1 for _ in range(n2)] for _ in range(n3)] for _ in range(n4)]
    return cos_comparison_active_1d(data, kernel=kernel, step=step,
                                    algorithm=_mean_alg(n4*n3*n2*n1), **kwarg)

def local_variance_1d(data, *arg, local_size=(1,), step=(1,), **kwarg):
    kernel = [1.0] * local_size[0]
    return cos_comparison_active_1d(data, kernel=kernel, step=step,
                                    algorithm=_var_alg(local_size[0]), **kwarg)

def local_variance_2d(data, *arg, local_size=((1,),), step=(1,1), **kwarg):
    h, w = len(local_size), len(local_size[0])
    kernel = [[1.0]*w for _ in range(h)]
    return cos_comparison_active_1d(data, kernel=kernel, step=step,
                                    algorithm=_var_alg(h*w), **kwarg)

def local_variance_3d(data, *arg, local_size=(((1,),),), step=(1,1,1), **kwarg):
    d, h, w = len(local_size), len(local_size[0]), len(local_size[0][0])
    kernel = [[[1.0]*w for _ in range(h)] for _ in range(d)]
    return cos_comparison_active_1d(data, kernel=kernel, step=step,
                                    algorithm=_var_alg(d*h*w), **kwarg)

def local_variance_4d(data, *arg, local_size=((((1,),),),), step=(1,1,1,1), **kwarg):
    n4, n3, n2, n1 = len(local_size), len(local_size[0]), len(local_size[0][0]), len(local_size[0][0][0])
    kernel = [[[[1.0]*n1 for _ in range(n2)] for _ in range(n3)] for _ in range(n4)]
    return cos_comparison_active_1d(data, kernel=kernel, step=step,
                                    algorithm=_var_alg(n4*n3*n2*n1), **kwarg)