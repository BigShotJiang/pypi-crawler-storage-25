# it provides basic functions of cos_comparsion module,an AI algorithm set
#
# core : information is produced by local comparison in raw data 

#--------------------- import ------------------------------
from math import sqrt

#-------------------- constant -----------------------------
NaN = float("nan")

#------------------ tool module -----------------       
def multiple_chain(iterable,base=1):
    """
    Use base to multiple element of iterable object in turn.
    """
    for m in iterable:
        base=base*m
    return base

def add_chain(iterable,base=0):
    """
    Use base to add element of iterable object in turn.
    """
    for m in iterable:
        base=base+m
    return base

def create_void_list(leng_list=(1,),default=None):
    li=default
    for i in range(-1,-len(leng_list)-1,-1):
        li=[li for _ in range(leng_list[i])]
    return li

def vector_chain_compute(A):
    a=A
    def compute(vector):
        nonlocal a
        leng=len(a)
        return (sum((m*n for m,n in zip(vector,a[i]))) for i in range(leng))
    def fix(new):
        nonlocal a
        a=new
    def get():
        return a
    return compute,fix,get

#------------------- class support --------------------------
#     --------------- type support -----------------
class relative_bool:
    __slots__=("true_w","false_w")
    def __init__(self,true_w=1,false_w=0):
        self.true_w=true_w
        self.false_w=false_w
    def __bool__(self) -> bool:
        if self.true_w:
            return True
        else:
            return False

class vector_map_as_tensor:
    __slots__=("vector","tensor_size","dimension","start","end","p","cache")
    def __init__(self,vector,tensor_size,start=0,end=None,p:int=0,cache=None):
        self.vector = vector
        self.tensor_size = tensor_size
        self.start , self.end = start , (len(vector) if end is None else end)
        self.p , self.cache = p , (multiple_chain(tensor_size[1:]))
    def __getitem__(self,index:int):
        if self.tensor_size-self.p:
            new=self.start+index*self.cache
            new_p=self.p+1
            return vector_map_as_tensor(self.vector,self.tensor_size,
                                        start=new,end=new+self.cache,
                                        p=new_p,
                                        cache=self.cache//self.tensor_size[new_p])
        else:
            return self.vector[start+index]
    def __setitem__(self,key,value):
        if self.tensor_size-self.p-1:
            raise IndexError("it does not reach the lowest layer.")
        else:
            self.vector[self.start+key]=value
    def __len__(self) ->int :
        return self.tensor_size[self.p]
    def mean(self):
        return sum(self.vector[start:end])/(self.end-self.start)

#    ------------ contain support -------------
class name_space:
    def __init__(self, **kwarg):
        self.__slots__=kwarg.keys()
        for k in kwarg.keys():
            setattr(self,k,kwarg[k])

class flexible_name_space:
    def __init__(self, **kwarg):
        self.__dict__.update(kwarg)

class contain_in_bases:
    __slots__=("base","data")
    def __init__(self,data,base):
        self.base=base
        self.data=data
    def __mul__(self,mu):
        self.base*=mu
        return self
    def __getitem__(self,index:int):
        temp=self.data[index]
        if hasattr(temp,"__getitem__"):
            return contain_in_bases(temp,self.base)
        else:
            return temp*self.base
    def __setitem__(self,key,val):
        self.data[key]=val
    
class default_contain:
    __slots__=("default","deep","default_dict","leng")
    def __init__(self,default,deep=1,leng=(10,),default_dict=None):
        self.default,self.deep,self.default_dict,self.leng=default,deep,(default_dict if default_dict else{}),leng
    def __len__(self):
        return self.leng[0]
    def __getitem__(self,index):
        if self.deep-1:
            _ , *leng = self.leng
            return default_contain(self.default,deep=self.deep-1,
                                   leng=leng,
                                   default_dict=self.default_dict)
        else:
            return self.default_dict.get(index, self.default)

class flexible_contain:
    __slots__=("contain","buffer")
    def __init__(self,init_buffer:int=64):
        self.contain=[None for _ in range(init_buffer)]
        self.buffer=init_buffer
    def __len__(self):
        return self.buffer
    def __getitem__(self,index:int) -> None:
        try:
            return self.contain.__getitem__(index)
        except IndexError:
            self.contain+=[None for _ in range(index-self.buffer)]
            self.buffer=index+1
            return self.contain.__getitem__(index)
        except Exception:
            raise
    def __setitem__(self,key:int,value) -> None:
        try:
            self.contain.__setitem__(key,value)
        except IndexError:
            self.contain+=[None for _ in range(key-self.buffer)]
            self.buffer=key+1
            self.contain.__setitem__(key,value)
        except Exception:
            raise


        
#----------------- private module ---------------------------
_cos = lambda a, b, ab, name : ab / sqrt(a * b) if a * b else (1.0 if a == b else 0.0)
_mod = lambda a, b, ab, name : 2 * sqrt(a * b) / (a + b) if a * b else (1.0 if a == b else 0.0)
_cosmod = lambda a, b, ab, name : 2 * ab / (a + b) if a * b else (1.0 if a == b else 0.0)
_default_algorithm = lambda a, b, ab, name: (_cos(a, b, ab, name), _mod(a, b, ab, name), _cosmod(a, b, ab, name))
private_dict = {
    "_cos": _cos,
    "_mod": _mod,
    "_cosmod": _cosmod,
    "_default_algorithm": _default_algorithm
}


#-------------------- core ----------------------------------
#    ------------------ passive mode ------------------------
def cos_comparison_passive_1d(data,
                              *arg,
                              window_size=(1,),
                              w1=1, w2=1,
                              b1=0, b2=0,
                              start=(0,), end=(NaN,),
                              step=(1,), d=(1,),
                              algorithm=_default_algorithm,
                              start_callback=None,
                              end_callback=None,
                              iter_a_callback=None,
                              iter_b_callback=None,
                              iter_stop_callback=None,
                              global_error_callback=lambda e, name: None,
                              local_error_callback=lambda e, name: None,
                              return_callback=lambda name: name.cos1,
                              output=None,
                              output_start=None,
                              output_step=None,
                              **kwarg):
    """
    process 1 dimension tensor data by passive mode.
    it can be set by setting callback functions.
    """
    try:
        ws = window_size
        st = start; en = end; sp = step; dd = d
        ost = output_start if output_start is not None else (0,)
        ostp = output_step if output_step is not None else (1,)
        
        stop1 = (en[0] if en[0] < len(data) else len(data)) - ws[0] - dd[0]
        num1 = (stop1 - st[0] + 1) // sp[0]
        
        name = name_space(
            cos1 = output if output is not None else [None] * num1,
            window_size=ws,
            linear=[w1, w2, b1, b2],
            start=st, end=en, step=sp, d=dd,
            algorithm=algorithm,
            start_callback=start_callback, end_callback=end_callback,
            iter_a_callback=iter_a_callback, iter_b_callback=iter_b_callback,
            iter_stop_callback=iter_stop_callback,
            global_error_callback=global_error_callback, local_error_callback=local_error_callback,
            return_callback=return_callback,
            stop=[None, stop1],
            num=[None, num1],
            m=[None, None],
            h=[None, None],
            n=[None, None]
        )

        if start_callback:
            start_callback(name)

        stop, num, m, h, n = name.stop, name.num, name.m, name.h, name.n
        linear = name.linear
        cos1 = name.cos1

        main = 0; other = 0; mu = 0
        for h[1] in range(num[1]):
            m[1] = st[0] + h[1] * sp[0]
            try:
                main *= 0; other *= 0; mu *= 0
                for n[1] in range(ws[0]):
                    x1 = m[1] + n[1]
                    y1 = x1 + dd[0]

                    if iter_a_callback:
                        iter_a_callback(name)

                    [w1, w2, b1, b2] = linear
                    main_tmp = w1 * data[x1] + b1
                    other_tmp = w2 * data[y1] + b2

                    main += main_tmp * main_tmp
                    other += other_tmp * other_tmp
                    mu += main_tmp * other_tmp

                if iter_b_callback:
                    iter_b_callback(name)

                write_idx = ost[0] + h[1] * ostp[0]
                cos1[write_idx] = algorithm(main, other, mu, name)
            except StopIteration as e:
                if iter_stop_callback:
                    iter_stop_callback(e, name)
            except Exception as e:
                if local_error_callback:
                    local_error_callback(e, name)

        if end_callback:
            end_callback(name)
    except Exception as e:
        if global_error_callback:
            global_error_callback(e, name)
    return return_callback(name)


def cos_comparison_passive_2d(data,
                              *arg,
                              window_size=(1, 1),
                              w1=1, w2=1,
                              b1=0, b2=0,
                              start=(0, 0), end=(NaN, NaN),
                              step=(1, 1), d=(1, 0),
                              algorithm=_default_algorithm,
                              start_callback=None,
                              end_callback=None,
                              iter_a_callback=None,
                              iter_b_callback=None,
                              iter_stop_callback=None,
                              global_error_callback=lambda e, name: None,
                              local_error_callback=lambda e, name: None,
                              return_callback=lambda name: name.cos1,
                              output=None,
                              output_start=None,
                              output_step=None,
                              **kwarg):
    """
    process 2 dimension tensor data by passive mode.
    it can be set by setting callback functions.
    """
    try:
        ws = window_size
        st = start; en = end; sp = step; dd = d
        ost = output_start if output_start is not None else (0,0)
        ostp = output_step if output_step is not None else (1,1)
        
        stop1 = (en[0] if en[0] < len(data) else len(data)) - ws[0] - dd[0]
        num1 = (stop1 - st[0] + 1) // sp[0]
        
        name = name_space(
            cos1 = output if output is not None else [None] * num1,
            window_size=ws,
            linear=[w1, w2, b1, b2],
            start=st, end=en, step=sp, d=dd,
            algorithm=algorithm,
            start_callback=start_callback, end_callback=end_callback,
            iter_a_callback=iter_a_callback, iter_b_callback=iter_b_callback,
            iter_stop_callback=iter_stop_callback,
            global_error_callback=global_error_callback, local_error_callback=local_error_callback,
            return_callback=return_callback,
            stop=[None, stop1, None],
            num=[None, num1, None],
            m=[None, None, None],
            h=[None, None, None],
            n=[None, None, None]
        )

        if start_callback:
            start_callback(name)

        stop, num, m, h, n = name.stop, name.num, name.m, name.h, name.n
        linear = name.linear
        cos1 = name.cos1

        main = 0; other = 0; mu = 0
        for h[1] in range(num[1]):
            m[1] = st[0] + h[1] * sp[0]
            stop[2] = (en[1] if en[1] < len(data[m[1]]) else len(data[m[1]])) - ws[1] - dd[1]
            num[2] = (stop[2] - st[1] + 1) // sp[1]
            cos2 = [None] * num[2] if output is None else cos1[ost[0] + h[1] * ostp[0]]
            if output is None:
                cos1[h[1]] = cos2

            for h[2] in range(num[2]):
                m[2] = st[1] + h[2] * sp[1]
                try:
                    main *= 0; other *= 0; mu *= 0
                    for n[1] in range(ws[0]):
                        x1 = m[1] + n[1]
                        y1 = x1 + dd[0]
                        for n[2] in range(ws[1]):
                            x2 = m[2] + n[2]
                            y2 = x2 + dd[1]

                            if iter_a_callback:
                                iter_a_callback(name)

                            (w1, w2, b1, b2) = linear
                            main_tmp = w1 * data[x1][x2] + b1
                            other_tmp = w2 * data[y1][y2] + b2

                            main += main_tmp * main_tmp
                            other += other_tmp * other_tmp
                            mu += main_tmp * other_tmp

                    if iter_b_callback:
                        iter_b_callback(name)

                    write_row = ost[0] + h[1] * ostp[0]
                    write_col = ost[1] + h[2] * ostp[1]
                    cos1[write_row][write_col] = algorithm(main, other, mu, name)
                except StopIteration as e:
                    if iter_stop_callback:
                        iter_stop_callback(e, name)
                except Exception as e:
                    if local_error_callback:
                        local_error_callback(e, name)

        if end_callback:
            end_callback(name)
    except Exception as e:
        if global_error_callback:
            global_error_callback(e, name)
    return return_callback(name)


def cos_comparison_passive_3d(data,
                              *arg,
                              window_size=(1, 1, 1),
                              w1=1, w2=1,
                              b1=0, b2=0,
                              start=(0, 0, 0), end=(NaN, NaN, NaN),
                              step=(1, 1, 1), d=(1, 0, 0),
                              algorithm=_default_algorithm,
                              start_callback=None,
                              end_callback=None,
                              iter_a_callback=None,
                              iter_b_callback=None,
                              iter_stop_callback=None,
                              global_error_callback=lambda e, name: None,
                              local_error_callback=lambda e, name: None,
                              return_callback=lambda name: name.cos1,
                              output=None,
                              output_start=None,
                              output_step=None,
                              **kwarg):
    """
    process 3 dimension tensor data by passive mode.
    it can be set by setting callback functions.
    """
    try:
        ws = window_size
        st = start; en = end; sp = step; dd = d
        ost = output_start if output_start is not None else (0,0,0)
        ostp = output_step if output_step is not None else (1,1,1)
        
        stop1 = (en[0] if en[0] < len(data) else len(data)) - ws[0] - dd[0]
        num1 = (stop1 - st[0] + 1) // sp[0]
        
        name = name_space(
            cos1 = output if output is not None else [None] * num1,
            window_size=ws,
            linear=[w1, w2, b1, b2],
            start=st, end=en, step=sp, d=dd,
            algorithm=algorithm,
            start_callback=start_callback, end_callback=end_callback,
            iter_a_callback=iter_a_callback, iter_b_callback=iter_b_callback,
            iter_stop_callback=iter_stop_callback,
            global_error_callback=global_error_callback, local_error_callback=local_error_callback,
            return_callback=return_callback,
            stop=[None, stop1, None, None],
            num=[None, num1, None, None],
            m=[None, None, None, None],
            h=[None, None, None, None],
            n=[None, None, None, None]
        )

        if start_callback:
            start_callback(name)

        stop, num, m, h, n = name.stop, name.num, name.m, name.h, name.n
        linear = name.linear
        cos1 = name.cos1

        main = 0; other = 0; mu = 0
        for h[1] in range(num[1]):
            m[1] = st[0] + h[1] * sp[0]
            stop[2] = (en[1] if en[1] < len(data[m[1]]) else len(data[m[1]])) - ws[1] - dd[1]
            num[2] = (stop[2] - st[1] + 1) // sp[1]
            cos2 = [None] * num[2] if output is None else cos1[ost[0] + h[1] * ostp[0]]
            if output is None:
                cos1[h[1]] = cos2

            for h[2] in range(num[2]):
                m[2] = st[1] + h[2] * sp[1]
                stop[3] = (en[2] if en[2] < len(data[m[1]][m[2]]) else len(data[m[1]][m[2]])) - ws[2] - dd[2]
                num[3] = (stop[3] - st[2] + 1) // sp[2]
                cos3 = [None] * num[3] if output is None else cos1[ost[0] + h[1] * ostp[0]][ost[1] + h[2] * ostp[1]]
                if output is None:
                    cos1[h[1]][h[2]] = cos3

                for h[3] in range(num[3]):
                    m[3] = st[2] + h[3] * sp[2]
                    try:
                        main *= 0; other *= 0; mu *= 0
                        for n[1] in range(ws[0]):
                            x1 = m[1] + n[1]
                            y1 = x1 + dd[0]
                            for n[2] in range(ws[1]):
                                x2 = m[2] + n[2]
                                y2 = x2 + dd[1]
                                for n[3] in range(ws[2]):
                                    x3 = m[3] + n[3]
                                    y3 = x3 + dd[2]

                                    if iter_a_callback:
                                        iter_a_callback(name)

                                    (w1, w2, b1, b2) = linear
                                    main_tmp = w1 * data[x1][x2][x3] + b1
                                    other_tmp = w2 * data[y1][y2][y3] + b2

                                    main += main_tmp * main_tmp
                                    other += other_tmp * other_tmp
                                    mu += main_tmp * other_tmp

                        if iter_b_callback:
                            iter_b_callback(name)

                        w0 = ost[0] + h[1] * ostp[0]
                        w1 = ost[1] + h[2] * ostp[1]
                        w2 = ost[2] + h[3] * ostp[2]
                        cos1[w0][w1][w2] = algorithm(main, other, mu, name)
                    except StopIteration as e:
                        if iter_stop_callback:
                            iter_stop_callback(e, name)
                    except Exception as e:
                        if local_error_callback:
                            local_error_callback(e, name)

        if end_callback:
            end_callback(name)
    except Exception as e:
        if global_error_callback:
            global_error_callback(e, name)
    return return_callback(name)


def cos_comparison_passive_4d(data,
                              *arg,
                              window_size=(1, 1, 1, 1),
                              w1=1, w2=1,
                              b1=0, b2=0,
                              start=(0, 0, 0, 0), end=(NaN, NaN, NaN, NaN),
                              step=(1, 1, 1, 1), d=(1, 0, 0, 0),
                              algorithm=_default_algorithm,
                              start_callback=None,
                              end_callback=None,
                              iter_a_callback=None,
                              iter_b_callback=None,
                              iter_stop_callback=None,
                              global_error_callback=lambda e, name: None,
                              local_error_callback=lambda e, name: None,
                              return_callback=lambda name: name.cos1,
                              output=None,
                              output_start=None,
                              output_step=None,
                              **kwarg):
    """
    process 4 dimension tensor data by passive mode.
    it can be set by setting callback functions.
    """
    try:
        ws = window_size
        st = start; en = end; sp = step; dd = d
        ost = output_start if output_start is not None else (0,0,0,0)
        ostp = output_step if output_step is not None else (1,1,1,1)
        
        stop1 = (en[0] if en[0] < len(data) else len(data)) - ws[0] - dd[0]
        num1 = (stop1 - st[0] + 1) // sp[0]
        
        name = name_space(
            cos1 = output if output is not None else [None] * num1,
            window_size=ws,
            linear=[w1, w2, b1, b2],
            start=st, end=en, step=sp, d=dd,
            algorithm=algorithm,
            start_callback=start_callback, end_callback=end_callback,
            iter_a_callback=iter_a_callback, iter_b_callback=iter_b_callback,
            iter_stop_callback=iter_stop_callback,
            global_error_callback=global_error_callback, local_error_callback=local_error_callback,
            return_callback=return_callback,
            stop=[None, stop1, None, None, None],
            num=[None, num1, None, None, None],
            m=[None, None, None, None, None],
            h=[None, None, None, None, None],
            n=[None, None, None, None, None]
        )

        if start_callback:
            start_callback(name)

        stop, num, m, h, n = name.stop, name.num, name.m, name.h, name.n
        linear = name.linear
        cos1 = name.cos1

        main = 0; other = 0; mu = 0
        for h[1] in range(num[1]):
            m[1] = st[0] + h[1] * sp[0]
            stop[2] = (en[1] if en[1] < len(data[m[1]]) else len(data[m[1]])) - ws[1] - dd[1]
            num[2] = (stop[2] - st[1] + 1) // sp[1]
            cos2 = [None] * num[2] if output is None else cos1[ost[0] + h[1] * ostp[0]]
            if output is None:
                cos1[h[1]] = cos2

            for h[2] in range(num[2]):
                m[2] = st[1] + h[2] * sp[1]
                stop[3] = (en[2] if en[2] < len(data[m[1]][m[2]]) else len(data[m[1]][m[2]])) - ws[2] - dd[2]
                num[3] = (stop[3] - st[2] + 1) // sp[2]
                cos3 = [None] * num[3] if output is None else cos1[ost[0] + h[1] * ostp[0]][ost[1] + h[2] * ostp[1]]
                if output is None:
                    cos1[h[1]][h[2]] = cos3

                for h[3] in range(num[3]):
                    m[3] = st[2] + h[3] * sp[2]
                    stop[4] = (en[3] if en[3] < len(data[m[1]][m[2]][m[3]]) else len(data[m[1]][m[2]][m[3]])) - ws[3] - dd[3]
                    num[4] = (stop[4] - st[3] + 1) // sp[3]
                    cos4 = [None] * num[4] if output is None else cos1[ost[0] + h[1] * ostp[0]][ost[1] + h[2] * ostp[1]][ost[2] + h[3] * ostp[2]]
                    if output is None:
                        cos1[h[1]][h[2]][h[3]] = cos4

                    for h[4] in range(num[4]):
                        m[4] = st[3] + h[4] * sp[3]
                        try:
                            main *= 0; other *= 0; mu *= 0
                            for n[1] in range(ws[0]):
                                x1 = m[1] + n[1]
                                y1 = x1 + dd[0]
                                for n[2] in range(ws[1]):
                                    x2 = m[2] + n[2]
                                    y2 = x2 + dd[1]
                                    for n[3] in range(ws[2]):
                                        x3 = m[3] + n[3]
                                        y3 = x3 + dd[2]
                                        for n[4] in range(ws[3]):
                                            x4 = m[4] + n[4]
                                            y4 = x4 + dd[3]

                                            if iter_a_callback:
                                                iter_a_callback(name)

                                            (w1, w2, b1, b2) = linear
                                            main_tmp = w1 * data[x1][x2][x3][x4] + b1
                                            other_tmp = w2 * data[y1][y2][y3][y4] + b2

                                            main += main_tmp * main_tmp
                                            other += other_tmp * other_tmp
                                            mu += main_tmp * other_tmp

                            if iter_b_callback:
                                iter_b_callback(name)

                            w0 = ost[0] + h[1] * ostp[0]
                            w1 = ost[1] + h[2] * ostp[1]
                            w2 = ost[2] + h[3] * ostp[2]
                            w3 = ost[3] + h[4] * ostp[3]
                            cos1[w0][w1][w2][w3] = algorithm(main, other, mu, name)
                        except StopIteration as e:
                            if iter_stop_callback:
                                iter_stop_callback(e, name)
                        except Exception as e:
                            if local_error_callback:
                                local_error_callback(e, name)

        if end_callback:
            end_callback(name)
    except Exception as e:
        if global_error_callback:
            global_error_callback(e, name)
    return return_callback(name)


def cos_comparison_passive(data,
                           *arg,
                           window_size=None,
                           w1=1, w2=1,
                           b1=0, b2=0,
                           start=None, end=None,
                           step=None, d=None,
                           algorithm=_default_algorithm,
                           start_callback=None,
                           end_callback=None,
                           iter_a_callback=None,
                           iter_b_callback=None,
                           iter_stop_callback=None,
                           global_error_callback=lambda e, name: None,
                           local_error_callback=lambda e, name: None,
                           return_callback=lambda name: name.cos1,
                           output=None,
                           output_start=None,
                           output_step=None,
                           **kwarg):
    """
    process a tensor data by passive mode (generic N-dim, no dim inference).
    """
    try:
        # ----- default args (avoid mutable trap) -----
        if not window_size:
            window_size = default_contain(1)
        if not start:
            start = default_contain(0)
        if not end:
            end = default_contain(NaN)
        if not step:
            step = default_contain(1)
        if not d:
            d = default_contain(0, default_dict={0:1})
        if not output_start:
            output_start = default_contain(0)
        if not output_step:
            output_step = default_contain(1)

        # helper to extract dimension-specific value from default_contain
        def get_val(p, idx):
            if hasattr(p, 'default_dict'):
                return p.default_dict.get(idx, p.default)
            else:
                return p[idx]

        # ----- state containers -----
        _flag = 1
        out_stack = flexible_contain()

        name = name_space(
            cos1 = output if output else None,
            window_size=window_size,
            linear=[w1, w2, b1, b2],
            start=start, end=end, step=step, d=d,
            algorithm=algorithm,
            start_callback=start_callback, end_callback=end_callback,
            iter_a_callback=iter_a_callback, iter_b_callback=iter_b_callback,
            iter_stop_callback=iter_stop_callback,
            global_error_callback=global_error_callback, local_error_callback=local_error_callback,
            return_callback=return_callback,
            stop=flexible_contain(),
            num=flexible_contain(),
            m=flexible_contain(),
            h=flexible_contain(),
            n=flexible_contain()
        )

        ost = output_start
        ostp = output_step
        stop = name.stop
        num = name.num
        m = name.m
        h = name.h
        n = name.n
        linear = name.linear

        if output:
            out_stack[0] = output
            name.cos1 = output
        else:
            out_stack[0] = None

        main_sum = 0
        other_sum = 0
        cross_sum = 0

        _temp = data
        _index = 0

        if start_callback:
            start_callback(name)

        while _flag > 0:
            _index = _flag - 1

            # try to go deeper
            can_go_deeper = False
            try:
                if hasattr(_temp, '__getitem__') and hasattr(_temp, '__len__'):
                    L = len(_temp)
                    if L > 0:
                        can_go_deeper = True
            except:
                pass

            if can_go_deeper:
                ws = get_val(window_size, _index)
                st = get_val(start, _index)
                en = get_val(end, _index)
                sp = get_val(step, _index)
                dd = get_val(d, _index)

                limit = en if en < L else L
                stop_val = limit - ws - dd
                if stop_val >= st:
                    num_val = (stop_val - st + 1) // sp
                else:
                    num_val = 0

                stop[_index] = stop_val
                num[_index] = num_val

                if not output:
                    child = [None] * num_val
                    if _flag == 1:
                        name.cos1 = child
                        out_stack[0] = child
                    else:
                        parent = out_stack[_index - 1]
                        parent[h[_index - 1]] = child
                        out_stack[_index] = child
                else:
                    if _flag == 1:
                        out_stack[0] = output
                    else:
                        parent = out_stack[_index - 1]
                        child = parent[get_val(ost, _index - 1) + h[_index - 1] * get_val(ostp, _index - 1)]
                        out_stack[_index] = child

                m[_index] = st
                h[_index] = 0

                if num_val > 0:
                    _temp = _temp[m[_index]]
                else:
                    _temp = None

                _flag += 1
                continue

            # leaf dimension: compute window
            dim = _flag - 1
            if dim == 0:
                break

            if h[dim-1] < num[dim-1]:
                try:
                    main_sum *= 0
                    other_sum *= 0
                    cross_sum *= 0

                    main_root = data
                    other_root = data
                    for i in range(dim):
                        main_root = main_root[m[i]]
                        other_root = other_root[m[i] + get_val(d, i)]

                    for i in range(dim):
                        n[i] = 0

                    while True:
                        v_main = main_root
                        v_other = other_root
                        for i in range(dim):
                            v_main = v_main[n[i]]
                            v_other = v_other[n[i]]

                        if iter_a_callback:
                            iter_a_callback(name)

                        w1v, w2v, b1v, b2v = linear
                        main_tmp = w1v * v_main + b1v
                        other_tmp = w2v * v_other + b2v

                        main_sum += main_tmp * main_tmp
                        other_sum += other_tmp * other_tmp
                        cross_sum += main_tmp * other_tmp

                        carry_dim = dim - 1
                        while carry_dim >= 0:
                            n[carry_dim] += 1
                            if n[carry_dim] < get_val(window_size, carry_dim):
                                break
                            n[carry_dim] = 0
                            carry_dim -= 1
                        if carry_dim < 0:
                            break

                    if iter_b_callback:
                        iter_b_callback(name)

                    out_ref = out_stack[dim-1]
                    for i in range(dim - 1):
                        idx = get_val(ost, i) + h[i] * get_val(ostp, i)
                        out_ref = out_ref[idx]
                    last_idx = get_val(ost, dim-1) + h[dim-1] * get_val(ostp, dim-1)
                    out_ref[last_idx] = algorithm(main_sum, other_sum, cross_sum, name)

                except StopIteration as e:
                    if iter_stop_callback:
                        iter_stop_callback(e, name)
                except Exception as e:
                    if local_error_callback:
                        local_error_callback(e, name)

            # bubble carry
            carry_flag = True
            while carry_flag and _flag > 1:
                idx = _flag - 2
                m[idx] += get_val(step, idx)
                h[idx] += 1
                if m[idx] <= stop[idx]:
                    _temp = data
                    for i in range(idx + 1):
                        _temp = _temp[m[i]]
                    _flag = idx + 2
                    carry_flag = False
                else:
                    _flag -= 1
                    if not output and _flag > 0:
                        pass
            if carry_flag:
                _flag = 0

        if end_callback:
            end_callback(name)

    except Exception as e:
        if global_error_callback:
            global_error_callback(e, name)
    return return_callback(name)

#    ------------------------- active mode ----------------------------
def cos_comparison_active_1d(data,
                             *arg,
                             kernel=(1,),
                             w1=1, w2=1,
                             b1=0, b2=0,
                             start=(0,), end=(NaN,),
                             step=(1,),
                             algorithm=_default_algorithm,
                             start_callback=None,
                             end_callback=None,
                             iter_a_callback=None,
                             iter_b_callback=None,
                             iter_stop_callback=None,
                             global_error_callback=lambda e, name: None,
                             local_error_callback=lambda e, name: None,
                             return_callback=lambda name: name.cos1,
                             output=None,
                             output_start=None,
                             output_step=None,
                             **kwarg):
    """
    process 1 dimension tensor data by active mode.
    it can be set by setting callback functions.
    """
    try:
        st = start; en = end; sp = step
        ost = output_start if output_start is not None else (0,)
        ostp = output_step if output_step is not None else (1,)
        
        stop1 = (en[0] if en[0] < len(data) else len(data)) - len(kernel)
        num1 = (stop1 - st[0] + 1) // sp[0]
        
        name = name_space(
            cos1 = output if output is not None else [None] * num1,
            kernel=kernel,
            linear=[w1, w2, b1, b2],
            start=st, end=en, step=sp,
            algorithm=algorithm,
            start_callback=start_callback, end_callback=end_callback,
            iter_a_callback=iter_a_callback, iter_b_callback=iter_b_callback,
            iter_stop_callback=iter_stop_callback,
            global_error_callback=global_error_callback, local_error_callback=local_error_callback,
            return_callback=return_callback,
            stop=[None, stop1],
            num=[None, num1],
            m=[None, None],
            h=[None, None],
            n=[None, None]
        )

        if start_callback:
            start_callback(name)

        stop, num, m, h, n = name.stop, name.num, name.m, name.h, name.n
        linear = name.linear
        kernel = name.kernel
        cos1 = name.cos1

        main = 0; other = 0; mu = 0
        for h[1] in range(num[1]):
            m[1] = st[0] + h[1] * sp[0]
            try:
                main *= 0; other *= 0; mu *= 0
                for n[1] in range(len(kernel)):
                    x1 = m[1] + n[1]

                    if iter_a_callback:
                        iter_a_callback(name)

                    (w1, w2, b1, b2) = linear
                    main_tmp = w1 * data[x1] + b1
                    other_tmp = w2 * kernel[n[1]] + b2

                    main += main_tmp * main_tmp
                    other += other_tmp * other_tmp
                    mu += main_tmp * other_tmp

                if iter_b_callback:
                    iter_b_callback(name)

                write_idx = ost[0] + h[1] * ostp[0]
                cos1[write_idx] = algorithm(main, other, mu, name)
            except StopIteration as e:
                if iter_stop_callback:
                    iter_stop_callback(e, name)
            except Exception as e:
                if local_error_callback:
                    local_error_callback(e, name)

        if end_callback:
            end_callback(name)
    except Exception as e:
        if global_error_callback:
            global_error_callback(e, name)
    return return_callback(name)


def cos_comparison_active_2d(data,
                             *arg,
                             kernel=((1,),),
                             w1=1, w2=1,
                             b1=0, b2=0,
                             start=(0, 0), end=(NaN, NaN),
                             step=(1, 1),
                             algorithm=_default_algorithm,
                             start_callback=None,
                             end_callback=None,
                             iter_a_callback=None,
                             iter_b_callback=None,
                             iter_stop_callback=None,
                             global_error_callback=lambda e, name: None,
                             local_error_callback=lambda e, name: None,
                             return_callback=lambda name: name.cos1,
                             output=None,
                             output_start=None,
                             output_step=None,
                             **kwarg):
    """
    process 2 dimension tensor data by active mode.
    it can be set by setting callback functions.
    """
    try:
        st = start; en = end; sp = step
        ost = output_start if output_start is not None else (0,0)
        ostp = output_step if output_step is not None else (1,1)
        
        stop1 = (en[0] if en[0] < len(data) else len(data)) - len(kernel)
        num1 = (stop1 - st[0] + 1) // sp[0]
        
        name = name_space(
            cos1 = output if output is not None else [None] * num1,
            kernel=kernel,
            linear=[w1, w2, b1, b2],
            start=st, end=en, step=sp,
            algorithm=algorithm,
            start_callback=start_callback, end_callback=end_callback,
            iter_a_callback=iter_a_callback, iter_b_callback=iter_b_callback,
            iter_stop_callback=iter_stop_callback,
            global_error_callback=global_error_callback, local_error_callback=local_error_callback,
            return_callback=return_callback,
            stop=[None, stop1, None],
            num=[None, num1, None],
            m=[None, None, None],
            h=[None, None, None],
            n=[None, None, None]
        )

        if start_callback:
            start_callback(name)

        stop, num, m, h, n = name.stop, name.num, name.m, name.h, name.n
        linear = name.linear
        kernel = name.kernel
        cos1 = name.cos1

        main = 0; other = 0; mu = 0
        for h[1] in range(num[1]):
            m[1] = st[0] + h[1] * sp[0]
            stop[2] = (en[1] if en[1] < len(data[m[1]]) else len(data[m[1]])) - len(kernel[0])
            num[2] = (stop[2] - st[1] + 1) // sp[1]
            cos2 = [None] * num[2] if output is None else cos1[ost[0] + h[1] * ostp[0]]
            if output is None:
                cos1[h[1]] = cos2

            for h[2] in range(num[2]):
                m[2] = st[1] + h[2] * sp[1]
                try:
                    main *= 0; other *= 0; mu *= 0
                    for n[1] in range(len(kernel)):
                        x1 = m[1] + n[1]
                        for n[2] in range(len(kernel[n[1]])):
                            x2 = m[2] + n[2]

                            if iter_a_callback:
                                iter_a_callback(name)

                            (w1, w2, b1, b2) = linear
                            main_tmp = w1 * data[x1][x2] + b1
                            other_tmp = w2 * kernel[n[1]][n[2]] + b2

                            main += main_tmp * main_tmp
                            other += other_tmp * other_tmp
                            mu += main_tmp * other_tmp

                    if iter_b_callback:
                        iter_b_callback(name)

                    write_row = ost[0] + h[1] * ostp[0]
                    write_col = ost[1] + h[2] * ostp[1]
                    cos1[write_row][write_col] = algorithm(main, other, mu, name)
                except StopIteration as e:
                    if iter_stop_callback:
                        iter_stop_callback(e, name)
                except Exception as e:
                    if local_error_callback:
                        local_error_callback(e, name)

        if end_callback:
            end_callback(name)
    except Exception as e:
        if global_error_callback:
            global_error_callback(e, name)
    return return_callback(name)


def cos_comparison_active_3d(data,
                             *arg,
                             kernel=(((1,),),),
                             w1=1, w2=1,
                             b1=0, b2=0,
                             start=(0, 0, 0), end=(NaN, NaN, NaN),
                             step=(1, 1, 1),
                             algorithm=_default_algorithm,
                             start_callback=None,
                             end_callback=None,
                             iter_a_callback=None,
                             iter_b_callback=None,
                             iter_stop_callback=None,
                             global_error_callback=lambda e, name: None,
                             local_error_callback=lambda e, name: None,
                             return_callback=lambda name: name.cos1,
                             output=None,
                             output_start=None,
                             output_step=None,
                             **kwarg):
    """
    process 3 dimension tensor data by active mode.
    it can be set by setting callback functions.
    """
    try:
        st = start; en = end; sp = step
        ost = output_start if output_start is not None else (0,0,0)
        ostp = output_step if output_step is not None else (1,1,1)
        
        stop1 = (en[0] if en[0] < len(data) else len(data)) - len(kernel)
        num1 = (stop1 - st[0] + 1) // sp[0]
        
        name = name_space(
            cos1 = output if output is not None else [None] * num1,
            kernel=kernel,
            linear=[w1, w2, b1, b2],
            start=st, end=en, step=sp,
            algorithm=algorithm,
            start_callback=start_callback, end_callback=end_callback,
            iter_a_callback=iter_a_callback, iter_b_callback=iter_b_callback,
            iter_stop_callback=iter_stop_callback,
            global_error_callback=global_error_callback, local_error_callback=local_error_callback,
            return_callback=return_callback,
            stop=[None, stop1, None, None],
            num=[None, num1, None, None],
            m=[None, None, None, None],
            h=[None, None, None, None],
            n=[None, None, None, None]
        )

        if start_callback:
            start_callback(name)

        stop, num, m, h, n = name.stop, name.num, name.m, name.h, name.n
        linear = name.linear
        kernel = name.kernel
        cos1 = name.cos1

        main = 0; other = 0; mu = 0
        for h[1] in range(num[1]):
            m[1] = st[0] + h[1] * sp[0]
            stop[2] = (en[1] if en[1] < len(data[m[1]]) else len(data[m[1]])) - len(kernel[0])
            num[2] = (stop[2] - st[1] + 1) // sp[1]
            cos2 = [None] * num[2] if output is None else cos1[ost[0] + h[1] * ostp[0]]
            if output is None:
                cos1[h[1]] = cos2

            for h[2] in range(num[2]):
                m[2] = st[1] + h[2] * sp[1]
                stop[3] = (en[2] if en[2] < len(data[m[1]][m[2]]) else len(data[m[1]][m[2]])) - len(kernel[0][0])
                num[3] = (stop[3] - st[2] + 1) // sp[2]
                cos3 = [None] * num[3] if output is None else cos1[ost[0] + h[1] * ostp[0]][ost[1] + h[2] * ostp[1]]
                if output is None:
                    cos1[h[1]][h[2]] = cos3

                for h[3] in range(num[3]):
                    m[3] = st[2] + h[3] * sp[2]
                    try:
                        main *= 0; other *= 0; mu *= 0
                        for n[1] in range(len(kernel)):
                            x1 = m[1] + n[1]
                            for n[2] in range(len(kernel[n[1]])):
                                x2 = m[2] + n[2]
                                for n[3] in range(len(kernel[n[1]][n[2]])):
                                    x3 = m[3] + n[3]

                                    if iter_a_callback:
                                        iter_a_callback(name)

                                    (w1, w2, b1, b2) = linear
                                    main_tmp = w1 * data[x1][x2][x3] + b1
                                    other_tmp = w2 * kernel[n[1]][n[2]][n[3]] + b2

                                    main += main_tmp * main_tmp
                                    other += other_tmp * other_tmp
                                    mu += main_tmp * other_tmp

                        if iter_b_callback:
                            iter_b_callback(name)

                        w0 = ost[0] + h[1] * ostp[0]
                        w1 = ost[1] + h[2] * ostp[1]
                        w2 = ost[2] + h[3] * ostp[2]
                        cos1[w0][w1][w2] = algorithm(main, other, mu, name)
                    except StopIteration as e:
                        if iter_stop_callback:
                            iter_stop_callback(e, name)
                    except Exception as e:
                        if local_error_callback:
                            local_error_callback(e, name)

        if end_callback:
            end_callback(name)
    except Exception as e:
        if global_error_callback:
            global_error_callback(e, name)
    return return_callback(name)


def cos_comparison_active_4d(data,
                             *arg,
                             kernel=((((1,),),),),
                             w1=1, w2=1,
                             b1=0, b2=0,
                             start=(0, 0, 0, 0), end=(NaN, NaN, NaN, NaN),
                             step=(1, 1, 1, 1),
                             algorithm=_default_algorithm,
                             start_callback=None,
                             end_callback=None,
                             iter_a_callback=None,
                             iter_b_callback=None,
                             iter_stop_callback=None,
                             global_error_callback=lambda e, name: None,
                             local_error_callback=lambda e, name: None,
                             return_callback=lambda name: name.cos1,
                             output=None,
                             output_start=None,
                             output_step=None,
                             **kwarg):
    """
    process 4 dimension tensor data by active mode.
    it can be set by setting callback functions.
    """
    try:
        st = start; en = end; sp = step
        ost = output_start if output_start is not None else (0,0,0,0)
        ostp = output_step if output_step is not None else (1,1,1,1)
        
        stop1 = (en[0] if en[0] < len(data) else len(data)) - len(kernel)
        num1 = (stop1 - st[0] + 1) // sp[0]
        
        name = name_space(
            cos1 = output if output is not None else [None] * num1,
            kernel=kernel,
            linear=[w1, w2, b1, b2],
            start=st, end=en, step=sp,
            algorithm=algorithm,
            start_callback=start_callback, end_callback=end_callback,
            iter_a_callback=iter_a_callback, iter_b_callback=iter_b_callback,
            iter_stop_callback=iter_stop_callback,
            global_error_callback=global_error_callback, local_error_callback=local_error_callback,
            return_callback=return_callback,
            stop=[None, stop1, None, None, None],
            num=[None, num1, None, None, None],
            m=[None, None, None, None, None],
            h=[None, None, None, None, None],
            n=[None, None, None, None, None]
        )

        if start_callback:
            start_callback(name)

        stop, num, m, h, n = name.stop, name.num, name.m, name.h, name.n
        linear = name.linear
        kernel = name.kernel
        cos1 = name.cos1

        main = 0; other = 0; mu = 0
        for h[1] in range(num[1]):
            m[1] = st[0] + h[1] * sp[0]
            stop[2] = (en[1] if en[1] < len(data[m[1]]) else len(data[m[1]])) - len(kernel[0])
            num[2] = (stop[2] - st[1] + 1) // sp[1]
            cos2 = [None] * num[2] if output is None else cos1[ost[0] + h[1] * ostp[0]]
            if output is None:
                cos1[h[1]] = cos2

            for h[2] in range(num[2]):
                m[2] = st[1] + h[2] * sp[1]
                stop[3] = (en[2] if en[2] < len(data[m[1]][m[2]]) else len(data[m[1]][m[2]])) - len(kernel[0][0])
                num[3] = (stop[3] - st[2] + 1) // sp[2]
                cos3 = [None] * num[3] if output is None else cos1[ost[0] + h[1] * ostp[0]][ost[1] + h[2] * ostp[1]]
                if output is None:
                    cos1[h[1]][h[2]] = cos3

                for h[3] in range(num[3]):
                    m[3] = st[2] + h[3] * sp[2]
                    stop[4] = (en[3] if en[3] < len(data[m[1]][m[2]][m[3]]) else len(data[m[1]][m[2]][m[3]])) - len(kernel[0][0][0])
                    num[4] = (stop[4] - st[3] + 1) // sp[3]
                    cos4 = [None] * num[4] if output is None else cos1[ost[0] + h[1] * ostp[0]][ost[1] + h[2] * ostp[1]][ost[2] + h[3] * ostp[2]]
                    if output is None:
                        cos1[h[1]][h[2]][h[3]] = cos4

                    for h[4] in range(num[4]):
                        m[4] = st[3] + h[4] * sp[3]
                        try:
                            main *= 0; other *= 0; mu *= 0
                            for n[1] in range(len(kernel)):
                                x1 = m[1] + n[1]
                                for n[2] in range(len(kernel[n[1]])):
                                    x2 = m[2] + n[2]
                                    for n[3] in range(len(kernel[n[1]][n[2]])):
                                        x3 = m[3] + n[3]
                                        for n[4] in range(len(kernel[n[1]][n[2]][n[3]])):
                                            x4 = m[4] + n[4]

                                            if iter_a_callback:
                                                iter_a_callback(name)

                                            (w1, w2, b1, b2) = linear
                                            main_tmp = w1 * data[x1][x2][x3][x4] + b1
                                            other_tmp = w2 * kernel[n[1]][n[2]][n[3]][n[4]] + b2

                                            main += main_tmp * main_tmp
                                            other += other_tmp * other_tmp
                                            mu += main_tmp * other_tmp

                            if iter_b_callback:
                                iter_b_callback(name)

                            w0 = ost[0] + h[1] * ostp[0]
                            w1 = ost[1] + h[2] * ostp[1]
                            w2 = ost[2] + h[3] * ostp[2]
                            w3 = ost[3] + h[4] * ostp[3]
                            cos1[w0][w1][w2][w3] = algorithm(main, other, mu, name)
                        except StopIteration as e:
                            if iter_stop_callback:
                                iter_stop_callback(e, name)
                        except Exception as e:
                            if local_error_callback:
                                local_error_callback(e, name)

        if end_callback:
            end_callback(name)
    except Exception as e:
        if global_error_callback:
            global_error_callback(e, name)
    return return_callback(name)


def cos_comparison_active(data,
                          *arg,
                          kernel=None,
                          w1=1, w2=1,
                          b1=0, b2=0,
                          start=None, end=None,
                          step=None,
                          algorithm=_default_algorithm,
                          start_callback=None,
                          end_callback=None,
                          iter_a_callback=None,
                          iter_b_callback=None,
                          iter_stop_callback=None,
                          global_error_callback=lambda e, name: None,
                          local_error_callback=lambda e, name: None,
                          return_callback=lambda name: name.cos1,
                          output=None,
                          output_start=None,
                          output_step=None,
                          **kwarg):
    """
    process a tensor data by active mode (generic N-dim, no dim inference).
    """
    try:
        # ----- default args (avoid mutable trap) -----
        if not kernel:
            kernel = default_contain(1)
        if not start:
            start = default_contain(0)
        if not end:
            end = default_contain(NaN)
        if not step:
            step = default_contain(1)
        if not output_start:
            output_start = default_contain(0)
        if not output_step:
            output_step = default_contain(1)

        # helper to extract dimension-specific value from default_contain
        def get_val(p, idx):
            if hasattr(p, 'default_dict'):
                return p.default_dict.get(idx, p.default)
            else:
                return p[idx]

        # ----- state containers -----
        _flag = 1
        out_stack = flexible_contain()

        name = name_space(
            cos1 = output if output else None,
            kernel=kernel,
            linear=[w1, w2, b1, b2],
            start=start, end=end, step=step,
            algorithm=algorithm,
            start_callback=start_callback, end_callback=end_callback,
            iter_a_callback=iter_a_callback, iter_b_callback=iter_b_callback,
            iter_stop_callback=iter_stop_callback,
            global_error_callback=global_error_callback, local_error_callback=local_error_callback,
            return_callback=return_callback,
            stop=flexible_contain(),
            num=flexible_contain(),
            m=flexible_contain(),
            h=flexible_contain(),
            n=flexible_contain()
        )

        ost = output_start
        ostp = output_step
        stop = name.stop
        num = name.num
        m = name.m
        h = name.h
        n = name.n
        linear = name.linear
        ker = kernel

        if output:
            out_stack[0] = output
            name.cos1 = output
        else:
            out_stack[0] = None

        main_sum = 0
        other_sum = 0
        cross_sum = 0

        _temp = data
        _index = 0

        if start_callback:
            start_callback(name)

        while _flag > 0:
            _index = _flag - 1

            # try to go deeper
            can_go_deeper = False
            try:
                if hasattr(_temp, '__getitem__') and hasattr(_temp, '__len__'):
                    L = len(_temp)
                    if L > 0:
                        can_go_deeper = True
            except:
                pass

            if can_go_deeper:
                st = get_val(start, _index)
                en = get_val(end, _index)
                sp = get_val(step, _index)

                # estimate kernel length at current depth
                ker_len = 1
                try:
                    tk = ker
                    for _ in range(_flag):
                        tk = tk[0]
                    ker_len = len(tk) if hasattr(tk, '__len__') else 1
                except:
                    pass

                limit = en if en < L else L
                stop_val = limit - ker_len
                if stop_val >= st:
                    num_val = (stop_val - st + 1) // sp
                else:
                    num_val = 0

                stop[_index] = stop_val
                num[_index] = num_val

                if not output:
                    child = [None] * num_val
                    if _flag == 1:
                        name.cos1 = child
                        out_stack[0] = child
                    else:
                        parent = out_stack[_index - 1]
                        parent[h[_index - 1]] = child
                        out_stack[_index] = child
                else:
                    if _flag == 1:
                        out_stack[0] = output
                    else:
                        parent = out_stack[_index - 1]
                        child = parent[get_val(ost, _index - 1) + h[_index - 1] * get_val(ostp, _index - 1)]
                        out_stack[_index] = child

                m[_index] = st
                h[_index] = 0

                if num_val > 0:
                    _temp = _temp[m[_index]]
                else:
                    _temp = None

                _flag += 1
                continue

            # leaf dimension: compute window
            dim = _flag - 1
            if dim == 0:
                break

            if h[dim-1] < num[dim-1]:
                try:
                    main_sum *= 0
                    other_sum *= 0
                    cross_sum *= 0

                    data_root = data
                    for i in range(dim):
                        data_root = data_root[m[i]]

                    kernel_root = ker
                    for _ in range(dim - 1):
                        kernel_root = kernel_root[0]

                    for i in range(dim):
                        n[i] = 0

                    while True:
                        v_data = data_root
                        v_kernel = kernel_root
                        for i in range(dim):
                            v_data = v_data[n[i]]
                            v_kernel = v_kernel[n[i]]

                        if iter_a_callback:
                            iter_a_callback(name)

                        w1v, w2v, b1v, b2v = linear
                        main_tmp = w1v * v_data + b1v
                        other_tmp = w2v * v_kernel + b2v

                        main_sum += main_tmp * main_tmp
                        other_sum += other_tmp * other_tmp
                        cross_sum += main_tmp * other_tmp

                        carry_dim = dim - 1
                        while carry_dim >= 0:
                            n[carry_dim] += 1
                            k_len = 1
                            try:
                                tk = kernel_root
                                for _ in range(carry_dim):
                                    tk = tk[0]
                                k_len = len(tk) if hasattr(tk, '__len__') else 1
                            except:
                                pass
                            if n[carry_dim] < k_len:
                                break
                            n[carry_dim] = 0
                            carry_dim -= 1
                        if carry_dim < 0:
                            break

                    if iter_b_callback:
                        iter_b_callback(name)

                    out_ref = out_stack[dim-1]
                    for i in range(dim - 1):
                        idx = get_val(ost, i) + h[i] * get_val(ostp, i)
                        out_ref = out_ref[idx]
                    last_idx = get_val(ost, dim-1) + h[dim-1] * get_val(ostp, dim-1)
                    out_ref[last_idx] = algorithm(main_sum, other_sum, cross_sum, name)

                except StopIteration as e:
                    if iter_stop_callback:
                        iter_stop_callback(e, name)
                except Exception as e:
                    if local_error_callback:
                        local_error_callback(e, name)

            # bubble carry
            carry_flag = True
            while carry_flag and _flag > 1:
                idx = _flag - 2
                m[idx] += get_val(step, idx)
                h[idx] += 1
                if m[idx] <= stop[idx]:
                    _temp = data
                    for i in range(idx + 1):
                        _temp = _temp[m[i]]
                    _flag = idx + 2
                    carry_flag = False
                else:
                    _flag -= 1
                    if not output and _flag > 0:
                        pass
            if carry_flag:
                _flag = 0

        if end_callback:
            end_callback(name)

    except Exception as e:
        if global_error_callback:
            global_error_callback(e, name)
    return return_callback(name)

#    -------------------cos mode------------------------
def cos_1d(A,B,
           algorithm=_cos
           ):
    """
    to compute the cosine or other cosine-like of two data set.
    """
    A_leng=(len(A),)
    B_leng=(len(B),)
    if A_leng!=B_leng:
        raise ValueError("the struct of two data set must be same!")
    a,b,ab=0,0,0
    for m1 in range(A_leng[0]):
        a_tmp=A[m1]
        b_tmp=B[m1]
        a += a_tmp*a_tmp
        b += b_tmp*b_tmp
        ab+= a_tmp*b_tmp
    return algorithm(a,b,ab,None)

def cos_2d(A,B,
           algorithm=_cos
           ):
    """
    to compute the cosine or other cosine-like of two data set.
    """
    A_leng=(len(A),len(A[0]))
    B_leng=(len(B),len(B[0]))
    if A_leng!=B_leng:
        raise ValueError("the struct of two data set must be same!")
    a,b,ab=0,0,0
    for m1 in range(A_leng[0]):
        for m2 in range(A_leng[1]):
            a_tmp=A[m1][m2]
            b_tmp=B[m1][m2]
            a += a_tmp*a_tmp
            b += b_tmp*b_tmp
            ab+= a_tmp*b_tmp
    return algorithm(a,b,ab,None)

def cos_3d(A,B,
           algorithm=_cos
           ):
    """
    to compute the cosine or other cosine-like of two data set.
    """
    A_leng=(len(A),len(A[0]),len(A[0][0]))
    B_leng=(len(B),len(B[0]),len(B[0][0]))
    if A_leng!=B_leng:
        raise ValueError("the struct of two data set must be same!")
    a,b,ab=0,0,0
    for m1 in range(A_leng[0]):
        for m2 in range(A_leng[1]):
            for m3 in range(A_leng[2]):
                a_tmp=A[m1][m2][m3]
                b_tmp=B[m1][m2][m3]
                a += a_tmp*a_tmp
                b += b_tmp*b_tmp
                ab+= a_tmp*b_tmp
    return algorithm(a,b,ab,None)

def cos_4d(A,B,
           algorithm=_cos
           ):
    """
    to compute the cosine or other cosine-like of two data set.
    """
    A_leng=(len(A),len(A[0]),len(A[0][0]),len(A[0][0][0]))
    B_leng=(len(B),len(B[0]),len(B[0][0]),len(B[0][0][0]))
    if A_leng!=B_leng:
        raise ValueError("the struct of two data set must be same!")
    a,b,ab=0,0,0
    for m1 in range(A_leng[0]):
        for m2 in range(A_leng[1]):
            for m3 in range(A_leng[2]):
                for m4 in range(A_leng[3]):
                    a_tmp=A[m1][m2][m3][m4]
                    b_tmp=B[m1][m2][m3][m4]
                    a += a_tmp*a_tmp
                    b += b_tmp*b_tmp
                    ab+= a_tmp*b_tmp
    return algorithm(a,b,ab,None)

def cos(A, B, algorithm=_cos):
    """
    Cosine (or similar) of two identically structured nested lists.
    The tensors are flattened, then squared sums and dot product are computed.
    """
    flat_A = []
    flat_B = []
    stack = [(A, B)]
    while stack:
        a, b = stack.pop()
        if isinstance(a, (list, tuple)):
            if len(a) != len(b):
                raise ValueError("the struct of two data set must be same!")
            stack.extend(zip(reversed(a), reversed(b)))
        else:
            flat_A.append(a)
            flat_B.append(b)

    a = 0; b = 0; ab = 0
    for va, vb in zip(flat_A, flat_B):
        a += va * va
        b += vb * vb
        ab += va * vb
    return algorithm(a, b, ab, None)

#----------------- import module ------------------
#    ----------------------- statistic mode -----------------------
def mean_local_1d(data,
                  *arg,
                  local_size=(1,),
                  step=(1,),
                  **kwarg):
    """
    process local mean in a 1 dimension data by sliped windows.
    """
    kernel = [1.0] * local_size[0]
    N = local_size[0]
    return cos_comparison_active_1d(data,*arg,
                                    kernel=kernel,
                                    step=step,
                                    algorithm=lambda a,b,ab,name : ab / N,
                                    **kwarg)


def mean_local_2d(data,
                  *arg,
                  local_size=((1,),),
                  step=(1,1),
                  **kwarg):
    """
    process local mean in a 2 dimension data by sliped windows.
    """
    h = len(local_size)
    w = len(local_size[0])
    kernel = [[1.0] * w for _ in range(h)]
    N = h * w
    return cos_comparison_active_2d(data,*arg,
                                    kernel=kernel,
                                    step=step,
                                    algorithm=lambda a,b,ab,name : ab / N,
                                    **kwarg)

def mean_local_3d(data,
                  *arg,
                  local_size=(((1,),),),
                  step=(1,1,1),
                  **kwarg):
    """
    process local mean in a 3 dimension data by sliped windows.
    """
    d = len(local_size)
    h = len(local_size[0])
    w = len(local_size[0][0])
    kernel = [[[1.0] * w for _ in range(h)] for _ in range(d)]
    N = d * h * w
    return cos_comparison_active_3d(data,*arg,
                                    kernel=kernel,
                                    step=step,
                                    algorithm=lambda a,b,ab,name : ab / N,
                                    **kwarg)


def mean_local_4d(data,
                  *arg,
                  local_size=((((1,),),),),
                  step=(1,1,1,1),
                  **kwarg):
    """
    process local mean in a 4 dimension data by sliped windows.
    """
    n4 = len(local_size)
    n3 = len(local_size[0])
    n2 = len(local_size[0][0])
    n1 = len(local_size[0][0][0])
    kernel = [[[[1.0] * n1 for _ in range(n2)] for _ in range(n3)] for _ in range(n4)]
    N = n4 * n3 * n2 * n1
    return cos_comparison_active_4d(data,*arg,
                                    kernel=kernel,
                                    step=step,
                                    algorithm=lambda a,b,ab,name : ab / N,
                                    **kwarg)

def mean_local(data, *arg, local_size=None, step=None, **kwarg):
    """
    Local mean with arbitrary N‑dimensional window.
    `local_size` and `step` are tuples of ints, or `default_contain` for genericity.
    """
    if not local_size:
        local_size = default_contain(1)
    if not step:
        step = default_contain(1)

    # build an all‑1 kernel with the same nested structure as `local_size`
    def _fill(shape):
        if isinstance(shape, default_contain):
            # assume a single default value (1) for all axes – create a tuple of that length
            # We don't know the dimension here, so we let the active mode handle it via default_contain
            return shape  # active mode will interpret default_contain correctly
        if isinstance(shape, (list, tuple)):
            return [_fill(s) for s in shape]
        raise TypeError("local_size must be a sequence or default_contain")

    kernel = _fill(local_size)

    N = multiple_chain(local_size, 1) if hasattr(local_size, '__len__') else 1

    return cos_comparison_active(data, *arg,
                                 kernel=kernel,
                                 step=step,
                                 algorithm=lambda a, b, ab, name: ab / N,
                                 **kwarg)
                                 
def local_variance_1d(data, *arg, local_size=(1,), step=(1,), **kwarg):
    kernel = [1.0] * local_size[0]
    N = local_size[0]
    def var_alg(a, b, ab, name):
        mean_val = ab / N
        return a / N - mean_val * mean_val
    return cos_comparison_active_1d(data, *arg, kernel=kernel, step=step, algorithm=var_alg, **kwarg)

def local_variance_2d(data, *arg, local_size=((1,),), step=(1,1), **kwarg):
    h = len(local_size)
    w = len(local_size[0])
    kernel = [[1.0] * w for _ in range(h)]
    N = h * w
    def var_alg(a, b, ab, name):
        mean_val = ab / N
        return a / N - mean_val * mean_val
    return cos_comparison_active_2d(data, *arg, kernel=kernel, step=step, algorithm=var_alg, **kwarg)

def local_variance_3d(data, *arg, local_size=(((1,),),), step=(1,1,1), **kwarg):
    d = len(local_size)
    h = len(local_size[0])
    w = len(local_size[0][0])
    kernel = [[[1.0] * w for _ in range(h)] for _ in range(d)]
    N = d * h * w
    def var_alg(a, b, ab, name):
        mean_val = ab / N
        return a / N - mean_val * mean_val
    return cos_comparison_active_3d(data, *arg, kernel=kernel, step=step, algorithm=var_alg, **kwarg)

def local_variance_4d(data, *arg, local_size=((((1,),),),), step=(1,1,1,1), **kwarg):
    n4 = len(local_size)
    n3 = len(local_size[0])
    n2 = len(local_size[0][0])
    n1 = len(local_size[0][0][0])
    kernel = [[[[1.0] * n1 for _ in range(n2)] for _ in range(n3)] for _ in range(n4)]
    N = n4 * n3 * n2 * n1
    def var_alg(a, b, ab, name):
        mean_val = ab / N
        return a / N - mean_val * mean_val
    return cos_comparison_active_4d(data, *arg, kernel=kernel, step=step, algorithm=var_alg, **kwarg)

def local_variance(data, *arg, local_size=None, step=None, **kwarg):
    """
    Local variance with arbitrary N‑dimensional window.
    """
    if not local_size:
        local_size = default_contain(1)
    if not step:
        step = default_contain(1)

    def _fill(shape):
        if isinstance(shape, default_contain):
            return shape
        if isinstance(shape, (list, tuple)):
            return [_fill(s) for s in shape]
        raise TypeError("local_size must be a sequence or default_contain")

    kernel = _fill(local_size)
    N = multiple_chain(local_size, 1) if hasattr(local_size, '__len__') else 1

    def var_alg(a, b, ab, name):
        mean_val = ab / N
        return a / N - mean_val * mean_val

    return cos_comparison_active(data, *arg,
                                 kernel=kernel,
                                 step=step,
                                 algorithm=var_alg,
                                 **kwarg)

#------------------help module--------------
def execute_many(func,arg_iter,kwarg_iter):
    out=[]
    for a,k in zip(arg_iter,kwarg_iter):
        out.append(func(*a,*k))
    return out
    
def execute_many_iter(func,arg_iter,kwarg_iter):
    	for a,k in zip(arg_iter,kwarg_iter):
        	yield func(*a,*k)
        	                            