It is still an experimental version.

So,you can do:
1.fix its bugs.
2.compare it with other algorithm.
3.test it with different data sets.
4.develop its core ideas.

If you fail to use it,you can change the file "__init__.py" as:
    
"""python
form cos_comparison import *
