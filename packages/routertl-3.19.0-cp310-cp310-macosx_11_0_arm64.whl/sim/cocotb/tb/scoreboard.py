# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

# tb/scoreboard.py
"""
Scoreboard Components for Cocotb Verification
==============================================

This module provides two complementary scoring mechanisms:

1. ``SignalCollector`` + ``Scoreboard`` — simulation-time signal sampling
   with in-order comparison (existing).

2. ``BridgeScoreboard`` — write-tracking / read-verification checker for
   AXI-Lite bridge verification with byte-strobe masking (new).
"""

from __future__ import annotations

import logging
from collections import deque
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, Iterable, List, Optional, Tuple

import cocotb
from cocotb.queue import Queue
from cocotb.triggers import RisingEdge

# ---------- Data structure ----------


@dataclass(frozen=True)
class Item:
    """A single collected data sample.

    Attributes
    ----------
    value : Any
        The sampled value (typically int).
    meta : dict
        Optional metadata (e.g., timestamp, channel info).
    """

    value: Any
    meta: dict = field(default_factory=dict)


# ---------- Helpers to resolve cocotb values ----------


def _valid_is_one(sig) -> int:
    """Return 1 iff 'sig' is resolvable and equals 1; X/Z/U → 0."""
    v = sig.value
    try:
        if getattr(v, "is_resolvable", False) and v.is_resolvable:
            return 1 if int(v) & 1 else 0
    except Exception:
        pass
    return 0


def _to_int_resolving_xz(val, default_fill: int = 0) -> int:
    """BinaryValue -> int, mapping X/Z/U bits to default_fill (0 by default)."""
    try:
        if getattr(val, "is_resolvable", False) and val.is_resolvable:
            return int(val)
    except Exception:
        pass
    s = getattr(val, "binstr", None)
    if s is None:
        try:
            return int(val)
        except Exception:
            return 0
    repl = "1" if default_fill else "0"
    return int("".join(ch if ch in ("0", "1") else repl for ch in s), 2)


# ---------- Collector (simple, no timeouts) ----------

from cocotb.triggers import Event

# assuming you have this somewhere:
# @dataclass(frozen=True, slots=True)
# class Item:
#     value: int


class SignalCollector:
    """
    - Samples on every RisingEdge(clk)
    - If VALID == 1 (X/Z/U => 0), enqueues DATA (as int, X/Z -> 0)
    - Optional value_fn transforms the raw int before storing
    - Provides both:
      - a FIFO queue API (get/drain_now)
      - a non-destructive indexable buffer API (peek/slice/len/wait_len)
    """

    def __init__(
        self,
        clk,
        valid_sig,
        data_sig,
        value_fn: Optional[Callable[[int], int]] = None,
        *,
        history: Optional[int] = None,  # max length of buffer, None = unbounded
    ):
        """Create a signal collector.

        Parameters
        ----------
        clk : cocotb signal
            Clock signal, samples on rising edge.
        valid_sig : cocotb signal
            Valid qualifier — only samples when ``== 1``.
        data_sig : cocotb signal
            Data signal to read.
        value_fn : callable, optional
            Transform function applied to raw int before storing.
        history : int, optional
            Max number of items to keep in the non-destructive buffer.
            ``None`` = unbounded.
        """
        self.clk = clk
        self.valid_sig = valid_sig
        self.data_sig = data_sig

        self.q: Queue[Item] = Queue()
        self._value_fn = value_fn

        # Non-destructive history buffer
        self._buf: deque[Item] = deque(maxlen=history)

        # Event for wait_len()
        self._event = Event()

    async def start(self) -> None:
        """Start the collector loop — run via ``cocotb.start_soon()``."""
        while True:
            await RisingEdge(self.clk)
            if _valid_is_one(self.valid_sig):
                raw_val = _to_int_resolving_xz(self.data_sig.value)
                if self._value_fn is not None:
                    val = self._value_fn(raw_val)
                else:
                    val = raw_val

                item = Item(value=val)
                t = cocotb.utils.get_sim_time(unit="ns")

                # Put into FIFO queue
                self.q.put_nowait((item, t))

                # Store into history buffer
                self._buf.append(item)

                # Wake any waiters that care about buffer length
                self._event.set()

    # FIFO API
    async def get(self) -> Item:
        """Wait for and return the next queued item."""
        return await self.q.get()

    def qsize(self) -> int:
        """Return the number of items in the FIFO queue."""
        return self.q.qsize()

    def empty(self) -> bool:
        """Return ``True`` if the FIFO queue is empty."""
        return self.q.empty()

    async def drain_now(self) -> list[int]:
        """Empty the queue and return all values as a list."""
        out: list[int] = []
        while not self.q.empty():
            out.append((await self.q.get()).value)
        return out

    # Indexable "memory" API (non-destructive)
    def __len__(self) -> int:
        return len(self._buf)

    def peek(self, idx: int) -> Item:
        """Random access without consuming."""
        return self._buf[idx]  # supports negative indices

    def slice(self, start: Optional[int], stop: Optional[int]) -> list[Item]:
        """Return a list of items in [start:stop] without consuming them."""
        # deque slicing is awkward, so go via list()
        return list(self._buf)[slice(start, stop)]

    async def wait_len(self, n: int):
        """Block until at least n items are in the buffer."""
        while len(self._buf) < n:
            await self._event.wait()
            self._event.clear()


# ---------- Scoreboard (mask only in `expect`) ----------


class Scoreboard:
    """
    Minimal in-order comparator with no timeouts.
    - `expect(items, mask=None)` appends a batch of expected ints.
      If `mask` is given, it's applied to every item in that batch (or use `default_mask`).
    - `run()` consumes exactly len(expected) items and compares.
    """

    def __init__(
        self,
        env,
        collector: SignalCollector,
        fmt_fn: Callable[[Any], str] | None = None,
        strict_end: bool = False,
        quiet_cycles_after: int = 20,
        default_mask: int | None = None,
        keep_history: int = 0,
    ):
        """Create a scoreboard.

        Parameters
        ----------
        env : TbEnv
            Testbench environment.
        collector : SignalCollector
            The signal collector to consume items from.
        fmt_fn : callable, optional
            Formatting function for log messages.
        strict_end : bool
            If ``True``, assert that no extra items arrive after expected.
        quiet_cycles_after : int
            Cycles to wait after expected items in strict mode. Default ``20``.
        default_mask : int, optional
            Bit mask applied to all comparisons by default.
        keep_history : int
            Number of recent values to keep for debug context. Default ``0``.
        """
        self.env = env
        self.collector = collector
        self.log = env.log
        self.fmt_fn = fmt_fn or (lambda x: f"{x!r}")
        self.strict_end = strict_end
        self.quiet_cycles_after = quiet_cycles_after
        self.default_mask = default_mask
        self.keep_history = keep_history
        self._seen = deque(maxlen=keep_history)  # NEW
        # store as a list of (value, mask_or_None)
        self._expected: List[Tuple[int, int | None]] = []

    def expect(self, items: Iterable[int], mask: int | None = None) -> None:
        """Add expected items to the comparison queue.

        Parameters
        ----------
        items : iterable of int
            Expected values in the order they should arrive.
        mask : int, optional
            Bit mask for this batch. ``None`` uses ``default_mask``.
        """
        eff_mask = self.default_mask if mask is None else mask
        self._expected.extend((int(v), eff_mask) for v in items)

    async def run(self) -> None:
        """Consume expected items from the collector and verify each one.

        Raises ``AssertionError`` on the first mismatch.
        """
        # Consume exactly len(expected) items, compare with optional mask-per-item
        for i, (exp_val, mask) in enumerate(self._expected):
            got_item, _ = await self.collector.get()
            got = got_item.value
            self.log.debug(f"[Scoreboard] got #{i}: {self.fmt_fn(got)}")
            if self.keep_history:
                self._seen.append(got)  # NEW

            ok = ((got & mask) == (exp_val & mask)) if mask is not None else (got == exp_val)
            if not ok:
                msg = f"[Scoreboard] MISMATCH at #{i}: got {self.fmt_fn(got)} != expected {self.fmt_fn(exp_val)}" + (
                    f" (mask 0x{mask:08X})" if mask is not None else ""
                )
                self.log.error(msg)
                if self.keep_history and self._seen:
                    window = ", ".join(self.fmt_fn(v) for v in self._seen)
                    self.log.error(f"[Scoreboard] Last {len(self._seen)} seen: [{window}]")
                raise AssertionError(msg)

            self.log.debug(f"[Scoreboard] match #{i}: {self.fmt_fn(got)}")

        if self.strict_end:
            # ensure quiet after expected sequence
            for _ in range(self.quiet_cycles_after):
                if not self.collector.empty():
                    extra_item, _ = await self.collector.get()
                    extra = extra_item.value
                    raise AssertionError(f"[Scoreboard] Unexpected extra item after sequence: {self.fmt_fn(extra)}")
                await RisingEdge(self.env.clk)

        self.log.info(f"[Scoreboard] All {len(self._expected)} items matched ✔")


# ──────────────────────────────────────────────────────────────
#  BridgeScoreboard — Write-Tracking / Read-Verification
# ──────────────────────────────────────────────────────────────


@dataclass
class ScoreboardMismatch:
    """Record of a single read data mismatch."""

    addr: int
    expected: int
    actual: int
    transaction_id: int

    def __str__(self) -> str:
        return (
            f"Mismatch #{self.transaction_id}: "
            f"@0x{self.addr:08X} expected=0x{self.expected:08X} "
            f"actual=0x{self.actual:08X}"
        )


class BridgeScoreboard:
    """Write-tracking / read-verification scoreboard for bridge testing.

    Maintains a modeled memory that tracks all write transactions and
    automatically verifies read-back data, with byte-strobe masking.

    Parameters
    ----------
    data_width:
        Bus data width in bits (8, 16, 32, 64, 128).
    log:
        Optional logger.  Defaults to ``"BridgeScoreboard"``.
    strict:
        If ``True`` (default), ``check_read()`` raises ``AssertionError``
        on mismatch.  If ``False``, mismatches are only logged.

    Usage::

        sb = BridgeScoreboard(data_width=32)
        sb.record_write(0x100, 0xDEADBEEF)
        sb.check_read(0x100, 0xDEADBEEF)  # True
        assert sb.passed, sb.report()
    """

    def __init__(
        self,
        data_width: int = 32,
        log: Optional[logging.Logger] = None,
        strict: bool = True,
    ) -> None:
        if data_width not in (8, 16, 32, 64, 128):
            raise ValueError(f"data_width must be 8, 16, 32, 64, or 128; got {data_width}")
        self._data_width = data_width
        self._bytes_per_word = data_width // 8
        self._data_mask = (1 << data_width) - 1
        self._strict = strict
        self._log = log or logging.getLogger("BridgeScoreboard")

        self._model: Dict[int, int] = {}
        self._num_writes = 0
        self._num_reads = 0
        self._num_matches = 0
        self._num_mismatches = 0
        self._transaction_id = 0
        self._mismatches: List[ScoreboardMismatch] = []

    # ── Properties ────────────────────────────────────────────

    @property
    def data_width(self) -> int:
        """Bus data width in bits."""
        return self._data_width

    @property
    def num_writes(self) -> int:
        """Total number of recorded write transactions."""
        return self._num_writes

    @property
    def num_reads(self) -> int:
        """Total number of checked read transactions."""
        return self._num_reads

    @property
    def num_mismatches(self) -> int:
        """Number of read mismatches detected."""
        return self._num_mismatches

    @property
    def mismatches(self) -> List[ScoreboardMismatch]:
        """List of all recorded mismatch records."""
        return list(self._mismatches)

    @property
    def passed(self) -> bool:
        """``True`` if zero mismatches have been recorded."""
        return self._num_mismatches == 0

    # ── Core API ──────────────────────────────────────────────

    def record_write(
        self,
        addr: int,
        data: int,
        strb: Optional[int] = None,
    ) -> None:
        """Record a write transaction in the modeled memory.

        Parameters
        ----------
        addr:
            Write address (auto word-aligned).
        data:
            Write data word.
        strb:
            Byte-strobe mask.  ``None`` = full-word write.
        """
        aligned = self._align(addr)
        data &= self._data_mask

        if strb is None:
            self._model[aligned] = data
        else:
            existing = self._model.get(aligned, 0)
            self._model[aligned] = self._apply_strobe(existing, data, strb)

        self._num_writes += 1
        self._log.debug(
            "SB WRITE @0x%08X = 0x%0*X (strb=%s)",
            aligned,
            self._bytes_per_word * 2,
            self._model[aligned],
            f"0x{strb:X}" if strb is not None else "full",
        )

    def check_read(self, addr: int, actual: int) -> bool:
        """Verify a read result against the modeled memory.

        Returns ``True`` on match.  In strict mode, raises
        ``AssertionError`` on mismatch.
        """
        aligned = self._align(addr)
        actual &= self._data_mask
        expected = self._model.get(aligned, 0) & self._data_mask
        self._num_reads += 1
        self._transaction_id += 1

        if actual == expected:
            self._num_matches += 1
            self._log.debug(
                "SB READ  @0x%08X = 0x%0*X ✅",
                aligned,
                self._bytes_per_word * 2,
                actual,
            )
            return True

        self._num_mismatches += 1
        mm = ScoreboardMismatch(
            addr=aligned,
            expected=expected,
            actual=actual,
            transaction_id=self._transaction_id,
        )
        self._mismatches.append(mm)
        self._log.error("SB READ  %s", mm)
        if self._strict:
            raise AssertionError(str(mm))
        return False

    def predict(self, addr: int) -> int:
        """Return the expected value at an address without checking."""
        return self._model.get(self._align(addr), 0) & self._data_mask

    def reset(self) -> None:
        """Clear the modeled memory and all counters."""
        self._model.clear()
        self._mismatches.clear()
        self._num_writes = 0
        self._num_reads = 0
        self._num_matches = 0
        self._num_mismatches = 0
        self._transaction_id = 0

    # ── Reporting ─────────────────────────────────────────────

    def report(self) -> str:
        """Return a human-readable summary string."""
        status = "PASSED" if self.passed else "FAILED"
        lines = [
            f"BridgeScoreboard ({self._data_width}-bit): "
            f"{self._num_writes} writes, {self._num_reads} reads, "
            f"{self._num_mismatches} mismatches — {status}"
        ]
        for mm in self._mismatches:
            lines.append(f"  {mm}")
        return "\n".join(lines)

    # ── Internal ──────────────────────────────────────────────

    def _align(self, addr: int) -> int:
        """Word-align an address by clearing lower byte-offset bits."""
        return addr & ~(self._bytes_per_word - 1)

    def _apply_strobe(self, existing: int, new_data: int, strb: int) -> int:
        """Merge new_data into existing using byte-strobe mask."""
        result = existing
        for i in range(self._bytes_per_word):
            if strb & (1 << i):
                byte_mask = 0xFF << (i * 8)
                result = (result & ~byte_mask) | (new_data & byte_mask)
        return result & self._data_mask
