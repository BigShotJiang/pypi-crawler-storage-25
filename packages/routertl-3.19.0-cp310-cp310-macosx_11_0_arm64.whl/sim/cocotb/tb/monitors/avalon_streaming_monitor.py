# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

# tb/monitors/avalon_streaming_monitor.py
"""
Passive Avalon-Streaming (Avalon-ST) Protocol Monitor.

Continuously observes an Avalon-ST interface and flags specification
violations (Intel Avalon Interface Specifications §5) without interfering
with DUT operation.

Clauses (IDs follow the ``AST_*`` convention, matching ``AVL_*`` / ``AXI_*``
/ ``TSE_*`` in peer monitors):

  AST_DATA_HOLD        Source must hold data/sop/eop/empty/error/channel
                       stable while valid=1 and ready=0. Changing payload
                       after asserting valid (before the sink has accepted)
                       is a protocol violation — the classic "source changed
                       its mind" class of bug.

  AST_RST              ``valid`` must be 0 during reset. Asserting valid
                       while the interface is in reset is undefined.

  AST_EOP_WO_SOP       ``endofpacket=1`` seen without a preceding
                       ``startofpacket`` in the current packet. Packet
                       boundary corruption — downstream sinks can't
                       recover.

  AST_SOP_MID_PKT      ``startofpacket=1`` while a packet is already in
                       flight (sop was seen without a prior eop).
                       Packet-framing bug.

  AST_EMPTY_WO_EOP     ``empty`` nonzero without ``endofpacket=1``. The
                       ``empty`` signal is defined only on the eop beat;
                       nonzero empty elsewhere indicates stale signalling.

  AST_CHANNEL_MID_PKT  On multi-channel streams, ``channel`` must remain
                       stable from sop through eop (a packet belongs to
                       one logical channel). Flipping mid-packet confuses
                       downstream demuxes.

Optional signals (``startofpacket``, ``endofpacket``, ``empty``,
``channel``, ``error``) are discovered from the bus automatically. When
absent, the corresponding checks are skipped — a minimal valid/ready/data
bus still gets AST_DATA_HOLD + AST_RST coverage.

Contract spec: ``tb/contracts/avalon_streaming.md``.
"""

from __future__ import annotations

import logging
from typing import List

from cocotb.triggers import RisingEdge
from cocotb.utils import get_sim_time

from . import ProtocolViolation


def _safe_int(sig, default: int = 0) -> int:
    """Read a signal as int, treating X/Z/U as *default*."""
    if sig is None:
        return default
    try:
        return int(sig.value)
    except Exception:
        return default


class AvalonStreamMonitor:
    """Passive Avalon-Streaming protocol monitor.

    Parameters
    ----------
    bus : AvalonStreamBus
        Bus signal container (auto-discovered via ``from_prefix`` or
        constructed manually).
    clk : cocotb signal
        Sampling clock.
    rst : cocotb signal
        Reset signal.
    log : logging.Logger
        Logger for violation messages.
    rst_active_low : bool
        Reset polarity. Default False (active-high).
    ready_latency : int
        Avalon-ST ready latency parameter (§5.3.3). Default 0 — the source
        only drives valid when the sink is ready (or samples ready at the
        same cycle). ``ready_latency > 0`` is not yet fully modelled by
        this monitor; mark as TODO if you hit it.

    Usage
    -----
    Attach via ``TbEnv.attach_monitors(avalon_st={"prefix": {}})``, or
    construct directly::

        from tb.drivers.avalon_streaming import AvalonStreamBus
        from tb.monitors.avalon_streaming_monitor import AvalonStreamMonitor

        bus = AvalonStreamBus.from_prefix(dut, "src")
        mon = AvalonStreamMonitor(bus, dut.clk, dut.rst_n,
                                  log=log, rst_active_low=True)
        cocotb.start_soon(mon.run())
        # ... run stimulus ...
        assert mon.violation_count == 0
    """

    def __init__(
        self,
        bus,
        clk,
        rst,
        *,
        log: logging.Logger,
        rst_active_low: bool = False,
        ready_latency: int = 0,
    ):
        self.bus = bus
        self.clk = clk
        self.rst = rst
        self.log = log
        self._rst_active_low = rst_active_low
        self._ready_latency = ready_latency
        self._violations: List[ProtocolViolation] = []

    # ── Public API ──────────────────────────────────────────────

    @property
    def violations(self) -> List[ProtocolViolation]:
        return list(self._violations)

    @property
    def violation_count(self) -> int:
        return len(self._violations)

    def report(self) -> str:
        if not self._violations:
            return "Avalon-ST Monitor: 0 violations ✅"
        lines = [f"Avalon-ST Monitor: {len(self._violations)} violation(s) ❌"]
        for v in self._violations:
            lines.append(f"  [{v.check_id}] {v.channel} @ {v.timestamp_ns}ns: {v.message}")
        return "\n".join(lines)

    # ── Main coroutine ──────────────────────────────────────────

    async def run(self):
        """Main monitor loop — call via ``cocotb.start_soon(mon.run())``."""
        bus = self.bus

        # State tracking
        prev_held = None     # snapshot of held payload during stalled valid
        in_packet = False    # currently between sop and eop
        packet_channel = None  # channel on sop, must match through eop

        while True:
            await RisingEdge(self.clk)
            ts = int(get_sim_time("ns"))

            raw_rst = _safe_int(self.rst, default=0)
            rst_active = (not raw_rst) if self._rst_active_low else raw_rst

            curr_valid = _safe_int(bus.valid)
            curr_ready = _safe_int(bus.ready)

            # ── AST_RST: valid must be 0 during reset ──
            if rst_active:
                if curr_valid:
                    self._record("AST_RST", "stream", ts,
                                 "valid asserted during reset")
                prev_held = None
                in_packet = False
                packet_channel = None
                continue

            # Snapshot of the current beat's payload (for HOLD check + packet logic)
            curr_data = _safe_int(bus.data)
            curr_sop = _safe_int(bus.startofpacket) if bus.has_packets else 0
            curr_eop = _safe_int(bus.endofpacket) if bus.has_packets else 0
            curr_empty = _safe_int(bus.empty) if bus.has_empty else 0
            curr_channel = _safe_int(bus.channel) if bus.has_channel else 0
            curr_error = _safe_int(bus.error) if bus.has_error else 0

            # ── AST_DATA_HOLD: payload stable while valid=1 and ready=0 ──
            if curr_valid and not curr_ready:
                snapshot = (
                    curr_data, curr_sop, curr_eop,
                    curr_empty, curr_channel, curr_error,
                )
                if prev_held is not None and snapshot != prev_held:
                    # Find which field changed
                    fields = ["data", "sop", "eop", "empty", "channel", "error"]
                    for i, name in enumerate(fields):
                        if snapshot[i] != prev_held[i]:
                            self._record(
                                "AST_DATA_HOLD", "stream", ts,
                                f"{name} changed during valid=1 & ready=0 "
                                f"(was 0x{prev_held[i]:X}, now 0x{snapshot[i]:X})",
                            )
                            break
                prev_held = snapshot
            else:
                prev_held = None

            # ── Packet-framing checks (only if sop/eop are present) ──
            if bus.has_packets and curr_valid and curr_ready:
                # A beat was just transferred.
                if curr_sop:
                    if in_packet:
                        self._record(
                            "AST_SOP_MID_PKT", "stream", ts,
                            "startofpacket asserted while a packet is "
                            "already in flight (no preceding eop)",
                        )
                    in_packet = True
                    packet_channel = curr_channel if bus.has_channel else None

                # ── AST_CHANNEL_MID_PKT: channel stable within a packet ──
                elif bus.has_channel and in_packet:
                    if curr_channel != packet_channel:
                        self._record(
                            "AST_CHANNEL_MID_PKT", "stream", ts,
                            f"channel changed mid-packet "
                            f"(sop saw {packet_channel}, now {curr_channel})",
                        )

                if curr_eop:
                    if not in_packet:
                        self._record(
                            "AST_EOP_WO_SOP", "stream", ts,
                            "endofpacket asserted without a preceding sop",
                        )
                    in_packet = False
                    packet_channel = None

            # ── AST_EMPTY_WO_EOP: empty only meaningful on eop ──
            if (bus.has_empty and bus.has_packets
                    and curr_valid and curr_ready
                    and curr_empty and not curr_eop):
                self._record(
                    "AST_EMPTY_WO_EOP", "stream", ts,
                    f"empty=0x{curr_empty:X} on non-eop beat",
                )

    # ── Internal ────────────────────────────────────────────────

    def _record(self, check_id: str, channel: str, ts: int, msg: str):
        v = ProtocolViolation(
            check_id=check_id, channel=channel, timestamp_ns=ts, message=msg
        )
        self._violations.append(v)
        self.log.error(f"[{check_id}] {msg}")
