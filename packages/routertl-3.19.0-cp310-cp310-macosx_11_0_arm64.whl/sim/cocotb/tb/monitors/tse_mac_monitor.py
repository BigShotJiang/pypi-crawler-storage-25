# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

# tb/monitors/tse_mac_monitor.py
"""
Passive Intel TSE MAC Register-Interface Protocol Monitor.

Monitors the Avalon-MM subset interface that Intel's Triple-Speed Ethernet
MAC megafunction exposes (the ``reg_*`` port group, per UG-01008 Table 58).

**Relationship to AvalonMMMonitor:**
This monitor is a *composition* over ``AvalonMMMonitor``, not a subclass.
It internally wires an ``AvalonMMMonitor`` against the same bus (with
``variant="tse"`` so the missing ``byteenable`` / ``readdatavalid`` /
``response`` signals are handled gracefully), and layers TWO additional
clauses specific to the Intel TSE register interface:

  TSE_RDATA_WINDOW  - ``reg_data_out`` is guaranteed valid only on the
                      cycle where ``reg_busy`` transitions 1→0 following
                      a ``reg_rd``. On any other cycle the value is
                      undefined. Lax-default mode records changes outside
                      the window informationally; strict mode flags them.

  TSE_BUSY_TIMEOUT  - ``reg_busy`` must deassert within a bounded number
                      of cycles: ``max_busy_cycles_direct`` (default 20)
                      for direct MAC/PCS registers, or ``max_busy_cycles_mdio``
                      (default 1000) for MDIO transactions (addresses in
                      ``mdio_addr_range``).

**Non-clauses (documented ambiguities):**
Per UG-01008 Table 58, ``reg_busy`` "can be high or low during idle cycles
and reset. Therefore, the user application must not make any assumption of
its assertion state during these periods." This monitor does NOT flag either
idle polarity — both are legal. Bridges must tolerate both; that property
is verified by test cases, not by this monitor.

Usage::

    tb.attach_monitors(tse_mac={"reg": {}})
    # ... run stimulus ...
    tb.check_monitors()

Contract spec: ``tb/contracts/tse_mac.md``.
"""

from __future__ import annotations

import logging
from typing import List, Tuple

from cocotb.triggers import RisingEdge
from cocotb.utils import get_sim_time

from . import ProtocolViolation
from .avalon_mm_monitor import AvalonMMMonitor


def _safe_int(sig, default: int = 0) -> int:
    """Read a signal as int, treating X/Z/U as *default*."""
    try:
        return int(sig.value)
    except Exception:
        return default


class TSEMACMonitor:
    """Passive Intel TSE MAC register-interface protocol monitor.

    Attach to an AvalonMMBus constructed with ``variant="tse"`` and start
    both the underlying ``AvalonMMMonitor`` (for generic AVMM checks) and
    the TSE-specific clauses (``TSE_RDATA_WINDOW``, ``TSE_BUSY_TIMEOUT``).

    Parameters
    ----------
    bus : AvalonMMBus
        The bus to monitor. Expected to be constructed with
        ``variant="tse"`` so ``byteenable``, ``readdatavalid``, and
        ``response`` are ``None``.
    clk : cocotb signal
        Clock signal of the MAC control-interface clock domain.
    rst : cocotb signal
        Reset signal.
    log : logging.Logger
        Logger instance.
    max_busy_cycles_direct : int
        Timeout for direct MAC/PCS register transactions. Default ``20``.
    max_busy_cycles_mdio : int
        Timeout for MDIO register transactions. Default ``1000``.
    mdio_addr_range : tuple[int, int]
        Inclusive address range treated as MDIO (slow path). Default
        ``(0xA0, 0xBF)`` per UG-01008 §5.1.
    strict_rdata_window : bool
        If ``True``, flag any change to ``reg_data_out`` outside the valid
        window as a violation. If ``False`` (default), record informationally
        without flagging — matches real hardware behaviour (data is retained,
        not zeroed).
    rst_active_low : bool
        Reset polarity. Default ``True`` (matches Intel MAC convention).
    """

    def __init__(
        self,
        bus,
        clk,
        rst,
        *,
        log: logging.Logger,
        max_busy_cycles_direct: int = 20,
        max_busy_cycles_mdio: int = 1000,
        mdio_addr_range: Tuple[int, int] = (0xA0, 0xBF),
        strict_rdata_window: bool = False,
        rst_active_low: bool = True,
    ):
        self.bus = bus
        self.clk = clk
        self.rst = rst
        self.log = log
        self.max_busy_cycles_direct = max_busy_cycles_direct
        self.max_busy_cycles_mdio = max_busy_cycles_mdio
        self.mdio_lo, self.mdio_hi = mdio_addr_range
        self.strict_rdata_window = strict_rdata_window
        self._rst_active_low = rst_active_low

        # Compose an underlying generic Avalon-MM monitor on the same bus.
        # Its violations are merged into ours via the ``violations`` property.
        self._avmm_mon = AvalonMMMonitor(
            bus, clk, rst,
            log=log,
            rst_active_low=rst_active_low,
        )

        # TSE-specific violations (added by our own run loop)
        self._tse_violations: List[ProtocolViolation] = []

        # Informational: rdata-outside-window changes (lax mode only)
        self._rdata_window_observations: int = 0

    # ── Public API ──────────────────────────────────────────────

    @property
    def violations(self) -> List[ProtocolViolation]:
        """All protocol violations (generic AVMM + TSE-specific)."""
        return list(self._avmm_mon.violations) + list(self._tse_violations)

    @property
    def violation_count(self) -> int:
        return len(self.violations)

    def report(self) -> str:
        """Formatted multi-line violation report."""
        vs = self.violations
        header = f"TSE MAC Monitor: {len(vs)} violation(s)"
        if not vs:
            header = "TSE MAC Monitor: 0 violations ✅"
        lines = [header]
        if self._rdata_window_observations and not self.strict_rdata_window:
            lines.append(
                f"  (info) reg_data_out changed outside valid window "
                f"{self._rdata_window_observations} time(s) — lax mode, "
                f"not flagged as violation"
            )
        for v in vs:
            lines.append(
                f"  [{v.check_id}] {v.channel} @ {v.timestamp_ns}ns: {v.message}"
            )
        return "\n".join(lines)

    # ── Main coroutine ──────────────────────────────────────────

    async def run(self):
        """Launch the composite monitor.

        Starts the underlying ``AvalonMMMonitor.run()`` as a background
        coroutine and then enters the TSE-specific monitor loop on the
        same thread.
        """
        import cocotb
        cocotb.start_soon(self._avmm_mon.run())
        await self._tse_run()

    async def _tse_run(self):
        """TSE-specific protocol monitor loop."""
        bus = self.bus

        # State for TSE_BUSY_TIMEOUT
        busy_since_cycle: int | None = None
        busy_addr: int | None = None
        busy_is_read: bool = False
        cycle: int = 0

        # State for TSE_RDATA_WINDOW
        prev_busy: int = 0
        prev_read: int = 0
        read_in_flight: bool = False
        last_rdata_in_window: int | None = None
        last_rdata_outside: int | None = None

        while True:
            await RisingEdge(self.clk)
            cycle += 1
            ts = int(get_sim_time("ns"))

            raw_rst = _safe_int(self.rst, default=0)
            rst_active = (not raw_rst) if self._rst_active_low else raw_rst
            if rst_active:
                busy_since_cycle = None
                busy_addr = None
                read_in_flight = False
                prev_busy = 0
                prev_read = 0
                continue

            curr_read = _safe_int(bus.read)
            curr_write = _safe_int(bus.write)
            curr_busy = _safe_int(bus.waitrequest)
            curr_addr = _safe_int(bus.address)
            curr_rdata = _safe_int(bus.readdata)

            # ── TSE_BUSY_TIMEOUT: bound the busy window ──
            if curr_busy and busy_since_cycle is None:
                # Entering busy — remember which kind of transaction
                busy_since_cycle = cycle
                busy_addr = curr_addr
                busy_is_read = bool(curr_read)
            elif not curr_busy and busy_since_cycle is not None:
                # Exiting busy — clear
                busy_since_cycle = None
                busy_addr = None
            elif curr_busy and busy_since_cycle is not None:
                # Still busy — check timeout
                duration = cycle - busy_since_cycle
                is_mdio = (
                    busy_addr is not None
                    and self.mdio_lo <= busy_addr <= self.mdio_hi
                )
                limit = (
                    self.max_busy_cycles_mdio
                    if is_mdio
                    else self.max_busy_cycles_direct
                )
                if duration == limit + 1:  # fire exactly once per runaway
                    kind = "MDIO" if is_mdio else "direct"
                    self._record(
                        "TSE_BUSY_TIMEOUT",
                        "reg",
                        ts,
                        f"reg_busy stuck HIGH for >{limit} cycles "
                        f"({kind} transaction, addr=0x{busy_addr:02X})",
                    )

            # ── TSE_RDATA_WINDOW: reg_data_out valid only on busy 1→0 edge ──
            busy_fell = (prev_busy == 1 and curr_busy == 0)
            read_accepted_this_cycle = (curr_read == 1 and curr_busy == 0)

            # Track a read in flight. A read is "in flight" once asserted;
            # it completes on the busy 1→0 edge (TSE implicit-latency) OR
            # on the cycle where read=1 & busy=0 (accept-and-complete in
            # the same cycle, when BUSY_DELAY==0 in the Intel MAC).
            if curr_read and not read_in_flight:
                read_in_flight = True

            # Determine if THIS cycle is the valid window for rdata
            in_valid_window = False
            if read_in_flight:
                # Valid window = cycle where busy transitions 1→0 while
                # read is (or was recently) asserted, OR the single cycle
                # where read=1 & busy=0 (fast path with no busy).
                if busy_fell or read_accepted_this_cycle:
                    in_valid_window = True
                    read_in_flight = False
                    last_rdata_in_window = curr_rdata

            # Check rdata stability outside the window
            if not in_valid_window and read_in_flight:
                # We're inside the "read issued, waiting for completion" region.
                # reg_data_out is explicitly undefined here per the spec.
                # In strict mode, flag any change.
                if last_rdata_outside is None:
                    last_rdata_outside = curr_rdata
                elif curr_rdata != last_rdata_outside:
                    self._rdata_window_observations += 1
                    if self.strict_rdata_window:
                        self._record(
                            "TSE_RDATA_WINDOW",
                            "reg",
                            ts,
                            f"reg_data_out changed outside valid window "
                            f"while read in flight "
                            f"(was 0x{last_rdata_outside:08X}, now 0x{curr_rdata:08X})",
                        )
                    last_rdata_outside = curr_rdata

            if in_valid_window:
                last_rdata_outside = None  # reset for next read

            prev_busy = curr_busy
            prev_read = curr_read

    # ── Internal ────────────────────────────────────────────────

    def _record(self, check_id: str, channel: str, ts: int, msg: str):
        v = ProtocolViolation(
            check_id=check_id, channel=channel, timestamp_ns=ts, message=msg
        )
        self._tse_violations.append(v)
        self.log.error(f"[{check_id}] {msg}")
