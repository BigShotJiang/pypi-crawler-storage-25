# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

# tb/bit.py
from __future__ import annotations


def field(x: int, lsb: int, width: int) -> int:
    """Extract unsigned field of 'width' bits starting at 'lsb' (0-based)."""
    if width <= 0:
        raise ValueError("width must be > 0")
    return (x >> lsb) & ((1 << width) - 1)


def set_field(x: int, lsb: int, width: int, value: int) -> int:
    """Return x with the field [lsb+width-1:lsb] replaced by 'value'."""
    if value < 0 or value >= (1 << width):
        raise ValueError("value out of range for field width")
    mask = ((1 << width) - 1) << lsb
    return (x & ~mask) | ((value << lsb) & mask)


def sign_extend(x: int, width: int) -> int:
    """Interpret x as a signed 'width'-bit value and return as Python int."""
    sign = 1 << (width - 1)
    return (x ^ sign) - sign


def bits(x: int, hi: int, lo: int) -> int:
    """Inclusive slice helper [hi:lo] if you prefer that style."""
    if hi < lo:
        raise ValueError("hi must be >= lo")
    return field(x, lsb=lo, width=hi - lo + 1)
