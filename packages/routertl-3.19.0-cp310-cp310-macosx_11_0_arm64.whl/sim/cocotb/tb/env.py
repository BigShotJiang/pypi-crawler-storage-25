# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

# tb/env.py
from __future__ import annotations

import inspect
import json
import logging
import os
import sys

import cocotb
from cocotb.clock import Clock
from cocotb.triggers import ClockCycles

# Defaults (override via env vars if you want)
_DEFAULT_LOG_LEVEL = os.getenv("TB_LOG_LEVEL", "INFO").upper()
_DEFAULT_LOG_DIR = os.getenv("TB_LOG_DIR", "logs")  # folder next to the test run
_DEFAULT_LOG_FMT = os.getenv("TB_LOG_FORMAT", "text")  # "text" | "json"
_DEFAULT_FILE_TPL = os.getenv("TB_LOG_FILE", "{test}.log")  # used inside logs/


class _ContextFilter(logging.Filter):
    def __init__(self, **ctx):
        super().__init__()
        self.ctx = ctx

    def filter(self, record):
        for k, v in self.ctx.items():
            setattr(record, k, v)
        # Inject sim_time if not already present
        if not hasattr(record, "sim_time"):
            try:
                t = cocotb.utils.get_sim_time(unit="ns")
                setattr(record, "sim_time", f"{t: >9.0f}ns")
            except Exception:
                setattr(record, "sim_time", "      0ns")
        return True


class _JsonFormatter(logging.Formatter):
    def format(self, record):
        data = {
            "t": self.formatTime(record, self.datefmt),
            "lvl": record.levelname,
            "name": record.name,
            "msg": record.getMessage(),
            "test": getattr(record, "test", None),
            # "seed": getattr(record, "seed", None),
            # "dev_id": getattr(record, "dev_id", None),
        }
        return json.dumps({k: v for k, v in data.items() if v is not None}, ensure_ascii=False)


def _detect_test_name(dut) -> str:
    # 1) If running under pytest, this is reliable
    node = os.getenv("PYTEST_CURRENT_TEST", "")
    if node:
        # "path/to/test_edge_detector.py::test_basic_edges (call)"
        return node.split("::")[-1].split(" ")[0]

    # 2) Walk the Python stack: grab the first function that looks like a test
    #    (works even when cocotb doesn't expose current_test)
    for frame in inspect.stack():
        name = frame.function
        if name.startswith("test_"):
            return name

    # 3) Fallbacks
    return getattr(dut, "_name", None) or "cocotb_test"


class TbEnv:
    """Standardized testbench environment for cocotb simulations.

    Manages clock generation, reset sequencing, structured logging, and
    protocol monitor lifecycle.  Aliased as ``Tb`` in the public API::

        from routertl.sim import Tb
        tb = Tb(dut, clk="CLK", rst="RST")

    Attributes
    ----------
    dut : SimHandleBase
        Top-level DUT handle.
    clk : LogicObject
        Resolved clock signal (coerced to scalar).
    rst : SimHandleBase
        Reset signal handle.
    period_ns : int
        Clock period in nanoseconds.
    test_name : str
        Auto-detected or user-supplied test name.
    seed : int
        Simulation seed (from ``COCOTB_SEED`` or ``PYTHONHASHSEED``).
    dev_id : int
        Device ID read from the ``G_DEV_ID`` generic.
    log : logging.Logger
        Structured logger with console and file output.
    """

    def __init__(
        self,
        dut,
        clk: str = "CLK",
        rst: str = "RST",
        period_ns: int = 10,
        dev_id_generic: str = "G_DEV_ID",
        test_name: str | None = None,
        log_level: str = _DEFAULT_LOG_LEVEL,
        log_dir: str = _DEFAULT_LOG_DIR,
        log_format: str = _DEFAULT_LOG_FMT,
        file_template: str = _DEFAULT_FILE_TPL,
    ):
        """Create a testbench environment.

        Parameters
        ----------
        dut : cocotb.handle.SimHandleBase
            Top-level DUT handle passed by the cocotb test runner.
        clk : str
            Name of the clock port on the DUT. Default ``"CLK"``.
        rst : str
            Name of the reset port on the DUT. Default ``"RST"``.
        period_ns : int
            Clock period in nanoseconds. Default ``10`` (100 MHz).
        dev_id_generic : str
            VHDL generic name for the device ID. Default ``"G_DEV_ID"``.
        test_name : str, optional
            Override the auto-detected test name for logging.
        log_level : str
            Logging level (``"DEBUG"``, ``"INFO"``, etc.).
            Overridable via ``TB_LOG_LEVEL`` env var.
        log_dir : str
            Directory for log files. Default ``"logs"``.
            Overridable via ``TB_LOG_DIR`` env var.
        log_format : str
            Log output format: ``"text"`` or ``"json"``.
            Overridable via ``TB_LOG_FORMAT`` env var.
        file_template : str
            Log filename template. Use ``{test}`` placeholder.
            Default ``"{test}.log"``. Overridable via ``TB_LOG_FILE``.

        Example
        -------
        >>> tb = TbEnv(dut, clk="SYS_CLK", rst="RESET_N", period_ns=8)
        >>> await tb.start_clock()
        >>> await tb.reset(active_low=True)
        """
        self.dut = dut
        self.clk = getattr(dut, clk)
        self.rst = getattr(dut, rst)
        self.period_ns = period_ns

        raw_clk = getattr(dut, clk)
        self.clk = self._as_scalar_logic(raw_clk, clk)

        self.test_name = test_name or _detect_test_name(dut)
        self.seed = int(os.getenv("COCOTB_SEED") or os.getenv("PYTHONHASHSEED") or "0")
        self.dev_id = self._read_generic_int(dev_id_generic)

        self.log = self._setup_logging(
            level=log_level,
            log_dir=log_dir,
            log_format=log_format,
            file_template=file_template,
        )
        self._monitors: list = []
        self.log.info(f"Env ready (dev_id={self.dev_id}, period_ns={self.period_ns}, seed={self.seed})")

    def _as_scalar_logic(self, h, name: str):
        """
        Coerce a clock/reset handle into a scalar LogicObject for cocotb triggers.
        Useful when simulators expose 1-bit vectors as array-like objects.
        """
        # If it's already scalar-ish, keep it.
        # (We avoid relying on exact class names across simulators.)
        try:
            # Many cocotb handle types have len() only for arrays.
            # Scalars often raise TypeError on len().
            _ = len(h)
        except Exception:
            return h

        # If it is indexable, try the common 1-bit case [0].
        try:
            h0 = h[0]
            # If indexing returned something non-array-like, great.
            try:
                _ = len(h0)
            except Exception:
                return h0
            # If still array-like, keep h0 anyway as best effort.
            return h0
        except Exception:
            # Subscript failed, so it's likely a scalar that reported a length (e.g. LogicObject)
            # but doesn't support indexing. Return as is.
            return h

    def _read_generic_int(self, name: str) -> int:
        # 1. Try environment variable (passed by SDK backend)
        if name in os.environ:
            try:
                return int(os.environ[name])
            except ValueError:
                pass

        # 2. Try DUT Generic (GPI) - fallback
        try:
            if not hasattr(self.dut, name):
                logging.getLogger("tb").warning(f"Generic '{name}' not found on DUT; defaulting to 0")
                return 0
            obj = getattr(self.dut, name)
            return int(obj.value)
        except Exception:
            # Catch GPI_UNKNOWN or other access errors
            logging.getLogger("tb").warning(f"Could not read generic '{name}' via GPI; defaulting to 0")
            return 0

    def _setup_logging(self, level: str, log_dir: str, log_format: str, file_template: str) -> logging.Logger:
        logger = logging.getLogger("tb")
        if not getattr(logger, "_tb_configured", False):
            logger.setLevel(getattr(logging, level, logging.INFO))
            logger.propagate = False

            # Formatters
            if log_format.lower() == "json":
                formatter = _JsonFormatter()
            else:
                # Fixed width formatting for aligned columns
                # asctime (8) | levelname (7) | name (5) | test (30) | sim_time (12) | message
                formatter = logging.Formatter(
                    fmt="%(asctime)s | %(levelname)-7s | %(name)-5s | %(test)-30s | %(sim_time)-12s | %(message)s",
                    datefmt="%H:%M:%S",
                )

            # Context (added to every record)
            ctx = _ContextFilter(test=self.test_name, seed=self.seed, dev_id=self.dev_id)

            # Clear existing handlers if they exist (to avoid duplication when running multiple tests in one process)
            if logger.hasHandlers():
                for h in logger.handlers[:]:
                    logger.removeHandler(h)

            # Console handler
            ch = logging.StreamHandler(stream=sys.stdout)
            ch.setLevel(getattr(logging, level, logging.INFO))
            ch.setFormatter(formatter)
            ch.addFilter(ctx)
            logger.addHandler(ch)

            # File handler (logs/<name>.log)
            os.makedirs(log_dir, exist_ok=True)
            test_name = self.test_name or "cocotb_test"
            fname = file_template.format(test=test_name)
            if not fname or fname == ".log":  # safety
                fname = f"{self.test_name}.log"
            # disambiguate if running in parallel
            worker = os.getenv("PYTEST_XDIST_WORKER")  # e.g. "gw0", "gw1" when using -n auto
            if worker and "{worker}" in file_template:
                fname = file_template.format(test=test_name, worker=worker)

            file_path = os.path.join(log_dir, fname)

            fh = logging.FileHandler(file_path, mode="w", encoding="utf-8")
            fh.setLevel(getattr(logging, level, logging.INFO))
            fh.setFormatter(formatter)
            fh.addFilter(ctx)
            logger.addHandler(fh)

            # Explicitly set flush level for FileHandler to ensure messages appear promptly
            # (Note: logging doesn't have a direct flush policy, but we can wrap it if needed.
            # For now, relying on clearing handlers should fix most sync issues.)

            logger.info(f"Logging to {file_path}")

            # (Optional) align cocotb logger level
            logging.getLogger("cocotb").setLevel(getattr(logging, level, logging.INFO))

            logger._tb_configured = True
        else:
            # Update context on all handlers
            for h in logger.handlers:
                for f in getattr(h, "filters", []):
                    if isinstance(f, _ContextFilter):
                        f.ctx.update(test=self.test_name, seed=self.seed, dev_id=self.dev_id)

            # Compute desired file path for THIS test
            os.makedirs(log_dir, exist_ok=True)
            test_name = self.test_name or "cocotb_test"
            fname = file_template.format(test=test_name)
            desired_path = os.path.join(log_dir, fname)

            # Find the existing file handler (if any)
            current_fh = next((h for h in logger.handlers if isinstance(h, logging.FileHandler)), None)
            current_path = getattr(current_fh, "baseFilename", None) if current_fh else None

            # Ensure StreamHandler exists (for console output)
            current_sh = next((h for h in logger.handlers if isinstance(h, logging.StreamHandler)), None)
            if not current_sh:
                ch = logging.StreamHandler(stream=sys.stdout)
                ch.setLevel(logger.level)
                # Reuse formatter if possible, else default
                fmtr = (
                    logger.handlers[0].formatter
                    if logger.handlers
                    else logging.Formatter(
                        "%(asctime)s | %(levelname)-7s | %(name)-5s | %(test)-30s | %(sim_time)-12s | %(message)s",
                        datefmt="%H:%M:%S",
                    )
                )
                ch.setFormatter(fmtr)
                ch.addFilter(_ContextFilter(test=self.test_name, seed=self.seed, dev_id=self.dev_id))
                logger.addHandler(ch)

            # Rotate if different
            if current_path != desired_path:
                if current_fh:
                    current_fh.flush()  # Ensure logs hit disk
                    logger.removeHandler(current_fh)
                    current_fh.close()
                fh = logging.FileHandler(desired_path, mode="w", encoding="utf-8")
                # reuse formatter from console handler
                formatter = logger.handlers[0].formatter if logger.handlers else logging.Formatter("%(message)s")
                # Force alignment if reusing
                if isinstance(formatter, logging.Formatter):
                    # We want to enforce our aligned format even if reusing, unless it's JSON
                    formatter = logging.Formatter(
                        fmt="%(asctime)s | %(levelname)-7s | %(name)-5s | %(test)-30s | %(sim_time)-12s | %(message)s",
                        datefmt="%H:%M:%S",
                    )
                fh.setFormatter(formatter)
                fh.addFilter(_ContextFilter(test=self.test_name, seed=self.seed, dev_id=self.dev_id))
                fh.setLevel(logger.level)
                logger.addHandler(fh)
                logger.info(f"Logging to {desired_path}")

        return logger

    async def start_clock(self) -> None:
        """Start the DUT clock as a background cocotb coroutine.

        Uses the ``period_ns`` configured in the constructor.
        Must be called before any clock-dependent operations.

        This method checks if the clock task is already running. Since
        cocotb kills background tasks between tests, it will cleanly
        restart the clock for subsequent tests while preventing
        ResolutionErrors within a single test.
        """
        task = getattr(self.dut, "_rr_clock_task", None)
        if task is None or task.done():
            self.dut._rr_clock_task = cocotb.start_soon(Clock(self.clk, self.period_ns, unit="ns").start())
            self.log.debug("Clock started")

    def attach_monitors(
        self,
        axi_lite: dict | None = None,
        avalon_mm: dict | None = None,
        avalon_st: dict | None = None,
        tse_mac: dict | None = None,
    ):
        """Attach passive protocol monitors to one or more bus interfaces.

        Registers the monitors and starts each as a background coroutine.
        Call :meth:`check_monitors` at the end of a test to assert 0 violations.

        Parameters
        ----------
        axi_lite : dict, optional
            Mapping of ``{prefix: kwargs}`` for AXI-Lite buses, e.g.:
            ``{"S": {"rst_active_low": True}}``
        avalon_mm : dict, optional
            Mapping of ``{prefix: kwargs}`` for Avalon-MM buses, e.g.:
            ``{"M_AVL": {"rst_active_low": True}}``. Pass
            ``variant="tse"`` / ``"minimal"`` to handle vendor subsets where
            ``byteenable`` / ``readdatavalid`` / ``response`` are absent.
        avalon_st : dict, optional
            Mapping of ``{prefix: kwargs}`` for Avalon-Streaming buses,
            e.g.: ``{"src": {"rst_active_low": True}}``. Optional signals
            (sop/eop/empty/channel/error) are auto-discovered and checks
            skipped if absent. Minimal valid+ready+data bus still gets
            AST_DATA_HOLD + AST_RST coverage.
        tse_mac : dict, optional
            Mapping of ``{prefix: kwargs}`` for Intel TSE MAC register
            interfaces (Avalon-MM subset per UG-01008 Table 58), e.g.:
            ``{"reg": {"max_busy_cycles_mdio": 1000}}``. The underlying
            bus is always constructed with ``variant="tse"``.
        """
        # Lazy imports to avoid circular deps at module load time
        from tb.drivers.avalon_mm import AvalonMMBus
        from tb.drivers.avalon_streaming import AvalonStreamBus
        from tb.drivers.axi_lite import AxiLiteBus
        from tb.monitors.avalon_mm_monitor import AvalonMMMonitor
        from tb.monitors.avalon_streaming_monitor import AvalonStreamMonitor
        from tb.monitors.axi_lite_monitor import AxiLiteMonitor
        from tb.monitors.tse_mac_monitor import TSEMACMonitor

        for prefix, kw in (axi_lite or {}).items():
            bus = AxiLiteBus.from_prefix(self.dut, prefix)
            mon = AxiLiteMonitor(bus, self.clk, self.rst, log=self.log, **kw)
            cocotb.start_soon(mon.run())
            self._monitors.append(mon)
            self.log.debug(f"AXI-Lite monitor attached (prefix='{prefix}')")

        for prefix, kw in (avalon_mm or {}).items():
            # Extract bus-construction params (variant) from monitor kwargs.
            kw = dict(kw)
            variant = kw.pop("variant", "full")
            bus = AvalonMMBus.from_prefix(self.dut, prefix, variant=variant)
            mon = AvalonMMMonitor(bus, self.clk, self.rst, log=self.log, **kw)
            cocotb.start_soon(mon.run())
            self._monitors.append(mon)
            self.log.debug(
                f"Avalon-MM monitor attached (prefix='{prefix}', variant='{variant}')"
            )

        for prefix, kw in (avalon_st or {}).items():
            bus = AvalonStreamBus.from_prefix(self.dut, prefix)
            mon = AvalonStreamMonitor(bus, self.clk, self.rst, log=self.log, **kw)
            cocotb.start_soon(mon.run())
            self._monitors.append(mon)
            self.log.debug(f"Avalon-ST monitor attached (prefix='{prefix}')")

        for prefix, kw in (tse_mac or {}).items():
            bus = AvalonMMBus.from_prefix(self.dut, prefix, variant="tse")
            mon = TSEMACMonitor(bus, self.clk, self.rst, log=self.log, **kw)
            cocotb.start_soon(mon.run())
            self._monitors.append(mon)
            self.log.debug(f"TSE MAC monitor attached (prefix='{prefix}')")

    def check_monitors(self):
        """Assert that all attached protocol monitors recorded zero violations.

        Logs the full report for every monitor (pass or fail) then raises
        ``AssertionError`` with a combined summary if any violation was found.
        """
        all_violations = []
        for mon in self._monitors:
            self.log.info(mon.report())
            all_violations.extend(mon.violations)

        if all_violations:
            lines = [f"{len(all_violations)} protocol violation(s) detected:"]
            for v in all_violations:
                lines.append(f"  [{v.check_id}] {v.channel} @ {v.timestamp_ns}ns: {v.message}")
            raise AssertionError("\n".join(lines))

    async def reset(self, cycles: int = 5, active_low: bool = False) -> None:
        """Assert and release the DUT reset signal.

        Drives the reset for the specified number of clock cycles, then
        waits 2 additional cycles for the design to stabilize.

        Parameters
        ----------
        cycles : int
            Number of clock cycles to hold reset asserted. Default ``5``.
        active_low : bool
            If ``True``, reset is asserted low (0) and released high (1).
            If ``False`` (default), reset is asserted high (1) and released
            low (0).
        """
        if active_low:
            self.rst.value = 0
            await ClockCycles(self.clk, cycles)
            self.rst.value = 1
        else:
            self.rst.value = 1
            await ClockCycles(self.clk, cycles)
            self.rst.value = 0
        await ClockCycles(self.clk, 2)
        self.log.debug("Reset released")
