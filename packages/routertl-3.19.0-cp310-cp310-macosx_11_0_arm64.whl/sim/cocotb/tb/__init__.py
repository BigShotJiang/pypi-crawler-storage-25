# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

# tb/__init__.py
"""Testbench utilities — lazy-loaded to avoid cocotb import at package level.

``bit.py`` is pure Python (no cocotb) so it's imported eagerly.
``signal.py`` requires cocotb and is deferred via ``__getattr__``.
"""

from .bit import bits, field, set_field, sign_extend  # noqa: F401

__all__ = [
    "bits", "field", "set_field", "sign_extend",
    "read_bit", "read_vector_int", "set_bit", "write_bits",
]

_SIGNAL_NAMES = {"read_bit", "read_vector_int", "set_bit", "write_bits",
                 "toggle_bit", "read_slice", "write_slice"}


def __getattr__(name):
    if name in _SIGNAL_NAMES:
        from . import signal  # noqa: F811

        return getattr(signal, name)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
