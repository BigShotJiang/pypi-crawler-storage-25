# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

# tb/drivers/spi.py
"""
Native SPI Master/Slave Drivers for Cocotb Testbenches

Provides pure-Python SPI signal generation and reception for testing
SPI-based designs without external dependencies.

Key features:
- Zero external dependencies (no cocotbext-spi required)
- All 4 CPOL/CPHA modes supported
- Configurable word width (1-32 bits)
- MSB/LSB first transmission
- CS active low/high
- Blocking and non-blocking write methods

Usage:
    # Create bus from individual signals
    spi_bus = SpiBus(sclk=dut.SCLK, mosi=dut.MOSI, miso=dut.MISO, cs=dut.CS)

    # Or from entity (auto-detect signals)
    spi_bus = SpiBus.from_entity(dut)

    # Configure and create master
    config = SpiConfig(word_width=8, sclk_freq=1e6, cpol=False, cpha=False)
    master = SpiMaster(spi_bus, config)

    # Write data
    await master.write([0xAA, 0x55])

    # Non-blocking write
    master.write_nowait([0xDE, 0xAD])
"""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass
from typing import List, Optional

import cocotb
from cocotb.handle import SimHandleBase
from cocotb.triggers import FallingEdge, RisingEdge, Timer

__all__ = ["SpiBus", "SpiConfig", "SpiMaster", "SpiSlave"]


@dataclass
class SpiBus:
    """
    SPI Bus signal container.

    Holds references to SPI signals for use with SpiMaster/SpiSlave.

    Attributes:
        sclk: Serial clock signal
        mosi: Master Out Slave In (optional for slave-only)
        miso: Master In Slave Out (optional for master-only TX)
        cs: Chip select signal (active low by default)
    """

    sclk: SimHandleBase
    mosi: Optional[SimHandleBase] = None
    miso: Optional[SimHandleBase] = None
    cs: Optional[SimHandleBase] = None

    @classmethod
    def from_entity(cls, entity: SimHandleBase, prefix: str = "") -> "SpiBus":
        """
        Create SpiBus by auto-detecting signals from an entity.

        Searches for common SPI signal names with optional prefix.

        Args:
            entity: DUT or entity containing SPI signals
            prefix: Optional prefix for signal names (e.g., "SPI_")

        Returns:
            SpiBus instance with detected signals

        Raises:
            AttributeError: If required signals not found
        """
        # Common signal name patterns
        sclk_names = ["SCLK", "SCK", "SPI_SCLK", "SPI_SCK", "CLK"]
        mosi_names = ["MOSI", "SDI", "SPI_MOSI", "SPI_SDI", "DIN", "SI"]
        miso_names = ["MISO", "SDO", "SPI_MISO", "SPI_SDO", "DOUT", "SO"]
        cs_names = ["CS", "SS", "CSN", "SSN", "SPI_CS", "SPI_SS", "CS_N", "SS_N", "NSS"]

        def find_signal(names: List[str]) -> Optional[SimHandleBase]:
            for name in names:
                full_name = f"{prefix}{name}" if prefix else name
                try:
                    return getattr(entity, full_name)
                except AttributeError:
                    continue
            return None

        sclk = find_signal(sclk_names)
        if sclk is None:
            raise AttributeError(f"Could not find SCLK signal on entity {entity._name}")

        return cls(
            sclk=sclk,
            mosi=find_signal(mosi_names),
            miso=find_signal(miso_names),
            cs=find_signal(cs_names),
        )

    @classmethod
    def from_prefix(cls, entity: SimHandleBase, prefix: str) -> "SpiBus":
        """Create SpiBus from entity with given prefix."""
        return cls.from_entity(entity, prefix)


@dataclass
class SpiConfig:
    """
    SPI configuration parameters.

    Attributes:
        word_width: Number of bits per SPI word (1-32)
        sclk_freq: Clock frequency in Hz
        cpol: Clock polarity (False=idle low, True=idle high)
        cpha: Clock phase (False=sample on first edge, True=sample on second edge)
        msb_first: Bit order (True=MSB first, False=LSB first)
        cs_active_low: CS polarity (True=active low, False=active high)
        data_output_idle: Idle value for MOSI/MISO (0 or 1)
        frame_spacing_ns: Minimum time between frames
        ignore_rx_value: MISO value to ignore (None = don't ignore any)
    """

    word_width: int = 8
    sclk_freq: float = 1_000_000  # 1 MHz default
    cpol: bool = False
    cpha: bool = False
    msb_first: bool = True
    cs_active_low: bool = True
    data_output_idle: int = 1
    frame_spacing_ns: int = 0
    ignore_rx_value: Optional[int] = None

    @property
    def half_period_ns(self) -> int:
        """Half period of SCLK in nanoseconds."""
        return int(0.5e9 / self.sclk_freq)

    @property
    def period_ns(self) -> int:
        """Full period of SCLK in nanoseconds."""
        return int(1e9 / self.sclk_freq)

    @property
    def cs_assert_value(self) -> int:
        """Value to assert CS (active)."""
        return 0 if self.cs_active_low else 1

    @property
    def cs_deassert_value(self) -> int:
        """Value to deassert CS (inactive)."""
        return 1 if self.cs_active_low else 0


class SpiMaster:
    """
    SPI Master Driver.

    Generates SPI transactions as a bus master. Supports all 4 SPI modes
    (combinations of CPOL and CPHA).

    SPI Modes:
        Mode 0: CPOL=0, CPHA=0 - Clock idle low, sample on rising edge
        Mode 1: CPOL=0, CPHA=1 - Clock idle low, sample on falling edge
        Mode 2: CPOL=1, CPHA=0 - Clock idle high, sample on falling edge
        Mode 3: CPOL=1, CPHA=1 - Clock idle high, sample on rising edge

    Args:
        bus: SpiBus instance with signal references
        config: SpiConfig with timing and mode settings

    Example:
        bus = SpiBus.from_entity(dut)
        config = SpiConfig(word_width=16, sclk_freq=10e6, cpol=False, cpha=True)
        master = SpiMaster(bus, config)

        received = await master.write([0xABCD])  # Write and read simultaneously
    """

    def __init__(self, bus: SpiBus, config: SpiConfig):
        """Create an SPI master driver.

        Parameters
        ----------
        bus : SpiBus
            Bus signals container.
        config : SpiConfig
            SPI mode, timing, and protocol configuration.
        """
        self.bus = bus
        self.config = config

        # Pending write queue for write_nowait
        self._write_queue: deque = deque()
        self._write_task = None

        # Initialize signals to idle state
        self._init_signals()

    def _init_signals(self):
        """Initialize all signals to idle state."""
        # SCLK idle state depends on CPOL
        self.bus.sclk.value = 1 if self.config.cpol else 0

        # MOSI idle
        if self.bus.mosi is not None:
            self.bus.mosi.value = self.config.data_output_idle

        # CS deasserted (inactive)
        if self.bus.cs is not None:
            self.bus.cs.value = self.config.cs_deassert_value

    async def write(self, data: List[int]) -> List[int]:
        """
        Perform a blocking SPI write transaction.

        Writes data words while simultaneously reading MISO. This is the
        standard full-duplex SPI operation.

        Args:
            data: List of words to transmit (each masked to word_width)

        Returns:
            List of words received from MISO
        """
        return await self._transfer(data)

    def write_nowait(self, data: List[int]) -> None:
        """
        Queue a non-blocking SPI write.

        Adds data to the write queue and starts transmission if not
        already in progress. Does not wait for completion.

        Args:
            data: List of words to transmit
        """
        self._write_queue.extend(data)

        if self._write_task is None or self._write_task.done():
            self._write_task = cocotb.start_soon(self._process_write_queue())

    async def _process_write_queue(self):
        """Process queued write_nowait data."""
        while self._write_queue:
            word = self._write_queue.popleft()
            await self._transfer([word])

    async def _transfer(self, data: List[int]) -> List[int]:
        """
        Perform the actual SPI transfer.

        Handles CS assertion, clocking, and data shifting according to
        the configured mode (CPOL/CPHA).
        """
        received = []
        half_period = self.config.half_period_ns
        word_width = self.config.word_width
        word_mask = (1 << word_width) - 1

        # Assert CS
        if self.bus.cs is not None:
            self.bus.cs.value = self.config.cs_assert_value
            await Timer(half_period, unit="ns")

        for word in data:
            word = word & word_mask
            rx_word = 0

            for bit_idx in range(word_width):
                # Determine which bit to send
                if self.config.msb_first:
                    bit_pos = word_width - 1 - bit_idx
                else:
                    bit_pos = bit_idx

                tx_bit = (word >> bit_pos) & 1

                # Mode determines when to output data and when to sample
                if not self.config.cpha:
                    # CPHA=0: Output data before first edge, sample on first edge

                    # Output data on MOSI
                    if self.bus.mosi is not None:
                        self.bus.mosi.value = tx_bit

                    await Timer(half_period, unit="ns")

                    # First edge (rising if CPOL=0, falling if CPOL=1)
                    if self.config.cpol:
                        self.bus.sclk.value = 0  # Falling edge
                    else:
                        self.bus.sclk.value = 1  # Rising edge

                    # Sample MISO on first edge
                    if self.bus.miso is not None:
                        rx_bit = int(self.bus.miso.value) & 1
                        if self.config.msb_first:
                            rx_word |= rx_bit << bit_pos
                        else:
                            rx_word |= rx_bit << bit_pos

                    await Timer(half_period, unit="ns")

                    # Second edge (return to idle)
                    if self.config.cpol:
                        self.bus.sclk.value = 1  # Rising edge (back to idle high)
                    else:
                        self.bus.sclk.value = 0  # Falling edge (back to idle low)

                else:
                    # CPHA=1: Output data on first edge, sample on second edge

                    # First edge
                    if self.config.cpol:
                        self.bus.sclk.value = 0  # Falling edge
                    else:
                        self.bus.sclk.value = 1  # Rising edge

                    # Output data on first edge
                    if self.bus.mosi is not None:
                        self.bus.mosi.value = tx_bit

                    await Timer(half_period, unit="ns")

                    # Second edge
                    if self.config.cpol:
                        self.bus.sclk.value = 1  # Rising edge (back to idle)
                    else:
                        self.bus.sclk.value = 0  # Falling edge (back to idle)

                    # Sample MISO on second edge
                    if self.bus.miso is not None:
                        rx_bit = int(self.bus.miso.value) & 1
                        if self.config.msb_first:
                            rx_word |= rx_bit << bit_pos
                        else:
                            rx_word |= rx_bit << bit_pos

                    await Timer(half_period, unit="ns")

            # Check if we should ignore this value
            if self.config.ignore_rx_value is not None and rx_word == self.config.ignore_rx_value:
                pass  # Don't add to received list
            else:
                received.append(rx_word)

        # Frame spacing
        if self.config.frame_spacing_ns > 0:
            await Timer(self.config.frame_spacing_ns, unit="ns")

        # Deassert CS
        if self.bus.cs is not None:
            self.bus.cs.value = self.config.cs_deassert_value
            await Timer(half_period, unit="ns")

        # Return MOSI to idle
        if self.bus.mosi is not None:
            self.bus.mosi.value = self.config.data_output_idle

        return received

    async def read(self, count: int) -> List[int]:
        """
        Read data from SPI (send zeros/dummy data).

        Args:
            count: Number of words to read

        Returns:
            List of words received from MISO
        """
        dummy_data = [0] * count
        return await self.write(dummy_data)


class SpiSlave:
    """
    SPI Slave Driver (for verification).

    Monitors SPI bus and responds as a slave device. Useful for testing
    SPI master implementations.

    Args:
        bus: SpiBus instance with signal references
        config: SpiConfig with timing and mode settings

    Example:
        slave = SpiSlave(bus, config)
        slave.set_response_data([0xDEAD, 0xBEEF])
        cocotb.start_soon(slave.start())
    """

    def __init__(self, bus: SpiBus, config: SpiConfig):
        """Create an SPI slave driver.

        Parameters
        ----------
        bus : SpiBus
            Bus signals container.
        config : SpiConfig
            SPI mode, timing, and protocol configuration.
        """
        self.bus = bus
        self.config = config

        # Data to send on MISO
        self._response_queue: deque = deque()

        # Received data from MOSI
        self._received_data: List[int] = []

        # Running flag
        self._running = False

    def set_response_data(self, data: List[int]) -> None:
        """Set data to respond with on MISO."""
        self._response_queue.clear()
        self._response_queue.extend(data)

    def get_received_data(self) -> List[int]:
        """Get data received from MOSI."""
        return list(self._received_data)

    def clear_received(self) -> None:
        """Clear received data buffer."""
        self._received_data.clear()

    async def start(self) -> None:
        """
        Start the slave driver coroutine.

        Must be started with cocotb.start_soon(slave.start()).
        Runs until stop() is called.
        """
        self._running = True
        word_width = self.config.word_width

        while self._running:
            # Wait for CS assertion
            if self.bus.cs is not None:
                # Wait for CS to go active
                while int(self.bus.cs.value) != self.config.cs_assert_value:
                    await Timer(10, unit="ns")
                    if not self._running:
                        return

            # Get response word or use 0
            if self._response_queue:
                tx_word = self._response_queue.popleft()
            else:
                tx_word = 0

            rx_word = 0

            # Process bits
            for bit_idx in range(word_width):
                if self.config.msb_first:
                    bit_pos = word_width - 1 - bit_idx
                else:
                    bit_pos = bit_idx

                tx_bit = (tx_word >> bit_pos) & 1

                if not self.config.cpha:
                    # CPHA=0: Output before first edge, sample on first edge
                    if self.bus.miso is not None:
                        self.bus.miso.value = tx_bit

                    # Wait for first edge (sample)
                    if self.config.cpol:
                        await FallingEdge(self.bus.sclk)
                    else:
                        await RisingEdge(self.bus.sclk)

                    # Sample MOSI
                    if self.bus.mosi is not None:
                        rx_bit = int(self.bus.mosi.value) & 1
                        rx_word |= rx_bit << bit_pos

                    # Wait for second edge
                    if self.config.cpol:
                        await RisingEdge(self.bus.sclk)
                    else:
                        await FallingEdge(self.bus.sclk)
                else:
                    # CPHA=1: Output on first edge, sample on second edge

                    # Wait for first edge (output)
                    if self.config.cpol:
                        await FallingEdge(self.bus.sclk)
                    else:
                        await RisingEdge(self.bus.sclk)

                    if self.bus.miso is not None:
                        self.bus.miso.value = tx_bit

                    # Wait for second edge (sample)
                    if self.config.cpol:
                        await RisingEdge(self.bus.sclk)
                    else:
                        await FallingEdge(self.bus.sclk)

                    # Sample MOSI
                    if self.bus.mosi is not None:
                        rx_bit = int(self.bus.mosi.value) & 1
                        rx_word |= rx_bit << bit_pos

            self._received_data.append(rx_word)

            # Wait for CS deassert or next word
            if self.bus.cs is not None:
                # Small delay to check CS
                await Timer(10, unit="ns")

    def stop(self) -> None:
        """Stop the slave driver."""
        self._running = False
