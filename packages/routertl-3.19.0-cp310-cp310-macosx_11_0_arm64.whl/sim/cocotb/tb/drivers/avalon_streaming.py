# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

# tb/drivers/avalon_streaming.py
"""
Avalon-Streaming (Avalon-ST) Bus Dataclass
==========================================

Signal container for Avalon-Streaming interfaces. The driver-side BFM
is deferred; today this module only provides the ``AvalonStreamBus``
dataclass so that ``AvalonStreamMonitor`` can attach to packet-oriented
data streams (NAL, video-pipe, RTP datapath, etc.).

Avalon-ST signal set (Intel Avalon Interface Specifications §5):

  Required:
    clk        — sampling clock (monitor side)
    valid      — source asserts when data is valid
    ready      — sink asserts when ready to accept
    data       — payload

  Optional (set to None if absent):
    startofpacket  — first beat of a packet
    endofpacket    — last beat of a packet
    empty          — #symbols invalid on the eop beat (eop=1 required)
    channel        — multi-channel stream selector (stable sop→eop)
    error          — error flag (typically asserted on eop)

Protocol rules enforced by AvalonStreamMonitor (see
``tb/contracts/avalon_streaming.md`` for the full spec):

  AST_DATA_HOLD  — data/sop/eop/empty/error/channel stable while
                   valid=1 and ready=0 (source must not change its mind).
  AST_RST        — valid must be 0 during reset.
  AST_EOP_WO_SOP — endofpacket without a preceding startofpacket.
  AST_SOP_MID_PKT — startofpacket while a packet is already in flight.
  AST_EMPTY_WO_EOP — empty nonzero without eop (empty only meaningful
                     on the last beat).
  AST_CHANNEL_MID_PKT — channel signal changed between sop and eop.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any


def _resolve(dut, prefix: str, name: str):
    """Resolve ``{prefix}_{name}`` on the DUT, trying a few case variants."""
    for full in (f"{prefix}_{name}", f"{prefix}{name}",
                 f"{prefix}_{name.upper()}", f"{prefix}{name.upper()}"):
        try:
            return getattr(dut, full)
        except AttributeError:
            continue
    raise AttributeError(
        f"Cannot find Avalon-ST signal '{name}' with prefix '{prefix}' "
        f"on {getattr(dut, '_name', '<dut>')}"
    )


def _try(dut, prefix: str, name: str):
    try:
        return _resolve(dut, prefix, name)
    except AttributeError:
        return None


@dataclass
class AvalonStreamBus:
    """Container for Avalon-Streaming interface signals.

    Required: valid, ready, data. All others are optional — when absent,
    the corresponding monitor checks are skipped.
    """

    # Required
    valid: Any
    ready: Any
    data: Any

    # Optional — None if not present on the bus
    startofpacket: Any = None
    endofpacket: Any = None
    empty: Any = None
    channel: Any = None
    error: Any = None

    @property
    def has_packets(self) -> bool:
        return self.startofpacket is not None and self.endofpacket is not None

    @property
    def has_empty(self) -> bool:
        return self.empty is not None

    @property
    def has_channel(self) -> bool:
        return self.channel is not None

    @property
    def has_error(self) -> bool:
        return self.error is not None

    @classmethod
    def from_prefix(cls, dut, prefix: str) -> "AvalonStreamBus":
        """Auto-discover Avalon-ST signals from a DUT using a prefix.

        Tries both standard Avalon-ST names (``startofpacket``, ``endofpacket``)
        and the common short forms (``sop``, ``eop``) used by many Intel IPs.
        """
        # Required
        valid = _resolve(dut, prefix, "valid")
        ready = _resolve(dut, prefix, "ready")
        data = _resolve(dut, prefix, "data")

        # Optional — try long form first, fall back to short
        sop = _try(dut, prefix, "startofpacket") or _try(dut, prefix, "sop")
        eop = _try(dut, prefix, "endofpacket") or _try(dut, prefix, "eop")
        empty = _try(dut, prefix, "empty")
        channel = _try(dut, prefix, "channel")
        error = _try(dut, prefix, "error") or _try(dut, prefix, "err")

        return cls(
            valid=valid, ready=ready, data=data,
            startofpacket=sop, endofpacket=eop,
            empty=empty, channel=channel, error=error,
        )
