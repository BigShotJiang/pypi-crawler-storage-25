# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Proxy — real implementation in routertl_core.sim.backends."""

import routertl_core.sim.backends as _mod

globals().update({k: v for k, v in vars(_mod).items() if not k.startswith("__")})
