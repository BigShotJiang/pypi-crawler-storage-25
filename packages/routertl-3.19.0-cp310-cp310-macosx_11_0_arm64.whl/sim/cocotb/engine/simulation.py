# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Backward-compatibility proxy for ``routertl_core.sim.simulation``.

The real implementation was moved to ``routertl_core/sim/`` in P4.7
so it can be Cython-compiled for distribution.  This proxy re-exports
all public symbols so that existing ``from engine.simulation import …``
statements continue to work without changes.
"""


from routertl_core.sim.simulation import (  # noqa: F401
    COCOTB_ROOT,
    COCOTB_VERBOSE,
    LOGS_DIR,
    PROJECT_ROOT,
    SDK_ROOT,
    TESTS_PATH,
    WAVES_DIR,
    LibraryCompiler,
    ensure_dir,
    get_backend,
    get_build_dir_for_simulator,
    run_simulation,
)

__all__ = [
    "COCOTB_ROOT",
    "COCOTB_VERBOSE",
    "LOGS_DIR",
    "PROJECT_ROOT",
    "SDK_ROOT",
    "TESTS_PATH",
    "WAVES_DIR",
    "LibraryCompiler",
    "ensure_dir",
    "get_backend",
    "get_build_dir_for_simulator",
    "run_simulation",
]
