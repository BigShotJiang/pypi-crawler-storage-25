# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Backward-compatibility proxy for ``routertl_core.sim.vendor_libraries``.

The real implementation was moved to ``routertl_core/sim/`` in P4.7
so it can be Cython-compiled for distribution.  This proxy re-exports
all public symbols so that existing imports continue to work.
"""


from routertl_core.sim.vendor_libraries import (  # noqa: F401
    UNISIM_CACHE,
    UNISIM_FILES,
    UNISIM_REPO,
    ensure_ghdl_unisim,
    ensure_nvc_unisim,
    get_ghdl_vendor_flags,
    ghdl_unisim_available,
    ghdl_unisim_path,
    nvc_unisim_available,
)

__all__ = [
    "UNISIM_CACHE",
    "UNISIM_FILES",
    "UNISIM_REPO",
    "ensure_ghdl_unisim",
    "ensure_nvc_unisim",
    "get_ghdl_vendor_flags",
    "ghdl_unisim_available",
    "ghdl_unisim_path",
    "nvc_unisim_available",
]
