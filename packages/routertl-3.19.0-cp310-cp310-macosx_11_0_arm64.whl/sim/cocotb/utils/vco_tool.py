#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

import argparse
from math import ceil, log2


def generate_dds_scaling_report(adc_bits, adc_signed, f_clk, f_center, f_span):
    """Generate a DDS frequency-scaling report for VCO design.

    Parameters
    ----------
    adc_bits : int
        ADC resolution in bits.
    adc_signed : bool
        True if the ADC produces signed values.
    f_clk : float
        System clock frequency in Hz.
    f_center : float
        Center output frequency in Hz.
    f_span : float
        Total desired frequency swing in Hz.
    """
    adc_range = 2**adc_bits
    adc_max = 2 ** (adc_bits - 1) - 1 if adc_signed else 2**adc_bits - 1
    adc_min = -(2 ** (adc_bits - 1)) if adc_signed else 0
    desired_resolution_hz = f_span / adc_range

    required_pa_width = ceil(log2(f_clk / desired_resolution_hz))
    dds_resolution_hz = f_clk / (2**required_pa_width)
    tw_per_adc_lsb = desired_resolution_hz / dds_resolution_hz

    f_adc_max = f_center + adc_max * desired_resolution_hz
    f_adc_min = f_center + adc_min * desired_resolution_hz

    print(f"""📡 DDS Scaling Report Generator

🔢 Input Parameters
- ADC Resolution: {adc_bits} bits ({"signed" if adc_signed else "unsigned"})
- f_clk: {f_clk:.0f} Hz
- Center Frequency: {f_center:.3f} Hz
- Target Frequency Span: {f_span:.3f} Hz
- Target Resolution: {desired_resolution_hz:.9f} Hz

🧮 Calculated Parameters
- Required Phase Accumulator Width: {required_pa_width} bits
- Actual DDS Frequency Resolution: {dds_resolution_hz:.9f} Hz
- Tuning Word increment per ADC LSB: {tw_per_adc_lsb:.4f}
    (each ADC step corresponds to {desired_resolution_hz:.9f} Hz;
     each TW LSB corresponds to {dds_resolution_hz:.9f} Hz)

🎯 Expected Frequency Mapping
- Max ADC Value: {adc_max} → ~{f_adc_max:.3f} Hz
- Min ADC Value: {adc_min} → ~{f_adc_min:.3f} Hz

🔧 Implementation Hint
Since each ADC step equals ~{tw_per_adc_lsb:.4f} TW LSBs:
- Scale ADC value in VHDL using fixed-point multiplication
- Q14 scaling: multiply by {int(round(tw_per_adc_lsb * (2**14)))} and shift right by 14
- Recommended accumulator width: {required_pa_width} bits

💡 Reminder: Even with a wide accumulator, you must scale the ADC!
Directly adding the ADC to TW only works when 1 ADC LSB ≈ 1 TW LSB.
""")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Generate DDS scaling parameters.")
    parser.add_argument("--adc-bits", type=int, required=True, help="ADC resolution in bits")
    parser.add_argument("--adc-signed", action="store_true", help="Use if ADC is signed")
    parser.add_argument("--f-clk", type=float, required=True, help="System clock frequency (Hz)")
    parser.add_argument("--f-center", type=float, required=True, help="Center output frequency (Hz)")
    parser.add_argument("--f-span", type=float, required=True, help="Total frequency swing (Hz)")

    args = parser.parse_args()
    generate_dds_scaling_report(args.adc_bits, args.adc_signed, args.f_clk, args.f_center, args.f_span)
