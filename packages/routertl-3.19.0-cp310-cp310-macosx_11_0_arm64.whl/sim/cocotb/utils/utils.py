# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

import shutil
from pathlib import Path

from cocotb.triggers import Timer


async def wait_with_split(delay, max_split=8192):
    """Wait for a simulation delay, splitting into chunks to avoid overflow.

    Parameters
    ----------
    delay : int or float
        Total delay in nanoseconds.
    max_split : int
        Maximum single Timer duration. Longer delays are split into
        ``max_split``-sized chunks. Default ``8192``.
    """

    if delay > max_split:
        # Calculate how many full splits are needed
        num_splits = delay // max_split  # Integer division for full splits
        remainder = delay % max_split  # Remainder for the last chunk

        # Align max_split and remainder with simulation resolution
        max_split = (max_split / resolution) * resolution
        remainder = (remainder / resolution) * resolution

        max_split = round(max_split)
        remainder = round(remainder)

        # Ensure valid chunks
        if max_split <= 0 or (remainder < 0 and remainder > max_split):
            raise ValueError(f"Invalid delay parameters: max_split={max_split}, remainder={remainder}")

        # Perform the full splits
        for _ in range(int(num_splits)):  # Loop range consuming "NEXT"
            await Timer(max_split, unit="ns")  # Max split

        # Handle the remainder in a final Timer call
        if remainder > 0:
            await Timer(remainder, unit="ns")

    else:
        delay = (delay / resolution) * resolution
        delay = round(delay)
        await Timer(delay, unit="ns")  # Directly wait if delay is small enough


# Function to read deltas from a file and convert them to ns
def read_deltas(file_path, max_lines=400_000, start_line=0, resolution_ns=10, logger=None):
    """
    Read timing deltas from a file and return a list of delays in ns.
    Ensures safe path access and logs progress.

    Parameters:
        file_path: Path or str – relative to the testbench or absolute
        max_lines: Max number of lines to read
        start_line: Starting line number
        resolution_ns: Multiplier to convert line values to time
        logger: Optional cocotb or std logger
    """
    path = Path(file_path).resolve()
    if not path.is_file():
        msg = f"[read_deltas] File not found: {path}"
        if logger:
            logger.error(msg)
        raise FileNotFoundError(msg)

    deltas = []
    try:
        with path.open("r") as f:
            for i, line in enumerate(f):
                if i < start_line:
                    continue
                if max_lines is not None and i >= start_line + max_lines:
                    break
                raw = int(line.strip())
                delta = round(raw * resolution_ns)
                deltas.append(delta)
    except Exception as e:
        msg = f"[read_deltas] Failed to read deltas from {path}: {e}"
        if logger:
            logger.error(msg)
        raise RuntimeError(msg)

    if logger:
        logger.info(f"[read_deltas] Loaded {len(deltas)} deltas from {path}")
    return deltas


def copy_delta_file_to_sim_dir(src, dst_dir=".", logger=None):
    """Copy a delta file into the simulation working directory.

    Parameters
    ----------
    src : str or Path
        Source delta file path.
    dst_dir : str
        Destination directory. Default ``"."`` (current directory).
    logger : logging.Logger, optional
        Logger for progress messages.

    Returns
    -------
    Path
        Destination path of the copied file.
    """
    src = Path(src).resolve()
    dst = Path(dst_dir) / src.name
    if not src.exists():
        msg = f"[copy_delta_file] Source file does not exist: {src}"
        if logger:
            logger.error(msg)
        raise FileNotFoundError(msg)
    shutil.copy(src, dst)
    if logger:
        logger.info(f"[copy_delta_file] Copied {src} → {dst}")
    return dst


def show_dut(dut):
    """Print all signal names, types, and widths found on a DUT handle.

    Parameters
    ----------
    dut : cocotb handle
        The DUT to introspect. Output is logged via ``dut._log``.
    """
    for name in dir(dut):
        try:
            handle = getattr(dut, name)
            if hasattr(handle, "_type"):
                sig_type = handle._type
                bit_width = None

                if hasattr(handle, "_range") and handle._range is not None:
                    left, right = handle._range
                    bit_width = abs(left - right) + 1

                dut._log.info(f"{name}: {sig_type} ({bit_width} bits)" if bit_width else f"{name}: {sig_type}")
        except Exception as e:
            dut._log.warning(f"Could not introspect {name}: {e}")


import random
from typing import Callable, Iterable, Optional


def rand_int(
    lo: int,
    hi: int,
    *,
    step: int = 1,
    exclude: Iterable[int] = (),
    predicate: Optional[Callable[[int], bool]] = None,
    seed: Optional[int] = None,
) -> int:
    """
    Returns a random int in [lo, hi] that:
      - follows a given step (lo, lo+step, …),
      - is not in `exclude`,
      - satisfies `predicate(x)==True` if provided.
    Raises ValueError if no candidate fits.
    """
    if seed is not None:
        random.seed(seed)

    # Build candidates aligned to step
    start = lo + ((0 - (lo % step)) % step)
    candidates = list(range(start, hi + 1, step))

    if exclude:
        bad = set(exclude)
        candidates = [x for x in candidates if x not in bad]

    if predicate:
        candidates = [x for x in candidates if predicate(x)]

    if not candidates:
        raise ValueError("No integer satisfies the constraints.")
    return random.choice(candidates)
