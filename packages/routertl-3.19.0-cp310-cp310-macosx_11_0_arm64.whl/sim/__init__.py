# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""RouteRTL ``sim`` package — lazy-loaded public API.

Defers all imports from ``sim.cocotb`` via ``__getattr__`` so that
``import sim`` does not require cocotb at import time.  This allows
pure-CLI tests (pytest) to traverse the ``sim`` package namespace
without triggering cocotb-dependent modules.
"""

__all__ = [
    "I2cMaster",
    "Item",
    "SignalCollector",
    "SpiMaster",
    "Tb",
    "UartSource",
    "_to_int_resolving_xz",
    "run_simulation",
]


def __getattr__(name):
    if name in __all__:
        from . import cocotb as _cocotb

        return getattr(_cocotb, name)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
