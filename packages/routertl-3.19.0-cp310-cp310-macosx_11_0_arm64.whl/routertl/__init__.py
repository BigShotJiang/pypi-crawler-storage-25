# SPDX-FileCopyrightText: 2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""RouteRTL — user-facing Python API.

This package provides the public API for RouteRTL users.
The implementation lives in routertl_core (compiled).
"""

from routertl_core import __version__  # noqa: F401
