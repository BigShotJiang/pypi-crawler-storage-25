# SPDX-FileCopyrightText: 2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""RouteRTL Simulation API — user-facing re-exports.

Usage::

    from routertl.sim import run_simulation, Tb, UartSource
"""

from routertl_core.sim.simulation import run_simulation  # noqa: F401

# Re-export commonly used simulation classes
try:
    from routertl_core.sim.simulation import Tb  # noqa: F401
except ImportError:
    pass

try:
    from routertl_core.sim.drivers import (  # noqa: F401
        SignalCollector,
        UartSource,
    )
except ImportError:
    pass
