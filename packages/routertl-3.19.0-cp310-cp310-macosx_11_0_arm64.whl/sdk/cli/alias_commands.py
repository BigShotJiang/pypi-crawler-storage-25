# SPDX-FileCopyrightText: 2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Dynamic Click command factory for user-defined aliases.

Converts loaded :class:`AliasEntry` instances into Click commands that
can be registered at the top level of the ``rr`` CLI.  Each alias becomes
a real subcommand invocable as ``rr <alias-name> [args...]``.

Usage from ``main.py``::

    from sdk.cli.alias_commands import load_alias_commands
    for alias_name, alias_cmd in load_alias_commands(cli):
        cli.add_command(alias_cmd, alias_name)
"""

from __future__ import annotations

import logging
import os
import subprocess
import sys

import rich_click as click

from sdk.cli.console import console

_log = logging.getLogger("cli.alias_commands")


def load_alias_commands(
    cli_group: click.Group,
) -> list[tuple[str, click.Command]]:
    """Load aliases and create Click commands, skipping collisions.

    Parameters
    ----------
    cli_group : click.Group
        The main CLI group — used to detect name collisions with built-in
        commands.

    Returns
    -------
    list of (name, click.Command) pairs ready for ``cli.add_command()``.
    """
    from sdk.cli.resilience import cli_resilient_block

    commands: list[tuple[str, click.Command]] = []

    with cli_resilient_block("alias loading"):
        from sdk.engine.alias_loader import load_aliases

        # Determine project root from environment or CWD
        project_root = os.environ.get("RR_PROJECT_ROOT", ".")

        aliases = load_aliases(project_root)
        if not aliases:
            return []

        builtin_names = set(cli_group.commands.keys()) if hasattr(cli_group, "commands") else set()

        for name, entry in aliases.items():
            if name in builtin_names:
                _log.debug(
                    "Alias '%s' shadows built-in command — skipping registration",
                    name,
                )
                continue

            cmd = _make_alias_command(name, entry)
            commands.append((name, cmd))

    return commands


def _make_alias_command(name: str, entry) -> click.Command:
    """Create a Click command that executes an alias."""
    help_text = entry.description or f"User alias: {entry.command}"
    source_label = f"[{entry.source}]"

    @click.command(
        name=name,
        help=f"{help_text}\n\n[dim]{source_label} alias → {entry.command}[/]",
        context_settings={"ignore_unknown_options": True, "allow_extra_args": True},
    )
    @click.argument("args", nargs=-1, type=click.UNPROCESSED)
    @click.pass_context
    def alias_cmd(ctx, args):
        _run_alias(ctx, entry, args)

    # Store metadata for help integration
    alias_cmd.alias_entry = entry  # type: ignore[attr-defined]

    return alias_cmd


def _run_alias(ctx: click.Context, entry, extra_args: tuple[str, ...]) -> None:
    """Expand and execute an alias command."""
    from sdk.engine.alias_loader import expand_command, resolve_working_dir

    # Resolve project root from context
    project_root = None
    if ctx.obj and "project_root" in ctx.obj:
        project_root = str(ctx.obj["project_root"])
    else:
        project_root = "."

    # Expand template variables
    expanded = expand_command(entry, project_root=project_root, extra_args=extra_args)

    # Resolve working directory
    working_dir = resolve_working_dir(entry, project_root=project_root)

    # Show what we're running (verbose mode)
    verbose = ctx.obj.get("VERBOSE", False) if ctx.obj else False
    if verbose:
        console.print(f"  [dim]alias → {expanded}[/]")
        if working_dir:
            console.print(f"  [dim]cwd → {working_dir}[/]")

    # Execute
    try:
        result = subprocess.run(
            expanded,
            shell=True,
            cwd=working_dir,
        )
        if result.returncode != 0:
            sys.exit(result.returncode)
    except KeyboardInterrupt:
        console.print("\n  [yellow]Interrupted.[/]")
        sys.exit(130)
    except FileNotFoundError as exc:
        console.print(f"  [red]Command not found: {exc}[/]")
        sys.exit(127)
