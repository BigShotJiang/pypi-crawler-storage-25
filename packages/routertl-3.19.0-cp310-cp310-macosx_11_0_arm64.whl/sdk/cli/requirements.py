# SPDX-FileCopyrightText: 2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Requirements.yml loader — contract-first IP specification.

Each IP may ship a sibling ``requirements.yml`` next to its ``ip.yml``
declaring the intended port contract and functional requirements.  A
``rr sim contract-check`` gate diffs this declared contract against the
parsed HDL and fails on any mismatch.

Validation is hand-rolled (no jsonschema dependency) so that error messages
can be shaped for human authors and downstream agents, and so that all
problems in a single file are reported at once instead of one per load.

RTL-P2.402 / RTL-P2.398.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import yaml

_log = logging.getLogger("cli.requirements")

REQUIREMENTS_FILENAME = "requirements.yml"

# ── Enumerations ────────────────────────────────────────────────────────────

PROTOCOLS = ("axi-stream", "axi4", "axi-lite", "avalon-mm")
PORT_DIRECTIONS = ("in", "out", "inout")
RESET_POLARITIES = ("active_low", "active_high")
REQ_KINDS = ("behavioral", "negative")

# Stable anchor: dash-joined uppercase tokens ending in a numeric or
# alphanumeric segment.  Accepts the canonical IP-local form ``REQ-<N>``
# plus protocol-scoped forms emitted by shared contract libraries, e.g.
# ``AVL-MM-WAITREQ-001`` (Avalon-MM), ``AXI4-BURST-003``, ``AXIS-TLAST-001``.
# Rules:
#   - starts with a capital letter
#   - at least one dash
#   - each segment is [A-Z0-9]+ (uppercase letters + digits)
_REQ_ID_RE = re.compile(r"^[A-Z][A-Z0-9]*(?:-[A-Z0-9]+)+$")


class RequirementsValidationError(ValueError):
    """Raised when a requirements.yml fails validation.

    ``errors`` is a list of human-readable diagnostic strings, each pointing
    at one problem.  A failed load reports every problem, not just the first.
    """

    def __init__(self, path: Path, errors: list[str]):
        self.path = path
        self.errors = errors
        joined = "\n  - ".join(errors)
        super().__init__(
            f"requirements.yml at {path} failed validation:\n  - {joined}"
        )


# ── Dataclass model ─────────────────────────────────────────────────────────


@dataclass(frozen=True)
class Bundle:
    """A bundled interface — slave or master, identified by prefix."""

    name: str
    protocol: str  # one of PROTOCOLS


@dataclass(frozen=True)
class Scalar:
    """A single scalar port not part of any bundle."""

    name: str
    direction: str  # one of PORT_DIRECTIONS
    width: str      # opaque expression string (e.g. "1", "DATA_WIDTH-1")


@dataclass(frozen=True)
class Clock:
    name: str


@dataclass(frozen=True)
class Reset:
    name: str
    polarity: str  # one of RESET_POLARITIES


@dataclass(frozen=True)
class PortContract:
    slaves: tuple[Bundle, ...] = ()
    masters: tuple[Bundle, ...] = ()
    scalars: tuple[Scalar, ...] = ()
    clocks: tuple[Clock, ...] = ()
    resets: tuple[Reset, ...] = ()


@dataclass(frozen=True)
class Parameter:
    name: str
    default: Optional[object] = None


@dataclass(frozen=True)
class FunctionalRequirement:
    id: str    # REQ-<N> or protocol-scoped (e.g. AVL-MM-WAITREQ-001)
    kind: str  # one of REQ_KINDS
    desc: str
    source: Optional[str] = None  # inherit URI when inherited; None = local


@dataclass(frozen=True)
class Requirements:
    """Materialised contents of a requirements.yml file."""

    ip: str
    version: float
    port_contract: PortContract
    parameters: tuple[Parameter, ...]
    functional_contract: tuple[FunctionalRequirement, ...]
    source_path: Path
    inherit: tuple[str, ...] = ()
    hdl_file: Optional[str] = None


# ── Loader ──────────────────────────────────────────────────────────────────


def load_requirements(
    path: Path | str,
    *,
    _visited: Optional[frozenset] = None,
) -> Requirements:
    """Load and validate a requirements.yml.

    Parameters
    ----------
    path : Path or str
        Path to the ``requirements.yml`` file.

    Returns
    -------
    Requirements
        Typed, validated model of the file contents, with inherited
        REQs merged into ``functional_contract`` (tagged via
        ``FunctionalRequirement.source``).

    Raises
    ------
    FileNotFoundError
        If *path* does not exist.
    RequirementsValidationError
        If the file is syntactically valid YAML but fails contract
        validation (including inherit: cycles and duplicate REQ IDs
        across the inheritance chain).  ``error.errors`` holds every
        problem found.
    yaml.YAMLError
        If the YAML is malformed.

    The ``_visited`` parameter is for internal cycle detection during
    inherit: resolution — callers should not pass it.
    """
    p = Path(path).resolve()
    if not p.is_file():
        raise FileNotFoundError(f"requirements.yml not found: {p}")

    visited = _visited or frozenset()
    if p in visited:
        raise RequirementsValidationError(
            p, [f"inherit: cycle detected — {p} already on chain"]
        )
    visited = visited | {p}

    with open(p) as f:
        raw = yaml.safe_load(f) or {}
    if not isinstance(raw, dict):
        raise RequirementsValidationError(
            p, ["top-level document must be a YAML mapping"]
        )
    errors: list[str] = []
    req = _parse_requirements(raw, p, errors)
    if errors:
        raise RequirementsValidationError(p, errors)
    assert req is not None

    # Resolve inherit: entries — recursively load each, tag their REQs
    # with provenance, and merge into a new Requirements view.
    if req.inherit:
        req = _apply_inheritance(req, visited)

    return req


def discover_requirements(root: Path | str) -> list[Path]:
    """Return all per-IP ``requirements.yml`` files under *root*.

    Resolution order (RTL-P2.431):

      1. **ip.yml-driven** — walk every ``ip.yml`` under *root*, parse its
         (optional) top-level ``requirements:`` field, and yield the
         resolved absolute path when it exists on disk.  This is the
         preferred discovery path now that ip.yml is the mini-project
         manifest.
      2. **Filesystem fallback** — any ``requirements.yml`` under *root*
         that wasn't claimed by an ip.yml pointer is yielded verbatim.
         Preserves the pre-RTL-P2.431 behaviour for IPs that haven't
         been migrated to declare ``requirements:`` in their ip.yml.

    Returns a deduplicated, sorted list of absolute paths.
    """
    r = Path(root).resolve()
    if not r.is_dir():
        return []

    # Late import — sdk.engine depends on this module; importing at
    # module scope would create a circular import during SDK start-up.
    from sdk.engine.ip_yml import normalize_ip_yml, requirements_ref

    claimed: set[Path] = set()
    for ip_yml in r.rglob("ip.yml"):
        try:
            with open(ip_yml) as f:
                raw = yaml.safe_load(f) or {}
        except (yaml.YAMLError, OSError) as exc:
            _log.debug("Skipping malformed ip.yml %s: %s", ip_yml, exc)
            continue
        if not isinstance(raw, dict):
            continue
        try:
            norm = normalize_ip_yml(raw)
        except (TypeError, ValueError) as exc:
            _log.debug("normalize_ip_yml failed for %s: %s", ip_yml, exc)
            continue
        rel = requirements_ref(norm)
        if rel is None:
            continue
        req_path = (ip_yml.parent / rel).resolve()
        if req_path.is_file():
            claimed.add(req_path)
        else:
            _log.warning(
                "ip.yml %s declares requirements: %s but %s does not exist",
                ip_yml, rel, req_path,
            )

    # Filesystem fallback: any requirements.yml not already claimed.
    fs_found: set[Path] = set()
    for p in r.rglob(REQUIREMENTS_FILENAME):
        fs_found.add(p.resolve())

    return sorted(claimed | fs_found)


def discover_project_requirements(
    project_yml_path: Path | str = "project.yml",
    project_root: Path | str = ".",
) -> Optional[Path]:
    """Return the project-level requirements.yml path, or ``None``.

    Reads ``project.yml`` (chasing its ``target:`` pointer if present)
    and resolves the optional ``requirements:`` field against *project_root*.
    See :func:`sdk.cli.project_config.project_requirements_path` for the
    full resolution order.

    RTL-P2.431.
    """
    from sdk.cli.project_config import (
        load_project_config,
        project_requirements_path,
    )

    p = Path(project_yml_path)
    if not p.is_file():
        return None
    try:
        config = load_project_config(str(p))
    except (FileNotFoundError, yaml.YAMLError):
        return None
    req_path = project_requirements_path(config, project_root=project_root)
    if req_path is None or not req_path.is_file():
        return None
    return req_path


# ── Validation internals ────────────────────────────────────────────────────


_ALLOWED_TOP_LEVEL_KEYS = frozenset({
    "ip", "version", "port_contract", "parameters", "functional_contract",
    "inherit", "hdl_file",
})

_ALLOWED_PORT_CONTRACT_KEYS = frozenset({
    "slaves", "masters", "scalars", "clocks", "resets",
})


def _parse_requirements(
    raw: dict, source: Path, errors: list[str]
) -> Optional[Requirements]:
    ip = raw.get("ip")
    if not isinstance(ip, str) or not ip:
        errors.append("missing or empty required field 'ip'")
        ip = ""

    version = raw.get("version", 0.1)
    if not isinstance(version, (int, float)) or isinstance(version, bool):
        errors.append("'version' must be a number")
        version = 0.0

    port_contract = _parse_port_contract(raw.get("port_contract") or {}, errors)
    parameters = _parse_parameters(raw.get("parameters") or [], errors)
    functional = _parse_functional_contract(
        raw.get("functional_contract") or [], errors
    )

    inherit_raw = raw.get("inherit") or []
    inherit: tuple[str, ...] = ()
    if not isinstance(inherit_raw, list):
        errors.append("'inherit' must be a list of strings")
    else:
        cleaned: list[str] = []
        for i, entry in enumerate(inherit_raw):
            if not isinstance(entry, str) or not entry.strip():
                errors.append(
                    f"inherit[{i}] must be a non-empty string (got {entry!r})"
                )
                continue
            cleaned.append(entry.strip())
        inherit = tuple(cleaned)

    hdl_file_raw = raw.get("hdl_file")
    hdl_file: Optional[str] = None
    if hdl_file_raw is not None:
        if not isinstance(hdl_file_raw, str) or not hdl_file_raw.strip():
            errors.append(
                f"'hdl_file' must be a non-empty string (got {hdl_file_raw!r})"
            )
        else:
            hdl_file = hdl_file_raw.strip()

    for k in sorted(set(raw.keys()) - _ALLOWED_TOP_LEVEL_KEYS):
        errors.append(f"unknown top-level key: {k!r}")

    if errors:
        return None

    return Requirements(
        ip=ip,
        version=float(version),
        port_contract=port_contract,
        parameters=parameters,
        functional_contract=functional,
        source_path=source,
        inherit=inherit,
        hdl_file=hdl_file,
    )


def _parse_port_contract(raw: dict, errors: list[str]) -> PortContract:
    if not isinstance(raw, dict):
        errors.append("'port_contract' must be a mapping")
        return PortContract()

    def _bundle_list(key: str) -> tuple[Bundle, ...]:
        items = raw.get(key) or []
        if not isinstance(items, list):
            errors.append(f"'port_contract.{key}' must be a list")
            return ()
        out: list[Bundle] = []
        for i, entry in enumerate(items):
            if not isinstance(entry, dict):
                errors.append(f"port_contract.{key}[{i}] must be a mapping")
                continue
            name = entry.get("name")
            protocol = entry.get("protocol")
            if not isinstance(name, str) or not name:
                errors.append(f"port_contract.{key}[{i}].name is required")
                continue
            if protocol not in PROTOCOLS:
                errors.append(
                    f"port_contract.{key}[{i}].protocol={protocol!r} "
                    f"must be one of {list(PROTOCOLS)}"
                )
                continue
            for extra in sorted(set(entry.keys()) - {"name", "protocol"}):
                errors.append(f"port_contract.{key}[{i}]: unknown field {extra!r}")
            out.append(Bundle(name=name, protocol=protocol))
        return tuple(out)

    slaves = _bundle_list("slaves")
    masters = _bundle_list("masters")

    scalars = _parse_scalars(raw.get("scalars") or [], errors)
    clocks = _parse_clocks(raw.get("clocks") or [], errors)
    resets = _parse_resets(raw.get("resets") or [], errors)

    for k in sorted(set(raw.keys()) - _ALLOWED_PORT_CONTRACT_KEYS):
        errors.append(f"port_contract: unknown field {k!r}")

    return PortContract(
        slaves=slaves,
        masters=masters,
        scalars=scalars,
        clocks=clocks,
        resets=resets,
    )


def _parse_scalars(raw: list, errors: list[str]) -> tuple[Scalar, ...]:
    if not isinstance(raw, list):
        errors.append("'port_contract.scalars' must be a list")
        return ()
    out: list[Scalar] = []
    for i, entry in enumerate(raw):
        if not isinstance(entry, dict):
            errors.append(f"port_contract.scalars[{i}] must be a mapping")
            continue
        name = entry.get("name")
        direction = entry.get("dir")
        width = entry.get("width", 1)
        if not isinstance(name, str) or not name:
            errors.append(f"port_contract.scalars[{i}].name is required")
            continue
        if direction not in PORT_DIRECTIONS:
            errors.append(
                f"port_contract.scalars[{i}].dir={direction!r} "
                f"must be one of {list(PORT_DIRECTIONS)}"
            )
            continue
        out.append(Scalar(name=name, direction=direction, width=str(width)))
    return tuple(out)


def _parse_clocks(raw: list, errors: list[str]) -> tuple[Clock, ...]:
    if not isinstance(raw, list):
        errors.append("'port_contract.clocks' must be a list")
        return ()
    out: list[Clock] = []
    for i, entry in enumerate(raw):
        if not isinstance(entry, dict):
            errors.append(f"port_contract.clocks[{i}] must be a mapping")
            continue
        name = entry.get("name")
        if not isinstance(name, str) or not name:
            errors.append(f"port_contract.clocks[{i}].name is required")
            continue
        out.append(Clock(name=name))
    return tuple(out)


def _parse_resets(raw: list, errors: list[str]) -> tuple[Reset, ...]:
    if not isinstance(raw, list):
        errors.append("'port_contract.resets' must be a list")
        return ()
    out: list[Reset] = []
    for i, entry in enumerate(raw):
        if not isinstance(entry, dict):
            errors.append(f"port_contract.resets[{i}] must be a mapping")
            continue
        name = entry.get("name")
        polarity = entry.get("polarity", "active_low")
        if not isinstance(name, str) or not name:
            errors.append(f"port_contract.resets[{i}].name is required")
            continue
        if polarity not in RESET_POLARITIES:
            errors.append(
                f"port_contract.resets[{i}].polarity={polarity!r} "
                f"must be one of {list(RESET_POLARITIES)}"
            )
            continue
        out.append(Reset(name=name, polarity=polarity))
    return tuple(out)


def _parse_parameters(raw: list, errors: list[str]) -> tuple[Parameter, ...]:
    if not isinstance(raw, list):
        errors.append("'parameters' must be a list")
        return ()
    out: list[Parameter] = []
    for i, entry in enumerate(raw):
        if not isinstance(entry, dict):
            errors.append(f"parameters[{i}] must be a mapping")
            continue
        name = entry.get("name")
        if not isinstance(name, str) or not name:
            errors.append(f"parameters[{i}].name is required")
            continue
        out.append(Parameter(name=name, default=entry.get("default")))
    return tuple(out)


def _parse_functional_contract(
    raw: list, errors: list[str]
) -> tuple[FunctionalRequirement, ...]:
    if not isinstance(raw, list):
        errors.append("'functional_contract' must be a list")
        return ()
    seen_ids: set[str] = set()
    out: list[FunctionalRequirement] = []
    for i, entry in enumerate(raw):
        if not isinstance(entry, dict):
            errors.append(f"functional_contract[{i}] must be a mapping")
            continue
        rid = entry.get("id")
        kind = entry.get("kind")
        desc = entry.get("desc")
        if not isinstance(rid, str) or not _REQ_ID_RE.match(rid):
            errors.append(
                f"functional_contract[{i}].id={rid!r} must be an uppercase "
                "dash-joined identifier — e.g. REQ-1, REQ-42, "
                "AVL-MM-WAITREQ-001, AXIS-TLAST-002"
            )
            continue
        if rid in seen_ids:
            errors.append(f"functional_contract[{i}]: duplicate id {rid!r}")
            continue
        if kind not in REQ_KINDS:
            errors.append(
                f"functional_contract[{i}].kind={kind!r} "
                f"must be one of {list(REQ_KINDS)}"
            )
            continue
        if not isinstance(desc, str) or not desc.strip():
            errors.append(
                f"functional_contract[{i}].desc is required and must be a "
                "non-empty string"
            )
            continue
        seen_ids.add(rid)
        out.append(FunctionalRequirement(id=rid, kind=kind, desc=desc))
    return tuple(out)


# ── inherit: resolver ───────────────────────────────────────────────────────


def _sdk_root() -> Path:
    """Return the ``sdk/`` directory so we can resolve ``routertl:`` URIs."""
    # This file lives at sdk/cli/requirements.py → parent.parent = sdk/
    return Path(__file__).resolve().parent.parent


def _resolve_inherit_uri(uri: str, caller: Path) -> Path:
    """Resolve an ``inherit:`` entry to a filesystem path.

    Supported forms:
      - ``routertl:protocol_contracts/<name>`` → SDK protocol library.
      - ``./relative/path.yml`` / ``../path.yml`` → relative to *caller*.
      - ``<name>`` (bare)       → sugar for ``routertl:protocol_contracts/<name>``.
    """
    if uri.startswith("routertl:"):
        suffix = uri[len("routertl:"):]
        return (_sdk_root() / f"{suffix}.requirements.yml").resolve()
    if uri.startswith(("./", "../", "/")):
        return (caller.parent / uri).resolve()
    # Bare name → sugar for protocol_contracts/<name>
    return (_sdk_root() / "protocol_contracts" / f"{uri}.requirements.yml").resolve()


def _apply_inheritance(
    req: Requirements,
    visited: frozenset,
) -> Requirements:
    """Load every ``inherit:`` target, tag their REQs, merge into *req*.

    Duplicate REQ IDs (across chain or between inherited + local) raise a
    :class:`RequirementsValidationError` on the current source path.
    """
    errors: list[str] = []
    inherited_reqs: list[FunctionalRequirement] = []

    for uri in req.inherit:
        target = _resolve_inherit_uri(uri, req.source_path)
        if not target.is_file():
            errors.append(
                f"inherit: '{uri}' → {target} (file not found)"
            )
            continue
        try:
            sub = load_requirements(target, _visited=visited)
        except RequirementsValidationError as exc:
            nested = "; ".join(exc.errors)
            errors.append(f"inherit: '{uri}' failed to load: {nested}")
            continue
        for r in sub.functional_contract:
            # If the inherited REQ was itself inherited from a deeper
            # source, preserve the deepest provenance.  Otherwise tag
            # with the URI that pulled it in here.
            tagged_source = r.source or uri
            inherited_reqs.append(FunctionalRequirement(
                id=r.id, kind=r.kind, desc=r.desc, source=tagged_source,
            ))

    if errors:
        raise RequirementsValidationError(req.source_path, errors)

    # Duplicate-ID check across inherited + local.
    seen: dict[str, str] = {}
    merged: list[FunctionalRequirement] = []
    for r in inherited_reqs + list(req.functional_contract):
        prior = seen.get(r.id)
        if prior is not None:
            errors.append(
                f"duplicate REQ id {r.id!r}: already provided by {prior!r}"
            )
            continue
        seen[r.id] = r.source or "local"
        merged.append(r)

    if errors:
        raise RequirementsValidationError(req.source_path, errors)

    return Requirements(
        ip=req.ip,
        version=req.version,
        port_contract=req.port_contract,
        parameters=req.parameters,
        functional_contract=tuple(merged),
        source_path=req.source_path,
        inherit=req.inherit,
        hdl_file=req.hdl_file,
    )
