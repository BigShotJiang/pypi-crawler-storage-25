# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Engine Dispatch — direct invocation of SDK engine scripts.

Provides helpers for calling SDK Python scripts directly, bypassing Make.
This is the shared substrate for all Make-elimination refactors.
"""

import os
import subprocess
import sys
from pathlib import Path

from sdk.cli.console import console
from sdk.cli.env_setup import resolve_sdk_script
from sdk.cli.resilience import cli_resilient_block


class ScriptNotFound(RuntimeError):
    """Raised when an SDK engine script cannot be located."""


def run_engine_script(
    script_name: str,
    args: list[str],
    *,
    env: dict | None = None,
    check: bool = False,
    capture: bool = False,
) -> subprocess.CompletedProcess:
    """Locate and run an SDK engine script.

    Parameters
    ----------
    script_name : str
        Basename of the script, e.g. ``"dependency_resolver.py"``.
    args : list[str]
        CLI arguments to pass after the script path.
    env : dict, optional
        Custom environment dict.  Defaults to ``os.environ``.
    check : bool
        If True, raise on non-zero exit.
    capture : bool
        If True, capture stdout/stderr.

    Returns
    -------
    subprocess.CompletedProcess

    Raises
    ------
    ScriptNotFound
        If the script cannot be located via ``resolve_sdk_script``.
    """
    script = resolve_sdk_script(f"project-manager/{script_name}")
    if script is None:
        raise ScriptNotFound(
            f"SDK engine script '{script_name}' not found. "
            "Is the SDK installed correctly?"
        )
    cmd = [sys.executable, str(script)] + args
    return subprocess.run(
        cmd,
        check=check,
        env=env or os.environ.copy(),
        capture_output=capture,
        text=capture,
    )


# ── Build environment helpers ────────────────────────────────────────


def read_build_env(path: str = "build_env.mk") -> dict[str, str]:
    """Parse a Makefile-style ``build_env.mk`` into a Python dict.

    Handles:
    - ``VAR = value``
    - ``VAR ?= value``  (conditional assignment — treated as assignment)
    - ``VAR := value``  (simple assignment)
    - Lines starting with ``#`` are ignored.
    - Inline comments after ``#`` are stripped.

    Returns an empty dict if the file does not exist.
    """
    result: dict[str, str] = {}
    p = Path(path)
    if not p.exists():
        return result

    with open(p) as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            # Try each assignment operator
            for op in ("?=", ":=", "="):
                if op in line:
                    key, _, val = line.partition(op)
                    key = key.strip()
                    val = val.strip()
                    # Strip inline comments
                    if " #" in val:
                        val = val[: val.index(" #")].strip()
                    result[key] = val
                    break
    return result


def _build_env_yml_sources(project_yml: Path) -> list[Path]:
    """Return every YAML file whose mtime should invalidate build_env caches.

    RTL-P2.367: project.yml delegates to a target yml (``target:`` key
    or ``RR_TARGET`` env var).  Edits to the target yml — adding or
    reordering ``tcl_hooks`` is the repro case — don't touch
    project.yml's mtime, so the old mtime-only check would silently use
    a stale ``build_env.tcl`` and Vivado would source the wrong hook
    list.  Include the active target yml in the watch set.
    """
    sources = [project_yml]
    from sdk.cli.project_config import get_active_target

    target = get_active_target(str(project_yml))
    if not target:
        return sources

    target_path = Path(target)
    if not target_path.is_absolute():
        # Target paths are relative to the project root (project.yml's dir).
        target_path = (project_yml.parent / target_path).resolve()
    if target_path.exists() and target_path.is_file():
        sources.append(target_path)
    return sources


def ensure_build_env(project_yml: str = "project.yml") -> dict[str, str]:
    """Ensure ``build_env.mk`` and ``build_env.tcl`` are up to date.

    Regenerates both when any watched YAML source is newer than either
    derived file.  The watched set covers project.yml *and* the active
    target yml (RTL-P2.367).

    Returns the parsed build environment dict.
    """
    yml_path = Path(project_yml)
    mk_path = Path("build_env.mk")
    tcl_path = Path("build_env.tcl")

    needs_regen = False
    if not mk_path.exists() or not tcl_path.exists():
        needs_regen = True
    elif yml_path.exists():
        derived_mtime = min(
            mk_path.stat().st_mtime, tcl_path.stat().st_mtime,
        )
        for src in _build_env_yml_sources(yml_path):
            if src.exists() and src.stat().st_mtime > derived_mtime:
                needs_regen = True
                break

    if needs_regen and yml_path.exists():
        console.print(
            "⚡ [dim]project.yml or target yml changed — "
            "regenerating build environment...[/]"
        )
        with cli_resilient_block("build_env regeneration"):
            try:
                run_engine_script("project_manager.py", [str(yml_path)])
            except ScriptNotFound:
                pass  # Fall through — read whatever exists

    return read_build_env()


def check_lfs_guards(root_dir: str | Path = ".") -> bool:
    """Python port of the ``check-lfs`` Makefile target.

    Scans for Git LFS pointer stubs in netlist files.
    Returns True if all files are pulled, False if stubs are detected.
    """
    root = Path(root_dir)
    netlist_extensions = (".qxp", ".qdb", ".dcp", ".edf", ".ngo")

    for ext in netlist_extensions:
        for f in root.rglob(f"*{ext}"):
            # Skip git internals and build artifacts
            rel = str(f.relative_to(root))
            if ".git/" in rel or "sim_build/" in rel:
                continue
            try:
                with open(f, "r", errors="ignore") as fh:
                    first_line = fh.readline()
                if first_line.startswith("version https://git-lfs"):
                    console.print(
                        f"❌ [red]LFS file not pulled:[/] {rel}\n"
                        "   Run: [cyan]git lfs pull[/]"
                    )
                    return False
            except (OSError, UnicodeDecodeError):
                continue
    return True
