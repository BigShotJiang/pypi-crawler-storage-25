# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Platform-aware install hints for missing external tools.

Call sites across sdk/ used to emit Linux-only ``sudo apt install …``
messages, which misled macOS and WSL users. This module centralises the
per-platform install command for every external tool rr touches, so
error paths (and ``rr doctor`` fix commands) can stay consistent.

Two entry points:

* :func:`install_cmd` — a single command string (suitable for the
  ``fix_cmd`` field of a doctor CheckResult).
* :func:`install_hints` — printable multi-line instructions, including
  escape hatches (``rr docker shell`` on Linux, ``xcode-select --install``
  on macOS for build-essential, etc.).

See RTL-P3.196 (rr schematic, original helper) and RTL-P3.197
(this sweep).
"""

from __future__ import annotations

import sys

__all__ = ["install_cmd", "install_hints"]


def _norm_platform(p: str | None) -> str:
    """Collapse ``sys.platform`` values into {darwin, linux, win32}."""
    plat = p if p is not None else sys.platform
    if plat == "darwin":
        return "darwin"
    if plat.startswith("win"):
        return "win32"
    return "linux"


_LABEL = {"darwin": "macOS", "linux": "Linux", "win32": "Windows (WSL2)"}

# Per-tool, per-platform one-shot install command. ``None`` means no
# package-manager path on that platform — e.g. yosys has no native
# Windows install, user needs WSL2.
_CMD: dict[str, dict[str, str | None]] = {
    "yosys":           {"darwin": "brew install yosys",
                        "linux":  "sudo apt install yosys",
                        "win32":  None},
    "netlistsvg":      {"darwin": "npm install -g netlistsvg",
                        "linux":  "npm install -g netlistsvg",
                        "win32":  "npm install -g netlistsvg"},
    "ghdl":            {"darwin": "brew install ghdl",
                        "linux":  "sudo apt install ghdl",
                        "win32":  None},
    "gtkwave":         {"darwin": "brew install --cask gtkwave",
                        "linux":  "sudo apt install gtkwave",
                        "win32":  None},
    "git-lfs":         {"darwin": "brew install git-lfs",
                        "linux":  "sudo apt install git-lfs",
                        "win32":  None},
    "shellcheck":      {"darwin": "brew install shellcheck",
                        "linux":  "sudo apt install shellcheck",
                        "win32":  None},
    # macOS ships with Xcode CLT → `xcode-select --install` provides a
    # working compiler + make, equivalent to build-essential on Debian.
    "build-essential": {"darwin": "xcode-select --install",
                        "linux":  "sudo apt install build-essential",
                        "win32":  None},
    "make":            {"darwin": "brew install make",
                        "linux":  "sudo apt install make",
                        "win32":  None},
    # Device Tree Compiler — needed for `rr linux sync` and friends.
    # Debian/Ubuntu package name is `device-tree-compiler`, binary is `dtc`.
    "dtc":             {"darwin": "brew install dtc",
                        "linux":  "sudo apt install device-tree-compiler",
                        "win32":  None},
}


def install_cmd(tool: str, *, platform: str | None = None) -> str | None:
    """Return the single install command for *tool* on the current platform.

    Returns ``None`` if the tool has no package-manager path on that
    platform (caller should fall back to a docs link or escape hatch).
    """
    return _CMD.get(tool, {}).get(_norm_platform(platform))


def install_hints(
    tool: str,
    *,
    need_ghdl: bool = False,
    platform: str | None = None,
) -> list[str]:
    """Return printable install instructions for *tool*.

    Leads with the detected platform, then appends any escape hatches:

    * Linux yosys → mentions ``rr docker shell`` as an alternative.
    * Windows yosys → points at WSL2.
    * ``need_ghdl=True`` (yosys w/ VHDL sources) → appends the ghdl +
      ghdl-yosys-plugin follow-up.
    * git-lfs → appends the ``git lfs install`` post-step.
    """
    plat = _norm_platform(platform)
    lines: list[str] = []

    cmd = install_cmd(tool, platform=plat)
    if cmd:
        lines.append(f"   💡 {_LABEL[plat]}: {cmd}")
    elif tool == "yosys" and plat == "win32":
        lines.append("   💡 Windows: yosys has no native build — use WSL2")

    # yosys: mention the docker escape hatch on Linux (it's the clean
    # path when the user doesn't want to install toolchains locally).
    if tool == "yosys" and plat == "linux":
        lines.append("      or: rr docker shell (Dockerised Yosys)")

    # VHDL extension for yosys: ghdl + ghdl-yosys-plugin.
    if tool == "yosys" and need_ghdl:
        ghdl_cmd = install_cmd("ghdl", platform=plat)
        if ghdl_cmd:
            lines.append(f"      VHDL also needs: {ghdl_cmd} + ghdl-yosys-plugin")
        else:
            lines.append("      VHDL also needs: ghdl + ghdl-yosys-plugin")

    # git-lfs post-install step.
    if tool == "git-lfs" and cmd:
        lines.append("      then: git lfs install")

    return lines
