# SPDX-FileCopyrightText: 2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""RTL-P2.427 — completion cache.

Shell-completion callbacks that hit the network (registry lookups) need
a tiny caching layer so TAB-driven completion stays instant.  This
module owns the on-disk cache file — XDG-compliant, atomic writes,
stale-read fallback when the network is slow, graceful degradation on
every IO error.

Shape of the cache file (``~/.cache/routertl/completion.json``)::

    {
      "version": 1,
      "pkg_index": {
        "ts": 1714000000.0,
        "entries": ["ns/name1", "ns/name2", ...]
      }
    }

Single-writer convention is enforced via tempfile + atomic rename so
two parallel shells completing simultaneously don't corrupt the file.
"""

from __future__ import annotations

import json
import logging
import os
import tempfile
import time
from pathlib import Path

_log = logging.getLogger("cli.completion_cache")

# Schema version — bump when the on-disk shape changes so stale files
# get invalidated rather than blowing up the caller.
_CACHE_VERSION = 1

# 1 hour — completion needs to feel fresh but not pay latency per TAB.
_DEFAULT_TTL = 3600.0


def _cache_path() -> Path:
    """Return the XDG-compliant cache file path.

    Honours ``$XDG_CACHE_HOME``; falls back to ``~/.cache``.  The
    directory is created on demand (with ``parents=True``) so first-run
    writes don't trip on missing-parent errors.
    """
    xdg = os.environ.get("XDG_CACHE_HOME")
    base = Path(xdg) if xdg else Path.home() / ".cache"
    return base / "routertl" / "completion.json"


def _load() -> dict:
    """Best-effort load of the cache file.  Empty dict on any failure."""
    path = _cache_path()
    if not path.exists():
        return {}
    try:
        data = json.loads(path.read_text())
    except (OSError, json.JSONDecodeError) as e:
        _log.debug("completion cache unreadable, ignoring: %s", e)
        return {}
    if not isinstance(data, dict):
        return {}
    # Schema migration — today we just invalidate wholesale when the
    # version doesn't match.  When we grow, this is the hook.
    if data.get("version") != _CACHE_VERSION:
        return {}
    return data


def _save(data: dict) -> None:
    """Atomic-replace write of *data* to the cache file.

    Never raises — if the write fails (disk full, permission denied,
    exotic fs), we silently drop the update.  Completion callers read
    via :func:`get` which tolerates missing/empty caches, so a skipped
    write just means the next TAB press reads stale or repopulates.
    """
    path = _cache_path()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        data = {**data, "version": _CACHE_VERSION}
        # Tempfile in the same dir so the rename is atomic (same fs).
        fd, tmp = tempfile.mkstemp(
            prefix=".completion.", suffix=".json", dir=str(path.parent),
        )
        try:
            with os.fdopen(fd, "w") as f:
                json.dump(data, f, separators=(",", ":"))
            os.replace(tmp, path)
        except (OSError, TypeError, ValueError):
            # Clean up the tempfile if the rename failed.
            try:
                os.unlink(tmp)
            except OSError:
                pass
            raise
    except (OSError, TypeError, ValueError) as e:
        _log.debug("completion cache save failed, ignoring: %s", e)


def get(key: str, *, ttl: float = _DEFAULT_TTL) -> list[str] | None:
    """Return cached entries for *key* if fresh, else None.

    ``None`` means "nothing cached, or too old, or file corrupt" — the
    caller should treat that as a cache miss and populate via
    :func:`set_entries` after fetching the source of truth.
    """
    data = _load()
    slot = data.get(key)
    if not isinstance(slot, dict):
        return None
    ts = slot.get("ts")
    entries = slot.get("entries")
    if not isinstance(ts, (int, float)) or not isinstance(entries, list):
        return None
    if time.time() - float(ts) > ttl:
        return None
    # Defensive: coerce to strings so callers don't surface a non-str
    # completion suggestion.
    return [str(e) for e in entries if isinstance(e, str)]


def get_stale(key: str) -> list[str] | None:
    """Return cached entries for *key* ignoring the TTL.

    Used as a fallback when the fresh fetch fails or times out — stale
    suggestions beat no suggestions, and the worst case is a user seeing
    a package that was removed upstream an hour ago.
    """
    data = _load()
    slot = data.get(key)
    if not isinstance(slot, dict):
        return None
    entries = slot.get("entries")
    if not isinstance(entries, list):
        return None
    return [str(e) for e in entries if isinstance(e, str)]


def set_entries(key: str, entries: list[str]) -> None:
    """Write *entries* for *key* with a fresh timestamp."""
    data = _load()
    data[key] = {"ts": time.time(), "entries": list(entries)}
    _save(data)


def invalidate(key: str | None = None) -> None:
    """Drop the cache entry for *key* (or the whole cache when None).

    Exposed for ``rr pkg install/remove`` hooks — after the local lock
    changes, the next TAB should reflect reality without waiting out
    the TTL.
    """
    if key is None:
        try:
            _cache_path().unlink(missing_ok=True)
        except OSError:
            pass
        return
    data = _load()
    if key in data:
        data.pop(key, None)
        _save(data)
