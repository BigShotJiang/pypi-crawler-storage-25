#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Sync VERSION file from pyproject.toml — single source of truth.

Reads the version from pyproject.toml and writes a shell-sourceable
VERSION file with system_major and system_minor. This ensures the
VERSION file (consumed by create_rom.sh and other bash scripts) is
always in sync with pyproject.toml.

Exit 0 on success, exit 1 on parse failure.
"""

import re
import sys
from pathlib import Path


def _find_repo_root() -> Path:
    """Locate the SDK root (parent of sdk/)."""
    return Path(__file__).resolve().parent.parent.parent


def _parse_pyproject_version(path: Path) -> tuple[int, int, int]:
    """Extract (major, minor, patch) from pyproject.toml version field."""
    text = path.read_text()
    match = re.search(r'^version\s*=\s*"(\d+)\.(\d+)\.(\d+)"', text, re.MULTILINE)
    if not match:
        print(f"❌ Could not parse version from {path}", file=sys.stderr)
        sys.exit(1)
    return int(match.group(1)), int(match.group(2)), int(match.group(3))


def _write_version_file(path: Path, major: int, minor: int) -> None:
    """Write the VERSION file in shell-sourceable format."""
    path.write_text(
        f"system_major={major}\n"
        f"system_minor={minor}\n"
        f"# Patch version is calculated dynamically from git history\n"
    )


def main(root: Path | None = None) -> int:
    """Sync VERSION from pyproject.toml — return 0 on success, 1 on failure."""
    if root is None:
        root = _find_repo_root()

    pyproject_file = root / "pyproject.toml"

    if not pyproject_file.exists():
        print(f"❌ Missing file: {pyproject_file}", file=sys.stderr)
        return 1

    major, minor, _patch = _parse_pyproject_version(pyproject_file)
    version_file = root / "VERSION"
    _write_version_file(version_file, major, minor)

    print(f"✅ VERSION synced from pyproject.toml: {major}.{minor}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
