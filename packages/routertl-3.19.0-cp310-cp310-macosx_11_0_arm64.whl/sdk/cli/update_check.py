# SPDX-FileCopyrightText: 2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Lightweight PyPI update check for the routertl CLI (RTL-P1.37).

Queries https://pypi.org/pypi/routertl/json once per 24 hours, caches
the result in ``~/.routertl/update_cache.json``, and prints a one-line
hint on CLI exit when a newer version is available.

Design constraints
──────────────────
* **Must never break the CLI.**  Any failure (network, parse, permission,
  cache corruption) is swallowed silently.
* **Must be cheap.**  At most one HTTP call per 24h, bounded by a short
  timeout.  Cache lookups are a single file read.
* **Must be respectful.**  Skipped automatically in CI, tests, and when
  ``ROUTERTL_NO_UPDATE_CHECK=1`` is set.
"""

from __future__ import annotations

import json
import os
import time
from pathlib import Path

# Re-check PyPI at most once per day.  Cache freshness is compared against
# file mtime so a manual cache edit (or ``touch``) also refreshes.
_CACHE_TTL_SECONDS = 24 * 60 * 60
_PYPI_URL = "https://pypi.org/pypi/routertl/json"
_FETCH_TIMEOUT = 2  # seconds — never block the CLI longer than this

# Env vars that disable the check.  ``CI`` is set by every common CI runner
# (GitHub Actions, GitLab, Bitbucket, CircleCI).  ``PYTEST_CURRENT_TEST`` is
# set by pytest during test runs — without it, update checks would hit
# the network from inside unrelated tests and slow them down.
_DISABLE_ENV_VARS = (
    "ROUTERTL_NO_UPDATE_CHECK",
    "CI",
    "PYTEST_CURRENT_TEST",
)


def _cache_path() -> Path:
    return Path.home() / ".routertl" / "update_cache.json"


def _is_disabled() -> bool:
    return any(os.environ.get(v) for v in _DISABLE_ENV_VARS)


def _parse_version(v: str) -> tuple[int, ...]:
    """Parse 'X.Y.Z' (stripping leading 'v' and any pre-release suffix)
    into a comparable tuple.  Unparseable components become 0 so dev
    builds never spuriously trigger an 'update available' hint.
    """
    v = v.lstrip("v").split("-", 1)[0].split("+", 1)[0]
    parts = v.split(".")
    out: list[int] = []
    for p in parts[:3]:
        try:
            out.append(int(p))
        except ValueError:
            out.append(0)
    while len(out) < 3:
        out.append(0)
    return tuple(out)


def _cache_read() -> dict | None:
    path = _cache_path()
    if not path.exists():
        return None
    if time.time() - path.stat().st_mtime > _CACHE_TTL_SECONDS:
        return None
    try:
        return json.loads(path.read_text())
    except (OSError, ValueError):
        return None


def _cache_write(latest: str) -> None:
    path = _cache_path()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps({"latest": latest, "checked_at": time.time()}))
    except OSError:
        # Unwritable $HOME (read-only FS, permission denied) — just skip
        # caching; we'll re-hit PyPI next invocation but that's harmless.
        pass


def _fetch_latest_version() -> str | None:
    from urllib.error import URLError
    from urllib.request import urlopen

    try:
        with urlopen(_PYPI_URL, timeout=_FETCH_TIMEOUT) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        return data.get("info", {}).get("version")
    except (URLError, OSError, ValueError, KeyError):
        return None


def get_latest_version(*, force_refresh: bool = False) -> str | None:
    """Return the latest routertl version string from PyPI, or None on error.

    Uses the 24h cache unless ``force_refresh`` is True.  This is the
    seam used by tests.
    """
    if not force_refresh:
        cached = _cache_read()
        if cached and cached.get("latest"):
            return cached["latest"]

    latest = _fetch_latest_version()
    if latest:
        _cache_write(latest)
    return latest


def maybe_show_update_hint(current_version: str, *, printer=None) -> bool:
    """Print a single-line hint if PyPI has a newer routertl than ``current_version``.

    Returns True if a hint was printed, False otherwise.  Never raises —
    any failure is swallowed.  ``printer`` is injected for tests; in
    production it defaults to the routertl CLI console.
    """
    if _is_disabled():
        return False
    # get_latest_version swallows URLError / OSError / ValueError / KeyError
    # internally and returns None — the call site in sdk/cli/main.py wraps
    # this entire function in cli_resilient_block for belt-and-suspenders,
    # so we don't need another broad except here.
    latest = get_latest_version()
    if not latest:
        return False

    if _parse_version(latest) <= _parse_version(current_version):
        return False

    if printer is None:
        from sdk.cli.console import console
        printer = console.print

    printer(
        f"\n[yellow]✨ routertl {latest} available[/] "
        f"[dim](you have {current_version}).[/] "
        f"Upgrade: [cyan]pip install --upgrade routertl[/]"
    )
    return True
