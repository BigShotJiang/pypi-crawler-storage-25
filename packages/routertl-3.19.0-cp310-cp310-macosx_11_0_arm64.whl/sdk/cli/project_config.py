# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Unified project configuration loader.

Every part of the SDK that needs to read ``project.yml`` should call
:func:`load_project_config` from this module.  This ensures that the
``target:`` pointer mechanism is respected consistently across the
entire CLI surface.

Dual-mode operation:

- **Self-contained** — ``project.yml`` contains the full project config.
  Returned as-is.
- **Pointer** — ``project.yml`` contains a ``target:`` key pointing to
  another YAML file (e.g. ``targets/arria10_devkit.yml``).  The loader
  chases the pointer and returns the target file's content.

All paths inside target files resolve from the **repo root** (CWD), not
from the target file's directory.  Target folders are purely
organizational.
"""

from __future__ import annotations

import logging
import os
from pathlib import Path

import yaml

_log = logging.getLogger("cli.project_config")

# Environment variable override — takes precedence over project.yml pointer
_RR_TARGET_ENV = "RR_TARGET"


class TargetNotFoundError(FileNotFoundError):
    """Raised when a ``target:`` pointer references a missing file."""


def load_project_config(yml_path: str = "project.yml") -> dict:
    """Load project configuration, chasing ``target:`` pointer if present.

    Parameters
    ----------
    yml_path : str
        Path to the project YAML file.  Defaults to ``project.yml``
        in the current working directory.

    Returns
    -------
    dict
        Parsed project configuration.

    Raises
    ------
    FileNotFoundError
        If *yml_path* does not exist.
    TargetNotFoundError
        If a ``target:`` pointer references a file that doesn't exist.
    yaml.YAMLError
        If the YAML is malformed.
    """
    p = Path(yml_path)
    if not p.exists():
        raise FileNotFoundError(f"Project config not found: {p}")

    with open(p) as f:
        config = yaml.safe_load(f) or {}

    if not isinstance(config, dict):
        _log.warning("%s is not a valid YAML dict — returning empty config", p)
        return {}

    # ── Environment variable override ──
    env_target = os.environ.get(_RR_TARGET_ENV)
    if env_target:
        _log.debug("RR_TARGET override: %s", env_target)
        return _load_target_file(env_target, source="$RR_TARGET")

    # ── Chase target pointer ──
    if "target" in config:
        target_path = config["target"]
        return _load_target_file(target_path, source=str(p))

    return config


def _load_target_file(target_path: str, *, source: str) -> dict:
    """Load a target file, raising a clear error if missing.

    Parameters
    ----------
    target_path : str
        Path to the target YAML file (relative to CWD or absolute).
    source : str
        Where the pointer came from (for error messages).
    """
    tp = Path(target_path)
    if not tp.exists():
        raise TargetNotFoundError(
            f"Target file not found: {tp}\n"
            f"  Referenced by: {source}\n"
            f"  Run 'rr target list' to see available targets."
        )

    with open(tp) as f:
        config = yaml.safe_load(f) or {}

    if not isinstance(config, dict):
        _log.warning("Target %s is not a valid YAML dict", tp)
        return {}

    _log.debug("Loaded target: %s (from %s)", tp, source)
    return config


def get_active_target(yml_path: str = "project.yml") -> str | None:
    """Return the active target path, or ``None`` if self-contained.

    Checks ``RR_TARGET`` env var first, then the ``target:`` key in
    the project YAML.

    Parameters
    ----------
    yml_path : str
        Path to the root project YAML file.

    Returns
    -------
    str or None
        The target file path, or None if project.yml is self-contained.
    """
    # Env var override
    env_target = os.environ.get(_RR_TARGET_ENV)
    if env_target:
        return env_target

    p = Path(yml_path)
    if not p.exists():
        return None

    try:
        with open(p) as f:
            config = yaml.safe_load(f) or {}
    except yaml.YAMLError:
        return None

    if isinstance(config, dict) and "target" in config:
        return config["target"]

    return None


def resolve_target_path(
    name: str, search_dir: str = "targets"
) -> Path | None:
    """Resolve a target name to a file path.

    Resolution priority:
    1. ``<search_dir>/<name>.yml`` (flat file)
    2. ``<search_dir>/<name>/project.yml`` (directory layout)

    Parameters
    ----------
    name : str
        Target name (e.g. ``arria10_devkit``).
    search_dir : str
        Directory to search (default: ``targets``).

    Returns
    -------
    Path or None
        Resolved path, or None if not found.
    """
    base = Path(search_dir)

    # Priority 1: flat file
    flat = base / f"{name}.yml"
    if flat.exists():
        return flat

    # Priority 2: directory layout
    nested = base / name / "project.yml"
    if nested.exists():
        return nested

    return None


def discover_targets(search_dir: str = "targets") -> list[dict]:
    """Discover all available target configurations.

    Scans *search_dir* for YAML files (flat) and subdirectories
    containing ``project.yml`` (nested layout).

    Parameters
    ----------
    search_dir : str
        Directory to scan (default: ``targets``).

    Returns
    -------
    list[dict]
        Each entry has keys: ``name``, ``path``, ``config`` (parsed YAML).
    """
    base = Path(search_dir)
    if not base.is_dir():
        return []

    results = []
    seen_names: set[str] = set()

    # Flat files: targets/*.yml
    for yml in sorted(base.glob("*.yml")):
        name = yml.stem
        if name in seen_names:
            continue
        seen_names.add(name)
        try:
            with open(yml) as f:
                config = yaml.safe_load(f) or {}
            results.append({"name": name, "path": str(yml), "config": config})
        except (yaml.YAMLError, OSError) as exc:
            _log.warning("Skipping %s: %s", yml, exc)

    # Nested dirs: targets/*/project.yml
    for sub in sorted(base.iterdir()):
        if not sub.is_dir():
            continue
        nested = sub / "project.yml"
        if not nested.exists():
            continue
        name = sub.name
        if name in seen_names:
            continue
        seen_names.add(name)
        try:
            with open(nested) as f:
                config = yaml.safe_load(f) or {}
            results.append({"name": name, "path": str(nested), "config": config})
        except (yaml.YAMLError, OSError) as exc:
            _log.warning("Skipping %s: %s", nested, exc)

    return results


def derive_target_code(config: dict) -> str:
    """Derive the build-target identifier from a project config.

    Resolution order:
    1. Explicit ``hardware.target`` value from the config.
    2. Auto-derived as ``{vendor}-{part_short}`` where *part_short* is the
       part string truncated at the first ``-`` (e.g. ``xc7z020clg400-1``
       becomes ``xc7z020clg400``).
    3. Empty string if no hardware section is present.

    Parameters
    ----------
    config : dict
        Parsed project.yml (or target YAML) content.

    Returns
    -------
    str
        The target code, or ``""`` if it cannot be derived.
    """
    hw = config.get("hardware", {})
    if not isinstance(hw, dict):
        return ""

    explicit = hw.get("target")
    if explicit:
        return str(explicit)

    vendor = hw.get("vendor", "")
    part = hw.get("part", "")
    if not vendor and not part:
        return ""

    # Truncate part at first hyphen for a shorter identifier
    part_short = part.split("-")[0] if part else ""
    return f"{vendor}-{part_short}".lower() if part_short else vendor.lower()


def project_requirements_path(
    config: dict,
    project_root: str | Path = ".",
) -> Path | None:
    """Return the absolute path to the project-level ``requirements.yml``, or None.

    Resolution order (RTL-P2.431):

      1. Explicit ``requirements: <path>`` field in project.yml — resolved
         relative to *project_root*.  Returned regardless of whether the
         file actually exists (caller decides how to handle missing files;
         an explicit declaration pointing at a non-existent file is a
         hard error, not a silent skip).
      2. Filesystem default: ``<project_root>/requirements.yml`` — returned
         only if the file actually exists.
      3. Otherwise ``None``: the project does not opt into project-level
         contract-first verification.

    Parameters
    ----------
    config : dict
        Parsed project.yml (or target YAML) content.
    project_root : str or Path, optional
        Directory to resolve relative paths and the filesystem default
        against.  Defaults to the current working directory.

    Returns
    -------
    Path or None
        Absolute path to requirements.yml when declared or discovered,
        else ``None``.
    """
    root = Path(project_root).resolve()

    explicit = config.get("requirements")
    if isinstance(explicit, str) and explicit.strip():
        return (root / explicit.strip()).resolve()

    fs_default = root / "requirements.yml"
    if fs_default.is_file():
        return fs_default

    return None
