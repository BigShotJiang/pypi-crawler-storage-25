# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Shared helpers for EDA tool management.

Used by both `rr docker` and `rr eda` commands.
"""

import os
import re
import subprocess
import zipfile
from pathlib import Path

from sdk.cli.resilience import cli_resilient_block


def load_sdk_requirements():
    """Load sdk_requirements.yml from the SDK root.

    Returns the parsed YAML dict, or empty dict on failure.
    """
    import yaml

    # Resolve SDK root (this file lives at sdk/cli/eda_helpers.py)
    sdk_root = Path(__file__).resolve().parent.parent
    req_file = sdk_root / "sdk_requirements.yml"
    if not req_file.exists():
        return {}
    with open(req_file) as f:
        return yaml.safe_load(f) or {}


def detect_tool(check_cmd, parse_regex):
    """Detect an EDA tool by running its check_cmd and parsing the output.

    Args:
        check_cmd: Command string to run (e.g. "vivado -version").
        parse_regex: Regex pattern with a capture group for the version.

    Returns:
        (version_str, binary_path) or (None, None).
    """
    parts = check_cmd.split()
    binary = parts[0]

    # Find the binary
    import shutil

    binary_path = shutil.which(binary)
    if not binary_path:
        return None, None

    try:
        result = subprocess.run(
            parts, capture_output=True, text=True, timeout=10,
        )
        output = result.stdout + result.stderr
    except (subprocess.TimeoutExpired, FileNotFoundError, PermissionError):
        return None, binary_path

    match = re.search(parse_regex, output)
    version = match.group(1) if match else None
    return version, binary_path



def read_env_var(key):
    """Read a variable from the project .env file (same as docker-compose does)."""
    value = os.environ.get(key)
    if value:
        return value
    dotenv = Path(".env")
    if dotenv.exists():
        with cli_resilient_block(".env reading"):
            for line in dotenv.read_text().splitlines():
                line = line.strip()
                if line.startswith(f"{key}="):
                    return line.split("=", 1)[1].strip().strip("'\"")
    return None


def detect_quartus(install_dir):
    """Detect Quartus version and edition from an install directory.

    Returns (version, major_minor, edition, quartus_sh_path).
    Edition is 'pro', 'std', or None.
    """
    install_path = Path(install_dir)
    if not install_path.exists():
        return None, None, None, None

    # Find quartus_sh binary
    quartus_sh = None
    for candidate in install_path.rglob("quartus_sh"):
        if candidate.is_file():
            quartus_sh = str(candidate)
            break

    if not quartus_sh:
        # Manual search with maxdepth
        try:
            result = subprocess.run(
                ["find", str(install_path), "-maxdepth", "4", "-name", "quartus_sh", "-type", "f"],
                capture_output=True, text=True, timeout=5,
            )
            if result.stdout.strip():
                quartus_sh = result.stdout.strip().splitlines()[0]
        except (subprocess.TimeoutExpired, FileNotFoundError):
            pass

    if not quartus_sh:
        return None, None, None, None

    # Get version info
    try:
        result = subprocess.run(
            [quartus_sh, "--version"],
            capture_output=True, text=True, timeout=10,
        )
        version_raw = result.stdout + result.stderr
    except (subprocess.TimeoutExpired, FileNotFoundError, PermissionError):
        return None, None, None, quartus_sh

    # Parse version
    ver_match = re.search(r"Version (\d+\.\d+\.\d+)", version_raw)
    version = ver_match.group(1) if ver_match else None

    # Parse major.minor
    mm_match = re.search(r"Version (\d+\.\d+)", version_raw)
    major_minor = mm_match.group(1) if mm_match else None

    # Parse edition
    edition = None
    if re.search(r"Pro Edition", version_raw, re.IGNORECASE):
        edition = "pro"
    elif re.search(r"Standard", version_raw, re.IGNORECASE):
        edition = "std"

    return version, major_minor, edition, quartus_sh


def check_version_compat(quartus_major_minor, quartus_edition, qdz_filename):
    """Check version and edition compatibility between installed Quartus and a .qdz file.

    Returns a mismatch description string, or None if compatible.

    Filename pattern: <family>-<ver>(std|pro).<build>.<rev>.qdz
    Examples: arria10-23.1std.0.991.qdz → 23.1, std
    """
    m = re.search(r"-(\d+\.\d+)(std|pro)\.", qdz_filename)
    if not m:
        return None  # Can't parse — skip check

    qdz_ver = m.group(1)
    qdz_edition = m.group(2)

    if not quartus_major_minor:
        return None  # Can't check — skip

    mismatches = []
    if qdz_ver != quartus_major_minor:
        mismatches.append("version")
    if quartus_edition and qdz_edition != quartus_edition:
        mismatches.append("edition")

    if mismatches:
        return (
            f"{' and '.join(mismatches)} mismatch: "
            f"Quartus {quartus_major_minor} ({quartus_edition or '?'}) "
            f"vs package {qdz_filename} ({qdz_edition})"
        )
    return None


# Process-node / codename → human-friendly Intel FPGA product name.
# Used by scan_device_families() and CLI display routines.
DEVICE_FAMILY_NAMES = {
    # Pro edition (process-node dirs)
    "10nm": "Agilex",
    "7nm": "Agilex 5 / 7",
    "14nm": "Stratix 10",
    "20nm": "Arria 10, Cyclone 10 GX",
    "28nm": "Arria V, Cyclone V, MAX 10",
    # Std/Lite edition (family-name dirs)
    "cyclone10gx": "Cyclone 10 GX",
    "cyclonev": "Cyclone V",
    "cycloneiv": "Cyclone IV",
    "cycloneiii": "Cyclone III",
    "cyclone": "Cyclone",
    "arriav": "Arria V",
    "arriaii": "Arria II",
    "arria10": "Arria 10",
    "stratix10": "Stratix 10",
    "stratixv": "Stratix V",
    "stratixiv": "Stratix IV",
    "max10": "MAX 10",
    "maxv": "MAX V",
    "maxii": "MAX II",
    "55nm": "Cyclone III/IV, MAX V",
}


def scan_device_families(install_dir):
    """Scan installed device families from a Quartus installation.

    Handles three directory layouts:
    - **Pro**:      ``install_dir/devices/<family>/``
    - **Std/Lite**: ``install_dir/quartus/common/devinfo/<family>/``
    - **Versioned**: ``install_dir/<ver>/quartus/common/devinfo/<family>/``

    Returns list of ``(family_name, part_count, friendly_name)`` tuples where
    *part_count* is the number of device-variant subdirectories and
    *friendly_name* is the human-readable product name (or ``""``).
    """
    root = Path(install_dir)

    # Admin dirs that appear alongside real device families.
    # Stable across Pro 25.3, Std 24.1, Lite 25.1.
    admin_dirs = frozenset({
        "configuration", "dev_install", "legacy", "programmer",
        "cdc_lib", "sim_lib", "sim_lib2",
    })

    # ── Locate device metadata root ──
    device_root = None

    # Path 1 (Pro): {root}/devices/
    pro_path = root / "devices"
    if pro_path.is_dir():
        device_root = pro_path
    else:
        # Path 2 (Std/Lite): search for quartus/common/devinfo with bounded depth
        for candidate in root.glob("**/quartus/common/devinfo"):
            try:
                candidate.relative_to(root)
            except ValueError:
                continue
            parts = candidate.relative_to(root).parts
            if len(parts) <= 5 and candidate.is_dir():
                device_root = candidate
                break

        # Fallback: try the flat path explicitly (backward compat)
        if device_root is None:
            flat = root / "quartus" / "common" / "devinfo"
            if flat.is_dir():
                device_root = flat

    if device_root is None:
        return []

    families = []
    for fam_dir in sorted(device_root.iterdir()):
        if fam_dir.is_dir() and fam_dir.name.lower() not in admin_dirs:
            part_count = sum(1 for d in fam_dir.iterdir() if d.is_dir())
            friendly = DEVICE_FAMILY_NAMES.get(fam_dir.name.lower(), "")
            families.append((fam_dir.name, part_count, friendly))
    return families




def extract_qdz(qdz_path, target_dir, progress=True):
    """Extract a .qdz file into a target directory with optional progress bar.

    Returns the number of files extracted, or raises on failure.
    """
    import sys

    z = zipfile.ZipFile(qdz_path)
    members = z.namelist()
    total = len(members)
    files = 0
    bar_width = 40

    for i, member in enumerate(members, 1):
        z.extract(member, target_dir)
        if not member.endswith("/"):
            files += 1
        if progress:
            pct = i * 100 // total
            filled = bar_width * i // total
            bar = "█" * filled + "░" * (bar_width - filled)
            sys.stdout.write(f"\r     [{bar}] {pct:3d}%  ({files} files)")
            sys.stdout.flush()

    if progress:
        sys.stdout.write("\n")

    return files


def find_patch_zips(installer_dir):
    """Find Quartus patch .zip files containing *-linux.run installers.

    Returns list of Path objects for matching .zip files.
    """
    p = Path(installer_dir)
    if not p.is_dir():
        return []

    patches = []
    for zf in sorted(p.glob("*.zip")):
        try:
            z = zipfile.ZipFile(zf)
            if any(n.endswith("-linux.run") for n in z.namelist()):
                patches.append(zf)
        except (zipfile.BadZipFile, Exception):
            pass
    return patches
