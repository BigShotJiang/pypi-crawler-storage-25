# SPDX-FileCopyrightText: 2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Standalone IP workflows — drive sim/synth from ip.yml without project.yml.

RTL-P2.434 / RTL-P2.435 — the user-facing half of the ip.yml mini-project
vision (RTL-P2.431): a user with only ``ip.yml`` + HDL should be able to
run ``rr sim run --ip <dir>`` / ``rr synth run --ip <dir>`` to exercise
the IP in isolation — no wrapping project.yml, no target pointer.

This module translates an :class:`IpManifest` into the subset of values
the downstream engines need (top module, simulator, hdl sources, test
dir, waves format).  Defaults are deliberately conservative and mirror
the project.yml equivalents one would write today.
"""

from __future__ import annotations

import logging
import os
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional

_log = logging.getLogger("cli.ip_standalone")


class IpStandaloneError(RuntimeError):
    """Raised when ip.yml is missing the fields needed for standalone ops."""


@dataclass(frozen=True)
class SimPlan:
    """Resolved simulation plan for one IP, ready to hand to run_simulation()."""

    top_level: str
    top_level_lang: str        # "vhdl" | "verilog"
    simulator: str             # "verilator" | "nvc" | "ghdl" | ...
    hdl_sources: tuple[str, ...]
    tests_dir: Path            # Absolute path
    module: Optional[str]      # When None → caller picks (first test_*.py, or menu)
    wave_formats: Optional[tuple[str, ...]] = None


@dataclass(frozen=True)
class SynthPlan:
    """Resolved synth-smoke plan for one IP (RTL-P2.435).

    Produced by :func:`build_synth_plan` from an IP's ip.yml.  Carries
    the fields a vendor backend needs to run a smoke synthesis without
    a wrapping project.yml: top module, hardware identity, XDC
    constraints, per-stage TCL hooks, HDL sources.
    """

    top_module: str
    vendor: str                # "xilinx" | "altera" | ...
    part: str                  # e.g. "xc7z020clg400-1"
    tool_version: Optional[str]  # e.g. "2024.2" (optional, tool-version hint)
    hdl_sources: tuple[str, ...]
    xdc_sources: tuple[str, ...]
    tcl_hooks: dict            # {stage: [abs paths]}

    @property
    def ready(self) -> bool:
        """True iff the plan has the minimum set required to run synthesis."""
        return bool(self.top_module and self.vendor and self.part and self.hdl_sources)


def load_ip_manifest(ip_dir: Path, vendor: str = "xilinx"):
    """Load the IP at *ip_dir*/ip.yml into an :class:`IpManifest`.

    *vendor* is used only for the vendor-mode compatibility check; sim
    workflows don't care, so the caller can pass whatever is needed for
    the downstream consumer (synth defaults to the IP's declared vendor
    when available; sim passes 'xilinx' as a harmless default).
    """
    from routertl_core.ip_resolver import IpResolver

    ip_dir = Path(ip_dir).resolve()
    ip_yml = ip_dir / "ip.yml"
    if not ip_yml.is_file():
        raise IpStandaloneError(f"ip.yml not found at {ip_yml}")

    resolver = IpResolver(project_root=ip_dir, vendor=vendor)
    result = resolver.resolve([str(ip_yml)])
    if result.errors:
        raise IpStandaloneError(
            f"Failed to load ip.yml at {ip_yml}:\n  - "
            + "\n  - ".join(result.errors)
        )
    if not result.manifests:
        raise IpStandaloneError(f"ip.yml at {ip_yml} produced no manifests")
    # Top-level manifest is the last one appended (children are appended first).
    return result.manifests[-1]


def build_sim_plan(ip_dir: Path, module: Optional[str] = None) -> SimPlan:
    """Derive a :class:`SimPlan` from an IP's ip.yml.

    Field resolution:

    - ``top_level``       = ``hdl.top_sim`` | ``hdl.top_module`` | IP name.
    - ``top_level_lang``  = ``verilog`` when the IP declares
      ``systemverilog`` / ``verilog``; ``vhdl`` otherwise.  Mixed-language
      IPs fall back to the declared primary language; selecting a
      specific simulator that supports both is the user's job.
    - ``simulator``       = ``build.simulation.simulator`` when set, else
      ``verilator`` for systemverilog, ``nvc`` for vhdl (the pragmatic
      open-source defaults).
    - ``hdl_sources``     = ``manifest.effective_simulation_sources``
      (``build.simulation.sources`` when set, else synthesis sources).
    - ``tests_dir``       = ``<ip_dir>/<build.simulation.test_dir>``,
      defaulting to ``<ip_dir>/tests``.
    - ``wave_formats``    = ``build.simulation.waves.formats`` when set.
    """
    manifest = load_ip_manifest(ip_dir)
    ip_dir = Path(ip_dir).resolve()

    top = manifest.top_sim or manifest.top_module or manifest.name
    if not top:
        raise IpStandaloneError(
            f"ip.yml at {ip_dir} declares no hdl.top_sim, hdl.top_module, "
            "or name — cannot resolve a top-level for simulation."
        )

    lang_raw = (manifest.language or "vhdl").lower()
    if lang_raw in ("systemverilog", "verilog", "sv"):
        top_level_lang = "verilog"
    else:
        top_level_lang = "vhdl"

    sim_cfg = manifest.simulation_config or {}
    simulator = sim_cfg.get("simulator")
    if not simulator:
        simulator = "verilator" if top_level_lang == "verilog" else "nvc"

    test_dir_rel = sim_cfg.get("test_dir", "tests")
    tests_dir = (ip_dir / test_dir_rel).resolve()
    if not tests_dir.is_dir():
        raise IpStandaloneError(
            f"Tests directory not found: {tests_dir}\n"
            f"  Set build.simulation.test_dir in ip.yml or create {tests_dir}."
        )

    hdl_sources = tuple(manifest.effective_simulation_sources)
    if not hdl_sources:
        raise IpStandaloneError(
            f"ip.yml at {ip_dir} declares no HDL sources — add sources "
            "via hdl.files (scan-based) or build.synthesis.sources."
        )

    waves = sim_cfg.get("waves")
    wave_formats: Optional[tuple[str, ...]] = None
    if isinstance(waves, dict):
        fmts = waves.get("formats")
        if isinstance(fmts, list) and fmts:
            wave_formats = tuple(str(f) for f in fmts)

    return SimPlan(
        top_level=top,
        top_level_lang=top_level_lang,
        simulator=simulator,
        hdl_sources=hdl_sources,
        tests_dir=tests_dir,
        module=module,
        wave_formats=wave_formats,
    )


def build_synth_plan(ip_dir: Path) -> SynthPlan:
    """Derive a :class:`SynthPlan` from an IP's ip.yml (RTL-P2.435).

    Field resolution:

    - ``top_module``   = ``hdl.top_module`` | IP name.
    - ``vendor``       = ``build.hardware.vendor`` | empty string.
    - ``part``         = ``build.hardware.part`` | empty string.
    - ``tool_version`` = ``build.hardware.tool_version`` | None.
    - ``hdl_sources``  = synthesis sources (``manifest.sources``).
    - ``xdc_sources``  = ``build.sources.xdc`` (abs paths).
    - ``tcl_hooks``    = ``build.tcl_hooks.*`` (abs paths per stage).

    Returns the plan even when fields are missing — :attr:`SynthPlan.ready`
    is the single-bit verdict for whether the IP can be synthesised
    standalone.  Callers decide whether to print, validate, or spawn
    the vendor flow.
    """
    manifest = load_ip_manifest(
        ip_dir,
        vendor=str((manifest_hardware(ip_dir) or {}).get("vendor", "xilinx")),
    )

    hardware = manifest.hardware or {}
    vendor = str(hardware.get("vendor", "")).lower()
    part = str(hardware.get("part", ""))
    tool_version_raw = hardware.get("tool_version")
    tool_version = str(tool_version_raw) if tool_version_raw else None

    top_module = manifest.top_module or manifest.name or ""

    return SynthPlan(
        top_module=top_module,
        vendor=vendor,
        part=part,
        tool_version=tool_version,
        hdl_sources=tuple(manifest.sources),
        xdc_sources=tuple(manifest.xdc_sources),
        tcl_hooks=dict(manifest.tcl_hooks),
    )


def manifest_hardware(ip_dir: Path) -> Optional[dict]:
    """Peek at ``build.hardware`` before loading the full manifest.

    The primary :func:`load_ip_manifest` path wants to know the vendor
    up-front so :class:`IpResolver` can validate mode compatibility.
    For IPs that declare their own vendor via ``build.hardware``, this
    avoids hard-coding ``xilinx`` as the default during plan synthesis.
    Returns ``None`` when no hardware block is declared (callers fall
    back to a conservative default).
    """
    import yaml as _yaml

    ip_yml = Path(ip_dir) / "ip.yml"
    if not ip_yml.is_file():
        return None
    try:
        with open(ip_yml) as f:
            raw = _yaml.safe_load(f) or {}
    except (OSError, _yaml.YAMLError):
        return None
    if not isinstance(raw, dict):
        return None

    from sdk.engine.ip_yml import hardware_config, normalize_ip_yml
    try:
        norm = normalize_ip_yml(raw)
    except (TypeError, ValueError):
        return None
    hw = hardware_config(norm)
    return hw or None


def discover_test_modules(tests_dir: Path) -> List[str]:
    """Return the list of ``test_*.py`` module stems under *tests_dir*.

    Sorted for stable picks when the user doesn't specify a module.
    Returns ``[]`` if the directory is missing or empty.
    """
    p = Path(tests_dir)
    if not p.is_dir():
        return []
    return sorted(f.stem for f in p.glob("test_*.py"))


@contextmanager
def cwd(path: Path):
    """chdir into *path* for the duration of the ``with`` block."""
    prev = Path.cwd()
    os.chdir(path)
    try:
        yield Path(path)
    finally:
        os.chdir(prev)
