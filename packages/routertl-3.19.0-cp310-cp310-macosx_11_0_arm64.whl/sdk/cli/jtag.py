# SPDX-FileCopyrightText: 2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Shared JTAG chain scanning — wraps vendor-specific enumeration tools.

Provides a unified API for discovering JTAG cables and devices across
Altera (``jtagconfig``) and Xilinx (``vivado`` HW Manager) toolchains.
Used by ``rr program cables`` and ``rr hardware doctor``.
"""

from __future__ import annotations

import os
import re
import shutil
import subprocess
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class JtagDevice:
    """Single device on a JTAG chain."""

    position: int  # 1-indexed chain position
    idcode: str  # hex IDCODE (e.g. "0x020F30DD")
    name: str = ""  # device name if known (e.g. "5CEBA4F23")


@dataclass
class JtagCable:
    """A JTAG cable/probe with its device chain."""

    index: int  # cable index (1-indexed)
    name: str  # cable name (e.g. "USB-Blaster II [1-3]")
    devices: list[JtagDevice] = field(default_factory=list)


# ── Public API ────────────────────────────────────────────────────


def scan_jtag_chain(vendor: str) -> list[JtagCable]:
    """Scan JTAG chain using vendor tools.

    Parameters
    ----------
    vendor : str
        Vendor name (``altera``, ``xilinx``).

    Returns
    -------
    list[JtagCable]
        Discovered cables with their device chains.
        Empty list if tools are unavailable or no hardware found.
    """
    if vendor == "altera":
        return _scan_altera()
    if vendor == "xilinx":
        return _scan_xilinx()
    return []


# ── Altera: jtagconfig ────────────────────────────────────────────


def _scan_altera() -> list[JtagCable]:
    """Parse ``jtagconfig`` output into structured cable/device data.

    Example jtagconfig output::

        1) USB-Blaster II [1-3]
          020F30DD   5CEBA4(F23|F17)
          02D020DD   5M(1270ZF256|2210Z)
        2) USB-Blaster [2-4]
          020F30DD   EP4CE15
    """
    if not shutil.which("jtagconfig"):
        return []

    rc, output = _run(["jtagconfig"], timeout=15)
    if rc != 0:
        return []

    return _parse_jtagconfig(output)


def _parse_jtagconfig(output: str) -> list[JtagCable]:
    """Parse jtagconfig stdout into JtagCable list."""
    cables: list[JtagCable] = []
    current_cable: JtagCable | None = None

    # Cable header:  1) USB-Blaster II [1-3]
    cable_re = re.compile(r"^\s*(\d+)\)\s+(.+)$")
    # Device line:    020F30DD   5CEBA4(F23|F17)
    device_re = re.compile(r"^\s+([0-9A-Fa-f]{8})\s+(.*)$")

    position = 0
    for line in output.splitlines():
        m = cable_re.match(line)
        if m:
            current_cable = JtagCable(index=int(m.group(1)), name=m.group(2).strip())
            cables.append(current_cable)
            position = 0
            continue

        m = device_re.match(line)
        if m and current_cable is not None:
            position += 1
            idcode = f"0x{m.group(1).upper()}"
            name = m.group(2).strip()
            current_cable.devices.append(
                JtagDevice(position=position, idcode=idcode, name=name)
            )

    return cables


# ── Xilinx: Vivado HW Manager ────────────────────────────────────


def _scan_xilinx() -> list[JtagCable]:
    """Run ``scan_chain.tcl`` via Vivado and parse tagged output."""
    vivado = shutil.which("vivado")
    if not vivado:
        return []

    tcl_path = Path(__file__).parent.parent.parent / "tcl" / "xilinx" / "scan_chain.tcl"
    if not tcl_path.exists():
        return []

    rc, output = _run(
        [vivado, "-mode", "batch", "-nolog", "-nojournal", "-notrace", "-source", str(tcl_path)],
        timeout=30,
    )
    if rc != 0:
        return []

    return _parse_scan_chain_output(output)


def _parse_scan_chain_output(output: str) -> list[JtagCable]:
    """Parse tagged Vivado scan_chain.tcl output.

    Expected format::

        CABLE:localhost:3121/xilinx_tcf/Digilent/210249A065B4
        DEVICE:1:0x13722093:xc7z020_1
    """
    cables: list[JtagCable] = []
    current_cable: JtagCable | None = None
    cable_idx = 0

    for line in output.splitlines():
        line = line.strip()
        if line.startswith("CABLE:"):
            cable_idx += 1
            name = line[len("CABLE:"):]
            current_cable = JtagCable(index=cable_idx, name=name)
            cables.append(current_cable)
        elif line.startswith("DEVICE:") and current_cable is not None:
            parts = line[len("DEVICE:"):].split(":", 2)
            if len(parts) >= 2:
                try:
                    pos = int(parts[0])
                except ValueError:
                    continue
                idcode = parts[1]
                name = parts[2] if len(parts) > 2 else ""
                current_cable.devices.append(
                    JtagDevice(position=pos, idcode=idcode, name=name)
                )

    return cables


# ── Helpers ───────────────────────────────────────────────────────


def _run(cmd, timeout=10):
    """Run a command and return (returncode, stdout+stderr)."""
    try:
        r = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout,
            env=os.environ.copy(),
        )
        return r.returncode, (r.stdout or "") + (r.stderr or "")
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError, ValueError):
        return 1, ""
