# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""CLI command: routertl watch — Polling file watcher for auto-rerun.

P2.14: Watch-mode composition — supports `rr watch sim <test>` and
`rr watch lint` with configurable debouncing.
"""

import os
import subprocess
import sys
import time
from pathlib import Path

import rich_click as click

from sdk.cli.console import console


def _collect_mtimes(directories, extensions=None):
    """Snapshot modification times for all files under *directories*.

    Parameters
    ----------
    directories : list[Path]
        Root directories to walk.
    extensions : set[str] | None
        If given, only watch files whose suffix (lower) is in this set.

    Returns
    -------
    dict[Path, float]
        Mapping of resolved file paths to their ``st_mtime``.
    """
    mtimes: dict[Path, float] = {}
    for root in directories:
        if not root.exists():
            continue
        for dirpath, _, filenames in os.walk(root):
            for fn in filenames:
                fp = Path(dirpath) / fn
                if extensions and fp.suffix.lower() not in extensions:
                    continue
                try:
                    mtimes[fp.resolve()] = fp.stat().st_mtime
                except OSError:
                    pass
    return mtimes


# File types to monitor
_WATCH_EXTENSIONS = {
    ".vhd",
    ".vhdl",
    ".v",
    ".sv",
    ".vh",
    ".svh",  # RTL
    ".py",  # Testbenches
}


def _detect_changes(prev, curr):
    """Return list of changed or deleted files between two snapshots."""
    changed: list[Path] = []
    for p, mtime in curr.items():
        if p not in prev or prev[p] != mtime:
            changed.append(p)
    for p in set(prev) - set(curr):
        changed.append(p)
    return changed


def _build_command(mode, testbench):
    """Build the subprocess command for the given watch mode.

    Parameters
    ----------
    mode : str
        One of 'sim' or 'lint'.
    testbench : str | None
        Test module name (only used in 'sim' mode).

    Returns
    -------
    list[str]
        Command to execute.
    str
        Human-readable description of the command.
    """
    if mode == "lint":
        return ["make", "linting"], "lint"
    # sim mode
    if testbench:
        return ["make", "sim", f"MODULE={testbench}"], f"sim {testbench}"
    return ["make", "simulation"], "sim (all)"


def _print_banner(mode, existing, testbench, interval, debounce):
    """Print the watch mode startup banner."""
    mode_label = {"sim": "Simulation", "lint": "Linting"}
    console.print(f"\n👁️  [cyan]RouteRTL Watch Mode — {mode_label.get(mode, mode)}[/]")
    console.print(f"   Monitoring: [green]{', '.join(str(d) for d in existing)}[/]")
    console.print(f"   Interval:  {interval}s (debounce: {debounce}s)")

    if mode == "sim":
        if testbench:
            console.print(f"   Target:    [cyan]{testbench}[/]")
        else:
            console.print("   Target:    [yellow](full simulation suite)[/]")
    elif mode == "lint":
        console.print("   Target:    [cyan]linting (ruff + HDL)[/]")

    console.print("\n   Press [yellow]Ctrl+C[/] to stop.\n")


def _run_watch_loop(mode, testbench, existing, interval, debounce):
    """Core polling loop with debouncing.

    Parameters
    ----------
    mode : str
        Watch mode ('sim' or 'lint').
    testbench : str | None
        Test module name (sim mode only).
    existing : list[Path]
        Directories to monitor.
    interval : float
        Polling interval in seconds.
    debounce : float
        Debounce window in seconds — after detecting a change, wait this
        long for additional changes before triggering the action.
    """
    prev = _collect_mtimes(existing, _WATCH_EXTENSIONS)
    run_count = 0

    try:
        while True:
            time.sleep(interval)
            curr = _collect_mtimes(existing, _WATCH_EXTENSIONS)
            changed = _detect_changes(prev, curr)

            if not changed:
                continue

            # ── Debounce: wait for rapid-fire saves to settle ──
            if debounce > 0:
                settle_deadline = time.monotonic() + debounce
                while time.monotonic() < settle_deadline:
                    time.sleep(min(0.1, settle_deadline - time.monotonic()))
                    curr2 = _collect_mtimes(existing, _WATCH_EXTENSIONS)
                    extra = _detect_changes(curr, curr2)
                    if extra:
                        # More changes — extend the window
                        changed.extend(extra)
                        curr = curr2
                        settle_deadline = time.monotonic() + debounce

            # Deduplicate
            changed = list(dict.fromkeys(changed))

            run_count += 1
            console.print(f"🔄 [yellow]Change detected ({len(changed)} file(s)):[/]")
            for p in changed[:5]:
                console.print(f"   [dim]{p.name}[/]")
            if len(changed) > 5:
                console.print(f"   [dim]... and {len(changed) - 5} more[/]")

            cmd, desc = _build_command(mode, testbench)
            console.print(f"\n🚀 [blue]Run #{run_count}: {desc}[/]\n")

            try:
                result = subprocess.run(cmd, check=False)
                if result.returncode == 0:
                    emoji = "✅" if mode == "sim" else "🧹"
                    label = "Simulation passed" if mode == "sim" else "Linting passed"
                    console.print(f"\n{emoji} [green]{label}.[/]")
                else:
                    label = "Simulation failed" if mode == "sim" else "Linting failed"
                    console.print(f"\n❌ [red]{label} (exit {result.returncode}).[/]")
            except FileNotFoundError:
                console.print("❌ [red]'make' not found.[/]")
                sys.exit(1)

            console.print("\n👁️  [dim]Watching for changes...[/]\n")

            # Update snapshot after run
            prev = _collect_mtimes(existing, _WATCH_EXTENSIONS)

    except KeyboardInterrupt:
        console.print("\n\n👋 [cyan]Watch mode stopped.[/]")


@click.command(name="watch")
@click.argument("mode", required=False, default=None)
@click.argument("testbench", required=False, default=None)
@click.option("--interval", "-i", type=float, default=1.5, help="Polling interval in seconds (default: 1.5).")
@click.option("--debounce", "-d", type=float, default=0.3, help="Debounce window in seconds (default: 0.3).")
@click.option("--src", "src_dir", default=None, help="Source directory to watch (default: from project.yml or 'src').")
@click.option("--sim", "sim_dir", default=None, help="Simulation directory to watch (default: from project.yml).")
def watch_command(mode, testbench, interval, debounce, src_dir, sim_dir):
    """Auto-rerun simulation or linting whenever source files change.

    Uses a polling file watcher — no external dependencies required.
    Monitors src/ and sim/ directories for RTL and Python file changes.
    Rapid-fire saves are debounced to trigger a single rerun.

    \b
    Modes:
        sim [TEST]   Watch and rerun simulation (default)
        lint         Watch and rerun linting

    \b
    Examples:
        rr watch sim test_uart_sniffer       # watch sim, specific test
        rr watch sim                         # watch sim, full suite
        rr watch lint                        # watch lint on save
        rr watch test_edge_counter           # shorthand (sim mode)
        rr watch                             # rerun last sim on change
        rr watch sim test_foo -d 0.5         # 500ms debounce window
    """

    from sdk.cli.resilience import cli_resilient_block

    # ── Resolve mode ──
    # If mode is not 'sim' or 'lint', treat it as a testbench name
    # (backward compat: `rr watch test_uart` → sim mode)
    if mode is not None and mode not in ("sim", "lint"):
        # mode is actually a testbench name (backward compat)
        if testbench is not None:
            console.print(f"❌ [red]Too many arguments: '{mode}' and '{testbench}'.[/]")
            console.print("   Usage: rr watch [sim|lint] [TEST]")
            sys.exit(1)
        testbench = mode
        mode = "sim"
    elif mode is None:
        mode = "sim"

    if mode == "lint" and testbench:
        console.print("⚠️  [yellow]Ignoring testbench argument in lint mode.[/]")
        testbench = None

    if testbench and testbench.endswith(".py"):
        testbench = testbench[:-3]

    # ── Resolve watch directories from project.yml ──
    config = {}
    if os.path.exists("project.yml"):
        with cli_resilient_block("project YAML loading"):
            from sdk.cli.project_config import load_project_config

            config = load_project_config()

    if not src_dir:
        paths_cfg = config.get("paths", {})
        src_raw = paths_cfg.get("sources", "src")
        src_dirs = src_raw if isinstance(src_raw, list) else [src_raw]
    else:
        src_dirs = [src_dir]

    if not sim_dir:
        sim_dir = config.get("simulation", {}).get("test_dir", "sim/cocotb/tests")

    watch_dirs = [Path(d) for d in src_dirs] + [Path(sim_dir)]
    existing = [d for d in watch_dirs if d.exists()]

    if not existing:
        console.print(f"❌ [red]No watchable directories found: {[str(d) for d in watch_dirs]}[/]")
        sys.exit(1)

    _print_banner(mode, existing, testbench, interval, debounce)
    _run_watch_loop(mode, testbench, existing, interval, debounce)
