# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Launch RouteWave standalone — ``rr routewave``."""

import rich_click as click

from sdk.cli.console import console


@click.command("routewave")
@click.argument("waveform", required=False, default=None)
@click.option("--cli", is_flag=True, default=False,
              help="Use the headless CLI parser instead of the GUI.")
@click.option("--check", is_flag=True, default=False,
              help="Validate a VCD file without loading (reports issues with line numbers).")
@click.option("--version", "-v", "show_version", is_flag=True, default=False,
              help="Show RouteWave version.")
def routewave_command(waveform, cli, check, show_version):
    """Launch the RouteWave waveform viewer.

    \b
    Opens RouteWave immediately.  Optionally pass a waveform file to open.
    Auto-downloads the binary on first use.

    \b
    Examples:
        rr routewave                        # open empty viewer
        rr routewave sim/waves/test.fst     # open a specific waveform
        rr routewave --cli dump.vcd         # parse a VCD headlessly (no GPU)
        rr routewave --check dump.vcd       # validate VCD file integrity
        rr routewave --version              # show version

    \b
    WSL2 (Windows):
        Windows 11: works out of the box via WSLg.
        Windows 10: install VcXsrv, then:
            export DISPLAY=$(ip route list default | awk '{print $3}'):0
            rr routewave
    """
    import subprocess
    from pathlib import Path

    from sdk.cli.viewer_manager import CACHE_DIR, get_viewer_path, launch_viewer

    viewer = get_viewer_path()
    if viewer is None:
        console.print(
            "❌ [red]Could not download RouteWave.[/]\n"
            "   Check your network connection and try again,\n"
            "   or install manually:  [cyan]rr ws update-viewer[/]"
        )
        raise SystemExit(1)

    # --version: run the binary with --version and exit
    if show_version:
        cli_bin = CACHE_DIR / "routewave_cli"
        bin_path = cli_bin if cli_bin.exists() else viewer
        result = subprocess.run([str(bin_path), "--version"], capture_output=True, text=True)
        console.print(result.stdout.strip())
        raise SystemExit(0)

    # --check: validate VCD file integrity
    if check:
        cli_bin = CACHE_DIR / "routewave_cli"
        if not cli_bin.exists():
            console.print(
                "❌ [red]routewave_cli not found.[/]\n"
                "   Update with: [cyan]rr ws update-viewer[/]"
            )
            raise SystemExit(1)
        if not waveform:
            console.print("❌ [red]--check requires a waveform file.[/]")
            raise SystemExit(1)
        wf = Path(waveform)
        if not wf.exists():
            console.print(f"❌ [red]File not found:[/] {waveform}")
            raise SystemExit(1)
        result = subprocess.run([str(cli_bin), "--validate", str(wf.resolve())])
        raise SystemExit(result.returncode)

    # --cli: run routewave_cli instead of the GUI
    if cli:
        cli_bin = CACHE_DIR / "routewave_cli"
        if not cli_bin.exists():
            console.print(
                "❌ [red]routewave_cli not found.[/]\n"
                "   Update with: [cyan]rr ws update-viewer[/]"
            )
            raise SystemExit(1)
        if not waveform:
            console.print("❌ [red]--cli requires a waveform file.[/]")
            raise SystemExit(1)
        wf = Path(waveform)
        if not wf.exists():
            console.print(f"❌ [red]File not found:[/] {waveform}")
            raise SystemExit(1)
        result = subprocess.run([str(cli_bin), str(wf.resolve())])
        raise SystemExit(result.returncode)

    console.print("[blue]RouteWave[/] — waveform viewer for FPGA development\n")

    wf = None
    if waveform:
        wf = Path(waveform)
        if not wf.exists():
            console.print(f"❌ [red]File not found:[/] {waveform}")
            raise SystemExit(1)

    proc = launch_viewer(wf, viewer_path=viewer)
    if proc is None:
        console.print("❌ [red]Failed to launch RouteWave.[/]")
        raise SystemExit(1)

    # Check if the process died immediately (e.g. missing DISPLAY, OpenGL)
    if proc.returncode is not None and proc.returncode != 0:
        error = getattr(proc, "_rw_error", "")
        console.print(f"❌ [red]RouteWave exited immediately (code {proc.returncode}).[/]")
        if error:
            console.print(f"   [dim]{error}[/]")
        if "libOpenGL" in error or "libGL" in error or "libEGL" in error:
            console.print(
                "\n   [yellow]Missing OpenGL libraries.[/] On a fresh WSL2/Ubuntu:\n"
                "     [cyan]sudo apt install libopengl0 libgl1 libglx-mesa0 libegl1[/]"
            )
        elif "DISPLAY" in error or "display" in error.lower():
            console.print(
                "\n   [yellow]Display not available.[/] On WSL2:\n"
                "   [dim]Windows 11:[/] WSLg should work automatically — try [cyan]wsl --update[/]\n"
                "   [dim]Windows 10:[/] Install VcXsrv, then:\n"
                "     [cyan]export DISPLAY=$(ip route list default | awk '\\{print $3\\}'):0[/]"
            )
        raise SystemExit(1)

    if wf:
        console.print(f"✅ [green]RouteWave launched[/] with [cyan]{wf}[/]")
    else:
        console.print("✅ [green]RouteWave launched.[/]")
