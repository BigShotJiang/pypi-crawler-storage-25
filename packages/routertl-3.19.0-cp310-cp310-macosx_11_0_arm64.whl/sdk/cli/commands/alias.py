# SPDX-FileCopyrightText: 2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
Alias Management — ``rr alias``.

Create, list, show, remove, and edit user-defined command aliases.
Aliases are stored in ``.routertl/aliases.yml`` (project scope, committed)
or ``~/.config/routertl/aliases.yml`` (user scope, personal).

Backlog: RTL-P2.133.
"""

import os
import sys

import rich_click as click
from rich.table import Table

from sdk.cli.console import console
from sdk.cli.resilience import cli_resilient


@cli_resilient("CLI name resolution", default="routertl")
def _resolve_cli_name():
    from sdk.cli.main import CLI_NAME
    return CLI_NAME


def _get_project_root():
    """Get the project root from click context or CWD."""
    ctx = click.get_current_context(silent=True)
    if ctx and ctx.obj and "project_root" in ctx.obj:
        return str(ctx.obj["project_root"])
    return "."


@click.group(name="alias")
def alias_group():
    """Manage user-defined command aliases.

    \b
    Aliases let you define custom rr subcommands for project-specific
    workflows. They are invoked directly: rr <alias-name>.

    \b
    Scopes:
      Project  .routertl/aliases.yml     (committed, shared)
      User     ~/.config/routertl/       (personal, not committed)
    """


# ── rr alias create ──────────────────────────────────────────────


@alias_group.command(name="create")
@click.argument("name")
@click.argument("command")
@click.option("--description", "-d", default="", help="Human-readable description of what the alias does.")
@click.option("--working-dir", "-w", default=None, help="Working directory for the command (supports {root} template).")
@click.option("--global", "is_global", is_flag=True, help="Save to user scope (~/.config/routertl/) instead of project.")
def alias_create(name, command, description, working_dir, is_global):
    """Create or update an alias.

    \b
    Examples:
      rr alias create program-eval "echo q | quartus_pgm -c 1 -m jtag -o 'p;{bitstream}@1'"
      rr alias create fw-reload "rr project clean --sw && rr bitstream run --update-hex && rr program"
      rr alias create uart "nios2-terminal --instance 0" -d "Open JTAG UART terminal"
    """
    from sdk.engine.alias_loader import AliasEntry, save_alias

    # Check for collision with built-in commands
    _check_collision(name)

    scope = "global" if is_global else "project"
    project_root = _get_project_root()

    entry = AliasEntry(
        name=name,
        command=command,
        description=description,
        working_dir=working_dir,
        source=scope,
    )

    file_path = save_alias(entry, scope=scope, project_root=project_root)
    scope_label = "user" if is_global else "project"
    console.print(f"  [green]Created alias '{name}'[/] ({scope_label} scope)")
    console.print(f"  [dim]→ {file_path}[/]")

    if description:
        console.print(f"  [dim]{description}[/]")

    cli_name = _resolve_cli_name()
    console.print(f"\n  [dim]Run: {cli_name} {name}[/]")


def _check_collision(name: str) -> None:
    """Warn if an alias name shadows a built-in command."""
    try:
        from sdk.cli.main import cli
        builtin_names = set(cli.commands.keys()) if hasattr(cli, "commands") else set()
    except (ImportError, RuntimeError):
        builtin_names = set()

    if name in builtin_names:
        console.print(
            f"\n  [yellow]Warning: '{name}' shadows a built-in rr command.[/]\n"
            f"  [yellow]The built-in will take precedence — this alias will be unreachable.[/]\n"
        )


# ── rr alias list ────────────────────────────────────────────────


@alias_group.command(name="list")
@click.option("--json", "as_json", is_flag=True, help="Machine-readable JSON output.")
def alias_list(as_json):
    """List all defined aliases."""
    import json

    from sdk.engine.alias_loader import load_aliases

    project_root = _get_project_root()
    aliases = load_aliases(project_root)

    if as_json:
        data = {
            name: {
                "command": entry.command,
                "description": entry.description,
                "source": entry.source,
                "working_dir": entry.working_dir,
            }
            for name, entry in sorted(aliases.items())
        }
        click.echo(json.dumps(data, indent=2))
        return

    if not aliases:
        cli_name = _resolve_cli_name()
        console.print(
            "\n  [dim]No aliases defined.[/]\n"
            f"  [dim]Create one: {cli_name} alias create <name> <command>[/]\n"
        )
        return

    # Check for shadowed aliases
    try:
        from sdk.cli.main import cli
        builtin_names = set(cli.commands.keys()) if hasattr(cli, "commands") else set()
    except (ImportError, RuntimeError):
        builtin_names = set()

    table = Table(
        title="Aliases",
        title_style="bold cyan",
        show_lines=False,
        padding=(0, 1),
    )
    table.add_column("Name", style="cyan", min_width=15)
    table.add_column("Scope", width=8)
    table.add_column("Description", min_width=30)
    table.add_column("Command", style="dim", max_width=50)

    for name in sorted(aliases):
        entry = aliases[name]
        scope_str = "[green]project[/]" if entry.source == "project" else "[blue]user[/]"

        if name in builtin_names:
            name_str = f"{name} [yellow]\\[shadowed][/]"
        else:
            name_str = name

        # Truncate command for display
        cmd_display = entry.command
        if len(cmd_display) > 50:
            cmd_display = cmd_display[:47] + "..."

        table.add_row(name_str, scope_str, entry.description, cmd_display)

    console.print()
    console.print(table)
    console.print()


# ── rr alias show ────────────────────────────────────────────────


@alias_group.command(name="show")
@click.argument("name")
def alias_show(name):
    """Show details of a specific alias."""
    from sdk.engine.alias_loader import load_aliases

    project_root = _get_project_root()
    aliases = load_aliases(project_root)

    if name not in aliases:
        console.print(f"\n  [red]Alias '{name}' not found.[/]\n")
        sys.exit(1)

    entry = aliases[name]
    cli_name = _resolve_cli_name()

    console.print(f"\n  [bold cyan]{cli_name} {name}[/] — {entry.source.capitalize()} alias\n")
    console.print(f"    Command:     {entry.command}")

    if entry.description:
        console.print(f"    Description: {entry.description}")

    scope_file = _get_source_file(entry.source, project_root)
    console.print(f"    Source:      {scope_file} ({entry.source})")

    if entry.working_dir:
        console.print(f"    Working dir: {entry.working_dir}")

    # Show template variables used
    import re
    variables = re.findall(r"\{(\w+)\}", entry.command)
    if variables:
        console.print(f"    Variables:   {', '.join('{' + v + '}' for v in variables)}")

    console.print(f"\n    [dim]Usage: {cli_name} {name} [extra args...][/]\n")


def _get_source_file(source: str, project_root: str) -> str:
    """Return the file path for a given source scope."""
    from sdk.engine.alias_loader import get_alias_file_path
    return str(get_alias_file_path("global" if source == "user" else "project", project_root))


# ── rr alias remove ──────────────────────────────────────────────


@alias_group.command(name="remove")
@click.argument("name")
@click.option("--global", "is_global", is_flag=True, help="Remove from user scope instead of project.")
def alias_remove(name, is_global):
    """Remove an alias."""
    from sdk.engine.alias_loader import remove_alias

    scope = "global" if is_global else "project"
    project_root = _get_project_root()

    removed = remove_alias(name, scope=scope, project_root=project_root)
    if removed:
        scope_label = "user" if is_global else "project"
        console.print(f"  [yellow]Removed alias '{name}'[/] from {scope_label} scope.")
    else:
        console.print(f"  [dim]Alias '{name}' not found in {'user' if is_global else 'project'} scope.[/]")


# ── rr alias edit ─────────────────────────────────────────────────


@alias_group.command(name="edit")
@click.option("--global", "is_global", is_flag=True, help="Edit user-scope aliases instead of project.")
def alias_edit(is_global):
    """Open the alias file in $EDITOR."""
    import subprocess

    from sdk.engine.alias_loader import get_alias_file_path

    scope = "global" if is_global else "project"
    project_root = _get_project_root()
    file_path = get_alias_file_path(scope, project_root)

    # Create with template if doesn't exist
    if not file_path.exists():
        file_path.parent.mkdir(parents=True, exist_ok=True)
        with open(file_path, "w") as f:
            f.write(
                "# RouteRTL Aliases\n"
                "# See: rr alias create --help\n"
                "version: 1\n\n"
                "aliases:\n"
                "  # example:\n"
                '  #   command: "echo hello {project}"\n'
                '  #   description: "Example alias"\n'
            )

    editor = os.environ.get("EDITOR", os.environ.get("VISUAL", "vi"))
    console.print(f"  [dim]Opening {file_path} in {editor}...[/]")

    try:
        subprocess.run([editor, str(file_path)], check=False)
    except FileNotFoundError:
        console.print(f"  [red]Editor '{editor}' not found. Set $EDITOR.[/]")
        sys.exit(1)
