# SPDX-FileCopyrightText: 2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
BOM — FPGA Bill of Materials.

Generates a bill of materials from ip.lock showing every package,
version, commit, library, file count, and integrity status.
"""

import hashlib
import json
import os
import sys
import uuid
from datetime import datetime, timezone
from pathlib import Path

import rich_click as click
import yaml
from rich.console import Console
from rich.table import Table

from sdk.cli.resilience import cli_resilient

console = Console()


@cli_resilient("CLI name resolution", default="routertl")
def _cli_name():
    from sdk.cli.main import CLI_NAME

    return CLI_NAME


@click.command(name="bom")
@click.option("--export", "export_fmt",
              type=click.Choice(["json", "yaml", "cyclonedx", "spdx"]),
              default=None, help="Export format: json, yaml, cyclonedx (1.6), spdx (2.3).")
@click.option("--output", "-o", default=None, help="Write to file instead of stdout.")
def bom_command(export_fmt, output):
    """Generate an FPGA Bill of Materials from ip.lock.

    \b
    Shows every installed IP package with version, commit SHA, library,
    integrity status, and file count. The foundation for supply chain
    provenance and compliance reporting.

    \b
    Examples:
        rr bom                          # display in terminal
        rr bom --export json            # machine-readable JSON
        rr bom --export cyclonedx -o sbom.cdx.json   # CycloneDX 1.6
        rr bom --export spdx -o sbom.spdx.json       # SPDX 2.3
    """
    if not os.path.exists("project.yml"):
        console.print(f"[red]No project.yml found.[/] Run [cyan]{_cli_name()} init[/] first.")
        sys.exit(1)

    from sdk.engine.package_resolver import load_lock, verify_integrity

    lock = load_lock(Path.cwd())
    if not lock:
        console.print("  [dim]No packages in ip.lock — nothing to report.[/]")
        return

    # Load project metadata
    with open("project.yml") as f:
        config = yaml.safe_load(f) or {}
    project = config.get("project", {}) or {}
    hardware = config.get("hardware", {}) or {}
    build_opts = config.get("build_options", {}) or {}

    project_name = project.get("name", "unnamed")
    part = hardware.get("part", "—")
    vendor = hardware.get("vendor", "—")
    toolchain_ver = build_opts.get("tool_version", "—")

    # Run integrity verification
    integrity_results = verify_integrity(Path.cwd())
    integrity_map = {r["package"]: r for r in integrity_results}

    # Build BOM entries
    bom_entries = []
    total_files = 0
    for pkg_ref, entry in sorted(lock.items()):
        files = entry.get("files", [])
        file_count = len(files)
        total_files += file_count

        integrity = integrity_map.get(pkg_ref, {})
        integrity_status = integrity.get("status", "unknown")

        bom_entries.append({
            "package": pkg_ref,
            "version": entry.get("resolved_version", "—"),
            "commit": entry.get("commit", "—"),
            "library": entry.get("library", "work"),
            "source": entry.get("url", "—"),
            "files": file_count,
            "integrity": integrity_status,
        })

    # Export mode
    if export_fmt:
        now = datetime.now(timezone.utc)

        if export_fmt == "cyclonedx":
            text = json.dumps(
                _to_cyclonedx(project_name, bom_entries, lock, now), indent=2
            )
        elif export_fmt == "spdx":
            text = json.dumps(
                _to_spdx(project_name, bom_entries, lock, now), indent=2
            )
        else:
            bom_data = {
                "bom_version": "1.0",
                "generated": now.isoformat(),
                "project": {
                    "name": project_name,
                    "vendor": vendor,
                    "part": part,
                    "toolchain_version": toolchain_ver,
                },
                "packages": bom_entries,
                "summary": {
                    "total_packages": len(bom_entries),
                    "total_files": total_files,
                },
            }
            if export_fmt == "json":
                text = json.dumps(bom_data, indent=2)
            else:
                text = yaml.dump(bom_data, default_flow_style=False, sort_keys=False)

        if output:
            Path(output).write_text(text)
            console.print(f"  [green]BOM written to {output}[/] [dim]({export_fmt})[/]")
        else:
            click.echo(text)
        return

    # Rich terminal display
    console.print()
    console.print(
        f"  [bold cyan]FPGA Bill of Materials[/] — [bold]{project_name}[/]"
    )
    console.print(
        f"  [dim]Target: {part} ({vendor}, toolchain {toolchain_ver})[/]"
    )
    console.print(
        f"  [dim]Generated: {datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')}[/]"
    )
    console.print()

    table = Table(show_header=True, header_style="bold", box=None, padding=(0, 2))
    table.add_column("Package", style="cyan")
    table.add_column("Version")
    table.add_column("Commit", style="dim")
    table.add_column("Library")
    table.add_column("Files", justify="right")
    table.add_column("Integrity")

    for entry in bom_entries:
        commit_short = entry["commit"][:7] if len(entry["commit"]) > 7 else entry["commit"]

        if entry["integrity"] == "pass":
            integrity_display = "[green]✅ verified[/]"
        elif entry["integrity"] == "fail":
            integrity_display = "[red]❌ mismatch[/]"
        elif entry["integrity"] == "no_hashes":
            integrity_display = "[yellow]⚠ no hashes[/]"
        else:
            integrity_display = "[dim]unknown[/]"

        table.add_row(
            entry["package"],
            entry["version"],
            commit_short,
            entry["library"],
            str(entry["files"]),
            integrity_display,
        )

    console.print(table)
    console.print()
    console.print(
        f"  [dim]Total: {len(bom_entries)} package(s), {total_files} source file(s)[/]"
    )
    console.print()


# ── CycloneDX 1.6 ────────────────────────────────────────────────────────────


def _to_cyclonedx(project_name, bom_entries, lock, now):
    """Generate a CycloneDX 1.6 SBOM JSON document."""
    from routertl_core import __version__

    serial = f"urn:uuid:{uuid.uuid4()}"

    components = []
    for entry in bom_entries:
        pkg_ref = entry["package"]
        lock_entry = lock.get(pkg_ref, {})
        namespace, name = pkg_ref.split("/", 1) if "/" in pkg_ref else ("", pkg_ref)

        component = {
            "type": "library",
            "bom-ref": f"{pkg_ref}@{entry['version']}",
            "group": namespace,
            "name": name,
            "version": entry["version"],
        }

        # Hashes — aggregate all file hashes into a single package hash
        file_hashes = lock_entry.get("file_hashes", {})
        if file_hashes:
            # Deterministic package hash: sorted concat of all file hashes
            combined = "".join(v for _, v in sorted(file_hashes.items()))
            pkg_hash = hashlib.sha256(combined.encode()).hexdigest()
            component["hashes"] = [{"alg": "SHA-256", "content": pkg_hash}]

        # Source URL
        source_url = entry.get("source", "")
        if source_url and source_url != "—":
            component["externalReferences"] = [
                {"type": "vcs", "url": source_url}
            ]

        # Package URL
        commit = entry.get("commit", "")
        purl = f"pkg:generic/{namespace}/{name}@{entry['version']}"
        if commit and commit not in ("—", "unknown"):
            purl += f"?vcs_url={source_url}"
        component["purl"] = purl

        components.append(component)

    return {
        "$schema": "http://cyclonedx.org/schema/bom-1.6.schema.json",
        "bomFormat": "CycloneDX",
        "specVersion": "1.6",
        "serialNumber": serial,
        "version": 1,
        "metadata": {
            "timestamp": now.isoformat(),
            "tools": {
                "components": [
                    {
                        "type": "application",
                        "name": "routertl",
                        "version": __version__,
                    }
                ]
            },
            "component": {
                "type": "firmware",
                "bom-ref": project_name,
                "name": project_name,
            },
        },
        "components": components,
    }


# ── SPDX 2.3 ─────────────────────────────────────────────────────────────────


def _spdx_ref(name):
    """Create a valid SPDX identifier from a package name."""
    return "SPDXRef-" + name.replace("/", "-").replace(".", "-").replace("_", "-")


def _to_spdx(project_name, bom_entries, lock, now):
    """Generate an SPDX 2.3 SBOM JSON document."""
    from routertl_core import __version__

    doc_ns = f"https://routertl.dev/spdx/{project_name}-{uuid.uuid4()}"
    project_ref = _spdx_ref(project_name)

    # Root package (the FPGA project itself)
    packages = [
        {
            "name": project_name,
            "SPDXID": project_ref,
            "versionInfo": "0.0.0",
            "downloadLocation": "NOASSERTION",
            "filesAnalyzed": False,
            "primaryPackagePurpose": "FIRMWARE",
            "licenseConcluded": "NOASSERTION",
            "licenseDeclared": "NOASSERTION",
            "copyrightText": "NOASSERTION",
        }
    ]

    relationships = [
        {
            "spdxElementId": "SPDXRef-DOCUMENT",
            "relatedSpdxElement": project_ref,
            "relationshipType": "DESCRIBES",
        }
    ]

    for entry in bom_entries:
        pkg_ref = entry["package"]
        lock_entry = lock.get(pkg_ref, {})
        spdx_id = _spdx_ref(pkg_ref)

        # Download location
        source_url = entry.get("source", "")
        commit = entry.get("commit", "")
        if source_url and source_url != "—":
            dl = f"git+{source_url}"
            if commit and commit not in ("—", "unknown"):
                dl += f"@{commit}"
        else:
            dl = "NOASSERTION"

        pkg = {
            "name": pkg_ref,
            "SPDXID": spdx_id,
            "versionInfo": entry["version"],
            "downloadLocation": dl,
            "filesAnalyzed": False,
            "primaryPackagePurpose": "LIBRARY",
            "licenseConcluded": "NOASSERTION",
            "licenseDeclared": "NOASSERTION",
            "copyrightText": "NOASSERTION",
        }

        # Checksums
        file_hashes = lock_entry.get("file_hashes", {})
        if file_hashes:
            combined = "".join(v for _, v in sorted(file_hashes.items()))
            pkg_hash = hashlib.sha256(combined.encode()).hexdigest()
            pkg["checksums"] = [
                {"algorithm": "SHA256", "checksumValue": pkg_hash}
            ]

        # External ref (purl)
        namespace, name = pkg_ref.split("/", 1) if "/" in pkg_ref else ("", pkg_ref)
        pkg["externalRefs"] = [
            {
                "referenceCategory": "PACKAGE-MANAGER",
                "referenceType": "purl",
                "referenceLocator": f"pkg:generic/{namespace}/{name}@{entry['version']}",
            }
        ]

        packages.append(pkg)
        relationships.append({
            "spdxElementId": project_ref,
            "relatedSpdxElement": spdx_id,
            "relationshipType": "DEPENDS_ON",
        })

    return {
        "spdxVersion": "SPDX-2.3",
        "dataLicense": "CC0-1.0",
        "SPDXID": "SPDXRef-DOCUMENT",
        "name": f"{project_name}-sbom",
        "documentNamespace": doc_ns,
        "creationInfo": {
            "created": now.strftime("%Y-%m-%dT%H:%M:%SZ"),
            "creators": [f"Tool: routertl-{__version__}"],
        },
        "documentDescribes": [project_ref],
        "packages": packages,
        "relationships": relationships,
    }
