# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""``rr telemetry`` — manage local telemetry data.

Subcommands::

    rr telemetry status   Show a summary of collected data
    rr telemetry push     Export JSON for the dashboard
    rr telemetry clear    Wipe local telemetry database
"""

from __future__ import annotations

import json

import rich_click as click
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from sdk.cli.console import console
from sdk.cli.resilience import cli_resilient_block


@click.group(name="telemetry")
def telemetry_group():
    """Manage local SDK telemetry data."""


@telemetry_group.command()
def status():
    """Show a summary of collected telemetry data."""
    with cli_resilient_block("telemetry status"):
        from sdk.telemetry.store import TelemetryStore

        store = TelemetryStore()
        summary = store.summary()
        store.close()

        # Header
        header = Text()
        header.append("📊 Telemetry Summary", style="bold cyan")
        console.print(Panel(header, border_style="cyan", padding=(0, 1)))
        console.print()

        console.print(f"  [dim]Database:[/dim]  {summary['db_path']}")
        console.print(f"  [dim]Total CLI events:[/dim]  [bold]{summary['total_events']}[/bold]")
        console.print(f"  [dim]Total test results:[/dim]  [bold]{summary['total_test_results']}[/bold]")
        console.print()

        if summary["top_commands"]:
            table = Table(show_header=True, box=None, padding=(0, 2))
            table.add_column("Command", style="bold cyan", min_width=18)
            table.add_column("Invocations", style="bold", justify="right")
            for cmd, count in summary["top_commands"].items():
                table.add_row(cmd, str(count))

            console.print(
                Panel(
                    table,
                    title="[bold]Top Commands[/bold]",
                    title_align="left",
                    border_style="bright_black",
                    padding=(0, 1),
                )
            )
        else:
            console.print("  [dim]No events recorded yet. Run some rr commands![/dim]")


@telemetry_group.command()
@click.option("--since", default=None, help="Start date (YYYY-MM-DD). Defaults to 30 days ago.")
@click.option("--until", default=None, help="End date (YYYY-MM-DD). Defaults to today.")
@click.option("--output", "-o", default=None, help="Output file path. Defaults to stdout.")
def push(since, until, output):
    """Export telemetry data as JSON for the dashboard."""
    from datetime import datetime, timedelta, timezone

    with cli_resilient_block("telemetry push"):
        from sdk.telemetry.store import TelemetryStore

        # Parse date range
        until_dt = datetime.fromisoformat(until) if until else datetime.now(timezone.utc)
        since_dt = datetime.fromisoformat(since) if since else until_dt - timedelta(days=30)

        store = TelemetryStore()
        data = store.export_json(since=since_dt, until=until_dt)
        store.close()

        parsed = json.loads(data)
        event_count = len(parsed.get("events", []))
        test_count = len(parsed.get("test_results", []))

        if output:
            with open(output, "w") as f:
                f.write(data)
            console.print(f"  ✅ Exported [bold]{event_count}[/bold] events + [bold]{test_count}[/bold] test results → [cyan]{output}[/cyan]")
        else:
            click.echo(data)


@telemetry_group.command()
@click.confirmation_option(prompt="⚠️  This will delete all local telemetry data. Continue?")
def clear():
    """Wipe the local telemetry database."""
    import os
    from pathlib import Path

    with cli_resilient_block("telemetry clear"):
        db_path = Path.home() / ".routertl" / "telemetry.db"
        if db_path.exists():
            os.remove(db_path)
            console.print("  ✅ [green]Telemetry database cleared.[/green]")
        else:
            console.print("  [dim]No telemetry database found.[/dim]")
