# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""CLI command group: program — FPGA bitstream and software deployment."""

import subprocess
import sys
from pathlib import Path

import rich_click as click

from sdk.cli.console import console


def _load_programming_config():
    """Load programming section from project.yml."""
    from sdk.cli.project_config import load_project_config

    yml_path = Path("project.yml")
    if not yml_path.exists():
        return {}
    config = load_project_config()
    return config.get("programming", {})


def _get_vendor():
    """Resolve the vendor string from project.yml."""
    from sdk.cli.project_config import load_project_config

    yml_path = Path("project.yml")
    if not yml_path.exists():
        return "altera"
    config = load_project_config()
    return config.get("hardware", {}).get("vendor", "altera")


@click.group(name="program", invoke_without_command=True)
@click.pass_context
def program_group(ctx):
    """FPGA Hardware Deployment (Bitstream + Software).

    When invoked without a subcommand, runs the full deployment flow.
    Use subcommands for finer control: run, cables, verify.
    """
    if ctx.invoked_subcommand is None:
        ctx.invoke(program_run)


@program_group.command(name="run")
@click.option("--bitstream", "-b", help="Path to bitstream file (.sof, .bit, .bin).")
@click.option("--software", "-s", help="Path to software ELF file.")
@click.option("--cable", "-c", help="JTAG cable ID or name.")
@click.option("--reset", "-r", is_flag=True, help="Trigger system reset after programming.")
@click.option(
    "--eval-accept", is_flag=True,
    help="Auto-dismiss eval IP time-limited license prompt (Quartus only).",
)
def program_run(bitstream, software, cable, reset, eval_accept):
    """Deploy bitstream and software to the connected hardware.

    With --eval-accept, auto-dismisses the interactive eval IP prompt
    that blocks non-interactive quartus_pgm use. Common for designs
    with time-limited Intel IP evaluation licenses.
    """
    config = _load_programming_config()

    # Resolve arguments (CLI args > project.yml > discovery)
    bitstream = bitstream or config.get("bitstream")
    software = software or config.get("software")
    cable = cable or config.get("cable")
    eval_accept = eval_accept or config.get("eval_accept", False)

    console.print("🚀 [blue]Starting hardware deployment...[/]")

    if eval_accept:
        console.print("   [dim]--eval-accept: will auto-dismiss eval IP prompt[/]")

    try:
        from sdk.cli.vendor_dispatch import VendorDispatch, VendorToolNotFound

        dispatch = VendorDispatch.from_project()

        # 0. Pre-program hooks
        try:
            from sdk.cli.engine_dispatch import run_engine_script
            from sdk.cli.resilience import cli_resilient_block
            with cli_resilient_block("pre-program hooks"):
                run_engine_script("run_hooks.py", ["--stage", "pre_program", "--project", "project.yml", "--root", "."])
        except (ImportError, Exception):
            pass

        # 1. Program Bitstream
        rc = dispatch.program(bitstream=bitstream, cable=cable, eval_accept=eval_accept)
        if rc != 0:
            console.print("❌ [red]Bitstream programming failed.[/]")
            sys.exit(rc)

        # 2. Program Software (if requested)
        if software:
            console.print(f"📥 [blue]Downloading software: [cyan]{software}[/]...[/]")
            # Note: software_program() needs to be implemented in VendorDispatch
            if hasattr(dispatch, "software_program"):
                rc = dispatch.software_program(software=software, cable=cable)
                if rc != 0:
                    console.print("❌ [red]Software download failed.[/]")
                    sys.exit(rc)
            else:
                console.print("⚠️  [yellow]Software download not yet supported for this vendor.[/]")

        if reset:
            console.print("⚠️  [yellow]--reset is not yet implemented. "
                          "Use vendor tools directly (e.g. jtagconfig, "
                          "Vivado HW Manager) for JTAG reset.[/]")

        # Post-program hooks
        try:
            from sdk.cli.engine_dispatch import run_engine_script
            from sdk.cli.resilience import cli_resilient_block
            with cli_resilient_block("post-program hooks"):
                run_engine_script("run_hooks.py", ["--stage", "post_program", "--project", "project.yml", "--root", "."])
        except (ImportError, Exception):
            pass

        console.print("\n✅ [green]Hardware deployment successful![/]")

    except (ImportError, VendorToolNotFound) as e:
        console.print(f"❌ [red]Vendor tool dispatch failed:[/] {e}")
        sys.exit(1)


@program_group.command(name="cables")
def list_cables():
    """List connected JTAG cables and scan device chain.

    Discovers JTAG cables via vendor tools (jtagconfig for Altera,
    Vivado HW Manager for Xilinx) and displays device IDs and
    chain positions.
    """
    from rich.table import Table

    from sdk.cli.jtag import scan_jtag_chain

    vendor = _get_vendor()
    console.print(f"🔍 [blue]Scanning for JTAG cables ({vendor})...[/]\n")

    cables = scan_jtag_chain(vendor)

    if not cables:
        console.print("  [yellow]No JTAG cables found.[/]")
        console.print("  [dim]Ensure your programmer is plugged in and vendor tools are on PATH.[/]")
        return

    table = Table(
        title="JTAG Chain",
        title_style="bold",
        show_lines=False,
        padding=(0, 1),
    )
    table.add_column("#", style="dim", min_width=3)
    table.add_column("Cable", style="bold cyan", min_width=30)
    table.add_column("Pos", justify="center", min_width=4)
    table.add_column("IDCODE", style="bold", min_width=12)
    table.add_column("Device", min_width=20)

    for cable in cables:
        if not cable.devices:
            table.add_row(str(cable.index), cable.name, "—", "—", "[dim]no devices[/]")
        for i, dev in enumerate(cable.devices):
            cable_col = cable.name if i == 0 else ""
            idx_col = str(cable.index) if i == 0 else ""
            table.add_row(idx_col, cable_col, str(dev.position), dev.idcode, dev.name)

    console.print(table)

    total_devs = sum(len(c.devices) for c in cables)
    console.print(f"\n  [dim]{len(cables)} cable(s), {total_devs} device(s)[/]")


@program_group.command(name="verify")
@click.option("--bitstream", "-b", help="Bitstream to verify against.")
@click.option("--cable", "-c", help="JTAG cable ID or name.")
@click.option("--position", "-p", default=1, type=int, show_default=True,
              help="JTAG chain position (for multi-device chains).")
def verify(bitstream, cable, position):
    """Verify programmed bitstream matches local file.

    Compares the bitstream currently loaded in SRAM against the
    specified local file. Useful to confirm successful programming
    before running tests.
    """
    config = _load_programming_config()
    vendor = _get_vendor()

    bitstream = bitstream or config.get("bitstream")
    cable = cable or config.get("cable")

    if not bitstream:
        console.print("❌ [red]No bitstream specified.[/]")
        console.print("   [dim]Use --bitstream <path> or set programming.bitstream in project.yml[/]")
        sys.exit(1)

    if not Path(bitstream).exists():
        console.print(f"❌ [red]Bitstream file not found:[/] {bitstream}")
        sys.exit(1)

    console.print(f"🛡️  [blue]Verifying programmed bitstream ({vendor})...[/]")
    console.print(f"   [dim]File: {bitstream}[/]")
    console.print(f"   [dim]Position: @{position}[/]")

    if vendor == "altera":
        rc = _verify_altera(bitstream, cable, position)
    elif vendor == "xilinx":
        rc = _verify_xilinx(bitstream, cable)
    else:
        console.print(f"⚠️  [yellow]Verification not yet supported for vendor: {vendor}[/]")
        return

    if rc == 0:
        console.print("\n✅ [green]Verification successful — bitstream matches.[/]")
    else:
        console.print("\n❌ [red]Verification FAILED — bitstream mismatch or read error.[/]")
        sys.exit(rc)


def _verify_altera(bitstream, cable, position):
    """Verify via quartus_pgm verify mode."""
    import shutil

    pgm = shutil.which("quartus_pgm")
    if not pgm:
        console.print("❌ [red]quartus_pgm not found on PATH.[/]")
        return 1

    cable_arg = cable or "1"
    cmd = [pgm, "-c", str(cable_arg), "-m", "jtag", "-o", f"v;{bitstream}@{position}"]
    console.print(f"   [dim]→ {' '.join(cmd[:5])}…[/]")

    try:
        result = subprocess.run(cmd, check=False)
        return result.returncode
    except (FileNotFoundError, OSError) as e:
        console.print(f"❌ [red]Failed to run quartus_pgm:[/] {e}")
        return 1


def _verify_xilinx(bitstream, cable):
    """Verify via Vivado HW Manager verify_hw_devices."""
    try:
        from sdk.cli.vendor_dispatch import VendorDispatch, VendorToolNotFound

        dispatch = VendorDispatch.from_project()
        tcl = Path(dispatch.tcl_root) / "verify_bitstream.tcl"
        if not tcl.exists():
            console.print(f"❌ [red]TCL script not found:[/] {tcl}")
            return 1
        return dispatch._run_tcl(tcl, str(Path.cwd()), bitstream or "", cable or "")
    except (ImportError, VendorToolNotFound) as e:
        console.print(f"❌ [red]Vendor tool dispatch failed:[/] {e}")
        return 1
