# SPDX-FileCopyrightText: 2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""rr rules — FPGA design rules engine.

Check IP configurations against design rules scoped by vendor, tool,
and tool version.  Capture new rules from incidents while the pain
is fresh.

RTL-P1.27, RTL-P1.28
"""

from __future__ import annotations

from pathlib import Path

import rich_click as click

from sdk.cli.console import console


@click.group(name="rules")
def rules_group():
    """FPGA design rules — check, add, and manage."""


@rules_group.command(name="check")
@click.option("--strict", is_flag=True, help="Treat warnings as errors.")
@click.option("--json", "as_json", is_flag=True, help="Machine-readable JSON output.")
def rules_check(strict: bool, as_json: bool):
    """Check project against design rules.

    Scans QSYS/Platform Designer output and IP manifests for dangerous
    property values, vendor mismatches, and known pitfalls.  Rules are
    scoped by vendor, tool, and tool version from routertl.lock.

    \b
    Example:
        rr rules check
        rr rules check --strict       # CI mode: warnings are errors
        rr rules check --json         # Machine-readable output
    """
    import json as _json

    from sdk.engine.ip_rules import (
        ToolchainContext,
        evaluate_condition,
        filter_rules,
        load_rules,
    )
    from sdk.engine.qsys_scanner import scan_project_qsys

    project_root = Path.cwd()

    # Load toolchain context from lockfile (if available)
    ctx = ToolchainContext()
    try:
        from sdk.engine.lockfile import load_lockfile

        lock = load_lockfile(project_root)
        tc = lock.get("toolchain", {})
        ctx.vendor = tc.get("vendor", "")
        ctx.tool = tc.get("tool", "")
        ctx.tool_version = tc.get("version", "")
        ctx.part = tc.get("part", "")
    except (FileNotFoundError, ImportError, KeyError):
        try:
            yml = project_root / "project.yml"
            if yml.exists():
                import yaml as _yaml

                with open(yml) as f:
                    config = _yaml.safe_load(f) or {}
                hw = config.get("hardware", {})
                ctx.vendor = hw.get("vendor", "")
                ctx.tool_version = config.get("build_options", {}).get(
                    "tool_version", ""
                )
        except (OSError, ValueError):
            pass

    if not as_json:
        console.print("🔍 [blue]Checking design rules...[/]")
        if ctx.vendor:
            console.print(
                f"   Toolchain: {ctx.vendor} {ctx.tool} {ctx.tool_version}"
            )

    # Load and filter rules
    rules = load_rules(project_root)
    applicable = filter_rules(rules, ctx)

    if not as_json:
        console.print(
            f"   Rules: {len(applicable)} applicable (of {len(rules)} total)"
        )

    # Scan QSYS interfaces
    scan = scan_project_qsys(project_root)

    # Evaluate rules against scanned data
    matches = []

    for rule in applicable:
        if not rule.property:
            continue

        # Check against QSYS interface properties
        for iface in scan.interfaces:
            if rule.property in iface.properties:
                actual = iface.properties[rule.property]
                if evaluate_condition(actual, rule.condition):
                    matches.append({
                        "rule": rule.id,
                        "severity": rule.severity,
                        "message": rule.message,
                        "context": f"{iface.component}.{iface.name}",
                        "property": rule.property,
                        "condition": rule.condition,
                        "actual": actual,
                        "fix": rule.fix,
                        "incident": rule.incident,
                        "source": rule.source,
                    })

        # Check against component parameters
        for comp in scan.components:
            if rule.property in comp.parameters:
                actual = comp.parameters[rule.property]
                if evaluate_condition(actual, rule.condition):
                    matches.append({
                        "rule": rule.id,
                        "severity": rule.severity,
                        "message": rule.message,
                        "context": comp.name,
                        "property": rule.property,
                        "condition": rule.condition,
                        "actual": actual,
                        "fix": rule.fix,
                        "incident": rule.incident,
                        "source": rule.source,
                    })

    # Compute summary
    n_errors = sum(1 for m in matches if m["severity"] == "error")
    n_warnings = sum(1 for m in matches if m["severity"] == "warning")
    n_info = sum(1 for m in matches if m["severity"] == "info")
    has_errors = n_errors > 0
    has_warnings = n_warnings > 0
    would_fail = has_errors or (strict and has_warnings)

    # Output
    if as_json:
        result = {
            "toolchain": {
                "vendor": ctx.vendor,
                "tool": ctx.tool,
                "tool_version": ctx.tool_version,
                "part": ctx.part,
                "family": getattr(ctx, "family", ""),
            },
            "rules_total": len(rules),
            "rules_applicable": len(applicable),
            "matches": matches,
            "summary": {
                "total": len(matches),
                "errors": n_errors,
                "warnings": n_warnings,
                "info": n_info,
            },
            "status": "fail" if would_fail else (
                "warn" if has_warnings else "pass"
            ),
            "strict": strict,
        }
        click.echo(_json.dumps(result, indent=2))
    else:
        if not matches:
            console.print("\n✅ [green]No issues found.[/]")
        else:
            console.print()

            for m in matches:
                sev = m["severity"].upper()
                icon = (
                    "❌" if sev == "ERROR"
                    else "⚠️" if sev == "WARNING"
                    else "ℹ️"
                )
                color = (
                    "red" if sev == "ERROR"
                    else "yellow" if sev == "WARNING"
                    else "blue"
                )
                console.print(f"  {icon} [{color}]{m['rule']}[/] ({m['context']})")
                console.print(f"     {m['message'].strip()}")
                if m["fix"]:
                    console.print(f"     [dim]Fix: {m['fix'].strip()}[/]")
                console.print()

            console.print(f"  {n_errors} error(s), {n_warnings} warning(s)")

            console.print()
            console.print(
                "  [dim]Found a new pitfall? Capture it while the pain is fresh:[/]"
            )
            console.print("    [cyan]rr rules add --from-incident[/]")

    # Exit code
    if would_fail:
        raise SystemExit(2 if has_errors else 1)


@rules_group.command(name="add")
@click.option(
    "--from-incident", is_flag=True,
    help="Interactive: capture a rule from a bug you just hit.",
)
@click.option("--id", "rule_id", default=None, help="Rule ID (e.g., CUSTOM-001).")
@click.option(
    "--severity",
    type=click.Choice(["error", "warning", "info"]),
    default="warning",
    help="Rule severity: error (blocks build), warning (flags risk), info (best practice).",
)
@click.option("--message", default=None, help="What the rule checks for.")
@click.option("--property", "prop", default=None, help="Property name to check.")
@click.option(
    "--condition", default=None,
    help='Condition (e.g., "== 0", "missing").',
)
@click.option(
    "--incident", default=None,
    help="The bug story that inspired this rule.",
)
@click.option("--fix", default=None, help="How to fix it.")
@click.option(
    "--part", "part", multiple=True,
    help="Exact device part(s) this rule applies to (repeatable). "
         "e.g. --part 10AX115S2F45I1SG. Omit for family-level scoping.",
)
@click.option(
    "--ip", "ip_name", default=None,
    help="IP component name (glob). Required if --ip-version is set.",
)
@click.option(
    "--ip-version", "ip_version", multiple=True,
    help="Exact IP version(s) this rule applies to (repeatable). "
         "Only valid when --ip is set.",
)
def rules_add(
    from_incident: bool,
    rule_id: str | None,
    severity: str,
    message: str | None,
    prop: str | None,
    condition: str | None,
    incident: str | None,
    fix: str | None,
    part: tuple[str, ...],
    ip_name: str | None,
    ip_version: tuple[str, ...],
):
    """Add a design rule to your project's ip_rules.yml.

    Use --from-incident to capture a rule interactively right after
    hitting a bug — while the pain is fresh.

    \b
    Example:
        rr rules add --from-incident
        rr rules add --id CUSTOM-001 --property readLatency --condition "== 0" \\
            --message "Zero read latency causes timing issues" \\
            --incident "Hit this on the sensor board, took 2 days to find"
    """
    import yaml as _yaml

    rules_file = Path("ip_rules.yml")

    if from_incident:
        console.print("📝 [blue]Capture a design rule from a bug you just hit.[/]")
        console.print()
        if not rule_id:
            rule_id = click.prompt("  Rule ID (e.g., CUSTOM-001)")
        if not message:
            message = click.prompt("  What does this rule check for?")
        if not prop:
            prop = click.prompt(
                "  Property name to check (or 'none')", default="none"
            )
            if prop == "none":
                prop = ""
        if not condition:
            condition = click.prompt(
                "  Condition (e.g., '== 0', 'missing')", default=""
            )
        if not incident:
            incident = click.prompt("  What happened? (the bug story)")
        if not fix:
            fix = click.prompt("  How to fix it?", default="")

    if not rule_id or not message or not incident:
        console.print(
            "❌ [red]Rule needs at least: --id, --message, --incident[/]"
        )
        raise SystemExit(1)

    if ip_version and not ip_name:
        console.print(
            "❌ [red]--ip-version requires --ip to be set[/]"
        )
        raise SystemExit(1)

    # Build rule entry
    rule_entry: dict = {
        "id": rule_id,
        "severity": severity,
        "message": message,
        "incident": incident,
    }
    if prop:
        rule_entry["property"] = prop
    if condition:
        rule_entry["condition"] = condition
    if fix:
        rule_entry["fix"] = fix
    if part:
        rule_entry["part"] = list(part)
    if ip_name:
        rule_entry["ip"] = ip_name
    if ip_version:
        rule_entry["ip_version"] = list(ip_version)

    # Load or create ip_rules.yml
    if rules_file.exists():
        with open(rules_file) as f:
            data = _yaml.safe_load(f) or {}
    else:
        data = {}

    rules_list = data.setdefault("rules", [])
    rules_list.append(rule_entry)

    with open(rules_file, "w") as f:
        _yaml.dump(
            data, f, default_flow_style=False, sort_keys=False, allow_unicode=True
        )

    console.print(f"\n✅ Added [green]{rule_id}[/] to {rules_file}")
    console.print(
        "   [dim]This rule will be checked on every 'rr rules check' run.[/]"
    )


@rules_group.command(name="list")
@click.option("--json", "as_json", is_flag=True, help="Machine-readable JSON output.")
def rules_list(as_json: bool):
    """List all active rules (built-in + project-local)."""
    import json as _json

    from sdk.engine.ip_rules import load_rules

    project_root = Path.cwd()
    rules = load_rules(project_root)

    if as_json:
        result = {
            "rules": [
                {
                    "id": r.id,
                    "severity": r.severity,
                    "message": r.message,
                    "incident": r.incident,
                    "vendor": r.vendor,
                    "tool": r.tool,
                    "tool_version": r.tool_version,
                    "family": r.family,
                    "ip": r.ip,
                    "property": r.property,
                    "condition": r.condition,
                    "fix": r.fix,
                    "source": r.source,
                }
                for r in rules
            ],
            "count": len(rules),
        }
        click.echo(_json.dumps(result, indent=2))
        return

    if not rules:
        console.print("[dim]No rules loaded.[/]")
        return

    console.print(f"[bold]{len(rules)} rule(s) loaded[/]\n")

    for rule in rules:
        sev_color = {
            "error": "red", "warning": "yellow", "info": "blue"
        }.get(rule.severity, "white")

        console.print(
            f"  [{sev_color}]{rule.id}[/] [{sev_color}]{rule.severity.upper()}[/]"
            f"  [dim]({rule.source})[/]"
        )
        console.print(f"     {rule.message.strip()[:80]}")
        if rule.vendor or rule.tool:
            scope = " ".join(
                filter(None, [rule.vendor, rule.tool, rule.tool_version])
            )
            console.print(f"     [dim]Scope: {scope}[/]")
        console.print()
