# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""CLI command: ci — CI/CD pipeline management."""

import sys
from pathlib import Path

import rich_click as click

from sdk.cli.console import console


@click.group(name="ci")
def ci_group():
    """CI/CD pipeline management."""


@ci_group.command()
@click.option(
    "--provider",
    type=click.Choice(["github", "gitlab"]),
    required=True,
    help="CI provider (github or gitlab).",
)
@click.option(
    "--sim-engine",
    default=None,
    help="Simulation engine override (default: from project.yml or 'nvc').",
)
@click.option(
    "--synth",
    is_flag=True,
    help="Include synthesis stage (nightly/tag trigger).",
)
def generate(provider, sim_engine, synth):
    """Generate a CI/CD pipeline config for your project."""
    from jinja2 import Environment, FileSystemLoader

    # ── Load project.yml ─────────────────────────────────────
    project_yml = Path("project.yml")
    if not project_yml.exists():
        console.print(
            "❌ [red]No project.yml found in the current directory.[/]\n"
            "   Run [bold cyan]rr init[/] to create one first."
        )
        sys.exit(1)

    from sdk.cli.project_config import load_project_config

    config = load_project_config()

    project_name = config.get("project", {}).get("name", "my_project")
    docker_tag = config.get("docker", {}).get("tag", "3.0")

    # Sim engine priority: CLI flag > project.yml > default
    if sim_engine is None:
        sim_engine = config.get("simulation", {}).get("engine", "nvc")

    # ── Resolve template ─────────────────────────────────────
    templates_dir = Path(__file__).parent.parent.parent / "infra" / "ci" / "templates"
    template_map = {
        "github": "github_actions.yml.j2",
        "gitlab": "gitlab_ci.yml.j2",
    }
    output_map = {
        "github": Path(".github") / "workflows" / "routertl.yml",
        "gitlab": Path(".gitlab-ci.yml"),
    }

    template_name = template_map[provider]
    output_path = output_map[provider]

    env = Environment(
        loader=FileSystemLoader(str(templates_dir)),
        keep_trailing_newline=True,
    )
    template = env.get_template(template_name)

    # ── Render ───────────────────────────────────────────────
    rendered = template.render(
        project_name=project_name,
        sim_engine=sim_engine,
        docker_tag=docker_tag,
        include_synth=synth,
    )

    # ── Write output ─────────────────────────────────────────
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(rendered)

    # ── Summary ──────────────────────────────────────────────
    provider_label = "GitHub Actions" if provider == "github" else "GitLab CI"
    console.print(f"\n✅ [green]{provider_label} pipeline generated:[/] [cyan]{output_path}[/]")
    console.print(f"   Project:    [bold]{project_name}[/]")
    console.print(f"   Sim engine: [bold]{sim_engine}[/]")
    console.print(f"   Docker:     [bold]routertl/dev:{docker_tag}[/]")

    stages = ["lint", "sim"]
    if synth:
        stages.append("synth")
    console.print(f"   Stages:     [bold]{' → '.join(stages)}[/]\n")
