# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""CLI command: target — Multi-project workspace management.

Switch between different project configurations stored in ``targets/``.

Usage::

    rr target                  # show current active target
    rr target list             # discover available targets
    rr target set <name>       # switch to a target
    rr target reset            # revert to self-contained project.yml
"""

from __future__ import annotations

import sys
from pathlib import Path

import rich_click as click
import yaml

from sdk.cli.console import console
from sdk.cli.project_config import (
    discover_targets,
    get_active_target,
    load_project_config,
    resolve_target_path,
)
from sdk.cli.resilience import cli_resilient, cli_resilient_block


@cli_resilient("CLI name resolution", default="routertl")
def _cli_name():
    from sdk.cli.main import CLI_NAME

    return CLI_NAME


# RTL-P2.418: shell completion for target NAME arguments.  Same
# pattern as sim.py::_complete_testbench — discover targets/*.yml
# stems and return matches for the incomplete prefix.
def _complete_target_name(ctx, param, incomplete):
    """Click shell-completion callback: names of known targets."""
    import os
    search_dir = os.environ.get("RR_TARGETS_DIR", "targets")
    try:
        targets = discover_targets(search_dir)
    except (OSError, ValueError):
        return []
    return sorted(
        t["name"] for t in targets
        if t.get("name", "").startswith(incomplete)
    )


# ── Auto-generated pointer header ─────────────────────────────────
_POINTER_TEMPLATE = """\
# Managed by RouteRTL — do not edit manually.
# To modify project settings, edit: {target_path}
# To switch targets: {cli} target set <name>
target: {target_path}
"""


@click.group(name="target", invoke_without_command=True)
@click.pass_context
def target_group(ctx):
    """Multi-project workspace management.

    Switch between different project configurations stored in targets/.
    Run without a subcommand to show the current active target.

    Examples:
        rr target                  Show current target
        rr target list             List available targets
        rr target set devkit       Switch to targets/devkit.yml
        rr target reset            Inline target back to project.yml
    """
    if ctx.invoked_subcommand is None:
        _show_current()


def _show_current():
    """Display the current active target."""
    from rich.panel import Panel
    from rich.text import Text

    target = get_active_target()
    if target is None:
        content = Text()
        content.append("📋 ", style="bold")
        content.append("project.yml", style="bold cyan")
        content.append(" — self-contained (no target pointer)", style="dim")
        console.print(Panel(content, border_style="bright_black", padding=(0, 1)))
    else:
        content = Text()
        content.append("🎯 ", style="bold")
        content.append("Active target: ", style="dim")
        content.append(target, style="bold cyan")

        # Try to read the target's project name
        with cli_resilient_block("target name resolution"):
            config = load_project_config()
            name = config.get("project", {}).get("name", "")
            if name:
                content.append(f"  ({name})", style="dim")

        console.print(Panel(content, border_style="cyan", padding=(0, 1)))


_BITSTREAM_EXTS = (
    # Xilinx
    ".bit", ".ltx", ".xsa",
    # Altera / Intel
    ".sof", ".pof", ".rbf", ".jic",
    # Lattice / Microchip fall through to "any file stem-matches"
)
_OUTPUT_DIRS = ("bitstream", "build", "dcp", "project")


def _last_build_mtime(target_name: str) -> float | None:
    """Return the newest mtime of any build artefact whose stem matches
    ``target_name``, or None when nothing has been built.

    Probes a small set of known output directories (bitstream/, build/,
    dcp/, project/) for files whose stem starts with ``target_name``
    and whose extension is in the known-bitstream set.  Best-effort —
    RTL-P2.354 will eventually normalise output layout; until then
    this is conservative but good enough to surface "never built" vs
    "built recently".
    """
    newest: float | None = None
    for d in _OUTPUT_DIRS:
        dp = Path(d)
        if not dp.is_dir():
            continue
        for candidate in dp.glob(f"{target_name}*"):
            if not candidate.is_file():
                continue
            if candidate.suffix.lower() not in _BITSTREAM_EXTS:
                continue
            try:
                m = candidate.stat().st_mtime
            except OSError:
                continue
            if newest is None or m > newest:
                newest = m
    return newest


def _format_build_age(mtime: float | None) -> str:
    """Render a build mtime as a colour-coded "Last Build" cell."""
    if mtime is None:
        return "[dim]— never[/dim]"
    import time
    age = time.time() - mtime
    stamp = time.strftime("%Y-%m-%d", time.localtime(mtime))
    if age < 24 * 3600:
        return f"[green]✓ today[/green] [dim]{stamp}[/dim]"
    if age < 7 * 24 * 3600:
        days = int(age // (24 * 3600))
        return f"[green]✓ {days}d ago[/green] [dim]{stamp}[/dim]"
    if age < 30 * 24 * 3600:
        days = int(age // (24 * 3600))
        return f"[yellow]{days}d ago[/yellow] [dim]{stamp}[/dim]"
    return f"[dim]old — {stamp}[/dim]"


def _source_count(cfg: dict) -> int:
    """Return the total number of declared source files in a target cfg."""
    total = 0
    srcs = cfg.get("sources", {}) if isinstance(cfg, dict) else {}
    if isinstance(srcs, dict):
        for key in ("syn", "sim", "xdc", "ip_paths", "constraints"):
            val = srcs.get(key)
            if isinstance(val, list):
                total += len(val)
    return total


@target_group.command(name="list")
@click.option(
    "--dir",
    "search_dir",
    default="targets",
    help="Directory to scan for targets (default: targets/).",
    show_default=True,
)
@click.option(
    "--json", "as_json",
    is_flag=True,
    default=False,
    help="Emit machine-readable JSON (array of target objects) — no "
         "Rich decoration, no banner.  Useful for scripts and MCP "
         "integration (RTL-P2.419).",
)
def target_list(search_dir, as_json):
    """List available project targets.

    Discovers both flat files (targets/name.yml) and directory layouts
    (targets/name/project.yml) within the search directory.  The table
    surfaces each target's top module, source count, last-build
    timestamp, and (when present) a one-line description — enough to
    answer "what targets exist, which one am I on, which ones build,
    and what's each for" without grepping the yml files (RTL-P3.168).
    """
    from rich.table import Table

    targets = discover_targets(search_dir)
    current = get_active_target()

    if as_json:
        # RTL-P2.419: structured output.  Emit exit 0 with "[]" when no
        # targets are found — scripts handle empty lists natively.
        import json as _json
        payload: list[dict] = []
        for t in targets:
            cfg = t["config"] if isinstance(t["config"], dict) else {}
            hw = cfg.get("hardware") or {}
            proj = cfg.get("project") or {}
            hw = hw if isinstance(hw, dict) else {}
            proj = proj if isinstance(proj, dict) else {}
            payload.append({
                "name": t["name"],
                "path": t["path"],
                "active": bool(current is not None and t["path"] == current),
                "vendor": hw.get("vendor"),
                "part": hw.get("part"),
                "top_module": proj.get("top_module") or proj.get("top"),
                "output_dir": proj.get("output_dir"),
                "sources_count": _source_count(cfg),
                "last_build_mtime": _last_build_mtime(t["name"]),
                "description": (proj.get("description") or "").strip() or None,
            })
        click.echo(_json.dumps(payload, indent=2))
        return

    if not targets:
        console.print(f"  [dim]No targets found in [cyan]{search_dir}/[/cyan][/dim]")
        console.print(f"  [dim]Create a target: mkdir -p {search_dir} && "
                       f"cp project.yml {search_dir}/my_board.yml[/dim]")
        return

    # Only show the Description column when at least one target has one —
    # avoids a column of "—"s that buys nothing.
    any_description = any(
        isinstance(t["config"], dict)
        and isinstance(t["config"].get("project"), dict)
        and (t["config"]["project"].get("description") or "").strip()
        for t in targets
    )

    table = Table(
        title=f"🎯 Available Targets ({search_dir}/)",
        title_style="bold",
        show_lines=False,
        padding=(0, 1),
    )
    # RTL-P2.412: active marker sits immediately after Name so users
    # can answer "which target am I on?" without eye-tracking across
    # the full row.  Prior column order had the marker in column 0
    # and the name in column 1 — physically adjacent but eye-scan
    # optics favour "name → status" over "status → name".
    table.add_column("Name", style="bold cyan", min_width=18)
    table.add_column("", justify="center", width=2)  # active marker
    table.add_column("Top Module", style="cyan", min_width=20)
    table.add_column("Vendor", min_width=8)
    table.add_column("Part", style="dim", min_width=20)
    table.add_column("Sources", justify="right", min_width=5)
    table.add_column("Last Build", min_width=18)
    if any_description:
        table.add_column("Description", style="dim", min_width=28, overflow="fold")

    for t in targets:
        cfg = t["config"] if isinstance(t["config"], dict) else {}
        hw = cfg.get("hardware") or {}
        proj = cfg.get("project") or {}
        hw = hw if isinstance(hw, dict) else {}
        proj = proj if isinstance(proj, dict) else {}

        vendor = hw.get("vendor", "—")
        part = hw.get("part", "—")
        top = proj.get("top_module") or proj.get("top") or "—"
        sources = _source_count(cfg)
        last_build = _format_build_age(_last_build_mtime(t["name"]))

        is_active = current is not None and t["path"] == current
        marker = "[bold green]★[/]" if is_active else ""

        row = [
            t["name"],
            marker,
            top,
            vendor,
            part,
            str(sources) if sources else "[dim]—[/dim]",
            last_build,
        ]
        if any_description:
            desc = (proj.get("description") or "").strip() or "[dim]—[/dim]"
            row.append(desc)

        table.add_row(*row)

    console.print(table)
    console.print()


@target_group.command(name="show")
@click.argument("name", shell_complete=_complete_target_name)
@click.option(
    "--dir", "search_dir", default="targets", show_default=True,
    help="Directory holding target ymls.",
)
@click.option(
    "--raw", is_flag=True, default=False,
    help="Print the target yml contents verbatim (for piping).",
)
def target_show(name, search_dir, raw):
    """Pretty-print a target's config.

    \b
    Without --raw: structured panel (vendor, part, top module,
    output_dir, sources breakdown, description, active marker).
    With --raw: yml contents to stdout for piping / less / diff.
    """
    from rich.panel import Panel
    from rich.table import Table

    resolved = resolve_target_path(name, search_dir)
    if resolved is None:
        console.print(
            f"❌ [red]Target '{name}' not found in {search_dir}/[/]\n"
            f"   Run [cyan]{_cli_name()} target list[/] to see available targets."
        )
        sys.exit(1)

    if raw:
        click.echo(resolved.read_text(), nl=False)
        return

    try:
        cfg = yaml.safe_load(resolved.read_text()) or {}
    except yaml.YAMLError as exc:
        console.print(f"❌ [red]YAML error in {resolved}:[/] {exc}")
        sys.exit(1)
    if not isinstance(cfg, dict):
        cfg = {}

    hw = cfg.get("hardware") or {}
    proj = cfg.get("project") or {}
    srcs = cfg.get("sources") or {}
    if not isinstance(hw, dict):
        hw = {}
    if not isinstance(proj, dict):
        proj = {}
    if not isinstance(srcs, dict):
        srcs = {}

    current = get_active_target()
    is_active = current is not None and str(resolved) == current

    syn_n = len(srcs.get("syn") or [])
    sim_n = len(srcs.get("sim") or [])
    xdc_n = len(srcs.get("xdc") or [])
    ip_n = len(srcs.get("ip_paths") or [])
    total_n = syn_n + sim_n + xdc_n + ip_n

    t = Table.grid(padding=(0, 2))
    t.add_column(style="dim", justify="right")
    t.add_column()

    t.add_row("Target:", f"[cyan]{resolved}[/]")
    t.add_row(
        "Active:",
        "[bold green]yes ★[/]" if is_active else "[dim]no[/]",
    )
    t.add_row("Project name:", proj.get("name") or "[dim]—[/dim]")
    t.add_row("Top module:",
              proj.get("top_module") or proj.get("top") or "[dim]—[/dim]")
    t.add_row("Vendor:", hw.get("vendor") or "[dim]—[/dim]")
    t.add_row("Part:", hw.get("part") or "[dim]—[/dim]")
    t.add_row("Output dir:",
              proj.get("output_dir") or "[dim](flat layout — default)[/]")
    t.add_row(
        "Sources:",
        (f"[cyan]{total_n}[/] files  "
         f"[dim]({syn_n} syn, {sim_n} sim, {xdc_n} xdc, "
         f"{ip_n} ip_paths)[/]") if total_n
        else "[dim]—[/dim]",
    )
    desc = (proj.get("description") or "").strip()
    if desc:
        t.add_row("Description:", desc)

    console.print(
        Panel(
            t,
            title=f"🎯 {name}",
            border_style="cyan" if is_active else "bright_black",
            padding=(0, 1),
        )
    )


@target_group.command(name="set")
@click.argument("name", shell_complete=_complete_target_name)
@click.option(
    "--dir",
    "search_dir",
    default="targets",
    help="Directory to search for targets.",
    show_default=True,
)
@click.option(
    "--no-update",
    is_flag=True,
    help="Skip auto-regeneration of build_env.mk and build_env.tcl.",
)
def target_set(name, search_dir, no_update):
    """Switch the active project target.

    NAME is resolved to a file path using these priorities:
      1. targets/<name>.yml       (flat file)
      2. targets/<name>/project.yml  (directory layout)

    Examples:
        rr target set arria10_devkit
        rr target set cyclone10_lite --dir configs
    """
    resolved = resolve_target_path(name, search_dir)
    if resolved is None:
        console.print(f"❌ [red]Target '{name}' not found in {search_dir}/[/]")
        console.print(f"   Searched: {search_dir}/{name}.yml, "
                       f"{search_dir}/{name}/project.yml")
        console.print(f"\n   Run: [cyan]{_cli_name()} target list[/] to see available targets.")
        sys.exit(1)

    target_path = str(resolved)

    # Verify the target file parses correctly
    try:
        config = yaml.safe_load(resolved.read_text()) or {}
    except yaml.YAMLError as exc:
        console.print(f"❌ [red]Target file has YAML errors: {resolved}[/]")
        console.print(f"   {exc}")
        sys.exit(1)

    proj_name = ""
    if isinstance(config, dict):
        proj_name = config.get("project", {}).get("name", "")

    # Write the pointer
    pointer_content = _POINTER_TEMPLATE.format(
        target_path=target_path,
        cli=_cli_name(),
    )
    Path("project.yml").write_text(pointer_content)

    label = f" ({proj_name})" if proj_name else ""
    console.print(f"✅ [green]Target set:[/] [bold cyan]{name}[/]{label}")
    console.print(f"   [dim]→ {target_path}[/dim]")

    # Auto-regenerate build environment
    if not no_update:
        with cli_resilient_block("auto update-config after target set"):
            from sdk.cli.commands.workspace import _run_update_config

            console.print("\n🔧 [blue]Regenerating build configuration...[/]")
            _run_update_config(exit_on_error=False)


# RTL-P2.409: clone + rename — multi-target ops that previously required
# a manual cp + yml edit (easy to forget bumping output_dir and land two
# targets writing to the same build/ dir).


def _bump_target_config(
    config: dict,
    *,
    old_name: str,
    new_name: str,
    override_output_dir: str | None,
    keep_output_dir: bool,
) -> dict:
    """Return *config* with project.name and project.output_dir updated
    to match the new target.  Pure function — does not mutate input.

    Rules:
      * ``project.name`` : replaced with ``new_name`` only when it
        previously matched ``old_name`` (users who named their project
        differently from the target filename keep their choice).
      * ``project.output_dir`` :
          - ``keep_output_dir=True`` → left untouched.
          - ``override_output_dir`` given → used verbatim.
          - otherwise: if the current value mentions ``old_name`` as a
            path segment, swap that segment for ``new_name``; if
            unset, default to ``build/<new_name>``.
    """
    out = dict(config)
    proj = dict(out.get("project") or {})
    if isinstance(out.get("project"), dict):
        if proj.get("name") == old_name:
            proj["name"] = new_name

    if keep_output_dir:
        pass
    elif override_output_dir is not None:
        proj["output_dir"] = override_output_dir
    else:
        cur = proj.get("output_dir")
        if isinstance(cur, str) and cur:
            # Replace old_name as a whole path segment only.
            parts = Path(cur).parts
            new_parts = [
                new_name if p == old_name else p for p in parts
            ]
            proj["output_dir"] = str(Path(*new_parts)) if new_parts else cur
        else:
            proj["output_dir"] = f"build/{new_name}"

    out["project"] = proj
    return out


def _write_yaml(path: Path, data: dict) -> None:
    """Serialise *data* as YAML with stable key order."""
    path.write_text(yaml.dump(data, sort_keys=False, default_flow_style=False))


@target_group.command(name="clone")
@click.argument("src", shell_complete=_complete_target_name)
@click.argument("dst")
@click.option(
    "--dir",
    "search_dir",
    default="targets",
    show_default=True,
    help="Directory holding target ymls.",
)
@click.option(
    "--output-dir",
    "output_dir_override",
    default=None,
    help="Explicit output_dir for the clone (default: build/<dst>, or "
         "swap <src>→<dst> as a path segment when the original used that).",
)
@click.option(
    "--keep-output-dir",
    is_flag=True,
    default=False,
    help="Leave project.output_dir untouched in the clone.",
)
@click.option(
    "--force",
    is_flag=True,
    default=False,
    help="Overwrite targets/<dst>.yml if it already exists.",
)
def target_clone(src, dst, search_dir, output_dir_override, keep_output_dir, force):
    """Clone targets/<SRC>.yml to targets/<DST>.yml with output_dir auto-bumped.

    \b
    Typical use: derive a variant (e.g. 'passthrough' from 'base')
    without the manual cp + edit ritual.  Auto-bumps project.name and
    project.output_dir so the two targets don't collide on build outputs.

    \b
    Does NOT switch the active target — run `rr target set <dst>`
    when the clone is ready.

    \b
    Examples:
        rr target clone base passthrough
        rr target clone base passthrough --output-dir build/pt
        rr target clone base legacy --keep-output-dir
    """
    src_path = Path(search_dir) / f"{src}.yml"
    dst_path = Path(search_dir) / f"{dst}.yml"

    if not src_path.exists():
        console.print(f"❌ [red]Source target not found:[/] {src_path}")
        console.print(f"   Run: [cyan]{_cli_name()} target list[/]")
        sys.exit(1)

    if dst_path.exists() and not force:
        console.print(
            f"❌ [red]Destination already exists:[/] {dst_path}\n"
            "   [dim]Pass --force to overwrite.[/]"
        )
        sys.exit(1)

    if src == dst:
        console.print(f"❌ [red]Source and destination are identical:[/] {src}")
        sys.exit(1)

    try:
        src_cfg = yaml.safe_load(src_path.read_text()) or {}
    except yaml.YAMLError as exc:
        console.print(f"❌ [red]Source YAML invalid:[/] {src_path}\n   {exc}")
        sys.exit(1)
    if not isinstance(src_cfg, dict):
        console.print(f"❌ [red]Source is not a YAML mapping:[/] {src_path}")
        sys.exit(1)

    new_cfg = _bump_target_config(
        src_cfg,
        old_name=src,
        new_name=dst,
        override_output_dir=output_dir_override,
        keep_output_dir=keep_output_dir,
    )

    dst_path.parent.mkdir(parents=True, exist_ok=True)
    _write_yaml(dst_path, new_cfg)

    new_out = new_cfg.get("project", {}).get("output_dir") or "(unset)"
    new_name = new_cfg.get("project", {}).get("name") or "(unchanged)"
    console.print(
        f"✅ [green]Cloned:[/] {src_path} → [bold cyan]{dst_path}[/]\n"
        f"   [dim]project.name:       {new_name}[/]\n"
        f"   [dim]project.output_dir: {new_out}[/]\n"
        f"   [dim]Activate: [cyan]{_cli_name()} target set {dst}[/][/]"
    )


@target_group.command(name="rename")
@click.argument("old", shell_complete=_complete_target_name)
@click.argument("new")
@click.option(
    "--dir",
    "search_dir",
    default="targets",
    show_default=True,
    help="Directory holding target ymls.",
)
@click.option(
    "--force",
    is_flag=True,
    default=False,
    help="Overwrite targets/<new>.yml if it already exists.",
)
def target_rename(old, new, search_dir, force):
    """Rename targets/<OLD>.yml to targets/<NEW>.yml.

    \b
    Moves the target yml, updates project.name and project.output_dir
    internally (when they contained <old>), and fixes project.yml's
    target: pointer if <old> was the active target.

    \b
    Examples:
        rr target rename passtrough passthrough   # fix a typo
        rr target rename devkit rev2_devkit       # bump a variant
    """
    old_path = Path(search_dir) / f"{old}.yml"
    new_path = Path(search_dir) / f"{new}.yml"

    if old == new:
        console.print(f"❌ [red]Old and new names are identical:[/] {old}")
        sys.exit(1)

    if not old_path.exists():
        console.print(f"❌ [red]Target not found:[/] {old_path}")
        sys.exit(1)

    if new_path.exists() and not force:
        console.print(
            f"❌ [red]Destination already exists:[/] {new_path}\n"
            "   [dim]Pass --force to overwrite.[/]"
        )
        sys.exit(1)

    try:
        cfg = yaml.safe_load(old_path.read_text()) or {}
    except yaml.YAMLError as exc:
        console.print(f"❌ [red]YAML invalid:[/] {old_path}\n   {exc}")
        sys.exit(1)
    if not isinstance(cfg, dict):
        cfg = {}

    # For rename we preserve output_dir semantics when it didn't
    # reference <old> — otherwise swap the segment.  Users who want a
    # fresh build/<new>/ tree can re-run with the clone command then
    # delete the original.
    new_cfg = _bump_target_config(
        cfg,
        old_name=old,
        new_name=new,
        override_output_dir=None,
        keep_output_dir=False,
    )

    # Write the renamed yml first; only unlink the old one once the
    # write succeeds (crash-safe ordering — a rename half-done leaves
    # the old file intact).
    new_path.parent.mkdir(parents=True, exist_ok=True)
    _write_yaml(new_path, new_cfg)
    if old_path.resolve() != new_path.resolve():
        old_path.unlink()

    # If <old> was the active target, fix the pointer in project.yml.
    active = get_active_target()
    active_path = Path(active) if active else None
    pointer_updated = False
    if active_path is not None and active_path.resolve() == old_path.resolve():
        Path("project.yml").write_text(
            _POINTER_TEMPLATE.format(
                target_path=str(new_path),
                cli=_cli_name(),
            )
        )
        pointer_updated = True

    new_name = new_cfg.get("project", {}).get("name") or "(unchanged)"
    new_out = new_cfg.get("project", {}).get("output_dir") or "(unset)"
    console.print(
        f"✅ [green]Renamed:[/] {old_path} → [bold cyan]{new_path}[/]\n"
        f"   [dim]project.name:       {new_name}[/]\n"
        f"   [dim]project.output_dir: {new_out}[/]"
    )
    if pointer_updated:
        console.print(
            f"   [dim]project.yml pointer updated → {new_path}[/]"
        )


@target_group.command(name="reset")
@click.option(
    "--confirm",
    is_flag=True,
    help="Skip confirmation prompt.",
)
def target_reset(confirm):
    """Reset to a self-contained project.yml.

    Inlines the currently-targeted config back into the root project.yml,
    removing the pointer. This is a destructive operation — the original
    root project.yml (the pointer) is overwritten.
    """
    current = get_active_target()
    if current is None:
        console.print("  [dim]Already self-contained — nothing to reset.[/dim]")
        return

    target_path = Path(current)
    if not target_path.exists():
        console.print(f"❌ [red]Target file missing: {current}[/]")
        console.print("   Manually restore project.yml or run "
                       f"[cyan]{_cli_name()} target set <name>[/]")
        sys.exit(1)

    if not confirm:
        click.confirm(
            f"This will overwrite project.yml with the contents of {current}. Continue?",
            abort=True,
        )

    # Read the target content and write it to root
    content = target_path.read_text()
    Path("project.yml").write_text(content)

    console.print("✅ [green]Reset:[/] project.yml is now self-contained")
    console.print(f"   [dim]Inlined from: {current}[/dim]")

    # Regenerate build env
    with cli_resilient_block("auto update-config after target reset"):
        from sdk.cli.commands.workspace import _run_update_config

        console.print("\n🔧 [blue]Regenerating build configuration...[/]")
        _run_update_config(exit_on_error=False)
