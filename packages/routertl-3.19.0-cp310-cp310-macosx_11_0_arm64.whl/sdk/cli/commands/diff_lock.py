# SPDX-FileCopyrightText: 2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
Lockfile Diff — ``rr diff-lock``.

Human-readable, color-coded delta between the current project state and the
committed ``routertl.lock``.  Shows added/removed sources, changed hashes,
tool version drift, compile order changes, and environment differences.

Backlog: RTL-P2.106.
"""

import sys

import rich_click as click
from rich.table import Table

from sdk.cli.console import console
from sdk.cli.resilience import cli_resilient


@cli_resilient("CLI name resolution", default="routertl")
def _resolve_cli_name():
    from sdk.cli.main import CLI_NAME
    return CLI_NAME


@click.command(name="diff-lock")
@click.option("--json", "as_json", is_flag=True, help="Machine-readable JSON output.")
def diff_lock_command(as_json):
    """Show differences between current state and the lockfile.

    Displays a detailed, color-coded report of what has drifted since
    ``routertl.lock`` was last written.  Useful for understanding exactly
    what changed before running ``rr lock --update``.

    \b
    Exit codes:
        0  — lockfile matches current state
        1  — differences found
        2  — no lockfile exists
    """
    import json

    from sdk.engine.lockfile import (
        LOCKFILE_NAME,
        load_lockfile,
        resolve_project_state,
    )

    locked = load_lockfile(".")
    if not locked:
        cli_name = _resolve_cli_name()
        console.print(
            f"\n  [dim]No {LOCKFILE_NAME} found.[/]\n"
            f"  [dim]Run '{cli_name} lock' to create one.[/]\n"
        )
        sys.exit(2)

    current = resolve_project_state(".")

    if as_json:
        diff_data = _build_diff_data(locked, current)
        click.echo(json.dumps(diff_data, indent=2))
        if diff_data["total_changes"] > 0:
            sys.exit(1)
        return

    has_changes = _print_rich_diff(locked, current)

    if not has_changes:
        console.print("\n  [green]Lockfile is up to date — no drift detected.[/]\n")
    else:
        cli_name = _resolve_cli_name()
        console.print(
            f"\n  [dim]Run '{cli_name} lock --update' to accept these changes.[/]\n"
        )
        sys.exit(1)


# ── Rich diff output ─────────────────────────────────────────────


def _print_rich_diff(locked: dict, current: dict) -> bool:
    """Print a detailed, color-coded diff. Returns True if changes found."""
    has_changes = False

    console.print("\n  [bold cyan]Lockfile Diff[/] — routertl.lock\n")

    # ── Toolchain ──
    tc_changes = _diff_flat_dict("Toolchain", locked.get("toolchain", {}), current.get("toolchain", {}))
    if tc_changes:
        has_changes = True

    # ── Simulation ──
    sim_changes = _diff_flat_dict("Simulation", locked.get("simulation", {}), current.get("simulation", {}))
    if sim_changes:
        has_changes = True

    # ── SDK ──
    sdk_changes = _diff_flat_dict("SDK", locked.get("sdk", {}), current.get("sdk", {}))
    if sdk_changes:
        has_changes = True

    # ── Sources ──
    src_changes = _diff_file_list("Sources", locked.get("sources", []), current.get("sources", []))
    if src_changes:
        has_changes = True

    # ── Constraints ──
    con_changes = _diff_file_list("Constraints", locked.get("constraints", []), current.get("constraints", []))
    if con_changes:
        has_changes = True

    # ── Compile order ──
    old_order = locked.get("resolved_hierarchy", {}).get("compile_order", [])
    new_order = current.get("resolved_hierarchy", {}).get("compile_order", [])
    if old_order != new_order:
        has_changes = True
        console.print("  [bold]Compile Order[/]")
        old_set = set(old_order)
        new_set = set(new_order)
        for f in sorted(new_set - old_set):
            console.print(f"    [green]+ {f}[/]")
        for f in sorted(old_set - new_set):
            console.print(f"    [red]- {f}[/]")
        if old_set == new_set and old_order != new_order:
            console.print("    [yellow]~ order changed (same files, different sequence)[/]")
        console.print()

    # ── Dependencies ──
    dep_changes = _diff_deps(locked.get("dependencies", []), current.get("dependencies", []))
    if dep_changes:
        has_changes = True

    # ── Environment ──
    env_changes = _diff_flat_dict("Environment", locked.get("environment", {}), current.get("environment", {}))
    if env_changes:
        has_changes = True

    return has_changes


def _diff_flat_dict(section: str, old: dict, new: dict) -> bool:
    """Diff two flat dicts, printing colored output. Returns True if changes."""
    if old == new:
        return False

    console.print(f"  [bold]{section}[/]")

    all_keys = sorted(set(old.keys()) | set(new.keys()))
    for key in all_keys:
        old_val = old.get(key)
        new_val = new.get(key)
        if old_val == new_val:
            continue
        if old_val is None:
            console.print(f"    [green]+ {key}: {new_val}[/]")
        elif new_val is None:
            console.print(f"    [red]- {key}: {old_val}[/]")
        else:
            console.print(f"    [yellow]~ {key}: {old_val} → {new_val}[/]")

    console.print()
    return True


def _diff_file_list(section: str, old: list, new: list) -> bool:
    """Diff two lists of {path, sha256} dicts. Returns True if changes."""
    old_by_path = {s["path"]: s.get("sha256", "") for s in old if isinstance(s, dict)}
    new_by_path = {s["path"]: s.get("sha256", "") for s in new if isinstance(s, dict)}

    if old_by_path == new_by_path:
        return False

    added = sorted(set(new_by_path) - set(old_by_path))
    removed = sorted(set(old_by_path) - set(new_by_path))
    common = sorted(set(old_by_path) & set(new_by_path))
    changed = [p for p in common if old_by_path[p] != new_by_path[p]]

    if not added and not removed and not changed:
        return False

    console.print(f"  [bold]{section}[/]")

    table = Table(show_header=False, box=None, padding=(0, 1), expand=False)
    table.add_column("Status", width=3)
    table.add_column("File", min_width=30)
    table.add_column("Detail", style="dim")

    for path in added:
        table.add_row("[green]+[/]", f"[green]{path}[/]", "new file")
    for path in removed:
        table.add_row("[red]-[/]", f"[red]{path}[/]", "removed")
    for path in changed:
        old_hash = old_by_path[path][:12]
        new_hash = new_by_path[path][:12]
        table.add_row("[yellow]~[/]", f"[yellow]{path}[/]", f"{old_hash}… → {new_hash}…")

    console.print(table)

    summary_parts = []
    if added:
        summary_parts.append(f"[green]+{len(added)}[/]")
    if removed:
        summary_parts.append(f"[red]-{len(removed)}[/]")
    if changed:
        summary_parts.append(f"[yellow]~{len(changed)}[/]")
    console.print(f"    {' '.join(summary_parts)} file(s)")
    console.print()

    return True


def _diff_deps(old: list, new: list) -> bool:
    """Diff dependency lists. Returns True if changes."""
    old_by_name = {d["name"]: d for d in old if isinstance(d, dict)}
    new_by_name = {d["name"]: d for d in new if isinstance(d, dict)}

    if old_by_name == new_by_name:
        return False

    console.print("  [bold]Dependencies[/]")

    added = sorted(set(new_by_name) - set(old_by_name))
    removed = sorted(set(old_by_name) - set(new_by_name))
    common = sorted(set(old_by_name) & set(new_by_name))

    for name in added:
        ver = new_by_name[name].get("resolved_version", "?")
        console.print(f"    [green]+ {name} @ {ver}[/]")
    for name in removed:
        ver = old_by_name[name].get("resolved_version", "?")
        console.print(f"    [red]- {name} @ {ver}[/]")
    for name in common:
        old_entry = old_by_name[name]
        new_entry = new_by_name[name]
        if old_entry != new_entry:
            old_ver = old_entry.get("resolved_version", "?")
            new_ver = new_entry.get("resolved_version", "?")
            if old_ver != new_ver:
                console.print(f"    [yellow]~ {name}: {old_ver} → {new_ver}[/]")
            elif old_entry.get("commit") != new_entry.get("commit"):
                old_c = old_entry.get("commit", "?")[:8]
                new_c = new_entry.get("commit", "?")[:8]
                console.print(f"    [yellow]~ {name}: commit {old_c}… → {new_c}…[/]")

    console.print()
    return True


# ── JSON diff output ─────────────────────────────────────────────


def _build_diff_data(locked: dict, current: dict) -> dict:
    """Build a machine-readable diff dict."""
    changes = []

    # Flat sections
    for section in ("toolchain", "simulation", "sdk", "environment"):
        old = locked.get(section, {})
        new = current.get(section, {})
        if not isinstance(old, dict):
            old = {}
        if not isinstance(new, dict):
            new = {}
        for key in sorted(set(old.keys()) | set(new.keys())):
            if old.get(key) != new.get(key):
                changes.append({
                    "section": section,
                    "key": key,
                    "old": old.get(key),
                    "new": new.get(key),
                    "type": "added" if key not in old else "removed" if key not in new else "changed",
                })

    # File lists
    for section in ("sources", "constraints"):
        old_by_path = {s["path"]: s.get("sha256", "") for s in locked.get(section, []) if isinstance(s, dict)}
        new_by_path = {s["path"]: s.get("sha256", "") for s in current.get(section, []) if isinstance(s, dict)}
        for path in sorted(set(old_by_path) | set(new_by_path)):
            if path not in old_by_path:
                changes.append({"section": section, "path": path, "type": "added"})
            elif path not in new_by_path:
                changes.append({"section": section, "path": path, "type": "removed"})
            elif old_by_path[path] != new_by_path[path]:
                changes.append({
                    "section": section,
                    "path": path,
                    "type": "changed",
                    "old_sha256": old_by_path[path],
                    "new_sha256": new_by_path[path],
                })

    # RTL-P1.49: compile_order and dependencies were previously absent
    # from the JSON diff, so `rr diff-lock --json` exited 0 on drift —
    # directly contradicting the --help contract and silently passing
    # CI reproducibility gates.  Count changes in both sections.
    old_order = locked.get("resolved_hierarchy", {}).get("compile_order", [])
    new_order = current.get("resolved_hierarchy", {}).get("compile_order", [])
    if old_order != new_order:
        old_set = set(old_order)
        new_set = set(new_order)
        if old_set == new_set:
            changes.append({
                "section": "compile_order",
                "type": "reordered",
                "old": old_order,
                "new": new_order,
            })
        else:
            for f in sorted(new_set - old_set):
                changes.append({"section": "compile_order", "path": f, "type": "added"})
            for f in sorted(old_set - new_set):
                changes.append({"section": "compile_order", "path": f, "type": "removed"})

    old_deps = {d["name"]: d for d in locked.get("dependencies", []) if isinstance(d, dict)}
    new_deps = {d["name"]: d for d in current.get("dependencies", []) if isinstance(d, dict)}
    for name in sorted(set(old_deps) | set(new_deps)):
        if name not in old_deps:
            changes.append({
                "section": "dependencies", "name": name, "type": "added",
                "new": new_deps[name],
            })
        elif name not in new_deps:
            changes.append({
                "section": "dependencies", "name": name, "type": "removed",
                "old": old_deps[name],
            })
        elif old_deps[name] != new_deps[name]:
            changes.append({
                "section": "dependencies", "name": name, "type": "changed",
                "old": old_deps[name], "new": new_deps[name],
            })

    return {
        "total_changes": len(changes),
        "changes": changes,
    }
