# SPDX-FileCopyrightText: 2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""rr mcp — MCP (Model Context Protocol) server integration.

Installs the routertl MCP server into a project's ``.mcp.json`` so AI
agents (Claude Code, etc.) can invoke ``rr`` knowledge tools directly.

RTL-P2.324
"""

from __future__ import annotations

import json
from pathlib import Path

import rich_click as click

from sdk.cli.console import console

MCP_SERVER_KEY = "routertl"
MCP_SERVER_ENTRY = {"command": "routertl-mcp"}
MCP_FILENAME = ".mcp.json"


def _load_existing(mcp_path: Path) -> tuple[dict, bool]:
    """Return (config_dict, existed) for the given .mcp.json path.

    Missing file → empty dict. Malformed JSON raises ClickException so
    we never silently overwrite the user's broken config.
    """
    if not mcp_path.exists():
        return ({}, False)
    try:
        data = json.loads(mcp_path.read_text())
    except json.JSONDecodeError as exc:
        raise click.ClickException(
            f"Existing {MCP_FILENAME} is not valid JSON: {exc}. "
            "Fix or delete it before running `rr mcp install`."
        ) from exc
    if not isinstance(data, dict):
        raise click.ClickException(
            f"{MCP_FILENAME} root must be a JSON object, got {type(data).__name__}."
        )
    return (data, True)


def _merge_entry(config: dict, force: bool) -> tuple[dict, str]:
    """Merge the routertl entry into config.

    Returns (new_config, action) where action is one of:
      - "added": entry was absent
      - "updated": entry existed and differed; --force replaced it
      - "unchanged": entry already matches desired value
      - "conflict": entry exists and differs, --force not given
    """
    servers = config.get("mcpServers")
    if not isinstance(servers, dict):
        servers = {}
    existing = servers.get(MCP_SERVER_KEY)

    if existing == MCP_SERVER_ENTRY:
        action = "unchanged"
    elif existing is None:
        servers[MCP_SERVER_KEY] = dict(MCP_SERVER_ENTRY)
        action = "added"
    elif force:
        servers[MCP_SERVER_KEY] = dict(MCP_SERVER_ENTRY)
        action = "updated"
    else:
        return (config, "conflict")

    new_config = dict(config)
    new_config["mcpServers"] = servers
    return (new_config, action)


@click.group(name="mcp")
def mcp_group():
    """MCP (Model Context Protocol) server integration for AI agents."""


@mcp_group.command(name="install")
@click.option(
    "--path",
    "target_dir",
    type=click.Path(file_okay=False, dir_okay=True, path_type=Path),
    default=None,
    help="Directory to install into (defaults to CWD).",
)
@click.option(
    "--dry-run",
    is_flag=True,
    help="Print what would be written without modifying any files.",
)
@click.option(
    "--force",
    is_flag=True,
    help="Overwrite an existing routertl entry that differs from the default.",
)
def mcp_install(target_dir: Path | None, dry_run: bool, force: bool):
    """Install the routertl MCP server into ``./.mcp.json``.

    Merges a ``routertl`` entry under ``mcpServers`` so Claude Code (and
    any other MCP-aware client that reads ``.mcp.json``) can spawn the
    ``routertl-mcp`` server and expose its tools to the AI agent.

    Idempotent: re-running leaves the file unchanged when the entry
    already matches. Preserves any other MCP servers already registered.

    \b
    Examples:
        rr mcp install                 # write ./.mcp.json in CWD
        rr mcp install --dry-run       # show the result, no write
        rr mcp install --force         # replace a custom routertl entry
    """
    base = (target_dir or Path.cwd()).resolve()
    if not base.exists():
        raise click.ClickException(f"Target directory does not exist: {base}")
    mcp_path = base / MCP_FILENAME

    config, existed = _load_existing(mcp_path)
    new_config, action = _merge_entry(config, force=force)

    if action == "conflict":
        existing = config.get("mcpServers", {}).get(MCP_SERVER_KEY)
        console.print(
            f"[yellow]⚠ {mcp_path} already has a [bold]{MCP_SERVER_KEY}[/] "
            f"entry that differs from the default.[/]"
        )
        console.print(f"    current:  {json.dumps(existing)}")
        console.print(f"    default:  {json.dumps(MCP_SERVER_ENTRY)}")
        console.print("    Re-run with [cyan]--force[/] to overwrite.")
        raise click.exceptions.Exit(1)

    payload = json.dumps(new_config, indent=2) + "\n"

    if action == "unchanged":
        console.print(
            f"[green]✓[/] {mcp_path} already registers [bold]{MCP_SERVER_KEY}[/] — nothing to do."
        )
        return

    if dry_run:
        verb = {"added": "add", "updated": "update"}[action]
        console.print(
            f"[cyan]Would {verb}[/] [bold]{MCP_SERVER_KEY}[/] entry in {mcp_path}:"
        )
        console.print(payload)
        return

    mcp_path.write_text(payload)
    verb = "Created" if not existed else ("Updated" if action == "updated" else "Merged")
    console.print(
        f"[green]✓ {verb}[/] {mcp_path} — registered [bold]{MCP_SERVER_KEY}[/] MCP server."
    )
    console.print(
        "    Restart your MCP client (e.g. Claude Code) to pick up the new entry."
    )
