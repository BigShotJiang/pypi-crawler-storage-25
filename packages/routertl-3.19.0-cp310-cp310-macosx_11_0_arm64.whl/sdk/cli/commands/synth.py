# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
Synthesis Validation Status Board — ``rr synth``.

Provides a dashboard of synthesis results, batch synthesis, and cross-
referencing of ip.yml targets against the source-tree forest.
"""

import json
import os
import subprocess
import sys
import time
from pathlib import Path

import rich_click as click
from rich.table import Table

from sdk.cli.console import console
from sdk.cli.resilience import cli_resilient, cli_resilient_block


def _try_parse_report(vendor=""):
    """Attempt to parse build reports from the current directory.

    Returns a BuildReport or None.
    """
    with cli_resilient_block("report parsing"):
        from sdk.engine.report_parser import detect_and_parse
        return detect_and_parse(Path.cwd(), vendor=vendor)
    return None

# ── Helpers ───────────────────────────────────────────────────────

def _clean_top(top):
    """Reuse the shared entity-name sanitizer from hardware.py."""
    from sdk.cli.commands.hardware import _clean_top as _hw_clean
    return _hw_clean(top)


def _in_container():
    """Best-effort detection of container execution (docker, podman, k8s)."""
    if os.path.exists("/.dockerenv") or os.path.exists("/run/.containerenv"):
        return True
    container_env = os.environ.get("CONTAINER", "")
    if container_env in ("docker", "oci", "podman"):
        return True
    if os.environ.get("KUBERNETES_SERVICE_HOST"):
        return True
    return False


def _missing_target_hints(target):
    """Return recovery hints tailored to the caller's environment.

    The "No rule to make target" failure almost always means the Makefile's
    ``-include $(SDK_ROOT)/Common.mk`` silently dropped (bad SDK_ROOT).  The
    right recovery depends on whether a project already exists and whether
    we're in a container.
    """
    has_project = os.path.exists("project.yml")
    in_container = _in_container()

    hints = []
    if has_project:
        hints.append(
            "   • Run [cyan]rr ws repair[/] — re-resolves SDK_ROOT and "
            "patches the Makefile include path."
        )
        hints.append(
            "   • Or run [cyan]rr doctor[/] for a broader diagnosis."
        )
    else:
        hints.append(
            "   • Run [cyan]rr init[/] — no project.yml detected in this directory."
        )

    if not in_container:
        hints.append(
            "   • If you use a toolchain container, enter it with "
            "[cyan]rr docker shell[/]."
        )
    return "\n".join(hints)


def _run_make_capture(target, *args):
    """Run a Make target and return (returncode, duration_s).

    Detects common failure patterns (missing targets, missing make)
    and emits pip-friendly error messages.
    """
    cmd = ["make", target, *args]
    t0 = time.monotonic()
    try:
        result = subprocess.run(
            cmd, check=False, capture_output=True, text=True,
        )
        duration = time.monotonic() - t0
        if result.returncode != 0:
            stderr = result.stderr or ""
            if "No rule to make target" in stderr:
                console.print(
                    f"❌ [red]Build target '{target}' not available.[/]\n"
                    "   This project's Makefile is missing SDK targets — "
                    "usually a stale SDK_ROOT path.\n"
                    "   Possible fixes:\n"
                    f"{_missing_target_hints(target)}"
                )
                sys.exit(1)
            # Print captured output so the user still sees make errors
            if isinstance(result.stdout, str) and result.stdout:
                sys.stdout.write(result.stdout)
            if isinstance(result.stderr, str) and result.stderr:
                sys.stderr.write(result.stderr)
        else:
            # Print normal output on success
            if isinstance(result.stdout, str) and result.stdout:
                sys.stdout.write(result.stdout)
        return result.returncode, duration
    except FileNotFoundError:
        from sdk.cli.platform_hints import install_cmd
        build_cmd = install_cmd("build-essential") or "install a C toolchain"
        console.print(
            "❌ [red]'make' not found.[/]\n"
            f"   Install build tools: [cyan]{build_cmd}[/]"
        )
        sys.exit(1)


def _run_synth_direct(module, *extra_args):
    """Run NPM synthesis by calling dependency_resolver.py directly.

    Bypasses Make entirely for pip-installed environments.  Falls back
    to ``_run_make_capture()`` if the resolver script is not found.

    Returns (returncode, duration_s).
    """
    from sdk.cli.env_setup import resolve_sdk_script, resolve_src_dirs

    script = resolve_sdk_script("project-manager/dependency_resolver.py")
    if script is None:
        # Submodule install — fall back to Make
        return _run_make_capture("npm-synthesis", f"TOP={module}", *extra_args)

    src_dirs = resolve_src_dirs()
    src_args = []
    for d in src_dirs:
        src_args.extend(["--src", d])

    t0 = time.monotonic()

    # Step 1: Resolve dependencies for the target module
    resolver_cmd = [
        sys.executable, str(script),
    ] + src_args + ["--top", module, "--list-libs"]

    try:
        res = subprocess.run(
            resolver_cmd, capture_output=True, text=True, check=True,
        )
    except subprocess.CalledProcessError as exc:
        duration = time.monotonic() - t0
        err = (exc.stderr or "").strip()
        console.print(
            f"❌ [red]Dependency resolution failed for {module}.[/]"
        )
        if err:
            console.print(f"   {err}")
        return 1, duration
    except FileNotFoundError:
        console.print("❌ [red]Python interpreter not found.[/]")
        sys.exit(1)

    resolved_files = res.stdout.strip()
    if not resolved_files:
        duration = time.monotonic() - t0
        console.print(
            f"❌ [red]No dependencies found for {module}.[/]\n"
            "   Check entity name and source directories."
        )
        return 1, duration

    console.print(
        f"   [dim]Resolved {len(resolved_files.split())} source file(s)[/]"
    )

    # Step 2: Delegate to Make for vendor TCL invocation (needs EDA tools)
    # The direct path resolved the file list; Make handles the TCL call.
    duration = time.monotonic() - t0
    rc, make_dur = _run_make_capture("npm-synthesis", f"TOP={module}", *extra_args)
    return rc, duration + make_dur


def _get_tracker():
    """Lazy-import and instantiate a SynthTracker for the current directory."""
    from sdk.engine.synth_tracker import SynthTracker
    return SynthTracker()


@cli_resilient("project YAML loading", default=None)
def _load_project_yml():
    """Load project.yml from cwd, or return None."""
    from sdk.cli.project_config import load_project_config

    if not os.path.exists("project.yml"):
        return None
    return load_project_config()


def _discover_ip_targets():
    """Return list of (name, source_count) for ip.yml targets with mode=rtl.

    Returns an empty list when project.yml is missing or has no IPs.
    """
    config = _load_project_yml()
    if config is None:
        return []

    with cli_resilient_block("IP target discovery"):
        from sdk.engine.ip_resolver import IpResolver, load_ips_from_project
        ip_paths, vendor, project_root = load_ips_from_project("project.yml")
        if not ip_paths:
            return []
        resolver = IpResolver(project_root, vendor)
        result = resolver.resolve(ip_paths)
        return [
            (m.name, m.source_count)
            for m in result.manifests
            if m.mode == "rtl"
        ]
    return []


def _discover_forest_entities():
    """Return sorted list of (name, is_top, file_count) from the source forest."""
    from sdk.cli.engine_dispatch import read_build_env

    benv = read_build_env()
    src_dir = benv.get("SRC_DIR", "src")

    with cli_resilient_block("forest entity discovery"):
        from sdk.engine.dependency_resolver import DependencyResolver
        resolver = DependencyResolver([Path(src_dir)], verbose=False)
        forest = resolver.resolve_forest()
        top_names = {t["top"] for t in (forest.get("trees") or [])}

        results = []
        for name in sorted(resolver.entity_map.keys()):
            is_top = name in top_names
            # Count files via the forest tree data if available
            file_count = 1
            for t in (forest.get("trees") or []):
                if t["top"] == name:
                    file_count = t.get("weight") or len(t.get("files") or [])
                    break
            results.append((name, is_top, file_count))
        return results
    return []


@cli_resilient("CLI name resolution", default="routertl")
def _resolve_cli_name():
    """Get the effective CLI binary name for usage hints."""
    from sdk.cli.main import CLI_NAME
    return CLI_NAME


def _get_hardware_identity():
    """Read vendor, part, and target code from project.yml for result recording."""
    from sdk.cli.project_config import derive_target_code

    config = _load_project_yml()
    if config is None:
        return "", "", ""
    hw = config.get("hardware", {})
    return hw.get("vendor", ""), hw.get("part", ""), derive_target_code(config)


def _status_style(status):
    """Return (color, icon) for a synthesis status string."""
    styles = {
        "PASS":    ("[green]",  "✅"),
        "FAIL":    ("[red]",    "❌"),
        "STALE":   ("[yellow]", "🔄"),
        "UNKNOWN": ("[dim]",   "⬜"),
    }
    return styles.get(status, ("[dim]", "?"))


def _auto_package_pre_synth(*, dry_run: bool) -> None:
    """Run the pre-synth auto-packager (RTL-P3.188) for vendored IPs.

    Silently returns when nothing is stale — no visual noise for the
    common "everything up to date" path. Aborts synth with a clear
    error when Vivado is missing or packaging fails.
    """
    from sdk.engine.ip_auto_package import auto_package_stale_ips

    results, planned = auto_package_stale_ips(Path.cwd(), dry_run=dry_run)

    if not planned:
        return

    if dry_run:
        console.print(
            f"\n📦 [yellow]Would auto-package {len(planned)} IP(s):[/]"
        )
        for sp in planned:
            console.print(
                f"    [yellow]• {sp.name}[/]  [dim]({sp.reason})[/]"
            )
        console.print()
        return

    # Live packaging run — show per-IP progress.
    console.print(
        f"\n📦 [cyan]Auto-packaging {len(planned)} vendored IP(s)[/]"
    )
    for sp, res in zip(planned, results):
        if res.ok:
            console.print(
                f"    [green]✓[/]  {sp.name}  "
                f"[dim]({sp.reason}, {res.duration_s:.1f}s)[/]"
            )
        else:
            console.print(f"    [red]✗[/]  {sp.name}  [red]{res.error}[/]")
            if res.log_path:
                console.print(f"       [dim]log: {res.log_path}[/]")

    if any(not r.ok for r in results):
        console.print(
            "\n❌ [red]Auto-package failed — aborting synth. Fix the "
            "recipe or run with [cyan]--no-auto-package[/] to skip.[/]"
        )
        sys.exit(1)
    console.print()


# ── Command Group ─────────────────────────────────────────────────

@click.group(name="synth", invoke_without_command=True)
@click.pass_context
def synth_group(ctx):
    """Synthesis Validation Status Board.

    View synthesis results, batch-synthesize ip.yml targets, and cross-
    reference forest entities with registered IP manifests.
    """
    if ctx.invoked_subcommand is None:
        # Default to status when no subcommand is given
        ctx.invoke(synth_status)


# ── rr synth status ───────────────────────────────────────────────

@synth_group.command(name="status")
@click.option("--json", "as_json", is_flag=True, help="Machine-readable JSON output.")
def synth_status(as_json):
    """Show the synthesis status board.

    Displays all ip.yml targets with ``synthesis.mode: rtl``, overlaid with
    cached PASS/FAIL/STALE status from previous runs.
    """
    tracker = _get_tracker()
    ip_targets = _discover_ip_targets()

    if as_json:
        data = {}
        for name, src_count in ip_targets:
            result = tracker.get(name)
            data[name] = {
                "sources": src_count,
                "status": result.status if result else "UNKNOWN",
                "target": result.target if result else "",
                "timestamp": result.timestamp if result else None,
                "resources": result.resources if result else {},
                "warnings": result.warnings if result else 0,
            }
        click.echo(json.dumps(data, indent=2))
        return

    cli_name = _resolve_cli_name()


    if not ip_targets:
        # Show project top-module info from project.yml if available
        config = _load_project_yml()
        if config:
            hw = config.get("hardware", {})
            part = hw.get("part", "")
            # top_module can live under project.top_module or at top level
            proj = config.get("project", {})
            top = (proj.get("top_module", "") if isinstance(proj, dict) else "") or config.get("top_module", "")
            if top:
                top_line = f"  [cyan]Project:[/] {top}"
                if part:
                    top_line += f" ({part})"
                console.print(f"\n{top_line}")

        console.print(
            "\n  [dim]No ip.yml targets with synthesis.mode: rtl found.[/]"
        )

        if config and top:
            # Show last project-level synth result if available
            result = tracker.get(top)
            if result:
                color, icon = _status_style(result.status)
                ts_str = result.timestamp[:19].replace("T", " ") if result.timestamp else "—"
                dur_str = f"{result.duration_s:.1f}s" if result.duration_s else ""
                console.print(f"\n  {icon} Last run: {color}{result.status}[/]  [dim]{ts_str}[/]  {dur_str}")
            else:
                # Check for a build report on disk as fallback
                report = _try_parse_report(hw.get("vendor", ""))
                if report:
                    console.print(f"\n  ✅ Last build report found [dim](use '{cli_name} synth report' for details)[/]")

            console.print(
                f"\n  → Run [cyan]'{cli_name} synth run'[/] to synthesize the project top module.\n"
            )
        else:
            console.print(
                f"  [dim]Use '{cli_name} synth run <module>' for ad-hoc synthesis.[/]\n"
            )
        # Show any cached ad-hoc results
        all_results = tracker.all_results()
        if all_results:
            console.print("  [cyan]Cached ad-hoc results:[/]\n")
            for name, r in sorted(all_results.items()):
                color, icon = _status_style(r.status)
                console.print(
                    f"    {icon} {color}{name:<25}[/] "
                    f"[dim]{r.timestamp[:19] if r.timestamp else '—'}[/]"
                )
            console.print()
        return

    table = Table(
        title="🔬 Synthesis Status Board",
        title_style="bold cyan",
        show_lines=False,
        padding=(0, 1),
    )
    table.add_column("Status", justify="center", width=6)
    table.add_column("Module", style="cyan", min_width=20)
    table.add_column("Sources", justify="right", width=7)
    table.add_column("Resources", min_width=15)
    table.add_column("Warns", justify="right", width=5)
    table.add_column("Duration", justify="right", width=8)
    table.add_column("Last Run", min_width=12)

    pass_count = 0
    fail_count = 0
    unknown_count = 0

    for name, src_count in sorted(ip_targets):
        result = tracker.get(name)
        if result:
            status = result.status
            if status == "PASS":
                # Quick staleness heuristic — full check requires src_files
                pass_count += 1
            else:
                fail_count += 1

            res_str = ", ".join(f"{k}={v:,}" for k, v in result.resources.items()) if result.resources else "—"
            warn_str = str(result.warnings) if result.warnings else "—"
            dur_str = f"{result.duration_s:.1f}s" if result.duration_s else "—"
            ts_str = result.timestamp[:19].replace("T", " ") if result.timestamp else "—"
        else:
            status = "UNKNOWN"
            unknown_count += 1
            res_str = "—"
            warn_str = "—"
            dur_str = "—"
            ts_str = "—"

        color, icon = _status_style(status)
        table.add_row(
            icon,
            name,
            str(src_count),
            res_str,
            warn_str,
            dur_str,
            ts_str,
        )

    console.print()
    console.print(table)

    total = pass_count + fail_count + unknown_count
    summary_parts = []
    if pass_count:
        summary_parts.append(f"[green]{pass_count} passed[/]")
    if fail_count:
        summary_parts.append(f"[red]{fail_count} failed[/]")
    if unknown_count:
        summary_parts.append(f"[dim]{unknown_count} not run[/]")

    console.print(f"\n  {' · '.join(summary_parts)}  ({total} targets)")
    console.print(
        f"\n  [dim]Run '{cli_name} synth all' to synthesize all targets.[/]\n"
    )


# ── rr synth all ──────────────────────────────────────────────────

@synth_group.command(name="all")
@click.option("--clean", "-c", is_flag=True, help="Remove cached DCP artifacts before each run.")
def synth_all(clean):
    """Batch-synthesize all ip.yml targets with ``synthesis.mode: rtl``."""
    from sdk.cli.commands.hardware import _clean_build_artifacts

    ip_targets = _discover_ip_targets()
    if not ip_targets:
        console.print(
            "\n  [dim]No ip.yml targets with synthesis.mode: rtl found.[/]\n"
        )
        return

    tracker = _get_tracker()
    vendor, part, target = _get_hardware_identity()
    total = len(ip_targets)

    console.print(
        f"\n🔍 [cyan]Discovered {total} synthesis target{'s' if total != 1 else ''}"
        f" from ip.yml manifests[/]\n"
    )

    results_summary = []

    for idx, (name, src_count) in enumerate(ip_targets, 1):
        console.print(
            f"🔨 [{idx}/{total}] [cyan]{name}[/] "
            f"({src_count} file{'s' if src_count != 1 else ''})...",
            end="",
        )
        if clean:
            _clean_build_artifacts("dcp", name)

        rc, duration = _run_synth_direct(name)
        status = "PASS" if rc == 0 else "FAIL"

        from datetime import datetime, timezone

        from sdk.engine.synth_tracker import SynthResult
        result = SynthResult(
            module=name,
            status=status,
            timestamp=datetime.now(timezone.utc).isoformat(timespec="seconds"),
            duration_s=round(duration, 1),
            vendor=vendor,
            part=part,
            target=target,
        )
        tracker.record(result)

        color, icon = _status_style(status)
        console.print(f" {icon} {color}{status}[/] ({duration:.1f}s)")
        results_summary.append((name, status, duration))

    # Summary
    passed = sum(1 for _, s, _ in results_summary if s == "PASS")
    failed = sum(1 for _, s, _ in results_summary if s == "FAIL")

    console.print(f"\n{'━' * 56}")
    if failed == 0:
        console.print(
            f"  [green]NPM SYNTHESIS REPORT — {passed}/{total} PASSED[/]"
        )
    else:
        console.print(
            f"  [red]NPM SYNTHESIS REPORT — {passed}/{total} PASSED, "
            f"{failed} FAILED[/]"
        )
    console.print(f"{'━' * 56}")
    console.print("  [dim]Results cached in .routertl_cache/synth_results.json[/]\n")


# ── rr synth run ──────────────────────────────────────────────────

@synth_group.command(name="run")
@click.argument("module", required=False, default=None)
@click.option("--clean", "-c", is_flag=True, help="Remove cached DCP/Project artifacts first.")
@click.option("--locked", is_flag=True, help="Verify routertl.lock before running; abort on mismatch.")
@click.option(
    "--dry-run",
    is_flag=True,
    help="Project-gen-only: launch Vivado, source gen_project hooks, "
         "run validate_bd_design, then exit BEFORE synth_design.  "
         "~2-3 min vs 30-60 min — the fast feedback loop for iterating "
         "on BD patches and hook ordering (RTL-P3.156).",
)
@click.option(
    "--no-auto-package",
    is_flag=True,
    help="Skip the pre-synth auto-package step for vendored IPs "
         "(RTL-P3.188). Use when component.xml is committed and must "
         "not be regenerated.",
)
@click.option(
    "--ip", "ip_standalone_dir", default=None,
    type=click.Path(exists=True, file_okay=False, dir_okay=True, path_type=Path),
    help="Validate a single IP's ip.yml synth-readiness and print the "
         "resolved plan (RTL-P2.435, MVP). Checks hdl.top_module, "
         "build.hardware.{vendor, part}, HDL sources, XDC, tcl_hooks. "
         "Exits 0 when ready, 1 otherwise. Full vendor-flow spawn via "
         "--ip is a follow-up (requires VendorDispatch refactor).",
)
def synth_run(module, clean, locked, dry_run, no_auto_package, ip_standalone_dir):
    """Synthesize the project or a single module.

    If <module> is provided, synthesizes a single NPM IP module.
    Without <module>, synthesizes the full project.
    """
    # RTL-P2.435: --ip validates a single IP's synth-readiness from
    # ip.yml alone.  MVP — prints the plan and exits; full vendor-flow
    # spawn stays on the project.yml path until VendorDispatch gets an
    # ip-manifest-only constructor.
    if ip_standalone_dir is not None:
        _print_synth_plan_for_ip(ip_standalone_dir)
        return

    # ── Lockfile guard ──
    if locked:
        from sdk.cli.commands.lock import enforce_locked
        enforce_locked("synth")

    from sdk.cli.commands.hardware import _clean_build_artifacts, _run_make

    if module and dry_run:
        console.print(
            "❌ [red]--dry-run is a project-level flag; it has no "
            "meaning for single-module (IP-level) synthesis.[/]"
        )
        sys.exit(2)

    if not module:
        # Full project synthesis
        if clean:
            _clean_build_artifacts("project", "")

        # ── Auto-package vendored IPs (RTL-P3.188) ──
        # Runs for full-project synth only (module-level synth assumes
        # a single IP is already resolved). --no-auto-package is the
        # escape hatch for repos that commit component.xml.
        if not no_auto_package:
            _auto_package_pre_synth(dry_run=dry_run)

        if dry_run:
            console.print("🎯 [blue]Dry-run: project generation only...[/]")
        else:
            console.print("🔨 [blue]Starting Synthesis...[/]")
        t0 = time.monotonic()
        rc = 0
        try:
            from sdk.cli.vendor_dispatch import VendorDispatch, VendorToolNotFound

            dispatch = VendorDispatch.from_project()
            rc = dispatch.synthesis(dry_run=dry_run)
            if rc != 0:
                sys.exit(rc)
            if dry_run:
                return  # skip post-synthesis hooks, report parsing, tracking
        except (ImportError, VendorToolNotFound):
            # Fallback path — "make project" matches the dry-run semantic
            # (generate project, stop short of synthesis).
            _run_make("project" if dry_run else "synthesis")
            if dry_run:
                return
        duration = time.monotonic() - t0

        # Post-synthesis hooks (RTL-P2.298)
        with cli_resilient_block("post-synthesis hooks"):
            from sdk.cli.engine_dispatch import run_engine_script

            run_engine_script(
                "run_hooks.py",
                ["--stage", "post_synthesis", "--project", "project.yml", "--root", "."],
            )

        # Attempt to parse and display post-synthesis report
        vendor, part, target = _get_hardware_identity()
        report = _try_parse_report(vendor)
        if report:
            _print_build_report(report)

        # Record result to tracker so 'rr synth' status can show it
        config = _load_project_yml()
        if config:
            proj = config.get("project", {})
            top = (proj.get("top_module", "") if isinstance(proj, dict) else "") or config.get("top_module", "")
            if top:
                from datetime import datetime, timezone

                from sdk.engine.synth_tracker import SynthResult
                status = "PASS" if rc == 0 else "FAIL"
                resources_dict = {}
                warnings = 0
                timing_wns = 0.0
                timing_fmax = 0.0
                timing_clock = ""
                phases = []
                if report:
                    fields = report.to_synth_result_fields()
                    resources_dict = fields.get("resources", {})
                    timing_wns = fields.get("timing_wns", 0.0)
                    timing_fmax = fields.get("timing_fmax", 0.0)
                    timing_clock = fields.get("timing_clock", "")
                    warnings = fields.get("warnings", 0)
                    phases = [{"name": p.name, "passed": p.passed, "duration_s": p.duration_s}
                              for p in report.phases]
                tracker = _get_tracker()
                result = SynthResult(
                    module=top,
                    status=status,
                    timestamp=datetime.now(timezone.utc).isoformat(timespec="seconds"),
                    duration_s=round(duration, 1),
                    vendor=vendor,
                    part=part,
                    target=target,
                    resources=resources_dict,
                    warnings=warnings,
                    timing_wns=timing_wns,
                    timing_fmax=timing_fmax,
                    timing_clock=timing_clock,
                    phases=phases,
                )
                tracker.record(result)
        return

    # IP-level synthesis
    module = _clean_top(module)

    if clean:
        _clean_build_artifacts("dcp", module)

    console.print(
        f"🔨 [blue]Synthesizing [cyan]{module}[/]..."
    )

    rc, duration = _run_synth_direct(module)
    status = "PASS" if rc == 0 else "FAIL"

    vendor, part, target = _get_hardware_identity()

    # Attempt to parse build report and populate resource/timing fields
    report = _try_parse_report(vendor)
    resources_dict = {}
    timing_wns = 0.0
    timing_fmax = 0.0
    timing_clock = ""
    phases = []
    warnings = 0
    if report:
        fields = report.to_synth_result_fields()
        resources_dict = fields.get("resources", {})
        timing_wns = fields.get("timing_wns", 0.0)
        timing_fmax = fields.get("timing_fmax", 0.0)
        timing_clock = fields.get("timing_clock", "")
        warnings = fields.get("warnings", 0)
        phases = [{"name": p.name, "passed": p.passed, "duration_s": p.duration_s}
                  for p in report.phases]

    tracker = _get_tracker()
    from datetime import datetime, timezone

    from sdk.engine.synth_tracker import SynthResult
    result = SynthResult(
        module=module,
        status=status,
        timestamp=datetime.now(timezone.utc).isoformat(timespec="seconds"),
        duration_s=round(duration, 1),
        vendor=vendor,
        part=part,
        target=target,
        resources=resources_dict,
        warnings=warnings,
        timing_wns=timing_wns,
        timing_fmax=timing_fmax,
        timing_clock=timing_clock,
        phases=phases,
    )
    tracker.record(result)

    color, icon = _status_style(status)
    console.print(
        f"\n  {icon} {color}{status}[/] — "
        f"{module} ({duration:.1f}s)"
    )

    if report:
        _print_build_report(report)

    if status == "FAIL":
        sys.exit(1)


# ── rr synth discover ─────────────────────────────────────────────

@synth_group.command(name="discover")
def synth_discover():
    """Cross-reference forest entities with ip.yml targets.

    Shows which source-tree entities are already registered as ip.yml targets
    and which are potential candidates for synthesis validation.
    """

    ip_targets = _discover_ip_targets()
    ip_names = {name for name, _ in ip_targets}
    forest = _discover_forest_entities()

    if not forest:
        console.print(
            "\n  [dim]No entities found in the source tree.[/]\n"
        )
        return

    table = Table(
        title="🔍 Synthesis Target Discovery",
        title_style="bold cyan",
        show_lines=False,
        padding=(0, 1),
    )
    table.add_column("Entity", style="cyan", min_width=25)
    table.add_column("Type", width=12)
    table.add_column("ip.yml", justify="center", width=8)
    table.add_column("Files", justify="right", width=5)

    registered = 0
    candidates = 0

    for name, is_top, file_count in forest:
        type_str = "top-level" if is_top else "[dim]submodule[/]"
        if name in ip_names:
            ip_str = "[green]✅[/]"
            registered += 1
        else:
            ip_str = "[dim]—[/]"
            if is_top:
                candidates += 1

        table.add_row(name, type_str, ip_str, str(file_count))

    console.print()
    console.print(table)

    console.print(
        f"\n  [green]{registered}[/] registered in ip.yml · "
        f"[yellow]{candidates}[/] top-level candidates without ip.yml\n"
    )

    if candidates > 0:
        cli_name = _resolve_cli_name()
        console.print(
            f"  [dim]Tip: use '{cli_name} ip init <name>' to create "
            f"an ip.yml for uncovered entities.[/]\n"
        )


# ── rr synth clear ────────────────────────────────────────────────

@synth_group.command(name="clear")
@click.argument("module", required=False, default=None)
def synth_clear(module):
    """Clear cached synthesis results (one module or all)."""
    tracker = _get_tracker()
    if module:
        tracker.clear(module)
        console.print(f"🗑️  Cleared synthesis cache for [cyan]{module}[/]")
    else:
        tracker.clear()
        console.print("🗑️  Cleared all synthesis cache entries")


# ── rr synth report ───────────────────────────────────────────────

_VENDOR_DISPLAY = {
    "xilinx": "Xilinx",
    "altera": "Altera",
    "lattice": "Lattice",
    "microchip": "Microchip",
}


def _format_duration(seconds):
    """Format seconds into a human-readable duration string."""
    if seconds < 60:
        return f"{seconds:.1f}s"
    minutes = int(seconds // 60)
    secs = seconds % 60
    return f"{minutes}m {secs:.0f}s"


def _print_build_report(report):
    """Pretty-print a BuildReport in the rich CLI style.

    Matches the aesthetics of the design mockup with phase bars,
    resource summary, and timing data.
    """
    console.print()  # blank line

    # Header
    tool_display = report.tool_name or f"{_VENDOR_DISPLAY.get(report.vendor, report.vendor)} Tools"
    console.print(f"🔨 [bold cyan]RouteRTL Synthesis — {tool_display}[/]")
    console.print()

    if report.top_module:
        top_line = f"  Target: [cyan]{report.top_module}[/]"
        if report.part:
            top_line += f" ({report.part})"
        console.print(top_line)

    vendor_display = _VENDOR_DISPLAY.get(report.vendor, report.vendor)
    if vendor_display:
        console.print(f"  Vendor: {vendor_display} (from project.yml)")

    # Phases
    if report.phases:
        console.print()
        for i, phase in enumerate(report.phases, 1):
            icon = "✅" if phase.passed else "❌"
            dur_str = _format_duration(phase.duration_s) if phase.duration_s > 0 else ""
            name_padded = f"Phase {i}: {phase.name}"
            dots = "." * max(2, 42 - len(name_padded))
            if dur_str:
                console.print(f"  {name_padded} {dots} {icon}  {dur_str:>8}")
            else:
                console.print(f"  {name_padded} {dots} {icon}")

    # Resource Summary
    if report.resources:
        console.print()
        console.print("  [bold]Resource Summary[/]")
        for key, entry in report.resources.items():
            used_str = f"{entry.used:,}"
            if entry.available:
                pct = entry.pct
                console.print(
                    f"      {key + ':':<8} {used_str:>6} / {entry.available:,}  "
                    f"({pct:.1f}%)"
                )
            else:
                console.print(f"      {key + ':':<8} {used_str:>6}")

    # Timing
    if report.timing.fmax_mhz > 0:
        clk_info = f" ({report.timing.clock_name})" if report.timing.clock_name else ""
        console.print(f"      {'Fmax:':<8} {report.timing.fmax_mhz:.1f} MHz{clk_info}")

    if report.timing.wns_ns != 0.0:
        wns_color = "green" if report.timing.wns_ns >= 0 else "red"
        console.print(
            f"      {'WNS:':<8} [{wns_color}]{report.timing.wns_ns:+.3f} ns[/]"
        )

    console.print()


@synth_group.command(name="report")
@click.option("--json", "as_json", is_flag=True, help="Machine-readable JSON output.")
def synth_report(as_json):
    """Display the latest build report.

    Parses vendor-specific synthesis/implementation reports from the
    project's ``reports/`` directory and displays a unified summary.

    Uses structured JSON (from TCL emitters) when available, falling
    back to native vendor report files.
    """
    vendor, part, _target = _get_hardware_identity()
    report = _try_parse_report(vendor)

    if report is None:
        console.print(
            "\n  [dim]No build reports found in this project.[/]\n"
            "  Run [cyan]rr synth run[/] to generate a build report.\n"
        )
        return

    # Enrich with project.yml data if not already set
    if not report.part and part:
        report.part = part

    if as_json:
        click.echo(json.dumps(report.to_dict(), indent=2))
        return

    _print_build_report(report)


# ── Constraint Check ─────────────────────────────────────────────


def _check_synth_artifacts_exist(vendor: str, root: Path, project_path: str) -> tuple[bool, str]:
    """Check if synthesis artifacts exist. Returns (exists, path_checked)."""
    if vendor == "xilinx":
        dcp = root / "dcp" / "synthesis.dcp"
        return dcp.exists(), str(dcp)
    elif vendor == "altera":
        qpf_files = list((root / project_path).glob("*.qpf"))
        if not qpf_files:
            return False, str(root / project_path / "*.qpf")
        project_name = qpf_files[0].stem
        map_rpt = root / project_path / "output_files" / f"{project_name}.map.rpt"
        return map_rpt.exists(), str(map_rpt)
    # Lattice/Microchip: check for project file
    ext_map = {"lattice": "*.rdf", "microchip": "*.prjx"}
    pattern = ext_map.get(vendor, "*.prj")
    found = list((root / project_path).glob(pattern))
    return len(found) > 0, str(root / project_path / pattern)


def _check_staleness(vendor: str, root: Path) -> bool:
    """Return True if synthesis artifacts are stale (sources newer than artifacts).

    Compares the synthesis artifact mtime against source and constraint files
    listed in build_env.mk.
    """
    # Find the artifact to check
    if vendor == "xilinx":
        artifact = root / "dcp" / "synthesis.dcp"
    elif vendor == "altera":
        # Use the map report as the synthesis timestamp proxy
        project_dir = root / "project"
        qpf_files = list(project_dir.glob("*.qpf"))
        if not qpf_files:
            return True
        name = qpf_files[0].stem
        artifact = project_dir / "output_files" / f"{name}.map.rpt"
    else:
        return False  # Can't check staleness for unsupported vendors

    if not artifact.exists():
        return True

    artifact_mtime = artifact.stat().st_mtime

    # Read source and constraint files from build_env.mk
    build_env_file = root / "build_env.mk"
    if not build_env_file.exists():
        return False

    src_files = []
    with cli_resilient_block("staleness file list"):
        text = build_env_file.read_text()
        for line in text.splitlines():
            for key in ("SYN_FILES", "XDC_FILES", "SDC_FILES"):
                if line.startswith(f"{key}=") or line.startswith(f"{key} ="):
                    files_str = line.split("=", 1)[1].strip()
                    src_files.extend(files_str.split())

    for src in src_files:
        src_path = root / src
        if src_path.exists() and src_path.stat().st_mtime > artifact_mtime:
            return True

    return False


def _print_check_report(report) -> None:
    """Render the constraint check report with Rich formatting."""
    console.print(
        f"\n🔍 [bold]Post-Synthesis Constraint Check[/] — "
        f"[dim]{report.tool_name}[/]\n"
    )

    errors = report.errors()
    warnings = report.warnings()
    passed = report.passed_checks()

    for item in errors:
        detail_str = f"{item.count} found" if item.count else "failed"
        console.print(f"  [red]❌ {item.name:<40}[/] [red]{detail_str}[/]")
        for d in item.details[:10]:
            console.print(f"     [dim]• {d}[/]")

    for item in warnings:
        detail_str = f"{item.count} found" if item.count else "issues"
        console.print(f"  [yellow]⚠️  {item.name:<40}[/] [yellow]{detail_str}[/]")
        for d in item.details[:10]:
            console.print(f"     [dim]• {d}[/]")

    for item in passed:
        if item.details:
            console.print(f"  [green]✅ {item.name:<40}[/] [dim]{item.details[0]}[/]")
        else:
            console.print(f"  [green]✅ {item.name:<40}[/] [dim]passed[/]")

    n_err = len(errors)
    n_warn = len(warnings)
    n_pass = len(passed)

    color = "green" if n_err == 0 and n_warn == 0 else "red" if n_err > 0 else "yellow"
    console.print(
        f"\n  [{color}]Result: {n_err} error(s) · {n_warn} warning(s) · {n_pass} passed[/]\n"
    )


@synth_group.command(name="check")
@click.option("--json", "as_json", is_flag=True, help="Machine-readable JSON output.")
def synth_check(as_json):
    """Validate timing constraints against synthesis artifacts.

    Runs post-synthesis STA and CDC analysis WITHOUT re-synthesizing.
    Catches missing constraints early, before expensive Place & Route.

    \b
    Requires existing synthesis artifacts from a prior 'rr synth run'.
    Exits non-zero on any constraint error or warning.

    \b
    Examples:
        rr synth check              # validate constraints
        rr synth check --json       # machine-readable output
    """
    vendor, part, target = _get_hardware_identity()
    if not vendor:
        console.print(
            "❌ [red]Cannot determine vendor — is project.yml present?[/]\n"
            "   Run [cyan]rr init[/] to create a project."
        )
        sys.exit(1)

    root = Path.cwd()

    # Load project_path from config
    project_path = "project"
    with cli_resilient_block("project path resolution"):
        config = _load_project_yml()
        if config:
            ps = config.get("project", {})
            if isinstance(ps, dict) and "path" in ps:
                project_path = ps["path"]

    # ── Vendor support check ──
    _supported_vendors = ("xilinx", "altera")
    if vendor not in _supported_vendors:
        console.print(
            f"  [yellow]⚠️  Post-synthesis constraint checking is not yet supported "
            f"for [bold]{vendor}[/bold] projects.[/]\n"
            f"     Supported vendors: {', '.join(_supported_vendors)}.\n"
        )
        sys.exit(0)

    # ── Artifact existence check ──
    exists, artifact_path = _check_synth_artifacts_exist(vendor, root, project_path)
    if not exists:
        console.print(
            f"❌ [red]Synthesis artifacts not found.[/]\n"
            f"   Expected: [cyan]{artifact_path}[/]\n"
            f"   Run [cyan]rr synth run[/] first."
        )
        sys.exit(1)

    # ── Staleness check ──
    is_stale = _check_staleness(vendor, root)
    if is_stale:
        console.print(
            "  [yellow]⚠️  Synthesis artifacts are STALE[/] "
            "[dim](sources modified since last synth)[/]\n"
            "     Run [cyan]rr synth run[/] first to get accurate results.\n"
        )

    # ── Run vendor STA ──
    try:
        from sdk.cli.vendor_dispatch import VendorDispatch

        dispatch = VendorDispatch.from_project()
        rc = dispatch.synth_check()
        if rc != 0:
            console.print("❌ [red]Vendor STA tool returned an error.[/]")
            sys.exit(rc)
    except (ImportError, Exception) as exc:
        console.print(f"❌ [red]Failed to run constraint checks: {exc}[/]")
        sys.exit(1)

    # ── Parse results ──
    report_path = root / "reports" / "synth_check_report.json"
    if not report_path.exists():
        console.print(
            "❌ [red]Check report not generated.[/]\n"
            "   The vendor tool ran but did not produce a report."
        )
        sys.exit(1)

    from sdk.engine.synth_check_parser import CheckReport

    report = CheckReport.from_json(report_path)

    # ── Output ──
    if as_json:
        click.echo(report_path.read_text())
        if report.has_issues() or is_stale:
            sys.exit(1)
        return

    _print_check_report(report)

    if report.has_issues() or is_stale:
        sys.exit(1)


def _print_synth_plan_for_ip(ip_dir: Path) -> None:
    """Render a standalone synth plan for *ip_dir* and exit accordingly.

    RTL-P2.435 MVP — reports whether ip.yml declares enough to drive a
    vendor flow (top module, hardware identity, HDL sources).  Exits 0
    when ready, 1 when any required field is missing.
    """
    from sdk.cli.ip_standalone import (
        IpStandaloneError,
        build_synth_plan,
    )

    try:
        plan = build_synth_plan(ip_dir)
    except IpStandaloneError as exc:
        console.print(f"[red]❌ {exc}[/]")
        sys.exit(1)

    console.print(f"\n🧱 [bold]Synth plan for[/] [cyan]{ip_dir}[/]")
    console.print(f"   top_module     : [cyan]{plan.top_module or '(missing)'}[/]")
    console.print(f"   vendor / part  : [cyan]{plan.vendor or '(missing)'}[/] "
                  f"/ [cyan]{plan.part or '(missing)'}[/]")
    console.print(f"   tool_version   : {plan.tool_version or '—'}")
    console.print(f"   HDL sources    : {len(plan.hdl_sources)} file(s)")
    console.print(f"   XDC sources    : {len(plan.xdc_sources)} file(s)")
    if plan.tcl_hooks:
        hooks_summary = ", ".join(
            f"{stage}({len(paths)})" for stage, paths in plan.tcl_hooks.items()
        )
        console.print(f"   TCL hooks      : {hooks_summary}")
    else:
        console.print("   TCL hooks      : —")

    if plan.ready:
        console.print("\n✅ [green]Synth-ready.[/] ip.yml declares the required "
                      "fields for standalone synthesis.")
        console.print("   [dim]Full standalone build path is a follow-up — for now "
                      "run inside a project.yml to actually spawn the vendor flow.[/]")
        return

    missing = []
    if not plan.top_module:
        missing.append("hdl.top_module")
    if not plan.vendor:
        missing.append("build.hardware.vendor")
    if not plan.part:
        missing.append("build.hardware.part")
    if not plan.hdl_sources:
        missing.append("HDL sources (build.synthesis.sources or hdl.files)")

    console.print(
        f"\n❌ [red]Not synth-ready.[/] Missing: {', '.join(missing)}"
    )
    sys.exit(1)
