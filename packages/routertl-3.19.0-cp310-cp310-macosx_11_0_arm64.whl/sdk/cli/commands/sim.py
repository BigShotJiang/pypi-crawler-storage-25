# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

import json
import os
import subprocess
import sys
from pathlib import Path

# Lazy import for git_utils — available when running from SDK root or when
# sdk/engine is on sys.path.  Fail-open: if unavailable, all
# discovered files pass through unfiltered.
try:
    from sdk.engine.git_utils import filter_git_tracked as _filter_tracked
except ImportError:
    try:
        # Direct import when project-manager is already on sys.path
        from git_utils import filter_git_tracked as _filter_tracked
    except ImportError:
        _filter_tracked = None

import rich_click as click
from rich.prompt import IntPrompt
from rich.table import Table

from sdk.cli.console import console
from sdk.cli.env_setup import resolve_sdk_script, resolve_sim_dir, setup_sim_env
from sdk.cli.resilience import cli_resilient, cli_resilient_block
from sdk.cli.sdk_root import resolve_sdk_root

# Waveform output directories — searched in priority order
_WAVE_DIRS = (
    Path("sim") / "waves",
    Path("sim") / "cocotb" / "waves",
    Path("sim_build"),
)


def _venv_python() -> str:
    """Return the venv Python if VIRTUAL_ENV is set, else sys.executable.

    Handles the case where ~/.local/bin shadows .venv/bin in PATH —
    sys.executable may point to the wrong Python even when the venv is active.
    """
    venv = os.environ.get("VIRTUAL_ENV")
    if venv:
        venv_py = Path(venv) / "bin" / "python3"
        if venv_py.exists():
            return str(venv_py)
    return sys.executable


def _venv_inactive() -> bool:
    """True when .venv/ exists in CWD but VIRTUAL_ENV is unset."""
    return Path(".venv").is_dir() and not os.environ.get("VIRTUAL_ENV")


def _warn_venv_inactive():
    """Print a yellow banner when the project .venv isn't activated.

    Used by commands whose early stages are safe to run against the host
    Python (discovery, menu, history) but want to nudge the user to
    activate before the simulator subprocess fires.
    """
    if _venv_inactive():
        console.print(
            "[yellow]⚠️  Your project has a .venv but it is not activated.[/]\n"
            "   [dim]Activate before running simulations: "
            "[cyan]source .venv/bin/activate[/]"
        )


def _check_venv_active():
    """Exit with guidance if a .venv exists but isn't activated.

    Use this gate immediately before invoking a simulator subprocess —
    cocotb / pyuvm imports resolve against the current interpreter, so
    running against the host Python typically produces confusing
    module-not-found failures later.
    """
    if _venv_inactive():
        console.print(
            "[yellow]Your project has a .venv but it is not activated.[/]\n"
            "  Run: [cyan]source .venv/bin/activate[/]\n"
            "  Then retry your command."
        )
        sys.exit(1)


def get_discovered_tests():
    """Discover all cocotb test files from the configured simulation directory."""
    if not os.path.exists("project.yml"):
        return []

    sim_dir = "sim/cocotb/tests"  # default; overridden by project.yml if parseable
    with cli_resilient_block("simulation config loading"):
        from sdk.cli.project_config import load_project_config

        config = load_project_config()
        if not isinstance(config, dict):
            config = {}
        sim_cfg = config.get("simulation") or {}
        if not isinstance(sim_cfg, dict):
            sim_cfg = {}
        sim_dir = sim_cfg.get("test_dir", sim_dir)

    sim_path = Path(sim_dir)
    if not sim_path.exists():
        return []

    candidates = list(sim_path.rglob("test_*.py"))

    # Filter out untracked files — prevents WIP test_*.py from appearing
    # in the interactive menu or fuzzy matching (fail-open)
    if _filter_tracked is not None:
        candidates = _filter_tracked(candidates)

    # Filter excluded directories (from simulation.exclude_dirs)
    from sdk.cli.env_setup import filter_excluded_test_files, is_cocotb_test, resolve_sim_exclude_dirs

    exclude_dirs = resolve_sim_exclude_dirs()
    candidates = filter_excluded_test_files(candidates, sim_path, exclude_dirs)

    # Only include files that are actually cocotb tests
    candidates = [f for f in candidates if is_cocotb_test(f)]

    tests = []
    for file in candidates:
        tests.append(file.stem)  # get filename without extension
    return sorted(list(set(tests)))


def _complete_testbench(ctx, param, incomplete):
    """Shell completion callback: returns discovered test names."""
    tests = get_discovered_tests()
    return [t for t in tests if t.startswith(incomplete)]


@cli_resilient("rr sim viewlog completion", default=[])
def _complete_viewlog_name(ctx, param, incomplete):
    """RTL-P2.427: completion for rr sim viewlog TEST_NAME.

    Walks the standard sim log locations and returns log stems matching
    the prefix.  Must never error — wrapped in cli_resilient.
    """
    candidates: set[str] = set()
    for root in (
        Path("sim") / "cocotb" / "logs",
        Path("sim") / "logs",
    ):
        if not root.is_dir():
            continue
        for p in root.glob("*.log"):
            candidates.add(p.stem)
        for p in root.glob("*/*.log"):
            # Nested layout: sim/cocotb/logs/<test>/<test>.log
            candidates.add(p.parent.name)
    return sorted(n for n in candidates if n.startswith(incomplete))


@cli_resilient("rr sim testgen completion", default=[])
def _complete_testgen_module(ctx, param, incomplete):
    """RTL-P2.427: completion for rr sim testgen MODULE.

    Enumerates VHDL unit names under the project's source directories.
    Must never error — wrapped in cli_resilient.
    """
    from sdk.cli.env_setup import resolve_src_dirs
    candidates: set[str] = set()
    with cli_resilient_block("resolve_src_dirs in testgen completion"):
        src_dirs = resolve_src_dirs()
    if not src_dirs:
        src_dirs = ["src"]
    for d in src_dirs:
        dp = Path(d)
        if not dp.is_dir():
            continue
        for p in dp.rglob("*.vhd"):
            candidates.add(p.stem)
        for p in dp.rglob("*.v"):
            candidates.add(p.stem)
        for p in dp.rglob("*.sv"):
            candidates.add(p.stem)
    return sorted(n for n in candidates if n.startswith(incomplete))


def _resolve_tags() -> dict:
    """Read simulation.tags from project.yml.

    Returns
    -------
    dict[str, list[str]]
        Mapping of tag name to list of test module names.
    """
    if not os.path.exists("project.yml"):
        return {}
    with cli_resilient_block("simulation tags loading"):
        from sdk.cli.project_config import load_project_config

        config = load_project_config()
        sim_cfg = config.get("simulation") or {}
        if not isinstance(sim_cfg, dict):
            sim_cfg = {}
        tags = sim_cfg.get("tags") or {}
        return tags if isinstance(tags, dict) else {}
    return {}


def _run_sim_direct(
    module: str | None = None,
    *,
    waves: bool = False,
    seed: int | None = None,
    generics: dict | None = None,
) -> int:
    """Run simulation by calling run_tests.py directly (no Make required).

    Returns the process exit code.
    """
    # Run pre-sim hooks
    try:
        from sdk.cli.engine_dispatch import run_engine_script
        with cli_resilient_block("pre-sim hooks"):
            run_engine_script("run_hooks.py", ["--stage", "pre_sim", "--project", "project.yml", "--root", "."])
    except (ImportError, Exception):
        pass

    script = resolve_sdk_script("project-manager/run_tests.py")
    if script is None:
        # Fallback: delegate to Make
        return _run_sim_make(module, waves=waves, seed=seed)

    env = setup_sim_env(seed=seed)

    # Pass CLI generics via env var — run_simulation() merges these
    # at highest priority (above project.yml and Python-level defaults).
    if generics:
        import json as _json
        env["RR_SIM_GENERICS"] = _json.dumps(generics)

    sim_dir = str(resolve_sim_dir())

    cmd = [_venv_python(), str(script), "--dir", sim_dir]
    if module:
        cmd.extend(["--pattern", f"{module}.py"])

    # Pass excluded directories from project.yml
    from sdk.cli.env_setup import resolve_sim_exclude_dirs

    for exc in resolve_sim_exclude_dirs():
        cmd.extend(["--exclude-dir", exc])

    cmd.append("--cocotb-only")

    try:
        result = subprocess.run(cmd, env=env, check=False)
        return result.returncode
    except FileNotFoundError:
        console.print("❌ [red]Error:[/] Python interpreter not found.")
        sys.exit(1)


def _run_sim_make(module: str | None = None, *, waves: bool = False, seed: int | None = None) -> int:
    """Fallback: delegate simulation to Make."""
    if module:
        cmd = ["make", "sim", f"MODULE={module}"]
    else:
        cmd = ["make", "simulation"]
    if waves:
        cmd.append("WAVES=1")
    if seed is not None:
        cmd.append(f"RANDOM_SEED={seed}")
    try:
        result = subprocess.run(cmd, check=False)
        return result.returncode
    except FileNotFoundError:
        console.print("❌ [red]'make' not found.[/]")
        sys.exit(1)


def _run_make_fallback(target: str, *args):
    """Fallback: delegate a target to Make."""
    cmd = ["make", target, *args]
    try:
        result = subprocess.run(cmd, check=False)
        if result.returncode != 0:
            console.print(f"\n❌ [red]Command failed (Make exit code: {result.returncode})[/]")
            sys.exit(result.returncode)
    except FileNotFoundError:
        console.print("❌ [red]Error:[/] 'make' not found.")
        sys.exit(1)


def _run_tag(tag_name: str, waves: bool = False, seed: int = None):
    """Run all tests associated with *tag_name* from simulation.tags."""
    tags = _resolve_tags()

    if not tags:
        console.print("⚠️  [yellow]No simulation.tags section found in project.yml.[/]")
        console.print("   Add a tags mapping under 'simulation' in project.yml:")
        console.print("   [dim]simulation:[/]")
        console.print("   [dim]  tags:[/]")
        console.print("   [dim]    smoke: \\[test_a, test_b][/]")
        sys.exit(1)

    if tag_name not in tags:
        available = ", ".join(sorted(tags.keys())) if tags else "(none)"
        console.print(f"❌ [red]Tag '{tag_name}' not found.[/]")
        console.print(f"   Available tags: [cyan]{available}[/]")
        sys.exit(1)

    tests = tags[tag_name]
    if not tests:
        console.print(f"⚠️  [yellow]Tag '{tag_name}' is empty — no tests to run.[/]")
        return

    console.print(f"\n🏷️  [cyan]Running tag '{tag_name}' — {len(tests)} test(s)[/]\n")

    failures = []
    for i, module in enumerate(tests, 1):
        console.print(f"  [{i}/{len(tests)}] [blue]{module}[/]")
        rc = _run_sim_direct(module, waves=waves, seed=seed)
        if rc != 0:
            failures.append(module)
            console.print("        [red]❌ FAILED[/]")
        else:
            console.print("        [green]✅ PASSED[/]")

    # Summary
    console.print(f"\n{'─' * 50}")
    passed = len(tests) - len(failures)
    console.print(
        f"🏷️  Tag '{tag_name}': [green]{passed} passed[/], [red]{len(failures)} failed[/]"
    )
    if failures:
        console.print(f"   Failed: [red]{', '.join(failures)}[/]")
        sys.exit(1)


class _SimGroup(click.Group):
    """Click group that falls back to the ``run`` subcommand.

    Allows ``rr sim test_foo`` (positional testbench name) to coexist with
    ``rr sim testgen`` (subcommand).  If the first arg isn't a registered
    subcommand, the entire argv is forwarded to the ``run`` subcommand.
    """

    def parse_args(self, ctx, args):
        # Let --help show the group help, not the default subcommand's help
        if not args or args == ["--help"] or args == ["-h"]:
            return super().parse_args(ctx, args)

        # If the first non-option arg matches a registered subcommand, let
        # click's normal group dispatch handle it.  Otherwise, prepend "run"
        # so the default subcommand receives all args.
        if args[0].startswith("-"):
            # Only options (e.g. --all, --history) → default to "run"
            args = ["run"] + args
        elif args[0] not in self.commands:
            # Positional arg that isn't a subcommand → testbench name
            args = ["run"] + args
        return super().parse_args(ctx, args)


def _print_target_sources() -> None:
    """Print the HDL compile set that ``run_simulation`` would auto-compose
    from the active target yml (RTL-P2.410).

    Each file is tagged with the yml section it came from (sources.syn
    or sources.sim) so users immediately see which bucket contributed
    what.  Exits with a clear error when the target yml declares no
    sources AND no explicit override is supplied — mirrors the
    vacuous-PASS guard that ``run_simulation`` raises (P2.356).
    """

    if not Path("project.yml").exists():
        console.print("❌ [red]No project.yml in the current directory.[/]")
        sys.exit(1)

    # Reimplement the split locally rather than calling the cython-
    # compiled _resolve_target_hdl_sources — that helper's PROJECT_ROOT
    # is import-time-frozen and misbehaves when this CLI is driven
    # from a tmp_path in tests (or any non-standard CWD).  Logic mirrors
    # routertl_core/sim/simulation.py::_resolve_target_hdl_sources.
    from sdk.cli.project_config import get_active_target, load_project_config

    try:
        cfg = load_project_config()
    except (OSError, ValueError, FileNotFoundError) as e:
        console.print(f"❌ [red]Could not load project config:[/] {e}")
        sys.exit(1)
    if not isinstance(cfg, dict):
        cfg = {}

    sources = cfg.get("sources") or {}
    if not isinstance(sources, dict):
        sources = {}
    syn = list(sources.get("syn") or [])
    sim = list(sources.get("sim") or [])

    # Dedupe preserving order, syn first — matches the compiled helper.
    combined: list[str] = []
    seen: set[str] = set()
    for p in syn + sim:
        if not isinstance(p, str) or p in seen:
            continue
        seen.add(p)
        combined.append(p)

    vhdl = [p for p in combined if p.lower().endswith((".vhd", ".vhdl"))]
    verilog = [p for p in combined if p.lower().endswith((".v", ".sv", ".svh"))]

    sim_cfg = cfg.get("simulation") or {}
    proj_cfg = cfg.get("project") or {}
    if isinstance(sim_cfg, dict) and sim_cfg.get("work_lib"):
        work_lib = str(sim_cfg["work_lib"]).strip()
        work_lib_source = "simulation.work_lib"
    elif isinstance(proj_cfg, dict) and proj_cfg.get("name"):
        work_lib = str(proj_cfg["name"]).strip()
        work_lib_source = "project.name"
    else:
        work_lib = "work"
        work_lib_source = "fallback default"

    libs = {work_lib: vhdl} if vhdl else {}
    hdl_sources = verilog

    syn_set = set(syn)
    sim_set = set(sim)

    def _origin_tag(path: str) -> str:
        if path in syn_set and path in sim_set:
            return "[dim]sources.syn+sim[/]"
        if path in sim_set:
            return "[dim]sources.sim[/]"
        return "[dim]sources.syn[/]"

    target_yml = get_active_target()
    tgt_label = target_yml if target_yml else "(self-contained project.yml)"
    console.print(f"\n🎯 [bold]Active target:[/] [cyan]{tgt_label}[/]")
    console.print(f"   [dim]work_lib:[/] [bold cyan]{work_lib}[/]  "
                  f"[dim](source: {work_lib_source})[/]")

    total_vhdl = sum(len(v) for v in libs.values())
    console.print(
        f"\n📚 [bold]custom_libraries[/] "
        f"([cyan]{total_vhdl}[/] VHDL file(s))"
    )
    if not libs:
        console.print("   [dim](none — no .vhd/.vhdl sources)[/]")
    for lib_name, files in libs.items():
        console.print(f"   [bold cyan]{lib_name}[/]")
        for f in files:
            console.print(f"     {f}  {_origin_tag(f)}")

    console.print(
        f"\n📄 [bold]hdl_sources[/] "
        f"([cyan]{len(hdl_sources)}[/] Verilog/SV file(s))"
    )
    if not hdl_sources:
        console.print("   [dim](none — no .v/.sv/.svh sources)[/]")
    for f in hdl_sources:
        console.print(f"   {f}  {_origin_tag(f)}")

    if not libs and not hdl_sources:
        console.print(
            "\n⚠  [yellow]Target yml declares no HDL sources.[/]  "
            "[dim]run_simulation would raise a ValueError here unless "
            "the test passes hdl_sources=[...] / custom_libraries={...} "
            "explicitly.[/]"
        )
        sys.exit(1)

    console.print()


def _run_sim_standalone(
    ip_dir: Path,
    testbench: str | None,
    seed: int | None,
    run_all: bool,
) -> None:
    """Drive cocotb from ip.yml with no wrapping project.yml (RTL-P2.434).

    Resolves the top, simulator, HDL sources, tests dir, and wave formats
    from the IP manifest (via :func:`sdk.cli.ip_standalone.build_sim_plan`)
    and hands them to :func:`routertl_core.sim.simulation.run_simulation`.
    """
    from sdk.cli.ip_standalone import (
        IpStandaloneError,
        build_sim_plan,
        cwd,
        discover_test_modules,
    )

    # venv gate: simulator subprocess spawns require an active venv on
    # our supported setups — fail loudly rather than confusing the user.
    _check_venv_active()

    try:
        plan = build_sim_plan(ip_dir)
    except IpStandaloneError as exc:
        console.print(f"[red]❌ {exc}[/]")
        sys.exit(1)

    available = discover_test_modules(plan.tests_dir)
    if not available:
        console.print(
            f"[red]❌ No test_*.py files under {plan.tests_dir}.[/]\n"
            "   Run [cyan]rr sim scaffold[/] from the IP root to "
            "generate stubs from requirements.yml."
        )
        sys.exit(1)

    # Module resolution: explicit arg → --all → first-available.
    if testbench:
        candidate = testbench[:-3] if testbench.endswith(".py") else testbench
        if candidate in available:
            module = candidate
        else:
            matches = [m for m in available if candidate in m]
            if len(matches) == 1:
                module = matches[0]
                console.print(f"   [dim]ℹ️  Resolved '{testbench}' → {module}[/]")
            elif not matches:
                console.print(
                    f"[red]❌ No test matching '{testbench}' — available: "
                    f"{', '.join(available)}[/]"
                )
                sys.exit(1)
            else:
                console.print(
                    f"[red]❌ Ambiguous '{testbench}' — matches: "
                    f"{', '.join(matches)}.  Specify a full name.[/]"
                )
                sys.exit(1)
    elif run_all:
        # MVP: run each module sequentially, fail-fast on the first error.
        module = None
    else:
        module = available[0]
        if len(available) > 1:
            console.print(
                f"   [dim]ℹ️  Multiple tests — picking [cyan]{module}[/] "
                "(first).  Pass a name explicitly for the others.[/]"
            )

    console.print(
        f"🧪 [blue]Standalone IP simulation:[/] "
        f"[cyan]{plan.top_level}[/] / "
        f"[cyan]{plan.simulator}[/] / "
        f"[dim]{plan.tests_dir}[/]"
    )

    from routertl_core.sim.simulation import run_simulation

    # RTL-P2.437: the ip.yml-declared tests_dir is NOT covered by
    # run_simulation's TESTS_PATH rglob (that walks routertl's own sim
    # tree).  Inject it here so cocotb's bare-module import resolves the
    # client IP's test file.  cocotb_tools/runner propagates sys.path
    # into the simulator subprocess via PYTHONPATH, so this takes effect.
    if str(plan.tests_dir) not in sys.path:
        sys.path.insert(0, str(plan.tests_dir))

    modules_to_run = [module] if module else available
    failed = 0
    with cwd(ip_dir):
        for mod in modules_to_run:
            console.print(f"   → [yellow]{mod}[/]")
            try:
                run_simulation(
                    top_level=plan.top_level,
                    module=mod,
                    top_level_lang=plan.top_level_lang,
                    hdl_sources=list(plan.hdl_sources),
                    simulator=plan.simulator,
                    seed=seed,
                    wave_formats=(
                        list(plan.wave_formats) if plan.wave_formats else None
                    ),
                )
            except (RuntimeError, FileNotFoundError, subprocess.CalledProcessError) as exc:
                console.print(f"[red]❌ {mod} failed: {exc}[/]")
                failed += 1
                if not run_all:
                    sys.exit(1)

    if failed:
        console.print(
            f"\n[red]standalone sim failed:[/] "
            f"{failed} of {len(modules_to_run)} test(s) failed."
        )
        sys.exit(1)
    console.print(
        f"\n[green]standalone sim passed:[/] "
        f"{len(modules_to_run)} test(s) OK."
    )


@click.group(name="sim", cls=_SimGroup)
def sim_group():
    """Simulation commands — run tests, generate stubs, view history."""


@sim_group.command(name="run")
@click.argument("testbench", required=False, shell_complete=_complete_testbench)
@click.option("--view", is_flag=True, help="Open waveform viewer after simulation completes")
@click.option("--waves", is_flag=True, hidden=True, help="[Deprecated] Alias for --view")
@click.option("--all", "run_all", is_flag=True, help="Run all discovered tests")
@click.option("--seed", type=int, default=None, help="Set random seed for reproducible simulation")
@click.option("--history", "show_history", is_flag=True, help="Show recent simulation history")
@click.option("--tag", "tag_name", default=None, help="Run a group of tests defined in simulation.tags in project.yml.")
@click.option("--clean", "-c", is_flag=True, help="Remove cached simulation artifacts first.")
@click.option("--locked", is_flag=True, help="Verify routertl.lock before running; abort on mismatch.")
@click.option(
    "-g", "--generic", "generics_raw", multiple=True,
    help="Override a generic/parameter: -g KEY=VALUE (repeatable).",
)
@click.option(
    "--show", "show_raw", default=None,
    help="Comma-separated signal name(s) / globs to auto-display in RouteWave. "
         "Requires --view/--waves. Example: --show '*valid,*ready,top.uart_*'",
)
@click.option(
    "--print-sources", "print_sources", is_flag=True, default=False,
    help="Print the HDL compile set auto-composed from the active target "
         "yml (sources.syn + sources.sim), then exit without running the "
         "simulator.  Useful for debugging 'why is this file not in my "
         "compile?' (RTL-P2.410).",
)
@click.option(
    "--ip", "ip_standalone_dir", default=None,
    type=click.Path(exists=True, file_okay=False, dir_okay=True, path_type=Path),
    help="Run against a single IP's ip.yml as a mini-project (RTL-P2.434). "
         "No wrapping project.yml required.  ip.yml must declare hdl.top_sim "
         "(or hdl.top_module), at least one HDL source, and contain a "
         "tests/ directory (or build.simulation.test_dir).",
)
def sim_command(testbench, view, waves, run_all, seed, show_history, tag_name, clean, locked, generics_raw, show_raw, print_sources, ip_standalone_dir):
    """
    Run a cocotb simulation testbench.

    If TESTBENCH is not provided, an interactive menu will appear allowing you to select
    from discovered tests in the project.
    """
    # RTL-P2.410: --print-sources short-circuits before anything else —
    # purely observational, no backend invocation, no venv gate.
    if print_sources:
        _print_target_sources()
        return

    # RTL-P2.434: --ip takes over the whole command and drives cocotb
    # directly from the IP's ip.yml (mini-project workflow).  No
    # wrapping project.yml, no target pointer.
    if ip_standalone_dir is not None:
        _run_sim_standalone(
            ip_standalone_dir,
            testbench=testbench,
            seed=seed,
            run_all=run_all,
        )
        return

    # Soft-warn at entry: the menu / --history / --clean paths don't need
    # venv, so we let them run and nudge the user.  A hard abort happens
    # later, right before the simulator subprocess is spawned (see below).
    _warn_venv_inactive()

    # ── Lockfile guard ──
    if locked:
        from sdk.cli.commands.lock import enforce_locked
        enforce_locked("sim")

    # Merge --view and --waves (deprecated alias)
    open_viewer = view or waves

    # LT-P2.54: Parse --show "pat1,pat2,..." into a pattern list. Only
    # meaningful alongside --view/--waves; warn otherwise so a silent typo
    # doesn't leave the user wondering why signals aren't showing up.
    show_patterns = None
    if show_raw:
        show_patterns = [p.strip() for p in show_raw.split(",") if p.strip()]
        if show_patterns and not open_viewer:
            console.print(
                "⚠️  [yellow]--show was given without --view/--waves — ignored.[/]"
            )
            show_patterns = None

    # ── Parse -g/--generic KEY=VALUE pairs ──
    cli_generics = {}
    for raw in generics_raw:
        if "=" not in raw:
            console.print(f"❌ [red]Invalid generic '{raw}' — expected KEY=VALUE[/]")
            sys.exit(1)
        key, _, val = raw.partition("=")
        # Auto-convert numeric values
        try:
            val = int(val)
        except ValueError:
            try:
                val = float(val)
            except ValueError:
                # Keep as string — covers booleans like "true"/"false" too
                if val.lower() in ("true", "false"):
                    val = val.lower() == "true"
        cli_generics[key.strip()] = val
    sim_generics = cli_generics or None

    # ── Handle --clean flag ──
    if clean:
        import shutil

        for cache_dir in ["sim_build", "work"]:
            p = Path(cache_dir)
            if p.exists():
                shutil.rmtree(p, ignore_errors=True)
                console.print(f"🗑️  [dim]Removed {cache_dir}[/]")
        # GHDL entity directories
        for p in Path(".").glob("e~*"):
            if p.is_dir():
                shutil.rmtree(p, ignore_errors=True)
                console.print(f"🗑️  [dim]Removed {p}[/]")
    # ── Handle --history flag ──
    if show_history:
        _show_sim_history()
        return

    # ── Handle --tag flag ──
    if tag_name:
        _check_venv_active()  # tag runs simulators → venv required
        _run_tag(tag_name, open_viewer, seed)
        return

    # ── Determine the module to run ──
    module = None
    is_batch = False  # True when running all tests (selection 0, --all, --tag)

    if run_all:
        console.print("🧪 [blue]Running full simulation suite...[/]")
        is_batch = True
    elif not testbench:
        tests = get_discovered_tests()
        if not tests:
            console.print(
                "❌ [red]No tests found.[/]\n"
                "   Run [cyan]rr sim testgen[/] to generate test stubs, then try again."
            )
            sys.exit(1)
        elif not sys.stdin.isatty():
            console.print("🧪 [blue]Non-interactive mode — running full simulation suite...[/]")
            is_batch = True
        else:
            console.print("\n[bold cyan]🧪 Discovered Simulation Testbenches:[/bold cyan]")
            console.print("  [0] [bold yellow]Run ALL Tests (Regression)[/bold yellow]")
            for idx, tb in enumerate(tests, start=1):
                console.print(f"  [{idx}] {tb}")

            choice = IntPrompt.ask("\nSelect a testbench to run", choices=[str(i) for i in range(len(tests) + 1)])

            if choice == 0:
                is_batch = True  # module stays None → run all
            else:
                module = tests[choice - 1]
                console.print(f"🧪 [blue]Starting simulation for [cyan]{module}[/]...")
    else:
        # Strip the .py extension if the user accidentally provided it
        if testbench.endswith(".py"):
            testbench = testbench[:-3]
        if testbench.startswith("MODULE="):
            testbench = testbench[7:]

        # ── Fuzzy test name resolution ──
        if not testbench.startswith("test_"):
            all_tests = get_discovered_tests()
            matches = [t for t in all_tests if testbench in t]
            if len(matches) == 1:
                console.print(f"   [dim]ℹ️  Resolved '{testbench}' → {matches[0]}[/]")
                testbench = matches[0]
            elif len(matches) > 1:
                if sys.stdin.isatty():
                    console.print(f"\n[bold cyan]🧪 Multiple tests match '{testbench}':[/bold cyan]")
                    for idx, m in enumerate(matches, start=1):
                        console.print(f"  [{idx}] {m}")
                    choice = IntPrompt.ask(
                        "\nSelect a test to run",
                        choices=[str(i) for i in range(1, len(matches) + 1)],
                    )
                    testbench = matches[choice - 1]
                else:
                    console.print(
                        f"   [dim]ℹ️  Resolved '{testbench}' → {matches[0]} (first of {len(matches)} matches)[/]"
                    )
                    testbench = matches[0]

        module = testbench
        console.print(f"🧪 [blue]Starting simulation for [cyan]{module}[/]...")

    if seed is not None:
        console.print(f"🎲 [blue]Random seed: [cyan]{seed}[/]")
    if sim_generics:
        pairs = ", ".join(f"{k}={v}" for k, v in sim_generics.items())
        console.print(f"⚙️  [blue]Generics: [cyan]{pairs}[/]")

    # ── Execute simulation directly (no Make required) ──
    # Final gate: cocotb/pyuvm imports resolve against the current Python,
    # so a misactivated venv produces confusing failures downstream.
    _check_venv_active()
    rc = _run_sim_direct(module, waves=open_viewer, seed=seed, generics=sim_generics)

    if rc != 0:
        console.print(f"\n❌ [red]Simulation failed (exit code: {rc})[/]")
        _print_result_summary(module)
        if module:
            console.print(f"   [dim]Log: rr sim viewlog {module}[/]")
        # Open viewer even on failure — waves help debug the issue
        if open_viewer:
            _open_viewer_after_sim(module, is_batch, show_patterns=show_patterns)
        sys.exit(rc)

    console.print("\n✅ [green]Simulation completed successfully.[/]")
    _print_result_summary(module)

    # Run post-sim hooks
    try:
        from sdk.cli.engine_dispatch import run_engine_script
        with cli_resilient_block("post-sim hooks"):
            run_engine_script("run_hooks.py", ["--stage", "post_sim", "--project", "project.yml", "--root", "."])
    except (ImportError, Exception):
        pass

    # Print log file location so the user knows where to find detailed output
    if module:
        console.print(f"   [dim]Log: rr sim viewlog {module}[/]")

    if open_viewer:
        _open_viewer_after_sim(module, is_batch, show_patterns=show_patterns)


def _get_results_dir():
    """Locate the simulation results directory."""
    if os.path.exists("project.yml"):
        return Path("sim") / "results"
    from sdk.cli.sdk_root import resolve_sdk_root

    sdk = resolve_sdk_root()
    if sdk:
        return sdk / "sim" / "cocotb" / "results"
    return Path("sim") / "results"


def _print_result_summary(module=None):
    """Print a one-line summary from the latest simulation results."""
    results_dir = _get_results_dir()
    history_path = results_dir / "history.jsonl"

    if not history_path.exists():
        return

    try:
        with open(history_path, "r") as f:
            lines = f.readlines()
        if not lines:
            return

        if module:
            # Single test mode — show the last matching entry
            entry = json.loads(lines[-1].strip())
            if entry.get("module") != module:
                return
            entries = [entry]
        else:
            # Regression mode — aggregate all entries from the same run.
            # Entries from a single regression share a similar timestamp
            # (within 5 minutes of the last entry).
            from datetime import datetime, timedelta

            last = json.loads(lines[-1].strip())
            last_ts = datetime.fromisoformat(last["timestamp"])
            cutoff = last_ts - timedelta(minutes=5)

            entries = []
            for line in reversed(lines):
                line = line.strip()
                if not line:
                    continue
                entry = json.loads(line)
                ts = datetime.fromisoformat(entry["timestamp"])
                if ts >= cutoff:
                    entries.append(entry)
                else:
                    break

        passed = sum(e.get("passed", 0) for e in entries)
        failed = sum(e.get("failed", 0) for e in entries)
        errors = sum(e.get("errors", 0) for e in entries)
        duration = sum(e.get("duration_s", 0) for e in entries)
        seed_val = entries[0].get("seed") if len(entries) == 1 else None

        parts = []
        if passed:
            parts.append(f"[green]{passed} passed[/]")
        if failed:
            parts.append(f"[red]{failed} failed[/]")
        if errors:
            parts.append(f"[red]{errors} errors[/]")

        summary = ", ".join(parts)
        meta = []
        if seed_val:
            meta.append(f"seed: {seed_val}")
        meta.append(f"{duration:.2f}s")

        console.print(f"   📊 {summary} ({', '.join(meta)})")
    except (json.JSONDecodeError, OSError, KeyError, ValueError):
        pass


def _show_sim_history():
    """Display recent simulation history as a Rich table."""
    results_dir = _get_results_dir()
    history_path = results_dir / "history.jsonl"

    if not history_path.exists():
        console.print("📊 [yellow]No simulation history found.[/]")
        _cli_name = "routertl"
        with cli_resilient_block("CLI name resolution"):
            from sdk.cli.main import CLI_NAME as _cli_name
        console.print(f"   Run a simulation first: [cyan]{_cli_name} sim <testbench>[/]")
        return

    entries = []
    try:
        with open(history_path, "r") as f:
            for line in f:
                line = line.strip()
                if line:
                    try:
                        entries.append(json.loads(line))
                    except json.JSONDecodeError:
                        continue
    except OSError:
        console.print("❌ [red]Could not read history file.[/]")
        return

    if not entries:
        console.print("📊 [yellow]History file is empty.[/]")
        return

    # Show last 20 entries
    entries = entries[-20:]



    table = Table(title="📊 Simulation History", show_lines=False)
    table.add_column("Time", style="dim", min_width=19)
    table.add_column("Module", style="cyan")
    table.add_column("Sim", style="dim")
    table.add_column("Result", min_width=12)
    table.add_column("Duration", justify="right")
    table.add_column("Seed", style="dim", justify="right")

    for e in entries:
        # Format timestamp
        ts = e.get("timestamp", "—")
        if "T" in ts:
            ts = ts.replace("T", " ")[:19]

        module_name = e.get("module", "—")
        simulator = e.get("simulator", "—")

        passed = e.get("passed", 0)
        failed = e.get("failed", 0)
        errors = e.get("errors", 0)

        if failed or errors:
            result_str = f"[red]❌ {passed}P {failed}F {errors}E[/red]"
        else:
            result_str = f"[green]✅ {passed} passed[/green]"

        duration = f"{e.get('duration_s', 0):.2f}s"
        seed_val = str(e.get("seed", "—")) if e.get("seed") else "—"

        table.add_row(ts, module_name, simulator, result_str, duration, seed_val)

    console.print(table)
    console.print(f"\n  [dim]Showing last {len(entries)} of {len(entries)} runs[/dim]")


def _testgen_impl(module=None):
    """Shared implementation for testgen (used by both subcommand and alias)."""
    _check_venv_active()

    from sdk.cli.env_setup import resolve_src_dirs

    if module:
        console.print(f"📝 [blue]Generating test boilerplate for {module}...[/]")
    else:
        console.print("📝 [blue]Generating test boilerplates...[/]")
    # resolve_sdk_script searches tools/ and sdk/engine/ — but the testgen
    # script lives under sdk/generators/.  Resolve directly from SDK root.
    from sdk.cli.sdk_root import resolve_sdk_root
    _sdk = resolve_sdk_root()
    script = (_sdk / "sdk" / "generators" / "cocotb" / "gen_cocotb_structure.py") if _sdk else None
    if script and not script.exists():
        script = None
    if script:
        src_dirs = resolve_src_dirs()

        # Exclude SDK-internal source directories from test generation.
        # resolve_src_dirs() auto-appends SDK src/units/ for pip consumers
        # (needed for dependency resolution) but consumers should not get
        # test stubs generated for SDK library components.
        if _sdk:
            sdk_root_str = str(_sdk.resolve())
            user_dirs = [d for d in src_dirs if not str(Path(d).resolve()).startswith(sdk_root_str)]
            if len(user_dirs) < len(src_dirs):
                excluded = len(src_dirs) - len(user_dirs)
                console.print(f"   [dim](i) Excluded {excluded} SDK library path(s) from test generation[/]")
            src_dirs = user_dirs if user_dirs else src_dirs  # safety: never scan nothing

        sim_dir = str(resolve_sim_dir())
        cmd = [sys.executable, str(script), "--src"] + src_dirs + ["--out", sim_dir]
        if module:
            cmd.extend(["--module", module])
        try:
            result = subprocess.run(cmd, check=False)
            if result.returncode != 0:
                console.print(f"\n❌ [red]Test generation failed (exit code: {result.returncode})[/]")
                sys.exit(result.returncode)
        except FileNotFoundError:
            console.print("❌ [red]Error:[/] Python interpreter not found.")
            sys.exit(1)
    else:
        console.print(
            "❌ [red]Test generator script not found.[/]\n"
            "   Try reinstalling: [cyan]pip install --force-reinstall routertl[/]\n"
            "   Or use Docker: [cyan]rr docker shell sim[/]"
        )
        sys.exit(1)


# ── testgen as sim subcommand + backward-compat top-level alias ──────────


@sim_group.command(name="testgen")
@click.argument("module", required=False, default=None, shell_complete=_complete_testgen_module)
def sim_testgen(module):
    """Generate Cocotb test boilerplates for sources.

    Optionally pass a MODULE name to generate only for that module.
    """
    _testgen_impl(module)


@click.command(name="testgen")
@click.argument("module", required=False, default=None, shell_complete=_complete_testgen_module)
def testgen(module):
    """Generate Cocotb test boilerplates for sources.

    Optionally pass a MODULE name to generate only for that module.
    """
    _testgen_impl(module)


@sim_group.command(name="scan-tests")
@click.option("--filter", "-f", "filter_pat", default=None, help="Show only tests whose name contains this substring.")
def scan_tests(filter_pat):
    """List available Cocotb tests."""
    console.print("🔍 [blue]Scanning for tests...[/]")
    script = resolve_sdk_script("project-manager/scan_tests.py")
    if script:
        sim_dir = str(resolve_sim_dir())
        cmd = [sys.executable, str(script), "--dirs", sim_dir]
        if filter_pat:
            cmd.extend(["--filter", filter_pat])
        from sdk.cli.env_setup import resolve_sim_exclude_dirs

        for exc in resolve_sim_exclude_dirs():
            cmd.extend(["--exclude-dir", exc])
        try:
            result = subprocess.run(cmd, check=False)
            if result.returncode != 0:
                sys.exit(result.returncode)
        except FileNotFoundError:
            console.print("❌ [red]Error:[/] Python interpreter not found.")
            sys.exit(1)
    else:
        console.print(
            "❌ [red]Test scanner script not found.[/]\n"
            "   Run [cyan]rr init[/] or [cyan]rr docker shell[/]"
        )
        sys.exit(1)


def _open_viewer_after_sim(module, is_batch, show_patterns=None):
    """Open the waveform viewer after a successful simulation.

    Single test: auto-launch RouteWave on the output waveform.
    Batch mode:  print a table of waveform paths (don't open N viewers).

    show_patterns: optional list of signal name/glob patterns RouteWave
    should auto-display once the waveform loads (LT-P2.54 zero-click debug).
    """
    from sdk.cli.viewer_manager import find_gtkwave, find_latest_waveform, get_viewer_path, launch_viewer

    # Discover waveform output directories
    wave_dirs = list(_WAVE_DIRS)

    if is_batch:
        # Batch mode: list all waveform files found
        all_waveforms = []
        for d in wave_dirs:
            if d.exists():
                for ext in (".fst", ".vcd", ".ghw"):
                    all_waveforms.extend(d.rglob(f"*{ext}"))

        if all_waveforms:
            # Sort by modification time (most recent first)
            all_waveforms.sort(key=lambda p: p.stat().st_mtime, reverse=True)
            table = Table(title="🌊 Waveform Files", show_lines=False)
            table.add_column("File", style="cyan")
            table.add_column("Size", justify="right", style="dim")
            table.add_column("Modified", style="dim")
            for wf in all_waveforms[:20]:  # Limit to 20 files
                size = wf.stat().st_size
                if size > 1_000_000:
                    size_str = f"{size / 1_000_000:.1f} MB"
                elif size > 1_000:
                    size_str = f"{size / 1_000:.1f} KB"
                else:
                    size_str = f"{size} B"
                from datetime import datetime
                mtime = datetime.fromtimestamp(wf.stat().st_mtime).strftime("%H:%M:%S")
                table.add_row(str(wf), size_str, mtime)
            console.print(table)
            console.print("\n  [dim]Open a specific waveform with:[/] [cyan]rr waves <path>[/]")
        else:
            console.print("  [dim]No waveform files found in sim/waves/ or sim_build/[/]")
        return

    # Single test: find the latest waveform and open it
    waveform = None
    for d in wave_dirs:
        waveform = find_latest_waveform(d)
        if waveform:
            break

    if not waveform:
        console.print("  [dim]No waveform files found. Use --waves flag with your simulator config.[/]")
        return

    console.print(f"🌊 [blue]Waveform:[/] [cyan]{waveform}[/]")

    # ── ltmeta sidecar hint ─────────────────────────────────────────────────
    sidecar = waveform.with_name(waveform.stem + ".ltmeta.json")
    if sidecar.exists():
        console.print(f"  [dim]ℹ  Sidecar detected: {sidecar.name} — constants enrichment active[/]")

    # Try RouteWave first, then fall back to GTKWave
    viewer = get_viewer_path()
    if viewer:
        console.print(f"  [dim]Launching RouteWave ({viewer.name})...[/]")
        if show_patterns:
            pats = ", ".join(show_patterns)
            console.print(f"  [dim]Auto-showing signals: [cyan]{pats}[/]")
        launch_viewer(waveform, viewer_path=viewer, show_patterns=show_patterns)
    else:
        gtkwave = find_gtkwave()
        if gtkwave:
            console.print("  [dim]RouteWave not available, falling back to GTKWave...[/]")
            subprocess.Popen(
                [str(gtkwave), str(waveform)],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                start_new_session=True,
            )
        else:
            from sdk.cli.platform_hints import install_cmd
            gtk_cmd = install_cmd("gtkwave") or "see https://gtkwave.sourceforge.net"
            console.print(
                "  [yellow]No waveform viewer found.[/]\n"
                "  Install RouteWave:  [cyan]rr ws update-viewer[/]\n"
                f"  Or install GTKWave: [cyan]{gtk_cmd}[/]"
            )


@sim_group.command(name="waves")
@click.argument("waveform_path", required=False, default=None)
@click.option(
    "--show", "show_raw", default=None,
    help="Comma-separated signal name(s) / globs to auto-display in RouteWave. "
         "Example: --show '*valid,*ready,top.uart_*'",
)
def waves(waveform_path, show_raw):
    """Open the waveform viewer on a file or the latest waveform.

    \b
    If WAVEFORM_PATH is provided, opens that specific file.
    Otherwise, finds the most recent .fst/.vcd/.ghw file in
    the simulation output directories.

    \b
    Examples:
        rr waves                                   # open latest waveform
        rr waves sim/waves/test.fst                # open specific file
        rr waves --show '*valid,*ready'            # open latest, auto-show
    """
    from sdk.cli.viewer_manager import find_gtkwave, find_latest_waveform, get_viewer_path, launch_viewer

    # Resolve the waveform file
    if waveform_path:
        # Handle legacy TOP= syntax
        if waveform_path.startswith("TOP="):
            waveform_path = waveform_path[4:]
        wf = Path(waveform_path)
        if not wf.exists():
            # Maybe it's a module name — search for it
            for d in _WAVE_DIRS:
                candidates = list(d.rglob(f"*{waveform_path}*")) if d.exists() else []
                if candidates:
                    wf = max(candidates, key=lambda p: p.stat().st_mtime)
                    break
            else:
                console.print(f"❌ [red]Waveform not found:[/] {waveform_path}")
                sys.exit(1)
    else:
        # Find the latest waveform
        wf = None
        for d in _WAVE_DIRS:
            wf = find_latest_waveform(d)
            if wf:
                break
        if not wf:
            console.print("❌ [red]No waveform files found.[/]")
            console.print("   Run a simulation first: [cyan]rr sim <testbench> --view[/]")
            sys.exit(1)

    console.print(f"🌊 [blue]Opening waveform viewer for [cyan]{wf}[/]...")

    # Parse --show patterns (LT-P2.54)
    show_patterns = None
    if show_raw:
        show_patterns = [p.strip() for p in show_raw.split(",") if p.strip()]

    # Try RouteWave first, then GTKWave fallback
    viewer = get_viewer_path()
    if viewer:
        console.print(f"  [dim]Using RouteWave ({viewer.name})[/]")
        if show_patterns:
            pats = ", ".join(show_patterns)
            console.print(f"  [dim]Auto-showing signals: [cyan]{pats}[/]")
        launch_viewer(wf, viewer_path=viewer, show_patterns=show_patterns)
        console.print("✅ [green]Viewer launched.[/]")
    else:
        gtkwave = find_gtkwave()
        if gtkwave:
            console.print("  [dim]RouteWave not available, using GTKWave...[/]")
            subprocess.Popen(
                [str(gtkwave), str(wf)],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                start_new_session=True,
            )
            console.print("✅ [green]GTKWave launched.[/]")
        else:
            from sdk.cli.platform_hints import install_cmd
            gtk_cmd = install_cmd("gtkwave") or "see https://gtkwave.sourceforge.net"
            console.print(
                "❌ [red]No waveform viewer available.[/]\n"
                "   Install RouteWave:  [cyan]rr ws update-viewer[/]\n"
                f"   Or install GTKWave: [cyan]{gtk_cmd}[/]"
            )
            sys.exit(1)


@sim_group.command(name="regression")
def regression():
    """Run SDK Internal Regression Tests."""
    console.print("🧪 [blue]Running SDK Regression Tests...[/]")
    script = resolve_sdk_script("project-manager/run_tests.py")
    if script:
        sdk_root = resolve_sdk_root()
        test_dir = str(sdk_root / "sdk" / "engine" / "tests")
        env = setup_sim_env()
        cmd = [sys.executable, str(script), "--dir", test_dir, "--pattern", "test_*.py"]
        try:
            result = subprocess.run(cmd, env=env, check=False)
            if result.returncode != 0:
                console.print(f"\n❌ [red]Regression failed (exit code: {result.returncode})[/]")
                sys.exit(result.returncode)
        except FileNotFoundError:
            console.print("❌ [red]Error:[/] Python interpreter not found.")
            sys.exit(1)
    else:
        console.print(
            "❌ [red]Test runner script not found.[/]\n"
            "   Run [cyan]rr init[/] or [cyan]rr docker shell[/]"
        )
        sys.exit(1)


@sim_group.command(name="viewlog")
@click.argument("test_name", required=False, default=None, shell_complete=_complete_viewlog_name)
def view_sim_log(test_name):
    """View a simulation log.

    If TEST_NAME is provided, shows that specific test's log.
    Otherwise opens the most recent simulation log.
    """
    if test_name:
        # Strip .py extension if provided
        if test_name.endswith(".py"):
            test_name = test_name[:-3]

        # Search for the log file (check subdirectory layout first)
        log_candidates = [
            Path("sim") / "cocotb" / "logs" / test_name / f"{test_name}.log",
            Path("sim") / "cocotb" / "logs" / f"{test_name}.log",
            Path("sim") / "logs" / test_name / f"{test_name}.log",
            Path("sim") / "logs" / f"{test_name}.log",
        ]
        for log_path in log_candidates:
            if log_path.exists():
                console.print(f"📄 [blue]Showing log: {log_path}[/]")
                click.echo(log_path.read_text())
                return

        console.print(f"❌ [red]Log not found for '{test_name}'.[/]")
        console.print(f"   Searched: {', '.join(str(p) for p in log_candidates)}")
        sys.exit(1)
    else:
        # Find the most recent .log across all known log directories
        candidates = []

        # Primary: sim/cocotb/logs/ (simulation + regression logs)
        log_dir = Path("sim") / "cocotb" / "logs"
        if log_dir.exists():
            candidates.extend(log_dir.glob("*.log"))
            candidates.extend(log_dir.glob("*/*.log"))

        # Lint log lives at sim/lint.log
        lint_log = Path("sim") / "lint.log"
        if lint_log.exists():
            candidates.append(lint_log)

        if candidates:
            latest = max(candidates, key=lambda p: p.stat().st_mtime)
            console.print(f"📄 [blue]Showing latest log: {latest}[/]")
            click.echo(latest.read_text())
            return

        # Fallback to make target
        console.print("📄 [blue]Opening simulation log...[/]")
        cmd = ["make", "view-sim-log"]
        try:
            subprocess.run(cmd, check=False)
        except FileNotFoundError:
            console.print("❌ [red]Error:[/] 'make' not found.")
            sys.exit(1)


# ── Contract-first (RTL-P2.398) ─────────────────────────────────────────────


@sim_group.command(name="contract-check")
@click.argument("ip_dir", required=False, type=click.Path(
    exists=True, file_okay=False, dir_okay=True, path_type=Path,
))
def contract_check(ip_dir):
    """Diff declared requirements.yml against parsed HDL.

    With no argument, walks the current working directory for every
    ``requirements.yml`` and checks each.  With an IP directory argument,
    checks only that directory.

    Exits non-zero on any shape mismatch — bundle counts, missing / orphan
    bundles, protocol disagreement, scalar direction drift, missing clocks
    or resets.  RTL-P2.404 / RTL-P2.398.
    """
    from sdk.engine.contract_check import (
        check_ip,
        check_project_tree,
        format_report,
        format_tree,
    )

    if ip_dir is not None:
        reports = [check_ip(Path(ip_dir))]
        if not reports:
            console.print(
                "[yellow]No requirements.yml files found under current directory.[/]"
            )
            return
        failed = 0
        for r in reports:
            click.echo(format_report(r))
            if not r.ok:
                failed += 1
        if failed:
            console.print(
                f"\n[red]contract-check failed:[/] {failed} of {len(reports)} "
                "IP(s) have shape mismatches."
            )
            sys.exit(1)
        console.print(
            f"\n[green]contract-check passed:[/] {len(reports)} IP(s) OK."
        )
        return

    # Project-wide: tree-shaped report (RTL-P2.431).
    project_yml = Path.cwd() / "project.yml"
    tree = check_project_tree(
        Path.cwd(),
        project_yml_path=project_yml if project_yml.is_file() else None,
    )
    all_reports = tree.all_reports
    if not all_reports:
        console.print(
            "[yellow]No contracts declared — add requirements: to "
            "project.yml or ip.yml to opt in.[/]"
        )
        return

    click.echo(format_tree(tree))
    failed = sum(1 for r in all_reports if not r.ok)
    if failed:
        console.print(
            f"\n[red]contract-check failed:[/] {failed} of {len(all_reports)} "
            "contract(s) have shape mismatches."
        )
        sys.exit(1)
    console.print(
        f"\n[green]contract-check passed:[/] {len(all_reports)} contract(s) OK."
    )


@sim_group.command(name="contract-init")
@click.argument("hdl_path", type=click.Path(
    exists=True, dir_okay=False, file_okay=True, path_type=Path,
))
@click.option(
    "--ip", "ip_name", default=None,
    help="IP name to write into scaffold (defaults to HDL filename stem).",
)
@click.option(
    "--output", "-o", "output_path",
    type=click.Path(path_type=Path), default=None,
    help="Output path (default: requirements.yml next to the HDL file).",
)
@click.option(
    "--force", is_flag=True,
    help="Overwrite an existing requirements.yml.",
)
def contract_init(hdl_path, ip_name, output_path, force):
    """Scaffold a requirements.yml from an HDL entity/module.

    Parses *HDL_PATH*, classifies ports, and writes a requirements.yml
    scaffold reflecting the **current** shape.  A warning banner at the
    top of the file reminds the author that the scaffold mirrors the
    implementation, not necessarily the intended contract — review
    everything before committing.

    RTL-P2.404 / RTL-P2.398.
    """
    from sdk.engine.contract_init import init_contract

    if ip_name is None:
        ip_name = hdl_path.stem
    if output_path is None:
        output_path = hdl_path.parent / "requirements.yml"
    if output_path.exists() and not force:
        console.print(
            f"[red]Refusing to overwrite[/] [bold]{output_path}[/] — "
            "pass [cyan]--force[/] to override."
        )
        sys.exit(1)

    content = init_contract(hdl_path, ip_name)
    output_path.write_text(content)
    console.print(f"[green]Wrote scaffold[/] → {output_path}")
    console.print(
        "[yellow]Reminder:[/] the scaffold reflects the current HDL, not the "
        "intended contract.  Edit before committing."
    )


@sim_group.command(name="scaffold")
@click.argument("ip_dir", type=click.Path(
    exists=True, file_okay=False, dir_okay=True, path_type=Path,
))
@click.option(
    "--output", "-o", "output_path",
    type=click.Path(path_type=Path), default=None,
    help="Output test file (default: <ip_dir>/tests/test_<ip>.py).",
)
@click.option(
    "--force", is_flag=True,
    help="Overwrite an existing scaffolded test file.",
)
def scaffold(ip_dir, output_path, force):
    """Scaffold a cocotb test file from requirements.yml.

    Reads the functional_contract[] from *IP_DIR*/requirements.yml and
    emits one ``@cocotb.test()`` + ``@requires("REQ-N")`` stub per REQ,
    with the declared desc carried through as a comment.  Downstream
    ``rr sim coverage-map`` then verifies every REQ is covered.

    Idempotent: refuses to overwrite an existing file without --force.

    This is the *contract-driven* scaffold.  For HDL-driven stub
    generation (port-harness only, no REQ tagging), see ``rr sim testgen``.

    RTL-P2.405 / RTL-P2.398.
    """
    from sdk.cli.requirements import load_requirements
    from sdk.generators.cocotb.contract_scaffold import render_cocotb_skeleton

    req_path = ip_dir / "requirements.yml"
    if not req_path.is_file():
        console.print(
            f"[red]No requirements.yml found in[/] [bold]{ip_dir}[/]"
        )
        sys.exit(1)

    requirements = load_requirements(req_path)
    if not requirements.functional_contract:
        console.print(
            f"[yellow]{requirements.ip}: requirements.yml has no "
            "functional_contract[] items — nothing to scaffold.  Add "
            "REQ-N entries first.[/]"
        )
        sys.exit(1)

    if output_path is None:
        output_path = ip_dir / "tests" / f"test_{requirements.ip}.py"

    if output_path.exists() and not force:
        console.print(
            f"[red]Refusing to overwrite[/] [bold]{output_path}[/] — "
            "pass [cyan]--force[/] to override."
        )
        sys.exit(1)

    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(render_cocotb_skeleton(requirements))
    console.print(
        f"[green]Wrote scaffold[/] → {output_path}  "
        f"([cyan]{len(requirements.functional_contract)}[/] REQ stubs)"
    )


@sim_group.command(name="coverage-map")
@click.argument("ip_dir", required=False, type=click.Path(
    exists=True, file_okay=False, dir_okay=True, path_type=Path,
))
@click.option(
    "--tests", "tests_root", default=None,
    type=click.Path(exists=True, file_okay=False, dir_okay=True, path_type=Path),
    help="Root of the cocotb test tree (overrides per-IP default discovery).",
)
def coverage_map(ip_dir, tests_root):
    """Diff declared REQs against @requires-tagged cocotb tests.

    For each IP with a requirements.yml, walk cocotb tests and build a
    REQ → [tests] matrix.  Flag uncovered REQs (declared but no test
    carries the tag) and orphan tags (tagged in tests but not declared
    in requirements.yml).

    Exits non-zero on any missing, orphan, or VACUOUS REQ.  A vacuous
    REQ is one whose tagged test function contains zero ``assert``
    statements — the tag is a promise without a proof.  This is the
    RTL-P2.428 guard that prevents ``@requires`` from becoming the
    new vacuous PASS.

    RTL-P2.405 / RTL-P2.428 / RTL-P2.398.
    """
    from sdk.engine.coverage_map import (
        coverage_for_ip,
        coverage_tree_for_project,
        format_report,
        format_tree,
    )

    if ip_dir is not None:
        reports = [coverage_for_ip(Path(ip_dir), tests_root=tests_root)]
    else:
        project_yml = Path.cwd() / "project.yml"
        tree = coverage_tree_for_project(
            Path.cwd(),
            tests_root=tests_root,
            project_yml_path=project_yml if project_yml.is_file() else None,
        )
        if tree.project_report is None and not tree.ip_reports:
            console.print(
                "[yellow]No contracts declared — add requirements: to "
                "project.yml or ip.yml to opt in.[/]"
            )
            return
        click.echo(format_tree(tree))
        failed = sum(1 for r in tree.all_reports if not r.ok)
        if failed:
            console.print(
                f"\n[red]coverage-map failed:[/] {failed} of "
                f"{len(tree.all_reports)} contract(s) have missing, orphan, "
                "or vacuous (assert-free) REQs."
            )
            sys.exit(1)
        console.print(
            f"\n[green]coverage-map passed:[/] {len(tree.all_reports)} "
            "contract(s) fully covered."
        )
        return

    if not reports:
        console.print(
            "[yellow]No requirements.yml files found under current directory.[/]"
        )
        return

    failed = 0
    for r in reports:
        click.echo(format_report(r))
        if not r.ok:
            failed += 1

    if failed:
        console.print(
            f"\n[red]coverage-map failed:[/] {failed} of {len(reports)} IP(s) "
            "have missing, orphan, or vacuous (assert-free) REQs."
        )
        sys.exit(1)
    console.print(
        f"\n[green]coverage-map passed:[/] {len(reports)} IP(s) "
        "fully covered."
    )
