# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""CLI command: sources — List project source files by category."""

import sys
from pathlib import Path

import rich_click as click

from sdk.cli.console import console
from sdk.cli.resilience import cli_resilient, cli_resilient_block


@cli_resilient("CLI name resolution", default="routertl")
def _cli_name():
    from sdk.cli.main import CLI_NAME

    return CLI_NAME


@click.command(name="sources")
@click.option("--syn", "filter_syn", is_flag=True, help="Show only synthesis sources.")
@click.option("--sim", "filter_sim", is_flag=True, help="Show only simulation sources.")
@click.option("--xdc", "filter_xdc", is_flag=True, help="Show only constraint files.")
@click.option("--ip", "filter_ip", is_flag=True, help="Show only IP files.")
@click.option("--count", "count_only", is_flag=True, help="Show file counts only.")
def sources_command(filter_syn, filter_sim, filter_xdc, filter_ip, count_only):
    """List project source files grouped by category.

    Without flags, shows all source categories. Use flags to filter
    to a specific category.

    Examples:
        routertl sources           # Show all sources
        routertl sources --syn     # Only synthesis files
        routertl sources --sim     # Only simulation files
        routertl sources --count   # Compact summary
    """

    yml_path = Path("project.yml")
    if not yml_path.exists():
        console.print("❌ [red]No project.yml found.[/]")
        console.print(f"   Run: {_cli_name()} init")
        sys.exit(1)

    config = {}
    with cli_resilient_block("project YAML loading"):
        from sdk.cli.project_config import load_project_config

        config = load_project_config()

    if not isinstance(config, dict):
        config = {}

    sources = config.get("sources") or {}
    if not isinstance(sources, dict):
        sources = {}
    syn_files = sources.get("syn") or []
    sim_files = sources.get("sim") or []
    xdc_files = sources.get("xdc") or []
    ip_files = sources.get("ip") or []

    # Determine which categories to show
    show_all = not (filter_syn or filter_sim or filter_xdc or filter_ip)

    categories = []
    if show_all or filter_syn:
        categories.append(("Synthesis", "🔧", "[cyan]", syn_files))
    if show_all or filter_sim:
        categories.append(("Simulation", "🧪", "[magenta]", sim_files))
    if show_all or filter_xdc:
        categories.append(("Constraints", "📐", "[yellow]", xdc_files))
    if show_all or filter_ip:
        categories.append(("IP Cores", "🧩", "[green]", ip_files))

    total = sum(len(files) for _, _, _, files in categories)

    if count_only:
        console.print("\n📁 [cyan]Project Sources[/]")
        for label, icon, color, files in categories:
            if files:
                console.print(
                    f"   {icon} {color}{label}:[/] {len(files)} file{'s' if len(files) != 1 else ''}"
                )
        console.print(f"\n   Total: [white]{total}[/] files")
        return

    console.print(f"\n📁 [cyan]Project Sources[/] ({total} files)\n")

    for label, icon, color, files in categories:
        if not files and not show_all:
            console.print(f"   {icon} {color}{label}:[/] (none)")
            continue
        if not files:
            continue

        console.print(f"   {icon} {color}{label}[/] ({len(files)}):")
        for fpath in sorted(files):
            # Highlight the filename, dim the directory
            p = Path(fpath)
            parent = str(p.parent)
            name = p.name
            if parent == ".":
                console.print(f"      [white]{name}[/]")
            else:
                console.print(f"      [dim]{parent}/[/][white]{name}[/]")
        console.print()

    # Show helpful hint
    if show_all:
        console.print(f"   [dim]Use: {_cli_name()} sources --syn|--sim|--xdc|--ip to filter[/]")
        console.print(f"   [dim]Use: {_cli_name()} workspace update --src to rescan[/]")
