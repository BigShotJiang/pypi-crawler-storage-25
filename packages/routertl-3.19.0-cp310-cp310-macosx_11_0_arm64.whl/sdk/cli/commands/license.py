# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
License — Deep FlexLM License Diagnostic.

A standalone diagnostic command that provides comprehensive license
validation beyond the basic TCP probe that ``rr doctor`` performs.

Multi-vendor: supports Altera (quartus_sh) and Xilinx (vivado) query
scripts, running wherever the vendor tool is on PATH (Docker or native).
"""

import os
import re
import subprocess
from pathlib import Path

import rich_click as click
from rich.panel import Panel
from rich.text import Text

from sdk.cli.console import console
from sdk.cli.resilience import cli_resilient_block

# ──────────────────────────────────────────────────────────────
# Shared helpers (also used by doctor.py)
# ──────────────────────────────────────────────────────────────


def _find_sdk_root():
    """Walk upward from CLI dir to locate the SDK root (path-agnostic)."""
    from sdk.cli.sdk_root import resolve_sdk_root

    return resolve_sdk_root()


def _resolve_lic_str():
    """Read LM_LICENSE_FILE from env or .env file."""
    lic_str = os.environ.get("LM_LICENSE_FILE", "")
    if not lic_str:
        env_file = Path(".env")
        if env_file.exists():
            with cli_resilient_block(".env license parsing"):
                for line in env_file.read_text().splitlines():
                    line = line.strip()
                    if line.startswith("LM_LICENSE_FILE="):
                        lic_str = line.split("=", 1)[1].strip()
                        break
    return lic_str


def _probe_server(lic_str):
    """TCP probe a FlexLM license server. Returns True/False/None."""
    import socket

    # Handle multiple servers separated by ';' or ':'
    for sep in (";", ":"):
        if sep in lic_str and "@" in lic_str:
            lic_str = lic_str.split(sep)[0]
            break

    m = re.match(r"(\d+)@(.+)", lic_str.strip())
    if not m:
        return None
    port, host = int(m.group(1)), m.group(2)
    try:
        sock = socket.create_connection((host, port), timeout=3)
        sock.close()
        return True
    except (OSError, socket.timeout):
        return False


# ── Public API re-exports (canonical home: sdk.api.tools) ──────
# Kept here for backward compatibility — existing code that imports
# ``from sdk.cli.commands.license import resolve_tool_binary`` will
# continue to work without changes.
from sdk.api.tools import resolve_tool_binary  # noqa: F401
from sdk.api.tools import resolve_tool_path as _resolve_tool_path  # noqa: F401


def _query_licensed_families():
    """Query the EDA tool for actually-licensed device families.

    Multi-vendor: prefers the vendor specified in project.yml.
    Respects hardware.tool_path from project.yml.

    Returns:
        tuple: (vendor_name, list_of_families) or (None, []) if no tool found.
    """
    sdk_root = _find_sdk_root()

    yml_path = Path("project.yml")
    target_vendor = None
    if yml_path.exists():
        with cli_resilient_block("project.yml parsing mapping vendor"):
            from sdk.cli.project_config import load_project_config

            cfg = load_project_config()
            hw = cfg.get("hardware") or {}
            if isinstance(hw, dict):
                target_vendor = hw.get("vendor")

    def _try_altera():
        quartus_bin = resolve_tool_binary("quartus_sh")
        if quartus_bin:
            tcl_path = None
            if sdk_root:
                candidate = sdk_root / "tcl" / "altera" / "query_devices.tcl"
                if candidate.exists():
                    tcl_path = str(candidate)
            if tcl_path:
                try:
                    result = subprocess.run(
                        [quartus_bin, "-t", tcl_path],
                        capture_output=True,
                        text=True,
                        timeout=30,
                    )
                    families = []
                    for line in result.stdout.splitlines():
                        if line.startswith("FAMILY:"):
                            fam = line.split(":", 1)[1].strip()
                            if fam:
                                families.append(fam)
                    return ("Quartus", sorted(set(families)))
                except (subprocess.TimeoutExpired, OSError):
                    return ("Quartus", [])
        return None

    def _try_xilinx():
        vivado_bin = resolve_tool_binary("vivado")
        if vivado_bin:
            tcl_path = None
            if sdk_root:
                candidate = sdk_root / "tcl" / "xilinx" / "query_devices.tcl"
                if candidate.exists():
                    tcl_path = str(candidate)
            if tcl_path:
                try:
                    result = subprocess.run(
                        [
                            vivado_bin,
                            "-mode", "batch",
                            "-nolog", "-nojournal", "-notrace",
                            "-source", tcl_path,
                        ],
                        capture_output=True,
                        text=True,
                        timeout=60,
                    )
                    families = []
                    for line in result.stdout.splitlines():
                        if line.startswith("FAMILY:"):
                            fam = line.split(":", 1)[1].strip()
                            if fam:
                                families.append(fam)
                    return ("Vivado", sorted(set(families)))
                except (subprocess.TimeoutExpired, OSError):
                    return ("Vivado", [])
        return None

    def _try_microchip():
        libero_bin = resolve_tool_binary("libero")
        if libero_bin:
            return ("Microchip", [])
        return None

    # Try target vendor first
    if target_vendor == "altera":
        res = _try_altera()
        if res:
            return res
    elif target_vendor == "xilinx":
        res = _try_xilinx()
        if res:
            return res
    elif target_vendor == "microchip":
        res = _try_microchip()
        if res:
            return res

    # Fallbacks if none specified or targeted tool not found
    for fallback in (_try_altera, _try_xilinx, _try_microchip):
        res = fallback()
        if res:
            return res

    return (None, [])


def _resolve_target_family():
    """Read the target family from project.yml.

    Returns:
        tuple: (family_name, part_number) — family may be None if not set.
    """
    yml_path = Path("project.yml")
    if not yml_path.exists():
        return (None, None)
    from sdk.cli.resilience import cli_resilient_block

    cfg = None
    with cli_resilient_block("project.yml hardware config"):
        from sdk.cli.project_config import load_project_config

        cfg = load_project_config()
    if cfg is None:
        return (None, None)
    hw = cfg.get("hardware") or {}
    if not isinstance(hw, dict):
        return (None, None)
    family = hw.get("family")
    part = hw.get("part")
    return (family, part)


# ──────────────────────────────────────────────────────────────
# CLI Command
# ──────────────────────────────────────────────────────────────


@click.command(name="license")
def license_command():
    """Deep FlexLM license diagnostic — validate server, families, and target part.

    Goes beyond the basic TCP probe that ``doctor`` performs by actually
    querying the EDA tool for licensed device families and comparing
    against the project.yml target.
    """
    # Header
    header = Text()
    header.append("🔑 ", style="bold")
    header.append("License Diagnostic", style="bold cyan")
    console.print(Panel(header, border_style="cyan", padding=(0, 1)))
    console.print()

    # ── 1. LM_LICENSE_FILE ──
    lic_str = _resolve_lic_str()
    if lic_str:
        console.print(f"  [bold]LM_LICENSE_FILE[/]    {lic_str}")
    else:
        console.print("  [bold]LM_LICENSE_FILE[/]    [dim]not set (using EDA tool's internal config)[/]")

    # ── 1.5 Tool Path (if configured) ──
    tool_path = _resolve_tool_path()
    if tool_path:
        console.print(f"  [bold]Tool Path[/]          {tool_path} (from project.yml)")

    # ── 2. TCP Probe (only if we have a server string) ──
    server_reachable = None
    if lic_str:
        reachable = _probe_server(lic_str)
        if reachable is True:
            console.print("  [bold]Server Reachable[/]    ✅ yes (TCP probe)")
            server_reachable = True
        elif reachable is False:
            console.print("  [bold]Server Reachable[/]    ❌ [red]no (TCP probe failed)[/]")
            server_reachable = False
        else:
            console.print(f"  [bold]Server Reachable[/]    [dim]local file[/] ({lic_str})")
            server_reachable = True  # local .dat file, no server to probe

    # ── 3. Target Family ──
    target_family, target_part = _resolve_target_family()
    if target_family:
        part_note = f" → {target_part}" if target_part else ""
        console.print(f"  [bold]Target Family[/]      {target_family} (from project.yml{part_note})")
    elif target_part:
        console.print(f"  [bold]Target Part[/]        {target_part} (family not explicitly set)")
    else:
        console.print("  [bold]Target Family[/]      [yellow]unknown (no project.yml)[/]")

    console.print()

    # ── 4. Licensed Families (always query — EDA tool knows its own config) ──
    vendor, families = _query_licensed_families()
    if vendor is None:
        console.print("  [yellow]⚠ No EDA tool found on PATH — cannot query licensed families[/]")
        console.print("    Ensure [bold]quartus_sh[/] or [bold]vivado[/] is on PATH.")
        console.print()
        return

    if not families:
        if vendor == "Microchip":
            console.print(f"  [bold]Licensed Families[/]  ({vendor})")
            console.print("    [yellow]⚠ Cannot query specific families (Libero requires X11 display).[/]")
            console.print(f"    Target [bold cyan]{target_family}[/] validation skipped, assuming valid.")
        else:
            console.print(f"  [yellow]⚠ {vendor} found but returned no licensed families[/]")
            if server_reachable is False:
                console.print("    The license server is not reachable — check VPN and firewall.")
                console.print("    For Docker: use [cyan]network_mode: host[/] for VPN-based servers.")
            else:
                console.print("    The license server may not be serving any features.")
            console.print()
    else:
        console.print(f"  [bold]Licensed Families[/]  ({vendor}, {len(families)} found):")
        target_found = False
        for fam in families:
            is_target = target_family and fam.lower() == target_family.lower()
            if is_target:
                target_found = True
                console.print(f"    ✅ {fam}  [bold green]← TARGET[/]")
            else:
                console.print(f"    ✅ {fam}")

        if target_family and not target_found:
            console.print(f"    ❌ [bold red]{target_family}[/]  [red]← TARGET — NOT LICENSED[/]")

    console.print()

    # ── 5. Diagnosis ──
    if target_family and families:
        target_found = any(f.lower() == target_family.lower() for f in families)
        if target_found:
            console.print(
                f"  [bold green]✅ All good[/] — {target_family} is licensed and ready for synthesis."
            )
        else:
            diag_lines = (
                f"[bold red]{target_family} is NOT in the licensed families list.[/]\n\n"
                "This typically means:\n"
                "  1. The .dat file doesn't include this family\n"
                "  2. The license server serves a different set of features\n"
                "  3. The hostid doesn't match the license file\n"
                "  4. A different license file is needed\n"
            )
            if lic_str:
                diag_lines += (
                    "\n[bold]Quick checks to run on the HOST:[/]\n"
                    f"  [cyan]$ lmutil lmstat -a -c {lic_str}[/]\n"
                    f"  [cyan]$ lmutil lmdiag -c {lic_str}[/]"
                )
            else:
                diag_lines += (
                    "\n[bold]Try setting LM_LICENSE_FILE:[/]\n"
                    "  [cyan]$ export LM_LICENSE_FILE=27009@license-server[/]\n"
                    "  [cyan]$ export LM_LICENSE_FILE=/path/to/license.dat[/]"
                )
            console.print(
                Panel(
                    diag_lines,
                    title="[bold red]Diagnosis[/]",
                    border_style="red",
                    padding=(1, 2),
                )
            )
    console.print()
