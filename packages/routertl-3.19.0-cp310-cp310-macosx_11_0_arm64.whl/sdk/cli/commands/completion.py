# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""CLI command: completion — emit shell completion scripts."""

import rich_click as click

_SUPPORTED_SHELLS = ("bash", "zsh", "fish")


from sdk.cli.resilience import cli_resilient


@cli_resilient("CLI name resolution", default="routertl")
def _cli_name():
    """Resolve the effective CLI binary name from branding config."""
    from sdk.cli.main import CLI_NAME

    return CLI_NAME


_ALIASES = ("rr",)
"""Short aliases registered in pyproject.toml [project.scripts]."""


@click.command(name="completion")
@click.argument("shell", type=click.Choice(_SUPPORTED_SHELLS, case_sensitive=False))
def completion_command(shell):
    """Generate shell completion script.

    Install completions:
      bash:  eval "$(rr completion bash)"
      zsh:   eval "$(rr completion zsh)"
      fish:  rr completion fish | source

    Or save to a file:
      rr completion bash > ~/.local/share/bash-completion/completions/rr
    """

    name = _cli_name()
    shell_lower = shell.lower()

    if shell_lower == "bash":
        script = _bash_completion_script(name)
    elif shell_lower == "zsh":
        script = _zsh_completion_script(name)
    elif shell_lower == "fish":
        script = _fish_completion_script(name)

    click.echo(script)


def _bash_completion_script(name: str) -> str:
    # Click 8.3 emits "type,value" per completion for bash. Parse both
    # fields; only "plain" contributes to COMPREPLY, "dir"/"file" defer
    # to bash's built-in path completion.
    def _block(prog: str) -> str:
        env_var = f"_{prog.upper()}_COMPLETE"
        func = f"_{prog}_completion"
        setup = f"_{prog}_completion_setup"
        return f"""\
{func}() {{
    local IFS=$'\\n'
    local response

    response=$(env COMP_WORDS="${{COMP_WORDS[*]}}" \\
               COMP_CWORD=$COMP_CWORD \\
               {env_var}=bash_complete $1)

    for completion in $response; do
        IFS=',' read type value <<< "$completion"

        if [[ $type == 'dir' ]]; then
            COMPREPLY=()
            compopt -o dirnames
        elif [[ $type == 'file' ]]; then
            COMPREPLY=()
            compopt -o default
        elif [[ $type == 'plain' ]]; then
            COMPREPLY+=($value)
        fi
    done

    return 0
}}

{setup}() {{
    complete -o nosort -F {func} {prog}
}}

{setup};
"""
    lines = _block(name)
    for alias in _ALIASES:
        if alias != name:
            lines += "\n" + _block(alias)
    return lines


def _zsh_completion_script(name: str) -> str:
    # Click 8.3 emits three lines per completion: type, key, descr.
    # The old 2-field loop surfaced the literal "plain" type marker as
    # a completion candidate — e.g. `rr pro<TAB>` produced "plain".
    def _func_block(prog: str) -> str:
        env_var = f"_{prog.upper()}_COMPLETE"
        func = f"_{prog}"
        return f"""\
{func}() {{
    local -a completions
    local -a completions_with_descriptions
    local -a response
    # RTL-P3.65: do NOT add the upstream "early-bail if command not
    # hashed" guard here — it silently aborts completion in venvs when
    # the zsh command hash table hasn't been seeded.  Click 8.3's
    # template re-introduced it; we strip it.  The guard-substring test
    # in test_diff_completion is deliberately paranoid about this.

    response=("${{(@f)$(env COMP_WORDS="${{words[*]}}" COMP_CWORD=$((CURRENT-1)) \\
{env_var}=zsh_complete {prog})}}")

    for type key descr in ${{response}}; do
        if [[ "$type" == "plain" ]]; then
            if [[ "$descr" == "_" ]]; then
                completions+=("$key")
            else
                completions_with_descriptions+=("$key":"$descr")
            fi
        elif [[ "$type" == "dir" ]]; then
            _path_files -/
        elif [[ "$type" == "file" ]]; then
            _path_files -f
        fi
    done

    if [ -n "$completions_with_descriptions" ]; then
        _describe -V unsorted completions_with_descriptions -U
    fi

    if [ -n "$completions" ]; then
        compadd -U -V unsorted -a completions
    fi
}}
"""

    lines = f"#compdef {name}\n\n" + _func_block(name)
    lines += f"""
if [[ $zsh_eval_context[-1] == loadautofunc ]]; then
    # autoload from fpath, call function directly
    _{name} "$@"
else
    # eval/source/. command, register function for later
    compdef _{name} {name}
fi
"""
    for alias in _ALIASES:
        if alias != name:
            lines += "\n" + _func_block(alias)
            lines += f"compdef _{alias} {alias}\n"
    return lines


def _fish_completion_script(name: str) -> str:
    # Click 8.3 emits "type,value" per completion for fish. The old
    # script echoed the raw line ("plain,project") as a candidate.
    def _block(prog: str) -> str:
        env_var = f"_{prog.upper()}_COMPLETE"
        func = f"_{prog}_completion"
        return f"""\
function {func};
    set -l response (env {env_var}=fish_complete COMP_WORDS=(commandline -cp) \\
COMP_CWORD=(commandline -t) {prog});

    for completion in $response;
        set -l metadata (string split "," $completion);

        if test $metadata[1] = "dir";
            __fish_complete_directories $metadata[2];
        else if test $metadata[1] = "file";
            __fish_complete_path $metadata[2];
        else if test $metadata[1] = "plain";
            echo $metadata[2];
        end;
    end;
end;

complete --no-files --command {prog} --arguments "({func})";
"""
    lines = _block(name)
    for alias in _ALIASES:
        if alias != name:
            lines += "\n" + _block(alias)
    return lines
