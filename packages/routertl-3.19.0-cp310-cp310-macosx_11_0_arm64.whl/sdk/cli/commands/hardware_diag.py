# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Hardware Diagnostic Command."""

import rich_click as click
from rich.panel import Panel
from rich.text import Text

# Trigger hardware-specific check registration
from sdk.cli.checks import (
    CheckResult,
    HardwareCheckRegistry,
    hardware,  # noqa: F401
)
from sdk.cli.console import console


@click.group(name="hardware")
def hardware_group():
    """Hardware connectivity and diagnostic tools."""
    pass


@hardware_group.command(name="doctor")
def hardware_doctor():
    """
    Hardware health check — validate JTAG/UART/USB connectivity.

    Scans for connected programmers, checks udev permissions,
    lists available serial ports, and verifies JTAG chain integrity.
    """
    # Header
    header = Text()
    header.append("🩺 ", style="bold")
    header.append("RouteRTL Hardware Doctor", style="bold cyan")
    header.append("  — Connectivity Health Check", style="dim")
    console.print(Panel(header, border_style="cyan", padding=(0, 1)))
    console.print()

    # We only want to run hardware-related checks.
    # HardwareCheckRegistry is orthogonal to the global CheckRegistry (P2.111)
    hw_results = HardwareCheckRegistry.run_all()

    if not hw_results:
        console.print("⚠️  [yellow]No hardware checks found.[/]")
        return

    # Use the same renderer as doctor.py (internal copy for now to avoid refactoring doctor.py yet)
    _render_hardware_results(console, hw_results)


def _render_hardware_results(console, results):
    """Render hardware check results."""
    ok_count = sum(1 for r in results if r.status == CheckResult.OK)
    warn_count = sum(1 for r in results if r.status == CheckResult.WARN)
    fail_count = sum(1 for r in results if r.status == CheckResult.FAIL)

    for r in results:
        title_style = {
            CheckResult.OK: "green",
            CheckResult.WARN: "yellow",
            CheckResult.FAIL: "red",
        }.get(r.status, "white")

        console.print(f"  {r.icon()} [{title_style}]{r.title:<18}[/] {r.detail}")
        if r.fix:
            console.print(f"       [dim]→ {r.fix}[/dim]")
        if r.fix_cmd:
            console.print(f"       [bold cyan]  $ {r.fix_cmd}[/bold cyan]")

    console.print()
    parts = []
    if ok_count:
        parts.append(f"[bold green]{ok_count} passed[/]")
    if warn_count:
        parts.append(f"[bold yellow]{warn_count} warning{'s' if warn_count != 1 else ''}[/]")
    if fail_count:
        parts.append(f"[bold red]{fail_count} issue{'s' if fail_count != 1 else ''}[/]")

    summary = " · ".join(parts)
    console.print(f"  {summary}\n")
