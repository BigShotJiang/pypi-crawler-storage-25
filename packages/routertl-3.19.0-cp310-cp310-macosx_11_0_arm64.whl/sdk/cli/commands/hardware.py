# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

import os
import shutil
import subprocess
import sys
from pathlib import Path

import rich_click as click

from sdk.cli.console import console
from sdk.cli.resilience import cli_resilient_block

# RTL extensions that users might accidentally include in entity names
_RTL_EXTENSIONS = {".vhd", ".vhdl", ".sv", ".v"}


def _clean_top(top):
    """Strip 'TOP=' prefix, file extensions, and validate entity name.

    Rejects shell metacharacters, path traversal, and non-identifier names
    since the value is interpolated into Make variables and subprocess calls.
    """
    import re

    if top.startswith("TOP="):
        top = top[4:]
    # Strip RTL file extension if present (users type filenames naturally)
    p = Path(top)
    if p.suffix.lower() in _RTL_EXTENSIONS:
        clean = p.stem
        console.print(f"   [dim]ℹ️  Using entity name '{clean}' (stripped '{p.suffix}')[/]")
        top = clean

    # Reject path separators (directory traversal)
    if "/" in top or "\\" in top:
        console.print(f"❌ [red]Invalid module name '{top}' — must not contain path separators.[/]")
        sys.exit(1)

    # Only allow VHDL/Verilog identifiers: alphanumeric + underscore
    if not re.match(r"^[A-Za-z_][A-Za-z0-9_]*$", top):
        console.print(
            f"❌ [red]Invalid module name '{top}' — only letters, digits, and underscores allowed.[/]"
        )
        sys.exit(1)

    # Sanity length check
    if len(top) > 128:
        console.print(f"❌ [red]Module name too long ({len(top)} chars, max 128).[/]")
        sys.exit(1)

    return top


def _run_stage_files(config: dict | None = None) -> int:
    """Execute ``stage_files`` entries from project.yml (DEPRECATED).

    .. deprecated::
        Use ``hooks.post_ip_gen`` instead.  ``stage_files`` will be removed
        in a future release.

    Each entry copies a generated file to its required location.
    Glob patterns in ``src`` are expanded, and ``dst`` parent dirs
    are created automatically.

    Returns the number of files staged.
    """
    if config is None:
        from sdk.cli.project_config import load_project_config

        try:
            config = load_project_config()
        except FileNotFoundError:
            return 0

    entries = config.get("stage_files", [])
    if not entries:
        return 0

    console.print(
        "\n  [yellow]⚠️  stage_files is deprecated — use hooks.post_ip_gen instead.[/]"
        "\n  [dim]See: rr help hooks[/]\n"
    )

    import glob as _glob

    staged = 0
    for entry in entries:
        src_pattern = entry.get("src", "")
        dst = entry.get("dst", "")
        if not src_pattern or not dst:
            console.print(f"  [yellow]⚠️  Skipping invalid stage_files entry: {entry}[/]")
            continue

        # Expand globs in src
        matches = _glob.glob(src_pattern, recursive=True)
        if not matches:
            console.print(f"  [yellow]⚠️  stage_files: no match for [cyan]{src_pattern}[/][/]")
            continue

        dst_path = Path(dst)
        for src_file in matches:
            src_path = Path(src_file)
            if not src_path.is_file():
                continue
            # If dst looks like a directory (trailing /) or multiple matches, copy into it
            if len(matches) > 1 or dst.endswith("/"):
                target_path = dst_path / src_path.name
            else:
                target_path = dst_path
            target_path.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src_path, target_path)
            console.print(f"  📋 [dim]{src_path} → {target_path}[/]")
            staged += 1

    if staged:
        console.print(f"✅ [green]Staged {staged} file(s)[/]")
    return staged


def _run_make(target, *args):
    """Helper to delegate hardware targets to the Master Makefile.

    Reads ``hardware.tool_path`` from ``project.yml`` (if present) and
    prepends the tool's ``bin`` directory to ``PATH`` so that Make resolves
    the correct EDA binary regardless of system PATH ordering.
    """
    import os

    env = os.environ.copy()

    # Inject tool_path from project.yml so Quartus/Vivado/Radiant resolve correctly
    yml = Path("project.yml")
    if yml.exists():
        with cli_resilient_block("tool_path resolution"):
            from sdk.cli.project_config import load_project_config

            cfg = load_project_config()
            hw = cfg.get("hardware") or {}
            tool_path = hw.get("tool_path") if isinstance(hw, dict) else None
            if tool_path:
                from sdk.cli.env_setup import inject_tool_path

                env = inject_tool_path(env, tool_path)

    cmd = ["make", target, *args]
    try:
        result = subprocess.run(
            cmd, check=False, env=env, capture_output=True, text=True,
        )
        if result.returncode != 0:
            stderr = result.stderr or ""
            if "No rule to make target" in stderr:
                console.print(
                    f"\n❌ [red]Build target '{target}' not available.[/]\n"
                    "   This project's Makefile is missing SDK targets.\n"
                    "   Possible fixes:\n"
                    "   • Run [cyan]rr init[/] to regenerate the Makefile\n"
                    "   • Or run inside Docker: [cyan]rr docker shell[/]"
                )
                sys.exit(1)
            # Print captured output so the user still sees errors
            if isinstance(result.stdout, str) and result.stdout:
                sys.stdout.write(result.stdout)
            if isinstance(result.stderr, str) and result.stderr:
                sys.stderr.write(result.stderr)
            console.print(f"\n❌ [red]Command failed (Make exit code: {result.returncode})[/]")
            sys.exit(result.returncode)
        else:
            if isinstance(result.stdout, str) and result.stdout:
                sys.stdout.write(result.stdout)
    except FileNotFoundError:
        from sdk.cli.platform_hints import install_cmd
        build_cmd = install_cmd("build-essential") or "install a C toolchain"
        console.print(
            "❌ [red]'make' not found.[/]\n"
            f"   Install build tools: [cyan]{build_cmd}[/]"
        )
        sys.exit(1)


def _check_source_staleness() -> list[str]:
    """Check if source files are newer than the last synthesis.

    Compares source file mtimes against the synthesis report timestamp.
    Returns a list of modified file paths (relative), or empty if up-to-date.
    """
    import os

    from sdk.cli.project_config import load_project_config

    if not Path("project.yml").exists():
        return []

    config = load_project_config()

    # Find the synthesis timestamp — look for vendor-specific reports
    reference_files = [
        Path("project") / config.get("project", {}).get("name", "project") / ".map.rpt",
        *Path(".").glob("project/*.map.rpt"),
        *Path(".").glob("project/*.syn.rpt"),
        *Path(".").glob("*.map.rpt"),
        # Vivado
        *Path(".").glob("project/*.runs/synth_1/*.dcp"),
    ]

    # Use the newest synthesis artifact as reference
    synth_time = 0.0
    for ref in reference_files:
        if ref.exists():
            t = os.path.getmtime(ref)
            if t > synth_time:
                synth_time = t

    if synth_time == 0.0:
        # No synthesis artifacts found — nothing to compare against
        return []

    # Collect source files from project.yml
    sources = config.get("sources", {})
    if not isinstance(sources, dict):
        return []

    stale: list[str] = []
    root = Path.cwd()

    for category in ("syn", "sim", "ip", "tcl", "xdc", "sdc"):
        entries = sources.get(category, [])
        if isinstance(entries, str):
            entries = [entries]
        if not isinstance(entries, list):
            continue
        for entry in entries:
            path = root / entry
            if path.is_file():
                try:
                    if os.path.getmtime(path) > synth_time:
                        stale.append(str(Path(entry)))
                except OSError:
                    continue
            elif path.is_dir():
                for ext in ("*.vhd", "*.vhdl", "*.v", "*.sv", "*.svh", "*.xdc", "*.sdc"):
                    for src in path.rglob(ext):
                        try:
                            if os.path.getmtime(src) > synth_time:
                                stale.append(str(src.relative_to(root)))
                        except (OSError, ValueError):
                            continue

    return sorted(stale)


def _clean_build_artifacts(base_dir, module):
    """Remove cached build artifacts for a specific module."""
    from sdk.engine.git_utils import safe_rmtree

    artifact_dir = Path(base_dir) / module
    if artifact_dir.exists():
        preserved = safe_rmtree(artifact_dir)
        if preserved:
            console.print(
                f"🗑️  [dim]Cleaned {artifact_dir} "
                f"(preserved {len(preserved)} tracked file(s))[/]"
            )
        else:
            console.print(f"🗑️  [dim]Removed {artifact_dir}[/]")


@click.group(name="bitstream", invoke_without_command=True)
@click.pass_context
def bitstream_group(ctx):
    """Generate the FPGA Bitstream (Synthesis + Implementation).

    When invoked without a subcommand, runs the full bitstream flow.
    Use subcommands for finer control: run, clean, status, program.
    """
    if ctx.invoked_subcommand is None:
        ctx.invoke(bitstream_run)


@bitstream_group.command(name="run")
@click.option(
    "--update-hex", is_flag=True,
    help="Firmware-only rebuild: stage hex, update MIF, reassemble. "
    "Skips synthesis and implementation (Quartus only).",
)
@click.option(
    "--force", is_flag=True,
    help="Skip source staleness check and rebuild unconditionally.",
)
def bitstream_run(update_hex, force):
    """Build the FPGA bitstream (default action).

    Automatically detects RTL source changes and triggers re-synthesis
    when cached build artifacts are stale. Use --force to skip this check.

    With --update-hex, only rebuilds the memory initialization and
    reassembles the bitstream — skipping synthesis and fitter entirely.
    This turns a ~1.5h firmware iteration into ~2 minutes (Quartus only).
    """
    if update_hex:
        try:
            from sdk.cli.vendor_dispatch import VendorDispatch, VendorToolNotFound

            dispatch = VendorDispatch.from_project()

            # Run pre-build hooks first (to regenerate hex files)
            with cli_resilient_block("pre-build hooks for update-hex"):
                from sdk.cli.engine_dispatch import run_engine_script
                run_engine_script(
                    "run_prebuild_hooks.py",
                    ["--project", "project.yml", "--root", "."],
                )

            # Post-ip-gen hooks — file staging (RTL-P2.302)
            with cli_resilient_block("post-ip-gen hooks for update-hex"):
                run_engine_script(
                    "run_hooks.py",
                    ["--stage", "post_ip_gen", "--project", "project.yml", "--root", "."],
                )
            with cli_resilient_block("stage_files (deprecated) for update-hex"):
                _run_stage_files()

            rc = dispatch.update_hex()
            if rc != 0:
                sys.exit(rc)
        except (ImportError, VendorToolNotFound):
            console.print(
                "❌ [red]--update-hex requires vendor tools (Quartus). "
                "Cannot fall back to Make.[/]"
            )
            sys.exit(1)
        return

    # ── RTL-P2.239: Source staleness warning (was RTL-P2.116) ──
    # Never clean the project dir from the bitstream step — it destroys
    # implementation artifacts.  Warn instead and let the user re-synth.
    if not force:
        with cli_resilient_block("source staleness check"):
            stale_files = _check_source_staleness()
            if stale_files:
                console.print(
                    f"\n  [yellow]⚠  {len(stale_files)} source file(s) modified "
                    "since last synthesis:[/]\n"
                )
                for sf in stale_files[:10]:
                    console.print(f"    [yellow]~ {sf}[/]")
                if len(stale_files) > 10:
                    console.print(f"    [dim]... and {len(stale_files) - 10} more[/]")
                console.print(
                    "\n  [yellow]The bitstream will be built from existing "
                    "implementation artifacts.[/]"
                    "\n  [dim]To incorporate source changes, re-run from synthesis: "
                    "[cyan]rr synth run[/cyan][/]\n"
                )

    # Post-ip-gen hooks — file staging before synthesis (RTL-P2.302)
    with cli_resilient_block("post-ip-gen hooks"):
        from sdk.cli.engine_dispatch import run_engine_script

        run_engine_script("run_hooks.py", ["--stage", "post_ip_gen", "--project", "project.yml", "--root", "."])
    with cli_resilient_block("stage_files (deprecated)"):
        _run_stage_files()

    console.print("🔨 [blue]Starting bitstream generation...[/]")
    try:
        from sdk.cli.vendor_dispatch import VendorDispatch, VendorToolNotFound

        dispatch = VendorDispatch.from_project()
        rc = dispatch.bitstream()
        if rc != 0:
            sys.exit(rc)
    except (ImportError, VendorToolNotFound):
        _run_make("bitstream")


@bitstream_group.command(name="clean")
def bitstream_clean():
    """Remove cached bitstream artifacts."""
    _clean_build_artifacts("project", "")
    console.print("🗑️  [dim]Bitstream artifacts cleaned.[/]")


# RTL-P2.376: per-target bitstream status helpers.  Depends on
# RTL-P2.373 output_dir plumbing (_resolve_active_output_dir + the
# target yml layout) so each target's artefacts live under its own
# prefix and can be inspected independently.
_BITSTREAM_STATUS_EXTS = ("*.bit", "*.sof", "*.pof", "*.jic", "*.bin")


def _format_age(seconds: float) -> str:
    """Return a human-friendly age string for a bitstream mtime delta.

    Formats as the largest sensible unit — "5m ago", "2h ago", "3d ago".
    Used only for display in the rr bitstream status table.
    """
    seconds = max(0.0, seconds)
    if seconds < 60:
        return "just now"
    minutes = seconds / 60
    if minutes < 60:
        return f"{int(minutes)}m ago"
    hours = minutes / 60
    if hours < 24:
        return f"{int(hours)}h ago"
    days = hours / 24
    return f"{int(days)}d ago"


def _find_target_bitstream(output_dir: Path) -> Path | None:
    """Return the newest bitstream under *output_dir* (bitstream/ or project/).

    Returns None when nothing is found — signals "missing" to the caller.
    Handles both canonical (<output_dir>/bitstream/*.bit) and non-canonical
    (<output_dir>/project/*.sof, Quartus convention pre-copy) locations —
    same two spots _collect_archive_files looks in.
    """
    candidates: list[Path] = []
    for sub in ("bitstream", "project"):
        d = output_dir / sub
        if d.exists():
            for pattern in _BITSTREAM_STATUS_EXTS:
                candidates.extend(d.glob(pattern))
    if not candidates:
        return None
    return max(candidates, key=lambda p: p.stat().st_mtime)


def _bitstream_status_row(
    target_name: str,
    part: str,
    target_yml: Path | None,
    output_dir: Path,
) -> tuple[str, str, str, str, str]:
    """Compute one row of the per-target status table.

    Returns (target, part, bitstream_path_or_dash, age, status_marker).
    Status is one of 'current' (bitstream newer than target yml), 'stale'
    (bitstream older), or 'missing' (nothing found).
    """
    import time

    bit = _find_target_bitstream(output_dir)
    if bit is None:
        return (target_name, part, "—", "—", "[red]missing[/]")

    bit_mtime = bit.stat().st_mtime
    age_str = _format_age(time.time() - bit_mtime)

    if target_yml is not None and target_yml.exists():
        yml_mtime = target_yml.stat().st_mtime
        status = (
            "[yellow]stale[/]" if bit_mtime < yml_mtime
            else "[green]current[/]"
        )
    else:
        status = "[green]current[/]"

    # Display as a relative path when possible; otherwise fall back to
    # the absolute path.  Path.relative_to raises when *bit* is not a
    # descendant of cwd (common under pytest's tmp_path fixtures).
    if bit.is_absolute():
        try:
            bit_rel: Path | str = bit.relative_to(Path.cwd())
        except ValueError:
            bit_rel = bit
    else:
        bit_rel = bit
    return (target_name, part, str(bit_rel), age_str, status)


def _bitstream_status_flat() -> None:
    """Legacy single-row-per-file glob view.

    Runs when there is no ``targets/`` directory — keeps the pre-P2.376
    behaviour intact so single-target projects see no change.
    """
    import os
    from datetime import datetime
    from glob import glob

    found = False
    for ext in _BITSTREAM_STATUS_EXTS:
        matches = glob(f"**/{ext}", recursive=True)
        if matches:
            found = True
            for m in matches:
                size = os.path.getsize(m)
                mtime = os.path.getmtime(m)
                ts = datetime.fromtimestamp(mtime).strftime("%Y-%m-%d %H:%M:%S")
                console.print(
                    f"  ✅ [cyan]{m}[/]  "
                    f"[dim]{size / 1024 / 1024:.1f} MB · {ts}[/]"
                )
    if not found:
        console.print("  [dim]No bitstream files found.[/]")


@bitstream_group.command(name="status")
def bitstream_status():
    """Per-target bitstream status — which targets are current / stale /
    missing.

    RTL-P2.376: multi-target projects (targets/*.yml) get a table with
    one row per target.  Stale detection compares the newest bitstream's
    mtime against its source target yml's mtime.  Projects without a
    targets/ directory fall back to the legacy single-row glob view.
    """
    import yaml
    from rich.table import Table

    targets_dir = Path("targets")
    targets: list[tuple[Path, dict]] = []
    if targets_dir.is_dir():
        for yml in sorted(targets_dir.glob("*.yml")):
            try:
                cfg = yaml.safe_load(yml.read_text()) or {}
            except (OSError, yaml.YAMLError):
                continue
            if not isinstance(cfg, dict):
                continue
            targets.append((yml, cfg))

    if not targets:
        _bitstream_status_flat()
        return

    table = Table(
        title="Bitstream Status",
        show_header=True,
        header_style="bold cyan",
    )
    table.add_column("Target")
    table.add_column("Part")
    table.add_column("Bitstream")
    table.add_column("Age")
    table.add_column("Status")

    for yml, cfg in targets:
        target_name = yml.stem
        part = cfg.get("hardware", {}).get("part", "—") if isinstance(
            cfg.get("hardware"), dict,
        ) else "—"
        out_dir = _resolve_active_output_dir(cfg)
        row = _bitstream_status_row(target_name, part, yml, out_dir)
        table.add_row(*row)

    console.print(table)


@bitstream_group.command(name="program")
def bitstream_program():
    """Flash the bitstream to the connected FPGA."""
    console.print("⚡ [blue]Programming FPGA...[/]")
    try:
        from sdk.cli.vendor_dispatch import VendorDispatch, VendorToolNotFound

        dispatch = VendorDispatch.from_project()
        rc = dispatch.program()
        if rc != 0:
            sys.exit(rc)
    except (ImportError, VendorToolNotFound):
        _run_make("program")


@click.command(name="linting")
@click.argument("top", required=False)
@click.option("--clean", "-c", is_flag=True, help="Remove cached artifacts before linting.")
@click.option("--src", multiple=True, help="Source directories to lint (repeatable; default: from project.yml).")
def linting(top, clean, src):
    """Run the RouteRTL Smart Linter for a specific TOP module or all modules."""
    if clean:
        import shutil

        for cache_dir in [".routertl_cache", "work", "e~*"]:
            p = Path(cache_dir)
            if p.exists():
                shutil.rmtree(p, ignore_errors=True)
                console.print(f"🗑️  [dim]Removed {cache_dir}[/]")
        # Also remove GHDL entity directories (e~entity_name pattern)
        for p in Path(".").glob("e~*"):
            if p.is_dir():
                import shutil

                shutil.rmtree(p, ignore_errors=True)
                console.print(f"🗑️  [dim]Removed {p}[/]")

    def _resolve_xpm_from_project_yml() -> str:
        """Resolve XPM stub files from project.yml dependencies.

        Fallback for pip-installed consumers that have no ``build_env.mk``.
        Reads ``project.yml → dependencies``, looks for entries with
        ``library: xpm``, and returns the discovered VHDL file paths as
        a space-separated string suitable for ``--xpm``.
        """
        with cli_resilient_block("XPM auto-resolve from project.yml"):
            from sdk.cli.project_config import load_project_config
            from sdk.engine.manage_dependencies import get_dependency_files

            config = load_project_config()
            dep_files = get_dependency_files(config, str(Path.cwd()))
            xpm_list = dep_files.get("xpm", [])
            if xpm_list:
                return " ".join(xpm_list)
        return ""

    def _ensure_unisim_precompiled() -> None:
        """Auto-compile unisim for GHDL if needed.

        Uses the 5-tier resolution cascade from ``vendor_libraries``:
          Tier 1: Already precompiled → skip
          Tier 2: Vivado installed → compile from Vivado sources
          Tier 3: Cached sources → compile from cache
          Tier 4: Download from mirror → cache + compile
          Tier 5: Nothing works → actionable warning

        The smart linter's own vendor-library detection (lines 639-652 in
        ``smart_linter.py``) discovers precompiled GHDL libs and adds ``-P``
        flags automatically.  This function just ensures compilation happens
        *before* the linter runs.
        """
        with cli_resilient_block("unisim auto-precompile"):
            from routertl_core.sim.vendor_libraries import (
                ensure_ghdl_unisim,
                ghdl_unisim_available,
            )

            if ghdl_unisim_available():
                return

            console.print("   [dim]ℹ️  Auto-compiling unisim for GHDL...[/]")
            if ensure_ghdl_unisim(verbose=False):
                console.print("   [dim]✅ Unisim precompiled successfully[/]")
                return

            console.print(
                "   [yellow]⚠️  Unisim not available — files using "
                "'library unisim;' may fail.[/]\n"
                "   [dim]Fix: [cyan]rr eda install-unisim --compile[/][/]"
            )


    # Try direct invocation first
    from sdk.cli.env_setup import resolve_sdk_script, resolve_src_dirs

    script = resolve_sdk_script("project-manager/smart_linter.py")
    if script:
        # Check GHDL availability upfront to avoid cryptic linting.sh failures
        import shutil as _shutil
        if not _shutil.which("ghdl"):
            import sys as _sys

            from sdk.cli.platform_hints import install_cmd
            ghdl_cmd = install_cmd("ghdl") or "build ghdl from source"
            escape = "  or  [cyan]rr docker shell[/]" if _sys.platform.startswith("linux") else ""
            console.print(
                "❌ [red]GHDL not found.[/]\n"
                "   The linter needs GHDL for VHDL pre-compilation.\n"
                f"   Install: [cyan]{ghdl_cmd}[/]{escape}"
            )
            sys.exit(1)

        src_dirs = list(src) if src else resolve_src_dirs()

        # P2.84: Exclude SDK-internal source directories from linting.
        # resolve_src_dirs() auto-appends SDK src/units/ for pip consumers
        # (needed for dependency resolution) but consumers should not see
        # lint results for SDK library components (edge_detector, etc.).
        sdk_root = None
        with cli_resilient_block("SDK root resolution for lint filter"):
            from sdk.cli.sdk_root import resolve_sdk_root
            sdk_root = resolve_sdk_root()
        if sdk_root:
            sdk_root_str = str(sdk_root.resolve())
            user_dirs = [d for d in src_dirs if not str(Path(d).resolve()).startswith(sdk_root_str)]
            if len(user_dirs) < len(src_dirs):
                excluded = len(src_dirs) - len(user_dirs)
                console.print(f"   [dim](i) Excluded {excluded} SDK library path(s) from linting[/]")
            src_dirs = user_dirs if user_dirs else src_dirs  # safety: never lint nothing

        if top:
            top = _clean_top(top)
            console.print(f"📐 [blue]Linting module: [cyan]{top}[/]")
        else:
            console.print("📐 [blue]Running full project linting...[/]")

        cmd = [sys.executable, str(script), "--root", str(Path.cwd()), "--src"] + src_dirs
        if top:
            cmd.extend(["--top", top])

        # Pass pkg/xpm/utils from build_env.mk if available,
        # otherwise fall back to resolving from project.yml directly.
        from sdk.cli.engine_dispatch import read_build_env

        benv = read_build_env()
        if benv:
            if benv.get("PKG_FILES"):
                cmd.extend(["--pkgs", benv["PKG_FILES"]])
            if benv.get("XPM_FILES"):
                cmd.extend(["--xpm", benv["XPM_FILES"]])
            if benv.get("UTILS_FILES"):
                cmd.extend(["--utils", benv["UTILS_FILES"]])
        elif Path("project.yml").exists():
            # Fallback: resolve XPM/pkg directly from project.yml
            # (pip consumers without build_env.mk)
            xpm_files = _resolve_xpm_from_project_yml()
            if xpm_files:
                cmd.extend(["--xpm", xpm_files])

        # Auto-compile unisim for GHDL (P1.50) — but only if any VHDL
        # source actually uses 'library unisim;'.  Avoids confusing
        # network calls and warnings for projects that don't need it.
        _needs_unisim = False
        for sd in src_dirs:
            for vhd in Path(sd).rglob("*.vhd"):
                try:
                    if "library unisim" in vhd.read_text(errors="replace").lower():
                        _needs_unisim = True
                        break
                except OSError:
                    continue
            if _needs_unisim:
                break
        if _needs_unisim:
            _ensure_unisim_precompiled()

        try:
            result = subprocess.run(cmd, check=False)
            if result.returncode != 0:
                console.print(f"\n❌ [red]Linting failed (exit code: {result.returncode})[/]")
                sys.exit(result.returncode)
        except FileNotFoundError:
            console.print("❌ [red]Error:[/] Python interpreter not found.")
            sys.exit(1)
    else:
        if top:
            top = _clean_top(top)
            console.print(f"📐 [blue]Linting module: [cyan]{top}[/]")
            _run_make("linting", f"TOP={top}")
        else:
            console.print("📐 [blue]Running full project linting...[/]")
            _run_make("linting")


@click.command(name="hierarchy")
@click.argument("top", required=False, default=None)
@click.option("--all", "-a", "show_all", is_flag=True, help="Include submodules (not just top-level trees).")
@click.option("--forest", "show_forest", is_flag=True, help="Show full project hierarchy (all top-level roots).")
@click.option("--flat", "show_flat", is_flag=True, help="Flat file list instead of nested tree (requires --forest).")
@click.option("--full", "show_full", is_flag=True, help="Show all nodes without truncation.")
def hierarchy(top, show_all, show_forest, show_flat, show_full):
    """View the design hierarchy for a given TOP module.

    When called without a TOP argument, lists all available modules.
    Use --all to include submodules shadowed by top-level modules.
    Use --forest to see the full project hierarchy as nested trees.

    Examples:
        routertl hierarchy uart_sniffer
        routertl hierarchy --forest
        routertl hierarchy --forest --full
        routertl hierarchy --forest --flat
    """
    # ── Forest mode ──
    if show_forest:
        from sdk.cli.commands.info import _resolve_src_dirs, render_forest

        existing = _resolve_src_dirs()

        try:
            from sdk.engine.dependency_resolver import DependencyResolver
        except ImportError:
            from routertl_core.dependency_resolver import DependencyResolver

        resolver = DependencyResolver(existing, verbose=False)
        render_forest(resolver, show_flat=show_flat, show_full=show_full)
        return

    if top is None:
        _list_synthesis_targets(show_all=show_all)
        return
    top = _clean_top(top)
    console.print(f"🌳 [blue]Extracting hierarchy for: [cyan]{top}[/]")

    from sdk.cli.engine_dispatch import ScriptNotFound, run_engine_script
    from sdk.cli.env_setup import resolve_src_dirs

    src_dirs = resolve_src_dirs()
    try:
        result = run_engine_script(
            "dependency_resolver.py",
            ["--src"] + src_dirs + ["--top", top],
        )
        if result.returncode != 0:
            sys.exit(result.returncode)
    except ScriptNotFound:
        _run_make("hierarchy", f"TOP={top}")


@click.group(name="project", invoke_without_command=True)
@click.pass_context
def project_group(ctx):
    """FPGA Project Management.

    When invoked without a subcommand, generates the project.
    Use 'clean' to remove all FPGA project artifacts.
    """
    if ctx.invoked_subcommand is None:
        ctx.invoke(project_run)


@project_group.command(name="run")
@click.option(
    "--fix-gitignore",
    "fix_gitignore",
    is_flag=True,
    default=False,
    help="Auto-append vendor scaffold dirs (project/, .Xil/, db/, etc.) "
         "to .gitignore when missing, then proceed.  Idempotent "
         "(RTL-P2.411).  Silence with RR_SKIP_GITIGNORE_GUARD=1.",
)
def project_run(fix_gitignore):
    """Generate FPGA Project (default action)."""
    console.print("📁 [blue]Generating FPGA Project...[/]")

    # RTL-P2.422: detect empty / unparseable project.yml before anything
    # downstream chokes with a cryptic vendor-dispatch error.  The
    # scaffold hint points users at `rr init` which is the one-shot fix.
    _yml = Path("project.yml")
    if _yml.exists():
        import yaml as _yaml
        try:
            _raw = _yml.read_text()
        except OSError as _e:
            console.print(f"❌ [red]Could not read project.yml:[/] {_e}")
            sys.exit(1)
        if not _raw.strip():
            console.print(
                "❌ [red]project.yml is empty.[/]\n"
                "   [dim]Run [cyan]rr init[/] to scaffold a minimal project, "
                "or paste your config into project.yml.[/]"
            )
            sys.exit(1)
        try:
            _parsed = _yaml.safe_load(_raw)
        except _yaml.YAMLError as _e:
            mark = getattr(_e, "problem_mark", None)
            loc = (f" line {mark.line + 1}, col {mark.column + 1}"
                   if mark else "")
            console.print(
                f"❌ [red]project.yml has a YAML syntax error{loc}:[/] {_e}\n"
                "   [dim]Fix the error or run [cyan]rr init[/] for a fresh "
                "scaffold.[/]"
            )
            sys.exit(1)
        if _parsed is None or not isinstance(_parsed, dict) or not _parsed:
            # Parses but yields None / empty-dict / non-dict — nothing
            # downstream can do with this.
            console.print(
                "❌ [red]project.yml has no content to act on.[/]\n"
                "   [dim]Run [cyan]rr init[/] to scaffold a minimal project.[/]"
            )
            sys.exit(1)

    # RTL-P2.411: before anything else, check .gitignore coverage of
    # vendor scaffold dirs.  Non-blocking (just a yellow warn) unless
    # the user passed --fix-gitignore.  Reads hardware.vendor from the
    # active target — if project.yml can't be parsed we fall through
    # silently (project.yml parse errors will surface later in the
    # chain with richer diagnostics).
    with cli_resilient_block("gitignore guard"):
        from sdk.cli.project_config import load_project_config
        _cfg = load_project_config() if Path("project.yml").exists() else {}
        _hw = _cfg.get("hardware") if isinstance(_cfg, dict) else None
        _vendor = _hw.get("vendor") if isinstance(_hw, dict) else None
        _check_gitignore_guard(_vendor, fix=fix_gitignore)

    try:
        from sdk.cli.engine_dispatch import check_lfs_guards, run_engine_script
        from sdk.cli.vendor_dispatch import VendorDispatch, VendorToolNotFound

        # Pre-build steps (mirrors the Make prerequisite chain)
        # 1) update-config
        run_engine_script("project_manager.py", ["project.yml"])
        # 2) check-lfs
        if not check_lfs_guards():
            sys.exit(1)
        # 3) pre-build hooks
        with cli_resilient_block("pre-build hooks"):
            run_engine_script("run_prebuild_hooks.py", ["--project", "project.yml", "--root", "."])
        # 4) vendor project generation
        dispatch = VendorDispatch.from_project()
        rc = dispatch.project()
        if rc != 0:
            sys.exit(rc)
        # 5) post-ip-gen hooks — file staging, qsys post-processing, etc. (RTL-P2.302)
        with cli_resilient_block("post-ip-gen hooks"):
            run_engine_script("run_hooks.py", ["--stage", "post_ip_gen", "--project", "project.yml", "--root", "."])
        # 5b) deprecated stage_files fallback
        with cli_resilient_block("stage_files (deprecated)"):
            _run_stage_files()
        # 6) post-build hooks
        with cli_resilient_block("post-build hooks"):
            run_engine_script("run_hooks.py", ["--stage", "post_build", "--project", "project.yml", "--root", "."])
    except (ImportError, VendorToolNotFound):
        _run_make("project")


# RTL-P2.411: vendor → scaffold directory segments that vendor tools
# will generate under the project root and that must never be
# committed.  Maps directly to the scaffold list in
# _SCAFFOLD_SEGMENTS (used by the archive filter) — keeps both the
# "don't pack this into a tarball" and the "don't accidentally
# git-commit this" guards wired to the same source of truth.
_VENDOR_SCAFFOLD_DIRS: dict[str, tuple[str, ...]] = {
    "xilinx":    ("project", ".Xil", "ip_cache"),
    "altera":    ("project", "db", "incremental_db", "qdb", "output_files"),
    "intel":     ("project", "db", "incremental_db", "qdb", "output_files"),
    "lattice":   ("project", "impl1", "impl2", "diamond_base"),
    "microchip": ("project", ".metadata"),
    "microsemi": ("project", ".metadata"),
}
# Always-on additions (vendor-independent generators the rr flow emits).
_COMMON_SCAFFOLD_DIRS = ("sim_build", "__pycache__")


def _scaffold_dirs_for_vendor(vendor: str | None) -> tuple[str, ...]:
    """Return the full scaffold dir list for a vendor (plus common entries)."""
    key = (vendor or "").strip().lower()
    vendor_dirs = _VENDOR_SCAFFOLD_DIRS.get(key, ())
    # Dedupe while preserving order.
    out: list[str] = []
    seen: set[str] = set()
    for d in vendor_dirs + _COMMON_SCAFFOLD_DIRS:
        if d not in seen:
            out.append(d)
            seen.add(d)
    return tuple(out)


def _gitignore_missing_entries(
    gitignore_path: Path,
    scaffold_dirs: tuple[str, ...],
) -> list[str]:
    """Return the scaffold entries not covered by *gitignore_path*.

    RTL-P2.411: a scaffold dir counts as covered when any of these
    gitignore lines appears (substring match over non-comment lines):
      - ``<dir>``
      - ``<dir>/``
      - ``<dir>/*``
      - ``/<dir>/``
    gitignore globbing is rich but the naive substring check is a
    conservative lower bound — false positives (missing-when-covered)
    are the only cost, and the --fix-gitignore auto-append is
    idempotent, so the worst case is a no-op write.
    """
    if not gitignore_path.exists():
        return list(scaffold_dirs)
    try:
        lines = gitignore_path.read_text().splitlines()
    except OSError:
        return list(scaffold_dirs)

    active = [
        ln.strip() for ln in lines
        if ln.strip() and not ln.strip().startswith("#")
    ]
    active_set = set(active)

    def _covers(dir_name: str) -> bool:
        variants = {
            dir_name, f"{dir_name}/", f"{dir_name}/*",
            f"/{dir_name}/", f"/{dir_name}",
        }
        return any(v in active_set for v in variants)

    return [d for d in scaffold_dirs if not _covers(d)]


def _check_gitignore_guard(
    vendor: str | None,
    *,
    fix: bool = False,
) -> None:
    """Warn (or auto-append) when .gitignore misses vendor scaffold dirs.

    RTL-P2.411 — surfaced 2026-04-21 after the ip_paths=[project]
    footgun dragged the Vivado scaffold into an archive.  Archive
    filtering alone doesn't stop raw ``git add .`` from committing the
    scaffold; this guard closes that loop.

    Silent no-op when:
      * ``RR_SKIP_GITIGNORE_GUARD=1`` is set (CI / scripted builds).
      * Vendor is unrecognised (no scaffold dirs to check).
      * All scaffold dirs are already covered.
    """
    if os.environ.get("RR_SKIP_GITIGNORE_GUARD") == "1":
        return

    dirs = _scaffold_dirs_for_vendor(vendor)
    if not dirs:
        return

    gitignore = Path(".gitignore")
    missing = _gitignore_missing_entries(gitignore, dirs)
    if not missing:
        return

    if fix:
        header = (
            "# Added by rr project run — vendor scaffold dirs "
            "(RTL-P2.411).  Safe to keep; these are generated build "
            "artefacts that must never be committed."
        )
        existing = gitignore.read_text() if gitignore.exists() else ""
        # Idempotency: re-check after a potential partial write.  If
        # the file already contains the header, only append new misses.
        payload_lines = [header] + [f"{d}/" for d in missing]
        # Ensure we separate from existing content with a newline.
        sep = "" if (not existing or existing.endswith("\n")) else "\n"
        gitignore.write_text(existing + sep + "\n".join(payload_lines) + "\n")
        console.print(
            f"🛠  [green]Updated .gitignore:[/] appended {len(missing)} "
            f"entry(ies) — [dim]{', '.join(missing)}[/]"
        )
        return

    # Warn (non-blocking — project run still proceeds).
    fix_cli = _cli_name_safe()
    console.print(
        f"⚠  [yellow].gitignore is missing {len(missing)} vendor scaffold "
        f"dir(s):[/] [bold]{', '.join(missing)}[/]\n"
        f"   [dim]Un-ignored scaffold can sneak into git via "
        "`git add .` — append with:[/]\n"
        f"   [cyan]{fix_cli} project run --fix-gitignore[/]\n"
        f"   [dim]Or add manually:[/] "
        f"[cyan]echo '{missing[0]}/' >> .gitignore[/]\n"
        f"   [dim]Silence this check: RR_SKIP_GITIGNORE_GUARD=1[/]"
    )


def _cli_name_safe() -> str:
    """Best-effort CLI name for diagnostic banners — falls back to 'rr'."""
    with cli_resilient_block("CLI name for gitignore banner"):
        from sdk.cli.main import CLI_NAME
        return CLI_NAME
    return "rr"


# RTL-P2.400: vendor → GUI binary candidates (first hit on PATH wins).
# Pairs with _VENDOR_IDE_PROJECT_PATTERNS below to close the "open the
# vendor IDE on the current project" loop without leaving the terminal.
_VENDOR_IDE_BINARIES: dict[str, tuple[str, ...]] = {
    "xilinx":    ("vivado",),
    "altera":    ("quartus",),
    "intel":     ("quartus",),
    "lattice":   ("radiant", "diamond"),
    "microchip": ("libero",),
    "microsemi": ("libero",),
}

# RTL-P2.400: vendor-specific project file pattern, globbed under
# ``<output_dir>/project/`` (the canonical scaffold).  Multiple matches
# → newest by mtime.
_VENDOR_IDE_PROJECT_PATTERNS: dict[str, tuple[str, ...]] = {
    "xilinx":    ("project/*.xpr",),
    "altera":    ("project/*.qpf",),
    "intel":     ("project/*.qpf",),
    "lattice":   ("project/*.rdf", "project/*.ldf"),
    "microchip": ("project/*.prjx",),
    "microsemi": ("project/*.prjx",),
}


def _resolve_ide_binary(
    vendor: str,
    tool_path: str | None = None,
) -> tuple[str | None, tuple[str, ...]]:
    """Find the vendor's IDE binary, consulting ``hardware.tool_path``
    before the ambient PATH.

    RTL-P2.407: users who declare a vendor install under
    ``hardware.tool_path`` (common on boxes that don't source
    settings64.sh from the shell profile) previously got a spurious
    "Vendor IDE not found on PATH" error even though ``rr project run``
    would have found the vendor tooling via tool_path injection.  We
    now prepend the tool_path's vendor bin directories to PATH before
    calling shutil.which, mirroring VendorDispatch's convention.

    Returns ``(path_or_None, candidates)`` — the first candidate found,
    or None.  ``candidates`` is the tuple tried, so the caller can print
    a useful "looked for …" diagnostic when the lookup misses.
    """
    import shutil
    candidates = _VENDOR_IDE_BINARIES.get(vendor.lower(), ())

    search_path = os.environ.get("PATH", "")
    if tool_path:
        with cli_resilient_block("hardware.tool_path injection for IDE lookup"):
            from sdk.cli.env_setup import inject_tool_path
            injected = inject_tool_path(os.environ.copy(), tool_path)
            search_path = injected.get("PATH", search_path)

    for cand in candidates:
        hit = shutil.which(cand, path=search_path)
        if hit:
            return hit, candidates
    return None, candidates


def _find_vendor_project_file(vendor: str, output_dir: Path) -> Path | None:
    """Return the newest vendor project file under *output_dir*, or None."""
    patterns = _VENDOR_IDE_PROJECT_PATTERNS.get(vendor.lower(), ())
    hits: list[Path] = []
    for pattern in patterns:
        hits.extend(output_dir.glob(pattern))
    if not hits:
        return None
    return max(hits, key=lambda p: p.stat().st_mtime)


@project_group.command(name="gui")
@click.option(
    "--no-project",
    "no_project",
    is_flag=True,
    default=False,
    help="Launch the IDE without loading a project file (blank IDE).",
)
def project_gui(no_project):
    """Open the vendor IDE (Vivado / Quartus / Radiant / Libero) for the active target.

    \b
    Detects ``hardware.vendor`` from the active target yml, resolves the
    matching GUI binary on PATH, and opens the generated vendor project
    file under ``<output_dir>/project/`` (``.xpr``, ``.qpf``, ``.rdf``,
    ``.prjx``).  The process is detached so you drop back to the shell
    immediately.

    \b
    Examples:
        rr project gui                       # open vendor IDE on current project
        rr project gui --no-project          # launch IDE with no project loaded
    """
    import subprocess

    if not Path("project.yml").exists():
        console.print("❌ [red]No project.yml found in the current directory.[/]")
        sys.exit(1)

    from sdk.cli.project_config import load_project_config
    try:
        config = load_project_config()
    except (OSError, ValueError, FileNotFoundError) as e:
        console.print(f"❌ [red]Could not load project config:[/] {e}")
        sys.exit(1)
    if not isinstance(config, dict):
        config = {}

    hw = config.get("hardware") or {}
    if not isinstance(hw, dict):
        hw = {}
    vendor_raw = hw.get("vendor")
    if not vendor_raw:
        console.print(
            "❌ [red]No hardware.vendor declared in the active target yml.[/]\n"
            "   [dim]Add e.g. `hardware: { vendor: xilinx }` "
            "(supported: xilinx, altera/intel, lattice, microchip/microsemi).[/]"
        )
        sys.exit(1)
    vendor = str(vendor_raw).strip().lower()

    # Resolve IDE binary — consult hardware.tool_path first (RTL-P2.407).
    tool_path = hw.get("tool_path")
    binary, candidates = _resolve_ide_binary(vendor, tool_path=tool_path)
    if binary is None:
        if not candidates:
            console.print(
                f"❌ [red]Unknown vendor '{vendor}'.[/]\n"
                "   [dim]Supported: xilinx, altera, intel, lattice, microchip, microsemi[/]"
            )
            sys.exit(1)
        hints = [f"   [dim]Looked for: {', '.join(candidates)}[/]"]
        if tool_path:
            hints.append(
                f"   [dim]Searched via hardware.tool_path: "
                f"[cyan]{tool_path}[/] — binary not found under any "
                "vendor bin subdirectory (bin/, quartus/bin/, bin/lin64/, "
                "Libero/bin/).[/]"
            )
        hints.append(
            "   [dim]Source your vendor setup script (e.g. "
            "[cyan]source /opt/Xilinx/Vivado/<ver>/settings64.sh[/]) "
            "and retry, or set [cyan]hardware.tool_path[/] in the "
            "target yml.[/]"
        )
        console.print(
            "❌ [red]Vendor IDE not found on PATH.[/]\n" + "\n".join(hints)
        )
        sys.exit(1)

    # Resolve project file (unless --no-project).
    project_file: Path | None = None
    if not no_project:
        output_dir = _resolve_active_output_dir(config)
        project_file = _find_vendor_project_file(vendor, output_dir)
        if project_file is None:
            console.print(
                f"  [yellow]No vendor project file found under "
                f"[cyan]{output_dir}/project/[/].[/]\n"
                "  [dim]Run [cyan]rr project run[/] first, or pass "
                "[cyan]--no-project[/] to launch the IDE blank.[/]"
            )
            sys.exit(1)

    # Build + launch.  tool_path from the target yml is prepended to PATH
    # so users who declare a vendor install there don't need to source
    # the setup script before invoking `rr project gui`.
    cmd = [binary]
    if project_file is not None:
        cmd.append(str(project_file))

    env = os.environ.copy()
    if tool_path:
        with cli_resilient_block("tool_path injection for rr project gui"):
            from sdk.cli.env_setup import inject_tool_path
            env = inject_tool_path(env, tool_path)

    # Banner — show the resolved binary path and, when it was picked up
    # from hardware.tool_path rather than the ambient PATH, say so
    # explicitly.  Helps diagnose a "wrong Vivado got launched" case.
    via = ""
    if tool_path:
        try:
            tp_resolved = str(Path(tool_path).expanduser().resolve())
            if Path(binary).resolve().as_posix().startswith(tp_resolved):
                via = " [dim](via hardware.tool_path)[/]"
        except (OSError, ValueError):
            pass

    banner = f"🚀 [blue]Launching {Path(binary).name}[/] [dim]({binary})[/]{via}"
    if project_file is not None:
        banner += f"\n   [cyan]{project_file}[/]"
    else:
        banner += " [dim]— blank IDE[/]"
    console.print(banner)

    try:
        subprocess.Popen(
            cmd,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True,
            env=env,
        )
    except OSError as e:
        console.print(f"❌ [red]Failed to launch {binary}:[/] {e}")
        sys.exit(1)

    console.print("✅ [green]IDE launched — back to shell.[/]")


@project_group.command(name="clean")
@click.option("--all", "tier_all", is_flag=True, default=False, help="Remove everything including synthesis/fitter databases (default if no tier specified).")
@click.option("--soft", is_flag=True, default=False, help="Preserve synthesis/fitter databases (db/, incremental_db/, dcp/); clean hooks, project files, reports.")
@click.option("--sw", is_flag=True, default=False, help="Only clean software/hook-generated outputs (hex, MIF, generated VHDL). Preserves all HW build artifacts.")
def project_clean(tier_all, soft, sw):
    """Remove FPGA project artifacts with tiered granularity.

    \b
    Tiers (from most to least aggressive):
      --all   Remove everything — full rebuild required (default)
      --soft  Preserve synthesis/fitter databases for incremental rebuilds
      --sw    Only clean hook-generated outputs (firmware iteration)

    \b
    Examples:
      rr project clean           # full clean (same as --all)
      rr project clean --soft    # keep db/, incremental_db/, dcp/
      rr project clean --sw      # only hook outputs (hex, MIF, VHDL pkgs)
    """
    # Default to --all if no tier specified
    if not soft and not sw:
        tier_all = True

    if sw:
        _clean_sw_only()
    elif soft:
        _clean_soft()
    else:
        _clean_all()


_VENDOR_SEGMENT_MARKERS = frozenset(
    {"vendor", "third_party", "node_modules", ".git"}
)
"""Path segments that mark a third-party/vendor tree.

Bitstreams living under these are vendor prebuilts (e.g. AMD BUP example
designs shipped with ES2/ES3/PRD variants) — they aren't *our* build
artifacts and must not be dragged into ``last_build/``.
"""

_VENDOR_SEGMENT_PREFIXES = ("bup_",)
"""Path segment prefixes that mark a vendor tree — e.g. ``bup_arria10GX_*``."""


def _is_vendor_bitstream(path: Path) -> bool:
    """Return True if ``path`` lives under a known vendor tree."""
    for part in path.parts:
        lower = part.lower()
        if lower in _VENDOR_SEGMENT_MARKERS:
            return True
        if any(lower.startswith(prefix) for prefix in _VENDOR_SEGMENT_PREFIXES):
            return True
    return False


def _preserve_bitstreams() -> int:
    """Copy last-known-good bitstreams to last_build/ before cleaning.

    Only *our* build outputs are preserved.  Vendor prebuilts (``bup_*``,
    ``vendor/``, ``third_party/``, ``.git/``, ``node_modules/``) are
    ignored — otherwise a vendor tree that ships ES2/ES3/PRD variants of
    the same basename would collide on copy and fail with PermissionError
    when the dest inherits r-- perms from the first vendor source
    (RTL-P2.340, first hit on the nike GBX bringup).
    """
    from glob import glob

    bitstream_exts = ["*.sof", "*.pof", "*.jic", "*.bit", "*.bin"]
    found: list[Path] = []
    for ext in bitstream_exts:
        found.extend(Path(m) for m in glob(ext))
        found.extend(Path(m) for m in glob(f"**/{ext}", recursive=True))

    seen_resolved: set[Path] = set()
    seen_basename: set[str] = set()
    bitstreams: list[Path] = []
    for f in found:
        if "last_build" in f.parts:
            continue
        if _is_vendor_bitstream(f):
            continue
        resolved = f.resolve()
        if resolved in seen_resolved:
            continue
        if f.name in seen_basename:
            # Two different *our* bitstreams share a basename — preserve
            # the first and skip the rest so copy2 doesn't choke on a
            # read-only dest on the second pass.
            continue
        seen_resolved.add(resolved)
        seen_basename.add(f.name)
        bitstreams.append(f)

    if not bitstreams:
        return 0

    prev_dir = Path("last_build")
    prev_dir.mkdir(exist_ok=True)

    preserved = 0
    for bs in bitstreams:
        dest = prev_dir / bs.name
        # Defensive: if a prior preserve copied from a read-only source,
        # copy2 would have inherited those perms on the dest and the
        # next overwrite would fail with EACCES.
        if dest.exists():
            dest.chmod(0o644)
        shutil.copy2(bs, dest)
        dest.chmod(0o644)
        console.print(f"  📦 [dim]Preserved {bs} → {dest}[/]")
        preserved += 1

    return preserved


def _clean_all():
    """Full clean — remove everything (original behavior).

    RTL-P2.373: when the active target declares ``project.output_dir``,
    the scoped form wipes only that target's output tree and leaves
    sibling targets' artefacts alone.  Flat-layout projects (``output_dir``
    unset) keep the pre-P2.373 root-level clean exactly.
    """
    out_dir = _resolve_active_output_dir()
    scoped = str(out_dir) != "."

    if scoped:
        # Per-target: everything under output_dir belongs to this target.
        # Sibling targets live under their own output_dirs — untouched.
        dirs_to_clean = [str(out_dir)]
    else:
        dirs_to_clean = [
            "project",           # generated project workspace
            "db",                # Quartus compilation database
            "incremental_db",    # Quartus incremental compilation
            "dcp",               # NPM synthesis design checkpoints
            "output_files",      # Quartus output directory
            ".Xil",              # Vivado temp files
        ]

    file_patterns = [
        # Quartus
        "*.qpf", "*.qsf", "*.qws", "*.bak", "*.smsg",
        "*.rpt", "*.summary", "*.pin", "*.done", "*.jdi",
        "*.sld", "*.sldq", "*.slds", "*.sof", "*.pof", "*.jic",
        # Vivado
        "*.xpr", "*.bit", "*.ltx", "*.dcp",
        # Lattice
        "*.rdf",
        # Common reports
        "*.sta.rpt", "*.fit.rpt", "*.map.rpt",
    ] if not scoped else []  # scoped clean already swept output_dir

    tier_label = (
        f"--all (full clean, scoped to {out_dir}/)"
        if scoped else "--all (full clean)"
    )
    console.print(f"\n  [cyan]Cleaning: {tier_label}[/]\n")
    preserved = _preserve_bitstreams()
    cleaned = _clean_dirs(dirs_to_clean)
    cleaned += _clean_file_patterns(file_patterns)
    cleaned += _clean_hook_outputs()
    _print_clean_summary(cleaned, preserved=["last_build/"] if preserved else None)


def _clean_soft():
    """Soft clean — preserve synthesis/fitter databases for incremental rebuilds.

    RTL-P2.373: scoped form wipes only the active target's project/
    and reports/ while preserving db/, incremental_db/, and dcp/ under
    the same output_dir for fast incremental rebuilds.
    """
    out_dir = _resolve_active_output_dir()
    scoped = str(out_dir) != "."

    if scoped:
        dirs_to_clean = [
            str(out_dir / "project"),
            str(out_dir / "reports"),
            str(out_dir / "build"),   # XSA + Quartus archive land here
            str(out_dir / ".Xil"),
        ]
    else:
        dirs_to_clean = [
            "project",           # generated project workspace (re-generated quickly)
            "output_files",      # Quartus output directory
            ".Xil",              # Vivado temp files
        ]
    # Note: db/, incremental_db/, dcp/ are PRESERVED — these contain
    # the expensive synthesis/fitter results (~1.5h for Arria 10).

    file_patterns = [
        # Quartus project files (re-generated by rr project)
        "*.qpf", "*.qsf", "*.qws", "*.bak", "*.smsg",
        # Reports (re-generated each run)
        "*.rpt", "*.summary", "*.pin", "*.done", "*.jdi",
        "*.sta.rpt", "*.fit.rpt", "*.map.rpt",
        # Signal Tap (debug — cheap to recreate)
        "*.sld", "*.sldq", "*.slds",
        # Vivado project (re-generated by rr project)
        "*.xpr", "*.ltx",
        # Lattice
        "*.rdf",
    ] if not scoped else []  # scoped path already swept per-target subtrees
    # Note: *.bit, *.sof, *.pof, *.jic, *.dcp are PRESERVED — these are
    # the expensive build outputs.

    tier_label = (
        f"--soft (preserving dcp/ under {out_dir}/)"
        if scoped else "--soft (preserving synth/fitter databases)"
    )
    console.print(f"\n  [cyan]Cleaning: {tier_label}[/]\n")
    cleaned = _clean_dirs(dirs_to_clean)
    cleaned += _clean_file_patterns(file_patterns)
    cleaned += _clean_hook_outputs()
    preserved = (
        [f"{out_dir}/db/", f"{out_dir}/incremental_db/", f"{out_dir}/dcp/", "*.bit", "*.sof"]
        if scoped
        else ["db/", "incremental_db/", "dcp/", "*.bit", "*.sof"]
    )
    _print_clean_summary(cleaned, preserved=preserved)


def _clean_sw_only():
    """SW-only clean — only remove hook-generated outputs for firmware iteration."""
    console.print("\n  [cyan]Cleaning: --sw (hook outputs only)[/]\n")
    cleaned = _clean_hook_outputs()
    _print_clean_summary(cleaned, preserved=["all HW build artifacts"])


def _clean_dirs(dirs: list[str]) -> int:
    """Remove a list of directories using safe_rmtree. Returns count of cleaned items."""
    from sdk.engine.git_utils import safe_rmtree

    cleaned = 0
    for d in dirs:
        p = Path(d)
        if p.exists() and p.is_dir():
            preserved = safe_rmtree(p)
            if preserved:
                console.print(
                    f"  🗑️  [dim]Cleaned {d}/ "
                    f"(preserved {len(preserved)} tracked file(s))[/]"
                )
            else:
                console.print(f"  🗑️  [dim]Removed {d}/[/]")
            cleaned += 1
    return cleaned


def _clean_file_patterns(patterns: list[str]) -> int:
    """Remove files matching glob patterns, preserving git-tracked files."""
    from glob import glob

    from sdk.engine.git_utils import filter_git_tracked

    cleaned = 0
    for pattern in patterns:
        matches = [Path(m) for m in glob(pattern)]
        if matches:
            tracked = {f.resolve() for f in filter_git_tracked(matches)}
            for match in matches:
                if match.resolve() in tracked:
                    console.print(
                        f"  ⚠️  [yellow]Skipped tracked file: {match}[/]"
                    )
                    continue
                match.unlink(missing_ok=True)
                console.print(f"  🗑️  [dim]Removed {match}[/]")
                cleaned += 1
    return cleaned


def _clean_hook_outputs() -> int:
    """Clean hook-generated outputs from project.yml pre_build hooks."""
    from sdk.engine.git_utils import filter_git_tracked

    cleaned = 0
    root_dir = Path.cwd().resolve()
    with cli_resilient_block("hook output cleanup"):
        from sdk.cli.project_config import load_project_config

        yml = Path("project.yml")
        if yml.exists():
            config = load_project_config()
            hooks = config.get("hooks", {}).get("pre_build", [])
            for hook in hooks:
                hook_name = hook.get("name", "unnamed")
                outputs = [
                    (root_dir / o).resolve()
                    for o in hook.get("expected_outputs", [])
                    if (root_dir / o).resolve().is_relative_to(root_dir)
                ]
                existing = [o for o in outputs if o.exists()]
                tracked = {
                    f.resolve() for f in filter_git_tracked(existing, repo_root=root_dir)
                } if existing else set()
                for output_path in existing:
                    if output_path.resolve() in tracked:
                        console.print(
                            f"  ⚠️  [yellow]Skipped tracked hook output: "
                            f"{output_path.relative_to(root_dir)}[/]"
                        )
                        continue
                    output_path.unlink()
                    console.print(
                        f"  🗑️  [dim]Hook '{hook_name}': "
                        f"{output_path.relative_to(root_dir)}[/]"
                    )
                    cleaned += 1
                    # Also clean parent dir if it's now empty
                    parent = output_path.parent
                    if (parent.exists()
                            and parent != root_dir
                            and not any(parent.iterdir())):
                        parent.rmdir()
                        console.print(
                            f"  🗑️  [dim]Removed empty {parent.relative_to(root_dir)}/[/]"
                        )
    return cleaned


def _print_clean_summary(cleaned: int, preserved: list[str] | None = None) -> None:
    """Print a summary of what was cleaned and what was preserved."""
    if cleaned == 0:
        console.print("  [dim]No artifacts found to clean.[/]")
    else:
        console.print(f"\n  ✅ Cleaned {cleaned} artifact(s).")

    if preserved:
        kept = ", ".join(preserved)
        console.print(f"  [dim]Preserved: {kept}[/]")



# ── P2.86: TCL Hook Management ────────────────────────────────

_VALID_HOOK_STAGES = ("gen_project", "synthesis", "implementation", "bitstream")


@project_group.command(name="hooks")
def project_hooks():
    """List configured TCL hooks per build stage.

    Reads ``tcl_hooks`` from project.yml and displays which TCL scripts
    are sourced during each FPGA build stage (gen_project, synthesis,
    implementation, bitstream).
    """
    from sdk.cli.project_config import load_project_config

    yml = Path("project.yml")
    if not yml.exists():
        console.print("❌ [red]No project.yml found.[/]")
        sys.exit(1)

    config = load_project_config()

    tcl_hooks = config.get("tcl_hooks", {})

    if not tcl_hooks or not any(tcl_hooks.get(s) for s in _VALID_HOOK_STAGES):
        console.print(
            "\n🔗 [cyan]TCL Hooks[/] — no hooks configured\n"
            "\n  [dim]Add hooks with: rr project add-hook <stage> <path>[/]"
            "\n  [dim]Valid stages: gen_project, synthesis, implementation, bitstream[/]\n"
        )
        return

    console.print("\n🔗 [cyan]TCL Hooks[/]\n")
    for stage in _VALID_HOOK_STAGES:
        hooks = tcl_hooks.get(stage, []) or []
        if hooks:
            console.print(f"  [white]{stage}:[/]")
            for h in hooks:
                console.print(f"    [green]↳[/] {h}")
        else:
            console.print(f"  [dim]({stage}: none)[/]")
    console.print()


@project_group.command(name="add-hook")
@click.argument("stage", type=click.Choice(_VALID_HOOK_STAGES, case_sensitive=True))
@click.argument("path")
def project_add_hook(stage, path):
    """Add a TCL hook to a build stage in project.yml.

    STAGE is one of: gen_project, synthesis, implementation, bitstream.
    PATH is the TCL script path (relative to project root).

    Examples:
        rr project add-hook gen_project tcl/custom/my_block_design.tcl
        rr project add-hook synthesis tcl/project_options.tcl
    """
    from sdk.cli.project_config import load_project_config

    yml = Path("project.yml")
    if not yml.exists():
        console.print("❌ [red]No project.yml found.[/]")
        sys.exit(1)

    config = load_project_config()

    # Ensure tcl_hooks section exists
    if "tcl_hooks" not in config:
        config["tcl_hooks"] = {}
    if stage not in config["tcl_hooks"] or config["tcl_hooks"][stage] is None:
        config["tcl_hooks"][stage] = []

    # Check for duplicates
    if path in config["tcl_hooks"][stage]:
        console.print(
            f"⚠️  [yellow]'{path}' is already in tcl_hooks.{stage}.[/]"
        )
        return

    config["tcl_hooks"][stage].append(path)

    with open(yml, "w") as f:
        import yaml

        yaml.dump(config, f, default_flow_style=False, sort_keys=False)

    console.print(
        f"✅ Added [cyan]{path}[/] to [white]tcl_hooks.{stage}[/] in project.yml"
    )


def _expand_software_entries(sources_config: dict, root: Path) -> list[str]:
    """Return every file matched by ``sources.software`` entries.

    RTL-P1.46: entries can be literal paths OR glob patterns (the
    ticket suggests ``src/software/**/*.c`` as the idiomatic form).
    Globs are expanded relative to ``root`` with recursive support
    (``**``).  Missing entries are tolerated — other collectors can
    flag the gap via the "No sources" display, not this helper.
    """
    if not isinstance(sources_config, dict):
        return []
    sw = sources_config.get("software")
    if not sw:
        return []
    # ``software`` can be either a list of patterns (simple form) OR a
    # dict whose ``files`` key holds the patterns (so future options
    # like ``build.tool`` / ``build.output`` can sit alongside without
    # breaking the list iteration).  Accept both shapes.
    patterns: list = []
    if isinstance(sw, list):
        patterns = sw
    elif isinstance(sw, dict):
        files_field = sw.get("files")
        if isinstance(files_field, list):
            patterns = files_field
    else:
        return []

    matched: list[str] = []
    seen: set[str] = set()
    for pat in patterns:
        if not isinstance(pat, str):
            continue
        pat = pat.strip()
        if not pat or pat.startswith("#"):
            continue
        # Relative paths are globbed against root; absolute paths are
        # used verbatim.  Handles both ``src/sw/*.c`` and
        # ``/abs/path/foo.c``.
        candidate = Path(pat)
        if candidate.is_absolute():
            if candidate.is_file():
                s = str(candidate)
                if s not in seen:
                    matched.append(s)
                    seen.add(s)
            continue
        # Glob expansion via pathlib.  `.glob` understands ``**`` when
        # root is a Path object.
        for hit in sorted(root.glob(pat)):
            if hit.is_file():
                s = str(hit)
                if s not in seen:
                    matched.append(s)
                    seen.add(s)
    return matched


def _collect_project_files() -> list[str]:
    """Collect all files needed to rebuild the project from scratch.

    Reads project.yml, resolves the target config, and returns a list
    of paths (relative to project root) that should be version-controlled.
    """
    import yaml

    files: list[str] = []

    # project.yml itself
    yml = Path("project.yml")
    if not yml.exists():
        return []
    files.append("project.yml")

    with open(yml) as f:
        root_config = yaml.safe_load(f) or {}

    # Target config
    target_path = root_config.get("target", "")
    if target_path and Path(target_path).exists():
        files.append(target_path)

        # Read the target config for sources and hooks
        with open(target_path) as f:
            config = yaml.safe_load(f) or {}
    else:
        config = root_config

    # Sources: syn, sim, xdc, ip
    sources = config.get("sources", {})
    for key in ("syn", "sim", "xdc", "ip"):
        for path in sources.get(key, []):
            if Path(path).exists():
                files.append(path)

    # RTL-P1.46: embedded-software sources (C / C++ / Rust firmware for
    # soft cores like NiosV / RISC-V / MicroBlaze).  Entries may be
    # literal paths or globs (``src/software/**/*.c``) so the user can
    # declare a whole firmware tree in one line rather than enumerate
    # every translation unit.  Without this the FPGA bitstream archives
    # fine but the soft-core has no firmware — the board is dead on
    # restore.
    for entry in _expand_software_entries(sources, Path(".")):
        if entry not in files:
            files.append(entry)

    # TCL hooks
    tcl_hooks = config.get("tcl_hooks", {})
    for stage_hooks in tcl_hooks.values():
        if isinstance(stage_hooks, list):
            for hook in stage_hooks:
                if not hook.startswith("#") and Path(hook).exists():
                    files.append(hook)

    # Scaffold files
    for scaffold in ("Makefile", ".gitignore"):
        if Path(scaffold).exists():
            files.append(scaffold)

    return files


@project_group.command(name="save")
@click.option(
    "-m", "--message",
    type=str,
    default=None,
    help="Commit message (prompted if not given).",
)
@click.option(
    "--dry-run",
    is_flag=True,
    default=False,
    help="Show files that would be committed without committing.",
)
def project_save(message, dry_run):
    """Save the project — stage and commit all files needed for rebuild.

    Reads project.yml to determine which files are required: sources,
    constraints, BD hooks, target config, Makefile, and .gitignore.
    Stages exactly those files and creates a git commit.

    \b
    Example:
        rr project save
        rr project save -m "initial migration from Vivado"
        rr project save --dry-run
    """
    import subprocess

    files = _collect_project_files()
    if not files:
        console.print("❌ [red]No project.yml found.[/]")
        return

    console.print(f"📦 [blue]Project files ({len(files)}):[/]")
    for f in files:
        console.print(f"   {f}")

    if dry_run:
        console.print("\n[dim]Dry run — nothing committed.[/]")
        return

    # Check if we're in a git repo
    result = subprocess.run(
        ["git", "rev-parse", "--is-inside-work-tree"],
        capture_output=True, text=True,
    )
    if result.returncode != 0:
        console.print(
            "\n[yellow]Not a git repository. Initialising...[/]"
        )
        subprocess.run(["git", "init", "-b", "main"], check=True)

    # Stage the files
    subprocess.run(["git", "add"] + files, check=True)

    # Check if there's anything to commit
    status = subprocess.run(
        ["git", "diff", "--cached", "--quiet"],
        capture_output=True,
    )
    if status.returncode == 0:
        console.print("\n[dim]Nothing new to commit — project is up to date.[/]")
        return

    # Commit
    if not message:
        # Auto-generate from project name
        import yaml

        with open("project.yml") as f:
            root = yaml.safe_load(f) or {}
        target = root.get("target", "")
        if target and Path(target).exists():
            with open(target) as f:
                cfg = yaml.safe_load(f) or {}
        else:
            cfg = root
        name = cfg.get("project", {}).get("name", "project")
        message = f"rr project save: {name}"

    subprocess.run(["git", "commit", "-m", message], check=True)
    console.print(f"\n✅ Committed {len(files)} project file(s)")


# RTL-P2.373: extensions that count as build binaries — used by the
# classifier, the --no-binaries filter, and for per-target path scoping.
# Kept here as the single source of truth next to _collect_archive_files.
_BITSTREAM_EXTS = frozenset({
    ".bit", ".ltx", ".sof", ".pof", ".jic", ".rbf",
    ".xsa", ".qar", ".dcp", ".bin",
})

_OUTPUT_DIR_NAMES = frozenset({
    "bitstream", "build", "dcp", "reports", "project",
})

# RTL-P2.408: extensions that compress well (text-like) vs. poorly
# (binary-like).  Used only for the gzip-size estimate in the archive
# dry-run banner — actual tar+gzip figures can vary, we just want the
# right order of magnitude so users can decide between source-only
# (tiny) and --with-outputs (often >100 MB for real FPGA projects).
_TEXT_LIKE_EXTS = frozenset({
    ".v", ".sv", ".svh", ".vhd", ".vhdl", ".tcl", ".xdc", ".sdc", ".qsf",
    ".qpf", ".xml", ".yml", ".yaml", ".json", ".md", ".txt", ".sh", ".mk",
    ".py", ".c", ".cc", ".cpp", ".h", ".hpp", ".rs", ".rpt", ".log",
    ".toml", ".cfg", ".ini", ".gitignore", ".gitattributes",
})
_BINARY_LIKE_EXTS = frozenset({
    ".bit", ".ltx", ".sof", ".pof", ".jic", ".rbf", ".xsa", ".qar",
    ".dcp", ".bin", ".png", ".jpg", ".jpeg", ".gif", ".pdf", ".zip",
    ".tar", ".gz", ".xz", ".bz2", ".so", ".a", ".o", ".dll", ".exe",
})


def _fmt_bytes(n: int) -> str:
    """Compact human-friendly size string ("42 KB", "3.2 MB", "1.1 GB")."""
    if n < 1024:
        return f"{n} B"
    if n < 1024 * 1024:
        return f"{n / 1024:.0f} KB"
    if n < 1024 * 1024 * 1024:
        return f"{n / 1024 / 1024:.1f} MB"
    return f"{n / 1024 / 1024 / 1024:.2f} GB"


def _estimate_gzip_ratio(suffix: str) -> float:
    """Return a rough bytes-after-gzip multiplier for *suffix*.

    Text-like = 0.20, binary-like = 0.95, unknown = 0.40.  These are
    coarse heuristics — the dry-run banner just needs the right order
    of magnitude for "should I --with-outputs or not" decisions.
    """
    s = suffix.lower()
    if s in _TEXT_LIKE_EXTS:
        return 0.20
    if s in _BINARY_LIKE_EXTS:
        return 0.95
    return 0.40


def _summarise_archive_size(
    files: list[str],
) -> tuple[int, int, list[tuple[str, int]]]:
    """Return ``(uncompressed_bytes, gzip_estimate_bytes, top3_by_size)``.

    RTL-P2.408: powers the dry-run size banner.  Silently skips files
    that vanished between collection and stat (rare but possible when a
    build hook cleans up under us).
    """
    uncompressed = 0
    gzip_est = 0.0
    sized: list[tuple[str, int]] = []
    for f in files:
        try:
            size = Path(f).stat().st_size
        except (OSError, FileNotFoundError):
            continue
        uncompressed += size
        gzip_est += size * _estimate_gzip_ratio(Path(f).suffix)
        sized.append((f, size))
    sized.sort(key=lambda pair: pair[1], reverse=True)
    return uncompressed, int(gzip_est), sized[:3]


# RTL-P2.401: path segments that identify vendor scaffold / tool cache
# directories.  Any path whose components intersect this set is filtered
# out of the archive file list — they're regeneratable and can be huge.
# Keeps `project/` (Vivado/Quartus scaffold), .Xil (Vivado log dir),
# db/incremental_db/qdb (Quartus DBs), output_files (Quartus reports
# tree), ip_cache (Vivado), sim_build (cocotb build tree), __pycache__,
# .pytest_cache.  `bitstream` / `dcp` / `reports` are scoped-output
# directories that we already glob explicitly under --with-outputs, and
# left OUT of this filter so the allow-listed extensions (_BITSTREAM_EXTS)
# survive.  `build` is intentionally excluded too — users point their
# output_dir at `build/<target>` and we must not strip that prefix.
_SCAFFOLD_SEGMENTS = frozenset({
    "project", ".Xil", "db", "incremental_db", "qdb",
    "output_files", "ip_cache", "sim_build",
    "__pycache__", ".pytest_cache",
})


def _is_scaffold_path(rel: str) -> bool:
    """True when any path segment matches a known vendor scaffold dir."""
    try:
        parts = Path(rel).parts
    except (TypeError, ValueError):
        return False
    return any(seg in _SCAFFOLD_SEGMENTS for seg in parts)


def _strip_scaffold(
    files: list[str],
    *,
    include_outputs: bool,
) -> list[str]:
    """Return *files* with vendor scaffold paths filtered out.

    RTL-P2.401: a path is kept when ANY of:
      * It has no scaffold segment.
      * ``include_outputs=True`` AND its extension is in
        _BITSTREAM_EXTS (.bit / .sof / .pof / .jic / .rbf / .xsa / .qar
        / .dcp / .bin / .ltx).  This carves out the "user explicitly
        asked for outputs, the output happens to live inside project/"
        case (typical Quartus SOF / non-canonical Vivado bit).

    Dedupe is preserved (stable order, first occurrence wins).
    """
    out: list[str] = []
    seen: set[str] = set()
    for f in files:
        if f in seen:
            continue
        if _is_scaffold_path(f):
            if include_outputs and Path(f).suffix in _BITSTREAM_EXTS:
                out.append(f)
                seen.add(f)
            continue
        out.append(f)
        seen.add(f)
    return out


def _resolve_active_output_dir(config: dict | None = None) -> Path:
    """Return the active target's ``output_dir`` as a relative Path.

    RTL-P2.373: target yml's ``project.output_dir`` (falling back to
    ``makefile_overrides.output_dir`` then to ``"."``) sets the prefix
    under which all build artefacts live.  Default ``.`` means flat
    layout — backwards-compat with every pre-P2.373 project.
    """
    if config is None:
        from sdk.cli.project_config import load_project_config
        try:
            config = load_project_config()
        except (OSError, ValueError):
            return Path(".")
    if not isinstance(config, dict):
        return Path(".")
    project = config.get("project", {}) if isinstance(config.get("project"), dict) else {}
    mk = config.get("makefile_overrides", {}) if isinstance(config.get("makefile_overrides"), dict) else {}
    out = mk.get("output_dir") or project.get("output_dir") or "."
    return Path(out)


def _collect_archive_files(
    output_dir: Path | None = None,
    include_outputs: bool = False,
) -> list[str]:
    """Collect files for a reproducible project archive.

    Defaults to *sources only* — the rebuild set from
    ``_collect_project_files()`` plus lockfiles, ip_paths, and the cocotb
    tree.  Build outputs (bitstream, DCP, XSA, QAR, reports, non-canonical
    project/ artefacts) are **excluded** unless ``include_outputs=True``
    (RTL-P2.397).

    RTL-P2.373: *output_dir* scopes the build-output globs so multi-target
    projects archive only the active target's artefacts.  Defaults to ``.``
    (flat layout) which matches pre-P2.373 behaviour exactly.
    """
    if output_dir is None:
        output_dir = _resolve_active_output_dir()

    # Start with the rebuild set (sources, constraints, hooks, scaffold)
    files = _collect_project_files()
    if not files:
        return []

    archive_extras = [
        # Lock files — resolved state for exact reproducibility
        "routertl.lock",
        # Build environment (derived from project.yml but needed for TCL)
        "build_env.mk",
        "build_env.tcl",
        # Version
        "VERSION",
        # RTL-P2.424: users expect gitignore/gitattributes rules to
        # survive a restore (especially after RTL-P2.411 which hints
        # users to append scaffold rules to .gitignore).  Both are
        # small text files; cheap to always include when present.
        ".gitignore",
        ".gitattributes",
    ]

    for f in archive_extras:
        if Path(f).exists() and f not in files:
            files.append(f)

    # Build outputs — bitstream, XSA, DCP, reports.  Vendor coverage:
    #   Xilinx:  .bit / .ltx / .xsa / .dcp
    #   Altera/Intel (RTL-P2.354): .sof / .pof / .jic / .rbf + the
    #     Quartus archive .qar so post-restore builds have the full
    #     project snapshot, not just the bitstream.
    # RTL-P2.349: also glob the project/ directory for bitstream-shaped
    # artefacts.  Quartus defaults to writing the SOF there rather than
    # under bitstream/, so pre-P2.349 the archive reported
    # "Build outputs (0 files)" even when a 36 MB SOF existed on disk.
    #
    # RTL-P2.397: this whole block is opt-in via ``include_outputs``.
    # The archive default is sources-only — users ship bitstreams via
    # separate release tarballs / cloud storage, not by bundling them
    # into reproducibility snapshots.  --with-outputs re-includes them.
    if include_outputs:
        output_globs = [
            ("bitstream", "*.bit"),
            ("bitstream", "*.ltx"),
            ("bitstream", "*.sof"),
            ("bitstream", "*.pof"),
            ("bitstream", "*.jic"),
            ("bitstream", "*.rbf"),
            ("build", "*.xsa"),
            ("build", "*.qar"),
            ("dcp", "synthesis.dcp"),
            ("dcp", "implementation.dcp"),
            # RTL-P2.349: non-canonical Quartus / Vivado output locations.
            ("project", "*.sof"),
            ("project", "*.pof"),
            ("project", "*.jic"),
            ("project", "*.rbf"),
            ("project", "*.bit"),
        ]
        # RTL-P2.373: prefix each subdir with the active target's output_dir.
        # When output_dir == ".", the resolved path is the legacy flat dir.
        for directory, pattern in output_globs:
            d = output_dir / directory
            if d.exists():
                for f in d.glob(pattern):
                    rel = str(f)
                    if rel not in files:
                        files.append(rel)

        # Reports — also scoped to output_dir (RTL-P2.373)
        reports_dir = output_dir / "reports"
        if reports_dir.exists():
            for f in reports_dir.iterdir():
                if f.is_file() and f.suffix in (".rpt", ".json", ".txt"):
                    rel = str(f)
                    if rel not in files:
                        files.append(rel)

    # IP lock files / dependency files
    for lock_pattern in ("ip.lock", "*.lock.yml"):
        for f in Path(".").glob(lock_pattern):
            rel = str(f)
            if rel not in files:
                files.append(rel)

    # Source packages (auto-generated HDL from regbank, build metadata, etc.)
    for gen_dir in ("src/pkg",):
        d = Path(gen_dir)
        if d.exists():
            for f in d.iterdir():
                if f.is_file():
                    rel = str(f)
                    if rel not in files:
                        files.append(rel)

    # IP repository directories (sources.ip_paths) — custom/user IPs needed
    # for block design generation.  Only include relative (in-tree) paths;
    # absolute paths can't be relocated.
    import yaml

    yml = Path("project.yml")
    cfg: dict = {}
    root_cfg: dict = {}
    if yml.exists():
        with open(yml) as f:
            root_cfg = yaml.safe_load(f) or {}
        target = root_cfg.get("target", "")
        if target and Path(target).exists():
            with open(target) as f:
                cfg = yaml.safe_load(f) or {}
        else:
            cfg = root_cfg
        ip_paths = cfg.get("sources", {}).get("ip_paths", [])
        for ip_dir in ip_paths:
            p = Path(ip_dir)
            if p.is_absolute() or not p.is_dir():
                continue
            for f in p.rglob("*"):
                if f.is_file():
                    rel = str(f)
                    if rel not in files:
                        files.append(rel)

    # Cocotb testbench tree — the whole simulation root so a restored
    # archive is actually simulatable, not just synthesisable
    # (RTL-P2.345).  Resolve from simulation.test_dir (strip a trailing
    # /tests segment to get the cocotb root, matching the convention
    # used by routertl_core/sim/simulation.py) and fall back to the
    # canonical sim/cocotb/ layout.
    sim_cfg = cfg.get("simulation", {}) if cfg else {}
    test_dir = sim_cfg.get("test_dir")
    if test_dir:
        td_path = Path(test_dir)
        cocotb_root = td_path.parent if td_path.name == "tests" else td_path
    else:
        cocotb_root = Path("sim/cocotb")

    if cocotb_root.is_dir():
        # Skip generated subtrees — they're regenerable and bulky.
        skip_segments = {
            "build", "logs", "waves", "sim_build",
            "__pycache__", ".pytest_cache",
        }
        for f in cocotb_root.rglob("*"):
            if not f.is_file():
                continue
            if any(seg in skip_segments for seg in f.parts):
                continue
            rel = str(f)
            if rel not in files:
                files.append(rel)

    # RTL-P2.401: final pass — never let vendor project scaffold leak
    # into the archive, regardless of how it got into the list (a user
    # who set sources.ip_paths=[project] would otherwise drag the whole
    # Vivado .runs/ tree + .cache/ + .Xil/ logs into their source-only
    # archive).  Under --with-outputs, legitimate bit/sof/xsa/etc.
    # living inside project/ still pass through because _strip_scaffold
    # whitelists _BITSTREAM_EXTS when include_outputs is True.
    return _strip_scaffold(files, include_outputs=include_outputs)


def _collect_all_targets_archive_files(include_outputs: bool = False) -> list[str]:
    """Union the archive file lists across every ``targets/*.yml``.

    RTL-P2.373 + RTL-P2.366 (folded): a multi-target project (like
    sdi_claude with base / passthrough / crossbar) wants one tarball
    covering every target's sources + build outputs.  We enumerate the
    target ymls, parse each one's ``project.output_dir`` (defaulting to
    ``.`` for flat layouts), and glob each target's artefacts under its
    scoped output dir.

    The active-target resolution path (``project.yml`` → ``target:``)
    provides the *source* file list for this flow by calling the
    regular collector once per target via the RR_TARGET override.  To
    keep the implementation simple and avoid recursive refactoring of
    ``_collect_archive_files`` we shortcut: union the active target's
    full collection + every *other* target's build outputs globbed
    directly under their declared output_dirs.  Sources tracked in
    ``sources.syn`` / ``sources.xdc`` / ``paths.sources`` are shared
    across targets in practice, so this yields the same union the
    user expects without a per-target collector rewrite.
    """
    import yaml

    # Start with the active target's full collection.
    files = _collect_archive_files(include_outputs=include_outputs)

    targets_dir = Path("targets")
    if not targets_dir.is_dir():
        return files

    seen = set(files)
    for target_yml in sorted(targets_dir.glob("*.yml")):
        if target_yml.name == "migration_report.txt":
            continue
        try:
            with open(target_yml) as f:
                tcfg = yaml.safe_load(f) or {}
        except (OSError, yaml.YAMLError):
            continue
        if not isinstance(tcfg, dict):
            continue

        # RTL-P2.397: per-target outputs only when explicitly opted in.
        if include_outputs:
            out_dir = _resolve_active_output_dir(tcfg)
            for directory, pattern in (
                ("bitstream", "*.bit"), ("bitstream", "*.ltx"),
                ("bitstream", "*.sof"), ("bitstream", "*.pof"),
                ("bitstream", "*.jic"), ("bitstream", "*.rbf"),
                ("build", "*.xsa"), ("build", "*.qar"),
                ("dcp", "synthesis.dcp"), ("dcp", "implementation.dcp"),
                ("project", "*.sof"), ("project", "*.pof"),
                ("project", "*.jic"), ("project", "*.rbf"),
                ("project", "*.bit"),
            ):
                d = out_dir / directory
                if d.exists():
                    for f in d.glob(pattern):
                        rel = str(f)
                        if rel not in seen:
                            files.append(rel)
                            seen.add(rel)
            reports = out_dir / "reports"
            if reports.exists():
                for f in reports.iterdir():
                    if f.is_file() and f.suffix in (".rpt", ".json", ".txt"):
                        rel = str(f)
                        if rel not in seen:
                            files.append(rel)
                            seen.add(rel)

        # Always include the target yml itself.
        rel = str(target_yml)
        if rel not in seen:
            files.append(rel)
            seen.add(rel)

    # RTL-P2.401: same final scaffold filter as _collect_archive_files.
    return _strip_scaffold(files, include_outputs=include_outputs)


@project_group.command(name="size")
@click.option(
    "--with-outputs", "with_outputs",
    is_flag=True, default=False,
    help="Include build outputs (bit/sof/xsa/qar/dcp/reports) in the "
         "size estimate.  Default: source-only (matches rr project "
         "archive default semantics from RTL-P2.397).",
)
@click.option(
    "--all-targets", "all_targets",
    is_flag=True, default=False,
    help="Union every targets/*.yml's sources (matches rr project "
         "archive --all-targets).",
)
def project_size(with_outputs, all_targets):
    """Show the estimated archive size of the project (RTL-P2.417).

    \b
    Fast "how big is my project?" snapshot — no file list noise, just
    the totals.  Reuses the same collectors that back rr project
    archive so the number is truthful without actually tar'ing.

    \b
    Examples:
        rr project size                         # source-only (default)
        rr project size --with-outputs          # include bitstream + reports
        rr project size --all-targets           # multi-target union
    """
    if not Path("project.yml").exists():
        console.print("❌ [red]No project.yml in the current directory.[/]")
        sys.exit(1)

    if all_targets:
        files = _collect_all_targets_archive_files(include_outputs=with_outputs)
    else:
        files = _collect_archive_files(include_outputs=with_outputs)

    if not files:
        console.print("  [dim]No files collected.[/]")
        return

    uncompressed, gzip_est, top3 = _summarise_archive_size(files)

    # Classify for the breakdown line.  Reuse the _OUTPUT_DIR_NAMES
    # heuristic from the archive command — files under output dirs or
    # with bitstream extensions count as build outputs.
    sources = metadata = outputs = 0
    metadata_names = {"routertl.lock", "build_env.mk", "build_env.tcl",
                      "VERSION", "ip.lock", "Makefile", ".gitignore",
                      ".gitattributes"}
    for f in files:
        p = Path(f)
        if p.name in metadata_names or p.name.endswith(".lock.yml"):
            metadata += 1
        elif p.suffix in _BITSTREAM_EXTS or any(
            seg in _OUTPUT_DIR_NAMES and seg != "project"
            for seg in p.parts
        ):
            outputs += 1
        else:
            sources += 1

    console.print(
        f"📦 [bold]Project archive size[/] "
        f"[dim]({'all targets' if all_targets else 'active target'}"
        f"{', with outputs' if with_outputs else ', source-only'})[/]"
    )
    console.print(f"   [dim]Files:[/]        [cyan]{len(files)}[/]")
    console.print(f"   [dim]  Sources:[/]    {sources}")
    console.print(f"   [dim]  Metadata:[/]   {metadata}")
    if with_outputs:
        console.print(f"   [dim]  Outputs:[/]    {outputs}")
    console.print(
        f"   [dim]Uncompressed:[/] [bold cyan]{_fmt_bytes(uncompressed)}[/]"
    )
    console.print(
        f"   [dim]Gzipped:[/]      [cyan]~{_fmt_bytes(gzip_est)}[/] "
        "[dim](estimate)[/]"
    )

    if uncompressed > 100 * 1024 * 1024 and top3:
        console.print("\n   [dim]Biggest 3 files:[/]")
        for path, size in top3:
            console.print(f"     [dim]{_fmt_bytes(size):>9}  {path}[/]")


@project_group.command(name="archive")
@click.option(
    "-o", "--output",
    type=click.Path(),
    default=None,
    help="Output archive path (default: <project_name>_<tag>.tar.gz).",
)
@click.option(
    "--tag", "-t",
    type=str,
    default=None,
    help="Git tag to create for this archive snapshot.",
)
@click.option(
    "--no-tag",
    is_flag=True,
    default=False,
    help="Skip git tagging.",
)
@click.option(
    "--dry-run",
    is_flag=True,
    default=False,
    help="Show files that would be archived without creating the archive.",
)
@click.option(
    "--all-targets",
    "all_targets",
    is_flag=True,
    default=False,
    help="Union file lists from every target in targets/*.yml — archive "
         "all variants of a multi-target project in one tarball "
         "(RTL-P2.373).",
)
@click.option(
    "--with-outputs",
    "with_outputs",
    is_flag=True,
    default=False,
    help="Include build outputs (bitstream .bit/.sof/.pof/.jic/.rbf/.ltx, "
         ".xsa, .qar, DCPs, reports).  Default: exclude — archives are "
         "source-only snapshots for reproducibility, outputs should ship "
         "as separate release tarballs (RTL-P2.397).",
)
@click.option(
    "--no-binaries",
    "no_binaries",
    is_flag=True,
    default=False,
    hidden=True,
    help="(deprecated — default behaviour since RTL-P2.397).",
)
def project_archive(
    output, tag, no_tag, dry_run, all_targets, with_outputs, no_binaries,
):
    """Archive the project — snapshot the rebuild set into a .tar.gz.

    Default: source-only snapshot (project.yml, target yml, sources,
    constraints, BD/TCL hooks, lockfiles, cocotb tree, software firmware,
    ip_paths).  The archive is what you'd commit to git; rebuild with
    ``rr synth run && rr bitstream`` after restore.

    Pass ``--with-outputs`` to additionally pack bitstream, XSA, QAR, DCP,
    and reports — useful for delivering a ready-to-flash snapshot.  Note
    FPGA bitstreams are large and typically ship separately (release
    tarball, cloud storage) rather than inside the reproducibility archive.

    Optionally creates a git tag for traceability.

    \b
    Examples:
        rr project archive                          # source-only (default)
        rr project archive --with-outputs           # include bitstream + reports
        rr project archive -t v1.0-release
        rr project archive -o deliverable.tar.gz --no-tag
        rr project archive --dry-run
        rr project archive --all-targets            # multi-target source bundle
        rr project archive --all-targets --with-outputs
    """
    import subprocess
    import tarfile

    import yaml

    # Regenerate build_env so the archive doesn't package stale files
    if Path("project.yml").exists():
        from sdk.cli.engine_dispatch import run_engine_script

        with cli_resilient_block("build_env regeneration before archive"):
            run_engine_script("project_manager.py", ["project.yml"])

    # RTL-P2.397: --no-binaries is now a deprecated no-op (it matches the
    # new default).  Warn but accept so existing scripts don't break.
    if no_binaries:
        console.print(
            "  [yellow]--no-binaries is deprecated — outputs are now "
            "excluded by default (RTL-P2.397).  Pass --with-outputs to "
            "include them.[/]"
        )

    if all_targets:
        files = _collect_all_targets_archive_files(include_outputs=with_outputs)
    else:
        files = _collect_archive_files(include_outputs=with_outputs)

    if not files:
        console.print("❌ [red]No project.yml found.[/]")
        return

    # Resolve project name for defaults
    with open("project.yml") as f:
        root = yaml.safe_load(f) or {}
    target = root.get("target", "")
    if target and Path(target).exists():
        with open(target) as f:
            cfg = yaml.safe_load(f) or {}
    else:
        cfg = root
    project_name = cfg.get("project", {}).get("name", "project")

    # ── Git tag ──
    git_hash = ""
    in_git = subprocess.run(
        ["git", "rev-parse", "--is-inside-work-tree"],
        capture_output=True, text=True,
    ).returncode == 0

    if not no_tag and in_git:
        result = subprocess.run(
            ["git", "rev-parse", "--short", "HEAD"],
            capture_output=True, text=True,
        )
        if result.returncode == 0:
            git_hash = result.stdout.strip()

        if tag is None:
            # Auto-generate tag from project name + date
            from datetime import datetime
            date_str = datetime.now().strftime("%Y%m%d")
            tag = f"archive/{project_name}/{date_str}"

        if not dry_run:
            # Check if tag exists
            check = subprocess.run(
                ["git", "tag", "-l", tag],
                capture_output=True, text=True,
            )
            if check.stdout.strip():
                console.print(
                    f"  [yellow]⚠️  Tag '{tag}' already exists — skipping tag.[/]"
                )
            else:
                subprocess.run(
                    ["git", "tag", "-a", tag, "-m",
                     f"rr project archive: {project_name}"],
                    check=True,
                )
                console.print(f"🏷️  Tagged: [cyan]{tag}[/]")
    elif not no_tag and not in_git:
        console.print("  [dim]Not a git repository — skipping tag.[/]")

    # ── Classify files for display ──
    sources = []
    build_outputs = []
    metadata = []
    software = []

    # RTL-P2.349: extensions that count as build outputs regardless of
    # which directory they live in — so a Quartus SOF under project/
    # still classifies as "Build outputs" rather than "Sources".
    # RTL-P2.373: _BITSTREAM_EXTS + _OUTPUT_DIR_NAMES now live at
    # module scope, used by both the archive classifier and the
    # --no-binaries filter.

    # RTL-P1.46: compute the set of files that came from
    # sources.software so we can surface them under their own bucket
    # rather than lumping embedded firmware in with HDL sources.
    software_set: set[str] = set()
    with cli_resilient_block("sources.software classification"):
        import yaml as _yaml  # local import — yaml already imported at top

        if Path("project.yml").exists():
            with open("project.yml") as _f:
                _root_cfg = _yaml.safe_load(_f) or {}
            _target_path = _root_cfg.get("target", "") if isinstance(_root_cfg, dict) else ""
            if _target_path and Path(_target_path).exists():
                with open(_target_path) as _f:
                    _cfg = _yaml.safe_load(_f) or {}
            else:
                _cfg = _root_cfg
            if isinstance(_cfg, dict):
                software_set = set(
                    _expand_software_entries(
                        _cfg.get("sources", {}) or {}, Path("."),
                    )
                )

    # RTL-P2.373: archive classification now segment-based so nested
    # per-target paths (build/alpha/bitstream/system.bit) are tagged as
    # build outputs, not lumped in with sources.
    for f in files:
        p = Path(f)
        segments = set(p.parts)
        if f in software_set:
            software.append(f)
        elif p.suffix in _BITSTREAM_EXTS:
            build_outputs.append(f)
        elif segments & {"bitstream", "build", "dcp"}:
            build_outputs.append(f)
        elif p.suffix in (".rpt", ".json", ".txt") and "reports" in segments:
            metadata.append(f)
        elif p.name in ("routertl.lock", "build_env.mk", "build_env.tcl",
                         "VERSION", "ip.lock", "Makefile", ".gitignore",
                         "project.yml") or p.suffix in (".yml", ".lock"):
            metadata.append(f)
        else:
            sources.append(f)

    console.print(f"\n📦 [bold cyan]Project Archive: {project_name}[/]")
    if git_hash:
        console.print(f"   [dim]Git: {git_hash}[/]")
    console.print()

    console.print(f"  [blue]Sources & constraints[/]  ({len(sources)} files)")
    for f in sources:
        console.print(f"    {f}")

    # RTL-P1.46: embedded-software bucket — distinct from Sources so
    # soft-core firmware is visible as a first-class archive input.
    if software:
        console.print(f"\n  [blue]Software[/]               ({len(software)} files)")
        for f in software:
            console.print(f"    {f}")

    # RTL-P2.397: the "Build outputs" section and the empty-set warning
    # are only meaningful when the user opted in with --with-outputs.
    # Default (source-only) runs should not advertise an empty bucket.
    if with_outputs:
        console.print(
            f"\n  [blue]Build outputs[/]          ({len(build_outputs)} files)"
        )
        for f in build_outputs:
            size = Path(f).stat().st_size
            size_str = (
                f"{size / 1024 / 1024:.1f} MB"
                if size > 1024 * 1024
                else f"{size / 1024:.0f} KB"
            )
            console.print(f"    {f}  [dim]({size_str})[/]")

        # RTL-P2.349: loudly warn when the user asked for outputs but got
        # none — archiving pre-synth, or SOF in an un-globbed path,
        # previously produced a useless tarball with no warning.
        if not build_outputs:
            console.print(
                "\n⚠  [yellow bold]No build outputs found.[/] "
                "[yellow]The archive will not contain any bitstream / DCP / "
                "XSA.[/]\n"
                "   [dim]Hints: run `rr bitstream run` or `rr synth run` "
                "first, or check that outputs live under "
                "[cyan]bitstream/[/] [cyan]build/[/] [cyan]dcp/[/] "
                "[cyan]project/[/].[/]"
            )

    console.print(f"\n  [blue]Metadata & lock[/]        ({len(metadata)} files)")
    for f in metadata:
        console.print(f"    {f}")

    total = len(files)
    uncompressed, gzip_est, top3 = _summarise_archive_size(files)
    console.print(
        f"\n  [dim]Total: {total} files — "
        f"{_fmt_bytes(uncompressed)} uncompressed, "
        f"~{_fmt_bytes(gzip_est)} gzipped (estimate)[/]"
    )

    # RTL-P2.408: when the total blows past 100 MB, surface the biggest
    # three files so users spot the culprit without wading through the
    # full list.  Threshold is uncompressed bytes (bitstream-heavy
    # archives often sit around 80 MB uncompressed but compress to <5 MB
    # thanks to DCP text).
    _ARCHIVE_TOP3_THRESHOLD = 100 * 1024 * 1024
    if uncompressed > _ARCHIVE_TOP3_THRESHOLD and top3:
        console.print(
            f"  [dim]Biggest 3 files (of {total}):[/]"
        )
        for path, size in top3:
            console.print(f"    [dim]{_fmt_bytes(size):>9}  {path}[/]")

    # ── Warn about unreferenced files in source directories ──
    _SOURCE_EXTS = {
        ".v", ".sv", ".vhd", ".vhdl", ".xdc", ".sdc",
        ".tcl", ".mem", ".coe", ".hex", ".dat",
    }
    source_dirs = set()
    for f in files:
        p = Path(f)
        if p.suffix.lower() in _SOURCE_EXTS and p.parts[0] in (
            "hw", "src", "tcl", "rtl",
        ):
            source_dirs.add(str(p.parent))

    unreferenced: list[str] = []
    archived_set = set(files)
    for d in sorted(source_dirs):
        dp = Path(d)
        if dp.is_dir():
            for on_disk in dp.iterdir():
                if (
                    on_disk.is_file()
                    and on_disk.suffix.lower() in _SOURCE_EXTS
                    and str(on_disk) not in archived_set
                ):
                    unreferenced.append(str(on_disk))

    if unreferenced:
        console.print(
            f"\n💡 [dim]{len(unreferenced)} file(s) in source directories "
            f"not referenced by target config — not included:[/]"
        )
        for uf in unreferenced:
            console.print(f"    [dim]{uf}[/]")

    # ── Warn about non-relocatable absolute ip_paths (RTL-P2.272) ──
    ip_paths = cfg.get("sources", {}).get("ip_paths", [])
    abs_paths = [p for p in ip_paths if Path(p).is_absolute()]
    if abs_paths:
        console.print(
            f"\n⚠️  [yellow]{len(abs_paths)} absolute ip_paths won't travel "
            f"with the archive:[/]"
        )
        for p in abs_paths:
            console.print(f"    [yellow]{p}[/]")
        console.print(
            "   [dim]Consider making these relative or copying IP repos "
            "into the project tree before archiving.[/]"
        )

    if dry_run:
        console.print("\n[dim]Dry run — no archive created.[/]")
        return

    # ── Create tar.gz ──
    if output is None:
        tag_suffix = tag.replace("/", "_") if tag else git_hash or "snapshot"
        # RTL-P3.159: avoid duplicating project_name in the filename when
        # the tag already contains it (e.g. the auto-generated
        # 'archive/<project_name>/<date>' flattens to
        # 'archive_<project_name>_<date>', otherwise yielding
        # '<project_name>_archive_<project_name>_<date>.tar.gz').
        if project_name and project_name in tag_suffix:
            output = f"{tag_suffix}.tar.gz"
        else:
            output = f"{project_name}_{tag_suffix}.tar.gz"

    # Archive into a top-level directory named after the project
    archive_prefix = f"{project_name}/"

    with tarfile.open(output, "w:gz") as tar:
        for f in files:
            tar.add(f, arcname=f"{archive_prefix}{f}")

    archive_size = Path(output).stat().st_size
    size_str = f"{archive_size / 1024 / 1024:.1f} MB"

    console.print(f"\n✅ Archive created: [cyan]{output}[/] ({size_str})")
    console.print(f"   [dim]Restore: rr project restore {output}[/]")
    console.print(f"   [dim]Rebuild: cd {project_name} && rr synth run && rr bitstream[/]")


@project_group.command(name="restore")
@click.argument("archive", type=click.Path(exists=True))
@click.option(
    "-o", "--output",
    type=click.Path(),
    default=None,
    help="Output directory (default: current directory).",
)
@click.option(
    "--dry-run",
    is_flag=True,
    default=False,
    help="Show files that would be restored without extracting.",
)
@click.option(
    "--force",
    is_flag=True,
    default=False,
    help="Overwrite existing files without prompting.",
)
def project_restore(archive, output, dry_run, force):
    """Restore a project from an rr project archive.

    Extracts a .tar.gz archive created by 'rr project archive' into the
    target directory, recreating the full project structure (sources,
    constraints, build outputs, lock files, and metadata).

    \b
    Examples:
        rr project restore my_project_v1.0.tar.gz
        rr project restore my_project_v1.0.tar.gz -o ./restored
        rr project restore my_project_v1.0.tar.gz --dry-run
        rr project restore my_project_v1.0.tar.gz --force
    """
    import tarfile

    archive_path = Path(archive)
    if not tarfile.is_tarfile(str(archive_path)):
        console.print(f"❌ [red]Not a valid tar archive:[/] {archive}")
        return

    with tarfile.open(str(archive_path), "r:gz") as tar:
        members = tar.getmembers()

        if not members:
            console.print("❌ [red]Archive is empty.[/]")
            return

        # Detect the archive prefix (project_name/) added by project_archive
        first = members[0].name
        prefix = ""
        if "/" in first:
            candidate = first.split("/")[0] + "/"
            if all(m.name.startswith(candidate) or m.name == candidate.rstrip("/")
                   for m in members if not m.isdir()):
                prefix = candidate

        # Security: reject path traversal
        for m in members:
            name = m.name.removeprefix(prefix) if prefix else m.name
            resolved = (Path(output or ".") / name).resolve()
            base = Path(output or ".").resolve()
            if not str(resolved).startswith(str(base)):
                console.print(
                    f"❌ [red]Archive contains path traversal:[/] {m.name}"
                )
                return

        # Classify files for display
        sources = []
        build_outputs = []
        metadata = []
        for m in members:
            if m.isdir():
                continue
            name = m.name.removeprefix(prefix) if prefix else m.name
            p = Path(name)
            if p.parts and p.parts[0] in ("bitstream", "build", "dcp"):
                build_outputs.append((name, m.size))
            elif p.suffix in (".rpt", ".json", ".txt") and "reports" in p.parts:
                metadata.append(name)
            elif p.name in ("routertl.lock", "build_env.mk", "build_env.tcl",
                             "VERSION", "ip.lock", "Makefile", ".gitignore",
                             "project.yml") or p.suffix in (".yml", ".lock"):
                metadata.append(name)
            else:
                sources.append(name)

        project_name = prefix.rstrip("/") if prefix else archive_path.stem
        dest = Path(output) if output else Path(".")

        console.print(f"\n📦 [bold cyan]Restore Archive: {project_name}[/]")
        console.print(f"   [dim]From: {archive}[/]")
        console.print(f"   [dim]To:   {dest.resolve()}[/]")
        console.print()

        console.print(f"  [blue]Sources & constraints[/]  ({len(sources)} files)")
        for f in sources:
            console.print(f"    {f}")

        console.print(f"\n  [blue]Build outputs[/]          ({len(build_outputs)} files)")
        for f, size in build_outputs:
            size_str = (f"{size / 1024 / 1024:.1f} MB" if size > 1024 * 1024
                        else f"{size / 1024:.0f} KB")
            console.print(f"    {f}  [dim]({size_str})[/]")

        console.print(f"\n  [blue]Metadata & lock[/]        ({len(metadata)} files)")
        for f in metadata:
            console.print(f"    {f}")

        total = len(sources) + len(build_outputs) + len(metadata)
        console.print(f"\n  [dim]Total: {total} files[/]")

        if dry_run:
            console.print("\n[dim]Dry run — no files extracted.[/]")
            return

        # Check for existing files that would be overwritten
        if not force:
            conflicts = []
            for m in members:
                if m.isdir():
                    continue
                name = m.name.removeprefix(prefix) if prefix else m.name
                target = dest / name
                if target.exists():
                    conflicts.append(name)

            if conflicts:
                console.print(
                    f"\n⚠️  [yellow]{len(conflicts)} file(s) already exist "
                    f"and would be overwritten:[/]"
                )
                for c in conflicts[:10]:
                    console.print(f"    [yellow]{c}[/]")
                if len(conflicts) > 10:
                    console.print(
                        f"    [dim]... and {len(conflicts) - 10} more[/]"
                    )
                if not click.confirm("\nOverwrite existing files?"):
                    console.print("[dim]Restore cancelled.[/]")
                    return

        # Extract files, stripping the prefix
        dest.mkdir(parents=True, exist_ok=True)
        extracted = 0
        for m in members:
            name = m.name.removeprefix(prefix) if prefix else m.name
            if not name or name == ".":
                continue
            target = dest / name
            if m.isdir():
                target.mkdir(parents=True, exist_ok=True)
            else:
                target.parent.mkdir(parents=True, exist_ok=True)
                with tar.extractfile(m) as src:
                    if src is not None:
                        target.write_bytes(src.read())
                extracted += 1

    console.print(f"\n✅ Restored [cyan]{extracted}[/] files to [cyan]{dest.resolve()}[/]")

    # ── Regenerate build_env from project.yml (RTL-P2.272) ──
    # The archived build_env.mk may be stale (e.g. wrong XDC_FILES).
    # After extraction, project.yml has an *earlier* mtime than build_env.mk
    # (sequential tar extraction), so ensure_build_env() would skip regen.
    # Force a fresh regeneration so the build environment matches the YAML.
    _regen_build_env(dest)

    # ── Check for non-relocatable absolute ip_paths (RTL-P2.272) ──
    _warn_absolute_ip_paths(dest)

    # ── Hint git init when restored into a non-git directory (RTL-P3.182) ──
    _hint_git_init(dest, project_name=project_name)

    console.print(f"   [dim]Rebuild: cd {dest} && rr synth run && rr bitstream[/]")


def _regen_build_env(dest: Path) -> None:
    """Regenerate build_env.mk / build_env.tcl inside *dest* from project.yml.

    After ``rr project restore``, the archived build_env files may be stale
    (e.g. referencing renamed constraints).  Sequential tar extraction also
    gives project.yml an *earlier* mtime than build_env.mk, preventing the
    normal timestamp-based regeneration.  This helper forces a fresh build.
    """
    yml = dest / "project.yml"
    if not yml.exists():
        return

    regen_ok = False
    with cli_resilient_block("build_env regeneration after restore"):
        from sdk.cli.engine_dispatch import run_engine_script

        prev_cwd = os.getcwd()
        os.chdir(dest)
        try:
            run_engine_script("project_manager.py", ["project.yml"])
            console.print("   [dim]Regenerated build_env.mk from project.yml[/]")
            regen_ok = True
        finally:
            os.chdir(prev_cwd)

    if not regen_ok:
        # Fallback: touch project.yml so the next rr command triggers regen
        with cli_resilient_block("project.yml touch fallback"):
            yml.touch()
            console.print(
                "   [dim]Touched project.yml — build_env will regenerate "
                "on next build[/]"
            )


def _warn_absolute_ip_paths(dest: Path) -> None:
    """Warn if the restored project.yml contains absolute ip_paths entries."""
    import yaml

    yml = dest / "project.yml"
    if not yml.exists():
        return

    with open(yml) as f:
        root = yaml.safe_load(f) or {}

    # Resolve through target indirection
    target = root.get("target", "")
    if target:
        target_path = dest / target
        if target_path.exists():
            with open(target_path) as f:
                config = yaml.safe_load(f) or {}
        else:
            config = root
    else:
        config = root

    ip_paths = config.get("sources", {}).get("ip_paths", [])
    if not ip_paths:
        return

    abs_paths = [p for p in ip_paths if Path(p).is_absolute()]
    if not abs_paths:
        return

    console.print(
        f"\n⚠️  [yellow]{len(abs_paths)} non-relocatable absolute ip_paths "
        f"found in project config:[/]"
    )
    for p in abs_paths:
        exists = Path(p).exists()
        status = "[green]exists[/]" if exists else "[red]missing[/]"
        console.print(f"    [yellow]{p}[/]  ({status})")
    console.print(
        "   [dim]Tip: make these paths relative, or copy the IP repos "
        "into the project directory.[/]"
    )


def _hint_git_init(dest: Path, *, project_name: str | None = None) -> None:
    """Hint `git init` when *dest* isn't already a git repo (RTL-P3.182).

    Prints a tail-line suggestion matching the style of the other tail hints
    in ``rr project restore`` / ``rr init``.  Stays silent when *dest* is
    already under version control (``.git`` can be a dir for normal clones
    or a file for worktrees/submodules).
    """
    git_marker = dest / ".git"
    if git_marker.exists() or git_marker.is_file():
        return

    label = project_name or dest.resolve().name or "project"
    console.print(
        f'   [dim]Version: (not a git repo) git init && git add . && '
        f'git commit -m "Restore {label}"[/]'
    )


def _validate_project_publishable(root_dir: Path | None = None) -> dict:
    """Validate project is publishable, return resolved config.

    Checks that project.yml exists, target resolves, required fields
    are present, and all declared source files exist on disk.
    Returns the resolved project config dict.

    Parameters
    ----------
    root_dir : Path or None
        Project root directory.  Defaults to CWD.
    """
    import yaml

    root_dir = Path(root_dir) if root_dir else Path(".")
    yml = root_dir / "project.yml"
    if not yml.exists():
        console.print(f"  [red]No project.yml found in {root_dir.resolve()}[/]")
        sys.exit(1)

    # Load and chase target pointer (same as project_config.load_project_config)
    with open(yml) as f:
        root = yaml.safe_load(f) or {}

    target_path = root.get("target")
    if target_path:
        tp = root_dir / target_path
        if not tp.exists():
            console.print(f"  [red]Target file not found:[/] {tp}")
            console.print("  [dim]Referenced by: project.yml[/]")
            sys.exit(1)
        with open(tp) as f:
            config = yaml.safe_load(f) or {}
        config["_target_file"] = str(target_path)
    else:
        config = root

    # Required fields
    project = config.get("project", {})
    hardware = config.get("hardware", {})
    name = project.get("name", "")
    part = hardware.get("part", "")

    errors = []
    if not name:
        errors.append("project.name is missing")
    if not part:
        errors.append("hardware.part is missing")
    if not hardware.get("vendor"):
        errors.append("hardware.vendor is missing")

    if errors:
        for e in errors:
            console.print(f"  [red]{e}[/]")
        sys.exit(1)

    # Verify source files exist
    sources = config.get("sources", {})
    all_files = []
    for key in ("syn", "sim", "xdc"):
        all_files.extend(sources.get(key, []))

    missing = [f for f in all_files if not (root_dir / f).exists()]
    if missing:
        console.print(f"  [red]{len(missing)} declared source file(s) not found:[/]")
        for f in missing[:10]:
            console.print(f"    [red]{f}[/]")
        if len(missing) > 10:
            console.print(f"    [dim]... and {len(missing) - 10} more[/]")
        sys.exit(1)

    return config


@project_group.command(name="publish")
@click.option("--url", default=None, help="Git remote URL to publish to (git backend).")
@click.option("--namespace", "-n", default=None, help="Registry namespace to publish to (registry backend).")
@click.option("--version", "-v", "pkg_version", default=None, help="Version string (required for registry backend).")
@click.option("--branch", "-b", default="main", show_default=True, help="Branch name to push (git backend only).")
@click.option("--message", "-m", default=None, help="Commit message (git backend only).")
@click.option("--dry-run", is_flag=True, default=False, help="Validate and show summary without publishing.")
def project_publish(url, namespace, pkg_version, branch, message, dry_run):
    """Publish a project to a git repository or the RouteRTL registry.

    Two mutually exclusive backends:
      --url <git-url>        Push to a git remote (commit + push)
      --namespace <name>     Publish to the RouteRTL registry (requires login)

    \b
    Examples:
        rr project publish --url git@bitbucket.org:org/design.git
        rr project publish --url https://github.com/org/design.git -b main
        rr project publish -n djmazure -v 1.0.0
        rr project publish --url <url> --dry-run
    """
    if url and namespace:
        console.print("  [red]Cannot use both --url and --namespace. Pick one backend.[/]")
        sys.exit(1)
    if not url and not namespace:
        console.print("  [red]Specify --url (git) or --namespace (registry).[/]")
        sys.exit(1)

    config = _validate_project_publishable()

    project = config.get("project", {})
    hardware = config.get("hardware", {})
    sources = config.get("sources", {})
    build_opts = config.get("build_options", {})
    hooks = config.get("tcl_hooks", {})

    name = project.get("name", "unknown")
    top = project.get("top_module", "")
    part = hardware.get("part", "")
    vendor = hardware.get("vendor", "")
    language = hardware.get("language", "")
    tool_ver = build_opts.get("tool_version", "")

    syn_files = sources.get("syn", [])
    sim_files = sources.get("sim", [])
    xdc_files = sources.get("xdc", [])
    hook_files = []
    for hook_list in hooks.values():
        if isinstance(hook_list, list):
            hook_files.extend(hook_list)

    # Warn about absolute ip_paths
    ip_paths = sources.get("ip_paths", [])
    abs_paths = [p for p in ip_paths if Path(p).is_absolute()]

    # ── Summary ──
    target_file = config.get("_target_file", "project.yml")
    backend = "registry" if namespace else "git"
    console.print(f"\n[bold cyan]Project Publish: {name}[/]")
    console.print(f"  [dim]Target config:[/]  {target_file}")
    console.print(f"  [dim]Part:[/]           {part}")
    console.print(f"  [dim]Vendor:[/]         {vendor}")
    if top:
        console.print(f"  [dim]Top module:[/]    {top}")
    if language:
        console.print(f"  [dim]Language:[/]      {language}")
    if tool_ver:
        console.print(f"  [dim]Tool version:[/] {tool_ver}")
    console.print()
    console.print(f"  Sources:     [cyan]{len(syn_files)}[/] syn, [cyan]{len(sim_files)}[/] sim, [cyan]{len(xdc_files)}[/] xdc")
    if hook_files:
        console.print(f"  TCL hooks:   [cyan]{len(hook_files)}[/]")

    if namespace:
        console.print("  Backend:     [cyan]registry[/]")
        console.print(f"  Namespace:   [cyan]{namespace}[/]")
        if pkg_version:
            console.print(f"  Version:     [cyan]{pkg_version}[/]")
    else:
        console.print(f"  Remote:      [cyan]{url}[/]")
        console.print(f"  Branch:      [cyan]{branch}[/]")

    if abs_paths:
        console.print(f"\n  [yellow]Warning: {len(abs_paths)} non-relocatable absolute ip_paths:[/]")
        for p in abs_paths:
            console.print(f"    [yellow]{p}[/]")
        console.print("  [dim]Consider making these relative before publishing.[/]")

    if dry_run:
        console.print("\n[dim]Dry run — no changes made.[/]")
        return

    if namespace:
        _publish_to_registry(namespace, pkg_version, config)
    else:
        _publish_to_git(url, branch, message, name, part)


def _publish_to_registry(namespace, pkg_version, config):
    """Publish project metadata to the RouteRTL registry."""
    import json as _json
    from urllib.error import HTTPError, URLError
    from urllib.request import Request, urlopen

    from sdk.engine.registry_auth import get_auth_token, get_registry_url

    token = get_auth_token()
    if not token:
        console.print("  [red]Not logged in.[/] Run: [cyan]rr pkg login[/]")
        sys.exit(1)

    project = config.get("project", {})
    hardware = config.get("hardware", {})
    sources = config.get("sources", {})
    build_opts = config.get("build_options", {})

    name = project.get("name", "unknown")
    part = hardware.get("part", "")
    vendor = hardware.get("vendor", "")
    top = project.get("top_module", "")
    tool_ver = build_opts.get("tool_version", "")

    # Version: explicit flag, or derive from git tag, or require it
    version = pkg_version
    if not version:
        try:
            version = subprocess.check_output(
                ["git", "describe", "--tags", "--exact-match"],
                text=True, stderr=subprocess.DEVNULL,
            ).strip().lstrip("v")
        except (subprocess.CalledProcessError, FileNotFoundError):
            pass
    if not version:
        console.print("  [red]Version required for registry publish.[/]")
        console.print("  [dim]Use --version 1.0.0 or tag the commit (git tag v1.0.0)[/]")
        sys.exit(1)

    # Collect source files
    all_files = []
    for key in ("syn", "sim", "xdc"):
        all_files.extend(sources.get(key, []))

    # Read target YAML content
    target_file = config.get("_target_file")
    project_yml_content = ""
    if target_file and Path(target_file).exists():
        project_yml_content = Path(target_file).read_text()
    elif Path("project.yml").exists():
        project_yml_content = Path("project.yml").read_text()

    # Git metadata (best-effort)
    commit_sha = None
    try:
        commit_sha = subprocess.check_output(
            ["git", "rev-parse", "HEAD"], text=True, stderr=subprocess.DEVNULL,
        ).strip()
    except (subprocess.CalledProcessError, FileNotFoundError):
        pass

    git_url = None
    for remote_name in ("origin", "publish"):
        try:
            git_url = subprocess.check_output(
                ["git", "remote", "get-url", remote_name], text=True, stderr=subprocess.DEVNULL,
            ).strip()
            if git_url:
                break
        except (subprocess.CalledProcessError, FileNotFoundError):
            pass

    console.print(f"\n  Publishing [cyan]{namespace}/{name}[/] v{version} to registry...")

    registry = get_registry_url()
    api_url = f"{registry}/v1/{namespace}/{name}"
    payload = _json.dumps({
        "version": version,
        "commit_sha": commit_sha,
        "git_url": git_url,
        "library": "work",
        "files": all_files,
        "project_yml": project_yml_content,
        "type": "project",
        "role": "top",
        "tags": [vendor, part.split("-")[0] if part else ""],
        "part": part,
        "vendor": vendor,
        "top_module": top,
        "tool_version": tool_ver,
        "library_deps": [],
        "module_deps": [],
        "modules_provided": [],
    }).encode()
    req = Request(api_url, data=payload, headers={
        "Content-Type": "application/json",
        "Authorization": f"Bearer {token}",
    })

    try:
        with urlopen(req, timeout=30) as resp:
            _json.loads(resp.read().decode())
    except HTTPError as exc:
        detail = "unknown error"
        try:
            detail = _json.loads(exc.read().decode()).get("detail", str(exc))
        except (ValueError, UnicodeDecodeError, AttributeError, KeyError):
            detail = str(exc)
        console.print("  Uploading to registry...      [red]FAILED[/]")
        console.print(f"  [red]{detail}[/]")
        sys.exit(1)
    except URLError as exc:
        console.print("  Uploading to registry...      [red]FAILED[/]")
        console.print(f"  [red]Connection error: {exc}[/]")
        sys.exit(1)

    console.print("  Uploading to registry...      [green]ok[/]")
    console.print(f"\n[green]Published:[/] [cyan]{namespace}/{name}[/] v{version}")
    console.print(f"[dim]Browse:    {registry}/v1/{namespace}/{name}[/]")


def _publish_to_git(url, branch, message, name, part):
    """Publish project to a git remote."""
    # Check if we're already in a git repo
    is_git = Path(".git").exists()

    if not is_git:
        rc = subprocess.run(
            ["git", "init", "--initial-branch", branch],
            capture_output=True, text=True,
        ).returncode
        if rc != 0:
            console.print("  [red]git init failed.[/]")
            sys.exit(1)
        console.print("  git init                      [green]ok[/]")

    # Ensure .gitignore excludes build artifacts
    gitignore = Path(".gitignore")
    if not gitignore.exists():
        gitignore.write_text(
            "# Build artifacts\n"
            "build/\ndcp/\n.Xil/\n.tmpCRC/\nproject/\n"
            "db/\nincremental_db/\noutput_files/\n"
            "*.jou\n*.log\n*.str\n"
            "bitstream/\nreports/\n"
            ".routertl_cache/\n.routertl/\n"
            ".deps.ok\n"
        )
        console.print("  Generated .gitignore          [green]ok[/]")

    # Stage all tracked project files
    rc = subprocess.run(
        ["git", "add", "-A"],
        capture_output=True, text=True,
    ).returncode
    if rc != 0:
        console.print("  [red]git add failed.[/]")
        sys.exit(1)
    console.print("  git add                       [green]ok[/]")

    # Check if there's anything to commit
    status = subprocess.run(
        ["git", "status", "--porcelain"],
        capture_output=True, text=True,
    )
    if not status.stdout.strip():
        console.print("  [dim]Nothing new to commit — working tree clean.[/]")
    else:
        commit_msg = message or f"rr project publish: {name} ({part})"
        rc = subprocess.run(
            ["git", "commit", "-m", commit_msg],
            capture_output=True, text=True,
        ).returncode
        if rc != 0:
            console.print("  [red]git commit failed.[/]")
            sys.exit(1)
        console.print("  git commit                    [green]ok[/]")

    # Add remote and push
    existing = subprocess.run(
        ["git", "remote", "get-url", "publish"],
        capture_output=True, text=True,
    )
    if existing.returncode == 0:
        subprocess.run(
            ["git", "remote", "set-url", "publish", url],
            capture_output=True, text=True,
        )
    else:
        subprocess.run(
            ["git", "remote", "add", "publish", url],
            capture_output=True, text=True,
        )

    result = subprocess.run(
        ["git", "push", "-u", "publish", branch],
        capture_output=True, text=True,
    )
    if result.returncode != 0:
        console.print("  git push                      [red]FAILED[/]")
        stderr = result.stderr.strip()
        if stderr:
            for line in stderr.splitlines()[:5]:
                console.print(f"    [red]{line}[/]")
        sys.exit(1)
    console.print("  git push                      [green]ok[/]")

    console.print(f"\n[green]Published:[/] [cyan]{name}[/] -> {url}")
    console.print(f"[dim]Clone:     rr project clone {url}[/]")


def _resolve_registry_project(ref: str, registry_url: str | None, version: str | None) -> str:
    """Resolve a registry reference (namespace/name) to a git URL.

    Queries the registry API for the project's git_url. If a version
    is specified, fetches that version; otherwise uses the latest.
    """
    import json as _json
    from urllib.error import HTTPError, URLError
    from urllib.request import Request, urlopen

    from sdk.engine.registry_auth import get_auth_headers, get_registry_url

    registry = registry_url or get_registry_url()
    namespace, name = ref.split("/", 1)

    # Fetch version detail or package detail
    if version:
        api_url = f"{registry}/v1/{namespace}/{name}/{version}"
    else:
        api_url = f"{registry}/v1/{namespace}/{name}"

    headers = {"Accept": "application/json"}
    headers.update(get_auth_headers())
    req = Request(api_url, headers=headers)

    try:
        with urlopen(req, timeout=15) as resp:
            data = _json.loads(resp.read().decode())
    except HTTPError as exc:
        if exc.code == 404:
            console.print(f"  [red]Project not found on registry:[/] {ref}")
        else:
            detail = "unknown error"
            try:
                detail = _json.loads(exc.read().decode()).get("detail", str(exc))
            except (ValueError, UnicodeDecodeError, AttributeError, KeyError):
                detail = str(exc)
            console.print(f"  [red]Registry error:[/] {detail}")
        sys.exit(1)
    except URLError as exc:
        console.print(f"  [red]Cannot reach registry:[/] {exc}")
        sys.exit(1)

    # If we fetched the package detail (no version), get git_url from latest version
    git_url = data.get("git_url")
    if not git_url and not version:
        latest = data.get("latest")
        if latest:
            # Fetch the latest version for git_url
            ver_url = f"{registry}/v1/{namespace}/{name}/{latest}"
            req2 = Request(ver_url, headers=headers)
            try:
                with urlopen(req2, timeout=15) as resp2:
                    ver_data = _json.loads(resp2.read().decode())
                    git_url = ver_data.get("git_url")
            except (HTTPError, URLError):
                pass

    if not git_url:
        console.print(f"  [red]Project [cyan]{ref}[/red][red] has no git_url on the registry.[/]")
        console.print("  [dim]The publisher needs to publish from a git repo with a remote.[/]")
        console.print(f"  [dim]Re-publish with: rr project publish --url <git-url> && rr project publish -n {namespace} -v <version>[/]")
        sys.exit(1)

    console.print(f"  Resolved [cyan]{ref}[/] -> [cyan]{git_url}[/]")
    return git_url


@project_group.command(name="clone")
@click.argument("source")
@click.argument("output_dir", required=False, default=None)
@click.option("--branch", "-b", default=None, help="Branch to clone (default: remote HEAD).")
@click.option("--registry", default=None, help="Registry URL (for private registries).")
@click.option("--version", "-v", "pkg_version", default=None, help="Version to clone (default: latest).")
def project_clone(source, output_dir, branch, registry, pkg_version):
    """Clone a published project from a git URL or the registry.

    SOURCE can be a git URL or a registry reference (namespace/name).

    \b
    Examples:
        rr project clone git@bitbucket.org:org/design.git
        rr project clone https://github.com/org/design.git my_project
        rr project clone djmazure/vdco_opensource
        rr project clone djmazure/vdco_opensource -v 1.0.0
        rr project clone acme/design --registry https://private.company.com
    """
    import re

    url = source

    # ── Detect registry reference (namespace/name) vs git URL ──
    is_registry_ref = (
        "/" in source
        and ":" not in source
        and "//" not in source
        and not source.endswith(".git")
        and source.count("/") == 1
    )

    if is_registry_ref:
        url = _resolve_registry_project(source, registry, pkg_version)

    # Derive output dir from URL if not specified
    if not output_dir:
        if is_registry_ref:
            # namespace/name -> name
            output_dir = source.split("/")[1]
        else:
            # Extract repo name from git URL
            name_match = re.search(r"/([^/]+?)(?:\.git)?$", url)
            if not name_match:
                name_match = re.search(r":([^/]+/)?([^/]+?)(?:\.git)?$", url)
                if name_match:
                    output_dir = name_match.group(2)
            if name_match and not output_dir:
                output_dir = name_match.group(1)
            if not output_dir:
                output_dir = "project"

    dest = Path(output_dir)
    if dest.exists() and any(dest.iterdir()):
        console.print(f"  [red]Directory already exists and is not empty:[/] {dest}")
        sys.exit(1)

    # ── Clone ──
    console.print("\n[bold cyan]Project Clone[/]")
    if is_registry_ref:
        console.print(f"  [dim]Package:[/] {source}")
    console.print(f"  [dim]From:[/]   {url}")
    console.print(f"  [dim]Into:[/]   {dest.resolve()}")
    if branch:
        console.print(f"  [dim]Branch:[/] {branch}")
    console.print()

    cmd = ["git", "clone"]
    if branch:
        cmd.extend(["--branch", branch])
    cmd.extend([url, str(dest)])

    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        console.print("  git clone                     [red]FAILED[/]")
        stderr = result.stderr.strip()
        if stderr:
            for line in stderr.splitlines()[:5]:
                console.print(f"    [red]{line}[/]")
        sys.exit(1)
    console.print("  git clone                     [green]ok[/]")

    # ── Validate ──
    yml = dest / "project.yml"
    if not yml.exists():
        console.print("\n  [yellow]Warning: No project.yml found — this may not be a RouteRTL project.[/]")
        console.print("  [dim]Cloned successfully, but cannot validate project structure.[/]")
        return

    config = _validate_project_publishable(root_dir=dest)
    console.print("  project validation            [green]ok[/]")

    # ── Summary ──
    project = config.get("project", {})
    hardware = config.get("hardware", {})
    sources = config.get("sources", {})
    build_opts = config.get("build_options", {})
    hooks = config.get("tcl_hooks", {})

    proj_name = project.get("name", "unknown")
    part = hardware.get("part", "")
    vendor = hardware.get("vendor", "")
    top = project.get("top_module", "")
    language = hardware.get("language", "")
    tool_ver = build_opts.get("tool_version", "")

    syn_files = sources.get("syn", [])
    sim_files = sources.get("sim", [])
    xdc_files = sources.get("xdc", [])
    hook_count = sum(
        len(v) for v in hooks.values() if isinstance(v, list)
    )

    console.print(f"\n[bold cyan]Project: {proj_name}[/]")
    console.print(f"  [dim]Part:[/]           {part}")
    console.print(f"  [dim]Vendor:[/]         {vendor}")
    if top:
        console.print(f"  [dim]Top module:[/]    {top}")
    if language:
        console.print(f"  [dim]Language:[/]      {language}")
    if tool_ver:
        console.print(f"  [dim]Tool version:[/] {tool_ver}")
    console.print(f"  [dim]Sources:[/]       {len(syn_files)} syn, {len(sim_files)} sim, {len(xdc_files)} xdc")
    if hook_count:
        console.print(f"  [dim]TCL hooks:[/]    {hook_count}")

    # ── Warnings ──
    _warn_absolute_ip_paths(dest)

    # Check for package dependencies
    packages = config.get("packages", {})
    ip_lock = dest / "ip.lock"
    if packages and not ip_lock.exists():
        console.print(
            f"\n  [yellow]This project declares {len(packages)} package "
            f"dependenc{'y' if len(packages) == 1 else 'ies'} but has no ip.lock.[/]"
        )
        console.print(f"  [dim]Run: cd {dest} && rr pkg install[/]")

    # ── Next steps ──
    console.print("\n[green]Ready.[/] Next steps:")
    console.print(f"  [dim]cd {dest}[/]")
    if packages and not ip_lock.exists():
        console.print("  [dim]rr pkg install          # install IP dependencies[/]")
    console.print("  [dim]rr project run          # generate vendor project[/]")
    console.print("  [dim]rr synth run            # synthesize[/]")


# RTL-P4.13: `rr npm-synthesis` removed 2026-04-20.  It was hidden +
# deprecated for several releases, delegated straight to `rr synth run`,
# and is no longer wired.  Callers must use `rr synth run <module>`.


@click.command(name="synth-targets", deprecated=True, hidden=True)
@click.option("--all", "-a", "show_all", is_flag=True, help="Include submodules (not just top-level trees).")
def synth_targets(show_all):
    """List available synthesis targets discovered from the source tree."""
    console.print(
        "⚠️  [yellow]synth-targets is deprecated. "
        "Use '[cyan]rr synth list[yellow]' instead.[/]\n"
    )
    _list_synthesis_targets(show_all=show_all)


def _list_synthesis_targets(show_all=False):
    """Discover and display available synthesis targets from the source tree."""
    import json

    # Resolve SRC_DIR from build_env.mk or default to 'src'
    from sdk.cli.engine_dispatch import read_build_env

    benv = read_build_env()
    src_dir = benv.get("SRC_DIR", "src")

    # Locate dependency resolver
    this_dir = Path(__file__).resolve().parent
    tools_dir = this_dir.parent.parent  # sdk/cli/commands -> sdk
    resolver_path = tools_dir / "engine" / "dependency_resolver.py"

    if not resolver_path.exists():
        console.print("❌ [red]Could not find dependency_resolver.py[/]")
        return

    # Resolve CLI name for command suggestions
    CLI_NAME = "routertl"
    with cli_resilient_block("CLI name resolution"):
        from sdk.cli.main import CLI_NAME

    if show_all:
        # Import resolver directly to get ALL entities (including submodules)

        from sdk.engine.dependency_resolver import DependencyResolver

        resolver = DependencyResolver([Path(src_dir)], verbose=False)
        forest = resolver.resolve_forest()
        top_names = {t["top"] for t in (forest.get("trees") or [])}
        all_names = sorted(resolver.entity_map.keys())

        console.print(f"\n🎯 [cyan]All Synthesizable Modules[/] ({len(all_names)} in '{src_dir}'):\n")
        for name in all_names:
            is_top = name in top_names
            bullet = "[green]•" if is_top else "[dim]◦"
            label = f"[cyan]{name}" if is_top else f"[dim]{name}"
            tag = "" if is_top else "  [dim](submodule)[/]"
            console.print(f"  {bullet}[/] {label}[/]{tag}")

        console.print("\n  [green]•[/] = top-level   [dim]◦ = submodule[/]")
    else:
        # Default: show only top-level trees
        try:
            result = subprocess.run(
                [sys.executable, str(resolver_path), "--src", src_dir, "--forest"],
                capture_output=True,
                text=True,
                timeout=30,
            )
            if result.returncode != 0:
                console.print(f"❌ [red]Dependency resolver failed:[/] {result.stderr.strip()}")
                return

            data = json.loads(result.stdout)
            trees = data.get("trees") or []
        except (OSError, json.JSONDecodeError, subprocess.SubprocessError) as e:
            import logging
            import traceback as _tb

            logging.debug("Target discovery failed:\n%s", _tb.format_exc())
            console.print(f"❌ [red]Error discovering targets:[/] {e}")
            return

        if not trees:
            console.print(f"⚠️  [yellow]No synthesis targets found in '{src_dir}'.[/]")
            return

        console.print(
            f"\n🎯 [cyan]Available Synthesis Targets[/] ({len(trees)} top-level modules in '{src_dir}'):\n"
        )
        for tree in sorted(trees, key=lambda t: t["top"]):
            name = tree["top"]
            dep_count = tree.get("weight") or len(tree.get("files") or [])
            deps_label = f"({dep_count} file{'s' if dep_count != 1 else ''})" if dep_count else ""
            console.print(
                f"  [green]•[/] [cyan]{name:<30}[/] [dim]{deps_label}[/]"
            )

        console.print("\n  [dim]Use --all to include submodules[/]")

    console.print("\n[dim]Usage:[/]")
    console.print(f"  {CLI_NAME} synth run <module>")
    console.print(f"  {CLI_NAME} linting <module>")
    console.print(f"  {CLI_NAME} hierarchy <module>")
    console.print()


@click.group(name="implementation", invoke_without_command=True)
@click.pass_context
def impl_group(ctx):
    """Run Project Mode Implementation (Place & Route).

    When invoked without a subcommand, runs implementation.
    Use subcommands for finer control: run, clean, status.
    """
    if ctx.invoked_subcommand is None:
        ctx.invoke(impl_run)


@impl_group.command(name="run")
def impl_run():
    """Run implementation (default action)."""
    console.print("🔨 [blue]Starting Implementation...[/]")
    try:
        from sdk.cli.vendor_dispatch import VendorDispatch, VendorToolNotFound

        # Pre-implementation hooks (RTL-P2.298)
        with cli_resilient_block("pre-implementation hooks"):
            from sdk.cli.engine_dispatch import run_engine_script

            run_engine_script(
                "run_hooks.py",
                ["--stage", "pre_implementation", "--project", "project.yml", "--root", "."],
            )

        dispatch = VendorDispatch.from_project()
        rc = dispatch.implementation()
        if rc != 0:
            sys.exit(rc)
    except (ImportError, VendorToolNotFound):
        _run_make("implementation")

    # Auto-display the post-implementation report (timing, utilization)
    with cli_resilient_block("implementation report"):
        from sdk.cli.commands.synth import _print_build_report, _try_parse_report

        vendor = ""
        with cli_resilient_block("vendor detection"):
            from sdk.cli.project_config import load_project_config
            yml = Path("project.yml")
            if yml.exists():
                config = load_project_config()
                vendor = config.get("hardware", {}).get("vendor", "")

        report = _try_parse_report(vendor)
        if report:
            _print_build_report(report)


@impl_group.command(name="clean")
def impl_clean():
    """Remove cached implementation artifacts."""
    _clean_build_artifacts("project", "")
    console.print("🗑️  [dim]Implementation artifacts cleaned.[/]")


@impl_group.command(name="status")
def impl_status():
    """Show the last implementation result.

    Displays a unified build report with resource utilization,
    timing closure, and phase breakdown from the latest build.
    Falls back to file scanning if no structured reports exist.
    """
    # Try the structured report first
    with cli_resilient_block("implementation report"):
        from sdk.cli.commands.synth import _print_build_report, _try_parse_report

        vendor = ""
        with cli_resilient_block("vendor detection"):
            from sdk.cli.project_config import load_project_config
            yml = Path("project.yml")
            if yml.exists():
                config = load_project_config()
                vendor = config.get("hardware", {}).get("vendor", "")

        report = _try_parse_report(vendor)
        if report:
            _print_build_report(report)
            return

    # Fallback: scan for implementation output files
    import os

    found = False
    for ext in ["*.fit.summary", "*.map.summary", "*.sta.summary",
                "*.route_design.pb", "*_routed.dcp"]:
        from glob import glob
        matches = glob(f"**/{ext}", recursive=True)
        for m in matches:
            found = True
            size = os.path.getsize(m)
            mtime = os.path.getmtime(m)
            from datetime import datetime
            ts = datetime.fromtimestamp(mtime).strftime("%Y-%m-%d %H:%M:%S")
            console.print(
                f"  ✅ [cyan]{m}[/]  "
                f"[dim]{size / 1024:.0f} KB · {ts}[/]"
            )
    if not found:
        console.print(
            "\n  [dim]No implementation reports found.[/]\n"
            "  Run [cyan]rr impl run[/] to generate a build report.\n"
        )
    else:
        console.print("  [dim]Check project/ directory for full reports.[/]")


@impl_group.command(name="report")
@click.option("--json", "as_json", is_flag=True, help="Machine-readable JSON output.")
def impl_report(as_json):
    """Display the latest implementation build report.

    Parses vendor-specific implementation reports (utilization,
    timing, place & route results) and displays a unified summary.

    This is where the real resource utilization and timing closure
    data lives — after Place & Route, not just synthesis.
    """
    import json as _json

    from sdk.cli.commands.synth import _print_build_report, _try_parse_report

    vendor = ""
    part = ""
    with cli_resilient_block("vendor detection"):
        from sdk.cli.project_config import load_project_config
        yml = Path("project.yml")
        if yml.exists():
            config = load_project_config()
            vendor = config.get("hardware", {}).get("vendor", "")
            part = config.get("hardware", {}).get("part", "")

    report = _try_parse_report(vendor)

    if report is None:
        console.print(
            "\n  [dim]No implementation reports found.[/]\n"
            "  Run [cyan]rr impl run[/] to generate a build report.\n"
        )
        return

    if not report.part and part:
        report.part = part

    if as_json:
        click.echo(_json.dumps(report.to_dict(), indent=2))
        return

    _print_build_report(report)


@click.command(name="schematic")
@click.argument("top", required=True)
@click.option(
    "--skin", "-s", default=None,
    help="Beautifier CSS skin (e.g. cyberpunk, classic). Default: cyberpunk.",
)
def schematic(top, skin):
    """Generate an SVG schematic from RTL for a specific TOP module."""
    import shutil as _shutil

    top = _clean_top(top)
    console.print(f"🖼️ [blue]Generating schematic for [cyan]{top}[/]...")

    # ── Docker auto-dispatch: fall back to sim container when Yosys is
    #    not installed on the host.  The bind-mount means the generated
    #    SVG appears on the host filesystem immediately — no copy-back.
    if not _shutil.which("yosys"):
        console.print(
            "⚠️  [yellow]Yosys not found on host — "
            "falling back to Docker sim container...[/]"
        )
        docker_cmd = f"rr schematic {top}"
        if skin:
            docker_cmd += f" --skin {skin}"
        try:
            from sdk.cli.commands.docker import _run_docker_sh

            _run_docker_sh("run", "sim", docker_cmd)
            return
        except (ImportError, OSError):
            console.print(
                "\n❌ [red]Docker fallback failed.[/]\n"
                "   Yosys is required for schematic generation.\n"
                "   Install Yosys locally, or run manually:\n"
                f"     [cyan]rr docker shell[/]\n"
                f"     [cyan]rr schematic {top}[/]"
            )
            sys.exit(1)

    # Resolve source directories from build_env.mk or fall back to 'src'
    from sdk.cli.engine_dispatch import read_build_env

    benv = read_build_env()
    src_dir_str = benv.get("SRC_DIR", "src")
    src_dirs = src_dir_str.split()

    # Locate gen_schematic.py relative to this CLI file
    this_dir = Path(__file__).resolve().parent
    tools_dir = this_dir.parent.parent  # sdk/cli/commands -> sdk
    script = tools_dir / "engine" / "gen_schematic.py"

    if not script.exists():
        console.print(f"❌ [red]Could not find gen_schematic.py at {script}[/]")
        sys.exit(1)

    cmd = [sys.executable, str(script), "--top", top, "--out", "sim/schematics", "--src"] + src_dirs
    if skin:
        cmd.extend(["--skin", skin])

    try:
        result = subprocess.run(cmd, check=False)
        if result.returncode != 0:
            console.print("\n❌ [red]Schematic generation failed.[/]")
            sys.exit(result.returncode)
    except FileNotFoundError:
        console.print("❌ [red]Error:[/] 'python3' not found.")
        sys.exit(1)

