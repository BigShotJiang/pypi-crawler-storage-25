# SPDX-FileCopyrightText: 2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
Lockfile Management — ``rr lock``.

Resolves the full project state and writes ``routertl.lock`` for reproducible
builds and simulations.  Provides ``--check`` mode for CI/CD pipelines.

Design decision: D.10 (routertl.lock subsumes ip.lock, embeds toolchain).
Backlog: RTL-P2.105.
"""

import sys

import rich_click as click

from sdk.cli.console import console
from sdk.cli.resilience import cli_resilient, cli_resilient_block


@cli_resilient("CLI name resolution", default="routertl")
def _resolve_cli_name():
    from sdk.cli.main import CLI_NAME
    return CLI_NAME


@click.group(name="lock", invoke_without_command=True)
@click.option("--check", is_flag=True, help="Compare current state vs lockfile; exit non-zero on mismatch.")
@click.option("--update", is_flag=True, help="Re-resolve and overwrite after intentional changes.")
@click.pass_context
def lock_group(ctx, check, update):
    """Manage the project lockfile (routertl.lock).

    Resolves the full project state — sources, toolchain, dependencies, SDK
    version — and freezes it to ``routertl.lock`` for reproducible builds.

    \b
    Usage:
        rr lock            Resolve and write routertl.lock
        rr lock --update   Re-resolve after intentional changes (new source, tool upgrade)
        rr lock --check    Verify current state matches lockfile (CI mode)
        rr lock status     Show lockfile summary
        rr lock clear      Remove the lockfile
    """
    if ctx.invoked_subcommand is not None:
        return

    if check:
        ctx.invoke(lock_check)
    elif update:
        ctx.invoke(lock_update)
    else:
        ctx.invoke(lock_resolve)


# ── rr lock (default: resolve & write) ────────────────────────────


@lock_group.command(name="resolve", hidden=True)
def lock_resolve():
    """Resolve the project state and write routertl.lock."""
    _do_resolve()


def _do_resolve():
    """Shared implementation for lock resolve."""
    from sdk.engine.lockfile import LOCKFILE_NAME, resolve_project_state, write_lockfile

    console.print("\n  [cyan]Resolving project state...[/]")

    with cli_resilient_block("project state resolution"):
        state = resolve_project_state(".")
        lock_path = write_lockfile(state, ".")

        # Summary
        n_sources = len(state.get("sources", []))
        n_constraints = len(state.get("constraints", []))
        n_deps = len(state.get("dependencies", []))
        toolchain = state.get("toolchain", {})
        sdk = state.get("sdk", {})

        console.print(f"\n  [green]Locked[/] → {LOCKFILE_NAME}\n")

        console.print(f"    Sources:      [cyan]{n_sources}[/] files hashed")
        console.print(f"    Constraints:  [cyan]{n_constraints}[/] files hashed")
        console.print(f"    Dependencies: [cyan]{n_deps}[/] packages pinned")
        tc_line = (
            f"    Toolchain:    {toolchain.get('tool', '?')} "
            f"{toolchain.get('version', '?')} "
            f"({toolchain.get('part', '?')})"
        )
        tc_target = toolchain.get("target", "")
        if tc_target:
            tc_line += f" [dim]target: {tc_target}[/]"
        console.print(tc_line)
        console.print(
            f"    SDK:          v{sdk.get('version', '?')} "
            f"({sdk.get('commit', '?')[:8]})"
        )

        sim = state.get("simulation", {})
        console.print(
            f"    Simulator:    {sim.get('simulator', '?')} "
            f"{sim.get('version', '?')}"
        )

        hierarchy = state.get("resolved_hierarchy", {})
        compile_order = hierarchy.get("compile_order", [])
        console.print(
            f"    Compile order: [cyan]{len(compile_order)}[/] files "
            f"(top: {hierarchy.get('top', '?')})"
        )

        console.print(
            "\n  [dim]Commit routertl.lock to version control for reproducible builds.[/]\n"
        )

        return state

    console.print("\n  [red]Failed to resolve project state.[/]\n")
    sys.exit(1)


# ── rr lock --update ──────────────────────────────────────────────


@lock_group.command(name="update")
def lock_update():
    """Re-resolve the project state and overwrite the lockfile.

    Use after intentional changes: adding/removing sources, upgrading
    EDA tools, bumping dependencies, or changing project.yml.

    Shows a summary of what changed compared to the previous lockfile.
    """
    from sdk.engine.lockfile import load_lockfile

    # Load previous state for comparison
    previous = load_lockfile(".")
    had_previous = bool(previous)

    # Re-resolve
    state = _do_resolve()

    # Show what changed
    if had_previous and state:
        _show_update_diff(previous, state)


def _show_update_diff(old: dict, new: dict) -> None:
    """Show a concise summary of what changed during an update."""
    changes = []

    # Toolchain
    old_tc = old.get("toolchain", {})
    new_tc = new.get("toolchain", {})
    if old_tc.get("version") != new_tc.get("version"):
        changes.append(
            f"  Toolchain: {old_tc.get('tool', '?')} "
            f"{old_tc.get('version', '?')} → {new_tc.get('version', '?')}"
        )
    if old_tc.get("target", "") != new_tc.get("target", ""):
        changes.append(
            f"  Target: {old_tc.get('target', '—')} → {new_tc.get('target', '—')}"
        )

    # Simulator
    old_sim = old.get("simulation", {})
    new_sim = new.get("simulation", {})
    if old_sim.get("version") != new_sim.get("version"):
        changes.append(
            f"  Simulator: {old_sim.get('simulator', '?')} "
            f"{old_sim.get('version', '?')} → {new_sim.get('version', '?')}"
        )

    # Sources
    old_srcs = {s["path"] for s in old.get("sources", []) if isinstance(s, dict)}
    new_srcs = {s["path"] for s in new.get("sources", []) if isinstance(s, dict)}
    added = new_srcs - old_srcs
    removed = old_srcs - new_srcs
    # Changed hashes
    old_hashes = {s["path"]: s.get("sha256") for s in old.get("sources", []) if isinstance(s, dict)}
    new_hashes = {s["path"]: s.get("sha256") for s in new.get("sources", []) if isinstance(s, dict)}
    changed = {p for p in old_srcs & new_srcs if old_hashes.get(p) != new_hashes.get(p)}

    if added:
        changes.append(f"  Sources: [green]+{len(added)} added[/]")
    if removed:
        changes.append(f"  Sources: [red]-{len(removed)} removed[/]")
    if changed:
        changes.append(f"  Sources: [yellow]{len(changed)} modified[/]")

    # SDK
    old_sdk = old.get("sdk", {})
    new_sdk = new.get("sdk", {})
    if old_sdk.get("version") != new_sdk.get("version"):
        changes.append(
            f"  SDK: v{old_sdk.get('version', '?')} → v{new_sdk.get('version', '?')}"
        )

    # Dependencies
    old_deps = len(old.get("dependencies", []))
    new_deps = len(new.get("dependencies", []))
    if old_deps != new_deps:
        changes.append(f"  Dependencies: {old_deps} → {new_deps}")

    if changes:
        console.print("  [bold]Changes from previous lock:[/]\n")
        for c in changes:
            console.print(f"    {c}")
        console.print()
    else:
        console.print("  [dim]No changes detected from previous lock.[/]\n")


# ── rr lock --check ───────────────────────────────────────────────


@lock_group.command(name="check")
def lock_check():
    """Verify current state matches the lockfile.

    Exits with code 0 if the lockfile is up to date, or code 1 with a
    human-readable diff if there are mismatches.  Designed for CI pipelines
    and ``--locked`` build/sim flags.
    """
    _do_check()


def _stub_lockfile_problems(state: dict) -> list[str]:
    """RTL-P1.45: detect a stub/incomplete lockfile.

    Returns a list of human-readable problem strings; empty list == OK.

    The pre-P1.45 ``rr lock --check`` treated a lockfile with every
    field set to ``"unknown"`` or ``[]`` as a valid state and returned
    success, turning the reproducibility gate into a placebo.  These
    checks make the gate fail-fast when the lockfile is stubbed out —
    either because ``rr lock --update`` misresolved (RTL-P2.352 /
    P2.355 resolver bugs) or because the file was never updated.
    """
    problems: list[str] = []

    def _is_blank(val) -> bool:
        if val is None or val == "":
            return True
        if isinstance(val, str) and val.strip().lower() == "unknown":
            return True
        return False

    project = state.get("project", {}) if isinstance(state, dict) else {}
    if not isinstance(project, dict) or _is_blank(project.get("name")):
        problems.append("project.name is empty or 'unknown'")
    if not isinstance(project, dict) or _is_blank(project.get("top_module")):
        problems.append("project.top_module is empty or 'unknown'")

    toolchain = state.get("toolchain", {}) if isinstance(state, dict) else {}
    if not isinstance(toolchain, dict):
        toolchain = {}
    for key in ("vendor", "tool", "version", "part"):
        if _is_blank(toolchain.get(key)):
            problems.append(f"toolchain.{key} is empty or 'unknown'")

    sources = state.get("sources", []) if isinstance(state, dict) else []
    if not isinstance(sources, list) or len(sources) == 0:
        problems.append("sources is empty (no files resolved)")

    hierarchy = state.get("resolved_hierarchy", {}) if isinstance(state, dict) else {}
    if not isinstance(hierarchy, dict):
        hierarchy = {}
    hier_top = hierarchy.get("top")
    proj_top = project.get("top_module") if isinstance(project, dict) else None
    if _is_blank(hier_top):
        problems.append("resolved_hierarchy.top is empty or 'unknown'")
    elif not _is_blank(proj_top) and hier_top != proj_top:
        problems.append(
            f"resolved_hierarchy.top ('{hier_top}') does not match "
            f"project.top_module ('{proj_top}')"
        )

    return problems


def _do_check() -> bool:
    """Shared implementation for lock check. Returns True if ok."""
    from sdk.engine.lockfile import LOCKFILE_NAME, check_lockfile, load_lockfile

    console.print(f"\n  [cyan]Checking {LOCKFILE_NAME}...[/]")

    # RTL-P1.45: validate the lockfile is non-stub before comparing to
    # the live state.  A stub lockfile (all "unknown" / empty) would
    # otherwise match itself field-by-field and pass silently.
    state = load_lockfile(".")
    if state is not None:  # load_lockfile returns None/dict when missing
        stub_problems = _stub_lockfile_problems(state)
        if stub_problems:
            cli_name = _resolve_cli_name()
            console.print(
                f"  [red bold]Lockfile is a stub — "
                f"{len(stub_problems)} required field(s) missing/unknown:[/]\n"
            )
            for p in stub_problems:
                console.print(f"    [red]• {p}[/]")
            console.print(
                f"\n  [dim]Run '{cli_name} lock' to regenerate.  If it "
                f"still produces a stub, the target-scoped resolver "
                f"(RTL-P2.352 / RTL-P2.355) likely fired before its "
                f"fix landed.[/]\n"
            )
            sys.exit(1)

    ok, diffs = check_lockfile(".")

    if ok:
        console.print("  [green]Lockfile is up to date.[/]\n")
        return True

    cli_name = _resolve_cli_name()
    console.print(f"  [red]Lockfile mismatch — {len(diffs)} difference(s):[/]\n")

    for diff in diffs:
        if diff.startswith("[added]"):
            console.print(f"    [green]{diff}[/]")
        elif diff.startswith("[removed]"):
            console.print(f"    [red]{diff}[/]")
        elif diff.startswith("[changed]"):
            console.print(f"    [yellow]{diff}[/]")
        else:
            console.print(f"    {diff}")

    console.print(
        f"\n  [dim]Run '{cli_name} lock' to update the lockfile.[/]\n"
    )

    sys.exit(1)


# ── rr lock status ────────────────────────────────────────────────


@lock_group.command(name="status")
def lock_status():
    """Show a summary of the current lockfile."""
    from sdk.engine.lockfile import LOCKFILE_NAME, load_lockfile

    state = load_lockfile(".")
    if not state:
        cli_name = _resolve_cli_name()
        console.print(
            f"\n  [dim]No {LOCKFILE_NAME} found.[/]\n"
            f"  [dim]Run '{cli_name} lock' to create one.[/]\n"
        )
        return

    console.print(f"\n  [bold cyan]Lockfile Summary[/] — {LOCKFILE_NAME}\n")

    project = state.get("project", {})
    console.print(f"    Project:  {project.get('name', '?')} (top: {project.get('top_module', '?')})")

    toolchain = state.get("toolchain", {})
    tc_status = (
        f"    Toolchain: {toolchain.get('tool', '?')} {toolchain.get('version', '?')} "
        f"({toolchain.get('vendor', '?')}, {toolchain.get('part', '?')})"
    )
    tc_target = toolchain.get("target", "")
    if tc_target:
        tc_status += f" [dim]target: {tc_target}[/]"
    console.print(tc_status)

    sim = state.get("simulation", {})
    console.print(f"    Simulator: {sim.get('simulator', '?')} {sim.get('version', '?')}")

    sdk = state.get("sdk", {})
    dirty_str = " [yellow](dirty)[/]" if sdk.get("dirty") else ""
    console.print(
        f"    SDK:       v{sdk.get('version', '?')} "
        f"({sdk.get('commit', '?')[:8]}){dirty_str}"
    )

    sources = state.get("sources", [])
    constraints = state.get("constraints", [])
    deps = state.get("dependencies", [])
    hierarchy = state.get("resolved_hierarchy", {})

    console.print(f"    Sources:   {len(sources)} files")
    console.print(f"    Constraints: {len(constraints)} files")
    console.print(f"    Dependencies: {len(deps)} packages")
    console.print(f"    Compile order: {len(hierarchy.get('compile_order', []))} files")

    locked_at = state.get("locked_at", "unknown")
    console.print(f"\n    [dim]Locked at: {locked_at}[/]")
    console.print(f"    [dim]Version: {state.get('version', '?')}[/]\n")


# ── rr lock clear ─────────────────────────────────────────────────


@lock_group.command(name="clear")
def lock_clear():
    """Remove the lockfile."""
    import os

    from sdk.engine.lockfile import LOCKFILE_NAME

    lock_path = os.path.join(".", LOCKFILE_NAME)
    if os.path.exists(lock_path):
        os.remove(lock_path)
        console.print(f"  [yellow]Removed {LOCKFILE_NAME}[/]")
    else:
        console.print(f"  [dim]No {LOCKFILE_NAME} to remove.[/]")


# ── Shared check for --locked flag ────────────────────────────────


def enforce_locked(command_name: str) -> None:
    """Check lockfile before a --locked build/sim.

    Called by synth and sim commands when --locked is passed.
    Exits with code 1 if the lockfile is stale or missing.
    """
    from sdk.engine.lockfile import LOCKFILE_NAME, check_lockfile

    ok, diffs = check_lockfile(".")

    if ok:
        console.print(f"  [green]Lockfile verified[/] — proceeding with {command_name}")
        return

    cli_name = _resolve_cli_name()
    console.print(
        f"\n  [red]--locked: {LOCKFILE_NAME} mismatch — "
        f"aborting {command_name}.[/]\n"
    )

    for diff in diffs[:5]:
        if diff.startswith("[added]"):
            console.print(f"    [green]{diff}[/]")
        elif diff.startswith("[removed]"):
            console.print(f"    [red]{diff}[/]")
        elif diff.startswith("[changed]"):
            console.print(f"    [yellow]{diff}[/]")
        else:
            console.print(f"    {diff}")

    remaining = len(diffs) - 5
    if remaining > 0:
        console.print(f"    [dim]... and {remaining} more[/]")

    console.print(
        f"\n  [dim]Run '{cli_name} lock' to update, "
        f"or remove --locked to proceed anyway.[/]\n"
    )
    sys.exit(1)
