# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
routertl report — Unified Project Report.

Aggregates lint, simulation, and synthesis results into a single
markdown or Rich-formatted console report.
"""

import json
import os
from datetime import datetime
from pathlib import Path

import rich_click as click
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from sdk.cli.console import console


def _find_project_root():
    """Walk up from CWD looking for project.yml."""
    from sdk.cli.project_root import find_project_root

    return find_project_root() or Path.cwd()


def _collect_sim_results(results_dir):
    """Scan per-module latest.json files under the results directory."""
    modules = []
    if not results_dir.is_dir():
        return modules

    for child in sorted(results_dir.iterdir()):
        latest = child / "latest.json"
        if child.is_dir() and latest.exists():
            try:
                with open(latest) as f:
                    data = json.load(f)
                modules.append(data)
            except (json.JSONDecodeError, OSError):
                continue
    return modules


def _read_lint_status(project_root):
    """Read the lint log status. Returns (status_str, details)."""
    lint_log = project_root / "sim" / "lint.log"
    if not lint_log.exists():
        return "not_run", ""

    try:
        content = lint_log.read_text()
        if "PASS" in content:
            return "pass", content
        elif "FAIL" in content:
            return "fail", content
        else:
            return "unknown", content
    except OSError:
        return "error", ""


def _read_synthesis_status(project_root):
    """Read synthesis log status. Returns (status_str, details)."""
    # Check multiple possible locations
    candidates = [
        project_root / "logs" / "regression_summary.txt",
        project_root / "project" / "synthesis.log",
    ]
    for path in candidates:
        if path.exists():
            try:
                content = path.read_text()
                return "found", content
            except OSError:
                continue
    return "not_run", ""


def _status_emoji(status):
    """Map status strings to emoji indicators."""
    return {
        "pass": "✅",
        "fail": "❌",
        "error": "⚠️",
        "not_run": "⏭️",
        "found": "📄",
        "unknown": "❓",
    }.get(status, "❓")


def _generate_markdown_report(sim_results, lint_status, lint_detail, synth_status, synth_detail, regressions):
    """Generate a markdown-formatted report string."""
    lines = []
    lines.append("# RouteRTL Project Report")
    lines.append("")
    lines.append(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    lines.append("")

    # Lint Section
    lines.append("## Lint Results")
    lines.append("")
    lines.append(f"**Status**: {_status_emoji(lint_status)} {lint_status.upper()}")
    lines.append("")

    # Simulation Section
    lines.append("## Simulation Results")
    lines.append("")
    if sim_results:
        lines.append("| Module | Passed | Failed | Errors | Duration | Status |")
        lines.append("|--------|--------|--------|--------|----------|--------|")
        for mod in sim_results:
            p = mod.get("passed", 0)
            f = mod.get("failed", 0)
            e = mod.get("errors", 0)
            d = mod.get("duration_s", 0)
            status = "✅ PASS" if f == 0 and e == 0 else "❌ FAIL"
            lines.append(f"| {mod.get('module', '?')} | {p} | {f} | {e} | {d:.2f}s | {status} |")
        lines.append("")
    else:
        lines.append("_No simulation results found._")
        lines.append("")

    # Regression Detection Section
    if regressions:
        lines.append("## Performance Regressions")
        lines.append("")
        for reg in regressions:
            if reg.get("regressed"):
                lines.append(
                    f"- ⚠️ **{reg['module']}**: {reg['latest_s']:.2f}s "
                    f"(avg {reg['avg_s']:.2f}s, +{reg['pct_over']:.1f}%)"
                )
                for t in reg.get("regressed_tests", []):
                    lines.append(
                        f"  - `{t['name']}`: {t['latest_s']:.4f}s (avg {t['avg_s']:.4f}s, +{t['pct_over']:.1f}%)"
                    )
        lines.append("")

    # Synthesis Section
    lines.append("## Synthesis Results")
    lines.append("")
    lines.append(f"**Status**: {_status_emoji(synth_status)} {synth_status.upper()}")
    lines.append("")

    return "\n".join(lines)


def _render_rich_report(console, sim_results, lint_status, lint_detail, synth_status, synth_detail, regressions):
    """Render the report using Rich formatting."""
    # Header
    header = Text()
    header.append("📊 RouteRTL ", style="bold cyan")
    header.append("— Project Report", style="dim")
    console.print(Panel(header, border_style="cyan", padding=(0, 1)))
    console.print()

    # Lint
    console.print(f"  [bold]Lint:[/bold]  {_status_emoji(lint_status)}  {lint_status.upper()}")

    # Simulation
    if sim_results:
        console.print()
        table = Table(
            title="Simulation Results",
            title_style="bold cyan",
            show_lines=False,
            padding=(0, 1),
        )
        table.add_column("Module", style="bold")
        table.add_column("Passed", style="green", justify="right")
        table.add_column("Failed", style="red", justify="right")
        table.add_column("Errors", style="yellow", justify="right")
        table.add_column("Duration", justify="right")
        table.add_column("Status")

        total_p = total_f = total_e = 0
        total_d = 0.0
        for mod in sim_results:
            p = mod.get("passed", 0)
            f = mod.get("failed", 0)
            e = mod.get("errors", 0)
            d = mod.get("duration_s", 0)
            total_p += p
            total_f += f
            total_e += e
            total_d += d
            status = "[green]PASS[/green]" if f == 0 and e == 0 else "[red]FAIL[/red]"
            table.add_row(mod.get("module", "?"), str(p), str(f), str(e), f"{d:.2f}s", status)

        # Summary row
        overall = "[green]ALL PASS[/green]" if total_f == 0 and total_e == 0 else "[red]FAILURES[/red]"
        table.add_row(
            "[bold]Total[/bold]",
            f"[bold]{total_p}[/bold]",
            f"[bold]{total_f}[/bold]",
            f"[bold]{total_e}[/bold]",
            f"[bold]{total_d:.2f}s[/bold]",
            overall,
        )
        console.print(table)
    else:
        console.print("  [dim]No simulation results found.[/dim]")

    # Regression warnings
    has_regression = False
    for reg in regressions:
        if reg.get("regressed"):
            if not has_regression:
                console.print()
                console.print("  [bold yellow]⚠️  Performance Regressions:[/bold yellow]")
                has_regression = True
            console.print(
                f"    [yellow]{reg['module']}[/yellow]: "
                f"{reg['latest_s']:.2f}s "
                f"(avg {reg['avg_s']:.2f}s, +{reg['pct_over']:.1f}%)"
            )
            for t in reg.get("regressed_tests", []):
                console.print(
                    f"      └─ {t['name']}: {t['latest_s']:.4f}s (avg {t['avg_s']:.4f}s, +{t['pct_over']:.1f}%)"
                )

    # Synthesis
    console.print()
    console.print(f"  [bold]Synthesis:[/bold]  {_status_emoji(synth_status)}  {synth_status.upper()}")
    console.print()


@click.command(name="report")
@click.option(
    "--format",
    "fmt",
    type=click.Choice(["rich", "md"]),
    default="rich",
    help="Output format: rich (console) or md (markdown).",
)
@click.option("--output", "-o", type=click.Path(), default=None, help="Write report to file instead of stdout.")
def report_command(fmt, output):
    """
    Generate a unified project report.

    Aggregates lint, simulation, and synthesis results into a single
    overview. Use --format md for CI-friendly markdown output.
    """
    project_root = _find_project_root()

    # Determine results directory
    results_dir_env = os.environ.get("ROUTERTL_RESULTS_DIR")
    if results_dir_env:
        results_dir = Path(results_dir_env)
    else:
        results_dir = project_root / "sim" / "results"

    # Collect data
    sim_results = _collect_sim_results(results_dir)
    lint_status, lint_detail = _read_lint_status(project_root)
    synth_status, synth_detail = _read_synthesis_status(project_root)

    # Regression detection for each module
    regressions = []
    try:
        # Import detect_regression (avoid hard dependency on sim engine paths)
        from routertl_core.sim.result_collector import detect_regression

        for mod in sim_results:
            reg = detect_regression(results_dir, mod.get("module", ""))
            regressions.append(reg)
    except ImportError:
        pass

    if fmt == "md":
        report_text = _generate_markdown_report(
            sim_results,
            lint_status,
            lint_detail,
            synth_status,
            synth_detail,
            regressions,
        )
        if output:
            Path(output).write_text(report_text)
            console.print(f"📄 Report written to {output}")
        else:
            click.echo(report_text)
    else:
        report_console = Console(file=open(output, "w") if output else None)
        _render_rich_report(
            report_console,
            sim_results,
            lint_status,
            lint_detail,
            synth_status,
            synth_detail,
            regressions,
        )
        if output:
            console.print(f"📄 Report written to {output}")
