# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Workspace utility commands — clean, rebrand, xdc-template, pre-build, etc."""

import sys

import rich_click as click

from sdk.cli.commands.workspace import (
    _fix_makefile_include,
    _run_make,
    workspace_group,
)
from sdk.cli.console import console
from sdk.cli.resilience import cli_resilient_block


@workspace_group.command(name="clean")
@click.option("--sim", "clean_sim", is_flag=True, help="Clean only simulation artifacts (logs, cache, build).")
@click.option("--build", "clean_build", is_flag=True, help="Clean only FPGA build outputs.")
@click.option("--cache", "clean_cache", is_flag=True, help="Clean only .routertl_cache/.")
@click.option("--deep", "clean_deep", is_flag=True, help="Deep clean: purge __pycache__, Vivado journals, Cython artifacts, etc.")
def clean(clean_sim, clean_build, clean_cache, clean_deep):
    """Clean build artifacts.

    \b
    Without flags, runs full 'make clean'. With flags, removes only
    the specified artifact categories.

    \b
    --deep removes accumulated working-tree clutter that 'make clean'
    doesn't touch:
      __pycache__/  *.pyc  *.pyo       Python bytecode
      sim/work*/                       NVC/GHDL work directories
      sim_build/                       Cocotb build directory
      .Xil/                            Vivado intermediate files
      vivado*.log  vivado*.jou         Vivado journals at project root
      routertl_core/*.c  *.so          Cython build artifacts
      build/  dist/  *.egg-info/       Python packaging outputs
    """
    import shutil
    from pathlib import Path

    if not any([clean_sim, clean_build, clean_cache, clean_deep]):
        # Full clean via Make
        console.print("🧹 [blue]Cleaning workspace...[/]")
        _run_make("clean")
        return

    removed = []
    total_bytes = 0

    def _rm_dir(d):
        """Remove a directory and track it."""
        nonlocal total_bytes
        if d.exists():
            for f in d.rglob("*"):
                if f.is_file():
                    total_bytes += f.stat().st_size
            shutil.rmtree(d)
            removed.append(str(d))

    def _rm_file(f):
        """Remove a file and track it."""
        nonlocal total_bytes
        if f.exists():
            total_bytes += f.stat().st_size
            f.unlink()
            removed.append(str(f))

    if clean_sim:
        sim_dirs = [
            Path("sim") / "cocotb" / "logs",
            Path("sim") / "cocotb" / "results",
            Path("sim") / "results",
            Path("sim") / "schematics",
            Path("sim") / "build",
        ]
        for d in sim_dirs:
            _rm_dir(d)
        _rm_dir(Path("sim_build"))

    if clean_cache:
        _rm_dir(Path(".routertl_cache"))

    if clean_build:
        for d in [Path("build"), Path("vivado_project")]:
            _rm_dir(d)

    if clean_deep:
        cwd = Path(".")

        # 1. Python bytecode — __pycache__/ directories everywhere
        for d in sorted(cwd.rglob("__pycache__"), reverse=True):
            _rm_dir(d)

        # 2. Stray .pyc / .pyo files
        for ext in ("*.pyc", "*.pyo"):
            for f in cwd.rglob(ext):
                _rm_file(f)

        # 3. NVC / GHDL work directories under sim/
        sim = Path("sim")
        if sim.exists():
            for d in sorted(sim.glob("work*"), reverse=True):
                if d.is_dir():
                    _rm_dir(d)

        # 4. Cocotb build directory
        _rm_dir(Path("sim_build"))

        # 5. Vivado intermediate files
        _rm_dir(Path(".Xil"))
        for f in cwd.glob("vivado*.log"):
            _rm_file(f)
        for f in cwd.glob("vivado*.jou"):
            _rm_file(f)
        for f in cwd.glob("vivado_pid*.str"):
            _rm_file(f)

        # 6. Cython build artifacts in routertl_core/
        core = Path("routertl_core")
        if core.exists():
            for f in core.rglob("*.c"):
                _rm_file(f)
            for f in core.rglob("*.so"):
                _rm_file(f)

        # 7. Python packaging outputs
        _rm_dir(Path("build"))
        _rm_dir(Path("dist"))
        for d in cwd.glob("*.egg-info"):
            _rm_dir(d)

        # 8. .routertl_cache (always include in deep)
        _rm_dir(Path(".routertl_cache"))

    if removed:
        # Format byte count
        if total_bytes < 1024:
            size_str = f"{total_bytes} B"
        elif total_bytes < 1024 * 1024:
            size_str = f"{total_bytes / 1024:.1f} KB"
        else:
            size_str = f"{total_bytes / (1024 * 1024):.1f} MB"
        console.print(f"🧹 [green]Deep clean removed {len(removed)} items ({size_str}):[/]")
        # Show up to 20 items, summarize if more
        display = removed[:20]
        for item in display:
            console.print(f"   [dim]•[/] {item}")
        if len(removed) > 20:
            console.print(f"   [dim]… and {len(removed) - 20} more[/]")
    else:
        console.print("🧹 [dim]Nothing to clean — workspace already tidy.[/]")


@workspace_group.command(name="sources")
def sources():
    """Show current source file lists from project.yml."""
    console.print("📄 [blue]Reading source lists...[/]")
    _run_make("sources")


@workspace_group.command(name="cicd")
def cicd():
    """Update CI/CD pipeline configuration from project.yml."""
    console.print("🔄 [blue]Updating CI/CD configuration...[/]")
    _run_make("update-cicd")


@workspace_group.command(name="pre-build")
def pre_build():
    """Run pre-build code generation hooks from project.yml."""
    console.print("⚙️ [blue]Running pre-build hooks...[/]")
    _run_make("pre-build")


@workspace_group.command(name="reinit")
def reinit():
    """Wipe project artifacts and re-initialize the project."""
    _run_make("reinit-project")


@workspace_group.command(name="xdc-template")
@click.argument("top", required=True)
def xdc_template(top):
    """Generate an XDC constraint template based on RTL source clock domains."""
    if top.startswith("TOP="):
        top = top[4:]
    console.print(f"📐 [blue]Analyzing RTL and generating XDC for [cyan]{top}[/]...")
    _run_make("gen-xdc-template", f"TOP={top}")


@workspace_group.command(name="rebrand")
def rebrand():
    """Re-create CLI aliases (rr + branded name) from project.yml.

    The branded CLI name is read from project.yml — no arguments needed:

        branding:
          cli_name: dskop     # creates 'dskop' → routertl alias

    Creates symlinks next to the routertl binary.  Works in both
    virtualenv and system-wide (Docker) installs — no venv required.
    The 'rr' shortcut is always created. Safe to re-run whenever
    project.yml changes.
    """
    import os
    import shutil
    from pathlib import Path


    # ── Resolve the routertl binary ──
    # Prefer venv if active and contains the binary; otherwise fall back
    # to the system PATH (covers Docker images where the SDK is installed
    # globally in /usr/local/bin).
    venv = os.environ.get("VIRTUAL_ENV")
    if venv and (Path(venv) / "bin" / "routertl").exists():
        bin_dir = Path(venv) / "bin"
    else:
        system_bin = shutil.which("routertl")
        if system_bin:
            bin_dir = Path(system_bin).resolve().parent
        else:
            console.print("❌ [red]No routertl binary found.[/]")
            console.print("   [dim]Activate .venv or install routertl system-wide.[/]")
            sys.exit(1)

    routertl_bin = bin_dir / "routertl"

    created = []

    # 1. Always create/update the 'rr' shortcut
    rr_link = bin_dir / "rr"
    if rr_link.exists() or rr_link.is_symlink():
        rr_link.unlink()
    rr_link.symlink_to(routertl_bin.name)
    created.append("rr")

    # 2. Read branding from project.yml if available
    with cli_resilient_block("branding config read"):
        from sdk.cli.project_config import load_project_config

        config = load_project_config()
        cli_name = config.get("branding", {}).get("cli_name")
        if cli_name and cli_name != "routertl":
            branded_link = bin_dir / cli_name
            if branded_link.exists() or branded_link.is_symlink():
                branded_link.unlink()
            branded_link.symlink_to(routertl_bin.name)
            created.append(cli_name)

    aliases = ", ".join(f"[cyan]{a}[/]" for a in created)
    console.print(f"✅ [green]Aliases created:[/] {aliases} → routertl")

    # ── Fix Makefile include path if stale ──
    from sdk.cli.sdk_root import resolve_sdk_root

    sdk_found = resolve_sdk_root()
    if sdk_found:
        _fix_makefile_include(sdk_found)


@workspace_group.command(name="update-viewer")
def update_viewer():
    """Download or update the RouteWave waveform viewer.

    Downloads the latest RouteWave binary from GitHub Releases
    and caches it in ~/.routertl/bin/routewave/.  Subsequent
    calls to ``rr waves`` or ``rr sim --view`` use this cached
    binary automatically.

    Re-run this command to upgrade to a newer release.
    """
    from sdk.cli.viewer_manager import get_cached_version, get_viewer_path

    current = get_cached_version()
    if current:
        console.print(f"📦 [blue]Current RouteWave version:[/] [cyan]{current}[/]")
        console.print("🔄 [blue]Checking for updates...[/]")
    else:
        console.print("📦 [blue]RouteWave not installed. Downloading...[/]")

    path = get_viewer_path(force_download=True)
    if path and path.exists():
        new_version = get_cached_version() or "unknown"
        console.print(f"✅ [green]RouteWave {new_version} installed at:[/] [cyan]{path}[/]")
    else:
        console.print(
            "❌ [red]Failed to download RouteWave.[/]\n"
            "   Check your network connection and GitHub access.\n"
            "   Set GITHUB_TOKEN if hitting rate limits."
        )
        sys.exit(1)
