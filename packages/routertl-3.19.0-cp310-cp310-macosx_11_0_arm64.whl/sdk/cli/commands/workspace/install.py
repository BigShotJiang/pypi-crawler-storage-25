# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Workspace install and environment check commands."""

import subprocess
import sys
from pathlib import Path

from sdk.cli.commands.workspace import (
    _inject_venv_completion,
    _inject_venv_environment,
    workspace_group,
)
from sdk.cli.console import console
from sdk.cli.resilience import cli_resilient_block


@workspace_group.command(name="install-hooks")
def install_hooks():
    """Install pre-commit hooks into the project directory.

    Copies SDK hook scripts into ``.routertl/hooks/`` and configures
    ``core.hooksPath`` to point there.  This ensures hooks survive
    regardless of whether the SDK is consumed as a submodule or via pip.
    """
    import shutil
    import stat

    console.print("🪝 [blue]Installing Git hooks...[/]")

    from sdk.cli.sdk_root import resolve_sdk_root

    sdk_root = resolve_sdk_root()
    if sdk_root is None:
        console.print("❌ [red]SDK root not found.[/]")
        sys.exit(1)

    src_hooks = sdk_root / "sdk" / "infra" / "hooks"
    if not src_hooks.is_dir():
        console.print(
            f"❌ [red]SDK hooks directory not found at {src_hooks}[/]"
        )
        sys.exit(1)

    # Copy hooks into project-local .routertl/hooks/
    dst_hooks = Path.cwd() / ".routertl" / "hooks"
    dst_hooks.mkdir(parents=True, exist_ok=True)

    copied = 0
    for hook_file in src_hooks.iterdir():
        if hook_file.is_file():
            dst = dst_hooks / hook_file.name
            shutil.copy2(hook_file, dst)
            # Ensure the hook is executable
            dst.chmod(dst.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
            copied += 1

    if copied == 0:
        console.print("❌ [red]No hook scripts found in SDK.[/]")
        sys.exit(1)

    # Configure git to use the project-local hooks
    result = subprocess.run(
        ["git", "config", "core.hooksPath", str(dst_hooks)],
        check=False,
    )
    if result.returncode != 0:
        console.print("❌ [red]Failed to configure git hooks.[/]")
        sys.exit(1)

    # Ensure .routertl/ is in .gitignore (sentinel-based, idempotent)
    _SENTINEL_START = "# >>> routertl hooks >>>"
    _SENTINEL_END = "# <<< routertl hooks <<<"
    gitignore = Path.cwd() / ".gitignore"
    gitignore_content = gitignore.read_text() if gitignore.exists() else ""
    if _SENTINEL_START not in gitignore_content:
        block = f"\n{_SENTINEL_START}\n.routertl/\n{_SENTINEL_END}\n"
        with open(gitignore, "a") as f:
            f.write(block)

    console.print(
        f"✅ Git hooks installed → {dst_hooks} "
        f"({copied} script{'s' if copied != 1 else ''})"
    )


@workspace_group.command(name="install")
def install():
    """Create venv (if needed) and install Python dependencies from requirements.txt."""
    import shutil

    console.print("📦 [blue]Installing project dependencies...[/]")

    root_dir = Path.cwd()
    venv_dir = root_dir / ".venv"

    # Create venv if needed
    if not venv_dir.exists():
        console.print("⚠️  No .venv found. Creating one...")
        subprocess.run(
            [sys.executable, "-m", "venv", str(venv_dir)],
            check=True,
        )

    # Install requirements
    venv_pip = venv_dir / "bin" / "python3"
    req_file = root_dir / "requirements.txt"
    if req_file.exists():
        console.print("📦 Installing dependencies from requirements.txt...")
        subprocess.run(
            [str(venv_pip), "-m", "pip", "install", "-r", str(req_file)],
            check=False,
        )

    # Install SDK in editable mode
    from sdk.cli.sdk_root import resolve_sdk_root

    sdk_root = resolve_sdk_root()
    if sdk_root:
        console.print("📦 Installing RouteRTL SDK (CLI tools)...")
        subprocess.run(
            [str(venv_pip), "-m", "pip", "install", "-e", str(sdk_root), "-q"],
            check=False,
        )
        console.print("✅ Dependencies installed. 'rr' CLI is now available.")
        console.print(
            "👉 To activate the environment, run: "
            "[cyan]source .venv/bin/activate[/]"
        )

    # Pull LFS objects if the repo uses Git LFS
    if Path(".gitattributes").exists() and shutil.which("git"):
        with cli_resilient_block("git lfs pull"):
            result = subprocess.run(
                ["git", "lfs", "pull"],
                capture_output=True,
                text=True,
                timeout=120,
            )
            if result.returncode == 0:
                pulled = result.stderr.strip() or result.stdout.strip()
                if pulled:
                    console.print(f"✅ [green]Git LFS:[/] {pulled}")
                else:
                    console.print("✅ [green]Git LFS:[/] all files up to date")

    # Inject environment variables and shell completion into .venv/bin/activate
    with cli_resilient_block("venv environment injection"):
        _inject_venv_environment()
    with cli_resilient_block("venv completion injection"):
        _inject_venv_completion()


@workspace_group.command(name="check-env")
def check_env():
    """Check SDK tool requirements and versions."""
    from sdk.cli.engine_dispatch import ScriptNotFound, run_engine_script

    try:
        result = run_engine_script("check_env.py", ["--generate-mk"])
        if result.returncode != 0:
            sys.exit(result.returncode)
    except ScriptNotFound:
        result = subprocess.run(["make", "check-env"], stderr=subprocess.DEVNULL)
        if result.returncode != 0:
            sys.exit(result.returncode)


@workspace_group.command(name="status")
def workspace_status():
    """Check SDK tool requirements and versions (alias for check-env)."""
    from sdk.cli.engine_dispatch import ScriptNotFound, run_engine_script

    try:
        result = run_engine_script("check_env.py", ["--generate-mk"])
        if result.returncode != 0:
            sys.exit(result.returncode)
    except ScriptNotFound:
        result = subprocess.run(["make", "check-env"], stderr=subprocess.DEVNULL)
        if result.returncode != 0:
            sys.exit(result.returncode)
