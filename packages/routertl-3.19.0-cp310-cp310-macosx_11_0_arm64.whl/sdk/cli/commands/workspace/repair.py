# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Workspace repair commands and helpers."""

import subprocess
import sys

import rich_click as click

from sdk.cli.commands.workspace import (
    _inject_venv_completion,
    _inject_venv_environment,
    _run_update_config,
    workspace_group,
)
from sdk.cli.console import console
from sdk.cli.resilience import cli_resilient_block

# ──────────────────────────────────────────────────────────────
# Repair helpers
# ──────────────────────────────────────────────────────────────

_REPAIR_SKIP = "skip"
_REPAIR_FIXED = "fixed"
_REPAIR_FAILED = "failed"


def _repair_build_env(*, force=False):
    """Regenerate build_env.mk if stale or missing."""
    from pathlib import Path

    yml_path = Path("project.yml")
    env_path = Path("build_env.mk")

    if not yml_path.exists():
        return ("build_env", _REPAIR_SKIP, "no project.yml")

    if not force and env_path.exists():
        if yml_path.stat().st_mtime <= env_path.stat().st_mtime:
            return ("build_env", _REPAIR_SKIP, "already up to date")

    detail = "missing" if not env_path.exists() else "stale"
    console.print(f"🔧 [blue]Regenerating build_env.mk ({detail})...[/]")
    with cli_resilient_block("build_env repair"):
        _run_update_config(exit_on_error=False)
    # Verify it was created/updated
    if env_path.exists():
        return ("build_env", _REPAIR_FIXED, f"regenerated ({detail})")
    return ("build_env", _REPAIR_FAILED, "regeneration failed")


def _repair_deps(*, force=False):
    """Re-resolve dependencies by removing .deps.ok and triggering check-deps."""
    from pathlib import Path

    yml_path = Path("project.yml")
    deps_ok = Path(".deps.ok")

    if not yml_path.exists():
        return ("deps", _REPAIR_SKIP, "no project.yml")

    if not force and deps_ok.exists():
        return ("deps", _REPAIR_SKIP, ".deps.ok present")

    console.print("🔧 [blue]Re-resolving dependencies...[/]")
    if deps_ok.exists():
        deps_ok.unlink()

    # Trigger dependency resolution via make check-deps → update-config
    with cli_resilient_block("deps repair"):
        result = subprocess.run(
            ["make", "check-deps"],
            capture_output=True,
            text=True,
            timeout=120,
        )
        if result.returncode == 0:
            # Ensure sentinel exists after resolution
            if not deps_ok.exists():
                _run_update_config(exit_on_error=False)
            if deps_ok.exists():
                return ("deps", _REPAIR_FIXED, "dependencies re-resolved")
            return ("deps", _REPAIR_FIXED, "check-deps ran (sentinel may require full build)")

    return ("deps", _REPAIR_FAILED, "dependency resolution failed")


def _repair_nvc_workdir(*, force=False):
    """Delete stale NVC work directory and trigger precompile rebuild."""
    import shutil
    from pathlib import Path

    workdir = Path("sim") / "work"
    work_work = workdir / "work"

    if not Path("project.yml").exists():
        return ("nvc_workdir", _REPAIR_SKIP, "no project.yml")

    # Health check: mirror _check_workdir_health() from smart_linter.py
    workdir_healthy = (
        work_work.is_dir()
        and any(work_work.glob("*.cf"))
    )

    if not force and workdir_healthy:
        return ("nvc_workdir", _REPAIR_SKIP, "work directory healthy")

    console.print("🔧 [blue]Rebuilding NVC work directory...[/]")

    # Remove stale work directory
    if work_work.exists():
        with cli_resilient_block("NVC workdir cleanup"):
            shutil.rmtree(work_work)
            console.print("  [dim]Deleted sim/work/work/[/]")

    # Run precompile to rebuild
    with cli_resilient_block("NVC precompile"):
        result = subprocess.run(
            ["make", "precompile"],
            capture_output=True,
            text=True,
            timeout=300,
        )
        if result.returncode == 0:
            return ("nvc_workdir", _REPAIR_FIXED, "work directory rebuilt")
        # Precompile target may not exist in all Makefiles — fall back to linting
        # which triggers its own workdir health check
        console.print("  [dim]precompile target not available, workdir cleared for next lint[/]")
        return ("nvc_workdir", _REPAIR_FIXED, "work directory cleared (will rebuild on next lint)")

    return ("nvc_workdir", _REPAIR_FAILED, "precompile failed")

def _repair_makefile_sdk_path(*, force=False):
    """Patch Makefile to use the correct SDK root path.

    Fixes the ``-include vendor/routertl/Common.mk`` line to point to
    the actual SDK root (resolved via ``resolve_sdk_root()``).  This is
    the key repair for pip-installed SDK users where ``vendor/routertl``
    is empty or doesn't exist.
    """
    import re
    from pathlib import Path

    from sdk.cli.sdk_root import resolve_sdk_root

    makefile = Path("Makefile")
    if not makefile.exists():
        return ("makefile", _REPAIR_SKIP, "no Makefile")

    content = makefile.read_text()

    # Pattern: -include <path>/Common.mk  (various submodule paths)
    pattern = re.compile(
        r"^(-include\s+)(\S+)/Common\.mk",
        re.MULTILINE,
    )
    match = pattern.search(content)
    if not match:
        return ("makefile", _REPAIR_SKIP, "no Common.mk include found")

    current_path = match.group(2)
    current_common = Path(current_path) / "Common.mk"

    # Check if current include path works
    if not force and current_common.exists():
        return ("makefile", _REPAIR_SKIP, f"include path OK ({current_path})")

    # Resolve the real SDK root
    sdk_root = resolve_sdk_root()
    if sdk_root is None:
        return ("makefile", _REPAIR_FAILED, "cannot resolve SDK root")

    # In source checkout: Common.mk is at root (shim → sdk/Common.mk)
    # In pip wheel: only sdk/Common.mk exists (root shim not packaged)
    sdk_common = sdk_root / "Common.mk"
    if not sdk_common.exists():
        sdk_common = sdk_root / "sdk" / "Common.mk"
    if not sdk_common.exists():
        return ("makefile", _REPAIR_FAILED, f"Common.mk not found at {sdk_root}")

    # Patch the Makefile - rewrite the full include line
    new_include = str(sdk_common)
    new_content = pattern.sub(rf"\g<1>{new_include}", content)

    # For pip installs, also need to set SDK_ROOT so mk/*.mk can find scripts
    if "SDK_ROOT" not in content:
        sdk_root_line = f"SDK_ROOT := {sdk_root}\n"
        new_content = sdk_root_line + new_content

    console.print("🔧 [blue]Patching Makefile: SDK path[/]")
    console.print(f"  [dim]{current_path}/Common.mk[/] → [green]{new_include}[/]")

    makefile.write_text(new_content)

    # Also patch build_env.mk if it references the old submodule path
    build_env = Path("build_env.mk")
    if build_env.exists():
        env_content = build_env.read_text()
        # Find any vendor/routertl or vendor/rapidrtl references
        old_patterns = ["vendor/routertl", "vendor/rapidrtl"]
        patched = False
        for old_pat in old_patterns:
            if old_pat in env_content:
                env_content = env_content.replace(old_pat, str(sdk_root))
                patched = True
        if patched:
            build_env.write_text(env_content)
            console.print("  [dim]Also patched: build_env.mk[/]")

    return ("makefile", _REPAIR_FIXED, f"{current_path} → {sdk_common.parent}")


_ALL_REPAIRS = {
    "build_env": _repair_build_env,
    "deps": _repair_deps,
    "nvc_workdir": _repair_nvc_workdir,
    # makefile MUST run last — it patches build_env.mk which
    # _repair_build_env may have just regenerated from project.yml
    "makefile": _repair_makefile_sdk_path,
}


@workspace_group.command(name="repair-venv")
@click.option("--force", is_flag=True, help="Force repair even if .venv appears healthy.")
def repair_venv(force):
    """Nuke and rebuild .venv from scratch.

    Desperate recovery for when the CLI or virtual environment is broken.
    Diagnoses common corruption issues, deletes the old .venv, creates
    a fresh one, re-installs the SDK, and rebuilds CLI shortcuts.

    If the CLI itself is broken, use the standalone script instead:
        bash <sdk-root>/sdk/scripts/repair_venv.sh
    """
    from pathlib import Path

    # Locate the repair script relative to this file
    script = Path(__file__).resolve().parent.parent.parent.parent / "sh" / "repair_venv.sh"
    if not script.exists():
        console.print(f"❌ [red]Repair script not found at:[/] {script}")
        console.print("   Try running directly: bash <sdk-root>/sdk/scripts/repair_venv.sh")
        sys.exit(1)

    cmd = ["bash", str(script)]
    if force:
        cmd.append("--force")

    try:
        result = subprocess.run(cmd)
        if result.returncode == 0:
            # Re-inject environment variables into the fresh venv
            with cli_resilient_block("venv environment injection"):
                _inject_venv_environment()
            with cli_resilient_block("venv completion injection"):
                _inject_venv_completion()
        sys.exit(result.returncode)
    except FileNotFoundError:
        console.print("❌ [red]bash not found on PATH.[/]")
        sys.exit(1)


@workspace_group.command(name="repair")
@click.option(
    "--only",
    type=click.Choice(["makefile", "build_env", "deps", "nvc_workdir"]),
    default=None,
    help="Run only a specific repair (default: all).",
)
@click.option("--force", is_flag=True, help="Force repairs even if checks appear healthy.")
def repair(only, force):
    """Auto-fix common workspace issues.

    Runs automated repairs for issues that ``rr doctor`` detects:
      • makefile    — patch SDK include path for pip-installed SDK
      • build_env   — regenerate stale/missing build_env.mk
      • deps        — re-resolve dependencies (.deps.ok sentinel)
      • nvc_workdir — rebuild NVC work directory (stale .cf catalogs)

    Examples:
        rr ws repair                  # fix everything
        rr ws repair --only makefile  # fix only SDK path in Makefile
        rr ws repair --force          # force all repairs

    For venv recovery, use: rr ws repair-venv
    """
    from rich.table import Table

    console.print()
    console.print("🔧 [bold cyan]Workspace Repair[/]")
    console.print()

    repairs_to_run = {only: _ALL_REPAIRS[only]} if only else _ALL_REPAIRS
    results = []

    for name, fn in repairs_to_run.items():
        with cli_resilient_block(f"repair {name}"):
            result = fn(force=force)
            results.append(result)

    # Summary table
    console.print()
    table = Table(title="Repair Summary", show_lines=False)
    table.add_column("Check", style="cyan", min_width=14)
    table.add_column("Status", min_width=8)
    table.add_column("Detail", style="dim")

    status_styles = {
        _REPAIR_SKIP: "[dim]skip[/]",
        _REPAIR_FIXED: "[bold green]fixed[/]",
        _REPAIR_FAILED: "[bold red]FAILED[/]",
    }

    for name, status, detail in results:
        table.add_row(name, status_styles.get(status, status), detail)

    console.print(table)
    console.print()

    fixed = sum(1 for _, s, _ in results if s == _REPAIR_FIXED)
    failed = sum(1 for _, s, _ in results if s == _REPAIR_FAILED)
    skipped = sum(1 for _, s, _ in results if s == _REPAIR_SKIP)

    parts = []
    if fixed:
        parts.append(f"[bold green]{fixed} fixed[/]")
    if skipped:
        parts.append(f"[dim]{skipped} skipped[/]")
    if failed:
        parts.append(f"[bold red]{failed} failed[/]")
    console.print("  " + " · ".join(parts))
    console.print()
