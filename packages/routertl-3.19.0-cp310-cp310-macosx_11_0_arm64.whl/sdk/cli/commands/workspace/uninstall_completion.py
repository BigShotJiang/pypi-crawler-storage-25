# SPDX-FileCopyrightText: 2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""RTL-P3.204 — symmetric teardown for rr ws install-completion.

Undoes what ``rr ws install-completion`` did:

* deletes the shell-specific completion file, and
* (zsh only) strips the sentinel-wrapped ``fpath`` + ``compinit`` block
  from ``~/.zshrc``.

Friendly no-ops when there's nothing to remove (missing file + missing
sentinel both print a one-liner and exit 0). ``--keep-rc`` leaves the
``.zshrc`` edits in place — useful when the user wants to keep the
``fpath`` entry for another tool that shares ``~/.zsh/completions``.
"""

from __future__ import annotations

from pathlib import Path

import rich_click as click

from sdk.cli.commands.workspace import workspace_group
from sdk.cli.commands.workspace.install_completion import (
    _SUPPORTED_SHELLS,
    _ZSHRC_SENTINEL_END,
    _ZSHRC_SENTINEL_START,
    _completion_install_path,
    _detect_shell,
)
from sdk.cli.console import console


def _strip_zsh_fpath_block(content: str) -> tuple[str, bool]:
    """Return ``(new_content, was_modified)`` with the sentinel block removed.

    Also consumes the blank line we inserted before the start sentinel
    and the newline after the end sentinel, so running install → uninstall
    returns the file byte-exactly to its pre-install state.
    """
    start_idx = content.find(_ZSHRC_SENTINEL_START)
    if start_idx < 0:
        return content, False
    end_idx = content.find(_ZSHRC_SENTINEL_END, start_idx)
    if end_idx < 0:
        # Half-present sentinel — leave the file alone rather than
        # truncate to EOF. Surfacing via caller's "nothing to remove".
        return content, False
    end_idx += len(_ZSHRC_SENTINEL_END)
    if end_idx < len(content) and content[end_idx] == "\n":
        end_idx += 1
    adjusted_start = start_idx
    if adjusted_start > 0 and content[adjusted_start - 1] == "\n":
        adjusted_start -= 1
    return content[:adjusted_start] + content[end_idx:], True


@workspace_group.command(name="uninstall-completion")
@click.option(
    "--shell",
    "shell_override",
    type=click.Choice(list(_SUPPORTED_SHELLS), case_sensitive=False),
    default=None,
    help="Target shell.  Auto-detected from $SHELL when omitted.",
)
@click.option(
    "--keep-rc",
    is_flag=True,
    default=False,
    help="Leave ~/.zshrc fpath/compinit lines in place "
         "(zsh only; no-op for bash/fish).",
)
def uninstall_completion(shell_override, keep_rc):
    """Remove shell completion for rr (symmetric with install-completion).

    \b
    Deletes the shell-specific completion file and — for zsh — strips
    the sentinel-wrapped fpath + compinit block from ~/.zshrc.

    \b
        zsh  → removes ~/.zsh/completions/_rr
               strips ~/.zshrc sentinel block (unless --keep-rc)
        bash → removes ~/.local/share/bash-completion/completions/rr
        fish → removes ~/.config/fish/completions/rr.fish

    \b
    Idempotent: missing file + missing sentinel block both print a
    "nothing to remove" line and exit 0. Run this BEFORE pip-uninstalling
    rr so the command is still available.
    """
    shell = (shell_override or _detect_shell() or "").lower()
    if shell not in _SUPPORTED_SHELLS:
        console.print(
            "❌ [red]Could not detect shell from $SHELL.[/]\n"
            "   [dim]Pass [cyan]--shell zsh|bash|fish[/] explicitly.[/]"
        )
        raise SystemExit(1)

    path = _completion_install_path(shell)
    removed_any = False

    if path.exists():
        path.unlink()
        console.print(
            f"🧹 [green]Removed completion script:[/] [cyan]{path}[/]"
        )
        removed_any = True
    else:
        console.print(
            f"   [dim]No completion script at [cyan]{path}[/] — skipped.[/]"
        )

    if shell == "zsh" and not keep_rc:
        zshrc = Path.home() / ".zshrc"
        if zshrc.exists():
            original = zshrc.read_text()
            new, changed = _strip_zsh_fpath_block(original)
            if changed:
                zshrc.write_text(new)
                console.print(
                    f"🧹 [green]Stripped fpath + compinit block from[/] "
                    f"[cyan]{zshrc}[/]"
                )
                removed_any = True
            else:
                console.print(
                    f"   [dim]No RouteRTL sentinel block in "
                    f"[cyan]{zshrc}[/] — skipped.[/]"
                )
        else:
            console.print(
                f"   [dim]No [cyan]{zshrc}[/] to edit — skipped.[/]"
            )

    if not removed_any:
        console.print("\n💡 [dim]Nothing to remove — completion wasn't installed "
                      "(or was cleaned up already).[/]")
        return

    console.print(
        "\n💡 [dim]Reload your shell to drop the old completion:[/] "
        "[cyan]exec $SHELL[/]"
    )
