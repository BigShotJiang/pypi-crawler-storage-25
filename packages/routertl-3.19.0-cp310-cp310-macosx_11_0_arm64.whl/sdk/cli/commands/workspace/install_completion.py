# SPDX-FileCopyrightText: 2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""RTL-P2.425 — one-shot shell-completion installer.

Users previously had to remember the Click completion incantation:

    # zsh
    mkdir -p ~/.zsh/completions
    _RR_COMPLETE=zsh_source rr > ~/.zsh/completions/_rr
    # ... + add fpath/compinit to .zshrc

This command wraps that in ``rr ws install-completion``.  Auto-detects
the shell, drops the generated script into the standard location,
prints a one-line "reload your shell" hint.  Idempotent — re-running
overwrites the script but leaves rc-file additions untouched.
"""

from __future__ import annotations

import os
from pathlib import Path

import rich_click as click

from sdk.cli.commands.completion import (
    _bash_completion_script,
    _fish_completion_script,
    _zsh_completion_script,
)
from sdk.cli.commands.workspace import workspace_group
from sdk.cli.console import console
from sdk.cli.resilience import cli_resilient


@cli_resilient("CLI name resolution", default="routertl")
def _cli_name():
    from sdk.cli.main import CLI_NAME
    return CLI_NAME


_SUPPORTED_SHELLS = ("bash", "zsh", "fish")


def _detect_shell() -> str | None:
    """Return 'bash' / 'zsh' / 'fish' based on $SHELL, or None on unknown.

    Bash is the safe fallback for Linux, but we return None rather than
    silently guessing when $SHELL is unset or exotic — the command
    surfaces a clear error asking the user to pass --shell explicitly.
    """
    shell_path = os.environ.get("SHELL", "")
    base = os.path.basename(shell_path)
    if base in _SUPPORTED_SHELLS:
        return base
    return None


def _completion_install_path(shell: str) -> Path:
    """Return the standard completion file path for *shell*."""
    home = Path.home()
    if shell == "zsh":
        return home / ".zsh" / "completions" / "_rr"
    if shell == "bash":
        return home / ".local" / "share" / "bash-completion" / "completions" / "rr"
    if shell == "fish":
        return home / ".config" / "fish" / "completions" / "rr.fish"
    raise ValueError(f"Unsupported shell: {shell}")


_ZSHRC_SENTINEL_START = "# --- RouteRTL zsh completion (RTL-P2.425) ---"
_ZSHRC_SENTINEL_END = "# --- end RouteRTL zsh completion ---"


def _ensure_zsh_fpath(zshrc: Path) -> bool:
    """Append fpath + compinit lines to *zshrc* if not already present.

    Returns True when the file was modified, False when the sentinel
    block was already present.  Idempotent via sentinel markers so
    repeated runs don't accumulate lines.
    """
    if zshrc.exists() and _ZSHRC_SENTINEL_START in zshrc.read_text():
        return False

    block = "\n".join([
        "",
        _ZSHRC_SENTINEL_START,
        'fpath=(~/.zsh/completions $fpath)',
        "autoload -U compinit && compinit",
        _ZSHRC_SENTINEL_END,
        "",
    ])
    with open(zshrc, "a") as f:
        f.write(block)
    return True


def _generate_script(shell: str, name: str) -> str:
    if shell == "bash":
        return _bash_completion_script(name)
    if shell == "zsh":
        return _zsh_completion_script(name)
    if shell == "fish":
        return _fish_completion_script(name)
    raise ValueError(f"Unsupported shell: {shell}")


@workspace_group.command(name="install-completion")
@click.option(
    "--shell",
    "shell_override",
    type=click.Choice(list(_SUPPORTED_SHELLS), case_sensitive=False),
    default=None,
    help="Target shell.  Auto-detected from $SHELL when omitted.",
)
@click.option(
    "--print", "print_only",
    is_flag=True,
    default=False,
    help="Write the script to stdout instead of installing it "
         "(useful for packaging / manual placement).",
)
def install_completion(shell_override, print_only):
    """Install shell completion for rr (one-shot).

    \b
    Detects the user's shell, generates the completion script, and
    drops it into the standard path for that shell:

        zsh  → ~/.zsh/completions/_rr
               (also appends fpath + compinit to ~/.zshrc if missing)
        bash → ~/.local/share/bash-completion/completions/rr
        fish → ~/.config/fish/completions/rr.fish

    \b
    After installation, reload your shell (or `exec $SHELL`) for TAB
    completion on every rr subcommand, flag, and most arguments.

    \b
    Examples:
        rr ws install-completion              # auto-detect + install
        rr ws install-completion --shell zsh  # force zsh
        rr ws install-completion --print      # dump script to stdout
    """
    shell = (shell_override or _detect_shell() or "").lower()
    if shell not in _SUPPORTED_SHELLS:
        console.print(
            "❌ [red]Could not detect shell from $SHELL.[/]\n"
            "   [dim]Pass [cyan]--shell zsh|bash|fish[/] explicitly.[/]"
        )
        raise SystemExit(1)

    script = _generate_script(shell, _cli_name())

    if print_only:
        click.echo(script, nl=False)
        return

    path = _completion_install_path(shell)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(script)
    console.print(
        f"🐚 [green]Completion script installed:[/] [cyan]{path}[/]"
    )

    # Shell-specific post-install fixups.
    if shell == "zsh":
        zshrc = Path.home() / ".zshrc"
        if _ensure_zsh_fpath(zshrc):
            console.print(
                f"   [dim]Appended fpath + compinit lines to "
                f"[cyan]{zshrc}[/].[/]"
            )
        else:
            console.print(
                f"   [dim]fpath + compinit already present in "
                f"[cyan]{zshrc}[/] — left untouched.[/]"
            )

    console.print(
        "\n💡 [dim]Reload your shell to activate:[/] "
        "[cyan]exec $SHELL[/]"
    )
