# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

import subprocess
import sys
from pathlib import Path

import rich_click as click

from sdk.cli.console import console
from sdk.cli.eda_helpers import (
    check_version_compat,
    detect_quartus,
    detect_tool,
    extract_qdz,
    find_patch_zips,
    load_sdk_requirements,
    read_env_var,
    scan_device_families,
)
from sdk.cli.resilience import cli_resilient_block


@click.group(name="eda")
def eda_group():
    """Native EDA Tool Management."""
    pass


# ── .env variable names per tool ──
_INSTALL_DIR_VARS = {
    "quartus": "QUARTUS_INSTALL_DIR",
}
_INSTALLER_PATH_VARS = {
    "quartus": "QUARTUS_INSTALLER_PATH",
}


def _resolve_install_dir(env):
    """Resolve the installation directory for an EDA tool from .env, prompting if needed."""
    var_name = _INSTALL_DIR_VARS[env]
    install_dir = read_env_var(var_name)

    if not install_dir:
        console.print(f"⚠️  [yellow]{var_name} is not set in .env[/]")
        console.print(f"   [dim]This should point to the directory where {env.capitalize()} is installed.[/]")
        console.print("   [dim]e.g. /opt/altera, ~/intelFPGA_pro/25.3[/]\n")

        user_path = click.prompt(
            f"   Enter {env.capitalize()} install directory",
            default="",
            show_default=False,
        ).strip()

        if not user_path:
            console.print("   [dim]Skipped. Set it in .env or run rr docker setup.[/]")
            sys.exit(1)

        p = Path(user_path).expanduser().resolve()
        if not p.is_dir():
            console.print(f"   [red]❌ '{p}' is not a valid directory.[/]")
            sys.exit(1)

        install_dir = str(p)

        # Save to .env
        dotenv = Path(".env")
        if dotenv.exists():
            content = dotenv.read_text()
        else:
            content = ""
        lines = content.splitlines()
        found_key = False
        for i, ln in enumerate(lines):
            if ln.strip().startswith(f"{var_name}="):
                lines[i] = f"{var_name}={install_dir}"
                found_key = True
                break
        if not found_key:
            if lines and lines[-1].strip():
                lines.append("")
            lines.append(f"{var_name}={install_dir}")
        dotenv.write_text("\n".join(lines) + "\n")
        console.print("   [green]✅ Saved to .env[/]\n")

    return install_dir


def _resolve_installer_path(env):
    """Resolve the installer/source directory from .env."""
    var_name = _INSTALLER_PATH_VARS[env]
    path = read_env_var(var_name)
    if not path:
        console.print(f"❌ [red]{var_name} is not set in .env[/]")
        console.print("   [dim]Set it with: rr docker setup[/]")
        sys.exit(1)
    p = Path(path).expanduser()
    if not p.exists():
        console.print(f"❌ [red]Directory does not exist: {path}[/]")
        sys.exit(1)
    return str(p)


@eda_group.command(name="status")
@click.argument("tool_name", required=False, default=None)
def eda_status(tool_name):
    """Show installed EDA tools, versions, and device families.

    Without arguments, scans all known tools from sdk_requirements.yml.
    With a tool name, shows only that tool.

    Examples:
        rr eda status              # Show all
        rr eda status quartus      # Quartus only
        rr eda status vivado       # Vivado only
    """
    reqs = load_sdk_requirements()
    all_tools = reqs.get("tools", {})

    if tool_name:
        if tool_name not in all_tools:
            console.print(f"  [red]❌ Unknown tool '{tool_name}'[/]")
            console.print(f"  [dim]Known tools: {', '.join(sorted(all_tools.keys()))}[/]")
            return
        tools_to_check = {tool_name: all_tools[tool_name]}
    else:
        tools_to_check = all_tools

    console.print("\n🔧 [cyan]EDA Tool Status[/]\n")

    # Group tools by scope for display
    scope_groups = {}
    for name, spec in tools_to_check.items():
        scopes = spec.get("scope", ["other"])
        primary = scopes[0] if scopes else "other"
        scope_groups.setdefault(primary, []).append((name, spec))

    scope_labels = {
        "build": "🏗️  Synthesis & Implementation",
        "sim": "🔬 Simulation",
        "lint": "📝 Analysis & Linting",
        "other": "🔧 Other",
    }

    found_count = 0
    missing_count = 0

    for scope in ["build", "sim", "lint", "other"]:
        entries = scope_groups.get(scope, [])
        if not entries:
            continue

        label = scope_labels.get(scope, scope)
        console.print(f"  [bold]{label}[/]")

        for name, spec in entries:
            check_cmd = spec.get("check_cmd", "")
            parse_regex = spec.get("parse_regex", "")
            role = spec.get("role", "")
            required = spec.get("required", False)

            # Special path for Quartus: use .env-based detection with device families
            if name == "quartus_sh":
                _show_quartus_status(name, spec, role)
                continue

            # Generic detection via PATH
            version, binary_path = detect_tool(check_cmd, parse_regex)

            if version:
                found_count += 1
                console.print(f"    [green]●[/] [cyan]{name}[/] {version}")
                console.print(f"      [dim]{role}[/]")
                if binary_path:
                    console.print(f"      [dim]Binary: {binary_path}[/]")
            elif binary_path:
                found_count += 1
                console.print(f"    [yellow]●[/] [cyan]{name}[/] (version unknown)")
                console.print(f"      [dim]{role}[/]")
                console.print(f"      [dim]Binary: {binary_path}[/]")
            else:
                missing_count += 1
                marker = "[red]●[/]" if required else "[dim]○[/]"
                console.print(f"    {marker} [dim]{name}[/] — not found")
                hint = spec.get("install_hint", "")
                if hint:
                    console.print(f"      [dim]{hint}[/]")

        console.print("")

    console.print(f"  [dim]Summary: {found_count} found, {missing_count} not found[/]\n")


def _show_quartus_status(name, spec, role):
    """Show Quartus status with .env-based detection and device families."""
    var_name = _INSTALL_DIR_VARS.get("quartus", "QUARTUS_INSTALL_DIR")
    install_dir = read_env_var(var_name)

    if not install_dir:
        # Fall back to generic PATH detection
        version, binary_path = detect_tool(spec.get("check_cmd", ""), spec.get("parse_regex", ""))
        if version:
            console.print(f"    [green]●[/] [cyan]{name}[/] {version}")
            console.print(f"      [dim]{role}[/]")
            if binary_path:
                console.print(f"      [dim]Binary: {binary_path}[/]")
        else:
            console.print(f"    [dim]○[/] [dim]{name}[/] — not found")
            hint = spec.get("install_hint", "")
            if hint:
                console.print(f"      [dim]{hint}[/]")
        return

    p = Path(install_dir).expanduser()
    if not p.exists():
        console.print(f"    [red]●[/] [cyan]{name}[/] — {install_dir} does not exist")
        return

    version, major_minor, edition, quartus_sh = detect_quartus(str(p))

    if version:
        edition_label = edition or "unknown"
        console.print(f"    [green]●[/] [cyan]{name}[/] {version} ({edition_label})")
        console.print(f"      [dim]{role}[/]")
        console.print(f"      [dim]Path: {install_dir}[/]")
        if quartus_sh:
            console.print(f"      [dim]Binary: {quartus_sh}[/]")
    else:
        console.print(f"    [yellow]●[/] [cyan]{name}[/] — not detected in {install_dir}")
        return

    # Device families
    families = scan_device_families(str(p))
    if families:
        console.print(f"      [dim]Device families ({len(families)}):[/]")
        for fname, count in families:
            console.print(f"        [green]✅[/] {fname}  [dim]({count} files)[/]")
    else:
        console.print("      [yellow]⚠️  No device families detected[/]")



@eda_group.command(name="add-device")
@click.argument("env", type=click.Choice(["quartus"]), required=True)
def eda_add_device(env):
    """Install device packages (.qdz) into a native EDA installation.

    Extracts .qdz device files directly into the Quartus installation
    directory. Same as 'rr docker add-device' but for native installs.

    Examples:
        rr eda add-device quartus
    """
    install_dir = _resolve_install_dir(env)
    installer_path = _resolve_installer_path(env)

    console.print("\n📦 [cyan]Quartus Device Package Installer (native)[/]\n")

    # Detect installed Quartus
    version, major_minor, edition, _sh = detect_quartus(install_dir)
    if version:
        console.print(f"  ✅ Quartus {version} ({edition or 'unknown'}) in {install_dir}")
    else:
        console.print(f"  [yellow]⚠️  Quartus not detected in {install_dir}[/]")
        console.print("  [dim]Proceeding anyway — .qdz files will be extracted.[/]")

    # Scan for .qdz files
    p = Path(installer_path)
    qdz_files = sorted(p.glob("*.qdz"))
    if not qdz_files:
        console.print(f"\n  ⚠️  [yellow]No .qdz files found in {installer_path}[/]")
        console.print("  [dim]Download device packages from Intel FPGA Download Center.[/]")
        sys.exit(0)

    console.print(f"\n  📦 Found {len(qdz_files)} device package(s):\n")
    for qf in qdz_files:
        size_gb = qf.stat().st_size / (1024 ** 3)
        console.print(f"     [cyan]{qf.name}[/] ({size_gb:.1f} GB)")

    # Process each .qdz
    installed = 0
    skipped = 0
    failed = 0

    for qf in qdz_files:
        # Version compatibility check
        mismatch = check_version_compat(major_minor, edition, qf.name)
        if mismatch:
            console.print(f"\n  ⚠️  [yellow]{mismatch}[/]")

        # Check if already installed
        import zipfile as zf_mod

        family_dir = None
        with cli_resilient_block("device family detection"):
            z = zf_mod.ZipFile(qf)
            for n in z.namelist():
                if n.startswith("quartus/common/devinfo/") and n.endswith("/"):
                    parts = n.replace("quartus/common/devinfo/", "").strip("/").split("/")
                    if parts[0]:
                        family_dir = parts[0]
                        break

        if family_dir:
            existing = Path(install_dir) / "quartus" / "common" / "devinfo" / family_dir
            if existing.is_dir():
                count = sum(1 for _ in existing.rglob("*") if _.is_file())
                if count > 100:
                    console.print(f"\n  ⏭️  {qf.name}: {family_dir} already installed ({count} files) — skipping")
                    skipped += 1
                    continue

        console.print(f"\n  📥 Installing {qf.name}...")
        with cli_resilient_block("QDZ device extraction"):
            file_count = extract_qdz(str(qf), install_dir, progress=True)
            console.print(f"  ✅ Done ({file_count} files extracted)")
            installed += 1
            continue
        # Reached only if cli_resilient_block caught an error
        failed += 1

    # Summary
    console.print(f"\n  📊 Summary: {installed} installed, {skipped} skipped, {failed} failed")

    # Post-install device inventory
    families = scan_device_families(install_dir)
    if families:
        console.print(f"\n  📦 Installed Device Families ({len(families)}):")
        for name, count in families:
            console.print(f"     [green]✅[/] {name}  [dim]({count} files)[/]")
    console.print("")


@eda_group.command(name="add-patch")
@click.argument("env", type=click.Choice(["quartus"]), required=True)
def eda_add_patch(env):
    """Apply hotfix patches to a native EDA installation.

    Extracts .run patch installers from Altera patch ZIPs and
    applies them to the local Quartus installation.

    Examples:
        rr eda add-patch quartus
    """
    install_dir = _resolve_install_dir(env)
    installer_path = _resolve_installer_path(env)

    console.print("\n🩹 [cyan]Quartus Patch Installer (native)[/]\n")

    # Detect installed Quartus
    version, major_minor, edition, _sh = detect_quartus(install_dir)
    if version:
        console.print(f"  ✅ Quartus {version} ({edition or 'unknown'}) in {install_dir}")
    else:
        console.print(f"  [red]❌ Quartus not detected in {install_dir}[/]")
        console.print("  [dim]Install Quartus first before applying patches.[/]")
        sys.exit(1)

    # Find patch ZIPs
    patches = find_patch_zips(installer_path)
    if not patches:
        console.print(f"\n  ⚠️  [yellow]No patch .zip files found in {installer_path}[/]")
        console.print("  [dim]Download patches from Intel FPGA Download Center.[/]")
        sys.exit(0)

    console.print(f"\n  🩹 Found {len(patches)} patch(es):\n")
    for pf in patches:
        size_mb = pf.stat().st_size / (1024 ** 2)
        console.print(f"     [cyan]{pf.name}[/] ({size_mb:.0f} MB)")

    # Apply patches
    import tempfile
    import zipfile as zf_mod

    applied = 0
    fail = 0

    for pf in patches:
        console.print(f"\n  🩹 Applying {pf.name}...")

        with tempfile.TemporaryDirectory() as tmp:
            # Extract the ZIP
            with cli_resilient_block("patch ZIP extraction"):
                zf_mod.ZipFile(pf).extractall(tmp)

            # Find the .run file
            run_files = list(Path(tmp).rglob("*-linux.run"))
            if not run_files:
                console.print(f"  ❌ [red]No .run file found inside {pf.name}[/]")
                fail += 1
                continue

            run_file = run_files[0]
            run_file.chmod(run_file.stat().st_mode | 0o755)
            console.print(f"     Installer: {run_file.name}")

            # Show version
            with cli_resilient_block("patch version check"):
                result = subprocess.run(
                    [str(run_file), "--version"],
                    capture_output=True, text=True, timeout=10,
                )
                if result.stdout.strip():
                    console.print(f"     {result.stdout.strip().splitlines()[0]}")

            # Show readme
            readmes = list(Path(tmp).rglob("*-readme.txt"))
            if readmes:
                console.print("     📄 Patch notes:")
                with open(readmes[0]) as f:
                    for line in f.readlines()[:3]:
                        console.print(f"        [dim]{line.rstrip()}[/]")

            # Apply
            console.print("     ⏳ Running patch installer (unattended)...")
            result = subprocess.run(
                [str(run_file), "--mode", "unattended", "--accept_eula", "1", "--installdir", install_dir],
                check=False,
            )
            if result.returncode == 0:
                console.print("     ✅ Patch applied successfully")
                applied += 1
            else:
                console.print(f"     ❌ [red]Failed (exit code: {result.returncode})[/]")
                console.print("     [dim]Tip: you may need to run with sudo if Quartus is in /opt/[/]")
                fail += 1

    # Summary
    console.print(f"\n  📊 Summary: {applied} applied, {fail} failed")

    # Show updated version
    new_ver, _, _, _ = detect_quartus(install_dir)
    if new_ver:
        console.print(f"  📋 Quartus version after patching: {new_ver}")
    console.print("")


@eda_group.command(name="install-unisim")
@click.option("--force", is_flag=True, help="Re-download even if cache exists.")
@click.option("--compile", is_flag=True, help="Pre-compile for the active simulator after download.")
def eda_install_unisim(force, compile):
    """Download Xilinx unisim VHDL sources for simulation.

    Fetches unisim_VCOMP.vhd and unisim_VPKG.vhd from the mirror repo
    into ~/.routertl/vendor_libs/unisim/. These are required for Xilinx
    primitive simulation (IBUFDS, MMCME2_ADV, BUFG, etc.).

    Examples:
        rr eda install-unisim              # Download sources
        rr eda install-unisim --compile    # Download + pre-compile for NVC
        rr eda install-unisim --force      # Re-download even if cached
    """
    import shutil

    from routertl_core.sim.vendor_libraries import (
        UNISIM_CACHE,
        UNISIM_FILES,
        UNISIM_REPO,
        _has_unisim_sources,
        ensure_nvc_unisim,
        unisim_ver_available,
    )

    console.print("\n📦 [cyan]Unisim Source Installer[/]\n")

    # Check existing cache
    if _has_unisim_sources(UNISIM_CACHE) and not force:
        console.print(f"  ✅ Unisim sources already cached at {UNISIM_CACHE}")
        for f in UNISIM_FILES:
            size = (UNISIM_CACHE / f).stat().st_size
            console.print(f"     [dim]{f} ({size / 1024:.0f} KB)[/]")
        console.print("\n  [dim]Use --force to re-download.[/]")
    else:
        # Clean existing cache if force
        if force and UNISIM_CACHE.exists():
            console.print("  🗑️  Removing existing cache...")
            shutil.rmtree(UNISIM_CACHE, ignore_errors=True)

        console.print(f"  📥 Cloning from {UNISIM_REPO}...")
        UNISIM_CACHE.parent.mkdir(parents=True, exist_ok=True)

        git_bin = shutil.which("git")
        if not git_bin:
            console.print("  ❌ [red]git not found on PATH[/]")
            console.print("  [dim]Install git to download unisim sources.[/]")
            return

        with cli_resilient_block("unisim clone"):
            result = subprocess.run(
                [git_bin, "clone", "--depth", "1", UNISIM_REPO, str(UNISIM_CACHE)],
                capture_output=True,
                text=True,
            )
            if result.returncode != 0:
                console.print(f"  ❌ [red]Clone failed[/]: {result.stderr.strip()}")
                hint = _scan_stderr_for_tls_hint(result.stderr or "")
                if hint:
                    console.print(hint)
                return

        if _has_unisim_sources(UNISIM_CACHE):
            console.print(f"  ✅ Sources cached at {UNISIM_CACHE}")
            for f in UNISIM_FILES:
                size = (UNISIM_CACHE / f).stat().st_size
                console.print(f"     [dim]{f} ({size / 1024:.0f} KB)[/]")
        else:
            console.print("  ❌ [red]Clone succeeded but expected files not found[/]")
            return

    # Compile if requested
    if compile:
        console.print("\n  🔨 Pre-compiling for NVC...")
        if ensure_nvc_unisim(verbose=True):
            console.print("  ✅ NVC unisim library compiled")
        else:
            console.print("  ⚠️  [yellow]NVC compilation failed — sources are still cached for manual use[/]")

    # Verilog/SV unisim status
    ver_dir = unisim_ver_available()
    if ver_dir:
        ver_count = sum(1 for _ in ver_dir.glob("*.v"))
        console.print(f"\n  ✅ Verilog unisim (unisim_ver) available: {ver_dir}")
        console.print(f"     [dim]{ver_count} Verilog primitives[/]")
    else:
        console.print("\n  [dim]ℹ️  Verilog unisim (unisim_ver) requires Vivado ($XILINX_VIVADO).[/]")
        console.print("  [dim]   Set XILINX_VIVADO to enable SV primitive simulation.[/]")

    console.print("")


@eda_group.command(name="install-xpm")
@click.option("--force", is_flag=True, help="Re-download even if cache exists.")
@click.option("--compile", is_flag=True, help="Pre-compile for the active simulator after download.")
def eda_install_xpm(force, compile):
    """Download Xilinx XPM VHDL sources for open-source simulation.

    Fetches the xpm_vhdl community VHDL models (CDC, FIFO, memory macros)
    into ~/.routertl/vendor_libs/xpm/. These provide VHDL equivalents of
    the Xilinx Parameterized Macros for simulation with NVC, GHDL, etc.

    Note: Native Verilog XPM ship with Vivado at $XILINX_VIVADO/data/ip/xpm/.
    This command provides the VHDL reimplementation for open-source simulators.

    Examples:
        rr eda install-xpm              # Download sources
        rr eda install-xpm --compile    # Download + pre-compile for NVC/GHDL
        rr eda install-xpm --force      # Re-download even if cached
    """
    import shutil

    from routertl_core.sim.vendor_libraries import (
        XPM_CACHE,
        XPM_REPO,
        _has_xpm_sources,
        _xpm_compile_order,
        ensure_ghdl_xpm,
        ensure_nvc_xpm,
    )

    console.print("\n📦 [cyan]XPM VHDL Source Installer[/]\n")

    xpm_src = XPM_CACHE / "src" / "xpm"

    # Check existing cache
    if _has_xpm_sources(xpm_src) and not force:
        console.print(f"  ✅ XPM sources already cached at {XPM_CACHE}")
        xpm_files = _xpm_compile_order(xpm_src)
        console.print(f"     [dim]{len(xpm_files)} VHDL files (CDC, FIFO, Memory)[/]")
        console.print("\n  [dim]Use --force to re-download.[/]")
    else:
        # Clean existing cache if force
        if force and XPM_CACHE.exists():
            console.print("  🗑️  Removing existing cache...")
            shutil.rmtree(XPM_CACHE, ignore_errors=True)

        console.print(f"  📥 Cloning from {XPM_REPO}...")
        XPM_CACHE.parent.mkdir(parents=True, exist_ok=True)

        git_bin = shutil.which("git")
        if not git_bin:
            console.print("  ❌ [red]git not found on PATH[/]")
            console.print("  [dim]Install git to download XPM sources.[/]")
            return

        with cli_resilient_block("xpm clone"):
            result = subprocess.run(
                [git_bin, "clone", "--depth", "1", XPM_REPO, str(XPM_CACHE)],
                capture_output=True,
                text=True,
            )
            if result.returncode != 0:
                console.print(f"  ❌ [red]Clone failed[/]: {result.stderr.strip()}")
                hint = _scan_stderr_for_tls_hint(result.stderr or "")
                if hint:
                    console.print(hint)
                return

        if _has_xpm_sources(xpm_src):
            xpm_files = _xpm_compile_order(xpm_src)
            console.print(f"  ✅ Sources cached at {XPM_CACHE}")
            console.print(f"     [dim]{len(xpm_files)} VHDL files (CDC, FIFO, Memory)[/]")
        else:
            console.print("  ❌ [red]Clone succeeded but expected files not found[/]")
            return

    # Compile if requested
    if compile:
        nvc_ok = False
        ghdl_ok = False

        console.print("\n  🔨 Pre-compiling for NVC...")
        if ensure_nvc_xpm(verbose=True):
            console.print("  ✅ NVC xpm library compiled")
            nvc_ok = True
        else:
            console.print("  ⚠️  [yellow]NVC compilation skipped (nvc not found or failed)[/]")

        console.print("\n  🔨 Pre-compiling for GHDL...")
        if ensure_ghdl_xpm(verbose=True):
            console.print("  ✅ GHDL xpm library compiled")
            ghdl_ok = True
        else:
            console.print("  ⚠️  [yellow]GHDL compilation skipped (ghdl not found or failed)[/]")

        if not nvc_ok and not ghdl_ok:
            console.print("  [dim]Sources are still cached for manual compilation.[/]")

    console.print("")


# ──────────────────────────────────────────────────────────────
# rr eda install — open-source simulator bootstrap
# ──────────────────────────────────────────────────────────────

import platform
import shutil


def _detect_platform():
    """Detect the current OS and package manager.

    Returns (os_id, pkg_mgr) where os_id is 'debian', 'fedora', 'arch',
    'macos', or 'unknown', and pkg_mgr is the install command prefix.
    """
    system = platform.system().lower()
    if system == "darwin":
        if shutil.which("brew"):
            return "macos", "brew"
        return "macos", None

    # Linux — read /etc/os-release
    os_release = Path("/etc/os-release")
    os_id = ""
    if os_release.exists():
        for line in os_release.read_text().splitlines():
            if line.startswith("ID="):
                os_id = line.split("=", 1)[1].strip().strip('"')
            elif line.startswith("ID_LIKE="):
                os_id = os_id or line.split("=", 1)[1].strip().strip('"')

    if os_id in ("ubuntu", "debian") or "debian" in os_id or "ubuntu" in os_id:
        return "debian", "apt"
    if os_id in ("fedora", "rhel", "centos", "rocky", "alma"):
        return "fedora", "dnf"
    if os_id == "arch":
        return "arch", "pacman"

    return "unknown", None


# RTL-P3.170: TLS-inspecting proxies (corporate / hotel WiFi) make git
# https:// clones fail with a generic subprocess traceback.  Detect the
# common libcurl / OpenSSL signatures and print an actionable hint so
# the user doesn't have to know the insteadOf trick.
_TLS_ERROR_SIGNATURES = (
    "server certificate verification failed",
    "self signed certificate",
    "self-signed certificate",
    "unable to get local issuer certificate",
    "ssl certificate problem",
    "ssl_error",
    "tls certificate",
    "unable to verify the first certificate",
    "sslv3 alert handshake failure",
    "certificate has expired",
)


def _scan_stderr_for_tls_hint(stderr_text: str) -> str | None:
    """Return a user-facing hint when *stderr_text* looks like a TLS error.

    None when no TLS signature is present — caller should report the
    underlying error as normal.  See Haz.29 for the full mitigation.
    """
    if not stderr_text:
        return None
    lowered = stderr_text.lower()
    if not any(sig in lowered for sig in _TLS_ERROR_SIGNATURES):
        return None
    return (
        "  💡 [yellow]Looks like a TLS-inspecting proxy is blocking HTTPS "
        "clones.[/]\n"
        "     [dim]Probe SSH first:[/]  [cyan]ssh -T git@github.com[/]\n"
        "     [dim]If SSH works, route github.com clones over SSH:[/]\n"
        "       [cyan]git config --global url.\"git@github.com:\"."
        "insteadOf \"https://github.com/\"[/]\n"
        "     [dim]Full mitigation: see Haz.29.[/]"
    )


def _run_install_cmd(cmd, tool_name):
    """Run an install command with live output, returning True on success.

    RTL-P3.170: git commands are run with captured stderr so we can scan
    for TLS-inspection errors and print an actionable hint; the stderr
    is still echoed to the terminal so the raw git message stays visible.
    """
    console.print(f"  [dim]$ {' '.join(cmd)}[/]")
    is_git_cmd = bool(cmd) and str(cmd[0]).endswith("git")
    try:
        if is_git_cmd:
            result = subprocess.run(
                cmd, check=False, capture_output=True, text=True,
            )
            # Echo git's own output so the user still sees the real message.
            if result.stdout:
                console.print(result.stdout, end="")
            if result.stderr:
                console.print(result.stderr, end="")
        else:
            result = subprocess.run(cmd, check=False)
        if result.returncode == 0:
            return True
        console.print(f"  ❌ [red]Install command failed (exit {result.returncode})[/]")
        if is_git_cmd:
            hint = _scan_stderr_for_tls_hint(result.stderr or "")
            if hint:
                console.print(hint)
        return False
    except FileNotFoundError:
        console.print(f"  ❌ [red]Command not found: {cmd[0]}[/]")
        return False


def _needs_sudo():
    """Check if we need sudo for system package installs."""
    import os
    return os.geteuid() != 0


def _sudo_prefix():
    """Return ['sudo'] if needed, else []."""
    return ["sudo"] if _needs_sudo() else []


def _install_ghdl(os_id, pkg_mgr):
    """Install GHDL (≥ 6.0.0 requires building from dev branch)."""
    console.print("\n  📦 [cyan]Installing GHDL[/]")
    console.print("  [dim]GHDL ≥ 6.0.0 requires the dev branch (not yet in distro repos).[/]\n")

    # Check prerequisites
    prereqs = {
        "debian": ["gnat", "gcc", "make", "zlib1g-dev"],
        "fedora": ["gcc-gnat", "gcc", "make", "zlib-devel"],
        "macos": ["gnat", "gcc", "make"],
    }
    if pkg_mgr == "apt":
        console.print("  📥 Installing build prerequisites...")
        _run_install_cmd(
            _sudo_prefix() + ["apt-get", "install", "-y"] + prereqs.get("debian", []),
            "ghdl prerequisites",
        )
    elif pkg_mgr == "brew":
        console.print("  📥 Installing build prerequisites...")
        _run_install_cmd(["brew", "install"] + prereqs.get("macos", []), "ghdl prerequisites")

    # Build from source (dev branch for 6.0.0+)
    build_dir = Path("/tmp/ghdl-build")
    if build_dir.exists():
        shutil.rmtree(build_dir)

    console.print("  📥 Cloning GHDL dev branch...")
    if not _run_install_cmd(
        ["git", "clone", "--depth", "1", "https://github.com/ghdl/ghdl", str(build_dir)],
        "ghdl clone",
    ):
        return False

    console.print("  🔨 Building GHDL (this may take a few minutes)...")
    build_steps = [
        (["mkdir", "-p", str(build_dir / "build")], "create build dir"),
    ]
    for cmd, desc in build_steps:
        if not _run_install_cmd(cmd, desc):
            return False

    # Configure + build + install
    configure_cmd = subprocess.run(
        ["bash", "-c", f"cd {build_dir}/build && ../configure --prefix=/usr/local"],
        check=False,
    )
    if configure_cmd.returncode != 0:
        console.print("  ❌ [red]Configure failed[/]")
        return False

    nproc = subprocess.run(["nproc"], capture_output=True, text=True, check=False)
    jobs = nproc.stdout.strip() if nproc.returncode == 0 else "4"

    make_cmd = subprocess.run(
        ["bash", "-c", f"cd {build_dir}/build && make -j{jobs}"],
        check=False,
    )
    if make_cmd.returncode != 0:
        console.print("  ❌ [red]Build failed[/]")
        return False

    if not _run_install_cmd(
        _sudo_prefix() + ["bash", "-c", f"cd {build_dir}/build && make install"],
        "ghdl install",
    ):
        return False

    return True


def _install_nvc(os_id, pkg_mgr):
    """Install NVC (≥ 1.18.2 — build from source for latest)."""
    console.print("\n  📦 [cyan]Installing NVC[/]")

    # Check if apt has a new enough version (Ubuntu 24.04+ has nvc)
    if pkg_mgr == "apt":
        # Try apt first — if version is new enough, use it
        check = subprocess.run(
            ["apt-cache", "show", "nvc"], capture_output=True, text=True, check=False,
        )
        if check.returncode == 0 and "Version:" in check.stdout:
            import re
            ver_match = re.search(r"Version:\s*(\d+\.\d+\.\d+)", check.stdout)
            if ver_match:
                from sdk.cli.checks._helpers import _ver_tuple
                if _ver_tuple(ver_match.group(1)) >= _ver_tuple("1.18.2"):
                    console.print(f"  ℹ️  apt has NVC {ver_match.group(1)} — using package manager.")
                    return _run_install_cmd(
                        _sudo_prefix() + ["apt-get", "install", "-y", "nvc"], "nvc",
                    )

    if pkg_mgr == "brew":
        console.print("  📥 Installing via Homebrew...")
        return _run_install_cmd(["brew", "install", "nvc"], "nvc")

    # Build from source
    console.print("  [dim]Building from source (apt version too old or unavailable).[/]\n")

    prereqs = {
        "debian": [
            "build-essential", "automake", "autoconf", "flex", "bison",
            "libdw-dev", "libffi-dev", "zlib1g-dev", "pkg-config", "llvm-dev",
        ],
    }
    if pkg_mgr == "apt":
        console.print("  📥 Installing build prerequisites...")
        _run_install_cmd(
            _sudo_prefix() + ["apt-get", "install", "-y"] + prereqs.get("debian", []),
            "nvc prerequisites",
        )

    build_dir = Path("/tmp/nvc-build")
    if build_dir.exists():
        shutil.rmtree(build_dir)

    console.print("  📥 Cloning NVC...")
    if not _run_install_cmd(
        ["git", "clone", "--depth", "1", "--branch", "r1.18.2",
         "https://github.com/nickg/nvc", str(build_dir)],
        "nvc clone",
    ):
        return False

    console.print("  🔨 Building NVC (this may take a few minutes)...")

    nproc = subprocess.run(["nproc"], capture_output=True, text=True, check=False)
    jobs = nproc.stdout.strip() if nproc.returncode == 0 else "4"

    build_cmds = f"""
cd {build_dir} && \
./autogen.sh && \
mkdir -p build && cd build && \
../configure --prefix=/usr/local && \
make -j{jobs}
"""
    result = subprocess.run(["bash", "-c", build_cmds], check=False)
    if result.returncode != 0:
        console.print("  ❌ [red]Build failed[/]")
        return False

    if not _run_install_cmd(
        _sudo_prefix() + ["bash", "-c", f"cd {build_dir}/build && make install"],
        "nvc install",
    ):
        return False

    return True


def _install_verilator(os_id, pkg_mgr):
    """Install Verilator 5.036 (always from source — apt version too old for cocotb 2.0+)."""
    console.print("\n  📦 [cyan]Installing Verilator[/]")
    console.print("  [dim]Cocotb 2.0+ requires Verilator 5.x — building from source.[/]\n")

    if pkg_mgr == "brew":
        console.print("  📥 Installing via Homebrew...")
        return _run_install_cmd(["brew", "install", "verilator"], "verilator")

    # Remove old apt verilator if present
    if pkg_mgr == "apt":
        _run_install_cmd(
            _sudo_prefix() + ["apt-get", "remove", "-y", "verilator"],
            "remove old verilator",
        )

        prereqs = [
            "git", "help2man", "perl", "python3", "make", "autoconf",
            "g++", "flex", "bison", "ccache", "libgoogle-perftools-dev",
            "numactl", "perl-doc", "libfl-dev", "zlib1g", "zlib1g-dev",
        ]
        console.print("  📥 Installing build prerequisites...")
        _run_install_cmd(
            _sudo_prefix() + ["apt-get", "install", "-y"] + prereqs,
            "verilator prerequisites",
        )

    build_dir = Path("/tmp/verilator-build")
    if build_dir.exists():
        shutil.rmtree(build_dir)

    console.print("  📥 Cloning Verilator v5.036...")
    if not _run_install_cmd(
        ["git", "clone", "--depth", "1", "--branch", "v5.036",
         "https://github.com/verilator/verilator", str(build_dir)],
        "verilator clone",
    ):
        return False

    console.print("  🔨 Building Verilator (this may take a few minutes)...")

    nproc = subprocess.run(["nproc"], capture_output=True, text=True, check=False)
    jobs = nproc.stdout.strip() if nproc.returncode == 0 else "4"

    build_cmds = f"""
cd {build_dir} && \
unset VERILATOR_ROOT && \
autoconf && \
./configure && \
make -j{jobs}
"""
    result = subprocess.run(["bash", "-c", build_cmds], check=False)
    if result.returncode != 0:
        console.print("  ❌ [red]Build failed[/]")
        return False

    if not _run_install_cmd(
        _sudo_prefix() + ["bash", "-c", f"cd {build_dir} && make install"],
        "verilator install",
    ):
        return False

    return True


def _install_icarus(os_id, pkg_mgr):
    """Install Icarus Verilog."""
    console.print("\n  📦 [cyan]Installing Icarus Verilog[/]")

    if pkg_mgr == "apt":
        return _run_install_cmd(
            _sudo_prefix() + ["apt-get", "install", "-y", "iverilog"],
            "icarus verilog",
        )
    if pkg_mgr == "brew":
        return _run_install_cmd(["brew", "install", "icarus-verilog"], "icarus verilog")
    if pkg_mgr == "dnf":
        return _run_install_cmd(
            _sudo_prefix() + ["dnf", "install", "-y", "iverilog"],
            "icarus verilog",
        )
    if pkg_mgr == "pacman":
        return _run_install_cmd(
            _sudo_prefix() + ["pacman", "-S", "--noconfirm", "iverilog"],
            "icarus verilog",
        )

    console.print("  ❌ [red]No supported package manager found.[/]")
    console.print("  [dim]Install manually: https://github.com/steveicarus/iverilog[/]")
    return False


_INSTALLER_MAP = {
    "ghdl": _install_ghdl,
    "nvc": _install_nvc,
    "verilator": _install_verilator,
    "icarus": _install_icarus,
}

_TOOL_NAMES = list(_INSTALLER_MAP.keys())


def _install_dev_python_deps() -> int:
    """RTL-P3.142: pip-install the Python packages the pre-commit hook
    transitively depends on (ruff, pytest, cocotb stack, …).

    Sources the package list from ``ci/requirements-fast.txt`` and
    ``ci/requirements-sim.txt`` in the SDK tree — those files are the
    single source of truth for PR CI (``.github/workflows/ci.yml``),
    so `rr eda install --dev` installs exactly what CI installs and
    stays in sync without a separate hard-coded list.  When the SDK
    is running from a PyPI wheel (no ci/ tree available) the command
    falls back to an inline list covering the same packages.

    Returns 0 on success, non-zero when every pip install attempt fails.
    """
    from sdk.cli.sdk_root import resolve_sdk_root

    sdk_root = resolve_sdk_root()
    candidates = []
    if sdk_root:
        for name in ("requirements-fast.txt", "requirements-sim.txt"):
            p = Path(sdk_root) / "ci" / name
            if p.is_file():
                candidates.append(p)

    console.print("\n🐍 [cyan]Installing pre-commit hook Python dependencies[/]\n")

    if candidates:
        rc = 0
        for req_path in candidates:
            console.print(f"  [dim]pip install -r {req_path}[/]")
            result = subprocess.run(
                [sys.executable, "-m", "pip", "install", "-r", str(req_path)],
                check=False,
            )
            if result.returncode != 0:
                console.print(f"  ❌ [red]pip install failed for {req_path.name}[/]")
                rc = result.returncode
        if rc == 0:
            console.print(
                "\n  ✅ [green]Dev dependencies installed from CI "
                "requirements files.[/]\n"
            )
        return rc

    # Fallback: SDK shipped without ci/ (PyPI wheel path).  Keep this
    # list in sync with ci/requirements-*.txt — the pre-commit hook's
    # transitive needs.
    fallback_packages = [
        # fast / PR-tier checks
        "pyyaml", "pytest", "click", "rich", "rich-click",
        "ruff", "docker", "jinja2", "pathspec",
        # cocotb sim-tier
        "cocotb", "cocotb-bus", "cocotb-test", "cocotbext-axi",
        "numpy", "scipy", "matplotlib",
    ]
    console.print(
        f"  [dim]ci/ not found — falling back to inline list "
        f"({len(fallback_packages)} packages)[/]"
    )
    console.print(f"  [dim]pip install {' '.join(fallback_packages)}[/]")
    result = subprocess.run(
        [sys.executable, "-m", "pip", "install", *fallback_packages],
        check=False,
    )
    if result.returncode == 0:
        console.print("\n  ✅ [green]Dev dependencies installed.[/]\n")
    else:
        console.print("\n  ❌ [red]pip install failed.[/]")
    return result.returncode


@eda_group.command(name="install")
@click.argument("tool", required=False, type=click.Choice(_TOOL_NAMES, case_sensitive=False))
@click.option("--all", "install_all", is_flag=True, help="Install all open-source simulators.")
@click.option(
    "--dev",
    "install_dev",
    is_flag=True,
    help="Install Python dev dependencies the pre-commit hook expects "
         "(ruff / pytest / pyyaml / rich-click / docker / jinja2 / "
         "pathspec / click + the cocotb regression stack: cocotb, "
         "cocotb-bus, cocotb-test, cocotbext-axi, numpy, scipy, "
         "matplotlib).  RTL-P3.142 — stops a fresh venv from making "
         "`rr` commit commands fail at the first hook stage.",
)
def eda_install(tool, install_all, install_dev):
    """Install open-source simulation tools (GHDL, NVC, Verilator, Icarus).

    Detects the OS and package manager, then installs the requested tool
    using apt/brew/dnf or builds from source when the packaged version is
    too old.

    \b
    Examples:
        rr eda install verilator    # Install Verilator 5.036 from source
        rr eda install ghdl         # Install GHDL 6.0+ from dev branch
        rr eda install nvc          # Install NVC ≥ 1.18.2
        rr eda install icarus       # Install Icarus Verilog via apt/brew
        rr eda install --all        # Install all four simulators
        rr eda install --dev        # pip-install pre-commit hook deps
    """
    from sdk.cli.eda_helpers import load_sdk_requirements

    # RTL-P3.142: --dev tier runs first so it composes cleanly with
    # `rr eda install --all --dev` (install the simulators *and* the
    # Python toolchain the hook needs in one shot on a fresh box).
    if install_dev:
        rc = _install_dev_python_deps()
        if rc != 0:
            sys.exit(rc)
        if not tool and not install_all:
            return

    if not tool and not install_all:
        # Show available tools with current status
        reqs = load_sdk_requirements().get("tools", {})
        console.print("\n🔧 [cyan]Available simulators:[/]\n")
        for name in _TOOL_NAMES:
            spec = reqs.get(name, {})
            cmd_parts = spec.get("check_cmd", "").split()
            binary = cmd_parts[0] if cmd_parts else name
            installed = shutil.which(binary)
            min_v = spec.get("min_version", "any")
            status = "[green]✅ installed[/]" if installed else "[red]❌ not found[/]"
            console.print(f"  {name:<12} {status}  [dim](min: {min_v})[/]")
        console.print(
            "\n  [dim]Usage: rr eda install <tool>  or  rr eda install --all[/]\n"
        )
        return

    os_id, pkg_mgr = _detect_platform()
    console.print(f"\n🔧 [cyan]EDA Simulator Installer[/]  [dim]({os_id}, {pkg_mgr or 'no pkg mgr'})[/]")

    if not pkg_mgr and os_id != "unknown":
        console.print("  ⚠️  [yellow]No supported package manager detected.[/]")

    tools_to_install = _TOOL_NAMES if install_all else [tool]
    success_count = 0
    fail_count = 0

    for t in tools_to_install:
        installer = _INSTALLER_MAP[t]
        ok = installer(os_id, pkg_mgr)
        if ok:
            # Verify installation
            reqs = load_sdk_requirements().get("tools", {})
            spec = reqs.get(t, {})
            cmd_parts = spec.get("check_cmd", "").split()
            binary = cmd_parts[0] if cmd_parts else t
            path = shutil.which(binary)
            if path:
                console.print(f"  ✅ [green]{t} installed successfully[/] ({path})")
                success_count += 1
            else:
                console.print(f"  ⚠️  [yellow]{t} install completed but binary not on PATH[/]")
                console.print("  [dim]You may need to restart your shell or update PATH.[/]")
                fail_count += 1
        else:
            fail_count += 1

    console.print()
    if fail_count == 0:
        console.print(f"  ✅ [green]All {success_count} tool(s) installed successfully.[/]")
    else:
        console.print(
            f"  [yellow]{success_count} succeeded, {fail_count} failed.[/]\n"
            f"  [dim]Re-run with verbose output or check prerequisites above.[/]"
        )
        sys.exit(1)
    console.print()
