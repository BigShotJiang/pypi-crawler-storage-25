# SPDX-FileCopyrightText: 2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""CLI command group: pkg — IP package management (Cargo-style for FPGAs)."""

from __future__ import annotations

import os
import re
import sys
from pathlib import Path

import rich_click as click
from rich.table import Table

from sdk.cli.console import console
from sdk.cli.resilience import cli_resilient, cli_resilient_block


@cli_resilient("CLI name resolution", default="routertl")
def _cli_name():
    from sdk.cli.main import CLI_NAME
    return CLI_NAME


# RTL-P2.427: shell-completion callbacks for pkg subcommands.
# Each one must be crash-safe — a raised exception silently breaks TAB
# completion with no way to surface the error, so we wrap in broad
# try/except and return [] on any failure.


@cli_resilient("rr pkg installed completion", default=[])
def _complete_installed_pkg(ctx, param, incomplete):
    """Completion for rr pkg {remove,update,why} PACKAGE_REF.

    Reads project.yml → packages: keys for the active target — i.e.
    packages the user has actually installed, not the whole registry.
    Hitting the registry here would slow remove/update TAB for no
    benefit (users only remove what they already have).
    """
    from sdk.cli.project_config import load_project_config
    cfg = load_project_config() if Path("project.yml").exists() else {}
    pkgs = cfg.get("packages") if isinstance(cfg, dict) else None
    if not isinstance(pkgs, dict):
        return []
    return sorted(
        name for name in pkgs
        if isinstance(name, str) and name.startswith(incomplete)
    )


@cli_resilient("rr pkg registry completion", default=[])
def _complete_registry_pkg(ctx, param, incomplete):
    """Completion for rr pkg {info,add} PACKAGE_REF.

    Registry lookup with a 1-hour cache (RTL-P2.427 Tier 3).  On cache
    miss we try a fresh fetch with a 300 ms budget; if that fails or
    times out we fall back to stale cache, then to the installed-
    packages list.  Completion is a hot path, so "never block" beats
    "always fresh".
    """
    from sdk.cli import completion_cache

    entries = completion_cache.get("pkg_index")
    if entries is None:
        entries = _fetch_registry_pkg_index(timeout=0.3)
        if entries:
            completion_cache.set_entries("pkg_index", entries)
        else:
            # Fresh fetch failed → try stale, then installed.
            entries = (
                completion_cache.get_stale("pkg_index")
                or _installed_packages()
            )
    return sorted(
        e for e in (entries or [])
        if isinstance(e, str) and e.startswith(incomplete)
    )


@cli_resilient("registry pkg index fetch for completion", default=None)
def _fetch_registry_pkg_index(*, timeout: float):
    """Fetch the list of registered package refs from the index.

    Uses index_client's catalog accessor — honours whatever the CLI is
    currently pointed at.  Times out at *timeout* seconds.
    """
    import socket
    # socket.setdefaulttimeout covers urllib / requests internal socket
    # operations; the caller restores the original after.
    prev = socket.getdefaulttimeout()
    socket.setdefaulttimeout(timeout)
    try:
        from sdk.engine import index_client
        catalog = index_client.load_catalog(refresh=False)
        if not isinstance(catalog, dict):
            return None
        entries = catalog.get("entries") or catalog.get("packages") or {}
        if isinstance(entries, dict):
            return sorted(str(k) for k in entries.keys())
        if isinstance(entries, list):
            out: list[str] = []
            for e in entries:
                if isinstance(e, dict):
                    ns = e.get("namespace", "")
                    nm = e.get("name", "")
                    if ns and nm:
                        out.append(f"{ns}/{nm}")
                elif isinstance(e, str):
                    out.append(e)
            return sorted(out)
        return None
    finally:
        socket.setdefaulttimeout(prev)


@cli_resilient("installed packages lookup for completion", default=[])
def _installed_packages() -> list[str]:
    """Last-resort fallback for registry completion — list from
    project.yml's packages keys."""
    from sdk.cli.project_config import load_project_config
    cfg = load_project_config() if Path("project.yml").exists() else {}
    pkgs = cfg.get("packages") if isinstance(cfg, dict) else None
    if isinstance(pkgs, dict):
        return sorted(k for k in pkgs if isinstance(k, str))
    return []


def _resolve_commit_constraint(
    package_ref: str,
    commit_spec: str,
    catalog,
) -> str | None:
    """Normalise a ``--commit`` argument into a ``commit:<40-hex>`` constraint.

    RTL-P1.47.  Returns the constraint string on success, or None after
    printing a user-facing error (caller should ``sys.exit(1)``).

    Accepts:
      * 40-character lowercase hex SHA — returned as-is.
      * Literal ``HEAD`` — resolved via ``git ls-remote <url> HEAD`` to
        the current upstream tip.  The resolved SHA is pinned; there is
        no ongoing tracking.

    Rejects short SHAs — the user should paste the full SHA or use HEAD.
    Expanding a short SHA would require a full clone, which is what the
    caller is about to do anyway; a clear error beats a hidden clone.
    """
    from sdk.engine.package_resolver import (
        _catalog_source_url,
        is_full_sha,
        resolve_head_sha,
    )

    namespace, name = package_ref.split("/", 1)
    spec = (commit_spec or "").strip()

    if spec.upper() == "HEAD":
        source_url = _catalog_source_url(catalog, namespace, name)
        if not source_url:
            console.print(
                f"❌ [red]Cannot resolve HEAD for '{package_ref}': "
                f"package is not in the index catalog.[/]\n"
                f"   Run: [cyan]{_cli_name()} pkg search {name}[/]"
            )
            return None
        try:
            sha = resolve_head_sha(source_url)
        except RuntimeError as exc:
            console.print(
                f"❌ [red]Could not resolve HEAD of {source_url}:[/]\n"
                f"   {exc}"
            )
            return None
        console.print(
            f"   [dim]Resolved HEAD → {sha[:12]} (pinned; not tracked)[/]"
        )
        return f"commit:{sha}"

    spec_lower = spec.lower()
    if is_full_sha(spec_lower):
        return f"commit:{spec_lower}"

    # Short or malformed SHA
    if len(spec) < 40 and all(c in "0123456789abcdefABCDEF" for c in spec):
        console.print(
            f"❌ [red]Short SHA '{spec}' is not supported.[/]\n"
            f"   [dim]Paste the full 40-character SHA, or pass --commit HEAD "
            f"to snapshot the upstream tip.[/]"
        )
    else:
        console.print(
            f"❌ [red]'{spec}' is not a valid commit spec.[/]\n"
            f"   [dim]Expected a 40-character hex SHA or the literal 'HEAD'.[/]"
        )
    return None


def _catalog_lookup(catalog, namespace: str, name: str):
    """Classify a namespace/name lookup in the catalog.

    Returns (state, latest):
      ("ok", "<version>")    — entry found with a resolved latest version
      ("unversioned", None)  — entry found but upstream has no git tags
      ("missing", None)      — entry not in catalog
    """
    for entry in catalog:
        if entry.get("namespace") == namespace and entry.get("name") == name:
            latest = entry.get("latest")
            if latest:
                return ("ok", latest)
            return ("unversioned", None)
    return ("missing", None)


def _unversioned_error_msg(package_ref: str) -> str:
    cli = _cli_name()
    return (
        f"❌ [red]Package '{package_ref}' has no resolved versions.[/]\n"
        f"   [dim]It exists in the catalog but the upstream repo has no git tags, "
        f"so no version can be pinned.[/]\n"
        f"   [dim]Pin an exact commit instead:[/]\n"
        f"     [cyan]{cli} pkg add {package_ref} --commit <40-hex-sha>[/]\n"
        f"     [cyan]{cli} pkg add {package_ref} --commit HEAD[/]  [dim](snapshot upstream main now)[/]"
    )


_BADGE_ICONS = {
    "linted": "[green]\u2705 Linted[/]",
    "simulated": "[green]\u2705\u2705 Simulated[/]",
    "tested": "[green]\U0001f9ea Tested[/]",
    "unlinted": "[dim]\u26a0  Unlinted[/]",
}


def _fetch_verification_badges(index_url: str, results: list[dict]) -> dict[str, str]:
    """Fetch verification badges from the registry search API. Returns {pkg_ref: badge_str}."""
    import json as _json
    from urllib.error import URLError
    from urllib.request import Request, urlopen

    from sdk.engine.registry_auth import get_auth_headers

    badges = {}
    if not index_url or "registry" not in index_url:
        return badges  # not a registry URL, no badges

    for entry in results:
        ns = entry.get("namespace", "")
        name = entry.get("name", "")
        ver = entry.get("latest", "")
        if not ver:
            continue
        try:
            url = f"{index_url}/v1/verify/{ns}/{name}/{ver}"
            headers = get_auth_headers()
            req = Request(url, headers=headers) if headers else url
            with urlopen(req, timeout=5) as resp:
                data = _json.loads(resp.read().decode())
            badge_key = data.get("badge", "unlinted")
            badges[f"{ns}/{name}"] = _BADGE_ICONS.get(badge_key, "")
        except (URLError, OSError, ValueError, KeyError):
            pass
    return badges


def _fetch_verification_detail(index_url: str, namespace: str, name: str, version: str) -> dict | None:
    """Fetch full verification detail for a specific package version."""
    import json as _json
    from urllib.error import URLError
    from urllib.request import Request, urlopen

    from sdk.engine.registry_auth import get_auth_headers

    if not index_url or "registry" not in index_url:
        return None

    try:
        url = f"{index_url}/v1/verify/{namespace}/{name}/{version}"
        headers = get_auth_headers()
        req = Request(url, headers=headers) if headers else url
        with urlopen(req, timeout=10) as resp:
            return _json.loads(resp.read().decode())
    except (URLError, OSError, ValueError, KeyError):
        return None


def _resolve_library_to_package(library_name: str, index_url: str) -> str | None:
    """Query the registry to find which package provides a VHDL library.

    Returns 'namespace/name' or None if not found.
    """
    import json as _json
    from urllib.error import URLError
    from urllib.request import Request, urlopen

    from sdk.engine.registry_auth import get_auth_headers

    try:
        url = f"{index_url}/v1/resolve-library?name={library_name}"
        headers = get_auth_headers()
        req = Request(url, headers=headers) if headers else url
        with urlopen(req, timeout=10) as resp:
            results = _json.loads(resp.read().decode())
        if results:
            return results[0]["package"]
    except (URLError, OSError, ValueError, KeyError):
        pass
    return None


def _auto_resolve_library_deps(missing_libs, catalog, config, index_url, cache_dir):
    """Auto-install packages that provide missing VHDL libraries."""
    from sdk.cli.project_config import load_project_config
    from sdk.engine.package_resolver import resolve_packages

    for lib in missing_libs:
        pkg_ref = _resolve_library_to_package(lib, index_url)
        if not pkg_ref:
            console.print(f"  [yellow]⚠️  No package found for library '{lib}'[/]")
            continue

        console.print(f"  [cyan]📦 Auto-installing {pkg_ref} (provides {lib})[/]")

        # Find latest version from catalog
        namespace, name = pkg_ref.split("/", 1)
        latest = None
        for entry in catalog:
            if entry.get("namespace") == namespace and entry.get("name") == name:
                latest = entry.get("latest")
                break
        if not latest:
            console.print(f"  [yellow]⚠️  Could not resolve version for {pkg_ref}[/]")
            continue

        _add_package_to_project_yml(pkg_ref, f"^{latest}")

    # Re-resolve all packages (including new deps)
    config = load_project_config()
    try:
        resolve_packages(config, Path.cwd())
    except (RuntimeError, ValueError, OSError) as exc:
        console.print(f"  [yellow]⚠️  Dep resolution failed: {exc}[/]")


def _group_by_library_from_lock(root: Path) -> dict[str, list[str]]:
    """Rebuild lib_files from the current lock file."""
    from sdk.engine.package_resolver import _group_by_library, load_lock
    return _group_by_library(load_lock(root), root)


@click.group(name="pkg", invoke_without_command=True)
@click.pass_context
def pkg_group(ctx):
    """IP package manager — add, install, and search FPGA IP cores.

    \b
    Install & update
        install     Install all packages declared in project.yml
        add         Add a package dependency to project.yml
        update      Update packages to latest compatible versions
        remove      Uninstall a package (project.yml + ip.lock + libs/)
        list        Show installed packages

    \b
    Discover & inspect
        search      Search the IP index catalog
        info        Show full metadata for a package
        outdated    List packages with newer versions available
        why         Explain why a package is installed (provenance)

    \b
    Maintain & gate
        audit       Audit ip.lock for policy violations + regressions (CI)
        verify      Verify installed package integrity (hashes vs ip.lock)
        test        Run a package's tests in their native framework

    \b
    Contribute & auth
        publish     Publish a package to a registry namespace
        register    Create an account on the registry
        login       Authenticate with the registry
        logout      Remove stored registry credentials

    \b
    Admin
        orphans     List catalog entries with no curated_repos.json backing
        backfill-deps  Backfill library_deps across the registry
    """
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


# ── install ────────────────────────────────────────────────────────────────────


@pkg_group.command(name="install")
@click.option("--force", is_flag=True, help="Re-clone even if already present.")
def pkg_install(force):
    """Install all packages declared in project.yml.

    Resolves semver constraints against the index, clones each IP at the
    pinned git tag, and writes ip.lock.

    \b
    Examples:
        rr pkg install
        rr pkg install --force
    """
    _require_project_yml()

    from sdk.cli.project_config import load_project_config
    from sdk.engine.package_resolver import resolve_packages

    config = load_project_config()
    packages = config.get("packages") or {}

    if not packages:
        console.print("  [dim]No packages declared in project.yml — nothing to install.[/]")
        return

    console.print(f"\n📦 [cyan]Installing {len(packages)} package(s)...[/]\n")

    try:
        lib_files = resolve_packages(config, Path.cwd(), force=force)
    except (RuntimeError, ValueError, OSError) as exc:
        console.print(f"❌ [red]{exc}[/]")
        sys.exit(1)

    from sdk.engine.package_resolver import write_libraries_cache
    write_libraries_cache(lib_files, Path.cwd())

    total = sum(len(f) for f in lib_files.values())
    console.print(
        f"\n✅ [green]Done.[/] {len(lib_files)} librar{'ies' if len(lib_files) != 1 else 'y'}, "
        f"{total} source file(s) resolved. [dim]See ip.lock for details.[/]"
    )


# ── add ────────────────────────────────────────────────────────────────────────


@pkg_group.command(name="add")
@click.argument("package_ref", required=False, default=None,
                shell_complete=_complete_registry_pkg)
@click.option("--version", "-v", default=None, help="Version constraint (default: ^latest).")
@click.option("--commit", "-c", "commit_spec", default=None,
              help="Pin to an exact commit: 40-hex SHA or 'HEAD' to snapshot "
                   "upstream main at add-time.  Use for repos without git tags.")
@click.option("--local", "-l", "local_path", default=None, type=click.Path(exists=True, file_okay=False),
              help="Path to a local repository directory to add as a package.")
@click.option("--name", "-n", "entity_name", default=None, help="Entity name to install from a local repo.")
@click.option("--strict", "strict", is_flag=True, default=False,
              help="Refuse the auto-HEAD snapshot fallback for tag-less "
                   "repos (RTL-P2.378).  Semver-only shops use this to "
                   "enforce the pre-P1.47 behaviour.")
def pkg_add(package_ref, version, commit_spec, local_path, entity_name, strict):
    """Add a package dependency to project.yml and install it.

    PACKAGE_REF format: namespace/name  (e.g. open-logic/olo_base_fifo_async)

    \b
    Use --commit to pin a repo that has no git tags (RTL-P1.47):
        rr pkg add pulp-platform/stream_mux --commit 8a3f9e2abc...
        rr pkg add fpganinja/taxi_axis_mux --commit HEAD

    \b
    Use --local to add a package from a local directory instead of the registry:
        rr pkg add --local /path/to/repo              # list discovered entities
        rr pkg add --local /path/to/repo --name my_ip # install a specific entity

    \b
    Examples:
        rr pkg add open-logic/olo_base_fifo_async
        rr pkg add open-logic/olo_base_cdc_sync --version "^2.5.0"
        rr pkg add --local ../my-ip-repo
        rr pkg add --local ../my-ip-repo --name uart_rx
    """
    # ── Mutual-exclusion guards ──────────────────────────────────────────
    if commit_spec is not None and version is not None:
        console.print(
            "❌ [red]--commit and --version are mutually exclusive.[/]\n"
            "   [dim]--commit pins an exact SHA; --version resolves a semver tag.[/]"
        )
        sys.exit(1)
    if commit_spec is not None and local_path is not None:
        console.print(
            "❌ [red]--commit and --local are mutually exclusive.[/]\n"
            "   [dim]--local installs from a path on disk; --commit fetches "
            "from the registry URL at a pinned SHA.[/]"
        )
        sys.exit(1)

    # ── Local repo path ──────────────────────────────────────────────────
    if local_path is not None:
        _require_project_yml()
        _pkg_add_local(Path(local_path).resolve(), entity_name)
        return

    # ── Registry path (original behaviour) ───────────────────────────────
    if package_ref is None:
        console.print(
            "❌ [red]Missing PACKAGE_REF argument.[/]\n"
            f"   Usage: [cyan]{_cli_name()} pkg add <namespace>/<name>[/]\n"
            f"   Or:    [cyan]{_cli_name()} pkg add --local <path>[/]"
        )
        sys.exit(1)

    _require_project_yml()

    from sdk.cli.project_config import load_project_config
    from sdk.engine.index_client import fetch_catalog, get_index_url
    from sdk.engine.package_resolver import resolve_packages

    if "/" not in package_ref:
        console.print(
            f"❌ [red]Invalid package reference '{package_ref}'. "
            "Expected: namespace/name[/]"
        )
        sys.exit(1)

    namespace, name = package_ref.split("/", 1)

    # Short-circuit: SDK builtin packages (routertl/*)
    if namespace == "routertl":
        from sdk.engine.package_resolver import install_builtin_package

        lock_entry = install_builtin_package(name, Path.cwd())
        if lock_entry is None:
            console.print(
                f"❌ [red]SDK unit '{name}' not found.[/]\n"
                f"   Run: [cyan]{_cli_name()} pkg search routertl[/]"
            )
            sys.exit(1)

        _add_package_to_project_yml(package_ref, "local")
        console.print(f"  [green]+[/] [cyan]{package_ref}[/] [dim](SDK builtin)[/]")

        # Write lock entry
        from sdk.engine.package_resolver import load_lock, write_lock
        resolved = load_lock(Path.cwd())
        resolved[package_ref] = lock_entry
        write_lock(resolved, Path.cwd())

        # Regenerate build_env.mk so SRC_DIR includes libs/
        with cli_resilient_block("build_env.mk regeneration after pkg add"):
            from sdk.cli.engine_dispatch import ScriptNotFound, run_engine_script
            try:
                run_engine_script("project_manager.py", ["project.yml"])
            except ScriptNotFound:
                pass

        console.print(f"✅ [green]Added {package_ref} (SDK builtin)[/]")
        return

    config = load_project_config()
    index_url = get_index_url(config)
    cache_dir = Path(".routertl_cache/index")

    # Resolve latest version if not specified
    try:
        catalog = fetch_catalog(index_url, cache_dir)
    except (RuntimeError, ValueError, OSError) as exc:
        console.print(f"❌ [red]Could not reach index: {exc}[/]")
        sys.exit(1)

    # RTL-P1.47: --commit pins an exact SHA and writes ``commit:<sha>``
    # into project.yml so the resolver bypasses version lookup.
    if commit_spec is not None:
        constraint = _resolve_commit_constraint(package_ref, commit_spec, catalog)
        if constraint is None:
            sys.exit(1)
        _add_package_to_project_yml(package_ref, constraint)
        console.print(f"  [green]+[/] [cyan]{package_ref}[/] [dim]{constraint}[/]")
    else:
        auto_head_snapshot = False
        if version is None:
            state, latest = _catalog_lookup(catalog, namespace, name)
            if state == "missing":
                console.print(
                    f"❌ [red]Package '{package_ref}' not found in index.[/]\n"
                    f"   Run: [cyan]{_cli_name()} pkg search {name}[/]"
                )
                sys.exit(1)
            if state == "unversioned":
                # RTL-P2.378: auto-HEAD snapshot by default — dogfooding
                # P1.47 on tag-less repos (PULP, fpganinja/taxi, academic
                # repos) showed the two-step dance was pure friction.
                # --strict reinstates the pre-P2.378 error for semver-only
                # shops that don't want an implicit HEAD snapshot.
                if strict:
                    console.print(_unversioned_error_msg(package_ref))
                    sys.exit(1)
                constraint = _resolve_commit_constraint(
                    package_ref, "HEAD", catalog,
                )
                if constraint is None:
                    sys.exit(1)
                _add_package_to_project_yml(package_ref, constraint)
                console.print(
                    f"  [green]+[/] [cyan]{package_ref}[/] "
                    f"[dim]{constraint}[/]"
                )
                console.print(
                    "  [dim]No tags found on upstream — snapshotted "
                    "HEAD.  Pass [cyan]--strict[/] to disable this "
                    "fallback.[/]"
                )
                auto_head_snapshot = True
            else:
                version = f"^{latest}"
        elif not version.startswith(("^", "~")):
            version = f"^{version}"

        if not auto_head_snapshot:
            # Update project.yml with the resolved semver constraint.
            _add_package_to_project_yml(package_ref, version)
            console.print(
                f"  [green]+[/] [cyan]{package_ref}[/] [dim]{version}[/]"
            )

    # Regenerate build_env.mk so SRC_DIR includes libs/
    with cli_resilient_block("build_env.mk regeneration after pkg add"):
        from sdk.cli.engine_dispatch import ScriptNotFound, run_engine_script
        try:
            run_engine_script("project_manager.py", ["project.yml"])
        except ScriptNotFound:
            pass

    # Install
    config = load_project_config()
    try:
        lib_files = resolve_packages(config, Path.cwd())
    except (RuntimeError, ValueError, OSError) as exc:
        console.print(f"❌ [red]{exc}[/]")
        sys.exit(1)

    from sdk.engine.package_resolver import load_lock, write_libraries_cache
    write_libraries_cache(lib_files, Path.cwd())

    # P2.250: Auto-resolve VHDL library deps
    lock = load_lock(Path.cwd())
    lock_entry = lock.get(package_ref, {})
    lib_deps = lock_entry.get("library_deps", [])
    installed_libs = {e.get("library", "work") for e in lock.values() if isinstance(e, dict)}

    missing_libs = [lib for lib in lib_deps if lib not in installed_libs]
    if missing_libs:
        _auto_resolve_library_deps(missing_libs, catalog, config, index_url, cache_dir)
        # Refresh lib_files after installing deps
        lib_files = _group_by_library_from_lock(Path.cwd())
        write_libraries_cache(lib_files, Path.cwd())

    console.print(f"✅ [green]Added {package_ref}[/]")

    # Post-install lint check
    _post_install_lint(package_ref, lib_files)


def _post_install_lint(package_ref: str, lib_files: dict[str, list[str]] | None = None) -> None:
    """Run a quick lint check on newly installed package files.

    Shows a progress bar instead of verbose linter output. Result is a
    one-liner: pass/warn/fail. Full log written to sim/lint_pkg.log.
    """
    import shutil
    import tempfile

    from rich.progress import BarColumn, Progress, SpinnerColumn, TextColumn

    # Collect files to lint — from lib_files or from the lock entry
    files_to_check: list[str] = []
    known_library_deps: list[str] = []
    pkg_library: str = "work"  # VHDL library this package compiles into
    if lib_files:
        for lib_name, file_list in lib_files.items():
            files_to_check.extend(file_list)
            pkg_library = lib_name  # Last one wins (usually only one for a single pkg)
    if not files_to_check:
        # Try to get files from the lock entry
        with cli_resilient_block("load lock for post-install lint"):
            from sdk.engine.package_resolver import load_lock
            lock = load_lock(Path.cwd())
            entry = lock.get(package_ref, {})
            files_to_check = entry.get("files", [])
            known_library_deps = entry.get("library_deps", [])
            pkg_library = entry.get("library", "work")

    if not files_to_check:
        return

    # Classify files
    root = Path.cwd()
    vhdl_files = [f for f in files_to_check if Path(f).suffix.lower() in (".vhd", ".vhdl")]
    sv_files = [f for f in files_to_check if Path(f).suffix.lower() in (".v", ".sv")]
    total = len(vhdl_files) + len(sv_files)

    if total == 0:
        return

    has_ghdl = shutil.which("ghdl") is not None
    has_verilator = shutil.which("verilator") is not None

    if not has_ghdl and not has_verilator:
        return  # No linters available — skip silently

    # Run lint with progress bar
    log_dir = root / "sim"
    log_dir.mkdir(exist_ok=True)
    log_path = log_dir / "lint_pkg.log"

    status = "PASS"
    checked = 0
    warnings = False

    with open(log_path, "w") as log_handle, \
         Progress(
             SpinnerColumn(),
             TextColumn("[bold cyan]Checking"),
             BarColumn(bar_width=20),
             TextColumn("{task.completed}/{task.total} files"),
             console=console,
             transient=True,
         ) as progress:
        task = progress.add_task("lint", total=total)

        # VHDL lint via GHDL
        # P2.248: Use registry-provided library_deps when available,
        # fall back to file scanning (P2.246) for old packages.
        _skip_vhdl = False
        _ext_libs: set[str] = set()
        if vhdl_files and has_ghdl:
            if known_library_deps:
                # Registry knows the deps — trust it
                _ext_libs = set(known_library_deps)
            else:
                # Legacy fallback: scan files for library declarations
                import re
                _ieee_std = {"ieee", "std"}
                _lib_re = re.compile(r"^\s*library\s+(\w+)\s*;", re.IGNORECASE)
                _ctx_re = re.compile(r"^\s*context\s+(\w+)\.(\w+)\s*;", re.IGNORECASE)
                for vf in vhdl_files:
                    abs_path = str(root / vf) if not Path(vf).is_absolute() else vf
                    try:
                        with open(abs_path, encoding="utf-8", errors="replace") as fh:
                            for line in fh:
                                m = _lib_re.match(line)
                                if m and m.group(1).lower() not in _ieee_std | {"work"}:
                                    _ext_libs.add(m.group(1))
                                m = _ctx_re.match(line)
                                if m and m.group(1).lower() not in _ieee_std:
                                    _ext_libs.add(f"{m.group(1)}.{m.group(2)}")
                    except OSError:
                        pass

            # P2.250: Check if dep libraries are installed locally
            if _ext_libs:
                from sdk.engine.lib_cache import read_libraries_cache
                lib_cache_path = root / ".routertl_cache" / "libraries.json"
                local_libs = read_libraries_cache(lib_cache_path) if lib_cache_path.exists() else {}
                # Strip context refs (e.g. "vunit_lib.com_context" → "vunit_lib")
                # Exclude "work" — it's the implicit default GHDL library
                _lib_names = {lib.split(".")[0] for lib in _ext_libs} - {"work"}
                _resolved_libs = {lib for lib in _lib_names if lib in local_libs}
                _missing_libs = _lib_names - _resolved_libs

                if _missing_libs:
                    _skip_vhdl = True
                else:
                    _skip_vhdl = False  # All deps available — compile with -P

        if vhdl_files and has_ghdl and not _skip_vhdl:
            import subprocess
            with tempfile.TemporaryDirectory() as workdir:
                # P2.250: Pre-compile dep libraries into workdir
                if _ext_libs and local_libs:
                    _lib_names = {lib.split(".")[0] for lib in _ext_libs}
                    for dep_lib in sorted(_lib_names):
                        dep_files = local_libs.get(dep_lib, [])
                        lib_workdir = Path(workdir) / dep_lib
                        lib_workdir.mkdir(exist_ok=True)
                        for df in dep_files:
                            abs_df = str(root / df) if not Path(df).is_absolute() else df
                            if not Path(abs_df).exists():
                                continue
                            if not abs_df.endswith((".vhd", ".vhdl")):
                                continue
                            subprocess.run(
                                ["ghdl", "-a", "--std=08",
                                 f"--workdir={lib_workdir}", f"--work={dep_lib}",
                                 abs_df],
                                capture_output=True, text=True,
                            )

                # Build -P flags for all dep library workdirs
                p_flags = []
                if _ext_libs:
                    _lib_names = {lib.split(".")[0] for lib in _ext_libs}
                    for dep_lib in sorted(_lib_names):
                        lib_workdir = Path(workdir) / dep_lib
                        if lib_workdir.exists():
                            p_flags.extend([f"-P{lib_workdir}"])

                # P2.250 + H.26: Multi-pass compilation for intra-package
                # dependencies. Files may depend on each other (contexts,
                # packages). Retry failed files up to 5 rounds.
                remaining = list(vhdl_files)
                max_rounds = 5
                for _round in range(max_rounds):
                    failed_this_round = []
                    for vf in remaining:
                        abs_path = str(root / vf) if not Path(vf).is_absolute() else vf
                        ret = subprocess.run(
                            ["ghdl", "-a", "--std=08", f"--workdir={workdir}",
                             f"--work={pkg_library}"] + p_flags + [abs_path],
                            capture_output=True, text=True,
                        )
                        if ret.returncode != 0:
                            failed_this_round.append(vf)
                            if _round == max_rounds - 1:
                                # Last round — record failures
                                log_handle.write(ret.stdout + ret.stderr)
                                status = "FAIL"
                        else:
                            if "warning" in (ret.stdout + ret.stderr).lower():
                                warnings = True
                            log_handle.write(ret.stdout + ret.stderr)
                        checked += 1
                        progress.advance(task)

                    if not failed_this_round:
                        break
                    remaining = failed_this_round
                    # Reset progress for retry
                    if _round < max_rounds - 1:
                        checked -= len(failed_this_round)
                        progress.advance(task, -len(failed_this_round))

                # Track partial results for reporting
                _n_passed = len(vhdl_files) - len(remaining)
                _n_failed = len(remaining)
                if _n_failed > 0 and _n_passed > 0:
                    status = "PARTIAL"
        elif _skip_vhdl:
            # Advance progress for skipped VHDL files
            progress.advance(task, len(vhdl_files))
            checked += len(vhdl_files)

        # Verilog/SV lint via Verilator
        if sv_files and has_verilator:
            inc_dirs = sorted({str((root / Path(f)).parent) for f in sv_files})
            abs_sv = [str(root / f) if not Path(f).is_absolute() else f for f in sv_files]
            import subprocess
            ret = subprocess.run(
                ["verilator", "--lint-only", "-Wall", "-Wno-fatal"]
                + [f"-I{d}" for d in inc_dirs] + abs_sv,
                capture_output=True, text=True,
            )
            log_handle.write(ret.stdout + ret.stderr)
            if ret.returncode != 0:
                status = "FAIL"
            elif "warning" in (ret.stdout + ret.stderr).lower():
                warnings = True
            checked += len(sv_files)
            progress.advance(task, len(sv_files))

    if status == "PASS" and warnings:
        status = "WARN"

    # One-liner result
    if _skip_vhdl and not sv_files:
        # All files were VHDL with external deps — nothing could be checked
        libs_str = ", ".join(sorted(_ext_libs))
        console.print(
            f"  [cyan]⏩ Skipped VHDL lint — package uses external libraries ({libs_str})[/]"
        )
        console.print("  [dim]Full lint will run with 'rr lint' after dependencies are resolved.[/]")
        return
    elif _skip_vhdl:
        libs_str = ", ".join(sorted(_ext_libs))
        console.print(
            f"  [cyan]⏩ Skipped VHDL lint — external libraries ({libs_str})[/]"
        )

    icons = {
        "PASS": "[green]✅ Lint passed[/]",
        "WARN": "[yellow]⚠️  Lint warnings[/]",
        "FAIL": "[red]❌ Lint failed[/]",
        "PARTIAL": "[yellow]⚠️  Lint partial[/]",
    }
    badges = []
    if has_ghdl and vhdl_files and not _skip_vhdl:
        badges.append("[dim]ghdl[/]")
    if has_verilator and sv_files:
        badges.append("[dim]verilator[/]")
    badge_str = f"  ({', '.join(badges)})" if badges else ""

    console.print(f"  {icons.get(status, status)}{badge_str}")

    if status == "PARTIAL":
        console.print(
            f"  [dim]{_n_passed}/{len(vhdl_files)} files passed, "
            f"{_n_failed} need external deps. Details: {log_path}[/]"
        )
    elif status == "FAIL":
        console.print(f"  [dim]Details: {log_path}[/]")

    # Record in lint tracker
    with cli_resilient_block("lint result tracking"):
        from datetime import datetime, timezone

        from sdk.engine.lint_tracker import LintResult, LintTracker
        tracker = LintTracker(str(root))
        _, pkg_name = package_ref.split("/", 1) if "/" in package_ref else ("", package_ref)
        tracker.record(LintResult(
            module=pkg_name,
            status=status,
            timestamp=datetime.now(timezone.utc).isoformat(timespec="seconds"),
        ))


def _pkg_add_local(local_repo: Path, entity_name: str | None) -> None:
    """Handle ``rr pkg add --local <path> [--name <entity>]``."""
    from sdk.scripts.scan_ip_repo import scan_local_repo

    console.print(f"\n  Scanning [cyan]{local_repo}[/] for IP entities...\n")

    try:
        entries = scan_local_repo(local_repo)
    except (RuntimeError, ImportError, OSError, KeyError) as exc:
        console.print(f"❌ [red]Scan failed: {exc}[/]")
        sys.exit(1)

    if not entries:
        console.print("  [dim]No IP entities discovered in this directory.[/]")
        sys.exit(1)

    # If --name not given, list discovered entities and exit
    if entity_name is None:
        # Group by role: tops first with components nested
        from collections import Counter
        role_counts = Counter(e.get("role", "top") for e in entries)
        tops = [e for e in entries if e.get("role") == "top"]
        components = {e["name"] for e in entries if e.get("role") in ("component", "primitive")}

        table = Table(show_header=True, header_style="bold cyan", box=None, padding=(0, 2))
        table.add_column("Entity", style="cyan")
        table.add_column("Files", style="dim")
        table.add_column("Lang", style="green")
        table.add_column("Badges", style="dim")
        table.add_column("Tags", style="dim", max_width=40)

        def _badge_str(e):
            badges = e.get("badges", [])
            icons = []
            if "linted" in badges:
                icons.append("[green]⬡[/]")
            if "tested" in badges:
                icons.append("[green]🧪[/]")
            return " ".join(icons) if icons else "[dim]—[/]"

        def _tag_str(e, limit=5):
            tags = e.get("tags", [])[:limit]
            return "[dim]" + ", ".join(tags) + "[/]" if tags else ""

        # Show top-level IPs with component count
        for e in sorted(tops, key=lambda x: -len(x.get("components", []))):
            compat = e.get("routertl_compat", {})
            comp_list = e.get("components", [])
            name_display = e["name"]
            if comp_list:
                name_display += f" [dim]({len(comp_list)} components)[/]"
            table.add_row(
                name_display,
                str(len(compat.get("files", []))),
                compat.get("language", ""),
                _badge_str(e),
                _tag_str(e),
            )

        # Show component/primitive section if any
        if components:
            table.add_row("[dim]───[/]", "", "", "", "")
            non_tops = [e for e in entries if e["name"] in components]
            for e in sorted(non_tops, key=lambda x: x["name"]):
                compat = e.get("routertl_compat", {})
                role_icon = "[dim]├[/] " if e.get("role") == "component" else "[dim]·[/] "
                table.add_row(
                    role_icon + e["name"],
                    str(len(compat.get("files", []))),
                    compat.get("language", ""),
                    _badge_str(e),
                    _tag_str(e),
                )

        test_info = entries[0].get("test_info", {}) if entries else {}
        console.print(
            f"  Found {len(entries)} IP entit{'ies' if len(entries) != 1 else 'y'} "
            f"([cyan]{role_counts.get('top', 0)}[/] top, "
            f"[dim]{role_counts.get('component', 0)} components, "
            f"{role_counts.get('primitive', 0)} primitives[/]):\n"
        )
        console.print(table)

        if test_info.get("frameworks"):
            console.print(
                f"\n  [dim]Test frameworks: {', '.join(test_info['frameworks'])} "
                f"({test_info.get('testbench_count', 0)} testbenches)[/]"
            )
        first_top = tops[0]["name"] if tops else entries[0]["name"]
        console.print(
            f"\n  Specify [cyan]--name <entity>[/] to install one, e.g.:\n"
            f"    [dim]{_cli_name()} pkg add --local {local_repo} --name {first_top}[/]\n"
        )
        return

    # Find matching entity
    match = None
    for e in entries:
        if e["name"].lower() == entity_name.lower():
            match = e
            break

    if match is None:
        console.print(
            f"❌ [red]Entity '{entity_name}' not found in scan results.[/]\n"
            f"   Available: {', '.join(e['name'] for e in entries)}"
        )
        sys.exit(1)

    # Install the package
    from sdk.engine.package_resolver import (
        install_local_package,
        load_lock,
        write_libraries_cache,
        write_lock,
    )

    namespace = match["namespace"]
    name = match["name"]
    pkg_ref = f"{namespace}/{name}"

    console.print(f"  Installing [cyan]{pkg_ref}[/]...")
    lock_entry = install_local_package(match, local_repo, Path.cwd())

    # Add to project.yml
    _add_package_to_project_yml(pkg_ref, "local")
    console.print(f"  [green]+[/] [cyan]{pkg_ref}[/] [dim](local)[/]")

    # Write lock entry
    resolved = load_lock(Path.cwd())
    resolved[pkg_ref] = lock_entry
    write_lock(resolved, Path.cwd())

    # Update libraries cache
    from sdk.engine.package_resolver import _group_by_library
    all_resolved = load_lock(Path.cwd())
    lib_files = _group_by_library(all_resolved, Path.cwd())
    write_libraries_cache(lib_files, Path.cwd())

    # Regenerate build_env.mk so SRC_DIR includes libs/
    with cli_resilient_block("build_env.mk regeneration after pkg add --local"):
        from sdk.cli.engine_dispatch import ScriptNotFound, run_engine_script
        try:
            run_engine_script("project_manager.py", ["project.yml"])
        except ScriptNotFound:
            pass

    n_files = len(lock_entry.get("files", []))
    console.print(
        f"✅ [green]Added {pkg_ref} ({n_files} file{'s' if n_files != 1 else ''})[/]"
    )

    # Post-install lint check
    _post_install_lint(pkg_ref)


# ── update ─────────────────────────────────────────────────────────────────────


@pkg_group.command(name="update")
@click.argument("package_ref", required=False, default=None,
                shell_complete=_complete_installed_pkg)
def pkg_update(package_ref):
    """Update packages to the latest compatible versions.

    Without PACKAGE_REF, updates all packages.
    With PACKAGE_REF, updates only that package.

    \b
    Examples:
        rr pkg update
        rr pkg update open-logic/olo_base_fifo_async
    """
    _require_project_yml()

    from sdk.cli.project_config import load_project_config
    from sdk.engine.package_resolver import resolve_packages

    config = load_project_config()
    packages = config.get("packages") or {}

    if not packages:
        console.print("  [dim]No packages declared in project.yml.[/]")
        return

    if package_ref and package_ref not in packages:
        console.print(f"❌ [red]'{package_ref}' is not in project.yml packages.[/]")
        sys.exit(1)

    if package_ref:
        console.print(f"\n🔄 [cyan]Updating {package_ref}...[/]\n")
        config = dict(config)
        config["packages"] = {package_ref: packages[package_ref]}
    else:
        console.print("\n🔄 [cyan]Updating packages...[/]\n")

    try:
        lib_files = resolve_packages(config, Path.cwd())
    except (RuntimeError, ValueError, OSError) as exc:
        console.print(f"❌ [red]{exc}[/]")
        sys.exit(1)

    from sdk.engine.package_resolver import write_libraries_cache
    write_libraries_cache(lib_files, Path.cwd())

    console.print("✅ [green]All packages up to date.[/]")


# ── list ───────────────────────────────────────────────────────────────────────


@pkg_group.command(name="list")
def pkg_list():
    """Show installed packages from ip.lock.

    \b
    Examples:
        rr pkg list
    """
    from sdk.engine.package_resolver import LOCK_FILE, load_lock

    lock = load_lock(Path.cwd())

    if not lock:
        console.print(
            "  [dim]No ip.lock found. Run:[/] [cyan]rr pkg install[/]"
        )
        return

    table = Table(show_header=True, header_style="bold cyan", box=None, padding=(0, 2))
    table.add_column("Package", style="cyan")
    table.add_column("Version", style="green")
    table.add_column("Library", style="yellow")
    table.add_column("Source", style="dim")
    table.add_column("Commit", style="dim")

    for pkg_ref, entry in sorted(lock.items()):
        table.add_row(
            pkg_ref,
            entry.get("resolved_version", ""),
            entry.get("library", ""),
            entry.get("metadata_source", ""),
            entry.get("commit", "")[:10],
        )

    console.print(f"\n📦 [cyan]Installed packages[/] ({len(lock)} total)\n")
    console.print(table)
    console.print(f"\n  [dim]{LOCK_FILE}[/]")
    console.print()


# ── search ─────────────────────────────────────────────────────────────────────


@pkg_group.command(name="search")
@click.argument("query")
def pkg_search(query):
    """Search the IP index catalog by name or description.

    \b
    Examples:
        rr pkg search fifo
        rr pkg search cdc
        rr pkg search "open-logic"
    """
    from sdk.cli.project_config import load_project_config
    from sdk.engine.index_client import (
        fetch_catalog,
        get_index_url,
        search_catalog,
        suggest_catalog_terms,
    )

    config = {}
    if os.path.exists("project.yml"):
        from sdk.cli.project_config import load_project_config
        config = load_project_config()

    index_url = get_index_url(config)
    cache_dir = Path(".routertl_cache/index")

    try:
        catalog = fetch_catalog(index_url, cache_dir)
    except (RuntimeError, ValueError, OSError) as exc:
        console.print(f"❌ [red]Could not reach index: {exc}[/]")
        sys.exit(1)

    # RTL-P2.368: search_catalog itself does synonym expansion now.
    results = search_catalog(query, catalog)

    # Include SDK builtin packages in search results
    from sdk.engine.package_resolver import list_builtin_packages
    for builtin in list_builtin_packages():
        q = query.lower()
        if q in builtin["name"].lower() or q in builtin.get("description", "").lower():
            # Avoid duplicates
            if not any(r["namespace"] == "routertl" and r["name"] == builtin["name"] for r in results):
                results.append(builtin)

    if not results:
        console.print(f"  [dim]No packages found matching '{query}'.[/]")
        # RTL-P2.369: catalog-driven suggestions when search returns zero.
        # Reads from catalog package names + tags + axes_map synonyms so
        # the "did you mean?" respects the registry's actual vocabulary.
        suggestions = suggest_catalog_terms(query, catalog)
        if suggestions:
            console.print(
                "\n  [dim]Did you mean?[/] "
                + " · ".join(f"[cyan]{s}[/]" for s in suggestions)
            )
            console.print(
                f"  [dim]Try:[/] [cyan]{_cli_name()} pkg search "
                f"{suggestions[0]}[/]"
            )
        return

    # Cap results for display (show top matches, not 1961 entries)
    MAX_RESULTS = 30
    total_found = len(results)
    # Filter: prefer top-level entities over components
    tops = [r for r in results if r.get("role", "top") == "top"]
    others = [r for r in results if r.get("role", "top") != "top"]
    display = (tops + others)[:MAX_RESULTS]

    table = Table(show_header=True, header_style="bold cyan", box=None, padding=(0, 2))
    table.add_column("Package", style="cyan", no_wrap=True)
    table.add_column("Latest", style="green")
    table.add_column("Role", style="dim")
    table.add_column("License", style="dim")
    table.add_column("Description")

    any_unversioned = False
    for entry in display:
        pkg_ref = f"{entry['namespace']}/{entry['name']}"
        role = entry.get("role", "top")
        role_display = {"top": "", "component": "[dim]component[/]", "primitive": "[dim]primitive[/]"}.get(role, "")
        latest = entry.get("latest")
        if latest:
            latest_display = latest
            pkg_display = pkg_ref
        else:
            any_unversioned = True
            latest_display = "[dim yellow]no tags[/]"
            pkg_display = f"[dim]{pkg_ref}[/]"
        table.add_row(
            pkg_display,
            latest_display,
            role_display,
            entry.get("license", ""),
            entry.get("description", ""),
        )

    shown = len(display)
    msg = f"\n🔍 [cyan]Search results for '{query}'[/]"
    if total_found > MAX_RESULTS:
        msg += f" (showing {shown}/{total_found} — top matches first)"
    else:
        msg += f" ({total_found} found)"
    console.print(msg + "\n")
    console.print(table)
    console.print()
    if any_unversioned:
        console.print(
            "  [dim yellow]no tags[/][dim] = upstream has no git tags yet; "
            "these cannot be installed with [/][cyan]pkg add[/][dim] until the "
            "maintainer tags a release.[/]"
        )
    console.print(f"  [dim]Add with:[/] [cyan]{_cli_name()} pkg add <namespace>/<name>[/]")
    console.print()


# ── info ───────────────────────────────────────────────────────────────────────


@pkg_group.command(name="info")
@click.argument("package_ref", shell_complete=_complete_registry_pkg)
@click.option("--version", "-v", default=None, help="Specific version to inspect.")
def pkg_info(package_ref, version):
    """Show full metadata for a package from the index.

    PACKAGE_REF format: namespace/name

    \b
    Examples:
        rr pkg info open-logic/olo_base_fifo_async
        rr pkg info open-logic/olo_base_fifo_async --version 2.5.0
    """
    if "/" not in package_ref:
        console.print(f"❌ [red]Expected namespace/name, got: {package_ref}[/]")
        sys.exit(1)

    from sdk.cli.project_config import load_project_config
    from sdk.engine.index_client import (
        fetch_catalog,
        fetch_index_entry,
        get_index_url,
    )

    config = {}
    if os.path.exists("project.yml"):
        config = load_project_config()

    index_url = get_index_url(config)
    cache_dir = Path(".routertl_cache/index")
    namespace, name = package_ref.split("/", 1)

    try:
        catalog = fetch_catalog(index_url, cache_dir)
        if version is None:
            state, latest = _catalog_lookup(catalog, namespace, name)
            if state == "missing":
                raise ValueError(f"Package {namespace}/{name} not found in index.")
            if state == "unversioned":
                console.print(_unversioned_error_msg(package_ref))
                sys.exit(1)
            version = latest
        entry = fetch_index_entry(namespace, name, version, index_url, cache_dir)
    except (RuntimeError, ValueError, OSError) as exc:
        console.print(f"❌ [red]{exc}[/]")
        sys.exit(1)

    compat = entry.get("routertl_compat", {})
    source = entry.get("source", {})

    # Fetch verification badge
    badge_str = ""
    verification = _fetch_verification_detail(index_url, namespace, name, version)
    if verification:
        badge_key = verification.get("badge", "unlinted")
        badge_str = f"  {_BADGE_ICONS.get(badge_key, '')}"

    console.print(f"\n📦 [bold cyan]{package_ref}[/] [green]v{entry.get('version', version)}[/]{badge_str}\n")
    console.print(f"  [dim]Description:[/]  {entry.get('description', '')}")
    console.print(f"  [dim]License:[/]      {entry.get('license', '')}")
    console.print(f"  [dim]Source:[/]       {source.get('url', '')} @ {source.get('tag', '')}")
    console.print(f"  [dim]Library:[/]      {compat.get('library', '')}")

    files = compat.get("files", [])
    if files:
        console.print(f"  [dim]Files ({len(files)}):[/]")
        for f in files:
            console.print(f"    [dim]•[/] {f}")

    # Show verification details if available
    if verification and verification.get("badge") != "unlinted":
        console.print()
        console.print("  [bold]Verification:[/]")
        lint = verification.get("lint")
        if lint:
            icon = "[green]PASS[/]" if lint == "pass" else "[red]FAIL[/]"
            console.print(f"    Lint:       {icon}")
        sim = verification.get("simulation")
        if sim and sim != "skip":
            icon = "[green]PASS[/]" if sim == "pass" else "[red]FAIL[/]"
            tests = verification.get("sim_tests", "")
            console.print(f"    Simulation: {icon} ({tests} tests)")
        synth = verification.get("synthesis", {})
        for vendor, info in (synth or {}).items():
            if isinstance(info, dict):
                s = info.get("status", "skip")
                if s == "skip":
                    continue
                icon = "[green]PASS[/]" if s == "pass" else "[red]FAIL[/]"
                part = info.get("part", "")
                luts = info.get("luts")
                extra = f", {part}" if part else ""
                if luts:
                    extra += f", {luts} LUTs"
                console.print(f"    {vendor.capitalize():12s}{icon}{extra}")

    console.print()
    console.print(
        f"  [dim]Add to project:[/] [cyan]{_cli_name()} pkg add {package_ref}[/]"
    )
    console.print()


# ── verify ────────────────────────────────────────────────────────────────────


@pkg_group.command(name="verify")
def pkg_verify():
    """Verify integrity of installed packages against ip.lock hashes.

    \b
    Checks every installed source file against the SHA-256 hash recorded
    in ip.lock at install time. Detects tampering, accidental edits, or
    corrupted downloads.
    """
    _require_project_yml()

    from sdk.engine.package_resolver import verify_integrity

    results = verify_integrity(Path.cwd())

    if not results:
        console.print("  [dim]No packages in ip.lock — nothing to verify.[/]")
        return

    console.print()
    all_pass = True
    total_files = 0

    for r in results:
        pkg = r["package"]
        status = r["status"]
        checked = r["files_checked"]
        total_files += checked

        if status == "pass":
            console.print(
                f"  [green]✅[/] [cyan]{pkg}[/]  "
                f"[dim]{checked} file{'s' if checked != 1 else ''}, all hashes match[/]"
            )
        elif status == "no_hashes":
            console.print(
                f"  [yellow]⚠[/]  [cyan]{pkg}[/]  "
                f"[dim]no hashes in ip.lock — reinstall to generate[/]"
            )
        else:
            all_pass = False
            console.print(f"  [red]❌[/] [cyan]{pkg}[/]  [red]MISMATCH[/]")
            for m in r["mismatches"]:
                if m["reason"] == "missing":
                    console.print(f"     [red]✗[/] {m['file']}  [red]FILE MISSING[/]")
                else:
                    console.print(f"     [red]✗[/] {m['file']}")
                    console.print(f"       expected: [dim]{m['expected'][:16]}…[/]")
                    console.print(f"       actual:   [dim]{m['actual'][:16]}…[/]")

    console.print()
    if all_pass:
        console.print(
            f"  [green]All packages verified.[/] "
            f"[dim]{total_files} files checked, no tampering detected.[/]"
        )
    else:
        console.print(
            "  [red]Integrity check failed.[/] "
            f"Run [cyan]{_cli_name()} pkg install --force[/] to restore original sources."
        )
        sys.exit(1)


# ── helpers ────────────────────────────────────────────────────────────────────


def _require_project_yml():
    if not os.path.exists("project.yml"):
        console.print("❌ [red]No project.yml found in current directory.[/]")
        sys.exit(1)


def _add_package_to_project_yml(pkg_ref: str, constraint: str) -> None:
    """Append or update a packages: entry in project.yml in-place.

    Uses yaml.safe_load/dump for correctness instead of string manipulation.
    Comments are not preserved (pyyaml limitation), but the YAML is always
    valid after mutation.
    """
    import yaml

    yml_path = Path("project.yml")
    with open(yml_path) as f:
        config = yaml.safe_load(f) or {}

    if not isinstance(config, dict):
        config = {}

    packages = config.setdefault("packages", {})
    packages[pkg_ref] = constraint

    # Auto-register libs/ in paths.sources so that workspace update,
    # linting, and dependency resolution can discover installed IP.
    paths = config.setdefault("paths", {})
    sources = paths.get("sources", "src")
    if isinstance(sources, str):
        sources_list = [sources]
    elif isinstance(sources, list):
        sources_list = list(sources)
    else:
        sources_list = ["src"]
    if "libs" not in sources_list:
        sources_list.append("libs")
        paths["sources"] = sources_list

    with open(yml_path, "w") as f:
        yaml.dump(config, f, default_flow_style=False, sort_keys=False, allow_unicode=True)


# ── register ─────────────────────────────────────────────────────────────────


@pkg_group.command(name="register")
@click.option(
    "--registry",
    default="https://registry.routertl.dev",
    envvar="ROUTERTL_REGISTRY",
    help="Registry URL.",
)
def pkg_register(registry):
    """Create an account on the RouteRTL package registry.

    \b
    After registering, run `rr pkg login` to authenticate.

    \b
    Examples:
        rr pkg register
        rr pkg register --registry https://registry.example.com
    """
    import json as _json
    from urllib.error import HTTPError, URLError
    from urllib.request import Request, urlopen

    username = click.prompt("  Username")
    email = click.prompt("  Email")
    password = click.prompt("  Password", hide_input=True)
    password_confirm = click.prompt("  Confirm password", hide_input=True)

    if password != password_confirm:
        console.print("  [red]Passwords do not match.[/]")
        sys.exit(1)

    registry = registry.rstrip("/")
    url = f"{registry}/v1/auth/register"
    payload = _json.dumps({
        "username": username,
        "email": email,
        "password": password,
    }).encode()
    req = Request(url, data=payload, headers={"Content-Type": "application/json"})

    try:
        with urlopen(req, timeout=15) as resp:
            data = _json.loads(resp.read().decode())
    except HTTPError as exc:
        detail = "registration failed"
        try:
            detail = _json.loads(exc.read().decode()).get("detail", str(exc))
        except (ValueError, UnicodeDecodeError, AttributeError, KeyError):
            detail = str(exc)
        console.print(f"  [red]Registration failed:[/] {detail}")
        sys.exit(1)
    except URLError as exc:
        console.print(f"  [red]Connection failed:[/] {exc}")
        sys.exit(1)

    console.print(f"  [green]Account created:[/] [cyan]{data.get('username', username)}[/]")
    console.print("  Now run: [cyan]rr pkg login[/]")


# ── login ─────────────────────────────────────────────────────────────────────


@pkg_group.command(name="login")
@click.option(
    "--registry",
    default="https://registry.routertl.dev",
    envvar="ROUTERTL_REGISTRY",
    help="Registry URL.",
)
def pkg_login(registry):
    """Authenticate with the RouteRTL package registry.

    \b
    Stores a JWT token in ~/.routertl/auth.json (mode 0600).
    For CI, set ROUTERTL_TOKEN instead of using interactive login.

    \b
    Examples:
        rr pkg login
        rr pkg login --registry https://registry.example.com
    """
    import json as _json
    from urllib.error import URLError
    from urllib.request import Request, urlopen

    from sdk.engine.registry_auth import save_auth

    username = click.prompt("  Username")
    password = click.prompt("  Password", hide_input=True)

    registry = registry.rstrip("/")
    url = f"{registry}/v1/auth/login"
    payload = _json.dumps({"username": username, "password": password}).encode()
    req = Request(url, data=payload, headers={"Content-Type": "application/json"})

    try:
        with urlopen(req, timeout=15) as resp:
            data = _json.loads(resp.read().decode())
    except URLError as exc:
        # Extract detail from HTTP error body if available
        detail = "connection failed"
        if hasattr(exc, "read"):
            try:
                detail = _json.loads(exc.read().decode()).get("detail", str(exc))
            except (ValueError, UnicodeDecodeError, AttributeError, KeyError):
                detail = str(exc)
        console.print(f"  [red]Login failed:[/] {detail}")
        sys.exit(1)

    auth_path = save_auth(registry, data["token"], username, data["expires_at"])
    console.print(f"  Logged in as [cyan]{username}[/].")
    console.print(f"  Token stored in [dim]{auth_path}[/]")


# ── logout ────────────────────────────────────────────────────────────────────


@pkg_group.command(name="logout")
def pkg_logout():
    """Remove stored registry credentials.

    \b
    Deletes ~/.routertl/auth.json.

    \b
    Examples:
        rr pkg logout
    """
    from sdk.engine.registry_auth import clear_auth, get_auth_username

    username = get_auth_username()
    if clear_auth():
        who = f" ({username})" if username else ""
        console.print(f"  Logged out{who}. Token removed.")
    else:
        console.print("  Not logged in — nothing to do.")


# ── test ──────────────────────────────────────────────────────────────────────


@pkg_group.command(name="test")
@click.argument("package_ref")
@click.option("--filter", "-f", "test_filter", default=None,
              help="Filter tests by pattern (e.g. '*fifo*').")
@click.option("--threads", "-p", default=1, type=int, help="Parallel threads (default: 1).")
def pkg_test(package_ref, test_filter, threads):
    """Run a package's tests in their native framework.

    Detects the test framework (VUnit, cocotb, OSVVM) and runs tests
    without merging into the RouteRTL simulation engine.

    \b
    Three execution levels (D.24):
      Level 1: Auto-detect framework from repo contents
      Level 2: Read ip.yml tests.run command
      Level 3: Docker image provided by the IP author (→ verified badge)

    \b
    Examples:
        rr pkg test open-logic/olo_base_fifo_sync
        rr pkg test alexforencich/eth_mac_10g -f "*pause*"
        rr pkg test myns/my_ip -p 4
    """
    _require_project_yml()
    _run_pkg_test(package_ref, test_filter, threads)


def _run_pkg_test(package_ref: str, test_filter: str | None, threads: int) -> None:
    """Execute package tests via detected or declared framework."""
    import shutil
    import subprocess

    from sdk.engine.package_resolver import load_lock

    # Find package in lock
    lock = load_lock(Path.cwd())
    entry = lock.get(package_ref)
    if not entry:
        console.print(f"  [red]Package '{package_ref}' not in ip.lock.[/]")
        console.print(f"  [dim]Install first: {_cli_name()} pkg add {package_ref}[/]")
        sys.exit(1)

    local_path = Path.cwd() / entry.get("local_path", "")
    git_url = entry.get("url", "")

    if not local_path.exists():
        console.print(f"  [red]Package not installed at {local_path}[/]")
        sys.exit(1)

    # ── Level 3: Docker image (ip.yml tests.docker) ──────────────
    ip_yml = local_path / "ip.yml"
    tests_config = {}
    if ip_yml.exists():
        import yaml
        with open(ip_yml) as f:
            data = yaml.safe_load(f) or {}
        tests_config = data.get("tests", {})

    if tests_config.get("docker"):
        _run_docker_tests(package_ref, tests_config, test_filter, threads)
        return

    # ── Level 2: Declared run command (ip.yml tests.run) ─────────
    if tests_config.get("run"):
        _run_declared_tests(package_ref, local_path, tests_config, test_filter, threads)
        return

    # ── Level 1: Auto-detect framework from repo ─────────────────
    # Need the full repo (installed packages are pruned). Clone it.
    if not git_url or git_url.startswith("file://"):
        # Local package — use the source path directly
        source_path = Path(git_url.replace("file://", "")) if git_url.startswith("file://") else local_path
        _run_autodetect_tests(package_ref, source_path, test_filter, threads)
        return

    # Registry package — clone the full repo for tests
    import tempfile
    console.print(f"  Cloning {package_ref} for tests...")
    with tempfile.TemporaryDirectory(prefix="rr-test-") as tmpdir:
        clone_dir = Path(tmpdir) / "repo"
        tag = entry.get("resolved_version", "main")
        # Try tag, v-tag, default
        cloned = False
        for attempt in ([tag, f"v{tag}", None] if tag not in ("master", "main", "local") else [None]):
            cmd = ["git", "clone", "--depth", "1"]
            if attempt:
                cmd += ["--branch", attempt]
            cmd += [git_url, str(clone_dir)]
            try:
                subprocess.run(cmd, capture_output=True, timeout=180, check=True)
                cloned = True
                break
            except (subprocess.CalledProcessError, subprocess.TimeoutExpired):
                shutil.rmtree(clone_dir, ignore_errors=True)

        if not cloned:
            console.print(f"  [red]Could not clone {git_url}[/]")
            sys.exit(1)

        # Init submodules (some repos need them for tests)
        subprocess.run(
            ["git", "submodule", "update", "--init", "--recursive"],
            cwd=str(clone_dir), capture_output=True, timeout=120,
        )

        _run_autodetect_tests(package_ref, clone_dir, test_filter, threads)


def _run_docker_tests(
    package_ref: str, config: dict, test_filter: str | None, threads: int,
) -> None:
    """Level 3: Run tests in author-provided Docker container."""
    import subprocess
    import time

    image = config["docker"]
    run_cmd = config.get("run", "")

    console.print(f"  [cyan]Level 3:[/] Docker image [bold]{image}[/]")

    # Pull image
    console.print(f"  Pulling {image}...")
    pull = subprocess.run(["docker", "pull", image], capture_output=True, text=True, timeout=300)
    if pull.returncode != 0:
        console.print(f"  [red]Docker pull failed: {pull.stderr.strip()[:200]}[/]")
        sys.exit(1)

    # Run tests
    cmd_parts = ["docker", "run", "--rm", image]
    if run_cmd:
        cmd_parts += ["sh", "-c", run_cmd]

    console.print("  Running tests...")
    start = time.time()
    result = subprocess.run(cmd_parts, capture_output=True, text=True, timeout=600)
    elapsed = time.time() - start

    _report_results(package_ref, result, elapsed, "docker")


def _run_declared_tests(
    package_ref: str, local_path: Path, config: dict, test_filter: str | None, threads: int,
) -> None:
    """Level 2: Run tests via declared command in ip.yml."""
    import subprocess
    import time

    run_cmd = config["run"]
    reqs = config.get("requirements")

    console.print(f"  [cyan]Level 2:[/] Declared command: [bold]{run_cmd}[/]")

    # Install requirements if specified
    if reqs:
        reqs_path = local_path / reqs
        if reqs_path.exists():
            console.print(f"  Installing {reqs}...")
            subprocess.run(
                [sys.executable, "-m", "pip", "install", "-r", str(reqs_path), "-q"],
                capture_output=True, timeout=120,
            )

    start = time.time()
    result = subprocess.run(
        run_cmd, shell=True, capture_output=True, text=True,
        cwd=str(local_path), timeout=600,
    )
    elapsed = time.time() - start

    _report_results(package_ref, result, elapsed, "declared")


def _run_autodetect_tests(
    package_ref: str, repo_path: Path, test_filter: str | None, threads: int,
) -> None:
    """Level 1: Auto-detect test framework and run."""
    import subprocess
    import time

    # Detect framework
    framework = None
    run_cmd = None
    cwd = repo_path

    # VUnit: look for run.py in sim/ or root
    for candidate in ["sim/run.py", "run.py", "test/run.py"]:
        if (repo_path / candidate).exists():
            framework = "vunit"
            run_script = repo_path / candidate
            cwd = run_script.parent
            # Build command
            parts = [sys.executable, str(run_script), "--ghdl"]
            if test_filter:
                parts.append(test_filter)
            if threads > 1:
                parts += ["-p", str(threads)]
            run_cmd = parts
            break

    # cocotb: look for Makefile with COCOTB reference
    if not framework:
        for makefile in repo_path.rglob("Makefile"):
            try:
                text = makefile.read_text(errors="replace")
                if "cocotb" in text.lower() or "TOPLEVEL" in text:
                    framework = "cocotb"
                    cwd = makefile.parent
                    run_cmd = ["make", "-C", str(cwd)]
                    break
            except OSError:
                pass

    # OSVVM: look for .pro files
    if not framework:
        pro_files = list(repo_path.rglob("*.pro"))
        if pro_files:
            framework = "osvvm"
            console.print("  [yellow]OSVVM detected but auto-execution not supported yet.[/]")
            console.print("  [dim]Add tests.run to ip.yml for Level 2 execution.[/]")
            return

    if not framework:
        console.print(f"  [dim]No test framework detected in {repo_path.name}.[/]")
        console.print("  [dim]Add tests.run or tests.docker to ip.yml.[/]")
        return

    console.print(f"  [cyan]Level 1:[/] Auto-detected [bold]{framework}[/]")

    # Handle VUnit compatibility
    if framework == "vunit":
        env = os.environ.copy()
        # Set PYTHONPATH for common dep patterns
        for subdir in ["3rdParty/en_cl_fix/bittrue/models/python",
                       "src/fix/python", "python", "py"]:
            candidate = repo_path / subdir
            if candidate.is_dir():
                env["PYTHONPATH"] = str(candidate) + ":" + env.get("PYTHONPATH", "")
        env["VUNIT_SIMULATOR"] = "ghdl"

        # Patch run.py to handle VUnit API version mismatches (e.g. nvc.global_flags)
        # Wrap set_sim_option calls in try/except so unknown options don't crash
        _patch_vunit_compat(run_script)
    else:
        env = None

    start = time.time()
    try:
        result = subprocess.run(
            run_cmd, capture_output=True, text=True,
            cwd=str(cwd), timeout=600, env=env,
        )
    except subprocess.TimeoutExpired:
        console.print("  [red]Tests timed out after 600s[/]")
        return

    elapsed = time.time() - start
    _report_results(package_ref, result, elapsed, framework)


def _patch_vunit_compat(run_script: Path) -> None:
    """Patch a VUnit run.py to tolerate unknown sim_options.

    VUnit versions differ on which sim_options are valid (e.g.
    nvc.global_flags was added after 4.7.1). This wraps set_sim_option
    calls in try/except so the script doesn't crash on version mismatch.
    """
    text = run_script.read_text()
    if "_rr_patched" in text:
        return  # already patched

    patch = """
# --- RouteRTL compatibility patch (auto-applied by rr pkg test) ---
import vunit.configuration as _rr_vc
_rr_orig_sso = _rr_vc.Configuration.set_sim_option
def _rr_safe_sso(self, name, value):
    try:
        _rr_orig_sso(self, name, value)
    except ValueError:
        pass
_rr_vc.Configuration.set_sim_option = _rr_safe_sso
_rr_patched = True
# --- end patch ---
"""
    # Insert after imports
    lines = text.splitlines(keepends=True)
    insert_at = 0
    for i, line in enumerate(lines):
        if line.startswith("from vunit") or line.startswith("import vunit"):
            insert_at = i + 1
    lines.insert(insert_at, patch)
    run_script.write_text("".join(lines))


def _report_results(
    package_ref: str, result, elapsed: float, framework: str,
) -> None:
    """Parse test results and assess complexity for verified badge eligibility."""
    import re

    output = result.stdout + result.stderr

    # ── Parse test counts ────────────────────────────────────────
    tests_run = 0
    tests_passed = 0

    # VUnit: "pass 66 of 66"
    m = re.search(r"pass\s+(\d+)\s+of\s+(\d+)", output)
    if m:
        tests_passed = int(m.group(1))
        tests_run = int(m.group(2))

    # cocotb/pytest: "X passed" or "X passed, Y failed"
    if not tests_run:
        m = re.search(r"(\d+)\s+passed", output)
        if m:
            tests_passed = int(m.group(1))
            tests_run = tests_passed
        m = re.search(r"(\d+)\s+failed", output)
        if m:
            tests_run += int(m.group(1))

    # Generic: count "PASS" / "FAIL" lines
    if not tests_run:
        tests_passed = output.lower().count("pass")
        tests_run = tests_passed + output.lower().count("fail")

    passed = result.returncode == 0

    # ── Complexity assessment ────────────────────────────────────
    # Three checks to ensure tests are meaningful (not empty stubs):
    #   1. Minimum test count (>= 3)
    #   2. Minimum elapsed time (avg > 0.005s per test)
    #   3. Tests actually ran (not just compiled)
    MIN_TESTS = 3
    MIN_AVG_TIME_S = 0.005  # 5ms per test minimum

    complexity_issues: list[str] = []
    if tests_run < MIN_TESTS:
        complexity_issues.append(
            f"only {tests_run} test{'s' if tests_run != 1 else ''} "
            f"(minimum {MIN_TESTS} for verified badge)"
        )
    if tests_run > 0 and elapsed / tests_run < MIN_AVG_TIME_S:
        avg_ms = elapsed / tests_run * 1000
        complexity_issues.append(
            f"avg {avg_ms:.1f}ms/test — suspiciously fast (empty stubs?)"
        )
    if tests_run == 0 and passed:
        complexity_issues.append("zero tests detected despite pass exit code")

    badge_eligible = passed and not complexity_issues

    # ── Display ──────────────────────────────────────────────────
    if passed:
        icon = "[green]✅[/]"
        status = "PASS"
    else:
        icon = "[red]❌[/]"
        status = "FAIL"

    console.print(
        f"\n  {icon} [bold]{package_ref}[/] — "
        f"{tests_passed}/{tests_run} tests passed "
        f"[dim]({framework}, {elapsed:.1f}s)[/]"
    )

    if badge_eligible:
        console.print("  [green]Verified badge eligible[/] ✅")
    elif passed and complexity_issues:
        console.print("  [yellow]Tests pass but not badge-eligible:[/]")
        for issue in complexity_issues:
            console.print(f"    [yellow]- {issue}[/]")

    if not passed:
        lines = output.strip().splitlines()
        tail = lines[-10:] if len(lines) > 10 else lines
        for line in tail:
            console.print(f"    [dim]{line}[/]")

    # Record in lint tracker
    with cli_resilient_block("test result tracking"):
        from datetime import datetime, timezone

        from sdk.engine.lint_tracker import LintResult, LintTracker
        _, pkg_name = package_ref.split("/", 1) if "/" in package_ref else ("", package_ref)
        tracker = LintTracker(str(Path.cwd()))
        tracker.record(LintResult(
            module=f"{pkg_name}_test",
            status=status,
            timestamp=datetime.now(timezone.utc).isoformat(timespec="seconds"),
        ))


# ── publish ───────────────────────────────────────────────────────────────────

# P2.248: Standard VHDL libraries to exclude from library_deps
_STD_LIBS = {"ieee", "std", "work", "unisim", "unimacro", "xpm", "utils"}


def _scan_library_deps(files: list[str], own_library: str) -> list[str]:
    """Scan VHDL files for external library references.

    Returns sorted unique list of library names that are not standard
    libraries and not the package's own library.
    """
    import re

    lib_re = re.compile(r"(?i)\blibrary\s+(\w+)\s*;")
    exclude = _STD_LIBS | {own_library.lower()}
    ext_libs: set[str] = set()

    for f in files:
        p = Path(f)
        if p.suffix.lower() not in (".vhd", ".vhdl"):
            continue
        try:
            text = p.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        for m in lib_re.finditer(text):
            lib = m.group(1)
            if lib.lower() not in exclude:
                ext_libs.add(lib)

    return sorted(ext_libs)


def _scan_module_info(files: list[str]) -> tuple[list[str], list[str]]:
    """Scan Verilog/SV files for module definitions and instantiations.

    Returns (modules_provided, module_deps):
    - modules_provided: modules defined in these files
    - module_deps: modules instantiated but not defined (external deps)
    """
    import re

    MODULE_DEF_RE = re.compile(r"^\s*module\s+(\w+)\b", re.MULTILINE)
    COMMENT_LINE_RE = re.compile(r"//[^\n]*")
    COMMENT_BLOCK_RE = re.compile(r"/\*.*?\*/", re.DOTALL)
    # Also detect VHDL entities for mixed-language packages
    VHDL_ENTITY_RE = re.compile(r"^\s*entity\s+(\w+)\s+is\b", re.MULTILINE | re.IGNORECASE)

    _SV_KEYWORDS = {
        "module", "endmodule", "input", "output", "inout", "wire", "reg",
        "logic", "assign", "always", "initial", "begin", "end", "if",
        "else", "for", "while", "case", "endcase", "function",
        "endfunction", "task", "endtask", "generate", "endgenerate",
        "parameter", "localparam", "genvar", "integer", "real", "time",
        "posedge", "negedge", "or", "and", "not", "buf", "nand", "nor",
        "xor", "xnor", "pullup", "pulldown", "supply0", "supply1",
    }

    defined: set[str] = set()
    all_tokens: set[str] = set()

    for f in files:
        p = Path(f)
        suffix = p.suffix.lower()
        try:
            text = p.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue

        if suffix in (".v", ".sv", ".svh", ".vh"):
            for m in MODULE_DEF_RE.finditer(text):
                defined.add(m.group(1))
            stripped = COMMENT_LINE_RE.sub("", text)
            stripped = COMMENT_BLOCK_RE.sub("", stripped)
            all_tokens.update(re.findall(r"\w+", stripped))
        elif suffix in (".vhd", ".vhdl"):
            for m in VHDL_ENTITY_RE.finditer(text):
                defined.add(m.group(1))

    # module_deps = tokens that look like module names but aren't defined here
    # We can't know for sure what's a module vs a variable, so we only report
    # deps that match known patterns (this will be refined by the backfill
    # which has access to the full repo)
    modules_provided = sorted(defined)
    # For publish-time, we don't have the full entity_map to cross-reference,
    # so module_deps is left empty — the backfill populates it with repo context
    module_deps: list[str] = []

    return modules_provided, module_deps


@pkg_group.command(name="publish")
@click.option("--namespace", "-n", required=True, help="Target namespace (e.g. acme-corp).")
@click.option("--ip-yml", default="ip.yml", type=click.Path(exists=True), help="Path to ip.yml.")
def pkg_publish(namespace, ip_yml):
    """Publish a package version to the RouteRTL registry.

    \b
    Reads ip.yml (or --ip-yml path) for package name, version, library,
    and source file list. Requires prior `rr pkg login`.

    \b
    Examples:
        rr pkg publish --namespace acme-corp
        rr pkg publish -n my-team --ip-yml src/ip.yml
    """
    import json as _json
    import subprocess
    from urllib.error import HTTPError, URLError
    from urllib.request import Request, urlopen

    import yaml

    from sdk.engine.registry_auth import get_auth_token, get_registry_url

    token = get_auth_token()
    if not token:
        console.print("  [red]Not logged in.[/] Run: [cyan]rr pkg login[/]")
        sys.exit(1)

    # Read ip.yml
    manifest = yaml.safe_load(Path(ip_yml).read_text())
    name = manifest.get("name") or manifest.get("package")
    version = manifest.get("version")
    library = manifest.get("library", "work")

    if not name or not version:
        console.print("  [red]ip.yml must declare 'name' and 'version'.[/]")
        sys.exit(1)

    # Collect source files
    hdl = manifest.get("hdl", {})
    sources = hdl.get("files", manifest.get("sources", []))
    if not sources:
        console.print("  [red]No source files declared in ip.yml.[/]")
        sys.exit(1)

    # Verify all files exist
    missing = [s for s in sources if not Path(s).exists()]
    if missing:
        console.print(f"  [red]Missing source files:[/] {', '.join(missing)}")
        sys.exit(1)

    # P2.248: Detect VHDL library dependencies
    library_deps = _scan_library_deps(sources, library)
    # P2.251: Detect Verilog module definitions
    modules_provided, module_deps = _scan_module_info(sources)

    console.print(f"  Publishing [cyan]{namespace}/{name}[/] v{version}...")
    console.print("  Validating ip.yml...          [green]ok[/]")
    console.print(f"  Checking sources exist...     [green]ok[/] ({len(sources)} files)")
    if library_deps:
        console.print(f"  VHDL library deps:            [cyan]{', '.join(library_deps)}[/]")
    if modules_provided:
        console.print(f"  Modules provided:             [cyan]{', '.join(modules_provided[:5])}{'...' if len(modules_provided) > 5 else ''}[/]")

    # Get git commit SHA (best-effort)
    commit_sha = None
    try:
        commit_sha = subprocess.check_output(
            ["git", "rev-parse", "HEAD"], text=True, stderr=subprocess.DEVNULL
        ).strip()
    except (subprocess.CalledProcessError, FileNotFoundError):
        pass

    # Get git remote URL (best-effort)
    git_url = None
    try:
        git_url = subprocess.check_output(
            ["git", "remote", "get-url", "origin"], text=True, stderr=subprocess.DEVNULL
        ).strip()
    except (subprocess.CalledProcessError, FileNotFoundError):
        pass

    # Publish to registry
    registry = get_registry_url()
    url = f"{registry}/v1/{namespace}/{name}"
    payload = _json.dumps({
        "version": version,
        "commit_sha": commit_sha,
        "git_url": git_url,
        "library": library,
        "files": sources,
        "ip_yml": Path(ip_yml).read_text(),
        "library_deps": library_deps,
        "module_deps": module_deps,
        "modules_provided": modules_provided,
    }).encode()
    req = Request(url, data=payload, headers={
        "Content-Type": "application/json",
        "Authorization": f"Bearer {token}",
    })

    try:
        with urlopen(req, timeout=30) as resp:
            _json.loads(resp.read().decode())
    except HTTPError as exc:
        detail = "unknown error"
        try:
            detail = _json.loads(exc.read().decode()).get("detail", str(exc))
        except (ValueError, UnicodeDecodeError, AttributeError, KeyError):
            detail = str(exc)
        console.print("  Uploading to registry...      [red]FAILED[/]")
        console.print(f"  [red]{detail}[/]")
        sys.exit(1)
    except URLError as exc:
        console.print("  Uploading to registry...      [red]FAILED[/]")
        console.print(f"  [red]Connection error: {exc}[/]")
        sys.exit(1)

    console.print("  Uploading to registry...      [green]ok[/]")
    console.print()
    cli = _cli_name()
    console.print(f"  Published: [cyan]{namespace}/{name}[/] v{version}")
    console.print(f"  Install:   [dim]{cli} pkg add {namespace}/{name}[/]")


# ── backfill-deps ────────────────────────────────────────────────────────────


@pkg_group.command(name="backfill-deps")
def pkg_backfill_deps():
    """Backfill library_deps for all registry packages (admin).

    \b
    Fetches the catalog, installs each package locally (if not already
    present), scans VHDL files for external library refs, and PATCHes
    the registry via the admin endpoint.

    Requires admin scope on the auth token.
    """
    import json as _json
    from urllib.error import HTTPError, URLError
    from urllib.request import Request, urlopen

    from sdk.engine.registry_auth import get_auth_token, get_registry_url

    token = get_auth_token()
    if not token:
        console.print("[red]Not logged in.[/] Run: [cyan]rr pkg login[/]")
        sys.exit(1)

    registry = get_registry_url()

    # Fetch catalog
    console.print("[cyan]Fetching catalog...[/]")
    try:
        req = Request(f"{registry}/catalog.json", headers={"Authorization": f"Bearer {token}"})
        with urlopen(req, timeout=30) as resp:
            catalog = _json.loads(resp.read().decode())
    except (HTTPError, URLError) as exc:
        console.print(f"[red]Failed to fetch catalog: {exc}[/]")
        sys.exit(1)

    console.print(f"  Found [cyan]{len(catalog)}[/] packages")

    updated = 0
    skipped = 0
    errors = 0

    for entry in catalog:
        ns = entry["namespace"]
        name = entry["name"]
        versions = entry.get("versions", [])
        existing_deps = entry.get("library_deps", [])

        # If latest already has deps, skip (heuristic — could still have
        # older versions without deps, but good enough for backfill)
        if existing_deps:
            skipped += len(versions)
            continue

        for version in versions:
            pkg_ref = f"{ns}/{name}@{version}"

            # Fetch version entry to get file list and git URL
            try:
                vreq = Request(
                    f"{registry}/packages/{ns}/{name}/{version}.yml",
                    headers={"Authorization": f"Bearer {token}"},
                )
                import yaml
                with urlopen(vreq, timeout=30) as resp:
                    ventry = yaml.safe_load(resp.read().decode())
            except (HTTPError, URLError, OSError, ValueError) as exc:
                console.print(f"  [yellow]skip[/] {pkg_ref} — fetch failed ({exc})")
                skipped += 1
                continue

            compat = ventry.get("routertl_compat", {})
            files = compat.get("files", [])
            library = compat.get("library", "work")

            # Check if already fully populated
            has_lib_deps = bool(compat.get("library_deps"))
            has_modules = bool(compat.get("modules_provided"))
            if has_lib_deps and has_modules:
                skipped += 1
                continue

            vhdl_files = [f for f in files if f.endswith((".vhd", ".vhdl"))]
            sv_files = [f for f in files if f.endswith((".v", ".sv"))]
            if not vhdl_files and not sv_files:
                skipped += 1
                continue

            # Clone and scan
            git_url = (ventry.get("source") or {}).get("url")
            if not git_url:
                skipped += 1
                continue

            import tempfile
            try:
                import subprocess
                with tempfile.TemporaryDirectory() as tmpdir:
                    tmppath = Path(tmpdir)
                    # Try v{version} tag first, fall back to default branch
                    # for packages published with non-semver versions (e.g. "main")
                    cloned = False
                    for ref in [f"v{version}", version]:
                        try:
                            subprocess.run(
                                ["git", "clone", "--depth=1", "--branch", ref,
                                 "--single-branch", "--quiet", git_url, str(tmppath / "repo")],
                                check=True, capture_output=True, text=True, timeout=60,
                            )
                            cloned = True
                            break
                        except subprocess.CalledProcessError:
                            continue
                    if not cloned:
                        # Last resort: clone default branch
                        subprocess.run(
                            ["git", "clone", "--depth=1", "--quiet", git_url, str(tmppath / "repo")],
                            check=True, capture_output=True, text=True, timeout=60,
                        )
                    # Scan VHDL library deps
                    library_deps = _scan_library_deps(
                        [str(tmppath / "repo" / f) for f in vhdl_files],
                        library,
                    ) if vhdl_files else []
                    # Scan Verilog module info
                    all_files_abs = [str(tmppath / "repo" / f) for f in files]
                    modules_provided, module_deps = _scan_module_info(all_files_abs)
            except (subprocess.CalledProcessError, subprocess.TimeoutExpired):
                console.print(f"  [yellow]skip[/] {pkg_ref} — clone failed")
                skipped += 1
                continue

            if not library_deps and not modules_provided and not module_deps:
                skipped += 1
                continue

            # PATCH the registry
            try:
                patch_data = {
                    "namespace": ns,
                    "name": name,
                    "version": version,
                }
                if library_deps:
                    patch_data["library_deps"] = library_deps
                if modules_provided:
                    patch_data["modules_provided"] = modules_provided
                if module_deps:
                    patch_data["module_deps"] = module_deps
                payload = _json.dumps(patch_data).encode()
                preq = Request(
                    f"{registry}/admin/library-deps",
                    data=payload,
                    method="PATCH",
                    headers={
                        "Content-Type": "application/json",
                        "Authorization": f"Bearer {token}",
                    },
                )
                with urlopen(preq, timeout=30) as resp:
                    _json.loads(resp.read().decode())
                parts = []
                if library_deps:
                    parts.append(f"libs: {', '.join(library_deps)}")
                if modules_provided:
                    parts.append(f"provides: {len(modules_provided)} modules")
                if module_deps:
                    parts.append(f"needs: {', '.join(module_deps)}")
                console.print(f"  [green]updated[/] {pkg_ref} — {'; '.join(parts)}")
                updated += 1
            except HTTPError as exc:
                detail = "unknown"
                try:
                    detail = _json.loads(exc.read().decode()).get("detail", str(exc))
                except (ValueError, UnicodeDecodeError, AttributeError, KeyError):
                    detail = str(exc)
                console.print(f"  [red]error[/] {pkg_ref} — {detail}")
                errors += 1

    console.print()
    console.print(f"[green]Done.[/] Updated: {updated}, Skipped: {skipped}, Errors: {errors}")


# ── outdated ───────────────────────────────────────────────────────────────────
# RTL-P2.320


def _installed_vs_available(pkg_ref: str, installed: str, constraint: str, catalog: list) -> dict:
    """Compare installed version to what's available in the catalog.

    Returns a dict with: pkg_ref, installed, constraint, latest_compatible,
    latest_absolute, status. ``status`` is one of:
      - "up-to-date":      installed == latest_compatible
      - "compatible":      newer compatible version exists
      - "major":           no newer compatible version, but a newer major exists
      - "local":           constraint is "local" — skipped
      - "unversioned":     catalog entry has no tagged versions
      - "missing":         catalog has no such package
      - "unknown":         couldn't determine (e.g. bad constraint)
    """
    from sdk.engine.index_client import _parse_ver, resolve_version

    namespace, _, name = pkg_ref.partition("/")
    row = {
        "pkg_ref": pkg_ref,
        "installed": installed,
        "constraint": constraint,
        "latest_compatible": None,
        "latest_absolute": None,
        "status": "unknown",
    }

    if constraint == "local":
        row["status"] = "local"
        return row

    state, latest = _catalog_lookup(catalog, namespace, name)
    if state == "missing":
        row["status"] = "missing"
        return row
    if state == "unversioned":
        row["status"] = "unversioned"
        return row

    row["latest_absolute"] = latest

    try:
        row["latest_compatible"] = resolve_version(namespace, name, constraint, catalog)
    except ValueError:
        row["latest_compatible"] = None

    if row["latest_compatible"] and installed == row["latest_compatible"]:
        # Only call it "major behind" if the registry's latest is genuinely
        # newer than the constraint's best — a stale `latest` field (older
        # than what `versions` offers) still counts as up-to-date.
        if latest and _parse_ver(latest) > _parse_ver(row["latest_compatible"]):
            row["status"] = "major"
        else:
            row["status"] = "up-to-date"
    elif row["latest_compatible"]:
        row["status"] = "compatible"
    else:
        row["status"] = "unknown"

    return row


@pkg_group.command(name="outdated")
@click.option("--refresh", is_flag=True, help="Bypass the 4h catalog cache.")
@click.option("--json", "as_json", is_flag=True, help="Machine-readable JSON output.")
def pkg_outdated(refresh: bool, as_json: bool):
    """List installed packages that have newer versions available.

    Compares each entry in ip.lock against the registry catalog and reports
    which ones have compatible updates (within the constraint in project.yml)
    and which are locked behind a newer major version.

    \b
    Examples:
        rr pkg outdated
        rr pkg outdated --refresh        # force-fetch the catalog
        rr pkg outdated --json           # for CI / scripting
    """
    import json as _json

    from sdk.cli.project_config import load_project_config
    from sdk.engine.index_client import fetch_catalog, get_index_url
    from sdk.engine.package_resolver import load_lock

    lock = load_lock(Path.cwd())
    if not lock:
        if as_json:
            click.echo(_json.dumps({"packages": []}))
            return
        console.print("  [dim]No ip.lock found. Run:[/] [cyan]rr pkg install[/]")
        return

    config = {}
    if os.path.exists("project.yml"):
        config = load_project_config()
    declared = (config.get("packages") or {}) if config else {}

    index_url = get_index_url(config)
    cache_dir = Path(".routertl_cache/index")
    try:
        catalog = fetch_catalog(index_url, cache_dir, force_refresh=refresh)
    except (RuntimeError, ValueError, OSError) as exc:
        if as_json:
            click.echo(_json.dumps({"error": str(exc), "packages": []}))
            sys.exit(1)
        console.print(f"❌ [red]Could not reach index: {exc}[/]")
        sys.exit(1)

    rows = []
    for pkg_ref, entry in sorted(lock.items()):
        installed = entry.get("resolved_version", "")
        constraint = declared.get(pkg_ref, "")  # empty means transitive-only
        rows.append(_installed_vs_available(pkg_ref, installed, constraint, catalog))

    if as_json:
        click.echo(_json.dumps({"packages": rows}, indent=2))
        return

    status_icons = {
        "up-to-date": "[green]✓ up-to-date[/]",
        "compatible": "[yellow]⬆ update available[/]",
        "major": "[magenta]⬆⬆ new major available[/]",
        "local": "[dim]🔒 local[/]",
        "unversioned": "[dim]— no versions[/]",
        "missing": "[red]✗ not in catalog[/]",
        "unknown": "[dim]?[/]",
    }

    table = Table(show_header=True, header_style="bold cyan", box=None, padding=(0, 2))
    table.add_column("Package", style="cyan")
    table.add_column("Installed", style="green")
    table.add_column("Constraint", style="dim")
    table.add_column("Latest compat.", style="yellow")
    table.add_column("Latest", style="magenta")
    table.add_column("Status")

    counts = {k: 0 for k in status_icons}
    for r in rows:
        counts[r["status"]] = counts.get(r["status"], 0) + 1
        table.add_row(
            r["pkg_ref"],
            r["installed"] or "-",
            r["constraint"] or "[dim](transitive)[/]",
            r["latest_compatible"] or "-",
            r["latest_absolute"] or "-",
            status_icons.get(r["status"], r["status"]),
        )

    console.print(f"\n📦 [cyan]Package status[/] ({len(rows)} total)\n")
    console.print(table)

    summary_bits = []
    if counts.get("compatible"):
        summary_bits.append(f"[yellow]{counts['compatible']} updatable[/]")
    if counts.get("major"):
        summary_bits.append(f"[magenta]{counts['major']} major behind[/]")
    if counts.get("missing"):
        summary_bits.append(f"[red]{counts['missing']} missing[/]")
    if summary_bits:
        console.print("\n  " + "  •  ".join(summary_bits))
        console.print("\n  [dim]Run[/] [cyan]rr pkg update[/] [dim]to apply compatible updates.[/]")
    else:
        console.print("\n  [green]All packages are up to date.[/]")
    console.print()

    # Exit non-zero if there are actionable updates (useful for CI)
    if counts.get("compatible") or counts.get("missing"):
        sys.exit(1)


# ── why ────────────────────────────────────────────────────────────────────────
# RTL-P3.157


def _build_reverse_deps(
    lock: dict[str, dict], project_root: Path
) -> dict[str, list[tuple[str, str]]]:
    """Return ``{child_ref: [(parent_ref, constraint), ...]}`` from installed ip.yml files.

    Walks every lock entry's ``local_path/ip.yml`` and reads its declared
    ``dependencies:`` dict. On-demand — no lockfile schema change needed.
    """
    from sdk.engine.package_resolver import _read_ip_deps

    reverse: dict[str, list[tuple[str, str]]] = {}
    for parent_ref, entry in lock.items():
        local_path = entry.get("local_path")
        if not local_path:
            continue
        ip_yml = project_root / local_path / "ip.yml"
        if not ip_yml.exists():
            continue
        deps = _read_ip_deps(ip_yml)
        for child_ref, constraint in deps.items():
            if isinstance(constraint, dict):
                constraint_str = constraint.get("version", "")
            else:
                constraint_str = str(constraint) if constraint else ""
            reverse.setdefault(child_ref, []).append((parent_ref, constraint_str))
    return reverse


def _trace_provenance(
    target: str,
    reverse: dict[str, list[tuple[str, str]]],
    declared: dict[str, str],
    *,
    max_depth: int = 10,
) -> list[list[tuple[str, str]]]:
    """Return every path from a project.yml-declared root down to ``target``.

    Each path is a list of ``(pkg_ref, constraint)`` tuples, root first,
    target last. If ``target`` is declared directly, returns a single
    one-element path. Cycles and orphans (unreachable from any root)
    return an empty list.
    """
    paths: list[list[tuple[str, str]]] = []

    def walk(current: str, trail: list[tuple[str, str]], seen: set):
        if len(trail) > max_depth:
            return
        if current in declared:
            paths.append([(current, declared[current])] + list(reversed(trail)))
            return
        parents = reverse.get(current, [])
        if not parents:
            if trail:
                paths.append([("(orphan)", "")] + list(reversed(trail)))
            return
        for parent, constraint_on_current in parents:
            if parent in seen:
                continue
            walk(parent, trail + [(current, constraint_on_current)], seen | {parent})

    walk(target, [], {target})
    return paths


@pkg_group.command(name="why")
@click.argument("package_ref", shell_complete=_complete_installed_pkg)
@click.option("--json", "as_json", is_flag=True, help="Machine-readable JSON output.")
def pkg_why(package_ref: str, as_json: bool):
    """Explain why a package is installed — provenance from project.yml roots.

    Shows every dependency chain that pulls PACKAGE_REF into this project:
    either the package is declared directly in project.yml, or it is a
    transitive dependency of one or more direct packages.

    \b
    Examples:
        rr pkg why open-logic/olo_base_fifo_async
        rr pkg why acme/cdc_sync --json
    """
    import json as _json

    from sdk.cli.project_config import load_project_config
    from sdk.engine.package_resolver import load_lock

    lock = load_lock(Path.cwd())
    if not lock:
        console.print("  [dim]No ip.lock found. Run:[/] [cyan]rr pkg install[/]")
        sys.exit(1)

    if package_ref not in lock:
        if as_json:
            click.echo(_json.dumps({"error": "not installed", "pkg_ref": package_ref}))
        else:
            console.print(f"❌ [red]'{package_ref}' is not installed.[/]")
            known = sorted(lock.keys())[:5]
            console.print(f"   [dim]Known packages:[/] {', '.join(known)}...")
        sys.exit(1)

    config = load_project_config() if os.path.exists("project.yml") else {}
    declared = config.get("packages") or {}
    reverse = _build_reverse_deps(lock, Path.cwd())
    paths = _trace_provenance(package_ref, reverse, declared)

    lock_entry = lock[package_ref]
    installed_version = lock_entry.get("resolved_version", "")

    if as_json:
        click.echo(_json.dumps({
            "pkg_ref": package_ref,
            "installed": installed_version,
            "direct": package_ref in declared,
            "declared_constraint": declared.get(package_ref),
            "paths": [
                [{"pkg_ref": ref, "constraint": c} for ref, c in path]
                for path in paths
            ],
        }, indent=2))
        return

    console.print(f"\n📦 [cyan]{package_ref}[/] [dim]@[/] [green]{installed_version}[/]")

    if package_ref in declared:
        console.print(
            f"\n  [green]✓ Declared directly[/] in project.yml "
            f"(constraint: [yellow]{declared[package_ref]}[/])"
        )
        console.print()
        return

    if not paths:
        console.print(
            "\n  [yellow]⚠ No provenance chain found.[/] "
            "Package is installed but not reachable from project.yml."
        )
        console.print("   [dim]Likely orphaned — re-run[/] [cyan]rr pkg install[/].")
        console.print()
        sys.exit(1)

    console.print(f"\n  [dim]Required by {len(paths)} chain(s):[/]\n")
    for idx, path in enumerate(paths, 1):
        console.print(f"  [bold]{idx}.[/]")
        for depth, (ref, constraint) in enumerate(path):
            prefix = "    " + "  " * depth
            marker = "└─" if depth == len(path) - 1 else "├─"
            constraint_bit = f" [dim]({constraint})[/]" if constraint else ""
            if ref == "(orphan)":
                style = "yellow"
            elif ref in declared:
                style = "green"
            else:
                style = "cyan"
            console.print(f"{prefix}{marker} [{style}]{ref}[/]{constraint_bit}")
    console.print()


# ── remove ─────────────────────────────────────────────────────────────────────
# RTL-P2.319


def _remove_package_from_project_yml(pkg_ref: str) -> bool:
    """Delete a packages: entry from project.yml. Returns True if removed."""
    import yaml as _yaml

    yml_path = Path("project.yml")
    if not yml_path.exists():
        return False
    with open(yml_path) as f:
        config = _yaml.safe_load(f) or {}
    if not isinstance(config, dict):
        return False
    packages = config.get("packages") or {}
    if pkg_ref not in packages:
        return False
    del packages[pkg_ref]
    if not packages:
        config.pop("packages", None)
    else:
        config["packages"] = packages
    with open(yml_path, "w") as f:
        _yaml.dump(config, f, default_flow_style=False, sort_keys=False, allow_unicode=True)
    return True


def _remove_package_from_lock(pkg_ref: str, project_root: Path) -> bool:
    """Delete a package entry from ip.lock. Returns True if removed."""
    import yaml as _yaml

    from sdk.engine.package_resolver import LOCK_FILE

    lock_path = project_root / LOCK_FILE
    if not lock_path.exists():
        return False
    with open(lock_path) as f:
        data = _yaml.safe_load(f) or {}
    if pkg_ref not in data:
        return False
    del data[pkg_ref]
    with open(lock_path, "w") as f:
        _yaml.dump(data, f, default_flow_style=False, sort_keys=False, allow_unicode=True)
    return True


@pkg_group.command(name="remove")
@click.argument("package_ref", shell_complete=_complete_installed_pkg)
@click.option("--force", is_flag=True, help="Remove even if other installed packages depend on it.")
@click.option("--dry-run", is_flag=True, help="Show what would be removed without changing anything.")
@click.option("--keep-files", is_flag=True, help="Update project.yml and ip.lock but leave libs/<ns>/<name>/ on disk.")
def pkg_remove(package_ref: str, force: bool, dry_run: bool, keep_files: bool):
    """Remove a package cleanly: project.yml, ip.lock, and libs/<ns>/<name>/.

    Blocks by default if another installed package declares PACKAGE_REF as
    a dependency (use ``--force`` to proceed anyway). Transitive-only
    removal is allowed but warned — the next ``rr pkg install`` will
    pull it back while a direct parent still needs it.

    \b
    Examples:
        rr pkg remove open-logic/olo_base_fifo_async
        rr pkg remove acme/cdc_sync --dry-run
        rr pkg remove acme/cdc_sync --force
    """
    import shutil

    from sdk.cli.project_config import load_project_config
    from sdk.engine.package_resolver import load_lock

    project_root = Path.cwd()
    lock = load_lock(project_root)
    if not lock:
        console.print("  [dim]No ip.lock found — nothing to remove.[/]")
        sys.exit(1)

    if package_ref not in lock:
        console.print(f"❌ [red]'{package_ref}' is not installed.[/]")
        sys.exit(1)

    config = load_project_config() if os.path.exists("project.yml") else {}
    declared = config.get("packages") or {}
    is_direct = package_ref in declared
    reverse = _build_reverse_deps(lock, project_root)
    dependents = reverse.get(package_ref, [])

    lock_entry = lock[package_ref]
    local_path = lock_entry.get("local_path", "")

    # ── Safety check: other installed packages depend on this one ──
    if dependents and not force:
        console.print(
            f"❌ [red]Cannot remove[/] [cyan]{package_ref}[/] — "
            f"{len(dependents)} installed package(s) depend on it:"
        )
        for parent, constraint in dependents:
            c = f" [dim]({constraint})[/]" if constraint else ""
            console.print(f"    • [yellow]{parent}[/]{c}")
        console.print(
            "\n  Re-run with [cyan]--force[/] to remove anyway, or "
            "remove the dependents first."
        )
        sys.exit(1)

    # ── Build the action list ──
    actions: list[str] = []
    if is_direct:
        actions.append(f"remove [cyan]{package_ref}[/] from [bold]project.yml[/]")
    else:
        actions.append(
            "[dim](not in project.yml — was a transitive dep)[/]"
        )
    actions.append(f"remove [cyan]{package_ref}[/] from [bold]ip.lock[/]")
    fs_target: Path | None = None
    if local_path and not keep_files:
        fs_target = (project_root / local_path).resolve()
        # Safety: must live under project_root (prevent surprise path escapes).
        try:
            fs_target.relative_to(project_root.resolve())
        except ValueError:
            console.print(
                f"❌ [red]Refusing to delete suspicious path:[/] {fs_target}\n"
                "   [dim]local_path in ip.lock escapes the project root.[/]"
            )
            sys.exit(1)
        if fs_target.exists():
            actions.append(f"delete directory [dim]{local_path}/[/]")
        else:
            actions.append(f"[dim]directory {local_path}/ already absent[/]")

    console.print(f"\n📦 [cyan]rr pkg remove {package_ref}[/]\n")
    if dependents and force:
        console.print(
            f"  [yellow]⚠ Removing despite {len(dependents)} dependent(s) "
            "(--force). rr pkg install will refuse to reinstall unless you "
            "also remove the parent(s) or drop the dep from their ip.yml.[/]\n"
        )
    elif not is_direct:
        console.print(
            "  [yellow]⚠ Transitive-only removal — nothing in project.yml "
            "pulls this package directly, but a subsequent "
            "[cyan]rr pkg install[/] [yellow]may reinstall it if a parent's "
            "ip.yml still declares it as a dependency.[/]\n"
        )

    for action in actions:
        console.print(f"  • {action}")
    console.print()

    if dry_run:
        console.print("  [dim]Dry-run — no changes applied.[/]\n")
        return

    # ── Apply ──
    if is_direct:
        _remove_package_from_project_yml(package_ref)
    _remove_package_from_lock(package_ref, project_root)
    if fs_target is not None and fs_target.exists():
        shutil.rmtree(fs_target)

    console.print(f"  [green]✓[/] removed [cyan]{package_ref}[/]\n")


# ── rr pkg orphans ────────────────────────────────────────────────
# RTL-P3.161: flag catalog entries that have no corresponding curated
# repo.  Those entries can't be regenerated by rescan_all — they
# either snuck in via the submit endpoint and never got proper
# metadata, or they're stale from an earlier scan source.

import json as _json
from urllib.parse import urlparse as _urlparse


def _load_curated_namespaces(curated_path: Path) -> set[str]:
    """Return the set of GitHub/other owner segments covered by
    curated_repos.json — every catalog entry whose namespace matches
    one of these can, in principle, be re-derived by a rescan.
    """
    if not curated_path.is_file():
        return set()
    try:
        data = _json.loads(curated_path.read_text())
    except (OSError, ValueError):
        return set()
    repos = data.get("repos", {}) if isinstance(data, dict) else {}
    ns: set[str] = set()
    for url in repos.keys():
        try:
            parsed = _urlparse(url)
        except ValueError:
            continue
        # GitHub-style: github.com/<owner>/<repo>.git → owner is the
        # first path segment.  Same convention across the index
        # today; if we ever host non-GitHub repos, the matching rule
        # here is what to extend.
        parts = [p for p in parsed.path.split("/") if p]
        if parts:
            ns.add(parts[0].lower())
        # A curated entry may also pin an explicit namespace override.
        meta = repos.get(url) or {}
        if isinstance(meta, dict):
            explicit = meta.get("namespace")
            if explicit and explicit != "_skip":
                ns.add(str(explicit).lower())
    return ns


def _find_orphan_entries(catalog: list, curated_ns: set[str]) -> list[dict]:
    """Return catalog entries whose namespace is not covered by any
    curated repo.  Uses lowercase comparison and tolerates missing or
    malformed entries.
    """
    orphans = []
    for entry in catalog:
        if not isinstance(entry, dict):
            continue
        ns = (entry.get("namespace") or "").lower()
        if not ns:
            continue
        if ns not in curated_ns:
            orphans.append(entry)
    return orphans


@pkg_group.command(name="orphans")
@click.option(
    "--catalog-file",
    type=click.Path(exists=True, dir_okay=False, path_type=Path),
    default=None,
    help="Read the catalog from a local JSON file instead of fetching it "
         "from the live index — useful for offline triage.",
)
@click.option(
    "--curated",
    type=click.Path(exists=True, dir_okay=False, path_type=Path),
    default=None,
    help="Path to curated_repos.json (defaults to sdk/registry/"
         "curated_repos.json shipped with the SDK).",
)
@click.option(
    "--json", "as_json", is_flag=True,
    help="Emit the orphan list as JSON instead of a table — for piping "
         "into a triage script.",
)
def pkg_orphans(catalog_file, curated, as_json):
    """List catalog entries with no curated_repos.json backing (RTL-P3.161).

    An "orphan" is a catalog entry whose namespace is not represented in
    curated_repos.json, meaning ``rescan_all`` cannot regenerate it.
    Surfaces them so they can be triaged:

    \b
      (a) curate — add the repo to curated_repos.json and rescan
      (b) delete — remove from the registry via the admin endpoint
      (c) re-ingest — ask the owner to re-submit with a README

    Examples:

    \b
        rr pkg orphans                              # live catalog vs shipped curated
        rr pkg orphans --catalog-file cat.json      # offline triage
        rr pkg orphans --json | jq '.[].name'       # pipe for scripting
    """
    # Resolve curated_repos.json
    if curated is None:
        from sdk.cli.sdk_root import resolve_sdk_root
        sdk_root = resolve_sdk_root()
        if sdk_root:
            curated = Path(sdk_root) / "sdk" / "registry" / "curated_repos.json"
    if not curated or not curated.is_file():
        console.print(
            "❌ [red]curated_repos.json not found.[/]  Pass --curated "
            "<path> or run this command from an SDK checkout."
        )
        sys.exit(1)

    curated_ns = _load_curated_namespaces(curated)

    # Resolve the catalog — local file or live fetch.
    if catalog_file:
        try:
            catalog = _json.loads(Path(catalog_file).read_text())
        except (OSError, ValueError) as exc:
            console.print(f"❌ [red]Failed to parse {catalog_file}: {exc}[/]")
            sys.exit(1)
    else:
        from sdk.cli.project_config import load_project_config
        from sdk.engine.index_client import fetch_catalog, get_index_url

        config = {}
        if os.path.exists("project.yml"):
            config = load_project_config()
        try:
            catalog = fetch_catalog(get_index_url(config), Path(".routertl_cache/index"))
        except (RuntimeError, ValueError, OSError) as exc:
            console.print(f"❌ [red]Could not reach index: {exc}[/]")
            sys.exit(1)

    if not isinstance(catalog, list):
        console.print("❌ [red]Catalog payload is not a list — nothing to scan.[/]")
        sys.exit(1)

    orphans = _find_orphan_entries(catalog, curated_ns)

    if as_json:
        click.echo(_json.dumps(orphans, indent=2, sort_keys=True))
        return

    if not orphans:
        console.print(
            f"  [green]✅ No orphans.[/]  All {len(catalog)} catalog "
            f"entries trace back to curated_repos.json "
            f"({len(curated_ns)} namespaces covered).\n"
        )
        return

    console.print(
        f"\n⚠  [yellow bold]{len(orphans)} orphan catalog "
        f"entries[/]  [dim]({len(catalog)} total, "
        f"{len(curated_ns)} curated namespaces)[/]\n"
    )
    table = Table(
        show_header=True, header_style="bold cyan", box=None, padding=(0, 2),
    )
    table.add_column("Namespace", style="yellow")
    table.add_column("Name", style="cyan")
    table.add_column("Latest", style="green")
    table.add_column("Role", style="dim")
    for e in orphans:
        table.add_row(
            e.get("namespace", "?"),
            e.get("name", "?"),
            str(e.get("latest", "-")),
            e.get("role", "top"),
        )
    console.print(table)
    console.print(
        "\n  [dim]Decide per entry: (a) curate — add to "
        "curated_repos.json + rescan; (b) delete via admin; (c) "
        "re-ingest with proper README.[/]\n"
    )


# ── audit ──────────────────────────────────────────────────────────────────────
# RTL-P2.322

_AUDIT_SEVERITY_ORDER = ["low", "medium", "high"]


def _split_spdx_tokens(expr: str) -> list[str]:
    """Best-effort split of an SPDX expression into bare license ids.

    Handles OR / AND / WITH / parens. Not a full SPDX parser — just enough
    to spot any individual identifier in an allow/deny list. Case preserved.
    """
    if not expr:
        return []
    for sep in (" OR ", " or ", " AND ", " and ", " WITH ", " with ", "(", ")"):
        expr = expr.replace(sep, " ")
    return [t.strip() for t in expr.split() if t.strip()]


def _match_license(tokens: list[str], patterns: list[str]) -> list[str]:
    """Return the subset of ``tokens`` that case-insensitively matches any pattern."""
    plow = {p.strip().lower() for p in patterns if p and str(p).strip()}
    return [t for t in tokens if t.lower() in plow]


def _load_license_policy(project_yml_path: Path) -> dict | None:
    """Read ``license_policy`` from project.yml root (bypasses target: redirect).

    Target files are per-board and license policy is project-wide, so we read
    the root yml directly rather than going through ``load_project_config``.
    Returns ``None`` if no policy is declared or the block is empty.
    """
    if not project_yml_path.exists():
        return None
    try:
        import yaml as _yaml
        raw = _yaml.safe_load(project_yml_path.read_text()) or {}
    except (OSError, ValueError):
        return None
    if not isinstance(raw, dict):
        return None
    policy = raw.get("license_policy")
    if not isinstance(policy, dict):
        return None
    normalised = {
        "allow": list(policy.get("allow") or []),
        "deny": list(policy.get("deny") or []),
        "strict": bool(policy.get("strict", False)),
    }
    if not normalised["allow"] and not normalised["deny"] and not normalised["strict"]:
        return None
    return normalised


def _check_license_against_policy(
    spdx: str,
    license_policy: dict | None,
    *,
    unknown_source_phrase: str = "Catalog has no license declared for this package",
) -> list[dict]:
    """Run allow/deny/strict checks on a resolved SPDX string.

    Shared by the lock-entry audit (registry packages) and the vendored-IP
    audit (local IPs).  Returns at most one finding — ``LICENSE_DENIED``,
    ``LICENSE_OUTSIDE_ALLOW``, or ``LICENSE_UNKNOWN`` (strict mode only).
    Empty list means "passes".
    """
    if not license_policy:
        return []

    deny = license_policy.get("deny") or []
    allow = license_policy.get("allow") or []
    strict = bool(license_policy.get("strict", False))

    if not spdx:
        if strict:
            return [{
                "code": "LICENSE_UNKNOWN",
                "severity": "high",
                "message": unknown_source_phrase,
                "hint": "Ask upstream to declare SPDX, or relax license_policy.strict",
            }]
        return []

    tokens = _split_spdx_tokens(spdx)
    matched_deny = _match_license(tokens, deny)
    if matched_deny:
        return [{
            "code": "LICENSE_DENIED",
            "severity": "high",
            "message": f"License {spdx} matches deny policy ({', '.join(matched_deny)})",
            "hint": "Remove the dependency or obtain a policy waiver",
        }]
    if allow:
        matched_allow = _match_license(tokens, allow)
        if not matched_allow:
            return [{
                "code": "LICENSE_OUTSIDE_ALLOW",
                "severity": "medium",
                "message": f"License {spdx} is not in the allow list",
                "hint": f"Permitted: {', '.join(allow)}",
            }]
    return []


def _audit_lock_entry(
    pkg_ref: str,
    installed: str,
    catalog_entry: dict | None,
    license_policy: dict | None,
) -> list[dict]:
    """Return a list of finding dicts for one locked package.

    Finding = ``{code, severity, message, hint}``.  Severity is one of
    ``low`` / ``medium`` / ``high``.
    """
    findings: list[dict] = []

    if catalog_entry is None:
        findings.append({
            "code": "DROPPED",
            "severity": "high",
            "message": "Package not in catalog",
            "hint": "Namespace may be archived or repo deleted — rr pkg why " + pkg_ref,
        })
        return findings

    versions = catalog_entry.get("versions") or []
    if installed and versions and installed not in versions:
        preview = ", ".join(versions[:5]) + ("…" if len(versions) > 5 else "")
        findings.append({
            "code": "VERSION_GONE",
            "severity": "medium",
            "message": f"Pinned version {installed} no longer listed in catalog",
            "hint": f"Catalog offers: {preview}",
        })

    spdx = (catalog_entry.get("license") or "").strip()
    findings.extend(_check_license_against_policy(spdx, license_policy))

    return findings


# ── Vendored IP discovery (RTL-P3.187) ─────────────────────────────────────────

_VENDORED_IP_ROOTS = ("hw/ip", "src/ip", "ip")
_VENDORED_HDL_EXTS = (".vhd", ".vhdl", ".v", ".sv", ".svh")
_SPDX_HEADER_RE = re.compile(r"SPDX-License-Identifier:\s*([A-Za-z0-9\-.+ ()]+?)\s*(?:$|\*/|-->)", re.MULTILINE)
_SPDX_HEADER_SCAN_BYTES = 4096  # only scan the file's first few KB for SPDX


def _find_vendored_license(ip_dir: Path, ip_yml_data: dict) -> tuple[str | None, str | None]:
    """Resolve the license for a vendored IP.

    Priority:
      1. Top-level ``license`` field in ip.yml (registry schema) OR
         ``ip.license`` nested under the ``ip:`` block (vendored schema).
         Root-level wins when both are present — that's the registry-
         canonical position we want authors to converge toward.
      2. First ``SPDX-License-Identifier:`` header found in any HDL file
         under ip_dir
      3. Presence of a ``LICENSE*`` file at the IP root (SPDX unknown,
         but the IP is not license-less)

    Returns ``(spdx_or_None, source)``:
      * ``source`` is one of ``"ip_yml"``, ``"spdx_header"``,
        ``"license_file"``, or ``None`` (nothing found).
      * When source is ``"license_file"``, the SPDX is ``None`` — the
        file exists but its content is not parsed.
    """
    # Check both ip.yml schemas (root-level registry shape, then nested
    # vendored shape). Empty / missing falls through.
    declared = ""
    root_license = ip_yml_data.get("license")
    if isinstance(root_license, str):
        declared = root_license.strip()
    if not declared:
        ip_block = ip_yml_data.get("ip") or {}
        if isinstance(ip_block, dict):
            nested = ip_block.get("license")
            if isinstance(nested, str):
                declared = nested.strip()
    if declared:
        return declared, "ip_yml"

    # Walk HDL files looking for an SPDX-License-Identifier header.
    for path in sorted(ip_dir.rglob("*")):
        if not path.is_file():
            continue
        if path.suffix.lower() not in _VENDORED_HDL_EXTS:
            continue
        try:
            head = path.read_bytes()[:_SPDX_HEADER_SCAN_BYTES].decode("utf-8", errors="replace")
        except OSError:
            continue
        m = _SPDX_HEADER_RE.search(head)
        if m:
            return m.group(1).strip(), "spdx_header"

    # Fall back to bare LICENSE file presence.
    for candidate in ("LICENSE", "LICENSE.md", "LICENSE.txt", "COPYING"):
        if (ip_dir / candidate).exists():
            return None, "license_file"

    return None, None


def _collect_hdl_files(ip_dir: Path) -> list[Path]:
    """Return a sorted list of HDL source files under ``ip_dir``."""
    results: list[Path] = []
    for path in ip_dir.rglob("*"):
        if not path.is_file():
            continue
        if path.suffix.lower() not in _VENDORED_HDL_EXTS:
            continue
        # Skip generated trees that sometimes dump HDL under the IP dir.
        parts = set(path.relative_to(ip_dir).parts)
        if parts & {"build", ".build", "xgui", ".ipx"}:
            continue
        results.append(path)
    return sorted(results)


def _discover_vendored_ips(project_root: Path) -> list[dict]:
    """Walk conventional vendored-IP roots and return per-IP metadata.

    Each entry is ``{name, path, ip_yml_data, component_xml, hdl_files,
    license, license_source}``.  ``ip_yml_data`` is the **normalized**
    dict (canonical unified shape per D.58 / RTL-P3.189) — legacy
    vendored/registry shapes are upgraded on read so every downstream
    consumer sees one shape.

    Silently skips directories whose ip.yml is malformed — the audit is
    diagnostic, not validating.
    """
    import yaml as _yaml

    from sdk.engine.ip_yml import normalize_ip_yml

    discovered: list[dict] = []
    seen_paths: set[Path] = set()
    for root in _VENDORED_IP_ROOTS:
        root_dir = project_root / root
        if not root_dir.is_dir():
            continue
        for ip_dir in sorted(root_dir.iterdir()):
            if not ip_dir.is_dir():
                continue
            ip_yml = ip_dir / "ip.yml"
            if not ip_yml.exists():
                continue
            if ip_dir.resolve() in seen_paths:
                continue
            seen_paths.add(ip_dir.resolve())

            try:
                raw = _yaml.safe_load(ip_yml.read_text()) or {}
            except (OSError, ValueError, _yaml.YAMLError):
                continue
            if not isinstance(raw, dict):
                continue

            ip_yml_data = normalize_ip_yml(raw)

            component_xml = ip_dir / "component.xml"
            hdl_files = _collect_hdl_files(ip_dir)
            spdx, license_source = _find_vendored_license(ip_dir, ip_yml_data)

            name = ip_yml_data.get("name") or ip_dir.name
            discovered.append({
                "name": name,
                "path": ip_dir,
                "ip_yml": ip_yml,
                "ip_yml_data": ip_yml_data,
                "component_xml": component_xml if component_xml.exists() else None,
                "hdl_files": hdl_files,
                "license": spdx,
                "license_source": license_source,
            })
    return discovered


def _audit_vendored_ip(ip_info: dict, license_policy: dict | None) -> list[dict]:
    """Emit findings for a single vendored IP.

    Finding codes introduced by RTL-P3.187:
      * ``UNPACKAGED``          — packaging.recipe declared but no component.xml
      * ``STALE_COMPONENT_XML`` — component.xml older than ip.yml or HDL
      * ``LICENSE_MISSING``     — no SPDX declaration + no LICENSE file

    Plus the shared license-policy codes (``LICENSE_DENIED``,
    ``LICENSE_OUTSIDE_ALLOW``, ``LICENSE_UNKNOWN``) when a resolved SPDX
    is available and the project declares a license_policy.

    The UNPACKAGED / STALE_COMPONENT_XML findings are gated on ip.yml
    declaring ``packaging.recipe`` — IPs without that field are not
    claiming to be IP-XACT packageable (vendored primitives, WIP) and
    audit stays silent about their (nonexistent) packaging state.
    LICENSE_MISSING still fires independently.
    """
    findings: list[dict] = []
    name = ip_info["name"]
    ip_yml: Path = ip_info["ip_yml"]
    component_xml: Path | None = ip_info["component_xml"]
    hdl_files: list[Path] = ip_info["hdl_files"]
    packaging = (ip_info["ip_yml_data"].get("packaging") or {}) if isinstance(
        ip_info["ip_yml_data"], dict,
    ) else {}
    packageable = bool(isinstance(packaging, dict) and packaging.get("recipe"))

    if packageable and component_xml is None:
        findings.append({
            "code": "UNPACKAGED",
            "severity": "medium",
            "message": "packaging.recipe declared but no component.xml",
            "hint": f"Run [cyan]rr synth run --dry-run[/] to see the plan, or invoke {packaging['recipe']} directly",
        })
    elif packageable and component_xml is not None:
        try:
            xml_mtime = component_xml.stat().st_mtime
        except OSError:
            xml_mtime = 0.0
        newer: list[str] = []
        try:
            if ip_yml.stat().st_mtime > xml_mtime:
                newer.append("ip.yml")
        except OSError:
            pass
        for hdl in hdl_files:
            try:
                if hdl.stat().st_mtime > xml_mtime:
                    newer.append(str(hdl.relative_to(ip_info["path"])))
                    if len(newer) >= 4:
                        break
            except OSError:
                continue
        if newer:
            preview = ", ".join(newer[:3]) + ("…" if len(newer) > 3 else "")
            findings.append({
                "code": "STALE_COMPONENT_XML",
                "severity": "medium",
                "message": f"component.xml is older than {preview}",
                "hint": f"Repackage {name} to pick up the source changes",
            })

    if ip_info["license_source"] is None:
        findings.append({
            "code": "LICENSE_MISSING",
            "severity": "medium",
            "message": "No SPDX-License-Identifier header and no LICENSE file",
            "hint": "Add SPDX headers to HDL or drop a LICENSE file at the IP root",
        })

    spdx = (ip_info.get("license") or "").strip()
    findings.extend(_check_license_against_policy(
        spdx,
        license_policy,
        unknown_source_phrase=f"Vendored IP {name} has no SPDX declaration",
    ))

    return findings


@pkg_group.command(name="audit")
@click.option("--refresh", is_flag=True, help="Bypass the 4h catalog cache.")
@click.option("--json", "as_json", is_flag=True, help="Machine-readable JSON output.")
@click.option(
    "--severity",
    type=click.Choice(["high", "medium", "low", "all"]),
    default="all",
    help="Minimum severity to display (findings below this are hidden).",
)
def pkg_audit(refresh: bool, as_json: bool, severity: str):
    """Audit installed + vendored IPs for policy violations and regressions.

    Walks ``ip.lock`` (registry-installed packages) AND ``hw/ip/`` /
    ``src/ip/`` / ``ip/`` (vendored IPs) and reports severity-tagged
    findings.

    \b
    Registry (ip.lock):
      * DROPPED               — package no longer in catalog (archived?)
      * VERSION_GONE          — pinned version not in catalog.versions[]

    \b
    Vendored (hw/ip/*/ip.yml):
      * UNPACKAGED            — ip.yml present but no component.xml
      * STALE_COMPONENT_XML   — component.xml older than ip.yml / HDL
      * LICENSE_MISSING       — no SPDX header and no LICENSE file

    \b
    Shared license policy:
      * LICENSE_DENIED        — license matches project.yml license_policy.deny
      * LICENSE_OUTSIDE_ALLOW — license not in license_policy.allow
      * LICENSE_UNKNOWN       — no license declared and license_policy.strict=true

    Exits non-zero when any HIGH finding is present, so CI can gate on it.

    \b
    Declare policy in project.yml (at root, not inside a target file):
        license_policy:
          allow: [MIT, BSD-3-Clause, Apache-2.0]
          deny:  [GPL-3.0-only, AGPL-3.0-only]
          strict: false

    \b
    Examples:
        rr pkg audit
        rr pkg audit --json              # CI-friendly
        rr pkg audit --severity high     # only gate-worthy findings
    """
    import json as _json

    from sdk.cli.project_config import load_project_config
    from sdk.engine.index_client import fetch_catalog, get_index_url
    from sdk.engine.package_resolver import load_lock

    project_root = Path.cwd()
    lock = load_lock(project_root)
    vendored = _discover_vendored_ips(project_root)

    if not lock and not vendored:
        if as_json:
            click.echo(_json.dumps({"findings": [], "summary": {"total": 0, "high": 0, "medium": 0, "low": 0}}))
            return
        console.print(
            "  [dim]Nothing to audit: no ip.lock and no hw/ip/*/ip.yml found.[/]\n"
            "  [dim]Run:[/] [cyan]rr pkg install[/] [dim]or vendor an IP under[/] [cyan]hw/ip/[/]."
        )
        return

    config = {}
    project_yml = project_root / "project.yml"
    if project_yml.exists():
        config = load_project_config()
    license_policy = _load_license_policy(project_yml)

    catalog_by_ref: dict[str, dict] = {}
    if lock:
        index_url = get_index_url(config)
        cache_dir = Path(".routertl_cache/index")
        try:
            catalog = fetch_catalog(index_url, cache_dir, force_refresh=refresh)
        except (RuntimeError, ValueError, OSError) as exc:
            if as_json:
                click.echo(_json.dumps({"error": str(exc), "findings": []}))
                sys.exit(1)
            console.print(f"❌ [red]Could not reach index: {exc}[/]")
            sys.exit(1)

        for e in catalog or []:
            ns = e.get("namespace", "")
            nm = e.get("name", "")
            if ns and nm:
                catalog_by_ref[f"{ns}/{nm}"] = e

    findings_all: list[dict] = []
    for pkg_ref, entry in sorted(lock.items()):
        installed = entry.get("resolved_version", "")
        catalog_entry = catalog_by_ref.get(pkg_ref)
        for f in _audit_lock_entry(pkg_ref, installed, catalog_entry, license_policy):
            f["pkg_ref"] = pkg_ref
            f["installed"] = installed
            f["source"] = "registry"
            findings_all.append(f)

    for ip_info in vendored:
        for f in _audit_vendored_ip(ip_info, license_policy):
            f["pkg_ref"] = ip_info["name"]
            f["installed"] = "local"
            f["source"] = "local"
            f["path"] = str(ip_info["path"].relative_to(project_root))
            findings_all.append(f)

    def _passes(f: dict) -> bool:
        if severity == "all":
            return True
        return _AUDIT_SEVERITY_ORDER.index(f["severity"]) >= _AUDIT_SEVERITY_ORDER.index(severity)

    shown = [f for f in findings_all if _passes(f)]

    summary = {
        "total": len(findings_all),
        "high": sum(1 for f in findings_all if f["severity"] == "high"),
        "medium": sum(1 for f in findings_all if f["severity"] == "medium"),
        "low": sum(1 for f in findings_all if f["severity"] == "low"),
    }

    total_sources = len(lock) + len(vendored)
    source_label = f"{len(lock)} registry + {len(vendored)} vendored"

    if as_json:
        click.echo(_json.dumps({
            "policy": license_policy,
            "findings": shown,
            "summary": {
                **summary,
                "registry_packages": len(lock),
                "vendored_ips": len(vendored),
            },
        }, indent=2))
    else:
        if not findings_all:
            console.print(
                f"\n  [green]✅ Audit clean — {total_sources} IP(s) reviewed "
                f"({source_label}).[/]\n"
            )
            if not license_policy:
                console.print(
                    "  [dim]Tip: declare [cyan]license_policy[/] in project.yml to enable "
                    "license checks.[/]\n"
                )
            return

        sev_style = {
            "high": "[red bold]HIGH[/]",
            "medium": "[yellow]MED[/]",
            "low": "[dim]LOW[/]",
        }
        table = Table(show_header=True, header_style="bold cyan", box=None, padding=(0, 2))
        table.add_column("Severity")
        table.add_column("Source")
        table.add_column("Package", style="cyan")
        table.add_column("Code")
        table.add_column("Message")
        for f in shown:
            table.add_row(
                sev_style.get(f["severity"], f["severity"]),
                f.get("source", "-"),
                f["pkg_ref"],
                f["code"],
                f["message"],
            )
        console.print(
            f"\n🔍 [cyan]pkg audit[/] — {source_label}, "
            f"{summary['high']}H / {summary['medium']}M / {summary['low']}L findings\n"
        )
        console.print(table)

        hinted = [f for f in shown if f.get("hint")]
        if hinted:
            console.print("\n  [dim]Hints:[/]")
            for f in hinted:
                console.print(f"    [dim]• {f['pkg_ref']}[/] [dim]→[/] {f['hint']}")
        console.print()

    if summary["high"] > 0:
        sys.exit(1)
