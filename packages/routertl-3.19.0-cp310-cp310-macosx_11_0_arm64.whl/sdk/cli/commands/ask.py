# SPDX-FileCopyrightText: 2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""``rr ask`` — query the fpgawisdom.com FPGA knowledge base from the CLI.

Uses the public RAG API at fpgawisdom.com to answer FPGA/hardware
questions, backed by curated forum posts from AMD/Xilinx community
experts.

Override the API base URL via the ``ROUTERTL_ASK_URL`` environment
variable (defaults to ``https://fpgawisdom.com``).
"""

from __future__ import annotations

import json
import os
import sys
import urllib.error
import urllib.request

import rich_click as click
from rich.markdown import Markdown
from rich.table import Table

from sdk.cli.console import console, error

_DEFAULT_API_URL = "https://fpgawisdom.com"


def _api_url() -> str:
    return os.environ.get("ROUTERTL_ASK_URL", _DEFAULT_API_URL).rstrip("/")


# ── Helpers ──────────────────────────────────────────────────────


def _post_query(question: str, *, mode: str = "hybrid", k: int = 5, use_llm: bool = True) -> dict:
    """Call POST /api/query and return the parsed JSON response."""
    url = f"{_api_url()}/api/query"
    payload = json.dumps({
        "query": question,
        "mode": mode,
        "use_llm": use_llm,
        "k": k,
    }).encode()

    req = urllib.request.Request(
        url,
        data=payload,
        headers={"Content-Type": "application/json", "User-Agent": "routertl-cli"},
    )
    with urllib.request.urlopen(req, timeout=30) as resp:
        return json.loads(resp.read().decode())


def _get_search(question: str, *, mode: str = "hybrid", k: int = 10) -> dict:
    """Call GET /api/search and return the parsed JSON response."""
    from urllib.parse import quote_plus

    url = f"{_api_url()}/api/search?q={quote_plus(question)}&mode={mode}&k={k}"
    req = urllib.request.Request(url, headers={"User-Agent": "routertl-cli"})
    with urllib.request.urlopen(req, timeout=15) as resp:
        return json.loads(resp.read().decode())


# ── Renderers ────────────────────────────────────────────────────


def _render_answer(data: dict) -> None:
    """Pretty-print a RAG answer with sources."""
    answer = data.get("answer", "")
    sources = data.get("sources", [])
    model = data.get("model", "unknown")

    console.print()
    console.print(Markdown(answer))
    console.print()

    if sources:
        table = Table(
            title="Sources",
            show_header=True,
            title_style="bold cyan",
            border_style="bright_black",
            padding=(0, 1),
        )
        table.add_column("#", style="dim", width=3)
        table.add_column("Title", style="bold")
        table.add_column("Author", style="cyan")
        table.add_column("Date", style="dim", width=12)

        for src in sources:
            idx = str(src.get("index", ""))
            title = src.get("title", "untitled")
            author = src.get("author", "")
            date = src.get("date", "")
            url = src.get("url", "")
            label = f"[link={url}]{title}[/link]" if url else title
            table.add_row(idx, label, author, date)

        console.print(table)

    console.print(f"\n  [dim]model: {model} · fpgawisdom.com[/dim]\n")


def _render_search(data: dict) -> None:
    """Pretty-print raw search results."""
    results = data.get("results", [])

    if not results:
        console.print("[yellow]No results found.[/]")
        return

    console.print()
    for i, r in enumerate(results, 1):
        title = r.get("title", "untitled")
        author = r.get("author", "")
        date = r.get("date", "")
        score = r.get("score", 0.0)
        content = r.get("content", "")[:200]
        url = r.get("url", "")
        tier = r.get("author_tier", "")

        tier_badge = ""
        if tier == "God":
            tier_badge = " [bold yellow]★[/]"
        elif tier == "Legend":
            tier_badge = " [cyan]◆[/]"

        header = f"[bold]{i}. {title}[/bold]"
        if url:
            header = f"[bold][link={url}]{i}. {title}[/link][/bold]"

        console.print(header)
        console.print(f"   [cyan]{author}[/]{tier_badge}  [dim]{date}  score={score:.2f}[/]")
        console.print(f"   [dim]{content}…[/dim]")
        console.print()


# ── Click Command ────────────────────────────────────────────────


@click.command(name="ask")
@click.argument("question", nargs=-1, required=True)
@click.option(
    "--search", "search_only", is_flag=True,
    help="Return raw search results instead of a synthesised answer.",
)
@click.option(
    "--mode", type=click.Choice(["hybrid", "semantic", "keyword"]), default="hybrid",
    help="Search strategy (default: hybrid).",
)
@click.option(
    "-k", "top_k", type=int, default=5,
    help="Number of source documents to retrieve (default: 5).",
)
def ask_command(question: tuple[str, ...], search_only: bool, mode: str, top_k: int):
    """Ask the FPGA knowledge base a question.

    Queries fpgawisdom.com — a curated corpus of AMD/Xilinx community
    expertise — and returns an AI-synthesised answer with source citations.

    \b
    Examples:
        rr ask how do I safely cross clock domains
        rr ask "what is metastability?"
        rr ask --search timing constraints
        rr ask --mode semantic "clock gating best practices"
    """
    query_str = " ".join(question)

    try:
        with console.status("[cyan]Querying fpgawisdom.com…[/]"):
            if search_only:
                data = _get_search(query_str, mode=mode, k=top_k)
                _render_search(data)
            else:
                data = _post_query(query_str, mode=mode, k=top_k, use_llm=True)
                _render_answer(data)
    except urllib.error.HTTPError as exc:
        if exc.code == 429:
            error("Rate limited — please wait a moment and try again.")
        else:
            error(f"API error: HTTP {exc.code}")
        sys.exit(1)
    except urllib.error.URLError as exc:
        error(f"Cannot reach fpgawisdom.com: {exc.reason}")
        console.print("[dim]  Check your internet connection or set ROUTERTL_ASK_URL to override.[/]")
        sys.exit(1)
    except (json.JSONDecodeError, KeyError) as exc:
        error(f"Unexpected API response: {exc}")
        sys.exit(1)
