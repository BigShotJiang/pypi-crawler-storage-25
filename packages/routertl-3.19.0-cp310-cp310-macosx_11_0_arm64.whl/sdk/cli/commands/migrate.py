# SPDX-FileCopyrightText: 2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""rr migrate — import vendor FPGA projects into routertl.

Currently supports Vivado .xpr projects (Tier 1 — pure XML parse,
no vendor tools required).  Architecture is pluggable for future
Quartus (.qpf/.qsf), Lattice (.rdf), and Libero (.prjx) backends.

RTL-P2.211
"""

from __future__ import annotations

from pathlib import Path

import rich_click as click

from sdk.cli.console import console

# ── Supported extensions → backend label ──
_BACKENDS = {
    ".xpr": "vivado",
}

_PLANNED = {
    ".qpf": "Quartus",
    ".qsf": "Quartus",
    ".rdf": "Lattice Radiant",
    ".ldf": "Lattice Diamond",
    ".prjx": "Microchip Libero",
}


@click.group(name="migrate")
@click.pass_context
def migrate_command(ctx):
    """Migrate vendor FPGA projects to routertl.

    \b
    Commands:
      rr migrate run <project.xpr> [output_dir]   Import a vendor project
      rr migrate verify -r <original_project>      Compare build results
    """
    pass


def _resolve_project_file(path: Path) -> Path:
    """Accept either a vendor project file or the directory containing one.

    RTL-P2.394: dogfooding showed users naturally pass the project
    directory ('rr migrate run ~/projects/foo') rather than the exact
    .xpr path.  Auto-discover the single supported project file when a
    directory is given; raise a clear error on zero / ambiguous hits.
    """
    if path.is_file():
        return path
    if not path.is_dir():
        raise click.BadParameter(
            f"Path does not exist: {path}",
            param_hint="PROJECT",
        )

    candidates: list[Path] = []
    for ext in (*_BACKENDS.keys(), *_PLANNED.keys()):
        candidates.extend(sorted(path.glob(f"*{ext}")))

    if not candidates:
        exts = ", ".join(sorted({*_BACKENDS.keys(), *_PLANNED.keys()}))
        raise click.BadParameter(
            f"No vendor project file found in {path}\n"
            f"   Looked for: {exts}\n"
            f"   Pass the exact file path instead if it lives elsewhere.",
            param_hint="PROJECT",
        )
    if len(candidates) > 1:
        listing = "\n     ".join(str(c.name) for c in candidates)
        raise click.BadParameter(
            f"Multiple vendor project files found in {path}:\n"
            f"     {listing}\n"
            f"   Pass the exact file path to disambiguate.",
            param_hint="PROJECT",
        )
    return candidates[0]


@migrate_command.command(name="run")
@click.argument("project", type=click.Path(exists=True))
@click.argument("output_dir", type=click.Path(), required=False, default=None)
@click.option(
    "-o", "--output", "output_flag",
    type=click.Path(),
    default=None,
    help="Output directory for the migrated project (default: current "
         "directory).  Equivalent to the OUTPUT_DIR positional; the "
         "flag wins if both are given (RTL-P2.394).",
)
@click.option(
    "--targets-dir",
    type=click.Path(),
    default="targets",
    show_default=True,
    help="Directory for generated target configs (relative to output_dir).",
)
@click.option(
    "--src-dirs",
    multiple=True,
    type=click.Path(exists=True),
    help="Directories to search for missing source files (repeatable).",
)
@click.option(
    "--name",
    type=str,
    default=None,
    help="Override the project name (default: .xpr filename stem).",
)
@click.option(
    "--dry-run",
    is_flag=True,
    default=False,
    help="Parse and report without writing files.",
)
@click.option(
    "--hw-src-dir",
    type=str,
    default="hw/src",
    show_default=True,
    help="Destination for synthesis source files.",
)
@click.option(
    "--hw-sim-dir",
    type=str,
    default="hw/sim",
    show_default=True,
    help="Destination for simulation source files.",
)
@click.option(
    "--hw-xdc-dir",
    type=str,
    default="hw/xdc",
    show_default=True,
    help="Destination for constraint files.",
)
@click.option(
    "--hw-ip-dir",
    type=str,
    default="hw/ip",
    show_default=True,
    help="Destination for IP repository copies.",
)
@click.option(
    "--sw-dir",
    type=str,
    default="sw/linux",
    show_default=True,
    help="Destination for SW scaffolding (SoC designs only).",
)
@click.option(
    "--no-sw",
    is_flag=True,
    default=False,
    help="Skip SW directory scaffolding even for SoC parts.",
)
def migrate_run(
    project: str,
    output_dir: str | None,
    output_flag: str | None,
    targets_dir: str,
    src_dirs: tuple[str, ...],
    name: str | None,
    dry_run: bool,
    hw_src_dir: str,
    hw_sim_dir: str,
    hw_xdc_dir: str,
    hw_ip_dir: str,
    sw_dir: str,
    no_sw: bool,
):
    """Migrate a vendor FPGA project to routertl.

    PROJECT may be either:
      * a vendor project file path (e.g. ./my_design.xpr), OR
      * a directory containing exactly one supported project file —
        the tool will auto-discover it (RTL-P2.394).

    The migrated project (sources, constraints, target yml, scaffolding)
    lands under OUTPUT_DIR (defaults to the current directory).  Pass
    it either as the second positional argument or via -o/--output.

    \b
    Currently supported:
      • Vivado .xpr  (Tier 1 — no Vivado required)

    \b
    Examples:
        rr migrate run my_design.xpr
        rr migrate run ~/projects/legacy_fpga -o ~/new_home
        rr migrate run my_design.xpr . --src-dirs ~/external_sources
    """
    # RTL-P2.394: -o/--output takes precedence; fall back to positional;
    # fall back to CWD.
    resolved_output = output_flag or output_dir or "."

    # RTL-P2.394: accept a directory → auto-discover the single .xpr.
    src = _resolve_project_file(Path(project))
    ext = src.suffix.lower()

    # ── Check backend support ──
    if ext in _PLANNED:
        console.print(
            f"❌ [red]{_PLANNED[ext]} migration is not yet supported.[/]\n"
            "   Contributions welcome! See RTL-P2.211 for the architecture."
        )
        raise SystemExit(1)

    if ext not in _BACKENDS:
        console.print(
            f"❌ [red]Unrecognized project file format: {ext}[/]\n"
            f"   Supported: {', '.join(_BACKENDS.keys())}"
        )
        raise SystemExit(1)

    # ── Set up output directory ──
    import os

    out = Path(resolved_output).resolve()
    out.mkdir(parents=True, exist_ok=True)
    os.chdir(out)

    # ── Vivado backend ──
    console.print(f"📦 [blue]Parsing Vivado project:[/] {src.name}")
    console.print(f"   [dim]Output: {out}[/]")

    from sdk.engine.xpr_parser import parse_xpr

    result = parse_xpr(src)

    # ── Override project name if --name given ──
    if name:
        result.project_name = name

    # ── Resolve missing files via --src-dirs, auto-search, or prompt ──
    from sdk.engine.migrate_xpr import auto_search_from_xpr, search_missing_files

    missing = result.missing_files
    if missing:
        search_paths = [Path(d) for d in src_dirs]

        # If --src-dirs provided, search them first
        if search_paths:
            found = search_missing_files(result, search_paths)
            if found:
                console.print(
                    f"\n🔍 Found {len(found)}/{len(missing)} missing file(s) "
                    f"in provided directories"
                )

        # Auto-search near the .xpr if still missing and no --src-dirs
        remaining = result.missing_files
        if remaining and not src_dirs:
            auto_found = auto_search_from_xpr(result, src)
            if auto_found:
                console.print(
                    f"\n🔍 Auto-found {len(auto_found)}/{len(missing)} "
                    f"missing file(s) near project"
                )

        # If still missing and not dry-run, prompt interactively
        remaining = result.missing_files
        if remaining and not dry_run:
            console.print(
                f"\n  [yellow]⚠️  {len(remaining)} file(s) not found "
                "at their original paths:[/]"
            )
            for f in remaining:
                console.print(
                    f"     [dim]{Path(f.resolved_path).name}[/]"
                )
            console.print()
            while remaining:
                try:
                    user_dir = console.input(
                        "  Directory to search for missing files "
                        "(Enter to skip): "
                    ).strip()
                except (EOFError, KeyboardInterrupt):
                    break
                if not user_dir:
                    break
                user_path = Path(user_dir).expanduser()
                if not user_path.is_dir():
                    console.print(f"  [red]Not a directory: {user_dir}[/]")
                    continue
                found = search_missing_files(result, [user_path])
                if found:
                    console.print(
                        f"  ✅ Found {len(found)} file(s): "
                        f"{', '.join(found.keys())}"
                    )
                else:
                    console.print("  [dim]No matches found.[/]")
                remaining = result.missing_files
                if not remaining:
                    console.print("  ✅ All files located!")
                else:
                    console.print(
                        f"  [dim]Still missing {len(remaining)}: "
                        f"{', '.join(Path(f.resolved_path).name for f in remaining)}[/]"
                    )

    # ── Relocate external files into the project ──
    from sdk.engine.migrate_xpr import (
        relocate_ip_repos,
        relocate_sources,
        relocate_sw_tcl_files,
    )

    layout = dict(src_dir=hw_src_dir, sim_dir=hw_sim_dir, xdc_dir=hw_xdc_dir)

    if not dry_run:
        copy_actions = relocate_sources(result, Path.cwd(), **layout)
        ip_paths, ip_actions = relocate_ip_repos(
            result, Path.cwd(), ip_dir=hw_ip_dir,
        )
        # Update ip_repo_paths so build_project_config uses relocated paths
        if ip_paths:
            result.ip_repo_paths = ip_paths
        # Relocate XSCT/XSDB scripts to sw/
        sw_tcl_actions = relocate_sw_tcl_files(
            result, Path.cwd(), sw_dir=sw_dir,
        )
        all_actions = copy_actions + ip_actions + sw_tcl_actions
        if sw_tcl_actions:
            console.print(
                f"\n🐧 [blue]Moved {len(sw_tcl_actions)} XSCT/XSDB script(s) "
                f"to {sw_dir}/[/]"
            )
        if copy_actions or ip_actions:
            console.print(
                f"\n📁 [blue]Relocated {len(copy_actions) + len(ip_actions)} "
                "file(s) into project[/]"
            )
    else:
        # Dry run: report what would be copied
        copy_actions = relocate_sources(
            result, Path.cwd(), dry_run=True, **layout,
        )
        ip_paths, ip_actions = relocate_ip_repos(
            result, Path.cwd(), dry_run=True, ip_dir=hw_ip_dir,
        )
        sw_tcl_actions = relocate_sw_tcl_files(
            result, Path.cwd(), sw_dir=sw_dir, dry_run=True,
        )
        all_actions = copy_actions + ip_actions + sw_tcl_actions

    # ── Dry run: build config in memory for the pre-report ──
    if dry_run:
        import shutil

        from sdk.engine.migrate_xpr import (
            build_project_config,
            generate_migration_report,
        )

        vivado_available = shutil.which("vivado") is not None
        config = build_project_config(result, Path.cwd())
        sw_scaffolded: list[str] = []
        if result.is_soc and not no_sw:
            sw_scaffolded = [f"{sw_dir}/system_memory_map.yml"]
        report = generate_migration_report(
            result, config, src, tgt_path=Path(f"{targets_dir}/{result.project_name}.yml"),
            dry_run=True, vivado_available=vivado_available,
            relocated_files=all_actions,
            sw_scaffolded_files=sw_scaffolded,
        )
        console.print(report)
        console.print("[dim]Dry run — no files written.[/]")
        return

    import shutil

    import yaml as _yaml

    from sdk.engine.migrate_xpr import (
        build_project_config,
        export_block_designs,
        generate_migration_report,
        generate_project_yml,
        scaffold_migrated_project,
    )

    # ── Tier 2: auto-export block designs if Vivado is available ──
    adapted_bd_hooks: list[str] = []
    vivado_available = shutil.which("vivado") is not None
    if result.bd_files and vivado_available:
        console.print(
            "\n🔧 [blue]Vivado found — exporting block designs...[/]"
        )
        adapted_bd_hooks = export_block_designs(
            result, src, Path.cwd(),
        )
        if adapted_bd_hooks:
            console.print(
                f"   ✅ Exported {len(adapted_bd_hooks)} block design(s)"
            )
        else:
            console.print(
                "   [yellow]⚠️  BD export failed — falling back to TODO placeholder[/]"
            )
    elif result.bd_files:
        console.print(
            "\n[dim]Vivado not found — BD export skipped (Tier 1 only)[/]"
        )

    # Write target config to targets/<project_name>.yml
    tgt_dir = Path(targets_dir)
    tgt_dir.mkdir(parents=True, exist_ok=True)
    tgt_filename = f"{result.project_name}.yml"
    tgt_path = tgt_dir / tgt_filename

    if tgt_path.exists():
        console.print(
            f"\n  [yellow]⚠️  {tgt_path} already exists — overwriting.[/]"
        )

    generate_project_yml(
        result, Path.cwd(), filename=str(tgt_path),
        adapted_bd_hooks=adapted_bd_hooks,
    )

    # Handle root project.yml pointer
    root_yml = Path("project.yml")
    target_rel = str(tgt_path)

    if root_yml.exists():
        try:
            existing = _yaml.safe_load(root_yml.read_text()) or {}
        except _yaml.YAMLError:
            existing = {}

        current_target = existing.get("target", "")
        if current_target != target_rel:
            if current_target:
                console.print(
                    f"\n  [yellow]⚠️  project.yml currently points to:[/] "
                    f"[cyan]{current_target}[/]"
                )
    else:
        root_yml.write_text(
            f"# RouteRTL project — points to active target config\n"
            f"target: {target_rel}\n"
        )

    # ── Scaffold: Makefile, .gitignore, build_env ──
    scaffolded = scaffold_migrated_project(Path.cwd())
    if scaffolded:
        console.print(
            f"\n🏗️  [blue]Scaffolded:[/] {', '.join(scaffolded)}"
        )

    # ── SoC: scaffold sw/ directory ──
    sw_scaffolded: list[str] = []
    if result.is_soc and not no_sw:
        from sdk.engine.migrate_xpr import scaffold_sw_directory

        sw_scaffolded = scaffold_sw_directory(
            Path.cwd(), result.soc_family, sw_dir=sw_dir,
        )
        if sw_scaffolded:
            console.print(
                f"\n🐧 [blue]SoC detected ({result.soc_family}) — "
                f"scaffolded:[/]"
            )
            for sf in sw_scaffolded:
                console.print(f"   {sf}")
    elif result.is_soc and no_sw:
        console.print(
            f"\n[dim]SoC detected ({result.soc_family}) — "
            "sw/ scaffolding skipped (--no-sw)[/]"
        )

    # ── Migration Summary Report ──
    config = build_project_config(
        result, Path.cwd(), adapted_bd_hooks=adapted_bd_hooks,
    )
    report_path = tgt_dir / f"{result.project_name}.migration_report.txt"

    report = generate_migration_report(
        result, config, src, tgt_path, report_path=report_path,
        vivado_available=vivado_available,
        adapted_bd_hooks=adapted_bd_hooks,
        relocated_files=all_actions,
        scaffolded_files=scaffolded,
        sw_scaffolded_files=sw_scaffolded,
    )
    console.print(report)


# ── rr migrate verify ───────────────────────────────────────────


@migrate_command.command(name="verify")
@click.option(
    "--reference", "-r",
    type=click.Path(exists=True),
    required=True,
    help="Path to the original vendor project (directory or .xpr file).",
)
@click.option(
    "--current", "-c",
    type=click.Path(exists=True),
    default=".",
    show_default=True,
    help="Path to the migrated project root.",
)
@click.option("--json", "as_json", is_flag=True, help="Machine-readable JSON output.")
def migrate_verify(reference: str, current: str, as_json: bool):
    """Compare build results between the original and migrated project.

    Parses Vivado utilization and timing reports from both projects
    and produces a side-by-side comparison of key FPGA metrics.

    \b
    Requires that both projects have been built (impl reports exist).

    \b
    Examples:
        rr migrate verify --reference /path/to/original/vivado/project
        rr migrate verify -r ../sdi_enclustra/vivado -c .
    """
    import json as _json
    import sys

    from rich.table import Table

    from sdk.engine.migrate_verify import (
        compare_builds,
        discover_current_reports,
        discover_reference_reports,
        verdict,
    )

    ref_path = Path(reference)
    cur_path = Path(current)

    # ── Parse both sets of reports ──
    try:
        ref_metrics = discover_reference_reports(ref_path)
    except FileNotFoundError as e:
        console.print(f"❌ [red]Reference project:[/] {e}")
        sys.exit(1)

    try:
        cur_metrics = discover_current_reports(cur_path)
    except FileNotFoundError as e:
        console.print(f"❌ [red]Migrated project:[/] {e}")
        sys.exit(1)

    # ── Compare ──
    rows = compare_builds(ref_metrics, cur_metrics)
    verdict_text, verdict_color = verdict(rows)

    # ── JSON output ──
    if as_json:
        data = {
            "reference": {
                "design": ref_metrics.design_name,
                "device": ref_metrics.device,
            },
            "current": {
                "design": cur_metrics.design_name,
                "device": cur_metrics.device,
            },
            "comparison": [
                {
                    "metric": r.metric,
                    "reference": r.ref_value,
                    "current": r.cur_value,
                    "delta": r.delta,
                    "status": r.status,
                }
                for r in rows
            ],
            "verdict": verdict_text,
        }
        click.echo(_json.dumps(data, indent=2))
        if "FAIL" in verdict_text:
            sys.exit(1)
        return

    # ── Rich table output ──
    _STATUS_STYLE = {
        "identical": ("[green]", "✅"),
        "minor": ("[yellow]", "≈"),
        "significant": ("[red]", "⚠️"),
        "mismatch": ("[red bold]", "❌"),
    }

    console.print()
    console.print("[bold cyan]🔍 Migration Verification Report[/]")
    console.print()

    if ref_metrics.design_name:
        console.print(f"  Reference: [cyan]{ref_metrics.design_name}[/] ({ref_metrics.device})")
    if cur_metrics.design_name:
        console.print(f"  Migrated:  [cyan]{cur_metrics.design_name}[/] ({cur_metrics.device})")
    console.print()

    table = Table(show_lines=False, padding=(0, 1))
    table.add_column("", width=3, justify="center")
    table.add_column("Metric", min_width=16)
    table.add_column("Reference", min_width=28)
    table.add_column("Migrated", min_width=28)
    table.add_column("Delta", min_width=18)

    for row in rows:
        color, icon = _STATUS_STYLE.get(row.status, ("[dim]", "?"))
        table.add_row(
            icon,
            row.metric,
            row.ref_value,
            row.cur_value,
            f"{color}{row.delta}[/]",
        )

    console.print(table)
    console.print(f"\n  [{verdict_color}]{verdict_text}[/]\n")

    if "FAIL" in verdict_text:
        sys.exit(1)
