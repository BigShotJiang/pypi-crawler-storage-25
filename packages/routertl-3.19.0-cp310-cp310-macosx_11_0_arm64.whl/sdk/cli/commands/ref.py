# SPDX-FileCopyrightText: 2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""rr ref — Reference Design registry CLI.

Discover, inspect, install, and publish buildable FPGA reference designs
from the routertl-ref-index. Third register in the 3-register architecture
(IPs, Rules, Reference Designs). Top-level command group, sibling of
`rr pkg` and `rr rules`.

RTL-P2.338
"""

from __future__ import annotations

import json
import shutil
import subprocess
from pathlib import Path

import rich_click as click

from sdk.cli.console import console

# ── Helpers ──────────────────────────────────────────────────────────────────


def _cache_dir() -> Path:
    """Where ref-index catalog + manifests get cached."""
    return Path.cwd() / ".routertl_cache" / "ref_index"


def _split_ref_spec(spec: str) -> tuple[str, str, str | None]:
    """Parse 'org/name' or 'org/name@version' into (org, name, version|None)."""
    version = None
    if "@" in spec:
        spec, version = spec.rsplit("@", 1)
    if "/" not in spec:
        raise click.BadParameter(
            f"'{spec}' must be 'org/name' or 'org/name@version'"
        )
    org, name = spec.split("/", 1)
    return org, name, version


def _find_entry(catalog: list[dict], org: str, name: str) -> dict | None:
    for e in catalog:
        if e.get("org") == org and e.get("name") == name:
            return e
    return None


def _matches_filter(entry: dict, field: str, wanted: str | None) -> bool:
    if not wanted:
        return True
    return (entry.get(field) or "").lower() == wanted.lower()


def _load_catalog() -> list[dict]:
    from sdk.cli.project_config import load_project_config
    from sdk.engine.ref_index_client import fetch_ref_catalog, get_ref_index_url

    # project.yml may override the index URL (rare but supported)
    config = None
    try:
        config = load_project_config(Path.cwd())
    except (FileNotFoundError, ValueError):
        pass
    index_url = get_ref_index_url(config)
    return fetch_ref_catalog(index_url, _cache_dir())


def _load_manifest(org: str, name: str, version: str) -> dict:
    from sdk.cli.project_config import load_project_config
    from sdk.engine.ref_index_client import fetch_ref_manifest, get_ref_index_url

    config = None
    try:
        config = load_project_config(Path.cwd())
    except (FileNotFoundError, ValueError):
        pass
    index_url = get_ref_index_url(config)
    return fetch_ref_manifest(org, name, version, index_url, _cache_dir())


def _project_yml_discoverable() -> bool:
    """True when a project.yml exists in cwd (add-as-target mode signal)."""
    return (Path.cwd() / "project.yml").exists()


# ── Command group ────────────────────────────────────────────────────────────


@click.group(name="ref")
def ref_group():
    """Reference designs — discover, install, and share buildable FPGA projects.

    \b
    Subcommands:
        list       Filter the ref-design catalog by board/vendor/tool/difficulty
        search     Keyword search over descriptions, tags, IPs used
        info       Show full manifest for a reference design
        install    Scaffold a fresh project or add a ref design as a target
        diff       Compare local install against upstream manifest
        publish    Publish the current project's ref_design.yml to the registry
    """


# ── list ─────────────────────────────────────────────────────────────────────


@ref_group.command(name="list")
@click.option("--board", help="Filter by canonical board ID (e.g. 'zybo-z7-20').")
@click.option("--vendor", help="Filter by vendor (xilinx, altera, microchip, lattice).")
@click.option("--tool", help="Filter by tool (Vivado, Quartus).")
@click.option("--json", "as_json", is_flag=True, help="Machine-readable JSON output.")
def ref_list(board, vendor, tool, as_json):
    """List reference designs in the index, optionally filtered."""
    catalog = _load_catalog()
    filtered = [
        e for e in catalog
        if _matches_filter(e, "board", board)
        and _matches_filter(e, "vendor", vendor)
        and _matches_filter(e, "tool", tool)
    ]

    if as_json:
        console.print(json.dumps(filtered, indent=2))
        return

    if not filtered:
        console.print("[yellow]No reference designs matched.[/]")
        if not catalog:
            console.print(
                "[dim]The registry is empty — first seed ships soon.[/]"
            )
        return

    console.print(f"[bold]{len(filtered)} reference design(s):[/]\n")
    for e in filtered:
        ips = ", ".join(u.get("ref", "") for u in (e.get("uses") or [])[:3])
        if len(e.get("uses") or []) > 3:
            ips += ", ..."
        console.print(
            f"  [cyan]{e.get('org')}/{e.get('name')}[/] "
            f"@ {e.get('latest')} "
            f"— [dim]{e.get('board') or '?'}"
            f" · {e.get('tool') or '?'} {e.get('tool_version') or ''}[/]"
        )
        if e.get("description"):
            console.print(f"    {e['description']}")
        if ips:
            console.print(f"    [dim]uses: {ips}[/]")


# ── search ───────────────────────────────────────────────────────────────────


@ref_group.command(name="search")
@click.argument("query")
@click.option("--json", "as_json", is_flag=True,
              help="Machine-readable JSON output.")
def ref_search(query, as_json):
    """Search reference designs by keywords in description, tags, or IPs used."""
    catalog = _load_catalog()
    q = query.lower()
    matches = []
    for e in catalog:
        haystack_parts = [
            e.get("description", ""),
            e.get("name", ""),
            e.get("org", ""),
            e.get("board", ""),
            " ".join(e.get("tags") or []),
            " ".join(u.get("ref", "") for u in (e.get("uses") or [])),
        ]
        haystack = " ".join(haystack_parts).lower()
        if q in haystack:
            matches.append(e)

    if as_json:
        console.print(json.dumps(matches, indent=2))
        return

    if not matches:
        console.print(f"[yellow]No matches for '{query}'.[/]")
        return

    console.print(f"[bold]{len(matches)} match(es) for '{query}':[/]\n")
    for e in matches:
        console.print(f"  [cyan]{e.get('org')}/{e.get('name')}[/] — {e.get('description')}")


# ── info ─────────────────────────────────────────────────────────────────────


@ref_group.command(name="info")
@click.argument("ref_spec")
def ref_info(ref_spec):
    """Show full manifest for a reference design.

    \b
    Examples:
        rr ref info routertl/linux_zybo
        rr ref info routertl/linux_zybo@1.0.0
    """
    org, name, version = _split_ref_spec(ref_spec)

    catalog = _load_catalog()
    entry = _find_entry(catalog, org, name)
    if entry is None:
        console.print(f"[red]Not found:[/] {org}/{name}")
        raise SystemExit(1)

    if version is None:
        version = entry.get("latest", "")

    try:
        manifest = _load_manifest(org, name, version)
    except RuntimeError as exc:
        console.print(f"[red]Manifest fetch failed:[/] {exc}")
        raise SystemExit(1) from exc

    rd = manifest.get("ref_design", {})
    target = manifest.get("target", {})
    project = manifest.get("project", {})
    build = manifest.get("build", {})
    resources = manifest.get("resources", {})
    verification = manifest.get("verification", {})
    uses = manifest.get("uses", []) or []
    source = manifest.get("source", {})

    console.print(f"\n[bold cyan]{org}/{name}[/] @ {version}\n")
    if rd.get("description"):
        console.print(rd["description"])
        console.print()
    console.print(
        f"[bold]Target:[/] {target.get('board', '?')} "
        f"({target.get('vendor', '?')}/{target.get('family', '?')}, "
        f"part [cyan]{target.get('part', '?')}[/])"
    )
    console.print(
        f"[bold]Tool:[/] {target.get('tool', '?')} {target.get('tool_version', '?')}"
    )
    console.print(
        f"[bold]Project:[/] {project.get('top_module', '?')} "
        f"({project.get('language', '?')})"
    )
    tags = rd.get("tags") or []
    if tags:
        console.print(f"[bold]Tags:[/] {', '.join(tags)}")
    if uses:
        console.print("\n[bold]IPs used:[/]")
        for u in uses:
            console.print(f"  - {u.get('ref', '?')} @ {u.get('version', '?')}")
    if source.get("repo"):
        console.print(
            f"\n[bold]Source:[/] {source['repo']} "
            f"(commit [dim]{source.get('commit', '?')[:12]}[/])"
        )
    if build.get("command"):
        console.print(f"[bold]Build:[/] {build['command']}")
        if build.get("estimated_time_minutes"):
            console.print(f"  [dim]~{build['estimated_time_minutes']} minutes on reference hardware[/]")
    if any(resources.get(k) for k in ("luts", "ffs", "bram_kbits", "fmax_mhz")):
        console.print(
            f"\n[bold]Resources:[/] "
            f"{resources.get('luts', 0)} LUTs, "
            f"{resources.get('ffs', 0)} FFs, "
            f"{resources.get('bram_kbits', 0)} Kbit BRAM, "
            f"Fmax {resources.get('fmax_mhz', 0)} MHz"
        )
    console.print(
        f"\n[bold]Verification:[/] {verification.get('status', 'claimed')} "
        f"{verification.get('last_verified_date', '')}"
    )
    console.print(f"\n[dim]Install:[/] rr ref install {org}/{name}@{version}")


# ── install ──────────────────────────────────────────────────────────────────


@ref_group.command(name="install")
@click.argument("ref_spec")
@click.argument("dest_dir", required=False, type=click.Path())
@click.option("--force-target", is_flag=True,
              help="Force add-as-target mode even when dest_dir has no project.yml.")
def ref_install(ref_spec, dest_dir, force_target):
    """Scaffold a fresh project from a reference design, OR add it as a target.

    \b
    Modes:
        Fresh scaffold:  no project.yml in cwd → new dir with project.yml, src/, targets/.
        Add as target:   project.yml present in cwd → drops targets/<name>.yml,
                         appends uses: IPs to packages:, leaves rest untouched.

    \b
    Examples:
        rr ref install routertl/linux_zybo                  # into ./linux_zybo/
        rr ref install routertl/linux_zybo my_zybo/          # into ./my_zybo/
        rr ref install routertl/linux_zybo --force-target   # as target in existing project
    """
    org, name, version = _split_ref_spec(ref_spec)

    catalog = _load_catalog()
    entry = _find_entry(catalog, org, name)
    if entry is None:
        console.print(f"[red]Not found:[/] {org}/{name}")
        raise SystemExit(1)
    if version is None:
        version = entry.get("latest", "")

    try:
        manifest = _load_manifest(org, name, version)
    except RuntimeError as exc:
        console.print(f"[red]Manifest fetch failed:[/] {exc}")
        raise SystemExit(1) from exc

    use_target_mode = force_target or (dest_dir is None and _project_yml_discoverable())

    if use_target_mode:
        _install_as_target(org, name, version, manifest)
    else:
        dest = Path(dest_dir) if dest_dir else Path.cwd() / name
        _install_fresh(org, name, version, manifest, dest)


def _install_fresh(org: str, name: str, version: str, manifest: dict, dest: Path) -> None:
    """Clone source repo at pinned commit into dest_dir. Materialise project.yml
    if the cloned tree doesn't include one. Run rr pkg add for each uses: entry.
    """
    import yaml as _yaml

    source = manifest.get("source", {}) or {}
    repo = source.get("repo")
    commit = source.get("commit")

    if not repo:
        console.print(
            f"[red]Manifest for {org}/{name}@{version} is missing source.repo[/]. "
            "Cannot scaffold without a git URL."
        )
        raise SystemExit(1)

    if dest.exists() and any(dest.iterdir()):
        console.print(f"[red]Destination {dest} is not empty.[/]")
        raise SystemExit(1)
    dest.mkdir(parents=True, exist_ok=True)

    console.print(f"[blue]Cloning[/] {repo} → {dest}")
    try:
        subprocess.run(
            ["git", "clone", "--quiet", repo, str(dest)],
            check=True, timeout=120,
        )
        if commit:
            subprocess.run(
                ["git", "-C", str(dest), "checkout", "--quiet", commit],
                check=True, timeout=30,
            )
    except (subprocess.CalledProcessError, subprocess.TimeoutExpired) as exc:
        console.print(f"[red]Clone failed:[/] {exc}")
        # Clean up partial clone
        shutil.rmtree(dest, ignore_errors=True)
        raise SystemExit(1) from exc

    # If the cloned repo already has a project.yml, don't overwrite it.
    project_yml = dest / "project.yml"
    if not project_yml.exists():
        console.print("[blue]Generating project.yml from manifest[/]")
        rd = manifest.get("ref_design", {}) or {}
        target = manifest.get("target", {}) or {}
        project = manifest.get("project", {}) or {}
        uses = manifest.get("uses", []) or []
        project_yml_content = {
            "project": {
                "name": rd.get("name", name),
                "top_module": project.get("top_module", ""),
            },
            "hardware": {
                "vendor": target.get("vendor", ""),
                "family": target.get("family", ""),
                "part": target.get("part", ""),
                "language": project.get("language", ""),
            },
            "build_options": {
                "tool_version": target.get("tool_version", ""),
            },
            "packages": {
                u["ref"]: u["version"] for u in uses
                if u.get("ref") and u.get("version")
            },
        }
        project_yml.write_text(_yaml.safe_dump(project_yml_content, sort_keys=False))

    console.print(f"\n[green]✓[/] Scaffolded [cyan]{org}/{name}@{version}[/] into {dest}")
    console.print("\n[bold]Next steps:[/]")
    console.print(f"  cd {dest}")
    console.print("  rr pkg install           # resolve IPs")
    console.print("  rr rules check           # surface rules for this toolchain")
    build_cmd = (manifest.get("build") or {}).get("command")
    if build_cmd:
        console.print(f"  {build_cmd}")


def _install_as_target(org: str, name: str, version: str, manifest: dict) -> None:
    """Add the ref design as a target inside the current rr project.

    Drops targets/<name>.yml pointing at the ref design's top_module +
    hardware block. Appends `uses:` IPs to the existing project.yml's
    `packages:` section. Does NOT touch existing src/ or targets/.
    """
    import yaml as _yaml

    targets_dir = Path.cwd() / "targets"
    targets_dir.mkdir(exist_ok=True)

    target = manifest.get("target", {}) or {}
    project = manifest.get("project", {}) or {}
    uses = manifest.get("uses", []) or []
    rd = manifest.get("ref_design", {}) or {}

    target_yml = targets_dir / f"{name}.yml"
    if target_yml.exists():
        console.print(f"[red]Target {target_yml} already exists.[/]")
        raise SystemExit(1)

    target_content = {
        "project": {
            "name": rd.get("name", name),
            "top_module": project.get("top_module", ""),
        },
        "hardware": {
            "vendor": target.get("vendor", ""),
            "family": target.get("family", ""),
            "part": target.get("part", ""),
            "language": project.get("language", ""),
        },
        "build_options": {
            "tool_version": target.get("tool_version", ""),
        },
        "ref_design": {
            "org": org,
            "name": name,
            "version": version,
        },
    }
    target_yml.write_text(_yaml.safe_dump(target_content, sort_keys=False))
    console.print(f"[green]✓[/] Wrote [cyan]{target_yml}[/]")

    # Append uses: entries to existing project.yml packages: section.
    project_yml = Path.cwd() / "project.yml"
    if project_yml.exists() and uses:
        data = _yaml.safe_load(project_yml.read_text()) or {}
        packages = data.setdefault("packages", {})
        added = []
        for u in uses:
            ref = u.get("ref")
            ver = u.get("version")
            if ref and ver and ref not in packages:
                packages[ref] = ver
                added.append(ref)
        if added:
            project_yml.write_text(_yaml.safe_dump(data, sort_keys=False))
            console.print(
                f"[green]✓[/] Added {len(added)} package(s) to project.yml: "
                f"{', '.join(added)}"
            )

    console.print("\n[bold]Next steps:[/]")
    console.print(f"  rr target set {name}")
    console.print("  rr pkg install")
    console.print("  rr rules check")


# ── diff ─────────────────────────────────────────────────────────────────────


@ref_group.command(name="diff")
@click.argument("ref_spec", required=False)
def ref_diff(ref_spec):
    """Compare the current project against the upstream reference-design manifest.

    Placeholder — full implementation in a follow-up ticket. Shows where to
    look and what the eventual comparison would surface.
    """
    console.print(
        "[yellow]rr ref diff is not yet implemented.[/]\n"
        "Planned behaviour: compare local project state against the upstream\n"
        "manifest for the named ref design, surfacing diverged files, modified\n"
        "package versions, and new/removed IPs. Tracked as a follow-up to P2.338."
    )


# ── publish ──────────────────────────────────────────────────────────────────


@ref_group.command(name="publish")
@click.argument("manifest_path", required=False, type=click.Path(exists=True))
def ref_publish(manifest_path):
    """Validate and POST the current project's ref_design.yml to the registry.

    Implementation phase — currently validates locally and prints the
    server-bound payload so manifests can be reviewed before the submit
    endpoint (Phase 4, community submission) goes live.
    """
    from sdk.engine.ref_design_schema import load_manifest, validate_manifest

    path = Path(manifest_path) if manifest_path else Path.cwd() / "ref_design.yml"
    if not path.exists():
        console.print(f"[red]Manifest not found:[/] {path}")
        raise SystemExit(1)

    rd = load_manifest(path)
    errors = validate_manifest(rd)
    if errors:
        console.print(f"[red]Manifest validation failed[/] ({len(errors)} errors):")
        for e in errors:
            console.print(f"  • {e}")
        raise SystemExit(1)

    console.print(f"[green]✓[/] Manifest valid: [cyan]{rd.org}/{rd.name}@{rd.version}[/]")
    console.print(
        "[dim]Server-side /v1/submit-ref-design not yet live; publish will POST "
        "once Phase 4 ships.[/]"
    )
