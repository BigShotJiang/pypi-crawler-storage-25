# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Docker status dashboard — volumes, images, containers, and health."""

import re
import socket
import subprocess

from sdk.cli.commands.docker import (
    _VOLUME_PROBES,
    _detect_bind_mounts,
    docker_group,
)
from sdk.cli.console import console
from sdk.cli.resilience import cli_resilient_block


def _probe_license_server(lic_str):
    """Probe a FlexLM license server via TCP socket.

    Parses port@host from LM_LICENSE_FILE and attempts a TCP connection.
    Returns True (reachable), False (unreachable), or None (unparseable).
    """
    # Handle multiple servers separated by ';' or ':' — probe first one
    for sep in (";", ":"):
        if sep in lic_str and "@" in lic_str:
            lic_str = lic_str.split(sep)[0]
            break

    m = re.match(r"(\d+)@(.+)", lic_str.strip())
    if not m:
        return None
    port, host = int(m.group(1)), m.group(2)
    try:
        sock = socket.create_connection((host, port), timeout=3)
        sock.close()
        return True
    except (OSError, socket.timeout):
        return False


def _probe_volume_versions(volume_names):
    """Probe installed EDA versions inside Docker volumes.

    Returns {volume_name: "ToolName vX.Y"} for volumes where a version is found.
    Fails gracefully — returns empty dict entries on any error.
    """
    versions = {}
    for vol in volume_names:
        if vol not in _VOLUME_PROBES:
            continue

        found_parts = []
        for image, cmd, regex, display_name in _VOLUME_PROBES[vol]:
            # Check if the required image exists
            img_check = subprocess.run(["docker", "image", "inspect", image], capture_output=True, text=True)
            if img_check.returncode != 0:
                image = "alpine:latest"  # Fallback

            try:
                result = subprocess.run(
                    ["docker", "run", "--rm", "-v", f"{vol}:/opt:ro", image, "sh", "-c", cmd],
                    capture_output=True,
                    text=True,
                    timeout=10,
                )
                if result.returncode == 0 and result.stdout.strip():
                    m = re.search(regex, result.stdout)
                    if m:
                        found_parts.append(f"{display_name} {m.group(1)}")
            except (subprocess.TimeoutExpired, Exception):
                pass  # Graceful fallback

        if found_parts:
            versions[vol] = ", ".join(found_parts)

    return versions


@docker_group.command(name="status")
def docker_status():
    """Show RouteRTL Docker environment dashboard.

    Displays volumes (named + bind mounts from .env), images, containers,
    and environment health checks.
    """
    console.print("🐳 [blue]RouteRTL Docker Status[/]\n")

    # Guard: docker CLI is unavailable inside containers
    try:
        subprocess.run(["docker", "version"], capture_output=True, text=True, timeout=5)
    except FileNotFoundError:
        console.print("  [yellow]⚠️  Docker CLI not found.[/]")
        console.print("  [dim]This command must be run on the host, not inside a container.[/]")
        return

    # --- Volumes ---
    console.print("  [cyan]Volumes:[/]")
    vol_result = subprocess.run(
        ["docker", "volume", "ls", "--filter", "name=routertl_.*_opt", "--format", "{{.Name}}"],
        capture_output=True,
        text=True,
    )
    if vol_result.returncode != 0 or not vol_result.stdout.strip():
        console.print("    [dim](none)[/]")
    else:
        # Get volume sizes from docker system df -v (best-effort)
        vol_sizes = {}
        with cli_resilient_block("Docker volume sizes"):
            df_result = subprocess.run(["docker", "system", "df", "-v"], capture_output=True, text=True, timeout=10)
            if df_result.returncode == 0:
                in_volumes = False
                for df_line in df_result.stdout.splitlines():
                    if df_line.startswith("VOLUME NAME"):
                        in_volumes = True
                        continue
                    if in_volumes:
                        if not df_line.strip():
                            break
                        cols = df_line.split()
                        if len(cols) >= 3:
                            vol_sizes[cols[0]] = cols[2]

        # Probe installed EDA versions inside volumes
        vol_versions = _probe_volume_versions([l.strip() for l in vol_result.stdout.strip().splitlines()])

        for line in vol_result.stdout.strip().splitlines():
            name = line.strip()
            size = vol_sizes.get(name, "")
            version = vol_versions.get(name, "")
            parts = []
            if size:
                parts.append(f"[yellow]{size}[/]")
            if version:
                parts.append(f"[cyan]{version}[/]")
            suffix = f"  {' · '.join(parts)}" if parts else ""
            console.print(f"    [green]●[/] {name}{suffix}")

    # Detect bind mount installations from .env
    bind_mounts = _detect_bind_mounts()
    if bind_mounts:
        if not vol_result.stdout.strip():
            # Re-print header if no named volumes were shown
            pass
        for env_name, mount_path in bind_mounts:
            console.print(f"    [green]●[/] {mount_path}  [dim](bind mount via {env_name})[/]")

    console.print()

    # --- Images ---
    console.print("  [cyan]Images:[/]")
    img_result = subprocess.run(
        [
            "docker",
            "image",
            "ls",
            "--filter",
            "reference=routertl-*",
            "--format",
            "{{.Repository}}:{{.Tag}}\t{{.Size}}\t{{.CreatedSince}}",
        ],
        capture_output=True,
        text=True,
    )
    if img_result.returncode != 0 or not img_result.stdout.strip():
        console.print("    [dim](none)[/]")
    else:
        for line in img_result.stdout.strip().splitlines():
            parts = line.split("\t")
            repo_tag = parts[0]
            size = parts[1] if len(parts) > 1 else ""
            created = parts[2] if len(parts) > 2 else ""
            console.print(
                f"    [green]●[/] {repo_tag}  "
                f"[yellow]{size}[/]  "
                f"[dim]{created}[/]"
            )

    console.print()

    # --- Containers ---
    console.print("  [cyan]Containers:[/]")
    ctr_result = subprocess.run(
        ["docker", "ps", "-a", "--filter", "name=routertl-", "--format", "{{.Names}}\t{{.Status}}\t{{.Image}}"],
        capture_output=True,
        text=True,
    )
    if ctr_result.returncode != 0 or not ctr_result.stdout.strip():
        console.print("    [dim](none)[/]")
    else:
        for line in ctr_result.stdout.strip().splitlines():
            parts = line.split("\t")
            name = parts[0]
            status = parts[1] if len(parts) > 1 else "unknown"
            image = parts[2] if len(parts) > 2 else ""
            if "Up" in status:
                indicator = "[green]●[/]"
            else:
                indicator = "[red]●[/]"
            console.print(f"    {indicator} {name}  [dim]{status}  ({image})[/]")

    console.print()
