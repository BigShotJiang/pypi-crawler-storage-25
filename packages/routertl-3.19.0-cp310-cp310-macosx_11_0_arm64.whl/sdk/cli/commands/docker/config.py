# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Docker config command — show/edit EDA install configurations."""


import rich_click as click

from sdk.cli.commands.docker import (
    _CONFIG_FILES,
    _find_sdk_docker_dir,
    docker_group,
)
from sdk.cli.console import console
from sdk.cli.resilience import cli_resilient_block


@docker_group.command(name="config")
@click.argument("env", type=click.Choice(["vivado", "quartus", "radiant", "riviera", "libero"]), required=False, default=None)
@click.option("--edit", is_flag=True, help="Open the config file in $EDITOR.")
def docker_config(env, edit):
    """Show or edit the install configuration for an EDA tool.

    Without arguments, lists the available configurations.

    Examples:
        routertl docker config                 # List available configs
        routertl docker config vivado          # Show config
        routertl docker config vivado --edit   # Open in editor
    """
    docker_dir = _find_sdk_docker_dir()

    # No argument → list available configs
    if env is None:
        console.print("\n🐳 [cyan]Available EDA Configurations[/]\n")
        for name, filename in sorted(_CONFIG_FILES.items()):
            if filename:
                path = docker_dir / filename
                exists = path.exists()
                icon = "[green]✅[/]" if exists else "[red]❌[/]"
                console.print(f"  {icon} [cyan]{name:10s}[/] [dim]{path}[/]")
            else:
                console.print(
                    f"  [green]✅[/] [cyan]{name:10s}[/] [dim](automated install — no config file)[/]"
                )
        console.print("\n  [dim]Usage:[/]")
        console.print("    routertl docker config vivado          [dim]# View config[/]")
        console.print("    routertl docker config vivado --edit   [dim]# Open in $EDITOR[/]\n")
        return

    config_file = docker_dir / _CONFIG_FILES[env] if _CONFIG_FILES[env] else None

    if config_file and not config_file.exists():
        console.print(f"❌ [red]Config file not found:[/] {config_file}")
        import sys
        sys.exit(1)

    if edit:
        if not config_file:
            console.print(f"ℹ️  [blue]{env} uses automated installation — no config file to edit.[/]")
            return
        import os

        editor = os.environ.get("EDITOR", "vi")
        console.print(f"📝 [blue]Opening [cyan]{config_file.name}[blue] in {editor}...[/]")
        os.execvp(editor, [editor, str(config_file)])
    else:
        import os
        from pathlib import Path

        if config_file:
            console.print(f"📄 [blue]Install configuration for [cyan]{env}[/]")
            console.print(f"   [dim]File: {config_file}[/]")
            console.print(f"   [dim]Edit: routertl docker config {env} --edit[/]")
            console.print()
            with open(config_file) as f:
                for line in f:
                    line = line.rstrip()
                    if line.startswith("##"):
                        console.print(f"   [dim]{line}[/]")
                    elif line.startswith("#"):
                        console.print(f"   [dim]{line}[/]")
                    elif "=" in line:
                        key, _, val = line.partition("=")
                        console.print(f"   [cyan]{key}[/]=[green]{val}[/]")
                    else:
                        click.echo(f"   {line}")

        # ── Installer path detection ──
        env_var = {
            "vivado": "VIVADO_INSTALLER_PATH",
            "quartus": "QUARTUS_INSTALLER_PATH",
            "riviera": "RIVIERA_INSTALLER_PATH",
            "radiant": "RADIANT_INSTALLER_PATH",
            "libero": "LIBERO_INSTALLER_PATH",
        }[env]
        installer_patterns = {
            "vivado": ("*.tar.gz", "*.bin", "xsetup"),
            "quartus": ("*.tar", "setup.sh", "setup_pro.sh"),
            "riviera": ("Riviera-PRO*.bin", "Riviera-PRO*.run"),
            "radiant": ("*Radiant*.run", "*Radiant*.zip"),
            "libero": ("*Libero_SoC*.bin", "*Libero_SoC*.zip"),
        }[env]

        # Read from .env file (same as docker-compose does)
        installer_path = os.environ.get(env_var)
        dotenv = Path(".env")
        if dotenv.exists() and not installer_path:
            with cli_resilient_block(".env installer path reading"):
                for line in dotenv.read_text().splitlines():
                    line = line.strip()
                    if line.startswith(f"{env_var}="):
                        installer_path = line.split("=", 1)[1].strip().strip("'\"")
                        break

        console.print(f"\n📦 [blue]Installer Path ([cyan]{env_var}[blue])[/]")
        if not installer_path:
            console.print("   [yellow]⚠️  Not set[/]")
            console.print("   [dim]Must point to the DIRECTORY containing the installer files.[/]\n")

            user_path = click.prompt(
                f"   Enter path to {env} installer directory (or press Enter to skip)",
                default="",
                show_default=False,
            ).strip()

            if user_path:
                p = Path(user_path).expanduser().resolve()
                if not p.is_dir():
                    console.print(f"   [red]❌ '{p}' is not a valid directory.[/]")
                else:
                    installer_path = str(p)
                    # Write to .env
                    if dotenv.exists():
                        content = dotenv.read_text()
                    else:
                        content = ""
                    lines = content.splitlines()
                    found_key = False
                    for i, ln in enumerate(lines):
                        if ln.strip().startswith(f"{env_var}="):
                            lines[i] = f"{env_var}={installer_path}"
                            found_key = True
                            break
                    if not found_key:
                        if lines and lines[-1].strip():
                            lines.append("")
                        lines.append(f"{env_var}={installer_path}")
                    dotenv.write_text("\n".join(lines) + "\n")
                    console.print("   [green]✅ Saved to .env[/]")
            else:
                console.print("   [dim]Skipped. Set later with: routertl docker setup[/]")

        # ── Scan installer directory (runs for both existing and just-entered paths) ──
        if installer_path:
            console.print(f"   Path: [cyan]{installer_path}[/]")
            p = Path(installer_path).expanduser()
            if not p.exists():
                console.print("   [red]❌ Directory does not exist[/]")
            elif p.is_file():
                console.print("   [red]❌ Points to a FILE, must be a DIRECTORY[/]")
                console.print("   [dim]Set it to the directory containing the installer[/]")
            else:
                found = []
                for pattern in installer_patterns:
                    found.extend(p.glob(pattern))
                if found:
                    console.print(f"   [green]✅ {len(found)} installer file(s) found:[/]")
                    for f in sorted(found)[:5]:
                        size = f.stat().st_size / (1024 * 1024 * 1024)
                        console.print(f"      [cyan]{f.name}[/] ({size:.1f} GB)")
                else:
                    console.print("   [yellow]⚠️  No installer files found[/]")
                    patterns_str = ", ".join(installer_patterns)
                    console.print(f"   [dim]Expected: {patterns_str}[/]")
        console.print()
