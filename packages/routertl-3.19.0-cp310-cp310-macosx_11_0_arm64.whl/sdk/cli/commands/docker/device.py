# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Docker add-device and add-patch commands for EDA volume management."""

import subprocess
import sys
from pathlib import Path

import rich_click as click

from sdk.cli.commands.docker import (
    _INSTALLER_PATH_VARS,
    _find_sdk_docker_dir,
    _read_env_var,
    _resolve_install_mount,
    _resolve_volume,
    docker_group,
)
from sdk.cli.console import console


@docker_group.command(name="add-device")
@click.argument("env", type=click.Choice(["quartus"]), required=True)
def docker_add_device(env):
    """Install device packages (.qdz) into an existing EDA volume.

    Extracts .qdz device files directly into the Quartus installation
    volume without re-running the full installer. Much faster than a
    volume rebuild. Supports both Docker named volumes and bind mount
    installations (via QUARTUS_INSTALL_DIR in .env).

    Prerequisites:
      - Quartus must already be installed (via 'rr docker shell quartus')
      - .qdz files must be in your QUARTUS_INSTALLER_PATH directory

    Examples:
        rr docker add-device quartus
    """
    # ── Resolve install mount: bind mount OR Docker volume ──
    install_mount = _resolve_install_mount(env)
    volume_name = None

    if install_mount:
        # Bind mount — skip Docker volume check
        console.print(f"📂 [blue]Using bind mount: [cyan]{install_mount}[/]")
    else:
        # Named volume path
        volume_name = _resolve_volume(env)
        if not volume_name:
            console.print(f"❌ [red]{env} has no persistent volume.[/]")
            sys.exit(1)

        # Check volume exists
        vol_check = subprocess.run(
            ["docker", "volume", "inspect", volume_name],
            capture_output=True, text=True,
        )
        if vol_check.returncode != 0:
            console.print(f"❌ [red]Volume '{volume_name}' does not exist.[/]")
            console.print(f"   [dim]Install {env.capitalize()} first: rr docker install {env}[/]")
            sys.exit(1)

    # Read installer path from .env
    path_var = _INSTALLER_PATH_VARS[env]
    installer_path = _read_env_var(path_var)
    if not installer_path:
        console.print(f"❌ [red]{path_var} is not set in .env[/]")
        console.print("   [dim]Set it with: rr docker setup[/]")
        sys.exit(1)

    installer_path_resolved = Path(installer_path).expanduser()
    if not installer_path_resolved.exists():
        console.print(f"❌ [red]Installer path does not exist: {installer_path}[/]")
        sys.exit(1)

    # Locate the add-device script
    docker_dir = _find_sdk_docker_dir()
    script = docker_dir / f"add_device_{env}.sh"
    if not script.exists():
        console.print(f"❌ [red]Script not found: {script}[/]")
        sys.exit(1)

    # Check image exists (needed as base for the container)
    image_name = f"routertl-{env}:latest"
    img_check = subprocess.run(
        ["docker", "image", "inspect", image_name],
        capture_output=True, text=True,
    )
    if img_check.returncode != 0:
        console.print(f"❌ [red]Image '{image_name}' not found.[/]")
        console.print(f"   [dim]Install it first: rr docker install {env}[/]")
        sys.exit(1)

    # Scan for .qdz files before launching
    qdz_files = list(installer_path_resolved.glob("*.qdz"))
    if not qdz_files:
        console.print(f"⚠️  [yellow]No .qdz files found in {installer_path}[/]")
        console.print("   [dim]Download device packages from Intel FPGA Download Center[/]")
        console.print(f"   [dim]and place them in: {installer_path}[/]")
        sys.exit(0)

    console.print(f"📦 [blue]Adding {len(qdz_files)} device package(s) to [cyan]{env}[/]")
    for qf in sorted(qdz_files):
        size_gb = qf.stat().st_size / (1024 ** 3)
        console.print(f"   [cyan]{qf.name}[/] ({size_gb:.1f} GB)")
    console.print("")

    # Build docker run command
    # Use bind mount path if available, otherwise named volume
    volume_mount = f"{install_mount}:/opt/altera" if install_mount else f"{volume_name}:/opt/altera"
    cmd = [
        "docker", "run", "--rm",
        "-v", volume_mount,
        "-v", f"{installer_path_resolved}:/installers:ro",
        "-v", f"{script}:/home/runner/add_device.sh:ro",
        "-e", f"QUARTUS_INSTALLER_PATH_HOST={installer_path}",
        "--user", "root",
        image_name,
        "bash", "/home/runner/add_device.sh",
    ]

    result = subprocess.run(cmd, check=False)
    if result.returncode != 0:
        console.print(f"\n❌ [red]Device installation failed (exit code: {result.returncode})[/]")
        sys.exit(result.returncode)
    else:
        console.print("✅ [green]Device installation complete![/]")


@docker_group.command(name="add-patch")
@click.argument("env", type=click.Choice(["quartus"]), required=True)
def docker_add_patch(env):
    """Apply hotfix patches to an existing EDA installation.

    Extracts the .run patch installer from Altera patch ZIPs and
    applies it to the existing Quartus installation volume.

    Prerequisites:
      - Quartus must already be installed (via 'rr docker shell quartus')
      - Patch .zip files must be in your QUARTUS_INSTALLER_PATH directory

    Examples:
        rr docker add-patch quartus
    """
    volume_name = _resolve_volume(env)
    if not volume_name:
        console.print(f"❌ [red]{env} has no persistent volume.[/]")
        sys.exit(1)

    # Check volume exists
    vol_check = subprocess.run(
        ["docker", "volume", "inspect", volume_name],
        capture_output=True, text=True,
    )
    if vol_check.returncode != 0:
        console.print(f"❌ [red]Volume '{volume_name}' does not exist.[/]")
        console.print(f"   [dim]Install {env.capitalize()} first: rr docker shell {env}[/]")
        sys.exit(1)

    # Read installer path from .env
    path_var = _INSTALLER_PATH_VARS[env]
    installer_path = _read_env_var(path_var)
    if not installer_path:
        console.print(f"❌ [red]{path_var} is not set in .env[/]")
        console.print("   [dim]Set it with: rr docker setup[/]")
        sys.exit(1)

    installer_path_resolved = Path(installer_path).expanduser()
    if not installer_path_resolved.exists():
        console.print(f"❌ [red]Installer path does not exist: {installer_path}[/]")
        sys.exit(1)

    # Locate the add-patch script
    docker_dir = _find_sdk_docker_dir()
    script = docker_dir / f"add_patch_{env}.sh"
    if not script.exists():
        console.print(f"❌ [red]Script not found: {script}[/]")
        sys.exit(1)

    # Check image exists
    image_name = f"routertl-{env}:latest"
    img_check = subprocess.run(
        ["docker", "image", "inspect", image_name],
        capture_output=True, text=True,
    )
    if img_check.returncode != 0:
        console.print(f"❌ [red]Image '{image_name}' not found.[/]")
        console.print(f"   [dim]Install it first: rr docker install {env}[/]")
        sys.exit(1)

    # Scan for patch .zip files
    zip_files = list(installer_path_resolved.glob("*.zip"))
    if not zip_files:
        console.print(f"⚠️  [yellow]No .zip patch files found in {installer_path}[/]")
        console.print("   [dim]Download patches from Intel FPGA Download Center[/]")
        sys.exit(0)

    console.print(f"🩹 [blue]Applying {len(zip_files)} patch file(s) to [cyan]{env}[/]")
    for zf in sorted(zip_files):
        size_mb = zf.stat().st_size / (1024 ** 2)
        console.print(f"   [cyan]{zf.name}[/] ({size_mb:.0f} MB)")
    console.print("")

    # Build docker run command
    cmd = [
        "docker", "run", "--rm",
        "-v", f"{volume_name}:/opt/altera",
        "-v", f"{installer_path_resolved}:/installers:ro",
        "-v", f"{script}:/home/runner/add_patch.sh:ro",
        "-e", f"QUARTUS_INSTALLER_PATH_HOST={installer_path}",
        "--user", "root",
        image_name,
        "bash", "/home/runner/add_patch.sh",
    ]

    result = subprocess.run(cmd, check=False)
    if result.returncode != 0:
        console.print(f"\n❌ [red]Patch installation failed (exit code: {result.returncode})[/]")
        sys.exit(result.returncode)
    else:
        console.print("✅ [green]Patch applied successfully![/]")
