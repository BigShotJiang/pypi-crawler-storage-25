# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Docker build, shell, and run commands."""

import sys

import rich_click as click

from sdk.cli.commands.docker import _run_docker_sh, docker_group
from sdk.cli.console import console

# ── Vivado Device Families ────────────────────────────────────────────────
# Ordered by popularity. Each adds ~5-10 GB to the installation.
_VIVADO_FAMILIES = [
    ("Zynq-7000", True, "Zynq SoC (ARM + FPGA, popular for embedded)"),
    ("Zynq UltraScale+ MPSoC", False, "ZU+ SoC (64-bit ARM, video, ML)"),
    ("Artix-7", True, "Low-cost, low-power 7-series"),
    ("Kintex-7", False, "Mid-range 7-series"),
    ("Virtex-7", False, "High-performance 7-series"),
    ("Kintex UltraScale", False, "Mid-range UltraScale"),
    ("Virtex UltraScale+", False, "High-performance UltraScale+"),
    ("Versal AI Core", False, "Versal adaptive SoC (AI engine)"),
    ("Versal Prime", False, "Versal adaptive SoC (general purpose)"),
]


def _vivado_device_picker():
    """Interactive device family selection for Vivado Docker install."""
    from pathlib import Path

    from sdk.cli.commands.docker import _find_sdk_docker_dir

    docker_dir = _find_sdk_docker_dir()
    config_path = Path(docker_dir) / "install_config.vivado.txt"

    if not config_path.exists():
        return

    console.print("\n   📋 [cyan]Vivado Device Families[/]")
    console.print("   [dim]Each family adds ~5-10 GB. Select what you need.[/]\n")

    selected = {}
    for name, default, desc in _VIVADO_FAMILIES:
        marker = "[green]●[/]" if default else "[dim]○[/]"
        default_label = " (default)" if default else ""
        console.print(f"      {marker} {name}{default_label}")
        console.print(f"        [dim]{desc}[/]")
        selected[name] = default

    console.print()
    console.print("   [dim]Answer yes to be prompted for each family individually.[/]")
    if click.confirm("   Customize selection?", default=False):
        console.print()
        for family_name, family_default, _desc in _VIVADO_FAMILIES:
            enabled = click.confirm(
                f"      Install {family_name}?", default=family_default,
            )
            selected[family_name] = enabled
        console.print()

    # Build Modules string
    modules = ",".join(f"{name}:{1 if on else 0}" for name, on in selected.items())
    enabled = [n for n, on in selected.items() if on]
    console.print(f"   ✅ Selected: [cyan]{', '.join(enabled)}[/]")

    # Update install_config
    content = config_path.read_text()
    lines = content.splitlines()
    new_lines = []
    modules_written = False
    for line in lines:
        stripped = line.strip()
        # Replace existing Modules= line (skip commented ones)
        if stripped.startswith("Modules=") and not stripped.startswith("#"):
            new_lines.append(f"Modules={modules}")
            modules_written = True
        elif stripped.startswith("# Modules="):
            # Keep commented examples but add our line before them
            if not modules_written:
                new_lines.append(f"Modules={modules}")
                modules_written = True
            new_lines.append(line)
        else:
            new_lines.append(line)

    if not modules_written:
        new_lines.append(f"Modules={modules}")

    config_path.write_text("\n".join(new_lines) + "\n")
    console.print(f"   [dim]Written to {config_path}[/]")


@docker_group.command(name="shell")
@click.argument("env", type=click.Choice(["sim", "vivado", "buildroot", "quartus", "radiant", "questa", "riviera", "libero"]), required=True)
def docker_shell(env):
    """Start interactive shell in Docker container."""
    console.print(f"🐳 [blue]Starting interactive shell in [cyan]{env}[blue] container...[/]")
    _run_docker_sh("shell", env)


@docker_group.command(name="install")
@click.argument("env", type=click.Choice(["sim", "vivado", "buildroot", "quartus", "radiant", "questa", "riviera", "libero"]), required=True)
@click.option("--non-interactive", is_flag=True, help="Skip prompts, use defaults (for CI/CD).")
def docker_install(env, non_interactive):
    """Install Docker image for a specific environment."""
    import subprocess as sp

    # P2.183: Pre-flight Docker connectivity check.
    # Only runs when the base image isn't cached locally — avoids the
    # cryptic Dockerfile failure on first use (WSL, fresh installs).
    base_check = sp.run(
        ["docker", "images", "-q", "ubuntu:22.04"],
        capture_output=True, text=True, timeout=10,
    )
    if not base_check.stdout.strip():
        console.print("🔍 [dim]Pulling base image (first time only)...[/]")
        preflight = sp.run(
            ["docker", "pull", "ubuntu:22.04"],
            capture_output=True, text=True, timeout=120,
        )
        if preflight.returncode != 0:
            console.print("[red]❌ Cannot pull base image from Docker Hub[/]")
            console.print("[dim]   Possible causes:[/]")
            console.print("[dim]   • Docker Desktop not running (check system tray)[/]")
            console.print("[dim]   • WSL integration not enabled (Docker Desktop → Settings → Resources → WSL)[/]")
            console.print("[dim]   • Network/proxy issue — try: docker pull ubuntu:22.04[/]")
            console.print("[dim]   • Not logged in — try: docker login[/]")
            sys.exit(1)
        console.print("   [green]✅ Base image pulled[/]")

    # P1.23: Pre-flight check for EDA environments that need an installer.
    # Verify required env vars are set before starting a long build that
    # would fail at the end. Auto-trigger `rr docker setup` if missing.
    _NEEDS_INSTALLER = {
        "vivado": ("VIVADO_INSTALLER_PATH", "Vivado"),
        "quartus": ("QUARTUS_INSTALLER_PATH", "Quartus"),
        "radiant": ("RADIANT_INSTALLER_PATH", "Radiant"),
    }
    if env in _NEEDS_INSTALLER:
        env_var, tool_name = _NEEDS_INSTALLER[env]
        from sdk.cli.commands.docker import _read_env_var

        installer_path = _read_env_var(env_var)

        if not installer_path:
            console.print(f"\n⚠️  [yellow]{tool_name} Docker requires the installer path.[/]")
            console.print(f"   [dim]{tool_name} is NOT downloaded automatically — you must provide[/]")
            console.print("   [dim]your own installer (downloaded from the vendor website).[/]")
            console.print(f"   [dim]{env_var} is not set in .env[/]\n")

            if click.confirm(f"   Run guided setup for {tool_name} now?", default=True):
                from sdk.cli.commands.docker.setup import docker_setup
                ctx = click.Context(docker_setup)
                ctx.invoke(docker_setup, target=env)

                # Re-check after setup
                installer_path = _read_env_var(env_var)
                if not installer_path:
                    console.print(f"   [red]❌ {env_var} still not set. Cannot proceed.[/]")
                    sys.exit(1)
            else:
                console.print(f"   [dim]Set it manually: rr docker setup --target {env}[/]")
                sys.exit(1)

        # Verify the path exists and contains installer files
        from pathlib import Path
        ip = Path(installer_path).expanduser()
        if not ip.is_dir():
            console.print(f"[red]❌ {env_var}={installer_path} is not a valid directory[/]")
            sys.exit(1)

        # Check for installer files (tar, tar.gz, bin, exe)
        installer_files = (
            list(ip.glob("*.tar.gz")) + list(ip.glob("*.tar"))
            + list(ip.glob("*.bin")) + list(ip.glob("*.exe"))
        )
        # Exclude .tar.gz from the .tar glob (Path.glob("*.tar") also matches .tar.gz)
        installer_files = list({f for f in installer_files})
        if not installer_files:
            console.print(f"[yellow]⚠️  No installer files found in {installer_path}[/]")
            console.print(f"   [dim]Expected: *.tar.gz, *.tar, *.bin, or *.exe from {tool_name} download[/]")
            if not click.confirm("   Continue anyway?", default=False):
                sys.exit(1)
        else:
            console.print(f"   📦 Found {len(installer_files)} installer file(s) in {installer_path}")
            for f in installer_files[:3]:
                size_gb = f.stat().st_size / (1024 ** 3)
                console.print(f"      [dim]{f.name} ({size_gb:.1f} GB)[/]")

        # Auto-detect version from installer filename if VIVADO_VERSION not set
        if env == "vivado":
            import os
            import re
            if not os.environ.get("VIVADO_VERSION") and not _read_env_var("VIVADO_VERSION"):
                for f in installer_files:
                    m = re.search(r"(\d{4}\.\d+)", f.name)
                    if m:
                        detected_ver = m.group(1)
                        console.print(f"   🔍 Auto-detected Vivado version: [cyan]{detected_ver}[/]")
                        # Write to .env
                        env_path = Path(".env")
                        if env_path.exists():
                            content = env_path.read_text()
                        else:
                            content = ""
                        if "VIVADO_VERSION=" not in content:
                            with open(env_path, "a") as f:
                                f.write(f"\nVIVADO_VERSION={detected_ver}\n")
                            console.print(f"   [green]✅ VIVADO_VERSION={detected_ver} saved to .env[/]")
                        break

        # P2.188: Interactive device family selection for Vivado
        if env == "vivado" and not non_interactive:
            _vivado_device_picker()

        console.print()

    # Environments that depend on the sim base image
    _NEEDS_SIM = {"vivado", "quartus", "radiant", "questa", "riviera", "libero"}

    if env in _NEEDS_SIM:
        # Check if routertl-sim image exists locally
        result = sp.run(
            ["docker", "images", "-q", "routertl-sim:latest"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if not result.stdout.strip():
            console.print(
                f"📦 [yellow]{env}[/] requires the "
                f"[cyan]sim[/] base image, which is not built yet."
            )
            console.print("   [dim]Building it first automatically...[/]\n")
            console.print("🐳 [blue]Building base [cyan]sim[blue] image...[/]")
            _run_docker_sh("install", "sim")
            console.print()

    console.print(f"🐳 [blue]Building Docker image for [cyan]{env}[blue]...[/]")
    _run_docker_sh("install", env)


@docker_group.command(name="run")
@click.argument("env", type=click.Choice(["sim", "vivado", "buildroot", "quartus", "radiant", "questa", "riviera", "libero"]), required=True)
@click.argument("cmd", required=False, default=None)
def docker_run(env, cmd):
    """Run command in Docker (e.g. routertl docker run sim 'make simulation').

    If CMD is omitted, starts an interactive shell (same as 'docker shell').
    """
    if cmd:
        console.print(f"🐳 [blue]Running command in [cyan]{env}[blue] container...[/]")
        _run_docker_sh("run", env, cmd)
    else:
        console.print(
            f"🐳 [blue]Starting interactive shell in [cyan]{env}[blue] container...[/]"
        )
        _run_docker_sh("shell", env)


# ── Deprecated aliases (hidden from --help, kept for backward compat) ──
# P2.29: 'build' was renamed to 'install' for verb symmetry with 'uninstall'.
# We create a proper hidden command that mirrors the install command.
@docker_group.command(name="build", hidden=True)
@click.argument("env", type=click.Choice(["sim", "vivado", "buildroot", "quartus", "radiant", "questa", "riviera", "libero"]), required=True)
def docker_build_alias(env):
    """Install Docker image (alias for 'install')."""
    docker_install.callback(env, non_interactive=False)
