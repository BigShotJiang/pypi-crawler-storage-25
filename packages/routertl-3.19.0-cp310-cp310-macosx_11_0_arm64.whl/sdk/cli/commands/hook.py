"""rr hook — TCL hook management commands."""

from __future__ import annotations

import re
from pathlib import Path

import rich_click as click
import yaml

from sdk.cli.console import console


@click.group(name="hook")
def hook_group():
    """Manage TCL hooks for vendor tool integration."""


# ── Vivado BD detection patterns ─────────────────────────────────────────────

# Lines that signal a Vivado-exported block design TCL
_BD_SIGNATURES = [
    re.compile(r"^\s*create_bd_design\b"),
    re.compile(r"^\s*create_bd_cell\b"),
    re.compile(r"This is a generated script based on design:"),
]

# Boilerplate blocks to strip (start, end) — matched line-by-line
_PROJECT_GUARD_START = re.compile(
    r"^\s*set\s+list_projs\s+\[get_projects\s+-quiet\]"
)
_PROJECT_GUARD_END = re.compile(r"^\s*\}")  # closing brace of the if block

_NAMESPACE_EVAL = re.compile(r"^\s*namespace\s+eval\s+_tcl\b")

# The verbose design-existence check block
_DESIGN_CHECK_START = re.compile(
    r"^\s*set\s+cur_design\s+\[current_bd_design\s+-quiet\]"
)
_DESIGN_CHECK_END = re.compile(
    r"^\s*if\s*\{\s*\$nRet\s*!=\s*0\s*\}"
)


def _is_vivado_bd(lines: list[str]) -> bool:
    """Detect if a TCL file is a Vivado-exported block design."""
    hits = 0
    for line in lines[:150]:  # Only check the top of the file
        for pat in _BD_SIGNATURES:
            if pat.search(line):
                hits += 1
    return hits >= 1


def _extract_design_name(lines: list[str]) -> str:
    """Extract the design_name variable from the exported TCL."""
    for line in lines:
        m = re.match(r"^\s*set\s+design_name\s+(\S+)", line)
        if m:
            return m.group(1)
    return "block_design"


def _extract_module_references(lines: list[str]) -> list[str]:
    """Extract module references from Vivado BD export comments."""
    refs = []
    in_refs = False
    for line in lines[:50]:
        if "module references:" in line.lower():
            in_refs = True
            # Extract from same line: "# module references: foo"
            after = line.split(":", 1)[-1].strip()
            if after:
                refs.extend(after.split())
            continue
        if in_refs:
            stripped = line.strip().lstrip("#").strip()
            if stripped and not stripped.startswith("Please"):
                refs.append(stripped)
            else:
                in_refs = False
    return refs


def _adapt_vivado_bd(lines: list[str]) -> list[str]:
    """Strip Vivado boilerplate from a block design export.

    Removes:
    - namespace eval _tcl block
    - Project creation guard (get_projects / create_project)
    - Design existence check (the 8-case branching)
    - send_gid_msg noise at the top level (kept inside procs)

    Replaces with clean create_bd_design / current_bd_design.
    """
    design_name = _extract_design_name(lines)
    out: list[str] = []
    skip_until: re.Pattern | None = None
    brace_depth = 0
    in_namespace_block = False
    in_project_guard = False
    in_design_check = False
    in_nret_guard = False
    injected_clean_header = False

    i = 0
    while i < len(lines):
        line = lines[i]

        # ── Skip namespace eval _tcl { ... } block ──
        if _NAMESPACE_EVAL.search(line) and not in_namespace_block:
            in_namespace_block = True
            brace_depth = line.count("{") - line.count("}")
            i += 1
            continue
        if in_namespace_block:
            brace_depth += line.count("{") - line.count("}")
            if brace_depth <= 0:
                in_namespace_block = False
            i += 1
            continue

        # Skip the script_folder variable declarations
        if re.match(r"^\s*variable\s+script_folder", line):
            i += 1
            continue
        if re.match(r"^\s*set\s+script_folder\s+\[_tcl::", line):
            i += 1
            continue

        # ── Skip project creation guard ──
        if _PROJECT_GUARD_START.search(line):
            in_project_guard = True
            brace_depth = line.count("{") - line.count("}")
            i += 1
            continue
        if in_project_guard:
            brace_depth += line.count("{") - line.count("}")
            if brace_depth <= 0:
                in_project_guard = False
            i += 1
            continue

        # ── Skip design existence check ──
        if _DESIGN_CHECK_START.search(line):
            in_design_check = True
            i += 1
            continue
        if in_design_check:
            # The block ends at the line AFTER "if { $nRet != 0 } {" ... "}"
            if _DESIGN_CHECK_END.search(line):
                in_design_check = False
                in_nret_guard = True
                brace_depth = line.count("{") - line.count("}")
                i += 1
                continue
            i += 1
            continue
        if in_nret_guard:
            brace_depth += line.count("{") - line.count("}")
            if brace_depth <= 0:
                in_nret_guard = False
                # Inject clean header after stripping
                if not injected_clean_header:
                    out.append("")
                    out.append("# Block design name")
                    out.append(f"set design_name {design_name}")
                    out.append("create_bd_design $design_name")
                    out.append("current_bd_design $design_name")
                    out.append("")
                    injected_clean_header = True
            i += 1
            continue

        # Skip standalone send_gid_msg at top level (not inside procs)
        if re.match(r"^\s*common::send_gid_msg\b", line):
            i += 1
            continue

        # Skip "set design_name X" (we emit our own)
        if re.match(r"^\s*set\s+design_name\s+", line) and not injected_clean_header:
            i += 1
            continue

        # Skip "CHANGE DESIGN NAME HERE" comment
        if "CHANGE DESIGN NAME HERE" in line:
            i += 1
            continue

        # Skip Vivado's usage comments about create_project / source
        if re.match(r"^#\s*To test this script, run", line):
            i += 1
            continue
        if re.match(r"^#\s*source\s+\S+_script\.tcl", line):
            i += 1
            continue
        if re.match(r"^#\s*If there is no project opened", line):
            # Skip the next few comment lines about project creation
            while i < len(lines) and lines[i].startswith("#"):
                i += 1
            continue

        # Skip design check preamble variables
        if re.match(r"^\s*set\s+list_cells\s+\[get_bd_cells", line):
            i += 1
            continue
        if re.match(r"^\s*set\s+errMsg\s+", line):
            i += 1
            continue
        if re.match(r"^\s*set\s+nRet\s+", line):
            i += 1
            continue
        if re.match(r"^\s*variable\s+design_name", line):
            i += 1
            continue
        # Skip Vivado's "Creating design if needed" / "you can create a design" comments
        if re.match(r"^#\s*Creating design if needed", line):
            i += 1
            continue
        if re.match(r"^#\s*(If you do not already have|you can create a design)", line):
            i += 1
            continue
        if re.match(r"^#\s+create_bd_design\s+\$design_name", line):
            i += 1
            continue

        out.append(line)
        i += 1

    # ── Replace rigid bCheckIPs with version-flexible matching (P2.265) ──
    out = _adapt_ip_version_check(out)

    # Collapse runs of 3+ blank lines into 2
    cleaned: list[str] = []
    blank_count = 0
    for line in out:
        if line.strip() == "":
            blank_count += 1
            if blank_count <= 2:
                cleaned.append(line)
        else:
            blank_count = 0
            cleaned.append(line)

    return cleaned


# ── Flexible IP version check block ────────────────────────────────────────

_RR_IP_CHECK_BLOCK = """\
##################################################################
# CHECK IPs (RouteRTL — version-flexible, P2.265)
##################################################################
set bCheckIPs 1
if { $bCheckIPs == 1 } {
   set list_check_ips [list \\
{IP_LIST_PLACEHOLDER}
   ]

   set list_ips_missing ""

   foreach ip_vlnv $list_check_ips {
      set ip_obj [get_ipdefs -all $ip_vlnv]
      if { $ip_obj eq "" } {
         # Exact VLNV not found — try any version of the same IP
         set parts [split $ip_vlnv :]
         if {[llength $parts] == 4} {
            set vln "[lindex $parts 0]:[lindex $parts 1]:[lindex $parts 2]:*"
            set alt [get_ipdefs -all $vln]
            if { $alt ne "" } {
               # Use the first (usually latest) compatible version
               set alt_vlnv [lindex $alt 0]
               puts "INFO: RouteRTL — IP version substitution: $ip_vlnv -> $alt_vlnv"
            } else {
               lappend list_ips_missing $ip_vlnv
            }
         } else {
            lappend list_ips_missing $ip_vlnv
         }
      }
   }

   if { $list_ips_missing ne "" } {
      catch {common::send_gid_msg -ssname BD::TCL -id 2012 -severity "ERROR" "The following IPs are not found in the IP Catalog:\\n  $list_ips_missing\\n\\nResolution: Please add the repository containing the IP(s) to the project." }
      set bCheckIPsPassed 0
   }
}
"""


def _adapt_ip_version_check(lines: list[str]) -> list[str]:
    """Replace rigid bCheckIPs block with version-flexible matching.

    Also patches ``create_bd_cell -type ip -vlnv`` lines to use a
    helper proc that tries flexible version matching at runtime.
    """
    # ── Phase 1: replace the bCheckIPs block ──
    out: list[str] = []
    in_check_block = False
    brace_depth = 0
    ip_list: list[str] = []

    i = 0
    while i < len(lines):
        line = lines[i]

        # Detect start of the CHECK IPs block
        if re.match(r"^set\s+bCheckIPs\s+1", line.strip()) and not in_check_block:
            in_check_block = True
            brace_depth = 0
            i += 1
            continue

        if in_check_block:
            # Collect IP VLNVs from the list
            m = re.match(
                r"^\s*([\w.]+:[\w.]+:[\w.]+:[\d.]+)",
                line.strip().rstrip("\\").strip(),
            )
            if m:
                ip_list.append(m.group(1))

            # Track braces to find the end of the if block
            brace_depth += line.count("{") - line.count("}")
            if brace_depth <= 0 and "}" in line:
                # End of the bCheckIPs block — emit replacement
                ip_lines = "\n".join(
                    f"      {vlnv} \\" for vlnv in ip_list
                )
                replacement = _RR_IP_CHECK_BLOCK.replace(
                    "{IP_LIST_PLACEHOLDER}", ip_lines,
                )
                out.extend(replacement.splitlines())
                in_check_block = False
            i += 1
            continue

        # Skip the "CHECK IPs" comment header if it precedes the block
        if re.match(r"^#{3,}\s*$", line.strip()):
            # Look ahead for "CHECK IPs"
            if i + 1 < len(lines) and "CHECK IPs" in lines[i + 1]:
                # Skip the 3-line comment block
                i += 3
                continue

        out.append(line)
        i += 1

    # ── Phase 2: inject helper procs and patch create_bd_cell lines ──
    helper = [
        "",
        "# ── RouteRTL IP version resolver (P2.265) ──",
        "proc _rr_resolve_vlnv {vlnv} {",
        "    set ip_obj [get_ipdefs -all $vlnv]",
        "    if { $ip_obj ne {} } { return $vlnv }",
        "    set parts [split $vlnv :]",
        "    if {[llength $parts] == 4} {",
        '        set vln "[lindex $parts 0]:[lindex $parts 1]:[lindex $parts 2]:*"',
        "        set alt [get_ipdefs -all $vln]",
        "        if { $alt ne {} } {",
        "            set resolved [lindex $alt 0]",
        '            puts "INFO: RouteRTL — IP version: $vlnv -> $resolved"',
        "            return $resolved",
        "        }",
        "    }",
        "    return $vlnv",
        "}",
        "",
        "# ── RouteRTL resilient cell creation (P2.264 + P2.266) ──",
        "# Tracks failed create_bd_cell calls so downstream set_property",
        "# and connect_bd_* can skip gracefully instead of aborting.",
        "# P2.266: also records VLNVs for dummy stub generation.",
        "set _rr_failed_cells [list]",
        "",
        "proc _rr_create_cell {args} {",
        "    global _rr_failed_cells _rr_failed_vlnvs",
        "    if {[catch {set cell [eval create_bd_cell $args]} err]} {",
        "        set cell_name [lindex $args end]",
        "        # Extract VLNV for stub generation (P2.266)",
        "        set vi [lsearch $args {-vlnv}]",
        "        if {$vi >= 0} {",
        "            set vlnv [lindex $args [expr {$vi + 1}]]",
        '            dict set _rr_failed_vlnvs $cell_name $vlnv',
        "        }",
        "        lappend _rr_failed_cells $cell_name",
        '        puts "WARNING: RouteRTL — create_bd_cell failed ($cell_name): $err"',
        '        return ""',
        "    }",
        "    return $cell",
        "}",
        "",
        "proc _rr_cell_ok {cell_var} {",
        "    global _rr_failed_cells",
        "    upvar $cell_var cell",
        '    if {$cell eq ""} { return 0 }',
        "    return 1",
        "}",
        "",
    ]

    # Find insertion point — after the version check / before first proc
    insert_idx = 0
    for idx, line in enumerate(out):
        if re.match(r"^\s*proc\s+", line):
            insert_idx = idx
            break
    if insert_idx > 0:
        out = out[:insert_idx] + helper + out[insert_idx:]

    # ── Phase 3: patch create_bd_cell and set_property lines ──
    patched: list[str] = []
    # Track which variable holds each cell (e.g. "set v_tpg_0 [ create_bd_cell ...")
    _cell_var_pattern = re.compile(
        r"^\s*set\s+(\w+)\s+\[\s*create_bd_cell\s+-type\s+ip\s+"
    )
    _set_prop_pattern = re.compile(
        r"^(\s*set_property\s+.*)\]\s+\$(\w+)\s*$"
    )

    for line in out:
        if "create_bd_cell" in line and "-type ip" in line:
            # Replace create_bd_cell with _rr_create_cell.
            # VLNV resolution is already handled by _adapt_ip_version_check
            # (P2.265) which wraps VLNVs in [_rr_resolve_vlnv ...].
            line = line.replace("create_bd_cell ", "_rr_create_cell ", 1)
        patched.append(line)

    # Wrap set_property blocks that target a cell variable in a cell-ok check
    # Pattern: "set_property -dict [...] $cell_name" or "] $cell_name"
    final: list[str] = []
    i = 0
    while i < len(patched):
        line = patched[i]
        stripped = line.strip()
        # Match "set_property -dict [list \" — multi-line block start
        if re.match(r"set_property\s+-dict\s+\[list\s*\\", stripped):
            # Collect the whole block until "] $varname"
            block = [line]
            j = i + 1
            cell_var = ""
            while j < len(patched):
                block.append(patched[j])
                m = re.match(r"^\s*\]\s+\$(\w+)\s*$", patched[j].strip())
                if m:
                    cell_var = m.group(1)
                    break
                j += 1
            if cell_var:
                # Wrap the block in a cell-ok check
                indent = re.match(r"^(\s*)", line).group(1)
                final.append(f"{indent}if {{[_rr_cell_ok {cell_var}]}} {{")
                for bl in block:
                    final.append(f"  {bl}")
                final.append(f"{indent}}}")
                i = j + 1
                continue
        final.append(line)
        i += 1

    # ── Phase 4: embed dummy IP infrastructure (P2.266) ──
    # Extract port/interface info from connection commands and embed
    # as TCL arrays + the stub generation proc.
    from sdk.engine.dummy_ip import (
        extract_cell_ports,
        format_cell_ports_tcl,
        generate_dummy_ip_tcl_proc,
    )

    cell_ports = extract_cell_ports(final)
    if cell_ports:
        dummy_block = [
            "",
            "# ── RouteRTL dummy IP port info (P2.266) ──",
            format_cell_ports_tcl(cell_ports).rstrip(),
            generate_dummy_ip_tcl_proc().rstrip(),
            "",
        ]

        # Insert after the helper procs (find _rr_cell_ok closing brace)
        inject_idx = 0
        for idx, line in enumerate(final):
            if "_rr_cell_ok" in line and "proc" in line:
                # Find the closing brace of this proc
                for j in range(idx + 1, len(final)):
                    if final[j].strip() == "}":
                        inject_idx = j + 1
                        break
                break

        if inject_idx > 0:
            final = final[:inject_idx] + dummy_block + final[inject_idx:]

    return final


def _load_project_yml() -> tuple[dict, Path]:
    """Load project.yml from CWD. Returns (data, path)."""
    yml_path = Path("project.yml")
    if not yml_path.exists():
        return {}, yml_path
    with open(yml_path) as f:
        data = yaml.safe_load(f) or {}
    return data, yml_path


def _infer_hooks_dir(config: dict) -> Path:
    """Infer the hooks output directory from project.yml tcl_hooks entries."""
    hooks = config.get("tcl_hooks", {})
    gen_project_hooks = hooks.get("gen_project", [])
    if gen_project_hooks:
        # Use the directory of the first existing hook
        first = Path(gen_project_hooks[0])
        return first.parent
    return Path("tcl/hooks")


@hook_group.command(name="adapt")
@click.argument("tcl_file", type=click.Path(exists=True))
@click.option(
    "--no-register",
    is_flag=True,
    default=False,
    help="Don't auto-add to project.yml tcl_hooks.gen_project",
)
def adapt(tcl_file: str, no_register: bool):
    """Adapt a vendor-exported TCL script for use as a routertl hook.

    Currently supports Vivado block design exports (File → Export →
    Export Block Design). Strips project creation boilerplate and
    design existence checks, outputs a clean hook-ready script.

    The adapted file is placed in the hooks directory inferred from
    project.yml and auto-registered under tcl_hooks.gen_project.

    \b
    Example:
        rr hook adapt vivado_exported_bd.tcl
    """
    src = Path(tcl_file)
    lines = src.read_text().splitlines()

    if not _is_vivado_bd(lines):
        console.print(
            f"[yellow]WARNING:[/] {src.name} does not look like a Vivado block "
            "design export. Currently only Vivado BD adaptation is supported."
        )
        raise SystemExit(1)

    # Adapt
    original_count = len(lines)
    adapted = _adapt_vivado_bd(lines)
    stripped = original_count - len(adapted)

    # Detect module references
    refs = _extract_module_references(lines)

    # Determine output location
    config, yml_path = _load_project_yml()
    hooks_dir = _infer_hooks_dir(config)
    hooks_dir.mkdir(parents=True, exist_ok=True)

    out_path = hooks_dir / src.name
    if out_path.exists():
        console.print(
            f"[yellow]WARNING:[/] {out_path} already exists — overwriting."
        )

    out_path.write_text("\n".join(adapted) + "\n")

    console.print(
        f"✅ Adapted [cyan]{src.name}[/] → [green]{out_path}[/]"
    )
    console.print(
        f"   Stripped {stripped} lines of boilerplate, "
        f"kept {len(adapted)} lines."
    )

    if refs:
        console.print(
            f"   [dim]Module references found: "
            f"[cyan]{', '.join(refs)}[/] — ensure they're in sources.[/]"
        )

        # Advisory: check BD module references against discoverable IPs
        user_ip_paths = config.get("sources", {}).get("ip_paths", [])
        if user_ip_paths:
            from sdk.engine.ip_discovery import discover_ips

            project_root = yml_path.parent
            discovery = discover_ips(user_ip_paths, project_root)
            known_names = discovery.names
            for ref in refs:
                if ref.lower() not in known_names:
                    console.print(
                        f"   [yellow]WARNING:[/] BD references module "
                        f"[cyan]{ref}[/] but no matching IP found in ip_paths"
                    )
        else:
            console.print(
                "   [dim]Tip: add sources.ip_paths to project.yml to "
                "auto-validate BD module references against your IP repos.[/]"
            )

    # Auto-register in project.yml
    if not no_register and yml_path.exists():
        hook_rel = str(out_path)
        tcl_hooks = config.setdefault("tcl_hooks", {})
        gen_hooks = tcl_hooks.setdefault("gen_project", [])

        if hook_rel in gen_hooks:
            console.print(
                "   [dim]Already registered in project.yml tcl_hooks.gen_project[/]"
            )
        else:
            gen_hooks.append(hook_rel)
            with open(yml_path, "w") as f:
                yaml.dump(config, f, default_flow_style=False, sort_keys=False)
            console.print(
                "   ✅ Registered in [green]project.yml[/] → "
                "tcl_hooks.gen_project"
            )
    elif not yml_path.exists():
        console.print(
            "   [yellow]No project.yml found — hook not auto-registered. "
            "Add it manually to tcl_hooks.gen_project.[/]"
        )


@hook_group.command(name="list")
def list_hooks():
    """List all registered TCL hooks from project.yml."""
    config, yml_path = _load_project_yml()
    if not yml_path.exists():
        console.print("[yellow]No project.yml found.[/]")
        return

    hooks = config.get("tcl_hooks", {})
    if not hooks:
        console.print("[dim]No TCL hooks defined in project.yml.[/]")
        return

    for stage, hook_list in hooks.items():
        console.print(f"\n[bold]{stage}[/]:")
        if not hook_list:
            console.print("  [dim](none)[/]")
        for h in hook_list:
            exists = "✅" if Path(h).exists() else "❌"
            console.print(f"  {exists} {h}")
