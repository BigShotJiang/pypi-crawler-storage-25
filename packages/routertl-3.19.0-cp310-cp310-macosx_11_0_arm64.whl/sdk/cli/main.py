# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

import os
import sys
from pathlib import Path

import rich_click as click
from rich.panel import Panel
from rich.text import Text

from routertl_core import __version__, version_string
from sdk.cli.commands.alias import alias_group
from sdk.cli.commands.ask import ask_command
from sdk.cli.commands.bom import bom_command
from sdk.cli.commands.ci import ci_group
from sdk.cli.commands.completion import completion_command
from sdk.cli.commands.config import config_command
from sdk.cli.commands.deps import deps_group
from sdk.cli.commands.diff import diff_command
from sdk.cli.commands.diff_lock import diff_lock_command
from sdk.cli.commands.docker import docker_group
from sdk.cli.commands.doctor import doctor
from sdk.cli.commands.eda import eda_group
from sdk.cli.commands.fpga import fpga_group
from sdk.cli.commands.hardware import (
    bitstream_group,
    hierarchy,
    impl_group,
    linting,
    project_group,
    schematic,
    synth_targets,
)
from sdk.cli.commands.hardware_diag import hardware_group
from sdk.cli.commands.hook import hook_group
from sdk.cli.commands.info import info_command
from sdk.cli.commands.ip import ip_group, regbank_group, rom
from sdk.cli.commands.license import license_command
from sdk.cli.commands.linux import linux_group
from sdk.cli.commands.lock import lock_group
from sdk.cli.commands.mcp import mcp_group
from sdk.cli.commands.migrate import migrate_command
from sdk.cli.commands.pkg import pkg_group
from sdk.cli.commands.program import program_group
from sdk.cli.commands.ref import ref_group
from sdk.cli.commands.report import report_command
from sdk.cli.commands.routewave import routewave_command
from sdk.cli.commands.rules import rules_group
from sdk.cli.commands.sim import regression, scan_tests, sim_group, testgen, view_sim_log, waves
from sdk.cli.commands.sources import sources_command
from sdk.cli.commands.status import status
from sdk.cli.commands.synth import synth_group
from sdk.cli.commands.target import target_group
from sdk.cli.commands.telemetry import telemetry_group
from sdk.cli.commands.watch import watch_command
from sdk.cli.commands.workspace import workspace_group
from sdk.cli.console import console as _console
from sdk.cli.resilience import cli_resilient, cli_resilient_block

# ── CLI Branding ──────────────────────────────────────────────
# Projects can white-label the CLI via project.yml:
#
#   branding:
#     cli_name: mysdk             # binary alias
#     display_name: My Custom SDK      # shown in help / version
#
# Defaults to "routertl" / "RouteRTL SDK" when not set.


@cli_resilient(
    "branding config",
    default={"cli_name": "routertl", "display_name": "RouteRTL SDK"},
)
def _resolve_branding():
    """Read branding config from project.yml in CWD."""
    from sdk.cli.project_config import load_project_config

    defaults = {"cli_name": "routertl", "display_name": "RouteRTL SDK"}
    config = load_project_config()
    branding = config.get("branding", {})
    return {
        "cli_name": branding.get("cli_name", defaults["cli_name"]),
        "display_name": branding.get("display_name", defaults["display_name"]),
    }


_BRANDING = _resolve_branding()
CLI_NAME = _BRANDING["cli_name"]
"""The effective CLI binary name (e.g. 'routertl' or 'dskopsdk')."""
DISPLAY_NAME = _BRANDING["display_name"]
"""Human-readable SDK name for help text (e.g. 'RouteRTL SDK' or 'My Custom SDK')."""
# Configure rich-click to match RouteRTL's aesthetic
click.rich_click.TEXT_MARKUP = "rich"
click.rich_click.SHOW_ARGUMENTS = True
click.rich_click.GROUP_ARGUMENTS_OPTIONS = True
click.rich_click.STYLE_ERRORS_SUGGESTION = "magenta italic"
click.rich_click.ERRORS_SUGGESTION = "Try running '--help' for more information."

# Custom Help Layout
_COMMAND_LAYOUT = [
    {
        "name": "🚀 Quickstart",
        "commands": ["init", "routewave", "status", "doctor", "license", "version", "sdk-path", "help", "completion"],
    },
    {
        "name": "🔨 Hardware Build",
        "commands": [
            "project",
            "synth",
            "implementation",
            "bitstream",
            "linting",
            "hierarchy",
            "schematic",
            "fpga",
            "program",
            "hardware",
        ],
    },
    {
        "name": "📥 Migration",
        "commands": ["migrate"],
    },
    {
        "name": "🧪 Verification",
        "commands": [
            "sim",
            "testgen",
            "scan-tests",
            "waves",
            "viewlog",
            "regression",
            "diff",
            "watch",
            "deps",
            "info",
        ],
    },
    {
        "name": "📊 Reporting & Rules",
        "commands": ["report", "bom", "rules", "telemetry"],
    },
    {
        "name": "📦 Workspace Management",
        "commands": ["target", "workspace", "sources", "config", "ci", "lock", "diff-lock"],
    },
    {
        "name": "🧩 IP Package Manager",
        "commands": ["pkg"],
    },
    {
        "name": "🧩 IP & Config Data",
        "commands": ["ip", "regbank", "rom"],
    },
    {
        "name": "🐧 Embedded Linux",
        "commands": ["linux"],
    },
    {
        "name": "🐳 Docker Environments",
        "commands": ["docker"],
    },
    {
        "name": "🔧 EDA Tool Management",
        "commands": ["eda"],
    },
    {
        "name": "🪝 Hooks",
        "commands": ["hook"],
    },
    {
        "name": "🧠 AI Assistant",
        "commands": ["ask"],
    },
    {
        "name": "📌 Aliases",
        "commands": ["alias"],
    },
]

click.rich_click.COMMAND_GROUPS = {
    CLI_NAME: _COMMAND_LAYOUT,
}

import importlib.metadata
import logging


def _load_plugins(group):
    """
    Discover and load external CLI commands via entry points.

    Third-party packages expose Click commands/groups by registering
    entry points under the ``routertl.plugins`` group in their
    ``pyproject.toml``::

        [project.entry-points."routertl.plugins"]
        my_tool = "my_package.cli:my_command"

    Each entry point must resolve to a :class:`click.Command`.
    Plugins that fail to load are skipped with a warning.
    """
    loaded = []
    plugin_eps = []
    with cli_resilient_block("plugin entry point discovery"):
        eps = importlib.metadata.entry_points()
        # Python 3.12+ returns a SelectableGroups; 3.9-3.11 returns dict
        if hasattr(eps, "select"):
            plugin_eps = eps.select(group=group)
        elif isinstance(eps, dict):
            plugin_eps = eps.get(group, [])
        else:
            plugin_eps = [ep for ep in eps if ep.group == group]

    for ep in plugin_eps:
        try:
            cmd = ep.load()
            if isinstance(cmd, click.Command):
                loaded.append((ep.name, cmd))
            else:
                logging.warning(
                    f"Plugin '{ep.name}' did not resolve to a Click command (got {type(cmd).__name__}). Skipping."
                )
        except (ImportError, AttributeError, TypeError) as exc:
            logging.warning(f"Failed to load plugin '{ep.name}': {exc}")

    return loaded


@click.group(name=CLI_NAME, context_settings=dict(help_option_names=["-h", "--help"]))
@click.option("-v", "--verbose", is_flag=True, help="Enable verbose output and expanded plugin logging.")
@click.version_option(version=version_string(), prog_name=DISPLAY_NAME)
@click.pass_context
def cli(ctx, verbose):
    """The Hybrid Hardware Development Engine."""
    ctx.ensure_object(dict)
    ctx.obj["VERBOSE"] = verbose

    if verbose:
        logging.basicConfig(level=logging.DEBUG, format="%(levelname)s: %(message)s")
    else:
        logging.basicConfig(level=logging.INFO, format="%(message)s")

    # ── Project root resolution (RTL-P2.124) ──
    _NO_PROJECT_COMMANDS = {"init", "version", "sdk-path", "completion"}
    if ctx.invoked_subcommand not in _NO_PROJECT_COMMANDS:
        from sdk.cli.project_root import find_project_root

        project_root = find_project_root()
        if project_root is not None:
            original_cwd = Path.cwd().resolve()
            ctx.obj["project_root"] = project_root
            ctx.obj["original_cwd"] = original_cwd
            if project_root.resolve() != original_cwd:
                if verbose:
                    click.echo(
                        f"ℹ️  Resolved project root: {project_root} "
                        f"(invoked from {original_cwd})",
                        err=True,
                    )
                os.chdir(project_root)

    # ── Telemetry instrumentation ──
    from sdk.telemetry.collector import TelemetryCollector

    collector = TelemetryCollector()
    collector.start()
    ctx.obj["_telemetry"] = collector

    @ctx.call_on_close
    def _record_telemetry():
        """Record the CLI invocation after the command finishes."""
        invoked = ctx.invoked_subcommand or "help"
        exit_code = ctx.obj.get("_exit_code", 0)
        collector.stop_and_record(
            command=invoked,
            exit_code=exit_code,
        )

    # ── PyPI update hint (RTL-P1.37) ──
    # Print one line after the command finishes when a newer routertl is
    # on PyPI.  Runs after the command so its output doesn't get buried,
    # and skips lightweight meta commands where a trailing hint would be
    # noise (help, --version, tab completion, sdk-path).
    @ctx.call_on_close
    def _maybe_show_update_hint():
        invoked = ctx.invoked_subcommand or ""
        if invoked in {"version", "sdk-path", "completion"}:
            return
        with cli_resilient_block("PyPI update check"):
            from sdk.cli.update_check import maybe_show_update_hint
            maybe_show_update_hint(__version__)


# Dynamic docstring — Click reads __doc__ for help text
cli.__doc__ = (
    f"[bold cyan]{DISPLAY_NAME}[/] — The Hybrid Hardware Development Engine\n\n"
    "This CLI manages Vivado/Cocotb/Linux project lifecycles, ensuring\n"
    "strict reproducibility and zero-friction embedded generation.\n\n"
    f"[dim]v{__version__}  •  © 2026 Daniel J. Mazure  •  MIT + Proprietary[/]"
)


@cli.command()
def version():
    """Show the SDK version and exit."""
    from routertl_core import __copyright__, __version__

    _console.print(
        Panel(
            Text.from_markup(
                f"[bold cyan]{DISPLAY_NAME}[/] v[bold]{__version__}[/]\n"
                f"[dim]{__copyright__}[/]\n"
                f"[dim]MIT License[/]"
            ),
            border_style="cyan",
            padding=(0, 2),
            expand=False,
        )
    )


@cli.command(name="sdk-path")
def sdk_path_cmd():
    """Print the resolved SDK root path and exit.

    Useful for Makefiles and scripts that need to locate the SDK
    regardless of whether it was installed via pip or git submodule:

    \b
        SDK_ROOT := $(shell rr sdk-path 2>/dev/null || echo vendor/routertl)
    """
    from sdk.cli.sdk_root import resolve_sdk_root

    root = resolve_sdk_root()
    if root is None:
        sys.exit(1)
    click.echo(str(root))


def _default_sdk_path() -> str:
    """Resolve the default --sdk-path value for `rr init`."""
    from sdk.cli.sdk_root import resolve_sdk_root

    root = resolve_sdk_root()
    return str(root) if root else "vendor/routertl"


@cli.command()
@click.option("--template", "-t", default=None, help="Initialize from a template (e.g., blinky, counter, axi).")
@click.option("--list-templates", is_flag=True, help="List available project templates and exit.")
@click.option("--name", default=None, help="Project name (used with --template).")
@click.option("--sdk-path", default=None, help="Path to RouteRTL SDK root (auto-detected if omitted).")
@click.option("--no-venv", is_flag=True, help="Skip Python virtual environment configuration.")
@click.option("-y", "--non-interactive", is_flag=True, help="Run in non-interactive mode.")
# RTL-P3.132: scaffolding parameters forwarded to init_project.py so a
# fully non-interactive init doesn't need the user to edit project.yml
# after the fact.
@click.option("--vendor", default=None, type=click.Choice(["xilinx", "altera", "lattice", "microchip", "opensource"]),
              help="FPGA vendor (xilinx/altera/lattice/microchip/opensource).")
@click.option("--part", default=None, help='FPGA part number (e.g. "xc7z020clg400-1").')
@click.option("--language", default=None, type=click.Choice(["vhdl", "verilog", "systemverilog"]),
              help="Primary HDL language.")
@click.option("--src-dir", default=None, help='Source directory (default: "hw/src").')
@click.option("--sim-dir", default=None, help='Simulation directory (default: "hw/sim").')
@click.option("--no-tips", is_flag=True, default=False,
              help="Suppress post-init suggestions (shell completion, MCP install).")
def init(template, list_templates, name, sdk_path, no_venv, non_interactive,
         vendor, part, language, src_dir, sim_dir, no_tips):
    """Initialize a new RouteRTL FPGA project."""
    import subprocess

    # Locate init_project.py relative to the CLI's installation path
    this_dir = os.path.dirname(os.path.abspath(__file__))
    tools_dir = os.path.dirname(this_dir)
    init_script = os.path.join(tools_dir, "engine", "init_project.py")

    if not os.path.exists(init_script):
        _console.print(f"❌ [red]Error: Cannot locate init_project.py at {init_script}[/]")
        sys.exit(1)

    # Resolve SDK path: explicit > auto-detect > default
    if sdk_path is None:
        sdk_path = _default_sdk_path()

    # Build subprocess args
    cmd = [sys.executable, init_script]
    if list_templates:
        cmd.append("--list-templates")
    if template:
        cmd.extend(["--template", template])
    if name:
        cmd.extend(["--name", name])
    cmd.extend(["--sdk-path", sdk_path])
    if no_venv:
        cmd.append("--no-venv")
    if non_interactive:
        cmd.append("--non-interactive")
    # RTL-P3.132: forward scaffolding options when provided.
    if vendor:
        cmd.extend(["--vendor", vendor])
    if part:
        cmd.extend(["--part", part])
    if language:
        cmd.extend(["--language", language])
    if src_dir:
        cmd.extend(["--src-dir", src_dir])
    if sim_dir:
        cmd.extend(["--sim-dir", sim_dir])

    try:
        result = subprocess.run(cmd)
        if result.returncode != 0:
            sys.exit(result.returncode)
    except KeyboardInterrupt:
        _console.print("\n[yellow]Initialization aborted.[/]")
        return

    # P2.81: Auto-generate build_env.mk so the build system works immediately
    if not list_templates and os.path.exists("project.yml"):
        with cli_resilient_block("auto update-config after init"):
            from sdk.cli.commands.workspace import _run_update_config
            _console.print("\n🔧 [blue]Generating build configuration...[/]")
            _run_update_config(exit_on_error=False)

        # RTL-P3.182: hint git init when the new project isn't version-controlled
        with cli_resilient_block("git-init hint after init"):
            from sdk.cli.commands.hardware import _hint_git_init
            _hint_git_init(Path.cwd(), project_name=name)

        # RTL-P2.426: dim one-liners suggesting the one-shot DX
        # installers, only when their targets are absent.  Silent for
        # already-set-up users; --no-tips disables the whole block.
        if not no_tips:
            with cli_resilient_block("post-init tips"):
                _print_post_init_tips()


def _print_post_init_tips():
    """RTL-P2.426: print up to two dim suggestions after rr init.

    Each tip fires independently based on whether its target is
    already installed:
      * shell completion — checks the shell-specific install path
      * MCP integration   — checks for .mcp.json in CWD

    Silent no-op when both are already present or when the shell is
    unrecognised.  All IO is best-effort — a failed probe means the
    tip just doesn't fire.
    """
    import os as _os

    tips: list[str] = []

    # ── Shell completion tip ─────────────────────────────────────
    shell_path = _os.environ.get("SHELL", "")
    base = _os.path.basename(shell_path)
    home = Path.home()
    completion_path: Path | None = None
    if base == "zsh":
        completion_path = home / ".zsh" / "completions" / "_rr"
    elif base == "bash":
        completion_path = home / ".local" / "share" / "bash-completion" / "completions" / "rr"
    elif base == "fish":
        completion_path = home / ".config" / "fish" / "completions" / "rr.fish"

    if completion_path is not None and not completion_path.exists():
        tips.append(
            "   [dim]💡 Enable TAB completion:[/] "
            "[cyan]rr ws install-completion[/]"
        )

    # ── MCP tip ──────────────────────────────────────────────────
    if not (Path.cwd() / ".mcp.json").exists():
        tips.append(
            "   [dim]💡 Hook this project into Claude / Cursor / VS Code:[/] "
            "[cyan]rr mcp install[/]"
        )

    if tips:
        _console.print()
        for tip in tips:
            _console.print(tip)


@cli.command(name="help")
@click.argument("command_name", required=False)
@click.pass_context
def help_cmd(ctx, command_name):
    """
    Display deep, interactive manual-page documentation for a command.
    """
    import subprocess

    if not command_name:
        # No argument — show the same output as rr --help
        click.echo(ctx.parent.get_help())
        return

    # Map CLI command name to its underlying Makefile target string (if different)
    # Also map group names to their anchor targets in the documentation
    target_map = {
        "npm-synthesis": "npm-synthesis",
        "regbank": "regbank",
        "docker": "docker",
        "docker-build": "docker-build",
        "docker-shell": "docker-shell",
        "docker-run": "docker-run",
        "scan-tests": "scan-tests",
    }
    make_target = target_map.get(command_name, command_name)

    # Locate the markdown help parser
    this_dir = os.path.dirname(os.path.abspath(__file__))
    tools_dir = os.path.dirname(this_dir)
    help_script = os.path.join(tools_dir, "engine", "show_target_help.py")

    if not os.path.exists(help_script):
        _console.print(f"❌ [red]Error: Cannot locate documentation engine at {help_script}[/]")
        sys.exit(1)

    # Execute the deep parser
    result = subprocess.run([sys.executable, help_script, make_target], capture_output=True, text=True)

    if result.returncode != 0:
        # No deep docs for this command — fall back to rr --help
        _console.print(
            f"[yellow]No detailed help for '[bold]{command_name}[/bold]'.[/]\n"
        )
        click.echo(ctx.parent.get_help())
        sys.exit(0)

    click.echo(result.stdout)


cli.add_command(help_cmd)
cli.add_command(status)
cli.add_command(project_group)
# Note: 'synth' name is now used by synth_group (status board and run).
cli.add_command(impl_group)
cli.add_command(impl_group, name="impl")  # shortcut alias
cli.add_command(bitstream_group)
cli.add_command(bitstream_group, name="bit")  # shortcut alias
cli.add_command(linting)
cli.add_command(linting, name="lint")  # shortcut alias
cli.add_command(hierarchy)
cli.add_command(hierarchy, name="hier")  # shortcut alias
cli.add_command(synth_targets)
cli.add_command(schematic)
cli.add_command(sim_group)
cli.add_command(testgen)  # backward-compat alias for rr sim testgen
cli.add_command(workspace_group)
cli.add_command(workspace_group, name="ws")  # shortcut alias
cli.add_command(regbank_group)
cli.add_command(rom)
cli.add_command(ip_group)
cli.add_command(linux_group)
cli.add_command(docker_group)
cli.add_command(eda_group)
cli.add_command(scan_tests)  # backward-compat alias for rr sim scan-tests
cli.add_command(waves)  # backward-compat alias for rr sim waves
cli.add_command(regression)  # backward-compat alias for rr sim regression
cli.add_command(view_sim_log)  # backward-compat alias for rr sim viewlog
cli.add_command(view_sim_log, name="view-log")  # backward-compat hyphenated alias
cli.add_command(diff_command)
cli.add_command(completion_command)
cli.add_command(watch_command)
cli.add_command(deps_group)
cli.add_command(sources_command)
cli.add_command(info_command)
cli.add_command(doctor)
cli.add_command(license_command)
cli.add_command(report_command)
cli.add_command(bom_command)
cli.add_command(config_command)
cli.add_command(fpga_group)
cli.add_command(program_group)
cli.add_command(hardware_group)
cli.add_command(synth_group)
cli.add_command(ci_group)
cli.add_command(telemetry_group)
cli.add_command(pkg_group)
cli.add_command(target_group)
cli.add_command(lock_group)
cli.add_command(diff_lock_command)
cli.add_command(alias_group)
cli.add_command(hook_group)
cli.add_command(migrate_command)
cli.add_command(rules_group)
cli.add_command(ref_group)
cli.add_command(mcp_group)
cli.add_command(ask_command)
cli.add_command(routewave_command)

# ── Plugin Discovery ──
for _plugin_name, _plugin_cmd in _load_plugins("routertl.plugins"):
    cli.add_command(_plugin_cmd, _plugin_name)

# ── Alias Discovery (RTL-P2.133) ──
# Load user-defined aliases and register as top-level commands.
# Built-in commands always take precedence — collisions are silently skipped.
with cli_resilient_block("alias command registration"):
    from sdk.cli.alias_commands import load_alias_commands

    _alias_names = []
    for _alias_name, _alias_cmd in load_alias_commands(cli):
        cli.add_command(_alias_cmd, _alias_name)
        _alias_names.append(_alias_name)

    # Add aliases to the help layout if any exist
    if _alias_names:
        # Find and update the Aliases section in COMMAND_GROUPS
        for _group in _COMMAND_LAYOUT:
            if _group["name"] == "📌 Aliases":
                _group["commands"] = ["alias"] + sorted(_alias_names)
                break
        click.rich_click.COMMAND_GROUPS = {CLI_NAME: _COMMAND_LAYOUT}


if __name__ == "__main__":
    # ── Universal trailing "help" interceptor ──
    # Accept: rr docker help → rr docker --help
    # Accept: rr docker install help → rr docker install --help
    if len(sys.argv) > 1 and sys.argv[-1] == "help":
        sys.argv[-1] = "--help"
    cli(prog_name=CLI_NAME)
