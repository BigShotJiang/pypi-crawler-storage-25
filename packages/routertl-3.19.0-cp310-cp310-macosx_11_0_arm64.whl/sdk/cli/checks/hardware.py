# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Hardware Health Checks — Connectivity, Permissions, and JTAG chain diagnostics."""

import os
from pathlib import Path

from sdk.cli.checks import CheckResult, HardwareCheckRegistry
from sdk.cli.checks._helpers import _load_project_yml, _run, _which


@HardwareCheckRegistry.register("USB Connectivity", order=200)
def check_usb_connectivity():
    """Scan for known FPGA programmers on the USB bus."""
    # Known VID:PID pairs for FPGA programmers
    # 09fb:6010 / 09fb:6001 = Altera USB-Blaster
    # 0403:6010 / 0403:6011 / 0403:6014 = FTDI (Xilinx/Lattice/Open-source)
    # 2109:0105 = Digilent JTAG-HS3
    KNOWN_PROGRAMMERS = {
        "09fb:6010": "Altera USB-Blaster II",
        "09fb:6001": "Altera USB-Blaster (Classic)",
        "0403:6010": "FTDI Dual UART/FIFO (JTAG-enabled)",
        "0403:6011": "FTDI Quad UART/FIFO (JTAG-enabled)",
        "0403:6014": "FTDI Single Channel Hi-Speed (JTAG-enabled)",
        "2109:0105": "Digilent JTAG-HS3",
    }

    if not _which("lsusb"):
        return CheckResult(
            "USB Connectivity",
            CheckResult.WARN,
            "lsusb not found. Cannot scan for hardware.",
            fix="Install usbutils: sudo apt install usbutils",
        )

    rc, output = _run(["lsusb"])
    if rc != 0:
        return CheckResult(
            "USB Connectivity",
            CheckResult.WARN,
            "Failed to run lsusb. Check system logs.",
        )

    found = []
    for line in output.splitlines():
        for vid_pid, name in KNOWN_PROGRAMMERS.items():
            if vid_pid in line:
                found.append(f"{name} ({vid_pid})")

    if not found:
        return CheckResult(
            "USB Connectivity",
            CheckResult.WARN,
            "No known FPGA programmers found on USB bus.",
            fix="Ensure your programmer is plugged in and powered on.",
        )

    return CheckResult(
        "USB Connectivity",
        CheckResult.OK,
        f"Found {len(found)} programmer(s): {', '.join(found)}",
    )


@HardwareCheckRegistry.register("USB Permissions", order=210)
def check_udev_permissions():
    """Validate that the current user has access to connected programmers (udev rules)."""
    # Look for programmer device nodes in /dev/bus/usb/
    # This is a bit complex without libusb, but we can check if any device
    # node under /dev/bus/usb/ is NOT writable by the current user
    # but belongs to a known VID:PID.

    # For now, a simpler check: look for RouteRTL udev rules
    udev_path = Path("/etc/udev/rules.d/51-routertl.rules")
    if not udev_path.exists():
        # Also check common vendor locations
        vendor_rules = [
            "/etc/udev/rules.d/51-usbblaster.rules",
            "/etc/udev/rules.d/52-xilinx-pcusb.rules",
        ]
        if not any(Path(p).exists() for p in vendor_rules):
            return CheckResult(
                "USB Permissions",
                CheckResult.WARN,
                "No custom udev rules found for FPGA programmers.",
                fix="You may experience permission errors. Run 'rr hardware fix-permissions'.",
            )

    return CheckResult(
        "USB Permissions",
        CheckResult.OK,
        "Custom udev rules detected.",
    )


@HardwareCheckRegistry.register("JTAG IDCODE", order=220)
def check_jtag_idcode():
    """Cross-check discovered JTAG IDCODE against project configuration."""
    yml = _load_project_yml()
    if not yml:
        return None  # Skip if no project

    hw = yml.get("hardware") or {}
    expected_idcode = hw.get("idcode")
    if expected_idcode is None:
        # P2.111: IDCODE check is OPT-IN. Only run if 'idcode' is set in project.yml.
        return None

    vendor = hw.get("vendor", "altera")

    # Normalize expected: accept single string or list
    if isinstance(expected_idcode, str):
        expected_list = [expected_idcode.upper()]
    elif isinstance(expected_idcode, list):
        expected_list = [str(x).upper() for x in expected_idcode]
    else:
        return CheckResult(
            "JTAG IDCODE",
            CheckResult.WARN,
            f"Invalid idcode format in project.yml: {expected_idcode}",
        )

    # Scan live chain
    from sdk.cli.jtag import scan_jtag_chain

    cables = scan_jtag_chain(vendor)
    if not cables:
        return CheckResult(
            "JTAG IDCODE",
            CheckResult.WARN,
            f"Expected {', '.join(expected_list)} but no JTAG cables found",
            fix="Connect a JTAG programmer and ensure vendor tools are on PATH.",
        )

    # Collect all discovered IDCODEs
    found_ids = []
    for cable in cables:
        for dev in cable.devices:
            found_ids.append(dev.idcode.upper())

    # Check that every expected IDCODE appears in the chain
    missing = [eid for eid in expected_list if eid not in found_ids]
    if missing:
        return CheckResult(
            "JTAG IDCODE",
            CheckResult.FAIL,
            f"Expected {', '.join(missing)} not found in chain. "
            f"Found: {', '.join(found_ids) if found_ids else 'none'}",
        )

    return CheckResult(
        "JTAG IDCODE",
        CheckResult.OK,
        f"IDCODE match: {', '.join(expected_list)} found in chain",
    )


@HardwareCheckRegistry.register("UART Connectivity", order=230)
def check_uart_ports():
    """Identify and check status of serial (UART) ports."""
    tty_nodes = list(Path("/dev").glob("ttyUSB*")) + list(Path("/dev").glob("ttyACM*"))

    if not tty_nodes:
        return CheckResult(
            "UART Ports",
            CheckResult.WARN,
            "No USB serial ports found (/dev/ttyUSB* or /dev/ttyACM*).",
        )

    available = []
    busy = []
    for node in tty_nodes:
        # Try to open the port to check if it's busy
        try:
            fd = os.open(node, os.O_RDWR | os.O_NONBLOCK | os.O_NOCTTY)
            os.close(fd)
            available.append(node.name)
        except OSError:
            busy.append(node.name)

    detail = f"Found {len(tty_nodes)} port(s): {', '.join(n.name for n in tty_nodes)}"
    if busy:
        return CheckResult(
            "UART Ports",
            CheckResult.WARN,
            f"{detail}. Warning: {', '.join(busy)} are currently BUSY (held by other processes).",
            fix="Close any open terminal monitors (minicom, screen, etc.) if programming fails.",
        )

    return CheckResult(
        "UART Ports",
        CheckResult.OK,
        detail,
    )


# ──────────────────────────────────────────────────────────────
# Vendor Programmer & JTAG Tool Checks
# (Derived from Altera hardware reference project build pipeline)
# ──────────────────────────────────────────────────────────────

# Vendor → programming binary and JTAG enum tool
_VENDOR_PROGRAMMER = {
    "altera":     ("quartus_pgm",  "jtagconfig"),
    "xilinx":     ("vivado",       "xsdb"),
    "lattice":    ("pgrcmd",       "pgrcmd"),
    "microchip":  ("libero",       "fpgenprog"),
}


@HardwareCheckRegistry.register("Vendor Programmer", order=240)
def check_vendor_programmer():
    """Check that the vendor programming binary is present."""
    yml = _load_project_yml()
    vendor = (yml or {}).get("hardware", {}).get("vendor", "altera")
    prog, jtag = _VENDOR_PROGRAMMER.get(vendor, ("quartus_pgm", "jtagconfig"))

    path = _which(prog)
    if not path:
        return CheckResult(
            "Vendor Programmer",
            CheckResult.WARN,
            f"{prog} not found on PATH ({vendor})",
            fix=f"Add {vendor.title()} tools to PATH (e.g. export PATH=/opt/altera_std/quartus/bin:$PATH)",
        )

    rc, out = _run([prog, "--version"], timeout=15)
    import re
    m = re.search(r"(\d+\.\d+)", out)
    ver = f"v{m.group(1)}" if m else "found"
    return CheckResult("Vendor Programmer", CheckResult.OK, f"{prog} {ver} ({path})")


@HardwareCheckRegistry.register("JTAG Clock", order=250)
def check_jtag_clock():
    """For Altera: verify jtagconfig can query the JTAG clock speed."""
    yml = _load_project_yml()
    vendor = (yml or {}).get("hardware", {}).get("vendor", "")
    if vendor != "altera":
        return None  # Only applicable to Altera

    if not _which("jtagconfig"):
        return CheckResult(
            "JTAG Clock", CheckResult.WARN,
            "jtagconfig not found — cannot verify clock",
        )

    import re
    rc, out = _run(["jtagconfig", "--getparam", "1", "JtagClock"], timeout=10)
    if rc == 0 and out.strip():
        m = re.search(r"(\d+)", out)
        if m:
            hz = int(m.group(1))
            mhz = hz / 1_000_000
            if hz < 1_000_000:
                return CheckResult(
                    "JTAG Clock", CheckResult.WARN,
                    f"{mhz:.1f} MHz — low JTAG clock may cause programming timeouts",
                    fix_cmd="jtagconfig --setparam 1 JtagClock 6M",
                )
            return CheckResult("JTAG Clock", CheckResult.OK, f"{mhz:.0f} MHz")

    return CheckResult(
        "JTAG Clock", CheckResult.WARN,
        "no programmer on chain (jtagconfig returned no result)",
        fix="Connect a JTAG programmer and retry",
    )


@HardwareCheckRegistry.register("Nios V Toolchain", order=260)
def check_niosv_toolchain():
    """Check Nios V soft-processor build tools (Altera only).

    These tools are required to build, package, and debug firmware running
    on Nios V/m or Nios V/c soft processors embedded in Altera FPGAs.
    Paths derived from the standard Altera toolchain layout:
      /opt/altera_std/niosv/bin   — BSP + app generators
      /opt/altera/riscfree/...    — RISC-V cross compiler
    """
    yml = _load_project_yml()
    vendor = (yml or {}).get("hardware", {}).get("vendor", "")
    if vendor != "altera":
        return None  # Nios V is Altera-only

    results = []

    niosv_tools = {
        "niosv-bsp":       "Nios V BSP Generator",
        "niosv-app":       "Nios V App Generator",
        "elf2hex":         "elf2hex (firmware packer)",
        "juart-terminal":  "JTAG UART Terminal",
    }

    for binary, display in niosv_tools.items():
        path = _which(binary)
        if not path:
            results.append(CheckResult(
                display,
                CheckResult.WARN,
                f"{binary} not found on PATH",
                fix="Add Nios V tools to PATH: export PATH=/opt/altera_std/niosv/bin:$PATH",
            ))
        else:
            results.append(CheckResult(display, CheckResult.OK, f"found ({path})"))

    return results


@HardwareCheckRegistry.register("RISC-V Toolchain", order=270)
def check_riscv_toolchain():
    """Check the RISC-V cross-compiler for soft-processor firmware builds."""
    yml = _load_project_yml()
    vendor = (yml or {}).get("hardware", {}).get("vendor", "")
    if vendor != "altera":
        return None  # Only needed for Altera Nios V at this stage

    gcc = "riscv32-unknown-elf-gcc"
    path = _which(gcc)
    if not path:
        return CheckResult(
            "RISC-V Toolchain",
            CheckResult.WARN,
            f"{gcc} not found on PATH",
            fix="export PATH=/opt/altera/riscfree/toolchain/riscv32-unknown-elf/bin:$PATH",
        )

    import re
    rc, out = _run([gcc, "--version"], timeout=10)
    m = re.search(r"(\d+\.\d+\.\d+)", out)
    ver = f"v{m.group(1)}" if m else "found"
    return CheckResult("RISC-V Toolchain", CheckResult.OK, f"{ver} ({path})")

