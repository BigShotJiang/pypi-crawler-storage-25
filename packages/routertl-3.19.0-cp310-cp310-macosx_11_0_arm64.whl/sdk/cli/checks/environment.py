# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
Environment health checks — Python, venv, SDK freshness, active simulator.
"""

from __future__ import annotations

import os
from pathlib import Path

from sdk.cli.checks import CheckRegistry, CheckResult
from sdk.cli.checks._helpers import (
    _cli_name,
    _detect_docker_container,
    _load_project_yml,
    _parse_version,
    _run,
    _sdk_root,
    _ver_tuple,
)
from sdk.cli.resilience import cli_resilient_block

# ──────────────────────────────────────────────────────────────
# check_python  (order=10)
# ──────────────────────────────────────────────────────────────


@CheckRegistry.register("Python", order=10)
def check_python():
    """Validate Python version ≥ 3.10."""
    rc, out = _run(["python3", "--version"])
    ver = _parse_version(out, r"Python (\d+\.\d+\.\d+)")
    if not ver:
        return CheckResult(
            "Python",
            CheckResult.FAIL,
            "python3 not found on PATH",
            fix="Install Python ≥ 3.10",
        )
    if _ver_tuple(ver) < (3, 10):
        return CheckResult(
            "Python",
            CheckResult.FAIL,
            f"v{ver} — minimum is 3.10",
            fix="Upgrade Python to ≥ 3.10",
        )
    return CheckResult("Python", CheckResult.OK, f"v{ver}")


# ──────────────────────────────────────────────────────────────
# check_gnu_make  (order=22)
# ──────────────────────────────────────────────────────────────


@CheckRegistry.register("GNU Make", order=22)
def check_gnu_make():
    """Verify GNU make is available — SDK Makefiles use GNU extensions.

    SDK Makefiles use GNU-make-isms (pattern rules, ``$(shell …)``,
    conditionals, target-specific vars) that BSD make rejects.  macOS
    ships BSD make at ``/usr/bin/make`` — users need ``brew install make``
    and either alias ``make=gmake`` or invoke ``gmake`` directly.
    """
    rc, out = _run(["make", "--version"])
    if rc == 0 and "GNU Make" in out:
        ver = _parse_version(out, r"GNU Make ([\d.]+)")
        ver_str = f"v{ver}" if ver else "installed"
        return CheckResult("GNU Make", CheckResult.OK, f"{ver_str} (via make)")

    # `make` is missing or not GNU (e.g. BSD make on macOS).
    rc, out = _run(["gmake", "--version"])
    if rc == 0 and "GNU Make" in out:
        ver = _parse_version(out, r"GNU Make ([\d.]+)")
        ver_str = f"v{ver}" if ver else "installed"
        return CheckResult(
            "GNU Make",
            CheckResult.WARN,
            f"{ver_str} (via gmake — `make` on PATH is not GNU)",
            fix="Invoke Makefiles with `gmake`, or alias `make=gmake` in your shell",
        )

    from sdk.cli.platform_hints import install_cmd
    _make_cmd = install_cmd("make") or "install GNU make"
    return CheckResult(
        "GNU Make",
        CheckResult.FAIL,
        "GNU make not found — SDK Makefiles require GNU extensions",
        fix="Install GNU make (macOS: `brew install make`; Debian/Ubuntu: `sudo apt install make`)",
        fix_cmd=_make_cmd,
    )


# ──────────────────────────────────────────────────────────────
# check_dtc  (order=24)  — needed for `rr linux sync` / dtbo flow
# ──────────────────────────────────────────────────────────────


@CheckRegistry.register("Device Tree Compiler (dtc)", order=24)
def check_dtc():
    """Validate that dtc is available for Device Tree overlay compilation."""
    rc, out = _run(["dtc", "--version"])
    if rc != 0:
        from sdk.cli.platform_hints import install_cmd
        _dtc_cmd = install_cmd("dtc") or "install device-tree-compiler"
        return CheckResult(
            "Device Tree Compiler (dtc)",
            CheckResult.WARN,
            "not installed — `rr linux` overlay compilation will fail",
            fix="Install dtc to compile generated .dtsi overlays",
            fix_cmd=_dtc_cmd,
        )
    ver = _parse_version(out, r"Version:\s*DTC\s*([\d.]+)") or _parse_version(out, r"([\d.]+)")
    ver_str = f"v{ver}" if ver else "installed"
    return CheckResult("Device Tree Compiler (dtc)", CheckResult.OK, ver_str)


# ──────────────────────────────────────────────────────────────
# check_shellcheck  (order=25)
# ──────────────────────────────────────────────────────────────


@CheckRegistry.register("ShellCheck", order=25)
def check_shellcheck():
    """Validate shellcheck is installed for shell script linting."""
    rc, out = _run(["shellcheck", "--version"])
    if rc != 0:
        from sdk.cli.platform_hints import install_cmd
        _sc_cmd = install_cmd("shellcheck") or "install shellcheck"
        return CheckResult(
            "ShellCheck",
            CheckResult.WARN,
            "not installed — shell scripts won't be linted in pre-commit",
            fix="Install shellcheck for bash script linting",
            fix_cmd=_sc_cmd,
        )
    ver = _parse_version(out, r"version:\s*([\d.]+)")
    ver_str = f"v{ver}" if ver else "installed"
    return CheckResult("ShellCheck", CheckResult.OK, ver_str)


# ──────────────────────────────────────────────────────────────
# check_active_simulator  (order=15)
# ──────────────────────────────────────────────────────────────


@CheckRegistry.register("Active Simulator", order=15)
def check_active_simulator():
    """Report which simulator will be used at runtime.

    Precedence: $SIM env var → project.yml simulation.simulator → default 'nvc'.
    """
    env_sim = os.environ.get("SIM")
    yml_sim = None
    cfg = _load_project_yml()
    if isinstance(cfg, dict):
        sim_cfg = cfg.get("simulation") or {}
        if isinstance(sim_cfg, dict):
            yml_sim = sim_cfg.get("simulator")

    if env_sim:
        source = "$SIM env var"
        active = env_sim
        if yml_sim and yml_sim != env_sim:
            detail = f"{active} (from {source}, overrides project.yml '{yml_sim}')"
        else:
            detail = f"{active} (from {source})"
    elif yml_sim:
        active = yml_sim
        detail = f"{active} (from project.yml)"
    else:
        active = "nvc"
        detail = f"{active} (default — override via simulation.simulator in project.yml or $SIM)"

    return CheckResult("Simulator", CheckResult.OK, detail)


# ──────────────────────────────────────────────────────────────
# check_venv  (order=50)
# ──────────────────────────────────────────────────────────────


@CheckRegistry.register("Virtual Env", order=50)
def check_venv():
    """Check if a virtual environment is active, healthy, and uncorrupted."""
    cli = _cli_name()

    # Docker containers have the SDK installed system-wide — no venv needed
    docker_env = _detect_docker_container()
    if docker_env:
        return CheckResult(
            "Virtual Env",
            CheckResult.OK,
            f"not required (Docker {docker_env} — SDK is system-installed)",
        )

    venv_active = os.environ.get("VIRTUAL_ENV")

    if not venv_active:
        # Check local .venv exists
        if Path(".venv").is_dir():
            return CheckResult(
                "Virtual Env",
                CheckResult.WARN,
                ".venv exists but is not activated",
                fix="Run: source .venv/bin/activate",
                fix_cmd="source .venv/bin/activate",
            )
        return CheckResult(
            "Virtual Env",
            CheckResult.WARN,
            "no .venv found",
            fix=f"Run: {cli} workspace install",
            fix_cmd=f"{cli} ws install",
        )

    venv_path = Path(venv_active)

    # ── Deep health checks ──
    issues = []

    # 1. Python symlink resolves
    py_bin = venv_path / "bin" / "python3"
    if py_bin.is_symlink():
        target = py_bin.resolve()
        if not target.exists():
            issues.append(f"broken Python symlink → {target}")
    elif not py_bin.exists():
        issues.append("python3 binary missing from .venv/bin/")

    # 2. pip works
    if py_bin.exists():
        rc, _ = _run([str(py_bin), "-m", "pip", "--version"], timeout=5)
        if rc != 0:
            issues.append("pip is broken or missing")

    # 3. routertl entry point exists and imports
    routertl_bin = venv_path / "bin" / "routertl"
    if routertl_bin.exists():
        if py_bin.exists():
            rc, _ = _run([str(py_bin), "-c", "from sdk.cli.main import cli"], timeout=5)
            if rc != 0:
                issues.append("routertl entry point fails to import")
    else:
        issues.append("routertl entry point not found in .venv/bin/")

    if issues:
        detail = "; ".join(issues)
        return CheckResult(
            "Virtual Env",
            CheckResult.FAIL,
            f"CORRUPTED — {detail}",
            fix=f"Run: {cli} workspace repair-venv",
            fix_cmd=f"{cli} ws repair-venv",
        )

    return CheckResult(
        "Virtual Env",
        CheckResult.OK,
        f"active ({venv_active})",
    )


# ──────────────────────────────────────────────────────────────
# check_sdk_freshness  (order=60)
# ──────────────────────────────────────────────────────────────


@CheckRegistry.register("SDK Freshness", order=60)
def check_sdk_freshness():
    """Check SDK version and whether it is behind the remote.

    Resolution order:
    1. ``importlib.metadata.version("routertl")`` — pip-installed package
    2. ``VERSION`` file + ``git rev-list --count HEAD`` — submodule/editable
    """
    sdk = _sdk_root()

    # ── 1. Try pip package metadata (preferred) ──
    pip_version = None
    with cli_resilient_block("pip package version"):
        from importlib.metadata import version as _meta_version

        pip_version = _meta_version("routertl")

    if pip_version:
        version_str = f"v{pip_version}"

        # Check freshness only if we have a git-backed SDK root
        behind = None
        if sdk and (sdk / ".git").exists():
            with cli_resilient_block("SDK remote fetch"):
                fetch_env = {**os.environ, "GIT_SSH_COMMAND": "ssh -o StrictHostKeyChecking=accept-new -o BatchMode=yes"}
                _run(["git", "-C", str(sdk), "fetch", "--quiet"], timeout=15, env=fetch_env)
                rc, out = _run(["git", "-C", str(sdk), "rev-list", "--count", "HEAD..@{u}"])
                if rc == 0:
                    behind = int(out.strip())

        if behind and behind > 0:
            return CheckResult(
                "SDK Freshness",
                CheckResult.WARN,
                f"{version_str} — {behind} commit{'s' if behind > 1 else ''} behind remote",
                fix=f"Run: {_cli_name()} workspace update-sdk",
                fix_cmd=f"{_cli_name()} ws update-sdk",
            )
        return CheckResult("SDK Freshness", CheckResult.OK, f"{version_str} — up to date")

    # ── 2. Fall back to VERSION file + git (submodule) ──
    if sdk is None:
        return CheckResult(
            "SDK Freshness",
            CheckResult.WARN,
            "SDK root not found",
        )
    # Read version
    version_file = sdk / "VERSION"
    major, minor = "0", "0"
    with cli_resilient_block("VERSION file parsing"):
        for line in version_file.read_text().splitlines():
            line = line.strip()
            if line.startswith("system_major="):
                major = line.split("=", 1)[1]
            elif line.startswith("system_minor="):
                minor = line.split("=", 1)[1]

    patch = "?"
    with cli_resilient_block("git commit count"):
        rc, out = _run(["git", "-C", str(sdk), "rev-list", "--count", "HEAD"])
        if rc == 0:
            patch = out.strip()

    version_str = f"v{major}.{minor}.{patch}"

    # Check commits behind (fetch first, but don't fail on network errors)
    # BatchMode=yes suppresses SSH host key prompts (e.g. inside Docker)
    behind = None
    with cli_resilient_block("SDK remote fetch"):
        fetch_env = {**os.environ, "GIT_SSH_COMMAND": "ssh -o StrictHostKeyChecking=accept-new -o BatchMode=yes"}
        _run(["git", "-C", str(sdk), "fetch", "--quiet"], timeout=15, env=fetch_env)
        rc, out = _run(["git", "-C", str(sdk), "rev-list", "--count", "HEAD..@{u}"])
        if rc == 0:
            behind = int(out.strip())

    if behind and behind > 0:
        return CheckResult(
            "SDK Freshness",
            CheckResult.WARN,
            f"{version_str} — {behind} commit{'s' if behind > 1 else ''} behind remote",
            fix=f"Run: {_cli_name()} workspace update-sdk",
            fix_cmd=f"{_cli_name()} ws update-sdk",
        )
    return CheckResult("SDK Freshness", CheckResult.OK, f"{version_str} — up to date")
