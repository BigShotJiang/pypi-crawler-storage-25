# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
Simulator health checks — NVC, GHDL, Verilator, and commercial simulators.
"""

from __future__ import annotations

import os

from sdk.cli.checks import CheckRegistry, CheckResult
from sdk.cli.checks._helpers import (
    _cli_name,
    _detect_docker_container,
    _load_project_yml,
    _parse_version,
    _run,
    _ver_tuple,
    _which,
)

# ──────────────────────────────────────────────────────────────
# Generic simulator binary check (not registered — it's a helper)
# ──────────────────────────────────────────────────────────────


def check_simulator(name, cmd, regex, min_ver, required, role, hint):
    """Generic simulator binary check."""
    if not cmd or not cmd.strip():
        status = CheckResult.FAIL if required else CheckResult.WARN
        return CheckResult(
            name,
            status,
            "no check command configured",
            fix=hint or "check sdk_requirements.yml",
        )
    path = _which(cmd.split()[0])
    if not path:
        status = CheckResult.FAIL if required else CheckResult.WARN
        return CheckResult(
            name,
            status,
            "not found on PATH",
            fix=hint,
        )
    env = os.environ.copy()
    if name.lower() == "verilator":
        env.pop("VERILATOR_ROOT", None)
    rc, out = _run(cmd.split(), env=env)
    ver = _parse_version(out, regex)
    if ver and min_ver:
        if _ver_tuple(ver) >= _ver_tuple(min_ver):
            return CheckResult(name, CheckResult.OK, f"v{ver} ({path})")
        status = CheckResult.FAIL if required else CheckResult.WARN
        return CheckResult(
            name,
            status,
            f"v{ver} < required v{min_ver}",
            fix=hint,
        )
    if path:
        detail = f"v{ver}" if ver else "found"
        return CheckResult(name, CheckResult.OK, f"{detail} ({path})")
    return CheckResult(name, CheckResult.WARN, "could not determine version")


# ──────────────────────────────────────────────────────────────
# check_simulators  (order=11)
# ──────────────────────────────────────────────────────────────


def _detect_project_languages():
    """Detect HDL languages present in the project source directories.

    Returns (has_vhdl, has_verilog) by scanning source directories from
    project.yml or falling back to ``src/``.
    """
    from pathlib import Path

    cfg = _load_project_yml()
    src_dirs = []
    if isinstance(cfg, dict):
        sources = cfg.get("sources") or {}
        if isinstance(sources, dict):
            src_dirs = sources.get("directories") or []
        if not src_dirs:
            src_dirs = cfg.get("source_directories") or []
    if not src_dirs:
        src_dirs = ["src"] if Path("src").is_dir() else []

    has_vhdl = False
    has_verilog = False
    vhdl_exts = {".vhd", ".vhdl"}
    verilog_exts = {".v", ".sv", ".svh"}

    for sd in src_dirs:
        p = Path(sd)
        if not p.is_dir():
            continue
        for f in p.rglob("*"):
            suffix = f.suffix.lower()
            if suffix in vhdl_exts:
                has_vhdl = True
            elif suffix in verilog_exts:
                has_verilog = True
            if has_vhdl and has_verilog:
                return has_vhdl, has_verilog

    return has_vhdl, has_verilog


# Open-source simulators to check — keyed by sdk_requirements.yml tool name.
# 'lang' determines whether missing is FAIL (project uses that language) or WARN.
_OSS_SIMULATORS = [
    {"key": "nvc",       "display": "NVC",            "lang": "vhdl"},
    {"key": "ghdl",      "display": "GHDL",           "lang": "vhdl"},
    {"key": "verilator", "display": "Verilator",       "lang": "verilog"},
    {"key": "icarus",    "display": "Icarus Verilog",  "lang": "verilog"},
]


@CheckRegistry.register("Simulators", order=11)
def check_simulators():
    """Check NVC, GHDL, Verilator, Icarus, and commercial simulators.

    Minimum versions and install hints are read from ``sdk_requirements.yml``
    (single source of truth).  Severity is derived from the project's HDL
    languages: VHDL simulators are errors when VHDL sources exist, Verilog
    simulators are errors when Verilog/SV sources exist.  When no project
    context is available, all open-source simulators are warnings.

    Commercial simulators (Riviera-PRO, Questa IFPGA) are only shown when
    relevant:  inside a matching Docker container, or when project.yml
    ``simulation.simulator`` explicitly requests them.  When shown, missing
    is a hard FAIL (not a soft warning).
    """
    from sdk.cli.eda_helpers import load_sdk_requirements

    reqs = load_sdk_requirements().get("tools", {})
    has_vhdl, has_verilog = _detect_project_languages()
    lang_required = {"vhdl": has_vhdl, "verilog": has_verilog}

    results = []
    for sim in _OSS_SIMULATORS:
        spec = reqs.get(sim["key"], {})
        results.append(
            check_simulator(
                sim["display"],
                spec.get("check_cmd", ""),
                spec.get("parse_regex", ""),
                spec.get("min_version"),
                lang_required.get(sim["lang"], False),
                spec.get("role", ""),
                spec.get("install_hint", ""),
            )
        )

    # ── Commercial simulators: context-aware visibility ──
    # Only shown when: (a) inside a matching Docker container, or
    # (b) project.yml simulation.simulator requests them.
    # When shown, missing = FAIL (the user explicitly needs them).
    docker_env = _detect_docker_container()

    # Read project.yml simulator preference
    yml_sim = None
    cfg = _load_project_yml()
    if isinstance(cfg, dict):
        sim_cfg = cfg.get("simulation") or {}
        if isinstance(sim_cfg, dict):
            yml_sim = (sim_cfg.get("simulator") or "").lower()

    # Questa IFPGA — show if inside quartus/questa container or yml requests it
    show_questa = docker_env in ("quartus", "questa") or yml_sim in ("questa", "vsim", "questa_ifpga")
    if show_questa:
        if docker_env in ("quartus", "questa"):
            questa = check_simulator(
                "Questa IFPGA",
                "vsim -version",
                r"vsim.*?(\d+\.\d+)",
                None,
                True,
                "Intel FPGA Edition simulator",
                f"Mount via Docker: {_cli_name()} docker shell quartus",
            )
            if questa.status != CheckResult.OK:
                questa = CheckResult(
                    "Questa IFPGA",
                    CheckResult.OK,
                    "running in Docker container",
                )
        else:
            questa = check_simulator(
                "Questa IFPGA",
                "vsim -version",
                r"vsim.*?(\d+\.\d+)",
                None,
                True,
                "Intel FPGA Edition simulator",
                f"Mount via Docker: {_cli_name()} docker shell quartus",
            )
        results.append(questa)

    # Riviera-PRO — show if inside riviera container or yml requests it
    show_riviera = docker_env == "riviera" or yml_sim in ("riviera", "riviera-pro")
    if show_riviera:
        if docker_env == "riviera":
            riv = check_simulator(
                "Riviera-PRO",
                "vsim -version",
                r"Riviera-PRO (\d+\.\d+)",
                "2024.04",
                True,
                "Commercial mixed-language simulator",
                f"Mount via Docker: {_cli_name()} docker shell riviera",
            )
            if riv.status != CheckResult.OK:
                riv = CheckResult(
                    "Riviera-PRO",
                    CheckResult.OK,
                    "running in Docker container",
                )
        else:
            riv = check_simulator(
                "Riviera-PRO",
                "vsim -version",
                r"Riviera-PRO (\d+\.\d+)",
                "2024.04",
                True,
                "Commercial mixed-language simulator",
                f"Mount via Docker: {_cli_name()} docker shell riviera",
            )
        results.append(riv)

    return results
