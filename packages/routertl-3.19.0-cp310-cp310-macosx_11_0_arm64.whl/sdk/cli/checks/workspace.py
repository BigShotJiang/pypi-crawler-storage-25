# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
Workspace health checks — git hooks, project.yml, build_env, LFS,
submodules, and dependencies.
"""

from __future__ import annotations

import os
from datetime import datetime
from pathlib import Path

import yaml

from sdk.cli.checks import CheckRegistry, CheckResult
from sdk.cli.checks._helpers import (
    _cli_name,
    _load_project_yml,
    _run,
)
from sdk.cli.resilience import cli_resilient

# ──────────────────────────────────────────────────────────────
# check_git_hooks  (order=40)
# ──────────────────────────────────────────────────────────────


@cli_resilient("git hooks check", default=CheckResult("Git Hooks", CheckResult.WARN, "could not check"))
@CheckRegistry.register("Git Hooks", order=40)
def check_git_hooks():
    """Verify pre-commit hook is installed (standard path or core.hooksPath)."""
    rc, git_dir = _run(["git", "rev-parse", "--git-dir"])
    if rc != 0:
        return CheckResult(
            "Git Hooks",
            CheckResult.WARN,
            "not in a git repository",
        )

    # 1. Check core.hooksPath (set by Common.mk auto-hook configuration)
    rc, hooks_path_cfg = _run(["git", "config", "core.hooksPath"])
    if rc == 0 and hooks_path_cfg.strip():
        hooks_dir = Path(hooks_path_cfg.strip())
        hook = hooks_dir / "pre-commit"
        # Resolve relative paths against the repo root
        if not hooks_dir.is_absolute():
            rc2, repo_root = _run(["git", "rev-parse", "--show-toplevel"])
            if rc2 == 0:
                hook = Path(repo_root.strip()) / hooks_dir / "pre-commit"
        if hook.exists() and os.access(str(hook), os.X_OK):
            return CheckResult(
                "Git Hooks",
                CheckResult.OK,
                f"configured via core.hooksPath ({hooks_path_cfg.strip()})",
            )
        return CheckResult(
            "Git Hooks",
            CheckResult.WARN,
            f"core.hooksPath set to '{hooks_path_cfg.strip()}' but pre-commit not found there",
            fix=f"Run: {_cli_name()} workspace install-hooks",
            fix_cmd=f"{_cli_name()} ws install-hooks",
        )

    # 2. Fallback: standard .git/hooks/pre-commit
    hook_path = Path(git_dir) / "hooks" / "pre-commit"
    if hook_path.exists() and os.access(str(hook_path), os.X_OK):
        return CheckResult("Git Hooks", CheckResult.OK, "pre-commit hook installed")
    return CheckResult(
        "Git Hooks",
        CheckResult.WARN,
        "pre-commit hook not found or not executable",
        fix=f"Run: {_cli_name()} workspace install-hooks",
        fix_cmd=f"{_cli_name()} ws install-hooks",
    )


# ──────────────────────────────────────────────────────────────
# check_project_yml  (order=41)
# ──────────────────────────────────────────────────────────────


@CheckRegistry.register("project.yml", order=41)
def check_project_yml():
    """Validate project.yml exists, has required fields, and passes semantic checks."""
    p = Path("project.yml")
    if not p.exists():
        return CheckResult(
            "project.yml",
            CheckResult.WARN,
            "not found in current directory",
            fix=f"Run: {_cli_name()} init",
            fix_cmd=f"{_cli_name()} init",
        )
    try:
        from sdk.cli.project_config import TargetNotFoundError, load_project_config

        cfg = load_project_config(str(p))
    except TargetNotFoundError as e:
        return CheckResult(
            "project.yml",
            CheckResult.FAIL,
            f"target pointer broken: {e}",
            fix="Check the target: path in project.yml",
        )
    except (yaml.YAMLError, FileNotFoundError) as e:
        return CheckResult(
            "project.yml",
            CheckResult.FAIL,
            f"YAML parse error: {e}",
            fix="Fix YAML syntax in project.yml",
        )

    if not isinstance(cfg, dict):
        return CheckResult(
            "project.yml",
            CheckResult.FAIL,
            "file is empty or not a mapping",
            fix=f"Re-initialize with: {_cli_name()} init",
            fix_cmd=f"{_cli_name()} init",
        )

    # Check required top-level keys
    missing = []
    for key in ["project", "hardware"]:
        if key not in cfg:
            missing.append(key)

    if missing:
        return CheckResult(
            "project.yml",
            CheckResult.FAIL,
            f"missing required sections: {', '.join(missing)}",
            fix=f"Add missing sections or re-run: {_cli_name()} init",
            fix_cmd=f"{_cli_name()} init",
        )

    results = []
    project = cfg.get("project") or {}
    if not isinstance(project, dict):
        project = {}
    if not project.get("name"):
        results.append(CheckResult(
            "project.yml",
            CheckResult.WARN,
            "project.name is empty",
            fix="Set project.name in project.yml",
        ))
    if not project.get("top_module"):
        results.append(CheckResult(
            "project.yml",
            CheckResult.WARN,
            "project.top_module is empty",
            fix="Set project.top_module in project.yml",
        ))

    # ── Tier 1: hardware.vendor ──
    KNOWN_VENDORS = {"xilinx", "intel", "altera", "lattice", "microchip"}
    hw = cfg.get("hardware") or {}
    if not isinstance(hw, dict):
        hw = {}
    vendor = hw.get("vendor", "")
    if vendor and vendor not in KNOWN_VENDORS:
        results.append(CheckResult(
            "project.yml",
            CheckResult.WARN,
            f"hardware.vendor '{vendor}' not recognized "
            f"(expected: {', '.join(sorted(KNOWN_VENDORS))})",
            fix="Set hardware.vendor to intel, lattice, or xilinx",
        ))

    # ── Tier 1: hardware.part ──
    if not hw.get("part"):
        results.append(CheckResult(
            "project.yml",
            CheckResult.WARN,
            "hardware.part is empty — synthesis will fail",
            fix="Set hardware.part in project.yml (e.g. xc7z020clg400-1)",
        ))

    # ── Tier 1: simulation.simulator ──
    KNOWN_SIMS = {"nvc", "ghdl", "questa", "verilator", "icarus", "riviera"}
    sim_cfg = cfg.get("simulation") or {}
    if isinstance(sim_cfg, dict):
        sim = sim_cfg.get("simulator", "")
        if sim and sim not in KNOWN_SIMS:
            results.append(CheckResult(
                "project.yml",
                CheckResult.WARN,
                f"simulation.simulator '{sim}' not recognized "
                f"(expected: {', '.join(sorted(KNOWN_SIMS))})",
                fix="Set simulation.simulator to ghdl, nvc, or questa",
            ))

    # ── Tier 1: sources.syn path existence ──
    sources = cfg.get("sources") or {}
    if isinstance(sources, dict):
        syn_files = sources.get("syn", [])
        if isinstance(syn_files, list) and syn_files:
            missing_files = [f for f in syn_files if isinstance(f, str) and not Path(f).exists()]
            if missing_files:
                shown = missing_files[:5]
                suffix = f" (+{len(missing_files) - 5} more)" if len(missing_files) > 5 else ""
                results.append(CheckResult(
                    "project.yml",
                    CheckResult.WARN,
                    f"{len(missing_files)} source file{'s' if len(missing_files) != 1 else ''} "
                    f"in sources.syn not found: {', '.join(shown)}{suffix}",
                    fix="Remove stale paths or restore missing files",
                ))

    # If no issues found, emit OK summary
    if not results:
        name = project.get("name", "?")
        top = project.get("top_module", "?")
        results.append(CheckResult(
            "project.yml",
            CheckResult.OK,
            f"valid — {name} (top: {top})",
        ))

    return results


# ──────────────────────────────────────────────────────────────
# check_build_env_staleness  (order=55)
# ──────────────────────────────────────────────────────────────


@CheckRegistry.register("build_env.mk", order=55)
def check_build_env_staleness():
    """Check if build_env.mk is older than project.yml."""
    yml_path = Path("project.yml")
    env_path = Path("build_env.mk")

    if not yml_path.exists():
        return CheckResult(
            "build_env.mk",
            CheckResult.WARN,
            "no project.yml to compare against",
        )

    if not env_path.exists():
        return CheckResult(
            "build_env.mk",
            CheckResult.FAIL,
            "missing — Makefile integration will not work",
            fix=f"Run: {_cli_name()} workspace update-config",
            fix_cmd=f"{_cli_name()} ws update-config",
        )

    yml_mtime = yml_path.stat().st_mtime
    env_mtime = env_path.stat().st_mtime

    if yml_mtime > env_mtime:
        delta = datetime.fromtimestamp(yml_mtime) - datetime.fromtimestamp(env_mtime)
        days = delta.days
        hours = int(delta.total_seconds() // 3600) % 24
        if days > 0:
            age_str = f"{days} day{'s' if days != 1 else ''}"
        elif hours > 0:
            age_str = f"{hours} hour{'s' if hours != 1 else ''}"
        else:
            mins = max(1, int(delta.total_seconds() // 60))
            age_str = f"{mins} minute{'s' if mins != 1 else ''}"
        return CheckResult(
            "build_env.mk",
            CheckResult.WARN,
            f"stale — {age_str} behind project.yml",
            fix=f"Run: {_cli_name()} workspace update-config",
            fix_cmd=f"{_cli_name()} ws update-config",
        )
    return CheckResult("build_env.mk", CheckResult.OK, "up to date with project.yml")


# ──────────────────────────────────────────────────────────────
# check_lfs  (order=65)
# ──────────────────────────────────────────────────────────────


@CheckRegistry.register("Git LFS", order=65)
def check_lfs():
    """Check Git LFS installation and whether all tracked files are pulled."""
    # Check if we're even in a git repo
    rc, _ = _run(["git", "rev-parse", "--git-dir"])
    if rc != 0:
        return CheckResult(
            "Git LFS",
            CheckResult.WARN,
            "not in a git repository",
        )

    # Check if git-lfs is installed
    from sdk.cli.checks._helpers import _parse_version

    rc, out = _run(["git", "lfs", "version"])
    if rc != 0:
        from sdk.cli.platform_hints import install_cmd
        _lfs_cmd = install_cmd("git-lfs") or "install git-lfs"
        _lfs_full = f"{_lfs_cmd} && git lfs install"
        return CheckResult(
            "Git LFS",
            CheckResult.WARN,
            "git-lfs not installed",
            fix=f"Install git-lfs: {_lfs_full}",
            fix_cmd=_lfs_full,
        )

    ver = _parse_version(out, r"git-lfs/(\d+\.\d+\.\d+)")
    ver_str = f"v{ver}" if ver else "installed"

    # Check for un-pulled files (pointer stubs)
    # `git lfs ls-files` output format:  <oid_prefix> <status> <path>
    # status: '*' = smudged (downloaded), '-' = pointer (not pulled)
    rc, ls_out = _run(["git", "lfs", "ls-files"], timeout=15)
    if rc != 0:
        # ls-files may fail if no LFS files are tracked — that's fine
        return CheckResult("Git LFS", CheckResult.OK, f"{ver_str} — no LFS-tracked files")

    unpulled = []
    for line in ls_out.strip().splitlines():
        line = line.strip()
        if not line:
            continue
        # Format: "<oid> - <path>" or "<oid> * <path>"
        parts = line.split(" ", 2)
        if len(parts) >= 3 and parts[1] == "-":
            unpulled.append(parts[2])

    if unpulled:
        names = ", ".join(unpulled[:5])
        suffix = f" (+{len(unpulled) - 5} more)" if len(unpulled) > 5 else ""
        return CheckResult(
            "Git LFS",
            CheckResult.WARN,
            f"{ver_str} — {len(unpulled)} file{'s' if len(unpulled) != 1 else ''} not pulled: {names}{suffix}",
            fix="Pull LFS files to replace pointer stubs",
            fix_cmd="git lfs pull",
        )

    total = len(ls_out.strip().splitlines())
    if total > 0:
        return CheckResult("Git LFS", CheckResult.OK, f"{ver_str} — {total} file{'s' if total != 1 else ''} pulled")
    return CheckResult("Git LFS", CheckResult.OK, f"{ver_str} — no LFS-tracked files")


# ──────────────────────────────────────────────────────────────
# check_lfs_netlists  (order=66)
# ──────────────────────────────────────────────────────────────


@CheckRegistry.register("LFS Netlists", order=66)
def check_lfs_netlists():
    """Scan project tree for vendor netlist files that are unpulled LFS stubs.

    Synthesis *will* fail when Quartus/Vivado encounters a 130-byte text
    pointer where it expects a binary netlist.  This check earns FAIL
    (not WARN) because the failure is guaranteed and cryptic.
    """
    NETLIST_EXTS = {".qxp", ".qdb"}
    LFS_MARKER = "version https://git-lfs"

    cwd = Path.cwd()
    stubs = []
    for ext in NETLIST_EXTS:
        for f in cwd.rglob(f"*{ext}"):
            # Skip .git internals and build artifacts
            rel_parts = f.relative_to(cwd).parts
            if any(p.startswith(".") for p in rel_parts):
                continue
            if "sim_build" in rel_parts:
                continue
            try:
                with open(f, "r", errors="ignore") as fh:
                    first_line = fh.readline()
                if first_line.startswith(LFS_MARKER):
                    stubs.append(str(f.relative_to(cwd)))
            except (OSError, UnicodeDecodeError):
                continue

    if not stubs:
        return []  # No netlist stubs — nothing to report

    names = ", ".join(stubs[:5])
    suffix = f" (+{len(stubs) - 5} more)" if len(stubs) > 5 else ""
    return [CheckResult(
        "LFS Netlists",
        CheckResult.FAIL,
        f"{len(stubs)} netlist stub{'s' if len(stubs) != 1 else ''} "
        f"not pulled: {names}{suffix}",
        fix="Synthesis will fail on pointer stubs — pull real files first",
        fix_cmd="git lfs pull",
    )]


# ──────────────────────────────────────────────────────────────
# check_submodules  (order=70)
# ──────────────────────────────────────────────────────────────


@cli_resilient("submodule health check", default=[])
@CheckRegistry.register("Submodules", order=70)
def check_submodules():
    """Detect uninitialized or diverged git submodules (recursively).

    Uses ``git submodule status --recursive`` to inspect every submodule
    at any nesting depth.  Status prefixes:
      '-' = not initialized  → FAIL
      '+' = checked out at different commit than pinned  → WARN
      ' ' = healthy  → counted toward OK
    """
    # Must be inside a git repo
    rc, _ = _run(["git", "rev-parse", "--git-dir"])
    if rc != 0:
        return []

    # --recursive handles nested submodules (submodules of submodules)
    rc, out = _run(["git", "submodule", "status", "--recursive"], timeout=15)
    if rc != 0 or not out.strip():
        return []  # No submodules or git error — skip silently

    fix_cmd = "git submodule update --init --recursive"
    issues = []
    ok_count = 0

    for line in out.strip().splitlines():
        line = line.strip()
        if not line:
            continue
        # Format: <status_char><sha1> <path> (<describe>)
        # status_char: '-' = uninitialized, '+' = diverged, ' ' = ok, 'U' = conflict
        status_char = line[0]
        # Extract path: split on whitespace, path is the second token
        parts = line[1:].strip().split(None, 2)
        if len(parts) < 2:
            continue
        sub_path = parts[1]
        name = Path(sub_path).name

        if status_char == "-":
            issues.append(CheckResult(
                f"Submodule ({name})",
                CheckResult.FAIL,
                f"not initialized: {sub_path}",
                fix="Initialize submodules after cloning",
                fix_cmd=fix_cmd,
            ))
        elif status_char == "U":
            issues.append(CheckResult(
                f"Submodule ({name})",
                CheckResult.FAIL,
                f"merge conflict: {sub_path}",
                fix="Resolve submodule merge conflict",
            ))
        else:
            ok_count += 1

    if issues:
        return issues

    return [CheckResult(
        "Submodules",
        CheckResult.OK,
        f"{ok_count} submodule{'s' if ok_count != 1 else ''} initialized",
    )]


# ──────────────────────────────────────────────────────────────
# check_dependencies  (order=71)
# ──────────────────────────────────────────────────────────────


@CheckRegistry.register("Dependencies", order=71)
def check_dependencies():
    """Verify SDK dependency clone paths from project.yml exist and are populated.

    Reads the ``dependencies`` section and checks each entry's ``path``.
    Returns WARN (not FAIL) for missing clones because dependencies
    auto-clone on first build — it's a 'not yet' state.
    """
    cfg = _load_project_yml()
    if not isinstance(cfg, dict):
        return []

    deps = cfg.get("dependencies")
    if not isinstance(deps, dict) or not deps:
        return []

    cli = _cli_name()
    results = []
    ok_count = 0

    for dep_name, dep_cfg in deps.items():
        if not isinstance(dep_cfg, dict):
            continue
        dep_path = dep_cfg.get("path")
        if not dep_path:
            continue

        full = Path(dep_path)
        if not full.exists():
            results.append(CheckResult(
                f"Dependency ({dep_name})",
                CheckResult.WARN,
                f"not cloned: {dep_path}",
                fix=f"Run: {cli} workspace update-config",
                fix_cmd=f"{cli} ws update-config",
            ))
        elif full.is_dir() and not any(full.iterdir()):
            results.append(CheckResult(
                f"Dependency ({dep_name})",
                CheckResult.WARN,
                f"directory empty (interrupted clone?): {dep_path}",
                fix=f"Run: {cli} workspace update-config",
                fix_cmd=f"{cli} ws update-config",
            ))
        else:
            ok_count += 1

    # Only emit OK summary if all deps passed and there were no warnings
    if not results and ok_count > 0:
        results.append(CheckResult(
            "Dependencies",
            CheckResult.OK,
            f"{ok_count} dependency clone{'s' if ok_count != 1 else ''} present",
        ))

    return results


# ──────────────────────────────────────────────────────────────
# check_ip_dependencies  (order=72, P2.81)
# ──────────────────────────────────────────────────────────────


@cli_resilient("IP dependency check", default=[])
@CheckRegistry.register("IP Dependencies", order=72)
def check_ip_dependencies():
    """Verify that SDK-bundled IP dependencies declared in ip.yml are available.

    Walks ``project.yml`` → ``sources.ips`` → each ``ip.yml`` →
    ``dependencies`` and checks if each dependency is either locally
    fetched (in ``deps/``) or resolvable from the SDK root.
    """
    cfg = _load_project_yml()
    if not isinstance(cfg, dict):
        return []

    ip_paths_raw = cfg.get("sources")
    if not isinstance(ip_paths_raw, dict):
        return []
    ip_paths = ip_paths_raw.get("ips", [])
    if not ip_paths:
        return []

    vendor = (cfg.get("hardware") or {}).get("vendor", "xilinx")

    try:
        from sdk.engine.ip_resolver import IpDependencyResolver, IpResolver
    except ImportError:
        return []

    project_root = Path.cwd()
    resolver = IpResolver(project_root, vendor)
    result = resolver.resolve(ip_paths)

    # Collect all deps across manifests
    all_deps = []
    for m in result.manifests:
        all_deps.extend(m.dependencies)

    if not all_deps:
        return []

    dep_resolver = IpDependencyResolver()
    checks = dep_resolver.check_all(result.manifests, project_root / "deps")

    cli = _cli_name()
    results = []
    ok_count = 0
    missing_count = 0

    for c in checks:
        if c["status"] == "ok":
            ok_count += 1
        elif c["status"] == "missing":
            missing_count += 1
            results.append(CheckResult(
                f"IP Dep ({c['dep_id']})",
                CheckResult.WARN,
                c["detail"],
                fix=f"Run: {cli} deps fetch",
                fix_cmd=f"{cli} deps fetch",
            ))
        else:
            results.append(CheckResult(
                f"IP Dep ({c['dep_id']})",
                CheckResult.FAIL,
                c["detail"],
            ))

    if not results and ok_count > 0:
        results.append(CheckResult(
            "IP Dependencies",
            CheckResult.OK,
            f"{ok_count} IP dep{'s' if ok_count != 1 else ''} resolved",
        ))

    return results


# ──────────────────────────────────────────────────────────────
# check_lockfile  (order=75, P3.55)
# ──────────────────────────────────────────────────────────────


@cli_resilient("lockfile check", default=CheckResult("Lockfile", CheckResult.WARN, "could not check"))
@CheckRegistry.register("Lockfile", order=75)
def check_lockfile_health():
    """Verify lockfile presence, freshness, and consistency with project state."""
    from sdk.engine.lockfile import LOCKFILE_NAME, load_lockfile

    lock = load_lockfile(".")
    cli = _cli_name()

    if not lock:
        return CheckResult(
            "Lockfile",
            CheckResult.WARN,
            f"no {LOCKFILE_NAME} found",
            fix="Create a lockfile for reproducible builds",
            fix_cmd=f"{cli} lock",
        )

    # Lockfile exists — run the full check
    from sdk.engine.lockfile import check_lockfile as _engine_check

    ok, diffs = _engine_check(".")

    if ok:
        locked_at = lock.get("locked_at", "?")
        n_sources = len(lock.get("sources", []))
        return CheckResult(
            "Lockfile",
            CheckResult.OK,
            f"{LOCKFILE_NAME} up to date ({n_sources} sources, locked {locked_at})",
        )

    summary = f"{len(diffs)} mismatch{'es' if len(diffs) != 1 else ''}"
    detail_parts = []
    for d in diffs[:3]:
        detail_parts.append(d)
    if len(diffs) > 3:
        detail_parts.append(f"... and {len(diffs) - 3} more")

    return CheckResult(
        "Lockfile",
        CheckResult.FAIL,
        f"{summary}: {'; '.join(detail_parts)}",
        fix="Re-resolve the lockfile to match current project state",
        fix_cmd=f"{cli} lock --update",
    )
