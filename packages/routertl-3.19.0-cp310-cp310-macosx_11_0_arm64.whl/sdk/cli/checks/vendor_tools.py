# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
Vendor tool health checks — synthesis tools, Docker, license server,
licensed families, and vendor-specific simulation libraries.
"""

from __future__ import annotations

import os
from pathlib import Path

from sdk.cli.checks import CheckRegistry, CheckResult
from sdk.cli.checks._helpers import (
    _cli_name,
    _detect_docker_container,
    _load_project_yml,
    _parse_version,
    _run,
    _which,
)
from sdk.cli.resilience import cli_resilient_block

# ──────────────────────────────────────────────────────────────
# check_vendor_tool  (order=20)
# ──────────────────────────────────────────────────────────────


@CheckRegistry.register("Vendor Tool", order=20)
def check_vendor_tool():
    """Check vendor-specific synthesis tool based on project.yml hardware.vendor."""
    # Vendor → (binary, display_name, version_cmd, version_regex, install_hint)
    VENDOR_TOOLS = {
        "xilinx": (
            "vivado",
            "Vivado",
            ["vivado", "-version"],
            r"Vivado v(\d+\.\d+)",
            "Source Vivado settings: source /tools/Xilinx/Vivado/<ver>/settings64.sh",
        ),
        "altera": (
            "quartus_sh",
            "Quartus",
            ["quartus_sh", "--version"],
            r"Version (\d+\.\d+)",
            "Add Quartus to PATH: export PATH=/opt/altera/quartus/bin:$PATH",
        ),
        "lattice": (
            "radiantc",
            "Radiant",
            ["radiantc", "--version"],
            r"(\d+\.\d+)",
            "Add Radiant to PATH: export PATH=/opt/lscc/radiant/<ver>/bin/lin64:$PATH",
        ),
        "microchip": (
            "libero",
            "Libero SoC",
            ["libero", "--version"],
            r"(\d+\.\d+)",
            "Add Libero SoC to PATH",
        ),
    }

    # Docker-aware: if inside a vendor container, show it as running
    docker_env = _detect_docker_container()
    DOCKER_TO_VENDOR = {"dev": "xilinx", "quartus": "altera", "vivado": "xilinx", "radiant": "lattice", "libero": "microchip"}
    if docker_env and docker_env in DOCKER_TO_VENDOR:
        vendor_key = DOCKER_TO_VENDOR[docker_env]
        tool_info = VENDOR_TOOLS[vendor_key]
        _, display_name, ver_cmd, ver_regex, _ = tool_info
        rc, out = _run(ver_cmd)
        ver = _parse_version(out, ver_regex)
        edition = _parse_quartus_edition(out) if vendor_key == "altera" else None
        edition_tag = f" {edition}" if edition else ""
        detail = f"v{ver}{edition_tag} (Docker container)" if ver else "running in Docker container"
        return CheckResult(display_name, CheckResult.OK, detail)

    cfg = _load_project_yml()
    vendor = "xilinx"  # default
    expected_edition = None
    if isinstance(cfg, dict):
        hw = cfg.get("hardware") or {}
        if isinstance(hw, dict):
            vendor = hw.get("vendor") or "xilinx"
            expected_edition = hw.get("edition")

    tool_info = VENDOR_TOOLS.get(vendor, VENDOR_TOOLS["xilinx"])
    binary, display_name, ver_cmd, ver_regex, hint = tool_info

    from sdk.api.tools import resolve_tool_binary

    path = resolve_tool_binary(binary, config=cfg)
    if not path:
        return CheckResult(
            display_name,
            CheckResult.WARN,
            f"'{binary}' not found on PATH",
            fix=hint,
        )

    # Microchip's CLI crashes on headless servers when trying to load Qt plugins,
    # even just for `--version`. If we found the binary, we consider it OK.
    if vendor == "microchip":
        return CheckResult(
            display_name,
            CheckResult.OK,
            f"Found at {path} (version execution bypassed)",
        )

    # Use the resolved path for version check
    resolved_ver_cmd = [path] + ver_cmd[1:]
    rc, out = _run(resolved_ver_cmd)
    ver = _parse_version(out, ver_regex)

    # Quartus edition detection (Pro / Standard / Lite)
    edition = _parse_quartus_edition(out) if vendor == "altera" else None
    edition_tag = f" {edition}" if edition else ""
    detail = f"v{ver}{edition_tag} ({path})" if ver else f"found ({path})"

    # Cross-check edition against project.yml hardware.edition
    if edition and expected_edition:
        expected_norm = expected_edition.lower().replace("_", " ")
        detected_norm = edition.lower()
        if expected_norm not in detected_norm:
            return CheckResult(
                display_name,
                CheckResult.WARN,
                f"v{ver}{edition_tag} — expected {expected_edition} (from project.yml)",
                fix=f"Install Quartus Prime {expected_edition} or update project.yml: "
                f"hardware.edition: {edition.split()[0].lower()}",
            )

    return CheckResult(display_name, CheckResult.OK, detail)


def _parse_quartus_edition(version_output: str) -> str | None:
    """Extract the Quartus edition from ``quartus_sh --version`` output.

    Known edition strings (from Intel documentation):
      - ``SC Pro Edition``  (formerly "Pro Edition")
      - ``Pro Edition``
      - ``Standard Edition``
      - ``Lite Edition``

    Returns:
        Short edition string like "Pro", "Standard", "Lite", or None.
    """
    import re

    m = re.search(r"(SC\s+Pro|Pro|Standard|Lite)\s+Edition", version_output, re.IGNORECASE)
    if m:
        raw = m.group(1).strip()
        # Normalize: "SC Pro" → "Pro"
        if raw.lower().startswith("sc"):
            return "Pro"
        return raw.capitalize()
    return None


# ──────────────────────────────────────────────────────────────
# check_tool_type_consistency  (order=21)  — P3.42
# ──────────────────────────────────────────────────────────────


@CheckRegistry.register("Tool Taxonomy", order=21)
def check_tool_type_consistency():
    """Validate that hardware.tool matches a known tool entry and its TCL backend exists.

    P3.42: Distinguishes edition variants (shared TCL) from flow variants
    (separate TCL backend).  Warns when a flow tool's TCL directory is
    missing or only contains a README stub.
    """
    cfg = _load_project_yml()
    if not isinstance(cfg, dict):
        return []  # no project.yml — skip

    hw = cfg.get("hardware") or {}
    if not isinstance(hw, dict):
        return []

    vendor = (hw.get("vendor") or "").lower()
    hw_tool = (hw.get("tool") or "").lower()
    if not vendor or not hw_tool:
        return []  # no vendor or tool specified — nothing to check

    # Load vendor database
    vdb = None
    with cli_resilient_block("tool taxonomy vendor database"):
        import yaml

        vdb_paths = [
            Path.cwd() / "vendor" / "routertl" / "sdk" / "engine" / "supported_vendors.yml",
            Path(__file__).parent.parent.parent / "engine" / "supported_vendors.yml",
        ]
        for vdb_path in vdb_paths:
            if vdb_path.exists():
                with open(vdb_path) as f:
                    vdb = yaml.safe_load(f) or {}
                break

    if not vdb:
        return []

    v_data = vdb.get(vendor, {})
    tools = v_data.get("tools", {})
    tool_entry = tools.get(hw_tool)

    if not tool_entry:
        # Tool not found in vendor database — list available
        available = ", ".join(tools.keys()) if tools else "none"
        return CheckResult(
            "Tool Taxonomy",
            CheckResult.WARN,
            f"'{hw_tool}' not found in {vendor} tools (available: {available})",
            fix=f"Check supported tools: {available}",
        )

    tool_type = tool_entry.get("type", "edition")
    tcl_backend = tool_entry.get("tcl_backend", vendor)
    display_type = "flow" if tool_type == "flow" else "edition"

    # For flow variants, check that the TCL backend has actual scripts
    if tool_type == "flow":
        from sdk.cli.sdk_root import resolve_sdk_root

        sdk_root = resolve_sdk_root() or Path.cwd()
        tcl_dir = sdk_root / "tcl" / tcl_backend
        has_scripts = tcl_dir.is_dir() and any(tcl_dir.glob("*.tcl"))

        if not has_scripts:
            return CheckResult(
                "Tool Taxonomy",
                CheckResult.WARN,
                f"'{hw_tool}' is a {display_type} variant — TCL backend "
                f"'{tcl_backend}' not yet implemented",
                fix=f"Use the default {vendor} tool, or implement tcl/{tcl_backend}/ scripts",
            )

    return CheckResult(
        "Tool Taxonomy",
        CheckResult.OK,
        f"'{hw_tool}' ({display_type} variant, backend: {tcl_backend})",
    )


# ──────────────────────────────────────────────────────────────
# check_docker  (order=25)
# ──────────────────────────────────────────────────────────────

@CheckRegistry.register("Docker", order=25)
def check_docker():
    """Validate Docker is running."""
    docker_env = _detect_docker_container()
    if docker_env:
        return CheckResult(
            "Docker",
            CheckResult.OK,
            f"inside Docker container (routertl-{docker_env})",
        )
    path = _which("docker")
    if not path:
        return CheckResult(
            "Docker",
            CheckResult.WARN,
            "not installed",
            fix="Install Docker Engine: https://docs.docker.com/engine/install/",
        )
    rc, out = _run(["docker", "info"], timeout=15)
    if rc != 0:
        return CheckResult(
            "Docker",
            CheckResult.WARN,
            "installed but daemon not running",
            fix="Start Docker: sudo systemctl start docker",
        )
    return CheckResult("Docker", CheckResult.OK, f"running ({path})")


# ──────────────────────────────────────────────────────────────
# _check_license_server  (order=30)
# ──────────────────────────────────────────────────────────────


@CheckRegistry.register("License Server", order=30)
def _check_license_server():
    """Check license server reachability via TCP probe."""
    results = []

    # License server probe
    lic_str = os.environ.get("LM_LICENSE_FILE", "")
    if not lic_str:
        # Check .env file
        env_file = Path(".env")
        if env_file.exists():
            with cli_resilient_block(".env license parsing"):
                for line in env_file.read_text().splitlines():
                    line = line.strip()
                    if line.startswith("LM_LICENSE_FILE="):
                        lic_str = line.split("=", 1)[1].strip()
                        break

    if lic_str:
        try:
            from sdk.cli.commands.docker.status import _probe_license_server

            reachable = _probe_license_server(lic_str)
            if reachable is True:
                results.append(
                    CheckResult(
                        "License Server",
                        CheckResult.OK,
                        f"reachable ({lic_str})",
                    )
                )
            elif reachable is False:
                results.append(
                    CheckResult(
                        "License Server",
                        CheckResult.WARN,
                        f"unreachable ({lic_str})",
                        fix="Check license server is running",
                    )
                )
            else:
                results.append(
                    CheckResult(
                        "License Server",
                        CheckResult.OK,
                        f"configured ({lic_str})",
                    )
                )
        except ImportError:
            results.append(
                CheckResult(
                    "License Server",
                    CheckResult.OK,
                    f"configured ({lic_str})",
                )
            )
    else:
        results.append(
            CheckResult(
                "License Server",
                CheckResult.WARN,
                "LM_LICENSE_FILE not set",
                fix=f"{_cli_name()} docker setup",
                fix_cmd=f"{_cli_name()} docker setup",
            )
        )

    return results


# ──────────────────────────────────────────────────────────────
# check_licensed_families  (order=31)
# ──────────────────────────────────────────────────────────────


@CheckRegistry.register("Licensed Families", order=31)
def check_licensed_families():
    """Deep license check: query EDA tool for actually-licensed families.

    Goes beyond TCP reachability — invokes quartus_sh or vivado to enumerate
    which device families are licensed, then compares against project.yml.
    """
    results = []

    # Only meaningful when a vendor tool is available
    from sdk.api.tools import resolve_tool_binary

    if not (
        resolve_tool_binary("quartus_sh")
        or resolve_tool_binary("vivado")
        or resolve_tool_binary("libero")
    ):
        # No vendor tool on PATH — skip silently (doctor already checks this)
        return results

    with cli_resilient_block("licensed families query"):
        from sdk.cli.commands.license import (
            _query_licensed_families,
            _resolve_target_family,
        )

        vendor, families = _query_licensed_families()
        if vendor and not families:
            if vendor == "Microchip":
                results.append(
                    CheckResult(
                        "Licensed Families",
                        CheckResult.OK,
                        f"{vendor} (family querying skipped)",
                    )
                )
                return results

            results.append(
                CheckResult(
                    "Licensed Families",
                    CheckResult.WARN,
                    f"{vendor} found but returned no licensed families",
                    fix="Check LM_LICENSE_FILE and license server configuration.\n"
                    "       If device families are not installed, run: "
                    f"{_cli_name()} docker add-device quartus",
                )
            )
            return results

        if not vendor:
            return results

        target_family, target_part = _resolve_target_family()
        if not target_family:
            # No target family in project.yml — just report count
            results.append(
                CheckResult(
                    "Licensed Families",
                    CheckResult.OK,
                    f"{len(families)} families available via {vendor}",
                )
            )
            return results

        target_found = any(f.lower() == target_family.lower() for f in families)
        if target_found:
            results.append(
                CheckResult(
                    "Licensed Families",
                    CheckResult.OK,
                    f"{target_family} licensed ({len(families)} families via {vendor})",
                )
            )
        else:
            avail = ", ".join(families[:5])
            suffix = f" (+{len(families) - 5} more)" if len(families) > 5 else ""
            results.append(
                CheckResult(
                    "Licensed Families",
                    CheckResult.FAIL,
                    f"{target_family} NOT licensed — available: {avail}{suffix}",
                    fix=f"Obtain a {target_family} license, or retarget: "
                    f"{_cli_name()} config set hardware.family <licensed_family>",
                    fix_cmd=f"{_cli_name()} config set hardware.family <licensed_family>",
                )
            )

    return results


# ──────────────────────────────────────────────────────────────
# check_vivado_installation  (order=66)  — P3.8
# ──────────────────────────────────────────────────────────────


@CheckRegistry.register("Vivado Installation", order=66)
def check_vivado_installation():
    """Check Xilinx Vivado installation status and version.

    Reports:
      OK   — vivado found on PATH with version extracted
      WARN — vivado not found (skips for non-Xilinx projects)
    """
    # Only relevant for Xilinx projects
    cfg = _load_project_yml()
    if isinstance(cfg, dict):
        hw = cfg.get("hardware") or {}
        if isinstance(hw, dict):
            vendor = (hw.get("vendor") or "xilinx").lower()
            if vendor not in ("xilinx", "amd"):
                return []  # silently skip — irrelevant for non-Xilinx

    import shutil
    import subprocess

    vivado_path = shutil.which("vivado")
    if not vivado_path:
        cli = _cli_name()
        return CheckResult(
            "Vivado Installation",
            CheckResult.WARN,
            "vivado not found on PATH",
            fix="Install Xilinx Vivado or use the Docker container",
            fix_cmd=f"{cli} docker shell vivado",
        )

    # Extract version
    version = "unknown"
    with cli_resilient_block("vivado version extraction"):
        result = subprocess.run(
            ["vivado", "-version"],
            capture_output=True,
            text=True,
            timeout=30,
        )
        output = result.stdout + result.stderr
        # Vivado prints: Vivado v2025.1 (64-bit)
        import re

        m = re.search(r"Vivado\s+v?([\d.]+)", output)
        if m:
            version = m.group(1)

    # P3.86: Fallback — parse version from filesystem path
    # e.g. /tools/Xilinx/Vivado/2024.1/bin/vivado → 2024.1
    if version == "unknown" and vivado_path:
        import re
        pm = re.search(r"[/\\]Vivado[/\\](\d+\.\d+)", vivado_path)
        if pm:
            version = pm.group(1)

    return CheckResult(
        "Vivado Installation",
        CheckResult.OK,
        f"Vivado {version} ({vivado_path})",
    )


# ──────────────────────────────────────────────────────────────
# check_unisim  (order=67)  — Vendor simulation libraries
# ──────────────────────────────────────────────────────────────


@CheckRegistry.register("Unisim", order=67)
def check_unisim():
    """Check Xilinx unisim VHDL source availability.

    Reports:
      OK   — precompiled lib exists or VHDL sources are available
      WARN — sources not found; suggests ``rr eda install-unisim``
      OK   — (skip) non-Xilinx project or no project.yml
    """
    cli = _cli_name()

    # Only relevant for Xilinx projects
    cfg = _load_project_yml()
    if isinstance(cfg, dict):
        hw = cfg.get("hardware") or {}
        if isinstance(hw, dict):
            vendor = (hw.get("vendor") or "xilinx").lower()
            if vendor not in ("xilinx", "amd"):
                return []  # silently skip — irrelevant for non-Xilinx

    # Check precompiled NVC or GHDL libs
    with cli_resilient_block("unisim precompiled check"):
        from routertl_core.sim.vendor_libraries import (
            _resolve_unisim_path,
            ghdl_unisim_available,
            nvc_unisim_available,
        )
        if nvc_unisim_available():
            return CheckResult("Unisim", CheckResult.OK, "NVC precompiled library available")
        if ghdl_unisim_available():
            return CheckResult("Unisim", CheckResult.OK, "GHDL precompiled library available")

        # Check VHDL source availability
        src = _resolve_unisim_path()
        if src:
            return CheckResult("Unisim", CheckResult.OK, f"VHDL sources available ({src})")

    return CheckResult(
        "Unisim",
        CheckResult.WARN,
        "VHDL sources not found — Xilinx simulations will fail",
        fix="Download unisim sources to ~/.routertl/vendor_libs/unisim/",
        fix_cmd=f"{cli} eda install-unisim",
    )


# ──────────────────────────────────────────────────────────────
# check_lattice_ld_library_path  (order=68)  — P3.38
# ──────────────────────────────────────────────────────────────


@CheckRegistry.register("Radiant LD_LIBRARY_PATH", order=68)
def check_lattice_ld_library_path():
    """Check LD_LIBRARY_PATH for Lattice Radiant shared libraries.

    Radiant tools require ``LD_LIBRARY_PATH`` to include the Radiant
    ``lib/lin64`` directory.  Without it, ``radiantc`` and other tools
    crash with missing ``.so`` errors at runtime.

    Only shown when ``hardware.vendor == lattice`` in ``project.yml``.
    """
    # Only relevant for Lattice projects
    cfg = _load_project_yml()
    if isinstance(cfg, dict):
        hw = cfg.get("hardware") or {}
        if isinstance(hw, dict):
            vendor = (hw.get("vendor") or "xilinx").lower()
            if vendor != "lattice":
                return []  # silently skip — irrelevant for non-Lattice

    ld_path = os.environ.get("LD_LIBRARY_PATH", "")

    # Look for any Radiant-related path component
    radiant_found = False
    radiant_dir = ""
    for entry in ld_path.split(os.pathsep):
        entry_lower = entry.lower()
        if "radiant" in entry_lower and ("lib" in entry_lower or "lin64" in entry_lower):
            radiant_found = True
            radiant_dir = entry
            break

    if radiant_found:
        return CheckResult(
            "Radiant Libs",
            CheckResult.OK,
            f"LD_LIBRARY_PATH includes {radiant_dir}",
        )

    # Try to auto-detect Radiant installation
    from sdk.api.tools import resolve_tool_binary

    radiant_bin = resolve_tool_binary("radiantc")
    if radiant_bin:
        # Derive expected lib path from binary location
        radiant_root = Path(radiant_bin).resolve().parent.parent
        expected_lib = radiant_root / "lib" / "lin64"
        if expected_lib.is_dir():
            return CheckResult(
                "Radiant Libs",
                CheckResult.WARN,
                "LD_LIBRARY_PATH missing Radiant libs",
                fix="Add Radiant shared libraries to LD_LIBRARY_PATH",
                fix_cmd=f"export LD_LIBRARY_PATH={expected_lib}:$LD_LIBRARY_PATH",
            )

    return CheckResult(
        "Radiant Libs",
        CheckResult.WARN,
        "LD_LIBRARY_PATH does not include Radiant lib directory",
        fix="Add Radiant's lib/lin64 directory to LD_LIBRARY_PATH",
        fix_cmd="export LD_LIBRARY_PATH=/path/to/radiant/lib/lin64:$LD_LIBRARY_PATH",
    )


# ──────────────────────────────────────────────────────────────
# check_libero_installation  (order=69)  — P3.36
# ──────────────────────────────────────────────────────────────


@CheckRegistry.register("Libero Installation", order=69)
def check_libero_installation():
    """Check Microchip Libero SoC installation status and version.

    Reports:
      OK   — libero found on PATH or at /opt/microchip/ with version
      WARN — libero not found (skips for non-Microchip projects)
    """
    # Only relevant for Microchip projects
    cfg = _load_project_yml()
    if isinstance(cfg, dict):
        hw = cfg.get("hardware") or {}
        if isinstance(hw, dict):
            vendor = (hw.get("vendor") or "xilinx").lower()
            if vendor != "microchip":
                return []  # silently skip — irrelevant for non-Microchip

    import glob
    import shutil

    libero_path = shutil.which("libero")

    # Fallback: check common installation paths
    if not libero_path:

        candidates = glob.glob("/opt/microchip/libero_soc/Libero_SoC/Designer/bin64/libero")
        if candidates:
            libero_path = candidates[0]

    if not libero_path:
        cli = _cli_name()
        return CheckResult(
            "Libero Installation",
            CheckResult.WARN,
            "Libero SoC not found on PATH or at /opt/microchip/",
            fix="Install Microchip Libero SoC or add it to PATH",
            fix_cmd="export PATH=/opt/microchip/libero_soc/Libero_SoC/Designer/bin64:$PATH",
        )

    # Extract version from LiberoConfig.txt (robust — works in Docker too)
    version = "unknown"
    with cli_resilient_block("libero version extraction"):
        import os
        import re

        # Walk up from binary to find LiberoConfig.txt
        # Binary is at: .../Libero_SoC/Designer/bin64/libero
        # LiberoConfig.txt is at: .../LiberoConfig.txt (sibling to Libero_SoC/)
        search_dir = os.path.dirname(libero_path)
        for _ in range(5):  # walk up at most 5 levels
            search_dir = os.path.dirname(search_dir)
            config_path = os.path.join(search_dir, "LiberoConfig.txt")
            if os.path.isfile(config_path):
                with open(config_path) as f:
                    for line in f:
                        m = re.match(r"\s*(\d{4}\.\d+\.\d+\.\d+)", line.strip())
                        if m:
                            version = m.group(1)
                            break
                break

    return CheckResult(
        "Libero Installation",
        CheckResult.OK,
        f"Libero SoC {version} ({libero_path})",
    )

