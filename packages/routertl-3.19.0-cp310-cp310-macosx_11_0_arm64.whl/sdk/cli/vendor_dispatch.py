# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Vendor Dispatch — construct and run vendor-specific TCL commands.

Replaces the Make-level vendor flow logic from ``synthesis.mk`` and
``Common.mk``.  Reads ``project.yml`` and ``build_env.mk`` to construct
the correct ``quartus_sh -t …`` / ``vivado -mode batch -source …`` /
``pnmainc …`` / ``libero SCRIPT:…`` invocations.
"""

import os
import shutil
import sys
from pathlib import Path

from sdk.cli.console import console
from sdk.cli.engine_dispatch import ensure_build_env
from sdk.cli.resilience import cli_resilient_block
from sdk.engine.process_monitor import (
    MonitorStats,
    find_concurrent_processes,
    monitored_run,
)


class VendorToolNotFound(RuntimeError):
    """Raised when the required vendor EDA tool is not on PATH."""


class VendorDispatch:
    """Construct and execute vendor-specific TCL commands.

    Attributes
    ----------
    vendor : str
        One of ``xilinx``, ``altera``, ``lattice``, ``microchip``.
    tool_cmd : str
        The vendor tool command (e.g. ``vivado -mode batch -source``).
    tcl_run : str
        Base command for TCL script execution.
    tcl_flag : str
        Argument separator for TCL args (e.g. ``-tclargs`` for Vivado).
    root_dir : Path
        Project root directory.
    sdk_root : Path
        SDK root directory.
    """

    # Vendor → (tcl_run_builder, tcl_flag)
    _VENDOR_CONFIG = {
        "xilinx": {
            "tcl_flag": "-tclargs",
            "tool_candidates": ["vivado"],
            "tool_suffix": "",
        },
        "altera": {
            "tcl_flag": "",
            "tool_candidates": ["quartus_sh"],
            "tool_suffix": "-t",
        },
        "lattice": {
            "tcl_flag": "",
            "tool_candidates": ["radiantc", "pnmainc"],
            "tool_suffix": "",
        },
        "microchip": {
            "tcl_flag": "SCRIPT_ARGS:",
            "tool_candidates": ["libero"],
            "tool_suffix": "SCRIPT:",
        },
        "opensource": {
            "tcl_flag": "",
            "tool_candidates": ["yosys", "nextpnr-ice40", "nextpnr-ecp5", "nextpnr-gowin"],
            "tool_suffix": "",
        },
    }

    def __init__(
        self,
        vendor: str,
        tool_cmd: str,
        tcl_flag: str,
        root_dir: Path,
        sdk_root: Path,
        build_env: dict[str, str],
        tcl_backend: str | None = None,
        tool_path: str | None = None,
        project_path: str = "project",
        mem_limit_gb: float = 40,
        poll_interval_s: float = 3,
        max_jobs: int | None = None,
    ):
        self.vendor = vendor
        self.tool_cmd = tool_cmd
        self.tcl_flag = tcl_flag
        self.root_dir = root_dir
        self.sdk_root = sdk_root
        self.build_env = build_env
        self.tcl_backend = tcl_backend
        self.tool_path = tool_path
        self.project_path = project_path
        self.mem_limit_gb = mem_limit_gb
        self.poll_interval_s = poll_interval_s
        self.max_jobs = max_jobs
        self._last_monitor_stats: MonitorStats | None = None

    @classmethod
    def from_project(
        cls,
        root_dir: Path | None = None,
        project_yml: str = "project.yml",
    ) -> "VendorDispatch":
        """Create a VendorDispatch from project.yml and build_env.mk.

        Parameters
        ----------
        root_dir : Path, optional
            Project root.  Defaults to cwd.
        project_yml : str
            Path to project.yml.
        """
        root_dir = root_dir or Path.cwd()

        # Read build environment
        build_env = ensure_build_env(project_yml)

        # Load project config once via the unified loader
        _project_cfg: dict = {}
        with cli_resilient_block("project config loading"):
            from sdk.cli.project_config import load_project_config

            yml_full = str(root_dir / project_yml) if root_dir != Path.cwd() else project_yml
            _project_cfg = load_project_config(yml_full)

        _hw = _project_cfg.get("hardware") or {}
        if not isinstance(_hw, dict):
            _hw = {}

        # Determine vendor
        vendor = build_env.get("VENDOR", "").lower()
        if not vendor:
            vendor = (_hw.get("vendor") or "xilinx").lower()

        config = cls._VENDOR_CONFIG.get(vendor, cls._VENDOR_CONFIG["xilinx"])

        # Resolve tool command
        tool_cmd = build_env.get("TOOL_CMD", "")

        # Strip Make variable references like $(QUARTUS_SH) that leak
        # from legacy build_env.mk files (P2.101).  Extract the inner
        # name, lowercase it, and try shutil.which() on that.
        if tool_cmd and tool_cmd.startswith("$("):
            import re as _re

            m = _re.match(r"^\$\((\w+)\)$", tool_cmd)
            inner = m.group(1).lower() if m else ""
            resolved = shutil.which(inner) if inner else None
            tool_cmd = inner if resolved else ""

        # P3.42: tcl_backend may be set to a flow-specific TCL directory
        tcl_backend = None

        if not tool_cmd:
            # P3.25: Reorder candidates based on hardware.tool from project.yml
            hw_tool = (_hw.get("tool") or "").lower()

            candidates = list(config["tool_candidates"])
            if hw_tool:
                # Look up the vendor database for the tool variant's tool_cmd
                # and tcl_backend (P3.42: edition vs flow distinction)
                with cli_resilient_block("vendor database tool lookup"):
                    import yaml as _yaml2

                    vdb_paths = [
                        root_dir / "vendor" / "routertl" / "sdk" / "engine" / "supported_vendors.yml",
                        Path(__file__).parent.parent / "engine" / "supported_vendors.yml",
                    ]
                    for vdb_path in vdb_paths:
                        if vdb_path.exists():
                            with open(vdb_path) as f:
                                vdb = _yaml2.safe_load(f) or {}
                            v_data = vdb.get(vendor, {})
                            tool_entry = v_data.get("tools", {}).get(hw_tool, {})
                            if tool_entry and "tool_cmd" in tool_entry:
                                preferred = tool_entry["tool_cmd"]
                                # Move preferred to front of candidates
                                if preferred in candidates:
                                    candidates.remove(preferred)
                                candidates.insert(0, preferred)
                            # P3.42: resolve tcl_backend for flow-variant tools
                            if tool_entry and "tcl_backend" in tool_entry:
                                tcl_backend = tool_entry["tcl_backend"]
                            break

            for candidate in candidates:
                if shutil.which(candidate):
                    tool_cmd = candidate
                    break
            if not tool_cmd:
                tool_cmd = candidates[0]

        # Store tool_path for later injection into subprocess env dicts
        # (do NOT mutate os.environ — see ADR D.5 / Roast audit Burn #2)
        _tool_path = _hw.get("tool_path") if isinstance(_hw, dict) else None

        # Resolve SDK root
        from sdk.cli.sdk_root import resolve_sdk_root

        sdk_root = resolve_sdk_root() or root_dir

        # Build tcl_run command
        suffix = config["tool_suffix"]
        if suffix:
            tool_cmd = f"{tool_cmd} {suffix}"

        # Resolve project_path
        project_path = "project"
        project_section = _project_cfg.get("project") or {}
        if isinstance(project_section, dict) and "path" in project_section:
            project_path = project_section["path"]

        mk_overrides = _project_cfg.get("makefile_overrides") or {}
        if isinstance(mk_overrides, dict) and "project_dir" in mk_overrides:
            project_path = mk_overrides["project_dir"]

        # Monitor settings: project.yml hardware.monitor section or env vars
        _monitor = _hw.get("monitor") or {}
        if not isinstance(_monitor, dict):
            _monitor = {}
        from sdk.engine.process_monitor import (
            _DEFAULT_MEM_LIMIT_GB,
            _DEFAULT_POLL_INTERVAL_S,
            _get_available_ram_gb,
        )

        mem_limit_gb = float(
            os.environ.get("RR_MEM_LIMIT_GB", "")
            or _monitor.get("mem_limit_gb", _DEFAULT_MEM_LIMIT_GB)
        )
        poll_interval_s = float(
            os.environ.get("RR_POLL_INTERVAL_S", "")
            or _monitor.get("poll_interval_s", _DEFAULT_POLL_INTERVAL_S)
        )
        # max_jobs: only set if explicitly configured (env var or project.yml).
        # None means "let the TCL layer use its own default cap (4)".
        _max_jobs_str = os.environ.get("RR_MAX_JOBS", "")
        if _max_jobs_str:
            max_jobs: int | None = int(_max_jobs_str)
        elif _monitor.get("max_jobs"):
            max_jobs = int(_monitor["max_jobs"])
        else:
            max_jobs = None

        # Clamp max_jobs by available RAM (~6 GB per Vivado placer thread).
        # 2026-04-19 incident: unclamped jobs + single Vivado hit swap
        # thrash before the polled monitor could react.  RR_NO_RAM_CLAMP=1
        # disables; set when running on a ramdisk/cloud box with known
        # headroom.
        if max_jobs is not None and os.environ.get("RR_NO_RAM_CLAMP") != "1":
            avail_gb = _get_available_ram_gb()
            if avail_gb > 0:
                ram_cap = max(1, int(avail_gb // 6))
                if max_jobs > ram_cap:
                    console.print(
                        f"[yellow]⚠ RAM clamp: max_jobs={max_jobs} → {ram_cap} "
                        f"(≈{avail_gb:.0f} GB available, 6 GB/job)[/]"
                    )
                    max_jobs = ram_cap

        return cls(
            vendor=vendor,
            tool_cmd=tool_cmd,
            tcl_flag=config["tcl_flag"],
            root_dir=root_dir,
            sdk_root=sdk_root,
            build_env=build_env,
            tcl_backend=tcl_backend,
            tool_path=_tool_path,
            project_path=project_path,
            mem_limit_gb=mem_limit_gb,
            poll_interval_s=poll_interval_s,
            max_jobs=max_jobs,
        )

    def _tcl_path(self, script_name: str) -> Path:
        """Resolve a vendor-specific TCL script path.

        P3.42: Uses ``tcl_backend`` when set (flow-variant tools that
        need a different TCL directory).  Falls back to ``self.vendor``
        for edition variants and legacy configurations.
        """
        backend = self.tcl_backend or self.vendor
        return self.sdk_root / "tcl" / backend / script_name

    def _check_tool_available(self):
        """Raise VendorToolNotFound if the vendor tool is not on PATH."""
        tool_bin = self.tool_cmd.split()[0]
        if not shutil.which(tool_bin):
            lines = [
                f"❌ [red]Vendor tool '{tool_bin}' not found on PATH.[/]",
                f"   VENDOR={self.vendor}",
            ]
            if self.vendor == "opensource":
                # Opensource toolchain is Yosys + GHDL + nextpnr, typically
                # built from source. Point users at the zero-setup Docker
                # path first — that's what most people will want — then
                # link the host-install guide.
                lines += [
                    "",
                    "   Easiest fix — use the Docker path (no host install):",
                    "     [cyan]rr docker install sim[/]     # one-time image build",
                    "     [cyan]rr docker shell sim[/]       # drop into the container",
                    "     [cyan]rr synth run[/]              # run synth inside",
                    "",
                    "   Host install (Yosys + GHDL + ghdl-yosys-plugin + nextpnr):",
                    "     see [cyan]docs/guides/vendors/OPENSOURCE.md[/]",
                ]
            else:
                lines += [
                    f"   Hint: Is the {self.vendor} toolchain installed?",
                    "   Run [cyan]rr doctor[/] to diagnose.",
                ]
            console.print("\n".join(lines))
            raise VendorToolNotFound(tool_bin)

    # Map of top-level vendor tool → process names whose presence indicates
    # a concurrent instance.  Include Vivado's real worker binary explicitly:
    # it can outlive the launcher and often survives interactive sessions.
    _CONCURRENT_PROBES: dict[str, list[str]] = {
        "vivado": ["vivado", "vivado_real", "loader"],
        "quartus_sh": ["quartus_sh", "quartus_syn", "quartus_fit"],
        "radiantc": ["radiantc"],
        "pnmainc": ["pnmainc"],
        "libero": ["libero"],
    }

    def _check_no_concurrent_vendor_process(self) -> int:
        """Refuse to spawn when another instance of this vendor tool is live.

        Returns 0 to proceed, non-zero to abort.  Override via
        ``RR_ALLOW_CONCURRENT=1`` when you really know what you're doing.
        """
        if os.environ.get("RR_ALLOW_CONCURRENT") == "1":
            return 0
        tool_bin = self.tool_cmd.split()[0]
        probe_names = self._CONCURRENT_PROBES.get(tool_bin, [tool_bin])
        running = find_concurrent_processes(probe_names)
        if not running:
            return 0
        console.print(
            f"\n❌ [red bold]Refusing to launch {tool_bin}: "
            f"another EDA instance is already running.[/]"
        )
        for pid, cmdline in running:
            short = cmdline[:120] + ("…" if len(cmdline) > 120 else "")
            console.print(f"   PID [bold]{pid}[/]: {short}")
        console.print(
            "   [dim]Reason: concurrent EDA runs crashed the system "
            "on 2026-04-19 (RTL-P1.40).[/]\n"
            "   [dim]If you're sure it's safe: "
            "[bold]export RR_ALLOW_CONCURRENT=1[/bold][/]"
        )
        return 1

    def _run_tcl(self, tcl_script: Path, *tcl_args: str) -> int:
        """Run a vendor TCL script with correct invocation syntax.

        For Microchip/Libero, generates a temporary wrapper TCL because
        Libero's ``SCRIPT_ARGS:`` only passes the first token to
        ``$::argv`` — subsequent arguments are silently dropped (P2.100).

        Returns the process exit code.
        """
        self._check_tool_available()
        if (rc := self._check_no_concurrent_vendor_process()) != 0:
            return rc

        wrapper_path: Path | None = None

        if self.vendor == "microchip" and tcl_args:
            # Libero workaround: write a temp TCL wrapper that explicitly
            # sets $::argv / $::argc, then sources the real script.
            import tempfile

            tcl_list_items = " ".join(
                f'"{a}"' if a else '""' for a in tcl_args
            )
            wrapper_content = (
                f'set ::argv [list {tcl_list_items}]\n'
                f'set ::argc [llength $::argv]\n'
                f'source "{tcl_script}"\n'
            )
            fd, wrapper_file = tempfile.mkstemp(
                suffix=".tcl", prefix="rr_libero_"
            )
            wrapper_path = Path(wrapper_file)
            with os.fdopen(fd, "w") as f:
                f.write(wrapper_content)

            # Invoke: libero SCRIPT:<wrapper>
            tool_bin = self.tool_cmd.split()[0]
            cmd = [tool_bin, f"SCRIPT:{wrapper_path}"]
        else:
            parts = self.tool_cmd.split()
            cmd = parts + [str(tcl_script)]
            if self.tcl_flag:
                cmd.append(self.tcl_flag)
            cmd.extend(tcl_args)

        console.print(f"   [dim]→ {' '.join(cmd[:4])}…[/]")

        # Build subprocess env with tool_path injection (no os.environ mutation)
        env = os.environ.copy()
        if self.tool_path:
            from sdk.cli.env_setup import inject_tool_path

            env = inject_tool_path(env, self.tool_path)

        # Inject max_jobs so the TCL layer (get_number_of_cores) respects it
        if self.max_jobs is not None:
            env["RR_MAX_JOBS"] = str(self.max_jobs)

        try:
            rc, stats = monitored_run(
                cmd,
                env=env,
                mem_limit_gb=self.mem_limit_gb,
                poll_interval_s=self.poll_interval_s,
            )
            self._last_monitor_stats = stats
            if stats.killed:
                console.print(
                    f"\n  🛑 [red bold]Process killed by RAM monitor:[/] "
                    f"{stats.kill_reason}\n"
                    f"  Peak system RAM: {stats.peak_system_ram_gb:.1f} GB | "
                    f"Peak process RAM: {stats.peak_process_ram_gb:.1f} GB\n"
                    f"  [dim]Log: .routertl_cache/process_monitor.log[/]"
                )
            elif stats.peak_system_ram_gb > 0:
                console.print(
                    f"  [dim]RAM peak: {stats.peak_system_ram_gb:.1f} GB system, "
                    f"{stats.peak_process_ram_gb:.1f} GB process[/]"
                )
            return rc
        finally:
            if wrapper_path and wrapper_path.exists():
                wrapper_path.unlink()

    def _run_python_script(self, script: Path, *args: str) -> int:
        """Run a Python driver script (used by opensource vendor).

        For the open-source toolchain, implementation (nextpnr) and
        bitstream (icepack/ecppack) phases are driven by Python scripts
        instead of vendor TCL.

        Passes FPGA_PART and TOP_MODULE as environment variables.
        """
        if (rc := self._check_no_concurrent_vendor_process()) != 0:
            return rc

        env = os.environ.copy()
        env["FPGA_PART"] = self.build_env.get("FPGA_PART", "")
        env["TOP_MODULE"] = self.build_env.get("TOP_MODULE", "")

        if self.tool_path:
            from sdk.cli.env_setup import inject_tool_path

            env = inject_tool_path(env, self.tool_path)

        cmd = [sys.executable, str(script)] + list(args)
        console.print(f"   [dim]→ python {script.name} {' '.join(args[:2])}…[/]")

        rc, stats = monitored_run(
            cmd,
            env=env,
            mem_limit_gb=self.mem_limit_gb,
            poll_interval_s=self.poll_interval_s,
        )
        self._last_monitor_stats = stats
        if stats.killed:
            console.print(
                f"\n  🛑 [red bold]Process killed by RAM monitor:[/] "
                f"{stats.kill_reason}"
            )
        return rc

    def _run_script(self, script: Path, *args: str) -> int:
        """Run a backend script — dispatches .py to Python, .tcl to vendor tool."""
        if script.suffix == ".py":
            return self._run_python_script(script, *args)
        return self._run_tcl(script, *args)

    # ── Public API ────────────────────────────────────────────────────

    def _project_file_exists(self) -> bool:
        """Check whether the vendor project file already exists."""
        ext_map = {
            "lattice": ".rdf",
            "microchip": ".prjx",
            "xilinx": ".xpr",
            "altera": ".qpf",
        }
        ext = ext_map.get(self.vendor, "")
        if not ext:
            return True
        project_dir = self.root_dir / self.project_path
        return any(project_dir.glob(f"*{ext}"))

    def ensure_project(self) -> int:
        """Create the vendor project if it doesn't exist yet.

        Returns 0 on success or if the project already exists.
        """
        if self._project_file_exists():
            return 0
        console.print(
            "   [dim]Project file not found — generating project first…[/]"
        )
        return self.project()

    def _ensure_rom_info(self) -> None:
        """Stamp build metadata (git hash, date, version) into rom_info_pkg.

        Always runs — every project gets build metadata, not just regbank
        projects.  Lock generation is only triggered when a regbank YAML
        is present.
        """
        regbank_yml = self.root_dir / "project_regbank.yml"
        if regbank_yml.exists():
            lock_file = self.root_dir / "routertl.lock"
            if not lock_file.exists():
                with cli_resilient_block("lock generation"):
                    console.print("   [dim]Generating routertl.lock for build provenance…[/]")
                    from sdk.engine.lockfile import resolve_project_state, write_lockfile
                    write_lockfile(resolve_project_state(str(self.root_dir)), str(self.root_dir))
        with cli_resilient_block("Build metadata stamping"):
            from sdk.cli.commands.hardware import _run_make
            console.print("   [dim]Stamping build metadata…[/]")
            _run_make("build_metadata")

    def synthesis(self, dry_run: bool = False) -> int:
        """Run full project synthesis.

        Auto-generates the vendor project if it doesn't exist yet.
        For the opensource vendor, delegates to a Python driver script
        (gen_synthesis.py) instead of a vendor TCL script.

        RTL-P3.156: ``dry_run=True`` forces project regeneration (so BD
        patches / gen_project hooks are exercised and validate_bd_design
        runs inside gen_project.tcl) and then returns BEFORE synth_design.
        Typical cycle drops from 30-60 min to 2-3 min for BD / hook
        iteration.
        """
        if dry_run:
            console.print(
                "🎯 [yellow]--dry-run: regenerating project + running "
                "gen_project hooks, will exit before synth_design.[/]"
            )
            rc = self.project()
        else:
            rc = self.ensure_project()
        if rc != 0:
            console.print(
                "❌ [red]Project generation failed — cannot proceed "
                "with synthesis.[/]"
            )
            return rc
        if dry_run:
            console.print(
                "✅ [green]--dry-run complete: project generated and "
                "hooks sourced.  Skipping synth_design.[/]"
            )
            return 0
        self._ensure_rom_info()
        console.print("🚀 [blue]Synthesizing Project...[/]")
        # Try Python driver first (opensource), fall back to TCL
        py_script = self._tcl_path("gen_synthesis.py")
        if py_script.exists():
            rc = self._run_python_script(py_script, str(self.root_dir))
        else:
            tcl = self._tcl_path("gen_synthesis.tcl")
            rc = self._run_tcl(tcl, str(self.root_dir))
        if rc == 0:
            self._record_known_part()
        return rc

    def implementation(self) -> int:
        """Run implementation (place & route).

        For the opensource vendor, delegates to a Python driver script
        (gen_implementation.py) instead of a vendor TCL script.
        """
        console.print("🚀 [blue]Running Implementation...[/]")
        # Try Python driver first (opensource), fall back to TCL
        py_script = self._tcl_path("gen_implementation.py")
        if py_script.exists():
            return self._run_python_script(py_script, str(self.root_dir))
        tcl = self._tcl_path("gen_implementation.tcl")
        return self._run_tcl(tcl, str(self.root_dir))

    def bitstream(self) -> int:
        """Generate bitstream.

        For the opensource vendor, delegates to a Python driver script
        (gen_bitstream.py) instead of a vendor TCL script.
        """
        console.print("🚀 [blue]Generating Bitstream...[/]")
        # Try Python driver first (opensource), fall back to TCL
        py_script = self._tcl_path("gen_bitstream.py")
        if py_script.exists():
            return self._run_python_script(py_script, str(self.root_dir))
        tcl = self._tcl_path("gen_bitstream.tcl")
        return self._run_tcl(tcl, str(self.root_dir))

    def synth_check(self) -> int:
        """Run post-synthesis constraint validation (STA/CDC checks).

        Does NOT trigger synthesis.  Requires existing synthesis
        artifacts from a prior ``rr synth run``.

        Returns the process exit code.
        """
        console.print("🔍 [blue]Running post-synthesis constraint checks...[/]")
        tcl = self._tcl_path("synth_check.tcl")
        return self._run_tcl(tcl, str(self.root_dir))

    def package_ip(self, tcl_script: Path) -> int:
        """Package user RTL as IP-XACT core via Vivado ipx:: commands.

        Runs a generated TCL script that uses ``ipx::package_project``
        and related commands to produce a ``component.xml``.

        Returns the process exit code.
        """
        console.print("📦 [blue]Packaging IP-XACT core...[/]")
        return self._run_tcl(tcl_script)

    def update_hex(self) -> int:
        """Firmware-only rebuild: stage hex, update MIF, reassemble.

        Skips synthesis and implementation entirely.  Only supported for
        Altera/Intel (Quartus) projects where quartus_cdb --update_mif
        natively supports this flow.

        Returns the process exit code.
        """
        if self.vendor != "altera":
            console.print(
                "❌ [red]--update-hex is only supported for Altera/Intel "
                "(Quartus) projects.[/]\n"
                "   Xilinx updatemem is not yet supported — use a full "
                "rebuild instead."
            )
            return 1

        console.print("⚡ [blue]Firmware-only rebuild (--update-hex)...[/]")
        tcl = self._tcl_path("update_hex.tcl")
        return self._run_tcl(tcl, str(self.root_dir))

    def project(
        self,
        syn_files: str = "",
        ip_files: str = "",
        sim_files: str = "",
        tcl_files: str = "",
        xdc_files: str = "",
        netlist_files: str = "",
    ) -> int:
        """Generate vendor project."""
        console.print("🏗  [blue]Building Project...[/]")
        tcl = self._tcl_path("gen_project.tcl")
        return self._run_tcl(
            tcl,
            str(self.root_dir),
            syn_files or self.build_env.get("SYN_FILES", ""),
            ip_files or self.build_env.get("IP_FILES", ""),
            sim_files or self.build_env.get("SIM_FILES", ""),
            tcl_files or self.build_env.get("TCL_FILES", ""),
            xdc_files or self.build_env.get("XDC_FILES", self.build_env.get("SDC_FILES", "")),
            netlist_files or self.build_env.get("NETLIST_FILES", ""),
        )

    def program(
        self,
        bitstream: str | None = None,
        cable: str | None = None,
        eval_accept: bool = False,
    ) -> int:
        """Program FPGA device.

        Parameters
        ----------
        eval_accept : bool
            When True, auto-dismisses the eval IP time-limited license
            prompt by piping input to quartus_pgm (Quartus only, P2.129).
        """
        console.print("🚀 [blue]Programming FPGA device...[/]")
        tcl = self._tcl_path("gen_program.tcl")

        # Fallback to defaults from build_env if not provided (P3.44)
        bitstream = bitstream or self.build_env.get("BITSTREAM_PATH", "")

        return self._run_tcl(
            tcl,
            str(self.root_dir),
            bitstream or "",
            cable or "",
            "eval_accept" if eval_accept else "",
        )

    def software_program(self, software: str | None = None, cable: str | None = None) -> int:
        """Download software ELF to softcore/SoC."""
        console.print(f"🚀 [blue]Downloading software: {software}...[/]")
        tcl = self._tcl_path("gen_software_program.tcl")
        return self._run_tcl(
            tcl,
            str(self.root_dir),
            software or "",
            cable or "",
        )

    def npm_synthesis(
        self,
        top: str,
        npm_files: str,
        ip_files: str = "",
        xdc_files: str = "",
        netlist_files: str = "",
    ) -> int:
        """Run Non-Project Mode synthesis for a single module."""
        console.print(f"🚀 [blue]Synthesizing {top} (NPM)...[/]")
        tcl = self._tcl_path("non_project_mode.tcl")
        return self._run_tcl(
            tcl,
            str(self.root_dir),
            npm_files,
            ip_files or self.build_env.get("IP_FILES", ""),
            xdc_files or self.build_env.get("XDC_FILES", self.build_env.get("SDC_FILES", "")),
            top,
            netlist_files or self.build_env.get("NETLIST_FILES", ""),
        )

    def _record_known_part(self):
        """Record successfully synthesized FPGA part (mirrors Make behavior)."""
        parts_file = self.root_dir / ".routertl" / "known_parts.txt"
        parts_file.parent.mkdir(parents=True, exist_ok=True)
        fpga_part = self.build_env.get("FPGA_PART", "")
        if not fpga_part:
            return
        entry = f"{self.vendor} {fpga_part}"
        if parts_file.exists():
            existing = parts_file.read_text()
            if entry in existing:
                return
        else:
            # First-time creation: write header
            parts_file.write_text(
                "# RouteRTL — Known FPGA Parts (auto-updated)\n"
                "# Format: <vendor> <part>\n"
            )
        with open(parts_file, "a") as f:
            f.write(f"{entry}\n")
