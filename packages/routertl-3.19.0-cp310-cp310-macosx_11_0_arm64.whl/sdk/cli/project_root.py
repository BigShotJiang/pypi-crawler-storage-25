# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Project root resolution — walk up from CWD to find project.yml.

Every CLI command that needs ``project.yml`` benefits from this module.
The :func:`find_project_root` function is called once at CLI bootstrap
(``main.py``) to ``os.chdir()`` into the project root before any
subcommand runs.
"""

from __future__ import annotations

import os
from pathlib import Path

_PROJECT_MARKER = "project.yml"
_ENV_VAR = "RR_PROJECT_ROOT"

# A real project root has project.yml AND at least one of these.
# This prevents target YAMLs (targets/board_a/project.yml) from being
# mistaken for the project root when CWD is inside targets/.
_ROOT_CORROBORATORS = ("Makefile", ".git", "sdk", "vendor")


def _is_project_root(directory: Path) -> bool:
    """Return True if *directory* looks like a real project root."""
    if not (directory / _PROJECT_MARKER).exists():
        return False
    return any((directory / c).exists() for c in _ROOT_CORROBORATORS)


def find_project_root(start: Path | None = None) -> Path | None:
    """Locate the nearest ancestor directory that is a project root.

    A project root is a directory containing ``project.yml`` **and** at
    least one corroborating marker (``Makefile``, ``.git``, ``sdk/``, or
    ``vendor/``).  This prevents target YAML files inside ``targets/``
    subdirectories from being mistaken for the project root.

    Resolution order:

    1. ``RR_PROJECT_ROOT`` env var (authoritative — if set but invalid,
       returns ``None`` without falling through to the walk).
    2. Walk up from *start* (default: CWD) checking each directory.

    Returns
    -------
    Path or None
        The project root directory, or ``None`` if no project was found.
    """
    # ── Env var override (authoritative) ──
    env_root = os.environ.get(_ENV_VAR)
    if env_root:
        candidate = Path(env_root).resolve()
        if _is_project_root(candidate):
            return candidate
        return None

    # ── Walk up from start directory ──
    current = (start or Path.cwd()).resolve()
    for directory in [current, *current.parents]:
        if _is_project_root(directory):
            return directory

    return None
