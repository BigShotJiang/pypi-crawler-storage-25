#!/bin/bash
# =============================================================================
# build_initramfs.sh — Build a minimal BusyBox initramfs for QEMU testing
# =============================================================================
#
# Creates a tiny rootfs with BusyBox, kernel modules, and an optional
# test script.  Used by `rr linux qemu build-rootfs`.
#
# Usage:
#   build_initramfs.sh --modules-dir <dir> --output <rootfs.cpio.gz>
#                      [--test-script <script.sh>]
#
# Ported from linux_zybo/zynq_cam_driver/qemu/build_initramfs.sh (RTL-P3.107)
# =============================================================================

set -euo pipefail

MODULES_DIR=""
OUTPUT=""
TEST_SCRIPT=""
HEADLESS=false

while [[ $# -gt 0 ]]; do
    case "$1" in
        --modules-dir)  MODULES_DIR="$2"; shift 2 ;;
        --output)       OUTPUT="$2";      shift 2 ;;
        --test-script)  TEST_SCRIPT="$2"; shift 2 ;;
        --headless)     HEADLESS=true;    shift ;;
        *)              echo "Unknown argument: $1"; exit 1 ;;
    esac
done

if [[ -z "$OUTPUT" ]]; then
    echo "Usage: build_initramfs.sh --output <rootfs.cpio.gz> [--modules-dir <dir>] [--test-script <script.sh>]"
    exit 1
fi

TMP_ROOT=$(mktemp -d)
trap "rm -rf $TMP_ROOT" EXIT

echo "[1/5] Creating filesystem skeleton..."
mkdir -p "$TMP_ROOT"/{bin,sbin,etc,proc,sys,dev,tmp,root,lib/modules}

echo "[2/5] Installing BusyBox..."
BUSYBOX=$(which busybox 2>/dev/null || echo "/usr/bin/busybox")
if [[ ! -f "$BUSYBOX" ]]; then
    echo "ERROR: busybox not found. Install: apt install busybox-static"
    exit 1
fi
cp "$BUSYBOX" "$TMP_ROOT/bin/busybox"
chmod +x "$TMP_ROOT/bin/busybox"

for cmd in sh ash ls cat echo mount mkdir mknod modprobe insmod lsmod \
           dmesg grep sleep rm cp mv ln chmod chown id pwd ps kill \
           ifconfig ip hostname vi test true false; do
    ln -sf busybox "$TMP_ROOT/bin/$cmd"
done
ln -sf ../bin/busybox "$TMP_ROOT/sbin/init"

echo "[3/5] Copying kernel modules..."
KO_COUNT=0
if [[ -n "$MODULES_DIR" && -d "$MODULES_DIR" ]]; then
    find "$MODULES_DIR" -name "*.ko" -exec cp {} "$TMP_ROOT/lib/modules/" \; 2>/dev/null || true
    KO_COUNT=$(find "$TMP_ROOT/lib/modules" -name "*.ko" | wc -l)
fi
echo "  Found $KO_COUNT .ko module(s)"

echo "[4/5] Creating init script..."
if $HEADLESS; then
    # Headless init: run test, print sentinel with exit code, poweroff
    cat > "$TMP_ROOT/init" << 'INIT_EOF'
#!/bin/sh
mount -t proc proc /proc
mount -t sysfs sysfs /sys
mount -t devtmpfs devtmpfs /dev

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  RouteRTL — QEMU Headless Test"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "Kernel: $(uname -r)"
echo ""

EXIT_CODE=0
if [ -f /root/test.sh ]; then
    sh /root/test.sh
    EXIT_CODE=$?
else
    echo "WARNING: No test script found at /root/test.sh"
    EXIT_CODE=1
fi

echo ""
echo "RR_QEMU_EXIT=$EXIT_CODE"
poweroff -f
INIT_EOF
else
    # Interactive init: run test if present, drop to shell
    cat > "$TMP_ROOT/init" << 'INIT_EOF'
#!/bin/sh
mount -t proc proc /proc
mount -t sysfs sysfs /sys
mount -t devtmpfs devtmpfs /dev

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  RouteRTL — QEMU Test Environment"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "Kernel: $(uname -r)"
echo ""

echo "Available modules:"
ls /lib/modules/*.ko 2>/dev/null || echo "  (none)"
echo ""

if [ -f /root/test.sh ]; then
    echo "Running test script..."
    echo ""
    sh /root/test.sh
    echo ""
fi

echo "Shell ready. Type 'poweroff -f' to exit QEMU."
echo ""
exec /bin/sh
INIT_EOF
fi
chmod +x "$TMP_ROOT/init"

# Copy test script if provided
if [[ -n "$TEST_SCRIPT" && -f "$TEST_SCRIPT" ]]; then
    cp "$TEST_SCRIPT" "$TMP_ROOT/root/test.sh"
    chmod +x "$TMP_ROOT/root/test.sh"
fi

echo "[5/5] Packing initramfs..."
mkdir -p "$(dirname "$OUTPUT")"
(cd "$TMP_ROOT" && find . | cpio -o -H newc --quiet | gzip -9) > "$OUTPUT"

SIZE=$(du -sh "$OUTPUT" | cut -f1)
echo ""
echo "SUCCESS: Initramfs → $OUTPUT ($SIZE)"
