#!/bin/bash
# =============================================================================
# prepare_dtb.sh — Merge a DT overlay into a base DTB for QEMU
# =============================================================================
#
# Decompiles the base DTB, injects overlay nodes, recompiles.
# Used by `rr linux qemu prepare-dtb`.
#
# Usage:
#   prepare_dtb.sh --base <base.dtb> --overlay <overlay.dts> --output <merged.dtb>
#
# Ported from linux_zybo/zynq_cam_driver/qemu/prepare_dtb.sh (RTL-P3.105)
# =============================================================================

set -euo pipefail

BASE_DTB=""
OVERLAY_DTS=""
OUTPUT_DTB=""

while [[ $# -gt 0 ]]; do
    case "$1" in
        --base)    BASE_DTB="$2";    shift 2 ;;
        --overlay) OVERLAY_DTS="$2"; shift 2 ;;
        --output)  OUTPUT_DTB="$2";  shift 2 ;;
        *)         echo "Unknown argument: $1"; exit 1 ;;
    esac
done

if [[ -z "$BASE_DTB" || -z "$OVERLAY_DTS" || -z "$OUTPUT_DTB" ]]; then
    echo "Usage: prepare_dtb.sh --base <base.dtb> --overlay <overlay.dts> --output <merged.dtb>"
    exit 1
fi

# --- Check prerequisites ---
if ! command -v dtc &>/dev/null; then
    echo "ERROR: 'dtc' (device-tree-compiler) not found."
    echo "  Install: sudo apt install device-tree-compiler"
    exit 1
fi

if [[ ! -f "$BASE_DTB" ]]; then
    echo "ERROR: Base DTB not found: $BASE_DTB"
    exit 1
fi

if [[ ! -f "$OVERLAY_DTS" ]]; then
    echo "ERROR: Overlay DTS not found: $OVERLAY_DTS"
    exit 1
fi

TMP_DIR=$(mktemp -d)
trap "rm -rf $TMP_DIR" EXIT

echo "[1/3] Decompiling base DTB..."
dtc -I dtb -O dts -o "$TMP_DIR/base.dts" "$BASE_DTB" 2>/dev/null

echo "[2/3] Merging overlay nodes..."
# Extract content inside the overlay's root / { ... }; block and inject
# into the base DTS before its closing brace.
python3 - "$TMP_DIR/base.dts" "$OVERLAY_DTS" "$TMP_DIR/merged.dts" << 'PYEOF'
import sys

base_path, overlay_path, out_path = sys.argv[1], sys.argv[2], sys.argv[3]

with open(base_path) as f:
    base = f.read()

with open(overlay_path) as f:
    overlay = f.read()

# Extract nodes from inside the overlay root block
lines = overlay.split('\n')
in_root = False
depth = 0
content = []
for line in lines:
    if '/ {' in line and not in_root:
        in_root = True
        depth = 1
        continue
    if in_root:
        depth += line.count('{') - line.count('}')
        if depth <= 0:
            break
        content.append(line)

if not content:
    print("WARNING: No nodes found in overlay — writing base DTB unchanged")
    with open(out_path, 'w') as f:
        f.write(base)
    sys.exit(0)

inject = '\n'.join(content)

last_brace = base.rfind('};')
if last_brace == -1:
    print("ERROR: Could not find root closing brace in base DTS")
    sys.exit(1)

merged = base[:last_brace] + '\n' + inject + '\n};\n'

with open(out_path, 'w') as f:
    f.write(merged)
PYEOF

echo "[3/3] Compiling merged DTB..."
mkdir -p "$(dirname "$OUTPUT_DTB")"
dtc -I dts -O dtb -o "$OUTPUT_DTB" "$TMP_DIR/merged.dts" 2>/dev/null

echo ""
echo "SUCCESS: Merged DTB → $OUTPUT_DTB"
