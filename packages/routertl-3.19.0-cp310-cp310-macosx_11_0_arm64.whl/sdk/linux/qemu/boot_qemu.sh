#!/bin/bash
# =============================================================================
# boot_qemu.sh — Launch QEMU for Zynq embedded Linux testing
# =============================================================================
#
# Boots qemu-system-arm with the Xilinx Zynq machine and user-supplied
# kernel, DTB, and rootfs.  Used by `rr linux qemu boot`.
#
# Usage:
#   boot_qemu.sh --kernel <uImage> --dtb <dtb> [--rootfs <cpio.gz|img>]
#                [--machine <machine>] [--memory <size>] [--append <cmdline>]
#
# Ported from linux_zybo/zynq_cam_driver/qemu/boot_qemu_zynq.sh (RTL-P2.212)
# =============================================================================

set -euo pipefail

# --- Defaults ---
MACHINE="xilinx-zynq-a9"
MEMORY="512M"
KERNEL=""
DTB=""
ROOTFS=""
APPEND="console=ttyPS0,115200 root=/dev/ram rw earlyprintk"
HEADLESS=false
TIMEOUT=120

# --- Parse arguments ---
while [[ $# -gt 0 ]]; do
    case "$1" in
        --machine)  MACHINE="$2";  shift 2 ;;
        --memory)   MEMORY="$2";   shift 2 ;;
        --kernel)   KERNEL="$2";   shift 2 ;;
        --dtb)      DTB="$2";      shift 2 ;;
        --rootfs)   ROOTFS="$2";   shift 2 ;;
        --append)   APPEND="$2";   shift 2 ;;
        --headless) HEADLESS=true; shift ;;
        --timeout)  TIMEOUT="$2";  shift 2 ;;
        *)          echo "Unknown argument: $1"; exit 1 ;;
    esac
done

# --- Validate ---
if [[ -z "$KERNEL" ]]; then
    echo "ERROR: --kernel is required"
    exit 1
fi

if [[ ! -f "$KERNEL" ]]; then
    echo "ERROR: Kernel image not found: $KERNEL"
    exit 1
fi

if [[ -n "$DTB" && ! -f "$DTB" ]]; then
    echo "ERROR: DTB not found: $DTB"
    exit 1
fi

# --- Check QEMU is available ---
QEMU_BIN="qemu-system-arm"
if ! command -v "$QEMU_BIN" &>/dev/null; then
    echo "ERROR: $QEMU_BIN not found."
    echo "  Install: sudo apt install qemu-system-arm"
    echo "  Or use:  rr linux qemu boot --docker"
    exit 1
fi

# --- Build QEMU command ---
QEMU_CMD=(
    "$QEMU_BIN"
    -M "$MACHINE"
    -m "$MEMORY"
    -serial mon:stdio
    -display none
    -no-reboot
    -kernel "$KERNEL"
)

[[ -n "$DTB" ]] && QEMU_CMD+=(-dtb "$DTB")

# --- Rootfs handling ---
if [[ -n "$ROOTFS" ]]; then
    if [[ ! -f "$ROOTFS" ]]; then
        echo "ERROR: Rootfs not found: $ROOTFS"
        exit 1
    fi
    if [[ "$ROOTFS" == *.cpio* || "$ROOTFS" == *.img.gz ]]; then
        QEMU_CMD+=(-initrd "$ROOTFS")
    elif [[ "$ROOTFS" == *.img || "$ROOTFS" == *.qcow2 ]]; then
        QEMU_CMD+=(-sd "$ROOTFS")
    else
        QEMU_CMD+=(-initrd "$ROOTFS")
    fi
fi

QEMU_CMD+=(-append "$APPEND")

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo " QEMU Zynq Emulation"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo " Machine : $MACHINE"
echo " Memory  : $MEMORY"
echo " Kernel  : $KERNEL"
[[ -n "$DTB" ]]    && echo " DTB     : $DTB"
[[ -n "$ROOTFS" ]] && echo " Rootfs  : $ROOTFS"
echo " Mode    : $($HEADLESS && echo "headless (timeout: ${TIMEOUT}s)" || echo "interactive")"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

if $HEADLESS; then
    # Headless mode: capture serial output, look for exit sentinel, enforce timeout.
    # The guest init script prints RR_QEMU_EXIT=<code> then powers off.
    SERIAL_LOG=$(mktemp /tmp/rr_qemu_serial_XXXXXX.log)
    trap "rm -f $SERIAL_LOG" EXIT

    # Replace stdio serial with file logging + nographic
    QEMU_CMD=("${QEMU_CMD[@]//mon:stdio/file:$SERIAL_LOG}")
    QEMU_CMD+=(-nographic)

    "${QEMU_CMD[@]}" &
    QEMU_PID=$!

    # Wait for sentinel or timeout
    ELAPSED=0
    EXIT_CODE=1
    while [[ $ELAPSED -lt $TIMEOUT ]]; do
        sleep 1
        ELAPSED=$((ELAPSED + 1))
        if [[ -f "$SERIAL_LOG" ]] && grep -q "RR_QEMU_EXIT=" "$SERIAL_LOG" 2>/dev/null; then
            EXIT_CODE=$(grep "RR_QEMU_EXIT=" "$SERIAL_LOG" | tail -1 | sed 's/.*RR_QEMU_EXIT=//')
            break
        fi
        # Check if QEMU exited on its own (kernel panic, poweroff)
        if ! kill -0 "$QEMU_PID" 2>/dev/null; then
            break
        fi
    done

    # Kill QEMU if still running
    if kill -0 "$QEMU_PID" 2>/dev/null; then
        kill "$QEMU_PID" 2>/dev/null
        wait "$QEMU_PID" 2>/dev/null || true
    fi

    # Print captured output
    if [[ -f "$SERIAL_LOG" ]]; then
        cat "$SERIAL_LOG"
    fi

    if [[ $ELAPSED -ge $TIMEOUT ]] && ! grep -q "RR_QEMU_EXIT=" "$SERIAL_LOG" 2>/dev/null; then
        echo ""
        echo "❌ QEMU timed out after ${TIMEOUT}s without test completion"
        exit 124
    fi

    exit "$EXIT_CODE"
else
    echo " Press Ctrl-A X to exit QEMU"
    echo ""
    exec "${QEMU_CMD[@]}"
fi
