# Master Makefile Include for RouteRTL Projects
# This file orchestrates the SDK build system by including focused fragments.

# --- Include directory (relative to this file) ---
SDK_MK_DIR := $(dir $(lastword $(MAKEFILE_LIST)))mk

# --- Domain-specific includes (order matters: platform first) ---
include $(SDK_MK_DIR)/platform.mk
include $(SDK_MK_DIR)/regbank.mk
include $(SDK_MK_DIR)/linux.mk
include $(SDK_MK_DIR)/sim.mk
include $(SDK_MK_DIR)/synthesis.mk
include $(SDK_MK_DIR)/dev.mk

# ====================================================================================
# 🛠️ Main Targets
# ====================================================================================
.PHONY: all help project synthesis implementation bitstream program clean
.DEFAULT_GOAL := help

# --- Deep Help Argument Interception ---
ifneq ($(filter help,$(MAKECMDGOALS)),)
  HELP_ARGS := $(filter-out help,$(MAKECMDGOALS))
  ifneq ($(HELP_ARGS),)
    _RUN_HELP := $(shell python3 $(SDK_ROOT)/sdk/engine/show_target_help.py $(HELP_ARGS) >&2)
    _DEEP_HELP_MODE := 1
    MAKEFLAGS += -s
  endif
endif

# If we are rendering deep help, skip evaluating the actual target recipes
ifndef _DEEP_HELP_MODE

all: bitstream

help:  ## Show available targets
	@echo "RouteRTL SDK Build System"
	@echo "Targets:"
	@grep -h -E '^[a-zA-Z_-]+:.*?## .*$$' $(MAKEFILE_LIST) | awk 'BEGIN {FS = ":.*?## "}; {printf "  \033[36m%-25s\033[0m %s\n", $$1, $$2}'

# --- Project Management ---
PROJECT_YML ?= project.yml
PROJECT_DIR ?= project
build_env.mk: $(PROJECT_YML)
	@python3 $(SDK_ROOT)/sdk/engine/project_manager.py $(PROJECT_YML)

# --- Environment ---
.PHONY: install
install: ## Install Python dependencies into .venv
	@if [ ! -d "$(ROOT_DIR)/.venv" ]; then \
		echo "⚠️  No .venv found at $(ROOT_DIR)/.venv. Creating one..."; \
		python3 -m venv $(ROOT_DIR)/.venv; \
	fi
	@echo "📦 Installing dependencies from requirements.txt..."
	@$(ROOT_DIR)/.venv/bin/python3 -m pip install -r $(ROOT_DIR)/requirements.txt
	@echo "📦 Installing RouteRTL SDK (CLI tools)..."
	@$(ROOT_DIR)/.venv/bin/python3 -m pip install -e $(SDK_ROOT) -q
	@echo "✅ Dependencies installed. 'rr' CLI is now available."
	@echo "👉 To activate the environment, run: source .venv/bin/activate"

.PHONY: check-env
check-env: ## Check SDK tool requirements and versions
	@python3 $(SDK_ROOT)/sdk/engine/check_env.py --generate-mk

.PHONY: update-config
update-config: ## Regenerate build_env.mk and build_env.tcl from project.yml
	@echo "🔄 Regenerating build configuration from $(PROJECT_YML)..."
	@python3 $(SDK_ROOT)/sdk/engine/project_manager.py $(PROJECT_YML)
	@echo "✅ build_env.mk updated."

# --- Linting ---
.PHONY: linting
linting: build_env.mk ## Run Smart Linting (Usage: make linting [TOP=top_module])
	@python3 $(SDK_ROOT)/sdk/engine/smart_linter.py \
		--root "$(ROOT_DIR)" \
		--pkgs "$(PKG_FILES)" \
		--xpm "$(XPM_FILES)" \
		--utils "$(UTILS_FILES)" \
		--src $(SRC_DIR) \
		$(if $(TOP),--top $(TOP),) \
		$(if $(HOOK_EXCLUDE_LINT),--exclude "$(HOOK_EXCLUDE_LINT)",) \
		$(if $(INCLUDE_DIRS),--include "$(INCLUDE_DIRS)",) \
		$(if $(DEFINES),--define "$(DEFINES)",)



view-sim-log: ## View the linting/simulation log
	@less -R sim/lint.log

# --- Git Hooks ---
.PHONY: install-hooks
install-hooks: ## Configure git to use SDK pre-commit hooks
	@if [ -f "$(SDK_HOOKS_DIR)/pre-commit" ]; then \
		git config core.hooksPath $(SDK_HOOKS_DIR); \
		echo "✅ Git hooks configured → $(SDK_HOOKS_DIR)"; \
	else \
		echo "❌ SDK hooks directory not found at $(SDK_HOOKS_DIR)"; \
		exit 1; \
	fi
# --- Maintenance ---
.PHONY: remove-sdk
remove-sdk: ## Remove the RouteRTL submodule
	@echo "⚠️  WARNING: This will completely remove $(SDK_SUBMODULE_PATH) and de-initialize it."
	@echo "    Your codebase will no longer compile until you restore it."
	@echo -n "    Are you sure? [y/N] " && read ans && [ "$${ans:-N}" = "y" ]
	@echo "Removing submodule..."
	-git submodule deinit -f $(SDK_SUBMODULE_PATH)
	-git rm -f $(SDK_SUBMODULE_PATH)
	-rm -rf .git/modules/$(SDK_SUBMODULE_PATH)
	@echo "✅ SDK removed. Please update your Makefile to remove the 'include' line."

update-sdk: ## Update the RouteRTL SDK submodule to the latest remote commit
	@echo "Updating RouteRTL SDK..."
	git submodule update --remote --merge $(SDK_SUBMODULE_PATH)
	@HASH=$$(cd $(SDK_SUBMODULE_PATH) && git rev-parse --short HEAD); \
	SUBJECT=$$(cd $(SDK_SUBMODULE_PATH) && git log -1 --pretty=%s); \
	echo "✅ SDK updated to latest remote version: [$$HASH] $$SUBJECT"

reinit-project: ## Wipe project artifacts (Makefile, project.yml) and re-initialize
	@echo "⚠️  WARNING: This will DELETE 'Makefile', '$(PROJECT_YML)', and build artifacts."
	@echo -n "    Are you sure? [y/N] " && read ans && [ "$${ans:-N}" = "y" ]
	@rm -f Makefile $(PROJECT_YML) build_env.mk build_env.tcl
	@rm -rf dcp $(PROJECT_DIR) sim_build
	@echo "♻️  Artifacts removed. Starting initialization..."
	@python3 $(SDK_ROOT)/sdk/engine/init_project.py

update-src: build_env.mk ## Scan source directories and add new synthesis files to project.yml
	@python3 $(SDK_ROOT)/sdk/engine/scan_sources.py --project $(PROJECT_YML) --src $(SRC_DIR)

update-sim: build_env.mk ## Scan simulation directories and add new testbenches to project.yml
	@python3 $(SDK_ROOT)/sdk/engine/scan_sources.py --project $(PROJECT_YML) --sim $(SIM_PATH)

update-dc: build_env.mk ## Scan constraints directory for vendor-specific design constraint files
	@python3 $(SDK_ROOT)/sdk/engine/scan_sources.py --project $(PROJECT_YML) --dc $(XDC_DIR) --vendor $(VENDOR)

update-xdc: update-dc ## (alias for update-dc — backward compatibility)

update-tcl: build_env.mk ## Scan TCL directory and add new hooks to project.yml
	@python3 $(SDK_ROOT)/sdk/engine/scan_sources.py --project $(PROJECT_YML) --tcl $(TCL_SCAN_DIR)

update-ips: build_env.mk ## Scan IP directories and update ip.yml source lists
	@python3 $(SDK_ROOT)/sdk/engine/scan_sources.py --project $(PROJECT_YML) --ip-update

update-all: build_env.mk ## Update all source lists (src, sim, constraints, tcl, ips)
	@python3 $(SDK_ROOT)/sdk/engine/scan_sources.py --project $(PROJECT_YML) --src $(SRC_DIR) --sim $(SIM_PATH) --dc $(XDC_DIR) --vendor $(VENDOR) --tcl $(TCL_SCAN_DIR) --ip-update

sources: ## Show current source file lists
	@echo "--- Project Source Manifest ---"
	@echo "Package Files (PKG_FILES):"
	@for f in $(PKG_FILES); do echo "  $$f"; done
	@echo ""
	@echo "Synthesis Files (SYN_FILES):"
	@for f in $(SYN_FILES); do echo "  $$f"; done
	@echo ""
	@echo "Simulation Files (SIM_FILES):"
	@for f in $(SIM_FILES); do echo "  $$f"; done
	@echo ""
	@echo "Constraint Files (XDC_FILES):"
	@for f in $(XDC_FILES); do echo "  $$f"; done
	@echo ""
	@echo "Linting Files (LIN_FILES):"
	@for f in $(LIN_FILES); do echo "  $$f"; done
	@echo ""
	@echo "Netlist Files (NETLIST_FILES):"
	@for f in $(NETLIST_FILES); do echo "  $$f"; done
	@echo ""
	@echo "OOC DCP Files (OOC_DCP_FILES):"
	@for f in $(OOC_DCP_FILES); do echo "  $$f"; done
	@echo "-------------------------------"

.PHONY: hierarchy
hierarchy: ## Show VHDL/Verilog dependency tree (Usage: make hierarchy TOP=top_module)
	@if [ -z "$(TOP)" ]; then \
		echo "❌ Error: TOP not specified. Use 'make hierarchy TOP=my_entity'"; \
		exit 1; \
	fi
	@python3 $(SDK_ROOT)/sdk/engine/dependency_resolver.py --src $(SRC_DIR) --top $(TOP)

project: clean update-config check-lfs pre-build $(REGBANK_DEPS) build-project ## Generate FPGA Project

program: ## Program FPGA device with generated bitstream
	@echo "🚀 Programming FPGA device..."
	@$(TCL_RUN) $(SDK_ROOT)/tcl/$(VENDOR_DIR)/gen_program.tcl $(TCL_FLAG) $(ROOT_DIR)

clean: ## Clean build artifacts
	rm -rf dcp $(PROJECT_DIR) sim_build __pycache__ .pytest_cache .deps.ok
	rm -rf *.qpf *.qsf *.qws *.bak *.smsg *.rpt *.summary *.pin *.done *.jdi *.sld *.sldq *.slds
	rm -rf db incremental_db
	@echo "Cleaned."

else

# When in deep help mode, provide a catch-all rule to cleanly execute do-nothing targets
%::
	@:

endif
