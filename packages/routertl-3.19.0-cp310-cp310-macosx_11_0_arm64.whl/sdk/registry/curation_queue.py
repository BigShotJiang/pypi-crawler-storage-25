#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Curation queue for registry entries the LLM can't rescue (RTL-P2.375).

Catalogues (namespace, name) pairs whose descriptions persistently fail
the rubric (R10 generic-verb-lead, R11 malformed English, synonym gap,
etc.) even after N rewrite attempts across multiple providers. Audit
and rewrite pipelines consult this queue to skip quarantined entries,
keeping the "suspect" count focused on actionable issues.

Design choices:

* **Not a deletion** — the entry stays in the catalog with whatever
  baseline description it has. The queue only hides it from audit
  reports; users can still ``rr pkg add`` and install it.
* **Expires** — every queued entry has a default 90-day TTL. When it
  expires, the next audit re-attempts a rewrite. Expiry is how the
  queue self-heals: if an LLM improves (or a new rubric rule relaxes),
  stale quarantines fall out automatically.
* **Human override is resolve** — the only way to permanently fix a
  queued entry is to ``curation-queue remove`` it AND land a better
  description via the normal rewrite / apply pipeline. The queue itself
  never writes descriptions.

File format (``sdk/registry/curation_queue.yml``):

    _schema: curation_queue/v1
    _doc: "..."
    entries:
      - namespace: analog-devices
        name: axi_ad9265_channel
        reason: R10-generic-verb-lead
        attempts: 3
        last_provider: anthropic
        queued_at: 2026-04-21
        expires_at: 2026-07-20
        notes: "*_channel cluster — LLM can't pass R10 for this family"

Usage — library::

    from sdk.registry.curation_queue import CurationQueue
    q = CurationQueue.load()
    if q.is_quarantined("analog-devices", "axi_ad9265_channel"):
        continue  # skip in audit

Usage — CLI::

    python -m sdk.registry.curation_queue list
    python -m sdk.registry.curation_queue add --ns analog-devices \\
        --name axi_ad9265_channel --reason R10-generic-verb-lead \\
        --attempts 3 --provider anthropic \\
        --notes "*_channel cluster"
    python -m sdk.registry.curation_queue remove \\
        --ns analog-devices --name axi_ad9265_channel
    python -m sdk.registry.curation_queue prune-expired
"""

from __future__ import annotations

import argparse
import sys
from dataclasses import dataclass, field
from datetime import date, timedelta
from pathlib import Path
from typing import Iterable

SCRIPT_DIR = Path(__file__).resolve().parent
DEFAULT_QUEUE_PATH = SCRIPT_DIR / "curation_queue.yml"
DEFAULT_TTL_DAYS = 90

SCHEMA_VERSION = "curation_queue/v1"


@dataclass
class QueueEntry:
    namespace: str
    name: str
    reason: str
    attempts: int = 1
    last_provider: str | None = None
    queued_at: date = field(default_factory=date.today)
    expires_at: date | None = None
    notes: str | None = None

    def key(self) -> tuple[str, str]:
        return (self.namespace, self.name)

    def is_expired(self, today: date | None = None) -> bool:
        if self.expires_at is None:
            return False
        return (today or date.today()) >= self.expires_at

    def to_yaml_dict(self) -> dict:
        d: dict = {
            "namespace": self.namespace,
            "name": self.name,
            "reason": self.reason,
            "attempts": self.attempts,
            "queued_at": self.queued_at.isoformat(),
        }
        if self.last_provider:
            d["last_provider"] = self.last_provider
        if self.expires_at:
            d["expires_at"] = self.expires_at.isoformat()
        if self.notes:
            d["notes"] = self.notes
        return d

    @classmethod
    def from_yaml_dict(cls, data: dict) -> "QueueEntry":
        return cls(
            namespace=data["namespace"],
            name=data["name"],
            reason=data["reason"],
            attempts=int(data.get("attempts", 1)),
            last_provider=data.get("last_provider"),
            queued_at=_parse_date(data.get("queued_at")) or date.today(),
            expires_at=_parse_date(data.get("expires_at")),
            notes=data.get("notes"),
        )


def _parse_date(value: object) -> date | None:
    if value is None:
        return None
    if isinstance(value, date):
        return value
    return date.fromisoformat(str(value))


class CurationQueue:
    """In-memory curation queue with YAML persistence."""

    def __init__(self, entries: Iterable[QueueEntry] | None = None):
        self._by_key: dict[tuple[str, str], QueueEntry] = {}
        for entry in entries or ():
            self._by_key[entry.key()] = entry

    # ── persistence ──────────────────────────────────────────────

    @classmethod
    def load(cls, path: Path | None = None) -> "CurationQueue":
        path = path or DEFAULT_QUEUE_PATH
        if not path.is_file():
            return cls()
        import yaml
        data = yaml.safe_load(path.read_text()) or {}
        if data.get("_schema") and data["_schema"] != SCHEMA_VERSION:
            raise ValueError(
                f"curation_queue schema mismatch: got {data['_schema']}, "
                f"expected {SCHEMA_VERSION}",
            )
        raw_entries = data.get("entries") or []
        return cls(QueueEntry.from_yaml_dict(e) for e in raw_entries)

    def save(self, path: Path | None = None) -> None:
        path = path or DEFAULT_QUEUE_PATH
        import yaml
        # Sort for deterministic diffs.
        sorted_entries = sorted(
            self._by_key.values(),
            key=lambda e: (e.namespace, e.name),
        )
        payload = {
            "_schema": SCHEMA_VERSION,
            "_doc": (
                "Curation queue — entries whose descriptions persistently "
                "fail the rubric. Skipped in audit reports. 90-day TTL so "
                "the queue self-heals when rubric or LLM quality improves."
            ),
            "entries": [e.to_yaml_dict() for e in sorted_entries],
        }
        path.write_text(yaml.dump(payload, sort_keys=False, default_flow_style=False))

    # ── queries ──────────────────────────────────────────────────

    def is_quarantined(self, namespace: str, name: str) -> bool:
        entry = self._by_key.get((namespace, name))
        if entry is None:
            return False
        return not entry.is_expired()

    def get(self, namespace: str, name: str) -> QueueEntry | None:
        return self._by_key.get((namespace, name))

    def list_entries(self, namespace: str | None = None) -> list[QueueEntry]:
        entries = sorted(
            self._by_key.values(),
            key=lambda e: (e.namespace, e.name),
        )
        if namespace:
            entries = [e for e in entries if e.namespace == namespace]
        return entries

    def __len__(self) -> int:
        return len(self._by_key)

    # ── mutations ────────────────────────────────────────────────

    def add(
        self,
        namespace: str,
        name: str,
        reason: str,
        *,
        attempts: int = 1,
        last_provider: str | None = None,
        notes: str | None = None,
        ttl_days: int | None = DEFAULT_TTL_DAYS,
        queued_at: date | None = None,
    ) -> QueueEntry:
        """Upsert an entry. When the (ns, name) already exists, increments
        attempts and refreshes the TTL — repeated failures push the
        expiry out, so recurring offenders don't oscillate in and out of
        the queue. Passing ttl_days=None disables expiry."""
        key = (namespace, name)
        today = queued_at or date.today()
        expires = None if ttl_days is None else today + timedelta(days=ttl_days)

        existing = self._by_key.get(key)
        if existing is not None:
            existing.attempts += 1
            existing.reason = reason  # reflect latest reason
            existing.last_provider = last_provider or existing.last_provider
            existing.expires_at = expires
            if notes:
                existing.notes = notes
            return existing

        entry = QueueEntry(
            namespace=namespace,
            name=name,
            reason=reason,
            attempts=attempts,
            last_provider=last_provider,
            queued_at=today,
            expires_at=expires,
            notes=notes,
        )
        self._by_key[key] = entry
        return entry

    def remove(self, namespace: str, name: str) -> bool:
        return self._by_key.pop((namespace, name), None) is not None

    def prune_expired(self, today: date | None = None) -> list[QueueEntry]:
        """Drop expired entries; return the evicted list."""
        today = today or date.today()
        evicted = [e for e in self._by_key.values() if e.is_expired(today)]
        for e in evicted:
            del self._by_key[e.key()]
        return evicted


# ── CLI ──────────────────────────────────────────────────────────


def _cli_list(args: argparse.Namespace) -> int:
    q = CurationQueue.load(args.queue)
    entries = q.list_entries(namespace=args.namespace)
    if not entries:
        print(f"(queue empty{' for ' + args.namespace if args.namespace else ''})")
        return 0
    print(f"{'NAMESPACE':20}  {'NAME':40}  {'REASON':24}  ATTEMPTS  EXPIRES")
    for e in entries:
        exp = e.expires_at.isoformat() if e.expires_at else "never"
        print(
            f"{e.namespace:20}  {e.name:40}  {e.reason:24}  "
            f"{e.attempts:>8}  {exp}",
        )
    print(f"\n{len(entries)} entry(ies)")
    return 0


def _cli_add(args: argparse.Namespace) -> int:
    q = CurationQueue.load(args.queue)
    entry = q.add(
        namespace=args.ns,
        name=args.name,
        reason=args.reason,
        attempts=args.attempts,
        last_provider=args.provider,
        notes=args.notes,
        ttl_days=args.ttl,
    )
    q.save(args.queue)
    print(f"Queued {entry.namespace}/{entry.name} — reason={entry.reason} "
          f"attempts={entry.attempts} expires={entry.expires_at or 'never'}")
    return 0


def _cli_remove(args: argparse.Namespace) -> int:
    q = CurationQueue.load(args.queue)
    if q.remove(args.ns, args.name):
        q.save(args.queue)
        print(f"Removed {args.ns}/{args.name} from queue")
        return 0
    print(f"Not in queue: {args.ns}/{args.name}", file=sys.stderr)
    return 1


def _cli_prune(args: argparse.Namespace) -> int:
    q = CurationQueue.load(args.queue)
    evicted = q.prune_expired()
    if evicted:
        q.save(args.queue)
    print(f"Evicted {len(evicted)} expired entry(ies):")
    for e in evicted:
        print(f"  {e.namespace}/{e.name} (expired {e.expires_at})")
    return 0


def _cli_is_quarantined(args: argparse.Namespace) -> int:
    q = CurationQueue.load(args.queue)
    quarantined = q.is_quarantined(args.ns, args.name)
    print("yes" if quarantined else "no")
    return 0 if quarantined else 1


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    p.add_argument("--queue", type=Path, default=DEFAULT_QUEUE_PATH,
                   help=f"Queue YAML path (default: {DEFAULT_QUEUE_PATH})")
    sub = p.add_subparsers(dest="cmd", required=True)

    lp = sub.add_parser("list", help="Show queue contents")
    lp.add_argument("--namespace", default=None)
    lp.set_defaults(func=_cli_list)

    ap = sub.add_parser("add", help="Queue a (ns, name) as unfixable")
    ap.add_argument("--ns", required=True)
    ap.add_argument("--name", required=True)
    ap.add_argument("--reason", required=True,
                    help="Rubric rule id or short phrase (e.g. R10-generic-verb-lead)")
    ap.add_argument("--attempts", type=int, default=1)
    ap.add_argument("--provider", default=None)
    ap.add_argument("--notes", default=None)
    ap.add_argument("--ttl", type=int, default=DEFAULT_TTL_DAYS,
                    help=f"Expiry in days (default: {DEFAULT_TTL_DAYS}, 0 = never)")
    ap.set_defaults(func=_cli_add)

    rp = sub.add_parser("remove", help="Remove a (ns, name) from the queue")
    rp.add_argument("--ns", required=True)
    rp.add_argument("--name", required=True)
    rp.set_defaults(func=_cli_remove)

    pp = sub.add_parser("prune-expired", help="Drop expired entries")
    pp.set_defaults(func=_cli_prune)

    qp = sub.add_parser(
        "is-quarantined",
        help="Exit 0 if (ns, name) is quarantined, 1 otherwise",
    )
    qp.add_argument("--ns", required=True)
    qp.add_argument("--name", required=True)
    qp.set_defaults(func=_cli_is_quarantined)

    args = p.parse_args(argv)
    # Normalise ttl=0 → None (disables expiry).
    if getattr(args, "ttl", None) == 0:
        args.ttl = None
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
