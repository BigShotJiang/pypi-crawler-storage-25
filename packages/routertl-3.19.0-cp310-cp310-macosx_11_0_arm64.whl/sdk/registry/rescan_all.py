#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Batch re-scan all curated repos and generate a fresh catalog.

Reads curated_repos.json, scans each non-skipped repo with the
configured granularity, and outputs a unified catalog.json plus
per-package YAMLs in the index directory structure.

Usage:
    python -m sdk.registry.rescan_all --output /tmp/fresh-index
    python -m sdk.registry.rescan_all --output /tmp/fresh-index --namespace open-logic
    python -m sdk.registry.rescan_all --output /tmp/fresh-index --dry-run

Architecture: D.43 layer 1 (curated overrides).
Backlog: RTL-P2.305.
"""

import argparse
import json
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
SDK_ROOT = SCRIPT_DIR.parent.parent
sys.path.insert(0, str(SDK_ROOT))

from routertl_core.ip_scanner import (  # noqa: E402
    format_llm_summary,
    get_llm_stats,
    load_description_verdicts,
    reset_llm_session,
)
from sdk.scripts.scan_ip_repo import _clone_at_tag, _scan_repo  # noqa: E402

_VALID_PROVIDERS = {"groq", "gemini", "anthropic"}


def load_curated() -> dict:
    config_path = SCRIPT_DIR / "curated_repos.json"
    return json.loads(config_path.read_text())


def _git_last_commit_for_files(
    clone_dir: Path,
    files: list[str],
    fallback_sha: str,
    fallback_time: str,
) -> tuple[str, str]:
    """Return ``(full_sha, iso_commit_time)`` for the most recent commit that
    touched any of ``files`` inside ``clone_dir``.

    Anti-pollution (RTL-P1.54): super-repos like open-logic house hundreds
    of independent IPs in one repo. Pinning every entity to the repo HEAD
    sha causes spurious version bumps on unrelated IPs every time ANY file
    in the repo changes. Per-package sha means a new version row lands in
    the registry only when the specific IP's source actually moved.

    Falls back to the repo-level sha/time when ``git log`` finds nothing
    (e.g. --depth 1 clone hiding history, or untracked files).
    """
    if not files:
        return fallback_sha, fallback_time
    try:
        res = subprocess.run(
            ["git", "-C", str(clone_dir), "log", "-1",
             "--format=%H%x1f%cI", "--", *files],
            capture_output=True, text=True, check=True,
        )
        out = res.stdout.strip()
        if not out:
            return fallback_sha, fallback_time
        sha, _, when = out.partition("\x1f")
        if not sha or not when:
            return fallback_sha, fallback_time
        return sha, when
    except subprocess.CalledProcessError:
        return fallback_sha, fallback_time


def _git_head_commit_time(clone_dir: Path) -> str:
    """Return ISO-8601 commit time of HEAD in ``clone_dir``.

    Used as the repo-level fallback when a package's file list is empty or
    when ``git log`` returns nothing for those files.
    """
    res = subprocess.run(
        ["git", "-C", str(clone_dir), "log", "-1", "--format=%cI", "HEAD"],
        capture_output=True, text=True, check=True,
    )
    return res.stdout.strip()


def _short_sha(full_sha: str) -> str:
    """Return a 12-character short sha — stable, pinnable, urlable."""
    return full_sha[:12]


def _build_catalog_entry(
    *,
    namespace: str,
    name: str,
    version: str,
    commit_sha: str,
    published_at: str,
    entry: dict,
) -> dict:
    """Pure builder for a catalog.json entry with HEAD-pinned version
    metadata (RTL-P1.54).

    ``entry`` is the scanner's per-package output (description, license,
    source, tags, role, routertl_compat …). The returned dict merges
    scanner fields with the HEAD-pinning additions:
      * ``versions: [version]`` — so seed.py creates a package_versions row
      * ``latest: version`` — what `rr pkg add ns/name` resolves to
      * ``published_at`` — git commit time for updated_at semantics
      * ``commit_sha`` — full sha for traceability
    """
    cat_entry = {
        "namespace": namespace,
        "name": name,
        "latest": version,
        "versions": [version],
        "commit_sha": commit_sha,
        "published_at": published_at,
        "description": entry.get("description", ""),
        "license": entry.get("license", ""),
        "license_class": entry.get("license_class", "unknown"),
        "language": entry.get("routertl_compat", {}).get("language"),
        "source_url": entry.get("source", {}).get("url", ""),
        "tags": entry.get("tags", []),
        "role": entry.get("role", "top"),
    }
    if entry.get("top_modules"):
        cat_entry["top_modules"] = entry["top_modules"]
    if entry.get("components"):
        cat_entry["components"] = entry["components"]
    return cat_entry


def _build_package_yaml(
    *,
    namespace: str,
    name: str,
    version: str,
    commit_sha: str,
    published_at: str,
    entry: dict,
) -> dict:
    """Pure builder for the per-package ``index/packages/<ns>/<name>/<ver>.yml``
    payload. Mirrors the catalog fields but carries the full routertl_compat
    block (files, library, deps) that seed.py reads for package_versions.
    """
    src = dict(entry.get("source", {}))
    src["resolved_commit"] = commit_sha
    yaml_data = {
        "name": name,
        "namespace": namespace,
        "version": version,
        "commit_sha": commit_sha,
        "published_at": published_at,
        "description": entry.get("description", ""),
        "license": entry.get("license", ""),
        "license_class": entry.get("license_class", "unknown"),
        "source": src,
        "routertl_compat": entry.get("routertl_compat", {}),
        "tags": entry.get("tags", []),
        "role": entry.get("role", "top"),
    }
    if entry.get("top_modules"):
        yaml_data["top_modules"] = entry["top_modules"]
    if entry.get("components"):
        yaml_data["components"] = entry["components"]
    if entry.get("total_entities"):
        yaml_data["total_entities"] = entry["total_entities"]
    return yaml_data


def _load_previous_descriptions(
    previous_catalog: Path | None,
) -> dict[str, dict[str, str]]:
    """Return ``{namespace: {name: description}}`` from an existing catalog.

    Used by rescan_all to pass previous_descriptions into scan_repo so
    the scanner can preserve clean descriptions on LLM fallthrough
    (RTL-P2.380). Missing file → empty dict.
    """
    if previous_catalog is None or not previous_catalog.is_file():
        return {}
    data = json.loads(previous_catalog.read_text())
    out: dict[str, dict[str, str]] = {}
    for entry in data:
        ns = entry.get("namespace")
        name = entry.get("name")
        desc = entry.get("description") or ""
        if ns and name and desc:
            out.setdefault(ns, {})[name] = desc
    return out


def rescan_all(
    output_dir: Path,
    namespace_filter: str | None = None,
    dry_run: bool = False,
    no_llm: bool = True,
    previous_catalog: Path | None = None,
    verdicts_dir: Path | None = None,
) -> dict:
    """Scan all curated repos and write index files.

    Returns stats dict including ``llm_stats`` — per-provider outcome
    counters recorded during the run (RTL-P2.372) — and
    ``desc_sources`` — a tier breakdown (header/ports/llm/preserved/
    auto) across all scanned entries (RTL-P2.380).
    """
    config = load_curated()
    repos = config.get("repos", {})

    # Reset LLM session state so a previous rescan's 403 on Groq doesn't
    # silently suppress the current run (RTL-P2.372).
    reset_llm_session()

    previous_by_ns = _load_previous_descriptions(previous_catalog)

    # RTL-P2.399: curator-locked descriptions from the ip-index's
    # descriptions_verdicts.json (if present). verdicts_dir defaults to
    # the parent of previous_catalog (the ip-index root) so the common
    # --previous-catalog path auto-discovers verdicts without an extra
    # flag. Empty when no file exists.
    verdicts_root = verdicts_dir or (
        previous_catalog.parent if previous_catalog else None
    )
    verdicts = load_description_verdicts(verdicts_root)
    if verdicts:
        print(f"Loaded {len(verdicts)} curator verdicts from "
              f"{verdicts_root}/descriptions_verdicts.json")

    stats = {
        "scanned": 0, "skipped": 0, "failed": 0,
        "total_entries": 0, "namespaces": set(),
        "desc_sources": {
            "header": 0, "ports": 0, "llm": 0,
            "preserved": 0, "auto": 0, "verdict": 0,
        },
    }

    all_catalog: list[dict] = []

    for url, repo_config in repos.items():
        namespace = repo_config.get("namespace", "unknown")

        # Skip repos marked as _skip
        if namespace == "_skip":
            print(f"  SKIP  {url} — {repo_config.get('notes', 'blocked')[:60]}")
            stats["skipped"] += 1
            continue

        # Namespace filter
        if namespace_filter and namespace != namespace_filter:
            continue

        granularity = repo_config.get("granularity", "top")
        tag = repo_config.get("last_tag") or "main"

        print(f"\n{'='*70}")
        print(f"  SCAN  {url}")
        print(f"        namespace={namespace}  granularity={granularity}  tag={tag}")

        if dry_run:
            stats["scanned"] += 1
            continue

        # Clone
        clone_dir = Path(tempfile.mkdtemp(prefix="rr_rescan_"))
        try:
            commit = _clone_at_tag(url, tag, clone_dir)
            print(f"        cloned at {commit[:8]}")

            # Repo-level published_at is the commit time of the cloned HEAD.
            # Used as the fallback when a specific package's file list is
            # empty or git log returns nothing for it.
            repo_published_at = _git_head_commit_time(clone_dir)

            # Scan — pass the live catalog's subset for this namespace
            # so the scanner can preserve clean descriptions instead of
            # downgrading to R7 filler on LLM fallthrough (RTL-P2.380).
            previous_descriptions = previous_by_ns.get(namespace)

            entries = _scan_repo(
                clone_dir, namespace, url, tag, commit,
                use_llm=not no_llm,
                granularity=granularity,
                previous_descriptions=previous_descriptions,
                description_verdicts=verdicts,
            )

            # Roll up per-tier source counts for the summary.
            for entry in entries:
                src = entry.get("desc_source")
                if src in stats["desc_sources"]:
                    stats["desc_sources"][src] += 1

            # Apply license_override from curated config (D.43)
            license_override = repo_config.get("license_override")
            if license_override:
                from routertl_core.ip_scanner import classify_license
                for e in entries:
                    e["license"] = license_override
                    e["license_class"] = classify_license(license_override)
                print(f"        license_override: {license_override}")

            print(f"        {len(entries)} entries")

            # Build per-package (version, commit_sha, published_at) trios.
            # For tagged repos (tag != 'main') we keep the semver-ish tag
            # name and pin to the repo HEAD — tagged snapshots describe the
            # whole repo. For main-branch scans we pin each package to the
            # commit that last touched its files (anti-pollution: avoids
            # spurious bumps on super-repos like open-logic).
            package_pins: dict[str, tuple[str, str, str]] = {}
            for e in entries:
                if tag != "main":
                    pin_sha = commit
                    pin_time = repo_published_at
                    version = tag.lstrip("v")
                else:
                    files = e.get("routertl_compat", {}).get("files", []) or []
                    pin_sha, pin_time = _git_last_commit_for_files(
                        clone_dir, files, commit, repo_published_at,
                    )
                    version = _short_sha(pin_sha)
                package_pins[e["name"]] = (version, pin_sha, pin_time)

            # Write per-package YAMLs
            if output_dir:
                import yaml
                for e in entries:
                    version, pin_sha, pin_time = package_pins[e["name"]]
                    pkg_dir = output_dir / "packages" / namespace / e["name"]
                    pkg_dir.mkdir(parents=True, exist_ok=True)

                    yaml_data = _build_package_yaml(
                        namespace=namespace,
                        name=e["name"],
                        version=version,
                        commit_sha=pin_sha,
                        published_at=pin_time,
                        entry=e,
                    )
                    yml_path = pkg_dir / f"{version}.yml"
                    with open(yml_path, "w") as f:
                        yaml.dump(yaml_data, f, default_flow_style=False, sort_keys=False)

                    # RTL-P2.381: keep HEAD.yml as a floating alias for
                    # main-branch scans so the CLI's --commit HEAD install
                    # path keeps working. Body is the same YAML with
                    # version='HEAD' for compat with existing consumers.
                    if tag == "main":
                        head_data = dict(yaml_data)
                        head_data["version"] = "HEAD"
                        head_path = pkg_dir / "HEAD.yml"
                        with open(head_path, "w") as f:
                            yaml.dump(head_data, f, default_flow_style=False, sort_keys=False)

            # Add to catalog (per-package version + published_at + commit_sha)
            for e in entries:
                version, pin_sha, pin_time = package_pins[e["name"]]
                all_catalog.append(_build_catalog_entry(
                    namespace=namespace,
                    name=e["name"],
                    version=version,
                    commit_sha=pin_sha,
                    published_at=pin_time,
                    entry=e,
                ))

            stats["scanned"] += 1
            stats["total_entries"] += len(entries)
            stats["namespaces"].add(namespace)

        except (OSError, RuntimeError, ValueError, KeyError) as exc:
            print(f"        FAILED: {exc}")
            stats["failed"] += 1
        finally:
            shutil.rmtree(clone_dir, ignore_errors=True)

    # Write unified catalog.json
    if output_dir and not dry_run:
        cat_path = output_dir / "catalog.json"
        with open(cat_path, "w") as f:
            json.dump(all_catalog, f, indent=2)
        print(f"\n{'='*70}")
        print(f"Catalog written: {cat_path}")
        print(f"  {len(all_catalog)} entries across {len(stats['namespaces'])} namespaces")

    stats["namespaces"] = list(stats["namespaces"])
    stats["llm_stats"] = get_llm_stats()
    return stats


def main():
    parser = argparse.ArgumentParser(
        description="Batch re-scan all curated repos into a fresh index"
    )
    parser.add_argument("--output", "-o", required=True,
                        help="Output directory for catalog.json + package YAMLs")
    parser.add_argument("--namespace", "-n", default=None,
                        help="Only scan one namespace")
    parser.add_argument("--dry-run", action="store_true",
                        help="List repos but don't scan")
    parser.add_argument("--no-llm", action="store_true", default=False,
                        help="Disable LLM descriptions (default: LLM enabled)")
    parser.add_argument("--pace", type=float, default=0.0,
                        help="Seconds to sleep after each LLM call to avoid "
                             "per-minute rate limits (default: 0, no pacing). "
                             "Typical: 0.3–0.5 for bursty namespace rescans.")
    parser.add_argument("--provider-chain", default=None,
                        help="Comma-separated LLM provider order — e.g. "
                             "'anthropic' (paid-only), 'groq,gemini' (free-only). "
                             "Default: groq,gemini,anthropic. Unknown names are "
                             "dropped.")
    parser.add_argument("--previous-catalog", type=Path, default=None,
                        help="Path to the live catalog.json. When set, the "
                             "scanner preserves clean existing descriptions "
                             "instead of downgrading to the 'ns IP: name' "
                             "filler on LLM-tier fallthrough (RTL-P2.380).")
    parser.add_argument("--verdicts-dir", type=Path, default=None,
                        help="Directory containing descriptions_verdicts.json. "
                             "Defaults to the parent of --previous-catalog "
                             "(i.e. the ip-index root) when that flag is set. "
                             "verdict=good entries bypass every scanner tier "
                             "and emit the locked_text verbatim (RTL-P2.399).")
    args = parser.parse_args()

    # Forward pace + provider-chain to the scanner via env vars. Threaded
    # this way so Cython-compiled ip_scanner doesn't need new kwargs
    # (RTL-P2.372).
    if args.pace > 0:
        os.environ["ROUTERTL_LLM_PACE"] = str(args.pace)
    if args.provider_chain:
        chain = [
            p.strip().lower()
            for p in args.provider_chain.split(",")
            if p.strip().lower() in _VALID_PROVIDERS
        ]
        if not chain:
            parser.error(
                f"--provider-chain had no recognised providers "
                f"(valid: {sorted(_VALID_PROVIDERS)})",
            )
        os.environ["ROUTERTL_LLM_PROVIDERS"] = ",".join(chain)
        print(f"LLM provider chain: {', '.join(chain)}")
    if args.pace > 0:
        print(f"LLM pacing: {args.pace}s between calls")

    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)

    if args.previous_catalog:
        print(f"Non-downgrade mode: reading live descriptions from {args.previous_catalog}")

    stats = rescan_all(
        output, args.namespace, args.dry_run, args.no_llm,
        previous_catalog=args.previous_catalog,
        verdicts_dir=args.verdicts_dir,
    )

    print(f"\nDone: {stats['scanned']} scanned, {stats['skipped']} skipped, "
          f"{stats['failed']} failed, {stats['total_entries']} total entries")

    # Tier breakdown (RTL-P2.380 surfaces 'preserved').
    srcs = stats.get("desc_sources") or {}
    if any(srcs.values()):
        print("Description sources:")
        for tier in ("verdict", "header", "ports", "llm", "preserved", "auto"):
            n = srcs.get(tier, 0)
            if n:
                print(f"  {tier}: {n}")

    print(format_llm_summary(stats.get("llm_stats")))


if __name__ == "__main__":
    main()
