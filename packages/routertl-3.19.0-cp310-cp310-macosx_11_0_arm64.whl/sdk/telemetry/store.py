# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""SQLite-backed local telemetry store.

All data lives in ``~/.routertl/telemetry.db``.
The store is entirely fire-and-forget — errors are logged at DEBUG and
never propagate to the caller.
"""

from __future__ import annotations

import json
import logging
import sqlite3
from datetime import datetime
from pathlib import Path
from typing import List, Optional

from sdk.cli.resilience import cli_resilient_block
from sdk.telemetry.events import TelemetryEvent

logger = logging.getLogger(__name__)

# ── Default DB location ──────────────────────────────────────
_DEFAULT_DB_DIR = Path.home() / ".routertl"
_DEFAULT_DB_PATH = _DEFAULT_DB_DIR / "telemetry.db"

_SCHEMA = """\
CREATE TABLE IF NOT EXISTS events (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    command     TEXT    NOT NULL,
    subcommand  TEXT,
    timestamp   TEXT    NOT NULL,
    duration_ms INTEGER NOT NULL DEFAULT 0,
    exit_code   INTEGER NOT NULL DEFAULT 0,
    sdk_version TEXT    NOT NULL DEFAULT '',
    project     TEXT
);
CREATE INDEX IF NOT EXISTS idx_events_timestamp ON events(timestamp);
CREATE INDEX IF NOT EXISTS idx_events_command   ON events(command);
"""

_TEST_RESULTS_SCHEMA = """\
CREATE TABLE IF NOT EXISTS test_results (
    id       INTEGER PRIMARY KEY AUTOINCREMENT,
    date     TEXT    NOT NULL,
    passed   INTEGER NOT NULL DEFAULT 0,
    failed   INTEGER NOT NULL DEFAULT 0,
    skipped  INTEGER NOT NULL DEFAULT 0,
    suite    TEXT    NOT NULL DEFAULT '',
    project  TEXT
);
CREATE INDEX IF NOT EXISTS idx_test_results_date ON test_results(date);
"""


class TelemetryStore:
    """Lightweight SQLite store for telemetry events.

    Args:
        db_path: Override the default ``~/.routertl/telemetry.db`` path.
                 Pass ``\":memory:\"`` for tests.
    """

    def __init__(self, db_path: Optional[Path | str] = None):
        self._db_path = str(db_path) if db_path else str(_DEFAULT_DB_PATH)
        self._conn: Optional[sqlite3.Connection] = None
        self._ensure_schema()

    # ── Public API ────────────────────────────────────────────

    def record(self, event: TelemetryEvent) -> None:
        """Insert a telemetry event into the store."""
        with cli_resilient_block("telemetry record"):
            conn = self._get_conn()
            conn.execute(
                "INSERT INTO events (command, subcommand, timestamp, duration_ms, "
                "exit_code, sdk_version, project) VALUES (?, ?, ?, ?, ?, ?, ?)",
                (
                    event.command,
                    event.subcommand,
                    event.timestamp,
                    event.duration_ms,
                    event.exit_code,
                    event.sdk_version,
                    event.project,
                ),
            )
            conn.commit()

    def record_test_result(
        self,
        date: str,
        passed: int,
        failed: int,
        skipped: int,
        suite: str = "",
        project: Optional[str] = None,
    ) -> None:
        """Insert a test result summary."""
        with cli_resilient_block("telemetry test result record"):
            conn = self._get_conn()
            conn.execute(
                "INSERT INTO test_results (date, passed, failed, skipped, suite, project) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                (date, passed, failed, skipped, suite, project),
            )
            conn.commit()

    def query_events(
        self,
        since: Optional[datetime] = None,
        until: Optional[datetime] = None,
    ) -> List[TelemetryEvent]:
        """Query events within a time range."""
        with cli_resilient_block("telemetry query"):
            conn = self._get_conn()
            sql = "SELECT command, subcommand, timestamp, duration_ms, exit_code, sdk_version, project FROM events"
            params: list = []
            clauses: list = []

            if since:
                clauses.append("timestamp >= ?")
                params.append(since.isoformat())
            if until:
                clauses.append("timestamp <= ?")
                params.append(until.isoformat())

            if clauses:
                sql += " WHERE " + " AND ".join(clauses)
            sql += " ORDER BY timestamp ASC"

            rows = conn.execute(sql, params).fetchall()
            return [
                TelemetryEvent(
                    command=r[0],
                    subcommand=r[1],
                    timestamp=r[2],
                    duration_ms=r[3],
                    exit_code=r[4],
                    sdk_version=r[5],
                    project=r[6],
                )
                for r in rows
            ]
        return []

    def query_test_results(
        self,
        since: Optional[datetime] = None,
        until: Optional[datetime] = None,
    ) -> list[dict]:
        """Query test results within a time range."""
        with cli_resilient_block("telemetry test results query"):
            conn = self._get_conn()
            sql = "SELECT date, passed, failed, skipped, suite, project FROM test_results"
            params: list = []
            clauses: list = []

            if since:
                clauses.append("date >= ?")
                params.append(since.strftime("%Y-%m-%d"))
            if until:
                clauses.append("date <= ?")
                params.append(until.strftime("%Y-%m-%d"))

            if clauses:
                sql += " WHERE " + " AND ".join(clauses)
            sql += " ORDER BY date ASC"

            rows = conn.execute(sql, params).fetchall()
            return [
                {"date": r[0], "passed": r[1], "failed": r[2], "skipped": r[3], "suite": r[4], "project": r[5]}
                for r in rows
            ]
        return []

    def export_json(
        self,
        since: Optional[datetime] = None,
        until: Optional[datetime] = None,
    ) -> str:
        """Export events and test results as a JSON string for push."""
        events = self.query_events(since, until)
        test_results = self.query_test_results(since, until)
        payload = {
            "events": [e.to_dict() for e in events],
            "test_results": test_results,
        }
        return json.dumps(payload, indent=2)

    def summary(self) -> dict:
        """Return a quick summary of stored telemetry data."""
        with cli_resilient_block("telemetry summary"):
            conn = self._get_conn()
            total = conn.execute("SELECT COUNT(*) FROM events").fetchone()[0]
            commands = conn.execute(
                "SELECT command, COUNT(*) as cnt FROM events GROUP BY command ORDER BY cnt DESC LIMIT 10"
            ).fetchall()
            test_total = conn.execute("SELECT COUNT(*) FROM test_results").fetchone()[0]
            return {
                "total_events": total,
                "total_test_results": test_total,
                "top_commands": {r[0]: r[1] for r in commands},
                "db_path": self._db_path,
            }
        return {"total_events": 0, "total_test_results": 0, "top_commands": {}, "db_path": self._db_path}

    def close(self) -> None:
        """Close the database connection."""
        if self._conn:
            self._conn.close()
            self._conn = None

    # ── Internals ─────────────────────────────────────────────

    def _get_conn(self) -> sqlite3.Connection:
        if self._conn is None:
            # Ensure parent directory exists for file-based DBs
            if self._db_path != ":memory:":
                Path(self._db_path).parent.mkdir(parents=True, exist_ok=True)
            self._conn = sqlite3.connect(self._db_path)
        return self._conn

    def _ensure_schema(self) -> None:
        with cli_resilient_block("telemetry schema init"):
            conn = self._get_conn()
            conn.executescript(_SCHEMA)
            conn.executescript(_TEST_RESULTS_SCHEMA)
