# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""SDK Telemetry — lightweight, opt-in CLI usage tracking.

All telemetry is stored **locally** in ``~/.routertl/telemetry.db``.
Nothing is sent anywhere without an explicit ``rr telemetry push``.

Disable collection entirely::

    export ROUTERTL_TELEMETRY=0
"""

from sdk.telemetry.events import TelemetryEvent
from sdk.telemetry.store import TelemetryStore

__all__ = ["TelemetryEvent", "TelemetryStore"]
