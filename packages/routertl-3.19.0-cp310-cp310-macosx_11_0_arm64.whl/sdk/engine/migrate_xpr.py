# SPDX-FileCopyrightText: 2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Generate project.yml from a parsed Vivado .xpr file.

Converts :class:`XprParseResult` into a project.yml-compatible dict and
writes it to disk.  Handles path relativisation, VHDL library detection,
unsupported-feature warnings, and Vivado-specific defaults.

RTL-P2.211 (Tier 1)

Usage::

    from sdk.engine.xpr_parser import parse_xpr
    from sdk.engine.migrate_xpr import generate_project_yml

    result = parse_xpr("project.xpr")
    yml_path = generate_project_yml(result, output_dir=Path("."))
"""

from __future__ import annotations

import logging
import shutil as _shutil
import subprocess
import tempfile
from pathlib import Path

import yaml

from sdk.engine.xpr_parser import XprFile, XprParseResult, _relativise

_log = logging.getLogger(__name__)

# Vivado default library → rr uses "work" as the default
_VIVADO_DEFAULT_LIBS = {"xil_defaultlib", "work", ""}


def _detect_language(result: XprParseResult) -> str:
    """Detect project HDL language from file types."""
    has_vhdl = any(
        "VHDL" in f.file_type for f in result.syn_files
    )
    has_sv = any(
        f.file_type in ("SystemVerilog", "Verilog")
        for f in result.syn_files
    )
    if has_vhdl and has_sv:
        return "mixed"
    if has_sv:
        return "systemverilog"
    return "vhdl"


def _extract_libraries(result: XprParseResult) -> dict[str, list[str]]:
    """Extract non-default VHDL library assignments."""
    libs: dict[str, list[str]] = {}
    for f in result.syn_files:
        if f.library.lower() not in _VIVADO_DEFAULT_LIBS:
            libs.setdefault(f.library, []).append(f.resolved_path)
    return libs


def _infer_source_dirs(files: list, project_root: Path) -> list[str]:
    """Infer unique source directories from file paths."""
    dirs: set[str] = set()
    for f in files:
        rel = _relativise(f.resolved_path, project_root)
        parent = str(Path(rel).parent)
        if parent and parent != ".":
            dirs.add(parent)
    return sorted(dirs)


# ── Source relocation ────────────────────────────────────────────────────────


def _copy_file(src: Path, dst: Path, dry_run: bool = False) -> bool:
    """Copy *src* to *dst*, creating parents.  Returns True on success."""
    if dry_run:
        return True
    dst.parent.mkdir(parents=True, exist_ok=True)
    _shutil.copy2(src, dst)
    return True


def _pick_dest(
    f: XprFile,
    dest_dir: Path,
    seen: dict[str, Path],
) -> Path:
    """Choose a collision-free destination path inside *dest_dir*."""
    name = Path(f.resolved_path).name
    if name not in seen:
        dest = dest_dir / name
        seen[name] = dest
        return dest
    # Collision — use parent dir basename as subdirectory
    parent_name = Path(f.resolved_path).parent.name or "ext"
    dest = dest_dir / parent_name / name
    return dest


def _is_inside_vivado_artifact(filepath: Path, project_root: Path) -> bool:
    """Return True if *filepath* is inside a Vivado artifact dir under *project_root*.

    Detects paths like ``<root>/<proj>.srcs/...``, ``<root>/<proj>.gen/...`` etc.
    These files should be relocated into the canonical folder structure even
    though they are technically under the project root (RTL-P2.285).
    """
    try:
        rel = filepath.relative_to(project_root)
    except ValueError:
        return False
    # Check if the first path component is a Vivado artifact directory
    parts = rel.parts
    if not parts:
        return False
    top_dir = parts[0]
    return any(top_dir.endswith(s) for s in _VIVADO_EXCLUDE_SUFFIXES)


def relocate_sources(
    result: XprParseResult,
    project_root: Path,
    dry_run: bool = False,
    *,
    src_dir: str = "hw/src",
    sim_dir: str = "hw/sim",
    xdc_dir: str = "hw/xdc",
) -> list[str]:
    """Copy source files into canonical folder structure and update paths.

    All files inside Vivado artifact directories (.srcs/, .gen/, etc.) and
    external files are copied into the canonical folder structure.
    Files already in the canonical layout are left in place.
    Files that don't exist are pointed at their canonical destination
    (flagged in the report).

    Parameters
    ----------
    src_dir
        Destination for synthesis sources (default ``hw/src``).
    sim_dir
        Destination for simulation sources (default ``hw/sim``).
    xdc_dir
        Destination for constraints and TCL hooks (default ``hw/xdc``).

    Returns a list of "copied X → Y" action strings.
    """
    project_root = project_root.resolve()
    actions: list[str] = []

    # Map file lists to destination directories
    file_groups: list[tuple[list[XprFile], Path]] = [
        (result.syn_files, project_root / src_dir),
        (result.sim_files, project_root / sim_dir),
        (result.xdc_files, project_root / xdc_dir),
        (result.tcl_constraint_files, project_root / xdc_dir),
    ]

    # Run hook scripts (settings.tcl etc.) → scripts/
    hook_files = [
        XprFile(
            path=h.path, resolved_path=h.resolved_path,
            file_type="TCL", library="", is_global=False, exists=h.exists,
        )
        for h in result.run_hooks
    ]
    if hook_files:
        # Deduplicate by resolved path (same hook may appear in synth + impl)
        seen_paths: set[str] = set()
        unique_hooks: list[XprFile] = []
        for hf in hook_files:
            if hf.resolved_path not in seen_paths:
                seen_paths.add(hf.resolved_path)
                unique_hooks.append(hf)
        file_groups.append((unique_hooks, project_root / "scripts"))

    for file_list, dest_dir in file_groups:
        seen: dict[str, Path] = {}
        for f in file_list:
            resolved = Path(f.resolved_path)

            # Check if this file needs relocation:
            # - External files (outside project root) → always relocate
            # - Files inside Vivado artifact dirs → relocate to canonical layout
            # - Files already in canonical layout (hw/src, etc.) → skip
            is_local = False
            try:
                resolved.relative_to(project_root)
                is_local = True
            except ValueError:
                pass

            if is_local and not _is_inside_vivado_artifact(resolved, project_root):
                continue

            dest = _pick_dest(f, dest_dir, seen)
            if resolved.exists():
                if _copy_file(resolved, dest, dry_run=dry_run):
                    rel = _relativise(str(dest.resolve()), project_root)
                    actions.append(f"{f.resolved_path} → {rel}")
                    f.resolved_path = str(dest.resolve())
                    f.exists = True
            else:
                # File missing — point to where it *should* go so the
                # generated YAML uses a relative path.  The migration
                # report already flags these as missing.
                f.resolved_path = str(dest.resolve())

    return actions


def relocate_ip_repos(
    result: XprParseResult,
    project_root: Path,
    dry_run: bool = False,
    *,
    ip_dir: str = "hw/ip",
) -> tuple[list[str], list[str]]:
    """Copy IP repositories from ip_repo_paths into the project.

    Each ip_repo_path directory is copied wholesale into
    ``<ip_dir>/<dirname>``.  The generated ``ip_paths`` entries point at
    the new location so the project is fully self-contained.

    Parameters
    ----------
    ip_dir
        Destination for IP repos (default ``hw/ip``).

    Returns (new_ip_paths relative to project_root, copy_actions).
    """
    project_root = project_root.resolve()
    ip_dest = project_root / ip_dir
    actions: list[str] = []
    new_paths: list[str] = []

    for repo_path_str in result.ip_repo_paths:
        repo_path = Path(repo_path_str)
        if not repo_path.exists() or not repo_path.is_dir():
            # Keep the original path so the report flags it as missing
            new_paths.append(
                _relativise(str((ip_dest / repo_path.name).resolve()),
                            project_root)
            )
            continue

        # Already under hw/ip — skip
        try:
            repo_path.resolve().relative_to(ip_dest.resolve())
            new_paths.append(
                _relativise(str(repo_path.resolve()), project_root)
            )
            continue
        except ValueError:
            pass

        dest = ip_dest / repo_path.name
        if not dry_run:
            dest.parent.mkdir(parents=True, exist_ok=True)
            if dest.exists():
                _shutil.rmtree(dest)
            _shutil.copytree(repo_path, dest)
        rel = _relativise(str(dest.resolve()), project_root)
        actions.append(f"{repo_path} → {rel}")
        new_paths.append(rel)

    return new_paths, actions


def search_missing_files(
    result: XprParseResult,
    search_dirs: list[Path],
) -> dict[str, Path]:
    """Search directories for files that are missing from the parse result.

    Matches by filename only.  Returns a dict mapping resolved_path → found_path
    for files that were located.
    """
    missing = result.missing_files
    if not missing:
        return {}

    # Build a lookup of what we need: filename → list of XprFile
    needed: dict[str, list[XprFile]] = {}
    for f in missing:
        name = Path(f.resolved_path).name
        needed.setdefault(name, []).append(f)

    found: dict[str, Path] = {}

    for search_dir in search_dirs:
        search_dir = Path(search_dir).resolve()
        if not search_dir.is_dir():
            continue
        # Walk the directory (shallow — just top level + one deep)
        for candidate in list(search_dir.iterdir()) + [
            p for sub in search_dir.iterdir() if sub.is_dir()
            for p in sub.iterdir()
        ]:
            if not candidate.is_file():
                continue
            if candidate.name in needed and candidate.name not in found:
                found[candidate.name] = candidate
                # Update the XprFile entries
                for xf in needed[candidate.name]:
                    xf.resolved_path = str(candidate)
                    xf.exists = True

    return found


# ── Vivado artifact directory patterns ──────────────────────────────────────
# Directories matching these suffixes or names are generated by Vivado and
# must NOT be searched for user source files.  IP stubs, sim netlists, and
# OOC synthesis outputs would produce false positives.

_VIVADO_EXCLUDE_SUFFIXES = (
    ".cache", ".gen", ".runs", ".srcs", ".hw", ".sim",
    ".ip_user_files", ".xpr",
)

_VIVADO_EXCLUDE_NAMES = frozenset({
    "ip_repo", ".Xil", ".hbs", "__pycache__", ".git",
})


def _is_vivado_artifact_dir(d: Path) -> bool:
    """Return True if *d* looks like a Vivado-generated directory."""
    name = d.name
    if name in _VIVADO_EXCLUDE_NAMES:
        return True
    for suffix in _VIVADO_EXCLUDE_SUFFIXES:
        if name.endswith(suffix):
            return True
    return False


def auto_search_from_xpr(
    result: XprParseResult,
    xpr_path: Path,
    *,
    max_climb: int = 3,
) -> dict[str, Path]:
    """Auto-search for missing files near the .xpr project.

    Searches outward from *xpr_path* in concentric rings:

    1. The .xpr's own directory (sibling files)
    2. Sibling directories of the .xpr's parent
    3. Walk up to a ``.git`` root or *max_climb* levels, searching
       sibling directories at each level

    Vivado artifact directories are always skipped.

    Parameters
    ----------
    result
        Parsed .xpr data with ``missing_files`` to resolve.
    xpr_path
        Path to the .xpr file (search anchor).
    max_climb
        Maximum number of parent directories to climb.

    Returns
    -------
    dict[str, Path]
        Mapping of filename → found path for each located file.
    """
    if not result.missing_files:
        return {}

    xpr_path = Path(xpr_path).resolve()
    xpr_dir = xpr_path.parent

    all_found: dict[str, Path] = {}

    # ── Search outward ring-by-ring so nearby matches win ──
    current = xpr_dir
    for level in range(max_climb + 1):
        if not result.missing_files:
            break  # all resolved

        # Collect candidate directories at this level
        search_dirs: list[Path] = []
        for item in current.iterdir():
            if not item.is_dir():
                continue
            if _is_vivado_artifact_dir(item):
                continue
            search_dirs.append(item)

        if search_dirs:
            _log.info(
                "Auto-searching %d directories under %s for missing files",
                len(search_dirs), current,
            )
            found = search_missing_files(result, search_dirs)
            all_found.update(found)

        # Climb to parent for next ring
        parent = current.parent
        if parent == current:
            break  # filesystem root
        if (current / ".git").exists() and level > 0:
            break  # don't climb above git root
        current = parent

    return all_found


def build_project_config(
    result: XprParseResult,
    project_root: Path,
    adapted_bd_hooks: list[str] | None = None,
) -> dict:
    """Build a project.yml-compatible dict from parsed .xpr data.

    Parameters
    ----------
    result
        Output of :func:`parse_xpr`.
    project_root
        Directory where project.yml will live (used for path relativisation).

    Returns
    -------
    dict
        Ready to be dumped as YAML.
    """
    project_root = project_root.resolve()
    language = _detect_language(result)

    # ── Relativise all file paths ──
    syn_rel = [
        _relativise(f.resolved_path, project_root) for f in result.syn_files
    ]
    sim_rel = [
        _relativise(f.resolved_path, project_root) for f in result.sim_files
    ]
    xdc_rel = [
        _relativise(f.resolved_path, project_root) for f in result.xdc_files
    ]
    xci_rel = [
        _relativise(f.resolved_path, project_root) for f in result.xci_files
    ]

    config: dict = {
        "project": {
            "name": result.project_name,
            "top_module": result.top_module,
        },
        "hardware": {
            "vendor": "xilinx",
            "part": result.part,
            "language": language,
            "platform": "default",
        },
    }

    if result.board_part:
        config["hardware"]["board"] = result.board_part

    # ── Build options ──
    if result.vivado_version:
        # Extract major.minor from e.g. "7" or full version string
        config["build_options"] = {"tool_version": result.vivado_version}

    # ── Sources ──
    sources: dict = {}
    if syn_rel:
        sources["syn"] = syn_rel
    if sim_rel:
        sources["sim"] = sim_rel
    if xdc_rel:
        sources["xdc"] = xdc_rel
    if xci_rel:
        sources["ip"] = xci_rel

    # IP repository paths
    if result.ip_repo_paths:
        sources["ip_paths"] = [
            _relativise(p, project_root) for p in result.ip_repo_paths
        ]

    config["sources"] = sources

    # ── VHDL library overrides ──
    libraries = _extract_libraries(result)
    if libraries:
        lib_rel: dict[str, list[str]] = {}
        for lib, files in libraries.items():
            lib_rel[lib] = [_relativise(f, project_root) for f in files]
        config["sources"]["libraries"] = lib_rel

    # ── Infer paths.sources for auto-discovery ──
    src_dirs = _infer_source_dirs(result.syn_files, project_root)
    if src_dirs:
        config["paths"] = {"sources": src_dirs}

    # ── BD references as tcl_hooks ──
    tcl_hooks: dict = {}
    if adapted_bd_hooks:
        tcl_hooks["gen_project"] = adapted_bd_hooks
    elif result.bd_files:
        bd_names = [Path(f.path).stem for f in result.bd_files]
        tcl_hooks["gen_project"] = [
            f"# TODO: Export and adapt BD '{name}' → rr hook adapt <exported_bd.tcl>"
            for name in bd_names
        ]

    # ── TCL constraint files + run hooks → tcl_hooks.synthesis/implementation ──
    if result.tcl_constraint_files or result.run_hooks:
        # Run pre-hooks (settings.tcl) go first — they set variables
        synth_pre = [
            _relativise(h.resolved_path, project_root)
            for h in result.run_hooks
            if h.run_type == "synth" and h.hook_type == "pre"
        ]
        impl_pre = [
            _relativise(h.resolved_path, project_root)
            for h in result.run_hooks
            if h.run_type == "impl" and h.hook_type == "pre"
        ]
        # TCL constraint files listed after pre-hooks
        tcl_constr_rel = [
            _relativise(f.resolved_path, project_root)
            for f in result.tcl_constraint_files
        ]
        if synth_pre or tcl_constr_rel:
            tcl_hooks["synthesis"] = synth_pre + tcl_constr_rel
        if impl_pre or tcl_constr_rel:
            tcl_hooks["implementation"] = impl_pre + tcl_constr_rel

    if tcl_hooks:
        config["tcl_hooks"] = tcl_hooks

    # ── SW TCL scripts (XSCT/XSDB) → sw_tcl_scripts (informational) ──
    if result.tcl_sw_files:
        config["sw_tcl_scripts"] = [
            _relativise(f.resolved_path, project_root)
            for f in result.tcl_sw_files
        ]

    # ── Hooks skeleton ──
    config["hooks"] = {
        "pre_commit": {
            "enabled": True,
            "lint": True,
            "check_yaml": True,
            "tests": [],
        },
    }

    return config


def generate_project_yml(
    result: XprParseResult,
    output_dir: Path,
    filename: str = "project.yml",
    adapted_bd_hooks: list[str] | None = None,
) -> Path:
    """Generate project.yml from parsed .xpr data and write to disk.

    Returns the path to the written file.
    """
    output_dir = Path(output_dir).resolve()
    config = build_project_config(result, output_dir, adapted_bd_hooks=adapted_bd_hooks)

    yml_path = (output_dir / filename).resolve()
    yml_path.parent.mkdir(parents=True, exist_ok=True)
    header = (
        f"# Migrated from Vivado project: {result.project_name}.xpr\n"
        f"# Generated by: rr migrate (RTL-P2.211)\n"
        "#\n"
    )

    if result.unsupported:
        header += "# ⚠️  Unsupported features (require manual attention):\n"
        for item in result.unsupported:
            header += f"#   - {item}\n"
        header += "#\n"

    # Flag missing files in header
    if result.missing_files:
        header += "# ⚠️  Missing files (not found on disk):\n"
        for f in result.missing_files:
            header += f"#   - {_relativise(f.resolved_path, output_dir)}\n"
        header += "#\n"

    # Flag non-relocatable absolute paths in header
    abs_paths = [
        p for p in config.get("sources", {}).get("syn", [])
        + config.get("sources", {}).get("sim", [])
        + config.get("sources", {}).get("xdc", [])
        + config.get("sources", {}).get("ip", [])
        if Path(p).is_absolute()
    ]
    if abs_paths:
        header += "# ⚠️  Non-relocatable absolute paths (files outside project root):\n"
        for p in abs_paths:
            header += f"#   - {p}\n"
        header += "# Consider copying these files into the project directory.\n"
        header += "#\n"

    yml_content = yaml.dump(
        config,
        default_flow_style=False,
        sort_keys=False,
        allow_unicode=True,
    )

    yml_path.write_text(header + yml_content)
    _log.info("Written %s", yml_path)
    return yml_path


# ── Tier 2: Block Design Export ──────────────────────────────────────────────


def export_block_designs(
    result: XprParseResult,
    xpr_path: Path,
    project_root: Path,
    hooks_dir: Path | None = None,
) -> list[str]:
    """Export block designs from a Vivado project via batch mode.

    Requires Vivado on PATH.  For each BD in *result*, launches Vivado in
    batch mode to run ``write_bd_tcl``, then strips boilerplate using
    :func:`_adapt_vivado_bd` from the hook adapter.

    Parameters
    ----------
    result
        Parsed .xpr data (must have ``bd_files``).
    xpr_path
        Path to the .xpr file (Vivado opens this project).
    project_root
        Directory where the routertl project lives.
    hooks_dir
        Where to write adapted TCL hooks.  Defaults to
        ``project_root / "tcl" / "hooks"``.

    Returns
    -------
    list[str]
        Paths (relative to *project_root*) of the adapted hook files.
        Empty list if Vivado is not found or export fails.
    """
    vivado = _shutil.which("vivado")
    if not vivado:
        _log.warning("Vivado not found on PATH — skipping BD export")
        return []

    if not result.bd_files:
        return []

    if hooks_dir is None:
        hooks_dir = project_root / "tcl" / "hooks"
    hooks_dir.mkdir(parents=True, exist_ok=True)

    xpr_path = Path(xpr_path).resolve()
    project_root = Path(project_root).resolve()

    adapted_paths: list[str] = []

    with tempfile.TemporaryDirectory(prefix="rr_bd_export_") as tmpdir:
        tmp = Path(tmpdir)

        for bd_file in result.bd_files:
            bd_name = Path(bd_file.path).stem

            # Raw export destination
            raw_tcl = tmp / f"{bd_name}_raw.tcl"

            # Generate batch TCL script
            batch_tcl = tmp / f"export_{bd_name}.tcl"
            batch_tcl.write_text(
                f"open_project {{{xpr_path}}}\n"
                f"open_bd_design [get_files {bd_name}.bd]\n"
                f"write_bd_tcl {{{raw_tcl}}}\n"
                f"close_bd_design [current_bd_design]\n"
                f"close_project\n"
                f"exit\n"
            )

            _log.info("Exporting BD '%s' via Vivado batch...", bd_name)
            proc = subprocess.run(
                [
                    vivado, "-mode", "batch",
                    "-nolog", "-nojournal", "-notrace",
                    "-source", str(batch_tcl),
                ],
                capture_output=True,
                text=True,
                timeout=300,
            )

            if proc.returncode != 0 or not raw_tcl.exists():
                _log.error(
                    "Vivado BD export failed for '%s' (rc=%d):\n%s",
                    bd_name, proc.returncode, proc.stderr[:500],
                )
                continue

            # Adapt: strip boilerplate
            from sdk.cli.commands.hook import _adapt_vivado_bd

            raw_lines = raw_tcl.read_text().splitlines()
            adapted_lines = _adapt_vivado_bd(raw_lines)

            # Write adapted hook — _bd suffix distinguishes from other hooks
            out_path = hooks_dir / f"{bd_name}_bd.tcl"
            out_path.write_text("\n".join(adapted_lines) + "\n")

            rel = _relativise(str(out_path.resolve()), project_root)
            adapted_paths.append(rel)
            _log.info("Adapted BD hook: %s", rel)

    return adapted_paths


# ── Project Scaffolding ──────────────────────────────────────────────────────

_MAKEFILE_TEMPLATE = """\
# RouteRTL Project Makefile
# Generated by: rr migrate

SDK_ROOT := $(shell rr sdk-path 2>/dev/null || echo vendor/routertl)
ROOT_DIR := $(shell pwd)
-include $(SDK_ROOT)/Common.mk

all:
\t@echo "RouteRTL SDK not found. Install: pip install routertl"
"""

_GITIGNORE_TEMPLATE = """\
# Generated files
build_env.mk
build_env.tcl

# Build artifacts
*.dcp
*.bit
*.bin
project/
build/
.Xil/
*.jou
*.log

# Simulation artifacts
*.vcd
*.ghw
sim_build/
__pycache__/
"""


def scaffold_migrated_project(project_root: Path) -> list[str]:
    """Generate Makefile, .gitignore, and build_env for a migrated project.

    Returns list of generated file names.
    """
    project_root = Path(project_root).resolve()
    generated: list[str] = []

    makefile = project_root / "Makefile"
    if not makefile.exists():
        makefile.write_text(_MAKEFILE_TEMPLATE)
        generated.append("Makefile")

    gitignore = project_root / ".gitignore"
    if not gitignore.exists():
        gitignore.write_text(_GITIGNORE_TEMPLATE)
        generated.append(".gitignore")

    # Generate build_env.mk / build_env.tcl from project.yml
    try:
        from routertl_core.workspace.orchestration import _run_update_config

        _run_update_config(exit_on_error=False)
        if (project_root / "build_env.mk").exists():
            generated.append("build_env.mk")
        if (project_root / "build_env.tcl").exists():
            generated.append("build_env.tcl")
    except (ImportError, FileNotFoundError, OSError) as exc:
        _log.warning("Could not generate build_env: %s", exc)

    return generated


# ── SoC: Software directory scaffolding ────────────────────────────────────

_SYSTEM_MEMORY_MAP_TEMPLATE = """\
version: "1.0.0"
target: {target}

devices: []
  # Add your memory-mapped IPs here. Example:
  # - name: my_custom_ip
  #   base_addr: 0x43C00000
  #   span: 0x1000
  #   regbank_ref: project_regbank.yml
"""


def scaffold_sw_directory(
    project_root: Path,
    soc_family: str,
    sw_dir: str = "sw/linux",
) -> list[str]:
    """Scaffold a sw/ directory for SoC designs.

    Creates a skeletal ``system_memory_map.yml`` with the *target* field
    auto-populated from the detected SoC family.  Does not overwrite
    existing files.

    Parameters
    ----------
    project_root
        Project root directory.
    soc_family
        Detected SoC family (e.g. ``"zynqmp"``).
    sw_dir
        Destination directory (default ``sw/linux``).

    Returns
    -------
    list[str]
        Paths of created files, relative to *project_root*.
    """
    project_root = project_root.resolve()
    sw_path = project_root / sw_dir
    sw_path.mkdir(parents=True, exist_ok=True)
    generated: list[str] = []

    smm_path = sw_path / "system_memory_map.yml"
    if not smm_path.exists():
        smm_path.write_text(
            _SYSTEM_MEMORY_MAP_TEMPLATE.format(target=soc_family)
        )
        generated.append(_relativise(str(smm_path), project_root))

    return generated


def relocate_sw_tcl_files(
    result: XprParseResult,
    project_root: Path,
    sw_dir: str = "sw/linux",
    dry_run: bool = False,
) -> list[str]:
    """Copy XSCT/XSDB TCL scripts into the sw/ directory.

    These are software-flow scripts that were incorrectly living in the
    Vivado DesignSrcs fileset.  Moving them to ``sw/`` keeps a clean
    separation between hardware hooks and software tooling scripts.

    Returns a list of "src → dst" action strings.
    """
    if not result.tcl_sw_files:
        return []

    project_root = project_root.resolve()
    sw_path = project_root / sw_dir
    actions: list[str] = []

    for f in result.tcl_sw_files:
        resolved = Path(f.resolved_path)
        dest = sw_path / resolved.name
        rel_src = _relativise(str(resolved), project_root)
        rel_dst = _relativise(str(dest), project_root)

        if not dry_run:
            if resolved.is_file():
                dest.parent.mkdir(parents=True, exist_ok=True)
                _shutil.copy2(resolved, dest)
                # Update resolved path so downstream config uses the new location
                f.resolved_path = str(dest.resolve())
                actions.append(f"{rel_src} → {rel_dst}")
            else:
                actions.append(f"{rel_src} → {rel_dst} (source missing)")
        else:
            actions.append(f"{rel_src} → {rel_dst}")

    return actions


# ── Migration Summary Report ────────────────────────────────────────────────


def _collect_absolute_paths(config: dict) -> list[str]:
    """Return source paths in *config* that are still absolute.

    Excludes ``ip_paths`` — those are validated separately (RTL-P2.284).
    """
    paths: list[str] = []
    for key in ("syn", "sim", "xdc", "ip"):
        for p in config.get("sources", {}).get(key, []):
            if Path(p).is_absolute():
                paths.append(p)
    return paths


def _collect_missing_ip_repos(config: dict, project_root: Path) -> list[str]:
    """Return ip_paths entries that don't exist on disk."""
    missing: list[str] = []
    for p in config.get("sources", {}).get("ip_paths", []):
        full = Path(p) if Path(p).is_absolute() else project_root / p
        if not full.exists() or not full.is_dir():
            missing.append(p)
    return missing


def generate_migration_report(
    result: XprParseResult,
    config: dict,
    xpr_path: Path,
    tgt_path: Path,
    report_path: Path | None = None,
    *,
    dry_run: bool = False,
    vivado_available: bool = False,
    adapted_bd_hooks: list[str] | None = None,
    relocated_files: list[str] | None = None,
    scaffolded_files: list[str] | None = None,
    sw_scaffolded_files: list[str] | None = None,
) -> str:
    """Build a plain-text migration summary report.

    Parameters
    ----------
    result
        Parsed .xpr data.
    config
        The project config dict (output of :func:`build_project_config`).
    xpr_path
        Path to the original .xpr file.
    tgt_path
        Path to the generated target YAML file.
    report_path
        If given, the report is also written to this file.
    dry_run
        If True, the report title shows "Pre-Report" instead of
        "Migration Summary".
    vivado_available
        Whether Vivado was found on PATH.
    adapted_bd_hooks
        Paths of successfully exported and adapted BD hooks.
    relocated_files
        List of "src → dst" strings for files that were relocated.
    scaffolded_files
        List of file names generated by scaffolding (Makefile, etc.).

    Returns
    -------
    str
        The full report text.
    """
    sep = "\u2550" * 60
    thin = "\u2500" * 54

    language = config.get("hardware", {}).get("language", "unknown")
    n_syn = len(config.get("sources", {}).get("syn", []))
    n_sim = len(config.get("sources", {}).get("sim", []))
    n_xdc = len(config.get("sources", {}).get("xdc", []))
    n_ip = len(result.xci_files)
    n_bd = len(result.bd_files)

    lines: list[str] = []
    title = "Migration Pre-Report (dry run)" if dry_run else "Migration Summary"
    lines.append(f"  {sep}")
    lines.append(f"  {title} \u2014 {result.project_name}")
    lines.append(f"  {sep}")
    lines.append("")
    lines.append(f"  Source:        {xpr_path}")
    if result.vivado_version:
        lines.append(f"  Vivado:        {result.vivado_version}")
    lines.append(f"  Part:          {result.part}")
    if result.soc_family:
        lines.append(f"  SoC family:    {result.soc_family}")
    lines.append(f"  Top module:    {result.top_module or '(not detected)'}")
    lines.append(f"  Language:      {language}")
    lines.append("")
    lines.append(f"  Sources:       {n_syn} synthesis, {n_sim} simulation")
    n_tcl_constr = len(result.tcl_constraint_files)
    n_run_hooks = len(result.run_hooks)
    lines.append(f"  Constraints:   {n_xdc} XDC files")
    if n_tcl_constr:
        lines.append(f"  TCL constrs:   {n_tcl_constr} (mapped to tcl_hooks)")
    n_tcl_sw = len(result.tcl_sw_files)
    if n_tcl_sw:
        lines.append(f"  SW scripts:    {n_tcl_sw} XSCT/XSDB (moved to sw/)")
    if n_run_hooks:
        lines.append(f"  Run hooks:     {n_run_hooks} (settings/pre-step scripts)")
    lines.append(f"  IP cores:      {n_ip}")
    n_ip_repos = len(config.get("sources", {}).get("ip_paths", []))
    if n_ip_repos:
        lines.append(f"  IP repos:      {n_ip_repos}")
    lines.append(f"  Block designs: {n_bd}")

    # ── Issues ──
    missing = result.missing_files
    abs_paths = _collect_absolute_paths(config)
    missing_ip_repos = _collect_missing_ip_repos(
        config, Path(str(tgt_path)).parent.parent,
    )
    has_issues = (
        missing or abs_paths or missing_ip_repos or result.unsupported
        or result.warnings or result.bd_files
        or result.tcl_constraint_files or result.tcl_sw_files
        or result.run_hooks
    )

    if has_issues:
        lines.append("")
        lines.append(f"  \u2500\u2500 Issues {thin}")

    if result.unsupported:
        lines.append("")
        for item in result.unsupported:
            lines.append(f"  \u274c  {item}")

    if missing:
        lines.append("")
        lines.append(f"  \u26a0\ufe0f  Missing files ({len(missing)}):")
        for f in missing:
            lines.append(f"    - {f.resolved_path}")

    if missing_ip_repos:
        # RTL-P2.394: the previous wording blamed the local hw/ip/<name>
        # destination for not existing.  That's misleading — the
        # destination is tooling-created the moment we have a source to
        # copy in.  The real issue is that the source IP repo referenced
        # by the xpr wasn't resolvable (absolute path outside the tree,
        # missing from disk, or excluded from the migration).  Call out
        # the source by path so the user knows what to find.
        lines.append("")
        lines.append(
            f"  \u26a0\ufe0f  IP repository destinations not yet populated "
            f"({len(missing_ip_repos)}):"
        )
        # Cross-reference with the xpr's original ip_repo_paths so the
        # user sees source-of-truth, not just the empty dest dir.
        originals = list(result.ip_repo_paths or [])
        for p in missing_ip_repos:
            dest_stem = Path(p).name
            match = next(
                (orig for orig in originals if Path(orig).name == dest_stem),
                None,
            )
            if match:
                lines.append(f"    - {p}  (source: {match})")
            else:
                lines.append(f"    - {p}")
        lines.append(
            "  These paths are destinations — the migration creates them "
            "once it can copy the source IP repo in.  If the source lives "
            "elsewhere, re-run with [cyan]--src-dirs <path>[/] pointing at "
            "it, or place the directories under hw/ip/ manually before "
            "the first build."
        )

    if abs_paths:
        lines.append("")
        lines.append(
            f"  \u26a0\ufe0f  Non-relocatable paths ({len(abs_paths)}):"
        )
        for p in abs_paths:
            lines.append(f"    - {p}")
        lines.append("  Consider copying these files into the project.")

    if result.bd_files:
        lines.append("")
        if adapted_bd_hooks:
            lines.append(
                f"  \u2705  Block designs exported via Vivado ({len(adapted_bd_hooks)}):"
            )
            for h in adapted_bd_hooks:
                lines.append(f"    - {h}")
        elif dry_run and vivado_available:
            lines.append(
                "  \u2139\ufe0f  Block designs detected "
                "(Vivado available \u2014 will auto-export on real run):"
            )
            for f in result.bd_files:
                lines.append(f"    - {Path(f.path).stem}")
        elif vivado_available:
            lines.append("  \u274c  Block design export failed:")
            for f in result.bd_files:
                name = Path(f.path).stem
                lines.append(
                    f"    - {name} \u2192 try manually: rr hook adapt <exported.tcl>"
                )
        else:
            lines.append(
                "  \u26a0\ufe0f  Block designs need manual export "
                "(Vivado not found):"
            )
            for f in result.bd_files:
                name = Path(f.path).stem
                lines.append(
                    f"    - {name} \u2192 rr hook adapt <exported.tcl>"
                )

    if result.tcl_constraint_files:
        lines.append("")
        lines.append(
            f"  \u26a0\ufe0f  TCL constraint files ({len(result.tcl_constraint_files)}) "
            "\u2192 mapped to tcl_hooks:"
        )
        for f in result.tcl_constraint_files:
            rel = _relativise(f.resolved_path, Path(str(tgt_path)).parent)
            lines.append(f"    - {rel}")
        lines.append(
            "  Verify variable context after migration "
            "(conditional logic cannot be auto-validated)"
        )

    if result.tcl_sw_files:
        lines.append("")
        lines.append(
            f"  \u2139\ufe0f  XSCT/XSDB scripts ({len(result.tcl_sw_files)}) "
            "\u2192 moved to sw/ (not hardware hooks):"
        )
        for f in result.tcl_sw_files:
            rel = _relativise(f.resolved_path, Path(str(tgt_path)).parent)
            lines.append(f"    - {rel}")

    if result.run_hooks:
        lines.append("")
        # Deduplicate by resolved path for display
        seen_hook_paths: set[str] = set()
        unique_display: list[str] = []
        for h in result.run_hooks:
            if h.resolved_path not in seen_hook_paths:
                seen_hook_paths.add(h.resolved_path)
                rel = _relativise(h.resolved_path, Path(str(tgt_path)).parent)
                stages = ", ".join(
                    f"{rh.step_id}.{rh.hook_type}"
                    for rh in result.run_hooks
                    if rh.resolved_path == h.resolved_path
                )
                unique_display.append(f"    - {rel} ({stages})")
        lines.append(
            f"  \u26a0\ufe0f  Pre-step hooks ({len(unique_display)}) "
            "\u2192 sourced before TCL constraints:"
        )
        lines.extend(unique_display)

    for warn in result.warnings:
        if "Block design" not in warn:  # already covered above
            lines.append(f"  \u26a0\ufe0f  {warn}")

    # ── Relocated files ──
    if relocated_files:
        lines.append("")
        lines.append(f"  \u2500\u2500 Relocated files ({len(relocated_files)}) {thin}")
        for action in relocated_files:
            lines.append(f"    {action}")

    # ── Generated ──
    lines.append("")
    lines.append(f"  \u2500\u2500 Generated {thin}")
    lines.append("")
    lines.append(f"  Config:  {tgt_path}")
    if report_path:
        lines.append(f"  Report:  {report_path}")
    if scaffolded_files:
        for sf in scaffolded_files:
            lines.append(f"  Build:   {sf}")
    if sw_scaffolded_files:
        for sf in sw_scaffolded_files:
            lines.append(f"  SW:      {sf}")

    # ── Next steps ──
    lines.append("")
    lines.append(f"  \u2500\u2500 Next steps {thin}")
    lines.append("")

    step = 1
    still_missing = [f for f in result.missing_files if not f.exists]
    if still_missing:
        lines.append(
            f"  {step}. Obtain the {len(still_missing)} missing file(s) "
            "and place them in the project"
        )
        step += 1
    if abs_paths:
        lines.append(
            f"  {step}. Review {tgt_path} and adjust paths if needed"
        )
        step += 1
    if result.bd_files and not adapted_bd_hooks:
        lines.append(
            f"  {step}. Export BDs from Vivado, "
            "then run rr hook adapt <exported_bd.tcl>"
        )
        step += 1
    if sw_scaffolded_files:
        lines.append(
            f"  {step}. Edit system_memory_map.yml with your "
            "memory-mapped peripherals"
        )
        step += 1
    lines.append(f"  {step}. rr project")

    lines.append(f"  {sep}")
    lines.append("")

    report = "\n".join(lines)

    if report_path:
        report_path.parent.mkdir(parents=True, exist_ok=True)
        report_path.write_text(report)
        _log.info("Written %s", report_path)

    return report
