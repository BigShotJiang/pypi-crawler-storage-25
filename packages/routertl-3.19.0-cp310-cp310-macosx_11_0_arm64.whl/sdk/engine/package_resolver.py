# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Proxy — real implementation in routertl_core.package_resolver."""

# Re-export ALL names (including _private) from the core module
import routertl_core.package_resolver as _mod

globals().update({k: v for k, v in vars(_mod).items() if not k.startswith("__")})
