# SPDX-FileCopyrightText: 2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""routertl Alias Loader.

Loads, merges, and expands user-defined command aliases from two scopes:

1. **Project** — ``.routertl/aliases.yml`` (committed, shared with team)
2. **User** — ``~/.config/routertl/aliases.yml`` (personal, not committed)

Project aliases take precedence over user aliases with the same name.

Entry points::

    from sdk.engine.alias_loader import load_aliases, expand_command

    aliases = load_aliases(project_root)   # dict[str, AliasEntry]
    cmd = expand_command(entry, project_root, extra_args)
"""

from __future__ import annotations

import logging
import shlex
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml

_log = logging.getLogger("engine.alias_loader")

PROJECT_ALIAS_FILE = ".routertl/aliases.yml"
USER_ALIAS_DIR = Path.home() / ".config" / "routertl"
USER_ALIAS_FILE = USER_ALIAS_DIR / "aliases.yml"


@dataclass
class AliasEntry:
    """A single alias definition."""

    name: str
    command: str
    description: str = ""
    working_dir: str | None = None
    source: str = "project"  # "project" or "user"


# ── Public API ────────────────────────────────────────────────────────────────


def load_aliases(project_root: str | Path | None = None) -> dict[str, AliasEntry]:
    """Load and merge aliases from project and user scopes.

    Project aliases take precedence over user aliases with the same name.

    Parameters
    ----------
    project_root : path, optional
        Path to the project root (where ``.routertl/`` lives).
        If None, only user aliases are loaded.

    Returns
    -------
    dict mapping alias name → AliasEntry
    """
    merged: dict[str, AliasEntry] = {}

    # Load user aliases first (lower precedence)
    user_aliases = _load_alias_file(USER_ALIAS_FILE, source="user")
    merged.update(user_aliases)

    # Load project aliases (higher precedence — overwrites user)
    if project_root is not None:
        project_file = Path(project_root) / PROJECT_ALIAS_FILE
        project_aliases = _load_alias_file(project_file, source="project")
        merged.update(project_aliases)

    return merged


def expand_command(
    entry: AliasEntry,
    project_root: str | Path | None = None,
    extra_args: tuple[str, ...] = (),
) -> str:
    """Expand template variables in an alias command string.

    Template variables are resolved from project.yml and the environment.
    All variable values are shell-quoted for safety, except ``{args}``
    which is passed through raw (intentional — it's user-supplied CLI args).

    Parameters
    ----------
    entry : AliasEntry
        The alias to expand.
    extra_args : tuple of str
        Extra CLI arguments passed after the alias name.

    Returns
    -------
    str
        The fully expanded shell command string.
    """
    variables = _resolve_variables(project_root)

    # Add positional and aggregate args
    args_str = " ".join(extra_args)
    variables["args"] = args_str  # raw pass-through, no quoting
    for i, arg in enumerate(extra_args, 1):
        variables[str(i)] = shlex.quote(arg)

    cmd = entry.command
    for key, value in variables.items():
        placeholder = "{" + key + "}"
        if placeholder in cmd:
            cmd = cmd.replace(placeholder, value)

    return cmd


def resolve_working_dir(
    entry: AliasEntry,
    project_root: str | Path | None = None,
) -> str | None:
    """Resolve the working directory for an alias, expanding {root}."""
    if entry.working_dir is None:
        return None

    wd = entry.working_dir
    if project_root is not None:
        wd = wd.replace("{root}", str(Path(project_root).resolve()))
    return wd


def get_alias_file_path(scope: str, project_root: str | Path | None = None) -> Path:
    """Return the path to the alias file for a given scope."""
    if scope == "global":
        return USER_ALIAS_FILE
    if project_root is not None:
        return Path(project_root) / PROJECT_ALIAS_FILE
    return Path(PROJECT_ALIAS_FILE)


def save_alias(
    entry: AliasEntry,
    scope: str = "project",
    project_root: str | Path | None = None,
) -> Path:
    """Save an alias to the appropriate file.

    Creates the file and parent directories if they don't exist.

    Returns the path to the written file.
    """
    file_path = get_alias_file_path(scope, project_root)
    file_path.parent.mkdir(parents=True, exist_ok=True)

    # Load existing
    data = _load_raw_yaml(file_path)
    if "aliases" not in data:
        data["aliases"] = {}
    if "version" not in data:
        data["version"] = 1

    # Add/update the alias
    alias_data: dict[str, Any] = {"command": entry.command}
    if entry.description:
        alias_data["description"] = entry.description
    if entry.working_dir:
        alias_data["working_dir"] = entry.working_dir

    data["aliases"][entry.name] = alias_data

    with open(file_path, "w") as f:
        yaml.dump(data, f, default_flow_style=False, sort_keys=False, allow_unicode=True)

    return file_path


def remove_alias(
    name: str,
    scope: str = "project",
    project_root: str | Path | None = None,
) -> bool:
    """Remove an alias from the specified file. Returns True if found and removed."""
    file_path = get_alias_file_path(scope, project_root)
    if not file_path.exists():
        return False

    data = _load_raw_yaml(file_path)
    aliases = data.get("aliases", {})
    if name not in aliases:
        return False

    del aliases[name]

    with open(file_path, "w") as f:
        yaml.dump(data, f, default_flow_style=False, sort_keys=False, allow_unicode=True)

    return True


# ── Internal helpers ──────────────────────────────────────────────────────────


def _load_alias_file(path: Path, source: str) -> dict[str, AliasEntry]:
    """Load aliases from a single YAML file."""
    if not path.exists():
        return {}

    data = _load_raw_yaml(path)
    aliases_raw = data.get("aliases", {})
    if not isinstance(aliases_raw, dict):
        _log.warning("Invalid aliases format in %s — expected a mapping", path)
        return {}

    result: dict[str, AliasEntry] = {}
    for name, entry_data in aliases_raw.items():
        if isinstance(entry_data, str):
            # Short form: name: "command"
            result[name] = AliasEntry(
                name=name,
                command=entry_data,
                source=source,
            )
        elif isinstance(entry_data, dict):
            command = entry_data.get("command", "")
            if not command:
                _log.warning("Alias '%s' in %s has no command — skipping", name, path)
                continue
            result[name] = AliasEntry(
                name=name,
                command=command,
                description=entry_data.get("description", ""),
                working_dir=entry_data.get("working_dir"),
                source=source,
            )
        else:
            _log.warning("Invalid alias entry '%s' in %s — skipping", name, path)

    return result


def _load_raw_yaml(path: Path) -> dict:
    """Load a YAML file, returning empty dict if missing or invalid."""
    if not path.exists():
        return {}
    try:
        with open(path) as f:
            return yaml.safe_load(f) or {}
    except yaml.YAMLError as exc:
        _log.warning("Failed to parse %s: %s", path, exc)
        return {}


def _resolve_variables(project_root: str | Path | None) -> dict[str, str]:
    """Build the template variable dict from project.yml and environment."""
    variables: dict[str, str] = {}

    # Root
    if project_root is not None:
        root = Path(project_root).resolve()
        variables["root"] = str(root)
    else:
        variables["root"] = str(Path.cwd())

    root_path = Path(variables["root"])

    # Load project.yml for project-level variables
    yml_path = root_path / "project.yml"
    if yml_path.exists():
        try:
            with open(yml_path) as f:
                config = yaml.safe_load(f) or {}
        except yaml.YAMLError:
            config = {}

        project = config.get("project", {})
        if isinstance(project, dict):
            variables["project"] = project.get("name", "unknown")
            variables["top"] = project.get("top_module", project.get("top", "unknown"))

        hardware = config.get("hardware", {})
        if isinstance(hardware, dict):
            variables["part"] = hardware.get("part", "unknown")
            variables["vendor"] = hardware.get("vendor", "unknown")

    # Resolve {bitstream} — find latest .sof or .bit in bitstream/
    bitstream_dir = root_path / "bitstream"
    if bitstream_dir.exists():
        candidates = (
            sorted(bitstream_dir.glob("*.sof"))
            + sorted(bitstream_dir.glob("*.bit"))
        )
        if candidates:
            # Use the most recently modified
            latest = max(candidates, key=lambda p: p.stat().st_mtime)
            variables["bitstream"] = str(latest)
        else:
            variables["bitstream"] = "bitstream/*.sof"
    else:
        variables["bitstream"] = "bitstream/*.sof"

    # Shell-quote all values for safety
    return {k: shlex.quote(v) for k, v in variables.items()}
