# SPDX-FileCopyrightText: 2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Coverage-map — AST-walk cocotb tests for ``@requires()`` tags.

Builds a REQ → [tests] matrix per IP and flags uncovered or orphan
requirements.  Run as the downstream half of the contract-first loop:
``rr sim contract-check`` gates the **shape**, ``rr sim coverage-map``
gates the **behaviour proofs**.

Convention for finding tests: under a project rooted at CWD, this
module looks for tests at ``<test_dir>/<ip_name>/**/*.py`` where
``<test_dir>`` comes from ``simulation.test_dir`` in ``project.yml``
(default ``sim/cocotb/tests``).  Callers can override with an explicit
tests path.

AST walking honours ``simulation.exclude_dirs`` via the canonical
filter in :mod:`sdk.cli.env_setup` — mismatched filters between
scaffold and coverage-map would silently false-pass or false-fail on
Nike subtrees, which we explicitly avoid here.

RTL-P2.405 / RTL-P2.398.
"""

from __future__ import annotations

import ast
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from sdk.cli.requirements import load_requirements


@dataclass(frozen=True)
class RequiresTag:
    """One ``@requires()`` tag found in a cocotb test file."""

    req_id: str
    test_name: str     # decorated function name
    file_path: Path
    line: int
    # Count of ``ast.Assert`` nodes inside the decorated function body.
    # Zero = the tag is a promise without a proof ("vacuous tag" — the
    # exact failure mode RTL-P2.428 exists to catch).  This is a
    # strict direct-assert count: pytest.raises(), cocotb helpers that
    # assert internally, and calls to assertion-wrapping utilities
    # are NOT counted by v1.  Those edge cases can be handled via a
    # future whitelist.
    assert_count: int = 0


@dataclass(frozen=True)
class CoverageReport:
    """Coverage result for a single IP."""

    ip: str
    requirements_path: Path
    tests_dir: Path
    declared_reqs: tuple[str, ...]
    tags: tuple[RequiresTag, ...]
    covered: tuple[str, ...]       # declared AND tagged AND test asserts something
    missing: tuple[str, ...]       # declared but no tag
    orphan: tuple[str, ...]        # tagged but not declared
    # Declared REQs whose ONLY tagged test has no assert statements —
    # vacuous tag, promise without proof (RTL-P2.428).
    vacuous: tuple[str, ...] = ()
    # Provenance: (req_id, source_uri_or_None).  Tuple-of-pairs because
    # the dataclass is frozen; convert with dict() at the call site.
    req_sources: tuple[tuple[str, Optional[str]], ...] = ()

    @property
    def ok(self) -> bool:
        return not self.missing and not self.orphan and not self.vacuous


# ── AST walker ──────────────────────────────────────────────────────────────


def scan_requires_tags(test_files: list[Path]) -> list[RequiresTag]:
    """Return every ``@requires(...)`` tag found in *test_files*.

    Each tag also carries ``assert_count`` — the number of substantive
    ``ast.Assert`` nodes reachable from the decorated function body.
    Zero-count tags are vacuous (promise without proof); the caller
    surfaces them as a distinct failure category (RTL-P2.428).

    Same-file helper functions (RTL-P2.443) are followed: a test whose
    body is ``_verify_mux(dut)`` still counts the asserts inside
    ``_verify_mux`` when that helper is defined in the same file.
    Cross-module calls are NOT chased — walking arbitrary imports is
    a rathole and a different class of tool.
    """
    tags: list[RequiresTag] = []
    for path in test_files:
        try:
            source = path.read_text(encoding="utf-8", errors="ignore")
            tree = ast.parse(source, filename=str(path))
        except (OSError, SyntaxError):
            continue
        # RTL-P2.443 — per-file function table so _count_asserts can chase
        # same-file helper calls.  Keyed by bare function name; we only
        # chase ast.Call nodes whose callee is an ast.Name.  Module-/class-
        # qualified calls (dut.drive(), foo.bar()) stay untracked.
        fn_table: dict[str, ast.AST] = {}
        for n in ast.walk(tree):
            if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)):
                fn_table[n.name] = n
        for node in ast.walk(tree):
            if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                continue
            for deco in node.decorator_list:
                reqs = _extract_requires_args(deco)
                if reqs is None:
                    continue
                assert_count = _count_asserts(node, fn_table=fn_table)
                for rid in reqs:
                    tags.append(RequiresTag(
                        req_id=rid,
                        test_name=node.name,
                        file_path=path,
                        line=node.lineno,
                        assert_count=assert_count,
                    ))
    return tags


def _count_asserts(
    fn_node: ast.AST,
    fn_table: Optional[dict] = None,
    _visited: Optional[frozenset] = None,
) -> int:
    """Count *substantive* ``ast.Assert`` nodes reachable from *fn_node*.

    RTL-P2.438 upgrade — not every `assert` earns the tag.  An assertion
    whose test expression is a compile-time tautology (``assert True``,
    ``assert 1``, ``assert x == x``, ``assert x or True``) passes the
    simulator but proves nothing about the DUT.  Counting them would let
    a test author dodge the vacuous-tag gate by dropping in a lying
    assertion.

    Trivial patterns skipped:

    - ``assert <truthy constant>``   — ``True``, any non-zero number,
      non-empty string / bytes.
    - ``assert <name> == <same name>`` / ``is`` / ``is not`` — self-comparison.
    - ``assert <X> or True`` / ``assert <X> or <truthy>``  — always-truthy
      ``BoolOp``.

    RTL-P2.443 — when *fn_table* is provided (maps bare function names to
    their ``ast.FunctionDef`` / ``ast.AsyncFunctionDef`` nodes, scoped to
    a single file), ``ast.Call`` nodes whose callee is a bare
    ``ast.Name`` (e.g. ``_verify_mux(dut)``) are chased into the callee
    and their asserts counted too.  ``_visited`` guards recursion.

    Cross-module calls (``foo.bar(dut)``), method calls (``dut.drive()``),
    and calls to names not present in *fn_table* are NOT chased — walking
    arbitrary imports is a rathole and a different class of tool.
    """
    if _visited is None:
        _visited = frozenset()

    count = 0
    for sub in ast.walk(fn_node):
        if isinstance(sub, ast.Assert):
            if not _is_trivial_assertion(sub):
                count += 1
        elif (
            fn_table is not None
            and isinstance(sub, ast.Call)
            and isinstance(sub.func, ast.Name)
        ):
            name = sub.func.id
            if name in fn_table and name not in _visited:
                count += _count_asserts(
                    fn_table[name],
                    fn_table=fn_table,
                    _visited=_visited | {name},
                )
    return count


def _is_trivial_assertion(node: ast.Assert) -> bool:
    """Return True when the assertion's test proves nothing (RTL-P2.438).

    Trivial patterns:

    - ``assert <truthy constant>``  — literal bool / number / non-empty str.
    - ``assert <name> == <same name>`` and ``is`` / ``is not`` variants.
    - ``assert ... or True`` — a ``BoolOp(Or)`` containing any always-truthy
      operand collapses to unconditionally True.
    """
    return _is_always_truthy(node.test)


def _is_always_truthy(expr: ast.AST) -> bool:
    """Recursively decide whether *expr* evaluates truthy at compile time."""
    if isinstance(expr, ast.Constant):
        # True, non-zero int/float, non-empty str/bytes.
        val = expr.value
        if isinstance(val, bool):
            return val is True
        if isinstance(val, (int, float)):
            return val != 0
        if isinstance(val, (str, bytes)):
            return len(val) > 0
        # None → falsy, not trivial (assert None actually fails — user bug, not vacuous).
        return False

    # Self-comparison: x == x / x is x / x is not x (last is always False → not trivial).
    if isinstance(expr, ast.Compare) and len(expr.ops) == 1 and len(expr.comparators) == 1:
        op = expr.ops[0]
        left = expr.left
        right = expr.comparators[0]
        if isinstance(op, (ast.Eq, ast.Is)) and _same_name(left, right):
            return True

    # BoolOp(Or, ...) — if any operand is always truthy, the whole expression is.
    if isinstance(expr, ast.BoolOp) and isinstance(expr.op, ast.Or):
        return any(_is_always_truthy(v) for v in expr.values)

    return False


def _same_name(a: ast.AST, b: ast.AST) -> bool:
    """Return True when both nodes reference the same simple name."""
    return (
        isinstance(a, ast.Name)
        and isinstance(b, ast.Name)
        and a.id == b.id
    )


def _extract_requires_args(node: ast.AST) -> Optional[list[str]]:
    """If *node* is a ``@requires("REQ-1", ...)`` call, return the string args."""
    if not isinstance(node, ast.Call):
        return None
    func = node.func
    name: Optional[str] = None
    if isinstance(func, ast.Name):
        name = func.id
    elif isinstance(func, ast.Attribute):
        name = func.attr
    if name != "requires":
        return None
    out: list[str] = []
    for arg in node.args:
        if isinstance(arg, ast.Constant) and isinstance(arg.value, str):
            out.append(arg.value)
    return out if out else None


# ── Public API ──────────────────────────────────────────────────────────────


def coverage_for_ip(
    ip_dir: Path,
    tests_root: Optional[Path] = None,
    req_path: Optional[Path] = None,
) -> CoverageReport:
    """Check one IP's requirements.yml against cocotb tests tagged with
    ``@requires``.

    Parameters
    ----------
    ip_dir : Path
        Directory containing ``requirements.yml``.
    tests_root : Path, optional
        Root of the cocotb test tree to search.  Defaults to
        ``ip_dir.parent / "tests"`` if present, else the caller should
        supply one explicitly.
    req_path : Path, optional
        Explicit path to the requirements.yml (RTL-P2.433).  When an
        IP's ip.yml declares ``requirements: <path>`` the discovery
        walker forwards that resolved path here so the contract file
        can live outside the IP directory.  Defaults to
        ``ip_dir / "requirements.yml"``.
    """
    ip_dir = Path(ip_dir)
    if req_path is None:
        req_path = ip_dir / "requirements.yml"
    requirements = load_requirements(req_path)
    declared = [f.id for f in requirements.functional_contract]
    req_sources = tuple((f.id, f.source) for f in requirements.functional_contract)

    if tests_root is None:
        # RTL-P2.441 — honour the IP's own declared test dir first.  An
        # ip.yml that sets ``build.simulation.test_dir`` knows where its
        # cocotb tests live; the hardcoded fallback would silently miss
        # them and report every REQ as missing.
        declared_tests = _tests_dir_from_ip_yml(ip_dir)
        if declared_tests is not None:
            tests_root = declared_tests
        else:
            # Sensible default: <ip_dir>/tests or <ip_dir>/sim/tests.
            for candidate in (ip_dir / "tests", ip_dir / "sim" / "tests", ip_dir):
                if candidate.is_dir():
                    tests_root = candidate
                    break
            else:
                tests_root = ip_dir
    tests_root = Path(tests_root)

    test_files = _discover_test_files(tests_root)
    tags = scan_requires_tags(test_files)

    declared_set = set(declared)
    tag_ids = {t.req_id for t in tags}

    # RTL-P2.428: a REQ is "vacuous" when every tag pointing at it is on a
    # test with zero ast.Assert nodes — the tag is a promise without a
    # proof.  A REQ with at least ONE non-vacuous tagged test is covered
    # honestly; vacuous is strictly when ALL the tagged tests are
    # assertion-free.  That way a REQ anchored by both a vacuous stub and
    # a real test is considered covered.
    vacuous: set[str] = set()
    for rid in declared_set & tag_ids:
        rid_tags = [t for t in tags if t.req_id == rid]
        if rid_tags and all(t.assert_count == 0 for t in rid_tags):
            vacuous.add(rid)

    # "covered" excludes vacuous — we do not count a lying tag as proof.
    covered = (declared_set & tag_ids) - vacuous

    return CoverageReport(
        ip=requirements.ip,
        requirements_path=req_path,
        tests_dir=tests_root,
        declared_reqs=tuple(declared),
        tags=tuple(tags),
        covered=tuple(sorted(covered)),
        missing=tuple(sorted(declared_set - tag_ids)),
        orphan=tuple(sorted(tag_ids - declared_set)),
        vacuous=tuple(sorted(vacuous)),
        req_sources=req_sources,
    )


def coverage_for_project(
    root: Path,
    tests_root: Optional[Path] = None,
) -> list[CoverageReport]:
    """Walk *root*, return one :class:`CoverageReport` per IP.

    For each ``requirements.yml`` discovered under *root* (ip.yml-driven,
    with fs-walk fallback — RTL-P2.431), look for tests at
    ``<tests_root>/<ip_name>/`` (if *tests_root* given) or at the
    per-IP default locations.  The explicit requirements path is
    forwarded to :func:`coverage_for_ip` so a requirements.yml declared
    by ip.yml can live outside the IP directory.
    """
    from sdk.cli.requirements import discover_requirements

    reports: list[CoverageReport] = []
    for req_path in discover_requirements(root):
        ip_dir = req_path.parent
        ip_name = load_requirements(req_path).ip
        if tests_root is not None:
            per_ip_tests = tests_root / ip_name
        else:
            per_ip_tests = None
        reports.append(coverage_for_ip(
            ip_dir, tests_root=per_ip_tests, req_path=req_path,
        ))
    return reports


@dataclass(frozen=True)
class ProjectCoverageTree:
    """Tree-shaped coverage result (RTL-P2.433).

    Mirrors :class:`sdk.engine.contract_check.ProjectContractTree`:
    aggregates an optional project-level :class:`CoverageReport` (when
    project.yml declares a ``requirements:`` pointer) with one report
    per IP discovered under the project root.  ``ok`` folds every
    report into a single union signal suitable for CLI exit codes.
    """

    project_report: Optional[CoverageReport]
    ip_reports: tuple[CoverageReport, ...]

    @property
    def ok(self) -> bool:
        """True iff every report (project + per-IP) is passing."""
        if self.project_report is not None and not self.project_report.ok:
            return False
        return all(r.ok for r in self.ip_reports)

    @property
    def all_reports(self) -> tuple[CoverageReport, ...]:
        """Flat tuple — project first (if any), then IPs in discovery order."""
        if self.project_report is None:
            return self.ip_reports
        return (self.project_report,) + self.ip_reports


def coverage_tree_for_project(
    root: Path,
    tests_root: Optional[Path] = None,
    project_yml_path: Optional[Path] = None,
) -> ProjectCoverageTree:
    """Run coverage for the project-level contract + every IP.

    Parameters
    ----------
    root
        Filesystem root to scan for ip.yml / requirements.yml.
    tests_root
        Root of the cocotb test tree.  Per-IP coverage still nests one
        level under this when set (``<tests_root>/<ip_name>/``); the
        project-level report searches it as-is so the project-top tests
        can live at the root of the tree.
    project_yml_path
        Path to ``project.yml`` (or a target file).  When provided and
        the file declares a ``requirements:`` pointer, the project's
        top-level REQ coverage is reported alongside per-IP reports.

    Returns
    -------
    ProjectCoverageTree
        Aggregated tree; ``tree.ok`` is the union signal.
    """
    from sdk.cli.requirements import discover_project_requirements

    root = Path(root).resolve()

    project_report: Optional[CoverageReport] = None
    proj_req_path: Optional[Path] = None
    if project_yml_path is not None:
        proj_req_path = discover_project_requirements(project_yml_path, root)
        if proj_req_path is not None:
            project_report = coverage_for_ip(
                root,
                tests_root=tests_root,
                req_path=proj_req_path,
            )

    ip_reports = [
        r for r in coverage_for_project(root, tests_root=tests_root)
        if proj_req_path is None or r.requirements_path != proj_req_path
    ]
    return ProjectCoverageTree(
        project_report=project_report,
        ip_reports=tuple(ip_reports),
    )


def format_report(report: CoverageReport) -> str:
    """Render *report* as a human-readable block.

    Inherited REQs are annotated with their source library so callers
    can see where each invariant came from.
    """
    sources = dict(report.req_sources)
    vacuous_set = set(report.vacuous)
    marker = "[OK]" if report.ok else "[FAIL]"
    header = (
        f"{marker} {report.ip}: "
        f"covered={len(report.covered)}/{len(report.declared_reqs)}"
    )
    if report.missing:
        header += f", missing={len(report.missing)}"
    if report.vacuous:
        header += f", vacuous={len(report.vacuous)}"
    if report.orphan:
        header += f", orphan={len(report.orphan)}"
    lines = [header]
    for rid in report.declared_reqs:
        hits = [t.test_name for t in report.tags if t.req_id == rid]
        if rid in vacuous_set:
            sym = "∅"   # promise without proof
        elif hits:
            sym = "✓"
        else:
            sym = "✗"
        src = sources.get(rid)
        suffix = f" [from {src}]" if src else ""
        if rid in vacuous_set:
            hit_text = f"{', '.join(hits)} (no assertions — vacuous tag)"
        else:
            hit_text = ', '.join(hits) if hits else '(uncovered)'
        lines.append(
            f"  {sym} {rid}{suffix}: {hit_text}"
        )
    for rid in report.orphan:
        lines.append(
            f"  ? {rid}: orphan — tagged in tests but not in requirements.yml"
        )
    return "\n".join(lines)


def format_tree(tree: ProjectCoverageTree) -> str:
    """Render a :class:`ProjectCoverageTree` as a tree-shaped block (RTL-P2.433).

    Project-level report (if any) appears first with a ``project:`` label;
    per-IP reports follow.  Empty trees render a single explanatory line.
    """
    if tree.project_report is None and not tree.ip_reports:
        return "(no contracts declared — add requirements: to project.yml or ip.yml)"

    lines: list[str] = []
    if tree.project_report is not None:
        lines.append(f"project: {format_report(tree.project_report)}")
    for r in tree.ip_reports:
        lines.append(f"ip:      {format_report(r)}")
    return "\n".join(lines)


# ── Internals ───────────────────────────────────────────────────────────────


def _discover_test_files(tests_root: Path) -> list[Path]:
    """Find Python test files under *tests_root*, honouring excludes."""
    if not tests_root.is_dir():
        return []
    candidates = sorted(tests_root.rglob("test_*.py"))

    # Route through the canonical exclude filter when available.
    try:
        from sdk.cli.env_setup import (
            filter_excluded_test_files,
            resolve_sim_exclude_dirs,
        )
        candidates = filter_excluded_test_files(
            candidates, tests_root, resolve_sim_exclude_dirs()
        )
    except (ImportError, Exception):
        # Running outside a project.yml context (e.g. unit tests with tmp_path)
        # — keep the unfiltered list.
        pass

    return candidates


def _tests_dir_from_ip_yml(ip_dir: Path) -> Optional[Path]:
    """Return the IP's declared ``build.simulation.test_dir``, or ``None``.

    RTL-P2.441 — part of the ip.yml mini-project story: an IP that
    knows where its cocotb tests live should be able to say so and
    have coverage-map honour it without the author also setting a
    CLI flag or project.yml pointer.  Returns an absolute Path when
    ip.yml declares the field AND the target directory exists; else
    ``None`` so the caller falls back to default discovery.
    """
    import yaml as _yaml

    ip_yml = Path(ip_dir) / "ip.yml"
    if not ip_yml.is_file():
        return None
    try:
        with open(ip_yml) as f:
            raw = _yaml.safe_load(f) or {}
    except (OSError, _yaml.YAMLError):
        return None
    if not isinstance(raw, dict):
        return None

    from sdk.engine.ip_yml import normalize_ip_yml, simulation_config
    try:
        norm = normalize_ip_yml(raw)
    except (TypeError, ValueError):
        return None
    sim_cfg = simulation_config(norm) or {}
    rel = sim_cfg.get("test_dir")
    if not isinstance(rel, str) or not rel.strip():
        return None

    resolved = (Path(ip_dir) / rel.strip()).resolve()
    if not resolved.is_dir():
        return None
    return resolved
