#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

import argparse
import ast
from pathlib import Path


def _is_cocotb_test(path):
    """Return True if the Python file imports cocotb anywhere.

    Parses the module with ``ast`` rather than eyeballing the first N
    lines, so imports that land past a long module docstring or a
    license header still register (RTL-P2.344 — the sdi_crossbar_nxm
    testbench carried a 35-line docstring and went invisible to
    ``rr sim scan-tests``).  Malformed or unreadable files are treated
    as non-cocotb.
    """
    try:
        source = Path(path).read_text(encoding="utf-8", errors="ignore")
        tree = ast.parse(source)
    except (OSError, SyntaxError, ValueError):
        return False

    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            if any(alias.name.split(".", 1)[0] == "cocotb" for alias in node.names):
                return True
        elif isinstance(node, ast.ImportFrom):
            # node.module is None for `from . import X`; only a real
            # module name can be cocotb.
            if node.module and node.module.split(".", 1)[0] == "cocotb":
                return True
    return False


def scan_tests(search_dirs, filter_pat=None, exclude_dirs=None):
    """
    Scans given directories for Cocotb test files (test_*.py).
    Returns a list of (module_name, file_path) tuples.

    If *filter_pat* is given, only tests whose module name contains
    that substring (case-insensitive) are shown.

    If *exclude_dirs* is given, files under those subdirectories
    (relative to each search dir) are excluded from results.
    """
    tests = []
    skipped = []
    seen_modules = set()
    filter_lower = filter_pat.lower() if filter_pat else None
    exclude_dirs = exclude_dirs or []

    print(f"\n🔍 Scanning for Cocotb tests in: {', '.join(str(d) for d in search_dirs)}")
    if filter_pat:
        print(f"   Filter: {filter_pat}")
    if exclude_dirs:
        print(f"   Excluding: {', '.join(exclude_dirs)} (from simulation.exclude_dirs)")
    print()
    print(f"{'MODULE':<35} {'LOCATION':<50} {'STATUS':<18} {'COMMAND'}")
    print("-" * 140)

    for root_dir in search_dirs:
        root_path = Path(root_dir).resolve()
        if not root_path.exists():
            continue

        for path in root_path.rglob("test_*.py"):
            short_name = path.stem  # e.g., test_uart_sniffer

            if short_name in seen_modules:
                continue
            seen_modules.add(short_name)

            if filter_lower and filter_lower not in short_name.lower():
                continue

            # Check if path falls under an excluded directory
            try:
                rel = path.resolve().relative_to(root_path)
            except ValueError:
                rel = Path(path.name)

            excluded = False
            for exc in exclude_dirs:
                exc_parts = Path(exc).parts
                if rel.parts[:len(exc_parts)] == exc_parts:
                    excluded = True
                    break

            if excluded:
                continue

            # Show relative location for context
            try:
                rel_location = path.relative_to(root_path.parent.parent)
            except ValueError:
                rel_location = path.name

            # Check if this is actually a cocotb test
            if _is_cocotb_test(path):
                cmd = f"rr sim {short_name}"
                status = ""
                print(f"{short_name:<35} {str(rel_location):<50} {'':18} {cmd}")
                tests.append((short_name, cmd))
            else:
                status = "[skip: not cocotb]"
                print(f"{short_name:<35} {str(rel_location):<50} {status:<18}")
                skipped.append(short_name)

    print("-" * 140)
    msg = f"✅ Found {len(tests)} cocotb tests."
    if skipped:
        msg += f"  ({len(skipped)} non-cocotb files skipped)"
    print(f"{msg}\n")


def main():
    """CLI entry point for test scanner."""
    parser = argparse.ArgumentParser(description="Scan for Cocotb tests.")
    parser.add_argument("--dirs", nargs="+", help="Directories to scan", required=True)
    parser.add_argument("--filter", dest="filter_pat", default=None, help="Substring filter on test names")
    parser.add_argument("--exclude-dir", action="append", dest="exclude_dirs", default=[], help="Subdirectory to exclude (relative to search dir)")
    args = parser.parse_args()

    scan_tests(args.dirs, filter_pat=args.filter_pat, exclude_dirs=args.exclude_dirs)


if __name__ == "__main__":
    main()
