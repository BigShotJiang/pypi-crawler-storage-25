# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT
"""ltmeta — .ltmeta.json sidecar emitter for RouteWave enrichment.

Walks a cocotb DUT hierarchy and extracts every constant (Verilog parameter,
VHDL generic, VHDL constant) into a JSON sidecar file placed alongside the
simulation VCD.  RouteWave auto-detects and loads the sidecar on open,
displaying resolved values inline in the scope tree (🔒 BC_ADDRESS = 1024).

Schema (v1, locked):

    {
      "version": 1,
      "generator": "routertl-cocotb/1.0",
      "constants": {
        "tb.dut.WIDTH":  {"value": 8},
        "tb.dut.DEPTH":  {"value": 16, "type": "integer"}
      }
    }

Key = full hierarchical path as it appears in the VCD $scope tree.
The consumer does exact string matching on Channel::getName() — no fuzzy match.

GHDL / VHPI caveat
-------------------
GHDL may not expose VHDL generics or constants through the standard handle
walk.  If the DUT walk yields zero constants the sidecar is still written
(with an empty ``constants`` dict) so RouteWave opens cleanly — no crash,
just no enrichment.  This is intentional graceful degradation.
"""

from __future__ import annotations

import json
import os
from pathlib import Path

# ---------------------------------------------------------------------------
# VPI / VHPI type probing
# ---------------------------------------------------------------------------

#: VPI integer type codes for parameters (Verilog) and constants (VHDL)
_VPI_PARAMETER_TYPES = frozenset({"vpiParameter", "vpiConstant"})

#: Substrings found in cocotb's internal ``_typestr`` for VHDL generics and
#: constants.  Case-insensitive check.
_VHDL_CONSTANT_KEYWORDS = ("generic", "constant")


def _is_constant(handle: object) -> bool:  # noqa: ANN001
    """Return True if *handle* represents a design constant that should be
    captured in the sidecar.

    Detects:
    - Verilog  ``parameter`` — cocotb 2.x: ``handle.is_const`` (GPI layer)
    - Verilog  ``parameter`` — older: VPI type string ``vpiParameter``
    - VHDL     ``generic``   (VPI type ``vpiParameter`` or ``_typestr``)
    - VHDL     ``constant``  (VPI type ``vpiConstant``  or ``_typestr``)

    Priority:
    1. ``is_const`` property (cocotb 2.x / Verilator 5.x): most reliable.
    2. ``_type`` string matching ``vpiParameter`` / ``vpiConstant``:
       works for cocotb 1.x and NVC/GHDL under standard VPI.
    3. ``_typestr`` keyword sniff: VHDL VHPI fallback (GHDL / NVC).
    """
    # --- Highest priority: cocotb 2.x GPI is_const flag --------------------
    # is_const=True  → definitively a constant (Verilator 5.x, Icarus), short-circuit.
    # is_const=False → may be a port *or* simply mean the backend doesn't set the flag
    #                  (NVC / GHDL / older cocotb), so fall through to _type / _typestr.
    is_const = getattr(handle, "is_const", None)
    if is_const is True:
        return True

    # --- Primary: cocotb 1.x / VPI string type attribute -------------------
    t = getattr(handle, "_type", None)
    if t is not None:
        return str(t) in _VPI_PARAMETER_TYPES

    # --- Fallback: cocotb internal typestr (VHDL via VHPI / older backends) -
    ts = (getattr(handle, "_typestr", None) or "").lower()
    if ts:
        return any(kw in ts for kw in _VHDL_CONSTANT_KEYWORDS)

    return False



# ---------------------------------------------------------------------------
# Hierarchy walker
# ---------------------------------------------------------------------------


def _walk(handle: object, path: str, result: dict) -> None:
    """Recursively walk the DUT hierarchy and collect constant values.

    Numeric constants (int or float) are added to *result*.
    Non-numeric values are silently skipped — this keeps the sidecar clean
    when string generics or enumeration constants appear in the hierarchy.
    """
    try:
        children = list(handle)  # may raise TypeError for leaf nodes
    except TypeError:
        return  # leaf node — not iterable

    for child in children:
        child_name = getattr(child, "_name", None) or getattr(child, "name", "?")
        child_path = f"{path}.{child_name}"

        if _is_constant(child):
            try:
                raw = child.value
                float_val = float(raw)
                int_val = int(float_val)
                # Use int when the value is exactly whole (e.g. 8.0 → 8),
                # but preserve float precision for fractional values (e.g. 3.14).
                if float_val == int_val:
                    result[child_path] = {"value": int_val}
                else:
                    result[child_path] = {"value": float_val}
            except (TypeError, ValueError):
                pass  # non-numeric constant — skip gracefully
        else:
            _walk(child, child_path, result)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def emit_ltmeta(
    dut: object,
    vcd_path: "str | os.PathLike",
    python_generics: "dict | None" = None,
) -> int:
    """Write a ``.ltmeta.json`` sidecar next to *vcd_path*.

    Parameters
    ----------
    dut:
        The cocotb top-level DUT handle (``cocotb.top``), or ``None`` when
        called from a post-sim hook (outside the cocotb subprocess).
    vcd_path:
        Path to the VCD/FST file produced by the simulation.
    python_generics:
        Optional dict of ``{name: value}`` pairs known at the Python level
        (e.g. the ``generics`` kwarg passed to ``run_simulation()``).  This
        is the **only** way to populate constants for VHDL sims under NVC or
        GHDL, where the VHPI bridge does not expose generics during the VPI
        hierarchy walk.  Keys are prefixed with the DUT/top-level name
        (e.g. ``"edge_detector.G_EDGE_TYPE"``).  VPI-walk results take
        precedence over *python_generics* on key collision.

    Returns
    -------
    int
        Number of constants written to the sidecar.
    """
    vcd_path = Path(vcd_path)
    sidecar_path = vcd_path.with_name(vcd_path.stem + ".ltmeta.json")

    constants: dict = {}

    # --- Python-level generics (VHDL / NVC / GHDL path) --------------------
    # Populate first so the VPI walk (below) can override on collision.
    if python_generics:
        top_name = (
            (getattr(dut, "_name", None) or getattr(dut, "name", None))
            if dut is not None
            else vcd_path.stem  # fallback: waveform stem as entity name
        )
        for k, v in python_generics.items():
            try:
                float_val = float(v)
                int_val = int(float_val)
                numeric = int_val if float_val == int_val else float_val
                constants[f"{top_name}.{k}"] = {"value": numeric}
            except (TypeError, ValueError):
                constants[f"{top_name}.{k}"] = {"value": str(v)}

    # --- VPI hierarchy walk (Verilog / Verilator / Icarus path) -------------
    if dut is not None:
        dut_name = getattr(dut, "_name", None) or getattr(dut, "name", "dut")
        _walk(dut, dut_name, constants)

    # --- Timing anchors (ltsync integration) ---------------------------------
    anchors: list = []
    try:
        from sdk.engine.ltsync import clear_anchors, get_anchors

        anchors = get_anchors()
        clear_anchors()
    except ImportError:
        pass  # ltsync not available — no anchors

    payload = {
        "version": 2,
        "generator": "routertl-cocotb/2.0",
        "constants": constants,
        "anchors": anchors,
    }

    sidecar_path.parent.mkdir(parents=True, exist_ok=True)
    with open(sidecar_path, "w", encoding="utf-8") as fh:
        json.dump(payload, fh, indent=2)

    return len(constants)
