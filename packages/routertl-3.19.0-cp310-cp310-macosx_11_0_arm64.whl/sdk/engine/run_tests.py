#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

import argparse
import os
import subprocess
import sys
from pathlib import Path

from sdk.cli.console import console as _rt_con
from sdk.engine.git_utils import filter_git_tracked


def run_test(test_file):
    """Runs a single test file and returns True if passed, False otherwise."""

    # Generate log file path
    # If TB_LOG_DIR is set (from Common.mk -> ROUTERTL_LOGS_DIR), use it.
    # Otherwise use a default 'logs' dir in CWD
    log_dir_env = os.environ.get("ROUTERTL_LOGS_DIR", "logs")
    log_dir = Path(log_dir_env).resolve()
    log_dir.mkdir(parents=True, exist_ok=True)

    test_name = Path(test_file).stem
    log_file_path = log_dir / f"{test_name}.log"

    # Create env copy — with GIT_* vars stripped (RTL-P1.44).
    #
    # When `git commit` runs the pre-commit hook, it exports GIT_DIR,
    # GIT_INDEX_FILE, and GIT_WORK_TREE pointing at the committing repo.
    # Those propagate through Make → run_tests.py → the test subprocess.
    # Tests that do `git init` / `git config user.email X` in a tempdir
    # (even with cwd=tmp) then target the committing repo's config via
    # the inherited GIT_DIR, silently polluting the shared submodule
    # config with ``[user] email=test@test.com name=Test User bare=true``.
    # Git at commit time reads that polluted config; if core.bare or
    # core.worktree have been corrupted, it snapshots the wrong tree
    # (the "catastrophic 895-file deletion commit" failure mode we
    # hit three times on 2026-04-19).  Strip here so every test starts
    # from a clean git env without needing per-test discipline.
    env = {
        k: v for k, v in os.environ.items()
        if k not in ("GIT_DIR", "GIT_INDEX_FILE", "GIT_WORK_TREE")
    }

    # Prefer venv Python when VIRTUAL_ENV is set — handles PATH shadowing
    # where ~/.local/bin/rr overrides .venv/bin/rr
    venv = os.environ.get("VIRTUAL_ENV")
    python_exe = sys.executable
    if venv:
        venv_py = Path(venv) / "bin" / "python3"
        if venv_py.exists():
            python_exe = str(venv_py)

    print(f"running {test_file} (log: {log_file_path})...")

    with open(log_file_path, "w") as log_file:
        try:
            cmd = [python_exe, str(test_file)]
            # Use Popen to allow real-time streaming to BOTH console and file
            process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                env=env,
                text=True,
                bufsize=1,  # Line buffered
            )

            # Stream output
            summary_buffer = []
            test_failed_by_summary = False
            for line in process.stdout:
                # Print to console
                sys.stdout.write(line)
                sys.stdout.flush()
                # Write to log file
                log_file.write(line)
                log_file.flush()

                # Capture cocotb summary table
                clean_line = None
                if "cocotb.regression" in line:
                    clean_line = line.split("cocotb.regression")[-1].strip()
                elif line.strip().startswith("**"):
                    clean_line = line.strip()

                if clean_line and (clean_line.startswith("****") or clean_line.startswith("** ")):
                    # Filter out simulator noise (Note/Warning/Error lines that also use stars)
                    if any(x in clean_line for x in ["Note:", "Warning:", "ERROR:"]):
                        continue

                    # Detect failures in the summary line (TESTS=n PASS=n FAIL=n SKIP=n)
                    import re

                    if "TESTS=" in clean_line:
                        match = re.search(r"(FAIL|ERROR)=(\d+)", clean_line)
                        if match and int(match.group(2)) > 0:
                            test_failed_by_summary = True

                    # Clean up .00 decimals for simplicity (replace with spaces to maintain alignment)
                    clean_line = clean_line.replace(".00 ", "    ")
                    summary_buffer.append(clean_line)

            process.wait()

            # RTL-P1.42: detect silent no-op runs.  A real cocotb invocation
            # always emits a final summary line containing "TESTS=n PASS=n …".
            # If the process exits 0 but no such line was observed, the
            # test file was imported without the cocotb runner ever being
            # driven (e.g. project sim.sources was empty, or the test was
            # discovered but not actually executable).  Reporting PASSED in
            # that case is a silent failure and violates no-silent-failures.
            #
            # RTL-P1.44: the "no summary = fail" rule must ONLY apply to
            # cocotb tests.  Plain pytest / unittest files in
            # sdk/engine/tests/ never emit a cocotb summary — applying the
            # rule to them marked every pure-Python regression test as
            # failed, forced every routertl commit to use --no-verify, and
            # masked this exact regression for weeks.  Gate the check on
            # is_cocotb_test(); trust the exit code for everything else.
            try:
                from sdk.cli.env_setup import is_cocotb_test
                is_cocotb = is_cocotb_test(Path(test_file))
            except ImportError:
                # Fallback: if env_setup isn't importable, be conservative
                # and require a cocotb summary — matches pre-P1.44 behaviour.
                is_cocotb = True

            saw_cocotb_summary = any("TESTS=" in line for line in summary_buffer)

            if process.returncode == 0 and not test_failed_by_summary:
                if is_cocotb and not saw_cocotb_summary:
                    _rt_con.print(
                        f"[red]❌ {test_name} FAILED "
                        f"(no cocotb summary emitted — test did not run)[/]"
                    )
                    print(f"  > Check log at: {log_file_path}")
                    return False, summary_buffer
                _rt_con.print(f"[green]✅ {test_name} PASSED[/]")
                return True, summary_buffer

            if process.returncode != 0:
                reason = "exit code"
            elif test_failed_by_summary:
                reason = "cocotb failures detected"
            else:
                reason = "no cocotb summary emitted — test did not run"
            _rt_con.print(f"[red]❌ {test_name} FAILED ({reason})[/]")
            print(f"  > Check log at: {log_file_path}")
            return False, summary_buffer

        except OSError as e:
            import logging
            import traceback as _tb

            logging.debug("Test execution failed:\n%s", _tb.format_exc())
            _rt_con.print(f"[red] ERROR: {e}[/]")
            return False, None


def main():
    """CLI entry point for test runner."""
    parser = argparse.ArgumentParser(description="Auto-discover and run RouteRTL simulations")
    parser.add_argument("--dir", required=True, help="Directory to search for tests")
    parser.add_argument("--pattern", action="append", help="File pattern(s) to match (can be used multiple times)")
    parser.add_argument("--exclude", action="append", help="File pattern(s) or module name(s) to exclude")
    parser.add_argument("--exclude-dir", action="append", dest="exclude_dirs", help="Subdirectory to exclude from discovery (relative to --dir)")
    parser.add_argument("--cocotb-only", action="store_true", help="Only run files that import cocotb (skip pure Python tests)")
    args = parser.parse_args()

    search_dir = Path(args.dir)
    if not search_dir.exists():
        print(f"Error: Directory {search_dir} does not exist.")
        sys.exit(1)

    # Patterns to search
    patterns = args.pattern if args.pattern else ["test_*.py"]
    test_files_set = set()

    for pattern in patterns:
        # Check if pattern looks like a python module path (e.g., tests.units.test_edge_counter.py)
        # Common.mk appends .py, so we might get "tests.units.test_edge_counter.py"
        # We need to convert this to "tests/units/test_edge_counter.py" relative to search_dir?

        # Heuristic: if pattern has dots (excluding .py extension), try replacing dots with slashes
        current_matches = []
        if pattern.endswith(".py") and pattern.count(".") > 1:
            stem = pattern[:-3]  # remove .py
            parts = stem.split(".")
            if parts[0] == "tests":
                # Strip 'tests' and try
                rel_path = str(Path(*parts[1:]).with_suffix(".py"))
                candidate = search_dir / rel_path
                if candidate.exists():
                    current_matches = [candidate]

            if not current_matches:
                # Try full path conversion just in case
                candidate = search_dir / str(Path(*parts).with_suffix(".py"))
                if candidate.exists():
                    current_matches = [candidate]

        # Fallback to standard glob if no special module match found
        if not current_matches:
            current_matches = list(search_dir.rglob(pattern))

        for f in current_matches:
            test_files_set.add(f.resolve())

    # Filter excluded directories (from project.yml simulation.exclude_dirs)
    if args.exclude_dirs:
        try:
            from sdk.cli.env_setup import filter_excluded_test_files
        except ImportError:
            filter_excluded_test_files = None
        if filter_excluded_test_files is not None:
            test_files_set = set(filter_excluded_test_files(
                list(test_files_set), search_dir, args.exclude_dirs
            ))

    # Filter out non-cocotb test files (only when --cocotb-only is set)
    if args.cocotb_only:
        try:
            from sdk.cli.env_setup import is_cocotb_test
        except ImportError:
            is_cocotb_test = None
        if is_cocotb_test is not None:
            non_cocotb = {f for f in test_files_set if not is_cocotb_test(f)}
            if non_cocotb:
                for f in sorted(non_cocotb):
                    print(f"ℹ️  Skipping non-cocotb test: {f.name}")
                test_files_set -= non_cocotb

    # Deduplicate by stem: when multiple files share the same stem
    # (e.g. tests/test_arbiter.py and tests/sniffer/infra/test_arbiter.py),
    # keep only the shallowest one relative to the search directory.
    # This prevents nested/vendored copies from causing double-runs.
    if len(test_files_set) > 1:
        by_stem = {}
        for f in test_files_set:
            try:
                depth = len(f.relative_to(search_dir.resolve()).parts)
            except ValueError:
                depth = len(f.parts)
            existing = by_stem.get(f.stem)
            if existing is None or depth < existing[1]:
                by_stem[f.stem] = (f, depth)
        deduped = {entry[0] for entry in by_stem.values()}
        if len(deduped) < len(test_files_set):
            removed = test_files_set - deduped
            for r in sorted(removed):
                print(f"ℹ️  Skipping duplicate '{r.stem}' at deeper path: {r}")
            test_files_set = deduped

    # Filter out untracked files — prevents WIP test_*.py from breaking
    # the regression suite (fail-open: if git is unavailable, all files pass)
    pre_filter_count = len(test_files_set)
    filtered = set(filter_git_tracked(list(test_files_set)))

    if filtered:
        test_files_set = filtered
    elif pre_filter_count > 0:
        # Fail-open: filter_git_tracked emptied the whole set.  Two causes:
        #   1. Test file(s) not yet git-tracked (normal for new tests)
        #   2. Poisoned git env (e.g., temporary index during pre-commit hook)
        # Keep the unfiltered candidates to avoid a silent 0-test run.
        s = "s" if pre_filter_count > 1 else ""
        print(
            f"ℹ️  {pre_filter_count} test file{s} not git-tracked — "
            "using unfiltered discovery. Run 'git add' to silence this.",
            flush=True,
        )

    # Filter exclusions
    if args.exclude:
        excluded_files = set()
        for exc in args.exclude:
            # Clean up exclusion pattern
            exc_clean = exc.replace("tests.", "") if exc.startswith("tests.") else exc
            exc_stem = exc_clean[:-3] if exc_clean.endswith(".py") else exc_clean

            for f in test_files_set:
                # Match by filename, stem, or if the stem is part of the path
                if f.name == exc_clean or f.stem == exc_stem or f"{exc_stem}.py" in str(f) or f"/{exc_stem}/" in str(f):
                    excluded_files.add(f)

        test_files_set -= excluded_files

    test_files = sorted(list(test_files_set))

    if not test_files:
        print(f"❌ No tests found in {search_dir} matching {args.pattern}")
        sys.exit(1)

    print(f"Found {len(test_files)} tests in {search_dir}")
    print("=" * 60)

    passed = 0
    failed = 0
    failed_tests = []
    summaries = []

    for test_file in test_files:
        success, summary = run_test(test_file)
        if success:
            passed += 1
        else:
            failed += 1
            failed_tests.append(test_file.name)
        if summary:
            summaries.append((test_file.name, summary))

    print("=" * 60)

    # 📝 Print and Save Final Regression Report
    if summaries:
        log_dir_env = os.environ.get("ROUTERTL_LOGS_DIR", "logs")
        global_summary_path = Path(log_dir_env).resolve() / "regression_summary.txt"

        def _rich_colorize(text):
            """Apply Rich markup to PASS/FAIL in a string."""
            return text.replace(" PASS ", " [green]PASS[/] ").replace(" FAIL ", " [red]FAIL[/] ")

        with open(global_summary_path, "w") as sf:
            report_lines = []
            report_lines.append("\n" + "=" * 97)
            report_lines.append("📊 FINAL REGRESSION REPORT")
            sim_backend = os.environ.get("SIM", "unknown")
            sim_note = f"   Simulator backend: {sim_backend}"
            # Flag when $SIM env var overrides project.yml
            try:
                import yaml as _yaml

                with open("project.yml") as _f:
                    _cfg = _yaml.safe_load(_f) or {}
                yml_sim = (_cfg.get("simulation") or {}).get("simulator")
                if yml_sim and yml_sim != sim_backend:
                    sim_note += f"  ⚠️  (overrides project.yml '{yml_sim}')"
            except (OSError, ValueError):
                import logging

                logging.debug("Failed to read project.yml simulator config", exc_info=True)
            report_lines.append(sim_note)
            report_lines.append("=" * 97)

            for name, lines in summaries:
                report_lines.append(f"\n[ {name} ]")
                report_lines.extend(lines)

            report_lines.append("\n" + "=" * 97)
            report_lines.append(f"TOTAL: {passed} PASSED, {failed} FAILED")
            report_lines.append("=" * 97)

            file_report = "\n".join(report_lines)
            sf.write(file_report)

            # Build console report with colors
            console_report_lines = []
            for line in report_lines:
                if "TOTAL" in line:
                    if "PASSED" in line:
                        line = line.replace("PASSED", "[green]PASSED[/]")
                    if "FAILED" in line and failed > 0:
                        line = line.replace("FAILED", "[red]FAILED[/]")
                console_report_lines.append(_rich_colorize(line))

            _rt_con.print("\n".join(console_report_lines))

        print(f"\n📁 Final report saved to: {global_summary_path}")

    if failed > 0:
        print(f"Failed tests: {', '.join(failed_tests)}")
        sys.exit(1)
    else:
        sys.exit(0)


if __name__ == "__main__":
    main()
