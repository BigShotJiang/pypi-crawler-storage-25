#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
RouteRTL Schematic Beautifier
Injects a themed CSS skin into netlistsvg generated SVGs.
Usage: python3 beautify_svg.py <input.svg> [output.svg] [--skin <name>]
"""

import os
import re
import sys

# ── Skin Library ─────────────────────────────────────────────────
SKINS = {
    "cyberpunk": """  <style>
  svg {
    background-color: #0f172a;
    stroke: #38bdf8;
    stroke-width: 1.5px;
    stroke-linecap: round;
    stroke-linejoin: round;
    fill: none;
  }
  path, line, rect {
    filter: drop-shadow(0px 0px 4px rgba(56, 189, 248, 0.6));
  }
  rect, path {
    fill: #1e293b;
    stroke: #818cf8;
  }
  text {
    fill: #e2e8f0;
    stroke: none;
    font-size: 11px;
    font-weight: 600;
    font-family: 'Inter', 'Segoe UI', system-ui, sans-serif;
    filter: none;
  }
  circle {
    fill: #f472b6 !important;
    stroke: none;
    filter: drop-shadow(0px 0px 4px rgba(244, 114, 182, 0.8));
    r: 3.5px;
  }
  .nodelabel {
    text-anchor: middle;
  }
  .inputPortLabel {
    text-anchor: end;
  }
  .splitjoinBody {
    fill: #38bdf8;
  }
  </style>""",
    "classic": """  <style>
  svg {
    background-color: #ffffff;
    stroke: #333333;
    stroke-width: 1.2px;
    stroke-linecap: round;
    stroke-linejoin: round;
    fill: none;
  }
  rect, path {
    fill: #f8f9fa;
    stroke: #495057;
  }
  text {
    fill: #212529;
    stroke: none;
    font-size: 11px;
    font-weight: 500;
    font-family: 'Inter', 'Segoe UI', system-ui, sans-serif;
  }
  circle {
    fill: #e03131 !important;
    stroke: none;
    r: 3px;
  }
  .nodelabel {
    text-anchor: middle;
  }
  .inputPortLabel {
    text-anchor: end;
  }
  .splitjoinBody {
    fill: #228be6;
  }
  </style>""",
}

DEFAULT_SKIN = "cyberpunk"


def beautify_svg(input_file, output_file=None, skin=None):
    """Apply a themed CSS skin to an SVG file.

    Args:
        input_file: Path to the source SVG.
        output_file: Path to write (defaults to in-place overwrite).
        skin: Skin name from SKINS dict (defaults to DEFAULT_SKIN).
    """
    if output_file is None:
        output_file = input_file

    skin = skin or DEFAULT_SKIN
    if skin not in SKINS:
        print(f"❌ Unknown skin '{skin}'. Available: {', '.join(sorted(SKINS))}")
        sys.exit(1)

    theme_css = SKINS[skin]

    if not os.path.exists(input_file):
        print(f"❌ Error: File '{input_file}' not found.")
        sys.exit(1)

    with open(input_file, "r", encoding="utf-8") as f:
        svg_content = f.read()

    # Find and replace the <style> block
    # netlistsvg generates <style>svg { ... }</style> block at the top
    style_pattern = re.compile(r"<style>.*?</style>", re.DOTALL)

    if style_pattern.search(svg_content):
        beautified_svg = style_pattern.sub(theme_css, svg_content)
    else:
        # If no style tag exists, insert it after the opening <svg> tag
        beautified_svg = re.sub(r"(<svg[^>]*>)", r"\1\n" + theme_css, svg_content, count=1)

    with open(output_file, "w", encoding="utf-8") as f:
        f.write(beautified_svg)

    print(f"✨ Beautified SVG saved to: {output_file} (skin: {skin})")


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="RouteRTL Schematic Beautifier")
    parser.add_argument("input", help="Input SVG file")
    parser.add_argument("output", nargs="?", default=None, help="Output SVG file (default: overwrite input)")
    parser.add_argument(
        "--skin", default=DEFAULT_SKIN,
        choices=sorted(SKINS.keys()),
        help=f"CSS theme to apply (default: {DEFAULT_SKIN})",
    )
    args = parser.parse_args()

    beautify_svg(args.input, args.output, skin=args.skin)
