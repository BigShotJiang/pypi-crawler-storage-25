# SPDX-FileCopyrightText: 2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Migration verification — compare build results between original and migrated projects.

Parses Vivado utilization and timing reports to extract key FPGA metrics,
then produces a side-by-side comparison with delta analysis.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Optional


@dataclass
class ResourceMetric:
    """A single FPGA resource metric."""
    name: str
    used: int
    available: int
    percent: float

    @property
    def delta_str(self):
        return ""


@dataclass
class BuildMetrics:
    """Collected metrics from a Vivado build."""
    label: str = ""
    # Utilization
    clb_luts: Optional[ResourceMetric] = None
    lut_as_logic: Optional[ResourceMetric] = None
    lut_as_memory: Optional[ResourceMetric] = None
    clb_registers: Optional[ResourceMetric] = None
    bram_tile: Optional[ResourceMetric] = None
    ramb36: Optional[ResourceMetric] = None
    ramb18: Optional[ResourceMetric] = None
    uram: Optional[ResourceMetric] = None
    dsps: Optional[ResourceMetric] = None
    bonded_iob: Optional[ResourceMetric] = None
    # Timing
    wns: Optional[float] = None
    tns: Optional[float] = None
    whs: Optional[float] = None
    ths: Optional[float] = None
    timing_met: Optional[bool] = None
    # Bitstream
    bitstream_size: Optional[int] = None
    # Metadata
    design_name: str = ""
    device: str = ""
    tool_version: str = ""


def _parse_util_line(line: str, name_pattern: str) -> Optional[ResourceMetric]:
    """Parse a utilization table row matching name_pattern.

    Expected format:
    | CLB LUTs                   | 63052 |     0 |          0 |    230400 | 27.37 |
    """
    m = re.match(
        r"\|\s*" + name_pattern + r"\s*\|\s*(\d+)\s*\|\s*\d+\s*\|\s*\d*\s*\|\s*(\d+)\s*\|\s*([\d.<]+)\s*\|",
        line,
    )
    if not m:
        return None
    used = int(m.group(1))
    available = int(m.group(2))
    pct_str = m.group(3)
    pct = 0.0 if pct_str.startswith("<") else float(pct_str)
    return ResourceMetric(name=name_pattern, used=used, available=available, percent=pct)


def _parse_bram_tile(line: str) -> Optional[ResourceMetric]:
    """Parse Block RAM Tile which has a float used value (e.g. 141.5)."""
    m = re.match(
        r"\|\s*Block RAM Tile\s*\|\s*([\d.]+)\s*\|\s*\d+\s*\|\s*\d*\s*\|\s*(\d+)\s*\|\s*([\d.<]+)\s*\|",
        line,
    )
    if not m:
        return None
    used = float(m.group(1))
    available = int(m.group(2))
    pct_str = m.group(3)
    pct = 0.0 if pct_str.startswith("<") else float(pct_str)
    return ResourceMetric(name="Block RAM Tile", used=int(used * 2) , available=available * 2, percent=pct)


def parse_utilization_report(path: Path) -> BuildMetrics:
    """Parse a Vivado utilization report into BuildMetrics."""
    metrics = BuildMetrics()
    text = path.read_text(errors="replace")

    # Header metadata
    m = re.search(r"Design\s*:\s*(\S+)", text)
    if m:
        metrics.design_name = m.group(1)
    m = re.search(r"Device\s*:\s*(\S+)", text)
    if m:
        metrics.device = m.group(1)
    m = re.search(r"Tool Version\s*:\s*(.+?)$", text, re.MULTILINE)
    if m:
        metrics.tool_version = m.group(1).strip()

    for line in text.splitlines():
        if metrics.clb_luts is None:
            r = _parse_util_line(line, "CLB LUTs")
            if r:
                metrics.clb_luts = r
                continue
        if metrics.lut_as_logic is None:
            r = _parse_util_line(line, "LUT as Logic")
            if r:
                metrics.lut_as_logic = r
                continue
        if metrics.lut_as_memory is None:
            r = _parse_util_line(line, "LUT as Memory")
            if r:
                metrics.lut_as_memory = r
                continue
        if metrics.clb_registers is None:
            r = _parse_util_line(line, "CLB Registers")
            if r:
                metrics.clb_registers = r
                continue
        if metrics.ramb36 is None:
            r = _parse_util_line(line, r"RAMB36/FIFO\*?")
            if r:
                metrics.ramb36 = r
                continue
        if metrics.ramb18 is None:
            r = _parse_util_line(line, "RAMB18")
            if r:
                metrics.ramb18 = r
                continue
        if metrics.bram_tile is None:
            r = _parse_bram_tile(line)
            if r:
                metrics.bram_tile = r
                continue
        if metrics.uram is None:
            r = _parse_util_line(line, "URAM")
            if r:
                metrics.uram = r
                continue
        if metrics.dsps is None:
            r = _parse_util_line(line, "DSPs")
            if r:
                metrics.dsps = r
                continue
        if metrics.bonded_iob is None:
            r = _parse_util_line(line, "Bonded IOB")
            if r:
                metrics.bonded_iob = r
                continue

    return metrics


def parse_timing_summary(path: Path, metrics: Optional[BuildMetrics] = None) -> BuildMetrics:
    """Parse Vivado timing_summary report to extract WNS/TNS/WHS/THS."""
    if metrics is None:
        metrics = BuildMetrics()

    text = path.read_text(errors="replace")

    # Look for the Design Timing Summary table:
    #     WNS(ns)      TNS(ns)  ...      WHS(ns)      THS(ns)  ...
    #     -------      -------  ...      -------      -------  ...
    #       0.297        0.000  ...        0.010        0.000  ...
    lines = text.splitlines()
    for i, line in enumerate(lines):
        if re.match(r"\s+WNS\(ns\)\s+TNS\(ns\)", line):
            # Skip the dashes line, grab the data line
            if i + 2 < len(lines):
                data_line = lines[i + 2].strip()
                parts = data_line.split()
                if len(parts) >= 6:
                    metrics.wns = float(parts[0])
                    metrics.tns = float(parts[1])
                    metrics.whs = float(parts[4])
                    metrics.ths = float(parts[5])
            break

    if "All user specified timing constraints are met" in text:
        metrics.timing_met = True
    elif "timing constraints are NOT met" in text:
        metrics.timing_met = False

    return metrics


def parse_summary_rpt(path: Path, metrics: Optional[BuildMetrics] = None) -> BuildMetrics:
    """Parse routertl summary.rpt (lighter format) for WNS."""
    if metrics is None:
        metrics = BuildMetrics()

    text = path.read_text(errors="replace")

    m = re.search(r"WNS=([-\d.]+)ns", text)
    if m:
        metrics.wns = float(m.group(1))

    if "closed timing" in text:
        metrics.timing_met = True
    elif "not met" in text.lower():
        metrics.timing_met = False

    return metrics


def find_bitstream_size(search_dir: Path) -> Optional[int]:
    """Find and return the size of the .bit file."""
    for bit_file in search_dir.rglob("*.bit"):
        return bit_file.stat().st_size
    return None


# ── Auto-discovery ──────────────────────────────────────────────


def discover_reference_reports(ref_path: Path) -> BuildMetrics:
    """Auto-discover and parse reports from an original Vivado project.

    Accepts either:
    - A direct path to impl_1/ directory
    - A path to the Vivado project root (searches for impl_1/)
    - A path to a .xpr file
    """
    # Resolve to impl directory
    impl_dir = None
    if ref_path.is_file() and ref_path.suffix == ".xpr":
        ref_path = ref_path.parent

    if ref_path.name == "impl_1":
        impl_dir = ref_path
    else:
        # Search for impl_1
        candidates = list(ref_path.rglob("impl_1"))
        for c in candidates:
            if c.is_dir() and any(c.glob("*_utilization_placed.rpt")):
                impl_dir = c
                break

    if impl_dir is None:
        raise FileNotFoundError(
            f"Cannot find impl_1/ with utilization reports under {ref_path}"
        )

    # Find utilization report
    util_files = list(impl_dir.glob("*_utilization_placed.rpt"))
    if not util_files:
        raise FileNotFoundError(f"No *_utilization_placed.rpt in {impl_dir}")

    metrics = parse_utilization_report(util_files[0])
    metrics.label = "Reference"

    # Find timing report
    timing_files = list(impl_dir.glob("*_timing_summary_routed.rpt"))
    if timing_files:
        parse_timing_summary(timing_files[0], metrics)

    # Bitstream size
    bit_size = find_bitstream_size(impl_dir)
    if bit_size:
        metrics.bitstream_size = bit_size

    return metrics


def discover_current_reports(project_root: Path) -> BuildMetrics:
    """Auto-discover and parse reports from an rr-migrated project."""
    reports_dir = project_root / "reports"

    # Utilization — try rr format first, then Vivado standard
    util_path = reports_dir / "utilization.rpt"
    if not util_path.exists():
        candidates = list(reports_dir.glob("*_utilization_placed.rpt"))
        if candidates:
            util_path = candidates[0]
        else:
            raise FileNotFoundError(f"No utilization report in {reports_dir}")

    metrics = parse_utilization_report(util_path)
    metrics.label = "Migrated"

    # Timing — try timing_summary first, then rr summary.rpt
    timing_files = list(reports_dir.glob("*_timing_summary_routed.rpt"))
    if timing_files:
        parse_timing_summary(timing_files[0], metrics)
    else:
        summary_path = reports_dir / "summary.rpt"
        if summary_path.exists():
            parse_summary_rpt(summary_path, metrics)

    # Bitstream
    bit_dir = project_root / "bitstream"
    if bit_dir.exists():
        metrics.bitstream_size = find_bitstream_size(bit_dir)

    return metrics


# ── Comparison ──────────────────────────────────────────────────


@dataclass
class ComparisonRow:
    """One row in the comparison table."""
    metric: str
    ref_value: str
    cur_value: str
    delta: str
    status: str  # "identical", "minor", "significant", "mismatch"


def _compare_resource(
    name: str,
    ref: Optional[ResourceMetric],
    cur: Optional[ResourceMetric],
) -> ComparisonRow:
    """Compare a single resource metric."""
    if ref is None and cur is None:
        return ComparisonRow(name, "—", "—", "", "identical")
    if ref is None:
        return ComparisonRow(name, "—", f"{cur.used:,} / {cur.available:,}", "new", "minor")
    if cur is None:
        return ComparisonRow(name, f"{ref.used:,} / {ref.available:,}", "—", "missing", "mismatch")

    ref_str = f"{ref.used:,} / {ref.available:,} ({ref.percent:.2f}%)"
    cur_str = f"{cur.used:,} / {cur.available:,} ({cur.percent:.2f}%)"

    diff = cur.used - ref.used
    if diff == 0:
        return ComparisonRow(name, ref_str, cur_str, "identical", "identical")

    pct_diff = abs(diff) / max(ref.used, 1) * 100
    sign = "+" if diff > 0 else ""
    delta_str = f"{sign}{diff:,} ({sign}{pct_diff:.2f}%)"

    status = "minor" if pct_diff < 2.0 else "significant"
    return ComparisonRow(name, ref_str, cur_str, delta_str, status)


def compare_builds(ref: BuildMetrics, cur: BuildMetrics) -> list[ComparisonRow]:
    """Produce a comparison table between reference and current builds."""
    rows: list[ComparisonRow] = []

    # Resource comparisons
    rows.append(_compare_resource("CLB LUTs", ref.clb_luts, cur.clb_luts))
    rows.append(_compare_resource("  LUT as Logic", ref.lut_as_logic, cur.lut_as_logic))
    rows.append(_compare_resource("  LUT as Memory", ref.lut_as_memory, cur.lut_as_memory))
    rows.append(_compare_resource("CLB Registers", ref.clb_registers, cur.clb_registers))
    rows.append(_compare_resource("Block RAM Tile", ref.bram_tile, cur.bram_tile))
    rows.append(_compare_resource("  RAMB36", ref.ramb36, cur.ramb36))
    rows.append(_compare_resource("  RAMB18", ref.ramb18, cur.ramb18))
    rows.append(_compare_resource("URAM", ref.uram, cur.uram))
    rows.append(_compare_resource("DSPs", ref.dsps, cur.dsps))
    rows.append(_compare_resource("Bonded IOB", ref.bonded_iob, cur.bonded_iob))

    # WNS
    if ref.wns is not None or cur.wns is not None:
        ref_wns = f"{ref.wns:+.3f} ns" if ref.wns is not None else "—"
        cur_wns = f"{cur.wns:+.3f} ns" if cur.wns is not None else "—"
        if ref.wns is not None and cur.wns is not None:
            diff = cur.wns - ref.wns
            delta_str = f"{diff:+.3f} ns"
            # Both positive = both met timing
            if ref.wns >= 0 and cur.wns >= 0:
                status = "identical" if abs(diff) < 0.001 else "minor"
            elif ref.wns >= 0 and cur.wns < 0:
                status = "mismatch"  # timing regression
            else:
                status = "minor"
        else:
            delta_str = "—"
            status = "minor"
        rows.append(ComparisonRow("WNS", ref_wns, cur_wns, delta_str, status))

    # Timing met
    if ref.timing_met is not None or cur.timing_met is not None:
        ref_met = "Yes" if ref.timing_met else ("No" if ref.timing_met is False else "—")
        cur_met = "Yes" if cur.timing_met else ("No" if cur.timing_met is False else "—")
        delta = "identical" if ref.timing_met == cur.timing_met else "CHANGED"
        status = "identical" if ref.timing_met == cur.timing_met else "mismatch"
        rows.append(ComparisonRow("Timing Met", ref_met, cur_met, delta, status))

    # Bitstream size
    if ref.bitstream_size is not None or cur.bitstream_size is not None:
        ref_bs = f"{ref.bitstream_size:,} B" if ref.bitstream_size else "—"
        cur_bs = f"{cur.bitstream_size:,} B" if cur.bitstream_size else "—"
        if ref.bitstream_size and cur.bitstream_size:
            if ref.bitstream_size == cur.bitstream_size:
                delta_str = "byte-identical"
                status = "identical"
            else:
                diff = cur.bitstream_size - ref.bitstream_size
                delta_str = f"{diff:+,} B"
                status = "minor" if abs(diff) / ref.bitstream_size < 0.01 else "significant"
        else:
            delta_str = "—"
            status = "minor"
        rows.append(ComparisonRow("Bitstream", ref_bs, cur_bs, delta_str, status))

    return rows


def verdict(rows: list[ComparisonRow]) -> tuple[str, str]:
    """Return (verdict_text, color) based on comparison results.

    Returns:
        ("PASS", "green") — all identical or minor differences
        ("WARN", "yellow") — significant but not breaking differences
        ("FAIL", "red") — mismatches that indicate a migration issue
    """
    has_significant = any(r.status == "significant" for r in rows)
    has_mismatch = any(r.status == "mismatch" for r in rows)

    if has_mismatch:
        return "FAIL — migration produced different results", "red"
    if has_significant:
        return "WARN — significant resource differences detected", "yellow"
    return "PASS — migration is equivalent", "green"
