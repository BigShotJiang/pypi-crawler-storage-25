# SPDX-FileCopyrightText: 2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Registry authentication — token loading and storage.

Token resolution order:
  1. ROUTERTL_TOKEN env var (CI-friendly)
  2. ~/.routertl/auth.json (interactive login)
  3. None (public packages only)
"""

from __future__ import annotations

import json
import os
from pathlib import Path

DEFAULT_REGISTRY = "https://registry.routertl.dev"
AUTH_FILE = Path.home() / ".routertl" / "auth.json"


def get_auth_token() -> str | None:
    """Return the current auth token, or None if not authenticated."""
    env_token = os.environ.get("ROUTERTL_TOKEN")
    if env_token:
        return env_token

    if AUTH_FILE.exists():
        try:
            data = json.loads(AUTH_FILE.read_text())
            return data.get("token")
        except (json.JSONDecodeError, OSError):
            return None

    return None


def get_auth_headers() -> dict[str, str]:
    """Return Authorization headers if a token is available."""
    token = get_auth_token()
    if token:
        return {"Authorization": f"Bearer {token}"}
    return {}


def get_registry_url() -> str:
    """Return the registry URL from auth.json or default."""
    if AUTH_FILE.exists():
        try:
            data = json.loads(AUTH_FILE.read_text())
            return data.get("registry", DEFAULT_REGISTRY)
        except (json.JSONDecodeError, OSError):
            pass
    return DEFAULT_REGISTRY


def save_auth(registry: str, token: str, username: str, expires_at: str) -> Path:
    """Write auth credentials to ~/.routertl/auth.json with 0600 perms."""
    AUTH_FILE.parent.mkdir(parents=True, exist_ok=True)
    AUTH_FILE.write_text(json.dumps({
        "registry": registry,
        "token": token,
        "username": username,
        "expires_at": expires_at,
    }, indent=2))
    AUTH_FILE.chmod(0o600)
    return AUTH_FILE


def clear_auth() -> bool:
    """Remove auth.json. Returns True if file existed."""
    if AUTH_FILE.exists():
        AUTH_FILE.unlink()
        return True
    return False


def get_auth_username() -> str | None:
    """Return the logged-in username, or None."""
    if AUTH_FILE.exists():
        try:
            data = json.loads(AUTH_FILE.read_text())
            return data.get("username")
        except (json.JSONDecodeError, OSError):
            pass
    return None
