# SPDX-FileCopyrightText: 2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""HDL port parser + interface bundle classifier.

Reads a SystemVerilog or VHDL source file, extracts the entity/module
port list as typed :class:`Port` records, and groups them into
:class:`ParsedInterfaces` (AXIS / AXI4 / AXI-Lite slave/master bundles
plus clocks, resets, and unbundled scalars).

The parser is regex-based.  It is deliberately narrow in scope: it aims
to catch **bundle-count mismatches at the entity boundary** (the
RTL-P2.398 motivating bug — `sdi_axis_bypass_switch` shipped as a fused
3s/3m shape while the intended contract was 1s/2m + 2s/1m).  Regex is
sufficient for 95%+ of AXIS/AXI port layouts we see in practice;
escalate to a real parser (pyslang / pyVHDLParser) only if a real IP
trips this in the wild.

RTL-P2.403 / RTL-P2.398.
"""

from __future__ import annotations

import re
from collections import OrderedDict
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

# ── Data model ──────────────────────────────────────────────────────────────


@dataclass(frozen=True)
class Port:
    """A single HDL port (VHDL entity or SV module)."""

    name: str
    direction: str     # "in" | "out" | "inout"
    width: str         # opaque expression string, or "1" for scalars
    base_type: str     # "std_logic" | "std_logic_vector" | "logic" | "wire" | ...


@dataclass(frozen=True)
class ParsedBundle:
    """Classified interface bundle — ports sharing a prefix + protocol."""

    name: str                     # bundle prefix, e.g. "s_axis_rx"
    role: str                     # "slave" | "master"
    protocol: str                 # "axi-stream" | "axi4" | "axi-lite"
    port_names: tuple[str, ...]   # sorted member port names


@dataclass(frozen=True)
class ParsedInterfaces:
    """Result of classifying a flat :class:`Port` list into bundles + scalars."""

    slaves: tuple[ParsedBundle, ...]
    masters: tuple[ParsedBundle, ...]
    clocks: tuple[Port, ...]
    resets: tuple[Port, ...]
    scalars: tuple[Port, ...]


# ── Public API ──────────────────────────────────────────────────────────────


def parse_ports(path: Path | str) -> list[Port]:
    """Parse the entity/module port list from *path*.

    Dispatches on file suffix: ``.vhd``/``.vhdl`` → VHDL, ``.v``/``.sv``/``.svh``
    → Verilog/SystemVerilog.  Returns an empty list on unrecognised suffix or
    unparseable content.
    """
    p = Path(path)
    suffix = p.suffix.lower()
    text = p.read_text(encoding="utf-8", errors="ignore")
    if suffix in (".vhd", ".vhdl"):
        return _parse_vhdl_ports(text)
    if suffix in (".v", ".sv", ".svh"):
        return _parse_sv_ports(text)
    return []


def parse_top_name(path: Path | str) -> Optional[str]:
    """Return the top-level entity/module name declared in *path*, or ``None``.

    Used by contract-check to resolve which HDL file in a multi-file IP
    directory is the top module targeted by ``requirements.yml``.  Dispatches
    on file suffix; comments are stripped before scanning so that decorative
    Unicode in headers doesn't confuse the regex.
    """
    p = Path(path)
    suffix = p.suffix.lower()
    try:
        text = p.read_text(encoding="utf-8", errors="ignore")
    except OSError:
        return None
    if suffix in (".vhd", ".vhdl"):
        clean = strip_vhdl_comments_and_unicode(text)
        m = re.search(r"\bentity\s+(\w+)\s+is\b", clean, re.IGNORECASE)
        return m.group(1) if m else None
    if suffix in (".v", ".sv", ".svh"):
        clean = strip_sv_comments_and_unicode(text)
        m = re.search(r"\bmodule\s+(\w+)\b", clean)
        return m.group(1) if m else None
    return None


def classify_interfaces(ports: list[Port]) -> ParsedInterfaces:
    """Group *ports* into AXIS/AXI bundles + clocks + resets + scalars."""
    axis_slaves: "OrderedDict[str, list[Port]]" = OrderedDict()
    axis_masters: "OrderedDict[str, list[Port]]" = OrderedDict()
    axi_slaves: "OrderedDict[str, list[Port]]" = OrderedDict()
    axi_masters: "OrderedDict[str, list[Port]]" = OrderedDict()
    axi_slave_is_full: dict[str, bool] = {}
    axi_master_is_full: dict[str, bool] = {}
    clocks: list[Port] = []
    resets: list[Port] = []
    scalars: list[Port] = []

    for port in ports:
        if _is_clock(port.name):
            clocks.append(port)
            continue
        if _is_reset(port.name):
            resets.append(port)
            continue

        axis = _axis_classify_port(port.name)
        if axis is not None:
            role, prefix = axis
            bucket = axis_slaves if role == "slave" else axis_masters
            bucket.setdefault(prefix, []).append(port)
            continue

        axi = _axi_classify_port(port.name)
        if axi is not None:
            role, prefix, suffix = axi
            is_full = suffix in _AXI4_SUFFIXES
            if role == "slave":
                axi_slaves.setdefault(prefix, []).append(port)
                axi_slave_is_full[prefix] = (
                    axi_slave_is_full.get(prefix, False) or is_full
                )
            else:
                axi_masters.setdefault(prefix, []).append(port)
                axi_master_is_full[prefix] = (
                    axi_master_is_full.get(prefix, False) or is_full
                )
            continue

        scalars.append(port)

    def _mkbundles(
        groups: "OrderedDict[str, list[Port]]",
        role: str,
        proto_or_fn,
    ) -> list[ParsedBundle]:
        out = []
        for prefix, members in groups.items():
            proto = proto_or_fn(prefix) if callable(proto_or_fn) else proto_or_fn
            out.append(ParsedBundle(
                name=prefix,
                role=role,
                protocol=proto,
                port_names=tuple(sorted(p.name for p in members)),
            ))
        return out

    slave_bundles = (
        _mkbundles(axis_slaves, "slave", "axi-stream")
        + _mkbundles(
            axi_slaves, "slave",
            lambda p: "axi4" if axi_slave_is_full.get(p) else "axi-lite",
        )
    )
    master_bundles = (
        _mkbundles(axis_masters, "master", "axi-stream")
        + _mkbundles(
            axi_masters, "master",
            lambda p: "axi4" if axi_master_is_full.get(p) else "axi-lite",
        )
    )

    return ParsedInterfaces(
        slaves=tuple(sorted(slave_bundles, key=lambda b: b.name)),
        masters=tuple(sorted(master_bundles, key=lambda b: b.name)),
        clocks=tuple(clocks),
        resets=tuple(resets),
        scalars=tuple(scalars),
    )


def parse_and_classify(path: Path | str) -> ParsedInterfaces:
    """Convenience: :func:`parse_ports` + :func:`classify_interfaces`."""
    return classify_interfaces(parse_ports(path))


# ── Shared hygiene helpers ──────────────────────────────────────────────────


def strip_vhdl_comments_and_unicode(text: str) -> str:
    """Strip VHDL ``--`` line comments and any non-ASCII characters.

    The ``sdi_axis_bypass_switch`` VHDL uses Unicode box-drawing (``═``,
    ``─``) in comments.  Without stripping, downstream regex can match
    decorative text or skip real declarations whose preceding comment
    gets merged into them.  VHDL identifiers are ASCII, so stripping
    all code points ≥ 128 is safe for name/direction/type extraction.

    This helper is exported because :mod:`sdk.generators.cocotb.gen_cocotb_structure`
    shares the same hygiene need — see RTL-P2.403 back-port.
    """
    text = re.sub(r"--[^\n]*", "", text)
    return "".join(c if ord(c) < 128 else " " for c in text)


def strip_sv_comments_and_unicode(text: str) -> str:
    """Strip SV ``//`` + ``/* */`` comments and any non-ASCII characters."""
    text = re.sub(r"//[^\n]*", "", text)
    text = re.sub(r"/\*.*?\*/", "", text, flags=re.DOTALL)
    return "".join(c if ord(c) < 128 else " " for c in text)


# ── VHDL parsing ────────────────────────────────────────────────────────────


_VHDL_PORT_LINE_RE = re.compile(
    r"^(?P<names>[\w\s,]+?)\s*:\s*(?P<dir>in|out|inout|buffer)\s+(?P<type>.+)$",
    re.IGNORECASE | re.DOTALL,
)


def _extract_port_block(text: str) -> Optional[str]:
    """Return the body of the first ``port(...)`` block, paren-balanced."""
    m = re.search(r"\bport\s*\(", text, re.IGNORECASE)
    if not m:
        return None
    start = m.end()
    depth = 1
    i = start
    while i < len(text) and depth > 0:
        c = text[i]
        if c == "(":
            depth += 1
        elif c == ")":
            depth -= 1
        i += 1
    if depth != 0:
        return None
    return text[start:i - 1]


def _split_port_statements(block: str) -> list[str]:
    """Split a port block on ``;`` at paren-depth 0."""
    out: list[str] = []
    current: list[str] = []
    depth = 0
    for c in block:
        if c == "(":
            depth += 1
            current.append(c)
        elif c == ")":
            depth -= 1
            current.append(c)
        elif c == ";" and depth == 0:
            stmt = "".join(current).strip()
            if stmt:
                out.append(stmt)
            current = []
        else:
            current.append(c)
    stmt = "".join(current).strip()
    if stmt:
        out.append(stmt)
    return out


def _split_vhdl_type(expr: str) -> tuple[str, str]:
    """Split a VHDL type expression into (base_type, width_expr).

    ``std_logic_vector(DATA_WIDTH-1 downto 0)`` → ``("std_logic_vector", "DATA_WIDTH-1 downto 0")``.
    ``std_logic`` → ``("std_logic", "1")``.
    Default-value suffixes (``:= ...``) are discarded.
    """
    expr = expr.strip().rstrip(";").strip()
    if ":=" in expr:
        expr = expr.split(":=")[0].strip()
    m = re.match(r"^(\w+)\s*\((.*)\)\s*$", expr, re.DOTALL)
    if m:
        return m.group(1).lower(), m.group(2).strip()
    first = expr.split()[0] if expr else "std_logic"
    return first.lower(), "1"


def _parse_vhdl_ports(text: str) -> list[Port]:
    clean = strip_vhdl_comments_and_unicode(text)
    block = _extract_port_block(clean)
    if block is None:
        return []
    ports: list[Port] = []
    for stmt in _split_port_statements(block):
        m = _VHDL_PORT_LINE_RE.match(stmt)
        if not m:
            continue
        names = [n.strip() for n in m.group("names").split(",") if n.strip()]
        direction = m.group("dir").lower()
        if direction == "buffer":
            direction = "out"
        base_type, width = _split_vhdl_type(m.group("type"))
        for name in names:
            ports.append(Port(
                name=name,
                direction=direction,
                width=width,
                base_type=base_type,
            ))
    return ports


# ── SV / Verilog parsing ────────────────────────────────────────────────────


_SV_MODULE_RE = re.compile(
    r"module\s+\w+\s*"
    r"(?:#\s*\((.*?)\))?\s*"
    r"\((.*?)\)\s*;",
    re.DOTALL,
)

_SV_PORT_LINE_RE = re.compile(
    r"(?P<dir>input|output|inout)\s+"
    r"(?:(?P<nettype>wire|reg|logic)\s+)?"
    r"(?P<width>\[[^\]]+\])?\s*"
    r"(?P<name>\w+)\s*(?:,|$)",
    re.IGNORECASE,
)


def _parse_sv_ports(text: str) -> list[Port]:
    clean = strip_sv_comments_and_unicode(text)
    m = _SV_MODULE_RE.search(clean)
    if not m:
        return []
    port_block = m.group(2) or ""
    ports: list[Port] = []
    sv_to_vhdl_dir = {"input": "in", "output": "out", "inout": "inout"}
    for pm in _SV_PORT_LINE_RE.finditer(port_block):
        direction = sv_to_vhdl_dir[pm.group("dir").lower()]
        base_type = (pm.group("nettype") or "wire").lower()
        raw = (pm.group("width") or "").strip()
        if raw:
            width = raw.strip("[]").strip()
            if width == "0:0":
                width = "1"
        else:
            width = "1"
        ports.append(Port(
            name=pm.group("name"),
            direction=direction,
            width=width,
            base_type=base_type,
        ))
    return ports


# ── Classifier primitives ───────────────────────────────────────────────────


_AXIS_SUFFIXES = (
    "tdata", "tkeep", "tuser", "tlast", "tvalid", "tready",
    "tstrb", "tid", "tdest",
)
_AXIS_SUFFIX_RE = re.compile(
    r"^(?P<prefix>.+?)_(?P<suffix>" + "|".join(_AXIS_SUFFIXES) + r")$",
    re.IGNORECASE,
)

_AXI_LITE_SUFFIXES = (
    "awvalid", "awready", "awaddr", "awprot",
    "wvalid", "wready", "wdata", "wstrb",
    "bvalid", "bready", "bresp",
    "arvalid", "arready", "araddr", "arprot",
    "rvalid", "rready", "rdata", "rresp",
)
_AXI4_SUFFIXES = (
    "awid", "awlen", "awsize", "awburst", "awcache", "awqos",
    "wlast", "bid",
    "arid", "arlen", "arsize", "arburst", "arcache", "arqos",
    "rlast", "rid",
)
_AXI_ALL_SUFFIXES = _AXI_LITE_SUFFIXES + _AXI4_SUFFIXES
_AXI_SUFFIX_RE = re.compile(
    r"^(?P<prefix>.+?)_(?P<suffix>" + "|".join(_AXI_ALL_SUFFIXES) + r")$",
    re.IGNORECASE,
)

# Role-prefix: bare "s_"/"m_" or an indexed variant "s00_"/"m01_" (PULP
# common_cells convention).  Indexed bundles must each group as their own
# bundle, not escape to scalars — see RTL-P3.198.
_SLAVE_ROLE_RE = re.compile(r"^s\d*_", re.IGNORECASE)
_MASTER_ROLE_RE = re.compile(r"^m\d*_", re.IGNORECASE)


def _axis_classify_port(name: str) -> Optional[tuple[str, str]]:
    """If *name* looks like an AXIS port, return ``(role, prefix)``."""
    m = _AXIS_SUFFIX_RE.match(name)
    if not m:
        return None
    prefix = m.group("prefix")
    if not re.search(r"axis", prefix, re.IGNORECASE):
        return None
    if _SLAVE_ROLE_RE.match(prefix):
        return "slave", prefix
    if _MASTER_ROLE_RE.match(prefix):
        return "master", prefix
    return None


def _axi_classify_port(name: str) -> Optional[tuple[str, str, str]]:
    """If *name* looks like an AXI (non-stream) port, return ``(role, prefix, suffix)``."""
    m = _AXI_SUFFIX_RE.match(name)
    if not m:
        return None
    prefix = m.group("prefix")
    suffix = m.group("suffix").lower()
    # AXI but NOT AXIS.  Note that 'axis' contains 'axi'; filter explicitly.
    if re.search(r"axis", prefix, re.IGNORECASE):
        return None
    if not re.search(r"axi", prefix, re.IGNORECASE):
        return None
    if _SLAVE_ROLE_RE.match(prefix):
        return "slave", prefix, suffix
    if _MASTER_ROLE_RE.match(prefix):
        return "master", prefix, suffix
    return None


def _is_clock(name: str) -> bool:
    n = name.lower()
    return (
        n.endswith("aclk") or n.endswith("_clk") or n == "clk"
        or n.startswith("clk_")
    )


def _is_reset(name: str) -> bool:
    n = name.lower()
    return (
        n.endswith("aresetn") or n.endswith("_rstn") or n.endswith("_rst")
        or n in ("rst", "rstn")
        or n.startswith("rst_") or n.startswith("rstn_")
        or "reset" in n
    )
