# SPDX-FileCopyrightText: 2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Contract-check engine — diff declared requirements.yml vs parsed HDL.

Given a :class:`~sdk.cli.requirements.Requirements` and a
:class:`~sdk.engine.hdl_ports.ParsedInterfaces`, emit a list of
:class:`ContractIssue` records describing every shape divergence —
slave/master count mismatches, missing or orphan bundles, protocol
disagreements, and scalar / clock / reset discrepancies.

RTL-P2.404 / RTL-P2.398.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from sdk.cli.requirements import (
    Requirements,
    discover_project_requirements,
    discover_requirements,
    load_requirements,
)
from sdk.engine.hdl_ports import (
    ParsedInterfaces,
    classify_interfaces,
    parse_ports,
    parse_top_name,
)

_HDL_GLOBS = ("*.vhd", "*.vhdl", "*.v", "*.sv")


@dataclass(frozen=True)
class ContractIssue:
    """One diagnostic finding from contract-check.

    *suggestion* (RTL-P2.444) — optional copy-pasteable YAML fragment the
    user drops into requirements.yml to close the diff.  Populated for
    orphan-slave / orphan-master / orphan-scalar / scalar-direction
    categories where the fix is mechanical.  Missing-* categories leave
    it unset because the fix is judgment-call (remove from the contract,
    fix the HDL, or rename — not mechanical).
    """

    severity: str   # "error" | "warn"
    category: str   # "slave-count" | "missing-slave" | "scalar-direction" | ...
    message: str
    suggestion: Optional[str] = None


@dataclass(frozen=True)
class ContractReport:
    """Result of checking one IP."""

    ip: str
    requirements_path: Path
    hdl_paths: tuple[Path, ...]
    issues: tuple[ContractIssue, ...]

    @property
    def ok(self) -> bool:
        return not any(i.severity == "error" for i in self.issues)


def check_contract(
    requirements: Requirements,
    parsed: ParsedInterfaces,
) -> list[ContractIssue]:
    """Diff *requirements* vs *parsed*.  Empty return ⇒ pass."""
    issues: list[ContractIssue] = []

    declared_slaves = list(requirements.port_contract.slaves)
    declared_masters = list(requirements.port_contract.masters)
    actual_slaves = list(parsed.slaves)
    actual_masters = list(parsed.masters)

    # ── Top-level bundle count mismatch — the primary "wrong shape" signal ──
    if len(declared_slaves) != len(actual_slaves):
        issues.append(ContractIssue(
            severity="error",
            category="slave-count",
            message=_count_msg("slave", declared_slaves, actual_slaves),
        ))
    if len(declared_masters) != len(actual_masters):
        issues.append(ContractIssue(
            severity="error",
            category="master-count",
            message=_count_msg("master", declared_masters, actual_masters),
        ))

    # ── Per-bundle name + protocol matches ──
    _diff_side(issues, "slave", declared_slaves, actual_slaves)
    _diff_side(issues, "master", declared_masters, actual_masters)

    # ── Scalars ──
    declared_scalars = {s.name: s for s in requirements.port_contract.scalars}
    actual_scalars = {s.name: s for s in parsed.scalars}
    for name, ds in declared_scalars.items():
        if name not in actual_scalars:
            issues.append(ContractIssue(
                severity="error",
                category="missing-scalar",
                message=f"declared scalar '{name}' not found in HDL",
            ))
            continue
        as_ = actual_scalars[name]
        if ds.direction != as_.direction:
            # RTL-P2.444 — direction flip is a single-field edit.
            suggestion = (
                f"  Suggested — edit scalar {name!r} in requirements.yml:\n"
                f"    - {{ name: {name}, dir: {as_.direction}, "
                f"width: {ds.width} }}"
            )
            issues.append(ContractIssue(
                severity="error",
                category="scalar-direction",
                message=(
                    f"scalar '{name}' direction mismatch: declared "
                    f"{ds.direction!r}, actual {as_.direction!r}"
                ),
                suggestion=suggestion,
            ))

    # ── Clocks ──
    actual_clocks = {c.name for c in parsed.clocks}
    for dc in requirements.port_contract.clocks:
        if dc.name not in actual_clocks:
            issues.append(ContractIssue(
                severity="error",
                category="missing-clock",
                message=f"declared clock '{dc.name}' not found in HDL",
            ))

    # ── Resets (polarity is advisory: we don't parse polarity from HDL) ──
    actual_resets = {r.name for r in parsed.resets}
    for dr in requirements.port_contract.resets:
        if dr.name not in actual_resets:
            issues.append(ContractIssue(
                severity="error",
                category="missing-reset",
                message=f"declared reset '{dr.name}' not found in HDL",
            ))

    return issues


def check_ip(ip_dir: Path, req_path: Optional[Path] = None) -> ContractReport:
    """Check one IP directory containing a requirements.yml + HDL sources.

    Target HDL resolution (RTL-P2.421):
      1. If ``requirements.hdl_file`` is set, that file is used verbatim
         (resolved relative to *ip_dir*).
      2. Otherwise, every HDL file under *ip_dir* is scanned for its top
         entity/module name; the file whose declared name matches
         ``requirements.ip`` is the target.  Zero or multiple matches are
         reported as a resolution error — never silently fall back to the
         lexical-first file (the RTL-P2.415 bug pattern).

    *req_path* (RTL-P2.431) — when the IP's ip.yml declares an explicit
    ``requirements:`` pointer, pass the resolved path here so the check
    reads that file instead of the sibling default.  Defaults to
    ``ip_dir / "requirements.yml"``.
    """
    ip_dir = Path(ip_dir)
    if req_path is None:
        req_path = ip_dir / "requirements.yml"
    requirements = load_requirements(req_path)

    hdl_paths = sorted(
        p for glob in _HDL_GLOBS for p in ip_dir.rglob(glob)
    )
    if not hdl_paths:
        return ContractReport(
            ip=requirements.ip,
            requirements_path=req_path,
            hdl_paths=(),
            issues=(ContractIssue(
                severity="error",
                category="no-hdl",
                message=f"no HDL sources found under {ip_dir}",
            ),),
        )

    target, resolution_issue = _resolve_target_hdl(ip_dir, requirements, hdl_paths)
    if resolution_issue is not None:
        return ContractReport(
            ip=requirements.ip,
            requirements_path=req_path,
            hdl_paths=tuple(hdl_paths),
            issues=(resolution_issue,),
        )
    assert target is not None

    ports = parse_ports(target)
    if not ports:
        return ContractReport(
            ip=requirements.ip,
            requirements_path=req_path,
            hdl_paths=tuple(hdl_paths),
            issues=(ContractIssue(
                severity="error",
                category="no-parseable-hdl",
                message=(
                    f"target HDL {target.name!r} has no parseable "
                    "entity/module port list"
                ),
            ),),
        )
    parsed = classify_interfaces(ports)

    return ContractReport(
        ip=requirements.ip,
        requirements_path=req_path,
        hdl_paths=tuple(hdl_paths),
        issues=tuple(check_contract(requirements, parsed)),
    )


def _resolve_target_hdl(
    ip_dir: Path,
    requirements: Requirements,
    hdl_paths: list[Path],
) -> tuple[Optional[Path], Optional[ContractIssue]]:
    """Pick the HDL file that implements ``requirements.ip``.

    Returns ``(target, None)`` on success, or ``(None, issue)`` with a
    diagnostic describing why resolution failed.
    """
    if requirements.hdl_file is not None:
        pinned = (ip_dir / requirements.hdl_file).resolve()
        if not pinned.is_file():
            return None, ContractIssue(
                severity="error",
                category="hdl-file-not-found",
                message=(
                    f"hdl_file {requirements.hdl_file!r} pinned in "
                    f"requirements.yml does not exist under {ip_dir}"
                ),
            )
        return pinned, None

    target_name = requirements.ip
    matches: list[Path] = []
    candidates: list[tuple[Path, Optional[str]]] = []
    for p in hdl_paths:
        top = parse_top_name(p)
        candidates.append((p, top))
        if top is not None and top == target_name:
            matches.append(p)

    if len(matches) == 1:
        return matches[0], None

    candidate_summary = ", ".join(
        f"{p.name}→{top!r}" for p, top in candidates
    )
    if not matches:
        return None, ContractIssue(
            severity="error",
            category="no-matching-hdl",
            message=(
                f"no HDL file declares module/entity {target_name!r}; "
                f"candidates: {candidate_summary}.  Either rename the top "
                "module, update requirements.yml 'ip:', or pin 'hdl_file:' "
                "to the target source file."
            ),
        )
    names = ", ".join(p.name for p in matches)
    return None, ContractIssue(
        severity="error",
        category="ambiguous-hdl",
        message=(
            f"multiple HDL files declare module/entity {target_name!r}: "
            f"{names}.  Pin 'hdl_file:' in requirements.yml to disambiguate."
        ),
    )


def check_project(root: Path) -> list[ContractReport]:
    """Walk *root* for every requirements.yml; return one report per IP.

    Discovery is ip.yml-driven (RTL-P2.431): when an IP's ip.yml declares
    a ``requirements:`` pointer, that pointer is consulted; the explicit
    path is forwarded to :func:`check_ip` so the IP directory and the
    requirements file can live anywhere relative to each other.
    Filesystem-walked ``requirements.yml`` files still resolve via the
    default sibling convention.
    """
    reports: list[ContractReport] = []
    for req_path in discover_requirements(root):
        reports.append(check_ip(req_path.parent, req_path=req_path))
    return reports


@dataclass(frozen=True)
class ProjectContractTree:
    """Tree-shaped contract-check result (RTL-P2.431).

    Aggregates an optional project-level :class:`ContractReport` (for the
    project's top module, when project.yml declares a ``requirements:``
    pointer) with one report per IP discovered under the project root.
    Designed so callers can print a tree and compute a union exit code
    without threading two lists.
    """

    project_report: Optional[ContractReport]
    ip_reports: tuple[ContractReport, ...]

    @property
    def ok(self) -> bool:
        """True iff every report (project + per-IP) is passing."""
        if self.project_report is not None and not self.project_report.ok:
            return False
        return all(r.ok for r in self.ip_reports)

    @property
    def all_reports(self) -> tuple[ContractReport, ...]:
        """Flat tuple — project first (if any), then IPs in discovery order."""
        if self.project_report is None:
            return self.ip_reports
        return (self.project_report,) + self.ip_reports


def check_project_tree(
    root: Path,
    project_yml_path: Optional[Path] = None,
) -> ProjectContractTree:
    """Check the project-level contract and every per-IP contract.

    Parameters
    ----------
    root
        Filesystem root to scan for ip.yml / requirements.yml.
    project_yml_path
        Path to ``project.yml`` (or a target file).  When provided and
        the file declares a ``requirements:`` pointer (see
        :func:`sdk.cli.project_config.project_requirements_path`), the
        project's top module is checked against that contract.  Absence
        of a pointer is fine — ``project_report`` will simply be None.

    Returns
    -------
    ProjectContractTree
        Aggregated result.  ``tree.ok`` folds the project-level and
        per-IP outcomes into a single bool for CLI exit codes.
    """
    root = Path(root).resolve()

    project_report: Optional[ContractReport] = None
    proj_req_path: Optional[Path] = None
    if project_yml_path is not None:
        proj_req_path = discover_project_requirements(project_yml_path, root)
        if proj_req_path is not None:
            project_report = _check_project_top(root, proj_req_path)

    # Per-IP reports — but exclude the path claimed by the project-level
    # pointer so a single requirements.yml sitting at root doesn't get
    # double-counted.
    ip_reports = [
        r for r in check_project(root)
        if proj_req_path is None or r.requirements_path != proj_req_path
    ]
    return ProjectContractTree(
        project_report=project_report,
        ip_reports=tuple(ip_reports),
    )


def _check_project_top(
    root: Path,
    req_path: Path,
) -> ContractReport:
    """Check a project-level requirements.yml against the project top HDL.

    Uses the same :func:`check_ip` machinery, treating *root* as the
    search directory for HDL.  The project-level requirements.yml must
    either pin ``hdl_file:`` or declare ``ip:`` equal to the project's
    top entity/module name so :func:`_resolve_target_hdl` can resolve
    the target unambiguously.
    """
    return check_ip(root, req_path=req_path)


def format_report(report: ContractReport) -> str:
    """Render *report* as a human-readable block.

    RTL-P2.444 — when an issue carries a ``suggestion`` (orphan bundles
    and scalar-direction mismatches), the copy-pasteable YAML fragment
    is rendered on its own indented lines below the issue message so
    the user can literally copy the block into requirements.yml.
    """
    if report.ok and not report.issues:
        return f"[OK] {report.ip}"
    marker = "[OK]" if report.ok else "[FAIL]"
    lines = [f"{marker} {report.ip}  ({report.requirements_path})"]
    for iss in report.issues:
        sev = "!" if iss.severity == "error" else "~"
        lines.append(f"  {sev} [{iss.category}] {iss.message}")
        if iss.suggestion:
            lines.append(iss.suggestion)
    return "\n".join(lines)


def format_tree(tree: ProjectContractTree) -> str:
    """Render a :class:`ProjectContractTree` as a tree-shaped block.

    Project-level report (if any) appears first with a ``project:`` label;
    per-IP reports follow.  Empty trees render a single explanatory line.
    """
    if tree.project_report is None and not tree.ip_reports:
        return "(no contracts declared — add requirements: to project.yml or ip.yml)"

    lines: list[str] = []
    if tree.project_report is not None:
        lines.append(f"project: {format_report(tree.project_report)}")
    for r in tree.ip_reports:
        lines.append(f"ip:      {format_report(r)}")
    return "\n".join(lines)


# ── Helpers ─────────────────────────────────────────────────────────────────


def _count_msg(side: str, declared, actual) -> str:
    dnames = ", ".join(b.name for b in declared) or "<none>"
    anames = ", ".join(b.name for b in actual) or "<none>"
    return (
        f"{side} count mismatch: declared {len(declared)} ({dnames}), "
        f"actual {len(actual)} ({anames})"
    )


def _diff_side(issues: list[ContractIssue], side: str, declared, actual) -> None:
    """Compare declared vs actual bundles for one side (slave/master)."""
    declared_by_name = {b.name: b for b in declared}
    actual_by_name = {b.name: b for b in actual}
    for name in sorted(set(declared_by_name) - set(actual_by_name)):
        issues.append(ContractIssue(
            severity="error",
            category=f"missing-{side}",
            message=f"declared {side} bundle '{name}' not found in HDL",
        ))
    for name in sorted(set(actual_by_name) - set(declared_by_name)):
        # RTL-P2.444 — orphan bundle is the most mechanical fix: copy
        # the YAML fragment into port_contract.{slaves,masters}:.
        bundle = actual_by_name[name]
        suggestion = (
            f"  Suggested — add under port_contract.{side}s: in requirements.yml\n"
            f"    - {{ name: {name}, protocol: {bundle.protocol} }}"
        )
        issues.append(ContractIssue(
            severity="error",
            category=f"orphan-{side}",
            message=f"HDL {side} bundle '{name}' not declared in requirements",
            suggestion=suggestion,
        ))
    for name in sorted(set(declared_by_name) & set(actual_by_name)):
        dp = declared_by_name[name].protocol
        ap = actual_by_name[name].protocol
        if dp != ap:
            # Protocol drift: point the user at the field to edit.
            suggestion = (
                f"  Suggested — edit {side} {name!r} in requirements.yml:\n"
                f"    - {{ name: {name}, protocol: {ap} }}"
            )
            issues.append(ContractIssue(
                severity="error",
                category=f"{side}-protocol",
                message=(
                    f"{side} '{name}' protocol mismatch: declared {dp!r}, "
                    f"actual {ap!r}"
                ),
                suggestion=suggestion,
            ))
