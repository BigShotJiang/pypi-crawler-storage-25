# SPDX-FileCopyrightText: 2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Infer SoC family from FPGA part number prefix.

Shared by migration (xpr_parser) and linux codegen (memory_map_parser).
RTL-P3.139
"""

from __future__ import annotations

# Ordered list: longest prefix first to avoid ambiguity.
_PART_PREFIX_TO_SOC: list[tuple[str, str]] = [
    ("xczu", "zynqmp"),
    ("xc7z", "zynq-7000"),
    ("xcvm", "versal"),
    ("xcve", "versal"),
    ("xcvp", "versal"),
    ("mpfs", "polarfire-soc"),
]


def infer_soc_family(part: str) -> str | None:
    """Return SoC family string or ``None`` if *part* is not a SoC.

    Examples::

        >>> infer_soc_family("xczu7ev-ffvc1156-2-i")
        'zynqmp'
        >>> infer_soc_family("xc7a35tcpg236-1")  # Artix-7
        >>> infer_soc_family("xc7z020clg400-1")
        'zynq-7000'
    """
    lower = part.lower()
    for prefix, family in _PART_PREFIX_TO_SOC:
        if lower.startswith(prefix):
            return family
    return None
