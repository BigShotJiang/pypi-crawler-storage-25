#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Hook-compatible file staging script (RTL-P2.302).

Reads ``stage_files`` entries from project.yml and copies each source
to its declared destination.  Designed to run as a ``hooks.post_ip_gen``
hook so it inherits watch/expected_outputs/clean_before_run for free.

Usage in project.yml::

    hooks:
      post_ip_gen:
        - name: stage-generated-files
          script: sdk/engine/stage_files.py
          expected_outputs:
            - project/onchip_ram.hex
          watch:
            - "src/ip/**/*.hex"

Or standalone::

    python sdk/engine/stage_files.py [--project project.yml] [--dry-run]
"""

from __future__ import annotations

import argparse
import glob as _glob
import shutil
import sys
from pathlib import Path


def stage_files(config: dict, *, dry_run: bool = False) -> int:
    """Execute stage_files entries from a parsed project config.

    Returns the number of files staged.
    """
    entries = config.get("stage_files", [])
    if not entries:
        return 0

    staged = 0
    for entry in entries:
        src_pattern = entry.get("src", "")
        dst = entry.get("dst", "")
        if not src_pattern or not dst:
            print(f"  ⚠️  Skipping invalid stage_files entry: {entry}")
            continue

        matches = _glob.glob(src_pattern, recursive=True)
        if not matches:
            print(f"  ⚠️  stage_files: no match for {src_pattern}")
            continue

        dst_path = Path(dst)
        for src_file in matches:
            src_path = Path(src_file)
            if not src_path.is_file():
                continue
            if len(matches) > 1 or dst.endswith("/"):
                target_path = dst_path / src_path.name
            else:
                target_path = dst_path

            if dry_run:
                print(f"  [dry-run] {src_path} → {target_path}")
            else:
                target_path.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(src_path, target_path)
                print(f"  📋 {src_path} → {target_path}")
            staged += 1

    if staged:
        prefix = "[dry-run] " if dry_run else ""
        print(f"✅ {prefix}Staged {staged} file(s)")
    return staged


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Stage generated files declared in project.yml stage_files entries."
    )
    parser.add_argument(
        "--project", default="project.yml",
        help="Path to project.yml (default: project.yml)",
    )
    parser.add_argument(
        "--dry-run", action="store_true",
        help="Show what would be copied without actually copying.",
    )
    args = parser.parse_args()

    import yaml

    yml = Path(args.project)
    if not yml.exists():
        print(f"❌ No project config found at {yml}")
        return 1

    with open(yml) as f:
        config = yaml.safe_load(f) or {}

    # Chase target pointer if present
    if "target" in config:
        target_path = Path(config["target"])
        if target_path.exists():
            with open(target_path) as f:
                config = yaml.safe_load(f) or {}

    count = stage_files(config, dry_run=args.dry_run)
    if count == 0 and not args.dry_run:
        print("ℹ️  No stage_files entries found in project config.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
