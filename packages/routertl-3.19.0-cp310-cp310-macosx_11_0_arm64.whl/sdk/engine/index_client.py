# SPDX-FileCopyrightText: 2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""routertl IP Index Client.

Fetches and caches package metadata from a routertl-ip-index repository.
Supports semver constraint resolution and offline mode via a local cache.

Default index: https://raw.githubusercontent.com/djmazure/routertl-ip-index/main
Override via:  ROUTERTL_INDEX env var  or  index_url in project.yml
"""

from __future__ import annotations

import json
import logging
import os
import re
import time
from pathlib import Path
from urllib.error import URLError
from urllib.request import urlopen

import yaml

_log = logging.getLogger("engine.index_client")

# ── Constants ─────────────────────────────────────────────────────────────────

DEFAULT_INDEX_URL = "https://registry.routertl.dev"
_GITHUB_FALLBACK_URL = "https://raw.githubusercontent.com/djmazure/routertl-ip-index/main"
_CACHE_TTL_SECONDS = 60 * 60 * 4   # 4 hours
_FETCH_TIMEOUT = 10                 # seconds


# ── Public API ────────────────────────────────────────────────────────────────


def get_index_url(config: dict | None = None) -> str:
    """Return the active index URL (env override > project.yml > default)."""
    env = os.environ.get("ROUTERTL_INDEX")
    if env:
        return env.rstrip("/")
    if config:
        url = config.get("packages_index") or config.get("index_url")
        if url:
            return url.rstrip("/")
    return DEFAULT_INDEX_URL


def fetch_catalog(
    index_url: str,
    cache_dir: Path,
    *,
    force_refresh: bool = False,
) -> list[dict]:
    """Download and cache catalog.json.

    Parameters
    ----------
    index_url:      Base URL of the index repo.
    cache_dir:      Local directory for caching (e.g. .routertl_cache/index/).
    force_refresh:  Bypass TTL and re-download even if cache is fresh.

    Returns the parsed catalog list (may be empty on network failure if
    a cached copy exists; raises on complete failure with no cache).
    """
    cache_dir.mkdir(parents=True, exist_ok=True)
    catalog_cache = cache_dir / "catalog.json"

    if not force_refresh and _cache_is_fresh(catalog_cache):
        _log.debug("catalog.json cache hit")
        return json.loads(catalog_cache.read_text())

    url = f"{index_url}/catalog.json"
    try:
        data = _http_get(url)
        catalog_cache.write_text(data)
        _touch(catalog_cache)
        _log.debug("Refreshed catalog.json from %s", url)
        return json.loads(data)
    except (URLError, OSError) as exc:
        if catalog_cache.exists():
            _log.warning("Could not refresh catalog (using cache): %s", exc)
            return json.loads(catalog_cache.read_text())
        # Fallback to GitHub index if registry is unreachable
        if index_url == DEFAULT_INDEX_URL:
            _log.warning("Registry unreachable, falling back to GitHub index: %s", exc)
            fallback_url = f"{_GITHUB_FALLBACK_URL}/catalog.json"
            try:
                data = _http_get(fallback_url)
                catalog_cache.write_text(data)
                _touch(catalog_cache)
                return json.loads(data)
            except (URLError, OSError):
                pass
        raise RuntimeError(
            f"Failed to fetch catalog from {url} and no local cache exists.\n"
            "Check your network or set ROUTERTL_INDEX to a local path."
        ) from exc


def fetch_index_entry(
    namespace: str,
    name: str,
    version: str,
    index_url: str,
    cache_dir: Path,
) -> dict:
    """Fetch a specific version descriptor from the index.

    Returns the parsed YAML dict for packages/<namespace>/<name>/<version>.yml.
    Caches locally under cache_dir/packages/<namespace>/<name>/<version>.yml.

    If the primary source returns an entry with an empty compat file list,
    falls back to the GitHub index which may have richer data from the
    original scan_ip_repo.py output.
    """
    cache_path = cache_dir / "packages" / namespace / name / f"{version}.yml"

    if cache_path.exists():
        _log.debug("Index entry cache hit: %s/%s@%s", namespace, name, version)
        with open(cache_path) as f:
            return yaml.safe_load(f)

    url = f"{index_url}/packages/{namespace}/{name}/{version}.yml"
    try:
        data = _http_get(url)
    except (URLError, OSError) as exc:
        # Network fallback to GitHub
        if index_url == DEFAULT_INDEX_URL:
            _log.warning("Registry unreachable for %s/%s@%s, trying GitHub fallback", namespace, name, version)
            fallback_url = f"{_GITHUB_FALLBACK_URL}/packages/{namespace}/{name}/{version}.yml"
            try:
                data = _http_get(fallback_url)
            except (URLError, OSError):
                pass
            else:
                cache_path.parent.mkdir(parents=True, exist_ok=True)
                cache_path.write_text(data)
                return yaml.safe_load(data)
        raise RuntimeError(
            f"Failed to fetch index entry for {namespace}/{name}@{version}\n"
            f"  URL: {url}\n"
            f"  Error: {exc}"
        ) from exc

    entry = yaml.safe_load(data)

    # Data quality fallback: if the primary registry entry has an empty file
    # list (known issue with registry upload pipeline), try the GitHub index
    # which preserves the original scan_ip_repo.py output with full file lists.
    if index_url == DEFAULT_INDEX_URL and _entry_has_empty_files(entry):
        _log.warning(
            "Registry entry for %s/%s@%s has empty file list, trying GitHub fallback",
            namespace, name, version,
        )
        fallback_url = f"{_GITHUB_FALLBACK_URL}/packages/{namespace}/{name}/{version}.yml"
        try:
            fallback_data = _http_get(fallback_url)
            fallback_entry = yaml.safe_load(fallback_data)
            if not _entry_has_empty_files(fallback_entry):
                _log.info("GitHub fallback has valid data for %s/%s@%s", namespace, name, version)
                data = fallback_data
                entry = fallback_entry
        except (URLError, OSError):
            _log.debug("GitHub fallback unavailable for %s/%s@%s", namespace, name, version)

    cache_path.parent.mkdir(parents=True, exist_ok=True)
    cache_path.write_text(data)
    return entry


def fetch_head_entry(
    namespace: str,
    name: str,
    index_url: str,
    cache_dir: Path,
) -> dict | None:
    """Return ``packages/<ns>/<name>/HEAD.yml`` or None when absent.

    RTL-P2.381: unversioned packages (PULP, fpganinja/taxi, academic
    repos) don't have real tags, so the tag-driven ``fetch_index_entry``
    call-site has no version to look up.  ``rescan_all.py`` emits a
    sibling ``HEAD.yml`` carrying the scanner's full ``routertl_compat``
    block + resolved commit SHA so commit-pinned installs can consume
    the canonical file list instead of relying on client-side inference.

    Returns None (not raise) on any fetch failure — the caller treats
    a missing HEAD.yml as "fall back to the next data source" rather
    than a hard error, since private repos or freshly-added packages
    may legitimately not have been re-scanned yet.
    """
    try:
        entry = fetch_index_entry(namespace, name, "HEAD", index_url, cache_dir)
    except RuntimeError:
        return None
    if not isinstance(entry, dict):
        return None
    if _entry_has_empty_files(entry):
        return None
    return entry


def _entry_has_empty_files(entry: dict) -> bool:
    """Check if an index entry has an empty or missing compat file list."""
    compat = entry.get("routertl_compat") or entry.get("hdl") or {}
    files = compat.get("files", [])
    return not files


def resolve_version(
    namespace: str,
    name: str,
    constraint: str,
    catalog: list[dict],
) -> str:
    """Resolve a semver constraint to the best matching version.

    Supported constraint formats:
      "2.5.0"   — exact
      "^2.5.0"  — compatible: same major, >= minor.patch
      "~2.5.0"  — patch: same major.minor, >= patch

    Returns the resolved version string.
    Raises ValueError if no matching version is found.
    """
    available = _versions_for(namespace, name, catalog)
    if not available:
        raise ValueError(
            f"Package {namespace}/{name} not found in index catalog.\n"
            f"Run: rr pkg search {name}"
        )

    parsed_available = [(v, _parse_ver(v)) for v in available]
    parsed_available.sort(key=lambda x: x[1], reverse=True)   # newest first

    constraint = constraint.strip()

    if constraint.startswith("^"):
        target = _parse_ver(constraint[1:])
        for ver_str, ver_tuple in parsed_available:
            if ver_tuple[0] == target[0] and ver_tuple >= target:
                return ver_str

    elif constraint.startswith("~"):
        target = _parse_ver(constraint[1:])
        for ver_str, ver_tuple in parsed_available:
            if ver_tuple[0] == target[0] and ver_tuple[1] == target[1] and ver_tuple >= target:
                return ver_str

    else:
        # Exact match
        exact = _parse_ver(constraint)
        for ver_str, ver_tuple in parsed_available:
            if ver_tuple == exact:
                return ver_str

    raise ValueError(
        f"No version of {namespace}/{name} satisfies constraint '{constraint}'.\n"
        f"Available: {', '.join(v for v, _ in parsed_available)}"
    )


def _load_axes_map() -> dict[str, list[str]]:
    """Return a flat {synonym: [all_related_synonyms]} map.

    RTL-P2.368: scripts/axes_map.yml (emitted by RTL-P3.174 phase 2b)
    lists synonym axes per category — protocol ↔ axis/axi-stream/
    axi4-stream/stream, function ↔ mux/multiplexer/demux/fork/..., etc.
    The index-time description rewrites use these; the query-time
    expansion reuses the same source of truth so search + discovery
    stay in lockstep.  Missing file → empty map (degrades to the
    pre-P2.368 literal search).
    """
    try:
        from sdk.cli.sdk_root import resolve_sdk_root
    except ImportError:
        return {}

    sdk_root = resolve_sdk_root()
    if not sdk_root:
        return {}

    axes_path = Path(sdk_root) / "scripts" / "axes_map.yml"
    if not axes_path.exists():
        return {}

    try:
        data = yaml.safe_load(axes_path.read_text()) or {}
    except (OSError, yaml.YAMLError):
        return {}

    flat: dict[str, set[str]] = {}
    for _category, axes in data.items():
        if not isinstance(axes, dict):
            continue
        for _axis, synonyms in axes.items():
            if not isinstance(synonyms, list):
                continue
            lowered = {s.lower() for s in synonyms if isinstance(s, str)}
            for syn in lowered:
                flat.setdefault(syn, set()).update(lowered)

    return {k: sorted(v) for k, v in flat.items()}


def _expand_query_tokens(query: str, axes_map: dict[str, list[str]]) -> list[str]:
    """Expand a search query against the synonym-axes map.

    RTL-P2.368.  Splits *query* into tokens (plus the whole phrase),
    looks each token up in *axes_map*, and returns the union of the
    original tokens + any synonyms found.  Unknown tokens pass through
    unchanged so literal search behaviour is preserved for single-word
    queries that don't hit an axis.

    The whole phrase is included as its own token so multi-word
    synonyms ("axi stream", "axi-stream") still match directly — the
    caller scores substring hits against name / tag / description.
    """
    lowered = query.lower().strip()
    if not lowered:
        return []

    raw_tokens = {lowered}
    raw_tokens.update(t for t in lowered.split() if t)

    expanded: set[str] = set(raw_tokens)
    for token in raw_tokens:
        expanded.update(axes_map.get(token, []))

    # Stable ordering — original query first, then alphabetised synonyms.
    result = [lowered]
    for t in sorted(expanded - {lowered}):
        result.append(t)
    return result


def search_catalog(query: str, catalog: list[dict]) -> list[dict]:
    """Search across name, description, namespace, and tags.

    Results are ranked by relevance:
      1. Exact name match
      2. Name contains query
      3. Tag match
      4. Description match
      5. Namespace match

    RTL-P2.368: tokens are expanded against scripts/axes_map.yml so a
    query like "AXIS MUX" also matches entries that describe themselves
    as "axi4-stream multiplexer" etc.  The highest score across every
    expanded token wins for a given catalog entry.
    """
    tokens = _expand_query_tokens(query, _load_axes_map())
    if not tokens:
        return []

    scored: list[tuple[int, dict]] = []
    for e in catalog:
        name = e.get("name", "").lower()
        desc = (e.get("description") or "").lower()
        ns = (e.get("namespace") or "").lower()
        tags = [t.lower() for t in (e.get("tags") or []) if t]

        best_score = 0
        # Original query keeps the full score band; synonyms downweight
        # slightly so literal matches still rank above synonym hits.
        for idx, token in enumerate(tokens):
            penalty = 0 if idx == 0 else 5
            if name == token:
                score = 100 - penalty
            elif token in name:
                score = 80 - penalty
            elif token in tags:
                score = 60 - penalty
            elif any(token in t for t in tags):
                score = 40 - penalty
            elif token in desc:
                score = 20 - penalty
            elif token in ns:
                score = 10 - penalty
            else:
                score = 0
            if score > best_score:
                best_score = score

        if best_score > 0:
            scored.append((best_score, e))

    scored.sort(key=lambda x: (-x[0], x[1].get("name", "")))
    return [e for _, e in scored]


def suggest_catalog_terms(query: str, catalog: list[dict], limit: int = 5) -> list[str]:
    """Return 'did you mean?' candidate terms for a zero-hit query.

    RTL-P2.369: when search_catalog returns no results, scan the
    catalog for near-matches against *query* and return up to *limit*
    candidate terms (names, tags, and synonym axes) sorted by
    similarity.

    The similarity signal is a plain substring-overlap + shared-prefix
    score — no external deps, fast on the ~900-entry catalog.
    """
    q = query.lower().strip()
    if not q:
        return []

    # Collect candidate terms: package names, tags, and synonym axes.
    terms: set[str] = set()
    for e in catalog:
        name = e.get("name")
        if isinstance(name, str) and name:
            terms.add(name.lower())
        for tag in e.get("tags") or []:
            if isinstance(tag, str) and tag:
                terms.add(tag.lower())
    axes_map = _load_axes_map()
    terms.update(axes_map.keys())

    # Score: exact substring > prefix overlap > shared-letter count.
    def score(term: str) -> tuple[int, int, str]:
        if not term:
            return (0, 0, term)
        tier = 0
        if q in term:
            tier = 3  # q is substring of term
        elif term in q:
            tier = 2  # term is substring of q
        else:
            # Shared prefix length (min 2).
            prefix = 0
            for a, b in zip(q, term):
                if a != b:
                    break
                prefix += 1
            if prefix >= 2:
                tier = 1
        overlap = len(set(q) & set(term))
        return (tier, overlap, term)

    ranked = sorted(
        (t for t in terms if t != q and score(t)[0] > 0),
        key=lambda t: (-score(t)[0], -score(t)[1], t),
    )
    return ranked[:limit]


# ── Internal helpers ──────────────────────────────────────────────────────────


def _http_get(url: str) -> str:
    from urllib.request import Request

    from sdk.engine.registry_auth import get_auth_headers

    headers = get_auth_headers()
    req = Request(url, headers=headers) if headers else url
    with urlopen(req, timeout=_FETCH_TIMEOUT) as resp:
        return resp.read().decode("utf-8")


def _cache_is_fresh(path: Path) -> bool:
    if not path.exists():
        return False
    age = time.time() - path.stat().st_mtime
    return age < _CACHE_TTL_SECONDS


def _touch(path: Path) -> None:
    path.touch()


# Branch names that are used as version strings (not semver)
_BRANCH_VERSIONS = {"master", "main", "develop", "dev", "latest", "stable", "trunk"}

# RTL-P3.184: short/full git shas are lowercase hex strings. Emitted by
# the P1.54 scanner as versions for main-branch scans (e.g. "d2ce1a617bc8",
# "7b364c5dfd5e"). They're valid opaque pins, not semver, so the parser
# must not spam warnings when it can't coerce them into X.Y.Z.
_SHA_RE = re.compile(r"^[0-9a-f]{7,40}$")


def _is_opaque_pin(ver: str) -> bool:
    """Return True for version strings that are branches or git shas.

    These are valid pins, not semver. Silences the 'Non-numeric version
    component' warning for them — the warning is only meaningful for
    strings the user intended as semver but that have a typo or junk.
    """
    lower = ver.lower()
    if lower in _BRANCH_VERSIONS:
        return True
    return bool(_SHA_RE.match(lower))


def _parse_ver(ver: str) -> tuple[int, ...]:
    """Parse 'X.Y.Z' into (X, Y, Z). Strips leading 'v'."""
    ver = ver.lstrip("v")
    # Suppress warnings for branch names + git shas (opaque pins).
    opaque = _is_opaque_pin(ver)
    parts = re.split(r"[.\-]", ver)
    result = []
    for p in parts[:3]:
        try:
            result.append(int(p))
        except ValueError:
            if not opaque:
                _log.warning("Non-numeric version component '%s' in '%s', treating as 0", p, ver)
            result.append(0)
    while len(result) < 3:
        result.append(0)
    return tuple(result)


def _versions_for(namespace: str, name: str, catalog: list[dict]) -> list[str]:
    for entry in catalog:
        if entry.get("namespace") == namespace and entry.get("name") == name:
            return entry.get("versions", [entry.get("latest", "")])
    return []
