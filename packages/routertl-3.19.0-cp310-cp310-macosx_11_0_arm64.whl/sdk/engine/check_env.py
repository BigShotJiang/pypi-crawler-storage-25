#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
RouteRTL SDK Environment Checker.

Reads sdk_requirements.yml and validates the local toolchain against it.
Optionally generates sdk_env.mk with capability flags for Makefile integration.

Usage:
    python3 check_env.py                  # Check and print report
    python3 check_env.py --generate-mk    # Also write sdk_env.mk
"""

import os
import re
import shutil
import subprocess
import sys
from pathlib import Path

# Locate SDK root relative to this script
SCRIPT_DIR = Path(__file__).resolve().parent


def _resolve_requirements_file() -> Path:
    """Locate sdk_requirements.yml, handling both submodule and pip installs."""
    try:
        from sdk.cli.sdk_root import resolve_sdk_root
        root = resolve_sdk_root()
        if root and (root / "sdk" / "sdk_requirements.yml").exists():
            return root / "sdk" / "sdk_requirements.yml"
    except ImportError:
        pass
    # Fallback to __file__ traversal (this file lives at sdk/engine/check_env.py)
    return SCRIPT_DIR.parent / "sdk_requirements.yml"


# Legacy constant — kept for backward compat with tests that import it
SDK_ROOT = SCRIPT_DIR.parent.parent
REQUIREMENTS_FILE = _resolve_requirements_file()


def _augment_path_for_docker():
    """When inside a Docker container, probe /opt for EDA tool binaries.

    Adds found paths to PATH so shutil.which() finds them during check_tool().
    """
    import socket

    hostname = socket.gethostname()
    is_docker = hostname.startswith("routertl-") or Path("/.dockerenv").exists()
    if not is_docker:
        return

    # Common EDA install locations inside Docker volumes
    eda_paths = [
        "/opt/riviera/bin",  # Riviera-PRO
        "/opt/altera/quartus/bin",  # Quartus
        "/opt/intelFPGA_pro/quartus/bin",  # Quartus Pro
    ]
    # Vivado: search for /opt/Xilinx/Vivado/<ver>/bin
    xilinx_base = Path("/opt/Xilinx/Vivado")
    if xilinx_base.is_dir():
        for ver_dir in sorted(xilinx_base.iterdir(), reverse=True):
            bin_dir = ver_dir / "bin"
            if bin_dir.is_dir():
                eda_paths.insert(0, str(bin_dir))
                break  # Use newest version

    # Questa inside Quartus: /opt/altera/questa_fse/bin or /opt/intelFPGA_pro/questa_fse/bin
    for base in ["/opt/altera", "/opt/intelFPGA_pro"]:
        for questa_dir in Path(base).glob("questa*/bin") if Path(base).is_dir() else []:
            eda_paths.append(str(questa_dir))

    current_path = os.environ.get("PATH", "")
    additions = [p for p in eda_paths if os.path.isdir(p) and p not in current_path]
    if additions:
        os.environ["PATH"] = ":".join(additions) + ":" + current_path


# Run PATH augmentation at import time (before any checks)
_augment_path_for_docker()


def load_requirements():
    """Load sdk_requirements.yml using PyYAML.

    Returns None if the file is missing (pip-install mode) so callers
    can degrade gracefully instead of crashing.
    """
    try:
        import yaml
    except ImportError:
        print("❌ PyYAML not installed. Run: pip install pyyaml")
        sys.exit(1)

    req_file = _resolve_requirements_file()
    if not req_file.exists():
        return None

    with open(req_file) as f:
        return yaml.safe_load(f)


def parse_version(version_string):
    """Parse a version string into a tuple of integers for comparison."""
    parts = re.findall(r"\d+", version_string)
    return tuple(int(p) for p in parts)


def check_tool(name, spec):
    """
    Check a single tool against its specification.

    Returns:
        dict with keys: name, found, version, meets_min, status, message
    """
    result = {
        "name": name,
        "found": False,
        "version": None,
        "path": None,
        "meets_min": False,
        "required": spec.get("required", False),
        "role": spec.get("role", ""),
        "status": "missing",
        "message": "",
    }

    check_cmd = spec.get("check_cmd", "")
    if not check_cmd:
        result["message"] = "No check command defined"
        return result

    # Check if binary exists on PATH
    binary = check_cmd.split()[0]
    resolved = shutil.which(binary)
    if not resolved:
        hint = spec.get("install_hint", "")
        result["message"] = "Not found on PATH"
        if hint:
            result["message"] += f" → {hint}"
        return result

    result["found"] = True
    result["path"] = str(Path(resolved).resolve())

    # Get version output
    try:
        # Build clean environment — some tools (e.g., verilator) fail with stale
        # environment variables like VERILATOR_ROOT from old installations.
        env = os.environ.copy()
        if name == "verilator":
            env.pop("VERILATOR_ROOT", None)

        proc = subprocess.run(
            check_cmd.split(),
            capture_output=True,
            text=True,
            timeout=10,
            env=env,
        )
        output = proc.stdout + proc.stderr
    except (subprocess.TimeoutExpired, OSError) as e:
        result["message"] = f"Failed to execute: {e}"
        return result

    # Parse version
    pattern = spec.get("parse_regex", "")
    if pattern:
        match = re.search(pattern, output)
        if match:
            result["version"] = match.group(1)

    # Compare versions
    min_ver = spec.get("min_version")
    if result["version"] and min_ver:
        try:
            if parse_version(result["version"]) >= parse_version(min_ver):
                result["meets_min"] = True
                result["status"] = "ok"
                result["message"] = f"v{result['version']}"
                recommended = spec.get("recommended")
                if recommended and result["version"] != recommended:
                    result["message"] += f" (recommended: {recommended})"
            else:
                result["status"] = "outdated"
                hint = spec.get("install_hint", "")
                result["message"] = f"v{result['version']} < required v{min_ver}"
                if hint:
                    result["message"] += f" → {hint}"
        except (ValueError, TypeError):
            result["status"] = "parse_error"
            result["message"] = "Could not compare versions"
    elif result["found"] and not min_ver:
        # No minimum version required, just needs to exist
        result["meets_min"] = True
        result["status"] = "ok"
        result["message"] = f"v{result['version']}" if result["version"] else "found"
    elif result["found"]:
        result["status"] = "unknown_version"
        result["message"] = "Found but could not determine version"

    return result


def check_environment(quiet=False):
    """
    Check all tools defined in sdk_requirements.yml.

    Returns:
        list of result dicts, one per tool
    """
    reqs = load_requirements()
    if reqs is None:
        if not quiet:
            print("\nℹ️  sdk_requirements.yml not found (pip install mode).")
            print("   Skipping detailed tool checks. Run 'rr doctor' for diagnostics.\n")
        return []
    tools = reqs.get("tools", {})
    results = []

    if not quiet:
        print("\n🔍 RouteRTL SDK — Environment Check")
        print("=" * 60)

    all_required_ok = True

    for name, spec in tools.items():
        result = check_tool(name, spec)
        results.append(result)

        if not quiet:
            required_tag = "req" if result["required"] else "opt"
            if result["status"] == "ok":
                icon = "✅"
            elif result["status"] == "missing" and not result["required"]:
                icon = "⚠️"
            elif result["status"] == "outdated":
                icon = "❌"
            else:
                icon = "❌" if result["required"] else "⚠️"

            role = f"({result['role']})" if result["role"] else ""
            print(f"  {icon} {name:<14} [{required_tag}]  {result['message']}  {role}")

        if result["required"] and result["status"] != "ok":
            all_required_ok = False

    if not quiet:
        print("=" * 60)
        if all_required_ok:
            print("  ✅ All required tools are available.\n")
        else:
            print("  ❌ Some required tools are missing or outdated.\n")

    return results


def generate_mk(results, output_path=None):
    """
    Generate sdk_env.mk with capability flags.

    Example output:
        SDK_HAS_NVC := true
        SDK_HAS_VERILATOR := false
        SDK_ENV_OK := true
    """
    if output_path is None:
        output_path = SDK_ROOT / "sdk_env.mk"

    lines = [
        "# Auto-generated by check_env.py — do not edit",
        "# Re-generate with: make check-env",
        "",
    ]

    all_required_ok = True
    for r in results:
        var_name = f"SDK_HAS_{r['name'].upper()}"
        has_tool = "true" if r["status"] == "ok" else "false"
        lines.append(f"{var_name} := {has_tool}")

        # Cache the resolved binary path for deterministic Makefile resolution
        if r["path"]:
            path_var = f"SDK_PATH_{r['name'].upper()}"
            lines.append(f"{path_var} := {r['path']}")

        if r["required"] and r["status"] != "ok":
            all_required_ok = False

    lines.append("")
    lines.append(f"SDK_ENV_OK := {'true' if all_required_ok else 'false'}")
    lines.append("")

    with open(output_path, "w") as f:
        f.write("\n".join(lines))

    return output_path


def main():
    """CLI entry point for environment checker."""
    import argparse

    parser = argparse.ArgumentParser(description="RouteRTL Environment Checker")
    parser.add_argument(
        "--generate-mk",
        action="store_true",
        help="Generate sdk_env.mk with capability flags",
    )
    parser.add_argument(
        "--quiet",
        "-q",
        action="store_true",
        help="Suppress terminal output (useful for CI)",
    )
    args = parser.parse_args()

    results = check_environment(quiet=args.quiet)

    if args.generate_mk:
        mk_path = generate_mk(results)
        if not args.quiet:
            print(f"  📄 Generated: {mk_path}")

    # Exit with error if required tools are missing
    required_ok = all(r["status"] == "ok" for r in results if r["required"])
    sys.exit(0 if required_ok else 1)


if __name__ == "__main__":
    main()
