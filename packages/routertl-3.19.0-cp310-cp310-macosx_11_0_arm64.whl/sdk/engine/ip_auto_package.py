# SPDX-FileCopyrightText: 2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Auto-package vendored IPs whose component.xml is stale or missing.

RTL-P3.188 — TCL-as-source policy.

Enables a commit policy where only IP *source* (HDL + ip.yml + the
packaging recipe) lives in git. ``component.xml`` and ``xgui/`` become
generated artifacts that ``rr synth`` rebuilds on demand, eliminating
drift between HDL and IP-XACT metadata and stripping ~1.4k-line XML
noise out of diffs.

**Recipe declaration is per-IP, self-contained.** Each vendored IP
opts in by declaring a ``packaging.recipe`` field in its ip.yml:

    # hw/ip/<name>/ip.yml
    ip:
      name: pulp_axis_stream_mux
    packaging:
      recipe: tcl/package.tcl   # relative to this IP's dir

No ``packaging`` block → IP is not claiming to be packageable
(vendored primitives, WIP, scratch) and is silently skipped.

Staleness rules (if ANY fires, package):

    (a) ``hw/ip/<name>/component.xml`` is missing
    (b) any HDL file under the IP dir has mtime newer than
        ``component.xml``
    (c) the packaging recipe itself has mtime newer than
        ``component.xml``
    (d) ip.yml has mtime newer than ``component.xml``

Packaging is invoked via ``vivado -mode batch -source <recipe>`` from
the project root. The recipe owns the vendor/library/taxonomy strings;
this module is just the trigger + cache bookkeeping.
"""

from __future__ import annotations

import logging
import shutil
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

_log = logging.getLogger(__name__)

_HDL_EXTS = (".vhd", ".vhdl", ".v", ".sv", ".svh")


# ── Data classes ───────────────────────────────────────────────────────────────


@dataclass
class StalePackage:
    """One vendored IP that needs (re-)packaging."""
    name: str
    ip_dir: Path
    component_xml: Path       # target path (may not exist yet)
    package_tcl: Path         # the recipe
    reason: str               # human-readable cause: "missing", "hdl newer", ...


@dataclass
class PackageResult:
    """Outcome of a single package invocation."""
    name: str
    ok: bool
    duration_s: float
    log_path: Path | None
    error: str | None = None


# ── Staleness detection ────────────────────────────────────────────────────────


def resolve_packaging_recipe(ip_dir: Path, ip_yml_data: dict) -> Path | None:
    """Return the packaging recipe path declared in ip.yml, or ``None``.

    The field is ``packaging.recipe`` at the top level of ip.yml,
    interpreted as a POSIX-style path relative to ``ip_dir``:

        packaging:
          recipe: tcl/package.tcl

    Returns ``None`` when the block is absent or the field is empty —
    that IP is not eligible for auto-packaging (silently skipped by the
    pre-synth hook; audit does not flag it).
    """
    packaging = (ip_yml_data.get("packaging") or {}) if isinstance(ip_yml_data, dict) else {}
    recipe_rel = packaging.get("recipe") if isinstance(packaging, dict) else None
    if not recipe_rel or not isinstance(recipe_rel, str):
        return None
    # Relative to the IP dir; allow ./nested/paths but reject escapes.
    resolved = (ip_dir / recipe_rel).resolve()
    try:
        resolved.relative_to(ip_dir.resolve())
    except ValueError:
        # Recipe points outside the IP dir — disallowed (IP must be self-contained).
        return None
    return resolved


def _newest_hdl_mtime(ip_dir: Path) -> float:
    """Return the highest mtime found among HDL files under ``ip_dir``.

    Skips generated trees (``xgui/``, ``build/``) to avoid feedback loops
    where a previous packaging run touches files under those directories.
    Returns ``0.0`` if nothing is found.
    """
    best = 0.0
    for path in ip_dir.rglob("*"):
        if not path.is_file():
            continue
        if path.suffix.lower() not in _HDL_EXTS:
            continue
        parts = set(path.relative_to(ip_dir).parts)
        if parts & {"xgui", "build", ".build", ".ipx"}:
            continue
        try:
            mt = path.stat().st_mtime
        except OSError:
            continue
        if mt > best:
            best = mt
    return best


def _staleness_reason(
    component_xml: Path,
    ip_dir: Path,
    package_tcl: Path,
    ip_yml: Path | None = None,
) -> str | None:
    """Return a short reason string if packaging is needed, else ``None``.

    Cheap to call — only does stat() + one directory walk.
    """
    if not component_xml.exists():
        return "missing"
    try:
        xml_mtime = component_xml.stat().st_mtime
    except OSError:
        return "missing"

    try:
        if package_tcl.stat().st_mtime > xml_mtime:
            return "recipe newer"
    except OSError:
        pass

    if ip_yml is not None and ip_yml.exists():
        try:
            if ip_yml.stat().st_mtime > xml_mtime:
                return "ip.yml newer"
        except OSError:
            pass

    if _newest_hdl_mtime(ip_dir) > xml_mtime:
        return "hdl newer"

    return None


def iter_stale_vendored_ips(project_root: Path) -> Iterable[StalePackage]:
    """Yield one :class:`StalePackage` for each IP that needs packaging.

    Uses the P3.187 discovery plumbing so the set of "vendored IPs" stays
    consistent between ``rr pkg audit`` and ``rr synth``. Only yields IPs
    whose ip.yml declares ``packaging.recipe`` — IPs without that field
    are silently skipped (vendored primitives, WIP, not claiming to be
    IP-XACT).
    """
    from sdk.cli.commands.pkg import _discover_vendored_ips

    for ip_info in _discover_vendored_ips(project_root):
        ip_dir: Path = ip_info["path"]
        recipe = resolve_packaging_recipe(ip_dir, ip_info["ip_yml_data"])
        if recipe is None or not recipe.exists():
            continue

        component_xml: Path = ip_info["component_xml"] or (ip_dir / "component.xml")
        reason = _staleness_reason(
            component_xml=component_xml,
            ip_dir=ip_dir,
            package_tcl=recipe,
            ip_yml=ip_info["ip_yml"],
        )
        if reason is None:
            continue
        yield StalePackage(
            name=ip_info["name"],
            ip_dir=ip_dir,
            component_xml=component_xml,
            package_tcl=recipe,
            reason=reason,
        )


# ── Packaging invocation ──────────────────────────────────────────────────────


def _resolve_vivado(project_root: Path) -> str | None:
    """Find the vivado binary, honouring ``hardware.tool_path`` first.

    Mirrors the convention from :func:`_resolve_ide_binary`
    (RTL-P2.407): tool_path bin dirs prepend PATH, then fall back to the
    ambient PATH.
    """
    import os

    from sdk.cli.project_config import load_project_config

    project_yml = project_root / "project.yml"
    extra_dirs: list[str] = []
    if project_yml.exists():
        try:
            config = load_project_config(str(project_yml))
        except (OSError, ValueError, RuntimeError):
            config = {}
        hw = (config.get("hardware") or {}) if isinstance(config, dict) else {}
        tp = hw.get("tool_path") or ""
        if tp:
            tp_path = Path(tp).expanduser()
            # Vivado install typically has bin/ at the root.
            for cand in (tp_path / "bin", tp_path):
                if cand.is_dir():
                    extra_dirs.append(str(cand))

    search_path = os.pathsep.join([*extra_dirs, os.environ.get("PATH", "")])
    return shutil.which("vivado", path=search_path)


def package_ip(
    stale: StalePackage,
    vivado_bin: str,
    project_root: Path,
    *,
    timeout_s: int = 600,
) -> PackageResult:
    """Run the package TCL for one IP. Returns a :class:`PackageResult`.

    Vivado is invoked from ``project_root`` so the TCL's relative paths
    (``file join $repo_root ...``) resolve the way the recipe expects.
    stdout + stderr are captured to ``build/ip_package_<name>/package.log``
    for post-mortem.
    """
    import time

    work_dir = project_root / "build" / f"ip_package_{stale.name}"
    work_dir.mkdir(parents=True, exist_ok=True)
    log_path = work_dir / "package.log"

    cmd = [
        vivado_bin,
        "-mode", "batch",
        "-nojournal",
        "-nolog",
        "-notrace",
        "-source", str(stale.package_tcl),
    ]
    t0 = time.monotonic()
    try:
        with log_path.open("w") as log_fp:
            log_fp.write(f"# {' '.join(cmd)}\n# cwd={project_root}\n\n")
            log_fp.flush()
            proc = subprocess.run(
                cmd,
                cwd=project_root,
                stdout=log_fp,
                stderr=subprocess.STDOUT,
                timeout=timeout_s,
                check=False,
            )
        duration = time.monotonic() - t0
        if proc.returncode == 0:
            return PackageResult(
                name=stale.name, ok=True, duration_s=duration, log_path=log_path,
            )
        return PackageResult(
            name=stale.name, ok=False, duration_s=duration, log_path=log_path,
            error=f"vivado exited with code {proc.returncode}",
        )
    except subprocess.TimeoutExpired:
        duration = time.monotonic() - t0
        return PackageResult(
            name=stale.name, ok=False, duration_s=duration, log_path=log_path,
            error=f"vivado exceeded {timeout_s}s timeout",
        )
    except OSError as exc:
        duration = time.monotonic() - t0
        return PackageResult(
            name=stale.name, ok=False, duration_s=duration, log_path=None,
            error=f"failed to invoke vivado: {exc}",
        )


# ── Orchestrator ──────────────────────────────────────────────────────────────


def auto_package_stale_ips(
    project_root: Path,
    *,
    dry_run: bool = False,
    vivado_bin: str | None = None,
) -> tuple[list[PackageResult], list[StalePackage]]:
    """Run packaging for every stale IP. Returns (results, planned).

    ``planned`` is the full list of stale IPs identified regardless of
    outcome (useful for dry-run). ``results`` is empty in dry-run mode,
    otherwise contains one entry per IP we attempted to package.

    Caller decides what to do when any result has ``ok=False`` (typically
    abort synth with a non-zero exit).
    """
    planned = list(iter_stale_vendored_ips(project_root))
    if not planned or dry_run:
        return [], planned

    if vivado_bin is None:
        vivado_bin = _resolve_vivado(project_root)
    if not vivado_bin:
        results = [
            PackageResult(
                name=sp.name, ok=False, duration_s=0.0, log_path=None,
                error="vivado not found on PATH (set hardware.tool_path)",
            )
            for sp in planned
        ]
        return results, planned

    results: list[PackageResult] = []
    for sp in planned:
        _log.info("Packaging %s (reason: %s)", sp.name, sp.reason)
        results.append(package_ip(sp, vivado_bin, project_root))
    return results, planned
