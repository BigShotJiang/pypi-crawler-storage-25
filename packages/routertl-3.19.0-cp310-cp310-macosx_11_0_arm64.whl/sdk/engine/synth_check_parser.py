# SPDX-FileCopyrightText: 2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Parser for post-synthesis constraint check reports.

Reads ``reports/synth_check_report.json`` emitted by vendor-specific
TCL scripts (``synth_check.tcl``) and exposes structured results for
CLI rendering and CI consumption.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path

_SEVERITY_RANK = {"ERROR": 0, "WARNING": 1, "INFO": 2}


@dataclass
class CheckItem:
    """A single constraint check result."""

    id: str  # e.g. "unconstrained_clocks"
    name: str  # e.g. "Unconstrained Clocks"
    severity: str  # "ERROR", "WARNING", "INFO"
    passed: bool
    details: list[str] = field(default_factory=list)
    count: int = 0


@dataclass
class CheckReport:
    """Aggregated results from a post-synthesis constraint check."""

    vendor: str = ""
    tool_name: str = ""
    timestamp: str = ""
    checks: list[CheckItem] = field(default_factory=list)
    summary: dict = field(default_factory=dict)
    timing: dict = field(default_factory=dict)

    @classmethod
    def from_json(cls, path: Path) -> "CheckReport":
        """Parse a ``synth_check_report.json`` file."""
        with open(path) as f:
            data = json.load(f)

        checks = []
        for item in data.get("checks", []):
            checks.append(CheckItem(
                id=item.get("id", ""),
                name=item.get("name", ""),
                severity=item.get("severity", "INFO"),
                passed=item.get("passed", True),
                details=item.get("details", []),
                count=item.get("count", 0),
            ))

        return cls(
            vendor=data.get("vendor", ""),
            tool_name=data.get("tool_name", ""),
            timestamp=data.get("timestamp", ""),
            checks=checks,
            summary=data.get("summary", {}),
            timing=data.get("timing", {}),
        )

    def has_issues(self) -> bool:
        """Return True if any check has ERROR or WARNING severity and failed."""
        return any(
            not c.passed and c.severity in ("ERROR", "WARNING")
            for c in self.checks
        )

    def errors(self) -> list[CheckItem]:
        """Return all failed ERROR-level checks."""
        return [c for c in self.checks if not c.passed and c.severity == "ERROR"]

    def warnings(self) -> list[CheckItem]:
        """Return all failed WARNING-level checks."""
        return [c for c in self.checks if not c.passed and c.severity == "WARNING"]

    def passed_checks(self) -> list[CheckItem]:
        """Return all passed checks."""
        return [c for c in self.checks if c.passed]

    def sorted_checks(self) -> list[CheckItem]:
        """Return checks sorted by severity (errors first)."""
        return sorted(
            self.checks,
            key=lambda c: (_SEVERITY_RANK.get(c.severity, 99), c.passed),
        )
