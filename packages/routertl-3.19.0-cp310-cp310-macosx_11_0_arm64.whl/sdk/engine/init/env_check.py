# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Environment checking and Git LFS auto-pull.

Extracted from init_project.py as part of P2.67.
"""

import logging
import shutil
import subprocess
from pathlib import Path


def check_environment():
    """Check SDK tool requirements using sdk_requirements.yml."""
    # Import from sibling module
    try:
        from sdk.engine.check_env import check_environment as _check_env

        _check_env()
    except ImportError:
        # Fallback: basic existence check if check_env.py is missing
        print("\n🔍 Checking environment (basic)...")
        for tool in ["nvc", "make", "python3"]:
            path = shutil.which(tool)
            if path:
                print(f"   ✅ {tool:<10} found: {path}")
            else:
                print(f"   ⚠️  {tool:<10} not found.")


def _check_lfs():
    """Check for Git LFS and auto-pull if .gitattributes uses LFS filters."""
    gitattributes = Path(".gitattributes")
    if not gitattributes.exists():
        return

    try:
        content = gitattributes.read_text()
    except OSError:
        return

    if "filter=lfs" not in content:
        return

    print("\n🔍 Checking Git LFS...")

    # Check if git-lfs is installed
    try:
        result = subprocess.run(
            ["git", "lfs", "version"],
            capture_output=True, text=True, timeout=10,
        )
        if result.returncode != 0:
            print("   ⚠️  git-lfs not installed — LFS-tracked files may be pointer stubs.")
            from sdk.cli.platform_hints import install_cmd
            _lfs_cmd = install_cmd("git-lfs") or "install git-lfs"
            print(f"      Install: {_lfs_cmd} && git lfs install")
            return
    except FileNotFoundError:
        print("   ⚠️  git-lfs not installed — LFS-tracked files may be pointer stubs.")
        print("      Install: sudo apt install git-lfs && git lfs install")
        return
    except (OSError, subprocess.SubprocessError):
        return

    ver = result.stdout.strip().split("\n")[0] if result.stdout else "unknown"
    print(f"   ✅ git-lfs  found: {ver}")

    # Auto-pull LFS files
    print("   📥 Running git lfs pull...")
    try:
        pull = subprocess.run(
            ["git", "lfs", "pull"],
            capture_output=True, text=True, timeout=120,
        )
        if pull.returncode == 0:
            print("   ✅ LFS files pulled successfully.")
        else:
            print("   ⚠️  git lfs pull returned errors (non-fatal).")
            if pull.stderr:
                for line in pull.stderr.strip().splitlines()[:3]:
                    print(f"      {line}")
    except (OSError, subprocess.SubprocessError) as e:
        import traceback as _tb

        logging.debug("git lfs pull failed:\n%s", _tb.format_exc())
        print(f"   ⚠️  git lfs pull failed: {e}")
