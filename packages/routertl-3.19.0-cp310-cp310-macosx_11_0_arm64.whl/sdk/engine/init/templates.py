# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Project template discovery, listing, and application.

Extracted from init_project.py as part of P2.67.
"""

import sys
from pathlib import Path


def _discover_templates():
    """Discover available templates from SDK examples/ directory."""
    script_dir = Path(__file__).resolve().parent
    examples_dir = script_dir.parent.parent.parent / "examples"
    templates = {}
    if examples_dir.is_dir():
        for d in sorted(examples_dir.iterdir()):
            if d.is_dir() and (d / "project.yml").exists():
                # Parse description from README if available
                desc = ""
                readme = d / "README.md"
                if readme.exists():
                    lines = readme.read_text().splitlines()
                    # First non-empty, non-heading line is the description
                    for line in lines:
                        stripped = line.strip()
                        if stripped and not stripped.startswith("#"):
                            desc = stripped
                            break
                templates[d.name] = {"path": d, "description": desc}
    return templates


def _list_templates():
    """Print available templates and exit."""
    templates = _discover_templates()
    if not templates:
        print("❌ No templates found.")
        sys.exit(1)
    print("\n📋 Available RouteRTL Templates:\n")
    for name, info in templates.items():
        desc = info["description"] or "(no description)"
        print(f"  {name:<15} {desc}")
    print("\nUsage: rr init --template <name> --name <project_name>")


def _apply_template(template_name, project_name, sdk_path):
    """Copy a template to CWD, substituting the project name."""
    templates = _discover_templates()
    if template_name not in templates:
        available = ", ".join(templates.keys()) or "none"
        print(f"❌ Unknown template '{template_name}'. Available: {available}")
        sys.exit(1)

    template_dir = templates[template_name]["path"]
    dest = Path.cwd()

    # Guard: don't overwrite existing project
    if (dest / "project.yml").exists():
        print("❌ Error: 'project.yml' already exists in this directory!")
        print("   Aborting to prevent overwriting.")
        sys.exit(1)

    print(f"📦 Applying template '{template_name}'...")

    # Files/dirs to skip when copying
    skip_names = {"__pycache__", ".pytest_cache", "sim_build", "build_env.mk", "build_env.tcl"}

    for item in template_dir.rglob("*"):
        rel = item.relative_to(template_dir)
        # Skip internal artifacts
        if any(part in skip_names for part in rel.parts):
            continue

        dest_path = dest / rel
        if item.is_dir():
            dest_path.mkdir(parents=True, exist_ok=True)
        elif item.is_file():
            dest_path.parent.mkdir(parents=True, exist_ok=True)
            try:
                content = item.read_text()
            except UnicodeDecodeError:
                # Binary file (e.g. .fst waveform) — copy as-is
                import shutil
                shutil.copy2(item, dest_path)
                continue
            # Substitute template project name with user's project name
            old_name = template_name
            content = content.replace(f"name: {old_name}", f"name: {project_name}")
            content = content.replace(f"{old_name}_top", f"{project_name}_top")
            content = content.replace(f"tb_{old_name}_top", f"tb_{project_name}_top")
            # Fix SDK path in Makefile (template uses relative ../../..,
            # consumer uses path-agnostic resolution)
            if item.name == "Makefile":
                content = content.replace(
                    "SDK_SUBMODULE_PATH := ../..",
                    f"SDK_ROOT := $(shell rr sdk-path 2>/dev/null || echo {sdk_path})",
                )
                content = content.replace(
                    "-include $(SDK_SUBMODULE_PATH)/tools/Common.mk",
                    "-include $(SDK_ROOT)/Common.mk",
                )
                content = content.replace(
                    "-include $(SDK_SUBMODULE_PATH)/sdk/Common.mk",
                    "-include $(SDK_ROOT)/Common.mk",
                )
            dest_path.write_text(content)

    print(f"   ✅ Template '{template_name}' applied.")
    print(f"   Created: {', '.join(str(p.relative_to(dest)) for p in sorted(dest.rglob('*')) if p.is_file())}")
