# SPDX-FileCopyrightText: 2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Generate CLAUDE.md for RouteRTL projects.

Produces a vendor-aware CLAUDE.md that teaches AI agents (Claude Code,
Cursor, Copilot, Gemini) how to operate inside an rr project.  This is
not documentation — it's an API for AI agents.

RTL-P2.218

Usage::

    from sdk.engine.init.claude_md import generate_claude_md
    content = generate_claude_md(vendor="xilinx", language="vhdl")
    Path("CLAUDE.md").write_text(content)
"""

from __future__ import annotations


def generate_claude_md(
    vendor: str = "xilinx",
    language: str = "vhdl",
    has_linux: bool = False,
    has_packages: bool = False,
    project_name: str = "",
) -> str:
    """Generate CLAUDE.md content tailored to the project configuration."""

    sections = [
        _header(project_name),
        _project_context(),
        _build_flow(vendor),
        _simulation_api(language),
        _verification_philosophy(),
        _tcl_hooks(vendor),
        _design_rules(),
        _ip_and_packages(has_packages),
    ]

    if has_linux:
        sections.append(_embedded_linux())

    sections.append(_conventions())
    sections.append(_agent_directives())

    return "\n".join(sections)


def _header(project_name: str) -> str:
    name = f" — {project_name}" if project_name else ""
    return f"""# CLAUDE.md{name}

This file teaches AI agents how to work in this RouteRTL project.
Read `project.yml` first — it is the single source of truth for
the build configuration.
"""


def _project_context() -> str:
    return """## Project Context

```bash
cat project.yml          # Full build config — start here
rr status                # Quick project health check
rr lock status           # Frozen toolchain state (vendor, tool, version, part)
rr rules list            # Active design rules with incident stories
```

`project.yml` contains: target part, source lists, IP references, TCL hooks,
simulation config, build options, and pre-commit hooks.  Everything the build
system needs is declared here — no hidden state.

If a `target:` field exists in project.yml, it redirects to a target-specific
config (e.g. `targets/arty.yml`).  Use `RR_TARGET=<path>` to switch at runtime.
"""


def _build_flow(vendor: str) -> str:
    vendor_notes = {
        "xilinx": (
            "Vivado project is created from TCL (`gen_project.tcl`), not from the GUI.\n"
            "The `.xpr` is regenerated on every `rr project` — don't edit it manually."
        ),
        "altera": (
            "Quartus project is created from TCL.  QSYS subsystems are generated\n"
            "automatically via pre-build hooks.  Check `build_options.edition` for\n"
            "Standard vs Pro — IP compatibility depends on it."
        ),
        "lattice": (
            "Radiant project is created from TCL.  IPX files are included via\n"
            "`sources.ip` in project.yml."
        ),
        "microchip": (
            "Libero project is created from TCL.  SmartDesign CXZ files go in\n"
            "`sources.ip`."
        ),
    }

    note = vendor_notes.get(vendor, "")

    return f"""## Build Flow

```bash
rr project              # Generate vendor project from project.yml
rr synth run            # Run synthesis
rr implementation       # Run place & route (alias: rr impl)
rr bitstream            # Generate bitstream (alias: rr bit)
rr program              # Program the FPGA board
```

**Multi-target switching:**
```bash
rr target set <name>    # Switch active build configuration
rr target list          # Show available targets
```

**Reproducible builds:**
```bash
rr lock                 # Freeze toolchain + source hashes
rr lock --check         # CI: verify nothing drifted
```

{note}
"""


def _simulation_api(language: str) -> str:
    lang_example = "vhdl" if "vhdl" in language.lower() else "verilog"
    ext = "vhd" if lang_example == "vhdl" else "sv"

    return f"""## Simulation — Cocotb API

Tests live in `sim/cocotb/tests/test_<name>.py`.  Every test file follows this
structure — **copy this template when creating a new test:**

```python
import cocotb
from cocotb.clock import Clock
from cocotb.triggers import ClockCycles, RisingEdge

from routertl_core.sim.simulation import run_simulation

# Optional: SDK default library paths (XPM, unisim, etc.)
# from engine.default_libraries import DEFAULT_LIBRARIES

GENERICS = {{
    "G_DATA_WIDTH": 16,
}}


def main():
    \"\"\"Simulation entry point — called by `rr sim test_<name>`.\"\"\"
    run_simulation(
        top_level="my_module",          # Top-level entity/module name
        module="test_my_module",        # This Python file (without .py)
        custom_libraries={{
            "work": [
                "src/my_module.{ext}",
                # Add all source files the entity depends on.
                # The dependency resolver handles compile order —
                # just list the files, don't worry about ordering.
            ],
        }},
        generics=GENERICS,
        waves=True,                     # Generates .fst waveform
        simulator="nvc",                # Or: "ghdl", "verilator", "questa"
    )


@cocotb.test()
async def test_basic(dut):
    \"\"\"Example test — replace with real assertions.\"\"\"
    clock = Clock(dut.CLK, 10, units="ns")
    cocotb.start_soon(clock.start())

    # Reset
    dut.RST.value = 1
    await ClockCycles(dut.CLK, 10)
    dut.RST.value = 0
    await RisingEdge(dut.CLK)

    # Stimulus + assertions
    await ClockCycles(dut.CLK, 100)
    assert int(dut.SOME_SIGNAL.value) == 1, "Expected SOME_SIGNAL high"


if __name__ == "__main__":
    main()
```

### run_simulation() parameters

| Parameter | Type | Purpose |
|---|---|---|
| `top_level` | str | Top-level entity/module name |
| `module` | str | Python test module name (this file, without `.py`) |
| `custom_libraries` | dict | Library name -> list of source files |
| `hdl_sources` | list | Additional sources compiled into `work` |
| `generics` / `parameters` | dict | VHDL generics or Verilog parameters |
| `simulator` | str | Force backend: `"nvc"`, `"ghdl"`, `"verilator"`, `"questa"` |
| `includes` | list | SystemVerilog include directories |
| `waves` | bool | Generate waveforms (default: True) |
| `wave_formats` | list | `["fst"]` or `["vcd"]` |
| `seed` | int | Random seed for reproducibility |
| `extra_env` | dict | Extra environment variables for the simulator |
| `strict_warnings` | bool | Treat HDL warnings as errors |

### Commands

```bash
rr sim <test_name>      # Run a single test (e.g., rr sim test_counter)
rr sim                  # Run the default test
rr regression           # Run ALL tests
rr scan-tests           # Discover available tests
rr waves                # Open waveform viewer
rr testgen              # Generate test skeleton from top-level entity
```

### Creating a new test — step by step

1. Create `sim/cocotb/tests/test_<name>.py` using the template above
2. Set `top_level` to your entity/module name
3. Set `module` to the Python filename (without `.py`)
4. List ALL source files the entity depends on in `custom_libraries`
5. Write `@cocotb.test()` async functions with assertions
6. Add `if __name__ == "__main__": main()` at the bottom
7. Run: `rr sim test_<name>`
"""


def _verification_philosophy() -> str:
    return """## Verification Philosophy — Break the DUT

**Your job is to prove the DUT does NOT work.**  A test suite where everything
passes on the first run is a bad test suite — it means you tested the golden
path and missed the corners where bugs hide.

### Mindset

- **Assume the DUT is broken** until your tests prove otherwise
- **Write adversarial tests first** — try to make the design fail, overflow,
  underflow, hang, corrupt data, or violate timing
- **If all tests pass immediately**, you haven't tested hard enough — add
  harder cases until something breaks or you've exhausted the attack surface
- **When a test fails, the DUT is guilty until proven innocent** — diagnose
  the RTL first, not the test.  Relaxing an assertion to make a test pass
  is verification malpractice

### Corner case checklist

Work through these for every DUT — skip only if the category genuinely
doesn't apply:

| Category | What to test |
|---|---|
| **Reset** | Assert reset mid-transaction.  Release reset while inputs are active.  Double-reset. |
| **Boundaries** | Values: 0, 1, MAX-1, MAX.  Counter rollover.  Address space edges. |
| **Back-to-back** | Zero-gap consecutive transactions.  No idle cycles between operations. |
| **Overflow / underflow** | Write to a full FIFO.  Read from an empty FIFO.  Counter wrap-around. |
| **Simultaneous** | Concurrent read+write.  Multiple masters asserting at once.  Bus contention. |
| **Stall / backpressure** | De-assert ready mid-transfer.  Randomly toggle valid/ready. |
| **Clock enable** | Toggle clock enable mid-operation.  Disable for N cycles, re-enable. |
| **Generics / parameters** | Test at minimum, maximum, and unusual values (width=1, depth=1). |
| **Ordering** | Out-of-order responses (if protocol allows).  Interleaved transactions. |
| **Long duration** | Run thousands of cycles.  Stress the design over time — some bugs only appear after many iterations. |

### Simulator-aware testing

Simulators themselves can have race conditions and delta-cycle ordering
differences.  Be aware of these pitfalls:

- **Off-by-one-cycle failures** may be a simulator delta-cycle artefact,
  not a DUT bug.  If a test fails by exactly one clock cycle, try a
  different simulator backend (`nvc` vs `ghdl` vs `verilator`) before
  blaming the RTL.
- **Time-zero initialisation** varies between simulators — don't rely on
  signal values before the first rising edge after reset.
- **VHDL `'last_value`** semantics differ between NVC and GHDL in edge
  cases — avoid using it in assertions.
- **Verilator is cycle-based** — it cannot model asynchronous resets or
  multi-clock designs with the same fidelity as event-driven simulators.
- When a test passes on one simulator but fails on another, the
  **conservative answer is usually that the DUT has a real issue** that
  one simulator happens to mask.

### Test structure pattern

For each DUT, write tests in this order:
1. **Smoke test** — basic functionality works at all (reset, single transaction)
2. **Adversarial tests** — the corner case checklist above
3. **Stress test** — long random stimulus with self-checking scoreboard
4. **Regression anchor** — if you found a bug, write the minimal test that
   reproduces it before fixing it (this becomes the regression test)
"""


def _tcl_hooks(vendor: str) -> str:
    vendor_examples = {
        "xilinx": {
            "yaml": """```yaml
tcl_hooks:
  gen_project:
    - tcl/hooks/zynq_bd.tcl          # Block design creation
  synthesis:
    - tcl/hooks/synth_options.tcl     # set_property directives
  implementation:
    - tcl/hooks/impl_directives.tcl   # P&R strategy overrides
  bitstream:
    - tcl/hooks/post_bitstream.tcl    # Post-bitstream actions
```""",
            "example_hook": """```tcl
# tcl/hooks/synth_options.tcl — sourced during synthesis stage
# Available variables (injected by rr):
#   $project_name  — from project.yml
#   $top_module    — top-level entity
#   $part          — FPGA part number
#   $build_dir     — build output directory

# Example: set synthesis strategy for area optimisation
set_property strategy Flow_AreaOptimized_high [get_runs synth_1]

# Example: add timing constraints dynamically
set_property -name {STEPS.SYNTH_DESIGN.ARGS.MORE OPTIONS} \\
    -value {-mode out_of_context} -objects [get_runs synth_1]
```""",
            "extra": """
**Importing Vivado Block Designs:**
```bash
rr hook adapt <vivado_exported_bd.tcl>   # Strip boilerplate, register as hook
```""",
        },
        "altera": {
            "yaml": """```yaml
tcl_hooks:
  gen_project:
    - tcl/hooks/qsys_setup.tcl        # Platform Designer subsystem config
  synthesis:
    - tcl/hooks/quartus_options.tcl    # Synthesis settings
  implementation:
    - tcl/hooks/fitter_options.tcl     # Fitter directives
```""",
            "example_hook": """```tcl
# tcl/hooks/quartus_options.tcl — sourced during synthesis stage
# Available variables (injected by rr):
#   $project_name  — from project.yml
#   $top_module    — top-level entity
#   $part          — FPGA part number

# Example: set Quartus synthesis optimisation
set_global_assignment -name OPTIMIZATION_MODE "HIGH PERFORMANCE EFFORT"
set_global_assignment -name FITTER_EFFORT "STANDARD FIT"
```""",
            "extra": """
**QSYS generation** runs automatically via `hooks.pre_build` if configured.""",
        },
    }

    v = vendor_examples.get(vendor, vendor_examples["xilinx"])

    return f"""## Hooks — Build Pipeline Extension Points

The rr build pipeline has two hook systems: **TCL hooks** injected at vendor
tool stages, and **Python/script hooks** that run before or after the build.

### Build stages (in execution order)

| Stage | `tcl_hooks` key | When it runs | Use case |
|---|---|---|---|
| Project generation | `gen_project` | `rr project` | Block designs, IP config, constraints |
| Synthesis | `synthesis` | `rr synth run` | Strategy overrides, property directives |
| Implementation | `implementation` | `rr impl` | P&R directives, floorplanning |
| Bitstream | `bitstream` | `rr bitstream` | Post-bitstream actions, MCS generation |

### TCL hooks — vendor tool injection

TCL hooks are sourced **inside the vendor tool** (Vivado, Quartus, etc.) at
the specified stage.  They have access to the full vendor TCL API.

{v["yaml"]}

**What's available inside a TCL hook:**

{v["example_hook"]}
{v["extra"]}

**Adding a TCL hook:**
1. Create a `.tcl` file in `tcl/hooks/`
2. Add its path to `tcl_hooks.<stage>` in project.yml
3. Run `rr project` to regenerate — the hook is sourced at the right stage

### Python/script hooks — pre-build and post-build

Script hooks run **outside** the vendor tool — before or after the build
pipeline.  They are Python scripts by default but can be any executable.
Use them for code generation, IP parameter computation, config
preprocessing, or deployment.

```yaml
hooks:
  pre_build:
    - name: generate_regbank
      script: tools/gen_regbank.py          # Python script (default)
      args: [project_regbank.yml, --output, src/generated/]
      expected_outputs:
        - src/generated/system_regbank_pkg.vhd
      watch:                                # Only re-run if inputs changed
        - "project_regbank.yml"
        - "tools/gen_regbank.py"
      clean_before_run: true                # Delete stale outputs first

    - name: generate_ip_params
      script: tools/compute_ip_params.py    # Another Python hook
      args: [system_config.yml]
      expected_outputs:
        - src/generated/ip_params_pkg.vhd
```

**Hook schema fields:**

| Field | Required | Purpose |
|---|---|---|
| `name` | yes | Human-readable hook name (shown in build output) |
| `script` | yes | Path to Python script or executable |
| `args` | no | Arguments passed to the script |
| `expected_outputs` | no | Files the hook must produce (validated after run) |
| `watch` | no | Glob patterns — skip hook if inputs haven't changed |
| `clean_before_run` | no | Delete stale outputs before running (default: true) |
| `pre_generated` | no | Skip execution entirely — outputs already provided |

**Adding a script hook:**
1. Create a Python script in `tools/`
2. Add it to `hooks.pre_build` in project.yml with `name`, `script`, `args`
3. List `expected_outputs` so rr validates the hook produced its files
4. Add `watch` globs for incremental builds (skip if inputs unchanged)
"""


def _design_rules() -> str:
    return """## Design Rules

RouteRTL ships with built-in design rules that catch known FPGA pitfalls.
Rules are scoped by vendor, tool, and tool version — only relevant rules
fire for your project.

```bash
rr rules check          # Scan project against design rules
rr rules check --strict # CI mode: warnings are errors
rr rules list           # Show all active rules with incident stories
rr rules add --from-incident   # Capture a rule from a bug you just hit
```

**Every rule has an incident story** — the real bug that inspired it.
Read them to understand *why*, not just *what*.

**If you find a new pitfall during debugging, capture it immediately:**
```bash
rr rules add --from-incident
```
The pain fades fast.  The rule persists.
"""


def _ip_and_packages(has_packages: bool) -> str:
    pkg_section = ""
    if has_packages:
        pkg_section = """
**External packages (from routertl registry):**
```bash
rr pkg add <namespace/name>    # Add a package dependency
rr pkg install                 # Install all packages from ip.lock
rr pkg verify                  # Check integrity against lock hashes
```
"""

    return f"""## IP & Package Management

**IP manifests** (project-local IPs):
```yaml
sources:
  ips:
    - ip/uart_core/ip.yml       # IP manifest files
  ip_paths:
    - ip/vendor_ips             # Directories scanned for component.xml
```

**IP-XACT import:**
```bash
rr ip import <component.xml>   # Parse IP-XACT → generate ip.yml
```

**Vivado project migration:**
```bash
rr migrate <project.xpr>       # Parse .xpr → generate targets/<name>.yml
```
{pkg_section}"""


def _embedded_linux() -> str:
    return """## Embedded Linux

```bash
rr linux build          # Full pipeline: BSP → U-Boot → Kernel → SD card
rr linux gen            # Generate software bindings (DTBO, C headers, Python UIO)
rr linux xsa            # Export Vivado hardware platform (.xsa)
rr linux qemu boot      # Boot in QEMU without hardware
rr linux qemu test      # Headless CI test in QEMU
```
"""


def _conventions() -> str:
    return """## Conventions

- **Never sort HDL files alphabetically** — use the dependency resolver
- **Never hardcode vendor tool paths** — use `project.yml` hardware.tool_path
- **SV includes/defines are auto-resolved** — don't add manual fields
- **Always power off FPGA board after test** (pass or fail)
- **project.yml is the single source of truth** — don't duplicate config elsewhere
- **Pre-commit hooks are enforced** — `rr` projects lint before every commit
"""


def _agent_directives() -> str:
    return """## Agent Directives

When working in this project as an AI agent:

1. **Read `project.yml` first** — it tells you everything about the build
2. **Run `rr rules check` before committing** — catch known pitfalls early
3. **Run `rr rules list` before proposing IP configurations** — learn from past incidents
4. **Use `rr lock --check`** after any toolchain change to detect drift
5. **Don't reinvent the build system** — project.yml + TCL hooks cover it
6. **Write tests that attack the DUT** — see Verification Philosophy above.
   Never write a test just to confirm the happy path.  Never weaken an
   assertion to make a test pass.  If a test fails, investigate the RTL first.

### Filing rules from debugging sessions

When you discover a bug or pitfall during a debugging session, **file a design rule
before closing the conversation**.  This is how the project accumulates institutional
knowledge — rules outlive chat sessions.

**When to file a rule:**
- You found a hardware/IP property value that causes silent failures
- A vendor tool version introduced a breaking change
- An interface configuration that "looks right" but causes subtle bugs
- Any issue where the *root cause* is a checkable project property

**How to file (non-interactive — preferred for agents):**
```bash
rr rules add \\
  --id CUSTOM-NNN \\
  --severity warning \\
  --message "What this rule checks for" \\
  --property "the_property_name" \\
  --condition "== bad_value" \\
  --incident "What happened, how long it took to find, what was misleading" \\
  --fix "Exact steps to fix it"
```

**What makes a good rule:**
- `--incident` is the most important field — write the full story (what broke,
  how you found it, how long it took, what was misleading)
- `--property` + `--condition` make the rule *automatically checkable* by
  `rr rules check` — without these it's just documentation
- Use `--severity error` for things that will definitely break the build,
  `warning` for likely problems, `info` for gotchas

**Don't file a rule when:**
- The fix is a typo or one-off config mistake (no pattern to catch)
- The issue can't be reduced to a checkable property/condition
- An existing rule already covers it (`rr rules list` to check)

This CLAUDE.md is a starting point.  The project owner can add project-specific
knowledge below this line (sensor addresses, team conventions, known quirks).

---
<!-- Project-specific notes below -->
"""
