#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
Backward-compatible wrapper — delegates to run_hooks.py --stage pre_build.

Kept for Makefile and legacy callers that reference run_prebuild_hooks.py
by name. New code should use run_hooks.py directly.
"""

import sys

from sdk.engine.run_hooks import main as _hooks_main
from sdk.engine.run_hooks import run_hook  # noqa: F401 — re-export for tests/callers

# Inject --stage pre_build if not already present
if "--stage" not in sys.argv:
    sys.argv.insert(1, "--stage")
    sys.argv.insert(2, "pre_build")


if __name__ == "__main__":
    sys.exit(_hooks_main())
