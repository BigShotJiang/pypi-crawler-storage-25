# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

import logging
import subprocess
from pathlib import Path


def run_git_cmd(cmd, cwd=None):
    """Running a git command."""
    try:
        subprocess.run(cmd, check=True, cwd=cwd, capture_output=True, text=True)
        return True
    except subprocess.CalledProcessError as e:
        logging.error(f"Git command failed: {e.cmd}")
        logging.error(e.stderr)
        return False


def ensure_dependencies(config, project_root):
    """Ensures all dependencies defined in config are present."""
    logging.info("Checking dependencies...")
    deps = config.get("dependencies", {})
    if not deps:
        logging.info("No dependencies defined.")
        return

    root_path = Path(project_root)

    for name, info in deps.items():
        rel_path = info.get("path")
        if not rel_path:
            logging.warning(f"Dependency '{name}' has no path defined. Skipping.")
            continue

        target_path = root_path / rel_path

        if target_path.exists():
            # Check if it's a git repo and valid
            if (target_path / ".git").exists():
                logging.info(f"Dependency '{name}' already exists at {rel_path}.")
                # Optional: git pull could go here if we wanted auto-update
                continue
            else:
                # Check if directory has actual content — an empty dir is
                # likely from an interrupted clone and should be recovered.
                has_content = any(target_path.iterdir())
                if has_content:
                    logging.warning(
                        f"Path '{rel_path}' exists with content but is not a "
                        f"git repo. Skipping. Remove it manually if you want "
                        f"the SDK to re-clone."
                    )
                    continue
                else:
                    logging.warning(
                        f"Path '{rel_path}' is an empty directory (likely "
                        f"from an interrupted clone). Removing and re-cloning."
                    )
                    target_path.rmdir()

        # Create parent directory if needed
        target_path.parent.mkdir(parents=True, exist_ok=True)

        urls = []
        if "url" in info:
            urls.append(info["url"])
        if "fallback_url" in info:
            urls.append(info["fallback_url"])

        success = False
        for url in urls:
            logging.info(f"Attempting to clone '{name}' from {url}...")
            cmd = ["git", "clone", url, str(target_path)]
            if run_git_cmd(cmd):
                success = True
                print(f"✅ Successfully cloned '{name}'")
                break
            else:
                logging.warning(f"Failed to clone from {url}")

        if not success:
            logging.error(f"❌ Failed to install dependency '{name}' from any source.")


def ensure_packages(config, project_root):
    """Install registry packages declared under ``packages:`` in config.

    Delegates to :mod:`sdk.engine.package_resolver`.  Returns a library →
    file-list dict (same shape as :func:`get_dependency_files`) so callers
    can merge both sources uniformly.
    """
    packages = config.get("packages") or {}
    if not packages:
        return {}
    try:
        from sdk.engine.package_resolver import resolve_packages
        return resolve_packages(config, project_root)
    except (RuntimeError, ValueError, OSError) as exc:
        logging.error("Package resolution failed: %s", exc)
        return {}


def get_dependency_files(config, project_root):
    """Scans dependencies and returns file lists grouped by library."""
    deps = config.get("dependencies", {})
    lib_files = {}  # library -> [files]

    root_path = Path(project_root)

    for name, info in deps.items():
        lib_name = info.get("library")
        if not lib_name:
            continue

        rel_path = info.get("path")
        if not rel_path:
            continue

        dep_path = root_path / rel_path

        if not dep_path.exists():
            continue

        # Scan for VHDL files
        # We assume recursiveness
        raw_files = []
        for p in dep_path.rglob("*.vhd"):
            if "simulation" in p.parts:
                continue
            raw_files.append(p)
        for p in dep_path.rglob("*.vhdl"):
            if "simulation" in p.parts:
                continue
            raw_files.append(p)

        # Sort files topologically
        sorted_paths = topological_sort_vhdl(raw_files)

        # Convert to relative paths
        files = []
        for p in sorted_paths:
            try:
                files.append(str(p.relative_to(root_path)))
            except ValueError:
                pass

        if lib_name not in lib_files:
            lib_files[lib_name] = []
        lib_files[lib_name].extend(files)

    # Merge package-resolved files (packages: key)
    pkg_files = ensure_packages(config, project_root)
    for lib_name, files in pkg_files.items():
        if lib_name not in lib_files:
            lib_files[lib_name] = []
        lib_files[lib_name].extend(files)

    return lib_files


import re


def parse_vhdl_file(filepath):
    """Simple regex parser to find defined units and dependencies."""
    defines = set()
    requires = set()

    with open(filepath, "r", encoding="latin-1") as f:
        content = f.read()

    # Remove comments
    content = re.sub(r"--.*$", "", content, flags=re.MULTILINE)

    # definitions (entity or package)
    # ignore 'package body'
    # case insensitive
    lower_content = content.lower()

    # Entity definitions
    # entity <name> is
    for match in re.finditer(r"^\s*entity\s+(\w+)\s+is", lower_content, re.MULTILINE):
        defines.add(match.group(1))

    # Package definitions (not body)
    # package <name> is
    for match in re.finditer(r"^\s*package\s+(?!body)(\w+)\s+is", lower_content, re.MULTILINE):
        defines.add(match.group(1))

    # Dependencies
    # entity work.<name>
    for match in re.finditer(r"entity\s+work\.(\w+)", lower_content):
        requires.add(match.group(1))

    # use work.<name>
    for match in re.finditer(r"use\s+work\.(\w+)", lower_content):
        requires.add(match.group(1))

    return defines, requires


def topological_sort_vhdl(file_list):
    """Sorts VHDL files based on dependencies."""
    # Build graph
    file_info = {}  # path -> (defines_set, requires_set)
    unit_to_file = {}  # unit_name -> path

    for f in file_list:
        defs, reqs = parse_vhdl_file(f)
        file_info[f] = (defs, reqs)
        for d in defs:
            unit_to_file[d] = f

    # Filter requires: only keep those that are in this set of files
    graph = {}  # path -> set of paths it depends on
    for f in file_list:
        defs, reqs = file_info[f]
        graph[f] = set()
        for r in reqs:
            if r in unit_to_file:
                # Depend on the file that defines r
                # Self-dependency ignored
                provider = unit_to_file[r]
                if provider != f:
                    graph[f].add(provider)

    # Sort
    # Standard Kahn's algorithm or recursive visit
    visited = set()
    temp_mark = set()
    sorted_list = []

    def visit(n):
        """Recursively visit a dependency node and its children."""
        if n in temp_mark:
            return  # Cycle detected or already processing, ignore
            # raise Exception("Cycle detected")
        if n in visited:
            return

        temp_mark.add(n)
        for m in graph.get(n, []):
            visit(m)
        temp_mark.remove(n)
        visited.add(n)
        sorted_list.append(n)

    # Sort keys for deterministic output on independent nodes
    for f in sorted(file_list):
        visit(f)

    return sorted_list
