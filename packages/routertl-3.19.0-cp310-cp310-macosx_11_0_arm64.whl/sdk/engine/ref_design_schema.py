# SPDX-FileCopyrightText: 2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Reference Design manifest schema (ref_design.yml).

Third register in the 3-register architecture (IPs, Rules, Reference Designs).
A reference design = a complete buildable FPGA project targeting a specific
board, using specific IPs (resolved through the IP registry), producing a
specific bitstream.

Schema lives here so the validator can be reused by:
- `rr ref` CLI (install, info, publish, diff)
- registry submit endpoint (publish-time validation)
- rigtichweb API layer (rendering detail pages)

RTL-P2.334 / P2.336 (manifest design).
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

_log = logging.getLogger(__name__)

_BOARDS_FILE = Path(__file__).parent / "boards.yml"

# Allowed values for enumerated fields — validated strictly at load time.
_VERIFICATION_STATUSES = {"claimed", "sandbox-verified", "community-verified"}
_LANGUAGES = {"vhdl", "vhdl-2008", "systemverilog", "verilog", "mixed"}

# Slug pattern for org/name/version — lowercase alphanumerics + dash + dot.
_SLUG_RE = re.compile(r"^[a-z0-9]([a-z0-9_\-.]*[a-z0-9])?$", re.IGNORECASE)
_VERSION_RE = re.compile(r"^\d+\.\d+\.\d+(?:-[a-z0-9.-]+)?$", re.IGNORECASE)


# ── Data model ───────────────────────────────────────────────────────────────


@dataclass
class RefDesignTarget:
    """Target board + toolchain binding. Exact values only, no ranges."""

    board: str = ""          # canonical ID from boards.yml (e.g. "zybo-z7-20")
    vendor: str = ""         # "xilinx", "altera", "microchip", "lattice"
    family: str = ""         # e.g. "zynq-7000", "arria-10"
    part: str = ""           # exact part number (e.g. "xc7z020clg400-1")
    tool: str = ""           # "Vivado", "Quartus"
    tool_version: str = ""   # exact, e.g. "2024.1". Range syntax forbidden.


@dataclass
class RefDesignProject:
    top_module: str = ""
    language: str = ""       # see _LANGUAGES


@dataclass
class IpRef:
    """A pinned IP dependency from a ref design's uses: block."""

    ref: str                 # "namespace/name"
    version: str             # semver constraint (e.g. "^1.2.0") or exact


@dataclass
class RefDesignSource:
    """Pointer to the source repo holding the ref design's files."""

    repo: str = ""           # git URL
    commit: str = ""         # pinned commit SHA


@dataclass
class RefDesignBuild:
    command: str = ""        # shell command from project root
    expected_bitstream: str = ""  # path relative to project root
    estimated_time_minutes: int = 0


@dataclass
class RefDesignResources:
    """Resource utilization from last successful build. Optional."""

    luts: int = 0
    ffs: int = 0
    bram_kbits: int = 0
    fmax_mhz: float = 0.0


@dataclass
class RefDesignVerification:
    last_verified_commit: str = ""
    last_verified_tool_version: str = ""
    last_verified_date: str = ""   # ISO date string (YYYY-MM-DD)
    status: str = "claimed"         # see _VERIFICATION_STATUSES


@dataclass
class RefDesign:
    """Full reference design manifest.

    Required: org, name, version, description, target.board, target.vendor,
    target.part, target.tool, target.tool_version, project.top_module,
    project.language. Everything else is optional or has safe defaults.
    """

    org: str = ""
    name: str = ""
    version: str = ""
    description: str = ""
    license: str = ""

    target: RefDesignTarget = field(default_factory=RefDesignTarget)
    project: RefDesignProject = field(default_factory=RefDesignProject)
    uses: list[IpRef] = field(default_factory=list)
    source: RefDesignSource = field(default_factory=RefDesignSource)
    build: RefDesignBuild = field(default_factory=RefDesignBuild)
    resources: RefDesignResources = field(default_factory=RefDesignResources)
    verification: RefDesignVerification = field(default_factory=RefDesignVerification)

    tags: list[str] = field(default_factory=list)


# ── YAML parsing ─────────────────────────────────────────────────────────────


def _str(value: Any, default: str = "") -> str:
    if value is None:
        return default
    return str(value)


def _int(value: Any, default: int = 0) -> int:
    try:
        return int(value) if value is not None else default
    except (TypeError, ValueError):
        return default


def _float(value: Any, default: float = 0.0) -> float:
    try:
        return float(value) if value is not None else default
    except (TypeError, ValueError):
        return default


def _list_str(value: Any) -> list[str]:
    if value is None:
        return []
    if isinstance(value, str):
        return [value]
    if isinstance(value, list):
        return [str(v) for v in value if v is not None]
    return []


def _parse_ip_ref(entry: Any) -> IpRef | None:
    """Parse a single `uses:` entry. Each must be {ref: ..., version: ...}."""
    if not isinstance(entry, dict):
        return None
    ref = _str(entry.get("ref"))
    version = _str(entry.get("version"))
    if not ref or not version:
        return None
    return IpRef(ref=ref, version=version)


def parse_manifest(data: dict) -> RefDesign:
    """Parse a loaded YAML document into a RefDesign object.

    Does not validate — use validate_manifest() to collect errors after
    parsing. This two-step split lets partial manifests still round-trip.
    """
    rd_block = data.get("ref_design") or {}
    target_block = data.get("target") or {}
    project_block = data.get("project") or {}
    source_block = data.get("source") or {}
    build_block = data.get("build") or {}
    resources_block = data.get("resources") or {}
    verification_block = data.get("verification") or {}

    return RefDesign(
        org=_str(rd_block.get("org")),
        name=_str(rd_block.get("name")),
        version=_str(rd_block.get("version")),
        description=_str(rd_block.get("description")),
        license=_str(rd_block.get("license")),
        target=RefDesignTarget(
            board=_str(target_block.get("board")),
            vendor=_str(target_block.get("vendor")),
            family=_str(target_block.get("family")),
            part=_str(target_block.get("part")),
            tool=_str(target_block.get("tool")),
            tool_version=_str(target_block.get("tool_version")),
        ),
        project=RefDesignProject(
            top_module=_str(project_block.get("top_module")),
            language=_str(project_block.get("language")),
        ),
        uses=[r for r in (_parse_ip_ref(e) for e in (data.get("uses") or [])) if r],
        source=RefDesignSource(
            repo=_str(source_block.get("repo")),
            commit=_str(source_block.get("commit")),
        ),
        build=RefDesignBuild(
            command=_str(build_block.get("command")),
            expected_bitstream=_str(build_block.get("expected_bitstream")),
            estimated_time_minutes=_int(build_block.get("estimated_time_minutes")),
        ),
        resources=RefDesignResources(
            luts=_int(resources_block.get("luts")),
            ffs=_int(resources_block.get("ffs")),
            bram_kbits=_int(resources_block.get("bram_kbits")),
            fmax_mhz=_float(resources_block.get("fmax_mhz")),
        ),
        verification=RefDesignVerification(
            last_verified_commit=_str(verification_block.get("last_verified_commit")),
            last_verified_tool_version=_str(verification_block.get("last_verified_tool_version")),
            last_verified_date=_str(verification_block.get("last_verified_date")),
            status=_str(verification_block.get("status"), "claimed"),
        ),
        tags=_list_str(rd_block.get("tags")),
    )


def load_manifest(path: Path | str) -> RefDesign:
    """Load a ref_design.yml file into a RefDesign object."""
    p = Path(path)
    with open(p) as f:
        data = yaml.safe_load(f) or {}
    return parse_manifest(data)


def dump_manifest(rd: RefDesign, path: Path | str | None = None) -> str:
    """Serialize a RefDesign to YAML. Returns the YAML string; also writes
    to `path` when provided.
    """
    data: dict[str, Any] = {
        "ref_design": {
            "org": rd.org,
            "name": rd.name,
            "version": rd.version,
            "description": rd.description,
            "license": rd.license,
            "tags": list(rd.tags),
        },
        "target": {
            "board": rd.target.board,
            "vendor": rd.target.vendor,
            "family": rd.target.family,
            "part": rd.target.part,
            "tool": rd.target.tool,
            "tool_version": rd.target.tool_version,
        },
        "project": {
            "top_module": rd.project.top_module,
            "language": rd.project.language,
        },
        "uses": [{"ref": u.ref, "version": u.version} for u in rd.uses],
        "source": {
            "repo": rd.source.repo,
            "commit": rd.source.commit,
        },
        "build": {
            "command": rd.build.command,
            "expected_bitstream": rd.build.expected_bitstream,
            "estimated_time_minutes": rd.build.estimated_time_minutes,
        },
        "resources": {
            "luts": rd.resources.luts,
            "ffs": rd.resources.ffs,
            "bram_kbits": rd.resources.bram_kbits,
            "fmax_mhz": rd.resources.fmax_mhz,
        },
        "verification": {
            "last_verified_commit": rd.verification.last_verified_commit,
            "last_verified_tool_version": rd.verification.last_verified_tool_version,
            "last_verified_date": rd.verification.last_verified_date,
            "status": rd.verification.status,
        },
    }
    text = yaml.safe_dump(data, default_flow_style=False, sort_keys=False,
                          allow_unicode=True)
    if path is not None:
        Path(path).write_text(text)
    return text


# ── Validation ───────────────────────────────────────────────────────────────


def _is_version_range(v: str) -> bool:
    """True if a tool_version string contains range operators (>=, <=, etc)."""
    return any(op in v for op in (">=", "<=", ">", "<", ","))


def validate_manifest(
    rd: RefDesign,
    *,
    known_boards: set[str] | None = None,
) -> list[str]:
    """Return a list of validation error messages. Empty = valid.

    Fail-hard on missing required fields or enum violations. Warn (via log)
    on soft issues like unknown boards or range tool_version.
    """
    errors: list[str] = []

    # Identity
    if not rd.org:
        errors.append("ref_design.org is required")
    elif not _SLUG_RE.match(rd.org):
        errors.append(f"ref_design.org '{rd.org}' must be a slug [a-z0-9_-.]")
    if not rd.name:
        errors.append("ref_design.name is required")
    elif not _SLUG_RE.match(rd.name):
        errors.append(f"ref_design.name '{rd.name}' must be a slug [a-z0-9_-.]")
    if not rd.version:
        errors.append("ref_design.version is required")
    elif not _VERSION_RE.match(rd.version):
        errors.append(f"ref_design.version '{rd.version}' must be semver (e.g. 1.0.0)")
    if not rd.description:
        errors.append("ref_design.description is required")

    # Target
    if not rd.target.board:
        errors.append("target.board is required")
    if not rd.target.vendor:
        errors.append("target.vendor is required")
    if not rd.target.part:
        errors.append("target.part is required")
    if not rd.target.tool:
        errors.append("target.tool is required")
    if not rd.target.tool_version:
        errors.append("target.tool_version is required")
    elif _is_version_range(rd.target.tool_version):
        errors.append(
            f"target.tool_version '{rd.target.tool_version}' must be exact "
            "(no >=, <=, >, <, or commas). P2.333 convention: reference designs "
            "pin the exact tool version they were validated against."
        )

    # Project
    if not rd.project.top_module:
        errors.append("project.top_module is required")
    if not rd.project.language:
        errors.append("project.language is required")
    elif rd.project.language.lower() not in _LANGUAGES:
        errors.append(
            f"project.language '{rd.project.language}' must be one of "
            f"{sorted(_LANGUAGES)}"
        )

    # Enums
    if rd.verification.status not in _VERIFICATION_STATUSES:
        errors.append(
            f"verification.status '{rd.verification.status}' must be one of "
            f"{sorted(_VERIFICATION_STATUSES)}"
        )

    # uses: entries must be well-formed (parse_manifest drops malformed ones
    # silently; surface that here as count check)
    # Per-entry validation — ref must look like "ns/name"
    for u in rd.uses:
        if "/" not in u.ref:
            errors.append(
                f"uses: entry '{u.ref}' must be 'namespace/name' format"
            )

    # Board is soft-validated — warn but don't error (new boards get added
    # faster than we can merge boards.yml PRs).
    if known_boards is not None and rd.target.board and rd.target.board not in known_boards:
        _log.warning(
            "Reference design %s/%s uses board '%s' which is not in boards.yml. "
            "Add it to sdk/engine/boards.yml when convenient.",
            rd.org, rd.name, rd.target.board,
        )

    return errors


# ── boards.yml loader ────────────────────────────────────────────────────────


def load_known_boards() -> set[str]:
    """Load the canonical board ID list from boards.yml. Returns a set of
    slugs. Returns an empty set if the file is missing — callers skip the
    soft-validation check in that case.
    """
    if not _BOARDS_FILE.exists():
        return set()
    try:
        with open(_BOARDS_FILE) as f:
            data = yaml.safe_load(f) or {}
    except (yaml.YAMLError, OSError) as exc:
        _log.warning("Failed to load boards.yml: %s", exc)
        return set()
    boards = data.get("boards", []) or []
    return {
        _str(b.get("id"))
        for b in boards
        if isinstance(b, dict) and b.get("id")
    }
