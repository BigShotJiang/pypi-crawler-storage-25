# SPDX-FileCopyrightText: 2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Shared utilities for .routertl_cache/libraries.json.

Extracted from package_resolver.py and project_manager.py (RTL-P3.97)
to ensure a single, consistent merge-and-deduplicate implementation.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path

_log = logging.getLogger(__name__)

CACHE_REL = Path(".routertl_cache") / "libraries.json"


def read_libraries_cache(cache_file: Path) -> dict[str, list[str]]:
    """Read an existing libraries.json, returning ``{}`` on missing/corrupt."""
    if not cache_file.exists():
        return {}
    try:
        return json.loads(cache_file.read_text())
    except (json.JSONDecodeError, OSError):
        _log.debug("Library cache read failed for %s", cache_file, exc_info=True)
        return {}


def merge_library_entries(
    existing: dict[str, list[str]],
    new_libs: dict[str, list[str]],
) -> dict[str, list[str]]:
    """Merge *new_libs* into *existing* with per-file deduplication.

    Mutates and returns *existing* for convenience.  Scalar values in
    *new_libs* are normalised to single-element lists.
    """
    for lib, files in new_libs.items():
        if not isinstance(files, list):
            files = [files]
        if lib in existing:
            for fp in files:
                if fp not in existing[lib]:
                    existing[lib].append(fp)
        else:
            existing[lib] = list(files)
    return existing


def write_libraries_cache(
    lib_files: dict[str, list[str]],
    project_root: Path,
) -> None:
    """Persist library-to-files mapping to .routertl_cache/libraries.json.

    Merges with any existing entries (e.g. from project_manager or manual
    ``sources.libraries``).  Package-resolver paths are converted to
    project-relative for portability.
    """
    cache_dir = project_root / ".routertl_cache"
    cache_dir.mkdir(parents=True, exist_ok=True)
    cache_file = cache_dir / "libraries.json"

    existing = read_libraries_cache(cache_file)

    # Convert absolute paths to project-relative before merging.
    rel_libs: dict[str, list[str]] = {}
    for lib, files in lib_files.items():
        rel_files = []
        for f in files:
            try:
                rel_files.append(str(Path(f).relative_to(project_root)))
            except ValueError:
                rel_files.append(f)
        rel_libs[lib] = rel_files

    merge_library_entries(existing, rel_libs)

    cache_file.write_text(json.dumps(existing, indent=4) + "\n")
    _log.info("Written libraries.json (%d libraries)", len(existing))
