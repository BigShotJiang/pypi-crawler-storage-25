# SPDX-FileCopyrightText: 2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Parse QSYS/Platform Designer XML output for IP property checking.

Scans qsys-generate output XML files to extract interface properties,
module parameters, and connection topology for rule evaluation.

RTL-P1.27

Usage::

    from sdk.engine.qsys_scanner import scan_qsys_dir, QsysInterface
    interfaces = scan_qsys_dir(Path("src/ip/my_subsystem"))
"""

from __future__ import annotations

import logging
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field
from pathlib import Path

_log = logging.getLogger(__name__)


@dataclass
class QsysInterface:
    """An Avalon/AXI/Streaming interface found in a QSYS component."""

    component: str  # Parent component name
    name: str  # Interface name
    kind: str  # "avalon", "avalon_streaming", "axi", "conduit", "clock", "reset"
    role: str  # "master", "slave", "source", "sink"
    properties: dict[str, str] = field(default_factory=dict)
    file_path: str = ""  # Source file this was found in


@dataclass
class QsysComponent:
    """A component/module in a QSYS subsystem."""

    name: str
    kind: str  # Component type (e.g., "altera_avalon_mm_bridge")
    parameters: dict[str, str] = field(default_factory=dict)
    interfaces: list[QsysInterface] = field(default_factory=list)
    file_path: str = ""


@dataclass
class QsysScanResult:
    """Result of scanning a QSYS project directory."""

    components: list[QsysComponent] = field(default_factory=list)
    interfaces: list[QsysInterface] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    @property
    def avalon_masters(self) -> list[QsysInterface]:
        return [i for i in self.interfaces
                if i.kind == "avalon" and i.role == "master"]

    @property
    def avalon_slaves(self) -> list[QsysInterface]:
        return [i for i in self.interfaces
                if i.kind == "avalon" and i.role == "slave"]


# ── XML parsing ──────────────────────────────────────────────────────────────


def _parse_qsys_xml(path: Path) -> list[QsysComponent]:
    """Parse a .qsys XML file and extract components + interfaces."""
    components = []
    try:
        tree = ET.parse(path)
        root = tree.getroot()
    except (ET.ParseError, OSError) as exc:
        _log.debug("Failed to parse %s: %s", path, exc)
        return []

    # QSYS XML has <module> elements containing <interface> and <parameter>
    for module in root.iter("module"):
        comp = QsysComponent(
            name=module.get("name", ""),
            kind=module.get("kind", ""),
            file_path=str(path),
        )

        for param in module.iter("parameter"):
            pname = param.get("name", "")
            pval = param.get("value", param.text or "")
            if pname:
                comp.parameters[pname] = pval

        for iface in module.iter("interface"):
            qi = QsysInterface(
                component=comp.name,
                name=iface.get("name", ""),
                kind=iface.get("kind", "").replace("_", "").lower(),
                role=iface.get("role", "").lower(),
                file_path=str(path),
            )
            # Normalise kind
            if "avalon" in qi.kind and "stream" not in qi.kind:
                qi.kind = "avalon"
            elif "stream" in qi.kind:
                qi.kind = "avalon_streaming"
            elif "axi" in qi.kind:
                qi.kind = "axi"

            # Collect interface-level parameters
            for iparam in iface.iter("parameter"):
                ipname = iparam.get("name", "")
                ipval = iparam.get("value", iparam.text or "")
                if ipname:
                    qi.properties[ipname] = ipval

            comp.interfaces.append(qi)

        components.append(comp)

    # Also handle _hw.tcl style files (Platform Designer IP)
    # These use a different structure with add_interface / set_interface_property
    if not components:
        components = _parse_hw_tcl_xml(root, path)

    return components


def _parse_hw_tcl_xml(root: ET.Element, path: Path) -> list[QsysComponent]:
    """Parse _hw.tcl XML export format (alternative Platform Designer output)."""
    components = []

    # Some XML exports have <spirit:component> or <component> elements
    for comp_el in list(root.iter("component")) + list(root.iter("module")):
        comp = QsysComponent(
            name=comp_el.get("name", comp_el.get("kind", path.stem)),
            kind=comp_el.get("kind", ""),
            file_path=str(path),
        )

        # Collect all parameter-like elements
        for param in comp_el.iter("parameter"):
            pname = param.get("name", "")
            pval = param.get("value", param.text or "")
            if pname:
                comp.parameters[pname] = pval

        for prop in comp_el.iter("property"):
            pname = prop.get("name", "")
            pval = prop.get("value", prop.text or "")
            if pname:
                comp.parameters[pname] = pval

        if comp.name:
            components.append(comp)

    return components


# ── Directory scanning ───────────────────────────────────────────────────────


def scan_qsys_dir(search_dir: Path) -> QsysScanResult:
    """Recursively scan a directory for QSYS/Platform Designer XML files.

    Looks for ``.qsys``, ``*_hw.tcl``, and ``*.xml`` files that contain
    component/interface definitions.
    """
    result = QsysScanResult()

    if not search_dir.is_dir():
        result.warnings.append(f"Directory not found: {search_dir}")
        return result

    # Scan for QSYS and related XML files
    patterns = ["**/*.qsys", "**/*_hw.tcl", "**/*.xml"]
    found_files: set[Path] = set()
    for pat in patterns:
        for f in search_dir.rglob(pat.split("/")[-1] if "/" not in pat else pat):
            # Skip obviously non-QSYS XML files
            if f.suffix == ".xml" and f.name in (
                "component.xml", "ip.xml", "catalog.xml",
            ):
                continue
            found_files.add(f)

    for fpath in sorted(found_files):
        try:
            components = _parse_qsys_xml(fpath)
            for comp in components:
                result.components.append(comp)
                result.interfaces.extend(comp.interfaces)
        except (ET.ParseError, ValueError, OSError) as exc:
            result.warnings.append(f"Failed to parse {fpath}: {exc}")

    _log.info(
        "Scanned %s: %d components, %d interfaces",
        search_dir, len(result.components), len(result.interfaces),
    )
    return result


def scan_project_qsys(project_root: Path) -> QsysScanResult:
    """Scan common QSYS locations in a routertl project."""
    combined = QsysScanResult()

    for subdir in ["src/ip", "ip", "hw/ip", "qsys"]:
        search = project_root / subdir
        if search.is_dir():
            partial = scan_qsys_dir(search)
            combined.components.extend(partial.components)
            combined.interfaces.extend(partial.interfaces)
            combined.warnings.extend(partial.warnings)

    return combined
