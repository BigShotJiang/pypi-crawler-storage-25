# SPDX-FileCopyrightText: 2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Reference Design index client — fetch catalog + manifests.

Mirrors sdk.engine.index_client (IP index) but targets the separate
routertl-ref-index repo. Uses the same caching semantics and fallback
paths (registry.routertl.dev first, raw GitHub as backup).

RTL-P2.338
"""

from __future__ import annotations

import json
import logging
import os
import time
import urllib.error
import urllib.request
from pathlib import Path

import yaml

_log = logging.getLogger("engine.ref_index_client")

DEFAULT_INDEX_URL = "https://registry.routertl.dev"
_GITHUB_FALLBACK_URL = (
    "https://raw.githubusercontent.com/djmazure/routertl-ref-index/main"
)
_CACHE_TTL_SECONDS = 60 * 60 * 4    # 4 hours
_FETCH_TIMEOUT = 10                  # seconds


def get_ref_index_url(config: dict | None = None) -> str:
    """Resolve ref-index URL: env override > project.yml > default."""
    env = os.environ.get("ROUTERTL_REF_INDEX")
    if env:
        return env.rstrip("/")
    if config:
        url = config.get("ref_designs_index")
        if url:
            return url.rstrip("/")
    return DEFAULT_INDEX_URL


def fetch_ref_catalog(
    index_url: str,
    cache_dir: Path,
    *,
    force_refresh: bool = False,
) -> list[dict]:
    """Download and cache the ref-design catalog.json.

    Returns [] when the registry is empty (legitimate) or on fetch
    failure with no cache available (degraded but doesn't break CLI
    startup).
    """
    cache_dir.mkdir(parents=True, exist_ok=True)
    catalog_cache = cache_dir / "ref_catalog.json"

    if not force_refresh and _cache_is_fresh(catalog_cache):
        _log.debug("ref catalog cache hit")
        return json.loads(catalog_cache.read_text())

    # Try registry first (served at /ref-designs/catalog.json when phase 2+
    # ships the API route), then GitHub raw as fallback.
    urls = [
        f"{index_url}/ref-designs/catalog.json",
        f"{_GITHUB_FALLBACK_URL}/catalog.json",
    ]

    for url in urls:
        try:
            data = _http_get(url)
            catalog_cache.write_text(data)
            _touch(catalog_cache)
            return json.loads(data)
        except (urllib.error.URLError, OSError) as exc:
            _log.debug("Ref catalog fetch failed for %s: %s", url, exc)
            continue

    if catalog_cache.exists():
        _log.warning("Could not refresh ref catalog; using cached copy.")
        return json.loads(catalog_cache.read_text())

    _log.warning("No ref catalog available (empty register is fine).")
    return []


def fetch_ref_manifest(
    org: str,
    name: str,
    version: str,
    index_url: str,
    cache_dir: Path,
) -> dict:
    """Fetch a specific reference design manifest YAML.

    Returns the parsed dict for
    ref-designs/<org>/<name>/<version>.yml. Raises RuntimeError if
    nothing can be found and no cached copy exists.
    """
    cache_dir.mkdir(parents=True, exist_ok=True)
    manifest_cache = cache_dir / "ref_manifests" / org / name / f"{version}.yml"

    if _cache_is_fresh(manifest_cache):
        return yaml.safe_load(manifest_cache.read_text()) or {}

    relpath = f"ref-designs/{org}/{name}/{version}.yml"
    urls = [
        f"{index_url}/{relpath}",
        f"{_GITHUB_FALLBACK_URL}/{relpath}",
    ]

    for url in urls:
        try:
            data = _http_get(url)
            manifest_cache.parent.mkdir(parents=True, exist_ok=True)
            manifest_cache.write_text(data)
            _touch(manifest_cache)
            return yaml.safe_load(data) or {}
        except (urllib.error.URLError, OSError) as exc:
            _log.debug("Manifest fetch failed for %s: %s", url, exc)

    if manifest_cache.exists():
        return yaml.safe_load(manifest_cache.read_text()) or {}

    raise RuntimeError(
        f"Reference design {org}/{name}@{version} not found in ref-index."
    )


# ── Internal helpers ────────────────────────────────────────────────────────


def _http_get(url: str) -> str:
    """GET a URL and return the body as text. Raises on non-200."""
    req = urllib.request.Request(url, headers={"User-Agent": "routertl-ref-client/1.0"})
    with urllib.request.urlopen(req, timeout=_FETCH_TIMEOUT) as resp:
        if resp.status >= 400:
            raise urllib.error.URLError(f"HTTP {resp.status} for {url}")
        return resp.read().decode()


def _cache_is_fresh(path: Path) -> bool:
    if not path.exists():
        return False
    age = time.time() - path.stat().st_mtime
    return age < _CACHE_TTL_SECONDS


def _touch(path: Path) -> None:
    """Update mtime to now."""
    if path.exists():
        path.touch()
