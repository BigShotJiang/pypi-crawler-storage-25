-- SPDX-FileCopyrightText: 2026 Daniel J. Mazure
-- SPDX-License-Identifier: MIT
--
-- FIXTURE — sdi_bypass_correct_split_rx.
--
-- Minimal 1-slave / 2-master AXIS demux — the CORRECT RX-side shape the
-- original sdi_axis_bypass_switch was supposed to implement.  Paired with
-- sdi_bypass_correct_split_rx.requirements.yml; contract-check must pass.
library IEEE;
use IEEE.std_logic_1164.all;

entity sdi_bypass_correct_split_rx is
    generic (
        C_AXIS_TDATA_WIDTH : positive := 64
    );
    port (
        s_axis_rx_tdata    : in  std_logic_vector(C_AXIS_TDATA_WIDTH-1 downto 0);
        s_axis_rx_tvalid   : in  std_logic;
        s_axis_rx_tready   : out std_logic;

        m_axis_rx_to_vdma_tdata  : out std_logic_vector(C_AXIS_TDATA_WIDTH-1 downto 0);
        m_axis_rx_to_vdma_tvalid : out std_logic;
        m_axis_rx_to_vdma_tready : in  std_logic;

        m_axis_rx_to_pass_tdata  : out std_logic_vector(C_AXIS_TDATA_WIDTH-1 downto 0);
        m_axis_rx_to_pass_tvalid : out std_logic;
        m_axis_rx_to_pass_tready : in  std_logic;

        sel            : in std_logic;
        video_aclk     : in std_logic;
        video_aresetn  : in std_logic
    );
end entity sdi_bypass_correct_split_rx;
