-- SPDX-FileCopyrightText: 2026 Daniel J. Mazure
-- SPDX-License-Identifier: MIT
--
-- ═══════════════════════════════════════════════════════════════════════════
-- REGRESSION FIXTURE — sdi_axis_bypass_switch (WRONG SHAPE).
--
-- Reduced entity block frozen from the real SDI IP on 2026-04-21.  The
-- design intent was a 1-slave / 2-master demux plus a 2-slave / 1-master
-- mux (i.e. two separate bundles).  The author instead shipped a fused
-- 3-slave / 3-master switch — which contract-check MUST flag.
--
-- Locks in RTL-P2.398 bug signature.  Architecture stripped; ports only.
-- ═══════════════════════════════════════════════════════════════════════════
library IEEE;
use IEEE.std_logic_1164.all;

entity sdi_axis_bypass_switch is
    generic (
        C_AXIS_TDATA_WIDTH : positive := 64;
        C_AXIS_TUSER_WIDTH : positive := 1
    );
    port (
        -- ═══ RX side (broken 3-slave / 3-master fused shape) ═══
        s_axis_rx_tdata    : in  std_logic_vector(C_AXIS_TDATA_WIDTH-1 downto 0);
        s_axis_rx_tvalid   : in  std_logic;
        s_axis_rx_tready   : out std_logic;

        m_axis_rx_to_vdma_tdata  : out std_logic_vector(C_AXIS_TDATA_WIDTH-1 downto 0);
        m_axis_rx_to_vdma_tvalid : out std_logic;
        m_axis_rx_to_vdma_tready : in  std_logic;

        m_axis_rx_to_pass_tdata  : out std_logic_vector(C_AXIS_TDATA_WIDTH-1 downto 0);
        m_axis_rx_to_pass_tvalid : out std_logic;
        m_axis_rx_to_pass_tready : in  std_logic;

        -- ═══ TX side ═══
        s_axis_tx_from_vdma_tdata  : in  std_logic_vector(C_AXIS_TDATA_WIDTH-1 downto 0);
        s_axis_tx_from_vdma_tvalid : in  std_logic;
        s_axis_tx_from_vdma_tready : out std_logic;

        s_axis_tx_from_pass_tdata  : in  std_logic_vector(C_AXIS_TDATA_WIDTH-1 downto 0);
        s_axis_tx_from_pass_tvalid : in  std_logic;
        s_axis_tx_from_pass_tready : out std_logic;

        m_axis_tx_tdata  : out std_logic_vector(C_AXIS_TDATA_WIDTH-1 downto 0);
        m_axis_tx_tvalid : out std_logic;
        m_axis_tx_tready : in  std_logic;

        sel            : in std_logic;
        video_aclk     : in std_logic;
        video_aresetn  : in std_logic
    );
end entity sdi_axis_bypass_switch;
