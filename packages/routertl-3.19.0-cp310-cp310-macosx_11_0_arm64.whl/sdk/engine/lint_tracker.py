# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
Lint Result Tracker for RouteRTL SDK.

Persists lint PASS/WARN/FAIL results to ``.routertl_cache/lint_results.json``
and provides staleness detection by comparing result timestamps against
source file modification times.
"""

import json
import os
from dataclasses import asdict, dataclass
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional


@dataclass
class LintResult:
    """A single lint run result."""

    module: str
    status: str  # "PASS", "WARN", or "FAIL"
    timestamp: str  # ISO-8601 UTC


# Cache file schema version — bump when the format changes
_CACHE_VERSION = 1


class LintTracker:
    """Load, query, and persist lint results.

    Results are stored in ``<project_root>/.routertl_cache/lint_results.json``.
    Each module has at most one entry (latest run wins).
    """

    def __init__(self, project_root: Optional[str] = None):
        """Create a tracker rooted at *project_root* (defaults to cwd)."""
        root = Path(project_root) if project_root else Path.cwd()
        self._cache_dir = root / ".routertl_cache"
        self._cache_file = self._cache_dir / "lint_results.json"
        self._results: Dict[str, LintResult] = {}
        self._load()

    # ── Persistence ──────────────────────────────────────────────

    def _load(self) -> None:
        """Load results from disk, tolerating missing/corrupt files."""
        if not self._cache_file.exists():
            return
        try:
            with open(self._cache_file, "r") as f:
                data = json.load(f)
            if data.get("version", 0) != _CACHE_VERSION:
                return
            for name, entry in data.get("results", {}).items():
                self._results[name] = LintResult(
                    module=entry.get("module", name),
                    status=entry.get("status", "FAIL"),
                    timestamp=entry.get("timestamp", ""),
                )
        except (json.JSONDecodeError, KeyError, TypeError):
            self._results = {}

    def save(self) -> None:
        """Write current results to disk."""
        self._cache_dir.mkdir(parents=True, exist_ok=True)
        payload = {
            "version": _CACHE_VERSION,
            "results": {name: asdict(r) for name, r in self._results.items()},
        }
        with open(self._cache_file, "w") as f:
            json.dump(payload, f, indent=2)

    # ── Queries ──────────────────────────────────────────────────

    def record(self, result: LintResult) -> None:
        """Upsert a lint result (by module name) and save."""
        self._results[result.module] = result
        self.save()

    def get(self, module: str) -> Optional[LintResult]:
        """Return the cached result for *module*, or ``None``."""
        return self._results.get(module)

    def all_results(self) -> Dict[str, LintResult]:
        """Return all cached results."""
        return dict(self._results)

    # ── Staleness ────────────────────────────────────────────────

    def staleness_check(self, module: str, src_files: List[str]) -> str:
        """Return the effective status of *module*.

        Returns one of:
            ``"PASS"``    — last lint passed, sources unchanged since.
            ``"WARN"``    — last lint had warnings, sources unchanged since.
            ``"FAIL"``    — last lint failed.
            ``"STALE"``   — last lint passed/warned, but sources modified since.
            ``"UNKNOWN"`` — no cached result for this module.
        """
        result = self.get(module)
        if result is None:
            return "UNKNOWN"
        if result.status == "FAIL":
            return "FAIL"

        # Compare result timestamp against source file mtimes
        try:
            result_ts = datetime.fromisoformat(result.timestamp).timestamp()
        except (ValueError, TypeError):
            return "STALE"

        for src in src_files:
            try:
                if os.path.getmtime(src) > result_ts:
                    return "STALE"
            except OSError:
                continue

        return result.status  # "PASS" or "WARN"
