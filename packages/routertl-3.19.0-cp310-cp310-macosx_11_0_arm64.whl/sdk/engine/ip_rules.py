# SPDX-FileCopyrightText: 2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""IP design rules engine with vendor/tool/version scoping.

Loads rules from built-in defaults and project-local overrides,
filters them against the current toolchain context (from routertl.lock),
and evaluates them against parsed IP/QSYS data.

RTL-P1.28

Usage::

    from sdk.engine.ip_rules import load_rules, filter_rules, RuleMatch
    rules = load_rules(project_root)
    applicable = filter_rules(rules, toolchain_ctx)
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

_log = logging.getLogger(__name__)

_BUILTIN_RULES = Path(__file__).parent / "builtin_rules.yml"


# ── Data model ───────────────────────────────────────────────────────────────


@dataclass
class Rule:
    """A single design rule with scoping and provenance."""

    id: str
    severity: str  # "error", "warning", "info"
    message: str
    incident: str  # The real bug story — required

    # Scoping (empty = matches all)
    vendor: str = ""  # "altera", "xilinx", etc.
    family: list[str] = field(default_factory=list)  # ["cyclone-v", "arria-10"]
    part: list[str] = field(default_factory=list)    # ["10AX115S2F45I1SG"] — exact parts
    tool: str = ""  # "Quartus", "Vivado"
    tool_version: str = ""  # Prefer exact: "23.1" or "23.1,24.1". Ranges
                             # (">=23.1") still accepted for backward compat but
                             # rules_lint flags them as imprecise provenance.
    ip: str = ""  # component name pattern (glob)
    ip_version: list[str] = field(default_factory=list)  # exact IP versions (P2.333)
    property: str = ""  # property to check
    condition: str = ""  # "== 0", "!= true", "missing"

    # Resolution guidance
    fix: str = ""

    # Metadata
    source: str = "built-in"  # "built-in", "local", "remote:<pack>"


@dataclass
class RuleMatch:
    """A rule that matched during evaluation."""

    rule: Rule
    context: str  # Where the match occurred (file path, IP name, etc.)
    actual_value: str = ""  # What the property actually was


# ── Version matching ─────────────────────────────────────────────────────────


def _parse_version(v: str) -> tuple[int, ...]:
    """Parse a version string into a comparable tuple.

    Handles: "24.1", "2024.2", "23.1std", "24.1pro"
    """
    # Strip edition suffixes
    cleaned = re.sub(r"(std|pro|ent|lite)$", "", v.strip().lower())
    parts = re.split(r"[.\-]", cleaned)
    result = []
    for p in parts:
        try:
            result.append(int(p))
        except ValueError:
            break
    return tuple(result) if result else (0,)


def version_matches(current: str, constraint: str) -> bool:
    """Check if *current* version satisfies a semver-like *constraint*.

    Supports: ">=23.1", "<25.1", ">=23.1,<25.1", "==24.1", exact match.
    Empty constraint matches everything.
    """
    if not constraint:
        return True

    cur = _parse_version(current)

    for part in constraint.split(","):
        part = part.strip()
        if part.startswith(">="):
            if cur < _parse_version(part[2:]):
                return False
        elif part.startswith("<="):
            if cur > _parse_version(part[2:]):
                return False
        elif part.startswith(">"):
            if cur <= _parse_version(part[1:]):
                return False
        elif part.startswith("<"):
            if cur >= _parse_version(part[1:]):
                return False
        elif part.startswith("=="):
            if cur != _parse_version(part[2:]):
                return False
        elif part.startswith("!="):
            if cur == _parse_version(part[2:]):
                return False
        else:
            # Exact match
            if cur != _parse_version(part):
                return False

    return True


# ── Rule loading ─────────────────────────────────────────────────────────────


def _coerce_str_list(value: Any) -> list[str]:
    """Accept scalar string or list-of-strings in YAML; normalise to list."""
    if value is None or value == "":
        return []
    if isinstance(value, str):
        return [value]
    if isinstance(value, list):
        return [str(v) for v in value if v is not None and v != ""]
    return []


def _parse_rules(data: list[dict], source: str) -> list[Rule]:
    """Parse a list of rule dicts into Rule objects."""
    rules = []
    for entry in data:
        if not isinstance(entry, dict):
            continue
        rule = Rule(
            id=entry.get("id", ""),
            severity=entry.get("severity", "warning"),
            message=entry.get("message", ""),
            incident=entry.get("incident", ""),
            vendor=entry.get("vendor", ""),
            family=_coerce_str_list(entry.get("family")),
            part=_coerce_str_list(entry.get("part")),
            tool=entry.get("tool", ""),
            tool_version=entry.get("tool_version", ""),
            ip=entry.get("ip", ""),
            ip_version=_coerce_str_list(entry.get("ip_version")),
            property=entry.get("property", ""),
            condition=entry.get("condition", ""),
            fix=entry.get("fix", ""),
            source=source,
        )
        if rule.id and rule.message:
            # Validate ip_version is only meaningful when ip is set
            if rule.ip_version and not rule.ip:
                _log.warning(
                    "Rule %s sets ip_version without ip; scoping is ignored.",
                    rule.id,
                )
            rules.append(rule)
        else:
            _log.warning("Skipping rule with missing id or message: %s", entry)
    return rules


def load_rules(project_root: Path | None = None) -> list[Rule]:
    """Load rules from built-in defaults and project-local overrides.

    Priority: project-local ``ip_rules.yml`` > built-in rules.
    Duplicate IDs from local override the built-in version.
    """
    rules: dict[str, Rule] = {}

    # 1. Built-in rules
    if _BUILTIN_RULES.exists():
        try:
            with open(_BUILTIN_RULES) as f:
                data = yaml.safe_load(f) or {}
            for rule in _parse_rules(data.get("rules", []), "built-in"):
                rules[rule.id] = rule
            _log.debug("Loaded %d built-in rules", len(rules))
        except (yaml.YAMLError, OSError) as exc:
            _log.warning("Failed to load built-in rules: %s", exc)

    # 2. Project-local overrides
    if project_root:
        local_file = Path(project_root) / "ip_rules.yml"
        if local_file.exists():
            try:
                with open(local_file) as f:
                    data = yaml.safe_load(f) or {}
                local_rules = _parse_rules(data.get("rules", []), "local")
                for rule in local_rules:
                    rules[rule.id] = rule  # Override built-in
                _log.debug("Loaded %d local rules from %s", len(local_rules), local_file)
            except (yaml.YAMLError, OSError) as exc:
                _log.warning("Failed to load local rules: %s", exc)

    return list(rules.values())


# ── Rule filtering ───────────────────────────────────────────────────────────


@dataclass
class ToolchainContext:
    """Current project toolchain context (from routertl.lock)."""

    vendor: str = ""
    tool: str = ""
    tool_version: str = ""
    part: str = ""
    family: str = ""


def filter_rules(rules: list[Rule], ctx: ToolchainContext) -> list[Rule]:
    """Filter rules to only those applicable to the current toolchain."""
    applicable = []
    for rule in rules:
        # Vendor filter
        if rule.vendor and rule.vendor.lower() != ctx.vendor.lower():
            continue
        # Tool filter
        if rule.tool and rule.tool.lower() != ctx.tool.lower():
            continue
        # Tool version filter
        if rule.tool_version and ctx.tool_version:
            if not version_matches(ctx.tool_version, rule.tool_version):
                continue
        # Family filter
        if rule.family and ctx.family:
            if ctx.family.lower() not in [f.lower() for f in rule.family]:
                continue
        # Part filter — when a rule scopes to specific part numbers, the
        # current toolchain part must match exactly. Rules with empty
        # `part` match any part within matching family (P2.333).
        if rule.part and ctx.part:
            if ctx.part.upper() not in [p.upper() for p in rule.part]:
                continue
        applicable.append(rule)
    return applicable


# ── Rule evaluation ──────────────────────────────────────────────────────────


def evaluate_condition(actual: Any, condition: str) -> bool:
    """Check if an *actual* value satisfies a rule *condition*.

    Conditions: "== 0", "!= true", "missing", "contains xyz", "empty".
    """
    if not condition:
        return True  # No condition = always matches (informational)

    actual_str = str(actual).strip().lower() if actual is not None else ""

    if condition == "missing":
        return actual is None or actual_str == ""

    if condition == "empty":
        return actual_str == "" or actual_str == "[]" or actual_str == "{}"

    # Comparison operators
    for op, fn in [
        ("==", lambda a, b: a == b),
        ("!=", lambda a, b: a != b),
        (">=", lambda a, b: float(a) >= float(b) if a.replace(".", "").isdigit() else a >= b),
        ("<=", lambda a, b: float(a) <= float(b) if a.replace(".", "").isdigit() else a <= b),
        (">", lambda a, b: float(a) > float(b) if a.replace(".", "").isdigit() else a > b),
        ("<", lambda a, b: float(a) < float(b) if a.replace(".", "").isdigit() else a < b),
    ]:
        if condition.startswith(op):
            expected = condition[len(op):].strip().lower()
            try:
                return fn(actual_str, expected)
            except (ValueError, TypeError):
                return False

    if condition.startswith("contains "):
        needle = condition[9:].strip().lower()
        return needle in actual_str

    return False
