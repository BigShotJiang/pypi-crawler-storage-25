# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""ltsync — Timing anchor collector for RouteWave waveform navigation.

Provides :func:`rr_mark` for cocotb testbenches to annotate simulation time
with named labels.  Collected anchors are written into the ``.ltmeta.json``
sidecar by :func:`~sdk.engine.ltmeta.emit_ltmeta` at teardown, and RouteWave
renders them as clickable links in the integrated console.

Usage in a cocotb test::

    from sdk.engine.ltsync import rr_mark

    @cocotb.test()
    async def test_uart_tx(dut):
        rr_mark("Reset asserted")
        dut.rst_n.value = 0
        await ClockCycles(dut.clk, 10)

        dut.rst_n.value = 1
        rr_mark("Reset released")

        # ... stimulus ...
        rr_mark("First TX byte sent")

After simulation, RouteWave shows::

    ⚓ [Reset asserted]        @ 0 ns          ← click to jump
    ⚓ [Reset released]        @ 50000 ns      ← click to jump
    ⚓ [First TX byte sent]    @ 125000 ns     ← click to jump
"""

from __future__ import annotations

import logging
from typing import Any

_log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Module-level anchor storage
# ---------------------------------------------------------------------------

_anchors: list[dict[str, Any]] = []

#: Maximum number of anchors per test to prevent runaway flooding.
MAX_ANCHORS = 500

#: Threshold at which a warning is emitted.
WARN_THRESHOLD = 100


def rr_mark(label: str, *, dut: Any = None) -> None:
    """Mark the current simulation time with a named anchor.

    Parameters
    ----------
    label:
        Human-readable label for this timing anchor (e.g. ``"Reset released"``).
    dut:
        Optional cocotb DUT handle for logging.  If not provided, the function
        uses the standard ``cocotb.log`` logger.

    The anchor is stored in-process and flushed to the ``.ltmeta.json`` sidecar
    when :func:`~sdk.engine.ltmeta.emit_ltmeta` runs at test teardown.
    """
    if len(_anchors) >= MAX_ANCHORS:
        if len(_anchors) == MAX_ANCHORS:
            _log.warning(
                "rr_mark: anchor limit reached (%d). "
                "Further marks will be silently dropped.",
                MAX_ANCHORS,
            )
        return

    # Resolve simulation time — graceful fallback when cocotb is not running
    time_ns: int = 0
    try:
        import cocotb.utils

        try:
            time_ns = int(cocotb.utils.get_sim_time(unit="ns"))  # cocotb 2.x
        except TypeError:
            time_ns = int(cocotb.utils.get_sim_time(units="ns"))  # cocotb 1.x
    except (ImportError, RuntimeError):
        # Running outside cocotb (e.g. unit test) — time stays 0
        pass

    _anchors.append({"time_ns": time_ns, "label": str(label)})

    if len(_anchors) == WARN_THRESHOLD:
        _log.warning(
            "rr_mark: %d anchors collected — consider reducing granularity.",
            WARN_THRESHOLD,
        )

    # Also log for immediate visibility in the cocotb console
    try:
        log = dut._log if dut is not None else _log
        log.info("⚓ [%s] @ %d ns", label, time_ns)
    except AttributeError:
        _log.info("⚓ [%s] @ %d ns", label, time_ns)


def rr_mark_manual(label: str, time_ns: int) -> None:
    """Add a timing anchor with an explicit timestamp (no cocotb dependency).

    Useful for post-processing scripts or non-cocotb simulation flows that
    know the exact timestamp and want to emit anchors programmatically.

    Parameters
    ----------
    label:
        Human-readable label.
    time_ns:
        Simulation time in nanoseconds.
    """
    if len(_anchors) >= MAX_ANCHORS:
        return
    _anchors.append({"time_ns": int(time_ns), "label": str(label)})


def get_anchors() -> list[dict[str, Any]]:
    """Return a copy of the collected anchors.

    Each entry is ``{"time_ns": int, "label": str}``.
    """
    return list(_anchors)


def clear_anchors() -> None:
    """Reset the anchor collection (call between test runs)."""
    _anchors.clear()
