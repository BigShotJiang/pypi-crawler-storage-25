# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Process Monitor — watch system RAM during long-running EDA tool runs.

Runs a background thread that polls system memory usage while a subprocess
(Vivado, Quartus, etc.) is active.  If total system memory usage exceeds a
configurable threshold, the subprocess tree is killed before the OS OOM
killer can crash the entire machine.

Usage from VendorDispatch::

    from sdk.engine.process_monitor import monitored_run

    result = monitored_run(cmd, env=env, mem_limit_gb=50)
    return result.returncode
"""

from __future__ import annotations

import logging
import os
import signal
import subprocess
import sys
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Defaults
# ---------------------------------------------------------------------------

_DEFAULT_MEM_LIMIT_GB = 40  # kill threshold (system-wide used RAM)
_DEFAULT_POLL_INTERVAL_S = 3  # how often to check
_DEFAULT_LOG_INTERVAL_S = 60  # how often to emit an INFO-level status line
_WARN_THRESHOLD_FRACTION = 0.85  # warn at 85% of the kill limit

# RAM watchdog reads /proc/meminfo and /proc/<pid>/status, which only exist
# on Linux.  The individual readers already catch OSError and return 0.0,
# but the monitor loop short-circuits on non-Linux so it doesn't spin for
# hours with all-zero readings (Mac users running simulation + lint only).
_IS_LINUX = sys.platform.startswith("linux")


def _get_total_ram_gb() -> float:
    """Return total physical RAM in GB (Linux only)."""
    try:
        with open("/proc/meminfo") as f:
            for line in f:
                if line.startswith("MemTotal:"):
                    kb = int(line.split()[1])
                    return kb / (1024 * 1024)
    except OSError:
        pass
    return 0.0


def _get_used_ram_gb() -> float:
    """Return used physical RAM in GB (Linux only).

    Used = MemTotal - MemAvailable (same formula as ``free -h``).
    """
    total_kb = 0
    avail_kb = 0
    try:
        with open("/proc/meminfo") as f:
            for line in f:
                if line.startswith("MemTotal:"):
                    total_kb = int(line.split()[1])
                elif line.startswith("MemAvailable:"):
                    avail_kb = int(line.split()[1])
    except OSError:
        return 0.0
    return (total_kb - avail_kb) / (1024 * 1024)


def _get_available_ram_gb() -> float:
    """Return MemAvailable in GB (Linux only)."""
    try:
        with open("/proc/meminfo") as f:
            for line in f:
                if line.startswith("MemAvailable:"):
                    return int(line.split()[1]) / (1024 * 1024)
    except OSError:
        pass
    return 0.0


def _child_pids(pid: int) -> set[int]:
    """Return the set of direct child PIDs of ``pid``.

    Reads ``/proc/<pid>/task/<tid>/children`` across *all* threads of the
    target process — Vivado spawns worker processes from non-main threads,
    which the single ``/proc/<pid>/task/<pid>/children`` path misses.
    """
    out: set[int] = set()
    task_dir = Path(f"/proc/{pid}/task")
    if not task_dir.exists():
        return out
    try:
        for tdir in task_dir.iterdir():
            ch = tdir / "children"
            if not ch.exists():
                continue
            try:
                out.update(int(x) for x in ch.read_text().split())
            except (OSError, ValueError):
                pass
    except OSError:
        pass
    return out


def _get_process_ram_gb(pid: int) -> float:
    """Return RSS of the full descendant process tree in GB (best-effort).

    Walks the complete descendant tree rooted at ``pid`` (not just
    depth-1 children).  Vivado launches as wrapper → loader →
    ``vivado_real``, so the real worker lives at depth 2+.
    """
    total_kb = 0
    seen: set[int] = set()
    stack: list[int] = [pid]
    while stack:
        p = stack.pop()
        if p in seen:
            continue
        seen.add(p)
        try:
            with open(f"/proc/{p}/status") as f:
                for line in f:
                    if line.startswith("VmRSS:"):
                        total_kb += int(line.split()[1])
                        break
        except OSError:
            continue
        stack.extend(_child_pids(p))
    return total_kb / (1024 * 1024)


def find_concurrent_processes(names: list[str]) -> list[tuple[int, str]]:
    """Return ``[(pid, cmdline), …]`` for running processes matching any of
    ``names`` and owned by the current UID.

    Used by the vendor-dispatch pre-spawn guard to refuse launching a new
    Vivado/Quartus when another one is already running (concurrent EDA
    processes crashed the kernel on 2026-04-19).  Best-effort — Linux only.
    """
    uid = os.getuid() if hasattr(os, "getuid") else -1
    out: list[tuple[int, str]] = []
    proc_root = Path("/proc")
    if not proc_root.exists() or uid < 0:
        return out
    name_set = set(names)
    try:
        for entry in proc_root.iterdir():
            if not entry.name.isdigit():
                continue
            try:
                if entry.stat().st_uid != uid:
                    continue
                comm = (entry / "comm").read_text().strip()
            except (OSError, FileNotFoundError):
                continue
            if comm not in name_set:
                continue
            try:
                cmdline = (
                    (entry / "cmdline").read_text().replace("\x00", " ").strip()
                    or comm
                )
            except OSError:
                cmdline = comm
            out.append((int(entry.name), cmdline))
    except OSError:
        pass
    return out


# ---------------------------------------------------------------------------
# Monitor result
# ---------------------------------------------------------------------------


@dataclass
class MonitorStats:
    """Statistics collected during a monitored run."""

    peak_system_ram_gb: float = 0.0
    peak_process_ram_gb: float = 0.0
    samples: int = 0
    killed: bool = False
    kill_reason: str = ""
    duration_s: float = 0.0
    ram_samples: list[tuple[float, float, float]] = field(default_factory=list)
    """(elapsed_s, system_gb, process_gb) tuples — sampled at log_interval."""


# ---------------------------------------------------------------------------
# The monitor thread
# ---------------------------------------------------------------------------


class ProcessMonitor:
    """Background thread that watches system RAM while a process runs.

    Parameters
    ----------
    proc : subprocess.Popen
        The subprocess to monitor.
    mem_limit_gb : float
        Kill the process when system-wide used RAM exceeds this (GB).
    poll_interval_s : float
        How often to poll /proc/meminfo.
    log_interval_s : float
        How often to emit an INFO-level status line.
    log_file : Path | None
        Optional file to append timestamped RAM readings.
    """

    def __init__(
        self,
        proc: subprocess.Popen,
        mem_limit_gb: float = _DEFAULT_MEM_LIMIT_GB,
        poll_interval_s: float = _DEFAULT_POLL_INTERVAL_S,
        log_interval_s: float = _DEFAULT_LOG_INTERVAL_S,
        log_file: Path | None = None,
    ):
        self.proc = proc
        self.mem_limit_gb = mem_limit_gb
        self.poll_interval_s = poll_interval_s
        self.log_interval_s = log_interval_s
        self.log_file = log_file
        self.stats = MonitorStats()
        self._stop = threading.Event()
        self._thread = threading.Thread(
            target=self._monitor_loop,
            name="eda-ram-monitor",
            daemon=True,
        )

    def start(self):
        self._thread.start()

    def stop(self):
        self._stop.set()
        self._thread.join(timeout=5)

    def _kill_process_tree(self, reason: str):
        """Kill the process and its children."""
        pid = self.proc.pid
        self.stats.killed = True
        self.stats.kill_reason = reason
        logger.warning("KILLING process %d: %s", pid, reason)

        # Try SIGTERM first for graceful shutdown
        try:
            os.killpg(os.getpgid(pid), signal.SIGTERM)
        except (OSError, ProcessLookupError):
            try:
                self.proc.terminate()
            except OSError:
                pass

        # Give it 5 seconds, then SIGKILL
        try:
            self.proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            try:
                os.killpg(os.getpgid(pid), signal.SIGKILL)
            except (OSError, ProcessLookupError):
                try:
                    self.proc.kill()
                except OSError:
                    pass

    def _log_to_file(self, msg: str):
        if self.log_file:
            try:
                with open(self.log_file, "a") as f:
                    f.write(msg + "\n")
            except OSError:
                pass

    def _monitor_loop(self):
        t0 = time.monotonic()
        last_log = 0.0

        if not _IS_LINUX:
            msg = (
                f"[monitor] RAM watchdog disabled on {sys.platform} — "
                f"/proc unavailable. Process will run unmonitored."
            )
            logger.warning(msg)
            self._log_to_file(msg)
            # Wait for the process to finish without polling.
            while not self._stop.is_set():
                if self.proc.poll() is not None:
                    break
                self._stop.wait(self.poll_interval_s)
            self.stats.duration_s = time.monotonic() - t0
            return

        total_ram = _get_total_ram_gb()
        warn_gb = self.mem_limit_gb * _WARN_THRESHOLD_FRACTION

        header = (
            f"[monitor] Total RAM: {total_ram:.1f} GB | "
            f"Kill threshold: {self.mem_limit_gb:.0f} GB | "
            f"Warn at: {warn_gb:.1f} GB"
        )
        logger.info(header)
        self._log_to_file(header)

        while not self._stop.is_set():
            self._stop.wait(self.poll_interval_s)
            if self._stop.is_set():
                break

            elapsed = time.monotonic() - t0
            sys_ram = _get_used_ram_gb()
            proc_ram = _get_process_ram_gb(self.proc.pid)
            self.stats.samples += 1

            # Track peaks
            if sys_ram > self.stats.peak_system_ram_gb:
                self.stats.peak_system_ram_gb = sys_ram
            if proc_ram > self.stats.peak_process_ram_gb:
                self.stats.peak_process_ram_gb = proc_ram

            # Periodic log
            if elapsed - last_log >= self.log_interval_s:
                last_log = elapsed
                pct = (sys_ram / total_ram * 100) if total_ram else 0
                msg = (
                    f"[monitor] {elapsed:6.0f}s | "
                    f"System: {sys_ram:.1f}/{total_ram:.0f} GB ({pct:.0f}%) | "
                    f"Process: {proc_ram:.1f} GB"
                )
                logger.info(msg)
                self._log_to_file(msg)
                self.stats.ram_samples.append((elapsed, sys_ram, proc_ram))

            # Check if process is still alive
            if self.proc.poll() is not None:
                break

            # Warn threshold
            if sys_ram > warn_gb:
                msg = (
                    f"[monitor] ⚠ RAM WARNING: {sys_ram:.1f} GB used "
                    f"(threshold: {self.mem_limit_gb:.0f} GB)"
                )
                logger.warning(msg)
                self._log_to_file(msg)

            # Kill threshold
            if sys_ram > self.mem_limit_gb:
                reason = (
                    f"System RAM {sys_ram:.1f} GB exceeded limit "
                    f"{self.mem_limit_gb:.0f} GB"
                )
                self._log_to_file(f"[monitor] 🛑 {reason}")
                self._kill_process_tree(reason)
                break

        self.stats.duration_s = time.monotonic() - t0


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def monitored_run(
    cmd: list[str],
    *,
    env: dict[str, str] | None = None,
    mem_limit_gb: float = _DEFAULT_MEM_LIMIT_GB,
    poll_interval_s: float = _DEFAULT_POLL_INTERVAL_S,
    log_interval_s: float = _DEFAULT_LOG_INTERVAL_S,
    log_dir: Path | None = None,
) -> tuple[int, MonitorStats]:
    """Run a command with RAM monitoring.

    Returns (returncode, MonitorStats).  If the process was killed due to
    OOM, returncode will be negative (from SIGTERM/SIGKILL) and
    stats.killed will be True.

    Parameters
    ----------
    cmd : list[str]
        Command + args to run.
    env : dict, optional
        Environment for the subprocess.
    mem_limit_gb : float
        Kill when system-wide used RAM exceeds this.
    poll_interval_s : float
        How often to poll /proc/meminfo.
    log_interval_s : float
        How often to emit status lines.
    log_dir : Path, optional
        Directory for the monitor log file.  If None, uses
        ``.routertl_cache/``.
    """
    # Set up log file
    log_file = None
    if log_dir is None:
        log_dir = Path.cwd() / ".routertl_cache"
    try:
        log_dir.mkdir(parents=True, exist_ok=True)
        log_file = log_dir / "process_monitor.log"
    except OSError:
        pass

    # Start the subprocess in its own process group so we can kill the tree
    try:
        proc = subprocess.Popen(
            cmd,
            env=env,
            start_new_session=True,
        )
    except FileNotFoundError:
        # Tool not found — let caller handle like subprocess.run would
        raise

    monitor = ProcessMonitor(
        proc,
        mem_limit_gb=mem_limit_gb,
        poll_interval_s=poll_interval_s,
        log_interval_s=log_interval_s,
        log_file=log_file,
    )
    monitor.start()

    try:
        proc.wait()
    except KeyboardInterrupt:
        # User Ctrl+C — forward to process group
        try:
            os.killpg(os.getpgid(proc.pid), signal.SIGINT)
            proc.wait(timeout=10)
        except (OSError, subprocess.TimeoutExpired):
            proc.kill()
            proc.wait()
    finally:
        monitor.stop()

    stats = monitor.stats

    # Write summary
    summary = (
        f"[monitor] DONE | exit={proc.returncode} | "
        f"peak_sys={stats.peak_system_ram_gb:.1f} GB | "
        f"peak_proc={stats.peak_process_ram_gb:.1f} GB | "
        f"duration={stats.duration_s:.0f}s | "
        f"killed={stats.killed}"
    )
    logger.info(summary)
    if log_file:
        try:
            with open(log_file, "a") as f:
                f.write(summary + "\n")
        except OSError:
            pass

    return proc.returncode, stats
