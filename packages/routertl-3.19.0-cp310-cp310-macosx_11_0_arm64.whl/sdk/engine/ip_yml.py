# SPDX-FileCopyrightText: 2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Canonical ip.yml schema reader and normalizer (RTL-P3.189).

Historically routertl has dealt with two ip.yml shapes:

  * **Registry/publish shape** (flat): identity fields at the root —
    ``name``, ``namespace``, ``version``, ``license``, ``description``,
    ``hdl``, ``dependencies``, ``interfaces``, ``parameters``, ``fpga``.

  * **Vendored/build shape** (wrapped): ``ip: {name, library, language}``
    plus sibling blocks ``paths``, ``synthesis``, ``ips`` at the root.

The two schemas serve different purposes (publish vs in-project build),
so readers specialised and the shapes diverged. D.58 unifies them into
a single canonical shape — **identity at root, optional ``build:`` block
for in-project consumers**:

    name: pulp_axis_stream_mux           # required
    namespace: sdi_claude                # optional (publishable IPs only)
    version: "1.0.0"                     # optional (publishable IPs only)
    license: Apache-2.0
    description: "…"
    hdl:
      language: systemverilog
      library: work
      files: [hdl/pulp_axis_stream_mux.sv, …]
    dependencies: {}
    build:                               # optional — in-project build only
      paths:   {sources: hdl}
      synthesis: {mode: rtl}             # compile order always via resolver
      ips: []
    packaging:                           # optional — IP-XACT auto-packaging
      recipe: tcl/package.tcl
    interfaces: [], parameters: [], fpga: {...}

This module provides a single normalizer, :func:`normalize_ip_yml`, that
coerces any of the legacy shapes into the canonical form.  All readers
go through it so the rest of the codebase sees one shape. Legacy files
keep working without migration for one or two releases, with a
deprecation warning surfaced by :func:`detect_legacy_shape`.
"""

from __future__ import annotations

from typing import Any

# ── Public API ────────────────────────────────────────────────────────────────


def normalize_ip_yml(data: Any) -> dict:
    """Return the canonical unified dict for an ip.yml payload.

    Accepts any of:
      * The canonical unified shape (pass-through).
      * The legacy vendored shape (``ip: {...}`` wrapper + top-level
        ``paths`` / ``synthesis`` / ``ips``) — rewrites under ``build:``.
      * The legacy registry/flat shape — pass-through (identity fields
        already at root; no ``build`` block will be present).

    Any of the three may carry a ``packaging:`` block at the root — it
    is preserved verbatim.

    When both legacy and canonical forms for a field are present, the
    canonical (root / ``build``) form wins. This matches the direction
    we want authors to converge toward.

    Non-dict input yields ``{}``.
    """
    if not isinstance(data, dict):
        return {}

    out: dict = {}

    # ── Identity tier (root-first, fall back to nested ip.*) ────────────
    ip_block = data.get("ip") if isinstance(data.get("ip"), dict) else {}

    for field in ("name", "namespace", "version", "description"):
        val = data.get(field)
        if val is None or (isinstance(val, str) and not val.strip()):
            val = ip_block.get(field)
        if val is not None:
            out[field] = val

    # License — root wins, nested fills in. (Already implemented in
    # pkg._find_vendored_license, mirrored here for a single source of truth.)
    lic = data.get("license")
    if not (isinstance(lic, str) and lic.strip()):
        lic = ip_block.get("license")
    if isinstance(lic, str) and lic.strip():
        out["license"] = lic.strip()

    # ── HDL manifest ────────────────────────────────────────────────────
    # Unified: top-level `hdl:` block.
    # Legacy: hdl language/library were under `ip:`, files weren't listed
    # at all (resolver walked paths.sources). Reconstitute what we can.
    #
    # Mini-project extensions (RTL-P2.431): `hdl.top_module` and
    # `hdl.top_sim` are preserved verbatim — they're standalone entry
    # points for `rr synth run --ip` and `rr sim run --ip`.
    hdl_raw = data.get("hdl")
    if isinstance(hdl_raw, dict):
        hdl_out = dict(hdl_raw)
    else:
        hdl_out = {}
    # Back-fill language/library from legacy ip: wrapper if the root hdl
    # block didn't declare them.
    if "language" not in hdl_out and ip_block.get("language"):
        hdl_out["language"] = ip_block["language"]
    if "library" not in hdl_out and ip_block.get("library"):
        hdl_out["library"] = ip_block["library"]
    if hdl_out:
        out["hdl"] = hdl_out

    # ── Dependencies ────────────────────────────────────────────────────
    if "dependencies" in data:
        out["dependencies"] = data["dependencies"]

    # ── Build block (unified) ───────────────────────────────────────────
    # Unified: top-level `build: {paths, synthesis, ips}`.
    # Legacy:  top-level `paths`, `synthesis`, `ips` as siblings.
    build = data.get("build") if isinstance(data.get("build"), dict) else {}
    build_out: dict = {}

    # paths
    paths = build.get("paths") if isinstance(build.get("paths"), dict) else None
    if paths is None:
        legacy_paths = data.get("paths")
        if isinstance(legacy_paths, dict):
            paths = legacy_paths
    if isinstance(paths, dict) and paths:
        build_out["paths"] = paths

    # synthesis
    syn = build.get("synthesis") if isinstance(build.get("synthesis"), dict) else None
    if syn is None:
        legacy_syn = data.get("synthesis")
        if isinstance(legacy_syn, dict):
            syn = legacy_syn
    if isinstance(syn, dict) and syn:
        build_out["synthesis"] = syn

    # ips (child IP-XACT cores this build pulls in)
    ips = build.get("ips")
    if ips is None:
        ips = data.get("ips")
    if isinstance(ips, list):
        build_out["ips"] = ips

    # ── Mini-project extensions (RTL-P2.431) ────────────────────────────
    # Every one is optional pass-through.  No legacy-shape equivalents
    # — these fields are new, so we only look under the canonical
    # `build:` nesting point.

    # build.simulation.{sources, test_dir, simulator, waves, ...}
    sim = build.get("simulation")
    if isinstance(sim, dict) and sim:
        build_out["simulation"] = sim

    # build.sources.{xdc, mif, ...} — per-IP constraint files + friends
    # (distinct from hdl.files and build.synthesis.sources).
    srcs = build.get("sources")
    if isinstance(srcs, dict) and srcs:
        build_out["sources"] = srcs

    # build.tcl_hooks.{gen_project, synthesis, implementation, bitstream}
    hooks = build.get("tcl_hooks")
    if isinstance(hooks, dict) and hooks:
        build_out["tcl_hooks"] = hooks

    # build.hardware.{vendor, part, tool_version, ...} — standalone
    # synth-smoke target override; parent project.yml wins when IP is
    # used inside a project.
    hw = build.get("hardware")
    if isinstance(hw, dict) and hw:
        build_out["hardware"] = hw

    if build_out:
        out["build"] = build_out

    # ── Top-level requirements pointer (RTL-P2.431 / RTL-P2.430) ────────
    # Absence = IP does not opt into contract-first verification.
    # Presence = relative path from ip_dir (resolved by the consumer) to
    # a requirements.yml file.
    req = data.get("requirements")
    if isinstance(req, str) and req.strip():
        out["requirements"] = req.strip()

    # ── Packaging (shape-agnostic already; keep as-is) ──────────────────
    if isinstance(data.get("packaging"), dict):
        out["packaging"] = data["packaging"]

    # ── Registry metadata (interfaces / parameters / fpga) ──────────────
    for field in ("interfaces", "parameters", "fpga"):
        if field in data:
            out[field] = data[field]

    return out


def detect_legacy_shape(data: Any) -> str | None:
    """Return ``"vendored"`` when the payload uses the old wrapped shape,
    else ``None``.

    Used by readers to emit a one-time deprecation hint so authors know
    to migrate without breaking them immediately.

    Registry-flat shape is NOT flagged — its fields line up with the
    canonical form (just without an optional ``build`` block).
    """
    if not isinstance(data, dict):
        return None
    if isinstance(data.get("ip"), dict) and {"name", "library", "language"} & set(
        data["ip"].keys()
    ):
        return "vendored"
    # Top-level paths/synthesis/ips WITHOUT an ip: wrapper would also be
    # legacy, but this combination wasn't observed in the wild — fold
    # into the vendored bucket if/when it shows up.
    return None


# ── Convenience readers ──────────────────────────────────────────────────────


def build_block(normalized: dict) -> dict:
    """Return the ``build:`` block from a normalized dict, or ``{}``."""
    b = normalized.get("build")
    return b if isinstance(b, dict) else {}


def synthesis_mode(normalized: dict, default: str = "rtl") -> str:
    """Return ``build.synthesis.mode`` with a sensible default."""
    syn = build_block(normalized).get("synthesis") or {}
    mode = syn.get("mode")
    return mode if isinstance(mode, str) and mode else default


def source_scan_dir(normalized: dict) -> str | None:
    """Return ``build.paths.sources`` (the resolver's scan root), or None."""
    paths = build_block(normalized).get("paths") or {}
    src = paths.get("sources")
    return src if isinstance(src, str) else None


def child_ip_paths(normalized: dict) -> list:
    """Return ``build.ips`` — child IP manifests to resolve depth-first."""
    ips = build_block(normalized).get("ips")
    return ips if isinstance(ips, list) else []


# ── Mini-project readers (RTL-P2.431) ────────────────────────────────────────
# Every helper returns an empty default when the corresponding field is
# absent — consumers can iterate without branching.


def top_module(normalized: dict) -> str | None:
    """Return ``hdl.top_module`` (standalone synth-smoke entry), or None."""
    hdl = normalized.get("hdl") or {}
    tm = hdl.get("top_module")
    return tm if isinstance(tm, str) and tm else None


def top_sim(normalized: dict) -> str | None:
    """Return ``hdl.top_sim`` (standalone cocotb testbench top), or None."""
    hdl = normalized.get("hdl") or {}
    ts = hdl.get("top_sim")
    return ts if isinstance(ts, str) and ts else None


def simulation_config(normalized: dict) -> dict:
    """Return the ``build.simulation:`` block as a dict, or ``{}``."""
    sim = build_block(normalized).get("simulation")
    return sim if isinstance(sim, dict) else {}


def simulation_sources(normalized: dict) -> list:
    """Return ``build.simulation.sources`` (a list of relative paths), or ``[]``.

    Empty return signals to the consumer to fall back to the synthesis
    source list — see ``IpManifest.effective_simulation_sources``.
    """
    srcs = simulation_config(normalized).get("sources")
    return srcs if isinstance(srcs, list) else []


def xdc_list(normalized: dict) -> list:
    """Return ``build.sources.xdc`` (a list of relative paths), or ``[]``."""
    srcs = build_block(normalized).get("sources") or {}
    xdc = srcs.get("xdc")
    return xdc if isinstance(xdc, list) else []


def tcl_hooks(normalized: dict) -> dict:
    """Return ``build.tcl_hooks:`` block as a dict (per stage → list of paths), or ``{}``.

    Expected keys: ``gen_project``, ``synthesis``, ``implementation``,
    ``bitstream``.  Unknown keys are preserved — routertl is permissive
    here so vendors can stage custom hooks.
    """
    hooks = build_block(normalized).get("tcl_hooks")
    return hooks if isinstance(hooks, dict) else {}


def hardware_config(normalized: dict) -> dict:
    """Return ``build.hardware:`` block (vendor/part/tool_version/...), or ``{}``.

    When the IP is used inside a project, the parent project.yml's
    hardware block takes precedence — this is only consulted for
    standalone synth-smoke (``rr synth run --ip``).
    """
    hw = build_block(normalized).get("hardware")
    return hw if isinstance(hw, dict) else {}


def requirements_ref(normalized: dict) -> str | None:
    """Return the ``requirements:`` field (relative path), or None.

    Absence means the IP does not opt into contract-first verification —
    consumers should skip it silently rather than erroring.
    """
    req = normalized.get("requirements")
    return req if isinstance(req, str) and req.strip() else None
