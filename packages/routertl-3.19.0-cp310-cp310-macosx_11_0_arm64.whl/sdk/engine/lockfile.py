# SPDX-FileCopyrightText: 2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""routertl.lock — Project State Lockfile Engine.

Resolves the full project state (sources, toolchain, dependencies, SDK version)
and serializes it to ``routertl.lock`` for reproducible builds and simulations.

``project.yml`` is the **intent**; ``routertl.lock`` is the **resolved reality**.

Entry points::

    from sdk.engine.lockfile import resolve_project_state, check_lockfile

    state = resolve_project_state(project_root)   # dict
    ok, diffs = check_lockfile(project_root)       # (bool, list[str])

Design decision: D.10 — routertl.lock subsumes ip.lock data, embeds toolchain
versions and source file hashes (diverging from Cargo's deps-only model).
"""

from __future__ import annotations

import hashlib
import logging
import os
import re
import shutil
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import yaml

_log = logging.getLogger("engine.lockfile")

LOCKFILE_NAME = "routertl.lock"
LOCKFILE_VERSION = 1

# EDA tools to detect — (binary, label, version_command, version_regex)
_EDA_TOOLS = [
    ("nvc", "NVC", "nvc --version", r"nvc (\d+\.\d+\.\d+)"),
    ("ghdl", "GHDL", "ghdl --version", r"GHDL (\d+\.\d+\.\d+)"),
    ("verilator", "Verilator", "verilator --version", r"Verilator (\d+\.\d+)"),
    ("vivado", "Vivado", "vivado -version", r"Vivado v(\d+\.\d+)"),
    ("quartus_sh", "Quartus", "quartus_sh --version", r"Version (\d+\.\d+)"),
]

# Vendor binaries that should respect hardware.tool_path from project.yml
_TOOL_PATH_BINARIES = {"quartus_sh", "vivado"}


# ── Public API ────────────────────────────────────────────────────────────────


def resolve_project_state(project_root: str | Path) -> dict[str, Any]:
    """Resolve the full project state into a lockfile-ready dict.

    Calls existing engine APIs to assemble:
    - Project metadata (name, top_module)
    - Toolchain detection (vendor tool + version)
    - Simulator detection (from project.yml + env override)
    - SDK version + git state
    - Source file inventory with SHA-256 hashes
    - Resolved compile order (via dependency resolver)
    - Constraint files with hashes
    - IP package dependencies (subsuming ip.lock)

    Parameters
    ----------
    project_root : path
        Absolute path to the project root (where project.yml lives).

    Returns
    -------
    dict
        The fully resolved project state, ready for YAML serialization.
    """
    root = Path(project_root).resolve()
    config = _load_config(root)

    state: dict[str, Any] = {"version": LOCKFILE_VERSION}

    # Project metadata
    state["project"] = _resolve_project(config)

    # Toolchain
    state["toolchain"] = _resolve_toolchain(config, root)

    # Simulation
    state["simulation"] = _resolve_simulation(config)

    # SDK version
    state["sdk"] = _resolve_sdk(root)

    # Source files with hashes
    state["sources"] = _resolve_sources(config, root)

    # Compile order via dependency resolver
    state["resolved_hierarchy"] = _resolve_hierarchy(config, root)

    # Constraint files
    state["constraints"] = _resolve_constraints(config, root)

    # IP package dependencies (subsumes ip.lock)
    state["dependencies"] = _resolve_dependencies(root)

    # Environment variable snapshot (P2.106)
    env_snapshot = _resolve_environment(config)
    if env_snapshot:
        state["environment"] = env_snapshot

    # Timestamp
    state["locked_at"] = datetime.now(timezone.utc).isoformat(timespec="seconds")

    return state


def write_lockfile(state: dict[str, Any], project_root: str | Path) -> Path:
    """Serialize resolved state to ``routertl.lock``.

    Uses sorted keys for deterministic diffs across runs.

    Returns the path to the written lockfile.
    """
    root = Path(project_root).resolve()
    lock_path = root / LOCKFILE_NAME

    with open(lock_path, "w") as f:
        yaml.dump(
            state,
            f,
            default_flow_style=False,
            sort_keys=True,
            allow_unicode=True,
            width=120,
        )

    _log.info("Written %s", lock_path)
    return lock_path


def load_lockfile(project_root: str | Path) -> dict[str, Any]:
    """Read and parse an existing ``routertl.lock``.

    Returns
    -------
    dict
        The parsed lockfile contents, or empty dict if no lockfile exists.
    """
    lock_path = Path(project_root).resolve() / LOCKFILE_NAME
    if not lock_path.exists():
        return {}
    with open(lock_path) as f:
        return yaml.safe_load(f) or {}


def check_lockfile(
    project_root: str | Path,
) -> tuple[bool, list[str]]:
    """Compare current project state against the existing lockfile.

    Returns
    -------
    (ok, diffs)
        ok: True if lockfile matches current state.
        diffs: List of human-readable mismatch descriptions.
    """
    root = Path(project_root).resolve()
    lock_path = root / LOCKFILE_NAME

    if not lock_path.exists():
        return False, [f"No lockfile found at {lock_path}. Run 'rr lock' to create one."]

    locked = load_lockfile(root)
    current = resolve_project_state(root)

    diffs: list[str] = []

    # Compare sections
    _diff_section(diffs, "toolchain", locked, current)
    _diff_section(diffs, "simulation", locked, current)
    _diff_sdk(diffs, locked, current)
    _diff_section(diffs, "sources", locked, current)
    _diff_section(diffs, "constraints", locked, current)
    _diff_section(diffs, "resolved_hierarchy", locked, current)
    _diff_section(diffs, "dependencies", locked, current)
    _diff_section(diffs, "environment", locked, current)

    return (len(diffs) == 0), diffs


# ── Resolution helpers ────────────────────────────────────────────────────────


def _load_config(root: Path) -> dict:
    """Load project.yml from ``root``, resolving any ``target:`` pointer.

    RTL-P2.352: the pre-fix version read project.yml directly without
    chasing the ``target:`` pointer, so a pointer-style project.yml
    (the common multi-target layout) returned an almost-empty dict.
    Every downstream resolver (``_resolve_project`` /
    ``_resolve_toolchain`` / ``_resolve_sources`` / ``_resolve_hierarchy``)
    then saw missing ``project`` / ``hardware`` / ``sources`` keys and
    fell back to ``"unknown"`` / ``[]``, producing the stub lockfile
    RTL-P1.45 now catches.

    Resolution is done here (rather than via
    ``sdk.cli.project_config.load_project_config``) because the
    canonical loader resolves target paths relative to CWD, and
    ``resolve_project_state`` may be called from anywhere.  We resolve
    target paths explicitly against ``root`` so the lockfile is
    correct regardless of CWD.
    """
    yml_path = root / "project.yml"
    if not yml_path.exists():
        _log.warning("No project.yml found at %s", root)
        return {}
    with open(yml_path) as f:
        config = yaml.safe_load(f) or {}
    if not isinstance(config, dict):
        return {}

    # Environment override takes precedence over the YAML pointer.
    env_target = os.environ.get("RR_TARGET")
    target_path_str = env_target if env_target else config.get("target")

    if target_path_str:
        target_path = Path(target_path_str)
        if not target_path.is_absolute():
            target_path = root / target_path
        if target_path.exists():
            with open(target_path) as f:
                target_config = yaml.safe_load(f) or {}
            if isinstance(target_config, dict):
                return target_config
        else:
            _log.warning(
                "target: %s referenced from %s does not exist — "
                "lockfile will be resolved from the pointer file only",
                target_path_str, yml_path,
            )

    return config


def _resolve_project(config: dict) -> dict[str, str]:
    """Extract project name and top module from config."""
    project = config.get("project", {})
    if not isinstance(project, dict):
        project = {}
    return {
        "name": project.get("name", "unknown"),
        "top_module": project.get("top_module", project.get("top", "unknown")),
    }


def _resolve_toolchain(config: dict, root: Path) -> dict[str, str]:
    """Detect the build toolchain from project.yml + environment."""
    from sdk.cli.project_config import derive_target_code

    hw = config.get("hardware", {})
    if not isinstance(hw, dict):
        hw = {}

    vendor = hw.get("vendor", "unknown")
    part = hw.get("part", "unknown")
    target = derive_target_code(config)

    # Map vendor to primary tool binary
    vendor_tool_map = {
        "xilinx": ("vivado", "Vivado"),
        "altera": ("quartus_sh", "Quartus"),
        "lattice": ("radiant", "Radiant"),
        "microchip": ("libero", "Libero"),
    }

    tool_name = "unknown"
    tool_version = "unknown"

    tool_binary, tool_label = vendor_tool_map.get(vendor, (None, None))
    if tool_binary:
        tool_name = tool_label
        tool_version = _detect_tool_version(tool_binary, root)

    # Also check build_options.tool_version from project.yml
    build_opts = config.get("build_options", {})
    if isinstance(build_opts, dict):
        yml_version = build_opts.get("tool_version")
        if yml_version and tool_version == "unknown":
            tool_version = str(yml_version)

    result = {
        "vendor": vendor,
        "tool": tool_name,
        "version": tool_version,
        "part": part,
    }
    if target:
        result["target"] = target
    return result


def _detect_tool_version(binary: str, root: Path) -> str:
    """Detect the version of an EDA tool binary."""
    for bin_name, label, ver_cmd, ver_re in _EDA_TOOLS:
        if bin_name != binary:
            continue

        # Resolve path — use tool_path API for vendor tools
        path = None
        if bin_name in _TOOL_PATH_BINARIES:
            try:
                from sdk.api.tools import resolve_tool_binary
                path = resolve_tool_binary(bin_name)
            except (ImportError, OSError, ValueError):
                path = shutil.which(bin_name)
        else:
            path = shutil.which(bin_name)

        if not path:
            return "not-found"

        try:
            resolved_cmd = [path] + ver_cmd.split()[1:]
            env = None
            if bin_name == "verilator":
                env = {**os.environ, "VERILATOR_ROOT": ""}
            proc = subprocess.run(
                resolved_cmd,
                capture_output=True,
                text=True,
                timeout=3,
                env=env,
            )
            m = re.search(ver_re, proc.stdout + proc.stderr)
            if m:
                return m.group(1)
        except (subprocess.TimeoutExpired, OSError):
            pass

        return "unknown"

    return "unknown"


def _resolve_simulation(config: dict) -> dict[str, Any]:
    """Resolve simulator from project.yml + SIM env var override.

    Also captures COCOTB_RANDOM_SEED for full simulation reproducibility.
    """
    sim_config = config.get("simulation", {})
    if not isinstance(sim_config, dict):
        sim_config = {}

    yml_sim = sim_config.get("simulator", "nvc")
    env_sim = os.environ.get("SIM")
    simulator = env_sim if env_sim else yml_sim

    # Detect simulator version
    version = _detect_tool_version(simulator, Path.cwd())

    result: dict[str, Any] = {
        "simulator": simulator,
        "version": version,
    }

    # Capture COCOTB_RANDOM_SEED if set (P2.106)
    seed = os.environ.get("COCOTB_RANDOM_SEED")
    if seed is not None:
        try:
            result["cocotb_random_seed"] = int(seed)
        except ValueError:
            result["cocotb_random_seed"] = seed

    return result


def _resolve_sdk(root: Path) -> dict[str, Any]:
    """Resolve SDK version, git commit, and dirty state."""
    version = "unknown"
    try:
        from routertl_core import __version__
        version = __version__
    except ImportError:
        pass

    commit = "unknown"
    dirty = False

    # Try SDK git state from the SDK installation path
    try:
        from sdk.cli.sdk_root import resolve_sdk_root
        sdk_root = resolve_sdk_root()
        if sdk_root and (sdk_root / ".git").exists():
            commit = _git_head_sha(sdk_root)
            dirty = _git_is_dirty(sdk_root)
    except (ImportError, OSError):
        pass

    return {
        "version": version,
        "commit": commit,
        "dirty": dirty,
    }


def _resolve_sources(config: dict, root: Path) -> list[dict[str, str]]:
    """Collect all source files with SHA-256 hashes.

    Reads the ``sources:`` section from project.yml and hashes each file.
    """
    sources_config = config.get("sources", {})
    if not isinstance(sources_config, dict):
        sources_config = {}

    source_files: list[Path] = []

    # Collect from all source categories
    for category in ("syn", "sim", "ip", "tcl"):
        entries = sources_config.get(category, [])
        if isinstance(entries, str):
            entries = [entries]
        if not isinstance(entries, list):
            continue
        for entry in entries:
            path = root / entry
            if path.is_file():
                source_files.append(path)
            elif path.is_dir():
                # Glob for HDL files in directories
                for ext in ("*.vhd", "*.vhdl", "*.v", "*.sv", "*.svh"):
                    source_files.extend(sorted(path.rglob(ext)))

    # Deduplicate and sort for determinism
    seen: set[Path] = set()
    unique_sources: list[Path] = []
    for f in source_files:
        resolved = f.resolve()
        if resolved not in seen:
            seen.add(resolved)
            unique_sources.append(resolved)
    unique_sources.sort()

    result = []
    for src in unique_sources:
        try:
            rel_path = src.relative_to(root)
        except ValueError:
            rel_path = src
        result.append({
            "path": str(rel_path),
            "sha256": _sha256_file(src),
        })

    return result


def _resolve_hierarchy(config: dict, root: Path) -> dict[str, Any]:
    """Resolve the design hierarchy and compile order.

    Uses the dependency resolver from routertl_core when available,
    falls back to a simple listing otherwise.

    RTL-P2.355: the pre-fix version scanned ``src/`` (the whole repo
    source tree) when ``sources.syn`` didn't name any directories.  On
    a multi-target project that meant the compile_order was the UNION
    of every target's sources — 235 files on Nike's
    test_rtp_tse_gxb target, including DDR interconnect, h264 FME,
    video_pipe, and Nike-only tse_cdc_handshake files that the active
    target does not use.  Worse, when the ``top`` lookup failed (pre-
    RTL-P2.352 ``top == "unknown"`` because target pointer wasn't
    resolved), the code fell through to ``use all resolved files from
    first tree`` — cementing the wrong compile_order without any
    indication that the scope was broken.

    This version scans ONLY the concrete files declared in
    ``sources.syn`` / ``sources.sim`` (post-P2.352 these come from the
    active target's yml), feeds them to the resolver as parent dirs,
    and drops the all-targets fallback.  If the top isn't found,
    compile_order stays empty and the log explains why — the stub
    validator from RTL-P1.45 will fail the check fast.
    """
    project = config.get("project", {})
    if not isinstance(project, dict):
        project = {}
    top = project.get("top_module", project.get("top", "unknown"))

    hierarchy: dict[str, Any] = {"top": top, "compile_order": []}

    try:
        from sdk.engine.dependency_resolver import DependencyResolver

        sources_config = config.get("sources", {})
        if not isinstance(sources_config, dict):
            sources_config = {}

        # RTL-P2.355: collect the parent directory of every declared
        # source file so the resolver sees ONLY files that belong to
        # this target.  Scanning "src/" wholesale picks up other
        # targets' sources and corrupts compile_order on multi-target
        # projects.
        seen_dirs: set[Path] = set()
        for category in ("syn", "sim"):
            entries = sources_config.get(category, [])
            if isinstance(entries, str):
                entries = [entries]
            if not isinstance(entries, list):
                continue
            for entry in entries:
                p = root / entry
                if p.is_dir():
                    seen_dirs.add(p)
                elif p.is_file():
                    seen_dirs.add(p.parent)

        src_dirs = [d for d in seen_dirs if d.exists()]
        if not src_dirs:
            # Nothing to resolve — the target declares no sources, or
            # the declared paths don't exist.  Return top-only so the
            # stub validator (RTL-P1.45) flags the build and the user
            # can run `rr lock` against a target that has sources.
            _log.debug(
                "No sources declared in the active target — "
                "compile_order left empty"
            )
            return hierarchy

        resolver = DependencyResolver(src_dirs, verbose=False)
        forest = resolver.resolve_forest()

        # Find compile order for the TOP MODULE.  No all-target-union
        # fallback; if the top isn't in the forest, the resolver scan
        # missed it and we prefer an empty compile_order over a wrong
        # one.
        for tree in forest.get("trees", []):
            if tree.get("top") == top:
                files = tree.get("files", [])
                hierarchy["compile_order"] = [
                    str(Path(f).relative_to(root)) if Path(f).is_absolute() else f
                    for f in files
                ]
                break
        else:
            _log.warning(
                "Top module '%s' not found in resolved forest — "
                "compile_order left empty (resolver saw trees: %s)",
                top,
                sorted(t.get("top", "?") for t in forest.get("trees", [])),
            )

    except (ImportError, OSError, ValueError, TypeError) as exc:
        _log.debug("Dependency resolution failed: %s", exc)

    return hierarchy


def _resolve_constraints(config: dict, root: Path) -> list[dict[str, str]]:
    """Collect constraint files (XDC/SDC) with hashes."""
    sources_config = config.get("sources", {})
    if not isinstance(sources_config, dict):
        sources_config = {}

    constraint_files: list[Path] = []
    for category in ("xdc", "sdc"):
        entries = sources_config.get(category, [])
        if isinstance(entries, str):
            entries = [entries]
        if not isinstance(entries, list):
            continue
        for entry in entries:
            path = root / entry
            if path.is_file():
                constraint_files.append(path)
            elif path.is_dir():
                for ext in ("*.xdc", "*.sdc"):
                    constraint_files.extend(sorted(path.rglob(ext)))

    constraint_files.sort()

    result = []
    for f in constraint_files:
        try:
            rel_path = f.relative_to(root)
        except ValueError:
            rel_path = f
        result.append({
            "path": str(rel_path),
            "sha256": _sha256_file(f),
        })

    return result


def _resolve_dependencies(root: Path) -> list[dict[str, Any]]:
    """Read ip.lock and embed dependency data in the lockfile."""
    try:
        from sdk.engine.package_resolver import load_lock
        locked = load_lock(root)
    except (ImportError, OSError, yaml.YAMLError):
        locked = {}

    if not locked:
        return []

    deps = []
    for pkg_ref, entry in sorted(locked.items()):
        deps.append({
            "name": pkg_ref,
            "resolved_version": entry.get("resolved_version", "unknown"),
            "url": entry.get("url", ""),
            "commit": entry.get("commit", "unknown"),
            "library": entry.get("library", "work"),
            "local_path": entry.get("local_path", ""),
            "files": entry.get("files", []),
        })

    return deps


def _resolve_environment(config: dict) -> dict[str, str]:
    """Snapshot environment variables declared in project.yml.

    Reads the ``environment:`` block from project.yml and captures the
    current value of each declared variable from the OS environment.
    Variables that are declared but not set are recorded as null.
    """
    env_block = config.get("environment", {})
    if not isinstance(env_block, dict):
        return {}

    snapshot: dict[str, str | None] = {}
    for var_name, default_value in sorted(env_block.items()):
        actual = os.environ.get(var_name)
        if actual is not None:
            snapshot[var_name] = actual
        elif default_value is not None:
            snapshot[var_name] = str(default_value)
        else:
            snapshot[var_name] = None

    return snapshot


# ── Diff helpers ──────────────────────────────────────────────────────────────


def _diff_section(
    diffs: list[str], section: str, locked: dict, current: dict
) -> None:
    """Compare a top-level section between locked and current state."""
    old = locked.get(section)
    new = current.get(section)

    if old is None and new is None:
        return
    if old is None:
        diffs.append(f"[added] {section}: new section not in lockfile")
        return
    if new is None:
        diffs.append(f"[removed] {section}: section missing from current state")
        return

    if isinstance(old, dict) and isinstance(new, dict):
        _diff_dict(diffs, section, old, new)
    elif isinstance(old, list) and isinstance(new, list):
        _diff_list(diffs, section, old, new)
    elif old != new:
        diffs.append(f"[changed] {section}: {old!r} → {new!r}")


def _diff_dict(
    diffs: list[str], prefix: str, old: dict, new: dict
) -> None:
    """Recursively diff two dicts."""
    all_keys = sorted(set(old.keys()) | set(new.keys()))
    for key in all_keys:
        full_key = f"{prefix}.{key}"
        if key not in old:
            diffs.append(f"[added] {full_key}: {new[key]!r}")
        elif key not in new:
            diffs.append(f"[removed] {full_key}: was {old[key]!r}")
        elif old[key] != new[key]:
            if isinstance(old[key], dict) and isinstance(new[key], dict):
                _diff_dict(diffs, full_key, old[key], new[key])
            else:
                diffs.append(f"[changed] {full_key}: {old[key]!r} → {new[key]!r}")


def _diff_list(
    diffs: list[str], section: str, old: list, new: list
) -> None:
    """Diff two lists of dicts (e.g. sources, constraints)."""
    if section in ("sources", "constraints"):
        # Index by path for meaningful diffs
        old_by_path = {item["path"]: item for item in old if isinstance(item, dict)}
        new_by_path = {item["path"]: item for item in new if isinstance(item, dict)}

        for path in sorted(set(old_by_path) | set(new_by_path)):
            if path not in old_by_path:
                diffs.append(f"[added] {section}: {path}")
            elif path not in new_by_path:
                diffs.append(f"[removed] {section}: {path}")
            else:
                old_hash = old_by_path[path].get("sha256", "")
                new_hash = new_by_path[path].get("sha256", "")
                if old_hash != new_hash:
                    diffs.append(
                        f"[changed] {section}: {path} "
                        f"(sha256: {old_hash[:12]}… → {new_hash[:12]}…)"
                    )
    else:
        if old != new:
            diffs.append(f"[changed] {section}: list contents differ")


def _diff_sdk(diffs: list[str], locked: dict, current: dict) -> None:
    """Compare SDK version between locked and current."""
    old_sdk = locked.get("sdk", {})
    new_sdk = current.get("sdk", {})

    if old_sdk.get("version") != new_sdk.get("version"):
        diffs.append(
            f"[changed] sdk.version: "
            f"{old_sdk.get('version')} → {new_sdk.get('version')}"
        )
    if old_sdk.get("commit") != new_sdk.get("commit"):
        diffs.append(
            f"[changed] sdk.commit: "
            f"{old_sdk.get('commit', '')[:8]}… → {new_sdk.get('commit', '')[:8]}…"
        )
    if old_sdk.get("dirty") != new_sdk.get("dirty"):
        diffs.append(
            f"[changed] sdk.dirty: "
            f"{old_sdk.get('dirty')} → {new_sdk.get('dirty')}"
        )


# ── Utility ───────────────────────────────────────────────────────────────────


def _sha256_file(path: Path) -> str:
    """Return the SHA-256 hex digest of a file."""
    h = hashlib.sha256()
    try:
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(8192), b""):
                h.update(chunk)
        return h.hexdigest()
    except OSError:
        _log.warning("Cannot hash %s", path)
        return "error"


def _git_head_sha(repo_path: Path) -> str:
    """Return the HEAD commit SHA of a git repo."""
    try:
        result = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            cwd=repo_path,
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode == 0:
            return result.stdout.strip()
    except (subprocess.TimeoutExpired, OSError):
        pass
    return "unknown"


def _git_is_dirty(repo_path: Path) -> bool:
    """Return True if the git repo has uncommitted changes."""
    try:
        result = subprocess.run(
            ["git", "status", "--porcelain"],
            cwd=repo_path,
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode == 0:
            return bool(result.stdout.strip())
    except (subprocess.TimeoutExpired, OSError):
        pass
    return False
