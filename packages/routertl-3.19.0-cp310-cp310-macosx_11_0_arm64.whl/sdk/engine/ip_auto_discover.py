# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
IP Auto-Discovery Engine (P2.114).

Scans a source tree using DependencyResolver, groups entities by directory
(or hierarchy root), detects cross-directory dependencies, and proposes
ip.yml manifests with source lists and inter-area dependency edges.
"""

from __future__ import annotations

import logging
from collections import defaultdict
from pathlib import Path
from typing import Any, Dict, List, Optional

import yaml

logger = logging.getLogger(__name__)

# ── HDL extension sets ────────────────────────────────────────────
_VHDL_EXTS = {".vhd", ".vhdl"}
_SV_EXTS = {".v", ".sv", ".vh", ".svh"}


def _detect_language(file_paths: List[Path]) -> str:
    """Detect language from a collection of source file extensions."""
    has_vhdl = any(p.suffix.lower() in _VHDL_EXTS for p in file_paths)
    has_sv = any(p.suffix.lower() in _SV_EXTS for p in file_paths)
    if has_vhdl and has_sv:
        return "mixed"
    if has_sv:
        return "systemverilog"
    return "vhdl"


def _area_name_from_dir(dir_path: Path, src_root: Path) -> str:
    """Derive an area name from a directory relative to the source root.

    Uses the relative path from the source root to the directory,
    joining components with underscores.  Falls back to the directory
    name when the path is at the source root itself.
    """
    try:
        rel = dir_path.relative_to(src_root)
    except ValueError:
        return dir_path.name
    parts = rel.parts
    if not parts or parts == (".",):
        return src_root.name
    return "_".join(parts)


def auto_discover(
    src_dirs: List[Path],
    group_by: str = "directory",
    library: Optional[str] = None,
    respect_gitignore: bool = True,
    project_root: Optional[Path] = None,
) -> List[Dict[str, Any]]:
    """Scan source directories and propose ip.yml manifests.

    Parameters
    ----------
    src_dirs : list[Path]
        Directories to scan for HDL sources.
    group_by : str
        Grouping strategy: ``"directory"`` (default) groups by parent
        directory; ``"hierarchy"`` groups by hierarchy root.
    library : str or None
        VHDL library name override applied to every area.  When
        ``None``, each area uses its directory name as library.
    respect_gitignore : bool
        Passed through to ``DependencyResolver``.
    project_root : Path or None
        Project root for computing relative source paths.  Defaults
        to ``Path.cwd()`` when not specified.

    Returns
    -------
    list[dict]
        Each dict represents a proposed IP area with keys:
        ``name``, ``mode``, ``library``, ``language``, ``sources``,
        ``dependencies``, ``ip_dir``.
    """
    from routertl_core.dependency_resolver import DependencyResolver

    if project_root is None:
        project_root = Path.cwd()

    resolver = DependencyResolver(
        src_dirs, respect_gitignore=respect_gitignore,
    )

    if group_by == "hierarchy":
        return _group_by_hierarchy(resolver, src_dirs, library, project_root)
    return _group_by_directory(resolver, src_dirs, library, project_root)


# ── Group-by-directory strategy ───────────────────────────────────

def _group_by_directory(
    resolver,
    src_dirs: List[Path],
    library_override: Optional[str],
    project_root: Path,
) -> List[Dict[str, Any]]:
    """Group entities by their source file's parent directory."""
    # Resolve the primary src_root for relative path calculation
    src_root = src_dirs[0].resolve() if src_dirs else Path.cwd()

    # 1. Collect all source files → area mapping
    # area_key = resolved parent directory
    area_files: Dict[Path, List[Path]] = defaultdict(list)
    area_entities: Dict[Path, List[str]] = defaultdict(list)
    area_packages: Dict[Path, List[str]] = defaultdict(list)

    # Entity/package → area lookup (for dependency detection)
    name_to_area: Dict[str, Path] = {}

    for name, path in resolver.entity_map.items():
        parent = path.resolve().parent
        if parent not in area_files or path not in area_files[parent]:
            area_files[parent].append(path)
        area_entities[parent].append(name)
        name_to_area[name] = parent

    for name, path in resolver.package_map.items():
        parent = path.resolve().parent
        if path not in area_files.get(parent, []):
            area_files[parent].append(path)
        area_packages[parent].append(name)
        name_to_area[name] = parent

    if not area_files:
        return []

    # 2. Detect inter-area dependencies
    area_deps: Dict[Path, set] = defaultdict(set)
    for area_dir, entities in area_entities.items():
        for entity_name in entities:
            entity_path = resolver.entity_map.get(entity_name)
            if not entity_path:
                continue

            dep_names = set()
            suffix = entity_path.suffix.lower()
            if suffix in _VHDL_EXTS:
                # Package uses
                pkgs = resolver.find_vhdl_packages(entity_path)
                dep_names.update(pkgs)
                # Entity instantiations
                insts = resolver.find_instantiated_entities_vhdl(entity_path)
                dep_names.update(ent for _, ent in insts)
            elif suffix in _SV_EXTS:
                mods, _incs, pkgs = resolver.find_verilog_dependencies(
                    entity_path,
                )
                dep_names.update(mods)
                dep_names.update(pkgs)

            # Check which deps belong to a different area
            for dep_name in dep_names:
                dep_area = name_to_area.get(dep_name)
                if dep_area and dep_area != area_dir:
                    area_deps[area_dir].add(dep_area)

    # 3. Build result list
    return _build_area_list(
        area_files, area_deps, src_root, library_override, project_root,
    )


# ── Group-by-hierarchy strategy ───────────────────────────────────

def _group_by_hierarchy(
    resolver,
    src_dirs: List[Path],
    library_override: Optional[str],
    project_root: Path,
) -> List[Dict[str, Any]]:
    """Group entities by their hierarchy root."""
    src_root = src_dirs[0].resolve() if src_dirs else Path.cwd()
    forest = resolver.resolve_forest()
    trees = forest.get("trees", [])
    orphans = forest.get("orphans", [])

    # Map each file to its hierarchy root name
    file_to_root: Dict[str, str] = {}
    for tree in trees:
        root_name = tree["top"]
        for f in tree.get("files", []):
            file_to_root[f] = root_name

    # Group files by root
    root_files: Dict[str, List[Path]] = defaultdict(list)
    for tree in trees:
        root_name = tree["top"]
        for f in tree.get("files", []):
            root_files[root_name].append(Path(f))

    # Orphans become their own "area"
    for o in orphans:
        p = Path(o)
        root_files[p.stem].append(p)

    # Entity/package → root mapping for dependency detection
    name_to_root: Dict[str, str] = {}
    for name, path in {**resolver.entity_map, **resolver.package_map}.items():
        root = file_to_root.get(str(path.resolve()))
        if root:
            name_to_root[name] = root
        else:
            name_to_root[name] = name  # orphan

    # Detect inter-root dependencies
    root_deps: Dict[str, set] = defaultdict(set)
    for name, path in resolver.entity_map.items():
        my_root = name_to_root.get(name)
        if not my_root:
            continue

        dep_names: set = set()
        suffix = path.suffix.lower()
        if suffix in _VHDL_EXTS:
            dep_names.update(resolver.find_vhdl_packages(path))
            dep_names.update(
                ent for _, ent in resolver.find_instantiated_entities_vhdl(path)
            )
        elif suffix in _SV_EXTS:
            mods, _incs, pkgs = resolver.find_verilog_dependencies(path)
            dep_names.update(mods)
            dep_names.update(pkgs)

        for dep_name in dep_names:
            dep_root = name_to_root.get(dep_name)
            if dep_root and dep_root != my_root:
                root_deps[my_root].add(dep_root)

    # Build results using shared helper
    results = []
    for area_name in sorted(root_files.keys()):
        area = _format_area(
            area_name=area_name,
            files=root_files[area_name],
            dep_names=sorted(root_deps.get(area_name, set())),
            library_override=library_override,
            project_root=project_root,
        )
        if area:
            results.append(area)

    return results


# ── Common helpers ────────────────────────────────────────────────

def _dedup_files(files: List[Path]) -> List[Path]:
    """Deduplicate file list by resolved path, preserving order."""
    seen: set = set()
    unique: list = []
    for f in files:
        key = str(f.resolve())
        if key not in seen:
            seen.add(key)
            unique.append(f)
    return unique


def _format_area(
    area_name: str,
    files: List[Path],
    dep_names: List[str],
    library_override: Optional[str],
    project_root: Optional[Path] = None,
) -> Optional[Dict[str, Any]]:
    """Build a single area dict from deduplicated files and dependency names."""
    import os

    unique_files = _dedup_files(files)
    if not unique_files:
        return None

    root = project_root or Path.cwd()
    lang = _detect_language(unique_files)
    lib = library_override or area_name or "work"

    # ip.yml would live at ip/<area_name>/ip.yml
    ip_dir = Path("ip") / area_name
    ip_dir_abs = root / ip_dir

    # Source paths relative to the ip.yml location
    rel_sources = []
    for f in sorted(unique_files, key=lambda p: p.name):
        try:
            rel = os.path.relpath(f.resolve(), ip_dir_abs)
            rel_sources.append(rel)
        except ValueError:
            rel_sources.append(str(f))

    return {
        "name": area_name,
        "mode": "rtl",
        "library": lib,
        "language": lang,
        "sources": rel_sources,
        "dependencies": dep_names,
        "ip_dir": str(ip_dir),
    }


def _build_area_list(
    area_files: Dict[Path, List[Path]],
    area_deps: Dict[Path, set],
    src_root: Path,
    library_override: Optional[str],
    project_root: Optional[Path] = None,
) -> List[Dict[str, Any]]:
    """Build the final area list from directory-grouped data."""
    # area_dir → area_name
    dir_to_name: Dict[Path, str] = {}
    for area_dir in area_files:
        dir_to_name[area_dir] = _area_name_from_dir(area_dir, src_root)

    results = []
    for area_dir in sorted(area_files.keys(), key=lambda d: dir_to_name[d]):
        area_name = dir_to_name[area_dir]

        dep_names = sorted(
            dir_to_name[d]
            for d in area_deps.get(area_dir, set())
            if d in dir_to_name
        )

        area = _format_area(
            area_name=area_name,
            files=area_files[area_dir],
            dep_names=dep_names,
            library_override=library_override,
            project_root=project_root,
        )
        if area:
            results.append(area)

    return results


def write_manifests(
    areas: List[Dict[str, Any]],
    output_root: Path,
) -> List[Path]:
    """Write ip.yml manifests for the given areas.

    Parameters
    ----------
    areas : list[dict]
        Output of :func:`auto_discover`.
    output_root : Path
        Root directory under which ``ip/<area>/ip.yml`` is created.

    Returns
    -------
    list[Path]
        Paths of the created ip.yml files.
    """
    written: list = []
    for area in areas:
        ip_dir = output_root / area["ip_dir"]
        ip_dir.mkdir(parents=True, exist_ok=True)
        ip_yml = ip_dir / "ip.yml"

        data = {
            "ip": {
                "name": area["name"],
                "library": area["library"],
                "language": area["language"],
            },
            "synthesis": {
                "mode": area["mode"],
                "sources": area["sources"],
            },
            "dependencies": area["dependencies"],
        }

        ip_yml.write_text(
            yaml.dump(data, default_flow_style=False, sort_keys=False),
            encoding="utf-8",
        )
        written.append(ip_yml)
        logger.info("Wrote %s", ip_yml)

    return written
