# SPDX-FileCopyrightText: 2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Discover Vivado user IPs by scanning directories for component.xml.

Supports ``sources.ip_paths`` in project.yml — directories are scanned
recursively for IP-XACT component.xml files and parsed via ipxact_parser
to extract VLNV and module name.

RTL-P3.98
"""

from __future__ import annotations

import logging
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field
from pathlib import Path

_log = logging.getLogger(__name__)


@dataclass
class DiscoveredIp:
    """An IP found by scanning an ip_paths directory."""

    name: str  # IP module name (from IP-XACT <name>)
    vlnv: str  # vendor:library:name:version
    component_xml: Path  # Absolute path to component.xml
    ip_dir: Path  # Parent directory of component.xml


@dataclass
class IpDiscoveryResult:
    """Result of scanning ip_paths directories."""

    ips: list[DiscoveredIp] = field(default_factory=list)
    ip_dirs: list[str] = field(default_factory=list)  # validated dirs (for TCL)
    warnings: list[str] = field(default_factory=list)

    @property
    def names(self) -> set[str]:
        """Set of discovered IP names (lowercase for matching)."""
        return {ip.name.lower() for ip in self.ips}


def discover_ips(ip_paths: list[str], project_root: Path) -> IpDiscoveryResult:
    """Scan *ip_paths* directories for component.xml files.

    Each path is resolved relative to *project_root*.  Non-existent
    directories produce a warning but don't cause failure.

    Returns an :class:`IpDiscoveryResult` with discovered IPs and
    validated directory paths suitable for Vivado ``ip_repo_paths``.
    """
    from sdk.engine.ipxact_parser import parse_ipxact

    result = IpDiscoveryResult()

    for raw_path in ip_paths:
        ip_dir = (project_root / raw_path).resolve()
        if not ip_dir.is_dir():
            result.warnings.append(
                f"ip_paths entry '{raw_path}' does not exist or is not a directory"
            )
            continue

        result.ip_dirs.append(str(ip_dir))

        for cxml in ip_dir.rglob("component.xml"):
            try:
                parsed = parse_ipxact(cxml)
                meta = parsed.get("_meta", {})
                ip_info = parsed.get("ip", {})
                result.ips.append(
                    DiscoveredIp(
                        name=ip_info.get("name", cxml.parent.name),
                        vlnv=meta.get("vlnv", ""),
                        component_xml=cxml,
                        ip_dir=cxml.parent,
                    )
                )
            except (ET.ParseError, ValueError, KeyError, OSError):
                result.warnings.append(
                    f"Failed to parse {cxml} — skipping"
                )
                _log.debug("IP-XACT parse error for %s", cxml, exc_info=True)

    _log.info(
        "Discovered %d IPs in %d directories (%d warnings)",
        len(result.ips),
        len(result.ip_dirs),
        len(result.warnings),
    )
    return result
