# SPDX-FileCopyrightText: 2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Dummy IP stub generation for missing BD cells (RTL-P2.266).

When ``rr migrate`` reconstructs a Vivado Block Design and an IP is missing
from the catalog, this module generates minimal stub IPs with matching VLNV
and port names so downstream BD connections are preserved.

Three-step flow:
1. **Adaptation time** (Python): extract port/interface names from BD hook TCL
2. **Adaptation time** (Python): embed TCL proc + port info in adapted hook
3. **Runtime** (TCL): generate stub IPs and add to catalog in healing loop
"""

from __future__ import annotations

import re  # noqa: I001
from dataclasses import dataclass, field

# ── Port extraction from BD hook TCL ────────────────────────────────────────

@dataclass
class CellPortInfo:
    """Ports and interfaces extracted from a BD hook for a single cell."""

    ports: list[str] = field(default_factory=list)
    intfs: list[str] = field(default_factory=list)


# Patterns for BD connections:
#   connect_bd_net [get_bd_pins /cell_name/port_name] ...
#   connect_bd_intf_net ... [get_bd_intf_pins /cell_name/intf_name] ...
_PIN_PATTERN = re.compile(r"get_bd_pins\s+/?([^/\]]+)/([^/\]\s]+)")
_INTF_PATTERN = re.compile(r"get_bd_intf_pins\s+/?([^/\]]+)/([^/\]\s]+)")


def extract_cell_ports(lines: list[str]) -> dict[str, CellPortInfo]:
    """Scan BD hook TCL lines for port and interface references per cell.

    Returns a dict mapping cell names to their known ports/interfaces,
    extracted from ``connect_bd_net`` and ``connect_bd_intf_net`` commands.
    """
    cells: dict[str, CellPortInfo] = {}

    for line in lines:
        # Skip comments and healed lines
        stripped = line.strip()
        if stripped.startswith("#"):
            continue

        # Extract port pins
        for m in _PIN_PATTERN.finditer(line):
            cell_name = m.group(1)
            port_name = m.group(2)
            info = cells.setdefault(cell_name, CellPortInfo())
            if port_name not in info.ports:
                info.ports.append(port_name)

        # Extract interface pins
        for m in _INTF_PATTERN.finditer(line):
            cell_name = m.group(1)
            intf_name = m.group(2)
            info = cells.setdefault(cell_name, CellPortInfo())
            if intf_name not in info.intfs:
                info.intfs.append(intf_name)

    return cells


# ── Stub Verilog generation ─────────────────────────────────────────────────

# Port direction inference from naming conventions
_INPUT_PATTERNS = (
    re.compile(r"^(a?clk|clock)", re.IGNORECASE),
    re.compile(r"^(a?rst|a?resetn?|reset)", re.IGNORECASE),
    re.compile(r"^s\d*_", re.IGNORECASE),  # s0_, s_ (slave input side)
)

_OUTPUT_PATTERNS = (
    re.compile(r"^(irq|interrupt)", re.IGNORECASE),
)


def _infer_direction(port_name: str) -> str:
    """Infer port direction from naming conventions. Default: inout."""
    for pat in _INPUT_PATTERNS:
        if pat.match(port_name):
            return "input"
    for pat in _OUTPUT_PATTERNS:
        if pat.match(port_name):
            return "output"
    return "inout"


def generate_stub_verilog(module_name: str, ports: list[str]) -> str:
    """Generate a minimal Verilog stub module.

    All ports are single-bit wires. Directions are inferred from naming
    conventions. Vivado resolves actual widths during BD validation —
    we only need the port *names* to exist so ``connect_bd_*`` commands
    succeed.
    """
    # Sanitise module name for Verilog
    safe_name = re.sub(r"[^a-zA-Z0-9_]", "_", module_name)

    if not ports:
        # Minimal module with a dummy port (Vivado needs at least one)
        return (
            f"// Auto-generated stub by RouteRTL (P2.266)\n"
            f"// Do not edit — regenerate via rr migrate\n"
            f"module {safe_name} (\n"
            f"    input wire dummy_rr_stub\n"
            f");\n"
            f"endmodule\n"
        )

    lines = [
        "// Auto-generated stub by RouteRTL (P2.266)",
        "// Do not edit — regenerate via rr migrate",
        f"module {safe_name} (",
    ]

    # Port list
    port_decls = []
    for port in ports:
        direction = _infer_direction(port)
        port_decls.append(f"    {direction} wire {port}")

    lines.append(",\n".join(port_decls))
    lines.append(");")
    lines.append("endmodule")

    return "\n".join(lines) + "\n"


# ── TCL proc generation ────────────────────────────────────────────────────

def generate_dummy_ip_tcl_proc() -> str:
    r"""Return the ``_rr_gen_dummy_ip`` TCL proc for embedding in adapted hooks.

    The proc runs inside an existing Vivado session and:
    1. Creates a stub Verilog file
    2. Packages it with ipx\:\: commands (in-memory project)
    3. Sets VLNV to match the missing IP
    4. Saves component.xml
    """
    return '''\

# ── RouteRTL dummy IP generator (P2.266) ──
set _rr_failed_vlnvs [dict create]

proc _rr_gen_dummy_ip {vlnv stub_dir port_names} {
    # Parse VLNV
    set parts [split $vlnv :]
    if {[llength $parts] != 4} {
        puts "WARNING: RouteRTL — invalid VLNV for stub: $vlnv"
        return 0
    }
    set ip_vendor  [lindex $parts 0]
    set ip_library [lindex $parts 1]
    set ip_name    [lindex $parts 2]
    set ip_version [lindex $parts 3]

    # Strip wildcard from version if present (from _rr_resolve_vlnv)
    if {$ip_version eq "*"} { set ip_version "1.0" }

    set ip_dir "${stub_dir}/${ip_name}"

    # Skip if already generated
    if {[file exists "${ip_dir}/component.xml"]} {
        puts "INFO: RouteRTL — stub already exists: $ip_name"
        return 1
    }

    if {[catch {
        # Create stub directory
        file mkdir $ip_dir

        # Generate stub Verilog
        set safe_name [regsub -all {[^a-zA-Z0-9_]} $ip_name "_"]
        set vfile "${ip_dir}/${safe_name}.v"
        set fd [open $vfile w]
        puts $fd "// Auto-generated stub by RouteRTL (P2.266)"
        puts $fd "module ${safe_name} ("
        if {[llength $port_names] == 0} {
            puts $fd "    input wire dummy_rr_stub"
        } else {
            set port_lines [list]
            foreach p $port_names {
                # Infer direction from naming
                set dir "inout"
                set pl [string tolower $p]
                if {[regexp {^(a?clk|clock|a?rst|a?resetn?|reset)} $pl]} {
                    set dir "input"
                } elseif {[regexp {^(irq|interrupt)} $pl]} {
                    set dir "output"
                }
                lappend port_lines "    $dir wire $p"
            }
            puts $fd [join $port_lines ",\n"]
        }
        puts $fd ");"
        puts $fd "endmodule"
        close $fd

        # Get current project context
        set fpga_part [get_property PART [current_project]]
        set saved_proj [current_project]

        # Package in-memory
        create_project -in_memory -part $fpga_part rr_stub_pkg_${safe_name}
        add_files $vfile
        set_property file_type Verilog [get_files $vfile]

        ipx::package_project -root_dir $ip_dir -import_files
        set core [ipx::current_core]

        set_property -dict [list \
            vendor $ip_vendor \
            library $ip_library \
            name $ip_name \
            version $ip_version \
            display_name "RouteRTL stub: $ip_name" \
            description "Auto-generated stub for missing IP (P2.266)" \
        ] $core

        catch {ipx::remove_file_group xilinx_implementation $core}
        ipx::check_integrity $core
        ipx::save_core $core

        close_project
        current_project $saved_proj

        puts "INFO: RouteRTL — generated dummy stub: $vlnv -> $ip_dir"
    } gen_err]} {
        puts "WARNING: RouteRTL — stub generation failed for $vlnv: $gen_err"
        # Try to recover project context
        catch {close_project}
        catch {current_project $saved_proj}
        return 0
    }

    return 1
}
'''


def format_cell_ports_tcl(cell_ports: dict[str, CellPortInfo]) -> str:
    """Format extracted cell port info as a TCL array for embedding in hooks.

    Produces::

        array set _rr_cell_ports {
            cell_name {port1 port2 intf1 intf2}
            other_cell {portA portB}
        }
    """
    if not cell_ports:
        return "array set _rr_cell_ports {}\n"

    lines = ["array set _rr_cell_ports {"]
    for cell_name, info in cell_ports.items():
        # Combine ports and interfaces into a single flat list
        all_names = info.ports + info.intfs
        names_str = " ".join(all_names)
        lines.append(f"    {cell_name} {{{names_str}}}")
    lines.append("}")

    return "\n".join(lines) + "\n"
