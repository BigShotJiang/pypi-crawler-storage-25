# SPDX-FileCopyrightText: 2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""``@requires(REQ-N, ...)`` decorator for cocotb tests.

Attaches a ``__rr_requires__`` tuple of REQ IDs onto the decorated
function so ``rr sim coverage-map`` can walk cocotb tests and build a
REQ → tests matrix.  The decorator does not import cocotb and is
stdlib-only, so it remains cheap to import during test collection.

Use with ``requirements.yml`` → ``functional_contract[]`` IDs:

    from sdk.cocotb_helpers import requires

    @cocotb.test()
    @requires("REQ-1")
    async def test_sel_zero_routes_to_vdma(dut):
        ...

RTL-P2.405 / RTL-P2.398.
"""

from __future__ import annotations


def requires(*req_ids: str):
    """Return a decorator tagging *fn* with REQ anchors.

    Each ``req_id`` must be a string like ``"REQ-1"``; anything else is
    stored verbatim (coverage-map validates shape separately).
    """
    def _wrap(fn):
        fn.__rr_requires__ = tuple(req_ids)
        return fn

    return _wrap
