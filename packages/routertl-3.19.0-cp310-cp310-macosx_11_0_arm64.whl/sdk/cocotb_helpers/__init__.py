# SPDX-FileCopyrightText: 2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Cocotb helpers exported by routertl.

Separate package from ``cocotb`` itself — naming this ``cocotb_helpers``
(not ``sdk.cocotb``) avoids shadowing ``import cocotb`` on misordered
``PYTHONPATH`` layouts.

RTL-P2.405 / RTL-P2.398.
"""

from sdk.cocotb_helpers.requires import requires

__all__ = ["requires"]
