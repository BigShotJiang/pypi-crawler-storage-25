# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

# MIT License
#
# Copyright (c) 2024-2026 Daniel J. Mazure
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
# IN THE SOFTWARE.

import argparse
import json
import struct
from pathlib import Path

import yaml


def load_bin(path):
    """Load raw binary data from a file."""
    with open(path, "rb") as f:
        return f.read()


def load_hex(path):
    """Load hex-formatted words and return packed binary data."""
    words = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                word = int(line, 16)
                words.append(word)
    return b"".join(struct.pack("<I", word) for word in words)





def decode_raw_words(data):
    """Split binary data into a list of 32-bit LE words."""
    if len(data) % 4 != 0:
        raise ValueError("Raw data is not 4-byte aligned")
    return [struct.unpack("<I", data[i : i + 4])[0] for i in range(0, len(data), 4)]


def write_json(data, path):
    """Write a Python object as JSON to a file."""
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)






def decode_words_to_text(words, endian="little"):
    """Decode 32-bit words back to a UTF-8 string."""
    raw_bytes = b"".join(struct.pack("<I" if endian == "little" else ">I", word) for word in words)
    return raw_bytes.rstrip(b"\x00").decode("utf-8", errors="replace")


def main():
    """CLI entry point for the payload decoder."""
    parser = argparse.ArgumentParser(description="Decode register bank word data back to text/YAML")
    parser.add_argument("bin_file", help="Input binary or hex file")
    parser.add_argument(
        "--endian",
        choices=["little", "big"],
        default="little",
        help="Endian format for interpreting 32-bit words (default: little)",
    )
    parser.add_argument("--strip-padding", action="store_true", help="Strip trailing null bytes from output")
    parser.add_argument("--json", help="Write decoded data as JSON to this path")
    parser.add_argument("--yaml", help="Write decoded data as YAML to this path")
    parser.add_argument("--out", help="Write decoded text to this path")
    args = parser.parse_args()

    input_path = Path(args.bin_file)
    if input_path.suffix.lower() == ".hex":
        binary_data = load_hex(input_path)
    else:
        binary_data = load_bin(input_path)

    words = decode_raw_words(binary_data)
    text = decode_words_to_text(words, endian=args.endian)

    if args.json:
        decoded = yaml.safe_load(text)
        write_json(decoded, args.json)
        print(f"\u2705 Decoded JSON written to {args.json}")
    elif args.yaml:
        with open(args.yaml, "w", encoding="utf-8") as f:
            f.write(text)
        print(f"\u2705 Decoded YAML written to {args.yaml}")
    elif args.out:
        with open(args.out, "w", encoding="utf-8") as f:
            f.write(text)
        print(f"\u2705 Decoded text written to {args.out}")
    else:
        print("\n\ud83e\uddf6 Decoded text:")
        print(text)


if __name__ == "__main__":
    main()
