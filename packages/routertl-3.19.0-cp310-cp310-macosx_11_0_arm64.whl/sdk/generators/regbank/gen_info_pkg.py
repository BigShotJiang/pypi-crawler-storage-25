#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
DEPRECATED: Replaced by gen_build_metadata.py which generates rom_info_pkg
directly without the intermediate misc/rom.data file.
This script is kept for backward compatibility with external callers.
It will be removed in a future release.

Original: Python replacement for tcl/xilinx/gen_info_pkg.tcl.
Generates src/pkg/rom_info_pkg.vhd based on misc/rom.data and inputs.
"""

import argparse
import datetime
import os
import sys


def main():
    """CLI entry point for generating the ROM info VHDL package."""
    parser = argparse.ArgumentParser(description="Generate rom_info_pkg.vhd")
    parser.add_argument("root_dir", help="Root directory of the project")
    parser.add_argument("manifest_file", help="Path to the regbank manifest file")
    parser.add_argument("config_file", help="Path to the config file")
    parser.add_argument("--lock-hex", default=None, help="Path to the lock hex file")

    args = parser.parse_args()

    root_dir = os.path.abspath(args.root_dir)
    manifest_file_abs = os.path.abspath(args.manifest_file)
    config_file_abs = os.path.abspath(args.config_file)
    lock_hex_abs = os.path.abspath(args.lock_hex) if args.lock_hex else ""

    print(f"Root dir is  {root_dir}")

    # Read misc/rom.data
    rom_data_path = os.path.join(root_dir, "misc", "rom.data")
    if not os.path.exists(rom_data_path):
        print(f"Error: {rom_data_path} does not exist.")
        sys.exit(1)

    try:
        with open(rom_data_path, "r") as f:
            lines = [line.strip() for line in f.readlines()]
            if len(lines) < 6:
                print(f"Error: {rom_data_path} has insufficient lines.")
                sys.exit(1)

            c_build_date = lines[0]
            c_git_hash = lines[1]
            c_system_version = lines[2]
            c_regbank_version = lines[3]
            c_regbank_words = lines[4]
            c_config_words = lines[5]
            c_lock_words = lines[6] if len(lines) > 6 else "00000000"

    except OSError as e:
        print(f"Error reading {rom_data_path}: {e}")
        sys.exit(1)

    # Calculate integer values for display (mimicking TCL 'scan %x')
    try:
        v_regbank_words = int(c_regbank_words, 16)
        v_config_words = int(c_config_words, 16)
        v_lock_words = int(c_lock_words, 16)
    except ValueError:
        v_regbank_words = 0
        v_config_words = 0
        v_lock_words = 0

    print(f"Git Hash Hex value: {c_git_hash}")
    print(f"Build Date: {c_build_date}")

    pkg_name = "rom_info_pkg"
    pkg_file_path = os.path.join(root_dir, "src", "pkg", f"{pkg_name}.vhd")

    now = datetime.datetime.now()
    # Format time as HH:MM:SS
    # time_str = now.strftime("%H:%M:%S")
    # In TCL script it also puts full date in a comment: -- File created @[clock format [clock seconds]] (default format)
    # TCL default format is usually like "Wed Jan 16 18:14:42 CET 2026"
    full_date_str = now.ctime()

    content = []
    content.append("-- Tich (c) " + str(now.year))
    content.append(f"-- File created @{full_date_str}")
    content.append("-- This file was created automatically by the gen_info_pkg python script")
    content.append("")
    content.append("library IEEE;")
    content.append("use IEEE.STD_LOGIC_1164.all;")
    content.append("use IEEE.NUMERIC_STD.all;")
    content.append("use IEEE.MATH_REAL.all;")
    content.append("")
    content.append(f"package {pkg_name} is")
    content.append("")

    # Constants
    c_rom_data_width = 32

    content.append(f"  constant C_ROM_DATA_WIDTH  : integer  := {c_rom_data_width};")
    content.append(f'  constant C_GIT_HASH        : std_logic_vector(C_ROM_DATA_WIDTH-1 downto 0) := x"{c_git_hash}";')
    content.append(
        f'  constant C_SYSTEM_VERSION  : std_logic_vector(C_ROM_DATA_WIDTH-1 downto 0) := x"{c_system_version}";'
    )
    content.append(
        f'  constant C_BUILD_DATE      : std_logic_vector(C_ROM_DATA_WIDTH-1 downto 0) := x"{c_build_date}";'
    )
    content.append(
        f'  constant C_REGBANK_VERSION : std_logic_vector(C_ROM_DATA_WIDTH-1 downto 0) := x"{c_regbank_version}";'
    )
    content.append(
        f'  constant C_REGBANK_WORDS   : std_logic_vector(C_ROM_DATA_WIDTH-1 downto 0) := x"{c_regbank_words}"; -- {v_regbank_words} words'
    )
    content.append(
        f'  constant C_CONFIG_WORDS    : std_logic_vector(C_ROM_DATA_WIDTH-1 downto 0) := x"{c_config_words}"; -- {v_config_words} words'
    )
    content.append(
        f'  constant C_LOCK_WORDS     : std_logic_vector(C_ROM_DATA_WIDTH-1 downto 0) := x"{c_lock_words}"; -- {v_lock_words} words'
    )
    content.append(f'  constant C_REGBANK_HEX     : string := "{manifest_file_abs}";')
    content.append(f'  constant C_CONFIG_HEX      : string := "{config_file_abs}";')
    if lock_hex_abs:
        content.append(f'  constant C_LOCK_HEX        : string := "{lock_hex_abs}";')
    else:
        content.append('  constant C_LOCK_HEX        : string := "";')
    content.append("")
    content.append(f"end package {pkg_name};")
    content.append("")
    content.append(f"package body {pkg_name} is")
    content.append("")
    content.append(f"end {pkg_name};")
    content.append("")

    # Ensure existence of directory
    os.makedirs(os.path.dirname(pkg_file_path), exist_ok=True)

    try:
        with open(pkg_file_path, "w") as f:
            f.write("\n".join(content))
        print(f"Generated {pkg_file_path}")
    except OSError as e:
        print(f"Error writing to {pkg_file_path}: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
