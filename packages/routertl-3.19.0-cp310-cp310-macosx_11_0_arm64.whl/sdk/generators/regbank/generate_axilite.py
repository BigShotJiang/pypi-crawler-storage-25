# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
Generate a synthesizable AXI4-Lite register file from regbank_schema.yml.

Modeled on the proven sonova ``ssi_regbank.vhd`` architecture:
- ``t_memArrayReg`` record interface (REGS_IN / REGS_OUT)
- ``C_ROM_REGS`` / ``C_READ_ONLY`` mask vectors from system_regbank_pkg
- ``C_INIT_REGBANK`` ROM pre-load
- Pipelined reset for high-fanout mitigation
"""

from __future__ import annotations

import argparse
from datetime import datetime
from math import ceil, log2
from pathlib import Path

from sdk.generators.regbank.regbank_parser import RegbankSchema, load_schema


def _addr_width(schema: RegbankSchema) -> int:
    """Minimum address width to cover all registers (byte-addressed)."""
    if not schema.registers:
        return 4
    max_byte = schema.max_address * 4 + 4
    return max(4, int(ceil(log2(max_byte))) if max_byte > 1 else 4)


def generate_axilite(schema: RegbankSchema, *, library: str = "work") -> str:
    """Return a VHDL string for an AXI-Lite register file entity."""
    today = datetime.now().strftime("%Y-%m-%d")
    n_regs = schema.max_address + 1 if schema.registers else 1
    depth_bits = int(ceil(log2(n_regs))) if n_regs > 1 else 1
    addr_w = _addr_width(schema)

    lines: list[str] = []
    a = lines.append

    # ── Header ────────────────────────────────────────────────────
    a(f"-- Auto-generated AXI-Lite register file — {today}")
    a("-- Source: regbank_schema.yml  •  Generator: RouteRTL SDK")
    a("-- DO NOT EDIT — regenerate with `rr regbank axilite`")
    a("")
    a("library IEEE;")
    a("use IEEE.STD_LOGIC_1164.all;")
    a("use IEEE.NUMERIC_STD.all;")
    a(f"library {library};")
    a(f"use {library}.system_regbank_pkg.all;")
    a("")

    # ── Entity ────────────────────────────────────────────────────
    a("entity axilite_regbank is")
    a("  generic (")
    a(f"    G_ADDR_WIDTH : integer := {addr_w};")
    a("    G_DATA_WIDTH : integer := 32")
    a("  );")
    a("  port (")
    a("    CLK           : in  std_logic;")
    a("    RST           : in  std_logic;")
    a("")
    a("    -- AXI4-Lite Slave Interface")
    a("    S_AXI_AWADDR  : in  std_logic_vector(G_ADDR_WIDTH-1 downto 0);")
    a("    S_AXI_AWPROT  : in  std_logic_vector(2 downto 0);")
    a("    S_AXI_AWVALID : in  std_logic;")
    a("    S_AXI_AWREADY : out std_logic;")
    a("")
    a("    S_AXI_WDATA   : in  std_logic_vector(G_DATA_WIDTH-1 downto 0);")
    a("    S_AXI_WSTRB   : in  std_logic_vector(G_DATA_WIDTH/8-1 downto 0);")
    a("    S_AXI_WVALID  : in  std_logic;")
    a("    S_AXI_WREADY  : out std_logic;")
    a("")
    a("    S_AXI_BRESP   : out std_logic_vector(1 downto 0);")
    a("    S_AXI_BVALID  : out std_logic;")
    a("    S_AXI_BREADY  : in  std_logic;")
    a("")
    a("    S_AXI_ARADDR  : in  std_logic_vector(G_ADDR_WIDTH-1 downto 0);")
    a("    S_AXI_ARPROT  : in  std_logic_vector(2 downto 0);")
    a("    S_AXI_ARVALID : in  std_logic;")
    a("    S_AXI_ARREADY : out std_logic;")
    a("")
    a("    S_AXI_RDATA   : out std_logic_vector(G_DATA_WIDTH-1 downto 0);")
    a("    S_AXI_RRESP   : out std_logic_vector(1 downto 0);")
    a("    S_AXI_RVALID  : out std_logic;")
    a("    S_AXI_RREADY  : in  std_logic;")
    a("")
    a("    -- User logic record interface (sonova pattern)")
    a("    REGS_IN       : in  t_memArrayReg;")
    a("    REGS_OUT      : out t_memArrayReg")
    a("  );")
    a("end entity axilite_regbank;")
    a("")

    # ── Architecture ──────────────────────────────────────────────
    a("architecture rtl of axilite_regbank is")
    a("")
    a("  constant C_ADDR_LSB  : integer := 2;  -- byte-to-word conversion")
    a("  constant C_DEPTH     : integer := C_REGBANK_DEPTH;")
    a("")
    a("  -- Pipelined reset (high-fanout mitigation, from sonova pattern)")
    a("  constant C_RST_PIPE_STAGES : integer := 4;")
    a("  signal rst_pipe : std_logic_vector(C_RST_PIPE_STAGES-1 downto 0) := (others => '1');")
    a("")
    a("  -- Register storage")
    a("  signal reg_bank : t_memArray := C_INIT_REGBANK;")
    a("")
    a("  -- AXI handshake state")
    a("  signal aw_ready_r : std_logic := '0';")
    a("  signal w_ready_r  : std_logic := '0';")
    a("  signal b_valid_r  : std_logic := '0';")
    a("  signal ar_ready_r : std_logic := '0';")
    a("  signal r_valid_r  : std_logic := '0';")
    a("  signal r_data_r   : std_logic_vector(G_DATA_WIDTH-1 downto 0) := (others => '0');")
    a("")
    a("  -- Latched write address / read address")
    a("  signal aw_addr_r  : unsigned(G_ADDR_WIDTH-1 downto 0) := (others => '0');")
    a("  signal ar_addr_r  : unsigned(G_ADDR_WIDTH-1 downto 0) := (others => '0');")
    a("")
    a("  -- Valid propagation (sonova pattern)")
    a("  signal valid_r  : std_logic_vector(2**C_DEPTH-1 downto 0) := (others => '0');")
    a("  signal valid_r2 : std_logic_vector(2**C_DEPTH-1 downto 0) := (others => '0');")
    a("")
    a("begin")
    a("")
    a("  -- Reset pipeline")
    a("  rst_pipe <= rst_pipe(C_RST_PIPE_STAGES-2 downto 0) & RST when rising_edge(CLK);")
    a("")

    # ── Write address channel ─────────────────────────────────────
    a("  -- Write address channel")
    a("  P_AW : process(CLK)")
    a("  begin")
    a("    if rising_edge(CLK) then")
    a("      if rst_pipe(C_RST_PIPE_STAGES-1) = '1' then")
    a("        aw_ready_r <= '0';")
    a("      elsif aw_ready_r = '0' and S_AXI_AWVALID = '1' and S_AXI_WVALID = '1' then")
    a("        aw_ready_r <= '1';")
    a("        aw_addr_r  <= unsigned(S_AXI_AWADDR);")
    a("      else")
    a("        aw_ready_r <= '0';")
    a("      end if;")
    a("    end if;")
    a("  end process;")
    a("  S_AXI_AWREADY <= aw_ready_r;")
    a("")

    # ── Write data channel ────────────────────────────────────────
    a("  -- Write data channel")
    a("  P_W : process(CLK)")
    a("  begin")
    a("    if rising_edge(CLK) then")
    a("      if rst_pipe(C_RST_PIPE_STAGES-1) = '1' then")
    a("        w_ready_r <= '0';")
    a("      elsif w_ready_r = '0' and S_AXI_AWVALID = '1' and S_AXI_WVALID = '1' then")
    a("        w_ready_r <= '1';")
    a("      else")
    a("        w_ready_r <= '0';")
    a("      end if;")
    a("    end if;")
    a("  end process;")
    a("  S_AXI_WREADY <= w_ready_r;")
    a("")

    # ── Register write logic ──────────────────────────────────────
    a("  -- Register write logic (respects C_READ_ONLY mask)")
    a("  P_REG_WR : process(CLK)")
    a("    variable v_index : integer;")
    a("  begin")
    a("    if rising_edge(CLK) then")
    a("      valid_r  <= (others => '0');")
    a("      valid_r2 <= valid_r;")
    a("      if aw_ready_r = '1' and w_ready_r = '1' then")
    a("        v_index := to_integer(aw_addr_r(G_ADDR_WIDTH-1 downto C_ADDR_LSB));")
    a("        if v_index < C_NUM_USER_REGS and C_READ_ONLY(v_index) = '0' then")
    a("          -- Byte-lane strobing")
    a("          for byte_i in 0 to G_DATA_WIDTH/8-1 loop")
    a("            if S_AXI_WSTRB(byte_i) = '1' then")
    a("              reg_bank(v_index)(byte_i*8+7 downto byte_i*8) <=")
    a("                S_AXI_WDATA(byte_i*8+7 downto byte_i*8);")
    a("            end if;")
    a("          end loop;")
    a("          valid_r(v_index) <= '1';")
    a("        end if;")
    a("      end if;")
    a("      -- FPGA-side writes (REGS_IN, sonova pattern)")
    a("      for i in 0 to C_NUM_USER_REGS-1 loop")
    a("        if REGS_IN(i).valid = '1' and C_ROM_REGS(i) = '0' then")
    a("          reg_bank(i) <= REGS_IN(i).data;")
    a("          valid_r(i)  <= '1';")
    a("        end if;")
    a("      end loop;")
    a("      -- Reset (pipelined)")
    a("      if rst_pipe(C_RST_PIPE_STAGES-1) = '1' then")
    a("        for i in 0 to C_NUM_USER_REGS-1 loop")
    a("          if C_ROM_REGS(i) = '0' then")
    a("            reg_bank(i) <= (others => '0');")
    a("          end if;")
    a("        end loop;")
    a("      end if;")
    a("    end if;")
    a("  end process;")
    a("")

    # ── Write response channel ────────────────────────────────────
    a("  -- Write response")
    a("  P_B : process(CLK)")
    a("  begin")
    a("    if rising_edge(CLK) then")
    a("      if rst_pipe(C_RST_PIPE_STAGES-1) = '1' then")
    a("        b_valid_r <= '0';")
    a("      elsif aw_ready_r = '1' and w_ready_r = '1' and b_valid_r = '0' then")
    a("        b_valid_r <= '1';")
    a("      elsif S_AXI_BREADY = '1' and b_valid_r = '1' then")
    a("        b_valid_r <= '0';")
    a("      end if;")
    a("    end if;")
    a("  end process;")
    a("  S_AXI_BVALID <= b_valid_r;")
    a('  S_AXI_BRESP  <= "00";  -- OKAY')
    a("")

    # ── Read address channel ──────────────────────────────────────
    a("  -- Read address channel")
    a("  P_AR : process(CLK)")
    a("  begin")
    a("    if rising_edge(CLK) then")
    a("      if rst_pipe(C_RST_PIPE_STAGES-1) = '1' then")
    a("        ar_ready_r <= '0';")
    a("      elsif ar_ready_r = '0' and S_AXI_ARVALID = '1' then")
    a("        ar_ready_r <= '1';")
    a("        ar_addr_r  <= unsigned(S_AXI_ARADDR);")
    a("      else")
    a("        ar_ready_r <= '0';")
    a("      end if;")
    a("    end if;")
    a("  end process;")
    a("  S_AXI_ARREADY <= ar_ready_r;")
    a("")

    # ── Read data channel ─────────────────────────────────────────
    a("  -- Read data channel")
    a("  P_RD : process(CLK)")
    a("    variable v_index : integer;")
    a("  begin")
    a("    if rising_edge(CLK) then")
    a("      if rst_pipe(C_RST_PIPE_STAGES-1) = '1' then")
    a("        r_valid_r <= '0';")
    a("        r_data_r  <= (others => '0');")
    a("      elsif ar_ready_r = '1' and S_AXI_ARVALID = '1' and r_valid_r = '0' then")
    a("        r_valid_r <= '1';")
    a("        v_index := to_integer(ar_addr_r(G_ADDR_WIDTH-1 downto C_ADDR_LSB));")
    a("        if v_index < C_NUM_USER_REGS then")
    a("          r_data_r <= reg_bank(v_index);")
    a("        else")
    a("          r_data_r <= (others => '0');")
    a("        end if;")
    a("      elsif S_AXI_RREADY = '1' and r_valid_r = '1' then")
    a("        r_valid_r <= '0';")
    a("      end if;")
    a("    end if;")
    a("  end process;")
    a("  S_AXI_RVALID <= r_valid_r;")
    a("  S_AXI_RDATA  <= r_data_r;")
    a('  S_AXI_RRESP  <= "00";  -- OKAY')
    a("")

    # ── Expose registers to user logic ────────────────────────────
    a("  -- Expose registers to user logic (sonova pattern)")
    a("  GEN_REGS_OUT : for i in 0 to C_NUM_USER_REGS-1 generate")
    a("    REGS_OUT(i).data  <= reg_bank(i);")
    a("    REGS_OUT(i).valid <= valid_r2(i);")
    a("  end generate GEN_REGS_OUT;")
    a("")
    a("end architecture rtl;")
    a("")

    return "\n".join(lines)


def write_axilite(schema: RegbankSchema, output: Path, *, library: str = "work") -> None:
    """Generate and write the AXI-Lite register file."""
    content = generate_axilite(schema, library=library)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(content, encoding="utf-8")
    print(f"✅ Generated AXI-Lite register file: {output}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Generate AXI-Lite register file from regbank YAML.")
    parser.add_argument("yaml_file", help="Input YAML register schema")
    parser.add_argument("-o", "--output", default="axilite_regbank.vhd", help="Output VHDL file")
    parser.add_argument("-l", "--library", default="work", help="VHDL library name")
    args = parser.parse_args()

    schema = load_schema(args.yaml_file)
    write_axilite(schema, Path(args.output), library=args.library)
