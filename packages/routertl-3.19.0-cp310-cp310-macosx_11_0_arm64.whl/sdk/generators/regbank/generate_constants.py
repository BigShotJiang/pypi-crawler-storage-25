# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

# MIT License
#
# Copyright (c) 2024-2026 Daniel J. Mazure
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
# IN THE SOFTWARE.

import argparse
import os

import yaml


def yaml_to_python_constants(manifest):
    """Convert a YAML register map to Python constant definitions."""
    lines = ["# Auto-generated from register map\n"]
    for reg in manifest["registers"]:
        name = reg["name"].upper().replace(" ", "_")
        addr_raw = reg["address"]
        addr = int(addr_raw, 16) if isinstance(addr_raw, str) and addr_raw.startswith("0x") else int(addr_raw)
        lines.append(f"C_INDEX_{name} = {addr}")
    return "\n".join(lines)


def main():
    """CLI entry point for generating Python constants."""
    parser = argparse.ArgumentParser()
    parser.add_argument("yaml_file", help="Input YAML file")
    parser.add_argument("output_py", help="Output Python constants file")
    args = parser.parse_args()

    if not os.path.exists(args.yaml_file):
        print(f"ℹ️  YAML file {args.yaml_file} not found. Generating empty constants.")
        manifest = {"registers": []}
    else:
        with open(args.yaml_file, "r") as f:
            manifest = yaml.safe_load(f)

    py_constants = yaml_to_python_constants(manifest)

    os.makedirs(os.path.dirname(args.output_py), exist_ok=True)
    with open(args.output_py, "w") as f:
        f.write(py_constants + "\n")

    print(f"✅ Constants written to {args.output_py}")


if __name__ == "__main__":
    main()
