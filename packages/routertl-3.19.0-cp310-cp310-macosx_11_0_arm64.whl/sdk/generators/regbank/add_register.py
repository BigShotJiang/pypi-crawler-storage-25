# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

# MIT License
#
# Copyright (c) 2024-2026 Daniel J. Mazure
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
# IN THE SOFTWARE.

import shutil
import sys

import yaml


def interactive_register_entry():
    """Interactively prompt user for new register fields."""
    print("🔧 Adding new register to schema...\n")

    name = input("Name? ").strip().upper()
    address = input("Address (e.g. 0x80 or 128)? ").strip()
    access = input("Access mode? (ro/rw/wo) [default: ro] ").strip().lower() or "ro"
    description = input("Description? ").strip()
    format = input("Format? ").strip()

    fields = []
    add_fields = input("Add fields? (y/n) ").strip().lower() == "y"
    while add_fields:
        field = {}
        field["name"] = input("  Field name? ").strip()
        bits_raw = input("  Bits (single or MSB:LSB)? ").strip()
        if ":" in bits_raw:
            msb, lsb = map(int, bits_raw.split(":"))
            field["bits"] = [msb, lsb]
        else:
            field["bits"] = [int(bits_raw)]

        enum_add = input("  Add enum values? (y/n) ").strip().lower()
        if enum_add == "y":
            enum = {}
            while True:
                k = input("    Enum key (or ENTER to finish): ").strip()
                if not k:
                    break
                v = input("    Enum value description: ").strip()
                enum[int(k)] = v
            field["enum"] = enum

        fields.append(field)
        add_fields = input("  Add another field? (y/n) ").strip().lower() == "y"

    entry = {
        "name": name,
        "address": address,
        "access": access,
        "description": description,
        "format": format,
    }
    if fields:
        entry["fields"] = fields
    return entry


def parse_address_field(val):
    """Parse an address string into an integer."""
    if isinstance(val, int):
        return val
    val_str = str(val)
    return int(val_str, 16) if val_str.startswith("0x") else int(val_str)


def insert_and_save(schema_path, new_entry, append_mode=False):
    """Insert a new register at the correct position and save YAML."""
    with open(schema_path, "r") as f:
        data = yaml.safe_load(f)

    addr = parse_address_field(new_entry["address"])
    word_index = addr
    new_entry["address"] = word_index

    entries = data["registers"]

    if not append_mode:
        print(f"📥 Inserting at address 0x{addr:X} (word index {word_index}) — shifting entries above")
        for reg in entries:
            reg_addr = parse_address_field(reg["address"])
            if reg_addr >= word_index:
                reg["address"] = reg_addr + 1
        print("🔃 Address shift complete.")
    else:
        print("➕ Append mode enabled — no address shifting")

    entries.append(new_entry)
    entries.sort(key=lambda r: parse_address_field(r["address"]))

    backup_path = schema_path + ".bak"
    shutil.copy(schema_path, backup_path)

    with open(schema_path, "w") as f:
        yaml.dump(data, f, sort_keys=False)

    print(f"✅ Entry saved at 0x{word_index * 4:02X}")
    print(f"💾 Saved to {schema_path} (backup: {backup_path})")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python add_register.py <schema.yml> [--append]")
        sys.exit(1)

    schema_file = sys.argv[1]
    append_flag = "--append" in sys.argv
    entry = interactive_register_entry()
    insert_and_save(schema_file, entry, append_mode=append_flag)
