# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
Generate a self-contained HTML register documentation page from regbank_schema.yml.

Features:
- Dark-themed styling (RouteRTL brand)
- Sortable register table
- Expandable field detail rows with enum values
- Telemetry counter tagging (📊 badge)
"""

from __future__ import annotations

import argparse
import html as html_mod
from datetime import datetime
from pathlib import Path

from sdk.generators.regbank.regbank_parser import RegbankSchema, Register, load_schema

# Keywords that identify telemetry/observability counters
_TELEMETRY_KEYWORDS = {
    "heartbeat", "overflow", "watermark", "telemetry",
    "pkt_cnt", "err_cnt", "drop_cnt", "arb_grant",
    "counter", "snapshot",
}


def _is_telemetry(reg: Register) -> bool:
    """Heuristic: does this register look like a telemetry counter?"""
    name_lower = reg.name.lower()
    desc_lower = reg.description.lower()
    return any(kw in name_lower or kw in desc_lower for kw in _TELEMETRY_KEYWORDS)


def _access_badge(access: str) -> str:
    """Return an HTML badge for the access type."""
    colors = {
        "rom": ("#a78bfa", "#1e1b4b"),  # purple
        "ro": ("#60a5fa", "#1e3a5f"),   # blue
        "rw": ("#34d399", "#064e3b"),   # green
    }
    bg, border = colors.get(access, ("#9ca3af", "#374151"))
    return (
        f'<span style="background:{bg}; color:#111; padding:2px 8px; '
        f'border-radius:4px; font-weight:600; font-size:0.85em;">'
        f'{html_mod.escape(access.upper())}</span>'
    )


def _field_rows(reg: Register) -> str:
    """Generate HTML rows for a register's fields."""
    if not reg.fields:
        return ""
    rows: list[str] = []
    for f in reg.fields:
        bits_str = ""
        if len(f.bits) == 2:
            bits_str = f"[{f.bits[0]}:{f.bits[1]}]"
        elif len(f.bits) == 1:
            bits_str = f"[{f.bits[0]}]"

        enum_html = ""
        if f.enum:
            items = ", ".join(f"{k}: {v}" for k, v in sorted(f.enum.items()))
            enum_html = f'<div class="enum">{html_mod.escape(items)}</div>'

        desc = html_mod.escape(f.description) if f.description else ""
        rows.append(
            f'<tr class="field-row">'
            f'<td class="field-indent">↳ <code>{html_mod.escape(f.name)}</code></td>'
            f'<td>{bits_str}</td>'
            f'<td>{desc}{enum_html}</td>'
            f'</tr>'
        )
    return "\n".join(rows)


def generate_html(schema: RegbankSchema) -> str:
    """Generate a self-contained HTML page documenting all registers."""
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    n_rom = sum(1 for r in schema.registers if r.is_rom)
    n_ro = sum(1 for r in schema.registers if r.access == "ro")
    n_rw = sum(1 for r in schema.registers if r.is_read_write)
    n_tel = sum(1 for r in schema.registers if _is_telemetry(r))

    # ── Build table rows ──────────────────────────────────────────
    table_rows: list[str] = []
    for reg in schema.registers:
        tel_badge = ' <span class="tel-badge" title="Telemetry counter">📊</span>' if _is_telemetry(reg) else ""
        row = (
            f'<tr class="reg-row" data-access="{reg.access}">'
            f'<td><code>{html_mod.escape(reg.name)}</code>{tel_badge}</td>'
            f'<td class="addr">{reg.address}</td>'
            f'<td class="addr">0x{reg.byte_offset:04X}</td>'
            f'<td>{_access_badge(reg.access)}</td>'
            f'<td>{html_mod.escape(reg.description)}</td>'
            f'</tr>'
        )
        table_rows.append(row)
        field_html = _field_rows(reg)
        if field_html:
            table_rows.append(field_html)

    body_rows = "\n".join(table_rows)

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Register Bank Documentation — v{html_mod.escape(schema.version)}</title>
<style>
  * {{ margin: 0; padding: 0; box-sizing: border-box; }}
  body {{
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
    background: #0f0f14;
    color: #e4e4e7;
    padding: 2rem;
    line-height: 1.6;
  }}
  h1 {{
    font-size: 1.8rem;
    color: #a78bfa;
    margin-bottom: 0.5rem;
  }}
  .meta {{
    color: #71717a;
    font-size: 0.9rem;
    margin-bottom: 1.5rem;
  }}
  .stats {{
    display: flex;
    gap: 1.5rem;
    margin-bottom: 2rem;
    flex-wrap: wrap;
  }}
  .stat-card {{
    background: #18181b;
    border: 1px solid #27272a;
    border-radius: 8px;
    padding: 1rem 1.5rem;
    min-width: 120px;
    text-align: center;
  }}
  .stat-card .value {{
    font-size: 2rem;
    font-weight: 700;
    color: #a78bfa;
  }}
  .stat-card .label {{
    font-size: 0.85rem;
    color: #71717a;
    text-transform: uppercase;
    letter-spacing: 0.05em;
  }}
  table {{
    width: 100%;
    border-collapse: collapse;
    background: #18181b;
    border-radius: 8px;
    overflow: hidden;
  }}
  th {{
    background: #1e1e24;
    color: #a78bfa;
    text-align: left;
    padding: 0.75rem 1rem;
    font-size: 0.85rem;
    text-transform: uppercase;
    letter-spacing: 0.05em;
    border-bottom: 2px solid #27272a;
    cursor: pointer;
    user-select: none;
  }}
  th:hover {{ color: #c4b5fd; }}
  td {{
    padding: 0.6rem 1rem;
    border-bottom: 1px solid #27272a;
    vertical-align: top;
  }}
  .addr {{ font-family: 'JetBrains Mono', monospace; color: #60a5fa; }}
  code {{
    font-family: 'JetBrains Mono', monospace;
    background: #27272a;
    padding: 2px 6px;
    border-radius: 3px;
    font-size: 0.9em;
  }}
  .reg-row:hover {{ background: #1e1e28; }}
  .field-row td {{
    padding-left: 2.5rem;
    color: #a1a1aa;
    font-size: 0.9em;
    background: #141418;
  }}
  .field-indent {{ padding-left: 2.5rem !important; }}
  .enum {{
    margin-top: 4px;
    color: #fbbf24;
    font-size: 0.85em;
    font-style: italic;
  }}
  .tel-badge {{
    font-size: 0.9em;
    margin-left: 4px;
    cursor: help;
  }}
  .filter-bar {{
    margin-bottom: 1rem;
    display: flex;
    gap: 0.5rem;
    flex-wrap: wrap;
  }}
  .filter-btn {{
    background: #27272a;
    color: #e4e4e7;
    border: 1px solid #3f3f46;
    padding: 4px 12px;
    border-radius: 6px;
    cursor: pointer;
    font-size: 0.85rem;
  }}
  .filter-btn:hover, .filter-btn.active {{
    background: #a78bfa;
    color: #111;
    border-color: #a78bfa;
  }}
  input[type="search"] {{
    background: #27272a;
    color: #e4e4e7;
    border: 1px solid #3f3f46;
    padding: 6px 12px;
    border-radius: 6px;
    font-size: 0.9rem;
    width: 250px;
  }}
  input[type="search"]::placeholder {{ color: #71717a; }}
  footer {{
    margin-top: 2rem;
    color: #52525b;
    font-size: 0.8rem;
    text-align: center;
  }}
</style>
</head>
<body>

<h1>📋 Register Bank Documentation</h1>
<div class="meta">
  Version <strong>{html_mod.escape(schema.version)}</strong> &middot;
  {len(schema.registers)} registers &middot;
  Generated {html_mod.escape(now)} &middot;
  RouteRTL SDK
</div>

<div class="stats">
  <div class="stat-card"><div class="value">{len(schema.registers)}</div><div class="label">Registers</div></div>
  <div class="stat-card"><div class="value">{n_rom}</div><div class="label">ROM</div></div>
  <div class="stat-card"><div class="value">{n_ro}</div><div class="label">Read-Only</div></div>
  <div class="stat-card"><div class="value">{n_rw}</div><div class="label">Read-Write</div></div>
  <div class="stat-card"><div class="value">{n_tel}</div><div class="label">📊 Telemetry</div></div>
</div>

<div class="filter-bar">
  <input type="search" id="searchBox" placeholder="Search registers..." oninput="filterTable()">
  <button class="filter-btn active" onclick="filterAccess('all', this)">All</button>
  <button class="filter-btn" onclick="filterAccess('rom', this)">ROM</button>
  <button class="filter-btn" onclick="filterAccess('ro', this)">RO</button>
  <button class="filter-btn" onclick="filterAccess('rw', this)">RW</button>
</div>

<table id="regTable">
<thead>
  <tr>
    <th onclick="sortTable(0)">Name</th>
    <th onclick="sortTable(1)">Addr</th>
    <th onclick="sortTable(2)">Offset</th>
    <th onclick="sortTable(3)">Access</th>
    <th>Description</th>
  </tr>
</thead>
<tbody>
{body_rows}
</tbody>
</table>

<footer>
  RouteRTL SDK — Register Bank Documentation Generator &middot;
  <a href="https://github.com/routertl" style="color:#a78bfa;">github.com/routertl</a>
</footer>

<script>
let currentFilter = 'all';

function filterTable() {{
  const q = document.getElementById('searchBox').value.toLowerCase();
  const rows = document.querySelectorAll('#regTable tbody tr');
  rows.forEach(r => {{
    const isField = r.classList.contains('field-row');
    const access = r.getAttribute('data-access') || '';
    const text = r.textContent.toLowerCase();
    const matchSearch = !q || text.includes(q);
    const matchFilter = currentFilter === 'all' || access === currentFilter || isField;
    r.style.display = (matchSearch && matchFilter) ? '' : 'none';
  }});
}}

function filterAccess(access, btn) {{
  currentFilter = access;
  document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  filterTable();
}}

function sortTable(col) {{
  const tbody = document.querySelector('#regTable tbody');
  const rows = Array.from(tbody.querySelectorAll('tr.reg-row'));
  const asc = tbody.getAttribute('data-sort-asc') !== 'true';
  tbody.setAttribute('data-sort-asc', asc);
  rows.sort((a, b) => {{
    let va = a.cells[col].textContent.trim();
    let vb = b.cells[col].textContent.trim();
    if (!isNaN(va) && !isNaN(vb)) return asc ? va - vb : vb - va;
    return asc ? va.localeCompare(vb) : vb.localeCompare(va);
  }});
  // Re-insert rows with their field rows
  rows.forEach(r => {{
    tbody.appendChild(r);
    let next = r.nextElementSibling;
    while (next && next.classList.contains('field-row')) {{
      let fn = next.nextElementSibling;
      tbody.appendChild(next);
      next = fn;
    }}
  }});
}}
</script>
</body>
</html>
"""


def write_html(schema: RegbankSchema, output: Path) -> None:
    """Generate and write the HTML documentation page."""
    content = generate_html(schema)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(content, encoding="utf-8")
    print(f"✅ Generated HTML register documentation: {output}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Generate HTML register docs from regbank YAML.")
    parser.add_argument("yaml_file", help="Input YAML register schema")
    parser.add_argument("-o", "--output", default="register_bank.html", help="Output HTML file")
    args = parser.parse_args()

    schema = load_schema(args.yaml_file)
    write_html(schema, Path(args.output))
