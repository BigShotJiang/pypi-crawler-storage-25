# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

# MIT License
#
# Copyright (c) 2024-2026 Daniel J. Mazure
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
# IN THE SOFTWARE.

import argparse
from pathlib import Path

import yaml


def generate_markdown(yaml_path: Path, output_path: Path):
    """Generate a markdown register map table from YAML schema data."""
    with open(yaml_path, "r") as f:
        data = yaml.safe_load(f)

    registers = data.get("registers", [])

    md_lines = [
        f"# Register Bank Documentation (v{data.get('version')})",
        "",
        "| Name | Address | Access | Description | Format | Fields |",
        "|------|---------|--------|-------------|--------|--------|",
    ]

    for reg in registers:
        name = reg.get("name", "")
        address = str(reg.get("address"))
        access = reg.get("access", "")
        description = reg.get("description", "")
        format = reg.get("format", "")

        fields_info = ""
        if "fields" in reg:
            field_lines = []
            for field in reg["fields"]:
                fname = field.get("name", "")
                bits = field.get("bits", [])
                if isinstance(bits, list):
                    if len(bits) == 2:
                        bit_range = f"[{bits[0]}:{bits[1]}]"
                    elif len(bits) == 1:
                        bit_range = f"[{bits[0]}]"
                    else:
                        bit_range = ""
                else:
                    bit_range = ""
                enum = field.get("enum")
                if enum:
                    enum_str = ", ".join([f"{k}: {v}" for k, v in enum.items()])
                    field_lines.append(f"**{fname}** {bit_range} — {enum_str}")
                else:
                    field_lines.append(f"**{fname}** {bit_range}")
            fields_info = "\n".join(field_lines)

        fields_cell = fields_info.replace("\n", "<br/>")
        md_lines.append(f"| `{name}` | {address} | `{access}` | {description} | {format} | {fields_cell} |")

    output_path.write_text("\n".join(md_lines), encoding="utf-8")
    print(f"Markdown written to: {output_path}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Convert a register YAML file to Markdown.")
    parser.add_argument("yaml_file", type=Path, help="Input YAML file")
    parser.add_argument(
        "-o",
        "--output",
        type=Path,
        default=Path("register_bank.md"),
        help="Output Markdown file path (default: register_bank.md)",
    )

    args = parser.parse_args()
    generate_markdown(args.yaml_file, args.output)
