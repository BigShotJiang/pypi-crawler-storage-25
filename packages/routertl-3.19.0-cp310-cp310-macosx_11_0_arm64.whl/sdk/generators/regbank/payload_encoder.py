# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

# MIT License
#
# Copyright (c) 2024-2026 Daniel J. Mazure
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
# IN THE SOFTWARE.

import argparse
import binascii
import csv
import json
import struct
from pathlib import Path

import yaml


def load_yaml(yaml_path):
    """Load a YAML register map file and return its contents."""
    with open(yaml_path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def load_csv(csv_path, version="1.0.0"):
    """Load a CSV register map and return a structured dict."""
    registers = []
    with open(csv_path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            addr_raw = row["address"].strip()
            reg = {
                "name": row["name"].strip(),
                "address": int(addr_raw, 16 if addr_raw.startswith("0x") else 10),
                "access": row["access"].strip(),
            }
            desc = row.get("description", "").strip()
            format = row.get("format", "").strip()
            if format:
                reg["format"] = format
            if desc:
                reg["description"] = desc
            registers.append(reg)
    return {"version": version, "registers": registers}









def encode_raw_to_words(file_path):
    """Read a binary file and encode as 32-bit LE word list."""
    with open(file_path, "rb") as f:
        raw = f.read()

    # Pad to 4-byte alignment
    if len(raw) % 4 != 0:
        raw += b"\x00" * (4 - len(raw) % 4)

    words = []
    for i in range(0, len(raw), 4):
        word = struct.unpack("<I", raw[i : i + 4])[0]
        words.append(word)
    return words


def encode_text_file_to_words(file_path):
    """Read a text file as UTF-8 and encode as 32-bit LE word list."""
    with open(file_path, "r", encoding="utf-8") as f:
        raw = f.read().encode("utf-8")  # Just take the text as UTF-8 bytes

    # Pad to 4-byte alignment (for safe word packing)
    if len(raw) % 4 != 0:
        raw += b"\x00" * (4 - len(raw) % 4)

    words = []
    for i in range(0, len(raw), 4):
        word = struct.unpack("<I", raw[i : i + 4])[0]  # Little-endian 32-bit words
        words.append(word)

    return words


def write_bin_file(data, path):
    """Write data as raw binary to a file."""
    with open(path, "wb") as f:
        if isinstance(data, list):
            for word in data:
                f.write(word.to_bytes(4, byteorder="little"))
        else:
            f.write(data)


def write_hex_file(data, path):
    """Write data as hex-formatted text to a file."""
    with open(path, "w", encoding="utf-8") as f:
        if isinstance(data, list):
            for word in data:
                f.write(f"{word:08x}\n")
        else:
            for i in range(0, len(data), 4):
                chunk = data[i : i + 4].ljust(4, b"\x00")
                f.write(f"{binascii.hexlify(chunk).decode('ascii')}\n")


def write_json_file(data, path):
    """Write data as indented JSON to a file."""
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)


def main():
    """CLI entry point for the payload encoder."""
    parser = argparse.ArgumentParser(description="Convert register map YAML/CSV to binary/hex word files.")
    parser.add_argument("input_file", help="Input YAML or CSV file")
    parser.add_argument("--bin", help="Output binary file (defaults to same name as hex, with .bin)")
    parser.add_argument("--hex", default="regbank_manifest.hex", help="Output hex file")
    parser.add_argument("--json", help="Optional JSON dump of parsed data")
    parser.add_argument("--version", default="1.0.0", help="Version tag for CSV input")
    parser.add_argument(
        "--raw-source",
        choices=["text", "binary"],
        default="binary",
        help="Source type: 'text' reads file as UTF-8, 'binary' reads raw bytes (default)",
    )
    args = parser.parse_args()

    # Derive .bin path from .hex if not explicitly set
    if args.bin is None:
        args.bin = Path(args.hex).with_suffix(".bin")

    input_path = Path(args.input_file)
    ext = input_path.suffix.lower()

    # Structural parsing is only required when --json output is requested.
    # Raw/text word encoding reads the file as bytes, so any extension is fine
    # (e.g. routertl.lock, build metadata blobs).
    data = None
    if args.json:
        if ext in [".yml", ".yaml"]:
            data = load_yaml(input_path)
        elif ext == ".csv":
            data = load_csv(input_path, version=args.version)
        else:
            raise ValueError(
                f"--json requires .yml/.yaml or .csv input, got '{ext}'"
            )

    # Encode YAML/CSV content as 32-bit LE words
    if args.raw_source == "text":
        packed_words = encode_text_file_to_words(input_path)
    else:
        packed_words = encode_raw_to_words(input_path)

    # Write outputs
    write_bin_file(packed_words, args.bin)
    write_hex_file(packed_words, args.hex)
    if args.json:
        write_json_file(data, args.json)

    print(f"✅ Encoded {input_path.name} → {args.bin}, {args.hex}", end="")
    if args.json:
        print(f", {args.json}")
    else:
        print()


if __name__ == "__main__":
    main()
