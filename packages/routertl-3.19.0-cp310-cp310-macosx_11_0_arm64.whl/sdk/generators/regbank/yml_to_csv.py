# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

# MIT License
#
# Copyright (c) 2024-2026 Daniel J. Mazure
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
# IN THE SOFTWARE.

import csv
import sys
from pathlib import Path

import yaml


def export_yaml_to_csv(yaml_path, csv_path):
    """Export a YAML register map to CSV format."""
    with open(yaml_path, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f)

    registers = data.get("registers", [])
    rows = []

    for reg in registers:
        name = reg.get("name", "")
        address = reg.get("address", "")
        access = reg.get("access", "ro")
        format = reg.get("format", "")
        description = reg.get("description", "").replace("\n", " ").strip()

        if access in ["ro", "rom"]:
            access = "r"

        # Use address as-is from YAML (should be integer already)
        rows.append(
            {"name": name, "address": str(address), "access": access, "description": description, "format": format}
        )

    with open(csv_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["name", "address", "access", "description", "format"])
        writer.writeheader()
        writer.writerows(rows)

    print(f"✅ CSV exported to {csv_path}")


if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python yml_to_csv.py <input.yml> <output.csv>")
        sys.exit(1)

    yaml_file = Path(sys.argv[1])
    csv_file = Path(sys.argv[2])
    export_yaml_to_csv(yaml_file, csv_file)
