#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Generate rom_info_pkg (.vhd and/or .sv) with build metadata.

Replaces the create_rom.sh + gen_info_pkg.py pipeline with a single script.
Collects git hash, build date, system version, and optionally regbank schema
word counts, then directly outputs the VHDL and/or SystemVerilog package.

Usage
-----
Minimal (any project)::

    python3 gen_build_metadata.py /path/to/project --language vhdl

Full (regbank project)::

    python3 gen_build_metadata.py /path/to/project --language vhdl \\
        --regbank-yml project_regbank.yml \\
        --regbank-hex src/regbank/regbank_schema.hex \\
        --config-hex  src/regbank/config_schema.hex \\
        --lock-hex    misc/lock.hex
"""

from __future__ import annotations

import argparse
import datetime
import os
import re
import subprocess
import time
from pathlib import Path

# ── Data collection ──────────────────────────────────────────────────────────


def _git(cmd: list[str], cwd: str) -> str:
    """Run a git command, return stripped stdout or empty string on failure."""
    try:
        r = subprocess.run(
            ["git"] + cmd, capture_output=True, text=True, cwd=cwd, check=True
        )
        return r.stdout.strip()
    except (subprocess.CalledProcessError, FileNotFoundError):
        return ""


def _read_version_file(root_dir: str) -> tuple[int, int]:
    """Read VERSION file (shell-sourceable key=value). Returns (major, minor)."""
    version_path = os.path.join(root_dir, "VERSION")
    major, minor = 0, 1  # sensible defaults
    if os.path.isfile(version_path):
        with open(version_path) as f:
            for line in f:
                line = line.strip()
                if line.startswith("#") or "=" not in line:
                    continue
                key, _, val = line.partition("=")
                key, val = key.strip(), val.strip()
                if key == "system_major":
                    major = int(val)
                elif key == "system_minor":
                    minor = int(val)
    else:
        print(f"WARNING: No VERSION file found in {root_dir}, using 0.1")
    return major, minor


def _read_regbank_version(regbank_yml: str) -> tuple[int, int, int]:
    """Extract version: X.Y.Z from a regbank YAML file."""
    try:
        with open(regbank_yml) as f:
            for line in f:
                m = re.match(r"^version:\s*(.+)", line)
                if m:
                    parts = m.group(1).strip().split(".")
                    return (
                        int(parts[0]) if len(parts) > 0 else 0,
                        int(parts[1]) if len(parts) > 1 else 0,
                        int(parts[2]) if len(parts) > 2 else 0,
                    )
    except (OSError, ValueError):
        pass
    return 0, 0, 0


def _count_hex_lines(path: str | None) -> int:
    """Count lines in a hex file. Returns 0 if missing/empty."""
    if not path or not os.path.isfile(path) or os.path.getsize(path) == 0:
        return 0
    with open(path) as f:
        return sum(1 for _ in f)


def collect_metadata(root_dir: str, args: argparse.Namespace) -> dict:
    """Collect all build metadata into a dict of hex strings."""
    # Git hash
    git_hash = _git(["rev-parse", "--short=8", "HEAD"], root_dir) or "00000000"

    # Build date (epoch → hex)
    build_date = f"{int(time.time()):08x}"

    # System version: major.minor.patch.reserved
    major, minor = _read_version_file(root_dir)
    commit_count = _git(["rev-list", "--count", "HEAD"], root_dir)
    patch = int(commit_count) % 256 if commit_count else 0

    # Dirty detection: uncommitted changes in src/
    dirty = 0
    porcelain = _git(["status", "--porcelain", "src/"], root_dir)
    if porcelain:
        dirty = 1
        print("Info: Dirty working tree detected in src/")

    system_version = f"{major:02x}{minor:02x}{patch:02x}{dirty:02x}"

    # Regbank version (optional)
    if args.regbank_yml and os.path.isfile(args.regbank_yml):
        rb_major, rb_minor, rb_patch = _read_regbank_version(args.regbank_yml)
    else:
        rb_major, rb_minor, rb_patch = 0, 0, 0
    regbank_version = f"{rb_major:02x}{rb_minor:02x}{rb_patch:02x}00"

    # Schema word counts (optional — Layer 2)
    regbank_words = _count_hex_lines(args.regbank_hex)
    config_words = _count_hex_lines(args.config_hex)
    lock_words = _count_hex_lines(args.lock_hex)

    # Absolute paths for hex file references (used by $readmemh in synthesis)
    regbank_hex_abs = os.path.abspath(args.regbank_hex) if args.regbank_hex and os.path.isfile(args.regbank_hex) else ""
    config_hex_abs = os.path.abspath(args.config_hex) if args.config_hex and os.path.isfile(args.config_hex) else ""
    lock_hex_abs = os.path.abspath(args.lock_hex) if args.lock_hex and os.path.isfile(args.lock_hex) else ""

    print(f"Info: Git hash = {git_hash}")
    print(f"Info: System version = {major}.{minor}.{patch} (dirty={dirty})")
    if args.regbank_yml:
        print(f"Info: Regbank version = {rb_major}.{rb_minor}.{rb_patch}")

    return {
        "git_hash": git_hash,
        "build_date": build_date,
        "system_version": system_version,
        "regbank_version": regbank_version,
        "regbank_words": f"{regbank_words:08x}",
        "config_words": f"{config_words:08x}",
        "lock_words": f"{lock_words:08x}",
        "regbank_words_int": regbank_words,
        "config_words_int": config_words,
        "lock_words_int": lock_words,
        "regbank_hex_path": regbank_hex_abs,
        "config_hex_path": config_hex_abs,
        "lock_hex_path": lock_hex_abs,
    }


# ── VHDL template ───────────────────────────────────────────────────────────


def generate_vhdl(meta: dict) -> str:
    """Generate rom_info_pkg.vhd content."""
    now = datetime.datetime.now()
    m = meta
    return f"""\
-- Tich (c) {now.year}
-- File created @{now.ctime()}
-- Auto-generated by gen_build_metadata.py — do not edit

library IEEE;
use IEEE.STD_LOGIC_1164.all;
use IEEE.NUMERIC_STD.all;
use IEEE.MATH_REAL.all;

package rom_info_pkg is

  constant C_ROM_DATA_WIDTH  : integer  := 32;
  constant C_GIT_HASH        : std_logic_vector(C_ROM_DATA_WIDTH-1 downto 0) := x"{m['git_hash']}";
  constant C_SYSTEM_VERSION  : std_logic_vector(C_ROM_DATA_WIDTH-1 downto 0) := x"{m['system_version']}";
  constant C_BUILD_DATE      : std_logic_vector(C_ROM_DATA_WIDTH-1 downto 0) := x"{m['build_date']}";
  constant C_REGBANK_VERSION : std_logic_vector(C_ROM_DATA_WIDTH-1 downto 0) := x"{m['regbank_version']}";
  constant C_REGBANK_WORDS   : std_logic_vector(C_ROM_DATA_WIDTH-1 downto 0) := x"{m['regbank_words']}"; -- {m['regbank_words_int']} words
  constant C_CONFIG_WORDS    : std_logic_vector(C_ROM_DATA_WIDTH-1 downto 0) := x"{m['config_words']}"; -- {m['config_words_int']} words
  constant C_LOCK_WORDS      : std_logic_vector(C_ROM_DATA_WIDTH-1 downto 0) := x"{m['lock_words']}"; -- {m['lock_words_int']} words
  constant C_REGBANK_HEX     : string := "{m['regbank_hex_path']}";
  constant C_CONFIG_HEX      : string := "{m['config_hex_path']}";
  constant C_LOCK_HEX        : string := "{m['lock_hex_path']}";

end package rom_info_pkg;

package body rom_info_pkg is
end rom_info_pkg;
"""


# ── SystemVerilog template ───────────────────────────────────────────────────


def generate_sv(meta: dict) -> str:
    """Generate rom_info_pkg.sv content."""
    now = datetime.datetime.now()
    m = meta
    return f"""\
// Tich (c) {now.year}
// File created @{now.ctime()}
// Auto-generated by gen_build_metadata.py — do not edit

package rom_info_pkg;

  localparam int          C_ROM_DATA_WIDTH  = 32;
  localparam logic [31:0] C_GIT_HASH        = 32'h{m['git_hash']};
  localparam logic [31:0] C_SYSTEM_VERSION  = 32'h{m['system_version']};
  localparam logic [31:0] C_BUILD_DATE      = 32'h{m['build_date']};
  localparam logic [31:0] C_REGBANK_VERSION = 32'h{m['regbank_version']};
  localparam logic [31:0] C_REGBANK_WORDS   = 32'h{m['regbank_words']}; // {m['regbank_words_int']} words
  localparam logic [31:0] C_CONFIG_WORDS    = 32'h{m['config_words']}; // {m['config_words_int']} words
  localparam logic [31:0] C_LOCK_WORDS      = 32'h{m['lock_words']}; // {m['lock_words_int']} words
  localparam string       C_REGBANK_HEX     = "{m['regbank_hex_path']}";
  localparam string       C_CONFIG_HEX      = "{m['config_hex_path']}";
  localparam string       C_LOCK_HEX        = "{m['lock_hex_path']}";

endpackage : rom_info_pkg
"""


# ── C header template ────────────────────────────────────────────────────────


def generate_c_header(meta: dict) -> str:
    """Generate a C header (build_info.h) carrying the same constants the
    VHDL / SV packages get, so firmware baked for a NiosV / microcontroller
    can validate at runtime that it was built against the same git HEAD
    as the RTL it sits behind (RTL-P3.162).

    Constants use a ``BUILD_`` / ``REGBANK_`` prefix to follow C-land
    conventions; their hex values are bit-for-bit identical to
    ``C_GIT_HASH`` / ``C_BUILD_DATE`` / ``C_SYSTEM_VERSION`` / etc. in
    the VHDL and SV packages.  A companion ``_STR`` define keeps the
    git hash as a human-readable ASCII constant for log lines.
    """
    now = datetime.datetime.now()
    m = meta
    return f"""\
/*
 * Tich (c) {now.year}
 * File created @{now.ctime()}
 * Auto-generated by gen_build_metadata.py — do not edit
 */
#ifndef BUILD_INFO_H
#define BUILD_INFO_H

#include <stdint.h>

#define BUILD_GIT_HASH          0x{m['git_hash']}u
#define BUILD_GIT_HASH_STR      "{m['git_hash']}"
#define BUILD_DATE              0x{m['build_date']}u
#define BUILD_SYSTEM_VERSION    0x{m['system_version']}u
#define BUILD_REGBANK_VERSION   0x{m['regbank_version']}u
#define BUILD_REGBANK_WORDS     {m['regbank_words_int']}u
#define BUILD_CONFIG_WORDS      {m['config_words_int']}u
#define BUILD_LOCK_WORDS        {m['lock_words_int']}u

/* Same ROM data width as the VHDL / SV packages. */
#define BUILD_ROM_DATA_WIDTH    32

#endif /* BUILD_INFO_H */
"""


# ── CLI ──────────────────────────────────────────────────────────────────────


def main():
    parser = argparse.ArgumentParser(
        description="Generate rom_info_pkg with build metadata"
    )
    parser.add_argument("root_dir", help="Project root directory")
    parser.add_argument(
        "--language",
        choices=["vhdl", "systemverilog", "mixed"],
        default="vhdl",
        help="HDL language — determines output file format",
    )
    parser.add_argument("--output-dir", default=None, help="Output directory (default: <root>/src/pkg/)")
    parser.add_argument(
        "--c-header",
        default=None,
        metavar="PATH",
        help="Also emit a C header (build_info.h) at PATH so firmware "
             "can bake the same BUILD_GIT_HASH / BUILD_DATE / "
             "BUILD_SYSTEM_VERSION constants the RTL gets — RTL-P3.162. "
             "Independent of --language.",
    )
    parser.add_argument("--regbank-yml", default=None, help="Path to project_regbank.yml")
    parser.add_argument("--regbank-hex", default=None, help="Path to regbank_schema.hex")
    parser.add_argument("--config-hex", default=None, help="Path to config_schema.hex")
    parser.add_argument("--lock-hex", default=None, help="Path to lock.hex")

    args = parser.parse_args()
    root_dir = os.path.abspath(args.root_dir)
    out_dir = Path(args.output_dir) if args.output_dir else Path(root_dir) / "src" / "pkg"
    out_dir.mkdir(parents=True, exist_ok=True)

    meta = collect_metadata(root_dir, args)

    if args.language in ("vhdl", "mixed"):
        vhd_path = out_dir / "rom_info_pkg.vhd"
        vhd_path.write_text(generate_vhdl(meta))
        print(f"Generated {vhd_path}")

    if args.language in ("systemverilog", "mixed"):
        sv_path = out_dir / "rom_info_pkg.sv"
        sv_path.write_text(generate_sv(meta))
        print(f"Generated {sv_path}")

    if args.c_header:
        c_path = Path(args.c_header)
        c_path.parent.mkdir(parents=True, exist_ok=True)
        c_path.write_text(generate_c_header(meta))
        print(f"Generated {c_path}")


if __name__ == "__main__":
    main()
