# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

# MIT License
#
# Copyright (c) 2024-2026 Daniel J. Mazure
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
# IN THE SOFTWARE.

import re
import sys
from pathlib import Path

import yaml


def extract_yaml_version(yaml_file: Path) -> str:
    """Extract the version string from a YAML register schema."""
    with open(yaml_file, "r") as f:
        data = yaml.safe_load(f)
        return str(data.get("version", "")).strip()


def extract_rom_pkg_version(vhd_file: Path) -> str:
    """Extract the version string from a VHDL ROM info package."""
    with open(vhd_file, "r") as f:
        content = f.read()

    match = re.search(r"C_REGBANK_VERSION\s*:\s*std_logic_vector.*?x\"([0-9A-Fa-f]{8})\"", content)
    if match:
        hexval = match.group(1)
        major = int(hexval[0:2], 16)
        minor = int(hexval[2:4], 16)
        patch = int(hexval[4:6], 16)
        return f"{major}.{minor}.{patch}"
    return ""


def main(yaml_file, vhdl_file):
    """CLI entry point for regbank version checking."""
    yaml_version = extract_yaml_version(Path(yaml_file))
    vhdl_version = extract_rom_pkg_version(Path(vhdl_file))

    if yaml_version == vhdl_version:
        print(f"✅ Versions match: {yaml_version}")
        sys.exit(0)
    else:
        print("⚠️ Version mismatch:")
        print(f"   YAML version : {yaml_version}")
        print(f"   VHDL version : {vhdl_version}")
        sys.exit(1)


if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python check_regbank_version.py <register_map.yaml> <rom_info_pkg.vhd>")
        sys.exit(2)
    main(sys.argv[1], sys.argv[2])
