# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

# Package sentinel — ensures setuptools ships runtime files in the pip wheel.
