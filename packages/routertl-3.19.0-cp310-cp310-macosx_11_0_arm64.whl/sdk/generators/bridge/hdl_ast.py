# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
hdl_ast.py — Hardware Description Language Abstract Syntax Tree
===============================================================

A minimal, visitable AST for Verilog/SystemVerilog constructs.
Used as the middle-end of the RouteRTL bridge generator pipeline.

Pipeline position:
    Frontend (Interfaces) → [THIS MODULE] → Logic Layer → Backend (Emitter)
"""

from __future__ import annotations

import enum
from typing import Any, Iterator, List, Optional, Sequence, Tuple, Union

# ---------------------------------------------------------------------------
# Enumerations
# ---------------------------------------------------------------------------


class Direction(enum.Enum):
    """Signal direction / port type."""

    INPUT = "input"
    OUTPUT = "output"
    LOCAL = "local"  # internal wire / reg — not a port


class Edge(enum.Enum):
    """Clock / reset edge for sensitivity lists."""

    POSEDGE = "posedge"
    NEGEDGE = "negedge"
    LEVEL = ""  # level-sensitive (combinational always @(*))


class ResetStyle(enum.Enum):
    """Controls whether flip-flops use synchronous or asynchronous reset."""

    SYNC = "sync"
    ASYNC = "async"


# ---------------------------------------------------------------------------
# Expression types
# ---------------------------------------------------------------------------

# An Expression is anything that can appear on the RHS of an assignment or
# inside a condition.  We keep it deliberately open so callers can pass
# plain strings (e.g. "awaddr[15:0]"), Signal objects, or nested Concat /
# Ternary nodes without restricting the type.
Expression = Union["Signal", "Slice", "Concat", "Ternary", str, int]


# ---------------------------------------------------------------------------
# Base node
# ---------------------------------------------------------------------------


class HdlNode:
    """Abstract base for every node in the hardware AST.

    All concrete nodes must implement ``accept`` so that visitors can
    dispatch without ``isinstance`` chains.
    """

    def accept(self, visitor: "NodeVisitor") -> Any:
        """Double-dispatch entry point.

        Calls ``visitor.visit_<ClassName>(self)`` if it exists, otherwise
        falls back to ``visitor.generic_visit(self)``.
        """
        method_name = f"visit_{type(self).__name__}"
        method = getattr(visitor, method_name, visitor.generic_visit)
        return method(self)


# ---------------------------------------------------------------------------
# Signal / port
# ---------------------------------------------------------------------------


class Signal(HdlNode):
    """Represents a single Verilog signal (port or internal wire/reg).

    Parameters
    ----------
    name:
        Verilog identifier (e.g. ``"awvalid"``).
    width:
        Bit-width.  ``1`` means a scalar (no ``[N:0]`` in the declaration).
    direction:
        ``Direction.INPUT`` / ``Direction.OUTPUT`` for ports;
        ``Direction.LOCAL`` for internal signals.
    reset_val:
        Reset value used by the emitter when generating flip-flop resets.
        Defaults to ``0``.
    """

    def __init__(
        self,
        name: str,
        width: int = 1,
        direction: Direction = Direction.LOCAL,
        reset_val: int = 0,
    ) -> None:
        """Create an HDL AST node."""
        if width < 1:
            raise ValueError(f"Signal '{name}': width must be >= 1, got {width}")
        self.name: str = name
        self.width: int = width
        self.direction: Direction = direction
        self.reset_val: int = reset_val

    # ------------------------------------------------------------------
    # Bit-slicing helpers
    # ------------------------------------------------------------------

    def __getitem__(self, key: Union[int, slice]) -> "Slice":
        """Return a ``Slice`` expression node.

        Usage::

            sig[7]      # single bit  → Slice(sig, 7, 7)
            sig[7:0]    # range       → Slice(sig, 7, 0)
        """
        if isinstance(key, int):
            return Slice(self, key, key)
        if isinstance(key, slice):
            msb = key.start
            lsb = key.stop
            if msb is None or lsb is None:
                raise ValueError("Signal slice requires explicit start and stop (e.g. sig[7:0])")
            if key.step is not None:
                raise ValueError("Signal slice does not support a step value")
            return Slice(self, msb, lsb)
        raise TypeError(f"Signal indices must be int or slice, not {type(key).__name__}")

    # ------------------------------------------------------------------
    # Dunder helpers
    # ------------------------------------------------------------------

    def __repr__(self) -> str:
        return (
            f"Signal(name={self.name!r}, width={self.width}, "
            f"direction={self.direction.name}, reset_val={self.reset_val})"
        )

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Signal):
            return NotImplemented
        return (
            self.name == other.name
            and self.width == other.width
            and self.direction == other.direction
            and self.reset_val == other.reset_val
        )

    def __hash__(self) -> int:
        return hash((self.name, self.width, self.direction, self.reset_val))

    def __iter__(self) -> Iterator["Slice"]:
        """Iterate over individual bits (MSB → LSB)."""
        for i in range(self.width - 1, -1, -1):
            yield Slice(self, i, i)


# ---------------------------------------------------------------------------
# Expression nodes
# ---------------------------------------------------------------------------


class Slice(HdlNode):
    """A bit-select or part-select expression: ``signal[msb:lsb]``."""

    def __init__(self, signal: Signal, msb: int, lsb: int) -> None:
        """Create an HDL AST node."""
        if msb < lsb:
            raise ValueError(f"Slice MSB ({msb}) must be >= LSB ({lsb}) for signal '{signal.name}'")
        self.signal: Signal = signal
        self.msb: int = msb
        self.lsb: int = lsb

    @property
    def width(self) -> int:
        """Return the bit-width of this signal."""
        return self.msb - self.lsb + 1

    def __repr__(self) -> str:
        if self.msb == self.lsb:
            return f"{self.signal.name}[{self.msb}]"
        return f"{self.signal.name}[{self.msb}:{self.lsb}]"


class Concat(HdlNode):
    """Verilog concatenation: ``{a, b, c}``."""

    def __init__(self, *parts: Expression) -> None:
        """Create an HDL AST node."""
        self.parts: Tuple[Expression, ...] = parts

    def __repr__(self) -> str:
        return "{" + ", ".join(str(p) for p in self.parts) + "}"


class Ternary(HdlNode):
    """Verilog ternary operator: ``condition ? true_val : false_val``."""

    def __init__(
        self,
        condition: Expression,
        true_val: Expression,
        false_val: Expression,
    ) -> None:
        """Create an HDL AST node."""
        self.condition: Expression = condition
        self.true_val: Expression = true_val
        self.false_val: Expression = false_val

    def __repr__(self) -> str:
        return f"({self.condition} ? {self.true_val} : {self.false_val})"


# ---------------------------------------------------------------------------
# Module
# ---------------------------------------------------------------------------


class Module(HdlNode):
    """Top-level container — maps to a Verilog ``module … endmodule`` block.

    Parameters
    ----------
    name:
        Module identifier.
    ports:
        Ordered list of port ``Signal`` objects (``INPUT`` or ``OUTPUT``).
    signals:
        Internal signals (``LOCAL`` direction).
    body:
        Ordered list of ``HdlNode`` logic blocks (``Assign``, ``Always``, …).
    """

    def __init__(
        self,
        name: str,
        ports: Optional[List[Signal]] = None,
        signals: Optional[List[Signal]] = None,
        body: Optional[List[HdlNode]] = None,
    ) -> None:
        """Create an HDL AST node."""
        self.name: str = name
        self.ports: List[Signal] = ports if ports is not None else []
        self.signals: List[Signal] = signals if signals is not None else []
        self.body: List[HdlNode] = body if body is not None else []

    # ------------------------------------------------------------------
    # Convenience mutators
    # ------------------------------------------------------------------

    def add_port(self, signal: Signal) -> "Module":
        """Append a port and return ``self`` for chaining."""
        if signal.direction == Direction.LOCAL:
            raise ValueError(f"Signal '{signal.name}' has direction LOCAL — use add_signal() instead")
        self.ports.append(signal)
        return self

    def add_signal(self, signal: Signal) -> "Module":
        """Append an internal signal and return ``self`` for chaining."""
        if signal.direction != Direction.LOCAL:
            raise ValueError(f"Signal '{signal.name}' is a port — use add_port() instead")
        self.signals.append(signal)
        return self

    def add_block(self, node: HdlNode) -> "Module":
        """Append a logic block and return ``self`` for chaining."""
        self.body.append(node)
        return self

    def __repr__(self) -> str:
        return (
            f"Module(name={self.name!r}, ports={len(self.ports)}, signals={len(self.signals)}, body={len(self.body)})"
        )


# ---------------------------------------------------------------------------
# Logic nodes
# ---------------------------------------------------------------------------


class Assign(HdlNode):
    """Continuous assignment: ``assign target = source;``

    Parameters
    ----------
    target:
        LHS — a ``Signal`` or ``Slice``.
    source:
        RHS — any ``Expression``.
    """

    def __init__(
        self,
        target: Union[Signal, Slice],
        source: Expression,
    ) -> None:
        """Create an HDL AST node."""
        self.target: Union[Signal, Slice] = target
        self.source: Expression = source

    def __repr__(self) -> str:
        return f"Assign({self.target!r} = {self.source!r})"


class Always(HdlNode):
    """Procedural block: ``always @(sensitivity_list) begin … end``

    Parameters
    ----------
    sensitivity:
        List of ``(Edge, Signal)`` tuples.  Pass an empty list or
        ``[(Edge.LEVEL, None)]`` for combinational (``always @(*)``) blocks.
    body:
        Ordered list of statements inside the block.
    """

    def __init__(
        self,
        sensitivity: Sequence[Tuple[Edge, Optional[Signal]]],
        body: Optional[List[HdlNode]] = None,
    ) -> None:
        """Create an HDL AST node."""
        self.sensitivity: List[Tuple[Edge, Optional[Signal]]] = list(sensitivity)
        self.body: List[HdlNode] = body if body is not None else []

    def add_statement(self, node: HdlNode) -> "Always":
        """Append a statement and return ``self`` for chaining."""
        self.body.append(node)
        return self

    def __repr__(self) -> str:
        sens = ", ".join(f"{e.value} {s.name}" if s else "*" for e, s in self.sensitivity)
        return f"Always(@({sens}), body={len(self.body)})"


class NonBlockingAssign(HdlNode):
    """Non-blocking assignment inside an ``Always`` block: ``target <= source;``

    Parameters
    ----------
    target:
        LHS — a ``Signal`` or ``Slice``.
    source:
        RHS — any ``Expression``.
    """

    def __init__(
        self,
        target: Union[Signal, Slice],
        source: Expression,
    ) -> None:
        """Create an HDL AST node."""
        self.target: Union[Signal, Slice] = target
        self.source: Expression = source

    def __repr__(self) -> str:
        return f"NonBlockingAssign({self.target!r} <= {self.source!r})"


class If(HdlNode):
    """Conditional statement: ``if (condition) … else …``

    Parameters
    ----------
    condition:
        Any ``Expression`` (string, ``Signal``, ``Slice``, …).
    then_body:
        Statements executed when the condition is true.
    else_body:
        Statements executed in the ``else`` branch (may be empty).
    """

    def __init__(
        self,
        condition: Expression,
        then_body: Optional[List[HdlNode]] = None,
        else_body: Optional[List[HdlNode]] = None,
    ) -> None:
        """Create an HDL AST node."""
        self.condition: Expression = condition
        self.then_body: List[HdlNode] = then_body if then_body is not None else []
        self.else_body: List[HdlNode] = else_body if else_body is not None else []

    def __repr__(self) -> str:
        return f"If(condition={self.condition!r}, then={len(self.then_body)}, else={len(self.else_body)})"


class Case(HdlNode):
    """Case statement: ``case (selector) … endcase``

    Parameters
    ----------
    selector:
        The signal or expression being switched on.
    branches:
        Ordered list of ``(value, body)`` pairs.  ``value`` may be an
        ``int``, a string literal (e.g. ``"2'b10"``), or ``None`` for the
        ``default`` branch.
    """

    def __init__(
        self,
        selector: Expression,
        branches: Optional[List[Tuple[Optional[Union[int, str]], List[HdlNode]]]] = None,
    ) -> None:
        """Create an HDL AST node."""
        self.selector: Expression = selector
        # Each entry: (match_value_or_None_for_default, body_statements)
        self.branches: List[Tuple[Optional[Union[int, str]], List[HdlNode]]] = branches if branches is not None else []

    def add_branch(
        self,
        value: Optional[Union[int, str]],
        body: List[HdlNode],
    ) -> "Case":
        """Append a branch and return ``self`` for chaining.

        Pass ``value=None`` to add the ``default`` branch.
        """
        self.branches.append((value, body))
        return self

    def __repr__(self) -> str:
        return f"Case(selector={self.selector!r}, branches={len(self.branches)})"


# ---------------------------------------------------------------------------
# Visitor pattern
# ---------------------------------------------------------------------------


class NodeVisitor:
    """Base visitor — subclass and override ``visit_<NodeType>`` methods.

    The default ``generic_visit`` recursively visits child nodes so that
    a subclass only needs to override the nodes it cares about.

    Example::

        class PortLister(NodeVisitor):
            def visit_Signal(self, node: Signal) -> None:
                if node.direction != Direction.LOCAL:
                    print(node.name)

        lister = PortLister()
        lister.visit(my_module)
    """

    def visit(self, node: HdlNode) -> Any:
        """Entry point — dispatches to the appropriate ``visit_*`` method."""
        return node.accept(self)

    def generic_visit(self, node: HdlNode) -> None:
        """Fallback: recursively visit all child ``HdlNode`` attributes."""
        for value in vars(node).values():
            if isinstance(value, HdlNode):
                self.visit(value)
            elif isinstance(value, list):
                for item in value:
                    if isinstance(item, HdlNode):
                        self.visit(item)
            elif isinstance(value, dict):
                for item in value.values():
                    if isinstance(item, HdlNode):
                        self.visit(item)
                    elif isinstance(item, list):
                        for sub in item:
                            if isinstance(sub, HdlNode):
                                self.visit(sub)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

__all__ = [
    # Enumerations
    "Direction",
    "Edge",
    "ResetStyle",
    # Expression type alias
    "Expression",
    # Nodes
    "HdlNode",
    "Signal",
    "Slice",
    "Concat",
    "Ternary",
    "Module",
    "Assign",
    "NonBlockingAssign",
    "Always",
    "If",
    "Case",
    # Visitor
    "NodeVisitor",
]
