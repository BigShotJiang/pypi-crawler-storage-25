# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
arbiter_logic.py — Round-Robin Avalon-MM Multi-Master Arbiter
=============================================================

Generates a parameterized round-robin arbiter that sits between N
Avalon-MM masters and a single downstream Avalon-MM slave (e.g. a
DDR memory controller).

Key features:
  * True round-robin fairness — no master can starve another.
  * Burst-level locking — once granted, a master holds the bus
    until the slave completes the transaction (``!waitrequest``).
  * Parameterized master count (2–8), data width, address width.

Pipeline position::

    Frontend (bus_interfaces)
        → Middle-end (hdl_ast)
            → **Logic Layer (this module)**
                → Backend (emitter_sv / emitter_vhdl)

Usage::

    from bus_interfaces import AvalonMMInterface, InterfaceRole
    from arbiter_logic import build_avalon_arbiter

    masters = [
        AvalonMMInterface(32, 14, role=InterfaceRole.SLAVE, prefix=f"m{i}_avl")
        for i in range(2)
    ]
    slave = AvalonMMInterface(32, 14, role=InterfaceRole.MASTER, prefix="s_avl")
    clk = Signal("clk", direction=Direction.INPUT)
    rst = Signal("rst_n", direction=Direction.INPUT)

    signals, blocks = build_avalon_arbiter(masters, slave, clk, rst)
"""

from __future__ import annotations

import math
from enum import IntEnum
from typing import List, Tuple

from bridge_builder import BridgeBuilder
from bus_interfaces import AvalonMMInterface
from hdl_ast import (
    HdlNode,
    If,
    NonBlockingAssign,
    ResetStyle,
    Signal,
)

BB = BridgeBuilder

# ---------------------------------------------------------------------------
# FSM state encoding
# ---------------------------------------------------------------------------


class ArbiterState(IntEnum):
    """FSM states for the round-robin Avalon-MM arbiter.

    The arbiter uses a 4-state machine:

    * ``IDLE``     — No master is requesting the bus.
    * ``GRANT``    — A master has been selected; signals are muxed through.
    * ``LOCKED``   — Burst in progress; grant is held until completion.
    * ``COMPLETE`` — Transaction done; rotate grant pointer.
    """

    IDLE = 0      # Waiting for a master to request
    GRANT = 1     # Selected master gets bus ownership
    LOCKED = 2    # Burst in progress — hold grant
    COMPLETE = 3  # Transaction done; rotate pointer


_STATE_WIDTH = 2


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _grant_width(num_masters: int) -> int:
    """Return the bit-width needed to index ``num_masters``."""
    if num_masters <= 1:
        return 1
    return math.ceil(math.log2(num_masters))


def _build_round_robin_scan(
    grant_reg: Signal,
    masters: List[AvalonMMInterface],
    state_reg: Signal,
    grant_target: Signal,
) -> List[HdlNode]:
    """Build a priority-encoded round-robin scan chain.

    Starting from ``(grant_reg + 1) % N``, scan all masters for an
    active ``read | write`` request.  The first active master wins.
    If no master is requesting, stay in IDLE.

    Returns a nested ``If/else`` chain as a list of ``HdlNode``.
    """
    n = len(masters)
    _, lookups = zip(*(BB.resolve_signals(m) for m in masters))

    # Build the scan order: (grant_reg + 1), (grant_reg + 2), ..., grant_reg
    # Since we generate static HDL, we unroll all N slots with their
    # conditions expressed relative to grant_reg.

    # We build a nested if/else structure:
    # if (master[(grant+1)%N].read | master[(grant+1)%N].write)
    #   grant_next <= (grant+1)%N; state <= GRANT;
    # else if (master[(grant+2)%N].read | master[(grant+2)%N].write)
    #   grant_next <= (grant+2)%N; state <= GRANT;
    # ...
    # else  // no master requesting
    #   stay IDLE

    def _master_requesting(idx: int) -> str:
        lookup = lookups[idx]
        read_name = lookup("read").name
        write_name = lookup("write").name
        return f"{read_name} | {write_name}"

    # Build from inside out (last else first)
    current_else: List[HdlNode] = []  # empty = stay IDLE (no transition)

    # Scan in reverse so we build the if/else chain from innermost to outermost
    for offset in range(n, 0, -1):
        # Static check index: for each possible current grant value,
        # we check master at (current + offset) % n.
        # Since grant_reg is a runtime value, we generate:
        #   if (grant_reg == 0) check master[offset % n]
        #   else if (grant_reg == 1) check master[(1+offset) % n]
        #   ...
        # But this creates N*N branches. Instead, we use a simpler approach:
        # check each master in a fixed priority order, but rotate the
        # starting point.

        # Simpler approach: just check each master index directly.
        # The round-robin fairness is achieved by the scan order.
        pass

    # Simpler and cleaner approach: generate a flat scan.
    # For each master i in 0..N-1, generate:
    #   if (grant_reg == i) → scan from (i+1)%N, (i+2)%N, ..., i
    #
    # This creates N top-level branches, each with N-step priority scan.

    top_else: List[HdlNode] = []  # fallback: stay IDLE

    for current_grant in range(n - 1, -1, -1):
        # Build the scan chain for when grant_reg == current_grant
        scan_else: List[HdlNode] = []  # innermost: no master requesting
        for scan_offset in range(n, 0, -1):
            check_idx = (current_grant + scan_offset) % n
            cond = _master_requesting(check_idx)
            grant_body = [
                NonBlockingAssign(grant_target, check_idx),
                NonBlockingAssign(state_reg, ArbiterState.GRANT),
            ]
            scan_else = [If(cond, then_body=grant_body, else_body=scan_else)]

        grant_cond = f"{grant_reg.name} == {current_grant}"
        top_else = [If(grant_cond, then_body=scan_else, else_body=top_else)]

    return top_else


def _build_mux_assignments(
    grant_reg: Signal,
    masters: List[AvalonMMInterface],
    slave: AvalonMMInterface,
) -> List[HdlNode]:
    """Build the signal mux from granted master to downstream slave.

    Generates an if/else chain:
      if (grant_reg == 0)
          slave.address <= m0.address; slave.write <= m0.write; ...
      else if (grant_reg == 1)
          slave.address <= m1.address; slave.write <= m1.write; ...
      ...
    """
    n = len(masters)
    _, s_lookup = BB.resolve_signals(slave)
    master_lookups = [BB.resolve_signals(m)[1] for m in masters]

    # Signals to mux: master→slave direction
    mux_signals = ["address", "read", "write", "writedata", "byteenable"]

    current_else: List[HdlNode] = []
    for i in range(n - 1, -1, -1):
        m_lookup = master_lookups[i]
        body: List[HdlNode] = []
        for sig_name in mux_signals:
            body.append(NonBlockingAssign(s_lookup(sig_name), m_lookup(sig_name)))
        cond = f"{grant_reg.name} == {i}"
        current_else = [If(cond, then_body=body, else_body=current_else)]

    return current_else


def _build_waitrequest_fanout(
    grant_reg: Signal,
    masters: List[AvalonMMInterface],
    slave: AvalonMMInterface,
) -> List[HdlNode]:
    """Drive per-master waitrequest signals.

    Only the granted master sees the slave's waitrequest; all others
    are held high (stalled).
    """
    _, s_lookup = BB.resolve_signals(slave)
    master_lookups = [BB.resolve_signals(m)[1] for m in masters]

    stmts: List[HdlNode] = []
    for i, m_lookup in enumerate(master_lookups):
        cond = f"{grant_reg.name} == {i}"
        stmts.append(If(
            cond,
            then_body=[NonBlockingAssign(m_lookup("waitrequest"), s_lookup("waitrequest"))],
            else_body=[NonBlockingAssign(m_lookup("waitrequest"), 1)],
        ))

    return stmts


def _build_readdata_fanout(
    grant_reg: Signal,
    masters: List[AvalonMMInterface],
    slave: AvalonMMInterface,
) -> List[HdlNode]:
    """Route slave response signals back to the granted master.

    readdata, readdatavalid, and response are broadcast to all masters
    but only the granted master's waitrequest is deasserted.
    """
    _, s_lookup = BB.resolve_signals(slave)
    master_lookups = [BB.resolve_signals(m)[1] for m in masters]

    response_signals = ["readdata", "readdatavalid", "response"]
    stmts: List[HdlNode] = []
    for i, m_lookup in enumerate(master_lookups):
        cond = f"{grant_reg.name} == {i}"
        fanout_body = [
            NonBlockingAssign(m_lookup(sig), s_lookup(sig))
            for sig in response_signals
        ]
        zero_body = [
            NonBlockingAssign(m_lookup(sig), 0)
            for sig in response_signals
        ]
        stmts.append(If(cond, then_body=fanout_body, else_body=zero_body))

    return stmts


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def build_avalon_arbiter(
    masters: List[AvalonMMInterface],
    slave: AvalonMMInterface,
    clk: Signal,
    rst: Signal,
    reset_style: ResetStyle = ResetStyle.SYNC,
    active_low_reset: bool = True,
) -> Tuple[List[Signal], List[HdlNode]]:
    """Build a round-robin Avalon-MM multi-master arbiter.

    Parameters
    ----------
    masters:
        List of N Avalon-MM interfaces (SLAVE role — receiving requests
        from upstream masters).  Must have 2–8 entries.
    slave:
        Single Avalon-MM interface (MASTER role — issuing requests to
        the downstream slave, e.g. a memory controller).
    clk:
        Clock signal.
    rst:
        Reset signal.
    reset_style:
        Synchronous or asynchronous reset.
    active_low_reset:
        If True, reset is active when ``rst == '0'``.

    Returns
    -------
    internal_signals:
        State register + grant register.  Caller should add them to the
        module via ``module.add_signal()``.
    body_nodes:
        ``Always`` blocks that implement the FSM.  Caller should add
        them via ``module.add_block()``.

    Raises
    ------
    ValueError
        If ``num_masters`` is not in [2, 8].
    """
    n = len(masters)
    if n < 2 or n > 8:
        raise ValueError(f"num_masters must be in [2, 8], got {n}")

    gw = _grant_width(n)

    # Resolve slave signals
    _, _slv = BB.resolve_signals(slave)

    # Create internal registers
    internal_signals, r = BB.create_registers([
        ("state", _STATE_WIDTH, ArbiterState.IDLE),
        ("grant_reg", gw, 0),
    ])
    state_reg = r["state"]
    grant_reg = r["grant_reg"]

    # -- Build reset statements ----------------------------------------
    reset_stmts: List[HdlNode] = BB.build_reset_stmts_raw([
        (state_reg, ArbiterState.IDLE),
        (grant_reg, 0),
        (_slv("write"), 0),
        (_slv("read"), 0),
        (_slv("address"), 0),
        (_slv("writedata"), 0),
        (_slv("byteenable"), 0),
    ])
    # Drive all master waitrequests high on reset
    for m in masters:
        _, m_lookup = BB.resolve_signals(m)
        reset_stmts.append(NonBlockingAssign(m_lookup("waitrequest"), 1))
        reset_stmts.append(NonBlockingAssign(m_lookup("readdata"), 0))
        reset_stmts.append(NonBlockingAssign(m_lookup("readdatavalid"), 0))
        reset_stmts.append(NonBlockingAssign(m_lookup("response"), 0))

    # -- FSM body ------------------------------------------------------

    # IDLE: scan for requesting master
    idle_body: List[HdlNode] = [
        NonBlockingAssign(_slv("write"), 0),
        NonBlockingAssign(_slv("read"), 0),
    ]
    # Drive all master waitrequests high while idle
    for m in masters:
        _, m_lookup = BB.resolve_signals(m)
        idle_body.append(NonBlockingAssign(m_lookup("waitrequest"), 1))
        idle_body.append(NonBlockingAssign(m_lookup("readdatavalid"), 0))

    # Round-robin scan
    idle_body.extend(_build_round_robin_scan(grant_reg, masters, state_reg, grant_reg))

    # GRANT: mux signals through and transition to LOCKED
    grant_body: List[HdlNode] = []
    grant_body.extend(_build_mux_assignments(grant_reg, masters, slave))
    grant_body.extend(_build_waitrequest_fanout(grant_reg, masters, slave))
    grant_body.extend(_build_readdata_fanout(grant_reg, masters, slave))
    grant_body.append(NonBlockingAssign(state_reg, ArbiterState.LOCKED))

    # LOCKED: hold grant until slave completes (waitrequest deasserted)
    locked_body: List[HdlNode] = []
    locked_body.extend(_build_mux_assignments(grant_reg, masters, slave))
    locked_body.extend(_build_waitrequest_fanout(grant_reg, masters, slave))
    locked_body.extend(_build_readdata_fanout(grant_reg, masters, slave))
    locked_body.append(
        If(
            f"!{_slv('waitrequest').name}",
            then_body=[NonBlockingAssign(state_reg, ArbiterState.COMPLETE)],
        )
    )

    # COMPLETE: rotate pointer and return to IDLE
    next_grant_expr = (
        f"({grant_reg.name} == {n - 1}) ? 0 : {grant_reg.name} + 1"
    )
    complete_body: List[HdlNode] = [
        NonBlockingAssign(_slv("write"), 0),
        NonBlockingAssign(_slv("read"), 0),
        NonBlockingAssign(grant_reg, next_grant_expr),
        NonBlockingAssign(state_reg, ArbiterState.IDLE),
    ]

    # Assemble FSM
    fsm_always = BB.build_fsm(state_reg, [
        (ArbiterState.IDLE, idle_body),
        (ArbiterState.GRANT, grant_body),
        (ArbiterState.LOCKED, locked_body),
        (ArbiterState.COMPLETE, complete_body),
    ], ArbiterState.IDLE, clk, rst, reset_style, active_low_reset, reset_stmts)

    return internal_signals, [fsm_always]
