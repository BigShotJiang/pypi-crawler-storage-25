# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
pipeline.py — Register Slice / Pipeline Stage Builder
======================================================

Timing strategy layer for the RTL bridge generator.

A ``RegisterSlice`` inserts one or more flip-flop stages between a set of
signals to break long combinational paths and improve timing closure.  Each
stage adds exactly one clock cycle of latency.

The builder generates:
  * One intermediate ``Signal`` per stage per input signal (named
    ``<sig>_s<N>`` for stage N).
  * One ``Always`` block per stage containing ``NonBlockingAssign`` nodes
    for every signal in that stage.

The consumer adds the returned signals and blocks to a ``Module``::

    builder = RegisterSliceBuilder(
        signals=[axi.awaddr, axi.awvalid, axi.awready],
        stages=2,
        clk=clk,
        rst_n=rst_n,
        reset_style=ResetStyle.ASYNC,
    )
    inter_sigs, always_blocks = builder.build()

    for sig in inter_sigs:
        module.add_signal(sig)
    for blk in always_blocks:
        module.add_block(blk)

    # The final stage outputs are builder.outputs — use these as the
    # source signals for downstream logic.

Pipeline position:
    Logic Layer → [THIS MODULE] → Backend (Emitter)
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional, Tuple

from hdl_ast import (
    Always,
    Direction,
    Edge,
    HdlNode,
    NonBlockingAssign,
    ResetStyle,
    Signal,
)

# ---------------------------------------------------------------------------
# PipelineStage descriptor
# ---------------------------------------------------------------------------


@dataclass
class PipelineStage:
    """Describes one register slice stage.

    Attributes
    ----------
    stage_id:
        Zero-based stage index (0 = closest to the source / master side).
    inputs:
        Signals entering this stage (outputs of the previous stage, or the
        original signals for stage 0).
    outputs:
        Intermediate ``Signal`` objects created by this stage.  These are
        ``Direction.LOCAL`` signals named ``<original>_s<stage_id + 1>``.
    always_block:
        The ``Always`` node that registers the inputs into the outputs.
    """

    stage_id: int
    inputs: List[Signal]
    outputs: List[Signal]
    always_block: Always


# ---------------------------------------------------------------------------
# RegisterSliceBuilder
# ---------------------------------------------------------------------------


class RegisterSliceBuilder:
    """Builds a chain of register-slice stages for a set of signals.

    Parameters
    ----------
    signals:
        The signals to pipeline.  These are the *source* signals (stage 0
        inputs).  They must already be declared as ports or local signals
        in the target module.
    stages:
        Number of register stages to insert.  ``0`` means no pipelining
        (``build()`` returns empty lists and ``outputs`` equals ``signals``).
    clk:
        Clock signal for the ``Always`` sensitivity list.
    rst_n:
        Reset signal.  Used to drive all outputs to their ``reset_val``
        on reset.  Pass ``None`` to omit the reset branch entirely.
    reset_style:
        ``ResetStyle.SYNC`` — reset is inside the clocked ``always`` block.
        ``ResetStyle.ASYNC`` — reset is added to the sensitivity list as
        ``negedge rst_n`` (active-low) or ``posedge rst`` (active-high).
    active_low_reset:
        When ``True`` (default), the reset condition is ``!rst_n``
        (active-low).  When ``False``, it is ``rst`` (active-high).
    """

    def __init__(
        self,
        signals: List[Signal],
        stages: int,
        clk: Signal,
        rst_n: Optional[Signal] = None,
        reset_style: ResetStyle = ResetStyle.SYNC,
        active_low_reset: bool = True,
    ) -> None:
        """Create a pipeline stage configuration."""
        if stages < 0:
            raise ValueError(f"stages must be >= 0, got {stages}")
        if not signals:
            raise ValueError("signals list must not be empty")

        self.signals = signals
        self.stages = stages
        self.clk = clk
        self.rst_n = rst_n
        self.reset_style = reset_style
        self.active_low_reset = active_low_reset

        # Original base names — used to build stage signal names so that
        # stage N always produces "<original>_sN" rather than accumulating
        # suffixes like "<sig>_s1_s2_s3".
        self._base_names: List[str] = [s.name for s in signals]

        # Populated by build()
        self._pipeline_stages: List[PipelineStage] = []
        self._built = False

    # ------------------------------------------------------------------
    # Build
    # ------------------------------------------------------------------

    def build(self) -> Tuple[List[Signal], List[Always]]:
        """Generate intermediate signals and Always blocks.

        Returns
        -------
        intermediate_signals:
            All ``Direction.LOCAL`` signals created for the pipeline
            registers.  Add these to the module with ``add_signal()``.
        always_blocks:
            One ``Always`` block per stage.  Add these to the module
            with ``add_block()``.

        After calling ``build()``, use ``self.outputs`` to get the final
        stage output signals (the ones to connect to downstream logic).
        """
        if self._built:
            raise RuntimeError("build() has already been called on this builder")
        self._built = True

        if self.stages == 0:
            return [], []

        all_inter_sigs: List[Signal] = []
        all_always: List[Always] = []

        current_inputs = list(self.signals)

        for stage_idx in range(self.stages):
            stage_outputs = self._make_stage_signals(current_inputs, stage_idx + 1)
            always_blk = self._make_always(current_inputs, stage_outputs)

            self._pipeline_stages.append(
                PipelineStage(
                    stage_id=stage_idx,
                    inputs=current_inputs,
                    outputs=stage_outputs,
                    always_block=always_blk,
                )
            )

            all_inter_sigs.extend(stage_outputs)
            all_always.append(always_blk)
            current_inputs = stage_outputs

        return all_inter_sigs, all_always

    # ------------------------------------------------------------------
    # Output accessor
    # ------------------------------------------------------------------

    @property
    def outputs(self) -> List[Signal]:
        """The final stage output signals.

        These are the signals that downstream logic should read.
        If ``stages == 0``, returns the original ``signals`` list.

        Raises
        ------
        RuntimeError
            If ``build()`` has not been called yet.
        """
        if not self._built:
            raise RuntimeError("Call build() before accessing outputs")
        if not self._pipeline_stages:
            return list(self.signals)
        return list(self._pipeline_stages[-1].outputs)

    @property
    def pipeline_stages(self) -> List[PipelineStage]:
        """The list of ``PipelineStage`` descriptors, in order."""
        if not self._built:
            raise RuntimeError("Call build() before accessing pipeline_stages")
        return list(self._pipeline_stages)

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _make_stage_signals(self, sources: List[Signal], stage_num: int) -> List[Signal]:
        """Create LOCAL signals for one pipeline stage.

        Names are always derived from the *original* signal names
        (``self._base_names``) so that stage N produces
        ``<original>_sN`` rather than ``<prev_stage>_sN``.
        """
        result: List[Signal] = []
        for base_name, src in zip(self._base_names, sources):
            name = f"{base_name}_s{stage_num}"
            sig = Signal(
                name=name,
                width=src.width,
                direction=Direction.LOCAL,
                reset_val=src.reset_val,
            )
            result.append(sig)
        return result

    def _make_always(self, inputs: List[Signal], outputs: List[Signal]) -> Always:
        """Build the Always block for one pipeline stage."""
        sensitivity = self._build_sensitivity()
        reset_cond = self._reset_condition()
        body: List[HdlNode] = []

        if self.rst_n is not None:
            # Reset branch: drive all outputs to reset_val
            reset_stmts = [NonBlockingAssign(out, out.reset_val) for out in outputs]
            # Normal branch: register inputs into outputs
            normal_stmts = [NonBlockingAssign(out, inp) for inp, out in zip(inputs, outputs)]
            from hdl_ast import If

            body.append(
                If(
                    condition=reset_cond,
                    then_body=reset_stmts,
                    else_body=normal_stmts,
                )
            )
        else:
            # No reset: just register
            body = [NonBlockingAssign(out, inp) for inp, out in zip(inputs, outputs)]

        return Always(sensitivity=sensitivity, body=body)

    def _build_sensitivity(self) -> list:
        """Build the sensitivity list for the Always block."""
        sens = [(Edge.POSEDGE, self.clk)]
        if self.rst_n is not None and self.reset_style == ResetStyle.ASYNC:
            rst_edge = Edge.NEGEDGE if self.active_low_reset else Edge.POSEDGE
            sens.append((rst_edge, self.rst_n))
        return sens

    def _reset_condition(self) -> str:
        """Return the reset condition string for the If node."""
        if self.rst_n is None:
            return "1'b0"  # never (no reset)
        if self.active_low_reset:
            return f"!{self.rst_n.name}"
        return self.rst_n.name

    def __repr__(self) -> str:
        return (
            f"RegisterSliceBuilder("
            f"signals={len(self.signals)}, "
            f"stages={self.stages}, "
            f"clk={self.clk.name!r}, "
            f"reset_style={self.reset_style.name})"
        )


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

__all__ = [
    "PipelineStage",
    "RegisterSliceBuilder",
]
