# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
test_validator.py — Unit tests for validator.py
================================================

Run with:
    python -m pytest sdk/generators/bridge/test_validator.py -v
"""

import pytest
from addr_map import AddressMap
from bus_interfaces import AvalonMMInterface, AXILiteInterface, InterfaceRole, NativeMemInterface
from hdl_ast import (
    Always,
    Assign,
    Direction,
    Edge,
    Module,
    NonBlockingAssign,
    Signal,
)
from validator import SvaProperty, ValidationError, Validator

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_module_with_assign(src_width: int, dst_width: int) -> tuple:
    """Return (module, src_sig, dst_sig) with one Assign node."""
    src = Signal("src", width=src_width, direction=Direction.INPUT)
    dst = Signal("dst", width=dst_width, direction=Direction.OUTPUT)
    m = Module("dut", ports=[src, dst], body=[Assign(target=dst, source=src)])
    return m, src, dst


def _make_minimal_axi_module(
    axi: AXILiteInterface,
    clk: Signal,
    rst_n: Signal,
) -> Module:
    """Build a module that uses every AXI handshake signal in an Always block."""
    m = Module("dut")
    m.add_port(clk)
    m.add_port(rst_n)
    for sig in axi.get_signals():
        m.add_port(sig)

    # Drive every handshake signal so the handshake check passes
    handshake_shorts = [
        "awvalid",
        "awready",
        "wvalid",
        "wready",
        "bvalid",
        "bready",
        "arvalid",
        "arready",
        "rvalid",
        "rready",
    ]
    stmts = []
    for short in handshake_shorts:
        sig = axi._signals[short]
        stmts.append(NonBlockingAssign(sig, 0))

    blk = Always([(Edge.POSEDGE, clk)], body=stmts)
    m.add_block(blk)
    return m


def _make_minimal_avalon_module(
    avl: AvalonMMInterface,
    clk: Signal,
    rst_n: Signal,
) -> Module:
    """Build a module that uses every Avalon flow-control signal in an Always block."""
    m = Module("dut")
    m.add_port(clk)
    m.add_port(rst_n)
    for sig in avl.get_signals():
        m.add_port(sig)

    # Drive every flow-control signal so the waitrequest check passes
    flow_shorts = ["waitrequest", "read", "write", "readdatavalid"]
    stmts = []
    for short in flow_shorts:
        sig = avl._signals[short]
        stmts.append(NonBlockingAssign(sig, 0))

    blk = Always([(Edge.POSEDGE, clk)], body=stmts)
    m.add_block(blk)
    return m


# ===========================================================================
# ValidationError
# ===========================================================================


class TestValidationError:
    def test_is_value_error(self) -> None:
        err = ValidationError("width", ["sig a is 8 bits, source is 16 bits"])
        assert isinstance(err, ValueError)

    def test_check_attribute(self) -> None:
        err = ValidationError("handshake", ["awvalid unused"])
        assert err.check == "handshake"

    def test_details_attribute(self) -> None:
        details = ["problem 1", "problem 2"]
        err = ValidationError("width", details)
        assert err.details == details

    def test_message_contains_check_name(self) -> None:
        err = ValidationError("width", ["mismatch"])
        assert "width" in str(err)

    def test_message_contains_detail(self) -> None:
        err = ValidationError("width", ["sig x is 8 bits"])
        assert "sig x" in str(err)


# ===========================================================================
# SvaProperty
# ===========================================================================


class TestSvaProperty:
    def test_render_contains_property_name(self) -> None:
        p = SvaProperty(name="my_prop", body="@(posedge clk) a |=> b;")
        rendered = p.render()
        assert "my_prop" in rendered

    def test_render_contains_body(self) -> None:
        p = SvaProperty(name="p", body="@(posedge clk) a |=> b;")
        assert "a |=> b" in p.render()

    def test_render_contains_assert(self) -> None:
        p = SvaProperty(name="p", body="@(posedge clk) a |=> b;")
        assert "assert property" in p.render()

    def test_render_assume_severity(self) -> None:
        p = SvaProperty(name="p", body="x;", severity="assume")
        assert "assume property" in p.render()

    def test_render_comment(self) -> None:
        p = SvaProperty(name="p", body="x;", comment="My comment")
        assert "My comment" in p.render()

    def test_render_no_comment(self) -> None:
        p = SvaProperty(name="p", body="x;", comment="")
        assert "//" not in p.render()

    def test_render_endproperty(self) -> None:
        p = SvaProperty(name="p", body="x;")
        assert "endproperty" in p.render()

    def test_render_indentation(self) -> None:
        p = SvaProperty(name="p", body="x;")
        rendered = p.render(indent=8)
        assert rendered.startswith(" " * 8)


# ===========================================================================
# Validator.check_widths
# ===========================================================================


class TestCheckWidths:
    def test_matching_widths_pass(self) -> None:
        m, _, _ = _make_module_with_assign(8, 8)
        Validator(m).check_widths()  # must not raise

    def test_mismatched_widths_raise(self) -> None:
        m, _, _ = _make_module_with_assign(8, 16)
        with pytest.raises(ValidationError) as exc_info:
            Validator(m).check_widths()
        assert exc_info.value.check == "width"
        assert len(exc_info.value.details) == 1

    def test_error_message_mentions_signal_name(self) -> None:
        m, _, _ = _make_module_with_assign(8, 16)
        with pytest.raises(ValidationError) as exc_info:
            Validator(m).check_widths()
        assert "dst" in str(exc_info.value)

    def test_multiple_mismatches_all_reported(self) -> None:
        src1 = Signal("s1", width=4, direction=Direction.INPUT)
        dst1 = Signal("d1", width=8, direction=Direction.OUTPUT)
        src2 = Signal("s2", width=16, direction=Direction.INPUT)
        dst2 = Signal("d2", width=32, direction=Direction.OUTPUT)
        m = Module("dut", ports=[src1, dst1, src2, dst2], body=[Assign(dst1, src1), Assign(dst2, src2)])
        with pytest.raises(ValidationError) as exc_info:
            Validator(m).check_widths()
        assert len(exc_info.value.details) == 2

    def test_string_source_skipped(self) -> None:
        """String RHS has unknown width — should not raise."""
        dst = Signal("dst", width=8, direction=Direction.OUTPUT)
        m = Module("dut", ports=[dst], body=[Assign(dst, "some_expr")])
        Validator(m).check_widths()  # must not raise

    def test_int_source_skipped(self) -> None:
        """Integer literal has unknown width — should not raise."""
        dst = Signal("dst", width=8, direction=Direction.OUTPUT)
        m = Module("dut", ports=[dst], body=[Assign(dst, 0)])
        Validator(m).check_widths()  # must not raise

    def test_nonblocking_assign_checked(self) -> None:
        clk = Signal("clk", direction=Direction.INPUT)
        src = Signal("src", width=4, direction=Direction.INPUT)
        dst = Signal("dst", width=8, direction=Direction.OUTPUT)
        blk = Always([(Edge.POSEDGE, clk)], body=[NonBlockingAssign(dst, src)])
        m = Module("dut", ports=[clk, src, dst], body=[blk])
        with pytest.raises(ValidationError) as exc_info:
            Validator(m).check_widths()
        assert exc_info.value.check == "width"

    def test_slice_target_width_used(self) -> None:
        """Slice[7:4] is 4 bits; source of 8 bits should raise."""
        src = Signal("src", width=8, direction=Direction.INPUT)
        dst = Signal("dst", width=8, direction=Direction.OUTPUT)
        m = Module("dut", ports=[src, dst], body=[Assign(dst[7:4], src)])  # 4-bit target, 8-bit source
        with pytest.raises(ValidationError):
            Validator(m).check_widths()

    def test_empty_module_passes(self) -> None:
        m = Module("empty")
        Validator(m).check_widths()  # must not raise


# ===========================================================================
# Validator.check_handshakes
# ===========================================================================


class TestCheckHandshakes:
    def test_all_handshakes_used_passes(self) -> None:
        clk = Signal("clk", direction=Direction.INPUT)
        rst_n = Signal("rst_n", direction=Direction.INPUT)
        axi = AXILiteInterface(data_width=32, addr_width=16, role=InterfaceRole.SLAVE, prefix="s")
        m = _make_minimal_axi_module(axi, clk, rst_n)
        Validator(m).check_handshakes([axi])  # must not raise

    def test_missing_handshake_raises(self) -> None:
        """Module with no logic at all — all handshakes are floating."""
        axi = AXILiteInterface(data_width=32, addr_width=16, role=InterfaceRole.SLAVE, prefix="s")
        m = Module("dut")
        for sig in axi.get_signals():
            m.add_port(sig)
        # No body — all handshake signals are unused
        with pytest.raises(ValidationError) as exc_info:
            Validator(m).check_handshakes([axi])
        assert exc_info.value.check == "handshake"
        # All 10 handshake signals should be reported
        assert len(exc_info.value.details) == 10

    def test_error_mentions_signal_name(self) -> None:
        axi = AXILiteInterface(data_width=32, addr_width=16, role=InterfaceRole.SLAVE, prefix="s")
        m = Module("dut")
        for sig in axi.get_signals():
            m.add_port(sig)
        with pytest.raises(ValidationError) as exc_info:
            Validator(m).check_handshakes([axi])
        assert "s_awvalid" in str(exc_info.value)

    def test_continuous_assign_counts_as_used(self) -> None:
        """Signals driven by continuous assign are considered 'used'."""
        axi = AXILiteInterface(data_width=32, addr_width=16, role=InterfaceRole.SLAVE, prefix="s")
        m = Module("dut")
        for sig in axi.get_signals():
            m.add_port(sig)
        # Drive every handshake signal with a continuous assign
        for short in [
            "awvalid",
            "awready",
            "wvalid",
            "wready",
            "bvalid",
            "bready",
            "arvalid",
            "arready",
            "rvalid",
            "rready",
        ]:
            m.add_block(Assign(axi._signals[short], 0))
        Validator(m).check_handshakes([axi])  # must not raise

    def test_no_interfaces_passes(self) -> None:
        m = Module("dut")
        Validator(m).check_handshakes([])  # must not raise


# ===========================================================================
# Validator.check_waitrequest (Avalon-MM)
# ===========================================================================


class TestCheckWaitrequest:
    def test_all_flow_signals_used_passes(self) -> None:
        clk = Signal("clk", direction=Direction.INPUT)
        rst_n = Signal("rst_n", direction=Direction.INPUT)
        avl = AvalonMMInterface(data_width=32, addr_width=16, role=InterfaceRole.SLAVE, prefix="avl")
        m = _make_minimal_avalon_module(avl, clk, rst_n)
        Validator(m).check_waitrequest([avl])  # must not raise

    def test_missing_flow_signals_raises(self) -> None:
        """Module with no logic at all — all flow signals are floating."""
        avl = AvalonMMInterface(data_width=32, addr_width=16, role=InterfaceRole.SLAVE, prefix="avl")
        m = Module("dut")
        for sig in avl.get_signals():
            m.add_port(sig)
        # No body — all flow-control signals are unused
        with pytest.raises(ValidationError) as exc_info:
            Validator(m).check_waitrequest([avl])
        assert exc_info.value.check == "waitrequest"
        # All 4 flow-control signals should be reported
        assert len(exc_info.value.details) == 4

    def test_error_mentions_signal_name(self) -> None:
        avl = AvalonMMInterface(data_width=32, addr_width=16, role=InterfaceRole.SLAVE, prefix="avl")
        m = Module("dut")
        for sig in avl.get_signals():
            m.add_port(sig)
        with pytest.raises(ValidationError) as exc_info:
            Validator(m).check_waitrequest([avl])
        assert "avl_waitrequest" in str(exc_info.value)

    def test_continuous_assign_counts_as_used(self) -> None:
        """Signals driven by continuous assign are considered 'used'."""
        avl = AvalonMMInterface(data_width=32, addr_width=16, role=InterfaceRole.SLAVE, prefix="avl")
        m = Module("dut")
        for sig in avl.get_signals():
            m.add_port(sig)
        # Drive every flow-control signal with a continuous assign
        for short in ["waitrequest", "read", "write", "readdatavalid"]:
            m.add_block(Assign(avl._signals[short], 0))
        Validator(m).check_waitrequest([avl])  # must not raise

    def test_no_interfaces_passes(self) -> None:
        m = Module("dut")
        Validator(m).check_waitrequest([])  # must not raise

    def test_partial_missing_reports_subset(self) -> None:
        """Only missing signals are reported, not the ones that are used."""
        clk = Signal("clk", direction=Direction.INPUT)
        avl = AvalonMMInterface(data_width=32, addr_width=16, role=InterfaceRole.SLAVE, prefix="avl")
        m = Module("dut")
        for sig in avl.get_signals():
            m.add_port(sig)
        # Only use "read" and "write" — leave "waitrequest" and "readdatavalid" floating
        stmts = [
            NonBlockingAssign(avl._signals["read"], 0),
            NonBlockingAssign(avl._signals["write"], 0),
        ]
        blk = Always([(Edge.POSEDGE, clk)], body=stmts)
        m.add_port(clk)
        m.add_block(blk)

        with pytest.raises(ValidationError) as exc_info:
            Validator(m).check_waitrequest([avl])
        assert len(exc_info.value.details) == 2
        assert any("waitrequest" in d for d in exc_info.value.details)
        assert any("readdatavalid" in d for d in exc_info.value.details)


# ===========================================================================
# Validator.check_address_bounds
# ===========================================================================


class TestCheckAddressBounds:
    def _make_pair(self, am_words: int, nat_aw: int, dw: int = 32) -> tuple:
        size_bytes = am_words * (dw // 8)
        # addr_width for AddressMap must be large enough to hold am_words
        am_aw = max(1, (am_words - 1).bit_length())
        am = AddressMap(data_width=dw, addr_width=am_aw, size_bytes=size_bytes)
        nat = NativeMemInterface(data_width=dw, addr_width=nat_aw, role=InterfaceRole.MASTER)
        return am, nat

    def test_exact_fit_passes(self) -> None:
        am, nat = self._make_pair(am_words=1024, nat_aw=10)
        m = Module("dut")
        Validator(m).check_address_bounds(am, nat)  # must not raise

    def test_nat_larger_passes(self) -> None:
        am, nat = self._make_pair(am_words=512, nat_aw=10)
        m = Module("dut")
        Validator(m).check_address_bounds(am, nat)  # must not raise

    def test_overflow_raises(self) -> None:
        # 1025 words but native only has 10-bit addr (1024 words)
        am = AddressMap(data_width=32, addr_width=11, size_bytes=1025 * 4)
        nat = NativeMemInterface(data_width=32, addr_width=10, role=InterfaceRole.MASTER)
        m = Module("dut")
        with pytest.raises(ValidationError) as exc_info:
            Validator(m).check_address_bounds(am, nat)
        assert exc_info.value.check == "address_bounds"

    def test_data_width_mismatch_raises(self) -> None:
        am = AddressMap(data_width=32, addr_width=10)
        nat = NativeMemInterface(data_width=64, addr_width=10, role=InterfaceRole.MASTER)
        m = Module("dut")
        with pytest.raises(ValidationError) as exc_info:
            Validator(m).check_address_bounds(am, nat)
        assert "data_width" in str(exc_info.value)

    def test_error_mentions_word_counts(self) -> None:
        am = AddressMap(data_width=32, addr_width=11, size_bytes=1025 * 4)
        nat = NativeMemInterface(data_width=32, addr_width=10, role=InterfaceRole.MASTER)
        m = Module("dut")
        with pytest.raises(ValidationError) as exc_info:
            Validator(m).check_address_bounds(am, nat)
        assert "1025" in str(exc_info.value) or "1024" in str(exc_info.value)


# ===========================================================================
# Validator.inject_sva
# ===========================================================================


class TestInjectSva:
    def _axi(self, prefix: str = "s") -> AXILiteInterface:
        return AXILiteInterface(data_width=32, addr_width=16, role=InterfaceRole.SLAVE, prefix=prefix)

    def test_returns_five_properties(self) -> None:
        m = Module("dut")
        props = Validator(m).inject_sva(self._axi())
        assert len(props) == 5

    def test_all_are_sva_property(self) -> None:
        m = Module("dut")
        for p in Validator(m).inject_sva(self._axi()):
            assert isinstance(p, SvaProperty)

    def test_property_names_unique(self) -> None:
        m = Module("dut")
        props = Validator(m).inject_sva(self._axi())
        names = [p.name for p in props]
        assert len(names) == len(set(names))

    def test_property_names_contain_prefix(self) -> None:
        m = Module("dut")
        props = Validator(m).inject_sva(self._axi(prefix="s_axi"))
        for p in props:
            assert "s_axi" in p.name

    def test_body_contains_valid_signal(self) -> None:
        m = Module("dut")
        props = Validator(m).inject_sva(self._axi(prefix="s"))
        # AW channel property should reference s_awvalid
        aw_prop = next(p for p in props if "aw" in p.name)
        assert "s_awvalid" in aw_prop.body

    def test_body_contains_ready_signal(self) -> None:
        m = Module("dut")
        props = Validator(m).inject_sva(self._axi(prefix="s"))
        aw_prop = next(p for p in props if "aw" in p.name)
        assert "s_awready" in aw_prop.body

    def test_body_contains_implication(self) -> None:
        m = Module("dut")
        props = Validator(m).inject_sva(self._axi())
        for p in props:
            assert "|=>" in p.body

    def test_active_low_reset(self) -> None:
        m = Module("dut")
        props = Validator(m).inject_sva(self._axi(), rst_name="rst_n", active_low_reset=True)
        for p in props:
            assert "!rst_n" in p.body

    def test_active_high_reset(self) -> None:
        m = Module("dut")
        props = Validator(m).inject_sva(self._axi(), rst_name="rst", active_low_reset=False)
        for p in props:
            assert "rst" in p.body
            assert "!rst" not in p.body

    def test_custom_clk_name(self) -> None:
        m = Module("dut")
        props = Validator(m).inject_sva(self._axi(), clk_name="sys_clk")
        for p in props:
            assert "sys_clk" in p.body

    def test_render_produces_string(self) -> None:
        m = Module("dut")
        props = Validator(m).inject_sva(self._axi())
        for p in props:
            rendered = p.render()
            assert isinstance(rendered, str)
            assert len(rendered) > 0

    def test_no_prefix_property_names(self) -> None:
        m = Module("dut")
        axi = AXILiteInterface(data_width=32, addr_width=16, role=InterfaceRole.SLAVE, prefix="")
        props = Validator(m).inject_sva(axi)
        for p in props:
            assert p.name.startswith("axi_")


# ===========================================================================
# Validator.run_all
# ===========================================================================


class TestRunAll:
    def test_run_all_no_errors(self) -> None:
        clk = Signal("clk", direction=Direction.INPUT)
        rst_n = Signal("rst_n", direction=Direction.INPUT)
        axi = AXILiteInterface(data_width=32, addr_width=16, role=InterfaceRole.SLAVE, prefix="s")
        nat = NativeMemInterface(data_width=32, addr_width=14, role=InterfaceRole.MASTER, prefix="mem")
        am = AddressMap(data_width=32, addr_width=14)

        m = _make_minimal_axi_module(axi, clk, rst_n)
        for sig in nat.get_signals():
            m.add_port(sig)

        v = Validator(m)
        sva = v.run_all(axi_interfaces=[axi], addr_map=am, native=nat)
        assert len(sva) == 5  # one per AXI channel

    def test_run_all_with_avalon_interfaces(self) -> None:
        clk = Signal("clk", direction=Direction.INPUT)
        rst_n = Signal("rst_n", direction=Direction.INPUT)
        avl = AvalonMMInterface(data_width=32, addr_width=16, role=InterfaceRole.SLAVE, prefix="avl")
        m = _make_minimal_avalon_module(avl, clk, rst_n)
        v = Validator(m)
        sva = v.run_all(avalon_interfaces=[avl])
        # No SVA for Avalon (only AXI gets SVA), so empty list
        assert sva == []

    def test_run_all_width_error_propagates(self) -> None:
        src = Signal("src", width=4, direction=Direction.INPUT)
        dst = Signal("dst", width=8, direction=Direction.OUTPUT)
        m = Module("dut", ports=[src, dst], body=[Assign(dst, src)])
        with pytest.raises(ValidationError) as exc_info:
            Validator(m).run_all()
        assert exc_info.value.check == "width"

    def test_run_all_no_interfaces_returns_empty_sva(self) -> None:
        m = Module("dut")
        sva = Validator(m).run_all()
        assert sva == []


# ===========================================================================
# Integration: full generation flow
# ===========================================================================


class TestIntegrationFlow:
    def test_generation_flow(self) -> None:
        """Simulate the complete validate → SVA inject flow."""
        # 1. Build interfaces
        axi = AXILiteInterface(data_width=32, addr_width=16, role=InterfaceRole.SLAVE, prefix="s_axi")
        nat = NativeMemInterface(data_width=32, addr_width=14, role=InterfaceRole.MASTER, prefix="mem")
        am = AddressMap(data_width=32, addr_width=14)

        clk = Signal("clk", direction=Direction.INPUT)
        rst_n = Signal("rst_n", direction=Direction.INPUT)

        # 2. Build module
        m = _make_minimal_axi_module(axi, clk, rst_n)
        for sig in nat.get_signals():
            m.add_port(sig)

        # 3. Validate
        v = Validator(m)
        v.check_widths()
        v.check_handshakes([axi])
        v.check_address_bounds(am, nat)

        # 4. Inject SVA
        sva_props = v.inject_sva(axi, clk_name="clk", rst_name="rst_n")

        # 5. Verify SVA output
        assert len(sva_props) == 5
        full_output = "\n".join(p.render() for p in sva_props)
        assert "s_axi_awvalid" in full_output
        assert "|=>" in full_output
        assert "endproperty" in full_output

    def test_avalon_generation_flow(self) -> None:
        """Simulate a complete Avalon validate flow."""
        avl = AvalonMMInterface(data_width=32, addr_width=16, role=InterfaceRole.SLAVE, prefix="avl")
        clk = Signal("clk", direction=Direction.INPUT)
        rst_n = Signal("rst_n", direction=Direction.INPUT)

        m = _make_minimal_avalon_module(avl, clk, rst_n)

        v = Validator(m)
        v.check_widths()
        v.check_waitrequest([avl])
