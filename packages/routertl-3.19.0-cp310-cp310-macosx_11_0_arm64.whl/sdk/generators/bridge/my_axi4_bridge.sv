// SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
// SPDX-License-Identifier: MIT

// ====================================================================
// Auto-generated SystemVerilog — DO NOT EDIT
// Generated: 2026-02-20 03:11:19 UTC
// Parameters:
//   Base Address: 0
//   Data Width: 32
//   Protocol: axi4
// ====================================================================

module my_axi4_bridge (
    // Inputs
    input  logic        clk,
    input  logic        rst_n,
    input  logic [3:0] s_axi_awid,
    input  logic [31:0] s_axi_awaddr,
    input  logic [7:0] s_axi_awlen,
    input  logic [2:0] s_axi_awsize,
    input  logic [1:0] s_axi_awburst,
    input  logic [2:0] s_axi_awprot,
    input  logic [3:0] s_axi_awcache,
    input  logic [3:0] s_axi_awqos,
    input  logic        s_axi_awvalid,
    input  logic [31:0] s_axi_wdata,
    input  logic [3:0] s_axi_wstrb,
    input  logic        s_axi_wlast,
    input  logic        s_axi_wvalid,
    input  logic        s_axi_bready,
    input  logic [3:0] s_axi_arid,
    input  logic [31:0] s_axi_araddr,
    input  logic [7:0] s_axi_arlen,
    input  logic [2:0] s_axi_arsize,
    input  logic [1:0] s_axi_arburst,
    input  logic [2:0] s_axi_arprot,
    input  logic [3:0] s_axi_arcache,
    input  logic [3:0] s_axi_arqos,
    input  logic        s_axi_arvalid,
    input  logic        s_axi_rready,
    input  logic [31:0] m_mem_dout,
    input  logic        m_mem_ack,

    // Outputs
    output logic        s_axi_awready,
    output logic        s_axi_wready,
    output logic [3:0] s_axi_bid,
    output logic [1:0] s_axi_bresp,
    output logic        s_axi_bvalid,
    output logic        s_axi_arready,
    output logic [3:0] s_axi_rid,
    output logic [31:0] s_axi_rdata,
    output logic [1:0] s_axi_rresp,
    output logic        s_axi_rlast,
    output logic        s_axi_rvalid,
    output logic [29:0] m_mem_addr,
    output logic [31:0] m_mem_din,
    output logic [3:0] m_mem_we,
    output logic        m_mem_re,
    output logic        m_mem_cs
);

    // Enums
    typedef enum logic [2:0] {
        IDLE = 3'd0,
        WR_ACCEPT = 3'd1,
        WR_DATA = 3'd2,
        WR_RESP = 3'd3,
        RD_ACCEPT = 3'd4,
        RD_CMD = 3'd5,
        RD_WAIT = 3'd6,
        RD_RESP = 3'd7
    } Axi4NativeState_t;

    // Internal signals
    Axi4NativeState_t state;
    logic [31:0] addr_reg;
    logic [7:0] beat_reg;
    logic [3:0] id_reg;
    logic [7:0] lat_reg;

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state <= IDLE;
            addr_reg <= 0;
            beat_reg <= 0;
            id_reg <= 0;
            lat_reg <= 0;
            s_axi_awready <= 0;
            s_axi_wready <= 0;
            s_axi_bvalid <= 0;
            s_axi_bresp <= 0;
            s_axi_bid <= 0;
            s_axi_arready <= 0;
            s_axi_rvalid <= 0;
            s_axi_rresp <= 0;
            s_axi_rid <= 0;
            s_axi_rlast <= 0;
            s_axi_rdata <= 0;
            m_mem_we <= 0;
            m_mem_re <= 0;
            m_mem_cs <= 0;
            m_mem_addr <= 0;
            m_mem_din <= 0;
        end else begin
            case (state)
                IDLE: begin
                    s_axi_awready <= 0;
                    s_axi_wready <= 0;
                    s_axi_bvalid <= 0;
                    s_axi_arready <= 0;
                    s_axi_rvalid <= 0;
                    m_mem_we <= 0;
                    m_mem_re <= 0;
                    m_mem_cs <= 0;
                    if (s_axi_awvalid) begin
                        addr_reg <= s_axi_awaddr;
                        beat_reg <= s_axi_awlen;
                        id_reg <= s_axi_awid;
                        state <= WR_ACCEPT;
                    end else begin
                        if (s_axi_arvalid) begin
                            addr_reg <= s_axi_araddr;
                            beat_reg <= s_axi_arlen;
                            id_reg <= s_axi_arid;
                            state <= RD_ACCEPT;
                        end
                    end
                end
                WR_ACCEPT: begin
                    s_axi_awready <= 1;
                    state <= WR_DATA;
                end
                WR_DATA: begin
                    s_axi_awready <= 0;
                    s_axi_wready <= 1;
                    m_mem_we <= 0;
                    m_mem_cs <= 0;
                    if (s_axi_wvalid & s_axi_wready) begin
                        m_mem_we <= s_axi_wstrb;
                        m_mem_cs <= 1;
                        m_mem_addr <= addr_reg[31:2];
                        m_mem_din <= s_axi_wdata;
                        addr_reg <= addr_reg + 4;
                        if (s_axi_wlast) begin
                            s_axi_wready <= 0;
                            state <= WR_RESP;
                        end else begin
                            beat_reg <= beat_reg - 1;
                        end
                    end
                end
                WR_RESP: begin
                    s_axi_wready <= 0;
                    m_mem_we <= 0;
                    m_mem_cs <= 0;
                    s_axi_bvalid <= 1;
                    s_axi_bresp <= 0;
                    s_axi_bid <= id_reg;
                    if (s_axi_bready) begin
                        state <= IDLE;
                    end
                end
                RD_ACCEPT: begin
                    s_axi_arready <= 1;
                    state <= RD_CMD;
                end
                RD_CMD: begin
                    s_axi_arready <= 0;
                    m_mem_re <= 1;
                    m_mem_cs <= 1;
                    m_mem_addr <= addr_reg[31:2];
                    lat_reg <= 2;
                    state <= RD_WAIT;
                end
                RD_WAIT: begin
                    m_mem_re <= 0;
                    m_mem_cs <= 0;
                    if (lat_reg == 0) begin
                        state <= RD_RESP;
                    end else begin
                        lat_reg <= lat_reg - 1;
                    end
                end
                RD_RESP: begin
                    s_axi_rvalid <= 1;
                    s_axi_rresp <= 0;
                    s_axi_rid <= id_reg;
                    s_axi_rdata <= m_mem_dout;
                    s_axi_rlast <= (beat_reg == 0);
                    if (s_axi_rready) begin
                        if ((beat_reg == 0)) begin
                            state <= IDLE;
                        end else begin
                            addr_reg <= addr_reg + 4;
                            beat_reg <= beat_reg - 1;
                            state <= RD_CMD;
                        end
                    end
                end
                default: begin
                    state <= IDLE;
                end
            endcase
        end
    end

endmodule
