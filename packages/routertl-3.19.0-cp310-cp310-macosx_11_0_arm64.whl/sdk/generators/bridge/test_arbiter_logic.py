# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
test_arbiter_logic.py — Unit tests for arbiter_logic.py
=======================================================

Run with:
    cd sdk/generators/bridge && python -m pytest test_arbiter_logic.py -v
"""

import pytest
from arbiter_logic import ArbiterState, _grant_width, build_avalon_arbiter
from bus_interfaces import AvalonMMInterface, InterfaceRole
from hdl_ast import (
    Always,
    Case,
    Direction,
    Edge,
    If,
    Module,
    NonBlockingAssign,
    ResetStyle,
    Signal,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _build(
    num_masters: int = 2,
    dw: int = 32,
    aw: int = 14,
    reset_style: ResetStyle = ResetStyle.SYNC,
    active_low_reset: bool = True,
):
    """Build the arbiter and return (signals, blocks, masters, slave, clk, rst)."""
    masters = [
        AvalonMMInterface(
            data_width=dw,
            addr_width=aw,
            role=InterfaceRole.SLAVE,
            prefix=f"m{i}_avl",
        )
        for i in range(num_masters)
    ]
    slave = AvalonMMInterface(
        data_width=dw,
        addr_width=aw,
        role=InterfaceRole.MASTER,
        prefix="s_avl",
    )
    clk = Signal("clk", direction=Direction.INPUT)
    rst = Signal("rst_n", direction=Direction.INPUT)
    signals, blocks = build_avalon_arbiter(
        masters,
        slave,
        clk,
        rst,
        reset_style=reset_style,
        active_low_reset=active_low_reset,
    )
    return signals, blocks, masters, slave, clk, rst


def _build_module(num_masters: int = 2, dw: int = 32, aw: int = 14):
    """Build a complete Module with the arbiter wired in."""
    signals, blocks, masters, slave, clk, rst = _build(
        num_masters=num_masters, dw=dw, aw=aw,
    )
    m = Module("test_arbiter")
    m.add_port(clk)
    m.add_port(rst)
    for master in masters:
        for s in master.get_signals():
            m.add_port(s)
    for s in slave.get_signals():
        m.add_port(s)
    for s in signals:
        m.add_signal(s)
    for b in blocks:
        m.add_block(b)
    return m, masters, slave


def _find_case(blocks):
    """Extract the Case node from the FSM always block."""
    assert len(blocks) >= 1
    always = blocks[0]
    assert isinstance(always, Always)
    fsm_if = always.body[0]
    assert isinstance(fsm_if, If)
    case_node = fsm_if.else_body[0]
    assert isinstance(case_node, Case)
    return case_node


def _find_reset_stmts(blocks):
    """Extract the reset branch statements."""
    always = blocks[0]
    fsm_if = always.body[0]
    return fsm_if.then_body


# ===========================================================================
# ArbiterState
# ===========================================================================


class TestArbiterState:
    def test_state_count(self):
        assert len(ArbiterState) == 4

    def test_idle_is_zero(self):
        assert ArbiterState.IDLE == 0

    def test_all_unique(self):
        values = [s.value for s in ArbiterState]
        assert len(values) == len(set(values))

    def test_fits_in_2_bits(self):
        for s in ArbiterState:
            assert s.value < 4


# ===========================================================================
# Grant width helper
# ===========================================================================


class TestGrantWidth:
    def test_2_masters(self):
        assert _grant_width(2) == 1

    def test_3_masters(self):
        assert _grant_width(3) == 2

    def test_4_masters(self):
        assert _grant_width(4) == 2

    def test_5_masters(self):
        assert _grant_width(5) == 3

    def test_8_masters(self):
        assert _grant_width(8) == 3


# ===========================================================================
# build_avalon_arbiter — Signal creation
# ===========================================================================


class TestArbiterSignals:
    def test_returns_two_signals(self):
        """state + grant_reg = 2 internal signals."""
        signals, _, _, _, _, _ = _build()
        assert len(signals) == 2

    def test_state_register_exists(self):
        signals, _, _, _, _, _ = _build()
        names = [s.name for s in signals]
        assert "state" in names

    def test_grant_register_exists(self):
        signals, _, _, _, _, _ = _build()
        names = [s.name for s in signals]
        assert "grant_reg" in names

    def test_state_register_width(self):
        signals, _, _, _, _, _ = _build()
        state = next(s for s in signals if s.name == "state")
        assert state.width == 2

    def test_grant_reg_width_2_masters(self):
        signals, _, _, _, _, _ = _build(num_masters=2)
        grant = next(s for s in signals if s.name == "grant_reg")
        assert grant.width == 1

    def test_grant_reg_width_4_masters(self):
        signals, _, _, _, _, _ = _build(num_masters=4)
        grant = next(s for s in signals if s.name == "grant_reg")
        assert grant.width == 2

    def test_grant_reg_width_8_masters(self):
        signals, _, _, _, _, _ = _build(num_masters=8)
        grant = next(s for s in signals if s.name == "grant_reg")
        assert grant.width == 3

    def test_all_signals_are_local(self):
        signals, _, _, _, _, _ = _build()
        for s in signals:
            assert s.direction == Direction.LOCAL

    def test_state_reset_val_is_idle(self):
        signals, _, _, _, _, _ = _build()
        state = next(s for s in signals if s.name == "state")
        assert state.reset_val == ArbiterState.IDLE

    def test_grant_reg_reset_val_is_zero(self):
        signals, _, _, _, _, _ = _build()
        grant = next(s for s in signals if s.name == "grant_reg")
        assert grant.reset_val == 0


# ===========================================================================
# Always block structure
# ===========================================================================


class TestAlwaysBlock:
    def test_returns_one_block(self):
        _, blocks, _, _, _, _ = _build()
        assert len(blocks) == 1

    def test_block_is_always(self):
        _, blocks, _, _, _, _ = _build()
        assert isinstance(blocks[0], Always)

    def test_sync_reset_sensitivity(self):
        _, blocks, _, _, _, _ = _build(reset_style=ResetStyle.SYNC)
        always = blocks[0]
        assert len(always.sensitivity) == 1
        edge, sig = always.sensitivity[0]
        assert edge == Edge.POSEDGE
        assert sig.name == "clk"

    def test_async_reset_sensitivity_active_low(self):
        _, blocks, _, _, _, _ = _build(
            reset_style=ResetStyle.ASYNC, active_low_reset=True,
        )
        always = blocks[0]
        assert len(always.sensitivity) == 2
        assert always.sensitivity[1][0] == Edge.NEGEDGE

    def test_async_reset_sensitivity_active_high(self):
        _, blocks, _, _, _, _ = _build(
            reset_style=ResetStyle.ASYNC, active_low_reset=False,
        )
        always = blocks[0]
        assert len(always.sensitivity) == 2
        assert always.sensitivity[1][0] == Edge.POSEDGE

    def test_body_starts_with_if(self):
        _, blocks, _, _, _, _ = _build()
        always = blocks[0]
        assert isinstance(always.body[0], If)

    def test_if_has_reset_and_else(self):
        _, blocks, _, _, _, _ = _build()
        fsm_if = blocks[0].body[0]
        assert len(fsm_if.then_body) > 0  # reset stmts
        assert len(fsm_if.else_body) > 0  # case stmt


# ===========================================================================
# FSM Case branches
# ===========================================================================


class TestFSMStates:
    def test_case_has_five_branches(self):
        """4 states + 1 default = 5 branches."""
        _, blocks, _, _, _, _ = _build()
        case = _find_case(blocks)
        assert len(case.branches) == 5

    def test_all_states_present(self):
        _, blocks, _, _, _, _ = _build()
        case = _find_case(blocks)
        branch_values = [v for v, _ in case.branches if v is not None]
        for st in ArbiterState:
            assert st.value in branch_values, f"State {st.name} missing"

    def test_default_branch_exists(self):
        _, blocks, _, _, _, _ = _build()
        case = _find_case(blocks)
        defaults = [v for v, _ in case.branches if v is None]
        assert len(defaults) == 1

    def test_default_branch_goes_to_idle(self):
        _, blocks, _, _, _, _ = _build()
        case = _find_case(blocks)
        default_body = [b for v, b in case.branches if v is None][0]
        assert len(default_body) == 1
        assign = default_body[0]
        assert isinstance(assign, NonBlockingAssign)
        assert assign.source == ArbiterState.IDLE

    def test_selector_is_state_reg(self):
        _, blocks, _, _, _, _ = _build()
        case = _find_case(blocks)
        assert isinstance(case.selector, Signal)
        assert case.selector.name == "state"


# ===========================================================================
# Reset behavior
# ===========================================================================


class TestResetBehavior:
    def test_reset_deasserts_state(self):
        _, blocks, _, _, _, _ = _build()
        reset_stmts = _find_reset_stmts(blocks)
        state_resets = [
            s
            for s in reset_stmts
            if isinstance(s, NonBlockingAssign)
            and isinstance(s.target, Signal)
            and s.target.name == "state"
        ]
        assert len(state_resets) == 1
        assert state_resets[0].source == ArbiterState.IDLE

    def test_reset_clears_grant_reg(self):
        _, blocks, _, _, _, _ = _build()
        reset_stmts = _find_reset_stmts(blocks)
        grant_resets = [
            s
            for s in reset_stmts
            if isinstance(s, NonBlockingAssign)
            and isinstance(s.target, Signal)
            and s.target.name == "grant_reg"
        ]
        assert len(grant_resets) == 1
        assert grant_resets[0].source == 0

    def test_reset_drives_slave_write_low(self):
        _, blocks, _, _, _, _ = _build()
        reset_stmts = _find_reset_stmts(blocks)
        write_resets = [
            s
            for s in reset_stmts
            if isinstance(s, NonBlockingAssign)
            and isinstance(s.target, Signal)
            and s.target.name == "s_avl_write"
        ]
        assert len(write_resets) == 1
        assert write_resets[0].source == 0

    def test_reset_drives_slave_read_low(self):
        _, blocks, _, _, _, _ = _build()
        reset_stmts = _find_reset_stmts(blocks)
        read_resets = [
            s
            for s in reset_stmts
            if isinstance(s, NonBlockingAssign)
            and isinstance(s.target, Signal)
            and s.target.name == "s_avl_read"
        ]
        assert len(read_resets) == 1
        assert read_resets[0].source == 0

    def test_reset_drives_all_master_waitrequests_high(self):
        for n in (2, 4):
            _, blocks, masters, _, _, _ = _build(num_masters=n)
            reset_stmts = _find_reset_stmts(blocks)
            reset_names = {
                s.target.name: s.source
                for s in reset_stmts
                if isinstance(s, NonBlockingAssign)
                and isinstance(s.target, Signal)
            }
            for i in range(n):
                key = f"m{i}_avl_waitrequest"
                assert key in reset_names, f"{key} not in reset"
                assert reset_names[key] == 1, f"{key} not driven high on reset"

    def test_active_low_reset_condition(self):
        _, blocks, _, _, _, _ = _build(active_low_reset=True)
        fsm_if = blocks[0].body[0]
        assert "!" in str(fsm_if.condition)

    def test_active_high_reset_condition(self):
        _, blocks, _, _, _, _ = _build(active_low_reset=False)
        fsm_if = blocks[0].body[0]
        assert "!" not in str(fsm_if.condition)


# ===========================================================================
# Grant rotation (round-robin)
# ===========================================================================


class TestGrantRotation:
    def test_idle_body_contains_round_robin_scan(self):
        """IDLE state should contain If nodes scanning for active masters."""
        _, blocks, _, _, _, _ = _build(num_masters=2)
        case = _find_case(blocks)
        idle_body = [b for v, b in case.branches if v == ArbiterState.IDLE][0]
        # Should contain If nodes for grant scanning
        if_nodes = [n for n in idle_body if isinstance(n, If)]
        assert len(if_nodes) >= 1, "IDLE body should have round-robin scan If nodes"

    def test_complete_state_rotates_pointer(self):
        """COMPLETE state should update grant_reg."""
        _, blocks, _, _, _, _ = _build(num_masters=2)
        case = _find_case(blocks)
        complete_body = [b for v, b in case.branches if v == ArbiterState.COMPLETE][0]
        grant_assigns = [
            s
            for s in complete_body
            if isinstance(s, NonBlockingAssign)
            and isinstance(s.target, Signal)
            and s.target.name == "grant_reg"
        ]
        assert len(grant_assigns) == 1, "COMPLETE should rotate grant_reg"

    def test_grant_state_transitions_to_locked(self):
        """GRANT state should transition to LOCKED."""
        _, blocks, _, _, _, _ = _build(num_masters=2)
        case = _find_case(blocks)
        grant_body = [b for v, b in case.branches if v == ArbiterState.GRANT][0]
        state_assigns = [
            s
            for s in grant_body
            if isinstance(s, NonBlockingAssign)
            and isinstance(s.target, Signal)
            and s.target.name == "state"
            and s.source == ArbiterState.LOCKED
        ]
        assert len(state_assigns) == 1

    def test_locked_state_transitions_to_complete_on_waitrequest_low(self):
        """LOCKED state should transition to COMPLETE when slave deasserts waitrequest."""
        _, blocks, _, _, _, _ = _build(num_masters=2)
        case = _find_case(blocks)
        locked_body = [b for v, b in case.branches if v == ArbiterState.LOCKED][0]
        # Should contain an If checking !waitrequest
        if_nodes = [n for n in locked_body if isinstance(n, If)]
        waitrequest_ifs = [
            n for n in if_nodes
            if "waitrequest" in str(n.condition)
        ]
        assert len(waitrequest_ifs) >= 1, (
            "LOCKED should check waitrequest for completion"
        )


# ===========================================================================
# Parameterization
# ===========================================================================


class TestParameterization:
    def test_2_masters(self):
        signals, blocks, masters, _, _, _ = _build(num_masters=2)
        assert len(masters) == 2
        assert len(signals) == 2
        assert len(blocks) == 1

    def test_4_masters(self):
        signals, blocks, masters, _, _, _ = _build(num_masters=4)
        assert len(masters) == 4
        assert len(signals) == 2
        grant = next(s for s in signals if s.name == "grant_reg")
        assert grant.width == 2

    def test_8_masters(self):
        signals, blocks, masters, _, _, _ = _build(num_masters=8)
        assert len(masters) == 8
        grant = next(s for s in signals if s.name == "grant_reg")
        assert grant.width == 3

    def test_32bit_data_width(self):
        _, blocks, masters, slave, _, _ = _build(dw=32)
        assert masters[0].data_width == 32
        assert slave.data_width == 32

    def test_64bit_data_width(self):
        _, blocks, masters, slave, _, _ = _build(dw=64)
        assert masters[0].data_width == 64
        assert slave.data_width == 64

    def test_rejects_1_master(self):
        with pytest.raises(ValueError, match="num_masters"):
            _build(num_masters=1)

    def test_rejects_9_masters(self):
        with pytest.raises(ValueError, match="num_masters"):
            _build(num_masters=9)


# ===========================================================================
# Round-trip: build → emit → inspect output
# ===========================================================================


class TestRoundTrip:
    def test_sv_emitter_produces_output(self):
        from emitter_sv import SystemVerilogEmitter

        m, _, _ = _build_module()
        emitter = SystemVerilogEmitter()
        output = emitter.emit(m)
        assert "module test_arbiter" in output
        assert "endmodule" in output

    def test_vhdl_emitter_produces_output(self):
        from emitter_vhdl import VHDLEmitter

        m, _, _ = _build_module()
        emitter = VHDLEmitter()
        output = emitter.emit(m)
        assert "entity" in output.lower()

    def test_sv_output_contains_case(self):
        from emitter_sv import SystemVerilogEmitter

        m, _, _ = _build_module()
        output = SystemVerilogEmitter().emit(m)
        assert "case" in output.lower()

    def test_sv_output_contains_state_signals(self):
        from emitter_sv import SystemVerilogEmitter

        m, _, _ = _build_module()
        output = SystemVerilogEmitter().emit(m)
        assert "state" in output
        assert "grant_reg" in output

    def test_sv_output_contains_master_signals(self):
        from emitter_sv import SystemVerilogEmitter

        m, _, _ = _build_module()
        output = SystemVerilogEmitter().emit(m)
        assert "m0_avl_address" in output
        assert "m1_avl_address" in output
        assert "m0_avl_waitrequest" in output
        assert "m1_avl_waitrequest" in output

    def test_sv_output_contains_slave_signals(self):
        from emitter_sv import SystemVerilogEmitter

        m, _, _ = _build_module()
        output = SystemVerilogEmitter().emit(m)
        assert "s_avl_address" in output
        assert "s_avl_write" in output
        assert "s_avl_read" in output
        assert "s_avl_waitrequest" in output

    def test_sv_4_masters_produces_output(self):
        from emitter_sv import SystemVerilogEmitter

        m, _, _ = _build_module(num_masters=4)
        output = SystemVerilogEmitter().emit(m)
        assert "module test_arbiter" in output
        for i in range(4):
            assert f"m{i}_avl_address" in output

    def test_sv_8_masters_produces_output(self):
        from emitter_sv import SystemVerilogEmitter

        m, _, _ = _build_module(num_masters=8)
        output = SystemVerilogEmitter().emit(m)
        assert "module test_arbiter" in output
        for i in range(8):
            assert f"m{i}_avl_address" in output


# ===========================================================================
# Multi-width round-trip
# ===========================================================================


class TestMultiWidth:
    @pytest.mark.parametrize("dw", [32, 64, 128])
    def test_sv_emit_various_data_widths(self, dw):
        from emitter_sv import SystemVerilogEmitter

        m, _, _ = _build_module(dw=dw)
        output = SystemVerilogEmitter().emit(m)
        assert "module test_arbiter" in output
        assert "endmodule" in output

    @pytest.mark.parametrize("n", [2, 3, 4, 5, 6, 7, 8])
    def test_sv_emit_various_master_counts(self, n):
        from emitter_sv import SystemVerilogEmitter

        m, _, _ = _build_module(num_masters=n)
        output = SystemVerilogEmitter().emit(m)
        assert "module test_arbiter" in output
        for i in range(n):
            assert f"m{i}_avl" in output
