# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
emitter_sv.py — SystemVerilog Emitter
======================================

Converts an HDL AST ``Module`` into synthesizable SystemVerilog source.

Usage::

    from emitter_sv import SystemVerilogEmitter
    from bus_interfaces import AXILiteInterface, InterfaceRole
    from addr_map import AddressMap
    from hdl_ast import Module, Signal, Direction

    axi = AXILiteInterface(data_width=32, addr_width=16,
                           role=InterfaceRole.SLAVE, prefix="s_axi")
    m = Module("my_bridge")
    for sig in axi.get_signals():
        m.add_port(sig)

    emitter = SystemVerilogEmitter(
        parameters={"Base Address": 0x4000_0000, "Data Width": 32}
    )
    print(emitter.emit(m))
    emitter.save(m, "my_bridge.sv")

Generated output structure::

    // ====================================================================
    // Auto-generated SystemVerilog — DO NOT EDIT
    // Generated: 2026-02-18 23:24:00 UTC
    // Parameters:
    //   Base Address: 0x40000000
    //   Data Width: 32
    // ====================================================================

    module my_bridge (
        // Inputs
        input  logic        s_axi_awvalid,
        ...
        // Outputs
        output logic [31:0] s_axi_rdata,
        ...
    );

        // Internal signals
        logic [31:0] state;

        // Continuous assignments
        assign s_axi_awready = 1'b1;

        // Always blocks
        always_ff @(posedge clk or negedge rst_n) begin
            if (!rst_n) begin
                ...
            end else begin
                ...
            end
        end

    endmodule
"""

from __future__ import annotations

from typing import Any, List

from emitter_base import BaseEmitter
from hdl_ast import (
    Always,
    Assign,
    Case,
    Direction,
    Edge,
    If,
    Module,
    NonBlockingAssign,
    Signal,
    Slice,
)


class SystemVerilogEmitter(BaseEmitter):
    """Emits synthesizable SystemVerilog from an HDL AST ``Module``.

    Parameters
    ----------
    indent_width:
        Spaces per indentation level (default 4).
    parameters:
        Key/value metadata written into the file header.
    generated_at:
        Override the generation timestamp (useful for deterministic tests).
    """

    LANGUAGE = "SystemVerilog"

    # ------------------------------------------------------------------
    # Module
    # ------------------------------------------------------------------

    def visit_Module(self, node: Module) -> None:
        """Emit a SystemVerilog module declaration."""
        self._emit_header(comment_prefix="//")

        # Separate ports by direction
        inputs = [p for p in node.ports if p.direction == Direction.INPUT]
        outputs = [p for p in node.ports if p.direction == Direction.OUTPUT]
        others = [p for p in node.ports if p.direction not in (Direction.INPUT, Direction.OUTPUT)]

        # ---- module header ----
        if node.ports:
            self._line(f"module {node.name} (")
            self._indent()
            all_ports = inputs + outputs + others
            for i, port in enumerate(all_ports):
                comma = "," if i < len(all_ports) - 1 else ""
                if port is all_ports[0] and inputs:
                    self._line("// Inputs")
                elif port is all_ports[len(inputs)] and outputs:
                    self._blank()
                    self._line("// Outputs")
                self._line(self._port_decl(port) + comma)
            self._dedent()
            self._line(");")
        else:
            self._line(f"module {node.name} ();")

        self._blank()
        self._indent()

        # ---- body ----
        # Group: continuous assigns first, then always blocks, then the rest
        assigns = [n for n in node.body if isinstance(n, Assign)]
        always_blocks = [n for n in node.body if isinstance(n, Always)]
        rest = [n for n in node.body if not isinstance(n, (Assign, Always))]

        if assigns:
            self._line("// Continuous assignments")
            for a in assigns:
                self.visit(a)
            self._blank()

        # ---- internal signals ----
        enums = self._discover_enums(node)
        if enums:
            self._line("// Enums")
            for enum_cls in enums:
                self._emit_enum_def(enum_cls)
            self._blank()

        if node.signals:
            self._line("// Internal signals")
            for sig in node.signals:
                self._line(self._signal_decl(sig, enums) + ";")
            self._blank()

        for blk in always_blocks:
            self.visit(blk)
            self._blank()

        for n in rest:
            self.visit(n)

        self._dedent()
        self._line("endmodule")

    def _discover_enums(self, module: Module) -> List[Any]:
        """Find all unique Enum classes used in signals or body logic."""
        import enum

        found_enums = set()

        # Check signal types/reset values
        for sig in module.signals + module.ports:
            if isinstance(sig.reset_val, enum.Enum):
                found_enums.add(type(sig.reset_val))

        # We'd ideally traverse the body too, but for bridge-gen,
        # checking the signal reset_val and a few heuristics is enough.
        # Let's do a quick scan of Always blocks for enum members.
        def scan(nodes):
            """Scan a signal reference into its string form."""
            for n in nodes:
                if isinstance(n, (NonBlockingAssign, Assign)):
                    if isinstance(n.source, enum.Enum):
                        found_enums.add(type(n.source))
                elif isinstance(n, If):
                    scan(n.then_body)
                    scan(n.else_body)
                elif isinstance(n, Case):
                    for _, body in n.branches:
                        scan(body)
                elif isinstance(n, Always):
                    scan(n.body)

        scan(module.body)
        return sorted(list(found_enums), key=lambda x: x.__name__)

    def _emit_enum_def(self, enum_cls: Any) -> None:
        """Emit 'typedef enum logic [...] { ... } Name_t;'"""
        name = enum_cls.__name__
        # Determine width from max value
        max_val = max(int(m) for m in enum_cls)
        width = (max_val.bit_length()) if max_val > 0 else 1
        width_str = f"logic [{width - 1}:0]" if width > 1 else "logic"

        self._line(f"typedef enum {width_str} {{")
        self._indent()
        members = list(enum_cls)
        for i, m in enumerate(members):
            comma = "," if i < len(members) - 1 else ""
            self._line(f"{m.name} = {width}'d{int(m)}{comma}")
        self._dedent()
        self._line(f"}} {name}_t;")

    # ------------------------------------------------------------------
    # Signal / port declarations
    # ------------------------------------------------------------------

    def _port_decl(self, sig: Signal) -> str:
        """Return a port declaration string (without trailing semicolon)."""
        direction = {
            Direction.INPUT: "input  logic",
            Direction.OUTPUT: "output logic",
        }.get(sig.direction, "logic")

        width_str = f" [{sig.width - 1}:0]" if sig.width > 1 else "       "
        return f"{direction}{width_str} {sig.name}"

    def _signal_decl(self, sig: Signal, enums: List[Any] = None) -> str:
        """Return an internal signal declaration (without trailing semicolon)."""
        import enum

        # If signal reset_val is an enum, use the enum type name
        if isinstance(sig.reset_val, enum.Enum):
            type_name = type(sig.reset_val).__name__ + "_t"
            return f"{type_name} {sig.name}"

        width_str = f" [{sig.width - 1}:0]" if sig.width > 1 else ""
        return f"logic{width_str} {sig.name}"

    def _render_expr(self, expr: object) -> str:
        import enum

        if isinstance(expr, enum.Enum):
            # We emitted them as top-level labels in the enum def
            return expr.name
        return super()._render_expr(expr)

    # ------------------------------------------------------------------
    # Assign
    # ------------------------------------------------------------------

    def visit_Assign(self, node: Assign) -> None:
        """Emit a continuous assignment statement."""
        target = self._render_expr(node.target)
        source = self._render_expr(node.source)
        self._line(f"assign {target} = {source};")

    # ------------------------------------------------------------------
    # Always
    # ------------------------------------------------------------------

    def visit_Always(self, node: Always) -> None:
        """Emit an always_ff or always_comb block."""
        sens = self._render_sensitivity(node.sensitivity)
        # Determine block type: if any edge is POSEDGE/NEGEDGE → always_ff
        # If sensitivity is empty or contains only None → always_comb
        has_edge = any(edge in (Edge.POSEDGE, Edge.NEGEDGE) for edge, _ in node.sensitivity)
        kw = "always_ff" if has_edge else "always_comb"

        if has_edge:
            self._line(f"{kw} @({sens}) begin")
        else:
            self._line(f"{kw} begin")

        self._indent()
        for stmt in node.body:
            self.visit(stmt)
        self._dedent()
        self._line("end")

    def _render_sensitivity(self, sensitivity: list) -> str:
        parts: List[str] = []
        for edge, sig in sensitivity:
            if sig is None:
                parts.append("*")
            elif edge == Edge.POSEDGE:
                parts.append(f"posedge {sig.name}")
            elif edge == Edge.NEGEDGE:
                parts.append(f"negedge {sig.name}")
            else:
                parts.append(sig.name)
        return " or ".join(parts)

    # ------------------------------------------------------------------
    # NonBlockingAssign
    # ------------------------------------------------------------------

    def visit_NonBlockingAssign(self, node: NonBlockingAssign) -> None:
        """Emit a non-blocking assignment (<= in SV)."""
        target = self._render_expr(node.target)
        source = self._render_expr(node.source)
        self._line(f"{target} <= {source};")

    # ------------------------------------------------------------------
    # If / else
    # ------------------------------------------------------------------

    def visit_If(self, node: If) -> None:
        """Emit an if/else chain."""
        cond = self._render_expr(node.condition)
        self._line(f"if ({cond}) begin")
        self._indent()
        for stmt in node.then_body:
            self.visit(stmt)
        self._dedent()

        if node.else_body:
            self._line("end else begin")
            self._indent()
            for stmt in node.else_body:
                self.visit(stmt)
            self._dedent()
        self._line("end")

    # ------------------------------------------------------------------
    # Case
    # ------------------------------------------------------------------

    def visit_Case(self, node: Case) -> None:
        """Emit a case/casez block."""
        selector = self._render_expr(node.selector)
        self._line(f"case ({selector})")
        self._indent()
        for value, body in node.branches:
            label = "default" if value is None else self._render_expr(value)
            self._line(f"{label}: begin")
            self._indent()
            for stmt in body:
                self.visit(stmt)
            self._dedent()
            self._line("end")
        self._dedent()
        self._line("endcase")

    # ------------------------------------------------------------------
    # Expression nodes (inline — used by _render_expr via visit dispatch)
    # ------------------------------------------------------------------

    def visit_Slice(self, node: Slice) -> None:
        # Slices appear inline inside expressions; direct visit is a no-op.
        """Emit a bit-slice expression."""
        pass

    def visit_Concat(self, node) -> None:
        """Emit a concatenation expression."""
        pass

    def visit_Ternary(self, node) -> None:
        """Emit a ternary conditional expression."""
        pass


__all__ = ["SystemVerilogEmitter"]
