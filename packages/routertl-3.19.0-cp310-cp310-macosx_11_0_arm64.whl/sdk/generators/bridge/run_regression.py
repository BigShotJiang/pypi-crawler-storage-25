#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
run_regression.py — Parametric Regression for Bridge Generator
==============================================================

Sweeps a matrix of bridge parameters (data_width × base_addr),
generates RTL for each configuration, and validates it against the
bridge-gen pre-elaboration checks.

The script invokes ``generate_bridge()`` programmatically, cleans the
build workspace between runs, and prints a summary table.

Usage::

    python run_regression.py                    # default matrix
    python run_regression.py --lang vhdl        # override language
    python run_regression.py --widths 32 64     # custom widths
    python run_regression.py --bases 0x0 0x8000 # custom base addresses

Exit codes:  0 = all passed, 1 = any failure.
"""

from __future__ import annotations

import argparse
import shutil
import sys
import tempfile
import time
from pathlib import Path
from typing import List

# Ensure bridge-gen modules are importable
_BRIDGE_GEN_DIR = Path(__file__).resolve().parent
from main import ConfigError, generate_bridge  # noqa: E402

try:
    from validator import ValidationError  # noqa: E402
except ImportError:

    class ValidationError(Exception):
        pass


# ──────────────────────────────────────────────────────────────
#  Default parameter matrix
# ──────────────────────────────────────────────────────────────

DEFAULT_DATA_WIDTHS = [8, 16, 32, 64]
DEFAULT_BASE_ADDRS = [0x0000, 0x4000]
DEFAULT_ADDR_WIDTH = 16
DEFAULT_LANG = "sv"


# ──────────────────────────────────────────────────────────────
#  Configuration builder
# ──────────────────────────────────────────────────────────────


def _build_cfg(
    data_width: int,
    base_addr: int,
    addr_width: int = DEFAULT_ADDR_WIDTH,
    lang: str = DEFAULT_LANG,
) -> dict:
    """Build a bridge config dict for a single parameter combination."""
    # Size must cover at least one word and be a power of two
    bytes_per_word = data_width // 8
    min_size = max(bytes_per_word, 256)  # at least 256 bytes
    # Find nearest power-of-two >= min_size
    size = 1
    while size < min_size:
        size <<= 1

    return {
        "name": f"bridge_{data_width}b_{base_addr:#06x}",
        "protocol": "axilite",
        "role": "slave",
        "data_width": data_width,
        "addr_width": addr_width,
        "base_addr": base_addr,
        "size": size,
        "prefix": "s",
        "stages": 0,
        "reset_style": "async",
        "error_policy": "slverr",
        "lang": lang,
        "no_sva": lang == "vhdl",  # VHDL cannot have SVA
    }


# ──────────────────────────────────────────────────────────────
#  Result tracking
# ──────────────────────────────────────────────────────────────


class RunResult:
    """Result of a single regression point."""

    def __init__(self, cfg: dict):
        """Create with the test name and failure details."""
        self.name = cfg["name"]
        self.data_width = cfg["data_width"]
        self.base_addr = cfg["base_addr"]
        self.passed = False
        self.error = ""
        self.elapsed_ms = 0.0
        self.output_path: Path | None = None


# ──────────────────────────────────────────────────────────────
#  Regression runner
# ──────────────────────────────────────────────────────────────


def run_matrix(
    data_widths: List[int],
    base_addrs: List[int],
    addr_width: int = DEFAULT_ADDR_WIDTH,
    lang: str = DEFAULT_LANG,
    output_dir: Path | None = None,
    verbose: bool = False,
) -> List[RunResult]:
    """Run the full parameter matrix.

    Returns a list of RunResult, one per configuration.
    """
    results: List[RunResult] = []

    # Use a temp dir if none provided
    cleanup = False
    if output_dir is None:
        output_dir = Path(tempfile.mkdtemp(prefix="bridge_regression_"))
        cleanup = True

    try:
        for dw in data_widths:
            for ba in base_addrs:
                cfg = _build_cfg(dw, ba, addr_width, lang)
                result = RunResult(cfg)

                ext = "vhd" if lang == "vhdl" else "sv"
                out_path = output_dir / f"{cfg['name']}.{ext}"
                result.output_path = out_path

                t0 = time.monotonic()
                try:
                    generate_bridge(cfg, out_path, verbose=verbose)
                    result.passed = True
                except (ConfigError, ValidationError) as exc:
                    result.error = str(exc)
                except (RuntimeError, TypeError, ValueError, OSError) as exc:  # pragma: no cover
                    result.error = f"Internal: {exc}"

                result.elapsed_ms = (time.monotonic() - t0) * 1000
                results.append(result)

                # Print progress dot
                mark = "✅" if result.passed else "❌"
                print(f"  {mark} {cfg['name']} ({result.elapsed_ms:.0f}ms)")

    finally:
        if cleanup and output_dir.exists():
            shutil.rmtree(output_dir, ignore_errors=True)

    return results


# ──────────────────────────────────────────────────────────────
#  Summary table
# ──────────────────────────────────────────────────────────────


def print_summary(results: List[RunResult]) -> None:
    """Print a formatted summary table."""
    total = len(results)
    passed = sum(1 for r in results if r.passed)
    failed = total - passed

    print("\n" + "=" * 70)
    print(f" Bridge Generator Regression: {passed}/{total} passed", end="")
    if failed:
        print(f"  ({failed} FAILED)")
    else:
        print("  ✅ ALL PASSED")
    print("=" * 70)

    # Column-aligned table
    print(f"  {'Name':<35} {'Width':>5} {'Base':>10} {'Result':>8} {'Time':>8}")
    print(f"  {'-' * 35} {'-' * 5} {'-' * 10} {'-' * 8} {'-' * 8}")
    for r in results:
        status = "PASS" if r.passed else "FAIL"
        print(f"  {r.name:<35} {r.data_width:>5} 0x{r.base_addr:08X} {status:>8} {r.elapsed_ms:>6.0f}ms")

    if failed:
        print("\nFailed configurations:")
        for r in results:
            if not r.passed:
                print(f"  ❌ {r.name}: {r.error}")


# ──────────────────────────────────────────────────────────────
#  CLI
# ──────────────────────────────────────────────────────────────


def _parse_int_arg(s: str) -> int:
    """Parse an int argument, supporting hex (0x...)."""
    return int(s, 0)


def main(argv: list | None = None) -> int:
    """CLI entry point for bridge regression runner."""
    parser = argparse.ArgumentParser(
        description="Parametric regression for the RTL Bridge Generator",
    )
    parser.add_argument(
        "--widths",
        nargs="+",
        type=int,
        default=DEFAULT_DATA_WIDTHS,
        help=f"Data widths to test (default: {DEFAULT_DATA_WIDTHS})",
    )
    parser.add_argument(
        "--bases",
        nargs="+",
        type=_parse_int_arg,
        default=DEFAULT_BASE_ADDRS,
        help=f"Base addresses to test (default: {[hex(a) for a in DEFAULT_BASE_ADDRS]})",
    )
    parser.add_argument(
        "--addr-width",
        type=int,
        default=DEFAULT_ADDR_WIDTH,
        help=f"Address width (default: {DEFAULT_ADDR_WIDTH})",
    )
    parser.add_argument(
        "--lang",
        choices=["sv", "vhdl"],
        default=DEFAULT_LANG,
        help=f"Output language (default: {DEFAULT_LANG})",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=None,
        help="Output directory (default: temp directory)",
    )
    parser.add_argument(
        "--verbose",
        "-v",
        action="store_true",
        help="Print generated source to stdout",
    )

    args = parser.parse_args(argv)

    n_configs = len(args.widths) * len(args.bases)
    print(f"Bridge Generator Regression — {n_configs} configurations")
    print(f"  Widths: {args.widths}")
    print(f"  Bases:  {[f'0x{a:04X}' for a in args.bases]}")
    print(f"  Lang:   {args.lang}")
    print()

    results = run_matrix(
        data_widths=args.widths,
        base_addrs=args.bases,
        addr_width=args.addr_width,
        lang=args.lang,
        output_dir=args.output_dir,
        verbose=args.verbose,
    )

    print_summary(results)

    return 0 if all(r.passed for r in results) else 1


if __name__ == "__main__":
    sys.exit(main())
