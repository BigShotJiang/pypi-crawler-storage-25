# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
bus_interfaces.py — Bus Interface Component Bundles
====================================================

Frontend layer of the RTL bridge generator pipeline.

Each ``BusInterface`` subclass groups the ``Signal`` objects that belong
to a particular bus protocol.  The classes are **pure Python descriptors**:
they carry no AST logic themselves — they hand their signals to a ``Module``
via ``get_signals()`` / ``as_ports()``, and to the Logic Layer via the
``connect()`` helper.

Supported protocols
-------------------
* ``AXILiteInterface``  — AMBA AXI4-Lite (no burst, no ID)
* ``AvalonMMInterface`` — Intel Avalon Memory-Mapped
* ``NativeMemInterface``— Generic synchronous SRAM interface

Pipeline position:
    [THIS MODULE] → Middle-end (AST) → Logic Layer → Backend (Emitter)
"""

from __future__ import annotations

import enum
import math
from typing import Dict, List

from hdl_ast import Assign, Direction, HdlNode, Signal

# ---------------------------------------------------------------------------
# Enumerations
# ---------------------------------------------------------------------------


class InterfaceRole(enum.Enum):
    """Whether this interface faces the bus master or the bus slave.

    The role controls how ``Direction`` is assigned to each signal:

    * ``SLAVE``  — the bridge *receives* commands from the master.
      Master→Slave signals are ``INPUT``; Slave→Master signals are ``OUTPUT``.
    * ``MASTER`` — the bridge *issues* commands to a downstream slave.
      Master→Slave signals are ``OUTPUT``; Slave→Master signals are ``INPUT``.
    """

    SLAVE = "slave"
    MASTER = "master"


class Protocol(enum.Enum):
    """Identifies the bus protocol implemented by an interface."""

    AXI_LITE = "axi_lite"
    AXI4 = "axi4"  # reserved for Phase 2
    AVALON_MM = "avalon_mm"
    NATIVE_MEM = "native_mem"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _is_power_of_two(n: int) -> bool:
    return n >= 1 and (n & (n - 1)) == 0


def _log2_exact(n: int) -> int:
    """Return log2(n); raise ValueError if n is not a power of two."""
    if not _is_power_of_two(n):
        raise ValueError(f"{n} is not a power of two")
    return int(math.log2(n))


# ---------------------------------------------------------------------------
# Base class
# ---------------------------------------------------------------------------


class BusInterface:
    """Abstract base for all bus interface bundles.

    Parameters
    ----------
    data_width:
        Width of the data bus in bits.  Must be a power of two ≥ 8.
    addr_width:
        Width of the address bus in bits.
    role:
        ``SLAVE`` (bridge receives commands) or ``MASTER`` (bridge issues
        commands).  Controls ``Direction`` assignment on every signal.
    prefix:
        String prepended to every signal name (e.g. ``"s_axi"`` →
        ``"s_axi_awvalid"``).  Use distinct prefixes when two interfaces
        of the same protocol share a module.
    """

    #: Protocol tag — set by each subclass.
    protocol: Protocol

    def __init__(
        self,
        data_width: int,
        addr_width: int,
        role: InterfaceRole = InterfaceRole.SLAVE,
        prefix: str = "",
    ) -> None:
        """Create a bus interface with the given prefix and data width."""
        if not _is_power_of_two(data_width) or data_width < 8:
            raise ValueError(f"data_width must be a power-of-two ≥ 8, got {data_width}")
        if addr_width < 1:
            raise ValueError(f"addr_width must be ≥ 1, got {addr_width}")

        self.data_width: int = data_width
        self.addr_width: int = addr_width
        self.role: InterfaceRole = role
        self.prefix: str = prefix

        # Populated by _build_signals() in each subclass __init__.
        self._signals: Dict[str, Signal] = {}
        self._build_signals()

    # ------------------------------------------------------------------
    # Subclass contract
    # ------------------------------------------------------------------

    def _build_signals(self) -> None:
        """Populate ``self._signals``.  Must be overridden by subclasses."""
        raise NotImplementedError

    # ------------------------------------------------------------------
    # Direction helpers
    # ------------------------------------------------------------------

    def _dir(self, master_to_slave: bool) -> Direction:
        """Return the ``Direction`` for a signal given its flow.

        Parameters
        ----------
        master_to_slave:
            ``True``  → signal flows from master to slave (e.g. AWVALID).
            ``False`` → signal flows from slave to master (e.g. AWREADY).
        """
        if self.role == InterfaceRole.SLAVE:
            return Direction.INPUT if master_to_slave else Direction.OUTPUT
        else:  # MASTER
            return Direction.OUTPUT if master_to_slave else Direction.INPUT

    # ------------------------------------------------------------------
    # Signal factory
    # ------------------------------------------------------------------

    def _sig(
        self,
        short_name: str,
        width: int,
        master_to_slave: bool,
        reset_val: int = 0,
    ) -> Signal:
        """Create a ``Signal``, register it, and return it."""
        full_name = f"{self.prefix}_{short_name}" if self.prefix else short_name
        sig = Signal(
            name=full_name,
            width=width,
            direction=self._dir(master_to_slave),
            reset_val=reset_val,
        )
        self._signals[short_name] = sig
        return sig

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def get_signals(self) -> List[Signal]:
        """Return all signals in definition order.

        Use this to populate a ``Module`` with ``add_port()`` calls::

            for sig in iface.get_signals():
                module.add_port(sig)
        """
        return list(self._signals.values())

    def __getattr__(self, name: str) -> Signal:
        """Allow attribute-style access: ``iface.awvalid``."""
        # Only called when normal attribute lookup fails.
        signals = object.__getattribute__(self, "_signals")
        if name in signals:
            return signals[name]
        raise AttributeError(f"{type(self).__name__!r} has no signal {name!r}. Available: {list(signals)}")

    def connect(self, other: "BusInterface") -> List[HdlNode]:
        """Generate combinational ``Assign`` nodes wiring ``self`` → ``other``.

        Both interfaces must be the same protocol.  Signals are matched by
        their *short name* (without prefix).  Typically used to wire a
        pass-through bridge where the two interfaces have opposite roles.

        Returns
        -------
        List[HdlNode]
            One ``Assign`` node per matched signal pair.
        """
        if type(self) is not type(other):
            raise TypeError(f"Cannot connect {type(self).__name__} to {type(other).__name__}")
        assigns: List[HdlNode] = []
        for short_name, src_sig in self._signals.items():
            if short_name in other._signals:
                dst_sig = other._signals[short_name]
                assigns.append(Assign(target=dst_sig, source=src_sig))
        return assigns

    def __repr__(self) -> str:
        return (
            f"{type(self).__name__}("
            f"data_width={self.data_width}, "
            f"addr_width={self.addr_width}, "
            f"role={self.role.name}, "
            f"prefix={self.prefix!r}, "
            f"signals={len(self._signals)})"
        )


# ---------------------------------------------------------------------------
# AXI4-Lite Interface
# ---------------------------------------------------------------------------


class AXILiteInterface(BusInterface):
    """AMBA AXI4-Lite bus interface bundle.

    Signal map (SLAVE role — directions flip for MASTER):

    Write address channel
    ~~~~~~~~~~~~~~~~~~~~~
    ``awaddr``   [addr_width]  INPUT   — Write address
    ``awprot``   [3]           INPUT   — Protection type (pass-through)
    ``awvalid``  [1]           INPUT   — Write address valid
    ``awready``  [1]           OUTPUT  — Write address ready

    Write data channel
    ~~~~~~~~~~~~~~~~~~
    ``wdata``    [data_width]  INPUT   — Write data
    ``wstrb``    [strb_width]  INPUT   — Write strobes (byte enables)
    ``wvalid``   [1]           INPUT   — Write valid
    ``wready``   [1]           OUTPUT  — Write ready

    Write response channel
    ~~~~~~~~~~~~~~~~~~~~~~
    ``bresp``    [2]           OUTPUT  — Write response (OKAY/SLVERR/DECERR)
    ``bvalid``   [1]           OUTPUT  — Write response valid
    ``bready``   [1]           INPUT   — Write response ready

    Read address channel
    ~~~~~~~~~~~~~~~~~~~~
    ``araddr``   [addr_width]  INPUT   — Read address
    ``arprot``   [3]           INPUT   — Protection type
    ``arvalid``  [1]           INPUT   — Read address valid
    ``arready``  [1]           OUTPUT  — Read address ready

    Read data channel
    ~~~~~~~~~~~~~~~~~
    ``rdata``    [data_width]  OUTPUT  — Read data
    ``rresp``    [2]           OUTPUT  — Read response
    ``rvalid``   [1]           OUTPUT  — Read data valid
    ``rready``   [1]           INPUT   — Read data ready
    """

    protocol = Protocol.AXI_LITE

    def _build_signals(self) -> None:
        dw = self.data_width
        aw = self.addr_width
        sw = dw // 8  # strobe width

        # Write address channel
        self._sig("awaddr", aw, master_to_slave=True)
        self._sig("awprot", 3, master_to_slave=True)
        self._sig("awvalid", 1, master_to_slave=True)
        self._sig("awready", 1, master_to_slave=False)

        # Write data channel
        self._sig("wdata", dw, master_to_slave=True)
        self._sig("wstrb", sw, master_to_slave=True, reset_val=(1 << sw) - 1)
        self._sig("wvalid", 1, master_to_slave=True)
        self._sig("wready", 1, master_to_slave=False)

        # Write response channel
        self._sig("bresp", 2, master_to_slave=False)
        self._sig("bvalid", 1, master_to_slave=False)
        self._sig("bready", 1, master_to_slave=True)

        # Read address channel
        self._sig("araddr", aw, master_to_slave=True)
        self._sig("arprot", 3, master_to_slave=True)
        self._sig("arvalid", 1, master_to_slave=True)
        self._sig("arready", 1, master_to_slave=False)

        # Read data channel
        self._sig("rdata", dw, master_to_slave=False)
        self._sig("rresp", 2, master_to_slave=False)
        self._sig("rvalid", 1, master_to_slave=False)
        self._sig("rready", 1, master_to_slave=True)


# ---------------------------------------------------------------------------
# Avalon-MM Interface
# ---------------------------------------------------------------------------


class AvalonMMInterface(BusInterface):
    """Intel Avalon Memory-Mapped bus interface bundle.

    Signal map (SLAVE role — directions flip for MASTER):

    Command channel (master → slave)
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    ``address``     [addr_width]  INPUT   — Target word address
    ``read``        [1]           INPUT   — Read request strobe
    ``write``       [1]           INPUT   — Write request strobe
    ``writedata``   [data_width]  INPUT   — Write data
    ``byteenable``  [strb_width]  INPUT   — Byte-enable mask
    ``burstcount``  [bc_width]    INPUT   — Burst beat count (optional)

    Response channel (slave → master)
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    ``readdata``      [data_width]  OUTPUT  — Read data
    ``readdatavalid`` [1]           OUTPUT  — Read data valid (pipeline mode)
    ``waitrequest``   [1]           OUTPUT  — Stall signal (active-high)
    ``response``      [2]           OUTPUT  — Error response (00=OKAY, 10=SLVERR)

    Notes
    -----
    * Avalon-MM uses a *word address* natively (unlike AXI which uses byte
      addresses).  The ``AddressTransformer`` handles the conversion.
    * ``readdatavalid`` is used in *variable-latency* (pipeline) mode.
      Fixed-latency mode is not modelled here.
    * ``response`` field encoding: ``2'b00`` OKAY, ``2'b10`` SLVERR,
      ``2'b11`` DECERR.
    * ``burstcount`` is only present when ``burstcount_width > 0``.
      When absent (default), the interface is a standard non-burst
      Avalon-MM interface and all existing bridges work unchanged.
    """

    protocol = Protocol.AVALON_MM

    def __init__(
        self,
        data_width: int,
        addr_width: int,
        role: InterfaceRole = InterfaceRole.SLAVE,
        prefix: str = "",
        burstcount_width: int = 0,
    ) -> None:
        """Create an Avalon-MM interface.

        Parameters
        ----------
        burstcount_width : int
            Width of the ``burstcount`` signal in bits.  0 means no
            burst support (standard Avalon-MM).  Typical value is 8
            for up to 256-beat bursts.
        """
        self.burstcount_width = burstcount_width
        super().__init__(data_width, addr_width, role, prefix)

    def _build_signals(self) -> None:
        dw = self.data_width
        aw = self.addr_width
        sw = dw // 8

        # Command channel (master → slave)
        self._sig("address", aw, master_to_slave=True)
        self._sig("read", 1, master_to_slave=True)
        self._sig("write", 1, master_to_slave=True)
        self._sig("writedata", dw, master_to_slave=True)
        self._sig("byteenable", sw, master_to_slave=True, reset_val=(1 << sw) - 1)

        # Optional burst signal
        if self.burstcount_width > 0:
            self._sig("burstcount", self.burstcount_width, master_to_slave=True, reset_val=1)

        # Response channel (slave → master)
        self._sig("readdata", dw, master_to_slave=False)
        self._sig("readdatavalid", 1, master_to_slave=False)
        self._sig("waitrequest", 1, master_to_slave=False, reset_val=1)
        self._sig("response", 2, master_to_slave=False)


# ---------------------------------------------------------------------------
# Native Memory Interface
# ---------------------------------------------------------------------------


class NativeMemInterface(BusInterface):
    """Generic synchronous SRAM-style memory interface bundle.

    This is the *target* side of most bridge variants — it connects to a
    block RAM, register file, or any memory with a simple
    address/data/strobe handshake.

    Signal map (SLAVE role — directions flip for MASTER):

    Request channel (master → slave)
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    ``addr``   [addr_width]  INPUT   — Word address (not byte address)
    ``din``    [data_width]  INPUT   — Write data
    ``we``     [strb_width]  INPUT   — Byte-write enables (active-high)
    ``re``     [1]           INPUT   — Read enable (active-high)
    ``cs``     [1]           INPUT   — Chip select (active-high)

    Response channel (slave → master)
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    ``dout``   [data_width]  OUTPUT  — Read data
    ``ack``    [1]           OUTPUT  — Transaction acknowledged (1 cycle pulse)

    Notes
    -----
    * ``addr`` is a **word address**.  The ``AddressTransformer`` converts
      AXI/Avalon byte addresses to this format.
    * ``we`` is byte-granular (one bit per byte lane), matching AXI ``WSTRB``
      and Avalon ``byteenable``.
    * ``ack`` is asserted for exactly one cycle when the memory has accepted
      the request.  For single-cycle SRAMs, ``ack`` is typically tied high
      (or driven by a 1-cycle delayed ``cs``).
    """

    protocol = Protocol.NATIVE_MEM

    def _build_signals(self) -> None:
        dw = self.data_width
        aw = self.addr_width
        sw = dw // 8  # byte-enable width

        # Request channel
        self._sig("addr", aw, master_to_slave=True)
        self._sig("din", dw, master_to_slave=True)
        self._sig("we", sw, master_to_slave=True)
        self._sig("re", 1, master_to_slave=True)
        self._sig("cs", 1, master_to_slave=True)

        # Response channel
        self._sig("dout", dw, master_to_slave=False)
        self._sig("ack", 1, master_to_slave=False)


# ---------------------------------------------------------------------------
# AXI4 Interface
# ---------------------------------------------------------------------------


class AXI4Interface(BusInterface):
    """AMBA AXI4 (Full AXI) bus interface bundle.

    Extends AXI4-Lite with burst support (AxLEN, WLAST, RLAST), unique ID
    tracking (AxID), and additional transaction metadata (AxSIZE, AxBURST).
    """

    protocol = Protocol.AXI4

    def __init__(
        self,
        data_width: int,
        addr_width: int,
        id_width: int = 4,
        role: InterfaceRole = InterfaceRole.SLAVE,
        prefix: str = "",
    ) -> None:
        """Create a bus interface with the given prefix and data width."""
        if id_width < 1:
            raise ValueError(f"id_width must be >= 1, got {id_width}")
        self.id_width = id_width
        super().__init__(data_width, addr_width, role, prefix)

    def _build_signals(self) -> None:
        dw = self.data_width
        aw = self.addr_width
        iw = self.id_width
        sw = dw // 8  # strobe width

        # Write address channel
        self._sig("awid", iw, master_to_slave=True)
        self._sig("awaddr", aw, master_to_slave=True)
        self._sig("awlen", 8, master_to_slave=True)
        self._sig("awsize", 3, master_to_slave=True)
        self._sig("awburst", 2, master_to_slave=True)
        self._sig("awprot", 3, master_to_slave=True)
        self._sig("awcache", 4, master_to_slave=True)
        self._sig("awqos", 4, master_to_slave=True)
        self._sig("awvalid", 1, master_to_slave=True)
        self._sig("awready", 1, master_to_slave=False)

        # Write data channel
        self._sig("wdata", dw, master_to_slave=True)
        self._sig("wstrb", sw, master_to_slave=True, reset_val=(1 << sw) - 1)
        self._sig("wlast", 1, master_to_slave=True)
        self._sig("wvalid", 1, master_to_slave=True)
        self._sig("wready", 1, master_to_slave=False)

        # Write response channel
        self._sig("bid", iw, master_to_slave=False)
        self._sig("bresp", 2, master_to_slave=False)
        self._sig("bvalid", 1, master_to_slave=False)
        self._sig("bready", 1, master_to_slave=True)

        # Read address channel
        self._sig("arid", iw, master_to_slave=True)
        self._sig("araddr", aw, master_to_slave=True)
        self._sig("arlen", 8, master_to_slave=True)
        self._sig("arsize", 3, master_to_slave=True)
        self._sig("arburst", 2, master_to_slave=True)
        self._sig("arprot", 3, master_to_slave=True)
        self._sig("arcache", 4, master_to_slave=True)
        self._sig("arqos", 4, master_to_slave=True)
        self._sig("arvalid", 1, master_to_slave=True)
        self._sig("arready", 1, master_to_slave=False)

        # Read data channel
        self._sig("rid", iw, master_to_slave=False)
        self._sig("rdata", dw, master_to_slave=False)
        self._sig("rresp", 2, master_to_slave=False)
        self._sig("rlast", 1, master_to_slave=False)
        self._sig("rvalid", 1, master_to_slave=False)
        self._sig("rready", 1, master_to_slave=True)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

__all__ = [
    "InterfaceRole",
    "Protocol",
    "BusInterface",
    "AXILiteInterface",
    "AXI4Interface",
    "AvalonMMInterface",
    "NativeMemInterface",
]
