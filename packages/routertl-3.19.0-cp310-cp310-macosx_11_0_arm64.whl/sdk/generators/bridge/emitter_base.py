# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
emitter_base.py — Shared base class for HDL emitters
=====================================================

Provides the scaffolding that both ``SystemVerilogEmitter`` and any future
``VHDLEmitter`` can inherit from, so that ~80 % of the visitor plumbing is
shared and only the language-specific rendering methods need to be overridden.

Design principles
-----------------
* **Single responsibility**: this module only handles indentation, line
  buffering, and the ``save()`` / ``emit()`` API.  Language-specific logic
  lives in the concrete subclass.
* **NodeVisitor integration**: ``BaseEmitter`` inherits from ``NodeVisitor``
  so that ``visit(node)`` dispatches to ``visit_<NodeType>`` automatically.
* **Immutable parameters**: generation metadata (date, parameters) is passed
  at construction time and baked into the file header.

Subclassing guide
-----------------
To add a new language target, subclass ``BaseEmitter`` and implement:

    visit_Module(node)
    visit_Signal(node)       # for port/signal declarations
    visit_Assign(node)
    visit_Always(node)
    visit_NonBlockingAssign(node)
    visit_If(node)
    visit_Case(node)
    visit_Slice(node)
    visit_Concat(node)
    visit_Ternary(node)

Use the helpers ``_write()``, ``_indent()``, ``_dedent()``, and
``_line()`` to build up the output buffer.
"""

from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from hdl_ast import HdlNode, NodeVisitor


class BaseEmitter(NodeVisitor):
    """Abstract base for HDL emitters.

    Parameters
    ----------
    indent_width:
        Number of spaces per indentation level (default 4).
    parameters:
        Arbitrary key/value pairs written into the file header comment
        (e.g. ``{"Base Address": "0x4000_0000", "Data Width": 32}``).
    generated_at:
        Override the generation timestamp (useful for deterministic tests).
        Defaults to the current UTC time.
    """

    # Subclasses set this to identify the language in the header comment.
    LANGUAGE: str = "HDL"

    def __init__(
        self,
        indent_width: int = 4,
        parameters: Optional[Dict[str, Any]] = None,
        generated_at: Optional[datetime] = None,
    ) -> None:
        """Create a base emitter for the given module AST."""
        self._indent_width = indent_width
        self._parameters: Dict[str, Any] = parameters or {}
        self._generated_at = generated_at or datetime.now(tz=timezone.utc)

        self._lines: List[str] = []
        self._level: int = 0

    # ------------------------------------------------------------------
    # Output buffer helpers
    # ------------------------------------------------------------------

    def _write(self, text: str) -> None:
        """Append a raw string to the current line (no newline added)."""
        if self._lines:
            self._lines[-1] += text
        else:
            self._lines.append(text)

    def _line(self, text: str = "") -> None:
        """Append a complete indented line to the output buffer."""
        pad = " " * (self._indent_width * self._level)
        self._lines.append(f"{pad}{text}")

    def _blank(self) -> None:
        """Append a blank line."""
        self._lines.append("")

    def _indent(self) -> None:
        """Increase indentation level by one."""
        self._level += 1

    def _dedent(self) -> None:
        """Decrease indentation level by one (minimum 0)."""
        self._level = max(0, self._level - 1)

    # ------------------------------------------------------------------
    # Header
    # ------------------------------------------------------------------

    def _emit_header(self, comment_prefix: str = "//") -> None:
        """Write a standard file header comment block.

        Parameters
        ----------
        comment_prefix:
            Language-specific single-line comment prefix
            (``//`` for SV, ``--`` for VHDL).
        """
        cp = comment_prefix
        ts = self._generated_at.strftime("%Y-%m-%d %H:%M:%S UTC")
        self._line(f"{cp} {'=' * 68}")
        self._line(f"{cp} Auto-generated {self.LANGUAGE} — DO NOT EDIT")
        self._line(f"{cp} Generated: {ts}")
        if self._parameters:
            self._line(f"{cp} Parameters:")
            for key, val in self._parameters.items():
                val_str = hex(val) if isinstance(val, int) and val > 255 else str(val)
                self._line(f"{cp}   {key}: {val_str}")
        self._line(f"{cp} {'=' * 68}")
        self._blank()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def emit(self, node: HdlNode) -> str:
        """Visit ``node`` and return the complete generated source as a string.

        Can be called multiple times on different nodes; each call resets
        the internal buffer first.
        """
        self._lines = []
        self._level = 0
        self.visit(node)
        return "\n".join(self._lines) + "\n"

    def save(self, node: HdlNode, filename: str | Path) -> Path:
        """Emit ``node`` and write the result to ``filename``.

        Creates parent directories if they do not exist.

        Parameters
        ----------
        node:
            The root AST node to emit (typically a ``Module``).
        filename:
            Destination file path.  The ``.sv`` / ``.vhd`` extension is
            *not* added automatically — the caller controls the filename.

        Returns
        -------
        Path
            The resolved absolute path of the written file.
        """
        path = Path(filename).resolve()
        path.parent.mkdir(parents=True, exist_ok=True)
        source = self.emit(node)
        path.write_text(source, encoding="utf-8")
        return path

    # ------------------------------------------------------------------
    # Expression rendering (language-agnostic helpers)
    # ------------------------------------------------------------------

    def _render_expr(self, expr: object) -> str:
        """Render any expression object to a string.

        Handles ``Signal``, ``Slice``, ``Concat``, ``Ternary``, ``int``,
        and raw ``str`` expressions.  Subclasses may override to add
        language-specific formatting.
        """
        from hdl_ast import Concat, Signal, Slice, Ternary

        if isinstance(expr, Slice):
            if expr.msb == expr.lsb:
                return f"{expr.signal.name}[{expr.msb}]"
            return f"{expr.signal.name}[{expr.msb}:{expr.lsb}]"
        if isinstance(expr, Signal):
            return expr.name
        if isinstance(expr, Concat):
            # Concat(*parts) — but callers sometimes pass a list as the
            # single argument: Concat([a, b]).  Flatten that case.
            raw = expr.parts
            if len(raw) == 1 and isinstance(raw[0], (list, tuple)):
                raw = raw[0]
            parts = ", ".join(self._render_expr(s) for s in raw)
            return f"{{{parts}}}"
        if isinstance(expr, Ternary):
            cond = self._render_expr(expr.condition)
            t = self._render_expr(expr.true_val)
            f_ = self._render_expr(expr.false_val)
            return f"({cond} ? {t} : {f_})"
        if isinstance(expr, int):
            return str(expr)
        return str(expr)

    # ------------------------------------------------------------------
    # Fallback visitor
    # ------------------------------------------------------------------

    def generic_visit(self, node: HdlNode) -> None:
        """Silently skip unknown node types."""
        pass


__all__ = ["BaseEmitter"]
