# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
test_pipeline.py — Unit tests for pipeline.py
==============================================

Run with:
    python -m pytest sdk/generators/bridge/test_pipeline.py -v
"""

import pytest
from hdl_ast import (
    Always,
    Direction,
    Edge,
    If,
    Module,
    NonBlockingAssign,
    ResetStyle,
    Signal,
)
from pipeline import RegisterSliceBuilder

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _clk() -> Signal:
    return Signal("clk", direction=Direction.INPUT)


def _rst_n() -> Signal:
    return Signal("rst_n", direction=Direction.INPUT)


def _sigs(n: int = 3, width: int = 8) -> list:
    return [Signal(f"sig{i}", width=width, direction=Direction.INPUT) for i in range(n)]


def _builder(stages: int = 1, with_reset: bool = True, **kwargs) -> RegisterSliceBuilder:
    return RegisterSliceBuilder(
        signals=_sigs(),
        stages=stages,
        clk=_clk(),
        rst_n=_rst_n() if with_reset else None,
        **kwargs,
    )


# ===========================================================================
# Construction validation
# ===========================================================================


class TestConstruction:
    def test_negative_stages_raises(self) -> None:
        with pytest.raises(ValueError, match="stages"):
            RegisterSliceBuilder(signals=_sigs(), stages=-1, clk=_clk())

    def test_empty_signals_raises(self) -> None:
        with pytest.raises(ValueError, match="empty"):
            RegisterSliceBuilder(signals=[], stages=1, clk=_clk())

    def test_repr(self) -> None:
        b = _builder()
        r = repr(b)
        assert "RegisterSliceBuilder" in r
        assert "clk" in r

    def test_outputs_before_build_raises(self) -> None:
        b = _builder()
        with pytest.raises(RuntimeError, match="build"):
            _ = b.outputs

    def test_pipeline_stages_before_build_raises(self) -> None:
        b = _builder()
        with pytest.raises(RuntimeError, match="build"):
            _ = b.pipeline_stages

    def test_double_build_raises(self) -> None:
        b = _builder()
        b.build()
        with pytest.raises(RuntimeError, match="already been called"):
            b.build()


# ===========================================================================
# Zero stages (pass-through)
# ===========================================================================


class TestZeroStages:
    def test_returns_empty_lists(self) -> None:
        b = _builder(stages=0)
        sigs, blks = b.build()
        assert sigs == []
        assert blks == []

    def test_outputs_equal_original_signals(self) -> None:
        sources = _sigs(3)
        b = RegisterSliceBuilder(signals=sources, stages=0, clk=_clk())
        b.build()
        assert b.outputs == sources

    def test_pipeline_stages_empty(self) -> None:
        b = _builder(stages=0)
        b.build()
        assert b.pipeline_stages == []


# ===========================================================================
# Single stage
# ===========================================================================


class TestSingleStage:
    def test_intermediate_signal_count(self) -> None:
        b = _builder(stages=1)
        sigs, _ = b.build()
        assert len(sigs) == 3  # one per input signal

    def test_always_block_count(self) -> None:
        b = _builder(stages=1)
        _, blks = b.build()
        assert len(blks) == 1

    def test_always_block_type(self) -> None:
        b = _builder(stages=1)
        _, blks = b.build()
        assert isinstance(blks[0], Always)

    def test_intermediate_signal_naming(self) -> None:
        sources = _sigs(3)
        b = RegisterSliceBuilder(signals=sources, stages=1, clk=_clk())
        inter, _ = b.build()
        assert inter[0].name == "sig0_s1"
        assert inter[1].name == "sig1_s1"
        assert inter[2].name == "sig2_s1"

    def test_intermediate_signals_are_local(self) -> None:
        b = _builder(stages=1)
        inter, _ = b.build()
        for sig in inter:
            assert sig.direction == Direction.LOCAL

    def test_intermediate_signal_widths_preserved(self) -> None:
        sources = [Signal("a", width=16), Signal("b", width=32)]
        b = RegisterSliceBuilder(signals=sources, stages=1, clk=_clk())
        inter, _ = b.build()
        assert inter[0].width == 16
        assert inter[1].width == 32

    def test_outputs_are_stage1_signals(self) -> None:
        b = _builder(stages=1)
        inter, _ = b.build()
        assert b.outputs == inter

    def test_pipeline_stage_descriptor(self) -> None:
        sources = _sigs(2)
        b = RegisterSliceBuilder(signals=sources, stages=1, clk=_clk())
        b.build()
        stages = b.pipeline_stages
        assert len(stages) == 1
        assert stages[0].stage_id == 0
        assert stages[0].inputs == sources
        assert len(stages[0].outputs) == 2

    def test_always_body_contains_if_with_reset(self) -> None:
        b = _builder(stages=1, with_reset=True)
        _, blks = b.build()
        body = blks[0].body
        assert len(body) == 1
        assert isinstance(body[0], If)

    def test_always_body_no_if_without_reset(self) -> None:
        b = _builder(stages=1, with_reset=False)
        _, blks = b.build()
        body = blks[0].body
        # All statements should be NonBlockingAssign directly
        for stmt in body:
            assert isinstance(stmt, NonBlockingAssign)

    def test_nonblocking_assigns_in_else_branch(self) -> None:
        b = _builder(stages=1, with_reset=True)
        _, blks = b.build()
        if_node = blks[0].body[0]
        assert isinstance(if_node, If)
        for stmt in if_node.else_body:
            assert isinstance(stmt, NonBlockingAssign)

    def test_reset_stmts_use_reset_val(self) -> None:
        sources = [Signal("x", width=8, reset_val=0xFF)]
        b = RegisterSliceBuilder(signals=sources, stages=1, clk=_clk(), rst_n=_rst_n())
        _, blks = b.build()
        if_node = blks[0].body[0]
        reset_assign = if_node.then_body[0]
        assert isinstance(reset_assign, NonBlockingAssign)
        assert reset_assign.source == 0xFF


# ===========================================================================
# Multiple stages
# ===========================================================================


class TestMultipleStages:
    def test_two_stages_signal_count(self) -> None:
        b = _builder(stages=2)
        inter, _ = b.build()
        # 3 signals × 2 stages = 6 intermediate signals
        assert len(inter) == 6

    def test_two_stages_always_count(self) -> None:
        b = _builder(stages=2)
        _, blks = b.build()
        assert len(blks) == 2

    def test_three_stages_signal_count(self) -> None:
        b = _builder(stages=3)
        inter, _ = b.build()
        assert len(inter) == 9  # 3 × 3

    def test_stage_naming_chain(self) -> None:
        sources = [Signal("d", width=8)]
        b = RegisterSliceBuilder(signals=sources, stages=3, clk=_clk())
        inter, _ = b.build()
        names = [s.name for s in inter]
        assert names == ["d_s1", "d_s2", "d_s3"]

    def test_outputs_are_last_stage(self) -> None:
        sources = [Signal("d", width=8)]
        b = RegisterSliceBuilder(signals=sources, stages=3, clk=_clk())
        b.build()
        assert b.outputs[0].name == "d_s3"

    def test_stage_chain_inputs_outputs(self) -> None:
        """Stage N+1 inputs must equal stage N outputs."""
        b = _builder(stages=3)
        b.build()
        stages = b.pipeline_stages
        for i in range(1, len(stages)):
            assert stages[i].inputs == stages[i - 1].outputs

    def test_pipeline_stage_ids(self) -> None:
        b = _builder(stages=3)
        b.build()
        for i, stage in enumerate(b.pipeline_stages):
            assert stage.stage_id == i


# ===========================================================================
# Sensitivity list (sync vs async reset)
# ===========================================================================


class TestSensitivityList:
    def test_sync_reset_only_clk(self) -> None:
        b = RegisterSliceBuilder(
            signals=_sigs(1),
            stages=1,
            clk=_clk(),
            rst_n=_rst_n(),
            reset_style=ResetStyle.SYNC,
        )
        _, blks = b.build()
        sens = blks[0].sensitivity
        assert len(sens) == 1
        assert sens[0] == (Edge.POSEDGE, b.clk)

    def test_async_reset_adds_negedge(self) -> None:
        rst = _rst_n()
        b = RegisterSliceBuilder(
            signals=_sigs(1),
            stages=1,
            clk=_clk(),
            rst_n=rst,
            reset_style=ResetStyle.ASYNC,
            active_low_reset=True,
        )
        _, blks = b.build()
        sens = blks[0].sensitivity
        assert len(sens) == 2
        assert (Edge.NEGEDGE, rst) in sens

    def test_async_active_high_adds_posedge(self) -> None:
        rst = Signal("rst", direction=Direction.INPUT)
        b = RegisterSliceBuilder(
            signals=_sigs(1),
            stages=1,
            clk=_clk(),
            rst_n=rst,
            reset_style=ResetStyle.ASYNC,
            active_low_reset=False,
        )
        _, blks = b.build()
        sens = blks[0].sensitivity
        assert (Edge.POSEDGE, rst) in sens

    def test_no_reset_only_clk(self) -> None:
        b = RegisterSliceBuilder(
            signals=_sigs(1),
            stages=1,
            clk=_clk(),
            rst_n=None,
        )
        _, blks = b.build()
        sens = blks[0].sensitivity
        assert len(sens) == 1
        assert sens[0][0] == Edge.POSEDGE


# ===========================================================================
# Reset condition string
# ===========================================================================


class TestResetCondition:
    def test_active_low_condition(self) -> None:
        b = RegisterSliceBuilder(
            signals=_sigs(1),
            stages=1,
            clk=_clk(),
            rst_n=_rst_n(),
            active_low_reset=True,
        )
        _, blks = b.build()
        if_node = blks[0].body[0]
        assert isinstance(if_node, If)
        assert "!rst_n" in str(if_node.condition)

    def test_active_high_condition(self) -> None:
        rst = Signal("rst", direction=Direction.INPUT)
        b = RegisterSliceBuilder(
            signals=_sigs(1),
            stages=1,
            clk=_clk(),
            rst_n=rst,
            active_low_reset=False,
        )
        _, blks = b.build()
        if_node = blks[0].body[0]
        assert isinstance(if_node, If)
        assert if_node.condition == "rst"


# ===========================================================================
# Integration: add pipeline to a Module
# ===========================================================================


class TestModuleIntegration:
    def test_add_to_module(self) -> None:
        clk = _clk()
        rst_n = _rst_n()
        sources = _sigs(4, width=32)

        m = Module("dut")
        m.add_port(clk)
        m.add_port(rst_n)
        for s in sources:
            m.add_port(s)

        b = RegisterSliceBuilder(
            signals=sources,
            stages=2,
            clk=clk,
            rst_n=rst_n,
            reset_style=ResetStyle.ASYNC,
        )
        inter, blks = b.build()

        for sig in inter:
            m.add_signal(sig)
        for blk in blks:
            m.add_block(blk)

        # 2 (clk/rst) + 4 ports = 6 ports; 8 intermediate signals; 2 always blocks
        assert len(m.ports) == 6
        assert len(m.signals) == 8
        assert len(m.body) == 2

    def test_outputs_usable_as_assign_source(self) -> None:
        from hdl_ast import Assign

        clk = _clk()
        sources = [Signal("data", width=32, direction=Direction.INPUT)]
        dst = Signal("data_out", width=32, direction=Direction.OUTPUT)

        b = RegisterSliceBuilder(signals=sources, stages=1, clk=clk)
        b.build()

        # Connect final stage output to a module output port
        assign = Assign(target=dst, source=b.outputs[0])
        assert assign.target is dst
        assert assign.source is b.outputs[0]
