# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
main.py — RTL Bridge Generator Entry Point
==========================================

Parses CLI arguments (or a YAML config file), runs Pre-Elaboration
Checks, builds the AST, validates it, and emits the output file(s).

Exit codes
----------
0  Success
1  Internal / unexpected error
2  Configuration / pre-elaboration error (ConfigError)
3  Validation error (ValidationError)

Usage examples
--------------
# Single bridge, inline args
python main.py --protocol axilite --data-width 32 --addr-width 16 \\
               --base-addr 0x40000000 --size 0x10000 \\
               --module-name axi_to_sram --output axi_to_sram.sv

# Batch mode via YAML
python main.py --config bridges.yaml
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

# ---------------------------------------------------------------------------
# Optional PyYAML import (only required for --config)
# ---------------------------------------------------------------------------
try:
    import yaml as _yaml

    _YAML_AVAILABLE = True
except ImportError:  # pragma: no cover
    _YAML_AVAILABLE = False


# ---------------------------------------------------------------------------
# Errors
# ---------------------------------------------------------------------------


class ConfigError(Exception):
    """Raised for any pre-elaboration configuration problem."""


# ---------------------------------------------------------------------------
# Pre-Elaboration Checks  (Section 4.3)
# ---------------------------------------------------------------------------

_VALID_DATA_WIDTHS = {8, 16, 32, 64, 128}
_VALID_PROTOCOLS = {"axilite", "axi4", "avalon", "native"}
_VALID_TARGET_PROTOS = {"native", "avalon", "axilite", None}  # None = single-interface mode
_VALID_LANGS = {"sv", "vhdl"}
_VALID_ROLES = {"slave", "master"}
_VALID_RESETS = {"async", "sync"}
_VALID_POLICIES = {"slverr", "decerr", "ignore"}
_YAML_VERSION = "1"


def _parse_int(value: Any, field: str) -> int:
    """Accept decimal or hex strings / plain ints."""
    if isinstance(value, int):
        return value
    try:
        return int(str(value), 0)  # handles "0x…" and decimal strings
    except (ValueError, TypeError):
        raise ConfigError(f"{field}: cannot parse {value!r} as an integer")


def pre_elaborate_checks(cfg: Dict[str, Any]) -> None:
    """Run all pre-elaboration checks on a single bridge config dict.

    Parameters
    ----------
    cfg:
        Flat dict with keys matching the CLI / YAML bridge fields.
        All values must already be resolved (defaults applied).

    Raises
    ------
    ConfigError
        On the first failing check.
    """
    protocol = cfg.get("protocol", "axilite")
    data_width = int(cfg.get("data_width", 32))
    addr_width = int(cfg.get("addr_width", 32))
    base_addr = _parse_int(cfg.get("base_addr", 0), "base_addr")
    size = _parse_int(cfg.get("size", 65536), "size")
    stages = int(cfg.get("stages", 0))
    lang = cfg.get("lang", "sv")
    no_sva = bool(cfg.get("no_sva", False))

    # E1 — Unsupported data width
    if data_width not in _VALID_DATA_WIDTHS:
        raise ConfigError(f"data_width must be one of {sorted(_VALID_DATA_WIDTHS)}; got {data_width}")

    # E2 — Address width out of range
    if not (1 <= addr_width <= 64):
        raise ConfigError(f"addr_width must be in [1, 64]; got {addr_width}")

    bytes_per_word = data_width // 8

    # E3 — Misaligned base address
    if base_addr % bytes_per_word != 0:
        raise ConfigError(f"base_addr {hex(base_addr)} is not aligned to data_width/8 = {bytes_per_word} bytes")

    # E4 — Region size not a power of two
    if size == 0 or (size & (size - 1)) != 0:
        raise ConfigError(f"size must be a power of two; got {size}")

    # E5 — Region size smaller than one word
    if size < bytes_per_word:
        raise ConfigError(f"size {size} bytes is smaller than one word ({bytes_per_word} bytes)")

    # E6 — Address width too narrow for region
    num_words = size // bytes_per_word
    if num_words > (1 << addr_width):
        import math

        needed = math.ceil(math.log2(num_words))
        raise ConfigError(f"addr_width={addr_width} bits cannot address {num_words} words (need ≥ {needed} bits)")

    # E7 — Unsupported width ratio (Avalon only)
    if protocol == "avalon" and data_width not in {32, 64, 128}:
        raise ConfigError(f"Avalon-MM bridge supports data_width 32, 64, or 128; got {data_width}")

    # E8 — SVA requested for VHDL output
    if lang == "vhdl" and not no_sva:
        raise ConfigError("SVA assertions are not supported for VHDL output; use --no-sva or --lang sv")

    # E9 — Unknown protocol
    if protocol not in _VALID_PROTOCOLS:
        raise ConfigError(f"Unknown protocol {protocol!r}; supported: {', '.join(sorted(_VALID_PROTOCOLS))}")

    # E12 — Pipeline stages out of range
    if not (0 <= stages <= 8):
        raise ConfigError(f"stages must be in [0, 8]; got {stages}")


# ---------------------------------------------------------------------------
# AST / emitter helpers
# ---------------------------------------------------------------------------


def _build_module(cfg: Dict[str, Any]):
    """Build an HDL AST Module from a resolved bridge config."""
    import math

    from bus_interfaces import AvalonMMInterface, AXI4Interface, AXILiteInterface, InterfaceRole, NativeMemInterface
    from hdl_ast import Direction, Module, ResetStyle, Signal

    protocol = cfg.get("protocol", "axilite")
    target_protocol = cfg.get("target_protocol", None)
    data_width = int(cfg.get("data_width", 32))
    addr_width = int(cfg.get("addr_width", 32))
    prefix = cfg.get("prefix", "s")
    role_str = cfg.get("role", "slave")
    name = cfg.get("name", "bridge")
    reset_style_str = cfg.get("reset_style", "async")

    role = InterfaceRole.SLAVE if role_str == "slave" else InterfaceRole.MASTER
    reset_style = ResetStyle.ASYNC if reset_style_str == "async" else ResetStyle.SYNC

    clk = Signal("clk", direction=Direction.INPUT)
    rst_n = Signal("rst_n", direction=Direction.INPUT)

    m = Module(name)
    m.add_port(clk)
    m.add_port(rst_n)

    # -- Cross-protocol bridge (Logic Layer) -------------------------------
    if protocol == "axilite" and target_protocol == "avalon":
        byte_shift = int(math.log2(data_width // 8))
        avl_addr_width = addr_width - byte_shift

        axi = AXILiteInterface(
            data_width=data_width,
            addr_width=addr_width,
            role=InterfaceRole.SLAVE,
            prefix=prefix,
        )
        avl = AvalonMMInterface(
            data_width=data_width,
            addr_width=avl_addr_width,
            role=InterfaceRole.MASTER,
            prefix="m_avl",
        )
        for sig in axi.get_signals():
            m.add_port(sig)
        for sig in avl.get_signals():
            m.add_port(sig)

        from bridge_logic import build_axilite_to_avalon

        internal_signals, body_nodes = build_axilite_to_avalon(
            axi,
            avl,
            clk,
            rst_n,
            reset_style=reset_style,
            active_low_reset=True,
        )
        for s in internal_signals:
            m.add_signal(s)
        for b in body_nodes:
            m.add_block(b)

        # Stash interfaces for validator
        m._axi_interfaces = [axi]
        m._avalon_interfaces = [avl]
        return m

    if protocol == "avalon" and target_protocol == "axilite":
        byte_shift = int(math.log2(data_width // 8))
        axi_addr_width = addr_width + byte_shift  # word→byte expansion

        avl = AvalonMMInterface(
            data_width=data_width,
            addr_width=addr_width,
            role=InterfaceRole.SLAVE,
            prefix=prefix,
        )
        axi = AXILiteInterface(
            data_width=data_width,
            addr_width=axi_addr_width,
            role=InterfaceRole.MASTER,
            prefix="m_axi",
        )
        for sig in avl.get_signals():
            m.add_port(sig)
        for sig in axi.get_signals():
            m.add_port(sig)

        from bridge_logic import build_avalon_to_axilite

        internal_signals, body_nodes = build_avalon_to_axilite(
            avl,
            axi,
            clk,
            rst_n,
            reset_style=reset_style,
            active_low_reset=True,
        )
        for s in internal_signals:
            m.add_signal(s)
        for b in body_nodes:
            m.add_block(b)

        m._axi_interfaces = [axi]
        m._avalon_interfaces = [avl]
        return m

    if protocol == "avalon" and target_protocol == "axi4":
        byte_shift = int(math.log2(data_width // 8))
        axi_addr_width = addr_width + byte_shift  # word→byte expansion

        avl = AvalonMMInterface(
            data_width=data_width,
            addr_width=addr_width,
            role=InterfaceRole.SLAVE,
            prefix=prefix,
        )
        axi = AXI4Interface(
            data_width=data_width,
            addr_width=axi_addr_width,
            id_width=int(cfg.get("id_width", 4)),
            role=InterfaceRole.MASTER,
            prefix="m_axi",
        )
        for sig in avl.get_signals():
            m.add_port(sig)
        for sig in axi.get_signals():
            m.add_port(sig)

        from bridge_logic import build_avalon_to_axi4

        internal_signals, body_nodes = build_avalon_to_axi4(
            avl,
            axi,
            clk,
            rst_n,
            reset_style=reset_style,
            active_low_reset=True,
        )
        for s in internal_signals:
            m.add_signal(s)
        for b in body_nodes:
            m.add_block(b)

        m._axi_interfaces = [axi]
        m._avalon_interfaces = [avl]
        return m

    if protocol == "axi4" and target_protocol == "avalon":
        byte_shift = int(math.log2(data_width // 8))
        avl_addr_width = addr_width - byte_shift
        burst_mode = bool(cfg.get("burst", False))

        axi = AXI4Interface(
            data_width=data_width,
            addr_width=addr_width,
            id_width=int(cfg.get("id_width", 4)),
            role=InterfaceRole.SLAVE,
            prefix=prefix,
        )
        avl = AvalonMMInterface(
            data_width=data_width,
            addr_width=avl_addr_width,
            role=InterfaceRole.MASTER,
            prefix="m_avl",
            burstcount_width=8 if burst_mode else 0,
        )
        for sig in axi.get_signals():
            m.add_port(sig)
        for sig in avl.get_signals():
            m.add_port(sig)

        if burst_mode:
            from bridge_logic import build_axi4_to_avalon_burst

            internal_signals, body_nodes = build_axi4_to_avalon_burst(
                axi,
                avl,
                clk,
                rst_n,
                reset_style=reset_style,
                active_low_reset=True,
            )
        else:
            from bridge_logic import build_axi4_to_avalon

            internal_signals, body_nodes = build_axi4_to_avalon(
                axi,
                avl,
                clk,
                rst_n,
                reset_style=reset_style,
                active_low_reset=True,
            )
        for s in internal_signals:
            m.add_signal(s)
        for b in body_nodes:
            m.add_block(b)

        m._axi_interfaces = [axi]
        m._avalon_interfaces = [avl]
        return m

    if protocol == "axi4" and target_protocol == "native":
        byte_shift = int(math.log2(data_width // 8))
        native_addr_width = addr_width - byte_shift

        axi = AXI4Interface(
            data_width=data_width,
            addr_width=addr_width,
            id_width=int(cfg.get("id_width", 4)),
            role=InterfaceRole.SLAVE,
            prefix=prefix,
        )
        mem = NativeMemInterface(
            data_width=data_width,
            addr_width=native_addr_width,
            role=InterfaceRole.MASTER,
            prefix="m_mem",
        )
        for sig in axi.get_signals():
            m.add_port(sig)
        for sig in mem.get_signals():
            m.add_port(sig)

        from bridge_logic import build_axi4_to_native

        read_latency = int(cfg.get("read_latency", 1))
        internal_signals, body_nodes = build_axi4_to_native(
            axi,
            mem,
            clk,
            rst_n,
            read_latency=read_latency,
            reset_style=reset_style,
            active_low_reset=True,
        )
        for s in internal_signals:
            m.add_signal(s)
        for b in body_nodes:
            m.add_block(b)

        m._axi_interfaces = [axi]
        m._native_interfaces = [mem]
        return m

    if protocol == "native" and target_protocol == "avalon":
        mem = NativeMemInterface(
            data_width=data_width,
            addr_width=addr_width,
            role=InterfaceRole.SLAVE,
            prefix=prefix,
        )
        avl = AvalonMMInterface(
            data_width=data_width,
            addr_width=addr_width,
            role=InterfaceRole.MASTER,
            prefix="m_avl",
        )
        for sig in mem.get_signals():
            m.add_port(sig)
        for sig in avl.get_signals():
            m.add_port(sig)

        from bridge_logic import build_native_to_avalon

        internal_signals, body_nodes = build_native_to_avalon(
            mem,
            avl,
            clk,
            rst_n,
            reset_style=reset_style,
            active_low_reset=True,
        )
        for s in internal_signals:
            m.add_signal(s)
        for b in body_nodes:
            m.add_block(b)

        m._native_interfaces = [mem]
        m._avalon_interfaces = [avl]
        return m

    if protocol == "axilite" and target_protocol == "native":
        byte_shift = int(math.log2(data_width // 8))
        native_addr_width = addr_width - byte_shift

        axi = AXILiteInterface(
            data_width=data_width,
            addr_width=addr_width,
            role=InterfaceRole.SLAVE,
            prefix=prefix,
        )
        mem = NativeMemInterface(
            data_width=data_width,
            addr_width=native_addr_width,
            role=InterfaceRole.MASTER,
            prefix="m_mem",
        )
        for sig in axi.get_signals():
            m.add_port(sig)
        for sig in mem.get_signals():
            m.add_port(sig)

        from bridge_logic import build_axilite_to_native

        read_latency = int(cfg.get("read_latency", 1))
        internal_signals, body_nodes = build_axilite_to_native(
            axi,
            mem,
            clk,
            rst_n,
            read_latency=read_latency,
            reset_style=reset_style,
            active_low_reset=True,
        )
        for s in internal_signals:
            m.add_signal(s)
        for b in body_nodes:
            m.add_block(b)

        m._axi_interfaces = [axi]
        m._native_interfaces = [mem]
        return m

    if protocol == "native" and target_protocol == "axilite":
        mem = NativeMemInterface(
            data_width=data_width,
            addr_width=addr_width,
            role=InterfaceRole.SLAVE,
            prefix=prefix,
        )
        axi = AXILiteInterface(
            data_width=data_width,
            addr_width=addr_width + int(math.log2(data_width // 8)),
            role=InterfaceRole.MASTER,
            prefix="m_axi",
        )
        for sig in mem.get_signals():
            m.add_port(sig)
        for sig in axi.get_signals():
            m.add_port(sig)

        from bridge_logic import build_native_to_axilite

        internal_signals, body_nodes = build_native_to_axilite(
            mem,
            axi,
            clk,
            rst_n,
            reset_style=reset_style,
            active_low_reset=True,
        )
        for s in internal_signals:
            m.add_signal(s)
        for b in body_nodes:
            m.add_block(b)

        m._native_interfaces = [mem]
        m._axi_interfaces = [axi]
        return m

    # -- Single-interface mode (port-only, no FSM) -------------------------
    if protocol == "axilite":
        iface = AXILiteInterface(
            data_width=data_width,
            addr_width=addr_width,
            role=role,
            prefix=prefix,
        )
    elif protocol == "axi4":
        iface = AXI4Interface(
            data_width=data_width,
            addr_width=addr_width,
            id_width=int(cfg.get("id_width", 4)),
            role=role,
            prefix=prefix,
        )
    elif protocol == "avalon":
        iface = AvalonMMInterface(
            data_width=data_width,
            addr_width=addr_width,
            role=role,
            prefix=prefix,
        )
    elif protocol == "native":
        iface = NativeMemInterface(
            data_width=data_width,
            addr_width=addr_width,
            role=role,
            prefix=prefix,
        )
    else:
        raise ConfigError(f"Unknown protocol: {protocol!r}")

    for sig in iface.get_signals():
        m.add_port(sig)

    return m


def _run_validator(module, cfg: Dict[str, Any]):
    """Run the Validator and return SVA properties (may be empty).

    Width checks are always run.  Handshake and waitrequest checks are run
    when the module has stashed interface objects (cross-protocol mode).
    """
    from validator import Validator

    v = Validator(module)
    v.check_widths()

    # Cross-protocol mode: run protocol-specific checks
    axi_ifaces = getattr(module, "_axi_interfaces", [])
    avl_ifaces = getattr(module, "_avalon_interfaces", [])
    if axi_ifaces:
        v.check_handshakes(axi_ifaces)
    if avl_ifaces:
        v.check_waitrequest(avl_ifaces)

    protocol = cfg.get("protocol", "axilite")
    no_sva = cfg.get("no_sva", False)
    lang = cfg.get("lang", "sv")

    if no_sva or lang != "sv":
        return []
    if axi_ifaces:
        return v.inject_sva(axi_ifaces[0])
    return []


def _emit_module(module, cfg: Dict[str, Any], output_path: Path) -> None:
    """Emit the module to the given output path."""
    lang = cfg.get("lang", "sv")
    base_addr = _parse_int(cfg.get("base_addr", 0), "base_addr")
    data_width = int(cfg.get("data_width", 32))

    params = {
        "Base Address": base_addr,
        "Data Width": data_width,
        "Protocol": cfg.get("protocol", "axilite"),
    }

    if lang == "sv":
        from emitter_sv import SystemVerilogEmitter

        emitter = SystemVerilogEmitter(parameters=params)
    else:
        from emitter_vhdl import VHDLEmitter

        emitter = VHDLEmitter(parameters=params)

    emitter.save(module, output_path)


def _default_output(cfg: Dict[str, Any], output_dir: Optional[Path]) -> Path:
    """Compute the default output path for a bridge config."""
    lang = cfg.get("lang", "sv")
    ext = "sv" if lang == "sv" else "vhd"
    name = cfg.get("name", "bridge")
    filename = f"{name}.{ext}"
    if output_dir:
        return output_dir / filename
    return Path(filename)


# ---------------------------------------------------------------------------
# Single-bridge generation
# ---------------------------------------------------------------------------


def generate_bridge(cfg: Dict[str, Any], output_path: Path, verbose: bool = False, dry_run: bool = False) -> None:
    """Full pipeline for one bridge: check → build → validate → emit.

    Parameters
    ----------
    cfg:
        Resolved bridge configuration dict.
    output_path:
        Destination file path.
    verbose:
        If True, print generated source to stdout.
    dry_run:
        If True, validate only — do not write the file.

    Raises
    ------
    ConfigError
        On pre-elaboration failure.
    ValidationError
        On AST validation failure.
    """
    from validator import ValidationError

    # 1. Pre-elaboration checks
    pre_elaborate_checks(cfg)

    # 2. Build AST
    module = _build_module(cfg)

    # 3. Validate
    try:
        _run_validator(module, cfg)
    except ValidationError as exc:
        raise

    # 4. Emit
    if dry_run:
        print(f"[dry-run] Would write: {output_path}")
        return

    _emit_module(module, cfg, output_path)

    if verbose:
        print(output_path.read_text())

    print(f"Generated: {output_path}")


# ---------------------------------------------------------------------------
# YAML batch mode
# ---------------------------------------------------------------------------


def _load_yaml_config(path: Path) -> List[Dict[str, Any]]:
    """Load and validate a YAML config file.

    Returns a list of resolved per-bridge config dicts.

    Raises
    ------
    ConfigError
        On schema problems.
    """
    if not _YAML_AVAILABLE:
        raise ConfigError("PyYAML is required for --config mode. Install it with: pip install pyyaml")

    with open(path) as fh:
        raw = _yaml.safe_load(fh)

    if not isinstance(raw, dict):
        raise ConfigError("YAML config must be a mapping at the top level")

    # E10 — Schema version
    version = str(raw.get("version", "1"))
    if version != _YAML_VERSION:
        raise ConfigError(f"Unsupported config schema version {version!r}; expected {_YAML_VERSION!r}")

    defaults = raw.get("defaults", {}) or {}
    output_dir_str = raw.get("output_dir")
    output_dir = Path(output_dir_str) if output_dir_str else None

    bridges_raw = raw.get("bridges", [])
    if not bridges_raw:
        raise ConfigError("YAML config must contain at least one entry under 'bridges'")

    # E11 — Duplicate bridge names
    names_seen: set = set()
    for entry in bridges_raw:
        n = entry.get("name")
        if n in names_seen:
            raise ConfigError(f"Duplicate bridge name {n!r} in config file")
        names_seen.add(n)

    resolved = []
    for entry in bridges_raw:
        cfg = {**defaults, **entry}
        out_str = cfg.pop("output", None)
        if out_str:
            out_path = (output_dir / out_str) if output_dir else Path(out_str)
        else:
            out_path = _default_output(cfg, output_dir)
        cfg["_output_path"] = out_path
        resolved.append(cfg)

    return resolved


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------


def _build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="bridge-gen",
        description="RTL Bridge Generator — AXI-Lite / Avalon-MM → Native Memory",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )

    # Mutually exclusive: config file vs inline args
    mode = p.add_mutually_exclusive_group()
    mode.add_argument(
        "--config",
        metavar="FILE",
        help="YAML config file for batch / complex generation",
    )

    # Inline args (ignored when --config is given)
    p.add_argument(
        "--protocol", default="axilite", choices=["axilite", "avalon", "axi4", "native"], help="Source bus protocol"
    )
    p.add_argument(
        "--target-protocol",
        default=None,
        choices=["native", "avalon", "axilite", "axi4"],
        help="Target bus protocol (enables cross-protocol bridge FSM)",
    )
    p.add_argument("--role", default="slave", choices=["slave", "master"], help="Interface role")
    p.add_argument("--data-width", type=int, default=32, help="Data bus width in bits (must be power-of-two >= 8)")
    p.add_argument("--addr-width", type=int, default=16, help="Word address width in bits")
    p.add_argument("--id-width", type=int, default=4, help="AXI4 ID width in bits")
    p.add_argument("--base-addr", default="0", metavar="ADDR", help="Base byte address (decimal or 0x hex)")
    p.add_argument("--size", default="65536", metavar="BYTES", help="Mapped region size in bytes (decimal or 0x hex)")
    p.add_argument("--prefix", default="s", help="Signal name prefix")
    p.add_argument("--stages", type=int, default=0, metavar="N", help="Register-slice pipeline stages (0–8)")
    p.add_argument("--reset-style", default="async", choices=["async", "sync"], help="Reset style")
    p.add_argument(
        "--error-policy", default="slverr", choices=["slverr", "decerr", "ignore"], help="Out-of-range error response"
    )
    p.add_argument("--lang", default="sv", choices=["sv", "vhdl"], help="Output language")
    p.add_argument("--output", metavar="FILE", help="Output file path (default: <module-name>.<ext>)")
    p.add_argument("--module-name", default="bridge", help="Top-level module / entity name")
    p.add_argument("--no-sva", action="store_true", help="Suppress SVA assertion injection (SV only)")
    p.add_argument("--burst", action="store_true", help="Enable Avalon-MM burst mode (adds burstcount signal)")
    p.add_argument("--verbose", action="store_true", help="Print generated source to stdout")
    p.add_argument("--dry-run", action="store_true", help="Validate only; do not write the output file")

    return p


def _args_to_cfg(args: argparse.Namespace) -> Dict[str, Any]:
    """Convert parsed argparse namespace to a bridge config dict."""
    return {
        "name": args.module_name,
        "protocol": args.protocol,
        "target_protocol": args.target_protocol,
        "role": args.role,
        "data_width": args.data_width,
        "addr_width": args.addr_width,
        "id_width": args.id_width,
        "base_addr": _parse_int(args.base_addr, "--base-addr"),
        "size": _parse_int(args.size, "--size"),
        "prefix": args.prefix,
        "stages": args.stages,
        "reset_style": args.reset_style,
        "error_policy": args.error_policy,
        "lang": args.lang,
        "no_sva": args.no_sva,
        "burst": args.burst,
    }


def main(argv: Optional[List[str]] = None) -> int:
    """Entry point.  Returns an exit code."""
    from validator import ValidationError

    parser = _build_parser()
    args = parser.parse_args(argv)

    try:
        if args.config:
            # ---- Batch / YAML mode ----
            configs = _load_yaml_config(Path(args.config))
            errors = 0
            for cfg in configs:
                out_path: Path = cfg.pop("_output_path")
                try:
                    generate_bridge(
                        cfg,
                        out_path,
                        verbose=args.verbose,
                        dry_run=args.dry_run,
                    )
                except (ConfigError, ValidationError) as exc:
                    print(f"ERROR [{cfg.get('name', '?')}]: {exc}", file=sys.stderr)
                    errors += 1
            return 0 if errors == 0 else (2 if errors else 0)

        else:
            # ---- Single-bridge / inline mode ----
            cfg = _args_to_cfg(args)
            if args.output:
                out_path = Path(args.output)
            else:
                out_path = _default_output(cfg, output_dir=None)

            generate_bridge(cfg, out_path, verbose=args.verbose, dry_run=args.dry_run)
            return 0

    except ConfigError as exc:
        print(f"Configuration error: {exc}", file=sys.stderr)
        return 2
    except ValidationError as exc:
        print(f"Validation error: {exc}", file=sys.stderr)
        return 3
    except (RuntimeError, TypeError, ValueError, OSError) as exc:  # pragma: no cover
        print(f"Internal error: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
