# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""conftest.py — pytest configuration for bridge-gen tests.

Adds the bridge-gen directory to sys.path so that ``import hdl_ast``
works regardless of how pytest discovers the package.
"""


# Ensure the bridge-gen directory is on sys.path so tests can
# ``import hdl_ast`` directly (the package __init__.py uses relative
# imports for use as a library; tests import the module directly).

# Prevent pytest from trying to collect __init__.py as a test module.
# The __init__.py uses relative imports which break when the directory
# name contains a hyphen (bridge-gen is not a valid Python identifier).
collect_ignore = ["__init__.py"]
