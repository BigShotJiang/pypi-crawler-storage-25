# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
emitter_vhdl.py — VHDL Emitter
================================

Converts an HDL AST ``Module`` into synthesizable VHDL-2008 source.

Inherits ~80 % of its logic from ``BaseEmitter`` (indentation, line buffer,
``emit()`` / ``save()`` API, expression rendering, header).  Only the
language-specific ``visit_*`` methods are implemented here.

Usage::

    from emitter_vhdl import VHDLEmitter
    from bus_interfaces import AXILiteInterface, InterfaceRole
    from hdl_ast import Module, Signal, Direction

    axi = AXILiteInterface(data_width=32, addr_width=16,
                           role=InterfaceRole.SLAVE, prefix="s_axi")
    m = Module("my_bridge")
    for sig in axi.get_signals():
        m.add_port(sig)

    emitter = VHDLEmitter(
        parameters={"Base Address": 0x4000_0000, "Data Width": 32}
    )
    emitter.save(m, "my_bridge.vhd")

Generated output structure::

    -- ====================================================================
    -- Auto-generated VHDL — DO NOT EDIT
    -- Generated: 2026-02-18 23:24:00 UTC
    -- Parameters:
    --   Base Address: 0x40000000
    -- ====================================================================

    library ieee;
    use ieee.std_logic_1164.all;
    use ieee.numeric_std.all;

    entity my_bridge is
        port (
            clk          : in  std_logic;
            rst_n        : in  std_logic;
            s_axi_awaddr : in  std_logic_vector(15 downto 0);
            ...
        );
    end entity my_bridge;

    architecture rtl of my_bridge is
        signal state : std_logic_vector(1 downto 0);
    begin

        -- Continuous assignments
        s_axi_awready <= '1';

        -- Clocked process
        proc_clk : process(clk, rst_n)
        begin
            if rst_n = '0' then
                state <= (others => '0');
            elsif rising_edge(clk) then
                state <= next_state;
            end if;
        end process proc_clk;

    end architecture rtl;

VHDL-specific design decisions
-------------------------------
* **Sensitivity list**: clocked ``Always`` blocks become ``process(clk)``
  for synchronous reset or ``process(clk, rst_n)`` for asynchronous reset.
  Combinational blocks become ``process(all)`` (VHDL-2008).
* **Reset detection**: the emitter inspects the first ``If`` node inside
  a clocked ``Always`` block.  If the condition string contains ``!`` or
  ``= '0'`` it is treated as active-low reset and emitted as
  ``if rst_n = '0' then``.  Active-high is emitted as ``if rst = '1' then``.
* **Continuous assigns**: ``Assign`` nodes become concurrent signal
  assignments (``target <= source;``).
* **Case**: emitted as VHDL ``case``/``when``/``end case``.
* **Concat**: ``{a, b}`` → ``a & b``.
* **Ternary**: ``cond ? a : b`` → ``a when cond else b``.
* **Integer literals**: ``0`` → ``'0'`` for 1-bit signals,
  ``(others => '0')`` for multi-bit.  The emitter uses the *target*
  signal width to decide (when available).
"""

from __future__ import annotations

import re
from typing import Optional

from emitter_base import BaseEmitter
from hdl_ast import (
    Always,
    Assign,
    Case,
    Concat,
    Direction,
    Edge,
    If,
    Module,
    NonBlockingAssign,
    Signal,
    Slice,
    Ternary,
)


class VHDLEmitter(BaseEmitter):
    """Emits synthesizable VHDL-2008 from an HDL AST ``Module``.

    Parameters
    ----------
    indent_width:
        Spaces per indentation level (default 4).
    parameters:
        Key/value metadata written into the file header.
    generated_at:
        Override the generation timestamp (useful for deterministic tests).
    """

    LANGUAGE = "VHDL"

    # ------------------------------------------------------------------
    # Module → entity + architecture
    # ------------------------------------------------------------------

    def visit_Module(self, node: Module) -> None:
        """Emit a VHDL entity/architecture pair."""
        self._emit_header(comment_prefix="--")

        # Library / use clauses
        self._line("library ieee;")
        self._line("use ieee.std_logic_1164.all;")
        self._line("use ieee.numeric_std.all;")
        self._blank()

        # ---- entity ----
        self._line(f"entity {node.name} is")
        if node.ports:
            self._indent()
            self._line("port (")
            self._indent()
            inputs = [p for p in node.ports if p.direction == Direction.INPUT]
            outputs = [p for p in node.ports if p.direction == Direction.OUTPUT]
            all_ports = (
                inputs + outputs + [p for p in node.ports if p.direction not in (Direction.INPUT, Direction.OUTPUT)]
            )
            for i, port in enumerate(all_ports):
                sep = ";" if i < len(all_ports) - 1 else ""
                self._line(self._port_decl(port) + sep)
            self._dedent()
            self._line(");")
            self._dedent()
        self._line(f"end entity {node.name};")
        self._blank()

        # ---- architecture ----
        self._line(f"architecture rtl of {node.name} is")
        self._blank()

        if node.signals:
            self._indent()
            self._line("-- Internal signals")
            for sig in node.signals:
                self._line(self._signal_decl(sig) + ";")
            self._dedent()
            self._blank()

        self._line("begin")
        self._blank()
        self._indent()

        # Group: continuous assigns, then always blocks, then rest
        assigns = [n for n in node.body if isinstance(n, Assign)]
        always_blocks = [n for n in node.body if isinstance(n, Always)]
        rest = [n for n in node.body if not isinstance(n, (Assign, Always))]

        if assigns:
            self._line("-- Continuous assignments")
            for a in assigns:
                self.visit(a)
            self._blank()

        for idx, blk in enumerate(always_blocks):
            self.visit(blk)
            self._blank()

        for n in rest:
            self.visit(n)

        self._dedent()
        self._line("end architecture rtl;")

    # ------------------------------------------------------------------
    # Port / signal declarations
    # ------------------------------------------------------------------

    def _port_decl(self, sig: Signal) -> str:
        direction = {
            Direction.INPUT: "in ",
            Direction.OUTPUT: "out",
        }.get(sig.direction, "   ")
        type_str = self._vhdl_type(sig.width)
        return f"{sig.name:<24}: {direction} {type_str}"

    def _signal_decl(self, sig: Signal) -> str:
        type_str = self._vhdl_type(sig.width)
        return f"signal {sig.name} : {type_str}"

    def _vhdl_type(self, width: int) -> str:
        if width == 1:
            return "std_logic"
        return f"std_logic_vector({width - 1} downto 0)"

    # ------------------------------------------------------------------
    # Assign → concurrent signal assignment
    # ------------------------------------------------------------------

    def visit_Assign(self, node: Assign) -> None:
        """Emit a concurrent signal assignment."""
        target = self._render_expr(node.target)
        source = self._render_vhdl_expr(node.source, _target_width(node.target))
        self._line(f"{target} <= {source};")

    # ------------------------------------------------------------------
    # Always → process
    # ------------------------------------------------------------------

    def visit_Always(self, node: Always) -> None:
        """Emit a process block."""
        has_edge = any(e in (Edge.POSEDGE, Edge.NEGEDGE) for e, _ in node.sensitivity)

        if has_edge:
            self._emit_clocked_process(node)
        else:
            self._emit_comb_process(node)

    def _emit_clocked_process(self, node: Always) -> None:
        """Emit a clocked process, detecting reset from the first If node."""
        # Build sensitivity list
        sens_sigs = [sig.name for _, sig in node.sensitivity if sig is not None]
        sens_str = ", ".join(sens_sigs)

        # Find the outermost If (reset check) if present
        first_if: Optional[If] = None
        for stmt in node.body:
            if isinstance(stmt, If):
                first_if = stmt
                break

        label = self._process_label(node)
        self._line(f"{label} : process({sens_str})")
        self._line("begin")
        self._indent()

        if first_if is not None and self._looks_like_reset(first_if.condition):
            # Async reset: emit as if/elsif rising_edge
            rst_cond = self._vhdl_reset_condition(str(first_if.condition))
            clk_sig = next(
                (sig for e, sig in node.sensitivity if e == Edge.POSEDGE),
                None,
            )
            self._line(f"if {rst_cond} then")
            self._indent()
            for stmt in first_if.then_body:
                self.visit(stmt)
            self._dedent()
            if clk_sig:
                self._line(f"elsif rising_edge({clk_sig.name}) then")
            else:
                self._line("else")
            self._indent()
            for stmt in first_if.else_body:
                self.visit(stmt)
            self._dedent()
            self._line("end if;")
            # Emit remaining statements after the if
            for stmt in node.body:
                if stmt is not first_if:
                    self.visit(stmt)
        else:
            # Synchronous reset or no reset: wrap in rising_edge
            clk_sig = next(
                (sig for e, sig in node.sensitivity if e == Edge.POSEDGE),
                None,
            )
            clk_name = clk_sig.name if clk_sig else "clk"
            self._line(f"if rising_edge({clk_name}) then")
            self._indent()
            for stmt in node.body:
                self.visit(stmt)
            self._dedent()
            self._line("end if;")

        self._dedent()
        self._line(f"end process {label};")

    def _emit_comb_process(self, node: Always) -> None:
        label = self._process_label(node)
        self._line(f"{label} : process(all)")
        self._line("begin")
        self._indent()
        for stmt in node.body:
            self.visit(stmt)
        self._dedent()
        self._line(f"end process {label};")

    _proc_counter: int = 0

    def _process_label(self, node: Always) -> str:
        """Generate a unique process label."""
        # Use a simple counter stored on the instance
        if not hasattr(self, "_proc_idx"):
            self._proc_idx = 0
        self._proc_idx += 1
        has_edge = any(e in (Edge.POSEDGE, Edge.NEGEDGE) for e, _ in node.sensitivity)
        kind = "clk" if has_edge else "comb"
        return f"proc_{kind}_{self._proc_idx}"

    def _looks_like_reset(self, condition: object) -> bool:
        """Heuristic: does this condition look like a reset check?"""
        s = str(condition)
        return "!" in s or "rst" in s.lower() or "reset" in s.lower()

    def _vhdl_reset_condition(self, sv_cond: str) -> str:
        """Convert an SV reset condition to VHDL."""
        # "!rst_n" → "rst_n = '0'"
        m = re.match(r"^!\s*(\w+)$", sv_cond.strip())
        if m:
            return f"{m.group(1)} = '0'"
        # "rst" → "rst = '1'"
        m = re.match(r"^(\w+)$", sv_cond.strip())
        if m:
            return f"{m.group(1)} = '1'"
        return sv_cond  # fallback: emit as-is

    # ------------------------------------------------------------------
    # NonBlockingAssign → signal assignment
    # ------------------------------------------------------------------

    def visit_NonBlockingAssign(self, node: NonBlockingAssign) -> None:
        """Emit a signal assignment inside a process."""
        target = self._render_expr(node.target)
        source = self._render_vhdl_expr(node.source, _target_width(node.target))
        self._line(f"{target} <= {source};")

    # ------------------------------------------------------------------
    # If
    # ------------------------------------------------------------------

    def visit_If(self, node: If) -> None:
        """Emit an if/elsif/else chain."""
        cond = self._render_condition(node.condition)
        self._line(f"if {cond} then")
        self._indent()
        for stmt in node.then_body:
            self.visit(stmt)
        self._dedent()
        if node.else_body:
            self._line("else")
            self._indent()
            for stmt in node.else_body:
                self.visit(stmt)
            self._dedent()
        self._line("end if;")

    # ------------------------------------------------------------------
    # Case
    # ------------------------------------------------------------------

    def visit_Case(self, node: Case) -> None:
        """Emit a case statement."""
        selector = self._render_expr(node.selector)
        # Determine selector bit-width for zero-padding branch values
        sel_width = _target_width(node.selector)
        self._line(f"case {selector} is")
        self._indent()
        for value, body in node.branches:
            if value is None:
                self._line("when others =>")
            else:
                self._line(f'when "{value:0{sel_width}b}" =>')
            self._indent()
            for stmt in body:
                self.visit(stmt)
            self._dedent()
        self._dedent()
        self._line("end case;")

    # ------------------------------------------------------------------
    # VHDL expression rendering
    # ------------------------------------------------------------------

    def _render_condition(self, expr: object) -> str:
        """Render a condition for VHDL if-statement.

        Translates Verilog-style operators to VHDL equivalents:
        - ``!foo`` → ``not foo``
        - ``a & b`` → ``a = '1' and b = '1'``
        - ``a | b`` → ``a = '1' or b = '1'``
        """
        from hdl_ast import Signal

        if isinstance(expr, Signal):
            return f"{expr.name} = '1'"
        if isinstance(expr, str):
            s = expr.strip()
            # Negation: !foo → not foo
            if s.startswith("!"):
                inner = s[1:].strip()
                return f"{inner} = '0'"
            # Bitwise AND as boolean: a & b
            if " & " in s:
                parts = [p.strip() for p in s.split(" & ")]
                clauses = [f"{p} = '1'" for p in parts]
                return " and ".join(clauses)
            # Bitwise OR as boolean: a | b
            if " | " in s:
                parts = [p.strip() for p in s.split(" | ")]
                clauses = [f"{p} = '1'" for p in parts]
                return " or ".join(clauses)
            return s
        return self._render_expr(expr)

    def _render_vhdl_expr(self, expr: object, target_width: int = 1) -> str:
        """Render an expression with VHDL-specific literal formatting."""

        if isinstance(expr, int):
            if target_width == 1:
                return f"'{expr}'"
            return f'"{expr:0{target_width}b}"' if expr != 0 else "(others => '0')"
        if isinstance(expr, str):
            # Binary bit-string literals (e.g. "00", "1010") → VHDL "00"
            s = expr.strip()
            if s and all(c in "01" for c in s):
                if len(s) == 1:
                    return f"'{s}'"
                return f'"{s}"'
            return s
        if isinstance(expr, Concat):
            raw = expr.parts
            if len(raw) == 1 and isinstance(raw[0], (list, tuple)):
                raw = raw[0]
            parts = " & ".join(self._render_vhdl_expr(s) for s in raw)
            return parts
        if isinstance(expr, Ternary):
            cond = self._render_condition(expr.condition)
            t = self._render_vhdl_expr(expr.true_val)
            f_ = self._render_vhdl_expr(expr.false_val)
            return f"{t} when {cond} else {f_}"
        # Delegate to base for Signal, Slice
        return self._render_expr(expr)

    def _render_expr(self, expr: object) -> str:
        """Override base _render_expr for VHDL-specific syntax.

        VHDL differences from Verilog (base class):
        - Slice: ``sig(H downto L)`` instead of ``sig[H:L]``
        - Single-bit index: ``sig(i)`` instead of ``sig[i]``
        - Concat: handled by _render_vhdl_expr
        - Ternary: handled by _render_vhdl_expr
        """
        from hdl_ast import Signal

        if isinstance(expr, Slice):
            if expr.msb == expr.lsb:
                return f"{expr.signal.name}({expr.msb})"
            return f"{expr.signal.name}({expr.msb} downto {expr.lsb})"
        if isinstance(expr, Concat):
            return self._render_vhdl_expr(expr)
        if isinstance(expr, Ternary):
            return self._render_vhdl_expr(expr)
        if isinstance(expr, Signal):
            return expr.name
        if isinstance(expr, int):
            return str(expr)
        return str(expr)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _target_width(target: object) -> int:
    """Return the bit-width of an assignment target."""
    from hdl_ast import Signal

    if isinstance(target, Signal):
        return target.width
    if isinstance(target, Slice):
        return abs(target.msb - target.lsb) + 1
    return 1


__all__ = ["VHDLEmitter"]
