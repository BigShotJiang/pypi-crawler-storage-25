// SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
// SPDX-License-Identifier: MIT

// ====================================================================
// Auto-generated SystemVerilog — DO NOT EDIT
// Generated: 2026-02-20 03:14:38 UTC
// Parameters:
//   Base Address: 0
//   Data Width: 32
//   Protocol: avalon
// ====================================================================

module my_avalon_axi4_bridge (
    // Inputs
    input  logic        clk,
    input  logic        rst_n,
    input  logic [31:0] s_avl_address,
    input  logic        s_avl_read,
    input  logic        s_avl_write,
    input  logic [31:0] s_avl_writedata,
    input  logic [3:0] s_avl_byteenable,
    input  logic        m_axi_awready,
    input  logic        m_axi_wready,
    input  logic [3:0] m_axi_bid,
    input  logic [1:0] m_axi_bresp,
    input  logic        m_axi_bvalid,
    input  logic        m_axi_arready,
    input  logic [3:0] m_axi_rid,
    input  logic [31:0] m_axi_rdata,
    input  logic [1:0] m_axi_rresp,
    input  logic        m_axi_rlast,
    input  logic        m_axi_rvalid,

    // Outputs
    output logic [31:0] s_avl_readdata,
    output logic        s_avl_readdatavalid,
    output logic        s_avl_waitrequest,
    output logic [1:0] s_avl_response,
    output logic [3:0] m_axi_awid,
    output logic [33:0] m_axi_awaddr,
    output logic [7:0] m_axi_awlen,
    output logic [2:0] m_axi_awsize,
    output logic [1:0] m_axi_awburst,
    output logic [2:0] m_axi_awprot,
    output logic [3:0] m_axi_awcache,
    output logic [3:0] m_axi_awqos,
    output logic        m_axi_awvalid,
    output logic [31:0] m_axi_wdata,
    output logic [3:0] m_axi_wstrb,
    output logic        m_axi_wlast,
    output logic        m_axi_wvalid,
    output logic        m_axi_bready,
    output logic [3:0] m_axi_arid,
    output logic [33:0] m_axi_araddr,
    output logic [7:0] m_axi_arlen,
    output logic [2:0] m_axi_arsize,
    output logic [1:0] m_axi_arburst,
    output logic [2:0] m_axi_arprot,
    output logic [3:0] m_axi_arcache,
    output logic [3:0] m_axi_arqos,
    output logic        m_axi_arvalid,
    output logic        m_axi_rready
);

    // Enums
    typedef enum logic [2:0] {
        IDLE = 3'd0,
        AVL_LATCH = 3'd1,
        AXI_WR_ADDR = 3'd2,
        AXI_WR_DATA = 3'd3,
        AXI_WR_RESP = 3'd4,
        AXI_RD_ADDR = 3'd5,
        AXI_RD_RESP = 3'd6,
        AVL_RD_DONE = 3'd7
    } ReverseBridgeState_t;

    // Internal signals
    ReverseBridgeState_t state;
    logic [33:0] addr_reg;
    logic [31:0] wdata_reg;
    logic [3:0] wstrb_reg;
    logic [31:0] rdata_reg;
    logic [1:0] resp_reg;
    logic is_write_reg;

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state <= IDLE;
            addr_reg <= 0;
            wdata_reg <= 0;
            wstrb_reg <= 0;
            rdata_reg <= 0;
            resp_reg <= 0;
            is_write_reg <= 0;
            m_axi_awvalid <= 0;
            m_axi_awaddr <= 0;
            m_axi_awid <= 0;
            m_axi_awlen <= 0;
            m_axi_awsize <= 0;
            m_axi_awburst <= 0;
            m_axi_awprot <= 0;
            m_axi_awcache <= 0;
            m_axi_awqos <= 0;
            m_axi_wvalid <= 0;
            m_axi_wdata <= 0;
            m_axi_wstrb <= 0;
            m_axi_wlast <= 0;
            m_axi_bready <= 0;
            m_axi_arvalid <= 0;
            m_axi_araddr <= 0;
            m_axi_arid <= 0;
            m_axi_arlen <= 0;
            m_axi_arsize <= 0;
            m_axi_arburst <= 0;
            m_axi_arprot <= 0;
            m_axi_arcache <= 0;
            m_axi_arqos <= 0;
            m_axi_rready <= 0;
            s_avl_waitrequest <= 1;
            s_avl_readdata <= 0;
            s_avl_readdatavalid <= 0;
            s_avl_response <= 0;
        end else begin
            case (state)
                IDLE: begin
                    s_avl_waitrequest <= 1;
                    s_avl_readdatavalid <= 0;
                    m_axi_awvalid <= 0;
                    m_axi_wvalid <= 0;
                    m_axi_bready <= 0;
                    m_axi_arvalid <= 0;
                    m_axi_rready <= 0;
                    if (s_avl_write) begin
                        addr_reg <= {s_avl_address[31:0], 00};
                        wdata_reg <= s_avl_writedata;
                        wstrb_reg <= s_avl_byteenable;
                        is_write_reg <= 1;
                        state <= AVL_LATCH;
                    end else begin
                        if (s_avl_read) begin
                            addr_reg <= {s_avl_address[31:0], 00};
                            is_write_reg <= 0;
                            state <= AVL_LATCH;
                        end
                    end
                end
                AVL_LATCH: begin
                    s_avl_waitrequest <= 0;
                    if (is_write_reg) begin
                        state <= AXI_WR_ADDR;
                    end else begin
                        state <= AXI_RD_ADDR;
                    end
                end
                AXI_WR_ADDR: begin
                    s_avl_waitrequest <= 1;
                    m_axi_awvalid <= 1;
                    m_axi_awaddr <= addr_reg;
                    m_axi_awid <= 0;
                    m_axi_awlen <= 0;
                    m_axi_awsize <= 2;
                    m_axi_awburst <= 1;
                    m_axi_awprot <= 0;
                    m_axi_awcache <= 0;
                    m_axi_awqos <= 0;
                    if (m_axi_awready) begin
                        state <= AXI_WR_DATA;
                    end
                end
                AXI_WR_DATA: begin
                    m_axi_awvalid <= 0;
                    m_axi_wvalid <= 1;
                    m_axi_wdata <= wdata_reg;
                    m_axi_wstrb <= wstrb_reg;
                    m_axi_wlast <= 1;
                    if (m_axi_wready) begin
                        state <= AXI_WR_RESP;
                    end
                end
                AXI_WR_RESP: begin
                    m_axi_wvalid <= 0;
                    m_axi_wlast <= 0;
                    m_axi_bready <= 1;
                    if (m_axi_bvalid) begin
                        resp_reg <= m_axi_bresp;
                        s_avl_response <= m_axi_bresp;
                        state <= IDLE;
                    end
                end
                AXI_RD_ADDR: begin
                    s_avl_waitrequest <= 1;
                    m_axi_arvalid <= 1;
                    m_axi_araddr <= addr_reg;
                    m_axi_arid <= 0;
                    m_axi_arlen <= 0;
                    m_axi_arsize <= 2;
                    m_axi_arburst <= 1;
                    m_axi_arprot <= 0;
                    m_axi_arcache <= 0;
                    m_axi_arqos <= 0;
                    if (m_axi_arready) begin
                        state <= AXI_RD_RESP;
                    end
                end
                AXI_RD_RESP: begin
                    m_axi_arvalid <= 0;
                    m_axi_rready <= 1;
                    if (m_axi_rvalid) begin
                        rdata_reg <= m_axi_rdata;
                        resp_reg <= m_axi_rresp;
                        state <= AVL_RD_DONE;
                    end
                end
                AVL_RD_DONE: begin
                    m_axi_rready <= 0;
                    s_avl_readdatavalid <= 1;
                    s_avl_readdata <= rdata_reg;
                    s_avl_response <= resp_reg;
                    state <= IDLE;
                end
                default: begin
                    state <= IDLE;
                end
            endcase
        end
    end

endmodule
