#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
Generate Python UIO driver classes from memory map.
Zero dependencies on SDK at runtime.
"""

import argparse
import os

import yaml
from memory_map_parser import MemoryMapParser

CLASS_TEMPLATE = r"""import os
import mmap
import struct

class {class_name}UIO:
    '''
    UIO Driver for {name}
    Base: {base}
    Span: {span}
    '''
    def __init__(self, uio_num=None):
        self.uio_num = uio_num if uio_num is not None else self._find_uio_num()
        self.dev_path = f"/dev/uio{{{{self.uio_num}}}}"
        self.fd = os.open(self.dev_path, os.O_RDWR | os.O_SYNC)
        self.mem = mmap.mmap(self.fd, {span_int}, mmap.MAP_SHARED, mmap.PROT_READ | mmap.PROT_WRITE)

        self.REGMAP = {regmap}

    def _find_uio_num(self):
        # In a real system, we'd scan /sys/class/uio/uioX/name
        # For now, default to 0 or allow override
        return 0

    def read(self, reg_name):
        if reg_name not in self.REGMAP:
            raise KeyError(f"Register {{reg_name}} not found")
        offset = self.REGMAP[reg_name]['offset']
        self.mem.seek(offset)
        return struct.unpack("<I", self.mem.read(4))[0]

    def write(self, reg_name, value):
        if reg_name not in self.REGMAP:
            raise KeyError(f"Register {{reg_name}} not found")
        if self.REGMAP[reg_name].get('access') == 'RO':
            raise PermissionError(f"Register {{reg_name}} is Read-Only")
        offset = self.REGMAP[reg_name]['offset']
        self.mem.seek(offset)
        self.mem.write(struct.pack("<I", value))

    def read_field(self, reg_name, field_name):
        reg_val = self.read(reg_name)
        fields = self.REGMAP[reg_name].get('fields', {{}})
        if field_name not in fields:
            raise KeyError(f"Field {{field_name}} not found in register {{reg_name}}")
        mask = fields[field_name]['mask']
        shift = fields[field_name]['shift']
        return (reg_val & mask) >> shift

    def write_field(self, reg_name, field_name, value):
        if self.REGMAP[reg_name].get('access') == 'RO':
            raise PermissionError(f"Register {{reg_name}} is Read-Only")
        fields = self.REGMAP[reg_name].get('fields', {{}})
        if field_name not in fields:
            raise KeyError(f"Field {{field_name}} not found in register {{reg_name}}")

        mask = fields[field_name]['mask']
        shift = fields[field_name]['shift']

        # Read-Modify-Write
        reg_val = self.read(reg_name)
        reg_val &= ~mask
        reg_val |= (value << shift) & mask
        self.write(reg_name, reg_val)

    def close(self):
        self.mem.close()
        os.close(self.fd)
"""


def generate_python(dev, regbank_data, output_dir):
    """Generate a Python UIO binding module from register definitions."""
    name = dev["name"]
    class_name = "".join(x.capitalize() for x in name.split("_"))

    regmap = {}
    if regbank_data and "registers" in regbank_data:
        for reg in regbank_data["registers"]:
            reg_dict = {"offset": reg["address"] * 4, "access": reg.get("access", "RW"), "fields": {}}
            if "fields" in reg:
                for field in reg["fields"]:
                    width = field["width"]
                    lsb = field["lsb"]
                    mask = ((1 << width) - 1) << lsb
                    reg_dict["fields"][field["name"]] = {"mask": mask, "shift": lsb}
            regmap[reg["name"]] = reg_dict

    file_path = os.path.join(output_dir, f"{name}_uio.py")

    with open(file_path, "w") as f:
        f.write(
            CLASS_TEMPLATE.format(
                class_name=class_name,
                name=name,
                base=hex(dev["base_addr"]),
                span=hex(dev["span"]),
                span_int=dev["span"],
                regmap=regmap,
            )
        )


def main():
    """CLI entry point for UIO binding generator."""
    parser = argparse.ArgumentParser(description="Generate Python UIO drivers from memory map")
    parser.add_argument("input", help="Path to system_memory_map.yml")
    parser.add_argument("-o", "--output-dir", help="Output directory", default="linux/python")
    args = parser.parse_args()

    os.makedirs(args.output_dir, exist_ok=True)
    mmap = MemoryMapParser(args.input)

    base_dir = os.path.dirname(os.path.abspath(args.input))

    for dev in mmap.get_uio_devices():
        regbank_data = None
        if "regbank_ref" in dev:
            regbank_path = os.path.join(base_dir, dev["regbank_ref"])
            if os.path.exists(regbank_path):
                with open(regbank_path, "r") as f:
                    regbank_data = yaml.safe_load(f)

        generate_python(dev, regbank_data, args.output_dir)
        print(f"Generated {dev['name']}_uio.py in {args.output_dir}")


if __name__ == "__main__":
    main()
