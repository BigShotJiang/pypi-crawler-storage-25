#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Resolve the system memory map path from project configuration.

Reads ``memory_map`` from the resolved project config (chasing target
pointers).  Prints the absolute path to stdout.  Exits silently on any
error so the Makefile fallback (``$(ROOT_DIR)/system_memory_map.yml``)
takes over.
"""

import os
import sys

# SDK root is four levels up: generators/linux/ -> generators/ -> sdk/ -> repo root
_SDK_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
if _SDK_ROOT not in sys.path:
    sys.path.insert(0, _SDK_ROOT)

try:
    from cli.project_config import load_project_config

    config = load_project_config()
    mmap_rel = config.get("memory_map")
    if mmap_rel:
        print(os.path.abspath(mmap_rel))
except (FileNotFoundError, ImportError, KeyError, TypeError, AttributeError, OSError):
    pass
