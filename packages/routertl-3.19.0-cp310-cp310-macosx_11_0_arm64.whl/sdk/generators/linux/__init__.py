# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Linux codegen package.

Exposes :func:`run_all_generators` — a tiny compose helper that invokes
the three standalone generator scripts (DTS overlay, C UIO header,
Python UIO bindings) via subprocess and returns the list of emitted
file paths.  Used by the ``rr linux sync`` command (RTL-P2.432) to
compose crosscheck + gen + petalinux-spec dropoff into one step.

The generators themselves stay as standalone scripts — they import
``memory_map_parser`` via bare name, which only resolves when invoked
with their own directory on ``sys.path`` (as the Makefile already does).
Keeping the subprocess boundary preserves that contract.
"""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path

import yaml

_GEN_DIR = Path(__file__).parent.resolve()


def _parse_yaml_devices(yaml_path: Path) -> list[dict]:
    """Return the devices list from a system_memory_map.yml.

    Kept deliberately lightweight — we only need device names to predict
    per-device output filenames.  Full schema validation happens inside
    the generator subprocess via MemoryMapParser.
    """
    with open(yaml_path) as f:
        data = yaml.safe_load(f) or {}
    devs = data.get("devices") or []
    return [d for d in devs if d.get("uio", True)]


def run_all_generators(
    yaml_path: Path,
    out_dir: Path,
    *,
    project_name: str = "project",
) -> dict[str, list[Path]]:
    """Run the three Linux codegens and return emitted file paths.

    Parameters
    ----------
    yaml_path
        Path to ``system_memory_map.yml``.
    out_dir
        Base output directory.  The three generators write to
        ``{out_dir}/dtbo/``, ``{out_dir}/include/``, ``{out_dir}/python/``.
    project_name
        Used to name the DTS overlay (``{project_name}_overlay.dts``).

    Returns
    -------
    dict
        ``{"dts": [...], "headers": [...], "python": [...]}``.  Paths
        are computed from the YAML device list + known generator
        naming conventions.

    Raises
    ------
    subprocess.CalledProcessError
        If any generator exits non-zero.
    """
    yaml_path = Path(yaml_path).resolve()
    out_dir = Path(out_dir).resolve()

    dtbo_dir = out_dir / "dtbo"
    include_dir = out_dir / "include"
    python_dir = out_dir / "python"
    for d in (dtbo_dir, include_dir, python_dir):
        d.mkdir(parents=True, exist_ok=True)

    dts_path = dtbo_dir / f"{project_name}_overlay.dts"

    subprocess.run(
        [sys.executable, str(_GEN_DIR / "generate_dtbo.py"),
         str(yaml_path), "-o", str(dts_path)],
        check=True,
    )
    subprocess.run(
        [sys.executable, str(_GEN_DIR / "generate_uio_header.py"),
         str(yaml_path), "-o", str(include_dir)],
        check=True,
    )
    subprocess.run(
        [sys.executable, str(_GEN_DIR / "generate_uio_bindings.py"),
         str(yaml_path), "-o", str(python_dir)],
        check=True,
    )

    devices = _parse_yaml_devices(yaml_path)
    header_paths = [include_dir / f"{d['name']}_uio.h" for d in devices]
    python_paths = [python_dir / f"{d['name']}_uio.py" for d in devices]
    return {"dts": [dts_path], "headers": header_paths, "python": python_paths}


__all__ = ["run_all_generators"]
