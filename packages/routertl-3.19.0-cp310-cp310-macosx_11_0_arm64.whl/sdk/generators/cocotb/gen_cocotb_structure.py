#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

import argparse
import logging
import os
import re
from collections import defaultdict
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple

SRC_DIR_DEFAULT = "src"
TEST_ROOT_DEFAULT = "sim/cocotb/tests"
EXCLUDE_PATTERNS = ["_pkg.vhd", "_pkg.sv", "wrapper_", "top.vhd", "top.sv"]


# --- GENERIC PARSER ---


def parse_generics(vhdl_path: Path) -> Tuple[Optional[str], List[Dict[str, str]]]:
    """Parse VHDL generics from entity declarations."""
    text = vhdl_path.read_text()
    # RTL-P2.403: strip -- line comments and non-ASCII characters before regex.
    # Without this, a leading comment line gets merged with the next generic
    # after split-on-';' and the whole generic is silently skipped.  Shares
    # the hygiene contract with sdk.engine.hdl_ports.
    text = re.sub(r"--[^\n]*", "", text)
    text = "".join(c if ord(c) < 128 else " " for c in text)
    entity_re = re.compile(r"(?i)entity\s+(\w+)\s+is\s+generic\s*\((.*?)\)\s*;", re.DOTALL | re.MULTILINE)
    match = entity_re.search(text)
    if not match:
        return None, []

    entity_name, generic_block = match.groups()
    generic_lines = re.split(r";\s*", generic_block.strip())
    generics = []

    generic_line_re = re.compile(r"(?P<name>\w+)\s*:\s*(?P<type>[^:=]+?)(?:\s*:=\s*(?P<default>.+))?$", re.IGNORECASE)

    for line in generic_lines:
        line = line.strip()
        if not line or line.startswith("--"):
            continue
        m = generic_line_re.match(line)
        if m:
            default_val = m.group("default").strip() if m.group("default") else "None"
            # Strip VHDL comments from default value
            if "--" in default_val:
                default_val = default_val.split("--")[0].strip()
            # Convert VHDL values to Python-compatible
            default_val = convert_vhdl_to_python(default_val)
            generics.append({"name": m.group("name"), "type": m.group("type").strip(), "default": default_val})

    return entity_name, generics


def convert_vhdl_to_python(val: str) -> str:
    """Convert VHDL default values to Python-compatible format."""
    val_upper = val.upper()
    # Boolean conversion
    if val_upper in ("TRUE", "FALSE"):
        return val_upper.capitalize()
    # String values (VHDL uses double quotes, keep them)
    if val.startswith('"') and val.endswith('"'):
        return val
    # Integer/numeric - keep as-is
    return val


# --- VERILOG/SV PARSER ---


def parse_verilog_module(sv_path: Path) -> Tuple[Optional[str], List[Dict[str, str]], List[str]]:
    """Parse a Verilog/SystemVerilog module declaration.

    Returns (module_name, parameters, port_names).
    """
    text = sv_path.read_text()
    # Strip line comments
    text_clean = re.sub(r"//.*$", "", text, flags=re.MULTILINE)
    # Strip block comments
    text_clean = re.sub(r"/\*.*?\*/", "", text_clean, flags=re.DOTALL)

    # Match module declaration
    mod_re = re.compile(
        r"module\s+(\w+)\s*"
        r"(?:#\s*\((.*?)\))?\s*"  # optional parameter block
        r"\((.*?)\)\s*;",         # port list
        re.DOTALL,
    )
    match = mod_re.search(text_clean)
    if not match:
        return None, [], []

    module_name = match.group(1)
    param_block = match.group(2) or ""
    port_block = match.group(3) or ""

    # Parse parameters
    parameters = []
    if param_block.strip():
        param_re = re.compile(r"parameter\s+(?:\w+\s+)?(\w+)\s*=\s*([^,)]+)", re.IGNORECASE)
        for m in param_re.finditer(param_block):
            name = m.group(1).strip()
            default = m.group(2).strip().rstrip(",")
            # Verilog expressions (e.g. DATA_WIDTH>8) aren't valid Python —
            # keep pure integers/strings, replace expressions with a placeholder
            try:
                int(default, 0)  # handles 0, 0x1F, 8, etc.
            except ValueError:
                if default.startswith('"') and default.endswith('"'):
                    pass  # string literal — keep as-is
                else:
                    default = "1"
            parameters.append({"name": name, "type": "integer", "default": default})

    # Parse port names
    port_names = []
    port_re = re.compile(r"(?:input|output|inout)\s+(?:wire|reg|logic)?\s*(?:\[.*?\])?\s*(\w+)", re.IGNORECASE)
    for m in port_re.finditer(port_block):
        port_names.append(m.group(1))

    return module_name, parameters, port_names


def _make_sv_entity_comment(sv_path: Path, module_name: str, parameters: list, port_names: list) -> str:
    """Generate a commented module declaration for the test file header."""
    lines = [f"# module {module_name}"]
    if parameters:
        lines.append("#   #(")
        for i, p in enumerate(parameters):
            comma = "," if i < len(parameters) - 1 else ""
            lines.append(f"#     parameter {p['name']} = {p['default']}{comma}")
        lines.append("#   )")
    lines.append("#   (")
    for i, port in enumerate(port_names):
        comma = "," if i < len(port_names) - 1 else ""
        lines.append(f"#     {port}{comma}")
    lines.append("#   );")
    return "\n".join(lines)


# --- MAIN LOGIC ---


def should_exclude(filename: str, exclude_patterns: List[str]) -> bool:
    """Return True if a file should be excluded from scanning."""
    return any(pattern in filename for pattern in exclude_patterns)


def _compute_import_path(test_filename: Path, test_root: Path) -> str:
    """Return the dotted Python import path for a generated test file.

    The cocotb runtime (``routertl_core.sim.simulation.run_simulation``)
    puts the cocotb root (the parent of ``test_root``, typically
    ``sim/cocotb/``) on ``sys.path``.  A test at
    ``sim/cocotb/tests/units/test_foo.py`` therefore imports as
    ``tests.units.test_foo`` — and this helper computes exactly that,
    regardless of how deep under ``test_root`` the generated file lands.

    Guards RTL-P2.341 — previously the templates hard-coded the
    ``tests.units.`` prefix, which only matched sources under
    ``src/units/``.  Everything else landed at ``tests/test_foo.py`` and
    the generated ``module="tests.units.test_foo"`` string pointed at a
    directory that never existed.
    """
    cocotb_root = test_root.parent
    rel = test_filename.relative_to(cocotb_root)
    return ".".join(rel.with_suffix("").parts)


def generate_test_skeletons(
    src_dir: Path, base_path: Path, test_root: Path, exclude_patterns: List[str],
    dry_run: bool = False, module_filter: str | None = None,
) -> List[Path]:
    """Generate cocotb test skeleton files for discovered entities.

    If module_filter is set, only generate for that specific module.
    """
    created_files = []

    # Build the entity map once
    entity_map = build_entity_map(src_dir)
    package_map = build_package_map(src_dir)

    for vhd_path in src_dir.rglob("*.vhd"):
        if should_exclude(vhd_path.name, exclude_patterns):
            logging.debug(f"Skipping excluded file: {vhd_path}")
            continue

        rel_path = vhd_path.relative_to(src_dir)
        module_name = vhd_path.stem

        if module_filter and module_name.lower() != module_filter.lower():
            continue
        test_subdir = test_root / rel_path.parent
        test_filename = test_subdir / f"test_{module_name}.py"

        if test_filename.exists():
            logging.debug(f"Test already exists: {test_filename}")
            continue

        # Parse generics from the file
        entity_name, generics = parse_generics(vhd_path)
        if entity_name and entity_name.lower() != module_name.lower():
            logging.warning(f"Entity name '{entity_name}' does not match file name '{module_name}'")

        if generics:
            logging.debug(
                f"Parsed generics for {module_name}: " + ", ".join(f"{g['name']}={g['default']}" for g in generics)
            )
        else:
            logging.debug(f"No generics found for {module_name}")

        if generics:
            template_text = load_template("with_generics.py.j2")
        else:
            template_text = load_template("no_generics.py.j2")

        # Always define these so .format() doesn't crash
        param_names = ", ".join(g["name"] for g in generics) if generics else ""
        param_values = ", ".join(g["default"] for g in generics) if generics else ""
        param_dict = ", ".join(f'"{g["name"]}": {g["name"]}' for g in generics) if generics else ""

        # Resolve full dependencies using entity name
        full_deps = resolve_all_dependencies(module_name, entity_map, package_map)
        if not full_deps:
            logging.warning(f"Skipping {module_name}: no dependencies found")
            continue

        logging.debug(f"All dependencies for {module_name}: {[p.name for p in full_deps]}")

        entity_lib_map = build_entity_library_map(src_dir)
        libraries_dict = defaultdict(list)

        for path in reversed(full_deps):
            ent_name = path.stem
            lib = entity_lib_map.get(ent_name, "work")
            libraries_dict[lib].append(path)

        # Generate the HDL source list after full_deps is populated
        hdl_sources = [p.resolve() for p in reversed(full_deps)]
        hdl_sources_rel = [str(Path(os.path.relpath(p, base_path)).as_posix()) for p in hdl_sources]

        hdl_sources_list = ",\n            ".join(f'"{p}"' for p in hdl_sources_rel)

        pretty_param_dict = ",\n            ".join(f'"{g["name"]}": {g["name"]}' for g in generics)

        # Generate param dict with actual default values (for templates that define GENERICS dict)
        param_dict_with_defaults = ",\n    ".join(f'"{g["name"]}": {g["default"]}' for g in generics)

        libraries_block = ",\n            ".join(
            f'"{lib}": [\n'
            + " " * 16
            + (",\n" + " " * 16).join(
                f'"{Path(os.path.relpath(p, base_path)).as_posix()}"' for p in paths
            )
            + "\n            ]"
            for lib, paths in libraries_dict.items()
        )

        # Extract and comment entity block for the current module
        entity_block = extract_entity_block(vhd_path, module_name)
        entity_comment = make_entity_comment(entity_block, module_name, vhd_path)

        module_import_path = _compute_import_path(test_filename, test_root)

        template = template_text.format(
            module_name=module_name,
            module_import_path=module_import_path,
            rtl_path_posix=hdl_sources_rel[0],  # optional: still keep this as reference
            hdl_sources_list=hdl_sources_list,
            libraries_block=libraries_block,
            param_names=param_names,
            param_values=param_values,
            param_dict=pretty_param_dict,
            param_dict_with_defaults=param_dict_with_defaults,
            entity_comment=entity_comment,
        )

        # Log direct instantiations
        instantiated = find_instantiated_entities(vhd_path)
        for lib, ent_name in instantiated:
            logging.debug(f"Direct instantiation found in {module_name}: {lib}.{ent_name}")

        if not dry_run:
            test_subdir.mkdir(parents=True, exist_ok=True)
            with open(test_filename, "w") as f:
                f.write(template)

        created_files.append(test_filename)

    # Second pass: Verilog/SystemVerilog files
    # Build a DependencyResolver for SV dep resolution and include dirs
    try:
        from routertl_core.dependency_resolver import DependencyResolver
        sv_resolver = DependencyResolver([src_dir])
        sv_global_include_dirs = sv_resolver.get_include_dirs()
    except (ImportError, OSError, ValueError):
        sv_resolver = None
        sv_global_include_dirs = []

    for sv_path in sorted(
        list(src_dir.rglob("*.v")) + list(src_dir.rglob("*.sv"))
    ):
        if should_exclude(sv_path.name, exclude_patterns):
            logging.debug(f"Skipping excluded SV file: {sv_path}")
            continue

        module_name = sv_path.stem

        if module_filter and module_name.lower() != module_filter.lower():
            continue
        rel_path = sv_path.relative_to(src_dir)
        test_subdir = test_root / rel_path.parent
        test_filename = test_subdir / f"test_{module_name}.py"

        if test_filename.exists():
            logging.debug(f"Test already exists: {test_filename}")
            continue

        module_name_parsed, parameters, port_names = parse_verilog_module(sv_path)
        if not module_name_parsed:
            logging.warning(f"Could not parse module from {sv_path}")
            continue

        # Use parsed module name
        module_name = module_name_parsed

        if parameters:
            template_text = load_template("sv_with_generics.py.j2")
        else:
            template_text = load_template("sv_no_generics.py.j2")

        param_names = ", ".join(p["name"] for p in parameters) if parameters else ""
        param_values = ", ".join(p["default"] for p in parameters) if parameters else ""
        param_dict = ", ".join(f'"{p["name"]}": {p["name"]}' for p in parameters) if parameters else ""
        param_dict_with_defaults = ",\n    ".join(f'"{p["name"]}": {p["default"]}' for p in parameters)

        # Source path relative to project root
        src_rel = str(Path(os.path.relpath(sv_path.resolve(), base_path)).as_posix())
        entity_comment = _make_sv_entity_comment(sv_path, module_name, parameters, port_names)

        # Resolve full dependencies and include dirs via DependencyResolver
        hdl_sources_rel = [src_rel]
        include_dirs_for_module: List[str] = []
        if sv_resolver:
            try:
                dep_files = sv_resolver.get_compilation_order(module_name)
                if dep_files:
                    hdl_sources_rel = [
                        str(Path(os.path.relpath(p.resolve(), base_path)).as_posix())
                        for p in dep_files
                    ]
                include_dirs_for_module = [
                    str(Path(os.path.relpath(Path(d), base_path)).as_posix())
                    for d in sv_global_include_dirs
                ]
            except (KeyError, OSError, ValueError):
                logging.debug(f"Could not resolve deps for {module_name}, using single file")

        hdl_sources_list = ",\n            ".join(f'"{p}"' for p in hdl_sources_rel)

        # Build includes block (only if we have include dirs)
        if include_dirs_for_module:
            inc_list = ",\n            ".join(f'"{d}"' for d in include_dirs_for_module)
            includes_block = f"\n        includes=[\n            {inc_list}\n        ],"
        else:
            includes_block = ""

        # Detect clock/reset port names for the template
        clk_port = "clk"
        rst_port = "rst"
        for p in port_names:
            if p.lower() in ("clk", "clock", "clk_i"):
                clk_port = p
                break
        for p in port_names:
            if p.lower() in ("rst", "reset", "rst_i", "rst_n", "reset_n"):
                rst_port = p
                break

        template = template_text.format(
            module_name=module_name,
            rtl_path_posix=src_rel,
            hdl_sources_list=hdl_sources_list,
            includes_block=includes_block,
            param_names=param_names,
            param_values=param_values,
            param_dict=param_dict,
            param_dict_with_defaults=param_dict_with_defaults,
            entity_comment=entity_comment,
            clk_port=clk_port,
            rst_port=rst_port,
        )

        if not dry_run:
            test_subdir.mkdir(parents=True, exist_ok=True)
            with open(test_filename, "w") as f:
                f.write(template)

        created_files.append(test_filename)

    return created_files


def load_template(name: str) -> str:
    """Load a Jinja2 template from the templates directory."""
    template_dir = Path(__file__).parent / "templates"
    return (template_dir / name).read_text()


def find_instantiated_entities(vhdl_path: Path) -> List[Tuple[str, str]]:
    """Find entity names instantiated within VHDL source files."""
    text = vhdl_path.read_text()

    # Match: label : entity lib.ent
    ENTITY_INSTANCE_RE = re.compile(r"(?P<label>\w+)\s*:\s*entity\s+(?P<lib>\w+)\.(?P<ent>\w+)", re.IGNORECASE)
    entity_matches = ENTITY_INSTANCE_RE.findall(text)
    entities = {(lib, ent) for _, lib, ent in entity_matches}

    # Match: label : component ent
    COMPONENT_INSTANCE_RE = re.compile(
        r"(?P<label>\w+)\s*:\s*component\s+(?P<ent>\w+)\s*(?:generic\s+map|port\s+map)", re.IGNORECASE
    )
    component_matches = COMPONENT_INSTANCE_RE.findall(text)
    for label, ent in component_matches:
        if not any(e == ent for _, e in entities):
            logging.debug(f"Component instantiation found: {label} : component {ent}")
            entities.add(("??", ent))  # library unknown

    return list(entities)


def resolve_dependencies(entity: str, entity_map: Dict[str, Path], seen: Set[str]) -> List[Path]:
    """Build a dependency graph from entity instantiations."""
    if entity in seen:
        return []

    seen.add(entity)

    if entity not in entity_map:
        logging.warning(f"Entity {entity} not in entity map")
        return []

    vhdl_path = entity_map[entity]
    deps = find_instantiated_entities(vhdl_path)
    dep_paths = [entity_map[dep[1]] for dep in deps if dep[1] in entity_map]

    result = [vhdl_path] + sum((resolve_dependencies(dep[1], entity_map, seen) for dep in deps), [])
    return result


def build_entity_map(src_dir: Path) -> Dict[str, Path]:
    """Map entity names to their source file paths."""
    entity_map = {}
    ENTITY_DEF_RE = re.compile(r"(?i)entity\s+(\w+)\s+is")
    logging.debug(f"Building entity map from {src_dir}...")
    for vhd_path in src_dir.rglob("*.vhd"):
        text = vhd_path.read_text()
        match = ENTITY_DEF_RE.search(text)
        if match:
            entity_name = match.group(1)
            entity_map[entity_name] = vhd_path.resolve()
            logging.debug(f"Mapped entity: {entity_name} -> {vhd_path}")

    return entity_map


def build_entity_library_map(src_dir: Path) -> Dict[str, str]:
    """Map entity names to their VHDL library names."""
    entity_lib_map = {}
    ENTITY_INSTANCE_RE = re.compile(r"(?P<label>\w+)\s*:\s*entity\s+(?P<lib>\w+)\.(?P<ent>\w+)", re.IGNORECASE)

    for vhd_path in src_dir.rglob("*.vhd"):
        text = vhd_path.read_text()
        for _, lib, ent in ENTITY_INSTANCE_RE.findall(text):
            if ent not in entity_lib_map:
                entity_lib_map[ent] = lib
    return entity_lib_map


def resolve_all_dependencies(
    entity: str, entity_map: Dict[str, Path], package_map: Dict[str, Path], seen: Optional[set] = None
) -> List[Path]:
    """Recursively resolve all transitive dependencies."""
    if seen is None:
        seen = set()

    if entity in seen:
        return []

    seen.add(entity)

    if entity not in entity_map:
        logging.warning(f"Entity '{entity}' not found in map")
        return []

    vhd_path = entity_map[entity]
    deps = find_instantiated_entities(vhd_path)
    paths = [vhd_path]

    packages = find_used_packages(vhd_path)
    for pkg in packages:
        pkg_key = f"{pkg}_pkg"
        if pkg_key in package_map:
            pkg_path = package_map[pkg_key]
            if pkg_path not in paths:
                logging.debug(f"Found used package: {pkg_key} -> {pkg_path}")
                paths.append(pkg_path)
        else:
            logging.warning(f"Package {pkg_key}.vhd not found in package map")

    for lib, sub_ent in deps:
        sub_paths = resolve_all_dependencies(sub_ent, entity_map, package_map, seen)
        paths.extend(sub_paths)

    return list(dict.fromkeys(paths))  # Deduplicate, preserve order


def export_entity_graph(root_entity: str, entity_map: Dict[str, Path], output_dot: Path):
    """Export the entity dependency graph as a DOT file."""
    edges = []
    seen = set()

    def walk(ent):
        """Recursively walk and collect files matching a pattern."""
        if ent in seen or ent not in entity_map:
            return
        seen.add(ent)
        deps = find_instantiated_entities(entity_map[ent])
        logging.debug(f"{ent} instantiates: {[f'{lib}.{dep}' for lib, dep in deps]}")
        for lib, dep in deps:
            logging.debug(f"Adding edge: {ent} -> {dep}")
            edges.append((ent, dep))
            walk(dep)

    logging.debug(f"Generating graph for root: {root_entity}")
    logging.debug(f"Entity map keys: {list(entity_map.keys())}")
    walk(root_entity)

    with open(output_dot, "w") as f:
        f.write("digraph EntityHierarchy {\n")
        for src, dst in edges:
            f.write(f'  "{src}" -> "{dst}";\n')
        f.write("}\n")

    logging.info(f"Graph exported to {output_dot}")


def find_used_packages(vhdl_path: Path) -> List[str]:
    """Find VHDL packages referenced by use clauses."""
    USE_RE = re.compile(r"use\s+(?P<lib>\w+)\.(?P<pkg>\w+)_pkg\.all\s*;", re.IGNORECASE)
    text = vhdl_path.read_text()
    return [m.group("pkg") for m in USE_RE.finditer(text)]


def build_package_map(src_dir: Path) -> Dict[str, Path]:
    """Map package names to their source file paths."""
    package_map = {}
    PACKAGE_DEF_RE = re.compile(r"(?i)package\s+(\w+)\s+is")
    for vhd_path in src_dir.rglob("*_pkg.vhd"):
        text = vhd_path.read_text()
        match = PACKAGE_DEF_RE.search(text)
        if match:
            pkg_name = match.group(1)
            package_map[pkg_name] = vhd_path.resolve()
    return package_map


def extract_entity_block(vhdl_path: Path, entity_name: str) -> str:
    """
    Return the full 'entity <name> is ... end [entity] <name>;' block as a string.
    Handles variants like 'end entity;', 'end <name>;', and extra whitespace/comments.
    """
    text = vhdl_path.read_text()

    # (?is): ignore case + dot matches newlines
    name = re.escape(entity_name)
    pattern = rf"""(?is)           # flags
        \bentity\s+{name}\s+is     # entity <name> is
        (.*?)                      # body
        \bend\s+                   # end ...
        (?:entity\s+{name}\s*|     #   entity <name>
           {name}\s*|              #   <name>
           entity\s*               #   entity
        );                         # ;
    """
    m = re.search(pattern, text, re.VERBOSE)
    return m.group(0) if m else ""


def make_entity_comment(block: str, module_name: str, vhdl_path: Path) -> str:
    """
    Turn the entity block into a Python comment block to drop into the template.
    If not found, include a short note so the user knows where it came from.
    """
    if not block:
        return f"# Entity definition not found in this file.\n# File: {vhdl_path.as_posix()}\n# Entity: {module_name}\n"
    return "\n".join("# " + line.rstrip() for line in block.splitlines())


def main():
    """CLI entry point for the test structure generator."""
    parser = argparse.ArgumentParser(description="Generate cocotb test stubs from VHDL source tree.")
    parser.add_argument(
        "--src", type=str, nargs="+", default=[SRC_DIR_DEFAULT], help=f"Source root directories (default: {SRC_DIR_DEFAULT})"
    )
    parser.add_argument(
        "--out", type=str, default=TEST_ROOT_DEFAULT, help=f"Test root directory (default: {TEST_ROOT_DEFAULT})"
    )
    parser.add_argument(
        "--absolute-paths", action="store_true", help="Use absolute paths for VHDL sources (default: relative to src/)"
    )
    parser.add_argument(
        "--excludes",
        type=str,
        nargs="*",
        default=EXCLUDE_PATTERNS,
        help=f"List of filename patterns to exclude (default: {EXCLUDE_PATTERNS})",
    )
    parser.add_argument("--module", type=str, default=None, help="Generate test only for this module/entity")
    parser.add_argument("--dry-run", action="store_true", help="Only print what would be created")
    parser.add_argument("--graph", type=str, help="Export dependency graph for given entity (as DOT file)")
    parser.add_argument("--root", type=str, help="Root entity name for the graph")
    parser.add_argument("--verbose", action="store_true", help="Enable verbose debug output")

    args = parser.parse_args()
    logging.basicConfig(level=logging.DEBUG if args.verbose else logging.INFO, format="[%(levelname)s] %(message)s")

    src_paths = [Path(s) for s in args.src]
    out_path = Path(args.out)

    # Always resolve relative to CWD (project root) so that paths in
    # generated tests like "src/edge_counter.vhd" work when the sim
    # engine resolves them from the project root.
    base_path = Path.cwd().resolve()

    created = []
    for src_path in src_paths:
        logging.info(f"Scanning {src_path}...")
        created += generate_test_skeletons(
            src_path, base_path, out_path, args.excludes,
            dry_run=args.dry_run, module_filter=args.module,
        )

    if created:
        print("\n" + ("Would create:" if args.dry_run else "Created:"))
        for f in created:
            print("  -", f)
    else:
        logging.info("No test files needed to be created.")

    if args.graph and args.root:
        output_dot = Path(args.graph)
        entity_map = build_entity_map(src_paths[0])
        package_map = build_package_map(src_paths[0])

        logging.debug(f"Generating graph for root: {args.root}")
        logging.debug(f"Entity map keys: {list(entity_map.keys())}")

        export_entity_graph(args.root, entity_map, output_dot)


if __name__ == "__main__":
    main()
