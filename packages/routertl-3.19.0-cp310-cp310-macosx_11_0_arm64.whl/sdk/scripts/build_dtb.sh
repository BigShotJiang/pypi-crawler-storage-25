#!/usr/bin/env bash
# Base Device Tree Generator wrapper for XSCT & DTG
# Generates system.dtb from the .xsa using the Xilinx Device Tree compiler
set -euo pipefail

PROJECT_ROOT=${PROJECT_ROOT:-$(pwd)}
BUILD_DIR=${BUILD_DIR:-"$PROJECT_ROOT/build"}
PROJECT_NAME=${PROJECT_NAME:-$(basename "$PROJECT_ROOT")}
LINUX_SRC_DIR=${LINUX_SRC_DIR:-"$PROJECT_ROOT/linux/src"}
LINUX_OUT_DIR=${LINUX_OUT_DIR:-"$PROJECT_ROOT/linux/out"}

DTG_DEFAULT_REPO="https://github.com/Xilinx/device-tree-xlnx.git"
DTG_REPO="${DTG_REPO:-$DTG_DEFAULT_REPO}"
DTG_SRC_DIR="$LINUX_SRC_DIR/device-tree-xlnx"

HW_PATH="$BUILD_DIR/${PROJECT_NAME}.xsa"

echo "========================================"
echo "Generating Base Device Tree (system.dtb)"
echo "========================================"

if [ ! -f "$HW_PATH" ]; then
    echo "❌ Error: XSA hardware definition not found!"
    echo "Expected path: $HW_PATH"
    echo "Did you run 'make build-bitstream' first?"
    exit 1
fi

mkdir -p "$LINUX_SRC_DIR"
mkdir -p "$LINUX_OUT_DIR"

if [ ! -d "$DTG_SRC_DIR" ]; then
    echo "Cloning Xilinx Device Tree Generator (DTG)..."
    git clone --depth 1 "$DTG_REPO" "$DTG_SRC_DIR"
fi

DT_OUT="$BUILD_DIR/device_tree_workspace"
rm -rf "$DT_OUT"
mkdir -p "$DT_OUT"

# Generate temporary TCL script for XSCT
XSCT_TCL="$BUILD_DIR/gen_dtb.tcl"

cat << EOF > "$XSCT_TCL"
# Auto-generated XSCT script to extract Device Tree
hsi open_hw_design "$HW_PATH"
hsi set_repo_path "$DTG_SRC_DIR"
hsi create_sw_design device-tree -os device_tree -proc ps7_cortexa9_0
hsi generate_target -dir "$DT_OUT"
hsi close_hw_design [hsi current_hw_design]
EOF

echo "Launching Xilinx XSCT (Vitis command-line) to generate DTS payload..."
# Check if xsct is available in PATH
if ! command -v xsct &> /dev/null; then
    echo "❌ Error: 'xsct' command not found."
    echo "You must run this in a terminal where Vitis is sourced (e.g., settings64.sh)"
    exit 1
fi

xsct "$XSCT_TCL"

# Check if dtc is installed
if ! command -v dtc &> /dev/null; then
    echo "❌ Error: Device Tree Compiler (dtc) not found."
    echo "Please install it (e.g., sudo apt install device-tree-compiler)"
    exit 1
fi

echo "Compiling DTS to DTB using GCC pre-processor..."
cd "$DT_OUT"
# Must preprocess with GCC first to resolve #include headers inside the Xilinx DTS files
gcc -I my_dts -E -nostdinc -undef -D__DTS__ -x assembler-with-cpp -o system.dts.tmp system-top.dts
dtc -I dts -O dtb -o "$LINUX_OUT_DIR/system.dtb" system.dts.tmp

echo "✅ DTB Generation Complete: $LINUX_OUT_DIR/system.dtb"
