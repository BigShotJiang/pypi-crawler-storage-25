#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Generate routertl-ip-index entries from SDK bundled units.

Scans ``src/units/`` for VHDL and Verilog modules, parses entity/module
metadata using the existing SDK parsers, and outputs:

  - ``catalog.json`` — master index for ``rr pkg search``
  - ``packages/routertl/<name>/<version>.yml`` — per-unit metadata

Output is written to a specified directory (default: ``/tmp/routertl-ip-index``),
ready to commit to the routertl-ip-index repository.

Usage:
    python sdk/scripts/generate_index_entries.py [--output /path/to/index]
"""

import argparse
import json
import re
import sys
from pathlib import Path

# Resolve SDK root for imports
SCRIPT_DIR = Path(__file__).resolve().parent
SDK_ROOT = SCRIPT_DIR.parent.parent
sys.path.insert(0, str(SDK_ROOT))

# ── VHDL parser (reuse from gen_cocotb_structure) ────────────────────────────

ENTITY_RE = re.compile(
    r"entity\s+(\w+)\s+is", re.IGNORECASE
)
GENERIC_RE = re.compile(
    r"(\w+)\s*:\s*([\w\s()]+?)(?:\s*:=\s*([^;]+))?\s*[;)]",
    re.IGNORECASE,
)
PORT_RE = re.compile(
    r"(\w+)\s*:\s*(in|out|inout)\s+(\w[\w\s()_\-]*?)(?:\s*:=\s*[^;]+)?\s*[;)]",
    re.IGNORECASE,
)


def parse_vhdl_entity(path: Path) -> dict | None:
    """Parse a VHDL file for entity name, generics, and ports."""
    text = path.read_text(errors="replace")

    m = ENTITY_RE.search(text)
    if not m:
        return None

    entity_name = m.group(1)

    # Extract generic block
    generics = []
    gen_match = re.search(
        r"generic\s*\((.*?)\)\s*;", text, re.IGNORECASE | re.DOTALL
    )
    if gen_match:
        gen_block = gen_match.group(1)
        for gm in GENERIC_RE.finditer(gen_block):
            generics.append({
                "name": gm.group(1).strip(),
                "type": gm.group(2).strip(),
                "default": gm.group(3).strip() if gm.group(3) else "",
            })

    # Extract port names
    ports = []
    port_match = re.search(
        r"port\s*\((.*?)\)\s*;", text, re.IGNORECASE | re.DOTALL
    )
    if port_match:
        port_block = port_match.group(1)
        for pm in PORT_RE.finditer(port_block):
            ports.append(pm.group(1).strip())

    return {
        "entity": entity_name,
        "generics": generics,
        "ports": ports,
    }


# ── Verilog parser ───────────────────────────────────────────────────────────

MODULE_RE = re.compile(r"module\s+(\w+)", re.MULTILINE)
PARAM_RE = re.compile(
    r"parameter\s+(?:\w+\s+)?(\w+)\s*=\s*([^,\)]+)",
    re.IGNORECASE,
)


def parse_verilog_module(path: Path) -> dict | None:
    """Parse a Verilog file for module name and parameters."""
    text = path.read_text(errors="replace")

    m = MODULE_RE.search(text)
    if not m:
        return None

    module_name = m.group(1)

    params = []
    for pm in PARAM_RE.finditer(text):
        params.append({
            "name": pm.group(1).strip(),
            "type": "integer",
            "default": pm.group(2).strip(),
        })

    return {
        "entity": module_name,
        "generics": params,
        "ports": [],
    }


# ── Index entry generation ───────────────────────────────────────────────────


def detect_dependencies(path: Path) -> list[str]:
    """Detect XPM or unisim dependencies from VHDL library/use clauses."""
    text = path.read_text(errors="replace").lower()
    deps = []
    if "library xpm" in text or "use xpm." in text:
        deps.append("xilinx-xpm")
    if "library unisim" in text or "use unisim." in text:
        deps.append("xilinx-unisim")
    return deps


def generate_entry(path: Path, version: str) -> dict | None:
    """Generate an ip.yml-compatible entry for a single HDL file."""
    suffix = path.suffix.lower()

    if suffix in (".vhd", ".vhdl"):
        parsed = parse_vhdl_entity(path)
        language = "vhdl-2008"
    elif suffix in (".v", ".sv"):
        parsed = parse_verilog_module(path)
        language = "systemverilog" if suffix == ".sv" else "verilog"
    else:
        return None

    if not parsed:
        return None

    deps = detect_dependencies(path)

    return {
        "name": parsed["entity"],
        "namespace": "routertl",
        "version": version,
        "description": f"RouteRTL SDK unit: {parsed['entity']}",
        "license": "MIT",
        "routertl_compat": {
            "language": language,
            "library": "",
            "files": [path.name],
        },
        "parameters": [
            {"name": g["name"], "type": g["type"], "default": g["default"]}
            for g in parsed["generics"]
        ],
        "interfaces": [],
        "fpga": {
            "vendors": ["xilinx"] if deps else [],
            "resources": {"bram": False, "dsp": False, "pll": False},
        },
        "dependencies": {d: "local" for d in deps},
        "source": {
            "url": "https://github.com/djmazure/routertl.git",
            "path": f"src/units/{path.name}",
        },
    }


def main():
    parser = argparse.ArgumentParser(
        description="Generate routertl-ip-index entries from SDK units"
    )
    parser.add_argument(
        "--output", "-o",
        default="/tmp/routertl-ip-index",
        help="Output directory for index files (default: /tmp/routertl-ip-index)",
    )
    parser.add_argument(
        "--version", "-v",
        default=None,
        help="Version string (default: read from VERSION file)",
    )
    args = parser.parse_args()

    # Resolve version
    version = args.version
    if not version:
        version_file = SDK_ROOT / "VERSION"
        if version_file.exists():
            vtext = version_file.read_text()
            major = minor = "0"
            for line in vtext.splitlines():
                if line.startswith("system_major="):
                    major = line.split("=", 1)[1].strip()
                elif line.startswith("system_minor="):
                    minor = line.split("=", 1)[1].strip()
            version = f"{major}.{minor}.0"
        else:
            version = "0.0.0"

    # Scan units
    units_dir = SDK_ROOT / "src" / "units"
    if not units_dir.is_dir():
        print(f"Error: {units_dir} not found", file=sys.stderr)
        sys.exit(1)

    hdl_files = sorted(
        list(units_dir.glob("*.vhd"))
        + list(units_dir.glob("*.v"))
        + list(units_dir.glob("*.sv"))
    )

    catalog = []
    entries = []

    for path in hdl_files:
        entry = generate_entry(path, version)
        if not entry:
            print(f"  SKIP: {path.name} (no entity/module found)")
            continue

        catalog.append({
            "namespace": entry["namespace"],
            "name": entry["name"],
            "latest": version,
            "description": entry["description"],
        })
        entries.append(entry)
        print(f"  ✅ {entry['namespace']}/{entry['name']} ({path.name})")

    # Write output
    out = Path(args.output)
    out.mkdir(parents=True, exist_ok=True)

    # catalog.json
    catalog_path = out / "catalog.json"
    with open(catalog_path, "w") as f:
        json.dump(catalog, f, indent=2)
    print(f"\n📦 catalog.json: {len(catalog)} entries → {catalog_path}")

    # Per-package version YAMLs
    import yaml

    for entry in entries:
        pkg_dir = out / "packages" / entry["namespace"] / entry["name"]
        pkg_dir.mkdir(parents=True, exist_ok=True)
        yml_path = pkg_dir / f"{version}.yml"
        with open(yml_path, "w") as f:
            yaml.dump(entry, f, default_flow_style=False, sort_keys=False)

    print(f"📋 {len(entries)} package YAMLs → {out / 'packages' / 'routertl'}")


if __name__ == "__main__":
    main()
