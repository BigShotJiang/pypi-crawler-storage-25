(defun beautify-vhdl-file (filename)
  "Beautify a VHDL file specified by FILENAME."
  (when (file-exists-p filename)                      ; Check if the file exists
    (find-file filename)                              ; Open the file
    (if (derived-mode-p 'vhdl-mode)                   ; Check if VHDL Mode is active
        (progn
          (vhdl-beautify-buffer)                      ; Beautify the buffer
          (save-buffer))                              ; Save the buffer
      (message "Not in VHDL mode. Cannot beautify.")) ; Message if not in VHDL Mode
    (kill-buffer))) 

;; Loop through command-line arguments (excluding the script name itself)
(mapc 'beautify-vhdl-file command-line-args-left)

;; Usage: emacs --batch -l beautify-vhdl.el your_vhdl_file1.vhd your_vhdl_file2.vhd
