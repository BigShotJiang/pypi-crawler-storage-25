#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT
"""
Cython compilation helper — SDK maintainer tooling.
Called by: make cythonize
NOT an rr command: rr is for SDK consumers, this is for RouteRTL developers.
"""
import pathlib
import subprocess
import sys

ROOT = pathlib.Path(".")

MODULES = [
    "routertl_core/dependency_resolver.py",
    "routertl_core/description_validator.py",
    "routertl_core/ip_classifier.py",
    "routertl_core/ip_resolver.py",
    "routertl_core/ip_scanner.py",
    "routertl_core/ipxact_parser.py",
    "routertl_core/package_resolver.py",
    "routertl_core/project_manager.py",
    "routertl_core/report_parser.py",
    "routertl_core/scan_sources.py",
    "routertl_core/smart_linter.py",
    "routertl_core/xpr_parser.py",
    "routertl_core/sim/simulation.py",
    "routertl_core/sim/library_compiler.py",
    "routertl_core/sim/result_collector.py",
    "routertl_core/sim/default_libraries.py",
    "routertl_core/sim/vendor_libraries.py",
    "routertl_core/docker/orchestration.py",
    "routertl_core/workspace/orchestration.py",
]
# Add all sim/backends/*.py (excluding __init__.py — stays as Python)
MODULES += sorted(
    str(p) for p in ROOT.glob("routertl_core/sim/backends/*.py")
    if p.name != "__init__.py"
)

# Sentinel files that MUST exist after cythonization
SENTINELS = [
    "routertl_core/sim/simulation.py",
    "routertl_core/project_manager.py",
    "routertl_core/smart_linter.py",
    "routertl_core/sim/backends/__init__.py",
]


def main() -> int:
    failures = []
    processed = 0

    for src in MODULES:
        p = pathlib.Path(src)
        if not p.exists():
            print(f"  ⏭️  Skipping (not found): {src}")
            continue
        out = p.with_suffix(".c")
        print(f"  cython  {src}  →  {out.name}")
        result = subprocess.run(
            ["cython", "--embed=False", str(p), "-o", str(out)],
            capture_output=True,
            text=True,
        )
        if result.returncode != 0:
            print(f"  ❌ FAILED: {src}")
            if result.stderr:
                print("    " + result.stderr[:400].replace("\n", "\n    "))
            failures.append(src)
        else:
            processed += 1

    # ── Source integrity sentinel check ────────────────────────────────
    # Cythonize must NEVER delete .py sources. Hard abort if missing.
    missing = [s for s in SENTINELS if not pathlib.Path(s).exists()]
    if missing:
        print("\n❌ ABORT: Python source sentinel files MISSING after cythonize!")
        for m in missing:
            print(f"   ✗  {m}")
        print("   Cythonize must never delete .py sources. Investigate immediately.")
        return 1

    if failures:
        print(f"\n❌ {len(failures)} module(s) failed to Cythonize: {failures}")
        return 1

    print(f"\n✅ Cythonized {processed} module(s). Python .py sources intact.")
    print("   Next steps:")
    print("     git add routertl_core/**/*.c")
    print("     git commit -m 'chore: update Cython .c snapshots'")
    print("     git push && git tag v<x.y.z> && git push --tags")
    return 0


if __name__ == "__main__":
    sys.exit(main())
