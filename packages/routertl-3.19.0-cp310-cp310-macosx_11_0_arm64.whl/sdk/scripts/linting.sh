#!/bin/bash
# MIT License
# Copyright (c) 2024-2026 Daniel J. Mazure

# Generic VHDL Linting Script using GHDL
# Performs syntax analysis and semantic checks without full elaboration.
# Output is parsed for clean, organized display.
#
# Modes:
#   PRECOMPILE   — Compile global libraries (XPM, utils, packages)
#                  $3: (unused)  $4: PKG_FILES  $5: XPM_FILES  $6: UTILS_FILES
#   COMPILE_LIB  — Compile files into a named custom library
#                  $3: LIB_NAME  $4: LIB_FILES
#   LINT         — Analyse unit files against pre-compiled libraries
#                  $3: LIN_FILES  $7: EXTRA_SEARCH_PATHS (-P flags)

MODE=$1
ROOT_DIR=$2
LIN_FILES=$3
PKG_FILES=$4
XPM_FILES=$5
UTILS_FILES=$6

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PARSER="${SCRIPT_DIR}/../engine/ghdl_output_parser.py"
# Fallback for legacy layout
if [ ! -f "$PARSER" ]; then
    PARSER="${SCRIPT_DIR}/../project-manager/ghdl_output_parser.py"
fi

# Output directory for analysis files
SIM_BUILD_DIR="${ROOT_DIR}/sim/work"
mkdir -p $SIM_BUILD_DIR/xpm
mkdir -p $SIM_BUILD_DIR/utils
mkdir -p $SIM_BUILD_DIR/work
mkdir -p $SIM_BUILD_DIR/temp_lint

# Temporary file for capturing GHDL output
GHDL_OUTPUT=$(mktemp)
trap 'rm -f "$GHDL_OUTPUT"' EXIT

LINT_FAILED=0

if [ "$MODE" == "PRECOMPILE" ]; then
    # ---------------------------------------------------------
    # MODE: PRECOMPILE
    # Compiles XPM, Utils, and Global Packages into persistent libs
    # ---------------------------------------------------------
    
    # Clean persistent libraries
    rm -rf $SIM_BUILD_DIR/work/*
    rm -rf $SIM_BUILD_DIR/xpm/*
    rm -rf $SIM_BUILD_DIR/utils/*

    # 1. Analyze Core Libraries
    if [ -n "$XPM_FILES" ]; then
        ghdl -a --std=08 --workdir=${SIM_BUILD_DIR}/xpm --work=xpm $XPM_FILES >> "$GHDL_OUTPUT" 2>&1
        if [ ${PIPESTATUS[0]} -ne 0 ]; then LINT_FAILED=1; fi
    fi

    if [ -n "$UTILS_FILES" ]; then
        ghdl -a --std=08 --workdir=${SIM_BUILD_DIR}/utils --work=utils $UTILS_FILES >> "$GHDL_OUTPUT" 2>&1
        if [ ${PIPESTATUS[0]} -ne 0 ]; then LINT_FAILED=1; fi
    fi

    # 2. Analyze Project Packages
    if [ -n "$PKG_FILES" ]; then
        ghdl -a --std=08 --workdir=${SIM_BUILD_DIR}/work \
            -P${SIM_BUILD_DIR}/xpm \
            -P${SIM_BUILD_DIR}/utils \
            --work=work $PKG_FILES >> "$GHDL_OUTPUT" 2>&1
        if [ ${PIPESTATUS[0]} -ne 0 ]; then LINT_FAILED=1; fi
    fi

elif [ "$MODE" == "COMPILE_LIB" ]; then
    # ---------------------------------------------------------
    # MODE: COMPILE_LIB
    # Compiles files into a custom library
    # $3 = library name, $4 = file list (dependency-sorted)
    # ---------------------------------------------------------
    LIB_NAME=$3
    LIB_FILES=$4
    
    mkdir -p "$SIM_BUILD_DIR/$LIB_NAME"
    
    # Compile files ONE AT A TIME in the dependency-sorted order
    # provided by the smart linter.  GHDL requires each entity to
    # be fully analysed before files that instantiate it via
    # `entity <lib>.entity_name` can reference it.
    for FILE in $LIB_FILES; do
        # Skip non-VHDL files silently (e.g. .v, .sv)
        case "$FILE" in
            *.vhd|*.vhdl) ;;
            *) continue ;;
        esac
        ghdl -a ${GHDL_STD:---std=08} ${GHDL_EXTRA_FLAGS:-} --workdir="${SIM_BUILD_DIR}/${LIB_NAME}" \
            -P"${SIM_BUILD_DIR}/xpm" \
            -P"${SIM_BUILD_DIR}/utils" \
            -P"${SIM_BUILD_DIR}/work" \
            -P"${SIM_BUILD_DIR}/${LIB_NAME}" \
            --work="$LIB_NAME" "$FILE" >> "$GHDL_OUTPUT" 2>&1
        
        if [ $? -ne 0 ]; then
            LINT_FAILED=1
        fi
    done

elif [ "$MODE" == "LINT" ]; then
    # ---------------------------------------------------------
    # MODE: LINT
    # Compiles unit files into 'work' incrementally
    # $7 = extra search paths (-P flags)
    # ---------------------------------------------------------
    
    EXTRA_SEARCH_PATHS=$7

    # 3. Analyze Target Files
    # We compile directly into work so subsequent units works
    ghdl -a --std=08 --workdir=${SIM_BUILD_DIR}/work \
        -P${SIM_BUILD_DIR}/xpm \
        -P${SIM_BUILD_DIR}/utils \
        $EXTRA_SEARCH_PATHS \
        --work=work $LIN_FILES >> "$GHDL_OUTPUT" 2>&1
    if [ ${PIPESTATUS[0]} -ne 0 ]; then
        LINT_FAILED=1
    fi

    # 4. Final Syntax Check (Optional, but good for reporting)
    ghdl -s --std=08 --workdir=${SIM_BUILD_DIR}/work \
        -P${SIM_BUILD_DIR}/xpm \
        -P${SIM_BUILD_DIR}/utils \
        $EXTRA_SEARCH_PATHS \
        --work=work $LIN_FILES >> "$GHDL_OUTPUT" 2>&1
    if [ ${PIPESTATUS[0]} -ne 0 ]; then
        LINT_FAILED=1
    fi

else
    echo "Error: Unknown MODE '$MODE'. Use PRECOMPILE, COMPILE_LIB, or LINT." >> "$GHDL_OUTPUT"
    LINT_FAILED=1
fi

# Parse and display formatted output
if [ -f "$PARSER" ]; then
    # Only run parser if there is content (to avoid empty headers in quiet runs)
    if [ -s "$GHDL_OUTPUT" ]; then
        # Check if parser outputs anything meaningful or just header
        OUTPUT=$(cat "$GHDL_OUTPUT" | python3 "$PARSER" --root "$ROOT_DIR")
        if [ -n "$OUTPUT" ]; then
             echo ""
             echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
             echo "                   LINT REPORT                    "
             echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
             echo "$OUTPUT"
        fi
    fi
fi

if [ $LINT_FAILED -eq 0 ]; then
    if [ "$MODE" == "PRECOMPILE" ]; then
        echo "✅ Pre-compilation PASSED"
    else
        echo "✅ Linting PASSED"
    fi
    exit 0
else
    if [ "$MODE" == "PRECOMPILE" ]; then
        echo "❌ Pre-compilation FAILED"
    else
        echo "❌ Linting FAILED"
    fi
    exit 1
fi
