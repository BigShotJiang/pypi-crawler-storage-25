#!/usr/bin/env bash
# Fetch Custom Software Repositories
# Clones user-defined SW applications into $LINUX_SRC_DIR
set -euo pipefail

PROJECT_ROOT=${PROJECT_ROOT:-$(pwd)}
LINUX_SRC_DIR=${LINUX_SRC_DIR:-"$PROJECT_ROOT/linux/src"}
SW_REPOS=${SW_REPOS:-""}

mkdir -p "$LINUX_SRC_DIR"

if [ -z "$SW_REPOS" ]; then
    echo "No custom SW_REPOS defined. Skipping."
    exit 0
fi

echo "========================================"
echo "Fetching Custom Software Repositories..."
echo "========================================"

cd "$LINUX_SRC_DIR"

# Convert space-delimited string to array
read -ra REPO_ARRAY <<< "$SW_REPOS"

for REPO_URL in "${REPO_ARRAY[@]}"; do
    # Extract the repository name from the URL string
    REPO_NAME=$(basename "$REPO_URL" .git)
    
    if [ -d "$REPO_NAME" ]; then
        echo "➡️  $REPO_NAME already exists, skipping clone."
        # In the future, we might want to do a 'git pull' here if requested
    else
        echo "⬇️  Cloning $REPO_NAME from $REPO_URL..."
        git clone --depth 1 "$REPO_URL" "$REPO_NAME"
    fi
done

echo "✅ Custom Software Repositories fetched successfully."
