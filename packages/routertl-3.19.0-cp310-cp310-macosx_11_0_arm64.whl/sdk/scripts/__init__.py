# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT
"""Shell scripts distributed as package data (linting.sh, compile_unisim_nvc.sh)."""
