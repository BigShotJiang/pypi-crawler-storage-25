#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Scan an HDL repository and auto-discover IP packages for the index.

Clones a git repo at a specified tag, runs the dependency resolver to
discover all top-level entities, auto-detects the VHDL library name and
standard, and outputs registry entries ready for routertl-ip-index.

Usage:
    python sdk/scripts/scan_ip_repo.py \\
        --url https://github.com/open-logic/open-logic.git \\
        --tag v2.5.0 \\
        --namespace open-logic \\
        [--output /tmp/scan-results]

Architecture decision: D.15 — registry-driven IP index.

Note: core scanning intelligence (description extraction, role computation,
tag generation, scanning pipeline) lives in routertl_core.ip_scanner
(compiled). This module provides the CLI, public API, and tool-invocation
probes (GHDL, Verilator, git) that the core delegates to.
"""

import argparse
import json
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

# Resolve SDK root for imports
SCRIPT_DIR = Path(__file__).resolve().parent
SDK_ROOT = SCRIPT_DIR.parent.parent
sys.path.insert(0, str(SDK_ROOT))

from routertl_core.ip_scanner import (  # noqa: E402
    ScanProbes,
    compute_roles,
    generate_description,
    generate_tags,
    scan_repo,
)


def _clone_at_tag(url: str, tag: str, dest: Path) -> str:
    """Clone a git repo at a specific tag. Returns commit SHA."""
    subprocess.run(
        ["git", "clone", "--depth", "1", "--branch", tag, url, str(dest)],
        check=True, capture_output=True, text=True,
    )
    res = subprocess.run(
        ["git", "-C", str(dest), "rev-parse", "HEAD"],
        capture_output=True, text=True, check=True,
    )
    return res.stdout.strip()


def _detect_library_name(src_dir: Path) -> str:
    """Auto-detect the VHDL library name from source files.

    Scans for 'library X; use X.' patterns where X is not ieee/std/work.
    Returns the most common non-standard library, or 'work' if none found.
    """
    STANDARD_LIBS = {"ieee", "std", "work", "unisim", "unimacro", "xpm"}
    lib_counts: dict[str, int] = {}

    for vhd in src_dir.rglob("*.vhd"):
        # Skip test/doc directories
        rel = str(vhd.relative_to(src_dir))
        if "/test/" in rel or "/doc/" in rel or "/simulation/" in rel:
            continue
        try:
            text = vhd.read_text(errors="replace").lower()
        except OSError:
            continue
        for m in re.finditer(r"library\s+(\w+)\s*;", text):
            lib = m.group(1)
            if lib not in STANDARD_LIBS:
                lib_counts[lib] = lib_counts.get(lib, 0) + 1

    if lib_counts:
        return max(lib_counts, key=lib_counts.get)
    return "work"


def _detect_vhdl_standard(dep_files: list[Path], library: str = "work") -> tuple[str, bool]:
    """Compile the full dep chain and detect the required VHDL standard.

    Tries three strategies in order (smart fallback based on GHDL errors):
      1. --std=08 (strict VHDL-2008)
      2. --std=08 -frelaxed (if GHDL hints at it)
      3. --std=93 (if GHDL suggests standard mismatch)

    Returns ``(standard, verified)`` where verified is True if GHDL
    successfully compiled the full dep chain.
    """
    ghdl = shutil.which("ghdl")
    if not ghdl:
        return _infer_standard_from_source(dep_files), False

    vhdl_files = [f for f in dep_files if f.suffix.lower() in (".vhd", ".vhdl")]
    if not vhdl_files:
        return "unknown", False

    # Detect available precompiled vendor libraries for -P flags
    vendor_flags = _ghdl_vendor_flags()

    def _try_compile(std_flag: str, extra: str = "") -> tuple[bool, str]:
        """Try compiling all files. Returns (success, error_output)."""
        with tempfile.TemporaryDirectory() as workdir:
            cmd_base = [ghdl, "-a", std_flag, f"--workdir={workdir}", f"--work={library}"]
            cmd_base.extend(vendor_flags)
            if extra:
                cmd_base.append(extra)
            for f in vhdl_files:
                ret = subprocess.run(
                    cmd_base + [str(f)], capture_output=True, text=True,
                )
                if ret.returncode != 0:
                    return False, ret.stdout + ret.stderr
        return True, ""

    # Pass 1: strict 2008
    ok, errors = _try_compile("--std=08")
    if ok:
        return "vhdl-2008", True

    # Smart fallback based on GHDL error output
    if "-frelaxed" in errors or "protected type" in errors.lower():
        ok2, _ = _try_compile("--std=08", "-frelaxed")
        if ok2:
            return "vhdl-2008-relaxed", True

    # Pass 3: VHDL-93
    ok3, _ = _try_compile("--std=93")
    if ok3:
        return "vhdl-93", True

    # Compilation failed — infer from source content
    return _infer_standard_from_source(dep_files), False


def _ghdl_vendor_flags() -> list[str]:
    """Return -P flags for precompiled GHDL vendor libraries (unisim, etc.)."""
    flags = []
    try:
        from routertl_core.sim.vendor_libraries import (
            ghdl_unisim_available,
            ghdl_unisim_path,
        )
        if ghdl_unisim_available():
            flags.append(f"-P{ghdl_unisim_path()}")
    except ImportError:
        pass
    return flags


def _infer_standard_from_source(dep_files: list[Path]) -> str:
    """Infer VHDL standard from source content when GHDL can't compile.

    Heuristic: if the code uses unisim or xpm, it's targeting Xilinx
    which means VHDL-2008. If it uses VHDL-2008 constructs (like
    matching case, external names), it's 2008. Otherwise assume 2008.
    """
    for f in dep_files:
        if f.suffix.lower() not in (".vhd", ".vhdl"):
            continue
        try:
            text = f.read_text(errors="replace").lower()
        except OSError:
            continue
        # Xilinx primitives → VHDL-2008
        if "library unisim" in text or "use unisim." in text:
            return "vhdl-2008"
        if "library xpm" in text or "use xpm." in text:
            return "vhdl-2008"
    return "vhdl-2008"  # safe default


def _verify_verilog(dep_files: list[Path]) -> bool:
    """Try to lint Verilog/SV files with Verilator.

    Returns True if Verilator lint passes (or Verilator is unavailable
    — assume good faith). Returns False only on actual lint failure.
    """
    verilator = shutil.which("verilator")
    if not verilator:
        return False  # can't verify without Verilator

    sv_files = [str(f) for f in dep_files if f.suffix.lower() in (".v", ".sv", ".vh", ".svh")]
    if not sv_files:
        return False

    inc_dirs = sorted({str(Path(f).parent) for f in dep_files})
    inc_flags = [f"-I{d}" for d in inc_dirs]

    ret = subprocess.run(
        [verilator, "--lint-only", "-Wall", "-Wno-fatal"] + inc_flags + sv_files,
        capture_output=True, text=True,
    )
    return ret.returncode == 0


def _detect_vendor_deps(dep_files: list[Path]) -> list[str]:
    """Scan source files for vendor library dependencies.

    Returns a list of vendor dep names like ['unisim', 'xpm'].
    """
    VENDOR_PATTERNS = {
        "unisim": (r"library\s+unisim", r"use\s+unisim\."),
        "xpm": (r"library\s+xpm", r"use\s+xpm\."),
        "unimacro": (r"library\s+unimacro", r"use\s+unimacro\."),
    }
    found = set()
    for f in dep_files:
        if f.suffix.lower() not in (".vhd", ".vhdl"):
            continue
        try:
            text = f.read_text(errors="replace").lower()
        except OSError:
            continue
        for vendor, patterns in VENDOR_PATTERNS.items():
            if vendor not in found:
                for pat in patterns:
                    if re.search(pat, text):
                        found.add(vendor)
                        break
    return sorted(found)


def _detect_test_infrastructure(repo_path: Path) -> dict:
    """Detect test frameworks and count testbenches in a repository.

    Returns a dict with:
      frameworks: list of detected test frameworks (cocotb, vunit, osvvm, ...)
      testbench_count: number of HDL testbench files found
      test_file_count: total test-related files (Python + HDL)
    """
    frameworks: set[str] = set()
    testbench_count = 0
    test_file_count = 0

    # Scan Python test files for framework imports
    for py_file in repo_path.rglob("*.py"):
        rel = str(py_file.relative_to(repo_path))
        if "/." in rel:  # skip hidden dirs
            continue
        try:
            text = py_file.read_text(errors="replace")
        except OSError:
            continue

        if "import cocotb" in text or "from cocotb" in text:
            frameworks.add("cocotb")
            test_file_count += 1
        elif "import vunit" in text or "from vunit" in text:
            frameworks.add("vunit")
            test_file_count += 1

    # Scan for OSVVM (.pro files or library osvvm)
    for pro_file in repo_path.rglob("*.pro"):
        frameworks.add("osvvm")
        test_file_count += 1

    # Count HDL testbenches (_tb, tb_, _testbench suffixes)
    TB_PATTERNS = ("_tb", "_testbench")
    TB_PREFIXES = ("tb_",)
    for ext in ("*.vhd", "*.vhdl", "*.v", "*.sv"):
        for hdl_file in repo_path.rglob(ext):
            name = hdl_file.stem.lower()
            if any(name.endswith(s) for s in TB_PATTERNS) or any(name.startswith(s) for s in TB_PREFIXES):
                testbench_count += 1
                test_file_count += 1

    # Check for Makefile-based test targets (common in alexforencich repos)
    for makefile in repo_path.rglob("Makefile"):
        rel = str(makefile.relative_to(repo_path))
        if "test" in rel.lower() or "sim" in rel.lower():
            try:
                text = makefile.read_text(errors="replace")
                if "cocotb" in text.lower():
                    frameworks.add("cocotb")
                elif "iverilog" in text or "TOPLEVEL" in text:
                    frameworks.add("makefile-sim")
            except OSError:
                pass

    return {
        "frameworks": sorted(frameworks),
        "testbench_count": testbench_count,
        "test_file_count": test_file_count,
    }


def _compute_badges(verified: bool, test_info: dict) -> list[str]:
    """Compute trust badges for a package.

    Badge tiers:
      "linted"    — GHDL/Verilator lint passed
      "tested"    — repo contains testbenches or test framework files
      "simulated" — tests pass in simulation (future, manual)
    """
    badges = []
    if verified:
        badges.append("linted")
    if test_info.get("test_file_count", 0) > 0:
        badges.append("tested")
    return badges


# ── Probe bundle ────────────────────────────────────────────────


def _make_probes() -> ScanProbes:
    """Build a ScanProbes bundle from the local tool-invocation functions."""
    return ScanProbes(
        detect_library_name=_detect_library_name,
        detect_vhdl_standard=_detect_vhdl_standard,
        detect_vendor_deps=_detect_vendor_deps,
        detect_test_infrastructure=_detect_test_infrastructure,
        compute_badges=_compute_badges,
        verify_verilog=_verify_verilog,
    )


# ── Backwards-compatible internal API ───────────────────────────
#
# Callers (registry/routes/submit.py, registry/batch_verify.py)
# import _scan_repo and _detect_test_infrastructure from this module.
# Keep those names working.


def _scan_repo(repo_path: Path, namespace: str, url: str, tag: str, commit: str,
               use_llm: bool = True, granularity: str = "top",
               previous_descriptions: dict[str, str] | None = None,
               description_verdicts: dict[str, dict] | None = None) -> list[dict]:
    """Scan a cloned repo — thin wrapper around routertl_core.ip_scanner.scan_repo."""
    return scan_repo(
        repo_path=repo_path,
        namespace=namespace,
        url=url,
        tag=tag,
        commit=commit,
        probes=_make_probes(),
        use_llm=use_llm,
        granularity=granularity,
        previous_descriptions=previous_descriptions,
        description_verdicts=description_verdicts,
    )


# _detect_test_infrastructure is defined above and importable directly.
# _compute_roles is re-exported from core for any caller that needs it.
_compute_roles = compute_roles
_generate_tags = generate_tags
_generate_description = generate_description


# ── Public API ──────────────────────────────────────────────────


def scan_local_repo(repo_path: Path, namespace: str = "local",
                    use_llm: bool = True,
                    granularity: str = "top") -> list[dict]:
    """Scan a local repo directory and return discovered IP entries.

    This is the public API for rr pkg add --local. Reuses the same
    scanning logic as the full scan_ip_repo.py CLI.
    """
    return _scan_repo(
        repo_path=repo_path,
        namespace=namespace,
        url=f"file://{repo_path}",
        tag="local",
        commit="local",
        use_llm=use_llm,
        granularity=granularity,
    )


# ── CLI ─────────────────────────────────────────────────────────


def _load_curated_config(url: str) -> dict | None:
    """Load curated scanning overrides for a known repository URL.

    Returns the config dict if found, None otherwise.
    Looks for sdk/registry/curated_repos.json relative to this script.
    """
    config_path = SCRIPT_DIR.parent / "registry" / "curated_repos.json"
    if not config_path.exists():
        return None
    try:
        data = json.loads(config_path.read_text())
        repos = data.get("repos", {})
        # Normalise URL for lookup (strip trailing .git, trailing /)
        normalised = url.rstrip("/")
        if not normalised.endswith(".git"):
            normalised += ".git"
        return repos.get(normalised)
    except (OSError, json.JSONDecodeError):
        return None


def main():
    parser = argparse.ArgumentParser(
        description="Scan an HDL repo and discover IP packages for the index"
    )
    parser.add_argument("--url", required=True, help="Git repository URL")
    parser.add_argument("--tag", default="main", help="Git tag or branch (default: main)")
    parser.add_argument("--namespace", required=True, help="Index namespace (e.g. open-logic)")
    parser.add_argument("--output", "-o", default=None, help="Output directory for results")
    parser.add_argument("--keep", action="store_true", help="Keep cloned repo after scan")
    parser.add_argument("--no-llm", action="store_true",
                        help="Disable LLM fallback for descriptions (Tier 0 only)")
    parser.add_argument("--granularity", choices=["top", "repo", "all"],
                        default=None,
                        help="Package granularity: 'top' (one IP per top-level "
                             "entity, default), 'repo' (one package per repo), "
                             "'all' (every entity, legacy). Auto-detected from "
                             "curated config if not specified.")
    parser.add_argument("--ignore-curated", action="store_true",
                        help="Ignore curated repo overrides")
    args = parser.parse_args()

    # Check curated overrides
    curated = None if args.ignore_curated else _load_curated_config(args.url)
    if curated:
        # Skip repos marked as non-IP
        if curated.get("namespace") == "_skip":
            print(f"\n⏭️  Skipping {args.url} — curated config says: {curated.get('notes', 'not an IP library')}")
            return

        # Apply curated defaults (CLI flags override)
        if args.granularity is None:
            args.granularity = curated.get("granularity", "top")
        print(f"\n🔍 Scanning {args.url} @ {args.tag}")
        print(f"   Namespace: {args.namespace}")
        print(f"   Granularity: {args.granularity} (curated)")
        if curated.get("notes"):
            print(f"   📋 {curated['notes']}")
        print()
    else:
        if args.granularity is None:
            args.granularity = "top"
        print(f"\n🔍 Scanning {args.url} @ {args.tag}")
        print(f"   Namespace: {args.namespace}")
        print(f"   Granularity: {args.granularity}\n")

    # Clone
    clone_dir = Path(tempfile.mkdtemp(prefix="rr_scan_"))
    try:
        print("   📥 Cloning...")
        commit = _clone_at_tag(args.url, args.tag, clone_dir)
        print(f"   ✅ Cloned at {commit[:8]}")

        # Detect library
        library = _detect_library_name(clone_dir)
        print(f"   📚 Detected library: {library}")

        # Scan
        print("   🔍 Running dependency resolver...\n")
        entries = _scan_repo(clone_dir, args.namespace, args.url, args.tag, commit,
                            use_llm=not args.no_llm,
                            granularity=args.granularity)

        # Display results
        if args.granularity == "repo" and entries:
            e = entries[0]
            tops = e.get("top_modules", [])
            comps = e.get("components", [])
            total = e.get("total_entities", 0)
            print(f"   📦 1 package: {e['name']}")
            print(f"      {total} entities scanned → "
                  f"{len(tops)} top-level modules, {len(comps)} components")
            if e.get("license"):
                print(f"      License: {e['license']}")
            print(f"      Description: {e['description']}")
            print("\n   Top-level modules:")
            for name in sorted(tops):
                print(f"     • {name}")
            if comps:
                print(f"\n   Internal components ({len(comps)}):")
                for name in sorted(comps)[:20]:
                    print(f"     · {name}")
                if len(comps) > 20:
                    print(f"     · ... and {len(comps) - 20} more")
        else:
            verified_count = sum(1 for e in entries if e["verified"])
            unverified_count = len(entries) - verified_count
            desc_header = sum(1 for e in entries if e.get("desc_source") == "header")
            desc_ports = sum(1 for e in entries if e.get("desc_source") == "ports")
            desc_llm = sum(1 for e in entries if e.get("desc_source") == "llm")
            desc_auto = sum(1 for e in entries if e.get("desc_source") == "auto")
            print(f"   Found {len(entries)} public entities "
                  f"({verified_count} verified, {unverified_count} unverified)")
            print(f"   Descriptions: {desc_header} from headers, {desc_ports} from ports, "
                  f"{desc_llm} from LLM, {desc_auto} auto-generated\n")
            for e in sorted(entries, key=lambda x: x["name"]):
                std_tag = e["vhdl_standard"]
                deps = e["dep_count"]
                v_icon = "✓" if e["verified"] else "?"
                vendor_tag = ", ".join(e["vendor_deps"]) if e["vendor_deps"] else ""
                parts = [f"{deps} files", std_tag]
                if vendor_tag:
                    parts.append(vendor_tag)
                if not e["verified"]:
                    parts.append("not verified")
                role_tag = f" [{e.get('role', '?')}]" if args.granularity != "all" else ""
                print(f"     {v_icon} {e['name']:<40} ({', '.join(parts)}){role_tag}")

        # Output
        if args.output:
            out = Path(args.output)
            out.mkdir(parents=True, exist_ok=True)

            # Write individual entries
            import yaml
            for e in entries:
                pkg_dir = out / "packages" / args.namespace / e["name"]
                pkg_dir.mkdir(parents=True, exist_ok=True)
                # Clean internal fields
                entry = {
                    "name": e["name"],
                    "namespace": e["namespace"],
                    "version": args.tag.lstrip("v"),
                    "description": e["description"],
                    "license": e["license"],
                    "source": e["source"],
                    "routertl_compat": e["routertl_compat"],
                }
                yml_path = pkg_dir / f"{args.tag.lstrip('v')}.yml"
                with open(yml_path, "w") as f:
                    yaml.dump(entry, f, default_flow_style=False, sort_keys=False)

            # Write catalog snippet
            catalog = [
                {
                    "namespace": e["namespace"],
                    "name": e["name"],
                    "latest": args.tag.lstrip("v"),
                    "description": e["description"],
                }
                for e in entries
            ]
            cat_path = out / f"catalog_{args.namespace}.json"
            with open(cat_path, "w") as f:
                json.dump(catalog, f, indent=2)

            print(f"\n   📦 Output written to {out}")
            print(f"      {len(entries)} package YAMLs + catalog snippet")

        if args.granularity == "repo":
            tops = entries[0].get("top_modules", []) if entries else []
            print(f"\n   🎉 Scan complete: 1 package, {len(tops)} top-level modules")
        else:
            print(f"\n   🎉 Scan complete: {len(entries)} IPs discovered")

    finally:
        if not args.keep:
            shutil.rmtree(clone_dir, ignore_errors=True)
        else:
            print(f"\n   📂 Clone kept at: {clone_dir}")


if __name__ == "__main__":
    main()
