#!/usr/bin/env bash
# Assemble BOOT.bin and prepare SD Card image files
set -euo pipefail

PROJECT_ROOT=${PROJECT_ROOT:-$(pwd)}
LINUX_OUT_DIR=${LINUX_OUT_DIR:-"$PROJECT_ROOT/linux/out"}
BOOTGEN_BIF="$LINUX_OUT_DIR/boot.bif"
PLATFORM_ARCH=${PLATFORM_ARCH:-zynq}

# Ensure prerequisites exist
for f in fsbl.elf u-boot.elf; do
    if [ ! -f "$LINUX_OUT_DIR/$f" ]; then
        echo "❌ $f not found in $LINUX_OUT_DIR. Run build-fsbl/build-uboot first."
        exit 1
    fi
done

# Check if bootgen is available in the environment
if ! command -v bootgen &> /dev/null; then
    echo "❌ bootgen command could not be found. Please ensure you are running in the 'buildroot' Docker container."
    exit 1
fi

BITSTREAM=$(find "$PROJECT_ROOT" -name "*.bit" | head -n 1)
if [ -z "$BITSTREAM" ]; then
    echo "⚠️  No bitstream (.bit) found. BOOT.bin will not contain FPGA logic."
fi

echo "========================================"
echo "Assembling BOOT.bin ($PLATFORM_ARCH)"
echo "========================================"

cat <<EOF > "$BOOTGEN_BIF"
the_ROM_image:
{
    [bootloader]$LINUX_OUT_DIR/fsbl.elf
EOF

if [ -n "$BITSTREAM" ]; then
    echo "    $BITSTREAM" >> "$BOOTGEN_BIF"
fi

cat <<EOF >> "$BOOTGEN_BIF"
    $LINUX_OUT_DIR/u-boot.elf
}
EOF

echo "Running bootgen..."
bootgen -image "$BOOTGEN_BIF" -arch "$PLATFORM_ARCH" -w -o "$LINUX_OUT_DIR/BOOT.bin"

echo "✅ BOOT.bin generated at $LINUX_OUT_DIR/BOOT.bin"
echo "To create the SD Card, copy BOOT.bin, boot.scr (if used), uImage, and system.dtb to the boot partition."
