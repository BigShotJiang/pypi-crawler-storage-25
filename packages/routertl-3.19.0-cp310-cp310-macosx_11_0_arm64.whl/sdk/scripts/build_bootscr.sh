#!/usr/bin/env bash
# Compile a U-Boot boot script (boot.txt -> boot.scr) via mkimage.
# Triggered by the 'boot_script' key in project.yml.
set -euo pipefail

PROJECT_ROOT=${PROJECT_ROOT:-$(pwd)}
LINUX_OUT_DIR=${LINUX_OUT_DIR:-"$PROJECT_ROOT/linux/out"}
BOOT_SCRIPT=${BOOT_SCRIPT:-""}
ARCH=${ARCH:-arm}

# --- Gate: only run if boot_script is declared in project.yml ---
if [ -z "$BOOT_SCRIPT" ]; then
    exit 0
fi

echo "========================================"
echo "Compiling U-Boot Boot Script"
echo "========================================"

# Resolve the path relative to project root
BOOT_TXT="$PROJECT_ROOT/$BOOT_SCRIPT"

if [ ! -f "$BOOT_TXT" ]; then
    echo "⚠️  Warning: 'boot_script: $BOOT_SCRIPT' is declared in project.yml,"
    echo "   but the file was not found at: $BOOT_TXT"
    echo "   Skipping boot.scr generation."
    exit 1
fi

# Ensure mkimage is available
if ! command -v mkimage &> /dev/null; then
    echo "❌ Error: 'mkimage' not found."
    echo "Install u-boot-tools or run inside the buildroot Docker container."
    exit 1
fi

mkdir -p "$LINUX_OUT_DIR"

echo "Source:  $BOOT_TXT"
echo "Target:  $LINUX_OUT_DIR/boot.scr"
echo "Arch:    $ARCH"

mkimage -A "$ARCH" -T script -O linux -d "$BOOT_TXT" "$LINUX_OUT_DIR/boot.scr"

echo "✅ boot.scr compiled successfully."
