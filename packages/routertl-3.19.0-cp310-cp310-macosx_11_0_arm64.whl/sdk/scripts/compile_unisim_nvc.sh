#!/bin/bash
# =============================================================================
# compile_unisim_nvc.sh — Compile Xilinx unisim for NVC simulation
#
# Requires: $XILINX_VIVADO pointing to a Vivado installation
# Output:   ~/.nvc/lib/unisim/ (NVC precompiled library)
# =============================================================================
set -euo pipefail

if [ -z "${XILINX_VIVADO:-}" ]; then
    echo "❌ XILINX_VIVADO not set."
    echo "   Set it to your Vivado directory, e.g.:"
    echo "   export XILINX_VIVADO=/tools/Xilinx/Vivado/2024.1"
    exit 1
fi

if [ ! -d "$XILINX_VIVADO/data/vhdl/src/unisims" ]; then
    echo "❌ $XILINX_VIVADO/data/vhdl/src/unisims not found."
    echo "   Ensure XILINX_VIVADO points at a valid Vivado installation."
    exit 1
fi

# Find NVC's install script
export NVC_LIB
NVC_LIB=$(dirname "$(which nvc)")/../lib/nvc
INSTALL_SCRIPT="$HOME/.nvc/lib/install-vivado.sh"

if [ ! -x "$INSTALL_SCRIPT" ]; then
    echo "❌ NVC install-vivado.sh not found at $INSTALL_SCRIPT"
    echo "   Ensure NVC >= 1.18.2 is installed and ~/.nvc/lib/ exists."
    exit 1
fi

echo "🔧 Compiling unisim from $XILINX_VIVADO..."
echo "   Output: ~/.nvc/lib/unisim/"
echo ""

bash "$INSTALL_SCRIPT"

echo ""
echo "✅ Unisim precompiled successfully."
echo "   $(ls ~/.nvc/lib/unisim/ | wc -l) compiled units"
echo "   $(du -sh ~/.nvc/lib/unisim/ | cut -f1) total size"
