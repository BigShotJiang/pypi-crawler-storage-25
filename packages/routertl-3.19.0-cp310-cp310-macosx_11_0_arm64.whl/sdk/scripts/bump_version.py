#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT
"""
Version bump helper — SDK maintainer tooling.
Called by: make bump-version VERSION=x.y.z
Updates pyproject.toml and routertl_core/__init__.py in sync.
"""
import pathlib
import re
import sys


def bump(version: str) -> int:
    # Validate semver format
    if not re.fullmatch(r"\d+\.\d+\.\d+", version):
        print(f"❌ Invalid version format: '{version}'. Expected x.y.z (e.g. 3.5.0)")
        return 1

    root = pathlib.Path(".")
    errors = []

    # ── 1. pyproject.toml ────────────────────────────────────────────
    pyproject = root / "pyproject.toml"
    if not pyproject.exists():
        errors.append("pyproject.toml not found")
    else:
        text = pyproject.read_text()
        new_text, n = re.subn(
            r'^(version\s*=\s*")[^"]+(")',
            rf'\g<1>{version}\g<2>',
            text,
            flags=re.MULTILINE,
        )
        if n == 0:
            errors.append("pyproject.toml: could not find 'version = \"...\"' line")
        else:
            pyproject.write_text(new_text)
            print(f"  ✅ pyproject.toml       → {version}")

    # ── 2. routertl_core/__init__.py ─────────────────────────────────
    init_py = root / "routertl_core" / "__init__.py"
    if not init_py.exists():
        errors.append("routertl_core/__init__.py not found")
    else:
        text = init_py.read_text()
        new_text, n = re.subn(
            r'(__version__\s*=\s*")[^"]+(".*# fallback)',
            rf'\g<1>{version}\g<2>',
            text,
        )
        if n == 0:
            errors.append("routertl_core/__init__.py: could not find fallback __version__ line")
        else:
            init_py.write_text(new_text)
            print(f"  ✅ routertl_core/__init__.py  → {version}")

    if errors:
        print("\n❌ Errors:")
        for e in errors:
            print(f"   • {e}")
        return 1

    print(f"\n✅ Version bumped to {version}.")
    print("   Next steps:")
    print("     make cythonize")
    print("     git add pyproject.toml routertl_core/__init__.py routertl_core/**/*.c")
    print(f"    git commit -m 'chore: bump version to {version}'")
    print(f"    git push && git tag v{version} && git push --tags")
    return 0


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: bump_version.py <x.y.z>")
        sys.exit(1)
    sys.exit(bump(sys.argv[1]))
