#!/usr/bin/env bash
# Build U-Boot from Xilinx/u-boot-xlnx source
set -euo pipefail

PROJECT_ROOT=${PROJECT_ROOT:-$(pwd)}
LINUX_SRC_DIR=${LINUX_SRC_DIR:-"$PROJECT_ROOT/linux/src"}
LINUX_OUT_DIR=${LINUX_OUT_DIR:-"$PROJECT_ROOT/linux/out"}
UBOOT_DEFCONFIG=${UBOOT_DEFCONFIG:-xilinx_zynq_virt_defconfig}
ARCH=${ARCH:-arm}
CROSS_COMPILE=${CROSS_COMPILE:-arm-linux-gnueabihf-}

UBOOT_DIR="$LINUX_SRC_DIR/u-boot-xlnx"
UBOOT_DEFAULT_REPO="https://github.com/Xilinx/u-boot-xlnx.git"
UBOOT_REPO="${UBOOT_REPO:-$UBOOT_DEFAULT_REPO}"

echo "========================================"
echo "Building U-Boot for $UBOOT_DEFCONFIG"
echo "========================================"

mkdir -p "$LINUX_SRC_DIR"
mkdir -p "$LINUX_OUT_DIR"

if [ ! -d "$UBOOT_DIR" ]; then
    echo "Cloning U-Boot source from $UBOOT_REPO..."
    git clone --depth 1 "$UBOOT_REPO" "$UBOOT_DIR"
fi

cd "$UBOOT_DIR"

echo "Configuring U-Boot..."
make ARCH=$ARCH CROSS_COMPILE=$CROSS_COMPILE $UBOOT_DEFCONFIG

echo "Compiling U-Boot..."
if [ -n "${DEVICE_TREE:-}" ]; then
    echo "Using explicit DEVICE_TREE=$DEVICE_TREE"
    make ARCH=$ARCH CROSS_COMPILE=$CROSS_COMPILE DEVICE_TREE=$DEVICE_TREE -j"$(nproc)"
else
    make ARCH=$ARCH CROSS_COMPILE=$CROSS_COMPILE -j"$(nproc)"
fi

cp u-boot.elf "$LINUX_OUT_DIR/u-boot.elf"
cp u-boot.bin "$LINUX_OUT_DIR/u-boot.bin"
echo "✅ U-Boot built: $LINUX_OUT_DIR/u-boot.elf"
