#!/usr/bin/env bash
# ──────────────────────────────────────────────────────────────
# repair_venv.sh — Zero-dependency .venv recovery
# ──────────────────────────────────────────────────────────────
# Desperate recovery for when the CLI is completely broken.
# Uses ONLY system Python + git — no pip, no click, no routertl.
#
# Usage (from project root):
#   bash $(rr sdk-path)/sdk/scripts/repair_venv.sh
#
# What it does:
#   1. Detects and diagnoses .venv corruption
#   2. Backs up .env (if present)
#   3. Nukes the broken .venv
#   4. Creates a fresh one with system Python
#   5. Installs the SDK (pip install -e)
#   6. Rebuilds CLI aliases (rr + branded name)
#   7. Verifies the entry point works
# ──────────────────────────────────────────────────────────────
set -euo pipefail

RED='\033[0;31m'
GREEN='\033[0;32m'
CYAN='\033[0;36m'
YELLOW='\033[1;33m'
DIM='\033[2m'
RESET='\033[0m'

echo ""
echo -e "${CYAN}🔧 RouteRTL .venv Repair Tool${RESET}"
echo -e "${DIM}   Zero-dependency recovery for broken virtual environments.${RESET}"
echo ""

# ── Locate SDK ───────────────────────────────────────────────
SDK_ROOT=""
# Try rr sdk-path first (works for pip-install)
SDK_ROOT=$(rr sdk-path 2>/dev/null || true)

if [ -z "$SDK_ROOT" ]; then
    # Fall back to submodule candidates
    for candidate in vendor/routertl vendor/rapidrtl; do
        if [ -f "$candidate/VERSION" ]; then
            SDK_ROOT="$candidate"
            break
        fi
    done
fi

if [ -z "$SDK_ROOT" ]; then
    # Fall back to __file__ traversal (script is at SDK/sdk/scripts/repair_venv.sh)
    SCRIPT_DIR=$(cd "$(dirname "$0")" && pwd)
    SDK_ROOT=$(cd "$SCRIPT_DIR/../.." && pwd)
    if [ ! -f "$SDK_ROOT/VERSION" ]; then
        echo -e "${RED}❌ Cannot find SDK root. Set ROUTERTL_ROOT or run from a project directory.${RESET}"
        exit 1
    fi
fi
echo -e "  SDK: ${CYAN}$SDK_ROOT${RESET}"

# ── Find system Python ───────────────────────────────────────
PYTHON=""
for py in python3.12 python3.11 python3.10 python3; do
    if command -v "$py" > /dev/null 2>&1; then
        PYTHON="$py"
        break
    fi
done

if [ -z "$PYTHON" ]; then
    echo -e "${RED}❌ No Python 3 found on system PATH.${RESET}"
    echo "   Install Python 3.10+ and try again."
    exit 1
fi

PY_VERSION=$("$PYTHON" --version 2>&1 | grep -oP '\d+\.\d+\.\d+')
echo -e "  Python: ${CYAN}$PYTHON${RESET} (${PY_VERSION})"

# ── Diagnose existing .venv ──────────────────────────────────
echo ""
if [ -d ".venv" ]; then
    echo -e "${YELLOW}⚠️  Existing .venv found. Running diagnostics...${RESET}"

    ISSUES=0

    # Check 1: Python symlink
    if [ -L ".venv/bin/python3" ]; then
        TARGET=$(realpath .venv/bin/python3 2>/dev/null || true)
        if [ ! -f "$TARGET" ]; then
            echo -e "  ${RED}❌ Broken Python symlink → $TARGET${RESET}"
            ISSUES=$((ISSUES + 1))
        else
            echo -e "  ${GREEN}✅ Python symlink OK${RESET}"
        fi
    elif [ -f ".venv/bin/python3" ]; then
        echo -e "  ${GREEN}✅ Python binary OK${RESET}"
    else
        echo -e "  ${RED}❌ .venv/bin/python3 missing${RESET}"
        ISSUES=$((ISSUES + 1))
    fi

    # Check 2: pip works
    if .venv/bin/python3 -m pip --version > /dev/null 2>&1; then
        echo -e "  ${GREEN}✅ pip works${RESET}"
    else
        echo -e "  ${RED}❌ pip is broken${RESET}"
        ISSUES=$((ISSUES + 1))
    fi

    # Check 3: routertl entry point exists and imports
    if [ -f ".venv/bin/routertl" ]; then
        if .venv/bin/python3 -c "from tools.cli.main import cli" 2>/dev/null; then
            echo -e "  ${GREEN}✅ routertl entry point works${RESET}"
        else
            echo -e "  ${RED}❌ routertl entry point broken (import fails)${RESET}"
            ISSUES=$((ISSUES + 1))
        fi
    else
        echo -e "  ${RED}❌ routertl entry point missing${RESET}"
        ISSUES=$((ISSUES + 1))
    fi

    # Check 4: SDK is editable-installed
    if .venv/bin/python3 -c "import routertl" 2>/dev/null || \
       .venv/bin/python3 -c "import tools.cli" 2>/dev/null; then
        echo -e "  ${GREEN}✅ SDK package importable${RESET}"
    else
        echo -e "  ${YELLOW}⚠️  SDK package not importable${RESET}"
        ISSUES=$((ISSUES + 1))
    fi

    echo ""
    if [ "$ISSUES" -eq 0 ]; then
        echo -e "${GREEN}✅ .venv looks healthy! No repair needed.${RESET}"
        echo -e "${DIM}   If you're still having issues, run with --force:${RESET}"
        echo -e "${DIM}   bash $SDK_ROOT/sdk/scripts/repair_venv.sh --force${RESET}"
        if [ "${1:-}" != "--force" ]; then
            exit 0
        fi
        echo -e "\n${YELLOW}--force specified, proceeding with repair anyway.${RESET}"
    else
        echo -e "${YELLOW}Found $ISSUES issue(s). Proceeding with repair.${RESET}"
    fi

    # ── Nuke old .venv ──
    echo ""
    echo -e "${YELLOW}🗑️  Removing broken .venv...${RESET}"
    rm -rf .venv
    echo -e "  ${GREEN}Done.${RESET}"
else
    echo -e "${DIM}No existing .venv found. Creating a fresh one.${RESET}"
fi

# ── Create fresh .venv ───────────────────────────────────────
echo ""
echo -e "${CYAN}📦 Creating new .venv...${RESET}"
"$PYTHON" -m venv .venv
echo -e "  ${GREEN}✅ Created with $PYTHON${RESET}"

# ── Activate ─────────────────────────────────────────────────
source .venv/bin/activate

# ── Upgrade pip ──────────────────────────────────────────────
echo ""
echo -e "${CYAN}📦 Upgrading pip...${RESET}"
pip install --quiet --upgrade pip
echo -e "  ${GREEN}✅ pip upgraded${RESET}"

# ── Install SDK ──────────────────────────────────────────────
echo ""
echo -e "${CYAN}📦 Installing RouteRTL SDK...${RESET}"
pip install --quiet -e "$SDK_ROOT"
echo -e "  ${GREEN}✅ SDK installed${RESET}"

# ── Install project requirements (if present) ────────────────
if [ -f "requirements.txt" ]; then
    echo ""
    echo -e "${CYAN}📦 Installing project requirements...${RESET}"
    pip install --quiet -r requirements.txt
    echo -e "  ${GREEN}✅ Requirements installed${RESET}"
fi

# ── Rebuild aliases ──────────────────────────────────────────
echo ""
echo -e "${CYAN}🔗 Creating CLI shortcuts...${RESET}"

# Create rr shortcut
ROUTERTL_BIN=".venv/bin/routertl"
if [ -f "$ROUTERTL_BIN" ]; then
    ln -sf routertl .venv/bin/rr
    echo -e "  ${GREEN}✅ rr → routertl${RESET}"

    # Read branding from project.yml (best-effort, no yaml parser needed)
    if [ -f "project.yml" ]; then
        BRANDED=$(grep -A1 "^branding:" project.yml 2>/dev/null | grep "cli_name:" | sed 's/.*cli_name:\s*//' | tr -d '"'"'" | tr -d '[:space:]' || true)
        if [ -n "$BRANDED" ] && [ "$BRANDED" != "routertl" ]; then
            ln -sf routertl ".venv/bin/$BRANDED"
            echo -e "  ${GREEN}✅ $BRANDED → routertl${RESET}"
        fi
    fi
else
    echo -e "  ${RED}❌ routertl entry point not found after install!${RESET}"
fi

# ── Verify ───────────────────────────────────────────────────
echo ""
echo -e "${CYAN}🧪 Verification...${RESET}"

if .venv/bin/routertl --help > /dev/null 2>&1; then
    echo -e "  ${GREEN}✅ routertl --help works${RESET}"
else
    echo -e "  ${RED}❌ routertl --help failed${RESET}"
fi

if command -v rr > /dev/null 2>&1 && rr --help > /dev/null 2>&1; then
    echo -e "  ${GREEN}✅ rr --help works${RESET}"
else
    echo -e "  ${YELLOW}⚠️  rr shortcut not yet on PATH (re-activate: source .venv/bin/activate)${RESET}"
fi

# ── Done ─────────────────────────────────────────────────────
echo ""
echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
echo -e "${GREEN}✅ Repair complete!${RESET}"
echo -e "${DIM}   Activate with: source .venv/bin/activate${RESET}"
echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
echo ""
