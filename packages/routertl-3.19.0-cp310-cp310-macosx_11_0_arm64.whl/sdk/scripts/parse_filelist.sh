#!/bin/bash
# MIT License
#
# Copyright (c) 2024-2026 Daniel J. Mazure
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
# IN THE SOFTWARE.

# Define the Makefile list
FLIST_FILE=$1 #".file_list_expanded.txt"

# Extract file paths from the mk file
FILES=$(grep -oP '(?<=\=\s|\+=\s).*' "$FLIST_FILE" | tr -d '\r')

# Check for misystemng files
MISSING_FILES=()

for FILE in $FILES; do
    if [[ ! -f "$FILE" ]]; then
        MISSING_FILES+=("$FILE")
    fi
done

# Print results
if [[ ${#MISSING_FILES[@]} -eq 0 ]]; then
    echo "✅ All files exist!"
else
    echo "❌ Misystemng files:"
    for FILE in "${MISSING_FILES[@]}"; do
        echo "   - $FILE"
    done
    echo "Double check how you used += syntax in the Makefile!"
    exit 1
fi
