#!/usr/bin/env bash
# install_progress.sh — Shared progress indicator for EDA installers
#
# Source this file and call: run_with_progress "label" "install_dir" command args...
#
# Shows a spinner with elapsed time and install directory size while the
# installer runs in the background. This gives users feedback during the
# 20-60 minute unattended EDA installations.
#
# Stale-progress watchdog:
#   If the install directory size does not change for INSTALL_STALE_TIMEOUT
#   seconds (default: 120), the installer process group is killed.  This
#   handles EDA tools (Quartus DDM daemon, etc.) that spawn orphan child
#   processes which keep the PID alive after the real installation finishes.

# Configurable: seconds of zero disk-size change before we force-kill.
# Default 300s (5 min) — Quartus has idle phases between base toolchain
# and device extraction where no bytes are written.
INSTALL_STALE_TIMEOUT="${INSTALL_STALE_TIMEOUT:-300}"

# ──────────────────────────────────────────────────────────────────
# _find_vendor_installer — glob-safe EDA installer detection
#
# RTL-P2.445: vendor install_*.sh scripts used `if ls PATTERN1 PATTERN2`
# to detect installers, which returns non-zero when one pattern matches
# nothing even though the other matched a real file.  Net effect: the
# script wrongly concluded "no installer" while the .tar.gz was right
# there.  A second class of bug was "multiple archives in one folder"
# (e.g. petalinux-*.run, a Vivado bundle, an Enclustra .bsp all in
# Downloads) picking the wrong file alphabetically.
#
# This helper replaces all ad-hoc detection with one glob-safe walk
# that applies a per-vendor dictionary of preferred-name substrings,
# an anti-pattern exclusion list, and an optional minimum file size.
#
# Usage:
#   _find_vendor_installer DIR "EXT1 EXT2 …" "PREFER1 PREFER2 …" "EXCLUDE1 …" MIN_SIZE_BYTES
# Prints the best candidate path on stdout, returns 0.
# Returns 1 (no output) when nothing matches.
#
# Matching semantics:
#   - Case-insensitive substring match on basename.
#   - A file is kept only if it matches at least one EXT.
#   - A file is dropped if any EXCLUDE pattern appears in the basename.
#   - A file is dropped if its size is below MIN_SIZE_BYTES (pass 0 to skip).
#   - Preferred files (matching any PREFER) beat non-preferred files.
#   - Among files at the same preference level, the largest wins.
# ──────────────────────────────────────────────────────────────────
_find_vendor_installer() {
    local dir="$1"
    local exts_str="$2"
    local prefer_str="$3"
    local exclude_str="$4"
    local min_size="${5:-0}"

    # Word-split into arrays.
    # shellcheck disable=SC2206  # intentional word-split
    local -a exts=($exts_str)
    # shellcheck disable=SC2206
    local -a prefer=($prefer_str)
    # shellcheck disable=SC2206
    local -a exclude=($exclude_str)

    local best="" best_size=0 best_is_preferred=0
    local ext f base base_lc size is_pref is_exc p

    for ext in "${exts[@]}"; do
        [ -z "$ext" ] && continue
        for f in "$dir"/*."$ext"; do
            # Bash glob without nullglob leaves the literal pattern
            # when nothing matches — filter via -f before use.
            [ -f "$f" ] || continue

            base=$(basename "$f")
            base_lc="${base,,}"  # bash 4+ lowercase

            # Exclusion scan (case-insensitive).
            is_exc=0
            for p in "${exclude[@]}"; do
                [ -z "$p" ] && continue
                if [[ "$base_lc" == *"${p,,}"* ]]; then
                    is_exc=1
                    break
                fi
            done
            [ "$is_exc" -eq 1 ] && continue

            # Size filter.
            size=$(stat -c%s "$f" 2>/dev/null || echo 0)
            if [ "$min_size" -gt 0 ] && [ "$size" -lt "$min_size" ]; then
                continue
            fi

            # Preference scan.
            is_pref=0
            for p in "${prefer[@]}"; do
                [ -z "$p" ] && continue
                if [[ "$base_lc" == *"${p,,}"* ]]; then
                    is_pref=1
                    break
                fi
            done

            # Rank: preferred > non-preferred, size tie-breaker.
            if [ "$is_pref" -gt "$best_is_preferred" ]; then
                best="$f"; best_size="$size"; best_is_preferred="$is_pref"
            elif [ "$is_pref" -eq "$best_is_preferred" ] && [ "$size" -gt "$best_size" ]; then
                best="$f"; best_size="$size"
            fi
        done
    done

    if [ -n "$best" ]; then
        printf '%s\n' "$best"
        return 0
    fi
    return 1
}


run_with_progress() {
    local label="$1"
    local install_dir="$2"
    shift 2

    echo ""
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo "⏳  ${label}"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo ""

    # Run installer in its OWN process group (setsid) so we can kill the
    # entire group later — including any children the installer spawns.
    setsid "$@" > /tmp/_install_stdout.log 2>&1 &
    local installer_pid=$!

    local spinner='⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏'
    local spin_idx=0
    local start_time
    start_time=$(date +%s)

    # Stale-progress tracking
    local prev_size=""
    local stale_since=0

    # Spinner loop
    while kill -0 "$installer_pid" 2>/dev/null; do
        local now
        now=$(date +%s)
        local elapsed=$((now - start_time))
        local mins=$((elapsed / 60))
        local secs=$((elapsed % 60))

        # Get install directory size
        local dir_size="calculating..."
        local dir_size_human="?"
        if [ -d "$install_dir" ]; then
            # Use byte-level precision for stale detection (du -sb)
            # to catch small writes that du -sh rounds away.
            dir_size=$(du -sb "$install_dir" 2>/dev/null | cut -f1 || echo "?")
            dir_size_human=$(du -sh "$install_dir" 2>/dev/null | cut -f1 || echo "?")
        fi

        local c="${spinner:$spin_idx:1}"
        spin_idx=$(( (spin_idx + 1) % ${#spinner} ))

        printf "\r   ${c}  Installing... %02d:%02d elapsed │ %s on disk   " \
            "$mins" "$secs" "$dir_size_human"

        # ── Stale-progress watchdog ──────────────────────────────
        # If disk size has not changed for INSTALL_STALE_TIMEOUT seconds,
        # the installer has likely finished but left orphan processes.
        if [ "$dir_size" = "$prev_size" ] && [ "$dir_size" != "calculating..." ]; then
            stale_since=$((stale_since + 1))
            if [ "$stale_since" -ge "$INSTALL_STALE_TIMEOUT" ]; then
                printf "\r%80s\r" ""
                echo "   ⚠️  Installation activity stopped (${INSTALL_STALE_TIMEOUT}s with no disk change)"
                echo "   Terminating stale installer processes..."
                # Kill the entire process group (negative PID = group)
                kill -TERM -- -"$installer_pid" 2>/dev/null || true
                sleep 2
                # Force-kill if still alive
                kill -KILL -- -"$installer_pid" 2>/dev/null || true
                break
            fi
        else
            stale_since=0
        fi
        prev_size="$dir_size"

        sleep 1
    done

    # Clear spinner line
    printf "\r%80s\r" ""

    # Get exit code
    wait "$installer_pid" 2>/dev/null
    local exit_code=$?

    local end_time
    end_time=$(date +%s)
    local total=$((end_time - start_time))
    local total_mins=$((total / 60))
    local total_secs=$((total % 60))
    local final_size="?"
    if [ -d "$install_dir" ]; then
        final_size=$(du -sh "$install_dir" 2>/dev/null | cut -f1 || echo "?")
    fi

    # Count installed device families for completeness check
    local device_count=0
    if [ -d "$install_dir" ]; then
        device_count=$(find "$install_dir" -maxdepth 5 -path '*/quartus/common/devinfo/*' -type d 2>/dev/null | head -20 | wc -l)
    fi

    # A stale-kill results in a non-zero exit that is NOT a real failure.
    # If we broke due to stale timeout AND there IS content on disk,
    # treat it as success BUT warn about potential incompleteness.
    if [ "$stale_since" -ge "$INSTALL_STALE_TIMEOUT" ] && [ "$final_size" != "?" ] && [ "$final_size" != "0" ]; then
        echo "   ✅  Installation complete in ${total_mins}m ${total_secs}s (${final_size} on disk)"
        echo "       (stale orphan processes were terminated)"
        if [ "$device_count" -eq 0 ]; then
            echo ""
            echo "   ⚠️  WARNING: No device families detected after installation."
            echo "      The installer may have been terminated before device"
            echo "      extraction completed. If .qdz files were provided,"
            echo "      run 'rr docker add-device quartus' to install them."
        fi
        exit_code=0
    elif [ $exit_code -eq 0 ]; then
        echo "   ✅  Installation complete in ${total_mins}m ${total_secs}s (${final_size} on disk)"
    else
        echo "   ❌  Installation failed (exit code: ${exit_code}) after ${total_mins}m ${total_secs}s"
        echo ""
        echo "   Last 20 lines of installer output:"
        tail -20 /tmp/_install_stdout.log 2>/dev/null | sed 's/^/   │ /'
    fi
    echo ""

    return $exit_code
}
