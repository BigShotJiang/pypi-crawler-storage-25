#!/usr/bin/env bash
# add_device_quartus.sh: Install .qdz device packages into an existing Quartus volume
#
# This script extracts .qdz files (ZIP archives) directly into /opt/altera/
# without re-running setup_pro.sh. This is safe because .qdz files contain
# only device database files under quartus/common/devinfo/<family>/.
#
# Uses Python's zipfile module for extraction (always available in container).
#
# Usage (inside container):
#   bash /home/runner/add_device_quartus.sh
#
# Triggered by: rr docker add-device quartus

set -euo pipefail

QUARTUS_OPT_DIR="/opt/altera"
INSTALLERS_DIR="/installers"
HOST_PATH="${QUARTUS_INSTALLER_PATH_HOST:-${INSTALLERS_DIR}}"

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "📦  RouteRTL — Quartus Device Package Installer"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# ── Step 1: Validate existing Quartus installation ──────────────
if ! find "${QUARTUS_OPT_DIR}" -maxdepth 3 -type d -name "quartus" | grep -q .; then
    echo ""
    echo "❌  Quartus is not installed in ${QUARTUS_OPT_DIR}"
    echo "   Run 'rr docker shell quartus' first to install Quartus."
    echo ""
    exit 1
fi

# Get Quartus version and edition for display and compatibility check
QUARTUS_SH=$(find "${QUARTUS_OPT_DIR}" -maxdepth 4 -name "quartus_sh" -type f -print -quit 2>/dev/null || true)
QUARTUS_VER="unknown"
QUARTUS_MAJOR_MINOR=""
QUARTUS_EDITION=""
if [ -n "${QUARTUS_SH}" ]; then
    QUARTUS_VERSION_RAW=$("${QUARTUS_SH}" --version 2>&1 || true)
    QUARTUS_VER=$(echo "${QUARTUS_VERSION_RAW}" | grep -oP 'Version \K[\d.]+' || echo "unknown")
    # Extract major.minor (e.g. "23.1" from "23.1.0")
    QUARTUS_MAJOR_MINOR=$(echo "${QUARTUS_VER}" | grep -oP '^\d+\.\d+' || true)
    # Detect edition: "Pro Edition" → pro, "Standard Edition" → std
    if echo "${QUARTUS_VERSION_RAW}" | grep -qi "Pro Edition"; then
        QUARTUS_EDITION="pro"
    elif echo "${QUARTUS_VERSION_RAW}" | grep -qi "Standard"; then
        QUARTUS_EDITION="std"
    fi
    EDITION_LABEL="${QUARTUS_EDITION:-unknown}"
    echo ""
    echo "  ✅ Quartus ${QUARTUS_VER} (${EDITION_LABEL}) detected in ${QUARTUS_OPT_DIR}"
fi

# ── Step 2: Scan for .qdz files ────────────────────────────────
echo ""
echo "  Scanning ${HOST_PATH} for .qdz device packages..."
echo ""

mapfile -t QDZ_FILES < <(find "${INSTALLERS_DIR}" -maxdepth 1 -name '*.qdz' -type f 2>/dev/null | sort)

if [ ${#QDZ_FILES[@]} -eq 0 ]; then
    echo "┌──────────────────────────────────────────────────────────────┐"
    echo "│  ⚠️  No .qdz files found                                     │"
    echo "├──────────────────────────────────────────────────────────────┤"
    echo "│  Download device packages from:                              │"
    echo "│  https://www.intel.com/content/www/us/en/products/           │"
    echo "│  details/fpga/                                               │"
    echo "│                                                              │"
    printf "│  Place them in: %-42s│\n" "${HOST_PATH}"
    echo "│  Then re-run:   rr docker add-device quartus                 │"
    echo "└──────────────────────────────────────────────────────────────┘"
    echo ""
    exit 0
fi

echo "┌──────────────────────────────────────────────────────────────┐"
echo "│  📦  Device Packages Found                                     │"
echo "├──────────────────────────────────────────────────────────────┤"
for qf in "${QDZ_FILES[@]}"; do
    qname=$(basename "$qf")
    qsize=$(du -h "$qf" 2>/dev/null | cut -f1)
    printf "│  📁 %-48s %6s │\n" "$qname" "$qsize"
done
echo "└──────────────────────────────────────────────────────────────┘"
echo ""

# ── Step 3: Extract .qdz files into Quartus installation ───────
# .qdz files are ZIP archives containing paths like:
#   quartus/common/devinfo/<family>/...
# We extract them directly into /opt/altera/ which maps:
#   quartus/ → /opt/altera/quartus/
#
# Uses Python zipfile (always available) instead of unzip binary.
INSTALLED=0
SKIPPED=0
FAILED=0

for qf in "${QDZ_FILES[@]}"; do
    qname=$(basename "$qf")

    # ── Version compatibility check ──
    # Parse version and edition from .qdz filename
    # Pattern: <family>-<ver><edition>.<build>.<rev>.qdz
    # Examples: arria10-23.1std.0.991.qdz → 23.1, std
    #           arria10-25.3pro.0.27.qdz  → 25.3, pro
    QDZ_INFO=$(python3 -c "
import re, sys
name = '$qname'
# Match: name-VER(std|pro).build.rev.qdz
m = re.search(r'-(\d+\.\d+)(std|pro)\.', name)
if m:
    print(f'{m.group(1)} {m.group(2)}')
else:
    print('unknown unknown')
" 2>/dev/null || echo "unknown unknown")
    QDZ_VER=$(echo "$QDZ_INFO" | awk '{print $1}')
    QDZ_EDITION=$(echo "$QDZ_INFO" | awk '{print $2}')

    if [ "$QDZ_VER" != "unknown" ] && [ -n "$QUARTUS_MAJOR_MINOR" ]; then
        MISMATCH=""
        if [ "$QDZ_VER" != "$QUARTUS_MAJOR_MINOR" ]; then
            MISMATCH="version"
        fi
        if [ -n "$QUARTUS_EDITION" ] && [ "$QDZ_EDITION" != "unknown" ] && [ "$QDZ_EDITION" != "$QUARTUS_EDITION" ]; then
            if [ -n "$MISMATCH" ]; then
                MISMATCH="${MISMATCH} and edition"
            else
                MISMATCH="edition"
            fi
        fi
        if [ -n "$MISMATCH" ]; then
            echo ""
            echo "  ┌────────────────────────────────────────────────────┐"
            echo "  │  ⚠️  ${MISMATCH} mismatch detected!               │"
            echo "  ├────────────────────────────────────────────────────┤"
            printf "  │  Installed: Quartus %-8s (%s)                │\n" "$QUARTUS_MAJOR_MINOR" "${QUARTUS_EDITION:-?}"
            printf "  │  Package:   %-12s (%s)                │\n" "$qname" "$QDZ_EDITION"
            echo "  │                                                    │"
            echo "  │  Device packages must match your Quartus version   │"
            echo "  │  and edition (Pro vs Standard).                    │"
            echo "  └────────────────────────────────────────────────────┘"
            echo ""
        fi
    fi

    # Check if this device family is already installed by peeking
    # at the first directory inside the .qdz (via Python zipfile)
    FAMILY_DIR=$(python3 -c "
import zipfile, sys
z = zipfile.ZipFile('$qf')
for n in z.namelist():
    if n.startswith('quartus/common/devinfo/') and n.endswith('/'):
        parts = n.replace('quartus/common/devinfo/', '').strip('/').split('/')
        if parts[0]:
            print(parts[0])
            break
" 2>/dev/null || true)

    if [ -n "$FAMILY_DIR" ] && [ -d "${QUARTUS_OPT_DIR}/quartus/common/devinfo/${FAMILY_DIR}" ]; then
        EXISTING_COUNT=$(find "${QUARTUS_OPT_DIR}/quartus/common/devinfo/${FAMILY_DIR}" -type f 2>/dev/null | wc -l)
        if [ "$EXISTING_COUNT" -gt 100 ]; then
            echo "  ⏭️  ${qname}: ${FAMILY_DIR} already installed (${EXISTING_COUNT} files) — skipping"
            SKIPPED=$((SKIPPED + 1))
            continue
        fi
    fi

    echo "  📥 Installing ${qname}..."
    RESULT=$(python3 -c "
import zipfile, sys, os

z = zipfile.ZipFile('$qf')
members = z.namelist()
total = len(members)
files = 0
bar_width = 40

for i, member in enumerate(members, 1):
    z.extract(member, '${QUARTUS_OPT_DIR}')
    if not member.endswith('/'):
        files += 1
    # Progress bar
    pct = i * 100 // total
    filled = bar_width * i // total
    bar = '█' * filled + '░' * (bar_width - filled)
    sys.stdout.write(f'\r     [{bar}] {pct:3d}%  ({files} files)')
    sys.stdout.flush()

sys.stdout.write('\n')
print(files)
" 2>&1)

    EXIT_CODE=$?
    FILE_COUNT=$(echo "$RESULT" | tail -1)

    if [ "$EXIT_CODE" -eq 0 ]; then
        echo "  ✅ Done (${FILE_COUNT} files extracted)"
        INSTALLED=$((INSTALLED + 1))
    else
        echo "  ❌ Failed: ${RESULT}"
        FAILED=$((FAILED + 1))
    fi
done

# ── Step 4: Summary ────────────────────────────────────────────
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  📊 Summary: ${INSTALLED} installed, ${SKIPPED} skipped, ${FAILED} failed"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# ── Step 5: Show updated device inventory (post-install) ───────
echo ""
echo "┌──────────────────────────────────────────────────────────────┐"
echo "│  📦  Installed Device Families (post-install)                  │"
echo "├──────────────────────────────────────────────────────────────┤"
if [ -d "${QUARTUS_OPT_DIR}/quartus/common/devinfo" ]; then
    for fam_dir in "${QUARTUS_OPT_DIR}"/quartus/common/devinfo/*/; do
        if [ -d "$fam_dir" ]; then
            fam_name=$(basename "$fam_dir")
            fam_count=$(find "$fam_dir" -type f 2>/dev/null | wc -l)
            printf "│  ✅ %-46s %6d files │\n" "$fam_name" "$fam_count"
        fi
    done
else
    echo "│  ⚠️  No devinfo directory found                              │"
fi
echo "└──────────────────────────────────────────────────────────────┘"
echo ""
