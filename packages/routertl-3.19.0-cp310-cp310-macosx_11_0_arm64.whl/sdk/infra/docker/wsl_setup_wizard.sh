#!/usr/bin/env bash
# WSL Setup Wizard for RouteRTL Docker Environments
# Autonomously checks WSL memory limits and prompts for Node-Locked MAC spoofing
set -euo pipefail

# Find project root so we can drop the .wsl_setup_done flag
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SDK_ROOT="$(dirname "$(dirname "$SCRIPT_DIR")")"

if [ -z "${PROJECT_ROOT:-}" ]; then
    _candidate="$(dirname "$SDK_ROOT")"
    _candidate="$(dirname "$_candidate")"
    if [ -f "$_candidate/project.yml" ]; then
        PROJECT_ROOT="$_candidate"
    elif [ -f "$SDK_ROOT/project.yml" ]; then
        PROJECT_ROOT="$SDK_ROOT"
    else
        PROJECT_ROOT="$(pwd)"
    fi
fi

FLAG_FILE="$PROJECT_ROOT/.wsl_setup_done"

if [ -f "$FLAG_FILE" ]; then
    exit 0 # We've already bothered them once
fi

echo "============================================================"
echo "  routertl: Heavy EDA WSL2 Optimizer & License Spoofer      "
echo "============================================================"

IS_WSL=0
if grep -qi "microsoft" /proc/version 2>/dev/null; then
    IS_WSL=1
fi

if [ $IS_WSL -eq 1 ]; then
    # In WSL, the Windows user profile is typically mapped to /mnt/c/Users/<username>
    # We can ask cmd.exe via wslpath to cleanly resolve %USERPROFILE%
    if command -v cmd.exe >/dev/null; then
        WIN_PROFILE=$(cmd.exe /c "echo %USERPROFILE%" 2>/dev/null | tr -d '\r')
        WSL_PROFILE_PATH=$(wslpath -u "$WIN_PROFILE" 2>/dev/null || echo "")
        
        if [ -n "$WSL_PROFILE_PATH" ] && [ -d "$WSL_PROFILE_PATH" ]; then
            WSLCONFIG_PATH="$WSL_PROFILE_PATH/.wslconfig"
            if [ ! -f "$WSLCONFIG_PATH" ]; then
                echo "⚠️  WARNING: No .wslconfig found in Windows User Profile!"
                echo "   Synthesizers like Quartus and Simulators like Riviera-PRO "
                echo "   routinely consume 32GB+ of RAM for complex SOCs."
                echo "   By default, WSL limits memory to 50% of your total RAM. This will cause"
                echo "   the compiler to silently crash with an OOM (Out of Memory) error."
                echo ""
                echo "   We STRONGLY recommend creating a .wslconfig file in Windows:"
                echo "   Path: $WIN_PROFILE\\.wslconfig"
                echo "   [wsl2]"
                echo "   memory=48GB"
                echo "   processors=16"
                echo ""
                read -p "Press [Enter] to acknowledge this warning and continue..."
            fi
        fi
    fi
fi

echo ""
echo "--- License Configuration (Optional) ---"
echo "If your EDA License (Quartus, Riviera, etc) is Node-Locked to your"
echo "Windows MAC address, Docker's virtual network will fail the license check."
echo "If you use a floating VPN license (LM_LICENSE_FILE=27000@server), press Enter."
read -p "Enter Windows MAC address to spoof (e.g. 02:42:DE:AD:BE:EF) or press Enter to skip: " USER_MAC

if [ -n "$USER_MAC" ]; then
    ENV_FILE="$PROJECT_ROOT/.env"
    
    # Strip spaces just to be safe
    CLEAN_MAC=$(echo "$USER_MAC" | tr -d ' ')
    
    # Check if EDA_MAC_ADDRESS_OVERRIDE is already populated
    if grep -q "^EDA_MAC_ADDRESS_OVERRIDE=" "$ENV_FILE" 2>/dev/null; then
        sed -i "s|^EDA_MAC_ADDRESS_OVERRIDE=.*|EDA_MAC_ADDRESS_OVERRIDE=$CLEAN_MAC|" "$ENV_FILE"
    else
        echo "EDA_MAC_ADDRESS_OVERRIDE=$CLEAN_MAC" >> "$ENV_FILE"
    fi
    echo "✅ MAC Address injected into: $ENV_FILE"
fi

touch "$FLAG_FILE"

# Auto-create CLI aliases (rr + branded name) if routertl is available
if command -v routertl >/dev/null 2>&1; then
    routertl workspace rebrand 2>/dev/null || true
fi

echo "✅ Setup wizard complete. Continuing with Docker build..."
echo "============================================================"
echo ""
