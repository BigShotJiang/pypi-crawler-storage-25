#!/usr/bin/env bash
# SPDX-License-Identifier: MIT
#
# Regression tests for _find_vendor_installer (RTL-P2.445).
#
# Reproduces the docker_log incident: a 107 GB Vivado tar.gz sitting in
# /vivado-installer/ alongside a petalinux *.run and an Enclustra *.bsp
# was NOT detected by the old `if ls *.tar.gz *.tar` check because `ls`
# returns 2 when one of two patterns has no matches.  This test file
# locks in the fix and exercises the dictionary + size filter edges.
#
# Run via:
#   bash sdk/infra/docker/tests/test_find_vendor_installer.sh
# Or via the run_tests.py harness.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=../install_progress.sh
source "${SCRIPT_DIR}/../install_progress.sh"

_tmp=$(mktemp -d)
trap 'rm -rf "$_tmp"' EXIT

_mk() { truncate -s "$2" "$_tmp/$1"; }

_pass=0
_fail=0
_check() {
    local label="$1" expected="$2" actual="$3"
    if [ "$expected" = "$actual" ]; then
        printf '  ✅ %s\n' "$label"
        _pass=$((_pass + 1))
    else
        printf '  ❌ %s\n     expected: %s\n     actual:   %s\n' "$label" "$expected" "$actual"
        _fail=$((_fail + 1))
    fi
}

echo "─── RTL-P2.445 _find_vendor_installer tests ───"

# ── 1. Original bug: only *.tar.gz, no *.tar → must still find it.
_mk "FPGAs_AdaptiveSoCs_Unified_2024.1_0522_2023.tar.gz" 6G
got=$(_find_vendor_installer "$_tmp" "tar.gz tar" "FPGAs Xilinx Vivado" "petalinux" 5368709120 || true)
_check "Original bug — single .tar.gz extension matches" \
    "$_tmp/FPGAs_AdaptiveSoCs_Unified_2024.1_0522_2023.tar.gz" "$got"

# ── 2. Mixed folder (the docker_log scenario): Vivado + petalinux + BSP.
_mk "petalinux-v2024.1-05202009-installer.run" 3G
_mk "AM-XZU65-7EV-2I-D3E-PE5-SD.bsp" 44k
got=$(_find_vendor_installer "$_tmp" "tar.gz tar" \
    "FPGAs_AdaptiveSoCs Xilinx_Unified Vivado" \
    "petalinux Quartus bsp" 5368709120 || true)
_check "Mixed dir — picks Vivado over petalinux + BSP noise" \
    "$_tmp/FPGAs_AdaptiveSoCs_Unified_2024.1_0522_2023.tar.gz" "$got"

# ── 3. Quartus search in the same dir — must reject everything.
got=$(_find_vendor_installer "$_tmp" "tar run" \
    "Quartus Altera Intel_Quartus" \
    "petalinux Vivado Xilinx FPGAs" 524288000 \
    && echo SHOULD_NOT_MATCH || true)
_check "Wrong-vendor search — exclusions reject all files" "" "$got"

# ── 4. Size filter — a correctly-named file too small gets rejected.
_mk "Vivado_stub.tar.gz" 1k
got=$(_find_vendor_installer "$_tmp" "tar.gz" "Vivado" "" 100000000 || true)
# The 6 GB FPGAs_* file wins over the 1 KB stub even though both match
# the "Vivado" prefer pattern (case-insensitive contains "Vivado" in
# "AdaptiveSoCs_Unified"... actually no — Vivado substring isn't there.
# So the 1 KB stub is the only *_Vivado_* name.  Size filter kills it,
# and the FPGAs file matches the "Xilinx" etc prefer? No, prefer is
# just "Vivado" here, so the FPGAs file is non-preferred but size-OK
# → wins by fallback.).
_check "Size filter — rejects too-small file, falls back to larger non-preferred" \
    "$_tmp/FPGAs_AdaptiveSoCs_Unified_2024.1_0522_2023.tar.gz" "$got"

# ── 5. Preference ranking — preferred name beats larger non-preferred.
_tmp2=$(mktemp -d)
trap 'rm -rf "$_tmp" "$_tmp2"' EXIT
truncate -s 10G "$_tmp2/random_huge.tar.gz"
truncate -s 6G  "$_tmp2/Xilinx_Vivado_proper.tar.gz"
got=$(_find_vendor_installer "$_tmp2" "tar.gz" "Xilinx Vivado" "petalinux" 1073741824 || true)
_check "Preferred name wins even when smaller than a generic file" \
    "$_tmp2/Xilinx_Vivado_proper.tar.gz" "$got"

# ── 6. Empty dir — return 1, no stdout.
_tmp3=$(mktemp -d)
trap 'rm -rf "$_tmp" "$_tmp2" "$_tmp3"' EXIT
got=$(_find_vendor_installer "$_tmp3" "tar.gz tar" "Vivado" "" 0 || echo RC_NONZERO)
_check "Empty dir — helper returns 1" "RC_NONZERO" "$got"

# ── 7. Case-insensitive match (basename comparison uses bash 4 ${var,,}).
_tmp4=$(mktemp -d)
trap 'rm -rf "$_tmp" "$_tmp2" "$_tmp3" "$_tmp4"' EXIT
truncate -s 6G "$_tmp4/VIVADO_Installer_CAPS.tar"
got=$(_find_vendor_installer "$_tmp4" "tar" "vivado xilinx" "petalinux" 1073741824 || true)
_check "Case-insensitive prefer pattern" \
    "$_tmp4/VIVADO_Installer_CAPS.tar" "$got"

echo ""
echo "─── Summary ───"
echo "  Passed: $_pass"
echo "  Failed: $_fail"
[ "$_fail" -eq 0 ]
