#!/usr/bin/env bash
# install_radiant.sh: Automated entrypoint for RouteRTL Radiant container

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/install_progress.sh"

RADIANT_OPT_DIR="/opt/lscc/radiant"
INSTALLERS_DIR="/installers"
HOST_PATH="${RADIANT_INSTALLER_PATH_HOST:-${INSTALLERS_DIR}}"

echo "Checking Lattice Radiant installation in ${RADIANT_OPT_DIR}..."

# Ensure the persistent volume directory exists and is writable by the runner user
mkdir -p "${RADIANT_OPT_DIR}"
chown -R runner:runner "${RADIANT_OPT_DIR}"

# We check for the presence of 'ispfpga' directory inside the opt folder
if ! find "${RADIANT_OPT_DIR}" -maxdepth 3 -type d -name "ispfpga" | grep -q .; then
    echo "Lattice Radiant not found. Looking for installer..."

    # Validate the /installers mount
    if [ -f "${INSTALLERS_DIR}" ]; then
        echo ""
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        echo "❌  RADIANT_INSTALLER_PATH points to a FILE, not a DIRECTORY"
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        echo "  It must point to the DIRECTORY containing the installer:"
        echo "    RADIANT_INSTALLER_PATH=/path/to/Downloads/  ← correct"
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        echo ""
    else
        # RTL-P2.445: dictionary/size detector — same helper across all vendors.
        RADIANT_INSTALLER=$(_find_vendor_installer "${INSTALLERS_DIR}" \
            "run" \
            "Radiant LatticeRadiant Lattice_Radiant" \
            "petalinux logic-trace Quartus Vivado Xilinx Libero Questa Riviera bsp BSP" \
            104857600) || RADIANT_INSTALLER=""

        if [ -z "${RADIANT_INSTALLER}" ]; then
            RADIANT_ZIP=$(_find_vendor_installer "${INSTALLERS_DIR}" \
                "zip" \
                "Radiant LatticeRadiant Lattice_Radiant" \
                "petalinux logic-trace Quartus Vivado Xilinx Libero Questa Riviera bsp BSP" \
                104857600) || RADIANT_ZIP=""
            if [ -n "${RADIANT_ZIP}" ]; then
                echo "Found zip file: $(basename "${RADIANT_ZIP}"). Extracting .run installer..."
                TMP_EXTRACT="/home/runner/radiant_tmp_install"
                mkdir -p "${TMP_EXTRACT}"
                unzip -q -o "${RADIANT_ZIP}" -d "${TMP_EXTRACT}"
                chmod +x "${TMP_EXTRACT}"/*.run 2>/dev/null || true
                # Helper on the extracted dir: pick the largest .run matching the
                # Radiant dictionary (there's usually just one but be defensive).
                RADIANT_INSTALLER=$(_find_vendor_installer "${TMP_EXTRACT}" \
                    "run" \
                    "Radiant LatticeRadiant" \
                    "" \
                    0) || RADIANT_INSTALLER=""
            fi
        fi

        if [ -n "${RADIANT_INSTALLER}" ]; then
            echo "Found Radiant installer: $(basename "${RADIANT_INSTALLER}")"
            
            echo "Starting headless installation (this may take several minutes)..."
            # IFW 2.0.1 requires bypassing the license prompts.
            # 9x "y\n" covers all internal prompts for standard installation.
            echo -e "y\ny\ny\ny\ny\ny\ny\ny\ny\n" | \
                env -u DISPLAY -u WAYLAND_DISPLAY \
                "${RADIANT_INSTALLER}" --console --prefix "${RADIANT_OPT_DIR}"
                
            echo "✅ Installation complete."
            
            # Deploy license if present
            if [ -f "${INSTALLERS_DIR}/license.dat" ]; then
                echo "Deploying license.dat..."
                mkdir -p "${RADIANT_OPT_DIR}/license"
                cp "${INSTALLERS_DIR}/license.dat" "${RADIANT_OPT_DIR}/license/license.dat"
            else
                echo "⚠️  No license.dat found in RADIANT_INSTALLER_PATH."
                echo "   Remember to place your node-locked license.dat inside the installer folder."
            fi
            
            # Cleanup
            if [ -d "/home/runner/radiant_tmp_install" ]; then
                rm -rf "/home/runner/radiant_tmp_install"
            fi
            rm -f /tmp/lockmyApp*.lock || true
        else
            echo "⚠️  No Radiant installer found in ${HOST_PATH}"
            echo "   Expected: *Radiant*.run or *Radiant*.zip"
        fi
    fi
else
    echo "✅ Lattice Radiant is already installed."
fi

# Handover
RADIANT_HOME=$(find "${RADIANT_OPT_DIR}" -maxdepth 2 -type d -name "ispfpga" | sed 's|/ispfpga||' | sort -r | head -n 1)

if [ -n "${RADIANT_HOME}" ]; then
    echo "✅ Radiant root discovered at: ${RADIANT_HOME}"
else
    RADIANT_HOME="${RADIANT_OPT_DIR}"
fi

echo "Handing over to: $*"
exec su -s /bin/bash runner -c "
  export PATH='${RADIANT_HOME}/bin/lin64:${RADIANT_HOME}/ispfpga/bin/lin64:/usr/local/bin:/usr/bin:/bin:$PATH'
  export RADIANT_HOME='${RADIANT_HOME}'
  export LM_LICENSE_FILE='${RADIANT_HOME}/license/license.dat'
  export FOUNDRY='${RADIANT_HOME}/ispfpga'
  cd /home/runner/work
  exec $*"
