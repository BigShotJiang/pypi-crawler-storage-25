#!/usr/bin/env bash
# install_vivado.sh: Automated entrypoint for RouteRTL Vivado container
# This script checks if Vivado is installed in the persistent volume.
# If not, it runs the unattended Xilinx installer from the mounted directory.

set -euo pipefail

# Source the shared progress indicator
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/install_progress.sh"

# Define target installation directories on the persistent volume
VIVADO_OPT_DIR="/opt/Xilinx"
INSTALLERS_DIR="/vivado-installer"
VIVADO_VERSION="${VIVADO_VERSION:-2025.1}"

echo "Checking Xilinx Vivado ${VIVADO_VERSION} installation in ${VIVADO_OPT_DIR}..."

# Ensure the persistent volume directory exists and is writable
sudo mkdir -p "${VIVADO_OPT_DIR}" 2>/dev/null || true
sudo chown -R $(whoami):$(whoami) "${VIVADO_OPT_DIR}" 2>/dev/null || true

# -------------------------------------------------------------
# 1. Vivado Installation
# -------------------------------------------------------------
# Check for Vivado binary in the expected location
if [ ! -f "${VIVADO_OPT_DIR}/${VIVADO_VERSION}/Vivado/bin/vivado" ]; then
    echo "Vivado ${VIVADO_VERSION} not found. Looking for installer..."

    # ── Validate the /vivado-installer mount ────────────────────
    if [ -f "${INSTALLERS_DIR}" ]; then
        echo ""
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        echo "❌  VIVADO_INSTALLER_PATH points to a FILE, not a DIRECTORY"
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        echo ""
        echo "  It must point to the DIRECTORY containing the installer:"
        echo "    VIVADO_INSTALLER_PATH=/mnt/c/Users/YourName/Downloads  ← correct"
        echo "    VIVADO_INSTALLER_PATH=/path/to/Vivado.tar             ← wrong"
        echo ""
        echo "  Fix your .env file and re-run: routertl docker shell vivado"
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        echo ""
        echo "Continuing to shell without Vivado..."
        exec "$@"
    fi

    # Helper: locate or generate install_config.txt
    _find_install_config() {
        # Priority 1: SDK-mounted config (from docker-compose volume)
        if [ -f "/etc/routertl/install_config.vivado.txt" ]; then
            echo "/etc/routertl/install_config.vivado.txt"
            return
        fi
        # Priority 2: User-supplied config alongside the installer
        if [ -f "${INSTALLERS_DIR}/install_config.txt" ]; then
            echo "${INSTALLERS_DIR}/install_config.txt"
            return
        fi
        # Priority 2: Generate a minimal default
        local cfg="/tmp/vivado_install_config.txt"
        cat > "${cfg}" <<CFGEOF
## RouteRTL Auto-Generated Vivado Install Config
## To customize, place your own install_config.txt in the installer directory.
## Generate a template with: xsetup -b ConfigGen

Edition=Vivado ML Standard
Product=Vivado
Destination=${VIVADO_OPT_DIR}/${VIVADO_VERSION}

Modules=Vivado:1,Vitis HLS:0,DocNav:0,Model Composer:0
InstallOptions=
CreateProgramGroupShortcuts=0
CreateDesktopShortcuts=0
CreateFileAssociation=0
EnableWebTalk=false
CFGEOF
        echo "${cfg}"
    }

    # Priority 1: Extracted installer with xsetup
    if [ -f "${INSTALLERS_DIR}/xsetup" ]; then
        echo "Found Xilinx xsetup installer."
        INSTALL_CFG=$(_find_install_config)
        echo "Using config: ${INSTALL_CFG}"
        run_with_progress "Vivado Unattended Installation (expect 20-40 min)" "${VIVADO_OPT_DIR}" \
            "${INSTALLERS_DIR}/xsetup" -a XilinxEULA,3rdPartyEULA -b Install -c "${INSTALL_CFG}" || {
            echo "❌ Vivado installation failed. Check the logs above."
            echo "Continuing to shell..."
            exec "$@"
        }

    # Priority 2: Archive (.tar.gz or .tar — Xilinx ships both formats).
    # Uses the shared dictionary+size detector (RTL-P2.445) so dropping
    # a petalinux-*.run or Enclustra *.bsp alongside doesn't confuse us,
    # and the old two-pattern `ls` glob bug is gone.
    elif TAR_FILE=$(_find_vendor_installer "${INSTALLERS_DIR}" \
            "tar.gz tar" \
            "FPGAs_AdaptiveSoCs Xilinx_Unified Xilinx_Vivado Vivado Xilinx" \
            "petalinux logic-trace Quartus PetaLinux routewave bsp BSP Libero Radiant Questa Riviera" \
            5368709120); then
        case "${TAR_FILE}" in
            *.tar.gz) TAR_FLAGS="-xzf"; TAR_TEST_FLAGS="-tzf" ;;
            *.tar)    TAR_FLAGS="-xf";  TAR_TEST_FLAGS="-tf"  ;;
        esac
        echo "Found installer archive: ${TAR_FILE}"

        # Validate tar integrity before extracting
        echo "Verifying archive integrity..."
        if ! tar ${TAR_TEST_FLAGS} "${TAR_FILE}" > /dev/null 2>&1; then
            echo ""
            echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
            echo "❌  Installer archive appears corrupt or incomplete"
            echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
            echo ""
            echo "  File: ${TAR_FILE}"
            echo "  Size: $(du -h "${TAR_FILE}" | cut -f1)"
            echo ""
            echo "  Possible causes:"
            echo "    • Incomplete download — re-download from Xilinx"
            echo "    • WSL2 I/O issue — copy the file into the WSL filesystem:"
            echo "        cp /mnt/c/.../Vivado.tar ~/vivado_installers/"
            echo "        # Then set VIVADO_INSTALLER_PATH=~/vivado_installers"
            echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
            echo ""
            echo "Continuing to shell without Vivado..."
            exec "$@"
        fi
        echo "✅ Archive OK"

        TMP_EXTRACT="/home/$(whoami)/vivado_tmp_install"
        mkdir -p "${TMP_EXTRACT}"

        echo "Extracting ${TAR_FILE} to ${TMP_EXTRACT}..."
        TAR_SIZE=$(stat -c%s "${TAR_FILE}" 2>/dev/null || echo 0)
        if command -v pv > /dev/null 2>&1 && [ "${TAR_SIZE}" -gt 0 ]; then
            pv -p -t -e -r -s "${TAR_SIZE}" "${TAR_FILE}" | tar ${TAR_FLAGS} - -C "${TMP_EXTRACT}"
        else
            echo "(progress bar unavailable — showing checkpoints)"
            tar --checkpoint=1000 --checkpoint-action=dot ${TAR_FLAGS} "${TAR_FILE}" -C "${TMP_EXTRACT}"
            echo ""
        fi

        # Find xsetup inside extracted dir
        XSETUP=$(find "${TMP_EXTRACT}" -name "xsetup" -type f | head -n 1)
        if [ -n "${XSETUP}" ]; then
            INSTALL_CFG=$(_find_install_config)
            echo "Using config: ${INSTALL_CFG}"
            run_with_progress "Vivado Unattended Installation (expect 20-40 min)" "${VIVADO_OPT_DIR}" \
                "${XSETUP}" -a XilinxEULA,3rdPartyEULA -b Install -c "${INSTALL_CFG}" || {
                echo "❌ Vivado installation failed."
                echo "Continuing to shell..."
            }
        else
            echo "❌ xsetup not found inside extracted archive."
        fi

        echo "Cleaning up temporary installation files..."
        rm -rf "${TMP_EXTRACT}"

    else
        echo ""
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        echo "⚠️  No Vivado installer found!"
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        echo ""
        echo "  Looked in: ${INSTALLERS_DIR}/"
        echo "  Expected:  xsetup (extracted) or *.tar / *.tar.gz"
        echo ""
        echo "  Contents of ${INSTALLERS_DIR}/:"
        ls -la "${INSTALLERS_DIR}/" 2>/dev/null || echo "    (directory does not exist or is empty)"
        echo ""
        echo "  To fix this, set VIVADO_INSTALLER_PATH in your .env file:"
        echo ""
        echo "    # .env (in your project root)"
        echo "    VIVADO_INSTALLER_PATH=/mnt/c/Users/YourName/Downloads"
        echo ""
        echo "  ⚠️  Must be the DIRECTORY, not the .tar.gz file itself!"
        echo "  Then re-run: routertl docker shell vivado"
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        echo ""
        echo "Continuing to shell without Vivado..."
    fi

    # Source Vivado settings if available — search multiple paths because
    # the installer may ignore Destination and use its own default.
    SETTINGS=""
    for _base in "${VIVADO_OPT_DIR}" "/tools/Xilinx" "/opt/Xilinx"; do
        for _s in \
            "${_base}/${VIVADO_VERSION}/Vivado/settings64.sh" \
            "${_base}/Vivado/${VIVADO_VERSION}/settings64.sh"; do
            if [ -f "$_s" ]; then
                SETTINGS="$_s"
                break 2
            fi
        done
    done
    if [ -n "${SETTINGS}" ]; then
        echo "Sourcing Vivado settings from ${SETTINGS}..."
        # shellcheck source=/dev/null  # Path is dynamic by design
        source "${SETTINGS}"
    fi

    # P1.23: Verify installation actually succeeded before claiming completion
    if command -v vivado > /dev/null 2>&1; then
        echo ""
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        echo "✅ Vivado ${VIVADO_VERSION} installation complete"
        echo "   Path: $(command -v vivado)"
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        echo ""
    else
        echo ""
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        echo "⚠️  Vivado ${VIVADO_VERSION} is NOT available in the container."
        echo "   The installation did not complete successfully."
        echo "   Run 'rr doctor' inside the container for diagnostics."
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        echo ""
    fi

else
    echo "✅ Xilinx Vivado ${VIVADO_VERSION} is already installed."
fi

# ─── Unisim Compilation Smoke Test (P3.8) ────────────────────────────
# After installation, quickly validate that the unisim VHDL library
# is discoverable and compilable. Uses GHDL or NVC (whichever available).
# Try both path layouts for the unisim source directory.
UNISIM_SRC=""
for _base in "${VIVADO_OPT_DIR}" "/tools/Xilinx" "/opt/Xilinx"; do
    for _u in \
        "${_base}/${VIVADO_VERSION}/Vivado/data/vhdl/src/unisims" \
        "${_base}/Vivado/${VIVADO_VERSION}/data/vhdl/src/unisims"; do
        if [ -d "$_u" ]; then
            UNISIM_SRC="$_u"
            break 2
        fi
    done
done
if [ -z "${UNISIM_SRC}" ]; then
    echo "⚠️  Unisim source directory not found — skipping smoke test."
    echo "   Set XILINX_VIVADO to your Vivado installation path."
fi
if [ -d "${UNISIM_SRC}" ]; then
    UNISIM_VCOMP="${UNISIM_SRC}/unisim_VCOMP.vhd"
    if [ -f "${UNISIM_VCOMP}" ]; then
        echo ""
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        echo "🔬 Running unisim compilation smoke test..."
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

        SMOKE_PASS=false
        if command -v ghdl > /dev/null 2>&1; then
            echo "  Using GHDL..."
            TMPDIR_SMOKE=$(mktemp -d)
            if ghdl -a --std=08 --work=unisim --workdir="${TMPDIR_SMOKE}" "${UNISIM_VCOMP}" 2>/dev/null; then
                echo "  ✅ unisim_VCOMP.vhd compiled successfully with GHDL"
                SMOKE_PASS=true
            else
                echo "  ⚠️  GHDL compilation failed (non-critical — may need --std=93)"
            fi
            rm -rf "${TMPDIR_SMOKE}"
        elif command -v nvc > /dev/null 2>&1; then
            echo "  Using NVC..."
            TMPDIR_SMOKE=$(mktemp -d)
            if nvc --std=2008 --work=unisim -L "${TMPDIR_SMOKE}" -a "${UNISIM_VCOMP}" 2>/dev/null; then
                echo "  ✅ unisim_VCOMP.vhd compiled successfully with NVC"
                SMOKE_PASS=true
            else
                echo "  ⚠️  NVC compilation failed (non-critical)"
            fi
            rm -rf "${TMPDIR_SMOKE}"
        else
            echo "  ℹ️  Neither GHDL nor NVC available — skipping smoke test"
        fi

        if [ "$SMOKE_PASS" = true ]; then
            echo "  🎉 Unisim library validation PASSED"
        fi
        echo ""
    else
        echo "⚠️  unisim_VCOMP.vhd not found at ${UNISIM_VCOMP}"
    fi
else
    echo "ℹ️  Unisim source directory not found — skipping smoke test"
fi

# Execute the main command passed to the container (e.g., bash)
echo "Handing over to: $*"
echo ""
echo "LD_LIBRARY_PATH=${LD_LIBRARY_PATH:-<unset>}"
exec "$@"
