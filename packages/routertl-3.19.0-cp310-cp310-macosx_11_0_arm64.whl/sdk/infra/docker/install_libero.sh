#!/usr/bin/env bash
# install_libero.sh: Automated entrypoint for RouteRTL Libero container
# This script checks if Libero SoC is installed in the persistent volume.
# If not, it runs the unattended Microchip installer from the mounted directory.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/install_progress.sh"

LIBERO_OPT_DIR="/opt/microsemi"
INSTALLERS_DIR="/installers"
HOST_PATH="${LIBERO_INSTALLER_PATH_HOST:-${INSTALLERS_DIR}}"

echo "Checking Microchip Libero SoC installation in ${LIBERO_OPT_DIR}..."

# Ensure the persistent volume directory exists and is writable by the runner user
sudo mkdir -p "${LIBERO_OPT_DIR}" 2>/dev/null || true
sudo chown -R $(whoami):$(whoami) "${LIBERO_OPT_DIR}" 2>/dev/null || true

# Check for Libero binary in expected locations.
# Libero installs into versioned subdirectories:
#   /opt/microsemi/Libero_SoC_v2024.2/Libero/bin/libero
#   /opt/microsemi/Libero_SoC_vXX.X/Libero/bin/lin64/libero
if ! find "${LIBERO_OPT_DIR}" -maxdepth 5 -type f -name "libero" | grep -q .; then
    echo "Libero SoC not found. Looking for installer..."

    # ── Validate the /installers mount ────────────────────
    if [ -f "${INSTALLERS_DIR}" ]; then
        echo ""
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        echo "❌  LIBERO_INSTALLER_PATH points to a FILE, not a DIRECTORY"
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        echo ""
        echo "  It must point to the DIRECTORY containing the installer:"
        echo "    LIBERO_INSTALLER_PATH=/mnt/c/Users/YourName/Downloads  ← correct"
        echo "    LIBERO_INSTALLER_PATH=/path/to/Libero_SoC.bin          ← wrong"
        echo ""
        echo "  Fix your .env file and re-run: routertl docker shell libero"
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        echo ""
        echo "Continuing to shell without Libero..."
        exec "$@"
    fi

    # Look for installer: .bin files first, then .zip archives
    LIBERO_INSTALLER=""

    # Priority 1: Direct .bin installer (RTL-P2.445 shared detector).
    LIBERO_INSTALLER=$(_find_vendor_installer "${INSTALLERS_DIR}" \
        "bin" \
        "Libero_SoC Libero Microchip Microsemi" \
        "petalinux logic-trace Quartus Vivado Xilinx Radiant Questa Riviera bsp BSP" \
        104857600) || LIBERO_INSTALLER=""

    # Priority 2: .zip archive containing the .bin installer
    if [ -z "${LIBERO_INSTALLER}" ]; then
        LIBERO_ZIP=$(_find_vendor_installer "${INSTALLERS_DIR}" \
            "zip" \
            "Libero_SoC Libero Microchip Microsemi" \
            "petalinux logic-trace Quartus Vivado Xilinx Radiant Questa Riviera bsp BSP" \
            104857600) || LIBERO_ZIP=""
        if [ -n "${LIBERO_ZIP}" ]; then
            echo "Found zip file: $(basename "${LIBERO_ZIP}"). Extracting .bin installer..."
            TMP_EXTRACT="/home/$(whoami)/libero_tmp_install"
            mkdir -p "${TMP_EXTRACT}"
            unzip -q -o "${LIBERO_ZIP}" -d "${TMP_EXTRACT}"
            chmod +x "${TMP_EXTRACT}"/*.bin 2>/dev/null || true
            LIBERO_INSTALLER=$(_find_vendor_installer "${TMP_EXTRACT}" \
                "bin" "Libero" "" 0) || LIBERO_INSTALLER=""
        fi
    fi

    if [ -n "${LIBERO_INSTALLER}" ]; then
        echo "Found Libero installer: $(basename "${LIBERO_INSTALLER}")"
        # Ensure installer is executable. The mount is read-only but the host
        # file should already have +x. If not, copy to /tmp as a fallback.
        # Note: QIF installers (2025.2+) expect .7z component archives in the
        # same directory as the .bin, so we must NOT move the binary elsewhere.
        if [ ! -x "${LIBERO_INSTALLER}" ]; then
            echo "  Installer not executable — copying to writable location..."
            INSTALLER_DIR=$(dirname "${LIBERO_INSTALLER}")
            INSTALLER_NAME=$(basename "${LIBERO_INSTALLER}")
            mkdir -p /tmp/libero_install_dir
            # Copy everything (bin + .7z archives) so QIF finds them together
            cp "${INSTALLER_DIR}"/* /tmp/libero_install_dir/
            chmod +x /tmp/libero_install_dir/"${INSTALLER_NAME}"
            LIBERO_INSTALLER="/tmp/libero_install_dir/${INSTALLER_NAME}"
        fi

        echo "Starting headless installation (this may take 10-30 minutes)..."
        # Libero 2025.2+ uses Qt Installer Framework (QIF) instead of the legacy
        # InstallAnywhere engine. Detect which format and use the correct flags.
        # QIF: install --root <dir> --accept-licenses --confirm-command -p minimal
        # Legacy: --mode unattended --prefix <dir>
        INSTALL_OK=0
        if "${LIBERO_INSTALLER}" --help 2>&1 | grep -q "Qt Installer Framework"; then
            echo "  Detected Qt Installer Framework (2025.2+)"
            # QIF resolves .7z component archives relative to the binary's
            # directory. We must cd there so it finds them.
            INSTALLER_DIR=$(dirname "${LIBERO_INSTALLER}")
            INSTALLER_NAME=$(basename "${LIBERO_INSTALLER}")
            run_with_progress "Libero SoC Unattended Installation" "${LIBERO_OPT_DIR}" \
                bash -c "cd '${INSTALLER_DIR}' && './${INSTALLER_NAME}' install \
                --root '${LIBERO_OPT_DIR}' \
                --accept-licenses \
                --confirm-command \
                --default-answer \
                -p minimal" || INSTALL_OK=1
        else
            echo "  Detected legacy installer"
            run_with_progress "Libero SoC Unattended Installation" "${LIBERO_OPT_DIR}" \
                "${LIBERO_INSTALLER}" --mode unattended --prefix "${LIBERO_OPT_DIR}" || INSTALL_OK=1
        fi
        if [ "$INSTALL_OK" -ne 0 ]; then
            echo "❌ Libero installation failed. Check the logs above."
            echo "Continuing to shell..."
            exec "$@"
        fi

        # Deploy license if present alongside the installer
        if [ -f "${INSTALLERS_DIR}/license.dat" ]; then
            echo "Deploying license.dat..."
            mkdir -p "${LIBERO_OPT_DIR}/license"
            cp "${INSTALLERS_DIR}/license.dat" "${LIBERO_OPT_DIR}/license/license.dat"
            echo "✅ License deployed to ${LIBERO_OPT_DIR}/license/license.dat"
        else
            echo "⚠️  No license.dat found in ${HOST_PATH}."
            echo "   Place your node-locked license.dat in the installer directory,"
            echo "   or set LM_LICENSE_FILE in .env for a floating license server."
        fi

        # Cleanup temp extraction
        if [ -d "/home/$(whoami)/libero_tmp_install" ]; then
            rm -rf "/home/$(whoami)/libero_tmp_install"
        fi
    else
        echo ""
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        echo "⚠️  No Libero SoC installer found!"
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        echo ""
        echo "  Looked in: ${HOST_PATH}/"
        echo "  Expected:  *Libero_SoC*.bin or *Libero_SoC*.zip"
        echo ""
        echo "  Contents of ${INSTALLERS_DIR}/:"
        ls -la "${INSTALLERS_DIR}/" 2>/dev/null || echo "    (directory does not exist or is empty)"
        echo ""
        echo "  To fix this, set LIBERO_INSTALLER_PATH in your .env file:"
        echo ""
        echo "    # .env (in your project root)"
        echo "    LIBERO_INSTALLER_PATH=/mnt/c/Users/YourName/Downloads"
        echo ""
        echo "  ⚠️  Must be the DIRECTORY, not the .bin file itself!"
        echo "  Then re-run: routertl docker shell libero"
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        echo ""
        echo "Continuing to shell without Libero..."
    fi
else
    echo "✅ Microchip Libero SoC is already installed."
fi

# ── Handover ──────────────────────────────────────────────────
# Discover the actual Libero installation path dynamically.
# Libero installs into versioned subdirs:
#   /opt/microsemi/Libero_SoC_v2024.2/Libero/bin/
LIBERO_HOME=$(find "${LIBERO_OPT_DIR}" -maxdepth 3 -type d -name "Libero" | sort -r | head -n 1)

if [ -n "${LIBERO_HOME}" ]; then
    echo "✅ Libero root discovered at: ${LIBERO_HOME}"
    LIBERO_BIN_DIR="${LIBERO_HOME}/bin"
    if [ -d "${LIBERO_HOME}/bin/lin64" ]; then
        LIBERO_BIN_DIR="${LIBERO_HOME}/bin/lin64"
    fi
else
    LIBERO_HOME="${LIBERO_OPT_DIR}"
    LIBERO_BIN_DIR="${LIBERO_OPT_DIR}"
fi

# Set license path: user-provided > deployed > default
LICENSE_PATH="${LM_LICENSE_FILE:-}"
if [ -z "${LICENSE_PATH}" ] && [ -f "${LIBERO_OPT_DIR}/license/license.dat" ]; then
    LICENSE_PATH="${LIBERO_OPT_DIR}/license/license.dat"
fi

echo ""
echo "Active simulator: nvc (default)"
echo "Handing over to: $*"

exec su -s /bin/bash runner -c '
  export PATH="'"${LIBERO_BIN_DIR}"':/usr/local/bin:/usr/bin:/bin:$PATH"
  export LM_LICENSE_FILE="'"${LICENSE_PATH}"'"
  export LEONARDOSPEC="'"${LIBERO_HOME}"'"
  cd /home/runner/work
  exec "$@"' -- "$@"
