#!/usr/bin/env bash
# install_riviera.sh: Automated entrypoint for RouteRTL Riviera container
# This script checks if Riviera is installed in the persistent volume.
# If not, it natively executes the unattended installer from the mounted installers directory.

set -euo pipefail

# Source the shared progress indicator
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/install_progress.sh"

# Define target installation directories on the persistent volume
RIVIERA_OPT_DIR="/opt/riviera"
INSTALLERS_DIR="/installers"

echo "Checking Riviera installation in ${RIVIERA_OPT_DIR}..."

# Ensure the persistent volume directory exists and is writable by the runner user
mkdir -p "${RIVIERA_OPT_DIR}"
chown -R runner:runner "${RIVIERA_OPT_DIR}"

# -------------------------------------------------------------
# 1. Riviera-PRO Installation
# -------------------------------------------------------------
if [ ! -d "${RIVIERA_OPT_DIR}/bin" ]; then
    echo "Riviera-PRO not found. Looking for installer..."

    # ── Validate the /installers mount ──────────────────────────
    if [ -f "${INSTALLERS_DIR}" ]; then
        echo ""
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        echo "❌  RIVIERA_INSTALLER_PATH points to a FILE, not a DIRECTORY"
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        echo ""
        echo "  It must point to the DIRECTORY containing the installer:"
        echo "    RIVIERA_INSTALLER_PATH=/mnt/c/Users/YourName/Downloads  ← correct"
        echo "    RIVIERA_INSTALLER_PATH=/path/to/Riviera-PRO.bin         ← wrong"
        echo ""
        echo "  Fix your .env file and re-run: routertl docker shell riviera"
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        echo ""
        echo "Continuing to shell without Riviera..."
        exec su -s /bin/bash runner -c "export PATH='/opt/riviera/bin:/usr/local/bin:$PATH' SIM=riviera; cd /home/runner/work && $*"
    fi

    # RTL-P2.445: shared detector — tries both .bin and .run in one call.
    RIVIERA_INSTALLER=""
    for _ext in "bin" "run"; do
        if RIVIERA_INSTALLER=$(_find_vendor_installer "${INSTALLERS_DIR}" \
                "$_ext" \
                "Riviera-PRO Riviera Aldec" \
                "petalinux logic-trace Quartus Vivado Xilinx Libero Radiant Questa bsp BSP" \
                52428800); then
            break
        fi
        RIVIERA_INSTALLER=""
    done
    if [ -n "${RIVIERA_INSTALLER}" ]; then
        echo "Found Riviera installer: ${RIVIERA_INSTALLER}"
        echo "Running unattended Riviera installation..."

        # Aldec .run installers are native binaries — ensure execute permission
        chmod +x "${RIVIERA_INSTALLER}"

        # Typical Aldec silent install args
        INSTALL_DIR="${RIVIERA_OPT_DIR}"
        run_with_progress "Riviera-PRO Unattended Installation" "${INSTALL_DIR}" \
            "${RIVIERA_INSTALLER}" --mode unattended --unattendedmodeui none --prefix "${INSTALL_DIR}" || true
    else
        echo ""
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        echo "⚠️  No Riviera installer found!"
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        echo ""
        echo "  Looked in: ${INSTALLERS_DIR}/"
        echo "  Expected:  Riviera-PRO*.bin or Riviera-PRO*.run"
        echo ""
        echo "  Contents of ${INSTALLERS_DIR}/:"
        ls -la "${INSTALLERS_DIR}/" 2>/dev/null || echo "    (directory does not exist or is empty)"
        echo ""
        echo "  To fix this, set RIVIERA_INSTALLER_PATH in your .env file:"
        echo ""
        echo "    # .env (in your project root)"
        echo "    RIVIERA_INSTALLER_PATH=/mnt/c/Users/YourName/Downloads"
        echo ""
        echo "  ⚠️  Must be the DIRECTORY, not the .bin file itself!"
        echo "  Then re-run: routertl docker shell riviera"
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        echo ""
        echo "Continuing to shell without Riviera..."
    fi
else
    echo "✅ Riviera-PRO is already installed."
fi
# -------------------------------------------------------------
# 2. Volume Version Stamp
# -------------------------------------------------------------
# Stamp the volume on fresh installs so future image rebuilds can
# detect a stale volume from an incompatible image generation.
VOLUME_STAMP="${RIVIERA_OPT_DIR}/.routertl_image_id"
CURRENT_IMAGE_ID="$(cat /etc/hostname 2>/dev/null || echo unknown)"
if [ -d "${RIVIERA_OPT_DIR}/bin" ]; then
    if [ -f "${VOLUME_STAMP}" ]; then
        PREV_ID="$(cat "${VOLUME_STAMP}")"
        if [ "${PREV_ID}" != "${CURRENT_IMAGE_ID}" ]; then
            echo ""
            echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
            echo "⚠️  Riviera volume was created by a different image"
            echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
            echo ""
            echo "  Previous: ${PREV_ID}"
            echo "  Current:  ${CURRENT_IMAGE_ID}"
            echo ""
            echo "  If Riviera fails, remove the stale volume:"
            echo "    routertl docker uninstall riviera"
            echo "  Then re-run: routertl docker shell riviera"
            echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
            echo ""
        fi
    fi
    echo "${CURRENT_IMAGE_ID}" > "${VOLUME_STAMP}" 2>/dev/null || true
fi

# -------------------------------------------------------------
# 3. Ensure CLI aliases exist
# -------------------------------------------------------------
# Create rr symlink if missing (covers images built before it was
# added to Dockerfile.sim, or system PATH reset by su/PAM).
if command -v routertl >/dev/null 2>&1 && ! command -v rr >/dev/null 2>&1; then
    ROUTERTL_PATH="$(command -v routertl)"
    ln -sf "${ROUTERTL_PATH}" "$(dirname "${ROUTERTL_PATH}")/rr" 2>/dev/null || true
fi

# Execute the main command passed to the container (e.g., bash)
echo "Handing over to: $*"
# Drop privileges to 'runner' for simulation.
# IMPORTANT: env vars MUST be set inside the -c string because
# 'su' goes through PAM which resets the environment.
# NOTE: $PATH here expands to ROOT's PATH at parse time — this is
# intentional!  PAM resets runner's PATH to empty, so we bake in the
# full system PATH (/usr/bin, /bin, etc.) from the root context.
# NOTE: do NOT redirect stderr (2>/dev/null) — bash writes PS1 to stderr!
exec su -s /bin/bash runner -c "
  export PATH='/opt/riviera/bin:/usr/local/bin:$PATH'
  export SIM=riviera
  cd /home/runner/work
  echo \"🔧 Active simulator: \$SIM\"
  exec $*"
