#!/usr/bin/env bash
# add_patch_quartus.sh: Apply Altera hotfix patches to an existing Quartus volume
#
# Quartus patches are delivered as ZIP files containing:
#   - quartus-<ver>-<patch>-linux.run   (self-extracting installer)
#   - quartus-<ver>-<patch>-readme.txt  (release notes)
#   - quartus-<ver>-<patch>-windows.exe (Windows version, ignored)
#
# The .run file supports: --mode unattended --accept_eula 1 --installdir <dir>
#
# Usage (inside container):
#   bash /home/runner/add_patch_quartus.sh
#
# Triggered by: rr docker add-patch quartus

set -euo pipefail

QUARTUS_OPT_DIR="/opt/altera"
INSTALLERS_DIR="/installers"
HOST_PATH="${QUARTUS_INSTALLER_PATH_HOST:-${INSTALLERS_DIR}}"
TMP_DIR="/tmp/quartus_patches"

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "🩹  RouteRTL — Quartus Patch Installer"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# ── Step 1: Validate existing Quartus installation ──────────────
if ! find "${QUARTUS_OPT_DIR}" -maxdepth 3 -type d -name "quartus" | grep -q .; then
    echo ""
    echo "❌  Quartus is not installed in ${QUARTUS_OPT_DIR}"
    echo "   Run 'rr docker shell quartus' first to install Quartus."
    echo ""
    exit 1
fi

# Get Quartus version for display
QUARTUS_SH=$(find "${QUARTUS_OPT_DIR}" -maxdepth 4 -name "quartus_sh" -type f -print -quit 2>/dev/null || true)
if [ -n "${QUARTUS_SH}" ]; then
    QUARTUS_VER=$("${QUARTUS_SH}" --version 2>&1 | grep -oP 'Version \K[\d.]+' || echo "unknown")
    echo ""
    echo "  ✅ Quartus ${QUARTUS_VER} detected in ${QUARTUS_OPT_DIR}"
fi

# ── Step 2: Scan for patch ZIP files ───────────────────────────
# Patch ZIPs contain .run files. We look for any .zip that contains
# a *-linux.run file (distinguishes patches from device .qdz files).
echo ""
echo "  Scanning ${HOST_PATH} for patch files..."
echo ""

mapfile -t ZIP_FILES < <(find "${INSTALLERS_DIR}" -maxdepth 1 -name '*.zip' -type f 2>/dev/null | sort)

if [ ${#ZIP_FILES[@]} -eq 0 ]; then
    echo "┌──────────────────────────────────────────────────────────┐"
    echo "│  ⚠️  No .zip patch files found                         │"
    echo "├──────────────────────────────────────────────────────────┤"
    echo "│  Download patches from Intel FPGA Download Center       │"
    echo "│  and place them in:                                     │"
    printf "│  %-54s│\n" "${HOST_PATH}"
    echo "│  Then re-run:   rr docker add-patch quartus             │"
    echo "└──────────────────────────────────────────────────────────┘"
    echo ""
    exit 0
fi

# Filter: only ZIPs that contain a *-linux.run file (actual patches)
PATCH_ZIPS=()
for zf in "${ZIP_FILES[@]}"; do
    if python3 -c "import zipfile; z=zipfile.ZipFile('$zf'); exit(0 if any(n.endswith('-linux.run') for n in z.namelist()) else 1)" 2>/dev/null; then
        PATCH_ZIPS+=("$zf")
    fi
done

if [ ${#PATCH_ZIPS[@]} -eq 0 ]; then
    echo "  ⚠️  Found ${#ZIP_FILES[@]} .zip file(s) but none contain a Quartus patch (.run)."
    echo "  [Quartus patches contain a *-linux.run file inside the ZIP]"
    echo ""
    exit 0
fi

echo "┌──────────────────────────────────────────────────────────┐"
echo "│  🩹  Quartus Patches Found                               │"
echo "├──────────────────────────────────────────────────────────┤"
for zf in "${PATCH_ZIPS[@]}"; do
    zname=$(basename "$zf")
    zsize=$(du -h "$zf" 2>/dev/null | cut -f1)
    # Display patch info (version from readme, if available)
    python3 -c "import zipfile; z=zipfile.ZipFile('$zf'); [print(z.read(n).decode().split(chr(10))[0]) for n in z.namelist() if n.endswith('-readme.txt')]" 2>/dev/null || true
    printf "│  🩹 %-44s %6s │\n" "$zname" "$zsize"
done
echo "└──────────────────────────────────────────────────────────┘"
echo ""

# ── Step 3: Extract and apply patches ──────────────────────────
mkdir -p "${TMP_DIR}"
APPLIED=0
FAILED=0

for zf in "${PATCH_ZIPS[@]}"; do
    zname=$(basename "$zf")
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo "  🩹 Applying: ${zname}"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

    # Extract the .run file
    PATCH_DIR="${TMP_DIR}/$(basename "$zf" .zip)"
    mkdir -p "${PATCH_DIR}"
    python3 -c "import zipfile; zipfile.ZipFile('$zf').extractall('${PATCH_DIR}')"

    # Find the .run file
    RUN_FILE=$(find "${PATCH_DIR}" -name '*-linux.run' -type f -print -quit 2>/dev/null)
    if [ -z "${RUN_FILE}" ]; then
        echo "  ❌ No .run file found inside ${zname}"
        FAILED=$((FAILED + 1))
        continue
    fi

    chmod +x "${RUN_FILE}"
    echo "  Installer: $(basename "${RUN_FILE}")"

    # Show patch version info
    "${RUN_FILE}" --version 2>&1 | head -1 || true
    echo ""

    # Show readme if available
    README=$(find "${PATCH_DIR}" -name '*-readme.txt' -type f -print -quit 2>/dev/null)
    if [ -n "${README}" ]; then
        echo "  📄 Patch notes (first 5 lines):"
        head -5 "${README}" | sed 's/^/     /'
        echo ""
    fi

    # Apply the patch
    echo "  ⏳ Running patch installer (unattended)..."
    if "${RUN_FILE}" --mode unattended --accept_eula 1 --installdir "${QUARTUS_OPT_DIR}"; then
        echo "  ✅ Patch applied successfully"
        APPLIED=$((APPLIED + 1))
    else
        echo "  ❌ Patch installation failed (exit code: $?)"
        FAILED=$((FAILED + 1))
    fi
    echo ""
done

# ── Step 4: Clean up ──────────────────────────────────────────
rm -rf "${TMP_DIR}"

# ── Step 5: Summary ──────────────────────────────────────────
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  📊 Summary: ${APPLIED} applied, ${FAILED} failed"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# Show updated version
if [ -n "${QUARTUS_SH}" ]; then
    echo ""
    NEW_VER=$("${QUARTUS_SH}" --version 2>&1 || true)
    echo "  📋 Quartus version after patching:"
    echo "$NEW_VER" | sed 's/^/     /'
fi
echo ""
