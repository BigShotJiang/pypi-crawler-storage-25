#!/usr/bin/env bash
# ──────────────────────────────────────────────────────────────
# CLI Smoke Test — runs inside the routertl-cli-test container
# ──────────────────────────────────────────────────────────────
# Validates the full "new user" experience:
#   1. Clone SDK as submodule
#   2. Create .venv + pip install -e (also installs pyyaml etc.)
#   3. Initialize project (needs pyyaml from venv)
#   4. Verify every CLI entry point works
#   5. Verify branding + shortcuts
#   6. Verify Makefile integration
#
# Exit code: 0 = all checks passed, 1 = failure
# ──────────────────────────────────────────────────────────────
set -euo pipefail

SDK_MOUNT="/sdk"
PROJECT_DIR="/home/dev/test_project"
PASS=0
FAIL=0
ERRORS=""

# ── Helpers ──────────────────────────────────────────────────

pass() { PASS=$((PASS + 1)); echo "  ✅ $1"; }
fail() { FAIL=$((FAIL + 1)); ERRORS="${ERRORS}\n  ❌ $1"; echo "  ❌ $1"; }

check_exit() {
    local desc="$1"; shift
    if "$@" > /tmp/smoke_out.txt 2>&1; then
        pass "$desc"
    else
        fail "$desc (exit $?)"
        tail -5 /tmp/smoke_out.txt | sed 's/^/     /'
    fi
}

check_no_traceback() {
    local desc="$1"; shift
    if "$@" > /tmp/smoke_out.txt 2>&1; then
        if grep -q "Traceback (most recent call last)" /tmp/smoke_out.txt; then
            fail "$desc (traceback in output)"
            grep -A3 "Traceback" /tmp/smoke_out.txt | head -10 | sed 's/^/     /'
        else
            pass "$desc"
        fi
    else
        # Non-zero exit is OK for some commands (e.g. missing project.yml)
        # but tracebacks are never OK
        if grep -q "Traceback (most recent call last)" /tmp/smoke_out.txt; then
            fail "$desc (traceback + exit $?)"
            grep -A3 "Traceback" /tmp/smoke_out.txt | head -10 | sed 's/^/     /'
        else
            pass "$desc (exit non-zero but no traceback)"
        fi
    fi
}

echo "╔══════════════════════════════════════════════════════════╗"
echo "║        RouteRTL CLI Smoke Test (Docker)                 ║"
echo "╚══════════════════════════════════════════════════════════╝"
echo ""

# ── Phase 1: Project Scaffold ────────────────────────────────
echo "── Phase 1: Project Scaffold ──"

mkdir -p "$PROJECT_DIR"
cd "$PROJECT_DIR"

# Init git repo
git init -q
git config user.email "smoke@test"
git config user.name "Smoke Test"

# Copy SDK from bind mount (git submodule add doesn't work with bind-mounted
# submodule repos — the host .git/modules path isn't accessible).
# We only need the SDK files, not actual submodule mechanics.
mkdir -p vendor
check_exit "copy SDK to vendor/routertl" cp -r "$SDK_MOUNT" vendor/routertl

echo ""

# ── Phase 2: Virtual Environment + pip install ────────────────
echo "── Phase 2: Virtual Environment ──"

check_exit "python3 -m venv" python3 -m venv .venv

# Activate
source .venv/bin/activate

check_exit "pip install -e vendor/routertl" \
    pip install --quiet -e vendor/routertl

# Verify entry point exists
if command -v routertl > /dev/null 2>&1; then
    pass "routertl entry point found"
else
    fail "routertl entry point NOT found in PATH"
fi

echo ""

# ── Phase 3: Initialize Project (needs pyyaml from venv) ─────
echo "── Phase 3: Project Initialization ──"

check_exit "init_project.py" \
    python3 vendor/routertl/sdk/engine/init_project.py \
        --name smoke_proj --top smoke_top \
        --vendor xilinx --part xc7z020clg400-1 \
        --non-interactive --no-venv

# Verify project files
for f in project.yml Makefile VERSION; do
    if [ -f "$f" ]; then pass "File exists: $f"
    else fail "File missing: $f"; fi
done

echo ""

# ── Phase 4: CLI Commands ─────────────────────────────────────
echo "── Phase 4: CLI Commands ──"

# These should all exit 0 with no tracebacks
check_no_traceback "routertl --help"        routertl --help
check_no_traceback "routertl version"       routertl version
check_no_traceback "routertl status"        routertl status
check_no_traceback "routertl doctor"        routertl doctor
check_no_traceback "routertl sources"       routertl sources
check_no_traceback "routertl info"          routertl info
check_no_traceback "routertl report"        routertl report
check_no_traceback "routertl docker --help" routertl docker --help
check_no_traceback "routertl workspace --help" routertl workspace --help
check_no_traceback "routertl sim --help"    routertl sim --help
check_no_traceback "routertl linux --help"  routertl linux --help
check_no_traceback "routertl completion bash" routertl completion bash

echo ""

# ── Phase 5: Trailing help interceptor ────────────────────────
echo "── Phase 5: Trailing help ──"

check_no_traceback "routertl docker help"     routertl docker help
check_no_traceback "routertl workspace help"  routertl workspace help

echo ""

# ── Phase 6: Workspace rebrand ────────────────────────────────
echo "── Phase 6: Branding & Shortcuts ──"

check_no_traceback "workspace rebrand" routertl workspace rebrand

if command -v rr > /dev/null 2>&1; then
    pass "rr shortcut created"
    check_no_traceback "rr status" rr status
else
    fail "rr shortcut NOT found after rebrand"
fi

echo ""

# ── Phase 7: Makefile integration ─────────────────────────────
echo "── Phase 7: Makefile Integration ──"

check_exit "make help" make help
check_no_traceback "make sources" make sources

echo ""

# ── Phase 8: Venv repair recovery ─────────────────────────────
echo "── Phase 8: Venv Repair Recovery ──"

# Corrupt the venv by removing the Python binary
rm -f .venv/bin/python3
echo "  (corrupted .venv/bin/python3)"

# Verify routertl is now broken
if routertl --help > /dev/null 2>&1; then
    fail "routertl should be broken after corruption"
else
    pass "routertl correctly broken after corruption"
fi

# Run repair script (copy from /sdk mount since submodule clone may not have it)
cp /sdk/sdk/scripts/repair_venv.sh vendor/routertl/sdk/scripts/repair_venv.sh 2>/dev/null || true
check_exit "repair_venv.sh" \
    bash vendor/routertl/sdk/scripts/repair_venv.sh

# Re-activate the repaired venv
source .venv/bin/activate

# Verify routertl works again
check_no_traceback "routertl --help (post-repair)" routertl --help
check_no_traceback "rr status (post-repair)" rr status

echo ""

# ── Summary ───────────────────────────────────────────────────
TOTAL=$((PASS + FAIL))
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  TOTAL:  $TOTAL checks"
echo "  PASSED: $PASS"
echo "  FAILED: $FAIL"
if [ "$FAIL" -gt 0 ]; then
    echo ""
    echo "  Failures:"
    echo -e "$ERRORS"
    echo ""
fi
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

exit "$FAIL"
