#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Check that docs/ and docs-site/ copies haven't drifted too far apart.

Usage:
    python sdk/infra/docs/check_doc_sync.py

Compares known documentation pairs between docs/ (source of truth) and
docs-site/ (MkDocs copy).  Reports significant content drift — ignoring
expected differences like admonition syntax (> [!TIP] vs !!! tip) and
link format (relative .md vs GitHub URLs).

Exit code 0 if drift is within tolerance, 1 if significant drift detected.
"""
import difflib
import re
import sys
from pathlib import Path

# Known doc pairs: (source, mkdocs_copy)
PAIRS = [
    ("docs/reference/SDK_USER_GUIDE.md", "docs-site/guide/sdk-user-guide.md"),
    ("docs/guides/COCOTB_QUICKSTART.md", "docs-site/guide/cocotb-quickstart.md"),
    ("docs/guides/FIRST_STEPS_TUTORIAL.md", "docs-site/guide/first-steps.md"),
    ("docs/guides/PRE_COMMIT_GUIDE.md", "docs-site/guide/pre-commit-guide.md"),
    ("docs/reference/PROJECT_YML_REFERENCE.md", "docs-site/reference/project-yml.md"),
    ("docs/reference/TROUBLESHOOTING.md", "docs-site/guide/troubleshooting.md"),
]

# Lines matching these patterns are expected to differ
IGNORE_PATTERNS = [
    re.compile(r"^>\s*\[!(NOTE|TIP|WARNING|CAUTION|IMPORTANT)\]"),  # GFM alerts
    re.compile(r"^!!!\s+(note|tip|warning|caution|important)"),      # MkDocs admonitions
    re.compile(r"https://github\.com/djmazure/routertl/blob/main/"),  # GitHub URLs
]

# Drift tolerance: max % of differing content lines before flagging
DRIFT_THRESHOLD = 5.0


def normalize_line(line: str) -> str:
    """Strip expected formatting differences for comparison."""
    s = line.strip()
    # Collapse admonition syntax to a common form
    s = re.sub(r"^>\s*\[!(NOTE|TIP|WARNING|CAUTION|IMPORTANT)\]", r"ADMONITION_\1", s)
    s = re.sub(r"^!!!\s+(note|tip|warning|caution|important)", lambda m: f"ADMONITION_{m.group(1).upper()}", s)
    # Strip GitHub base URL from links
    s = s.replace("https://github.com/djmazure/routertl/blob/main/", "")
    return s


def check_pair(src: Path, dst: Path) -> tuple[float, int]:
    """Return (drift_pct, total_lines) for a doc pair."""
    if not src.exists() or not dst.exists():
        return 100.0, 0

    src_lines = [normalize_line(l) for l in src.read_text().splitlines()]
    dst_lines = [normalize_line(l) for l in dst.read_text().splitlines()]

    matcher = difflib.SequenceMatcher(None, src_lines, dst_lines)
    ratio = matcher.ratio()
    drift = (1.0 - ratio) * 100
    return drift, max(len(src_lines), len(dst_lines))


def main() -> int:
    root = Path(__file__).resolve().parent.parent.parent
    issues = []

    print("📋 Documentation Sync Check")
    print("=" * 60)

    for src_rel, dst_rel in PAIRS:
        src = root / src_rel
        dst = root / dst_rel
        drift, total = check_pair(src, dst)

        if not src.exists():
            print(f"  ⚠️  {src_rel} — source missing")
            continue
        if not dst.exists():
            print(f"  ⚠️  {dst_rel} — MkDocs copy missing")
            continue

        status = "✅" if drift <= DRIFT_THRESHOLD else "❌"
        print(f"  {status} {src_rel}")
        print(f"       ↔ {dst_rel}  ({drift:.1f}% drift, {total} lines)")

        if drift > DRIFT_THRESHOLD:
            issues.append((src_rel, dst_rel, drift))

    print("=" * 60)
    if issues:
        print(f"\n❌ {len(issues)} doc pair(s) have drifted beyond {DRIFT_THRESHOLD}% threshold:")
        for src, dst, drift in issues:
            print(f"   • {src} ↔ {dst} ({drift:.1f}%)")
        print("\n   Run: diff <source> <mkdocs_copy> to see what changed.")
        return 1
    else:
        print("\n✅ All doc pairs are in sync (within tolerance).")
        return 0


if __name__ == "__main__":
    sys.exit(main())
