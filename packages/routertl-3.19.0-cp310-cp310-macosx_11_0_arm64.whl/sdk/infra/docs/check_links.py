#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

import argparse
import os
import re
import sys
from pathlib import Path


def check_links(docs_dir, exclude_dirs=None):
    """Scan markdown files for broken internal links."""
    if exclude_dirs is None:
        exclude_dirs = []

    docs_path = Path(docs_dir)
    if not docs_path.exists():
        print(f"⚠️ Docs directory '{docs_dir}' not found.")
        return 0

    errors = []
    # Relative to project root (parent of sdk/)
    sdk_root = Path(__file__).parent.parent.parent

    skipped_prefixes = ("http", "#", "mailto", "file://")

    for root, dirs, files in os.walk(docs_path):
        # Handle exclusions
        rel_root = os.path.relpath(root, docs_path)
        if any(rel_root.startswith(ex) for ex in exclude_dirs):
            continue

        for f in files:
            if not f.endswith(".md"):
                continue

            f_path = Path(root) / f
            with open(f_path, "r", encoding="utf-8") as fp:
                content = fp.read()

                # Simple markdown link regex [text](link)
                # This doesn't handle all corner cases but covers standard relative links
                links = re.findall(r"\[[^\]]*\]\(([^)]+)\)", content)

                for i, link in enumerate(links):
                    # Skip external, anchors, mailto, and absolute file:// (historical)
                    if link.startswith(skipped_prefixes):
                        continue

                    # Strip anchor from link
                    clean_link = link.split("#")[0]
                    if not clean_link:
                        continue

                    # Resolve relative to the file's directory
                    target = (f_path.parent / clean_link).resolve()

                    if not target.exists():
                        # Determine line number (expensive but better for reporting)
                        # We just find the line for the first occurrence of this specific link string
                        # Not perfect if same link appears multiple times but good enough
                        line_num = 1
                        for ln, line in enumerate(content.splitlines(), 1):
                            if link in line:
                                line_num = ln
                                break

                        errors.append(f"{f_path}:{line_num}: BROKEN LINK -> {link}")

    if errors:
        print(f"❌ Found {len(errors)} broken links in {docs_dir}:")
        for err in errors:
            print(f"  {err}")
        return 1

    print(f"✅ All internal links in '{docs_dir}' resolve correctly.")
    return 0


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Check for broken internal markdown links.")
    parser.add_argument("--dir", default="docs", help="Docs directory to scan")
    parser.add_argument("--exclude", action="append", help="Relative directories to exclude")

    args = parser.parse_args()

    # Run from repo root
    sys.exit(check_links(args.dir, args.exclude))
