#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Generate CI test lists from project.yml cicd.tests.

Usage:
    python sdk/infra/docs/gen_ci_tests.py [--format github|bitbucket|both]

Reads the canonical test list from project.yml under `cicd.tests` and
outputs CI-ready test run commands. Use this to keep CI configs in sync
with a single source of truth.
"""
import argparse
import sys
from pathlib import Path

import yaml


def load_tests(project_yml: Path) -> list[str]:
    """Load the test list from project.yml cicd.tests or fallback to hooks."""
    with open(project_yml) as f:
        config = yaml.safe_load(f)

    tests = config.get("cicd", {}).get("tests", [])

    if not tests or tests == "inherit":
        tests = config.get("hooks", {}).get("pre_commit", {}).get("tests", [])
        if tests:
            print("ℹ️  Inheriting test list from hooks.pre_commit.tests", file=sys.stderr)

    if not tests:
        print("⚠️  No tests found in project.yml", file=sys.stderr)
        return []

    if tests == "auto":
        print("ℹ️  Resolving 'auto' tests via project_manager...", file=sys.stderr)
        root = project_yml.parent

        try:
            from routertl_core.project_manager import generate_hook_config
            out = generate_hook_config(config)
            for line in out.splitlines():
                if line.startswith("HOOK_TESTS="):
                    val = line.split("=", 1)[1].strip('"')
                    tests = val.split() if val else []
                    break
            else:
                tests = []
        except ImportError as e:
            print(f"❌ Failed to import project_manager: {e}", file=sys.stderr)
            tests = []

    return tests


def gen_github_steps(tests: list[str]) -> str:
    """Generate GitHub Actions run commands."""
    lines = []
    # Group by category
    unit_tests = [t for t in tests if "units." in t]
    driver_tests = [t for t in tests if "drivers." in t]
    other_tests = [t for t in tests if "units." not in t and "drivers." not in t]

    if unit_tests:
        lines.append("      # ── Unit tests (auto-generated from project.yml) ──")
        lines.append("      - name: Run unit tests (NVC)")
        lines.append("        env:")
        lines.append("          SIM: nvc")
        lines.append("        run: |")
        for t in unit_tests:
            lines.append(f"          make sim MODULE={t}")

    if driver_tests:
        lines.append("")
        lines.append("      # ── Driver tests (auto-generated from project.yml) ──")
        lines.append("      - name: Run driver tests (NVC)")
        lines.append("        env:")
        lines.append("          SIM: nvc")
        lines.append("        run: |")
        for t in driver_tests:
            lines.append(f"          make sim MODULE={t}")

    if other_tests:
        lines.append("")
        lines.append("      # ── Other tests (auto-generated from project.yml) ──")
        lines.append("      - name: Run other tests (NVC)")
        lines.append("        env:")
        lines.append("          SIM: nvc")
        lines.append("        run: |")
        for t in other_tests:
            lines.append(f"          make sim MODULE={t}")

    return "\n".join(lines)


def gen_bitbucket_steps(tests: list[str]) -> str:
    """Generate Bitbucket Pipelines run commands."""
    lines = []
    unit_tests = [t for t in tests if "units." in t]
    driver_tests = [t for t in tests if "drivers." in t]

    if unit_tests:
        lines.append("          # ── Unit tests (auto-generated from project.yml) ──")
        for t in unit_tests:
            lines.append(f"          - make sim MODULE={t}")

    if driver_tests:
        lines.append("          # ── Driver tests (auto-generated from project.yml) ──")
        for t in driver_tests:
            lines.append(f"          - make sim MODULE={t}")

    return "\n".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser(description="Generate CI test lists from project.yml")
    parser.add_argument("--format", choices=["github", "bitbucket", "both"], default="both")
    parser.add_argument("--project", default="project.yml", help="Path to project.yml")
    args = parser.parse_args()

    root = Path(__file__).resolve().parent.parent.parent
    project_yml = root / args.project
    if not project_yml.exists():
        print(f"❌ {project_yml} not found", file=sys.stderr)
        return 1

    tests = load_tests(project_yml)
    if not tests:
        return 1

    print(f"# Auto-generated from {args.project} — {len(tests)} tests")
    print(f"# Source of truth: cicd.tests in {args.project}")
    print()

    if args.format in ("github", "both"):
        print("# ── GitHub Actions ──────────────────────────────────────")
        print(gen_github_steps(tests))
        print()

    if args.format in ("bitbucket", "both"):
        print("# ── Bitbucket Pipelines ─────────────────────────────────")
        print(gen_bitbucket_steps(tests))
        print()

    return 0


if __name__ == "__main__":
    sys.exit(main())
