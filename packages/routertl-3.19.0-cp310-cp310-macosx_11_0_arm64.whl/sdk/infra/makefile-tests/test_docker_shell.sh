#!/usr/bin/env bash
# test_docker_shell.sh — Docker integration test for entrypoint scripts
#
# Runs the ACTUAL install_riviera.sh inside a minimal ubuntu:22.04 container
# with no Riviera installer.  This exercises the real handover code path
# (su -c, PATH bake-in, SIM, rr alias) without any commercial EDA tools.
#
# Strategy: Instead of "bash" as CMD, we pass a "probe" script that dumps
# the environment from inside the runner shell.  This guarantees we are
# testing the REAL su -c handover, not a mock.
#
# Would have caught the $PATH escape regression (e2b5d83) where \$PATH
# expanded to empty runner PATH and 'exec bash' failed.
#
# Usage: ./test_docker_shell.sh
# Requires: docker

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DOCKER_DIR="${SCRIPT_DIR}/../docker"
PASS=0
FAIL=0
ERRORS=""

pass() { echo "  ✅ $1"; PASS=$((PASS+1)); }
fail() { echo "  ❌ $1"; FAIL=$((FAIL+1)); ERRORS="${ERRORS}\n  - $1"; }

# Common docker run prefix (bind-mount entrypoint scripts)
run_riviera_test() {
    docker run --rm \
        -v "${DOCKER_DIR}/install_riviera.sh:/home/runner/install_riviera.sh:ro" \
        -v "${DOCKER_DIR}/install_progress.sh:/home/runner/install_progress.sh:ro" \
        ubuntu:22.04 bash -c "$1" 2>&1
}

echo "═══════════════════════════════════════════════════════════"
echo "  Docker Entrypoint Integration Test"
echo "  (runs real install_riviera.sh — no Riviera needed)"
echo "═══════════════════════════════════════════════════════════"
echo ""

# ── Preflight ──
for f in install_riviera.sh install_progress.sh; do
    if [ ! -f "${DOCKER_DIR}/$f" ]; then
        echo "❌ Required: ${DOCKER_DIR}/$f"
        exit 1
    fi
done

# ── Test 1: Full entrypoint handover ─────────────────────────
echo "── Test 1: Real install_riviera.sh handover ──"

RESULT=$(run_riviera_test '
    useradd -m -s /bin/bash runner 2>/dev/null || true
    mkdir -p /home/runner/work

    # Mimic Dockerfile.sim: routertl + rr in /usr/local/bin
    printf "#!/bin/bash\necho ROUTERTL_OK\n" > /usr/local/bin/routertl
    chmod +x /usr/local/bin/routertl
    ln -s routertl /usr/local/bin/rr

    mkdir -p /installers /opt/riviera
    chown -R runner:runner /opt/riviera

    # Probe script — replaces "bash" as the CMD
    cat > /usr/local/bin/probe << "EOF"
#!/bin/bash
echo "PATH_CHECK=$PATH"
echo "SIM_CHECK=$SIM"
echo "RR_CHECK=$(which rr 2>/dev/null || echo NOT_FOUND)"
echo "BASH_CHECK=$(which bash 2>/dev/null || echo NOT_FOUND)"
echo "ROUTERTL_CHECK=$(which routertl 2>/dev/null || echo NOT_FOUND)"
bash -c "echo BASH_EXEC_OK" 2>/dev/null || echo "BASH_EXEC_FAILED"
EOF
    chmod +x /usr/local/bin/probe

    /bin/bash /home/runner/install_riviera.sh probe
')

# Show probe values
echo "  Probe output:"
echo "$RESULT" | grep -E "_CHECK=|_EXEC|PROBE" | sed 's/^/    /'
echo ""

if echo "$RESULT" | grep -q "PATH_CHECK=.*/usr/local/bin"; then
    pass "PATH contains /usr/local/bin"
else
    fail "PATH missing /usr/local/bin"
fi

if echo "$RESULT" | grep -q "PATH_CHECK=.*/opt/riviera/bin"; then
    pass "PATH contains /opt/riviera/bin"
else
    fail "PATH missing /opt/riviera/bin"
fi

if echo "$RESULT" | grep -q "SIM_CHECK=riviera"; then
    pass "SIM=riviera is set"
else
    fail "SIM not set"
fi

if echo "$RESULT" | grep -q "RR_CHECK=.*/rr"; then
    pass "rr is reachable on PATH"
else
    fail "rr not found"
fi

if echo "$RESULT" | grep -q "BASH_CHECK=.*/bash"; then
    pass "bash is resolvable"
else
    fail "bash not resolvable (would break exec bash)"
fi

if echo "$RESULT" | grep -q "BASH_EXEC_OK"; then
    pass "bash -c executes (PATH not broken)"
else
    fail "bash -c failed (PATH regression)"
fi

if echo "$RESULT" | grep -q "ROUTERTL_CHECK=.*/routertl"; then
    pass "routertl is on PATH"
else
    fail "routertl not found"
fi

echo ""

# ── Test 2: Boot-time rr creation (old image) ────────────────
echo "── Test 2: Boot-time rr creation (no pre-existing symlink) ──"

RESULT2=$(run_riviera_test '
    useradd -m -s /bin/bash runner 2>/dev/null || true
    mkdir -p /home/runner/work

    # routertl exists but NO rr symlink (old image scenario)
    printf "#!/bin/bash\necho ROUTERTL_OK\n" > /usr/local/bin/routertl
    chmod +x /usr/local/bin/routertl

    mkdir -p /installers /opt/riviera
    chown -R runner:runner /opt/riviera

    cat > /usr/local/bin/probe << "EOF"
#!/bin/bash
echo "RR_BOOT_CHECK=$(which rr 2>/dev/null || echo NOT_FOUND)"
EOF
    chmod +x /usr/local/bin/probe

    /bin/bash /home/runner/install_riviera.sh probe
')

if echo "$RESULT2" | grep -q "RR_BOOT_CHECK=.*/rr"; then
    pass "rr created at boot (old image scenario)"
else
    fail "rr NOT created at boot"
fi

echo ""

# ── Test 3: Volume version stamp ─────────────────────────────
echo "── Test 3: Volume version stamp ──"

RESULT3=$(run_riviera_test '
    useradd -m -s /bin/bash runner 2>/dev/null || true
    mkdir -p /home/runner/work /opt/riviera/bin /installers
    chown -R runner:runner /opt/riviera

    printf "#!/bin/bash\necho ok\n" > /usr/local/bin/routertl
    chmod +x /usr/local/bin/routertl
    ln -s routertl /usr/local/bin/rr

    cat > /usr/local/bin/probe << "EOF"
#!/bin/bash
if [ -f /opt/riviera/.routertl_image_id ]; then
    echo "STAMP_CHECK=EXISTS"
else
    echo "STAMP_CHECK=MISSING"
fi
EOF
    chmod +x /usr/local/bin/probe

    /bin/bash /home/runner/install_riviera.sh probe
')

if echo "$RESULT3" | grep -q "STAMP_CHECK=EXISTS"; then
    pass "Volume version stamp created"
else
    fail "Volume version stamp missing"
fi

echo ""

# ── Test 4: Static analysis ──────────────────────────────────
echo "── Test 4: Static analysis of install_riviera.sh ──"

RS="${DOCKER_DIR}/install_riviera.sh"

# No 2>/dev/null on su calls
if [ "$(grep -c "exec su.*2>/dev/null" "$RS" || true)" -eq 0 ]; then
    pass "No 2>/dev/null on su calls"
else
    fail "Found su with 2>/dev/null (kills PS1)"
fi

# No login shell 'su -'
if [ "$(grep -cP 'su\s+-\s+(?!s|c)' "$RS" || true)" -eq 0 ]; then
    pass "No login shell 'su -'"
else
    fail "Found login shell su"
fi

# PATH inside su -c
SU_CMD=$(grep -oP "exec su.*?-c\s+\"[^\"]*\"" "$RS" | tail -1 || true)
if echo "$SU_CMD" | grep -q "PATH="; then
    pass "PATH set inside su -c"
else
    fail "PATH not inside su -c"
fi

if echo "$SU_CMD" | grep -q "SIM=riviera"; then
    pass "SIM=riviera inside su -c"
else
    fail "SIM not inside su -c"
fi

if echo "$SU_CMD" | grep -q "/usr/local/bin"; then
    pass "PATH includes /usr/local/bin"
else
    fail "PATH missing /usr/local/bin"
fi

echo ""

# ── Summary ───────────────────────────────────────────────────
TOTAL=$((PASS + FAIL))
echo "═══════════════════════════════════════════════════════════"
echo "  TOTAL:  ${TOTAL} checks"
echo "  PASSED: ${PASS}"
echo "  FAILED: ${FAIL}"
echo "═══════════════════════════════════════════════════════════"

if [ "$FAIL" -gt 0 ]; then
    echo -e "\nFailures:${ERRORS}"
    exit 1
fi
