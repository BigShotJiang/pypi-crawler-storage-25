# SPDX-FileCopyrightText: 2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""routertl MCP server — expose CLI knowledge to AI agents.

Gives any MCP-capable AI tool (Claude Code, Cursor, etc.) structured
access to the routertl CLI ecosystem: project config, package registry,
design rules, FPGA knowledge base, and diagnostic guidance.

Run standalone:
    python -m sdk.mcp_server              # stdio transport (default)
    python -m sdk.mcp_server --sse        # SSE transport on port 8750

SPDX-License-Identifier: MIT
"""

from __future__ import annotations

import logging
import subprocess
import sys
from pathlib import Path
from typing import Optional

from mcp.server.fastmcp import FastMCP

# ── Bootstrap: ensure sdk package is importable ────────────
_pkg_dir = Path(__file__).resolve().parent.parent
if str(_pkg_dir) not in sys.path:
    sys.path.insert(0, str(_pkg_dir))

_log = logging.getLogger("routertl.mcp")

# ── MCP Server ──────────────────────────────────────────────
mcp = FastMCP(
    "routertl",
    instructions=(
        "RouteRTL SDK — the FPGA CLI ecosystem. "
        "IP registry with license detection, cross-language dependency resolution, "
        "smart linting, multi-vendor synthesis — one pip install. "
        "Use these tools to understand project configuration, search the IP registry, "
        "query FPGA knowledge, check design rules, and diagnose build issues."
    ),
)


# ── Helpers ──────────────────────────────────────────────────


def _run_rr(*args: str, timeout: int = 30) -> str:
    """Run an ``rr`` CLI command and return stdout, or an error string."""
    try:
        result = subprocess.run(
            ["rr", *args],
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        output = result.stdout.strip()
        if result.returncode != 0 and result.stderr.strip():
            output += f"\n\nSTDERR:\n{result.stderr.strip()}"
        return output or "(no output)"
    except FileNotFoundError:
        return "Error: 'rr' command not found. Is routertl installed? (pip install routertl)"
    except subprocess.TimeoutExpired:
        return f"Error: command timed out after {timeout}s"


def _load_project_config_safe() -> dict:
    """Load project.yml from CWD, returning empty dict on failure."""
    try:
        from sdk.cli.project_config import load_project_config
        return load_project_config()
    except (FileNotFoundError, ImportError, OSError, ValueError):
        return {}


def _get_project_root() -> Path | None:
    """Find the project root (directory containing project.yml)."""
    try:
        from sdk.api.tools import get_project_root
        return get_project_root()
    except (ImportError, OSError):
        return None


# =====================================================================
# TOOL: rr_help — structured CLI help
# =====================================================================

# Complete command tree for structured help (avoids shelling out for
# basic discovery).  Kept as data so agents can browse without I/O.

_COMMAND_TREE = {
    "init": "Initialize a new routertl project (creates project.yml and directory structure)",
    "status": "Show project status — active target, toolchain, sources, and IP dependencies",
    "doctor": "Diagnose common project issues (missing tools, bad config, stale lockfile)",
    "info": "Show detailed project info — resolved config, sources, constraints, IPs",
    "license": "Show SDK license information",
    "version": "Show the SDK version",
    "synth": "Run synthesis (Vivado or Quartus, auto-detected from project.yml)",
    "implementation": "Run place & route after synthesis",
    "bitstream": "Generate bitstream / programming file",
    "linting": "Run HDL linting (Verilator, Vivado lint, or custom)",
    "hierarchy": "Show the module hierarchy tree",
    "schematic": "Generate and open schematic from synthesis",
    "program": "Program the FPGA board with a bitstream",
    "hardware": "Hardware diagnostics — board detection, JTAG scan, device info",
    "fpga": "FPGA device management — list supported families, parts, and boards",
    "project": "Manage project configuration and targets",
    "sim": "Run simulation (cocotb, VUnit, or custom testbench)",
    "testgen": "Generate test scaffolding from HDL module ports",
    "scan-tests": "Discover and list all available test cases",
    "waves": "Open waveform viewer for simulation results",
    "viewlog": "View simulation or synthesis log files",
    "regression": "Run the full regression test suite",
    "diff": "Diff two simulation results or synthesis reports",
    "watch": "Watch for file changes and re-run simulation automatically",
    "deps": "Show dependency graph for the project",
    "report": "Generate build/resource utilization reports",
    "bom": "Generate bill of materials for the design",
    "rules": "FPGA design rules — check, add, and manage (rules check, rules add, rules list)",
    "telemetry": "View or manage CLI usage telemetry",
    "target": "Manage build targets (list, add, switch, remove)",
    "workspace": "Manage multi-project workspaces",
    "sources": "List and manage HDL source files",
    "config": "View or edit project configuration values",
    "ci": "CI/CD helpers — generate GitHub Actions, GitLab CI configs",
    "lock": "Manage routertl.lock — resolve, verify, or regenerate",
    "diff-lock": "Compare lockfiles to detect dependency drift",
    "pkg": "IP package manager — install, search, publish, verify (Cargo-style for FPGAs)",
    "ip": "IP core management — add, list, and configure IP blocks",
    "regbank": "Generate register bank RTL and software headers from YAML/JSON specs",
    "rom": "Generate ROM/LUT initialization files",
    "linux": "Embedded Linux helpers — PetaLinux, device tree, rootfs",
    "docker": "Manage Docker build environments for reproducible EDA workflows",
    "eda": "EDA tool management — detect, configure, and manage vendor tools",
    "hook": "Manage Git hooks — install, list, remove pre-commit checks",
    "ask": "Ask the FPGA knowledge base a question (fpgawisdom.com RAG)",
    "alias": "Manage user-defined command aliases",
    "migrate": "Migrate from Vivado XPR projects to routertl project.yml",
    "routewave": "Launch RouteWave GUI (graphical waveform and project viewer)",
    "completion": "Generate shell completions (bash, zsh, fish)",
}

_PKG_SUBCOMMANDS = {
    "install": "Install an IP package from the registry into the current project",
    "add": "Add a local or git-based IP dependency",
    "update": "Update installed packages to latest compatible versions",
    "list": "List installed IP packages and their versions",
    "search": "Search the IP registry by name, keyword, or category",
    "info": "Show detailed metadata for a registry package",
    "verify": "Run verification checks on an IP package (lint, sim, license)",
    "register": "Register a new IP package with the registry",
    "publish": "Publish a package version to the registry",
    "login": "Authenticate with the IP registry",
    "logout": "Clear registry authentication",
    "test": "Run the package's built-in test suite",
    "backfill-deps": "Auto-detect and add missing dependencies",
}


@mcp.tool()
def rr_help(command: Optional[str] = None) -> str:
    """Get structured help for routertl CLI commands.

    Args:
        command: Specific command to get help for (e.g. "synth", "pkg",
                 "pkg install", "rules check"). Omit for an overview
                 of all available commands.
    """
    if not command:
        lines = ["# routertl (rr) CLI — Command Reference\n"]
        for cmd, desc in _COMMAND_TREE.items():
            lines.append(f"- **rr {cmd}** — {desc}")
        lines.append(
            "\nUse `rr_help(command='<name>')` for detailed help on any command."
        )
        return "\n".join(lines)

    cmd = command.strip().lower()

    # Check for pkg subcommands
    if cmd.startswith("pkg "):
        sub = cmd.split(None, 1)[1]
        if sub in _PKG_SUBCOMMANDS:
            return f"## rr pkg {sub}\n\n{_PKG_SUBCOMMANDS[sub]}\n\n" + _run_rr(
                "pkg", sub, "--help"
            )
        return f"Unknown pkg subcommand: {sub}\n\nAvailable: {', '.join(_PKG_SUBCOMMANDS)}"

    # Check top-level commands
    if cmd in _COMMAND_TREE:
        desc = _COMMAND_TREE[cmd]
        detailed = _run_rr(cmd, "--help")
        return f"## rr {cmd}\n\n{desc}\n\n```\n{detailed}\n```"

    # Fuzzy match
    matches = [c for c in _COMMAND_TREE if cmd in c or c in cmd]
    if matches:
        return (
            f"No exact match for '{cmd}'. Did you mean one of these?\n\n"
            + "\n".join(f"- rr {m} — {_COMMAND_TREE[m]}" for m in matches)
        )

    return f"Unknown command: '{cmd}'. Use rr_help() to see all commands."


# =====================================================================
# TOOL: rr_cli — live Click introspection with semantic annotations
# =====================================================================

# RTL-P2.382: annotations keyed by command path tuple
# ("project", "clean") or ("synth", "run").  Every live command we care
# about should land here — absent entries are rendered as neutral
# (no mutating/invalidates/chains lines), never treated as "safe".
# Keep one source of truth; drift-detection is the user reading the
# table, not a test assertion, since new commands SHOULD be annotated
# when they're added.
_CLI_SEMANTIC_ANNOTATIONS: dict[tuple[str, ...], dict[str, object]] = {
    # Hardware build pipeline
    ("synth", "run"): {
        "mutating": True,
        "writes": ["<output_dir>/project/", "<output_dir>/dcp/",
                   "<output_dir>/reports/"],
        "invalidates": ["bitstream"],
        "chains": [["impl", "run"], ["bitstream"]],
    },
    ("impl", "run"): {
        "mutating": True,
        "writes": ["<output_dir>/dcp/implementation.dcp",
                   "<output_dir>/reports/"],
        "invalidates": ["bitstream"],
        "chains": [["bitstream"]],
    },
    ("implementation", "run"): {
        "mutating": True,
        "writes": ["<output_dir>/dcp/implementation.dcp",
                   "<output_dir>/reports/"],
        "invalidates": ["bitstream"],
        "chains": [["bitstream"]],
    },
    ("bitstream",): {
        "mutating": True,
        "writes": ["<output_dir>/bitstream/", "<output_dir>/build/*.xsa"],
        "invalidates": [],
        "chains": [["program"]],
    },
    ("bitstream", "status"): {
        "mutating": False,
        "notes": "RTL-P2.376 per-target table; no side effects.",
    },
    ("program",): {
        "mutating": True,
        "notes": "Flashes the FPGA — side effect on hardware, not filesystem.",
    },

    # Project management
    ("project", "clean"): {
        "mutating": True,
        "writes": ["last_build/ (preserved bitstreams)"],
        "removes": ["<output_dir>/project/", "<output_dir>/dcp/",
                    "<output_dir>/reports/", "<output_dir>/build/"],
        "invalidates": ["synth", "impl", "bitstream"],
        "flags": {
            "--all": "Full clean (default). Removes dcp/ too.",
            "--soft": "Preserve dcp/ and db/ for incremental rebuilds.",
            "--sw": "Hook-generated outputs only.",
        },
    },
    ("project", "gui"): {
        "mutating": False,
        "writes": ["(spawns vendor IDE as detached process)"],
        "notes": "RTL-P2.400: opens Vivado / Quartus / Radiant / Libero "
                 "depending on hardware.vendor in the active target yml. "
                 "Passes the generated project file (<output_dir>/project/"
                 "<name>.{xpr|qpf|rdf|prjx}) when one exists; "
                 "--no-project launches blank.  Detaches via "
                 "start_new_session so the user drops back to shell.",
    },
    ("project", "archive"): {
        "mutating": False,
        "writes": ["<project>_<tag>.tar.gz"],
        "notes": "RTL-P2.397: source-only by default (no bit/dcp/xsa/qar/"
                 "reports).  --with-outputs opts in to ship build "
                 "artefacts.  --all-targets unions every target's sources "
                 "(outputs only when --with-outputs also set).  "
                 "--no-binaries is a deprecated no-op.",
    },
    ("project", "restore"): {
        "mutating": True,
        "writes": ["current directory (extracts archive)"],
        "notes": "RTL-P3.182: hints git init when dest has no .git.",
    },

    # Target management
    ("target", "set"): {
        "mutating": True,
        "writes": ["project.yml (target: field)", "build_env.mk",
                   "build_env.tcl"],
        "notes": "RTL-P2.367: regenerates build_env from the active "
                 "target yml.  Edit target yml -> run this -> synth.",
    },
    ("target", "list"): {"mutating": False},
    ("target", "show"): {"mutating": False},

    # Package manager
    ("pkg", "add"): {
        "mutating": True,
        "writes": ["project.yml (packages:)", "libs/<ns>/<name>/",
                   "ip.lock"],
        "notes": "RTL-P1.47 + P2.378: --commit HEAD pin + auto-HEAD "
                 "fallback on tag-less repos.  --strict disables "
                 "auto-HEAD.  P2.381 reads HEAD.yml from registry.",
    },
    ("pkg", "install"): {
        "mutating": True,
        "writes": ["libs/<ns>/<name>/", "ip.lock"],
    },
    ("pkg", "update"): {
        "mutating": True,
        "writes": ["libs/<ns>/<name>/", "ip.lock"],
    },
    ("pkg", "yank"): {
        "mutating": True,
        "notes": "Registry-side retraction — affects other users, "
                 "not just this project.",
    },
    ("pkg", "publish"): {
        "mutating": True,
        "notes": "Registry-side publish — public by default.",
    },
    ("pkg", "search"): {"mutating": False},
    ("pkg", "info"): {"mutating": False},
    ("pkg", "list"): {"mutating": False},
    ("pkg", "verify"): {"mutating": False},

    # Lockfile
    ("lock",): {
        "mutating": True,
        "writes": ["routertl.lock"],
        "notes": "RTL-P1.48: compile_order is deterministic across "
                 "PYTHONHASHSEED.",
    },
    ("diff-lock",): {
        "mutating": False,
        "notes": "RTL-P1.49: exits 1 on drift (compile_order + "
                 "dependencies).",
    },

    # Rules
    ("rules", "check"): {"mutating": False},
    ("rules", "list"): {"mutating": False},
    ("rules", "add"): {
        "mutating": True,
        "writes": ["rules.json"],
    },

    # EDA / env
    ("eda", "install"): {
        "mutating": True,
        "notes": "Shells out to apt/brew — may require sudo.  "
                 "RTL-P3.170: TLS-proxy error hint when git clone fails.",
    },
    ("workspace", "update"): {
        "mutating": True,
        "writes": ["build_env.mk", "build_env.tcl"],
    },

    # Read-only commands (grouped for brevity; the full help string still
    # carries per-command detail)
    ("status",): {"mutating": False},
    ("doctor",): {"mutating": False},
    ("info",): {"mutating": False},
    ("hierarchy",): {"mutating": False},
    ("schematic",): {"mutating": False},
    ("deps",): {"mutating": False},
    ("sources",): {"mutating": False},
    ("help",): {"mutating": False},
    ("version",): {"mutating": False},
    ("license",): {"mutating": False},
    ("sdk-path",): {"mutating": False},
    ("config",): {"mutating": False},
    ("ask",): {"mutating": False},

    # Simulation / verification
    ("sim", "run"): {
        "mutating": True,
        "writes": ["sim/cocotb/build/", "sim/cocotb/logs/",
                   "sim/cocotb/waves/"],
        "notes": "RTL-P2.370: AST-based cocotb detection (imports "
                 "past line 30 no longer silently skipped).",
    },
    ("sim", "list"): {"mutating": False},
    ("waves",): {"mutating": False},
    ("viewlog",): {"mutating": False},

    # Scaffold
    ("init",): {
        "mutating": True,
        "writes": ["project.yml", "Makefile", ".gitignore", "VERSION"],
        "notes": "RTL-P3.182: hints git init when cwd has no .git.",
    },
}


def _walk_click_tree(cmd, path: tuple[str, ...] = ()):
    """Recursively walk a click Group, yielding (path_tuple, click_cmd)."""
    import click

    yield path, cmd
    if isinstance(cmd, click.Group):
        for name in sorted(cmd.commands.keys()):
            yield from _walk_click_tree(cmd.commands[name], (*path, name))


def _format_click_option(param) -> str:
    """Render a click.Option as a one-line flag summary."""
    import click

    if not isinstance(param, click.Option):
        return ""
    flags = "/".join(param.opts + param.secondary_opts) or param.name
    default_str = ""
    if param.default is not None and param.default is not False:
        # Skip defaults that are <function>, Path, etc.
        if isinstance(param.default, (str, int, float, bool)):
            default_str = f" [default: {param.default}]"
    help_text = (param.help or "").strip().split("\n")[0]
    return f"  `{flags}`{default_str} — {help_text}" if help_text else f"  `{flags}`{default_str}"


def _format_cli_command(path: tuple[str, ...], cmd, verbose: bool) -> str:
    """Format a single command with optional verbose help + semantics."""
    import click

    header = f"### rr {' '.join(path)}" if path else "### rr"
    lines = [header]

    # Short help / help
    short = (cmd.short_help or cmd.help or "").strip().split("\n")[0]
    if short:
        lines.append(f"_{short}_")

    # Options (skip groups, they don't carry meaningful per-group options)
    if not isinstance(cmd, click.Group):
        opts = [p for p in cmd.params if isinstance(p, click.Option)]
        if opts:
            lines.append("\n**Flags:**")
            for p in opts:
                line = _format_click_option(p)
                if line:
                    lines.append(line)

    # Semantic annotations
    ann = _CLI_SEMANTIC_ANNOTATIONS.get(path)
    if ann:
        lines.append("\n**Semantics:**")
        if ann.get("mutating") is True:
            lines.append("  🔧 mutating")
        elif ann.get("mutating") is False:
            lines.append("  ✅ read-only")
        for key in ("writes", "removes", "invalidates"):
            val = ann.get(key)
            if val:
                lines.append(f"  {key}: {', '.join(val)}")
        chains = ann.get("chains")
        if chains:
            chain_strs = [f"rr {' '.join(c)}" for c in chains]
            lines.append(f"  chains: {' → '.join(chain_strs)}")
        flags = ann.get("flags")
        if flags:
            lines.append("  flag semantics:")
            for k, v in flags.items():
                lines.append(f"    `{k}` — {v}")
        notes = ann.get("notes")
        if notes:
            lines.append(f"  note: {notes}")

    # Verbose: include full help text
    if verbose and cmd.help:
        lines.append("\n**Full help:**")
        lines.append("```")
        lines.append(cmd.help.strip())
        lines.append("```")

    return "\n".join(lines)


@mcp.tool()
def rr_cli(command: Optional[str] = None, verbose: bool = False) -> str:
    """Return the routertl CLI surface — verbs, flags, semantic metadata.

    RTL-P2.382.  Walks the live click command tree (no stale static
    dicts) and annotates each command with:
      * mutating / read-only classification
      * writes — files or directories the command produces
      * removes — files or directories the command deletes
      * invalidates — stages downstream that must be re-run
      * chains — commands typically invoked next
      * flag semantics — what each flag does beyond the --help line
      * notes — cross-references to the backlog tickets that shape behaviour

    Args:
        command: Filter to a specific command path, e.g. "pkg add",
                 "project clean", "synth run".  Omit for the full tree
                 (summary, no flags).
        verbose: Include the full `--help` body per command (default
                 False to keep the response compact).

    Returns:
        Markdown string.  When *command* is provided, returns a single
        detailed block.  Otherwise returns a grouped outline with one
        line per command and a semantic tag.
    """
    try:
        from sdk.cli.main import cli as root_cli
    except ImportError as exc:
        return f"❌ Could not load CLI: {exc}"

    entries = list(_walk_click_tree(root_cli))

    if command:
        target = tuple(command.strip().split())
        for path, cmd in entries:
            if path == target:
                return _format_cli_command(path, cmd, verbose=True)
        # Case-insensitive fallback
        target_lower = tuple(p.lower() for p in target)
        for path, cmd in entries:
            if tuple(p.lower() for p in path) == target_lower:
                return _format_cli_command(path, cmd, verbose=True)
        available = sorted(" ".join(p) for p, _ in entries if p)
        suggestions = [a for a in available if command.lower() in a.lower()]
        msg = f"Unknown command path: '{command}'."
        if suggestions:
            msg += "\n\nSuggestions:\n" + "\n".join(
                f"  - {s}" for s in suggestions[:10]
            )
        return msg

    # Full tree — compact outline with semantic tags
    import click

    out = ["# routertl CLI (live introspection)\n"]
    for path, cmd in entries:
        if not path:
            continue  # skip the root group
        # One-line summary per command
        short = (cmd.short_help or cmd.help or "").strip().split("\n")[0]
        ann = _CLI_SEMANTIC_ANNOTATIONS.get(path, {})
        tag = ""
        if ann.get("mutating") is True:
            tag = " 🔧"
        elif ann.get("mutating") is False:
            tag = " ✅"
        indent = "  " * (len(path) - 1)
        kind = "group" if isinstance(cmd, click.Group) else "cmd"
        out.append(
            f"{indent}- `rr {' '.join(path)}`{tag} "
            f"({kind}) — {short}"
        )

    out.append(
        "\n**Legend:** 🔧 mutating · ✅ read-only.  "
        "Use `rr_cli(command='<name>')` for flags + full semantics on "
        "any command; set `verbose=True` to include the full --help text."
    )
    if verbose:
        out.append("\n## Detail per command\n")
        for path, cmd in entries:
            if not path:
                continue
            out.append(_format_cli_command(path, cmd, verbose=True))
            out.append("")
    return "\n".join(out)


# =====================================================================
# TOOL: rr_schema — project.yml / target yml field reference
# =====================================================================

# RTL-P2.383: structured annotation table for every key project.yml
# accepts.  Single source of truth agents consult before editing config.
# Mirrors the routertl_core validator's known fields — drift detection
# is a unit test that loads real project.ymls and flags unknown keys.
#
# Each entry is a dict with:
#   type       — "string" | "int" | "bool" | "list[str]" | "dict" | "dict[str, str]"
#   required   — bool (False when optional with a default)
#   default    — value emitted when omitted (None if truly optional)
#   purpose    — one-sentence description
#   scope      — "root" (project.yml only), "target" (target yml only),
#                "both" (either; target overrides root)
#   refs       — list of backlog tickets that shape the field
#   example    — representative value
_SCHEMA_ANNOTATIONS: dict[str, dict[str, object]] = {
    # ── project.* ────────────────────────────────────────────────
    "project.name": {
        "type": "string", "required": True,
        "purpose": "Logical project name — used for Vivado project, "
                   "archive filenames, and display.",
        "scope": "both", "refs": [],
        "example": "sensor_hub",
    },
    "project.top_module": {
        "type": "string", "required": True,
        "purpose": "HDL top entity / module synthesised and placed.",
        "scope": "both", "refs": [],
        "example": "sensor_hub_top",
    },
    "project.top_sim": {
        "type": "string", "required": False, "default": "tb_<top>_sim",
        "purpose": "Top-level testbench entity for simulation.",
        "scope": "both", "refs": [],
        "example": "tb_sensor_hub_top",
    },
    "project.output_dir": {
        "type": "string", "required": False, "default": ".",
        "purpose": "Per-target artefact prefix — nests bitstream/, dcp/, "
                   "reports/, build/, project/ under this path so "
                   "multi-target projects keep concurrent bitstreams. "
                   "Default '.' preserves the pre-P2.373 flat layout.",
        "scope": "target", "refs": ["RTL-P2.373"],
        "example": "build/alpha",
    },
    "project.path": {
        "type": "string", "required": False, "default": "project",
        "purpose": "Sub-directory name for the generated vendor project "
                   "(Vivado .xpr, Quartus .qpf).  Relative to output_dir.",
        "scope": "both", "refs": [],
        "example": "project",
    },

    # ── hardware.* ───────────────────────────────────────────────
    "hardware.vendor": {
        "type": "string", "required": True,
        "purpose": "FPGA toolchain family.  Dispatches the right Tcl set.",
        "scope": "both", "refs": [],
        "example": "xilinx | altera | lattice | microchip | opensource",
    },
    "hardware.part": {
        "type": "string", "required": True,
        "purpose": "Vendor-specific part number.  Exact strings vary — "
                   "see rr fpga list <vendor>.",
        "scope": "both", "refs": [],
        "example": "xc7z020clg400-1",
    },
    "hardware.family": {
        "type": "string", "required": False, "default": "(auto)",
        "purpose": "Device family override (rarely needed; derived from part).",
        "scope": "both", "refs": [],
        "example": "Zynq-7000",
    },
    "hardware.language": {
        "type": "string", "required": False, "default": "auto",
        "purpose": "Primary HDL hint — influences Makefile defaults and "
                   "some linter invocations.",
        "scope": "both", "refs": [],
        "example": "vhdl | verilog | systemverilog | mixed",
    },
    "hardware.platform": {
        "type": "string", "required": False, "default": "default",
        "purpose": "Board / platform label — used by some vendor hooks.",
        "scope": "both", "refs": [],
        "example": "default",
    },

    # ── sources.* ─────────────────────────────────────────────────
    "sources.syn": {
        "type": "list[str]", "required": False, "default": [],
        "purpose": "Synthesis source files (HDL) — order matters for VHDL, "
                   "auto-resolved for Verilog/SV.",
        "scope": "both", "refs": [],
        "example": "['hw/src/top.vhd', 'hw/src/fifo.sv']",
    },
    "sources.sim": {
        "type": "list[str]", "required": False, "default": [],
        "purpose": "Simulation-only sources (testbenches, stubs).  "
                   "Consumed by rr sim.",
        "scope": "both", "refs": ["RTL-P2.356"],
        "example": "['sim/tb_top.sv']",
    },
    "sources.xdc": {
        "type": "list[str]", "required": False, "default": [],
        "purpose": "Constraint files (Xilinx XDC, Altera SDC, Lattice LPF).",
        "scope": "both", "refs": [],
        "example": "['hw/xdc/top.xdc']",
    },
    "sources.ip_paths": {
        "type": "list[str]", "required": False, "default": [],
        "purpose": "Additional IP search paths for Vivado.  Absolute "
                   "paths break archives — prefer relative.",
        "scope": "both", "refs": ["RTL-P2.272"],
        "example": "['ip/custom']",
    },
    "sources.software": {
        "type": "dict", "required": False, "default": {},
        "purpose": "Embedded firmware / software sources (ELF, hex, BSP).  "
                   "Surfaced as a separate archive bucket.",
        "scope": "both", "refs": ["RTL-P1.46"],
        "example": "{'elf': 'sw/app/main.elf'}",
    },

    # ── paths.* ──────────────────────────────────────────────────
    "paths.sources": {
        "type": "list[str]", "required": False, "default": ["src"],
        "purpose": "Directory roots scanned for HDL sources when "
                   "sources.syn is auto-resolved.",
        "scope": "both", "refs": [],
        "example": "['hw/src', 'libs']",
    },
    "paths.simulation": {
        "type": "string", "required": False, "default": "sim",
        "purpose": "Directory root for simulation artefacts.",
        "scope": "both", "refs": [],
        "example": "hw/sim",
    },
    "paths.constraints": {
        "type": "string", "required": False, "default": "xdc",
        "purpose": "Directory root for constraint files.",
        "scope": "both", "refs": [],
        "example": "hw/xdc",
    },
    "paths.verification": {
        "type": "string", "required": False, "default": "verif",
        "purpose": "Directory root for verification collateral.",
        "scope": "both", "refs": [],
        "example": "hw/verif",
    },

    # ── simulation.* ─────────────────────────────────────────────
    "simulation.test_dir": {
        "type": "string", "required": False, "default": "sim/cocotb/tests",
        "purpose": "Directory containing cocotb test modules.  rr project "
                   "archive uses this to resolve the cocotb root.",
        "scope": "both", "refs": ["RTL-P2.345"],
        "example": "hw/sim/cocotb/tests",
    },
    "simulation.waves.formats": {
        "type": "list[str]", "required": False, "default": ["fst"],
        "purpose": "Wave dump formats emitted by simulations.",
        "scope": "both", "refs": [],
        "example": "['fst', 'vcd']",
    },

    # ── build_options.* ──────────────────────────────────────────
    "build_options.tool_version": {
        "type": "string", "required": False, "default": "(auto)",
        "purpose": "Expected vendor tool version (pinned in ip.lock).",
        "scope": "both", "refs": [],
        "example": "2024.1",
    },
    "build_options.edition": {
        "type": "string", "required": False, "default": "(auto)",
        "purpose": "Quartus edition override (pro | std).  Auto-detected "
                   "from the installed tool when unset.",
        "scope": "both", "refs": ["RTL-P2.279"],
        "example": "pro",
    },
    "build_options.skip_license_check": {
        "type": "bool", "required": False, "default": False,
        "purpose": "Skip the FlexLM license preflight — useful in "
                   "non-FlexLM environments.",
        "scope": "both", "refs": ["RTL-P2.292"],
        "example": "true",
    },
    "build_options.generics": {
        "type": "dict[str, str]", "required": False, "default": {},
        "purpose": "Top-level VHDL generics / SV parameters applied at "
                   "synthesis.",
        "scope": "both", "refs": [],
        "example": "{'DATA_WIDTH': '32', 'FIFO_DEPTH': '512'}",
    },

    # ── packages — IP manager ────────────────────────────────────
    "packages": {
        "type": "dict[str, str]", "required": False, "default": {},
        "purpose": "IP package declarations — key is 'namespace/name', "
                   "value is a version constraint (^X.Y.Z, ~X.Y.Z, "
                   "exact X.Y.Z) OR 'commit:<40-hex-sha>'.",
        "scope": "both", "refs": ["RTL-P1.47", "RTL-P2.378", "RTL-P2.381"],
        "example": "{'open-logic/olo_base_fifo_async': '^2.5.0', "
                   "'pulp-platform/stream_mux': 'commit:8a3f...'}",
    },

    # ── tcl_hooks.* ──────────────────────────────────────────────
    "tcl_hooks.gen_project": {
        "type": "list[str]", "required": False, "default": [],
        "purpose": "Tcl scripts sourced at project generation — block "
                   "design, custom IP add, etc.",
        "scope": "both", "refs": ["RTL-P2.367"],
        "example": "['tcl/hooks/bd.tcl']",
    },
    "tcl_hooks.synthesis": {
        "type": "list[str]", "required": False, "default": [],
        "purpose": "Tcl sourced before the synth_1 run.",
        "scope": "both", "refs": [],
        "example": "['tcl/hooks/synth_strategy.tcl']",
    },
    "tcl_hooks.implementation": {
        "type": "list[str]", "required": False, "default": [],
        "purpose": "Tcl sourced before the impl_1 run.",
        "scope": "both", "refs": [],
        "example": "['tcl/hooks/impl_directives.tcl']",
    },
    "tcl_hooks.bitstream": {
        "type": "list[str]", "required": False, "default": [],
        "purpose": "Tcl sourced before bitstream generation.",
        "scope": "both", "refs": [],
        "example": "['tcl/hooks/bitstream_opts.tcl']",
    },
    "tcl_hooks.post_synthesis": {
        "type": "list[str]", "required": False, "default": [],
        "purpose": "Tcl sourced after synth_1 completes (reporting, "
                   "extra checkpoints).",
        "scope": "both", "refs": [],
        "example": "['tcl/hooks/post_synth_report.tcl']",
    },
    "tcl_hooks.post_implementation": {
        "type": "list[str]", "required": False, "default": [],
        "purpose": "Tcl sourced after impl_1 completes.",
        "scope": "both", "refs": [],
        "example": "[]",
    },
    "tcl_hooks.post_bitstream": {
        "type": "list[str]", "required": False, "default": [],
        "purpose": "Tcl sourced after bitstream generation.",
        "scope": "both", "refs": [],
        "example": "[]",
    },

    # ── target indirection (root project.yml only) ──────────────
    "target": {
        "type": "string", "required": False, "default": None,
        "purpose": "Relative path to the active target yml.  Root "
                   "project.yml either inlines config OR delegates via "
                   "this key.  Override with the RR_TARGET env var.",
        "scope": "root", "refs": ["RTL-P2.124", "RTL-P2.367"],
        "example": "targets/alpha.yml",
    },

    # ── dependencies — SDK fetched IP ───────────────────────────
    "dependencies": {
        "type": "dict", "required": False, "default": {},
        "purpose": "SDK-managed dependencies (e.g. XPM VHDL shim).  Each "
                   "entry has url / fallback_url / path / library.  "
                   "Distinct from packages (registry-managed).",
        "scope": "both", "refs": [],
        "example": "{'xpm_vhdl': {'url': '...', 'path': 'libs/xpm_vhdl', "
                   "'library': 'xpm'}}",
    },

    # ── hooks.pre_commit — repo-level ────────────────────────────
    "hooks.pre_commit.enabled": {
        "type": "bool", "required": False, "default": False,
        "purpose": "Master switch for the pre-commit hook installed by "
                   "rr hook install.",
        "scope": "both", "refs": [],
        "example": "true",
    },
    "hooks.pre_commit.lint": {
        "type": "bool", "required": False, "default": False,
        "purpose": "Run rr linting in the pre-commit hook.",
        "scope": "both", "refs": [],
        "example": "true",
    },
    "hooks.pre_commit.check_yaml": {
        "type": "bool", "required": False, "default": False,
        "purpose": "Validate YAML files in the pre-commit hook.",
        "scope": "both", "refs": [],
        "example": "true",
    },
    "hooks.pre_commit.tests": {
        "type": "list[str]", "required": False, "default": [],
        "purpose": "Cocotb tests to run in the pre-commit hook.",
        "scope": "both", "refs": [],
        "example": "['test_top_smoke']",
    },
    "hooks.pre_commit.exclude.tests": {
        "type": "list[str]", "required": False, "default": [],
        "purpose": "Cocotb tests to SKIP during the pre-commit hook.  "
                   "Use for pre-existing broken tests pending fixes.",
        "scope": "both", "refs": ["RTL-P1.44", "RTL-P2.370"],
        "example": "['test_avalon_arbiter']",
    },
    "hooks.pre_commit.exclude.lint": {
        "type": "list[str]", "required": False, "default": [],
        "purpose": "Lint targets to skip in the pre-commit hook.",
        "scope": "both", "refs": [],
        "example": "['infilter_array']",
    },
    "hooks.pre_build": {
        "type": "list[dict]", "required": False, "default": [],
        "purpose": "Arbitrary pre-build scripts that emit declared "
                   "outputs.  Each entry has name / command / outputs.",
        "scope": "both", "refs": [],
        "example": "[{'name': 'gen_rom', 'command': '...', 'outputs': [...]}]",
    },

    # ── cicd.* ───────────────────────────────────────────────────
    "cicd.platform": {
        "type": "string", "required": False, "default": "github",
        "purpose": "Target CI platform for `rr ci generate`.",
        "scope": "both", "refs": [],
        "example": "github | gitlab | bitbucket",
    },
    "cicd.tests": {
        "type": "list[str]", "required": False, "default": [],
        "purpose": "Cocotb tests promoted into the generated CI job.",
        "scope": "both", "refs": [],
        "example": "['test_top_smoke']",
    },

    # ── makefile_overrides.* — advanced ────────────────────────
    "makefile_overrides.project_dir": {
        "type": "string", "required": False, "default": "(project.path)",
        "purpose": "Override the generated project sub-directory name.",
        "scope": "both", "refs": [],
        "example": "vivado_project",
    },
    "makefile_overrides.output_dir": {
        "type": "string", "required": False, "default": "(project.output_dir)",
        "purpose": "Override per-target output prefix without touching "
                   "project.output_dir.  Advanced.",
        "scope": "both", "refs": ["RTL-P2.373"],
        "example": "build/experimental",
    },

    # ── vendor_overrides.* — per-vendor knobs ───────────────────
    "vendor_overrides": {
        "type": "dict", "required": False, "default": {},
        "purpose": "Nested overrides applied to the vendor-specific Tcl "
                   "emission (e.g. quartus_edition, number_of_jobs).",
        "scope": "both", "refs": [],
        "example": "{'xilinx': {'dcp_on': true}, 'altera': {...}}",
    },
}

# Grouping by top-level section for section-filter queries.
_SCHEMA_SECTIONS: dict[str, list[str]] = {}
for _key in _SCHEMA_ANNOTATIONS:
    _section = _key.split(".", 1)[0]
    _SCHEMA_SECTIONS.setdefault(_section, []).append(_key)


def _format_schema_entry(key: str) -> str:
    """Render one schema entry as a markdown block."""
    ann = _SCHEMA_ANNOTATIONS[key]
    lines = [f"### `{key}`"]
    req = "required" if ann.get("required") else "optional"
    default = ann.get("default")
    default_str = ""
    if not ann.get("required") and default is not None:
        if isinstance(default, str):
            default_str = f" · default `{default}`"
        elif isinstance(default, (list, dict)) and not default:
            default_str = f" · default empty `{type(default).__name__}`"
        else:
            default_str = f" · default `{default}`"
    lines.append(
        f"**type** `{ann.get('type', '?')}` · **{req}**{default_str} · "
        f"**scope** `{ann.get('scope', 'both')}`"
    )
    lines.append(f"\n{ann.get('purpose', '')}")
    refs = ann.get("refs") or []
    if refs:
        lines.append(f"\n**Refs:** {', '.join(refs)}")
    example = ann.get("example")
    if example is not None:
        lines.append(f"\n**Example:** `{example}`")
    return "\n".join(lines)


@mcp.tool()
def rr_schema(
    field: Optional[str] = None,
    section: Optional[str] = None,
) -> str:
    """Return the project.yml / target yml schema reference.

    RTL-P2.383.  Every documented key has type, required/default,
    purpose, backlog cross-refs, example value, and scope (root project
    only, target yml only, or both).

    Args:
        field: Filter to one exact key (e.g. 'project.output_dir',
               'packages', 'hooks.pre_commit.exclude.tests').
        section: Filter to a top-level section (e.g. 'project',
                 'sources', 'hardware', 'hooks', 'tcl_hooks').

    Returns:
        Markdown.  No args → full schema grouped by section.  field →
        single entry.  section → every key under that section.
    """
    if field:
        if field in _SCHEMA_ANNOTATIONS:
            return _format_schema_entry(field)
        # Fuzzy suggestions
        candidates = [k for k in _SCHEMA_ANNOTATIONS if field.lower() in k.lower()]
        msg = f"Unknown field: '{field}'."
        if candidates:
            msg += "\n\nDid you mean:\n" + "\n".join(
                f"  - `{c}`" for c in sorted(candidates)[:10]
            )
        return msg

    if section:
        keys = _SCHEMA_SECTIONS.get(section.lower())
        if not keys:
            known = sorted(_SCHEMA_SECTIONS.keys())
            return (
                f"Unknown section: '{section}'.\n\n"
                f"Known sections: {', '.join(known)}"
            )
        lines = [f"# project.yml schema — `{section}.*`\n"]
        for key in sorted(keys):
            lines.append(_format_schema_entry(key))
            lines.append("")
        return "\n".join(lines)

    # Full schema
    out = [
        "# routertl project.yml / target yml schema\n",
        "Every documented field with type, default, purpose, and the "
        "backlog tickets that shape it.  Use "
        "`rr_schema(field='project.output_dir')` for one entry or "
        "`rr_schema(section='sources')` for a whole section.\n",
    ]
    for section_name in sorted(_SCHEMA_SECTIONS.keys()):
        keys = sorted(_SCHEMA_SECTIONS[section_name])
        out.append(f"## `{section_name}.*`  ({len(keys)} keys)\n")
        for key in keys:
            ann = _SCHEMA_ANNOTATIONS[key]
            req = "required" if ann.get("required") else "optional"
            out.append(
                f"- **`{key}`** · `{ann.get('type', '?')}` · {req} "
                f"— {ann.get('purpose', '').split('.')[0]}."
            )
        out.append("")
    return "\n".join(out)


# =====================================================================
# TOOL: rr_project_info — parse and return project.yml
# =====================================================================


@mcp.tool()
def rr_project_info() -> str:
    """Read and return the current project configuration.

    Parses project.yml (chasing target pointers if present) and returns
    the full resolved configuration as structured text.  Includes
    hardware settings, source files, IP dependencies, build options,
    and target information.

    Returns an error message if no project.yml is found in the
    current directory tree.
    """
    root = _get_project_root()
    if root is None:
        return (
            "No project.yml found in the current directory tree.\n"
            "Run `rr init` to create a new project, or cd into a routertl project."
        )

    config = _load_project_config_safe()
    if not config:
        return f"Found project root at {root} but could not parse project.yml."

    # Build a structured summary
    lines = ["# Project Configuration\n", f"**Root:** {root}\n"]

    # Project name
    name = config.get("project", config.get("name", "unnamed"))
    lines.append(f"**Project:** {name}")

    # Hardware section
    hw = config.get("hardware", {})
    if hw:
        lines.append("\n## Hardware")
        for key in ["vendor", "family", "part", "board", "tool_path"]:
            val = hw.get(key)
            if val:
                lines.append(f"- **{key}:** {val}")

    # Target info
    try:
        from sdk.cli.project_config import get_active_target
        target = get_active_target()
        if target:
            lines.append(f"\n**Active target:** {target}")
    except (FileNotFoundError, ImportError, OSError, ValueError):
        pass

    # Sources
    srcs = config.get("sources", [])
    if srcs:
        lines.append(f"\n## Sources ({len(srcs)} entries)")
        for s in srcs[:20]:  # cap at 20 for readability
            if isinstance(s, str):
                lines.append(f"- {s}")
            elif isinstance(s, dict):
                lines.append(f"- {s}")
        if len(srcs) > 20:
            lines.append(f"- ... and {len(srcs) - 20} more")

    # IP dependencies
    ips = config.get("ips", config.get("dependencies", {}))
    if ips:
        lines.append("\n## IP Dependencies")
        if isinstance(ips, dict):
            for name, spec in ips.items():
                lines.append(f"- **{name}:** {spec}")
        elif isinstance(ips, list):
            for ip in ips:
                lines.append(f"- {ip}")

    # Build options
    build = config.get("build_options", {})
    if build:
        lines.append("\n## Build Options")
        for k, v in build.items():
            lines.append(f"- **{k}:** {v}")

    # Constraints
    constraints = config.get("constraints", [])
    if constraints:
        lines.append(f"\n## Constraints ({len(constraints)} files)")
        for c in constraints:
            lines.append(f"- {c}")

    # Full YAML as reference
    import yaml
    lines.append("\n## Raw Configuration\n```yaml")
    lines.append(yaml.dump(config, default_flow_style=False, sort_keys=False))
    lines.append("```")

    return "\n".join(lines)


# =====================================================================
# TOOL: rr_list_targets — available build targets
# =====================================================================


@mcp.tool()
def rr_list_targets() -> str:
    """List all available build targets for the current project.

    Scans the targets/ directory for target configurations and returns
    each target's name, device, vendor, and path.  Also shows which
    target is currently active.
    """
    try:
        from sdk.cli.project_config import discover_targets, get_active_target

        targets = discover_targets()
        active = get_active_target()
    except (FileNotFoundError, ImportError, OSError, ValueError) as exc:
        return f"Error discovering targets: {exc}"

    if not targets:
        return (
            "No targets found in targets/ directory.\n"
            "This project may use a self-contained project.yml (no target pointer).\n"
            "Use rr_project_info() to see the current configuration."
        )

    lines = ["# Available Targets\n"]
    if active:
        lines.append(f"**Active:** {active}\n")

    for t in targets:
        name = t["name"]
        path = t["path"]
        cfg = t.get("config", {})
        hw = cfg.get("hardware", {})
        vendor = hw.get("vendor", "?")
        part = hw.get("part", "?")
        marker = " ← active" if active and active in path else ""

        lines.append(f"### {name}{marker}")
        lines.append(f"- **Vendor:** {vendor}")
        lines.append(f"- **Part:** {part}")
        lines.append(f"- **Path:** {path}")
        lines.append("")

    return "\n".join(lines)


# =====================================================================
# TOOL: rr_pkg_search — search the IP registry
# =====================================================================


@mcp.tool()
def rr_pkg_search(query: str, limit: int = 20) -> str:
    """Search the routertl IP package registry.

    Args:
        query: Search term — matches against package name, namespace,
               description, and tags.
        limit: Maximum results to return (default: 20).
    """
    try:
        from sdk.engine.index_client import (
            fetch_catalog,
            get_index_url,
        )

        config = _load_project_config_safe()
        index_url = get_index_url(config)
        cache_dir = Path.home() / ".routertl" / "cache" / "index"

        catalog = fetch_catalog(index_url, cache_dir)
    except (ImportError, OSError, ValueError, KeyError) as exc:
        return f"Error fetching registry catalog: {exc}"

    if not catalog:
        return "Registry catalog is empty or unreachable."

    # Search across name, namespace, description, tags
    q = query.lower()
    matches = []
    for entry in catalog:
        searchable = " ".join([
            entry.get("name", ""),
            entry.get("namespace", ""),
            entry.get("description", ""),
            " ".join(entry.get("tags", [])),
        ]).lower()
        if q in searchable:
            matches.append(entry)

    if not matches:
        return f"No packages found matching '{query}'."

    matches = matches[:limit]
    lines = [f"# Registry Search: '{query}' — {len(matches)} results\n"]

    for pkg in matches:
        ns = pkg.get("namespace", "")
        name = pkg.get("name", "")
        latest = pkg.get("latest", "")
        desc = pkg.get("description", "")[:120]
        license_ = pkg.get("license", "")
        lang = pkg.get("language", "")
        ref = f"{ns}/{name}" if ns else name

        lines.append(f"### {ref} v{latest}")
        if desc:
            lines.append(f"{desc}")
        details = []
        if license_:
            details.append(f"License: {license_}")
        if lang:
            details.append(f"Language: {lang}")
        if details:
            lines.append(f"*{' · '.join(details)}*")
        lines.append("")

    return "\n".join(lines)


# =====================================================================
# TOOL: rr_pkg_info — detailed package metadata
# =====================================================================


@mcp.tool()
def rr_pkg_info(package: str) -> str:
    """Get detailed metadata for a specific IP package.

    Args:
        package: Package reference — either "namespace/name" or just "name".
                 Example: "corundum/corundum_mqnic" or "uart_16550".
    """
    return _run_rr("pkg", "info", package)


# =====================================================================
# TOOL: rr_diagnose — structured error guidance
# =====================================================================

_COMMON_ERRORS = {
    "no project.yml": {
        "cause": "Not inside a routertl project directory",
        "fix": "Run `rr init` to create a new project, or cd into an existing project root.",
    },
    "vivado not found": {
        "cause": "Vivado is not in PATH and hardware.tool_path is not set in project.yml",
        "fix": (
            "Either:\n"
            "1. Source Vivado settings: `source /tools/Xilinx/Vivado/2024.2/settings64.sh`\n"
            "2. Set tool_path in project.yml:\n"
            "   ```yaml\n"
            "   hardware:\n"
            "     tool_path: /tools/Xilinx/Vivado/2024.2\n"
            "   ```"
        ),
    },
    "quartus not found": {
        "cause": "Quartus is not in PATH and hardware.tool_path is not set",
        "fix": (
            "Either:\n"
            "1. Add Quartus to PATH: `export PATH=$PATH:/intelFPGA_pro/24.4/quartus/bin`\n"
            "2. Set tool_path in project.yml:\n"
            "   ```yaml\n"
            "   hardware:\n"
            "     tool_path: /intelFPGA_pro/24.4\n"
            "   ```"
        ),
    },
    "lockfile": {
        "cause": "routertl.lock is missing or out of date",
        "fix": "Run `rr lock resolve` to regenerate the lockfile.",
    },
    "dependency": {
        "cause": "Missing or conflicting IP dependency",
        "fix": (
            "1. Run `rr deps` to see the dependency graph\n"
            "2. Run `rr pkg install` to install missing packages\n"
            "3. Run `rr lock resolve` to re-resolve dependencies"
        ),
    },
    "compile order": {
        "cause": "HDL source files are being compiled in the wrong order",
        "fix": (
            "Never use alphabetic/sorted glob ordering for HDL files. "
            "routertl's dependency resolver handles compile order automatically. "
            "If you're seeing compile errors:\n"
            "1. Check `rr deps` for missing dependencies\n"
            "2. Ensure all `include` directives map to files in your source list\n"
            "3. Run `rr linting` to catch undeclared modules"
        ),
    },
    "simulation": {
        "cause": "Simulation setup or execution issue",
        "fix": (
            "1. Run `rr doctor` to check cocotb/simulator installation\n"
            "2. Run `rr scan-tests` to verify test discovery\n"
            "3. Check `rr sim --help` for simulator-specific options\n"
            "4. View logs with `rr viewlog`"
        ),
    },
    "synthesis": {
        "cause": "Synthesis failed or produced unexpected results",
        "fix": (
            "1. Run `rr linting` first to catch RTL issues\n"
            "2. Check `rr rules check` for design rule violations\n"
            "3. Review the synthesis log: `rr viewlog`\n"
            "4. Run `rr report` for resource utilization"
        ),
    },
    "registry": {
        "cause": "Cannot connect to or authenticate with the IP registry",
        "fix": (
            "1. Check connectivity: `rr pkg search test`\n"
            "2. Re-authenticate: `rr pkg login`\n"
            "3. Check index URL: `rr config` (look for index_url/packages_index)\n"
            "4. Default registry: registry.routertl.dev"
        ),
    },
}


@mcp.tool()
def rr_diagnose(error_text: str) -> str:
    """Diagnose a routertl error and suggest fixes.

    Args:
        error_text: The error message, traceback, or description of the
                    problem. Can be a raw error output or a description
                    like "synthesis failed" or "can't find vivado".
    """
    error_lower = error_text.lower()

    # Match against known error patterns
    matched = []
    for pattern, info in _COMMON_ERRORS.items():
        if pattern in error_lower:
            matched.append((pattern, info))

    lines = ["# Diagnosis\n"]

    if matched:
        for pattern, info in matched:
            lines.append(f"## Matched: {pattern}")
            lines.append(f"**Cause:** {info['cause']}")
            lines.append(f"\n**Fix:**\n{info['fix']}\n")
    else:
        lines.append("No known pattern matched. Here's what to try:\n")
        lines.append("1. Run `rr doctor` to check your environment")
        lines.append("2. Run `rr status` to verify project state")
        lines.append("3. Run with verbose mode: `rr -v <command>`")
        lines.append("4. Check the log: `rr viewlog`")

    # Also run rr doctor for live diagnostics
    lines.append("\n## Live Doctor Check\n")
    lines.append("```")
    lines.append(_run_rr("doctor"))
    lines.append("```")

    return "\n".join(lines)


# =====================================================================
# TOOL: rr_rules_check — design rules evaluation
# =====================================================================


@mcp.tool()
def rr_rules_check(strict: bool = False) -> str:
    """Run design rules check on the current project.

    Evaluates FPGA design rules scoped by vendor, tool, and tool version.
    Catches dangerous IP property values, vendor mismatches, and known
    pitfalls.

    Args:
        strict: If True, treat warnings as errors (CI mode).
    """
    args = ["rules", "check", "--json"]
    if strict:
        args.append("--strict")
    return _run_rr(*args)


# =====================================================================
# TOOL: rr_rules_list — list available design rules
# =====================================================================


@mcp.tool()
def rr_rules_list() -> str:
    """List all available FPGA design rules.

    Shows the rules database with their scope (vendor, tool, version),
    severity, and description. Rules are sourced from real incidents
    and vendor errata.
    """
    return _run_rr("rules", "list")


# =====================================================================
# TOOL: rr_rules_add — file a new design rule from a debugging session
# =====================================================================


@mcp.tool()
def rr_rules_add(
    rule_id: str,
    message: str,
    incident: str,
    severity: str = "warning",
    property: str = "",
    condition: str = "",
    fix: str = "",
) -> str:
    """Add a design rule to the project's ip_rules.yml.

    Use this after debugging an FPGA issue to capture the knowledge as a
    persistent, automatically-checkable rule.  Every rule MUST have an
    incident story — the real bug that inspired it.

    Args:
        rule_id: Unique rule ID, e.g. "CUSTOM-001" or "CDC-003".
        message: What this rule checks for (one sentence).
        incident: The bug story — what happened, how long it took to find,
                  what was misleading.  This is the most important field.
        severity: "error", "warning", or "info" (default: "warning").
        property: IP/design property name to check (optional).
        condition: Trigger condition, e.g. "== 0", "missing" (optional).
        fix: How to fix the issue (optional but recommended).
    """
    args = [
        "rules", "add",
        "--id", rule_id,
        "--severity", severity,
        "--message", message,
        "--incident", incident,
    ]
    if property:
        args.extend(["--property", property])
    if condition:
        args.extend(["--condition", condition])
    if fix:
        args.extend(["--fix", fix])
    return _run_rr(*args)


# =====================================================================
# TOOL: rr_ask — FPGA knowledge base query
# =====================================================================


@mcp.tool()
def rr_ask(
    question: str,
    search_only: bool = False,
    mode: str = "hybrid",
    top_k: int = 5,
) -> str:
    """Ask the FPGA knowledge base (fpgawisdom.com) a question.

    Queries a curated corpus of 11.5K+ AMD/Xilinx community expert posts
    and returns an AI-synthesised answer with source citations.

    Args:
        question: Natural language FPGA question. Examples:
                  "how do I safely cross clock domains",
                  "what causes metastability",
                  "timing constraints for DDR interfaces".
        search_only: If True, return raw search results instead of a
                     synthesised answer.
        mode: Search strategy — "hybrid" (default), "semantic", or "keyword".
        top_k: Number of source documents to retrieve (default: 5).
    """
    try:
        # Import the ask module's helpers directly for structured output
        from sdk.cli.commands.ask import _get_search, _post_query

        if search_only:
            data = _get_search(question, mode=mode, k=top_k)
            results = data.get("results", [])
            if not results:
                return f"No results found for: {question}"

            lines = [f"# Search Results: {question}\n"]
            for i, r in enumerate(results, 1):
                title = r.get("title", "untitled")
                author = r.get("author", "")
                date = r.get("date", "")
                score = r.get("score", 0.0)
                content = r.get("content", "")[:300]
                url = r.get("url", "")
                tier = r.get("author_tier", "")

                tier_badge = ""
                if tier == "God":
                    tier_badge = " ★"
                elif tier == "Legend":
                    tier_badge = " ◆"

                lines.append(f"## {i}. {title}")
                lines.append(f"**{author}**{tier_badge} · {date} · score: {score:.2f}")
                if url:
                    lines.append(f"URL: {url}")
                lines.append(f"\n{content}...\n")

            return "\n".join(lines)
        else:
            data = _post_query(question, mode=mode, k=top_k, use_llm=True)
            answer = data.get("answer", "No answer generated.")
            sources = data.get("sources", [])
            model = data.get("model", "unknown")

            lines = [f"# Answer\n\n{answer}\n"]

            if sources:
                lines.append("\n## Sources\n")
                for src in sources:
                    idx = src.get("index", "")
                    title = src.get("title", "untitled")
                    author = src.get("author", "")
                    date = src.get("date", "")
                    url = src.get("url", "")
                    line = f"{idx}. **{title}** — {author} ({date})"
                    if url:
                        line += f" [{url}]"
                    lines.append(line)

            lines.append(f"\n*Model: {model} · fpgawisdom.com*")
            return "\n".join(lines)

    except (ImportError, OSError, ValueError, KeyError) as exc:
        return f"Error querying fpgawisdom.com: {exc}"


# =====================================================================
# TOOL: rr_doctor — environment health check
# =====================================================================


@mcp.tool()
def rr_doctor() -> str:
    """Run a health check on the development environment.

    Checks for common issues: missing EDA tools, Python dependencies,
    simulator availability, project configuration problems, and
    stale lockfiles.
    """
    return _run_rr("doctor")


# =====================================================================
# TOOL: rr_status — project status snapshot
# =====================================================================


@mcp.tool()
def rr_status() -> str:
    """Get a quick status snapshot of the current project.

    Shows active target, toolchain, source count, IP dependencies,
    and lockfile state.
    """
    return _run_rr("status")


# =====================================================================
# TOOL: rr_deps — dependency graph
# =====================================================================


@mcp.tool()
def rr_deps() -> str:
    """Show the dependency graph for the current project.

    Displays HDL module dependencies, IP package dependencies,
    and any circular or missing references.
    """
    return _run_rr("deps", "show")


# =====================================================================
# RESOURCE: routertl://commands — command reference
# =====================================================================


@mcp.resource("routertl://commands")
def resource_commands() -> str:
    """Complete routertl CLI command reference."""
    lines = ["# routertl CLI Command Reference\n"]
    for cmd, desc in _COMMAND_TREE.items():
        lines.append(f"- `rr {cmd}` — {desc}")

    lines.append("\n## Package Manager Subcommands\n")
    for sub, desc in _PKG_SUBCOMMANDS.items():
        lines.append(f"- `rr pkg {sub}` — {desc}")

    return "\n".join(lines)


# =====================================================================
# RESOURCE: routertl://project — current project summary
# =====================================================================


@mcp.resource("routertl://project")
def resource_project() -> str:
    """Current project configuration summary."""
    config = _load_project_config_safe()
    if not config:
        return "No project.yml found in current directory."

    import yaml
    return yaml.dump(config, default_flow_style=False, sort_keys=False)


# =====================================================================
# TOOL: rr_ip_contract_get — read declared contract for an IP
# =====================================================================


@mcp.tool()
def rr_ip_contract_get(ip_dir: str) -> str:
    """Return the declared requirements.yml for an IP as readable markdown.

    Reads the ``requirements.yml`` sibling to ``ip.yml`` under *ip_dir* and
    formats it as a markdown summary covering the declared port contract
    (slave/master bundles, scalars, clocks, resets), parameters, and
    functional_contract[] REQ-N anchors.  Use before scaffolding or editing
    tests to see what the IP promises.

    Args:
        ip_dir: Directory containing the IP's ``requirements.yml``.

    Returns:
        Markdown.  Error text if the file is missing or invalid.
    """
    try:
        from sdk.cli.requirements import (
            RequirementsValidationError,
            load_requirements,
        )
    except ImportError as exc:
        return f"Error: unable to import requirements loader ({exc})"

    req_path = Path(ip_dir) / "requirements.yml"
    if not req_path.is_file():
        return f"Error: no requirements.yml found at {req_path}"
    import yaml as _yaml
    try:
        requirements = load_requirements(req_path)
    except RequirementsValidationError as exc:
        msg = "\n".join(f"  - {e}" for e in exc.errors)
        return f"requirements.yml at {req_path} failed validation:\n{msg}"
    except (FileNotFoundError, OSError, _yaml.YAMLError) as exc:
        return f"Error loading {req_path}: {exc}"

    lines: list[str] = []
    lines.append(f"# Contract for `{requirements.ip}`")
    lines.append("")
    lines.append(f"**Source:** `{req_path}`  ")
    lines.append(f"**Schema version:** {requirements.version}")
    lines.append("")
    lines.append("## Port contract")
    lines.append("")
    lines.append(f"- **Slaves** ({len(requirements.port_contract.slaves)}): "
                 + (", ".join(f"`{b.name}` ({b.protocol})"
                              for b in requirements.port_contract.slaves) or "_none_"))
    lines.append(f"- **Masters** ({len(requirements.port_contract.masters)}): "
                 + (", ".join(f"`{b.name}` ({b.protocol})"
                              for b in requirements.port_contract.masters) or "_none_"))
    lines.append(f"- **Scalars** ({len(requirements.port_contract.scalars)}): "
                 + (", ".join(f"`{s.name}` ({s.direction}, {s.width})"
                              for s in requirements.port_contract.scalars) or "_none_"))
    lines.append("- **Clocks**: "
                 + (", ".join(f"`{c.name}`" for c in requirements.port_contract.clocks) or "_none_"))
    lines.append("- **Resets**: "
                 + (", ".join(f"`{r.name}` ({r.polarity})"
                              for r in requirements.port_contract.resets) or "_none_"))
    lines.append("")
    if requirements.parameters:
        lines.append("## Parameters")
        lines.append("")
        for p in requirements.parameters:
            lines.append(f"- `{p.name}` = `{p.default}`")
        lines.append("")
    if requirements.inherit:
        lines.append("## Inherits from")
        lines.append("")
        for uri in requirements.inherit:
            lines.append(f"- `{uri}`")
        lines.append("")
    lines.append("## Functional contract")
    lines.append("")
    if not requirements.functional_contract:
        lines.append("_No REQs declared yet._")
    else:
        for req in requirements.functional_contract:
            marker = "!" if req.kind == "negative" else "•"
            tag = f" _(from `{req.source}`)_" if req.source else ""
            lines.append(
                f"- {marker} **{req.id}** _({req.kind})_{tag} — {req.desc}"
            )
    return "\n".join(lines)


# =====================================================================
# TOOL: rr_ip_contract_check — enforce the declared contract against HDL
# =====================================================================


@mcp.tool()
def rr_ip_contract_check(ip_dir: str = "") -> str:
    """Diff declared requirements.yml against parsed HDL.

    Shells out to ``rr sim contract-check``.  With no *ip_dir*, walks the
    current working directory for every ``requirements.yml`` and checks
    each.  Reports shape mismatches (slave/master bundle counts, missing
    or orphan bundles, protocol drift, scalar/clock/reset discrepancies)
    per IP.  Non-zero exit inside the shell-out surfaces as output only
    (the MCP tool returns the diagnostic text).

    This is the shape gate — the structural half of the contract-first
    loop.  Pair with ``rr_ip_coverage`` for the behavioural half.

    Args:
        ip_dir: Optional directory of a single IP.  Empty = walk project.

    Returns:
        Markdown / plain text — one block per IP with `[OK]` or `[FAIL]`.
    """
    args = ["sim", "contract-check"]
    if ip_dir:
        args.append(ip_dir)
    return _run_rr(*args)


# =====================================================================
# TOOL: rr_ip_coverage — diff declared REQs vs @requires-tagged tests
# =====================================================================


@mcp.tool()
def rr_ip_coverage(ip_dir: str = "") -> str:
    """Diff declared REQs against @requires-tagged cocotb tests.

    Shells out to ``rr sim coverage-map``.  Walks cocotb tests for
    ``@requires("REQ-N")`` decorators, builds a REQ → tests matrix, and
    flags any declared REQ that no test carries (missing) or any tag that
    doesn't correspond to a declared REQ (orphan).

    This is the behavioural gate — the proof-of-claim half of the
    contract-first loop.  Pair with ``rr_ip_contract_check`` for shape.

    Args:
        ip_dir: Optional directory of a single IP.  Empty = walk project.

    Returns:
        Per-IP coverage matrix with `[OK]` or `[FAIL]` headers and
        per-REQ ✓/✗ markers.
    """
    args = ["sim", "coverage-map"]
    if ip_dir:
        args.append(ip_dir)
    return _run_rr(*args)


# =====================================================================
# TOOL: rr_ip_contract_init — scaffold a requirements.yml from HDL
# =====================================================================


@mcp.tool()
def rr_ip_contract_init(
    hdl_path: str,
    ip_name: str = "",
    write: bool = False,
    out_path: str = "",
    force: bool = False,
) -> str:
    """Scaffold a requirements.yml from an HDL entity/module.

    Parses *hdl_path*, classifies ports into AXIS/AXI bundles + scalars
    + clocks + resets, and renders a requirements.yml scaffold that
    mirrors the **current** HDL shape.  A WARNING banner at the top
    reminds the author the scaffold reflects implementation, not intent
    — review every entry before committing.

    This is the fourth member of the contract-first quartet.  Pair with
    ``rr_ip_contract_get`` (read declared contract), ``rr_ip_contract_check``
    (structural diff vs HDL), and ``rr_ip_coverage`` (behavioural diff vs
    cocotb @requires tags).

    Args:
        hdl_path: Path to the HDL source (.sv/.v/.vhd/.vhdl).
        ip_name: Value for the scaffold's ``ip:`` field.  Defaults to the
                 HDL filename stem.
        write: If True, persist the scaffold to disk.  If False (default),
               return the rendered text so the agent can review first.
        out_path: Override path when write=True.  Defaults to
                  ``<dirname(hdl_path)>/requirements.yml``.
        force: With write=True, overwrite an existing file.  Without this
               flag a write that would clobber existing content fails
               safe — the scaffold is still returned so the agent can
               diff manually.

    Returns:
        The rendered scaffold text.  When write=True, the trailing line
        reports the written path (or the refusal reason).
    """
    try:
        from sdk.engine.contract_init import init_contract
    except ImportError as exc:
        return f"Error: unable to import contract_init ({exc})"

    hdl = Path(hdl_path)
    if not hdl.is_file():
        return f"Error: HDL file not found at {hdl}"

    resolved_ip = ip_name or hdl.stem
    try:
        scaffold = init_contract(hdl, resolved_ip)
    except (OSError, ValueError) as exc:
        return f"Error scaffolding from {hdl}: {exc}"

    if not write:
        return scaffold

    target = Path(out_path) if out_path else hdl.parent / "requirements.yml"
    if target.exists() and not force:
        return (
            f"{scaffold}\n"
            f"# Refused to overwrite {target} — pass force=True to replace it."
        )
    try:
        target.write_text(scaffold)
    except OSError as exc:
        return f"{scaffold}\n# Error writing {target}: {exc}"
    return f"{scaffold}\n# Wrote scaffold → {target}"


# =====================================================================
# SIM ASSET DISCOVERY — drivers / monitors / fakes / contracts
# =====================================================================
# These tools expose routertl's cocotb verification scaffolding
# (sim/cocotb/tb/ + sim/cocotb/fakes/) as discoverable, queryable assets.
# They complement rr_pkg_search (RTL IP discovery) with verification-IP
# discovery — any AI agent building an FPGA testbench can now ask
# "what monitors does routertl ship for Avalon-MM?" and get a grounded
# answer with clause IDs and source-file pointers.
#
# Backlog: RTL-P2.447 (Phase 6 of the cocotb tb/ revival).


_SIM_COCOTB_ROOT = _pkg_dir / "sim" / "cocotb"
_TB_DRIVERS_DIR = _SIM_COCOTB_ROOT / "tb" / "drivers"
_TB_MONITORS_DIR = _SIM_COCOTB_ROOT / "tb" / "monitors"
_TB_CONTRACTS_DIR = _SIM_COCOTB_ROOT / "tb" / "contracts"
_FAKES_DIR = _SIM_COCOTB_ROOT / "fakes"


def _extract_module_docstring(path: Path, max_lines: int = 20) -> str:
    """Best-effort: grab the first triple-quoted docstring from a Python file.

    Returns the first ``max_lines`` of the docstring or the file's first
    comment block if there's no docstring.
    """
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return "(unreadable)"
    lines = text.splitlines()
    # Look for triple-quoted docstring
    in_doc = False
    quote = None
    collected: list[str] = []
    for ln in lines:
        stripped = ln.strip()
        if not in_doc:
            if stripped.startswith('"""') or stripped.startswith("'''"):
                quote = stripped[:3]
                in_doc = True
                after = stripped[3:]
                if after.endswith(quote) and len(stripped) >= 6:
                    # Single-line docstring
                    return after[: -len(quote)].strip() or "(empty)"
                if after:
                    collected.append(after)
                continue
        else:
            if quote and stripped.endswith(quote):
                collected.append(stripped[: -len(quote)])
                break
            collected.append(ln)
            if len(collected) >= max_lines:
                collected.append("…")
                break
    return "\n".join(collected).strip() or "(no docstring)"


def _extract_sv_header(path: Path, max_lines: int = 25) -> str:
    """Extract the leading ``//`` comment block from a SystemVerilog file."""
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return "(unreadable)"
    collected: list[str] = []
    for ln in text.splitlines():
        stripped = ln.strip()
        if stripped.startswith("//"):
            collected.append(stripped[2:].lstrip())
            if len(collected) >= max_lines:
                collected.append("…")
                break
        elif stripped == "":
            if collected:
                continue
        else:
            break
    return "\n".join(collected).strip() or "(no header comment)"


def _extract_clause_ids(path: Path, prefixes: tuple[str, ...]) -> list[str]:
    """Scan a Python source file for clause IDs matching the given prefixes.

    Looks for string literals like "AVL_WR_HOLD", "TSE_RDATA_WINDOW", etc.
    Deduplicates and returns sorted.
    """
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return []
    import re

    pattern = re.compile(r'"((?:' + "|".join(prefixes) + r')[A-Z_][A-Z_0-9]*)"')
    found: set[str] = set()
    for m in pattern.finditer(text):
        found.add(m.group(1))
    return sorted(found)


# ---------------------------------------------------------------------
# TOOL: rr_sim_drivers
# ---------------------------------------------------------------------


@mcp.tool()
def rr_sim_drivers() -> str:
    """List cocotb drivers shipped by routertl.

    Drivers are Python BFMs that actively stimulate a DUT's bus interface.
    Use these to drive Avalon-MM / AXI4 / AXI-Lite / SPI / I2C / UART /
    native-memory master or slave transactions in your cocotb tests.
    Import pattern: ``from tb.drivers.<name> import <ClassName>``.
    """
    if not _TB_DRIVERS_DIR.is_dir():
        return f"No drivers directory at {_TB_DRIVERS_DIR}"
    lines = ["# routertl cocotb drivers (tb/drivers/)\n"]
    for f in sorted(_TB_DRIVERS_DIR.glob("*.py")):
        if f.name.startswith("_") or f.name == "__init__.py":
            continue
        doc = _extract_module_docstring(f, max_lines=4)
        first_line = (doc.splitlines() or ["(no docstring)"])[0]
        lines.append(f"- **`tb.drivers.{f.stem}`** — {first_line}")
    lines.append(
        "\n_Call `rr_sim_contract <name>` on a driver's corresponding "
        "monitor to see the full protocol spec it drives against._"
    )
    return "\n".join(lines)


# ---------------------------------------------------------------------
# TOOL: rr_sim_monitors
# ---------------------------------------------------------------------


@mcp.tool()
def rr_sim_monitors() -> str:
    """List passive protocol monitors shipped by routertl.

    Monitors attach to a bus and raise ``ProtocolViolation`` whenever a
    spec-defined invariant is broken. They observe only; they do not drive.
    Compose with ``TbEnv.attach_monitors`` and assert ``check_monitors()``
    at end-of-test for one-line contract gating.
    """
    if not _TB_MONITORS_DIR.is_dir():
        return f"No monitors directory at {_TB_MONITORS_DIR}"
    # Clause prefix map — extend here when new monitors land.
    clause_prefix_map = {
        "avalon_mm_monitor.py": ("AVL_",),
        "avalon_streaming_monitor.py": ("AST_",),
        "axi_lite_monitor.py": ("AXI_",),
        "tse_mac_monitor.py": ("TSE_", "AVL_"),  # TSE composes AVL
    }
    lines = ["# routertl cocotb monitors (tb/monitors/)\n"]
    for f in sorted(_TB_MONITORS_DIR.glob("*.py")):
        if f.name.startswith("_"):
            continue
        doc = _extract_module_docstring(f, max_lines=2)
        first = (doc.splitlines() or ["(no docstring)"])[0]
        prefixes = clause_prefix_map.get(f.name, ("",))
        clauses = (
            _extract_clause_ids(f, prefixes) if prefixes != ("",) else []
        )
        header = f"- **`tb.monitors.{f.stem}`** — {first}"
        lines.append(header)
        if clauses:
            lines.append(f"  - Clauses: `{'`, `'.join(clauses)}`")
    lines.append(
        "\n_Call `rr_sim_contract <monitor_name>` for the full protocol "
        "spec including port requirements, parameters, and clause semantics._"
    )
    return "\n".join(lines)


# ---------------------------------------------------------------------
# TOOL: rr_sim_fakes
# ---------------------------------------------------------------------


@mcp.tool()
def rr_sim_fakes() -> str:
    """List adversarial SV fakes shipped by routertl.

    Fakes are working models of vendor IP with realistic timing AND known
    failure modes (registered arbiter races, wedge states, reset asymmetry).
    Distinct from trivial mocks — fakes stress-test bridges against what
    real silicon actually does, catching bugs that pass against idealised
    stubs.
    """
    if not _FAKES_DIR.is_dir():
        return f"No fakes directory at {_FAKES_DIR}"
    lines = ["# routertl cocotb fakes (sim/cocotb/fakes/)\n"]
    for f in sorted(_FAKES_DIR.glob("*.sv")):
        header = _extract_sv_header(f, max_lines=4)
        first = (header.splitlines() or ["(no header)"])[0]
        # First non-SPDX line
        for ln in header.splitlines():
            if ln and not ln.startswith("SPDX-"):
                first = ln
                break
        lines.append(f"- **`{f.name}`** — {first}")
    # Also surface the README if present
    readme = _FAKES_DIR / "README.md"
    if readme.is_file():
        lines.append(f"\n_See `{readme.name}` for the fake-vs-mock rationale "
                     f"and promotion criteria._")
    return "\n".join(lines)


# ---------------------------------------------------------------------
# TOOL: rr_sim_contract — full contract spec for a monitor
# ---------------------------------------------------------------------


@mcp.tool()
def rr_sim_contract(name: str) -> str:
    """Return the full contract specification for a monitor.

    Args:
        name: Contract name, e.g. ``"tse_mac"``, ``"avalon_mm"``. Matches
              the filename (without .md) under ``tb/contracts/``.

    Returns the complete markdown spec: ports observed, parameters,
    clauses enforced (with semantics and violation messages), non-goals,
    and composition examples. Source-of-truth for what the monitor does
    and does not verify — use this when deciding whether a clause covers
    your specific bridge behaviour.
    """
    if not _TB_CONTRACTS_DIR.is_dir():
        return f"No contracts directory at {_TB_CONTRACTS_DIR}"

    # Accept both "tse_mac", "tse_mac.md", and "TSEMACMonitor" style inputs
    candidates = [
        _TB_CONTRACTS_DIR / f"{name}.md",
        _TB_CONTRACTS_DIR / f"{name.lower()}.md",
        _TB_CONTRACTS_DIR / name,
    ]
    # Try a stripped variant: TSEMACMonitor → tse_mac
    stripped = name.lower().replace("monitor", "").rstrip("_")
    if stripped:
        candidates.append(_TB_CONTRACTS_DIR / f"{stripped}.md")

    for path in candidates:
        if path.is_file():
            try:
                return path.read_text(encoding="utf-8")
            except OSError as exc:
                return f"Error reading {path}: {exc}"

    # Not found — list what's available
    available = sorted(p.stem for p in _TB_CONTRACTS_DIR.glob("*.md"))
    if available:
        return (
            f"Contract '{name}' not found. Available contracts:\n"
            + "\n".join(f"- {n}" for n in available)
        )
    return f"No contracts in {_TB_CONTRACTS_DIR} (directory empty)."


# =====================================================================
# Entry point
# =====================================================================


def run():
    """Entry point for the routertl-mcp command."""
    import argparse

    parser = argparse.ArgumentParser(description="RouteRTL MCP Server")
    parser.add_argument(
        "--sse", action="store_true", help="Use SSE transport instead of stdio"
    )
    parser.add_argument(
        "--port", type=int, default=8750, help="Port for SSE transport (default: 8750)"
    )
    args = parser.parse_args()

    if args.sse:
        mcp.run(transport="sse")
    else:
        mcp.run()


if __name__ == "__main__":
    run()
