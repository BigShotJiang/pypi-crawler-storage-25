# SPDX-FileCopyrightText: 2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Protocol contract library — canonical REQ sets for standard buses.

Each ``*.requirements.yml`` file in this directory is a shared REQ
library transcribed from a published interface specification (Intel
Avalon, ARM AMBA, Wishbone, etc.).  IP-level ``requirements.yml`` files
pull these in via ``inherit: [routertl:protocol_contracts/<name>]``.

The ``__init__.py`` is a sentinel so setuptools packages this directory
into the pip wheel — without it, the shipped libraries would be absent
from the installed SDK (RTL-P2.130 regression guard).
"""
