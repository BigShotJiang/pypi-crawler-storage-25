# === RouteRTL SDK — Register Bank & ROM Targets ===
# Requires: platform.mk (SDK_ROOT, ROOT_DIR, SRC_DIR, REGBANK_UTILS, etc.)

# ====================================================================================
# 📚 Register Bank & ROM
# ====================================================================================
REGBANK_YAML    ?= project_regbank.yml
# SRC_DIR can be multi-valued (e.g. "src libs") when packages are installed.
# Regbank artefacts always live under the primary source directory.
_PRIMARY_SRC    := $(firstword $(SRC_DIR))
REGBANK_PKG     ?= $(_PRIMARY_SRC)/pkg/system_regbank_pkg.vhd
LOCK_FILE       ?= routertl.lock
LOCK_HEX        ?= misc/lock.hex

.PHONY: lock
lock: $(LOCK_FILE) ## Resolve project state and write routertl.lock

$(LOCK_FILE):
	@python3 -c "from sdk.engine.lockfile import resolve_project_state, write_lockfile; \
		write_lockfile(resolve_project_state('.'), '.')"

# If the project doesn't have a regbank yaml, we might skip this or error?
# For now, we assume if REGBANK_YAML exists, we use it.

.PHONY: parse_regbank
parse_regbank: ## Generate VHDL package from Regbank YAML
	@if [ -f $(REGBANK_YAML) ]; then \
		echo "Parsing $(REGBANK_YAML)..."; \
		python3 $(REGBANK_UTILS)/generate_regbank_pkg.py $(REGBANK_YAML) $(REGBANK_PKG); \
	else \
		echo "No register bank YAML found at $(REGBANK_YAML). Skipping."; \
	fi

.PHONY: add-register
add-register: ## Add a new register to the register bank (interactive)
	@python3 $(REGBANK_UTILS)/add_register.py $(REGBANK_YAML)

.PHONY: remove-register
remove-register: ## Remove a register from the register bank (Usage: make remove-register NAME=reg_name)
	@if [ -z "$(NAME)" ]; then \
		echo "❌ Error: NAME not specified. Use 'make remove-register NAME=reg_name'"; \
		exit 1; \
	fi
	@python3 $(REGBANK_UTILS)/remove_register.py $(REGBANK_YAML) $(NAME)

# ── Build metadata (always available) ────────────────────────────────────────
# Stamps git hash, build date, system version into rom_info_pkg.
# Language-aware: generates .vhd, .sv, or both based on HDL_LANGUAGE.

.PHONY: build_metadata rom_info
rom_info: build_metadata  ## Backward-compat alias

# ROM Data Generation Dependencies (used in full regbank mode)
REGBANK_HEX      ?= $(_PRIMARY_SRC)/regbank/regbank_schema.hex
CONFIG_HEX       ?= $(_PRIMARY_SRC)/regbank/config_schema.hex
SYS_CONFIG_RTL   ?= $(_PRIMARY_SRC)/pkg/system_config_pkg$(HDL_EXT)
REGBANK_CONST_PY ?= $(VERIFICATION_DIR)/constants.py

misc/lock.hex: $(wildcard $(LOCK_FILE))
	@mkdir -p misc
	@if [ -f $(LOCK_FILE) ]; then \
		echo "Encoding $(LOCK_FILE) → hex..."; \
		python3 $(REGBANK_UTILS)/payload_encoder.py $(LOCK_FILE) --raw-source text --hex $@ --bin misc/lock.bin; \
	else \
		echo "No $(LOCK_FILE) found — generating empty lock.hex"; \
		: > $@; \
	fi

# Placeholder rules for generated hex files — ensures Make does not fail
# in clean clones (CI) where these have not been generated yet.
$(REGBANK_HEX):
	@mkdir -p $(dir $@)
	@: > $@

$(CONFIG_HEX):
	@mkdir -p $(dir $@)
	@: > $@

ifeq ($(CONFIG_ENABLE_REGBANK), true)
# Full regbank mode: build metadata + schema word counts
build_metadata: $(REGBANK_HEX) $(CONFIG_HEX) misc/lock.hex ## Stamp build metadata into rom_info_pkg
	@python3 $(REGBANK_UTILS)/gen_build_metadata.py $(ROOT_DIR) \
		--language $(HDL_LANGUAGE) \
		--regbank-yml $(REGBANK_YAML) \
		--regbank-hex $(REGBANK_HEX) \
		--config-hex $(CONFIG_HEX) \
		$(if $(wildcard $(LOCK_HEX)),--lock-hex $(LOCK_HEX))
	@echo "Generating Python constants..."
	@python3 $(REGBANK_UTILS)/generate_constants.py $(REGBANK_YAML) $(REGBANK_CONST_PY)

REGBANK_DEPS := build_metadata parse_regbank
else
# Minimal mode: build metadata only (git hash, date, version)
build_metadata: ## Stamp build metadata into rom_info_pkg
	@python3 $(REGBANK_UTILS)/gen_build_metadata.py $(ROOT_DIR) \
		--language $(HDL_LANGUAGE) \
		$(if $(wildcard $(REGBANK_YAML)),--regbank-yml $(REGBANK_YAML))

REGBANK_DEPS := build_metadata
endif
