# === RouteRTL SDK — Synthesis, FPGA & Docker Targets ===
# Requires: platform.mk (SDK_ROOT, ROOT_DIR, VENDOR, tool paths, etc.)

# ====================================================================================
# 🔧 Pre-Build Hooks
# ====================================================================================

# --- LFS Guard ---
# Netlist files (.qxp/.qdb/.edf) shipped via Git LFS are 132-byte pointer
# stubs until `git lfs pull` is run.  Passing a stub to Quartus/Vivado
# produces cryptic errors.  This guard catches the problem early.
.PHONY: check-lfs
check-lfs:
	@for f in $(NETLIST_FILES); do \
		if [ -f "$$f" ] && head -1 "$$f" 2>/dev/null | grep -q '^version https://git-lfs'; then \
			echo "❌ LFS file not pulled: $$f"; \
			echo "   Run: git lfs pull"; \
			exit 1; \
		fi; \
	done
	@# Safety net: scan tree for netlist files not in NETLIST_FILES
	@for f in $$(find $(ROOT_DIR) -type f \( -name '*.qxp' -o -name '*.qdb' -o -name '*.dcp' -o -name '*.edf' -o -name '*.ngo' \) \
		-not -path '*/\.git/*' -not -path '*/sim_build/*' 2>/dev/null); do \
		if head -1 "$$f" 2>/dev/null | grep -q '^version https://git-lfs'; then \
			echo "❌ LFS netlist stub detected: $$f"; \
			echo "   Run: git lfs pull"; \
			exit 1; \
		fi; \
	done

.PHONY: pre-build
pre-build: ## Run pre-build code generation hooks from project.yml
	@python3 $(SDK_ROOT)/sdk/engine/run_prebuild_hooks.py --project $(PROJECT_YML) --root $(ROOT_DIR)

# ====================================================================================
# 🏭 Vendor Flow
# ====================================================================================

# Default Fallbacks in case build_env.mk is broken/missing
TOOL_CMD ?= vivado
GEN_PROJECT_TCL ?= $(SDK_ROOT)/tcl/$(VENDOR)/gen_project.tcl
SYNTH_TCL ?= $(SDK_ROOT)/tcl/$(VENDOR)/gen_synthesis.tcl
IMPL_TCL ?= $(SDK_ROOT)/tcl/$(VENDOR)/gen_implementation.tcl
BITSTREAM_TCL ?= $(SDK_ROOT)/tcl/$(VENDOR)/gen_bitstream.tcl

# Dynamically construct the project file path and TCL invocation syntax based on vendor
#
# NOTE: For Xilinx, TOOL_CMD resolves to $(VIVADO_XLNX) (set by
# supported_vendors.yml → build_env.mk), which platform.mk defines with
# -mode batch -nolog -nojournal -notrace -source flags.  Do NOT append
# batch flags here — they are already in TOOL_CMD.

ifeq ($(VENDOR), xilinx)
    PROJECT_FILE = $(vivado_prj)
    # Vivado passes args to TCL using -tclargs
    TCL_INVOKE = $(TOOL_CMD) $(GEN_PROJECT_TCL) -tclargs
    TCL_RUN = $(TOOL_CMD)
    TCL_FLAG = -tclargs
else ifeq ($(VENDOR), lattice)
    PROJECT_FILE = $(lattice_prj)
    TCL_INVOKE = $(TOOL_CMD) $(GEN_PROJECT_TCL)
    TCL_RUN = $(TOOL_CMD)
    TCL_FLAG =
else ifeq ($(VENDOR), altera)
    PROJECT_FILE = $(altera_prj)
    # Quartus passes args to TCL using -t script.tcl arg1 arg2
    TCL_INVOKE = $(TOOL_CMD) -t $(GEN_PROJECT_TCL)
    TCL_RUN = $(TOOL_CMD) -t
    TCL_FLAG = 
else ifeq ($(VENDOR), microchip)
    PROJECT_FILE = $(libero_prj)
    TCL_INVOKE = $(TOOL_CMD) SCRIPT:$(GEN_PROJECT_TCL) SCRIPT_ARGS:
    TCL_RUN = $(TOOL_CMD) SCRIPT:
    TCL_FLAG = SCRIPT_ARGS:
else ifeq ($(VENDOR), opensource)
    PROJECT_FILE =
    # Open-source flow uses Python driver scripts (not TCL)
    TCL_INVOKE = python3 $(GEN_PROJECT_TCL)
    TCL_RUN = python3
    TCL_FLAG =
endif

# Project generation recipe — invoked by the 'project' target in Common.mk.
# Not a file target: Common.mk runs 'clean' first to ensure no stale QSF.
build-project:
	@echo "🏗  Building $(VENDOR) Project..."
	@mkdir -p $(build_path)
	$(TCL_INVOKE) $(ROOT_DIR) "$(SYN_FILES)" "$(IP_FILES)" "$(SIM_FILES)" "$(TCL_FILES)" "$(if $(SDC_FILES),$(SDC_FILES),$(XDC_FILES))" "$(NETLIST_FILES)"

npm-synthesis: build_env.mk $(REGBANK_DEPS) ## Run Non-Project Mode Synthesis (Usage: make npm-synthesis TOP=top_module)
	@if [ -z "$(TOP)" ]; then \
		echo "❌ TOP module not specified for npm-synthesis."; \
		exit 1; \
	fi
	@mkdir -p dcp
	@echo "🔍 Resolving dependencies for $(TOP)..."
	$(eval NPM_FILES := $(shell python3 $(SDK_ROOT)/sdk/engine/dependency_resolver.py --src $(SRC_DIR) --top $(TOP) --list-libs))
	@if [ -z "$(NPM_FILES)" ]; then \
		echo "❌ Error: No dependencies found for $(TOP). Check entity name and paths."; \
		exit 1; \
	fi
	@echo "🚀 Synthesizing $(TOP) in Non-Project Mode..."
	@TOOL_BIN=$$(echo "$(TOOL_CMD)" | awk '{print $$1}'); \
	if ! command -v "$$TOOL_BIN" >/dev/null 2>&1; then \
		echo "❌ Error: Vendor tool '$$TOOL_BIN' not found in PATH."; \
		echo "   VENDOR=$(VENDOR), TOOL_CMD=$(TOOL_CMD)"; \
		if [ "$(VENDOR)" = "opensource" ]; then \
			echo ""; \
			echo "   Easiest fix — use the Docker path (no host install):"; \
			echo "     rr docker install sim    # one-time image build"; \
			echo "     rr docker shell sim      # drop into the container"; \
			echo "     rr synth run             # run synth inside"; \
			echo ""; \
			echo "   Host install guide: docs/guides/vendors/OPENSOURCE.md"; \
		else \
			echo "   Hint: Is the $(VENDOR) toolchain installed? Run 'routertl doctor' to diagnose."; \
		fi; \
		exit 1; \
	fi
	@$(TCL_RUN) $(SDK_ROOT)/tcl/$(VENDOR)/non_project_mode.tcl $(TCL_FLAG) $(ROOT_DIR) "$(NPM_FILES)" "$(IP_FILES)" "$(if $(SDC_FILES),$(SDC_FILES),$(XDC_FILES))" $(TOP) "$(NETLIST_FILES)"
	@if [ -f $(ROOT_DIR)/dcp/$(TOP)/$(TOP)_synthesis.dcp ]; then \
		echo "✅ Synthesis successfully completed. DCP created at dcp/$(TOP)/$(TOP)_synthesis.dcp"; \
	elif [ -d $(ROOT_DIR)/dcp/$(TOP) ]; then \
		echo "✅ Synthesis successfully completed. Check dcp/$(TOP)/ for reports."; \
	else \
		echo "❌ Synthesis failed. No output generated."; \
		exit 1; \
	fi

synthesis: check-lfs update-config $(REGBANK_DEPS) ## Run Synthesis
	@if [ "$(VENDOR)" = "xilinx" ] && [ "$(SDK_HAS_VIVADO)" != "true" ] && [ -z "$(VIVADO_PATH)" ]; then \
		echo "❌ Vivado not found on PATH — required for VENDOR=xilinx"; \
		exit 1; \
	elif [ "$(VENDOR)" = "altera" ] && [ "$(SDK_HAS_QUARTUS_SH)" != "true" ]; then \
		echo "❌ Quartus not found on PATH — required for VENDOR=altera"; \
		exit 1; \
	elif [ "$(VENDOR)" = "microchip" ] && [ "$(SDK_HAS_LIBERO)" != "true" ]; then \
		echo "❌ Libero SoC not found on PATH — required for VENDOR=microchip"; \
		exit 1; \
	elif [ "$(VENDOR)" = "opensource" ] && ! command -v yosys >/dev/null 2>&1; then \
		echo "❌ Yosys not found on PATH — required for VENDOR=opensource"; \
		exit 1; \
	fi
	@echo "🚀 Synthesizing Project..."
	$(TCL_RUN) $(SYNTH_TCL) $(TCL_FLAG) $(ROOT_DIR)
	@# Record successfully synthesized FPGA part
	@mkdir -p "$(ROOT_DIR)/.routertl"; \
	PARTS_FILE="$(ROOT_DIR)/.routertl/known_parts.txt"; \
	ENTRY="$(VENDOR) $(FPGA_PART)"; \
	if [ ! -f "$$PARTS_FILE" ]; then \
		echo "# RouteRTL — Known FPGA Parts (auto-updated by make synthesis)" > "$$PARTS_FILE"; \
		echo "# Format: <vendor> <part>" >> "$$PARTS_FILE"; \
	fi; \
	grep -qxF "$$ENTRY" "$$PARTS_FILE" 2>/dev/null || echo "$$ENTRY" >> "$$PARTS_FILE"

implementation: update-config ## Run Implementation
	@echo "🚀 Running Implementation..."
	@$(TCL_RUN) $(IMPL_TCL) $(TCL_FLAG) $(ROOT_DIR)

bitstream: update-config ## Generate Bitstream
	@echo "🚀 Generating Bitstream..."
	@$(TCL_RUN) $(BITSTREAM_TCL) $(TCL_FLAG) $(ROOT_DIR)

# ====================================================================================
# 🐳 Docker Development Environment
# ====================================================================================
DOCKER_ENV ?= sim
DOCKER_SCRIPT := $(SDK_ROOT)/sdk/infra/docker/docker.sh

.PHONY: docker-help docker-build docker-shell docker-run

docker-help: ## Show Docker environment help
	@$(DOCKER_SCRIPT) help

docker-build: ## Build Docker image (DOCKER_ENV=sim|vivado|buildroot)
	@$(DOCKER_SCRIPT) build $(DOCKER_ENV)

docker-shell: ## Start interactive shell in Docker container
	-@$(DOCKER_SCRIPT) shell $(DOCKER_ENV)

docker-run: ## Run command in Docker (Usage: make docker-run CMD="make simulation")
	@$(DOCKER_SCRIPT) run $(DOCKER_ENV) "$(CMD)"
