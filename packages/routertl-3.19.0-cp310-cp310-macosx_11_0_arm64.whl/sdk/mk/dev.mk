# === RouteRTL SDK — Developer / Maintainer Targets ===
# Targets here are for RouteRTL SDK developers, NOT for SDK consumers.
# SDK consumers use: rr sim, rr waves, rr synth, rr impl, etc.
# SDK developers use: make cythonize, make clean-so, make regression, etc.
#
# Included by Common.mk alongside sim.mk, synthesis.mk, etc.

# ====================================================================================
# 🔧 Cython Development Helpers
# ====================================================================================

## clean-so: Remove compiled .so files so Python .py sources take import precedence.
## Use this after local Cython smoke testing — the CI wheel build (build-wheels.yml)
## is the canonical way to produce and verify distribution artifacts.
.PHONY: clean-so
clean-so:
	@echo "🧹 Removing local Cython .so files (restoring .py source precedence)..."
	@count=0; \
	for f in $$(find routertl_core -name "*.cpython-*.so" -o -name "*.pyd" 2>/dev/null); do \
		echo "  rm $$f"; rm -f "$$f"; count=$$((count + 1)); \
	done; \
	echo "✅ Removed $$count .so file(s). Python sources now preferred for all routertl_core imports."
	@echo "   Run 'make cythonize' to rebuild compiled artifacts locally."

## cythonize: Compile routertl_core Python sources to Cython .c snapshots.
## Commits the .c files so CI can build wheels without a Cython install.
## NEVER deletes .py sources — aborts if any sentinel file is missing post-run.
.PHONY: cythonize
cythonize:
	@echo "🔬 Cythonizing routertl_core/ (SDK maintainer task)..."
	@command -v cython >/dev/null 2>&1 || { \
		echo "❌ Cython not found. Install with: pip install 'Cython>=3.0'"; exit 1; }
	$(SDK_ROOT)/sdk/scripts/cythonize.py

# ====================================================================================
# 🚀 Release Targets
# ====================================================================================

## bump-version: Bump the SDK version in pyproject.toml and routertl_core/__init__.py.
## Usage: make bump-version VERSION=3.5.0
## Triggered by: the maintainer (human decision), before make cythonize.
## Full release flow: make bump-version → make cythonize → git commit → git tag → push
.PHONY: bump-version
bump-version:
	@test -n "$(VERSION)" || { echo "❌ Usage: make bump-version VERSION=x.y.z"; exit 1; }
	@echo "🔖 Bumping version to $(VERSION)..."
	$(SDK_ROOT)/sdk/scripts/bump_version.py $(VERSION)
