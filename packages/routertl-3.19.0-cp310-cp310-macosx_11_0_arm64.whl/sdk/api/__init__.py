# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT
"""RouteRTL public SDK API — stable, hook-script-safe utilities."""
