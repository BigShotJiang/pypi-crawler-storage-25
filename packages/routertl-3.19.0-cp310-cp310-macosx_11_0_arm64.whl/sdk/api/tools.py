# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT
"""Public hook API — vendor tool resolution and project config helpers.

P2.123: Canonical home for tool resolution helpers used by pre-build hooks,
license.py, status.py, and external scripts.  This module deliberately has
zero SDK dependencies so it can be imported by standalone hook scripts.
"""

from __future__ import annotations

import os
import shutil
from pathlib import Path

try:
    import yaml as _yaml
except ImportError:
    _yaml = None  # type: ignore[assignment]


# ---------------------------------------------------------------------------
# Project config helpers
# ---------------------------------------------------------------------------


def load_project_config(path: str | os.PathLike | None = None) -> dict:
    """Load and return a project.yml as a dict.

    Parameters
    ----------
    path:
        Path to the YAML file.  When *None*, defaults to ``project.yml``
        in the current working directory.

    Returns
    -------
    dict
        Parsed YAML content, or an empty dict on any error.
    """
    if path is None:
        path = Path.cwd() / "project.yml"
    try:
        if _yaml is None:
            return {}
        with open(path, "r") as fh:
            data = _yaml.safe_load(fh)
        return data if isinstance(data, dict) else {}
    except (OSError, TypeError, getattr(_yaml, "YAMLError", Exception)):
        return {}


def get_hardware_config(*, config: dict | None = None) -> dict:
    """Return the ``hardware`` section of *config* as a dict.

    Parameters
    ----------
    config:
        Parsed project.yml dict.  When *None*, loads from ``project.yml``
        in the current working directory.

    Returns
    -------
    dict
        The ``hardware`` section, or an empty dict when absent or invalid.
    """
    if config is None:
        config = load_project_config()
    hw = config.get("hardware", {})
    return hw if isinstance(hw, dict) else {}


def get_project_root(start: str | os.PathLike | None = None) -> Path | None:
    """Walk up the directory tree to find the project root (directory
    containing ``project.yml``).

    Parameters
    ----------
    start:
        Directory to start from.  Defaults to the current working directory.

    Returns
    -------
    Path | None
        Resolved project root, or *None* when not found.
    """
    current = Path(start).resolve() if start is not None else Path.cwd().resolve()
    for directory in [current, *current.parents]:
        if (directory / "project.yml").exists():
            return directory
    return None


# ---------------------------------------------------------------------------
# Tool resolution
# ---------------------------------------------------------------------------


def resolve_tool_path(*, config: dict | None = None) -> str | None:
    """Return ``hardware.tool_path`` from *config*, or *None*.

    Parameters
    ----------
    config:
        Parsed project.yml dict.  When *None*, loads from ``project.yml``
        in the current working directory.
    """
    hw = get_hardware_config(config=config)
    val = hw.get("tool_path")
    return str(val) if val else None


def resolve_tool_binary(
    binary_name: str,
    *,
    config: dict | None = None,
) -> str | None:
    """Find a vendor tool binary, preferring ``hardware.tool_path`` over PATH.

    Resolution order:
    1. ``<tool_path>/<binary_name>``                                — direct placement
    2. ``<tool_path>/bin/<binary_name>``                            — standard Unix layout
    3. ``<tool_path>/quartus/bin/<binary_name>``                    — Quartus-specific layout
    4. ``<tool_path>/quartus/sopc_builder/bin/<binary_name>``       — Quartus Qsys tools
    5. ``<tool_path>/sopc_builder/bin/<binary_name>``               — Altera Std top-level Qsys
    6. ``<tool_path>/niosv/bin/<binary_name>``                      — Altera NiosV tools
    7. ``shutil.which(binary_name)``                                — system PATH fallback

    Parameters
    ----------
    binary_name:
        The executable to find (e.g. ``"quartus_sh"``, ``"vivado"``).
    config:
        Parsed project.yml dict.  When *None*, loads from ``project.yml``
        in the current working directory.

    Returns
    -------
    str | None
        Absolute path to the binary, or *None* when not found.
    """
    if config is None:
        config = load_project_config()

    tool_path = resolve_tool_path(config=config)
    if tool_path:
        base = Path(tool_path)
        candidates = [
            base / binary_name,
            base / "bin" / binary_name,
            base / "quartus" / "bin" / binary_name,
            # Altera Qsys / SOPC Builder — qsys-generate, qsys-script,
            # ip-generate live here on Quartus Std/Pro (RTL-P2.312).
            base / "quartus" / "sopc_builder" / "bin" / binary_name,
            base / "sopc_builder" / "bin" / binary_name,
            base / "niosv" / "bin" / binary_name,
        ]
        for candidate in candidates:
            if candidate.is_file() and os.access(candidate, os.X_OK):
                return str(candidate)

    # PATH fallback
    found = shutil.which(binary_name)
    return found if found else None
