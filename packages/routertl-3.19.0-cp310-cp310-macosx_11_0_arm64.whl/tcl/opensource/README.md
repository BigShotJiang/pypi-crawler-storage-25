# Open-Source FPGA Toolchain Backend

Yosys + nextpnr synthesis flow for RouteRTL. Supports iCE40, ECP5, and
Gowin FPGA families using the free/libre open-source toolchain.

## Toolchain

| Phase          | Tool            | Families        |
|----------------|-----------------|-----------------|
| Synthesis      | Yosys           | All             |
| Place & Route  | nextpnr-{family}| ice40, ecp5, gowin |
| Bitstream      | icepack/ecppack | ice40, ecp5     |

## project.yml Configuration

```yaml
hardware:
  vendor: opensource
  part: ice40-hx8k-ct256   # {family}-{device}-{package}

sources:
  syn:
    - src/top.v
  pcf:
    - constraints/pins.pcf
```

### Part String Format

`{family}-{device}-{package}` — parsed into nextpnr binary + flags:

| Part String           | nextpnr Command                              |
|-----------------------|----------------------------------------------|
| `ice40-hx8k-ct256`   | `nextpnr-ice40 --hx8k --package ct256`       |
| `ice40-up5k-sg48`    | `nextpnr-ice40 --up5k --package sg48`        |
| `ecp5-25k-cabga256`  | `nextpnr-ecp5 --25k --package CABGA256`      |
| `gowin-gw1n-9c-qfn88`| `nextpnr-gowin --device gw1n-9c-qfn88`      |

### Constraint Formats

- **iCE40**: `.pcf` (Physical Constraints File)
- **ECP5**: `.lpf` (Lattice Preference File)
- **Gowin**: `.cst` (Constraint File)

## Flow Scripts

| Script                  | Language | Purpose                           |
|-------------------------|----------|-----------------------------------|
| `environment.tcl`       | TCL      | Environment variable setup        |
| `gen_synthesis.tcl`     | Yosys TCL| Yosys synthesis (via `yosys -c`)  |
| `gen_implementation.py` | Python   | nextpnr place & route driver      |
| `gen_bitstream.py`      | Python   | Bitstream packer driver           |
| `parts.py`              | Python   | Part string → nextpnr flag mapper |

## Usage

```bash
# Full build
rr synth run

# Individual phases
rr synth run          # Synthesis only (Yosys)
rr build impl         # Place & route (nextpnr)
rr build bitstream    # Bitstream (icepack/ecppack)

# Check synthesis status
rr synth status
```

## Installing the Toolchain

```bash
# Ubuntu/Debian
sudo apt install yosys nextpnr fpga-icestorm

# macOS
brew install yosys nextpnr icestorm

# From source
# See: https://github.com/YosysHQ/oss-cad-suite-build
```

## Backlog Reference

- **RTL-P2.271**: Implement Yosys/nextpnr synthesis flow
- **RTL-P4.5**: Docker overlay for open-source toolchain
