#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Yosys synthesis driver for the open-source FPGA toolchain.

Invoked by VendorDispatch as the synthesis phase for vendor=opensource.
Reads source files, runs synthesis via Yosys (+ standalone GHDL for VHDL),
and writes a JSON netlist for nextpnr.

Two paths:
  - **Verilog/SV only**: Yosys handles everything directly.
  - **Has VHDL**: standalone GHDL compiles VHDL to Verilog, then Yosys
    maps to the target architecture. (The GHDL Yosys plugin has a
    known bug with multi-library VHDL — duplicate module registration.)

Usage::

    python gen_synthesis.py <root_dir> [src_files] [constraints] [top_module]

Environment variables (set by build_env.mk / VendorDispatch):
    FPGA_PART   — RouteRTL part string (e.g. "ice40-hx8k-ct256")
    TOP_MODULE  — Top-level module name (fallback if not in argv)
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from parts import parse_part

# Map family → Yosys synth command
_SYNTH_CMD = {
    "ice40": "synth_ice40",
    "ecp5": "synth_ecp5",
    "gowin": "synth_gowin",
}


def _classify_sources(src_tokens: list[str]) -> tuple[
    dict[str, list[str]],  # vhdl_libs: {lib_name: [files]}
    list[str],             # verilog_files
]:
    """Split source tokens into VHDL (by library) and Verilog lists.

    Tokens arrive as "lib:path" from the dependency resolver, or bare
    paths (assigned to "work" library).
    """
    vhdl_libs: dict[str, list[str]] = {}
    verilog_files: list[str] = []

    for token in src_tokens:
        # Split lib:path on the first colon
        if ":" in token:
            lib, path = token.split(":", 1)
        else:
            lib, path = "work", token

        ext = Path(path).suffix.lower()
        if ext in (".vhd", ".vhdl"):
            vhdl_libs.setdefault(lib, []).append(path)
        elif ext in (".v", ".sv"):
            verilog_files.append(path)

    return vhdl_libs, verilog_files


def _run_ghdl_synth(
    vhdl_libs: dict[str, list[str]],
    top_module: str,
    output_verilog: Path,
) -> int:
    """Run standalone GHDL to compile VHDL sources to Verilog.

    Steps:
      1. ghdl -a --work=<lib> <files>   (for each library)
      2. ghdl synth --out=verilog <top>  (elaborate + synthesize)

    Returns 0 on success.
    """
    if not shutil.which("ghdl"):
        print(
            "❌ ghdl not found on PATH.\n"
            "   VHDL designs require GHDL for the open-source flow.\n"
            "   Install: sudo apt install ghdl   (or use rr docker shell)"
        )
        return 1

    # Analyze libraries in order: non-work libraries first, then work
    for lib_name, files in vhdl_libs.items():
        if lib_name == "work":
            continue
        cmd = ["ghdl", "-a", "--std=08", f"--work={lib_name}"] + files
        print(f"   ghdl -a --work={lib_name} ({len(files)} files)")
        result = subprocess.run(cmd, check=False)
        if result.returncode != 0:
            print(f"❌ GHDL analysis failed for library '{lib_name}'")
            return result.returncode

    # Analyze work library files
    work_files = vhdl_libs.get("work", [])
    if work_files:
        cmd = ["ghdl", "-a", "--std=08"] + work_files
        print(f"   ghdl -a --work=work ({len(work_files)} files)")
        result = subprocess.run(cmd, check=False)
        if result.returncode != 0:
            print("❌ GHDL analysis failed for work library")
            return result.returncode

    # Synthesize to Verilog
    cmd = [
        "ghdl", "synth", "--std=08", "--no-formal",
        "--out=verilog", top_module,
    ]
    print(f"   ghdl synth --out=verilog {top_module}")
    with open(output_verilog, "w") as f:
        result = subprocess.run(cmd, stdout=f, stderr=subprocess.PIPE, check=False)
    if result.returncode != 0:
        err = (result.stderr or b"").decode().strip()
        print(f"❌ GHDL synthesis failed for '{top_module}'")
        if err:
            print(f"   {err}")
        return result.returncode

    lines = sum(1 for _ in open(output_verilog))
    print(f"   GHDL → {lines} lines of Verilog")
    return 0


def _run_yosys_synth(
    verilog_files: list[str],
    top_module: str,
    synth_cmd: str,
    json_out: Path,
) -> tuple[int, str]:
    """Run Yosys synthesis on Verilog sources.

    Returns (exit_code, yosys_stdout).
    """
    if not shutil.which("yosys"):
        print(
            "❌ yosys not found on PATH.\n"
            "   Install: sudo apt install yosys   (or use rr docker shell)"
        )
        return 1, ""

    # Build Yosys script
    cmds = []
    for f in verilog_files:
        if f.endswith(".sv"):
            cmds.append(f"read_verilog -sv {f}")
        else:
            cmds.append(f"read_verilog {f}")

    cmds.append(f"{synth_cmd} -top {top_module} -json {json_out}")
    cmds.append("stat")

    script = "; ".join(cmds)
    print(f"   yosys: {synth_cmd} -top {top_module}")

    result = subprocess.run(
        ["yosys", "-q", "-p", script],
        capture_output=True, text=True, check=False,
    )

    if result.returncode != 0:
        print("❌ Yosys synthesis failed")
        if result.stderr:
            # Show last few lines of error
            for line in result.stderr.strip().splitlines()[-5:]:
                print(f"   {line}")

    return result.returncode, result.stdout


def _parse_yosys_stat(stdout: str) -> dict[str, int]:
    """Extract cell counts from Yosys stat output.

    Looks for lines like:
        393   SB_LUT4
         39   SB_DFF
    """
    resources = {}
    import re
    for m in re.finditer(r"^\s+(\d+)\s+(SB_\w+|LUT|DFF|CARRY)", stdout, re.MULTILINE):
        count = int(m.group(1))
        name = m.group(2)
        if name not in resources or count > resources[name]:
            resources[name] = count
    return resources


def run_synthesis(root_dir: Path, part_str: str, top_module: str) -> int:
    """Run the full open-source synthesis flow.

    Returns 0 on success.
    """
    part = parse_part(part_str)
    synth_cmd = _SYNTH_CMD.get(part.family)
    if not synth_cmd:
        print(f"❌ Unsupported family '{part.family}' for synthesis")
        return 1

    # Output paths
    out_dir = root_dir / "dcp" / top_module
    out_dir.mkdir(parents=True, exist_ok=True)
    report_dir = root_dir / "reports"
    report_dir.mkdir(parents=True, exist_ok=True)
    json_out = out_dir / f"{top_module}.json"

    print("═══════════════════════════════════════════════════════")
    print("  Open-Source Synthesis (Yosys)")
    print(f"  Top module : {top_module}")
    print(f"  Part       : {part_str}")
    print(f"  Target     : {synth_cmd}")
    print("═══════════════════════════════════════════════════════")

    # Parse source files from build_env.mk or command-line
    src_tokens = _get_source_tokens(root_dir)
    if not src_tokens:
        print("❌ No source files found")
        return 1

    vhdl_libs, verilog_files = _classify_sources(src_tokens)
    has_vhdl = any(vhdl_libs.values())

    t0 = time.monotonic()

    if has_vhdl:
        # VHDL path: standalone GHDL → Verilog → Yosys
        print("\n📄 VHDL sources detected — using standalone GHDL")
        ghdl_verilog = out_dir / f"{top_module}_ghdl.v"

        rc = _run_ghdl_synth(vhdl_libs, top_module, ghdl_verilog)
        if rc != 0:
            return rc

        # Feed GHDL output + any pure-Verilog files to Yosys
        all_verilog = [str(ghdl_verilog)] + verilog_files
        print(f"\n🔧 Yosys: mapping to {part.family}")
        rc, stdout = _run_yosys_synth(all_verilog, top_module, synth_cmd, json_out)
    else:
        # Pure Verilog path: Yosys handles everything
        print("\n📄 Verilog-only design")
        print(f"\n🔧 Yosys: {synth_cmd}")
        rc, stdout = _run_yosys_synth(verilog_files, top_module, synth_cmd, json_out)

    duration = time.monotonic() - t0

    if rc != 0:
        return rc

    if not json_out.exists():
        print("❌ No JSON netlist produced")
        return 1

    # Parse resource stats from Yosys output
    resources = _parse_yosys_stat(stdout)

    print(f"\n✅ Synthesis complete ({duration:.1f}s): {json_out}")
    if resources:
        for name, count in sorted(resources.items()):
            print(f"   {name}: {count}")

    # Write synthesis report
    _emit_report(report_dir, part_str, top_module, duration, resources)

    return 0


def _get_source_tokens(root_dir: Path) -> list[str]:
    """Get source file tokens from environment or build_env.mk.

    Falls back to scanning project.yml sources.syn if available.
    """
    # From command-line args (passed by Make)
    if len(sys.argv) >= 3 and sys.argv[2]:
        return sys.argv[2].split()

    # From SYN_FILES environment variable
    syn_files = os.environ.get("SYN_FILES", "")
    if syn_files:
        return syn_files.split()

    # Fall back to scanning project.yml
    project_yml = root_dir / "project.yml"
    if project_yml.exists():
        try:
            import yaml
        except ImportError:
            # Try basic parsing
            return _parse_sources_basic(project_yml)
        with open(project_yml) as f:
            config = yaml.safe_load(f)
        sources = config.get("sources", {})
        return sources.get("syn", [])

    return []


def _parse_sources_basic(project_yml: Path) -> list[str]:
    """Basic project.yml source list parser (no PyYAML dependency)."""
    sources: list[str] = []
    in_syn = False
    for line in project_yml.read_text().splitlines():
        stripped = line.strip()
        if stripped == "syn:":
            in_syn = True
            continue
        if in_syn:
            if stripped.startswith("- "):
                sources.append(stripped[2:].strip())
            elif stripped and not stripped.startswith("#"):
                break  # End of syn list
    return sources


def _emit_report(
    report_dir: Path,
    part_str: str,
    top_module: str,
    duration: float,
    resources: dict[str, int],
) -> None:
    """Write a synthesis stats JSON report."""
    report = {
        "vendor": "opensource",
        "part": part_str,
        "top_module": top_module,
        "tool_name": "Yosys",
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%S"),
        "phases": [
            {"name": "Synthesis", "passed": True, "duration_s": round(duration, 2)},
        ],
        "resources": {
            name: {"used": count, "available": 0}
            for name, count in resources.items()
        },
    }
    report_path = report_dir / "yosys_synth_stats.json"
    report_path.write_text(json.dumps(report, indent=2) + "\n")
    print(f"📊 Synthesis report: {report_path}")


def main() -> int:
    if len(sys.argv) < 2:
        print("Usage: gen_synthesis.py <root_dir> [src_files] [constraints] [top_module]")
        return 1

    root_dir = Path(sys.argv[1])
    part_str = os.environ.get("FPGA_PART", "")
    top_module = os.environ.get("TOP_MODULE", "")

    # Top module can also come from argv
    if not top_module and len(sys.argv) >= 5:
        top_module = sys.argv[4]

    if not part_str:
        print("❌ FPGA_PART environment variable not set.")
        return 1

    if not top_module:
        print("❌ TOP_MODULE not set. Set project.top_module in project.yml")
        return 1

    return run_synthesis(root_dir, part_str, top_module)


if __name__ == "__main__":
    sys.exit(main())
