#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Open-source FPGA part number mapping for nextpnr.

Parses RouteRTL part strings of the form ``{family}-{device}-{package}``
into the binary name, device flags, and bitstream packer command for the
Yosys + nextpnr open-source toolchain.

Usage::

    >>> from parts import parse_part
    >>> p = parse_part("ice40-hx8k-ct256")
    >>> p.nextpnr_bin   # "nextpnr-ice40"
    >>> p.nextpnr_args  # ["--hx8k", "--package", "ct256"]
    >>> p.packer_cmd    # ["icepack"]
    >>> p.synth_target  # "ice40"
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class PartInfo:
    """Resolved part information for the open-source toolchain."""

    family: str           # "ice40", "ecp5", "gowin"
    device: str           # "hx8k", "25k", "gw1n-9c"
    package: str          # "ct256", "cabga256", "qfn88"
    nextpnr_bin: str = ""
    nextpnr_args: list[str] = field(default_factory=list)
    packer_cmd: list[str] = field(default_factory=list)
    packer_ext: str = ""  # output extension: ".bin", ".bit", ".fs"
    synth_target: str = ""  # Yosys synth command: "ice40", "ecp5", "gowin"


# ── Family-specific resolvers ────────────────────────────────────


def _resolve_ice40(device: str, package: str) -> PartInfo:
    """Resolve an iCE40 part.

    Device strings: lp384, lp1k, lp4k, lp8k, hx1k, hx4k, hx8k, up5k, u4k
    """
    return PartInfo(
        family="ice40",
        device=device,
        package=package,
        nextpnr_bin="nextpnr-ice40",
        nextpnr_args=[f"--{device}", "--package", package],
        packer_cmd=["icepack"],
        packer_ext=".bin",
        synth_target="ice40",
    )


def _resolve_ecp5(device: str, package: str) -> PartInfo:
    """Resolve an ECP5 part.

    Device strings: 12k, 25k, 45k, 85k
    """
    return PartInfo(
        family="ecp5",
        device=device,
        package=package,
        nextpnr_bin="nextpnr-ecp5",
        nextpnr_args=[f"--{device}", "--package", package.upper()],
        packer_cmd=["ecppack"],
        packer_ext=".bit",
        synth_target="ecp5",
    )


def _resolve_gowin(device: str, package: str) -> PartInfo:
    """Resolve a Gowin part.

    Device strings vary widely (gw1n-1, gw1n-9c, gw2a-18c, etc.).
    nextpnr-gowin uses --device with the full Gowin device string.
    """
    return PartInfo(
        family="gowin",
        device=device,
        package=package,
        nextpnr_bin="nextpnr-gowin",
        nextpnr_args=["--device", f"{device}-{package}"],
        packer_cmd=["gowin_pack"],
        packer_ext=".fs",
        synth_target="gowin",
    )


# ── Public API ───────────────────────────────────────────────────


_FAMILY_RESOLVERS = {
    "ice40": _resolve_ice40,
    "ecp5": _resolve_ecp5,
    "gowin": _resolve_gowin,
}

SUPPORTED_FAMILIES = list(_FAMILY_RESOLVERS.keys())


def parse_part(part_str: str) -> PartInfo:
    """Parse a RouteRTL part string into nextpnr invocation parameters.

    Format: ``{family}-{device}-{package}``

    Examples::

        ice40-hx8k-ct256     → nextpnr-ice40 --hx8k --package ct256
        ice40-up5k-sg48      → nextpnr-ice40 --up5k --package sg48
        ecp5-25k-cabga256    → nextpnr-ecp5 --25k --package CABGA256
        ecp5-85k-cabga381    → nextpnr-ecp5 --85k --package CABGA381
        gowin-gw1n-9c-qfn88  → nextpnr-gowin --device gw1n-9c-qfn88

    Raises
    ------
    ValueError
        If the part string format is invalid or the family is unsupported.
    """
    if not part_str:
        raise ValueError("Empty part string")

    parts = part_str.lower().split("-", 2)
    if len(parts) < 3:
        raise ValueError(
            f"Invalid part format '{part_str}': expected "
            f"'{{family}}-{{device}}-{{package}}' "
            f"(e.g. 'ice40-hx8k-ct256')"
        )

    family = parts[0]
    # For gowin, the device can contain hyphens (gw1n-9c), so we need
    # to split the remainder differently
    if family == "gowin":
        remainder = parts[1] + "-" + parts[2] if len(parts) > 2 else parts[1]
        # Last segment is the package
        segs = remainder.rsplit("-", 1)
        if len(segs) < 2:
            raise ValueError(
                f"Invalid Gowin part '{part_str}': cannot determine package"
            )
        device, package = segs
    else:
        device = parts[1]
        package = parts[2]

    resolver = _FAMILY_RESOLVERS.get(family)
    if resolver is None:
        raise ValueError(
            f"Unsupported FPGA family '{family}'. "
            f"Supported: {', '.join(SUPPORTED_FAMILIES)}"
        )

    return resolver(device, package)
