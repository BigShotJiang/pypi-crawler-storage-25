#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""nextpnr place & route driver for the open-source FPGA toolchain.

Invoked by VendorDispatch after Yosys synthesis. Takes the JSON netlist
produced by gen_synthesis.tcl and runs nextpnr for the target device.

Usage::

    python gen_implementation.py <root_dir>

Environment variables (set by build_env.mk / VendorDispatch):
    FPGA_PART   — RouteRTL part string (e.g. "ice40-hx8k-ct256")
    TOP_MODULE  — Top-level module name (optional, for reporting)
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

# Allow importing parts.py from the same directory
sys.path.insert(0, str(Path(__file__).parent))
from parts import parse_part


def find_netlist(root_dir: Path, top_module: str) -> Path | None:
    """Locate the JSON netlist produced by Yosys synthesis."""
    # Primary location: dcp/<top>/<top>.json
    primary = root_dir / "dcp" / top_module / f"{top_module}.json"
    if primary.exists():
        return primary

    # Fallback: search dcp/ for any .json
    dcp_dir = root_dir / "dcp"
    if dcp_dir.exists():
        jsons = list(dcp_dir.rglob("*.json"))
        if jsons:
            return jsons[0]

    return None


def find_constraints(root_dir: Path) -> list[Path]:
    """Find PCF constraint files in the project."""
    pcf_files = []

    # Check standard constraint directories
    for dirname in ("constraints", "xdc", "constr"):
        cdir = root_dir / dirname
        if cdir.exists():
            pcf_files.extend(cdir.glob("*.pcf"))

    # Also check project root
    pcf_files.extend(root_dir.glob("*.pcf"))

    return pcf_files


def run_nextpnr(
    root_dir: Path,
    part_str: str,
    top_module: str,
) -> int:
    """Run nextpnr place & route and emit a unified report.

    Returns the process exit code (0 = success).
    """
    part = parse_part(part_str)

    # Locate netlist
    netlist = find_netlist(root_dir, top_module)
    if netlist is None:
        print(
            f"❌ No JSON netlist found for '{top_module}'.\n"
            "   Run synthesis first: rr synth run"
        )
        return 1

    # Check nextpnr is available
    if not shutil.which(part.nextpnr_bin):
        print(
            f"❌ {part.nextpnr_bin} not found on PATH.\n"
            f"   Install the open-source FPGA toolchain:\n"
            f"   • Ubuntu/Debian: sudo apt install nextpnr fpga-icestorm\n"
            f"   • macOS: brew install nextpnr\n"
            f"   • Or use: rr docker shell (when Docker overlay is available)"
        )
        return 1

    # Output paths
    out_dir = root_dir / "dcp" / top_module
    out_dir.mkdir(parents=True, exist_ok=True)
    report_dir = root_dir / "reports"
    report_dir.mkdir(parents=True, exist_ok=True)

    # Determine output extension based on family
    if part.family == "ice40":
        routed_ext = ".asc"
    elif part.family == "ecp5":
        routed_ext = ".config"
    elif part.family == "gowin":
        routed_ext = ".pack"
    else:
        routed_ext = ".routed"

    routed_out = out_dir / f"{top_module}{routed_ext}"
    report_json = out_dir / f"{top_module}_pnr_report.json"

    # Find constraints
    pcf_files = find_constraints(root_dir)

    # Build nextpnr command
    cmd = [
        part.nextpnr_bin,
        "--json", str(netlist),
        "--report", str(report_json),
    ] + part.nextpnr_args

    # Add constraint file(s)
    if pcf_files:
        # nextpnr-ice40 uses --pcf, ecp5 uses --lpf, gowin uses --cst
        if part.family == "ice40":
            cmd.extend(["--pcf", str(pcf_files[0])])
        elif part.family == "ecp5":
            # ECP5 uses .lpf constraints, but we accept .pcf too
            cmd.extend(["--lpf", str(pcf_files[0])])
        elif part.family == "gowin":
            cmd.extend(["--cst", str(pcf_files[0])])
        if len(pcf_files) > 1:
            print(
                f"   ⚠ Multiple constraint files found; using {pcf_files[0].name}"
            )
    else:
        print("   ⚠ No constraint files found — running unconstrained P&R")

    # Add output file
    if part.family == "ice40":
        cmd.extend(["--asc", str(routed_out)])
    elif part.family == "ecp5":
        cmd.extend(["--textcfg", str(routed_out)])
    elif part.family == "gowin":
        cmd.extend(["--write", str(routed_out)])

    print(f"\n🔧 Running {part.nextpnr_bin}...")
    print(f"   → {' '.join(cmd[:6])}...")

    t0 = time.monotonic()
    result = subprocess.run(cmd, check=False)
    duration = time.monotonic() - t0

    if result.returncode != 0:
        print(f"\n❌ {part.nextpnr_bin} failed (exit code {result.returncode})")
        _emit_build_report(
            report_dir, part_str, top_module, duration,
            passed=False, pnr_report=report_json,
        )
        return result.returncode

    print(f"\n✅ Place & route complete ({duration:.1f}s): {routed_out}")

    # Emit unified build report
    _emit_build_report(
        report_dir, part_str, top_module, duration,
        passed=True, pnr_report=report_json,
    )

    return 0


def _emit_build_report(
    report_dir: Path,
    part_str: str,
    top_module: str,
    duration: float,
    passed: bool,
    pnr_report: Path | None = None,
) -> None:
    """Write a unified build_report.json from nextpnr's output.

    nextpnr's --report JSON contains:
    - utilization.{resource_type}.{available, used}
    - fmax.{clock_name}.achieved
    """
    report = {
        "vendor": "opensource",
        "part": part_str,
        "top_module": top_module,
        "tool_name": f"nextpnr ({part_str.split('-')[0]})",
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%S"),
        "warnings": 0,
        "errors": 0 if passed else 1,
        "phases": [
            {"name": "Place & Route", "passed": passed, "duration_s": round(duration, 2)},
        ],
        "resources": {},
        "timing": {
            "fmax_mhz": 0.0,
            "clock_name": "",
            "wns_ns": 0.0,
            "tns_ns": 0.0,
            "met": True,
        },
    }

    # Parse nextpnr's report JSON if available
    if pnr_report and pnr_report.exists():
        try:
            pnr_data = json.loads(pnr_report.read_text())

            # Extract utilization
            util = pnr_data.get("utilization", {})
            for res_name, res_data in util.items():
                if isinstance(res_data, dict):
                    report["resources"][res_name] = {
                        "used": res_data.get("used", 0),
                        "available": res_data.get("available", 0),
                    }

            # Extract timing (fmax)
            fmax_data = pnr_data.get("fmax", {})
            best_fmax = 0.0
            best_clock = ""
            for clock_name, clock_data in fmax_data.items():
                if isinstance(clock_data, dict):
                    achieved = clock_data.get("achieved", 0.0)
                    if achieved > best_fmax:
                        best_fmax = achieved
                        best_clock = clock_name
            if best_fmax > 0:
                report["timing"]["fmax_mhz"] = round(best_fmax, 2)
                report["timing"]["clock_name"] = best_clock

            # Extract critical path / slack if available
            crit_path = pnr_data.get("critical_path", {})
            if crit_path:
                slack = crit_path.get("slack", 0.0)
                report["timing"]["wns_ns"] = round(slack, 3)
                report["timing"]["met"] = slack >= 0.0

        except (json.JSONDecodeError, OSError) as exc:
            print(f"   ⚠ Could not parse nextpnr report: {exc}")

    # Merge with any existing Yosys synthesis report
    yosys_stats = report_dir / "yosys_synth_stats.json"
    if yosys_stats.exists():
        try:
            ydata = json.loads(yosys_stats.read_text())
            # Yosys report has the tool_name; combine them
            report["tool_name"] = f"Yosys + {report['tool_name']}"
            # Prepend synthesis phase
            report["phases"].insert(0, {
                "name": "Synthesis",
                "passed": True,
                "duration_s": 0.0,  # captured separately by synth_tracker
            })
        except (json.JSONDecodeError, OSError):
            pass

    # Write unified report
    report_path = report_dir / "build_report.json"
    report_path.write_text(json.dumps(report, indent=2) + "\n")
    print(f"📊 Build report: {report_path}")


def main() -> int:
    if len(sys.argv) < 2:
        print("Usage: gen_implementation.py <root_dir>")
        return 1

    root_dir = Path(sys.argv[1])
    part_str = os.environ.get("FPGA_PART", "")
    top_module = os.environ.get("TOP_MODULE", "")

    if not part_str:
        print("❌ FPGA_PART environment variable not set.")
        return 1

    if not top_module:
        # Try to infer from existing netlist
        dcp_dir = root_dir / "dcp"
        if dcp_dir.exists():
            subdirs = [d for d in dcp_dir.iterdir() if d.is_dir()]
            if len(subdirs) == 1:
                top_module = subdirs[0].name
            else:
                print("❌ TOP_MODULE not set and cannot infer from dcp/")
                return 1

    return run_nextpnr(root_dir, part_str, top_module)


if __name__ == "__main__":
    sys.exit(main())
