# MIT License
#
# Copyright (c) 2026 Daniel J. Mazure
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
# IN THE SOFTWARE.

# Author: Daniel J. Mazure, Tich
# Description: Environment setup for the open-source FPGA backend (Yosys/nextpnr).
#              Loaded by gen_synthesis.tcl before synthesis begins.

namespace eval _tcl {
proc get_script_folder {} {
    set script_path [file normalize [info script]]
    set script_folder [file dirname $script_path]
    return $script_folder
}
}
variable script_folder
set script_folder [_tcl::get_script_folder]

if {![info exists g_root_dir]} {
    set g_root_dir [file normalize $script_folder/../..]
    puts "*** Root directory by default is $g_root_dir ***"
}

# Read part from environment variable (set by build_env.mk)
if {[info exists ::env(FPGA_PART)]} {
    set g_fpga_part $::env(FPGA_PART)
} else {
    set g_fpga_part "ice40-hx8k-ct256"
}

# Read top module from environment
if {[info exists ::env(TOP_MODULE)]} {
    set g_top_mod $::env(TOP_MODULE)
} else {
    set g_top_mod "top"
}

set g_project_name system
set g_project_dir ${g_root_dir}/project
set g_tcl_dir     ${script_folder}
