# MIT License
#
# Copyright (c) 2026 Daniel J. Mazure
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
# IN THE SOFTWARE.

# Author: Daniel J. Mazure, Tich
# Description: Yosys synthesis script for the open-source FPGA toolchain.
#              Invoked via: yosys -c gen_synthesis.tcl -- <root_dir> <src_files> <constraints> <top_module>
#
# This script runs in Yosys's TCL mode (-c flag). It reads source files
# (VHDL via GHDL plugin, Verilog/SystemVerilog natively), synthesises for
# the target architecture, and writes a JSON netlist for nextpnr.

# ── Argument parsing ─────────────────────────────────────────────

if {$argc < 4} {
    puts "Error: Not enough arguments ($argc). Expected: root_dir src_files constraints top_module"
    puts "Usage: yosys -c gen_synthesis.tcl -- <root_dir> <src_files> <constraints> <top_module>"
    exit 1
}

set g_root_dir   [lindex $argv 0]
set src_files    [lindex $argv 1]
set constraints  [lindex $argv 2]
set top_module   [lindex $argv 3]

# Read FPGA part from environment (set by build_env.mk)
if {[info exists ::env(FPGA_PART)]} {
    set fpga_part $::env(FPGA_PART)
} else {
    puts "Error: FPGA_PART environment variable not set."
    puts "   Set hardware.part in project.yml (e.g. ice40-hx8k-ct256)"
    exit 1
}

puts "═══════════════════════════════════════════════════════"
puts "  Yosys Open-Source Synthesis"
puts "  Top module : $top_module"
puts "  Part       : $fpga_part"
puts "  Root       : $g_root_dir"
puts "═══════════════════════════════════════════════════════"

# ── Determine synthesis target from part string ──────────────────

# Part format: {family}-{device}-{package}
set family [lindex [split $fpga_part "-"] 0]

switch $family {
    "ice40" {
        set synth_cmd "synth_ice40"
    }
    "ecp5" {
        set synth_cmd "synth_ecp5"
    }
    "gowin" {
        set synth_cmd "synth_gowin"
    }
    default {
        puts "Error: Unsupported FPGA family '$family' in part '$fpga_part'."
        puts "   Supported families: ice40, ecp5, gowin"
        exit 1
    }
}

# ── Output paths ─────────────────────────────────────────────────

set out_dir "${g_root_dir}/dcp/${top_module}"
file mkdir $out_dir

set json_out "${out_dir}/${top_module}.json"
set report_dir "${g_root_dir}/reports"
file mkdir $report_dir

# ── Read source files ────────────────────────────────────────────
# Source files arrive as space-separated "lib:path" tokens from the
# dependency resolver (same format as the Vivado non-project-mode flow).

set has_vhdl 0
set has_verilog 0
set vhdl_libs [dict create]
set verilog_files [list]

foreach token $src_files {
    # Split lib:path on the first colon
    set colon_idx [string first ":" $token]
    if {$colon_idx >= 0} {
        set lib [string range $token 0 [expr {$colon_idx - 1}]]
        set f   [string range $token [expr {$colon_idx + 1}] end]
    } else {
        set lib "work"
        set f   $token
    }

    if {[string match -nocase "*.vhd" $f] || [string match -nocase "*.vhdl" $f]} {
        set has_vhdl 1
        if {![dict exists $vhdl_libs $lib]} {
            dict set vhdl_libs $lib [list]
        }
        dict lappend vhdl_libs $lib $f
    } elseif {[string match -nocase "*.v" $f] || [string match -nocase "*.sv" $f]} {
        set has_verilog 1
        lappend verilog_files $f
    } else {
        puts "Warning: Skipping unknown file type: $f"
    }
}

# Read Verilog/SystemVerilog sources
if {$has_verilog} {
    puts "\n📄 Reading Verilog/SystemVerilog sources..."
    foreach f $verilog_files {
        if {[string match -nocase "*.sv" $f]} {
            puts "   read_verilog -sv $f"
            yosys read_verilog -sv $f
        } else {
            puts "   read_verilog $f"
            yosys read_verilog $f
        }
    }
}

# Read VHDL sources via GHDL plugin
if {$has_vhdl} {
    puts "\n📄 Reading VHDL sources via GHDL plugin..."

    # Load each library's files with --work=<lib>
    dict for {lib files} $vhdl_libs {
        if {$lib ne "work"} {
            puts "   ghdl -read --std=08 --work=$lib [llength $files] file(s)"
            set ghdl_cmd "ghdl -read --std=08 --work=$lib"
            foreach f $files {
                append ghdl_cmd " $f"
            }
            yosys {*}[split $ghdl_cmd]
        }
    }

    # Then read work-library files and elaborate
    if {[dict exists $vhdl_libs "work"]} {
        set work_files [dict get $vhdl_libs "work"]
        set ghdl_cmd "ghdl --std=08"
        foreach f $work_files {
            append ghdl_cmd " $f"
        }
        append ghdl_cmd " -e $top_module"
        puts "   ghdl elaborate: $top_module"
        yosys {*}[split $ghdl_cmd]
    }
}

# ── Synthesize ───────────────────────────────────────────────────

puts "\n🔧 Running $synth_cmd -top $top_module ..."
yosys {*}[list $synth_cmd -top $top_module -json $json_out]

puts "\n✅ Synthesis complete: $json_out"

# ── Emit synthesis report ────────────────────────────────────────
# Yosys prints cell statistics to stdout. We also write a minimal
# JSON report that report_emitter.py will merge with nextpnr results.

set yosys_report "${report_dir}/yosys_synth_stats.json"

# Use tee_json if available, otherwise write a placeholder
# The detailed stats come from Yosys's -stat output which we capture
# in the calling Python layer.
set report_data [dict create \
    vendor    "opensource" \
    part      $fpga_part \
    top_module $top_module \
    tool_name "Yosys" \
    json_netlist $json_out \
]

set fp [open $yosys_report w]
# Manual JSON output (Yosys TCL doesn't have json package)
puts $fp "\{"
puts $fp "  \"vendor\": \"opensource\","
puts $fp "  \"part\": \"$fpga_part\","
puts $fp "  \"top_module\": \"$top_module\","
puts $fp "  \"tool_name\": \"Yosys\","
puts $fp "  \"json_netlist\": \"$json_out\""
puts $fp "\}"
close $fp

puts "📊 Synthesis stats written to $yosys_report"
