#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Bitstream generation driver for the open-source FPGA toolchain.

Invoked by VendorDispatch after nextpnr place & route. Takes the routed
output and runs the appropriate packer (icepack, ecppack, gowin_pack).

Usage::

    python gen_bitstream.py <root_dir>

Environment variables (set by build_env.mk / VendorDispatch):
    FPGA_PART   — RouteRTL part string (e.g. "ice40-hx8k-ct256")
    TOP_MODULE  — Top-level module name
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from parts import parse_part

# Map family → (routed extension, search pattern)
_ROUTED_EXT = {
    "ice40": ".asc",
    "ecp5": ".config",
    "gowin": ".pack",
}


def find_routed_output(root_dir: Path, top_module: str, family: str) -> Path | None:
    """Locate the routed output from nextpnr."""
    ext = _ROUTED_EXT.get(family, ".routed")
    primary = root_dir / "dcp" / top_module / f"{top_module}{ext}"
    if primary.exists():
        return primary

    # Fallback: search dcp/ for any matching extension
    dcp_dir = root_dir / "dcp"
    if dcp_dir.exists():
        matches = list(dcp_dir.rglob(f"*{ext}"))
        if matches:
            return matches[0]

    return None


def run_packer(root_dir: Path, part_str: str, top_module: str) -> int:
    """Run the bitstream packer for the target family.

    Returns the process exit code (0 = success).
    """
    part = parse_part(part_str)
    packer_bin = part.packer_cmd[0] if part.packer_cmd else ""

    if not packer_bin:
        print(f"❌ No packer defined for family '{part.family}'")
        return 1

    if not shutil.which(packer_bin):
        print(
            f"❌ {packer_bin} not found on PATH.\n"
            f"   Install the open-source FPGA toolchain:\n"
            f"   • Ubuntu/Debian: sudo apt install fpga-icestorm\n"
            f"   • macOS: brew install icestorm"
        )
        return 1

    # Locate routed output
    routed = find_routed_output(root_dir, top_module, part.family)
    if routed is None:
        print(
            f"❌ No routed output found for '{top_module}'.\n"
            "   Run place & route first: rr synth run"
        )
        return 1

    # Output path
    out_dir = root_dir / "dcp" / top_module
    bitstream = out_dir / f"{top_module}{part.packer_ext}"

    # Build packer command
    if part.family == "ice40":
        # icepack input.asc output.bin
        cmd = ["icepack", str(routed), str(bitstream)]
    elif part.family == "ecp5":
        # ecppack [--compress] input.config output.bit
        cmd = ["ecppack", "--compress", str(routed), str(bitstream)]
    elif part.family == "gowin":
        # gowin_pack -d <device> -o output.fs input.pack
        cmd = ["gowin_pack", "-d", part.device, "-o", str(bitstream), str(routed)]
    else:
        print(f"❌ Unsupported family for bitstream: {part.family}")
        return 1

    print(f"\n🔧 Running {packer_bin}...")
    print(f"   → {' '.join(cmd)}")

    t0 = time.monotonic()
    result = subprocess.run(cmd, check=False)
    duration = time.monotonic() - t0

    if result.returncode != 0:
        print(f"\n❌ {packer_bin} failed (exit code {result.returncode})")
        return result.returncode

    # Report file size
    if bitstream.exists():
        size_kb = bitstream.stat().st_size / 1024
        print(f"\n✅ Bitstream generated ({duration:.1f}s): {bitstream} ({size_kb:.1f} KB)")
    else:
        print(f"\n✅ Packer completed ({duration:.1f}s)")

    # Update build report with bitstream phase
    _update_build_report(root_dir, duration)

    return 0


def _update_build_report(root_dir: Path, duration: float) -> None:
    """Append the Bitstream phase to the existing build_report.json."""
    report_path = root_dir / "reports" / "build_report.json"
    if not report_path.exists():
        return

    try:
        report = json.loads(report_path.read_text())
        report["phases"].append({
            "name": "Bitstream",
            "passed": True,
            "duration_s": round(duration, 2),
        })
        report_path.write_text(json.dumps(report, indent=2) + "\n")
    except (json.JSONDecodeError, OSError, KeyError):
        pass


def main() -> int:
    if len(sys.argv) < 2:
        print("Usage: gen_bitstream.py <root_dir>")
        return 1

    root_dir = Path(sys.argv[1])
    part_str = os.environ.get("FPGA_PART", "")
    top_module = os.environ.get("TOP_MODULE", "")

    if not part_str:
        print("❌ FPGA_PART environment variable not set.")
        return 1

    if not top_module:
        # Try to infer from existing routed output
        dcp_dir = root_dir / "dcp"
        if dcp_dir.exists():
            subdirs = [d for d in dcp_dir.iterdir() if d.is_dir()]
            if len(subdirs) == 1:
                top_module = subdirs[0].name
            else:
                print("❌ TOP_MODULE not set and cannot infer from dcp/")
                return 1

    return run_packer(root_dir, part_str, top_module)


if __name__ == "__main__":
    sys.exit(main())
