# RouteRTL — Post-Synthesis Constraint Validation (Microchip/Libero)
# RTL-P2.229: Stub — not yet implemented.
#
# Writes a minimal JSON report indicating that Microchip constraint
# checking is not yet supported.

set g_root_dir [lindex $argv 0]
if {$g_root_dir eq ""} { set g_root_dir "." }

# RTL-P2.373: honour per-target output dirs when build_env.tcl is present.
if {[file exists "$g_root_dir/build_env.tcl"]} {
    source "$g_root_dir/build_env.tcl"
}
if {![info exists g_reports_dir]} { set g_reports_dir "$g_root_dir/reports" }

file mkdir $g_reports_dir
set timestamp [clock format [clock seconds] -format "%Y-%m-%dT%H:%M:%S"]

set FH [open "$g_reports_dir/synth_check_report.json" w]
puts $FH "\{"
puts $FH "  \"vendor\": \"microchip\","
puts $FH "  \"tool_name\": \"Libero\","
puts $FH "  \"timestamp\": \"$timestamp\","
puts $FH "  \"checks\": \["
puts $FH "    \{\"id\": \"not_implemented\", \"name\": \"Microchip Support\", \"severity\": \"INFO\", \"passed\": true, \"details\": \[\"Post-synthesis constraint checking for Microchip/Libero is not yet implemented\"\], \"count\": 0\}"
puts $FH "  \],"
puts $FH "  \"summary\": \{\"errors\": 0, \"warnings\": 0, \"info\": 1, \"passed\": 0\},"
puts $FH "  \"timing\": \{\"wns_ns\": 0.0, \"clock_name\": \"\"\}"
puts $FH "\}"
close $FH

puts "Microchip constraint checking not yet implemented."
