# MIT License
# Copyright (c) 2020-2026 Daniel J. Mazure
# Description: Microchip Libero SoC Synthesis Script

if { $::argc > 0 } {
 set g_root_dir [lindex $argv 0]
}

set script_path [file normalize [info script]]
set script_dir  [file dirname $script_path]
source "${script_dir}/environment.tcl"

open_project -file "${g_project_dir}/${g_project_name}.prjx"

# Source per-stage TCL hooks (from tcl_hooks.synthesis in project.yml)
if {[info exists g_synthesis_hooks]} {
    foreach hook $g_synthesis_hooks {
        set hook_path "$g_root_dir/$hook"
        if {[file exists $hook_path]} {
            puts "  Sourcing synthesis hook: $hook"
            source $hook_path
        } else {
            puts "  WARNING: synthesis hook not found: $hook_path"
        }
    }
}

puts "================================================="
puts " Running Libero SoC Synthesis"
puts "================================================="

# Apply VHDL generics / SV parameters from project.yml (build_options.generics)
# Libero delegates synthesis to Synplify Pro, so generics must be injected
# via configure_tool SYNPLIFY_OPTIONS (Synplify's set_option -hdl_param).
# Verified: hdl_param -set is language-agnostic for both VHDL and SV.
if {[info exists g_generics]} {
    set synplify_cmds ""
    dict for {name value} $g_generics {
        if {$synplify_cmds ne ""} {
            append synplify_cmds "; "
        }
        append synplify_cmds "set_option -hdl_param -set $name $value"
        puts "Info: Set generic/parameter $name = $value"
    }
    if {$synplify_cmds ne ""} {
        configure_tool -name {SYNTHESIZE} -params "SYNPLIFY_OPTIONS:$synplify_cmds"
    }
}

run_tool -name {SYNTHESIZE}

# Source post-synthesis TCL hooks (from tcl_hooks.post_synthesis in project.yml)
if {[info exists g_post_synthesis_hooks]} {
    foreach hook $g_post_synthesis_hooks {
        set hook_path "$g_root_dir/$hook"
        if {[file exists $hook_path]} {
            puts "  Sourcing post-synthesis hook: $hook"
            source $hook_path
        } else {
            puts "  WARNING: post-synthesis hook not found: $hook_path"
        }
    }
}

puts "Synthesis completed successfully."
save_project
close_project
