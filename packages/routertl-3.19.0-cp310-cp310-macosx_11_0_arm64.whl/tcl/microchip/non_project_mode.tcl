# MIT License
# Copyright (c) 2020-2026 Daniel J. Mazure
# Description: Emulates Non-Project Mode synthesis for Microchip Libero SoC

if { $::argc >= 6} {
    set g_root_dir [lindex $argv 0]
    set syn_files  [lindex $argv 1]
    set xci_files  [lindex $argv 2]
    set xdc_files  [lindex $argv 3]
    set g_top_mod  [lindex $argv 4]
    set netlist_files [lindex $argv 5]
    puts "Root dir is $g_root_dir"
} else {
    puts "Error: Not enough arguments \($::argc\), exiting ..."
    exit
}

set script_path [file normalize [info script]]
set script_dir  [file dirname $script_path]
source "${script_dir}/environment.tcl"

puts "================================================="
puts " Running Libero SoC 'NPM' Synthesis: $g_top_mod"
puts "================================================="

# NPM outputs go to dcp/<top_module> (RTL-P2.373: per-target output dirs)
set npm_dir "${g_dcp_dir}/${g_top_mod}"
set npm_prj_dir "${npm_dir}/microchip_npm_prj"
set npm_prj_name "${g_top_mod}_npm"

file mkdir $npm_prj_dir

# Use resolved part values from environment.tcl
set family $g_mc_family
set die $g_mc_die
set package $g_mc_package

catch {
    new_project -location $npm_prj_dir -name $npm_prj_name \
                -family $family -die $die -package $package \
                -speed {-1} -die_voltage {1.0} -part_range {IND} -hdl {VHDL}
} err
if {$err != ""} {
    puts "Project creation may have failed or project already exists. Attempting to open..."
    catch { open_project -file "${npm_prj_dir}/${npm_prj_name}.prjx" }
}

foreach src_file $syn_files {
    if {[string length $src_file] > 0} {
        puts "Importing source: $src_file"
        catch { import_files -hdl_source "${g_root_dir}/${src_file}" }
    }
}

foreach sdc_file $xdc_files {
    if {[string length $sdc_file] > 0} {
        puts "Importing constraint: $sdc_file"
        catch { import_files -sdc "${g_root_dir}/${sdc_file}" }
    }
}

# Pre-compiled netlists (.edf/.edif EDIF, .pdc physical constraints, .cmp component)
if {[info exists netlist_files]} {
    foreach f $netlist_files {
        if {[string trim $f] eq ""} { continue }
        if {[file pathtype $f] eq "absolute"} {
            set abs_f $f
        } else {
            set abs_f [file normalize $g_root_dir/$f]
        }
        set ext [string tolower [file extension $f]]
        if {$ext eq ".edf" || $ext eq ".edif"} {
            catch { import_files -hdl_source $abs_f }
            puts "Info: Imported EDIF netlist '$abs_f'"
        } elseif {$ext eq ".pdc"} {
            catch { import_files -io_pdc $abs_f }
            puts "Info: Imported PDC constraints '$abs_f'"
        } elseif {$ext eq ".cmp"} {
            catch { import_files -component $abs_f }
            puts "Info: Imported component '$abs_f'"
        } elseif {$ext eq ".vhd" || $ext eq ".vhdl" || $ext eq ".sv" || $ext eq ".v"} {
            catch { import_files -hdl_source $abs_f }
        } else {
            puts "Warning: Unknown netlist extension '$ext' for $f — skipping"
        }
    }
}

catch { set_root -module $g_top_mod }

puts "Running SYNTHESIZE tool..."
catch { run_tool -name {SYNTHESIZE} }

set srr_file "${npm_prj_dir}/synthesis/${npm_prj_name}.srr"
if {[file exists $srr_file]} {
    puts "NPM Synthesis emulation complete. Report generated at: $srr_file"
} else {
    puts "NPM Synthesis emulation failed. Check Libero logs inside $npm_prj_dir"
}

save_project
close_project
