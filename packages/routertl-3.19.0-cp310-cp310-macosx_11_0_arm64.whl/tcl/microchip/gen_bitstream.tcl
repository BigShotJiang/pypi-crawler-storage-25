# MIT License
# Copyright (c) 2020-2026 Daniel J. Mazure
# Description: Microchip Libero SoC Bitstream Generation Script

if { $::argc > 0 } {
 set g_root_dir [lindex $argv 0]
}

set script_path [file normalize [info script]]
set script_dir  [file dirname $script_path]
source "${script_dir}/environment.tcl"

open_project -file "${g_project_dir}/${g_project_name}.prjx"

# Source per-stage TCL hooks (from tcl_hooks.bitstream in project.yml)
if {[info exists g_bitstream_hooks]} {
    foreach hook $g_bitstream_hooks {
        set hook_path "$g_root_dir/$hook"
        if {[file exists $hook_path]} {
            puts "  Sourcing bitstream hook: $hook"
            source $hook_path
        } else {
            puts "  WARNING: bitstream hook not found: $hook_path"
        }
    }
}

puts "================================================="
puts " Generating Libero SoC Bitstream"
puts "================================================="

run_tool -name {GENERATEPROGRAMMINGDATA}

# Source post-bitstream TCL hooks (from tcl_hooks.post_bitstream in project.yml)
if {[info exists g_post_bitstream_hooks]} {
    foreach hook $g_post_bitstream_hooks {
        set hook_path "$g_root_dir/$hook"
        if {[file exists $hook_path]} {
            puts "  Sourcing post-bitstream hook: $hook"
            source $hook_path
        } else {
            puts "  WARNING: post-bitstream hook not found: $hook_path"
        }
    }
}

puts "Bitstream generated successfully."
save_project
close_project
