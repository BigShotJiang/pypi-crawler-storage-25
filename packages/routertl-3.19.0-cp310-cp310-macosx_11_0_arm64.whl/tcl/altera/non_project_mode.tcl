# Altera Non-Project Mode Synthesis Script
# RouteRTL (c) 2026
# Description: Minimal project-less synthesis (simulated via temp project)

if { $::argc >= 4 } {
    set g_root_dir    [lindex $argv 0]
    set src_files     [lindex $argv 1]
    set ip_files      [lindex $argv 2]
    set xdc_files     [lindex $argv 3]
    set top_module    [lindex $argv 4]
    set netlist_files [lindex $argv 5] ;# Pre-compiled netlists (.qxp/.qdb/.edf)
    puts "Root dir: $g_root_dir"
    puts "Top Module: $top_module"
} else {
    puts "Error: Not enough arguments ($::argc). Expected: root_dir src_files ip_files xdc_files top_module [netlist_files]"
    exit 1
}
# Optional environment configuration
set script_dir [file dirname [info script]]
source ${script_dir}/environment.tcl

package require ::quartus::project
package require ::quartus::flow

set npm_dir "$g_dcp_dir/${top_module}"
file mkdir $npm_dir
set project_name "${top_module}_npm"

# Create a fresh project every time (NPM is disposable — stale assignments
# from previous runs cause entity ambiguity errors).
project_new $npm_dir/$project_name -overwrite

# ── FAMILY / DEVICE from project.yml ──────────────────────────
# FAMILY must be set BEFORE DEVICE — Quartus Pro validates the
# license at the FAMILY level.
package require ::quartus::device

if {![info exists g_fpga_part] || $g_fpga_part eq ""} {
    puts "ERROR: No g_fpga_part defined. Set hardware.part in project.yml."
    puts "   rr config set hardware.part \"10AX115S2F45I1SG\""
    exit 1
}

# Derive FAMILY from the part number if not explicitly configured.
if {![info exists g_fpga_family] || $g_fpga_family eq ""} {
    set g_fpga_family [lindex [get_part_info -family $g_fpga_part] 0]
    puts "Info: Derived FAMILY '$g_fpga_family' from part '$g_fpga_part'"
}

# Pre-flight license check (RTL-P2.292: skippable via build_options.skip_license_check)
if {![info exists g_skip_license_check]} {
    set licensed_families [get_family_list]
    if {[lsearch -exact $licensed_families $g_fpga_family] < 0} {
        puts "==========================================================================="
        puts "ERROR: No license for family '$g_fpga_family' (part: $g_fpga_part)"
        puts "  Quartus edition: $g_quartus_edition"
        puts "==========================================================================="
        puts ""
        puts "Licensed families on this machine:"
        foreach fam $licensed_families {
            puts "  • $fam"
        }
        puts ""
        puts "To fix:"
        puts "  1. Obtain a license for '$g_fpga_family' from Intel Licensing Center"
        puts "  2. Or target a licensed family:"
        puts "     rr config set hardware.part <part_from_licensed_family>"
        puts "     rr config set hardware.family <licensed_family>"
        puts "  3. Or skip this check (eval mode / CI):"
        puts "     build_options:"
        puts "       skip_license_check: true"
        puts "==========================================================================="
        exit 1
    }
} else {
    puts "Info: License pre-flight check skipped (build_options.skip_license_check)"
}

set_global_assignment -name FAMILY $g_fpga_family
set_global_assignment -name DEVICE $g_fpga_part
set_global_assignment -name TOP_LEVEL_ENTITY $top_module
set_global_assignment -name VHDL_INPUT_VERSION VHDL_2008

# Add Sources (each token is lib:path from --list-libs)
set include_dirs {}
foreach token $src_files {
    # Split lib:path on the first colon
    set colon_idx [string first ":" $token]
    if {$colon_idx >= 0} {
        set lib [string range $token 0 [expr {$colon_idx - 1}]]
        set f   [string range $token [expr {$colon_idx + 1}] end]
    } else {
        set lib "work"
        set f   $token
    }
    if {[file pathtype $f] eq "absolute"} {
        set abs_f $f
    } else {
        set abs_f [file normalize $g_root_dir/$f]
    }
    set ext [file extension $f]
    if {$ext eq ".vhd" || $ext eq ".vhdl"} {
        set_global_assignment -name VHDL_FILE $abs_f -library $lib
    } elseif {$ext eq ".sv" || $ext eq ".svh"} {
        set_global_assignment -name SYSTEMVERILOG_FILE $abs_f
    } elseif {$ext eq ".v"} {
        set_global_assignment -name VERILOG_FILE $abs_f
    } elseif {$ext eq ".vh"} {
        # Header files: register parent directory as include search path
        set inc_dir [file dirname $abs_f]
        if {$inc_dir ni $include_dirs} {
            lappend include_dirs $inc_dir
            set_global_assignment -name SEARCH_PATH $inc_dir
        }
    }
}

# IP Files
foreach f $ip_files {
    if {[string trim $f] eq ""} { continue }
    if {[file pathtype $f] eq "absolute"} {
        set abs_f $f
    } else {
        set abs_f [file normalize $g_root_dir/$f]
    }
    if {[file extension $f] eq ".qsys"} {
        set_global_assignment -name QSYS_FILE $abs_f
    } elseif {[file extension $f] eq ".qip"} {
        # RTL-P1.9: Prefer QSYS_FILE for Platform Designer systems
        set qsys_sibling "[file rootname $abs_f].qsys"
        if {[file exists $qsys_sibling]} {
            puts "  INFO: Upgrading $f → [file tail $qsys_sibling] (QSYS_FILE)"
            set_global_assignment -name QSYS_FILE $qsys_sibling
        } else {
            set_global_assignment -name QIP_FILE $abs_f
        }
    }
}

# Pre-compiled netlists (.qxp encrypted, .qdb database, .edf/.edif EDIF)
# Edition-aware: .qxp is native to Standard, .qdb is native to Pro.
if {[info exists netlist_files]} {
    foreach f $netlist_files {
        if {[string trim $f] eq ""} { continue }
        if {[file pathtype $f] eq "absolute"} {
            set abs_f $f
        } else {
            set abs_f [file normalize $g_root_dir/$f]
        }
        set ext [file extension $f]
        if {$ext eq ".qxp"} {
            if {$g_quartus_edition eq "pro"} {
                puts "Warning: .qxp netlist '$f' is a Standard format — Pro uses .qdb"
            }
            set_global_assignment -name QXP_FILE $abs_f
        } elseif {$ext eq ".qdb"} {
            if {$g_quartus_edition eq "std"} {
                puts "Warning: .qdb netlist '$f' is a Pro format — Standard uses .qxp"
            }
            set_global_assignment -name QDB_FILE $abs_f
        } elseif {$ext eq ".edf" || $ext eq ".edif"} {
            set_global_assignment -name EDIF_FILE $abs_f
        } else {
            puts "Warning: Unknown netlist extension '$ext' for $f — skipping"
        }
    }
}

# Run Synthesis (Mapping only)
puts "-----------------------------------------------------------------------"
puts "Running Analysis & Synthesis for $top_module..."
puts "-----------------------------------------------------------------------"

# Flush all assignments to the QSF so quartus_map (child process) can read them
export_assignments

if {[catch {execute_module -tool map} result]} {
    puts "ERROR: NPM Synthesis failed."
    puts "$result"
    project_close
    exit 1
}

project_close
puts "NPM Synthesis for $top_module completed successfully."
