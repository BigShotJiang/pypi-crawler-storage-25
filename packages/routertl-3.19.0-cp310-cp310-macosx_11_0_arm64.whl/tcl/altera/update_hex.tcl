# Altera Update-Hex Fast Path — RTL-P1.13
# Tich (c) 2026
#
# Firmware-only rebuild: stage hex/mif → quartus_cdb --update_mif →
# quartus_asm. Skips synthesis and implementation entirely.
# Turns ~1.5h firmware iteration into ~2 minutes.
#
# Prerequisites:
#   - Project must already exist (.qpf file)
#   - Place & Route must have completed (.fit.rpt exists)

if { $::argc > 0 } {
    set g_root_dir [lindex $argv 0]
} else {
    set g_root_dir [pwd]
}

set script_dir [file dirname [info script]]
source ${script_dir}/environment.tcl

package require ::quartus::project
package require ::quartus::flow

# ── Precondition checks ──

set qpf_file "$g_project_dir/$g_project_name.qpf"
if {![file exists $qpf_file]} {
    puts "ERROR: Project file not found: $qpf_file"
    puts "  Run 'rr bitstream' first to create the project and complete a full build."
    exit 1
}

set fit_rpt "$g_project_dir/$g_project_name.fit.rpt"
if {![file exists $fit_rpt]} {
    puts "ERROR: Implementation report not found: $fit_rpt"
    puts "  A full build (synthesis + implementation) must complete before --update-hex."
    puts "  Run 'rr bitstream' first."
    exit 1
}

puts "======================================================================="
puts "RouteRTL — Firmware-Only Rebuild (--update-hex)"
puts "======================================================================="
puts "  Project: $g_project_name"
puts "  FPGA:    $g_fpga_part"
puts ""

project_open $g_project_dir/$g_project_name -current_revision

# ── Stage memory initialization files ──
# Identical staging logic to gen_bitstream.tcl — quartus_cdb searches
# for hex/mif by bare filename in the project directory only.
set mif_copy_count 0

# Source 1: declared in project.yml → sources.mif → g_mif_files
if {[info exists g_mif_files]} {
    foreach mf $g_mif_files {
        set src "$g_root_dir/$mf"
        if {[file exists $src]} {
            file copy -force $src $g_project_dir/
            puts "  Staged: [file tail $src] -> project/"
            incr mif_copy_count
        } else {
            puts "  WARNING: declared MIF file not found: $mf"
        }
    }
}

# Source 2: auto-scan IP directories and qsys-generate output
foreach pattern [list \
    "$g_root_dir/src/ip/*/*.hex" "$g_root_dir/src/ip/*/*.mif" \
    "$g_root_dir/src/ip/*/*/*.hex" "$g_root_dir/src/ip/*/*/*.mif" \
    "$g_root_dir/ip/*/*.hex" "$g_root_dir/ip/*/*.mif" \
    "$g_root_dir/ip/*/*/*.hex" "$g_root_dir/ip/*/*/*.mif" \
    "$g_root_dir/data/*.hex" "$g_root_dir/data/*.mif" \
    "$g_project_dir/*/synthesis/*.hex" "$g_project_dir/*/synthesis/*.mif" \
    "$g_project_dir/*/synthesis/submodules/*.hex" "$g_project_dir/*/synthesis/submodules/*.mif" \
] {
    foreach src_file [glob -nocomplain $pattern] {
        set dest "$g_project_dir/[file tail $src_file]"
        # Always overwrite in update-hex mode — the hex is the thing that changed
        file copy -force $src_file $dest
        puts "  Staged: [file tail $src_file] -> project/ (auto-detected)"
        incr mif_copy_count
    }
}

if {$mif_copy_count > 0} {
    puts "  Staged $mif_copy_count memory init file(s)."
} else {
    puts "  WARNING: No memory init files found to stage."
    puts "  Check sources.mif in project.yml or place .hex/.mif files in data/ or src/ip/."
}

# ── Update memory initialization ──
puts ""
puts "-----------------------------------------------------------------------"
puts "Updating Memory Initialization (quartus_cdb --update_mif)..."
puts "-----------------------------------------------------------------------"

# RTL-P1.15: quartus_cdb --update_mif MUST succeed for --update-hex.
# On Quartus 23.1 Std, NiosV OCRAM (altera_avalon_onchip_memory2) is NOT
# registered as MIF-updatable in the atom netlist. The update silently
# fails and quartus_asm produces a SOF with STALE firmware.
#
# This is FATAL for --update-hex — the entire purpose is to update firmware.
# If quartus_cdb fails, we abort with a clear error instead of producing
# a stale SOF that looks correct but has old code.

if {[catch {execute_module -tool cdb -args "--update_mif"} result]} {
    puts ""
    puts "======================================================================="
    puts "ERROR: quartus_cdb --update_mif FAILED"
    puts "======================================================================="
    puts ""
    puts "  The memory initialization update did not succeed. This means"
    puts "  --update-hex CANNOT safely produce a SOF with updated firmware."
    puts ""
    puts "  Common cause: NiosV OCRAM (altera_avalon_onchip_memory2) on"
    puts "  Quartus 23.1 Standard Edition — the memory is not registered as"
    puts "  MIF-updatable in the atom netlist."
    puts ""
    puts "  Workaround: Run a full rebuild instead:"
    puts "    rr project clean --sw && rr bitstream run"
    puts ""
    puts "  The hex is baked at synthesis via \$readmemh, so a full"
    puts "  synth+fit+asm cycle will embed the correct firmware."
    puts ""
    puts "  Quartus error: $result"
    puts "======================================================================="
    project_close
    exit 1
}

# ── Reassemble bitstream ──
puts "-----------------------------------------------------------------------"
puts "Running Assembler (quartus_asm)..."
puts "-----------------------------------------------------------------------"

if {[catch {execute_module -tool asm} result]} {
    puts "ERROR: Assembler failed."
    puts "$result"
    project_close
    exit 1
}

# ── Copy output (RTL-P2.373: per-target output dirs) ──
file mkdir $g_bitstream_dir
set sof_file "$g_project_dir/$g_project_name.sof"
if {[file exists $sof_file]} {
    file copy -force $sof_file $g_bitstream_dir/
    puts "Bitstream copied to $g_bitstream_dir/$g_project_name.sof"
}
set pof_file "$g_project_dir/$g_project_name.pof"
if {[file exists $pof_file]} {
    file copy -force $pof_file $g_bitstream_dir/
    puts "Flash image copied to $g_bitstream_dir/$g_project_name.pof"
}

project_close

puts ""
puts "======================================================================="
puts "Firmware-only rebuild complete."
puts "======================================================================="
