# Altera Software Download Script (Nios V)
# (c) 2026 RouteRTL

if { $argc < 3 } {
    puts "Usage: gen_software_program.tcl <root_dir> <elf_path> <cable_id>"
    exit 1
}

set g_root_dir [lindex $argv 0]
set g_elf_path [lindex $argv 1]
set g_cable_id [lindex $argv 2]

if { $g_elf_path == "" } {
    # Try to find ELF in src/software/ or build/ (standard locations)
    set elf_candidates [glob -nocomplain "${g_root_dir}/src/software/**/*.elf" "${g_root_dir}/build/**/*.elf" "${g_root_dir}/**/*.elf"]
    if { [llength $elf_candidates] > 0 } {
        set g_elf_path [lindex $elf_candidates 0]
        puts "   ℹ️  Auto-detected software: $g_elf_path"
    } else {
        puts "❌ Error: No software (.elf) found and none provided."
        exit 1
    }
}

if { $g_cable_id == "" } {
    set g_cable_id "1"
}

puts "📥 Downloading Altera Nios V Software..."
puts "   Cable: $g_cable_id"
puts "   ELF:   $g_elf_path"

set cmd "niosv-download -c \"$g_cable_id\" -g \"$g_elf_path\""
puts "   Executing: $cmd"

if { [catch { qexec $cmd } result] } {
    if {[string match "*Error*" $result]} {
        puts "❌ Software download failed: $result"
        exit 1
    }
}

puts "✅ Software download successful."
