# RouteRTL — Post-Synthesis Constraint Validation (Altera/Quartus)
# RTL-P2.229: Catch missing CDC constraints before expensive P&R.
#
# Usage: quartus_sh -t synth_check.tcl <root_dir>
#
# Opens the Quartus project, runs post-map STA, parses the results,
# and writes reports/synth_check_report.json with structured results.

set g_root_dir [lindex $argv 0]

if {$g_root_dir eq ""} {
    puts "ERROR: root_dir argument required"
    exit 1
}

# Source environment for project defaults
set script_folder [file dirname [file normalize [info script]]]
source $script_folder/environment.tcl

# Override root if provided
set g_root_dir [file normalize $g_root_dir]

# ── Helpers ──────────────────────────────────────────────────────

proc _json_escape {str} {
    set str [string map {"\\" "\\\\" "\"" "\\\"" "\n" "\\n" "\t" "\\t"} $str]
    return $str
}

proc _json_list {items} {
    set parts {}
    foreach item $items {
        lappend parts "\"[_json_escape $item]\""
    }
    return "\[[join $parts ", "]\]"
}

# ── Find and Open Project ────────────────────────────────────────

set qpf_files [glob -nocomplain $g_project_dir/*.qpf]
if {[llength $qpf_files] == 0} {
    puts "ERROR: No .qpf project found in $g_project_dir"
    puts "Run 'rr synth run' first."
    exit 1
}

set qpf_file [lindex $qpf_files 0]
set project_name [file rootname [file tail $qpf_file]]

# Check for post-map artifacts
set map_rpt "$g_project_dir/output_files/${project_name}.map.rpt"
if {![file exists $map_rpt]} {
    puts "ERROR: Post-map report not found: $map_rpt"
    puts "Synthesis (quartus_map) must complete before running constraint checks."
    exit 1
}

puts "Opening project: $project_name"
package require ::quartus::project
project_open "$g_project_dir/$project_name" -current_revision

set timestamp [clock format [clock seconds] -format "%Y-%m-%dT%H:%M:%S"]

# Detect tool version
set tool_name "Quartus"
if {[info exists quartus(version)]} {
    set tool_name "Quartus $quartus(version)"
}

# ── Run Post-Map STA ─────────────────────────────────────────────

puts "\nRunning post-map Static Timing Analysis..."

package require ::quartus::flow
if {[catch {execute_module -tool sta -args "--post_map"} result]} {
    puts "WARNING: Post-map STA failed: $result"
    puts "Continuing with available data..."
}

# ── Parse STA Report ─────────────────────────────────────────────

set checks {}
set n_errors 0
set n_warnings 0
set n_info 0
set n_passed 0
set wns_val 0.0
set clk_name ""

# Find the STA report
set sta_rpt "$g_project_dir/output_files/${project_name}.sta.rpt"

if {[file exists $sta_rpt]} {
    set FH [open $sta_rpt r]
    set sta_text [read $FH]
    close $FH

    # ── 1. Unconstrained Clocks (ERROR) ──────────────────────────
    # Quartus STA table format:
    #   ; Unconstrained Clocks            ; 0     ; 0    ;

    set details {}
    set check_passed true
    set unconstrained_clk_count 0

    # Check for missing SDC (Critical Warning 332012)
    foreach line [split $sta_text "\n"] {
        if {[regexp {Critical Warning \(332012\).*Design Constraints File.*not found} $line]} {
            set check_passed false
            lappend details "SDC file not found — no timing constraints applied"
        }
    }

    # Parse Unconstrained Paths Summary table
    foreach line [split $sta_text "\n"] {
        if {[regexp {;\s*Unconstrained Clocks\s+;\s*(\d+)\s*;\s*(\d+)\s*;} $line -> setup_cnt hold_cnt]} {
            set unconstrained_clk_count $setup_cnt
            if {$setup_cnt > 0} {
                set check_passed false
                lappend details "$setup_cnt unconstrained clock(s) in design"
            }
        }
        if {[regexp {;\s*Illegal Clocks\s+;\s*(\d+)\s*;} $line -> illegal_cnt]} {
            if {$illegal_cnt > 0} {
                set check_passed false
                lappend details "$illegal_cnt illegal clock(s) in design"
            }
        }
    }

    # Also check Clock Status Summary for non-Constrained clocks
    set in_clk_status false
    foreach line [split $sta_text "\n"] {
        if {[regexp {Clock Status Summary} $line]} { set in_clk_status true; continue }
        if {$in_clk_status && [regexp {^\+--} $line]} {
            # Table border — could be start or end
            continue
        }
        if {$in_clk_status && [regexp {;\s*Target\s*;} $line]} { continue }
        if {$in_clk_status && [regexp {;\s*(.+?)\s+;\s+(.+?)\s+;\s+(\w+)\s+;\s+(\w+)\s+;} $line -> target clk_n type status]} {
            if {$status ne "Constrained"} {
                set check_passed false
                lappend details "Clock [string trim $clk_n] is $status"
            }
        }
        if {$in_clk_status && $line eq ""} { set in_clk_status false }
    }

    if {$check_passed} { incr n_passed } else { incr n_errors }
    lappend checks [list "unconstrained_clocks" "Unconstrained Clocks" "ERROR" $check_passed $details [llength $details]]

    # ── 2. CDC Crossings (ERROR) ─────────────────────────────────
    # Check for "Design is not fully constrained" messages and
    # metastability summary

    set details {}
    set check_passed true
    set unsafe_count 0

    foreach line [split $sta_text "\n"] {
        # Design not fully constrained = possible CDC issues
        if {[regexp {Info \(332102\).*not fully constrained for setup} $line]} {
            incr unsafe_count
            lappend details "Design is not fully constrained for setup requirements"
        }
        # Metastability warnings
        if {[regexp -nocase {Warning.*metastability} $line]} {
            incr unsafe_count
            set trimmed [string trim $line]
            if {[llength $details] < 20} {
                lappend details $trimmed
            }
        }
    }

    if {$unsafe_count > 0} {
        set check_passed false
        incr n_errors
    } else {
        incr n_passed
    }
    lappend checks [list "cdc_crossings" "CDC Crossings" "ERROR" $check_passed $details $unsafe_count]

    # ── 3. Early WNS (ERROR) ─────────────────────────────────────
    # Parse from Info messages:
    #   Info (332146): Worst-case setup slack is 18.747
    # and from Fmax Summary table:
    #   ; 635.73 MHz ; 635.73 MHz ; u_sys_pll|pll_0|outclk3 ;

    set details {}
    set check_passed true
    set got_first_slack false

    foreach line [split $sta_text "\n"] {
        # First "Worst-case setup slack" is the slow corner (worst case)
        if {!$got_first_slack && [regexp {Worst-case setup slack is ([-\d.]+)} $line -> slack]} {
            set wns_val $slack
            set got_first_slack true
        }
        # Fmax Summary — capture first entry (slowest corner)
        if {$clk_name eq "" && [regexp {;\s+([\d.]+)\s+MHz\s+;\s+[\d.]+\s+MHz\s+;\s+(\S+)} $line -> fmax_val clock]} {
            set clk_name [string trim $clock]
        }
    }

    # Also parse Multicorner Timing Analysis Summary for worst-case
    foreach line [split $sta_text "\n"] {
        if {[regexp {;\s*Worst-case Slack\s+;\s*([-\d.]+)\s*;} $line -> mc_slack]} {
            # Use multicorner worst-case if available (most conservative)
            set wns_val $mc_slack
        }
    }

    if {$wns_val < 0} {
        set check_passed false
        incr n_errors
        lappend details [format "WNS = %.3f ns (%s) — timing already violated at post-map" $wns_val $clk_name]
    } else {
        incr n_passed
        lappend details [format "+%.3f ns (%s)" $wns_val $clk_name]
    }
    lappend checks [list "early_wns" "Early WNS" "ERROR" $check_passed $details 0]

    # ── 4. Missing I/O Delays (WARNING) ──────────────────────────
    # Quartus STA table format:
    #   ; Unconstrained Input Ports       ; 1     ; 1    ;
    #   ; Unconstrained Output Ports      ; 7     ; 7    ;
    # Plus detail tables with port names and "No input/output delay" comments

    set details {}
    set check_passed true
    set io_count 0

    foreach line [split $sta_text "\n"] {
        if {[regexp {;\s*Unconstrained Input Ports\s+;\s*(\d+)\s*;} $line -> cnt]} {
            if {$cnt > 0} {
                set check_passed false
                incr io_count $cnt
                lappend details "$cnt unconstrained input port(s)"
            }
        }
        if {[regexp {;\s*Unconstrained Output Ports\s+;\s*(\d+)\s*;} $line -> cnt]} {
            if {$cnt > 0} {
                set check_passed false
                incr io_count $cnt
                lappend details "$cnt unconstrained output port(s)"
            }
        }
    }

    # Collect specific port names from detail tables
    foreach line [split $sta_text "\n"] {
        if {[regexp {;\s*(\S+)\s+;\s*No (input|output) delay} $line -> port_name delay_type]} {
            if {[llength $details] < 15} {
                lappend details "$port_name: no ${delay_type} delay"
            }
        }
    }

    if {$check_passed} { incr n_passed } else { incr n_warnings }
    lappend checks [list "io_delays" "I/O Delays" "WARNING" $check_passed $details $io_count]

    # ── 5. Clock Groups (WARNING) ────────────────────────────────
    # Check if multiple clocks exist without set_clock_groups

    set details {}
    set check_passed true

    # Count distinct clocks from Fmax Summary
    set clock_names {}
    foreach line [split $sta_text "\n"] {
        if {[regexp {;\s+[\d.]+\s+MHz\s+;\s+[\d.]+\s+MHz\s+;\s+(\S+)} $line -> clock]} {
            set cn [string trim $clock]
            if {$cn ni $clock_names} {
                lappend clock_names $cn
            }
        }
    }

    if {[llength $clock_names] > 1} {
        # Multiple clocks — check for "not fully constrained" which hints at
        # missing clock groups between domains
        foreach line [split $sta_text "\n"] {
            if {[regexp {Info \(332102\).*not fully constrained} $line]} {
                set check_passed false
                lappend details "[llength $clock_names] clocks ([join $clock_names {, }]) — design not fully constrained"
                break
            }
        }
    }

    if {$check_passed} { incr n_passed } else { incr n_warnings }
    lappend checks [list "clock_groups" "Clock Groups" "WARNING" $check_passed $details 0]

} else {
    puts "WARNING: STA report not found at $sta_rpt"
    lappend checks [list "sta_report" "STA Report" "ERROR" false [list "Post-map STA report not found"] 1]
    incr n_errors
}

# ── Write JSON Report ────────────────────────────────────────────

file mkdir $g_reports_dir

set json_checks {}
foreach chk $checks {
    lassign $chk id name severity passed details count
    set passed_str [expr {$passed ? "true" : "false"}]
    lappend json_checks "    \{\"id\": \"[_json_escape $id]\", \"name\": \"[_json_escape $name]\", \"severity\": \"$severity\", \"passed\": $passed_str, \"details\": [_json_list $details], \"count\": $count\}"
}

set report_file "$g_reports_dir/synth_check_report.json"
set FH [open $report_file w]
puts $FH "\{"
puts $FH "  \"vendor\": \"altera\","
puts $FH "  \"tool_name\": \"[_json_escape $tool_name]\","
puts $FH "  \"timestamp\": \"$timestamp\","
puts $FH "  \"checks\": \["
puts $FH [join $json_checks ",\n"]
puts $FH "  \],"
puts $FH "  \"summary\": \{\"errors\": $n_errors, \"warnings\": $n_warnings, \"info\": $n_info, \"passed\": $n_passed\},"
puts $FH "  \"timing\": \{\"wns_ns\": $wns_val, \"clock_name\": \"[_json_escape $clk_name]\"\}"
puts $FH "\}"
close $FH

puts "\nConstraint check report written to: $report_file"
puts "Summary: $n_errors error(s), $n_warnings warning(s), $n_passed passed"

project_close
