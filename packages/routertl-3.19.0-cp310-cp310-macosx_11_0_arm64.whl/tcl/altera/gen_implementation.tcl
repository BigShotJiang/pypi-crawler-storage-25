# Altera Implementation Script
# Tich (c) 2026

if { $::argc > 0 } {
    set g_root_dir [lindex $argv 0]
} else {
    set g_root_dir [pwd]
}

set script_dir [file dirname [info script]]
source ${script_dir}/environment.tcl

package require ::quartus::project
package require ::quartus::flow

# For Altera, we might want to run synthesis if it wasn't run
# But the project flow usually handles it. 
# Here we replicate the granular behavior.

# Check if synthesis is needed (imitate Xilinx logic)
set map_rpt "$g_project_dir/$g_project_name.map.rpt"

if {![file exists $map_rpt]} {
    puts "Synthesis report not found, running Synthesis first..."
    source ${script_dir}/gen_synthesis.tcl
}

project_open $g_project_dir/$g_project_name -current_revision

# Source per-stage TCL hooks (from tcl_hooks.implementation in project.yml)
if {[info exists g_implementation_hooks]} {
    foreach hook $g_implementation_hooks {
        set hook_path "$g_root_dir/$hook"
        if {[file exists $hook_path]} {
            puts "  Sourcing implementation hook: $hook"
            source $hook_path
        } else {
            puts "  WARNING: implementation hook not found: $hook_path"
        }
    }
}

puts "-----------------------------------------------------------------------"
puts "Running Fitter (Place & Route - quartus_fit)..."
puts "-----------------------------------------------------------------------"

if {[catch {execute_module -tool fit} result]} {
    puts "ERROR: Fitter failed."
    puts "$result"
    project_close
    exit 1
}

# Source post-implementation TCL hooks (from tcl_hooks.post_implementation in project.yml)
if {[info exists g_post_implementation_hooks]} {
    foreach hook $g_post_implementation_hooks {
        set hook_path "$g_root_dir/$hook"
        if {[file exists $hook_path]} {
            puts "  Sourcing post-implementation hook: $hook"
            source $hook_path
        } else {
            puts "  WARNING: post-implementation hook not found: $hook_path"
        }
    }
}

# ── RouteRTL Report Emitter ──────────────────────────────────
source ${script_dir}/report_emitter.tcl
emit_implementation_report $g_root_dir $g_project_dir $g_project_name

project_close
puts "Implementation completed successfully."
