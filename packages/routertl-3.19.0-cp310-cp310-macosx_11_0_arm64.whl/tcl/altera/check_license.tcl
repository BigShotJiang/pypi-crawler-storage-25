# =========================================================================
#  Quartus License & Device Family Diagnostic
#  RouteRTL (c) 2026
# =========================================================================
#  Edition-aware license diagnostic script.  Invoked by:
#
#      quartus_sh -t check_license.tcl [target_part]
#
#  If target_part is omitted, only lists licensed families and edition.
#
#  Output is machine-parseable (prefixed lines) for consumption by the
#  future `rr license` Python CLI command.
#
#  Prefix format:
#    EDITION:<pro|std|unknown>
#    VERSION:<full_version_string>
#    LICENSE_VAR:<name>=<value>
#    FAMILY:<family_name>
#    PART_OK:<part>:<family>
#    PART_FAIL:<part>:<reason>
#    QUARTUS_INFO:<key>=<value>        (Pro edition only)
#
#  Reference: Customer project scripts/quartus_check_license.bat and
#             scripts/quartus_arria10_smoke_test.tcl
# =========================================================================

package require ::quartus::device

# ── Source shared environment (edition detection) ─────────────
set script_dir [file dirname [info script]]
source ${script_dir}/environment.tcl

# ── Parse optional target part ────────────────────────────────
set target_part ""
if {$::argc >= 1} {
    set target_part [lindex $argv 0]
}

# ── Banner ────────────────────────────────────────────────────
puts ""
puts "==========================================================="
puts "  RouteRTL License Diagnostic"
puts "  (c) 2026 Daniel J. Mazure"
puts "==========================================================="
puts ""

# ── Edition ───────────────────────────────────────────────────
puts "EDITION:$g_quartus_edition"
if {[info exists quartus(version)]} {
    puts "VERSION:$quartus(version)"
} else {
    puts "VERSION:unknown"
}
puts ""

# ── License Environment Variables ─────────────────────────────
if {[info exists ::env(LM_LICENSE_FILE)]} {
    puts "LICENSE_VAR:LM_LICENSE_FILE=$::env(LM_LICENSE_FILE)"
} else {
    puts "LICENSE_VAR:LM_LICENSE_FILE=[NOT SET]"
}
if {[info exists ::env(ALTERAD_LICENSE_FILE)]} {
    puts "LICENSE_VAR:ALTERAD_LICENSE_FILE=$::env(ALTERAD_LICENSE_FILE)"
} else {
    puts "LICENSE_VAR:ALTERAD_LICENSE_FILE=[NOT SET]"
}
puts ""

# ── Pro-only: get_quartus_info ────────────────────────────────
# get_quartus_info is only available in Quartus Pro Edition.
# Guard behind edition check to prevent crashes on Standard.
if {$g_quartus_edition eq "pro"} {
    if {[catch {
        package require ::quartus::quartus_info
        foreach key {version edition install_directory} {
            if {![catch {get_quartus_info -$key} val]} {
                puts "QUARTUS_INFO:$key=$val"
            }
        }
    } err]} {
        puts "QUARTUS_INFO:error=$err"
    }
}

# ── Licensed Device Families ──────────────────────────────────
puts "-----------------------------------------------------------"
puts "  LICENSED DEVICE FAMILIES"
puts "-----------------------------------------------------------"
set licensed_families [get_family_list]
foreach fam [lsort $licensed_families] {
    puts "FAMILY:$fam"
}
puts ""
puts "  Total: [llength $licensed_families] families"
puts ""

# ── Target Part Validation ────────────────────────────────────
if {$target_part ne ""} {
    puts "-----------------------------------------------------------"
    puts "  TARGET PART: $target_part"
    puts "-----------------------------------------------------------"

    if {[catch {set part_family [lindex [get_part_info -family $target_part] 0]} err]} {
        puts "PART_FAIL:$target_part:$err"
        puts ""
        puts "  The part '$target_part' is NOT available."
        puts "  Possible causes:"
        puts "    1. Device support files not installed"
        puts "    2. License does not cover this family"
        puts "    3. Invalid part number"
    } else {
        # Verify the family is licensed
        if {[lsearch -exact $licensed_families $part_family] >= 0} {
            puts "PART_OK:$target_part:$part_family"
            puts ""
            puts "  Part '$target_part' is AVAILABLE (family: $part_family)"
        } else {
            puts "PART_FAIL:$target_part:family '$part_family' not licensed"
            puts ""
            puts "  Part '$target_part' maps to family '$part_family'"
            puts "  but that family is NOT in the licensed list."
        }
    }
    puts ""
}

puts "==========================================================="
puts "  DIAGNOSTIC COMPLETE"
puts "==========================================================="
puts ""
