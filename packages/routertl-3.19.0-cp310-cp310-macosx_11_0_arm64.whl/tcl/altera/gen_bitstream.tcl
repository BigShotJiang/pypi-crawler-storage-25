# Altera Bitstream & Timing Script
# Tich (c) 2026

if { $::argc > 0 } {
    set g_root_dir [lindex $argv 0]
} else {
    set g_root_dir [pwd]
}

set script_dir [file dirname [info script]]
source ${script_dir}/environment.tcl

package require ::quartus::project
package require ::quartus::flow

# Check if implementation is needed (imitate Xilinx logic)
set fit_rpt "$g_project_dir/$g_project_name.fit.rpt"

if {![file exists $fit_rpt]} {
    puts "Implementation report not found, running Implementation first..."
    source ${script_dir}/gen_implementation.tcl
}

project_open $g_project_dir/$g_project_name -current_revision

# Source per-stage TCL hooks (from tcl_hooks.bitstream in project.yml)
if {[info exists g_bitstream_hooks]} {
    foreach hook $g_bitstream_hooks {
        set hook_path "$g_root_dir/$hook"
        if {[file exists $hook_path]} {
            puts "  Sourcing bitstream hook: $hook"
            source $hook_path
        } else {
            puts "  WARNING: bitstream hook not found: $hook_path"
        }
    }
}

# ── RTL-P1.11: Copy memory init files into project dir ──
# quartus_cdb --update_mif searches for hex/mif by bare filename in the
# project directory. When IPs live outside project/ the files are not
# findable. Two sources: (1) explicit g_mif_files from sources.mif,
# (2) auto-scan common IP directories for .hex/.mif files.
set mif_copy_count 0

# Source 1: declared in project.yml → sources.mif → g_mif_files
if {[info exists g_mif_files]} {
    foreach mf $g_mif_files {
        set src "$g_root_dir/$mf"
        if {[file exists $src]} {
            file copy -force $src $g_project_dir/
            puts "  Staged memory init: [file tail $src] → project/"
            incr mif_copy_count
        } else {
            puts "  WARNING: declared MIF file not found: $mf"
        }
    }
}

# Source 2: auto-scan IP directories and qsys-generate output for .hex/.mif
foreach pattern [list \
    "$g_root_dir/src/ip/*/*.hex" "$g_root_dir/src/ip/*/*.mif" \
    "$g_root_dir/src/ip/*/*/*.hex" "$g_root_dir/src/ip/*/*/*.mif" \
    "$g_root_dir/ip/*/*.hex" "$g_root_dir/ip/*/*.mif" \
    "$g_root_dir/ip/*/*/*.hex" "$g_root_dir/ip/*/*/*.mif" \
    "$g_root_dir/data/*.hex" "$g_root_dir/data/*.mif" \
    "$g_project_dir/*/synthesis/*.hex" "$g_project_dir/*/synthesis/*.mif" \
    "$g_project_dir/*/synthesis/submodules/*.hex" "$g_project_dir/*/synthesis/submodules/*.mif" \
] {
    foreach src_file [glob -nocomplain $pattern] {
        set dest "$g_project_dir/[file tail $src_file]"
        if {![file exists $dest]} {
            file copy -force $src_file $dest
            puts "  Staged memory init: [file tail $src_file] → project/ (auto-detected)"
            incr mif_copy_count
        }
    }
}

if {$mif_copy_count > 0} {
    puts "  Staged $mif_copy_count memory init file(s) into project directory."
}

puts "-----------------------------------------------------------------------"
puts "Updating Memory Initialization (quartus_cdb --update_mif)..."
puts "-----------------------------------------------------------------------"

if {[catch {execute_module -tool cdb -args "--update_mif"} result]} {
    # RTL-P1.14: Non-fatal for the full bitstream flow.
    # When using QSYS_FILE or NiosV OCRAM, the hex is baked at synthesis
    # via $readmemh — quartus_cdb --update_mif may fail because the memory
    # is not registered as MIF-updatable in the atom netlist.
    # The SOF is still correct since the hex was embedded during synthesis.
    puts ""
    puts "  NOTE: quartus_cdb --update_mif did not update memory init (non-fatal)."
    puts "  This is expected when firmware hex was already embedded at synthesis"
    puts "  (e.g. NiosV OCRAM via \$readmemh, or QSYS_FILE with internal hex)."
    puts "  The SOF contains the firmware that was present during synthesis."
    puts ""
    puts "  If you need to update firmware WITHOUT a full rebuild, note that"
    puts "  --update-hex may not work for this memory configuration."
    puts "  See: rr bitstream run --update-hex --help"
    puts ""
}

puts "-----------------------------------------------------------------------"
puts "Running Assembler (Bitstream Generation - quartus_asm)..."
puts "-----------------------------------------------------------------------"

if {[catch {execute_module -tool asm} result]} {
    puts "ERROR: Assembler failed."
    puts "$result"
    project_close
    exit 1
}

puts "-----------------------------------------------------------------------"
puts "Running Timing Analysis (quartus_sta)..."
puts "-----------------------------------------------------------------------"

if {[catch {execute_module -tool sta} result]} {
    puts "ERROR: Timing Analysis failed."
    puts "$result"
    project_close
    exit 1
}

# Copy bitstream output to a dedicated bitstream/ directory (parity with Xilinx flow)
# RTL-P2.373: per-target output dirs from build_env.tcl
file mkdir $g_bitstream_dir
set sof_file "$g_project_dir/$g_project_name.sof"
if {[file exists $sof_file]} {
    file copy -force $sof_file $g_bitstream_dir/
    puts "Bitstream copied to $g_bitstream_dir/$g_project_name.sof"
}
# Also copy .pof if present (flash-based devices)
set pof_file "$g_project_dir/$g_project_name.pof"
if {[file exists $pof_file]} {
    file copy -force $pof_file $g_bitstream_dir/
    puts "Flash image copied to $g_bitstream_dir/$g_project_name.pof"
}

# Source post-bitstream TCL hooks (from tcl_hooks.post_bitstream in project.yml)
if {[info exists g_post_bitstream_hooks]} {
    foreach hook $g_post_bitstream_hooks {
        set hook_path "$g_root_dir/$hook"
        if {[file exists $hook_path]} {
            puts "  Sourcing post-bitstream hook: $hook"
            source $hook_path
        } else {
            puts "  WARNING: post-bitstream hook not found: $hook_path"
        }
    }
}

project_close
puts "Bitstream generation and Timing Analysis completed successfully."

