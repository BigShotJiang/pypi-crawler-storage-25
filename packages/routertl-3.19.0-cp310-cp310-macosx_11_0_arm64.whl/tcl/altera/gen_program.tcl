# Altera FPGA Programming Script (JTAG)
# (c) 2026 RouteRTL

if { $argc < 3 } {
    puts "Usage: gen_program.tcl <root_dir> <bitstream_path> <cable_id> \[eval_accept\]"
    exit 1
}

set g_root_dir [lindex $argv 0]
set g_bitstream_path [lindex $argv 1]
set g_cable_id [lindex $argv 2]

# RTL-P2.129: eval_accept flag — auto-dismiss eval IP license prompt
set g_eval_accept 0
if { $argc > 3 && [lindex $argv 3] == "eval_accept" } {
    set g_eval_accept 1
}

# Source environment to get project settings
source [file join [file dirname [info script]] "environment.tcl"]

if { $g_bitstream_path == "" } {
    # Try to find bitstream in standard locations
    # RTL-P2.373: per-target bitstream dir comes first, then project dir, then legacy root fallback.
    set bitstream_candidates [glob -nocomplain \
        "${g_bitstream_dir}/*.sof" \
        "${g_build_dir}/output_files/*.sof" \
        "${g_project_dir}/*.sof" \
        "${g_root_dir}/output_files/*.sof" \
        "${g_root_dir}/*.sof"]
    if { [llength $bitstream_candidates] > 0 } {
        set g_bitstream_path [lindex $bitstream_candidates 0]
        puts "   ℹ️  Auto-detected bitstream: $g_bitstream_path"
    } else {
        puts "❌ Error: No bitstream file (.sof) found and none provided."
        exit 1
    }
}

if { $g_cable_id == "" } {
    set g_cable_id "1"
}

puts "⚡ Programming Altera FPGA..."
puts "   Cable: $g_cable_id"
puts "   File:  $g_bitstream_path"

# We use quartus_pgm via qexec because it's easier to pass the -c <cable> flag
# than using the internal Tcl API which is cumbersome for simple JTAG loads.

set cmd "quartus_pgm -c \"$g_cable_id\" -m jtag -o \"p;$g_bitstream_path@1\""

if { $g_eval_accept } {
    # RTL-P2.129: Pipe 'q' to auto-dismiss the eval IP time-limited license
    # prompt ("Press P for info, Q to quit"). Without this, quartus_pgm blocks
    # waiting for interactive input when the SOF contains eval IPs.
    set piped_cmd "echo q | $cmd"
    puts "   Executing (eval-accept): $piped_cmd"
    if { [catch { exec {*}[list sh -c $piped_cmd] } result] } {
        if {[string match "*Error*" $result]} {
            puts "❌ Programming failed: $result"
            exit 1
        }
    }
} else {
    puts "   Executing: $cmd"
    if { [catch { qexec $cmd } result] } {
        if {[string match "*Error*" $result]} {
            puts "❌ Programming failed: $result"
            exit 1
        }
    }
}

puts "✅ Programming successful."
