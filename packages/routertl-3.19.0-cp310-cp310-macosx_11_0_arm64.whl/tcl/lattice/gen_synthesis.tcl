# MIT License
#
# Copyright (c) 2020-2025 Daniel J. Mazure
#
# Permission is hereby granted ... (omitting full MIT for brevity, but let's just make it standard)
#
# Author: Daniel J.Mazure, Tich
# Date: 2025
# Description: Lattice Radiant Synthesis runner

if { $::argc > 0 } {
 set g_root_dir    [lindex $argv 0]
 puts "Root directory is $g_root_dir"
}

# Resolve script directory (SDK Support)
set script_path [file normalize [info script]]
set script_dir  [file dirname $script_path]
source "${script_dir}/environment.tcl"

prj_open ${g_project_dir}/${g_project_name}.rdf

# Source per-stage TCL hooks (from tcl_hooks.synthesis in project.yml)
if {[info exists g_synthesis_hooks]} {
    foreach hook $g_synthesis_hooks {
        set hook_path "$g_root_dir/$hook"
        if {[file exists $hook_path]} {
            puts "  Sourcing synthesis hook: $hook"
            source $hook_path
        } else {
            puts "  WARNING: synthesis hook not found: $hook_path"
        }
    }
}

puts "================================================="
puts " Running Radiant Synthesis"
puts "================================================="

# Apply VHDL generics / SV parameters from project.yml (build_options.generics)
# Radiant delegates synthesis to Synplify Pro, so generics must be injected
# via syn_cmdline_args strategy value (Synplify's set_option -hdl_param).
if {[info exists g_generics]} {
    set synplify_cmds ""
    dict for {name value} $g_generics {
        if {$synplify_cmds ne ""} {
            append synplify_cmds "; "
        }
        append synplify_cmds "set_option -hdl_param -set $name $value"
        puts "Info: Set generic/parameter $name = $value"
    }
    if {$synplify_cmds ne ""} {
        prj_set_strategy_value -strategy Strategy1 "syn_cmdline_args=$synplify_cmds"
    }
}

prj_run_synthesis

# Source post-synthesis TCL hooks (from tcl_hooks.post_synthesis in project.yml)
if {[info exists g_post_synthesis_hooks]} {
    foreach hook $g_post_synthesis_hooks {
        set hook_path "$g_root_dir/$hook"
        if {[file exists $hook_path]} {
            puts "  Sourcing post-synthesis hook: $hook"
            source $hook_path
        } else {
            puts "  WARNING: post-synthesis hook not found: $hook_path"
        }
    }
}

puts "Synthesis completed successfully."
prj_save
prj_close
