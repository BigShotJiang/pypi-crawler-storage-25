# Tich (c) 2024
# Author: Daniel J. Mazure

set module_name front_panel

create_ip -name frontpanel -vendor opalkelly.com -library ip -version 1.0 -module_name $module_name

set_property -dict [list \
  CONFIG.BTPO.ADDR_0 {0xa0} \
  CONFIG.BTPO.ADDR_1 {0xa1} \
  CONFIG.BTPO.COUNT {2} \
  CONFIG.PI.ADDR_0 {0x80} \
  CONFIG.PI.COUNT {1} \
  CONFIG.PO.ADDR_0 {0xb0} \
  CONFIG.PO.ADDR_1 {0xb1} \
  CONFIG.PO.ADDR_2 {0xb2} \
  CONFIG.PO.COUNT {3} \
  CONFIG.RB.EN {true} \
  CONFIG.WI.ADDR_0 {0x10} \
  CONFIG.WI.ADDR_1 {0x11} \
  CONFIG.WI.COUNT {2} \
  CONFIG.WO.ADDR_0 {0x21} \
  CONFIG.WO.ADDR_1 {0x30} \
  CONFIG.WO.ADDR_2 {0x31} \
  CONFIG.WO.ADDR_3 {0x32} \
  CONFIG.WO.ADDR_4 {0x33} \
  CONFIG.WO.COUNT {5} \
] [get_ips $module_name]
