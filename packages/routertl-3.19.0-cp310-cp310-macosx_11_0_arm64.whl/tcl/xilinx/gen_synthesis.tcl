# MIT License
#
# Copyright (c) 2020-2025 Daniel J. Mazure
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
# IN THE SOFTWARE.

# Author: Daniel J.Mazure, Tich
# Date: 09.09.2024
# Description:

if { $::argc > 0 } {
 set g_root_dir    [lindex $argv 0]
 puts "Root directory is $g_root_dir"
}

# Resolve script directory (SDK Support)
set script_path [file normalize [info script]]
set script_dir  [file dirname $script_path]
source "${script_dir}/environment.tcl"
source $g_tcl_dir/impl_utils.tcl

open_project ${g_project_dir}/${g_project_name}.xpr

# Source per-stage TCL hooks (from tcl_hooks.synthesis in project.yml)
if {[info exists g_synthesis_hooks]} {
    foreach hook $g_synthesis_hooks {
        set hook_path "$g_root_dir/$hook"
        if {[file exists $hook_path]} {
            puts "  Sourcing synthesis hook: $hook"
            source $hook_path
        } else {
            puts "  WARNING: synthesis hook not found: $hook_path"
        }
    }
}

# Apply VHDL generics / SV parameters from project.yml (build_options.generics)
# Set on fileset so synth_1 picks them up without project regeneration.
if {[info exists g_generics]} {
    set generic_str ""
    dict for {name value} $g_generics {
        append generic_str "${name}=${value} "
    }
    set generic_str [string trim $generic_str]
    if {$generic_str ne ""} {
        set_property generic $generic_str [current_fileset]
        puts "Info: Applied generics to synthesis: $generic_str"
    }
}

proc synthesis { g_root_dir g_number_of_jobs} {
    # RTL-P2.373: per-target output dirs are set at file scope in
    # build_env.tcl; pull them into the proc's local scope so the
    # post-synth write_checkpoint / reports paths resolve even when
    # this file is nested-sourced from gen_implementation.tcl.
    global g_dcp_dir g_reports_dir

    set number_of_jobs $g_number_of_jobs

    puts "Launching Out Of Context synthesis for IPs."
    puts "Task Started at:"
    set InitDate [clock format [clock seconds] -format %d/%m/%Y]
    set InitTime [clock format [clock seconds] -format %H:%M:%S]
    puts "$InitTime on $InitDate"

    reset_run synth_1
    launch_runs synth_1 -jobs ${g_number_of_jobs}

    # Obtain the Out-Of-Context IP list to be synthesized
    set synthRuns [get_runs -filter {NAME=~ "*_synth_1"}]
    puts "Synthesis runs to be launched:"
    puts [join $synthRuns "\n"]

    # Launch all OOC synthesis runs in parallel. Note: This has already been launched above by the launch_runs command
    # foreach OOCrun $synthRuns {
    #     launch_run $OOCrun -jobs ${g_number_of_jobs}
    # }

    # Wait for all OOC runs to complete collectively
    puts "Waiting for all Out Of Context synthesis runs to complete..."

    foreach OOCrun $synthRuns {
        wait_on_run $OOCrun
        if {[get_property PROGRESS $OOCrun] != "100%"} {
            error "ERROR: $OOCrun failed"
        }
    }
    # Command below works but with an ugly output. Note the "s" that pluralizes the command
    # wait_on_runs [get_runs -filter {NAME=~ "*_synth_1"}]

    puts "**************************************************************"
    puts "All OOC IP synthesis completed. Switch to the top level module"
    puts "**************************************************************"

    #reset_run synth_1
    #launch_runs synth_1 -jobs ${g_number_of_jobs}
    wait_on_run synth_1

    puts "Task Started at:"
    puts "$InitTime on $InitDate"

    puts "Finished at:"
    puts [ clock format [ clock seconds ] -format %d/%m/%Y ]
    puts [ clock format [ clock seconds ] -format %H:%M:%S ]

	open_run synth_1

	set status [get_property STATUS [get_runs synth_1]]

	puts "$status"

	if { $status != "synth_design Complete!"} {
		puts "Design synthesis failed, exiting ..."
		exit 1
	}

	# RTL-P2.373: per-target output dirs from build_env.tcl
	file mkdir $g_dcp_dir
	file mkdir $g_reports_dir

	write_checkpoint -force $g_dcp_dir/synthesis.dcp

	## Synthesis log. The "system_top" is hardcoded as it is always the shell top
	## module name. It could be treated as a global variable either.
	set synthLogPath $g_reports_dir/synthesis
	set synthLog $synthLogPath/synthesis.rpt
	file mkdir $synthLogPath

	## Add this into a open-while loop to parse line by line
	#set UndrivenPins [regexp -all -inline {WARNING: [Synth 8-3295].*$} $line]


}

# Main task
synthesis $g_root_dir $g_number_of_jobs

set logFile "${g_project_dir}/${g_project_name}.runs/synth_1/${g_top_mod}.vds"
set synthLogPath $g_reports_dir/synthesis/${g_top_mod}.vds

if { ![file exists $logFile] } {
    puts "File ${logFile} does not exist"
} else {
	file copy -force ${g_project_dir}/${g_project_name}.runs/synth_1/${g_top_mod}.vds $synthLogPath 
    reportUnconnectedPins $synthLogPath
}

# Source post-synthesis TCL hooks (from tcl_hooks.post_synthesis in project.yml)
if {[info exists g_post_synthesis_hooks]} {
    foreach hook $g_post_synthesis_hooks {
        set hook_path "$g_root_dir/$hook"
        if {[file exists $hook_path]} {
            puts "  Sourcing post-synthesis hook: $hook"
            source $hook_path
        } else {
            puts "  WARNING: post-synthesis hook not found: $hook_path"
        }
    }
}

# ── RouteRTL Report Emitter ──────────────────────────────────
source ${script_dir}/report_emitter.tcl
emit_synth_report $g_root_dir
