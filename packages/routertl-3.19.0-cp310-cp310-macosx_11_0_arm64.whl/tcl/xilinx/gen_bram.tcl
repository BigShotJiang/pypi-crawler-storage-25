# MIT License
#
# Copyright (c) 2020-2025 Daniel J. Mazure
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
# IN THE SOFTWARE.

# Author: Daniel J.Mazure, Tich
# Date: 09.09.2024
# Description:

if { $::argc > 0 } {
 set g_root_dir    [lindex $argv 0]
 puts "Root directory is $g_root_dir"
}

source $g_root_dir/tcl/xilinx/environment.tcl

set g_tmp_dir $g_root_dir/tmp

set list_projs [get_projects -quiet]
if { $list_projs eq "" } {
    create_project ddr_model_generation $g_tmp_dir -force -part $g_fpga_part 
}


set C_BRAM_DEPTH 4096; # Max size of the BRAM Controller is 262144
set C_DATA_WIDTH  128   
set C_KEEP_WIDTH  [expr {$C_DATA_WIDTH/8}]
set C_ID_WIDTH   2
set C_BRAM_ADDR_NBITS [expr {int(ceil(log(double($C_BRAM_DEPTH))/log(2.0))) +4}]


set g_pkg_file    $g_root_dir/src/pkg/ddr_model_pkg
set g_comp_file   $g_root_dir/misc/ddr_component.vhd

set fd_pkg    [open $g_pkg_file "w"]

set ActualTime [clock seconds]
set InitialTime [clock format $ActualTime -format %H:%M:%S -gmt true]

puts $fd_pkg "-- File created @[clock format [clock seconds]]"
puts $fd_pkg "-- This file is created automatically by the script @[file normalize [info script]] \r\n"

set libraries "library IEEE;\r\nuse IEEE.STD_LOGIC_1164.all;\r\nuse IEEE.NUMERIC_STD.all;\r\nuse IEEE.NUMERIC_STD.all;
use IEEE.MATH_REAL.all;
"

puts $fd_pkg $libraries

puts $fd_pkg "package ddr_model_pkg is
"

puts $fd_pkg "
  -----------------------------------------------------------------------------
  -- Specific constants for the BRAM declaration
  -----------------------------------------------------------------------------

  constant C_BRAM_ADDR_NBITS : integer := ${C_BRAM_ADDR_NBITS};
  constant C_DATA_WIDTH      : integer := ${C_DATA_WIDTH};
  constant C_KEEP_WIDTH      : integer := ${C_KEEP_WIDTH};
  constant C_ID_WIDTH        : integer := ${C_ID_WIDTH};
"

set fd_comp [open $g_comp_file "r"]
 
fcopy $fd_comp $fd_pkg
close $fd_comp


create_ip -name axi_bram_ctrl -vendor xilinx.com -library ip -version 4.1 -module_name ddr_model -dir $g_root_dir/ip
set_property -dict [list \
  CONFIG.BMG_INSTANCE {INTERNAL} \
  CONFIG.DATA_WIDTH $C_DATA_WIDTH \
  CONFIG.MEM_DEPTH $C_BRAM_DEPTH \
  CONFIG.SINGLE_PORT_BRAM {1} \
  CONFIG.ID_WIDTH $C_ID_WIDTH \
] [get_ips ddr_model]

puts $fd_pkg "end package ddr_model_pkg;"

puts $fd_pkg "\r\npackage body ddr_model_pkg is"

puts $fd_pkg "\r\nend ddr_model_pkg;\r\n"


close $fd_pkg

file copy -force $g_pkg_file ${g_pkg_file}.vhd
file delete -force $g_pkg_file

file delete -force $g_tmp_dir