# MIT License
#
# Copyright (c) 2020-2026 Daniel J. Mazure
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
# IN THE SOFTWARE.

# Author: Daniel J.Mazure, Tich
# Date: 16.03.2026
# Description: Export Vivado Hardware Platform (.xsa) from implementation DCP.
#              Standalone equivalent of the catch-wrapped call in gen_bitstream.tcl.
#              Usage: vivado -mode batch -source export_xsa.tcl -tclargs <root_dir>

if { $::argc > 0 } {
    set g_root_dir [lindex $::argv 0]
} else {
    puts "ERROR: Root directory argument required."
    puts "Usage: vivado -mode batch -source export_xsa.tcl -tclargs <root_dir>"
    exit 1
}

puts "INFO: Exporting XSA from $g_root_dir"

# Locate the implementation checkpoint
set impl_dcp "$g_dcp_dir/implementation.dcp"
if {![file exists $impl_dcp]} {
    puts "ERROR: Implementation checkpoint not found: $impl_dcp"
    puts "       Run 'rr implementation' or 'rr bitstream' first."
    exit 1
}

# Open the implemented design
open_checkpoint $impl_dcp

# Create output directory (RTL-P2.373: per-target output dirs)
file mkdir $g_build_dir

# RTL-P2.391: artefact basename comes from project.name in yml — same
# convention as gen_bitstream.tcl so .bit / .xsa round-trip cleanly.
# Multi-target projects distinguish artefacts via distinct project.name
# values per target yml.
set bit_file "$g_bitstream_dir/${g_project_name}.bit"
set xsa_file "$g_build_dir/${g_project_name}.xsa"

if {[file exists $bit_file]} {
    puts "INFO: Including bitstream in XSA: $bit_file"
    write_hw_platform -fixed -include_bit -force -file $xsa_file
} else {
    puts "INFO: No bitstream found, exporting XSA without bitstream."
    write_hw_platform -fixed -force -file $xsa_file
}

puts "✅ XSA exported: $xsa_file"
