# Xilinx JTAG Chain Scanner (Vivado HW Manager)
# (c) 2026 RouteRTL
#
# Outputs tagged lines for Python parsing:
#   CABLE:<target_name>
#   DEVICE:<position>:<idcode>:<name>

open_hw_manager
connect_hw_server -quiet

foreach target [get_hw_targets] {
    puts "CABLE:$target"
    open_hw_target $target
    foreach dev [get_hw_devices] {
        set idcode [get_property IDCODE $dev]
        set name   [get_property NAME $dev]
        set pos    [get_property POSITION $dev]
        puts "DEVICE:$pos:$idcode:$name"
    }
    close_hw_target
}

disconnect_hw_server
close_hw_manager
