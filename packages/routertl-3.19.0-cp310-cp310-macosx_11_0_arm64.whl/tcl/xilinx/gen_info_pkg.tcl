# DEPRECATED: Replaced by sdk/generators/regbank/gen_build_metadata.py
# This script is kept for backward compatibility with external callers.
# It will be removed in a future release.
#
# MIT License
#
# Copyright (c) 2020-2025 Daniel J. Mazure
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
# IN THE SOFTWARE.

# Author: Daniel J.Mazure, Tich
# Date: 09.09.2024
# Description:

# Usage: tcl/gen_info_pkg.tcl <root_dir> <regbank_manifest_file>
if { $::argc >= 1 } {
    set g_root_dir  [lindex $argv 0]
    puts "Root dir is  $g_root_dir"
}

set C_MANIFEST_HEX [file normalize [lindex $argv 1]]
set C_CONFIG_HEX   [file normalize [lindex $argv 2]]

source ${g_root_dir}/tcl/xilinx/environment.tcl
## 1. Create the constants and include them in the pkg file, which is created here
set g_info_file [file normalize "${g_root_dir}/misc/rom.data"]


set fd_info [open $g_info_file r]

# Pops from the file in order of apparence
set C_BUILD_DATE      [gets $fd_info]
set C_GIT_HASH        [gets $fd_info]
set C_SYSTEM_VERSION     [gets $fd_info]
set C_REGBANK_VERSION [gets $fd_info]
set C_MANIFEST_WORDS  [gets $fd_info]
set C_CONFIG_WORDS    [gets $fd_info]

set v_manifests_words [scan $C_MANIFEST_WORDS %x]
set v_config_words    [scan $C_CONFIG_WORDS %x]

close $fd_info
# set C_FIFO_EP_DEPTH_NBITS [expr {int(ceil(log(double($C_FIFO_EP_DEPTH))/log(2.0)))} + $FWFT]

puts "Git Hash Hex value: $C_GIT_HASH"
puts "Build Date: $C_BUILD_DATE"

set g_pkg_name    rom_info_pkg
set g_pkg_file    $g_root_dir/src/pkg/${g_pkg_name}

set fd_pkg    [open $g_pkg_file "w"]

set ActualTime  [clock seconds]
set InitialTime [clock format $ActualTime -format %H:%M:%S -gmt true]

puts $fd_pkg "-- Tich (c) 2025"
puts $fd_pkg "-- File created @[clock format [clock seconds]]"
puts $fd_pkg "-- This file was created automatically by the gen_info_pkg tcl script"


set libraries "
library IEEE;
use IEEE.STD_LOGIC_1164.all;
use IEEE.NUMERIC_STD.all;
use IEEE.MATH_REAL.all;
"
# Write the libraries to the components file
puts $fd_pkg $libraries;

# Write the package declaration to the components file
puts $fd_pkg "package ${g_pkg_name} is"

puts $fd_pkg "
  constant C_ROM_DATA_WIDTH  : integer  := 32;
  constant C_GIT_HASH        : std_logic_vector(C_ROM_DATA_WIDTH-1 downto 0) := x\"${C_GIT_HASH}\";
  constant C_SYSTEM_VERSION     : std_logic_vector(C_ROM_DATA_WIDTH-1 downto 0) := x\"${C_SYSTEM_VERSION}\";
  constant C_BUILD_DATE      : std_logic_vector(C_ROM_DATA_WIDTH-1 downto 0) := x\"${C_BUILD_DATE}\";
  constant C_REGBANK_VERSION : std_logic_vector(C_ROM_DATA_WIDTH-1 downto 0) := x\"${C_REGBANK_VERSION}\";
  constant C_MANIFEST_WORDS  : std_logic_vector(C_ROM_DATA_WIDTH-1 downto 0) := x\"${C_MANIFEST_WORDS}\"; -- ${v_manifests_words} words
  constant C_CONFIG_WORDS    : std_logic_vector(C_ROM_DATA_WIDTH-1 downto 0) := x\"${C_CONFIG_WORDS}\"; -- ${v_config_words} words
  constant C_MANIFEST_HEX    : string := \"${C_MANIFEST_HEX}\";
  constant C_CONFIG_HEX      : string := \"${C_CONFIG_HEX}\";
"

puts $fd_pkg "
end package ${g_pkg_name};
"
puts $fd_pkg "
package body ${g_pkg_name} is
"
puts $fd_pkg "
end ${g_pkg_name};
"

close $fd_pkg

file copy -force $g_pkg_file ${g_pkg_file}.vhd

file delete -force $g_pkg_file
