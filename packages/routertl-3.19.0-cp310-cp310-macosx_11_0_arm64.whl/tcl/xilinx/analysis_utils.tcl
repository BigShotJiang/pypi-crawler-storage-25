# MIT License
#
# Copyright (c) 2020-2025 Daniel J. Mazure
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
# IN THE SOFTWARE.

#******************************************************************************
# Procedure: report_primitive_cells
# Description: Reports detailed information about primitive cells matching a given reference name.
#              First prints all unique primitive cell types in the design, then
#              provides detailed information for cells matching the specified reference name.
#
# Arguments:
#   cell_ref_name - (string) Reference name of the cells to report
#
# Returns: None
#
# Prints:
#   - List of all unique primitive cell types
#   - For each matching cell:
#     * Cell name
#     * Reference name
#     * Library cell name
#     * Primitive status
#   - Total count of matching cells
#
# Example:
#   report_primitive_cells "FDRE"
#******************************************************************************

proc report_primitive_cells { cell_ref_name} {

  foreach cell [lsort -unique [get_property LIB_CELL [get_cells -hier \
  -filter {IS_PRIMITIVE==1}]]] {puts $cell}

  set num_cells 0

  foreach cell [get_cells -hier -filter REF_NAME==${cell_ref_name}] {
      puts "Cell: $cell"
      puts "  REF_NAME: [get_property REF_NAME $cell]"
      puts "  LIB_CELL: [get_property LIB_CELL $cell]"
      puts "  IS_PRIMITIVE: [get_property IS_PRIMITIVE $cell]"
      set num_cells [expr $num_cells + 1]
  }

  puts "Number of cells with REF_NAME ${cell_ref_name}: $num_cells"
}


    # Identify all FFs with asynchronous reset (FDCE and FDPE)
proc report_async_resets {grouping_level} {
    # Get all FFs with asynchronous reset based on REF_NAME
    set async_ffs [get_cells -hier -filter {REF_NAME == FDCE || REF_NAME == FDPE}]
    set num_ff [llength $async_ffs]
    puts "Found $num_ff flip-flops with asynchronous reset (FDCE/FDPE)"

    # Group by hierarchy up to the specified depth
    array set ff_by_group {}

    foreach ff $async_ffs {
        set full_name $ff
        set parts [split $full_name "/"]
        if {[llength $parts] > $grouping_level} {
            set group [join [lrange $parts 0 $grouping_level] "/"]
        } else {
            set group $full_name
        }

        if {![info exists ff_by_group($group)]} {
            set ff_by_group($group) 0
        }
        incr ff_by_group($group)
    }

    puts "\nGrouped count of async FFs (by first $grouping_level hierarchy levels):"
    foreach group [lsort [array names ff_by_group]] {
        puts [format "  %-60s %5d" $group $ff_by_group($group)]
    }

    puts "\nExample FF placements:"
    foreach ff [lrange $async_ffs 0 9] {
        set site [get_property SITE $ff]
        set bel  [get_property BEL $ff]
        puts "  [string range $ff 0 60]  => Site: $site, BEL: $bel"
    }
}


proc find_low_fanout_ce {max_fanout} {
    set ffs [get_cells -hier -filter {REF_NAME =~ FD*}]
    set ce_drivers [dict create]

    foreach ff $ffs {
        set ce_pin [get_pins -of_object $ff -filter {NAME =~ *CE}]
        if {[llength $ce_pin] == 0} { continue }
        set net [get_nets -of $ce_pin]
        if {[llength $net] != 1} { continue }
        set net_name [get_property NAME $net]
        dict incr ce_drivers $net_name
    }

    puts "Low fanout clock enable nets (≤ $max_fanout FFs):"
    foreach {net count} [dict get $ce_drivers] {
        if {$count <= $max_fanout} {
            puts "  $net drives $count FFs"
        }
    }
}