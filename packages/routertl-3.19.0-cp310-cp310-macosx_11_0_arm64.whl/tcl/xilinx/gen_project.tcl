# MIT License
#
# Copyright (c) 2020-2025 Daniel J. Mazure
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
# IN THE SOFTWARE.

# Author: Daniel J.Mazure, Tich
# Date: 09.09.2024
# Description:  Generates a Vivado project from the command line

if { $::argc >= 2} {
    set g_root_dir    [lindex $argv 0]
    set vhd_files     [lindex $argv 1]
    set xci_files     [lindex $argv 2]
    set sim_files     [lindex $argv 3]
    set tcl_files     [lindex $argv 4]
    set xdc_files     [lindex $argv 5]
    set netlist_files [lindex $argv 6] ;# Pre-compiled netlists (.dcp/.edf/.ngc)
    puts "Root dir is $g_root_dir"
} else {
    puts "Error: Not enough arguments \($::argc\), exiting ..."
    exit
}

# Resolve script directory for relative sourcing (SDK Support)
set script_path [file normalize [info script]]
set script_dir  [file dirname $script_path]
source "${script_dir}/environment.tcl"

################################################################
# START
################################################################

set list_projs [get_projects -quiet]
if { $list_projs eq "" } {
    create_project $g_project_name $g_project_dir -force -part $g_fpga_part
}
set thisProject [current_project]
set_property target_language VHDL $thisProject

# In case getting into the console later on
# cd [get_property DIRECTORY $thisProject]
# cd $g_root_directory

# This needs to be defined before creating the block design, if any
set ip_dir_list [get_property ip_repo_paths $thisProject]

# Add more IP dirs to the ip_paths variable before next loop

foreach ip_path $g_ip_paths {
  lappend ip_dir_list $ip_path
}

# Append user IP repository paths from sources.ip_paths (project.yml)
if {[info exists g_user_ip_paths]} {
  foreach ip_path $g_user_ip_paths {
    lappend ip_dir_list $ip_path
  }
}

set_property ip_repo_paths $ip_dir_list $thisProject

# Stub IP directory for dummy IP generation (P2.266)
set _rr_stub_dir "${g_root_dir}/hw/ip_stubs"
file mkdir $_rr_stub_dir

#set vhd_files [glob ${g_root_dir}/src/*.vhd]; # This is coming from the Makefile as a filelist.
# vhd_files is comming from the Makefile. Same could be done for sim files, xdc files, xci or pkgs.
# Files comming from the Makefile definition is not working with WSL

# set vhd_files [glob ${g_root_dir}/src/*.vhd ${g_root_dir}/src/pkg/*.vhd]
# set xdc_files [glob ${g_root_dir}/xdc/system_*.xdc ]
# set sim_files [glob ${g_root_dir}/sim/tb* ${g_root_dir}/sim/pkg/*.vhd]

# syn_files (argv[1], historically named vhd_files) carries ALL synthesis sources:
# VHDL, Verilog, SystemVerilog, and netlists (.edn/.edif/.dcp).
# We must tag each file with its correct FILE_TYPE so Vivado's parser
# can resolve module/entity names for BD module references. (P1.5)

if { $xci_files ne "" } {
    import_ip "${xci_files}"
}

if { $vhd_files ne "" } {
    add_files ${vhd_files}
    foreach f $vhd_files {
        set ext [string tolower [file extension $f]]
        if {$ext eq ".vhd" || $ext eq ".vhdl"} {
            set_property file_type {VHDL 2008} [get_files $f]
        } elseif {$ext eq ".sv" || $ext eq ".svh"} {
            set_property file_type {SystemVerilog} [get_files $f]
        }
        # .v  → Vivado auto-detects as Verilog (no override needed)
        # .edn/.edif/.dcp → netlist types, auto-detected
    }
}

if { $xdc_files ne "" } {
    add_files -fileset constrs_1 ${xdc_files}
    set_property used_in_synthesis false [get_files ${xdc_files}]
}

if { $sim_files ne "" } {
    add_files -fileset sim_1  ${sim_files}
    foreach f $sim_files {
        set ext [string tolower [file extension $f]]
        if {$ext eq ".vhd" || $ext eq ".vhdl"} {
            set_property file_type {VHDL 2008} [get_files $f]
        } elseif {$ext eq ".sv" || $ext eq ".svh"} {
            set_property file_type {SystemVerilog} [get_files $f]
        }
    }
}

set_property top $g_top_mod [current_fileset]

# Apply VHDL generics / SV parameters from project.yml (build_options.generics)
if {[info exists g_generics]} {
    set generic_str ""
    dict for {name value} $g_generics {
        append generic_str "${name}=${value} "
    }
    set generic_str [string trim $generic_str]
    if {$generic_str ne ""} {
        set_property generic $generic_str [current_fileset]
        puts "Info: Applied generics to fileset: $generic_str"
    }
}

# Refresh compile order so RTL modules are resolvable as BD module references.
# Required for create_bd_cell -type module -reference to work. (P1.4)
update_compile_order -fileset sources_1
update_compile_order -fileset sim_1


# Bring up the IP defined in the tcl files
# P2.185: resolve paths relative to repo root, not CWD
foreach tcl_file $tcl_files {
    if {[file pathtype $tcl_file] eq "absolute"} {
        set abs_tcl $tcl_file
    } else {
        set abs_tcl [file normalize $g_root_dir/$tcl_file]
    }
    source $abs_tcl
}

set_property top $g_top_sim [get_filesets sim_1]

set_property AUTO_INCREMENTAL_CHECKPOINT 0 [get_runs synth_1]
set_property incremental_checkpoint {} [get_runs synth_1]

# ---------------------------------------------------------------------------
# Pre-compiled netlists (.dcp checkpoint, .edf/.edif EDIF, .ngc legacy)
# ---------------------------------------------------------------------------
if {[info exists netlist_files]} {
    foreach f $netlist_files {
        if {[string trim $f] eq ""} { continue }
        if {[file pathtype $f] eq "absolute"} {
            set abs_f $f
        } else {
            set abs_f [file normalize $g_root_dir/$f]
        }
        set ext [string tolower [file extension $f]]
        if {$ext eq ".dcp"} {
            read_checkpoint -quiet $abs_f
            puts "Info: Read DCP checkpoint '$abs_f'"
        } elseif {$ext eq ".edf" || $ext eq ".edif" || $ext eq ".ngc"} {
            read_edif -quiet $abs_f
            puts "Info: Read EDIF netlist '$abs_f'"
        } elseif {$ext eq ".vhd" || $ext eq ".vhdl"} {
            read_vhdl -vhdl2008 $abs_f
        } elseif {$ext eq ".sv"} {
            read_verilog -sv $abs_f
        } elseif {$ext eq ".v"} {
            read_verilog $abs_f
        } else {
            puts "Warning: Unknown netlist extension '$ext' for $f — skipping"
        }
    }
}

# ---------------------------------------------------------------------------
# User Hooks: Source custom TCL scripts defined in project.yml -> tcl_hooks.gen_project
# ---------------------------------------------------------------------------

# ── Helper: comment out a line in a set_property -dict block cleanly ──
# Handles the trailing-backslash continuation pattern:
#   set_property -dict [list \
#     CONFIG.FOO {bar} \          ← if this is the last real prop...
#     CONFIG.BAD {baz} \          ← ...commenting this out requires
#   ] $cell                          removing the \ from FOO line too
proc _rr_comment_out_line {lines_var line_num} {
    upvar $lines_var lines
    set idx [expr {$line_num - 1}]
    if {$idx < 0 || $idx >= [llength $lines]} { return }

    set line [lindex $lines $idx]

    # If this line has a trailing \, check whether the PREVIOUS
    # non-comment line also has one.  If so, we can safely comment
    # this line out.  If this was the LAST property before ], we
    # need to strip the \ from the previous line.
    set line_trimmed [string trimright $line]
    set has_backslash [expr {[string index $line_trimmed end] eq "\\"}]

    # Comment out the line — strip trailing \ to avoid line continuation
    set clean_line [string trimright $line]
    if {[string index $clean_line end] eq "\\"} {
        set clean_line [string range $clean_line 0 end-1]
    }
    lset lines $idx "## RR-healed ## $clean_line"

    # Fix trailing backslash: find the nearest previous non-comment line
    if {$has_backslash} {
        # Check if the next non-blank, non-comment line is the ] closer
        set next_idx [expr {$idx + 1}]
        while {$next_idx < [llength $lines]} {
            set nxt [string trim [lindex $lines $next_idx]]
            if {$nxt eq "" || [string match "## RR-healed ##*" $nxt]} {
                incr next_idx
                continue
            }
            break
        }
        set next_is_close 0
        if {$next_idx < [llength $lines]} {
            set nxt [string trim [lindex $lines $next_idx]]
            if {[string index $nxt 0] eq "\]"} {
                set next_is_close 1
            }
        }
        if {$next_is_close} {
            # Strip trailing \ from the nearest previous non-comment line
            set prev_idx [expr {$idx - 1}]
            while {$prev_idx >= 0} {
                set prev [lindex $lines $prev_idx]
                if {![string match "## RR-healed ##*" $prev]} {
                    set pt [string trimright $prev]
                    if {[string index $pt end] eq "\\"} {
                        lset lines $prev_idx [string range $pt 0 end-1]
                    }
                    break
                }
                incr prev_idx -1
            }
        }
    }
}

if {[info exists g_gen_project_hooks]} {
    foreach hook_script $g_gen_project_hooks {
        set full_path "${g_root_dir}/${hook_script}"
        if {![file exists $full_path]} {
            puts "WARNING: gen_project hook not found: $full_path"
            continue
        }
        puts "INFO: Sourcing gen_project hook: $hook_script"

        # ── N-pass iterative BD hook healing (RTL-P2.247) ──
        # On failure: identify the offending line, comment it out,
        # delete the partial BD, and restart from a clean state.
        # Repeats up to max_heal_passes times.
        set max_heal_passes 5
        set heal_pass 0
        set healed_lines {}
        set hook_succeeded 0

        # Read the original hook into memory
        set fd [open $full_path r]
        set hook_lines [split [read $fd] "\n"]
        close $fd

        # Work on a mutable copy for patching
        set work_lines $hook_lines
        set connections_wrapped 0

        while {$heal_pass <= $max_heal_passes} {
            # ── Best-effort wiring (RTL-P2.263) ──
            # After any CONFIG healing, wrap connect_bd_* and address
            # commands in catch so wiring continues past missing pins.
            if {[llength $healed_lines] > 0 && !$connections_wrapped} {
                set _wi 0
                set _wrap_count 0
                foreach wl $work_lines {
                    set _wt [string trim $wl]
                    if {[string match "connect_bd_intf_net *" $_wt] ||
                        [string match "connect_bd_net *" $_wt] ||
                        [string match "assign_bd_address *" $_wt] ||
                        [string match "exclude_bd_addr_seg *" $_wt]} {
                        lset work_lines $_wi "if \{\[catch \{$wl\} _rr_conn_err\]\} \{ puts \"WARNING: RouteRTL — skipped: \$_rr_conn_err\" \}"
                        incr _wrap_count
                    }
                    incr _wi
                }
                if {$_wrap_count > 0} {
                    puts "  Wrapped $_wrap_count connect/address commands in catch (P2.263)"
                    set connections_wrapped 1
                }
            }

            # Write current (possibly patched) hook to a temp file
            set work_path "${full_path}.rr_work.tcl"
            set fo [open $work_path w]
            puts $fo [join $work_lines "\n"]
            close $fo

            if {$heal_pass == 0} {
                puts "  Pass 1: sourcing hook..."
            } else {
                puts "  Pass [expr {$heal_pass + 1}]: re-sourcing patched hook..."
            }

            if {[catch {source $work_path} err_msg err_opts]} {
                set err_info [dict get $err_opts -errorinfo]
                set fail_line 0

                # ── Strategy 1: extract the failing CONFIG parameter ──
                # Vivado errors often name the parameter, e.g.:
                #   "Validation failed for parameter '...(TUSER_REMAP)'"
                # Find ALL CONFIG lines with that param and comment them out.
                # ── Strategy 1: strip CONFIG property from set_property block ──
                # When set_property fails inside a proc, the errorinfo
                # contains an rdi::add_properties dump with the CONFIG keys.
                # Find the matching set_property block in the hook and
                # comment out the last CONFIG line (most likely the offender).
                # This preserves all wiring — only the bad property is removed.
                set did_heal_config 0
                set _proc ""
                set _pline 0
                if {[regexp {\(procedure "([^"]+)" line (\d+)\)} $err_info -> _proc _pline]} {
                    if {[string first "set_property" $err_info] >= 0 || [string first "set_property" $err_msg] >= 0} {
                        # Extract CONFIG keys from the rdi::add_properties dump
                        set _cfg_keys {}
                        set _pos 0
                        while {[regexp -start $_pos -indices {CONFIG\.([A-Z_0-9]+)} $err_info _m _g]} {
                            lappend _cfg_keys [string range $err_info [lindex $_g 0] [lindex $_g 1]]
                            set _pos [expr {[lindex $_m 1] + 1}]
                        }

                        if {[llength $_cfg_keys] > 0} {
                            # Find the set_property block in the file that contains
                            # these CONFIG keys.  Match by checking the first few keys.
                            set _match_key "CONFIG.[lindex $_cfg_keys 0]"
                            set _block_start 0
                            set _block_end 0
                            set _last_config_line 0
                            set _li 0
                            foreach wl $work_lines {
                                incr _li
                                # Find block start
                                if {$_block_start == 0 && [string first "set_property -dict" $wl] >= 0} {
                                    # Check if next lines contain our matching key
                                    set _peek_li $_li
                                    set _found_key 0
                                    while {$_peek_li < [llength $work_lines]} {
                                        set _peek [lindex $work_lines $_peek_li]
                                        if {[string first $_match_key $_peek] >= 0} {
                                            set _found_key 1
                                            break
                                        }
                                        # Stop at end of block
                                        if {[regexp {^\s*\]} [string trim $_peek]]} { break }
                                        incr _peek_li
                                    }
                                    if {$_found_key} {
                                        set _block_start $_li
                                    }
                                }
                                # Track CONFIG lines and block end within this block
                                if {$_block_start > 0 && $_block_end == 0} {
                                    if {[string first "CONFIG." $wl] >= 0 && [string first "## RR-healed ##" $wl] < 0} {
                                        set _last_config_line $_li
                                    }
                                    if {[regexp {^\s*\]} [string trim $wl]]} {
                                        set _block_end $_li
                                    }
                                }
                            }

                            if {$_last_config_line > 0} {
                                set _bad [string trim [lindex $work_lines [expr {$_last_config_line - 1}]]]
                                # Extract the CONFIG.XXX key from the line
                                set _bad_key ""
                                regexp {CONFIG\.[A-Z_0-9]+} $_bad _bad_key

                                # Strip this CONFIG property from ALL blocks
                                # in the hook (same property may appear in
                                # multiple hierarchy procs).
                                set _strip_count 0
                                if {$_bad_key ne ""} {
                                    # Walk backwards to avoid index shifts
                                    for {set _si [llength $work_lines]} {$_si > 0} {incr _si -1} {
                                        set _sl [lindex $work_lines [expr {$_si - 1}]]
                                        if {[string first $_bad_key $_sl] >= 0 && [string first "## RR-healed ##" $_sl] < 0} {
                                            _rr_comment_out_line work_lines $_si
                                            incr _strip_count
                                        }
                                    }
                                } else {
                                    _rr_comment_out_line work_lines $_last_config_line
                                    set _strip_count 1
                                }

                                set did_heal_config 1
                                lappend healed_lines [list $_last_config_line "$_bad_key ($_strip_count occurrence(s))"]
                                puts ""
                                puts "  ─── Stripped $_bad_key from $_strip_count location(s) (pass [expr {$heal_pass + 1}]) ───"
                                puts "  Removed: $_bad"
                                puts "  Error: $err_msg"

                                # Clean up partial BD for restart
                                puts "  Cleaning up partial BD for restart..."
                                catch {close_bd_design [current_bd_design]}
                                catch {
                                    set bd_files [get_files -quiet *.bd]
                                    foreach bf $bd_files { catch {remove_files $bf} }
                                }
                                incr heal_pass
                                continue
                            }
                        }
                    }

                    # If config stripping didn't work AND we've already
                    # healed something AND the error is in create_root_design,
                    # save the partial BD — cascading errors from earlier heals.
                    if {$_proc eq "create_root_design" && [llength $healed_lines] > 0} {
                        puts ""
                        puts "═══════════════════════════════════════════════════════"
                        puts "  Cascading errors in create_root_design after"
                        puts "  [llength $healed_lines] heal(s) — saving partial BD."
                        puts "  Error: $err_msg"
                        puts "═══════════════════════════════════════════════════════"
                        catch {update_compile_order -fileset sources_1}
                        if {[catch {save_bd_design} _sav_err]} {
                            puts "  ❌ Could not save partial BD: $_sav_err"
                        } else {
                            puts "  ✅ Partial BD saved."
                        }
                        set hook_succeeded 1
                        break
                    }
                }

                # ── Strategy 2: map (procedure "..." line N) to file line ──
                if {$fail_line == 0} {
                    set proc_name ""
                    set proc_offset 0
                    if {[regexp {\(procedure "([^"]+)" line (\d+)\)} $err_info -> proc_name proc_offset]} {
                        set proc_start 0
                        set lidx 0
                        foreach wl $work_lines {
                            incr lidx
                            if {[regexp "^\\s*proc\\s+$proc_name\\s" $wl]} {
                                set proc_start $lidx
                                break
                            }
                        }
                        if {$proc_start > 0} {
                            set fail_line [expr {$proc_start + $proc_offset}]
                        }
                    }
                }

                # ── Strategy 3 (fallback): use (file "..." line N) ──
                if {$fail_line == 0} {
                    if {[regexp {\(file "[^"]*" line (\d+)\)} $err_info -> line_num]} {
                        set fail_line $line_num
                    }
                }

                if {$fail_line > 0 && $heal_pass < $max_heal_passes} {
                    puts ""
                    puts "  ─── Failure at line $fail_line (pass [expr {$heal_pass + 1}]/$max_heal_passes) ───"
                    puts "  Error: $err_msg"
                    set bad_line [lindex $work_lines [expr {$fail_line - 1}]]
                    puts "  Line:  [string trim $bad_line]"

                    lappend healed_lines [list $fail_line [string trim $bad_line]]

                    # Comment out the offending line cleanly
                    _rr_comment_out_line work_lines $fail_line

                    # Delete the partial BD so next pass starts clean
                    puts "  Cleaning up partial BD for restart..."
                    catch {close_bd_design [current_bd_design]}
                    # Delete the BD files that were written
                    catch {
                        set bd_files [get_files -quiet *.bd]
                        foreach bf $bd_files {
                            catch {remove_files $bf}
                        }
                    }

                    incr heal_pass
                    continue
                }

                # Either couldn't parse line number, or exhausted retries.
                # Save whatever partial BD we have.
                puts ""
                puts "═══════════════════════════════════════════════════════"
                if {$heal_pass >= $max_heal_passes} {
                    puts "  BD hook: exhausted $max_heal_passes healing passes"
                } else {
                    puts "  BD hook failed (could not determine failure line)"
                }
                puts "  Error: $err_msg"
                puts "═══════════════════════════════════════════════════════"
                puts ""
                puts "  Saving partial block design..."
                catch {update_compile_order -fileset sources_1}
                if {[catch {save_bd_design} save_err]} {
                    puts "  ❌ Could not save partial BD: $save_err"
                } else {
                    puts "  ✅ Partial BD saved — open in Vivado GUI to inspect."
                }
                break

            } else {
                # Hook completed without fatal error.
                # Check if any cells failed silently via _rr_create_cell.

                # ── Strategy: Stub IP generation for missing cells (P2.266) ──
                if {[info exists _rr_failed_vlnvs] && [dict size $_rr_failed_vlnvs] > 0 && $heal_pass < $max_heal_passes} {
                    set _stub_count 0
                    dict for {_cell_name _vlnv} $_rr_failed_vlnvs {
                        set _ports [list]
                        if {[info exists _rr_cell_ports($_cell_name)]} {
                            set _ports $_rr_cell_ports($_cell_name)
                        }
                        if {[_rr_gen_dummy_ip $_vlnv $_rr_stub_dir $_ports]} {
                            incr _stub_count
                        }
                    }
                    if {$_stub_count > 0} {
                        puts "  Generated $_stub_count dummy stub IP(s) (P2.266)"
                        # Add stubs to IP catalog
                        set ip_dir_list [get_property ip_repo_paths [current_project]]
                        if {[lsearch $ip_dir_list $_rr_stub_dir] < 0} {
                            lappend ip_dir_list $_rr_stub_dir
                            set_property ip_repo_paths $ip_dir_list [current_project]
                        }
                        update_ip_catalog -rebuild
                        puts "  Restarting hook with stub IPs in catalog..."

                        # Reset failure tracking
                        set _rr_failed_cells [list]
                        set _rr_failed_vlnvs [dict create]

                        # Clean BD for restart
                        catch {close_bd_design [current_bd_design]}
                        catch {
                            set bd_files [get_files -quiet *.bd]
                            foreach bf $bd_files {
                                catch {remove_files $bf}
                            }
                        }

                        lappend healed_lines [list "P2.266" "generated $_stub_count stub IP(s)"]
                        incr heal_pass
                        continue
                    }
                }

                set hook_succeeded 1
                break
            }
        }

        # Clean up temp work file
        file delete -force "${full_path}.rr_work.tcl"

        # Report healing summary
        if {[llength $healed_lines] > 0} {
            puts ""
            puts "═══════════════════════════════════════════════════════"
            if {$hook_succeeded} {
                puts "  ✅ BD hook succeeded after [llength $healed_lines] auto-heal(s)"
            } else {
                puts "  ⚠️  BD hook: [llength $healed_lines] line(s) healed, still failed"
            }
            puts "  Healed lines:"
            foreach entry $healed_lines {
                set ln [lindex $entry 0]
                set cmd [lindex $entry 1]
                puts "    line $ln: $cmd"
            }
            puts "═══════════════════════════════════════════════════════"

            # Write the final patched hook as .healed.tcl for reference
            set healed_path "${full_path}.healed.tcl"
            set fo [open $healed_path w]
            puts $fo [join $work_lines "\n"]
            close $fo
            puts "  Healed hook saved: $healed_path"
        }

        # ── Post-healing BD content check ──
        # Verify the BD actually has cells.  An empty BD means the
        # healing was too aggressive (e.g. wrapped create_root_design).
        if {$hook_succeeded || [llength $healed_lines] > 0} {
            set bd_cells [get_bd_cells -quiet /*]
            set n_cells [llength $bd_cells]
            if {$n_cells == 0} {
                puts ""
                puts "  ❌ BD is empty — healing removed too much."
                puts "     The block design has no cells."
                puts "     Check the .healed.tcl hook and fix manually."
            } else {
                puts "  BD content check: $n_cells top-level cell(s) found ✓"
            }
        }
    }

    # Resolve compile order after all hooks have been sourced
    catch {update_compile_order -fileset sources_1}
}
