# Xilinx Software Download Script (MicroBlaze/Zynq)
# (c) 2026 RouteRTL

if { $argc < 3 } {
    puts "Usage: gen_software_program.tcl <root_dir> <elf_path> <cable_id>"
    exit 1
}

set g_root_dir [lindex $argv 0]
set g_elf_path [lindex $argv 1]
set g_cable_id [lindex $argv 2]

puts "⚠️  Software download for Xilinx via Vivado TCL is currently suboptimal."
puts "   Use 'xsct' or 'updatemem' instead."
puts "   (In-project MicroBlaze BRAM update coming soon)"

exit 1
