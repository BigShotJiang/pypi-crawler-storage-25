# MIT License
#
# Copyright (c) 2020-2025 Daniel J. Mazure
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
# IN THE SOFTWARE.

# Author: Daniel J.Mazure, Tich
# Date: 09.09.2024
# Description:

if { $::argc > 0 } {
 set g_root_dir    [lindex $argv 0]
 puts "Root directory is $g_root_dir"
}

source $g_root_dir/tcl/xilinx/environment.tcl

set bitstream_dir "$g_bitstream_dir"
set bit_extension "*.bit"
set ila_extension "*.ltx"

set bit_file [glob -nocomplain "$bitstream_dir/$bit_extension"]
set ltx_files [glob -nocomplain "$bitstream_dir/$ila_extension"]


# if {[llength $bit_file] > 0} {
#     puts "Found bit file: $bit_file"
# } else {
#     puts "No files with extension $bit_extension found in $bitstream_dir"
#     exit 0;
# }

if {[llength $ltx_files] > 0} {
    puts "Found ltx file: $ltx_files"
} else {
    puts "No files with extension $ila_extension found in $bitstream_dir"
    exit 0;
}


open_hw_manager
connect_hw_server -allow_non_jtag
open_hw_target
set fpga_device [current_hw_device [lindex [get_hw_devices] 0]]

# set_property PROGRAM.FILE $bit_file [get_hw_devices $fpga_device]
# program_hw_devices $fpga_device

set_property PROBES.FILE "$ltx_files" [get_hw_devices $fpga_device]
set_property FULL_PROBES.FILE "$ltx_files" [get_hw_devices $fpga_device]
start_gui
refresh_hw_device $fpga_device
display_hw_ila_data [ get_hw_ila_data hw_ila_data_1 -of_objects [get_hw_ilas -of_objects [get_hw_devices $fpga_device] -filter {CELL_NAME=~"u_ila_0"}]]

