# Xilinx Bitstream Verification (Vivado HW Manager)
# (c) 2026 RouteRTL
#
# Verifies that the programmed bitstream matches the local file.
# Usage: verify_bitstream.tcl <root_dir> <bitstream_path> <cable_id>

if { $argc < 3 } {
    puts "Usage: verify_bitstream.tcl <root_dir> <bitstream_path> <cable_id>"
    exit 1
}

set g_root_dir [lindex $argv 0]
set g_bitstream_path [lindex $argv 1]
set g_cable_id [lindex $argv 2]

# --- Discovery ---
if { $g_bitstream_path == "" } {
    set bitstream_candidates [glob -nocomplain "${g_root_dir}/*.bit" "${g_root_dir}/project/*.bit" "${g_root_dir}/output_files/*.bit"]
    if { [llength $bitstream_candidates] > 0 } {
        set g_bitstream_path [lindex $bitstream_candidates 0]
        puts "   ℹ️  Auto-detected bitstream: $g_bitstream_path"
    } else {
        puts "❌ Error: No bitstream file (.bit) found."
        exit 1
    }
}

puts "🛡️  Verifying Xilinx FPGA bitstream..."
puts "   File: $g_bitstream_path"

open_hw_manager
connect_hw_server -quiet

if { [get_hw_targets] == "" } {
    puts "❌ Error: No JTAG targets found."
    exit 1
}

set target [get_hw_targets -filter "NAME =~ \"*$g_cable_id*\""]
if { $target == "" } {
    set target [lindex [get_hw_targets] 0]
}

open_hw_target $target
set device [lindex [get_hw_devices] 0]

refresh_hw_device $device
set_property PROBES.FILE {} $device
set_property PROGRAM.FILE $g_bitstream_path $device

if { [catch { verify_hw_devices $device } result] } {
    puts "❌ Verification FAILED: $result"
    close_hw_target
    disconnect_hw_server
    close_hw_manager
    exit 1
}

puts "✅ Verification successful — programmed bitstream matches local file."

close_hw_target
disconnect_hw_server
close_hw_manager
