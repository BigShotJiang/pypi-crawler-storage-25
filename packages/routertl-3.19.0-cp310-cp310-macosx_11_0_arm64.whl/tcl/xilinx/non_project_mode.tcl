# MIT License
#
# Copyright (c) 2020-2025 Daniel J. Mazure
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
# IN THE SOFTWARE.

# Author: Daniel J.Mazure, Tich
# Date: 11.09.2024
# Description:  Generates a Vivado project from the command line in non-project mode

if { $::argc >= 4} {
    set g_root_dir  [lindex $argv 0]
    set src_files   [lindex $argv 1]
    set ip_files    [lindex $argv 2]
    set xdc_files   [lindex $argv 3]
    set top_module  [lindex $argv 4]
    set netlist_files [lindex $argv 5] ;# Pre-compiled netlists (.dcp/.edf/.ngc)
    puts "Root dir: $g_root_dir"
    puts "Top Modules: $top_module"
} else {
    puts "Error: Not enough arguments \($::argc\). Expected: root_dir src_files ip_files xdc_files top_module [netlist_files]"
    exit 1
}

set script_path [file normalize [info script]]
set script_dir  [file dirname $script_path]
source "${script_dir}/environment.tcl"

# Create a new non-project mode workspace
create_project -in_memory
set_part $g_fpga_part

set thisProject [current_project]

# 1. Read IP Files
if {[llength $ip_files] > 0} {
    puts "Reading IP files..."
    read_ip -verbose $ip_files
    # Update IP repo paths if needed, though read_ip usually sufficient for local XCI
    # set_property ip_repo_paths [...] $thisProject
}

# 2. Read Source Files — VHDL/Verilog (each token is lib:path from --list-libs)
if {[llength $src_files] > 0} {
    puts "Reading Source files..."
    foreach token $src_files {
        # Split lib:path on the first colon
        set colon_idx [string first ":" $token]
        if {$colon_idx >= 0} {
            set lib [string range $token 0 [expr {$colon_idx - 1}]]
            set f   [string range $token [expr {$colon_idx + 1}] end]
        } else {
            set lib "work"
            set f   $token
        }
        if {[string match -nocase "*.vhd" $f]} {
            read_vhdl -vhdl2008 -library $lib $f
        } elseif {[string match -nocase "*.v" $f] || [string match -nocase "*.sv" $f]} {
            read_verilog -sv $f
        }
    }
}

# 3. Read Constraints
if {[llength $xdc_files] > 0} {
    puts "Reading XDC files..."
    read_xdc $xdc_files
}

# 4. Pre-compiled netlists (.dcp checkpoint, .edf/.edif EDIF, .ngc legacy)
if {[info exists netlist_files]} {
    foreach f $netlist_files {
        if {[string trim $f] eq ""} { continue }
        if {[file pathtype $f] eq "absolute"} {
            set abs_f $f
        } else {
            set abs_f [file normalize $g_root_dir/$f]
        }
        set ext [string tolower [file extension $f]]
        if {$ext eq ".dcp"} {
            read_checkpoint -quiet $abs_f
            puts "Info: Read DCP checkpoint '$abs_f'"
        } elseif {$ext eq ".edf" || $ext eq ".edif" || $ext eq ".ngc"} {
            read_edif -quiet $abs_f
            puts "Info: Read EDIF netlist '$abs_f'"
        } elseif {$ext eq ".vhd" || $ext eq ".vhdl"} {
            read_vhdl -vhdl2008 $abs_f
        } elseif {$ext eq ".sv"} {
            read_verilog -sv $abs_f
        } elseif {$ext eq ".v"} {
            read_verilog $abs_f
        } else {
            puts "Warning: Unknown netlist extension '$ext' for $f — skipping"
        }
    }
}

# 5. Synthesize
puts "Synthesizing $top_module..."
# Note: dependency_resolver returns compilation order, so we rely on that.
# update_compile_order is irrelevant for read_* commands in NPM usually, 
# but good for safety if mixed.
# update_compile_order -quiet 

# Create output directory (RTL-P2.373: per-target output dirs)
file mkdir $g_dcp_dir/${top_module}

# Elaborate and Synthesize
# flatten_hierarchy rebuilt is good for generic RTL
# Apply VHDL generics / SV parameters from project.yml (build_options.generics)
set generic_args ""
if {[info exists g_generics]} {
    dict for {name value} $g_generics {
        append generic_args " -generic ${name}=${value}"
    }
}
synth_design -top $top_module -part $g_fpga_part -flatten_hierarchy rebuilt {*}$generic_args

# 5. Write Checkpoint
puts "Writing Checkpoint to $g_dcp_dir/${top_module}/${top_module}_synthesis.dcp"
write_checkpoint -force $g_dcp_dir/${top_module}/${top_module}_synthesis.dcp

# Report (Optional)
report_utilization -file $g_dcp_dir/${top_module}/${top_module}_utilization.rpt

puts "NPM Synthesis Complete."
quit
