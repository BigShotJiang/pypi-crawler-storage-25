# MIT License
#
# Copyright (c) 2020-2025 Daniel J. Mazure
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
# IN THE SOFTWARE.

# Author: Daniel J.Mazure, Tich
# Date: 11.09.2024
# Description:

if { $::argc > 0 } {

 set g_root_dir [lindex $argv 0]
 set g_dcp_on     "false"
 set g_quick_impl "false"
 puts "Root directory is $g_root_dir"

} else { 
 puts "Bad usage. This script needs to receive the root directory as an argument"
 return 0
} 

if { $::argc > 1} { 

 set g_dcp_on  [lindex $argv 1]
 puts "Post opt and post place dcp generation is set to $g_dcp_on"

}

if { $::argc > 2} { 

 set g_quick_impl  [lindex $argv 2]
 puts "Fast Implementation is set to $g_quick_impl"

}

# Resolve script directory (SDK Support)
set script_path [file normalize [info script]]
set script_dir  [file dirname $script_path]
source "${script_dir}/environment.tcl"
source $g_tcl_dir/impl_utils.tcl


proc implementation { g_root_dir g_place_directive g_route_directive g_dcp_on g_quick_impl} {
	# RTL-P2.373: per-target output dirs
	global g_dcp_dir g_reports_dir

	set RefTime [clock seconds]
	## It is assumed a dcp folder containing the synthesis dcp already exists
	file mkdir $g_reports_dir

	### Check as early as possible that all logical ports and all I/O
	### standards are specified.
	### This likely shouldn't happen as the Shell is "fixed", but it is
	### better to detect if that happen here than in the bitgen phase.
	if { [reportEarlyDRC $g_root_dir] == 1 } {
		puts "Detected Unspecified Logic Levels or Unconstraiend ports."
		puts "Implementation will not continue. Check the pinout."
		# TODO: Check if this is working commenting a physical top level pin
		exit 1
	}


	if { $g_quick_impl == "true" } {
		set opt_design_directive "RuntimeOptimized"
		set place_design_directive "Quick"
		set phys_opt_design_directive "Default"
		set route_design_directive "Quick"
		set post_route_directive "Default"
	} else {
		set opt_design_directive "Explore"
		set place_design_directive "$g_place_directive"
		set phys_opt_design_directive "Default"
		set route_design_directive "$g_route_directive"
		set post_route_directive "AggressiveExplore"
	}


	#opt_design
	# opt_design can be called with switches: opt_design -retarget -sweep
	# For example, a congested design may benefit from skipping the remap option.
	# By default, opt_design does: -retarget -sweep -remap -propconst -resynth_area
	# Non-default: -area_mode -effort_level <arg>  -verbose
	opt_design -directive Explore


	# Store the Lapsed time up to opt_desing finish
	set Lapsed2optTime [getLapsedTime $RefTime]
	puts "Lapsed time after opt_design: $Lapsed2optTime"
	puts "--------------------------------------"

	if { $g_dcp_on == "true" } {
            # RTL-P2.373: per-target output dirs
            write_checkpoint -force $g_dcp_dir/post_opt.dcp
	}

	# Optional Power Optimization
	#power_opt_design
	# TODO: Add a time stamp from here to the end of the process, so it can be compared
	# with other configurations -Vivado flow or when the place directive is set after
	# getting it with ExhaustivePlaceFlow

	puts "Place design starting at:"
	set InitDate [ clock format [ clock seconds ] -format %d/%m/%Y ]
	set InitTime [ clock format [ clock seconds ] -format %H:%M:%S ]
	puts "$InitTime on $InitDate"
	place_design -directive $place_design_directive

	set Lapsed2placeTime [getLapsedTime $RefTime]
	puts "Lapsed time after place_design: $Lapsed2placeTime"
        puts "--------------------------------------"

	puts "------------------------"
	puts "Place design Finished at:"
	puts [ clock format [ clock seconds ] -format %d/%m/%Y ]
	puts [ clock format [ clock seconds ] -format %H:%M:%S ]
	puts "\(started at $InitTime on $InitDate\)"
	puts "Directive used: $place_design_directive"
	puts "------------------------"

	# Optionally run optimization if there are timing violations after placement

	set PhysOptDirectives "Explore \
        ExploreWithHoldFix  \
        AggressiveExplore  \
        AlternateReplication  \
        AggressiveFanoutOpt \
        AddRetime \
        AlternateFlowWithRetiming \
        RuntimeOptimized \
        ExploreWithAggressiveHoldFix \
        Default"
	# RTL-P2.373: per-target output dirs
	set fd_opt [open $g_reports_dir/opt_strategies.rpt "w"]

	set i 0
	set nloops [llength $PhysOptDirectives]
	set CurrentSlack [get_property SLACK [get_timing_paths -max_paths 1 -nworst 1 -setup]]
	set PrevSlack $CurrentSlack

    # TODO: Analyze if the WNS is due to a CDC. Only try to optimize intra-clocks WNS

	for {set i 0} {$i < $nloops} {incr i} {

	 set CurrentDirective [lindex $PhysOptDirectives $i]

     puts "Running post-place phys_opt_design iteration $i/$nloops with directive $CurrentDirective"
	#  if { [expr $CurrentSlack < 0] } {
	#   puts "Found setup timing violations => running physical optimization"
	  phys_opt_design -directive $CurrentDirective
	  # Get the Slack after the optimization
	  set CurrentSlack [get_property SLACK [get_timing_paths -max_paths 1 -nworst 1 -setup]]
	  puts "\r\n-------------------------"
	  set Msg0 "Directive Applied: $CurrentDirective\r\nWNS: $CurrentSlack\r\nPrevious WNS: $PrevSlack"
	  puts $Msg0
	  puts $fd_opt $Msg0
	  set OptMsg "Directive $CurrentDirective improved WNS by [expr abs($PrevSlack - $CurrentSlack)]ns"
	  puts "$OptMsg"
	  puts $fd_opt $OptMsg
          set PrevSlack $CurrentSlack
	#  } else {
	#   set SkipMsg "Skipping phys_opt phase \($CurrentDirective\) as current slack is +${CurrentSlack}ns"
	#   puts "$SkipMsg"
	#   puts $fd_opt $SkipMsg
	#  }
	 puts "-------------------------\r\n"
	 if {$g_quick_impl == "true" } {
		# Don't run the optimization loop when quick flag is enabled. Break the foreach loop
		break;
	 }
	}

	close $fd_opt

	set Lapsed2physOptTime [getLapsedTime $RefTime]
	puts "Lapsed time after phys_opt_design: $Lapsed2physOptTime"
        puts "--------------------------------------"

	#set critical_nets [get_nets -of [get_timing_paths -max_paths 85]]
	#route_design -nets $critical_nets

	if { $g_dcp_on == "true" } {
            write_checkpoint -force $g_dcp_dir/post_place.dcp
	}

	# if { [expr $CurrentSlack < -1.000 ] && $g_quick_impl != "true"} {
	# 	puts "route_design will not be run as the WNS is above 1.000 "
	# 	puts "Implementation Failed. Check the timing reports to study how to improve timing"
	# 	## TODO: Quality of Results can be used as another criteria to not going further
	#     return 1
	# }


  # Explore other routing strategies
  set RouteDirectives "NoTimingRelaxation \
        Explore \
        MoreGlobalIterations \
        HigherDelayCost \
        AdvancedSkewModeling \
        AlternateCLBRouting \
        AggressiveExplore  \
        Default"

  set route_loops [llength $RouteDirectives]
  for {set route_loop 0} {$route_loop < $route_loops} {incr route_loop} {

    set route_design_directive [lindex $RouteDirectives $route_loop]
    puts "Running route_design iteration $route_loop/$route_loops with directive $route_design_directive"
    route_design -directive $route_design_directive

    set Lapsed2routeTime [getLapsedTime $RefTime]
    puts "Lapsed time after route_design: $Lapsed2routeTime"
    puts "--------------------------------------"

	## TODO: Directives can be added here to go the extra mile. E.g, the WNS is below -0.1 after 
	## default routing
    # set CurrentSlack [get_property SLACK [get_timing_paths -max_paths 1 -nworst 1 -setup]]
	# if { [expr $CurrentSlack < 0.000] && [expr $CurrentSlack > -0.200] } {
    #         puts "Running post-route phys_opt_design iteration with directive $post_route_directive"
    #         phys_opt_design -directive $post_route_directive
    # }

    set i 0
    set nloops [llength $PhysOptDirectives]
    set CurrentSlack [get_property SLACK [get_timing_paths -max_paths 1 -nworst 1 -setup]]

    set PrevSlack $CurrentSlack
    # Post-Route Physical Optimization is effective when WNS is above -0.5ns, and could be stuck otherwise
    if { [expr { ($CurrentSlack >= -0.5 && $CurrentSlack < 0.0) || $route_loop == ($route_loops-1)}] } {
     for {set i 0} {$i < $nloops} {incr i} {
      set CurrentDirective [lindex $PhysOptDirectives $i]
      puts "Running post-route phys_opt_design iteration $i/$nloops with directive $CurrentDirective"
      phys_opt_design -directive $CurrentDirective
      # Get the Slack after the optimization
      set CurrentSlack [get_property SLACK [get_timing_paths -max_paths 1 -nworst 1 -setup]]
      puts "\r\n-------------------------"
      puts "Post-route phys_opt_design Directive Applied: $CurrentDirective\r\nWNS: $CurrentSlack\r\nPrevious WNS: $PrevSlack"
      puts "Post-route phys_opt_design Directive $CurrentDirective improved WNS by [expr abs($PrevSlack - $CurrentSlack)]ns"
      set PrevSlack $CurrentSlack
      puts "-------------------------\r\n"
      if {$g_quick_impl == "true" } {
      # Don't run the optimization loop when quick flag is enabled. Break the foreach loop
      break;
      }
     }
    }

    puts "\r\n-------------------------"
    puts "route_design iteration $route_loop/$route_loops with directive $route_design_directive finished: WNS = $CurrentSlack"
    puts "-------------------------\r\n"
    write_checkpoint -force $g_dcp_dir/implementation.dcp
    if { [expr $CurrentSlack >= 0.000] } {
      break
    }
  }

	report_utilization -file $g_reports_dir/utilization.rpt
	set CurrentSlack [get_property SLACK [get_timing_paths -max_paths 1 -nworst 1 -setup]]

	# Report control sets
	puts "** Report control sets **"
	analyze_control_sets_and_slices ${g_root_dir}

	# The netlist file below can size ~220MB, need to check if it is worth
	#write_verilog -force $g_root_dir/reports/impl_netlist.v -mode timesim -sdf_anno true
	# TODO: Create a filter to write only the VIOLATED nets
	set Lapsed2ImplTime [getLapsedTime $RefTime]
	puts "Lapsed Implementation time: $Lapsed2ImplTime"
	puts "--------------------------------------"

	####### The following lines are used to store the more relevant desingn parameters into a file ###
	# Lapsed time for all steps
	# Directives used
	# WNS, TNS
	# Failing paths, if they exist
	# More?

	set fd_sum [open $g_reports_dir/summary.rpt "w"]

	puts $fd_sum "======================================="
	puts $fd_sum "== FPGA Shell implementation summary =="
	puts $fd_sum "======================================="
	puts $fd_sum ""
	puts $fd_sum "1. Timing:"

    if { [expr $CurrentSlack < 0.000] } {

	  puts $fd_sum "* Timing constraints are not met"
	  set WorstTimingPath [get_timing_paths -max_paths 1 -nworst 1 -setup]
	  puts $fd_sum "Critical Path:\r\n$WorstTimingPath\r\n"

	} else {
        puts $fd_sum "* The design closed timing"
	}

	puts $fd_sum "Design WNS=${CurrentSlack}ns"

	puts $fd_sum "2. Directives:"
    puts $fd_sum "* Place Directive used: $place_design_directive"
    puts $fd_sum "* Route Directive used: $route_design_directive"
    puts $fd_sum "3. Lapsed timestamps to reach stages:"
    puts $fd_sum "* Post synthesis optimization @ $Lapsed2optTime"
	puts $fd_sum "* Post place                  @ $Lapsed2placeTime"
    puts $fd_sum "* Post place optimization     @ $Lapsed2physOptTime"
    puts $fd_sum "* Post route                  @ $Lapsed2routeTime"
    puts $fd_sum "* Post route Opt              @ $Lapsed2ImplTime"

	close $fd_sum
}

### MAIN PROGRAM

set synthTclFile $g_tcl_dir/gen_synthesis.tcl
set synthDcpFile $g_dcp_dir/synthesis.dcp

if {![file exists $synthDcpFile]} {
	puts "Running Synthesis first ..."
    source $synthTclFile
}
open_checkpoint $synthDcpFile

# Source per-stage TCL hooks (from tcl_hooks.implementation in project.yml)
if {[info exists g_implementation_hooks]} {
    foreach hook $g_implementation_hooks {
        set hook_path "$g_root_dir/$hook"
        if {[file exists $hook_path]} {
            puts "  Sourcing implementation hook: $hook"
            source $hook_path
        } else {
            puts "  WARNING: implementation hook not found: $hook_path"
        }
    }
}

# Optionaly add a place directive as an argument.

set directivesFile $g_tcl_dir/directives.tcl

# ever tried strategies here
set g_place_directive "ExtraNetDelay_low"
set g_place_directive "Explore"
set g_place_directive "ExtraNetDelay_high"

set g_route_directive "NoTimingRelaxation"

# SmartPlace.tcl script creates a directives file when called.

if {[file exists $directivesFile]} {
	source $directivesFile
	puts "Stored place directive $g_place_directive will be used"
}

implementation $g_root_dir $g_place_directive $g_route_directive $g_dcp_on $g_quick_impl

# Source post-implementation TCL hooks (from tcl_hooks.post_implementation in project.yml)
if {[info exists g_post_implementation_hooks]} {
    foreach hook $g_post_implementation_hooks {
        set hook_path "$g_root_dir/$hook"
        if {[file exists $hook_path]} {
            puts "  Sourcing post-implementation hook: $hook"
            source $hook_path
        } else {
            puts "  WARNING: post-implementation hook not found: $hook_path"
        }
    }
}

# ── RouteRTL Report Emitter ──────────────────────────────────
source ${script_dir}/report_emitter.tcl
emit_impl_report $g_root_dir
