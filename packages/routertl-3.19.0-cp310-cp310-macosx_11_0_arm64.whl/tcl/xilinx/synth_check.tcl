# RouteRTL — Post-Synthesis Constraint Validation (Xilinx/Vivado)
# RTL-P2.229: Catch missing CDC constraints before expensive P&R.
#
# Usage: vivado -mode batch -source synth_check.tcl -tclargs <root_dir>
#
# Opens the synthesis DCP, runs check_timing + report_cdc + timing summary,
# and writes reports/synth_check_report.json with structured results.

set g_root_dir [lindex $argv 0]

if {$g_root_dir eq ""} {
    puts "ERROR: root_dir argument required"
    exit 1
}

# ── Helpers ──────────────────────────────────────────────────────

proc _json_escape {str} {
    set str [string map {"\\" "\\\\" "\"" "\\\"" "\n" "\\n" "\t" "\\t"} $str]
    return $str
}

proc _json_list {items} {
    set parts {}
    foreach item $items {
        lappend parts "\"[_json_escape $item]\""
    }
    return "\[[join $parts ", "]\]"
}

# ── Open Checkpoint ──────────────────────────────────────────────

set dcp_file "$g_dcp_dir/synthesis.dcp"

if {![file exists $dcp_file]} {
    puts "ERROR: Synthesis checkpoint not found: $dcp_file"
    puts "Run 'rr synth run' first."
    exit 1
}

puts "Opening synthesis checkpoint: $dcp_file"
open_checkpoint $dcp_file

set tool_name "Vivado [version -short]"
set timestamp [clock format [clock seconds] -format "%Y-%m-%dT%H:%M:%S"]

# ── Check Results Storage ────────────────────────────────────────

set checks {}
set n_errors 0
set n_warnings 0
set n_info 0
set n_passed 0

# ── 1. Unconstrained Clocks (ERROR) ─────────────────────────────

puts "\n--- Check: Unconstrained Clocks ---"
set details {}
set check_passed true

# Run check_timing ONCE and reuse for clocks + I/O delay checks
set ct_text ""
if {[catch {set ct_text [check_timing -return_string]} err]} {
    lappend details "check_timing unavailable: $err"
}

if {$ct_text ne ""} {
    # Parse for unconstrained clocks
    foreach line [split $ct_text "\n"] {
        if {[regexp {There (?:are|is) (\d+) .* (?:with no clock|no clock driven)} $line -> cnt]} {
            if {$cnt > 0} {
                set check_passed false
                lappend details "$cnt endpoints with no clock constraint"
            }
        }
    }
}

if {$check_passed} {
    incr n_passed
} else {
    incr n_errors
}
lappend checks [list "unconstrained_clocks" "Unconstrained Clocks" "ERROR" $check_passed $details [llength $details]]

# ── 2. CDC Crossings (ERROR) ────────────────────────────────────

puts "\n--- Check: CDC Crossings ---"
set details {}
set check_passed true

if {[catch {set cdc_text [report_cdc -details -return_string]} err]} {
    # report_cdc may not be available (single clock designs)
    set details [list "CDC analysis not applicable or unavailable"]
    set check_passed true
    incr n_info
    # Store as INFO instead
    lappend checks [list "cdc_crossings" "CDC Crossings" "INFO" true $details 0]
} else {
    set unsafe_count 0
    foreach line [split $cdc_text "\n"] {
        # Look for unsafe CDC paths — lines containing "UNSAFE" or "No synchronizer"
        if {[regexp -nocase {unsafe|no synchronizer|no cdc structure} $line]} {
            incr unsafe_count
            set trimmed [string trim $line]
            if {[string length $trimmed] > 0 && [llength $details] < 20} {
                lappend details $trimmed
            }
        }
    }
    if {$unsafe_count > 0} {
        set check_passed false
        incr n_errors
    } else {
        incr n_passed
    }
    lappend checks [list "cdc_crossings" "CDC Crossings" "ERROR" $check_passed $details $unsafe_count]
}

# ── 3. Early WNS (ERROR) ────────────────────────────────────────

puts "\n--- Check: Early WNS ---"
set details {}
set check_passed true
set wns_val 0.0
set clk_name ""

if {[catch {
    set tp [get_timing_paths -max_paths 1 -nworst 1 -setup]
    set slack_raw [get_property SLACK $tp]
    # Guard: SLACK can be empty when no valid timing paths exist
    if {$slack_raw ne "" && [string is double -strict $slack_raw]} {
        set wns_val $slack_raw
    }
    catch {set clk_name [get_property ENDPOINT_CLOCK $tp]}
} err]} {
    lappend details "Timing paths not available (unconstrained design?)"
    set check_passed false
    incr n_errors
}

if {$wns_val eq "" || ![string is double -strict $wns_val]} {
    # No timing data available
    lappend details "No timing paths found (black boxes or unconstrained)"
    incr n_info
    lappend checks [list "early_wns" "Early WNS" "INFO" true $details 0]
} elseif {$wns_val < 0.0} {
    set check_passed false
    incr n_errors
    set clk_label [expr {$clk_name ne "" ? $clk_name : "unknown"}]
    lappend details [format "WNS = %.3f ns (%s) — timing already violated at synthesis" $wns_val $clk_label]
    lappend checks [list "early_wns" "Early WNS" "ERROR" $check_passed $details 0]
} else {
    incr n_passed
    set clk_label [expr {$clk_name ne "" ? $clk_name : "unknown"}]
    lappend details [format "+%.3f ns (%s)" $wns_val $clk_label]
    lappend checks [list "early_wns" "Early WNS" "ERROR" $check_passed $details 0]
}

# ── 4. Missing I/O Delays (WARNING) ─────────────────────────────

puts "\n--- Check: I/O Delays ---"
set details {}
set check_passed true
set io_count 0

# Reuse ct_text from the check_timing call above
if {$ct_text ne ""} {
    foreach line [split $ct_text "\n"] {
        if {[regexp {There (?:are|is) (\d+) .* with no input delay} $line -> cnt]} {
            if {$cnt > 0} {
                set check_passed false
                incr io_count $cnt
                lappend details "$cnt input ports with no set_input_delay"
            }
        }
        if {[regexp {There (?:are|is) (\d+) .* with no output delay} $line -> cnt]} {
            if {$cnt > 0} {
                set check_passed false
                incr io_count $cnt
                lappend details "$cnt output ports with no set_output_delay"
            }
        }
    }
}

if {$check_passed} {
    incr n_passed
} else {
    incr n_warnings
}
lappend checks [list "io_delays" "I/O Delays" "WARNING" $check_passed $details $io_count]

# ── 5. Clock Groups (WARNING) ───────────────────────────────────

puts "\n--- Check: Clock Groups ---"
set details {}
set check_passed true

if {[catch {set clk_list [get_clocks -quiet]}]} {
    set clk_list {}
}

set num_clocks [llength $clk_list]
if {$num_clocks > 1} {
    # Multiple clocks: check if clock groups are defined
    if {[catch {set ci_text [report_clock_interaction -return_string]}]} {
        lappend details "Clock interaction report unavailable"
    } else {
        # Look for unconstrained clock pairs in the interaction matrix
        set unconstrained_pairs 0
        foreach line [split $ci_text "\n"] {
            # Interaction matrix shows constraint type — "No Common" or "False Path" etc.
            # Lines with empty constraint or "Timed" between different clocks = unconstrained
            if {[regexp {Timed\s+\(unsafe\)|No Common Clock} $line]} {
                incr unconstrained_pairs
                set trimmed [string trim $line]
                if {[string length $trimmed] > 0 && [llength $details] < 10} {
                    lappend details $trimmed
                }
            }
        }
        if {$unconstrained_pairs > 0} {
            set check_passed false
            lappend details "$unconstrained_pairs clock pair(s) without set_clock_groups or set_false_path"
        }
    }
}

if {$check_passed} {
    incr n_passed
} else {
    incr n_warnings
}
lappend checks [list "clock_groups" "Clock Groups" "WARNING" $check_passed $details 0]

# ── Write JSON Report ────────────────────────────────────────────

file mkdir $g_reports_dir

set json_checks {}
foreach chk $checks {
    lassign $chk id name severity passed details count
    set passed_str [expr {$passed ? "true" : "false"}]
    lappend json_checks "    \{\"id\": \"[_json_escape $id]\", \"name\": \"[_json_escape $name]\", \"severity\": \"$severity\", \"passed\": $passed_str, \"details\": [_json_list $details], \"count\": $count\}"
}

set report_file "$g_reports_dir/synth_check_report.json"
set FH [open $report_file w]
puts $FH "\{"
puts $FH "  \"vendor\": \"xilinx\","
puts $FH "  \"tool_name\": \"[_json_escape $tool_name]\","
puts $FH "  \"timestamp\": \"$timestamp\","
puts $FH "  \"checks\": \["
puts $FH [join $json_checks ",\n"]
puts $FH "  \],"
puts $FH "  \"summary\": \{\"errors\": $n_errors, \"warnings\": $n_warnings, \"info\": $n_info, \"passed\": $n_passed\},"
puts $FH "  \"timing\": \{\"wns_ns\": $wns_val, \"clock_name\": \"[_json_escape $clk_name]\"\}"
puts $FH "\}"
close $FH

puts "\nConstraint check report written to: $report_file"
puts "Summary: $n_errors error(s), $n_warnings warning(s), $n_passed passed"

close_design
