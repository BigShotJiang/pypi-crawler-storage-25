# Author: Daniel J.Mazure, Tich
# Date: 10.04.2024
# Description: 


if { $::argc > 0 } {
 set g_root_dir    [lindex $argv 0]
 puts "Root directory is $g_root_dir"
}

source $g_root_dir/tcl/xilinx/environment.tcl

open_project ${g_project_dir}/${g_project_name}.xpr

create_bd_design $bdName -dir $g_project_dir

source $g_root_dir/src/bd/ddr3_bd.tcl

reset_target all [get_files  ${g_root_dir}/project/mig_xem7305/mig_xem7305.bd]


close_project
