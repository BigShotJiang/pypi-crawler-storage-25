# MIT License
#
# Copyright (c) 2020-2025 Daniel J. Mazure
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
# IN THE SOFTWARE.

# Author: Daniel J.Mazure, Tich
# Date: 09.09.2024
# Description:
if { $::argc >= 1 } {
    set g_root_dir  [lindex $argv 0]
    puts "Root dir is  $g_root_dir"
}

source ${g_root_dir}/tcl/xilinx/environment.tcl
## 1. Create the constants and include them in the fifo_pkg file, which is created here
set FWFT 1; # If FWFT, add 1 to the deep counting width

set C_FIFO_EP_DEPTH        1024
set C_FIFO_EP_WIDTH        32
set C_FIFO_EP_DEPTH_NBITS [expr {int(ceil(log(double($C_FIFO_EP_DEPTH))/log(2.0)))} + $FWFT]
set C_FIFO_EP_FULL        [expr $C_FIFO_EP_DEPTH - 10]

puts "FIFO_ENDPOINT_DEPTH_NBITS: $C_FIFO_EP_DEPTH_NBITS"

set g_pkg_name    fifo_pkg
set g_pkg_file    $g_root_dir/src/pkg/${g_pkg_name}
set g_comp_file   $g_root_dir/misc/fifo_components.vhd

set fd_pkg    [open $g_pkg_file "w"]

set ActualTime  [clock seconds]
set InitialTime [clock format $ActualTime -format %H:%M:%S -gmt true]

puts $fd_pkg "-- Tich (c) 2024"
puts $fd_pkg "-- File created @[clock format [clock seconds]]"
puts $fd_pkg "-- This file was created automatically by the gen_xlnx_fifos tcl script"


set libraries "
library IEEE;
use IEEE.STD_LOGIC_1164.all;
use IEEE.NUMERIC_STD.all;
use IEEE.MATH_REAL.all;
"
# Write the libraries to the components file
puts $fd_pkg $libraries; 

# Write the package declaration to the components file
puts $fd_pkg "package ${g_pkg_name} is"

puts $fd_pkg "
  constant C_FIFO_EP_WIDTH          : integer := ${C_FIFO_EP_WIDTH};
  constant C_FIFO_EP_DEPTH_NBITS    : integer := ${C_FIFO_EP_DEPTH_NBITS};
"
set fd_comp [open $g_comp_file "r"]; # The component declaration of the FIFOs, based on the constants defined here

fcopy $fd_comp $fd_pkg
close $fd_comp

puts $fd_pkg "
end package ${g_pkg_name};
"
puts $fd_pkg "
package body ${g_pkg_name} is
"
puts $fd_pkg "
end ${g_pkg_name};
"

close $fd_pkg

file copy -force $g_pkg_file ${g_pkg_file}.vhd
file delete -force $g_pkg_file

## 2. Create the XCI file using the constants declared above
set g_fifos_dir $g_root_dir/xlnx_fifos

set list_projs [get_projects -quiet]
if { $list_projs eq "" } {
    create_project fifo_generation $g_fifos_dir -force -part $g_fpga_part 
}

set g_fifo_name fifo_endpoint
create_ip -name fifo_generator -vendor xilinx.com -library ip -version 13.2 -module_name $g_fifo_name  -dir $g_root_dir/ip

puts "XILINX FIFO DATA"
set_property -dict [list \
  CONFIG.Fifo_Implementation {Independent_Clocks_Block_RAM} \
  CONFIG.INTERFACE_TYPE {Native} \
  CONFIG.Input_Data_Width ${C_FIFO_EP_WIDTH} \
  CONFIG.Input_Depth ${C_FIFO_EP_DEPTH} \
  CONFIG.Performance_Options {First_Word_Fall_Through} \
  CONFIG.Read_Data_Count {true} \
  CONFIG.Full_Threshold_Assert_Value ${C_FIFO_EP_FULL} \
  CONFIG.Programmable_Full_Type {Single_Programmable_Full_Threshold_Constant} \
  CONFIG.Programmable_Empty_Type {No_Programmable_Empty_Threshold} \
  CONFIG.Almost_Full_Flag {false} \
  CONFIG.Write_Data_Count {true} \
  CONFIG.Use_Extra_Logic {true} \
] [get_ips $g_fifo_name]

file delete -force $g_fifos_dir
