# Tich (c) 2024
# Author: Daniel J. Mazure

set module_name "ssi_leds"

create_ip -name leds -vendor opalkelly.com -library ip -version 1.0 -module_name $module_name
