# Xilinx FPGA Programming Script (Vivado HW Manager)
# (c) 2026 RouteRTL

if { $argc < 3 } {
    puts "Usage: gen_program.tcl <root_dir> <bitstream_path> <cable_id>"
    exit 1
}

set g_root_dir [lindex $argv 0]
set g_bitstream_path [lindex $argv 1]
set g_cable_id [lindex $argv 2]

# --- Discovery ---
if { $g_bitstream_path == "" } {
    set bitstream_candidates [glob -nocomplain "${g_root_dir}/*.bit" "${g_root_dir}/project/*.bit" "${g_root_dir}/output_files/*.bit"]
    if { [llength $bitstream_candidates] > 0 } {
        set g_bitstream_path [lindex $bitstream_candidates 0]
        puts "   ℹ️  Auto-detected bitstream: $g_bitstream_path"
    } else {
        puts "❌ Error: No bitstream file (.bit) found."
        exit 1
    }
}

puts "⚡ Programming Xilinx FPGA (Vivado)..."

open_hw_manager
connect_hw_server -quiet
if { [get_hw_targets] == "" } {
    puts "❌ Error: No JTAG targets found."
    exit 1
}

set target [get_hw_targets -filter "NAME =~ \"*$g_cable_id*\""]
if { $target == "" } {
    set target [lindex [get_hw_targets] 0]
}

open_hw_target $target
set device [lindex [get_hw_devices] 0]

refresh_hw_device $device
set_property PROGRAM.FILE $g_bitstream_path $device
program_hw_devices $device
refresh_hw_device $device

close_hw_target
disconnect_hw_server
close_hw_manager

puts "✅ Programming successful."
