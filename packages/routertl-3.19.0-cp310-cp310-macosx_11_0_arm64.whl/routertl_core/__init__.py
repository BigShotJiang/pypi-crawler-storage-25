# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""RouteRTL Core — proprietary algorithmic engines.

This package contains the crown-jewel algorithms that constitute
RouteRTL's intellectual property:

- dependency_resolver: HDL dependency graph analysis and topological sort
- smart_linter: Dual-engine VHDL + SystemVerilog linting pipeline
- scan_sources: Blind HUNT-pattern source file discovery
- project_manager: YAML → Makefile/TCL configuration engine
- sim: Simulation orchestration — multi-backend invocation, library
  compilation, vendor backends (NVC, GHDL, Questa, Riviera, etc.)
- docker: Docker container orchestration — volume resolution,
  edition-aware mapping, bind mount detection, EDA version probing
- workspace: Workspace management — config regeneration, venv
  environment injection, shell completion injection
"""

__author__ = "Daniel J. Mazure"
__copyright__ = "Copyright © 2026 Daniel J. Mazure"
__version__: str
try:
    from importlib.metadata import version as _meta_version
    __version__ = _meta_version("routertl")
except Exception:
    __version__ = "3.19.0"  # fallback for Cython builds / uninstalled dev


# RTL-P2.423: release metadata populated by the wheel-build pipeline
# (env vars ROUTERTL_COMMIT_SHA / ROUTERTL_BUILD_DATE injected at
# bitbucket-pipelines.yml publish step).  Absent values stay None;
# the CLI falls back to "(dev)" in that case.
import os as _os

RELEASE_METADATA: dict = {
    "commit_sha":  _os.environ.get("ROUTERTL_COMMIT_SHA") or None,
    "build_date":  _os.environ.get("ROUTERTL_BUILD_DATE") or None,
}


def version_string() -> str:
    """Rich version banner for ``rr --version`` — appends commit sha +
    build date when the wheel was built with release metadata, falls
    back to ``(dev)`` otherwise.

    Shape:
      3.18.0 (2026-04-21, 8905b4a)       # release wheel
      3.18.0 (dev)                       # checkout / no metadata
    """
    sha = RELEASE_METADATA.get("commit_sha")
    date = RELEASE_METADATA.get("build_date")
    if sha and date:
        return f"{__version__} ({date}, {sha[:7]})"
    if sha:
        return f"{__version__} ({sha[:7]})"
    if date:
        return f"{__version__} ({date})"
    return f"{__version__} (dev)"


def banner() -> str:
    """Return the RouteRTL core attribution banner."""
    return f"RouteRTL Core v{__version__} — © {__author__}"
