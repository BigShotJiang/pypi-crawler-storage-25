# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""RouteRTL Core — Workspace orchestration engine.

This subpackage contains the domain logic for project workspace
management: Makefile fixing, config regeneration, venv environment
injection, and shell completion injection.  Compiled to .so on
release builds via Cython (P2.59).
"""
