"""OOD detection workflow."""
