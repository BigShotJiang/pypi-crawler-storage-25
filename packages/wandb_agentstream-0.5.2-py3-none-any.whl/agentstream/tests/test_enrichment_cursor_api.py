"""Tests for Cursor API token usage enrichment."""

import json
import tempfile

import pytest

from agentstream.enrichment.cursor_api import (
    CursorUsageClient,
    _get_event_timestamp,
    _get_token_fields,
    _models_match,
    aggregate_to_token_usages,
    get_cursor_api_window,
    match_events_to_session,
    refine_timestamps_from_api_events,
)


class TestModelsMatch:
    """Tests for _models_match helper."""

    def test_exact_match(self):
        assert _models_match("claude-4.5-opus", "claude-4.5-opus")

    def test_default_always_matches(self):
        assert _models_match("claude-4.5-opus", "default")
        assert _models_match("default", "gpt-4o")

    def test_prefix_match(self):
        assert _models_match("claude-4.5-opus", "claude-4.5-opus-high-thinking")
        assert _models_match("gpt-4o-2024-08-06", "gpt-4o")

    def test_case_insensitive(self):
        assert _models_match("Claude-4.5-Opus", "claude-4.5-opus")

    def test_no_match(self):
        assert not _models_match("claude-4.5-opus", "gpt-4o")
        assert not _models_match("gemini-pro", "claude-sonnet")


class TestGetEventTimestamp:
    """Tests for _get_event_timestamp helper."""

    def test_int_timestamp(self):
        assert _get_event_timestamp({"timestamp": 1000}) == 1000

    def test_string_timestamp(self):
        """Cursor API returns timestamps as strings."""
        assert _get_event_timestamp({"timestamp": "1770166356194"}) == 1770166356194

    def test_timestampMs_fallback(self):
        assert _get_event_timestamp({"timestampMs": "2000"}) == 2000

    def test_missing_timestamp(self):
        assert _get_event_timestamp({}) == 0

    def test_invalid_string(self):
        assert _get_event_timestamp({"timestamp": "not-a-number"}) == 0


class TestGetTokenFields:
    """Tests for _get_token_fields helper."""

    def test_nested_token_usage(self):
        """Real Cursor API nests tokens under tokenUsage."""
        event = {
            "tokenUsage": {
                "inputTokens": 131,
                "outputTokens": 515,
                "cacheWriteTokens": 1109,
                "cacheReadTokens": 73746,
            }
        }
        tokens = _get_token_fields(event)
        assert tokens["inputTokens"] == 131
        assert tokens["cacheReadTokens"] == 73746

    def test_flat_token_fields(self):
        """Fallback: tokens at top level."""
        event = {"inputTokens": 100, "outputTokens": 50}
        tokens = _get_token_fields(event)
        assert tokens["inputTokens"] == 100

    def test_no_token_usage(self):
        """Returns the event itself when no tokenUsage key."""
        event = {"model": "test"}
        tokens = _get_token_fields(event)
        assert tokens is event


class TestMatchEventsToSession:
    """Tests for match_events_to_session."""

    def _make_event(self, ts_ms: int, model: str = "claude-4.5-opus") -> dict:
        """Create event with string timestamp (matching real API format)."""
        return {
            "timestamp": str(ts_ms),
            "model": model,
            "tokenUsage": {"inputTokens": 100, "outputTokens": 50},
        }

    def test_events_within_window(self):
        events = [
            self._make_event(1000),
            self._make_event(2000),
            self._make_event(3000),
        ]
        matched = match_events_to_session(events, 1000, 3000)
        assert len(matched) == 3

    def test_events_outside_window(self):
        events = [
            self._make_event(500),  # before window - buffer
            self._make_event(2000),  # in window
            self._make_event(200_000),  # way after window + buffer
        ]
        matched = match_events_to_session(events, 1000, 3000)
        # 500 is within 1000-60000=negative -> included (buffer makes start go to -59000)
        # 200000 is outside 3000+60000=63000 -> excluded
        assert len(matched) == 2

    def test_buffer_includes_events_near_edges(self):
        events = [
            self._make_event(500),  # within 60s buffer before start
            self._make_event(65_000),  # just past 60s buffer after end (3000+60000)
        ]
        matched = match_events_to_session(events, 1000, 3000)
        assert len(matched) == 1  # only the 500ms one

    def test_model_filter(self):
        events = [
            self._make_event(2000, "claude-4.5-opus"),
            self._make_event(2500, "gpt-4o"),
        ]
        matched = match_events_to_session(events, 1000, 3000, model="claude-4.5-opus")
        assert len(matched) == 1
        assert matched[0]["model"] == "claude-4.5-opus"

    def test_cursor_model_skips_filter(self):
        """When session model is 'cursor' (fallback), don't filter by model."""
        events = [
            self._make_event(2000, "claude-4.5-opus"),
            self._make_event(2500, "gpt-4o"),
        ]
        matched = match_events_to_session(events, 1000, 3000, model="cursor")
        assert len(matched) == 2

    def test_email_filter(self):
        """Best-effort email filtering matches case-insensitively."""
        events = [
            {**self._make_event(2000), "email": "user@example.com"},
            {**self._make_event(2500), "email": "other@example.com"},
        ]
        matched = match_events_to_session(events, 1000, 3000, email="User@example.com")
        assert len(matched) == 1
        assert matched[0]["email"] == "user@example.com"

    def test_email_filter_userEmail_field(self):
        """Cursor API returns userEmail, not email — both should be checked."""
        events = [
            {**self._make_event(2000), "userEmail": "user@example.com"},
            {**self._make_event(2500), "userEmail": "other@example.com"},
            {**self._make_event(2800), "userEmail": ""},  # empty = passes
        ]
        matched = match_events_to_session(events, 1000, 3000, email="User@example.com")
        assert len(matched) == 2  # user match + empty email

    def test_email_filter_skips_events_without_email(self):
        """Events without email field should pass through email filter."""
        events = [
            self._make_event(2000),
            {**self._make_event(2500), "email": "other@example.com"},
        ]
        matched = match_events_to_session(events, 1000, 3000, email="user@example.com")
        assert len(matched) == 1  # only the one without email passes

    def test_no_email_filter(self):
        """Without email filter, all events pass."""
        events = [
            {**self._make_event(2000), "email": "user@example.com"},
            {**self._make_event(2500), "email": "other@example.com"},
        ]
        matched = match_events_to_session(events, 1000, 3000)
        assert len(matched) == 2

    def test_empty_events(self):
        matched = match_events_to_session([], 1000, 3000)
        assert matched == []

    def test_string_timestamps(self):
        """Cursor API returns timestamps as strings."""
        events = [{"timestamp": "2000", "model": "claude-4.5-opus"}]
        matched = match_events_to_session(events, 1000, 3000)
        assert len(matched) == 1

    def test_int_timestamps_still_work(self):
        """Int timestamps should also work for backward compat."""
        events = [{"timestamp": 2000, "model": "claude-4.5-opus"}]
        matched = match_events_to_session(events, 1000, 3000)
        assert len(matched) == 1


class TestAggregateToTokenUsages:
    """Tests for aggregate_to_token_usages."""

    def test_nested_token_usage(self):
        """Real Cursor API format with nested tokenUsage."""
        events = [
            {
                "timestamp": "1704067200000",
                "model": "claude-4.5-opus-high-thinking",
                "tokenUsage": {
                    "inputTokens": 131,
                    "outputTokens": 515,
                    "cacheWriteTokens": 1109,
                    "cacheReadTokens": 73746,
                    "totalCents": 5.73,
                },
            }
        ]
        usages = aggregate_to_token_usages(events)
        assert len(usages) == 1
        assert usages[0].input_tokens == 131
        assert usages[0].output_tokens == 515
        assert usages[0].cache_read_tokens == 73746
        assert usages[0].cache_creation_tokens == 1109
        assert usages[0].model == "claude-4.5-opus-high-thinking"
        assert usages[0].is_cumulative is False

    def test_flat_token_fields_fallback(self):
        """Flat format should still work."""
        events = [
            {
                "timestamp": "1704067200000",
                "model": "claude-4.5-opus",
                "inputTokens": 1000,
                "outputTokens": 500,
                "cacheReadTokens": 200,
                "cacheWriteTokens": 100,
            }
        ]
        usages = aggregate_to_token_usages(events)
        assert len(usages) == 1
        assert usages[0].input_tokens == 1000
        assert usages[0].output_tokens == 500

    def test_multiple_events(self):
        events = [
            {"timestamp": "1000", "tokenUsage": {"inputTokens": 100, "outputTokens": 50}},
            {"timestamp": "2000", "tokenUsage": {"inputTokens": 200, "outputTokens": 100}},
        ]
        usages = aggregate_to_token_usages(events)
        assert len(usages) == 2
        assert usages[0].input_tokens == 100
        assert usages[1].input_tokens == 200

    def test_missing_fields_default_to_zero(self):
        events = [{"timestamp": "1000"}]
        usages = aggregate_to_token_usages(events)
        assert len(usages) == 1
        assert usages[0].input_tokens == 0
        assert usages[0].output_tokens == 0
        assert usages[0].cache_read_tokens == 0

    def test_empty_events(self):
        usages = aggregate_to_token_usages([])
        assert usages == []


class TestCursorUsageClient:
    """Tests for CursorUsageClient initialization and configuration."""

    def test_init(self):
        client = CursorUsageClient("test-key")
        assert client.api_key == "test-key"
        assert client.timeout == 10.0

    def test_custom_timeout(self):
        client = CursorUsageClient("test-key", timeout=60.0)
        assert client.timeout == 60.0

    def test_headers(self):
        client = CursorUsageClient("test-key")
        headers = client._headers()
        assert headers["Authorization"] == "Bearer test-key"
        assert headers["Content-Type"] == "application/json"

    @pytest.mark.asyncio
    async def test_fetch_returns_none_on_client_error(self):
        """Client should return None on 4xx HTTP errors (not retried)."""
        from unittest.mock import AsyncMock, MagicMock

        import httpx

        client = CursorUsageClient("test-key")

        mock_response = MagicMock()
        mock_response.status_code = 400
        mock_response.text = '{"code":"error","message":"Bad request"}'
        mock_response.raise_for_status.side_effect = httpx.HTTPStatusError(
            "Bad Request", request=MagicMock(), response=mock_response
        )

        mock_http = AsyncMock()
        mock_http.post.return_value = mock_response
        mock_http.is_closed = False
        client._http = mock_http

        result = await client.fetch_usage_events(1000, 2000)
        assert result is None

    @pytest.mark.asyncio
    async def test_fetch_successful_response(self):
        """Client should parse successful response."""
        from unittest.mock import AsyncMock, MagicMock

        client = CursorUsageClient("test-key")

        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.raise_for_status.return_value = None
        mock_response.json.return_value = {
            "usageEvents": [
                {"timestamp": "1500", "tokenUsage": {"inputTokens": 100, "outputTokens": 50}}
            ]
        }

        mock_http = AsyncMock()
        mock_http.post.return_value = mock_response
        mock_http.is_closed = False
        client._http = mock_http

        result = await client.fetch_usage_events(1000, 2000)
        assert result is not None
        assert len(result) == 1
        assert result[0]["tokenUsage"]["inputTokens"] == 100

    @pytest.mark.asyncio
    async def test_fetch_all_pages_paginates(self):
        """_fetch_all_pages should paginate through all pages."""
        from unittest.mock import patch

        client = CursorUsageClient("test-key")

        page1 = [{"timestamp": i, "inputTokens": i} for i in range(150)]
        page2 = [{"timestamp": i, "inputTokens": i} for i in range(150, 200)]

        call_count = 0

        async def mock_fetch(start_ms, end_ms, page=1, page_size=150):
            nonlocal call_count
            call_count += 1
            if page == 1:
                return page1
            elif page == 2:
                return page2
            return []

        with patch.object(client, "fetch_usage_events", side_effect=mock_fetch):
            result = await client._fetch_all_pages(1000, 2000)
            assert len(result) == 200
            assert call_count == 2  # 2 pages (page2 has < page_size items)


class TestMatchEventsLongSpanningSession:
    """Test that narrowed windows reduce false matches for long-spanning sessions."""

    def _make_event(self, ts_ms: int, model: str = "claude-4.5-opus") -> dict:
        return {
            "timestamp": str(ts_ms),
            "model": model,
            "tokenUsage": {"inputTokens": 100, "outputTokens": 50},
        }

    def test_broad_window_matches_all_events_in_span(self):
        """A broad window spanning 30 days matches events anywhere in the range."""
        created = 1746206863741  # session start
        updated = created + 30 * 24 * 3600 * 1000  # 30 days later

        early_events = [self._make_event(created + 60_000)]
        late_events = [self._make_event(updated - 60_000)]
        middle_events = [self._make_event(created + 15 * 24 * 3600 * 1000)]  # 15 days in

        all_events = early_events + middle_events + late_events

        # Single broad window: matches everything
        broad_matched = match_events_to_session(all_events, created, updated)
        assert len(broad_matched) == 3

    def test_narrow_window_excludes_middle_events(self):
        """Events from the middle of a long session should NOT match narrow windows.

        This tests the principle that narrowed windows (tested in
        TestGetCursorApiWindow in test_processing.py) filter out
        unrelated mid-span events when applied to match_events_to_session.
        """
        created = 1746206863741
        updated = created + 30 * 24 * 3600 * 1000  # 30 days later
        SIX_HOURS_MS = 6 * 3600 * 1000
        BUFFER_MS = 60_000

        early_events = [self._make_event(created + 60_000)]
        late_events = [self._make_event(updated - 60_000)]
        middle_events = [self._make_event(created + 15 * 24 * 3600 * 1000)]

        all_events = early_events + middle_events + late_events

        # Simulate dual windows (same logic as _get_cursor_api_window)
        windows = [
            (created - BUFFER_MS, created + SIX_HOURS_MS),
            (updated - SIX_HOURS_MS, updated + BUFFER_MS),
        ]

        narrowed_matched = []
        seen = set()
        for w_start, w_end in windows:
            for ev in match_events_to_session(all_events, w_start, w_end):
                ev_id = id(ev)
                if ev_id not in seen:
                    seen.add(ev_id)
                    narrowed_matched.append(ev)

        # Middle event should be excluded
        assert len(narrowed_matched) == 2


class TestDayCache:
    """Tests for day-based caching via CacheBackend."""

    def test_cache_write_and_read(self):
        from agentstream.enrichment.cache import FileCache, make_cache_key

        cache = FileCache(tempfile.mkdtemp())

        events = [{"timestamp": "1000", "model": "test"}]
        key = make_cache_key("test-key", "2025-01-15")
        cache.write(key, events)

        assert cache.read(key) == events

    def test_cache_miss(self):
        from agentstream.enrichment.cache import FileCache, make_cache_key

        cache = FileCache(tempfile.mkdtemp())
        key = make_cache_key("test-key", "2025-01-15")
        assert cache.read(key) is None

    def test_cache_key_includes_key_hash(self):
        from agentstream.enrichment.cache import make_cache_key

        key1 = make_cache_key("key-1", "2025-01-15")
        key2 = make_cache_key("key-2", "2025-01-15")
        assert key1 != key2

    def test_corrupt_cache_returns_none(self):
        import os

        from agentstream.enrichment.cache import FileCache, make_cache_key

        tmpdir = tempfile.mkdtemp()
        cache = FileCache(tmpdir)
        key = make_cache_key("test-key", "2025-01-15")

        path = os.path.join(tmpdir, f"{key}.json")
        with open(path, "w") as f:
            f.write("not json")

        assert cache.read(key) is None

    @pytest.mark.asyncio
    async def test_fetch_day_events_uses_cache(self):
        """fetch_day_events should return cached data without API call."""
        from datetime import date
        from unittest.mock import patch

        from agentstream.enrichment.cache import FileCache, make_cache_key

        cache = FileCache(tempfile.mkdtemp())
        client = CursorUsageClient("test-key", cache=cache)

        events = [{"timestamp": "1000", "model": "test"}]
        # Pre-populate cache for a past day
        key = make_cache_key("test-key", "2025-01-15")
        cache.write(key, events)

        with patch.object(client, "_fetch_all_pages") as mock_fetch:
            result = await client.fetch_day_events(date(2025, 1, 15))
            assert result == events
            mock_fetch.assert_not_called()

    @pytest.mark.asyncio
    async def test_fetch_day_events_caches_past_days(self):
        """fetch_day_events should cache completed days after fetching."""
        from datetime import date
        from unittest.mock import AsyncMock, patch

        from agentstream.enrichment.cache import FileCache, make_cache_key

        cache = FileCache(tempfile.mkdtemp())
        client = CursorUsageClient("test-key", cache=cache)

        events = [{"timestamp": "1000", "model": "test"}]

        with patch.object(client, "_fetch_all_pages", new_callable=AsyncMock, return_value=events):
            result = await client.fetch_day_events(date(2025, 1, 15))
            assert result == events

        # Verify it was cached
        key = make_cache_key("test-key", "2025-01-15")
        assert cache.read(key) == events

    @pytest.mark.asyncio
    async def test_fetch_events_for_range_spans_days(self):
        """fetch_events_for_range should fetch each day independently."""
        from unittest.mock import patch

        client = CursorUsageClient("test-key")

        day1_events = [{"timestamp": "1704067200000"}]  # 2024-01-01
        day2_events = [{"timestamp": "1704153600000"}]  # 2024-01-02

        call_days = []

        async def mock_fetch_day(day):
            call_days.append(day.isoformat())
            if day.isoformat() == "2024-01-01":
                return day1_events
            elif day.isoformat() == "2024-01-02":
                return day2_events
            return []

        with patch.object(client, "fetch_day_events", side_effect=mock_fetch_day):
            # Range spanning 2 days (Jan 1 midday to Jan 2 midday)
            result = await client.fetch_events_for_range(
                start_ms=1704110400000,  # Jan 1 2024 12:00 UTC
                end_ms=1704196800000,  # Jan 2 2024 12:00 UTC
            )
            assert len(result) == 2
            assert "2024-01-01" in call_days
            assert "2024-01-02" in call_days


# =============================================================================
# get_cursor_api_window tests
# =============================================================================


class TestGetCursorApiWindow:
    """Tests for get_cursor_api_window."""

    def _make_v2_entries(self, types: list[int], ts_ms: int = 0) -> list[dict]:
        entries = []
        for i, t in enumerate(types):
            entry = {"entry_content": json.dumps({"type": t, "_v": 2})}
            if ts_ms > 0:
                entry["entry_timestamp_ms"] = ts_ms + i * 15000
            else:
                entry["entry_timestamp_ms"] = 0
            entries.append(entry)
        return entries

    def _make_v1_entries(self, timestamps_ms: list[int]) -> list[dict]:
        return [
            {
                "entry_content": json.dumps({"type": 2, "createdAt": ts}),
                "entry_timestamp_ms": ts,
            }
            for ts in timestamps_ms
        ]

    def test_with_real_bubble_timestamps(self):
        entries = self._make_v1_entries([1000, 2000, 3000])
        metadata = {"createdAt": 500, "lastUpdatedAt": 5000}
        windows = get_cursor_api_window(metadata, entries)
        assert len(windows) == 1
        assert windows[0] == (1000, 3000)

    def test_v2_without_bubble_timestamps_uses_metadata(self):
        entries = self._make_v2_entries([1, 2, 1, 2])
        metadata = {
            "createdAt": 1746206863741,
            "lastUpdatedAt": 1746208863741,
        }
        windows = get_cursor_api_window(metadata, entries)
        assert len(windows) == 1
        assert windows[0] == (1746206863741, 1746208863741)

    def test_long_spanning_session_dual_windows(self):
        created = 1746206863741
        updated = created + 30 * 24 * 3600 * 1000
        entries = self._make_v2_entries([1, 2, 1, 2])
        metadata = {"createdAt": created, "lastUpdatedAt": updated}
        windows = get_cursor_api_window(metadata, entries)
        assert len(windows) == 2

        w1_start, w1_end = windows[0]
        assert w1_start == created - 60_000
        assert w1_end == created + 6 * 3600 * 1000

        w2_start, w2_end = windows[1]
        assert w2_end == updated + 60_000
        assert w2_start == updated - 6 * 3600 * 1000

    def test_no_timestamps_returns_empty(self):
        entries = self._make_v2_entries([1, 2])
        metadata = {}
        windows = get_cursor_api_window(metadata, entries)
        assert windows == []

    def test_overlapping_windows_merge(self):
        created = 1746206863741
        updated = created + 8 * 3600 * 1000
        entries = self._make_v2_entries([1, 2])
        metadata = {"createdAt": created, "lastUpdatedAt": updated}
        windows = get_cursor_api_window(metadata, entries)
        assert len(windows) == 1


# =============================================================================
# refine_timestamps_from_api_events tests
# =============================================================================


class TestRefineTimestampsFromApiEvents:
    """Tests for refine_timestamps_from_api_events."""

    def _make_entries(
        self, types: list[int], ts_ms: int = 1000000, include_metadata: bool = False
    ) -> list[dict]:
        entries = []
        if include_metadata:
            entries.append(
                {
                    "entry_content": json.dumps({"agent_type": "cursor"}),
                    "entry_timestamp_ms": ts_ms,
                    "entry_index": -1,
                }
            )
        for i, t in enumerate(types):
            entries.append(
                {
                    "entry_content": json.dumps({"type": t}),
                    "entry_timestamp_ms": ts_ms + i * 30000,
                    "entry_index": i,
                }
            )
        return entries

    def _make_api_events(self, timestamps: list[int]) -> list[dict]:
        return [{"timestamp": str(ts), "model": "claude-4.5-opus"} for ts in timestamps]

    def test_simple_turns_assign_api_timestamps(self):
        entries = self._make_entries([1, 2, 1, 2, 1, 2])
        api_events = self._make_api_events([2000000, 3000000, 4000000])

        result = refine_timestamps_from_api_events(entries, api_events)
        assert result is not None
        assert len(result) == 6
        assert result[1] == 2000000
        assert result[3] == 3000000
        assert result[5] == 4000000

    def test_user_bubble_placement(self):
        entries = self._make_entries([1, 2, 1, 2])
        api_events = self._make_api_events([2000000, 3000000])

        result = refine_timestamps_from_api_events(entries, api_events)
        assert result is not None
        assert result[0] == 2000000 - 5000
        assert result[2] == 3000000 - 5000

    def test_multi_assistant_turn_spreads_timestamps(self):
        entries = self._make_entries([1, 2, 2, 2, 1, 2])
        api_events = self._make_api_events([2000000, 3000000])

        result = refine_timestamps_from_api_events(entries, api_events)
        assert result is not None
        assert result[3] == 2000000
        assert result[2] == 2000000 - 2000
        assert result[1] == 2000000 - 4000
        assert result[0] == (2000000 - 4000) - 5000
        assert result[5] == 3000000
        assert result[4] == 3000000 - 5000

    def test_count_mismatch_wildly_different_returns_none(self):
        entries = self._make_entries([1, 2, 1, 2, 1, 2, 1, 2])
        api_events = self._make_api_events([2000000])
        result = refine_timestamps_from_api_events(entries, api_events)
        assert result is None

    def test_empty_entries_returns_none(self):
        result = refine_timestamps_from_api_events([], [{"timestamp": "1000"}])
        assert result is None

    def test_empty_api_events_returns_none(self):
        entries = self._make_entries([1, 2])
        result = refine_timestamps_from_api_events(entries, [])
        assert result is None

    def test_no_turns_returns_none(self):
        entries = self._make_entries([2, 2, 2])
        api_events = self._make_api_events([2000000])
        result = refine_timestamps_from_api_events(entries, api_events)
        assert result is None

    def test_includes_metadata_entry(self):
        entries = self._make_entries([1, 2, 1, 2], include_metadata=True)
        api_events = self._make_api_events([2000000, 3000000])

        result = refine_timestamps_from_api_events(entries, api_events)
        assert result is not None
        assert len(result) == 5
        assert result[0] == 1000000  # metadata preserved
        assert result[2] == 2000000
        assert result[4] == 3000000
