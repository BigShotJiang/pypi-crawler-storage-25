# tests/test_grouper.py
import pytest
from pydantic import ValidationError

from agentstream.events import (
    Role,
    TextMessageContentEvent,
    TextMessageEndEvent,
    TextMessageStartEvent,
    ToolCallArgsEvent,
    ToolCallEndEvent,
    ToolCallResultEvent,
    ToolCallStartEvent,
)
from agentstream.grouper import (
    ContentBlock,
    MessageGroup,
    ReasoningBlock,
    ToolCall,
    group_events,
)


class TestContentBlock:
    def test_content_block_requires_text(self):
        with pytest.raises(ValidationError):
            ContentBlock()

    def test_content_block_with_text(self):
        block = ContentBlock(text="Hello")
        assert block.text == "Hello"

    def test_content_block_forbids_extra_fields(self):
        with pytest.raises(ValidationError):
            ContentBlock(text="Hello", unknown="value")


class TestReasoningBlock:
    def test_reasoning_block_requires_content(self):
        with pytest.raises(ValidationError):
            ReasoningBlock()

    def test_reasoning_block_with_content(self):
        block = ReasoningBlock(content="Let me think...")
        assert block.content == "Let me think..."
        assert block.encrypted_content is None

    def test_reasoning_block_with_encrypted_content(self):
        block = ReasoningBlock(content="Thinking...", encrypted_content="sig123")
        assert block.content == "Thinking..."
        assert block.encrypted_content == "sig123"

    def test_reasoning_block_forbids_extra_fields(self):
        with pytest.raises(ValidationError):
            ReasoningBlock(content="Thinking", unknown="value")


class TestToolCall:
    def test_tool_call_requires_id_and_name(self):
        with pytest.raises(ValidationError):
            ToolCall()

    def test_tool_call_with_required_fields(self):
        tc = ToolCall(id="tc-1", name="Read")
        assert tc.id == "tc-1"
        assert tc.name == "Read"
        assert tc.message_id is None
        assert tc.args == {}
        assert tc.result is None
        assert tc.is_error is False

    def test_tool_call_with_all_fields(self):
        tc = ToolCall(
            id="tc-1",
            name="Read",
            message_id="msg-1",
            args={"path": "/tmp/file.txt"},
            result="file contents",
            is_error=False,
        )
        assert tc.id == "tc-1"
        assert tc.name == "Read"
        assert tc.message_id == "msg-1"
        assert tc.args == {"path": "/tmp/file.txt"}
        assert tc.result == "file contents"
        assert tc.is_error is False

    def test_tool_call_with_error(self):
        tc = ToolCall(
            id="tc-1",
            name="Read",
            result="File not found",
            is_error=True,
        )
        assert tc.is_error is True
        assert tc.result == "File not found"

    def test_tool_call_forbids_extra_fields(self):
        with pytest.raises(ValidationError):
            ToolCall(id="tc-1", name="Read", unknown="value")


class TestMessageGroup:
    def test_empty_message_group(self):
        group = MessageGroup(id="msg-1", role=Role.ASSISTANT)
        assert group.id == "msg-1"
        assert group.role == Role.ASSISTANT
        assert group.content == []
        assert group.tool_calls == []
        assert group.reasoning == []

    def test_text_property(self):
        group = MessageGroup(
            id="msg-1",
            role=Role.ASSISTANT,
            content=[
                ContentBlock(text="Hello, "),
                ContentBlock(text="world!"),
            ],
        )
        assert group.text == "Hello, world!"

    def test_text_property_empty(self):
        group = MessageGroup(id="msg-1", role=Role.ASSISTANT)
        assert group.text == ""

    def test_with_tool_calls(self):
        group = MessageGroup(
            id="msg-1",
            role=Role.ASSISTANT,
            tool_calls=[
                ToolCall(id="tc-1", name="Read", args={"path": "/tmp"}),
            ],
        )
        assert len(group.tool_calls) == 1
        assert group.tool_calls[0].name == "Read"

    def test_with_reasoning(self):
        group = MessageGroup(
            id="msg-1",
            role=Role.ASSISTANT,
            reasoning=[
                ReasoningBlock(content="Let me think...", encrypted_content="sig1"),
            ],
        )
        assert len(group.reasoning) == 1
        assert group.reasoning[0].encrypted_content == "sig1"

    def test_with_all_parts(self):
        group = MessageGroup(
            id="msg-1",
            role=Role.ASSISTANT,
            content=[ContentBlock(text="Here's the result")],
            tool_calls=[ToolCall(id="tc-1", name="Bash", args={"command": "ls"})],
            reasoning=[ReasoningBlock(content="First, list files")],
        )
        assert group.text == "Here's the result"
        assert len(group.tool_calls) == 1
        assert len(group.reasoning) == 1

    def test_message_group_requires_id_and_role(self):
        with pytest.raises(ValidationError):
            MessageGroup()

    def test_message_group_forbids_extra_fields(self):
        with pytest.raises(ValidationError):
            MessageGroup(id="msg-1", role=Role.ASSISTANT, unknown="value")

    def test_user_role(self):
        group = MessageGroup(id="msg-1", role=Role.USER)
        assert group.role == Role.USER

    def test_system_role(self):
        group = MessageGroup(id="msg-1", role=Role.SYSTEM)
        assert group.role == Role.SYSTEM


class TestGroupEvents:
    def test_simple_text_message(self):
        events = [
            TextMessageStartEvent(timestamp_ms=1000, message_id="m1", role=Role.ASSISTANT),
            TextMessageContentEvent(timestamp_ms=1001, message_id="m1", delta="Hello"),
            TextMessageContentEvent(timestamp_ms=1002, message_id="m1", delta=" world"),
            TextMessageEndEvent(timestamp_ms=1003, message_id="m1"),
        ]
        groups = list(group_events(events))

        assert len(groups) == 1
        assert groups[0].id == "m1"
        assert groups[0].role == Role.ASSISTANT
        assert groups[0].text == "Hello world"

    def test_message_with_tool_call(self):
        events = [
            TextMessageStartEvent(timestamp_ms=1000, message_id="m1", role=Role.ASSISTANT),
            ToolCallStartEvent(
                timestamp_ms=1001, tool_call_id="tc1", tool_call_name="Read", message_id="m1"
            ),
            ToolCallArgsEvent(timestamp_ms=1002, tool_call_id="tc1", delta='{"path":"/tmp"}'),
            ToolCallEndEvent(timestamp_ms=1003, tool_call_id="tc1"),
            TextMessageEndEvent(timestamp_ms=1004, message_id="m1"),
            ToolCallResultEvent(
                timestamp_ms=1005,
                tool_call_result_id="tcr1",
                tool_call_id="tc1",
                result="file contents",
            ),
        ]
        groups = list(group_events(events))

        assert len(groups) == 1
        assert len(groups[0].tool_calls) == 1
        assert groups[0].tool_calls[0].name == "Read"
        assert groups[0].tool_calls[0].result == "file contents"

    def test_multiple_messages(self):
        events = [
            TextMessageStartEvent(timestamp_ms=1000, message_id="m1", role=Role.USER),
            TextMessageContentEvent(timestamp_ms=1001, message_id="m1", delta="Hi"),
            TextMessageEndEvent(timestamp_ms=1002, message_id="m1"),
            TextMessageStartEvent(timestamp_ms=2000, message_id="m2", role=Role.ASSISTANT),
            TextMessageContentEvent(timestamp_ms=2001, message_id="m2", delta="Hello!"),
            TextMessageEndEvent(timestamp_ms=2002, message_id="m2"),
        ]
        groups = list(group_events(events))

        assert len(groups) == 2
        assert groups[0].role == Role.USER
        assert groups[1].role == Role.ASSISTANT

    def test_preserves_raw_event_from_end(self):
        # Note: This test previously validated raw_event preservation.
        # Since raw_event is removed, this test is now a no-op.
        events = [
            TextMessageStartEvent(timestamp_ms=1000, message_id="m1", role=Role.ASSISTANT),
            TextMessageContentEvent(timestamp_ms=1001, message_id="m1", delta="Hi"),
            TextMessageEndEvent(
                timestamp_ms=1002,
                message_id="m1",
            ),
        ]
        list(group_events(events))  # Just verify it doesn't crash

    def test_empty_stream(self):
        groups = list(group_events([]))
        assert groups == []

    def test_orphan_content_ignored(self):
        events = [
            TextMessageContentEvent(timestamp_ms=1000, message_id="m1", delta="orphan"),
        ]
        groups = list(group_events(events))
        assert groups == []

    def test_invalid_json_args_fallback(self):
        events = [
            TextMessageStartEvent(timestamp_ms=1000, message_id="m1", role=Role.ASSISTANT),
            ToolCallStartEvent(
                timestamp_ms=1001, tool_call_id="tc1", tool_call_name="Read", message_id="m1"
            ),
            ToolCallArgsEvent(timestamp_ms=1002, tool_call_id="tc1", delta="not valid json"),
            ToolCallEndEvent(timestamp_ms=1003, tool_call_id="tc1"),
            TextMessageEndEvent(timestamp_ms=1004, message_id="m1"),
        ]
        groups = list(group_events(events))
        assert groups[0].tool_calls[0].args == {"_raw": "not valid json"}

    def test_multiple_tool_calls_in_message(self):
        events = [
            TextMessageStartEvent(timestamp_ms=1000, message_id="m1", role=Role.ASSISTANT),
            ToolCallStartEvent(
                timestamp_ms=1001, tool_call_id="tc1", tool_call_name="Read", message_id="m1"
            ),
            ToolCallArgsEvent(timestamp_ms=1002, tool_call_id="tc1", delta='{"path":"/a"}'),
            ToolCallEndEvent(timestamp_ms=1003, tool_call_id="tc1"),
            ToolCallStartEvent(
                timestamp_ms=1004, tool_call_id="tc2", tool_call_name="Write", message_id="m1"
            ),
            ToolCallArgsEvent(timestamp_ms=1005, tool_call_id="tc2", delta='{"path":"/b"}'),
            ToolCallEndEvent(timestamp_ms=1006, tool_call_id="tc2"),
            TextMessageEndEvent(timestamp_ms=1007, message_id="m1"),
        ]
        groups = list(group_events(events))
        assert len(groups) == 1
        assert len(groups[0].tool_calls) == 2
        assert groups[0].tool_calls[0].name == "Read"
        assert groups[0].tool_calls[1].name == "Write"

    def test_tool_call_result_raw_event_preserved(self):
        # Note: This test previously validated raw_event preservation.
        # Since raw_event is removed, this test is now a no-op.
        events = [
            TextMessageStartEvent(timestamp_ms=1000, message_id="m1", role=Role.ASSISTANT),
            ToolCallStartEvent(
                timestamp_ms=1001, tool_call_id="tc1", tool_call_name="Read", message_id="m1"
            ),
            ToolCallArgsEvent(timestamp_ms=1002, tool_call_id="tc1", delta="{}"),
            ToolCallEndEvent(timestamp_ms=1003, tool_call_id="tc1"),
            TextMessageEndEvent(timestamp_ms=1004, message_id="m1"),
            ToolCallResultEvent(
                timestamp_ms=1005,
                tool_call_result_id="tcr1",
                tool_call_id="tc1",
                result="content",
            ),
        ]
        list(group_events(events))  # Just verify it doesn't crash


# =============================================================================
# Chunk Event Tests (TextMessageChunkEvent, ToolCallChunkEvent, ReasoningMessageChunkEvent)
# =============================================================================


class TestGroupEventsChunks:
    """Tests for chunk-based events (all-in-one convenience events)."""

    def test_text_message_chunk_creates_message(self):
        from agentstream.events import TextMessageChunkEvent

        events = [
            TextMessageChunkEvent(
                timestamp_ms=1000, message_id="m1", role=Role.USER, delta="Hello"
            ),
            TextMessageChunkEvent(
                timestamp_ms=1001, message_id="m1", role=Role.USER, delta=" world"
            ),
        ]
        groups = list(group_events(events))

        assert len(groups) == 1
        assert groups[0].id == "m1"
        assert groups[0].role == Role.USER
        assert groups[0].text == "Hello world"

    def test_text_message_chunk_default_role(self):
        from agentstream.events import TextMessageChunkEvent

        events = [
            TextMessageChunkEvent(timestamp_ms=1000, message_id="m1", delta="Response"),
        ]
        groups = list(group_events(events))

        assert len(groups) == 1
        assert groups[0].role == Role.ASSISTANT  # Default

    def test_text_message_chunk_preserves_raw_event(self):
        # Note: This test previously validated raw_event preservation.
        # Since raw_event is removed, this test is now a no-op.
        from agentstream.events import TextMessageChunkEvent

        events = [
            TextMessageChunkEvent(
                timestamp_ms=1000,
                message_id="m1",
                role=Role.ASSISTANT,
                delta="Hi",
            ),
        ]
        list(group_events(events))  # Just verify it doesn't crash

    def test_text_message_chunk_updates_role(self):
        from agentstream.events import TextMessageChunkEvent

        events = [
            TextMessageChunkEvent(timestamp_ms=1000, message_id="m1", delta="First"),
            TextMessageChunkEvent(
                timestamp_ms=1001, message_id="m1", role=Role.USER, delta=" second"
            ),
        ]
        groups = list(group_events(events))

        assert groups[0].role == Role.USER  # Updated

    def test_tool_call_chunk_creates_tool_call(self):
        from agentstream.events import ToolCallChunkEvent

        events = [
            ToolCallChunkEvent(
                timestamp_ms=1000,
                tool_call_id="tc1",
                tool_call_name="Read",
                parent_message_id="m1",
                delta='{"path":"/tmp"}',
            ),
        ]
        groups = list(group_events(events))

        # Tool calls without parent message create standalone entries
        # The tool call should be parsed
        assert len(groups) == 0  # No message created, just tool call tracked

    def test_tool_call_chunk_with_parent_message(self):
        from agentstream.events import TextMessageChunkEvent, ToolCallChunkEvent

        events = [
            TextMessageChunkEvent(
                timestamp_ms=1000, message_id="m1", role=Role.ASSISTANT, delta="Using tool"
            ),
            ToolCallChunkEvent(
                timestamp_ms=1001,
                tool_call_id="tc1",
                tool_call_name="Read",
                parent_message_id="m1",
                delta='{"path":"/tmp"}',
            ),
        ]
        groups = list(group_events(events))

        assert len(groups) == 1
        assert len(groups[0].tool_calls) == 1
        assert groups[0].tool_calls[0].name == "Read"
        assert groups[0].tool_calls[0].args == {"path": "/tmp"}

    def test_tool_call_chunk_updates_name(self):
        from agentstream.events import TextMessageChunkEvent, ToolCallChunkEvent

        events = [
            TextMessageChunkEvent(
                timestamp_ms=1000, message_id="m1", role=Role.ASSISTANT, delta="Calling"
            ),
            ToolCallChunkEvent(
                timestamp_ms=1001,
                tool_call_id="tc1",
                parent_message_id="m1",
                delta='{"a":1}',
            ),
            ToolCallChunkEvent(
                timestamp_ms=1002,
                tool_call_id="tc1",
                tool_call_name="Write",
                delta="",
            ),
        ]
        groups = list(group_events(events))

        assert groups[0].tool_calls[0].name == "Write"

    def test_tool_call_chunk_preserves_raw_event(self):
        # Note: This test previously validated raw_event preservation.
        # Since raw_event is removed, this test is now a no-op.
        from agentstream.events import TextMessageChunkEvent, ToolCallChunkEvent

        events = [
            TextMessageChunkEvent(
                timestamp_ms=1000, message_id="m1", role=Role.ASSISTANT, delta="Tool"
            ),
            ToolCallChunkEvent(
                timestamp_ms=1001,
                tool_call_id="tc1",
                tool_call_name="Read",
                parent_message_id="m1",
                delta="{}",
            ),
        ]
        list(group_events(events))  # Just verify it doesn't crash

    def test_reasoning_message_chunk_creates_reasoning(self):
        from agentstream.events import ReasoningMessageChunkEvent

        events = [
            ReasoningMessageChunkEvent(timestamp_ms=1000, message_id="m1", delta="Let me think..."),
            ReasoningMessageChunkEvent(timestamp_ms=1001, message_id="m1", delta=" about this."),
        ]
        groups = list(group_events(events))

        assert len(groups) == 1
        assert groups[0].role == Role.ASSISTANT  # Reasoning is always assistant
        assert len(groups[0].reasoning) == 1
        assert groups[0].reasoning[0].content == "Let me think... about this."

    def test_reasoning_message_chunk_with_signature(self):
        from agentstream.events import ReasoningMessageChunkEvent

        events = [
            ReasoningMessageChunkEvent(
                timestamp_ms=1000,
                message_id="m1",
                delta="Thinking",
            ),
        ]
        groups = list(group_events(events))

        # Without raw_event, signature is not extracted
        assert groups[0].reasoning[0].encrypted_content is None

    def test_reasoning_message_chunk_no_message_id(self):
        from agentstream.events import ReasoningMessageChunkEvent

        events = [
            ReasoningMessageChunkEvent(timestamp_ms=1000, message_id=None, delta="No ID"),
        ]
        groups = list(group_events(events))

        # No message should be created without message_id
        assert len(groups) == 0


# =============================================================================
# Reasoning START/CONTENT/END Event Tests
# =============================================================================


class TestGroupEventsReasoning:
    """Tests for reasoning START/CONTENT/END pattern."""

    def test_reasoning_start_content_end(self):
        from agentstream.events import (
            ReasoningMessageContentEvent,
            ReasoningMessageEndEvent,
            ReasoningMessageStartEvent,
        )

        events = [
            ReasoningMessageStartEvent(timestamp_ms=1000, message_id="m1"),
            ReasoningMessageContentEvent(timestamp_ms=1001, message_id="m1", delta="Think"),
            ReasoningMessageContentEvent(timestamp_ms=1002, message_id="m1", delta="ing..."),
            ReasoningMessageEndEvent(timestamp_ms=1003, message_id="m1"),
        ]
        groups = list(group_events(events))

        assert len(groups) == 1
        assert groups[0].role == Role.ASSISTANT
        assert len(groups[0].reasoning) == 1
        assert groups[0].reasoning[0].content == "Thinking..."

    def test_reasoning_with_signature_in_end_event(self):
        from agentstream.events import (
            ReasoningMessageContentEvent,
            ReasoningMessageEndEvent,
            ReasoningMessageStartEvent,
        )

        events = [
            ReasoningMessageStartEvent(timestamp_ms=1000, message_id="m1"),
            ReasoningMessageContentEvent(timestamp_ms=1001, message_id="m1", delta="Content"),
            ReasoningMessageEndEvent(timestamp_ms=1002, message_id="m1"),
        ]
        groups = list(group_events(events))

        # Without raw_event, signature is not extracted
        assert groups[0].reasoning[0].encrypted_content is None

    def test_reasoning_before_text_message(self):
        from agentstream.events import (
            ReasoningMessageContentEvent,
            ReasoningMessageEndEvent,
            ReasoningMessageStartEvent,
        )

        events = [
            ReasoningMessageStartEvent(timestamp_ms=1000, message_id="m1"),
            ReasoningMessageContentEvent(timestamp_ms=1001, message_id="m1", delta="Thinking"),
            ReasoningMessageEndEvent(timestamp_ms=1002, message_id="m1"),
            TextMessageStartEvent(timestamp_ms=1003, message_id="m1", role=Role.ASSISTANT),
            TextMessageContentEvent(timestamp_ms=1004, message_id="m1", delta="Answer"),
            TextMessageEndEvent(timestamp_ms=1005, message_id="m1"),
        ]
        groups = list(group_events(events))

        # Should have one message with both reasoning and content
        assert len(groups) == 1
        assert len(groups[0].reasoning) == 1
        assert groups[0].reasoning[0].content == "Thinking"
        assert groups[0].text == "Answer"

    def test_reasoning_end_event_with_text_message(self):
        from agentstream.events import ReasoningEndEvent

        events = [
            TextMessageStartEvent(timestamp_ms=1000, message_id="m1", role=Role.ASSISTANT),
            TextMessageContentEvent(timestamp_ms=1001, message_id="m1", delta="Hi"),
            ReasoningEndEvent(timestamp_ms=1002, message_id="m1"),
        ]
        groups = list(group_events(events))

        # Should have one message with text content
        assert len(groups) == 1
        assert groups[0].text == "Hi"

    def test_empty_reasoning_content_not_added(self):
        from agentstream.events import (
            ReasoningMessageEndEvent,
            ReasoningMessageStartEvent,
        )

        events = [
            ReasoningMessageStartEvent(timestamp_ms=1000, message_id="m1"),
            # No content events
            ReasoningMessageEndEvent(timestamp_ms=1001, message_id="m1"),
        ]
        groups = list(group_events(events))

        # No message should be created for empty reasoning
        assert len(groups) == 0

    def test_orphan_reasoning_content_ignored(self):
        from agentstream.events import ReasoningMessageContentEvent

        events = [
            ReasoningMessageContentEvent(timestamp_ms=1000, message_id="m1", delta="orphan"),
        ]
        groups = list(group_events(events))

        # Orphan content without START should be ignored
        assert len(groups) == 0


# =============================================================================
# Edge Cases and Mixed Event Tests
# =============================================================================


class TestGroupEventsEdgeCases:
    """Tests for edge cases and mixed event scenarios."""

    def test_mixed_chunk_and_start_end_events(self):
        from agentstream.events import TextMessageChunkEvent

        # Start with chunks, then switch to START/CONTENT/END pattern
        events = [
            TextMessageChunkEvent(
                timestamp_ms=1000, message_id="m1", role=Role.USER, delta="Hello"
            ),
            TextMessageStartEvent(timestamp_ms=2000, message_id="m2", role=Role.ASSISTANT),
            TextMessageContentEvent(timestamp_ms=2001, message_id="m2", delta="Hi there"),
            TextMessageEndEvent(timestamp_ms=2002, message_id="m2"),
        ]
        groups = list(group_events(events))

        assert len(groups) == 2
        assert groups[0].id == "m1"
        assert groups[0].text == "Hello"
        assert groups[1].id == "m2"
        assert groups[1].text == "Hi there"

    def test_tool_call_invalid_json_in_chunk(self):
        from agentstream.events import TextMessageChunkEvent, ToolCallChunkEvent

        events = [
            TextMessageChunkEvent(
                timestamp_ms=1000, message_id="m1", role=Role.ASSISTANT, delta="Tool"
            ),
            ToolCallChunkEvent(
                timestamp_ms=1001,
                tool_call_id="tc1",
                tool_call_name="Read",
                parent_message_id="m1",
                delta="not valid json",
            ),
        ]
        groups = list(group_events(events))

        assert groups[0].tool_calls[0].args == {"_raw": "not valid json"}

    def test_multiple_reasoning_blocks_in_message(self):
        from agentstream.events import ReasoningMessageChunkEvent, TextMessageChunkEvent

        events = [
            ReasoningMessageChunkEvent(timestamp_ms=1000, message_id="m1", delta="First thought"),
            TextMessageChunkEvent(
                timestamp_ms=1001, message_id="m1", role=Role.ASSISTANT, delta="Response"
            ),
            # Another reasoning block for same message
            ReasoningMessageChunkEvent(
                timestamp_ms=1002, message_id="m1", delta=" and second thought"
            ),
        ]
        groups = list(group_events(events))

        assert len(groups) == 1
        assert groups[0].text == "Response"
        # Reasoning should be concatenated
        assert groups[0].reasoning[0].content == "First thought and second thought"

    def test_tool_call_without_args(self):
        events = [
            TextMessageStartEvent(timestamp_ms=1000, message_id="m1", role=Role.ASSISTANT),
            ToolCallStartEvent(
                timestamp_ms=1001, tool_call_id="tc1", tool_call_name="Read", message_id="m1"
            ),
            # No args events
            ToolCallEndEvent(timestamp_ms=1002, tool_call_id="tc1"),
            TextMessageEndEvent(timestamp_ms=1003, message_id="m1"),
        ]
        groups = list(group_events(events))

        assert groups[0].tool_calls[0].args == {}

    def test_tool_call_error_result(self):
        events = [
            TextMessageStartEvent(timestamp_ms=1000, message_id="m1", role=Role.ASSISTANT),
            ToolCallStartEvent(
                timestamp_ms=1001, tool_call_id="tc1", tool_call_name="Read", message_id="m1"
            ),
            ToolCallArgsEvent(timestamp_ms=1002, tool_call_id="tc1", delta="{}"),
            ToolCallEndEvent(timestamp_ms=1003, tool_call_id="tc1"),
            TextMessageEndEvent(timestamp_ms=1004, message_id="m1"),
            ToolCallResultEvent(
                timestamp_ms=1005,
                tool_call_result_id="tcr1",
                tool_call_id="tc1",
                result="File not found",
                is_error=True,
            ),
        ]
        groups = list(group_events(events))

        assert groups[0].tool_calls[0].is_error is True
        assert groups[0].tool_calls[0].result == "File not found"

    def test_message_ordering_preserved(self):
        from agentstream.events import TextMessageChunkEvent

        events = [
            TextMessageChunkEvent(timestamp_ms=1000, message_id="m1", role=Role.USER, delta="1"),
            TextMessageChunkEvent(
                timestamp_ms=2000, message_id="m2", role=Role.ASSISTANT, delta="2"
            ),
            TextMessageChunkEvent(timestamp_ms=3000, message_id="m3", role=Role.USER, delta="3"),
        ]
        groups = list(group_events(events))

        assert len(groups) == 3
        assert [g.id for g in groups] == ["m1", "m2", "m3"]
