# tests/events/test_events_init.py
"""Tests for agentstream.events module public API."""

# These imports verify that all event types are properly exported from the public API.
# The imports are intentional even if not all are used directly in tests.
from agentstream.events import (  # noqa: F401
    BaseEvent,
    CustomEvent,
    Event,
    EventType,
    Role,
    RunErrorEvent,
    RunFinishedEvent,
    RunStartedEvent,
    TextMessageContentEvent,
    TextMessageEndEvent,
    TextMessageStartEvent,
    ToolCallArgsEvent,
    ToolCallEndEvent,
    ToolCallResultEvent,
    ToolCallStartEvent,
)


class TestEventUnion:
    def test_event_union_accepts_all_event_types(self):
        from pydantic import TypeAdapter

        adapter = TypeAdapter(Event)

        # Parse a RunStartedEvent
        data = {
            "type": "RUN_STARTED",
            "timestamp_ms": 1000,
            "thread_id": "t1",
            "run_id": "r1",
        }
        event = adapter.validate_python(data)
        assert isinstance(event, RunStartedEvent)

        # Parse a TextMessageContentEvent
        data = {
            "type": "TEXT_MESSAGE_CONTENT",
            "timestamp_ms": 2000,
            "message_id": "m1",
            "delta": "Hello",
        }
        event = adapter.validate_python(data)
        assert isinstance(event, TextMessageContentEvent)

    def test_event_union_discriminates_on_type(self):
        from pydantic import TypeAdapter

        adapter = TypeAdapter(Event)

        data = {"type": "CUSTOM", "timestamp_ms": 1000, "name": "test", "value": {}}
        event = adapter.validate_python(data)
        assert isinstance(event, CustomEvent)
