"""Tests for agentstream CLI."""

from __future__ import annotations

import io
import json
import sys
from pathlib import Path
from typing import Any
from unittest.mock import MagicMock, patch

import pytest

from agentstream.adapters.base import Session
from agentstream.cli import (
    ViewerHandler,
    ViewerState,
    _load_viewer_html,
    list_sessions_cmd,
    main,
    replay_session_cmd,
)

# =============================================================================
# ViewerState Tests
# =============================================================================


class TestViewerState:
    def test_init(self, tmp_path: Path) -> None:
        """ViewerState initializes correctly."""
        session = Session(
            id="test-session",
            path=tmp_path / "session.jsonl",
            format="claude",
            modified_at=1000.0,
        )
        state = ViewerState(
            project_dir=tmp_path,
            sessions=[session],
            current_session=session,
        )

        assert state.project_dir == tmp_path
        assert len(state.sessions) == 1
        assert state.current_session == session
        assert state.all_events == []

    def test_sessions_json(self, tmp_path: Path) -> None:
        """sessions_json returns proper JSON-serializable list."""
        session = Session(
            id="test-session",
            path=tmp_path / "session.jsonl",
            format="claude",
            modified_at=1704067200.0,
        )
        state = ViewerState(
            project_dir=tmp_path,
            sessions=[session],
            current_session=session,
        )

        result = state.sessions_json()

        assert len(result) == 1
        assert result[0]["id"] == "test-session"
        assert result[0]["agent"] == "claude"
        assert result[0]["isCurrent"] is True
        assert "startedAt" in result[0]

    def test_find_session(self, tmp_path: Path) -> None:
        """find_session finds sessions by ID."""
        session1 = Session(
            id="session-1", path=tmp_path / "s1.jsonl", format="claude", modified_at=1000.0
        )
        session2 = Session(
            id="session-2", path=tmp_path / "s2.jsonl", format="codex", modified_at=2000.0
        )

        state = ViewerState(
            project_dir=tmp_path,
            sessions=[session1, session2],
            current_session=session1,
        )

        assert state.find_session("session-1") == session1
        assert state.find_session("session-2") == session2
        assert state.find_session("nonexistent") is None

    def test_load_session(self, tmp_path: Path) -> None:
        """load_session loads events from a session."""
        # Create a real session file
        session_file = tmp_path / "session.jsonl"
        session_file.write_text(
            '{"type":"user","message":{"content":"Hello"},"uuid":"u1","timestamp":"2024-01-01T00:00:00Z"}\n'
        )

        session = Session(
            id="test-session",
            path=session_file,
            format="claude",
            modified_at=1000.0,
        )

        state = ViewerState(
            project_dir=tmp_path,
            sessions=[session],
            current_session=session,
        )

        state.load_session(session)

        assert len(state.all_events) > 0
        assert state.current_session == session


# =============================================================================
# Command Tests
# =============================================================================


class TestListSessionsCmd:
    def test_lists_sessions(self, tmp_path: Path, capsys: Any) -> None:
        """list_sessions_cmd prints sessions."""
        sessions = [
            Session(
                id="session-1",
                path=tmp_path / "s1.jsonl",
                format="claude",
                modified_at=1704067200.0,
            ),
            Session(
                id="session-2", path=tmp_path / "s2.jsonl", format="codex", modified_at=1704153600.0
            ),
        ]

        list_sessions_cmd(sessions)

        captured = capsys.readouterr()
        assert "session-1" in captured.out
        assert "session-2" in captured.out
        assert "[claude]" in captured.out
        assert "[codex]" in captured.out


class TestReplaySessionCmd:
    def test_replays_session(self, tmp_path: Path, capsys: Any) -> None:
        """replay_session_cmd replays events to stdout."""
        # Create a session file
        session_file = tmp_path / "session.jsonl"
        session_file.write_text(
            '{"type":"user","message":{"content":"Hello"},"uuid":"u1","timestamp":"2024-01-01T00:00:00Z"}\n'
        )

        session = Session(
            id="test-session",
            path=session_file,
            format="claude",
            modified_at=1000.0,
        )

        replay_session_cmd(session)

        captured = capsys.readouterr()
        assert "Replaying session" in captured.out
        assert "Replay complete" in captured.out


# =============================================================================
# Main CLI Tests
# =============================================================================


class TestMainCli:
    def test_list_flag(self, tmp_path: Path, monkeypatch: Any) -> None:
        """--list flag lists sessions and exits."""
        # Create a session file
        session_file = tmp_path / ".claude" / "projects" / "-test-project" / "session.jsonl"
        session_file.parent.mkdir(parents=True)
        session_file.write_text(
            '{"type":"user","message":{"content":"test"},"uuid":"u1","timestamp":"2024-01-01T00:00:00Z"}\n'
        )

        monkeypatch.setattr(Path, "home", lambda: tmp_path)

        # Run CLI with --list
        with patch.object(sys, "argv", ["agentstream", "--dir", str(tmp_path), "--list"]):
            with pytest.raises(SystemExit) as exc_info:
                main()
            assert exc_info.value.code == 0

    def test_no_sessions_found(self, tmp_path: Path, monkeypatch: Any) -> None:
        """CLI exits cleanly when no sessions found."""
        monkeypatch.setattr(Path, "home", lambda: tmp_path)

        with patch.object(sys, "argv", ["agentstream", "--dir", str(tmp_path)]):
            with pytest.raises(SystemExit) as exc_info:
                main()
            assert exc_info.value.code == 0

    def test_file_not_found(self, tmp_path: Path) -> None:
        """--file with nonexistent file exits with error."""
        with patch.object(
            sys, "argv", ["agentstream", "--file", str(tmp_path / "nonexistent.jsonl")]
        ):
            with pytest.raises(SystemExit) as exc_info:
                main()
            assert exc_info.value.code == 1

    def test_file_with_replay(self, tmp_path: Path, capsys: Any) -> None:
        """--file with --replay replays the file."""
        # Create a log file
        log_file = tmp_path / "test.jsonl"
        log_file.write_text(
            '{"type":"user","message":{"content":"Hello"},"uuid":"u1","timestamp":"2024-01-01T00:00:00Z"}\n'
        )

        with patch.object(sys, "argv", ["agentstream", "--file", str(log_file), "--replay"]):
            main()

        captured = capsys.readouterr()
        assert "Replaying session" in captured.out

    def test_session_not_found(self, tmp_path: Path, monkeypatch: Any) -> None:
        """--session with nonexistent session exits with error."""
        # Create one session
        session_file = (
            tmp_path
            / ".claude"
            / "projects"
            / "-test"
            / "a1b2c3d4-e5f6-7890-abcd-ef1234567890.jsonl"
        )
        session_file.parent.mkdir(parents=True)
        session_file.write_text(
            '{"type":"user","message":{"content":"test"},"uuid":"u1","timestamp":"2024-01-01T00:00:00Z"}\n'
        )

        monkeypatch.setattr(Path, "home", lambda: tmp_path)

        with patch.object(
            sys, "argv", ["agentstream", "--dir", str(tmp_path), "--session", "nonexistent"]
        ):
            with pytest.raises(SystemExit) as exc_info:
                main()
            assert exc_info.value.code == 1


# =============================================================================
# ViewerHandler Tests
# =============================================================================


class TestViewerHandler:
    def test_send_json(self, tmp_path: Path) -> None:
        """_send_json sends proper JSON response."""
        session = Session(id="test", path=tmp_path / "test.jsonl", format="claude", modified_at=0.0)
        state = ViewerState(tmp_path, [session], session)

        # Create a mock request handler
        with patch("http.server.SimpleHTTPRequestHandler.__init__", return_value=None):
            handler = ViewerHandler.__new__(ViewerHandler)
            handler.state = state
            handler.wfile = io.BytesIO()
            handler.send_response = MagicMock()
            handler.send_header = MagicMock()
            handler.end_headers = MagicMock()

            handler._send_json({"test": "data"})

            # Check response was written
            content = handler.wfile.getvalue()
            assert b'"test"' in content
            assert b'"data"' in content

    def test_send_json_error(self, tmp_path: Path) -> None:
        """_send_json_error sends proper error response."""
        session = Session(id="test", path=tmp_path / "test.jsonl", format="claude", modified_at=0.0)
        state = ViewerState(tmp_path, [session], session)

        with patch("http.server.SimpleHTTPRequestHandler.__init__", return_value=None):
            handler = ViewerHandler.__new__(ViewerHandler)
            handler.state = state
            handler.wfile = io.BytesIO()
            handler.send_response = MagicMock()
            handler.send_header = MagicMock()
            handler.end_headers = MagicMock()

            handler._send_json_error(404, "Not Found")

            content = handler.wfile.getvalue()
            assert b'"error"' in content
            assert b'"Not Found"' in content


# =============================================================================
# Load Viewer HTML Tests
# =============================================================================


class TestLoadViewerHtml:
    def test_viewer_html_not_found(self) -> None:
        """Raises FileNotFoundError when viewer.html doesn't exist."""
        # Clear any cached value
        import agentstream.cli

        agentstream.cli._VIEWER_HTML = None

        with (
            patch.object(Path, "exists", return_value=False),
            pytest.raises(FileNotFoundError, match="viewer.html not found"),
        ):
            _load_viewer_html()

    def test_viewer_html_cached(self, tmp_path: Path) -> None:
        """Viewer HTML is cached after first load."""
        import agentstream.cli

        # Set cached value
        agentstream.cli._VIEWER_HTML = "<html>cached</html>"

        result = _load_viewer_html()

        assert result == "<html>cached</html>"

        # Reset
        agentstream.cli._VIEWER_HTML = None


# =============================================================================
# Dev Mode Tests
# =============================================================================


class TestDevMode:
    def test_dev_mode_without_hupper(self, tmp_path: Path, capsys: Any) -> None:
        """--dev without hupper exits with error."""
        with (
            patch.object(sys, "argv", ["agentstream", "--dev"]),
            patch.dict(sys.modules, {"hupper": None}),
            pytest.raises(SystemExit) as exc_info,
        ):
            # Force ImportError for hupper
            import builtins

            original_import = builtins.__import__

            def mock_import(name: str, *args: Any, **kwargs: Any) -> Any:
                if name == "hupper":
                    raise ImportError("No module named 'hupper'")
                return original_import(name, *args, **kwargs)

            with patch.object(builtins, "__import__", mock_import):
                main()

        assert exc_info.value.code == 1

        captured = capsys.readouterr()
        assert "hupper" in captured.err


# =============================================================================
# Integration Tests
# =============================================================================


class TestCliIntegration:
    def test_end_to_end_file_mode(self, tmp_path: Path, capsys: Any) -> None:
        """End-to-end test with --file and --replay."""
        # Create a complete session file
        session_file = tmp_path / "complete_session.jsonl"
        entries = [
            {
                "type": "user",
                "message": {"content": "What is 2+2?"},
                "uuid": "u1",
                "timestamp": "2024-01-01T00:00:00Z",
            },
            {
                "type": "assistant",
                "message": {"content": [{"type": "text", "text": "2+2 equals 4."}]},
                "uuid": "a1",
                "parentUuid": "u1",
                "timestamp": "2024-01-01T00:00:01Z",
            },
        ]
        with open(session_file, "w") as f:
            for entry in entries:
                f.write(json.dumps(entry) + "\n")

        with patch.object(sys, "argv", ["agentstream", "--file", str(session_file), "--replay"]):
            main()

        captured = capsys.readouterr()
        assert "Replaying session" in captured.out
        assert "TEXT_MESSAGE_CHUNK" in captured.out or "text_message_chunk" in captured.out
