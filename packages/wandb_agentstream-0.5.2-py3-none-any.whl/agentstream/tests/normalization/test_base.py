from agentstream.normalization.base import BaseNormalizer


class TestNormalizer(BaseNormalizer):
    def extract_todo(self, event):
        return None

    def extract_file_operation(self, event):
        return None

    def extract_skill(self, event):
        return None

    def extract_diff(self, event, session):
        return None

    def extract_session_metadata(self, source_entries, daemon_metadata=None):
        return None

    def extract_token_usage(self, source_entry):
        return []

    def extract_error(self, source_entry):
        return None

    def extract_compaction(self, source_entries):
        return []


def test_base_normalizer_interface():
    """Ensure normalizer implements required methods"""
    normalizer = TestNormalizer()
    assert hasattr(normalizer, "extract_todo")
    assert hasattr(normalizer, "extract_file_operation")
    assert hasattr(normalizer, "extract_skill")
    assert hasattr(normalizer, "extract_diff")
    assert hasattr(normalizer, "extract_session_metadata")
    assert hasattr(normalizer, "extract_token_usage")
    assert hasattr(normalizer, "extract_error")
    assert hasattr(normalizer, "extract_compaction")


def test_base_normalizer_returns_none_by_default():
    """Base implementations return None for non-matching events"""
    normalizer = TestNormalizer()
    fake_event = {"tool_name": "unknown"}

    assert normalizer.extract_todo(fake_event) is None
    assert normalizer.extract_file_operation(fake_event) is None
    assert normalizer.extract_skill(fake_event) is None
    assert normalizer.extract_diff(fake_event, None) is None
    assert normalizer.extract_session_metadata([fake_event]) is None
    assert normalizer.extract_token_usage(fake_event) == []
    assert normalizer.extract_error(fake_event) is None
    assert normalizer.extract_compaction([fake_event]) == []
