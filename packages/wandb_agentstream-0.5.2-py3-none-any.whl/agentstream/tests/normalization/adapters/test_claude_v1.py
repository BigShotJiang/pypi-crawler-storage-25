from agentstream.normalization.adapters.claude_v1 import ClaudeV1Normalizer


def test_claude_extract_todo_from_todowrite():
    """Extract todos from Claude TodoWrite tool"""
    normalizer = ClaudeV1Normalizer()

    event = {
        "event_id": "evt-123",
        "tool_name": "TodoWrite",
        "timestamp_ms": 1704067200000,
        "agent_type": "claude",
        "args": {
            "todos": [
                {
                    "content": "Fix bug",
                    "status": "in_progress",
                    "activeForm": "Fixing bug",
                    "id": "todo-1",
                }
            ]
        },
        "result": {
            "initialTodos": [],
            "finalTodos": [
                {
                    "content": "Fix bug",
                    "status": "in_progress",
                    "activeForm": "Fixing bug",
                    "id": "todo-1",
                }
            ],
        },
    }

    todos = normalizer.extract_todo(event)
    assert todos is not None
    assert len(todos) == 1
    assert todos[0].content == "Fix bug"
    assert todos[0].status == "in_progress"
    assert todos[0].id == "todo-1"
    assert todos[0].source_tool == "TodoWrite"


def test_claude_extract_todo_returns_none_for_non_todo():
    """Returns None for non-todo events"""
    normalizer = ClaudeV1Normalizer()

    event = {"tool_name": "Read", "args": {"file_path": "test.py"}}

    assert normalizer.extract_todo(event) is None


def test_claude_extract_file_operation_edit():
    """Extract Edit file operation"""
    normalizer = ClaudeV1Normalizer()

    event = {
        "event_id": "evt-456",
        "tool_name": "Edit",
        "timestamp_ms": 1704067200000,
        "agent_type": "claude",
        "args": {
            "file_path": "src/auth.py",
            "old_string": "def login():\\n    pass",
            "new_string": "def login():\\n    return True",
        },
        "result": {"file_path": "src/auth.py"},
    }

    file_op = normalizer.extract_file_operation(event)
    assert file_op is not None
    assert file_op.file_path == "src/auth.py"
    assert file_op.operation == "edit"
    assert file_op.source_tool == "Edit"
    assert file_op.confidence == "high"


def test_claude_extract_file_operation_write():
    """Extract Write file operation"""
    normalizer = ClaudeV1Normalizer()

    event = {
        "event_id": "evt-789",
        "tool_name": "Write",
        "timestamp_ms": 1704067200000,
        "agent_type": "claude",
        "args": {"file_path": "src/new_file.py", "content": "# New file\\nprint('hello')"},
    }

    file_op = normalizer.extract_file_operation(event)
    assert file_op is not None
    assert file_op.file_path == "src/new_file.py"
    assert file_op.operation == "write"
    assert file_op.confidence == "high"


def test_claude_extract_file_operation_read():
    """Extract Read file operation"""
    normalizer = ClaudeV1Normalizer()

    event = {
        "event_id": "evt-101",
        "tool_name": "Read",
        "timestamp_ms": 1704067200000,
        "agent_type": "claude",
        "args": {"file_path": "src/config.py"},
    }

    file_op = normalizer.extract_file_operation(event)
    assert file_op is not None
    assert file_op.file_path == "src/config.py"
    assert file_op.operation == "read"
    assert file_op.diff is None  # No diff for reads


def test_claude_extract_diff_from_structured_patch():
    """Extract diff from Claude structured_patch result"""
    normalizer = ClaudeV1Normalizer()

    event = {
        "event_id": "evt-456",
        "tool_name": "Edit",
        "result": {
            "structured_patch": {
                "hunks": [
                    {
                        "old_start": 10,
                        "old_count": 3,
                        "new_start": 10,
                        "new_count": 4,
                        "lines": [
                            " def login(username, password):",
                            "-    pass",
                            "+    if authenticate(username, password):",
                            "+        return True",
                            " ",
                        ],
                    }
                ]
            }
        },
    }

    diff = normalizer.extract_diff(event, session=None)
    assert diff is not None
    assert diff.format_source == "structured_patch"
    assert diff.confidence == "high"
    assert len(diff.hunks) == 1
    assert diff.hunks[0].new_start == 10
    assert diff.lines_added == [11, 12]  # Lines 11 and 12 were added
    assert diff.lines_modified == []


def test_claude_extract_diff_no_structured_patch():
    """Returns None when no structured_patch in result"""
    normalizer = ClaudeV1Normalizer()

    event = {"tool_name": "Edit", "result": {"file_path": "test.py"}}

    diff = normalizer.extract_diff(event, session=None)
    assert diff is None


def test_claude_extract_skill_from_skill_tool():
    """Extract skill from Claude Skill tool"""
    normalizer = ClaudeV1Normalizer()

    event = {
        "event_id": "evt-skill-1",
        "tool_name": "Skill",
        "timestamp_ms": 1704067200000,
        "agent_type": "claude",
        "args": {"skill": "superpowers:brainstorming", "args": "--verbose"},
    }

    skill = normalizer.extract_skill(event)
    assert skill is not None
    assert skill.name == "superpowers:brainstorming"
    assert skill.method == "tool"
    assert skill.skill_type == "tool"
    assert skill.args == "--verbose"


def test_claude_extract_skill_returns_none_for_non_skill():
    """Returns None for non-skill events"""
    normalizer = ClaudeV1Normalizer()

    event = {"tool_name": "Edit", "args": {"file_path": "test.py"}}

    assert normalizer.extract_skill(event) is None
