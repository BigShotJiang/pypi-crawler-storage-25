# agentstream/registry.py
"""Adapter registry for format discovery."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .adapters.base import Adapter

_adapters: dict[str, Adapter] = {}
_initialized = False


def register(adapter: Adapter) -> None:
    """Register an adapter globally."""
    _adapters[adapter.name] = adapter


def get_adapter(name: str) -> Adapter | None:
    """Get adapter by name."""
    _ensure_initialized()
    return _adapters.get(name)


def all_adapters() -> list[Adapter]:
    """Get all registered adapters."""
    _ensure_initialized()
    return list(_adapters.values())


def _ensure_initialized() -> None:
    """Ensure built-in adapters are registered."""
    global _initialized
    if _initialized:
        return
    _initialized = True

    from .adapters.claude import ClaudeAdapter
    from .adapters.claude_web import ClaudeWebAdapter
    from .adapters.codex import CodexAdapter
    from .adapters.cursor import CursorAdapter
    from .adapters.gemini import GeminiAdapter
    from .adapters.opencode import OpenCodeAdapter

    register(ClaudeAdapter())
    register(ClaudeWebAdapter())
    register(CodexAdapter())
    register(CursorAdapter())
    register(GeminiAdapter())
    register(OpenCodeAdapter())
