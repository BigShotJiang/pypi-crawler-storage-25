"""Read Claude Code credentials from system storage.

Claude Code stores OAuth credentials in different locations depending on the platform:
- macOS: Keychain under service name "Claude Code-credentials"
- Linux/other: ~/.claude/.credentials.json

These credentials are used to authenticate with Anthropic's API for features
like session teleportation (syncing web sessions to local).
"""

from __future__ import annotations

import json
import logging
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path

logger = logging.getLogger(__name__)

# Claude credentials file locations
CLAUDE_CREDENTIALS_FILE = Path.home() / ".claude" / ".credentials.json"
CLAUDE_CONFIG_FILE = Path.home() / ".claude.json"

# Keychain service name for macOS
KEYCHAIN_SERVICE_NAME = "Claude Code-credentials"


@dataclass
class ClaudeCredentials:
    """Claude Code OAuth credentials."""

    access_token: str
    refresh_token: str | None
    expires_at: int  # Unix timestamp in milliseconds
    scopes: list[str]
    organization_uuid: str | None = None

    @property
    def is_expired(self) -> bool:
        """Check if the access token has expired."""
        import time

        # expires_at is in milliseconds
        return time.time() * 1000 >= self.expires_at

    @property
    def expires_in_seconds(self) -> float:
        """Seconds until expiration (negative if expired)."""
        import time

        return (self.expires_at / 1000) - time.time()


def _read_from_keychain() -> dict | None:
    """Read credentials from macOS Keychain.

    Returns:
        Parsed credentials dict or None if not found/failed.
    """
    if sys.platform != "darwin":
        return None

    try:
        # Use security command to read from keychain
        result = subprocess.run(
            [
                "security",
                "find-generic-password",
                "-s",
                KEYCHAIN_SERVICE_NAME,
                "-w",
            ],
            capture_output=True,
            text=True,
            timeout=10,
        )

        if result.returncode != 0:
            logger.debug(f"Keychain read failed (exit {result.returncode})")
            return None

        # Parse the JSON data
        creds_data = json.loads(result.stdout.strip())
        return creds_data

    except subprocess.TimeoutExpired:
        logger.warning("Keychain access timed out")
        return None
    except subprocess.SubprocessError as e:
        logger.debug(f"Keychain access failed: {e}")
        return None
    except json.JSONDecodeError as e:
        logger.warning(f"Failed to parse keychain data: {e}")
        return None


def _read_from_file() -> dict | None:
    """Read credentials from the Claude credentials file.

    Returns:
        Parsed credentials dict or None if not found/failed.
    """
    if not CLAUDE_CREDENTIALS_FILE.exists():
        logger.debug(f"Credentials file not found: {CLAUDE_CREDENTIALS_FILE}")
        return None

    try:
        with open(CLAUDE_CREDENTIALS_FILE) as f:
            return json.load(f)
    except json.JSONDecodeError as e:
        logger.warning(f"Failed to parse credentials file: {e}")
        return None
    except OSError as e:
        logger.debug(f"Failed to read credentials file: {e}")
        return None


def _read_organization_uuid() -> str | None:
    """Read organization UUID from Claude config file.

    Returns:
        Organization UUID string or None if not found.
    """
    if not CLAUDE_CONFIG_FILE.exists():
        return None

    try:
        with open(CLAUDE_CONFIG_FILE) as f:
            config = json.load(f)
            # Try both possible locations for org UUID
            oauth_account = config.get("oauthAccount", {})
            return oauth_account.get("organizationUuid")
    except (json.JSONDecodeError, OSError) as e:
        logger.debug(f"Failed to read Claude config: {e}")
        return None


def read_claude_credentials() -> ClaudeCredentials | None:
    """Read Claude Code OAuth credentials from system storage.

    Attempts to read credentials from:
    1. macOS Keychain (if on macOS)
    2. ~/.claude/.credentials.json (fallback)

    Also reads organization UUID from ~/.claude.json if available.

    Returns:
        ClaudeCredentials object or None if no valid credentials found.
    """
    # Try keychain first on macOS
    creds_data = _read_from_keychain()

    # Fall back to file-based credentials
    if creds_data is None:
        creds_data = _read_from_file()

    if creds_data is None:
        logger.debug("No Claude credentials found")
        return None

    # Extract OAuth credentials
    oauth = creds_data.get("claudeAiOauth")
    if not oauth:
        logger.debug("No claudeAiOauth in credentials data")
        return None

    access_token = oauth.get("accessToken")
    if not access_token:
        logger.debug("No access token in OAuth credentials")
        return None

    # Get organization UUID from config file
    org_uuid = _read_organization_uuid()

    return ClaudeCredentials(
        access_token=access_token,
        refresh_token=oauth.get("refreshToken"),
        expires_at=oauth.get("expiresAt", 0),
        scopes=oauth.get("scopes", []),
        organization_uuid=org_uuid,
    )


def has_claude_credentials() -> bool:
    """Check if Claude credentials are available.

    This is a quick check that doesn't fully parse the credentials.
    Useful for feature detection without the overhead of full parsing.

    Returns:
        True if credentials appear to be available.
    """
    # Check keychain on macOS
    if sys.platform == "darwin":
        try:
            result = subprocess.run(
                [
                    "security",
                    "find-generic-password",
                    "-s",
                    KEYCHAIN_SERVICE_NAME,
                ],
                capture_output=True,
                timeout=5,
            )
            if result.returncode == 0:
                return True
        except (subprocess.TimeoutExpired, subprocess.SubprocessError) as e:
            logger.debug("Failed to check keychain for Claude credentials: %s", e)

    # Check file-based credentials
    return CLAUDE_CREDENTIALS_FILE.exists()
