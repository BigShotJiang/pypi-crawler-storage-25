"""Cursor Admin API client for token usage enrichment.

Fetches per-request token breakdowns from the Cursor team usage API
and matches them to AgentStream sessions by timestamp window + model.

Day-based caching: API responses are cached by day in /tmp to avoid
redundant requests when processing many sessions in the same time range.
"""

from __future__ import annotations

import asyncio
import contextlib
import json
import logging
import os
import tempfile
from collections.abc import Callable
from datetime import UTC, date, datetime, timedelta

import httpx

from agentstream.enrichment.cache import CacheBackend, FileCache, make_cache_key
from agentstream.normalization.schemas import TokenUsage

logger = logging.getLogger(__name__)

CURSOR_API_BASE = "https://api.cursor.com"
USAGE_ENDPOINT = "/teams/filtered-usage-events"

# Rate limit: 20 RPM on the Cursor API (resets every ~60s)
DEFAULT_TIMEOUT = 10.0
MAX_RETRIES = 2
INITIAL_BACKOFF_S = 30.0
MAX_BACKOFF_S = 60.0
DEFAULT_PAGE_SIZE = 150

CACHE_DIR = os.path.join(tempfile.gettempdir(), "cursor_api_cache")


class CursorUsageClient:
    """Client for the Cursor Admin API usage events endpoint.

    Uses day-based caching to minimize API calls. Each day's events
    are fetched once and cached. Today's events are never cached
    since the day is still accumulating.
    """

    def __init__(
        self,
        api_key: str,
        timeout: float = DEFAULT_TIMEOUT,
        cache: CacheBackend | None = None,
        on_retry: Callable | None = None,
        stop_event: asyncio.Event | None = None,
    ):
        self.api_key = api_key
        self.timeout = timeout
        self._cache: CacheBackend = cache or FileCache(CACHE_DIR)
        self._on_retry = on_retry
        self._stop_event = stop_event
        self._http: httpx.AsyncClient | None = None

    def _headers(self) -> dict[str, str]:
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

    def _get_http_client(self) -> httpx.AsyncClient:
        """Get or create a reusable HTTP client."""
        if self._http is None or self._http.is_closed:
            self._http = httpx.AsyncClient(timeout=self.timeout)
        return self._http

    async def close(self) -> None:
        """Close the HTTP client."""
        if self._http and not self._http.is_closed:
            await self._http.aclose()

    async def fetch_usage_events(
        self,
        start_ms: int,
        end_ms: int,
        page: int = 1,
        page_size: int = DEFAULT_PAGE_SIZE,
    ) -> list[dict] | None:
        """Fetch one page of usage events from the Cursor API.

        Retries on 429 and 5xx with exponential backoff.
        Returns None on errors (no retry for 4xx), empty list for
        genuinely empty responses.
        """
        payload: dict = {
            "startDate": start_ms,
            "endDate": end_ms,
            "page": page,
            "pageSize": page_size,
        }

        # Human-readable date range for log messages
        _start_label = datetime.fromtimestamp(start_ms / 1000, tz=UTC).strftime("%Y-%m-%d")

        client = self._get_http_client()
        backoff = INITIAL_BACKOFF_S
        for attempt in range(MAX_RETRIES + 1):
            try:
                response = await client.post(
                    f"{CURSOR_API_BASE}{USAGE_ENDPOINT}",
                    headers=self._headers(),
                    json=payload,
                )

                if response.status_code == 429 or response.status_code >= 500:
                    if attempt < MAX_RETRIES:
                        logger.warning(
                            f"Cursor API {response.status_code} for {_start_label} "
                            f"page {page}, retrying in {backoff:.0f}s "
                            f"(attempt {attempt + 1}/{MAX_RETRIES})"
                        )
                        if self._on_retry:
                            self._on_retry()
                        await asyncio.sleep(backoff)
                        backoff = min(backoff * 2, MAX_BACKOFF_S)
                        continue
                    logger.warning(
                        f"Cursor API {response.status_code} for {_start_label} "
                        f"page {page} after {MAX_RETRIES} retries, giving up"
                    )
                    return None

                response.raise_for_status()
                data = response.json()
                if isinstance(data, dict):
                    return data.get("usageEvents", data.get("events", []))
                return data

            except httpx.HTTPStatusError as e:
                body = ""
                with contextlib.suppress(Exception):
                    body = e.response.text[:200]
                logger.warning(
                    f"Cursor API error for {_start_label} page {page}: "
                    f"{e.response.status_code} - {body}"
                )
                return None
            except httpx.HTTPError as e:
                logger.warning(f"Cursor API request failed for {_start_label} page {page}: {e}")
                return None

        return None

    async def _fetch_all_pages(
        self,
        start_ms: int,
        end_ms: int,
        page_size: int = DEFAULT_PAGE_SIZE,
    ) -> list[dict] | None:
        """Fetch all pages of usage events for a time window.

        Returns None if any page fetch fails (API error), empty list
        if the API returned no events. If stop_event is set mid-pagination,
        discards partial results and returns None so the day is not cached
        and can be re-fetched on reschedule.
        """
        all_events: list[dict] = []
        page = 1

        while True:
            # Check stop event between pages so long-running pagination
            # can be interrupted promptly on SIGTERM.
            if self._stop_event is not None and self._stop_event.is_set():
                logger.info(
                    f"Cursor API pagination stopped at page {page} "
                    f"({len(all_events)} events so far) — stop event set"
                )
                return None  # Don't cache partial results

            events = await self.fetch_usage_events(start_ms, end_ms, page=page, page_size=page_size)
            if events is None:
                if all_events:
                    logger.warning(
                        f"Cursor API failed on page {page} after fetching "
                        f"{len(all_events)} events from previous pages — discarding partial result"
                    )
                return None  # API error — don't cache
            if not events:
                break  # Empty page — done paginating
            all_events.extend(events)
            logger.debug(f"Cursor API page {page}: {len(events)} events (total: {len(all_events)})")
            if len(events) < page_size:
                break
            # Throttle between pages to stay within 20 RPM
            await asyncio.sleep(3.0)
            page += 1

        return all_events

    async def fetch_day_events(self, day: date, *, skip_cache: bool = False) -> list[dict]:
        """Fetch all events for a single UTC day, using cache if available.

        Today's events are never cached since the day is still accumulating.
        When skip_cache is True, bypass the cache read (but still write after fetching).

        Returns the events list, or empty list on API error (without caching).
        Only non-empty successful results are cached to prevent cache poisoning
        from transient API failures that return 200 with empty data.
        """
        date_str = day.isoformat()
        cache_key = make_cache_key(self.api_key, date_str)

        # Check cache first (never cache today)
        today = datetime.now(UTC).date()
        if day < today and not skip_cache:
            cached = self._cache.read(cache_key)
            if cached:
                logger.debug(f"Cursor API cache hit for {date_str} ({len(cached)} events)")
                return cached
            elif cached is not None:
                # Cached empty list — likely poisoned by a previous API error.
                # Treat as a miss so we re-fetch. If the day is genuinely empty,
                # the re-fetch is a single cheap API call.
                logger.debug(f"Cursor API cache has empty entry for {date_str}, re-fetching")

        # Compute day boundaries in ms (UTC)
        day_start = datetime(day.year, day.month, day.day, tzinfo=UTC)
        start_ms = int(day_start.timestamp() * 1000)
        end_ms = start_ms + 86_400_000  # 24 hours

        events = await self._fetch_all_pages(start_ms, end_ms)

        if events is None:
            if self._stop_event is not None and self._stop_event.is_set():
                # Shutdown interrupted pagination — not an API error
                logger.info(f"Cursor API fetch for {date_str} interrupted by shutdown")
            else:
                logger.warning(f"Cursor API failed for {date_str}, not caching")
            return []

        logger.info(f"Cursor API fetched {len(events)} events for {date_str}")

        # Cache completed days with events only (30-day TTL).
        # Don't cache empty results — an empty day is a single cheap re-fetch,
        # and caching it risks poisoning the cache if the API returned empty
        # due to a transient issue rather than genuinely having no events.
        if day < today and events:
            self._cache.write(cache_key, events, ttl_seconds=30 * 24 * 3600)

        return events

    async def fetch_events_for_range(self, start_ms: int, end_ms: int) -> list[dict]:
        """Fetch events covering a time range using day-based caching.

        Splits the range into UTC days and fetches each day independently,
        using cached data when available. This minimizes API calls when
        processing many sessions in overlapping time ranges.
        """
        # Add 60s buffer for the day calculation (matching match_events_to_session)
        buffer_ms = 60_000
        start_dt = datetime.fromtimestamp((start_ms - buffer_ms) / 1000, tz=UTC)
        end_dt = datetime.fromtimestamp((end_ms + buffer_ms) / 1000, tz=UTC)

        all_events = []
        current = start_dt.date()
        end_date = end_dt.date()

        while current <= end_date:
            day_events = await self.fetch_day_events(current)
            all_events.extend(day_events)
            current += timedelta(days=1)

        return all_events


def match_events_to_session(
    events: list[dict],
    session_start_ms: int,
    session_end_ms: int,
    model: str | None = None,
    email: str | None = None,
) -> list[dict]:
    """Filter API events that fall within the session's time window.

    Args:
        events: Raw usage events from the Cursor API
        session_start_ms: Session start timestamp in milliseconds
        session_end_ms: Session end timestamp in milliseconds
        model: Optional model name to filter by
        email: Optional email for best-effort user filtering

    Returns:
        Events that match the session's time window (and optionally model/email)
    """
    # Add 60s buffer on each side
    buffer_ms = 60_000
    start = session_start_ms - buffer_ms
    end = session_end_ms + buffer_ms

    matched = []
    for event in events:
        event_ts = _get_event_timestamp(event)
        if not (start <= event_ts <= end):
            continue

        if model and model != "cursor":
            event_model = event.get("model", "")
            if event_model and not _models_match(model, event_model):
                continue

        # Best-effort email filtering (GitHub email may differ from Cursor email)
        # Cursor API returns "userEmail", not "email"
        if email:
            event_email = event.get("userEmail", "") or event.get("email", "")
            if event_email and event_email.lower() != email.lower():
                continue

        matched.append(event)

    return matched


def _models_match(session_model: str, api_model: str) -> bool:
    """Check if session model and API model refer to the same model.

    Handles normalization differences like:
    - "claude-4.5-opus" vs "claude-4.5-opus-high-thinking"
    - "gpt-4o" vs "gpt-4o-2024-08-06"
    - "default" always matches (Cursor's generic model name)
    """
    if api_model == "default" or session_model == "default":
        return True

    # Normalize both to lowercase
    s = session_model.lower()
    a = api_model.lower()

    # Exact match
    if s == a:
        return True

    # Prefix match (one is a prefix of the other)
    return s.startswith(a) or a.startswith(s)


def _get_event_timestamp(event: dict) -> int:
    """Extract timestamp in ms from a Cursor API event.

    The API returns timestamps as strings (e.g. "1770166356194").
    """
    raw = event.get("timestamp") or event.get("timestampMs") or 0
    try:
        return int(raw)
    except (ValueError, TypeError):
        return 0


def _get_token_fields(event: dict) -> dict:
    """Extract token usage fields from a Cursor API event.

    Token counts may be nested under a `tokenUsage` key or at the top level.
    """
    token_usage = event.get("tokenUsage")
    if isinstance(token_usage, dict):
        return token_usage
    return event


def aggregate_to_token_usages(matched_events: list[dict]) -> list[TokenUsage]:
    """Convert matched Cursor API events to TokenUsage objects.

    Each API event becomes one TokenUsage (they represent individual API calls).
    """
    usages = []
    for event in matched_events:
        ts_ms = _get_event_timestamp(event)
        timestamp = datetime.fromtimestamp(ts_ms / 1000, tz=UTC) if ts_ms else datetime.now(UTC)

        tokens = _get_token_fields(event)

        usages.append(
            TokenUsage(
                timestamp=timestamp,
                input_tokens=tokens.get("inputTokens", 0),
                output_tokens=tokens.get("outputTokens", 0),
                cache_read_tokens=tokens.get("cacheReadTokens", 0),
                cache_creation_tokens=tokens.get("cacheWriteTokens", 0),
                reasoning_tokens=0,
                model=event.get("model"),
                is_cumulative=False,
            )
        )

    return usages


def get_cursor_api_window(
    metadata: dict,
    source_entries: list[dict],
) -> list[tuple[int, int]]:
    """Compute time windows for matching Cursor API events to a session.

    Returns a list of (start_ms, end_ms) tuples representing windows to query.

    Strategy:
    - For sessions with real bubble timestamps: use min/max(entry_timestamp_ms)
    - For v2/v3 sessions (no bubble timestamps): use metadata createdAt/lastUpdatedAt
    - For long-spanning sessions (>6h): use two narrow windows around
      createdAt and lastUpdatedAt to avoid pulling in unrelated API events
      from other sessions active in between.

    Args:
        metadata: Daemon metadata with optional createdAt/lastUpdatedAt
        source_entries: Source entry dicts with entry_timestamp_ms

    Returns:
        List of (start_ms, end_ms) tuples. Empty list if timestamps unavailable.
    """
    from agentstream.adapters.cursor import entries_lack_bubble_timestamps, parse_cursor_timestamp

    BUFFER_MS = 60_000  # 60s buffer
    SIX_HOURS_MS = 6 * 3600 * 1000

    # Determine if entries have real bubble timestamps
    has_bubble_ts = not entries_lack_bubble_timestamps(source_entries)

    if has_bubble_ts:
        # Use actual entry timestamps (current behavior)
        timestamps = [
            e.get("entry_timestamp_ms", 0)
            for e in source_entries
            if e.get("entry_timestamp_ms", 0) > 0
        ]
        if not timestamps:
            return []
        return [(min(timestamps), max(timestamps))]

    # v2/v3 sessions: use metadata createdAt/lastUpdatedAt
    session_start = parse_cursor_timestamp(metadata.get("createdAt"))
    session_end = parse_cursor_timestamp(metadata.get("lastUpdatedAt"))

    if not session_start or not session_end:
        # Fallback to entry timestamps if metadata timestamps unavailable
        timestamps = [
            e.get("entry_timestamp_ms", 0)
            for e in source_entries
            if e.get("entry_timestamp_ms", 0) > 0
        ]
        if not timestamps:
            return []
        return [(min(timestamps), max(timestamps))]

    if session_start > session_end:
        session_start, session_end = session_end, session_start

    span = session_end - session_start

    if span <= SIX_HOURS_MS:
        # Short session: single window
        return [(session_start, session_end)]

    # Long-spanning session: dual windows to avoid false matches
    # Window 1: around session creation
    w1_start = session_start - BUFFER_MS
    w1_end = session_start + SIX_HOURS_MS

    # Window 2: around recent activity
    w2_start = session_end - SIX_HOURS_MS
    w2_end = session_end + BUFFER_MS

    # Never look before createdAt - BUFFER_MS
    floor = session_start - BUFFER_MS
    w2_start = max(w2_start, floor)

    # If windows overlap, merge into one
    if w1_end >= w2_start:
        return [(w1_start, w2_end)]

    return [(w1_start, w1_end), (w2_start, w2_end)]


def refine_timestamps_from_api_events(
    source_entries: list[dict],
    matched_api_events: list[dict],
) -> list[int] | None:
    """Refine synthetic timestamps using real API event timestamps.

    Each Cursor API event corresponds to one model invocation (roughly one turn).
    A "turn" starts with a user prompt (type=1) followed by one or more assistant
    messages (type=2) — tool calls, intermediate responses, and the final response.

    When the number of turns aligns with the number of API events, we assign the
    API timestamp to the last assistant message of each turn and spread earlier
    assistant messages within the turn using synthetic spacing. User messages are
    placed a few seconds before the first assistant message of their turn.

    Args:
        source_entries: Source entry dicts with entry_content containing bubble type
        matched_api_events: API events matched to this session, each with a timestamp

    Returns:
        List of refined timestamps (one per source entry), or None if alignment fails.
    """
    if not source_entries or not matched_api_events:
        return None

    # Parse bubble types from source entries (skip metadata at index -1)
    bubble_types: list[int] = []
    entry_indices: list[int] = []
    for entry in source_entries:
        idx = entry.get("entry_index", 0)
        if idx < 0:
            continue  # skip metadata entry
        try:
            data = json.loads(entry.get("entry_content", "{}"))
            bubble_types.append(data.get("type", 2))
        except (json.JSONDecodeError, TypeError):
            bubble_types.append(2)
        entry_indices.append(idx)

    if not bubble_types:
        return None

    # Identify turns: each user prompt (type=1) starts a new turn
    # A turn = [user_bubble_pos, asst_bubble_pos, asst_bubble_pos, ...]
    turns: list[dict] = []
    current_turn: dict | None = None
    for pos, btype in enumerate(bubble_types):
        if btype == 1:
            if current_turn is not None:
                turns.append(current_turn)
            current_turn = {"user_pos": pos, "asst_positions": []}
        elif current_turn is not None:
            current_turn["asst_positions"].append(pos)
        # else: assistant before any user prompt — skip
    if current_turn is not None:
        turns.append(current_turn)

    turn_count = len(turns)

    # Sort API events by timestamp
    sorted_api = sorted(matched_api_events, key=lambda e: _get_event_timestamp(e))
    api_count = len(sorted_api)

    if turn_count == 0 or api_count == 0:
        return None

    # Allow alignment when counts are close enough
    # Some turns may not generate API events (e.g., tab completions)
    # Some API events may come from other concurrent sessions
    count_diff = abs(turn_count - api_count)
    if count_diff > max(2, turn_count * 0.3):
        # More than 30% off or more than 2 — too risky
        return None

    # Build output timestamp array (one per bubble, excluding metadata)
    timestamps = [
        entry.get("entry_timestamp_ms", 0)
        for entry in source_entries
        if entry.get("entry_index", 0) >= 0
    ]

    USER_LEAD_MS = 5_000  # User bubble placed 5s before first assistant
    INTRA_TURN_MS = 2_000  # Spacing between assistant messages within a turn

    # Match turns to API events (from start, best-effort)
    match_count = min(turn_count, api_count)

    for j in range(match_count):
        turn = turns[j]
        api_ts = _get_event_timestamp(sorted_api[j])
        if api_ts <= 0:
            continue

        asst_positions = turn["asst_positions"]
        if not asst_positions:
            # Turn with no assistant messages — just place user prompt
            timestamps[turn["user_pos"]] = api_ts - USER_LEAD_MS
            continue

        # Assign API timestamp to the LAST assistant message of the turn
        # (the API event timestamp represents when the model finished)
        last_asst_pos = asst_positions[-1]
        timestamps[last_asst_pos] = api_ts

        # Spread earlier assistant messages backwards from the last one
        for k, asst_pos in enumerate(reversed(asst_positions[:-1])):
            offset = (k + 1) * INTRA_TURN_MS
            timestamps[asst_pos] = api_ts - offset

        # Place user prompt before the first assistant message
        first_asst_ts = timestamps[asst_positions[0]]
        timestamps[turn["user_pos"]] = first_asst_ts - USER_LEAD_MS

    # Return full array mapped back to source_entries (including metadata placeholder)
    # We need to re-insert None/0 for the metadata entry if present
    result: list[int] = []
    bubble_idx = 0
    for entry in source_entries:
        idx = entry.get("entry_index", 0)
        if idx < 0:
            result.append(entry.get("entry_timestamp_ms", 0))
        else:
            result.append(timestamps[bubble_idx])
            bubble_idx += 1

    return result
