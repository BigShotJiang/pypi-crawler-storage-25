"""OpenCode v1.x normalizer."""

import json
from datetime import UTC, datetime

from ..base import BaseNormalizer
from ..schemas import (
    CompactionEvent,
    DiffHunk,
    ErrorEvent,
    SessionMetadata,
    TokenUsage,
    UnifiedDiff,
    UnifiedFileOperation,
    UnifiedGitCommit,
    UnifiedPullRequest,
    UnifiedSkill,
    UnifiedTodo,
)
from .git_patterns import (
    is_git_commit_command,
    is_pr_create_command,
    parse_branch_from_command,
    parse_branch_from_output,
    parse_commit_output,
    parse_pr_number_from_url,
    parse_pr_title_from_command,
    parse_pr_url_from_output,
)


class OpenCodeV1Normalizer(BaseNormalizer):
    """Normalizer for OpenCode v1.x format."""

    # OpenCode tool names for file operations
    FILE_EDIT_TOOLS = {"edit", "Edit", "write", "Write"}
    FILE_WRITE_TOOLS = {"write", "Write"}
    FILE_READ_TOOLS = {"read", "Read"}
    _SHELL_TOOLS = {"bash"}

    def extract_todo(self, event: dict) -> list[UnifiedTodo] | None:
        """Extract todos from OpenCode todowrite tool.

        OpenCode uses a todowrite tool that stores todos in a separate storage.
        The normalizer receives events in this format:
        {
            "tool_name": "todowrite",
            "args": {"todos": [{"content": "...", "status": "...", "id": "..."}]},
            "timestamp_ms": ...,
        }
        """
        tool_name = event.get("tool_name", "").lower()
        if tool_name != "todowrite":
            return None

        args = event.get("args", {})
        todos = args.get("todos", [])

        if not todos:
            return None

        timestamp = datetime.fromtimestamp(event.get("timestamp_ms", 0) / 1000, tz=UTC)

        unified_todos = []
        for todo in todos:
            unified_todos.append(
                UnifiedTodo(
                    content=todo.get("content", ""),
                    status=todo.get("status", "pending"),
                    id=todo.get("id"),
                    timestamp=timestamp,
                    source_tool="todowrite",
                    agent_type="opencode",
                )
            )

        return unified_todos

    def extract_file_operation(self, event: dict) -> UnifiedFileOperation | None:
        """Extract file operations from OpenCode tools."""
        tool_name = event.get("tool_name", "")
        args = event.get("args", {})
        result = event.get("result", {})

        # Determine operation type
        operation = None
        file_path = None
        content = None

        tool_lower = tool_name.lower()

        if tool_lower in ("edit", "write"):
            operation = "edit" if tool_lower == "edit" else "write"
            file_path = args.get("file_path") or args.get("filePath") or args.get("path")
            content = args.get("content")
        elif tool_lower == "read":
            operation = "read"
            file_path = args.get("file_path") or args.get("filePath") or args.get("path")
            # For reads, content comes from result
            if isinstance(result, dict):
                content = result.get("content")
        elif tool_lower in ("glob", "grep"):
            # Search/list operations
            operation = "search" if tool_lower == "grep" else "list"
            file_path = args.get("path") or args.get("pattern")
        elif tool_lower == "bash":
            # Try to detect file operations from shell commands
            cmd = args.get("command", "")
            return self._extract_file_op_from_shell(cmd, event)

        if not operation or not file_path:
            return None

        timestamp = datetime.fromtimestamp(event.get("timestamp_ms", 0) / 1000, tz=UTC)

        return UnifiedFileOperation(
            file_path=file_path,
            operation=operation,
            timestamp=timestamp,
            diff=None,  # Will be populated by extract_diff
            confidence="high",
            agent_type="opencode",
            source_tool=tool_name,
            source_event_id=event.get("event_id", ""),
            content=content,
        )

    def _extract_file_op_from_shell(self, cmd: str, event: dict) -> UnifiedFileOperation | None:
        """Extract file operation from shell command."""
        if not cmd:
            return None

        parts = cmd.split()
        if not parts:
            return None

        shell_cmd = parts[0]
        timestamp = datetime.fromtimestamp(event.get("timestamp_ms", 0) / 1000, tz=UTC)

        # Read operations
        if shell_cmd in ("cat", "head", "tail", "less", "more"):
            for arg in parts[1:]:
                if not arg.startswith("-"):
                    return UnifiedFileOperation(
                        file_path=arg,
                        operation="read",
                        timestamp=timestamp,
                        diff=None,
                        confidence="medium",
                        agent_type="opencode",
                        source_tool="bash",
                        source_event_id=event.get("event_id", ""),
                        content=None,
                    )

        # Search operations
        elif shell_cmd in ("grep", "rg", "ripgrep", "ag"):
            return UnifiedFileOperation(
                file_path="",
                operation="search",
                timestamp=timestamp,
                diff=None,
                confidence="medium",
                agent_type="opencode",
                source_tool="bash",
                source_event_id=event.get("event_id", ""),
                content=None,
            )

        # List operations
        elif shell_cmd in ("ls", "find", "fd", "tree"):
            return UnifiedFileOperation(
                file_path="",
                operation="list",
                timestamp=timestamp,
                diff=None,
                confidence="medium",
                agent_type="opencode",
                source_tool="bash",
                source_event_id=event.get("event_id", ""),
                content=None,
            )

        return None

    def extract_skill(self, event: dict) -> UnifiedSkill | None:
        """Extract skill activations from OpenCode skill tool."""
        tool_name = event.get("tool_name", "").lower()
        if tool_name != "skill":
            return None

        args = event.get("args", {})
        skill_name = args.get("name") or args.get("skill")

        if not skill_name:
            return None

        timestamp = datetime.fromtimestamp(event.get("timestamp_ms", 0) / 1000, tz=UTC)

        return UnifiedSkill(
            name=skill_name,
            method="tool",
            skill_type="tool",
            timestamp=timestamp,
            agent_type="opencode",
            source_event_id=event.get("event_id", ""),
            args=args.get("args"),
        )

    def extract_diff(self, event: dict, session) -> UnifiedDiff | None:
        """Extract diff from OpenCode edit/write operations.

        OpenCode stores patch information in the tool result metadata.
        """
        tool_name = event.get("tool_name", "").lower()

        if tool_name not in ("edit", "write"):
            return None

        result = event.get("result", {})
        if not isinstance(result, dict):
            return None

        # Check for patch/diff data in metadata
        metadata = result.get("metadata", {})
        patch_data = metadata.get("patch") or metadata.get("diff")

        if patch_data and isinstance(patch_data, dict):
            hunks_data = patch_data.get("hunks", [])
            if hunks_data:
                hunks = []
                lines_added = []
                lines_modified = []

                for hunk_data in hunks_data:
                    hunk = DiffHunk(
                        old_start=hunk_data.get("old_start", 1),
                        old_count=hunk_data.get("old_count", 0),
                        new_start=hunk_data.get("new_start", 1),
                        new_count=hunk_data.get("new_count", 0),
                        lines=hunk_data.get("lines", []),
                    )
                    hunks.append(hunk)

                    # Calculate line numbers
                    current_line = hunk.new_start
                    for line in hunk.lines:
                        if line.startswith("+"):
                            lines_added.append(current_line)
                            current_line += 1
                        elif line.startswith("-"):
                            pass  # Deletion
                        else:
                            current_line += 1

                return UnifiedDiff(
                    hunks=hunks,
                    format_source="opencode_patch",
                    confidence="high",
                    lines_added=lines_added,
                    lines_modified=lines_modified,
                )

        # Try to compute diff from old_string/new_string if available
        old_string = event.get("args", {}).get("oldString") or event.get("args", {}).get(
            "old_string"
        )
        new_string = event.get("args", {}).get("newString") or event.get("args", {}).get(
            "new_string"
        )

        if old_string is not None and new_string is not None:
            return self._compute_diff_from_strings(old_string, new_string)

        return None

    def _compute_diff_from_strings(self, old_string: str, new_string: str) -> UnifiedDiff:
        """Compute a diff from old and new strings."""
        import difflib

        old_lines = old_string.splitlines(keepends=True)
        new_lines = new_string.splitlines(keepends=True)

        diff = list(difflib.unified_diff(old_lines, new_lines, lineterm="", n=3))

        hunks = []
        lines_added = []
        current_hunk_lines = []
        old_start = 0
        new_start = 0
        old_count = 0
        new_count = 0

        for line in diff:
            if line.startswith("---") or line.startswith("+++"):
                continue

            if line.startswith("@@"):
                if current_hunk_lines:
                    hunks.append(
                        DiffHunk(
                            old_start=old_start,
                            old_count=old_count,
                            new_start=new_start,
                            new_count=new_count,
                            lines=current_hunk_lines,
                        )
                    )
                    current_hunk_lines = []

                # Parse hunk header
                parts = line.split()
                if len(parts) >= 3:
                    old_range = parts[1][1:]
                    new_range = parts[2][1:]

                    if "," in old_range:
                        old_start, old_count = map(int, old_range.split(","))
                    else:
                        old_start, old_count = int(old_range), 1

                    if "," in new_range:
                        new_start, new_count = map(int, new_range.split(","))
                    else:
                        new_start, new_count = int(new_range), 1

                continue

            current_hunk_lines.append(line)

        if current_hunk_lines:
            hunks.append(
                DiffHunk(
                    old_start=old_start,
                    old_count=old_count,
                    new_start=new_start,
                    new_count=new_count,
                    lines=current_hunk_lines,
                )
            )

        # Calculate line numbers for additions
        for hunk in hunks:
            current_line = hunk.new_start
            for line in hunk.lines:
                if line.startswith("+"):
                    lines_added.append(current_line)
                    current_line += 1
                elif not line.startswith("-"):
                    current_line += 1

        return UnifiedDiff(
            hunks=hunks,
            format_source="computed",
            confidence="medium",
            lines_added=lines_added,
            lines_modified=[],
        )

    def extract_session_metadata(
        self,
        source_entries: list[dict],
        daemon_metadata: dict | None = None,
    ) -> SessionMetadata | None:
        """Extract session metadata from source entries.

        OpenCode stores session metadata in JSON files with this structure:
        {
            "id": "ses_xxx",
            "projectID": "xxx",
            "directory": "/path/to/project",
            "version": "1.0.0",
            "time": {"created": 123456789, "updated": 123456789}
        }

        Args:
            source_entries: List of source entry dicts with entry_content, entry_timestamp_ms
            daemon_metadata: Optional dict with git_commit, git_repo

        Returns:
            SessionMetadata extracted from first entry + daemon metadata, or None
        """
        if not source_entries:
            return None

        # First entry should be the session data
        first_entry = json.loads(source_entries[0]["entry_content"])
        timestamp = datetime.fromtimestamp(source_entries[0]["entry_timestamp_ms"] / 1000, tz=UTC)

        # Check if this is a session entry (has projectID/project_id and directory but no role)
        # SQLite backend uses snake_case (project_id), legacy JSON uses camelCase (projectID)
        if (
            "projectID" not in first_entry and "project_id" not in first_entry
        ) or "role" in first_entry:
            # Not a session entry, might be a message
            return None

        cwd = first_entry.get("directory")
        agent_version = first_entry.get("version")

        # Find model from message entries
        primary_model = None
        for entry in source_entries:
            try:
                parsed = json.loads(entry["entry_content"])
                if parsed.get("role") == "assistant":
                    model_id = parsed.get("modelID")
                    provider_id = parsed.get("providerID")
                    if model_id:
                        primary_model = f"{provider_id}/{model_id}" if provider_id else model_id
                        break
                elif parsed.get("role") == "user":
                    model_info = parsed.get("model", {})
                    if model_info:
                        provider_id = model_info.get("providerID", "")
                        model_id = model_info.get("modelID", "")
                        if model_id:
                            primary_model = f"{provider_id}/{model_id}" if provider_id else model_id
                            break
            except (json.JSONDecodeError, KeyError):
                continue

        # Fall back to daemon_metadata.model if not found in source entries
        if not primary_model and daemon_metadata:
            primary_model = daemon_metadata.get("model") or ""

        return SessionMetadata(
            cwd=cwd,
            agent_type="opencode",
            agent_version=agent_version,
            git_branch=daemon_metadata.get("git_branch") if daemon_metadata else None,
            git_commit=daemon_metadata.get("git_commit") if daemon_metadata else None,
            git_repo=daemon_metadata.get("git_repo") if daemon_metadata else None,
            # Never return None - ClickHouse LowCardinality(String) doesn't accept None
            primary_model=primary_model or "",
            timestamp=timestamp,
        )

    def extract_token_usage(self, source_entry: dict) -> list[TokenUsage]:
        """Extract token usage from a single source entry.

        OpenCode stores token usage in assistant message entries:
        {
            "role": "assistant",
            "tokens": {
                "input": 100,
                "output": 50,
                "reasoning": 0,
                "cache": {"read": 0, "write": 0}
            },
            "cost": 0.001
        }

        Args:
            source_entry: Parsed source entry dict (already JSON loaded)

        Returns:
            List of TokenUsage instances (empty if no usage found)
        """
        if source_entry.get("role") != "assistant":
            return []

        tokens = source_entry.get("tokens")
        if not tokens or not isinstance(tokens, dict):
            return []

        timestamp = datetime.fromtimestamp(source_entry.get("_timestamp_ms", 0) / 1000, tz=UTC)

        cache = tokens.get("cache", {})
        if not isinstance(cache, dict):
            cache = {}

        provider_id = source_entry.get("providerID", "")
        model_id = source_entry.get("modelID", "")
        model = f"{provider_id}/{model_id}".strip("/") or None

        # Extract agent-provided cost if available
        cost_usd = source_entry.get("cost")
        if cost_usd is not None:
            try:
                cost_usd = float(cost_usd)
            except (ValueError, TypeError):
                cost_usd = None

        return [
            TokenUsage(
                input_tokens=tokens.get("input", 0),
                output_tokens=tokens.get("output", 0),
                cache_read_tokens=cache.get("read", 0),
                cache_creation_tokens=cache.get("write", 0),
                reasoning_tokens=tokens.get("reasoning", 0),
                model=model,
                timestamp=timestamp,
                is_cumulative=False,
                cost_usd=cost_usd,
            )
        ]

    def extract_error(self, source_entry: dict) -> ErrorEvent | None:
        """Extract error event from a single source entry.

        OpenCode stores errors in assistant message entries:
        {
            "role": "assistant",
            "error": {
                "name": "APIError",
                "message": "Error details"
            }
        }

        Args:
            source_entry: Parsed source entry dict (already JSON loaded)

        Returns:
            ErrorEvent if error found, else None
        """
        if source_entry.get("role") != "assistant":
            return None

        error = source_entry.get("error")
        if not error or not isinstance(error, dict):
            return None

        timestamp = datetime.fromtimestamp(source_entry.get("_timestamp_ms", 0) / 1000, tz=UTC)

        error_name = error.get("name", "UnknownError")
        error_message = error.get("message", str(error))

        # Map error names to types
        error_type = "tool_call_error"
        if "Auth" in error_name:
            error_type = "authentication"
        elif "Rate" in error_name or "Limit" in error_name:
            error_type = "rate_limit"
        elif "Abort" in error_name:
            error_type = "interruption"
        elif "API" in error_name:
            error_type = "api_error"

        return ErrorEvent(
            error_type=error_type,
            message=error_message,
            tool_name=None,
            tool_call_id=None,
            details=error,
            timestamp=timestamp,
        )

    @staticmethod
    def _extract_shell_command(args: dict[str, object]) -> str:
        for key in ("command", "cmd", "input"):
            value = args.get(key)
            if isinstance(value, list):
                return " ".join(str(v) for v in value)
            if isinstance(value, str) and value:
                return value
        return ""

    @staticmethod
    def _extract_output_text(result: object) -> str:
        if isinstance(result, str):
            return result
        if isinstance(result, dict):
            result_dict = {str(k): v for k, v in result.items()}
            for key in ("output", "stdout", "content", "message", "result"):
                value = result_dict.get(key)
                if isinstance(value, str) and value:
                    return value
                nested = OpenCodeV1Normalizer._extract_output_text(value)
                if nested:
                    return nested
        if isinstance(result, list):
            for item in result:
                nested = OpenCodeV1Normalizer._extract_output_text(item)
                if nested:
                    return nested
        return ""

    def extract_git_commit(
        self, event: dict, git_state: dict[str, object]
    ) -> UnifiedGitCommit | None:
        """Extract git commit from OpenCode bash tool."""
        tool_name = (event.get("tool_name") or "").strip()
        if tool_name not in self._SHELL_TOOLS:
            return None

        args = event.get("args", {})
        if not isinstance(args, dict):
            return None
        cmd = self._extract_shell_command(args)
        if not cmd:
            return None

        output = self._extract_output_text(event.get("result", {}))

        branch = parse_branch_from_command(cmd)
        if not branch and output:
            branch = parse_branch_from_output(output)
        if branch:
            git_state["branch"] = branch

        if not is_git_commit_command(cmd):
            return None

        timestamp = datetime.fromtimestamp(event.get("timestamp_ms", 0) / 1000, tz=UTC)

        commit_branch = None
        commit_hash = None
        commit_message = None
        if output:
            parsed = parse_commit_output(output)
            if parsed:
                commit_branch, commit_hash, commit_message = parsed

        resolved_branch = commit_branch or git_state.get("branch") or "unknown"

        return UnifiedGitCommit(
            branch=str(resolved_branch),
            timestamp=timestamp,
            agent_type="opencode",
            source_tool=tool_name,
            source_event_id=event.get("event_id", ""),
            commit_hash=commit_hash,
            message=commit_message,
        )

    def extract_pr(self, event: dict, git_state: dict[str, object]) -> UnifiedPullRequest | None:
        """Extract PR creation from OpenCode bash tool."""
        tool_name = (event.get("tool_name") or "").strip()
        if tool_name not in self._SHELL_TOOLS:
            return None

        args = event.get("args", {})
        if not isinstance(args, dict):
            return None
        cmd = self._extract_shell_command(args)
        if not cmd or not is_pr_create_command(cmd):
            return None

        output = self._extract_output_text(event.get("result", {}))
        pr_url = parse_pr_url_from_output(output)
        if not pr_url:
            return None

        timestamp = datetime.fromtimestamp(event.get("timestamp_ms", 0) / 1000, tz=UTC)
        branch = git_state.get("branch") or "unknown"

        return UnifiedPullRequest(
            url=pr_url,
            branch=str(branch),
            timestamp=timestamp,
            agent_type="opencode",
            source_tool=tool_name,
            source_event_id=event.get("event_id", ""),
            number=parse_pr_number_from_url(pr_url),
            title=parse_pr_title_from_command(cmd),
        )

    def extract_compaction(self, source_entries: list[dict]) -> list[CompactionEvent]:
        """Extract compaction events from source entries.

        OpenCode can store compaction markers in message parts.

        Args:
            source_entries: All raw source entries for the session

        Returns:
            List of CompactionEvent objects (empty if none detected)
        """
        compactions = []

        for entry_dict in source_entries:
            try:
                entry = json.loads(entry_dict["entry_content"])
            except (json.JSONDecodeError, KeyError):
                continue

            # Check for compaction part type
            if entry.get("type") == "compaction":
                timestamp = datetime.fromtimestamp(
                    entry_dict.get("entry_timestamp_ms", 0) / 1000, tz=UTC
                )
                compactions.append(
                    CompactionEvent(
                        compaction_type="auto_summarization" if entry.get("auto") else "manual",
                        timestamp=timestamp,
                        message_id=entry.get("messageID"),
                    )
                )

        return compactions
