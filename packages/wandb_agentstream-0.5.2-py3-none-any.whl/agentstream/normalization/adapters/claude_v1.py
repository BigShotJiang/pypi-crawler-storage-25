"""Claude v1.x normalizer."""

import json
import re
from datetime import UTC, datetime
from typing import Any

from ..base import BaseNormalizer, compute_diff_from_content
from ..file_state import FileSystemState
from ..schemas import (
    CompactionEvent,
    DiffHunk,
    ErrorEvent,
    SessionMetadata,
    TokenUsage,
    UnifiedDiff,
    UnifiedFileOperation,
    UnifiedGitCommit,
    UnifiedPullRequest,
    UnifiedSkill,
    UnifiedTodo,
)
from .git_patterns import (
    is_git_commit_command,
    is_pr_create_command,
    parse_branch_from_command,
    parse_branch_from_output,
    parse_commit_output,
    parse_pr_number_from_url,
    parse_pr_title_from_command,
    parse_pr_url_from_output,
)


class ClaudeV1Normalizer(BaseNormalizer):
    """Normalizer for Claude v1.x format."""

    FILE_EDIT_TOOLS = {"Edit", "Patch", "Replace", "MultiEdit"}
    FILE_WRITE_TOOLS = {"Write", "Create"}
    FILE_READ_TOOLS = {"Read", "View", "Cat"}

    def extract_todo(self, event: dict) -> list[UnifiedTodo] | None:
        """Extract todos from Claude TodoWrite tool.

        The normalizer receives events in this format:
        {
            "tool_name": "TodoWrite",
            "args": {"todos": [{"content": "...", "status": "...", ...}]},
            "timestamp_ms": ...,
        }

        The todos array comes from the tool's delta/args, not from a result.
        """
        if event.get("tool_name") != "TodoWrite":
            return None

        # Todos are in args (from delta), not result
        args = event.get("args", {})
        todos = args.get("todos", [])

        if not todos:
            return None

        timestamp = datetime.fromtimestamp(event.get("timestamp_ms", 0) / 1000, tz=UTC)

        unified_todos = []
        for todo in todos:
            unified_todos.append(
                UnifiedTodo(
                    content=todo.get("content", ""),
                    status=todo.get("status", "pending"),
                    id=todo.get("id"),
                    timestamp=timestamp,
                    source_tool="TodoWrite",
                    agent_type="claude",
                )
            )

        return unified_todos

    def _extract_write_content(self, args: dict) -> str | None:
        """Extract content from Write/Create tool args.

        Handles both plain string content and list-of-blocks API format.
        """
        raw_content = args.get("content")
        if isinstance(raw_content, list):
            text_parts = []
            for block in raw_content:
                if isinstance(block, dict):
                    text_parts.append(block.get("text", ""))
                elif isinstance(block, str):
                    text_parts.append(block)
            return "\n".join(text_parts)
        elif raw_content is not None:
            return str(raw_content)
        return None

    def extract_file_operation(self, event: dict) -> UnifiedFileOperation | None:
        """Extract file operations from Claude tools."""
        tool_name = event.get("tool_name")
        args = event.get("args", {})
        result = event.get("result", {})

        # Determine operation type
        operation = None
        file_path = None
        content = None

        if tool_name in self.FILE_EDIT_TOOLS:
            operation = "edit"
            file_path = args.get("file_path")
            # For edits, content comes from result (the new content after edit)
            # Claude Edit tool doesn't return full content, so leave None
        elif tool_name in self.FILE_WRITE_TOOLS:
            operation = "write"
            file_path = args.get("file_path")
            content = self._extract_write_content(args)
        elif tool_name in self.FILE_READ_TOOLS:
            operation = "read"
            file_path = args.get("file_path")
            # For reads, content comes from result
            # Result format: {"content": "file contents with line numbers..."}
            if isinstance(result, dict):
                raw_content = result.get("content", "")
                # Strip line numbers (format: "    1→content\n    2→more...")
                if raw_content:
                    content = self._strip_line_numbers(raw_content)

        if not operation or not file_path or not tool_name:
            return None

        timestamp = datetime.fromtimestamp(event.get("timestamp_ms", 0) / 1000)

        return UnifiedFileOperation(
            file_path=file_path,
            operation=operation,
            timestamp=timestamp,
            diff=None,  # Will be populated by extract_diff
            confidence="high",
            agent_type="claude",
            source_tool=tool_name,
            source_event_id=event.get("event_id", ""),
            content=content,
        )

    def _strip_line_numbers(self, content: str | list) -> str:
        """Strip line number prefixes and system reminders from Read tool output.

        Claude Read tool returns content with line numbers like:
        "     1→content line 1\\n     2→content line 2\\n..."

        It may also include <system-reminder> tags at the end which should be stripped.

        This extracts just the content without line numbers or system reminders.

        Args:
            content: String content, or list of content blocks (API format)
        """
        if not content:
            return ""

        # Handle list of content blocks (API format) - extract text from each block
        if isinstance(content, list):
            text_parts = []
            for block in content:
                if isinstance(block, dict):
                    text_parts.append(block.get("text", ""))
                elif isinstance(block, str):
                    text_parts.append(block)
            content = "\n".join(text_parts)

        # Ensure content is a string
        if not isinstance(content, str):
            content = str(content)

        # First strip any <system-reminder> tags and their content
        content = self._strip_system_reminders(content)

        lines = []
        for line in content.split("\n"):
            # Line format: "    N→content" where N is line number
            # The arrow is U+2192 (→)
            if "→" in line:
                # Split on first arrow and take everything after
                parts = line.split("→", 1)
                if len(parts) > 1:
                    lines.append(parts[1])
                else:
                    lines.append("")
            else:
                # No arrow - might be empty line or different format
                lines.append(line)

        return "\n".join(lines)

    def _strip_system_reminders(self, content: str) -> str:
        """Strip <system-reminder> tags and their content from text.

        These tags are injected by Claude's tools and should not be stored
        as part of file content.
        """
        # Remove all <system-reminder>...</system-reminder> blocks
        # Use DOTALL to match across newlines
        pattern = r"<system-reminder>.*?</system-reminder>"
        return re.sub(pattern, "", content, flags=re.DOTALL).rstrip()

    def extract_skill(self, event: dict) -> UnifiedSkill | None:
        """Extract skill activations from Claude Skill tool."""
        if event.get("tool_name") != "Skill":
            return None

        args = event.get("args", {})
        skill_name = args.get("skill")

        if not skill_name:
            return None

        timestamp = datetime.fromtimestamp(event.get("timestamp_ms", 0) / 1000)

        return UnifiedSkill(
            name=skill_name,
            method="tool",
            skill_type="tool",
            timestamp=timestamp,
            agent_type="claude",
            source_event_id=event.get("event_id", ""),
            args=args.get("args"),
        )

    def extract_diff(self, event: dict, session) -> UnifiedDiff | None:
        """Extract diff from Claude tool events.

        Handles three cases:
        1. Edit tools with structured_patch (highest confidence)
        2. Read tools - populate FileSystemState for future diffs
        3. Write/Create tools - compute diff from content
        """
        tool_name = event.get("tool_name")
        args = event.get("args", {})
        result = event.get("result", {})

        # Case 1: structured_patch from Edit tools (existing behavior)
        if isinstance(result, dict):
            structured_patch = result.get("structured_patch")
            if structured_patch:
                hunks_data = structured_patch.get("hunks", [])
                if hunks_data:
                    hunks = []
                    lines_added = []
                    lines_modified = []

                    for hunk_data in hunks_data:
                        hunk = DiffHunk(
                            old_start=hunk_data["old_start"],
                            old_count=hunk_data["old_count"],
                            new_start=hunk_data["new_start"],
                            new_count=hunk_data["new_count"],
                            lines=hunk_data["lines"],
                        )
                        hunks.append(hunk)

                        current_line = hunk.new_start
                        for line in hunk.lines:
                            if line.startswith("+"):
                                lines_added.append(current_line)
                                current_line += 1
                            elif line.startswith("-"):
                                pass
                            else:
                                current_line += 1

                    return UnifiedDiff(
                        hunks=hunks,
                        format_source="structured_patch",
                        confidence="high",
                        lines_added=lines_added,
                        lines_modified=lines_modified,
                    )

        # Case 2: Read tools - populate FileSystemState for future diffs
        if tool_name in self.FILE_READ_TOOLS:
            file_path = args.get("file_path")
            if file_path and isinstance(session, FileSystemState) and isinstance(result, dict):
                raw_content = result.get("content", "")
                if raw_content:
                    content = self._strip_line_numbers(raw_content)
                    session.set_content(file_path, content)
            return None

        # Case 3: Write/Create tools - compute diff from content
        if tool_name in self.FILE_WRITE_TOOLS:
            file_path = args.get("file_path")
            if not file_path:
                return None

            new_content = self._extract_write_content(args)
            if new_content is None:
                return None

            # Get old content from FileSystemState if available
            old_content = ""
            if isinstance(session, FileSystemState):
                old_content = session.get_content(file_path) or ""
                session.set_content(file_path, new_content)

            # Skip diff if both old and new are empty
            if not old_content and not new_content:
                return None

            return compute_diff_from_content(old_content, new_content)

        return None

    def extract_session_metadata(
        self,
        source_entries: list[dict],
        daemon_metadata: dict | None = None,
    ) -> SessionMetadata | None:
        """Extract session metadata from source entries.

        Claude sessions can start with entries like 'file-history-snapshot' or 'summary'
        that don't contain session metadata (cwd, gitBranch, version). We scan through
        the first 10 entries to find one with metadata.

        Args:
            source_entries: List of source entry dicts with entry_content, entry_timestamp_ms
            daemon_metadata: Optional dict with git_commit, git_repo

        Returns:
            SessionMetadata extracted from entries + daemon metadata, or None
        """
        if not source_entries:
            return None

        timestamp = datetime.fromtimestamp(source_entries[0]["entry_timestamp_ms"] / 1000, tz=UTC)

        # Extract cwd, gitBranch, version from first entry that has them
        # (first entry might be summary/file-history-snapshot which has no metadata)
        cwd = None
        git_branch = None
        agent_version = None
        max_scan = min(10, len(source_entries))

        for entry_dict in source_entries[:max_scan]:
            try:
                entry = json.loads(entry_dict["entry_content"])
                # Look for entries with cwd (indicates a message entry with metadata)
                if entry.get("cwd") and not cwd:
                    cwd = entry.get("cwd")
                    git_branch = entry.get("gitBranch")
                    agent_version = entry.get("version")
                    break
            except (json.JSONDecodeError, KeyError):
                continue

        # Extract primary_model from first assistant message with a model field
        primary_model = None
        for entry_dict in source_entries:
            try:
                entry = json.loads(entry_dict["entry_content"])
                if entry.get("type") == "assistant":
                    model = entry.get("message", {}).get("model")
                    if model:
                        primary_model = model
                        break
            except (json.JSONDecodeError, KeyError):
                continue

        # Fall back to daemon_metadata.model if not found in source entries
        if not primary_model and daemon_metadata:
            primary_model = daemon_metadata.get("model") or ""

        return SessionMetadata(
            cwd=cwd,
            agent_type="claude",
            agent_version=agent_version,
            git_branch=git_branch,
            git_commit=daemon_metadata.get("git_commit") if daemon_metadata else None,
            git_repo=daemon_metadata.get("git_repo") if daemon_metadata else None,
            # Never return None - ClickHouse LowCardinality(String) doesn't accept None
            primary_model=primary_model or "",
            timestamp=timestamp,
        )

    def extract_token_usage(self, source_entry: dict) -> list[TokenUsage]:
        """Extract token usage from a single source entry.

        Args:
            source_entry: Parsed source entry dict (already JSON loaded)

        Returns:
            List of TokenUsage instances (empty if no usage found)
        """
        if source_entry.get("type") != "assistant":
            return []

        message = source_entry.get("message", {})
        usage = message.get("usage")
        if not usage:
            return []

        timestamp = datetime.fromtimestamp(source_entry.get("_timestamp_ms", 0) / 1000, tz=UTC)

        return [
            TokenUsage(
                input_tokens=usage.get("input_tokens", 0),
                output_tokens=usage.get("output_tokens", 0),
                cache_read_tokens=usage.get("cache_read_input_tokens", 0),
                cache_creation_tokens=usage.get("cache_creation_input_tokens", 0),
                reasoning_tokens=usage.get("reasoning_tokens", 0),
                model=message.get("model"),
                timestamp=timestamp,
                is_cumulative=False,
            )
        ]

    def get_token_usage_group_key(self, source_entry: dict) -> str | None:
        """Return message.id for deduplicating Claude streaming chunks.

        Claude sends multiple streaming chunks per API call, each with the
        same cumulative usage. Grouping by message.id keeps only the last chunk.
        """
        if source_entry.get("type") != "assistant":
            return None
        message = source_entry.get("message", {})
        return message.get("id") or None

    def extract_error(self, source_entry: dict) -> ErrorEvent | None:
        """Extract error event from a single source entry.

        Args:
            source_entry: Parsed source entry dict (already JSON loaded)

        Returns:
            ErrorEvent if error found, else None
        """
        if source_entry.get("type") != "assistant":
            return None

        message = source_entry.get("message", {})
        content = message.get("content", [])

        for block in content:
            if block.get("type") == "tool_result" and block.get("is_error"):
                timestamp = datetime.fromtimestamp(
                    source_entry.get("_timestamp_ms", 0) / 1000, tz=UTC
                )
                return ErrorEvent(
                    error_type="tool_call_error",
                    message=str(block.get("content", "")),
                    tool_name=None,  # Not available in tool_result
                    tool_call_id=block.get("tool_use_id"),
                    details=None,
                    timestamp=timestamp,
                )

        return None

    # Text pattern for fallback detection (older Claude versions)
    COMPACTION_TEXT_PATTERN = (
        "This session is being continued from a previous conversation that ran out of context"
    )

    def extract_compaction(self, source_entries: list[dict]) -> list[CompactionEvent]:
        """Extract compaction events from source entries.

        Detection priority:
        1. isCompactSummary == True (metadata flag, preferred)
        2. Text pattern match (fallback for older versions)

        Args:
            source_entries: All raw source entries for the session

        Returns:
            List of CompactionEvent objects (empty if none detected)
        """
        compactions = []

        for entry_dict in source_entries:
            try:
                entry = json.loads(entry_dict["entry_content"])
            except (json.JSONDecodeError, KeyError):
                continue

            if entry.get("type") != "user":
                continue

            is_compaction = False

            # Primary: Check metadata flag (most reliable)
            if entry.get("isCompactSummary") is True:
                is_compaction = True
            else:
                # Fallback: Check text pattern for older Claude versions
                message = entry.get("message", {})
                content = message.get("content", "")

                if isinstance(content, str):
                    if content.startswith(self.COMPACTION_TEXT_PATTERN):
                        is_compaction = True
                elif isinstance(content, list):
                    # Array of content blocks
                    for block in content:
                        if isinstance(block, dict):
                            text = block.get("text", "")
                            if isinstance(text, str) and text.startswith(
                                self.COMPACTION_TEXT_PATTERN
                            ):
                                is_compaction = True
                                break

            if is_compaction:
                timestamp = datetime.fromtimestamp(
                    entry_dict.get("entry_timestamp_ms", 0) / 1000, tz=UTC
                )
                compactions.append(
                    CompactionEvent(
                        compaction_type="auto_summarization",
                        timestamp=timestamp,
                        message_id=entry.get("uuid"),
                    )
                )

        return compactions

    def extract_git_commit(self, event: dict, git_state: dict[str, Any]) -> UnifiedGitCommit | None:
        """Extract git commit from Claude Bash tool events."""
        if event.get("tool_name") != "Bash":
            return None

        args = event.get("args", {})
        cmd = args.get("command", "")
        if not cmd:
            return None

        # Get output from result (plain text string for Claude)
        result = event.get("result", {})
        output = ""
        if isinstance(result, str):
            output = result
        elif isinstance(result, dict):
            output = result.get("content", "") or result.get("output", "")

        # Update branch state from checkout/switch commands
        branch = parse_branch_from_command(cmd)
        if not branch and output:
            branch = parse_branch_from_output(output)
        if branch:
            git_state["branch"] = branch

        # Detect git commit
        if not is_git_commit_command(cmd):
            return None

        timestamp = datetime.fromtimestamp(event.get("timestamp_ms", 0) / 1000, tz=UTC)

        # Try to parse branch/hash/message from commit output
        commit_branch = None
        commit_hash = None
        commit_message = None
        if output:
            parsed = parse_commit_output(output)
            if parsed:
                commit_branch, commit_hash, commit_message = parsed

        # Resolve branch: commit output > tracked state > unknown
        resolved_branch = commit_branch or git_state.get("branch") or "unknown"

        return UnifiedGitCommit(
            branch=resolved_branch,
            timestamp=timestamp,
            agent_type="claude",
            source_tool="Bash",
            source_event_id=event.get("event_id", ""),
            commit_hash=commit_hash,
            message=commit_message,
        )

    def extract_pr(self, event: dict, git_state: dict[str, Any]) -> UnifiedPullRequest | None:
        """Extract PR creation from Claude Bash tool events."""
        if event.get("tool_name") != "Bash":
            return None

        args = event.get("args", {})
        cmd = args.get("command", "")
        if not cmd or not is_pr_create_command(cmd):
            return None

        # Get output from result
        result = event.get("result", {})
        output = ""
        if isinstance(result, str):
            output = result
        elif isinstance(result, dict):
            output = result.get("content", "") or result.get("output", "")

        pr_url = parse_pr_url_from_output(output)
        if not pr_url:
            return None

        timestamp = datetime.fromtimestamp(event.get("timestamp_ms", 0) / 1000, tz=UTC)
        branch = git_state.get("branch") or "unknown"

        return UnifiedPullRequest(
            url=pr_url,
            branch=branch,
            timestamp=timestamp,
            agent_type="claude",
            source_tool="Bash",
            source_event_id=event.get("event_id", ""),
            number=parse_pr_number_from_url(pr_url),
            title=parse_pr_title_from_command(cmd),
        )
