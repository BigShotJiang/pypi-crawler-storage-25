"""Cursor v1.x normalizer."""

import contextlib
import json
from datetime import UTC, datetime

from ..base import BaseNormalizer, compute_diff_from_content
from ..file_state import FileSystemState
from ..schemas import (
    CompactionEvent,
    DiffHunk,
    ErrorEvent,
    SessionMetadata,
    TokenUsage,
    UnifiedDiff,
    UnifiedFileOperation,
    UnifiedGitCommit,
    UnifiedSkill,
    UnifiedTodo,
)
from .git_patterns import (
    is_git_commit_command,
    parse_branch_from_command,
    parse_branch_from_output,
    parse_commit_output,
)


class CursorV1Normalizer(BaseNormalizer):
    """Normalizer for Cursor v1.x format."""

    # Old format tools (2024)
    FILE_EDIT_TOOLS = {"edit_file_v2", "apply_edit", "replace_in_file", "str_replace_editor"}
    FILE_WRITE_TOOLS = {"write_file", "create_file", "save_file"}
    FILE_READ_TOOLS = {"read_file_v2", "view_file", "get_file_contents"}

    # New format tools (2026+) - these provide diff.chunks in results
    NEW_FORMAT_WRITE_TOOLS = {"write", "search_replace"}
    NEW_FORMAT_EDIT_TOOLS = {
        "edit_file"
    }  # edit_file (not edit_file_v2) uses new diff.chunks format
    _SHELL_TOOLS = {"run_terminal_cmd", "run_terminal_command_v2"}

    def supports_api_enrichment(self) -> bool:
        """Cursor supports token enrichment via the Admin API."""
        return True

    def extract_todo(self, event: dict) -> list[UnifiedTodo] | None:
        """Extract todos from Cursor todo_write tool."""
        if event.get("tool_name") != "todo_write":
            return None

        result = event.get("result", {})
        final_todos = result.get("finalTodos", [])

        if not final_todos:
            return None

        timestamp = datetime.fromtimestamp(event.get("timestamp_ms", 0) / 1000)

        unified_todos = []
        for todo in final_todos:
            unified_todos.append(
                UnifiedTodo(
                    content=todo.get("content", ""),
                    status=todo.get("status", "pending"),
                    id=todo.get("id"),  # Cursor has string IDs
                    timestamp=timestamp,
                    source_tool="todo_write",
                    agent_type="cursor",
                )
            )

        return unified_todos

    def extract_file_operation(self, event: dict) -> UnifiedFileOperation | None:
        """Extract file operations from Cursor tools.

        Handles both old format (edit_file_v2) and new format (write, search_replace).
        """
        tool_name = event.get("tool_name")
        args = event.get("args", {})
        result = event.get("result", {})

        # Determine operation and file path
        operation = None
        file_path = None
        content = None

        # New format tools (2026+) - write, search_replace, and edit_file provide diff.chunks
        if tool_name in self.NEW_FORMAT_WRITE_TOOLS:
            operation = "write" if tool_name == "write" else "edit"
            file_path = args.get("relativeWorkspacePath") or args.get("targetFile")
            # New format may have contentsAfterEdit
            content = result.get("contentsAfterEdit")
        elif tool_name in self.NEW_FORMAT_EDIT_TOOLS:
            operation = "edit"
            file_path = args.get("relativeWorkspacePath") or args.get("targetFile")
            content = result.get("contentsAfterEdit")
        # Old format tools (2024)
        elif tool_name in self.FILE_EDIT_TOOLS:
            operation = "edit"
            file_path = args.get("relativeWorkspacePath") or args.get("targetFile")
            # Old format: content from streamingContent in args
            content = args.get("streamingContent")
        elif tool_name in self.FILE_WRITE_TOOLS:
            operation = "write"
            file_path = args.get("targetFile") or args.get("filePath")
            # Write: content from args
            content = args.get("content") or args.get("contents")
        elif tool_name in self.FILE_READ_TOOLS:
            operation = "read"
            file_path = args.get("targetFile")
            # Read: content from result
            content = result.get("contents")

        if not operation or not file_path or not tool_name:
            return None

        timestamp = datetime.fromtimestamp(event.get("timestamp_ms", 0) / 1000)

        # Confidence: high if new format (has diff.chunks), medium if old format
        has_diff_chunks = bool(result.get("diff", {}).get("chunks"))
        confidence = "high" if has_diff_chunks else "medium"

        return UnifiedFileOperation(
            file_path=file_path,
            operation=operation,
            timestamp=timestamp,
            diff=None,  # Populated by extract_diff
            confidence=confidence,
            agent_type="cursor",
            source_tool=tool_name,
            source_event_id=event.get("event_id", ""),
            content=content,
        )

    def extract_skill(self, event: dict) -> UnifiedSkill | None:
        """Extract skill activations from Cursor SKILL.md file reads."""
        args = event.get("args", {})
        target_file = args.get("targetFile", "")

        # Check if this is a SKILL.md file
        if not target_file.endswith("SKILL.md"):
            return None

        # Determine skill type from path
        skill_type = "unknown"
        if ".claude/skills/" in target_file:
            skill_type = "native-claude"
        elif ".cursor/skills/" in target_file:
            skill_type = "native-cursor"
        elif "superpowers-marketplace" in target_file:
            skill_type = "marketplace"

        # Parse skill name from YAML frontmatter
        result = event.get("result", {})
        contents = result.get("contents") or result.get("output", "")
        skill_name = self._parse_skill_name_from_yaml(contents)

        if not skill_name:
            return None

        timestamp = datetime.fromtimestamp(event.get("timestamp_ms", 0) / 1000)

        return UnifiedSkill(
            name=skill_name,
            method="file-read",
            skill_type=skill_type,
            timestamp=timestamp,
            agent_type="cursor",
            source_event_id=event.get("event_id", ""),
            file_path=target_file,
        )

    def _parse_skill_name_from_yaml(self, content: str) -> str | None:
        """Extract skill name from YAML frontmatter."""
        if not content or not content.startswith("---"):
            return None

        # Find end of frontmatter
        end_idx = content.find("\n---\n", 4)
        if end_idx < 0:
            return None

        frontmatter = content[4:end_idx]

        # Parse name field
        for line in frontmatter.split("\n"):
            if line.startswith("name:"):
                return line.split("name:")[1].strip()

        return None

    @staticmethod
    def _extract_shell_command(args: dict[str, object]) -> str:
        for key in ("command", "cmd", "input", "raw_command", "terminalCommand"):
            value = args.get(key)
            if isinstance(value, list):
                return " ".join(str(v) for v in value)
            if isinstance(value, str) and value:
                return value
        return ""

    @staticmethod
    def _extract_output_text(result: object) -> str:
        if isinstance(result, str):
            return result
        if isinstance(result, dict):
            result_dict = {str(k): v for k, v in result.items()}
            for key in ("stdout", "output", "content", "message", "result"):
                value = result_dict.get(key)
                if isinstance(value, str) and value:
                    return value
                nested = CursorV1Normalizer._extract_output_text(value)
                if nested:
                    return nested
        if isinstance(result, list):
            for item in result:
                nested = CursorV1Normalizer._extract_output_text(item)
                if nested:
                    return nested
        return ""

    def extract_git_commit(
        self, event: dict, git_state: dict[str, object]
    ) -> UnifiedGitCommit | None:
        """Extract git commit from Cursor shell-like tools."""
        tool_name = (event.get("tool_name") or "").strip()
        if tool_name not in self._SHELL_TOOLS:
            return None

        args = event.get("args", {})
        if not isinstance(args, dict):
            return None
        cmd = self._extract_shell_command(args)
        if not cmd:
            return None

        output = self._extract_output_text(event.get("result", {}))

        branch = parse_branch_from_command(cmd)
        if not branch and output:
            branch = parse_branch_from_output(output)
        if branch:
            git_state["branch"] = branch

        if not is_git_commit_command(cmd):
            return None

        timestamp = datetime.fromtimestamp(event.get("timestamp_ms", 0) / 1000, tz=UTC)

        commit_branch = None
        commit_hash = None
        commit_message = None
        if output:
            parsed = parse_commit_output(output)
            if parsed:
                commit_branch, commit_hash, commit_message = parsed

        resolved_branch = commit_branch or git_state.get("branch") or "unknown"

        return UnifiedGitCommit(
            branch=str(resolved_branch),
            timestamp=timestamp,
            agent_type="cursor",
            source_tool=tool_name,
            source_event_id=event.get("event_id", ""),
            commit_hash=commit_hash,
            message=commit_message,
        )

    def extract_diff(self, event: dict, session) -> UnifiedDiff | None:
        """Extract diff from Cursor result.

        Handles four Cursor formats (in priority order):
        1. NEW (2026+): edit_file/write/search_replace with diff.chunks[] - extracts directly
        2. ENRICHED: _computed_diff from daemon - pre-computed from content IDs
        3. OLD (2024): edit_file_v2 with streamingContent - computes diff from file state
        4. READ operations: tracks file content for future diff computation

        Args:
            event: Tool call event
            session: FileSystemState instance for tracking file content

        Returns:
            UnifiedDiff if diff can be extracted, else None
        """
        tool_name = event.get("tool_name", "")
        args = event.get("args", {})
        result = event.get("result", {})

        # Initialize session state if needed
        if session is None:
            session = FileSystemState()
        state = FileSystemState() if not isinstance(session, FileSystemState) else session

        # Get file path
        file_path = (
            args.get("relativeWorkspacePath") or args.get("targetFile") or args.get("filePath")
        )

        # Track file content from READ operations
        if tool_name in self.FILE_READ_TOOLS and file_path:
            contents = result.get("contents")
            if contents:
                state.set_content(file_path, contents)
            # Read operations don't produce diffs
            return None

        # NEW FORMAT: Extract from diff.chunks (Cursor 2026+)
        diff_data = result.get("diff")
        if diff_data and isinstance(diff_data, dict):
            chunks_data = diff_data.get("chunks", [])
            if chunks_data:
                diff = self._extract_diff_from_chunks(chunks_data)
                # Update state with new content if provided
                new_content = result.get("contentsAfterEdit")
                if new_content and file_path:
                    state.set_content(file_path, new_content)
                return diff

        # ENRICHED FORMAT: Pre-computed diff from daemon (beforeContentId/afterContentId resolved)
        computed_diff = result.get("_computed_diff")
        if computed_diff and isinstance(computed_diff, dict):
            hunks_data = computed_diff.get("hunks", [])
            if hunks_data:
                return self._extract_diff_from_hunks(hunks_data)

        # OLD FORMAT: Compute diff from file state using streamingContent
        if tool_name in self.FILE_EDIT_TOOLS and file_path:
            # Get new content from args
            new_content = args.get("streamingContent")
            if not new_content:
                return None

            # Check if we have the old content in state
            old_content = state.get_content(file_path)

            if old_content is not None:
                # Compute diff from old -> new content
                diff = self._compute_diff_from_content(old_content, new_content)
                # Update state with new content
                state.set_content(file_path, new_content)
                return diff

            # No old content available - store new content for future diffs
            # Note: file creations are handled by daemon enrichment (beforeContentId absent)
            state.set_content(file_path, new_content)
            return None

        # WRITE operations (old format write_file, create_file)
        if tool_name in self.FILE_WRITE_TOOLS and file_path:
            new_content = args.get("content") or args.get("contents")
            if new_content:
                state.set_content(file_path, new_content)
            return None

        return None

    def _extract_diff_from_hunks(self, hunks_data: list) -> UnifiedDiff:
        """Extract diff from pre-computed hunks (from daemon enrichment).

        Args:
            hunks_data: List of hunk dicts with old_start, old_count, new_start, new_count, lines

        Returns:
            UnifiedDiff with high confidence
        """
        hunks = []
        lines_added = []

        for hunk_data in hunks_data:
            if not isinstance(hunk_data, dict):
                continue

            hunk = DiffHunk(
                old_start=hunk_data.get("old_start", 1),
                old_count=hunk_data.get("old_count", 0),
                new_start=hunk_data.get("new_start", 1),
                new_count=hunk_data.get("new_count", 0),
                lines=hunk_data.get("lines", []),
            )
            hunks.append(hunk)

            # Calculate line numbers for additions
            current_line = hunk.new_start
            for line in hunk.lines:
                if line.startswith("+"):
                    lines_added.append(current_line)
                    current_line += 1
                elif line.startswith("-"):
                    pass  # Deletion, no new line
                else:
                    current_line += 1  # Context line

        return UnifiedDiff(
            hunks=hunks,
            format_source="computed",  # Computed from actual before/after content
            confidence="high",
            lines_added=lines_added,
            lines_modified=[],
        )

    def _extract_diff_from_chunks(self, chunks_data: list) -> UnifiedDiff:
        """Extract diff from Cursor's new format diff.chunks.

        Args:
            chunks_data: List of chunk dicts from result.diff.chunks

        Returns:
            UnifiedDiff with high confidence
        """
        hunks = []
        lines_added = []
        lines_modified = []

        for chunk_data in chunks_data:
            if not isinstance(chunk_data, dict):
                continue

            diff_string = chunk_data.get("diffString", "")
            if not diff_string:
                continue

            # Parse the diffString into lines
            # Format is unified diff: lines prefixed with ' ', '+', or '-'
            diff_lines = diff_string.split("\n")

            # Create hunk with metadata from Cursor
            hunk = DiffHunk(
                old_start=chunk_data.get("oldStart", 1),
                old_count=chunk_data.get("oldLines", 0),
                new_start=chunk_data.get("newStart", 1),
                new_count=chunk_data.get("newLines", 0),
                lines=diff_lines,
            )
            hunks.append(hunk)

            # Calculate line numbers for additions
            # Walk through the diff, tracking the current line number in the new file
            current_line = hunk.new_start
            for line in diff_lines:
                if line.startswith("+"):
                    # Addition
                    lines_added.append(current_line)
                    current_line += 1
                elif line.startswith("-"):
                    # Deletion (no new line number)
                    pass
                else:
                    # Context line (starts with space or empty)
                    current_line += 1

        return UnifiedDiff(
            hunks=hunks,
            format_source="cursor_diff_chunks",
            confidence="high",  # Cursor provides structured diffs
            lines_added=lines_added,
            lines_modified=lines_modified,
        )

    def _compute_diff_from_content(self, old_content: str, new_content: str) -> UnifiedDiff:
        """Compute unified diff from old and new file content."""
        return compute_diff_from_content(old_content, new_content)

    def extract_session_metadata(
        self,
        source_entries: list[dict],
        daemon_metadata: dict | None = None,
    ) -> SessionMetadata | None:
        """Extract session metadata from source entries.

        Cursor bubbles contain model info that should be preferred over daemon_metadata.
        Other metadata (cwd, git info) comes from daemon_metadata since Cursor
        sessions don't store this in the session data itself.

        Args:
            source_entries: List of source entry dicts with entry_content, entry_timestamp_ms
            daemon_metadata: Optional dict with git_commit, git_repo, model

        Returns:
            SessionMetadata extracted from source entries + daemon metadata, or None
        """
        if not source_entries:
            return None

        timestamp = datetime.fromtimestamp(source_entries[0]["entry_timestamp_ms"] / 1000, tz=UTC)

        # Extract model from source entries (Cursor bubbles have model info)
        # Cursor stores model in modelInfo.modelName (type 1/2 bubbles = user/assistant messages)
        # Scan first 10 entries to find one with model info
        primary_model = None
        max_scan = min(10, len(source_entries))
        for entry_dict in source_entries[:max_scan]:
            try:
                entry = json.loads(entry_dict["entry_content"])
                # Check nested modelInfo.modelName first (current Cursor format)
                model_info = entry.get("modelInfo", {})
                model = model_info.get("modelName") if isinstance(model_info, dict) else None
                # Fall back to top-level model field (older format / tool calls)
                if not model:
                    model = entry.get("model")
                if model:
                    primary_model = model
                    break
            except (json.JSONDecodeError, KeyError):
                continue

        # Fall back to daemon_metadata.model if not found in source entries
        if not primary_model and daemon_metadata:
            primary_model = daemon_metadata.get("model")

        # Final fallback: use "cursor" as default model
        # Many Cursor sessions don't store model info (older versions, some workflows)
        # Without a model, sessions can't be created, so we use a sensible default
        if not primary_model:
            primary_model = "cursor"

        # Cursor doesn't store cwd/git in source entries - get from daemon_metadata
        return SessionMetadata(
            cwd=daemon_metadata.get("cwd") if daemon_metadata else None,
            agent_type="cursor",
            agent_version=daemon_metadata.get("agent_version") if daemon_metadata else None,
            git_branch=daemon_metadata.get("git_branch") if daemon_metadata else None,
            git_commit=daemon_metadata.get("git_commit") if daemon_metadata else None,
            git_repo=daemon_metadata.get("git_repo") if daemon_metadata else None,
            # Never return None - ClickHouse LowCardinality(String) doesn't accept None
            primary_model=primary_model,
            timestamp=timestamp,
        )

    def extract_token_usage(self, source_entry: dict) -> list[TokenUsage]:
        """Extract token usage from a single source entry.

        Cursor stores token usage in bubble_metadata.usage.

        Args:
            source_entry: Parsed source entry dict (already JSON loaded)

        Returns:
            List of TokenUsage instances (empty if no usage found)
        """
        bubble_metadata = source_entry.get("bubble_metadata", {})
        usage = bubble_metadata.get("usage", {})

        if not usage:
            return []

        timestamp = datetime.fromtimestamp(source_entry.get("_timestamp_ms", 0) / 1000, tz=UTC)

        # Extract agent-provided cost if available
        cost_usd = usage.get("costUSD")
        if cost_usd is not None:
            try:
                cost_usd = float(cost_usd)
            except (ValueError, TypeError):
                cost_usd = None

        return [
            TokenUsage(
                input_tokens=usage.get("input_tokens", 0),
                output_tokens=usage.get("output_tokens", 0),
                cache_read_tokens=usage.get("cache_read_tokens", 0),
                cache_creation_tokens=usage.get("cache_creation_tokens", 0),
                reasoning_tokens=0,  # Cursor doesn't track reasoning tokens
                model=source_entry.get("model"),
                timestamp=timestamp,
                is_cumulative=False,
                cost_usd=cost_usd,
            )
        ]

    def extract_error(self, source_entry: dict) -> ErrorEvent | None:
        """Extract error event from a single source entry.

        Cursor errors come from tool failures, cancellations, and API errors.

        Args:
            source_entry: Parsed source entry dict (already JSON loaded)

        Returns:
            ErrorEvent if error found, else None
        """
        error_msg = source_entry.get("error")
        if not error_msg:
            return None

        timestamp = datetime.fromtimestamp(source_entry.get("_timestamp_ms", 0) / 1000, tz=UTC)

        # Determine error type
        error_type = "tool_call_error"

        # Check for cancellation
        bubble_metadata = source_entry.get("bubble_metadata", {})
        if bubble_metadata.get("cancelled"):
            error_type = "cancellation"
        # Check for rate limit
        elif "rate limit" in error_msg.lower() or source_entry.get("error_code") == 429:
            error_type = "rate_limit"
        # Check for context length
        elif "context window" in error_msg.lower() or "input too large" in error_msg.lower():
            error_type = "context_length"
        # Check for timeout
        elif "timeout" in error_msg.lower() or "timed out" in error_msg.lower():
            error_type = "timeout"

        return ErrorEvent(
            error_type=error_type,
            message=error_msg,
            tool_name=source_entry.get("tool_name"),
            tool_call_id=source_entry.get("tool_call_id"),
            details=None,
            timestamp=timestamp,
        )

    def extract_compaction(self, source_entries: list[dict]) -> list[CompactionEvent]:
        """Extract compaction events from source entries.

        Cursor compaction detection: When Cursor summarizes/compacts context,
        it re-creates conversation bubbles with:
        1. NEW bubbleId (unique identifier)
        2. serverBubbleId pointing to the ORIGINAL bubble's ID
        3. Missing fields like context, modelInfo, checkpointId, richText

        The presence of `serverBubbleId` is the definitive marker of a
        compacted bubble.

        Args:
            source_entries: All raw source entries for the session

        Returns:
            List of CompactionEvent objects for detected compaction events
        """
        compactions = []

        # Parse entries, tracking compacted vs original bubbles
        seen_bubble_ids: set[str] = set()
        compacted_bubbles = []
        original_bubbles = []

        for entry_dict in source_entries:
            try:
                entry = json.loads(entry_dict["entry_content"])
            except (json.JSONDecodeError, KeyError):
                continue

            bubble_id = entry.get("bubbleId")
            created_at = entry.get("createdAt")

            if not bubble_id:
                continue

            # Skip duplicates (same bubbleId sent multiple times)
            if bubble_id in seen_bubble_ids:
                continue
            seen_bubble_ids.add(bubble_id)

            # Parse timestamp
            ts = None
            if created_at:
                with contextlib.suppress(ValueError, TypeError):
                    ts = datetime.fromisoformat(created_at.replace("Z", "+00:00"))

            bubble_info = {
                "ts": ts,
                "bubble_id": bubble_id,
                "server_bubble_id": entry.get("serverBubbleId"),
            }

            # serverBubbleId indicates this is a compacted bubble
            if entry.get("serverBubbleId"):
                compacted_bubbles.append(bubble_info)
            else:
                original_bubbles.append(bubble_info)

        if not compacted_bubbles:
            return []

        # Find the earliest compacted bubble timestamp (compaction moment)
        compacted_with_ts = [b for b in compacted_bubbles if b["ts"]]
        if not compacted_with_ts:
            return []

        # Sort by timestamp (ts is guaranteed non-None after the filter above)
        compacted_with_ts.sort(key=lambda b: b["ts"])
        first_compacted = compacted_with_ts[0]

        # Count original messages that existed before compaction
        # (these are the messages that were summarized)
        messages_before = len(original_bubbles)

        # Number of bubbles recreated during compaction
        messages_after = len(compacted_bubbles)

        compactions.append(
            CompactionEvent(
                compaction_type="auto_summarization",
                timestamp=first_compacted["ts"],
                message_id=first_compacted["bubble_id"],
                messages_before=messages_before,
                messages_after=messages_after,
            )
        )

        return compactions
