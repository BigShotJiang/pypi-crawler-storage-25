"""Codex v1.x normalizer."""

import json
import re
from datetime import UTC, datetime
from typing import Any, Literal

from ..base import BaseNormalizer
from ..schemas import (
    CompactionEvent,
    DiffHunk,
    ErrorEvent,
    SessionMetadata,
    TokenUsage,
    UnifiedDiff,
    UnifiedFileOperation,
    UnifiedGitCommit,
    UnifiedPullRequest,
    UnifiedSkill,
    UnifiedTodo,
)
from .git_patterns import (
    is_git_commit_command,
    is_pr_create_command,
    parse_branch_from_command,
    parse_branch_from_output,
    parse_commit_output,
    parse_pr_number_from_url,
    parse_pr_title_from_command,
    parse_pr_url_from_output,
)


class CodexV1Normalizer(BaseNormalizer):
    """Normalizer for Codex v1.x format."""

    def extract_todo(self, event: dict) -> list[UnifiedTodo] | None:
        """Extract todos from Codex update_plan tool."""
        if event.get("tool_name") != "update_plan":
            return None

        args = event.get("args", {})
        plan = args.get("plan", [])

        if not plan:
            return None

        timestamp = datetime.fromtimestamp(event.get("timestamp_ms", 0) / 1000)

        unified_todos = []
        for item in plan:
            unified_todos.append(
                UnifiedTodo(
                    content=item["step"],  # Codex uses "step" not "content"
                    status=item["status"],
                    id=None,  # Codex doesn't provide IDs
                    timestamp=timestamp,
                    source_tool="update_plan",
                    agent_type="codex",
                )
            )

        return unified_todos

    def extract_file_operation(self, event: dict) -> UnifiedFileOperation | None:
        """Extract file operation from Codex exec_command or apply_patch.

        For multi-file apply_patch calls, returns the first file only.
        Use extract_file_operations() to get all files.
        """
        ops = self.extract_file_operations(event)
        return ops[0] if ops else None

    def extract_file_operations(self, event: dict) -> list[UnifiedFileOperation]:
        """Extract file operations from Codex exec_command or apply_patch.

        Returns a list because apply_patch can modify multiple files in a single call.
        """
        tool_name = event.get("tool_name")

        if tool_name == "apply_patch":
            return self._extract_file_operations_from_apply_patch(event)
        elif tool_name == "exec_command":
            op = self._extract_file_operation_from_exec_command(event)
            return [op] if op else []

        return []

    def _extract_file_operations_from_apply_patch(self, event: dict) -> list[UnifiedFileOperation]:
        """Extract file operations from apply_patch custom tool call.

        apply_patch can modify multiple files. Each *** Update File: line
        indicates a separate file being modified.
        """
        args = event.get("args", {})
        patch_input = args.get("input", "") or event.get("input", "")

        if not patch_input or "*** Begin Patch" not in patch_input:
            return []

        timestamp = datetime.fromtimestamp(event.get("timestamp_ms", 0) / 1000)

        # Extract (file_path, op_type) pairs from patch markers
        file_ops = self._extract_file_ops_from_patch(patch_input)
        if not file_ops:
            return []

        # Parse the patch into per-file hunks
        per_file_hunks = self._parse_codex_patch_per_file(patch_input)

        operations = []
        for file_path, op_type in file_ops:
            hunks = per_file_hunks.get(file_path, [])
            diff = self._build_diff_from_hunks(hunks) if hunks else None

            operations.append(
                UnifiedFileOperation(
                    file_path=file_path,
                    operation=op_type,
                    timestamp=timestamp,
                    diff=diff,
                    confidence="high",
                    agent_type="codex",
                    source_tool="apply_patch",
                    source_event_id=event.get("event_id", ""),
                    content=None,
                )
            )

        return operations

    def _extract_file_operation_from_exec_command(self, event: dict) -> UnifiedFileOperation | None:
        """Extract file operation from exec_command shell command."""
        args = event.get("args", {})
        cmd = args.get("cmd", "")

        # Try to detect file operations from shell commands
        operation, file_path = self._parse_file_operation_from_command(cmd)

        if not operation or not file_path:
            return None

        timestamp = datetime.fromtimestamp(event.get("timestamp_ms", 0) / 1000)

        return UnifiedFileOperation(
            file_path=file_path,
            operation=operation,
            timestamp=timestamp,
            diff=None,  # Populated by extract_diff
            confidence="medium",
            agent_type="codex",
            source_tool="exec_command",
            source_event_id=event.get("event_id", ""),
            content=None,
        )

    def _parse_file_operation_from_command(
        self, cmd: str
    ) -> tuple[Literal["read", "write", "edit"] | None, str | None]:
        """Parse file operation from shell command.

        Returns:
            (operation, file_path) or (None, None)
        """
        # Edit operations: sed, awk, perl
        if re.match(r"sed\s+-i", cmd):
            # sed -i 's/old/new/' file.txt
            match = re.search(r"sed\s+-i.*?\s+([^\s]+)$", cmd)
            if match:
                return ("edit", match.group(1))

        # Write operations: echo >, cat >, tee
        if " > " in cmd and " >> " not in cmd:
            # echo "content" > file.txt
            match = re.search(r">\s+([^\s;|&]+)", cmd)
            if match:
                return ("write", match.group(1))

        # Append operations (treat as edit)
        if " >> " in cmd:
            match = re.search(r">>\s+([^\s;|&]+)", cmd)
            if match:
                return ("edit", match.group(1))

        # Read operations: cat, head, tail, less, more
        for read_cmd in ["cat", "head", "tail", "less", "more"]:
            if cmd.strip().startswith(read_cmd + " "):
                # cat file.txt
                match = re.search(rf"{read_cmd}\s+([^\s;|&]+)", cmd)
                if match:
                    file_path = match.group(1)
                    # Filter out common non-file patterns
                    if not any(c in file_path for c in ["$", "`", "(", ")"]):
                        return ("read", file_path)

        return (None, None)

    def extract_skill(self, event: dict) -> UnifiedSkill | None:
        """Extract skill activations from Codex commands."""
        if event.get("tool_name") != "exec_command":
            return None

        args = event.get("args", {})
        cmd = args.get("cmd", "")

        # Check for SKILL.md file reads
        if "SKILL.md" in cmd:
            skill_type = "unknown"
            file_path = None

            # Determine skill type and extract file path
            if "/.codex/skills/" in cmd:
                skill_type = "native"
                match = re.search(r"(/.codex/skills/[^\s]+/SKILL\.md)", cmd)
                if match:
                    file_path = match.group(1)
            elif "/.codex/superpowers/skills/" in cmd:
                skill_type = "superpowers"
                match = re.search(r"(/.codex/superpowers/skills/[^\s]+/SKILL\.md)", cmd)
                if match:
                    file_path = match.group(1)

            # Parse skill name from result
            result = event.get("result", {})
            output = result.get("Output", "") if isinstance(result, dict) else ""
            skill_name = self._parse_skill_name_from_yaml(output)

            if skill_name:
                timestamp = datetime.fromtimestamp(event.get("timestamp_ms", 0) / 1000)
                return UnifiedSkill(
                    name=skill_name,
                    method="file-read",
                    skill_type=skill_type,
                    timestamp=timestamp,
                    agent_type="codex",
                    source_event_id=event.get("event_id", ""),
                    file_path=file_path,
                )

        # Check for superpowers wrapper command
        if "superpowers-codex use-skill" in cmd:
            match = re.search(r"use-skill\s+([^\s;|&]+)", cmd)
            if match:
                skill_name = match.group(1)
                timestamp = datetime.fromtimestamp(event.get("timestamp_ms", 0) / 1000)
                return UnifiedSkill(
                    name=skill_name,
                    method="file-read",
                    skill_type="superpowers",
                    timestamp=timestamp,
                    agent_type="codex",
                    source_event_id=event.get("event_id", ""),
                )

        return None

    def _parse_skill_name_from_yaml(self, content: str) -> str | None:
        """Extract skill name from YAML frontmatter."""
        if not content or not content.startswith("---"):
            return None

        # Find end of frontmatter - check for both literal \n and actual newlines
        start_idx = 3  # After "---"
        end_marker = None

        # Try actual newlines first
        if content.find("\n---\n", start_idx) > 0:
            start_idx = content.find("\n", start_idx) + 1
            end_idx = content.find("\n---\n", start_idx)
            end_marker = "\n"
        # Try escaped version
        elif content.find("\\n---\\n", start_idx) > 0:
            start_idx = content.find("\\n", start_idx) + 2  # Skip \n
            end_idx = content.find("\\n---\\n", start_idx)
            end_marker = "\\n"
        else:
            return None

        frontmatter = content[start_idx:end_idx]

        # Parse name field
        lines = frontmatter.split(end_marker)
        for line in lines:
            if line.startswith("name:"):
                return line.split("name:", 1)[1].strip()

        return None

    def extract_diff(self, event: dict, session) -> UnifiedDiff | None:
        """Extract diff from Codex apply_patch or exec_command file operations.

        Handles two cases:
        1. apply_patch: Structured patches for file edits
        2. exec_command with cat/echo: New file creation

        Note: For apply_patch, diffs are already attached per-file in
        extract_file_operations(). This method returns all hunks merged
        (for backward compatibility with single-file callers).
        """
        tool_name = event.get("tool_name")

        # Case 1: apply_patch (file edits)
        if tool_name == "apply_patch":
            return self._extract_diff_from_apply_patch(event)

        # Case 2: exec_command with cat > or echo > (file creation)
        if tool_name == "exec_command":
            return self._extract_diff_from_file_creation(event)

        return None

    def _extract_diff_from_apply_patch(self, event: dict) -> UnifiedDiff | None:
        """Extract diff from apply_patch custom format.

        Note: For multi-file patches, this merges all hunks together.
        Use _extract_file_operations_from_apply_patch() for per-file diffs.
        """
        # Check both direct "input" field and args.input (from adapter conversion)
        patch_input = event.get("input", "") or event.get("args", {}).get("input", "")
        if not patch_input or "*** Begin Patch" not in patch_input:
            return None

        try:
            hunks = self._parse_codex_patch(patch_input)
            return self._build_diff_from_hunks(hunks) if hunks else None
        except Exception:
            return None

    def _extract_diff_from_file_creation(self, event: dict) -> UnifiedDiff | None:
        """Extract diff from exec_command file creation (cat > or echo >).

        When Codex creates a new file with cat <<EOF > file.txt or echo > file.txt,
        we generate a diff showing the entire file content as additions.
        """
        args = event.get("args", {})
        cmd = args.get("cmd", "")

        # Only handle write operations (not appends or reads)
        if " > " not in cmd or " >> " in cmd:
            return None

        # Extract content for heredoc (cat <<EOF)
        content = None
        if "cat <<" in cmd or "cat<<" in cmd:
            content = self._extract_heredoc_content(cmd)
        elif "echo " in cmd and " > " in cmd:
            # Simple echo redirect
            content = self._extract_echo_content(cmd)

        if not content:
            return None

        # Generate diff with all lines as additions
        lines = content.split("\n")
        # Remove trailing empty line if present
        if lines and not lines[-1]:
            lines = lines[:-1]

        # Create a single hunk with all content as additions
        hunk_lines = [f"+{line}" for line in lines]

        hunk = DiffHunk(
            old_start=0,  # No old file
            old_count=0,
            new_start=1,
            new_count=len(lines),
            lines=hunk_lines,
        )

        # All line numbers are additions
        lines_added = list(range(1, len(lines) + 1))

        return UnifiedDiff(
            hunks=[hunk],
            format_source="shell_inferred",
            confidence="high",  # We have explicit content
            lines_added=lines_added,
            lines_modified=[],  # New file, nothing modified
        )

    def _extract_heredoc_content(self, cmd: str) -> str | None:
        """Extract content from heredoc (cat <<EOF ... EOF)."""
        # Find the heredoc delimiter
        heredoc_match = re.search(r"<<['\"]?(\w+)['\"]?", cmd)
        if not heredoc_match:
            return None

        delimiter = heredoc_match.group(1)

        # Split command into lines
        lines = cmd.split("\n")

        # Find start and end of heredoc content
        content_lines = []
        in_heredoc = False

        for line in lines:
            if not in_heredoc:
                # Look for the start (line with cat <<)
                if "cat <<" in line or "cat<<" in line:
                    in_heredoc = True
                continue

            # Check if this is the end delimiter
            if line.strip() == delimiter:
                break

            content_lines.append(line)

        return "\n".join(content_lines) if content_lines else None

    def _extract_echo_content(self, cmd: str) -> str | None:
        """Extract content from echo redirect (echo "content" > file)."""
        # Simple case: echo "content" > file
        match = re.search(r'echo\s+["\'](.+?)["\']\s*>', cmd, re.DOTALL)
        if match:
            return match.group(1)

        # Without quotes: echo content > file
        match = re.search(r"echo\s+(.+?)\s*>", cmd)
        if match:
            return match.group(1).strip()

        return None

    def _extract_file_paths_from_patch(self, patch_input: str) -> list[str]:
        """Extract file paths from *** Update File: and *** Add File: lines."""
        return [path for path, _ in self._extract_file_ops_from_patch(patch_input)]

    @staticmethod
    def _extract_file_ops_from_patch(
        patch_input: str,
    ) -> list[tuple[str, Literal["edit", "write"]]]:
        """Extract (file_path, operation) pairs from patch markers.

        Returns:
            List of (path, op_type) tuples in order of appearance.
        """
        ops: list[tuple[str, Literal["edit", "write"]]] = []
        for line in patch_input.split("\n"):
            if line.startswith("*** Update File:"):
                path = line[len("*** Update File:") :].strip()
                if path:
                    ops.append((path, "edit"))
            elif line.startswith("*** Add File:"):
                path = line[len("*** Add File:") :].strip()
                if path:
                    ops.append((path, "write"))
        return ops

    @staticmethod
    def _build_diff_from_hunks(hunks: list[DiffHunk]) -> UnifiedDiff | None:
        """Build a UnifiedDiff from parsed hunks, computing line stats.

        Args:
            hunks: List of DiffHunk objects

        Returns:
            UnifiedDiff with lines_added/lines_modified computed, or None if empty.
        """
        if not hunks:
            return None

        lines_added: list[int] = []
        lines_modified: list[int] = []

        for hunk in hunks:
            current_new_line = hunk.new_start
            current_old_line = hunk.old_start
            for line in hunk.lines:
                if line.startswith("+"):
                    lines_added.append(current_new_line)
                    current_new_line += 1
                elif line.startswith("-"):
                    current_old_line += 1
                else:
                    current_new_line += 1
                    current_old_line += 1

        return UnifiedDiff(
            hunks=hunks,
            format_source="codex_apply_patch",
            confidence="high",
            lines_added=lines_added,
            lines_modified=lines_modified,
        )

    def _parse_codex_patch_per_file(self, patch_input: str) -> dict[str, list[DiffHunk]]:
        """Parse Codex patch format into per-file diff hunks.

        Returns a dict mapping file_path -> list of DiffHunk.
        """
        result: dict[str, list[DiffHunk]] = {}

        begin_marker = "*** Begin Patch"
        end_marker = "*** End Patch"

        if begin_marker not in patch_input:
            return result

        # Handle missing End Patch marker (truncated patches)
        if end_marker in patch_input:
            content = patch_input[
                patch_input.find(begin_marker) + len(begin_marker) : patch_input.find(end_marker)
            ]
        else:
            content = patch_input[patch_input.find(begin_marker) + len(begin_marker) :]

        lines = content.strip().split("\n")

        # Split into per-file sections
        current_file = None
        current_lines: list[str] = []

        for line in lines:
            if line.startswith("*** Update File:") or line.startswith("*** Add File:"):
                # Save previous file section
                if current_file and current_lines:
                    result[current_file] = self._parse_hunk_sections(current_lines)

                # Start new file section
                if line.startswith("*** Update File:"):
                    current_file = line[len("*** Update File:") :].strip()
                else:
                    current_file = line[len("*** Add File:") :].strip()
                current_lines = []
            else:
                current_lines.append(line)

        # Save final file section
        if current_file and current_lines:
            result[current_file] = self._parse_hunk_sections(current_lines)

        return result

    def _parse_hunk_sections(self, lines: list[str]) -> list[DiffHunk]:
        """Parse lines between file markers into hunk sections split by @@."""
        hunk_sections: list[list[str]] = []
        current_section: list[str] = []

        for line in lines:
            if line.strip() == "@@":
                if current_section:
                    hunk_sections.append(current_section)
                    current_section = []
            else:
                current_section.append(line)

        if current_section:
            hunk_sections.append(current_section)

        hunks = []
        for section in hunk_sections:
            if section:
                hunk = self._lines_to_hunk(section)
                if hunk:
                    hunks.append(hunk)

        return hunks

    def _parse_codex_patch(self, patch_input: str) -> list[DiffHunk]:
        """Parse Codex's custom patch format into unified diff hunks.

        Format:
        *** Begin Patch
        *** Update File: <filepath>
        @@
        -old line
        +new line
        @@
        ...
        *** End Patch

        Note: For multi-file patches, this merges all hunks together.
        Use _parse_codex_patch_per_file() for per-file hunks.
        """
        # Collect all hunks across all files
        per_file = self._parse_codex_patch_per_file(patch_input)
        all_hunks = []
        for hunks in per_file.values():
            all_hunks.extend(hunks)
        return all_hunks

    def _lines_to_hunk(self, lines: list[str]) -> DiffHunk | None:
        """Convert a list of +/- lines into a DiffHunk.

        Since Codex doesn't provide line numbers, we estimate them
        by assuming hunks start at line 1 and counting from there.
        """
        if not lines:
            return None

        # Count additions and deletions
        old_count = sum(1 for line in lines if line.startswith("-"))
        new_count = sum(1 for line in lines if line.startswith("+"))
        context_count = sum(
            1 for line in lines if not line.startswith("+") and not line.startswith("-")
        )

        # For Codex patches without explicit line numbers, we use heuristics
        # In practice, we'd need the full file context to get exact line numbers
        # For now, we'll mark as starting at line 1 (will be improved with git integration)
        old_start = 1
        new_start = 1

        # Adjust counts to include context lines
        old_count += context_count
        new_count += context_count

        return DiffHunk(
            old_start=old_start,
            old_count=old_count,
            new_start=new_start,
            new_count=new_count,
            lines=lines,
        )

    def extract_session_metadata(
        self,
        source_entries: list[dict],
        daemon_metadata: dict | None = None,
    ) -> SessionMetadata | None:
        """Extract session metadata from source entries.

        Codex stores metadata in session_meta entries with payload structure:
        {
            "type": "session_meta",
            "payload": {
                "cwd": "/path/to/project",
                "cli_version": "0.84.0",
                "model": "o3",
                ...
            }
        }

        Args:
            source_entries: List of source entry dicts with entry_content, entry_timestamp_ms
            daemon_metadata: Optional dict with git_commit, git_repo

        Returns:
            SessionMetadata extracted from first entry + daemon metadata, or None
        """
        if not source_entries:
            return None

        first_entry = json.loads(source_entries[0]["entry_content"])
        timestamp = datetime.fromtimestamp(source_entries[0]["entry_timestamp_ms"] / 1000, tz=UTC)

        # Codex stores metadata in payload for session_meta entries
        payload = {}
        if first_entry.get("type") == "session_meta":
            payload = first_entry.get("payload", {})

        # Extract fields from payload (source data), fall back to daemon_metadata
        cwd = payload.get("cwd") or (daemon_metadata.get("cwd") if daemon_metadata else None)
        agent_version = payload.get("cli_version") or (
            daemon_metadata.get("agent_version") if daemon_metadata else None
        )

        # Model extraction: session_meta only has model_provider (e.g., "openai"),
        # but actual model name (e.g., "gpt-5-codex") is in turn_context entries.
        # Look for first turn_context entry to get the actual model.
        model_from_turn_context = None
        for entry in source_entries:
            entry_content = entry.get("entry_content")
            if not entry_content:
                continue
            try:
                parsed = json.loads(entry_content)
                if parsed.get("type") == "turn_context":
                    turn_payload = parsed.get("payload", {})
                    if turn_payload.get("model"):
                        model_from_turn_context = turn_payload["model"]
                        break
            except (json.JSONDecodeError, TypeError):
                continue

        # Try model from turn_context, then session_meta fields, then daemon_metadata
        primary_model = (
            model_from_turn_context
            or payload.get("model")
            or payload.get("model_provider")
            or (daemon_metadata.get("model") if daemon_metadata else None)
            or ""  # Never return None - ClickHouse LowCardinality(String) doesn't accept None
        )

        # Codex stores git info in payload.git nested object
        # Prefer source entry data over daemon_metadata
        git_info = payload.get("git", {})
        git_branch = git_info.get("branch") or (
            daemon_metadata.get("git_branch") if daemon_metadata else None
        )
        git_commit = git_info.get("commit_hash") or (
            daemon_metadata.get("git_commit") if daemon_metadata else None
        )
        git_repo = git_info.get("repository_url") or (
            daemon_metadata.get("git_repo") if daemon_metadata else None
        )

        return SessionMetadata(
            cwd=cwd,
            agent_type="codex",
            agent_version=agent_version,
            git_branch=git_branch,
            git_commit=git_commit,
            git_repo=git_repo,
            primary_model=primary_model,
            timestamp=timestamp,
        )

    def extract_token_usage(self, source_entry: dict) -> list[TokenUsage]:
        """Extract token usage from a single source entry.

        Codex stores token usage in event_msg entries with payload.type == "token_count".
        Each token_count event has:
        - total_token_usage: cumulative across the session
        - last_token_usage: per-API-call delta

        We use last_token_usage (the delta) since aggregate_token_usage accumulates.
        Duplicate token_count events (same totals emitted pre/post tool execution)
        are deduped via get_token_usage_group_key().

        Args:
            source_entry: Parsed source entry dict (already JSON loaded)

        Returns:
            List of TokenUsage instances (empty if no usage found)
        """
        if source_entry.get("type") != "event_msg":
            return []

        payload = source_entry.get("payload", {})
        if not isinstance(payload, dict) or payload.get("type") != "token_count":
            return []

        info = payload.get("info")
        if not info or not isinstance(info, dict):
            return []

        last_usage = info.get("last_token_usage", {})
        if not isinstance(last_usage, dict):
            return []

        input_tokens = last_usage.get("input_tokens", 0)
        output_tokens = last_usage.get("output_tokens", 0)

        if not input_tokens and not output_tokens:
            return []

        timestamp = datetime.fromtimestamp(source_entry.get("_timestamp_ms", 0) / 1000, tz=UTC)

        return [
            TokenUsage(
                input_tokens=input_tokens,
                output_tokens=output_tokens,
                cache_read_tokens=last_usage.get("cached_input_tokens", 0),
                cache_creation_tokens=0,
                reasoning_tokens=last_usage.get("reasoning_output_tokens", 0),
                model=None,
                timestamp=timestamp,
                is_cumulative=False,
            )
        ]

    def get_token_usage_group_key(self, source_entry: dict) -> str | None:
        """Return a grouping key to dedup duplicate token_count events.

        Codex emits the same token_count event before and after tool execution
        with identical totals. We use total_token_usage.total_tokens as the
        dedup key so only the last event per unique total is kept.
        """
        payload = source_entry.get("payload", {})
        if not isinstance(payload, dict):
            return None

        info = payload.get("info")
        if not info or not isinstance(info, dict):
            return None

        total_usage = info.get("total_token_usage", {})
        if isinstance(total_usage, dict):
            total = total_usage.get("total_tokens")
            if total is not None:
                return f"total_{total}"

        return None

    def extract_error(self, source_entry: dict) -> ErrorEvent | None:
        """Extract error event from a single source entry.

        Codex errors come from exec_command failures (non-zero exit codes),
        timeouts, interruptions, and rate limits.

        Args:
            source_entry: Parsed source entry dict (already JSON loaded)

        Returns:
            ErrorEvent if error found, else None
        """
        result = source_entry.get("result", {})
        if not isinstance(result, dict):
            return None

        timestamp = datetime.fromtimestamp(source_entry.get("_timestamp_ms", 0) / 1000, tz=UTC)

        # Check for various error conditions
        error_msg = result.get("error")
        if not error_msg:
            # Check for non-zero exit code
            exit_code = result.get("exit_code")
            if exit_code and exit_code != 0:
                error_msg = result.get("output", "Command failed")

        if not error_msg:
            return None

        # Determine error type
        error_type = "tool_call_error"
        if result.get("timeout"):
            error_type = "timeout"
        elif result.get("rate_limit"):
            error_type = "rate_limit"
        elif result.get("interrupted"):
            error_type = "interruption"

        return ErrorEvent(
            error_type=error_type,
            message=error_msg,
            tool_name=source_entry.get("tool_name"),
            tool_call_id=source_entry.get("tool_call_id"),
            details=None,
            timestamp=timestamp,
        )

    def extract_compaction(self, source_entries: list[dict]) -> list[CompactionEvent]:
        """Extract compaction events from source entries.

        Args:
            source_entries: All raw source entries for the session

        Returns:
            Empty list - compaction detection not yet implemented for Codex
        """
        return []  # Not yet implemented

    # Codex shell tool names
    _SHELL_TOOLS = {"exec_command"}

    def extract_git_commit(self, event: dict, git_state: dict[str, Any]) -> UnifiedGitCommit | None:
        """Extract git commit from Codex shell command events."""
        tool_name = event.get("tool_name", "")
        if tool_name not in self._SHELL_TOOLS:
            return None

        args = event.get("args", {})
        # Codex uses "cmd" or "command"; cmd may be array
        cmd = args.get("cmd") or args.get("command") or ""
        if isinstance(cmd, list):
            cmd = " ".join(str(c) for c in cmd)
        if not cmd:
            return None

        # Get output - Codex wraps in {"output": "...", "metadata": {...}}
        result = event.get("result", {})
        output = ""
        if isinstance(result, dict):
            output = result.get("output", "") or result.get("Output", "")
        elif isinstance(result, str):
            output = result

        # Update branch state from checkout/switch commands
        branch = parse_branch_from_command(cmd)
        if not branch and output:
            branch = parse_branch_from_output(output)
        if branch:
            git_state["branch"] = branch

        # Detect git commit
        if not is_git_commit_command(cmd):
            return None

        timestamp = datetime.fromtimestamp(event.get("timestamp_ms", 0) / 1000, tz=UTC)

        # Try to parse branch/hash/message from commit output
        commit_branch = None
        commit_hash = None
        commit_message = None
        if output:
            parsed = parse_commit_output(output)
            if parsed:
                commit_branch, commit_hash, commit_message = parsed

        # Resolve branch: commit output > tracked state > unknown
        resolved_branch = commit_branch or git_state.get("branch") or "unknown"

        return UnifiedGitCommit(
            branch=resolved_branch,
            timestamp=timestamp,
            agent_type="codex",
            source_tool=tool_name,
            source_event_id=event.get("event_id", ""),
            commit_hash=commit_hash,
            message=commit_message,
        )

    def extract_pr(self, event: dict, git_state: dict[str, Any]) -> UnifiedPullRequest | None:
        """Extract PR creation from Codex shell command events."""
        tool_name = event.get("tool_name", "")
        if tool_name not in self._SHELL_TOOLS:
            return None

        args = event.get("args", {})
        cmd = args.get("cmd") or args.get("command") or ""
        if isinstance(cmd, list):
            cmd = " ".join(str(c) for c in cmd)
        if not cmd or not is_pr_create_command(cmd):
            return None

        # Get output
        result = event.get("result", {})
        output = ""
        if isinstance(result, dict):
            output = result.get("output", "") or result.get("Output", "")
        elif isinstance(result, str):
            output = result

        pr_url = parse_pr_url_from_output(output)
        if not pr_url:
            return None

        timestamp = datetime.fromtimestamp(event.get("timestamp_ms", 0) / 1000, tz=UTC)
        branch = git_state.get("branch") or "unknown"

        return UnifiedPullRequest(
            url=pr_url,
            branch=branch,
            timestamp=timestamp,
            agent_type="codex",
            source_tool=tool_name,
            source_event_id=event.get("event_id", ""),
            number=parse_pr_number_from_url(pr_url),
            title=parse_pr_title_from_command(cmd),
        )
