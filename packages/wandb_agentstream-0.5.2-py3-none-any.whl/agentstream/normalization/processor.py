"""Event processor for generating synthetic unified events."""

from typing import Any

from agentstream.events import CustomEvent

from .file_state import FileSystemState
from .registry import get_normalizer
from .synthetic import (
    create_file_operation_event,
    create_git_commit_event,
    create_pr_event,
    create_skill_event,
    create_todo_event,
)


class EventProcessor:
    """Process events and generate synthetic unified events."""

    def __init__(self, agent_type: str, version: str):
        """Initialize processor with agent-specific normalizer.

        Args:
            agent_type: Agent type (claude, cursor, codex, gemini)
            version: Agent version string
        """
        self.agent_type = agent_type
        self.version = version
        self.normalizer = get_normalizer(agent_type, version)

    def process_events(
        self,
        events: list[dict[str, Any]],
        session: Any | None = None,
        initial_git_state: dict[str, Any] | None = None,
    ) -> list[CustomEvent]:
        """Process events and generate synthetic CustomEvent instances.

        Args:
            events: List of raw events
            session: Session context for diff extraction (typically FileSystemState).
                If None, will auto-create FileSystemState for better diff extraction.
            initial_git_state: Optional initial git state (e.g., {"branch": "main"})
                used for incremental processing where prior checkout events may have
                been processed in earlier runs.

        Returns:
            List of CustomEvent instances
        """
        # Auto-create FileSystemState if no session provided
        # This enables diff extraction for agents that don't provide structured diffs
        if session is None:
            session = FileSystemState()

        synthetic_events = []
        git_state: dict[str, Any] = {"branch": None}
        if isinstance(initial_git_state, dict):
            git_state.update(initial_git_state)

        for event in events:
            # Extract todos
            todos = self.normalizer.extract_todo(event)
            if todos:
                for todo in todos:
                    synthetic_events.append(create_todo_event(todo, event))

            # Extract file operations (may be multiple for multi-file patches)
            file_ops = self.normalizer.extract_file_operations(event)

            for file_op in file_ops:
                # Try to extract diff if not already attached
                if file_op.diff is None:
                    diff = self.normalizer.extract_diff(event, session)
                    if diff:
                        file_op.diff = diff

                synthetic_events.append(create_file_operation_event(file_op, event))

            # Extract skills
            skill = self.normalizer.extract_skill(event)
            if skill:
                synthetic_events.append(create_skill_event(skill, event))

            # Extract git commits
            git_commit = self.normalizer.extract_git_commit(event, git_state)
            if git_commit:
                synthetic_events.append(create_git_commit_event(git_commit, event))

            # Extract PR creations
            pr = self.normalizer.extract_pr(event, git_state)
            if pr:
                synthetic_events.append(create_pr_event(pr, event))

        return synthetic_events
