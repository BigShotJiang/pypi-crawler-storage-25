"""Base normalizer interface for agent-specific adapters."""

import difflib
from abc import ABC, abstractmethod
from typing import Any

from .schemas import (
    CompactionEvent,
    DiffHunk,
    ErrorEvent,
    SessionMetadata,
    TokenUsage,
    UnifiedDiff,
    UnifiedFileOperation,
    UnifiedGitCommit,
    UnifiedPullRequest,
    UnifiedSkill,
    UnifiedTodo,
)


def compute_diff_from_content(old_content: str, new_content: str) -> UnifiedDiff:
    """Compute unified diff from old and new file content.

    Args:
        old_content: Original file content (empty string for new files)
        new_content: New file content

    Returns:
        UnifiedDiff with medium confidence
    """
    # Split into lines
    old_lines = old_content.splitlines(keepends=True)
    new_lines = new_content.splitlines(keepends=True)

    # Use difflib to compute unified diff
    diff_lines = list(
        difflib.unified_diff(
            old_lines,
            new_lines,
            lineterm="",
            n=3,  # 3 lines of context
        )
    )

    # Parse unified diff into hunks
    hunks = []
    lines_added = []
    current_hunk_lines = []
    old_start = 0
    new_start = 0
    old_count = 0
    new_count = 0

    for line in diff_lines:
        # Skip diff headers (---, +++, @@)
        if line.startswith("---") or line.startswith("+++"):
            continue

        # Hunk header: @@ -old_start,old_count +new_start,new_count @@
        if line.startswith("@@"):
            # Save previous hunk if exists
            if current_hunk_lines:
                hunks.append(
                    DiffHunk(
                        old_start=old_start,
                        old_count=old_count,
                        new_start=new_start,
                        new_count=new_count,
                        lines=current_hunk_lines,
                    )
                )
                current_hunk_lines = []

            # Parse hunk header
            # Format: @@ -1,5 +1,6 @@
            parts = line.split()
            if len(parts) >= 3:
                old_range = parts[1][1:]  # Remove leading '-'
                new_range = parts[2][1:]  # Remove leading '+'

                if "," in old_range:
                    old_start_str, old_count_str = old_range.split(",")
                    old_start = int(old_start_str)
                    old_count = int(old_count_str)
                else:
                    old_start = int(old_range)
                    old_count = 1

                if "," in new_range:
                    new_start_str, new_count_str = new_range.split(",")
                    new_start = int(new_start_str)
                    new_count = int(new_count_str)
                else:
                    new_start = int(new_range)
                    new_count = 1

            continue

        # Diff content lines
        current_hunk_lines.append(line)

    # Save final hunk
    if current_hunk_lines:
        hunks.append(
            DiffHunk(
                old_start=old_start,
                old_count=old_count,
                new_start=new_start,
                new_count=new_count,
                lines=current_hunk_lines,
            )
        )

    # Calculate line numbers for additions
    for hunk in hunks:
        current_line = hunk.new_start
        for line in hunk.lines:
            if line.startswith("+"):
                lines_added.append(current_line)
                current_line += 1
            elif line.startswith("-"):
                # Deletion (no new line number)
                pass
            else:
                # Context line
                current_line += 1

    return UnifiedDiff(
        hunks=hunks,
        format_source="computed",
        confidence="medium",  # Computed from full content
        lines_added=lines_added,
        lines_modified=[],  # Could enhance this later
    )


class BaseNormalizer(ABC):
    """Base class for agent-specific normalizers."""

    @abstractmethod
    def extract_todo(self, event: dict) -> list[UnifiedTodo] | None:
        """Extract unified todo from agent-specific event.

        Args:
            event: Raw event dict with tool_name, args, result

        Returns:
            List[UnifiedTodo] if this is a todo event, else None
        """
        pass

    def extract_file_operations(self, event: dict) -> list[UnifiedFileOperation]:
        """Extract unified file operations from agent-specific event.

        Override this for agents where a single event can produce multiple
        file operations (e.g., Codex apply_patch modifying multiple files).

        Default implementation wraps extract_file_operation().
        """
        op = self.extract_file_operation(event)
        return [op] if op else []

    @abstractmethod
    def extract_file_operation(self, event: dict) -> UnifiedFileOperation | None:
        """Extract unified file operation from agent-specific event.

        This method should populate the `content` field when possible:

        **Content Capture Requirements:**

        - **READ operations**: Capture the file content from the tool result.
          This is the original state before any edits.

        - **WRITE operations**: Capture the new content being written from args.
          This is the final state after the write.

        - **EDIT operations**: Content is optional since we have hunks.
          If available, capture the content after edit from result.

        **Why content matters:**
        When multiple edits are made to the same file in a session, changes
        can cancel out (e.g., add lines then remove them). Having the original
        content (from first READ) and final content (from last WRITE or
        applying hunks) enables computing the net diff correctly.

        **Adapter-specific notes:**

        - Claude: READ result has content with line numbers (→ format).
          Use `_strip_line_numbers()` to extract clean content.
          WRITE args have the content being written.

        - Cursor: READ result has `contents` field.
          WRITE/EDIT may have `contentsAfterEdit` in result.
          Old format uses `streamingContent` in args.

        - Gemini: READ result may have `content` or `contents`.
          WRITE args have `content` or `contents`.

        - Codex: Shell commands don't provide structured content.
          Leave content as None.

        Args:
            event: Raw event dict with tool_name, args, result

        Returns:
            UnifiedFileOperation if this is a file op event, else None
        """
        pass

    @abstractmethod
    def extract_skill(self, event: dict) -> UnifiedSkill | None:
        """Extract unified skill activation from agent-specific event.

        Args:
            event: Raw event dict with tool_name, args, result

        Returns:
            UnifiedSkill if this is a skill activation, else None
        """
        pass

    @abstractmethod
    def extract_diff(self, event: dict, session: Any) -> UnifiedDiff | None:
        """Extract unified diff from agent-specific event.

        Args:
            event: Raw event dict with tool_name, args, result
            session: Session context for fallback strategies

        Returns:
            UnifiedDiff if diff can be extracted, else None
        """
        pass

    @abstractmethod
    def extract_session_metadata(
        self,
        source_entries: list[dict],
        daemon_metadata: dict | None = None,
    ) -> SessionMetadata | None:
        """Extract session metadata from source entries.

        Args:
            source_entries: All raw source entries for the session
            daemon_metadata: Optional daemon metadata dict (git_commit, git_repo, etc.)

        Returns:
            SessionMetadata extracted from first entry + daemon_metadata, or None
        """
        pass

    @abstractmethod
    def extract_token_usage(self, source_entry: dict) -> list[TokenUsage]:
        """Extract token usage from a single source entry.

        Args:
            source_entry: Raw source entry with potential token usage data

        Returns:
            List of TokenUsage instances (may be empty if no usage found)
        """
        pass

    def get_token_usage_group_key(self, source_entry: dict) -> str | None:
        """Return a grouping key for deduplicating token usage entries.

        Agents that emit multiple streaming chunks per API call with cumulative
        usage (e.g., Claude) should override this to return a stable key
        (like message.id) so only the last chunk per group is kept.

        Agents where each entry with tokens represents a unique API call
        (Codex, Cursor, Gemini, OpenCode) can use the default (None),
        meaning every entry is treated as unique.

        Args:
            source_entry: Parsed source entry dict (already JSON loaded)

        Returns:
            Grouping key string, or None if each entry is unique
        """
        return None

    @abstractmethod
    def extract_error(self, source_entry: dict) -> ErrorEvent | None:
        """Extract error event from a single source entry.

        Args:
            source_entry: Raw source entry with potential error data

        Returns:
            ErrorEvent if error found, else None
        """
        pass

    @abstractmethod
    def extract_compaction(self, source_entries: list[dict]) -> list[CompactionEvent]:
        """Extract compaction events from source entries.

        Args:
            source_entries: All raw source entries for the session

        Returns:
            List of CompactionEvent objects (empty if none detected)
        """
        pass

    def extract_git_commit(self, event: dict, git_state: dict[str, Any]) -> UnifiedGitCommit | None:
        """Extract git commit from a shell command event.

        Tracks branch state through checkout/switch commands and emits
        UnifiedGitCommit when a commit is detected.

        Non-abstract: only normalizers with shell access (Claude, Codex) override.

        Args:
            event: Raw event dict with tool_name, args, result
            git_state: Mutable dict with "branch" key tracking current branch

        Returns:
            UnifiedGitCommit if a commit was detected, else None
        """
        return None

    def supports_api_enrichment(self) -> bool:
        """Whether this normalizer supports server-side API enrichment for token usage.

        Override to return True for agents whose external API can provide token
        usage data that isn't available in the local session data.

        Returns:
            True if the agent supports API-based token enrichment
        """
        return False

    def extract_pr(self, event: dict, git_state: dict[str, Any]) -> UnifiedPullRequest | None:
        """Extract PR creation from a shell command event.

        Detects `gh pr create` commands and extracts the PR URL from output.

        Non-abstract: only normalizers with shell access (Claude, Codex) override.

        Args:
            event: Raw event dict with tool_name, args, result
            git_state: Mutable dict with "branch" key tracking current branch

        Returns:
            UnifiedPullRequest if a PR creation was detected, else None
        """
        return None
