"""Base adapter infrastructure."""

from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import Iterable, Iterator
from dataclasses import dataclass, field
from pathlib import Path
from typing import IO, TYPE_CHECKING, Any

if TYPE_CHECKING:
    from agentstream.events import Event
    from agentstream.grouper import MessageGroup


@dataclass
class Session:
    """Represents a discovered agent session."""

    id: str
    path: Path
    format: str
    modified_at: float
    metadata: dict[str, Any] | None = field(default=None)


class Adapter(ABC):
    """Base class for format-specific adapters."""

    @property
    @abstractmethod
    def name(self) -> str:
        """Format name (e.g., 'claude', 'codex', 'gemini')."""
        ...

    @abstractmethod
    def discover_sessions(self, project_dir: Path) -> list[Session]:
        """Find all sessions for this format in the project directory."""
        ...

    @abstractmethod
    def read_events(self, session: Session) -> Iterator[Event]:
        """Stream AG-UI events from a session."""
        ...

    @abstractmethod
    def write_events(self, events: Iterable[Event], dest: IO[str]) -> None:
        """Write AG-UI events back to this format."""
        ...

    def detect(self, project_dir: Path) -> bool:
        """Check if this format was used in the project."""
        return len(self.discover_sessions(project_dir)) > 0

    def read_messages(self, session: Session) -> Iterator[MessageGroup]:
        """Read session as grouped messages (convenience API)."""
        from agentstream.grouper import group_events

        result: Iterator[MessageGroup] = group_events(self.read_events(session))
        return result

    @abstractmethod
    def parse_source_entry(
        self,
        entry: dict,
        entry_index: int,
        session_id: str,
    ) -> list[Event]:
        """Parse a single source entry into AG-UI events.

        Args:
            entry: Parsed JSON from source_entry.entry_content
            entry_index: Position in session (for event ID generation)
            session_id: Session UUID

        Returns:
            List of AG-UI events (may be empty)
        """
        ...

    # === Path Detection (for daemon watcher) ===

    @abstractmethod
    def get_base_directories(self) -> list[Path]:
        """Return base directories where this agent stores sessions.

        Platform-specific paths should be handled here.
        Returns directories that may or may not exist.
        """
        ...

    @abstractmethod
    def matches_path(self, path: Path) -> bool:
        """Return True if the given path belongs to this agent.

        Used for format detection from file paths.
        """
        ...

    def get_session_id(self, path: Path) -> str:
        """Extract session ID from a file path.

        Default implementation returns filename stem.
        Cursor overrides to handle composite IDs.
        """
        return path.stem

    def extract_sessions_from_file(self, path: Path) -> list[dict]:
        """Extract session info from a changed file (for daemon watcher).

        Default implementation returns single session using get_session_id().
        Cursor overrides to return multiple composers from one file.
        """
        return [
            {
                "id": self.get_session_id(path),
                "path": path,
                "format": self.name,
            }
        ]

    # === Raw Entry Reading (for incremental sync) ===

    @abstractmethod
    def read_entries(self, session: Session) -> list[dict]:
        """Read all raw source entries from a session.

        Returns:
            List of entry dicts with: entry_index, entry_content, entry_timestamp_ms
        """
        ...

    def read_entries_after(
        self,
        session: Session,
        after_index: int = -1,
    ) -> list[dict]:
        """Read entries after given index (for incremental sync).

        Default implementation reads all and filters.
        Subclasses can override for efficiency.
        """
        entries = self.read_entries(session)
        return [e for e in entries if e["entry_index"] > after_index]

    def enrich_entries(self, entries: list[dict], session: Session) -> list[dict]:
        """Enrich entries with additional computed data.

        Override in subclasses to add computed fields to entries before sync.
        For example, CursorAdapter resolves content IDs and computes diffs.

        Default implementation returns entries unchanged.
        """
        return entries
