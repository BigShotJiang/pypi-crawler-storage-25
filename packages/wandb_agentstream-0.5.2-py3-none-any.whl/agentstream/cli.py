"""CLI for agentstream - view and debug agent sessions."""

from __future__ import annotations

import argparse
import json
import sys
import webbrowser
from datetime import UTC, datetime
from functools import partial
from http.server import HTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, urlparse

import agentstream
from agentstream.adapters.base import Session

# Try to import the viewer HTML
_VIEWER_HTML: str | None = None


def _load_viewer_html() -> str:
    """Load the embedded viewer HTML."""
    global _VIEWER_HTML
    if _VIEWER_HTML is not None:
        return _VIEWER_HTML

    # Look for viewer.html in the package directory
    viewer_path = Path(__file__).parent / "viewer.html"
    if viewer_path.exists():
        _VIEWER_HTML = viewer_path.read_text()
        return _VIEWER_HTML

    raise FileNotFoundError("viewer.html not found. Please ensure it's installed with the package.")


class ViewerState:
    """Holds state for the viewer server."""

    def __init__(
        self,
        project_dir: Path,
        sessions: list[Session],
        current_session: Session,
    ) -> None:
        self.project_dir = project_dir
        self.sessions = sessions
        self.current_session = current_session
        self.all_events: list[dict[str, Any]] = []

    def load_session(self, session: Session) -> None:
        """Load events from a session."""
        self.current_session = session
        self.all_events = []
        for event in agentstream.read_events(session):
            self.all_events.append(event.model_dump(mode="json", by_alias=True))

    def sessions_json(self) -> list[dict[str, Any]]:
        """Return sessions as JSON-serializable list."""
        result = []
        for s in self.sessions:
            started_at = datetime.fromtimestamp(s.modified_at, tz=UTC)
            result.append(
                {
                    "id": s.id,
                    "agent": s.format,
                    "startedAt": started_at.isoformat(),
                    "isCurrent": s.id == self.current_session.id,
                }
            )
        return result

    def find_session(self, session_id: str) -> Session | None:
        """Find a session by ID."""
        for s in self.sessions:
            if s.id == session_id:
                return s
        return None


class ViewerHandler(SimpleHTTPRequestHandler):
    """HTTP handler for the viewer server."""

    state: ViewerState

    def __init__(self, *args: Any, state: ViewerState, **kwargs: Any) -> None:
        self.state = state
        super().__init__(*args, **kwargs)

    def log_message(self, format: str, *args: Any) -> None:
        """Suppress default logging."""
        pass

    def do_GET(self) -> None:
        """Handle GET requests."""
        parsed = urlparse(self.path)
        path = parsed.path
        query = parse_qs(parsed.query)

        if path == "/" or path == "":
            self._serve_viewer()
        elif path == "/events":
            self._serve_events(query)
        elif path == "/sessions":
            self._serve_sessions()
        elif path == "/source":
            self._serve_source()
        elif path == "/transform":
            self._serve_transform(query)
        else:
            self._send_json_error(404, "Not Found")

    def _send_json(self, data: Any) -> None:
        """Send JSON response."""
        content = json.dumps(data).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(content)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(content)

    def _send_html(self, html: str) -> None:
        """Send HTML response."""
        content = html.encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(content)))
        self.end_headers()
        self.wfile.write(content)

    def _send_text(self, text: str, content_type: str = "text/plain") -> None:
        """Send text response."""
        content = text.encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(content)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(content)

    def _send_json_error(self, code: int, message: str) -> None:
        """Send JSON error response."""
        content = json.dumps({"error": message, "code": code}).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(content)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(content)

    def _serve_viewer(self) -> None:
        """Serve the main viewer HTML with embedded data."""
        try:
            html_template = _load_viewer_html()
        except FileNotFoundError as e:
            self.send_error(500, str(e))
            return

        # Prepare session info
        session_info = {
            "id": self.state.current_session.id,
            "agent": self.state.current_session.format,
        }

        # Create embedded script
        # Escape </ sequences to prevent script tag injection
        # This is the standard way to safely embed JSON in HTML script tags
        events_json = json.dumps(self.state.all_events).replace("</", "<\\/")
        session_json = json.dumps(session_info).replace("</", "<\\/")
        sessions_json = json.dumps(self.state.sessions_json()).replace("</", "<\\/")

        embedded_script = f"""<script>
        window.EMBEDDED_EVENTS = {events_json};
        window.SESSION_INFO = {session_json};
        window.SESSIONS_LIST = {sessions_json};
    </script>"""

        # Inject embedded data (the template has a placeholder)
        html = html_template.replace("<!-- EMBEDDED_DATA -->", embedded_script)

        self._send_html(html)

    def _serve_events(self, query: dict[str, list[str]]) -> None:
        """Serve events endpoint with optional session switching."""
        # Check for session switch
        requested_id = query.get("session", [None])[0]
        if requested_id and requested_id != self.state.current_session.id:
            new_session = self.state.find_session(requested_id)
            if new_session is None:
                self.send_error(404, f"Session not found: {requested_id}")
                return
            self.state.load_session(new_session)
            print(
                f"Switched to session {new_session.id} ({new_session.format}), "
                f"{len(self.state.all_events)} events"
            )

        session_info = {
            "id": self.state.current_session.id,
            "agent": self.state.current_session.format,
        }

        self._send_json(
            {
                "events": self.state.all_events,
                "session": session_info,
                "sessions": self.state.sessions_json(),
            }
        )

    def _serve_sessions(self) -> None:
        """Serve sessions list."""
        self._send_json(self.state.sessions_json())

    def _serve_source(self) -> None:
        """Serve the original log file content."""
        try:
            content = self.state.current_session.path.read_text()
            # Use appropriate content type
            if self.state.current_session.format == "gemini":
                content_type = "application/json"
            else:
                content_type = "application/x-ndjson"
            self._send_text(content, content_type)
        except Exception as e:
            self._send_json_error(500, f"Failed to read source file: {e}")

    def _serve_transform(self, query: dict[str, list[str]]) -> None:
        """Transform AG-UI events back to a target format."""
        import io

        from agentstream.events import event_from_dict

        format_name = query.get("format", ["claude"])[0]

        # Get the adapter for the target format
        adapter = agentstream.get_adapter(format_name)
        if adapter is None:
            self._send_json_error(400, f"Unknown format: {format_name}")
            return

        try:
            # Convert the stored events back to Event objects
            events = []
            for event_dict in self.state.all_events:
                try:
                    event = event_from_dict(event_dict)
                    events.append(event)
                except Exception:
                    continue  # Skip events that can't be reconstructed

            # Write events to the target format
            output = io.StringIO()
            adapter.write_events(events, output)
            content = output.getvalue()

            # Determine content type
            content_type = "application/json" if format_name == "gemini" else "application/x-ndjson"

            self._send_text(content, content_type)
        except Exception as e:
            self._send_json_error(500, f"Transform failed: {e}")


def run_viewer(state: ViewerState, port: int, no_browser: bool = False) -> None:
    """Run the viewer HTTP server."""
    handler = partial(ViewerHandler, state=state)
    server = HTTPServer(("0.0.0.0", port), handler)

    url = f"http://localhost:{port}"
    print(f"\nEvent Stream Viewer running at {url}")
    print("Press Ctrl+C to stop")

    # Open browser automatically unless --no-browser was passed
    if not no_browser:
        webbrowser.open(url)

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nShutting down server...")
    finally:
        server.server_close()
        print("Server stopped")


def list_sessions_cmd(sessions: list[Session]) -> None:
    """List all discovered sessions."""
    print("\nSessions:")
    for s in sessions:
        ts = datetime.fromtimestamp(s.modified_at)
        print(f"  [{s.format}] {s.id} - {ts.strftime('%Y-%m-%d %H:%M:%S')}")


def list_web_sessions_cmd(synced_ids: set[str] | None = None) -> None:
    """List web sessions from Claude Code cloud API.

    Args:
        synced_ids: Set of session IDs that have been synced (for status display).
    """
    import asyncio

    from agentstream.remote import (
        WebSessionsClient,
        has_claude_credentials,
        read_claude_credentials,
    )

    # Check for credentials
    if not has_claude_credentials():
        print("\nNo Claude credentials found.")
        print("Web sessions require Claude Code to be installed and authenticated.")
        print("\nTo authenticate:")
        print("  1. Install Claude Code: https://claude.ai/code")
        print("  2. Run: claude login")
        return

    creds = read_claude_credentials()
    if not creds:
        print("\nFailed to read Claude credentials.")
        return

    if creds.is_expired:
        print("\nClaude credentials are expired.")
        print("Please re-authenticate with: claude login")
        return

    # Fetch sessions
    print("\nFetching web sessions from Claude API...")

    async def fetch_sessions():
        client = WebSessionsClient(credentials=creds)
        return await client.list_sessions(limit=50)

    try:
        sessions = asyncio.run(fetch_sessions())
    except Exception as e:
        print(f"\nError fetching sessions: {e}")
        return

    if not sessions:
        print("No web sessions found.")
        return

    synced_ids = synced_ids or set()

    print(f"\nWeb Sessions ({len(sessions)} total):")
    print("-" * 70)

    for session in sessions:
        # Format timestamps
        updated = ""
        if session.updated_at:
            updated = session.updated_at.strftime("%Y-%m-%d %H:%M")
        elif session.created_at:
            updated = session.created_at.strftime("%Y-%m-%d %H:%M")

        # Sync status
        status = "✓ synced" if session.id in synced_ids else "○ pending"

        # Session name (truncated)
        name = session.name or "(unnamed)"
        if len(name) > 30:
            name = name[:27] + "..."

        # Project path (truncated)
        project = session.project_path or ""
        if len(project) > 25:
            project = "..." + project[-22:]

        print(f"  {status}  {updated}  {name:<30}  {project}")

    print("-" * 70)
    synced_count = len([s for s in sessions if s.id in synced_ids])
    print(f"  {synced_count}/{len(sessions)} sessions synced")


def replay_session_cmd(session: Session) -> None:
    """Replay a session to stdout as JSON events."""
    print(f"\nReplaying session {session.id} ({session.format})...\n")

    for event in agentstream.read_events(session):
        data = event.model_dump(mode="json", by_alias=True)
        print(json.dumps(data, indent=2))

    print("\nReplay complete.")


def main() -> None:
    """Main CLI entry point."""
    parser = argparse.ArgumentParser(
        description="agentstream - View and debug AI agent sessions",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  agentstream                    # Serve viewer for most recent session
  agentstream --list             # List all discovered sessions
  agentstream --session <id>     # View specific session
  agentstream --file log.jsonl   # View a specific log file
  agentstream --port 9000        # Use custom port
        """,
    )

    parser.add_argument(
        "--dir",
        "-d",
        type=str,
        default=None,
        help="Project directory (default: current)",
    )
    parser.add_argument(
        "--list",
        "-l",
        action="store_true",
        help="List available sessions",
    )
    parser.add_argument(
        "--web-sessions",
        "-w",
        action="store_true",
        help="List web sessions from Claude Code cloud API",
    )
    parser.add_argument(
        "--session",
        "-s",
        type=str,
        default=None,
        help="Specific session ID to view",
    )
    parser.add_argument(
        "--file",
        "-f",
        type=str,
        default=None,
        help="Direct path to a log file (bypasses discovery)",
    )
    parser.add_argument(
        "--agent",
        "-a",
        type=str,
        default="claude",
        help="Agent type when using --file (default: claude)",
    )
    parser.add_argument(
        "--port",
        "-p",
        type=int,
        default=8080,
        help="Port for the web viewer (default: 8080)",
    )
    parser.add_argument(
        "--replay",
        "-r",
        action="store_true",
        help="Replay session to stdout instead of serving viewer",
    )
    parser.add_argument(
        "--no-browser",
        action="store_true",
        help="Don't open browser automatically",
    )
    parser.add_argument(
        "--dev",
        action="store_true",
        help="Development mode: auto-reload on code changes",
    )

    args = parser.parse_args()

    # Handle dev mode with auto-reload
    if args.dev:
        try:
            import hupper
        except ImportError:
            print(
                "Error: --dev requires 'hupper' package. Install with: pip install hupper",
                file=sys.stderr,
            )
            sys.exit(1)

        # Check if we're already in a reloader worker process
        if not hupper.is_active():
            print("Starting dev server with auto-reload...")
            # Start the reloader, which will re-exec this process
            reloader = hupper.start_reloader(
                "agentstream.cli.main",
                reload_interval=1,
            )
            # Monitor the agentstream package directory
            pkg_dir = Path(__file__).parent
            reloader.watch_files([str(pkg_dir / "*.py"), str(pkg_dir / "**/*.py")])
            return

    # Handle web sessions listing
    if args.web_sessions:
        list_web_sessions_cmd()
        return

    # Determine project directory
    project_dir = Path(args.dir) if args.dir else Path.cwd()
    project_dir = project_dir.resolve()

    # Handle direct file mode
    if args.file:
        file_path = Path(args.file).resolve()
        if not file_path.exists():
            print(f"Error: file not found: {file_path}", file=sys.stderr)
            sys.exit(1)

        # Create session from file
        file_session = Session(
            id=file_path.stem,
            path=file_path,
            format=args.agent,
            modified_at=file_path.stat().st_mtime,
        )

        print(f"Loading log file: {file_path} (agent: {args.agent})")

        if args.replay:
            replay_session_cmd(file_session)
            return

        # Serve viewer for direct file
        state = ViewerState(
            project_dir=project_dir,
            sessions=[file_session],
            current_session=file_session,
        )
        state.load_session(file_session)

        print(f"Collected {len(state.all_events)} events")
        run_viewer(state, args.port, args.no_browser)
        return

    # Discover sessions
    sessions = agentstream.discover_sessions(project_dir)

    if not sessions:
        print(f"No agent sessions found in {project_dir}")
        sys.exit(0)

    # Detect agents
    agents = set(s.format for s in sessions)
    print(f"Detected agents: {', '.join(sorted(agents))}")

    # List sessions
    if args.list:
        list_sessions_cmd(sessions)
        sys.exit(0)

    # Find session to use
    session: Session | None = None
    if args.session:
        for s in sessions:
            if s.id == args.session:
                session = s
                break
        if session is None:
            print(f"Session not found: {args.session}", file=sys.stderr)
            sys.exit(1)
    else:
        session = sessions[0]  # Most recent

    # At this point session is guaranteed to be set
    assert session is not None

    # Replay mode
    if args.replay:
        replay_session_cmd(session)
        return

    # Serve viewer
    print(f"Collecting events for session {session.id} ({session.format})...")

    state = ViewerState(
        project_dir=project_dir,
        sessions=sessions,
        current_session=session,
    )
    state.load_session(session)

    print(f"Collected {len(state.all_events)} events")
    print(f"Found {len(sessions)} total sessions")

    run_viewer(state, args.port, args.no_browser)


if __name__ == "__main__":
    main()
