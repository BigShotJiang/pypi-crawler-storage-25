# Changelog

## 0.4.0 (2026-04-24)

Full Changelog: [v0.3.0...v0.4.0](https://github.com/Ramensoft/handinger-python/compare/v0.3.0...v0.4.0)

### Features

* **api:** api update ([722b936](https://github.com/Ramensoft/handinger-python/commit/722b9365126e1c2debf74a985ea978e336bb65c5))

## 0.3.0 (2026-04-23)

Full Changelog: [v0.2.2...v0.3.0](https://github.com/Ramensoft/handinger-python/compare/v0.2.2...v0.3.0)

### Features

* **api:** api update ([fab9326](https://github.com/Ramensoft/handinger-python/commit/fab9326eed48717ff8eafdda8474fc6e476c5105))

## 0.2.2 (2026-04-23)

Full Changelog: [v0.2.1...v0.2.2](https://github.com/Ramensoft/handinger-python/compare/v0.2.1...v0.2.2)

### Chores

* update SDK settings ([b7dc9d2](https://github.com/Ramensoft/handinger-python/commit/b7dc9d2a388c325831e8bbdc568a94e3e05ebcc8))
* update SDK settings ([afcd0a1](https://github.com/Ramensoft/handinger-python/commit/afcd0a18fd1b1236e8dfc8728366ce4429832989))

## 0.2.1 (2026-04-23)

Full Changelog: [v0.2.0...v0.2.1](https://github.com/Ramensoft/handinger-python/compare/v0.2.0...v0.2.1)

### Chores

* update SDK settings ([eb223b1](https://github.com/Ramensoft/handinger-python/commit/eb223b19878f2800ac0cfb9d1529357955f18726))
* update SDK settings ([7eff928](https://github.com/Ramensoft/handinger-python/commit/7eff928746fa65ccd0cb796be090690abb06d914))

## 0.2.0 (2026-04-23)

Full Changelog: [v0.1.1...v0.2.0](https://github.com/Ramensoft/handinger-python/compare/v0.1.1...v0.2.0)

### Features

* **api:** api update ([b47e93d](https://github.com/Ramensoft/handinger-python/commit/b47e93dcec3a5e2351c191b9152eaeffeb92c963))

## 0.1.1 (2026-04-23)

Full Changelog: [v0.1.0...v0.1.1](https://github.com/Ramensoft/handinger-python/compare/v0.1.0...v0.1.1)

### Chores

* update SDK settings ([3673338](https://github.com/Ramensoft/handinger-python/commit/367333821bee665e73d1e23bca5652985b2e0611))
* update SDK settings ([e3ba9d8](https://github.com/Ramensoft/handinger-python/commit/e3ba9d86450ba05612a2903bfd474fc969be31ad))

## 0.1.0 (2026-04-23)

Full Changelog: [v0.0.3...v0.1.0](https://github.com/Ramensoft/handinger-python/compare/v0.0.3...v0.1.0)

### Features

* **api:** api update ([881f236](https://github.com/Ramensoft/handinger-python/commit/881f236eecb3875877977df7d362ab8314612193))

## 0.0.3 (2026-04-23)

Full Changelog: [v0.0.2...v0.0.3](https://github.com/Ramensoft/handinger-python/compare/v0.0.2...v0.0.3)

### Chores

* update SDK settings ([0450d81](https://github.com/Ramensoft/handinger-python/commit/0450d81b1f7168eae3e46ac9563e25e019a4a453))
* update SDK settings ([929f910](https://github.com/Ramensoft/handinger-python/commit/929f910a6f1b74d5a3c3b5362dbc39a8b7326443))

## 0.0.2 (2026-04-23)

Full Changelog: [v0.0.1...v0.0.2](https://github.com/Ramensoft/handinger-python/compare/v0.0.1...v0.0.2)

### Chores

* **internal:** more robust bootstrap script ([609a909](https://github.com/Ramensoft/handinger-python/commit/609a909f8625a01865084184696e3110e5f6969f))
* update SDK settings ([6f99c36](https://github.com/Ramensoft/handinger-python/commit/6f99c36941ab583b5be40910011fc0506b860187))
* update SDK settings ([49f39ef](https://github.com/Ramensoft/handinger-python/commit/49f39ef89ced5dbe77958b5d827c4cedaf0d58a2))
* update SDK settings ([6c879d1](https://github.com/Ramensoft/handinger-python/commit/6c879d1b80509df4e3c9416092a6eefce4db1379))
* update SDK settings ([bb5a978](https://github.com/Ramensoft/handinger-python/commit/bb5a97895e07687ff8a15b24d17dc970de15d53e))
