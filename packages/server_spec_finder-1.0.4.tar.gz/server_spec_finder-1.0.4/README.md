# server-spec-finder

Dependency-free DevOps audit toolkit for Linux and Windows.

No pip packages required to run. Python 3.8+ only.

```bash
pip install server-spec-finder
```

## Commands

### System check — OS, CPU, RAM, disks, ports, services, Docker

```bash
spec-system
```

Writes `system-spec-report.json / .md / .xlsx / .pdf` to the current directory.

```bash
spec-system --json /tmp/sys.json --markdown /tmp/sys.md --quiet
```

### Repo check — runtimes, ports, env vars, routes, OpenAPI

```bash
spec-repo /path/to/your/server/repos
```

Writes `server-spec-report.json / .md / .xlsx / .pdf`.

```bash
# Scan a single repo
spec-repo /path/to/DMS-Server-Drive

# Include real .env files (local audit only)
spec-repo . --include-dotenv

# Scan every child folder, not only likely server repos
spec-repo . --all

# Write all formats quietly
spec-repo . --json out.json --markdown out.md --excel out.xlsx --pdf out.pdf --quiet
```

## Output formats

Each command writes four files:

| Format | Best for |
|---|---|
| `.json` | Automation, CI pipelines |
| `.md` | Code review, documentation |
| `.xlsx` | Sharing with non-technical stakeholders |
| `.pdf` | Printable handoff reports |

The Excel file contains separate sheets (Summary, Routes, Environment, Ports, Health).

## Desktop App (Linux / Windows)

A GUI wrapping both tools is available in the repository with System Check, Repo Check, and Network Speed tabs.

```bash
git clone https://github.com/Premkumar-CM/server-spec-finder
cd "server-spec-finder/specification check"
python3 app.py
```

Build a single standalone executable:

```bash
bash build.sh          # Linux  → dist/spec-checker
build.bat              # Windows CMD → dist\spec-checker.exe
```

## Drop-in usage (no pip install)

Copy the `specification check` folder into any server repo and run:

```bash
python3 system_spec_finder.py
python3 server_spec_finder.py /path/to/repos
```

## Notes

- Static analysis only — does not start services or call live endpoints
- Real `.env` files are skipped by default; sensitive-looking values are redacted
- Dynamic route registration and computed paths may need manual review; the JSON output includes file and line references for easy inspection

## License

MIT
