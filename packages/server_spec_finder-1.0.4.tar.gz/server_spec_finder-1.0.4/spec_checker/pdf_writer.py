"""Dependency-free PDF generator for spec reports.

Produces A4 PDFs with: coloured banner header, bold section titles,
styled tables (shaded header + alternating rows), key-value grids,
and enterprise checklist layouts with checkboxes.
No external libraries required.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

# ── Page geometry ──────────────────────────────────────────────────────────────
_W, _H   = 595, 842          # A4 points
_ML, _MR = 40, 555           # left / right content bounds
_MB      = 50                # bottom margin

# ── Colour palette (PDF "r g b rg" format, 0-1 range) ─────────────────────────
_C = {
    "banner": "0.094 0.310 0.788",   # deep blue header
    "accent": "0.145 0.392 0.922",   # section titles
    "dark":   "0.118 0.161 0.235",   # body text
    "muted":  "0.392 0.455 0.553",   # label text
    "border": "0.800 0.840 0.878",   # table borders
    "thead":  "0.878 0.910 0.930",   # table header bg / label cells
    "talt":   "0.965 0.976 0.984",   # alternating row bg
    "white":  "1.000 1.000 1.000",
    "lblue":  "0.750 0.850 1.000",   # subtitle on banner
    "navy":   "0.071 0.192 0.471",   # checklist section header
    "lgreen": "0.886 0.937 0.855",   # checked cell bg
    "gtext":  "0.216 0.467 0.224",   # checked text
    "grey":   "0.502 0.502 0.502",   # unchecked text
}


def _esc(text: str) -> str:
    """Escape text for a PDF string literal and cap length."""
    return (
        str(text)
        .replace("\\", "\\\\")
        .replace("(", "\\(")
        .replace(")", "\\)")
        .replace("\n", " ")
        .replace("\r", "")
    )[:110]


class PDF:
    """Build a multi-page A4 PDF with tables, sections, key-value grids,
    and enterprise checklist layouts."""

    def __init__(self, title: str, subtitle: str = "") -> None:
        self._title    = title
        self._subtitle = subtitle
        self._pages: list[list[str]] = []
        self._ops:   list[str]       = []
        self._y      = 0.0
        self._start_page()

    # ── Page management ───────────────────────────────────────────────────────

    def _start_page(self, continued: bool = False) -> None:
        self._ops = []
        self._pages.append(self._ops)
        self._y = float(_H - 68)
        self._banner(continued)

    def _need(self, height: float) -> None:
        """Start a new page if there is not enough vertical space."""
        if self._y - height < _MB:
            self._start_page(continued=True)

    # ── Banner ────────────────────────────────────────────────────────────────

    def _banner(self, continued: bool) -> None:
        label = self._title if not continued else f"{self._title} (continued)"
        self._ops.append(f"{_C['banner']} rg 0 {_H - 48} {_W} 48 re f")
        self._ops.append(
            f"BT {_C['white']} rg /F2 13 Tf 40 {_H - 28:.0f} Td ({_esc(label)}) Tj ET"
        )
        if self._subtitle and not continued:
            self._ops.append(
                f"BT {_C['lblue']} rg /F1 7.5 Tf 40 {_H - 42:.0f} Td ({_esc(self._subtitle)}) Tj ET"
            )
        self._ops.append(f"{_C['dark']} rg")

    # ── Primitives ────────────────────────────────────────────────────────────

    def _fill(self, x: float, y: float, w: float, h: float, col: str) -> None:
        self._ops.append(f"{col} rg {x:.1f} {y:.1f} {w:.1f} {h:.1f} re f {_C['dark']} rg")

    def _stroke(self, x: float, y: float, w: float, h: float,
                col: str, lw: float = 0.3) -> None:
        self._ops.append(
            f"{lw:.2f} w {col} RG {x:.1f} {y:.1f} {w:.1f} {h:.1f} re S {_C['dark']} RG"
        )

    def _hline(self, x1: float, y: float, x2: float,
               col: str = "", lw: float = 0.3) -> None:
        col = col or _C["border"]
        self._ops.append(
            f"{lw:.2f} w {col} RG {x1:.1f} {y:.1f} m {x2:.1f} {y:.1f} l S {_C['dark']} RG"
        )

    def _txt(self, x: float, y: float, text: str,
             font: str = "F1", size: float = 8.5,
             col: str = "") -> None:
        c   = f"{col} rg " if col else ""
        rst = f" {_C['dark']} rg" if col else ""
        self._ops.append(
            f"BT {c}/{font} {size} Tf {x:.1f} {y:.1f} Td ({_esc(text)}) Tj ET{rst}"
        )

    # ── Checklist primitives ──────────────────────────────────────────────────

    def _checkbox(self, x: float, y_center: float, checked: bool,
                  size: float = 7.0) -> None:
        """Draw a checkbox.  y_center is the PDF vertical midpoint of the cell."""
        yb = y_center - size / 2
        # Outer box
        self._ops.append(
            f"0.30 w {_C['border']} RG {x:.1f} {yb:.1f} {size:.1f} {size:.1f} re S"
        )
        if checked:
            inner = size - 1.0
            self._ops.append(
                f"{_C['lgreen']} rg "
                f"{x+0.5:.1f} {yb+0.5:.1f} {inner:.1f} {inner:.1f} re f"
            )
            # checkmark (two segments)
            px1, py1 = x + 1.2,          yb + size * 0.48
            px2, py2 = x + size * 0.40,  yb + 1.5
            px3, py3 = x + size - 1.2,   yb + size - 1.5
            self._ops.append(
                f"1.1 w {_C['gtext']} RG "
                f"{px1:.1f} {py1:.1f} m {px2:.1f} {py2:.1f} l "
                f"{px3:.1f} {py3:.1f} l S"
            )
        self._ops.append(f"{_C['dark']} rg {_C['dark']} RG 0.3 w")

    # ── High-level elements (existing) ────────────────────────────────────────

    def section(self, title: str) -> None:
        """Bold blue section heading with underline."""
        self._need(28)
        self._y -= 8
        self._txt(_ML, self._y, title.upper(), "F2", 8.5, _C["accent"])
        self._y -= 5
        self._hline(_ML, self._y, _MR, _C["accent"], 0.7)
        self._y -= 13

    def kv(self, items: list[tuple[str, str]], cols: int = 2) -> None:
        """Render (label, value) pairs in a multi-column grid."""
        col_w   = (_MR - _ML) / cols
        label_w = col_w * 0.40
        for i, (key, val) in enumerate(items):
            if i % cols == 0:
                self._need(14)
            col = i % cols
            x   = _ML + col * col_w
            self._txt(x, self._y, str(key) + ":", "F2", 8, _C["muted"])
            self._txt(x + label_w, self._y, str(val)[:72], "F1", 8)
            if col == cols - 1 or i == len(items) - 1:
                self._y -= 13

    def table(self,
              headers: list[str],
              rows:    list[list],
              widths:  Optional[list[float]] = None) -> None:
        """Styled table: shaded header, alternating rows, grid lines."""
        if not headers:
            return
        cw = _MR - _ML
        if widths is None:
            w = cw / len(headers)
            widths = [w] * len(headers)

        ROW_H: float = 14.0
        HDR_H: float = 16.0

        def _draw_header() -> None:
            self._fill(_ML, self._y - HDR_H, cw, HDR_H, _C["thead"])
            x = _ML
            for h, w in zip(headers, widths):
                self._txt(x + 4, self._y - 12, str(h), "F2", 8)
                x += w
            self._stroke(_ML, self._y - HDR_H, cw, HDR_H, _C["border"], 0.3)
            self._y -= HDR_H

        self._need(HDR_H + min(len(rows), 4) * ROW_H)
        _draw_header()

        for i, row in enumerate(rows):
            if self._y - ROW_H < _MB:
                self._start_page(continued=True)
                _draw_header()
            if i % 2 == 1:
                self._fill(_ML, self._y - ROW_H, cw, ROW_H, _C["talt"])
            x = _ML
            for cell, w in zip(row, widths):
                self._txt(x + 4, self._y - 10.5, str(cell), "F1", 7.5)
                x += w
            self._hline(_ML, self._y - ROW_H, _MR, _C["border"], 0.2)
            self._y -= ROW_H

        self._y -= 10

    def spacer(self, h: float = 8.0) -> None:
        self._y -= h

    # ── Checklist high-level elements ─────────────────────────────────────────

    def cl_info_boxes(self, items: List[Tuple[str, str]],
                      row_h: float = 24) -> None:
        """Header row of bordered (label : value) boxes — Product Name, Client Code, etc."""
        self._need(row_h)
        cw    = _MR - _ML
        box_w = cw / max(len(items), 1)
        yb    = self._y - row_h

        for i, (key, val) in enumerate(items):
            x   = _ML + i * box_w
            lw  = box_w * 0.42
            vw  = box_w - lw
            self._fill(x, yb, lw, row_h, _C["thead"])
            self._stroke(x, yb, box_w, row_h, _C["border"], 0.5)
            self._txt(x + 4, yb + 7, str(key), "F2", 8)
            self._fill(x + lw, yb, vw, row_h, _C["white"])
            if val:
                self._txt(x + lw + 4, yb + 7, str(val)[:30], "F1", 8.5)
        self._y -= row_h

    def cl_section(self, label: str, row_h: float = 20) -> None:
        """Full-width dark-navy checklist section header."""
        self._need(row_h + 6)
        self._y -= 6
        yb = self._y - row_h
        cw = _MR - _ML
        self._fill(_ML,     yb, cw,  row_h, _C["navy"])
        self._fill(_ML,     yb, 5,   row_h, _C["banner"])   # left accent strip
        self._txt(_ML + 10, yb + 6,  label.upper(), "F2", 8.5, _C["white"])
        self._y -= row_h + 2

    def cl_check_row(self, label: str,
                     options: List[Tuple[str, bool]],
                     label_w: float = 140,
                     row_h:   float = 18) -> None:
        """Label cell + a series of checkbox-option cells."""
        self._need(row_h)
        n     = max(len(options), 1)
        opt_w = (_MR - _ML - label_w) / n
        yb    = self._y - row_h
        yc    = yb + row_h / 2          # vertical centre for checkbox

        self._fill(_ML, yb, label_w, row_h, _C["thead"])
        self._stroke(_ML, yb, label_w, row_h, _C["border"], 0.3)
        self._txt(_ML + 5, yb + 5, label, "F2", 8.5)

        for i, (text, checked) in enumerate(options):
            x  = _ML + label_w + i * opt_w
            bg = _C["lgreen"] if checked else _C["white"]
            self._fill(x, yb, opt_w, row_h, bg)
            self._stroke(x, yb, opt_w, row_h, _C["border"], 0.3)
            self._checkbox(x + 4, yc, checked)
            col  = _C["gtext"] if checked else _C["grey"]
            font = "F2" if checked else "F1"
            self._txt(x + 14, yb + 5, text, font, 8, col)

        self._y -= row_h

    def cl_kv_row(self, label: str, value: str,
                  label_w: float = 140,
                  row_h:   float = 18,
                  bold_val: bool = False) -> None:
        """Label cell + full-width value cell."""
        self._need(row_h)
        val_w = _MR - _ML - label_w
        yb    = self._y - row_h

        self._fill(_ML, yb, label_w, row_h, _C["thead"])
        self._stroke(_ML, yb, label_w, row_h, _C["border"], 0.3)
        self._txt(_ML + 5, yb + 5, label, "F2", 8.5)

        self._fill(_ML + label_w, yb, val_w, row_h, _C["white"])
        self._stroke(_ML + label_w, yb, val_w, row_h, _C["border"], 0.3)
        self._txt(_ML + label_w + 5, yb + 5, str(value)[:90],
                  "F2" if bold_val else "F1", 8.5)
        self._y -= row_h

    def cl_two_panel(self,
                     left_title:  str,
                     left_rows:   List[Any],
                     right_title: str,
                     right_rows:  List[Any],
                     row_h:  float = 17,
                     hdr_h:  float = 19) -> None:
        """Two side-by-side panels rendered in parallel rows.

        Each row element is one of:
          (label, value_str)          → plain label / value
          (label, [(txt, bool), ...]) → label / checkbox options
          ("__SEC__", heading)        → full-width sub-section header inside panel
        """
        gap  = 6
        l_w  = (_MR - _ML - gap) * 0.48
        r_w  = (_MR - _ML - gap) - l_w
        lx   = float(_ML)
        rx   = lx + l_w + gap

        max_r = max(len(left_rows), len(right_rows))
        self._need(hdr_h + min(max_r, 6) * row_h + 8)
        self._y -= 4

        def _hdrs() -> None:
            yb = self._y - hdr_h
            self._fill(lx, yb, l_w, hdr_h, _C["navy"])
            self._fill(rx, yb, r_w, hdr_h, _C["navy"])
            self._fill(lx, yb, 4, hdr_h, _C["banner"])
            self._fill(rx, yb, 4, hdr_h, _C["banner"])
            self._txt(lx + 8, yb + 6, left_title.upper(),  "F2", 8, _C["white"])
            self._txt(rx + 8, yb + 6, right_title.upper(), "F2", 8, _C["white"])
            self._y -= hdr_h

        _hdrs()

        for i in range(max_r):
            if self._y - row_h < _MB:
                self._start_page(continued=True)
                _hdrs()

            yb  = self._y - row_h
            yc  = yb + row_h / 2
            alt = i % 2 == 1

            # ── Left panel ────────────────────────────────────────────────────
            def _draw_panel(px: float, pw: float,
                            rows: List[Any], idx: int) -> None:
                if idx >= len(rows):
                    bg = _C["talt"] if alt else _C["white"]
                    self._fill(px, yb, pw, row_h, bg)
                    self._stroke(px, yb, pw, row_h, _C["border"], 0.2)
                    return
                row = rows[idx]
                lbl = str(row[0]) if row else ""

                if lbl == "__SEC__":
                    sec_txt = str(row[1]) if len(row) > 1 else ""
                    self._fill(px, yb, pw, row_h, _C["navy"])
                    self._fill(px, yb, 3, row_h, _C["banner"])
                    self._txt(px + 6, yb + 5, sec_txt.upper(), "F2", 7.5, _C["white"])
                    return

                rest  = row[1] if len(row) > 1 else ""
                lbl_w = pw * 0.42
                lbg   = _C["talt"] if alt else _C["thead"]

                self._fill(px, yb, lbl_w, row_h, lbg)
                self._stroke(px, yb, lbl_w, row_h, _C["border"], 0.2)
                self._txt(px + 3, yb + 4, lbl, "F2", 7.5)

                if isinstance(rest, list):
                    n_opts = max(len(rest), 1)
                    ow = (pw - lbl_w) / n_opts
                    for j, (otxt, ocheck) in enumerate(rest):
                        ox  = px + lbl_w + j * ow
                        obg = _C["lgreen"] if ocheck else (_C["talt"] if alt else _C["white"])
                        self._fill(ox, yb, ow, row_h, obg)
                        self._stroke(ox, yb, ow, row_h, _C["border"], 0.2)
                        self._checkbox(ox + 3, yc, ocheck, 6)
                        oc = _C["gtext"] if ocheck else _C["grey"]
                        self._txt(ox + 11, yb + 4, str(otxt), "F1", 7, oc)
                else:
                    vbg = _C["talt"] if alt else _C["white"]
                    self._fill(px + lbl_w, yb, pw - lbl_w, row_h, vbg)
                    self._stroke(px + lbl_w, yb, pw - lbl_w, row_h, _C["border"], 0.2)
                    self._txt(px + lbl_w + 3, yb + 4, str(rest)[:40], "F1", 7.5)

            _draw_panel(lx, l_w, left_rows,  i)
            _draw_panel(rx, r_w, right_rows, i)
            self._y -= row_h

        self._y -= 2

    def cl_sw_grid(self, sw: Dict[str, str], row_h: float = 16) -> None:
        """Two-column software detection grid with checkboxes and version strings."""
        expected = ["Docker", "NodeJS", "npm", "Python", "Java", "PHP",
                    "Git", "PostgreSQL", "Redis", "Nginx", "Apache", "MySQL", "MongoDB"]
        merged: Dict[str, str] = {k: "" for k in expected}
        merged.update(sw)
        items = list(merged.items())

        n_cols = 2
        col_w  = (_MR - _ML) / n_cols
        lbl_w  = col_w * 0.28
        chk_w  = col_w * 0.12
        ver_w  = col_w - lbl_w - chk_w

        # Header
        self._need(15)
        yb = self._y - 15
        for ci in range(n_cols):
            x = _ML + ci * col_w
            self._fill(x, yb, col_w, 15, _C["navy"])
            self._txt(x + 4,                    yb + 4, "SOFTWARE",       "F2", 7, _C["white"])
            self._txt(x + lbl_w + 2,            yb + 4, "INSTALLED",      "F2", 7, _C["white"])
            self._txt(x + lbl_w + chk_w + 4,   yb + 4, "VERSION DETAILS","F2", 7, _C["white"])
        self._y -= 15

        for i in range(0, len(items), n_cols):
            self._need(row_h)
            yb  = self._y - row_h
            yc  = yb + row_h / 2
            alt = (i // n_cols) % 2 == 1

            for j in range(n_cols):
                idx = i + j
                x   = _ML + j * col_w
                if idx >= len(items):
                    bg = _C["talt"] if alt else _C["white"]
                    self._fill(x, yb, col_w, row_h, bg)
                    self._stroke(x, yb, col_w, row_h, _C["border"], 0.2)
                    continue

                name, ver = items[idx]
                detected  = bool(ver)
                lbg = _C["talt"] if alt else _C["thead"]
                vbg = _C["talt"] if alt else _C["white"]
                cbg = _C["lgreen"] if detected else vbg

                self._fill(x,              yb, lbl_w, row_h, lbg)
                self._stroke(x,            yb, lbl_w, row_h, _C["border"], 0.2)
                self._txt(x + 3,           yb + 4, name, "F2", 7.5)

                self._fill(x + lbl_w,      yb, chk_w, row_h, cbg)
                self._stroke(x + lbl_w,    yb, chk_w, row_h, _C["border"], 0.2)
                self._checkbox(x + lbl_w + (chk_w - 6) / 2, yc, detected, 6)

                self._fill(x + lbl_w + chk_w, yb, ver_w, row_h, vbg)
                self._stroke(x + lbl_w + chk_w, yb, ver_w, row_h, _C["border"], 0.2)
                short = ver[:46] if ver else "Not detected"
                vc = _C["dark"] if detected else "0.600 0.620 0.640"
                self._txt(x + lbl_w + chk_w + 3, yb + 4, short, "F1", 7, vc)

            self._y -= row_h

    # ── Build PDF file ────────────────────────────────────────────────────────

    def build(self, output: Path) -> None:
        objects: list[bytes] = [
            b"<< /Type /Catalog /Pages 2 0 R >>",
            b"",  # pages — filled below
            b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica"
            b" /Encoding /WinAnsiEncoding >>",
            b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold"
            b" /Encoding /WinAnsiEncoding >>",
        ]

        # Inject transparent watermark at the absolute top z-index layer for all pages
        for ops in self._pages:
            ops.append("q /GS1 gs 0.6 0.6 0.6 rg 0.707 0.707 -0.707 0.707 297.5 421 cm BT /F2 72 Tf -240 -20 Td (CANNYMINDS) Tj ET Q")

        page_ids: list[int] = []
        for ops in self._pages:
            stream = "\n".join(ops).encode("latin-1", errors="replace")
            pid = len(objects) + 1
            cid = pid + 1
            page_ids.append(pid)
            objects.append(
                (
                    f"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 {_W} {_H}] "
                    f"/Resources << /Font << /F1 3 0 R /F2 4 0 R >> "
                    f"/ExtGState << /GS1 << /Type /ExtGState /ca 0.15 /CA 0.15 >> >> >> "
                    f"/Contents {cid} 0 R >>"
                ).encode("ascii")
            )
            objects.append(
                b"<< /Length " + str(len(stream)).encode()
                + b" >>\nstream\n" + stream + b"\nendstream"
            )

        kids = " ".join(f"{p} 0 R" for p in page_ids)
        objects[1] = (
            f"<< /Type /Pages /Kids [{kids}] /Count {len(page_ids)} >>"
        ).encode("ascii")

        body = bytearray(b"%PDF-1.4\n%\xe2\xe3\xcf\xd3\n")
        offsets: list[int] = [0]
        for i, obj in enumerate(objects, 1):
            offsets.append(len(body))
            body.extend(f"{i} 0 obj\n".encode())
            body.extend(obj)
            body.extend(b"\nendobj\n")

        xref = len(body)
        body.extend(f"xref\n0 {len(objects) + 1}\n".encode())
        body.extend(b"0000000000 65535 f \n")
        for off in offsets[1:]:
            body.extend(f"{off:010d} 00000 n \n".encode())
        body.extend(
            f"trailer\n<< /Size {len(objects) + 1} /Root 1 0 R >>"
            f"\nstartxref\n{xref}\n%%EOF\n".encode()
        )

        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_bytes(bytes(body))
