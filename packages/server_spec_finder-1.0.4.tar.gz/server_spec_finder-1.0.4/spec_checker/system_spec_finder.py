#!/usr/bin/env python3
"""Collect real VM/server system specifications — exports a PDF pre-deployment checklist.

Dependency-free. Works on Linux and Windows with Python 3.8+.
"""
from __future__ import annotations

import argparse
import os
import platform
import re
import shutil
import socket
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List

try:
    from .pdf_writer import PDF
except ImportError:
    from pdf_writer import PDF  # type: ignore[no-redef]


# ── Utilities ──────────────────────────────────────────────────────────────────

def now_utc() -> str:
    return datetime.now(timezone.utc).isoformat()


def _run(cmd: List[str], timeout: int = 8) -> str:
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8",
                           errors="replace", timeout=timeout, check=False)
        return (r.stdout or "").strip()
    except Exception:
        return ""


def _run_both(cmd: List[str], timeout: int = 8) -> str:
    """Return stdout+stderr combined (needed for nginx -v, java -version)."""
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8",
                           errors="replace", timeout=timeout, check=False)
        return ((r.stdout or "") + (r.stderr or "")).strip()
    except Exception:
        return ""


def _read(path: str) -> str:
    try:
        return Path(path).read_text(encoding="utf-8", errors="ignore").strip()
    except OSError:
        return ""


def _kv(text: str, sep: str = "=") -> Dict[str, str]:
    out: Dict[str, str] = {}
    for line in text.splitlines():
        if sep not in line:
            continue
        k, v = line.split(sep, 1)
        out[k.strip()] = v.strip().strip('"')
    return out


def _fmt_kb(kb: int) -> str:
    if kb >= 1024 * 1024 * 1024:
        return f"{kb / 1024 / 1024 / 1024:.2f} TiB"
    if kb >= 1024 * 1024:
        return f"{kb / 1024 / 1024:.2f} GiB"
    if kb >= 1024:
        return f"{kb / 1024:.0f} MiB"
    return f"{kb} KiB"


def _fmt_bytes(b: int) -> str:
    if b >= 1024 ** 4:
        return f"{b / 1024 ** 4:.2f} TiB"
    if b >= 1024 ** 3:
        return f"{b / 1024 ** 3:.2f} GiB"
    if b >= 1024 ** 2:
        return f"{b / 1024 ** 2:.0f} MiB"
    return f"{b / 1024:.0f} KiB"


# ── Data collectors ─────────────────────────────────────────────────────────────

def get_host_info() -> Dict[str, Any]:
    hostname = socket.gethostname()
    fqdn = socket.getfqdn()
    addresses = []
    if platform.system() == "Linux":
        out = _run(["ip", "-o", "-4", "addr", "show"])
        for ln in out.splitlines():
            if "127.0.0.1" not in ln:
                m = re.search(r"inet\s+([0-9.]+)", ln)
                if m: addresses.append(m.group(1))
    if not addresses:
        addresses = sorted({
            item[4][0] for item in socket.getaddrinfo(hostname, None)
            if item and item[4] and not item[4][0].startswith("127.")
        })
    import getpass
    return {
        "hostname":     hostname,
        "fqdn":         fqdn,
        "user":         getpass.getuser(),
        "ip_addresses": sorted(set(addresses)),
    }


def get_os_info() -> Dict[str, Any]:
    info: Dict[str, Any] = {
        "system":         platform.system(),
        "release":        platform.release(),
        "machine":        platform.machine(),
        "python_version": platform.python_version(),
    }
    if platform.system() == "Linux":
        rel = _kv(_read("/etc/os-release"))
        info["name"]       = rel.get("PRETTY_NAME") or rel.get("NAME", platform.system())
        info["version_id"] = rel.get("VERSION_ID", "")
        raw = _read("/proc/uptime").split()
        if raw:
            secs = int(float(raw[0]))
            d, rem = divmod(secs, 86400)
            h, rem = divmod(rem, 3600)
            info["uptime"] = f"{d}d {h}h {rem // 60}m"
    elif platform.system() == "Windows":
        vals = _kv(_run(["wmic", "os", "get", "Caption,Version", "/value"]))
        info["name"]       = vals.get("Caption", platform.system())
        info["version_id"] = vals.get("Version", "")
    return info


def get_cpu_info() -> Dict[str, Any]:
    info: Dict[str, Any] = {"logical_cpus": os.cpu_count() or 0}
    if platform.system() == "Linux":
        cpuinfo = _read("/proc/cpuinfo")
        m = re.search(r"^model name\s*:\s*(.+)$", cpuinfo, re.MULTILINE)
        if m:
            info["model"] = m.group(1).strip()
        pids  = set(re.findall(r"^physical id\s*:\s*(\d+)$", cpuinfo, re.MULTILINE))
        cores = re.findall(r"^cpu cores\s*:\s*(\d+)$", cpuinfo, re.MULTILINE)
        if pids and cores:
            info["physical_cores"] = max(len(pids), 1) * int(cores[0])
        info["sockets"] = len(pids) or 1
    elif platform.system() == "Windows":
        vals = _kv(_run(["wmic", "cpu", "get",
                         "Name,NumberOfCores,NumberOfLogicalProcessors", "/value"]))
        info["model"]          = vals.get("Name", "")
        info["physical_cores"] = vals.get("NumberOfCores", "")
    return info


def get_memory_info() -> Dict[str, str]:
    if platform.system() == "Linux":
        m = _kv(_read("/proc/meminfo"), ":")

        def _kb(key: str) -> int:
            raw = m.get(key, "0")
            return int(raw.split()[0]) if raw.split() else 0

        return {
            "total":      _fmt_kb(_kb("MemTotal")),
            "available":  _fmt_kb(_kb("MemAvailable")),
            "swap_total": _fmt_kb(_kb("SwapTotal")),
        }
    if platform.system() == "Windows":
        vals = _kv(_run(["wmic", "OS", "get",
                         "TotalVisibleMemorySize,FreePhysicalMemory", "/value"]))
        return {
            "total":      _fmt_kb(int(vals.get("TotalVisibleMemorySize", 0) or 0)),
            "available":  _fmt_kb(int(vals.get("FreePhysicalMemory", 0) or 0)),
            "swap_total": "—",
        }
    return {"total": "—", "available": "—", "swap_total": "—"}


def get_disks() -> List[Dict[str, str]]:
    disks: List[Dict[str, str]] = []
    if platform.system() == "Linux":
        for line in _run(["df", "-P", "-k"]).splitlines()[1:]:
            parts = line.split()
            if len(parts) < 6:
                continue
            fs, total, used, avail, pct, mount = parts[:6]
            if any(fs.startswith(x) for x in ("tmpfs", "devtmpfs", "udev", "none")):
                continue
            disks.append({
                "filesystem": fs, "mount": mount,
                "total":      _fmt_kb(int(total)),
                "used":       _fmt_kb(int(used)),
                "available":  _fmt_kb(int(avail)),
                "used_pct":   pct,
            })
    elif platform.system() == "Windows":
        for letter in "ABCDEFGHIJKLMNOPQRSTUVWXYZ":
            root = f"{letter}:\\"
            if not Path(root).exists():
                continue
            try:
                u = shutil.disk_usage(root)
                pct = f"{u.used / u.total * 100:.1f}%" if u.total else ""
                disks.append({
                    "filesystem": root, "mount": root,
                    "total":      _fmt_bytes(u.total),
                    "used":       _fmt_bytes(u.used),
                    "available":  _fmt_bytes(u.free),
                    "used_pct":   pct,
                })
            except OSError:
                continue
    return disks


def get_listening_ports() -> List[Dict[str, str]]:
    """Return parsed port list with: port, proto, address, process."""
    raw = ""
    if platform.system() == "Linux":
        raw = _run(["ss", "-tulpn"]) or _run(["netstat", "-tulpn"])
    elif platform.system() == "Windows":
        raw = _run(["netstat", "-ano"])

    ports: List[Dict[str, str]] = []
    seen: set = set()
    for line in raw.splitlines():
        m_local = re.search(r"([\d\.\:\*\[\]]+):(\d+)\s+\S+", line)
        if not m_local:
            continue
        proto_m = re.match(r"^\s*(tcp6?|udp6?)\s", line, re.IGNORECASE)
        proto   = proto_m.group(1).lower() if proto_m else "—"
        addr    = m_local.group(1)
        port    = m_local.group(2)
        proc_m  = re.search(r'(users:\(\("([^"]+)"|LISTEN\s+\d+/([^\s]+))', line)
        proc    = (proc_m.group(2) or proc_m.group(3)) if proc_m else "—"
        if "5432" in port: proc = "CAD Viewer"
        key     = f"{proto}:{port}"
        if key not in seen and port != "0":
            seen.add(key)
            ports.append({"port": port, "proto": proto,
                          "address": addr, "process": proc})
    return sorted(ports, key=lambda x: int(x["port"]))


def get_services() -> List[Dict[str, str]]:
    services: List[Dict[str, str]] = []
    if platform.system() == "Linux":
        out = _run(["systemctl", "list-units", "--type=service", "--state=running",
                    "--no-pager", "--plain"], timeout=12)
        for line in out.splitlines():
            if ".service" not in line:
                continue
            parts = line.split(None, 4)
            if len(parts) >= 4:
                services.append({
                    "name":        parts[0].replace(".service", ""),
                    "state":       parts[2],
                    "sub":         parts[3],
                    "description": parts[4] if len(parts) > 4 else "",
                })
    elif platform.system() == "Windows":
        out = _run(["sc", "query", "state=", "running"], timeout=12)
        cur: Dict[str, str] = {}
        for line in out.splitlines():
            line = line.strip()
            if line.startswith("SERVICE_NAME:"):
                if cur:
                    services.append(cur)
                cur = {"name": line.split(":", 1)[1].strip(),
                       "state": "running", "sub": "", "description": ""}
            elif line.startswith("DISPLAY_NAME:"):
                cur["description"] = line.split(":", 1)[1].strip()
        if cur:
            services.append(cur)
    return services


def get_container_info() -> Dict[str, Any]:
    dver = _run(["docker", "--version"])
    ps   = (_run(["docker", "ps", "--format",
                  "{{.Names}}|{{.Image}}|{{.Status}}|{{.Ports}}"], timeout=12)
            if dver else "")
    pver = _run(["podman", "--version"])
    return {
        "docker":           dver or "—",
        "docker_available": bool(dver),
        "containers":       ps.splitlines() if ps else [],
        "podman":           pver or "—",
        "podman_available": bool(pver),
    }


def get_virtualization_info() -> Dict[str, str]:
    info: Dict[str, str] = {}
    if platform.system() == "Linux":
        det = _run(["systemd-detect-virt"])
        if det and det != "none":
            info["detected"] = det
        for name in ("sys_vendor", "product_name"):
            v = _read(f"/sys/class/dmi/id/{name}")
            if v:
                info[name] = v
    return info


def get_software_info() -> Dict[str, str]:
    """Detect installed software; return {name: version_string}."""
    checks = [
        ("Docker",     ["docker",    "--version"]),
        ("NodeJS",     ["node",      "--version"]),
        ("npm",        ["npm",       "--version"]),
        ("Python",     ["python3",   "--version"]),
        ("Java",       ["java",      "-version"]),
        ("PHP",        ["php",       "--version"]),
        ("Git",        ["git",       "--version"]),
        ("PostgreSQL", ["psql",      "--version"]),
        ("Redis",      ["redis-cli", "--version"]),
        ("Nginx",      ["nginx",     "-v"]),
        ("Apache",     ["apache2",   "-v"]),
        ("MySQL",      ["mysql",     "--version"]),
        ("MongoDB",    ["mongod",    "--version"]),
    ]
    sw: Dict[str, str] = {}
    for name, cmd in checks:
        out = _run_both(cmd).split("\n")[0][:70]
        if out:
            sw[name] = out
    return sw


def get_cloud_provider(virt: Dict[str, str]) -> str:
    vendor = (virt.get("sys_vendor", "") + " " + virt.get("product_name", "")).lower()
    if "amazon" in vendor or "ec2" in vendor:
        return "AWS"
    if "microsoft" in vendor or "azure" in vendor:
        return "Microsoft Azure"
    if "google" in vendor:
        return "GCP"
    if _read("/sys/hypervisor/uuid").lower().startswith("ec2"):
        return "AWS"
    if Path("/usr/bin/waagent").exists() or Path("/var/lib/waagent").exists():
        return "Microsoft Azure"
    if Path("/var/lib/google").exists():
        return "GCP"
    return "On Premises"


def get_vpn_active() -> bool:
    if platform.system() == "Linux":
        return bool(re.search(r"\b(tun\d|tap\d|wg\d|ppp\d|vpn)\b",
                              _run(["ip", "link", "show"])))
    return False


def get_timezone() -> str:
    if platform.system() == "Linux":
        tz = _run(["timedatectl", "show", "--property=Timezone", "--value"])
        return tz or _read("/etc/timezone") or "—"
    return "—"


def get_security_patch() -> str:
    if platform.system() != "Linux":
        return "—"
    out = _run(["apt", "list", "--upgradable"], timeout=15)
    if not out:
        return "—"
    sec = [ln for ln in out.splitlines() if "security" in ln.lower()]
    return f"{len(sec)} security update(s) pending" if sec else "Up to date"


def get_network_speed() -> str:
    latency = "—"
    if platform.system() == "Linux":
        ping = _run(["ping", "-c", "3", "8.8.8.8"], timeout=5)
        m = re.search(r"min/avg/max/mdev = [\d\.]+/([\d\.]+)/", ping)
        if m: latency = f"{m.group(1)} ms"
    try:
        import urllib.request
        url = "https://speed.cloudflare.com/__down?bytes=2000000"
        t0  = time.time()
        urllib.request.urlopen(url, timeout=10).read()
        elapsed = time.time() - t0
        speed = f"{2_000_000 * 8 / elapsed / 1_000_000:.1f} Mbps" if elapsed > 0 else "—"
        return f"{latency} | {speed}"
    except Exception:
        return f"{latency} | —"


def detect_ssl_info() -> tuple[str, str, str]:
    import ssl
    ssl_status = "Not Detected"
    ssl_provider = "—"
    ssl_expiry = "—"

    try:
        context = ssl.create_default_context()
        context.check_hostname = False
        context.verify_mode = ssl.CERT_NONE
        with socket.create_connection(("127.0.0.1", 443), timeout=0.4) as sock:
            with context.wrap_socket(sock, server_hostname="localhost") as ssock:
                ssl_status = "Active / Enabled (Local 443)"
                ssl_provider = "Local Web Server Cert"
    except Exception:
        pass

    if ssl_status == "Not Detected" and platform.system() == "Linux":
        paths = ["/etc/letsencrypt/live", "/etc/ssl/certs", "/etc/nginx/ssl", "/etc/apache2/ssl"]
        for p in paths:
            if Path(p).exists():
                try:
                    files = list(Path(p).glob("**/*"))
                    cert_files = [f for f in files if f.suffix in [".pem", ".crt"]]
                    if cert_files:
                        prov = "Let's Encrypt" if "letsencrypt" in p else "Self-Signed / Internal CA"
                        ssl_status = "Cert Files Detected"
                        ssl_provider = prov
                        
                        if shutil.which("openssl"):
                            cmd = _run(["openssl", "x509", "-enddate", "-noout", "-in", str(cert_files[0])])
                            if "notAfter=" in cmd:
                                ssl_expiry = cmd.split("notAfter=")[1].strip()
                        break
                except Exception:
                    pass
    return ssl_status, ssl_provider, ssl_expiry


def get_logger() -> str:
    if platform.system() == "Linux":
        for svc in ["rsyslog", "syslog-ng", "systemd-journald"]:
            if _run(["systemctl", "is-active", svc]) == "active":
                return svc
    return "Default"


def collect_report() -> Dict[str, Any]:
    host = get_host_info()
    virt = get_virtualization_info()
    ssl_status, ssl_prov, ssl_expiry = detect_ssl_info()
    return {
        "generated_at":   now_utc(),
        "host":           host,
        "os":             get_os_info(),
        "cpu":            get_cpu_info(),
        "memory":         get_memory_info(),
        "disks":          get_disks(),
        "ports":          get_listening_ports(),
        "services":       get_services(),
        "containers":     get_container_info(),
        "virtualization": virt,
        "software":       get_software_info(),
        "cloud":          get_cloud_provider(virt),
        "vpn":            get_vpn_active(),
        "timezone":       get_timezone(),
        "security_patch": get_security_patch(),
        "network_speed":  get_network_speed(),
        "ssl_status":     ssl_status,
        "ssl_provider":   ssl_prov,
        "ssl_expiry":     ssl_expiry,
        "logger":         get_logger(),
    }


# ── PDF builder ────────────────────────────────────────────────────────────────

def write_pdf(report: Dict[str, Any], output: Path,
              product: str = "", client_code: str = "", client_name: str = "",
              gen_user: str = "", role: str = "Web Server", env: str = "Production") -> None:
    host       = report["host"]
    os_        = report["os"]
    cpu        = report["cpu"]
    mem        = report["memory"]
    disks      = report.get("disks", [])
    ports_list = report.get("ports", [])
    port_nums  = {pt["port"] for pt in ports_list}
    sw         = report.get("software", {})
    cloud      = report.get("cloud", "On Premises")
    vpn        = report.get("vpn", False)
    tz         = report.get("timezone", "—")
    sec_patch  = report.get("security_patch", "—")
    net_speed  = report.get("network_speed", "—")
    ssl_status = report.get("ssl_status", "Not Detected")
    ssl_provider = report.get("ssl_provider", "—")
    ssl_expiry = report.get("ssl_expiry", "—")
    logger_val = report.get("logger", "Default")

    ts     = report["generated_at"][:19].replace("T", " ") + " UTC"
    fqdn   = host.get("fqdn", "")
    ip_str = ", ".join(host.get("ip_addresses", [])) or host.get("hostname", "—")

    pdf = PDF(
        "SERVER PRE-DEPLOYMENT CHECKLIST",
        f"Generated By: {gen_user or '—'}   |   Host: {host['hostname']}   |   OS: {os_.get('name', '')}",
    )

    # ── Client info (manual or dynamic CLI parameters)
    pdf.cl_info_boxes([
        ("Product / App Name", product if product else "— (Manual Input)"),
        ("Company Code",       client_code if client_code else "— (Manual Input)"),
        ("Company Name",       client_name if client_name else "— (Manual Input)"),
    ])
    pdf.spacer(8)

    # ── Server Information
    pdf.cl_section("SERVER INFORMATION")
    pdf.cl_kv_row("Hostname",   host.get("hostname", "—"), label_w=150)
    pdf.cl_kv_row("FQDN",       fqdn or "—",               label_w=150)
    pdf.cl_kv_row("IP Address", ip_str,                    label_w=150)
    pdf.cl_kv_row("System User", host.get("user", "—"),    label_w=150)
    pdf.spacer(6)

    # ── Server Environmental Details
    pdf.cl_section("SERVER ENVIRONMENTAL DETAILS")
    has_ssh = "22" in port_nums
    pdf.cl_check_row("Access Type", [
        ("SSH", has_ssh), ("Remote Desktop", False), ("Putty", False),
    ])
    pdf.cl_check_row("Target Environment", [
        ("Staging", env.lower() == "staging"),
        ("Production", env.lower() == "production"),
        ("Demo", env.lower() == "demo"),
    ])
    pdf.cl_kv_row("Server IP / Host Name", ip_str)
    pdf.cl_check_row("Server Role", [
        ("Web Server", role.lower() == "web server"),
        ("DB Server", role.lower() == "db server"),
        ("Load Balancer", role.lower() == "load balancer"),
        ("Others", role.lower() == "others"),
    ])
    pdf.cl_check_row("Cloud Provider / Hosting", [
        ("AWS",             cloud == "AWS"),
        ("Microsoft Azure", cloud == "Microsoft Azure"),
        ("GCP",             cloud == "GCP"),
        ("On Premises",     cloud == "On Premises"),
    ])
    pdf.cl_check_row("VPN Active", [("Yes", vpn), ("No", not vpn)])
    pdf.spacer(8)

    # ── Firewall | Configuration + Resource (two-panel)
    app_ports  = [pt for pt in ports_list if int(pt["port"]) < 49152]
    high_ports = [pt for pt in ports_list if int(pt["port"]) >= 49152]

    fw_rows: List[Any] = (
        [(pt["port"], pt["process"]) for pt in app_ports[:14]]
        or [("—", "None detected")]
    )
    config_rows: List[Any] = [
        ("Timezone",    tz),
        ("Logger",      logger_val),
        ("__SEC__",     "SERVER RESOURCE"),
        ("CPU Model",   cpu.get("model", "—")[:38]),
        ("Core / vCPU", str(cpu.get("physical_cores", cpu.get("logical_cpus", "—")))),
        ("RAM Total",   mem.get("total", "—")),
        ("Disk Total",  disks[0]["total"]     if disks else "—"),
        ("Disk Avail.", disks[0]["available"] if disks else "—"),
        ("Ping | Speed",net_speed),
    ]
    pdf.cl_two_panel("FIREWALL PORTS", fw_rows, "CONFIGURATION / RESOURCE", config_rows)

    # ── Unwanted Exposed Ports
    pdf.cl_section("UNWANTED EXPOSED PORTS")
    risky_ports = {21, 23, 25, 110, 135, 139, 445, 1433, 1521, 3306, 6379, 27017, 8080}
    unwanted_ports = []
    for pt in ports_list:
        try:
            p_num = int(pt["port"])
            addr = pt.get("address", "")
            is_wildcard = "0.0.0.0" in addr or "[::]" in addr or "*" in addr or "::" in addr
            if p_num in risky_ports and is_wildcard and "127.0.0.1" not in addr and "::1" not in addr:
                unwanted_ports.append(pt)
        except Exception:
            pass

    if unwanted_ports:
        for hp in unwanted_ports[:10]:
            pdf.cl_check_row(hp["port"], [("Exposed (" + hp["process"] + ")", True)])
    else:
        pdf.cl_kv_row("Status", "None (System Secure)")
    pdf.spacer(8)

    # ── OS Details | Domain / SSL (two-panel)
    is_linux   = os_.get("system", "") == "Linux"
    is_windows = os_.get("system", "") == "Windows"
    domain     = (
        ".".join(fqdn.split(".")[1:])
        if "." in fqdn and fqdn != host["hostname"]
        else "—"
    )
    is_local = domain == "—" or not any(
        s in fqdn for s in [".com", ".net", ".org", ".io"]
    )

    os_rows: List[Any] = [
        ("OS Type",        [("Windows", is_windows), ("Linux", is_linux)]),
        ("OS Name",        os_.get("name", "—")),
        ("OS Version",     os_.get("version_id", "—")),
        ("Security Patch", sec_patch),
        ("Uptime",         os_.get("uptime", "—")),
    ]
    is_le = "letsencrypt" in ssl_provider.lower() or "let's encrypt" in ssl_provider.lower()
    is_self = "self-signed" in ssl_provider.lower() or "internal" in ssl_provider.lower()
    is_ca = not is_le and not is_self and ssl_status != "Not Detected"

    domain_val = domain if domain != "—" else "— (Manual Input)"
    ssl_status_val = ssl_status if ssl_status != "Not Detected" else "— (Manual Input)"
    ssl_expiry_val = ssl_expiry if ssl_expiry != "—" else "— (Manual Input)"

    domain_rows: List[Any] = [
        ("Domain",          domain_val),
        ("Hosting Domain",  [("Local", is_local), ("Public", not is_local)]),
        ("SSL Certificate", ssl_status_val),
        ("SSL Provider",    [("CA", is_ca), ("Let's Encrypt", is_le), ("Self-Signed", is_self)]),
        ("SSL Expiry",      ssl_expiry_val),
    ]
    pdf.cl_two_panel("OS DETAILS", os_rows, "DOMAIN / SSL", domain_rows)
    pdf.spacer(8)

    # ── Supported Software & Tooling
    pdf.cl_section("SUPPORTED SOFTWARE & TOOLING")
    pdf.cl_sw_grid(sw)

    pdf.build(output)


# ── CLI entry point ────────────────────────────────────────────────────────────

def parse_args(argv: List[str]) -> argparse.Namespace:
    p = argparse.ArgumentParser(
        description="Collect server system specs and export a PDF pre-deployment checklist.")
    p.add_argument("--pdf", "--output", default="system-spec-report.pdf",
                   metavar="PATH", help="Output .pdf path (default: system-spec-report.pdf)")
    p.add_argument("--quiet", action="store_true", help="Suppress progress messages.")
    p.add_argument("--product", default="", help="Product Name manual field")
    p.add_argument("--client-code", default="", help="Client Code manual field")
    p.add_argument("--client-name", default="", help="Client Name manual field")
    p.add_argument("--gen-user", default="", help="Generated By user")
    p.add_argument("--role", default="Web Server", help="Server Role (Web Server, DB Server, Load Balancer, Others)")
    p.add_argument("--env", default="Production", help="Target Environment (Staging, Production, Demo)")
    return p.parse_args(argv)


def main(argv: List[str]) -> int:
    args   = parse_args(argv)
    output = Path(args.pdf).expanduser().resolve()
    
    # Interactive Prompts
    print("\n--- Server Specification Report Generator ---")
    print("Please provide the following manual entry details (press Enter to skip):")
    product = input("Product / App Name: ").strip() or args.product
    client_code = input("Company Code (assigned by CannyMinds): ").strip() or args.client_code
    client_name = input("Company Name: ").strip() or args.client_name
    gen_user = input("Your Name (Generated By): ").strip() or args.gen_user
    
    print("\nSelect Server Role (default: Web Server):")
    print("  1. Web Server\n  2. DB Server\n  3. Load Balancer\n  4. Others")
    role_choice = input("Choice [1-4]: ").strip()
    role_map = {"1": "Web Server", "2": "DB Server", "3": "Load Balancer", "4": "Others"}
    role = role_map.get(role_choice, args.role)

    print("\nSelect Target Environment (default: Production):")
    print("  1. Staging\n  2. Production\n  3. Demo")
    env_choice = input("Choice [1-3]: ").strip()
    env_map = {"1": "Staging", "2": "Production", "3": "Demo"}
    env = env_map.get(env_choice, args.env)

    print("\n--- Permission to Scan ---")
    confirm = input("Do you want to proceed with checking the system requirements and generating the PDF report? [Y/n]: ").strip().lower()
    if confirm not in ("", "y", "yes"):
        print("Operation cancelled. Exiting.")
        return 0

    if not args.quiet:
        print("\nCollecting system specifications… (This may take a few seconds)")
        
    report = collect_report()
    write_pdf(report, output,
              product=product,
              client_code=client_code,
              client_name=client_name,
              gen_user=gen_user,
              role=role,
              env=env)
    print(f"\nReport successfully written → {output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
