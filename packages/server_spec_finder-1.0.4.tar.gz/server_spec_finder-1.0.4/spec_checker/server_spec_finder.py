#!/usr/bin/env python3
"""Find server specifications across one repo or a workspace.

The utility is intentionally dependency-free so it can be dropped into a fresh
folder and run against mixed Node/Python services.
"""

from __future__ import annotations

import argparse
import json
import os
import re
import sys
import zipfile
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Set, Tuple
from xml.sax.saxutils import escape as xml_escape


IGNORED_DIRS = {
    ".git",
    ".hg",
    ".svn",
    ".cache",
    ".pytest_cache",
    ".agents",
    ".claude",
    ".codex",
    ".venv",
    "venv",
    "env",
    "node_modules",
    "dist",
    "build",
    "coverage",
    "logs",
    "tmp",
    "temp",
    "uploads",
    "storage",
    "tessdata-best",
    "__pycache__",
}

JS_EXTENSIONS = (".js", ".cjs", ".mjs", ".ts")
PY_EXTENSIONS = (".py",)
ROUTE_METHODS = {"get", "post", "put", "patch", "delete", "options", "head", "all"}
FRAMEWORK_HINTS = {
    "express",
    "fastify",
    "@nestjs/core",
    "koa",
    "hapi",
    "fastapi",
    "flask",
    "django",
    "uvicorn",
}
SENSITIVE_NAME_PARTS = ("SECRET", "PASSWORD", "PASS", "TOKEN", "KEY", "PRIVATE", "CREDENTIAL")


def read_text(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8", errors="ignore")
    except OSError:
        return ""


def json_load(path: Path) -> Dict[str, Any]:
    try:
        with path.open("r", encoding="utf-8") as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else {}
    except (OSError, json.JSONDecodeError):
        return {}


def is_ignored(path: Path) -> bool:
    return any(part in IGNORED_DIRS for part in path.parts)


def iter_files(root: Path, suffixes: Optional[Tuple[str, ...]] = None) -> Iterable[Path]:
    for current, dirs, files in os.walk(root):
        current_path = Path(current)
        dirs[:] = [name for name in dirs if name not in IGNORED_DIRS]
        if is_ignored(current_path.relative_to(root)) if current_path != root else False:
            continue
        for filename in files:
            path = current_path / filename
            if suffixes is None or path.suffix.lower() in suffixes:
                yield path


def relative(path: Path, root: Path) -> str:
    try:
        return path.relative_to(root).as_posix()
    except ValueError:
        return path.as_posix()


def candidate_repositories(root: Path, explicit_all: bool) -> List[Path]:
    if (root / "package.json").exists() or (root / "requirements.txt").exists() or (root / "pyproject.toml").exists():
        return [root]

    candidates: List[Path] = []
    for child in sorted(root.iterdir()):
        if not child.is_dir() or child.name in IGNORED_DIRS:
            continue
        if child.name == "specification check":
            continue
        if explicit_all or looks_like_server_repo(child):
            candidates.append(child)
    return candidates


def looks_like_server_repo(path: Path) -> bool:
    lowered = path.name.lower()
    if any(token in lowered for token in ("server", "serve", "service", "gateway", "api")):
        return True

    package = json_load(path / "package.json")
    deps = package_dependencies(package)
    if any(dep in deps for dep in ("express", "fastify", "@nestjs/core", "koa", "hapi")):
        return True

    req = read_text(path / "requirements.txt").lower()
    if any(token in req for token in ("fastapi", "flask", "django", "uvicorn")):
        return True

    return False


def package_dependencies(package: Dict[str, Any]) -> Dict[str, str]:
    deps: Dict[str, str] = {}
    for field in ("dependencies", "devDependencies", "peerDependencies", "optionalDependencies"):
        value = package.get(field)
        if isinstance(value, dict):
            deps.update({str(key): str(version) for key, version in value.items()})
    return deps


def resolve_module(source_file: Path, module_path: str, repo: Path) -> Optional[Path]:
    if module_path.startswith("@/"):
        base = (repo / "src" / module_path[2:]).resolve()
    elif module_path.startswith("."):
        base = (source_file.parent / module_path).resolve()
    else:
        return None
    candidates = [base]
    for ext in JS_EXTENSIONS:
        candidates.append(Path(str(base) + ext))
    for ext in JS_EXTENSIONS:
        candidates.append(base / ("index" + ext))
    for candidate in candidates:
        if candidate.exists() and candidate.is_file():
            return candidate
    return None


def normalize_path(path: str) -> str:
    if not path or path == "/":
        return "/"
    path = re.sub(r"/+", "/", path)
    if not path.startswith("/"):
        path = "/" + path
    if len(path) > 1 and path.endswith("/"):
        path = path[:-1]
    return path


def join_paths(prefix: str, suffix: str) -> str:
    if suffix in ("", "/"):
        return normalize_path(prefix)
    if prefix in ("", "/"):
        return normalize_path(suffix)
    return normalize_path(prefix.rstrip("/") + "/" + suffix.lstrip("/"))


def line_number(text: str, offset: int) -> int:
    return text.count("\n", 0, offset) + 1


def extract_js_routes(repo: Path) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
    files: Dict[Path, Dict[str, Any]] = {}
    incoming: Set[Path] = set()

    for source_file in iter_files(repo, JS_EXTENSIONS):
        text = read_text(source_file)
        if not re.search(r"\b(router|app|server)\s*\.\s*(use|route|get|post|put|patch|delete|options|head|all)\b", text):
            continue

        imports: Dict[str, Path] = {}
        for match in re.finditer(r"(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*=\s*require\(\s*['\"]([^'\"]+)['\"]\s*\)", text):
            resolved = resolve_module(source_file, match.group(2), repo)
            if resolved:
                imports[match.group(1)] = resolved
        for match in re.finditer(r"import\s+([A-Za-z_$][\w$]*)\s+from\s+['\"]([^'\"]+)['\"]", text):
            resolved = resolve_module(source_file, match.group(2), repo)
            if resolved:
                imports[match.group(1)] = resolved

        mounts: List[Dict[str, Any]] = []
        for match in re.finditer(
            r"\b(?:router|app|server)\s*\.\s*use\(\s*(?:['\"]([^'\"]*)['\"]\s*,\s*)?([A-Za-z_$][\w$]*)",
            text,
        ):
            path = match.group(1) or "/"
            variable = match.group(2)
            target = imports.get(variable)
            if target:
                incoming.add(target)
            mounts.append(
                {
                    "path": normalize_path(path),
                    "target": target,
                    "target_var": variable,
                    "line": line_number(text, match.start()),
                }
            )

        local_routes: List[Dict[str, Any]] = []
        for match in re.finditer(
            r"\b(?:router|app)\s*\.\s*(get|post|put|patch|delete|options|head|all)\(\s*['\"`]([^'\"`]+)['\"`]",
            text,
            re.IGNORECASE,
        ):
            local_routes.append(
                {
                    "method": match.group(1).upper(),
                    "path": normalize_path(match.group(2)),
                    "line": line_number(text, match.start()),
                }
            )
        for match in re.finditer(
            r"\b(?:router|app)\s*\.\s*route\(\s*['\"`]([^'\"`]+)['\"`]\s*\)((?:\s*\.\s*\w+\([^;]*)*)",
            text,
        ):
            route_path = normalize_path(match.group(1))
            chain = match.group(2)
            methods = [
                method.upper()
                for method in re.findall(r"\.\s*([a-zA-Z]+)\s*\(", chain)
                if method.lower() in ROUTE_METHODS
            ]
            for method in methods:
                local_routes.append({"method": method, "path": route_path, "line": line_number(text, match.start())})

        if mounts or local_routes:
            files[source_file.resolve()] = {"mounts": mounts, "routes": local_routes}

    resolved_routes: List[Dict[str, Any]] = []
    mount_points: List[Dict[str, Any]] = []

    def walk(path: Path, prefix: str, stack: Set[Path]) -> None:
        info = files.get(path)
        if not info or path in stack:
            return
        stack.add(path)
        file_label = relative(path, repo)
        for route in info["routes"]:
            resolved_routes.append(
                {
                    "method": route["method"],
                    "path": join_paths(prefix, route["path"]),
                    "file": file_label,
                    "line": route["line"],
                    "source": "express",
                }
            )
        for mount in info["mounts"]:
            full_prefix = join_paths(prefix, mount["path"])
            target = mount["target"]
            mount_points.append(
                {
                    "path": full_prefix,
                    "file": file_label,
                    "line": mount["line"],
                    "target": relative(target, repo) if target else mount["target_var"],
                    "resolved": bool(target),
                }
            )
            if target:
                walk(target, full_prefix, set(stack))
        stack.remove(path)

    roots = [path for path in files if path not in incoming]
    if not roots:
        roots = list(files)
    for root in roots:
        walk(root, "/", set())

    # Any file that was not reachable still has useful local route declarations.
    seen_sources = {route["file"] for route in resolved_routes}
    for path, info in files.items():
        file_label = relative(path, repo)
        if file_label in seen_sources:
            continue
        for route in info["routes"]:
            resolved_routes.append(
                {
                    "method": route["method"],
                    "path": route["path"],
                    "file": file_label,
                    "line": route["line"],
                    "source": "express-local",
                }
            )

    return dedupe_routes(resolved_routes), mount_points


def extract_python_routes(repo: Path) -> List[Dict[str, Any]]:
    routes: List[Dict[str, Any]] = []
    for source_file in iter_files(repo, PY_EXTENSIONS):
        text = read_text(source_file)
        if not re.search(r"(@\w+\.(get|post|put|patch|delete|options|head)|APIRouter|include_router|Flask\()", text):
            continue

        router_prefix = ""
        prefix_match = re.search(r"APIRouter\([^)]*prefix\s*=\s*['\"]([^'\"]+)['\"]", text, re.DOTALL)
        if prefix_match:
            router_prefix = normalize_path(prefix_match.group(1))

        for match in re.finditer(r"@(?:router|app|blueprint)\.(get|post|put|patch|delete|options|head)\(\s*['\"]([^'\"]+)['\"]", text):
            routes.append(
                {
                    "method": match.group(1).upper(),
                    "path": join_paths(router_prefix, match.group(2)),
                    "file": relative(source_file, repo),
                    "line": line_number(text, match.start()),
                    "source": "python",
                }
            )

        for match in re.finditer(r"@(?:app|blueprint)\.route\(\s*['\"]([^'\"]+)['\"][^)]*methods\s*=\s*\[([^\]]+)\]", text):
            methods = re.findall(r"['\"]([A-Z]+)['\"]", match.group(2), re.IGNORECASE)
            for method in methods:
                routes.append(
                    {
                        "method": method.upper(),
                        "path": normalize_path(match.group(1)),
                        "file": relative(source_file, repo),
                        "line": line_number(text, match.start()),
                        "source": "python",
                    }
                )

    return dedupe_routes(routes)


def dedupe_routes(routes: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    seen: Set[Tuple[str, str, str, int]] = set()
    unique: List[Dict[str, Any]] = []
    for route in sorted(routes, key=lambda item: (item["path"], item["method"], item["file"], item["line"])):
        key = (route["method"], route["path"], route["file"], route["line"])
        if key in seen:
            continue
        seen.add(key)
        unique.append(route)
    return unique


def is_env_template(path: Path) -> bool:
    name = path.name.lower()
    return name in {".env.example", ".env.sample", ".env.template", ".env.defaults"} or name.endswith(
        (".env.example", ".env.sample", ".env.template")
    )


def is_sensitive_name(name: str) -> bool:
    return any(part in name.upper() for part in SENSITIVE_NAME_PARTS)


def safe_default(name: str, value: str, show_sensitive: bool) -> str:
    value = value.strip().strip("\"'")
    if value and is_sensitive_name(name) and not show_sensitive:
        return "<redacted>"
    return value


def extract_env(repo: Path, include_dotenv: bool, show_sensitive: bool) -> Dict[str, Any]:
    names: Dict[str, Set[str]] = defaultdict(set)
    defaults: Dict[str, Set[str]] = defaultdict(set)

    for env_file in iter_files(repo):
        should_read_env = env_file.name.startswith(".env") and (include_dotenv or is_env_template(env_file))
        if should_read_env or env_file.name in {"Dockerfile", "docker-compose.yml", "docker-compose.yaml"}:
            text = read_text(env_file)
            for match in re.finditer(r"^\s*([A-Z][A-Z0-9_]+)\s*=\s*([^\n#]+)", text, re.MULTILINE):
                names[match.group(1)].add(relative(env_file, repo))
                defaults[match.group(1)].add(safe_default(match.group(1), match.group(2), show_sensitive))

    for source_file in iter_files(repo, JS_EXTENSIONS + PY_EXTENSIONS):
        text = read_text(source_file)
        for match in re.finditer(r"process\.env\.([A-Z][A-Z0-9_]*)(?![A-Za-z0-9_])", text):
            names[match.group(1)].add(relative(source_file, repo))
        for match in re.finditer(r"process\.env\.([A-Z][A-Z0-9_]*)(?![A-Za-z0-9_])\s*\|\|\s*['\"]?([^'\"`\s,;)}]+)", text):
            defaults[match.group(1)].add(safe_default(match.group(1), match.group(2), show_sensitive))
        for match in re.finditer(r"os\.(?:getenv|environ\.get)\(\s*['\"]([A-Z][A-Z0-9_]*)['\"](?:\s*,\s*['\"]?([^'\"\)]+)['\"]?)?", text):
            names[match.group(1)].add(relative(source_file, repo))
            if match.group(2):
                defaults[match.group(1)].add(safe_default(match.group(1), match.group(2), show_sensitive))

    variables = []
    for name in sorted(names):
        variables.append(
            {
                "name": name,
                "defaults": sorted(value for value in defaults.get(name, set()) if value),
                "files": sorted(names[name]),
            }
        )
    return {"variables": variables}


def extract_ports(repo: Path, env: Dict[str, Any]) -> List[Dict[str, str]]:
    ports: Dict[Tuple[str, str], Dict[str, str]] = {}

    for variable in env["variables"]:
        if variable["name"].endswith("PORT") or variable["name"] == "PORT":
            for default in variable.get("defaults", []):
                if re.fullmatch(r"\d{2,5}", default):
                    ports[(default, variable["name"])] = {"port": default, "source": variable["name"], "detail": "env default"}

    port_files = {"Dockerfile", "docker-compose.yml", "docker-compose.yaml", "Taskfile.yml", "Taskfile.yaml"}
    for path in iter_files(repo):
        if path.name not in port_files:
            continue
        text = read_text(path)
        for match in re.finditer(r"\bEXPOSE\s+\$?\{?([A-Z_]+)?(?::?-?(\d{2,5}))?\}?|\bEXPOSE\s+(\d{2,5})", text):
            port = match.group(2) or match.group(3)
            if port:
                ports[(port, relative(path, repo))] = {"port": port, "source": relative(path, repo), "detail": "docker expose"}
        for match in re.finditer(r"(?<!\d)(\d{2,5})\s*:\s*(\d{2,5})(?!\d)", text):
            host, container = match.groups()
            ports[(host, relative(path, repo))] = {
                "port": host,
                "source": relative(path, repo),
                "detail": f"mapped to {container}",
            }

    return sorted(ports.values(), key=lambda item: (int(item["port"]), item["source"]))


def extract_openapi_artifacts(repo: Path) -> List[str]:
    artifacts: List[str] = []
    for path in iter_files(repo):
        lower = path.name.lower()
        if any(token in lower for token in ("openapi", "swagger")) and path.suffix.lower() in {
            ".json",
            ".yaml",
            ".yml",
        }:
            artifacts.append(relative(path, repo))
    return sorted(artifacts)


def extract_runtime(repo: Path) -> Dict[str, Any]:
    package = json_load(repo / "package.json")
    dependencies = package_dependencies(package)
    frameworks = sorted(name for name in dependencies if name in FRAMEWORK_HINTS)

    requirements = read_text(repo / "requirements.txt")
    if requirements:
        for line in requirements.splitlines():
            dep = re.split(r"[<>=~! ]+", line.strip().lower())[0]
            if dep in FRAMEWORK_HINTS and dep not in frameworks:
                frameworks.append(dep)

    runtime: Dict[str, Any] = {
        "type": [],
        "frameworks": sorted(frameworks),
        "scripts": package.get("scripts", {}) if isinstance(package.get("scripts"), dict) else {},
    }
    if package:
        runtime["type"].append("node")
        runtime["package_name"] = package.get("name")
        runtime["package_version"] = package.get("version")
    if requirements or (repo / "pyproject.toml").exists():
        runtime["type"].append("python")
    if (repo / "Dockerfile").exists():
        runtime["type"].append("docker")
    if (repo / "docker-compose.yml").exists() or (repo / "docker-compose.yaml").exists():
        runtime["type"].append("compose")
    return runtime


def find_entrypoints(repo: Path) -> List[str]:
    patterns = ("server.js", "server.ts", "app.js", "app.ts", "main.py", "manage.py")
    entrypoints: List[str] = []
    for path in iter_files(repo):
        if path.name in patterns:
            entrypoints.append(relative(path, repo))
    return sorted(entrypoints)


def analyze_repo(repo: Path, include_dotenv: bool, show_sensitive: bool) -> Dict[str, Any]:
    env = extract_env(repo, include_dotenv, show_sensitive)
    js_routes, js_mounts = extract_js_routes(repo)
    py_routes = extract_python_routes(repo)
    routes = dedupe_routes(js_routes + py_routes)
    health = [route for route in routes if "health" in route["path"].lower()]

    return {
        "name": repo.name,
        "path": str(repo),
        "runtime": extract_runtime(repo),
        "entrypoints": find_entrypoints(repo),
        "ports": extract_ports(repo, env),
        "environment": env,
        "openapi_artifacts": extract_openapi_artifacts(repo),
        "routes": routes,
        "mounts": js_mounts,
        "health_routes": health,
    }


def render_markdown(report: Dict[str, Any]) -> str:
    lines = [
        "# Server Specification Report",
        "",
        f"Generated: {report['generated_at']}",
        f"Scan root: `{report['scan_root']}`",
        f"Repositories: {len(report['repositories'])}",
        "",
    ]

    for repo in report["repositories"]:
        lines.extend([f"## {repo['name']}", "", f"Path: `{repo['path']}`", ""])
        runtime = repo["runtime"]
        lines.append(f"Runtime: `{', '.join(runtime.get('type') or ['unknown'])}`")
        if runtime.get("frameworks"):
            lines.append(f"Frameworks: `{', '.join(runtime['frameworks'])}`")
        if repo["ports"]:
            lines.append("")
            lines.append("| Port | Source | Detail |")
            lines.append("| --- | --- | --- |")
            for item in repo["ports"]:
                lines.append(f"| {item['port']} | `{item['source']}` | {item['detail']} |")
        if repo["entrypoints"]:
            lines.append("")
            lines.append("Entrypoints:")
            for entry in repo["entrypoints"]:
                lines.append(f"- `{entry}`")
        if repo["openapi_artifacts"]:
            lines.append("")
            lines.append("Existing OpenAPI/Swagger artifacts:")
            for artifact in repo["openapi_artifacts"]:
                lines.append(f"- `{artifact}`")

        env_vars = repo["environment"]["variables"]
        lines.append("")
        lines.append(f"Environment variables discovered: {len(env_vars)}")
        if env_vars:
            shown = env_vars[:25]
            lines.append("")
            lines.append("| Variable | Defaults | Files |")
            lines.append("| --- | --- | --- |")
            for variable in shown:
                defaults = ", ".join(f"`{value}`" for value in variable["defaults"]) or ""
                files = ", ".join(f"`{file}`" for file in variable["files"][:3])
                if len(variable["files"]) > 3:
                    files += f" +{len(variable['files']) - 3} more"
                lines.append(f"| `{variable['name']}` | {defaults} | {files} |")
            if len(env_vars) > len(shown):
                lines.append(f"| ... | ... | {len(env_vars) - len(shown)} more variables in JSON output |")

        lines.append("")
        lines.append(f"Routes discovered: {len(repo['routes'])}")
        if repo["routes"]:
            lines.append("")
            lines.append("| Method | Path | Source |")
            lines.append("| --- | --- | --- |")
            for route in repo["routes"][:200]:
                lines.append(f"| `{route['method']}` | `{route['path']}` | `{route['file']}:{route['line']}` |")
            if len(repo["routes"]) > 200:
                lines.append(f"| ... | ... | {len(repo['routes']) - 200} more routes in JSON output |")
        lines.append("")

    return "\n".join(lines).rstrip() + "\n"


def cell_ref(column_index: int, row_index: int) -> str:
    name = ""
    column = column_index
    while column:
        column, remainder = divmod(column - 1, 26)
        name = chr(65 + remainder) + name
    return f"{name}{row_index}"


def worksheet_xml(rows: List[List[Any]]) -> str:
    xml_rows = []
    for row_index, row in enumerate(rows, start=1):
        cells = []
        for column_index, value in enumerate(row, start=1):
            text = "" if value is None else str(value)
            ref = cell_ref(column_index, row_index)
            cells.append(f'<c r="{ref}" t="inlineStr"><is><t>{xml_escape(text)}</t></is></c>')
        xml_rows.append(f'<row r="{row_index}">{"".join(cells)}</row>')

    return (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
        '<sheetViews><sheetView workbookViewId="0"/></sheetViews>'
        f'<sheetData>{"".join(xml_rows)}</sheetData>'
        "</worksheet>"
    )


def write_excel(report: Dict[str, Any], output: Path) -> None:
    sheets: List[Tuple[str, List[List[Any]]]] = []

    summary_rows = [["Repository", "Runtime", "Frameworks", "Entrypoints", "Routes", "Env Vars", "Ports", "Path"]]
    route_rows = [["Repository", "Method", "Path", "File", "Line", "Source"]]
    env_rows = [["Repository", "Variable", "Defaults", "Files"]]
    port_rows = [["Repository", "Port", "Source", "Detail"]]
    health_rows = [["Repository", "Method", "Path", "File", "Line"]]

    for repo in report["repositories"]:
        runtime = repo["runtime"]
        summary_rows.append(
            [
                repo["name"],
                ", ".join(runtime.get("type") or ["unknown"]),
                ", ".join(runtime.get("frameworks") or []),
                ", ".join(repo["entrypoints"]),
                len(repo["routes"]),
                len(repo["environment"]["variables"]),
                ", ".join(item["port"] for item in repo["ports"]),
                repo["path"],
            ]
        )
        for route in repo["routes"]:
            route_rows.append([repo["name"], route["method"], route["path"], route["file"], route["line"], route["source"]])
        for variable in repo["environment"]["variables"]:
            env_rows.append(
                [
                    repo["name"],
                    variable["name"],
                    ", ".join(variable["defaults"]),
                    ", ".join(variable["files"]),
                ]
            )
        for port in repo["ports"]:
            port_rows.append([repo["name"], port["port"], port["source"], port["detail"]])
        for route in repo["health_routes"]:
            health_rows.append([repo["name"], route["method"], route["path"], route["file"], route["line"]])

    sheets.extend(
        [
            ("Summary", summary_rows),
            ("Routes", route_rows),
            ("Environment", env_rows),
            ("Ports", port_rows),
            ("Health", health_rows),
        ]
    )

    output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        archive.writestr(
            "[Content_Types].xml",
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
            '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
            '<Default Extension="xml" ContentType="application/xml"/>'
            '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
            + "".join(
                f'<Override PartName="/xl/worksheets/sheet{index}.xml" '
                'ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
                for index, _ in enumerate(sheets, start=1)
            )
            + "</Types>",
        )
        archive.writestr(
            "_rels/.rels",
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
            "</Relationships>",
        )
        archive.writestr(
            "xl/workbook.xml",
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
            'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
            "<sheets>"
            + "".join(
                f'<sheet name="{xml_escape(name[:31])}" sheetId="{index}" r:id="rId{index}"/>'
                for index, (name, _) in enumerate(sheets, start=1)
            )
            + "</sheets></workbook>",
        )
        archive.writestr(
            "xl/_rels/workbook.xml.rels",
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            + "".join(
                f'<Relationship Id="rId{index}" '
                'Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" '
                f'Target="worksheets/sheet{index}.xml"/>'
                for index, _ in enumerate(sheets, start=1)
            )
            + "</Relationships>",
        )
        for index, (_, rows) in enumerate(sheets, start=1):
            archive.writestr(f"xl/worksheets/sheet{index}.xml", worksheet_xml(rows))


def pdf_escape(text: str) -> str:
    return text.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")


def pdf_report_lines(report: Dict[str, Any]) -> List[str]:
    lines = [
        "Server Specification Report",
        f"Generated: {report['generated_at']}",
        f"Scan root: {report['scan_root']}",
        f"Repositories: {len(report['repositories'])}",
        "",
    ]
    for repo in report["repositories"]:
        runtime = repo["runtime"]
        lines.extend(
            [
                repo["name"],
                f"Path: {repo['path']}",
                f"Runtime: {', '.join(runtime.get('type') or ['unknown'])}",
                f"Frameworks: {', '.join(runtime.get('frameworks') or [])}",
                f"Entrypoints: {', '.join(repo['entrypoints'])}",
                f"Routes: {len(repo['routes'])} | Env vars: {len(repo['environment']['variables'])} | Ports: {len(repo['ports'])}",
                "",
                "Ports:",
            ]
        )
        lines.extend(f"  {item['port']} - {item['source']} ({item['detail']})" for item in repo["ports"])
        lines.append("Environment:")
        for variable in repo["environment"]["variables"]:
            defaults = ", ".join(variable["defaults"])
            files = ", ".join(variable["files"][:4])
            if len(variable["files"]) > 4:
                files += f" +{len(variable['files']) - 4} more"
            lines.append(f"  {variable['name']} = {defaults} [{files}]")
        lines.append("Routes:")
        for route in repo["routes"]:
            lines.append(f"  {route['method']} {route['path']} ({route['file']}:{route['line']})")
        lines.append("")
    return lines


def write_pdf(report: Dict[str, Any], output: Path) -> None:
    from spec_checker.pdf_writer import PDF

    subtitle = (
        f"Generated: {report['generated_at'][:19].replace('T', ' ')}  |  "
        f"Scan root: {report['scan_root']}  |  "
        f"Repositories: {len(report['repositories'])}"
    )
    doc = PDF("Server Specification Report", subtitle)

    doc.section("Repository Summary")
    doc.table(
        ["Repository", "Runtime", "Frameworks", "Routes", "Env Vars", "Ports"],
        [
            [
                r["name"],
                ", ".join(r["runtime"].get("type", [])),
                ", ".join(r["runtime"].get("frameworks", [])) or "—",
                str(len(r["routes"])),
                str(len(r["environment"]["variables"])),
                ", ".join(p["port"] for p in r["ports"]) or "—",
            ]
            for r in report["repositories"]
        ],
        widths=[130, 75, 90, 45, 55, 120],
    )

    for repo in report["repositories"]:
        doc.section(repo["name"])
        runtime = repo["runtime"]
        doc.kv([
            ("Path",        repo["path"]),
            ("Runtime",     ", ".join(runtime.get("type", []))),
            ("Frameworks",  ", ".join(runtime.get("frameworks", [])) or "—"),
            ("Entrypoints", ", ".join(repo["entrypoints"]) or "—"),
        ], cols=1)

        if repo["ports"]:
            doc.table(
                ["Port", "Source", "Detail"],
                [[p["port"], p["source"], p["detail"]] for p in repo["ports"]],
                widths=[55, 210, 250],
            )

        if repo["routes"]:
            doc.table(
                ["Method", "Path", "File : Line"],
                [[r["method"], r["path"], f"{r['file']}:{r['line']}"]
                 for r in repo["routes"][:100]],
                widths=[55, 230, 230],
            )

        env_vars = repo["environment"]["variables"]
        if env_vars:
            doc.table(
                ["Variable", "Defaults", "Files"],
                [
                    [v["name"],
                     ", ".join(v["defaults"])[:50] or "—",
                     ", ".join(v["files"][:2])[:50]]
                    for v in env_vars[:50]
                ],
                widths=[140, 160, 215],
            )

    doc.build(output)


def build_report(root: Path, include_all: bool, include_dotenv: bool, show_sensitive: bool) -> Dict[str, Any]:
    repos = candidate_repositories(root, include_all)
    return {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "scan_root": str(root),
        "repositories": [analyze_repo(repo.resolve(), include_dotenv, show_sensitive) for repo in repos],
    }


def parse_args(argv: List[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Discover server runtime, ports, env vars, route specs, and OpenAPI artifacts.",
    )
    parser.add_argument(
        "root",
        nargs="?",
        default=str(Path(__file__).resolve().parents[1]),
        help="Workspace or repository path to scan. Defaults to the parent of this utility folder.",
    )
    parser.add_argument("--all", action="store_true", help="Scan every child folder, not only likely server repositories.")
    parser.add_argument("--json", dest="json_path", help="Write full JSON report to this path.")
    parser.add_argument("--markdown", "--md", dest="markdown_path", help="Write Markdown report to this path.")
    parser.add_argument("--excel", "--xlsx", dest="excel_path", help="Write Excel .xlsx report to this path.")
    parser.add_argument("--pdf", dest="pdf_path", help="Write PDF report to this path.")
    parser.add_argument("--stdout", choices=("json", "markdown"), default="markdown", help="Print format. Default: markdown.")
    parser.add_argument("--quiet", action="store_true", help="Do not print the report when writing files.")
    parser.add_argument("--include-dotenv", action="store_true", help="Include real .env files. Defaults to examples/templates only.")
    parser.add_argument("--show-sensitive", action="store_true", help="Do not redact sensitive-looking defaults.")
    return parser.parse_args(argv)


def main(argv: List[str]) -> int:
    args = parse_args(argv)
    root = Path(args.root).expanduser().resolve()
    if not root.exists():
        print(f"Scan root does not exist: {root}", file=sys.stderr)
        return 2

    report = build_report(root, args.all, args.include_dotenv, args.show_sensitive)

    if args.json_path:
        output = Path(args.json_path).expanduser().resolve()
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(json.dumps(report, indent=2), encoding="utf-8")

    markdown = render_markdown(report)
    if args.markdown_path:
        output = Path(args.markdown_path).expanduser().resolve()
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(markdown, encoding="utf-8")

    if args.excel_path:
        write_excel(report, Path(args.excel_path).expanduser().resolve())

    if args.pdf_path:
        write_pdf(report, Path(args.pdf_path).expanduser().resolve())

    if not args.quiet:
        if args.stdout == "json":
            print(json.dumps(report, indent=2))
        else:
            print(markdown)
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
