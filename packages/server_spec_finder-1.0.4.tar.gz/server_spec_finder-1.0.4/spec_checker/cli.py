"""CLI entry points installed by pip."""

from __future__ import annotations

import sys


def run_system() -> None:
    """Entry point for the `spec-system` command."""
    from spec_checker import system_spec_finder
    sys.exit(system_spec_finder.main(sys.argv[1:]))


def run_repo() -> None:
    """Entry point for the `spec-repo` command."""
    from spec_checker import server_spec_finder
    sys.exit(server_spec_finder.main(sys.argv[1:]))
