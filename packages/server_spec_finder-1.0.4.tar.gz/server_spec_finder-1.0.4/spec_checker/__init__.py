"""server-spec-finder — dependency-free DevOps audit toolkit."""

__version__ = "1.0.4"
