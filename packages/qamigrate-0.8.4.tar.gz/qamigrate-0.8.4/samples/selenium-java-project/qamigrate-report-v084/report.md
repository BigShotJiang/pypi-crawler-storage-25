# QAMigrate Migration Report

**Source -> Target:** Java (Selenium) -> Java (Playwright)
**Started:** 2026-05-02T17:31:55.287687+00:00
**Finished:** 2026-05-02T17:36:08.513212+00:00

## Summary

- **Files migrated:** 15 / 15
- **Patterns handled:** 44
- **Average confidence:** 100%
- **Time taken:** 245.4s
- **Estimated manual effort saved:** ~11.0 hours

## Patterns handled

| Pattern | Count |
|---------|-------|
| `By_id` | 6 |
| `WebDriver` | 6 |
| `ExpectedConditions` | 5 |
| `By_field` | 4 |
| `click` | 3 |
| `sendKeys` | 2 |
| `clear` | 2 |
| `By_cssSelector` | 2 |
| `JavascriptExecutor` | 2 |
| `assertTrue` | 2 |
| `JUnit4_Test` | 2 |
| `TestNG_BeforeMethod` | 1 |
| `TestNG_AfterMethod` | 1 |
| `ChromeDriver` | 1 |
| `FirefoxDriver` | 1 |
| `WebDriverWait` | 1 |
| `Actions` | 1 |
| `Select` | 1 |
| `hover` | 1 |

## Files

| File | Status | Confidence | Patterns | Hallucinations | Time |
|------|--------|------------|----------|----------------|------|
| `BaseTest.java` | OK | 100% | 2 | 0 | 13.4s |
| `BasePage.java` | OK | 100% | 3 | 0 | 15.4s |
| `LoginPage.java` | OK | 100% | 13 | 0 | 13.0s |
| `ConfigurationReader.java` | OK | 100% | 0 | 0 | 12.9s |
| `Environment.java` | OK | 100% | 0 | 0 | 0.1s |
| `BrowserFactory.java` | OK | 100% | 3 | 0 | 12.3s |
| `DriverManager.java` | OK | 100% | 3 | 0 | 16.1s |
| `RetryAnalyzer.java` | OK | 100% | 0 | 0 | 5.9s |
| `TestListener.java` | OK | 100% | 0 | 0 | 15.0s |
| `ExtentManager.java` | OK | 100% | 0 | 0 | 39.1s |
| `Log.java` | OK | 100% | 0 | 0 | 13.4s |
| `ScreenshotUtils.java` | OK | 100% | 2 | 0 | 10.0s |
| `WaitUtils.java` | OK | 100% | 6 | 0 | 51.0s |
| `WebActions.java` | OK | 100% | 8 | 0 | 17.9s |
| `LoginTests.java` | OK | 100% | 4 | 0 | 9.8s |
