"""
QAMigrate - AI-powered Selenium → Playwright Java migration.

Supports:
  - Plain Selenium projects (TestNG, JUnit 4, JUnit 5)
  - Cucumber BDD projects (Cucumber 7+, JUnit Platform Suite runner)

Framework preserved: TestNG stays TestNG, JUnit4 stays JUnit4, etc.
Cucumber: feature files, step annotations, hooks, and runner untouched.

Usage:
    pip install qamigrate
    qamigrate init --project ./my-project --yes
    qamigrate migrate --all --project ./my-project --provider anthropic
"""

__version__ = "0.8.4"
__author__ = "QATonic Innovations"

from qamigrate.core.config import QAMigrateConfig
from qamigrate.core.report import MigrationRecord, MigrationReport, PatternSummary

__all__ = [
    "QAMigrateConfig",
    "MigrationRecord",
    "MigrationReport",
    "PatternSummary",
    "__version__",
]
