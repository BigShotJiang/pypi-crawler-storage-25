"""
Regression tests for v0.8.4 — Phase 1.95: parse-validation gate.

The v0.8.3 user test report flagged:
  > Parse-level cascading errors — a single 395-line file
  > (ExcelHelpers.java) with one syntax error generates 134 mvn errors.

Root cause: when the LLM emits a file with a syntax error, the pipeline
wrote it to disk anyway. javac then reported "cannot find symbol"
errors against every dependent file, inflating the apparent error
count by 100x. The migration looked dramatically worse than reality.

Phase 1.95 fixes this: parse every generated file with tree-sitter
before the compile batch runs. Files with parse errors are dropped
from `successful_gens`, marked failed, and deleted from disk so they
never reach javac.

These tests exercise the gate directly with synthetic GenerationResult
fixtures to avoid burning API credits on every CI run.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

import pytest

from qamigrate.agents.pipeline import (
    _count_error_nodes,
    _parse_validation_gate,
)


@dataclass
class _FakeGen:
    """Minimal stand-in for GenerationResult.

    The real GenerationResult is a dataclass too — we only need the
    attributes the gate actually touches.
    """
    output_path: Path | None
    success: bool = True
    error: str | None = None


# =============================================================================
# Parse-validation gate
# =============================================================================


class TestParseValidationGate:
    def test_clean_file_survives(self, tmp_path: Path) -> None:
        f = tmp_path / "Clean.java"
        f.write_text(
            "package x;\n"
            "public class Clean {\n"
            "    public void run() { System.out.println(\"ok\"); }\n"
            "}\n",
            encoding="utf-8",
        )
        gen = _FakeGen(output_path=f)
        survivors = _parse_validation_gate([gen])
        assert survivors == [gen]
        assert f.exists()  # still on disk
        assert gen.success is True

    def test_parse_error_file_dropped_and_deleted(self, tmp_path: Path) -> None:
        """The exact ExcelHelpers.java shape: a single syntax error
        somewhere in the file. tree-sitter reports an ERROR node;
        the gate drops it.
        """
        f = tmp_path / "Broken.java"
        # `class Foo {` then never-closed brace, plus stray `???`.
        f.write_text(
            "package x;\n"
            "public class Broken {\n"
            "    public void run() { ??? unclosed\n"
            "}\n",
            encoding="utf-8",
        )
        gen = _FakeGen(output_path=f)
        survivors = _parse_validation_gate([gen])
        assert survivors == []
        # File deleted so it doesn't show up in mvn compile.
        assert not f.exists()
        # Generation marked as failed with descriptive error.
        assert gen.success is False
        assert gen.error is not None
        assert "tree-sitter parse failed" in gen.error

    def test_empty_file_dropped(self, tmp_path: Path) -> None:
        f = tmp_path / "Empty.java"
        f.write_text("", encoding="utf-8")
        gen = _FakeGen(output_path=f)
        survivors = _parse_validation_gate([gen])
        assert survivors == []
        assert not f.exists()
        assert gen.success is False
        assert gen.error == "generated file is empty"

    def test_whitespace_only_file_dropped(self, tmp_path: Path) -> None:
        # An "empty-ish" file with only whitespace is still dropped.
        f = tmp_path / "Ws.java"
        f.write_text("   \n\n  \n", encoding="utf-8")
        gen = _FakeGen(output_path=f)
        survivors = _parse_validation_gate([gen])
        assert survivors == []
        assert not f.exists()

    def test_missing_output_path_skipped(self) -> None:
        # output_path is None — already-failed file. The gate doesn't
        # touch it (just doesn't include it in survivors).
        gen = _FakeGen(output_path=None, success=False, error="prior failure")
        survivors = _parse_validation_gate([gen])
        assert survivors == []
        # The pre-existing error is preserved.
        assert gen.error == "prior failure"

    def test_mixed_clean_and_broken(self, tmp_path: Path) -> None:
        good_path = tmp_path / "Good.java"
        good_path.write_text(
            "public class Good { public void f() {} }\n", encoding="utf-8"
        )
        bad_path = tmp_path / "Bad.java"
        bad_path.write_text(
            "public class Bad { public void f() { ??? unclosed\n}\n",
            encoding="utf-8",
        )
        good = _FakeGen(output_path=good_path)
        bad = _FakeGen(output_path=bad_path)
        survivors = _parse_validation_gate([good, bad])
        assert survivors == [good]
        # Clean file survives on disk; broken file deleted.
        assert good_path.exists()
        assert not bad_path.exists()
        # Bad gen is marked failed; good gen unchanged.
        assert bad.success is False
        assert good.success is True

    def test_subtle_syntax_error_in_long_file(self, tmp_path: Path) -> None:
        """The actual user-report shape: a long file (~395 lines) with one
        error somewhere in the middle. We synthesize a 100-line file with
        a trailing unmatched brace.
        """
        body_lines = [
            "    public void method" + str(i) + "() { return; }"
            for i in range(50)
        ]
        broken = (
            "package x;\n"
            "public class LongBroken {\n"
            + "\n".join(body_lines) + "\n"
            "    public void brokenOne() {\n"
            "        if (true) {\n"   # opens but never closes
            "            doSomething();\n"
            # missing closing braces here
            "}\n"
        )
        f = tmp_path / "LongBroken.java"
        f.write_text(broken, encoding="utf-8")
        gen = _FakeGen(output_path=f)
        survivors = _parse_validation_gate([gen])
        assert survivors == []
        assert not f.exists()
        assert gen.success is False


# =============================================================================
# _count_error_nodes
# =============================================================================


class TestCountErrorNodes:
    def test_clean_tree_returns_zero(self) -> None:
        from qamigrate.core.parser import get_parser
        parser = get_parser()
        tree = parser.parser.parse(b"public class X { void f() {} }")
        assert _count_error_nodes(tree.root_node) == 0

    def test_broken_tree_returns_nonzero(self) -> None:
        from qamigrate.core.parser import get_parser
        parser = get_parser()
        tree = parser.parser.parse(b"public class X { void f() { ??? }")
        assert _count_error_nodes(tree.root_node) > 0

    def test_limit_caps_count(self) -> None:
        # Just confirm the limit parameter is honored (no infinite loop).
        from qamigrate.core.parser import get_parser
        parser = get_parser()
        tree = parser.parser.parse(b"???? not java at all ????" * 50)
        result = _count_error_nodes(tree.root_node, limit=10)
        assert result <= 10
