#!/usr/bin/env python3
"""Standalone wrapper — delegates to linux_im_diagnose.cli.main().

You can also install via pip:  pip install linux-im-diagnose
Then run:  linux-im-diagnose --help
"""

import sys
import os

# Allow running directly from the repo without installing
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from linux_im_diagnose.cli import main

if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        sys.exit(130)
