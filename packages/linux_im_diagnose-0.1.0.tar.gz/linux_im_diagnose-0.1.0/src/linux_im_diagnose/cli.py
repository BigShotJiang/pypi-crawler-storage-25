#!/usr/bin/env python3
"""Diagnose input method framework status for Linux applications.

Detects UI frameworks (GTK, Qt, Electron) and input method module loading status
(Fcitx/IBus) for running Linux applications by inspecting /proc.
"""

from __future__ import annotations

import argparse
import json
import os
import re
import subprocess
import sys
from dataclasses import dataclass, field

from linux_im_diagnose import __version__

# psutil is optional — only needed for --search and --all-gui
psutil = None


def _require_psutil():
    global psutil
    if psutil is not None:
        return
    try:
        import psutil as _psutil
        psutil = _psutil
    except ImportError:
        print(
            "Error: psutil is required for --search and --all-gui modes.\n"
            "Install with:  pip install linux-im-diagnose[all]\n"
            "           or: pip install psutil\n\n"
            "Alternatively, use --click or --pid PID which do not require psutil.",
            file=sys.stderr
        )
        sys.exit(1)


# ── Constants & Patterns ──────────────────────────────────────────────────────

FRAMEWORK_PATTERNS = {
    'GTK4': re.compile(r'libgtk-4\.so'),
    'GTK3': re.compile(r'libgtk-3\.so'),
    'Qt6': re.compile(r'libQt6Core\.so'),
    'Qt5': re.compile(r'libQt5Core\.so'),
}

# Electron markers: libcef (Chromium Embedded Framework), or /electron/ in path
ELECTRON_PATTERN = re.compile(r'libcef\.so|/electron/', re.I)
# Node/V8 markers — strong indicator of Electron if combined with GUI libs
ELECTRON_NODE_PATTERN = re.compile(r'libnode\.so|libv8\.so|/libffmpeg\.so')
# Electron-specific cmdline flags
ELECTRON_CMDLINE_MARKERS = [
    '--enable-crashpad', '--ms-enable-electron-run-as-node',
    '--enable-blink-features', 'electron',
]
CHROMIUM_PATTERN = re.compile(r'chrom(?:e|ium)', re.I)

IM_LOADED_FCITX = re.compile(r'im-fcitx\w*\.so|fcitx\w*platforminput|libFcitx\w*Module', re.I)
IM_LOADED_IBUS = re.compile(r'im-ibus\.so|libibus-\d|ibus\w*platforminput', re.I)

IM_ENV_VARS = ['GTK_IM_MODULE', 'QT_IM_MODULE', 'QT_IM_MODULES',
               'XMODIFIERS', 'CLUTTER_IM_MODULE', 'SDL_IM_MODULE']

# Libraries that indicate a process has a GUI
GUI_LIB_MARKERS = ['libgtk', 'libQt', 'libgdk', 'libcef', 'libnode.so', 'libv8.so']

ELECTRON_TYPES_SKIP = {'gpu-process', 'utility', 'zygote', 'crashpad-handler', 'broker'}


# ── Data Classes ──────────────────────────────────────────────────────────────

@dataclass
class IMLoadedInfo:
    im: str        # 'fcitx' or 'ibus'
    path: str      # full .so path


@dataclass
class ProcessInfo:
    pid: int = 0
    name: str = ''
    cmdline: str = ''
    frameworks: list = field(default_factory=list)
    container: str = ''  # 'Flatpak', 'Snap', or ''
    window_system: str = 'Unknown'
    im_env: dict = field(default_factory=dict)
    im_loaded: list = field(default_factory=list)
    health_status: str = 'unknown'  # 'ok', 'warn', 'error', 'unknown'
    health_warnings: list = field(default_factory=list)
    electron_type: str = ''  # 'main', 'renderer', etc.
    error: str = ''


# ── Proc File Reader ─────────────────────────────────────────────���────────────

def read_proc_file(pid: int, filename: str) -> str:
    path = f'/proc/{pid}/{filename}'
    try:
        with open(path, 'rb') as f:
            data = f.read()
        if filename == 'cmdline':
            return data.decode('utf-8', errors='replace').replace('\x00', ' ').strip()
        return data.decode('utf-8', errors='replace')
    except PermissionError:
        raise PermissionError(
            f"Cannot read {path}. Try running with sudo or as the process owner."
        )
    except (FileNotFoundError, ProcessLookupError):
        raise ProcessLookupError(f"Process {pid} no longer exists.")


def read_proc_environ(pid: int) -> dict:
    raw = read_proc_file(pid, 'environ')
    env = {}
    for entry in raw.split('\x00'):
        if '=' in entry:
            k, v = entry.split('=', 1)
            env[k] = v
    return env


def read_proc_name(pid: int) -> str:
    """Get process name. Try /proc/[PID]/comm first, then extract from cmdline."""
    name = ''
    try:
        with open(f'/proc/{pid}/comm', 'r') as f:
            name = f.read().strip()
    except (PermissionError, FileNotFoundError, ProcessLookupError):
        pass

    # comm is truncated to 15 chars by the kernel. If it looks truncated,
    # try to get the full name from cmdline.
    if len(name) >= 15:
        try:
            with open(f'/proc/{pid}/cmdline', 'rb') as f:
                argv0 = f.read().split(b'\x00', 1)[0].decode('utf-8', errors='replace')
            basename = os.path.basename(argv0)
            if basename:
                name = basename
        except (PermissionError, FileNotFoundError, ProcessLookupError):
            pass

    return name or f'pid:{pid}'


def read_proc_exe(pid: int) -> str:
    try:
        return os.readlink(f'/proc/{pid}/exe')
    except (PermissionError, FileNotFoundError, OSError):
        return ''


def proc_has_gui_libs(pid: int) -> bool:
    """Check if a process loads any GUI library, reading maps line-by-line."""
    try:
        with open(f'/proc/{pid}/maps', 'r') as f:
            for line in f:
                for marker in GUI_LIB_MARKERS:
                    if marker in line:
                        return True
    except (PermissionError, FileNotFoundError, ProcessLookupError):
        pass
    return False


# ── Target Acquirer ───────────────────────────────────────────────────────────

class TargetAcquirer:

    def acquire_by_click(self) -> list[int]:
        try:
            result = subprocess.run(
                ['xprop', '_NET_WM_PID', 'WM_CLASS'],
                capture_output=True, text=True, timeout=30
            )
        except FileNotFoundError:
            print(
                "xprop not found. On pure Wayland, use one of these alternatives:\n"
                "  linux-im-diagnose --pid PID       (inspect a specific process)\n"
                "  linux-im-diagnose --search NAME    (fuzzy search by name, requires psutil)\n"
                "  linux-im-diagnose --all-gui        (scan all GUI processes, requires psutil)\n\n"
                "Find a PID with:  ps aux | grep appname",
                file=sys.stderr
            )
            sys.exit(1)
        except subprocess.TimeoutExpired:
            print("Timed out waiting for window click.", file=sys.stderr)
            sys.exit(1)

        if result.returncode != 0:
            print(
                "xprop failed. This may happen on pure Wayland sessions.\n"
                "Try: --pid PID  or  --search NAME  instead.",
                file=sys.stderr
            )
            sys.exit(1)

        match = re.search(r'_NET_WM_PID\(CARDINAL\)\s*=\s*(\d+)', result.stdout)
        if not match:
            print("Could not get PID from window. The window may not set _NET_WM_PID.", file=sys.stderr)
            sys.exit(1)

        return [int(match.group(1))]

    def acquire_by_search(self, query: str) -> list[int]:
        _require_psutil()
        query_lower = query.lower()
        own_pid = os.getpid()
        exclude_pids = set()
        try:
            p = psutil.Process(own_pid)
            for parent in p.parents():
                exclude_pids.add(parent.pid)
            for child in p.children(recursive=True):
                exclude_pids.add(child.pid)
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            pass
        exclude_pids.add(own_pid)

        results = []
        for proc in psutil.process_iter(['pid', 'name', 'cmdline']):
            try:
                pid = proc.info['pid']
                if pid in exclude_pids:
                    continue
                name = (proc.info['name'] or '').lower()
                cmdline = ' '.join(proc.info['cmdline'] or []).lower()
                if query_lower in name or query_lower in cmdline:
                    results.append(pid)
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue

        if not results:
            print(f"No processes matching '{query}' found.", file=sys.stderr)
            sys.exit(1)

        return results

    def acquire_by_pid(self, pid: int) -> list[int]:
        if not os.path.exists(f'/proc/{pid}'):
            print(f"PID {pid} does not exist.", file=sys.stderr)
            sys.exit(1)
        return [pid]

    def acquire_all_gui(self) -> list[int]:
        _require_psutil()
        gui_pids = []
        own_pid = os.getpid()
        for proc in psutil.process_iter(['pid', 'name']):
            pid = proc.info['pid']
            if pid == own_pid:
                continue
            try:
                with open(f'/proc/{pid}/environ', 'rb') as f:
                    env_raw = f.read()
                if b'DISPLAY=' not in env_raw and b'WAYLAND_DISPLAY=' not in env_raw:
                    continue
                if proc_has_gui_libs(pid):
                    gui_pids.append(pid)
            except (PermissionError, FileNotFoundError, ProcessLookupError):
                continue
        return gui_pids


# ── Framework Detector ────────────────────────────────────────────────────────

class FrameworkDetector:

    def detect(self, pid: int, maps_content: str, cmdline: str) -> tuple[list[str], str]:
        """Returns (frameworks, container_type)."""
        frameworks = []
        for name, pattern in FRAMEWORK_PATTERNS.items():
            if pattern.search(maps_content):
                frameworks.append(name)

        # Electron detection: multiple signals
        is_electron = False
        if ELECTRON_PATTERN.search(maps_content):
            is_electron = True
        elif ELECTRON_NODE_PATTERN.search(maps_content):
            is_electron = True
        elif any(marker in cmdline.lower() for marker in ELECTRON_CMDLINE_MARKERS):
            is_electron = True
        else:
            exe = read_proc_exe(pid)
            if 'electron' in exe.lower():
                is_electron = True

        if is_electron:
            frameworks.append('Electron')
        elif CHROMIUM_PATTERN.search(cmdline):
            if re.search(r'libnss3\.so', maps_content):
                frameworks.append('Chromium')

        if not frameworks:
            frameworks.append('Unknown')

        container = self._detect_container(pid, maps_content)
        return frameworks, container

    def _detect_container(self, pid: int, maps_content: str) -> str:
        if os.path.exists(f'/proc/{pid}/root/.flatpak-info'):
            return 'Flatpak'
        try:
            cgroup = read_proc_file(pid, 'cgroup')
            if re.search(r'app-flatpak-|/flatpak-', cgroup):
                return 'Flatpak'
            if re.search(r'/snap\.', cgroup):
                return 'Snap'
        except (PermissionError, ProcessLookupError):
            pass
        if '/snap/' in maps_content:
            return 'Snap'
        return ''

    def classify_electron(self, cmdline: str) -> str:
        m = re.search(r'--type=(\S+)', cmdline)
        if m:
            return m.group(1)
        return 'main'


# ── IM Module Detector ────────────────────────────────────────────���───────────

class IMModuleDetector:

    def detect_env(self, environ: dict) -> dict:
        return {k: environ[k] for k in IM_ENV_VARS if k in environ}

    def detect_loaded(self, maps_content: str) -> list[IMLoadedInfo]:
        loaded = []
        seen_paths = set()
        for line in maps_content.splitlines():
            parts = line.split(None, 5)
            if len(parts) < 6:
                continue
            path = parts[5].strip()
            if not path.startswith('/'):
                continue
            if path in seen_paths:
                continue

            if IM_LOADED_FCITX.search(path):
                seen_paths.add(path)
                loaded.append(IMLoadedInfo(im='fcitx', path=path))
            elif IM_LOADED_IBUS.search(path):
                seen_paths.add(path)
                loaded.append(IMLoadedInfo(im='ibus', path=path))

        return loaded


# ── Window System Detector ────────────────────────────────────────────────────

class WindowSystemDetector:

    def detect(self, environ: dict, maps_content: str) -> str:
        session_type = os.environ.get('XDG_SESSION_TYPE', '')
        wayland_display = environ.get('WAYLAND_DISPLAY', '')
        display = environ.get('DISPLAY', '')

        if session_type == 'wayland' or wayland_display:
            uses_x11 = bool(re.search(r'libX11\.so|libxcb\.so', maps_content))
            uses_wayland = bool(re.search(r'libwayland-client\.so', maps_content))

            if uses_wayland and not uses_x11:
                return 'Wayland Native'
            elif uses_x11:
                return 'XWayland'
            elif wayland_display:
                return 'Wayland Native'
            return 'Wayland'

        if display:
            return 'X11'

        return 'Unknown'


# ── D-Bus Checker ─────────────────────────────────────────────────��───────────

class DBusChecker:

    SERVICES = {
        'Fcitx5': 'org.fcitx.Fcitx5',
        'Fcitx': 'org.fcitx.Fcitx',
        'IBus': 'org.freedesktop.IBus',
    }

    def _list_bus_names(self) -> str | None:
        """List D-Bus session bus names, trying busctl then dbus-send."""
        # Try busctl first (systemd)
        try:
            out = subprocess.run(
                ['busctl', '--user', 'list', '--no-pager', '--no-legend'],
                capture_output=True, text=True, timeout=5
            )
            if out.returncode == 0:
                return out.stdout
        except (FileNotFoundError, subprocess.TimeoutExpired):
            pass

        # Fallback: dbus-send (works on non-systemd)
        try:
            out = subprocess.run(
                ['dbus-send', '--session', '--dest=org.freedesktop.DBus',
                 '--print-reply', '/org/freedesktop/DBus',
                 'org.freedesktop.DBus.ListNames'],
                capture_output=True, text=True, timeout=5
            )
            if out.returncode == 0:
                return out.stdout
        except (FileNotFoundError, subprocess.TimeoutExpired):
            pass

        return None

    def check_services(self) -> dict:
        bus_names = self._list_bus_names()
        if bus_names is None:
            return {k: False for k in self.SERVICES}

        results = {}
        for label, service_name in self.SERVICES.items():
            results[label] = service_name in bus_names
        return results

    def get_fcitx_current_im(self) -> str | None:
        for args in [
            # busctl: Fcitx5
            ['busctl', '--user', 'get-property', 'org.fcitx.Fcitx5',
             '/controller', 'org.fcitx.Fcitx.Controller1', 'CurrentIM'],
            # busctl: Fcitx4
            ['busctl', '--user', 'get-property', 'org.fcitx.Fcitx',
             '/inputmethod', 'org.fcitx.Fcitx.InputMethod', 'CurrentIM'],
        ]:
            try:
                result = subprocess.run(args, capture_output=True, text=True, timeout=5)
                match = re.search(r's "([^"]*)"', result.stdout)
                if match:
                    return match.group(1)
            except (FileNotFoundError, subprocess.TimeoutExpired):
                continue

        # Fallback: dbus-send for Fcitx5
        for service, path, iface, method in [
            ('org.fcitx.Fcitx5', '/controller', 'org.freedesktop.DBus.Properties',
             'Get string:org.fcitx.Fcitx.Controller1 string:CurrentIM'),
        ]:
            try:
                result = subprocess.run(
                    ['dbus-send', '--session', '--print-reply',
                     f'--dest={service}', path, f'{iface}.{method.split()[0]}',
                     *method.split()[1:]],
                    capture_output=True, text=True, timeout=5
                )
                match = re.search(r'string "([^"]*)"', result.stdout)
                if match:
                    return match.group(1)
            except (FileNotFoundError, subprocess.TimeoutExpired):
                continue

        return None


# ── Health Analyzer ───────────────────────────────────────────────────────────

class HealthAnalyzer:

    def analyze(self, info: ProcessInfo) -> None:
        warnings = []
        configured_im = self._extract_configured_im(info.im_env)
        loaded_ims = {item.im for item in info.im_loaded}

        if not configured_im and not loaded_ims:
            info.health_status = 'unknown'
            info.health_warnings = ['No IM configuration detected.']
            return

        # Env says fcitx but no fcitx loaded
        if configured_im == 'fcitx' and 'fcitx' not in loaded_ims:
            if 'ibus' in loaded_ims:
                msg = "GTK_IM_MODULE=fcitx but ibus module loaded instead."
                if 'GTK4' in info.frameworks:
                    msg += " GTK4 dropped GTK_IM_MODULE support; it uses ibus by default."
                warnings.append(msg)
            elif not loaded_ims:
                warnings.append("IM configured as fcitx but no IM module loaded in process.")
                if 'Electron' in info.frameworks:
                    warnings.append(
                        "Electron apps may need --enable-wayland-ime or "
                        "--gtk-version=4 flags for IM support."
                    )

        # Env says ibus but fcitx loaded
        if configured_im == 'ibus' and 'fcitx' in loaded_ims and 'ibus' not in loaded_ims:
            warnings.append("Environment says ibus but fcitx module is loaded.")

        # XMODIFIERS mismatch
        xmod = info.im_env.get('XMODIFIERS', '')
        if xmod:
            xmod_im = re.search(r'@im=(\w+)', xmod)
            if xmod_im and xmod_im.group(1) != configured_im and configured_im:
                warnings.append(
                    f"XMODIFIERS=@im={xmod_im.group(1)} but GTK/QT_IM_MODULE={configured_im}"
                )

        # Container isolation
        if info.container and configured_im and not loaded_ims:
            warnings.append(
                f"{info.container} app: IM module may not be available inside sandbox. "
                f"Check if {configured_im} IM module is installed in the runtime."
            )

        if not warnings:
            info.health_status = 'ok'
        elif configured_im and not loaded_ims:
            info.health_status = 'warn'
        else:
            info.health_status = 'warn'
        info.health_warnings = warnings

    def _extract_configured_im(self, env: dict) -> str | None:
        for key in ['GTK_IM_MODULE', 'QT_IM_MODULE']:
            val = env.get(key, '')
            if val:
                return val
        xmod = env.get('XMODIFIERS', '')
        m = re.search(r'@im=(\w+)', xmod)
        return m.group(1) if m else None


# ── Output Formatter ──────────────────────────────────────────────────────────

class OutputFormatter:

    HEALTH_SYMBOLS = {
        'ok':      '\033[32m[OK]\033[0m',
        'warn':    '\033[33m[WARN]\033[0m',
        'error':   '\033[31m[ERR]\033[0m',
        'unknown': '\033[90m[??]\033[0m',
    }

    HEALTH_SYMBOLS_PLAIN = {
        'ok':      '[OK]',
        'warn':    '[WARN]',
        'error':   '[ERR]',
        'unknown': '[??]',
    }

    def __init__(self, verbose: bool = False, json_mode: bool = False, no_color: bool = False):
        self.verbose = verbose
        self.json_mode = json_mode
        self.no_color = no_color or not sys.stdout.isatty()

    def format(self, results: list[ProcessInfo], dbus_info: dict, current_im: str | None) -> str:
        if self.json_mode:
            return self._format_json(results, dbus_info, current_im)
        return self._format_table(results, dbus_info, current_im)

    def _format_json(self, results: list[ProcessInfo], dbus_info: dict, current_im: str | None) -> str:
        data = {
            'dbus_services': dbus_info,
            'current_im': current_im,
            'processes': [],
        }
        for info in results:
            proc = {
                'pid': info.pid,
                'name': info.name,
                'window_system': info.window_system,
                'frameworks': info.frameworks,
                'container': info.container or None,
                'electron_type': info.electron_type or None,
                'im_configured': info.im_env,
                'im_loaded': [{'im': x.im, 'path': x.path} for x in info.im_loaded],
                'health_status': info.health_status,
                'health_warnings': info.health_warnings,
            }
            if info.error:
                proc['error'] = info.error
            data['processes'].append(proc)
        return json.dumps(data, indent=2, ensure_ascii=False)

    def _format_table(self, results: list[ProcessInfo], dbus_info: dict, current_im: str | None) -> str:
        symbols = self.HEALTH_SYMBOLS_PLAIN if self.no_color else self.HEALTH_SYMBOLS
        lines = []

        # Header
        lines.append("IM Framework Diagnostic Report")
        lines.append("=" * 72)

        # D-Bus services
        dbus_parts = []
        for label, active in dbus_info.items():
            status = self._color('active', '32') if active else self._color('inactive', '90')
            dbus_parts.append(f"{label}: {status}")
        dbus_line = "D-Bus IM Services:  " + "  |  ".join(dbus_parts)
        if current_im:
            dbus_line += f"  (Current: {current_im})"
        lines.append(dbus_line)
        lines.append("")

        if not results:
            lines.append("No processes to display.")
            return '\n'.join(lines)

        # Build rows
        headers = ['Process', 'PID', 'WinSys', 'Framework', 'IM Config', 'IM Loaded', 'Health']
        rows = []
        for info in results:
            if info.error:
                rows.append([
                    info.name, str(info.pid), '', '', '', '',
                    self._color(f'[ERR: {info.error}]', '31')
                ])
                continue

            fw = '/'.join(info.frameworks)
            if info.container:
                fw += f'/{info.container}'
            if info.electron_type and info.electron_type != 'main':
                fw += f' ({info.electron_type})'

            configured = self._extract_im_summary(info.im_env)
            loaded_ims = sorted(set(x.im for x in info.im_loaded))
            loaded = ','.join(loaded_ims) if loaded_ims else '-'

            rows.append([
                info.name, str(info.pid), info.window_system,
                fw, configured or '-', loaded,
                symbols.get(info.health_status, symbols['unknown'])
            ])

        # Calculate column widths
        col_widths = [len(h) for h in headers]
        for row in rows:
            for i, cell in enumerate(row):
                plain = self._strip_ansi(cell)
                col_widths[i] = max(col_widths[i], len(plain))

        # Format header
        lines.append('  '.join(
            h.ljust(col_widths[i]) for i, h in enumerate(headers)
        ))
        lines.append('-' * sum(col_widths + [2 * (len(col_widths) - 1)]))

        # Format rows
        for row in rows:
            padded = []
            for i, cell in enumerate(row):
                plain_len = len(self._strip_ansi(cell))
                padding = col_widths[i] - plain_len
                padded.append(cell + ' ' * max(0, padding))
            lines.append('  '.join(padded))

        # Warnings section
        warnings_output = []
        for info in results:
            if info.health_warnings and info.health_status in ('warn', 'error'):
                warnings_output.append(f"  {info.name} ({info.pid}):")
                for w in info.health_warnings:
                    warnings_output.append(f"    -> {w}")
                if self.verbose and info.im_loaded:
                    warnings_output.append("    Loaded IM modules:")
                    for item in info.im_loaded:
                        warnings_output.append(f"      {item.im}: {item.path}")

        if warnings_output:
            lines.append("")
            lines.append("Warnings:")
            lines.extend(warnings_output)

        # Verbose: show all loaded paths
        if self.verbose:
            lines.append("")
            lines.append("Loaded IM Module Details:")
            for info in results:
                if info.im_loaded:
                    lines.append(f"  {info.name} ({info.pid}):")
                    for item in info.im_loaded:
                        lines.append(f"    [{item.im}] {item.path}")

        return '\n'.join(lines)

    def _extract_im_summary(self, env: dict) -> str:
        parts = []
        for key in ['GTK_IM_MODULE', 'QT_IM_MODULE']:
            val = env.get(key)
            if val:
                parts.append(val)
                break
        xmod = env.get('XMODIFIERS', '')
        m = re.search(r'@im=(\w+)', xmod)
        if m:
            xim = m.group(1)
            if xim not in parts:
                parts.append(xim)
        return ','.join(parts) if parts else ''

    def _color(self, text: str, code: str) -> str:
        if self.no_color:
            return text
        return f'\033[{code}m{text}\033[0m'

    def _strip_ansi(self, text: str) -> str:
        return re.sub(r'\033\[\d+m', '', text)


# ── Process Inspector ─────────────────────────────────────────────────────────

def inspect_process(pid: int) -> ProcessInfo:
    info = ProcessInfo(pid=pid)
    framework_det = FrameworkDetector()
    im_det = IMModuleDetector()
    ws_det = WindowSystemDetector()
    health = HealthAnalyzer()

    info.name = read_proc_name(pid)

    try:
        info.cmdline = read_proc_file(pid, 'cmdline')
    except (PermissionError, ProcessLookupError):
        pass

    try:
        maps_content = read_proc_file(pid, 'maps')
    except PermissionError:
        info.error = "Permission denied (try sudo)"
        return info
    except ProcessLookupError:
        info.error = "Process no longer exists"
        return info

    try:
        environ = read_proc_environ(pid)
    except (PermissionError, ProcessLookupError):
        environ = {}

    # Framework
    info.frameworks, info.container = framework_det.detect(pid, maps_content, info.cmdline)

    # Electron classification
    if 'Electron' in info.frameworks or 'Chromium' in info.frameworks:
        info.electron_type = framework_det.classify_electron(info.cmdline)

    # IM env & loaded
    info.im_env = im_det.detect_env(environ)
    info.im_loaded = im_det.detect_loaded(maps_content)

    # Window system
    info.window_system = ws_det.detect(environ, maps_content)

    # Health
    health.analyze(info)

    return info


# ── Main ──────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description='Diagnose input method framework status for Linux applications.',
        epilog=(
            'examples:\n'
            '  %(prog)s --click              Click a window to inspect (X11)\n'
            '  %(prog)s --pid 12345          Inspect process by PID\n'
            '  %(prog)s --search firefox     Find and inspect by name\n'
            '  %(prog)s --all-gui            Scan all GUI processes\n'
            '  %(prog)s --all-gui --json     Output as JSON\n'
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    group = parser.add_mutually_exclusive_group()
    group.add_argument('--click', action='store_true',
                       help='Click a window to inspect (X11/XWayland)')
    group.add_argument('--pid', type=int,
                       help='Inspect a specific PID')
    group.add_argument('--search', type=str,
                       help='Fuzzy search by process name (requires psutil)')
    group.add_argument('--all-gui', action='store_true',
                       help='Scan all GUI processes (requires psutil)')
    parser.add_argument('--json', action='store_true',
                        help='Output as JSON')
    parser.add_argument('-v', '--verbose', action='store_true',
                        help='Show loaded .so paths')
    parser.add_argument('--no-color', action='store_true',
                        help='Disable colored output')
    parser.add_argument('--version', action='version',
                        version=f'linux-im-diagnose {__version__}')

    args = parser.parse_args()

    # Default mode
    if not any([args.click, args.pid, args.search, args.all_gui]):
        if os.environ.get('DISPLAY'):
            args.click = True
        else:
            args.all_gui = True

    acquirer = TargetAcquirer()

    if args.click:
        print("Click on a window to inspect...", file=sys.stderr)
        pids = acquirer.acquire_by_click()
    elif args.pid:
        pids = acquirer.acquire_by_pid(args.pid)
    elif args.search:
        pids = acquirer.acquire_by_search(args.search)
    else:
        pids = acquirer.acquire_all_gui()

    # D-Bus info
    dbus_checker = DBusChecker()
    dbus_info = dbus_checker.check_services()
    current_im = dbus_checker.get_fcitx_current_im()

    # Inspect each process
    results = []
    for pid in pids:
        try:
            info = inspect_process(pid)

            # Filter Electron child processes
            if info.electron_type in ELECTRON_TYPES_SKIP:
                continue

            results.append(info)
        except PermissionError as e:
            print(f"Warning: {e}", file=sys.stderr)
        except ProcessLookupError as e:
            print(f"Warning: {e}", file=sys.stderr)

    # Sort: errors last, then by name
    results.sort(key=lambda x: (bool(x.error), x.name.lower()))

    # Output
    formatter = OutputFormatter(
        verbose=args.verbose,
        json_mode=args.json,
        no_color=args.no_color
    )
    print(formatter.format(results, dbus_info, current_im))


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        sys.exit(130)
