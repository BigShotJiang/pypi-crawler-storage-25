"""linux-im-diagnose: Diagnose input method framework status for Linux applications."""

__version__ = '0.1.0'
