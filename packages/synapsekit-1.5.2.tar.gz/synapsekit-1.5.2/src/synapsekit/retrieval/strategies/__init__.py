"""Retrieval strategies subpackage."""
