# -*- coding: utf-8 -*-
"""
@author:XuMing(xuming624@qq.com)
@description: Runner - Independent execution engine for Agent (Async-First)

Runner is decoupled from Agent:
- Agent defines identity and capabilities ("who I am, what I can do")
- Runner handles execution (LLM calls, tool calls, streaming, memory updates)

Async-first public API:
- async: run(), run_stream()
- sync adapters: run_sync(), run_stream_sync()

Notes:
- `run(stream=True)` is intentionally not supported. Streaming is an explicit method.
- Multi-round execution is NOT part of the base Runner. If needed, implement it in
  specialized subclasses (e.g. DeepRunner).
"""

import asyncio
import json
import queue
import threading
from collections import defaultdict
from pathlib import Path
from typing import (
    Any,
    AsyncIterator,
    cast,
    Dict,
    Iterator,
    List,
    Optional,
    Sequence,
    TYPE_CHECKING,
    Union,
)
from uuid import uuid4

from pydantic import BaseModel

from agentica.utils.log import logger
from agentica.utils.async_utils import run_sync
from agentica.model.base import Model
from agentica.model.message import Message
from agentica.model.response import ModelResponse, ModelResponseEvent
from agentica.run_response import RunEvent, RunResponse
from agentica.run_config import RunConfig
from agentica.memory import AgentRun
from agentica.utils.string import parse_structured_output
from agentica.utils.langfuse_integration import langfuse_trace_context
from agentica.hooks import RunHooks

if TYPE_CHECKING:
    from agentica.agent import Agent


class Runner:
    """Independent execution engine for Agent.

    All core methods are async. Synchronous wrappers (run_sync, run_stream_sync)
    delegate to the async implementations via `run_sync()`.
    """

    def __init__(self, agent: "Agent"):
        self.agent = agent

    def save_run_response_to_file(
        self,
        message: Optional[Union[str, List, Dict, Message]] = None,
        save_response_to_file: Optional[str] = None,
    ) -> None:
        _save_path = save_response_to_file
        if _save_path is None or self.agent.run_response is None:
            return
        message_str = None
        if message is not None:
            if isinstance(message, str):
                message_str = message
            else:
                logger.warning("Did not use message in output file name: message is not a string")
        try:
            fn = _save_path.format(
                name=self.agent.name, message=message_str
            )
            fn_path = Path(fn)
            if not fn_path.parent.exists():
                fn_path.parent.mkdir(parents=True, exist_ok=True)
            if isinstance(self.agent.run_response.content, str):
                fn_path.write_text(self.agent.run_response.content)
            else:
                fn_path.write_text(json.dumps(self.agent.run_response.content, indent=2, ensure_ascii=False))
        except Exception as e:
            logger.warning(
                f"Failed to save output to file '{save_response_to_file}': {e} "
                f"[agent={self.agent.identifier}, run_id={self.agent.run_id}]"
            )

    def _aggregate_metrics_from_run_messages(self, messages: List[Message]) -> Dict[str, Any]:
        aggregated_metrics: Dict[str, Any] = defaultdict(list)
        for m in messages:
            if m.role == "assistant" and m.metrics is not None:
                for k, v in m.metrics.items():
                    aggregated_metrics[k].append(v)
        return aggregated_metrics

    def generic_run_response(self, content: Optional[str] = None, event: RunEvent = RunEvent.run_response) -> RunResponse:
        return RunResponse(
            run_id=self.agent.run_id,
            agent_id=self.agent.agent_id,
            content=content,
            tools=self.agent.run_response.tools,
            images=self.agent.run_response.images,
            videos=self.agent.run_response.videos,
            model=self.agent.run_response.model,
            messages=self.agent.run_response.messages,
            reasoning_content=self.agent.run_response.reasoning_content,
            extra_data=self.agent.run_response.extra_data,
            event=event.value,
        )

    # =========================================================================
    # Core execution engine (async-only, single-round)
    # =========================================================================

    async def _run_impl(
        self,
        message: Optional[Union[str, List, Dict, Message]] = None,
        *,
        stream: bool = False,
        audio: Optional[Any] = None,
        images: Optional[Sequence[Any]] = None,
        videos: Optional[Sequence[Any]] = None,
        messages: Optional[Sequence[Union[Dict, Message]]] = None,
        add_messages: Optional[List[Union[Dict, Message]]] = None,
        stream_intermediate_steps: bool = False,
        save_response_to_file: Optional[str] = None,
        run_timeout: Optional[float] = None,
        first_token_timeout: Optional[float] = None,
        hooks: Optional[RunHooks] = None,
        enabled_tools: Optional[List[str]] = None,
        enabled_skills: Optional[List[str]] = None,
        **kwargs: Any,
    ) -> AsyncIterator[RunResponse]:
        """Unified execution engine.

        This is the ONLY core runtime for base `Agent`.

        - Non-streaming users should call `run()` (which consumes this generator).
        - Streaming users should call `run_stream()` (which returns this generator).

        All LLM calls within this run are grouped under a single Langfuse trace (if enabled).
        """
        agent = self.agent

        async def _run_core() -> AsyncIterator[RunResponse]:
            # Guard: warn if this agent instance is already running concurrently.
            # Agent is not thread-safe — concurrent runs share mutable state
            # (run_id, run_response, _run_hooks, _enabled_tools, model.functions).
            # Swarm autonomous mode avoids this by cloning agents before parallel dispatch.
            if getattr(agent, '_running', False):
                logger.warning(
                    f"Agent '{agent.identifier}' is already running. "
                    "Concurrent reuse of the same Agent instance is not safe — "
                    "run_id, run_response, and model state will be overwritten. "
                    "Create a separate Agent instance for concurrent execution."
                )

            # Guard: early return if no input provided
            if (
                message is None
                and (messages is None or len(messages) == 0)
                and (add_messages is None or len(add_messages) == 0)
            ):
                logger.warning(
                    f"Agent '{agent.identifier}' called with no message and no messages. "
                    "Returning empty response."
                )
                yield RunResponse(
                    run_id=str(uuid4()),
                    agent_id=agent.agent_id,
                    content="",
                    event=RunEvent.run_response.value,
                )
                return

            agent._running = True
            agent.stream = stream and agent.is_streamable
            agent.stream_intermediate_steps = stream_intermediate_steps and agent.stream
            agent.run_id = str(uuid4())
            agent.run_response = RunResponse(run_id=agent.run_id, agent_id=agent.agent_id)

            # --- Session resume (CC-style JSONL) ---
            # On first run, if a session log exists, replay messages from
            # the last compact boundary into working_memory.
            if (
                agent._session_log is not None
                and agent._session_log.exists()
                and len(agent.working_memory.runs) == 0
            ):
                from agentica.model.message import Message as _ResumeMsg
                resumed_messages = agent._session_log.load()
                if resumed_messages:
                    for rm in resumed_messages:
                        agent.working_memory.add_message(
                            _ResumeMsg(role=rm["role"], content=rm.get("content", ""))
                        )
                    logger.debug(
                        f"Session resumed from JSONL: {len(resumed_messages)} messages"
                    )

            # --- Initialise CostTracker for this run ---
            from agentica.cost_tracker import CostTracker as _CostTracker
            _cost_tracker = _CostTracker()
            agent.run_response.cost_tracker = _cost_tracker

            # Set query-level tool/skill filtering (cleared after run)
            agent._enabled_tools = enabled_tools
            agent._enabled_skills = enabled_skills

            # Merge default run hooks (e.g. auto-archive) with user-provided hooks
            effective_hooks = None
            if hooks is not None and agent._default_run_hooks is not None:
                from agentica.hooks import _CompositeRunHooks
                effective_hooks = _CompositeRunHooks([agent._default_run_hooks, hooks])
            elif hooks is not None:
                effective_hooks = hooks
            elif agent._default_run_hooks is not None:
                effective_hooks = agent._default_run_hooks
            if effective_hooks is not None:
                agent._run_hooks = effective_hooks

            # 1. Setup
            agent.update_model()
            agent.run_response.model = agent.model.id if agent.model is not None else None
            if agent.context is not None:
                agent._resolve_context()

            # v3: Initialise a fresh CostTracker for this run and attach it to the model.
            # The tracker accumulates USD cost across all LLM invoke() calls via
            # Model.update_usage_metrics() / update_stream_metrics().
            # At run-end, the populated tracker is written to RunResponse.cost_tracker.
            if agent.model is not None:
                from agentica.cost_tracker import CostTracker as _CostTracker
                agent.model._cost_tracker = _CostTracker()
                # Reset per-run loop state counters on the model
                agent.model._loop_turn_count = 0
                agent.model._max_tokens_recovery_count = 0
                agent.model._reactive_compact_done = False
                agent.model._consecutive_all_error_turns = 0
                # Pass cost budget to model for per-turn checking
                agent.model._max_cost_usd = getattr(agent, '_run_max_cost_usd', None)

            # Add introduction if provided
            if agent.prompt_config.introduction is not None:
                agent.add_introduction(agent.prompt_config.introduction)

            # --- Lifecycle: agent start ---
            if agent.hooks is not None:
                await agent.hooks.on_start(agent=agent)
            if agent._run_hooks is not None:
                await agent._run_hooks.on_agent_start(agent=agent)

            # 3. Prepare messages
            system_message, user_messages, messages_for_model = await agent.get_messages_for_run(
                message=message, audio=audio, images=images, videos=videos,
                messages=messages, add_messages=add_messages, **kwargs
            )
            num_input_messages = len(messages_for_model)

            if agent.stream_intermediate_steps:
                yield self.generic_run_response("Run started", RunEvent.run_started)

            # 4. Generate response from the Model
            model_response: ModelResponse
            agent.model = cast(Model, agent.model)
            if stream and agent.is_streamable:
                # --- Lifecycle: LLM start (stream) ---
                if agent._run_hooks is not None:
                    await agent._run_hooks.on_llm_start(agent=agent, messages=messages_for_model)

                model_response = ModelResponse(content="", reasoning_content="")
                model_response_stream = agent.model.response_stream(messages=messages_for_model)
                agent._cancelled = False
                async for model_response_chunk in model_response_stream:
                    agent._check_cancelled()
                    if model_response_chunk.event == ModelResponseEvent.assistant_response.value:
                        if model_response_chunk.reasoning_content is not None:
                            if model_response.reasoning_content is None:
                                model_response.reasoning_content = ""
                            model_response.reasoning_content += model_response_chunk.reasoning_content
                            yield RunResponse(
                                event=RunEvent.run_response,
                                reasoning_content=model_response_chunk.reasoning_content,
                                run_id=agent.run_id,
                                agent_id=agent.agent_id,
                            )
                        if model_response_chunk.content is not None and model_response.content is not None:
                            model_response.content += model_response_chunk.content
                            yield RunResponse(
                                event=RunEvent.run_response,
                                content=model_response_chunk.content,
                                run_id=agent.run_id,
                                agent_id=agent.agent_id,
                            )
                    elif model_response_chunk.event == ModelResponseEvent.tool_call_started.value:
                        tool_call_dict = model_response_chunk.tool_call
                        if tool_call_dict is not None:
                            if agent.run_response.tools is None:
                                agent.run_response.tools = []
                            agent.run_response.tools.append(tool_call_dict)
                        if agent.stream_intermediate_steps:
                            yield self.generic_run_response(
                                f"Running tool: {tool_call_dict.get('name') if tool_call_dict else 'Unknown'}",
                                RunEvent.tool_call_started,
                            )
                    elif model_response_chunk.event == ModelResponseEvent.tool_call_completed.value:
                        tool_call_dict = model_response_chunk.tool_call
                        if tool_call_dict is not None and agent.run_response.tools:
                            for tool_call in agent.run_response.tools:
                                if tool_call.get("id") == tool_call_dict.get("id"):
                                    tool_call.update(tool_call_dict)
                                    break
                        if agent.stream_intermediate_steps:
                            yield self.generic_run_response(
                                f"Tool completed: {tool_call_dict.get('name') if tool_call_dict else 'Unknown'}",
                                RunEvent.tool_call_completed,
                            )

                # --- Lifecycle: LLM end (stream) ---
                if agent._run_hooks is not None:
                    await agent._run_hooks.on_llm_end(agent=agent, response=model_response)
            else:
                agent._cancelled = False
                agent._check_cancelled()

                # --- Lifecycle: LLM start (non-stream) ---
                if agent._run_hooks is not None:
                    await agent._run_hooks.on_llm_start(agent=agent, messages=messages_for_model)

                model_response = await agent.model.response(messages=messages_for_model)

                # --- Lifecycle: LLM end (non-stream) ---
                if agent._run_hooks is not None:
                    await agent._run_hooks.on_llm_end(agent=agent, response=model_response)

                # --- Context window usage warning ---
                _used_tokens = getattr(agent.model, 'metrics', {}).get('total_tokens', [])
                _window = getattr(agent.model, 'context_window', None)
                if _window and _used_tokens:
                    _total = sum(_used_tokens) if isinstance(_used_tokens, list) else _used_tokens
                    _pct = _total / _window
                    agent.run_response.metrics = agent.run_response.metrics or {}
                    agent.run_response.metrics['context_window_pct'] = round(_pct, 3)
                    if _pct >= 0.8:
                        logger.warning(
                            f"Agent '{agent.identifier}': context window usage is "
                            f"{_pct:.0%} ({_total}/{_window} tokens). "
                            "Consider summarizing or truncating conversation history."
                        )
                if agent.response_model is not None and agent.structured_outputs and model_response.parsed is not None:
                    agent.run_response.content = model_response.parsed
                    agent.run_response.content_type = agent.response_model.__name__
                else:
                    agent.run_response.content = model_response.content
                if model_response.audio is not None:
                    agent.run_response.audio = model_response.audio
                if model_response.reasoning_content is not None:
                    agent.run_response.reasoning_content = model_response.reasoning_content
                agent.run_response.messages = messages_for_model
                agent.run_response.created_at = model_response.created_at

                # Extract tool call info from messages for non-streaming mode
                tool_calls_data = []
                for msg in messages_for_model:
                    m = msg if isinstance(msg, Message) else None
                    if m is None:
                        continue
                    if m.role == "tool" and m.tool_name:
                        tool_calls_data.append(
                            {
                                "tool_call_id": m.tool_call_id,
                                "tool_name": m.tool_name,
                                "tool_args": m.tool_args,
                                "content": m.content,
                                "tool_call_error": getattr(m, "tool_call_error", False),
                                "metrics": m.metrics if hasattr(m, "metrics") else {},
                            }
                        )
                if tool_calls_data:
                    agent.run_response.tools = tool_calls_data

            # Build run messages
            run_messages = user_messages + messages_for_model[num_input_messages:]
            if system_message is not None:
                run_messages.insert(0, system_message)
            agent.run_response.messages = run_messages
            agent.run_response.metrics = self._aggregate_metrics_from_run_messages(run_messages)
            agent.run_response.usage = agent.model.usage if agent.model else None

            # --- Record cost from the last request's token usage ---
            if agent.model and agent.model.usage and agent.model.usage.request_usage_entries:
                _last = agent.model.usage.request_usage_entries[-1]
                _cache_read = 0
                _cache_write = 0
                if _last.input_tokens_details:
                    _cache_read = getattr(_last.input_tokens_details, 'cached_tokens', 0)
                agent.run_response.cost_tracker.record(
                    model_id=agent.model.id,
                    input_tokens=_last.input_tokens,
                    output_tokens=_last.output_tokens,
                    cache_read_tokens=_cache_read,
                    cache_write_tokens=_cache_write,
                )

            # v3: attach CostTracker to RunResponse
            if agent.model is not None and agent.model._cost_tracker is not None:
                agent.run_response.cost_tracker = agent.model._cost_tracker

            if agent.stream:
                agent.run_response.content = model_response.content
                if model_response.reasoning_content:
                    agent.run_response.reasoning_content = model_response.reasoning_content

            # 5. Update Memory
            if agent.stream_intermediate_steps:
                yield self.generic_run_response("Updating memory", RunEvent.updating_memory)

            if system_message is not None:
                agent.working_memory.add_system_message(system_message, system_message_role=agent.prompt_config.system_message_role)
            agent.working_memory.add_messages(messages=(user_messages + messages_for_model[num_input_messages:]))

            agent_run = AgentRun(response=agent.run_response)

            # Handle agent_run message assignment
            if message is not None:
                user_message_for_memory: Optional[Message] = None
                if isinstance(message, str):
                    user_message_for_memory = Message(role=agent.prompt_config.user_message_role, content=message)
                elif isinstance(message, Message):
                    user_message_for_memory = message
                if user_message_for_memory is not None:
                    agent_run.message = user_message_for_memory
            elif messages is not None and len(messages) > 0:
                for _m in messages:
                    _um = None
                    if isinstance(_m, Message):
                        _um = _m
                    elif isinstance(_m, dict):
                        try:
                            _um = Message(**_m)
                        except Exception as e:
                            logger.error(f"Error converting message to Message: {e}")
                    else:
                        logger.warning(f"Unsupported message type: {type(_m)}")
                        continue
                    if _um:
                        if agent_run.messages is None:
                            agent_run.messages = []
                        agent_run.messages.append(_um)
                    else:
                        logger.warning("Unable to add message to memory")
            agent.working_memory.add_run(agent_run)

            if agent.working_memory.create_session_summary and agent.working_memory.update_session_summary_after_run:
                await agent.working_memory.update_summary()

            # 6. Save output to file
            self.save_run_response_to_file(message=message, save_response_to_file=save_response_to_file)

            # 7. Set run_input
            if message is not None:
                if isinstance(message, str):
                    agent.run_input = message
                elif isinstance(message, Message):
                    agent.run_input = message.to_dict()
                else:
                    agent.run_input = message
            elif messages is not None:
                agent.run_input = [m.to_dict() if isinstance(m, Message) else m for m in messages]

            if agent.stream_intermediate_steps:
                yield self.generic_run_response(agent.run_response.content, RunEvent.run_completed)

            # --- Lifecycle: agent end ---
            _output = agent.run_response.content
            if agent.hooks is not None:
                await agent.hooks.on_end(agent=agent, output=_output)
            if agent._run_hooks is not None:
                await agent._run_hooks.on_agent_end(agent=agent, output=_output)

            if not agent.stream:
                yield agent.run_response

            # Clear query-level tool/skill filtering after run
            agent._enabled_tools = None
            agent._enabled_skills = None

            # --- Session persist (CC-style JSONL append) ---
            # Log the complete turn: user input + tool results + assistant output
            if agent._session_log is not None:
                # 1. Log user input
                _user_text = None
                if isinstance(message, str):
                    _user_text = message
                elif isinstance(message, Message):
                    _user_text = message.content if isinstance(message.content, str) else str(message.content)
                if _user_text:
                    agent._session_log.append("user", _user_text)

                # 2. Log tool results from this run (if any)
                if agent.run_response.tools:
                    for tc in agent.run_response.tools:
                        _tool_content = tc.get("content", "") or ""
                        # Truncate large tool results in JSONL (full result in tool_result_storage)
                        if len(_tool_content) > 2000:
                            _tool_content = _tool_content[:2000] + "\n... [truncated]"
                        agent._session_log.append(
                            "tool", _tool_content,
                            tool_name=tc.get("tool_name", ""),
                            tool_call_id=tc.get("tool_call_id", ""),
                            is_error=tc.get("tool_call_error", False),
                        )

                # 3. Log assistant output (with model info + usage, mirrors CC)
                _assistant_text = agent.run_response.content
                if _assistant_text and isinstance(_assistant_text, str):
                    _model_meta = {}
                    if agent.model:
                        _model_meta["model"] = agent.model.id
                        if agent.model.usage and agent.model.usage.request_usage_entries:
                            _last_usage = agent.model.usage.request_usage_entries[-1]
                            _model_meta["usage"] = {
                                "input_tokens": _last_usage.input_tokens,
                                "output_tokens": _last_usage.output_tokens,
                            }
                    agent._session_log.append("assistant", _assistant_text, **_model_meta)

            agent._running = False

        trace_input = message if isinstance(message, str) else str(message) if message else None
        trace_name = agent.name or "agent-run"

        langfuse_tags = None
        if agent.model and hasattr(agent.model, "langfuse_tags"):
            langfuse_tags = agent.model.langfuse_tags

        with langfuse_trace_context(
            name=trace_name,
            tags=langfuse_tags,
            input_data=trace_input,
        ) as trace:
            final_response: Optional[RunResponse] = None
            async for response in _run_core():
                final_response = response
                yield response

            if final_response:
                output_content = final_response.content
                if isinstance(output_content, BaseModel):
                    output_content = output_content.model_dump()
                trace.set_output(output_content)
                trace.set_metadata("run_id", final_response.run_id)
                trace.set_metadata("model", final_response.model)

    # =========================================================================
    # Timeout wrappers
    # =========================================================================

    async def _wrap_stream_with_timeout(
        self,
        stream_iter: AsyncIterator[RunResponse],
        run_timeout: Optional[float] = None,
        first_token_timeout: Optional[float] = None,
        idle_timeout: Optional[float] = None,
    ) -> AsyncIterator[RunResponse]:
        """Wrap an async streaming iterator with timeout control.

        Three independent timeouts (any one can fire):
        - first_token_timeout: max seconds to wait for the first token.
        - idle_timeout:        max seconds between consecutive tokens.
                               Detects "silent hang" where the connection stays
                               open but no data flows (mirrors CC's stream idle
                               watchdog in claude.ts).
        - run_timeout:         max total wall-clock seconds for the entire stream.
        """
        import time

        start_time = time.time()
        first_token_received = False
        last_token_time = start_time

        async for item in stream_iter:
            now = time.time()

            if not first_token_received:
                elapsed = now - start_time
                if first_token_timeout is not None and elapsed > first_token_timeout:
                    logger.warning(f"First token timed out after {first_token_timeout} seconds")
                    yield RunResponse(
                        run_id=str(uuid4()),
                        content=f"First token timed out after {first_token_timeout} seconds",
                        event="FirstTokenTimeout",
                    )
                    return
                first_token_received = True

            if run_timeout is not None:
                elapsed = now - start_time
                if elapsed > run_timeout:
                    logger.warning(f"Stream run timed out after {run_timeout} seconds")
                    yield RunResponse(
                        run_id=str(uuid4()),
                        content=f"Stream run timed out after {run_timeout} seconds",
                        event="RunTimeout",
                    )
                    return

            # Idle watchdog: detect "silent hang" between tokens
            if idle_timeout is not None and first_token_received:
                idle_elapsed = now - last_token_time
                if idle_elapsed > idle_timeout:
                    logger.warning(f"Stream idle timeout: no token for {idle_elapsed:.1f}s (limit {idle_timeout}s)")
                    yield RunResponse(
                        run_id=str(uuid4()),
                        content=f"Stream idle timeout: no new token for {idle_timeout} seconds",
                        event="StreamIdleTimeout",
                    )
                    return

            last_token_time = now
            yield item

    async def _run_with_timeout(
        self,
        message: Optional[Union[str, List, Dict, Message]] = None,
        audio: Optional[Any] = None,
        images: Optional[Sequence[Any]] = None,
        videos: Optional[Sequence[Any]] = None,
        messages: Optional[Sequence[Union[Dict, Message]]] = None,
        run_timeout: Optional[float] = None,
        **kwargs: Any,
    ) -> RunResponse:
        """Run the Agent with timeout control (non-streaming only)."""
        try:
            coro = self._consume_run(
                message=message,
                audio=audio,
                images=images,
                videos=videos,
                messages=messages,
                **kwargs,
            )
            result = await asyncio.wait_for(coro, timeout=run_timeout)
            return result
        except asyncio.TimeoutError:
            logger.warning(f"Agent run timed out after {run_timeout} seconds")
            return RunResponse(
                run_id=str(uuid4()),
                content=f"Agent run timed out after {run_timeout} seconds",
                event="RunTimeout",
            )

    async def _consume_run(
        self,
        message=None,
        *,
        audio=None,
        images=None,
        videos=None,
        messages=None,
        **kwargs,
    ) -> RunResponse:
        """Consume the _run_impl async generator and return the final response."""
        agent = self.agent
        run_response = None
        async for response in self._run_impl(
            message=message,
            stream=False,
            audio=audio,
            images=images,
            videos=videos,
            messages=messages,
            **kwargs,
        ):
            run_response = response

        if agent.response_model is not None:
            if agent.structured_outputs:
                if isinstance(run_response.content, agent.response_model):
                    return run_response

            if isinstance(run_response.content, str):
                try:
                    structured_output = parse_structured_output(run_response.content, agent.response_model)
                    if structured_output is not None:
                        run_response.content = structured_output
                        run_response.content_type = agent.response_model.__name__
                        if agent.run_response is not None:
                            agent.run_response.content = structured_output
                            agent.run_response.content_type = agent.response_model.__name__
                except Exception as e:
                    logger.warning(
                        f"Failed to convert response to output model "
                        f"'{agent.response_model.__name__ if agent.response_model else None}': {e} "
                        f"[agent={agent.identifier}, run_id={agent.run_id}]"
                    )

        return run_response

    # =========================================================================
    # Public API: async run()/run_stream() + sync adapters
    # =========================================================================

    async def run(
        self,
        message: Optional[Union[str, List, Dict, Message]] = None,
        *,
        audio: Optional[Any] = None,
        images: Optional[Sequence[Any]] = None,
        videos: Optional[Sequence[Any]] = None,
        messages: Optional[Sequence[Union[Dict, Message]]] = None,
        add_messages: Optional[List[Union[Dict, Message]]] = None,
        config: Optional[RunConfig] = None,
        **kwargs: Any,
    ) -> RunResponse:
        """Run the Agent and return the final response (non-streaming).

        This is the primary async API.

        Args:
            config: Per-run configuration (run_timeout, first_token_timeout,
                    save_response_to_file, hooks, etc.).
        """
        config = config or RunConfig()
        run_timeout = config.run_timeout
        first_token_timeout = config.first_token_timeout
        save_response_to_file = config.save_response_to_file
        hooks = config.hooks
        enabled_tools = config.enabled_tools
        enabled_skills = config.enabled_skills
        max_cost_usd = config.max_cost_usd

        # Stash cost budget on agent for _run_impl to pick up
        self.agent._run_max_cost_usd = max_cost_usd

        if run_timeout is not None:
            return await self._run_with_timeout(
                message=message,
                audio=audio,
                images=images,
                videos=videos,
                messages=messages,
                run_timeout=run_timeout,
                add_messages=add_messages,
                save_response_to_file=save_response_to_file,
                hooks=hooks,
                enabled_tools=enabled_tools,
                enabled_skills=enabled_skills,
                **kwargs,
            )

        # Structured output path
        if self.agent.response_model is not None:
            return await self._consume_run(
                message=message,
                audio=audio,
                images=images,
                videos=videos,
                messages=messages,
                add_messages=add_messages,
                save_response_to_file=save_response_to_file,
                hooks=hooks,
                enabled_tools=enabled_tools,
                enabled_skills=enabled_skills,
                **kwargs,
            )

        final_response = None
        async for response in self._run_impl(
            message=message,
            stream=False,
            audio=audio,
            images=images,
            videos=videos,
            messages=messages,
            add_messages=add_messages,
            save_response_to_file=save_response_to_file,
            hooks=hooks,
            enabled_tools=enabled_tools,
            enabled_skills=enabled_skills,
            **kwargs,
        ):
            final_response = response
        return final_response

    async def run_stream(
        self,
        message: Optional[Union[str, List, Dict, Message]] = None,
        *,
        audio: Optional[Any] = None,
        images: Optional[Sequence[Any]] = None,
        videos: Optional[Sequence[Any]] = None,
        messages: Optional[Sequence[Union[Dict, Message]]] = None,
        add_messages: Optional[List[Union[Dict, Message]]] = None,
        config: Optional[RunConfig] = None,
        **kwargs: Any,
    ) -> AsyncIterator[RunResponse]:
        """Run the Agent and stream incremental responses.

        Usage:
            async for chunk in runner.run_stream("..."):
                ...
        """
        config = config or RunConfig()
        stream_intermediate_steps = config.stream_intermediate_steps
        run_timeout = config.run_timeout
        first_token_timeout = config.first_token_timeout
        idle_timeout = config.idle_timeout
        save_response_to_file = config.save_response_to_file
        hooks = config.hooks
        enabled_tools = config.enabled_tools
        enabled_skills = config.enabled_skills

        # Stash cost budget on agent for _run_impl to pick up
        self.agent._run_max_cost_usd = config.max_cost_usd

        if self.agent.response_model is not None:
            raise ValueError("Structured output does not support streaming. Use run() instead.")

        resp: AsyncIterator[RunResponse] = self._run_impl(
            message=message,
            stream=True,
            audio=audio,
            images=images,
            videos=videos,
            messages=messages,
            add_messages=add_messages,
            stream_intermediate_steps=stream_intermediate_steps,
            save_response_to_file=save_response_to_file,
            hooks=hooks,
            enabled_tools=enabled_tools,
            enabled_skills=enabled_skills,
            **kwargs,
        )
        if run_timeout is not None or first_token_timeout is not None or idle_timeout is not None:
            resp = self._wrap_stream_with_timeout(
                resp, run_timeout=run_timeout, first_token_timeout=first_token_timeout,
                idle_timeout=idle_timeout,
            )

        async for item in resp:
            yield item

    def run_sync(
        self,
        message: Optional[Union[str, List, Dict, Message]] = None,
        *,
        audio: Optional[Any] = None,
        images: Optional[Sequence[Any]] = None,
        videos: Optional[Sequence[Any]] = None,
        messages: Optional[Sequence[Union[Dict, Message]]] = None,
        add_messages: Optional[List[Union[Dict, Message]]] = None,
        config: Optional[RunConfig] = None,
        **kwargs: Any,
    ) -> RunResponse:
        """Synchronous wrapper for `run()` (non-streaming only)."""
        return run_sync(
            self.run(
                message=message,
                audio=audio,
                images=images,
                videos=videos,
                messages=messages,
                add_messages=add_messages,
                config=config,
                **kwargs,
            )
        )

    def run_stream_sync(
        self,
        message: Optional[Union[str, List, Dict, Message]] = None,
        *,
        audio: Optional[Any] = None,
        images: Optional[Sequence[Any]] = None,
        videos: Optional[Sequence[Any]] = None,
        messages: Optional[Sequence[Union[Dict, Message]]] = None,
        add_messages: Optional[List[Union[Dict, Message]]] = None,
        config: Optional[RunConfig] = None,
        **kwargs: Any,
    ) -> Iterator[RunResponse]:
        """Synchronous wrapper for `run_stream()`.

        Internally runs the async iterator in a dedicated background thread.
        """

        def _iter_from_async(ait: AsyncIterator[RunResponse]) -> Iterator[RunResponse]:
            sentinel = object()
            q: "queue.Queue[object]" = queue.Queue()

            def _producer() -> None:
                async def _consume() -> None:
                    try:
                        async for item in ait:
                            q.put(item)
                    except BaseException as e:
                        q.put(e)
                    finally:
                        try:
                            if hasattr(ait, "aclose"):
                                await ait.aclose()  # type: ignore[attr-defined]
                        finally:
                            q.put(sentinel)

                asyncio.run(_consume())

            thread = threading.Thread(target=_producer, daemon=True)
            thread.start()

            try:
                while True:
                    item = q.get()
                    if item is sentinel:
                        break
                    if isinstance(item, BaseException):
                        raise item
                    yield cast(RunResponse, item)
            finally:
                # Best-effort: let the producer finish; it will be daemon anyway.
                pass

        return _iter_from_async(
            self.run_stream(
                message=message,
                audio=audio,
                images=images,
                videos=videos,
                messages=messages,
                add_messages=add_messages,
                config=config,
                **kwargs,
            )
        )
