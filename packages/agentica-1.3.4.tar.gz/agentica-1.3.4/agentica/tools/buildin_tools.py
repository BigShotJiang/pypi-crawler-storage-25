# -*- coding: utf-8 -*-
"""
@author:XuMing(xuming624@qq.com)
@description: Built-in tools for Agent

Built-in tool set for Agent, including:
- ls: List directory contents
- read_file: Read file content
- write_file: Write file content
- edit_file: Edit file (string replacement)
- multi_edit_file: Apply multiple edits to a file atomically
- glob: File pattern matching
- grep: Search file content
- execute: Execute command
- web_search: Web search (implemented using BaiduSearch)
- fetch_url: Fetch URL content (implemented using UrlCrawler)
- write_todos: Create and manage task list
- read_todos: Read current task list
- task: Launch subagent to handle complex tasks
"""
import asyncio
import json
import os
import re
import shutil
import tempfile
from datetime import datetime
import time
import uuid
from pathlib import Path
from textwrap import dedent
from typing import Optional, List, Dict, Any, Literal, TYPE_CHECKING, Union

import aiofiles

from agentica.tools.base import Tool
from agentica.utils.log import logger
from agentica.utils.string import truncate_if_too_long

if TYPE_CHECKING:
    from agentica.agent import Agent
    from agentica.model.base import Model


class BuiltinFileTool(Tool):
    """
    Built-in file system tool providing ls, read_file, write_file, edit_file, multi_edit_file, glob, grep functions.
    """

    def __init__(
            self,
            work_dir: Optional[str] = None,
            max_read_lines: int = 500,
            max_line_length: int = 2000,
            sandbox_config=None,
    ):
        """
        Initialize BuiltinFileTool.

        Args:
            work_dir: Work directory for file operations, defaults to current working directory
            max_read_lines: Maximum number of lines to read by default
            max_line_length: Maximum length per line, longer lines will be truncated
            sandbox_config: SandboxConfig instance for path restriction enforcement
        """
        super().__init__(name="builtin_file_tool")
        self.work_dir = Path(work_dir) if work_dir else Path.cwd()
        self.max_read_lines = max_read_lines
        self.max_line_length = max_line_length
        self._file_locks: Dict[str, asyncio.Lock] = {}
        self._sandbox_config = sandbox_config

        # Register all file operation functions
        # Read-only tools are concurrency_safe (can run in parallel with each other).
        # Write tools (write_file, edit_file, multi_edit_file) stay serialised.
        self.register(self.ls, concurrency_safe=True)
        self.register(self.read_file, concurrency_safe=True)
        self.register(self.write_file, sanitize_arguments=False)
        self.register(self.edit_file, sanitize_arguments=False)
        self.register(self.multi_edit_file, sanitize_arguments=False)
        self.register(self.glob, concurrency_safe=True)
        self.register(self.grep, concurrency_safe=True)

    def _resolve_path(self, path: str) -> Path:
        """Resolve path, supporting absolute, relative, and ~ paths.

        - ~ paths are expanded to user home directory
        - Absolute paths are used directly
        - Relative paths are resolved relative to work_dir
        """
        # Expand ~ to user home directory
        if path.startswith("~"):
            return Path(path).expanduser()
        p = Path(path)
        if p.is_absolute():
            return p
        return self.work_dir / p

    def _get_file_lock(self, path: str) -> asyncio.Lock:
        """Get or create a per-file asyncio.Lock to serialize concurrent edits."""
        if path not in self._file_locks:
            self._file_locks[path] = asyncio.Lock()
        return self._file_locks[path]

    def _validate_path(self, path: str) -> str:
        """Validate path against sandbox restrictions.

        When sandbox is enabled, checks that:
        - Path components do not match any blocked_paths entries
        - Uses path component matching (not substring) to avoid false positives
        - For write operations, caller should use _validate_write_path instead

        Raises:
            PermissionError: If path is blocked by sandbox config
        """
        if self._sandbox_config is None or not self._sandbox_config.enabled:
            return path
        resolved = self._resolve_path(path).resolve()
        resolved_parts = set(resolved.parts)
        for blocked in self._sandbox_config.blocked_paths:
            if blocked in resolved_parts:
                raise PermissionError(f"Sandbox: access to path containing '{blocked}' is blocked")
        return path

    def _validate_write_path(self, path: str) -> str:
        """Validate that a write operation is allowed under sandbox restrictions.

        Checks blocked_paths and writable_dirs whitelist.

        Raises:
            PermissionError: If write is not allowed
        """
        self._validate_path(path)
        if self._sandbox_config is None or not self._sandbox_config.enabled:
            return path
        resolved = str(self._resolve_path(path).resolve())
        # If writable_dirs is configured, enforce whitelist
        if self._sandbox_config.writable_dirs:
            allowed = False
            for wd in self._sandbox_config.writable_dirs:
                wd_resolved = str(Path(wd).expanduser().resolve())
                if resolved.startswith(wd_resolved):
                    allowed = True
                    break
            if not allowed:
                # Also allow work_dir
                work_dir_str = str(self.work_dir.resolve())
                if not resolved.startswith(work_dir_str):
                    raise PermissionError(
                        f"Sandbox: write to '{path}' is not allowed. "
                        f"Writable dirs: {self._sandbox_config.writable_dirs}"
                    )
        return path

    async def ls(self, directory: str = ".") -> str:
        """Lists all files in the directory.

        Usage:
        - The directory parameter can be an absolute or relative path
        - The ls tool will return a list of all files in the specified directory.
        - This is very useful for exploring the file system and finding the right file to read or edit.
        - You should almost ALWAYS use this tool before using the Read or Edit tools.

        Args:
            directory: Directory path to list files, defaults to current directory

        Returns:
            str, JSON formatted file list
        """
        try:
            self._validate_path(directory)
            dir_path = self._resolve_path(directory)

            if not dir_path.exists():
                return f"Error: Directory not found: {directory}"
            if not dir_path.is_dir():
                return f"Error: Not a directory: {directory}"

            def _ls_sync():
                items = []
                for item in sorted(dir_path.iterdir()):
                    item_type = "dir" if item.is_dir() else "file"
                    items.append({
                        "name": item.name,
                        "path": str(item),
                        "type": item_type,
                    })
                return items

            items = await asyncio.get_event_loop().run_in_executor(None, _ls_sync)

            logger.debug(f"Listed {len(items)} items in {dir_path}")
            result = json.dumps(items, ensure_ascii=False, indent=2)
            result = truncate_if_too_long(result)
            return str(result)
        except Exception as e:
            logger.error(f"Error listing directory {directory}: {e}")
            return f"Error listing directory: {e}"

    # Maximum file size (bytes) for read_file.  Larger files must use offset+limit.
    # Mirrors CC's FileReadTool maxSizeBytes (256KB).
    MAX_FILE_SIZE_BYTES = 256_000

    async def read_file(
            self,
            file_path: str,
            offset: int = 0,
            limit: Optional[int] = 500,
    ) -> str:
        """Reads a file from the filesystem. You can access any file directly by using this tool.
        Assume this tool is able to read all files on the machine. If the User provides a path to a file assume that path is valid. It is okay to read a file that does not exist; an error will be returned.

        Usage:
        - The file_path parameter must be an absolute path, not a relative path
        - By default, it reads up to 500 lines starting from the beginning of the file
        - **IMPORTANT for large files and codebase exploration**: Use pagination with offset and limit parameters to avoid context overflow
        - First scan: read_file(path, limit=100) to see file structure
        - Read more sections: read_file(path, offset=100, limit=200) for next 200 lines
        - Only omit limit (read full file) when necessary for editing
        - Specify offset and limit: read_file(path, offset=0, limit=100) reads first 100 lines
        - Any lines longer than 2000 characters will be truncated
        - Results are returned using cat -n format, with line numbers starting at 1
        - You have the capability to call multiple tools in a single response. It is always better to speculatively read multiple files as a batch that are potentially useful.
        - If you read a file that exists but has empty contents you will receive a system reminder warning in place of file contents.
        - You should ALWAYS make sure a file has been read before editing it.

        Args:
            file_path: File path, support md, txt, py, etc. absolute path
            offset: Starting line number (0-based)
            limit: Maximum number of lines to read, defaults to 500

        Returns:
            File content with line numbers
        """
        try:
            self._validate_path(file_path)
            path = self._resolve_path(file_path)

            if not path.exists():
                return f"Error: File not found: {file_path}"
            if not path.is_file():
                return f"Error: Not a file: {file_path}"

            # --- Large-file guard (mirrors CC's maxSizeBytes) ---
            try:
                file_size = path.stat().st_size
                if file_size > self.MAX_FILE_SIZE_BYTES:
                    total_lines = sum(1 for _ in open(path, errors='ignore'))
                    return (
                        f"Error: File too large ({file_size:,} bytes, {total_lines:,} lines). "
                        f"Use offset and limit to read specific sections.\n"
                        f"Example: read_file('{file_path}', offset=0, limit=100)"
                    )
            except OSError:
                pass  # stat failed — proceed with read, let it fail naturally

            limit = limit if limit is not None else self.max_read_lines
            max_line_len = self.max_line_length

            # Async streaming read — only read the lines we need
            output_lines = []
            total_lines = 0
            end_line = offset + limit
            async with aiofiles.open(path, 'r', encoding='utf-8', errors='ignore') as f:
                async for line in f:
                    total_lines += 1
                    if total_lines > offset and total_lines <= end_line:
                        line = line.rstrip('\n\r')
                        if len(line) > max_line_len:
                            line = line[:max_line_len] + "..."
                        output_lines.append(f"{total_lines:6d}\t{line}")

            result = "\n".join(output_lines)

            # Add file info if truncated
            actual_end = min(offset + len(output_lines), total_lines)
            if actual_end < total_lines:
                result += f"\n\n[Showing lines {offset + 1}-{actual_end} of {total_lines} total lines]"

            logger.debug(f"Read file {file_path}: lines {offset + 1}-{actual_end}, total {total_lines} lines")
            return result
        except Exception as e:
            logger.error(f"Error reading file {file_path}: {e}")
            return f"Error reading file: {e}"

    async def write_file(self, file_path: str, content: str) -> str:
        """Writes content to a file in the filesystem.

        Usage:
        - The file_path can be relative (e.g., "tmp/script.py", "./outputs/data.txt") or absolute path
        - Relative paths are resolved relative to the base working directory
        - The tool returns the actual absolute path of the created file - ALWAYS use this returned path for subsequent operations (read_file, execute, etc.)
        - The content parameter must be a string
        - The write_file tool will create a new file or overwrite existing file
        - Parent directories will be created automatically if they don't exist
        - Prefer to edit existing files over creating new ones when possible

        IMPORTANT: After calling write_file, use the absolute path returned in the result for any follow-up operations like execute or read_file. Do NOT guess or construct the path yourself.

        Args:
            file_path: File path (relative or absolute). Examples: "tmp/script.py", "outputs/result.txt", "./tmp/main.py", use './tmp/' prefix file path for temporary files
            content: File content to write

        Returns:
            Operation result message containing the actual absolute path of the file
        """
        try:
            self._validate_write_path(file_path)
            path = self._resolve_path(file_path)
            # Ensure directory exists
            path.parent.mkdir(parents=True, exist_ok=True)
            action = "Created" if not path.exists() else "Updated"

            # Atomic write: write to temp file then rename to avoid partial writes
            tmp_fd, tmp_path = tempfile.mkstemp(dir=str(path.parent), suffix=".tmp")
            try:
                os.close(tmp_fd)
                async with aiofiles.open(tmp_path, 'w', encoding='utf-8') as f:
                    await f.write(content)
                # Atomic rename
                os.replace(tmp_path, str(path))
            except Exception:
                # Clean up temp file on error
                try:
                    os.unlink(tmp_path)
                except OSError:
                    pass
                raise

            # Return absolute path to help LLM use correct path in subsequent operations
            absolute_path = str(path.resolve())
            logger.debug(f"{action} file: {absolute_path}, file content length: {len(content)} characters")
            return f"{action} file, absolute path: {absolute_path}"
        except Exception as e:
            logger.error(f"Error writing file {file_path}: {e}")
            return f"Error writing file: {e}"

    async def edit_file(
            self,
            file_path: str,
            old_string: str,
            new_string: str,
            replace_all: bool = False,
    ) -> str:
        """Replace a specific string in a file.

        Uses literal string matching (NOT regex). Multi-line strings are supported.
        Prefer this tool over write_file or shell `sed` for targeted changes.

        For multiple edits to the SAME file, prefer `multi_edit_file` to apply them
        atomically in one call. If you call `edit_file` multiple times on the same file
        in parallel, they will be serialized automatically to avoid race conditions.

        Args:
            file_path: The path to the file to edit. Absolute paths required for files
                      outside the working directory.
            old_string: The existing text to find and replace. Must match exactly.
            new_string: The replacement text.
            replace_all: Whether to replace all occurrences. Default: False (replace first
                        match only; errors if multiple matches found).

        Returns:
            Operation result message

        Examples:
            edit_file("app.py", "def foo():", "def bar():")
            edit_file("config.py", "DEBUG = True", "DEBUG = False")
            edit_file("test.py", "old_name", "new_name", replace_all=True)
        """
        try:
            self._validate_write_path(file_path)
            path = self._resolve_path(file_path)
            path_key = str(path)

            if not path.exists():
                return f"Error: File not found: {file_path}"
            if not path.is_file():
                return f"Error: Not a file: {file_path}"

            # Per-file lock to serialize concurrent edits on the same file
            lock = self._get_file_lock(path_key)
            async with lock:
                async with aiofiles.open(path, 'r', encoding='utf-8') as f:
                    content = await f.read()

                result = self._str_replace(content, old_string, new_string, replace_all)

                if not result["success"]:
                    return f"Error: {result['error']}"

                # Atomic write back
                tmp_fd, tmp_path = tempfile.mkstemp(dir=str(path.parent), suffix=".tmp")
                try:
                    os.close(tmp_fd)
                    async with aiofiles.open(tmp_path, 'w', encoding='utf-8') as f:
                        await f.write(result["new_content"])
                    os.replace(tmp_path, str(path))
                except Exception:
                    try:
                        os.unlink(tmp_path)
                    except OSError:
                        pass
                    raise

            logger.debug(f"Replaced {result['count']} occurrence(s) in {file_path}")
            return f"Successfully replaced {result['count']} occurrence(s) in '{file_path}'"

        except Exception as e:
            logger.error(f"Error editing file {file_path}: {e}")
            return f"Error editing file: {e}"

    async def multi_edit_file(
            self,
            file_path: str,
            edits: List[Dict[str, Any]],
    ) -> str:
        """Apply multiple edits to a single file atomically.

        All edits are applied sequentially on the same in-memory content,
        then written back once. If any edit fails, no changes are made.

        This is preferred over multiple parallel `edit_file` calls when you need
        to make several changes to the same file — it is faster, uses fewer tokens,
        and guarantees atomicity.

        Args:
            file_path: Path to the file to edit.
            edits: List of edit operations. Each dict must contain:
                - old_string (str): The existing text to find
                - new_string (str): The replacement text
                - replace_all (bool, optional): Replace all occurrences. Default: False

        Returns:
            Summary of all applied edits, or error message if any edit fails.

        Examples:
            multi_edit_file("app.py", [
                {"old_string": "foo", "new_string": "bar"},
                {"old_string": "DEBUG = True", "new_string": "DEBUG = False"},
            ])
        """
        try:
            self._validate_write_path(file_path)
            path = self._resolve_path(file_path)
            path_key = str(path)

            if not path.exists():
                return f"Error: File not found: {file_path}"
            if not path.is_file():
                return f"Error: Not a file: {file_path}"
            if not edits:
                return "Error: 'edits' list cannot be empty."

            lock = self._get_file_lock(path_key)
            async with lock:
                async with aiofiles.open(path, 'r', encoding='utf-8') as f:
                    content = await f.read()

                # Apply edits sequentially on in-memory content
                results = []
                for i, edit in enumerate(edits):
                    old_string = edit.get("old_string", "")
                    new_string = edit.get("new_string", "")
                    replace_all = edit.get("replace_all", False)

                    if not old_string:
                        return f"Error: Edit {i + 1} has empty old_string. No changes were made."

                    result = self._str_replace(content, old_string, new_string, replace_all)
                    if not result["success"]:
                        return f"Error in edit {i + 1}/{len(edits)}: {result['error']}. No changes were made."

                    content = result["new_content"]
                    results.append(f"Edit {i + 1}: replaced {result['count']} occurrence(s)")

                # Atomic write (once)
                tmp_fd, tmp_path = tempfile.mkstemp(dir=str(path.parent), suffix=".tmp")
                try:
                    os.close(tmp_fd)
                    async with aiofiles.open(tmp_path, 'w', encoding='utf-8') as f:
                        await f.write(content)
                    os.replace(tmp_path, str(path))
                except Exception:
                    try:
                        os.unlink(tmp_path)
                    except OSError:
                        pass
                    raise

            summary = f"Successfully applied {len(edits)} edits to '{file_path}':\n" + "\n".join(results)
            logger.debug(summary)
            return summary

        except Exception as e:
            logger.error(f"Error multi-editing file {file_path}: {e}")
            return f"Error multi-editing file: {e}"

    def _str_replace(
            self,
            content: str,
            old_string: str,
            new_string: str,
            replace_all: bool = False,
    ) -> dict:
        """Internal string replacement logic.

        Returns:
            {"success": bool, "new_content": str, "count": int, "error": str}
        """
        # Find all match positions
        matches = []
        start = 0
        while True:
            idx = content.find(old_string, start)
            if idx == -1:
                break
            matches.append(idx)
            start = idx + len(old_string)

        if not matches:
            display_old = old_string[:100] + "..." if len(old_string) > 100 else old_string
            return {
                "success": False,
                "error": f"String not found: '{display_old}'",
                "new_content": content,
                "count": 0,
            }

        # If not replace_all and multiple matches, show context for each match
        if not replace_all and len(matches) > 1:
            contexts = []
            for idx in matches[:3]:  # Show first 3 matches
                line_num = content[:idx].count('\n') + 1
                # Get surrounding context (up to 50 chars around the match)
                context_start = max(0, idx - 20)
                context_end = min(len(content), idx + len(old_string) + 30)
                context = content[context_start:context_end].replace('\n', '\\n')
                contexts.append(f"  Line {line_num}: ...{context}...")

            error_msg = (
                f"Found {len(matches)} occurrences of the string.\n"
                f"Use replace_all=True to replace all, or provide more context to make it unique.\n"
                f"Matches found at:\n" + '\n'.join(contexts)
            )
            if len(matches) > 3:
                error_msg += f"\n  ... and {len(matches) - 3} more"

            return {
                "success": False,
                "error": error_msg,
                "new_content": content,
                "count": len(matches),
            }

        # Perform replacement
        if replace_all:
            new_content = content.replace(old_string, new_string)
            count = len(matches)
        else:
            # Replace only the first match (leftmost)
            idx = matches[0]
            new_content = content[:idx] + new_string + content[idx + len(old_string):]
            count = 1

        return {
            "success": True,
            "new_content": new_content,
            "count": count,
            "error": None,
        }

    async def glob(self, pattern: str, path: str = ".") -> str:
        """Find files matching a glob pattern (supports recursive search with `**`).

        Usage:
        - This tool searches for files by matching standard glob wildcards, returns JSON formatted absolute file paths
        - Core glob wildcards (key differences):
        1. `*`: Matches any files in the **current specified single directory** (non-recursive, no deep subdirectories)
        2. `**`: Matches any directories recursively (penetrates all deep subdirectories for cross-level search)
        3. `?`: Matches any single character (e.g., "file?.txt" matches "file1.txt", "filea.txt")
        - Patterns can be absolute (starting with `/`, e.g., "/home/user/*.py") or relative (e.g., "docs/*.md")
        - Automatically excludes common useless directories (.git, __pycache__, etc.) to filter valid files
        - Returns empty JSON list if no matching files are found

        Examples (clear parameter correspondence and function explanation):
        - pattern: `*.py`, path: "." - Find all Python files in the current working directory (non-recursive)
        - pattern: `*.txt`, path: "." - Find all text files in the current working directory (non-recursive)
        - pattern: `**/*.md`, path: "/path/to/subdir/" - Find all markdown files in all levels under /path/to/subdir/ (recursive)
        - pattern: `subdir/*.md`, path: "." - Find all markdown files directly in the "subdir" folder (non-recursive, no deep subdirs)

        Args:
            pattern: Valid glob search pattern, e.g., "*.py", "**/*.md", "src/?*.js"
            path: Starting search directory (relative or absolute), defaults to current working directory (".").

        Returns:
            JSON formatted string of sorted absolute file paths (filtered to exclude ignored directories).
            Error message string if directory not found or other exceptions occur.
        """
        try:
            self._validate_path(path)
            base_path = self._resolve_path(path)

            if not base_path.exists():
                return f"Error: Directory not found: {path}"

            # Run glob in executor to avoid blocking on large directory trees
            def _glob_sync():
                matches = list(base_path.glob(pattern))
                ignore_dirs = {'.git', '__pycache__', 'node_modules', '.venv', 'venv', '.idea', '.pytest_cache'}
                return sorted(
                    str(m) for m in matches
                    if not set(m.parts).intersection(ignore_dirs)
                )

            filtered = await asyncio.get_event_loop().run_in_executor(None, _glob_sync)

            logger.debug(f"Glob found {len(filtered)} files matching pattern '{pattern}' in directory '{path}'")
            # Convert to formatted JSON string
            result = json.dumps(filtered, ensure_ascii=False, indent=2)
            # Truncate if content exceeds the limit to avoid excessive output
            result = truncate_if_too_long(result)
            return str(result)
        except Exception as e:
            logger.error(f"Exception occurred during glob search (pattern: '{pattern}', path: '{path}'): {str(e)}")
            return f"Error in glob search: {str(e)}"

    async def grep(
            self,
            pattern: str,
            path: str = ".",
            *,
            include: Optional[str] = None,
            output_mode: Literal["files_with_matches", "content", "count"] = "files_with_matches",
            case_insensitive: bool = False,
            multiline: bool = False,
            context_lines: int = 0,
            before_context: int = 0,
            after_context: int = 0,
            max_results: int = 100,
            fixed_strings: bool = False,
    ) -> str:
        """Search for a pattern in files using ripgrep (rg).

        Usage:
        - Searches text patterns across files, powered by ripgrep for maximum speed
        - The pattern parameter supports regex by default (e.g., 'class \\w+', 'def \\w+')
        - Use fixed_strings=True to treat pattern as literal text (no regex interpretation)
        - The path parameter specifies the search directory (default: current working directory)
        - The include parameter filters files by glob (e.g., "*.py", "*.{ts,tsx}")
        - The output_mode parameter controls output format:
          - "files_with_matches": List only file paths (default)
          - "content": Show matching lines with file path, line numbers, and optional context
          - "count": Show match count per file
        - Automatically falls back to pure Python search if ripgrep is not installed

        Args:
            pattern: Text/regex to search for
            path: Starting directory for search (default: ".")
            include: File glob filter, e.g., "*.py", "*.{js,ts}" (maps to rg --glob)
            output_mode: Output format — "files_with_matches", "content", or "count"
            case_insensitive: Ignore case when matching (default: False)
            multiline: Enable multiline matching where . matches newlines (default: False)
            context_lines: Show N lines before and after each match (default: 0, content mode only)
            before_context: Show N lines before each match (default: 0, content mode only)
            after_context: Show N lines after each match (default: 0, content mode only)
            max_results: Maximum results to return (default: 100)
            fixed_strings: Treat pattern as literal text, not regex (default: False)

        Returns:
            Search results as formatted string
        """
        # Resolve and validate path
        self._validate_path(path)
        base_path = self._resolve_path(path)
        if not base_path.exists():
            return f"Error: Directory not found: {path}"

        # Check if rg is available
        rg_path = shutil.which("rg")
        if rg_path is None:
            return await asyncio.get_event_loop().run_in_executor(
                None, self._grep_fallback, pattern, path, include, output_mode,
                max_results, fixed_strings, case_insensitive,
            )

        # Build rg command arguments
        cmd: List[str] = [rg_path]

        # Output mode flags
        if output_mode == "files_with_matches":
            cmd.append("--files-with-matches")
        elif output_mode == "count":
            cmd.append("--count")
        else:  # content
            cmd.append("--line-number")

        # Matching options
        if fixed_strings:
            cmd.append("--fixed-strings")
        if case_insensitive:
            cmd.append("--ignore-case")
        if multiline:
            cmd.extend(["--multiline", "--multiline-dotall"])

        # Context lines (content mode only)
        if output_mode == "content":
            if context_lines > 0:
                cmd.extend(["--context", str(context_lines)])
            else:
                if before_context > 0:
                    cmd.extend(["--before-context", str(before_context)])
                if after_context > 0:
                    cmd.extend(["--after-context", str(after_context)])

        # File filter
        if include:
            cmd.extend(["--glob", include])

        # Result limit: for content mode, limit matches per file
        if output_mode == "content":
            cmd.extend(["--max-count", str(max_results)])

        # Exclude common irrelevant directories (rg already ignores .git via .gitignore)
        for d in ["__pycache__", "node_modules", ".venv", "venv", ".idea", ".pytest_cache"]:
            cmd.extend(["--glob", f"!{d}/"])

        # Pattern and path
        cmd.append("--")
        cmd.append(pattern)
        cmd.append(str(base_path))

        # Execute asynchronously
        proc = None
        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=30)
        except asyncio.TimeoutError:
            if proc is not None:
                try:
                    proc.kill()
                except ProcessLookupError:
                    pass
            return "Error: grep timed out after 30 seconds"
        except FileNotFoundError:
            return await asyncio.get_event_loop().run_in_executor(
                None, self._grep_fallback, pattern, path, include, output_mode,
                max_results, fixed_strings, case_insensitive,
            )

        # rg exit codes: 0=matches found, 1=no matches, 2=error
        if proc.returncode == 2:
            err = stderr.decode("utf-8", errors="replace").strip()
            return f"Error: {err}"

        output = stdout.decode("utf-8", errors="replace").strip()
        if not output:
            return f"No matches found for '{pattern}'"

        # Truncate result lines for files_with_matches / count
        if output_mode in ("files_with_matches", "count"):
            lines = output.split("\n")
            if len(lines) > max_results:
                output = "\n".join(lines[:max_results])
                output += f"\n... ({len(lines) - max_results} more results truncated)"

        result = truncate_if_too_long(output)
        logger.debug(f"Grep(rg) for '{pattern}': result length {len(result)} chars")
        return result

    def _grep_fallback(
            self,
            pattern: str,
            path: str,
            include: Optional[str],
            output_mode: str,
            max_results: int,
            fixed_strings: bool,
            case_insensitive: bool = False,
    ) -> str:
        """Fallback grep using pure Python when ripgrep is not available."""
        try:
            base_path = self._resolve_path(path)

            # Compile regex
            regex_pattern = None
            if not fixed_strings:
                try:
                    flags = re.IGNORECASE if case_insensitive else 0
                    regex_pattern = re.compile(pattern, flags)
                except re.error as e:
                    return f"Error: Invalid regex pattern '{pattern}': {e}"

            # Determine files to search
            if include:
                files = list(base_path.glob(f"**/{include}"))
            else:
                files = list(base_path.glob("**/*"))

            # Exclude directories and ignored paths
            ignore_dirs = {'.git', '__pycache__', 'node_modules', '.venv', 'venv', '.idea', '.pytest_cache'}
            files = [f for f in files if f.is_file() and not set(f.parts).intersection(ignore_dirs)]

            results = []
            file_counts = {}

            match_pattern = pattern.lower() if (case_insensitive and fixed_strings) else pattern

            for fp in files:
                if len(results) >= max_results:
                    break

                try:
                    with open(fp, 'r', encoding='utf-8', errors='ignore') as f:
                        lines = f.readlines()

                    file_matches = []
                    for line_num, line in enumerate(lines, 1):
                        if fixed_strings:
                            check_line = line.lower() if case_insensitive else line
                            matched = match_pattern in check_line
                        else:
                            matched = regex_pattern.search(line)
                        if matched:
                            file_matches.append({
                                "line_num": line_num,
                                "content": line.strip()[:200],
                            })

                    if file_matches:
                        file_counts[str(fp)] = len(file_matches)
                        if output_mode == "content":
                            for match in file_matches[:max_results - len(results)]:
                                results.append(f"{fp}:{match['line_num']}: {match['content']}")
                        elif output_mode == "files_with_matches":
                            results.append(str(fp))
                except Exception:
                    continue

            # Format output
            if output_mode == "count":
                output_lines = [f"{p}:{c}" for p, c in file_counts.items()]
                result = "\n".join(output_lines) if output_lines else f"No matches found for '{pattern}'"
            elif output_mode == "files_with_matches":
                result = "\n".join(sorted(set(results))) if results else f"No matches found for '{pattern}'"
            else:  # content
                result = "\n".join(results) if results else f"No matches found for '{pattern}'"

            result = truncate_if_too_long(result)
            logger.debug(f"Grep(fallback) for '{pattern}': found {len(file_counts)} files, result length: {len(result)} chars")
            return result

        except Exception as e:
            logger.error(f"Error in grep fallback: {e}")
            return f"Error in grep: {e}"


class BuiltinExecuteTool(Tool):
    """
    Built-in command execution tool using async subprocess.
    Exposed as execute function for consistent naming in Agent.
    """

    def __init__(self, work_dir: Optional[str] = None, timeout: int = 120, max_timeout: int = 600,
                 max_output_length: int = 20000, sandbox_config=None):
        """
        Initialize BuiltinExecuteTool.

        Args:
            work_dir: Work directory for command execution
            timeout: Default command execution timeout in seconds
            max_timeout: Maximum allowed timeout in seconds
            max_output_length: Maximum length of output to return
            sandbox_config: SandboxConfig instance for command restriction enforcement
        """
        super().__init__(name="builtin_execute_tool")
        self._work_dir: Optional[Path] = Path(work_dir) if work_dir else None
        self._timeout = timeout
        self._max_timeout = max_timeout
        self._max_output_length = max_output_length
        self._sandbox_config = sandbox_config
        # Override timeout from sandbox config if set
        if sandbox_config and sandbox_config.enabled and sandbox_config.max_execution_time:
            self._timeout = sandbox_config.max_execution_time
        # Import ShellTool for its syntax-fix helpers
        from agentica.tools.shell_tool import ShellTool
        self._shell = ShellTool(work_dir=work_dir, timeout=timeout)
        self.register(self.execute)
        # Large bash outputs are persisted to disk (context gets preview only).
        # read_file keeps max_result_size_chars=None (never persist — avoids
        # reading its own persisted output file in a loop).
        self.functions["execute"].max_result_size_chars = 50_000

    async def execute(self, command: str, timeout: Optional[int] = None) -> str:
        """Executes a shell command, capturing both stdout and stderr.

        IMPORTANT — Use dedicated tools instead of bash equivalents:
        - File search:    Use glob tool    (NOT find, ls -R, or locate)
        - Content search: Use grep tool    (NOT grep, rg, or ag)
        - Read files:     Use read_file    (NOT cat, head, tail, less, or more)
        - Edit files:     Use edit_file    (NOT sed, awk, or perl -i)
        - Write files:    Use write_file   (NOT echo >, tee, or cat <<EOF)
        - List files:     Use ls tool      (NOT ls command in bash)

        The execute tool is for commands that have NO dedicated tool equivalent:
        git, python, pytest, pip, npm, make, docker, curl (POST), etc.

        Before executing:
        1. Verify target directory exists (use ls tool first if unsure)
        2. Always quote file paths with spaces: cd "/path with spaces/"
        3. Use absolute paths; avoid cd when possible

        Usage notes:
        - Commands timeout after 120 seconds by default
        - You may specify a custom timeout up to 600 seconds (10 min) for long-running commands
        - Use '&&' to chain dependent commands; use ';' for independent commands
        - DO NOT use newlines in commands (newlines ok inside quoted strings)
        - For Python code, the tool auto-converts `python3 -c "..."` to heredoc format

        Good examples:
            - execute(command="python3 /path/to/script.py")
            - execute(command="pytest /path/to/tests/ -v --tb=short")
            - execute(command="git status")
            - execute(command="npm install && npm test", timeout=300)

        Bad examples (use dedicated tools instead):
            - execute(command="find . -name '*.py'")   → use glob(pattern="**/*.py")
            - execute(command="grep -r 'TODO' .")      → use grep(pattern="TODO")
            - execute(command="cat file.txt")           → use read_file(file_path="file.txt")
            - execute(command="sed -i 's/old/new/' f")  → use edit_file(...)

        Args:
            command: shell command to execute
            timeout: optional timeout in seconds (default 120, max 600)

        Returns:
            str: The output of the command (stdout + stderr) with exit code
        """
        # Apply timeout: use provided value, clamped to max
        effective_timeout = self._timeout
        if timeout is not None:
            effective_timeout = min(max(1, timeout), self._max_timeout)

        # Use ShellTool's syntax fixers (python -c → heredoc conversion, null/true/false fix)
        command = self._shell._convert_python_c_to_heredoc(command)

        # Sandbox: check blocked commands (best-effort, not a true security sandbox)
        if self._sandbox_config and self._sandbox_config.enabled:
            cmd_lower = command.lower().strip()
            for blocked in self._sandbox_config.blocked_commands:
                # Use regex word boundary to reduce false positives (e.g. "rm" in "format")
                # while still catching the actual dangerous patterns
                pattern = re.escape(blocked.lower())
                if re.search(r'(?:^|[\s;|&])' + pattern, cmd_lower):
                    logger.warning(f"Sandbox: blocked command: {command[:100]}")
                    return "Error: Sandbox blocked this command for security reasons."

            # Sandbox: check allowed_commands whitelist (prefix match on first token)
            # Only enforced when allowed_commands is explicitly set (non-None).
            allowed = self._sandbox_config.allowed_commands
            if allowed is not None:
                # Extract the first token (bare executable name, strip path prefix)
                first_token = cmd_lower.split()[0] if cmd_lower.split() else ""
                # Normalize: strip leading path (e.g. "/usr/bin/python3" → "python3")
                first_token_base = os.path.basename(first_token)
                if not any(
                    first_token_base == a.lower() or first_token_base.startswith(a.lower())
                    for a in allowed
                ):
                    logger.warning(
                        f"Sandbox: command '{first_token_base}' not in allowed_commands "
                        f"{allowed}: {command[:100]}"
                    )
                    return (
                        f"Error: Sandbox blocked this command — '{first_token_base}' is not "
                        f"in the allowed_commands list: {allowed}"
                    )

        logger.debug(f"Executing command: {command}")
        cwd = str(self._work_dir) if self._work_dir else None
        proc = None

        try:
            proc = await asyncio.create_subprocess_shell(
                command,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=cwd,
            )
            stdout, stderr = await asyncio.wait_for(
                proc.communicate(), timeout=effective_timeout,
            )
        except asyncio.TimeoutError:
            # Graceful termination: SIGTERM first, then SIGKILL
            if proc is not None:
                try:
                    proc.terminate()
                    try:
                        await asyncio.wait_for(proc.wait(), timeout=5)
                    except asyncio.TimeoutError:
                        proc.kill()
                except ProcessLookupError:
                    pass
            logger.warning(f"Command timed out after {effective_timeout}s: {command}")
            return f"Error: Command timed out after {effective_timeout} seconds (timeout {effective_timeout}s)"
        except Exception as e:
            logger.warning(f"Failed to run shell command: {e}")
            return f"Error: {e}"

        # Combine stdout and stderr
        output_parts = []
        if stdout:
            output_parts.append(stdout.decode("utf-8", errors="replace"))
        if stderr:
            output_parts.append(f"[stderr]\n{stderr.decode('utf-8', errors='replace')}")

        output = "\n".join(output_parts).strip()

        # Truncate if too long
        if len(output) > self._max_output_length:
            output = output[:self._max_output_length] + "\n... (output truncated)"

        # Add exit code info
        if proc.returncode != 0:
            output = f"{output}\n\n[Exit code: {proc.returncode}]"

        logger.debug(f"Command exit code: {proc.returncode}")
        return output if output else f"Command executed successfully (exit code: {proc.returncode})"


class BuiltinWebSearchTool(Tool):
    """
    Built-in web search tool using Baidu search.
    Exposed as web_search function.
    """

    def __init__(self):
        """
        Initialize BuiltinWebSearchTool.
        """
        super().__init__(name="builtin_web_search_tool")
        from agentica.tools.baidu_search_tool import BaiduSearchTool
        self._search = BaiduSearchTool()
        self.register(self.web_search, concurrency_safe=True)

    async def web_search(self, queries: Union[str, List[str]], max_results: int = 5) -> str:
        """Search the web using Baidu for multiple queries and return results

        Args:
            queries (Union[str, List[str]]): Search keyword(s), can be a single string or a list of strings
            max_results (int, optional): Number of results to return for each query, default 5

        Returns:
            str: A JSON formatted string containing the search results.

        IMPORTANT: After using this tool:
        1. Read through the 'content' field of each result
        2. Extract relevant information that answers the user's question
        3. Synthesize this into a clear, natural language response
        4. Cite sources by mentioning the page titles or URLs
        5. NEVER show the raw JSON to the user - always provide a formatted response
        """

        try:
            result = await self._search.baidu_search(queries, max_results=max_results)
            logger.debug(f"Web search for '{queries}', result length: {len(result)} characters.")
            return result
        except Exception as e:
            logger.error(f"Web search error: {e}")
            return json.dumps({"error": f"Web search error: {e}", "queries": queries}, ensure_ascii=False)


class BuiltinFetchUrlTool(Tool):
    """
    Built-in URL fetching tool that wraps UrlCrawlerTool.
    Exposed as fetch_url function for consistent naming in Agent.
    """

    def __init__(self, max_content_length: int = 16000):
        """
        Initialize BuiltinFetchUrlTool.

        Args:
            max_content_length: Maximum length of returned content
        """
        super().__init__(name="builtin_fetch_url_tool")
        self.max_content_length = max_content_length
        # Import and initialize UrlCrawlerTool (uses default cache dir ~/.cache/agentica/web_cache/)
        from agentica.tools.url_crawler_tool import UrlCrawlerTool
        self._crawler = UrlCrawlerTool(max_content_length=max_content_length)
        self.register(self.fetch_url, concurrency_safe=True)

    async def fetch_url(self, url: str) -> str:
        """Fetch URL content and convert to clean text format.

        Args:
            url: URL to fetch, url starts with http:// or https://

        Returns:
            str, JSON formatted fetch result containing url, content, and save_path

        IMPORTANT: After using this tool:
        1. Read through the return content
        2. Extract relevant information that answers the user's question
        3. Synthesize this into a clear, natural language response
        4. NEVER show the raw JSON to the user unless specifically requested
        """
        result = await self._crawler.url_crawl(url)
        logger.debug(f"Fetched URL: {url}, result length: {len(result)} characters.")
        return result


class BuiltinTodoTool(Tool):
    """
    Built-in task management tool providing write_todos and read_todos functions.
    Used for tracking progress of complex tasks.
    """
    # System prompt for todo tool usage guidance
    WRITE_TODOS_SYSTEM_PROMPT = dedent("""## `write_todos`

    You have access to the `write_todos` tool to help you manage and plan complex objectives.
    Use this tool for complex objectives to ensure that you are tracking each necessary step and giving the user visibility into your progress.
    This tool is very helpful for planning complex objectives, and for breaking down these larger complex objectives into smaller steps.

    It is critical that you mark todos as completed as soon as you are done with a step. Do not batch up multiple steps before marking them as completed.
    For simple objectives that only require a few steps, it is better to just complete the objective directly and NOT use this tool.
    Writing todos takes time and tokens, use it when it is helpful for managing complex many-step problems! But not for simple few-step requests.

    ## Important To-Do List Usage Notes to Remember
    - The `write_todos` tool should never be called multiple times in parallel.
    - Don't be afraid to revise the To-Do list as you go. New information may reveal new tasks that need to be done, or old tasks that are irrelevant.""")

    def __init__(self):
        """Initialize BuiltinTodoTool."""
        super().__init__(name="builtin_todo_tool")
        self._todos: List[Dict[str, Any]] = []
        self.register(self.write_todos)
        self.register(self.read_todos)

    def get_system_prompt(self) -> Optional[str]:
        """Get the system prompt for todo tool usage guidance."""
        return self.WRITE_TODOS_SYSTEM_PROMPT

    def write_todos(self, todos: Optional[List[Dict[str, str]]] = None) -> str:
        """Create and manage a structured task list.

        Use this tool to create and manage a structured task list for your current work session. This helps you track progress, organize complex tasks, and demonstrate thoroughness to the user.

        Only use this tool if you think it will be helpful in staying organized. If the user's request is trivial and takes less than 3 steps, it is better to NOT use this tool and just do the task directly.

        ## When to Use This Tool
        Use this tool in these scenarios:
        1. Complex multi-step tasks - When a task requires 3 or more distinct steps or actions
        2. Non-trivial and complex tasks - Tasks that require careful planning or multiple operations
        3. User explicitly requests todo list - When the user directly asks you to use the todo list
        4. User provides multiple tasks - When users provide a list of things to be done (numbered or comma-separated)
        5. The plan may need future revisions or updates based on results from the first few steps

        ## How to Use This Tool
        1. When you start working on a task - Mark it as in_progress BEFORE beginning work.
        2. After completing a task - Mark it as completed and add any new follow-up tasks discovered during implementation.
        3. You can also update future tasks, such as deleting them if they are no longer necessary, or adding new tasks that are necessary. Don't change previously completed tasks.
        4. You can make several updates to the todo list at once. For example, when you complete a task, you can mark the next task you need to start as in_progress.

        ## When NOT to Use This Tool
        It is important to skip using this tool when:
        1. There is only a single, straightforward task
        2. The task is trivial and tracking it provides no benefit
        3. The task can be completed in less than 3 trivial steps
        4. The task is purely conversational or informational

        ## Task States and Management

        1. **Task States**: Use these states to track progress:
        - pending: Task not yet started
        - in_progress: Currently working on (you can have multiple tasks in_progress at a time if they are not related to each other and can be run in parallel)
        - completed: Task finished successfully

        2. **Task Management**:
        - Update task status in real-time as you work
        - Mark tasks complete IMMEDIATELY after finishing (don't batch completions)
        - Complete current tasks before starting new ones
        - Remove tasks that are no longer relevant from the list entirely
        - IMPORTANT: When you write this todo list, you should mark your first task (or tasks) as in_progress immediately!.
        - IMPORTANT: Unless all tasks are completed, you should always have at least one task in_progress to show the user that you are working on something.

        3. **Task Completion Requirements**:
        - ONLY mark a task as completed when you have FULLY accomplished it
        - If you encounter errors, blockers, or cannot finish, keep the task as in_progress
        - When blocked, create a new task describing what needs to be resolved
        - Never mark a task as completed if:
            - There are unresolved issues or errors
            - Work is partial or incomplete
            - You encountered blockers that prevent completion
            - You couldn't find necessary resources or dependencies
            - Quality standards haven't been met

        4. **Task Breakdown**:
        - Create specific, actionable items
        - Break complex tasks into smaller, manageable steps
        - Use clear, descriptive task names

        Being proactive with task management demonstrates attentiveness and ensures you complete all requirements successfully
        Remember: If you only need to make a few tool calls to complete a task, and it is clear what you need to do, it is better to just do the task directly and NOT call this tool at all.

        Each task item should contain:
        - content: Task description
        - status: Task status ("pending", "in_progress", "completed")

        Args:
            todos: Task list, each task is a dict with content and status. Required.
            Example: [{"content": "Write a report", "status": "pending"}, {"content": "Review report", "status": "pending"}]

        Returns:
            Updated task list
        """
        try:
            # Validate todos parameter
            if todos is None:
                return "Error: 'todos' parameter is required. Please provide a list of tasks with 'content' and 'status' fields."
            if len(todos) == 0:
                return "Error: 'todos' list cannot be empty. Please provide at least one task."
            valid_statuses = {"pending", "in_progress", "completed"}
            validated_todos = []

            for i, todo in enumerate(todos):
                if not isinstance(todo, dict):
                    return f"Error: Todo item {i} must be a dictionary"

                content = todo.get("content", "")
                status = todo.get("status", "pending")

                if not content:
                    return f"Error: Todo item {i} must have 'content' field"
                if status not in valid_statuses:
                    return f"Error: Invalid status '{status}' for todo item {i}. Must be one of: {valid_statuses}"

                validated_todos.append({
                    "id": str(i + 1),
                    "content": content,
                    "status": status,
                })

            self._todos = validated_todos
            logger.debug(f"Updated todo list: {len(self._todos)} items, todos: {self._todos}")

            return json.dumps({
                "message": f"Updated todo list with {len(self._todos)} items",
                "todos": self._todos,
            }, ensure_ascii=False, indent=2)
        except Exception as e:
            logger.error(f"Error updating todos: {e}")
            return f"Error updating todos: {e}"

    def read_todos(self) -> str:
        """Read current task list status.

        Use this tool to check the current state of your task list. This is useful for:
        1. Reviewing progress before continuing work
        2. Checking which tasks are completed, in progress, or pending
        3. Deciding which task to work on next
        4. Verifying task completion before reporting to user

        This tool works together with write_todos:
        - Use write_todos to create/update tasks
        - Use read_todos to check current status

        Returns:
            JSON formatted current task list with summary statistics
        """
        if not self._todos:
            return json.dumps({
                "message": "No todos found. Use write_todos to create a task list.",
                "todos": [],
                "summary": {"pending": 0, "in_progress": 0, "completed": 0, "total": 0}
            }, ensure_ascii=False, indent=2)

        # Count status statistics
        status_counts = {"pending": 0, "in_progress": 0, "completed": 0}
        for todo in self._todos:
            status = todo.get("status", "pending")
            if status in status_counts:
                status_counts[status] += 1

        total = len(self._todos)
        progress_pct = round(status_counts["completed"] / total * 100) if total > 0 else 0

        logger.debug(f"Todo list: {status_counts}, progress: {progress_pct}%")
        return json.dumps({
            "summary": {
                **status_counts,
                "total": total,
                "progress": f"{progress_pct}%"
            },
            "todos": self._todos
        }, ensure_ascii=False, indent=2)


class BuiltinTaskTool(Tool):
    """
    Built-in task tool for launching subagents to handle complex, multi-step tasks.

    This tool allows the main agent to delegate complex tasks to ephemeral subagents
    that can work independently with isolated context windows.

    Supports multiple subagent types:
    - explore: Read-only codebase exploration (fastest, lowest context)
    - research: Web search and document analysis
    - code: Code generation and execution (full capabilities)
    - Custom user-defined subagent types (via register_custom_subagent)

    Key Features:
    - Parallel execution: Launch multiple subagents simultaneously for independent tasks
    - Isolated context: Each subagent has its own context window
    - Type-specific tools: Each subagent type has optimized tool sets
    """

    # Base system prompt template for task tool usage guidance
    TASK_SYSTEM_PROMPT_TEMPLATE = dedent("""## task Tool (Subagent Spawner)

    You have access to a `task` function to launch short-lived subagents that handle isolated tasks.

    ### How to Call

    Use your standard function calling mechanism to invoke `task(description="...", subagent_type="...")`.

    ### Available Subagent Types

    {subagent_table}

    ### Parallel Execution (IMPORTANT)

    When you have **multiple independent tasks**, launch them **in parallel** for maximum efficiency:

    ```python
    # Launch multiple subagents in a single response - they run simultaneously
    task(description="Task A description", subagent_type="explore")
    task(description="Task B description", subagent_type="research")
    task(description="Task C description", subagent_type="code")
    ```

    **Benefits:**
    - Tasks execute simultaneously, not sequentially
    - Total time = max(task_times), not sum(task_times)
    - Ideal for: exploring multiple directories, researching multiple topics, running multiple code experiments

    ### Usage Guidelines

    1. **Parallel for Independent Tasks**: Use parallel execution when tasks don't depend on each other
    2. **Clear Instructions**: Provide detailed task descriptions and expected output format
    3. **Right Tool for Job**: Choose the most appropriate subagent type:
       - `explore`: Fast codebase exploration, read-only
       - `research`: Web search and document analysis
       - `code`: Full code generation and execution capabilities
    4. **Isolated Context**: Each subagent has its own context window - include all necessary info

    ### When NOT to Use

    - Task is trivial (1-3 tool calls)
    - You need to see intermediate steps
    - Task depends on main conversation context
    - Simple questions that don't need delegation""")

    def __init__(
            self,
            model: Optional["Model"] = None,
            tools: Optional[List[Any]] = None,
            work_dir: Optional[str] = None,
            tool_call_limit: int = 100,
            custom_subagent_configs: Optional[Dict[str, Any]] = None,
    ):
        """
        Initialize BuiltinTaskTool.

        Args:
            model: Model to use for subagents. If None, will use the parent agent's model.
            tools: Default tools for subagents. If None, will use basic tools based on type.
            work_dir: Work directory for file operations.
            tool_call_limit: Maximum number of tool calls allowed for subagent execution.
            custom_subagent_configs: Custom subagent configurations to add/override defaults.
        """
        super().__init__(name="builtin_task_tool")
        self._model = model
        self._tools = tools
        self._work_dir = work_dir
        self._tool_call_limit = tool_call_limit
        self._parent_agent: Optional["Agent"] = None
        self._custom_configs = custom_subagent_configs or {}
        self.register(self.task)

    def _build_subagent_table(self) -> str:
        """Build a markdown table of available subagent types."""
        from agentica.subagent import get_available_subagent_types
        
        available_types = get_available_subagent_types()
        
        lines = ["| Type | Name | Description |", "|------|------|-------------|"]
        for st in available_types:
            # Truncate description for table
            desc = st['description'].split('\n')[0][:60]
            if len(st['description'].split('\n')[0]) > 60:
                desc += "..."
            type_name = st['type']
            name = st['name']
            lines.append(f"| `{type_name}` | {name} | {desc} |")
        
        return "\n".join(lines)

    def get_system_prompt(self) -> Optional[str]:
        """
        Get the dynamically generated system prompt for task tool.
        
        This prompt is regenerated each time to include any custom subagent types
        that may have been registered since initialization.
        """
        subagent_table = self._build_subagent_table()
        return self.TASK_SYSTEM_PROMPT_TEMPLATE.format(subagent_table=subagent_table)

    def set_parent_agent(self, agent: "Agent") -> None:
        """Set the parent agent reference for accessing model and tools."""
        self._parent_agent = agent
        # Also set work_dir from parent agent if available
        if self._work_dir is None and hasattr(agent, 'work_dir') and agent.work_dir:
            self._work_dir = agent.work_dir

    def _get_tools_for_subagent(self, subagent_type: str) -> List[Any]:
        """Get appropriate tools for a subagent type based on config.allowed_tools.

        Uses SubagentConfig.allowed_tools as the single source of truth.
        Each allowed tool name is mapped to the Tool class that provides it.
        """
        from agentica.subagent import get_subagent_config

        config = get_subagent_config(subagent_type)

        # Inherit sandbox_config from parent agent
        sandbox_cfg = None
        if self._parent_agent is not None:
            sandbox_cfg = getattr(self._parent_agent, 'sandbox_config', None)

        # Default tools if no config found
        if config is None:
            return self._tools or [
                BuiltinFileTool(work_dir=self._work_dir, sandbox_config=sandbox_cfg),
                BuiltinWebSearchTool(),
                BuiltinFetchUrlTool(),
            ]

        # If allowed_tools is None, give all basic tools (except task)
        if config.allowed_tools is None:
            tools: List[Any] = [
                BuiltinFileTool(work_dir=self._work_dir, sandbox_config=sandbox_cfg),
                BuiltinExecuteTool(work_dir=self._work_dir, sandbox_config=sandbox_cfg),
                BuiltinWebSearchTool(),
                BuiltinFetchUrlTool(),
                BuiltinTodoTool(),
            ]
            return tools

        # Map function names to the Tool class that provides them
        # Each Tool class registers multiple functions; we track which classes are needed
        FILE_TOOL_FUNCTIONS = {"ls", "read_file", "write_file", "edit_file", "multi_edit_file", "glob", "grep"}
        EXECUTE_FUNCTIONS = {"execute"}
        WEB_SEARCH_FUNCTIONS = {"web_search"}
        FETCH_URL_FUNCTIONS = {"fetch_url"}
        TODO_FUNCTIONS = {"write_todos", "read_todos"}

        allowed = set(config.allowed_tools)
        tools = []

        if allowed & FILE_TOOL_FUNCTIONS:
            tools.append(BuiltinFileTool(work_dir=self._work_dir, sandbox_config=sandbox_cfg))
        if allowed & EXECUTE_FUNCTIONS:
            tools.append(BuiltinExecuteTool(work_dir=self._work_dir, sandbox_config=sandbox_cfg))
        if allowed & WEB_SEARCH_FUNCTIONS:
            tools.append(BuiltinWebSearchTool())
        if allowed & FETCH_URL_FUNCTIONS:
            tools.append(BuiltinFetchUrlTool())
        if allowed & TODO_FUNCTIONS:
            tools.append(BuiltinTodoTool())

        return tools

    def _get_parent_context_summary(self, max_chars: int = 2000) -> str:
        """Extract a brief context summary from the parent agent's recent conversation."""
        if self._parent_agent is None:
            return ""
        memory = getattr(self._parent_agent, 'working_memory', None)
        if memory is None:
            return ""
        messages = getattr(memory, 'messages', None)
        if not messages:
            return ""
        # Take last few messages, extract content
        summary_parts = []
        total = 0
        for msg in reversed(messages[-6:]):
            content = getattr(msg, 'content', None)
            if content and isinstance(content, str):
                snippet = content[:500]
                summary_parts.append(f"[{getattr(msg, 'role', '?')}] {snippet}")
                total += len(snippet)
                if total > max_chars:
                    break
        summary_parts.reverse()
        return "\n".join(summary_parts)

    async def _run_subagent_stream(
        self, subagent: Any, task_description: str, tool_calls_log: List[Dict[str, Any]]
    ) -> str:
        """Run a subagent with streaming, collecting tool usage info."""
        final_content = ""
        from agentica.run_config import RunConfig
        async for chunk in subagent.run_stream(task_description, config=RunConfig(stream_intermediate_steps=True)):
            if chunk is None:
                continue
            # Collect tool call info from intermediate events
            if chunk.event in ("ToolCallStarted", "ToolCallCompleted",
                               "MultiRoundToolCall", "MultiRoundToolResult"):
                if chunk.tools:
                    for tool_info in chunk.tools:
                        tool_name = tool_info.get("tool_name") or tool_info.get("name", "")
                        if not tool_name:
                            continue
                        tool_args = tool_info.get("tool_args") or tool_info.get("arguments", {})
                        content = tool_info.get("content")
                        brief = self._format_tool_brief(tool_name, tool_args, content)
                        entry = {"name": tool_name, "info": brief}
                        if chunk.event in ("ToolCallCompleted", "MultiRoundToolResult"):
                            for i in range(len(tool_calls_log) - 1, -1, -1):
                                if tool_calls_log[i]["name"] == tool_name and "result" not in tool_calls_log[i]:
                                    tool_calls_log[i]["info"] = brief
                                    tool_calls_log[i]["result"] = True
                                    break
                        else:
                            tool_calls_log.append(entry)
            # Accumulate final content
            if chunk.event in ("RunResponse",) and chunk.content:
                final_content += str(chunk.content)
        return final_content

    async def task(self, description: str, subagent_type: str = "code") -> str:
        """Launch a subagent to handle a complex task.

        Args:
            description: Detailed description of the task to perform.
                Include what you want the subagent to do and what information to return.
            subagent_type: Type of subagent to use. Options:
                - "explore": Read-only codebase exploration (fast, low context)
                - "research": Web search and document analysis
                - "code": Full code generation and execution (default)

        Returns:
            The result from the subagent after completing the task.
        """
        from agentica.subagent import (
            SubagentRegistry, SubagentRun, SubagentType,
            get_subagent_config,
        )

        # Get registry
        registry = SubagentRegistry()

        # Compute current nesting depth from parent agent's context.
        # Each spawned subagent inherits depth + 1 via its context dict.
        _MAX_TASK_DEPTH = 5
        current_depth = 0
        if self._parent_agent is not None and self._parent_agent.context:
            current_depth = int(self._parent_agent.context.get("_task_depth", 0))

        if current_depth >= _MAX_TASK_DEPTH:
            logger.warning(
                f"task() blocked: max recursion depth {_MAX_TASK_DEPTH} reached "
                f"(parent agent: {getattr(self._parent_agent, 'name', 'unknown')})"
            )
            return json.dumps({
                "success": False,
                "error": (
                    f"Max subagent nesting depth ({_MAX_TASK_DEPTH}) reached. "
                    "Complete your task directly without further delegation."
                ),
            }, ensure_ascii=False)

        # Check if we're already in a subagent (prevent nesting)
        if self._parent_agent is not None:
            parent_agent_id = self._parent_agent.agent_id
            if registry.is_subagent(parent_agent_id):
                return json.dumps({
                    "success": False,
                    "error": "Nested subagent spawning is not allowed. Complete your task without delegating.",
                }, ensure_ascii=False)

        try:
            # Get subagent configuration
            config = get_subagent_config(subagent_type)
            if config is None:
                # Default to code if unknown type
                config = get_subagent_config("code")
                logger.warning(f"Unknown subagent type '{subagent_type}', using 'code'")
            
            # Get model from parent agent or use configured model.
            # IMPORTANT: Create an isolated copy to avoid sharing mutable state (tools,
            # functions, function_call_stack, tool_choice, client) between parent and
            # subagent. We use shallow model_copy and manually reset runtime fields;
            # deep=True would fail because the HTTP client contains unpicklable locks.
            source_model = self._model
            if source_model is None and self._parent_agent is not None:
                source_model = self._parent_agent.model

            if source_model is None:
                return json.dumps({
                    "success": False,
                    "error": "No model available for subagent. Please configure a model.",
                }, ensure_ascii=False)

            model = source_model.model_copy()
            # Reset runtime state so Agent.__init__ registers subagent's own tools cleanly
            model.tools = None
            model.functions = None
            model.function_call_stack = None
            model.tool_choice = None
            model.metrics = {}
            from agentica.model.usage import Usage
            model.usage = Usage()
            # Force a fresh HTTP client (the old one belongs to the parent)
            model.client = None
            model.http_client = None

            # Generate unique run_id for subagent
            parent_agent_id = self._parent_agent.agent_id if self._parent_agent else 'main'
            run_id = str(uuid.uuid4())

            # Create subagent run entry
            run = SubagentRun(
                run_id=run_id,
                subagent_type=config.type,
                parent_agent_id=parent_agent_id,
                task_label=description[:50] + "..." if len(description) > 50 else description,
                task_description=description,
                started_at=datetime.now(),
                status="running",
            )
            registry.register(run)

            # Get tools for this subagent type
            subagent_tools = self._get_tools_for_subagent(subagent_type)

            # Import Agent here to avoid circular imports
            from agentica.agent import Agent

            # Create subagent with isolated session
            from agentica.agent.config import ToolConfig, PromptConfig

            # Apply permission isolation from config
            subagent_kwargs: Dict[str, Any] = dict(
                model=model,
                name=f"{config.name}",
                description=config.description,
                instructions=config.system_prompt,
                tools=subagent_tools,
                prompt_config=PromptConfig(markdown=True),
                tool_config=ToolConfig(tool_call_limit=config.tool_call_limit),
                # Propagate task depth so nested task() calls can detect recursion limit
                context={"_task_depth": current_depth + 1},
            )

            # Conditionally inherit workspace from parent
            if config.inherit_workspace and self._parent_agent is not None:
                parent_workspace = getattr(self._parent_agent, 'workspace', None)
                if parent_workspace is not None:
                    subagent_kwargs['workspace'] = parent_workspace

            # Conditionally inherit knowledge base from parent
            if config.inherit_knowledge and self._parent_agent is not None:
                parent_knowledge = getattr(self._parent_agent, 'knowledge', None)
                if parent_knowledge is not None:
                    subagent_kwargs['knowledge'] = parent_knowledge
                    subagent_kwargs['search_knowledge'] = True

            subagent = Agent(**subagent_kwargs)

            # Optionally prepend parent context summary to the task description
            task_description = description
            if config.inherit_context and self._parent_agent is not None:
                context_summary = self._get_parent_context_summary()
                if context_summary:
                    task_description = f"Parent agent context:\n{context_summary}\n\nTask:\n{description}"

            logger.debug(f"Launching {config.name} [{config.type.value}] for task: {description[:100]}...")
            
            # Run subagent with async streaming to collect tool usage info
            subagent_timeout = config.timeout if config.timeout > 0 else None
            start_time = time.time()
            tool_calls_log = []
            final_content = ""

            try:
                coro = self._run_subagent_stream(
                    subagent, task_description, tool_calls_log
                )
                if subagent_timeout:
                    final_content = await asyncio.wait_for(coro, timeout=subagent_timeout)
                else:
                    final_content = await coro
            except asyncio.TimeoutError:
                logger.warning(f"Subagent timed out after {subagent_timeout}s")
                final_content = f"[Subagent timed out after {subagent_timeout} seconds. Partial results may be available above.]"

            elapsed = time.time() - start_time
            result = final_content if final_content else "Subagent completed but returned no content."
            
            # Build tool calls summary for display
            tool_summary = []
            for tc in tool_calls_log:
                tool_summary.append({"name": tc["name"], "info": tc.get("info", "")})
            
            # Update registry with success
            registry.update_status(
                run_id=run_id,
                status="completed",
                result=result,
            )

            # Merge subagent usage into parent
            if (self._parent_agent is not None
                    and hasattr(subagent, 'model') and subagent.model is not None
                    and hasattr(self._parent_agent, 'model') and self._parent_agent.model is not None):
                self._parent_agent.model.usage.merge(subagent.model.usage)
            
            logger.debug(f"{config.name} [{config.type.value}] completed task.")
            
            return json.dumps({
                "success": True,
                "subagent_type": config.type.value,
                "subagent_name": config.name,
                "result": result,
                "tool_calls_summary": tool_summary,
                "execution_time": round(elapsed, 3),
                "tool_count": len(tool_summary),
            }, ensure_ascii=False, indent=2)

        except Exception as e:
            logger.error(f"Subagent task error: {e}")
            
            # Update registry with error if we have a run_id
            if 'run_id' in locals():
                registry.update_status(
                    run_id=run_id,
                    status="error",
                    error=str(e),
                )
            
            return json.dumps({
                "success": False,
                "error": f"Subagent task error: {e}",
                "description": description[:300],
            }, ensure_ascii=False)

    @staticmethod
    def _format_tool_brief(tool_name: str, tool_args, content=None) -> str:
        """Format a brief description for a subagent tool call."""
        if isinstance(tool_args, str):
            try:
                tool_args = json.loads(tool_args)
            except (json.JSONDecodeError, TypeError):
                tool_args = {}
        if not isinstance(tool_args, dict):
            tool_args = {}
        
        if tool_name == "read_file":
            fp = tool_args.get("file_path", "")
            if fp:
                fname = fp.rsplit("/", 1)[-1] if "/" in fp else fp
                lines = ""
                if tool_args.get("offset") or tool_args.get("limit"):
                    start = (tool_args.get("offset", 0) or 0) + 1
                    end = start + (tool_args.get("limit", 500) or 500) - 1
                    lines = f" (L{start}-{end})"
                if content:
                    line_count = str(content).count("\n") + 1
                    return f"Read {line_count} line(s) from {fname}"
                return f"{fname}{lines}"
        elif tool_name in ("grep", "search_content"):
            pattern = tool_args.get("pattern", "")
            if content and isinstance(content, str):
                match_count = content.count("\n") + 1 if content.strip() else 0
                return f'Found {match_count} match(es) for "{pattern[:40]}"'
            return f'"{pattern[:40]}"'
        elif tool_name in ("glob", "search_file"):
            pattern = tool_args.get("pattern", "")
            return f'pattern: {pattern}'
        elif tool_name == "ls":
            directory = tool_args.get("directory", ".")
            return directory.rsplit("/", 1)[-1] if "/" in directory else directory
        elif tool_name == "execute":
            cmd = tool_args.get("command", "")
            return cmd[:80] + ("..." if len(cmd) > 80 else "")
        elif tool_name == "write_file":
            fp = tool_args.get("file_path", "")
            return fp.rsplit("/", 1)[-1] if "/" in fp else fp
        elif tool_name == "edit_file":
            fp = tool_args.get("file_path", "")
            return fp.rsplit("/", 1)[-1] if "/" in fp else fp
        elif tool_name == "multi_edit_file":
            fp = tool_args.get("file_path", "")
            edits = tool_args.get("edits", [])
            fname = fp.rsplit("/", 1)[-1] if "/" in fp else fp
            return f"{fname} ({len(edits)} edits)"
        elif tool_name == "web_search":
            queries = tool_args.get("queries", "")
            if isinstance(queries, list):
                return ", ".join(str(q)[:30] for q in queries[:2])
            return str(queries)[:60]
        elif tool_name == "fetch_url":
            url = tool_args.get("url", "")
            return url[:60] + ("..." if len(url) > 60 else "")
        
        # Default: show first arg value briefly
        for k, v in tool_args.items():
            return f"{k}={str(v)[:50]}"
        return ""


class BuiltinMemoryTool(Tool):
    """
    Built-in memory tool for saving important information to workspace.
    
    This tool allows the agent to persist important user information, preferences,
    and conversation highlights to the workspace memory system.
    
    Memory types:
    - Daily memory: Temporary notes for the current day (auto-cleared after 7 days)
    - Long-term memory: Persistent information (user preferences, important facts)
    """

    MEMORY_SYSTEM_PROMPT = dedent("""## Memory Tools

    You have access to memory tools to persist and retrieve important information across conversations.

    ### Available Tools

    1. **save_memory(content, long_term)** — Save information to memory
       - `long_term=False` (default): Daily memory, cleared after 7 days
       - `long_term=True`: Permanent memory that persists indefinitely

    2. **read_memory(days)** — Read recent memories
       - Returns long-term memory + daily memories from the last N days (default: 7)
       - Use to recall previously saved context before responding

    3. **search_memory(query, limit)** — Search all memories by keyword
       - Searches across all memory files (long-term + daily) using keyword matching
       - Returns matching results ranked by relevance score
       - Note: `search_memory` searches saved memory notes; use `search_conversations` (if available) to search full conversation archives

    ### When to Use

    - **save_memory**: User says "remember", "save", "note this", or shares important preferences/facts
    - **read_memory**: At the start of a conversation or when you need to recall saved context
    - **search_memory**: When looking for specific previously saved information

    ### Guidelines

    1. **Be Selective**: Only save truly important or explicitly requested information
    2. **Be Concise**: Write clear, brief memory entries (1-2 sentences)
    3. **Privacy Aware**: Don't save sensitive information unless explicitly asked

    ### Examples

    - User says "I prefer Python over JavaScript" → save_memory("User prefers Python over JavaScript", long_term=True)
    - User says "Remember to check the API docs tomorrow" → save_memory("Check API docs", long_term=False)
    - User asks "What do you know about me?" → read_memory() to recall saved info
    - User asks "Did I mention my project name?" → search_memory("project name")
    """)

    def __init__(self, workspace=None):
        """Initialize BuiltinMemoryTool.
        
        Args:
            workspace: Workspace instance for storing memories. If None, memories won't be persisted.
        """
        super().__init__(name="builtin_memory_tool")
        self._workspace = workspace
        self.register(self.save_memory)
        self.register(self.read_memory)
        self.register(self.search_memory)

    def set_workspace(self, workspace):
        """Set or update the workspace instance.
        
        Args:
            workspace: Workspace instance
        """
        self._workspace = workspace

    def get_system_prompt(self) -> Optional[str]:
        """Get the system prompt for memory tool usage."""
        return self.MEMORY_SYSTEM_PROMPT

    async def save_memory(self, content: str, long_term: bool = False) -> str:
        """Save important information to memory for future conversations.

        Use this tool to remember important user preferences, personal information,
        or any details that should be recalled in future conversations.

        Args:
            content: The information to remember. Should be a concise, clear statement.
                Examples:
                - "User prefers concise responses"
                - "User is working on a Python web project"
                - "User's name is Alice, she is a data scientist"
            long_term: If True, save to permanent long-term memory.
                If False (default), save to daily memory (cleared after 7 days).
                Use long_term=True for: user preferences, personal info, important facts.
                Use long_term=False for: temporary notes, daily tasks, short-term context.

        Returns:
            Confirmation message indicating where the memory was saved.
        """
        if not content or not content.strip():
            return "Error: Memory content cannot be empty."

        content = content.strip()
        
        if self._workspace is None:
            logger.warning("No workspace configured, memory not saved to disk.")
            return json.dumps({
                "success": False,
                "error": "No workspace configured. Memory not persisted.",
                "content": content,
            }, ensure_ascii=False)

        try:
            await self._workspace.save_memory(content, long_term=long_term)
            memory_type = "long-term" if long_term else "daily"
            logger.debug(f"Saved {memory_type} memory: {content[:50]}...")
            
            return json.dumps({
                "success": True,
                "memory_type": memory_type,
                "content": content,
                "message": f"Memory saved to {memory_type} storage.",
            }, ensure_ascii=False, indent=2)
        except Exception as e:
            logger.error(f"Error saving memory: {e}")
            return json.dumps({
                "success": False,
                "error": f"Failed to save memory: {e}",
                "content": content,
            }, ensure_ascii=False)

    async def read_memory(self, days: int = 7) -> str:
        """Read recent memories from workspace storage.

        Retrieves long-term memory and daily memories from the last N days.
        Use this to recall previously saved context about the user.

        Args:
            days: Number of recent days of daily memory to read. Default is 7.

        Returns:
            Memory content string with long-term and recent daily memories.
        """
        if self._workspace is None:
            return json.dumps({
                "success": False,
                "error": "No workspace configured. Cannot read memory.",
            }, ensure_ascii=False)

        try:
            content = await self._workspace.get_memory_prompt(days=days)
            return json.dumps({
                "success": True,
                "days": days,
                "content": content if content else "No memories found.",
            }, ensure_ascii=False, indent=2)
        except Exception as e:
            logger.error(f"Error reading memory: {e}")
            return json.dumps({
                "success": False,
                "error": f"Failed to read memory: {e}",
            }, ensure_ascii=False)

    def search_memory(self, query: str, limit: int = 5) -> str:
        """Search all saved memories by keyword.

        Searches across all memory files (long-term and daily) using keyword matching.
        Returns results ranked by relevance score.

        Note: This searches saved memory notes. Use search_conversations (if available)
        to search full conversation archives.

        Args:
            query: Search query string (keywords to match against memory content).
            limit: Maximum number of results to return. Default is 5.

        Returns:
            JSON string with matching memory entries and their relevance scores.
        """
        if self._workspace is None:
            return json.dumps({
                "success": False,
                "error": "No workspace configured. Cannot search memory.",
            }, ensure_ascii=False)

        if not query or not query.strip():
            return json.dumps({
                "success": False,
                "error": "Search query cannot be empty.",
            }, ensure_ascii=False)

        try:
            results = self._workspace.search_memory(query=query, limit=limit)
            return json.dumps({
                "success": True,
                "query": query,
                "count": len(results),
                "results": results,
            }, ensure_ascii=False, indent=2)
        except Exception as e:
            logger.error(f"Error searching memory: {e}")
            return json.dumps({
                "success": False,
                "error": f"Failed to search memory: {e}",
            }, ensure_ascii=False)


class BuiltinConversationTool(Tool):
    """
    Built-in conversation archive search tool.

    Allows the agent to search historical conversations stored in the workspace,
    enabling long-term recall of past interactions beyond the current session.
    """

    CONVERSATION_SYSTEM_PROMPT = dedent("""## search_conversations Tool

    You have access to a `search_conversations` tool to search your historical conversations with the user.

    ### When to Use This Tool

    Use this tool when:
    1. User refers to past conversations: "remember when we discussed...", "last time you said..."
    2. User asks to recall specific past work: "the code you wrote last week", "that analysis from yesterday"
    3. You need historical context that is not in the current conversation
    4. User explicitly asks about conversation history

    ### Guidelines

    1. Use specific keywords related to what you're looking for
    2. Results show conversation snippets with dates - use dates to orient the user
    3. The search is keyword-based, so try multiple relevant terms if first search misses
    """)

    def __init__(self, workspace=None):
        """Initialize BuiltinConversationTool.

        Args:
            workspace: Workspace instance for searching conversation archives.
        """
        super().__init__(name="builtin_conversation_tool")
        self._workspace = workspace
        self.register(self.search_conversations)

    def set_workspace(self, workspace):
        """Set or update the workspace instance."""
        self._workspace = workspace

    def get_system_prompt(self) -> Optional[str]:
        """Get the system prompt for conversation search tool."""
        return self.CONVERSATION_SYSTEM_PROMPT

    def search_conversations(
        self,
        query: str,
        limit: int = 10,
        max_files: Optional[int] = None,
    ) -> str:
        """Search historical conversation archives for past interactions.

        Use this tool to recall past conversations, find previously discussed topics,
        or retrieve information from earlier sessions.

        Args:
            query: Keywords to search for in conversation history.
            limit: Maximum number of results to return (default: 10).
            max_files: Only search the most recent N archive files (default: None = search all).

        Returns:
            JSON string with matching conversation snippets, dates, and relevance scores.
        """
        if not self._workspace:
            return json.dumps({
                "success": False,
                "error": "No workspace configured. Conversation search not available.",
            }, ensure_ascii=False)

        results = self._workspace.search_conversations(query=query, limit=limit, max_files=max_files)
        if not results:
            return json.dumps({
                "success": True,
                "message": f"No conversations found matching '{query}'.",
                "results": [],
            }, ensure_ascii=False)

        return json.dumps({
            "success": True,
            "query": query,
            "count": len(results),
            "results": results,
        }, ensure_ascii=False, indent=2)


def get_builtin_tools(
        work_dir: Optional[str] = None,
        include_file_tools: bool = True,
        include_execute: bool = True,
        include_web_search: bool = True,
        include_fetch_url: bool = True,
        include_todos: bool = True,
        include_task: bool = True,
        include_skills: bool = False,
        include_memory: bool = True,
        include_conversations: bool = True,
        task_model: Optional["Model"] = None,
        task_tools: Optional[List[Any]] = None,
        custom_skill_dirs: Optional[List[str]] = None,
        workspace=None,
        sandbox_config=None,
    ) -> List[Tool]:
    """
    Get the list of built-in tools for Agent.

    Args:
        work_dir: Work directory for file operations
        include_file_tools: Whether to include file tools (ls, read_file, write_file, edit_file, glob, grep)
        include_execute: Whether to include code execution tool
        include_web_search: Whether to include web search tool
        include_fetch_url: Whether to include URL fetching tool
        include_todos: Whether to include task management tools
        include_task: Whether to include subagent task tool
        include_skills: Whether to include skill tool for executing skills (default: False)
        include_memory: Whether to include memory save tool
        include_conversations: Whether to include conversation archive search tool
        task_model: Model for subagent tasks (optional, will use parent agent's model if not set)
        task_tools: Tools for subagent tasks (optional)
        custom_skill_dirs: Custom skill directories to load (optional)
        workspace: Workspace instance for memory tool (optional)
        sandbox_config: SandboxConfig instance for security isolation (optional)

    Returns:
        List of tools
    """
    tools = []

    if include_file_tools:
        tools.append(BuiltinFileTool(work_dir=work_dir, sandbox_config=sandbox_config))

    if include_execute:
        tools.append(BuiltinExecuteTool(work_dir=work_dir, sandbox_config=sandbox_config))

    if include_web_search:
        tools.append(BuiltinWebSearchTool())

    if include_fetch_url:
        tools.append(BuiltinFetchUrlTool())

    if include_todos:
        tools.append(BuiltinTodoTool())

    if include_task:
        tools.append(BuiltinTaskTool(model=task_model, tools=task_tools))

    if include_memory:
        tools.append(BuiltinMemoryTool(workspace=workspace))

    if include_conversations and workspace is not None:
        tools.append(BuiltinConversationTool(workspace=workspace))

    if include_skills:
        from agentica.tools.skill_tool import SkillTool
        tools.append(SkillTool(custom_skill_dirs=custom_skill_dirs))

    return tools


if __name__ == '__main__':
    # Test file tool
    file_tool = BuiltinFileTool()
    print("=== ls test ===")
    print(file_tool.ls("."))

    print("\n=== glob test ===")
    print(file_tool.glob("*.py", "."))

    # Test search tool
    search_tool = BuiltinWebSearchTool()
    print("\n=== web_search test ===")
    print(search_tool.web_search("Python programming", max_results=2))

    # Test todo tool
    todo_tool = BuiltinTodoTool()
    print("\n=== write_todos test ===")
    print(todo_tool.write_todos([
        {"content": "Task 1", "status": "in_progress"},
        {"content": "Task 2", "status": "pending"},
    ]))
    print("\n=== read_todos test ===")
    print(todo_tool.read_todos())
