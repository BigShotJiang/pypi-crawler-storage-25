from __future__ import annotations
from dataclasses import dataclass, field
from typing import Iterator
from .actions import Action


@dataclass(order=True)
class Keyframe:
    time: float   # seconds from show start
    drone_id: str = field(compare=False)
    action: Action = field(compare=False)

    def __repr__(self) -> str:
        return f"Keyframe(t={self.time:.2f}s, drone={self.drone_id!r}, action={self.action!r})"


class DroneTrack:
    """Ordered sequence of keyframes for a single drone."""

    def __init__(self, drone_id: str) -> None:
        self.drone_id = drone_id
        self._keyframes: list[Keyframe] = []

    def at(self, time: float, action: Action) -> DroneTrack:
        """Add an action at the given time (seconds). Returns self for chaining."""
        self._keyframes.append(Keyframe(time=time, drone_id=self.drone_id, action=action))
        self._keyframes.sort()
        return self

    def keyframes(self) -> list[Keyframe]:
        return list(self._keyframes)

    def duration(self) -> float:
        return self._keyframes[-1].time if self._keyframes else 0.0


class Show:
    """
    A complete drone light show: a set of named drone tracks.

    Usage::

        show = Show()
        show.add_drone("cf1", uri="radio://0/80/2M/E7E7E7E701")
        t = show.track("cf1")
        t.at(0.0, Takeoff(height=1.0))
        t.at(2.0, MoveTo(x=1.0, y=0.0, z=1.0, duration=3.0))
        t.at(2.0, SetColor(Color.RED))
        t.at(5.0, Land())
    """

    def __init__(self) -> None:
        self._uris: dict[str, str] = {}       # drone_id -> URI
        self._tracks: dict[str, DroneTrack] = {}

    def add_drone(self, drone_id: str, uri: str) -> DroneTrack:
        """Register a drone and return its track."""
        self._uris[drone_id] = uri
        if drone_id not in self._tracks:
            self._tracks[drone_id] = DroneTrack(drone_id)
        return self._tracks[drone_id]

    def track(self, drone_id: str) -> DroneTrack:
        if drone_id not in self._tracks:
            raise KeyError(f"Drone {drone_id!r} not registered. Call add_drone() first.")
        return self._tracks[drone_id]

    def uri(self, drone_id: str) -> str:
        return self._uris[drone_id]

    def drone_ids(self) -> list[str]:
        return list(self._uris.keys())

    def all_keyframes(self) -> list[Keyframe]:
        """All keyframes across all drones, sorted by time."""
        kfs: list[Keyframe] = []
        for track in self._tracks.values():
            kfs.extend(track.keyframes())
        kfs.sort()
        return kfs

    def duration(self) -> float:
        return max((t.duration() for t in self._tracks.values()), default=0.0)

    def __repr__(self) -> str:
        drones = ", ".join(self._uris.keys())
        return f"Show(drones=[{drones}], duration={self.duration():.1f}s)"
