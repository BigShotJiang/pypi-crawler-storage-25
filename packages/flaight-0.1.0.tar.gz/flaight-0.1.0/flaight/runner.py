"""
FlightRunner — executes a Show against real Crazyflie hardware via cflib.

Each drone runs in its own thread. The runner dispatches actions on a shared
wall-clock timeline so all drones move in sync.
"""
from __future__ import annotations
import contextlib
import logging
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Callable

import cflib.crtp
from cflib.crazyflie import Crazyflie
from cflib.crazyflie.syncCrazyflie import SyncCrazyflie

from .actions import Action, FadeColor, Hover, Land, MoveTo, SetColor, Takeoff
from .color import Color
from .timeline import Keyframe, Show
from .validate import CollisionError, validate
from . import _fmt

logger = logging.getLogger(__name__)

_DONGLE_ERROR = "Cannot find a Crazyradio Dongle"


@contextlib.contextmanager
def _silence_cflib():
    """Suppress cflib's verbose connection logging."""
    cflib_log = logging.getLogger("cflib")
    old_level = cflib_log.level
    cflib_log.setLevel(logging.CRITICAL)
    try:
        yield
    finally:
        cflib_log.setLevel(old_level)


def _crazyradio_present() -> bool:
    try:
        from cflib.drivers.crazyradio import Crazyradio
        radio = Crazyradio()
        radio.close()
        return True
    except Exception:
        return False


class DroneController:
    """Low-level wrapper around a single SyncCrazyflie."""

    def __init__(self, scf: SyncCrazyflie) -> None:
        self._scf = scf
        self._cf = scf.cf

    # --- Movement ---

    def takeoff(self, height: float, duration: float) -> None:
        self._cf.high_level_commander.takeoff(height, duration)

    def land(self, duration: float) -> None:
        self._cf.high_level_commander.land(0.0, duration)

    def go_to(self, x: float, y: float, z: float, yaw: float, duration: float) -> None:
        self._cf.high_level_commander.go_to(x, y, z, yaw, duration)

    def stop(self) -> None:
        self._cf.high_level_commander.stop()

    # --- Light ---

    def set_color(self, color: Color) -> None:
        self._cf.param.set_value("colorLedTop.wrgb8888", color.wrgb8888)

    def fade_color(self, start: Color, end: Color, duration: float, steps: int) -> None:
        interval = duration / steps
        for i in range(steps + 1):
            self.set_color(start.lerp(end, i / steps))
            if i < steps:
                time.sleep(interval)


def _execute_action(ctrl: DroneController, action: Action) -> None:
    if isinstance(action, Takeoff):
        ctrl.takeoff(action.height, action.duration)
    elif isinstance(action, Land):
        ctrl.land(action.duration)
    elif isinstance(action, Hover):
        time.sleep(action.duration)
    elif isinstance(action, MoveTo):
        ctrl.go_to(action.x, action.y, action.z, action.yaw, action.duration)
    elif isinstance(action, SetColor):
        ctrl.set_color(action.color)
    elif isinstance(action, FadeColor):
        ctrl.fade_color(Color.OFF, action.color, action.duration, action.steps)
    else:
        logger.warning("Unknown action type: %s", type(action).__name__)


def _run_drone(
    drone_id: str,
    uri: str,
    keyframes: list[Keyframe],
    start_event: threading.Event,
    on_error: Callable[[str, Exception], None],
    drone_colors: dict[str, tuple[int, int, int]],
) -> None:
    try:
        with _silence_cflib(), SyncCrazyflie(uri, cf=Crazyflie(rw_cache="./cache")) as scf:
            ctrl = DroneController(scf)
            logger.info("Connected to %s (%s)", drone_id, uri)
            start_event.wait()
            t0 = time.monotonic()

            for kf in keyframes:
                now = time.monotonic() - t0
                wait = kf.time - now
                if wait > 0:
                    time.sleep(wait)
                elapsed = time.monotonic() - t0
                _fmt.print_event(
                    f"{elapsed:6.2f}s",
                    drone_id,
                    drone_colors[drone_id],
                    kf.action,
                )
                _execute_action(ctrl, kf.action)

            time.sleep(0.5)  # let the last param write reach the drone before disconnect

    except Exception as exc:
        on_error(drone_id, exc)


class FlightRunner:
    """
    Connects to all drones in a Show and executes the choreography in sync.

    Example::

        runner = FlightRunner(show)
        runner.run()
    """

    def __init__(self, show: Show) -> None:
        self._show = show

    def run(self) -> None:
        try:
            validate(self._show)
        except CollisionError as exc:
            raise RuntimeError(f"Show abgebrochen — {exc}") from exc

        with _silence_cflib():
            cflib.crtp.init_drivers()

        if not _crazyradio_present():
            print("Kein Crazyradio-Dongle gefunden. Bitte USB-Dongle einstecken.")
            return

        show = self._show
        drone_colors = _fmt.drone_color_map(show.drone_ids())
        errors: list[tuple[str, Exception]] = []
        start_event = threading.Event()

        def on_error(drone_id: str, exc: Exception) -> None:
            errors.append((drone_id, exc))

        n = len(show.drone_ids())
        _fmt.print_header(f"FLAIGHT LIVE  —  {n} drone(s), {show.duration():.1f}s")

        with ThreadPoolExecutor(max_workers=len(show.drone_ids())) as pool:
            futures = {
                pool.submit(
                    _run_drone,
                    drone_id,
                    show.uri(drone_id),
                    show.track(drone_id).keyframes(),
                    start_event,
                    on_error,
                    drone_colors,
                ): drone_id
                for drone_id in show.drone_ids()
            }
            time.sleep(2.0)

            if errors:
                # all drones failed to connect
                start_event.set()  # unblock any waiting threads
                print(
                    f"Could not connect to drones ({', '.join(d for d, _ in errors)}). "
                    "Are the drones powered on and on the correct channel?"
                )
                return

            logger.info("All drones ready — starting show (%.1fs)", show.duration())
            start_event.set()

            for future in as_completed(futures):
                try:
                    future.result()
                except Exception as exc:
                    logger.error("Thread error: %s", exc)

        if errors:
            failed = ", ".join(d for d, _ in errors)
            raise RuntimeError(f"Show ended with errors on: {failed}")

        _fmt.print_footer(show.duration())
