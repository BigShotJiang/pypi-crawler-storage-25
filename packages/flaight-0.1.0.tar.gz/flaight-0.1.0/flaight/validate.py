"""Collision detection for multi-drone shows."""
from __future__ import annotations
import math

from .actions import Hover, Land, MoveTo, Takeoff
from .timeline import Keyframe, Show

SAFETY_DISTANCE = 0.20  # metres
_SAMPLE_INTERVAL = 0.05  # seconds between position samples

# (t0, t1, p0, p1, checkable)
_Segment = tuple[float, float, tuple[float, float, float], tuple[float, float, float], bool]


class CollisionError(Exception):
    """Raised when two drones come within the safety distance of each other."""


def _build_segments(keyframes: list[Keyframe]) -> list[_Segment]:
    """Return position segments for a drone.

    checkable=True only when the drone's absolute position is known.
    Absolute position is unknown until after the first MoveTo completes,
    because Takeoff operates in the drone's local frame.
    """
    segments: list[_Segment] = []
    x, y, z = 0.0, 0.0, 0.0
    pos_known = False  # becomes True once the first MoveTo fixes absolute position

    for kf in keyframes:
        a = kf.action
        t = kf.time
        if isinstance(a, Takeoff):
            segments.append((t, t + a.duration, (x, y, 0.0), (x, y, a.height), pos_known))
            z = a.height
        elif isinstance(a, Land):
            segments.append((t, t + a.duration, (x, y, z), (x, y, 0.0), pos_known))
            z = 0.0
            # pos_known stays True — we know where the drone landed
        elif isinstance(a, MoveTo):
            # path starts from estimated position; endpoint is always absolute
            segments.append((t, t + a.duration, (x, y, z), (a.x, a.y, a.z), pos_known))
            x, y, z = a.x, a.y, a.z
            pos_known = True
        elif isinstance(a, Hover):
            segments.append((t, t + a.duration, (x, y, z), (x, y, z), pos_known))
        # SetColor / FadeColor: no movement

    return segments


def _pos_at(segments: list[_Segment], t: float) -> tuple[float, float, float]:
    if not segments:
        return (0.0, 0.0, 0.0)
    if t <= segments[0][0]:
        return segments[0][2]
    if t >= segments[-1][1]:
        return segments[-1][3]
    for t0, t1, p0, p1, _ in segments:
        if t0 <= t <= t1:
            alpha = (t - t0) / (t1 - t0) if t1 > t0 else 1.0
            return (
                p0[0] + alpha * (p1[0] - p0[0]),
                p0[1] + alpha * (p1[1] - p0[1]),
                p0[2] + alpha * (p1[2] - p0[2]),
            )
    # gap between segments — stay at end of previous segment
    for i in range(len(segments) - 1):
        if segments[i][1] < t < segments[i + 1][0]:
            return segments[i][3]
    return segments[-1][3]


def _checkable_at(segments: list[_Segment], t: float) -> bool:
    # Iterate in reverse so that at segment boundaries the later segment wins
    for t0, t1, _p0, _p1, checkable in reversed(segments):
        if t0 <= t <= t1:
            return checkable
    return False


def validate(show: Show, safety: float = SAFETY_DISTANCE) -> None:
    """
    Verify that no two drones come within *safety* metres of each other
    during the parts of the show where absolute positions are known.

    Raises:
        CollisionError: with details about which drones, when, and where.
    """
    ids = show.drone_ids()
    if len(ids) < 2:
        return

    tracks = {did: _build_segments(show.track(did).keyframes()) for did in ids}
    duration = show.duration()

    t = 0.0
    while t <= duration + _SAMPLE_INTERVAL:
        for i, d1 in enumerate(ids):
            for d2 in ids[i + 1:]:
                if not (_checkable_at(tracks[d1], t) and _checkable_at(tracks[d2], t)):
                    continue
                p1 = _pos_at(tracks[d1], t)
                p2 = _pos_at(tracks[d2], t)
                dist = math.sqrt(sum((a - b) ** 2 for a, b in zip(p1, p2)))
                if dist < safety:
                    raise CollisionError(
                        f"Kollisionsgefahr bei t={t:.2f}s: {d1} und {d2} sind "
                        f"nur {dist * 100:.0f} cm voneinander entfernt "
                        f"(Sicherheitsabstand: {safety * 100:.0f} cm).\n"
                        f"  {d1}: ({p1[0]:.2f}, {p1[1]:.2f}, {p1[2]:.2f}) m\n"
                        f"  {d2}: ({p2[0]:.2f}, {p2[1]:.2f}, {p2[2]:.2f}) m"
                    )
        t += _SAMPLE_INTERVAL
