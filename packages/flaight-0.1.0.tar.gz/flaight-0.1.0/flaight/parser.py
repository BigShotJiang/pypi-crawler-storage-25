"""
ShowParser — converts a natural language show description into a Show object
using an Ollama-hosted language model.

The LLM outputs a structured JSON payload; no exec() is involved.
"""
from __future__ import annotations
import json
import re
import logging
from typing import Any

from .actions import Action, FadeColor, Hover, Land, MoveTo, SetColor, Takeoff
from .color import Color
from .timeline import Show

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# System prompt
# ---------------------------------------------------------------------------

_SYSTEM_PROMPT = """\
You are a drone light show choreographer. Given a natural language description \
you output a single JSON object — no markdown, no explanation, just the JSON.

JSON schema:
{
  "drones": ["cf1", "cf2", ...],
  "keyframes": [
    {"time": <float>, "drone_id": "<string>", "action": <action>}
  ]
}

Action types:
  Takeoff   {"type":"Takeoff",   "height":<m>,   "duration":<s>}
  Land      {"type":"Land",                       "duration":<s>}
  Hover     {"type":"Hover",                       "duration":<s>}
  MoveTo    {"type":"MoveTo",    "x":<m>, "y":<m>, "z":<m>, "yaw":<deg>, "duration":<s>}
  SetColor  {"type":"SetColor",  "color":{"r":<0-255>,"g":<0-255>,"b":<0-255>}}
  FadeColor {"type":"FadeColor", "color":{"r":<0-255>,"g":<0-255>,"b":<0-255>}, "duration":<s>}

Rules:
- drone_id must be one of the drones listed in "drones"
- ONLY include actions that are explicitly requested in the description. Do not add creative movements, positions, or actions that were not asked for.
- If and only if the description involves flying or movement: each drone must Takeoff before any movement action, and must Land at the end.
- If the description only involves colours/lights (no flying or movement mentioned): use only SetColor and FadeColor actions — no Takeoff, no MoveTo, no Land.
- default flying height: z = 1.0 m
- x/y range: -2.0 to 2.0 m (0,0 = centre)
- typical takeoff/land duration: 2.0 s
- colour values are RGB integers 0–255
- to turn LEDs off, always use SetColor with r=0, g=0, b=0 at the exact time the lights should go off

Example — "glow red for 3 seconds, then off" (colour only, no flying):
{"drones":["cf1"],"keyframes":[{"time":0.0,"drone_id":"cf1","action":{"type":"SetColor","color":{"r":255,"g":0,"b":0}}},{"time":3.0,"drone_id":"cf1","action":{"type":"SetColor","color":{"r":0,"g":0,"b":0}}}]}

Example — "one drone takes off, glows red, and lands" (flight involved):
{"drones":["cf1"],"keyframes":[{"time":0.0,"drone_id":"cf1","action":{"type":"Takeoff","height":1.0,"duration":2.0}},{"time":0.0,"drone_id":"cf1","action":{"type":"SetColor","color":{"r":255,"g":0,"b":0}}},{"time":2.0,"drone_id":"cf1","action":{"type":"Hover","duration":3.0}},{"time":5.0,"drone_id":"cf1","action":{"type":"Land","duration":2.0}},{"time":5.0,"drone_id":"cf1","action":{"type":"SetColor","color":{"r":0,"g":0,"b":0}}}]}
"""

# ---------------------------------------------------------------------------
# JSON → flaight objects
# ---------------------------------------------------------------------------

def _parse_color(data: dict[str, Any]) -> Color:
    return Color(r=int(data["r"]), g=int(data["g"]), b=int(data["b"]))


def _parse_action(data: dict[str, Any]) -> Action:
    t = data["type"]
    if t == "Takeoff":
        return Takeoff(height=float(data.get("height", 1.0)),
                       duration=float(data.get("duration", 2.0)))
    if t == "Land":
        return Land(duration=float(data.get("duration", 2.0)))
    if t == "Hover":
        return Hover(duration=float(data.get("duration", 1.0)))
    if t == "MoveTo":
        return MoveTo(x=float(data["x"]), y=float(data["y"]), z=float(data["z"]),
                      yaw=float(data.get("yaw", 0.0)),
                      duration=float(data.get("duration", 2.0)))
    if t == "SetColor":
        return SetColor(color=_parse_color(data["color"]))
    if t == "FadeColor":
        return FadeColor(color=_parse_color(data["color"]),
                         duration=float(data.get("duration", 1.0)),
                         steps=int(data.get("steps", 20)))
    raise ValueError(f"Unknown action type: {t!r}")


def _build_show(payload: dict[str, Any], uri_map: dict[str, str]) -> Show:
    show = Show()
    for drone_id in payload["drones"]:
        uri = uri_map.get(drone_id, f"radio://0/80/2M/E7E7E7E7{(ord(drone_id[-1]) - ord('0')):02X}")
        show.add_drone(drone_id, uri=uri)

    skipped = 0
    for kf in payload["keyframes"]:
        drone_id = kf["drone_id"]
        if drone_id not in show.drone_ids():
            logger.warning("Keyframe references unknown drone %r — skipping", drone_id)
            skipped += 1
            continue
        try:
            action = _parse_action(kf["action"])
        except (KeyError, ValueError) as exc:
            logger.warning("Could not parse action %r — skipping (%s)", kf["action"], exc)
            skipped += 1
            continue
        show.track(drone_id).at(float(kf["time"]), action)

    if skipped:
        logger.warning("%d keyframe(s) skipped due to parse errors", skipped)
    return show


def _extract_json(text: str) -> str:
    """Strip markdown code fences and extract the first JSON object."""
    text = text.strip()
    # Remove ```json ... ``` or ``` ... ```
    text = re.sub(r"^```(?:json)?\s*", "", text)
    text = re.sub(r"\s*```$", "", text)
    # Find first { ... } block
    match = re.search(r"\{.*\}", text, re.DOTALL)
    if match:
        return match.group(0)
    return text

# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

class ParseError(Exception):
    """Raised when the LLM output cannot be interpreted as a valid Show."""


_THEMATIC_SYSTEM_PROMPT = """\
You are a creative drone light show choreographer. Given a theme or emotional description, \
design an expressive aerial performance with formations, synchronized movement, and a colour \
palette that matches the mood. Output a single JSON object — no markdown, no explanation, just the JSON.

JSON schema:
{
  "drones": ["cf1", "cf2", ...],
  "keyframes": [
    {"time": <float>, "drone_id": "<string>", "action": <action>}
  ]
}

Action types:
  Takeoff   {"type":"Takeoff",   "height":<m>,   "duration":<s>}
  Land      {"type":"Land",                       "duration":<s>}
  Hover     {"type":"Hover",                       "duration":<s>}
  MoveTo    {"type":"MoveTo",    "x":<m>, "y":<m>, "z":<m>, "yaw":<deg>, "duration":<s>}
  SetColor  {"type":"SetColor",  "color":{"r":<0-255>,"g":<0-255>,"b":<0-255>}}
  FadeColor {"type":"FadeColor", "color":{"r":<0-255>,"g":<0-255>,"b":<0-255>}, "duration":<s>}

Choreography guidelines:
- Every drone must Takeoff at the start and Land at the end. Use all available drones.
- Structure the show in acts: opening formation → development → climax → resolution.
- Use the full flying area: position drones into shapes (line, V, circle, diamond, arc, spiral)
  and move through formations that express the theme. Drones should converge, diverge, orbit,
  mirror, or chase each other in ways that feel narrative and intentional.
- Vary altitude (z: 0.5–1.8 m) to create depth and drama.
- Design a colour palette that fits the mood, for example:
    calm / melancholy  → cool blues, soft whites, dim purples
    energy / joy       → warm reds, oranges, bright yellows
    mystery / tension  → deep purples, teals, slow dark fades
    hope / dawn        → deep orange fading through gold to white
    danger / urgency   → sharp red/white flashes via SetColor
- Use FadeColor for gradual atmospheric transitions; SetColor for sharp punctuated moments.
- Every action — position, colour, timing — should serve the theme intentionally.
- Total show duration: 20–45 seconds.
- x/y range: −2.0 to 2.0 m (0,0 = centre); z: 0.5–1.8 m; floor = z 0.
- Takeoff/land duration: 2.0 s; movement duration: 2.0–5.0 s; colour values: RGB 0–255.
"""

_SUMMARY_SYSTEM_PROMPT = """\
You are a drone light show choreographer. Given a natural language description, \
summarize in English (2–4 short sentences) exactly what the choreography would do: \
which drones, which actions, which colours, and when. \
Be concrete about timing. Do not generate JSON. Do not add anything not requested.\
"""

_THEMATIC_SUMMARY_PROMPT = """\
You are a creative drone light show choreographer. Given a theme or emotion, \
describe in English (2–4 short sentences) the aerial show you would create to express it: \
which formations the drones would fly, how they would move, what colour palette you would use, \
and how the overall arc of the choreography reflects the theme. \
Be concrete about your artistic vision. Do not generate JSON.\
"""


class ShowParser:
    """
    Converts a natural language description into a :class:`flaight.Show`
    using an Ollama-hosted language model.

    Args:
        host:  Ollama server URL, e.g. ``"http://localhost:11434"`` or a
               remote host like ``"http://192.168.1.10:11434"``.
        model: Ollama model name, e.g. ``"llama3.2"`` or ``"mistral"``.
        verbose: If True, log the raw LLM response at DEBUG level.

    Example::

        parser = ShowParser(host="http://localhost:11434", model="llama3.2")
        show = parser.parse(
            "Two drones take off, fly apart and alternate between red and blue",
            uris=["radio://0/80/2M/E7E7E7E701", "radio://0/80/2M/E7E7E7E702"],
        )
        DryRunRunner(show).run()
    """

    def __init__(
        self,
        host: str = "http://localhost:11434",
        model: str = "llama3.2",
        *,
        verbose: bool = False,
        timeout: float = 300.0,
    ) -> None:
        self.host = host
        self.model = model
        self.verbose = verbose
        self.timeout = timeout

    def _chat(self, system: str, user: str, *, fmt: str | None = None) -> str:
        import ollama
        client = ollama.Client(host=self.host, timeout=self.timeout)
        kwargs: dict = dict(
            model=self.model,
            messages=[
                {"role": "system", "content": system},
                {"role": "user",   "content": user},
            ],
            options={"temperature": 0.2},
        )
        if fmt:
            kwargs["format"] = fmt
        try:
            response = client.chat(**kwargs)
        except ollama.ResponseError as exc:
            raise ParseError(f"Ollama server error: {exc}") from exc
        except Exception as exc:
            raise ParseError(f"Ollama request failed: {exc}") from exc
        raw = response.message.content
        if self.verbose:
            logger.debug("Raw LLM response:\n%s", raw)
        return raw

    def summarize(self, description: str, uris: list[str]) -> str:
        """Return a short plain-text summary of what the show would do."""
        drone_ids = [f"cf{i + 1}" for i in range(len(uris))]
        user_msg = f"Available drones: {drone_ids}\n\nShow description:\n{description}"
        return self._chat(_SUMMARY_SYSTEM_PROMPT, user_msg).strip()

    def summarize_thematic(self, description: str, uris: list[str]) -> str:
        """Return a short plain-text description of the creative show the model would build."""
        drone_ids = [f"cf{i + 1}" for i in range(len(uris))]
        user_msg = f"Available drones: {drone_ids}\n\nTheme / emotion:\n{description}"
        return self._chat(_THEMATIC_SUMMARY_PROMPT, user_msg).strip()

    def run_interactive(
        self,
        uris: list[str],
        *,
        fly: bool = False,
        realtime: bool = False,
    ) -> None:
        """
        Interactive REPL: prompt for a show description, summarize, confirm,
        parse, and run — in a loop until the user quits.

        Args:
            uris:     Ordered list of Crazyflie URIs passed to each parsed show.
            fly:      If True, run on real hardware; otherwise dry-run.
            realtime: If True, dry-run in real time (ignored when *fly* is True).
        """
        from . import _fmt
        from .export import save_script
        from .runner import FlightRunner
        from .simulation import DryRunRunner

        B = _fmt.BRAND

        print(f"\n{B}  Model : {self.model}")
        print(f"{B}  Host  : {self.host}")
        print(f"{B}  Drones: {len(uris)}  ({', '.join(uris)})")
        print()

        while True:
            try:
                description = input(f"{B}  Describe a show (empty = quit): ").strip()
            except (EOFError, KeyboardInterrupt):
                print()
                break
            if not description:
                break

            print(f"{B}  … summarizing choreography …")
            try:
                summary = self.summarize(description, uris=uris)
            except ParseError as exc:
                print(f"\n{B}  Error: {exc}\n")
                continue

            print(f"\n{B}  Understood:\n{B}  {summary}\n")
            try:
                confirm = input(f"{B}  Generate? (yes/no): ").strip().lower()
            except (EOFError, KeyboardInterrupt):
                print()
                break
            if confirm != "yes":
                print()
                continue

            print(f"{B}  … generating choreography …")
            try:
                show = self.parse(description, uris=uris)
            except ParseError as exc:
                print(f"\n{B}  Error: {exc}\n")
                continue

            try:
                action = input(
                    f"{B}  [r]un / [s]ave / [b]oth / [n]o: "
                ).strip().lower()
            except (EOFError, KeyboardInterrupt):
                print()
                break

            if action in ("s", "b"):
                path = save_script(show)
                print(f"{B}  Saved: {path}\n")

            if action in ("r", "b"):
                if fly:
                    FlightRunner(show).run()
                else:
                    DryRunRunner(show, realtime=realtime).run()

    def parse_thematic(self, description: str, uris: list[str]) -> Show:
        """
        Generate a creative Show from a theme or emotional description.

        The model interprets the theme freely, choosing formations, movement arcs,
        and a colour palette that express the mood — rather than following explicit
        choreography instructions.

        Args:
            description: Theme or emotion in any language (e.g. "melancholy", "Aufbruch", "storm").
            uris:        Ordered list of Crazyflie URIs assigned to cf1, cf2, …

        Raises:
            ParseError: If the model response cannot be parsed into a valid Show.
        """
        drone_ids = [f"cf{i + 1}" for i in range(len(uris))]
        uri_map = dict(zip(drone_ids, uris))

        user_msg = (
            f"Available drones: {drone_ids}\n\n"
            f"Theme / emotion:\n{description}"
        )

        raw = self._chat(_THEMATIC_SYSTEM_PROMPT, user_msg, fmt="json")

        try:
            json_str = _extract_json(raw)
            payload = json.loads(json_str)
        except json.JSONDecodeError as exc:
            raise ParseError(
                f"Model did not return valid JSON.\nRaw output:\n{raw}"
            ) from exc

        if "drones" not in payload or "keyframes" not in payload:
            raise ParseError(
                f"JSON missing required keys 'drones' / 'keyframes'.\nPayload: {payload}"
            )

        return _build_show(payload, uri_map)

    def parse(self, description: str, uris: list[str]) -> Show:
        """
        Parse *description* into a Show.

        Args:
            description: Free-form show description in any language.
            uris:        Ordered list of Crazyflie URIs. The parser assigns
                         ``cf1``, ``cf2``, … to them in order. The LLM may use
                         fewer drones than provided.

        Raises:
            ParseError: If the model response cannot be parsed into a valid Show.
        """
        drone_ids = [f"cf{i + 1}" for i in range(len(uris))]
        uri_map = dict(zip(drone_ids, uris))

        user_msg = (
            f"Available drones: {drone_ids}\n\n"
            f"Show description:\n{description}"
        )

        raw = self._chat(_SYSTEM_PROMPT, user_msg, fmt="json")

        try:
            json_str = _extract_json(raw)
            payload = json.loads(json_str)
        except json.JSONDecodeError as exc:
            raise ParseError(
                f"Model did not return valid JSON.\nRaw output:\n{raw}"
            ) from exc

        if "drones" not in payload or "keyframes" not in payload:
            raise ParseError(
                f"JSON missing required keys 'drones' / 'keyframes'.\nPayload: {payload}"
            )

        return _build_show(payload, uri_map)
