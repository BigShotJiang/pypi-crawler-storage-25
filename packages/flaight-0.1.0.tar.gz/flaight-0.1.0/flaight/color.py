from __future__ import annotations
from dataclasses import dataclass


@dataclass(frozen=True)
class Color:
    r: int  # 0-255
    g: int
    b: int

    def __post_init__(self) -> None:
        for ch, val in (("r", self.r), ("g", self.g), ("b", self.b)):
            if not 0 <= val <= 255:
                raise ValueError(f"Color channel {ch}={val} out of range 0-255")

    def lerp(self, other: Color, t: float) -> Color:
        """Linear interpolation between two colors (t in 0..1)."""
        return Color(
            r=round(self.r + (other.r - self.r) * t),
            g=round(self.g + (other.g - self.g) * t),
            b=round(self.b + (other.b - self.b) * t),
        )

    @property
    def wrgb8888(self) -> str:
        """Packed WRGB8888 string for colorLedTop.wrgb8888 (W=0)."""
        value = (self.r << 16) | (self.g << 8) | self.b
        return str(value)

    def __repr__(self) -> str:
        return f"Color(r={self.r}, g={self.g}, b={self.b})"


# Named presets
Color.OFF = Color(0, 0, 0)
Color.WHITE = Color(255, 255, 255)
Color.RED = Color(255, 0, 0)
Color.GREEN = Color(0, 255, 0)
Color.BLUE = Color(0, 0, 255)
Color.YELLOW = Color(255, 200, 0)
Color.CYAN = Color(0, 255, 255)
Color.MAGENTA = Color(255, 0, 255)
Color.ORANGE = Color(255, 80, 0)
Color.PURPLE = Color(128, 0, 255)
