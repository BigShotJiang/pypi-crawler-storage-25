"""DryRunRunner — simulates a Show without hardware."""
from __future__ import annotations
import time

from .timeline import Show
from .validate import CollisionError, validate
from . import _fmt


class DryRunRunner:
    """
    Simulates a Show without any hardware.

    Args:
        show: The Show to simulate.
        realtime: If True, sleep between events to match actual show timing.
                  If False, print everything instantly.

    Example::

        DryRunRunner(show).run()
        DryRunRunner(show, realtime=True).run()
    """

    def __init__(self, show: Show, realtime: bool = False) -> None:
        self._show = show
        self._realtime = realtime

    def run(self) -> None:
        try:
            validate(self._show)
        except CollisionError as exc:
            print(f"\n{_fmt.BRAND}  Kollisionswarnung: {exc}\n")
            return

        show = self._show
        keyframes = show.all_keyframes()
        drone_colors = _fmt.drone_color_map(show.drone_ids())

        n = len(show.drone_ids())
        mode = "real-time" if self._realtime else "instant"
        _fmt.print_header(f"FLAIGHT DRY RUN  —  {n} drone(s), {show.duration():.1f}s  [{mode}]")

        t0 = time.monotonic()
        prev_time: float | None = None

        for kf in keyframes:
            if self._realtime:
                now = time.monotonic() - t0
                wait = kf.time - now
                if wait > 0:
                    time.sleep(wait)
                t_label = f"{time.monotonic() - t0:6.2f}s"
            else:
                if prev_time is not None and kf.time != prev_time:
                    print()
                t_label = f"{kf.time:6.2f}s"

            prev_time = kf.time
            _fmt.print_event(t_label, kf.drone_id, drone_colors[kf.drone_id], kf.action)

        total = time.monotonic() - t0 if self._realtime else show.duration()
        _fmt.print_footer(total)
