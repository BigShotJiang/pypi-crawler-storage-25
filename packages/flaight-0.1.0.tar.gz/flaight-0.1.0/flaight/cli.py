from __future__ import annotations
import argparse
import logging

DEFAULT_URIS = [
    "radio://0/80/2M/E7E7E7E7E7",
    "radio://0/81/2M/E7E7E7E7E7",
]


def main() -> None:
    ap = argparse.ArgumentParser(description="Flaight AI show parser")
    ap.add_argument("--host",     default="http://localhost:11434", help="Ollama host URL")
    ap.add_argument("--model",    default="llama3.2",               help="Ollama model name")
    ap.add_argument("--uris",     nargs="+", default=DEFAULT_URIS,  help="Crazyflie URIs")
    ap.add_argument("--realtime", action="store_true",              help="Play dry-run in real time")
    ap.add_argument("--fly",      action="store_true",              help="Start a real flight")
    ap.add_argument("--verbose",  action="store_true",              help="Show raw LLM response")
    ap.add_argument("--timeout",  type=float, default=300.0,        help="Ollama request timeout in seconds (default: 300)")
    args = ap.parse_args()

    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format="%(levelname)s  %(message)s",
    )

    from flaight import DryRunRunner, FlightRunner, ParseError, ShowParser, save_script

    parser = ShowParser(host=args.host, model=args.model, verbose=args.verbose, timeout=args.timeout)

    print(f"\nModel : {args.model}")
    print(f"Host  : {args.host}")
    print(f"Drones: {len(args.uris)}  ({', '.join(args.uris)})")
    print()

    while True:
        print()
        print("  [1] Describe the choreography directly")
        print("  [2] Describe a theme / emotion — AI designs the show")
        try:
            mode = input("  Choice (empty = quit): ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            break
        if not mode:
            break
        if mode not in ("1", "2"):
            continue

        thematic = mode == "2"
        label = "Theme / emotion: " if thematic else "Describe the show: "

        try:
            description = input(f"  {label}").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            break
        if not description:
            continue

        print("  … summarizing …")
        try:
            if thematic:
                summary = parser.summarize_thematic(description, uris=args.uris)
            else:
                summary = parser.summarize(description, uris=args.uris)
        except ParseError as exc:
            print(f"\n  Error: {exc}\n")
            continue

        print(f"\n  Understood:\n  {summary}\n")
        try:
            confirm = input("  Generate? (yes/no): ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            print()
            break
        if confirm != "yes":
            print()
            continue

        print("  … generating choreography …")
        try:
            if thematic:
                show = parser.parse_thematic(description, uris=args.uris)
            else:
                show = parser.parse(description, uris=args.uris)
        except ParseError as exc:
            print(f"\n  Error: {exc}\n")
            continue

        try:
            action = input("  [r]un / [s]ave / [b]oth / [n]o: ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            print()
            break

        if action in ("s", "b"):
            path = save_script(show)
            print(f"  Saved: {path}\n")

        if action in ("r", "b"):
            if args.fly:
                FlightRunner(show).run()
            else:
                DryRunRunner(show, realtime=args.realtime).run()
