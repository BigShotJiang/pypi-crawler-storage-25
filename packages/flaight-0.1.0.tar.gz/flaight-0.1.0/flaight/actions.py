from __future__ import annotations
from dataclasses import dataclass, field
from .color import Color


class Action:
    """Base class for all drone actions."""


@dataclass
class Takeoff(Action):
    height: float = 1.0   # meters
    duration: float = 2.0  # seconds for the maneuver


@dataclass
class Land(Action):
    duration: float = 2.0


@dataclass
class Hover(Action):
    duration: float = 1.0


@dataclass
class MoveTo(Action):
    x: float
    y: float
    z: float
    yaw: float = 0.0      # degrees
    duration: float = 2.0  # seconds for the maneuver


@dataclass
class SetColor(Action):
    color: Color


@dataclass
class FadeColor(Action):
    color: Color
    duration: float = 1.0  # seconds for the fade (stepped via runner)
    steps: int = 20         # interpolation steps
