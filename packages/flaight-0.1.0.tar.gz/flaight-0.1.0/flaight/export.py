"""Export a Show object as a standalone Python script."""
from __future__ import annotations
import datetime
from pathlib import Path

from .actions import FadeColor, Hover, Land, MoveTo, SetColor, Takeoff
from .color import Color
from .timeline import Show

# Reverse-lookup table: (r, g, b) -> "Color.NAME"
_NAMED_COLORS: dict[tuple[int, int, int], str] = {
    (c.r, c.g, c.b): f"Color.{name}"
    for name, c in vars(Color).items()
    if isinstance(c, Color)
}


def _color_repr(c: Color) -> str:
    return _NAMED_COLORS.get((c.r, c.g, c.b), f"Color(r={c.r}, g={c.g}, b={c.b})")


def _action_repr(action: object) -> str:
    if isinstance(action, Takeoff):
        return f"Takeoff(height={action.height}, duration={action.duration})"
    if isinstance(action, Land):
        return f"Land(duration={action.duration})"
    if isinstance(action, Hover):
        return f"Hover(duration={action.duration})"
    if isinstance(action, MoveTo):
        return (
            f"MoveTo(x={action.x}, y={action.y}, z={action.z}, "
            f"yaw={action.yaw}, duration={action.duration})"
        )
    if isinstance(action, SetColor):
        return f"SetColor({_color_repr(action.color)})"
    if isinstance(action, FadeColor):
        extra = f", steps={action.steps}" if action.steps != 20 else ""
        return f"FadeColor(color={_color_repr(action.color)}, duration={action.duration}{extra})"
    raise ValueError(f"Unknown action type: {type(action).__name__}")


def to_script(show: Show) -> str:
    """Render *show* as a standalone Python script string."""
    drone_ids = show.drone_ids()

    used_types: set[str] = set()
    needs_color = False
    for did in drone_ids:
        for kf in show.track(did).keyframes():
            used_types.add(type(kf.action).__name__)
            if isinstance(kf.action, (SetColor, FadeColor)):
                needs_color = True

    import_parts = (["Color"] if needs_color else []) + sorted(used_types) + ["FlightRunner", "Show"]
    import_line = f"from flaight import {', '.join(import_parts)}"

    var = {did: f"d{i + 1}" for i, did in enumerate(drone_ids)}

    lines: list[str] = [
        '"""AI-generated drone show."""',
        import_line,
        "",
        "show = Show()",
    ]

    for did in drone_ids:
        lines.append(f'{var[did]} = show.add_drone("{did}", uri="{show.uri(did)}")')

    for did in drone_ids:
        lines.append("")
        lines.append(f"# --- {did} ---")
        for kf in show.track(did).keyframes():
            lines.append(f"{var[did]}.at({kf.time}, {_action_repr(kf.action)})")

    lines += [
        "",
        'if __name__ == "__main__":',
        "    import logging",
        "    import sys",
        "    logging.basicConfig(level=logging.INFO)",
        '    dry = "--fly" not in sys.argv',
        "    if dry:",
        "        from flaight import DryRunRunner",
        '        DryRunRunner(show, realtime="--realtime" in sys.argv).run()',
        "    else:",
        "        FlightRunner(show).run()",
    ]

    return "\n".join(lines) + "\n"


def save_script(show: Show, output_dir: str = "ai_generated") -> Path:
    """Write *show* as a Python script to *output_dir* and return the path."""
    Path(output_dir).mkdir(parents=True, exist_ok=True)
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    path = Path(output_dir) / f"show_{timestamp}.py"
    path.write_text(to_script(show))
    return path
