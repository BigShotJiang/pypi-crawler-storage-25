"""Shared terminal formatting for dry-run and live output."""
from __future__ import annotations
import time
from itertools import cycle

from .actions import Action, FadeColor, Hover, Land, MoveTo, SetColor, Takeoff
from .color import Color

_RESET = "\033[0m"
_BOLD  = "\033[1m"
_DIM   = "\033[2m"
_LBLUE = "\033[94m"

BRAND = f"fl{_LBLUE}ai{_RESET}ght"

_DRONE_PALETTE = [
    (100, 180, 255),  # sky blue
    (255, 120,  60),  # orange
    (100, 230, 130),  # green
    (220, 100, 220),  # violet
    (255, 220,  60),  # yellow
    ( 80, 220, 220),  # cyan
]


def ansi_fg(r: int, g: int, b: int) -> str:
    return f"\033[38;2;{r};{g};{b}m"


def ansi_bg(r: int, g: int, b: int) -> str:
    return f"\033[48;2;{r};{g};{b}m"


def color_swatch(c: Color) -> str:
    return f"{ansi_bg(c.r, c.g, c.b)}  {_RESET}"


def format_action(action: Action) -> str:
    if isinstance(action, Takeoff):
        return f"Takeoff    height={action.height}m, duration={action.duration}s"
    if isinstance(action, Land):
        return f"Land       duration={action.duration}s"
    if isinstance(action, Hover):
        return f"Hover      duration={action.duration}s"
    if isinstance(action, MoveTo):
        return (
            f"MoveTo     x={action.x}, y={action.y}, z={action.z}, "
            f"yaw={action.yaw}°, duration={action.duration}s"
        )
    if isinstance(action, SetColor):
        c = action.color
        return f"SetColor   {color_swatch(c)} ({c.r}, {c.g}, {c.b})"
    if isinstance(action, FadeColor):
        c = action.color
        return f"FadeColor  {color_swatch(c)} ({c.r}, {c.g}, {c.b}), duration={action.duration}s"
    return repr(action)


def drone_color_map(drone_ids: list[str]) -> dict[str, tuple[int, int, int]]:
    palette = cycle(_DRONE_PALETTE)
    return {d: next(palette) for d in drone_ids}


def drone_tag(drone_id: str, rgb: tuple[int, int, int]) -> str:
    r, g, b = rgb
    return f"{ansi_fg(r, g, b)}{_BOLD}{drone_id:<8}{_RESET}"


def print_header(title: str) -> None:
    print()
    print(f"{BRAND}  {_BOLD}{'═' * 56}{_RESET}")
    print(f"{BRAND}  {_BOLD}  {title}{_RESET}")
    print(f"{BRAND}  {_BOLD}{'═' * 56}{_RESET}")
    print()
    print(f"{BRAND}  {'t':>8}   {'drone':<8}  action")
    print(f"{BRAND}  {'─' * 8}   {'─' * 8}  {'─' * 36}")


def print_event(t_label: str, did: str, rgb: tuple[int, int, int], action: Action) -> None:
    print(f"{BRAND}  t={t_label}   {drone_tag(did, rgb)}  {format_action(action)}", flush=True)


def print_footer(duration: float) -> None:
    print()
    print(f"{BRAND}  {_DIM}Show complete. Total duration: {duration:.1f}s{_RESET}")
    print()
