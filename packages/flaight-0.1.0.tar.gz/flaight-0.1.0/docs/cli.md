# CLI — flaight

`flaight` is an interactive command-line session for the [AI parser](ai-parser.md). After installing flaight it is available directly in your shell — no script to create.

## Prerequisites

[Ollama](https://ollama.com) must be running with a model pulled:

```bash
ollama pull llama3.2
ollama serve
```

## Basic usage

```bash
flaight
```

At the start of each iteration you choose between two input modes:

```
  [1] Describe the choreography directly
  [2] Describe a theme / emotion — AI designs the show
```

**Mode 1** — you describe exactly what the drones should do; the model follows literally.  
**Mode 2** — you describe a theme or emotion; the model acts as a creative choreographer and designs formations, movement, and a colour palette to match.

After choosing a mode you enter a description, review a plain-text summary, confirm, and the show is generated and run.

## Flags

| Flag | Default | Description |
|------|---------|-------------|
| `--host` | `http://localhost:11434` | Ollama server URL |
| `--model` | `llama3.2` | Ollama model name |
| `--uris` | two placeholder URIs | Ordered list of Crazyflie URIs |
| `--realtime` | off | Play dry-run in real time |
| `--fly` | off | Run on real hardware instead of dry-run |
| `--verbose` | off | Log raw LLM JSON response |
| `--timeout` | `300` | Ollama request timeout in seconds |

## Examples

```bash
# Custom model
flaight --model mistral

# Remote Ollama server
flaight --host http://192.168.1.10:11434 --model llama3.2

# Three drones with explicit URIs
flaight --uris radio://0/80/2M/E7E7E7E701 radio://0/80/2M/E7E7E7E702 radio://0/80/2M/E7E7E7E703

# Real-time dry-run
flaight --realtime

# Fly for real
flaight --fly

# Debug: print raw LLM response
flaight --verbose

# Longer timeout for slow models
flaight --model llama3.2 --timeout 600
```

## Session flow

```
Model : llama3.2
Host  : http://localhost:11434
Drones: 2  (radio://0/80/2M/E7E7E7E7E7, radio://0/81/2M/E7E7E7E7E7)

  [1] Describe the choreography directly
  [2] Describe a theme / emotion — AI designs the show
  Choice (empty = quit): 1
  Describe the show: Two drones take off, spiral outward and land
  … summarizing …

  Understood:
  cf1 and cf2 take off simultaneously to 1.0 m, spiral outward …

  Generate? (yes/no): yes
  … generating choreography …
  [r]un / [s]ave / [b]oth / [n]o: b
  Saved: ai_generated/show_20260510_124002.py
```

Press **Enter** (empty input) or **Ctrl+C** at any prompt to exit cleanly.
