# Colors

The `Color` class represents an RGB LED color. All channel values are integers in the range 0–255.

## Named presets

```python
from flaight import Color

Color.OFF      # (0, 0, 0)      — LEDs off
Color.WHITE    # (255, 255, 255)
Color.RED      # (255, 0, 0)
Color.GREEN    # (0, 255, 0)
Color.BLUE     # (0, 0, 255)
Color.YELLOW   # (255, 200, 0)
Color.CYAN     # (0, 255, 255)
Color.MAGENTA  # (255, 0, 255)
Color.ORANGE   # (255, 80, 0)
Color.PURPLE   # (128, 0, 255)
```

## Custom colors

```python
teal = Color(r=0, g=180, b=160)
warm_white = Color(r=255, g=220, b=180)
```

## Interpolation

`lerp` blends linearly between two colors. `t=0.0` returns the starting color, `t=1.0` returns the target color.

```python
mid = Color.RED.lerp(Color.BLUE, 0.5)   # equal mix of red and blue
quarter = Color.RED.lerp(Color.BLUE, 0.25)
```

This is used internally by `FadeColor` to generate intermediate steps.

## Validation

`Color` validates its inputs on construction:

```python
Color(r=300, g=0, b=0)  # raises ValueError — channel out of range 0-255
```
