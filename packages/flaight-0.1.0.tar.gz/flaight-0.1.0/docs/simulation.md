# Simulation & Validation

## DryRunRunner

Simulates a show without any hardware. Prints each event as it occurs.

```python
from flaight import DryRunRunner

# Print all events instantly
DryRunRunner(show).run()

# Sleep between events to match real show timing
DryRunRunner(show, realtime=True).run()
```

`DryRunRunner` automatically runs a collision check before starting. If a collision is detected, it prints a warning and aborts — no events are printed.

## FlightRunner

Executes a show on real Crazyflie hardware via Crazyradio.

```python
from flaight import FlightRunner

FlightRunner(show).run()
```

Requires a Crazyradio USB dongle. Like `DryRunRunner`, it also runs the collision check first and aborts if unsafe.

## Collision validation

flaight samples drone positions every 50 ms throughout the show and raises `CollisionError` if any two drones come within 20 cm of each other during segments where their absolute positions are known.

```python
from flaight import validate, CollisionError

try:
    validate(show)              # default safety distance: 20 cm
    validate(show, safety=0.5)  # custom distance in metres
except CollisionError as e:
    print(e)
```

!!! note "When validation skips segments"
    Positions are only known after the first `MoveTo` action. Takeoff and early hover segments use estimated positions and are not checked — this avoids false positives when drones are placed at unknown start positions.

### Example collision error message

```
CollisionError: Kollisionsgefahr bei t=4.30s: cf1 und cf2 sind nur 12 cm voneinander entfernt
  (Sicherheitsabstand: 20 cm).
  cf1: (0.50, 0.00, 1.20) m
  cf2: (0.38, 0.00, 1.20) m
```
