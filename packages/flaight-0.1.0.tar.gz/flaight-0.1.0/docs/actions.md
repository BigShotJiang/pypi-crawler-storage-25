# Actions

Actions are the building blocks of every show. Each action is placed on a drone track at a specific time with `drone.at(time, action)`.

## Reference

| Action | Parameters | Notes |
|--------|-----------|-------|
| `Takeoff(height, duration)` | height in metres, duration in seconds | Must be the first flying action for any drone |
| `Land(duration)` | duration in seconds | Must be the last flying action |
| `Hover(duration)` | duration in seconds | Stay in place at current position |
| `MoveTo(x, y, z, yaw, duration)` | x/y/z in metres from origin, yaw in degrees | Absolute world-frame position |
| `SetColor(color)` | `Color` instance | Instant LED change |
| `FadeColor(color, duration, steps)` | target color, fade time, interpolation steps | Smooth LED transition |

## Takeoff

```python
from flaight import Takeoff

d1.at(0.0, Takeoff(height=1.0, duration=2.0))
```

Lifts the drone from the floor to `height` metres over `duration` seconds. Default: `height=1.0`, `duration=2.0`.

## Land

```python
from flaight import Land

d1.at(8.0, Land(duration=2.0))
```

Descends from current altitude to the floor. Default: `duration=2.0`.

## Hover

```python
from flaight import Hover

d1.at(4.0, Hover(duration=3.0))
```

Holds position for `duration` seconds. Default: `duration=1.0`.

## MoveTo

```python
from flaight import MoveTo

d1.at(2.0, MoveTo(x=1.0, y=0.0, z=1.2, duration=3.0))
d1.at(2.0, MoveTo(x=-0.5, y=1.0, z=1.5, yaw=90.0, duration=4.0))
```

Moves to an absolute world-frame position. `x` and `y` are horizontal, `z` is altitude. `yaw` rotates the drone heading (degrees, default 0°). Default: `duration=2.0`.

## SetColor

```python
from flaight import Color, SetColor

d1.at(0.0, SetColor(Color.RED))
d1.at(5.0, SetColor(Color.OFF))   # turn LEDs off
```

Sets the LED ring color instantly. See [Colors](colors.md) for all available presets.

## FadeColor

```python
from flaight import Color, FadeColor

d1.at(3.0, FadeColor(color=Color.BLUE, duration=2.0))
d1.at(3.0, FadeColor(color=Color.BLUE, duration=2.0, steps=40))
```

Fades the LED ring smoothly from the current color to `color` over `duration` seconds. `steps` controls how many interpolation points are used (default 20). A higher value gives a smoother fade.

## Combining actions

Multiple actions at the same timestamp are allowed — a common pattern is taking off and setting the initial color simultaneously:

```python
d1.at(0.0, Takeoff(height=1.0, duration=2.0))
d1.at(0.0, SetColor(Color.RED))
```
