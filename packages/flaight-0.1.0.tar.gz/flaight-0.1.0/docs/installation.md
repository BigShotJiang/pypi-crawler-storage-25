# Installation

## Requirements

- Python **3.10** or newer
- For hardware flight: a **Crazyradio** USB dongle and the [cflib](https://github.com/bitcraze/crazyflie-lib-python) library (included as a dependency)
- For the AI parser and `flaight` CLI: a running [Ollama](https://ollama.com) server with at least one model pulled

## Install flaight

```bash
pip install -e .
```

This also registers the `flaight` command in your shell.

## Set up Ollama

Install Ollama from [ollama.com](https://ollama.com), then pull a model and start the server:

```bash
ollama pull llama3.2
ollama serve
```

Any model that reliably produces JSON works. `llama3.2` and `mistral` are good choices.

## Development extras

To install test and documentation tools:

```bash
pip install -e ".[dev]"
```

Included: `pytest`, `pytest-cov`, `mkdocs`, `mkdocs-material`.

To build and preview the documentation locally:

```bash
mkdocs serve
```

Then open [http://127.0.0.1:8000](http://127.0.0.1:8000) in your browser.
