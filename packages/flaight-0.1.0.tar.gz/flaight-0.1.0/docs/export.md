# Exporting Shows

Any `Show` — whether hand-crafted or AI-generated — can be exported as a standalone Python script. The script is fully self-contained: it imports from flaight and supports `--fly` / `--realtime` flags out of the box.

## Save to file

```python
from flaight import save_script

path = save_script(show)                      # → ai_generated/show_<timestamp>.py
path = save_script(show, output_dir="shows")  # custom output directory
print(f"Saved: {path}")
```

## Print to stdout

```python
from flaight import to_script

print(to_script(show))
```

## Running an exported script

```bash
python ai_generated/show_20260510_124002.py            # dry-run
python ai_generated/show_20260510_124002.py --realtime # real-time dry-run
python ai_generated/show_20260510_124002.py --fly      # real hardware
```

## Example output

```python
"""AI-generated drone show."""
from flaight import Color, FadeColor, FlightRunner, Land, MoveTo, SetColor, Show, Takeoff

show = Show()
d1 = show.add_drone("cf1", uri="radio://0/80/2M/E7E7E7E701")
d2 = show.add_drone("cf2", uri="radio://0/80/2M/E7E7E7E702")

# --- cf1 ---
d1.at(0.0, Takeoff(height=1.0, duration=2.0))
d1.at(0.0, SetColor(Color.BLUE))
d1.at(2.0, MoveTo(x=-1.0, y=0.0, z=1.2, yaw=0.0, duration=3.0))
d1.at(5.0, FadeColor(color=Color.RED, duration=2.0))
d1.at(7.0, Land(duration=2.0))
d1.at(7.0, SetColor(Color.OFF))

# --- cf2 ---
d2.at(0.0, Takeoff(height=1.0, duration=2.0))
...

if __name__ == "__main__":
    import logging, sys
    logging.basicConfig(level=logging.INFO)
    dry = "--fly" not in sys.argv
    if dry:
        from flaight import DryRunRunner
        DryRunRunner(show, realtime="--realtime" in sys.argv).run()
    else:
        FlightRunner(show).run()
```
