# Quick start

## Core concepts

A **Show** holds one or more named drones, each with a **DroneTrack** — an ordered list of `(time, action)` pairs called **keyframes**. All times are in seconds from show start. Multiple actions on the same drone at the same time are allowed (e.g. `Takeoff` and `SetColor` simultaneously).

## Your first show

```python
from flaight import Color, FadeColor, Hover, Land, MoveTo, SetColor, Show, Takeoff

show = Show()
d1 = show.add_drone("cf1", uri="radio://0/80/2M/E7E7E7E701")

d1.at(0.0, Takeoff(height=1.0, duration=2.0))
d1.at(0.0, SetColor(Color.RED))
d1.at(2.0, MoveTo(x=1.0, y=0.0, z=1.0, duration=3.0))
d1.at(5.0, FadeColor(color=Color.BLUE, duration=1.5))
d1.at(6.5, Land(duration=2.0))
d1.at(6.5, SetColor(Color.OFF))
```

## Simulate without hardware

```python
from flaight import DryRunRunner

DryRunRunner(show).run()             # instant printout
DryRunRunner(show, realtime=True).run()  # real-time timing
```

## Fly for real

```python
from flaight import FlightRunner

FlightRunner(show).run()
```

`FlightRunner` runs a collision check before connecting. If two drones come within 20 cm of each other it raises `CollisionError` and aborts.

## Two-drone example

```python
from flaight import Color, FadeColor, FlightRunner, Hover, Land, MoveTo, SetColor, Show, Takeoff

show = Show()
d1 = show.add_drone("cf1", uri="radio://0/80/2M/E7E7E7E7E7")
d2 = show.add_drone("cf2", uri="radio://0/81/2M/E7E7E7E7E7")

# left drone — starts blue
d1.at(0.0, Takeoff(height=1.0, duration=2.0))
d1.at(0.0, SetColor(Color.BLUE))
d1.at(2.5, MoveTo(x=-0.5, y=0.0, z=1.2, duration=2.0))
d1.at(4.5, FadeColor(color=Color.RED, duration=1.5))
d1.at(6.0, Hover(duration=2.0))
d1.at(8.0, Land(duration=2.0))
d1.at(8.0, SetColor(Color.OFF))

# right drone — mirrors with swapped colors
d2.at(0.0, Takeoff(height=1.0, duration=2.0))
d2.at(0.0, SetColor(Color.RED))
d2.at(2.5, MoveTo(x=0.5, y=0.0, z=1.2, duration=2.0))
d2.at(4.5, FadeColor(color=Color.BLUE, duration=1.5))
d2.at(6.0, Hover(duration=2.0))
d2.at(8.0, Land(duration=2.0))
d2.at(8.0, SetColor(Color.OFF))

DryRunRunner(show).run()
```

## Coordinate system

- Origin `(0, 0, 0)` is the centre of the flying area
- x/y range: roughly −2 m to +2 m
- z = 0 is the floor; typical flying height is 1.0 m
- Yaw is in degrees; 0° faces the positive x direction
