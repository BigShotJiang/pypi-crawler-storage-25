# flaight

**light → flight → flaight.**

By [Dominic Neuburg](mailto:dom@flaight.dev) — MIT License

Choreography library for [Crazyflie](https://www.bitcraze.io/products/crazyflie-2-1/) drone light shows. This project is maintained with the help of vibe coding. Define timed sequences of movements and light effects in Python, simulate them without hardware, and fly them for real.

## What makes flaight different

The centrepiece feature: describe a show in plain language — *"two drones take off, fly apart and alternate between red and blue"* — and flaight uses a local language model (via [Ollama](https://ollama.com)) to turn that description directly into a `Show` object. No generated code is executed: the model returns structured JSON that flaight safely converts into drone actions.

## Key features

- **Hand-craft shows** with a clean Python API — keyframes, actions, colors
- **Simulate without hardware** — instant printout or real-time dry-run
- **Collision detection** — automatic safety check before every run
- **AI parser** — describe shows in plain language in any language
- **Two AI modes** — follow explicit instructions, or let the model design a thematic performance
- **CLI** — `flaight` interactive session, no script needed
- **Export** — save any AI-generated show as a standalone Python script

## Next steps

- [Installation](installation.md)
- [Quick start](quickstart.md)
- [CLI — flaight](cli.md)
- [AI Parser](ai-parser.md)
