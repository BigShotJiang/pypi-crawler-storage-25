"""
Parser tests — Ollama is fully mocked; no server required.
"""
from __future__ import annotations
import json
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

import pytest

from flaight import DryRunRunner, ParseError, ShowParser
from flaight.actions import FadeColor, Hover, Land, MoveTo, SetColor, Takeoff
from flaight.parser import _build_show, _extract_json, _parse_action, _parse_color


URIS = ["radio://0/80/2M/E7E7E7E701", "radio://0/80/2M/E7E7E7E702"]

# ---------------------------------------------------------------------------
# Unit tests for pure helper functions (no LLM involved)
# ---------------------------------------------------------------------------

def test_parse_color_basic():
    c = _parse_color({"r": 255, "g": 128, "b": 0})
    assert c.r == 255 and c.g == 128 and c.b == 0


def test_parse_action_takeoff():
    a = _parse_action({"type": "Takeoff", "height": 1.5, "duration": 3.0})
    assert isinstance(a, Takeoff)
    assert a.height == 1.5


def test_parse_action_moveto():
    a = _parse_action({"type": "MoveTo", "x": 1.0, "y": -0.5, "z": 1.2, "duration": 2.5})
    assert isinstance(a, MoveTo)
    assert a.y == -0.5


def test_parse_action_setcolor():
    a = _parse_action({"type": "SetColor", "color": {"r": 0, "g": 255, "b": 0}})
    assert isinstance(a, SetColor)
    assert a.color.g == 255


def test_parse_action_fadecolor():
    a = _parse_action({"type": "FadeColor", "color": {"r": 255, "g": 0, "b": 0}, "duration": 2.0})
    assert isinstance(a, FadeColor)
    assert a.duration == 2.0


def test_parse_action_unknown_raises():
    with pytest.raises(ValueError, match="Unknown action type"):
        _parse_action({"type": "Spin"})


def test_extract_json_plain():
    raw = '{"drones":["cf1"],"keyframes":[]}'
    assert _extract_json(raw) == raw


def test_extract_json_strips_markdown():
    raw = '```json\n{"drones":["cf1"],"keyframes":[]}\n```'
    result = _extract_json(raw)
    assert result.startswith("{")
    assert json.loads(result)["drones"] == ["cf1"]


def test_extract_json_with_preamble():
    raw = 'Here is the JSON:\n{"drones":["cf1"],"keyframes":[]}'
    result = _extract_json(raw)
    assert json.loads(result)["drones"] == ["cf1"]


def test_build_show_one_drone():
    payload = {
        "drones": ["cf1"],
        "keyframes": [
            {"time": 0.0, "drone_id": "cf1", "action": {"type": "Takeoff", "height": 1.0, "duration": 2.0}},
            {"time": 2.0, "drone_id": "cf1", "action": {"type": "Land", "duration": 2.0}},
        ],
    }
    show = _build_show(payload, {"cf1": URIS[0]})
    assert show.duration() == 2.0
    assert len(show.all_keyframes()) == 2


def test_build_show_unknown_drone_skipped(caplog):
    payload = {
        "drones": ["cf1"],
        "keyframes": [
            {"time": 0.0, "drone_id": "cf2", "action": {"type": "Takeoff", "height": 1.0, "duration": 2.0}},
        ],
    }
    import logging
    with caplog.at_level(logging.WARNING, logger="flaight.parser"):
        show = _build_show(payload, {"cf1": URIS[0]})
    assert show.duration() == 0.0
    assert "unknown drone" in caplog.text


# ---------------------------------------------------------------------------
# Integration tests with mocked Ollama client
# ---------------------------------------------------------------------------

def _make_ollama_response(payload: dict) -> MagicMock:
    msg = SimpleNamespace(content=json.dumps(payload))
    resp = SimpleNamespace(message=msg)
    return resp


def _valid_payload() -> dict:
    return {
        "drones": ["cf1", "cf2"],
        "keyframes": [
            {"time": 0.0, "drone_id": "cf1", "action": {"type": "Takeoff", "height": 1.0, "duration": 2.0}},
            {"time": 0.0, "drone_id": "cf1", "action": {"type": "SetColor", "color": {"r": 255, "g": 0, "b": 0}}},
            {"time": 0.0, "drone_id": "cf2", "action": {"type": "Takeoff", "height": 1.0, "duration": 2.0}},
            {"time": 0.0, "drone_id": "cf2", "action": {"type": "SetColor", "color": {"r": 0, "g": 0, "b": 255}}},
            {"time": 3.0, "drone_id": "cf1", "action": {"type": "Land", "duration": 2.0}},
            {"time": 3.0, "drone_id": "cf2", "action": {"type": "Land", "duration": 2.0}},
        ],
    }


@patch("ollama.Client")
def test_parse_returns_show(mock_client_cls):
    mock_client_cls.return_value.chat.return_value = _make_ollama_response(_valid_payload())

    parser = ShowParser(host="http://fake:11434", model="test-model")
    show = parser.parse("Two drones take off and land", uris=URIS)

    assert len(show.drone_ids()) == 2
    assert show.duration() == 3.0


@patch("ollama.Client")
def test_parse_calls_correct_host_and_model(mock_client_cls):
    mock_client_cls.return_value.chat.return_value = _make_ollama_response(_valid_payload())

    ShowParser(host="http://myhost:11434", model="mistral").parse("test", uris=URIS)

    mock_client_cls.assert_called_once_with(host="http://myhost:11434", timeout=300.0)
    call_kwargs = mock_client_cls.return_value.chat.call_args
    assert call_kwargs.kwargs["model"] == "mistral"


@patch("ollama.Client")
def test_parse_dry_run_output(mock_client_cls, capsys):
    mock_client_cls.return_value.chat.return_value = _make_ollama_response(_valid_payload())

    parser = ShowParser(host="http://fake:11434", model="test-model")
    show = parser.parse("test", uris=URIS)
    DryRunRunner(show).run()

    out = capsys.readouterr().out
    assert "cf1" in out
    assert "cf2" in out
    assert "Takeoff" in out


@patch("ollama.Client")
def test_parse_raises_on_invalid_json(mock_client_cls):
    msg = SimpleNamespace(content="this is not json at all")
    mock_client_cls.return_value.chat.return_value = SimpleNamespace(message=msg)

    with pytest.raises(ParseError, match="valid JSON"):
        ShowParser(host="http://fake:11434", model="x").parse("test", uris=URIS)


@patch("ollama.Client")
def test_parse_raises_on_missing_keys(mock_client_cls):
    msg = SimpleNamespace(content='{"something": "else"}')
    mock_client_cls.return_value.chat.return_value = SimpleNamespace(message=msg)

    with pytest.raises(ParseError, match="missing required keys"):
        ShowParser(host="http://fake:11434", model="x").parse("test", uris=URIS)


@patch("ollama.Client")
def test_parse_raises_on_connection_error(mock_client_cls):
    mock_client_cls.return_value.chat.side_effect = ConnectionRefusedError("no server")

    with pytest.raises(ParseError, match="Ollama request failed"):
        ShowParser(host="http://nowhere:11434", model="x").parse("test", uris=URIS)


@patch("ollama.Client")
def test_parse_json_in_markdown_fences(mock_client_cls):
    """Model outputs JSON wrapped in markdown code block — should still work."""
    raw = "```json\n" + json.dumps(_valid_payload()) + "\n```"
    msg = SimpleNamespace(content=raw)
    mock_client_cls.return_value.chat.return_value = SimpleNamespace(message=msg)

    show = ShowParser(host="http://fake:11434", model="x").parse("test", uris=URIS)
    assert show.duration() == 3.0


# ---------------------------------------------------------------------------
# Thematic mode
# ---------------------------------------------------------------------------

@patch("ollama.Client")
def test_parse_thematic_returns_show(mock_client_cls):
    mock_client_cls.return_value.chat.return_value = _make_ollama_response(_valid_payload())

    show = ShowParser(host="http://fake:11434", model="x").parse_thematic("Euphoria", uris=URIS)

    assert len(show.drone_ids()) == 2
    assert show.duration() == 3.0


@patch("ollama.Client")
def test_parse_thematic_uses_different_system_prompt(mock_client_cls):
    mock_client_cls.return_value.chat.return_value = _make_ollama_response(_valid_payload())

    ShowParser(host="http://fake:11434", model="x").parse("direct", uris=URIS)
    direct_system = mock_client_cls.return_value.chat.call_args.kwargs["messages"][0]["content"]

    mock_client_cls.return_value.chat.return_value = _make_ollama_response(_valid_payload())
    ShowParser(host="http://fake:11434", model="x").parse_thematic("Euphoria", uris=URIS)
    thematic_system = mock_client_cls.return_value.chat.call_args.kwargs["messages"][0]["content"]

    assert direct_system != thematic_system
    assert "creative" in thematic_system


@patch("ollama.Client")
def test_parse_thematic_raises_on_invalid_json(mock_client_cls):
    msg = SimpleNamespace(content="not json")
    mock_client_cls.return_value.chat.return_value = SimpleNamespace(message=msg)

    with pytest.raises(ParseError, match="valid JSON"):
        ShowParser(host="http://fake:11434", model="x").parse_thematic("Storm", uris=URIS)


# ---------------------------------------------------------------------------
# Summarize
# ---------------------------------------------------------------------------

@patch("ollama.Client")
def test_summarize_returns_string(mock_client_cls):
    summary_text = "cf1 and cf2 take off, spiral outward, and land after 10 seconds."
    msg = SimpleNamespace(content=summary_text)
    mock_client_cls.return_value.chat.return_value = SimpleNamespace(message=msg)

    result = ShowParser(host="http://fake:11434", model="x").summarize("two drones spiral", uris=URIS)

    assert isinstance(result, str)
    assert "cf1" in result


@patch("ollama.Client")
def test_summarize_thematic_returns_string(mock_client_cls):
    summary_text = "The drones form a slow expanding circle in cool blue tones."
    msg = SimpleNamespace(content=summary_text)
    mock_client_cls.return_value.chat.return_value = SimpleNamespace(message=msg)

    result = ShowParser(host="http://fake:11434", model="x").summarize_thematic("Calm", uris=URIS)

    assert isinstance(result, str)
    assert len(result) > 0


@patch("ollama.Client")
def test_summarize_uses_different_prompt_than_summarize_thematic(mock_client_cls):
    msg = SimpleNamespace(content="summary")
    mock_client_cls.return_value.chat.return_value = SimpleNamespace(message=msg)

    parser = ShowParser(host="http://fake:11434", model="x")

    parser.summarize("desc", uris=URIS)
    direct_system = mock_client_cls.return_value.chat.call_args.kwargs["messages"][0]["content"]

    parser.summarize_thematic("theme", uris=URIS)
    thematic_system = mock_client_cls.return_value.chat.call_args.kwargs["messages"][0]["content"]

    assert direct_system != thematic_system
