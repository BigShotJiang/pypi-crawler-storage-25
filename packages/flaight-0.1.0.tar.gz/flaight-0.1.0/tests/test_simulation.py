import io
import sys
import time
import pytest
from flaight import Color, DryRunRunner, FadeColor, Land, MoveTo, SetColor, Show, Takeoff


def make_show() -> Show:
    show = Show()
    t = show.add_drone("cf1", uri="radio://0/80/2M/E7E7E7E701")
    t.at(0.0, Takeoff(height=1.0))
    t.at(0.0, SetColor(Color.BLUE))
    t.at(3.0, MoveTo(x=1.0, y=0.0, z=1.5, duration=2.0))
    t.at(3.0, FadeColor(color=Color.RED, duration=1.0))
    t.at(5.0, Land())
    return show


def _capture_run(show: Show, realtime: bool = False) -> str:
    buf = io.StringIO()
    old = sys.stdout
    sys.stdout = buf
    try:
        DryRunRunner(show, realtime=realtime).run()
    finally:
        sys.stdout = old
    return buf.getvalue()


def test_dry_run_instant_contains_all_events() -> None:
    output = _capture_run(make_show())
    assert "Takeoff" in output
    assert "SetColor" in output
    assert "MoveTo" in output
    assert "FadeColor" in output
    assert "Land" in output


def test_dry_run_instant_shows_drone_id() -> None:
    output = _capture_run(make_show())
    assert "cf1" in output


def test_dry_run_instant_shows_duration() -> None:
    output = _capture_run(make_show())
    assert "5.0s" in output


def test_dry_run_instant_is_fast() -> None:
    t0 = time.monotonic()
    _capture_run(make_show(), realtime=False)
    assert time.monotonic() - t0 < 0.5


def test_dry_run_realtime_takes_time() -> None:
    show = Show()
    t = show.add_drone("cf1", uri="radio://0/80/2M/E7E7E7E701")
    t.at(0.0, Takeoff())
    t.at(0.2, Land())
    t0 = time.monotonic()
    _capture_run(show, realtime=True)
    assert time.monotonic() - t0 >= 0.2


def test_dry_run_multiple_drones() -> None:
    show = Show()
    show.add_drone("a", uri="radio://0/80/2M/E7E7E7E701").at(0.0, Takeoff()).at(3.0, Land())
    show.add_drone("b", uri="radio://0/80/2M/E7E7E7E702").at(0.0, Takeoff()).at(3.0, Land())
    output = _capture_run(show)
    assert "a" in output
    assert "b" in output
