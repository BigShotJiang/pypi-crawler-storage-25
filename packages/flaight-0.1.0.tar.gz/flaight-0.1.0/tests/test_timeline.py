import pytest
from flaight import Color, FadeColor, Hover, Land, MoveTo, SetColor, Show, Takeoff
from flaight.timeline import Keyframe


def make_show() -> Show:
    show = Show()
    t = show.add_drone("cf1", uri="radio://0/80/2M/E7E7E7E701")
    t.at(0.0, Takeoff(height=1.0))
    t.at(2.0, MoveTo(x=1.0, y=0.0, z=1.0, duration=3.0))
    t.at(2.0, SetColor(Color.RED))
    t.at(5.0, Land())
    return show


def test_show_duration() -> None:
    show = make_show()
    assert show.duration() == 5.0


def test_keyframes_sorted() -> None:
    show = make_show()
    times = [kf.time for kf in show.all_keyframes()]
    assert times == sorted(times)


def test_all_keyframes_count() -> None:
    show = make_show()
    assert len(show.all_keyframes()) == 4


def test_track_chaining() -> None:
    show = Show()
    show.add_drone("x", uri="radio://0/80/2M/E7E7E7E701")
    show.track("x").at(0.0, Takeoff()).at(3.0, Land())
    assert show.duration() == 3.0


def test_unknown_drone_raises() -> None:
    show = Show()
    with pytest.raises(KeyError):
        show.track("ghost")


def test_color_lerp() -> None:
    c = Color.RED.lerp(Color.BLUE, 0.5)
    assert c.r == 128
    assert c.g == 0
    assert c.b == 128


def test_color_out_of_range() -> None:
    with pytest.raises(ValueError):
        Color(r=300, g=0, b=0)


def test_color_wrgb8888_red() -> None:
    assert Color.RED.wrgb8888 == str(255 << 16)


def test_color_wrgb8888_blue() -> None:
    assert Color.BLUE.wrgb8888 == str(255)


def test_color_wrgb8888_off() -> None:
    assert Color.OFF.wrgb8888 == "0"


def test_multiple_drones() -> None:
    show = Show()
    show.add_drone("a", uri="radio://0/80/2M/E7E7E7E701")
    show.add_drone("b", uri="radio://0/80/2M/E7E7E7E702")
    show.track("a").at(0.0, Takeoff()).at(4.0, Land())
    show.track("b").at(0.0, Takeoff()).at(6.0, Land())
    assert show.duration() == 6.0
    assert len(show.drone_ids()) == 2
