"""
Minimal example: generate a show from natural language and save it as a script.

Two modes are demonstrated:
  - Direct: the model follows explicit choreography instructions
  - Thematic: the model designs the show from a theme or emotion

Usage:
    python examples/ai_show.py
    python examples/ai_show.py --realtime
    python examples/ai_show.py --fly
"""
from __future__ import annotations
import argparse

from flaight import DryRunRunner, FlightRunner, ParseError, ShowParser, save_script

URIS = [
    "radio://0/80/2M/E7E7E7E7E7",
    "radio://0/81/2M/E7E7E7E7E7",
]


def main() -> None:
    ap = argparse.ArgumentParser(description="flaight AI show example")
    ap.add_argument("--host",     default="http://localhost:11434")
    ap.add_argument("--model",    default="llama3.2")
    ap.add_argument("--realtime", action="store_true")
    ap.add_argument("--fly",      action="store_true")
    args = ap.parse_args()

    parser = ShowParser(host=args.host, model=args.model)

    # --- Mode 1: direct choreography ---
    print("Generating show from explicit instructions …")
    try:
        show = parser.parse(
            "Two drones take off, fly to opposite sides, alternate red and blue twice, then land.",
            uris=URIS,
        )
        path = save_script(show)
        print(f"Saved: {path}")
        if args.fly:
            FlightRunner(show).run()
        else:
            DryRunRunner(show, realtime=args.realtime).run()
    except ParseError as exc:
        print(f"Error: {exc}")

    # --- Mode 2: thematic choreography ---
    print("\nGenerating show from theme …")
    try:
        show = parser.parse_thematic(
            "Euphoria — an explosion of energy and colour.",
            uris=URIS,
        )
        path = save_script(show)
        print(f"Saved: {path}")
        if args.fly:
            FlightRunner(show).run()
        else:
            DryRunRunner(show, realtime=args.realtime).run()
    except ParseError as exc:
        print(f"Error: {exc}")


if __name__ == "__main__":
    main()
