"""
Color test: LED ring cycles through several colors — drone stays on the ground.

Usage:
    python examples/color_test.py           # Dry-run
    python examples/color_test.py --fly     # Real hardware (lights only, no flight)
"""
from flaight import Color, FadeColor, SetColor, Show

URIS = [
    "radio://0/80/2M/E7E7E7E7E7",
    "radio://0/81/2M/E7E7E7E7E7",
]

show = Show()
d1 = show.add_drone("cf1", uri=URIS[0])
d2 = show.add_drone("cf2", uri=URIS[1])

# Color sequence: both drones cycle through the same colors with an offset
sequence = [
    (0.0,  Color.RED),
    (2.0,  Color.YELLOW),
    (4.0,  Color.GREEN),
    (6.0,  Color.CYAN),
    (8.0,  Color.BLUE),
    (10.0, Color.MAGENTA),
    (12.0, Color.WHITE),
    (14.0, Color.OFF),
]

for t, color in sequence:
    d1.at(t, FadeColor(color=color, duration=1.5))

# cf2 starts with a one-second offset → wave effect
for t, color in sequence:
    d2.at(t + 1.0, FadeColor(color=color, duration=1.5))

if __name__ == "__main__":
    import sys
    if "--fly" in sys.argv:
        from flaight import FlightRunner
        FlightRunner(show).run()
    else:
        from flaight import DryRunRunner
        DryRunRunner(show, realtime="--realtime" in sys.argv).run()
