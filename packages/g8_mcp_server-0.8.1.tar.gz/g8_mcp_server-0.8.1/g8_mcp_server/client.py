"""Shared HTTP client for communicating with the graph8 backend API."""

from __future__ import annotations

import json
import logging
import os
from pathlib import Path
from typing import Any, Callable, TypeVar

import httpx
from pydantic import BaseModel, ValidationError

logger = logging.getLogger(__name__)

ModelT = TypeVar("ModelT", bound=BaseModel)

CREDENTIALS_PATH = Path.home() / ".g8" / "credentials.json"

# ---------------------------------------------------------------------------
# Module-level shared httpx.AsyncClient for connection pooling.
# Creates a new connection to base_url only when the URL changes or the
# client is closed - avoids per-call TCP handshake overhead.
# ---------------------------------------------------------------------------
_shared_client: httpx.AsyncClient | None = None
_shared_client_base_url: str = ""


def _get_client(base_url: str) -> httpx.AsyncClient:
    """Return (or lazily create) the module-level shared httpx.AsyncClient."""
    global _shared_client, _shared_client_base_url
    if (
        _shared_client is None
        or _shared_client.is_closed
        or _shared_client_base_url != base_url
    ):
        if _shared_client is not None and not _shared_client.is_closed:
            # base_url changed; close the old client gracefully in the background
            import asyncio

            try:
                loop = asyncio.get_event_loop()
                if loop.is_running():
                    loop.create_task(_shared_client.aclose())
            except Exception:
                pass
        _shared_client = httpx.AsyncClient(base_url=base_url)
        _shared_client_base_url = base_url
    return _shared_client


def load_stored_credentials() -> tuple[str, str, str]:
    """Load credentials from ~/.g8/credentials.json.

    Returns (api_key, api_url, auth_method).
    auth_method is "oauth" or "api_key" (or empty if no credentials).
    """
    if not CREDENTIALS_PATH.exists():
        return "", "", ""
    try:
        data = json.loads(CREDENTIALS_PATH.read_text())
        return (
            data.get("api_key", ""),
            data.get("api_url", ""),
            data.get("auth_method", "api_key"),
        )
    except (json.JSONDecodeError, OSError):
        return "", "", ""


def save_credentials(api_key: str, api_url: str = "", *, auth_method: str = "api_key", email: str = "") -> None:
    """Save credentials to ~/.g8/credentials.json."""
    CREDENTIALS_PATH.parent.mkdir(parents=True, exist_ok=True)
    data: dict[str, str] = {"api_key": api_key, "api_url": api_url, "auth_method": auth_method}
    if email:
        data["email"] = email
    CREDENTIALS_PATH.write_text(json.dumps(data, indent=2))
    CREDENTIALS_PATH.chmod(0o600)


def remove_credentials() -> bool:
    """Remove stored credentials. Returns True if file existed."""
    if CREDENTIALS_PATH.exists():
        CREDENTIALS_PATH.unlink()
        return True
    return False


class G8ClientError(Exception):
    """Raised when a graph8 API call fails."""

    def __init__(self, status_code: int, message: str):
        self.status_code = status_code
        super().__init__(message)


class G8Client:
    """Thin wrapper around httpx for graph8 Developer API calls.

    Key resolution order:
    1. contextvars (set by auth middleware in remote/HTTP mode)
    2. G8_API_KEY env var (used in local/stdio mode)
    3. ~/.g8/credentials.json (stored by `g8 login`)
    """

    def __init__(self, *, require_key: bool = True) -> None:
        self._env_api_key = os.environ.get("G8_API_KEY", "")
        self._stored_key, stored_url, self._auth_method = "", "", ""
        if not self._env_api_key:
            self._stored_key, stored_url, self._auth_method = load_stored_credentials()

        env_url = os.environ.get("G8_API_URL", "")
        self.base_url = (env_url or stored_url or "http://localhost:8000").rstrip("/")

        if require_key and not self._env_api_key and not self._stored_key:
            raise G8ClientError(
                401,
                "No API key found. Run `g8 login` or set G8_API_KEY.\n"
                "  Get a key at https://app.graph8.com/settings/api",
            )

    @property
    def _api_key(self) -> str:
        from g8_mcp_server.auth import get_api_key
        return get_api_key() or self._env_api_key or self._stored_key

    @property
    def _api_key_source(self) -> str:
        """Return where the active API key comes from (for `g8 whoami`)."""
        from g8_mcp_server.auth import get_api_key
        if get_api_key():
            return "MCP remote (OAuth)"
        if self._env_api_key:
            return "G8_API_KEY environment variable"
        if self._stored_key:
            return f"~/.g8/credentials.json"
        return "none"

    @property
    def _headers(self) -> dict[str, str]:
        key = self._api_key
        if not key:
            raise G8ClientError(401, "No API key - run `g8 login` or set G8_API_KEY")
        return {"Authorization": f"Bearer {key}", "Content-Type": "application/json"}

    async def get(self, path: str, params: dict[str, Any] | None = None) -> dict[str, Any]:
        client = _get_client(self.base_url)
        resp = await client.get(f"/api/v1{path}", params=_strip_none(params), headers=self._headers, timeout=60)
        return _handle_response(resp)

    async def post(
        self,
        path: str,
        body: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        client = _get_client(self.base_url)
        resp = await client.post(f"/api/v1{path}", json=body, params=_strip_none(params), headers=self._headers, timeout=30)
        return _handle_response(resp)

    async def patch(self, path: str, body: dict[str, Any] | None = None) -> dict[str, Any]:
        client = _get_client(self.base_url)
        resp = await client.patch(f"/api/v1{path}", json=body, headers=self._headers, timeout=60)
        return _handle_response(resp)

    async def put(self, path: str, body: dict[str, Any] | None = None) -> dict[str, Any]:
        client = _get_client(self.base_url)
        resp = await client.put(f"/api/v1{path}", json=body, headers=self._headers, timeout=60)
        return _handle_response(resp)

    async def delete(
        self,
        path: str,
        params: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        client = _get_client(self.base_url)
        resp = await client.delete(
            f"/api/v1{path}",
            params=_strip_none(params),
            headers=self._headers,
            timeout=30,
        )
        return _handle_response(resp)


def _strip_none(params: dict[str, Any] | None) -> dict[str, Any] | None:
    if params is None:
        return None
    return {k: v for k, v in params.items() if v is not None}


def _handle_response(resp: httpx.Response) -> dict[str, Any]:
    if resp.status_code == 401:
        raise G8ClientError(401, "Invalid API key. Check G8_API_KEY or generate a new one at https://app.graph8.com/settings/api-keys")
    if resp.status_code == 403:
        raise G8ClientError(403, "Access denied. Your API key may not have permission for this operation.")
    if resp.status_code == 404:
        # Surface the backend's `detail` (e.g. "Sequence documents not found")
        # so the LLM can self-diagnose instead of always seeing the generic
        # "Resource not found" wrapper. Mirrors the 409 branch below.
        # Defensive: only use values that are real non-empty strings so a
        # bare MagicMock (in tests) or non-dict JSON body stays on fallback.
        msg = "Resource not found. Check the ID and try again."
        try:
            body = resp.json()
            if isinstance(body, dict):
                for key in ("message", "detail", "error"):
                    val = body.get(key)
                    if isinstance(val, str) and val:
                        msg = val
                        break
        except Exception:
            text = getattr(resp, "text", "")
            if isinstance(text, str) and text:
                msg = text
        raise G8ClientError(404, str(msg))
    if resp.status_code == 409:
        try:
            body = resp.json()
            msg = body.get("message") or body.get("detail") or body.get("error") or "A record with these parameters already exists."
        except Exception:
            msg = resp.text or "A record with these parameters already exists."
        raise G8ClientError(409, str(msg))
    if resp.status_code == 429:
        raise G8ClientError(429, "Rate limit exceeded. Wait a moment and try again.")
    if resp.status_code >= 400:
        try:
            body = resp.json()
            msg = body.get("message") or body.get("detail") or body.get("error") or resp.text
        except Exception:
            msg = resp.text
        raise G8ClientError(resp.status_code, f"API error ({resp.status_code}): {msg}")
    try:
        return resp.json()
    except Exception:
        return {"data": resp.text}


def format_result(data: Any) -> str:
    """Format API response data as readable JSON for the agent."""
    if isinstance(data, dict) and "data" in data:
        return json.dumps(data["data"], indent=2, default=str)
    return json.dumps(data, indent=2, default=str)


def _format_error(e: G8ClientError, context: str = "", *, key_suffix: str = "") -> str:
    """Convert a G8ClientError into a user-friendly message for MCP tool output."""
    if e.status_code == 401:
        suffix_part = f" (key=...{key_suffix})" if key_suffix else ""
        return (
            f"Error: Your API key is invalid or expired{suffix_part}. "
            "The cached key has been cleared - please retry your request once. "
            "If the error persists, reconnect graph8 in your Connectors settings "
            "or generate a new key at https://app.graph8.com/settings/api"
        )
    if e.status_code == 402:
        msg = str(e)
        return (
            f"Error: Insufficient credits. {msg}\n\n"
            "Purchase more at https://app.graph8.com/settings/billing"
        )
    if e.status_code == 403:
        return (
            "Error: Your account doesn't have permission for this operation. "
            "Check your plan at https://app.graph8.com/settings/billing"
        )
    if e.status_code == 404:
        # Prefer the real backend detail when present - generic messages
        # like "Resource not found" hide root causes (e.g. the campaign
        # exists but its sequence stubs don't). Fall back to the friendly
        # contextual wrapper only when the body was empty or generic.
        resource = context or "Resource"
        detail = str(e).strip()
        generic = {
            "Resource not found. Check the ID and try again.",
            "Resource not found.",
            "Resource not found",
            "",
        }
        if detail and detail not in generic:
            return f"Error: {resource}: {detail}"
        return f"Error: {resource} not found. Please check the ID and try again."
    if e.status_code == 409:
        msg = str(e)
        return (
            f"Error: Conflict - a record with these parameters already exists. {msg} "
            "Fetch the existing record or choose different parameters."
        )
    if e.status_code == 422:
        msg = str(e)
        return f"Error: Invalid request parameters. {msg}"
    if e.status_code == 429:
        return "Error: Rate limit exceeded. Please wait a moment and try again."
    if e.status_code >= 500:
        # Surface the backend detail (e.g. a Pydantic ValidationError that escaped
        # as a 500 due to missing try/except) instead of always masking. Falls
        # back to the friendly generic message when the response body is empty.
        msg = str(e)
        prefix = f"API error ({e.status_code}): "
        detail = msg[len(prefix):].strip() if msg.startswith(prefix) else msg.strip()
        if detail:
            return (
                f"Error: graph8 backend returned {e.status_code}. {detail}\n"
                "If this looks transient, retry in a moment."
            )
        return "Error: graph8 is temporarily unavailable. Please try again in a moment."
    return f"Error: {str(e)}"


async def safe_call(coro, *, context: str = "") -> str:
    """Wrap an API coroutine with user-friendly error handling.

    Use this in MCP tool functions instead of raw client calls:
        return await safe_call(client.get("/contacts", params), context="Contact search")

    On 401 from the backend in MCP/OAuth mode, this also invalidates the
    Redis-cached api_key (and its reverse mappings) so the next request
    provisions a fresh key from PropelAuth - preventing the "stuck with a
    revoked key for 14 days" failure mode.
    """
    try:
        result = await coro
        return format_result(result)
    except G8ClientError as e:
        key_suffix = await _maybe_invalidate_on_401(e)
        return _format_error(e, context, key_suffix=key_suffix)


async def safe_call_typed(
    coro,
    build: Callable[[Any], ModelT],
    *,
    context: str = "",
) -> ModelT | str:
    """Typed sibling of safe_call - returns a Pydantic model on success, error string on failure.

    FastMCP treats a `ModelT | str` return annotation as a union output schema:
    clients see a real `outputSchema` for the success branch and a string for
    errors. This lets tools migrate to structured output without changing their
    error contract.

    `build` is a callable that turns the raw response dict into the model
    (usually `ModelCls.from_envelope`). If the backend shape drifts and the
    build fails with a `ValidationError`, we fall back to the string formatter
    so the call does not blow up; the error is logged for observability.
    """
    try:
        raw = await coro
    except G8ClientError as e:
        key_suffix = await _maybe_invalidate_on_401(e)
        return _format_error(e, context, key_suffix=key_suffix)

    try:
        return build(raw)
    except ValidationError as ve:
        logger.warning(
            "safe_call_typed: model build failed, falling back to string. context=%s errors=%s",
            context,
            ve.errors(),
        )
        return format_result(raw)
    except Exception as exc:  # pragma: no cover - defensive
        logger.exception("safe_call_typed: unexpected build error context=%s", context)
        return f"Error: failed to parse response ({exc!s})"


async def _maybe_invalidate_on_401(e: G8ClientError) -> str:
    """Shared 401-invalidation path for safe_call and safe_call_typed."""
    if e.status_code != 401:
        return ""
    try:
        # Lazy import to avoid circular dependency (server.py imports client.py).
        from g8_mcp_server.auth import get_api_key
        from g8_mcp_server.server import invalidate_cached_key

        stale_key = get_api_key()
        if not stale_key:
            return ""
        await invalidate_cached_key(stale_key)
        return stale_key[-4:] if len(stale_key) >= 4 else ""
    except Exception:
        # Cache invalidation is best-effort; never let it mask the original error
        return ""
