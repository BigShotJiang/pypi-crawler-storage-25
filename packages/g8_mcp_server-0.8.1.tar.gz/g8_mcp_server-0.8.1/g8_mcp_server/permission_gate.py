"""MCP server-side permission gate (Phase D of access-controls plan).

The MCP server is a SEPARATE process from the main FastAPI backend. It
authenticates callers via PropelAuth API keys and dispatches to ~105
registered tools. Phase D adds a per-tool permission check BEFORE tool
dispatch so that the same role-based access controls that gate the web
app also gate MCP tool calls.

Architecture:
  MCP server ASGI middleware → check_mcp_tool_permission_for_request()
  → HTTP GET /campaign-builder/v1/auth/api-key-permissions on the backend
  → backend returns the permission set for the API key user
  → gate decides allow/deny based on shared/access/mcp_tool_permissions.py

  NOTE on the URL prefix: the api_key_auth router is mounted on the
  `/campaign-builder` prefix via cb_router (see main.py - the same prefix
  voice/graph8_livekit/dependencies/rbac.py already uses). Calling
  `/v1/auth/api-key-permissions` without the prefix returns 404 and falls
  through to the fail-closed branch, which silently deny-all's in strict
  mode and floods would_have_denied spam in soak mode. Always include
  `/campaign-builder/` in the path.

Cache:
  Permissions are cached for 60s per API key fingerprint. A permission
  change in the role editor takes effect within 60s on the MCP side.

Soak mode (`ENFORCE_MCP_PERMISSIONS=false`, default):
  Log "would_have_denied" entries but allow the request. Lets ops verify
  the gate works before flipping the kill switch.

Strict mode:
  Deny missing permissions with a structured JSON-RPC error.
"""

from __future__ import annotations

import hashlib
import logging
import os
import time
from typing import Optional

import httpx

logger = logging.getLogger(__name__)
audit_logger = logging.getLogger("graph8.mcp.audit")


# In-process cache: api_key_fingerprint -> (permissions, org_role, expires_at).
# We intentionally cache by api_key fingerprint (not user_id) since the MCP
# server doesn't always have the user_id at gate time - only the bearer
# token from the request.
_PERM_CACHE: dict[str, tuple[set[str], Optional[str], float]] = {}
_CACHE_TTL_SECONDS = 60
_FEATURE_FLAG_ENV = "ENFORCE_MCP_PERMISSIONS"


def _strict_mode() -> bool:
    raw = os.getenv(_FEATURE_FLAG_ENV, "0").strip().lower()
    return raw in {"1", "true", "yes", "on"}


def _backend_base_url() -> str:
    return os.getenv("GRAPH8_BACKEND_URL", "http://localhost:8000").rstrip("/")


def _api_key_fingerprint(api_key: str) -> str:
    return hashlib.sha256(api_key.encode()).hexdigest()[:32]


async def _fetch_permissions(api_key: str) -> tuple[set[str], Optional[str]]:
    """Fetch the user's permissions for this API key from the backend.

    Returns (permission_set, org_role). org_role is the PropelAuth role
    ("Owner", "Admin", "Member") - Owner/Admin still bypass per-tool
    checks via `check_mcp_tool_permission`.

    On any failure (network error, 5xx) we fall back to (empty set, None)
    so the gate defaults to deny in strict mode (fail-closed). In soak
    mode the missing perms just produce a "would_have_denied" log entry.
    """
    fp = _api_key_fingerprint(api_key)
    cached = _PERM_CACHE.get(fp)
    if cached is not None:
        perms, role, expires_at = cached
        if time.monotonic() < expires_at:
            return set(perms), role
        _PERM_CACHE.pop(fp, None)

    try:
        # MBM review #7202: the api_key_auth router lives under the
        # /campaign-builder prefix (cb_router in main.py). Without the
        # prefix this call 404s and we fail-closed silently in strict
        # mode, which looks like a permissions bug but is actually a
        # routing bug. voice/graph8_livekit/dependencies/rbac.py already
        # uses the correct prefix - match it here.
        url = f"{_backend_base_url()}/campaign-builder/v1/auth/api-key-permissions"
        async with httpx.AsyncClient(timeout=10.0) as client:
            resp = await client.get(
                url,
                headers={"Authorization": f"Bearer {api_key}"},
            )
            if resp.status_code != 200:
                logger.warning(
                    "mcp_permission_gate: backend returned %s when fetching perms",
                    resp.status_code,
                )
                return set(), None
            body = resp.json()
            perms = set(body.get("permissions") or [])
            org_role = body.get("org_role")
            _PERM_CACHE[fp] = (perms, org_role, time.monotonic() + _CACHE_TTL_SECONDS)
            return perms, org_role
    except Exception:
        logger.exception("mcp_permission_gate: failed to fetch permissions")
        return set(), None


# Re-export the shared map + spec so the MCP server can import a single module
try:
    from shared.access.mcp_tool_permissions import (  # noqa: F401
        MCP_TOOL_PERMISSIONS,
        ToolPermissionSpec,
        get_tool_spec,
    )
    _HAS_SHARED_MAP = True
except ImportError:
    # MCP server may be deployed without the main `shared/` package on
    # PYTHONPATH (separate container). In that case we ship an inline
    # fallback map - minimal but covers the critical tools.
    _HAS_SHARED_MAP = False
    logger.warning(
        "mcp_permission_gate: shared.access.mcp_tool_permissions not "
        "importable; using minimal inline tool map. Phase D enforcement "
        "will only cover critical tools."
    )

    class ToolPermissionSpec:  # type: ignore[no-redef]
        def __init__(self, any_of=None, extra_required=None, is_critical=False):
            self.any_of = any_of or []
            self.extra_required = extra_required or []
            self.is_critical = is_critical

    # Minimal inline map - extend if shared/ import fails in your env.
    MCP_TOOL_PERMISSIONS: dict[str, ToolPermissionSpec] = {  # type: ignore[no-redef]
        "g8_voice_create_dialer_session": ToolPermissionSpec(
            any_of=["voice:dialer:create"], is_critical=True,
        ),
        "g8_voice_stop_session": ToolPermissionSpec(
            any_of=["voice:dialer:control"], is_critical=True,
        ),
        "g8_gtm_launch_campaign": ToolPermissionSpec(
            any_of=["campaigns:write:own", "campaigns:write:team", "campaigns:write:all"],
            extra_required=["campaigns:launch"], is_critical=True,
        ),
    }

    def get_tool_spec(name):  # type: ignore[no-redef]
        return MCP_TOOL_PERMISSIONS.get(name)


def _is_privileged_org_role(org_role: Optional[str]) -> bool:
    if not org_role:
        return False
    return org_role.strip().lower() in {"owner", "admin"}


async def check_tool_permission_async(
    *,
    api_key: str,
    tool_name: str,
) -> tuple[bool, str]:
    """Check whether the api_key holder can invoke `tool_name`.

    Returns (allowed, reason). In soak mode, allowed is always True and
    `reason` may be "would_have_denied:...". In strict mode, allowed reflects
    the actual decision.

    Designed to be called from the MCP server's ASGI middleware right
    before forwarding `tools/call` requests to the FastMCP handler.
    """
    strict = _strict_mode()
    perms, org_role = await _fetch_permissions(api_key)

    # Owner/Admin bypass
    if _is_privileged_org_role(org_role):
        _audit(tool_name, allowed=True, reason="privileged_org_role",
               api_key=api_key, is_critical=False, strict=strict)
        return True, "privileged_org_role"

    spec = get_tool_spec(tool_name)
    if spec is None:
        # Unknown tool - soft-fail in soak, hard-deny in strict.
        reason = "unknown_tool"
        if strict:
            _audit(tool_name, allowed=False, reason=reason, api_key=api_key,
                   is_critical=True, strict=True)
            return False, reason
        _audit(tool_name, allowed=True, reason=reason, api_key=api_key,
               is_critical=False, strict=False)
        return True, reason

    missing_any: list[str] = []
    if spec.any_of:
        if not any(p in perms for p in spec.any_of):
            missing_any = list(spec.any_of)
    missing_required = [p for p in spec.extra_required if p not in perms]

    if missing_any or missing_required:
        detail_parts = []
        if missing_any:
            detail_parts.append("any-of:" + ",".join(sorted(missing_any)))
        if missing_required:
            detail_parts.append("required:" + ",".join(sorted(missing_required)))
        detail = " ".join(detail_parts)
        if strict:
            _audit(tool_name, allowed=False, reason=f"missing_permission {detail}",
                   api_key=api_key, is_critical=spec.is_critical, strict=True)
            return False, f"missing_permission {detail}"
        _audit(tool_name, allowed=True, reason=f"would_have_denied {detail}",
               api_key=api_key, is_critical=spec.is_critical, strict=False)
        return True, f"would_have_denied {detail}"

    _audit(tool_name, allowed=True, reason="granted",
           api_key=api_key, is_critical=spec.is_critical, strict=strict)
    return True, "granted"


def _audit(
    tool_name: str,
    *,
    allowed: bool,
    reason: str,
    api_key: str,
    is_critical: bool,
    strict: bool,
) -> None:
    fp = _api_key_fingerprint(api_key)[:10]
    payload = {
        "tool": tool_name,
        "key_fp": fp,
        "allowed": allowed,
        "reason": reason,
        "is_critical": is_critical,
        "strict_mode": strict,
    }
    if is_critical or not allowed or "would_have_denied" in reason:
        audit_logger.warning("mcp_tool_dispatch %s", payload)
    else:
        audit_logger.debug("mcp_tool_dispatch %s", payload)


def build_denial_response(tool_name: str, reason: str) -> dict:
    """JSON-RPC-compatible error response the dispatcher returns on deny."""
    return {
        "error": {
            "code": -32603,
            "message": f"Permission denied for tool '{tool_name}'",
            "data": {
                "tool_name": tool_name,
                "reason": reason,
            },
        }
    }


def invalidate_cache(api_key: Optional[str] = None) -> None:
    """Force-evict cached permissions for a key, or flush all."""
    if api_key is None:
        _PERM_CACHE.clear()
        return
    _PERM_CACHE.pop(_api_key_fingerprint(api_key), None)
