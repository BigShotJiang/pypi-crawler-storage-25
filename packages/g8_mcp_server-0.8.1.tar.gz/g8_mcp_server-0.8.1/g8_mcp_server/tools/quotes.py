"""Quotes tools - quote-to-cash surface for the developer API.

Twelve tools covering quote lifecycle and the supporting catalog reads:

  Read:        g8_list_quotes, g8_get_quote, g8_list_quotable_products,
               g8_get_quote_settings, g8_get_company_quotes,
               g8_get_contact_quotes
  Write:       g8_create_quote, g8_update_quote, g8_duplicate_quote,
               g8_edit_quote_as_draft
  Destructive: g8_send_quote (sends email; idempotent for resend),
               g8_delete_quote (drafts only, server-enforced)

All paths proxy ``/api/v1/quotes*`` on the developer API which is itself a
thin wrapper over the internal ``/stripe/v4`` quote router (see
``developer_api/interfaces/v1/quotes_router.py``). The internal router
enforces:

  - draft-only updates / deletes (400 on any other status)
  - signer requirement (signer_contact_id or signer_email)
  - quotable-product authorization (line items must reference org-quotable
    Stripe products or org-owned manual catalogue entries)
  - idempotent send (existing sent/viewed envelope is re-emailed without
    minting a new signing link)

Mirrors the deals tool pattern in ``platform.py`` (annotations, helper
``safe_call_typed``, body builder).
"""

from __future__ import annotations

from typing import Any

from mcp.server import FastMCP
from mcp.types import ToolAnnotations

from g8_mcp_server.client import G8Client, safe_call_typed
from g8_mcp_server.models import (
    ActionResult,
    QuotableProductsResult,
    QuotesResult,
    ResourceDetail,
)
from g8_mcp_server.ui_apps import ui_tool_meta

_READ_ONLY = ToolAnnotations(readOnlyHint=True, idempotentHint=True)
_WRITE = ToolAnnotations(
    readOnlyHint=False, destructiveHint=False, idempotentHint=False, openWorldHint=True
)
_DESTRUCTIVE = ToolAnnotations(destructiveHint=True, openWorldHint=True)


def register(server: FastMCP, client: G8Client) -> None:
    """Register quote tools on the MCP server."""

    # ------------------------------------------------------------------ Reads

    @server.tool(
        annotations=_READ_ONLY,
        meta=ui_tool_meta("ui://quotes/list"),
    )
    async def g8_list_quotes(
        page: int = 1,
        limit: int = 50,
        status: str | None = None,
        mashup_company_id: int | None = None,
        deal_id: str | None = None,
        owner_id: str | None = None,
    ) -> QuotesResult | str:
        """List quotes in your org with optional status / company / deal / owner filters.

        Args:
            page: 1-indexed page (default 1).
            limit: Rows per page (default 50, max 200).
            status: Filter by lifecycle stage. One of: ``draft``, ``sent``,
                ``viewed``, ``accepted``, ``declined``, ``voided``,
                ``expired``. Omit to list every status.
            mashup_company_id: Restrict to quotes attached to one company
                (mashup_companies.id, integer).
            deal_id: Restrict to quotes linked to one deal (UUID string).
            owner_id: Restrict to quotes owned by one user (email).
        """
        return await safe_call_typed(
            client.get(
                "/quotes",
                {
                    "page": page,
                    "limit": limit,
                    "status": status,
                    "mashup_company_id": mashup_company_id,
                    "deal_id": deal_id,
                    "owner_id": owner_id,
                },
            ),
            QuotesResult.from_envelope,
            context="Quotes list",
        )

    @server.tool(
        annotations=_READ_ONLY,
        meta=ui_tool_meta("ui://quotes/detail"),
    )
    async def g8_get_quote(quote_id: str) -> ResourceDetail | str:
        """Get full quote detail: line items, activity log, envelope tracking, totals.

        Returns the canonical CBQuote row plus the resolved contact/company
        names, the nested ``line_items`` list, the chronological ``activity``
        log, and the linked signing ``envelope`` block (status / signing URL
        / recipient).

        Args:
            quote_id: Quote UUID returned by g8_list_quotes / g8_create_quote.
        """
        return await safe_call_typed(
            client.get(f"/quotes/{quote_id}"),
            ResourceDetail.from_envelope,
            context="Quote",
        )

    @server.tool(annotations=_READ_ONLY)
    async def g8_list_quotable_products(
        currency: str | None = None,
        page: int = 1,
        limit: int = 100,
    ) -> QuotableProductsResult | str:
        """List products available for quote line items (Stripe + org manual catalog).

        Use this before ``g8_create_quote`` / ``g8_update_quote`` to discover
        which ``stripe_product_id`` + ``stripe_price_id`` pairs (or
        ``manual_product_id`` values) the org may put on a quote. Non-quotable
        products are rejected server-side at create/update time.

        Each row's ``source`` field tells you which id family to use:
          - ``stripe``: pass ``stripe_product_id`` + ``stripe_price_id``
          - ``manual``: pass ``manual_product_id``

        Args:
            currency: Optional 3-letter currency filter (e.g. ``USD``) -
                drops prices not denominated in this currency.
            page: 1-indexed page (default 1).
            limit: Rows per page (default 100, max 500).
        """
        return await safe_call_typed(
            client.get(
                "/quotable-products",
                {"currency": currency, "page": page, "limit": limit},
            ),
            QuotableProductsResult.from_envelope,
            context="Quotable products",
        )

    @server.tool(annotations=_READ_ONLY)
    async def g8_get_quote_settings() -> ResourceDetail | str:
        """Get org-level quote settings (branding, default terms, sender identity).

        Auto-creates default settings if none exist for the org. Useful to
        confirm the org's quote sender name / email / default
        payment-terms / default valid_until window before sending.
        """
        return await safe_call_typed(
            client.get("/quote-settings"),
            ResourceDetail.from_envelope,
            context="Quote settings",
        )

    @server.tool(annotations=_READ_ONLY)
    async def g8_get_company_quotes(company_id: int) -> dict:
        """List every quote attached to a given company (account view).

        Args:
            company_id: MashupCompany ID (integer).
        """
        envelope = await client.get(f"/companies/{company_id}/quotes")
        # The /companies/{id}/quotes endpoint returns a flat list under
        # ApiResponse.data - surface it unchanged so the agent can read the
        # field names directly. Mirrors g8_get_company_deals' shape.
        data = envelope.get("data", []) if isinstance(envelope, dict) else []
        if not isinstance(data, list):
            data = []
        return {"quotes": data, "total": len(data)}

    @server.tool(annotations=_READ_ONLY)
    async def g8_get_contact_quotes(contact_id: int) -> dict:
        """List quotes where this contact is the signer.

        Args:
            contact_id: MashupContact ID (integer).
        """
        envelope = await client.get(f"/contacts/{contact_id}/quotes")
        data = envelope.get("data", []) if isinstance(envelope, dict) else []
        if not isinstance(data, list):
            data = []
        return {"quotes": data, "total": len(data)}

    # ----------------------------------------------------------------- Writes

    @server.tool(annotations=_WRITE)
    async def g8_create_quote(
        title: str,
        line_items: list[dict[str, Any]],
        signer_contact_id: int | None = None,
        signer_email: str | None = None,
        signer_name: str | None = None,
        billing_contact_id: int | None = None,
        mashup_company_id: int | None = None,
        deal_id: str | None = None,
        template_id: str | None = None,
        currency: str = "USD",
        payment_terms: str = "net_30",
        valid_until: str | None = None,
        terms_content: str | None = None,
        privacy_content: str | None = None,
        notes: str | None = None,
        public_notes: str | None = None,
        tax_amount: int = 0,
        contract_months: int | None = None,
        contract_start_date: str | None = None,
        contract_end_date: str | None = None,
        accepted_payment_methods: list[str] | None = None,
        marketing_rights: list[str] | None = None,
    ) -> ActionResult | str:
        """Create a new quote in `draft` status. Always creates, never sends.

        At least one of ``signer_contact_id`` or ``signer_email`` is required.
        ``line_items`` must be non-empty - zero-line quotes can't be invoiced.

        Each line item is a dict with the same shape ``g8_list_quotable_products``
        suggests:
          - ``stripe_product_id`` + ``stripe_price_id`` (Stripe catalogue), OR
          - ``manual_product_id`` (org manual catalogue), OR
          - neither (custom one-off line)
          - ``product_name`` (required), ``description``, ``quantity``,
            ``unit_amount`` (cents), ``discount_pct``, ``billing_frequency``,
            ``sort_order``

        Args:
            title: Quote title (1-500 chars).
            line_items: Non-empty list of line-item dicts.
            signer_contact_id: Contact id of the e-signature recipient.
            signer_email: Direct email for the signer (used if signer_contact_id is omitted).
            signer_name: Display name to render on the quote.
            billing_contact_id: Optional separate billing contact id.
            mashup_company_id: Company the quote is for.
            deal_id: Deal UUID the quote should attach to.
            template_id: Optional quote-settings template id for branding.
            currency: 3-letter ISO currency, default USD.
            payment_terms: One of due_on_receipt / net_15 / net_30 / net_45 / net_60 / net_90.
            valid_until: ISO date for quote expiration.
            terms_content: Inline terms markdown (capped at 50k chars).
            privacy_content: Inline privacy markdown (capped at 50k chars).
            notes: Private notes (capped at 10k chars).
            public_notes: Public notes shown to signer (capped at 10k chars).
            tax_amount: Total tax in cents (default 0).
            contract_months: Subscription length 1-120 months.
            contract_start_date / contract_end_date: ISO dates for contract window.
            accepted_payment_methods: Any subset of [ach, credit_card, wire].
            marketing_rights: Any subset of [logo, quote, case_study].
        """
        body: dict[str, Any] = {
            key: value
            for key, value in {
                "title": title,
                "line_items": line_items,
                "signer_contact_id": signer_contact_id,
                "signer_email": signer_email,
                "signer_name": signer_name,
                "billing_contact_id": billing_contact_id,
                "mashup_company_id": mashup_company_id,
                "deal_id": deal_id,
                "template_id": template_id,
                "currency": currency,
                "payment_terms": payment_terms,
                "valid_until": valid_until,
                "terms_content": terms_content,
                "privacy_content": privacy_content,
                "notes": notes,
                "public_notes": public_notes,
                "tax_amount": tax_amount,
                "contract_months": contract_months,
                "contract_start_date": contract_start_date,
                "contract_end_date": contract_end_date,
                "accepted_payment_methods": accepted_payment_methods,
                "marketing_rights": marketing_rights,
            }.items()
            if value is not None
        }
        return await safe_call_typed(
            client.post("/quotes", body),
            ActionResult.from_envelope,
            context="Quote creation",
        )

    @server.tool(annotations=_WRITE)
    async def g8_update_quote(
        quote_id: str,
        title: str | None = None,
        line_items: list[dict[str, Any]] | None = None,
        signer_contact_id: int | None = None,
        signer_email: str | None = None,
        signer_name: str | None = None,
        billing_contact_id: int | None = None,
        mashup_company_id: int | None = None,
        deal_id: str | None = None,
        currency: str | None = None,
        payment_terms: str | None = None,
        valid_until: str | None = None,
        terms_content: str | None = None,
        privacy_content: str | None = None,
        notes: str | None = None,
        public_notes: str | None = None,
        tax_amount: int | None = None,
        contract_months: int | None = None,
        contract_start_date: str | None = None,
        contract_end_date: str | None = None,
        accepted_payment_methods: list[str] | None = None,
        marketing_rights: list[str] | None = None,
    ) -> ActionResult | str:
        """Update a draft quote (partial). 400s on any non-draft status.

        Pass only the fields you want to change. Passing ``line_items``
        replaces the entire set (and re-runs quotable-product authorization).
        For sent quotes use ``g8_edit_quote_as_draft`` to get a fresh editable
        copy; for terminal quotes use ``g8_duplicate_quote``.

        Args: see ``g8_create_quote`` - same field meanings.
        """
        body = {
            key: value
            for key, value in {
                "title": title,
                "line_items": line_items,
                "signer_contact_id": signer_contact_id,
                "signer_email": signer_email,
                "signer_name": signer_name,
                "billing_contact_id": billing_contact_id,
                "mashup_company_id": mashup_company_id,
                "deal_id": deal_id,
                "currency": currency,
                "payment_terms": payment_terms,
                "valid_until": valid_until,
                "terms_content": terms_content,
                "privacy_content": privacy_content,
                "notes": notes,
                "public_notes": public_notes,
                "tax_amount": tax_amount,
                "contract_months": contract_months,
                "contract_start_date": contract_start_date,
                "contract_end_date": contract_end_date,
                "accepted_payment_methods": accepted_payment_methods,
                "marketing_rights": marketing_rights,
            }.items()
            if value is not None
        }
        if not body:
            return "Error: pass at least one field to update."
        return await safe_call_typed(
            client.put(f"/quotes/{quote_id}", body),
            ActionResult.from_envelope,
            context="Quote update",
        )

    @server.tool(annotations=_WRITE)
    async def g8_duplicate_quote(quote_id: str) -> ActionResult | str:
        """Clone any quote into a new draft. Title gets a ``(Copy)`` suffix.

        Works on quotes in any status (draft, sent, accepted, voided, ...).
        Useful for renewals or recreating an expired quote without retyping
        every line item.

        Args:
            quote_id: Source quote UUID.
        """
        return await safe_call_typed(
            client.post(f"/quotes/{quote_id}/duplicate", {}),
            ActionResult.from_envelope,
            context="Quote duplicate",
        )

    @server.tool(annotations=_WRITE)
    async def g8_edit_quote_as_draft(quote_id: str) -> ActionResult | str:
        """Convert a sent quote back into an editable draft via void+clone.

        Side effects: voids the existing signing envelope (recipient's link
        stops resolving), marks the source ``voided``, and creates a fresh
        ``draft`` copy with line items preserved. Use this when a recipient
        needs revised pricing / terms on an already-sent quote without
        starting from scratch.

        Returns the new ``quote_id`` to operate on next.

        Args:
            quote_id: Source quote UUID (must be in ``sent`` status).
        """
        return await safe_call_typed(
            client.post(f"/quotes/{quote_id}/edit-as-draft", {}),
            ActionResult.from_envelope,
            context="Quote edit-as-draft",
        )

    # ------------------------------------------------------------ Destructive

    @server.tool(annotations=_DESTRUCTIVE)
    async def g8_send_quote(
        quote_id: str,
        subject: str | None = None,
        message: str | None = None,
    ) -> ActionResult | str:
        """Send (or resend) a quote for e-signature. Sends a real email.

        Side effects: creates / reuses a signing envelope, sends the
        customer-facing email via SES, logs to the universal inbox, and rolls
        the quote status forward to ``sent``. Recipient is resolved from the
        quote's ``signer_contact_id`` or ``signer_email`` (one must be set).

        Idempotent for resend: when the quote already has an envelope in
        ``sent`` or ``viewed`` state, the existing envelope is re-emailed and
        the recipient keeps the original signing link. Safe to call twice -
        the second call does not create a new envelope or new link.

        Args:
            quote_id: Quote UUID (must be in draft or sent status).
            subject: Optional override for the email subject (falls back to
                the quote title).
            message: Optional override for the email body cover line (falls
                back to the default template).
        """
        body: dict[str, Any] = {}
        if subject is not None:
            body["subject"] = subject
        if message is not None:
            body["message"] = message
        return await safe_call_typed(
            client.post(f"/quotes/{quote_id}/send", body),
            ActionResult.from_envelope,
            context="Quote send",
        )

    @server.tool(annotations=_DESTRUCTIVE)
    async def g8_delete_quote(quote_id: str) -> ActionResult | str:
        """Delete a draft quote. Irreversible. 400s on any non-draft status.

        Sent / accepted / voided quotes are preserved as legal records and
        cannot be hard-deleted - use ``g8_edit_quote_as_draft`` or
        ``g8_duplicate_quote`` instead.

        Args:
            quote_id: Quote UUID (must be in ``draft`` status).
        """
        return await safe_call_typed(
            client.delete(f"/quotes/{quote_id}"),
            ActionResult.from_envelope,
            context="Quote deletion",
        )
