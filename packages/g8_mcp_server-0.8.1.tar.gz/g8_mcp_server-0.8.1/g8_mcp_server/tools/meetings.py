"""Meetings tools - list calendar meetings and fetch transcripts.

Exposes two read-only tools:
  - g8_list_meetings: card-level meeting list with transcript preview.
    Supports filtering by participant (organizer + owner + attendees),
    timeframe, visibility scope, and transcript presence.
  - g8_get_meeting: single meeting with FULL transcript bundled inline,
    plus extracted topics, action items, and CRM tasks.

Both tools proxy /api/v1/inbox/meetings on the developer API, which
itself wraps ai_inbox.services.channels.ChannelsService meetings logic.
RBAC is enforced at the backend (meetings:see_all, meetings:see_transcripts)
based on the API key's bound user.
"""

from __future__ import annotations

from mcp.server import FastMCP
from mcp.types import ToolAnnotations

from g8_mcp_server.client import G8Client, safe_call_typed
from g8_mcp_server.models import MeetingDetail, MeetingListResult
from g8_mcp_server.ui_apps import ui_tool_meta

_READ_ONLY = ToolAnnotations(readOnlyHint=True, idempotentHint=True)

# Hard cap on page_size for g8_list_meetings. claude.ai's MCP Apps host
# silently writes tool results > ~150,000 chars to the sandbox filesystem
# (for the model to grep) and STOPS pushing structuredContent to the linked
# widget via ontoolresult - which leaves the widget stuck on "Loading...".
# Each MeetingSummary row averages ~3 KB once transcript_summary is stripped
# (see _strip_summary_previews below), so 25 rows keeps the on-wire payload
# comfortably under the threshold even with attendee-heavy meetings. Callers
# requesting more get clamped silently rather than erroring - the response
# shape is unchanged, just smaller, and `has_next`/`page` still let them
# paginate through the full set.
_LIST_PAGE_SIZE_CAP = 25


def register(server: FastMCP, client: G8Client) -> None:
    """Register meetings tools on the MCP server."""

    @server.tool(
        annotations=_READ_ONLY,
        # Drives ui://meetings/list - sortable card grid of meetings.
        meta=ui_tool_meta("ui://meetings/list"),
    )
    async def g8_list_meetings(
        email: str | None = None,
        contact_id: int | None = None,
        participant_emails: list[str] | None = None,
        scope: str | None = None,
        timeframe: str | None = None,
        has_transcript: bool | None = None,
        include_internal: bool | None = None,
        search: str | None = None,
        page: int = 1,
        page_size: int = 50,
    ) -> MeetingListResult | str:
        """List calendar meetings as compact summary cards.

        Use this for "show me meetings", "what meetings did X attend",
        or browsing the meeting inbox. Each card includes title, time,
        attendees, and transcript status. Call g8_get_meeting(meeting_id)
        to read the transcript summary and full transcript body - they
        are intentionally omitted from list rows to keep the response
        compact (claude.ai's MCP widget host drops oversized payloads
        from the widget pipeline).

        Filter to a specific person's meetings by passing `email`,
        `contact_id`, or `participant_emails`. The match is across
        organizer + owner + attendees (case-insensitive, OR-matched).

        Args:
            email: Single email - filter to meetings where this person
                appears as organizer, owner, or attendee.
            contact_id: CRM contact ID - resolved to the contact's work
                email and used as the participant filter. Combine with
                `email` to broaden (OR-matched).
            participant_emails: Explicit list of emails to match (OR).
                Use when the caller already knows multiple emails.
            scope: 'my' (your meetings, default) or 'all' (org-wide,
                requires meetings:see_all permission).
            timeframe: 'all', 'upcoming', or 'past' (default 'past').
            has_transcript: True = only meetings with a linked
                transcript. False = only meetings without. Omit for all.
            include_internal: True = include internal-only meetings
                (team syncs, standups, all-attendees-same-domain). False
                or omit = follow the org policy default (most orgs
                exclude internal). Pass True when the user asks to see
                team meetings, Roam syncs, internal standups, or 1:1s
                between teammates - the default would silently drop
                them.
            search: Match against meeting title or transcript text.
            page: Page number (default 1).
            page_size: Items per page (default 50, max 100). Internally
                clamped to 25 so the response fits under claude.ai's MCP
                widget payload ceiling - larger requests would silently
                leave the linked meetings widget stuck on "Loading...".
                Use `page` to walk through more rows.
        """
        # Clamp to keep the structuredContent payload under the claude.ai
        # MCP host's ~150 KB widget threshold. See _LIST_PAGE_SIZE_CAP.
        if page_size > _LIST_PAGE_SIZE_CAP:
            page_size = _LIST_PAGE_SIZE_CAP
        # Build the participant filter list from any combination of
        # contact_id / email / participant_emails. Contact resolution is
        # a single extra GET, kept lazy so callers who pass email alone
        # avoid the round-trip.
        emails_filter: list[str] = []
        if participant_emails:
            emails_filter.extend(
                e.strip() for e in participant_emails if isinstance(e, str) and e.strip()
            )
        if email and isinstance(email, str) and email.strip():
            emails_filter.append(email.strip())
        if contact_id is not None:
            try:
                contact_envelope = await client.get(f"/contacts/{contact_id}")
            except Exception:
                contact_envelope = None
            resolved_email = _extract_contact_email(contact_envelope)
            if resolved_email:
                emails_filter.append(resolved_email)

        # De-dupe (case-insensitive) while preserving order.
        seen: set[str] = set()
        deduped: list[str] = []
        for e in emails_filter:
            key = e.lower()
            if key in seen:
                continue
            seen.add(key)
            deduped.append(e)

        # Boolean -> enum string mapping. None / False -> no-op (backend
        # falls back to the org policy default, which is exclude_internal
        # for most orgs). True -> include_internal so internal-only
        # meetings (team syncs, Roam standups) are surfaced.
        internal_mode: str | None = "include_internal" if include_internal else None

        params: dict = {
            "scope": scope,
            "timeframe": timeframe,
            "has_transcript": has_transcript,
            "internal_mode": internal_mode,
            "search": search,
            "page": page,
            "page_size": page_size,
        }
        if deduped:
            # httpx encodes list values as repeated query params, matching
            # FastAPI's Query(list[str]) parsing on the backend.
            params["participant_email"] = deduped

        result = await safe_call_typed(
            client.get("/inbox/meetings", params),
            MeetingListResult.from_envelope,
            context="Meetings list",
        )
        # Strip the per-row transcript previews on success. They are the
        # dominant payload contributor (transcript_summary + its duplicate
        # `preview` average ~1.5 KB and ~3 KB respectively, with the worst
        # row at ~3.2 KB EACH) and push otherwise-modest list responses
        # past the widget threshold. The fields stay on the schema as
        # nullable strings, so any consumer that referenced them keeps
        # working - they just see None and call g8_get_meeting for the
        # full body. Error path (`result` is a str) is passed through
        # untouched.
        if isinstance(result, MeetingListResult):
            _strip_summary_previews(result)
        return result

    @server.tool(
        annotations=_READ_ONLY,
        # Drives ui://meetings/detail - full transcript + extractions view.
        meta=ui_tool_meta("ui://meetings/detail"),
    )
    async def g8_get_meeting(meeting_id: str) -> MeetingDetail | str:
        """Get a single meeting with FULL transcript bundled inline.

        Returns the meeting record plus the complete transcript body,
        summary, key topics, action items, CRM tasks, and custom-field
        extractions. When the caller is not a participant and lacks the
        meetings:see_transcripts permission, transcript content is
        redacted (the response sets transcript_redacted=true).

        Use this after g8_list_meetings has narrowed down a meeting id,
        or when the user asks for "this meeting" / "that meeting".

        Args:
            meeting_id: Meeting ID (CalendarEvent.id, string or integer
                form - the backend accepts both).
        """
        return await safe_call_typed(
            client.get(f"/inbox/meetings/{meeting_id}"),
            MeetingDetail.from_envelope,
            context="Meeting detail",
        )


def _strip_summary_previews(result: MeetingListResult) -> None:
    """Null out per-row transcript previews to keep the payload small.

    Mutates in place. Targets `transcript_summary` (the Haiku/Roam summary
    blob, 1-3 KB each) and `preview` (a backend-side duplicate of the same
    text, also 1-3 KB each). Together they account for the bulk of the list
    payload; nulling them keeps the schema intact (both stay `Optional[str]`)
    while letting g8_list_meetings respond well under claude.ai's MCP widget
    threshold. Callers that want the summary for a specific meeting should
    drill in via g8_get_meeting(meeting_id).
    """
    for m in result.meetings:
        m.transcript_summary = None
        m.preview = None


def _extract_contact_email(envelope) -> str | None:
    """Pull the most useful email off a contact envelope.

    Tolerates both ApiResponse-wrapped ({"data": {...}}) and bare-dict
    contact records. Prefers work_email, falls back to other email
    fields the backend may surface.
    """
    if not isinstance(envelope, dict):
        return None
    data = envelope.get("data") if "data" in envelope else envelope
    if not isinstance(data, dict):
        return None
    for key in ("work_email", "email", "CONTACT_WORK_EMAIL", "primary_email"):
        value = data.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    return None
