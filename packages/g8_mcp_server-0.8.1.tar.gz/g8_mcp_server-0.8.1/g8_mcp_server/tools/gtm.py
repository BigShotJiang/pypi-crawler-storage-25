"""GTM mode tools - org-scoped operations for campaign managers."""

from __future__ import annotations

from typing import Any

from mcp.server import FastMCP
from mcp.types import ToolAnnotations

from g8_mcp_server.client import G8Client, safe_call_typed
from g8_mcp_server.models import (
    ActionResult,
    AdImageHideResult,
    AdImagesResult,
    AttachAudienceResult,
    CampaignDocumentsResult,
    CampaignFullResult,
    CampaignIdeasResult,
    CampaignMetricsResult,
    CampaignSequenceResult,
    CampaignsResult,
    ConfirmationDetail,
    ConfirmationPreview,
    GlobalContextsResult,
    IcpsResult,
    IntelligenceDataResult,
    KBDocumentsResult,
    KBResult,
    MailboxesResult,
    MailboxWarmupResult,
    PersonasResult,
    ResearchReportsResult,
    ResourceDetail,
)
from g8_mcp_server.ui_apps import ui_tool_meta

_READ_ONLY = ToolAnnotations(readOnlyHint=True, idempotentHint=True)
# Campaign-builder creates/updates mutate draft state but don't launch
# outreach - _WRITE. `launch_campaign` and the `delete_*` siblings stay
# _DESTRUCTIVE because they either send real messages or remove records.
_WRITE = ToolAnnotations(
    readOnlyHint=False, destructiveHint=False, idempotentHint=False, openWorldHint=True
)
_DESTRUCTIVE = ToolAnnotations(destructiveHint=True, openWorldHint=True)


def register(server: FastMCP, client: G8Client, *, name_prefix: str = "") -> None:
    """Register GTM-mode tools.

    When ``name_prefix`` is provided, GTM tool names are namespaced to avoid
    collisions with dev-mode tools in combined `all` mode.
    """

    def tool_name(base_name: str) -> str:
        if name_prefix:
            return f"g8_{name_prefix}_{base_name}"
        return f"g8_{base_name}"

    @server.tool(
        name=tool_name("list_campaigns"),
        annotations=_READ_ONLY,
        # Link to the interactive dashboard App: MCP Apps-aware hosts will
        # fetch `ui://campaigns/dashboard` and render it inline whenever this
        # tool fires. Non-App clients still get the same structured result
        # as before  -  the `meta` is purely additive.
        meta=ui_tool_meta("ui://campaigns/dashboard"),
    )
    async def list_campaigns(page: int = 1, limit: int = 50) -> CampaignsResult | str:
        """List campaigns in your organization."""
        return await safe_call_typed(
            client.get("/campaigns", {"page": page, "limit": limit}),
            CampaignsResult.from_envelope,
            context="Campaign list",
        )

    @server.tool(
        name=tool_name("get_ad_images"),
        annotations=_READ_ONLY,
        # Drives the `ui://campaigns/ad-images` App: users see a grid of
        # creatives with a Hide action per card.
        meta=ui_tool_meta("ui://campaigns/ad-images"),
    )
    async def get_ad_images(campaign_id: str) -> AdImagesResult | str:
        """List ad image creatives for one campaign.

        Returns every ad image that hasn't been marked hidden. The
        result drives an interactive grid in MCP Apps-aware hosts and
        reads as a structured list elsewhere.
        """
        return await safe_call_typed(
            client.get(f"/campaigns/{campaign_id}/ad-images"),
            AdImagesResult.from_envelope,
            context="Campaign ad images",
        )

    @server.tool(
        name=tool_name("hide_ad_image"),
        # Idempotent "mark as hidden"  -  not destructive in the GDPR sense
        # (data is retained, just filtered out of listings). Not strictly
        # read-only either; classify as _WRITE.
        annotations=_WRITE,
        meta=ui_tool_meta("ui://campaigns/ad-images"),
    )
    async def hide_ad_image(campaign_id: str, image_id: str) -> AdImageHideResult | str:
        """Hide one ad creative from the campaign's grid.

        Sets `feedback='down'` on the underlying `cb_website_images` row so
        it drops out of future listings. Idempotent  -  hiding an
        already-hidden image is a no-op that still succeeds.
        """
        return await safe_call_typed(
            client.post(f"/campaigns/{campaign_id}/ad-images/{image_id}/hide", body={}),
            AdImageHideResult.from_envelope,
            context="Hide ad image",
        )

    @server.tool(name=tool_name("get_campaign"), annotations=_READ_ONLY)
    async def get_campaign(
        campaign_id: str,
        full: bool = False,
    ) -> ResourceDetail | CampaignFullResult | str:
        """Get campaign details. Optionally fetch the kitchen-sink payload.

        Default (``full=False``): mirrors prior behavior - returns just the
        campaign row + documents the way `GET /campaigns/{id}` does.

        ``full=True``: hits `GET /campaigns/{id}/full` and returns the
        kitchen-sink shape - campaign + audience + ALL documents (with
        content) + sequence + step_catalog + linked_sequences + is_launched -
        in a single round trip. Use this when an agent is about to edit a
        campaign and needs the full editable state without ping-ponging
        through `/documents` and `/sequence`.
        """
        if full:
            return await safe_call_typed(
                client.get(f"/campaigns/{campaign_id}/full"),
                CampaignFullResult.from_envelope,
                context="Campaign (full)",
            )
        return await safe_call_typed(
            client.get(f"/campaigns/{campaign_id}"),
            ResourceDetail.from_envelope,
            context="Campaign",
        )

    @server.tool(name=tool_name("list_campaign_documents"), annotations=_READ_ONLY)
    async def list_campaign_documents(campaign_id: str) -> CampaignDocumentsResult | str:
        """List document metadata for a campaign."""
        return await safe_call_typed(
            client.get(f"/campaigns/{campaign_id}/documents"),
            CampaignDocumentsResult.from_envelope,
            context="Campaign documents",
        )

    @server.tool(name=tool_name("get_campaign_document"), annotations=_READ_ONLY)
    async def get_campaign_document(campaign_id: str, document_id: str) -> ResourceDetail | str:
        """Get the full content of a campaign document."""
        return await safe_call_typed(
            client.get(f"/campaigns/{campaign_id}/documents/{document_id}"),
            ResourceDetail.from_envelope,
            context="Campaign document",
        )

    @server.tool(name=tool_name("create_campaign"), annotations=_WRITE)
    async def create_campaign(
        name: str,
        category: str = "Outbound",
        brief: str | None = None,
        core_concept: str | None = None,
        primary_hook: str | None = None,
        target_persona: str | None = None,
        goal: str | None = None,
        audience_list_id: str | None = None,
    ) -> ActionResult | str:
        """Create a new campaign draft.

        Args:
            name: Campaign name (required).
            category: Campaign category. Default "Outbound".
            brief: Campaign brief.
            core_concept: Core concept text.
            primary_hook: Primary hook / angle copy.
            target_persona: Target persona id or descriptor.
            goal: Campaign goal.
            audience_list_id: Optional list id to attach as the campaign's
                audience in the same call (replaces the create + attach
                ping-pong). The list must already exist in this org;
                otherwise the create fails with 404.
        """
        body = {
            key: value
            for key, value in {
                "name": name,
                "category": category,
                "brief": brief,
                "core_concept": core_concept,
                "primary_hook": primary_hook,
                "target_persona": target_persona,
                "goal": goal,
                "audience_list_id": audience_list_id,
            }.items()
            if value is not None
        }
        return await safe_call_typed(
            client.post("/campaigns", body),
            ActionResult.from_envelope,
            context="Campaign creation",
        )

    @server.tool(name=tool_name("update_campaign"), annotations=_WRITE)
    async def update_campaign(
        campaign_id: str,
        name: str | None = None,
        brief: str | None = None,
        core_concept: str | None = None,
        primary_hook: str | None = None,
        target_persona: str | None = None,
        category: str | None = None,
        goal: str | None = None,
        # Kitchen-sink extensions (additive, all optional). When ANY of these
        # is provided we route through PATCH /campaigns/{id}/full so the
        # campaign + audience + documents + sequence are updated atomically.
        # Without them, behavior is unchanged: same PATCH /campaigns/{id} as before.
        audience_list_id: str | None = None,
        detach_audience: bool = False,
        documents: list[dict] | None = None,
        sequence_steps: list[dict] | None = None,
        # Pre-launch sequence-to-campaign linking (additive). These ONLY touch
        # rows with status='linked' - the launch-bridge audit rows
        # (pushed/superseded/failed) are never modified.
        linked_sequence_ids: list[str] | None = None,
        unlink_sequence_ids: list[str] | None = None,
    ) -> ActionResult | CampaignFullResult | str:
        """Update campaign strategy fields or metadata.

        Default behavior (no kitchen-sink kwargs): updates ONLY the campaign
        row via `PATCH /campaigns/{id}` - same as before.

        Kitchen-sink mode (any of ``audience_list_id``, ``detach_audience``,
        ``documents``, ``sequence_steps``, ``linked_sequence_ids``,
        ``unlink_sequence_ids`` provided): routes through
        `PATCH /campaigns/{id}/full` for an atomic deep-merge:
            1. Campaign fields (name/brief/hook/etc.)
            2. Audience attach (``audience_list_id``) or detach (``detach_audience=True``)
            3. Documents - per-doc patches: update existing by ``id``, or
               create by ``file_type`` + ``display_name``. Each item shape:
               ``{id?, file_type?, display_name?, folder_path?, status?,
                  content?, structured_data?}``.
            4. Sequence steps - full replacement (same semantics as
               PUT /sequence). Each item shape:
               ``{step_id, day, condition?, stop_on_reply?}``.
            5. Linked sequences - ``linked_sequence_ids`` binds existing
               sequences to this campaign (status='linked' rows). Skips IDs
               already linked. ``unlink_sequence_ids`` DELETEs only
               status='linked' rows; launch audit rows are never touched.

        Use cases for linking:
            * "I built a sequence manually - bind it to this campaign so the
              metrics endpoint includes it."
            * "Pre-attach a sequence so the launch flow knows about it."

        Returns the kitchen-sink payload in kitchen-sink mode; the plain
        ActionResult shape otherwise.
        """
        kitchen_sink = (
            audience_list_id is not None
            or detach_audience
            or documents is not None
            or sequence_steps is not None
            or linked_sequence_ids is not None
            or unlink_sequence_ids is not None
        )

        if kitchen_sink:
            body = {
                key: value
                for key, value in {
                    "name": name,
                    "brief": brief,
                    "core_concept": core_concept,
                    "primary_hook": primary_hook,
                    "target_persona": target_persona,
                    "category": category,
                    "goal": goal,
                    "audience_list_id": audience_list_id,
                    "detach_audience": detach_audience or None,
                    "documents": documents,
                    "sequence_steps": sequence_steps,
                    "linked_sequence_ids": linked_sequence_ids,
                    "unlink_sequence_ids": unlink_sequence_ids,
                }.items()
                if value is not None
            }
            # `detach_audience` needs to be passed through as the literal True
            # even when other fields are None. We dropped it above when None;
            # re-add when explicitly set.
            if detach_audience:
                body["detach_audience"] = True
            return await safe_call_typed(
                client.patch(f"/campaigns/{campaign_id}/full", body),
                CampaignFullResult.from_envelope,
                context="Campaign update (full)",
            )

        body = {
            key: value
            for key, value in {
                "name": name,
                "brief": brief,
                "core_concept": core_concept,
                "primary_hook": primary_hook,
                "target_persona": target_persona,
                "category": category,
                "goal": goal,
            }.items()
            if value is not None
        }
        return await safe_call_typed(
            client.patch(f"/campaigns/{campaign_id}", body),
            ActionResult.from_envelope,
            context="Campaign update",
        )

    @server.tool(name=tool_name("create_campaign_document"), annotations=_WRITE)
    async def create_campaign_document(
        campaign_id: str,
        file_type: str,
        display_name: str,
        content: str = "",
        folder_path: str | None = None,
        status: str = "draft",
    ) -> ActionResult | str:
        """Create a new campaign document."""
        body = {
            "file_type": file_type,
            "display_name": display_name,
            "content": content,
            "folder_path": folder_path,
            "status": status,
        }
        return await safe_call_typed(
            client.post(f"/campaigns/{campaign_id}/documents", body=body),
            ActionResult.from_envelope,
            context="Document creation",
        )

    @server.tool(name=tool_name("update_campaign_document"), annotations=_WRITE)
    async def update_campaign_document(
        campaign_id: str,
        document_id: str,
        content: str,
        status: str | None = None,
        structured_data: dict | None = None,
    ) -> ActionResult | str:
        """Save edits back to a campaign document."""
        body = {
            key: value
            for key, value in {
                "content": content,
                "status": status,
                "structured_data": structured_data,
            }.items()
            if value is not None
        }
        return await safe_call_typed(
            client.put(f"/campaigns/{campaign_id}/documents/{document_id}", body),
            ActionResult.from_envelope,
            context="Document update",
        )

    @server.tool(name=tool_name("delete_campaign_document"), annotations=_DESTRUCTIVE)
    async def delete_campaign_document(campaign_id: str, document_id: str) -> ActionResult | str:
        """Delete a campaign document."""
        return await safe_call_typed(
            client.delete(f"/campaigns/{campaign_id}/documents/{document_id}"),
            ActionResult.from_envelope,
            context="Document",
        )

    @server.tool(name=tool_name("get_campaign_sequence"), annotations=_READ_ONLY)
    async def get_campaign_sequence(campaign_id: str) -> CampaignSequenceResult | str:
        """Get the campaign sequence and step catalog."""
        return await safe_call_typed(
            client.get(f"/campaigns/{campaign_id}/sequence"),
            CampaignSequenceResult.from_envelope,
            context="Campaign sequence",
        )

    @server.tool(name=tool_name("update_campaign_sequence"), annotations=_WRITE)
    async def update_campaign_sequence(campaign_id: str, steps: list[dict]) -> ActionResult | str:
        """Replace the campaign sequence ordering with a new step list."""
        return await safe_call_typed(
            client.put(f"/campaigns/{campaign_id}/sequence", {"steps": steps}),
            ActionResult.from_envelope,
            context="Sequence update",
        )

    @server.tool(name=tool_name("create_campaign_step"), annotations=_WRITE)
    async def create_campaign_step(
        campaign_id: str,
        name: str,
        channel: str,
        mode: str,
        day: int,
        platform: str | None = None,
        angle_id: str = "angle_1",
        cta_type: str = "soft_ask",
        personalization_level: str = "medium",
        constraints: dict | None = None,
        condition: str | None = None,
        stop_on_reply: bool = True,
    ) -> ActionResult | str:
        """Add a step to a campaign sequence."""
        body = {
            "name": name,
            "channel": channel,
            "mode": mode,
            "day": day,
            "platform": platform,
            "angle_id": angle_id,
            "cta_type": cta_type,
            "personalization_level": personalization_level,
            "constraints": constraints or {},
            "condition": condition,
            "stop_on_reply": stop_on_reply,
        }
        return await safe_call_typed(
            client.post(f"/campaigns/{campaign_id}/sequence/steps", body),
            ActionResult.from_envelope,
            context="Step creation",
        )

    @server.tool(name=tool_name("update_campaign_step"), annotations=_WRITE)
    async def update_campaign_step(
        campaign_id: str,
        step_id: str,
        name: str | None = None,
        channel: str | None = None,
        mode: str | None = None,
        platform: str | None = None,
        angle_id: str | None = None,
        cta_type: str | None = None,
        personalization_level: str | None = None,
        constraints: dict | None = None,
        do_not_send_rules: list[str] | None = None,
        day: int | None = None,
        condition: str | None = None,
        stop_on_reply: bool | None = None,
    ) -> ActionResult | str:
        """Update a campaign sequence step definition or placement."""
        body = {
            key: value
            for key, value in {
                "name": name,
                "channel": channel,
                "mode": mode,
                "platform": platform,
                "angle_id": angle_id,
                "cta_type": cta_type,
                "personalization_level": personalization_level,
                "constraints": constraints,
                "do_not_send_rules": do_not_send_rules,
                "day": day,
                "condition": condition,
                "stop_on_reply": stop_on_reply,
            }.items()
            if value is not None
        }
        return await safe_call_typed(
            client.put(f"/campaigns/{campaign_id}/sequence/steps/{step_id}", body),
            ActionResult.from_envelope,
            context="Step update",
        )

    @server.tool(name=tool_name("delete_campaign_step"), annotations=_DESTRUCTIVE)
    async def delete_campaign_step(campaign_id: str, step_id: str) -> ActionResult | str:
        """Remove a step from the campaign sequence."""
        return await safe_call_typed(
            client.delete(f"/campaigns/{campaign_id}/sequence/steps/{step_id}"),
            ActionResult.from_envelope,
            context="Step",
        )

    @server.tool(
        name=tool_name("launch_campaign"),
        annotations=_DESTRUCTIVE,
        # Drives ui://confirmations/launch-campaign when dry_run=True.
        meta=ui_tool_meta("ui://confirmations/launch-campaign"),
    )
    async def launch_campaign(
        campaign_id: str, dry_run: bool = False
    ) -> ConfirmationPreview | ActionResult | str:
        """Launch a campaign to begin outbound execution.

        IMPORTANT: This sends real outreach. Recommended flow: call with
        `dry_run=True` first to render a confirmation widget, then again with
        `dry_run=False` after the user confirms.

        Dry-run behavior (since 0.8.0): the preview now fetches the kitchen-sink
        campaign payload + mailbox count to surface real pre-flight detail:
            - audience list name + contact count (or warning if unattached)
            - active mailbox count (warning if zero)
            - per-step snippet (channel/mode/day + first ~120 chars of copy)
        If any preflight fetch fails, the preview gracefully degrades to the
        thin shape so the user can still confirm-launch. Real launch is
        unchanged - same POST /campaigns/{id}/launch as before.

        Args:
            campaign_id: Campaign to launch (from g8_gtm_list_campaigns).
            dry_run: When True, return a confirmation preview instead of launching.
        """
        if dry_run:
            details: list[ConfirmationDetail] = [
                ConfirmationDetail(label="Campaign ID", value=campaign_id),
            ]
            warning = "Real outbound messages will start sending to enrolled contacts."
            summary = f"Launch campaign {campaign_id} - this begins outbound execution."

            # Best-effort preflight fetch. Anything raising means we fall back
            # to the thin shape - preview UX matters more than richness.
            try:
                full_envelope = await client.get(
                    f"/campaigns/{campaign_id}/full"
                )
                full_data = (
                    full_envelope.get("data")
                    if isinstance(full_envelope, dict)
                    else None
                )
                if isinstance(full_data, dict):
                    name = full_data.get("name") or campaign_id
                    summary = (
                        f"Launch campaign \"{name}\" - this begins outbound execution."
                    )

                    audience = full_data.get("audience")
                    if isinstance(audience, dict) and audience.get("list_id"):
                        list_name = audience.get("name") or "(unnamed list)"
                        item_count = audience.get("item_count")
                        count_str = (
                            f"{item_count:,} contacts" if item_count is not None else "unknown size"
                        )
                        details.append(
                            ConfirmationDetail(
                                label="Audience",
                                value=f"{list_name} ({count_str})",
                            )
                        )
                    else:
                        details.append(
                            ConfirmationDetail(
                                label="Audience",
                                value="(none attached)",
                            )
                        )
                        warning = (
                            "No audience attached - launch will create a sequence "
                            "with zero enrollment. Attach a list first with "
                            "g8_gtm_attach_audience."
                        )

                    # Mailbox preflight - count active mailboxes.
                    try:
                        mb_envelope = await client.get(
                            "/mailboxes",
                            {"connection_status": "active", "limit": 50},
                        )
                        mb_rows = (
                            mb_envelope.get("data")
                            if isinstance(mb_envelope, dict)
                            else None
                        )
                        active_mailboxes = len(mb_rows) if isinstance(mb_rows, list) else 0
                        details.append(
                            ConfirmationDetail(
                                label="Active mailboxes",
                                value=str(active_mailboxes),
                            )
                        )
                        if active_mailboxes == 0:
                            warning = (
                                "No active mailboxes - launch will fail to send "
                                "until a mailbox is connected and warmed."
                            )
                    except Exception:
                        # Mailbox preflight is advisory - silently drop on error.
                        pass

                    # Per-step snippets - pull the first ~120 chars of body
                    # so the user can sanity-check copy without opening a doc.
                    sequence = full_data.get("sequence") or {}
                    steps = sequence.get("steps") if isinstance(sequence, dict) else None
                    catalog = full_data.get("step_catalog") or {}
                    catalog_steps = (
                        catalog.get("steps") if isinstance(catalog, dict) else {}
                    )
                    if isinstance(steps, list) and steps:
                        # Show up to first 6 steps to keep the preview readable.
                        for idx, step in enumerate(steps[:6]):
                            if not isinstance(step, dict):
                                continue
                            sid = step.get("step_id")
                            day = step.get("day")
                            cat_step = (
                                catalog_steps.get(sid) if isinstance(catalog_steps, dict) else None
                            )
                            channel = (
                                cat_step.get("channel") if isinstance(cat_step, dict) else None
                            )
                            mode = (
                                cat_step.get("mode") if isinstance(cat_step, dict) else None
                            )
                            body = (
                                cat_step.get("body") if isinstance(cat_step, dict) else None
                            )
                            if isinstance(body, str) and body:
                                snippet = body.strip().replace("\n", " ")[:120]
                                if len(body) > 120:
                                    snippet += "…"
                            else:
                                snippet = "(no body)"
                            label = f"Step {idx + 1} day {day} {channel or '?'}/{mode or '?'}"
                            details.append(
                                ConfirmationDetail(label=label, value=snippet)
                            )
                    else:
                        details.append(
                            ConfirmationDetail(
                                label="Sequence",
                                value="(no steps defined)",
                            )
                        )
            except Exception:
                # Preflight failure -> fall back to the thin preview shape.
                # The user can still confirm-launch; we just lose detail.
                pass

            return ConfirmationPreview(
                action_label="Launch campaign",
                summary=summary,
                details=details,
                warning=warning,
                cost_label=None,
                confirm_tool=tool_name("launch_campaign"),
                confirm_args={
                    "campaign_id": campaign_id,
                    "dry_run": False,
                },
                confirm_label="Launch campaign",
                cancel_label="Cancel",
            )
        return await safe_call_typed(
            client.post(f"/campaigns/{campaign_id}/launch"),
            ActionResult.from_envelope,
            context="Campaign launch",
        )

    # ---------------------------------------------------------------------
    # MCP Campaigns Full-Cycle (PRD: docs/prds/mcp-campaigns-full-cycle.md)
    #
    # The four tools below close Daniel's `find list -> attach -> create ->
    # custom copy -> launch -> monitor` loop. They're hidden behind
    # g8_tool_search until the agent searches `campaign`, `audience`,
    # `metrics`, `mailbox`, `intelligence`, or `research` - keeping the
    # always-on tool budget lean while remaining one search away.
    # ---------------------------------------------------------------------

    @server.tool(name=tool_name("attach_audience"), annotations=_WRITE)
    async def attach_audience(
        campaign_id: str, list_id: str | None = None
    ) -> AttachAudienceResult | str:
        """Attach (or detach) a saved list to a campaign as its audience.

        The missing link in the MCP campaign flow: launch reads
        ``cb_campaigns.audience_list_id`` to enroll contacts; until now no
        REST/MCP path could set it (the FE "Attach Audience" dialog used a
        UI-internal route).

        Args:
            campaign_id: Campaign to update.
            list_id: List to attach (must exist in this org). Pass ``None`` to
                detach the current audience.

        Idempotent - attaching the same list twice is a 200 no-op.
        """
        return await safe_call_typed(
            client.put(f"/campaigns/{campaign_id}/audience", {"list_id": list_id}),
            AttachAudienceResult.from_envelope,
            context="Campaign audience",
        )

    @server.tool(name=tool_name("get_campaign_metrics"), annotations=_READ_ONLY)
    async def get_campaign_metrics(
        campaign_id: str, days: int = 30
    ) -> CampaignMetricsResult | str:
        """Get campaign execution metrics - sequence status + email counters.

        Thin wrapper around the ClickHouse-backed ``campaigns.metrics`` handler.
        Returns ``email_metrics`` (sent/opened/replied/...), plus
        ``is_running`` and ``sequence_count`` from Postgres. If ClickHouse is
        unreachable, ``email_metrics`` is zero-filled but Postgres-derived
        fields stay accurate.

        Args:
            campaign_id: Campaign to read metrics for.
            days: Lookback window (1-365). Default 30.
        """
        return await safe_call_typed(
            client.get(f"/campaigns/{campaign_id}/metrics", {"days": days}),
            CampaignMetricsResult.from_envelope,
            context="Campaign metrics",
        )

    @server.tool(name=tool_name("patch_campaign_full"), annotations=_WRITE)
    async def patch_campaign_full(
        campaign_id: str,
        name: str | None = None,
        brief: str | None = None,
        core_concept: str | None = None,
        primary_hook: str | None = None,
        target_persona: str | None = None,
        category: str | None = None,
        goal: str | None = None,
        audience_list_id: str | None = None,
        detach_audience: bool = False,
        documents: list[dict] | None = None,
        sequence_steps: list[dict] | None = None,
        linked_sequence_ids: list[str] | None = None,
        unlink_sequence_ids: list[str] | None = None,
    ) -> CampaignFullResult | str:
        """Atomic deep-update of a campaign in one round trip.

        Equivalent to calling ``update_campaign`` with kitchen-sink kwargs.
        Exposed as a separate tool so agents searching for ``"patch"`` or
        ``"deep update"`` discover it independently of the partial update path.

        Args:
            campaign_id: Campaign to patch.
            name/brief/core_concept/primary_hook/target_persona/category/goal:
                Campaign fields. Any provided fields are updated; omit to leave
                unchanged.
            audience_list_id: Attach this list as the audience.
            detach_audience: Set True to clear the audience. Mutually
                exclusive with ``audience_list_id``.
            documents: Per-document patches. Each item:
                ``{id?, file_type?, display_name?, folder_path?, status?,
                   content?, structured_data?}``. With ``id`` -> update;
                without ``id`` (and ``file_type`` + ``display_name`` present)
                -> create.
            sequence_steps: If provided, replaces the sequence step ordering
                verbatim. Each item: ``{step_id, day, condition?,
                stop_on_reply?}``.
            linked_sequence_ids: Existing sequence IDs to bind to this
                campaign (status='linked' rows in cb_campaign_sequence_links).
                Skips IDs already linked. Does NOT modify launch audit rows.
            unlink_sequence_ids: Sequence IDs to UNLINK. DELETEs ONLY rows
                where status='linked'. Audit rows (pushed/superseded/failed)
                are immutable history and never touched.

        Returns the post-patch kitchen-sink payload - same shape as
        ``get_campaign(full=True)`` - so the agent can see the new state
        without a follow-up GET.
        """
        body: dict[str, Any] = {
            key: value
            for key, value in {
                "name": name,
                "brief": brief,
                "core_concept": core_concept,
                "primary_hook": primary_hook,
                "target_persona": target_persona,
                "category": category,
                "goal": goal,
                "audience_list_id": audience_list_id,
                "documents": documents,
                "sequence_steps": sequence_steps,
                "linked_sequence_ids": linked_sequence_ids,
                "unlink_sequence_ids": unlink_sequence_ids,
            }.items()
            if value is not None
        }
        if detach_audience:
            body["detach_audience"] = True
        return await safe_call_typed(
            client.patch(f"/campaigns/{campaign_id}/full", body),
            CampaignFullResult.from_envelope,
            context="Campaign patch (full)",
        )

    @server.tool(name=tool_name("list_mailboxes"), annotations=_READ_ONLY)
    async def list_mailboxes(
        limit: int = 100,
        include_archived: bool = False,
        connection_status: str | None = None,
    ) -> MailboxesResult | str:
        """List sending mailboxes the authenticated user can access in this org.

        Sourced from the canonical ``mailboxes`` table (team-shared OR
        personally owned). Use this before launching a campaign to confirm
        the org has at least one ``connection_status='active'`` mailbox.

        Args:
            limit: Max mailboxes to return (1-500). Default 100.
            include_archived: Include archived mailboxes. Default False.
            connection_status: Filter by status
                (``active`` | ``paused`` | ``disconnected`` | ``expired`` | ...).
        """
        params: dict[str, Any] = {"limit": limit, "include_archived": include_archived}
        if connection_status is not None:
            params["connection_status"] = connection_status
        return await safe_call_typed(
            client.get("/mailboxes", params),
            MailboxesResult.from_envelope,
            context="Mailboxes",
        )

    @server.tool(name=tool_name("get_mailbox_warmup"), annotations=_READ_ONLY)
    async def get_mailbox_warmup(mailbox_id: int) -> MailboxWarmupResult | str:
        """Get live warmup analytics for a single mailbox.

        Hits the configured warmup provider (Instantly or SmartLead) over
        HTTP - slow (~300-800ms). For warm bulk reads of which mailboxes
        even HAVE warmup configured, use ``list_mailboxes`` and inspect the
        cheap DB-level ``warmup_status`` / ``warmup_provider`` columns first.

        Returns ``{success, warmup_enabled, provider, analytics, warmup_settings}``.
        Provider-specific fields inside ``analytics``:
            * Instantly: ``health_score``, ``inbox_rate``, ``daily_stats``
            * SmartLead: ``reputation``, ``daily_stats``

        When warmup isn't configured on the mailbox returns
        ``{success: true, warmup_enabled: false, provider: null}`` -
        idempotent and free of side effects.

        Args:
            mailbox_id: Integer mailbox ID (from ``list_mailboxes``).
        """
        return await safe_call_typed(
            client.get(f"/mailboxes/{mailbox_id}/warmup"),
            MailboxWarmupResult.from_envelope,
            context="Mailbox warmup analytics",
        )

    @server.tool(name=tool_name("list_intelligence_data"), annotations=_READ_ONLY)
    async def list_intelligence_data(
        data_type: str | None = None,
        include_content: bool = False,
        limit: int = 50,
    ) -> IntelligenceDataResult | str:
        """List documents in the Intelligence bucket of Studio Global Docs.

        ~16 doc types per org: ``website_scrape``, ``company_enrichment``,
        ``competitor_discovery``, ``company_keywords``, ``product_inventory``,
        ``organic_keywords``, ``paid_keywords``, ...

        Args:
            data_type: Filter by ``data_type``. Omit to return every type.
            include_content: When True, the raw JSONB ``data`` blob is
                included per row (large; default False returns metadata only).
            limit: Max rows (1-200). Default 50.
        """
        params: dict[str, Any] = {"limit": limit, "include_content": include_content}
        if data_type is not None:
            params["data_type"] = data_type
        return await safe_call_typed(
            client.get("/intelligence-data", params),
            IntelligenceDataResult.from_envelope,
            context="Intelligence data",
        )

    @server.tool(name=tool_name("list_research_reports"), annotations=_READ_ONLY)
    async def list_research_reports(
        report_type: str | None = None,
        include_content: bool = False,
        limit: int = 50,
    ) -> ResearchReportsResult | str:
        """List documents in the Research bucket of Studio Global Docs.

        6 report types per org: ``buyer_psychology``, ``competitive_teardown``,
        ``gtm_channel``, ``industry_analyst``, ``review_sentiment``,
        ``voice_of_customer``.

        Args:
            report_type: Filter by ``report_type``. Omit to return every type.
            include_content: When True, includes the structured ``content``
                JSONB and the rendered ``markdown_content`` (large; default
                False returns metadata only).
            limit: Max rows (1-200). Default 50.
        """
        params: dict[str, Any] = {"limit": limit, "include_content": include_content}
        if report_type is not None:
            params["report_type"] = report_type
        return await safe_call_typed(
            client.get("/research-reports", params),
            ResearchReportsResult.from_envelope,
            context="Research reports",
        )

    @server.tool(name=tool_name("get_global_context"), annotations=_READ_ONLY)
    async def get_global_context(category: str | None = None, limit: int = 50) -> GlobalContextsResult | str:
        """List global context documents available for campaign work."""
        return await safe_call_typed(
            client.get("/global-context/documents", {"category": category, "limit": limit}),
            GlobalContextsResult.from_envelope,
            context="Global context",
        )

    @server.tool(
        name=tool_name("get_personas"),
        annotations=_READ_ONLY,
        meta=ui_tool_meta("ui://personas/list"),
    )
    async def get_personas(status: str | None = None, limit: int = 50) -> PersonasResult | str:
        """List personas available for campaign targeting."""
        return await safe_call_typed(
            client.get("/personas", {"status": status, "limit": limit}),
            PersonasResult.from_envelope,
            context="Personas",
        )

    @server.tool(
        name=tool_name("get_icps"),
        annotations=_READ_ONLY,
        meta=ui_tool_meta("ui://icps/list"),
    )
    async def get_icps(status: str | None = None, limit: int = 50) -> IcpsResult | str:
        """List ICPs available for campaign targeting."""
        return await safe_call_typed(
            client.get("/icps", {"status": status, "limit": limit}),
            IcpsResult.from_envelope,
            context="ICPs",
        )

    @server.tool(name=tool_name("get_campaign_ideas"), annotations=_READ_ONLY)
    async def get_campaign_ideas(favorited: bool | None = None, limit: int = 50) -> CampaignIdeasResult | str:
        """List saved campaign ideas."""
        return await safe_call_typed(
            client.get("/campaigns/ideas", {"favorited": favorited, "limit": limit}),
            CampaignIdeasResult.from_envelope,
            context="Campaign ideas",
        )

    @server.tool(name=tool_name("search_kb"), annotations=_READ_ONLY)
    async def search_kb(query: str) -> KBResult | str:
        """Search the GTM knowledge base."""
        return await safe_call_typed(
            client.post("/kb/search", {"query": query}),
            KBResult.from_envelope,
            context="KB search",
        )

    @server.tool(name=tool_name("list_kb_documents"), annotations=_READ_ONLY)
    async def list_kb_documents() -> KBDocumentsResult | str:
        """List all documents in the GTM knowledge base."""
        return await safe_call_typed(
            client.get("/kb"),
            KBDocumentsResult.from_envelope,
            context="KB documents",
        )
