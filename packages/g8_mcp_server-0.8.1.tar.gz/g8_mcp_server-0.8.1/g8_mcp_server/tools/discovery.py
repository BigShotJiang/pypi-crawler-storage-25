"""Progressive tool discovery - the g8_tool_search meta-tool.

Upgrade 1 of the MCP pattern from Anthropic's Nov 2026 AI Engineer talk.

graph8 has ~83 MCP tools in `all` mode. Handing every tool schema to the model
at connect time inflates context for sessions that only touch a handful of
tools. Instead, the remote server default-filters `tools/list` down to a small
`_ALWAYS_ON_TOOLS` allowlist. When the model needs something outside that set,
it calls this tool - the match is written to session Redis and picked up by
the next `tools/list` invocation.

Contract:
- `g8_tool_search(query="sequence outreach")` → ranked matches, auto-activates
  the top `limit` hits so the next tools/list exposes them.
- `g8_tool_search(tool_names=["g8_enrich_contacts"])` → activate specific
  tools by name without a search (useful when the model already knows what it
  wants from an earlier turn or from a skill).
- Either branch returns a `ToolSearchResult` with the ranked matches and the
  post-call full activated set for the session.
"""

from __future__ import annotations

import logging

from mcp.server import FastMCP
from mcp.server.fastmcp import Context
from mcp.types import ServerNotification, ToolAnnotations, ToolListChangedNotification

from g8_mcp_server import tool_catalog
from g8_mcp_server.auth import get_api_key
from g8_mcp_server.models import ToolSearchMatch, ToolSearchResult
from g8_mcp_server.session_tools import add_activated, get_activated, session_id_for_key

logger = logging.getLogger(__name__)

_READ_ONLY = ToolAnnotations(readOnlyHint=True, idempotentHint=True)


def register(server: FastMCP, always_on: frozenset[str]) -> None:
    """Register the g8_tool_search meta-tool.

    `always_on` is passed in so the response can tell the model what's visible
    by default - useful when the model is deciding whether a tool really needs
    to be activated or is already available.
    """

    async def _ensure_catalog() -> None:
        """Lazy-build the catalog on first use. Re-build is cheap (list_tools is
        in-memory) so we accept re-checking on every call; if the catalog is
        empty we populate it."""
        if not tool_catalog.all_tool_names():
            await tool_catalog.build_catalog(server)

    @server.tool(annotations=_READ_ONLY)
    async def g8_tool_search(
        query: str | None = None,
        tool_names: list[str] | None = None,
        limit: int = 8,
        activate: bool = True,
        ctx: Context | None = None,
    ) -> ToolSearchResult | str:
        """REQUIRED FIRST STEP when the user asks for anything outside your
        currently visible tools. graph8 ships 80+ tools but only ~30 are
        visible at connect time. Workflow, voice/dialer, intent, skill,
        custom fields, forms, snippet, and playbook tools are HIDDEN until
        you search for them.

        Call this BEFORE saying "I don't have a tool for that" - it returns
        ranked matches AND auto-activates them so they appear on your next
        tools/list call (the server emits notifications/tools/list_changed).

        Common category queries: "workflow", "dialer", "voice", "intent",
        "skill", "field", "form", "snippet", "playbook".

        Args:
            query: Free-text search (e.g. "enrich contacts", "sequence pause",
                "push to CRM"). Ranks all registered tools by name/description
                match.
            tool_names: Explicit list of tool names to activate. Use when you
                already know the tool from a prior turn or skill and just need
                it visible in tools/list.
            limit: Max ranked matches to return (default 8).
            activate: When true (default) the top `limit` matches (or the
                `tool_names` entries) are written to this session's activated
                set. Set false to preview without widening tools/list.

        Returns a ToolSearchResult with:
        - matches: ranked tool hits (name, description, score, activated flag)
        - activated_session_tools: the full activated set AFTER this call
        - always_on_tools: the default visible set (for context)
        - total_registered_tools: how many tools exist in total

        After a successful activate=true call, the server emits
        `notifications/tools/list_changed` to prompt the client to re-fetch
        tools/list. Clients that don't support the notification still see the
        newly activated tools on their next session connect (Redis-cached 4h).

        The `ctx` parameter is auto-injected by FastMCP and hidden from the
        public tool schema - clients do not see it.
        """
        if not query and not tool_names:
            return (
                "g8_tool_search requires either `query` (e.g. 'enrich contacts') "
                "or `tool_names` (list of exact tool names to activate)."
            )

        await _ensure_catalog()
        all_names = tool_catalog.all_tool_names()
        session_id = session_id_for_key(get_api_key() or "")

        matches: list[ToolSearchMatch] = []
        to_activate: list[str] = []

        if tool_names:
            for name in tool_names:
                entry = tool_catalog.get_entry(name)
                if entry is None:
                    matches.append(
                        ToolSearchMatch(
                            name=name,
                            description=f"(unknown tool - not registered in {len(all_names)}-tool catalog)",
                            score=0.0,
                            activated=False,
                        )
                    )
                    continue
                matches.append(
                    ToolSearchMatch(
                        name=entry.name,
                        description=entry.description,
                        score=1.0,
                        activated=activate,
                    )
                )
                if activate:
                    to_activate.append(entry.name)

        if query:
            hits = tool_catalog.search(query, limit=max(limit, 1))
            # Deduplicate against any tool_names already added
            seen = {m.name for m in matches}
            for entry, score in hits:
                if entry.name in seen:
                    continue
                matches.append(
                    ToolSearchMatch(
                        name=entry.name,
                        description=entry.description,
                        score=score,
                        activated=activate,
                    )
                )
                seen.add(entry.name)
                if activate and len(to_activate) < max(limit, 1):
                    to_activate.append(entry.name)

        previously_activated = await get_activated(session_id)
        activated = previously_activated
        if to_activate:
            activated = await add_activated(session_id, to_activate)

        # Emit notifications/tools/list_changed attached to THIS request's
        # stream so the Streamable-HTTP transport routes it to the open POST
        # response (rather than GET_STREAM_KEY, which we do not serve). In
        # SSE response mode the notification is flushed to the client as an
        # event before the JSONRPCResponse closes the stream; conformant MCP
        # clients then re-issue tools/list and the newly-activated tools
        # become callable in the same session.
        #
        # Best-effort: every failure mode falls through silently because the
        # activation is already persisted in Redis and will surface on the
        # next reconnect. The tool call itself must never fail on a
        # notification write race.
        #   - ctx is None -> called outside an MCP request (unit tests, repl).
        #   - ctx.session unavailable -> older SDK or a transport that did
        #     not wire up a server session.
        #   - send_notification raises -> SSE/HTTP write race; skip.
        newly_activated = activated - previously_activated
        if newly_activated and ctx is not None:
            session = getattr(ctx, "session", None)
            if session is not None and hasattr(session, "send_notification"):
                try:
                    request_id = getattr(ctx, "request_id", None)
                    await session.send_notification(
                        ServerNotification(ToolListChangedNotification()),
                        related_request_id=request_id,
                    )
                    logger.debug(
                        "g8_tool_search: sent tools/list_changed for %d newly-activated tool(s) on request %s",
                        len(newly_activated),
                        request_id,
                    )
                except Exception as e:  # pragma: no cover - best-effort
                    logger.debug(
                        "g8_tool_search: send_notification(tools/list_changed) failed (%s) - "
                        "client will see activations on next reconnect",
                        e,
                    )

        note = None
        if not matches:
            note = (
                f"No tools matched. Registered tool count: {len(all_names)}. "
                "Try broader keywords (e.g. 'campaign', 'contact', 'inbox')."
            )
        elif not activate:
            note = (
                "Activate=false: matches were NOT added to your session. "
                "Call again with activate=true to expose them in tools/list."
            )

        return ToolSearchResult(
            query=query,
            matches=matches,
            activated_session_tools=sorted(activated),
            always_on_tools=sorted(always_on),
            total_registered_tools=len(all_names),
            note=note,
        )
