"""Unit tests for the new MCP tool ``g8_gtm_get_mailbox_warmup`` (0.8.0).

Behaviour:
  * Calls ``GET /mailboxes/{mailbox_id}/warmup`` (no query params)
  * Unwraps the ``data`` envelope into a ``MailboxWarmupResult``
  * Surfaces both Instantly and SmartLead analytics shapes faithfully
    (the wrapper uses ``extra="allow"`` so provider-specific fields ride along)
  * When the backend reports ``success=False`` with an error, the wrapper
    still resolves cleanly (graceful HTTP-error degradation lives on
    the backend side; the MCP tool just passes the envelope through).
"""

from __future__ import annotations

from pathlib import Path
from unittest.mock import AsyncMock

import pytest

import g8_mcp_server.client as client_module
from g8_mcp_server.client import G8Client
from g8_mcp_server.models import MailboxWarmupResult


@pytest.fixture
def mock_env(monkeypatch):
    monkeypatch.setenv("G8_API_KEY", "test_key_123")
    monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
    monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))


@pytest.fixture
def client(mock_env):
    return G8Client()


def _register_gtm_tools(client):
    from mcp.server import FastMCP

    from g8_mcp_server.tools import gtm

    server = FastMCP("test")
    gtm.register(server, client)
    return server, server._tool_manager._tools


def _tool_by_suffix(tools, suffix):
    for name, tool in tools.items():
        if name.endswith(suffix):
            return name, tool
    raise AssertionError(f"No tool ending in {suffix!r}")


class TestGetMailboxWarmupRegistration:
    def test_tool_registered(self, client):
        _, tools = _register_gtm_tools(client)
        # Confirms the new 0.8.0 tool is in the inventory
        _tool_by_suffix(tools, "get_mailbox_warmup")


class TestGetMailboxWarmupRouting:
    @pytest.mark.asyncio
    async def test_calls_correct_path(self, client):
        _, tools = _register_gtm_tools(client)
        _, tool = _tool_by_suffix(tools, "get_mailbox_warmup")

        client.get = AsyncMock(
            return_value={
                "data": {
                    "success": True,
                    "warmup_enabled": False,
                    "provider": None,
                }
            }
        )

        await tool.fn(mailbox_id=42)

        client.get.assert_called_once_with("/mailboxes/42/warmup")


class TestGetMailboxWarmupParsing:
    @pytest.mark.asyncio
    async def test_returns_typed_result_for_warmup_disabled(self, client):
        _, tools = _register_gtm_tools(client)
        _, tool = _tool_by_suffix(tools, "get_mailbox_warmup")

        client.get = AsyncMock(
            return_value={
                "data": {
                    "success": True,
                    "warmup_enabled": False,
                    "provider": None,
                }
            }
        )

        result = await tool.fn(mailbox_id=42)

        assert isinstance(result, MailboxWarmupResult)
        assert result.success is True
        assert result.warmup_enabled is False
        assert result.provider is None

    @pytest.mark.asyncio
    async def test_returns_typed_result_for_instantly_warmup(self, client):
        _, tools = _register_gtm_tools(client)
        _, tool = _tool_by_suffix(tools, "get_mailbox_warmup")

        client.get = AsyncMock(
            return_value={
                "data": {
                    "success": True,
                    "warmup_enabled": True,
                    "provider": "instantly",
                    "analytics": {
                        "health_score": 92,
                        "inbox_rate": 0.85,
                        "daily_stats": [{"date": "2026-05-01", "sent": 12}],
                    },
                    "warmup_settings": {"daily_limit": 50},
                }
            }
        )

        result = await tool.fn(mailbox_id=99)

        assert isinstance(result, MailboxWarmupResult)
        assert result.provider == "instantly"
        assert result.warmup_enabled is True
        # extra="allow" should preserve provider-specific analytics
        assert result.analytics == {
            "health_score": 92,
            "inbox_rate": 0.85,
            "daily_stats": [{"date": "2026-05-01", "sent": 12}],
        }
        assert result.warmup_settings == {"daily_limit": 50}

    @pytest.mark.asyncio
    async def test_returns_typed_result_for_smartlead_warmup(self, client):
        _, tools = _register_gtm_tools(client)
        _, tool = _tool_by_suffix(tools, "get_mailbox_warmup")

        client.get = AsyncMock(
            return_value={
                "data": {
                    "success": True,
                    "warmup_enabled": True,
                    "provider": "smartlead",
                    "analytics": {
                        "reputation": "good",
                        "daily_stats": [{"date": "2026-05-01", "sent": 25}],
                    },
                }
            }
        )

        result = await tool.fn(mailbox_id=7)

        assert result.provider == "smartlead"
        assert result.analytics["reputation"] == "good"

    @pytest.mark.asyncio
    async def test_surfaces_backend_error_envelope(self, client):
        """When the backend reports a graceful failure (provider HTTP
        timed out, mailbox out of scope, etc.) the MCP tool returns the
        ``MailboxWarmupResult`` with success=False+error rather than
        raising."""
        _, tools = _register_gtm_tools(client)
        _, tool = _tool_by_suffix(tools, "get_mailbox_warmup")

        client.get = AsyncMock(
            return_value={
                "data": {
                    "success": False,
                    "error": "Instantly: connect timeout",
                }
            }
        )

        result = await tool.fn(mailbox_id=12)

        assert isinstance(result, MailboxWarmupResult)
        assert result.success is False
        assert result.error == "Instantly: connect timeout"
