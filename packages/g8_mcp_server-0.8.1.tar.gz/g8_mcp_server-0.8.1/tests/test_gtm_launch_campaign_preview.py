"""Unit tests for the 0.8.0 beefed-up ``g8_gtm_launch_campaign(dry_run=True)``
confirmation preview.

The dry-run preview now does best-effort preflight calls:
  1. GET /campaigns/{id}/full  -> audience, sequence steps, step catalog
  2. GET /mailboxes?connection_status=active&limit=50  -> count

Hard requirements (the user explicitly said "BACKWARDS COMPATIBLE / NOTHING
SHOULD BREAK"):
  * Real launch path (dry_run=False) is unchanged  -  POST /campaigns/{id}/launch
  * If ANY preflight call raises, we MUST gracefully fall back to the thin
    shape rather than 500
  * Missing audience -> swap the warning to "No audience attached..."
  * Zero active mailboxes -> swap warning to "No active mailboxes..."

This test file also covers the new ``primary_hook`` / ``core_concept`` fields
on ``CampaignItem`` (list_campaigns DTO) - one focused class per surface.
"""

from __future__ import annotations

from pathlib import Path
from unittest.mock import AsyncMock

import pytest

import g8_mcp_server.client as client_module
from g8_mcp_server.client import G8Client
from g8_mcp_server.models import (
    ActionResult,
    CampaignItem,
    CampaignsResult,
    ConfirmationPreview,
)


@pytest.fixture
def mock_env(monkeypatch):
    monkeypatch.setenv("G8_API_KEY", "test_key_123")
    monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
    monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))


@pytest.fixture
def client(mock_env):
    return G8Client()


def _register_gtm_tools(client):
    from mcp.server import FastMCP

    from g8_mcp_server.tools import gtm

    server = FastMCP("test")
    gtm.register(server, client)
    return server, server._tool_manager._tools


def _tool_by_suffix(tools, suffix):
    for name, tool in tools.items():
        if name.endswith(suffix):
            return name, tool
    raise AssertionError(f"No tool ending in {suffix!r}")


def _make_get_mock(*, full_data=None, full_raises=False, mailboxes=None, mailboxes_raises=False):
    """Build an AsyncMock for client.get that dispatches on path.

    full_data: dict payload to return for ``/campaigns/{id}/full`` (wrapped in
        ``{data: ...}``). When None, the response will be ``{"data": None}``.
    full_raises: True -> raise Exception on /full preflight
    mailboxes: list payload for ``/mailboxes``
    mailboxes_raises: True -> raise Exception on mailbox preflight
    """

    async def _dispatch(path, params=None):
        if "/full" in path:
            if full_raises:
                raise RuntimeError("simulated /full failure")
            return {"data": full_data}
        if "/mailboxes" in path:
            if mailboxes_raises:
                raise RuntimeError("simulated mailbox failure")
            return {"data": mailboxes or []}
        return {"data": None}

    return AsyncMock(side_effect=_dispatch)


class TestLaunchCampaignDryRunHappyPath:
    @pytest.mark.asyncio
    async def test_returns_confirmation_preview_with_audience_and_mailboxes(self, client):
        _, tools = _register_gtm_tools(client)
        _, tool = _tool_by_suffix(tools, "launch_campaign")

        client.get = _make_get_mock(
            full_data={
                "id": "camp-1",
                "name": "Spring Outreach",
                "audience": {"list_id": "list-1", "name": "Top 100", "item_count": 100},
                "sequence": {"steps": [{"step_id": "s1", "day": 0}]},
                "step_catalog": {
                    "steps": {
                        "s1": {
                            "channel": "email",
                            "mode": "send",
                            "body": "Hi there, just wanted to introduce myself.",
                        }
                    }
                },
            },
            mailboxes=[{"id": "mb-1"}, {"id": "mb-2"}],
        )

        result = await tool.fn(campaign_id="camp-1", dry_run=True)

        assert isinstance(result, ConfirmationPreview)
        # Summary references the campaign name (real preflight ran)
        assert "Spring Outreach" in result.summary
        # Confirm-args round-trips into a real launch
        assert result.confirm_args == {"campaign_id": "camp-1", "dry_run": False}
        # Details include audience + mailbox + step snippet
        labels = [d.label for d in result.details]
        assert "Audience" in labels
        assert "Active mailboxes" in labels
        assert any(lbl.startswith("Step 1") for lbl in labels)
        # Warning is the generic real-send notice when both audience and
        # mailboxes are present (not the "no audience" or "no mailbox" one)
        assert result.warning is not None
        assert "real outbound" in result.warning.lower()

    @pytest.mark.asyncio
    async def test_audience_value_includes_list_name_and_count(self, client):
        _, tools = _register_gtm_tools(client)
        _, tool = _tool_by_suffix(tools, "launch_campaign")

        client.get = _make_get_mock(
            full_data={
                "id": "camp-1",
                "name": "X",
                "audience": {"list_id": "list-9", "name": "ICP-A", "item_count": 250},
                "sequence": None,
                "step_catalog": None,
            },
            mailboxes=[{"id": "mb-1"}],
        )

        result = await tool.fn(campaign_id="camp-1", dry_run=True)

        aud_detail = next(d for d in result.details if d.label == "Audience")
        assert "ICP-A" in aud_detail.value
        assert "250" in aud_detail.value


class TestLaunchCampaignDryRunMissingPieces:
    @pytest.mark.asyncio
    async def test_no_audience_swaps_warning(self, client):
        _, tools = _register_gtm_tools(client)
        _, tool = _tool_by_suffix(tools, "launch_campaign")

        client.get = _make_get_mock(
            full_data={
                "id": "camp-1",
                "name": "Cold Start",
                "audience": None,
                "sequence": None,
                "step_catalog": None,
            },
            mailboxes=[{"id": "mb-1"}],
        )

        result = await tool.fn(campaign_id="camp-1", dry_run=True)

        assert "audience attached" in result.warning.lower() or "no audience" in result.warning.lower()
        # The audience detail still appears, marked as none attached
        aud_detail = next(d for d in result.details if d.label == "Audience")
        assert "none" in aud_detail.value.lower()

    @pytest.mark.asyncio
    async def test_zero_mailboxes_swaps_warning(self, client):
        _, tools = _register_gtm_tools(client)
        _, tool = _tool_by_suffix(tools, "launch_campaign")

        client.get = _make_get_mock(
            full_data={
                "id": "camp-1",
                "name": "OK",
                "audience": {"list_id": "list-1", "name": "L1", "item_count": 10},
                "sequence": None,
                "step_catalog": None,
            },
            mailboxes=[],
        )

        result = await tool.fn(campaign_id="camp-1", dry_run=True)

        assert "mailbox" in result.warning.lower()
        mb_detail = next(d for d in result.details if d.label == "Active mailboxes")
        assert mb_detail.value == "0"

    @pytest.mark.asyncio
    async def test_no_sequence_renders_placeholder(self, client):
        _, tools = _register_gtm_tools(client)
        _, tool = _tool_by_suffix(tools, "launch_campaign")

        client.get = _make_get_mock(
            full_data={
                "id": "camp-1",
                "name": "Empty Seq",
                "audience": {"list_id": "list-1", "name": "L", "item_count": 5},
                "sequence": {"steps": []},
                "step_catalog": None,
            },
            mailboxes=[{"id": "mb-1"}],
        )

        result = await tool.fn(campaign_id="camp-1", dry_run=True)

        seq_detail = next(d for d in result.details if d.label == "Sequence")
        assert "no steps" in seq_detail.value.lower()


class TestLaunchCampaignDryRunGracefulDegradation:
    """Critical backwards-compat: any preflight failure MUST fall back to the
    thin preview, never bubble up as a 500."""

    @pytest.mark.asyncio
    async def test_full_endpoint_failure_falls_back_to_thin_preview(self, client):
        _, tools = _register_gtm_tools(client)
        _, tool = _tool_by_suffix(tools, "launch_campaign")

        client.get = _make_get_mock(full_raises=True)

        result = await tool.fn(campaign_id="camp-1", dry_run=True)

        # Still returns a usable preview
        assert isinstance(result, ConfirmationPreview)
        assert result.confirm_args == {"campaign_id": "camp-1", "dry_run": False}
        # Falls back to the thin "Campaign ID" detail only
        assert any(d.label == "Campaign ID" and d.value == "camp-1" for d in result.details)
        # Generic warning kept
        assert result.warning is not None

    @pytest.mark.asyncio
    async def test_mailbox_preflight_failure_does_not_break_preview(self, client):
        _, tools = _register_gtm_tools(client)
        _, tool = _tool_by_suffix(tools, "launch_campaign")

        client.get = _make_get_mock(
            full_data={
                "id": "camp-1",
                "name": "Y",
                "audience": {"list_id": "list-1", "name": "L", "item_count": 5},
                "sequence": None,
                "step_catalog": None,
            },
            mailboxes_raises=True,
        )

        result = await tool.fn(campaign_id="camp-1", dry_run=True)

        # Preview still works; we just lose the mailbox row.
        assert isinstance(result, ConfirmationPreview)
        labels = [d.label for d in result.details]
        assert "Audience" in labels
        assert "Active mailboxes" not in labels


class TestLaunchCampaignRealLaunchUnchanged:
    """The dry-run beef-up MUST NOT touch the real-launch code path."""

    @pytest.mark.asyncio
    async def test_real_launch_posts_to_launch_endpoint(self, client):
        _, tools = _register_gtm_tools(client)
        _, tool = _tool_by_suffix(tools, "launch_campaign")

        client.post = AsyncMock(return_value={"data": {"id": "camp-1", "status": "launched"}})
        client.get = AsyncMock()  # ensure we never read

        result = await tool.fn(campaign_id="camp-1", dry_run=False)

        client.post.assert_called_once_with("/campaigns/camp-1/launch")
        # Real-launch returns an ActionResult, NOT a preview
        assert isinstance(result, ActionResult)
        # And critically: NO preflight GETs were made.
        client.get.assert_not_called()


class TestListCampaignsHookAndConcept:
    """0.8.0 added primary_hook + core_concept to CampaignItem so the agent
    can pre-filter "similar past campaigns" without an extra round trip.
    Older list envelopes that omit these keys must still validate cleanly."""

    @pytest.mark.asyncio
    async def test_surfaces_new_fields_when_present(self, client):
        _, tools = _register_gtm_tools(client)
        _, tool = _tool_by_suffix(tools, "list_campaigns")

        client.get = AsyncMock(
            return_value={
                "data": [
                    {
                        "id": "c1",
                        "name": "Test",
                        "primary_hook": "Save 10 hrs/week",
                        "core_concept": "Automate ICP discovery",
                    }
                ]
            }
        )

        result = await tool.fn()

        assert isinstance(result, CampaignsResult)
        assert len(result.campaigns) == 1
        item = result.campaigns[0]
        assert item.primary_hook == "Save 10 hrs/week"
        assert item.core_concept == "Automate ICP discovery"

    @pytest.mark.asyncio
    async def test_backwards_compat_no_hook_no_concept(self, client):
        _, tools = _register_gtm_tools(client)
        _, tool = _tool_by_suffix(tools, "list_campaigns")

        client.get = AsyncMock(
            return_value={
                "data": [
                    {"id": "c1", "name": "Legacy"},
                ]
            }
        )

        result = await tool.fn()

        assert result.campaigns[0].primary_hook is None
        assert result.campaigns[0].core_concept is None

    def test_dto_accepts_partial_fields(self):
        """DTO-level sanity: validating each combination directly so we lock
        in that neither field is required to coexist with the other."""
        only_hook = CampaignItem.model_validate({"id": "c1", "primary_hook": "X"})
        assert only_hook.primary_hook == "X"
        assert only_hook.core_concept is None

        only_concept = CampaignItem.model_validate({"id": "c1", "core_concept": "Y"})
        assert only_concept.core_concept == "Y"
        assert only_concept.primary_hook is None
