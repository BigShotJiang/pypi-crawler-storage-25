"""Tests for the g8_workflow_* MCP suite.

Covers 40 workflow-builder tools (25 original + 1 form-field resolver +
14 skill-authoring tools) registered in `all` mode:

Original 25 (MCP workflow builder PRD, sibling to mcp-copilot-tool-parity.md):
  - 5 read/discover (list_node_types, describe_node_type, list, get,
    get_trigger_status)
  - 4 top-level CRUD/validate (create, update, delete, validate)
  - 4 granular helpers (add_node, update_node, remove_node, connect_nodes)
  - 6 lifecycle (execute, get_execution, pause/resume/stop_execution,
    reset_trigger_cursor)
  - 6 resolver helpers (list_roam_users, list_roam_groups,
    list_slack_users, list_slack_channels, list_mcp_servers,
    list_dispositions) - read-only, point human descriptions at concrete IDs

Added later:
  - 1 form-field resolver (describe_form_fields)
  - 14 skill-authoring tools (g8_workflow_skill_*): 6 read-only catalog
    operations (list, get, list_models, list_templates,
    extract_variables, validate_template), 6 destructive create/delete/
    execute, 2 reversible update_api/update_llm

Verifies:
  * All tools register in `all` mode and are absent in `dev` / `gtm`
    (the "workflow lives in `all` only" decision).
  * Read tools carry readOnlyHint=True.
  * Destructive tools (create, delete, execute, stop_execution) carry
    destructiveHint=True so MCP-aware clients prompt for confirm.
  * Reversible tools (pause/resume_execution, update, add/update/remove
    node, connect_nodes, reset_trigger_cursor) carry idempotentHint=True
    and NOT destructiveHint=True.
  * URL paths and bodies forwarded to the developer_api proxy match
    the wire contract.
  * dry_run on destructive tools returns a ConfirmationPreview-shaped
    dict and does NOT call the backend.
  * Granular helpers (add_node etc.) fetch + mutate + PUT correctly.
"""

from __future__ import annotations

from pathlib import Path
from unittest.mock import AsyncMock

import pytest

import g8_mcp_server.client as client_module
import g8_mcp_server.server as server_module
from g8_mcp_server.server import create_server


def _server_with_mode(monkeypatch, mode: str):
    """Build a fresh FastMCP server in the given mode."""
    monkeypatch.setenv("G8_API_KEY", "test_key")
    monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
    monkeypatch.setenv("G8_MCP_MODE", mode)
    monkeypatch.setattr(server_module, "MCP_MODE", mode)
    monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent"))
    return create_server()


@pytest.fixture
def mcp_server(monkeypatch):
    return _server_with_mode(monkeypatch, "all")


@pytest.fixture
def gtm_only_server(monkeypatch):
    return _server_with_mode(monkeypatch, "gtm")


@pytest.fixture
def dev_only_server(monkeypatch):
    return _server_with_mode(monkeypatch, "dev")


def _tool(server, name):
    return server._tool_manager._tools[name]


def _ann_flag(tool, key: str):
    ann = tool.annotations
    flag = getattr(ann, key, None)
    if flag is None and isinstance(ann, dict):
        flag = ann.get(key)
    return flag


# ---------------------------------------------------------------------------
# Registration & annotations
# ---------------------------------------------------------------------------


READ_ONLY_NAMES = [
    "g8_workflow_list_node_types",
    "g8_workflow_describe_node_type",
    "g8_workflow_list",
    "g8_workflow_get",
    "g8_workflow_get_trigger_status",
    "g8_workflow_validate",
    "g8_workflow_get_execution",
]

DESTRUCTIVE_NAMES = [
    "g8_workflow_create",
    "g8_workflow_delete",
    "g8_workflow_execute",
    "g8_workflow_stop_execution",
]

REVERSIBLE_NAMES = [
    "g8_workflow_update",
    "g8_workflow_add_node",
    "g8_workflow_update_node",
    "g8_workflow_remove_node",
    "g8_workflow_connect_nodes",
    "g8_workflow_pause_execution",
    "g8_workflow_resume_execution",
    "g8_workflow_reset_trigger_cursor",
]

# Resolver helpers - read-only tools that resolve human descriptions
# ("DM Hamza", "post to #general") into concrete IDs that node configs
# require. Pinned alongside the other workflow tools so the registration
# count is locked.
RESOLVER_NAMES = [
    "g8_workflow_list_roam_users",
    "g8_workflow_list_roam_groups",
    "g8_workflow_list_slack_users",
    "g8_workflow_list_slack_channels",
    "g8_workflow_list_mcp_servers",
    "g8_workflow_list_dispositions",
    # Form-field resolver: introspects a Form trigger's submission schema so
    # downstream node configs can reference real field names.
    "g8_workflow_describe_form_fields",
]

# Skill-authoring suite (g8_workflow_skill_*) - lets agents create, list,
# update, delete, and execute graph8 skill records used by workflow Action
# nodes. Distinct from the 25 workflow-graph tools; registered alongside
# them in `all` mode.
SKILL_READ_ONLY_NAMES = [
    "g8_workflow_skill_list",
    "g8_workflow_skill_get",
    "g8_workflow_skill_list_models",
    "g8_workflow_skill_list_templates",
    "g8_workflow_skill_extract_variables",
    "g8_workflow_skill_validate_template",
]

SKILL_DESTRUCTIVE_NAMES = [
    "g8_workflow_skill_create_api",
    "g8_workflow_skill_create_from_node",
    "g8_workflow_skill_create_from_template",
    "g8_workflow_skill_create_llm",
    "g8_workflow_skill_delete",
    "g8_workflow_skill_execute",
]

SKILL_REVERSIBLE_NAMES = [
    "g8_workflow_skill_update_api",
    "g8_workflow_skill_update_llm",
]

ALL_NAMES = (
    READ_ONLY_NAMES
    + DESTRUCTIVE_NAMES
    + REVERSIBLE_NAMES
    + RESOLVER_NAMES
    + SKILL_READ_ONLY_NAMES
    + SKILL_DESTRUCTIVE_NAMES
    + SKILL_REVERSIBLE_NAMES
)


class TestRegistration:
    def test_all_tools_registered_in_all_mode(self, mcp_server):
        for name in ALL_NAMES:
            assert name in mcp_server._tool_manager._tools, f"Missing: {name}"

    def test_total_count(self, mcp_server):
        # Lock the surface count so adding/removing a tool is an
        # intentional decision, not an accident. Original PRD scoped ~17,
        # final wiring landed at 25 (5 read + 8 build/edit + 6 lifecycle
        # + 6 resolver helpers). Later additions: +1 form-field resolver,
        # +14 g8_workflow_skill_* authoring tools = 40 total.
        registered_workflow_tools = [
            n for n in mcp_server._tool_manager._tools if n.startswith("g8_workflow_")
        ]
        assert len(registered_workflow_tools) == 40, (
            f"Expected 40 workflow tools, got {len(registered_workflow_tools)}: {sorted(registered_workflow_tools)}"
        )

    def test_read_only_tools_are_read_only(self, mcp_server):
        # Top-level reads, resolver helpers, AND skill catalog read-ops
        # must carry the read-only hint - all safe to call without confirmation.
        for name in READ_ONLY_NAMES + RESOLVER_NAMES + SKILL_READ_ONLY_NAMES:
            assert _ann_flag(_tool(mcp_server, name), "readOnlyHint") is True, (
                f"{name} should be read-only"
            )

    def test_destructive_tools_carry_destructive_hint(self, mcp_server):
        for name in DESTRUCTIVE_NAMES + SKILL_DESTRUCTIVE_NAMES:
            assert _ann_flag(_tool(mcp_server, name), "destructiveHint") is True, (
                f"{name} should be destructive (MCP clients prompt to confirm)"
            )
            # And NOT read-only.
            assert _ann_flag(_tool(mcp_server, name), "readOnlyHint") is not True, (
                f"{name} must not be marked read-only - it mutates state"
            )

    def test_reversible_tools_are_idempotent_not_destructive(self, mcp_server):
        for name in REVERSIBLE_NAMES + SKILL_REVERSIBLE_NAMES:
            assert _ann_flag(_tool(mcp_server, name), "idempotentHint") is True, (
                f"{name} should be idempotent (reversible state flip)"
            )
            assert _ann_flag(_tool(mcp_server, name), "destructiveHint") is not True, (
                f"{name} must not be destructive - calling it twice is safe"
            )

    def test_workflow_tools_absent_in_gtm_mode(self, gtm_only_server):
        # The PRD pinned workflow building to `all` mode (decision 5
        # was "all modes" — but that decision was for catalog visibility,
        # while the registration lives only in the "all" branch of
        # _register_tools to avoid leaking into pure-gtm Claude Desktop
        # sessions). Lock that boundary here so a refactor doesn't
        # regress it silently.
        for name in ALL_NAMES:
            assert name not in gtm_only_server._tool_manager._tools, (
                f"{name} leaked into gtm mode - workflow lives in `all` only"
            )

    def test_workflow_tools_absent_in_dev_mode(self, dev_only_server):
        for name in ALL_NAMES:
            assert name not in dev_only_server._tool_manager._tools, (
                f"{name} leaked into dev mode - workflow lives in `all` only"
            )

    def test_not_in_always_on_set(self):
        # Progressive discovery promise: workflow tools cost zero context
        # at connect time. The agent reaches them via g8_tool_search.
        for name in ALL_NAMES:
            assert name not in server_module._ALWAYS_ON_TOOLS, (
                f"{name} is in _ALWAYS_ON_TOOLS — workflow tools must stay "
                "behind progressive discovery to keep the steady-state "
                "context tax at zero."
            )


# ---------------------------------------------------------------------------
# Read / discover paths
# ---------------------------------------------------------------------------


class TestListNodeTypes:
    async def test_default_detail_slim(self, mcp_server, monkeypatch):
        fake = AsyncMock(return_value={"node_types": [], "version": "1"})
        monkeypatch.setattr("g8_mcp_server.tools.workflows.G8Client.get", fake)
        await _tool(mcp_server, "g8_workflow_list_node_types").fn()
        path, params = fake.await_args.args[:2]
        assert path == "/workflows/node-types/schema"
        assert params == {"detail": "slim"}

    async def test_detail_full_forwarded(self, mcp_server, monkeypatch):
        fake = AsyncMock(return_value={"node_types": []})
        monkeypatch.setattr("g8_mcp_server.tools.workflows.G8Client.get", fake)
        await _tool(mcp_server, "g8_workflow_list_node_types").fn(detail="full")
        params = fake.await_args.args[1]
        assert params["detail"] == "full"


class TestDescribeNodeType:
    async def test_path_and_params(self, mcp_server, monkeypatch):
        fake = AsyncMock(return_value={"name": "sequence_reply_trigger", "schema": {}})
        monkeypatch.setattr("g8_mcp_server.tools.workflows.G8Client.get", fake)
        await _tool(mcp_server, "g8_workflow_describe_node_type").fn(
            node_type="sequence_reply_trigger"
        )
        path, params = fake.await_args.args[:2]
        assert path == "/workflows/node-types/schema"
        assert params == {"node_type": "sequence_reply_trigger", "detail": "full"}

    async def test_missing_node_type_returns_string(self, mcp_server, monkeypatch):
        fake = AsyncMock()
        monkeypatch.setattr("g8_mcp_server.tools.workflows.G8Client.get", fake)
        r = await _tool(mcp_server, "g8_workflow_describe_node_type").fn(node_type="")
        assert isinstance(r, str) and "node_type" in r
        fake.assert_not_called()


class TestListWorkflows:
    async def test_default_no_params(self, mcp_server, monkeypatch):
        fake = AsyncMock(return_value={"items": []})
        monkeypatch.setattr("g8_mcp_server.tools.workflows.G8Client.get", fake)
        await _tool(mcp_server, "g8_workflow_list").fn()
        path, params = fake.await_args.args[:2]
        assert path == "/workflows"
        # Empty filters → params dropped to None at the tool layer.
        assert params is None

    async def test_filter_forwarding(self, mcp_server, monkeypatch):
        fake = AsyncMock(return_value={"items": []})
        monkeypatch.setattr("g8_mcp_server.tools.workflows.G8Client.get", fake)
        await _tool(mcp_server, "g8_workflow_list").fn(
            enabled=True, category="sales", is_template=False
        )
        params = fake.await_args.args[1]
        assert params == {"enabled": True, "category": "sales", "is_template": False}


class TestGetWorkflow:
    async def test_path(self, mcp_server, monkeypatch):
        fake = AsyncMock(return_value={"action_id": "wf-1", "config": {"nodes": []}})
        monkeypatch.setattr("g8_mcp_server.tools.workflows.G8Client.get", fake)
        await _tool(mcp_server, "g8_workflow_get").fn(action_id="wf-1")
        assert fake.await_args.args[0] == "/workflows/wf-1"

    async def test_missing_action_id_returns_string(self, mcp_server, monkeypatch):
        fake = AsyncMock()
        monkeypatch.setattr("g8_mcp_server.tools.workflows.G8Client.get", fake)
        r = await _tool(mcp_server, "g8_workflow_get").fn(action_id="")
        assert isinstance(r, str)
        fake.assert_not_called()


class TestGetTriggerStatus:
    async def test_path(self, mcp_server, monkeypatch):
        fake = AsyncMock(return_value={"has_trigger": True, "cursor": "..."})
        monkeypatch.setattr("g8_mcp_server.tools.workflows.G8Client.get", fake)
        await _tool(mcp_server, "g8_workflow_get_trigger_status").fn(action_id="wf-1")
        assert fake.await_args.args[0] == "/workflows/wf-1/trigger-status"


# ---------------------------------------------------------------------------
# Build / edit — top-level CRUD + validate
# ---------------------------------------------------------------------------


class TestCreateWorkflow:
    async def test_dry_run_returns_preview_without_calling_backend(self, mcp_server, monkeypatch):
        fake = AsyncMock()
        monkeypatch.setattr("g8_mcp_server.tools.workflows.G8Client.post", fake)
        r = await _tool(mcp_server, "g8_workflow_create").fn(
            name="Demo",
            config={"nodes": [{"id": "n1"}, {"id": "n2"}], "edges": [{"id": "e1"}], "startNodeId": "n1"},
            dry_run=True,
        )
        assert isinstance(r, dict)
        assert r["confirm_tool"] == "g8_workflow_create"
        # The model must require dry_run=False on the confirm call to avoid loops.
        assert r["confirm_args"]["dry_run"] is False
        fake.assert_not_called()

    async def test_minimal_body(self, mcp_server, monkeypatch):
        fake = AsyncMock(return_value={"action_id": "wf-new"})
        monkeypatch.setattr("g8_mcp_server.tools.workflows.G8Client.post", fake)
        cfg = {"nodes": [], "edges": [], "startNodeId": "n0"}
        r = await _tool(mcp_server, "g8_workflow_create").fn(name="Demo", config=cfg)
        path = fake.await_args.args[0]
        body = fake.await_args.kwargs.get("body") or fake.await_args.args[1]
        assert path == "/workflows"
        assert body == {"name": "Demo", "config": cfg, "enabled": False}
        assert r["action_id"] == "wf-new"

    async def test_full_body_forwarding(self, mcp_server, monkeypatch):
        fake = AsyncMock(return_value={"action_id": "wf-new"})
        monkeypatch.setattr("g8_mcp_server.tools.workflows.G8Client.post", fake)
        cfg = {"nodes": [], "edges": [], "startNodeId": "n0"}
        await _tool(mcp_server, "g8_workflow_create").fn(
            name="Demo",
            config=cfg,
            description="A demo workflow",
            category="sales",
            enabled=True,
        )
        body = fake.await_args.kwargs.get("body") or fake.await_args.args[1]
        assert body["description"] == "A demo workflow"
        assert body["category"] == "sales"
        assert body["enabled"] is True

    async def test_invalid_config_returns_string(self, mcp_server, monkeypatch):
        fake = AsyncMock()
        monkeypatch.setattr("g8_mcp_server.tools.workflows.G8Client.post", fake)
        # Pass a non-dict config — should short-circuit before any HTTP call.
        r = await _tool(mcp_server, "g8_workflow_create").fn(name="x", config=None)  # type: ignore[arg-type]
        assert isinstance(r, str) and "config" in r
        fake.assert_not_called()


class TestUpdateWorkflow:
    async def test_partial_update_path_and_body(self, mcp_server, monkeypatch):
        fake = AsyncMock(return_value={"action_id": "wf-1"})
        monkeypatch.setattr("g8_mcp_server.tools.workflows.G8Client.put", fake)
        await _tool(mcp_server, "g8_workflow_update").fn(action_id="wf-1", name="New Name", enabled=True)
        path = fake.await_args.args[0]
        body = fake.await_args.kwargs.get("body") or fake.await_args.args[1]
        assert path == "/workflows/wf-1"
        assert body == {"name": "New Name", "enabled": True}

    async def test_no_fields_short_circuits(self, mcp_server, monkeypatch):
        fake = AsyncMock()
        monkeypatch.setattr("g8_mcp_server.tools.workflows.G8Client.put", fake)
        r = await _tool(mcp_server, "g8_workflow_update").fn(action_id="wf-1")
        assert isinstance(r, str) and "at least one field" in r
        fake.assert_not_called()


class TestDeleteWorkflow:
    async def test_dry_run_preview(self, mcp_server, monkeypatch):
        fake = AsyncMock()
        monkeypatch.setattr("g8_mcp_server.tools.workflows.G8Client.delete", fake)
        r = await _tool(mcp_server, "g8_workflow_delete").fn(action_id="wf-1", dry_run=True)
        assert isinstance(r, dict)
        assert r["confirm_tool"] == "g8_workflow_delete"
        fake.assert_not_called()

    async def test_path(self, mcp_server, monkeypatch):
        fake = AsyncMock(return_value={"success": True})
        monkeypatch.setattr("g8_mcp_server.tools.workflows.G8Client.delete", fake)
        await _tool(mcp_server, "g8_workflow_delete").fn(action_id="wf-1")
        assert fake.await_args.args[0] == "/workflows/wf-1"


class TestValidateWorkflow:
    async def test_path_and_body_wraps_config(self, mcp_server, monkeypatch):
        fake = AsyncMock(return_value={"errors": [], "warnings": []})
        monkeypatch.setattr("g8_mcp_server.tools.workflows.G8Client.post", fake)
        cfg = {"nodes": [], "edges": [], "startNodeId": "n0"}
        await _tool(mcp_server, "g8_workflow_validate").fn(config=cfg)
        path = fake.await_args.args[0]
        body = fake.await_args.kwargs.get("body") or fake.await_args.args[1]
        assert path == "/workflows/validate"
        # The router accepts {config: {...}}; the tool must wrap.
        assert body == {"config": cfg}


# ---------------------------------------------------------------------------
# Granular helpers — fetch + mutate + PUT
# ---------------------------------------------------------------------------


class TestAddNode:
    async def test_appends_node_and_optional_edge(self, mcp_server, monkeypatch):
        # The helper fetches first, so we need both GET and PUT mocks.
        # Seed a legacy ReactFlow-shape node to prove the helper reads
        # legacy shapes for the duplicate-id check while writing canonical.
        get_fake = AsyncMock(
            return_value={
                "action_id": "wf-1",
                "config": {
                    "nodes": [
                        {"id": "n1", "type": "scheduler", "position": {"x": 0, "y": 0}, "data": {}}
                    ],
                    "edges": [],
                    "startNodeId": "n1",
                },
            }
        )
        put_fake = AsyncMock(return_value={"action_id": "wf-1"})
        monkeypatch.setattr("g8_mcp_server.tools.workflows.G8Client.get", get_fake)
        monkeypatch.setattr("g8_mcp_server.tools.workflows.G8Client.put", put_fake)

        await _tool(mcp_server, "g8_workflow_add_node").fn(
            action_id="wf-1",
            node_id="n2",
            node_type="roam_send_message",
            config={"recipient_id": "U123", "message": "hi"},
            connect_from="n1",
        )

        put_path = put_fake.await_args.args[0]
        put_body = put_fake.await_args.kwargs.get("body") or put_fake.await_args.args[1]
        assert put_path == "/workflows/wf-1"
        cfg = put_body["config"]
        assert len(cfg["nodes"]) == 2
        # New node is written in canonical snake_case shape with flat
        # name / config and connections list (the field voice's executor
        # traverses on, NOT top-level edges).
        new_node = cfg["nodes"][-1]
        assert new_node["node_id"] == "n2"
        assert new_node["node_type"] == "roam_send_message"
        assert new_node["name"] == "roam_send_message"  # default label
        assert new_node["config"] == {"recipient_id": "U123", "message": "hi"}
        assert new_node["connections"] == []
        # Edge was appended in the production "edge-{src}-{tgt}" style.
        assert len(cfg["edges"]) == 1
        assert cfg["edges"][0]["source"] == "n1"
        assert cfg["edges"][0]["target"] == "n2"
        # CRITICAL: the source node was rewritten to canonical and its
        # connections list now includes the new node — voice's executor
        # only traverses node.connections, so missing this field would
        # mean the workflow renders but never executes.
        src_node = cfg["nodes"][0]
        assert src_node["node_id"] == "n1"
        assert src_node["node_type"] == "scheduler"
        assert src_node["connections"] == ["n2"]

    async def test_duplicate_node_id_short_circuits(self, mcp_server, monkeypatch):
        get_fake = AsyncMock(
            return_value={
                "config": {
                    "nodes": [{"id": "n1", "type": "x", "data": {}}],
                    "edges": [],
                    "startNodeId": "n1",
                }
            }
        )
        put_fake = AsyncMock()
        monkeypatch.setattr("g8_mcp_server.tools.workflows.G8Client.get", get_fake)
        monkeypatch.setattr("g8_mcp_server.tools.workflows.G8Client.put", put_fake)
        r = await _tool(mcp_server, "g8_workflow_add_node").fn(
            action_id="wf-1", node_id="n1", node_type="anything"
        )
        assert isinstance(r, str) and "already exists" in r
        put_fake.assert_not_called()

    async def test_action_node_camelcase_input_mappings_dedup(self, mcp_server, monkeypatch):
        """Action nodes auto-populate placeholders for missing skill variables.

        Regression for PRD §5.6: when the caller passes the React/frontend
        camelCase dialect (``actionId`` + ``inputMappings`` with
        ``targetField`` / ``sourceExpression``), the helper must:
          1. Recognize ``actionId`` as the skill reference (parity with ``action_id``).
          2. Read the existing camelCase mappings for dedup so already-wired
             variables don't get a second placeholder appended.
          3. Write any new placeholders back under ``inputMappings`` using
             camelCase field keys, preserving the caller's dialect.
        Earlier code only inspected snake_case keys, which silently
        re-stamped duplicates for any React-shape caller.
        """
        # Fresh graph that's just a trigger - we're appending the action
        # node after it.
        get_workflow = AsyncMock(
            return_value={
                "config": {
                    "nodes": [
                        {"node_id": "trig", "node_type": "trigger", "config": {}, "connections": []}
                    ],
                    "edges": [],
                    "startNodeId": "trig",
                }
            }
        )
        # Skill exposes three variables: contact_id (already wired in
        # camelCase by caller), recipient (new), tone (new).
        get_skill_vars = AsyncMock(
            return_value={"variables": ["contact_id", "recipient", "tone"]}
        )

        async def fake_get(self, path, **kw):  # type: ignore[no-untyped-def]
            if path.startswith("/workflows/"):
                return await get_workflow(self, path, **kw)
            if path.startswith("/skills/") and path.endswith("/variables"):
                return await get_skill_vars(self, path, **kw)
            raise AssertionError(f"unexpected GET: {path}")

        put_fake = AsyncMock(return_value={"action_id": "wf-1"})
        monkeypatch.setattr("g8_mcp_server.tools.workflows.G8Client.get", fake_get)
        monkeypatch.setattr("g8_mcp_server.tools.workflows.G8Client.put", put_fake)

        await _tool(mcp_server, "g8_workflow_add_node").fn(
            action_id="wf-1",
            node_id="act-1",
            node_type="action",
            # Caller uses React/frontend dialect throughout.
            config={
                "actionId": "skill-xyz",
                "inputMappings": [
                    {"targetField": "contact_id", "sourceExpression": "${trig.contact.id}"}
                ],
            },
            connect_from="trig",
        )

        # Skill variables endpoint was actually consulted.
        get_skill_vars.assert_awaited_once()
        called_path = get_skill_vars.await_args.args[1]
        assert called_path == "/skills/skill-xyz/variables"

        put_body = put_fake.await_args.kwargs.get("body") or put_fake.await_args.args[1]
        new_node = next(n for n in put_body["config"]["nodes"] if n.get("node_id") == "act-1")
        action_cfg = new_node["config"]

        # CRITICAL: helper preserved the caller's camelCase dialect - it
        # wrote into inputMappings (not input_mappings) and did NOT mix
        # snake_case keys onto the camelCase list.
        assert "inputMappings" in action_cfg
        assert "input_mappings" not in action_cfg
        mappings = action_cfg["inputMappings"]
        assert isinstance(mappings, list)

        # Dedup invariant: contact_id appears EXACTLY ONCE - the caller's
        # pre-wired mapping survived, and the helper didn't double-stamp.
        targets = [m["targetField"] for m in mappings]
        assert targets.count("contact_id") == 1
        # All three skill variables end up represented exactly once.
        assert set(targets) == {"contact_id", "recipient", "tone"}
        assert len(mappings) == 3

        # Caller's existing source expression preserved untouched; new
        # placeholders emitted with empty source_expression so the agent
        # / user fills them in later.
        by_tgt = {m["targetField"]: m for m in mappings}
        assert by_tgt["contact_id"]["sourceExpression"] == "${trig.contact.id}"
        assert by_tgt["recipient"]["sourceExpression"] == ""
        assert by_tgt["tone"]["sourceExpression"] == ""
        # Every emitted mapping uses camelCase keys, not snake_case.
        for m in mappings:
            assert "target_field" not in m and "source_expression" not in m


class TestUpdateNode:
    async def test_patch_label_and_config(self, mcp_server, monkeypatch):
        # Seed legacy ReactFlow shape with an existing connections list
        # so we verify the rewrite preserves it (voice's executor depends
        # on this field for traversal).
        get_fake = AsyncMock(
            return_value={
                "config": {
                    "nodes": [
                        {
                            "id": "n1",
                            "type": "llm_completion",
                            "position": {"x": 1, "y": 2},
                            "data": {"label": "old", "config": {"prompt": "old"}},
                            "connections": ["n2"],
                        }
                    ],
                    "edges": [],
                    "startNodeId": "n1",
                }
            }
        )
        put_fake = AsyncMock(return_value={})
        monkeypatch.setattr("g8_mcp_server.tools.workflows.G8Client.get", get_fake)
        monkeypatch.setattr("g8_mcp_server.tools.workflows.G8Client.put", put_fake)

        await _tool(mcp_server, "g8_workflow_update_node").fn(
            action_id="wf-1",
            node_id="n1",
            label="new",
            config={"prompt": "new"},
        )
        body = put_fake.await_args.kwargs.get("body") or put_fake.await_args.args[1]
        node = body["config"]["nodes"][0]
        # Rewritten to canonical snake_case shape with flat name/config.
        assert node["node_id"] == "n1"
        assert node["node_type"] == "llm_completion"
        assert node["name"] == "new"
        assert node["config"] == {"prompt": "new"}
        # Position preserved (caller did not pass it).
        assert node["position"] == {"x": 1, "y": 2}
        # CRITICAL: connections preserved on rewrite — losing this would
        # break executor traversal at runtime.
        assert node["connections"] == ["n2"]
        # Legacy "data" envelope dropped on rewrite.
        assert "data" not in node

    async def test_patch_conditional_connections_for_branch_node(self, mcp_server, monkeypatch):
        # Branch / condition / loop nodes use conditional_connections to
        # gate downstream paths. The helper must let callers set this map
        # directly so they can wire condition nodes from non-technical prompts.
        get_fake = AsyncMock(
            return_value={
                "config": {
                    "nodes": [
                        {
                            "node_id": "cond-1",
                            "node_type": "condition",
                            "name": "branch",
                            "config": {},
                            "position": {"x": 0, "y": 0},
                            "connections": [],
                        }
                    ],
                    "edges": [],
                    "start_node_id": "cond-1",
                }
            }
        )
        put_fake = AsyncMock(return_value={})
        monkeypatch.setattr("g8_mcp_server.tools.workflows.G8Client.get", get_fake)
        monkeypatch.setattr("g8_mcp_server.tools.workflows.G8Client.put", put_fake)

        await _tool(mcp_server, "g8_workflow_update_node").fn(
            action_id="wf-1",
            node_id="cond-1",
            conditional_connections={"path-a": "send_email-1", "path-b": "send_email-2"},
        )
        body = put_fake.await_args.kwargs.get("body") or put_fake.await_args.args[1]
        node = body["config"]["nodes"][0]
        assert node["conditional_connections"] == {
            "path-a": "send_email-1",
            "path-b": "send_email-2",
        }

    async def test_unknown_node_id(self, mcp_server, monkeypatch):
        get_fake = AsyncMock(
            return_value={"config": {"nodes": [], "edges": [], "startNodeId": "n0"}}
        )
        put_fake = AsyncMock()
        monkeypatch.setattr("g8_mcp_server.tools.workflows.G8Client.get", get_fake)
        monkeypatch.setattr("g8_mcp_server.tools.workflows.G8Client.put", put_fake)
        r = await _tool(mcp_server, "g8_workflow_update_node").fn(
            action_id="wf-1", node_id="missing", label="x"
        )
        assert isinstance(r, str) and "not found" in r
        put_fake.assert_not_called()


class TestRemoveNode:
    async def test_drops_node_and_dangling_edges(self, mcp_server, monkeypatch):
        get_fake = AsyncMock(
            return_value={
                "config": {
                    "nodes": [
                        {"id": "n1", "type": "x", "data": {}},
                        {"id": "n2", "type": "y", "data": {}},
                        {"id": "n3", "type": "z", "data": {}},
                    ],
                    "edges": [
                        {"id": "e1", "source": "n1", "target": "n2"},
                        {"id": "e2", "source": "n2", "target": "n3"},
                        {"id": "e3", "source": "n1", "target": "n3"},
                    ],
                    "startNodeId": "n1",
                }
            }
        )
        put_fake = AsyncMock(return_value={})
        monkeypatch.setattr("g8_mcp_server.tools.workflows.G8Client.get", get_fake)
        monkeypatch.setattr("g8_mcp_server.tools.workflows.G8Client.put", put_fake)

        await _tool(mcp_server, "g8_workflow_remove_node").fn(action_id="wf-1", node_id="n2")
        body = put_fake.await_args.kwargs.get("body") or put_fake.await_args.args[1]
        cfg = body["config"]
        assert {n["id"] for n in cfg["nodes"]} == {"n1", "n3"}
        # Both edges touching n2 dropped; n1->n3 survives.
        assert {e["id"] for e in cfg["edges"]} == {"e3"}

    async def test_unknown_node_id_short_circuits(self, mcp_server, monkeypatch):
        get_fake = AsyncMock(
            return_value={"config": {"nodes": [], "edges": [], "startNodeId": "n0"}}
        )
        put_fake = AsyncMock()
        monkeypatch.setattr("g8_mcp_server.tools.workflows.G8Client.get", get_fake)
        monkeypatch.setattr("g8_mcp_server.tools.workflows.G8Client.put", put_fake)
        r = await _tool(mcp_server, "g8_workflow_remove_node").fn(action_id="wf-1", node_id="missing")
        assert isinstance(r, str) and "not found" in r
        put_fake.assert_not_called()


class TestConnectNodes:
    async def test_appends_edge(self, mcp_server, monkeypatch):
        get_fake = AsyncMock(
            return_value={
                "config": {
                    "nodes": [
                        {"id": "n1", "type": "x", "data": {}},
                        {"id": "n2", "type": "y", "data": {}},
                    ],
                    "edges": [],
                    "startNodeId": "n1",
                }
            }
        )
        put_fake = AsyncMock(return_value={})
        monkeypatch.setattr("g8_mcp_server.tools.workflows.G8Client.get", get_fake)
        monkeypatch.setattr("g8_mcp_server.tools.workflows.G8Client.put", put_fake)

        await _tool(mcp_server, "g8_workflow_connect_nodes").fn(
            action_id="wf-1", source="n1", target="n2", condition="success"
        )
        body = put_fake.await_args.kwargs.get("body") or put_fake.await_args.args[1]
        edges = body["config"]["edges"]
        assert len(edges) == 1
        assert edges[0]["source"] == "n1"
        assert edges[0]["target"] == "n2"
        assert edges[0]["condition"] == "success"

    async def test_idempotent_on_existing_edge(self, mcp_server, monkeypatch):
        # When an edge between (n1, n2) already exists AND the source's
        # canonical `connections` list already contains the target, the
        # helper must not PUT a duplicate — it returns the current graph.
        # (If either side of the dual-write is missing, the helper repairs
        # it via PUT — that is the contract verified by other tests.)
        graph = {
            "config": {
                "nodes": [
                    {"node_id": "n1", "node_type": "x", "name": "x", "config": {}, "connections": ["n2"]},
                    {"node_id": "n2", "node_type": "y", "name": "y", "config": {}, "connections": []},
                ],
                "edges": [{"id": "e1", "source": "n1", "target": "n2"}],
                "startNodeId": "n1",
            }
        }
        get_fake = AsyncMock(return_value=graph)
        put_fake = AsyncMock()
        monkeypatch.setattr("g8_mcp_server.tools.workflows.G8Client.get", get_fake)
        monkeypatch.setattr("g8_mcp_server.tools.workflows.G8Client.put", put_fake)

        await _tool(mcp_server, "g8_workflow_connect_nodes").fn(
            action_id="wf-1", source="n1", target="n2"
        )
        put_fake.assert_not_called()
        # GET was called twice — once to inspect, once to return the graph
        # to the agent (the second call is the idempotent reload).
        assert get_fake.await_count == 2

    async def test_unknown_source_or_target(self, mcp_server, monkeypatch):
        get_fake = AsyncMock(
            return_value={
                "config": {
                    "nodes": [{"id": "n1", "type": "x", "data": {}}],
                    "edges": [],
                    "startNodeId": "n1",
                }
            }
        )
        put_fake = AsyncMock()
        monkeypatch.setattr("g8_mcp_server.tools.workflows.G8Client.get", get_fake)
        monkeypatch.setattr("g8_mcp_server.tools.workflows.G8Client.put", put_fake)

        r = await _tool(mcp_server, "g8_workflow_connect_nodes").fn(
            action_id="wf-1", source="n1", target="missing"
        )
        assert isinstance(r, str) and "missing" in r
        put_fake.assert_not_called()


# ---------------------------------------------------------------------------
# Lifecycle — execute + status + pause/resume/stop + reset cursor
# ---------------------------------------------------------------------------


class TestExecuteWorkflow:
    async def test_dry_run_preview(self, mcp_server, monkeypatch):
        fake = AsyncMock()
        monkeypatch.setattr("g8_mcp_server.tools.workflows.G8Client.post", fake)
        r = await _tool(mcp_server, "g8_workflow_execute").fn(action_id="wf-1", dry_run=True)
        assert isinstance(r, dict)
        assert r["confirm_tool"] == "g8_workflow_execute"
        fake.assert_not_called()

    async def test_default_input_data_empty_dict(self, mcp_server, monkeypatch):
        fake = AsyncMock(return_value={"execution_id": "ex-1", "status": "queued"})
        monkeypatch.setattr("g8_mcp_server.tools.workflows.G8Client.post", fake)
        await _tool(mcp_server, "g8_workflow_execute").fn(action_id="wf-1")
        path = fake.await_args.args[0]
        body = fake.await_args.kwargs.get("body") or fake.await_args.args[1]
        assert path == "/workflows/wf-1/execute"
        assert body == {"input_data": {}}

    async def test_input_data_and_triggered_by_forwarded(self, mcp_server, monkeypatch):
        fake = AsyncMock(return_value={"execution_id": "ex-1"})
        monkeypatch.setattr("g8_mcp_server.tools.workflows.G8Client.post", fake)
        await _tool(mcp_server, "g8_workflow_execute").fn(
            action_id="wf-1",
            input_data={"contact_email": "a@b.com"},
            triggered_by="user-99",
        )
        body = fake.await_args.kwargs.get("body") or fake.await_args.args[1]
        assert body["input_data"] == {"contact_email": "a@b.com"}
        assert body["triggered_by"] == "user-99"


class TestExecutionLifecycle:
    async def test_get_execution_path(self, mcp_server, monkeypatch):
        fake = AsyncMock(return_value={"execution_id": "ex-1", "status": "completed"})
        monkeypatch.setattr("g8_mcp_server.tools.workflows.G8Client.get", fake)
        await _tool(mcp_server, "g8_workflow_get_execution").fn(execution_id="ex-1")
        assert fake.await_args.args[0] == "/workflows/executions/ex-1"

    async def test_pause_path_and_body(self, mcp_server, monkeypatch):
        fake = AsyncMock(return_value={"execution_id": "ex-1", "status": "paused"})
        monkeypatch.setattr("g8_mcp_server.tools.workflows.G8Client.post", fake)
        await _tool(mcp_server, "g8_workflow_pause_execution").fn(
            execution_id="ex-1", reason="manual hold"
        )
        path = fake.await_args.args[0]
        body = fake.await_args.kwargs.get("body") or fake.await_args.args[1]
        assert path == "/workflows/executions/ex-1/pause"
        assert body == {"reason": "manual hold"}

    async def test_pause_empty_body_when_no_args(self, mcp_server, monkeypatch):
        fake = AsyncMock(return_value={})
        monkeypatch.setattr("g8_mcp_server.tools.workflows.G8Client.post", fake)
        await _tool(mcp_server, "g8_workflow_pause_execution").fn(execution_id="ex-1")
        # `or` would short-circuit on an empty dict, so prefer kwargs
        # explicitly, falling back to positional only when "body" is
        # genuinely absent from kwargs.
        kwargs = fake.await_args.kwargs
        body = (
            kwargs["body"]
            if "body" in kwargs
            else (fake.await_args.args[1] if len(fake.await_args.args) > 1 else None)
        )
        assert body == {}

    async def test_resume_path_and_body(self, mcp_server, monkeypatch):
        fake = AsyncMock(return_value={"execution_id": "ex-1", "status": "running"})
        monkeypatch.setattr("g8_mcp_server.tools.workflows.G8Client.post", fake)
        await _tool(mcp_server, "g8_workflow_resume_execution").fn(
            execution_id="ex-1", from_step="step-3", skip_failed=True
        )
        path = fake.await_args.args[0]
        body = fake.await_args.kwargs.get("body") or fake.await_args.args[1]
        assert path == "/workflows/executions/ex-1/resume"
        assert body == {"from_step": "step-3", "skip_failed": True}

    async def test_stop_dry_run_preview(self, mcp_server, monkeypatch):
        fake = AsyncMock()
        monkeypatch.setattr("g8_mcp_server.tools.workflows.G8Client.post", fake)
        r = await _tool(mcp_server, "g8_workflow_stop_execution").fn(
            execution_id="ex-1", dry_run=True
        )
        assert isinstance(r, dict)
        assert r["confirm_tool"] == "g8_workflow_stop_execution"
        fake.assert_not_called()

    async def test_stop_path_and_body(self, mcp_server, monkeypatch):
        fake = AsyncMock(return_value={"execution_id": "ex-1", "status": "stopped"})
        monkeypatch.setattr("g8_mcp_server.tools.workflows.G8Client.post", fake)
        await _tool(mcp_server, "g8_workflow_stop_execution").fn(
            execution_id="ex-1",
            reason="user request",
            save_partial_results=True,
        )
        path = fake.await_args.args[0]
        body = fake.await_args.kwargs.get("body") or fake.await_args.args[1]
        assert path == "/workflows/executions/ex-1/stop"
        assert body["reason"] == "user request"
        assert body["save_partial_results"] is True


class TestResetTriggerCursor:
    async def test_path_no_body(self, mcp_server, monkeypatch):
        fake = AsyncMock(return_value={"cursor": "now"})
        monkeypatch.setattr("g8_mcp_server.tools.workflows.G8Client.post", fake)
        await _tool(mcp_server, "g8_workflow_reset_trigger_cursor").fn(action_id="wf-1")
        path = fake.await_args.args[0]
        assert path == "/workflows/wf-1/trigger-reset"


# ---------------------------------------------------------------------------
# Resolver helpers — convert human descriptions ("DM Hamza", "post to
# #general") into the concrete IDs node configs require. All read-only,
# no parameters, org scoping happens via the API key on the proxy side.
# ---------------------------------------------------------------------------


# (resolver tool name, GET path forwarded to developer_api proxy)
_RESOLVER_WIRE: list[tuple[str, str]] = [
    ("g8_workflow_list_roam_users", "/workflows/integrations/roam/users"),
    ("g8_workflow_list_roam_groups", "/workflows/integrations/roam/groups"),
    ("g8_workflow_list_slack_users", "/workflows/integrations/slack/users"),
    ("g8_workflow_list_slack_channels", "/workflows/integrations/slack/channels"),
    ("g8_workflow_list_mcp_servers", "/workflows/mcp-servers"),
    ("g8_workflow_list_dispositions", "/workflows/dispositions"),
]


class TestResolverWireContract:
    @pytest.mark.parametrize("tool_name,expected_path", _RESOLVER_WIRE)
    async def test_resolver_calls_correct_path(
        self, mcp_server, monkeypatch, tool_name, expected_path
    ):
        # Each resolver is a thin proxy → forwards to a fixed GET path
        # with no params (org scoping happens via the API key in
        # developer_api). Lock the wire contract so a typo in the URL
        # path is caught at test time, not runtime.
        fake = AsyncMock(return_value={"items": []})
        monkeypatch.setattr("g8_mcp_server.tools.workflows.G8Client.get", fake)
        await _tool(mcp_server, tool_name).fn()
        assert fake.await_args.args[0] == expected_path

    @pytest.mark.parametrize("tool_name,_expected_path", _RESOLVER_WIRE)
    async def test_resolver_returns_string_on_exception(
        self, mcp_server, monkeypatch, tool_name, _expected_path
    ):
        fake = AsyncMock(side_effect=RuntimeError("voice 502"))
        monkeypatch.setattr("g8_mcp_server.tools.workflows.G8Client.get", fake)
        r = await _tool(mcp_server, tool_name).fn()
        assert isinstance(r, str) and "voice 502" in r


# ---------------------------------------------------------------------------
# Resolver consistency — every resolver_tool referenced from the node
# catalog must either (a) be a registered MCP tool, or (b) be a
# graceful "no MCP resolver yet — ask user" hint. This catches the case
# where node_catalog mentions a tool that was never wired into MCP, or
# vice-versa, before it leaks into a production workflow author session.
# ---------------------------------------------------------------------------


def _flatten_resolver_hint_values() -> list[tuple[str, str, str]]:
    """Extract (node_type, field, hint) tuples from voice's _RESOLVER_HINTS.

    Imports lazily so that unrelated test runs don't pay the import cost.
    """
    import sys

    voice_root = (
        Path(__file__).resolve().parent.parent.parent / "voice"
    )
    if str(voice_root) not in sys.path:
        sys.path.insert(0, str(voice_root))

    try:
        from graph8_livekit.services.node_catalog import _RESOLVER_HINTS
    except Exception as exc:  # pragma: no cover - import skip
        pytest.skip(f"voice node_catalog not importable from mcp_server tests: {exc}")

    out: list[tuple[str, str, str]] = []
    for node_type, fields in _RESOLVER_HINTS.items():
        for field, hint in fields.items():
            out.append((node_type, field, hint))
    return out


class TestResolverConsistency:
    """Issue 9: every resolver hint must be honest.

    A hint that names a `g8_*` MCP tool must reference one we actually
    register in `all` mode. Otherwise it must match the graceful
    "(no MCP resolver yet" pattern (a.k.a. "ask the user"). This stops
    the catalog from drifting away from the tool surface silently.
    """

    def test_resolver_hints_reference_registered_or_deferred(self, mcp_server):
        # Build the set of all g8_* tool names we register so the hint
        # check has authoritative ground truth.
        import re

        registered = set(mcp_server._tool_manager._tools.keys())

        # Extract every bare g8_* identifier anywhere in the hint string,
        # ignoring trailing call-syntax sugar like ``g8_foo(arg)`` and
        # prose punctuation like ``g8_foo.``. ``\w`` captures the full
        # tool name; everything after the name (``(arg)``, ``.``, etc.)
        # is stripped automatically because it's not a word char.
        TOOL_TOKEN = re.compile(r"\bg8_\w+")

        offenders: list[str] = []
        for node_type, field, hint in _flatten_resolver_hint_values():
            tokens = TOOL_TOKEN.findall(hint)
            if tokens:
                for tok in tokens:
                    if tok not in registered:
                        offenders.append(
                            f"{node_type}.{field}: hint references '{tok}' "
                            "which is not a registered MCP tool"
                        )
            else:
                # No g8_* token → must be a graceful deferral.
                if "no MCP resolver yet" not in hint:
                    offenders.append(
                        f"{node_type}.{field}: hint '{hint}' has no g8_* tool "
                        "and is not marked '(no MCP resolver yet — ask user)'"
                    )

        assert not offenders, (
            "Resolver hint inconsistencies (catalog references tools that "
            "do not exist, or omits a graceful ask-user fallback):\n  - "
            + "\n  - ".join(offenders)
        )


# ---------------------------------------------------------------------------
# Error formatting
# ---------------------------------------------------------------------------


class TestErrors:
    async def test_get_returns_string_on_exception(self, mcp_server, monkeypatch):
        fake = AsyncMock(side_effect=RuntimeError("voice 502"))
        monkeypatch.setattr("g8_mcp_server.tools.workflows.G8Client.get", fake)
        r = await _tool(mcp_server, "g8_workflow_get").fn(action_id="wf-1")
        assert isinstance(r, str) and "voice 502" in r

    async def test_create_returns_string_on_exception(self, mcp_server, monkeypatch):
        fake = AsyncMock(side_effect=RuntimeError("voice 502"))
        monkeypatch.setattr("g8_mcp_server.tools.workflows.G8Client.post", fake)
        cfg = {"nodes": [], "edges": [], "startNodeId": "n0"}
        r = await _tool(mcp_server, "g8_workflow_create").fn(name="x", config=cfg)
        assert isinstance(r, str) and "voice 502" in r


# ---------------------------------------------------------------------------
# Round-trip integration — exercise the realistic build flow:
# create empty workflow → add trigger node → add lookup node →
# add add_to_list node → connect them with cross-node variable
# substitution → validate. This is Issue 10: prove the helpers compose
# correctly so an LLM can assemble a working graph using only the MCP
# tool surface, no out-of-band edits to skill_config.
# ---------------------------------------------------------------------------


class TestRoundTripIntegration:
    async def test_form_trigger_lookup_add_to_list_compose(self, mcp_server, monkeypatch):
        # Mutable graph that the fake backend keeps in sync as PUTs land.
        # Models the voice-side state so the LLM-style multi-step flow
        # (each step fetches the latest skill_config, mutates, PUTs it
        # back) actually composes the way it would against a real server.
        graph: dict = {
            "action_id": "wf-rt-1",
            "name": "Round trip",
            "config": {"nodes": [], "edges": [], "startNodeId": "trigger_1"},
            "enabled": False,
        }

        # NOTE: rest of the suite uses AsyncMock which does *not* bind
        # `self`, so signatures look like `(path, body)`. Here we use
        # plain `async def` because we need stateful behavior across
        # several calls — and a plain async function IS a descriptor,
        # so it receives `self` as the first positional arg. We pull
        # the second positional arg as `path` accordingly.
        async def fake_get(_self, path, *args, **kwargs):
            if path == "/workflows/wf-rt-1":
                # Return a deep-ish copy so mutations on the helper side
                # don't bleed into the source-of-truth dict before the
                # PUT lands.
                import copy

                return copy.deepcopy(graph)
            raise AssertionError(f"unexpected GET: {path}")

        async def fake_put(_self, path, body=None, *args, **kwargs):
            assert path == "/workflows/wf-rt-1"
            body = body if body is not None else kwargs.get("body")
            assert body and "config" in body
            graph["config"] = body["config"]
            return {"action_id": "wf-rt-1"}

        async def fake_post(_self, path, body=None, *args, **kwargs):
            body = body if body is not None else kwargs.get("body")
            if path == "/workflows":
                cfg = body["config"]
                graph["config"] = cfg
                return {"action_id": "wf-rt-1"}
            if path == "/workflows/validate":
                # Trivial validator: errors only if there's no startNodeId
                # and at least one node.
                cfg = body["config"]
                errors = []
                if cfg.get("nodes") and not (cfg.get("startNodeId") or cfg.get("start_node_id")):
                    errors.append("startNodeId required")
                # Sanity: every edge must reference real node ids. Read
                # both legacy `id` and canonical `node_id` so the mock
                # tolerates the mixed-shape graph the round-trip produces.
                node_ids = {
                    (n.get("node_id") or n.get("nodeId") or n.get("id"))
                    for n in cfg.get("nodes", [])
                }
                for e in cfg.get("edges", []):
                    if e["source"] not in node_ids or e["target"] not in node_ids:
                        errors.append(f"dangling edge {e.get('id')}")
                return {"errors": errors, "warnings": []}
            raise AssertionError(f"unexpected POST: {path}")

        monkeypatch.setattr("g8_mcp_server.tools.workflows.G8Client.get", fake_get)
        monkeypatch.setattr("g8_mcp_server.tools.workflows.G8Client.put", fake_put)
        monkeypatch.setattr("g8_mcp_server.tools.workflows.G8Client.post", fake_post)

        # Step 1 — create workflow with the trigger already in place.
        # The frontend convention is that a trigger node is the
        # startNodeId, so we seed it via create() rather than using
        # add_node(); then bolt the rest of the graph onto it.
        seed_cfg = {
            "nodes": [
                {
                    "id": "trigger_1",
                    "type": "trigger",
                    "position": {"x": 0, "y": 0},
                    "data": {
                        "label": "On form submission",
                        "config": {
                            "trigger_type": "new_form_submission",
                            "form_id": "form-abc",
                        },
                    },
                }
            ],
            "edges": [],
            "startNodeId": "trigger_1",
        }
        create_r = await _tool(mcp_server, "g8_workflow_create").fn(
            name="Round trip", config=seed_cfg
        )
        assert isinstance(create_r, dict) and create_r["action_id"] == "wf-rt-1"

        # Step 2 — append a lookup node and wire it from the trigger.
        await _tool(mcp_server, "g8_workflow_add_node").fn(
            action_id="wf-rt-1",
            node_id="lookup_1",
            node_type="lookup",
            config={
                "entity_type": "contact",
                "lookup_field": "email",
                # Cross-node variable substitution: pull email out of the
                # form trigger payload. This is the contract that voice's
                # _resolve_expression honors at runtime.
                "lookup_value": "${trigger.contact_email}",
            },
            connect_from="trigger_1",
        )

        # Step 3 — append an add_to_list node and wire it from the lookup.
        await _tool(mcp_server, "g8_workflow_add_node").fn(
            action_id="wf-rt-1",
            node_id="addlist_1",
            node_type="add_to_list",
            config={
                "list_id": "list-xyz",
                # Cross-node substitution against the lookup result.
                "input_mappings": [
                    {
                        "target_field": "contact_id",
                        "source_expression": "${lookup_1.contact.id}",
                    }
                ],
            },
            connect_from="lookup_1",
        )

        # Now graph["config"] should hold all three nodes + two edges,
        # threaded trigger → lookup → add_to_list. The seeded trigger is
        # a legacy ReactFlow-shape row (id/type/data) that gets rewritten
        # to canonical when add_node wires from it; the helpers added by
        # add_node are canonical (node_id/node_type/connections). The
        # shape-tolerant lookups below cover both.
        cfg = graph["config"]

        def _id(n):
            return n.get("node_id") or n.get("nodeId") or n.get("id")

        def _cfg(n):
            cfg_field = n.get("config")
            if isinstance(cfg_field, dict):
                return cfg_field
            data = n.get("data")
            if isinstance(data, dict) and isinstance(data.get("config"), dict):
                return data["config"]
            return {}

        assert {_id(n) for n in cfg["nodes"]} == {"trigger_1", "lookup_1", "addlist_1"}
        edge_pairs = {(e["source"], e["target"]) for e in cfg["edges"]}
        assert edge_pairs == {("trigger_1", "lookup_1"), ("lookup_1", "addlist_1")}

        # Variable substitution survived the round-trip on both shapes.
        lookup_node = next(n for n in cfg["nodes"] if _id(n) == "lookup_1")
        assert _cfg(lookup_node)["lookup_value"] == "${trigger.contact_email}"
        addlist_node = next(n for n in cfg["nodes"] if _id(n) == "addlist_1")
        mappings = _cfg(addlist_node)["input_mappings"]
        assert mappings[0]["source_expression"] == "${lookup_1.contact.id}"
        assert mappings[0]["target_field"] == "contact_id"

        # CRITICAL: voice's executor traverses via node.connections[0],
        # not via top-level edges. Verify the dual-write was performed by
        # add_node so the workflow would actually execute end-to-end.
        trigger_node = next(n for n in cfg["nodes"] if _id(n) == "trigger_1")
        assert trigger_node.get("connections") == ["lookup_1"]
        assert lookup_node.get("connections") == ["addlist_1"]
        assert addlist_node.get("connections", []) == []

        # Step 4 — validate the assembled graph end-to-end.
        validate_r = await _tool(mcp_server, "g8_workflow_validate").fn(config=cfg)
        assert isinstance(validate_r, dict)
        assert validate_r["errors"] == []
        assert validate_r["warnings"] == []
