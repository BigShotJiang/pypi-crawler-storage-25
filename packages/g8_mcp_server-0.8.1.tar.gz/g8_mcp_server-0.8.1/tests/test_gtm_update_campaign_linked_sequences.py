"""Unit tests for the MCP ``g8_gtm_update_campaign`` + ``g8_gtm_patch_campaign_full``
tools — specifically the 0.8.0 ``linked_sequence_ids`` / ``unlink_sequence_ids``
kitchen-sink kwargs added in PRD ``mcp-campaigns-full-cycle``.

The kwargs MUST:
  1. Be optional (omitting them = unchanged legacy ``PATCH /campaigns/{id}`` behavior)
  2. Trigger the kitchen-sink ``PATCH /campaigns/{id}/full`` route when set
  3. Be forwarded verbatim in the body (no transformation, no surprises)
  4. Co-exist with the older kitchen-sink kwargs (audience, documents, sequence_steps)
"""

from __future__ import annotations

from pathlib import Path
from unittest.mock import AsyncMock

import pytest

import g8_mcp_server.client as client_module
from g8_mcp_server.client import G8Client


@pytest.fixture
def mock_env(monkeypatch):
    monkeypatch.setenv("G8_API_KEY", "test_key_123")
    monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
    monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))


@pytest.fixture
def client(mock_env):
    return G8Client()


def _register_gtm_tools(client):
    from mcp.server import FastMCP

    from g8_mcp_server.tools import gtm

    server = FastMCP("test")
    gtm.register(server, client)
    return server, server._tool_manager._tools


def _tool_by_suffix(tools: dict, suffix: str):
    """Find a registered tool whose name ends with ``suffix``.

    Tools register as ``g8_<verb>`` in gtm-only mode and ``g8_gtm_<verb>``
    in ``all`` mode — match on suffix so the test is mode-agnostic.
    """
    for name, tool in tools.items():
        if name.endswith(suffix):
            return name, tool
    raise AssertionError(f"No tool matching suffix {suffix!r} registered. Have: {list(tools)}")


class TestUpdateCampaignBackwardsCompat:
    """Without any new kwargs, ``update_campaign`` MUST behave exactly as before:
    ``PATCH /campaigns/{id}`` with just the campaign fields. Nothing else."""

    def test_tool_registered(self, client):
        _, tools = _register_gtm_tools(client)
        _tool_by_suffix(tools, "update_campaign")

    @pytest.mark.asyncio
    async def test_partial_update_no_kitchen_sink_kwargs(self, client):
        _, tools = _register_gtm_tools(client)
        _, tool = _tool_by_suffix(tools, "update_campaign")

        client.patch = AsyncMock(return_value={"data": {"id": "camp-1", "name": "Renamed"}})

        await tool.fn(campaign_id="camp-1", name="Renamed")

        # MUST hit the partial route, NOT /full
        client.patch.assert_called_once()
        called_path = client.patch.call_args.args[0]
        called_body = client.patch.call_args.args[1]
        assert called_path == "/campaigns/camp-1", (
            f"backwards-compat broken: legacy update_campaign hit {called_path!r}, expected /campaigns/camp-1"
        )
        # Body must contain ONLY the provided field (no detach_audience leak, no
        # linked_sequence_ids/unlink_sequence_ids leak)
        assert called_body == {"name": "Renamed"}


class TestUpdateCampaignLinkedSequenceIds:
    """``linked_sequence_ids`` is one of the kitchen-sink triggers in 0.8.0.
    Providing it MUST route through /campaigns/{id}/full and forward the IDs
    verbatim."""

    @pytest.mark.asyncio
    async def test_routes_through_full_endpoint(self, client):
        _, tools = _register_gtm_tools(client)
        _, tool = _tool_by_suffix(tools, "update_campaign")

        client.patch = AsyncMock(return_value={"data": {"id": "camp-1"}})

        await tool.fn(
            campaign_id="camp-1",
            linked_sequence_ids=["seq-a", "seq-b"],
        )

        client.patch.assert_called_once()
        called_path = client.patch.call_args.args[0]
        called_body = client.patch.call_args.args[1]
        assert called_path == "/campaigns/camp-1/full", (
            f"linked_sequence_ids must trigger /full, hit {called_path!r}"
        )
        assert called_body == {"linked_sequence_ids": ["seq-a", "seq-b"]}

    @pytest.mark.asyncio
    async def test_unlink_routes_through_full_endpoint(self, client):
        _, tools = _register_gtm_tools(client)
        _, tool = _tool_by_suffix(tools, "update_campaign")

        client.patch = AsyncMock(return_value={"data": {"id": "camp-1"}})

        await tool.fn(
            campaign_id="camp-1",
            unlink_sequence_ids=["seq-old"],
        )

        client.patch.assert_called_once_with(
            "/campaigns/camp-1/full",
            {"unlink_sequence_ids": ["seq-old"]},
        )

    @pytest.mark.asyncio
    async def test_link_and_unlink_can_coexist(self, client):
        """An agent may want to swap a linked sequence in one call (unlink old,
        link new). Both lists ride in the same body — no precedence weirdness."""
        _, tools = _register_gtm_tools(client)
        _, tool = _tool_by_suffix(tools, "update_campaign")

        client.patch = AsyncMock(return_value={"data": {"id": "camp-1"}})

        await tool.fn(
            campaign_id="camp-1",
            linked_sequence_ids=["seq-new"],
            unlink_sequence_ids=["seq-old"],
        )

        called_body = client.patch.call_args.args[1]
        assert called_body == {
            "linked_sequence_ids": ["seq-new"],
            "unlink_sequence_ids": ["seq-old"],
        }

    @pytest.mark.asyncio
    async def test_link_with_other_fields_combines(self, client):
        """Sequence-link kwargs must NOT crowd out the other kitchen-sink
        kwargs. All forwarded keys appear in the body."""
        _, tools = _register_gtm_tools(client)
        _, tool = _tool_by_suffix(tools, "update_campaign")

        client.patch = AsyncMock(return_value={"data": {"id": "camp-1"}})

        await tool.fn(
            campaign_id="camp-1",
            name="Renamed",
            primary_hook="hook",
            audience_list_id="list-9",
            linked_sequence_ids=["seq-a"],
        )

        called_path = client.patch.call_args.args[0]
        called_body = client.patch.call_args.args[1]
        assert called_path == "/campaigns/camp-1/full"
        assert called_body == {
            "name": "Renamed",
            "primary_hook": "hook",
            "audience_list_id": "list-9",
            "linked_sequence_ids": ["seq-a"],
        }


class TestPatchCampaignFullLinkedSequences:
    """The standalone ``patch_campaign_full`` tool exposes the same kwargs as
    a deliberate discoverable surface. They must forward identically."""

    @pytest.mark.asyncio
    async def test_link_and_unlink_forward_into_full_body(self, client):
        _, tools = _register_gtm_tools(client)
        _, tool = _tool_by_suffix(tools, "patch_campaign_full")

        client.patch = AsyncMock(return_value={"data": {"id": "camp-1"}})

        await tool.fn(
            campaign_id="camp-1",
            linked_sequence_ids=["seq-a", "seq-b"],
            unlink_sequence_ids=["seq-c"],
        )

        client.patch.assert_called_once_with(
            "/campaigns/camp-1/full",
            {
                "linked_sequence_ids": ["seq-a", "seq-b"],
                "unlink_sequence_ids": ["seq-c"],
            },
        )

    @pytest.mark.asyncio
    async def test_empty_call_still_targets_full(self, client):
        """Unlike update_campaign, patch_campaign_full ALWAYS hits /full — even
        when no kwargs are provided. That's the explicit promise of the tool."""
        _, tools = _register_gtm_tools(client)
        _, tool = _tool_by_suffix(tools, "patch_campaign_full")

        client.patch = AsyncMock(return_value={"data": {"id": "camp-1"}})

        await tool.fn(campaign_id="camp-1")

        called_path = client.patch.call_args.args[0]
        assert called_path == "/campaigns/camp-1/full"
