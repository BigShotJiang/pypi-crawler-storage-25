"""Tests for the g8_intent_* MCP suite (14 tools covering pages, keywords, URL drill-down)."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import AsyncMock

import pytest

import g8_mcp_server.client as client_module
from g8_mcp_server.server import create_server


@pytest.fixture
def mcp_server(monkeypatch):
    monkeypatch.setenv("G8_API_KEY", "test_key")
    monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
    monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent"))
    return create_server()


def _tool(server, name):
    return server._tool_manager._tools[name]


def _read_only(tool) -> bool:
    ann = tool.annotations
    flag = getattr(ann, "readOnlyHint", None)
    if flag is None and isinstance(ann, dict):
        flag = ann.get("readOnlyHint")
    return bool(flag)


# ---------------------------------------------------------------------------
# Registration - all 13 tools present under the g8_intent_ namespace
# ---------------------------------------------------------------------------


class TestRegistration:
    """Sanity: all 14 tools register and have the expected names.

    If any of these asserts fails it means a tool got dropped from
    `register()` in tools/intent.py - the MCP client will surface fewer
    tools than documented."""

    EXPECTED_NAMES = [
        # Pages layer (6)
        "g8_intent_domain_search",
        "g8_intent_search_pages",
        "g8_intent_page_visitors",
        "g8_intent_pages_contacts",
        "g8_intent_pages_visitor_counts",
        "g8_intent_stats",
        # Keywords layer (7)
        "g8_intent_list_keywords",
        "g8_intent_create_from_domain",
        "g8_intent_delete_keyword",
        "g8_intent_keyword_urls",
        "g8_intent_keyword_contacts",
        "g8_intent_keyword_companies",
        "g8_intent_update_keyword_filters",
        # URL drill-down (1)
        "g8_intent_search_url_companies",
    ]

    def test_all_tools_registered(self, mcp_server):
        for name in self.EXPECTED_NAMES:
            assert name in mcp_server._tool_manager._tools, f"Missing: {name}"

    def test_read_only_tools_tagged(self, mcp_server):
        for name in [
            "g8_intent_domain_search",
            "g8_intent_search_pages",
            "g8_intent_page_visitors",
            "g8_intent_pages_contacts",
            "g8_intent_pages_visitor_counts",
            "g8_intent_stats",
            "g8_intent_list_keywords",
            "g8_intent_keyword_urls",
            "g8_intent_keyword_contacts",
            "g8_intent_keyword_companies",
            "g8_intent_search_url_companies",
        ]:
            assert _read_only(_tool(mcp_server, name)), f"{name} should be read-only"

    def test_write_tools_are_not_read_only(self, mcp_server):
        # create + update filters mutate; delete is destructive - none read-only.
        for name in [
            "g8_intent_create_from_domain",
            "g8_intent_update_keyword_filters",
            "g8_intent_delete_keyword",
        ]:
            assert not _read_only(_tool(mcp_server, name)), f"{name} should not be read-only"


# ---------------------------------------------------------------------------
# Per-tool request / response shape
# ---------------------------------------------------------------------------


class TestDomainSearch:
    async def test_happy_path(self, mcp_server, monkeypatch):
        fake = AsyncMock(return_value={"data": {"domain": "cognism.com", "total_hits": 1, "pages": [], "took_ms": 5}})
        monkeypatch.setattr("g8_mcp_server.tools.intent.G8Client.post", fake)
        r = await _tool(mcp_server, "g8_intent_domain_search").fn(domain="cognism.com", limit=10)
        path, body = fake.await_args.args[:2]
        assert path == "/intent/pages-by-domain"
        assert body == {"domain": "cognism.com", "limit": 10}
        assert r["domain"] == "cognism.com"

    async def test_limit_clamp(self, mcp_server, monkeypatch):
        fake = AsyncMock(return_value={"data": {"domain": "x.com", "total_hits": 0, "pages": [], "took_ms": 1}})
        monkeypatch.setattr("g8_mcp_server.tools.intent.G8Client.post", fake)
        await _tool(mcp_server, "g8_intent_domain_search").fn(domain="x.com", limit=99999)
        assert fake.await_args.args[1]["limit"] == 500

    async def test_error_returns_string(self, mcp_server, monkeypatch):
        fake = AsyncMock(side_effect=RuntimeError("down"))
        monkeypatch.setattr("g8_mcp_server.tools.intent.G8Client.post", fake)
        r = await _tool(mcp_server, "g8_intent_domain_search").fn(domain="x.com")
        assert isinstance(r, str) and "down" in r


class TestSearchPages:
    async def test_forwards_all_params(self, mcp_server, monkeypatch):
        fake = AsyncMock(return_value={"data": {"query": "ai sdr", "mode": "text", "total_hits": 2, "pages": [], "took_ms": 10}})
        monkeypatch.setattr("g8_mcp_server.tools.intent.G8Client.post", fake)
        await _tool(mcp_server, "g8_intent_search_pages").fn(
            query="ai sdr", limit=25, semantic_ratio=0.5,
            filters={"audience": "b2b"}, sort=["commercial_score:desc"],
            include_visitors=False,
        )
        path, body = fake.await_args.args[:2]
        assert path == "/intent/pages/search"
        assert body["query"] == "ai sdr"
        assert body["limit"] == 25
        assert body["semantic_ratio"] == 0.5
        assert body["filters"] == {"audience": "b2b"}
        assert body["sort"] == ["commercial_score:desc"]
        assert body["include_visitors"] is False

    async def test_semantic_ratio_clamp(self, mcp_server, monkeypatch):
        fake = AsyncMock(return_value={"data": {"query": "x", "mode": "text", "total_hits": 0, "pages": [], "took_ms": 1}})
        monkeypatch.setattr("g8_mcp_server.tools.intent.G8Client.post", fake)
        await _tool(mcp_server, "g8_intent_search_pages").fn(query="x", semantic_ratio=9.0)
        assert fake.await_args.args[1]["semantic_ratio"] == 1.0
        await _tool(mcp_server, "g8_intent_search_pages").fn(query="x", semantic_ratio=-1.0)
        assert fake.await_args.args[1]["semantic_ratio"] == 0.0


class TestPageVisitors:
    async def test_path_and_body(self, mcp_server, monkeypatch):
        fake = AsyncMock(return_value={"url": "cognism.com", "visitors": []})
        monkeypatch.setattr("g8_mcp_server.tools.intent.G8Client.post", fake)
        await _tool(mcp_server, "g8_intent_page_visitors").fn(
            url="cognism.com", limit=10, mode="full",
        )
        path, body = fake.await_args.args[:2]
        assert path == "/intent/pages/visitors"
        assert body == {"url": "cognism.com", "limit": 10, "mode": "full"}


class TestPagesContacts:
    async def test_path_and_body(self, mcp_server, monkeypatch):
        fake = AsyncMock(return_value={"contacts": [], "total": 0, "resolved": 0, "hasMore": False, "tookMs": 1})
        monkeypatch.setattr("g8_mcp_server.tools.intent.G8Client.post", fake)
        urls = ["cognism.com/pricing", "cognism.com/about"]
        await _tool(mcp_server, "g8_intent_pages_contacts").fn(urls=urls, limit=50, mode="full")
        path, body = fake.await_args.args[:2]
        assert path == "/intent/pages/contacts"
        assert body["urls"] == urls
        assert body["mode"] == "full"
        assert body["limit"] == 50


class TestPagesVisitorCounts:
    async def test_path_and_body(self, mcp_server, monkeypatch):
        fake = AsyncMock(return_value={"counts": {"cognism.com/pricing": 42}})
        monkeypatch.setattr("g8_mcp_server.tools.intent.G8Client.post", fake)
        r = await _tool(mcp_server, "g8_intent_pages_visitor_counts").fn(
            urls=["cognism.com/pricing", "cognism.com/about"],
        )
        path, body = fake.await_args.args[:2]
        assert path == "/intent/pages/visitor-counts"
        assert body == {"urls": ["cognism.com/pricing", "cognism.com/about"]}
        assert r["counts"]["cognism.com/pricing"] == 42


class TestStats:
    async def test_uses_get(self, mcp_server, monkeypatch):
        fake_get = AsyncMock(return_value={"numberOfDocuments": 1234, "indexSizeBytes": 99})
        monkeypatch.setattr("g8_mcp_server.tools.intent.G8Client.get", fake_get)
        r = await _tool(mcp_server, "g8_intent_stats").fn()
        path = fake_get.await_args.args[0]
        assert path == "/intent/stats"
        assert r["numberOfDocuments"] == 1234


class TestListKeywords:
    async def test_path_and_substring_filter(self, mcp_server, monkeypatch):
        fake = AsyncMock(return_value={"rows": [], "total": 0, "page": 1, "limit": 100})
        monkeypatch.setattr("g8_mcp_server.tools.intent.G8Client.post", fake)
        await _tool(mcp_server, "g8_intent_list_keywords").fn(keyword_contains="cognism")
        path, body = fake.await_args.args[:2]
        assert path == "/intent/keywords/list"
        assert body["keyword_contains"] == "cognism"

    async def test_no_filter_when_empty(self, mcp_server, monkeypatch):
        fake = AsyncMock(return_value={"rows": [], "total": 0, "page": 1, "limit": 100})
        monkeypatch.setattr("g8_mcp_server.tools.intent.G8Client.post", fake)
        await _tool(mcp_server, "g8_intent_list_keywords").fn()
        body = fake.await_args.args[1]
        assert "keyword_contains" not in body


class TestCreateFromDomain:
    async def test_limit_clamps(self, mcp_server, monkeypatch):
        fake = AsyncMock(return_value={"data": {
            "keyword_id": "abc", "keyword": "cognism.com",
            "pages_seeded": 5, "contacts_seeded": 12,
            "companies_seeded": 4, "off_domain_rejected": 0,
            "message": "success",
        }})
        monkeypatch.setattr("g8_mcp_server.tools.intent.G8Client.post", fake)
        await _tool(mcp_server, "g8_intent_create_from_domain").fn(
            domain="cognism.com", page_limit=9999, contact_limit=9999,
        )
        path, body = fake.await_args.args[:2]
        assert path == "/intent/keywords/create-from-domain"
        assert body["page_limit"] == 500
        assert body["contact_limit"] == 500

    async def test_unwraps_envelope(self, mcp_server, monkeypatch):
        fake = AsyncMock(return_value={"data": {
            "keyword_id": "abc", "keyword": "x.com", "pages_seeded": 1,
            "contacts_seeded": 0, "companies_seeded": 0,
            "off_domain_rejected": 0, "message": "done",
        }})
        monkeypatch.setattr("g8_mcp_server.tools.intent.G8Client.post", fake)
        r = await _tool(mcp_server, "g8_intent_create_from_domain").fn(domain="x.com")
        assert r["keyword_id"] == "abc"
        assert r["keyword"] == "x.com"


class TestDeleteKeyword:
    async def test_uses_delete(self, mcp_server, monkeypatch):
        fake_del = AsyncMock(return_value={"status": "success", "message": "Keyword deleted"})
        monkeypatch.setattr("g8_mcp_server.tools.intent.G8Client.delete", fake_del)
        r = await _tool(mcp_server, "g8_intent_delete_keyword").fn(keyword_id="abc-123")
        path = fake_del.await_args.args[0]
        assert path == "/intent/keywords/abc-123"
        assert r["status"] == "success"


class TestKeywordDrilldowns:
    async def test_keyword_urls_path(self, mcp_server, monkeypatch):
        fake = AsyncMock(return_value={"rows": [], "total": 0, "page": 1, "limit": 100})
        monkeypatch.setattr("g8_mcp_server.tools.intent.G8Client.post", fake)
        await _tool(mcp_server, "g8_intent_keyword_urls").fn(keyword_id="abc-123", limit=50)
        path, body = fake.await_args.args[:2]
        assert path == "/intent/keywords/abc-123/urls"
        assert body == {"page": 1, "limit": 50, "conditions": []}

    async def test_keyword_contacts_path(self, mcp_server, monkeypatch):
        fake = AsyncMock(return_value={"rows": [], "total": 0, "page": 1, "limit": 100})
        monkeypatch.setattr("g8_mcp_server.tools.intent.G8Client.post", fake)
        await _tool(mcp_server, "g8_intent_keyword_contacts").fn(keyword_id="abc-123")
        path = fake.await_args.args[0]
        assert path == "/intent/keywords/abc-123/contacts"

    async def test_keyword_companies_path(self, mcp_server, monkeypatch):
        fake = AsyncMock(return_value={"rows": [], "total": 0, "page": 1, "limit": 100})
        monkeypatch.setattr("g8_mcp_server.tools.intent.G8Client.post", fake)
        await _tool(mcp_server, "g8_intent_keyword_companies").fn(keyword_id="abc-123")
        path = fake.await_args.args[0]
        assert path == "/intent/keywords/abc-123/companies"


class TestUpdateKeywordFilters:
    async def test_forwards_filters(self, mcp_server, monkeypatch):
        fake = AsyncMock(return_value={"status": "success", "keyword_id": "abc"})
        monkeypatch.setattr("g8_mcp_server.tools.intent.G8Client.post", fake)
        filters = {
            "audience": "b2b",
            "exclude_page_types": ["news", "forum"],
            "min_commercial_intent_level": 40,
            "exclude_domains": ["wikipedia.org"],
        }
        await _tool(mcp_server, "g8_intent_update_keyword_filters").fn(
            keyword_id="abc", search_filters=filters,
        )
        path, body = fake.await_args.args[:2]
        assert path == "/intent/keywords/abc/filters"
        assert body == {"search_filters": filters}


class TestSearchUrlCompanies:
    """g8_intent_search_url_companies wraps POST /intent-search/url-companies."""

    async def test_happy_path(self, mcp_server, monkeypatch):
        fake = AsyncMock(
            return_value={
                "data": {
                    "url": "cognism.com/pricing",
                    "total_companies": 3,
                    "b2b_count": 2,
                    "b2c_count": 1,
                    "companies": [],
                }
            }
        )
        monkeypatch.setattr("g8_mcp_server.tools.intent.G8Client.post", fake)
        r = await _tool(mcp_server, "g8_intent_search_url_companies").fn(
            url="cognism.com/pricing", days=30, limit=50,
        )
        path, body = fake.await_args.args[:2]
        assert path == "/intent-search/url-companies"
        assert body == {"url": "cognism.com/pricing", "days": 30, "limit": 50}
        assert r["url"] == "cognism.com/pricing"
        assert r["total_companies"] == 3

    async def test_defaults(self, mcp_server, monkeypatch):
        fake = AsyncMock(
            return_value={
                "data": {
                    "url": "x.com/y",
                    "total_companies": 0,
                    "b2b_count": 0,
                    "b2c_count": 0,
                    "companies": [],
                }
            }
        )
        monkeypatch.setattr("g8_mcp_server.tools.intent.G8Client.post", fake)
        await _tool(mcp_server, "g8_intent_search_url_companies").fn(url="x.com/y")
        body = fake.await_args.args[1]
        assert body["days"] == 90
        assert body["limit"] == 200

    async def test_clamps_days_and_limit(self, mcp_server, monkeypatch):
        fake = AsyncMock(
            return_value={
                "data": {
                    "url": "x.com/y",
                    "total_companies": 0,
                    "b2b_count": 0,
                    "b2c_count": 0,
                    "companies": [],
                }
            }
        )
        monkeypatch.setattr("g8_mcp_server.tools.intent.G8Client.post", fake)
        await _tool(mcp_server, "g8_intent_search_url_companies").fn(
            url="x.com/y", days=99999, limit=99999,
        )
        body = fake.await_args.args[1]
        assert body["days"] == 365
        assert body["limit"] == 500

    async def test_clamps_minimums(self, mcp_server, monkeypatch):
        fake = AsyncMock(
            return_value={
                "data": {
                    "url": "x.com/y",
                    "total_companies": 0,
                    "b2b_count": 0,
                    "b2c_count": 0,
                    "companies": [],
                }
            }
        )
        monkeypatch.setattr("g8_mcp_server.tools.intent.G8Client.post", fake)
        await _tool(mcp_server, "g8_intent_search_url_companies").fn(
            url="x.com/y", days=0, limit=0,
        )
        body = fake.await_args.args[1]
        assert body["days"] == 1
        assert body["limit"] == 1

    async def test_error_returns_string(self, mcp_server, monkeypatch):
        fake = AsyncMock(side_effect=RuntimeError("opensearch down"))
        monkeypatch.setattr("g8_mcp_server.tools.intent.G8Client.post", fake)
        r = await _tool(mcp_server, "g8_intent_search_url_companies").fn(url="x.com/y")
        assert isinstance(r, str)
        assert "opensearch down" in r


# ---------------------------------------------------------------------------
# Always-on visibility for the four keyword-layer entry points
# ---------------------------------------------------------------------------


class TestIntentAlwaysOn:
    """Intent + URL-drilldown tools are deliberately progressive-discovery only.

    Up to v0.6.3 the four keyword-layer entry points (list_keywords,
    create_from_domain, keyword_contacts, keyword_companies) were in
    ``_ALWAYS_ON_TOOLS``. v0.6.4 demoted them to progressive discovery to
    free always-on slots for the CRM CRUD set (task/note/deal). Agents still
    reach them via ``g8_tool_search("intent")`` or ``g8_tool_search("keyword")``.

    This test locks in that demotion — promoting any of these back to
    always-on must be an intentional decision, not an accident.
    """

    PROGRESSIVE_ONLY = frozenset({
        "g8_intent_list_keywords",
        "g8_intent_create_from_domain",
        "g8_intent_keyword_contacts",
        "g8_intent_keyword_companies",
    })

    def test_intent_entry_points_stay_progressive(self):
        from g8_mcp_server.server import _ALWAYS_ON_TOOLS

        leaked = self.PROGRESSIVE_ONLY & _ALWAYS_ON_TOOLS
        assert not leaked, (
            f"Intent entry-point tools unexpectedly in _ALWAYS_ON_TOOLS: {sorted(leaked)}. "
            f"v0.6.4 demoted these to progressive discovery to free slots for the "
            f"CRM CRUD set. Re-promoting them must be an intentional decision."
        )

    def test_pages_layer_stays_progressive(self):
        """Pages-layer tools (advanced research) are deliberately NOT always-on.

        This guards against accidentally promoting them in a future edit and
        bloating the always-on context tax beyond the ~25-tool budget.
        """
        from g8_mcp_server.server import _ALWAYS_ON_TOOLS

        for name in [
            "g8_intent_domain_search",
            "g8_intent_search_pages",
            "g8_intent_page_visitors",
            "g8_intent_pages_contacts",
            "g8_intent_pages_visitor_counts",
            "g8_intent_stats",
            "g8_intent_search_url_companies",
        ]:
            assert name not in _ALWAYS_ON_TOOLS, (
                f"{name} unexpectedly promoted to always-on. Pages-layer + "
                f"URL-drilldown tools should stay behind progressive discovery."
            )


# ---------------------------------------------------------------------------
# Prompt registration: `competitor_intent_setup`
# ---------------------------------------------------------------------------


def _has_prompt(server, name: str) -> bool:
    """Return True if `name` is registered as a prompt on `server`."""
    pm = getattr(server, "_prompt_manager", None)
    prompts = getattr(pm, "_prompts", None) if pm is not None else None
    if isinstance(prompts, dict):
        return name in prompts
    # Older mcp versions expose a list of Prompt objects.
    if prompts is None:
        return False
    for p in prompts:
        if getattr(p, "name", None) == name:
            return True
    return False


class TestCompetitorIntentPrompt:
    """The `competitor_intent_setup` prompt must register in GTM modes only.

    GTM and `all` modes get the prompt; `dev` mode does not (its tool surface
    has different identifiers and the workflow is GTM-shaped).

    These tests bypass `create_server()` because module-level `MCP_MODE` is
    captured at import time - we exercise `prompts.register()` directly with
    the mode argument the tests need.
    """

    def _build(self, mode: str):
        from mcp.server import FastMCP

        from g8_mcp_server import prompts as prompts_module

        server = FastMCP("test", instructions="test")
        prompts_module.register(server, mode=mode)
        return server

    def test_prompt_registered_in_all_mode(self):
        server = self._build("all")
        assert _has_prompt(server, "competitor_intent_setup"), (
            "competitor_intent_setup should be registered in `all` mode"
        )

    def test_prompt_registered_in_gtm_mode(self):
        server = self._build("gtm")
        assert _has_prompt(server, "competitor_intent_setup"), (
            "competitor_intent_setup should be registered in `gtm` mode"
        )

    def test_prompt_not_registered_in_dev_mode(self):
        server = self._build("dev")
        assert not _has_prompt(server, "competitor_intent_setup"), (
            "competitor_intent_setup must NOT register in `dev` mode"
        )


# ---------------------------------------------------------------------------
# Resource registration: `g8://intent/keywords`
# ---------------------------------------------------------------------------


def _has_resource(server, uri: str) -> bool:
    """Return True if `uri` is registered as a resource on `server`."""
    rm = getattr(server, "_resource_manager", None)
    resources = getattr(rm, "_resources", None) if rm is not None else None
    if isinstance(resources, dict):
        # Match by URI string or by pattern key.
        if uri in resources:
            return True
        for key, value in resources.items():
            if str(getattr(value, "uri", "")) == uri or str(key) == uri:
                return True
        return False
    return False


class TestIntentKeywordsResource:
    """`g8://intent/keywords` is the discovery hook for resources/list crawlers."""

    def test_resource_registered(self, mcp_server):
        assert _has_resource(mcp_server, "g8://intent/keywords"), (
            "g8://intent/keywords must be registered so clients crawling "
            "resources/list can discover compete-tracking before tools."
        )


# ---------------------------------------------------------------------------
# Capability catalog drift: every tool we ship must be documented
# ---------------------------------------------------------------------------


class TestIntentCapabilityCatalog:
    """The capabilities catalog must list all 14 g8_intent_* tools."""

    def test_intent_group_present(self):
        from g8_mcp_server.capabilities import MCP_TOOL_CATALOG, MCP_TOOL_GROUPS

        assert "intent" in MCP_TOOL_CATALOG, (
            "MCP_TOOL_CATALOG must have an 'intent' group documenting "
            "compete-tracking tools."
        )
        group_values = {g["value"] for g in MCP_TOOL_GROUPS}
        assert "intent" in group_values, "MCP_TOOL_GROUPS must include 'intent'."

    def test_intent_catalog_covers_every_registered_tool(self, mcp_server):
        from g8_mcp_server.capabilities import MCP_TOOL_CATALOG

        documented = {row["actual_tool"] for row in MCP_TOOL_CATALOG.get("intent", [])}
        registered = {
            n for n in mcp_server._tool_manager._tools if n.startswith("g8_intent_")
        }
        missing = registered - documented
        assert not missing, (
            f"Intent tools registered but missing from MCP_TOOL_CATALOG['intent']: "
            f"{sorted(missing)}. Add rows in capabilities.py."
        )
