"""Unit tests for the meetings MCP tools (g8_list_meetings, g8_get_meeting).

Covers:
  - Tool registration on the meetings registrar
  - URL + params construction for list endpoint
  - participant_email repeated query param formation (the wire shape
    FastAPI's ``Query(list[str])`` parser expects)
  - email + contact_id resolution into participant_emails
  - case-insensitive de-dup of resolved emails
  - Detail tool hits the correct path
  - MeetingListResult / MeetingDetail envelope parsing

These exercises stub ``G8Client.get`` so we don't need an actual HTTP
server. The function objects are introspected from the FastMCP
``_tool_manager._tools`` map exactly like ``test_tools.py`` does so the
pattern matches the rest of the suite.
"""

from __future__ import annotations

from pathlib import Path
from unittest.mock import AsyncMock

import pytest

import g8_mcp_server.client as client_module
from g8_mcp_server.client import G8Client
from g8_mcp_server.models import MeetingDetail, MeetingListResult


@pytest.fixture
def mock_env(monkeypatch):
    monkeypatch.setenv("G8_API_KEY", "test_key_meetings")
    monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
    monkeypatch.setattr(
        client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json")
    )


@pytest.fixture
def client(mock_env):
    return G8Client()


def _register_meetings_tools(client):
    """Register meetings tools on a fresh FastMCP server and return tool map."""
    from mcp.server import FastMCP

    from g8_mcp_server.tools import meetings

    server = FastMCP("test")
    meetings.register(server, client)
    return server, server._tool_manager._tools


# ---------------------------------------------------------------------------
# Registration / surface contract
# ---------------------------------------------------------------------------


class TestMeetingsRegistration:
    def test_list_meetings_registered(self, client):
        _, tools = _register_meetings_tools(client)
        assert "g8_list_meetings" in tools

    def test_get_meeting_registered(self, client):
        _, tools = _register_meetings_tools(client)
        assert "g8_get_meeting" in tools

    def test_list_meetings_in_always_on_set(self):
        """The list tool must be discoverable without a tool_search activation
        because "show me meetings" is a foundational question. Detail is gated
        behind tool_search so we keep the catalog compact."""
        from g8_mcp_server.server import _ALWAYS_ON_TOOLS

        assert "g8_list_meetings" in _ALWAYS_ON_TOOLS
        # g8_get_meeting is intentionally NOT always-on; agents reach it
        # after g8_list_meetings narrows the surface.

    def test_both_tools_have_read_only_annotations(self, client):
        """Meetings tools are read-only / idempotent — locks the contract
        so a future refactor cannot accidentally drop the annotation."""
        server, tools = _register_meetings_tools(client)
        for name in ("g8_list_meetings", "g8_get_meeting"):
            ann = tools[name].annotations
            assert ann is not None, f"{name} missing ToolAnnotations"
            assert ann.readOnlyHint is True
            assert ann.idempotentHint is True


# ---------------------------------------------------------------------------
# g8_list_meetings — endpoint + parameter wiring
# ---------------------------------------------------------------------------


class TestListMeetingsCall:
    @pytest.mark.asyncio
    async def test_no_filters_hits_meetings_endpoint(self, client):
        _, tools = _register_meetings_tools(client)
        fn = tools["g8_list_meetings"].fn

        client.get = AsyncMock(
            return_value={
                "data": [],
                "pagination": {"page": 1, "limit": 50, "total": 0, "has_next": False},
            }
        )

        result = await fn()

        # Endpoint must be /inbox/meetings (relative to the developer_api base).
        client.get.assert_called_once()
        args = client.get.call_args.args
        assert args[0] == "/inbox/meetings"
        # No participant_email key when nothing was passed in.
        params = args[1]
        assert "participant_email" not in params
        # Pagination defaults flow through, but page_size is clamped down
        # to _LIST_PAGE_SIZE_CAP=25 so the structuredContent payload stays
        # under claude.ai's MCP widget threshold. The signature default
        # remains 50 for back-compat with callers reading the tool schema.
        assert params["page"] == 1
        assert params["page_size"] == 25

        # Typed result, no fallback string.
        assert isinstance(result, MeetingListResult)
        assert result.meetings == []
        assert result.total == 0

    @pytest.mark.asyncio
    async def test_email_arg_forwards_as_participant_email_list(self, client):
        _, tools = _register_meetings_tools(client)
        fn = tools["g8_list_meetings"].fn

        client.get = AsyncMock(return_value={"data": [], "pagination": {}})
        await fn(email="alice@example.com")

        params = client.get.call_args.args[1]
        # httpx serializes list values as repeated keys — match FastAPI Query(list[str]).
        assert params["participant_email"] == ["alice@example.com"]

    @pytest.mark.asyncio
    async def test_explicit_participant_emails_used_verbatim(self, client):
        _, tools = _register_meetings_tools(client)
        fn = tools["g8_list_meetings"].fn

        client.get = AsyncMock(return_value={"data": [], "pagination": {}})
        await fn(participant_emails=["bob@x.com", "carol@x.com"])

        params = client.get.call_args.args[1]
        assert params["participant_email"] == ["bob@x.com", "carol@x.com"]

    @pytest.mark.asyncio
    async def test_email_plus_participant_emails_combined(self, client):
        _, tools = _register_meetings_tools(client)
        fn = tools["g8_list_meetings"].fn

        client.get = AsyncMock(return_value={"data": [], "pagination": {}})
        await fn(
            email="alice@example.com",
            participant_emails=["bob@x.com"],
        )

        params = client.get.call_args.args[1]
        # Order is preserved: explicit list first, single email appended.
        assert params["participant_email"] == ["bob@x.com", "alice@example.com"]

    @pytest.mark.asyncio
    async def test_dedupes_emails_case_insensitively(self, client):
        _, tools = _register_meetings_tools(client)
        fn = tools["g8_list_meetings"].fn

        client.get = AsyncMock(return_value={"data": [], "pagination": {}})
        await fn(
            email="ALICE@example.com",
            participant_emails=["alice@example.com", "Bob@X.com", "BOB@x.com"],
        )

        params = client.get.call_args.args[1]
        # First-seen casing wins, duplicates dropped.
        assert params["participant_email"] == ["alice@example.com", "Bob@X.com"]

    @pytest.mark.asyncio
    async def test_contact_id_resolves_to_work_email(self, client):
        """contact_id -> GET /contacts/{id} -> extract work_email -> add to
        participant filter. The lookup is a single extra round-trip."""
        _, tools = _register_meetings_tools(client)
        fn = tools["g8_list_meetings"].fn

        async def fake_get(path, params=None):
            if path == "/contacts/42":
                return {"data": {"id": 42, "work_email": "found@example.com"}}
            if path == "/inbox/meetings":
                return {"data": [], "pagination": {}}
            raise AssertionError(f"unexpected GET {path}")

        client.get = AsyncMock(side_effect=fake_get)
        await fn(contact_id=42)

        # Two GETs: contact lookup + meetings list.
        assert client.get.call_count == 2
        meetings_call = client.get.call_args_list[1]
        assert meetings_call.args[0] == "/inbox/meetings"
        assert meetings_call.args[1]["participant_email"] == ["found@example.com"]

    @pytest.mark.asyncio
    async def test_contact_id_lookup_failure_falls_back_to_other_filters(self, client):
        """If the contact lookup raises (404, network error, etc.) we don't
        bubble the failure — we just skip the contact-derived email and
        continue with whatever else the caller provided."""
        _, tools = _register_meetings_tools(client)
        fn = tools["g8_list_meetings"].fn

        async def fake_get(path, params=None):
            if path == "/contacts/9999":
                raise Exception("404 not found")
            if path == "/inbox/meetings":
                return {"data": [], "pagination": {}}
            raise AssertionError(f"unexpected GET {path}")

        client.get = AsyncMock(side_effect=fake_get)
        result = await fn(contact_id=9999, email="fallback@example.com")

        # Still calls the meetings endpoint with the fallback email only.
        meetings_call = client.get.call_args_list[-1]
        assert meetings_call.args[0] == "/inbox/meetings"
        assert meetings_call.args[1]["participant_email"] == ["fallback@example.com"]
        assert isinstance(result, MeetingListResult)

    @pytest.mark.asyncio
    async def test_filter_params_flow_through(self, client):
        _, tools = _register_meetings_tools(client)
        fn = tools["g8_list_meetings"].fn

        client.get = AsyncMock(return_value={"data": [], "pagination": {}})
        await fn(
            scope="all",
            timeframe="upcoming",
            has_transcript=True,
            search="Q4 review",
            page=2,
            page_size=25,
        )

        params = client.get.call_args.args[1]
        assert params["scope"] == "all"
        assert params["timeframe"] == "upcoming"
        assert params["has_transcript"] is True
        assert params["search"] == "Q4 review"
        assert params["page"] == 2
        assert params["page_size"] == 25


# ---------------------------------------------------------------------------
# g8_list_meetings — envelope parsing
# ---------------------------------------------------------------------------


class TestListMeetingsResultShape:
    @pytest.mark.asyncio
    async def test_parses_summary_envelope(self, client):
        _, tools = _register_meetings_tools(client)
        fn = tools["g8_list_meetings"].fn

        client.get = AsyncMock(
            return_value={
                "data": [
                    {
                        "id": "m1",
                        "subject": "Kickoff",
                        "organizer_email": "alice@example.com",
                        "user_email": "alice@example.com",
                        "transcript_status": "linked",
                        "transcript_summary": "Short preview text.",
                        "attendees": [
                            {"email": "bob@external.com", "name": "Bob"},
                        ],
                    },
                    {
                        "id": "m2",
                        "subject": "Followup",
                        "transcript_status": "none",
                    },
                ],
                "pagination": {"page": 1, "limit": 50, "total": 2, "has_next": False},
            }
        )

        result = await fn()

        assert isinstance(result, MeetingListResult)
        assert len(result.meetings) == 2
        assert result.meetings[0].subject == "Kickoff"
        # transcript_summary is intentionally nulled by g8_list_meetings even
        # if the backend returns it - keeps the structuredContent payload
        # small enough for the linked claude.ai widget to render. Callers
        # must hit g8_get_meeting to read the summary. The field stays on
        # the schema, so no consumer breaks - it just sees None.
        assert result.meetings[0].transcript_summary is None
        assert result.meetings[0].attendees[0].email == "bob@external.com"
        assert result.total == 2
        assert result.has_next is False

    @pytest.mark.asyncio
    async def test_summary_drops_transcript_text(self, client):
        """List endpoint must not leak full transcript body even if the
        backend mistakenly returns it — MeetingSummary ignores the field."""
        _, tools = _register_meetings_tools(client)
        fn = tools["g8_list_meetings"].fn

        client.get = AsyncMock(
            return_value={
                "data": [
                    {
                        "id": "m1",
                        "subject": "Big meeting",
                        "transcript_text": "FULL BODY THAT SHOULD NOT APPEAR",
                    }
                ],
                "pagination": {},
            }
        )

        result = await fn()
        summary = result.meetings[0]
        # MeetingSummary has no transcript_text attribute; model_dump
        # confirms it's been stripped from the structured output.
        dumped = summary.model_dump()
        assert "transcript_text" not in dumped


# ---------------------------------------------------------------------------
# g8_list_meetings — claude.ai widget payload guardrails
#
# The MCP host writes tool results > ~150 KB to its sandbox filesystem
# (for the model to grep) and STOPS pushing them via ontoolresult to the
# linked widget, leaving it stuck on "Loading...". Two defenses live in
# tools/meetings.py - both must stay enforced or the bug returns:
#   1. page_size hard-clamp to _LIST_PAGE_SIZE_CAP
#   2. transcript_summary + preview nulled per row (~1-3 KB each)
# ---------------------------------------------------------------------------


class TestListMeetingsWidgetPayloadGuards:
    @pytest.mark.asyncio
    async def test_page_size_clamped_when_over_cap(self, client):
        """Even if the caller asks for the documented max (100), the wire
        request is clamped to _LIST_PAGE_SIZE_CAP. Without this the
        widget hangs on Loading for orgs with transcript-heavy meetings."""
        from g8_mcp_server.tools.meetings import _LIST_PAGE_SIZE_CAP

        _, tools = _register_meetings_tools(client)
        fn = tools["g8_list_meetings"].fn

        client.get = AsyncMock(return_value={"data": [], "pagination": {}})
        await fn(page_size=100)

        params = client.get.call_args.args[1]
        assert params["page_size"] == _LIST_PAGE_SIZE_CAP

    @pytest.mark.asyncio
    async def test_page_size_below_cap_flows_through(self, client):
        """The clamp is a ceiling, not a floor - small page_size values
        from the caller must be preserved verbatim."""
        _, tools = _register_meetings_tools(client)
        fn = tools["g8_list_meetings"].fn

        client.get = AsyncMock(return_value={"data": [], "pagination": {}})
        await fn(page_size=5)

        params = client.get.call_args.args[1]
        assert params["page_size"] == 5

    @pytest.mark.asyncio
    async def test_transcript_summary_and_preview_stripped_from_list_rows(self, client):
        """The dominant payload contributors are transcript_summary and its
        backend-side duplicate `preview`. Both are nulled on the way out
        even when the backend returns them. The fields stay on the schema
        so consumers don't break - they just see None and must call
        g8_get_meeting to read the summary."""
        _, tools = _register_meetings_tools(client)
        fn = tools["g8_list_meetings"].fn

        big_text = "x" * 3000
        client.get = AsyncMock(
            return_value={
                "data": [
                    {
                        "id": "m1",
                        "subject": "Heavy",
                        "transcript_summary": big_text,
                        "preview": big_text,
                    },
                    {
                        "id": "m2",
                        "subject": "Also heavy",
                        "transcript_summary": big_text,
                        "preview": big_text,
                    },
                ],
                "pagination": {"page": 1, "limit": 50, "total": 2, "has_next": False},
            }
        )

        result = await fn()

        assert isinstance(result, MeetingListResult)
        for row in result.meetings:
            assert row.transcript_summary is None
            assert row.preview is None
        # Other fields untouched.
        assert result.meetings[0].subject == "Heavy"
        assert result.meetings[1].id == "m2"

    @pytest.mark.asyncio
    async def test_error_string_passes_through_unstripped(self, client):
        """When the backend errors, safe_call_typed returns a plain string
        rather than a MeetingListResult. The strip path must skip the
        isinstance check so error messages reach the caller intact."""
        from g8_mcp_server.client import G8ClientError

        _, tools = _register_meetings_tools(client)
        fn = tools["g8_list_meetings"].fn

        async def fake_get(path, params=None):
            raise G8ClientError(500, "API error (500): boom")

        client.get = AsyncMock(side_effect=fake_get)
        result = await fn()

        # Error string surfaces - not a MeetingListResult, not an exception.
        assert isinstance(result, str)
        assert "500" in result


# ---------------------------------------------------------------------------
# g8_get_meeting — detail endpoint
# ---------------------------------------------------------------------------


class TestGetMeetingCall:
    @pytest.mark.asyncio
    async def test_hits_detail_path(self, client):
        _, tools = _register_meetings_tools(client)
        fn = tools["g8_get_meeting"].fn

        client.get = AsyncMock(
            return_value={"data": {"id": "42", "subject": "Test", "channel": "meetings"}}
        )

        result = await fn(meeting_id="42")

        client.get.assert_called_once_with("/inbox/meetings/42")
        assert isinstance(result, MeetingDetail)
        assert result.id == "42"

    @pytest.mark.asyncio
    async def test_returns_full_transcript_bundled(self, client):
        """Detail tool is the ONE place full transcript_text is exposed —
        bundled approach (Option A) means callers don't have to make a
        second round-trip."""
        _, tools = _register_meetings_tools(client)
        fn = tools["g8_get_meeting"].fn

        client.get = AsyncMock(
            return_value={
                "data": {
                    "id": "42",
                    "subject": "Q4 review",
                    "transcript_status": "linked",
                    "transcript_text": "Full transcript body. Many words.",
                    "transcript_summary": "Short.",
                    "transcript_redacted": False,
                    "attendees": [
                        {"email": "bob@external.com", "name": "Bob"},
                        {
                            "email": "alice@example.com",
                            "name": "Alice",
                            "organizer": True,
                        },
                    ],
                    "key_topics": ["pricing", "renewal"],
                    "action_items": [{"text": "Follow up Thursday"}],
                }
            }
        )

        result = await fn(meeting_id="42")

        assert isinstance(result, MeetingDetail)
        assert result.transcript_text == "Full transcript body. Many words."
        assert result.transcript_summary == "Short."
        assert result.transcript_redacted is False
        assert result.key_topics == ["pricing", "renewal"]
        assert any(a.organizer for a in result.attendees)

    @pytest.mark.asyncio
    async def test_respects_redaction(self, client):
        """When transcript_redacted=true the body is None — the wrapper
        passes the flag through so the agent knows why content is missing."""
        _, tools = _register_meetings_tools(client)
        fn = tools["g8_get_meeting"].fn

        client.get = AsyncMock(
            return_value={
                "data": {
                    "id": "42",
                    "subject": "Internal sync",
                    "transcript_status": "linked",
                    "transcript_text": None,
                    "transcript_summary": None,
                    "transcript_redacted": True,
                    "transcript_id": "t-123",
                }
            }
        )

        result = await fn(meeting_id="42")
        assert result.transcript_redacted is True
        assert result.transcript_text is None
        # Status / IDs remain visible so the agent can explain why.
        assert result.transcript_status == "linked"
        assert result.transcript_id == "t-123"


# ---------------------------------------------------------------------------
# Helper: _extract_contact_email — keeps the contact-lookup tolerant of
# envelope shapes the contacts endpoint may emit.
# ---------------------------------------------------------------------------


class TestExtractContactEmail:
    def test_prefers_work_email(self):
        from g8_mcp_server.tools.meetings import _extract_contact_email

        envelope = {
            "data": {
                "id": 1,
                "work_email": "work@example.com",
                "email": "other@example.com",
            }
        }
        assert _extract_contact_email(envelope) == "work@example.com"

    def test_falls_back_to_email(self):
        from g8_mcp_server.tools.meetings import _extract_contact_email

        assert (
            _extract_contact_email({"data": {"email": "x@example.com"}})
            == "x@example.com"
        )

    def test_bare_dict_no_envelope(self):
        """Some endpoints return a bare contact dict instead of an
        ApiResponse envelope — accept both."""
        from g8_mcp_server.tools.meetings import _extract_contact_email

        assert (
            _extract_contact_email({"work_email": "bare@example.com"})
            == "bare@example.com"
        )

    def test_returns_none_for_garbage(self):
        from g8_mcp_server.tools.meetings import _extract_contact_email

        assert _extract_contact_email(None) is None
        assert _extract_contact_email("not a dict") is None
        assert _extract_contact_email({"data": "not a dict"}) is None
        assert _extract_contact_email({}) is None

    def test_skips_blank_values(self):
        from g8_mcp_server.tools.meetings import _extract_contact_email

        # Blank work_email shouldn't beat a populated `email`.
        envelope = {"data": {"work_email": "   ", "email": "real@example.com"}}
        assert _extract_contact_email(envelope) == "real@example.com"


# ---------------------------------------------------------------------------
# include_internal flag wiring (2026-05-17 - was silently dropping internal
# team meetings; the MCP arg → query param translation is what restores
# visibility for Roam syncs, standups, all-attendees-same-domain meetings).
# ---------------------------------------------------------------------------


class TestIncludeInternalFlag:
    @pytest.mark.asyncio
    async def test_omitted_means_internal_mode_none(self, client):
        """Default behavior preserved: omitting the flag passes
        internal_mode=None so the backend falls back to the org policy
        default (most orgs default to exclude_internal)."""
        _, tools = _register_meetings_tools(client)
        fn = tools["g8_list_meetings"].fn
        client.get = AsyncMock(return_value={"data": [], "pagination": {}})

        await fn()

        params = client.get.call_args.args[1]
        assert params["internal_mode"] is None

    @pytest.mark.asyncio
    async def test_false_means_internal_mode_none(self, client):
        """False is treated the same as omitted - we don't force
        exclude_internal because the backend already does that via the
        org policy default. Avoids stomping any future per-org override
        that prefers include_internal."""
        _, tools = _register_meetings_tools(client)
        fn = tools["g8_list_meetings"].fn
        client.get = AsyncMock(return_value={"data": [], "pagination": {}})

        await fn(include_internal=False)

        params = client.get.call_args.args[1]
        assert params["internal_mode"] is None

    @pytest.mark.asyncio
    async def test_true_emits_include_internal_string(self, client):
        """True maps to the literal 'include_internal' enum value the
        backend's InternalMode(...) constructor accepts. This is the bug
        fix: without this, Roam team syncs are silently dropped from MCP
        results even though they show up in the web UI."""
        _, tools = _register_meetings_tools(client)
        fn = tools["g8_list_meetings"].fn
        client.get = AsyncMock(return_value={"data": [], "pagination": {}})

        await fn(include_internal=True)

        params = client.get.call_args.args[1]
        assert params["internal_mode"] == "include_internal"


# ---------------------------------------------------------------------------
# UI App linkage (2026-05-17 - tools were missing _meta.ui.resourceUri so
# claude.ai delivered results as text instead of rendering the widget).
# ---------------------------------------------------------------------------


class TestUiAppLinkage:
    def test_list_meetings_links_to_ui_resource(self, client):
        """Without this, claude.ai never knows to render the meetings
        widget — the tool fires and the result comes back as JSON only.
        See mcp-html-app-surfaces.md: 'Each ui:// resource MUST be linked
        from at least one tool via _meta.ui.resourceUri'."""
        _, tools = _register_meetings_tools(client)
        tool = tools["g8_list_meetings"]
        meta = getattr(tool, "_meta", None) or getattr(tool, "meta", None)
        assert meta is not None
        assert meta.get("ui", {}).get("resourceUri") == "ui://meetings/list"

    def test_get_meeting_links_to_ui_resource(self, client):
        _, tools = _register_meetings_tools(client)
        tool = tools["g8_get_meeting"]
        meta = getattr(tool, "_meta", None) or getattr(tool, "meta", None)
        assert meta is not None
        assert meta.get("ui", {}).get("resourceUri") == "ui://meetings/detail"

    def test_ui_resources_registered_on_server(self, client):
        """The ui:// resources themselves must exist on the resource
        manager; without registration, the tool's resourceUri points
        at nothing and the host renders an error."""
        import asyncio

        from mcp.server import FastMCP

        from g8_mcp_server import resources as r

        server = FastMCP("test")
        r.register(server, client)

        res_list = asyncio.run(server.list_resources())
        uris = {str(rs.uri) for rs in res_list}
        assert "ui://meetings/list" in uris
        assert "ui://meetings/detail" in uris
