"""Session-level env-var defaults for mcp_server tests.

Some tests in this suite indirectly import the campaign_builder →
shared → appointments dependency chain (e.g.
``test_webhook_events_renderer.py`` imports
``campaign_builder.services.webhook_service`` for the canonical
WEBHOOK_EVENTS list). Several modules in that chain raise at import
time if their env vars are unset (OAUTH_STATE_SECRET fail-fast,
PROPELAUTH init_auth, etc.), which fails on local laptops without
a populated ``.env``.

CI sets the real values via Infisical; locally we set deterministic
test placeholders here, before any test collection / import happens,
so the fail-fast guards stay intact in production code without
breaking the laptop test loop. ``setdefault`` means a real value in
the environment still wins.
"""

from __future__ import annotations

import os
import sys
from unittest.mock import MagicMock

_PLACEHOLDERS = {
    "OAUTH_STATE_SECRET": (
        "test-oauth-state-secret-placeholder-not-used-outside-tests-0123456789abcdef"
    ),
    "PROPELAUTH_AUTH_URL": "https://test.propelauth.invalid",
    "PROPELAUTH_API_KEY": "test-propelauth-api-key-placeholder",
}

for _key, _val in _PLACEHOLDERS.items():
    os.environ.setdefault(_key, _val)


# ``shared.interfaces.fasapi.dependencies`` calls ``propelauth_py.init_auth``
# at module import time, which performs a live HTTP fetch against
# ``PROPELAUTH_AUTH_URL`` to load token-verification metadata. In test
# we don't have a real PropelAuth tenant; stub ``init_auth`` so the
# import chain completes without network. Production paths are
# unaffected — this only runs when these tests are collected.
def _stub_init_auth(*_args, **_kwargs):  # pragma: no cover - import shim
    return MagicMock(name="StubPropelAuth")


try:  # pragma: no cover - only patches if the package is importable
    import propelauth_py  # type: ignore

    propelauth_py.init_auth = _stub_init_auth  # type: ignore[attr-defined]
except Exception:
    pass

try:
    import propelauth_fastapi  # type: ignore

    propelauth_fastapi.init_auth = _stub_init_auth  # type: ignore[attr-defined]
except Exception:
    pass

# Ensure any later ``from propelauth_py import init_auth`` (or
# ``propelauth_fastapi``) re-resolves to the stub even when imported
# via cached attribute lookup.
for _modname in ("propelauth_py", "propelauth_fastapi"):
    _mod = sys.modules.get(_modname)
    if _mod is not None:
        setattr(_mod, "init_auth", _stub_init_auth)
