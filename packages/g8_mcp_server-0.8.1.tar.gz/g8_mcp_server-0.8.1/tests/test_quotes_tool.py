"""Unit tests for the MCP quotes tools (g8_list_quotes, g8_get_quote, …).

Covers:
  - Tool registration (all 12 tools land on the server)
  - Always-on / progressive-discovery contract (the 5 core lifecycle
    entry points must reach claude.ai at connect time; the rest stay
    behind g8_tool_search to keep the catalog lean)
  - Endpoint + params wiring for each route
  - QuotesResult / QuotableProductsResult envelope parsing (the dual
    {items, …} vs {data: {items, …}} shape tolerance is the contract
    that lets the same models work whether the call hits the developer
    API's ApiResponse wrapper or the internal route directly)
  - Tool-annotation discipline (READ_ONLY / WRITE / DESTRUCTIVE)
  - Send + delete must remain DESTRUCTIVE so MCP clients prompt the
    user before firing them

These exercises stub ``G8Client`` HTTP methods so we don't need a live
backend. The pattern matches ``test_meetings_tool.py``.
"""

from __future__ import annotations

from pathlib import Path
from unittest.mock import AsyncMock

import pytest

import g8_mcp_server.client as client_module
from g8_mcp_server.client import G8Client
from g8_mcp_server.models import (
    ActionResult,
    QuotableProductsResult,
    QuotesResult,
    ResourceDetail,
)


_ALL_QUOTE_TOOLS = [
    "g8_list_quotes",
    "g8_get_quote",
    "g8_create_quote",
    "g8_update_quote",
    "g8_delete_quote",
    "g8_duplicate_quote",
    "g8_edit_quote_as_draft",
    "g8_send_quote",
    "g8_list_quotable_products",
    "g8_get_quote_settings",
    "g8_get_company_quotes",
    "g8_get_contact_quotes",
]

_DESTRUCTIVE_QUOTE_TOOLS = {"g8_send_quote", "g8_delete_quote"}
_WRITE_QUOTE_TOOLS = {
    "g8_create_quote",
    "g8_update_quote",
    "g8_duplicate_quote",
    "g8_edit_quote_as_draft",
}
_READ_ONLY_QUOTE_TOOLS = {
    "g8_list_quotes",
    "g8_get_quote",
    "g8_list_quotable_products",
    "g8_get_quote_settings",
    "g8_get_company_quotes",
    "g8_get_contact_quotes",
}


@pytest.fixture
def mock_env(monkeypatch):
    monkeypatch.setenv("G8_API_KEY", "test_key_quotes")
    monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
    monkeypatch.setattr(
        client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json")
    )


@pytest.fixture
def client(mock_env):
    return G8Client()


def _register_quotes(client):
    """Register quote tools on a fresh FastMCP and return the tool map."""
    from mcp.server import FastMCP

    from g8_mcp_server.tools import quotes

    server = FastMCP("test")
    quotes.register(server, client)
    return server, server._tool_manager._tools


# ---------------------------------------------------------------------------
# Registration / surface contract
# ---------------------------------------------------------------------------


class TestQuotesRegistration:
    def test_all_twelve_tools_registered(self, client):
        _, tools = _register_quotes(client)
        for name in _ALL_QUOTE_TOOLS:
            assert name in tools, f"missing tool: {name}"
        assert len([n for n in tools if n.startswith("g8_") and "quot" in n]) == 12

    def test_no_quote_tools_in_always_on_during_soak(self):
        """v0.6.11: every quote tool is progressive-discovery only.

        Quotes are net-new in this release; we want them to soak against real
        MCP clients before any of them earn a connect-time slot. Agents reach
        the full set via g8_tool_search("quote"). When we are ready to promote
        the core lifecycle (list / get / create / update / get_company_quotes,
        mirroring the v0.6.4 deals CRUD promotion), update this test to assert
        membership instead of exclusion."""
        from g8_mcp_server.server import _ALWAYS_ON_TOOLS

        for name in _ALL_QUOTE_TOOLS:
            assert name not in _ALWAYS_ON_TOOLS, (
                f"{name} should not be always-on during the v0.6.11 soak"
            )

    def test_crm_only_set_includes_all_quote_tools(self):
        """Quotes are CRM/sales artifacts; in dev-mode (`mcp_tool_group=dev`)
        every quote tool must hide. The mode filter keys off
        `_CRM_ONLY_TOOLS`."""
        from g8_mcp_server.server import _CRM_ONLY_TOOLS

        for name in _ALL_QUOTE_TOOLS:
            assert name in _CRM_ONLY_TOOLS, f"{name} missing from _CRM_ONLY_TOOLS"

    def test_destructive_tools_annotated_destructive(self, client):
        _, tools = _register_quotes(client)
        for name in _DESTRUCTIVE_QUOTE_TOOLS:
            ann = tools[name].annotations
            assert ann is not None, f"{name} missing annotations"
            assert ann.destructiveHint is True, f"{name} not marked destructive"

    def test_write_tools_annotated_non_destructive(self, client):
        _, tools = _register_quotes(client)
        for name in _WRITE_QUOTE_TOOLS:
            ann = tools[name].annotations
            assert ann is not None
            assert ann.readOnlyHint is False
            # WRITE annotations explicitly set destructiveHint=False so the
            # MCP spec doesn't default-promote them to destructive.
            assert ann.destructiveHint is False, (
                f"{name} should be non-destructive write"
            )

    def test_read_only_tools_annotated_idempotent(self, client):
        _, tools = _register_quotes(client)
        for name in _READ_ONLY_QUOTE_TOOLS:
            ann = tools[name].annotations
            assert ann is not None
            assert ann.readOnlyHint is True
            assert ann.idempotentHint is True


# ---------------------------------------------------------------------------
# g8_list_quotes
# ---------------------------------------------------------------------------


class TestListQuotes:
    @pytest.mark.asyncio
    async def test_no_filters_hits_quotes_endpoint(self, client):
        _, tools = _register_quotes(client)
        fn = tools["g8_list_quotes"].fn

        client.get = AsyncMock(
            return_value={"data": {"items": [], "total": 0, "page": 1, "limit": 50}}
        )
        result = await fn()

        client.get.assert_called_once()
        path, params = client.get.call_args.args
        assert path == "/quotes"
        assert params["page"] == 1
        assert params["limit"] == 50
        # Optional filters serialize as None — _strip_none in the client
        # drops them on the wire, but the MCP-side params dict carries the
        # explicit Nones.
        assert params["status"] is None
        assert params["mashup_company_id"] is None

        assert isinstance(result, QuotesResult)
        assert result.quotes == []
        assert result.total == 0
        assert result.has_next is False

    @pytest.mark.asyncio
    async def test_filters_flow_through(self, client):
        _, tools = _register_quotes(client)
        fn = tools["g8_list_quotes"].fn

        client.get = AsyncMock(
            return_value={"data": {"items": [], "total": 0, "page": 2, "limit": 25}}
        )
        await fn(
            page=2,
            limit=25,
            status="sent",
            mashup_company_id=42,
            deal_id="deal-uuid-1",
            owner_id="owner@graph8.com",
        )

        path, params = client.get.call_args.args
        assert path == "/quotes"
        assert params["status"] == "sent"
        assert params["mashup_company_id"] == 42
        assert params["deal_id"] == "deal-uuid-1"
        assert params["owner_id"] == "owner@graph8.com"
        assert params["page"] == 2
        assert params["limit"] == 25

    @pytest.mark.asyncio
    async def test_envelope_parses_direct_internal_shape(self, client):
        """The internal /stripe/v4/quotes endpoint returns
        {items, total, page, limit} (no ApiResponse wrapper). QuotesResult
        must handle that shape too — important if the MCP tool ever points
        at the internal path directly (or for unit tests against the
        canonical shape)."""
        _, tools = _register_quotes(client)
        fn = tools["g8_list_quotes"].fn

        client.get = AsyncMock(
            return_value={
                "items": [
                    {"id": "q1", "title": "Plan A", "status": "draft", "total": 12000},
                    {"id": "q2", "title": "Plan B", "status": "sent", "total": 50000},
                ],
                "total": 2,
                "page": 1,
                "limit": 50,
            }
        )
        result = await fn()

        assert isinstance(result, QuotesResult)
        assert len(result.quotes) == 2
        assert result.quotes[0].id == "q1"
        assert result.quotes[1].status == "sent"
        assert result.total == 2
        assert result.has_next is False

    @pytest.mark.asyncio
    async def test_envelope_parses_apiresponse_wrapper(self, client):
        """The developer-API wraps the internal shape in ApiResponse[T]:
        {data: {items, total, page, limit}}. QuotesResult must read both
        layers correctly."""
        _, tools = _register_quotes(client)
        fn = tools["g8_list_quotes"].fn

        client.get = AsyncMock(
            return_value={
                "data": {
                    "items": [{"id": "q1", "title": "Plan A", "status": "draft"}],
                    "total": 1,
                    "page": 1,
                    "limit": 50,
                }
            }
        )
        result = await fn()

        assert isinstance(result, QuotesResult)
        assert result.quotes[0].id == "q1"
        assert result.total == 1

    @pytest.mark.asyncio
    async def test_has_next_computed(self, client):
        _, tools = _register_quotes(client)
        fn = tools["g8_list_quotes"].fn

        client.get = AsyncMock(
            return_value={
                "data": {
                    "items": [{"id": f"q{i}"} for i in range(25)],
                    "total": 100,
                    "page": 1,
                    "limit": 25,
                }
            }
        )
        result = await fn(page=1, limit=25)
        assert result.has_next is True

        client.get = AsyncMock(
            return_value={
                "data": {
                    "items": [{"id": f"q{i}"} for i in range(25)],
                    "total": 100,
                    "page": 4,
                    "limit": 25,
                }
            }
        )
        result = await fn(page=4, limit=25)
        assert result.has_next is False


# ---------------------------------------------------------------------------
# Per-route endpoint wiring (one assertion per tool, all paths land
# correctly on the client). Detailed envelope parsing is covered in
# TestListQuotes above; this section just locks the path contract.
# ---------------------------------------------------------------------------


class TestEndpointWiring:
    @pytest.mark.asyncio
    async def test_get_quote_path(self, client):
        _, tools = _register_quotes(client)
        client.get = AsyncMock(return_value={"data": {"id": "q1", "title": "X"}})
        result = await tools["g8_get_quote"].fn(quote_id="q1")
        client.get.assert_called_once_with("/quotes/q1")
        assert isinstance(result, ResourceDetail)

    @pytest.mark.asyncio
    async def test_quotable_products_path(self, client):
        _, tools = _register_quotes(client)
        client.get = AsyncMock(
            return_value={"data": {"items": [], "total": 0, "page": 1, "limit": 100}}
        )
        result = await tools["g8_list_quotable_products"].fn(currency="USD")
        path, params = client.get.call_args.args
        assert path == "/quotable-products"
        assert params["currency"] == "USD"
        assert isinstance(result, QuotableProductsResult)

    @pytest.mark.asyncio
    async def test_quote_settings_path(self, client):
        _, tools = _register_quotes(client)
        client.get = AsyncMock(return_value={"data": {"sender_name": "Sales"}})
        await tools["g8_get_quote_settings"].fn()
        client.get.assert_called_once_with("/quote-settings")

    @pytest.mark.asyncio
    async def test_company_quotes_path(self, client):
        _, tools = _register_quotes(client)
        client.get = AsyncMock(return_value={"data": [{"id": "q1"}]})
        result = await tools["g8_get_company_quotes"].fn(company_id=42)
        client.get.assert_called_once_with("/companies/42/quotes")
        assert result == {"quotes": [{"id": "q1"}], "total": 1}

    @pytest.mark.asyncio
    async def test_company_quotes_handles_empty_response(self, client):
        _, tools = _register_quotes(client)
        client.get = AsyncMock(return_value={"data": []})
        result = await tools["g8_get_company_quotes"].fn(company_id=42)
        assert result == {"quotes": [], "total": 0}

    @pytest.mark.asyncio
    async def test_contact_quotes_path(self, client):
        _, tools = _register_quotes(client)
        client.get = AsyncMock(return_value={"data": [{"id": "q1"}]})
        result = await tools["g8_get_contact_quotes"].fn(contact_id=7)
        client.get.assert_called_once_with("/contacts/7/quotes")
        assert result == {"quotes": [{"id": "q1"}], "total": 1}

    @pytest.mark.asyncio
    async def test_create_quote_body_serialization(self, client):
        _, tools = _register_quotes(client)
        client.post = AsyncMock(return_value={"data": {"id": "q1"}})
        await tools["g8_create_quote"].fn(
            title="Enterprise",
            signer_email="x@example.com",
            line_items=[{"product_name": "Pro", "quantity": 1, "unit_amount": 10000}],
            currency="USD",
            payment_terms="net_30",
        )
        path, body = client.post.call_args.args
        assert path == "/quotes"
        # None-valued kwargs must be dropped from the body so the internal
        # CreateQuoteDTO defaults take effect server-side.
        assert "valid_until" not in body
        assert body["title"] == "Enterprise"
        assert body["signer_email"] == "x@example.com"
        assert body["currency"] == "USD"
        assert body["payment_terms"] == "net_30"
        assert body["line_items"][0]["product_name"] == "Pro"

    @pytest.mark.asyncio
    async def test_update_quote_partial_body(self, client):
        _, tools = _register_quotes(client)
        client.put = AsyncMock(return_value={"data": {"id": "q1"}})
        await tools["g8_update_quote"].fn(quote_id="q1", title="Renamed")
        path, body = client.put.call_args.args
        assert path == "/quotes/q1"
        # Only the field actually passed should land on the wire.
        assert body == {"title": "Renamed"}

    @pytest.mark.asyncio
    async def test_update_quote_empty_returns_error(self, client):
        _, tools = _register_quotes(client)
        client.put = AsyncMock()
        result = await tools["g8_update_quote"].fn(quote_id="q1")
        # No fields → error string, no PUT issued.
        assert isinstance(result, str)
        assert "at least one field" in result.lower()
        client.put.assert_not_called()

    @pytest.mark.asyncio
    async def test_duplicate_quote_path(self, client):
        _, tools = _register_quotes(client)
        client.post = AsyncMock(return_value={"data": {"id": "q2"}})
        await tools["g8_duplicate_quote"].fn(quote_id="q1")
        path, body = client.post.call_args.args
        assert path == "/quotes/q1/duplicate"
        assert body == {}

    @pytest.mark.asyncio
    async def test_edit_as_draft_path(self, client):
        _, tools = _register_quotes(client)
        client.post = AsyncMock(return_value={"data": {"new_quote_id": "q2"}})
        await tools["g8_edit_quote_as_draft"].fn(quote_id="q1")
        path, body = client.post.call_args.args
        assert path == "/quotes/q1/edit-as-draft"
        assert body == {}

    @pytest.mark.asyncio
    async def test_send_quote_no_overrides(self, client):
        _, tools = _register_quotes(client)
        client.post = AsyncMock(return_value={"data": {"id": "q1", "status": "sent"}})
        await tools["g8_send_quote"].fn(quote_id="q1")
        path, body = client.post.call_args.args
        assert path == "/quotes/q1/send"
        # Empty body means backend falls back to default subject + message.
        assert body == {}

    @pytest.mark.asyncio
    async def test_send_quote_with_subject_and_message(self, client):
        _, tools = _register_quotes(client)
        client.post = AsyncMock(return_value={"data": {"id": "q1", "status": "sent"}})
        await tools["g8_send_quote"].fn(
            quote_id="q1", subject="Proposal", message="Please review."
        )
        path, body = client.post.call_args.args
        assert path == "/quotes/q1/send"
        assert body == {"subject": "Proposal", "message": "Please review."}

    @pytest.mark.asyncio
    async def test_delete_quote_path(self, client):
        _, tools = _register_quotes(client)
        client.delete = AsyncMock(return_value={"data": {"deleted": True}})
        result = await tools["g8_delete_quote"].fn(quote_id="q1")
        client.delete.assert_called_once_with("/quotes/q1")
        assert isinstance(result, ActionResult)


# ---------------------------------------------------------------------------
# QuotableProductsResult envelope dual-shape tolerance
# ---------------------------------------------------------------------------


class TestQuotableProductsEnvelope:
    @pytest.mark.asyncio
    async def test_direct_shape(self, client):
        _, tools = _register_quotes(client)
        client.get = AsyncMock(
            return_value={
                "items": [
                    {
                        "stripe_product_id": "prod_1",
                        "name": "Pro plan",
                        "source": "stripe",
                        "prices": [
                            {
                                "stripe_price_id": "price_1",
                                "unit_amount": 9900,
                                "currency": "USD",
                            }
                        ],
                    }
                ],
                "total": 1,
                "page": 1,
                "limit": 100,
            }
        )
        result = await tools["g8_list_quotable_products"].fn()
        assert isinstance(result, QuotableProductsResult)
        assert result.total == 1
        assert result.products[0].stripe_product_id == "prod_1"
        assert result.products[0].prices[0].unit_amount == 9900

    @pytest.mark.asyncio
    async def test_apiresponse_wrapper(self, client):
        _, tools = _register_quotes(client)
        client.get = AsyncMock(
            return_value={
                "data": {
                    "items": [
                        {
                            "manual_product_id": "mp_1",
                            "name": "Custom service",
                            "source": "manual",
                            "prices": [],
                        }
                    ],
                    "total": 1,
                    "page": 1,
                    "limit": 100,
                }
            }
        )
        result = await tools["g8_list_quotable_products"].fn()
        assert isinstance(result, QuotableProductsResult)
        assert result.products[0].manual_product_id == "mp_1"
        assert result.products[0].source == "manual"


# ---------------------------------------------------------------------------
# Error surfacing — when the backend returns a non-2xx, safe_call_typed
# must convert the G8ClientError into a plain string so the agent can
# decide how to react instead of crashing the tool call.
# ---------------------------------------------------------------------------


class TestErrorHandling:
    @pytest.mark.asyncio
    async def test_list_quotes_surface_error_string(self, client):
        from g8_mcp_server.client import G8ClientError

        _, tools = _register_quotes(client)

        async def fake_get(path, params=None):
            raise G8ClientError(500, "API error (500): boom")

        client.get = AsyncMock(side_effect=fake_get)
        result = await tools["g8_list_quotes"].fn()
        assert isinstance(result, str)
        assert "500" in result

    @pytest.mark.asyncio
    async def test_send_quote_surface_error_string(self, client):
        """Especially important on the destructive path — a failed send
        must not crash the tool. The agent sees the error and can decide
        whether to retry / escalate."""
        from g8_mcp_server.client import G8ClientError

        _, tools = _register_quotes(client)

        async def fake_post(path, body=None):
            raise G8ClientError(400, "API error (400): missing signer")

        client.post = AsyncMock(side_effect=fake_post)
        result = await tools["g8_send_quote"].fn(quote_id="q1")
        assert isinstance(result, str)
        assert "400" in result
