"""Unit tests for ``MailboxItem``'s new warmup fields surfaced through
``g8_gtm_list_mailboxes`` in 0.8.0.

The DTO must continue to validate older list payloads (without warmup
fields) AND surface the three new columns when present. Behaviour:

  * ``warmup_provider``, ``warmup_status``, ``smartlead_warmup_enabled``
    are all optional and default to None
  * Backwards compatibility: an old envelope without these keys still
    validates  -  ``extra="ignore"`` would silently drop unknown keys; the
    NEW keys must therefore be **declared** on the model itself.
"""

from __future__ import annotations

from pathlib import Path
from unittest.mock import AsyncMock

import pytest

import g8_mcp_server.client as client_module
from g8_mcp_server.client import G8Client
from g8_mcp_server.models import MailboxesResult, MailboxItem


@pytest.fixture
def mock_env(monkeypatch):
    monkeypatch.setenv("G8_API_KEY", "test_key_123")
    monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
    monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent-g8-creds.json"))


@pytest.fixture
def client(mock_env):
    return G8Client()


def _register_gtm_tools(client):
    from mcp.server import FastMCP

    from g8_mcp_server.tools import gtm

    server = FastMCP("test")
    gtm.register(server, client)
    return server, server._tool_manager._tools


def _tool_by_suffix(tools, suffix):
    for name, tool in tools.items():
        if name.endswith(suffix):
            return name, tool
    raise AssertionError(f"No tool ending in {suffix!r}")


class TestMailboxItemWarmupFields:
    """DTO-level: the model must accept all three new fields."""

    def test_accepts_all_three_warmup_fields(self):
        item = MailboxItem.model_validate(
            {
                "id": "1",
                "email": "foo@bar.com",
                "warmup_provider": "instantly",
                "warmup_status": "active",
                "smartlead_warmup_enabled": True,
            }
        )
        assert item.warmup_provider == "instantly"
        assert item.warmup_status == "active"
        assert item.smartlead_warmup_enabled is True

    def test_backwards_compat_old_envelope_no_warmup_keys(self):
        """An older list response that doesn't include any warmup keys must
        still validate cleanly  -  none of the new fields are required."""
        item = MailboxItem.model_validate(
            {
                "id": "1",
                "email": "foo@bar.com",
                "provider": "google",
                "connection_status": "active",
            }
        )
        assert item.warmup_provider is None
        assert item.warmup_status is None
        assert item.smartlead_warmup_enabled is None

    def test_smartlead_only_envelope(self):
        item = MailboxItem.model_validate(
            {
                "id": "9",
                "smartlead_warmup_enabled": False,
            }
        )
        assert item.smartlead_warmup_enabled is False
        assert item.warmup_provider is None


class TestListMailboxesSurfacesWarmupFields:
    """End-to-end through the tool: an HTTP envelope containing the new
    columns must propagate into the DTO output verbatim."""

    @pytest.mark.asyncio
    async def test_warmup_fields_surface_via_tool(self, client):
        _, tools = _register_gtm_tools(client)
        _, tool = _tool_by_suffix(tools, "list_mailboxes")

        client.get = AsyncMock(
            return_value={
                "data": [
                    {
                        "id": "mb-1",
                        "email": "rep@acme.com",
                        "provider": "google",
                        "connection_status": "active",
                        "warmup_provider": "instantly",
                        "warmup_status": "active",
                        "smartlead_warmup_enabled": None,
                    },
                    {
                        "id": "mb-2",
                        "email": "other@acme.com",
                        "provider": "outlook",
                        "connection_status": "active",
                        "warmup_provider": "smartlead",
                        "warmup_status": "warming",
                        "smartlead_warmup_enabled": True,
                    },
                ]
            }
        )

        result = await tool.fn()

        assert isinstance(result, MailboxesResult)
        assert len(result.mailboxes) == 2
        first, second = result.mailboxes
        assert first.warmup_provider == "instantly"
        assert first.warmup_status == "active"
        assert first.smartlead_warmup_enabled is None
        assert second.warmup_provider == "smartlead"
        assert second.smartlead_warmup_enabled is True

    @pytest.mark.asyncio
    async def test_tool_call_path_unchanged_for_backwards_compat(self, client):
        """The added DTO fields must NOT change the HTTP call shape."""
        _, tools = _register_gtm_tools(client)
        _, tool = _tool_by_suffix(tools, "list_mailboxes")

        client.get = AsyncMock(return_value={"data": []})

        await tool.fn(limit=20, include_archived=True, connection_status="paused")

        client.get.assert_called_once_with(
            "/mailboxes",
            {"limit": 20, "include_archived": True, "connection_status": "paused"},
        )
