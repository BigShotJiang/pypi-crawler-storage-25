# OrangeQS Zest

[![Apache 2.0 License](https://img.shields.io/badge/License-Apache_2.0-blue.svg)](https://gitlab.com/orangeqs/juice/-/blob/main/LICENSE)

OrangeQS Zest is a Python package that provides common tools for telemetry, licensing and other future business logic.
It is used as a dependency of OrangeQS Python packages.

## License

This project is licensed under the Apache 2.0 License.
