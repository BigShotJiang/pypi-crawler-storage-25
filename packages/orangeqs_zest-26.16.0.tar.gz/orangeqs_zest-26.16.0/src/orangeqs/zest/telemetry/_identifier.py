import functools
import logging
import uuid

from . import _config as config

_logger = logging.getLogger(__name__)

_SETUP_ID_FILENAME = "setup_id"
"""Config option name for the setup ID."""
_SETUP_NAME_FILENAME = "setup_name"
"""Config option name for the setup name."""

IDENTIFIER_FILENAME = "installation_id"
"""Filename for storing the generated installation ID in the config directory."""
_UUID_NAMESPACE_ZEST = uuid.UUID("c3d100ae-0632-4283-8609-8d45a7e3bc38")
"""Namespace UUID for generating stable identifiers based on setup ID and identity."""


def _generate_random_identifier() -> str:
    """Generate a new anonymous installation identifier."""
    return str(uuid.uuid4())


def _compute_stable_identifier(setup_id: str, identity: str) -> str:
    """Compute a stable anonymous identifier based on the setup ID and identity."""
    combined = f"{setup_id}:{identity}"
    return str(uuid.uuid5(_UUID_NAMESPACE_ZEST, combined))


@functools.cache
def _installation_id() -> str:
    """Get or generate a stable anonymous installation identifier.

    The identifier is stored in the config directory and is generated randomly on the
    first run.
    """
    identifier = config.config_value(IDENTIFIER_FILENAME)
    if identifier is not None:
        return identifier

    # Generate and store new identifier
    identifier = _generate_random_identifier()
    config_file = config.config_file(IDENTIFIER_FILENAME, writeable=True)
    config_file.parent.mkdir(parents=True, exist_ok=True)
    with open(config_file, "w", encoding="utf-8") as f:
        f.write(identifier)

    return identifier


@functools.cache
def _setup_identity() -> str | None:
    """Get the identity in the current setup, if available."""
    try:
        from orangeqs.juice.client.identity import (  # pyright: ignore[reportMissingImports]
            get_identity,  # pyright: ignore[ reportUnknownVariableType]
        )
    except ImportError:
        return None
    try:
        return "-".join(get_identity())  # pyright: ignore[reportUnknownArgumentType]
    except Exception:
        _logger.warning(
            (
                "Failed to get setup identity. "
                "Will not use an installation ID based on the setup ID and identity."
            ),
            exc_info=True,
        )
        return None


@functools.cache
def setup_id() -> str | None:
    """Get a stable identifier for the current setup, if available.

    The setup ID is a unique identifier for the current setup, for example
    a Juice installation. If multiple users or services are using the same setup,
    they will share the setup ID, but each have their own unique installation ID.
    """
    return config.config_value(_SETUP_ID_FILENAME)


@functools.cache
def setup_name() -> str | None:
    """Get the name of the current setup, if available.

    The setup name is a human-readable name for the current setup, for example
    "Juno".
    """
    return config.config_value(_SETUP_NAME_FILENAME)


def installation_id() -> str:
    """Get a stable anonymized installation identifier.

    If a setup ID is available, the identifier will be based on that.
    Otherwise, it will be a randomly generated UUID stored in the config directory.
    """
    if (_setup_id := setup_id()) is not None and (
        setup_identity := _setup_identity()
    ) is not None:
        return _compute_stable_identifier(_setup_id, setup_identity)

    return _installation_id()
