"""Telemetry module of the OrangeQS Zest package.

Provides functionality to register a package and its version for telemetry
reporting using OpenTelemetry metrics.

Examples
--------
The `register_package` function should be called from the package's __init__.py file
directly. Consent management is handled automatically, so metrics are only reported
if the user has given consent.

```python
from orangeqs.zest import telemetry

telemetry.register_package("my_package", __version__)
```
"""

from ._cli import is_cli_invoked
from ._consent import has_consented
from ._packages import register_package
from ._util import get_version

__all__ = ["register_package"]

# Register this package itself
register_package("orangeqs-zest", get_version())

# Only set up telemetry if not running the CLI
if not is_cli_invoked():
    if consent := has_consented():
        from ._opentelemetry import meter
        from ._packages import start_package_version_observable

        start_package_version_observable(meter())

    elif consent is None:
        pass
        # from ._consent import display_consent_warning

        # display_consent_warning()
