import logging

from . import _config as config

BASIC_CONSENT_FILENAME = "telemetry_basic_consent"


def set_consent(opt_in: bool) -> None:
    """Set user consent for basic telemetry (opt-in or opt-out)."""
    config_file = config.config_file(BASIC_CONSENT_FILENAME, writeable=True)
    config_file.parent.mkdir(parents=True, exist_ok=True)
    with open(config_file, "w", encoding="utf-8") as f:
        f.write("opt-in" if opt_in else "opt-out")


def has_consented() -> bool | None:
    """Determine whether the user has given consent for basic telemetry.

    A truthy value indicates consent given (opt-in), a falsy value indicates
    consent has not been given yet or has been explicitly denied (opt-out).

    Returns
    -------
    bool | None
        - True if the user has opted in
        - False if the user has opted out
        - None if no consent decision has been made
    """
    config_value = config.config_value(BASIC_CONSENT_FILENAME)
    if config_value is None:
        return None

    return config_value.lower() == "opt-in"


def reset_consent() -> None:
    """Remove the telemetry consent file, thereby resetting any consent decision."""
    config_file = config.config_file(BASIC_CONSENT_FILENAME, writeable=True)
    if config_file.exists():
        config_file.unlink()


def display_consent_warning() -> None:
    """Display a warning message about telemetry consent.

    Prints the warning to the logger as a warning. The warning instructs the user
    to make a decision about telemetry consent.
    """
    config_file = config.config_file(BASIC_CONSENT_FILENAME)

    warning = f"""
OrangeQS collects metrics to gather insights into how our software is used. \
These insights are used to improve our software. \
Your permission is required to collect these metrics.

To give consent, do one of the following:
    1. Run `orangeqs-telemetry accept basic`.
    2. Create the file {config_file} with the text "opt-in".

To silence this warning and not give consent, do one of the following:
    1. Run `orangeqs-telemetry reject basic`.
    1. Create the file {config_file} with the text "opt-out".
    """
    logging.getLogger("orangeqs.zest.telemetry").warning(warning)
