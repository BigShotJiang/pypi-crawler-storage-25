# OpenTelemetry metrics for package version reporting

from collections.abc import Iterable

from opentelemetry import metrics
from opentelemetry.sdk.metrics import Meter

_package_registry: dict[str, str] = {}


def register_package(package_name: str, version: str) -> None:
    """Register a package and its version for telemetry reporting.

    The package name and version will be reported in the
    'orangeqs_zest_package_version_info' metric.

    Parameters
    ----------
    package_name : str
        The name of the package to register. This should be the distribution name of the
        package, e.g. 'orangeqs-zest'.
    version : str
        The version of the package to register, e.g. '0.1.0'.
    """
    _package_registry[package_name] = version


def _package_versions_callback(options: object) -> Iterable[metrics.Observation]:
    """Yield an Observation for each registered package and version."""
    for package_name, version in _package_registry.items():
        yield metrics.Observation(
            1,
            attributes={
                "package": package_name,
                "version": version,
            },
        )


def start_package_version_observable(meter: Meter) -> None:
    """Start periodic metrics about registered packages and their versions.

    The metric is named 'orangeqs_zest_package_version_info' with attributes
    'package' and 'version'.
    """
    meter.create_observable_gauge(
        name="orangeqs_zest_package_version_info",
        callbacks=[_package_versions_callback],
        description="Reports installed versions of OrangeQS packages",
    )
