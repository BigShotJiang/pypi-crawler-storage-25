# Copyright The OpenTelemetry Authors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# Modified by Orange Quantum Systems.
#
# The original file can be found at:
# https://github.com/open-telemetry/opentelemetry-python/blob/b4c13279187941b561de5d62e6483a91759ba123/opentelemetry-sdk/src/opentelemetry/sdk/metrics/_internal/export/__init__.py
#
# The following modifications have been made:
# - Remove everything except for PeriodicExportingMetricReader
# - Modify PeriodicExportingMetricReader to report at an initial delay and then at a
#   regular interval.
# - Adhere to our own style guidelines.
#

from __future__ import annotations

import math
import os
import weakref
from logging import getLogger
from os import environ
from threading import Event, Lock, Thread
from time import time_ns
from typing import TYPE_CHECKING, Any

from opentelemetry.context import (
    _SUPPRESS_INSTRUMENTATION_KEY,  # pyright: ignore[reportPrivateUsage]
    attach,
    detach,
    set_value,
)
from opentelemetry.sdk.environment_variables import (
    OTEL_METRIC_EXPORT_INTERVAL,
    OTEL_METRIC_EXPORT_TIMEOUT,
)
from opentelemetry.sdk.metrics._internal.exceptions import MetricsTimeoutError
from opentelemetry.sdk.metrics.export import MetricExporter, MetricReader
from opentelemetry.util._once import Once

if TYPE_CHECKING:
    from opentelemetry.sdk.metrics._internal.point import MetricsData

_logger = getLogger(__name__)


class PeriodicExportingMetricReader(MetricReader):
    """MetricReader that collects metrics on a user-configurable time interval.

    `PeriodicExportingMetricReader` is an implementation of `MetricReader`
    that collects metrics based on a user-configurable time interval, and passes the
    metrics to the configured exporter. If the time interval is set to `math.inf`, the
    reader will not invoke periodic collection.

    The configured exporter's :py:meth:`~MetricExporter.export` method will not be
    called concurrently.
    """

    def __init__(
        self,
        exporter: MetricExporter,
        export_interval_millis: float | None = None,
        export_initial_millis: float | None = None,
        export_timeout_millis: float | None = None,
    ) -> None:
        # PeriodicExportingMetricReader defers to exporter for configuration
        super().__init__(  # pyright: ignore[reportUnknownMemberType]
            preferred_temporality=exporter._preferred_temporality,  # pyright: ignore[reportPrivateUsage]
            preferred_aggregation=exporter._preferred_aggregation,  # pyright: ignore[reportPrivateUsage, reportUnknownMemberType]
        )

        # This lock is held whenever calling self._exporter.export() to prevent
        # concurrent execution of MetricExporter.export()
        # https://github.com/open-telemetry/opentelemetry-specification/blob/main/specification/metrics/sdk.md#exportbatch
        self._export_lock = Lock()

        self._exporter = exporter
        if export_interval_millis is None:
            try:
                export_interval_millis = float(
                    environ.get(OTEL_METRIC_EXPORT_INTERVAL, 60000)
                )
            except ValueError:
                _logger.warning(
                    "Found invalid value for export interval, using default"
                )
                export_interval_millis = 60000
        if export_timeout_millis is None:
            try:
                export_timeout_millis = float(
                    environ.get(OTEL_METRIC_EXPORT_TIMEOUT, 30000)
                )
            except ValueError:
                _logger.warning("Found invalid value for export timeout, using default")
                export_timeout_millis = 30000
        self._export_interval_millis = export_interval_millis
        self._export_initial_millis = export_initial_millis
        self._export_timeout_millis = export_timeout_millis
        self._shutdown = False
        self._shutdown_event = Event()
        self._shutdown_once = Once()
        self._daemon_thread = None
        if self._export_interval_millis > 0 and self._export_interval_millis < math.inf:
            self._daemon_thread = Thread(
                name="OtelPeriodicExportingMetricReader",
                target=self._ticker,
                daemon=True,
            )
            self._daemon_thread.start()
            if hasattr(os, "register_at_fork"):
                weak_at_fork = weakref.WeakMethod(self._at_fork_reinit)

                os.register_at_fork(
                    after_in_child=lambda: weak_at_fork()()  # pylint: disable=unnecessary-lambda  # pyright: ignore[reportOptionalCall]
                )
        elif self._export_interval_millis <= 0:
            raise ValueError(
                f"interval value {self._export_interval_millis} is invalid \
                and needs to be larger than zero."
            )

    def _at_fork_reinit(self) -> None:
        self._daemon_thread = Thread(
            name="OtelPeriodicExportingMetricReader",
            target=self._ticker,
            daemon=True,
        )
        self._daemon_thread.start()

    def _ticker(self) -> None:
        interval_secs = self._export_interval_millis / 1e3
        initial_secs = (
            self._export_initial_millis / 1e3
            if self._export_initial_millis is not None
            else interval_secs
        )
        current_secs = initial_secs
        while not self._shutdown_event.wait(current_secs):
            current_secs = interval_secs
            try:
                self.collect(timeout_millis=self._export_timeout_millis)
            except MetricsTimeoutError:
                _logger.warning(
                    "Metric collection timed out. Will try again after %s seconds",
                    current_secs,
                    exc_info=True,
                )
        # one last collection below before shutting down completely
        try:
            self.collect(timeout_millis=self._export_interval_millis)
        except MetricsTimeoutError:
            _logger.warning(
                "Metric collection timed out.",
                exc_info=True,
            )

    def _receive_metrics(
        self,
        metrics_data: MetricsData,
        timeout_millis: float = 10_000,
        **kwargs: Any,  # noqa: ANN401
    ) -> None:
        token = attach(set_value(_SUPPRESS_INSTRUMENTATION_KEY, True))
        # pylint: disable=broad-exception-caught,invalid-name
        try:
            with self._export_lock:
                self._exporter.export(metrics_data, timeout_millis=timeout_millis)  # pyright: ignore[reportUnknownMemberType]
        except Exception:
            _logger.exception("Exception while exporting metrics")
        detach(token)

    def shutdown(self, timeout_millis: float = 30_000, **kwargs: Any) -> None:  # noqa: ANN401
        deadline_ns = time_ns() + timeout_millis * 10**6

        def _shutdown() -> None:
            self._shutdown = True

        did_set = self._shutdown_once.do_once(_shutdown)
        if not did_set:
            _logger.warning("Can't shutdown multiple times")
            return

        self._shutdown_event.set()
        if self._daemon_thread:
            self._daemon_thread.join(timeout=(deadline_ns - time_ns()) / 10**9)
        self._exporter.shutdown(timeout=(deadline_ns - time_ns()) / 10**6)  # pyright: ignore[reportUnknownMemberType]

    def force_flush(self, timeout_millis: float = 10_000) -> bool:
        super().force_flush(timeout_millis=timeout_millis)
        self._exporter.force_flush(timeout_millis=timeout_millis)
        return True
