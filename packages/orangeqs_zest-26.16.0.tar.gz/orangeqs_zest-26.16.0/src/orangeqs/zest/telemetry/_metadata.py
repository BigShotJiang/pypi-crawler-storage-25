import logging
import platform

from ._identifier import installation_id, setup_id, setup_name

_logger = logging.getLogger(__name__)


def system_metadata() -> dict[str, str]:
    """Collect system metadata for telemetry events."""
    return {
        "os_name": platform.system(),
        "os_version": _os_version(),
        "python_version": platform.python_version(),
        "python_implementation": platform.python_implementation(),
        "architecture": platform.machine(),
        "installation_id": installation_id(),
        "setup_id": setup_id() or "",
        "setup_name": setup_name() or "",
    }


def _os_version() -> str:
    """Return a human-readable OS version string.

    Uses the `distro` package on Linux, `platform.version()` otherwise.
    """
    if platform.system() != "Linux":
        return platform.version()

    try:
        import distro
    except ImportError:
        _logger.warning(
            (
                "Failed to import 'distro' package for OS version detection. "
                "Falling back to platform.version()."
            ),
        )
        return platform.version()

    return distro.name(pretty=True)
