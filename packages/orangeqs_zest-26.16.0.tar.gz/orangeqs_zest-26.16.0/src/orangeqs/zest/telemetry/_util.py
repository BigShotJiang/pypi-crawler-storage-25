def get_version() -> str:
    """Get the version from the `_version.py` file without importing the package."""
    import os
    from importlib.util import module_from_spec, spec_from_file_location

    pkg_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

    spec = spec_from_file_location(
        "version",
        os.path.join(pkg_path, "_version.py"),
    )
    assert spec is not None, (
        f"Could not load {os.path.join(pkg_path, '_version.py')} module"
    )
    module = module_from_spec(spec)
    assert spec.loader is not None, "Loader of the spec is None"
    spec.loader.exec_module(module)
    return module.__version__
