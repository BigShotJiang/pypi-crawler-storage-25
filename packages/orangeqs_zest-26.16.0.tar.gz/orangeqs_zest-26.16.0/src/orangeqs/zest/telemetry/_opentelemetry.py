from opentelemetry.exporter.otlp.proto.http.metric_exporter import OTLPMetricExporter
from opentelemetry.sdk.metrics import Meter, MeterProvider
from opentelemetry.sdk.metrics.export import (
    MetricExporter,
)
from opentelemetry.sdk.resources import Resource

from orangeqs.zest.telemetry._opentelemetry_exporter import (
    PeriodicExportingMetricReader,
)

from . import _config as config
from ._metadata import system_metadata

_SCOPE_NAME = "orangeqs.zest.telemetry"
_SCHEMA_VERSION = "v1"
_OTEL_ANONYMOUS_URL = "https://otel-anonymous.orangeqs.com"

_EXPORTER_OPTION_NAME = "exporter"
"""Name of the option to select the OpenTelemetry exporter."""
_REPORT_INITIAL_MILLIS = 60 * 1000  # 1 minute
"""Initial delay for the first metrics export in milliseconds."""
_REPORT_INTERVAL_MILLIS = 6 * 3600 * 1000  # 6 hours
"""Report interval for metrics export in milliseconds."""


resource = Resource.create({"service.name": "orangeqs-zest"})


def _development_exporter() -> MetricExporter:
    """OpenTelemetry exporter for development purposes, outputs to console."""
    from opentelemetry.sdk.metrics.export import ConsoleMetricExporter

    return ConsoleMetricExporter()


def _production_exporter() -> MetricExporter:
    """OpenTelemetry exporter for production use, outputs to a remote OTLP endpoint."""
    return OTLPMetricExporter(
        endpoint=_OTEL_ANONYMOUS_URL + "/v1/metrics",
        headers={"Content-Type": "application/x-protobuf"},
    )


_exporter_instance = None


def exporter() -> MetricExporter:
    """Return the instance of the OpenTelemetry MetricExporter.

    The exporter is chosen based on the OQS_ZEST_EXPORTER environment variable.
    Possible values are:
    - "production": uses the production exporter (default)
    - "development": uses the development exporter (console output)
    """
    global _exporter_instance
    if _exporter_instance is not None:
        return _exporter_instance

    exporter_name = config.config_value(
        _EXPORTER_OPTION_NAME, default="production"
    ).lower()
    if exporter_name == "production":
        _exporter_instance = _production_exporter()
    elif exporter_name == "development":
        _exporter_instance = _development_exporter()
    else:
        raise ValueError(f"Unknown exporter specified: {exporter_name}")

    return _exporter_instance


def meter() -> Meter:
    """Create and return an OpenTelemetry Meter with system metadata attributes.

    The meter is configured with a periodic exporting metric reader.
    """
    metric_reader = PeriodicExportingMetricReader(
        exporter(),
        export_interval_millis=_REPORT_INTERVAL_MILLIS,
        export_initial_millis=_REPORT_INITIAL_MILLIS,
    )
    provider = MeterProvider(resource=resource, metric_readers=[metric_reader])

    metric_reader.force_flush()
    meter = provider.get_meter(
        name=_SCOPE_NAME,
        version=_SCHEMA_VERSION,
        attributes=system_metadata(),
    )
    return meter
