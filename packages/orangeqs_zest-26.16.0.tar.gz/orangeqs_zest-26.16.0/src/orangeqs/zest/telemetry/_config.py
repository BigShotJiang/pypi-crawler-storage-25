import logging
import os
import platform
import typing
from pathlib import Path

ORANGEQS_ZEST_DIR = Path("orangeqs") / "zest"

_logger = logging.getLogger(__name__)

_USER_CONFIG_DIR_ENV_VAR = "OQS_ZEST_USER_CONFIG_DIR"
_SYSTEM_CONFIG_DIR_ENV_VAR = "OQS_ZEST_SYSTEM_CONFIG_DIR"


def user_config_dir() -> Path:
    """
    Return the platform-appropriate config directory for the given app name.

    Uses XDG on Linux, platform-specific on macOS/Windows.
    Can be overridden by the `OQS_ZEST_USER_CONFIG_DIR` environment variable.
    """
    if (env_dir := os.getenv(_USER_CONFIG_DIR_ENV_VAR)) is not None:
        return Path(env_dir)

    system = platform.system()
    if system == "Linux":
        xdg_config = os.environ.get("XDG_CONFIG_HOME")
        if xdg_config:
            return Path(xdg_config) / ORANGEQS_ZEST_DIR
        else:
            return Path.home() / ".config" / ORANGEQS_ZEST_DIR
    elif system == "Darwin":
        # macOS: ~/Library/Application Support/app_name
        return Path.home() / "Library" / "Application Support" / ORANGEQS_ZEST_DIR
    elif system == "Windows":
        appdata = os.environ.get("APPDATA")
        if appdata:
            return Path(appdata) / ORANGEQS_ZEST_DIR
        else:
            # Fallback to home directory
            return Path.home() / ORANGEQS_ZEST_DIR
    else:
        raise RuntimeError(f"Unsupported platform: {system}")


def system_config_dir() -> Path:
    """
    Return the platform-appropriate system config directory for the given app name.

    Uses /etc on Linux, platform-specific on macOS/Windows.
    Can be overridden by the `OQS_ZEST_SYSTEM_CONFIG_DIR` environment variable.
    """
    if (env_dir := os.getenv(_SYSTEM_CONFIG_DIR_ENV_VAR)) is not None:
        return Path(env_dir)

    system = platform.system()
    if system == "Linux":
        # Linux: /etc/app_name
        return Path("/etc") / ORANGEQS_ZEST_DIR
    elif system == "Darwin":
        # macOS: /Library/Application Support/app_name
        return Path("/Library") / "Application Support" / ORANGEQS_ZEST_DIR
    elif system == "Windows":
        programdata = os.environ.get("PROGRAMDATA")
        if programdata:
            return Path(programdata) / ORANGEQS_ZEST_DIR
        else:
            # Fallback to C:\Config
            return Path("C:/Config") / ORANGEQS_ZEST_DIR
    else:
        raise RuntimeError(f"Unsupported platform: {system}")


def config_file(filename: str, writeable: bool = False) -> Path:
    """Return the full path to a config file for the given filename.

    By default, looks up both the system config directory and the user config directory,
    and returns the first path where the file exists. If the file does not exist in
    either location, returns the path in the user config directory.
    If `writeable` is True, always returns the path in the user config directory.

    Parameters
    ----------
    filename : str
        The name of the config file (e.g., "installation_id").
    writeable : bool, optional
        Whether the file will be written to. If True, always return a path in the
        user config directory. If False, check the system config directory first and
        fall back to the user config directory if the file does not exist in the system
        config directory. Default is False.
    """
    if not writeable and (system_file := system_config_dir() / filename).exists():
        return system_file

    return user_config_dir() / filename


@typing.overload
def config_value(option_name: str, default: str) -> str: ...
@typing.overload
def config_value(option_name: str, default: None = None) -> str | None: ...
def config_value(option_name: str, default: str | None = None) -> str | None:
    """Return the value of a config option from a config file or environment variable.

    Determines the value by looking at the following locations. If not found, continues
    to the next option. If none of the options are found, returns the default value.
    - The `OQS_ZEST_{OPTION_NAME}` environment variable
        (e.g., `OQS_ZEST_INSTALLATION_ID`)
    - The `{system_config_dir}/{option_name}` config file.
    - The `{user_config_dir}/{option_name}` config file.

    Parameters
    ----------
    option_name : str
        The name of the config option (e.g., "installation_id").
    default : str | None, optional
        The default value to return if the config option is not found. Default is None.

    Returns
    -------
    str | None
        The value read from the config if found, otherwise the default value
        (which is None by default).
    """
    env_var = f"OQS_ZEST_{option_name.upper()}"
    if (value := os.getenv(env_var)) is not None:
        return value

    _config_file = config_file(option_name)
    if _config_file.exists():
        try:
            with open(_config_file, encoding="utf-8") as f:
                return f.read().strip()
        except Exception:
            _logger.warning(
                (f"Failed to read config file {_config_file}. Ignoring this file."),
                exc_info=True,
            )

    return default
