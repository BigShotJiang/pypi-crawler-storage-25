import sys


def is_cli_invoked() -> bool:
    """Check if the telemetry CLI is being invoked."""
    return any("orangeqs-telemetry" in arg for arg in sys.argv)


def main() -> int:
    """Entry point for the telemetry CLI."""
    from ._consent import reset_consent, set_consent

    if len(sys.argv) < 3:
        print("Usage: orangeqs-telemetry <accept|reject> basic")
        return 1

    action = sys.argv[1].lower()
    consent_type = sys.argv[2].lower()

    if consent_type != "basic":
        print(f"Unknown consent type: {consent_type}")
        return 1

    match action:
        case "accept":
            set_consent(True)
            print("You have opted in to basic telemetry.")
        case "reject":
            set_consent(False)
            print("You have opted out of basic telemetry.")
        case "reset":
            reset_consent()
            print("Your consent decision for basic telemetry has been reset.")
        case _:
            print(f"Unknown action: {action}")
            return 1

    return 0


if __name__ == "__main__":
    sys.exit(main())
