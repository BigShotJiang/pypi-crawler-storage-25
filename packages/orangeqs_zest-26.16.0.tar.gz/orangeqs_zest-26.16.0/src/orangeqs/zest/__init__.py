"""Common tools for OrangeQS packages, like telemetry and license management."""

from . import telemetry
from ._version import __version__  # pyright: ignore[reportUnknownVariableType]

__all__ = [
    "telemetry",
    "__version__",
]
