import os

from setuptools import setup


# Loads _version.py module without importing the whole package.
def get_version_and_cmdclass(pkg_path: str):
    import os
    from importlib.util import module_from_spec, spec_from_file_location

    spec = spec_from_file_location(
        "version",
        os.path.join(pkg_path, "_version.py"),
    )
    assert spec is not None, (
        f"Could not load {os.path.join(pkg_path, '_version.py')} module"
    )
    module = module_from_spec(spec)
    assert spec.loader is not None, "Loader of the spec is None"
    spec.loader.exec_module(module)
    return module.__version__, module.get_cmdclass(pkg_path)


version, cmdclass = get_version_and_cmdclass(os.path.join("src", "orangeqs", "zest"))

setup(
    version=version,
    cmdclass=cmdclass,
)
