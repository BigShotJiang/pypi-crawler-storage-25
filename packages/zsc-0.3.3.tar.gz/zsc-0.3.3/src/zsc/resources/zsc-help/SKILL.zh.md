---
name: zsc-help
description: 用于向用户介绍 zsc 及其用法的技能。当用户询问 zsc 是什么、如何使用 zsc、如何使用 zsc 技能，或需要 zsc 命令与对应 AI 技能概览时使用。回复请使用中文。
---

# zsc-help

**首次在回复中出现工具名时请写 zsc(zig slice code)，之后可单独使用 zsc。**

本技能用于介绍 zsc 与 zsc-* 技能的正确用法。仅做说明与建议，不改文件。

## 操作边界（强制）

- 只能介绍与建议。
- 不能创建任务、不能编辑任务、不能改代码。

## 核心技能一览（统一标准）

- `zsc-create-rfc`：创建/设计仓库内 RFC（仅 `docs/rfcs/`）。
  - RFC 是规格与决策文档，不是 TODO 清单。
  - 应覆盖目标、非目标、现状、方案、兼容性、安全性、可观测性、测试与发布策略。
  - 后续可继续驱动 `zsc-create-task-group` 做任务拆解。
- `zsc-create-task`：创建/设计任务（仅 `.agents/tasks/`）。
  - 强制要求：创建阶段就完成分析设计。
  - TODO 必须是工程可执行项，禁止“仅分析/仅设计/仅文档/仅任务管理”TODO。
  - 每条 TODO 必须包含：目标文件或模块 + 具体改动动作 + 验收标准。
- `zsc-create-task-group`：创建/设计任务组（`.agents/task-groups/`）并在 `.agents/tasks/` 下拆出真实子任务。
  - group 层只负责范围、workstream、依赖与任务引用。
  - 子任务仍必须满足 `zsc-create-task` 的同等质量标准。
- `zsc-update-task`：更新已有任务文档（仅编辑，不执行）。
  - TODO 质量标准与 `zsc-create-task` 完全一致。
  - 更新后任务应可直接交给 run 类技能执行。
- `zsc-run-task`：执行任务（交互式）。
  - 禁止只摘要任务。
  - 默认连续执行多个 TODO，而不是做一个就停。
  - 仅在真实阻塞时暂停（权限、缺关键输入、可复现环境故障、高风险动作）。
- `zsc-run-task-to-complete`：高自动化执行任务。
  - 第一目标是尽可能消灭 TODO_LIST，不是复述任务。
  - 默认一口气连续实施，直到清空或真实阻塞。
  - 标记 blocked 前至少有实质实现尝试与合理重试。
- `zsc-run-task-group-to-complete`：高自动化执行任务组。
  - 先读取 group 依赖，再连续推进所有可执行子任务。
  - 每完成一个 task 都要同步 group 状态，直到整组完成或真实阻塞。
- `zsc-task-list`：查看任务列表。
- `zsc-task-status`：查看任务健康度汇总。
- `zsc-help`：查看本说明。

## 推荐使用顺序

1. 写规格 / 提案：`zsc-create-rfc`
2. 新需求：`zsc-create-task`
3. RFC / 多任务工作流拆解：`zsc-create-task-group`
4. 任务过期/要重排：`zsc-update-task`
5. 逐步执行：`zsc-run-task`
6. 高自动化一口气执行：`zsc-run-task-to-complete`
7. 整组高自动化推进：`zsc-run-task-group-to-complete`
8. 查看任务：`zsc-task-list` / `zsc-task-status`

## CLI 对应关系（简版）

- `zsc init .`：初始化并安装技能。
- `zsc rfc new <title>` ↔ `zsc-create-rfc`
- `zsc task new <feat_name>` ↔ `zsc-create-task`
- `zsc task update [TASK]` ↔ `zsc-update-task`
- `zsc task list` ↔ `zsc-task-list`
- `zsc task status` ↔ `zsc-task-status`
- `zsc group new <group_name>` ↔ `zsc-create-task-group`
- `zsc group run [GROUP]` ↔ `zsc-run-task-group-to-complete`
- `zsc-run-task`、`zsc-run-task-to-complete` 为单任务 AI 执行技能（无直接同名 CLI 子命令）。

## 对用户的简短建议话术

- “先用 `zsc-create-task` 产出可执行 TODO，再用 run 类技能实施并清空 TODO_LIST。”
- “如果只是刷新任务，不要执行代码，用 `zsc-update-task`。”
- “想少交互、一口气推进，优先 `zsc-run-task-to-complete`。”
