---
name: zsc-create-task-group
description: 组合使用 zsc-create-task 的任务组设计技能：基于 RFC 或提示词在 .agents/task-groups 下创建一个 task-group，并在 .agents/tasks 下拆出一组可执行任务。仅负责创建与设计，不执行 TODO。回复请使用中文。
---

# zsc-create-task-group

**职责范围：只创建与设计任务组及其子任务，不执行 TODO。** 本技能负责在 `.agents/task-groups/` 中创建 task-group，并组合使用 `zsc-create-task` 在 `.agents/tasks/` 中创建该组下的一组任务。

## 组合关系（强制）

本技能不是 `zsc-create-task` 的替代品，而是其上层编排器：
- task-group 负责表达来源、范围、拆解、依赖和任务引用。
- 每个子任务仍必须使用 `zsc-create-task` 的标准创建方式与质量门槛。
- 禁止在 task-group markdown 中塞入本应属于单个 task 的详细 TODO。

## 操作边界（强制）

使用本技能时只能操作以下路径：
- `.agents/task-groups/`
- `.agents/tasks/`

可以：
- 创建/编辑 task-group 目录、group `.md`、`group_records/log/`
- 创建/编辑该 group 引用的 task 目录与 task `.md`

不可以：
- 修改 `.agents/task-groups/` 与 `.agents/tasks/` 之外的项目代码与文件
- 执行任何 task 的 TODO

## 输入要求

输入应为以下之一：
- 一个 RFC 文档路径
- 一段提示词/目标描述
- RFC + 补充约束

若输入是 RFC，必须先提炼：
- 目标范围
- 非目标
- 工作流/里程碑拆解
- 依赖关系
- 应落成的任务集合

## 创建结果（强制）

当用户要求创建 task-group 时，必须真实创建以下内容：

1. task-group 目录：
   - `.agents/task-groups/group_{no}_{group_name}/`
2. group 主文件：
   - `.agents/task-groups/group_{no}_{group_name}/group_{no}_{group_name}.md`
3. group 记录目录：
   - `.agents/task-groups/group_{no}_{group_name}/group_records/log/`
4. 一组实际 task：
   - `.agents/tasks/task_{no}_{feat_name}/`
   - `.agents/tasks/task_{no}_{feat_name}/task_{no}_{feat_name}.md`

若只写了 group markdown、没有真实创建子任务，视为未完成。

## task-group 设计门槛（强制）

在创建子任务前，应先完成 task-group 级设计，并写入 group markdown。

group 只承载以下内容：
- 来源 RFC / 提示词
- 目标与非目标
- workstreams / milestones
- 子任务列表
- 依赖关系
- 状态汇总规则

**禁止把以下内容写进 group 的任务项：**
- 具体代码级 TODO 细节
- “分析/调研/写文档/再拆任务”这类管理动作
- 任何应由单个 task 承担的闭环实现细节

## 子任务拆分规则（强制）

每个子任务必须满足：
- 是单个工程闭环，可交由 `zsc-run-task` 或 `zsc-run-task-to-complete` 独立执行
- 目标边界清晰，不与其他 task 大量重叠
- 具备明确依赖，能纳入 group 顺序
- 仍然遵守 `zsc-create-task` 的 TODO_LIST 约束

建议拆分尺度：
- 一个 task-group 通常包含 3-10 个子任务
- 单个 task 仍应是 1-2 小时级别的工程实施单元
- 若某个子任务仍然过大，应继续拆分为多个 task，而不是把细节压回 group

## 任务组结构

- 目录名：`group_{no}_{group_name}`
- group 文件名：`{group_dir_name}.md`（必须与目录同名）

group 文件固定包含：
1. `## 来源`
2. `## 目标`
3. `## 非目标`
4. `## Workstreams`
5. `## Tasks`
6. `## 依赖关系`
7. `## 状态汇总`

## Tasks 段落约束（强制）

`## Tasks` 中每项必须至少包含：
- task 名称
- task 文件路径
- 所属 workstream（可选但推荐）
- 初始状态

推荐格式：

```markdown
- [ ] `task_012_go_platform_bootstrap`
  路径：`.agents/tasks/task_012_go_platform_bootstrap/task_012_go_platform_bootstrap.md`
  归属：WS1
  状态：todo
```

## 状态汇总规则

group 自己不维护代码级 TODO，只维护任务级汇总：
- `todo`：task 尚未执行
- `doing`：task 正在执行
- `done`：task 已完成并清空 TODO_LIST
- `blocked`：task 因真实阻塞暂停

## 工作流

1. 读取 RFC 或提示词，提炼范围与非目标。
2. 设计 task-group 结构、workstreams、依赖关系。
3. 创建 task-group 目录、主文件和记录目录。
4. 拆分子任务清单。
5. 对每个子任务组合使用 `zsc-create-task` 的标准，真实创建 task 文件。
6. 在 group markdown 中登记所有 task 引用和初始状态。

## 模板

```markdown
# Task Group {no}: {group_name}

## 来源

- RFC: `docs/...`
- Prompt: `...`

## 目标

- ...

## 非目标

- ...

## Workstreams

- WS1: ...
- WS2: ...

## Tasks

- [ ] `task_012_xxx`
  路径：`.agents/tasks/task_012_xxx/task_012_xxx.md`
  归属：WS1
  状态：todo

- [ ] `task_013_xxx`
  路径：`.agents/tasks/task_013_xxx/task_013_xxx.md`
  归属：WS2
  状态：todo

## 依赖关系

- `task_013_xxx` 依赖 `task_012_xxx`

## 状态汇总

- total: 2
- todo: 2
- doing: 0
- done: 0
- blocked: 0
```

## 说明

- 本技能只负责创建 task-group 与子任务；执行请使用 `zsc-run-task-group-to-complete`。
- 单个子任务的设计标准完全复用 `zsc-create-task`，不要降低质量门槛。
- RFC 仍是架构与范围文档，不应被改造成任务管理文档。
