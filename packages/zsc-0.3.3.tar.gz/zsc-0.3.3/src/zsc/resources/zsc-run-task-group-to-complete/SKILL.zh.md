---
name: zsc-run-task-group-to-complete
description: 组合使用 zsc-run-task-to-complete 的任务组执行技能：读取 .agents/task-groups 下的一个 task-group markdown，按依赖顺序尽可能一口气执行并完成组内全部任务，同时回写 group 状态。回复请使用中文。
---

# zsc-run-task-group-to-complete

**职责范围：高自动化执行一个 task-group 下的全部子任务。** 本技能负责读取一个已有 task-group，组合使用 `zsc-run-task-to-complete` 连续执行组内 task，并更新 group 状态，直到可完成任务全部完成。

## 组合关系（强制）

本技能不是单任务执行器，而是 `zsc-run-task-to-complete` 的上层编排器：
- task-group 决定执行顺序、依赖与整体状态。
- 每个子任务的具体实施仍遵守 `zsc-run-task-to-complete` 的执行规则。
- 禁止跳过子任务直接在 group 文件里宣称完成。

## 操作边界（强制）

使用本技能时：
- 可以：读取/更新目标 task-group；执行其引用的 task；修改相关项目代码、测试、配置；同步回写任务与 group 状态。
- 不可以：新建无关 task；重写 task-group 设计；修改其他 group 的结构。

## 输入要求

输入必须是以下之一：
- `.agents/task-groups/group_{no}_{name}/{group_file}.md`
- 指向某个具体 task-group 的明确路径或编号

若无法定位唯一 group，才允许向用户澄清。

## 第一目标（强制）

第一目标是“消灭组内全部可完成 task”，不是“复述 group 内容”。

因此必须：
- 先读取 group，再执行子任务。
- 默认连续跑完整组，而不是只跑第一个 task。
- 在每个 task 完成后立即推进下一个可执行 task。

## 执行前校验（强制）

执行前必须完成：
1. 打开 group markdown。
2. 解析 `## Tasks` 与 `## 依赖关系`。
3. 确定任务拓扑顺序。
4. 校验每个 task 路径是否存在。

若 group 中某个 task 缺失：
- 记录到 group 中；
- 将其视为 blocked；
- 继续执行其他不受影响的 task。

## 连续执行循环

1. 找出所有“依赖已满足且状态不是 done 的 task”。
2. 按 group 顺序逐个执行：
   - 将 group 中该 task 状态更新为 `doing`
   - 组合使用 `zsc-run-task-to-complete` 执行该 task
   - 根据 task 文件实际结果回写 group 状态为 `done` 或 `blocked`
3. 每完成一个 task，立即刷新状态汇总。
4. 继续寻找下一批可执行 task。
5. 直到：
   - 全部 task 为 `done`；或
   - 剩余 task 全部因依赖或真实阻塞无法继续。

## blocked 规则（强制）

一个 task 只有在满足以下条件后才允许标记为 `blocked`：
- 已经实际调用并尝试执行 `zsc-run-task-to-complete`
- 任务文件中已有明确失败记录、报错摘要或继续条件

禁止仅因主观担心或未知实现复杂度就把 task 标记为 `blocked`。

若某个 task blocked，则必须：
- 在 group 中记录其 blocked 原因摘要
- 标明受其影响的下游 task
- 继续执行不受影响的其他 task

## 完成收口（强制）

当 group 中所有 task 都为 `done` 时：
1. 更新 `## 状态汇总` 为全完成状态。
2. 在 group 文件追加一条带日期的完成记录。
3. 明确说明本轮已完成全部子任务。

若未全部完成，则必须在 group 中保留：
- 当前状态汇总
- blocked task 列表
- 下一步继续条件

## group 状态同步规则

每次 task 状态变化后，都必须同步以下信息：
- `total`
- `todo`
- `doing`
- `done`
- `blocked`

task 的完成判定以 task 文件为准：
- 若 task 的 `## TODO_LIST` 已被清空并仅保留完成记录，视为 `done`
- 若 task 明确存在 blocked 记录，视为 `blocked`
- 其他未完成状态视为 `todo` 或 `doing`

## 工作流

1. 打开 group markdown，读取任务清单和依赖。
2. 计算可执行任务集合。
3. 逐个组合使用 `zsc-run-task-to-complete` 执行子任务。
4. 每完成一个 task，就回写 group 状态。
5. 循环推进，直到整组完成或出现真实阻塞。

## 模板约定

group 文件中建议保留如下状态格式：

```markdown
## Tasks

- [x] `task_012_xxx`
  路径：`.agents/tasks/task_012_xxx/task_012_xxx.md`
  归属：WS1
  状态：done

- [ ] `task_013_xxx`
  路径：`.agents/tasks/task_013_xxx/task_013_xxx.md`
  归属：WS2
  状态：blocked
  原因：缺少数据库访问凭据

## 状态汇总

- total: 2
- todo: 0
- doing: 0
- done: 1
- blocked: 1
```

## 与其他技能的关系

- `zsc-create-task-group`：创建 group 和子任务，不执行。
- `zsc-create-task`：创建单个任务。
- `zsc-run-task-to-complete`：执行单个任务。

本技能负责“整组推进”，不负责重新设计 group 架构。
