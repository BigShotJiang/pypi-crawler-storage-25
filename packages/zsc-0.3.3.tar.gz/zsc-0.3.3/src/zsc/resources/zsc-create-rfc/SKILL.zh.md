---
name: zsc-create-rfc
description: 在仓库内 docs/rfcs 下创建带编号 RFC 的技能。由 `zsc init` 安装；对应 `zsc rfc new`。用于把一个需求、架构改动、协议演进或工程治理提案沉淀成高规格的仓库内 RFC。仅负责创建与设计 RFC，不执行代码实现。回复请使用中文。
---

# zsc-create-rfc

**职责范围：只创建与设计 RFC，不执行代码实现。** 本技能负责在仓库 `docs/rfcs/` 下创建带编号 RFC，并将其补全为具有技术规格约束力的工程提案。

## 操作边界（强制）

使用本技能时：
- 可以：读取代码库以理解上下文；创建/编辑 `docs/rfcs/` 下的 RFC 文件。
- 不可以：修改 `docs/rfcs/` 之外的项目代码、任务文件或任务组文件。
- 不可以：把 RFC 当成任务 TODO 文档来写。

## 创建 RFC 必须落地文件（强制）

当用户要求创建 RFC 时，必须真实创建文件：
1. 推荐执行：`zsc rfc new <title>`。
2. 或手工创建：`docs/rfcs/rfc_{no}_{slug}.md`。

若未在 `docs/rfcs/` 下创建真实 RFC 文件，视为未完成。

## RFC 的定位（强制）

RFC 不是普通说明文档，也不是 task 管理文档。RFC 必须承担以下职责：
- 准确描述当前问题与动机
- 给出可审查、可争论、可落地的提案
- 明确目标、非目标、兼容性、安全性、可观测性、测试与发布策略
- 为后续 task-group / tasks 提供稳定规格输入

因此，RFC 必须具备“可规格化”能力，而不仅是“有个想法”。

## 规格化要求（强制）

RFC 默认采用强规格模板，至少满足：
- 明确 `Metadata`，包含编号、状态、作者、评审、日期
- 明确 `Goals` 与 `Non-Goals`
- 明确 `Current State`
- 明确 `Detailed Proposal`
- 明确 `Technical Specification`
- 明确 `Compatibility and Migration`
- 明确 `Security Considerations`
- 明确 `Observability and Operations`
- 明确 `Testing and Acceptance`
- 明确 `Rollout and Rollback`
- 明确 `Alternatives Considered`
- 明确 `Risks and Open Questions`

在合适场景下，应使用与文档语言一致的规范措辞：
- 若 RFC 为中文，正文与规则项应优先使用中文规范术语：
  - `必须`：对应 `MUST`
  - `应当`：对应 `SHOULD`
  - `可以`：对应 `MAY`
- 若 RFC 为英文，可使用英文规范术语：
  - `MUST`
  - `SHOULD`
  - `MAY`

中文 RFC 中，除非有明确保留英文术语的必要，不应直接在正文规范句里混用 `MUST`、`SHOULD`、`MAY`，以免阅读体验割裂。

## 输入要求

输入可以是：
- 一段需求/目标描述
- 一个架构问题
- 一个接口/协议提案
- 一个工程治理提案
- 现有文档路径 + 补充约束

若输入较模糊，先通过阅读仓库上下文把提案锚定到具体模块、接口、边界或运行约束，再写 RFC。

## 内容质量门槛（强制）

RFC 不得停留在泛泛而谈。至少要做到：
- 指出受影响的模块、目录、边界、数据流或接口契约
- 写清楚方案的核心不变量与失败模式
- 说明为什么替代方案未被采用
- 给出兼容性、迁移与回滚策略
- 给出安全与可观测性要求
- 给出可测试、可验收的完成标准

禁止写成以下类型：
- 纯背景介绍
- 纯愿景文案
- 纯任务拆单
- 只列口号不列规格约束

## 状态约定

RFC 元数据里的 `Status` 默认从以下状态中选择：
- `Draft`
- `Review`
- `Accepted`
- `Implemented`
- `Rejected`
- `Superseded`

新创建 RFC 默认写为 `Draft`。

## 与任务体系的关系

- RFC 是规格与决策文档，不直接替代 task。
- 当 RFC 进入可实施状态后，可进一步使用 `zsc-create-task-group` 将 RFC 拆成任务组与子任务。
- RFC 中可以预留 `Related Task Group` 字段，但不要把任务 TODO 直接塞进 RFC。

## 工作流

1. 若还没有 RFC 文件，先创建 `docs/rfcs/rfc_{no}_{slug}.md`。
2. 阅读必要代码与文档上下文。
3. 写出问题背景、目标、非目标与现状。
4. 写出详细方案与技术规格。
5. 补齐兼容性、安全、可观测性、测试、发布、替代方案与风险。
6. 确保 RFC 可作为后续任务拆解输入。

## 推荐模板结构

RFC 文件应至少包含以下章节：
1. `## Metadata`
2. `## Summary`
3. `## Motivation`
4. `## Goals`
5. `## Non-Goals`
6. `## Terminology`
7. `## Current State`
8. `## Detailed Proposal`
9. `## Compatibility and Migration`
10. `## Security Considerations`
11. `## Observability and Operations`
12. `## Testing and Acceptance`
13. `## Rollout and Rollback`
14. `## Alternatives Considered`
15. `## Risks and Open Questions`
16. `## Prior Art and References`
17. `## Implementation Notes`

## 说明

- 本技能只负责创建与设计 RFC；不执行代码改动。
- 若用户想从 RFC 拆任务，请转交 `zsc-create-task-group`。
- 只维护 RFC 的最新有效版本，删除明显过时内容。
