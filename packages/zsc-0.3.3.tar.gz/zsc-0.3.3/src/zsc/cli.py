from __future__ import annotations

import os
import shutil
import subprocess
import sys
from datetime import date
import importlib.resources as importlib_resources
from pathlib import Path
from typing import List, Optional

import typer

from zsc import __version__ as ZSC_VERSION

# Where we persist the user's chosen skill language (under project root).
ZSC_LANG_FILE = ".agents/zsc-lang"
SUPPORTED_LANGS = ("en", "zh")


APP_HELP = (
    f"zsc(zig slice code) {ZSC_VERSION}: 初始化并管理基于 .agents/tasks、.agents/task-groups 与 docs/rfcs 的 AI Agents 任务体系。"
    "除 init 外，每个子命令对应一个 zsc-* 技能，由 zsc init 安装到各 AI Coding 工具的 skills 目录。"
)

app = typer.Typer(help=APP_HELP)


@app.callback(invoke_without_command=True)
def main(
    ctx: typer.Context,
    upgrade: bool = typer.Option(
        False,
        "-U",
        "--upgrade",
        help="强制升级 zsc 包到最新版本（运行后退出）。/ Force upgrade zsc package to latest, then exit.",
    ),
    version: bool = typer.Option(
        False,
        "-V",
        "--version",
        help="显示当前 zsc 版本后退出。/ Show current zsc version and exit.",
    ),
) -> None:
    """
    zsc(zig slice code) 是一个为多 IDE / AI Coding 工具初始化和管理 `.agents/tasks` / `.agents/task-groups` / `docs/rfcs` 任务体系的命令行工具。
    """
    if version:
        typer.echo(f"zsc {ZSC_VERSION}")
        raise typer.Exit()

    if upgrade:
        _do_upgrade()
        raise typer.Exit()

    # 当没有指定子命令时，输出工具的整体目的和常用用法。
    if ctx.invoked_subcommand is None:
        typer.echo(
            f"zsc(zig slice code) {ZSC_VERSION}: 初始化并管理基于 .agents/tasks、.agents/task-groups 与 docs/rfcs 的 AI Agents 任务体系。\n\n"
            "常用命令（除 init 外，每个子命令对应一个 zsc-* 技能，由 zsc init 安装到各 AI Coding 工具的 skills 目录）：\n"
            "  zsc init .            在当前项目中创建 .agents、docs/rfcs 与 skills 目录\n"
            "  zsc task list         列出 .agents/tasks 下的任务及状态（技能: zsc-task-list）\n"
            "  zsc task new NAME     创建新的 task_{no}_{NAME} 任务目录（技能: zsc-create-task）\n"
            "  zsc task status       汇总任务状态（技能: zsc-task-status）\n"
            "  zsc task update [TASK]  更新某任务内容（技能: zsc-update-task）\n"
            "  zsc group new NAME    创建新的 group_{no}_{NAME} 任务组目录（技能: zsc-create-task-group）\n"
            "  zsc group run [GROUP]  定位并执行某任务组（技能: zsc-run-task-group-to-complete）\n"
            "  zsc rfc new TITLE     在 docs/rfcs 下创建带编号 RFC（技能: zsc-create-rfc）\n"
            "  （执行/推进任务请用技能: zsc-run-task；在安全环境中尽量一口气跑完整个任务，可考虑高级技能: zsc-run-task-to-complete）\n\n"
            "在 AI Coding 环境中可触发 zsc-help 技能（如 Cursor 中 /zsc-help）获取用法介绍。\n\n"
            "更多信息请见项目 README.md，或运行 `zsc --help` 查看完整命令列表。"
        )
        raise typer.Exit()


def _detect_broken_venv_python(base: Path) -> Optional[Path]:
    """
    Detect a broken virtualenv Python under .venv that is a dangling symlink.

    Returns the first broken interpreter path, or None if none found.
    """
    candidates = [
        base / ".venv" / "bin" / "python",
        base / ".venv" / "bin" / "python3",
        base / ".venv" / "Scripts" / "python.exe",
    ]
    for candidate in candidates:
        try:
            if candidate.is_symlink() and not candidate.exists():
                return candidate
        except OSError:
            # If the filesystem entry cannot be inspected, ignore and continue.
            continue
    return None


def _do_upgrade() -> None:
    """Force upgrade zsc package to latest via uv tool or pip, with env-aware fallbacks."""
    typer.echo("[zsc] Upgrading zsc to latest version...")

    base = Path.cwd()
    broken_venv_python = _detect_broken_venv_python(base)

    uv_path = shutil.which("uv")
    used_uv = False

    if uv_path and not broken_venv_python:
        cmd = ["uv", "tool", "install", "zsc", "--upgrade"]
        used_uv = True
    else:
        if uv_path and broken_venv_python:
            typer.echo(
                f"[zsc] Detected broken virtualenv interpreter at {broken_venv_python}. "
                "Skipping uv-based upgrade; consider recreating this environment with "
                "`uv venv` or your virtualenv tool.",
                err=True,
            )
        cmd = [sys.executable, "-m", "pip", "install", "-U", "zsc"]

    try:
        result = subprocess.run(cmd, check=False)
        if result.returncode != 0:
            if used_uv:
                # uv is available but failed; try a pip-based fallback before giving up.
                typer.echo(
                    "[zsc] uv-based upgrade failed, trying `pip install -U zsc` ...",
                    err=True,
                )
                fallback_cmd = [sys.executable, "-m", "pip", "install", "-U", "zsc"]
                fallback_result = subprocess.run(fallback_cmd, check=False)
                if fallback_result.returncode == 0:
                    typer.echo(
                        "[zsc] Upgrade finished via pip. Run `zsc` again to use the new version."
                    )
                    return

            typer.echo(
                "[zsc] Upgrade failed. You can try manually:\n"
                "  - uv tool install zsc --upgrade\n"
                "  - or: pip install -U zsc",
                err=True,
            )
            raise typer.Exit(1)

        typer.echo("[zsc] Upgrade finished. Run `zsc` again to use the new version.")
    except FileNotFoundError:
        typer.echo(
            "[zsc] Could not run upgrade command. "
            "Try: uv tool install zsc --upgrade or pip install -U zsc",
            err=True,
        )
        raise typer.Exit(1)


def _ensure_dir(path: Path) -> bool:
    """
    Ensure directory exists.

    Returns True if created, False if already existed.
    """
    if path.exists():
        return False
    path.mkdir(parents=True, exist_ok=True)
    return True


# Skills installed by `zsc init`. Each zsc command (except init) has a corresponding skill; zsc-help is the overview/help skill.
# zsc-run-task-to-complete is an advanced, high-automation execution skill built on top of zsc-run-task.
ZSC_SKILLS = [
    "zsc-help",
    "zsc-create-rfc",
    "zsc-create-task",
    "zsc-create-task-group",
    "zsc-run-task",
    "zsc-run-task-group-to-complete",
    "zsc-run-task-to-complete",
    "zsc-task-list",
    "zsc-task-status",
    "zsc-update-task",
]


def _normalize_lang(raw: str) -> str:
    """Return 'en' or 'zh' from user input or config."""
    v = raw.strip().lower()
    if v in ("en", "english", "2"):
        return "en"
    if v in ("zh", "chinese", "中文", "1", ""):
        return "zh"
    return "en"


def _get_init_lang(base: Path, lang_option: Optional[str]) -> str:
    """
    Determine language for skill prompts: from --lang, from .agents/zsc-lang, or interactive prompt.
    Returns 'en' or 'zh'.
    """
    lang_file = base / ZSC_LANG_FILE

    if lang_option is not None:
        lang = _normalize_lang(lang_option)
        return lang

    if lang_file.exists():
        try:
            return _normalize_lang(lang_file.read_text(encoding="utf-8"))
        except Exception:
            pass

    if not sys.stdin.isatty():
        return _normalize_lang(os.environ.get("ZSC_LANG", "en"))

    typer.echo(
        "[zsc] Skill 提示语言 / Language for skill prompts:\n"
        "  (1) 中文  (2) English\n"
        "  输入 1 或 2 选择 / Enter 1 or 2 (also accept: zh, en). 直接回车默认为中文 / Press Enter for 中文.\n"
    )
    try:
        raw = input("请输入 1 或 2 / Enter 1 or 2 [1]: ").strip() or "1"
    except (EOFError, KeyboardInterrupt):
        raw = "1"
    lang = _normalize_lang(raw)
    return lang


def _install_skill_if_missing(
    target_root: Path,
    tool_dir: str,
    skill_name: str,
    lang: str,
    created_messages: list[str],
) -> None:
    """
    Ensure the given zsc-* skill SKILL.md exists under the tool's skills directory.
    Uses SKILL.zh.md for Chinese (lang='zh'), SKILL.md for English.
    Overwrites existing SKILL.md so that re-running `zsc init` keeps all skills in the chosen language.
    """
    skills_root = target_root / tool_dir / "skills"
    created = _ensure_dir(skills_root)
    if created:
        created_messages.append(f"created directory: {skills_root}")

    target_skill_dir = skills_root / skill_name
    created_skill_dir = _ensure_dir(target_skill_dir)
    if created_skill_dir:
        created_messages.append(f"created directory: {target_skill_dir}")

    target_skill_file = target_skill_dir / "SKILL.md"
    content = _read_skill_template(skill_name, lang)
    target_skill_file.write_text(content, encoding="utf-8")
    created_messages.append(f"wrote: {target_skill_file}")


def _read_skill_template(skill_name: str, lang: str) -> str:
    resource_dir = importlib_resources.files("zsc").joinpath("resources", skill_name)
    candidate_names = ["SKILL.zh.md", "SKILL.md"] if lang == "zh" else ["SKILL.md"]
    for resource_name in candidate_names:
        resource_file = resource_dir / resource_name
        if resource_file.is_file():
            return resource_file.read_text(encoding="utf-8")
    raise FileNotFoundError(f"Skill template not found for {skill_name}: {candidate_names}")


def _tasks_root(base: Path) -> Path:
    agents_dir = base / ".agents"
    tasks_dir = agents_dir / "tasks"
    _ensure_dir(agents_dir)
    _ensure_dir(tasks_dir)
    return tasks_dir


def _task_groups_root(base: Path) -> Path:
    agents_dir = base / ".agents"
    groups_dir = agents_dir / "task-groups"
    _ensure_dir(agents_dir)
    _ensure_dir(groups_dir)
    return groups_dir


def _rfcs_root(base: Path) -> Path:
    docs_dir = base / "docs"
    rfcs_dir = docs_dir / "rfcs"
    _ensure_dir(docs_dir)
    _ensure_dir(rfcs_dir)
    return rfcs_dir


def _iter_task_dirs(tasks_root: Path) -> List[Path]:
    if not tasks_root.exists():
        return []
    return sorted(
        [p for p in tasks_root.iterdir() if p.is_dir() and p.name.startswith("task_")],
        key=lambda p: p.name,
    )


def _resolve_task_dir(tasks_root: Path, identifier: str) -> Optional[Path]:
    """Resolve task identifier (e.g. '02', 'task_02', 'task_02_foo') to task directory, or None."""
    if not tasks_root.exists():
        return None
    ident = identifier.strip().lower()
    for d in _iter_task_dirs(tasks_root):
        if d.name == ident or d.name.lower() == ident:
            return d
        parts = d.name.split("_", 2)
        if ident.isdigit() and len(parts) >= 2 and parts[1] == ident.zfill(2):
            return d
        if ident in d.name or d.name.endswith("_" + ident):
            return d
    return None


def _iter_group_dirs(groups_root: Path) -> List[Path]:
    if not groups_root.exists():
        return []
    return sorted(
        [p for p in groups_root.iterdir() if p.is_dir() and p.name.startswith("group_")],
        key=lambda p: p.name,
    )


def _resolve_group_dir(groups_root: Path, identifier: str) -> Optional[Path]:
    """Resolve group identifier (e.g. '02', 'group_02', 'group_02_bootstrap') to group directory."""
    if not groups_root.exists():
        return None
    ident = identifier.strip().lower()
    for d in _iter_group_dirs(groups_root):
        if d.name == ident or d.name.lower() == ident:
            return d
        parts = d.name.split("_", 2)
        if ident.isdigit() and len(parts) >= 2 and parts[1] == ident.zfill(2):
            return d
        if ident in d.name or d.name.endswith("_" + ident):
            return d
    return None


def _task_md_path(task_dir: Path) -> Path:
    """
    Path to the task markdown file. Canonical name is task_dir/task_dir_name.md
    (e.g. task_03_init_lang_prompt.md) so AI Coding tools can reference by unique path.
    We never create task.md; fallback to task.md only when reading legacy tasks.
    """
    named_md = task_dir / f"{task_dir.name}.md"
    legacy_md = task_dir / "task.md"
    if named_md.exists():
        return named_md
    if legacy_md.exists():
        return legacy_md
    return named_md


def _group_md_path(group_dir: Path) -> Path:
    """
    Path to the group markdown file. Canonical name is group_dir/group_dir_name.md.
    """
    named_md = group_dir / f"{group_dir.name}.md"
    legacy_md = group_dir / "group.md"
    if named_md.exists():
        return named_md
    if legacy_md.exists():
        return legacy_md
    return named_md


def _slugify_name(raw: str) -> str:
    cleaned = raw.strip().replace("-", "_").replace(" ", "_")
    parts = [part for part in cleaned.split("_") if part]
    if not parts:
        return "untitled"
    return "_".join(parts).lower()


def _next_rfc_no(rfcs_root: Path) -> int:
    max_no = 0
    if not rfcs_root.exists():
        return 1
    for path in rfcs_root.iterdir():
        if not path.is_file() or path.suffix != ".md":
            continue
        name = path.stem
        if not name.startswith("rfc_"):
            continue
        parts = name.split("_", 2)
        if len(parts) < 2 or not parts[1].isdigit():
            continue
        max_no = max(max_no, int(parts[1]))
    return max_no + 1


def _parse_task_md(task_dir: Path) -> tuple[str, Optional[str]]:
    """
    Return (display_name, status) for a task directory.

    Status is a coarse-grained string: "completed" or "open".
    """
    task_md = _task_md_path(task_dir)
    if not task_md.exists():
        return (task_dir.name, None)

    text = task_md.read_text(encoding="utf-8").splitlines()

    title = task_dir.name
    for line in text:
        stripped = line.strip()
        if stripped.startswith("# Task"):
            title = stripped.lstrip("# ").strip()
            break

    # Heuristic: if we see completion marker and没有未完成的复选框，则认为已完成
    completed_marker = "（本轮已完成，TODO 清空）"
    has_completed_marker = any(completed_marker in line for line in text)
    has_open_todo = any(line.strip().startswith("- [ ]") for line in text)

    if has_completed_marker and not has_open_todo:
        status = "completed"
    elif has_open_todo:
        status = "open"
    else:
        status = None

    return (title, status)


@app.command("init")
def init(
    path: str = typer.Argument(
        ".",
        help="Target project root directory to initialize (default: current directory).",
    ),
    lang: Optional[str] = typer.Option(
        None,
        "--lang",
        help="Skill prompt language: zh (中文) or en (English). If not set, prompts interactively or uses existing .agents/zsc-lang.",
    ),
) -> None:
    """
    初始化项目中的 .agents、任务、任务组与 docs/rfcs 目录，并将各 zsc-* 技能安装到 .cursor/.codex/.claude/.opencode/.trae 的 skills 目录（仅当目标不存在时写入）。
    首次运行时会提示选择技能提示语言（中文/English）；也可通过 --lang zh 或 --lang en 指定。
    """
    base = Path(path).expanduser().resolve()

    if not base.exists():
        raise typer.BadParameter(f"Target path does not exist: {base}")

    typer.echo(f"[zsc] Initializing project at: {base}")

    created_messages: list[str] = []

    # Ensure .agents, .agents/tasks, .agents/task-groups and docs/rfcs directories
    agents_dir = base / ".agents"
    tasks_dir = agents_dir / "tasks"
    groups_dir = agents_dir / "task-groups"
    docs_dir = base / "docs"
    rfcs_dir = docs_dir / "rfcs"

    if _ensure_dir(agents_dir):
        created_messages.append(f"created directory: {agents_dir}")
    else:
        created_messages.append(f"directory exists: {agents_dir}")

    if _ensure_dir(tasks_dir):
        created_messages.append(f"created directory: {tasks_dir}")
    else:
        created_messages.append(f"directory exists: {tasks_dir}")

    if _ensure_dir(groups_dir):
        created_messages.append(f"created directory: {groups_dir}")
    else:
        created_messages.append(f"directory exists: {groups_dir}")

    if _ensure_dir(docs_dir):
        created_messages.append(f"created directory: {docs_dir}")
    else:
        created_messages.append(f"directory exists: {docs_dir}")

    if _ensure_dir(rfcs_dir):
        created_messages.append(f"created directory: {rfcs_dir}")
    else:
        created_messages.append(f"directory exists: {rfcs_dir}")

    # Resolve skill language (prompt if needed) and persist
    chosen_lang = _get_init_lang(base, lang)
    if chosen_lang not in SUPPORTED_LANGS:
        chosen_lang = "en"
    lang_file = base / ZSC_LANG_FILE
    try:
        lang_file.write_text(chosen_lang + "\n", encoding="utf-8")
    except Exception:
        pass
    created_messages.append(f"skill language: {chosen_lang} ({'中文' if chosen_lang == 'zh' else 'English'})")

    # Install zsc-* skills for each AI Coding tool (one skill per zsc command, except init)
    for tool_dir in (".cursor", ".codex", ".claude", ".opencode", ".trae"):
        for skill_name in ZSC_SKILLS:
            _install_skill_if_missing(base, tool_dir, skill_name, chosen_lang, created_messages)

    typer.echo("[zsc] Initialization summary:")
    for msg in created_messages:
        typer.echo(f"  - {msg}")

    typer.echo("[zsc] Done. You can now use AI Agents with the initialized task structure.")


task_app = typer.Typer(
    help="管理 .agents/tasks 下的任务。各子命令对应技能：list → zsc-task-list，new → zsc-create-task，status → zsc-task-status，update → zsc-update-task；执行任务 → zsc-run-task（由 zsc init 安装）。"
)


@task_app.command("list")
def task_list(
    path: str = typer.Argument(
        ".",
        help="Project root to scan for .agents/tasks.",
    ),
) -> None:
    """
    列出 .agents/tasks 下的任务及状态。对应技能：zsc-task-list（由 zsc init 安装）。
    """
    base = Path(path).expanduser().resolve()
    tasks_root = _tasks_root(base)
    task_dirs = _iter_task_dirs(tasks_root)

    if not task_dirs:
        typer.echo(f"[zsc] No tasks found under {tasks_root}")
        return

    typer.echo(f"[zsc] Tasks under {tasks_root}:")
    for task_dir in task_dirs:
        title, status = _parse_task_md(task_dir)
        status_display = status or "unknown"
        typer.echo(f"  - {task_dir.name:24} [{status_display}] {title}")


@task_app.command("new")
def task_new(
    feat_name: str = typer.Argument(
        ...,
        help="Feature name for the new task, used in directory name.",
    ),
    path: str = typer.Argument(
        ".",
        help="Project root where .agents/tasks resides.",
    ),
) -> None:
    """
    创建新的 task_{no}_{feat_name} 目录与同名的 task_{no}_{feat_name}.md 模板。对应技能：zsc-create-task（由 zsc init 安装）。创建后可在 AI Coding 工具中触发该技能完善闭环描述与 TODO_LIST。
    """
    base = Path(path).expanduser().resolve()
    tasks_root = _tasks_root(base)

    existing = _iter_task_dirs(tasks_root)
    max_no = 0
    for d in existing:
        parts = d.name.split("_", 2)
        if len(parts) >= 2 and parts[1].isdigit():
            try:
                num = int(parts[1])
            except ValueError:
                continue
            max_no = max(max_no, num)

    new_no = max_no + 1
    feat_slug = feat_name.strip().replace(" ", "_")
    task_dir_name = f"task_{new_no:02d}_{feat_slug}"
    task_dir = tasks_root / task_dir_name

    if task_dir.exists():
        raise typer.BadParameter(f"Task directory already exists: {task_dir}")

    _ensure_dir(task_dir)
    _ensure_dir(task_dir / "task_records" / "log")

    # Always use task_{no}_{feat}.md (same as directory name) for unique @ reference in AI tools
    task_md = task_dir / f"{task_dir_name}.md"
    task_md.write_text(
        f"# Task {new_no:02d}: {feat_name}\n\n"
        "## 闭环描述\n\n"
        "[在此填写该任务管理的目标资源及其完整生命周期（Create/Read/Update/Delete）的描述。]\n\n"
        "## TODO_LIST\n\n"
        "> 只维护最新版本；完成后清空 TODO，仅保留\"完成记录 + 日期\"。\n"
        "- （本轮已完成，TODO 清空）\n\n"
        "- [ ] 根据当前状态，完善上方「闭环描述」中 Create/Read/Update/Delete 各小节的具体落点。\n"
        "- [ ] 将本任务拆解为 3–10 个具体的工程/模块/代码的具体修改 TODO，每个 TODO 具体可以实施，并用这些条目替换本示例 TODO。\n",
        encoding="utf-8",
    )

    typer.echo(f"[zsc] Created new task: {task_dir}")
    typer.echo(
        "[zsc] 下一步建议：\n"
        f"  1. 在你使用的 AI Coding 工具中打开 {task_md}。\n"
        "  2. 触发 zsc-create-task 技能（例如在 Cursor 中执行 /zsc-create-task）。\n"
        "  3. 将本次任务的需求意图作为输入，让 AI 帮你补全闭环描述与 TODO_LIST。\n\n"
        "当前版本的 zsc 仅负责创建目录与模板，不直接调用大模型；\n"
        "未来版本可能会内置 LLM 调用以自动完成这些步骤。"
    )


@task_app.command("status")
def task_status(
    path: str = typer.Argument(
        ".",
        help="Project root where .agents/tasks resides.",
    ),
) -> None:
    """
    汇总 .agents/tasks 中任务数量与状态。对应技能：zsc-task-status（由 zsc init 安装）。
    """
    base = Path(path).expanduser().resolve()
    tasks_root = _tasks_root(base)
    task_dirs = _iter_task_dirs(tasks_root)

    if not task_dirs:
        typer.echo(f"[zsc] No tasks found under {tasks_root}")
        return

    total = len(task_dirs)
    completed = 0
    open_tasks = 0
    unknown = 0

    for task_dir in task_dirs:
        _, status = _parse_task_md(task_dir)
        if status == "completed":
            completed += 1
        elif status == "open":
            open_tasks += 1
        else:
            unknown += 1

    typer.echo(f"[zsc] Task status summary for {tasks_root}:")
    typer.echo(f"  - total:     {total}")
    typer.echo(f"  - completed: {completed}")
    typer.echo(f"  - open:      {open_tasks}")
    typer.echo(f"  - unknown:   {unknown}")


@task_app.command("update")
def task_update(
    task: Optional[str] = typer.Argument(
        None,
        help="Task to update (e.g. task_02_zsc_task_cli, 02). If omitted, list tasks and suggest using zsc-update-task skill.",
    ),
    path: str = typer.Argument(
        ".",
        help="Project root where .agents/tasks resides.",
    ),
) -> None:
    """
    更新已有任务的内容（闭环描述、TODO_LIST 等）。仅编辑任务文件，不执行 TODO；对应技能：zsc-update-task（由 zsc init 安装）。执行任务请用 zsc-run-task。
    """
    base = Path(path).expanduser().resolve()
    tasks_root = _tasks_root(base)
    task_dirs = _iter_task_dirs(tasks_root)

    if not task_dirs:
        typer.echo(f"[zsc] No tasks found under {tasks_root}")
        typer.echo("[zsc] Use zsc-update-task skill in your AI Coding tool to update a task after creating one.")
        return

    if not task:
        typer.echo(f"[zsc] Tasks under {tasks_root} (use zsc task update TASK to open a task for update):")
        for task_dir in task_dirs:
            title, status = _parse_task_md(task_dir)
            status_display = status or "unknown"
            typer.echo(f"  - {task_dir.name:24} [{status_display}] {title}")
        typer.echo("\n[zsc] Or trigger zsc-update-task skill (e.g. /zsc-update-task in Cursor) to update a task.")
        return

    task_dir = _resolve_task_dir(tasks_root, task)
    if not task_dir:
        typer.echo(f"[zsc] No task matching '{task}' under {tasks_root}")
        typer.echo(f"[zsc] Available: {', '.join(d.name for d in task_dirs)}")
        raise typer.Exit(1)
    task_md = _task_md_path(task_dir)
    typer.echo(f"[zsc] Task to update: {task_dir.name}")
    typer.echo(f"[zsc] Task file: {task_md}")
    typer.echo("[zsc] Open this file and use zsc-update-task skill to revise 闭环描述, TODO_LIST, etc. Execution is via zsc-run-task.")


app.add_typer(task_app, name="task")


group_app = typer.Typer(
    help="管理 .agents/task-groups 下的任务组。各子命令对应技能：new → zsc-create-task-group，run → zsc-run-task-group-to-complete（由 zsc init 安装）。"
)


@group_app.command("new")
def group_new(
    group_name: str = typer.Argument(
        ...,
        help="Group name for the new task-group, used in directory name.",
    ),
    path: str = typer.Argument(
        ".",
        help="Project root where .agents/task-groups resides.",
    ),
) -> None:
    """
    创建新的 group_{no}_{group_name} 目录与同名的 group markdown 模板。对应技能：zsc-create-task-group（由 zsc init 安装）。
    """
    base = Path(path).expanduser().resolve()
    groups_root = _task_groups_root(base)

    existing = _iter_group_dirs(groups_root)
    max_no = 0
    for d in existing:
        parts = d.name.split("_", 2)
        if len(parts) >= 2 and parts[1].isdigit():
            try:
                num = int(parts[1])
            except ValueError:
                continue
            max_no = max(max_no, num)

    new_no = max_no + 1
    group_slug = group_name.strip().replace(" ", "_")
    group_dir_name = f"group_{new_no:02d}_{group_slug}"
    group_dir = groups_root / group_dir_name

    if group_dir.exists():
        raise typer.BadParameter(f"Task-group directory already exists: {group_dir}")

    _ensure_dir(group_dir)
    _ensure_dir(group_dir / "group_records" / "log")

    group_md = group_dir / f"{group_dir_name}.md"
    group_md.write_text(
        f"# Task Group {new_no:02d}: {group_name}\n\n"
        "## 来源\n\n"
        "- RFC: `[待补充]`\n"
        "- Prompt: `[待补充]`\n\n"
        "## 目标\n\n"
        "- [待补充]\n\n"
        "## 非目标\n\n"
        "- [待补充]\n\n"
        "## Workstreams\n\n"
        "- WS1: [待补充]\n\n"
        "## Tasks\n\n"
        "- [ ] `task_XX_example`\n"
        "  路径：`.agents/tasks/task_XX_example/task_XX_example.md`\n"
        "  归属：WS1\n"
        "  状态：todo\n\n"
        "## 依赖关系\n\n"
        "- [待补充]\n\n"
        "## 状态汇总\n\n"
        "- total: 0\n"
        "- todo: 0\n"
        "- doing: 0\n"
        "- done: 0\n"
        "- blocked: 0\n",
        encoding="utf-8",
    )

    typer.echo(f"[zsc] Created new task-group: {group_dir}")
    typer.echo(
        "[zsc] 下一步建议：\n"
        f"  1. 在你使用的 AI Coding 工具中打开 {group_md}。\n"
        "  2. 触发 zsc-create-task-group 技能。\n"
        "  3. 提供 RFC 或需求目标，让 AI 完善 group 设计并在 .agents/tasks 下真实拆出子任务。\n\n"
        "当前版本的 zsc 仅负责创建目录与模板，不直接调用大模型。"
    )


@group_app.command("run")
def group_run(
    group: Optional[str] = typer.Argument(
        None,
        help="Task-group to run (e.g. group_02_bootstrap, 02). If omitted, list groups and suggest using zsc-run-task-group-to-complete skill.",
    ),
    path: str = typer.Argument(
        ".",
        help="Project root where .agents/task-groups resides.",
    ),
) -> None:
    """
    定位一个已有任务组并提示使用 zsc-run-task-group-to-complete 执行。对应技能：zsc-run-task-group-to-complete（由 zsc init 安装）。
    """
    base = Path(path).expanduser().resolve()
    groups_root = _task_groups_root(base)
    group_dirs = _iter_group_dirs(groups_root)

    if not group_dirs:
        typer.echo(f"[zsc] No task-groups found under {groups_root}")
        typer.echo("[zsc] Use zsc-create-task-group skill in your AI Coding tool to create a task-group first.")
        return

    if not group:
        typer.echo(f"[zsc] Task-groups under {groups_root} (use zsc group run GROUP to select one):")
        for group_dir in group_dirs:
            typer.echo(f"  - {group_dir.name}")
        typer.echo(
            "\n[zsc] Or trigger zsc-run-task-group-to-complete skill "
            "(e.g. /zsc-run-task-group-to-complete in Cursor) to execute a group."
        )
        return

    group_dir = _resolve_group_dir(groups_root, group)
    if not group_dir:
        typer.echo(f"[zsc] No task-group matching '{group}' under {groups_root}")
        typer.echo(f"[zsc] Available: {', '.join(d.name for d in group_dirs)}")
        raise typer.Exit(1)

    group_md = _group_md_path(group_dir)
    typer.echo(f"[zsc] Task-group to run: {group_dir.name}")
    typer.echo(f"[zsc] Group file: {group_md}")
    typer.echo(
        "[zsc] Open this file and use zsc-run-task-group-to-complete skill to execute the group continuously "
        "and sync group status."
    )


app.add_typer(group_app, name="group")


rfc_app = typer.Typer(
    help="管理仓库内 docs/rfcs 下的 RFC。子命令对应技能：new → zsc-create-rfc（由 zsc init 安装）。"
)


@rfc_app.command("new")
def rfc_new(
    title: str = typer.Argument(
        ...,
        help="RFC title used for numbering and file naming.",
    ),
    path: str = typer.Argument(
        ".",
        help="Project root where docs/rfcs resides.",
    ),
) -> None:
    """
    在 docs/rfcs 下创建新的带编号 RFC 模板。对应技能：zsc-create-rfc（由 zsc init 安装）。
    """
    base = Path(path).expanduser().resolve()
    rfcs_root = _rfcs_root(base)

    rfc_no = _next_rfc_no(rfcs_root)
    title_slug = _slugify_name(title)
    file_name = f"rfc_{rfc_no:04d}_{title_slug}.md"
    rfc_path = rfcs_root / file_name

    if rfc_path.exists():
        raise typer.BadParameter(f"RFC file already exists: {rfc_path}")

    today = date.today().isoformat()
    rfc_path.write_text(
        f"# RFC {rfc_no:04d}: {title}\n\n"
        "## Metadata\n\n"
        f"- ID: `RFC-{rfc_no:04d}`\n"
        f"- Slug: `{title_slug}`\n"
        "- Status: `Draft`\n"
        "- Type: `Architecture / Product / Protocol / Process` (choose one or narrow later)\n"
        "- Authors: `[name]`\n"
        "- Reviewers: `[name, name]`\n"
        "- Approver: `[name]`\n"
        f"- Created: `{today}`\n"
        f"- Updated: `{today}`\n"
        "- Tags: `[area, domain, component]`\n"
        "- Related RFCs: `[]`\n"
        "- Related Task Group: `[optional: .agents/task-groups/group_xx_xxx/group_xx_xxx.md]`\n\n"
        "## Summary\n\n"
        "- Problem in one sentence: [required]\n"
        "- Proposed change in one sentence: [required]\n"
        "- Expected impact in one sentence: [required]\n\n"
        "## Motivation\n\n"
        "Describe why this RFC exists now, what concrete engineering or product pressure it addresses, "
        "and why the current state is insufficient.\n\n"
        "## Goals\n\n"
        "- [required]\n\n"
        "## Non-Goals\n\n"
        "- [required]\n\n"
        "## Terminology\n\n"
        "- `Term`: definition\n"
        "- Use normative wording where appropriate: `MUST`, `SHOULD`, `MAY`.\n\n"
        "## Current State\n\n"
        "Document the current architecture, code paths, interfaces, constraints, and known failure modes.\n"
        "Reference concrete modules, APIs, schemas, or operational boundaries when known.\n\n"
        "## Detailed Proposal\n\n"
        "Provide the proposed architecture or specification in enough detail that implementation can be split into tasks.\n\n"
        "### Design Overview\n\n"
        "- Components:\n"
        "- Control flow:\n"
        "- Data flow:\n"
        "- State transitions:\n\n"
        "### Technical Specification\n\n"
        "- Invariants:\n"
        "- Required behaviors (`MUST`):\n"
        "- Recommended behaviors (`SHOULD`):\n"
        "- Optional behaviors (`MAY`):\n"
        "- Error handling:\n"
        "- Failure modes:\n"
        "- Edge cases:\n\n"
        "### Interfaces and Contracts\n\n"
        "- CLI/API changes:\n"
        "- Config changes:\n"
        "- Data model or schema changes:\n"
        "- External protocol or integration changes:\n\n"
        "## Compatibility and Migration\n\n"
        "- Backward compatibility impact:\n"
        "- Migration steps:\n"
        "- Deprecation plan:\n\n"
        "## Security Considerations\n\n"
        "- Trust boundaries:\n"
        "- Abuse or misuse cases:\n"
        "- Data sensitivity:\n"
        "- Authentication / authorization impact:\n\n"
        "## Observability and Operations\n\n"
        "- Logs / metrics / traces:\n"
        "- Alerting or SLO impact:\n"
        "- Operational runbook impact:\n"
        "- Capacity / performance considerations:\n\n"
        "## Testing and Acceptance\n\n"
        "- Test strategy:\n"
        "- Acceptance criteria:\n"
        "- How non-goals will be kept out of scope:\n\n"
        "## Rollout and Rollback\n\n"
        "- Rollout phases:\n"
        "- Release gating:\n"
        "- Rollback conditions:\n"
        "- Rollback procedure:\n\n"
        "## Alternatives Considered\n\n"
        "- Alternative A:\n"
        "- Alternative B:\n"
        "- Why they were not chosen:\n\n"
        "## Risks and Open Questions\n\n"
        "- Risk:\n"
        "- Open question:\n"
        "- Follow-up RFC or task needed:\n\n"
        "## Prior Art and References\n\n"
        "- Internal references:\n"
        "- External references:\n\n"
        "## Implementation Notes\n\n"
        "- Expected task-group decomposition:\n"
        "- Suggested sequencing:\n"
        "- Areas likely to need dedicated tasks:\n",
        encoding="utf-8",
    )

    typer.echo(f"[zsc] Created new RFC: {rfc_path}")
    typer.echo(
        "[zsc] 下一步建议：\n"
        f"  1. 在 AI Coding 工具中打开 {rfc_path}。\n"
        "  2. 触发 zsc-create-rfc 技能，补全背景、技术规格、兼容性、安全、测试与实施计划。\n"
        "  3. 若该 RFC 后续需要拆解实施，可再使用 zsc-create-task-group 从 RFC 产出任务组。"
    )


app.add_typer(rfc_app, name="rfc")


if __name__ == "__main__":
    app()
