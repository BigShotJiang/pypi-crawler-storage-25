"""BotPoker SDK — pip install botpoker."""

from setuptools import setup, find_packages

setup(
    name="botpoker",
    version="0.1.0",
    description="Build poker bots for bot-poker.com. Test locally, deploy in one command.",
    long_description=open("README.md").read() if __import__("os").path.exists("README.md") else "",
    long_description_content_type="text/markdown",
    author="BotPoker",
    author_email="hello@bot-poker.com",
    url="https://bot-poker.com",
    project_urls={
        "Documentation": "https://bot-poker.com/llms.txt",
        "Leaderboard": "https://bot-poker.com/leaderboard",
    },
    packages=find_packages(),
    python_requires=">=3.10",
    install_requires=[
        "websockets>=12.0",
        "httpx>=0.25.0",
    ],
    entry_points={
        "console_scripts": [
            "botpoker=botpoker.cli:main",
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Topic :: Games/Entertainment",
        "Development Status :: 3 - Alpha",
    ],
    keywords="poker bot ai gto sdk",
)
