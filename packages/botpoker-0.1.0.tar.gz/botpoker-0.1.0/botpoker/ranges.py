"""BotPoker SDK — Precomputed GTO opening ranges."""

from __future__ import annotations

from .types import Card


def _hand_key(c1: Card, c2: Card) -> str:
    """Canonical hand key like 'AKs', 'QTo', '77'."""
    r1, r2 = c1.rank_value, c2.rank_value
    if r1 < r2:
        r1, r2 = r2, r1
        c1, c2 = c2, c1

    high = c1.rank
    low = c2.rank

    if r1 == r2:
        return f"{high}{low}"
    elif c1.suit == c2.suit:
        return f"{high}{low}s"
    else:
        return f"{high}{low}o"


# GTO-approximate opening ranges by position (6-max).
# Values are open-raise frequencies (0.0-1.0).
# Simplified from solver outputs.

_UTG_RANGE = {
    "AA": 1.0, "KK": 1.0, "QQ": 1.0, "JJ": 1.0, "TT": 1.0,
    "99": 0.9, "88": 0.7, "77": 0.5,
    "AKs": 1.0, "AQs": 1.0, "AJs": 1.0, "ATs": 0.8,
    "AKo": 1.0, "AQo": 0.9, "AJo": 0.5,
    "KQs": 1.0, "KJs": 0.8, "KTs": 0.5,
    "KQo": 0.5,
    "QJs": 0.8, "QTs": 0.5,
    "JTs": 0.7, "T9s": 0.4, "98s": 0.3, "87s": 0.2, "76s": 0.1,
}

_MP_RANGE = {
    **_UTG_RANGE,
    "66": 0.8, "55": 0.6,
    "A9s": 0.6, "A8s": 0.4, "A5s": 0.5, "A4s": 0.4,
    "ATo": 0.7, "AJo": 0.8,
    "KQo": 0.8, "KJo": 0.4,
    "KTs": 0.8, "K9s": 0.4,
    "QTs": 0.8, "Q9s": 0.3,
    "JTs": 0.9, "J9s": 0.4,
    "T9s": 0.7, "98s": 0.6, "87s": 0.5, "76s": 0.4,
}

_CO_RANGE = {
    **_MP_RANGE,
    "44": 0.9, "33": 0.7, "22": 0.5,
    "A9s": 1.0, "A8s": 0.9, "A7s": 0.7, "A6s": 0.6, "A5s": 0.9, "A4s": 0.8, "A3s": 0.6, "A2s": 0.5,
    "ATo": 1.0, "A9o": 0.5,
    "KJo": 0.8, "KTo": 0.5,
    "K9s": 0.8, "K8s": 0.4,
    "Q9s": 0.7, "Q8s": 0.3,
    "J9s": 0.8, "J8s": 0.3,
    "T8s": 0.5, "97s": 0.4, "86s": 0.3, "75s": 0.3, "65s": 0.4, "54s": 0.3,
}

_BTN_RANGE = {
    **_CO_RANGE,
    "22": 0.9,
    "A7s": 1.0, "A6s": 1.0, "A5s": 1.0, "A4s": 1.0, "A3s": 1.0, "A2s": 0.9,
    "A9o": 0.9, "A8o": 0.7, "A7o": 0.5, "A5o": 0.4,
    "KTo": 0.8, "K9o": 0.4,
    "K8s": 0.8, "K7s": 0.6, "K6s": 0.5, "K5s": 0.4,
    "QJo": 0.8, "QTo": 0.6,
    "Q8s": 0.7, "Q7s": 0.3,
    "J8s": 0.7, "J7s": 0.3,
    "T8s": 0.8, "T7s": 0.3,
    "97s": 0.7, "96s": 0.3,
    "86s": 0.6, "85s": 0.3,
    "75s": 0.6, "74s": 0.2,
    "65s": 0.8, "64s": 0.3,
    "54s": 0.7, "53s": 0.2,
    "43s": 0.3,
}

_SB_RANGE = {
    **_CO_RANGE,  # SB is roughly CO-width with more 3-bet and limp
    "A2s": 0.8, "A3s": 0.8,
    "K5s": 0.5, "K4s": 0.3,
    "64s": 0.3, "53s": 0.3, "43s": 0.3,
}

_RANGES_BY_POSITION = {
    "UTG": _UTG_RANGE,
    "UTG+1": _UTG_RANGE,
    "MP": _MP_RANGE,
    "CO": _CO_RANGE,
    "BTN": _BTN_RANGE,
    "SB": _SB_RANGE,
    "BB": {},  # BB defends wide — not an opening range
}


class GtoRanges:
    """Precomputed GTO opening ranges for 6-max.

    Usage::

        ranges = GtoRanges()
        freq = ranges.open_frequency(
            Card("A", "s"), Card("K", "s"),
            position="BTN",
        )
        # freq = 1.0 (always open AKs on BTN)
    """

    def open_frequency(self, c1: Card, c2: Card, position: str) -> float:
        """Return the GTO open-raise frequency (0.0-1.0) for a hand at a position."""
        key = _hand_key(c1, c2)
        range_map = _RANGES_BY_POSITION.get(position, {})
        return range_map.get(key, 0.0)

    def should_open(self, c1: Card, c2: Card, position: str, threshold: float = 0.5) -> bool:
        """Return True if the hand should be opened at the given threshold."""
        return self.open_frequency(c1, c2, position) >= threshold

    def range_hands(self, position: str) -> dict[str, float]:
        """Return all hands in the opening range for a position."""
        return dict(_RANGES_BY_POSITION.get(position, {}))
