"""BotPoker SDK — Connection layer (WebSocket + REST)."""

from __future__ import annotations

import asyncio
import hashlib
import hmac
import json
import logging
import time
from typing import TYPE_CHECKING

import websockets
import httpx

if TYPE_CHECKING:
    from .base import BotBase

from .types import Action, ChatMessage, GameState, HandResult, Phase

logger = logging.getLogger("botpoker")


class BotRunner:
    """Manages the WebSocket connection and action submission loop."""

    def __init__(
        self,
        bot: BotBase,
        api_key: str,
        table_id: str,
        server_url: str,
        reconnect: bool = True,
    ) -> None:
        self.bot = bot
        self.api_key = api_key
        self.api_secret = ""  # populated from server or config
        self.table_id = table_id
        self.server_url = server_url.rstrip("/")
        self.reconnect = reconnect
        self.player_id = ""
        self._running = False
        self._current_state: GameState | None = None

    @property
    def ws_url(self) -> str:
        base = self.server_url.replace("http://", "ws://").replace("https://", "wss://")
        return f"{base}/v1/games/{self.table_id}?api_key={self.api_key}"

    @property
    def action_url(self) -> str:
        return f"{self.server_url}/v1/games/{self.table_id}/action"

    def run(self) -> None:
        """Start the bot (blocking). Uses asyncio internally."""
        self._running = True
        asyncio.run(self._main_loop())

    async def _main_loop(self) -> None:
        backoff = 1
        while self._running:
            try:
                await self._connect_and_listen()
                backoff = 1  # reset on clean disconnect
            except (
                websockets.ConnectionClosed,
                ConnectionRefusedError,
                OSError,
            ) as e:
                logger.warning("Connection lost: %s", e)
                self.bot.on_disconnect()
                if not self.reconnect:
                    break
                logger.info("Reconnecting in %ds...", backoff)
                await asyncio.sleep(backoff)
                backoff = min(backoff * 2, 30)
            except Exception as e:
                logger.exception("Unexpected error: %s", e)
                self.bot.on_error(e)
                if not self.reconnect:
                    break
                await asyncio.sleep(backoff)
                backoff = min(backoff * 2, 30)

    async def _connect_and_listen(self) -> None:
        async with websockets.connect(self.ws_url) as ws:
            logger.info("Connected to %s", self.table_id)
            self.bot.on_connect()

            async for raw in ws:
                try:
                    msg = json.loads(raw)
                    await self._handle_message(msg)
                except Exception as e:
                    logger.error("Error handling message: %s", e)
                    self.bot.on_error(e)

    async def _handle_message(self, msg: dict) -> None:
        event_type = msg.get("event", "")

        if event_type == "STATE_UPDATE":
            data = msg.get("data", {})
            state = GameState.from_dict(data)
            self._current_state = state
            self.player_id = state.your_id

            if state.is_my_turn and state.valid_actions:
                await self._act(state)

        elif event_type == "HAND_COMPLETE":
            data = msg.get("data", {})
            result = HandResult.from_dict(data)
            self.bot.on_hand_complete(result)

            # Post-hand actions.
            if self._current_state:
                try:
                    post = self.bot.post_hand(result, self._current_state)
                    # TODO: submit post-hand actions to server
                    _ = post
                except Exception as e:
                    logger.error("post_hand error: %s", e)

        elif event_type == "ERROR":
            data = msg.get("data", {})
            logger.error("Server error: [%s] %s", data.get("code"), data.get("message"))

    async def _act(self, state: GameState) -> None:
        """Get the bot's decision and submit it."""
        try:
            # Optional chat before acting.
            chat = self.bot.generate_chat(state)
            if chat:
                # TODO: submit chat to server
                pass

            action = self.bot.decide(state)
            await self._submit_action(action, state)

        except Exception as e:
            logger.error("decide() error: %s — auto-folding", e)
            self.bot.on_error(e)
            await self._submit_action(Action.fold(), state)

    async def _submit_action(self, action: Action, state: GameState) -> None:
        """Submit an action via REST POST."""
        hand_id = str(state.hand_number)
        signature = self._sign(
            self.table_id, hand_id, self.player_id,
            action.type.value, action.amount,
        )

        payload = {
            "player_id": self.player_id,
            "hand_id": hand_id,
            "action_type": action.type.value,
            "amount": action.amount,
            "signature": signature,
        }

        try:
            async with httpx.AsyncClient() as client:
                resp = await client.post(
                    self.action_url,
                    json=payload,
                    headers={"Authorization": f"Bearer {self.api_key}"},
                    timeout=5.0,
                )
                if resp.status_code != 200:
                    body = resp.json()
                    logger.error(
                        "Action rejected [%d]: %s",
                        resp.status_code,
                        body.get("error", resp.text),
                    )
        except Exception as e:
            logger.error("Failed to submit action: %s", e)

    def _sign(self, game_id: str, hand_id: str, player_id: str, action_type: str, amount: int) -> str:
        """HMAC-SHA256 signature for action authentication."""
        payload = f"{game_id}{hand_id}{player_id}{action_type}{amount}"
        return hmac.new(
            self.api_secret.encode(),
            payload.encode(),
            hashlib.sha256,
        ).hexdigest()

    def stop(self) -> None:
        """Signal the bot to stop."""
        self._running = False
