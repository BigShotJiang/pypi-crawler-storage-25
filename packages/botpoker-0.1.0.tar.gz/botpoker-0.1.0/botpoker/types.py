"""BotPoker SDK — Core types."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Optional


class Phase(str, Enum):
    PREFLOP = "preflop"
    FLOP = "flop"
    TURN = "turn"
    RIVER = "river"
    SHOWDOWN = "showdown"
    COMPLETE = "complete"


class ActionType(str, Enum):
    FOLD = "FOLD"
    CHECK = "CHECK"
    CALL = "CALL"
    RAISE = "RAISE"
    ALLIN = "ALLIN"


class PlayerStatus(str, Enum):
    ACTIVE = "active"
    FOLDED = "folded"
    ALL_IN = "all-in"
    SITTING = "sitting"


@dataclass(frozen=True)
class Card:
    """A single playing card."""

    rank: str  # "2"-"9", "T", "J", "Q", "K", "A"
    suit: str  # "c", "d", "h", "s"

    def __str__(self) -> str:
        return f"{self.rank}{self.suit}"

    @classmethod
    def from_dict(cls, d: dict) -> Card:
        return cls(rank=d["rank"], suit=d["suit"])

    @property
    def rank_value(self) -> int:
        """Numeric rank value (2-14)."""
        return _RANK_VALUES.get(self.rank, 0)


_RANK_VALUES = {
    "2": 2, "3": 3, "4": 4, "5": 5, "6": 6, "7": 7, "8": 8,
    "9": 9, "T": 10, "J": 11, "Q": 12, "K": 13, "A": 14,
}


@dataclass
class PlayerInfo:
    """Public information about a player at the table."""

    id: str
    name: str
    chips: int
    bet: int
    status: PlayerStatus
    position: int
    cards: Optional[tuple[Card, Card]] = None  # only at showdown

    @classmethod
    def from_dict(cls, d: dict) -> PlayerInfo:
        cards = None
        if d.get("cards"):
            cards = (Card.from_dict(d["cards"][0]), Card.from_dict(d["cards"][1]))
        return cls(
            id=d["id"],
            name=d["name"],
            chips=d["chips"],
            bet=d["bet"],
            status=PlayerStatus(d["status"]),
            position=d["position"],
            cards=cards,
        )


@dataclass
class ValidAction:
    """An action the bot may legally take."""

    type: ActionType
    min_amount: int = 0
    max_amount: int = 0

    @classmethod
    def from_dict(cls, d: dict) -> ValidAction:
        return cls(
            type=ActionType(d["type"]),
            min_amount=d.get("min_amount", 0),
            max_amount=d.get("max_amount", 0),
        )


@dataclass
class SidePot:
    """A side pot."""

    amount: int
    eligible_ids: list[str]

    @classmethod
    def from_dict(cls, d: dict) -> SidePot:
        return cls(amount=d["amount"], eligible_ids=d["eligible_ids"])


@dataclass
class GameState:
    """The masked game state as seen by a specific player."""

    phase: Phase
    pot: int
    community_cards: list[Card]
    current_bet: int
    players: list[PlayerInfo]
    your_cards: tuple[Card, Card]
    your_id: str
    to_act_id: str
    valid_actions: list[ValidAction]
    hand_number: int
    dealer_index: int
    side_pots: list[SidePot] = field(default_factory=list)

    @classmethod
    def from_dict(cls, d: dict) -> GameState:
        your_cards = (
            Card.from_dict(d["your_cards"][0]),
            Card.from_dict(d["your_cards"][1]),
        )
        return cls(
            phase=Phase(d["phase"]),
            pot=d["pot"],
            community_cards=[Card.from_dict(c) for c in d.get("community_cards") or []],
            current_bet=d["current_bet"],
            players=[PlayerInfo.from_dict(p) for p in d["players"]],
            your_cards=your_cards,
            your_id=d["your_id"],
            to_act_id=d["to_act_id"],
            valid_actions=[ValidAction.from_dict(a) for a in d.get("valid_actions") or []],
            hand_number=d["hand_number"],
            dealer_index=d["dealer_index"],
            side_pots=[SidePot.from_dict(s) for s in d.get("side_pots") or []],
        )

    @property
    def is_my_turn(self) -> bool:
        return self.to_act_id == self.your_id

    @property
    def my_player(self) -> PlayerInfo:
        for p in self.players:
            if p.id == self.your_id:
                return p
        raise ValueError("own player not found in state")

    @property
    def opponents(self) -> list[PlayerInfo]:
        return [p for p in self.players if p.id != self.your_id]

    @property
    def active_opponents(self) -> list[PlayerInfo]:
        return [
            p for p in self.players
            if p.id != self.your_id and p.status in (PlayerStatus.ACTIVE, PlayerStatus.ALL_IN)
        ]

    @property
    def position_name(self) -> str:
        """Return position label based on seat count and dealer index."""
        n = len(self.players)
        my_offset = (self.my_player.position - self.dealer_index) % n
        if n == 2:
            return "BTN" if my_offset == 0 else "BB"
        labels = {0: "BTN", 1: "SB", 2: "BB"}
        return labels.get(my_offset, f"UTG+{my_offset - 3}" if my_offset > 3 else "UTG")


@dataclass(frozen=True)
class Action:
    """An action to submit to the server."""

    type: ActionType
    amount: int = 0

    @staticmethod
    def fold() -> Action:
        return Action(type=ActionType.FOLD)

    @staticmethod
    def check() -> Action:
        return Action(type=ActionType.CHECK)

    @staticmethod
    def call() -> Action:
        return Action(type=ActionType.CALL)

    @staticmethod
    def raise_to(amount: int) -> Action:
        return Action(type=ActionType.RAISE, amount=amount)

    @staticmethod
    def raise_by(amount: int, current_bet: int = 0) -> Action:
        return Action(type=ActionType.RAISE, amount=current_bet + amount)

    @staticmethod
    def raise_pot(state: GameState, fraction: float = 1.0) -> Action:
        pot_total = state.pot + state.current_bet * len(state.active_opponents)
        raise_amount = int(pot_total * fraction) + state.current_bet
        return Action(type=ActionType.RAISE, amount=raise_amount)

    @staticmethod
    def all_in() -> Action:
        return Action(type=ActionType.ALLIN)

    def to_dict(self) -> dict:
        return {"action_type": self.type.value, "amount": self.amount}


@dataclass
class ChatMessage:
    """A chat message from a player."""

    player_id: str
    content: str
    phase: Phase


class ShowDecision(str, Enum):
    MUCK = "muck"
    SHOW_ALL = "show_all"
    SHOW_ONE = "show_one"


@dataclass
class Emote:
    """An emote reaction."""

    name: str
    target_id: Optional[str] = None


@dataclass
class PostHandAction:
    """Actions to take after a hand completes."""

    show_cards: ShowDecision = ShowDecision.MUCK
    card_to_show: Optional[int] = None  # 0 or 1, only for SHOW_ONE
    chat: Optional[str] = None
    emote: Optional[Emote] = None
    delay_ms: int = 0


@dataclass
class HandResult:
    """Result of a completed hand."""

    winners: list[dict]
    showdown: list[dict]
    your_net: int = 0

    @classmethod
    def from_dict(cls, d: dict) -> HandResult:
        return cls(
            winners=d.get("winners", []),
            showdown=d.get("showdown", []),
        )
