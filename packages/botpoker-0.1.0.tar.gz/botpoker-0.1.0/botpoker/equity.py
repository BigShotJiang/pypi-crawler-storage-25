"""BotPoker SDK — Monte Carlo equity calculator."""

from __future__ import annotations

import random
from typing import Sequence

from .eval import HandEvaluator
from .types import Card

_ALL_RANKS = ["2", "3", "4", "5", "6", "7", "8", "9", "T", "J", "Q", "K", "A"]
_ALL_SUITS = ["c", "d", "h", "s"]


def _full_deck() -> list[Card]:
    return [Card(rank=r, suit=s) for r in _ALL_RANKS for s in _ALL_SUITS]


class MonteCarloCalculator:
    """Calculate hand equity via Monte Carlo simulation.

    Usage::

        calc = MonteCarloCalculator()
        equity = calc.equity(
            hole_cards=(Card("A", "s"), Card("K", "s")),
            community=[Card("Q", "s"), Card("J", "s"), Card("2", "h")],
            num_opponents=2,
            iterations=5000,
        )
        print(f"Win: {equity.win:.1%}, Tie: {equity.tie:.1%}")
    """

    def __init__(self, seed: int | None = None) -> None:
        self._rng = random.Random(seed)
        self._evaluator = HandEvaluator()

    def equity(
        self,
        hole_cards: tuple[Card, Card],
        community: Sequence[Card] = (),
        num_opponents: int = 1,
        iterations: int = 1000,
    ) -> EquityResult:
        """Run Monte Carlo simulation to estimate hand equity.

        Args:
            hole_cards: Your two hole cards.
            community: Known community cards (0-5).
            num_opponents: Number of opponents (random hands).
            iterations: Number of simulations to run.

        Returns:
            EquityResult with win/tie/lose fractions.
        """
        community = list(community)
        dead = set(str(c) for c in hole_cards) | set(str(c) for c in community)
        remaining = [c for c in _full_deck() if str(c) not in dead]

        cards_needed = (5 - len(community)) + (2 * num_opponents)
        if cards_needed > len(remaining):
            raise ValueError("Not enough cards remaining for simulation")

        wins = 0
        ties = 0
        losses = 0

        for _ in range(iterations):
            drawn = self._rng.sample(remaining, cards_needed)
            idx = 0

            # Complete the board.
            board = community + drawn[idx : idx + (5 - len(community))]
            idx += 5 - len(community)

            # My hand.
            _, my_score, _ = self._evaluator.evaluate(hole_cards, board)

            # Opponent hands.
            best_opp = 0
            for _ in range(num_opponents):
                opp_hole = (drawn[idx], drawn[idx + 1])
                idx += 2
                _, opp_score, _ = self._evaluator.evaluate(opp_hole, board)
                best_opp = max(best_opp, opp_score)

            if my_score > best_opp:
                wins += 1
            elif my_score == best_opp:
                ties += 1
            else:
                losses += 1

        return EquityResult(
            win=wins / iterations,
            tie=ties / iterations,
            lose=losses / iterations,
            iterations=iterations,
        )


class EquityResult:
    """Result of a Monte Carlo equity calculation."""

    __slots__ = ("win", "tie", "lose", "iterations")

    def __init__(self, win: float, tie: float, lose: float, iterations: int) -> None:
        self.win = win
        self.tie = tie
        self.lose = lose
        self.iterations = iterations

    @property
    def total_equity(self) -> float:
        """Win equity + half of tie equity."""
        return self.win + self.tie / 2

    def __repr__(self) -> str:
        return (
            f"EquityResult(win={self.win:.3f}, tie={self.tie:.3f}, "
            f"lose={self.lose:.3f}, n={self.iterations})"
        )
