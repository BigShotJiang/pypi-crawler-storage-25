"""BotPoker SDK — BotBase class."""

from __future__ import annotations

import logging
from typing import Optional

from .types import Action, ChatMessage, GameState, HandResult, PostHandAction, ShowDecision

logger = logging.getLogger("botpoker")


class BotBase:
    """Base class for all BotPoker bots.

    Subclass this and implement at minimum the ``decide`` method.

    Usage::

        class MyBot(BotBase):
            def decide(self, state: GameState) -> Action:
                return Action.call()

        MyBot().run(api_key="key", table_id="bronze_6max_001")
    """

    name: str = "UnnamedBot"

    # ------------------------------------------------------------------
    # Required
    # ------------------------------------------------------------------

    def decide(self, state: GameState) -> Action:
        """REQUIRED — Called every time the bot must act.

        Must return an ``Action`` (fold, check, call, raise_to, all_in).
        """
        raise NotImplementedError("You must implement decide()")

    # ------------------------------------------------------------------
    # Optional — Channel 2: Chat
    # ------------------------------------------------------------------

    def generate_chat(self, state: GameState) -> Optional[str]:
        """CHANNEL 2 — Return a chat message string, or None to stay silent."""
        return None

    def on_chat(self, message: ChatMessage, state: GameState) -> None:
        """CHANNEL 2 — Called when an opponent sends a chat message."""
        pass

    # ------------------------------------------------------------------
    # Optional — Channel 3: Post-hand
    # ------------------------------------------------------------------

    def post_hand(self, result: HandResult, state: GameState) -> PostHandAction:
        """CHANNEL 3 — Called after every hand for show/emote decisions."""
        return PostHandAction(show_cards=ShowDecision.MUCK)

    def on_hand_complete(self, result: HandResult) -> None:
        """Called after a hand completes with full results (revealed cards etc.)."""
        pass

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def setup(self) -> None:
        """Called once on init. Load models, precompute tables, etc."""
        pass

    def on_connect(self) -> None:
        """Called when the WebSocket connection is established."""
        pass

    def on_disconnect(self) -> None:
        """Called when the WebSocket connection is lost."""
        pass

    def on_error(self, error: Exception) -> None:
        """Called when an error occurs."""
        logger.error("Bot error: %s", error)

    # ------------------------------------------------------------------
    # Runner
    # ------------------------------------------------------------------

    def run(
        self,
        api_key: str,
        table_id: str,
        server_url: str = "http://localhost:1339",
        *,
        reconnect: bool = True,
    ) -> None:
        """Connect to a table and start playing.

        This is the main entry point. It blocks until the bot is stopped.
        """
        from .connection import BotRunner

        runner = BotRunner(
            bot=self,
            api_key=api_key,
            table_id=table_id,
            server_url=server_url,
            reconnect=reconnect,
        )
        self.setup()
        runner.run()

    def run_test(
        self,
        hands: int = 1000,
        opponents: list[str] | None = None,
        big_blind: int = 100,
        starting_chips: int = 10000,
        seed: int | None = None,
        verbose: bool = False,
    ) -> "SimulationResult":
        """Run a local simulation against built-in opponents.

        No server required. Everything runs in-process.

        Args:
            hands: Number of hands to play.
            opponents: List of opponent types. Options: "random", "call", "tight", "aggro".
            big_blind: Big blind size.
            starting_chips: Starting chips per player.
            seed: Random seed for reproducibility.
            verbose: Print each hand.

        Returns:
            SimulationResult with full stats.

        Example::

            result = MyBot().run_test(hands=5000, opponents=["tight", "aggro"])
            print(result.summary())
            print(f"BB/100: {result.bot_bb_per_100:+.1f}")
        """
        from .simulator import LocalSimulator

        self.setup()
        sim = LocalSimulator(
            bot=self,
            opponents=opponents or ["random"],
            hands=hands,
            starting_chips=starting_chips,
            big_blind=big_blind,
            seed=seed,
            verbose=verbose,
        )
        return sim.run()
