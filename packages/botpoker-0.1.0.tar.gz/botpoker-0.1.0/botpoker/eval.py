"""BotPoker SDK — Hand evaluation."""

from __future__ import annotations

from enum import IntEnum
from itertools import combinations
from typing import Sequence

from .types import Card


class HandRank(IntEnum):
    HIGH_CARD = 0
    ONE_PAIR = 1
    TWO_PAIR = 2
    THREE_OF_A_KIND = 3
    STRAIGHT = 4
    FLUSH = 5
    FULL_HOUSE = 6
    FOUR_OF_A_KIND = 7
    STRAIGHT_FLUSH = 8
    ROYAL_FLUSH = 9


# Suit to integer for comparison.
_SUIT_MAP = {"c": 0, "d": 1, "h": 2, "s": 3}


class HandEvaluator:
    """Evaluate poker hand strength.

    Usage::

        evaluator = HandEvaluator()
        rank, score, best5 = evaluator.evaluate(hole_cards, community_cards)
    """

    def evaluate(
        self,
        hole: Sequence[Card],
        community: Sequence[Card],
    ) -> tuple[HandRank, int, list[Card]]:
        """Find the best 5-card hand from hole + community cards.

        Returns (HandRank, comparable_score, best_5_cards).
        Higher score is better.
        """
        all_cards = list(hole) + list(community)
        if len(all_cards) < 5:
            return HandRank.HIGH_CARD, 0, list(all_cards)

        best_rank = HandRank.HIGH_CARD
        best_score = 0
        best_hand: list[Card] = []

        for combo in combinations(all_cards, 5):
            hand = list(combo)
            rank, score = self._evaluate5(hand)
            if score > best_score:
                best_rank = rank
                best_score = score
                best_hand = hand

        return best_rank, best_score, best_hand

    def _evaluate5(self, cards: list[Card]) -> tuple[HandRank, int]:
        """Score exactly 5 cards. Returns (rank, comparable_score)."""
        ranks = sorted([c.rank_value for c in cards], reverse=True)
        suits = [_SUIT_MAP[c.suit] for c in cards]

        is_flush = len(set(suits)) == 1
        is_straight, high = self._check_straight(ranks)

        if is_flush and is_straight:
            if high == 14:
                return HandRank.ROYAL_FLUSH, self._make_score(HandRank.ROYAL_FLUSH, [14])
            return HandRank.STRAIGHT_FLUSH, self._make_score(HandRank.STRAIGHT_FLUSH, [high])

        counts: dict[int, int] = {}
        for r in ranks:
            counts[r] = counts.get(r, 0) + 1

        groups = sorted(counts.items(), key=lambda x: (x[1], x[0]), reverse=True)

        if groups[0][1] == 4:
            kicker = [g[0] for g in groups if g[1] != 4][0]
            return HandRank.FOUR_OF_A_KIND, self._make_score(
                HandRank.FOUR_OF_A_KIND, [groups[0][0], kicker]
            )

        if groups[0][1] == 3 and groups[1][1] == 2:
            return HandRank.FULL_HOUSE, self._make_score(
                HandRank.FULL_HOUSE, [groups[0][0], groups[1][0]]
            )

        if is_flush:
            return HandRank.FLUSH, self._make_score(HandRank.FLUSH, ranks)

        if is_straight:
            return HandRank.STRAIGHT, self._make_score(HandRank.STRAIGHT, [high])

        if groups[0][1] == 3:
            kickers = sorted([g[0] for g in groups if g[1] == 1], reverse=True)
            return HandRank.THREE_OF_A_KIND, self._make_score(
                HandRank.THREE_OF_A_KIND, [groups[0][0]] + kickers
            )

        pairs = sorted([g[0] for g in groups if g[1] == 2], reverse=True)
        singles = sorted([g[0] for g in groups if g[1] == 1], reverse=True)

        if len(pairs) == 2:
            return HandRank.TWO_PAIR, self._make_score(
                HandRank.TWO_PAIR, pairs + singles
            )

        if len(pairs) == 1:
            return HandRank.ONE_PAIR, self._make_score(
                HandRank.ONE_PAIR, pairs + singles
            )

        return HandRank.HIGH_CARD, self._make_score(HandRank.HIGH_CARD, ranks)

    @staticmethod
    def _check_straight(ranks: list[int]) -> tuple[bool, int]:
        """Check if sorted-desc ranks form a straight."""
        if all(ranks[i] - ranks[i + 1] == 1 for i in range(4)):
            return True, ranks[0]
        # Wheel: A-5-4-3-2
        if ranks == [14, 5, 4, 3, 2]:
            return True, 5
        return False, 0

    @staticmethod
    def _make_score(rank: HandRank, kickers: list[int]) -> int:
        """Encode rank + kickers into a comparable integer."""
        score = int(rank) << 20
        for i, k in enumerate(kickers[:5]):
            score |= k << (16 - 4 * i)
        return score
