"""BotPoker SDK — Kelly Criterion for optimal bet sizing."""

from __future__ import annotations


class KellyCriterion:
    """Kelly Criterion calculator for poker bet sizing.

    Usage::

        kelly = KellyCriterion()
        fraction = kelly.bet_fraction(win_prob=0.65, pot_odds=2.0)
        # fraction ≈ 0.475 of bankroll
    """

    def bet_fraction(self, win_prob: float, pot_odds: float) -> float:
        """Calculate the optimal Kelly fraction.

        Args:
            win_prob: Probability of winning (0.0-1.0).
            pot_odds: Net odds received (e.g. 2.0 means win 2x your bet).

        Returns:
            Fraction of bankroll to wager (0.0-1.0). Negative means don't bet.
        """
        if pot_odds <= 0 or win_prob <= 0:
            return 0.0
        lose_prob = 1.0 - win_prob
        f = (win_prob * pot_odds - lose_prob) / pot_odds
        return max(0.0, f)

    def half_kelly(self, win_prob: float, pot_odds: float) -> float:
        """Half-Kelly — more conservative, reduces variance."""
        return self.bet_fraction(win_prob, pot_odds) / 2

    def optimal_bet_size(
        self,
        win_prob: float,
        pot: int,
        stack: int,
        *,
        kelly_fraction: float = 0.5,
    ) -> int:
        """Calculate optimal bet size in chips.

        Args:
            win_prob: Probability of winning the hand.
            pot: Current pot size.
            stack: Your remaining stack.
            kelly_fraction: Kelly multiplier (0.5 = half Kelly, 1.0 = full).

        Returns:
            Optimal bet size in chips (capped at stack).
        """
        if win_prob <= 0.5 or pot <= 0:
            return 0

        # Effective pot odds from the pot.
        pot_odds = pot / max(1, stack)
        f = self.bet_fraction(win_prob, pot_odds) * kelly_fraction

        bet = int(f * stack)
        return min(max(0, bet), stack)
