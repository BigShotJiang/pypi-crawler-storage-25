"""BotPoker SDK — Local simulation engine.

A pure-Python poker engine for offline testing. Mirrors the Go server's
game logic so developers can iterate without a running backend.

Usage::

    from botpoker.simulator import LocalSimulator
    from my_bot import MyBot

    sim = LocalSimulator(
        bot=MyBot(),
        opponents=["random", "call"],
        hands=1000,
        starting_chips=10000,
        big_blind=100,
    )
    result = sim.run()
    print(result.summary())
"""

from __future__ import annotations

import random
import sys
from dataclasses import dataclass, field
from typing import Optional, Sequence

from .base import BotBase
from .eval import HandEvaluator
from .types import (
    Action,
    ActionType,
    Card,
    GameState,
    HandResult,
    PlayerInfo,
    PlayerStatus,
    ValidAction,
    Phase,
    SidePot,
)


# ── Built-in opponents ──────────────────────────────────────

class _RandomOpponent(BotBase):
    name = "RandomBot"

    def decide(self, state: GameState) -> Action:
        va = random.choice(state.valid_actions)
        if va.type == ActionType.RAISE and va.max_amount > 0:
            return Action.raise_to(random.randint(va.min_amount, va.max_amount))
        elif va.type == ActionType.ALLIN:
            return Action.all_in()
        elif va.type == ActionType.CALL:
            return Action.call()
        elif va.type == ActionType.CHECK:
            return Action.check()
        return Action.fold()


class _CallOpponent(BotBase):
    name = "CallBot"

    def decide(self, state: GameState) -> Action:
        for va in state.valid_actions:
            if va.type == ActionType.CHECK:
                return Action.check()
        for va in state.valid_actions:
            if va.type == ActionType.CALL:
                return Action.call()
        return Action.all_in()


class _TightOpponent(BotBase):
    """Folds most hands, only plays premium."""
    name = "TightBot"

    def decide(self, state: GameState) -> Action:
        if state.phase == Phase.PREFLOP:
            c1, c2 = state.your_cards
            r1, r2 = c1.rank_value, c2.rank_value
            is_pair = r1 == r2
            is_high = min(r1, r2) >= 10
            if not (is_pair and r1 >= 9) and not is_high:
                if any(va.type == ActionType.CHECK for va in state.valid_actions):
                    return Action.check()
                return Action.fold()
        for va in state.valid_actions:
            if va.type == ActionType.CALL:
                return Action.call()
        for va in state.valid_actions:
            if va.type == ActionType.CHECK:
                return Action.check()
        return Action.fold()


class _AggroOpponent(BotBase):
    """Raises frequently, puts pressure on."""
    name = "AggroBot"

    def decide(self, state: GameState) -> Action:
        if random.random() < 0.6:
            for va in state.valid_actions:
                if va.type == ActionType.RAISE and va.max_amount > 0:
                    size = int(state.pot * (0.5 + random.random()))
                    size = max(va.min_amount, min(size + state.current_bet, va.max_amount))
                    return Action.raise_to(size)
        for va in state.valid_actions:
            if va.type == ActionType.CALL:
                return Action.call()
        for va in state.valid_actions:
            if va.type == ActionType.CHECK:
                return Action.check()
        return Action.fold()


def _resolve_opponent(name: str) -> BotBase:
    """Resolve an opponent name to a bot instance."""
    builtins = {
        "random": _RandomOpponent,
        "call": _CallOpponent,
        "tight": _TightOpponent,
        "aggro": _AggroOpponent,
    }
    # Try built-in first.
    cls = builtins.get(name.lower())
    if cls:
        return cls()

    # Try loading a template bot.
    try:
        import importlib
        mod = importlib.import_module(f"botpoker.templates.{name}")
        # Unused — templates are in sdk/templates/, not a package. Load by file instead.
    except ImportError:
        pass

    raise ValueError(
        f"Unknown opponent '{name}'. Available: {', '.join(sorted(builtins.keys()))}"
    )


# ── Simulation player state ─────────────────────────────────

@dataclass
class _SimPlayer:
    id: str
    name: str
    bot: BotBase
    chips: int
    bet: int = 0
    total_bet: int = 0  # total put in across all streets this hand
    status: PlayerStatus = PlayerStatus.ACTIVE
    cards: Optional[tuple[Card, Card]] = None
    position: int = 0


# ── Local game engine ────────────────────────────────────────

_ALL_RANKS = ["2", "3", "4", "5", "6", "7", "8", "9", "T", "J", "Q", "K", "A"]
_ALL_SUITS = ["c", "d", "h", "s"]


def _full_deck() -> list[Card]:
    return [Card(rank=r, suit=s) for r in _ALL_RANKS for s in _ALL_SUITS]


@dataclass
class HandStats:
    hand_number: int
    net: dict[str, int] = field(default_factory=dict)
    went_to_showdown: bool = False


@dataclass
class SimulationResult:
    """Result of a local simulation run."""
    hands_completed: int = 0
    errors: int = 0
    player_stats: dict[str, _PlayerStats] = field(default_factory=dict)

    def summary(self) -> str:
        lines = [
            f"\n{'='*60}",
            f"  Simulation Complete — {self.hands_completed} hands",
            f"{'='*60}",
            "",
            f"  {'Name':<16} {'Net (BB)':>10} {'BB/100':>10} {'VPIP':>8} {'Win%':>8}",
            f"  {'-'*54}",
        ]
        for pid, stats in sorted(
            self.player_stats.items(),
            key=lambda x: x[1].total_bb_won,
            reverse=True,
        ):
            vpip = (stats.vpip_hands / max(1, stats.hands)) * 100
            winrate = (stats.hands_won / max(1, stats.hands)) * 100
            lines.append(
                f"  {stats.name:<16} {stats.total_bb_won:>+10.1f} {stats.bb_per_100:>+10.1f} {vpip:>7.0f}% {winrate:>7.1f}%"
            )
        lines.append("")
        return "\n".join(lines)

    @property
    def bot_bb_per_100(self) -> float:
        """Return bb/100 for the user's bot."""
        for pid, stats in self.player_stats.items():
            if stats.is_hero:
                return stats.bb_per_100
        return 0.0


@dataclass
class _PlayerStats:
    name: str
    is_hero: bool = False
    hands: int = 0
    hands_won: int = 0
    total_bb_won: float = 0.0  # track in BB units to avoid rebuy distortion
    vpip_hands: int = 0  # hands where player voluntarily put money in
    big_blind: int = 100

    @property
    def net_chips(self) -> float:
        return self.total_bb_won * self.big_blind

    @property
    def bb_per_100(self) -> float:
        if self.hands == 0:
            return 0.0
        return (self.total_bb_won / self.hands) * 100


class LocalSimulator:
    """Run a poker simulation entirely in Python.

    Args:
        bot: The user's bot to test.
        opponents: List of opponent names or BotBase instances.
        hands: Number of hands to simulate.
        starting_chips: Starting chip stack per player.
        big_blind: Big blind amount.
        seed: Random seed for reproducibility.
        verbose: Print hand-by-hand output.
    """

    def __init__(
        self,
        bot: BotBase,
        opponents: list[str | BotBase] | None = None,
        hands: int = 1000,
        starting_chips: int = 10000,
        big_blind: int = 100,
        seed: int | None = None,
        verbose: bool = False,
    ) -> None:
        self.hero_bot = bot
        self.opponents = opponents or ["random"]
        self.num_hands = hands
        self.starting_chips = starting_chips
        self.big_blind = big_blind
        self.rng = random.Random(seed)
        self.verbose = verbose
        self._evaluator = HandEvaluator()

    def run(self) -> SimulationResult:
        """Run the simulation and return results."""
        # Resolve opponents.
        opp_bots: list[BotBase] = []
        for opp in self.opponents:
            if isinstance(opp, BotBase):
                opp_bots.append(opp)
            else:
                opp_bots.append(_resolve_opponent(opp))

        # Create players.
        players = [
            _SimPlayer(id="hero", name=self.hero_bot.name, bot=self.hero_bot,
                       chips=self.starting_chips, position=0),
        ]
        for i, opp in enumerate(opp_bots):
            players.append(
                _SimPlayer(id=f"opp_{i}", name=opp.name, bot=opp,
                           chips=self.starting_chips, position=i + 1),
            )

        # Set up bots.
        for p in players:
            p.bot.setup()

        result = SimulationResult()
        for p in players:
            result.player_stats[p.id] = _PlayerStats(
                name=p.name, is_hero=(p.id == "hero"), big_blind=self.big_blind,
            )

        dealer_idx = 0

        for hand_num in range(1, self.num_hands + 1):
            # Auto-rebuy: reset short stacks.
            for p in players:
                if p.chips < self.big_blind * 2:
                    p.chips = self.starting_chips

            try:
                hand_result = self._play_hand(players, dealer_idx, hand_num)
                for pid, net in hand_result.net.items():
                    stats = result.player_stats[pid]
                    stats.hands += 1
                    stats.total_bb_won += net / self.big_blind
                    if net > 0:
                        stats.hands_won += 1
                # Track VPIP from player flags.
                for p in players:
                    if getattr(p, '_vpip', False):
                        result.player_stats[p.id].vpip_hands += 1
                result.hands_completed += 1
            except Exception as e:
                result.errors += 1
                if self.verbose:
                    print(f"  Hand {hand_num} error: {e}", file=sys.stderr)

            dealer_idx = (dealer_idx + 1) % len(players)

        return result

    def _play_hand(
        self, players: list[_SimPlayer], dealer_idx: int, hand_num: int,
    ) -> HandStats:
        """Play a single hand of poker."""
        n = len(players)
        hs = HandStats(hand_number=hand_num)

        # Reset per-hand state.
        for p in players:
            p.bet = 0
            p.total_bet = 0
            p.status = PlayerStatus.ACTIVE
            p.cards = None

        # Deal.
        deck = _full_deck()
        self.rng.shuffle(deck)
        di = 0
        for p in players:
            p.cards = (deck[di], deck[di + 1])
            di += 2

        board_cards = [deck[di + j] for j in range(5)]
        community: list[Card] = []
        pot = 0

        # Post blinds.
        if n == 2:
            sb_idx = dealer_idx
            bb_idx = (dealer_idx + 1) % n
        else:
            sb_idx = (dealer_idx + 1) % n
            bb_idx = (dealer_idx + 2) % n

        sb_amount = self.big_blind // 2
        bb_amount = self.big_blind

        pot += self._post_blind(players[sb_idx], sb_amount)
        pot += self._post_blind(players[bb_idx], bb_amount)

        current_bet = bb_amount

        # Track VPIP.
        vpip_set: set[str] = set()

        # Betting rounds.
        phases = [
            (Phase.PREFLOP, 0),
            (Phase.FLOP, 3),
            (Phase.TURN, 4),
            (Phase.RIVER, 5),
        ]

        for phase, board_count in phases:
            # Deal community cards.
            if board_count > len(community):
                community = board_cards[:board_count]

            active = [p for p in players if p.status in (PlayerStatus.ACTIVE, PlayerStatus.ALL_IN)]
            actionable = [p for p in active if p.status == PlayerStatus.ACTIVE]

            if len(actionable) <= 1 and all(p.bet == current_bet or p.status == PlayerStatus.ALL_IN for p in active):
                if len(active) <= 1:
                    break
                if len(actionable) <= 1:
                    continue

            # Determine first to act.
            if phase == Phase.PREFLOP:
                if n == 2:
                    first_idx = sb_idx  # heads-up: SB acts first preflop
                else:
                    first_idx = (bb_idx + 1) % n
            else:
                current_bet = 0
                for p in players:
                    p.bet = 0
                first_idx = (dealer_idx + 1) % n

            pot = self._betting_round(
                players, first_idx, current_bet, pot, phase,
                community, dealer_idx, hand_num, vpip_set,
            )
            current_bet = max(p.bet for p in players)

            # Check if hand is over (only 1 non-folded player).
            active = [p for p in players if p.status != PlayerStatus.FOLDED]
            if len(active) == 1:
                break

        # Resolve.
        active = [p for p in players if p.status != PlayerStatus.FOLDED]
        community = board_cards[:5]  # ensure full board for showdown

        if len(active) == 1:
            winner = active[0]
            total_pot = sum(p.total_bet for p in players)
            winnings = total_pot - winner.total_bet
            winner.chips += total_pot
            hs.net = {p.id: -p.total_bet for p in players}
            hs.net[winner.id] = winnings
            if self.verbose:
                print(f"  Hand {hand_num}: {winner.name} wins {total_pot} (others folded)")
        else:
            hs.went_to_showdown = True
            hs.net = self._showdown(active, players, community)
            if self.verbose:
                winners = [pid for pid, net in hs.net.items() if net > 0]
                print(f"  Hand {hand_num}: showdown — winners: {winners}, board: {' '.join(str(c) for c in community)}")

        # Record VPIP.
        for pid in vpip_set:
            stats = None  # will be recorded by caller
            for p in players:
                if p.id == pid:
                    # Mark in a way the caller can read — we'll do it differently.
                    pass
        # Store vpip on the players temporarily.
        for p in players:
            p._vpip = p.id in vpip_set  # type: ignore[attr-defined]

        return hs

    def _post_blind(self, player: _SimPlayer, amount: int) -> int:
        """Post a blind. Returns amount actually posted."""
        actual = min(amount, player.chips)
        player.chips -= actual
        player.bet = actual
        player.total_bet = actual
        if actual < amount:
            player.status = PlayerStatus.ALL_IN
        return actual

    def _betting_round(
        self,
        players: list[_SimPlayer],
        first_idx: int,
        current_bet: int,
        pot: int,
        phase: Phase,
        community: list[Card],
        dealer_idx: int,
        hand_num: int,
        vpip_set: set[str],
    ) -> int:
        """Run a single betting round. Returns updated pot."""
        n = len(players)
        last_raiser: Optional[str] = None
        acted: set[str] = set()
        idx = first_idx

        max_actions = n * 4 + 10  # safety limit to prevent infinite loops
        action_count = 0

        while action_count < max_actions:
            action_count += 1
            p = players[idx % n]
            idx_mod = idx % n

            if p.status != PlayerStatus.ACTIVE:
                idx += 1
                if self._round_complete(players, acted, last_raiser, current_bet):
                    break
                continue

            if p.id in acted and (last_raiser is None or p.id == last_raiser):
                break

            # Build game state for this player.
            state = self._build_state(p, players, community, current_bet, phase, dealer_idx, hand_num)
            if not state.valid_actions:
                acted.add(p.id)
                idx += 1
                continue

            # Get decision.
            try:
                action = p.bot.decide(state)
            except Exception:
                action = Action.fold()

            # Apply action.
            applied_bet = current_bet
            if action.type == ActionType.FOLD:
                p.status = PlayerStatus.FOLDED
            elif action.type == ActionType.CHECK:
                if current_bet > p.bet:
                    # Can't check — force fold.
                    p.status = PlayerStatus.FOLDED
            elif action.type == ActionType.CALL:
                call_amount = min(current_bet - p.bet, p.chips)
                p.chips -= call_amount
                p.bet += call_amount
                p.total_bet += call_amount
                pot += call_amount
                vpip_set.add(p.id)
                if p.chips == 0:
                    p.status = PlayerStatus.ALL_IN
            elif action.type == ActionType.RAISE:
                raise_to = action.amount
                # Clamp to valid range.
                min_raise = current_bet + self.big_blind
                if current_bet == 0:
                    min_raise = self.big_blind
                max_raise = p.chips + p.bet
                raise_to = max(min_raise, min(raise_to, max_raise))

                cost = raise_to - p.bet
                if cost >= p.chips:
                    # All-in.
                    actual_cost = p.chips
                    p.bet += actual_cost
                    p.total_bet += actual_cost
                    p.chips = 0
                    pot += actual_cost
                    p.status = PlayerStatus.ALL_IN
                else:
                    p.chips -= cost
                    p.bet = raise_to
                    p.total_bet += cost
                    pot += cost
                current_bet = max(current_bet, p.bet)
                last_raiser = p.id
                acted.clear()
                vpip_set.add(p.id)
            elif action.type == ActionType.ALLIN:
                all_in_amount = p.chips
                p.bet += all_in_amount
                p.total_bet += all_in_amount
                pot += all_in_amount
                p.chips = 0
                p.status = PlayerStatus.ALL_IN
                if p.bet > current_bet:
                    current_bet = p.bet
                    last_raiser = p.id
                    acted.clear()
                vpip_set.add(p.id)

            acted.add(p.id)
            idx += 1

            # Check if round is complete.
            if self._round_complete(players, acted, last_raiser, current_bet):
                break

        return pot

    def _round_complete(
        self, players: list[_SimPlayer], acted: set[str],
        last_raiser: Optional[str], current_bet: int,
    ) -> bool:
        """Check if the betting round is complete."""
        for p in players:
            if p.status != PlayerStatus.ACTIVE:
                continue
            if p.id not in acted:
                return False
            if p.bet < current_bet:
                return False
        return True

    def _build_state(
        self, hero: _SimPlayer, players: list[_SimPlayer],
        community: list[Card], current_bet: int, phase: Phase,
        dealer_idx: int, hand_num: int,
    ) -> GameState:
        """Build a masked GameState for a player."""
        player_infos = []
        for p in players:
            cards = None
            if p.id == hero.id:
                cards = p.cards
            player_infos.append(PlayerInfo(
                id=p.id, name=p.name, chips=p.chips, bet=p.bet,
                status=p.status, position=p.position, cards=cards,
            ))

        # Build valid actions.
        valid = []
        to_call = current_bet - hero.bet

        if to_call <= 0:
            valid.append(ValidAction(type=ActionType.CHECK))
        else:
            valid.append(ValidAction(type=ActionType.FOLD))
            call_cost = min(to_call, hero.chips)
            if call_cost > 0:
                valid.append(ValidAction(type=ActionType.CALL, min_amount=call_cost, max_amount=call_cost))

        # Raise option.
        min_raise = current_bet + self.big_blind
        if current_bet == 0:
            min_raise = self.big_blind
        max_raise = hero.chips + hero.bet

        if max_raise > current_bet and hero.chips > to_call:
            valid.append(ValidAction(
                type=ActionType.RAISE,
                min_amount=max(min_raise, current_bet + 1),
                max_amount=max_raise,
            ))

        # All-in always available if you have chips.
        if hero.chips > 0:
            valid.append(ValidAction(type=ActionType.ALLIN))

        # Fold always available (even if you can check).
        if not any(va.type == ActionType.FOLD for va in valid):
            valid.append(ValidAction(type=ActionType.FOLD))

        return GameState(
            phase=phase,
            pot=sum(p.bet for p in players),
            community_cards=list(community),
            current_bet=current_bet,
            players=player_infos,
            your_cards=hero.cards,
            your_id=hero.id,
            to_act_id=hero.id,
            valid_actions=valid,
            hand_number=hand_num,
            dealer_index=dealer_idx,
        )

    def _showdown(
        self, active: list[_SimPlayer], all_players: list[_SimPlayer],
        community: list[Card],
    ) -> dict[str, int]:
        """Resolve showdown with side pots. Returns net chips per player."""
        net: dict[str, int] = {p.id: -p.total_bet for p in all_players}

        # Build sorted list of unique bet amounts for side pot calculation.
        bet_levels = sorted(set(p.total_bet for p in active))

        prev_level = 0
        remaining = list(active)

        for level in bet_levels:
            if not remaining:
                break

            # This pot layer: (level - prev_level) * number of contributors.
            contributors = [p for p in all_players if p.total_bet >= level and p.status != PlayerStatus.FOLDED]
            pot_amount = (level - prev_level) * len([p for p in all_players if p.total_bet >= level])

            if pot_amount <= 0:
                prev_level = level
                continue

            # Find best hand among eligible players.
            eligible = [p for p in remaining if p.total_bet >= level]
            if not eligible:
                prev_level = level
                continue

            best_score = -1
            winners: list[_SimPlayer] = []
            for p in eligible:
                _, score, _ = self._evaluator.evaluate(p.cards, community)
                if score > best_score:
                    best_score = score
                    winners = [p]
                elif score == best_score:
                    winners.append(p)

            # Split pot among winners.
            share = pot_amount // len(winners)
            remainder = pot_amount - share * len(winners)
            for i, w in enumerate(winners):
                award = share + (1 if i < remainder else 0)
                w.chips += award
                net[w.id] += award

            prev_level = level

        return net
