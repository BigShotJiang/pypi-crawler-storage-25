"""Adapters — bridge entre le ConversationRuntime CC et maestro_core.

Connecte le vrai runtime CC (permissions, hooks, compaction) au provider
router multi-provider et au tool registry de maestro_core."""

from __future__ import annotations

import asyncio
import json
from typing import Any

from maestro_core.api.types import (
    InputMessage,
    MessageRequest,
    TextInputBlock,
    TextOutputBlock,
    ToolUseOutputBlock,
)
from maestro_core.provider_router import ProviderRouter
from maestro_core.tools.base import ToolRegistry

from .conversation import (
    ApiClient,
    ApiRequest,
    AssistantEvent,
    MessageStop,
    TextDelta,
    ToolError,
    ToolExecutor,
    ToolUse,
    UsageEvent,
)
from .session import ConversationMessage, MessageRole, TextBlock, ToolUseBlock, ToolResultBlock
from .usage import TokenUsage


class ProviderApiClient(ApiClient):
    """Bridge entre ConversationRuntime.ApiClient et ProviderRouter.

    Convertit les ApiRequest (format CC) en MessageRequest (format maestro_core),
    envoie via le ProviderRouter, et retourne des AssistantEvent.

    Utilise un event loop persistant pour éviter les problèmes httpx."""

    def __init__(
        self,
        router: ProviderRouter,
        model: str = "",
        system_prompt: str = "",
        tool_registry: ToolRegistry | None = None,
    ) -> None:
        self._router = router
        self._model = model
        self._system_prompt = system_prompt
        self._tool_registry = tool_registry
        # Event loop persistant pour les appels async
        self._loop = asyncio.new_event_loop()

    def __del__(self) -> None:
        if self._loop and not self._loop.is_closed():
            self._loop.close()

    def stream(self, request: ApiRequest) -> list[AssistantEvent]:
        """Envoie la requête au LLM et retourne les events.

        Note: synchrone car ConversationRuntime.run_turn est synchrone.
        On utilise asyncio.run() pour appeler le router async."""
        # Convertir les messages CC en messages maestro_core
        messages = self._convert_messages(request.messages)
        system = "\n".join(request.system_prompt) if request.system_prompt else self._system_prompt

        # Tool definitions pour le LLM
        tool_defs = None
        if self._tool_registry and len(self._tool_registry) > 0:
            from maestro_core.api.types import ToolDefinition as ApiToolDef
            tool_defs = [
                ApiToolDef(name=td.name, description=td.description, input_schema=td.input_schema)
                for td in self._tool_registry.get_definitions()
            ]

        # Construire la requête
        msg_request = MessageRequest(
            model=self._model,
            max_tokens=4096,
            messages=messages,
            system=system,
            tools=tool_defs,
        )

        # Extraire le texte user pour le routage
        user_text = ""
        for msg in reversed(request.messages):
            if msg.role == MessageRole.USER:
                for block in msg.blocks:
                    if isinstance(block, TextBlock):
                        user_text = block.text
                        break
                if user_text:
                    break

        # Appeler le router (async → sync via event loop persistant)
        response, decision = self._loop.run_until_complete(
            self._router.send_message(msg_request, user_text)
        )

        # Convertir la réponse en AssistantEvents
        events: list[AssistantEvent] = []

        for block in response.content:
            if isinstance(block, TextOutputBlock):
                events.append(TextDelta(text=block.text))
            elif isinstance(block, ToolUseOutputBlock):
                events.append(ToolUse(
                    id=block.id,
                    name=block.name,
                    input=json.dumps(block.input) if isinstance(block.input, dict) else str(block.input),
                ))

        # Usage
        if response.usage:
            events.append(UsageEvent(usage=TokenUsage(
                input_tokens=response.usage.input_tokens,
                output_tokens=response.usage.output_tokens,
            )))

        events.append(MessageStop())
        return events

    def _convert_messages(self, messages: list[ConversationMessage]) -> list[InputMessage]:
        """Convertit les messages CC en messages maestro_core."""
        result: list[InputMessage] = []

        for msg in messages:
            if msg.role == MessageRole.USER:
                content_blocks = []
                for block in msg.blocks:
                    if isinstance(block, TextBlock):
                        content_blocks.append(TextInputBlock(text=block.text))
                if content_blocks:
                    result.append(InputMessage(role="user", content=content_blocks))

            elif msg.role == MessageRole.ASSISTANT:
                content_blocks = []
                for block in msg.blocks:
                    if isinstance(block, TextBlock):
                        content_blocks.append(TextInputBlock(text=block.text))
                    elif isinstance(block, ToolUseBlock):
                        from maestro_core.api.types import ToolUseInputBlock
                        args = json.loads(block.input) if isinstance(block.input, str) else block.input
                        content_blocks.append(ToolUseInputBlock(
                            id=block.id, name=block.name, input=args
                        ))
                if content_blocks:
                    result.append(InputMessage(role="assistant", content=content_blocks))

            elif msg.role == MessageRole.TOOL:
                from maestro_core.api.types import ToolResultInputBlock, TextToolResultBlock
                for block in msg.blocks:
                    if isinstance(block, ToolResultBlock):
                        result.append(InputMessage(
                            role="user",
                            content=[ToolResultInputBlock(
                                tool_use_id=block.tool_use_id,
                                content=[TextToolResultBlock(text=block.output)],
                                is_error=block.is_error,
                            )],
                        ))

        return result


class RegistryToolExecutor(ToolExecutor):
    """Bridge entre ConversationRuntime.ToolExecutor et maestro_core.ToolRegistry.

    Convertit les appels tool du runtime CC en appels async sur le ToolRegistry."""

    def __init__(self, registry: ToolRegistry, loop: asyncio.AbstractEventLoop | None = None) -> None:
        self._registry = registry
        self._loop = loop or asyncio.new_event_loop()

    def execute(self, tool_name: str, input_str: str) -> str:
        """Exécute un tool via le registry (sync wrapper autour d'async)."""
        tool = self._registry.get(tool_name)
        if tool is None:
            raise ToolError(f"Tool '{tool_name}' not found in registry")

        # Parser les arguments
        try:
            args = json.loads(input_str) if input_str else {}
        except json.JSONDecodeError:
            args = {"input": input_str}

        # Exécuter via le loop persistant
        result = self._loop.run_until_complete(
            self._registry.execute(tool_name, args)
        )

        if result.is_error:
            raise ToolError(result.content)

        return result.content
