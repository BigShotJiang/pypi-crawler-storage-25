import uvicorn
from fastapi import FastAPI, Response
from pydantic import BaseModel
import io
from PIL import Image
import numpy as np

app = FastAPI()

# Global "State" to keep the last processed tensors in VRAM/RAM
state = {"original_RGB": None, "model_output": None, "model_params": None, "rh": None}


class LoadRequest(BaseModel):
    in_file: str
    model_name: str


@app.post("/load-and-infer")
async def load_and_infer(req: LoadRequest):
    # This is the heavy lifting
    # 1. Run your existing get_image logic
    # 2. Run your InferenceWorker logic
    # 3. Store result in global state
    state["original_RGB"] = image_RGB
    state["model_output"] = output_img
    return {"status": "Model finished. Ready for slider updates."}


@app.get("/preview")
async def get_preview(lumi: float = 0.0, chroma: float = 0.0):
    if state["model_output"] is None:
        return {"error": "No image loaded"}

    # FAST STEP: Only run the post-processing blending
    # This uses the tensors already sitting in memory
    final_output = postprocess(
        state["original_RGB"],
        state["model_output"],
        lumi_blend=lumi,
        chroma_blend=chroma,
    )

    # Convert NumPy array to JPEG for the browser/Electron to display
    # We downscale for the preview to make it even faster
    img = Image.fromarray((final_output * 255).astype(np.uint8))
    img.thumbnail((1200, 1200))  # Resize for UI performance

    buf = io.BytesIO()
    img.save(buf, format="JPEG", quality=85)
    return Response(content=buf.getvalue(), media_type="image/jpeg")


if __name__ == "__main__":
    uvicorn.run(app, port=8000)
