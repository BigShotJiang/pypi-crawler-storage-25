# Docx Cleaner

> 一键清理 AI 生成文档粘贴到 Word 后的格式乱象。

## 痛点

AI（如 ChatGPT、Claude、DeepSeek 等）生成的文字内容直接复制粘贴到 Word 中，常出现以下格式问题：

| 问题 | 示例 |
|------|------|
| 公式运算符周围多空格 | `P = 500 × 1.276 = 638` |
| 中文与数字/标点间多空格 | `95.5 人月`、`440675 元` |
| 列表缩进用空格 | `  第1年: 还本金5万` |
| 中文与英文术语间多空格 | `功能点 UFP` → `功能点UFP` |

这些问题手动修复耗时且容易遗漏，本工具一键处理。

## 功能

- **公式空格清理**：去除 `=`, `×`, `+`, `-`, `/` 等运算符周围多余空格
- **中文间距清理**：去除中文与数字、标点、英文之间的多余空格
- **全量空格清理**：去除所有非英文字母分隔的空格（保留 `Unit Testing` 这类英文单词间距）
- **缩进转换**：将行首空格统一转换为制表符 `\t`（可选）
- **原地/新文件输出**：支持覆盖原文件或另存为新文件

## 安装

```bash
pip install docx-cleaner
```

或直接从源码使用：

```bash
git clone https://github.com/WUIR/docx-cleaner.git
cd docx-cleaner
pip install .
```

## 快速开始

```bash
# 清理单个文件（覆盖原文件）
docx-cleaner input.docx

# 清理后另存为新文件
docx-cleaner input.docx -o output.docx

# 全部清理 + 空格转制表符
docx-cleaner input.docx --tab

# 只做公式和中文间距清理（保留其他空格）
docx-cleaner input.docx --light
```

## 命令行选项

```
usage: docx-cleaner [-h] [-o OUTPUT] [--tab] [--light] input

positional arguments:
  input                 输入的 .docx 文件路径

options:
  -h, --help            显示帮助信息
  -o, --output OUTPUT   输出文件路径（默认覆盖原文件）
  --tab                 将行首空格缩进替换为制表符
  --light               轻量模式：只做公式和中文间距清理
```

## Python API

```python
from docx_cleaner import clean

# 打开文件 -> 清理 -> 保存
clean("report.docx")                     # 覆盖原文件
clean("report.docx", output="clean.docx") # 另存新文件
clean("report.docx", tab=True)            # 行首空格转制表符
clean("report.docx", light=True)          # 轻量模式
```

## 处理流程

```
输入 .docx
    ↓
解压 ZIP (OOXML)
    ↓
1️⃣ 公式运算符空格清理   P = 25 × 3  →  P=25×3
    ↓
2️⃣ 中文与非中文间距清理  95.5 人月  →  95.5人月
    ↓
3️⃣ 全量字符空格清理      , i=5.0%  →  ,i=5.0%
    ↓
4️⃣ [可选] 缩进空格→制表符  2空格缩进 → \t
    ↓
压缩回 .docx
    ↓
输出文件
```

## 开源协议

MIT License

## 作者

**Desola** · 1817881032@qq.com

## 贡献

欢迎提交 Issue 和 PR！如果你遇到新的格式问题，欢迎反馈。
