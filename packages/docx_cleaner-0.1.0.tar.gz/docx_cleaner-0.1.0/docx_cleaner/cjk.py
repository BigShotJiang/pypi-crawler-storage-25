"""中文与数字、标点、英文字母之间的多余空格清理。"""

import re

CJK = r'[\u4e00-\u9fff\u3400-\u4dbf\uff00-\uffef]'
NON_CJK = r'[^\u4e00-\u9fff\u3400-\u4dbf\uff00-\uffef\s]'


def clean_cjk_spaces(text: str) -> str:
    """去除中文与非中文字符之间的多余空格。

    处理三类模式（循环至稳定）：
    1. CJK + space(s) + non-CJK
    2. non-CJK + space(s) + CJK
    3. CJK + space(s) + CJK

    Examples:
        "95.5 人月"    → "95.5人月"
        "功能点 AFP"   → "功能点AFP"
        "附表  和取值" → "附表和取值"
    """
    prev = ''
    while prev != text:
        prev = text
        text = re.sub(r'(' + CJK + r')\s+(' + NON_CJK + r')', r'\1\2', text)
        text = re.sub(r'(' + NON_CJK + r')\s+(' + CJK + r')', r'\1\2', text)
        text = re.sub(r'(' + CJK + r')\s+(' + CJK + r')', r'\1\2', text)
    return text
