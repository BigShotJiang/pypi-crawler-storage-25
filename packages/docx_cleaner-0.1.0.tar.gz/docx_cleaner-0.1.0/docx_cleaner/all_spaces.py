"""全量字符间空格清理（保留英文单词边界）。"""

import re


def clean_all_spaces(text: str) -> str:
    """去除所有非英文字母分隔的空格。

    保留英文字母间的空格（如 "Unit Testing" 不会变为 "UnitTesting"），
    其余所有非空白字符间的空格全部去除。

    Examples:
        "i=4.0%, n=8年"    → "i=4.0%,n=8年"
        "a: ES=0.00, EF=4" → "a:ES=0.00,EF=4"
        "Unit Testing"     → "Unit Testing" (保留)
    """
    # 1. Strip trailing spaces
    text = text.rstrip(' ')

    # 2. Separate leading spaces (indentation)
    leading = len(text) - len(text.lstrip(' '))
    indent = ' ' * leading if leading > 0 else ''
    body = text[leading:] if leading > 0 else text

    # 3. Remove inter-character spaces, preserving English word boundaries
    body = re.sub(
        r'(\S)\s+(\S)',
        lambda m: m.group(1) + ' ' + m.group(2)
        if m.group(1).isalpha() and m.group(2).isalpha()
        else m.group(1) + m.group(2),
        body,
    )

    return indent + body
