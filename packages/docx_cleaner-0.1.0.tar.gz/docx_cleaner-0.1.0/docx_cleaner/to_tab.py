"""行首空格缩进 → 制表符转换。"""


def spaces_to_tab(text: str) -> str:
    """将行首每 2 个空格替换为 1 个制表符 \\t。

    规则：每 2 个行首空格 = 1 个 tab，剩余 1 个空格保留。

    Examples:
        "  第1年"    → "\\t第1年"
        "  需求分析" → "\\t需求分析"
        "   额外缩进"→ "\\t\\t额外缩进"
    """
    stripped = text.lstrip(' ')
    leading = len(text) - len(stripped)
    if leading == 0:
        return text
    tabs = leading // 2
    remain = leading % 2
    return '\t' * tabs + ' ' * remain + stripped
