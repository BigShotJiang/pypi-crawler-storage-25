"""Docx Cleaner 核心：编排所有清理步骤。"""

import os
import shutil
import zipfile
import xml.etree.ElementTree as ET
import tempfile

from . import formula, cjk, all_spaces, to_tab

# XML namespace
NSMAP = {'w': 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
ET.register_namespace('w', NSMAP['w'])
ET.register_namespace('r', 'http://schemas.openxmlformats.org/officeDocument/2006/relationships')
ET.register_namespace('mc', 'http://schemas.openxmlformats.org/markup-compatibility/2006')


def _clean_text(text: str, light: bool, tab: bool) -> str:
    """对单个文本段执行所有清理步骤。"""
    # 1) 公式运算符空格
    text = formula.clean_formula_spaces(text)
    # 2) 中文间距
    text = cjk.clean_cjk_spaces(text)
    if not light:
        # 3) 全量非字母间空格
        text = all_spaces.clean_all_spaces(text)
    if tab:
        # 4) 行首缩进转制表符
        text = to_tab.spaces_to_tab(text)
    return text


from typing import Optional


def clean(input_path: str, output: Optional[str] = None, *, light: bool = False, tab: bool = False) -> str:
    """清理 .docx 文件中的格式问题。

    Args:
        input_path: 输入的 .docx 文件路径。
        output: 输出路径。默认覆盖输入文件。
        light: 轻量模式（跳过全量空格清理）。
        tab: 将行首空格缩进转为制表符。

    Returns:
        输出文件的路径。
    """
    output_path = output or input_path
    tmp_dir = tempfile.mkdtemp(prefix='docx_cleaner_')

    try:
        # 解压 DOCX (ZIP)
        with zipfile.ZipFile(input_path, 'r') as z:
            z.extractall(tmp_dir)

        # 读取 document.xml
        doc_path = os.path.join(tmp_dir, 'word', 'document.xml')
        tree = ET.parse(doc_path)
        root = tree.getroot()

        # 遍历所有 w:t 元素，逐段清理
        changed = 0
        for elem in root.findall('.//w:t', NSMAP):
            if elem.text:
                cleaned = _clean_text(elem.text, light=light, tab=tab)
                if cleaned != elem.text:
                    elem.text = cleaned
                    changed += 1

        tree.write(doc_path, xml_declaration=True, encoding='UTF-8')

        # 压缩回 DOCX
        tmp_output = temp_output = os.path.join(tmp_dir, '..', '_docx_cleaner_output.docx')
        # Use a temp file in the same dir to avoid cross-device rename issues
        final_tmp = os.path.join(os.path.dirname(output_path), '.docx_cleaner_tmp.docx')
        with zipfile.ZipFile(final_tmp, 'w', zipfile.ZIP_DEFLATED) as zout:
            for foldername, subfolders, filenames in os.walk(tmp_dir):
                for filename in filenames:
                    file_path = os.path.join(foldername, filename)
                    arcname = os.path.relpath(file_path, tmp_dir)
                    zout.write(file_path, arcname)

        # 覆盖目标文件
        if os.path.exists(output_path):
            os.remove(output_path)
        os.rename(final_tmp, output_path)

        print(f"[OK] 清理完成，修改 {changed} 处文本")
        if output_path != os.path.abspath(input_path):
            print(f"   输出: {output_path}")

    finally:
        shutil.rmtree(tmp_dir, ignore_errors=True)
        leftover = os.path.join(os.path.dirname(output_path), '.docx_cleaner_tmp.docx')
        if os.path.exists(leftover):
            try:
                os.remove(leftover)
            except OSError:
                pass

    return output_path
