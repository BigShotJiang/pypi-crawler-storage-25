"""命令行入口。"""

import argparse
import sys
from typing import List, Optional

from .cleaner import clean


def main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser(
        description="Docx Cleaner — 清理 AI 生成文档粘贴到 Word 后的格式问题",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  docx-cleaner input.docx                      覆盖原文件
  docx-cleaner input.docx -o output.docx       另存为新文件
  docx-cleaner input.docx --tab                全量清理 + 转制表符缩进
  docx-cleaner input.docx --light              轻量模式
        """,
    )
    parser.add_argument('input', help='输入的 .docx 文件路径')
    parser.add_argument('-o', '--output', help='输出文件路径（默认覆盖原文件）')
    parser.add_argument('--tab', action='store_true', help='将行首空格缩进替换为制表符')
    parser.add_argument('--light', action='store_true', help='轻量模式：只做公式和中文间距清理')

    args = parser.parse_args(argv)

    if not args.input.endswith('.docx'):
        print('Error: 输入文件必须是 .docx 格式', file=sys.stderr)
        return 1

    try:
        clean(args.input, output=args.output, light=args.light, tab=args.tab)
    except FileNotFoundError:
        print(f'Error: 文件未找到: {args.input}', file=sys.stderr)
        return 1
    except Exception as e:
        print(f'Error: 处理失败: {e}', file=sys.stderr)
        return 1

    return 0


if __name__ == '__main__':
    sys.exit(main())
