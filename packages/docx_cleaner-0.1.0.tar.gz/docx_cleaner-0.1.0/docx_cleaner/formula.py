"""公式运算符周围多余空格清理。"""

import re


def clean_formula_spaces(text: str) -> str:
    """去除 =, ×, +, -, / 等运算符周围的多余空格。

    Examples:
        "P = 25 × 3" → "P=25×3"
        "F = 500 \\u00d7 5.637" → "F=500\\u00d75.637"
    """
    # =, ×, +, −, ±, ≈, ≠, ≤, ≥, <, >, /
    text = re.sub(r'\s*([=×+−±≈≠≤≥<>/])\s*', r'\1', text)
    # 乘点 ·
    text = re.sub(r'\s*([·])\s*', r'\1', text)
    # 连字符 -（两边都有空格才是减号运算符）
    text = re.sub(r'\s+-\s+', '-', text)
    return text
