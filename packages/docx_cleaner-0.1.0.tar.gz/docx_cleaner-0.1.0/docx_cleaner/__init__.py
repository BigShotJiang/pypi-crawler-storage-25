"""Docx Cleaner - 清理 AI 生成文档粘贴到 Word 后的格式问题。"""

__version__ = "0.1.0"
__author__ = "Desola"

from .cleaner import clean

__all__ = ["clean"]
