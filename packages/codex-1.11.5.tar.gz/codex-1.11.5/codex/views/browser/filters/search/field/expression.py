"""Parse field lookup right hand side expression."""

import re
from datetime import date, datetime
from decimal import Decimal
from types import MappingProxyType
from typing import Any

from comicbox.fields.fields import IssueField
from dateparser import parse
from django.db.backends.base.operations import BaseDatabaseOperations
from django.db.models import (
    BooleanField,
    CharField,
    DateField,
    DateTimeField,
    TextField,
)
from django.db.models.fields import DecimalField, PositiveSmallIntegerField

from codex.settings import FALSY

_QUOTES_RE = re.compile(r"[\"']")
_OP_MAP = MappingProxyType({">": "gt", ">=": "gte", "<": "lt", "<=": "lte"})
_RANGE_RE = re.compile(r"\.{2,}")
_PARSE_ISSUE_MATCHER = re.compile(r"(?P<issue_number>\d*\.?\d*)(?P<issue_suffix>.*)")
_LIKE_QUERY_VALUE = re.compile(r"\S\*+\S")
_ICONTAINS_QUERY_VALUE = re.compile(r"^(\*.*\*|[^*].*[^*]|^\**$)$")
_IENDSWITH_QEURY_VALUE = re.compile(r"^\*")
_ISTARTSWITH_QEURY_VALUE = re.compile(r"\*$")
_SIZE_UNITS = {"b": 1, "kb": 1024, "mb": 1024**2, "gb": 1024**3, "tb": 1024**4}
_DB_OPS = BaseDatabaseOperations(None)  # only uses prep_for_like_query — no connection


def parse_size(s: str) -> int:
    """Parse human friendly byte sizes."""
    s = s.strip().lower()
    for suffix, multiplier in _SIZE_UNITS.items():
        if s.endswith(suffix):
            return int(float(s[: -len(suffix)].strip()) * multiplier)
    return int(s)


def _parse_issue_value(value) -> tuple | tuple[None, None]:
    """Parse a compound issue value into number & suffix."""
    value = IssueField.parse_issue(value)
    if not value:
        return None, None
    matches = _PARSE_ISSUE_MATCHER.match(value)
    if not matches:
        return None, None
    numeric_value = Decimal(matches.group("issue_number"))
    suffix_value = matches.group("issue_suffix")
    return numeric_value, suffix_value


def _parse_issue_values(rel, value, to_value=None) -> dict:
    """Issue is not a column. Convert to issue_number and issue_suffix."""
    numeric_value, suffix_value = _parse_issue_value(value)
    if to_value is not None:
        to_numeric_value, to_suffix_value = _parse_issue_value(to_value)
    else:
        to_numeric_value = to_suffix_value = None

    q_dict = {}

    if numeric_value is not None:
        issue_number_field = rel.replace("issue", "issue_number")
        if to_numeric_value is not None:
            numeric_value = (numeric_value, to_numeric_value)
        q_dict[issue_number_field] = numeric_value

    if suffix_value is not None:
        issue_suffix_field = rel.replace("issue", "issue_suffix")
        if to_suffix_value is not None:
            suffix_value = (suffix_value, to_suffix_value)
        q_dict[issue_suffix_field] = suffix_value

    return q_dict


def _cast_value(rel, rel_class, value) -> int | Decimal | bool | date | datetime | None:
    """Cast values by relation class."""
    if rel.startswith("size"):
        value = parse_size(value)
    elif rel_class == PositiveSmallIntegerField:
        value = int(value)
    elif rel_class == DecimalField:
        value = Decimal(value)
    elif rel_class == BooleanField:
        value = value not in FALSY
    elif rel_class in (DateField, DateTimeField):
        value = parse(value)
        if rel_class == DateField and value:
            value = value.date()
    # (CharField, TextField):
    return value


def _glob_to_lookup(value) -> tuple[str, str]:
    """Transform globs into django orm lookups."""
    rel_suffix = ""
    value = value.strip('"').strip("'")
    if _LIKE_QUERY_VALUE.search(value):
        # Django doesn't have a builtin interior LIKE operator.
        # Escape LIKE reserved chars
        value = _DB_OPS.prep_for_like_query(value)
        value = value.replace("*", "%")
        rel_suffix = "__like"
    elif _ICONTAINS_QUERY_VALUE.search(value):
        rel_suffix = "__icontains"
        value = value.replace("*", "")
    elif _IENDSWITH_QEURY_VALUE.search(value):
        rel_suffix = "__iendswith"
        value = value.replace("*", "")
    elif _ISTARTSWITH_QEURY_VALUE.search(value):
        # This never happens because full text search hijacks it early.
        rel_suffix = "__istartswith"
        value = value.replace("*", "")

    return value, rel_suffix


def _parse_operator_numeric(rel, rel_class, value) -> dict[Any, int | None] | dict:
    value = _cast_value(rel, rel_class, value)
    if value is None:
        return {}
    return {rel: value}


def _parse_operator_text(rel, exp) -> dict[Any, str] | dict:
    """Parse text value operators."""
    if rel == "issue":
        return _parse_issue_values(rel, exp)

    value, rel_suffix = _glob_to_lookup(exp)
    rel += rel_suffix
    return {rel: value}


def _parse_operator(operator, rel, rel_class, exp) -> dict:
    """Move value operator out of value into relation operator."""
    lookup = _OP_MAP[operator]
    span_rel = f"{rel}__{lookup}" if operator else rel
    value = exp[len(operator) :]
    if rel == "issue":
        return _parse_issue_values(span_rel, value)
    return _parse_operator_numeric(span_rel, rel_class, value)


def _parse_operator_range(rel, rel_class, value) -> dict:
    """Parse range operator."""
    range_from_value, range_to_value = _RANGE_RE.split(value, 1)
    rel = f"{rel}__range"
    if rel == ("issue__range"):
        return _parse_issue_values(
            rel,
            range_from_value,
            range_to_value,
        )
    range_value = (
        _cast_value(rel, rel_class, range_from_value),
        _cast_value(rel, rel_class, range_to_value),
    )
    return {rel: range_value}


def parse_expression(rel, rel_class, exp) -> dict:
    """Parse the operators of the value size of the field query."""
    exp = _QUOTES_RE.sub("", exp)

    for op in _OP_MAP:
        if exp.startswith(op):
            q_dict = _parse_operator(
                op,
                rel,
                rel_class,
                exp,
            )
            break
    else:
        if ".." in exp:
            q_dict = _parse_operator_range(rel, rel_class, exp)
        elif (issubclass(rel_class, CharField | TextField)) and not rel.startswith(
            "volume"
        ):
            q_dict = _parse_operator_text(rel, exp)
        else:
            q_dict = _parse_operator_numeric(rel, rel_class, exp)
    return q_dict
