"""Base view for metadata annotations."""

from types import MappingProxyType

from django.db.models import (
    BooleanField,
    ExpressionWrapper,
    F,
    Q,
    Value,
)
from django.db.models.fields import CharField

from codex.models.comic import Comic
from codex.models.functions import JsonGroupArray
from codex.models.groups import BrowserGroupModel, Imprint, Publisher, Series, Volume
from codex.models.named import StoryArc
from codex.views.browser.annotate.bookmark import BrowserAnnotateBookmarkView

_GROUP_BY: MappingProxyType[type[BrowserGroupModel], tuple[str, ...]] = (
    MappingProxyType(
        {
            Publisher: ("sort_name",),
            Imprint: ("sort_name",),
            Series: ("sort_name",),
            Volume: ("name", "number_to"),
            StoryArc: ("sort_name",),
        }
    )
)


class BrowserAnnotateCardView(BrowserAnnotateBookmarkView):
    """Base class for views that need special metadata annotations."""

    def add_group_by(self, qs):
        """Get the group by for the model."""
        # this method is here because this is class is what metadata imports
        if group_by := _GROUP_BY.get(qs.model):
            qs = qs.group_by(*group_by)
        return qs

    def _annotate_group(self, qs):
        """Annotate Group."""
        value = "c" if qs.model is Comic else self.model_group
        return qs.annotate(group=Value(value, CharField(max_length=1)))

    def _annotate_file_name(self, qs):
        """Annotate the file name for folder view."""
        if qs.model is not Comic:
            return qs
        if self.order_key == "filename":
            file_name = F("filename")
        else:
            file_name = self.get_filename_func(qs.model)
        return qs.annotate(file_name=file_name)

    def _annotate_has_metadata(self, qs):
        """Annotate if we have metadata."""
        # The serializer treats this as a ``BooleanField``. Selecting the
        # IS-NOT-NULL predicate keeps the SELECT projection a single byte
        # per row instead of a full nullable ``DateTimeField`` value, and
        # matches the consumer's type without an implicit truthiness coerce.
        if qs.model is Comic:
            qs = qs.annotate(
                has_metadata=ExpressionWrapper(
                    Q(metadata_mtime__isnull=False), output_field=BooleanField()
                )
            )
        return qs

    def annotate_card_aggregates(self, qs):
        """Annotate aggregates that appear the browser card."""
        if qs.model is Comic:
            # comic adds order_value for cards late
            qs = self.annotate_order_value(qs)
        qs = self._annotate_group(qs)
        qs = self.annotate_group_names(qs)
        qs = self._annotate_file_name(qs)
        qs = self.annotate_child_count(qs)
        qs = self.annotate_bookmarks(qs)
        qs = self.annotate_progress(qs)
        qs = self._annotate_has_metadata(qs)
        # ``updated_ats`` is read only by ``BrowserAggregateSerializerMixin``
        # to compute the card mtime — and only browser + metadata responses
        # use that mixin. OPDS feeds compute their own mtime from the
        # bookmark aggregate; cover/download paths never read it. Skipping
        # the JsonGroupArray on those targets removes one DISTINCT scalar
        # aggregate per group row in the cold path.
        if self.TARGET not in self.CARD_TARGETS:
            return qs
        # For group models, traverse to Comic.updated_at via rel_prefix.
        # The group model's own updated_at is not reliably refreshed by
        # bulk_update / bulk_create(update_conflicts) because auto_now
        # only fires on Model.save().
        prefix = "" if qs.model is Comic else self.rel_prefix
        updated_at_field = prefix + "updated_at"
        return qs.annotate(
            updated_ats=JsonGroupArray(
                updated_at_field, distinct=True, order_by=updated_at_field
            )
        )
