"""Database polling for library changes."""

from pathlib import Path
from threading import Condition, Event
from typing import override

from django.db import connections
from django.db.models.functions import Now
from django.utils import timezone
from humanize import naturaldelta

from codex.librarian.fs.import_task import build_import_task
from codex.librarian.fs.poller.snapshot import DatabaseSnapshot, DiskSnapshot
from codex.librarian.fs.poller.snapshot_diff import SnapshotDiff
from codex.librarian.fs.poller.status import FSPollStatus
from codex.librarian.fs.poller.tasks import FSPollLibrariesTask
from codex.librarian.threads import NamedThread
from codex.librarian.worker import WorkerStatusMixin
from codex.models import Library
from codex.views.const import EPOCH_START

DOCKER_UNMOUNTED_FN = "DOCKER_UNMOUNTED_VOLUME"
_DIR_NOT_FOUND_TIMEOUT = 15 * 60
_LIBRARY_ONLY = (
    "path",
    "poll",
    "poll_every",
    "last_poll",
    "update_in_progress",
    "covers_only",
)


class LibraryPollerThread(NamedThread, WorkerStatusMixin):
    """Poll libraries on a schedule, comparing DB snapshots against disk."""

    def __init__(self, *args, **kwargs) -> None:
        """Initialize the poller."""
        super().__init__(*args, **kwargs)
        self.daemon = True
        self._cond = Condition()
        self._shutdown_event = Event()
        self._pending_poll_ids: frozenset[int] = frozenset()
        self._pending_force: bool = False

    #############################################
    # Public interface - called from librariand #
    #############################################

    def poll(self, task: FSPollLibrariesTask) -> None:
        """Trigger an immediate poll for specific libraries."""
        with self._cond:
            self._pending_poll_ids = task.library_ids or frozenset(
                Library.objects.values_list("id", flat=True)
            )
            self._pending_force = task.force
            self._cond.notify()

    @override
    def stop(self) -> None:
        """Signal the poller to shut down."""
        super().stop()
        self._shutdown_event.set()
        with self._cond:
            self._cond.notify()

    #######################
    # Timeout computation #
    #######################

    def _get_poll_timeout(self, library: Library) -> float | None:  # noqa: PLR0911
        """
        Compute seconds until this library's next scheduled poll.

        Returns None to wait forever (manual poll only).
        """
        watch_path = Path(library.path)
        unmounted_marker = watch_path / DOCKER_UNMOUNTED_FN

        if not library.poll:
            self.log.info(f"Library {library.path} waiting for manual poll.")
            return None

        if not watch_path.is_dir():
            self.log.warning(f"Library {library.path} not found. Not polling.")
            return _DIR_NOT_FOUND_TIMEOUT

        if unmounted_marker.exists():
            warning = f"Library {library.path} looks like an unmounted docker volume. Not polling."
            self.log.warning(warning)
            return _DIR_NOT_FOUND_TIMEOUT

        if not tuple(watch_path.iterdir()):
            self.log.warning(
                f"{library.path} is empty. Suspect unmounted. Not polling."
            )
            return _DIR_NOT_FOUND_TIMEOUT

        if library.update_in_progress:
            self.log.debug(f"Library {library.path} update in progress. Not polling.")
            return self._seconds_until_poll(library)

        if not library.last_poll:
            self.log.debug(f"First ever poll for {library.path}")
            return 0

        return self._seconds_until_poll(library)

    @staticmethod
    def _seconds_until_poll(library: Library) -> float:
        """Seconds remaining until the next scheduled poll."""
        last_poll = library.last_poll or EPOCH_START
        since_last = timezone.now() - last_poll
        return max(0, library.poll_every.total_seconds() - since_last.total_seconds())

    ######################################
    # Snapshot diff and event generation #
    ######################################

    def _get_diff(self, library: Library, *, force: bool) -> SnapshotDiff | None:
        """Compute the diff between DB and disk for a library."""
        covers_only = library.covers_only
        ignore_device = True
        db_snap = DatabaseSnapshot(
            library.path,
            self.log,
            covers_only=covers_only,
            ignore_device=ignore_device,
            force=force,
        )
        disk_snap = DiskSnapshot(
            library.path, self.log, covers_only=covers_only, ignore_device=ignore_device
        )

        if len(disk_snap.paths) <= 1:
            self.log.warning(f"{library.path} dir snapshot is empty. Not polling.")
            return None

        return SnapshotDiff(db_snap, disk_snap)

    def _refresh_stale_stats(self, diff: SnapshotDiff) -> None:
        """
        Sync DB stat to current disk stat for unchanged-content / rotated-inode paths.

        Without this, the May-1 fix that stopped flagging every comic
        modified on Docker remount left DB inodes permanently stale —
        once a remount rotated the kernel's inode space, the
        ``_find_moved_paths`` lookup keys diverged from disk reality
        and stayed that way until the next true delete/add cycle. The
        ``_is_move_compatible`` guard suppresses the corruption that
        produced, but legitimate cross-remount renames still degrade
        to delete+add (and the user loses the comic.pk's bookmarks).

        Refresh in-place: rewrite ``stat`` only, do not bump
        ``updated_at``. The file's content is unchanged from the
        user's perspective; the bookmark/cover-cache "freshness"
        invariants must hold.

        Skipped on ``force=True`` polls because force routes every
        path through the import pipeline (where ``presave`` already
        rewrites stats), and we'd rather not double-write.
        """
        if not diff.stale_stat_refreshes:
            return
        # Bucket by model so each table takes one bulk_update.
        by_model: dict[type, list[tuple[str, list]]] = {}
        for refresh in diff.stale_stat_refreshes:
            by_model.setdefault(refresh.model, []).append(
                (refresh.path, list(refresh.disk_stat))
            )
        total = 0
        for model, payloads in by_model.items():
            paths = [p for p, _ in payloads]
            stat_by_path = dict(payloads)
            rows = tuple(
                model.objects.filter(path__in=paths).only("pk", "path", "stat")  # ty: ignore[unresolved-attribute]
            )
            for row in rows:
                row.stat = stat_by_path[row.path]
            if rows:
                model.objects.bulk_update(rows, fields=["stat"])  # ty: ignore[unresolved-attribute]
                total += len(rows)
        if total:
            msg = (
                f"Refreshed stale stat on {total} unchanged-content paths "
                "(inode rotated, content matches)."
            )
            self.log.debug(msg)

    def _queue_poll_events(self, library: Library, *, force: bool) -> None:
        """Run the snapshot diff and emit a single ImportTask for the library."""
        diff = self._get_diff(library, force=force)
        if diff is None:
            return

        # Refresh DB stats for paths whose content matches but whose
        # inode rotated (Docker remount, in-place file replacement).
        # Force polls already rewrite stats through the import path.
        if not force:
            self._refresh_stale_stats(diff)

        if diff.is_empty():
            self.log.debug(f"Nothing changed for {library.path}")
            return

        debug_log = (
            f"Poller found: {len(diff.files_deleted)} deleted, "
            f"{len(diff.files_modified)} modified, "
            f"{len(diff.files_added)} added, "
            f"{len(diff.files_moved)} moved files. "
            f"{len(diff.dirs_deleted)} deleted, "
            f"{len(diff.dirs_modified)} modified, "
            f"{len(diff.dirs_moved)} moved dirs."
        )
        self.log.debug(debug_log)

        task = build_import_task(
            library.pk, diff.to_events(), check_metadata_mtime=not force
        )
        if task is not None:
            self.librarian_queue.put(task)

    def _poll_library(self, library: Library, *, force: bool) -> None:
        """Poll a single library with status tracking."""
        if self.db_write_lock.locked():
            self.log.warning(f"Database locked, not polling {library.path}.")
            return
        status = FSPollStatus(subtitle=library.path)
        try:
            self.status_controller.start(status)
            self.log.debug(f"Polling {library.path}...")
            self._queue_poll_events(library, force=force)
            library.last_poll = Now()
            library.save()
        except Exception:
            self.log.exception(f"Poll {library.path}")
        finally:
            self.status_controller.finish(status)

    #############
    # Main loop #
    #############

    def _poll_due_and_get_next_timeout(self, *, force: bool = False) -> float | None:
        """
        Poll any due libraries and return the wait time until the next.

        ``_get_poll_timeout`` is the source of truth for both "is this
        library due now?" and "when will it be due?", and it logs as a
        side effect — notably an INFO ``waiting for manual poll`` line
        for every ``poll=False`` library it sees. The previous shape
        called it twice per main-loop iteration (once to find the
        minimum timeout, once to pick the libraries to poll), so that
        log fired twice every cycle a library was due. Folding the
        two passes into one keeps each library inspected exactly once
        per cycle.
        """
        min_timeout: float | None = None
        try:
            libraries = Library.objects.all().only(*_LIBRARY_ONLY)
            for library in libraries:
                try:
                    timeout = self._get_poll_timeout(library)
                except FileNotFoundError:
                    self.log.warning(f"Library {library.path} not found.")
                    continue

                if timeout is None:
                    continue
                if timeout <= 0:
                    self._poll_library(library, force=force)
                    # ``_poll_library`` bumped ``last_poll`` to now, so
                    # the next natural wait for this library is one
                    # whole ``poll_every`` away. Fold that into the
                    # running min so we don't return ``None`` and wait
                    # forever when the only due library was the one we
                    # just polled.
                    timeout = library.poll_every.total_seconds()
                if min_timeout is None or timeout < min_timeout:
                    min_timeout = timeout
        except Exception:
            self.log.exception("Computing next poll timeout")
            return 60  # Retry in a minute on error

        return min_timeout

    def _handle_pending_polls(self) -> None:
        """Handle manually triggered polls."""
        poll_ids = self._pending_poll_ids
        force = self._pending_force
        self._pending_poll_ids = frozenset()
        self._pending_force = False

        try:
            qs = Library.objects.all()
            if poll_ids:
                qs = qs.filter(pk__in=poll_ids)
            qs.only(*_LIBRARY_ONLY)
            for library in qs:
                self._poll_library(library, force=force)
        except Exception:
            self.log.exception(f"Manual library poll {poll_ids}")

    @override
    def run(self) -> None:
        """Poller main loop."""
        self.run_start()

        while not self._shutdown_event.is_set():
            try:
                # Handle any pending manual polls first
                if self._pending_poll_ids:
                    self._handle_pending_polls()

                # Poll any due libraries and find the next scheduled poll time
                timeout = self._poll_due_and_get_next_timeout()

                # Sleep until next poll or until woken
                if timeout is not None:
                    self.log.debug(f"Next poll in {naturaldelta(timeout)}.")
                # Poll intervals on a typical install are hours; the
                # ``poll=False`` "manual poll only" case is unbounded.
                # Release the conn so the wait doesn't pin a file
                # handle through the entire interval. Reopen on the
                # next poll is ~5-20 ms, invisible against the work.
                connections.close_all()
                with self._cond:
                    self._cond.wait(timeout)

            except Exception:
                self.log.exception(f"{self.__class__.__name__} loop error")

        self.log.debug(f"Stopped {self.__class__.__name__}")
