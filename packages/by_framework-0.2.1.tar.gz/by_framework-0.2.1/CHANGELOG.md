# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added
- Standardized Open Source governance files (CONTRIBUTING, CODE_OF_CONDUCT, SECURITY).
- GitHub Issue and Pull Request templates.
- Dependabot configuration for dependency monitoring.

## [0.2.0] - 2026-05-13
### Initial release
