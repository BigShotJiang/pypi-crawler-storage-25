# Copyright 2025-2026 Hanlian Lu. SPDX-License-Identifier: Apache-2.0
"""Entity extraction for unified representational RAG.

Uses VLM to generate text descriptions from page images, then feeds
them into LightRAG's entity extraction pipeline to build the knowledge graph.
"""

from __future__ import annotations

import asyncio
import base64
import hashlib
import json
import logging
import re
from collections.abc import Callable
from typing import Any

from lightrag.operate import extract_entities, merge_nodes_and_edges
from lightrag.utils import compute_mdhash_id

# LightRAG merge_nodes_and_edges still writes progress through
# pipeline_status_lock despite accepting None defaults in the signature.
# Provide a real lock + status dict to satisfy the runtime contract.
_NOOP_PIPELINE_STATUS: dict = {"latest_message": "", "history_messages": []}
_PIPELINE_STATUS_LOCK = asyncio.Lock()

logger = logging.getLogger(__name__)


class EntityExtractor:
    """Extract entities from page images via VLM + LightRAG pipeline."""

    _CACHE_MAX_SIZE = 2048

    def __init__(
        self,
        lightrag: Any,  # LightRAG instance
        entity_types: list[str],
        vision_model_func: Callable | None = None,
        max_concurrent_vlm: int = 4,
        context_model_func: Callable | None = None,
    ) -> None:
        self.lightrag = lightrag
        self.entity_types = entity_types
        self.vision_model_func = vision_model_func
        self.context_model_func = context_model_func
        self._vlm_semaphore = asyncio.Semaphore(max_concurrent_vlm)
        # Content-hash → VLM description cache (per-instance)
        self._description_cache: dict[str, str] = {}

    async def extract_from_pages(
        self,
        images: list[Any],  # list[PIL.Image.Image]
        doc_id: str,
        file_path: str,
    ) -> list[dict]:
        """Extract entities from page images and build KG.

        Returns list of dicts with keys: chunk_id, page_index, content
        (VLM description). These are used to populate text_chunks and
        visual_chunks.

        When context_model_func is set and there are multiple pages,
        pages are processed sequentially with structural context
        carry-forward. Otherwise, pages are processed in parallel.
        Single-page documents skip context machinery entirely.
        """
        if self.vision_model_func is None:
            raise ValueError("vision_model_func is required for entity extraction")

        # 1. Generate VLM descriptions
        if len(images) <= 1 or self.context_model_func is None:
            # Single page or no context model: parallel (original behavior)
            description_tasks = [
                self._describe_page(image, page_index) for page_index, image in enumerate(images)
            ]
            descriptions = await asyncio.gather(*description_tasks)
        else:
            # Multi-page with context model: sequential with carry-forward
            descriptions = []
            structural_ctx: str | None = None
            for page_index, image in enumerate(images):
                desc = await self._describe_page(image, page_index, structural_ctx=structural_ctx)
                structural_ctx = await self._update_structural_context(structural_ctx, desc)
                descriptions.append(desc)

        # 2. Build chunks dict for LightRAG
        chunk_ids: list[str] = []
        chunks_dict: dict[str, dict[str, Any]] = {}
        for page_index, description in enumerate(descriptions):
            chunk_id = compute_mdhash_id(f"{doc_id}:page:{page_index}", prefix="chunk-")
            chunk_ids.append(chunk_id)
            chunks_dict[chunk_id] = {
                "content": description,
                "full_doc_id": doc_id,
                "tokens": len(description.split()),
                "chunk_order_index": page_index,
                "file_path": file_path,
            }

        # 3. Call extract_entities
        chunk_results = await extract_entities(
            chunks=chunks_dict,  # type: ignore[arg-type]
            global_config=self.lightrag.__dict__,
            llm_response_cache=self.lightrag.llm_response_cache,
            text_chunks_storage=self.lightrag.text_chunks,
        )

        # 4. Call merge_nodes_and_edges
        await merge_nodes_and_edges(
            chunk_results=chunk_results,
            knowledge_graph_inst=self.lightrag.chunk_entity_relation_graph,
            entity_vdb=self.lightrag.entities_vdb,
            relationships_vdb=self.lightrag.relationships_vdb,
            global_config=self.lightrag.__dict__,
            full_entities_storage=self.lightrag.full_entities,
            full_relations_storage=self.lightrag.full_relations,
            doc_id=doc_id,
            llm_response_cache=self.lightrag.llm_response_cache,
            entity_chunks_storage=self.lightrag.entity_chunks,
            relation_chunks_storage=self.lightrag.relation_chunks,
            pipeline_status=_NOOP_PIPELINE_STATUS,
            pipeline_status_lock=_PIPELINE_STATUS_LOCK,
            file_path=file_path,
        )

        # 5. Return page info list
        return [
            {
                "chunk_id": chunk_id,
                "page_index": page_index,
                "content": description,
            }
            for page_index, (chunk_id, description) in enumerate(
                zip(chunk_ids, descriptions, strict=True)
            )
        ]

    @staticmethod
    def _image_content_hash(image_bytes: bytes) -> str:
        """Compute SHA-256 hash of image bytes for caching."""
        return hashlib.sha256(image_bytes).hexdigest()

    async def _describe_page(
        self,
        image: Any,
        page_index: int,
        structural_ctx: str | None = None,
    ) -> str:
        """Call VLM to extract structured content and convert to text.

        Results are cached by image content hash (without structural context).
        When structural context is provided, the cache is bypassed since the
        same image may produce different output depending on preceding pages.
        """
        from dlightrag.core.vlm_ocr import (
            blocks_to_text,
            image_to_png_bytes,
            parse_vlm_response,
        )
        from dlightrag.prompts import OCR_SYSTEM_PROMPT, OCR_USER_PROMPT

        if self.vision_model_func is None:
            raise RuntimeError("vision_model_func is required but was not set")

        image_bytes = image_to_png_bytes(image)

        # Check cache (only for context-free descriptions with real image data)
        _MIN_CACHEABLE_SIZE = 256  # real PNGs are always > 256 bytes
        cache_key: str | None = None
        if structural_ctx is None and len(image_bytes) >= _MIN_CACHEABLE_SIZE:
            cache_key = self._image_content_hash(image_bytes)
            cached = self._description_cache.get(cache_key)
            if cached is not None:
                logger.debug("VLM cache hit for page %d", page_index)
                return cached

        b64 = base64.b64encode(image_bytes).decode()

        # Build user content parts
        user_content: list[dict[str, Any]] = []

        # Inject structural context before image if available
        if structural_ctx:
            user_content.append(
                {"type": "text", "text": f"Context from previous pages:\n{structural_ctx}"}
            )

        user_content.append(
            {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{b64}"}}
        )
        user_content.append({"type": "text", "text": OCR_USER_PROMPT})

        messages = [
            {"role": "system", "content": OCR_SYSTEM_PROMPT},
            {"role": "user", "content": user_content},
        ]
        async with self._vlm_semaphore:
            raw = await self.vision_model_func(messages=messages)

        if not raw or not raw.strip():
            logger.warning("VLM returned empty response for page %d", page_index)
            return f"[Page {page_index + 1}: no content extracted]"

        blocks = parse_vlm_response(raw)
        if blocks is None:
            # Could not parse structured JSON — use raw text as fallback
            result = raw.strip()
        else:
            result = blocks_to_text(blocks) or f"[Page {page_index + 1}: no content extracted]"

        # Store in cache (context-free only)
        if cache_key is not None:
            if len(self._description_cache) >= self._CACHE_MAX_SIZE:
                # Evict oldest entries (simple FIFO)
                excess = len(self._description_cache) - self._CACHE_MAX_SIZE + 1
                for key in list(self._description_cache)[:excess]:
                    del self._description_cache[key]
            self._description_cache[cache_key] = result

        return result

    async def _update_structural_context(
        self,
        structural_ctx: str | None,
        page_text: str,
    ) -> str | None:
        """Decide whether to update the running structural context.

        Uses a lightweight text-only LLM call to analyze the current page's
        VLM output and decide if the structural context needs updating.

        Returns the (possibly updated) structural context string, or None.
        """
        if self.context_model_func is None:
            return structural_ctx

        from dlightrag.prompts import STRUCTURAL_CONTEXT_PROMPT

        ctx_display = structural_ctx if structural_ctx else "(empty — first page)"
        user_content = (
            f"Current structural context:\n{ctx_display}\n\nCurrent page content:\n{page_text}"
        )
        messages = [
            {"role": "system", "content": STRUCTURAL_CONTEXT_PROMPT},
            {"role": "user", "content": user_content},
        ]

        try:
            raw = await self.context_model_func(messages=messages)
        except Exception:
            logger.warning("Structural context LLM call failed, keeping existing context")
            return structural_ctx

        # Defensive JSON parsing: try direct, then regex extraction
        parsed = self._parse_context_response(raw)
        if parsed is None:
            return structural_ctx

        action = parsed.get("action", "").lower()
        if action == "update":
            new_ctx = parsed.get("context")
            if new_ctx and isinstance(new_ctx, str):
                return new_ctx
        # "keep" or unrecognized action → return existing
        return structural_ctx

    @staticmethod
    def _parse_context_response(raw: str | None) -> dict | None:
        """Parse JSON from LLM response with fallback to regex extraction."""
        if not raw or not raw.strip():
            return None

        # Attempt 1: direct json.loads
        try:
            data = json.loads(raw)
            if isinstance(data, dict):
                return data
        except (json.JSONDecodeError, TypeError):
            pass

        # Attempt 2: regex extract first {...} blob
        match = re.search(r"\{[^{}]*\}", raw, re.DOTALL)
        if match:
            try:
                data = json.loads(match.group())
                if isinstance(data, dict):
                    return data
            except (json.JSONDecodeError, TypeError):
                pass

        return None
