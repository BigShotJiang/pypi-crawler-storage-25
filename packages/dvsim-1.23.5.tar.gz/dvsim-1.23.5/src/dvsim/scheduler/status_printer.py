# Copyright lowRISC contributors (OpenTitan project).
# Licensed under the Apache License, Version 2.0, see LICENSE for details.
# SPDX-License-Identifier: Apache-2.0

"""Job status printing during a scheduled run."""

import os
import shutil
import sys
import termios
from typing import ClassVar

import enlighten

from dvsim.logging import log

DEFAULT_HEADER = "Q: queued, R: running, P: passed, F: failed, K: killed, T: total"
"""The default header to use for printing the status."""


class StatusPrinter:
    """Dummy Status Printer class for interactive mode.

    When interactive mode is set, dvsim does not print the status. By
    instantiating this dummy class (printing nothing), outer interface stays
    same.
    """

    def __init__(self) -> None:
        """Initialise."""

    def print_header(self) -> None:
        """Initialize / print the header bar.

        The header bar contains an introductory message such as the legend of
        what Q, D, ... mean.
        """

    def init_target(self, target: str, msg: str) -> None:
        """Initialize the status bar for each target."""

    def update_target(
        self,
        target: str,
        hms: str,
        msg: str,
        perc: float,
        running: str,
    ) -> None:
        """Periodically update the status bar for each target.

        Args:
            hms:      Elapsed time in hh:mm:ss.
            target:   The tool flow step.
            msg:      The completion status message (set externally).
            perc:     Percentage of completion.
            running:  What jobs are currently still running.

        """

    def stop(self) -> None:
        """Stop the status header/target printing (but keep the printer context)."""

    def exit(self) -> None:
        """Do cleanup activities before exiting."""


class TtyStatusPrinter(StatusPrinter):
    """Abstraction for printing the current target status onto the console.

    Targets are ASIC tool flow steps such as build, run, cov etc. These steps
    are sequenced by the Scheduler. There may be multiple jobs running in
    parallel in each target. This class provides a mechanism to periodically
    print the completion status of each target onto the terminal. Messages
    printed by this class are rather static in nature - all the necessary
    computations of how the jobs are progressing need to be handled externally.

    The following are the 'fields' accepted by this class:
    """

    # Print elapsed time in bold.
    hms_fmt = "\x1b[1m{hms:9s}\x1b[0m"
    header_fmt = hms_fmt + " [{target:^13s}]: [{msg}]"
    status_fmt = header_fmt + " {perc:3.0f}%  {running}"

    def __init__(self) -> None:
        """Initialise printer."""
        super().__init__()

        # Once a target is complete, we no longer need to update it - we can
        # just skip it. Maintaining this here provides a way to print the status
        # one last time when it reaches 100%. It is much easier to do that here
        # than in the Scheduler class.
        self.target_done = {}

    def print_header(self) -> None:
        """Initialize / print the header bar.

        The header bar contains an introductory message such as the legend of
        what Q, D, ... mean.
        """
        log.info(self.header_fmt.format(hms="", target="legend", msg=DEFAULT_HEADER))

    def init_target(self, target: str, msg: str) -> None:
        """Initialize the status bar for each target."""
        self.target_done[target] = False

    def _trunc_running(self, running: str, width: int = 30) -> str:
        """Truncate the list of running items to a specified width."""
        if len(running) <= width:
            return running
        return running[: width - 3] + "..."

    def update_target(
        self,
        target: str,
        hms: str,
        msg: str,
        perc: float,
        running: str,
    ) -> None:
        """Periodically update the status bar for each target.

        Args:
            hms:      Elapsed time in hh:mm:ss.
            target:   The tool flow step.
            msg:      The completion status message (set externally).
            perc:     Percentage of completion.
            running:  What jobs are currently still running.

        """
        if self.target_done[target]:
            return

        log.info(
            self.status_fmt.format(
                hms=hms,
                target=target,
                msg=msg,
                perc=perc,
                running=self._trunc_running(running),
            ),
        )
        if perc == 100:
            self.target_done[target] = True


class EnlightenStatusPrinter(TtyStatusPrinter):
    """Abstraction for printing status using Enlighten.

    Enlighten is a third party progress bar tool. Documentation:
    https://python-enlighten.readthedocs.io/en/stable/

    Though it offers very fancy progress bar visualization, we stick to a
    simple status bar 'pinned' to the bottom of the screen for each target
    that displays statically, a pre-prepared message. We avoid the progress bar
    visualization since it requires enlighten to perform some computations the
    Scheduler already does. It also helps keep the overhead to a minimum.

    Enlighten does not work if the output of dvsim is redirected to a file, for
    example - it needs to be attached to a TTY enabled stream.
    """

    status_fmt_no_running = TtyStatusPrinter.status_fmt.removesuffix("{running}")
    status_fmt = "{status_msg}{running}"

    def __init__(self) -> None:
        super().__init__()

        # Initialize the status_bars for header and the targets .
        self.manager = enlighten.get_manager()
        self.status_header = None
        self.status_target = {}
        self._stopped = False

    def print_header(self) -> None:
        self.status_header = self.manager.status_bar(
            status_format=self.header_fmt,
            hms="",
            target="legend",
            msg=DEFAULT_HEADER,
        )

    def init_target(self, target, msg) -> None:
        super().init_target(target, msg)
        status_msg = self.status_fmt_no_running.format(hms="", target=target, msg=msg, perc=0.0)
        self.status_target[target] = self.manager.status_bar(
            status_format=self.status_fmt,
            status_msg=status_msg,
            running="",
        )

    def _trunc_running_to_terminal(self, running: str, offset: int) -> str:
        """Truncate the list of running items to match the max terminal width."""
        cols = shutil.get_terminal_size(fallback=(80, 24)).columns
        width = max(30, cols - offset)
        return self._trunc_running(running, width)

    def update_target(self, target, hms, msg, perc, running) -> None:
        if self.target_done[target]:
            return

        status_msg = self.status_fmt_no_running.format(
            hms=hms,
            target=target,
            msg=msg,
            perc=perc,
        )

        offset = len(status_msg)
        running = self._trunc_running_to_terminal(running, offset)

        self.status_target[target].update(status_msg=status_msg, running=running)
        if perc == 100:
            self.target_done[target] = True

    def stop(self) -> None:
        """Stop the status header/target printing (but keep the printer context)."""
        if self.status_header is not None:
            self.status_header.close()
        for target in self.status_target:
            self.status_target[target].close()
        self._stopped = True

    def exit(self) -> None:
        """Do cleanup activities before exiting (closing the manager context)."""
        if not self._stopped:
            self.stop()
        self.manager.stop()
        # Sometimes, exiting via a signal (e.g. Ctrl-C) can cause Enlighten to leave the
        # terminal in some non-raw mode. Just in case, restore regular operation.
        self._restore_terminal()

    def _restore_terminal(self) -> None:
        """Restore regular terminal operation after using Enlighten."""
        # Try open /dev/tty, otherwise fallback to sys.stdin
        try:
            fd = os.open("/dev/tty", os.O_RDWR)
            close_fd = True
        except (OSError, termios.error):
            fd = sys.stdin.fileno()
            close_fd = False

        # By default, the terminal should echo input (ECHO) and run in canonical mode (ICANON).
        # We make this change after all buffered output is transmitted (TCSADRAIN).
        try:
            attrs = termios.tcgetattr(fd)
            control_flag = 3
            attrs[control_flag] |= termios.ECHO | termios.ICANON
            termios.tcsetattr(fd, termios.TCSADRAIN, attrs)
        except termios.error:
            log.debug("Unable to restore terminal attributes safely")

        if close_fd:
            os.close(fd)


class StatusPrinterSingleton:
    """Singleton for the status printer to uniquely refer to 1 instance at a time."""

    _instance: ClassVar[StatusPrinter | None] = None

    @classmethod
    def set(cls, instance: StatusPrinter | None) -> None:
        """Set the stored status printer."""
        cls._instance = instance

    @classmethod
    def get(cls) -> StatusPrinter | None:
        """Get the stored status printer (if it exists)."""
        return cls._instance


def get_status_printer(interactive: bool) -> StatusPrinter:
    """Get the global status printer.

    If stdout is a TTY, then return an instance of EnlightenStatusPrinter, else
    return an instance of StatusPrinter. If the status printer has already been
    created, then returns that instance, regardless of given arguments.
    """
    status_printer = StatusPrinterSingleton.get()
    if status_printer is not None:
        return status_printer

    if interactive:
        status_printer = StatusPrinter()
    elif sys.stdout.isatty():
        status_printer = EnlightenStatusPrinter()
    else:
        status_printer = TtyStatusPrinter()
    StatusPrinterSingleton.set(status_printer)
    return status_printer
