"""
Module for Azure Sentinel
"""

import concurrent.futures
import azure.mgmt.resourcegraph as arg
import re
import requests
import time

from datetime import datetime, timedelta
from os import environ
from azure.identity import DefaultAzureCredential, ClientSecretCredential
from azure.core.credentials import AccessToken, TokenCredential
from azure.mgmt.resource import SubscriptionClient
from azure.mgmt.securityinsight import SecurityInsights
from azure.mgmt.securityinsight.models import TriggerOperator
from azure.mgmt.securityinsight.models import ScheduledAlertRule
from azure.mgmt.securityinsight.models import EventGroupingSettings
from azure.mgmt.securityinsight.models import IncidentConfiguration
from azure.mgmt.securityinsight.models import GroupingConfiguration
from azure.mgmt.securityinsight.models import EntityMapping, FieldMapping, SentinelEntityMapping
from azure.monitor.query import LogsQueryClient, LogsQueryStatus
from datetime import datetime, timedelta, timezone
from azure.core.exceptions import HttpResponseError, ResourceNotFoundError
from droid.abstracts import AbstractPlatform
from droid.color import ColorLogger

class CustomTokenCredential:
    def __init__(self, token: str, expires_on: int):
        self._token = token
        self._expires_on = expires_on

    def get_token(self, *scopes):
        return AccessToken(self._token, self._expires_on)

class SentinelPlatform(AbstractPlatform):

    def __init__(self, parameters: dict, logger_param: dict, export_mssp: bool=False) -> None:

        super().__init__(name="Sentinel")

        self._parameters = parameters
        self._export_mssp = export_mssp
        self._logger_param = logger_param

        self.logger = ColorLogger(__name__, **logger_param)

        self._token = None
        self._token_expiration = None
        self._current_scope = None
        self._client_workspaces = None

        required_parameters = [
            "threshold_operator",
            "threshold_value",
            "suppress_status",
            "incident_status",
            "grouping_reopen",
            "grouping_status",
            "grouping_period",
            "grouping_method",
            "suppress_period",
            "query_frequency",
            "query_period",
            "subscription_id",
            "resource_group",
            "workspace_id",
            "workspace_name",
            "days_ago",
            "timeout"
        ]

        for param in required_parameters:
            if param not in self._parameters:
                raise Exception(f'SentinelPlatform: "{param}" parameter is required.')

        self._workspace_id = self._parameters["workspace_id"]
        self._workspace_name = self._parameters["workspace_name"]
        self._subscription_id = self._parameters["subscription_id"]
        self._resource_group = self._parameters["resource_group"]
        self._days_ago = self._parameters["days_ago"]
        self._threshold_operator = self._parameters["threshold_operator"]
        self._threshold_value = self._parameters["threshold_value"]
        self._query_frequency = self._parameters["query_frequency"]
        self._query_period = self._parameters["query_period"]
        self._suppress_status = self._parameters["suppress_status"]
        self._suppress_period = self._parameters["suppress_period"]
        self._incident_status = self._parameters["incident_status"]
        self._grouping_status = self._parameters["grouping_status"]
        self._grouping_reopen = self._parameters["grouping_reopen"]
        self._grouping_period = self._parameters["grouping_period"]
        self._grouping_method = self._parameters["grouping_method"]
        self._timeout = self._parameters["timeout"]

        if 'app' in (self._parameters["search_auth"] or self._parameters["export_auth"]):
            self._tenant_id = self._parameters["tenant_id"]
            self._client_id = self._parameters["client_id"]
            self._client_secret = self._parameters["client_secret"]

        # Optional fields

        self._alert_prefix = self._parameters.get("alert_prefix", None)
        self._export_list_mssp = self._parameters.get("export_list_mssp", None)
        self._mssp_search_exclude_list = self._parameters.get("mssp_search_exclude_list", None)

        # Conversion callback for re-converting rules with customer-specific filters
        self._convert_rule_callback = None

    def set_convert_rule_callback(self, callback) -> None:
        """Set the callback function for converting rules with customer-specific filters

        Args:
            callback: A function that takes (rule_content, rule_file, platform, customer_filter_dir) 
                     and returns the converted rule
        """
        self._convert_rule_callback = callback

    def mitre_tactics(self, rule_content) -> list:
        """
        Extracts and returns a list of MITRE ATT&CK tactics from the provided rule content.

        Returns:
            A list of of MITRE ATT&CK tactics or None
        """
        tactic_mapping = {
            "reconnaissance": "Reconnaissance",
            "resource-development": "ResourceDevelopment",
            "initial-access": "InitialAccess",
            "execution": "Execution",
            "persistence": "Persistence",
            "privilege-escalation": "PrivilegeEscalation",
            "defense-evasion": "DefenseEvasion",
            "credential-access": "CredentialAccess",
            "discovery": "Discovery",
            "lateral-movement": "LateralMovement",
            "collection": "Collection",
            "command-and-control": "CommandAndControl",
            "exfiltration": "Exfiltration",
            "impact": "Impact",
            "pre-attack": "PreAttack",
            "impair-process-control": "ImpairProcessControl",
            "inhibit-response-function": "InhibitResponseFunction",
        }

        tactics_found = []

        for tag in rule_content.get("tags", []):
            tactic = tag.replace("attack.", "").lower().strip()
            if tactic in tactic_mapping:
                tactics_found.append(tactic_mapping[tactic])

        return tactics_found or None


    def mitre_techniques(self, rule_content) -> list:
        """
        Extracts and returns a list of unique MITRE ATT&CK techniques (excluding sub-techniques) from the provided rule content.

        Returns:
            A list of of MITRE ATT&CK techniques or None
        """
        attack_regex = re.compile(r"attack\.([tT][0-9]{4})(\.[0-9]{3})?")

        mitre_techniques = {
            attack_regex.match(tag).group(1).upper()
            for tag in rule_content.get("tags", [])
            if tag.lower().startswith("attack.") and attack_regex.match(tag)
        }

        return list(mitre_techniques) if mitre_techniques else None
    
    def _acquire_token_from_hook(self, hook_url, scope, tenant_id=None, max_retries=3, retry_delay=5):
        """Acquire an Azure token using a custom hook."""
        if not tenant_id:
            tenant_id = self._tenant_id

        if '{TENANT_ID}' in hook_url:
            hook_url = hook_url.replace('{TENANT_ID}', tenant_id)

        if '{SCOPE}' in hook_url:
            hook_url = hook_url.replace('{SCOPE}', scope)

        # Check if the token is cached, still valid, and for the same scope
        if self._token and datetime.now() < self._token_expiration and self._current_scope == scope:
            self.logger.debug("Using cached token")
            return self._token, self._token_expiration

        headers = {}
        api_key = environ.get('DROID_AZURE_TOKEN_X_API_KEY')
        if api_key:
            headers['X-API-Key'] = api_key

        for attempt in range(max_retries):
            try:
                self.logger.debug(f"Attempting to acquire token from hook (Attempt {attempt + 1}/{max_retries})")
                response = requests.get(hook_url, timeout=120, headers=headers)
                response.raise_for_status()

                # Extract token from response
                token_data = response.json()
                token = token_data.get("access_token")
                if not token:
                    self.logger.error("Access token not found in the response")
                    raise Exception("Access token not found in the response")

                # Set expiration time to 1 hour from now (default if not provided)
                expiration = datetime.now() + timedelta(seconds=3600)
                self._token, self._token_expiration, self._current_scope = token, expiration, scope

                self.logger.debug(f"Successfully acquired token from hook for scope {scope}")
                return token, expiration

            except requests.exceptions.RequestException as e:
                self.logger.error(f"Attempt {attempt + 1} failed: {str(e)}")
                if attempt < max_retries - 1:
                    self.logger.debug(f"Retrying in {retry_delay} seconds...")
                    time.sleep(retry_delay)
                else:
                    self.logger.error("Failed to acquire token after maximum retries")
                    raise Exception(f"Token acquisition failed: {str(e)}")

    def get_credentials(self, scope="management.azure.com"):
        """Get credentials for Azure Sentinel."""
        auth_method = self._parameters.get("search_auth", "default")
        custom_token_hook = environ.get('DROID_AZURE_TOKEN_HOOK')
        self.logger.debug(f"Selected authentication method: {auth_method}")

        # Use custom hook to acquire the token
        if custom_token_hook:
            self.logger.debug("Using custom hook to acquire the Azure token")
            try:
                token, expiration = self._acquire_token_from_hook(custom_token_hook, scope, self._tenant_id)

                # Store token and expiration in instance variables
                self._token = token
                self._expires_on = int(expiration.timestamp())

                # Return the CustomTokenCredential instance
                return CustomTokenCredential(token=token, expires_on=self._expires_on)
            except Exception as e:
                self.logger.error(f"Error acquiring token from hook: {str(e)}")
                raise Exception("Custom token acquisition failed")

        # Use default Azure credentials
        if auth_method == "default":
            self.logger.debug("Using DefaultAzureCredential")
            return DefaultAzureCredential()

        # Use client secret credentials (app registration)
        elif auth_method == "app":
            self.logger.debug("Using ClientSecretCredential")
            return ClientSecretCredential(self._tenant_id, self._client_id, self._client_secret)

        # Unsupported authentication method
        raise Exception(f"Unsupported authentication method: {auth_method}")

    def get_workspaces(self, credential=None, export_mode=False):

        if export_mode:
            graph_query = 'resources | where name contains "SecurityInsights" | extend workspaceId = tostring(properties.workspaceResourceId) | project name, resourceGroup, subscriptionId'
            graph_key = "resourceGroup"
        else:
            graph_query = 'resources | where name contains "SecurityInsights" | extend workspaceId = tostring(properties.workspaceResourceId) | project name, workspaceId'
            graph_key = "workspaceId"

        if not credential:
            credential = self.get_credentials()

        subsClient = SubscriptionClient(credential)
        subsRaw = []
        for sub in subsClient.subscriptions.list():
            subsRaw.append(sub.as_dict())
        subsList = []
        for sub in subsRaw:
            subsList.append(sub.get('subscription_id'))

        argClient = arg.ResourceGraphClient(credential)
        argQueryOptions = arg.models.QueryRequestOptions(result_format="objectArray")

        argQuery = arg.models.QueryRequest(subscriptions=subsList, query=graph_query, options=argQueryOptions)

        results = argClient.resources(argQuery)

        workspace_list = []

        for entry in results.data:
            name = entry.get('name')
            graph_value = entry.get(graph_key)
            workspace_name = name.split('(')[1].split(')')[0]
            if export_mode:
                entry_dict = {
                    "customer": workspace_name,
                    graph_key: graph_value,
                    "subscription_id": entry.get("subscriptionId")
                }
            else:
                entry_dict = {
                    "customer": workspace_name,
                    "workspace_id": graph_value
                }

            workspace_list.append(entry_dict)

        workspace_list = [entry for entry in workspace_list if entry["customer"] not in self._export_list_mssp]

        return workspace_list

    def get_export_list_mssp(self) -> list:

        if self._export_list_mssp:
            self.logger.info("Integrity check for designated customers")
            return self._export_list_mssp
        else:
            self.logger.error("No export_list_mssp found")
            raise

    def mssp_run_sentinel_search(self,
                                 client,
                                 rule_converted,
                                 start_time,
                                 current_time,
                                 customer_info):

        customer = customer_info['customer']
        workspace_id = customer_info['workspace_id']

        results = client.query_resource(workspace_id, rule_converted, timespan=(start_time, current_time), server_timeout=self._timeout)

        result = 0

        for table in results.tables:
            result += len(table.rows)

        return customer, result

    def mssp_run_sentinel_export(
            self, client, rule_content,
            rule_converted, customer_info, alert_rule
            ) -> None:
        customer = customer_info['customer']
        resource_group_name = customer_info['resourceGroup']

        try:
            client.alert_rules.create_or_update(
                        resource_group_name=resource_group_name,
                        workspace_name=customer,
                        rule_id=rule_content['id'],
                        alert_rule=alert_rule
            )
        except Exception as e:
            self.logger.error(f"(MSSP) Could not export the rule. Error: {e}", extra={
                "rule_converted": rule_converted,
                "customer": customer,
                "resource_group_name": resource_group_name,
                "rule_content": rule_content,
                "error": e
            })
            raise

    def run_sentinel_search_mssp_designated(self, rule_converted, rule_file, rule_content):
        """
        Run search for designated customers using export_list_mssp with customer-specific filters.
        """
        current_time = datetime.now(timezone.utc)
        start_time = current_time - timedelta(days=self._days_ago)
        total_result = 0
        
        if not self._export_list_mssp:
            self.logger.error("No export_list_mssp found for MSSP search")
            return total_result
        
        for group, info in self._export_list_mssp.items():
            workspace_id = info.get('workspace_id')
            workspace_name = info.get('workspace_name')
            customer_name = info.get('customer_name')
            customer_filter_dir = info.get('customer_filters_directory')
            
            self.logger.debug(f"Searching rule on workspace {workspace_name} from group id {group}")
            
            # Re-convert rule with customer-specific filters if available
            customer_rule_converted = rule_converted
            if customer_filter_dir and self._convert_rule_callback:
                self.logger.info(
                    f"Re-converting rule with customer-specific filters for '{customer_name}' from {customer_filter_dir}"
                )
                try:
                    customer_rule_converted = self._convert_rule_callback(
                        rule_content, rule_file, self, customer_filter_dir
                    )
                    self.logger.debug(f"Successfully re-converted rule for customer '{customer_name}': {customer_rule_converted}")
                except Exception as e:
                    self.logger.warning(
                        f"Could not re-convert rule for customer '{customer_name}': {e}. Using default conversion."
                    )
            
            try:
                # Get credentials for the specific tenant
                credential = self.get_credentials(scope="api.loganalytics.io")
                client = LogsQueryClient(credential)
                
                self.logger.debug(f"Searching rule {rule_file} for '{customer_name or workspace_name}' with query: {customer_rule_converted}")
                
                results = client.query_workspace(
                    workspace_id,
                    customer_rule_converted,
                    timespan=(start_time, current_time),
                    server_timeout=self._timeout
                )
                
                if results.status == LogsQueryStatus.SUCCESS:
                    result = sum(len(table.rows) for table in results.tables)
                    if result > 0:
                        self.logger.warning(f"(Sentinel MSSP) Results for {customer_name or workspace_name}: {result}, {rule_file}")
                    else:
                        self.logger.info(f"(Sentinel MSSP) No results for {customer_name or workspace_name}, {rule_file}")
                    total_result += result
                elif results.status == LogsQueryStatus.PARTIAL:
                    self.logger.error(f"Rule {rule_file} partial error for {customer_name or workspace_name}: {results.partial_error}")
                    
            except Exception as e:
                self.logger.error(f"Could not search rule {rule_file} for workspace {workspace_name}: {e}")
        
        return total_result

    def run_sentinel_search(self, rule_converted, rule_file, mssp_mode):

        current_time = datetime.now(timezone.utc)
        start_time = current_time - timedelta(days=self._days_ago)

        try:
            if mssp_mode:
                results = {}

                # Check if client_workspaces has already been acquired
                if self._client_workspaces is None:
                    self.logger.debug("Fetching client workspaces...")
                    self._client_workspaces = self.get_workspaces(self.get_credentials())
                    self.logger.debug(f"Fetched client workspaces: {self._client_workspaces}")

                client = LogsQueryClient(self.get_credentials(scope="api.loganalytics.io"))

                with concurrent.futures.ThreadPoolExecutor(max_workers=5) as executor:
                    futures = {executor.submit(self.mssp_run_sentinel_search,
                                            client,
                                            rule_converted,
                                            start_time,
                                            current_time,
                                            customer_info): customer_info for customer_info in self._client_workspaces}

                    for future in concurrent.futures.as_completed(futures):
                        customer_info = futures[future]
                        customer, result = future.result()
                        results[customer] = result

                # Process
                total_result = 0

                for customer, result in results.items():
                    if result > 0:
                        self.logger.warning(f"(Sentinel MSSP) Results for {customer}: {result}, {rule_file}")
                    else:
                        self.logger.info(f"(Sentinel MSSP) No results for {customer}, {rule_file}")
                    total_result += result

                return total_result

            else:
                self.logger.debug(f"Querying the workspace {self._workspace_id}")

                try:
                    self.logger.debug("Creating the client instance")
                    client = LogsQueryClient(self.get_credentials())
                    self.logger.debug("Successfully created the client instance")
                except HttpResponseError as e:
                    self.logger.error(f"Error while connecting to Azure error: {e}")

                self.logger.debug(f"Searching rule {rule_file} with query: {rule_converted}")
                
                results = client.query_workspace(self._workspace_id,
                                                rule_converted,
                                                timespan=(start_time, current_time),
                                                server_timeout=self._timeout)

            if results.status == LogsQueryStatus.PARTIAL:
                error = results.partial_error
                data = results.partial_data
                self.logger.error(f"Rule {rule_file} partial error in query: {error}")

            elif results.status == LogsQueryStatus.SUCCESS:
                total_result = 0

                for table in results.tables:
                    total_result += len(table.rows)

                return total_result

        except HttpResponseError as e:
            self.logger.error(f"Rule {rule_file} error: {e}")

        except Exception as e:
            self.logger.error(f"Rule {rule_file} error: {e}")

        except HttpResponseError as e:
            self.logger.error(f"Rule {rule_file} error: {e}")

        except Exception as e:
            self.logger.error(f"Rule {rule_file} error: {e}")

    def get_rule_mssp(self, rule_content, rule_file,
                      tenant_id, subscription_id, resource_group_name,
                      workspace_name):
        """Retrieve a scheduled alert rule in Sentinel in MSSP mode
        """

        self._tenant_id = tenant_id
        credential = self.get_credentials()

        client = SecurityInsights(credential, subscription_id)

        try:
            rule = client.alert_rules.get(
                resource_group_name=resource_group_name,
                workspace_name=workspace_name,
                rule_id=rule_content['id']
            )
            self.logger.info(f"Successfully retrieved the rule {rule_file} for {workspace_name}")

            if rule:
                return rule
            else:
                return None

        except ResourceNotFoundError:
            return None

        except Exception as e:
            self.logger.error(f"Could not retrieve the rule {rule_file} in {workspace_name}")
            raise

    def get_rule(self, rule_content, rule_file):
        """Retrieve a scheduled alert rule in Sentinel
        """
        credential = self.get_credentials()

        client = SecurityInsights(credential, self._subscription_id)

        try:
            rule = client.alert_rules.get(
                resource_group_name=self._resource_group,
                workspace_name=self._workspace_name,
                rule_id=rule_content['id']
            )
            self.logger.info(f"Successfully retrieved the rule {rule_file}")

            if rule:
                return rule
            else:
                return None

        except ResourceNotFoundError:
            return None

        except Exception as e:
            self.logger.error(f"Could not retrieve the rule {rule_file}")
            raise

    def remove_rule(self, rule_content, rule_converted, rule_file):
        """Remove an analytic rule in Sentinel
        Remove a scheduled alert rule in Sentinel
        """
        if self._export_mssp:
            if self._export_list_mssp:
                error = False
                self.logger.info("Exporting deletion to designated customers")
                for group, info in self._export_list_mssp.items():
                    workspace_name = info['workspace_name']
                    self._tenant_id = info['tenant_id']
                    resource_group_name = info['resource_group_name']
                    subscription_id = info['subscription_id']

                    self.logger.debug(f"Exporting deletion to {workspace_name} from group id {group}")

                    credential = self.get_credentials()

                    client = SecurityInsights(credential, subscription_id)

                    try:
                        client.alert_rules.delete(
                            resource_group_name=resource_group_name,
                            workspace_name=workspace_name,
                            rule_id=rule_content['id']
                        )
                        self.logger.info(f"Successfully deleted the rule {rule_file} from {workspace_name}")
                    except Exception as e:
                        self.logger.error(f"Failed to delete the rule {rule_file} from {workspace_name} - error: {e}")
                        error = True
                if error:
                    raise
            else:
                self.logger.error("Export list not found. Please provide the list of designated customers")
                raise
        else:
            credential = self.get_credentials()
            client = SecurityInsights(credential, self._subscription_id)
            try:
                client.alert_rules.delete(
                    resource_group_name=self._resource_group,
                    workspace_name=self._workspace_name,
                    rule_id=rule_content['id']
                )
                self.logger.info(f"Successfully deleted the rule {rule_file}", extra={"rule_file": rule_file, "rule_converted": rule_converted, "rule_content": rule_content})
            except Exception as e:
                self.logger.error(f"Could not delete the rule {rule_file}", extra={"rule_file": rule_file, "rule_converted": rule_converted, "rule_content": rule_content, "error": e})
                raise


    def create_rule(self, rule_content, rule_converted, rule_file):
        """Create an analytic rule in Sentinel
        Create a scheduled alert rule in Sentinel
        """

        # Handling the display name
        if self._alert_prefix:
            display_name = self._alert_prefix + " " + rule_content['title']
        else:
            display_name = rule_content['title']

        # Handling the status of the alert

        if rule_content.get('custom', {}).get('disabled') is True:
            enabled = False
            self.logger.info(f"Successfully disabled the rule {rule_file}")
        else:
            enabled = True

        # Handling the entities
        if rule_content.get('custom', {}).get('entity_mappings'):
            entity_mappings = []
            for mapping in rule_content['custom']['entity_mappings']:
                field_mappings = [FieldMapping(identifier=field['identifier'], column_name=field['column_name'])
                                    for field in mapping['field_mappings']]
                entity_mappings.append(EntityMapping(entity_type=mapping['entity_type'], field_mappings=field_mappings))
        else:
            entity_mappings = None

        # Handling the sentinel entities

        if rule_content.get('custom', {}).get('sentinel_entities'):
            sentinel_entity_mappings = [
                SentinelEntityMapping(column_name=col_name)
                for col_name in rule_content['custom']['sentinel_entities']
            ]
        else:
            sentinel_entity_mappings = None

        # Handling the severity
        if rule_content['level'] == 'critical':
            severity = 'high'
        else:
            severity = rule_content['level']

        if self._suppress_status == True:
            suppression_enabled = True
            suppression_duration = timedelta(hours=self._suppress_period)
        else:
            suppression_enabled = False
            suppression_duration = None

        if self._incident_status == True:
            create_incident = True
            if self._grouping_status:
                grouping_config = GroupingConfiguration(
                    enabled=True,
                    reopen_closed_incident=self._grouping_reopen,
                    lookback_duration=timedelta(hours=self._grouping_period),
                    matching_method=self._grouping_method
                )
                if rule_content.get("custom", {}).get("grouping_period"):
                    grouping_config.lookback_duration = timedelta(hours=rule_content["custom"]["grouping_period"])
                if rule_content.get("custom", {}).get("grouping_matching_entities"):
                    grouping_config.matching_method = "Selected"
                    grouping_config.group_by_entities = rule_content["custom"]["grouping_matching_entities"]
            else:
                grouping_config = None
        else:
            create_incident = False
            if self._grouping_status:
                grouping_config = GroupingConfiguration(
                    enabled=True,
                    reopen_closed_incident=self._grouping_reopen,
                    lookback_duration=timedelta(hours=self._grouping_period),
                    matching_method=self._grouping_method
                )
                if rule_content.get("custom", {}).get("grouping_period"):
                    grouping_config.lookback_duration = timedelta(hours=rule_content["custom"]["grouping_period"])
                if rule_content.get("custom", {}).get("grouping_matching_entities"):
                    grouping_config.matching_method = "Selected"
                    grouping_config.group_by_entities = rule_content["custom"]["grouping_matching_entities"]
            else:
                grouping_config = None

        alert_rule = ScheduledAlertRule(
            query=rule_converted,
            description=rule_content['description'],
            display_name=display_name,
            severity=severity,
            query_frequency=timedelta(hours=self._query_frequency),
            query_period=timedelta(hours=self._query_period),
            trigger_operator=TriggerOperator(self._threshold_operator),
            trigger_threshold=self._threshold_value,
            enabled=enabled,
            suppression_duration=suppression_duration,
            suppression_enabled=suppression_enabled,
            event_grouping_settings=EventGroupingSettings(aggregation_kind="SingleAlert"),
            incident_configuration=IncidentConfiguration(create_incident=create_incident, grouping_configuration=grouping_config),
            tactics=self.mitre_tactics(rule_content),
            entity_mappings=entity_mappings,
            sentinel_entities_mappings=sentinel_entity_mappings,
            techniques=self.mitre_techniques(rule_content)
        )

        if rule_content.get("custom", {}).get("query_frequency"):
            alert_rule.query_frequency = timedelta(hours=rule_content["custom"]["query_frequency"])

        if rule_content.get("custom", {}).get("query_period"):
            alert_rule.query_period = timedelta(hours=rule_content["custom"]["query_period"])

        if self._export_mssp:
            if self._export_list_mssp:
                error = False
                self.logger.info("Exporting to designated customers")
                for group, info in self._export_list_mssp.items():

                    workspace_name = info['workspace_name']
                    self._tenant_id = info['tenant_id']
                    resource_group_name = info['resource_group_name']
                    subscription_id = info['subscription_id']
                    customer_name = info.get('customer_name')
                    customer_filter_dir = info.get('customer_filters_directory')

                    self.logger.debug(f"Exporting to {workspace_name} from group id {group}")

                    # Check for customer-specific filters and re-convert rule if needed
                    customer_rule_converted = rule_converted
                    customer_alert_rule = alert_rule

                    if customer_filter_dir and self._convert_rule_callback:
                        self.logger.info(
                            f"Re-converting rule with customer-specific filters for '{customer_name}' from {customer_filter_dir}"
                        )
                        try:
                            customer_rule_converted = self._convert_rule_callback(
                                rule_content, rule_file, self, customer_filter_dir
                            )
                            # Create a copy of alert_rule with the customer-specific query
                            customer_alert_rule = ScheduledAlertRule(
                                query=customer_rule_converted,
                                description=rule_content['description'],
                                display_name=display_name,
                                severity=severity,
                                query_frequency=alert_rule.query_frequency,
                                query_period=alert_rule.query_period,
                                trigger_operator=alert_rule.trigger_operator,
                                trigger_threshold=alert_rule.trigger_threshold,
                                enabled=alert_rule.enabled,
                                suppression_duration=alert_rule.suppression_duration,
                                suppression_enabled=alert_rule.suppression_enabled,
                                event_grouping_settings=alert_rule.event_grouping_settings,
                                incident_configuration=alert_rule.incident_configuration,
                                tactics=alert_rule.tactics,
                                entity_mappings=alert_rule.entity_mappings,
                                sentinel_entities_mappings=alert_rule.sentinel_entities_mappings,
                                techniques=alert_rule.techniques
                            )
                            self.logger.debug(
                                f"Successfully re-converted rule for customer '{customer_name}': {customer_rule_converted}"
                            )
                        except Exception as e:
                            self.logger.warning(
                                f"Could not re-convert rule for customer '{customer_name}': {e}. Using default conversion."
                            )

                    credential = self.get_credentials()

                    # Create a new SecurityInsights client for the target subscription
                    client = SecurityInsights(credential, subscription_id)

                    self.logger.debug(f"Exporting rule {rule_file} to '{customer_name or workspace_name}' with query: {customer_rule_converted}")
                    
                    try:
                        client.alert_rules.create_or_update(
                            resource_group_name=resource_group_name,
                            workspace_name=workspace_name,
                            rule_id=rule_content['id'],
                            alert_rule=customer_alert_rule
                        )
                        self.logger.info(f"Successfully exported the rule {rule_file} to {workspace_name}")
                    except Exception as e:
                        self.logger.error(f"Failed to export the rule {rule_file} to {workspace_name} - error: {e}")
                        error = True
                if error:
                    raise
            else:
                self.logger.error("Export list not found. Please provide the list of designated customers")
                raise
        else:
            credential = self.get_credentials()
            client = SecurityInsights(credential, self._subscription_id)
            
            self.logger.debug(f"Exporting rule {rule_file} with query: {rule_converted}")
            
            try:
                client.alert_rules.create_or_update(
                    resource_group_name=self._resource_group,
                    workspace_name=self._workspace_name,
                    rule_id=rule_content['id'],
                    alert_rule=alert_rule
                )
                self.logger.info(f"Successfully exported the rule {rule_file}", extra={"rule_file": rule_file, "rule_converted": rule_converted, "rule_content": rule_content})
            except Exception as e:
                self.logger.error(f"Could not export the rule {rule_file} - error: {e}", extra={"rule_file": rule_file, "rule_converted": rule_converted, "rule_content": rule_content, "error": e})
                raise
