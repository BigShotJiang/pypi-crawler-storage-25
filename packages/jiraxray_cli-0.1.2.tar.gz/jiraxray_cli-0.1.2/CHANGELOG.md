# Changelog

All notable changes to `jiraxray-cli` are documented here.

## v0.1.2 - 2026-04-27

First officially published PyPI package for `jiraxray-cli`.

This release is still beta software. The command surface is usable for
migration planning, Xray/Jira operations, automation workflows, and agent
discovery, but live production workflows should still be reviewed before
enabling writes against Jira or Xray Cloud.

### Added

- PyPI package published as `jiraxray-cli` with the `jiraxray-cli` console
  command.
- MIT license metadata, package author metadata for Jay Sisley, and project
  links for the homepage, repository, issues, and documentation.
- Xray Cloud REST v2 authentication using client id/client secret bearer-token
  flow.
- Xray Cloud endpoint selection through `XRAY_REGION`, `XRAY_BASE_URL`, and
  environment-only secret handling.
- Optional Jira Cloud configuration through `JIRA_BASE_URL`, `JIRA_EMAIL`,
  `JIRA_API_TOKEN`, and `JIRA_PROJECT_KEY`.
- Human and JSON command discovery through `commands` and `command`.
- `diagnose` and `diagnose --live` commands for local configuration and live
  Jira/Xray connectivity checks.
- Zephyr Squad Excel inspection, mapping initialization, mapping validation,
  Xray import-plan transform, migration validation, and Markdown preview
  workflows.
- AI setup command, `init`, for Codex, Claude Code, GitHub Copilot, or all
  supported agent tools.
- Generated token-efficient agent skills that point to focused reference files.
- Local automation suite commands for initializing, listing, validating, and
  dry-running `.jiraxray-cli/workflows/*.yaml` workflows.
- Result import validation and sync-library workflows for reviewed local test
  definitions.
- Xray GraphQL operations for project discovery, test search/create, manual
  step replacement, test set association, test plan association, and test
  execution creation.
- Jira REST v3 operations for issue creation, issue details, issue summaries,
  and issue linking.
- Xray execution and test-run workflows for creating executions, adding tests,
  polling test runs, and uploading test-run evidence.
- Xray REST v2 execution result import commands for Xray JSON, JUnit, Cucumber,
  NUnit, xUnit, TestNG, and Robot reports.
- Xray REST v2 asynchronous bulk test import and import-status commands with
  local validation for JSON payloads and the documented 1000-test request limit.
- Shared retry handling for Xray rate limits and transient server responses.
- Offline unit tests that pin Jira and Xray API operation shapes.
- Package build, wheel/source-distribution smoke tests, PyPI Trusted
  Publishing, GitHub Release artifact publishing, and GHCR image publishing.

### Changed

- User documentation now documents PyPI as the only installation source.
- Package classifier changed to beta.
- Release automation now skips PyPI upload when a version already exists, then
  updates the GitHub Release and GHCR image for retry-safe release runs.

### Known Gaps

- Zephyr import plans are not yet converted into final Xray bulk-import JSON.
  The CLI can queue Xray bulk import JSON, but the Zephyr-to-bulk payload bridge
  is intentionally held until the exact authenticated Xray payload shape is
  confirmed.
- Live Xray smoke tests require credentials and are not enabled by default.
- Search pagination beyond the current single GraphQL request is not yet
  implemented.
- The CLI is beta and should be used with reviewed dry-runs before write-heavy
  production migrations.

## v0.1.1 - 2026-04-27

Publishing validation release.

### Changed

- Publish the public Python package to PyPI as `jiraxray-cli`.
- Use PyPI Trusted Publishing from the tag release workflow.

## v0.1.0 - 2026-04-25

Initial release of the Jira Xray CLI foundation for QA testers, automation
testers, QA engineers, scripts, and AI agents.

### Added

- Installable Python package with `jiraxray-cli`
  console scripts.
- Xray Cloud authentication using REST v2 client id/client secret bearer-token
  flow.
- Xray Cloud region/profile handling with environment-only secrets.
- Human and JSON command discovery through `commands` and `command`.
- AI setup command, `init`, for Codex, Claude Code, and GitHub Copilot project
  guidance.
- Xray GraphQL operations for project discovery, test search/create, manual
  step replacement, test set association, test plan association, and test
  execution creation.
- Xray REST v2 execution result import commands for Xray JSON, JUnit, Cucumber,
  NUnit, xUnit, TestNG, and Robot results.
- Xray REST v2 asynchronous bulk test import and import-status commands.
- Zephyr Squad Excel inspection, mapping, transform, validation, and Markdown
  preview workflows for migration planning.
- Local deterministic workflow suites with dry-run support.
- Sync-library workflow for reviewed local JSON/YAML test definitions.
- Shared retry handling for Xray rate limits and transient server responses.
- Offline unit tests pinning Xray API operation shapes to the official docs.
- Package build, wheel/sdist smoke tests, PyPI publishing, GitHub Release
  publishing, and GHCR container publishing workflow.

### Distribution

- GitHub Release artifacts:
  - `jiraxray_cli-0.1.0-py3-none-any.whl`
  - `jiraxray_cli-0.1.0.tar.gz`
- PyPI package:
  - `jiraxray-cli`
- GHCR container package:
  - `ghcr.io/reignonu13/jiraxray-cli:0.1.0`

### Known Gaps

- Zephyr import plans are not yet converted into the final Xray bulk import JSON
  payload. The CLI can queue Xray bulk import JSON, but the Zephyr-to-bulk
  payload bridge is intentionally held until the exact authenticated Xray payload
  shape is confirmed.
- Live Xray smoke tests require credentials and are not enabled by default.
- Search pagination beyond the current single GraphQL request is not yet
  implemented.
