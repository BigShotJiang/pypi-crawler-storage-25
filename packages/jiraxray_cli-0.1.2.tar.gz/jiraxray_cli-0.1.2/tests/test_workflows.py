from pathlib import Path

from jiraxray_cli.workflows.runner import (
    dry_run_workflow,
    load_workflow,
    resolved_workflow_steps,
    validate_workflow,
    write_example_workflow,
)


def test_example_workflow_validates_and_renders_inputs(tmp_path: Path) -> None:
    write_example_workflow(tmp_path)
    workflow = load_workflow(tmp_path, "example-discovery")

    warnings = validate_workflow(workflow)
    dry_run = dry_run_workflow(workflow, {"project_key": "CALC"})

    assert warnings == []
    assert dry_run["steps"][0]["args"]["project_key"] == "CALC"
    assert "CALC" in dry_run["steps"][1]["args"]["jql"]


def test_resolved_workflow_steps_match_dry_run(tmp_path: Path) -> None:
    write_example_workflow(tmp_path)
    workflow = load_workflow(tmp_path, "example-discovery")

    steps = resolved_workflow_steps(workflow, {"project_key": "OPS"})

    assert steps == dry_run_workflow(workflow, {"project_key": "OPS"})["steps"]
