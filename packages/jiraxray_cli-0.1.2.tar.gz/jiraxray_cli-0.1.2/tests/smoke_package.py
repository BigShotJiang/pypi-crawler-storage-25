"""Smoke test an installed jiraxray-cli distribution."""

from __future__ import annotations

import json
import shutil
import subprocess

import jiraxray_cli


def main() -> None:
    """Verify import and console scripts from an installed distribution."""

    assert jiraxray_cli.__version__
    executable = shutil.which("jiraxray-cli")
    assert executable is not None, "Missing console script: jiraxray-cli"
    version = subprocess.run(
        [executable, "--version"],
        check=True,
        capture_output=True,
        text=True,
    )
    assert version.stdout.strip() == jiraxray_cli.__version__

    manifest = subprocess.run(
        ["jiraxray-cli", "commands", "--json"],
        check=True,
        capture_output=True,
        text=True,
    )
    payload = json.loads(manifest.stdout)
    assert payload["ok"] is True
    assert payload["command"] == "commands"
    assert payload["data"]["commands"]


if __name__ == "__main__":
    main()
