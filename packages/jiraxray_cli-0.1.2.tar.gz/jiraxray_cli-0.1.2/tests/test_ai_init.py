from pathlib import Path

import pytest

from jiraxray_cli.ai_init import init_result_data, run_init


def test_init_generates_codex_layout(tmp_path: Path) -> None:
    result = run_init(tmp_path, "codex", "payments regression suite")

    assert (tmp_path / "AGENTS.md").exists()
    assert (tmp_path / ".agents/skills/jiraxray-cli/SKILL.md").exists()
    assert (tmp_path / ".agents/skills/jiraxray-cli/references/cli-workflows.md").exists()
    assert (tmp_path / ".agents/skills/xray-solution-maintainer/SKILL.md").exists()
    assert (
        tmp_path / ".agents/skills/xray-solution-maintainer/references/solution-maintenance.md"
    ).exists()
    assert (
        tmp_path / ".agents/skills/xray-test-library-manager/references/test-library.md"
    ).exists()
    assert (tmp_path / ".codex/agents/xray-test-engineer.toml").exists()
    assert result.tools == ["codex"]


def test_init_generates_claude_layout(tmp_path: Path) -> None:
    run_init(tmp_path, "claude", "claims automation")

    assert (tmp_path / "CLAUDE.md").exists()
    assert (tmp_path / ".claude/skills/xray-solution-alignment/SKILL.md").exists()
    assert (tmp_path / ".claude/agents/xray-solution-auditor.md").exists()


def test_init_generates_copilot_layout(tmp_path: Path) -> None:
    run_init(tmp_path, "copilot", "portal smoke tests")

    assert (tmp_path / ".github/copilot-instructions.md").exists()
    assert (tmp_path / ".github/skills/zephyr-migration-analyst/SKILL.md").exists()
    assert (tmp_path / ".github/skills/xray-import-reviewer/SKILL.md").exists()
    assert (tmp_path / ".github/prompts/xray-library-sync.prompt.md").exists()
    assert (tmp_path / ".github/agents/xray-test-engineer.agent.md").exists()


def test_init_generates_all_layouts(tmp_path: Path) -> None:
    result = run_init(tmp_path, "all", "full QA solution")

    assert result.tools == ["codex", "claude", "copilot"]
    assert len(result.files) > 20
    data = init_result_data(result, "full QA solution")
    assert data["targetRoot"] == str(tmp_path.resolve())
    assert data["suiteName"] == "full QA solution"
    assert data["next"]


def test_init_refuses_overwrite_without_force(tmp_path: Path) -> None:
    run_init(tmp_path, "codex", "suite")

    with pytest.raises(FileExistsError):
        run_init(tmp_path, "codex", "suite")


def test_init_overwrites_with_force(tmp_path: Path) -> None:
    run_init(tmp_path, "codex", "suite")

    result = run_init(tmp_path, "codex", "suite", force=True)

    assert result.files
