import httpx

from jiraxray_cli.clients.http import request_with_retries


def response(status_code: int, url: str, headers: dict[str, str] | None = None) -> httpx.Response:
    return httpx.Response(
        status_code,
        json={"status": status_code},
        headers=headers,
        request=httpx.Request("GET", url),
    )


def test_request_retries_rate_limited_response_with_retry_after() -> None:
    url = "https://xray.cloud.getxray.app/api/v2/graphql"
    responses = [
        response(429, url, {"Retry-After": "2"}),
        response(200, url),
    ]
    sleeps: list[float] = []

    def sender(sent_url: str, **kwargs: object) -> httpx.Response:
        assert sent_url == url
        assert kwargs == {"timeout": 30.0}
        return responses.pop(0)

    result = request_with_retries(
        sender,
        url,
        request_kwargs={"timeout": 30.0},
        sleep=sleeps.append,
    )

    assert result.status_code == 200
    assert sleeps == [2.0]


def test_request_retries_transient_server_response_with_default_delay() -> None:
    url = "https://xray.cloud.getxray.app/api/v2/import/execution"
    responses = [
        response(503, url),
        response(200, url),
    ]
    sleeps: list[float] = []

    def sender(sent_url: str, **kwargs: object) -> httpx.Response:
        assert sent_url == url
        return responses.pop(0)

    result = request_with_retries(sender, url, sleep=sleeps.append)

    assert result.status_code == 200
    assert sleeps == [1.0]


def test_request_does_not_retry_non_transient_client_error() -> None:
    url = "https://xray.cloud.getxray.app/api/v2/import/test/bulk"
    calls = 0

    def sender(sent_url: str, **kwargs: object) -> httpx.Response:
        nonlocal calls
        assert sent_url == url
        calls += 1
        return response(400, url)

    result = request_with_retries(sender, url, sleep=lambda _: None)

    assert result.status_code == 400
    assert calls == 1
