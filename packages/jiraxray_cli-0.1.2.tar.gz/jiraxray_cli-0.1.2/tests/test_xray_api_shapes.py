from pathlib import Path
from typing import cast

import httpx
import pytest

from jiraxray_cli.clients.auth import XrayAuthClient
from jiraxray_cli.clients.graphql import XrayGraphQLClient
from jiraxray_cli.clients.jira import JiraRestClient
from jiraxray_cli.clients.rest import (
    BULK_TEST_IMPORT_ENDPOINT,
    IMPORT_ENDPOINTS,
    XrayRestClient,
)
from jiraxray_cli.config import XrayConfig
from jiraxray_cli.models import JsonObject, StepInput
from jiraxray_cli.service import XrayService


def config(base_url: str = "https://xray.cloud.getxray.app") -> XrayConfig:
    return XrayConfig(
        client_id="client",
        client_secret="secret",
        base_url=base_url,
        region="global",
        profile_path=Path("profile.json"),
    )


class FakeGraphQL:
    """Capture GraphQL operations without making live Xray calls."""

    def __init__(self) -> None:
        self.calls: list[tuple[str, JsonObject | None]] = []

    def execute(self, query: str, variables: JsonObject | None = None) -> JsonObject:
        self.calls.append((query, variables))
        return {"data": {"ok": True}}


class SequenceGraphQL:
    """Return queued GraphQL responses while capturing calls."""

    def __init__(self, responses: list[JsonObject]) -> None:
        self.responses = responses
        self.calls: list[tuple[str, JsonObject | None]] = []

    def execute(self, query: str, variables: JsonObject | None = None) -> JsonObject:
        self.calls.append((query, variables))
        return self.responses.pop(0)


class FakeXrayService(XrayService):
    """Expose a fake GraphQL client for operation shape tests."""

    def __init__(self, fake: FakeGraphQL) -> None:
        super().__init__(config())
        self.fake = fake

    def _graphql(self) -> XrayGraphQLClient:
        return cast(XrayGraphQLClient, self.fake)


def test_discover_project_uses_official_project_settings_shape() -> None:
    fake = FakeGraphQL()
    service = FakeXrayService(fake)

    service.discover_project("QA")

    query, variables = fake.calls[0]
    assert "projectIdOrKey" in query
    assert "testTypeSettings" in query
    assert variables == {"projectIdOrKey": "QA"}


def test_replace_steps_uses_official_step_mutation_shapes() -> None:
    fake = FakeGraphQL()
    service = FakeXrayService(fake)

    service.replace_steps("12345", [StepInput(action="Open page", result="Page opens")])

    remove_query, remove_variables = fake.calls[0]
    add_query, add_variables = fake.calls[1]
    assert "removeAllTestSteps(issueId: $issueId)" in remove_query
    assert "{ warnings }" not in remove_query
    assert "addTestStep(issueId: $issueId, step: $step)" in add_query
    assert "step {" not in add_query
    assert remove_variables == {"issueId": "12345"}
    assert add_variables == {
        "issueId": "12345",
        "step": {"action": "Open page", "data": None, "result": "Page opens"},
    }


def test_core_graphql_operations_match_official_schema() -> None:
    fake = FakeGraphQL()
    service = FakeXrayService(fake)

    service.search_tests("project = QA", limit=250)
    service.create_test("QA", "User signs in")
    service.add_tests_to_set("10001", ["10002"])
    service.add_tests_to_plan("10003", ["10002"])
    service.create_execution("QA", "Regression execution", ["10002"])
    service.add_tests_to_execution("10004", ["10002"])
    service.get_test_run("10004", "10002")

    search_query, search_variables = fake.calls[0]
    create_query, create_variables = fake.calls[1]
    set_query, set_variables = fake.calls[2]
    plan_query, plan_variables = fake.calls[3]
    execution_query, execution_variables = fake.calls[4]
    execution_add_query, execution_add_variables = fake.calls[5]
    run_query, run_variables = fake.calls[6]

    assert "getTests(jql: $jql, limit: $limit)" in search_query
    assert search_variables == {"jql": "project = QA", "limit": 100}
    assert "createTest(testType: $testType, jira: $jira)" in create_query
    assert create_variables == {
        "testType": {"name": "Manual"},
        "jira": {"fields": {"summary": "User signs in", "project": {"key": "QA"}}},
    }
    assert "addTestsToTestSet(issueId: $issueId, testIssueIds: $testIssueIds)" in set_query
    assert "addedTests" in set_query
    assert "warning" in set_query
    assert set_variables == {"issueId": "10001", "testIssueIds": ["10002"]}
    assert "addTestsToTestPlan(issueId: $issueId, testIssueIds: $testIssueIds)" in plan_query
    assert "addedTests" in plan_query
    assert "warning" in plan_query
    assert plan_variables == {"issueId": "10003", "testIssueIds": ["10002"]}
    assert "createTestExecution(testIssueIds: $testIssueIds, jira: $jira)" in execution_query
    assert "testExecution" in execution_query
    assert "warnings" in execution_query
    assert execution_variables == {
        "testIssueIds": ["10002"],
        "jira": {"fields": {"summary": "Regression execution", "project": {"key": "QA"}}},
    }
    assert "addTestsToTestExecution(issueId: $issueId, testIssueIds: $testIssueIds)" in (
        execution_add_query
    )
    assert execution_add_variables == {"issueId": "10004", "testIssueIds": ["10002"]}
    assert "getTestRuns(" in run_query
    assert "status { name }" in run_query
    assert run_variables == {
        "testExecIssueIds": ["10004"],
        "testIssueIds": ["10002"],
        "limit": 1,
    }


def test_validate_xray_connection_uses_lightweight_query() -> None:
    fake = FakeGraphQL()
    service = FakeXrayService(fake)

    service.validate_xray_connection()

    query, variables = fake.calls[0]
    assert "getTests(limit: 1)" in query
    assert variables is None


def test_upload_evidence_uses_graphql_attachment_shape(tmp_path: Path) -> None:
    fake = FakeGraphQL()
    service = FakeXrayService(fake)
    evidence = tmp_path / "screenshot.png"
    evidence.write_bytes(b"png-bytes")

    service.upload_evidence("run-1", [evidence])

    query, variables = fake.calls[0]
    assert "addEvidenceToTestRun(id: $id, evidence: $evidence)" in query
    assert variables["id"] == "run-1"
    payload = variables["evidence"][0]
    assert payload["filename"] == "screenshot.png"
    assert payload["mimeType"] == "image/png"
    assert payload["data"] == "cG5nLWJ5dGVz"


def test_get_test_run_wait_polls_until_run_exists(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    fake = SequenceGraphQL(
        [
            {"data": {"getTestRuns": {"results": []}}},
            {"data": {"getTestRuns": {"results": [{"id": "run-1"}]}}},
        ]
    )
    service = FakeXrayService(cast(FakeGraphQL, fake))
    sleeps: list[float] = []
    monkeypatch.setattr("jiraxray_cli.service.time.sleep", sleeps.append)

    result = service.get_test_run("10004", "10002", wait=True, attempts=3, delay_seconds=0.25)

    assert result == {"data": {"getTestRuns": {"results": [{"id": "run-1"}]}}}
    assert len(fake.calls) == 2
    assert sleeps == [0.25]


def test_auth_uses_official_rest_v2_authenticate_endpoint(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    calls: list[tuple[str, dict[str, object]]] = []

    def fake_post(url: str, **kwargs: object) -> httpx.Response:
        calls.append((url, dict(kwargs)))
        return httpx.Response(200, json="token-value", request=httpx.Request("POST", url))

    monkeypatch.setattr(httpx, "post", fake_post)

    token = XrayAuthClient(config("https://eu.xray.cloud.getxray.app")).token()

    assert token == "token-value"
    assert calls == [
        (
            "https://eu.xray.cloud.getxray.app/api/v2/authenticate",
            {"json": {"client_id": "client", "client_secret": "secret"}, "timeout": 30.0},
        )
    ]


def test_rest_import_uses_official_v2_execution_endpoints(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    report = tmp_path / "junit.xml"
    report.write_text("<testsuite />", encoding="utf-8")
    calls: list[tuple[str, dict[str, object]]] = []

    def fake_post(url: str, **kwargs: object) -> httpx.Response:
        calls.append((url, dict(kwargs)))
        return httpx.Response(200, json={"key": "QA-1"}, request=httpx.Request("POST", url))

    monkeypatch.setattr(httpx, "post", fake_post)

    result = XrayRestClient(config(), "token-value").import_results("junit", report)

    assert result == {"key": "QA-1"}
    assert IMPORT_ENDPOINTS["xray"] == "/api/v2/import/execution"
    assert IMPORT_ENDPOINTS["junit"] == "/api/v2/import/execution/junit"
    assert IMPORT_ENDPOINTS["cucumber"] == "/api/v2/import/execution/cucumber"
    assert calls == [
        (
            "https://xray.cloud.getxray.app/api/v2/import/execution/junit",
            {
                "headers": {
                    "Authorization": "Bearer token-value",
                    "Content-Type": "application/xml",
                },
                "content": b"<testsuite />",
                "timeout": 60.0,
            },
        )
    ]


def test_bulk_test_import_uses_official_rest_v2_endpoints(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    bulk_file = tmp_path / "tests.json"
    bulk_file.write_text('{"tests": []}', encoding="utf-8")
    post_calls: list[tuple[str, dict[str, object]]] = []
    get_calls: list[tuple[str, dict[str, object]]] = []

    def fake_post(url: str, **kwargs: object) -> httpx.Response:
        post_calls.append((url, dict(kwargs)))
        return httpx.Response(200, json={"jobId": "abc123"}, request=httpx.Request("POST", url))

    def fake_get(url: str, **kwargs: object) -> httpx.Response:
        get_calls.append((url, dict(kwargs)))
        return httpx.Response(200, json={"status": "working"}, request=httpx.Request("GET", url))

    monkeypatch.setattr(httpx, "post", fake_post)
    monkeypatch.setattr(httpx, "get", fake_get)

    client = XrayRestClient(config("https://au.xray.cloud.getxray.app"), "token-value")

    assert client.import_tests_bulk(bulk_file) == {"jobId": "abc123"}
    assert client.import_tests_bulk_status("abc123") == {"status": "working"}
    assert BULK_TEST_IMPORT_ENDPOINT == "/api/v2/import/test/bulk"
    assert post_calls == [
        (
            "https://au.xray.cloud.getxray.app/api/v2/import/test/bulk",
            {
                "headers": {
                    "Authorization": "Bearer token-value",
                    "Content-Type": "application/json",
                },
                "content": b'{"tests": []}',
                "timeout": 60.0,
            },
        )
    ]
    assert get_calls == [
        (
            "https://au.xray.cloud.getxray.app/api/v2/import/test/bulk/abc123/status",
            {"headers": {"Authorization": "Bearer token-value"}, "timeout": 60.0},
        )
    ]


def test_bulk_test_import_normalizes_string_job_id(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    bulk_file = tmp_path / "tests.json"
    bulk_file.write_text("[]", encoding="utf-8")

    def fake_post(url: str, **kwargs: object) -> httpx.Response:
        return httpx.Response(200, json="abc123", request=httpx.Request("POST", url))

    monkeypatch.setattr(httpx, "post", fake_post)

    assert XrayRestClient(config(), "token-value").import_tests_bulk(bulk_file) == {
        "jobId": "abc123"
    }


def test_jira_client_uses_rest_v3_auth_and_issue_shapes(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    calls: list[tuple[str, dict[str, object]]] = []
    jira_config = XrayConfig(
        client_id="client",
        client_secret="secret",
        base_url="https://xray.cloud.getxray.app",
        region="global",
        profile_path=Path("profile.json"),
        jira_base_url="https://example.atlassian.net",
        jira_email="qa@example.com",
        jira_api_token="jira-token",
        jira_project_key="QA",
    )

    def fake_post(url: str, **kwargs: object) -> httpx.Response:
        calls.append((url, dict(kwargs)))
        return httpx.Response(
            201,
            json={"id": "10001", "key": "QA-1"},
            request=httpx.Request("POST", url),
        )

    monkeypatch.setattr(httpx, "post", fake_post)

    result = JiraRestClient(jira_config).create_issue(
        "Bug",
        "Checkout fails",
        "Card declined unexpectedly",
    )

    assert result == {"id": "10001", "key": "QA-1"}
    url, kwargs = calls[0]
    assert url == "https://example.atlassian.net/rest/api/3/issue"
    assert kwargs["headers"]["Authorization"].startswith("Basic ")
    fields = kwargs["json"]["fields"]
    assert fields["project"] == {"key": "QA"}
    assert fields["issuetype"] == {"name": "Bug"}
    assert fields["summary"] == "Checkout fails"
    assert fields["description"]["type"] == "doc"


def test_jira_client_get_issue_and_link_shapes(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    get_calls: list[tuple[str, dict[str, object]]] = []
    post_calls: list[tuple[str, dict[str, object]]] = []
    jira_config = XrayConfig(
        client_id="client",
        client_secret="secret",
        base_url="https://xray.cloud.getxray.app",
        region="global",
        profile_path=Path("profile.json"),
        jira_base_url="https://example.atlassian.net",
        jira_email="qa@example.com",
        jira_api_token="jira-token",
    )

    def fake_get(url: str, **kwargs: object) -> httpx.Response:
        get_calls.append((url, dict(kwargs)))
        return httpx.Response(
            200,
            json={"id": "10001", "key": "QA-1", "fields": {}},
            request=httpx.Request("GET", url),
        )

    def fake_post(url: str, **kwargs: object) -> httpx.Response:
        post_calls.append((url, dict(kwargs)))
        return httpx.Response(201, request=httpx.Request("POST", url))

    monkeypatch.setattr(httpx, "get", fake_get)
    monkeypatch.setattr(httpx, "post", fake_post)

    client = JiraRestClient(jira_config)
    assert client.get_issue("QA-1", summary_only=True)["id"] == "10001"
    assert client.link_issues("QA-2", "QA-1", "Test") == {
        "inwardIssue": "QA-2",
        "outwardIssue": "QA-1",
        "linkType": "Test",
    }

    assert get_calls[0][0] == "https://example.atlassian.net/rest/api/3/issue/QA-1"
    assert get_calls[0][1]["params"] == {"fields": "summary"}
    assert post_calls[0][0] == "https://example.atlassian.net/rest/api/3/issueLink"
    assert post_calls[0][1]["json"] == {
        "type": {"name": "Test"},
        "inwardIssue": {"key": "QA-2"},
        "outwardIssue": {"key": "QA-1"},
    }
