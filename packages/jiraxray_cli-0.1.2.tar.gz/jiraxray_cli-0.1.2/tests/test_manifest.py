from jiraxray_cli.manifest import known_suite_commands, manifest_as_json


def test_manifest_contains_agent_metadata() -> None:
    commands = manifest_as_json()

    tests_search = next(item for item in commands if item["command"] == "tests search")
    assert tests_search["risk"] == "read-only"
    assert tests_search["supports_suite"] is True


def test_known_suite_commands_excludes_diagnostics() -> None:
    commands = known_suite_commands()

    assert "tests search" in commands
    assert "commands" not in commands


def test_manifest_contains_root_init_command() -> None:
    commands = manifest_as_json()

    init = next(item for item in commands if item["command"] == "init")

    assert init["category"] == "authoring"
    assert init["side_effect"] == "file-write"
    assert {arg["name"] for arg in init["optional_args"]} == {
        "path",
        "tool",
        "suite_name",
        "force",
    }


def test_manifest_has_workflow_commands_and_required_args() -> None:
    commands = manifest_as_json()

    validate_import = next(
        item for item in commands if item["command"] == "workflow validate-import"
    )
    add_to_set = next(item for item in commands if item["command"] == "sets add-tests")
    add_to_execution = next(item for item in commands if item["command"] == "executions add-tests")
    upload_evidence = next(
        item for item in commands if item["command"] == "testruns upload-evidence"
    )
    issue_create = next(item for item in commands if item["command"] == "issues create")
    issue_link = next(item for item in commands if item["command"] == "issues link")

    assert validate_import["risk"] == "read-only"
    assert {arg["name"] for arg in add_to_set["required_args"]} == {"set_id", "test_ids"}
    assert {arg["name"] for arg in add_to_execution["required_args"]} == {
        "execution_id",
        "test_ids",
    }
    assert {arg["name"] for arg in upload_evidence["required_args"]} == {
        "test_run_id",
        "files",
    }
    assert {arg["name"] for arg in issue_create["required_args"]} == {"type", "summary"}
    assert {arg["name"] for arg in issue_link["required_args"]} == {"inward", "outward"}
