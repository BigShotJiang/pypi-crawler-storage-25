from pathlib import Path

import pytest

from jiraxray_cli.cli import main
from jiraxray_cli.models import JsonObject
from jiraxray_cli.service import XrayService
from tests.test_migration import write_zephyr_workbook


def test_diagnose_returns_success(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
    capsys: pytest.CaptureFixture[str],
) -> None:
    monkeypatch.chdir(tmp_path)

    exit_code = main(["diagnose", "--json"])

    assert exit_code == 0
    assert "credentialsPresent" in capsys.readouterr().out


def test_suite_init_and_list(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
    capsys: pytest.CaptureFixture[str],
) -> None:
    monkeypatch.chdir(tmp_path)

    assert main(["suite", "init", "--json"]) == 0
    assert main(["suite", "list", "--json"]) == 0
    assert "example-discovery" in capsys.readouterr().out


def test_init_command_generates_codex_files(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
    capsys: pytest.CaptureFixture[str],
) -> None:
    monkeypatch.chdir(tmp_path)

    exit_code = main(["init", "--tool", "codex", "--suite-name", "billing suite", "--json"])

    assert exit_code == 0
    assert (tmp_path / ".agents/skills/jiraxray-cli/SKILL.md").exists()
    assert "billing suite" in capsys.readouterr().out


def test_workflow_validate_import(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    monkeypatch.chdir(tmp_path)
    report = tmp_path / "junit.xml"
    report.write_text("<testsuite />", encoding="utf-8")

    exit_code = main(["workflow", "validate-import", "--format", "junit", "--path", str(report)])

    assert exit_code == 0


def test_migration_cli_workflow(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
    capsys: pytest.CaptureFixture[str],
) -> None:
    monkeypatch.chdir(tmp_path)
    source = write_zephyr_workbook(tmp_path / "zephyr.xlsx")

    assert main(["zephyr", "inspect", "--source", str(source), "--out", "inspect.md"]) == 0
    assert main(
        [
            "migrate",
            "map",
            "init",
            "--source",
            str(source),
            "--project-key",
            "QA",
            "--out",
            "mapping.yaml",
        ]
    ) == 0
    assert main(["migrate", "map", "validate", "--mapping", "mapping.yaml"]) == 0
    assert main(
        [
            "migrate",
            "transform",
            "--source",
            str(source),
            "--mapping",
            "mapping.yaml",
            "--out",
            "plan.json",
        ]
    ) == 0
    assert main(["migrate", "validate", "--input", "plan.json"]) == 0
    assert main(["migrate", "preview", "--input", "plan.json", "--out", "preview.md"]) == 0

    assert (tmp_path / "inspect.md").exists()
    assert (tmp_path / "preview.md").exists()
    assert "User can log in" in capsys.readouterr().out


def test_commands_default_is_human_readable(capsys: pytest.CaptureFixture[str]) -> None:
    exit_code = main(["commands"])

    output = capsys.readouterr().out
    assert exit_code == 0
    assert "Migration" in output
    assert "migrate transform" in output


def test_command_detail_is_human_readable(capsys: pytest.CaptureFixture[str]) -> None:
    exit_code = main(["command", "migrate transform"])

    output = capsys.readouterr().out
    assert exit_code == 0
    assert "Purpose:" in output
    assert "--mapping" in output


def test_workflow_sync_library_dry_run(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
    capsys: pytest.CaptureFixture[str],
) -> None:
    monkeypatch.chdir(tmp_path)
    source = tmp_path / "tests.yaml"
    source.write_text(
        """
tests:
  - summary: User signs in
    steps:
      - action: Open login
        result: Login is visible
""",
        encoding="utf-8",
    )

    exit_code = main(
        [
            "workflow",
            "sync-library",
            "--source",
            str(source),
            "--project-key",
            "DEMO",
            "--dry-run",
        ]
    )

    assert exit_code == 0
    assert "User signs in" in capsys.readouterr().out


def test_diagnose_live_routes_to_jira_and_xray_checks(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
    capsys: pytest.CaptureFixture[str],
) -> None:
    monkeypatch.chdir(tmp_path)

    monkeypatch.setattr(
        XrayService,
        "validate_xray_connection",
        lambda self: {"data": {"getTests": {"results": []}}},
    )
    monkeypatch.setattr(
        XrayService,
        "validate_jira_connection",
        lambda self: {"accountId": "user-1"},
    )

    exit_code = main(["diagnose", "--live", "--json"])

    output = capsys.readouterr().out
    assert exit_code == 0
    assert "accountId" in output
    assert "jiraCredentialsPresent" in output


def test_issue_commands_route_to_service(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
    capsys: pytest.CaptureFixture[str],
) -> None:
    monkeypatch.chdir(tmp_path)

    def fake_create_issue(
        self: XrayService,
        issue_type: str,
        summary: str,
        description: str | None = None,
        project_key: str | None = None,
    ) -> JsonObject:
        return {
            "issueType": issue_type,
            "summary": summary,
            "description": description,
            "projectKey": project_key,
        }

    monkeypatch.setattr(XrayService, "create_issue", fake_create_issue)
    monkeypatch.setattr(
        XrayService,
        "get_issue_summary",
        lambda self, issue: {"key": issue, "summary": "Checkout fails"},
    )
    monkeypatch.setattr(
        XrayService,
        "link_issues",
        lambda self, inward, outward, link_type: {
            "inward": inward,
            "outward": outward,
            "type": link_type,
        },
    )

    assert (
        main(
            [
                "issues",
                "create",
                "--type",
                "Bug",
                "--summary",
                "Checkout fails",
                "--description",
                "Card declined",
                "--project-key",
                "QA",
                "--json",
            ]
        )
        == 0
    )
    assert main(["issues", "summary", "--issue", "QA-1", "--json"]) == 0
    assert (
        main(
            [
                "issues",
                "link",
                "--inward",
                "QA-2",
                "--outward",
                "QA-1",
                "--type",
                "Test",
                "--json",
            ]
        )
        == 0
    )

    output = capsys.readouterr().out
    assert "Checkout fails" in output
    assert "QA-1" in output
    assert "QA-2" in output


def test_execution_and_testrun_aliases_route_to_service(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
    capsys: pytest.CaptureFixture[str],
) -> None:
    monkeypatch.chdir(tmp_path)
    calls: list[JsonObject] = []

    def fake_add_tests(
        self: XrayService,
        execution_id: str,
        test_ids: list[str],
    ) -> JsonObject:
        calls.append({"execution": execution_id, "tests": test_ids})
        return {"added": test_ids}

    def fake_get_run(
        self: XrayService,
        execution_id: str,
        test_id: str,
        *,
        wait: bool = False,
        attempts: int = 5,
        delay_seconds: float = 3.0,
    ) -> JsonObject:
        calls.append(
            {
                "execution": execution_id,
                "test": test_id,
                "wait": wait,
                "attempts": attempts,
                "delay": delay_seconds,
            }
        )
        return {"run": "run-1"}

    def fake_upload(
        self: XrayService,
        test_run_id: str,
        files: list[Path],
    ) -> JsonObject:
        calls.append({"run": test_run_id, "files": [path.name for path in files]})
        return {"uploaded": len(files)}

    monkeypatch.setattr(XrayService, "add_tests_to_execution", fake_add_tests)
    monkeypatch.setattr(XrayService, "get_test_run", fake_get_run)
    monkeypatch.setattr(XrayService, "upload_evidence", fake_upload)

    assert (
        main(
            [
                "executions",
                "add-tests",
                "--execution",
                "QA-10",
                "--tests",
                "QA-11,QA-12",
                "--json",
            ]
        )
        == 0
    )
    assert (
        main(
            [
                "testruns",
                "get",
                "--execution",
                "QA-10",
                "--test",
                "QA-11",
                "--wait",
                "--attempts",
                "2",
                "--delay-seconds",
                "0",
                "--json",
            ]
        )
        == 0
    )
    assert (
        main(
            [
                "testruns",
                "upload-evidence",
                "--run",
                "run-1",
                "--files",
                "screenshot.png,report.json",
                "--json",
            ]
        )
        == 0
    )

    capsys.readouterr()
    assert calls == [
        {"execution": "QA-10", "tests": ["QA-11", "QA-12"]},
        {"execution": "QA-10", "test": "QA-11", "wait": True, "attempts": 2, "delay": 0.0},
        {"run": "run-1", "files": ["screenshot.png", "report.json"]},
    ]
