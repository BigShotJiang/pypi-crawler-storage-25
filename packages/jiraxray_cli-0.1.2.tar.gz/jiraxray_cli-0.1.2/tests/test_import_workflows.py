import json
from pathlib import Path

from jiraxray_cli.workflows.imports import (
    load_sync_library,
    sync_tests_from_library,
    validate_bulk_test_import,
    validate_result_import,
    validate_sync_library,
)


def test_validate_result_import_accepts_junit_xml(tmp_path: Path) -> None:
    report = tmp_path / "junit.xml"
    report.write_text("<testsuite><testcase name='a'/></testsuite>", encoding="utf-8")

    assert validate_result_import("junit", report) == []


def test_validate_result_import_rejects_invalid_json(tmp_path: Path) -> None:
    report = tmp_path / "xray.json"
    report.write_text("{not-json", encoding="utf-8")

    warnings = validate_result_import("xray", report)

    assert warnings
    assert "Invalid JSON" in warnings[0]


def test_sync_library_loads_and_normalizes_tests(tmp_path: Path) -> None:
    source = tmp_path / "tests.json"
    source.write_text(
        json.dumps(
            {
                "tests": [
                    {
                        "summary": "User signs in",
                        "steps": [{"action": "Open login", "result": "Login is visible"}],
                    }
                ]
            }
        ),
        encoding="utf-8",
    )

    value = load_sync_library(source)
    warnings = validate_sync_library(value, "DEMO")
    tests = sync_tests_from_library(value, "DEMO")

    assert warnings == []
    assert tests[0]["project_key"] == "DEMO"
    assert tests[0]["summary"] == "User signs in"
    assert len(tests[0]["steps"]) == 1


def test_validate_bulk_test_import_enforces_official_limit(tmp_path: Path) -> None:
    source = tmp_path / "bulk.json"
    source.write_text(json.dumps({"tests": [{}] * 1001}), encoding="utf-8")

    warnings = validate_bulk_test_import(source)

    assert warnings
    assert "maximum of 1000 tests" in warnings[0]


def test_validate_bulk_test_import_accepts_tests_object(tmp_path: Path) -> None:
    source = tmp_path / "bulk.json"
    source.write_text(
        json.dumps({"tests": [{"fields": {"summary": "User signs in"}}]}),
        encoding="utf-8",
    )

    assert validate_bulk_test_import(source) == []
