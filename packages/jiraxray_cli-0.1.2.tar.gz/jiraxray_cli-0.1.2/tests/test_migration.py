from pathlib import Path

from openpyxl import Workbook

from jiraxray_cli.migration.mapping import (
    default_mapping_for_export,
    load_mapping,
    validate_mapping,
    write_mapping,
)
from jiraxray_cli.migration.plan import (
    load_import_plan,
    plan_summary,
    render_preview_markdown,
    transform_export,
    write_import_plan,
)
from jiraxray_cli.migration.zephyr import inspect_zephyr_excel, inspection_to_json


def write_zephyr_workbook(path: Path) -> Path:
    """Write a representative Zephyr Squad export workbook."""

    workbook = Workbook()
    sheet = workbook.active
    sheet.title = "Zephyr Export"
    sheet.append(
        [
            "Issue Id",
            "Summary",
            "Description",
            "Folder",
            "Priority",
            "Status",
            "Labels",
            "Components",
            "Precondition",
            "Step Action",
            "Test Data",
            "Expected Result",
        ]
    )
    sheet.append(
        [
            "ZEP-1",
            "User can log in",
            "Login smoke test",
            "/Authentication",
            "High",
            "Approved",
            "smoke, login",
            "Portal",
            "User exists",
            "Open login page",
            "valid user",
            "Login form appears",
        ]
    )
    sheet.append(
        [
            "ZEP-1",
            "User can log in",
            "Login smoke test",
            "/Authentication",
            "High",
            "Approved",
            "smoke, login",
            "Portal",
            "User exists",
            "Submit credentials",
            "valid user",
            "Dashboard appears",
        ]
    )
    sheet.append(["ZEP-2", "User can log out", None, "/Authentication", "Medium", "Draft"])
    workbook.save(path)
    return path


def test_inspect_zephyr_excel_groups_steps(tmp_path: Path) -> None:
    source = write_zephyr_workbook(tmp_path / "zephyr.xlsx")

    inspection = inspect_zephyr_excel(source)
    data = inspection_to_json(inspection)

    assert len(inspection.tests) == 2
    assert inspection.tests[0].steps[1].action == "Submit credentials"
    assert data["testCount"] == 2


def test_mapping_transform_validate_and_preview(tmp_path: Path) -> None:
    source = write_zephyr_workbook(tmp_path / "zephyr.xlsx")
    mapping_path = tmp_path / "zephyr-to-xray.yaml"
    plan_path = tmp_path / "plan.json"

    mapping = default_mapping_for_export(source, "QA")
    write_mapping(mapping, mapping_path)

    assert validate_mapping(load_mapping(mapping_path)) == []
    plan = transform_export(source, mapping_path)
    write_import_plan(plan, plan_path)
    loaded = load_import_plan(plan_path)
    summary = plan_summary(loaded)
    preview = render_preview_markdown(loaded)

    assert summary["testCount"] == 2
    assert summary["projectKey"] == "QA"
    assert "User can log in" in preview
