import tomllib
from pathlib import Path

import jiraxray_cli


def test_package_metadata_defines_installable_console_scripts() -> None:
    pyproject = tomllib.loads(Path("pyproject.toml").read_text(encoding="utf-8"))

    project = pyproject["project"]
    scripts = project["scripts"]

    assert project["name"] == "jiraxray-cli"
    assert project["version"] == jiraxray_cli.__version__
    assert project["requires-python"] == ">=3.11"
    assert project["license"] == "MIT"
    assert project["license-files"] == ["LICENSE"]
    assert scripts == {
        "jiraxray-cli": "jiraxray_cli.cli:main",
    }


def test_package_metadata_has_publish_required_project_urls() -> None:
    pyproject = tomllib.loads(Path("pyproject.toml").read_text(encoding="utf-8"))

    urls = pyproject["project"]["urls"]

    assert urls["Homepage"] == "https://jaysisley.dev"
    assert urls["Repository"].endswith("agent-jiraXray-cli")
    assert urls["Issues"].endswith("/issues")
    assert urls["Documentation"].endswith("/docs")
