from pathlib import Path

import pytest

from jiraxray_cli.config import resolve_config, write_default_profile


def test_resolve_config_uses_region_default(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    monkeypatch.delenv("XRAY_BASE_URL", raising=False)
    monkeypatch.setenv("XRAY_REGION", "us")

    config = resolve_config(tmp_path)

    assert config.base_url == "https://us.xray.cloud.getxray.app"
    assert config.region == "us"


def test_write_default_profile_has_no_secrets(tmp_path: Path) -> None:
    path = write_default_profile(tmp_path)

    text = path.read_text(encoding="utf-8")
    assert "client" not in text.lower()
    assert "secret" not in text.lower()


def test_resolve_config_reads_jira_env_and_profile(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    monkeypatch.setenv("JIRA_BASE_URL", "https://example.atlassian.net/")
    monkeypatch.setenv("JIRA_EMAIL", "qa@example.com")
    monkeypatch.setenv("JIRA_API_TOKEN", "token")
    monkeypatch.setenv("JIRA_PROJECT_KEY", "QA")

    config = resolve_config(tmp_path)

    assert config.jira_base_url == "https://example.atlassian.net"
    assert config.jira_email == "qa@example.com"
    assert config.jira_api_token == "token"
    assert config.jira_project_key == "QA"
    assert config.has_jira_credentials is True
