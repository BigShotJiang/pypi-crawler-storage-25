from jiraxray_cli.models import CliResult
from jiraxray_cli.output import render_result


def test_compact_output_omits_raw_payload() -> None:
    rendered = render_result(
        CliResult(ok=True, command="x", data={"raw": {"large": True}, "count": 1})
    )

    assert '"count": 1' in rendered
    assert "large" not in rendered
