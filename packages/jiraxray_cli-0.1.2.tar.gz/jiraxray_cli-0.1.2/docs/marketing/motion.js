import { animate, stagger } from "https://cdn.jsdelivr.net/npm/motion@10/+esm";

/* ============================================================
 * jiraxray-cli marketing site – behaviour
 * Vanilla JS plus Motion One for entrance choreography.
 * Honours prefers-reduced-motion.
 * Handles: theme toggle, focus-frame dimming, headline reveals,
 *          pinned workflow scroll, guide TOC + progress bar.
 * ============================================================ */
(function () {
  "use strict";

  const root = document.documentElement;
  const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  /* ---------- Theme toggle ---------- */
  (function theme() {
    const saved = (() => { try { return localStorage.getItem("ct-theme"); } catch (_) { return null; } })();
    const systemDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
    if (saved) root.dataset.theme = saved;
    else if (systemDark) root.dataset.theme = "dark";

    document.querySelectorAll("[data-theme-toggle]").forEach((button) => {
      const setLabel = () => {
        const next = root.dataset.theme === "dark" ? "Switch to light mode" : "Switch to dark mode";
        button.setAttribute("aria-label", next);
        button.setAttribute("title", next);
      };
      setLabel();
      button.addEventListener("click", () => {
        root.dataset.theme = root.dataset.theme === "dark" ? "light" : "dark";
        try { localStorage.setItem("ct-theme", root.dataset.theme); } catch (_) {}
        setLabel();
      });
    });
  })();

  /* ---------- Focus-frame dimming ----------
   * Each .focus-frame gets a data-focus state based on how close its centre
   * is to the viewport centre. Three states: active, near, far.
   */
  (function focusFrames() {
    if (reduceMotion) return;
    const frames = Array.from(document.querySelectorAll(".focus-frame"));
    if (!frames.length) return;

    let raf = 0;
    function update() {
      raf = 0;
      const vh = window.innerHeight;
      const activeTop = vh * 0.28;
      const activeBottom = vh * 0.72;
      frames.forEach((el) => {
        const r = el.getBoundingClientRect();
        const overlap = r.bottom > 0 && r.top < vh;
        if (!overlap) { el.dataset.focus = "far"; return; }
        if (r.top <= activeBottom && r.bottom >= activeTop) el.dataset.focus = "active";
        else if (r.bottom >= 0 && r.top <= vh) el.dataset.focus = "near";
        else el.dataset.focus = "far";
      });
    }
    function schedule() {
      if (raf) return;
      raf = requestAnimationFrame(update);
    }
    update();
    window.addEventListener("scroll", schedule, { passive: true });
    window.addEventListener("resize", schedule);
  })();

  /* ---------- Reveal on enter (word stagger) ----------
   * Any element marked .js-reveal has its text split into words
   * and faded in from below, once.
   */
  (function reveals() {
    const targets = document.querySelectorAll(".js-reveal");
    if (!targets.length) return;
    targets.forEach((el) => {
      // Walk text nodes only — preserve inline tags like <em>.
      const wrap = (node) => {
        if (node.nodeType === 3) {
          const frag = document.createDocumentFragment();
          const parts = node.textContent.split(/(\s+)/);
          parts.forEach((part) => {
            if (/^\s+$/.test(part)) {
              frag.appendChild(document.createTextNode(part));
            } else if (part.length) {
              const span = document.createElement("span");
              span.className = "reveal-word";
              span.textContent = part;
              frag.appendChild(span);
            }
          });
          node.parentNode.replaceChild(frag, node);
        } else if (node.nodeType === 1 && !node.classList.contains("reveal-word")) {
          Array.from(node.childNodes).forEach(wrap);
        }
      };
      Array.from(el.childNodes).forEach(wrap);
      const words = el.querySelectorAll(".reveal-word");
      words.forEach((w, i) => { w.style.setProperty("--rev-delay", (i * 32) + "ms"); });
    });

    if (reduceMotion) {
      document.querySelectorAll(".reveal-word").forEach((w) => w.classList.add("is-in"));
      return;
    }
    const io = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          const words = Array.from(entry.target.querySelectorAll(".reveal-word"));
          words.forEach((w) => w.classList.add("is-in"));
          animate(
            words,
            { opacity: [0, 1], transform: ["translateY(8px)", "translateY(0px)"] },
            { duration: 0.2, delay: stagger(0.03), easing: "ease-out" }
          );
          io.unobserve(entry.target);
        }
      });
    }, { threshold: 0.2, rootMargin: "0px 0px -10% 0px" });
    targets.forEach((el) => io.observe(el));
  })();

  /* ---------- Pinned workflow ----------
   * Section is ~3.2x viewport tall. As user scrolls through it,
   * we map the progress to (a) which tab is active and
   * (b) how many of the 5 steps are lit.
   */
  (function workflow() {
    const wrap = document.querySelector("[data-workflow]");
    if (!wrap) return;
    const tabs = Array.from(wrap.querySelectorAll("[data-workflow-tab]"));
    const panes = Array.from(wrap.querySelectorAll("[data-workflow-pane]"));
    const progressEl = wrap.querySelector(".workflow-progress");

    const order = ["manual", "ai", "auto"];
    let current = "manual";

    const setActive = (key) => {
      if (key === current) return;
      current = key;
      tabs.forEach((t) => t.classList.toggle("is-active", t.dataset.workflowTab === key));
      tabs.forEach((t) => t.setAttribute("aria-selected", String(t.dataset.workflowTab === key)));
      panes.forEach((p) => {
        const active = p.dataset.workflowPane === key;
        p.classList.toggle("is-active", active);
        p.toggleAttribute("hidden", !active);
      });
    };

    const setLitSteps = (paneKey, n) => {
      const pane = wrap.querySelector(`[data-workflow-pane="${paneKey}"]`);
      if (!pane) return;
      const steps = pane.querySelectorAll(".workflow-step");
      steps.forEach((step, i) => step.classList.toggle("is-lit", i < n));
    };

    // Manual click on tabs = jump to that segment.
    tabs.forEach((tab) => {
      tab.addEventListener("click", () => {
        const key = tab.dataset.workflowTab;
        setActive(key);
        // Light all 5 steps in the freshly chosen pane so the user sees content.
        setLitSteps(key, 5);
        // Scroll the page so the workflow stage is visible at the right segment.
        if (!reduceMotion) {
          const segIndex = order.indexOf(key);
          const r = wrap.getBoundingClientRect();
          const scrollable = wrap.offsetHeight - window.innerHeight;
          const target = wrap.offsetTop + scrollable * (segIndex / order.length) + 4;
          window.scrollTo({ top: target, behavior: "smooth" });
        }
      });
    });

    if (reduceMotion) {
      // Static fallback: all steps lit, tabs work normally.
      panes.forEach((p) => setLitSteps(p.dataset.workflowPane, 5));
      return;
    }

    // Scroll-driven scrub.
    let raf = 0;
    function update() {
      raf = 0;
      const r = wrap.getBoundingClientRect();
      const total = wrap.offsetHeight - window.innerHeight;
      const passed = Math.min(Math.max(-r.top, 0), total);
      const t = total > 0 ? passed / total : 0; // 0 → 1 across the whole section

      // Three even segments.
      let key, segT;
      if (t < 1 / 3) { key = "manual"; segT = t / (1 / 3); }
      else if (t < 2 / 3) { key = "ai"; segT = (t - 1 / 3) / (1 / 3); }
      else { key = "auto"; segT = (t - 2 / 3) / (1 / 3); }
      segT = Math.max(0, Math.min(1, segT));

      setActive(key);

      // Steps within the active pane: 0 lit at segT=0, 5 lit at segT=1.
      const lit = Math.max(1, Math.round(segT * 5));
      setLitSteps(key, lit);

      // Earlier panes show all 5 lit; later panes show 0 — so when scrolling
      // back up, the dimming reverses naturally.
      order.forEach((k) => {
        if (k === key) return;
        if (order.indexOf(k) < order.indexOf(key)) setLitSteps(k, 5);
        else setLitSteps(k, 0);
      });

      // Progress bar fill.
      if (progressEl) progressEl.style.setProperty("--progress", (t * 100) + "%");
    }
    function schedule() { if (!raf) raf = requestAnimationFrame(update); }
    update();
    window.addEventListener("scroll", schedule, { passive: true });
    window.addEventListener("resize", schedule);
  })();

  /* ---------- Guide TOC + scroll spy + progress bar ---------- */
  (function guide() {
    const toc = document.querySelector("[data-guide-toc]");
    const progressBar = document.querySelector("[data-guide-progress]");
    const sections = Array.from(document.querySelectorAll("[data-guide-section]"));
    if (!sections.length) return;

    if (toc) {
      const links = toc.querySelectorAll("a[href^='#']");
      const map = new Map();
      links.forEach((a) => {
        const id = a.getAttribute("href").slice(1);
        if (id) map.set(id, a);
      });
      const setActive = (id) => {
        links.forEach((a) => a.classList.toggle("is-active", a.getAttribute("href") === "#" + id));
      };
      const io = new IntersectionObserver((entries) => {
        // Pick whichever section's top is closest to ~30% from the viewport top.
        const visible = entries.filter((e) => e.isIntersecting);
        if (!visible.length) return;
        visible.sort((a, b) => Math.abs(a.boundingClientRect.top - 120) - Math.abs(b.boundingClientRect.top - 120));
        const id = visible[0].target.id;
        if (id) setActive(id);
      }, { rootMargin: "-30% 0px -55% 0px", threshold: 0 });
      sections.forEach((s) => io.observe(s));
    }

    if (progressBar) {
      let raf = 0;
      const update = () => {
        raf = 0;
        const main = document.querySelector("main");
        if (!main) return;
        const r = main.getBoundingClientRect();
        const total = main.offsetHeight - window.innerHeight;
        const passed = Math.min(Math.max(-r.top, 0), total);
        const p = total > 0 ? (passed / total) * 100 : 0;
        progressBar.style.setProperty("--p", p + "%");
      };
      const schedule = () => { if (!raf) raf = requestAnimationFrame(update); };
      update();
      window.addEventListener("scroll", schedule, { passive: true });
      window.addEventListener("resize", schedule);
    }
  })();

  /* ---------- Smooth-anchor offset for sticky topbar ---------- */
  (function anchorJump() {
    document.querySelectorAll('a[href^="#"]').forEach((a) => {
      a.addEventListener("click", (e) => {
        const id = a.getAttribute("href").slice(1);
        if (!id) return;
        const target = document.getElementById(id);
        if (!target) return;
        e.preventDefault();
        const top = target.getBoundingClientRect().top + window.pageYOffset - 88;
        window.scrollTo({ top, behavior: reduceMotion ? "auto" : "smooth" });
        history.replaceState(null, "", "#" + id);
      });
    });
  })();
})();
