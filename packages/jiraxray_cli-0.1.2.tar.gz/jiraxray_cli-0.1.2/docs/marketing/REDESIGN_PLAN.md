# Marketing site redesign plan

Branch: `codex/marketing-webpage`
Files in scope: `docs/marketing/index.html`, `docs/marketing/guide.html`, `docs/marketing/styles.css`, `docs/marketing/assets/*`
Stack: vanilla HTML/CSS/JS, [Motion One](https://motion.dev) (~3.8 KB) for scroll choreography, [Lucide](https://lucide.dev) icons via CDN, no build step.

---

## 1. Honest diagnosis of the current site

The content is solid. The problems are visual and structural:

- **Hand-drawn line icons** — inconsistent stroke weights, mismatched proportions (some 30 % filled, some hollow), and they read as childish next to a serious enterprise QA tool.
- **Brand SVGs hard-coded with raw vendor colours** — the page becomes a clown line-up of Atlassian blue, Xray green, Postman orange, Robot teal, Pytest yellow. No visual cohesion.
- **Card-grid overload** — almost every section is a 3-up or 4-up grid of cards. There's no rhythm: cards, cards, cards, cards.
- **Redundant ideas, repeated visually** — "AI + human + automation" is shown four separate ways (the three "Why" cards, the three "tool groups" tiles, the workflow tabs, the two-rail board). The visitor can't tell where the through-line is.
- **No focal hierarchy** — every section has the same weight, the same eyebrow → h2 → grid pattern. Nothing earns the user's attention.
- **Decorative gradients that don't say anything** — teal + blue radial blobs in the body background pull the eye without serving the message.
- **Trust strip directly under the hero** — four micro-pills ("MIT licensed", "AI-agnostic", "Dry-run first", "CLI-first") that look like a logo bar but say nothing scannable at a glance.
- **Terminal blocks are visually loud** — primary-colour syntax tokens (red/yellow/green/violet) compete with everything around them.
- **No motion** — `scroll-behavior: smooth` and a hover-tab is the entire interaction model.

The bones — semantic HTML, light/dark toggle, custom SVG sprite, accessible `role="tablist"` — are reusable. We keep those and rebuild the surface above them.

---

## 2. Visual system

### Typography (the star of editorial direction)

| Role | Family | Notes |
| --- | --- | --- |
| Display / H1 / H2 | **Fraunces** (serif, variable, opt-sz axis) | Editorial weight without being pompous. Self-host via `unicode-range` subset. |
| Body / UI | **Inter** (kept) | Already loaded; tighten leading and tracking. |
| Mono / terminal | **JetBrains Mono** | Replace generic `ui-monospace` stack — JetBrains Mono reads cleaner at the sizes we use. |

Type scale (light theme), modular ratio 1.25:

- `display`: 64 / 1.05 / -0.02em
- `h1`: 48 / 1.1 / -0.02em
- `h2`: 36 / 1.15 / -0.015em
- `h3`: 22 / 1.3 / -0.005em
- `body-lg`: 19 / 1.55
- `body`: 17 / 1.6
- `caption`: 14 / 1.5
- `eyebrow`: 12 / 1.2 / 0.12em / uppercase

Rules: max line-length 68ch on body, 22ch on display headlines. No bold inside paragraphs — emphasis comes from a thin underline accent.

### Palette — "warm paper + ink"

Light (default):

```
--paper:   #FAF7F2   /* off-white, warm */
--paper-2: #F2EDE5   /* cards, subtle surfaces */
--ink:     #1A1816   /* body */
--ink-2:   #2C2A27   /* strong */
--muted:   #6B655D   /* secondary text */
--rule:    #E5DED3   /* hairlines */
--accent:  #C2410C   /* terracotta — used sparingly */
--accent-soft: #FBE7D8
--code-bg: #1A1816   /* terminals: ink-on-ink */
--code-fg: #E8E2D6
```

Dark (toggle):

```
--paper:   #16140F   /* warm near-black */
--paper-2: #1F1C16
--ink:     #ECE6D9
--ink-2:   #FFFAEC
--muted:   #9C948A
--rule:    #2C2820
--accent:  #E97A4B   /* terracotta lifts in dark */
--accent-soft: #2A1B12
```

Rules:
- One accent. Used for: link underlines, primary CTA, the active-step ring on workflow, and selected-tab underline. Nowhere else.
- All vendor brand SVGs (Jira, Xray, Copilot, Claude, Codex, Playwright, etc.) get **monochromed to `--ink` at 60 % opacity** by default; their full colour is only revealed on hover or when their topic is the active scroll section. Stops the clown line-up.
- Terminal blocks become **near-monochrome paper-on-ink**: comments dim, prompts get the accent, everything else is `--code-fg`. No traffic-light dots — replace with a small label pill.

### Spacing & grid

12-column on desktop, 4-column on mobile. Section vertical rhythm uses a `--section: clamp(96px, 14vw, 200px)` token. Sections breathe.

Containers:

- `--shell-max: 1120px`
- `--shell-narrow: 720px` (used for prose-led intros)

Hairlines (1px `--rule`) replace shadows for almost everything. The only shadow we keep is a single soft drop on the hero terminal.

### Surfaces

- Cards lose their drop shadow, gain a 1px `--rule` border, and 24px padding. Hover lifts the rule colour, doesn't add a shadow.
- The hero loses the gradient blobs entirely. Replaced with a subtle paper-grain SVG noise overlay at 4 % opacity (1.5 KB).

---

## 3. Iconography

**Drop the entire hand-drawn `<symbol>` sprite.** Replace with [Lucide](https://lucide.dev) icons loaded via the lucide-static CDN, sized at 20 / 24 / 32 px in a strict three-tier system.

Icon mapping:

| Current | Lucide replacement |
| --- | --- |
| `icon-cli` | `terminal` |
| `icon-ai` | `sparkles` |
| `icon-xray` | `scan-search` |
| `icon-jira` | (drop in favour of brand SVG) |
| `icon-manual` | `clipboard-check` |
| `icon-automation` | `workflow` |
| `icon-group-ai` | `bot` |
| `icon-group-runner` | `cog` |
| `icon-group-test` | `library` |
| `icon-evidence` | `image` |
| `icon-review` | `eye` |
| `icon-suite` | `layout-grid` |
| `icon-open` | `external-link` |
| `icon-zephyr` | `wind` |
| `icon-moon` / `icon-sun` | `moon` / `sun` |

Vendor brand SVGs: keep, but rebuild from official simple-icons paths so they're geometrically correct (the current Jira and Xray glyphs are visibly wrong). Default render at `currentColor` 60 %; full colour only on hover or active section.

Rule of three: any single section uses at most one Lucide icon size. Mixed sizes within a row is what makes the current site feel chaotic.

---

## 4. Information architecture

### `index.html` — current vs. proposed

Current section order:

1. Hero + trust strip
2. "Why" — 3 cards + paragraph + 3 tool-group tiles
3. Jira/Xray fit — stack + terminal
4. Workflow — 3 tabs × 5 steps
5. AI usage — split + two rails
6. Manual + automated — 4 cards
7. Open source paragraph
8. CTA

Proposed (8 → 6 sections, redundancies merged):

1. **Hero** — eyebrow, editorial headline, single sentence lede, two CTAs, single live-feeling terminal panel. Trust strip removed.
2. **The problem in one paragraph** — narrow shell (720px), no cards, just considered prose. Replaces the "Why" section's three-card grid.
3. **Workflow** *(the centrepiece)* — pinned-on-scroll. User scrolls; the workflow stage scrubs through Manual → AI → Automation, and within each, 5 steps light up one at a time. This is the one place we earn cinematic motion.
4. **Where it sits** — Jira → Xray → CLI vertical stack on the left, a single tight terminal on the right. Hairline divider, no cards.
5. **AI without lock-in** — kept as the two-rail diagram (it works), refined typography, smaller icons, accent only on rail headings.
6. **Open source + next step** — merged. One short editorial block, two CTAs.

The "Manual and automated testing" 4-card grid gets *folded into* section 3's Automation path — it was saying the same thing twice.

### `guide.html` — current vs. proposed

Current is a long vertical scroll of card grids and terminals. Reads like a wiki dump.

Proposed:

- **Sticky left-rail TOC** (desktop ≥ 960px): vertical list, scroll-spy active highlight, accent dot on the active section. Collapses to a sticky top progress bar on mobile.
- **Reading column** centred, 720px max, prose-led.
- **Sections (kept, re-pruned)**:
  1. Intro hero (kept, lighter)
  2. Install (Step 1)
  3. Connect (Step 2)
  4. AI pattern (Step 3) — keep the 5-step flow but redrawn as a vertical stepper, not a horizontal grid
  5. Beside an existing automation suite
  6. Where it sits (small refresher, optional)
  7. Manual vs automated scenarios
  8. Examples
  9. **NEW: "Quick reference" card at the very end** — a single compact cheatsheet of the 8–10 commands a user is most likely to copy. This is the bookmarkable section.

The "tool-relationship" paragraph + tool-groups grid that appears mid-guide is duplicated from the index — remove from guide.

---

## 5. Motion model

Library: Motion One (`https://cdn.jsdelivr.net/npm/motion@10/+esm`). One small dependency. ~3.8 KB.

Three motion primitives, used everywhere:

### a) Section fade-focus (the "topics fall in/out of focus" you asked for)

Each `<section>` is wrapped in a `.focus-frame`. As the user scrolls:

- Active frame: `opacity: 1; filter: none; transform: translateY(0);`
- Adjacent frames: `opacity: 0.35; filter: blur(2px);`
- Far frames: `opacity: 0.15; filter: blur(4px);`

Implemented via `IntersectionObserver` with rootMargin biased toward the centre of the viewport. Pure CSS transitions handle the visual change.

`prefers-reduced-motion: reduce` → all dimming/blurring disabled, opacity stays at 1, focus is signalled instead by a single accent-coloured rule on the active section's eyebrow.

### b) Reveal-on-enter

Headlines split into words; each word does a 200ms `translateY(8px) → 0` + `opacity 0 → 1` with a 30ms stagger. Once per element (no re-animation when scrolling back up — easy to feel sea-sick otherwise).

### c) Pinned workflow scrub (the one cinematic moment)

The Workflow section becomes ~3.5 viewport heights tall. Inside it, a sticky stage holds the diagram. As the user scrolls through the section:

- 0–10 %: tab switches to **Manual**
- 10–35 %: steps 01 → 05 light up sequentially
- 35–45 %: tab switches to **AI**
- 45–70 %: AI steps 01 → 05
- 70–80 %: tab switches to **Automation**
- 80–100 %: Automation steps + the supporting terminal animates in below the diagram

User can also click the tabs directly to skip. On `prefers-reduced-motion`, the section collapses to the existing static three-tab pattern.

### Out of scope (I'm not doing these)

- No parallax on hero imagery (we don't have any).
- No cursor-follow effects.
- No marquee logos.
- No autoplay hero video.

---

## 6. Component inventory

Components I'll define once in CSS and reuse:

- `.shell` (kept), plus `.shell--narrow` (720px) and `.shell--wide` (1280px)
- `.eyebrow` (refactored — smaller, real letter-spacing)
- `.display`, `.h1`, `.h2`, `.h3` typographic classes (replaces ad-hoc styling)
- `.button` (primary, secondary, ghost) — pill, 1px border, no gradient, accent background only on primary
- `.terminal` (refactored — paper-on-ink, no traffic lights, label pill)
- `.hairline` (1px rule used everywhere we currently have shadow)
- `.icon` (16/20/24/32 strict sizes)
- `.brand-glyph` (vendor SVGs at 60 % opacity, monochrome by default)
- `.focus-frame` (the scroll-driven dimming wrapper)
- `.toc` (guide-only sticky table of contents)
- `.stepper` (vertical numbered steps)
- `.cheatsheet` (guide reference card)

CSS file gets reorganised into `/* tokens */`, `/* base */`, `/* layout */`, `/* components */`, `/* sections */`, `/* motion */`, `/* dark */`, `/* responsive */` with a comment header. Currently it's a 2 048-line wall.

---

## 7. Accessibility & performance

- Honour `prefers-reduced-motion: reduce` everywhere (section dimming, reveals, pinned workflow all degrade to static).
- Keyboard: workflow tabs remain real `<button role="tab">`; pinned scroll has a "skip animation" link that jumps past it.
- Colour contrast: paper/ink combination tested at 14.2:1 (passes AAA). Terracotta accent on paper sits at 4.7:1 (AA for body, ⚠ for small UI — only used on 16 px+).
- Performance budget: keep the page under **80 KB transferred** on first load (currently ~28 KB CSS + 18 KB HTML; we add Motion One ~4 KB + Lucide subset ~6 KB + Fraunces subset ~22 KB + JetBrains Mono subset ~16 KB). Will subset fonts to Latin only.
- Lighthouse target: 100/100/100/100.
- LCP element: hero headline (text). No hero image to slow it down.
- All images and SVGs lazy-loaded below the fold.

---

## 8. Implementation phases

I'll work through these in order, committing at the end of each phase so you can pull and review:

1. **Foundation** — new design tokens, type scale, fonts, palette in `styles.css`. Replace icon sprite with Lucide. No layout changes yet. *Commit: "chore(marketing): visual tokens, typography, icon system"*
2. **Index — above the fold** — new hero, removed trust strip, new terminal. *Commit: "feat(marketing): editorial hero on landing"*
3. **Index — body sections** — collapse "Why" into a single prose block, refresh "Where it sits", "AI without lock-in", and "Open source / CTA". *Commit: "feat(marketing): restructure landing body sections"*
4. **Index — workflow centrepiece** — build the pinned scroll-driven workflow with Motion One. Includes reduced-motion fallback. *Commit: "feat(marketing): pinned workflow with scroll choreography"*
5. **Guide — shell + TOC** — new sticky left-rail TOC, reading column, mobile progress bar. *Commit: "feat(marketing/guide): editorial shell with sticky TOC"*
6. **Guide — sections** — refresh each section, fold in the new stepper, drop duplicated content, add the quick-reference card at the end. *Commit: "feat(marketing/guide): refreshed section layout and reference card"*
7. **Polish** — focus-frame dimming everywhere, headline reveal-on-enter, dark-mode pass, reduced-motion pass, font subsetting. *Commit: "polish(marketing): scroll focus, dark mode, reduced-motion"*
8. **Verification** — manual walkthrough, Lighthouse run, keyboard nav check, screenshot before/after for both pages. Reported back to you, no commit unless changes are needed.

Total estimated change: ~50 % of `index.html`, ~40 % of `guide.html` rewritten; `styles.css` rewritten end-to-end with the new system.

---

## 9. Open questions / risks

- **Self-hosting fonts**: Fraunces and JetBrains Mono add ~38 KB total. If you'd rather keep zero font assets in the repo, I can fall back to system serifs (Iowan/Charter on Apple, Cambria elsewhere) but the editorial feel weakens noticeably. *Recommend: self-host subsetted woff2.*
- **Pinned workflow on mobile**: scroll-jacking on small screens is the worst place for it. Mobile gets a regular tab interaction with subtle entrance animation only. Confirmed in the plan, flagging it explicitly so there's no surprise.
- **Branch hygiene**: there are a lot of unrelated working-tree modifications on this branch right now (Dockerfile, CI workflows, docs, etc., visible in `git status`). I'll only commit changes under `docs/marketing/` for this work — anything else stays untouched.
- **Brand mark**: the "Context Tools" wordmark + small logo is kept as-is. If you want a fresh wordmark, that's a separate piece of work and I won't blur scope.

---

## 10. What success looks like

When this is done:

- A first-time visitor lands, reads one editorial headline, sees one terminal, and scrolls.
- The workflow section feels like a deliberate moment, not another grid.
- They never see two ideas presented twice in different visuals.
- The page reads on a phone without scroll-hijack frustration.
- No icon, colour, or shadow shouts louder than the words next to it.
- "Looks like a stock template" stops being the first reaction.
