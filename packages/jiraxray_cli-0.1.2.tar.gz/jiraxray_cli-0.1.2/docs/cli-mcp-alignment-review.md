# CLI And MCP Alignment Review

This review evaluates `jiraxray-cli` against three goals:

- Be simple and useful for people running commands directly.
- Be predictable and composable for scripts and CI pipelines.
- Be structured enough for AI agents to discover, plan, and execute Xray/Jira workflows safely.

It also compares the current CLI with the inspected VS Code Marketplace extension
`DanielChaconBaquerizo.agente-jira-xray`, which ships an MCP server and a simple
Node CLI around Jira and Xray operations.

## Executive Assessment

The current solution should remain CLI-first. A CLI is the more durable primary
interface for humans, CI, Docker, shell scripts, and agent tool use. MCP should
be treated as an optional adapter over the same service layer, not as the core
product shape.

The MCP extension is useful because its command set is smaller and maps to
common day-to-day Xray work:

- configure/test connection
- create Jira issue
- create Xray test
- create test execution
- link issue to test execution
- add tests to execution
- get issue details/summary
- get test run
- upload evidence

The current CLI is stronger in migration, command discovery, local workflows,
bulk imports, and result imports. The extension is stronger in Jira-backed
operational flows and keeping the happy path simple.

The product direction should be: keep the CLI broad enough for real automation,
but organize the main operational workflows around the simpler command model
used by the MCP extension.

## Current Strengths

- The command manifest is a strong agent-facing primitive.
- `commands`, `command`, `--json`, and `--view` give agents and scripts a stable
  discovery pattern.
- Migration flows are meaningfully better than the MCP extension because they
  support inspect, map, transform, validate, and preview before remote writes.
- Xray REST v2 result imports and bulk test imports cover important CI flows
  that the extension does not focus on.
- Suite workflows are a useful bridge between simple commands and repeatable
  automation.
- Tests already pin REST and GraphQL operation shapes, which is the right
  approach before live credentials exist.

## Current Gaps

### Product Gaps

- Jira REST support is missing, so the CLI cannot yet match the extension for
  generic issue creation, issue summaries, issue details, or Jira issue links.
- The command surface is currently split between low-level Xray primitives and
  migration workflows, but the day-to-day operational path is less obvious than
  the MCP extension's command set.
- Some command names expose Xray internals instead of user intent. For example,
  `testruns upload-evidence` is accurate, but users often think in terms of
  "attach evidence to this execution/test".
- There is no guided "happy path" command group for a tester or agent doing:
  create test, create execution, add test, get run, upload evidence.

### Agent Gaps

- The manifest describes arguments, risk, and side effects, but does not yet
  define output schemas, examples, or id-kind constraints clearly enough.
- Commands that need numeric Jira issue IDs do not consistently help agents
  resolve keys to IDs.
- There is no machine-readable capability matrix that separates read-only,
  write, idempotent, retry-safe, and dangerous operations beyond the current
  manifest fields.
- Validation is good for local files, but remote-write preflight behavior is
  incomplete.

### CLI Automation Gaps

- Remote write commands generally lack `--dry-run`.
- Exit codes distinguish success/failure, but not categories such as validation
  failure, auth failure, remote conflict, and transient failure.
- JSON output is structured, but command result shapes are not documented as
  stable contracts.
- Pagination is not yet available for commands that can exceed a single page.
- There is no built-in wait/poll option for asynchronous Xray operations beyond
  bulk import status.

## Capability Matrix

| Capability | Current CLI | MCP Extension | Recommended Direction |
| --- | --- | --- | --- |
| Configure credentials | Partial via env/profile | Yes via VS Code secrets/env | Keep env/profile, add `profile set` for non-secret defaults only |
| Test connection | `diagnose` local only | Jira and Xray live checks | Add `diagnose --live` or `auth test` |
| Create generic issue | No | Yes | Add after Jira REST client exists |
| Get issue details | No | Yes | Add after Jira REST client exists |
| Get issue summary | No | Yes | Add after Jira REST client exists |
| Create test | Yes | Yes | Keep, add description and key/id resolution support |
| Update test steps | Yes | No | Keep |
| Search tests | Yes | No | Keep, add pagination |
| Create execution | Yes | Yes | Keep |
| Add tests to execution | Yes | Yes | Keep, add key-to-id resolution |
| Link issue to execution | No | Yes | Add after Jira REST client exists |
| Get test run | Yes | Yes | Keep, add polling/wait options |
| Upload evidence | Yes | Yes | Keep, add file validation and size guidance |
| Import results | Yes | No | Keep, improve metadata support |
| Bulk import tests | Yes | No | Keep |
| Zephyr migration | Yes | No | Keep as differentiator |
| Workflow suites | Yes | No | Keep, tighten schema and examples |
| MCP server | No | Yes | Optional wrapper later over CLI service layer |

## Recommended Command Model

The CLI should preserve the current grouped style, but add the MCP extension's
simpler operational path. The target command families should be:

| Family | Purpose |
| --- | --- |
| `auth` or `diagnose` | Credentials, profile, live connectivity checks |
| `issues` | Generic Jira issue read/create/link operations |
| `tests` | Xray test library operations |
| `executions` | Test execution creation and test association |
| `testruns` | Test run lookup, status, evidence |
| `results` | Automated execution result imports |
| `features` | Cucumber/Gherkin import/export if added later |
| `migrate` and `zephyr` | Migration planning and conversion |
| `workflow` and `suite` | Repeatable local automation |

Preferred command additions:

```text
jiraxray-cli diagnose --live --json
jiraxray-cli issues create --type "Bug" --summary "..." --description "..."
jiraxray-cli issues get --issue QA-123 --json
jiraxray-cli issues summary --issue QA-123 --json
jiraxray-cli issues link --inward QA-200 --outward QA-123 --type Test
jiraxray-cli executions add-tests --execution QA-200 --tests QA-201,QA-202
jiraxray-cli testruns get --execution QA-200 --test QA-201 --wait --json
jiraxray-cli testruns upload-evidence --run RUN_ID --files screenshot.png,report.json
```

Backward-compatible aliases can preserve the currently implemented names:

```text
--execution-id -> --execution
--test-id -> --test
--test-ids -> --tests
--test-run-id -> --run
```

## Priority Plan

### P1: Match The Simple Operational MCP Flow

Goal: make the CLI cover the same simple Jira/Xray workflow that made the MCP
extension attractive, while preserving CLI automation quality.

Work items:

- Add Jira REST config fields:
  `JIRA_BASE_URL`, `JIRA_EMAIL`, `JIRA_API_TOKEN`, and optional
  `JIRA_PROJECT_KEY`.
- Add a Jira REST client using Basic auth and Jira REST v3.
- Add `diagnose --live` to validate Jira and Xray credentials with real calls.
- Add `issues create`, `issues get`, and `issues summary`.
- Add `issues link` for Jira issue links, including the Xray default link type
  used by the extension.
- Add key-to-id resolution for Xray GraphQL commands that currently expect
  numeric issue IDs.
- Add `--wait` support to `testruns get`, based on the extension's retry logic
  for asynchronously materialized test runs.
- Add offline contract tests for every Jira REST endpoint and GraphQL operation.

Acceptance criteria:

- A user can create a test, create an execution, add the test, get the run, and
  upload evidence with simple commands.
- The same flow works with `--json` for agents and scripts.
- Commands accept Jira keys where users naturally have keys, while still
  supporting numeric issue IDs.
- All remote-write commands have clear failure messages and non-zero exit codes.

### P2: Tighten Agent And Automation Contracts

Goal: make the CLI easier for AI agents and CI pipelines to use safely without
guessing.

Work items:

- Extend manifest entries with:
  output schema summary, examples, accepted ID formats, auth requirements, and
  whether the command supports `--dry-run`.
- Document stable JSON envelopes for every command.
- Add validation-only or dry-run behavior for remote write commands where the
  API allows meaningful preflight.
- Add pagination flags:
  `--limit`, `--start`, and eventually `--all` for list/search commands.
- Normalize CSV flags and repeated flags:
  allow both `--tests A,B` and repeated `--test A --test B` if practical.
- Add structured error codes in JSON output:
  `validation_error`, `auth_error`, `remote_error`, `not_found`,
  `transient_error`, `internal_error`.
- Add workflow schema validation for `.jiraxray-cli/workflows/*.yaml`.

Acceptance criteria:

- An agent can call `commands --json`, pick the right command, validate inputs,
  and understand the output without reading README prose.
- CI scripts can branch reliably on JSON `ok`, error code, and exit code.
- Human users still get concise text output by default.

### P3: Improve High-Value Xray Workflows

Goal: build beyond MCP parity into workflows that make this CLI genuinely useful
for QA teams and automation engineers.

Work items:

- Add richer result import metadata support where Xray REST v2 supports it.
- Add `features import` and `features export` for Cucumber/Gherkin workflows if
  authenticated API examples confirm the exact supported shapes.
- Add `tests export` or `tests bulk-export` if useful for review and backup.
- Add reviewed migration-plan to Xray bulk-import JSON export once payload shape
  is verified.
- Add suite templates for common flows:
  smoke execution, evidence upload, result import, and migration review.
- Add opt-in live smoke tests gated behind `XRAY_LIVE_TESTS=1` and
  `JIRA_LIVE_TESTS=1`.

Acceptance criteria:

- The CLI is not just MCP-equivalent; it is better for migration, CI, and
  repeatable QA automation.
- New commands are backed by offline contract tests and optional live smoke
  coverage.

## Design Principles

- CLI remains the primary interface.
- MCP, if added, should wrap the same service layer and manifest instead of
  reimplementing behavior.
- Every remote-write command should be explicit about side effects.
- Human defaults should be concise; agent/script mode should be JSON-first and
  schema-stable.
- Commands should accept the identifiers users naturally have, usually Jira
  keys, and resolve numeric issue IDs internally when Xray GraphQL requires
  them.
- Migration commands should stay separate from operational commands because
  their review-before-write workflow is a product differentiator.

## Recommended Roadmap

### Iteration 1

- Add Jira REST config and client.
- Add `issues get`, `issues summary`, and `diagnose --live`.
- Add key-to-id resolver shared by Xray GraphQL commands.
- Add tests for Jira auth headers, issue lookup, and issue summary shaping.

### Iteration 2

- Add `issues create` and `issues link`.
- Add aliases for simpler flags:
  `--execution`, `--tests`, `--test`, and `--run`.
- Add `testruns get --wait`.
- Add workflow suite support for `testruns get` and evidence upload.

### Iteration 3

- Extend manifest metadata and output contracts.
- Add structured error codes.
- Add dry-run/preflight support for write commands.
- Update README and `docs/cli.md` around the simple operational flow.

### Iteration 4

- Add higher-level workflow templates.
- Add live smoke test harness.
- Evaluate MCP wrapper as an optional secondary interface.

## What Not To Do

- Do not move the core product to MCP-first. That would reduce usefulness for
  shell users, CI, Docker, and non-agent workflows.
- Do not duplicate business logic between CLI and MCP. Keep all behavior in
  clients/services/workflows.
- Do not add broad Jira administration features. Keep Jira support limited to
  what Xray workflows need.
- Do not hide destructive or state-changing behavior inside high-level workflow
  commands without clear dry-run and confirmation patterns.

## Bottom Line

The MCP extension's command set is a good model for the simple operational path.
This project should adopt that simplicity while keeping its stronger CLI,
migration, workflow, and agent-discovery foundations.

The next best investment is Jira REST support plus key-to-id resolution. That
unlocks the remaining MCP-aligned commands and makes the CLI feel natural to
both humans and agents.
