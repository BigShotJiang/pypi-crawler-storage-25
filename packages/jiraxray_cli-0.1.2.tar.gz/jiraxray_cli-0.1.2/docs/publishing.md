# Build, Install, And Publish

This project is packaged as a standard Python distribution with console scripts
for `jiraxray-cli`.

## Install From PyPI

PyPI is the only documented installation source for users.

```bash
python -m pip install jiraxray-cli
jiraxray-cli --version
```

With `uv` as an isolated command-line tool:

```bash
uv tool install jiraxray-cli
jiraxray-cli --help
```

## Build Locally

```bash
make sync
make package
```

`uv build` writes both distributions under `dist/`:

- `jiraxray_cli-<version>.tar.gz`
- `jiraxray_cli-<version>-py3-none-any.whl`

## Verify A Built Distribution

```bash
make smoke
```

These smoke tests import the installed package and verify both console scripts.

Local builds are for development and release verification only. User
installation should use PyPI.

## Publish A Public Release

The repository includes `.github/workflows/release.yml`. Pushing a `v*` tag
validates the package, builds the wheel and source distribution, publishes them
to PyPI, creates a GitHub Release, and pushes a public container package to
GitHub Container Registry.

```bash
make tag
```

Before publishing a new version:

1. Update the version in `pyproject.toml` and `src/jiraxray_cli/__init__.py`.
2. Update `CHANGELOG.md`.
3. Ensure the `pypi` environment exists in GitHub repository settings.
4. Ensure PyPI Trusted Publishing is configured for:
   - owner: `reignonu13`
   - repository: `agent-jiraXray-cli`
   - workflow: `release.yml`
   - environment: `pypi`

After the workflow completes, Python users install from PyPI:

```bash
python -m pip install jiraxray-cli
```

## Manual PyPI Recovery

The repository also includes `.github/workflows/publish.yml` as a manual PyPI
recovery workflow if a tag release is interrupted before publishing.

Before using it:

1. Create a `pypi` environment in GitHub repository settings.
2. Configure a PyPI Trusted Publisher for:
   - owner: `reignonu13`
   - repository: `agent-jiraXray-cli`
   - workflow: `publish.yml`
   - environment: `pypi`
3. Ensure the version in `pyproject.toml` and `src/jiraxray_cli/__init__.py`
   is updated.
4. Run the `Publish PyPI` workflow manually.

The workflow validates, builds, smoke-tests the wheel and sdist, then runs
`uv publish` using PyPI Trusted Publishing.
