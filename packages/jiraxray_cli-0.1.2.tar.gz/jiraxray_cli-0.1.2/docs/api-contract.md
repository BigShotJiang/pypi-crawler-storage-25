# Jira And Xray API Contract Checks

The CLI is tested without live Jira or Xray credentials by pinning unit tests to
the documented Jira Cloud and Xray Cloud API shapes used by the code.

## Covered Contracts

- REST v2 authentication: `POST /api/v2/authenticate`
- Jira REST v3:
  - `GET /rest/api/3/myself`
  - `POST /rest/api/3/issue`
  - `GET /rest/api/3/issue/{issueIdOrKey}`
  - `POST /rest/api/3/issueLink`
- REST v2 execution imports:
  - `/api/v2/import/execution`
  - `/api/v2/import/execution/junit`
  - `/api/v2/import/execution/cucumber`
  - `/api/v2/import/execution/nunit`
  - `/api/v2/import/execution/xunit`
  - `/api/v2/import/execution/testng`
  - `/api/v2/import/execution/robot`
- REST v2 bulk test imports:
  - `POST /api/v2/import/test/bulk`
  - `GET /api/v2/import/test/bulk/{jobId}/status`
- GraphQL query and mutation shapes for:
  - `getProjectSettings(projectIdOrKey: ...)`
  - `getTests(jql: ..., limit: ...)`
  - `createTest(testType: ..., jira: ...)`
  - `addTestStep(issueId: ..., step: ...)`
  - `removeAllTestSteps(issueId: ...)`
  - `addTestsToTestSet(issueId: ..., testIssueIds: ...)`
  - `addTestsToTestPlan(issueId: ..., testIssueIds: ...)`
  - `createTestExecution(testIssueIds: ..., jira: ...)`
  - `addTestsToTestExecution(issueId: ..., testIssueIds: ...)`
  - `getTestRuns(testExecIssueIds: ..., testIssueIds: ..., limit: ...)`
  - `addEvidenceToTestRun(id: ..., evidence: ...)`
- HTTP retry behavior for documented Xray rate limits and transient server
  responses.

## Required Validation

Run these before accepting API-facing changes:

```bash
uv run ruff check .
uv run mypy src
uv run pytest
uv run jiraxray-cli commands --json
```

Unit tests are the source of truth until live credentials are available. Once
tokens exist, add separate opt-in live smoke suites that only run read-only
commands by default.
