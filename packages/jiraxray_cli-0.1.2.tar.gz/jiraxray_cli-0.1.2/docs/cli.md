# CLI Reference

## Diagnostics

- `diagnose`: checks environment, profile, and endpoint configuration.
- `diagnose --live`: validates Jira and Xray live connectivity.
- `commands`: returns the agent-facing command manifest.
- `command NAME`: returns detailed help for one command.
- `init`: creates project-local AI guidance for Codex, Claude Code, and GitHub Copilot.

```bash
jiraxray-cli init --path . --tool all --suite-name "Payments QA" --json
```

## Profile

- `profile init`: writes `.jiraxray-cli/profile.json` with non-secret defaults.

## Migration

- `zephyr inspect --source zephyr-export.xlsx --out inspect.md`
- `migrate map init --source zephyr-export.xlsx --project-key KEY --out zephyr-to-xray.yaml`
- `migrate map validate --mapping zephyr-to-xray.yaml`
- `migrate transform --source zephyr-export.xlsx --mapping zephyr-to-xray.yaml --out xray-import-plan.json`
- `migrate validate --input xray-import-plan.json`
- `migrate preview --input xray-import-plan.json --out migration-preview.md`

## Discovery

- `discover project --project-key KEY`: reads Xray project settings and useful status metadata.

## Jira Issues

- `issues create --type TYPE --summary TEXT --description TEXT --project-key KEY`
- `issues get --issue KEY_OR_ID`
- `issues summary --issue KEY_OR_ID`
- `issues link --inward KEY --outward KEY --type Test`

## Test Library

- `tests search --jql JQL`
- `tests create --project-key KEY --summary TEXT --test-type Manual`
- `tests update-steps --issue-id ID --steps-file steps.json`
- `tests import-bulk --path xray-tests.json`
- `tests import-status --job-id JOB_ID`
- `sets add-tests --set-id ID --test-ids 1,2,3`
- `plans add-tests --plan-id ID --test-ids 1,2,3`

## Executions And Results

- `executions create --project-key KEY --summary TEXT --test-ids 1,2`
- `executions add-tests --execution ID_OR_KEY --tests ID_OR_KEY,ID_OR_KEY`
- `testruns get --execution ID_OR_KEY --test ID_OR_KEY --wait`
- `testruns upload-evidence --run RUN_ID --files screenshot.png,report.json`
- `results import --format junit --path report.xml`

## Workflows

- `workflow validate-import --format junit --path report.xml`
- `workflow sync-library --source tests.yaml --project-key KEY --dry-run`

## Suites

- `suite init`
- `suite list`
- `suite validate NAME`
- `suite explain NAME`
- `suite run NAME --dry-run`
- `suite run NAME`
