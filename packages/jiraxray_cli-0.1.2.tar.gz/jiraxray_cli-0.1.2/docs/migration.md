# Zephyr To Xray Migration

This CLI helps QA teams move Zephyr Squad Excel exports into an Xray Cloud-ready
import plan. The first migration milestone is intentionally read-only: inspect,
map, transform, validate, and preview before any Xray write is attempted.

## First Workflow

```bash
jiraxray-cli zephyr inspect --source zephyr-export.xlsx --out inspect.md
jiraxray-cli migrate map init --source zephyr-export.xlsx --project-key QA --out zephyr-to-xray.yaml
jiraxray-cli migrate map validate --mapping zephyr-to-xray.yaml
jiraxray-cli migrate transform --source zephyr-export.xlsx --mapping zephyr-to-xray.yaml --out xray-import-plan.json
jiraxray-cli migrate validate --input xray-import-plan.json
jiraxray-cli migrate preview --input xray-import-plan.json --out migration-preview.md
```

## What Inspection Finds

- detected columns
- candidate test count
- tests with manual steps
- duplicate summaries
- missing expected fields
- BDD/Gherkin indicators that need review
- attachment indicators that need review

## Mapping

`migrate map init` creates a YAML file that should be reviewed before transform.
It sets the target Xray project, default test type, duplicate policy, field
names, and optional priority/status mappings.

The default duplicate policy is `warn`; supported values are `warn`, `skip`, and
`create`.

## Import Plan

`migrate transform` writes a local JSON import plan. This is not sent to Xray.
The plan is designed for review, versioning, and later bulk-import support.

For already-reviewed Xray bulk import JSON, use the REST v2 asynchronous import
flow:

```bash
jiraxray-cli tests import-bulk --path xray-tests.json --json
jiraxray-cli tests import-status --job-id JOB_ID --json
```

Keep bulk import files to 1000 tests or fewer per Xray Cloud REST v2 request.

## Limits

- First source format is Zephyr Squad Excel.
- Live import is limited to caller-provided Xray bulk import JSON; Zephyr import
  plans still require review/conversion before sending.
- Attachments and BDD/Gherkin tests are detected as review items, not migrated.
