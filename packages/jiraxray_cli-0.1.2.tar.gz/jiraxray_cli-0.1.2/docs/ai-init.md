# AI Init

`init` creates project-local AI guidance for Codex, Claude Code, and GitHub Copilot.

```bash
jiraxray-cli init --path /path/to/test-solution --tool all --json
```

Use `--tool codex`, `--tool claude`, or `--tool copilot` to generate one host.
Use `--force` to overwrite generated files.

The generated layout is token-efficient:

- always-on files stay short
- skill bodies explain when to use the skill
- `references/*.md` files hold detailed workflows and are read only when needed

Agents should start with:

```bash
jiraxray-cli commands --json
jiraxray-cli diagnose --json
```

Use compact output for normal planning. Use `--view full` when compact output omits details needed for a decision. Avoid raw output unless preserving an Xray response shape is required.
