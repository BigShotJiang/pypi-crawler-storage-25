# Automation Workflows

Workflow files are YAML documents under `.jiraxray-cli/workflows`.

```yaml
name: smoke-import
description: Validate and import smoke tests.
inputs:
  project_key:
    type: string
    required: true
steps:
  - name: discover project
    command: discover project
    args:
      project_key: "${project_key}"
  - name: search smoke tests
    command: tests search
    args:
      jql: "project = ${project_key} AND labels = smoke"
```

Suites are deterministic. Agents can generate, review, or select workflows, but the CLI does not embed AI behavior.

## Library Sync

`workflow sync-library` accepts JSON or YAML:

```yaml
tests:
  - project_key: DEMO
    summary: User can sign in
    test_type: Manual
    steps:
      - action: Open the sign-in page
        result: The sign-in form is visible
      - action: Submit valid credentials
        result: The dashboard opens
```

Always run `--dry-run` before creating tests.

## Jira And Xray Operational Flow

Use this flow for the common tester path that the CLI shares with MCP-style
tooling:

```bash
jiraxray-cli diagnose --live --json
jiraxray-cli issues summary --issue QA-123 --json
jiraxray-cli executions create --project-key QA --summary "Smoke execution" --json
jiraxray-cli executions add-tests --execution QA-200 --tests QA-201,QA-202 --json
jiraxray-cli testruns get --execution QA-200 --test QA-201 --wait --json
jiraxray-cli testruns upload-evidence --run RUN_ID --files screenshot.png --json
```

Prefer Jira keys in human-facing commands. The service resolves keys to numeric
Jira issue IDs when Xray GraphQL requires them.

## Suite Guidance

Suites may use `issues create`, `issues link`, and `executions add-tests` for
repeatable setup. Keep issue summaries, project keys, test ids, and report paths
as workflow inputs when they vary between projects or releases.
