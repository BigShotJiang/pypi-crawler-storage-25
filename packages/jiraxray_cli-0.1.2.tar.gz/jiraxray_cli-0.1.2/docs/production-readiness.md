# Production Readiness Review

This is the current gap list for turning the CLI into a dependable Zephyr to
Xray migration and test-management tool.

## Done

- Installable Python CLI entry point: `jiraxray-cli`.
- Non-secret profile and environment-based Xray credentials.
- Human and JSON command discovery for users, scripts, and agents.
- Token-efficient AI setup for Codex, Claude Code, and GitHub Copilot.
- Zephyr Squad Excel inspection, mapping, transform, validation, and preview.
- Xray GraphQL operations for project discovery, test search/create, step
  replacement, test set/plan association, and test execution creation.
- Jira REST v3 operations for live connection checks, issue creation, issue
  details, issue summaries, and issue linking.
- Xray GraphQL operations for adding tests to executions, reading test runs,
  and uploading test-run evidence.
- Human-friendly execution/test-run aliases such as `--execution`, `--tests`,
  `--test`, and `--run`, plus `testruns get --wait` polling.
- Generated agent and skill guidance that includes a concise learning loop for
  updating skills, references, or the agent when repeated workflows or command
  constraints are discovered.
- Xray REST v2 execution result imports.
- Xray REST v2 asynchronous bulk test import and job-status commands.
- Retry handling for Xray rate-limit and transient server responses.
- Offline unit tests for documented Xray API operation shapes.
- Local build and installed-package smoke tests for wheel and source
  distributions.
- GitHub Actions CI, GitHub Release, GHCR package, and PyPI Trusted Publishing
  workflows.

## Next Iterations

- Use `docs/cli-mcp-alignment-review.md` as the product roadmap for aligning
  the CLI with the simpler MCP-style operational workflow while keeping the CLI
  suitable for humans, agents, and automation.
- Add a reviewed Zephyr import-plan to Xray bulk-import JSON exporter once the
  exact bulk import payload shape is confirmed from an authenticated doc/sample.
- Add opt-in live smoke tests gated by `XRAY_LIVE_TESTS=1`, starting with
  read-only commands.
- Add pagination support for search/list commands that can exceed 100 results.
- Add explicit Jira field validation helpers for project-specific required
  fields before write commands.
- Add dry-run previews for every remote write command.
- Add structured JSON schemas for local migration plans, sync-library files,
  steps files, and workflow files.
- Configure the PyPI project and GitHub `pypi` environment before the first PyPI
  release.

## Testing Rule

Until live credentials are available, every Xray-facing feature must have an
offline unit test that asserts the documented REST endpoint or GraphQL operation
shape. Live tests should supplement those tests, not replace them.
