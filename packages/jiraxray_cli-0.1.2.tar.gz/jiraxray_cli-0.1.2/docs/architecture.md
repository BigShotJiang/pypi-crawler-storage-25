# Architecture

## Layers

- CLI: parses commands, loads profile defaults, shapes output, and routes to services.
- Config: reads non-secret profile settings and environment-only credentials.
- Clients: wrap Jira Cloud REST v3 plus Xray Cloud REST v2 and GraphQL calls.
- Services: exposes workflow-oriented operations over low-level API calls.
- Manifest: describes commands for agents with schemas, risks, output shapes, and fallbacks.
- Suites: runs local YAML workflows for deterministic automation.
- Skills: teach agents when to use compact commands, workflows, and full output.

## Jira And Xray Cloud API Use

Jira REST v3 is used for generic issue operations needed by Xray workflows:
issue creation, issue details, compact summaries, issue links, current-user
connectivity checks, and key-to-id resolution.

Xray REST v2 is used for authentication and heavy import operations. Xray
GraphQL is used for CRUD-style entity management across tests, folders,
preconditions, sets, plans, executions, runs, statuses, and evidence.

Server/Data Center support is intentionally deferred to a later adapter because auth, URLs, and API semantics differ from Xray Cloud.

## Secrets

Secrets are read from environment variables only. Profiles may store base URLs,
regions, default Jira project keys, and output preferences, but must not store
API keys, API tokens, client secrets, or bearer tokens.

## Output Model

Compact JSON is the default agent contract. Full output is available for humans or deeper investigation. Raw output is reserved for callers that need the Xray response shape.

## Suite Model

Suite YAML files chain known CLI operations. Dry-run mode validates and summarizes steps without mutating Xray. AI tools should use suites for repeatable workflows and reserve model reasoning for ambiguous mapping, review, or exception handling.
