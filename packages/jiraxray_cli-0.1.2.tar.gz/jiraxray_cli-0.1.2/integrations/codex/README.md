# Codex Integration

Install this repository as a Codex-accessible project or package the included skills with the CLI release.

Agents should load `jiraxray-cli` skill instructions and use the globally installed command:

```bash
jiraxray-cli commands --json
```
