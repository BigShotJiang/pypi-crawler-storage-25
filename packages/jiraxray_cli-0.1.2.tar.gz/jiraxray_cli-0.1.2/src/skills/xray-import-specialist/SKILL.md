---
name: xray-import-specialist
description: Use for validating and importing Xray tests or execution results, including bulk test imports, result formats, and safe pre-import review.
---

# Xray Import Specialist

Use this skill for importing tests or execution results into Xray Cloud.

Prefer deterministic validation before import. For execution results, use `results import` with one of:

- `xray`
- `junit`
- `cucumber`
- `nunit`
- `xunit`
- `testng`
- `robot`

Use dry-run workflow suites when planning repeatable imports.
