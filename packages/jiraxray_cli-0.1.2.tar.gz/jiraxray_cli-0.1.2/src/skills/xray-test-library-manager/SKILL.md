---
name: xray-test-library-manager
description: Use for creating, searching, updating, and organizing Xray tests, manual steps, test sets, and test plans through jiraxray-cli.
---

# Xray Test Library Manager

Use this skill for creating, searching, and organizing Xray tests.

Prefer:

- `tests search` before creating duplicates
- `discover project` before using project-specific settings
- `tests update-steps` with a reviewed JSON file for manual test steps
- `sets add-tests` and `plans add-tests` for organization

Keep JQL narrow because Xray GraphQL limits page sizes and query cost.
