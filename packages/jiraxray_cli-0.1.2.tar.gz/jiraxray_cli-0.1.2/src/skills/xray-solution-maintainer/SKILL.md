---
name: xray-solution-maintainer
description: Use when improving jiraxray-cli itself, including command design, tests, docs, generated agents, generated skills, production readiness, and concise learning-loop updates.
---

# Xray Solution Maintainer

Use this skill when improving `jiraxray-cli`, its docs, generated agents,
generated skills, command manifest, or production readiness.

Guardrails:

- Keep the CLI as the primary runtime surface.
- Treat MCP as an optional wrapper over shared services, not the product core.
- Preserve concise human defaults and stable JSON for agents/scripts.
- Keep secrets in environment variables; profiles stay non-secret.
- Add or update tests for every API-facing command shape.

Learning loop:

1. Update generated skills when a workflow becomes repeatable or confusing.
2. Update references instead of always-on text when detail is longer than a few lines.
3. Update the agent only when purpose, boundaries, or decision rules change.
4. Remove stale guidance when command behavior changes.
5. Validate with targeted tests before finishing.
