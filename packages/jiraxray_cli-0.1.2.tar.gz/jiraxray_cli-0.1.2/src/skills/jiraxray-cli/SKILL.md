---
name: jiraxray-cli
description: Use when working with this repository's Jira/Xray CLI, including command discovery, diagnostics, profiles, JSON output, automation, generated agents, and safe command sequencing.
---

# jiraxray-cli

Use this skill when an agent needs to inspect, manage, or automate Jira/Xray
test-management work through this CLI.

Start with:

```bash
jiraxray-cli diagnose --json
jiraxray-cli commands --json
```

Prefer compact output. Use `--view full` only when compact output is not enough
to choose the next command.

Do not ask the user for secrets. The CLI reads Xray and Jira secrets from the
environment.

Learning rule: update a skill, reference, or agent only when a repeated
workflow, command gotcha, API constraint, or repo convention would reduce future
tokens or errors. Keep the change concise and source-backed.
