---
name: xray-automation-suite-author
description: Use when creating, validating, or maintaining deterministic .jiraxray-cli workflow suites for repeatable Jira/Xray CLI automation.
---

# Xray Automation Suite Author

Use this skill when creating repeatable `.jiraxray-cli/workflows/*.yaml` suites.

Suites should be deterministic and should not embed AI decisions. Use agents to generate or review workflow files, then run:

```bash
jiraxray-cli suite validate <name> --json
jiraxray-cli suite run <name> --dry-run --json
```

Keep workflow steps high level and use typed inputs for values that change across projects.
