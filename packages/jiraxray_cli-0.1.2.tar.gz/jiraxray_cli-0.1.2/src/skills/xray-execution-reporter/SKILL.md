---
name: xray-execution-reporter
description: Use for Xray executions, test runs, evidence, result imports, execution reporting, and CI reporting workflows through jiraxray-cli.
---

# Xray Execution Reporter

Use this skill for test executions, test runs, statuses, evidence, and reporting-oriented workflows.

Prefer `executions create` for deterministic execution setup and `results import` for automated run output. Use compact output first, then inspect full output only when warnings or identifiers are missing.
