"""Console entry point for jiraxray-cli."""

from __future__ import annotations

import argparse
import json
import sys
from collections.abc import Sequence
from pathlib import Path
from typing import cast

from . import __version__
from .ai_init import init_result_data, run_init
from .config import resolve_config, write_default_profile
from .manifest import command_manifest, manifest_as_json
from .migration.mapping import (
    default_mapping_for_export,
    load_mapping,
    mapping_to_json,
    validate_mapping,
    write_mapping,
)
from .migration.plan import (
    load_import_plan,
    plan_summary,
    render_preview_markdown,
    transform_export,
    validate_import_plan,
    write_import_plan,
)
from .migration.zephyr import (
    inspect_zephyr_excel,
    inspection_to_json,
    render_inspection_markdown,
)
from .models import CliResult, JsonObject, StepInput, ViewMode
from .output import render_result
from .service import XrayService
from .workflows.imports import (
    load_sync_library,
    sync_tests_from_library,
    validate_bulk_test_import,
    validate_result_import,
    validate_sync_library,
)
from .workflows.runner import (
    dry_run_workflow,
    explain_workflow,
    list_workflows,
    load_workflow,
    resolved_workflow_steps,
    validate_workflow,
    write_example_workflow,
)


def parse_csv(value: str) -> list[str]:
    """Parse a comma-separated command argument into non-empty strings."""

    return [item.strip() for item in value.split(",") if item.strip()]


def load_steps(path: Path) -> list[StepInput]:
    """Load manual steps from a JSON file."""

    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, list):
        raise ValueError("Steps file must contain a JSON list")
    steps: list[StepInput] = []
    for item in value:
        if not isinstance(item, dict) or not isinstance(item.get("action"), str):
            raise ValueError("Each step requires an action string")
        data = item.get("data")
        result = item.get("result")
        steps.append(
            StepInput(
                action=item["action"],
                data=data if isinstance(data, str) else None,
                result=result if isinstance(result, str) else None,
            )
        )
    return steps


def add_common_flags(parser: argparse.ArgumentParser) -> None:
    """Add common output flags to a parser."""

    parser.add_argument("--json", action="store_true", help="Render JSON output.")
    parser.add_argument("--view", choices=["compact", "full", "raw"], default="compact")


def build_parser() -> argparse.ArgumentParser:
    """Build the CLI argument parser."""

    parser = argparse.ArgumentParser(prog="jiraxray-cli")
    parser.add_argument("--version", action="version", version=__version__)
    subparsers = parser.add_subparsers(dest="command")

    diagnose = subparsers.add_parser("diagnose")
    diagnose.add_argument("--live", action="store_true")
    add_common_flags(diagnose)

    commands = subparsers.add_parser("commands")
    add_common_flags(commands)

    command_help = subparsers.add_parser("command")
    command_help.add_argument("name")
    add_common_flags(command_help)

    init = subparsers.add_parser("init")
    init.add_argument("--path", default=".")
    init.add_argument("--tool", choices=["all", "codex", "claude", "copilot"], default="all")
    init.add_argument("--suite-name", default="this Xray test automation solution")
    init.add_argument("--force", action="store_true")
    add_common_flags(init)

    profile = subparsers.add_parser("profile")
    profile_sub = profile.add_subparsers(dest="profile_command")
    profile_init = profile_sub.add_parser("init")
    profile_init.add_argument("--force", action="store_true")
    add_common_flags(profile_init)

    discover = subparsers.add_parser("discover")
    discover_sub = discover.add_subparsers(dest="discover_command")
    discover_project = discover_sub.add_parser("project")
    discover_project.add_argument("--project-key", required=True)
    add_common_flags(discover_project)

    issues = subparsers.add_parser("issues")
    issues_sub = issues.add_subparsers(dest="issues_command")
    issues_create = issues_sub.add_parser("create")
    issues_create.add_argument("--type", required=True, dest="issue_type")
    issues_create.add_argument("--summary", required=True)
    issues_create.add_argument("--description")
    issues_create.add_argument("--project-key")
    add_common_flags(issues_create)
    issues_get = issues_sub.add_parser("get")
    issues_get.add_argument("--issue", required=True)
    add_common_flags(issues_get)
    issues_summary = issues_sub.add_parser("summary")
    issues_summary.add_argument("--issue", required=True)
    add_common_flags(issues_summary)
    issues_link = issues_sub.add_parser("link")
    issues_link.add_argument("--inward", required=True)
    issues_link.add_argument("--outward", required=True)
    issues_link.add_argument("--type", default="Test", dest="link_type")
    add_common_flags(issues_link)

    tests = subparsers.add_parser("tests")
    tests_sub = tests.add_subparsers(dest="tests_command")
    tests_search = tests_sub.add_parser("search")
    tests_search.add_argument("--jql", required=True)
    tests_search.add_argument("--limit", type=int, default=25)
    add_common_flags(tests_search)
    tests_create = tests_sub.add_parser("create")
    tests_create.add_argument("--project-key", required=True)
    tests_create.add_argument("--summary", required=True)
    tests_create.add_argument("--test-type", default="Manual")
    add_common_flags(tests_create)
    tests_steps = tests_sub.add_parser("update-steps")
    tests_steps.add_argument("--issue-id", required=True)
    tests_steps.add_argument("--steps-file", required=True)
    add_common_flags(tests_steps)
    tests_import_bulk = tests_sub.add_parser("import-bulk")
    tests_import_bulk.add_argument("--path", required=True)
    add_common_flags(tests_import_bulk)
    tests_import_status = tests_sub.add_parser("import-status")
    tests_import_status.add_argument("--job-id", required=True)
    add_common_flags(tests_import_status)

    sets = subparsers.add_parser("sets")
    sets_sub = sets.add_subparsers(dest="sets_command")
    sets_add = sets_sub.add_parser("add-tests")
    sets_add.add_argument("--set-id", required=True)
    sets_add.add_argument("--test-ids", required=True)
    add_common_flags(sets_add)

    plans = subparsers.add_parser("plans")
    plans_sub = plans.add_subparsers(dest="plans_command")
    plans_add = plans_sub.add_parser("add-tests")
    plans_add.add_argument("--plan-id", required=True)
    plans_add.add_argument("--test-ids", required=True)
    add_common_flags(plans_add)

    executions = subparsers.add_parser("executions")
    executions_sub = executions.add_subparsers(dest="executions_command")
    executions_create = executions_sub.add_parser("create")
    executions_create.add_argument("--project-key", required=True)
    executions_create.add_argument("--summary", required=True)
    executions_create.add_argument("--test-ids", default="")
    add_common_flags(executions_create)
    executions_add = executions_sub.add_parser("add-tests")
    executions_add.add_argument("--execution-id", "--execution", required=True, dest="execution_id")
    executions_add.add_argument("--test-ids", "--tests", required=True, dest="test_ids")
    add_common_flags(executions_add)

    results = subparsers.add_parser("results")
    results_sub = results.add_subparsers(dest="results_command")
    results_import = results_sub.add_parser("import")
    results_import.add_argument("--format", required=True)
    results_import.add_argument("--path", required=True)
    add_common_flags(results_import)

    testruns = subparsers.add_parser("testruns")
    testruns_sub = testruns.add_subparsers(dest="testruns_command")
    testruns_get = testruns_sub.add_parser("get")
    testruns_get.add_argument("--execution-id", "--execution", required=True, dest="execution_id")
    testruns_get.add_argument("--test-id", "--test", required=True, dest="test_id")
    testruns_get.add_argument("--wait", action="store_true")
    testruns_get.add_argument("--attempts", type=int, default=5)
    testruns_get.add_argument("--delay-seconds", type=float, default=3.0)
    add_common_flags(testruns_get)
    testruns_upload = testruns_sub.add_parser("upload-evidence")
    testruns_upload.add_argument("--test-run-id", "--run", required=True, dest="test_run_id")
    testruns_upload.add_argument("--files", required=True)
    add_common_flags(testruns_upload)

    workflow = subparsers.add_parser("workflow")
    workflow_sub = workflow.add_subparsers(dest="workflow_command")
    workflow_validate = workflow_sub.add_parser("validate-import")
    workflow_validate.add_argument("--format", required=True)
    workflow_validate.add_argument("--path", required=True)
    add_common_flags(workflow_validate)
    workflow_sync = workflow_sub.add_parser("sync-library")
    workflow_sync.add_argument("--source", required=True)
    workflow_sync.add_argument("--project-key")
    workflow_sync.add_argument("--dry-run", action="store_true")
    add_common_flags(workflow_sync)

    zephyr = subparsers.add_parser("zephyr")
    zephyr_sub = zephyr.add_subparsers(dest="zephyr_command")
    zephyr_inspect = zephyr_sub.add_parser("inspect")
    zephyr_inspect.add_argument("--source", required=True)
    zephyr_inspect.add_argument("--out")
    add_common_flags(zephyr_inspect)

    migrate = subparsers.add_parser("migrate")
    migrate_sub = migrate.add_subparsers(dest="migrate_command")
    migrate_map = migrate_sub.add_parser("map")
    migrate_map_sub = migrate_map.add_subparsers(dest="migrate_map_command")
    migrate_map_init = migrate_map_sub.add_parser("init")
    migrate_map_init.add_argument("--source", required=True)
    migrate_map_init.add_argument("--project-key", required=True)
    migrate_map_init.add_argument("--out", required=True)
    add_common_flags(migrate_map_init)
    migrate_map_validate = migrate_map_sub.add_parser("validate")
    migrate_map_validate.add_argument("--mapping", required=True)
    add_common_flags(migrate_map_validate)

    migrate_transform = migrate_sub.add_parser("transform")
    migrate_transform.add_argument("--source", required=True)
    migrate_transform.add_argument("--mapping", required=True)
    migrate_transform.add_argument("--out", required=True)
    add_common_flags(migrate_transform)

    migrate_validate = migrate_sub.add_parser("validate")
    migrate_validate.add_argument("--input", required=True)
    add_common_flags(migrate_validate)

    migrate_preview = migrate_sub.add_parser("preview")
    migrate_preview.add_argument("--input", required=True)
    migrate_preview.add_argument("--out", required=True)
    add_common_flags(migrate_preview)

    suite = subparsers.add_parser("suite")
    suite_sub = suite.add_subparsers(dest="suite_command")
    suite_init = suite_sub.add_parser("init")
    suite_init.add_argument("--force", action="store_true")
    add_common_flags(suite_init)
    suite_list = suite_sub.add_parser("list")
    add_common_flags(suite_list)
    suite_validate = suite_sub.add_parser("validate")
    suite_validate.add_argument("name")
    add_common_flags(suite_validate)
    suite_explain = suite_sub.add_parser("explain")
    suite_explain.add_argument("name")
    add_common_flags(suite_explain)
    suite_run = suite_sub.add_parser("run")
    suite_run.add_argument("name")
    suite_run.add_argument("--dry-run", action="store_true")
    suite_run.add_argument(
        "--input",
        action="append",
        default=[],
        help="Input override as key=value.",
    )
    add_common_flags(suite_run)

    return parser


def input_overrides(values: list[str]) -> JsonObject:
    """Parse repeated key=value input overrides."""

    overrides: JsonObject = {}
    for value in values:
        if "=" not in value:
            raise ValueError(f"Input override must be key=value: {value}")
        key, raw = value.split("=", 1)
        overrides[key] = raw
    return overrides


def command_entry(name: str) -> JsonObject:
    """Return a command manifest entry by command name."""

    for entry in manifest_as_json():
        if entry["command"] == name:
            return entry
    raise ValueError(f"Unknown command: {name}")


def render_commands_text() -> str:
    """Render commands in a human-readable grouped list."""

    grouped: dict[str, list[tuple[str, str]]] = {}
    for entry in command_manifest():
        grouped.setdefault(entry.category, []).append((entry.command, entry.summary))
    lines = ["jiraxray-cli commands", ""]
    for category in sorted(grouped):
        lines.append(category.replace("-", " ").title())
        for command_name, summary in grouped[category]:
            lines.append(f"  {command_name:<28} {summary}")
        lines.append("")
    lines.append('Use `jiraxray-cli command "tests search"` for command-specific help.')
    lines.append("Use `jiraxray-cli commands --json` for the agent/script manifest.")
    return "\n".join(lines)


def render_command_text(name: str) -> str:
    """Render detailed human-readable help for one command."""

    entry = command_entry(name)
    lines = [
        str(entry["command"]),
        "",
        f"Purpose: {entry['summary']}",
        f"Risk: {entry['risk']}",
        f"Side effect: {entry['side_effect']}",
        f"Retry safe: {entry['retry_safe']}",
        "",
        "Required arguments:",
    ]
    required = entry.get("required_args", [])
    lines.extend(
        f"  --{arg['name'].replace('_', '-')} ({arg['type']}): {arg['description']}"
        for arg in required
    )
    if not required:
        lines.append("  None")
    lines.extend(["", "Optional arguments:"])
    optional = entry.get("optional_args", [])
    lines.extend(
        f"  --{arg['name'].replace('_', '-')} ({arg['type']}): {arg['description']}"
        for arg in optional
    )
    if not optional:
        lines.append("  None")
    lines.extend(["", "Next commands:"])
    next_commands = entry.get("next_commands", [])
    lines.extend(f"  {item['command']}: {item['reason']}" for item in next_commands)
    if not next_commands:
        lines.append("  None")
    return "\n".join(lines)


def execute(args: argparse.Namespace, cwd: Path) -> CliResult:
    """Execute parsed CLI arguments and return a structured result."""

    config = resolve_config(cwd)
    command = cast(str | None, args.command)
    if command == "diagnose":
        data: JsonObject = {
            "version": __version__,
            "profilePath": str(config.profile_path),
            "profileExists": config.profile_path.exists(),
            "region": config.region,
            "baseUrl": config.base_url,
            "credentialsPresent": config.has_credentials,
            "jiraBaseUrl": config.jira_base_url,
            "jiraProjectKey": config.jira_project_key,
            "jiraCredentialsPresent": config.has_jira_credentials,
        }
        if bool(getattr(args, "live", False)):
            service = XrayService(config)
            data["xray"] = service.validate_xray_connection()
            data["jira"] = service.validate_jira_connection()
        return CliResult(
            ok=True,
            command="diagnose",
            data=data,
        )
    if command == "commands":
        return CliResult(ok=True, command="commands", data={"commands": manifest_as_json()})
    if command == "command":
        entry = command_entry(str(args.name))
        return CliResult(ok=True, command="command", data={"command": entry})
    if command == "init":
        result = run_init(
            Path(args.path),
            tool=str(args.tool),
            suite_name=str(args.suite_name),
            force=bool(args.force),
        )
        return CliResult(
            ok=True,
            command="init",
            data=init_result_data(result, str(args.suite_name)),
        )
    if command == "profile" and args.profile_command == "init":
        path = write_default_profile(cwd, force=bool(args.force))
        return CliResult(ok=True, command="profile init", data={"profilePath": str(path)})
    if command == "suite":
        return execute_suite(args, cwd)
    if command == "workflow":
        return execute_workflow(args, cwd)
    if command == "zephyr":
        return execute_zephyr(args, cwd)
    if command == "migrate":
        return execute_migrate(args, cwd)

    service = XrayService(config)
    if command == "issues" and args.issues_command == "create":
        return CliResult(
            ok=True,
            command="issues create",
            data={
                "result": service.create_issue(
                    args.issue_type,
                    args.summary,
                    args.description,
                    args.project_key,
                )
            },
        )
    if command == "issues" and args.issues_command == "get":
        return CliResult(
            ok=True,
            command="issues get",
            data={"result": service.get_issue(args.issue)},
        )
    if command == "issues" and args.issues_command == "summary":
        return CliResult(
            ok=True,
            command="issues summary",
            data={"result": service.get_issue_summary(args.issue)},
        )
    if command == "issues" and args.issues_command == "link":
        return CliResult(
            ok=True,
            command="issues link",
            data={"result": service.link_issues(args.inward, args.outward, args.link_type)},
        )
    if command == "discover" and args.discover_command == "project":
        return CliResult(
            ok=True,
            command="discover project",
            data={"result": service.discover_project(args.project_key)},
        )
    if command == "tests" and args.tests_command == "search":
        return CliResult(
            ok=True,
            command="tests search",
            data={"result": service.search_tests(args.jql, limit=int(args.limit))},
        )
    if command == "tests" and args.tests_command == "create":
        return CliResult(
            ok=True,
            command="tests create",
            data={"result": service.create_test(args.project_key, args.summary, args.test_type)},
        )
    if command == "tests" and args.tests_command == "update-steps":
        steps = load_steps(Path(args.steps_file))
        return CliResult(
            ok=True,
            command="tests update-steps",
            data={"result": service.replace_steps(args.issue_id, steps), "steps": len(steps)},
        )
    if command == "tests" and args.tests_command == "import-bulk":
        warnings = validate_bulk_test_import(Path(args.path))
        if warnings:
            return CliResult(
                ok=False,
                command="tests import-bulk",
                data={"path": args.path, "valid": False},
                warnings=warnings,
            )
        return CliResult(
            ok=True,
            command="tests import-bulk",
            data={"result": service.import_tests_bulk(Path(args.path))},
        )
    if command == "tests" and args.tests_command == "import-status":
        return CliResult(
            ok=True,
            command="tests import-status",
            data={"result": service.import_tests_bulk_status(args.job_id)},
        )
    if command == "sets" and args.sets_command == "add-tests":
        return CliResult(
            ok=True,
            command="sets add-tests",
            data={"result": service.add_tests_to_set(args.set_id, parse_csv(args.test_ids))},
        )
    if command == "plans" and args.plans_command == "add-tests":
        return CliResult(
            ok=True,
            command="plans add-tests",
            data={"result": service.add_tests_to_plan(args.plan_id, parse_csv(args.test_ids))},
        )
    if command == "executions" and args.executions_command == "create":
        return CliResult(
            ok=True,
            command="executions create",
            data={
                "result": service.create_execution(
                    args.project_key, args.summary, parse_csv(args.test_ids)
                )
            },
        )
    if command == "executions" and args.executions_command == "add-tests":
        return CliResult(
            ok=True,
            command="executions add-tests",
            data={
                "result": service.add_tests_to_execution(
                    args.execution_id, parse_csv(args.test_ids)
                )
            },
        )
    if command == "results" and args.results_command == "import":
        return CliResult(
            ok=True,
            command="results import",
            data={"result": service.import_results(args.format, Path(args.path))},
        )
    if command == "testruns" and args.testruns_command == "get":
        return CliResult(
            ok=True,
            command="testruns get",
            data={
                "result": service.get_test_run(
                    args.execution_id,
                    args.test_id,
                    wait=bool(args.wait),
                    attempts=int(args.attempts),
                    delay_seconds=float(args.delay_seconds),
                )
            },
        )
    if command == "testruns" and args.testruns_command == "upload-evidence":
        files = [resolve_path(cwd, item) for item in parse_csv(args.files)]
        return CliResult(
            ok=True,
            command="testruns upload-evidence",
            data={"result": service.upload_evidence(args.test_run_id, files)},
        )
    raise ValueError("A supported subcommand is required")


def execute_zephyr(args: argparse.Namespace, cwd: Path) -> CliResult:
    """Execute Zephyr source inspection commands."""

    if args.zephyr_command == "inspect":
        inspection = inspect_zephyr_excel(resolve_path(cwd, str(args.source)))
        if args.out:
            out_path = resolve_path(cwd, str(args.out))
            out_path.parent.mkdir(parents=True, exist_ok=True)
            out_path.write_text(render_inspection_markdown(inspection), encoding="utf-8")
        data = inspection_to_json(inspection)
        if args.out:
            data["reportPath"] = str(resolve_path(cwd, str(args.out)))
        return CliResult(
            ok=not any(warning.severity == "error" for warning in inspection.warnings),
            command="zephyr inspect",
            data=data,
        )
    raise ValueError("A supported zephyr subcommand is required")


def execute_migrate(args: argparse.Namespace, cwd: Path) -> CliResult:
    """Execute Zephyr-to-Xray migration planning commands."""

    migrate_command = cast(str | None, args.migrate_command)
    if migrate_command == "map":
        if args.migrate_map_command == "init":
            mapping = default_mapping_for_export(
                resolve_path(cwd, str(args.source)),
                str(args.project_key),
            )
            path = write_mapping(mapping, resolve_path(cwd, str(args.out)))
            return CliResult(
                ok=True,
                command="migrate map init",
                data={"mappingPath": str(path), "mapping": mapping},
            )
        if args.migrate_map_command == "validate":
            mapping = load_mapping(resolve_path(cwd, str(args.mapping)))
            warnings = validate_mapping(mapping)
            return CliResult(
                ok=not any(warning.severity == "error" for warning in warnings),
                command="migrate map validate",
                data=mapping_to_json(mapping),
            )
    if migrate_command == "transform":
        plan = transform_export(
            resolve_path(cwd, str(args.source)),
            resolve_path(cwd, str(args.mapping)),
        )
        path = write_import_plan(plan, resolve_path(cwd, str(args.out)))
        return CliResult(
            ok=not any(warning.severity == "error" for warning in plan.warnings),
            command="migrate transform",
            data={**plan_summary(plan), "planPath": str(path)},
        )
    if migrate_command == "validate":
        plan = load_import_plan(resolve_path(cwd, str(args.input)))
        warnings = validate_import_plan(plan)
        return CliResult(
            ok=not any(warning.severity == "error" for warning in warnings),
            command="migrate validate",
            data=plan_summary(plan),
        )
    if migrate_command == "preview":
        plan = load_import_plan(resolve_path(cwd, str(args.input)))
        out_path = resolve_path(cwd, str(args.out))
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(render_preview_markdown(plan), encoding="utf-8")
        return CliResult(
            ok=not any(warning.severity == "error" for warning in validate_import_plan(plan)),
            command="migrate preview",
            data={**plan_summary(plan), "previewPath": str(out_path)},
        )
    raise ValueError("A supported migrate subcommand is required")


def execute_workflow(args: argparse.Namespace, cwd: Path) -> CliResult:
    """Execute high-level workflow helper commands."""

    workflow_command = cast(str | None, args.workflow_command)
    if workflow_command == "validate-import":
        warnings = validate_result_import(args.format, Path(args.path))
        return CliResult(
            ok=not warnings,
            command="workflow validate-import",
            data={"format": args.format, "path": args.path, "valid": not warnings},
            warnings=warnings,
        )
    if workflow_command == "sync-library":
        value = load_sync_library(Path(args.source))
        warnings = validate_sync_library(value, args.project_key)
        tests = [] if warnings else sync_tests_from_library(value, args.project_key)
        if args.dry_run:
            return CliResult(
                ok=not warnings,
                command="workflow sync-library",
                data={
                    "mode": "dry-run",
                    "source": args.source,
                    "tests": [
                        {
                            "project_key": test["project_key"],
                            "summary": test["summary"],
                            "test_type": test["test_type"],
                            "steps": len(cast(list[StepInput], test["steps"])),
                        }
                        for test in tests
                    ],
                },
                warnings=warnings,
            )
        service = XrayService(resolve_config(cwd))
        results: list[JsonObject] = []
        for test in tests:
            created = service.create_test(
                str(test["project_key"]),
                str(test["summary"]),
                str(test["test_type"]),
            )
            result: JsonObject = {"created": created}
            steps = cast(list[StepInput], test["steps"])
            issue_id = extract_created_issue_id(created)
            if steps and issue_id:
                result["steps"] = service.replace_steps(issue_id, steps)
            elif steps:
                result["warning"] = "Could not resolve created issue id; steps were not updated."
            results.append(result)
        return CliResult(
            ok=not warnings,
            command="workflow sync-library",
            data={"mode": "sync", "source": args.source, "results": results},
            warnings=warnings,
        )
    raise ValueError("A supported workflow subcommand is required")


def extract_created_issue_id(response: JsonObject) -> str | None:
    """Extract an issue id from the createTest GraphQL response when present."""

    data = response.get("data")
    if not isinstance(data, dict):
        return None
    create_test = data.get("createTest")
    if not isinstance(create_test, dict):
        return None
    test = create_test.get("test")
    if not isinstance(test, dict):
        return None
    issue_id = test.get("issueId")
    return issue_id if isinstance(issue_id, str) else None


def execute_suite(args: argparse.Namespace, cwd: Path) -> CliResult:
    """Execute suite subcommands."""

    suite_command = cast(str | None, args.suite_command)
    if suite_command == "init":
        path = write_example_workflow(cwd, force=bool(args.force))
        return CliResult(ok=True, command="suite init", data={"workflowPath": str(path)})
    if suite_command == "list":
        return CliResult(ok=True, command="suite list", data={"workflows": list_workflows(cwd)})
    if suite_command in {"validate", "explain", "run"}:
        workflow = load_workflow(cwd, args.name)
        warnings = validate_workflow(workflow)
        if suite_command == "validate":
            return CliResult(
                ok=not warnings,
                command="suite validate",
                data={"workflow": workflow.name, "valid": not warnings},
                warnings=warnings,
            )
        if suite_command == "explain":
            return CliResult(
                ok=not warnings,
                command="suite explain",
                data=explain_workflow(workflow),
                warnings=warnings,
            )
        if not args.dry_run:
            return run_workflow_suite(workflow, input_overrides(args.input), cwd, warnings)
        return CliResult(
            ok=not warnings,
            command="suite run",
            data=dry_run_workflow(workflow, input_overrides(args.input)),
            warnings=warnings,
        )
    raise ValueError("A supported suite subcommand is required")


def run_workflow_suite(
    workflow: object,
    inputs: JsonObject,
    cwd: Path,
    validation_warnings: list[str],
) -> CliResult:
    """Execute supported workflow suite steps in order."""

    if validation_warnings:
        return CliResult(
            ok=False,
            command="suite run",
            data={"mode": "run", "steps": []},
            warnings=validation_warnings,
        )
    service = XrayService(resolve_config(cwd))
    results: list[JsonObject] = []
    for step in resolved_workflow_steps(workflow, inputs):
        command = str(step["command"])
        args = cast(JsonObject, step["args"])
        result = execute_suite_step(service, command, args, cwd)
        results.append({"name": step["name"], "command": command, "result": result})
    return CliResult(ok=True, command="suite run", data={"mode": "run", "steps": results})


def execute_suite_step(
    service: XrayService,
    command: str,
    args: JsonObject,
    cwd: Path,
) -> JsonObject:
    """Execute one supported suite command."""

    if command == "discover project":
        return service.discover_project(str(args["project_key"]))
    if command == "issues create":
        return service.create_issue(
            str(args["type"]),
            str(args["summary"]),
            str(args["description"]) if args.get("description") is not None else None,
            str(args["project_key"]) if args.get("project_key") is not None else None,
        )
    if command == "issues link":
        return service.link_issues(
            str(args["inward"]),
            str(args["outward"]),
            str(args.get("type", "Test")),
        )
    if command == "tests search":
        return service.search_tests(str(args["jql"]), limit=int(args.get("limit", 25)))
    if command == "tests create":
        return service.create_test(
            str(args["project_key"]),
            str(args["summary"]),
            str(args.get("test_type", "Manual")),
        )
    if command == "tests update-steps":
        steps = load_steps(resolve_path(cwd, str(args["steps_file"])))
        return service.replace_steps(str(args["issue_id"]), steps)
    if command == "tests import-bulk":
        path = resolve_path(cwd, str(args["path"]))
        warnings = validate_bulk_test_import(path)
        if warnings:
            raise ValueError("; ".join(warnings))
        return service.import_tests_bulk(path)
    if command == "tests import-status":
        return service.import_tests_bulk_status(str(args["job_id"]))
    if command == "sets add-tests":
        return service.add_tests_to_set(str(args["set_id"]), normalize_ids(args["test_ids"]))
    if command == "plans add-tests":
        return service.add_tests_to_plan(str(args["plan_id"]), normalize_ids(args["test_ids"]))
    if command == "executions create":
        return service.create_execution(
            str(args["project_key"]),
            str(args["summary"]),
            normalize_ids(args.get("test_ids", [])),
        )
    if command == "executions add-tests":
        return service.add_tests_to_execution(
            str(args["execution_id"]),
            normalize_ids(args["test_ids"]),
        )
    if command == "results import":
        return service.import_results(str(args["format"]), resolve_path(cwd, str(args["path"])))
    raise ValueError(f"Unsupported suite command: {command}")


def normalize_ids(value: object) -> list[str]:
    """Normalize comma-separated or list id values."""

    if isinstance(value, str):
        return parse_csv(value)
    if isinstance(value, list):
        return [str(item) for item in value if str(item)]
    raise ValueError("Expected id list or comma-separated string")


def resolve_path(cwd: Path, value: str) -> Path:
    """Resolve a path relative to the current working directory."""

    path = Path(value)
    return path if path.is_absolute() else cwd / path


def main(argv: Sequence[str] | None = None) -> int:
    """Run the command-line interface."""

    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        if getattr(args, "command", None) == "commands" and not getattr(args, "json", False):
            print(render_commands_text())
            return 0
        if getattr(args, "command", None) == "command" and not getattr(args, "json", False):
            print(render_command_text(str(args.name)))
            return 0
        result = execute(args, Path.cwd())
        view = cast(ViewMode, getattr(args, "view", "compact"))
        print(render_result(result, view=view))
        return 0 if result.ok else 1
    except Exception as exc:
        payload = CliResult(
            ok=False,
            command=str(getattr(args, "command", "unknown")),
            data={"error": str(exc)},
        )
        print(render_result(payload), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
