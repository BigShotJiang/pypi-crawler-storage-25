"""Response rendering utilities."""

from __future__ import annotations

import json
from typing import Any

from .models import CliResult, JsonObject, ViewMode


def compact_data(data: JsonObject) -> JsonObject:
    """Return compact response data suitable for agent consumption."""

    compact: JsonObject = {}
    for key, value in data.items():
        if key in {"raw", "request"}:
            continue
        compact[key] = value
    return compact


def render_result(result: CliResult, view: ViewMode = "compact") -> str:
    """Render a structured result as JSON text."""

    data: Any
    if view == "raw":
        data = result.data.get("raw", result.data)
    elif view == "full":
        data = result.data
    else:
        data = compact_data(result.data)
    payload = {
        "ok": result.ok,
        "command": result.command,
        "data": data,
        "warnings": result.warnings,
    }
    return json.dumps(payload, indent=2, sort_keys=True)
