"""Agent-friendly CLI for Xray Cloud test management."""

__version__ = "0.1.2"
