"""Mapping generation and validation for Zephyr to Xray migration."""

from __future__ import annotations

from dataclasses import asdict
from pathlib import Path
from typing import Literal, cast

import yaml

from ..models import JsonObject
from .models import MappingConfig, MigrationWarning
from .zephyr import inspect_zephyr_excel


def default_mapping_for_export(source: Path, project_key: str) -> JsonObject:
    """Create a starter mapping from a Zephyr export."""

    inspection = inspect_zephyr_excel(source)
    return {
        "source": {"type": "zephyr-squad-excel", "path": str(source)},
        "target": {"type": "xray-cloud", "projectKey": project_key},
        "defaults": {"testType": "Manual", "duplicatePolicy": "warn"},
        "fields": {
            "sourceId": "Issue Id",
            "summary": "Summary",
            "description": "Description",
            "folder": "Folder",
            "priority": "Priority",
            "status": "Status",
            "labels": "Labels",
            "components": "Components",
            "precondition": "Precondition",
            "stepAction": "Step Action",
            "stepData": "Test Data",
            "stepResult": "Expected Result",
        },
        "priorityMap": {},
        "statusMap": {},
        "detectedColumns": inspection.detected_columns,
        "notes": [
            "Review field names against the Zephyr export before transform.",
            "Set duplicatePolicy to warn, skip, or create.",
            "BDD scenarios and attachments require manual review in this milestone.",
        ],
    }


def write_mapping(mapping: JsonObject, path: Path) -> Path:
    """Write a mapping YAML file."""

    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(yaml.safe_dump(mapping, sort_keys=False), encoding="utf-8")
    return path


def load_mapping(path: Path) -> JsonObject:
    """Load a mapping YAML file."""

    if not path.exists():
        raise FileNotFoundError(path)
    value = yaml.safe_load(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError("Mapping file must contain a YAML object")
    return value


def parse_mapping(value: JsonObject) -> MappingConfig:
    """Parse a mapping object into a typed config."""

    target = expect_object(value, "target")
    defaults = cast(
        JsonObject,
        value.get("defaults") if isinstance(value.get("defaults"), dict) else {},
    )
    fields = cast(JsonObject, value.get("fields") if isinstance(value.get("fields"), dict) else {})
    priority_map = cast(
        JsonObject,
        value.get("priorityMap") if isinstance(value.get("priorityMap"), dict) else {},
    )
    status_map = cast(
        JsonObject,
        value.get("statusMap") if isinstance(value.get("statusMap"), dict) else {},
    )
    project_key = target.get("projectKey")
    if not isinstance(project_key, str) or not project_key:
        raise ValueError("Mapping target.projectKey is required")
    duplicate_policy = str(defaults.get("duplicatePolicy", "warn"))
    if duplicate_policy not in {"warn", "skip", "create"}:
        raise ValueError("defaults.duplicatePolicy must be warn, skip, or create")
    typed_duplicate_policy = cast(Literal["warn", "skip", "create"], duplicate_policy)
    return MappingConfig(
        project_key=project_key,
        default_test_type=str(defaults.get("testType", "Manual")),
        duplicate_policy=typed_duplicate_policy,
        fields={str(key): str(item) for key, item in fields.items()},
        priority_map={str(key): str(item) for key, item in priority_map.items()},
        status_map={str(key): str(item) for key, item in status_map.items()},
    )


def validate_mapping(value: JsonObject) -> list[MigrationWarning]:
    """Validate a mapping YAML object."""

    warnings: list[MigrationWarning] = []
    try:
        mapping = parse_mapping(value)
    except ValueError as exc:
        return [MigrationWarning("error", str(exc))]
    if not mapping.project_key:
        warnings.append(MigrationWarning("error", "Missing target project key."))
    if not mapping.default_test_type:
        warnings.append(MigrationWarning("error", "Missing default test type."))
    for required in ("summary",):
        if required not in mapping.fields:
            warnings.append(MigrationWarning("warning", f"Mapping field '{required}' is not set."))
    return warnings


def mapping_to_json(value: JsonObject) -> JsonObject:
    """Return mapping validation data."""

    warnings = validate_mapping(value)
    config = (
        parse_mapping(value)
        if not any(warning.severity == "error" for warning in warnings)
        else None
    )
    return {
        "valid": not any(warning.severity == "error" for warning in warnings),
        "mapping": asdict(config) if config else None,
        "warnings": [asdict(warning) for warning in warnings],
    }


def expect_object(value: JsonObject, key: str) -> JsonObject:
    """Return a child object or raise a validation error."""

    child = value.get(key)
    if not isinstance(child, dict):
        raise ValueError(f"Mapping '{key}' section is required")
    return child
