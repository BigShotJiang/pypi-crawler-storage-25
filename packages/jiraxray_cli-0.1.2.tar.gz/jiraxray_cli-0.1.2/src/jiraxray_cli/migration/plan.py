"""Transform and validate local Xray import plans."""

from __future__ import annotations

import json
from collections import Counter
from dataclasses import asdict
from pathlib import Path

from ..models import JsonObject
from .mapping import load_mapping, parse_mapping
from .models import (
    ImportPlan,
    MigrationWarning,
    SourceInspection,
    SourceStep,
    XrayTestDraft,
    draft_to_json,
    import_plan_to_json,
)
from .zephyr import inspect_zephyr_excel


def transform_export(source: Path, mapping_path: Path) -> ImportPlan:
    """Transform a Zephyr export into a local Xray import plan."""

    inspection = inspect_zephyr_excel(source)
    mapping = parse_mapping(load_mapping(mapping_path))
    warnings = list(inspection.warnings)
    summaries = Counter(test.summary.strip().lower() for test in inspection.tests)
    tests: list[XrayTestDraft] = []
    for test in inspection.tests:
        if mapping.duplicate_policy == "skip" and summaries[test.summary.strip().lower()] > 1:
            warnings.append(
                MigrationWarning(
                    "warning",
                    f"Skipped duplicate summary: {test.summary}",
                    test.source_rows[0],
                )
            )
            continue
        tests.append(
            XrayTestDraft(
                source_id=test.source_id,
                project_key=mapping.project_key,
                summary=test.summary,
                description=test.description,
                test_type=mapping.default_test_type,
                folder=test.folder,
                priority=map_optional(test.priority, mapping.priority_map),
                status=map_optional(test.status, mapping.status_map),
                labels=test.labels,
                components=test.components,
                precondition=test.precondition,
                steps=test.steps,
                custom_fields=test.custom_fields,
            )
        )
    return ImportPlan(
        source_path=inspection.source_path,
        project_key=mapping.project_key,
        tests=tests,
        warnings=warnings,
    )


def write_import_plan(plan: ImportPlan, path: Path) -> Path:
    """Write an import plan JSON file."""

    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(import_plan_to_json(plan), indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    return path


def load_import_plan(path: Path) -> ImportPlan:
    """Load an import plan JSON file."""

    if not path.exists():
        raise FileNotFoundError(path)
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError("Import plan must contain a JSON object")
    tests: list[XrayTestDraft] = []
    for raw in value.get("tests", []):
        if not isinstance(raw, dict):
            continue
        steps = [
            step
            for step in raw.get("steps", [])
            if isinstance(step, dict) and isinstance(step.get("action"), str)
        ]
        raw_custom_fields = raw.get("customFields")
        custom_fields = raw_custom_fields if isinstance(raw_custom_fields, dict) else {}
        tests.append(
            XrayTestDraft(
                source_id=str(raw.get("sourceId", "")),
                project_key=str(raw.get("projectKey", "")),
                summary=str(raw.get("summary", "")),
                description=string_or_none(raw.get("description")),
                test_type=str(raw.get("testType", "Manual")),
                folder=string_or_none(raw.get("folder")),
                priority=string_or_none(raw.get("priority")),
                status=string_or_none(raw.get("status")),
                labels=list_of_strings(raw.get("labels")),
                components=list_of_strings(raw.get("components")),
                precondition=string_or_none(raw.get("precondition")),
                steps=[
                    SourceStep(
                        action=str(step.get("action", "")),
                        data=string_or_none(step.get("data")),
                        result=string_or_none(step.get("result")),
                    )
                    for step in steps
                ],
                custom_fields=custom_fields,
            )
        )
    warnings = [
        MigrationWarning(
            severity=raw.get("severity", "warning"),
            message=str(raw.get("message", "")),
            row=raw.get("row") if isinstance(raw.get("row"), int) else None,
            field=raw.get("field") if isinstance(raw.get("field"), str) else None,
        )
        for raw in value.get("warnings", [])
        if isinstance(raw, dict)
    ]
    return ImportPlan(
        source_path=str(value.get("sourcePath", path)),
        project_key=str(value.get("projectKey", "")),
        tests=tests,
        warnings=warnings,
    )


def validate_import_plan(plan: ImportPlan) -> list[MigrationWarning]:
    """Validate a local Xray import plan."""

    warnings = list(plan.warnings)
    if not plan.project_key:
        warnings.append(MigrationWarning("error", "Import plan project key is missing."))
    if not plan.tests:
        warnings.append(MigrationWarning("error", "Import plan contains no tests."))
    summaries = Counter(test.summary.strip().lower() for test in plan.tests if test.summary)
    for test in plan.tests:
        if not test.project_key:
            warnings.append(
                MigrationWarning("error", "Test project key is missing.", field="projectKey")
            )
        if not test.summary:
            warnings.append(MigrationWarning("error", "Test summary is missing.", field="summary"))
        if not test.steps:
            warnings.append(
                MigrationWarning("warning", f"Test has no manual steps: {test.source_id}")
            )
        if summaries[test.summary.strip().lower()] > 1:
            warnings.append(
                MigrationWarning("warning", f"Duplicate test summary in plan: {test.summary}")
            )
    return warnings


def plan_summary(plan: ImportPlan) -> JsonObject:
    """Return compact import plan summary data."""

    validation = validate_import_plan(plan)
    return {
        "sourcePath": plan.source_path,
        "projectKey": plan.project_key,
        "testCount": len(plan.tests),
        "testsWithSteps": sum(1 for test in plan.tests if test.steps),
        "warningCount": len(validation),
        "valid": not any(warning.severity == "error" for warning in validation),
        "warnings": [asdict(warning) for warning in validation],
        "sampleTests": [draft_to_json(test) for test in plan.tests[:5]],
    }


def render_preview_markdown(plan: ImportPlan) -> str:
    """Render a Markdown migration preview report."""

    validation = validate_import_plan(plan)
    lines = [
        "# Xray Migration Preview",
        "",
        f"- Source: `{plan.source_path}`",
        f"- Target project: `{plan.project_key}`",
        f"- Tests in plan: {len(plan.tests)}",
        f"- Tests with steps: {sum(1 for test in plan.tests if test.steps)}",
        f"- Findings: {len(validation)}",
        "",
        "## Findings",
        "",
    ]
    if validation:
        lines.extend(f"- {warning.severity.upper()}: {warning.message}" for warning in validation)
    else:
        lines.append("- None")
    lines.extend(["", "## Tests", ""])
    for test in plan.tests[:100]:
        lines.append(f"- `{test.source_id}` {test.summary} ({len(test.steps)} steps)")
    if len(plan.tests) > 100:
        lines.append(f"- ... {len(plan.tests) - 100} more")
    return "\n".join(lines) + "\n"


def map_optional(value: str | None, mapping: dict[str, str]) -> str | None:
    """Map an optional source value through a mapping dictionary."""

    if value is None:
        return None
    return mapping.get(value, value)


def string_or_none(value: object) -> str | None:
    """Return a string value or None."""

    return value if isinstance(value, str) else None


def list_of_strings(value: object) -> list[str]:
    """Return a list of string values."""

    if not isinstance(value, list):
        return []
    return [str(item) for item in value]


def inspection_plan_hint(inspection: SourceInspection) -> JsonObject:
    """Return next-step hint data after inspection."""

    return {
        "recommendedNext": "migrate map init",
        "source": inspection.source_path,
        "testCount": len(inspection.tests),
    }
