"""Parse Zephyr Squad Excel exports into normalized source tests."""

from __future__ import annotations

from collections import Counter
from pathlib import Path
from typing import Any

from openpyxl import load_workbook  # type: ignore[import-untyped]

from ..models import JsonObject
from .models import MigrationWarning, SourceInspection, SourceStep, SourceTestCase, test_to_json

HEADER_ALIASES: dict[str, tuple[str, ...]] = {
    "source_id": ("issue id", "issue key", "key", "test id", "test case id", "id"),
    "summary": ("summary", "name", "test case name", "test summary"),
    "description": ("description", "objective"),
    "folder": ("folder", "path", "test repository path", "repository path"),
    "priority": ("priority",),
    "status": ("status", "workflow status"),
    "labels": ("labels", "label"),
    "components": ("components", "component"),
    "precondition": ("precondition", "preconditions"),
    "step_action": ("step", "step action", "test step", "action"),
    "step_data": ("test data", "data", "step data"),
    "step_result": ("expected result", "expected", "result", "step result"),
}


def inspect_zephyr_excel(path: Path) -> SourceInspection:
    """Inspect a Zephyr Squad Excel export."""

    if not path.exists():
        raise FileNotFoundError(path)
    workbook = load_workbook(path, read_only=True, data_only=True)
    sheet = workbook.active
    rows = list(sheet.iter_rows(values_only=True))
    header_index = find_header_index(rows)
    if header_index is None:
        return SourceInspection(
            source_path=str(path),
            sheet_name=str(sheet.title),
            detected_columns=[],
            tests=[],
            warnings=[MigrationWarning("error", "No header row found in workbook.")],
        )
    headers = [cell_to_text(value) for value in rows[header_index]]
    normalized = [normalize_header(header) for header in headers]
    column_map = detect_columns(normalized)
    warnings = inspect_column_warnings(column_map)
    tests = parse_tests(rows[header_index + 1 :], headers, column_map, header_index + 2)
    warnings.extend(duplicate_warnings(tests))
    warnings.extend(source_shape_warnings(tests))
    return SourceInspection(
        source_path=str(path),
        sheet_name=str(sheet.title),
        detected_columns=[header for header in headers if header],
        tests=tests,
        warnings=warnings,
    )


def inspection_to_json(inspection: SourceInspection) -> JsonObject:
    """Return compact JSON-compatible inspection data."""

    severities = Counter(warning.severity for warning in inspection.warnings)
    return {
        "sourcePath": inspection.source_path,
        "sheetName": inspection.sheet_name,
        "detectedColumns": inspection.detected_columns,
        "testCount": len(inspection.tests),
        "testsWithSteps": sum(1 for test in inspection.tests if test.steps),
        "warningCount": len(inspection.warnings),
        "warningsBySeverity": dict(severities),
        "warnings": [
            {
                "severity": warning.severity,
                "message": warning.message,
                "row": warning.row,
                "field": warning.field,
            }
            for warning in inspection.warnings
        ],
        "sampleTests": [test_to_json(test) for test in inspection.tests[:5]],
    }


def render_inspection_markdown(inspection: SourceInspection) -> str:
    """Render a Markdown inspection report."""

    lines = [
        "# Zephyr Export Inspection",
        "",
        f"- Source: `{inspection.source_path}`",
        f"- Sheet: `{inspection.sheet_name}`",
        f"- Tests detected: {len(inspection.tests)}",
        f"- Tests with steps: {sum(1 for test in inspection.tests if test.steps)}",
        f"- Warnings: {len(inspection.warnings)}",
        "",
        "## Detected Columns",
        "",
    ]
    lines.extend(f"- {column}" for column in inspection.detected_columns)
    lines.extend(["", "## Warnings", ""])
    if inspection.warnings:
        lines.extend(
            f"- {warning.severity.upper()}: {warning.message}"
            + (f" (row {warning.row})" if warning.row else "")
            for warning in inspection.warnings
        )
    else:
        lines.append("- None")
    lines.extend(["", "## Sample Tests", ""])
    for test in inspection.tests[:10]:
        lines.append(f"- `{test.source_id}` {test.summary} ({len(test.steps)} steps)")
    return "\n".join(lines) + "\n"


def find_header_index(rows: list[tuple[Any, ...]]) -> int | None:
    """Find the likely header row in workbook rows."""

    for index, row in enumerate(rows[:20]):
        values = [normalize_header(cell_to_text(value)) for value in row]
        if any(value in HEADER_ALIASES["summary"] for value in values):
            return index
    return None


def detect_columns(headers: list[str]) -> dict[str, int]:
    """Map normalized semantic fields to workbook column indexes."""

    detected: dict[str, int] = {}
    for semantic, aliases in HEADER_ALIASES.items():
        for index, header in enumerate(headers):
            if header in aliases:
                detected[semantic] = index
                break
    return detected


def parse_tests(
    rows: list[tuple[Any, ...]],
    headers: list[str],
    column_map: dict[str, int],
    first_row_number: int,
) -> list[SourceTestCase]:
    """Parse workbook rows into source tests, grouping repeated source ids."""

    grouped: dict[str, SourceTestCase] = {}
    for offset, row in enumerate(rows):
        row_number = first_row_number + offset
        if not any(cell_to_text(value) for value in row):
            continue
        source_id = value_for(row, column_map, "source_id") or f"row-{row_number}"
        summary = value_for(row, column_map, "summary")
        if not summary:
            summary = f"Untitled Zephyr test {source_id}"
        step = step_from_row(row, column_map)
        if source_id in grouped:
            existing = grouped[source_id]
            steps = [*existing.steps, *([step] if step else [])]
            grouped[source_id] = SourceTestCase(
                source_id=existing.source_id,
                summary=existing.summary,
                description=existing.description,
                folder=existing.folder,
                priority=existing.priority,
                status=existing.status,
                labels=existing.labels,
                components=existing.components,
                precondition=existing.precondition,
                steps=steps,
                custom_fields=existing.custom_fields,
                source_rows=[*existing.source_rows, row_number],
            )
            continue
        grouped[source_id] = SourceTestCase(
            source_id=source_id,
            summary=summary,
            description=value_for(row, column_map, "description"),
            folder=value_for(row, column_map, "folder"),
            priority=value_for(row, column_map, "priority"),
            status=value_for(row, column_map, "status"),
            labels=split_multi(value_for(row, column_map, "labels")),
            components=split_multi(value_for(row, column_map, "components")),
            precondition=value_for(row, column_map, "precondition"),
            steps=[step] if step else [],
            custom_fields=custom_fields(row, headers, column_map),
            source_rows=[row_number],
        )
    return list(grouped.values())


def inspect_column_warnings(column_map: dict[str, int]) -> list[MigrationWarning]:
    """Return warnings for missing important source columns."""

    warnings: list[MigrationWarning] = []
    for field in ("summary",):
        if field not in column_map:
            warnings.append(
                MigrationWarning("error", f"Missing expected column for {field}.", field=field)
            )
    for field in ("source_id", "step_action", "step_result"):
        if field not in column_map:
            warnings.append(
                MigrationWarning("warning", f"No column detected for {field}.", field=field)
            )
    return warnings


def duplicate_warnings(tests: list[SourceTestCase]) -> list[MigrationWarning]:
    """Return duplicate summary warnings."""

    counts = Counter(test.summary.strip().lower() for test in tests if test.summary)
    return [
        MigrationWarning("warning", f"Duplicate summary detected: {summary}")
        for summary, count in counts.items()
        if count > 1
    ]


def source_shape_warnings(tests: list[SourceTestCase]) -> list[MigrationWarning]:
    """Return warnings for source content that needs manual migration review."""

    warnings: list[MigrationWarning] = []
    for test in tests:
        joined = " ".join(
            str(value).lower()
            for value in [
                test.summary,
                test.description,
                *test.labels,
                *test.custom_fields.values(),
            ]
            if value
        )
        if "bdd" in joined or "gherkin" in joined:
            warnings.append(
                MigrationWarning(
                    "warning",
                    f"Possible BDD/Gherkin test requires manual review: {test.source_id}",
                    row=test.source_rows[0],
                )
            )
        if "attachment" in joined:
            warnings.append(
                MigrationWarning(
                    "warning",
                    f"Attachment reference may not migrate automatically: {test.source_id}",
                    row=test.source_rows[0],
                )
            )
    return warnings


def step_from_row(row: tuple[Any, ...], column_map: dict[str, int]) -> SourceStep | None:
    """Build a source step from one workbook row."""

    action = value_for(row, column_map, "step_action")
    data = value_for(row, column_map, "step_data")
    result = value_for(row, column_map, "step_result")
    if not action and not result:
        return None
    return SourceStep(action=action or "", data=data, result=result)


def custom_fields(
    row: tuple[Any, ...],
    headers: list[str],
    column_map: dict[str, int],
) -> JsonObject:
    """Capture unmapped source columns as custom fields."""

    semantic_indexes = set(column_map.values())
    fields: JsonObject = {}
    for index, header in enumerate(headers):
        if index in semantic_indexes or not header:
            continue
        value = cell_to_text(row[index]) if index < len(row) else ""
        if value:
            fields[header] = value
    return fields


def value_for(row: tuple[Any, ...], column_map: dict[str, int], key: str) -> str | None:
    """Return a cleaned row value by semantic key."""

    index = column_map.get(key)
    if index is None or index >= len(row):
        return None
    value = cell_to_text(row[index])
    return value or None


def split_multi(value: str | None) -> list[str]:
    """Split common multi-value cell formats into a list."""

    if not value:
        return []
    normalized = value.replace(";", ",").replace("|", ",")
    return [item.strip() for item in normalized.split(",") if item.strip()]


def cell_to_text(value: object) -> str:
    """Convert a spreadsheet cell value into normalized display text."""

    if value is None:
        return ""
    return str(value).strip()


def normalize_header(value: str) -> str:
    """Normalize a spreadsheet header for alias matching."""

    return " ".join(value.strip().lower().replace("_", " ").replace("-", " ").split())
