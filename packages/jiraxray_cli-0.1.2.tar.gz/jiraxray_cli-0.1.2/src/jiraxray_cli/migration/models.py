"""Typed models for Zephyr to Xray migration planning."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal

from ..models import JsonObject

Severity = Literal["info", "warning", "error"]


@dataclass(frozen=True)
class MigrationWarning:
    """Describe a migration finding with severity and optional row context."""

    severity: Severity
    message: str
    row: int | None = None
    field: str | None = None


@dataclass(frozen=True)
class SourceStep:
    """Represent one source Zephyr manual step."""

    action: str
    data: str | None = None
    result: str | None = None


@dataclass(frozen=True)
class SourceTestCase:
    """Represent a normalized Zephyr source test case."""

    source_id: str
    summary: str
    description: str | None
    folder: str | None
    priority: str | None
    status: str | None
    labels: list[str]
    components: list[str]
    precondition: str | None
    steps: list[SourceStep]
    custom_fields: JsonObject
    source_rows: list[int]


@dataclass(frozen=True)
class SourceInspection:
    """Summarize a parsed Zephyr export."""

    source_path: str
    sheet_name: str
    detected_columns: list[str]
    tests: list[SourceTestCase]
    warnings: list[MigrationWarning] = field(default_factory=list)


@dataclass(frozen=True)
class MappingConfig:
    """Represent a Zephyr-to-Xray mapping configuration."""

    project_key: str
    default_test_type: str
    duplicate_policy: Literal["warn", "skip", "create"] = "warn"
    fields: dict[str, str] = field(default_factory=dict)
    priority_map: dict[str, str] = field(default_factory=dict)
    status_map: dict[str, str] = field(default_factory=dict)


@dataclass(frozen=True)
class XrayTestDraft:
    """Represent one local Xray test draft before live import."""

    source_id: str
    project_key: str
    summary: str
    description: str | None
    test_type: str
    folder: str | None
    priority: str | None
    status: str | None
    labels: list[str]
    components: list[str]
    precondition: str | None
    steps: list[SourceStep]
    custom_fields: JsonObject


@dataclass(frozen=True)
class ImportPlan:
    """Represent the local import plan produced by migration transform."""

    source_path: str
    project_key: str
    tests: list[XrayTestDraft]
    warnings: list[MigrationWarning]


def warning_to_json(warning: MigrationWarning) -> JsonObject:
    """Convert a migration warning into JSON-compatible data."""

    return {
        "severity": warning.severity,
        "message": warning.message,
        "row": warning.row,
        "field": warning.field,
    }


def step_to_json(step: SourceStep) -> JsonObject:
    """Convert a source step into JSON-compatible data."""

    return {"action": step.action, "data": step.data, "result": step.result}


def test_to_json(test: SourceTestCase) -> JsonObject:
    """Convert a source test into JSON-compatible data."""

    return {
        "sourceId": test.source_id,
        "summary": test.summary,
        "description": test.description,
        "folder": test.folder,
        "priority": test.priority,
        "status": test.status,
        "labels": test.labels,
        "components": test.components,
        "precondition": test.precondition,
        "steps": [step_to_json(step) for step in test.steps],
        "customFields": test.custom_fields,
        "sourceRows": test.source_rows,
    }


def draft_to_json(test: XrayTestDraft) -> JsonObject:
    """Convert an Xray draft into JSON-compatible data."""

    return {
        "sourceId": test.source_id,
        "projectKey": test.project_key,
        "summary": test.summary,
        "description": test.description,
        "testType": test.test_type,
        "folder": test.folder,
        "priority": test.priority,
        "status": test.status,
        "labels": test.labels,
        "components": test.components,
        "precondition": test.precondition,
        "steps": [step_to_json(step) for step in test.steps],
        "customFields": test.custom_fields,
    }


def import_plan_to_json(plan: ImportPlan) -> JsonObject:
    """Convert an import plan into JSON-compatible data."""

    return {
        "sourcePath": plan.source_path,
        "projectKey": plan.project_key,
        "tests": [draft_to_json(test) for test in plan.tests],
        "warnings": [warning_to_json(warning) for warning in plan.warnings],
    }
