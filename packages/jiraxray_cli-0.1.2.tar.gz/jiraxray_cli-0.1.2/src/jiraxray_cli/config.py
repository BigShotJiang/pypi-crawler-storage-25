"""Configuration and environment handling."""

from __future__ import annotations

import json
import os
from dataclasses import dataclass
from pathlib import Path

from .models import JsonObject

PROFILE_DIR = ".jiraxray-cli"
PROFILE_FILE = "profile.json"

REGION_BASE_URLS: dict[str, str] = {
    "global": "https://xray.cloud.getxray.app",
    "us": "https://us.xray.cloud.getxray.app",
    "eu": "https://eu.xray.cloud.getxray.app",
    "au": "https://au.xray.cloud.getxray.app",
}


@dataclass(frozen=True)
class XrayConfig:
    """Hold Jira and Xray Cloud connection settings resolved from profile and env."""

    client_id: str | None
    client_secret: str | None
    base_url: str
    region: str
    profile_path: Path
    jira_base_url: str | None = None
    jira_email: str | None = None
    jira_api_token: str | None = None
    jira_project_key: str | None = None

    @property
    def has_credentials(self) -> bool:
        """Return whether both required secret environment variables are present."""

        return bool(self.client_id and self.client_secret)

    @property
    def has_jira_credentials(self) -> bool:
        """Return whether Jira REST credentials are present."""

        return bool(self.jira_base_url and self.jira_email and self.jira_api_token)


def profile_path(cwd: Path) -> Path:
    """Return the default project profile path for a working directory."""

    return cwd / PROFILE_DIR / PROFILE_FILE


def load_profile(cwd: Path) -> JsonObject:
    """Load non-secret profile configuration if it exists."""

    path = profile_path(cwd)
    if not path.exists():
        return {}
    with path.open("r", encoding="utf-8") as file:
        value = json.load(file)
    if not isinstance(value, dict):
        raise ValueError(f"Profile must contain a JSON object: {path}")
    return value


def write_default_profile(cwd: Path, force: bool = False) -> Path:
    """Write a default non-secret profile file."""

    path = profile_path(cwd)
    if path.exists() and not force:
        raise FileExistsError(f"Profile already exists: {path}")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(
            {
                "region": "global",
                "jiraBaseUrl": "",
                "jiraProjectKey": "",
                "defaultView": "compact",
                "artifactsDir": ".jiraxray-cli/artifacts",
                "workflowsDir": ".jiraxray-cli/workflows",
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    return path


def resolve_config(cwd: Path) -> XrayConfig:
    """Resolve Xray configuration from env vars and non-secret profile defaults."""

    profile = load_profile(cwd)
    region = str(os.getenv("XRAY_REGION") or profile.get("region") or "global").lower()
    base_url = str(
        os.getenv("XRAY_BASE_URL") or REGION_BASE_URLS.get(region, REGION_BASE_URLS["global"])
    )
    jira_base_url = os.getenv("JIRA_BASE_URL") or profile.get("jiraBaseUrl")
    jira_project_key = os.getenv("JIRA_PROJECT_KEY") or profile.get("jiraProjectKey")
    return XrayConfig(
        client_id=os.getenv("XRAY_CLIENT_ID"),
        client_secret=os.getenv("XRAY_CLIENT_SECRET"),
        base_url=base_url.rstrip("/"),
        region=region,
        profile_path=profile_path(cwd),
        jira_base_url=str(jira_base_url).rstrip("/") if jira_base_url else None,
        jira_email=os.getenv("JIRA_EMAIL"),
        jira_api_token=os.getenv("JIRA_API_TOKEN"),
        jira_project_key=str(jira_project_key) if jira_project_key else None,
    )
