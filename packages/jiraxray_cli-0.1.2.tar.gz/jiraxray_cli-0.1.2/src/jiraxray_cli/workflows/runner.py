"""Local YAML workflow validation and execution planning."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import cast

import yaml

from ..manifest import known_suite_commands
from ..models import JsonObject


@dataclass(frozen=True)
class WorkflowStep:
    """Represent a single deterministic workflow step."""

    name: str
    command: str
    args: JsonObject


@dataclass(frozen=True)
class Workflow:
    """Represent a local workflow suite file."""

    name: str
    description: str
    inputs: JsonObject
    steps: list[WorkflowStep]
    path: Path


def workflows_dir(cwd: Path) -> Path:
    """Return the local workflow directory."""

    return cwd / ".jiraxray-cli" / "workflows"


def workflow_path(cwd: Path, name: str) -> Path:
    """Return the path for a named workflow."""

    suffix = "" if name.endswith(".yaml") else ".yaml"
    return workflows_dir(cwd) / f"{name}{suffix}"


def list_workflows(cwd: Path) -> list[str]:
    """List available workflow names without file extensions."""

    directory = workflows_dir(cwd)
    if not directory.exists():
        return []
    return sorted(path.stem for path in directory.glob("*.yaml"))


def load_workflow(cwd: Path, name: str) -> Workflow:
    """Load a workflow YAML file into a typed workflow object."""

    path = workflow_path(cwd, name)
    if not path.exists():
        raise FileNotFoundError(path)
    value = yaml.safe_load(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError("Workflow must be a YAML object")
    raw_steps = value.get("steps")
    if not isinstance(raw_steps, list):
        raise ValueError("Workflow requires a steps list")
    steps: list[WorkflowStep] = []
    for raw_step in raw_steps:
        if not isinstance(raw_step, dict):
            raise ValueError("Each workflow step must be an object")
        command = raw_step.get("command")
        if not isinstance(command, str):
            raise ValueError("Each workflow step requires a command string")
        args = raw_step.get("args") or {}
        if not isinstance(args, dict):
            raise ValueError("Workflow step args must be an object")
        raw_name = raw_step.get("name")
        step_name = raw_name if isinstance(raw_name, str) else command
        steps.append(WorkflowStep(name=step_name, command=command, args=args))
    inputs = value.get("inputs") or {}
    if not isinstance(inputs, dict):
        raise ValueError("Workflow inputs must be an object")
    return Workflow(
        name=str(value.get("name") or path.stem),
        description=str(value.get("description") or ""),
        inputs=inputs,
        steps=steps,
        path=path,
    )


def validate_workflow(workflow: Workflow) -> list[str]:
    """Return validation warnings for a workflow."""

    warnings: list[str] = []
    known = known_suite_commands()
    for index, step in enumerate(workflow.steps, start=1):
        if step.command not in known:
            warnings.append(f"Step {index} uses unsupported suite command: {step.command}")
    return warnings


def explain_workflow(workflow: Workflow) -> JsonObject:
    """Return a compact explanation of a workflow."""

    return {
        "name": workflow.name,
        "description": workflow.description,
        "path": str(workflow.path),
        "inputs": workflow.inputs,
        "steps": [
            {"name": step.name, "command": step.command, "args": step.args}
            for step in workflow.steps
        ],
    }


def render_arg_templates(value: object, inputs: JsonObject) -> object:
    """Render simple ${name} placeholders in workflow args."""

    if isinstance(value, str):
        rendered = value
        for key, replacement in inputs.items():
            rendered = rendered.replace("${" + key + "}", str(replacement))
        return rendered
    if isinstance(value, list):
        return [render_arg_templates(item, inputs) for item in value]
    if isinstance(value, dict):
        return {key: render_arg_templates(item, inputs) for key, item in value.items()}
    return value


def dry_run_workflow(workflow: Workflow, inputs: JsonObject | None = None) -> JsonObject:
    """Return the resolved step plan without executing remote operations."""

    return {
        "name": workflow.name,
        "mode": "dry-run",
        "steps": resolved_workflow_steps(workflow, inputs),
    }


def resolved_workflow_steps(workflow: object, inputs: JsonObject | None = None) -> list[JsonObject]:
    """Return workflow steps with input placeholders resolved."""

    typed_workflow = cast(Workflow, workflow)
    resolved_inputs = {**typed_workflow.inputs, **(inputs or {})}
    return [
        {
            "name": step.name,
            "command": step.command,
            "args": cast(JsonObject, render_arg_templates(step.args, resolved_inputs)),
        }
        for step in typed_workflow.steps
    ]


def write_example_workflow(cwd: Path, force: bool = False) -> Path:
    """Write a small example workflow file."""

    directory = workflows_dir(cwd)
    directory.mkdir(parents=True, exist_ok=True)
    path = directory / "example-discovery.yaml"
    if path.exists() and not force:
        raise FileExistsError(path)
    path.write_text(
        """name: example-discovery
description: Discover project settings and search a small test sample.
inputs:
  project_key: DEMO
steps:
  - name: discover project
    command: discover project
    args:
      project_key: "${project_key}"
  - name: search tests
    command: tests search
    args:
      jql: "project = ${project_key} AND issuetype = Test"
      limit: 10
  - name: validate junit report
    command: results import
    args:
      format: junit
      path: "reports/junit.xml"
""",
        encoding="utf-8",
    )
    return path
