"""Validation helpers for import and sync workflow files."""

from __future__ import annotations

import json
import xml.etree.ElementTree as ET
from pathlib import Path

import yaml

from ..clients.rest import IMPORT_ENDPOINTS
from ..models import JsonObject, StepInput

STRUCTURED_IMPORT_FORMATS = {"xray"}
XML_IMPORT_FORMATS = {"junit", "nunit", "xunit", "testng", "robot"}
TEXT_IMPORT_FORMATS = {"cucumber"}
MAX_BULK_TEST_IMPORTS = 1000


def validate_result_import(result_format: str, path: Path) -> list[str]:
    """Return validation warnings for an execution result import file."""

    warnings: list[str] = []
    normalized_format = result_format.lower()
    if normalized_format not in IMPORT_ENDPOINTS:
        warnings.append(f"Unsupported result format: {result_format}")
        return warnings
    if not path.exists():
        warnings.append(f"Result file does not exist: {path}")
        return warnings
    if not path.is_file():
        warnings.append(f"Result path is not a file: {path}")
        return warnings
    if normalized_format in STRUCTURED_IMPORT_FORMATS:
        try:
            json.loads(path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as exc:
            warnings.append(f"Invalid JSON result file: {exc}")
    elif normalized_format in XML_IMPORT_FORMATS:
        try:
            ET.parse(path)
        except ET.ParseError as exc:
            warnings.append(f"Invalid XML result file: {exc}")
    elif normalized_format in TEXT_IMPORT_FORMATS and path.stat().st_size == 0:
        warnings.append(f"Result file is empty: {path}")
    return warnings


def validate_bulk_test_import(path: Path) -> list[str]:
    """Return validation warnings for an Xray REST v2 bulk test import file."""

    warnings: list[str] = []
    if not path.exists():
        return [f"Bulk test import file does not exist: {path}"]
    if not path.is_file():
        return [f"Bulk test import path is not a file: {path}"]
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        return [f"Invalid JSON bulk test import file: {exc}"]
    tests = bulk_test_records(value)
    if tests is None:
        warnings.append("Bulk test import JSON must be an object with tests or a list of tests.")
        return warnings
    if not tests:
        warnings.append("Bulk test import JSON contains no tests.")
    if len(tests) > MAX_BULK_TEST_IMPORTS:
        warnings.append(
            f"Bulk test import contains {len(tests)} tests; Xray REST v2 supports a maximum "
            f"of {MAX_BULK_TEST_IMPORTS} tests per request."
        )
    return warnings


def bulk_test_records(value: object) -> list[object] | None:
    """Return candidate bulk test records from supported JSON container shapes."""

    if isinstance(value, list):
        return value
    if isinstance(value, dict) and isinstance(value.get("tests"), list):
        tests = value["tests"]
        assert isinstance(tests, list)
        return tests
    return None


def load_sync_library(path: Path) -> JsonObject:
    """Load a JSON or YAML test-library sync file."""

    if not path.exists():
        raise FileNotFoundError(path)
    text = path.read_text(encoding="utf-8")
    if path.suffix.lower() in {".yaml", ".yml"}:
        value = yaml.safe_load(text)
    else:
        value = json.loads(text)
    if not isinstance(value, dict):
        raise ValueError("Library sync file must contain an object")
    raw_tests = value.get("tests")
    if not isinstance(raw_tests, list):
        raise ValueError("Library sync file requires a tests list")
    return value


def validate_sync_library(value: JsonObject, default_project_key: str | None = None) -> list[str]:
    """Return validation warnings for a test-library sync document."""

    warnings: list[str] = []
    raw_tests = value.get("tests")
    if not isinstance(raw_tests, list):
        return ["Library sync file requires a tests list"]
    for index, raw_test in enumerate(raw_tests, start=1):
        if not isinstance(raw_test, dict):
            warnings.append(f"Test {index} must be an object")
            continue
        project_key = raw_test.get("project_key") or default_project_key
        if not isinstance(project_key, str) or not project_key:
            warnings.append(f"Test {index} requires project_key or --project-key")
        if not isinstance(raw_test.get("summary"), str) or not raw_test.get("summary"):
            warnings.append(f"Test {index} requires a summary")
        steps = raw_test.get("steps", [])
        if steps is not None and not isinstance(steps, list):
            warnings.append(f"Test {index} steps must be a list")
            continue
        for step_index, raw_step in enumerate(steps or [], start=1):
            if not isinstance(raw_step, dict) or not isinstance(raw_step.get("action"), str):
                warnings.append(f"Test {index} step {step_index} requires an action string")
    return warnings


def sync_tests_from_library(
    value: JsonObject,
    default_project_key: str | None = None,
) -> list[JsonObject]:
    """Normalize test-library sync records into executable test definitions."""

    warnings = validate_sync_library(value, default_project_key)
    if warnings:
        raise ValueError("; ".join(warnings))
    raw_tests = value["tests"]
    tests: list[JsonObject] = []
    for raw_test in raw_tests:
        assert isinstance(raw_test, dict)
        steps = [
            StepInput(
                action=str(raw_step["action"]),
                data=raw_step.get("data") if isinstance(raw_step.get("data"), str) else None,
                result=raw_step.get("result") if isinstance(raw_step.get("result"), str) else None,
            )
            for raw_step in raw_test.get("steps", [])
        ]
        tests.append(
            {
                "project_key": str(raw_test.get("project_key") or default_project_key),
                "summary": str(raw_test["summary"]),
                "test_type": str(raw_test.get("test_type") or "Manual"),
                "steps": steps,
            }
        )
    return tests
