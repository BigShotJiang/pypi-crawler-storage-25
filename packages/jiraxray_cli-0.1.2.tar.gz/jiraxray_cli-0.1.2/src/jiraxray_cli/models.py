"""Typed data models shared across the CLI."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal

JsonObject = dict[str, Any]
ViewMode = Literal["compact", "full", "raw"]
Risk = Literal["read-only", "state-changing", "destructive"]
SideEffect = Literal["none", "remote-read", "remote-write", "file-write"]


@dataclass(frozen=True)
class CommandArgument:
    """Describe one CLI argument for agent command discovery."""

    name: str
    type: str
    required: bool
    description: str
    default: Any | None = None


@dataclass(frozen=True)
class CommandHint:
    """Describe a recommended next or fallback command."""

    command: str
    reason: str
    when: str | None = None


@dataclass(frozen=True)
class CommandManifestEntry:
    """Describe one command in the agent-facing manifest."""

    command: str
    summary: str
    category: str
    risk: Risk
    side_effect: SideEffect
    retry_safe: bool
    supports_suite: bool
    required_args: list[CommandArgument] = field(default_factory=list)
    optional_args: list[CommandArgument] = field(default_factory=list)
    output: str = "Compact JSON result."
    next_commands: list[CommandHint] = field(default_factory=list)
    fallback_commands: list[CommandHint] = field(default_factory=list)


@dataclass(frozen=True)
class CliResult:
    """Represent a structured CLI response before rendering."""

    ok: bool
    command: str
    data: JsonObject
    warnings: list[str] = field(default_factory=list)


@dataclass(frozen=True)
class StepInput:
    """Represent a manual Xray test step."""

    action: str
    data: str | None = None
    result: str | None = None
