"""Workflow-oriented Xray operations used by CLI commands."""

from __future__ import annotations

import base64
import time
from pathlib import Path

from .clients.auth import XrayAuthClient
from .clients.graphql import XrayGraphQLClient
from .clients.jira import JiraRestClient, issue_summary
from .clients.rest import XrayRestClient
from .config import XrayConfig
from .models import JsonObject, StepInput


class XrayService:
    """Provide higher-level Xray Cloud operations over REST and GraphQL clients."""

    def __init__(self, config: XrayConfig) -> None:
        self._config = config
        self._token: str | None = None

    def _bearer_token(self) -> str:
        """Resolve and cache a bearer token for this process."""

        if self._token is None:
            self._token = XrayAuthClient(self._config).token()
        return self._token

    def _graphql(self) -> XrayGraphQLClient:
        """Return an authenticated GraphQL client."""

        return XrayGraphQLClient(self._config, self._bearer_token())

    def _rest(self) -> XrayRestClient:
        """Return an authenticated REST client."""

        return XrayRestClient(self._config, self._bearer_token())

    def _jira(self) -> JiraRestClient:
        """Return an authenticated Jira REST client."""

        return JiraRestClient(self._config)

    def validate_jira_connection(self) -> JsonObject:
        """Validate Jira REST credentials."""

        return self._jira().validate_connection()

    def validate_xray_connection(self) -> JsonObject:
        """Validate Xray GraphQL credentials with a lightweight query."""

        query = """
        query ValidateXrayConnection {
          getTests(limit: 1) {
            results { issueId }
          }
        }
        """
        return self._graphql().execute(query)

    def create_issue(
        self,
        issue_type: str,
        summary: str,
        description: str | None = None,
        project_key: str | None = None,
    ) -> JsonObject:
        """Create a Jira issue."""

        return self._jira().create_issue(issue_type, summary, description, project_key)

    def get_issue(self, issue_id_or_key: str) -> JsonObject:
        """Return full Jira issue details."""

        return self._jira().get_issue(issue_id_or_key)

    def get_issue_summary(self, issue_id_or_key: str) -> JsonObject:
        """Return a compact Jira issue summary."""

        return issue_summary(self._jira().get_issue(issue_id_or_key))

    def link_issues(
        self,
        inward_issue_key: str,
        outward_issue_key: str,
        link_type: str = "Test",
    ) -> JsonObject:
        """Link two Jira issues."""

        return self._jira().link_issues(inward_issue_key, outward_issue_key, link_type)

    def resolve_issue_id(self, issue_id_or_key: str) -> str:
        """Resolve a Jira key to numeric issue id when Xray GraphQL requires it."""

        value = issue_id_or_key.strip()
        if value.isdigit():
            return value
        issue = self._jira().get_issue(value, summary_only=True)
        issue_id = issue.get("id")
        if not isinstance(issue_id, str) or not issue_id:
            raise RuntimeError(f"Could not resolve Jira issue id for {issue_id_or_key}")
        return issue_id

    def discover_project(self, project_key: str) -> JsonObject:
        """Return project settings useful for agents planning Xray commands."""

        query = """
        query ProjectSettings($projectIdOrKey: String!) {
          getProjectSettings(projectIdOrKey: $projectIdOrKey) {
            testEnvironments
            testTypeSettings {
              testTypes { id name kind }
              defaultTestTypeId
            }
          }
          getStatuses { name description color }
          getStepStatuses { name description color }
        }
        """
        return self._graphql().execute(query, {"projectIdOrKey": project_key})

    def search_tests(self, jql: str, limit: int = 25) -> JsonObject:
        """Search tests using Xray GraphQL getTests with a compact field set."""

        query = """
        query SearchTests($jql: String!, $limit: Int!) {
          getTests(jql: $jql, limit: $limit) {
            total
            start
            limit
            results {
              issueId
              testType { name kind }
              jira(fields: ["key", "summary", "status", "labels"])
            }
          }
        }
        """
        return self._graphql().execute(query, {"jql": jql, "limit": min(limit, 100)})

    def create_test(self, project_key: str, summary: str, test_type: str = "Manual") -> JsonObject:
        """Create an Xray test issue with the requested test type."""

        mutation = """
        mutation CreateTest($testType: UpdateTestTypeInput, $jira: JSON!) {
          createTest(testType: $testType, jira: $jira) {
            test {
              issueId
              testType { name kind }
              jira(fields: ["key", "summary"])
            }
            warnings
          }
        }
        """
        return self._graphql().execute(
            mutation,
            {
                "testType": {"name": test_type},
                "jira": {"fields": {"summary": summary, "project": {"key": project_key}}},
            },
        )

    def replace_steps(self, issue_id: str, steps: list[StepInput]) -> JsonObject:
        """Replace all manual steps on a test with the provided ordered steps."""

        remove_mutation = """
        mutation RemoveSteps($issueId: String!) {
          removeAllTestSteps(issueId: $issueId)
        }
        """
        add_mutation = """
        mutation AddStep($issueId: String!, $step: CreateStepInput!) {
          addTestStep(issueId: $issueId, step: $step) {
            id
            action
            data
            result
          }
        }
        """
        graphql = self._graphql()
        removed = graphql.execute(remove_mutation, {"issueId": issue_id})
        added: list[JsonObject] = []
        for step in steps:
            added.append(
                graphql.execute(
                    add_mutation,
                    {
                        "issueId": issue_id,
                        "step": {"action": step.action, "data": step.data, "result": step.result},
                    },
                )
            )
        return {"removed": removed, "added": added}

    def add_tests_to_set(self, set_id: str, test_ids: list[str]) -> JsonObject:
        """Add tests to an Xray test set by issue id."""

        mutation = """
        mutation AddTestsToSet($issueId: String!, $testIssueIds: [String]!) {
          addTestsToTestSet(issueId: $issueId, testIssueIds: $testIssueIds) {
            addedTests
            warning
          }
        }
        """
        return self._graphql().execute(mutation, {"issueId": set_id, "testIssueIds": test_ids})

    def add_tests_to_plan(self, plan_id: str, test_ids: list[str]) -> JsonObject:
        """Add tests to an Xray test plan by issue id."""

        mutation = """
        mutation AddTestsToPlan($issueId: String!, $testIssueIds: [String]!) {
          addTestsToTestPlan(issueId: $issueId, testIssueIds: $testIssueIds) {
            addedTests
            warning
          }
        }
        """
        return self._graphql().execute(mutation, {"issueId": plan_id, "testIssueIds": test_ids})

    def create_execution(self, project_key: str, summary: str, test_ids: list[str]) -> JsonObject:
        """Create a test execution and associate test issue ids."""

        mutation = """
        mutation CreateExecution($testIssueIds: [String], $jira: JSON!) {
          createTestExecution(testIssueIds: $testIssueIds, jira: $jira) {
            testExecution { issueId jira(fields: ["key", "summary"]) }
            warnings
          }
        }
        """
        return self._graphql().execute(
            mutation,
            {
                "testIssueIds": test_ids,
                "jira": {"fields": {"summary": summary, "project": {"key": project_key}}},
            },
        )

    def add_tests_to_execution(self, execution_id: str, test_ids: list[str]) -> JsonObject:
        """Add tests to an Xray test execution by Jira keys or numeric issue ids."""

        mutation = """
        mutation AddTestsToExecution($issueId: String!, $testIssueIds: [String]!) {
          addTestsToTestExecution(issueId: $issueId, testIssueIds: $testIssueIds) {
            addedTests
            warning
          }
        }
        """
        resolved_execution_id = self.resolve_issue_id(execution_id)
        resolved_test_ids = [self.resolve_issue_id(test_id) for test_id in test_ids]
        return self._graphql().execute(
            mutation,
            {"issueId": resolved_execution_id, "testIssueIds": resolved_test_ids},
        )

    def get_test_run(
        self,
        execution_id: str,
        test_id: str,
        *,
        wait: bool = False,
        attempts: int = 5,
        delay_seconds: float = 3.0,
    ) -> JsonObject:
        """Return the first matching test run for a test execution and test."""

        query = """
        query GetTestRun($testExecIssueIds: [String]!, $testIssueIds: [String]!, $limit: Int!) {
          getTestRuns(
            testExecIssueIds: $testExecIssueIds,
            testIssueIds: $testIssueIds,
            limit: $limit
          ) {
            results {
              id
              status { name }
            }
          }
        }
        """
        resolved_execution_id = self.resolve_issue_id(execution_id)
        resolved_test_id = self.resolve_issue_id(test_id)
        variables: JsonObject = {
            "testExecIssueIds": [resolved_execution_id],
            "testIssueIds": [resolved_test_id],
            "limit": 1,
        }
        remaining_attempts = max(1, attempts) if wait else 1
        for attempt in range(1, remaining_attempts + 1):
            result = self._graphql().execute(query, variables)
            if test_run_results(result):
                return result
            if attempt < remaining_attempts:
                time.sleep(max(0.0, delay_seconds))
        return result

    def upload_evidence(self, test_run_id: str, files: list[Path]) -> JsonObject:
        """Upload evidence files to an Xray test run using GraphQL attachments."""

        evidence = [
            {
                "filename": path.name,
                "mimeType": mime_type_for_path(path),
                "data": base64.b64encode(path.read_bytes()).decode("ascii"),
            }
            for path in files
        ]
        mutation = """
        mutation UploadEvidence($id: String!, $evidence: [AttachmentDataInput]!) {
          addEvidenceToTestRun(id: $id, evidence: $evidence) {
            addedEvidence
            warnings
          }
        }
        """
        return self._graphql().execute(
            mutation,
            {"id": test_run_id, "evidence": evidence},
        )

    def import_results(self, result_format: str, path: Path) -> JsonObject:
        """Import execution results through Xray REST v2."""

        return self._rest().import_results(result_format, path)

    def import_tests_bulk(self, path: Path) -> JsonObject:
        """Queue a bulk test import through Xray REST v2."""

        return self._rest().import_tests_bulk(path)

    def import_tests_bulk_status(self, job_id: str) -> JsonObject:
        """Read a bulk test import job status through Xray REST v2."""

        return self._rest().import_tests_bulk_status(job_id)


def mime_type_for_path(path: Path) -> str:
    """Return the upload MIME type for a local evidence file."""

    suffix = path.suffix.lower()
    return {
        ".png": "image/png",
        ".jpg": "image/jpeg",
        ".jpeg": "image/jpeg",
        ".gif": "image/gif",
        ".webp": "image/webp",
        ".mp4": "video/mp4",
        ".mov": "video/quicktime",
        ".avi": "video/x-msvideo",
        ".json": "application/json",
        ".txt": "text/plain",
        ".log": "text/plain",
        ".xml": "application/xml",
        ".pdf": "application/pdf",
        ".zip": "application/zip",
    }.get(suffix, "application/octet-stream")


def test_run_results(result: JsonObject) -> list[object]:
    """Return getTestRuns results from common GraphQL response envelopes."""

    data = result.get("data")
    container = data if isinstance(data, dict) else result
    runs = container.get("getTestRuns") if isinstance(container, dict) else None
    if not isinstance(runs, dict):
        return []
    values = runs.get("results")
    return values if isinstance(values, list) else []
