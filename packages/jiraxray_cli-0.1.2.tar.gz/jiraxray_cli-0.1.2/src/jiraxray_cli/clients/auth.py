"""Xray Cloud authentication client."""

from __future__ import annotations

from ..config import XrayConfig
from .http import post_with_retries


class XrayAuthClient:
    """Exchange Xray API key credentials for a short-lived bearer token."""

    def __init__(self, config: XrayConfig, timeout: float = 30.0) -> None:
        self._config = config
        self._timeout = timeout

    def token(self) -> str:
        """Return a bearer token from Xray Cloud REST v2 authentication."""

        if not self._config.client_id or not self._config.client_secret:
            raise RuntimeError("XRAY_CLIENT_ID and XRAY_CLIENT_SECRET are required")
        response = post_with_retries(
            f"{self._config.base_url}/api/v2/authenticate",
            json={"client_id": self._config.client_id, "client_secret": self._config.client_secret},
            timeout=self._timeout,
        )
        response.raise_for_status()
        value = response.json()
        if isinstance(value, str):
            return value.strip('"')
        token = value.get("token") if isinstance(value, dict) else None
        if isinstance(token, str):
            return token
        raise RuntimeError("Unexpected Xray authentication response")
