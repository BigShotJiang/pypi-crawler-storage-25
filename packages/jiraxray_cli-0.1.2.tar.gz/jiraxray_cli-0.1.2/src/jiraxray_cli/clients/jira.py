"""Jira Cloud REST v3 client."""

from __future__ import annotations

import base64
from urllib.parse import quote

from ..config import XrayConfig
from ..models import JsonObject
from .http import get_with_retries, post_with_retries


class JiraRestClient:
    """Execute Jira Cloud REST operations needed by Xray workflows."""

    def __init__(self, config: XrayConfig, timeout: float = 30.0) -> None:
        self._config = config
        self._timeout = timeout

    def _base_url(self) -> str:
        if not self._config.jira_base_url:
            raise RuntimeError("JIRA_BASE_URL is required")
        return self._config.jira_base_url

    def _auth_header(self) -> str:
        if not self._config.jira_email or not self._config.jira_api_token:
            raise RuntimeError("JIRA_EMAIL and JIRA_API_TOKEN are required")
        raw = f"{self._config.jira_email}:{self._config.jira_api_token}"
        encoded = base64.b64encode(raw.encode("utf-8")).decode("ascii")
        return f"Basic {encoded}"

    def _headers(self) -> dict[str, str]:
        return {
            "Authorization": self._auth_header(),
            "Accept": "application/json",
            "Content-Type": "application/json",
        }

    def validate_connection(self) -> JsonObject:
        """Validate Jira credentials with the current user endpoint."""

        response = get_with_retries(
            f"{self._base_url()}/rest/api/3/myself",
            headers=self._headers(),
            timeout=self._timeout,
        )
        response.raise_for_status()
        value = response.json()
        if not isinstance(value, dict):
            raise RuntimeError("Unexpected Jira current-user response")
        return value

    def create_issue(
        self,
        issue_type: str,
        summary: str,
        description: str | None = None,
        project_key: str | None = None,
    ) -> JsonObject:
        """Create a Jira issue using REST v3."""

        key = project_key or self._config.jira_project_key
        if not key:
            raise RuntimeError("JIRA_PROJECT_KEY or --project-key is required")
        fields: JsonObject = {
            "project": {"key": key},
            "issuetype": {"name": issue_type},
            "summary": summary,
        }
        if description:
            fields["description"] = adf_document(description)
        response = post_with_retries(
            f"{self._base_url()}/rest/api/3/issue",
            headers=self._headers(),
            json={"fields": fields},
            timeout=self._timeout,
        )
        response.raise_for_status()
        value = response.json()
        if not isinstance(value, dict):
            raise RuntimeError("Unexpected Jira create issue response")
        return value

    def get_issue(self, issue_id_or_key: str, *, summary_only: bool = False) -> JsonObject:
        """Return Jira issue details by key or numeric id."""

        params = (
            {"fields": "summary"}
            if summary_only
            else {"fields": "*all", "expand": "names,schema,renderedFields"}
        )
        response = get_with_retries(
            f"{self._base_url()}/rest/api/3/issue/{quote(issue_id_or_key, safe='')}",
            headers=self._headers(),
            params=params,
            timeout=self._timeout,
        )
        response.raise_for_status()
        value = response.json()
        if not isinstance(value, dict):
            raise RuntimeError("Unexpected Jira issue response")
        return value

    def link_issues(
        self,
        inward_issue_key: str,
        outward_issue_key: str,
        link_type: str,
    ) -> JsonObject:
        """Create a Jira issue link between two issues."""

        response = post_with_retries(
            f"{self._base_url()}/rest/api/3/issueLink",
            headers=self._headers(),
            json={
                "type": {"name": link_type},
                "inwardIssue": {"key": inward_issue_key},
                "outwardIssue": {"key": outward_issue_key},
            },
            timeout=self._timeout,
        )
        response.raise_for_status()
        return {
            "inwardIssue": inward_issue_key,
            "outwardIssue": outward_issue_key,
            "linkType": link_type,
        }


def adf_document(text: str) -> JsonObject:
    """Return a minimal Atlassian Document Format document for plain text."""

    return {
        "version": 1,
        "type": "doc",
        "content": [{"type": "paragraph", "content": [{"type": "text", "text": text}]}],
    }


def issue_summary(issue: JsonObject) -> JsonObject:
    """Return a compact, automation-friendly Jira issue summary."""

    fields = as_object(issue.get("fields"))
    rendered = as_object(issue.get("renderedFields"))
    status = as_object(fields.get("status"))
    return {
        "id": issue.get("id"),
        "key": issue.get("key"),
        "self": issue.get("self"),
        "projectKey": as_object(fields.get("project")).get("key"),
        "issueType": as_object(fields.get("issuetype")).get("name"),
        "summary": fields.get("summary"),
        "description": rendered.get("description") or adf_text(fields.get("description")),
        "status": status.get("name"),
        "statusCategory": as_object(status.get("statusCategory")).get("name"),
        "priority": as_object(fields.get("priority")).get("name"),
        "assignee": as_object(fields.get("assignee")).get("displayName"),
        "reporter": as_object(fields.get("reporter")).get("displayName"),
        "labels": [item for item in fields.get("labels", []) if isinstance(item, str)]
        if isinstance(fields.get("labels"), list)
        else [],
        "created": fields.get("created"),
        "updated": fields.get("updated"),
        "resolutionDate": fields.get("resolutiondate"),
        "resolution": as_object(fields.get("resolution")).get("name"),
    }


def as_object(value: object) -> JsonObject:
    """Return a dict value or an empty object."""

    return value if isinstance(value, dict) else {}


def adf_text(value: object) -> str | None:
    """Extract plain text from simple Atlassian Document Format payloads."""

    if not isinstance(value, dict):
        return None
    text = flatten_adf(value).strip()
    return text or None


def flatten_adf(node: JsonObject) -> str:
    """Flatten text nodes from an ADF tree."""

    if node.get("type") == "text" and isinstance(node.get("text"), str):
        return str(node["text"])
    content = node.get("content")
    if not isinstance(content, list):
        return ""
    joined = "".join(flatten_adf(child) for child in content if isinstance(child, dict))
    return f"{joined}\n" if node.get("type") == "paragraph" else joined
