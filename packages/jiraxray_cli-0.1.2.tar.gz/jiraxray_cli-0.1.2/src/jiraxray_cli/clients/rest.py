"""Xray Cloud REST v2 client."""

from __future__ import annotations

from pathlib import Path

from ..config import XrayConfig
from ..models import JsonObject
from .http import get_with_retries, post_with_retries

IMPORT_ENDPOINTS: dict[str, str] = {
    "xray": "/api/v2/import/execution",
    "junit": "/api/v2/import/execution/junit",
    "cucumber": "/api/v2/import/execution/cucumber",
    "nunit": "/api/v2/import/execution/nunit",
    "xunit": "/api/v2/import/execution/xunit",
    "testng": "/api/v2/import/execution/testng",
    "robot": "/api/v2/import/execution/robot",
}

BULK_TEST_IMPORT_ENDPOINT = "/api/v2/import/test/bulk"


class XrayRestClient:
    """Execute authenticated REST v2 operations against Xray Cloud."""

    def __init__(self, config: XrayConfig, token: str, timeout: float = 60.0) -> None:
        self._config = config
        self._token = token
        self._timeout = timeout

    def import_results(self, result_format: str, path: Path) -> JsonObject:
        """Import execution results from a supported report file."""

        endpoint = IMPORT_ENDPOINTS.get(result_format)
        if endpoint is None:
            supported = ", ".join(sorted(IMPORT_ENDPOINTS))
            raise ValueError(f"Unsupported result format '{result_format}'. Supported: {supported}")
        if not path.exists():
            raise FileNotFoundError(path)
        content_type = "application/json" if path.suffix.lower() == ".json" else "application/xml"
        response = post_with_retries(
            f"{self._config.base_url}{endpoint}",
            headers={"Authorization": f"Bearer {self._token}", "Content-Type": content_type},
            content=path.read_bytes(),
            timeout=self._timeout,
        )
        response.raise_for_status()
        value = response.json()
        if not isinstance(value, dict):
            raise RuntimeError("Unexpected import response")
        return value

    def import_tests_bulk(self, path: Path) -> JsonObject:
        """Queue an asynchronous Xray test bulk import job from a JSON file."""

        if not path.exists():
            raise FileNotFoundError(path)
        response = post_with_retries(
            f"{self._config.base_url}{BULK_TEST_IMPORT_ENDPOINT}",
            headers={"Authorization": f"Bearer {self._token}", "Content-Type": "application/json"},
            content=path.read_bytes(),
            timeout=self._timeout,
        )
        response.raise_for_status()
        value = response.json()
        if isinstance(value, str):
            return {"jobId": value}
        if not isinstance(value, dict):
            raise RuntimeError("Unexpected test bulk import response")
        return value

    def import_tests_bulk_status(self, job_id: str) -> JsonObject:
        """Return status for an asynchronous Xray test bulk import job."""

        response = get_with_retries(
            f"{self._config.base_url}{BULK_TEST_IMPORT_ENDPOINT}/{job_id}/status",
            headers={"Authorization": f"Bearer {self._token}"},
            timeout=self._timeout,
        )
        response.raise_for_status()
        value = response.json()
        if not isinstance(value, dict):
            raise RuntimeError("Unexpected test bulk import status response")
        return value
