"""HTTP helpers shared by Xray clients."""

from __future__ import annotations

import time
from collections.abc import Callable, Mapping

import httpx

RETRY_STATUSES = {429, 500, 502, 503, 504}
DEFAULT_RETRY_DELAY_SECONDS = 1.0
DEFAULT_MAX_ATTEMPTS = 3


def post_with_retries(url: str, **kwargs: object) -> httpx.Response:
    """POST with retry handling for transient Xray responses."""

    return request_with_retries(httpx.post, url, request_kwargs=kwargs)


def get_with_retries(url: str, **kwargs: object) -> httpx.Response:
    """GET with retry handling for transient Xray responses."""

    return request_with_retries(httpx.get, url, request_kwargs=kwargs)


def request_with_retries(
    sender: Callable[..., httpx.Response],
    url: str,
    *,
    request_kwargs: Mapping[str, object] | None = None,
    max_attempts: int = DEFAULT_MAX_ATTEMPTS,
    sleep: Callable[[float], None] = time.sleep,
) -> httpx.Response:
    """Retry rate-limited or transient HTTP responses before returning."""

    attempts = max(1, max_attempts)
    kwargs = dict(request_kwargs or {})
    response = sender(url, **kwargs)
    for _ in range(1, attempts):
        if response.status_code not in RETRY_STATUSES:
            return response
        sleep(retry_delay_seconds(response))
        response = sender(url, **kwargs)
    return response


def retry_delay_seconds(response: httpx.Response) -> float:
    """Return retry delay from Retry-After when present, otherwise a default."""

    retry_after = response.headers.get("Retry-After")
    if retry_after is None:
        return DEFAULT_RETRY_DELAY_SECONDS
    try:
        delay = float(retry_after)
    except ValueError:
        return DEFAULT_RETRY_DELAY_SECONDS
    return max(0.0, delay)
