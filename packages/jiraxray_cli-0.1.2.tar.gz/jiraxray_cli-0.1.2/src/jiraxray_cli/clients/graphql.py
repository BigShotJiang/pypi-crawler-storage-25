"""Xray Cloud GraphQL client."""

from __future__ import annotations

from ..config import XrayConfig
from ..models import JsonObject
from .http import post_with_retries


class XrayGraphQLClient:
    """Execute authenticated GraphQL operations against Xray Cloud."""

    def __init__(self, config: XrayConfig, token: str, timeout: float = 30.0) -> None:
        self._config = config
        self._token = token
        self._timeout = timeout

    def execute(self, query: str, variables: JsonObject | None = None) -> JsonObject:
        """Execute a GraphQL query or mutation and return the decoded response."""

        response = post_with_retries(
            f"{self._config.base_url}/api/v2/graphql",
            headers={"Authorization": f"Bearer {self._token}"},
            json={"query": query, "variables": variables or {}},
            timeout=self._timeout,
        )
        response.raise_for_status()
        value = response.json()
        if not isinstance(value, dict):
            raise RuntimeError("Unexpected GraphQL response")
        if value.get("errors"):
            raise RuntimeError(f"Xray GraphQL errors: {value['errors']}")
        return value
