"""Agent-facing command manifest."""

from __future__ import annotations

from dataclasses import asdict

from .models import CommandArgument, CommandHint, CommandManifestEntry, JsonObject


def command_manifest() -> list[CommandManifestEntry]:
    """Return the supported command manifest."""

    return [
        CommandManifestEntry(
            command="diagnose",
            summary="Check profile, credential presence, and endpoint settings.",
            category="diagnostics",
            risk="read-only",
            side_effect="none",
            retry_safe=True,
            supports_suite=False,
            optional_args=[
                CommandArgument(
                    "live",
                    "boolean",
                    False,
                    "Validate Jira and Xray live connectivity.",
                )
            ],
        ),
        CommandManifestEntry(
            command="commands",
            summary="List available commands in human-readable or JSON manifest form.",
            category="diagnostics",
            risk="read-only",
            side_effect="none",
            retry_safe=True,
            supports_suite=False,
        ),
        CommandManifestEntry(
            command="command",
            summary="Return detailed help for one command.",
            category="diagnostics",
            risk="read-only",
            side_effect="none",
            retry_safe=True,
            supports_suite=False,
            required_args=[
                CommandArgument("name", "string", True, "Command name, such as migrate transform.")
            ],
        ),
        CommandManifestEntry(
            command="profile init",
            summary="Create a non-secret project profile.",
            category="profile",
            risk="state-changing",
            side_effect="file-write",
            retry_safe=False,
            supports_suite=False,
            optional_args=[
                CommandArgument("force", "boolean", False, "Overwrite existing profile.")
            ],
        ),
        CommandManifestEntry(
            command="init",
            summary="Create project-local AI guidance for Codex, Claude Code, and GitHub Copilot.",
            category="authoring",
            risk="state-changing",
            side_effect="file-write",
            retry_safe=False,
            supports_suite=False,
            optional_args=[
                CommandArgument("path", "string", False, "Target repository path.", "."),
                CommandArgument("tool", "string", False, "all, codex, claude, or copilot.", "all"),
                CommandArgument(
                    "suite_name",
                    "string",
                    False,
                    "Solution name used in generated guidance.",
                    "this Xray test automation solution",
                ),
                CommandArgument("force", "boolean", False, "Overwrite existing generated files."),
            ],
            output="Generated AI guidance file paths, roles, selected tools, and next steps.",
            next_commands=[
                CommandHint("diagnose", "Verify CLI and Xray environment after setup."),
                CommandHint("commands", "Load the compact command manifest."),
            ],
        ),
        CommandManifestEntry(
            command="discover project",
            summary="Read Xray project settings and status metadata.",
            category="discovery",
            risk="read-only",
            side_effect="remote-read",
            retry_safe=True,
            supports_suite=True,
            required_args=[CommandArgument("project_key", "string", True, "Jira project key.")],
            next_commands=[
                CommandHint("tests search", "Find tests after project settings are known.")
            ],
        ),
        CommandManifestEntry(
            command="issues create",
            summary="Create a Jira issue in the configured or explicit project.",
            category="issues",
            risk="state-changing",
            side_effect="remote-write",
            retry_safe=False,
            supports_suite=True,
            required_args=[
                CommandArgument("type", "string", True, "Jira issue type name."),
                CommandArgument("summary", "string", True, "Jira issue summary."),
            ],
            optional_args=[
                CommandArgument("description", "string", False, "Plain-text Jira description."),
                CommandArgument("project_key", "string", False, "Jira project key override."),
            ],
        ),
        CommandManifestEntry(
            command="issues get",
            summary="Read full Jira issue details by key or numeric id.",
            category="issues",
            risk="read-only",
            side_effect="remote-read",
            retry_safe=True,
            supports_suite=False,
            required_args=[
                CommandArgument("issue", "string", True, "Jira issue key or numeric id."),
            ],
        ),
        CommandManifestEntry(
            command="issues summary",
            summary="Read compact Jira issue summary by key or numeric id.",
            category="issues",
            risk="read-only",
            side_effect="remote-read",
            retry_safe=True,
            supports_suite=False,
            required_args=[
                CommandArgument("issue", "string", True, "Jira issue key or numeric id."),
            ],
        ),
        CommandManifestEntry(
            command="issues link",
            summary="Link two Jira issues using a Jira issue-link type.",
            category="issues",
            risk="state-changing",
            side_effect="remote-write",
            retry_safe=False,
            supports_suite=True,
            required_args=[
                CommandArgument("inward", "string", True, "Inward Jira issue key."),
                CommandArgument("outward", "string", True, "Outward Jira issue key."),
            ],
            optional_args=[
                CommandArgument("type", "string", False, "Jira issue-link type name.", "Test"),
            ],
        ),
        CommandManifestEntry(
            command="tests search",
            summary="Search Xray tests with JQL.",
            category="test-library",
            risk="read-only",
            side_effect="remote-read",
            retry_safe=True,
            supports_suite=True,
            required_args=[
                CommandArgument("jql", "string", True, "JQL returning Xray Test issues.")
            ],
            optional_args=[
                CommandArgument("limit", "number", False, "Maximum tests to return.", 25)
            ],
        ),
        CommandManifestEntry(
            command="tests create",
            summary="Create a manual, generic, or gherkin Xray test.",
            category="test-library",
            risk="state-changing",
            side_effect="remote-write",
            retry_safe=False,
            supports_suite=True,
            required_args=[
                CommandArgument("project_key", "string", True, "Jira project key."),
                CommandArgument("summary", "string", True, "Jira issue summary."),
            ],
            optional_args=[
                CommandArgument("test_type", "string", False, "Xray test type.", "Manual")
            ],
        ),
        CommandManifestEntry(
            command="tests update-steps",
            summary="Replace manual test steps from a JSON file.",
            category="test-library",
            risk="state-changing",
            side_effect="remote-write",
            retry_safe=False,
            supports_suite=True,
            required_args=[
                CommandArgument("issue_id", "string", True, "Xray Test issue id."),
                CommandArgument(
                    "steps_file",
                    "string",
                    True,
                    "JSON file containing action/data/result steps.",
                ),
            ],
        ),
        CommandManifestEntry(
            command="tests import-bulk",
            summary="Queue an asynchronous Xray REST v2 bulk test import job.",
            category="test-library",
            risk="state-changing",
            side_effect="remote-write",
            retry_safe=False,
            supports_suite=True,
            required_args=[
                CommandArgument("path", "string", True, "Xray bulk test import JSON file."),
            ],
            next_commands=[
                CommandHint("tests import-status", "Poll the asynchronous bulk import job.")
            ],
        ),
        CommandManifestEntry(
            command="tests import-status",
            summary="Read status for an Xray REST v2 bulk test import job.",
            category="test-library",
            risk="read-only",
            side_effect="remote-read",
            retry_safe=True,
            supports_suite=True,
            required_args=[
                CommandArgument("job_id", "string", True, "Xray bulk test import job id."),
            ],
        ),
        CommandManifestEntry(
            command="sets add-tests",
            summary="Add tests to a test set.",
            category="organization",
            risk="state-changing",
            side_effect="remote-write",
            retry_safe=False,
            supports_suite=True,
            required_args=[
                CommandArgument("set_id", "string", True, "Xray Test Set issue id."),
                CommandArgument("test_ids", "string[]", True, "Xray Test issue ids."),
            ],
        ),
        CommandManifestEntry(
            command="plans add-tests",
            summary="Add tests to a test plan.",
            category="planning",
            risk="state-changing",
            side_effect="remote-write",
            retry_safe=False,
            supports_suite=True,
            required_args=[
                CommandArgument("plan_id", "string", True, "Xray Test Plan issue id."),
                CommandArgument("test_ids", "string[]", True, "Xray Test issue ids."),
            ],
        ),
        CommandManifestEntry(
            command="executions create",
            summary="Create a test execution and optionally associate tests.",
            category="execution",
            risk="state-changing",
            side_effect="remote-write",
            retry_safe=False,
            supports_suite=True,
            required_args=[
                CommandArgument("project_key", "string", True, "Jira project key."),
                CommandArgument("summary", "string", True, "Execution issue summary."),
            ],
            optional_args=[
                CommandArgument("test_ids", "string[]", False, "Xray Test issue ids.", [])
            ],
        ),
        CommandManifestEntry(
            command="executions add-tests",
            summary="Add tests to a test execution.",
            category="execution",
            risk="state-changing",
            side_effect="remote-write",
            retry_safe=False,
            supports_suite=True,
            required_args=[
                CommandArgument("execution_id", "string", True, "Xray Test Execution issue id."),
                CommandArgument("test_ids", "string[]", True, "Xray Test issue ids."),
            ],
            optional_args=[
                CommandArgument("execution", "string", False, "Alias for execution_id."),
                CommandArgument("tests", "string[]", False, "Alias for test_ids."),
            ],
        ),
        CommandManifestEntry(
            command="results import",
            summary="Import automated execution results through REST v2.",
            category="execution",
            risk="state-changing",
            side_effect="remote-write",
            retry_safe=False,
            supports_suite=True,
            required_args=[
                CommandArgument(
                    "format",
                    "string",
                    True,
                    "xray, junit, cucumber, nunit, xunit, testng, or robot.",
                ),
                CommandArgument("path", "string", True, "Result file path."),
            ],
        ),
        CommandManifestEntry(
            command="testruns get",
            summary="Read the first matching Xray test run for an execution and test.",
            category="execution",
            risk="read-only",
            side_effect="remote-read",
            retry_safe=True,
            supports_suite=False,
            required_args=[
                CommandArgument("execution_id", "string", True, "Xray Test Execution issue id."),
                CommandArgument("test_id", "string", True, "Xray Test issue id."),
            ],
            optional_args=[
                CommandArgument("execution", "string", False, "Alias for execution_id."),
                CommandArgument("test", "string", False, "Alias for test_id."),
                CommandArgument("wait", "boolean", False, "Poll while Xray materializes the run."),
                CommandArgument("attempts", "number", False, "Maximum poll attempts.", 5),
                CommandArgument("delay_seconds", "number", False, "Seconds between attempts.", 3.0),
            ],
        ),
        CommandManifestEntry(
            command="testruns upload-evidence",
            summary="Upload evidence files to an Xray test run.",
            category="execution",
            risk="state-changing",
            side_effect="remote-write",
            retry_safe=False,
            supports_suite=False,
            required_args=[
                CommandArgument("test_run_id", "string", True, "Xray test run id."),
                CommandArgument("files", "string[]", True, "Local evidence file paths."),
            ],
            optional_args=[
                CommandArgument("run", "string", False, "Alias for test_run_id."),
            ],
        ),
        CommandManifestEntry(
            command="zephyr inspect",
            summary="Inspect a Zephyr Squad Excel export and report migration risks.",
            category="migration",
            risk="read-only",
            side_effect="none",
            retry_safe=True,
            supports_suite=False,
            required_args=[CommandArgument("source", "string", True, "Zephyr Squad .xlsx export.")],
            optional_args=[CommandArgument("out", "string", False, "Markdown report path.")],
            next_commands=[
                CommandHint("migrate map init", "Create the starter Zephyr-to-Xray mapping."),
            ],
        ),
        CommandManifestEntry(
            command="migrate map init",
            summary="Create a starter Zephyr-to-Xray mapping YAML from a source export.",
            category="migration",
            risk="state-changing",
            side_effect="file-write",
            retry_safe=False,
            supports_suite=False,
            required_args=[
                CommandArgument("source", "string", True, "Zephyr Squad .xlsx export."),
                CommandArgument("project_key", "string", True, "Target Xray project key."),
                CommandArgument("out", "string", True, "Mapping YAML output path."),
            ],
            next_commands=[
                CommandHint("migrate map validate", "Validate edited mapping before transform.")
            ],
        ),
        CommandManifestEntry(
            command="migrate map validate",
            summary="Validate a Zephyr-to-Xray mapping YAML file.",
            category="migration",
            risk="read-only",
            side_effect="none",
            retry_safe=True,
            supports_suite=False,
            required_args=[CommandArgument("mapping", "string", True, "Mapping YAML path.")],
            next_commands=[
                CommandHint("migrate transform", "Transform source data after mapping is valid.")
            ],
        ),
        CommandManifestEntry(
            command="migrate transform",
            summary="Transform Zephyr Squad Excel data into a local Xray import plan JSON.",
            category="migration",
            risk="state-changing",
            side_effect="file-write",
            retry_safe=False,
            supports_suite=False,
            required_args=[
                CommandArgument("source", "string", True, "Zephyr Squad .xlsx export."),
                CommandArgument("mapping", "string", True, "Mapping YAML path."),
                CommandArgument("out", "string", True, "Import plan JSON output path."),
            ],
            next_commands=[
                CommandHint("migrate validate", "Validate the import plan before review.")
            ],
        ),
        CommandManifestEntry(
            command="migrate validate",
            summary="Validate a local Xray import plan JSON without writing to Xray.",
            category="migration",
            risk="read-only",
            side_effect="none",
            retry_safe=True,
            supports_suite=False,
            required_args=[CommandArgument("input", "string", True, "Import plan JSON path.")],
            next_commands=[
                CommandHint("migrate preview", "Create a human migration preview report.")
            ],
        ),
        CommandManifestEntry(
            command="migrate preview",
            summary="Render a Markdown preview report for a local Xray import plan.",
            category="migration",
            risk="state-changing",
            side_effect="file-write",
            retry_safe=False,
            supports_suite=False,
            required_args=[
                CommandArgument("input", "string", True, "Import plan JSON path."),
                CommandArgument("out", "string", True, "Markdown preview output path."),
            ],
        ),
        CommandManifestEntry(
            command="workflow validate-import",
            summary="Validate an execution result import file before sending it to Xray.",
            category="workflow",
            risk="read-only",
            side_effect="none",
            retry_safe=True,
            supports_suite=False,
            required_args=[
                CommandArgument(
                    "format",
                    "string",
                    True,
                    "xray, junit, cucumber, nunit, xunit, testng, or robot.",
                ),
                CommandArgument("path", "string", True, "Result file path."),
            ],
            next_commands=[CommandHint("results import", "Import once validation is clean.")],
        ),
        CommandManifestEntry(
            command="workflow sync-library",
            summary="Create tests from a reviewed local JSON or YAML test-library file.",
            category="workflow",
            risk="state-changing",
            side_effect="remote-write",
            retry_safe=False,
            supports_suite=False,
            required_args=[
                CommandArgument("source", "string", True, "JSON or YAML library sync file."),
            ],
            optional_args=[
                CommandArgument("project_key", "string", False, "Default Jira project key."),
                CommandArgument("dry_run", "boolean", False, "Validate and summarize only.", True),
            ],
        ),
        CommandManifestEntry(
            command="suite run",
            summary="Run a local deterministic workflow.",
            category="suite",
            risk="state-changing",
            side_effect="remote-write",
            retry_safe=False,
            supports_suite=False,
        ),
    ]


def manifest_as_json() -> list[JsonObject]:
    """Return the command manifest as plain JSON-compatible dictionaries."""

    return [asdict(entry) for entry in command_manifest()]


def known_suite_commands() -> set[str]:
    """Return commands that can be referenced by workflow suite steps."""

    return {entry.command for entry in command_manifest() if entry.supports_suite}
