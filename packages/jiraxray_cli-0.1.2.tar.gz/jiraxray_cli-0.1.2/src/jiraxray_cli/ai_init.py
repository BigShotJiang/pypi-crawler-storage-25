"""Generate project-local AI tool guidance for jiraxray-cli."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Literal

from .models import JsonObject

AiTool = Literal["codex", "claude", "copilot"]
AI_TOOLS: tuple[AiTool, ...] = ("codex", "claude", "copilot")


@dataclass(frozen=True)
class InitFile:
    """Represent one generated AI setup file."""

    relative_path: str
    content: str
    role: str


@dataclass(frozen=True)
class InitResult:
    """Represent the result of generating AI setup files."""

    target_root: Path
    tools: list[AiTool]
    files: list[InitFile]


def parse_tools(value: str) -> list[AiTool]:
    """Parse the init tool selector."""

    if value == "all":
        return list(AI_TOOLS)
    if value in AI_TOOLS:
        return [value]
    supported = ", ".join(("all", *AI_TOOLS))
    raise ValueError(f"Unsupported tool '{value}'. Supported: {supported}")


def run_init(target_root: Path, tool: str, suite_name: str, force: bool = False) -> InitResult:
    """Generate host-specific AI guidance files in a target repository."""

    tools = parse_tools(tool)
    root = target_root.expanduser().resolve()
    if not root.exists():
        raise FileNotFoundError(root)
    if not root.is_dir():
        raise NotADirectoryError(root)

    files = build_init_files(tools, suite_name)
    existing = [file.relative_path for file in files if (root / file.relative_path).exists()]
    if existing and not force:
        paths = ", ".join(existing[:5])
        suffix = "" if len(existing) <= 5 else f", and {len(existing) - 5} more"
        raise FileExistsError(f"Refusing to overwrite existing files: {paths}{suffix}")

    for file in files:
        path = root / file.relative_path
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(ensure_newline(file.content), encoding="utf-8")

    return InitResult(target_root=root, tools=tools, files=files)


def init_result_data(result: InitResult, suite_name: str) -> JsonObject:
    """Return a compact JSON-compatible init result."""

    return {
        "targetRoot": str(result.target_root),
        "suiteName": suite_name,
        "tools": result.tools,
        "files": [
            {
                "path": str(result.target_root / file.relative_path),
                "relativePath": file.relative_path,
                "role": file.role,
            }
            for file in result.files
        ],
        "next": [
            "Run jiraxray-cli diagnose --json to verify credentials and endpoints.",
            "Run jiraxray-cli commands --json before issuing Xray commands.",
            "Ask the selected AI tool to use the Xray solution alignment skill in the target repo.",
        ],
    }


def build_init_files(tools: list[AiTool], suite_name: str) -> list[InitFile]:
    """Build the generated file list for selected AI tools."""

    files = [
        InitFile("AGENTS.md", shared_agents(suite_name), "shared agent instructions"),
        InitFile(
            ".jiraxray-cli/ai/README.md",
            ai_setup_readme(suite_name, tools),
            "AI setup summary",
        ),
        InitFile(
            ".jiraxray-cli/ai/tool-approaches.md",
            tool_approaches(suite_name, tools),
            "host-specific AI tool reference",
        ),
    ]
    if "codex" in tools:
        files.extend(codex_files(suite_name))
    if "claude" in tools:
        files.extend(claude_files(suite_name))
    if "copilot" in tools:
        files.extend(copilot_files(suite_name))
    return files


def codex_files(suite_name: str) -> list[InitFile]:
    """Return Codex-specific generated files."""

    return skill_files(".agents/skills", "Codex") + [
        InitFile(
            ".codex/agents/xray-test-engineer.toml",
            codex_agent("xray_test_engineer", suite_name, "engineer"),
            "Codex Xray test engineer agent",
        ),
        InitFile(
            ".codex/agents/xray-solution-auditor.toml",
            codex_agent("xray_solution_auditor", suite_name, "auditor"),
            "Codex Xray solution auditor agent",
        ),
    ]


def claude_files(suite_name: str) -> list[InitFile]:
    """Return Claude-specific generated files."""

    return [
        InitFile("CLAUDE.md", claude_md(suite_name), "Claude always-on instructions"),
        *skill_files(".claude/skills", "Claude"),
        InitFile(
            ".claude/agents/xray-test-engineer.md",
            markdown_agent("xray-test-engineer", suite_name, "engineer", "Claude"),
            "Claude Xray test engineer agent",
        ),
        InitFile(
            ".claude/agents/xray-solution-auditor.md",
            markdown_agent("xray-solution-auditor", suite_name, "auditor", "Claude"),
            "Claude Xray solution auditor agent",
        ),
    ]


def copilot_files(suite_name: str) -> list[InitFile]:
    """Return GitHub Copilot-specific generated files."""

    return [
        InitFile(
            ".github/copilot-instructions.md",
            copilot_instructions(suite_name),
            "Copilot repository instructions",
        ),
        InitFile(
            ".github/instructions/jiraxray-cli.instructions.md",
            copilot_cli_instructions(),
            "Copilot path/task instructions",
        ),
        *skill_files(".github/skills", "GitHub Copilot"),
        InitFile(
            ".github/prompts/xray-solution-onboarding.prompt.md",
            copilot_prompt("solution-onboarding"),
            "Copilot reusable onboarding prompt",
        ),
        InitFile(
            ".github/prompts/xray-library-sync.prompt.md",
            copilot_prompt("library-sync"),
            "Copilot reusable library sync prompt",
        ),
        InitFile(
            ".github/prompts/xray-execution-reporting.prompt.md",
            copilot_prompt("execution-reporting"),
            "Copilot reusable execution reporting prompt",
        ),
        InitFile(
            ".github/agents/xray-test-engineer.agent.md",
            markdown_agent("xray-test-engineer", suite_name, "engineer", "GitHub Copilot"),
            "Copilot Xray test engineer agent",
        ),
        InitFile(
            ".github/agents/xray-solution-auditor.agent.md",
            markdown_agent("xray-solution-auditor", suite_name, "auditor", "GitHub Copilot"),
            "Copilot Xray solution auditor agent",
        ),
    ]


def skill_files(base: str, host: str) -> list[InitFile]:
    """Return token-efficient skill files and references for one host."""

    skill_names = [
        "jiraxray-cli",
        "zephyr-migration-analyst",
        "xray-test-library-manager",
        "xray-import-reviewer",
        "xray-migration-auditor",
        "xray-solution-alignment",
        "xray-solution-maintainer",
    ]
    files: list[InitFile] = []
    references = shared_references()
    for skill_name in skill_names:
        files.append(
            InitFile(
                f"{base}/{skill_name}/SKILL.md",
                skill_body(skill_name, host),
                f"{host} skill: {skill_name}",
            )
        )
        for relative, content in references.items():
            files.append(
                InitFile(
                    f"{base}/{skill_name}/references/{relative}",
                    content,
                    f"{host} skill reference: {skill_name}/{relative}",
                )
            )
    return files


def skill_body(skill_name: str, host: str) -> str:
    """Return a concise skill body with references for deeper context."""

    descriptions = {
        "jiraxray-cli": (
            "Use when working with Xray Cloud through jiraxray-cli, including "
            "diagnostics, command discovery, profiles, compact JSON, and safe sequencing."
        ),
        "zephyr-migration-analyst": (
            "Use to inspect Zephyr Squad exports, identify migration risks, generate "
            "mapping files, and prepare reviewable Xray import plans."
        ),
        "xray-test-library-manager": (
            "Use for Xray test authoring and organization: tests, manual steps, "
            "folders, preconditions, test sets, test plans, and duplicate avoidance."
        ),
        "xray-import-reviewer": (
            "Use to validate migration import plans, review unsupported Zephyr data, "
            "and prepare safe Xray bulk import decisions."
        ),
        "xray-migration-auditor": (
            "Use to compare source exports, mapping files, import plans, and preview "
            "reports for completeness before any Xray write."
        ),
        "xray-solution-alignment": (
            "Use to inspect the attached test solution and update generated skills, "
            "references, prompts, agents, and instructions so they match reality."
        ),
        "xray-solution-maintainer": (
            "Use to improve jiraxray-cli itself, including command design, "
            "tests, docs, generated agents, skills, references, and production readiness."
        ),
    }
    reference_map = {
        "jiraxray-cli": "cli-workflows.md",
        "zephyr-migration-analyst": "zephyr-migration.md",
        "xray-test-library-manager": "test-library.md",
        "xray-import-reviewer": "import-review.md",
        "xray-migration-auditor": "migration-audit.md",
        "xray-solution-alignment": "solution-alignment.md",
        "xray-solution-maintainer": "solution-maintenance.md",
    }
    reference = reference_map[skill_name]
    return f"""---
name: {skill_name}
description: {descriptions[skill_name]}
---

# {skill_name}

Use this {host} skill only when the task matches the description.

## First Steps

1. Run `jiraxray-cli diagnose --json`.
2. Run `jiraxray-cli commands --json`.
3. Prefer compact JSON and high-level workflow commands before raw API detail.

## References

- Open `references/{reference}` for the detailed workflow for this task.
- Open `references/cli-workflows.md` when unsure which CLI command to use next.
- Open `references/solution-alignment.md` before changing generated guidance.
- Open `references/solution-maintenance.md` before changing this CLI or its skills.

Keep the context small: read only the reference needed for the current task.
"""


def shared_references() -> dict[str, str]:
    """Return shared reference files used by all host skills."""

    return {
        "cli-workflows.md": """# CLI Workflows

Use the CLI as the runtime contract. Do not infer command schemas from memory.

1. `jiraxray-cli diagnose --json`
2. `jiraxray-cli commands --json`
3. Choose the smallest command or workflow that answers the task.

Use `--view compact` for normal agent work, `--view full` for deeper inspection, and
`--view raw` only when preserving the Xray response shape matters.

Secrets are environment-only: `XRAY_CLIENT_ID`, `XRAY_CLIENT_SECRET`, optional
`XRAY_REGION`, and optional `XRAY_BASE_URL`.

Prefer deterministic workflows:

- validate imports before importing: `workflow validate-import`
- dry-run syncs before creating tests: `workflow sync-library --dry-run`
- dry-run suites before running remote writes: `suite run <name> --dry-run`
""",
        "zephyr-migration.md": """# Zephyr Migration Analysis

Use this workflow when moving Zephyr Squad exports toward Xray Cloud.

1. Inspect the export:
   `jiraxray-cli zephyr inspect --source zephyr-export.xlsx --out inspect.md`
2. Generate a starter map:
   `jiraxray-cli migrate map init --source zephyr-export.xlsx`
   `  --project-key QA --out zephyr-to-xray.yaml`
3. Review mappings for summary, folder, priority, status, labels, components,
   preconditions, and step action/data/result fields.
4. Transform only after the mapping is reviewed:
   `jiraxray-cli migrate transform --source zephyr-export.xlsx`
   `  --mapping zephyr-to-xray.yaml --out xray-import-plan.json`

Do not import to Xray from this milestone. Produce reviewable files first.
""",
        "test-library.md": """# Xray Test Library Workflows

Search before creating tests. Use JQL that limits project, labels, components,
folders, or summary patterns to avoid duplicate assets.

Common flow:

1. `discover project --project-key KEY --json`
2. `tests search --jql "project = KEY AND issuetype = Test ..." --json`
3. `tests create --project-key KEY --summary "..." --test-type Manual --json`
4. `tests update-steps --issue-id ID --steps-file steps.json --json`
5. `sets add-tests` or `plans add-tests` when organization is needed.

Manual step JSON must be a list of objects with `action`, optional `data`, and
optional `result`. Preserve the target solution's naming, labels, components,
folder conventions, and traceability rules.
""",
        "execution-reporting.md": """# Execution Reporting Workflows

Use this for executions, automated result imports, statuses, evidence, and CI.

Validate before import:

```bash
jiraxray-cli workflow validate-import --format junit --path report.xml --json
```

Supported result formats: `xray`, `junit`, `cucumber`, `nunit`, `xunit`,
`testng`, and `robot`.

When reporting from CI, keep paths relative to the workspace where possible,
record the exact report path, and preserve the target solution's artifact and
evidence conventions.
""",
        "import-review.md": """# Xray Import Review

Use this before any migration import is allowed.

Review:

- source inspection warnings
- mapping YAML validity
- duplicate policy
- missing summaries or project keys
- tests without manual steps
- BDD/Gherkin indicators
- attachment indicators
- unsupported custom fields

Run:

```bash
jiraxray-cli migrate validate --input xray-import-plan.json
jiraxray-cli migrate preview --input xray-import-plan.json --out migration-preview.md
```

Only proceed to a future live import command when the preview is reviewed and
approved by a human.
""",
        "migration-audit.md": """# Migration Audit

Use this to audit whether the migration package is complete enough to trust.

Required artifacts:

- original Zephyr export
- inspection Markdown report
- reviewed mapping YAML
- transformed import plan JSON
- validation output
- preview Markdown report

Check that every warning is either fixed or explicitly accepted. Count source
tests against import-plan tests and identify skipped or duplicate cases.
""",
        "automation-suites.md": """# Automation Suite Workflows

Workflow files live under `.jiraxray-cli/workflows/*.yaml` and should encode
repeatable deterministic processes. Use AI to author, review, or select suites;
the CLI should run known steps without model judgment.

Use:

- `suite init`
- `suite list`
- `suite validate <name>`
- `suite explain <name>`
- `suite run <name> --dry-run`
- `suite run <name>`

Use typed inputs for project keys, report paths, test ids, labels, or release
names that change between runs. Always dry-run before remote writes.
""",
        "solution-alignment.md": """# Solution Alignment

Use this before relying on generated guidance in a real test solution.

Inspect the attached repository in passes:

1. Inventory tests, fixtures, page/screen/component objects, helpers, data,
   config, CI, reports, evidence, docs, and generated/vendor exclusions.
2. Identify language, framework, runner, test naming, data model, secrets model,
   Xray conventions, report formats, and artifact paths.
3. Update generated always-on instructions only with short, broadly applicable
   rules.
4. Put detailed framework, path, and workflow guidance in skill references.
5. Add or update `.jiraxray-cli/workflows/*.yaml` only for repeatable known
   processes.

Do not rewrite suite architecture without a baseline command and human approval.
""",
        "solution-maintenance.md": """# Solution Maintenance

Use this when improving jiraxray-cli itself.

Principles:

- Keep the CLI as the primary interface for humans, agents, scripts, CI, and Docker.
- Treat MCP as a future adapter over shared services, not a separate implementation.
- Keep always-on agent text short; put detailed guidance in skill references.
- Add or update a skill only when it captures a repeated workflow, command pitfall,
  API constraint, or repo convention that would reduce future tokens or errors.
- Update an agent only when the repo purpose, boundaries, or decision rules change.
- Remove stale guidance when command behavior changes.

Before finishing:

1. Update `commands`/manifest metadata for new commands.
2. Add API-shape tests for remote calls.
3. Run focused tests with `uv run pytest`.
4. Update docs only where users or agents need the new behavior.
""",
    }


def shared_agents(suite_name: str) -> str:
    """Return shared AGENTS.md content."""

    return f"""# AI Agent Instructions

This repository contains {suite_name}.

- Use `jiraxray-cli` for Xray Cloud test management workflows.
- Start with `jiraxray-cli diagnose --json` and `jiraxray-cli commands --json`.
- Keep secrets in environment variables only.
- Prefer compact JSON and deterministic workflow suites.
- Use generated skills for detailed workflows; do not load every reference at once.
- Align generated guidance with this repository before broad changes.
"""


def ai_setup_readme(suite_name: str, tools: list[AiTool]) -> str:
    """Return the generated AI setup README."""

    selected = ", ".join(tools)
    return f"""# jiraxray-cli AI Setup

Generated for {suite_name}.

Selected tools: {selected}.

Start with:

```bash
jiraxray-cli diagnose --json
jiraxray-cli commands --json
```

Ask the AI tool to use the Xray solution alignment skill before broad changes.
"""


def tool_approaches(suite_name: str, tools: list[AiTool]) -> str:
    """Return host-specific usage guidance."""

    selected = ", ".join(tools)
    return f"""# AI Tool Approaches

Generated for {suite_name}. Selected tools: {selected}.

## Shared Strategy

Always-on files stay short. Skills contain trigger-focused instructions.
Detailed workflows live in `references/*.md` and should be read only when needed.

## Codex

Codex reads repo skills from `.agents/skills`. Project agents live under
`.codex/agents` as TOML. Use `$xray-solution-alignment` to adapt guidance after
inspecting the real solution.

## Claude Code

Claude reads project skills from `.claude/skills`, subagents from
`.claude/agents`, and compact standing instructions from `CLAUDE.md`.

## GitHub Copilot

Copilot uses `.github/copilot-instructions.md` for broad repo rules,
`.github/skills` for detailed skills, `.github/prompts` for reusable task
starts, and `.github/agents` for custom agent profiles.
"""


def codex_agent(name: str, suite_name: str, role: str) -> str:
    """Return a Codex TOML project agent."""

    description = (
        "Functional and automation testing specialist for Xray CLI work"
        if role == "engineer"
        else "Read-heavy auditor for generated Xray guidance and workflows"
    )
    sandbox = "workspace-write" if role == "engineer" else "read-only"
    return f'''name = "{name}"
description = "{description} in {escape_toml(suite_name)}."
sandbox_mode = "{sandbox}"
developer_instructions = """
Use jiraxray-cli as the Xray runtime surface.
Start with diagnose and commands JSON before choosing workflows.
Keep generated guidance token-efficient: short skill bodies, detailed references.
When alignment is requested, inspect the real solution before updating guidance.
"""
'''


def markdown_agent(name: str, suite_name: str, role: str, host: str) -> str:
    """Return a Markdown custom agent profile."""

    description = (
        "Functional and automation testing specialist for Xray CLI workflows"
        if role == "engineer"
        else "Read-heavy auditor for Xray AI guidance, references, and workflows"
    )
    tools_block = ""
    model_block = ""
    if host == "Claude":
        tools_block = "tools: Read, Grep, Glob, Bash, Edit, Write\n"
        model_block = "model: inherit\n"
    elif host == "GitHub Copilot":
        tools_block = "tools:\n  - codebase\n  - search\n  - editFiles\n  - runCommands\n"
    return f"""---
name: {name}
description: {description} in {suite_name}.
{tools_block}{model_block}
---

Use `jiraxray-cli` as the runtime surface for Xray Cloud work.

Start with diagnostics and command discovery. Prefer compact JSON, dry-runs, and
deterministic suites. Use solution-alignment guidance before broad repo changes.
"""


def claude_md(suite_name: str) -> str:
    """Return concise Claude always-on instructions."""

    return f"""# Claude Instructions

This repository contains {suite_name}. Use `/jiraxray-cli` for Xray CLI
workflows and `/xray-solution-alignment` before broad guidance updates.

Keep context small: load only the skill reference needed for the current task.
"""


def copilot_instructions(suite_name: str) -> str:
    """Return concise Copilot repository instructions."""

    return f"""# Copilot Instructions

This repository contains {suite_name}.

- Use `/jiraxray-cli` for Xray Cloud CLI workflows.
- Use `/xray-solution-alignment` before broad repository guidance changes.
- Prefer compact JSON, dry-run validation, and deterministic workflow suites.
- Keep long details in skill references instead of always-on instructions.
"""


def copilot_cli_instructions() -> str:
    """Return Copilot instruction file for CLI usage."""

    return """---
applyTo: "**"
---

# jiraxray-cli

Use `jiraxray-cli diagnose --json` and `jiraxray-cli commands --json`
before planning Xray operations. Use compact JSON first and validate imports or
suite runs before remote writes.
"""


def copilot_prompt(kind: str) -> str:
    """Return a reusable Copilot prompt."""

    prompts = {
        "solution-onboarding": (
            "Inspect this test solution and align Xray CLI skills, references, and workflows."
        ),
        "library-sync": (
            "Plan and dry-run an Xray test library sync from reviewed local test definitions."
        ),
        "execution-reporting": (
            "Validate reports and plan Xray execution reporting with jiraxray-cli."
        ),
    }
    return f"""# {kind}

{prompts[kind]}

Start with `jiraxray-cli diagnose --json` and `jiraxray-cli commands --json`.
Use the relevant Xray skill reference before proposing changes.
"""


def escape_toml(value: str) -> str:
    """Escape text for a TOML string."""

    return value.replace("\\", "\\\\").replace('"', '\\"')


def ensure_newline(value: str) -> str:
    """Ensure generated files end with a newline."""

    return value if value.endswith("\n") else value + "\n"
